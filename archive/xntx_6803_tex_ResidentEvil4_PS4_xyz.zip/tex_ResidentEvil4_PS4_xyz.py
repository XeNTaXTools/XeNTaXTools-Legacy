from inc_noesis import *
import binascii

def registerNoesisTypes():
	handle = noesis.register("Resident Evil 4 [PS4]", ".xyz")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
	#noesis.logPopup()
	return 1

def imageUntilePS4(buffer, width, height, bpb):
    # PS4 GNF unswizzle python library translated by TheUkranianBard
    # adaptation of Scarlet's GNF image untiling by xdanieldzd (https://github.com/xdanieldzd)
    # https://github.com/xdanieldzd/Scarlet/blob/8c56632eb2968e64b6d6fad14af3758e606a127d/Scarlet/Drawing/ImageBinary.cs#L1256
    # assume MIT License
    PS4Tile = (
         0,  1,  8,  9,  2,  3, 10, 11,
        16, 17, 24, 25, 18, 19, 26, 27,
         4,  5, 12, 13,  6,  7, 14, 15,
        20, 21, 28, 29, 22, 23, 30, 31,
        32, 33, 40, 41, 34, 35, 42, 43,
        48, 49, 56, 57, 50, 51, 58, 59,
        36, 37, 44, 45, 38, 39, 46, 47,
        52, 53, 60, 61, 54, 55, 62, 63
    )
    tileWidth = 8
    tileHeight = 8
    tileSize = tileWidth * tileHeight
    # untiling setup
    if (width % tileWidth) or (height % tileHeight):
        width_show = width
        height_show = height
        width = width_real = ((width + (tileWidth - 1)) // tileWidth) * tileWidth
        height = height_real = ((height + (tileHeight - 1)) // tileHeight) * tileHeight
    else:
        width_show = width_real = width
        height_show = height_real = height
    RowSize = bpb * width
    out = bytearray(buffer)
    # untiling
    for InY in range(0, height):
        for InX in range(0, width):
            Z = InY * width + InX
            globalX = (Z // tileSize) * tileWidth
            globalY = (globalX // width) * tileHeight
            globalX %= width
            inTileX = Z % tileWidth
            inTileY = (Z // tileWidth) % tileHeight
            inTilePixel = inTileY * tileHeight + inTileX
            inTilePixel = PS4Tile[inTilePixel]
            inTileX = inTilePixel % tileWidth
            inTileY = inTilePixel // tileHeight
            OutX = globalX + inTileX
            OutY = globalY + inTileY
            PixelOffset_In = InX * bpb + InY * RowSize
            PixelOffset_Out = OutX * bpb + OutY * RowSize
            out[PixelOffset_Out: PixelOffset_Out+bpb] = buffer[PixelOffset_In: PixelOffset_In + bpb]
    # crop
    if width_show != width_real or height_show != height_real:
        crop = bytearray(width_show * height_show * bpb)
        ReadInOneRow = width_show * bpb
        for Y in range(0,height_show):
            Offset_IN = Y * RowSize
            Offset_OUT = Y * width_show * bpb
            crop[Offset_OUT: Offset_OUT + ReadInOneRow] = out[Offset_IN: Offset_IN + ReadInOneRow]
        out = crop
    return out
    
def noepyCheckType(data):
    bs = NoeBitStream(data)
    if bs.readBytes(4) != b'\x58\x59\x5a\x20': return 0
    return 1
    
def noepyLoadRGBA(data, texList):
    rapi.processCommands("-texnorepfn")
    bs = NoeBitStream(data)
    bs.seek(0x4)
    headerSize = bs.readUInt() + 8
    bs.readUByte()
    numTexs = bs.readUByte()
    bs.readUByte()
    bs.readUByte()
    xyzSize = bs.readUInt()
    for i in range(numTexs):
        texName = rapi.getExtensionlessName(rapi.getInputName())
        if numTexs > 1:
            i = i + 1
            texName = texName + "_" + str(i)
            print(texName)
        bs.seek(0x6, 1)
        imgFmt = bs.readUByte()
        print(hex(imgFmt), ":format")
        flags = bs.readBits(4)
        print(flags, ":flags")
        bs.readBits(4)
        width = bs.readUShort()
        print(width, ":width")
        height = bs.readUShort()
        print(height, ":height")
        imgWidth = (width + 1) - 0xC000    
        print(imgWidth, ":width2")
        imgHeight = ((height + 1) - 0x7000) << 2
        print(imgHeight, ":height2")
        bs.seek(0x10, 1)
        datasize = bs.readUInt()
        tmp1 = bs.tell()
        print(hex(datasize), ":datasize")
        bs.seek(headerSize)
        data = bs.readBytes(datasize)
        headerSize = bs.tell()
        if imgFmt == 0x30:
            data2 = imageUntilePS4(data, imgWidth >> 2, imgHeight >> 2, 8)
            texFmt = noesis.NOESISTEX_DXT1
        elif imgFmt == 0x40:
            data2 = imageUntilePS4(data, imgWidth >> 2, imgHeight >> 2, 16)
            texFmt = noesis.NOESISTEX_DXT3
        elif imgFmt == 0x50:
            data2 = imageUntilePS4(data, imgWidth >> 2, imgHeight >> 2, 16)
            texFmt = noesis.NOESISTEX_DXT5
        elif imgFmt == 0x60:
            data = imageUntilePS4(data, imgWidth >> 2, imgHeight >> 2, 8)
            #data2 = rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_ATI1)
            format = b'\x41\x54\x49\x31'
            type = b'\x51\x00\x00\x00'
        elif imgFmt == 0x70:
            data = imageUntilePS4(data, imgWidth >> 2, imgHeight >> 2, 16)
            #data2 = rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_ATI2)
            format = b'\x41\x54\x49\x32'
            type = b'\x54\x00\x00\x00'
        elif imgFmt == 0x80:
            data = imageUntilePS4(data, imgWidth >> 2, imgHeight >> 2, 16)
            #data2 = rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_BC6S) #noesis.FOURCC_BC6H
            if flags == 0x2:
                flags = 0x6
                type = b'\x5F\x00\x00\x00' 
            elif flags == 0x6:
                type = b'\x60\x00\x00\x00'
        elif imgFmt == 0x90:
            data = imageUntilePS4(data, imgWidth >> 2, imgHeight >> 2, 16)
            data2 = rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_BC7)
            texFmt = noesis.NOESISTEX_RGBA32
        elif imgFmt == 0xa0:
            data = imageUntilePS4(data, imgWidth, imgHeight, 4)
            data2 = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "b8 g8 r8 a8")
            texFmt = noesis.NOESISTEX_RGBA32
        if imgFmt == 0x60 or imgFmt == 0x70 or imgFmt == 0x80:
            if flags == 0x6:
                #build dx10 dds header and append tex data
                ddsHeader = b'\x44\x44\x53\x20\x7C\x00\x00\x00\x07\x10\x00\x00'
                ddsHeader += bytearray(noePack("I", imgHeight))
                ddsHeader += bytearray(noePack("I", imgWidth))
                ddsHeader += bytearray(noePack("I", datasize))
                ddsHeader += b'\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x20\x00\x00\x00\x04\x00\x00\x00\x44\x58\x31\x30\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x20\x00\x00\x00\x04\x00\x00\x00'
                ddsHeader += type
                #print(binascii.hexlify(type))
                ddsHeader += b'\x03\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00'
                #print(binascii.hexlify(ddsHeader))
                ddsHeader += data
                texList.append(rapi.loadTexByHandler(ddsHeader, ".dds"))
            else:
                #build dds header and append tex data
                ddsHeader = b'\x44\x44\x53\x20\x7C\x00\x00\x00\x07\x10\x00\x00'
                ddsHeader += bytearray(noePack("I", imgHeight))
                ddsHeader += bytearray(noePack("I", imgWidth))
                ddsHeader += bytearray(noePack("I", datasize))
                ddsHeader += b'\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x20\x00\x00\x00\x04\x00\x00\x00'
                ddsHeader += format
                #print(binascii.hexlify(format))
                ddsHeader += b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
                #print(binascii.hexlify(ddsHeader))
                ddsHeader += data
                texList.append(rapi.loadTexByHandler(ddsHeader, ".dds"))
        else:
            texList.append(NoeTexture(texName, imgWidth, imgHeight, data2, texFmt))
        bs.seek(tmp1)    
    return 1