from inc_noesis import *
import noesis
import rapi

def registerNoesisTypes():
    handle = noesis.register("Skyforge", ".bin")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    Magic = bs.readInt()
    #print(Magic)
    if Magic != 0x0: 
        return 0
    return 1   

def noepyLoadModel(data, mdlList):
    ctx = rapi.rpgCreateContext()
    bs = NoeBitStream(data)
    fileName = rapi.getLocalFileName(rapi.getInputName()).rstrip(".bin")
    rapi.rpgSetName(fileName)
    bs.seek(0x4, NOESEEK_ABS)
    VBytes = 24            #FVF/vertex stride
    VCount = bs.readUInt() // VBytes
    #print(hex(VCount), "vcount")
    VBuf = bs.readBytes(VCount * VBytes)
    skip = bs.readBytes(4)
    FCount = bs.readUInt() // 2
    #print(hex(FCount), "fcount")
    IBuf = bs.readBytes(FCount * 2) 
    rapi.rpgBindPositionBufferOfs(VBuf, noesis.RPGEODATA_SHORT, VBytes, 0)   #position of vertices
    rapi.rpgBindUV1BufferOfs(VBuf, noesis.RPGEODATA_SHORT, VBytes, 8)   #UVs    
    rapi.rpgCommitTriangles(IBuf, noesis.RPGEODATA_USHORT, FCount, noesis.RPGEO_TRIANGLE, 1) #SHORT for word indices
    mdl = rapi.rpgConstructModel()                                                          
    mdlList.append(mdl)
    rapi.rpgClearBufferBinds()
    return 1