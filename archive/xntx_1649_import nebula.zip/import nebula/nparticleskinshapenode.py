import Blender
from Blender import *
from Blender import Armature as A
from Blender.Mathutils import *
from math import *
import struct,os,bpy
from word import word

def nparticleskinshapenode(plik,root,noextend,scn,txt,numer):
        klucz = word(4,plik)
        if klucz=='BCLS':
                plik.read(26)
                klucz=word(4,plik)
                #print klucz
        while(klucz=='TXTS'):
                struct.unpack('h', plik.read(2))
                long = struct.unpack('h', plik.read(2))[0]
                typtextury = word(long,plik)
                if typtextury=='DiffMap0':
                    long = struct.unpack('h', plik.read(2))[0]
                    textura = word(long,plik)
                    texturediff = Texture.New('DIFF')
                    texturediff.type = Texture.Types.IMAGE
                    image = None
                    path=root+'textures'+os.sep+textura[9:]
                    try:
                       image = Image.Load(path)
                       print textura
                    except:
                       print 'nie wczytano',textura
                    texturediff.image = image
                elif typtextury=='BumpMap0':
                    long = struct.unpack('h', plik.read(2))[0]
                    textura = word(long,plik)
                    texturebump = Texture.New('NORM')
                    texturebump.type = Texture.Types.IMAGE
                    texturebump.setImageFlags('NormalMap') 
                    image = None
                    path=root+'textures'+os.sep+textura[9:]
                    try:
                       image = Image.Load(path)
                       print textura
                    except:
                       print 'nie wczytano',textura
                    texturebump.image = image
                elif typtextury=='SpecMap0':
                    long = struct.unpack('h', plik.read(2))[0]
                    textura = word(long,plik)
                    texturespec = Texture.New('SPEC')
                    texturespec.type = Texture.Types.IMAGE
                    image = None
                    path=root+'textures'+os.sep+textura[9:]
                    try:
                       image = Image.Load(path)
                       print textura
                    except:
                       print 'nie wczytano',textura
                    texturespec.image = image
                else:
                    long = struct.unpack('h', plik.read(2))[0]
                    textura = word(long,plik)
                klucz=word(4,plik)
                #print klucz
        while(klucz=='TLFS' or klucz=='TNIS'):
                struct.unpack('h', plik.read(2))
                long = struct.unpack('h', plik.read(2))[0]
                parametr = word(long,plik)                
                print parametr,'=',struct.unpack('f', plik.read(4))[0]
                klucz=word(4,plik)
                #print klucz
        if klucz=='NSMS':#name material
                struct.unpack('h', plik.read(2))
                long = struct.unpack('h', plik.read(2))[0]
                parametr = word(long,plik)
                print'name material',parametr
                parametr=noextend+'-mat'+str(numer)
                if len(parametr)>20:
	                 parametr=parametr[len(parametr)-20:]    
                material = Material.New(parametr)
                txt.write(str(parametr)+'\n')
                try:
                   material.setTexture(0,texturediff,Texture.TexCo.UV,Texture.MapTo.COL) 
                   material.setTexture(1,texturebump,Texture.TexCo.UV,Texture.MapTo.NOR)
                   material.setTexture(2,texturespec,Texture.TexCo.UV,Texture.MapTo.SPEC) 
                except:
	               print'no materials'
                klucz=word(4,plik)
        if klucz=='DHSS':#hair,skinned,lightmap
                struct.unpack('h', plik.read(2))
                long = struct.unpack('h', plik.read(2))[0]
                parametr = word(long,plik)
                print'material type:',parametr
                txt.write(str('material type: ')+str(parametr)+'\n')
                klucz=word(4,plik)
                #print klucz
        if klucz=='HSMS':
                struct.unpack('h', plik.read(2))
                long = struct.unpack('h', plik.read(2))[0]
                mesh = word(long,plik)
                txt.write(str(mesh)+'\n')
                print mesh
                klucz=word(4,plik)
        print klucz#IRGS
        print struct.unpack(6*'b', plik.read(6))
        klucz=word(4,plik)
        print klucz#SVNS
        print struct.unpack(3*'b', plik.read(3))
        klucz=word(4,plik)
        if klucz=='AKSS':
             print klucz#AKSS
             struct.unpack('h', plik.read(2))
             long = struct.unpack('H', plik.read(2))[0]
             print word(long,plik)
             klucz=word(4,plik)
        if klucz=='AVCS':
             struct.unpack(38*'b', plik.read(38))
             klucz=word(4,plik)
        if klucz=='BVCS':
             struct.unpack(38*'b', plik.read(38))
             klucz=word(4,plik)
        if klucz=='DVCS':
             struct.unpack(38*'b', plik.read(38))
             klucz=word(4,plik)
        if klucz=='EVCS':
             struct.unpack(38*'b', plik.read(38))
             klucz=word(4,plik)
        if klucz=='FVCS':
             struct.unpack(38*'b', plik.read(38))
             klucz=word(4,plik)
        if klucz=='HVCS':
             struct.unpack(38*'b', plik.read(38))
             klucz=word(4,plik)
        if klucz=='JVCS':
             struct.unpack(38*'b', plik.read(38))
             klucz=word(4,plik)
        if klucz=='MVCS':
             struct.unpack(38*'b', plik.read(38))
             klucz=word(4,plik)
        if klucz=='LVCS':
             struct.unpack(38*'b', plik.read(38))
             klucz=word(4,plik)
        if klucz=='MMTS':
             struct.unpack(38*'b', plik.read(38))
             klucz=word(4,plik)
        if klucz=='NVCS':
             struct.unpack(38*'b', plik.read(38))
             klucz=word(4,plik)
        if klucz=='QVCS':
             struct.unpack(38*'b', plik.read(38))
             klucz=word(4,plik)
        if klucz=='CVCS':
             struct.unpack(58*'b', plik.read(58))
             klucz=word(4,plik)
        if klucz=='DMES':
             struct.unpack(168*'b', plik.read(168))
             #klucz=word(4,plik)