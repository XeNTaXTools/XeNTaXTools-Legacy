import Blender
from Blender import *
from Blender import Armature as A
from Blender.Mathutils import *
import struct,os,bpy
from math import *



from word import word



def nskinanimator(plik,noextend,scn,klasa):
    bonesname=[]
    childparent=[]
    location=[]
    rotation=[]
    scale=[]
    klucz = word(4,plik)
    if klucz=='BCLS':
         struct.unpack('H', plik.read(2))#long next bytes
         struct.unpack(6*'f', plik.read(24))#boundig box
         klucz=word(4,plik)
    if klucz=='NHCS':
         plik.read(20)
         klucz=word(4,plik)
         #print klucz
    if klucz=='MNAS':
         struct.unpack('h', plik.read(2))
         long = struct.unpack('h', plik.read(2))[0]
         print word(long,plik)
         #klucz=word(4)
    plik.read(6)
    numbones = struct.unpack('i', plik.read(4))[0]
    print 'numbones',numbones
    armOb = Blender.Object.New('Armature','armobj-'+noextend )
    armature = Blender.Armature.New('arm-'+noextend)
    armature.drawType = Blender.Armature.STICK
    armOb.link(armature)
    scn.objects.link(armOb)
    #armOb.makeParentDeform([meshOb])
    armature.makeEditable()

    for i in range(numbones):
          struct.unpack(4*'c', plik.read(4))
          struct.unpack('h', plik.read(2))
          child =  struct.unpack('i', plik.read(4))[0]
          parent = struct.unpack('i', plik.read(4))[0]
          #print child,parent
          struct.unpack(0*'f', plik.read(0*4))
          x =  struct.unpack('f', plik.read(4))[0]
          y =  struct.unpack('f', plik.read(4))[0]
          z =  struct.unpack('f', plik.read(4))[0] 
          trans=(x,-z,y)
          location.append(trans)
          rx =  struct.unpack('f', plik.read(4))[0]
          ry =  struct.unpack('f', plik.read(4))[0]
          rz =  struct.unpack('f', plik.read(4))[0]
          rw =  struct.unpack('f', plik.read(4))[0]
          quat = Quaternion(rw,rx,-rz,ry)
          rot = quat.toMatrix()
          #rot = quat.toEuler() 
          rotation.append(rot)
          sx = struct.unpack('f', plik.read(4))[0]
          sy = struct.unpack('f', plik.read(4))[0]
          sz = struct.unpack('f', plik.read(4))[0]
          scale.append([sx,sz,sy])
          long = struct.unpack('h', plik.read(2))[0]
          name = word(long,plik)
          #print name
          bonesname.append(name)
          childparent.append([child,parent])     
          obj=Object.New('Empty',str(child))
          #if parent==-1:        
          #    obj=Object.New('Empty',str(parent))
          scn.link(obj)
          #Redraw()

    for i in range(numbones): 
        nr1=childparent[i][0] 
        nr2=childparent[i][1]
        #print nr1,nr2
        if nr2!=-1:
            child= Object.Get(str(nr1))
            parent=Object.Get(str(nr2))
            parent.makeParent([child],1,0)  
            
            child.setMatrix(rotation[nr1])
            child.setLocation(location[nr1])
            child.setSize(scale[nr1])
            Window.RedrawAll()
            
        else:       
            child= Object.Get(str(nr1))
            child.setMatrix(rotation[nr1])
            child.setLocation(location[nr1])
            #Window.RedrawAll()  
     
    #bone = Blender.Armature.Editbone()
    #armature.bones[str(-1)] = bone
    
    for i in range(numbones): 
      nr1=childparent[i][0] 
      nr2=childparent[i][1]
      if nr2!=-1:
        child=Object.Get(str(nr1))
        parent=Object.Get(str(nr2))
        chm = child.getMatrix('worldspace')[3] #children matrix
        #pm = parent.getMatrix('worldspace')[3] #parent matrix      
        bone = Blender.Armature.Editbone()
        bone.head=   Vector(chm[0],chm[1],chm[2])
        #bone.tail=   Vector(chm[0],chm[1],chm[2])
        bvec = bone.tail - bone.head
        bvec.normalize()
        bone.tail = bone.head + 0.001 * bvec
        armature.bones[str(nr1)] = bone
        bone.parent = armature.bones[str(nr2)]
      else: 
           child=Object.Get(str(nr1))
           chm = child.getMatrix('worldspace')[3] #children matrix     
           bone = Blender.Armature.Editbone()
           bone.head=Vector(0,0,0)
           bone.tail=   Vector(chm[0],chm[1],chm[2])
           if bone.tail==bone.head:
                bone.head=Vector(0,1,0)
           armature.bones[str(nr1)] = bone
    armature.update()
    Redraw()
    for obj in scn.objects:
        if obj.type=='Empty':
            scn.unlink(obj)

    klucz = word(4,plik)
    if klucz=='TNJE':
                plik.read(2)
                klucz=word(4,plik)
                #print klucz
    if klucz=='LCGB':#lista animacji
                txt=Text.New('animacje')
                print'=== ANIMATIONS ==='
                struct.unpack('h', plik.read(2))
                numanim = struct.unpack('i', plik.read(4))[0]
                for anim in range(numanim):
                     klucz=word(4,plik)
                     if klucz=='LCTS':
                          #plik.read(10)
                          info = struct.unpack(5*'H', plik.read(10))
                          long = struct.unpack('h', plik.read(2))[0]
                          nameanim = word(long,plik)
                          print nameanim
                          txt.write(str(nameanim)+'\n')
                klucz=word(4,plik)
    if klucz=='LCDE':
                plik.read(2)
    if klasa=='ncharacter3skinanimator':
                klucz=word(4,plik)
                if klucz=='TRVS':
                     plik.read(2)
                     long = struct.unpack('h', plik.read(2))[0]
                     print word(long,plik)
                     klucz=word(4,plik)
                if klucz=='TVGB':
                     plik.read(6)
                     klucz=word(4,plik)
                while(klucz=='TVTS'):
                     plik.read(10) 
                     long = struct.unpack('h', plik.read(2))[0]
                     print word(long,plik)
                     klucz=word(4,plik)
                if klucz=='TVDE':
                     plik.read(2)

                      
    