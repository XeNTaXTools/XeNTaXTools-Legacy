import Blender
from Blender import *
from Blender import Armature as A
from Blender.Mathutils import *
from math import *
import struct,os,bpy
from word import word

def ncharacter3skinshapenode(plik,root,noextend,scn,txt,numer): 
        klucz = word(4,plik)
        if klucz=='RPRS':
                plik.read(6)
                klucz=word(4,plik)              
        if klucz=='BCLS':
                struct.unpack('H', plik.read(2))#long next bytes
                #print'boundig box',
                struct.unpack(6*'f', plik.read(24))#boundig box
                klucz=word(4,plik)
        while(klucz=='TXTS'):
                struct.unpack('h', plik.read(2))
                long = struct.unpack('h', plik.read(2))[0]
                typtextury = word(long,plik)
                if typtextury=='DiffMap0':
                    long = struct.unpack('h', plik.read(2))[0]
                    textura = word(long,plik)
                    texturediff = Texture.New('DIFF')
                    texturediff.type = Texture.Types.IMAGE
                    image = None
                    path=root+'textures'+os.sep+textura[9:]
                    try:
                       image = Image.Load(path)
                       print textura
                    except:
                       print 'nie wczytano',textura
                    texturediff.image = image
                elif typtextury=='BumpMap0':
                    long = struct.unpack('h', plik.read(2))[0]
                    textura = word(long,plik)
                    texturebump = Texture.New('NORM')
                    texturebump.type = Texture.Types.IMAGE
                    texturebump.setImageFlags('NormalMap') 
                    image = None
                    path=root+'textures'+os.sep+textura[9:]
                    try:
                       image = Image.Load(path)
                       print textura
                    except:
                       print 'nie wczytano',textura
                    texturebump.image = image
                elif typtextury=='SpecMap0':
                    long = struct.unpack('h', plik.read(2))[0]
                    textura = word(long,plik)
                    texturespec = Texture.New('SPEC')
                    texturespec.type = Texture.Types.IMAGE
                    image = None
                    path=root+'textures'+os.sep+textura[9:]
                    try:
                       image = Image.Load(path)
                       print textura
                    except:
                       print 'nie wczytano',textura
                    texturespec.image = image
                else:
                    long = struct.unpack('h', plik.read(2))[0]
                    textura = word(long,plik)
                klucz=word(4,plik)
                #print klucz
        while(klucz=='TLFS' or klucz=='TNIS'):
                struct.unpack('h', plik.read(2))
                long = struct.unpack('h', plik.read(2))[0]
                parametr = word(long,plik)                
                print parametr,'=',struct.unpack('f', plik.read(4))[0]
                klucz=word(4,plik)
                #print klucz
        if klucz=='NSMS':#name material
                struct.unpack('h', plik.read(2))
                long = struct.unpack('h', plik.read(2))[0]
                parametr = word(long,plik)
                print'name material:',parametr
                parametr=noextend+'-mat'+str(numer)
                if len(parametr)>20:
	                 parametr=parametr[len(parametr)-20:]    
                material = Material.New(parametr)
                txt.write(str(parametr)+'\n')
                material.setTexture(0,texturediff,Texture.TexCo.UV,Texture.MapTo.COL) 
                material.setTexture(1,texturebump,Texture.TexCo.UV,Texture.MapTo.NOR)
                material.setTexture(2,texturespec,Texture.TexCo.UV,Texture.MapTo.SPEC) 
                klucz=word(4,plik)
                #print klucz
        if klucz=='DHSS':#hair,skinned,lightmap
                struct.unpack('h', plik.read(2))
                long = struct.unpack('h', plik.read(2))[0]
                parametr = word(long,plik)
                print'material type:',parametr
                txt.write(str('material type: ')+str(parametr)+'\n')
                klucz=word(4,plik)
                #print klucz
        if klucz=='HSMS':
                struct.unpack('h', plik.read(2))
                long = struct.unpack('h', plik.read(2))[0]
                mesh = word(long,plik)
                txt.write(str(mesh)+'\n')
                print mesh
                klucz=word(4,plik)
        print klucz#IRGS
        print struct.unpack(6*'b', plik.read(6))
        klucz=word(4,plik)
        print klucz#SVNS
        print struct.unpack(3*'b', plik.read(3))
        klucz=word(4,plik)
        if klucz=='AKSS':
             print klucz#AKSS
             struct.unpack('h', plik.read(2))
             long = struct.unpack('H', plik.read(2))[0]
             print word(long,plik)
             klucz=word(4,plik)
        if klucz=='RFGB':    
             print klucz,struct.unpack('H', plik.read(2))
             numIGFS = struct.unpack('i', plik.read(4))[0]
             print 'numIGFS =',numIGFS
             klucz=word(4,plik)
             for nr in range(numIGFS):
                 print klucz,struct.unpack(6*'b', plik.read(6))
                 txt.write(str('mesh nr: ')+str(struct.unpack('i', plik.read(4))[0])+'\n')
                 klucz=word(4,plik)
                 print klucz,struct.unpack(6*'b', plik.read(6))
                 numjoints = struct.unpack('i', plik.read(4))[0]
                 print 'numvertexgroup =',numjoints
                 klucz=word(4,plik)
                 txt.write('fixvertexgroup: '+str(numjoints)+'\n')
                 while(klucz=='DIJS'):
                     struct.unpack('H', plik.read(2))[0]
                     struct.unpack(2*'i', plik.read(8))  
                     txt.write('grupy: ')                   
                     for k in range(8):
                           num = struct.unpack('i', plik.read(4))[0]
                           txt.write(str(num)+' ')
                     txt.write('\n')
                     klucz=word(4,plik)
                     #print klucz
                 struct.unpack(6*'b', plik.read(6))
                 klucz=word(4,plik)
        if klucz=='RFDE':
             #print klucz#RFDE
             struct.unpack(2*'b', plik.read(2))
        #if klucz=='TCSS':
        #     struct.unpack(38*'b', plik.read(38))
             #klucz=word(4,plik)
        #print fixnumarray