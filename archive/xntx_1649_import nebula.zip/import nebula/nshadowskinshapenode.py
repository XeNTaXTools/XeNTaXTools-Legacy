import Blender
from Blender import *
from Blender import Armature as A
from Blender.Mathutils import *
from math import *
import struct,os,bpy
from word import word

def nschadowskinshapenode(plik):
        klucz = word(4,plik)
        if klucz=='BCLS':
                plik.read(26)
                klucz=word(4,plik)
                print klucz
        if klucz=='MHSS':
                struct.unpack('h', plik.read(2))
                long = struct.unpack('h', plik.read(2))[0]
                mesh = word(long,plik)
                print mesh
                klucz=word(4,plik)
        if klucz=='AKSS':
                struct.unpack(28*'b', plik.read(28))
                #long = struct.unpack('h', plik.read(2))[0]
                #mesh = word(long)
                #print mesh
                #klucz=word(4)
# podklasy dla ntransform
def model(plik):
        klucz = word(4,plik)
        #if klucz=='BCLS':
        #        plik.read(26)
        #        klucz=word(4,plik)
        #        print klucz
        if klucz=='PTRS':
                struct.unpack(14*'b', plik.read(14))
                klucz=word(4,plik)
                print klucz
        if klucz=='PCSS':
                struct.unpack(14*'b', plik.read(14))
                #klucz=word(4,plik)
                #print klucz
#def shadowskin(plik):
	