import Blender
from Blender import *
from Blender import Armature as A
from Blender.Mathutils import *
import struct,os,bpy
from word import *



def importnvx2(root,nvx2name,noextend,material,vertexgrupy):
   filename = root+'meshes'+os.sep+nvx2name
   plik = open(filename, 'rb')
   file=Blender.sys.basename(filename)
   print
   print'================  ',file
   print
   numfacesperobjs=[]
   numvertexperobjs=[]
   print  word(4,plik)
   numobjects = struct.unpack('i', plik.read(4))[0]
   print 'numobjects =',numobjects
   numvertex =  struct.unpack('i', plik.read(4))[0]
   print 'vertex =',numvertex
   type = struct.unpack('i', plik.read(4))[0]
   print 'type =',type
   numfaces = struct.unpack('i', plik.read(4))[0]
   print 'numfaces',numfaces
   print  struct.unpack('h', plik.read(2))
   print  struct.unpack(6*'b', plik.read(6*1))
   print 'tu czytam vertexy'
   for i in range(numobjects):
       print '== object',i,' =='
       struct.unpack('i', plik.read(4))[0]# num total vertex
       numvertexperobj = struct.unpack('i', plik.read(4))[0]
       print'numvertexperobj',numvertexperobj
       numvertexperobjs.append(numvertexperobj)
       struct.unpack('i', plik.read(4))[0]
       numfacesperobj = struct.unpack('i', plik.read(4))[0]
       numfacesperobjs.append(numfacesperobj)# numfaces of 2 object
       print 'numfacesperobj',numfacesperobj
       struct.unpack('i', plik.read(4))[0]
       struct.unpack('i', plik.read(4))[0]
   vertexytotal=[]
   uvcoordtotal=[]
   para=[]
   for i in range(numvertex): 
        #print i
        #for j in range(numvertexperobjs[i]):
        vertx=struct.unpack('f', plik.read(4))[0]
        verty=struct.unpack('f', plik.read(4))[0]
        vertz=struct.unpack('f', plik.read(4))[0]
        vertexytotal.append([vertx,-vertz,verty])
        #print vertx,verty,vertz
        struct.unpack(4*'b', plik.read(4*1))
        u = (struct.unpack('h', plik.read(2))[0]*2**-12)/2
        v = (struct.unpack('h', plik.read(2))[0]*2**-12)/2
        uvcoordtotal.append([u,1-v])
        #print u,v
        if type == 9:
            struct.unpack(4*'h', plik.read(4*2))
        if type == 10:
            struct.unpack(6*'h', plik.read(6*2))
        w1 =  struct.unpack('B', plik.read(1))[0]#skin weights normalized
        w2 =  struct.unpack('B', plik.read(1))[0]#skin weights normalized
        w3 =  struct.unpack('B', plik.read(1))[0]#skin weights normalized
        w4 =  struct.unpack('B', plik.read(1))[0]#skin weights normalized
        #print w1,w2,w3,w4
        weights = Vector(w1,w2,w3,w4)/DotVecs(Vector(w1,w2,w3,w4),Vector(1.0, 1.0, 1.0, 1.0))
        #print weights[0],weights[1],weights[2],weights[3]
        for j in range(4):
            para.append([struct.unpack('B', plik.read(1))[0],weights[j]])  
   
   for i in range(numobjects):   
      mesh = bpy.data.meshes.new(noextend+str(i))
      mesh.vertexUV = True 
      vertexylocal=[]
      uvcoordlocal=[]
      facy=[]
      for j in range(numfacesperobjs[i]):
           f1=struct.unpack('h', plik.read(2))[0]
           f2=struct.unpack('h', plik.read(2))[0]
           f3=struct.unpack('h', plik.read(2))[0]
           facy.append([f1,f2,f3])
           #print f1,f2,f3
      mesh.verts.extend(vertexytotal)
      mesh.faces.extend(facy,ignoreDups=True)
      #mesh.update()
      for faceID in range(0,len(mesh.faces)):
            face = mesh.faces[faceID]
            index1 = facy[faceID][0]
            index2 = facy[faceID][1]
            index3 = facy[faceID][2]
            uv1 = Vector(uvcoordtotal[index1])
            uv2 = Vector(uvcoordtotal[index2])
            uv3 = Vector(uvcoordtotal[index3])
            face.uv = [uv1, uv2, uv3]
            face.smooth=True
            face.sel=0
      for k in material:
           if k[0]==i:
                name=k[1]
      mesh.materials += [Material.Get(str(name))] 
      scene = bpy.data.scenes.active
      scene.objects.new(mesh,noextend+str(i))
      numgr=[]
      for k in range(numvertex):
           for j in range(4):
               nr = para[k*4+j][0]
               w  = para[k*4+j][1]
               if str(nr) not in mesh.getVertGroupNames():                    
                       mesh.addVertGroup(str(nr))
                       numgr.append(nr)             
               mesh.assignVertsToGroup(str(nr),[k],w,1)
      id=0
      for gr in vertexgrupy[noextend+str(i)]:
            try:
                mesh.renameVertGroup(str(id),str(gr)+'a')
                mesh.update()
            except:
                pass 
            id+=1
      for grname in mesh.getVertGroupNames():
         if 'a' not in grname:
            mesh.removeVertGroup(grname) 
            mesh.update() 
            
      for grname in mesh.getVertGroupNames():
            mesh.renameVertGroup(grname,grname[:-1])
            mesh.update() 
            
      #print numgr 
      mesh.update()
      Blender.Redraw()
   
   for i in range(numobjects):
      Blender.Window.EditMode(0) 
      obj=Object.Get(noextend+str(i))
      objdata=obj.getData(mesh=1)
      selverts=objdata.verts.selected()
      objdata.verts.delete(selverts)
      Blender.Window.EditMode(1)
      #armOb = Object.Get('armobj-'+noextend)       
      #armOb.makeParentDeform([obj],1,0)
      Blender.Redraw()
      
   Redraw() 