import struct,os,bpy


def word(long,plik): 
   s=''
   for j in range(0,long):  
       s+=struct.unpack('c',plik.read(1))[0]
   return s