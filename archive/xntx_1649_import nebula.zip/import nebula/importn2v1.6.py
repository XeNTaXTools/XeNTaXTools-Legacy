import Blender
from Blender import *
from Blender import Armature as A
from Blender.Mathutils import *
from math import *
import struct,os,bpy
from nskinanimator import nskinanimator
from nskinshapenode import nskinshapenode
from nshadowskinshapenode import *
from word import word
from nparticleskinshapenode import *
from nshapenode import *
from ncharacter3skinshapenode import *
from importnvx2 import *


klucze=['BCLS','PTRS','PCSS','MHSS',\
         'AKSS','les_','wen_','BCLS',\
         'NHCS','MNAS','TNJE','LCGB',\
         'LCTS','LCDE','TRVS','TVGB',\
         'TVTS','TVDE','BCLS','TXTS',\
         'TLFS','NSMS','DHSS','HSMS',\
         'IRGS','SVNS','RVGB','IGFS',\
         'PJGB','DIJS','RFDE','PJDE',\
         'AKSS','AVCS','BVCS','DVCS',\
         'EVCS','FVCS','HVCS','JVCS',\
         'MVCS','LVCS','MMTS','NVCS',\
         'QVCS','CVCS','ATSS']

def Main():
    Window.FileSelector(Import, 'import nebula2', '*.n2')
    return

def Import(filename):
    global plik,noextend,scn,klucz,root,fixnumarray
    plik = open(filename, 'rb')
    file    = Blender.sys.basename(filename)
    #root = Blender.sys.dirname(filename)
    root="c:/Program Files/Drakensang/pack.npk"+os.sep
    
    print
    print'================  ',file
    print
    noextend = file[:file.lower().find('.')]
    if len(noextend)>20:
        noextend='model'
    materialen=[]
    scn = Blender.Scene.GetCurrent()     
    plik.seek(0, os.SEEK_END)
    fileSize = plik.tell()
    print 'rozmiar pliku:',fileSize,'bytes'
    plik.seek(0, os.SEEK_SET)
    where = plik.tell()
    plik.read(54)
    try:
       txt=Text.Get(noextend)
    except:
       txt=Text.New(noextend)
       numer=0    
       while(where<fileSize):
            klucz=word(4,plik)
            if klucz not in klucze:             
                  print klucz,plik.tell()
                  break
            if klucz=='BCLS':
                struct.unpack('H', plik.read(2))#long next bytes
                struct.unpack(6*'f', plik.read(24))#boundig box
            if klucz=='PTRS':
                struct.unpack(14*'b', plik.read(14))
            if klucz=='PCSS':
                struct.unpack(14*'b', plik.read(14))
            if klucz=='MHSS':
                struct.unpack('h', plik.read(2))
                long = struct.unpack('h', plik.read(2))[0]
                mesh = word(long,plik)
                print mesh                
            if klucz=='AKSS':
                struct.unpack('h', plik.read(2))
                long = struct.unpack('h', plik.read(2))[0]
                word(long,plik)
            if klucz=='ATSS':
                struct.unpack('h', plik.read(2))
                long = struct.unpack('h', plik.read(2))[0]
                print word(long,plik)
                long = struct.unpack('h', plik.read(2))[0]
                print word(long,plik)
            if klucz=='les_':
                struct.unpack('bbbb', plik.read(4))
                #txt.write(str('}')+'\n')
            if klucz=='wen_':
                long = struct.unpack('H', plik.read(2))[0]
                klasa = word(long,plik)
                #txt.write(str('{')+'\n')
                #print klasa
                
                if klasa=='ntransformnode':
                     long = struct.unpack('H', plik.read(2))[0]                     
                     podklasa = word(long,plik)
                     print klasa,podklasa
                     if podklasa!='model'and podklasa!='shadowskin':
                          txt.write(str('model: ')+str(podklasa)+'\n')
                     #else:
                     #     txt.write(str('model: ')+str(noextend)+'\n') 
                if klasa=='nskinanimator':
                     long = struct.unpack('H', plik.read(2))[0]
                     grupa = word(long,plik) 
                     print klasa,grupa
                     #txt.write(str(klasa)+str(' ')+str(grupa)+'\n')
                     nskinanimator(plik,noextend,scn,klasa)
                if klasa=='nskinshapenode':
                     long = struct.unpack('H', plik.read(2))[0]
                     grupa = word(long,plik)
                     print klasa,grupa 
                     txt.write(str('name material: '))
                     print'===nskinshapenode.py'
                     nskinshapenode(plik,root,noextend,scn,txt,numer)
                     numer+=1
                if klasa=='ncharacter3node':
                     long = struct.unpack('H', plik.read(2))[0]
                     podklasa = word(long,plik) 
                     print klasa,podklasa 
                     txt.write(str('grupa: ')+str(podklasa)+'\n')
                if klasa=='ncharacter3skinanimator':
                     long = struct.unpack('H', plik.read(2))[0]
                     podklasa = word(long,plik) 
                     print klasa,podklasa
                     #txt.write(str(klasa)+str(' ')+str(podklasa)+'\n')
                     nskinanimator(plik,noextend,scn,klasa)
                     #break
                if klasa=='nshadowskinshapenode':
                     long = struct.unpack('H', plik.read(2))[0]
                     grupa = word(long,plik)
                     print klasa,grupa 
                     #txt.write(str(klasa)+str(' ')+str(grupa)+'\n')
                if klasa=='ncharacter3skinshapenode':
                     long = struct.unpack('H', plik.read(2))[0]
                     grupa = word(long,plik)
                     print klasa,grupa
                     txt.write(str('name material: '))
                     print'===ncharacter3skinshapenode.py' 
                     ncharacter3skinshapenode(plik,root,noextend,scn,txt,numer)
                     numer+=1
                     #break
                if klasa=='nparticleskinshapenode2':
                     long = struct.unpack('H', plik.read(2))[0]
                     grupa = word(long,plik)
                     print klasa,grupa         
                     txt.write(str('name material: '))
                     print'===nparticleskinshapenode2.py' 
                     #txt.write(str(klasa)+str(' ')+str(grupa))
                     nparticleskinshapenode(plik,root,noextend,scn,txt,numer) 
                     numer+=1
                if klasa=='nshapenode':
                     long = struct.unpack('H', plik.read(2))[0]
                     grupa = word(long,plik)
                     print klasa,grupa
                     txt.write(str(klasa)+str(' ')+str(grupa)+'\n')
                     print'===nshapenode.py' 
                     nshapenode(plik,root,noextend,scn,txt,numer)
                     numer+=1
                     
                                   
            where = plik.tell()
    if where>=fileSize:
        print '===================== czysto'
    #txt.close()
    models=[]
    meshes=[]
    materialen={}
    lines=txt.asLines() 
    for i in range(len(lines)):
       #print lines[i]
       if 'grupa' not in lines[0]:
             if 'meshes' in lines[i]:
                  mesh=lines[i][lines[i].lower().find(':')+1:]
                  if mesh not in meshes:
                         meshes.append(mesh) 
                         models.append(noextend)
       if 'grupa'  in lines[0]:
             if 'meshes' in lines[i]:
                  mesh=lines[i][lines[i].lower().find(':')+1:] 
                  if mesh not in meshes:
                         meshes.append(mesh) 
             if 'model' in lines[i]:
                  model=lines[i][lines[i].lower().find(':')+1:]
                  if model not in models:
                         models.append(model)
    
    materialen[noextend] = []
    vertexgrupy={}
    vertexgrupy[noextend]=[]
    for i in range(len(lines)):
       line=lines[i]
       if 'grupa' not in lines[0]:
             if 'name material' in line:
                  namematerial = line[line.lower().find(':')+2:]
                  #print namematerial
             if 'mesh nr:' in line:
                  nr=int(line[line.lower().find(':')+2:])
                  materialen[noextend].append([nr,namematerial])
                  vertexgrupy[noextend+str(nr)]=[]
             if 'fixvertexgroup' in line:
                  numgrs = int(line.split(' ')[1])
                  m=0            
             if 'grupy:' in line:
                  nrgr = line.split(' ') 
                  for j in range(8):
                       if m<numgrs:
                            if int(nrgr[j+1]) not in vertexgrupy[noextend+str(nr)]:
                                vertexgrupy[noextend+str(nr)].append(int(nrgr[j+1]))
                                m+=1                 
                            if int(nrgr[j+1]) not in vertexgrupy[noextend]:
                                vertexgrupy[noextend].append(int(nrgr[j+1]))
       if 'grupa'  in lines[0]:
             if 'model' in line:
                  model=line[line.lower().find(':')+1:]
                  materialen[model] = []
             if 'name material' in line:
                  namematerial = line[line.lower().find(':')+2:]
                  #print namematerial
             if 'mesh nr:' in line:
                  nr=int(line[line.lower().find(':')+2:])
                  materialen[model].append([nr,namematerial])
             if 'fixvertexgroup' in line:
                  nrgrs = int(line.split(' ')[1])
                  vertexgrupy[model]=[]
                  m=0              
             if 'grupy:' in line:
                  nrgr = line.split(' ') 
                  for j in range(8):
                       if m<nrgrs:
                             vertexgrupy[model].append(int(nrgr[j+1]))
                             m+=1
                 
                  
    print 'vertexgrupy',vertexgrupy
                        
    #print meshes 
    action={}
    draw={}
    block=[]
    if 0<len(meshes)<120:
        for nraction in range(len(meshes)):
            action[str(nraction)]=False
            draw[str(nraction)] = Draw.Create(action[str(nraction)])
            block.append((models[nraction],draw[str(nraction)]))
        Draw.PupBlock("meshes",block)
        for act in action:
            action[act] = draw[act].val
            if action[act]==True:
                  print 'wybrano model: ',models[int(act)]
                  print 'wczytuje mesh: ',meshes[int(act)]
                  nvx2name=meshes[int(act)]
                  importnvx2(root,nvx2name,noextend,\
                         materialen[models[int(act)]],\
                         vertexgrupy)
                  """
                  arm = Armature.Get('arm-'+noextend) 
                  arm.makeEditable()   
                  for bone in arm.bones.values():
                         oldname = bone.name 
                         #print oldname 
                         try:                       
                            newname = str(vertexgrupy[noextend].index(int(oldname)))+'a'
                            #bone.name = newname
                         except:
                            #print 'jakas kosc',oldname
                            pass   
                            """
            else:
	            pass   
        #arm.update()
    if 0<len(meshes)>=120:
        for nraction in range(120):
            action[str(nraction)]=False
            draw[str(nraction)] = Draw.Create(action[str(nraction)])
            block.append((models[nraction],draw[str(nraction)]))
        Draw.PupBlock("meshes",block)
        for act in action:
            action[act] = draw[act].val
            if action[act]==True:
                  print 'wybrano model: ',models[int(act)]
                  print 'wczytuje mesh: ',meshes[int(act)]
                  nvx2name=meshes[int(act)]
                  importnvx2(root,nvx2name,noextend,\
                         materialen[models[int(act)]],\
                         vertexgrupy[models[int(act)]]) 
    """
    arm = Armature.Get('arm-'+noextend) 
    arm.makeEditable()   
    for bone in arm.bones.values():
          if 'a' in bone.name:
              oldname = bone.name
              bone.name = oldname[:-1]
          else:
              oldname = bone.name
              bone.name = oldname+'b'  
    arm.update()  
    """               
Main()