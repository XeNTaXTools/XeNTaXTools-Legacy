// DecPCAWE.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "WaveWriter.h"

static const unsigned IMA_StepTable[89] = 
{
    7, 8, 9, 10, 11, 12, 13, 14,
    16, 17, 19, 21, 23, 25, 28, 31,
    34, 37, 41, 45, 50, 55, 60, 66,
    73, 80, 88, 97, 107, 118, 130, 143,
    157, 173, 190, 209, 230, 253, 279, 307,
    337, 371, 408, 449, 494, 544, 598, 658,
    724, 796, 876, 963, 1060, 1166, 1282, 1411,
    1552, 1707, 1878, 2066, 2272, 2499, 2749, 3024,
    3327, 3660, 4026, 4428, 4871, 5358, 5894, 6484,
    7132, 7845, 8630, 9493, 10442, 11487, 12635, 13899,
    15289, 16818, 18500, 20350, 22385, 24623, 27086, 29794,
    32767
};

static const int IMA_IndexTable[16] = 
{
    -1, -1, -1, -1, 2, 4, 6, 8,
    -1, -1, -1, -1, 2, 4, 6, 8 
};

static inline void clamp_step_index(int* stepIndex)
{
    if (*stepIndex < 0 ) *stepIndex = 0;
    if (*stepIndex > 88) *stepIndex = 88;
}

static inline void clamp_sample(int* sample)
{
    if (*sample < -32768) *sample = -32768;
    if (*sample >  32767) *sample =  32767;
}

static inline void process_nibble(unsigned char code, int* stepIndex, int* sample)
{
    unsigned step;
    int diff;
    
    code &= 0x0F;
    
    step = IMA_StepTable[*stepIndex];
    diff = step >> 3;
    if (code & 1) diff += step >> 2;
    if (code & 2) diff += step >> 1;
    if (code & 4) diff += step;
    if (code & 8)	*sample -= diff;
    else 		*sample += diff;
    clamp_sample(sample);
    *stepIndex += IMA_IndexTable[code];
    clamp_step_index(stepIndex);
}

// The arguments sent to the application
struct SArguments
{
	SArguments() :
		ShowBanner(true),
		ShowUsage(false),
		InputFilename(""),
		OutputFilename(""),
		OuputWaveFile(true),
		OutputSampleRate(22050),
		Channels(1)
	{
	};

	bool ShowBanner;
	bool ShowUsage;
	std::string InputFilename;
	std::string OutputFilename;
	bool OuputWaveFile;
	unsigned long OutputSampleRate;
	unsigned char Channels;
};

// Parse the arguments sent to the program
bool ParseArguments(SArguments& Args, unsigned long Argc, _TCHAR* Argv[])
{
	// Go through each of the arguments sent
	for(unsigned long i=1;i<Argc;)
	{
		std::string Arg(Argv[i++]);
		
		// Check it
		if(Arg=="-b" || Arg=="--no-banner")
		{
			Args.ShowBanner=false;
		}
		else if(Arg=="-o" || Arg=="--output")
		{
			if(i>=Argc)
			{
				return false;
			}
			Args.OutputFilename=std::string(Argv[i++]);
		}
		else if(Arg=="-w" || Arg=="--wave")
		{
			Args.OuputWaveFile=true;
		}
		else if(Arg=="-r" || Arg=="--raw")
		{
			Args.OuputWaveFile=false;
		}
		else if(Arg=="--sample-rate")
		{
			if(i>=Argc)
			{
				return false;
			}
			Args.OutputSampleRate=atoi(Argv[i++]);
		}
		else if(Arg=="-c" || Arg=="--channels")
		{
			if(i>=Argc)
			{
				return false;
			}
			Args.Channels=atoi(Argv[i++]);
		}
		else
		{
			Args.InputFilename=Arg;
		}
	}
	return true;
}

int _tmain(int Argc, _TCHAR* Argv[])
{
	// Parse the arguments
	SArguments Args;
	if(Argc==1)
	{
		Args.ShowUsage=true;
	}
	bool ArgParse=ParseArguments(Args, Argc, Argv);

	// Display banner
	if(Args.ShowBanner)
	{
		std::cerr << "Decode Audio from Pirates of the Caribbean at World's End" << std::endl << std::endl;
	}

	// Display usage
	if(Args.ShowUsage)
	{
		std::cout << "Usage: DecPCAWE InputFilename [Options]" << std::endl;
		std::cout << std::endl;
		std::cout << "  -o, --output File     Specify the output filename" << std::endl;
		std::cout << "  -w, --wave            Output a standard wave file (.wav)" << std::endl;
		std::cout << "  -r, --raw             Output raw data (no header)" << std::endl;
		std::cout << "  -c, --channels Num    Specify the number of channels" << std::endl;
		std::cout << "  --sample-rate Rate    Specify the sampling rate" << std::endl;
		std::cout << std::endl;
	}

	// Check for errors
	if(!ArgParse)
	{
		std::cerr << "The arguments are not valid." << std::endl;
		return 1;
	}
	if(Args.InputFilename.empty())
	{
		std::cerr << "You need to enter an input filename." << std::endl;
		return 1;
	}
	if(Args.OutputFilename.empty())
	{
		std::cerr << "You need to enter an output filename." << std::endl;
		return 1;
	}

	// Load the input file
	std::ifstream Input;
	Input.open(Args.InputFilename.c_str(), std::ios_base::in | std::ios_base::binary);
	if(!Input.is_open())
	{
		std::cerr << "Could not open input file \"" << Args.InputFilename << "\"." << std::endl;
		return 1;
	}

	// Load the output file
	std::ofstream Output;
	Output.open(Args.OutputFilename.c_str(), std::ios_base::out | std::ios_base::binary | std::ios_base::trunc);
	if(!Output.is_open())
	{
		std::cerr << "Could not open output file \"" << Args.OutputFilename << "\"." << std::endl;
		Input.close();
		return 1;
	}

	// Prepare the wave header
	unsigned long NumberSamples=0;
	if(Args.OuputWaveFile)
	{
		PrepareWaveHeader(Output);
	}

	// Loop through the data
	unsigned char Channels=Args.Channels;
	const char InBlockSize=28;
	const char OutBlockSize=InBlockSize*2;
	unsigned char* InputBuffer=new unsigned char[InBlockSize];
	short* OutputBuffer=new short[OutBlockSize*Channels];

	Input.seekg(0x0800);
	while(!Input.eof())
	{
		bool Done=true;
		for(unsigned long i=0;i<Channels;i++)
		{
			short TheLastSample;
			unsigned char TheLastIndex;
			unsigned char Extra;

			Input.read((char*)&TheLastSample, 2);
			Input.read((char*)&TheLastIndex, 1);
			Input.read((char*)&Extra, 1);

			if(TheLastSample==0xABAB && TheLastIndex==0xAB && Extra==0xAB)
			{
				Done=true;
				break;
			}

			Input.read((char*)InputBuffer, InBlockSize);
			if(i==0)
			{
				//Output.write((char*)InputBuffer, InBlockSize);
			}

			int LastSample=TheLastSample;
			int LastIndex=TheLastIndex;
	
			for(unsigned long j=0;j<InBlockSize;j++)
			{
				unsigned char Char;
				unsigned char Code;
				
				// Get the char
				Char=InputBuffer[j];
				Code=Char >> 4;
				process_nibble(Code, &LastIndex, &LastSample);
				OutputBuffer[i+Channels*(j*2)]=(short)LastSample;
				
				Code=Char & 0x0F;
				process_nibble(Code, &LastIndex, &LastSample);
				OutputBuffer[i+Channels*(j*2+1)]=(short)LastSample;
			}
		}

		Output.write((char*)OutputBuffer, OutBlockSize*Channels*2);
		NumberSamples+=Channels*OutBlockSize;
		// TODO: Write buffer
	}

	// Write the wave header
	if(Args.OuputWaveFile)
	{
		Output.seekp(0);
		WriteWaveHeader(Output, Args.OutputSampleRate, 16, Channels, NumberSamples);
	}

	// Free
	delete[] InputBuffer;
	delete[] OutputBuffer;
	Input.close();
	Output.close();
	return 0;
}

