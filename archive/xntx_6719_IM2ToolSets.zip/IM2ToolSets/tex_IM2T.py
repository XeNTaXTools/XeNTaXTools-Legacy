from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Iron Man II Textures", ".IM2T")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
	#noesis.logPopup()
	return 1

#check if it's this type based on the data
def noepyCheckType(data):
	bs = NoeBitStream(data)
	Magic = bs.readBytes(4)
	if Magic != b'\x49\x4D\x32\x54':
		return 0
	return 1
	
def noepyLoadRGBA(data, texList):
	datasize = len(data) - 0x20
	bs = NoeBitStream(data, NOE_BIGENDIAN)
	bs.seek(0x4, NOESEEK_ABS)
	Platform = bs.readUInt()
	MapType = bs.readUInt()
	imgWidth = bs.readUInt()
	imgHeight = bs.readUInt()
	MipmapNum = bs.readUInt()
	bs.seek(0x20, NOESEEK_ABS)
	data = bs.readBytes(datasize)
	if Platform == 0:	# PS3
		if MapType == 0:
			texFmt = noesis.NOESISTEX_DXT1
		elif MapType == 3:
			texFmt = noesis.NOESISTEX_DXT5
		elif MapType == 6:
			data = rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_DXT5)
			data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "p8 b8 r8 g8")
			texFmt = noesis.NOESISTEX_RGBA32
		elif MapType == 8:
			imgWidth //= 2
			imgHeight //= 2
			untwid = bytearray()
			for x in range(imgWidth):
				for y in range(imgHeight):
					idx = noesis.morton2D(x, y)
					untwid += data[idx * 4:idx * 4 + 4]
			data = rapi.imageDecodeRaw(untwid, imgWidth, imgHeight, "r8 g8 b8 p8")
			texFmt = noesis.NOESISTEX_RGBA32
		else:
			noesis.logPopup()
			print("Unknown error!")
			return 0
	elif Platform == 1:		# Xbox 360
		if MapType == 0:	# DXT1
			texFmt = noesis.NOESISTEX_DXT1
			data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 8)
		elif MapType == 3:	# DXT5
			texFmt = noesis.NOESISTEX_DXT5
			data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 16)
		elif MapType == 4:	# ATI1
			data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 8)
			data = rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_ATI1)
			texFmt = noesis.NOESISTEX_RGBA32
		elif MapType == 6:	# ATI2
			data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 16)
			data = rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_ATI2)
			texFmt = noesis.NOESISTEX_RGBA32
		else:
			noesis.logPopup()
			print("Unknown error! Did you mistake your game version?")
			return 0
	else:
		noesis.logPopup()
		print("Unknown error!")
		return 0
	texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
	return 1