#by Durik256 for xentax.com 02.02.2022 (ogre?)
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Tân Thiên Long 3D", ".skeleton")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)
    noesis.logPopup()
    return 1

offset_skeleton = -1
def noepyCheckType(data):
    global offset_skeleton
    offset_skeleton = data.find('[Serializer_v1.10]'.encode())
    if offset_skeleton == -1:
        return 0
    return 1

def noepyLoadModel(data, mdlList):
    bs = NoeBitStream(data)
    bs.seek(offset_skeleton+19, NOESEEK_ABS)
    
    file_size = bs.getSize()
    
    bones = []
    while bs.getOffset() < file_size:
        if bs.readShort() == 8192:
            bs.seek(4, NOESEEK_REL)
            name_bone = str(len(bones))+"_"+readString(bs)
            id_bone = bs.readUByte()
            bs.seek(1, NOESEEK_REL)
            pos = NoeVec3.fromBytes(bs.readBytes(12))
            mat = NoeQuat.fromBytes(bs.readBytes(16)).toMat43().transpose()
            mat[3] = pos
            bones.append(NoeBone(id_bone,name_bone,mat))
        else:
            bs.seek(-2, NOESEEK_REL)
            break

    for x in range(len(bones)-1):
        bs.readShort()#[00 30]
        bs.readInt()#[A0 00 00 00]
        bone_index = bs.readUShort()
        parent_index = bs.readUShort()
        bones[bone_index].parentIndex = parent_index
    
    for bone in bones:
        pIndex = bone.parentIndex
        if pIndex != -1:
            bone.setMatrix(bone.getMatrix() * bones[pIndex].getMatrix())
    
    mdl = NoeModel()
    mdl.setBones(bones)
    mdlList.append(mdl)
    return 1
 
def readString(bs):
    bytes = []
    for x in range(50):#max length string
        byte = bs.readUByte()
        if byte != 10:
            bytes.append(byte)
        else:
            break
    return noeAsciiFromBytes(bytes)
