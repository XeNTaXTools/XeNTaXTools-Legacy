from inc_noesis import *
import os

def registerNoesisTypes():
	handle = noesis.register("Alone in the dark (PC)", ".xmt")
	noesis.setHandlerTypeCheck(handle, AITDCheckType)
	noesis.setHandlerLoadRGBA(handle, AITDLoadRGBA)
	#noesis.logPopup()
	return 1

#check if it's this type based on the data
def AITDCheckType(data):
	bs = NoeBitStream(data)
	bs.seek(0x200, NOESEEK_ABS)
	Magic = bs.readBytes(4)
	print(Magic, "Magic")
	if Magic != b'\x54\x45\x58\x54':
		return 0
	return 1
	
def AITDLoadRGBA(data, texList):
	dataSize = len(data) - 0x1000
	bs = NoeBitStream(data)
	bs.seek(0x20c, NOESEEK_ABS)
	imgWidth = bs.readUInt()            
	print(imgWidth, "imgWidth")
	imgHeight = bs.readUInt()           
	print(imgHeight, "imgHeight")
	bs.seek(0x21c, NOESEEK_ABS)
	imgFmt = bs.readInt()
	print(imgFmt, "imgFmt")
	bs.seek(0x1000, NOESEEK_ABS)        
	data = bs.readBytes(dataSize)      
	#DXT1
	if imgFmt == 0x0B or imgFmt == 0x27:
		texFmt = noesis.NOESISTEX_DXT1
	#DXT5
	elif imgFmt == 0x0F:
		texFmt = noesis.NOESISTEX_DXT5
	#unknown, not handled
	else:
		print("Error: Unsupported image format")
		return None
	texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
	return 1