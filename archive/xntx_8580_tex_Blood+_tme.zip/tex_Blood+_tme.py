# Blood+ tme loader by BloodRaynare
# VERY WIP! Only supports 8-bit TMEs ATM and palettes might be incorrect for some files

from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Blood+ TME image file", ".tme")
	noesis.setHandlerTypeCheck(handle, tmeCheckType)
	noesis.setHandlerLoadRGBA(handle, tmeLoadImage)
	# noesis.logPopup()
	return 1

def tmeCheckType(data):
	bs = NoeBitStream(data)
	Magic = bs.readUInt()
	if Magic != 0x2000104c:
		return 0
	return 1

def tmeLoadImage(data, texList):
	bs = NoeBitStream(data)
	bs.seek(0x0a, NOESEEK_ABS)
	CSMFlags = bs.readByte()
	bs.seek(0x40, NOESEEK_ABS)
	imgWidth = bs.readUInt()
	imgHeight = bs.readUInt()
	bitPerPixel = 8
	bytePerPixel = 4
	pixelSize = imgWidth*imgHeight
	bs.seek(0x70, NOESEEK_ABS)
	pixelData = bs.readBytes(pixelSize)
	paletteSize = 0x400
	palOff = 0x70+pixelSize+0x60
	bs.seek(palOff, NOESEEK_ABS)
	paletteData = bs.readBytes(paletteSize)
	if CSMFlags == 0x08:
		pixelData = rapi.imageDecodeRawPal(pixelData, paletteData, imgWidth, imgHeight, bitPerPixel, "r8 g8 b8 a8", noesis.DECODEFLAG_PS2SHIFT)
	else:
		pixelData = rapi.imageDecodeRawPal(pixelData, paletteData, imgWidth, imgHeight, bitPerPixel, "r8 g8 b8 a8")
	texFmt = noesis.NOESISTEX_RGBA32
	texList.append(NoeTexture("tmetex", imgWidth, imgHeight, pixelData, texFmt))
	return 1
