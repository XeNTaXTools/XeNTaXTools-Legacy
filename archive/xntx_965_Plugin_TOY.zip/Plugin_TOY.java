import org.watto.Language;
import org.watto.component.WSProgressDialog;
import org.watto.manipulator.FileManipulator;
import java.io.File;

public class Plugin_TOY extends ArchivePlugin {
	public Plugin_TOY() {
		super("TOY","TOY");
		
		setProperties(true, false, false, false);
		setGames("Souptoys");
		setExtensions("toy");
		setPlatforms("PC");
	}
	
	public int getMatchRating(FileManipulator fm) {
		try {
			int rating = 0;
			
			if(fm.getExtension().equals(getExtensions()[0])) {
				rating += 25;
			}
			
			// Skip the header
			fm.seek(76);
			
			// Check the signature
			if(fm.readString(23).equals("SOUPTOYS.COM TOY FORMAT")) {
				rating += 50;
			}
			
			System.out.println("The rating: " + rating);

			return rating;
		}
		catch (Throwable t){
			System.out.println(t);
			return 0;
		}
	}
	
	public Resource[] read(File path) {
		try {
			// Get things ready
			addFileTypes();
			FileManipulator fm = new FileManipulator(path, "r");
			
			// Find location of the end header and go there
			long endHeaderOffsetOffset = fm.getLength() - 4;
			fm.seek(endHeaderOffsetOffset);
			
			// 4 - The location of the end header (two assignments separate for clarity)
			long endHeaderOffset = fm.readIntL();
			endHeaderOffset += 76;
			endHeaderOffset -= 4;
			fm.seek(endHeaderOffset);
			
			// 4 - The location of the file table
			long fileTableOffset = fm.readIntL();
			fileTableOffset += 76;
			fm.seek(fileTableOffset);
			
			// 4 - The number of files
			int numFiles = fm.readIntL();
			Resource[] resources = new Resource[numFiles];
			WSProgressDialog.setMaximum(numFiles);
			
			// Read the file table
			for(int i=0;i<numFiles;i++) {
				// 4 - Filename length
				int filenameLength = fm.readIntL();
				
				// x - Filename
				String filename = fm.readString(filenameLength);
				
				// 4 - Offset
				long offset = fm.readIntL();
				offset += 76;
				
				// 4 - Extension length
				int extLength = fm.readIntL();
				
				// x - Extension
				String extension = fm.readString(extLength);
				
				// 4 - Length
				long length = fm.readIntL();
				
				// Add the resource
				resources[i] = new Resource(path, filename, offset, length);
				
				WSProgressDialog.setValue(i);
			}
			
			fm.close();
			return resources;
		}
		catch (Throwable t) {
			logError(t);
			return null;
		}
	}
}
