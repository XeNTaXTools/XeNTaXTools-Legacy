# by Durik for xentax.com 
from inc_noesis import *

def registerNoesisTypes():
   handle = noesis.register("Front Mission", ".cl5")
   noesis.setHandlerTypeCheck(handle, CheckType)
   noesis.setHandlerLoadModel(handle, LoadModel)
   return 1

def CheckType(data):
    return 1       

def LoadModel(data, mdlList):
    bs = NoeBitStream(data)
    bs.seek(896)#vert_offset
    vbuf = bs.readBytes(30*8)#30 - vert_count, 8 - stride
    
    bs.seek(168)#indices_offset
    ibuf = read_ibuf(bs, 14)#14 - face_count
    
    ctx = rapi.rpgCreateContext()
                
    rapi.rpgBindPositionBuffer(vbuf, noesis.RPGEODATA_SHORT, 8)
    rapi.rpgCommitTriangles(ibuf, noesis.RPGEODATA_SHORT, len(ibuf)//2, noesis.RPGEO_TRIANGLE)
            
    mdl = rapi.rpgConstructModel()
    mdlList.append(mdl)
    return 1
    
def read_ibuf(bs, count):
    ibuf = b''
    for x in range(count):
        face = [bs.readUByte() for x in range(4)]
        
        for i in face[:3]:
            ibuf +=(i).to_bytes(2, 'little')
        
        for i in face[1:][::-1]:
            ibuf +=(i).to_bytes(2, 'little')
        
        bs.seek(20, 1)
    return ibuf