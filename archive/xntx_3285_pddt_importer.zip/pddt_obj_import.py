from bintools import BinFile, BinBytes
from struct import Struct
from os import SEEK_SET, SEEK_CUR, SEEK_END
from array import array

bl_info = {
    "name": "PDDT Importer",
    "description": "Imports _obj.bin files from PDDT",
    "author": "oddwarlock, based on chrrox's max script",
    "version": (0, 1),
    "blender": (2, 66, 0),
    "location": "File > Import",
    "warning": "",
    "wiki_url": "http://www.example.com/",
    "tracker_url": "http://www.example.com/",
    "category": "Import-Export"}


def do_import(context, filepath):
    f = BinFile(filepath)

    magic = f.int()
    obj_cnt = f.int()
    unk_cnt = f.int()
    obj_pptr = f.int()
    bone_pptr = f.int()
    obj_name_pptr = f.int()
    head_ptr2 = f.int()
    head_ptr3 = f.int()
    head_count1 = f.int()

    head_bones = f.int(head_count1, head_ptr3)

    obj_name_ptrs = f.int(obj_cnt, obj_name_pptr)
    #TODO use obj names
    obj_names = [f.nstr(ptr) for ptr in obj_name_ptrs]

    obj_ptrs = f.int(obj_cnt, obj_pptr)
    bone_ptrs = f.int(obj_cnt, bone_pptr)

    arms = [Armature(f, ptr) for ptr in bone_ptrs if ptr != 0]
    objs = [Obj(f, ptr) for ptr in obj_ptrs if ptr != 0]

    return (objs, arms, f)#{'FINISHED'}

class Unk:#{{{
    def __init__(s, f, base):
        f.seek(base)
        s.base = base

        s.count1 = f.int()
        s.count2 = f.int()
        s.count3 = f.int()

        s.ptr1 = f.int()
        s.ptr2 = f.int()
        s.ptr3 = f.int()

        s.count4 = f.int()
        s.ptr4 = f.int()
        s.ptr5 = f.int()

        print('base', hex(s.base))
        print('count1', hex(s.count1))
        print('count2', hex(s.count2))
        print('count3', hex(s.count3))
        print('ptr1', hex(s.ptr1))
        print('ptr2', hex(s.ptr2))
        print('ptr3', hex(s.ptr3))
        print('ptr4', hex(s.ptr4))
        print('ptr5', hex(s.ptr5))

        s.ptr1_data = f.float(s.count1, s.ptr1)

        s.ptr2_ptrs = f.int(s.count1, s.ptr2)
        s.ptr2_names = [f.nstr(ptr) for ptr in s.ptr2_ptrs]

        s.ptr3_ptrs = []
        f.seek(s.ptr3)
        p = f.int()
        while p != 0:
            s.ptr3_ptrs.append(p)
            p = f.int()

        s.ptr3_data = []
        A = s.ptr3_ptrs
        n = len(s.ptr3_ptrs)
        for i,j in zip(range(0,n,2),range(1,n,2)):
            str1 = f.nstr(A[i])
            str2_ptr = f.int(1,A[j])[0]
            str2 = f.nstr(str2_ptr)
            s.ptr3_data.append((str1,str2))

        s.ptr4_ptrs = []
        f.seek(s.ptr4)
        p = f.int()
        while p != 0:
            s.ptr4_ptrs.append(p)
            p = f.int()

        s.ptr4_names = [f.nstr(ptr) for ptr in s.ptr4_ptrs]

        #MAGIC
        s.ptr5_data = f.float(56, s.ptr5)
#}}}
class Armature:#{{{
    def __init__(s, f, base):
        f.seek(base)
        s.base = base

        s.unk = []

        s.chain_arr = f.int()
        s.mtx_arr = f.int()
        s.name_pptr = f.int()
        s.unk_ptr = f.int()
        s.count = f.int()

        if s.unk_ptr != 0:
            #s.unk = Unk(f, s.unk_ptr)
            pass
        else:
            s.unk = None

        st_matrix = Struct('< 16f')
        s.chain = f.int(s.count, s.chain_arr)
        s.matrices = f.struct(st_matrix, s.count, s.mtx_arr)
        s.matrices = [(m[0:4],m[4:8],m[8:12],m[12:16]) for m in s.matrices]
        s.name_ptrs = f.int(s.count, s.name_pptr)
        #s.unk2 = f.int(s.count, s.unk[0])

        s.names = []
        for ptr in s.name_ptrs:
            s.names.append(f.nstr(ptr))
#}}}
class Obj:#{{{
    def __init__(self, file, base):
        s = self
        f = s.file = file
        s.base = base

        s.unk = []
        f.seek(base)
        s.unk.append(f.int(2))
        #they look like floats?
        s.unk.append(f.float(4))
        hdr = f.int(4)

        mesh_size = 216
        mesh_cnt = hdr[0]
        mesh_arr = hdr[1]

        mat_size = 1200
        mat_cnt = hdr[2]
        mat_arr = hdr[3]

        s.meshes = s._make_stuff(f, base, mesh_cnt, mesh_arr, mesh_size, Mesh)
        s.mats = s._make_stuff(f, base, mat_cnt, mat_arr, mat_size, Material)

        face_sec_size = 92
        st_vert = Struct('< 3f')
        st_vnorm = st_vert
        st_vcol = Struct('< 3f 4x')
        st_weight = Struct('< 4f')
        st_boneid = Struct('< 4I')
        st_uv = Struct('< 2f')

        for mesh in s.meshes:
            mesh.face_sections = s._make_stuff(f, base, mesh.face_sec_cnt,
                    mesh.face_sec_arr, face_sec_size, FaceSection)
            mesh.faces = []
            for fc in mesh.face_sections:
                mesh.faces.extend(fc.make_faces(f, base))
                fc.get_weights(f,base)

            #TODO handle more than one face section material
            mesh.material = s.mats[mesh.face_sections[0].material_index].name

            mesh.verts = f.struct(st_vert, mesh.vert_cnt, base + mesh.vert_arr)

            raw_vcols = f.struct(st_vcol, mesh.vcol_cnt, base + mesh.vcol_arr)

            mesh.vcols = []
            for vc in raw_vcols:
                mesh.vcols.append([abs(x) for x in vc])

            mesh.vnorms = f.struct(st_vnorm, mesh.vnorm_cnt, base + mesh.vnorm_arr)
            mesh.weights = f.struct(st_weight, mesh.weight_cnt, base + mesh.weight_arr)
            mesh.boneids = f.struct(st_boneid, mesh.boneid_cnt, base + mesh.boneid_arr)
            raw_uvs = f.struct(st_uv, mesh.uv_cnt, base + mesh.uv_arr)

            mesh.uvs = []
            for uv in raw_uvs:
                mesh.uvs.append((uv[0], uv[1]*-1))


    def _make_stuff(s, f, base, cnt, ptr, size, class_):
        ret = []
        for i in range(cnt):
            data = bytearray(size)
            f.seek(base + ptr + i * size)
            n = f.readinto(data)
            assert n == size
            ret.append(class_(data))
        return ret
#}}}
class Mesh:#{{{
    def __init__(s, data):
        d = BinBytes(data)
        s.unk = []
        s.unk.append(d.int())
        s.unk.append(d.float(4))
        #first is null
        #[1:5] == obj.unk
        #probably object and mesh origin?

        s.face_sec_cnt = d.int()
        s.face_sec_arr = d.int()

        s.unk.append(d.int(2))

        s.vert_cnt = d.int()
        s.vert_arr = d.int()
        s.vnorm_arr = d.int()
        s.vcol_arr = d.int()

        s.unk.append(d.int())

        s.uv_arr = d.int()

        s.unk.append(d.int(5))
        
        s.weight_arr = d.int()
        s.boneid_arr = d.int()

        s.unk.append(d.int(16))

        s.name = d.fstr(64)

        s.vnorm_cnt = s.vert_cnt if s.vnorm_arr > 0 else 0
        s.vcol_cnt = s.vert_cnt if s.vcol_arr > 0 else 0
        s.uv_cnt = s.vert_cnt if s.uv_arr > 0 else 0
        s.weight_cnt = s.vert_cnt if s.weight_arr > 0 else 0
        s.boneid_cnt = s.vert_cnt if s.boneid_arr > 0 else 0
#}}}
class Material:#{{{
    def __init__(s, data):
        d = BinBytes(data)
        s.unk = []
        s.unk.append(d.int(2))
        s.type = d.fstr(8)
        s.unk.append(d.int(264))
        s.name = d.fstr(64)
        s.unk.append(d.int(16))
#}}}
class FaceSection:#{{{
    def __init__(s, data):
        d = BinBytes(data)
        s.unk = []
        s.unk.append(d.int(5))

        s.material_index = d.int()

        s.unk.append(d.int(2))
        s.weight_count = d.int()
        s.weight_arr = d.int()

        s.unk.append(d.int())

        s.ftype = d.int()

        s.unk.append(d.int())

        s.face_cnt = d.int()
        s.face_arr = d.int()

        s.unk.append(d.int(8))

    def get_weights(s, f, base):
        s.weights = f.short(s.weight_count, base + s.weight_arr)

    def make_faces(s, f, base):
        facevals = f.short(s.face_cnt, base + s.face_arr)
        facevals.reverse()

        faces = []

        if s.ftype == 5:
            start_direction = -1
            face_direction = start_direction
            f1 = facevals.pop()
            f2 = facevals.pop()
            while len(facevals) > 0:
                f3 = facevals.pop()
                if f3 == 0xFFFF:
                    f1 = facevals.pop()
                    f2 = facevals.pop()
                    face_direction = start_direction
                else:
                    face_direction *= -1
                    if f1 != f2 and f2 != f3 and f1 != f3:
                        if face_direction > 0:
                            faces.append((f1, f2, f3))
                        else:
                            faces.append((f1, f3, f2))
                    f1 = f2
                    f2 = f3

        return faces
#}}}


try:
    import bpy
    from bpy_extras.io_utils import ImportHelper
    from bpy.props import StringProperty
    from bpy.types import Operator
    from mathutils import Matrix, Vector
    from bpy_extras.io_utils import unpack_list, unpack_face_list

    class ImportPDDT(Operator, ImportHelper):
        """Import PDDT _obj.bin file"""
        bl_idname = "import_scene.pddt"
        bl_label = "Import PDDT"

        filename_ext = "*_obj.bin"

        filter_glob = StringProperty(
                default="*_obj.bin",
                options={'HIDDEN'},
                )

        def execute(self, context):
            objs, arms, f = do_import(context, self.filepath)
            f.close()
            do_blender(context, objs, arms)
            return {'FINISHED'}

    def menu_func_import(self, context):
        self.layout.operator(ImportPDDT.bl_idname, text="PDDT (_obj.bin)")

    def register():
        bpy.utils.register_class(ImportPDDT)
        bpy.types.INFO_MT_file_import.append(menu_func_import)

    def unregister():
        bpy.utils.unregister_class(ImportPDDT)
        bpy.types.INFO_MT_file_import.remove(menu_func_import)

    def do_blender(context, objs, arms):
        for robj in objs:
            parent_obj = None

            for rmat in robj.mats:
                mat = bpy.data.materials.new(rmat.name)

            for rmesh in robj.meshes:
                mesh = bpy.data.meshes.new(rmesh.name)
                obj = bpy.data.objects.new(rmesh.name, mesh)

                obj.active_material = bpy.data.materials[rmesh.material]

                if not(parent_obj):
                    parent_obj = obj
                else:
                    obj.parent = parent_obj

                mesh.vertices.add(len(rmesh.verts))
                mesh.vertices.foreach_set("co", unpack_list(rmesh.verts))

                mesh.tessfaces.add(len(rmesh.faces))
                mesh.tessfaces.foreach_set("vertices_raw", unpack_face_list(rmesh.faces))

                vc_layer = mesh.tessface_vertex_colors.new()

                for i, face_vc in enumerate(vc_layer.data):
                    if len(rmesh.vcols) == 0: break
                    vertices_raw = mesh.tessfaces[i].vertices_raw
                    face_vc.color1 = rmesh.vcols[vertices_raw[0]]
                    face_vc.color2 = rmesh.vcols[vertices_raw[1]]
                    face_vc.color3 = rmesh.vcols[vertices_raw[2]]

                uv_layer = mesh.tessface_uv_textures.new()

                for i, face_uv in enumerate(uv_layer.data):
                    if len(rmesh.uvs) == 0: break
                    vertices_raw = mesh.tessfaces[i].vertices_raw
                    face_uv.uv1 = rmesh.uvs[vertices_raw[0]]
                    face_uv.uv2 = rmesh.uvs[vertices_raw[1]]
                    face_uv.uv3 = rmesh.uvs[vertices_raw[2]]

                mesh.update()
                bpy.context.scene.objects.link(obj)

        for rarm in arms:
            if bpy.ops.object.mode_set.poll():
                bpy.ops.object.mode_set(mode='OBJECT')

            bpy.ops.object.add(type='ARMATURE', enter_editmode=True)
            arm = bpy.context.object.data

            for i in range(rarm.count):
                bone = arm.edit_bones.new(rarm.names[i])
                bone.tail = Vector((0,0,1))
                matrix = Matrix(rarm.matrices[i]).transposed().inverted()

                bone.head = Vector(matrix[3][0:3])
                bone.tail = bone.head + (0.01 * Vector(matrix[0][0:3]).normalized())

            if bpy.ops.object.mode_set.poll():
                bpy.ops.object.mode_set(mode='OBJECT')

    if __name__ == "__main__":
        #objs, arms, f = do_import(None, '/tmp/mikitm001_obj.bin') 
        #f.close()
        #do_blender(None, objs, arms)
        register()

except ImportError:
    if __name__ == "__main__":
        #global f, arms, objs
        #objs, arms, f = do_import(None, '/tmp/mikitm001_obj.bin')
        pass
    pass
