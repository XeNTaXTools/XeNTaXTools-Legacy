from io import FileIO, BytesIO
from struct import Struct
from array import array
from os import SEEK_SET, SEEK_CUR, SEEK_END

class BinCommon():

    _endian = '<'
    _structs = {}

    for t in ['b', 'B', 'H', 'h', 'I', 'i', 'f']:
        _structs[t] = Struct(_endian + t)

    """
    read a struct from the file
    """
    def struct(self, st, n=None, offset=None, whence=SEEK_SET):
        #print(st, n, offset, whence)
        if offset:
            self.seek(offset, whence)
        if n == None:
            data = self.read(st.size)
            ret = st.unpack(data)
        else:
            ret = []
            for i in range(n):
                data = self.read(st.size)
                ret.append(st.unpack(data))
        return ret

    """
    read array(t) of length n
    uses host endianness

    """
    def array(self, t, n):
        a = array(t)
        a.fromfile(self, n)
        return a

    """
    private helper method

    """
    def _read(self, t, n, offset, whence):
        if offset:
            self.seek(offset, whence)
        ret = None
        if n == None:
            s = self._structs[t]
            ret = self.struct(s)[0]
        else:
            ret = self.array(t,n)
        return ret

    """
    read unsigned byte

    """
    def byte(self, n=None, offset=None, whence=SEEK_SET):
        return self._read('B', n, offset, whence)

    """
    read unsigned short

    """
    def short(self, n=None, offset=None, whence=SEEK_SET):
        return self._read('H', n, offset, whence)

    """
    read unsigned int

    """
    def int(self, n=None, offset=None, whence=SEEK_SET):
        return self._read('I', n, offset, whence)

    """
    read float

    """
    def float(self, n=None, offset=None, whence=SEEK_SET):
        return self._read('f', n, offset, whence)

    """
    read fixed string of size

    """
    def fstr(self, size, n=None, offset=None, whence=SEEK_SET):
        if offset:
            self.seek(offset, whence)
        if n == None:
            data = self.read(size)
            return data.decode()
        else:
            ret = []
            data = self.read(size*n)
            for i in range(n):
                ret.append(data[i*size:(i+1)*size].decode())
            return ret

    """
    read null-terminated string

    """
    def nstr(self, offset=None, whence=SEEK_SET):
        if offset:
            self.seek(offset, whence)
        ret = bytearray()
        t = self.read(1)
        while t != b'\x00':
            ret.extend(t)
            t = self.read(1)
        return ret.decode()

class BinFile(FileIO, BinCommon):
    pass

class BinBytes(BytesIO, BinCommon):
    pass
