from inc_noesis import *
import noesis
import rapi

def registerNoesisTypes():
    handle = noesis.register("Metal Gear Solid HD collection (PS3)", ".cmdl")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    return 1   

def noepyLoadModel(data, mdlList):
    ctx = rapi.rpgCreateContext()
    rapi.rpgSetOption(noesis.RPGOPT_BIGENDIAN, 1)  #set big-endian byte order
    bs = NoeBitStream(data, NOE_BIGENDIAN)
    meshName = rapi.getLocalFileName(rapi.getInputName()).strip(".cmdl")
    rapi.rpgSetName(meshName)
    MODL = bs.readBytes(4)   #face indices
    unk = bs.readInt()
    FIOffset = bs.readUInt() + 0xc
    unk = bs.readInt()    
    POS0 = bs.readBytes(4)   #vertex data
    unk = bs.readInt()
    VOffset = bs.readUInt() + 0xc
    VBuffer = bs.readUInt()
    VCount = VBuffer // 16
    NRM0 = bs.readBytes(4)   #normals
    unk = bs.readInt()
    NOffset = bs.readUInt() + 0xc
    NBuff = bs.readUInt()
    TEX0 = bs.readBytes(4)   #UVs
    unk = bs.readInt()
    UVOffset = bs.readUInt() + 0xc
    UVBuff = bs.readUInt()
    bs.seek(VOffset, NOESEEK_ABS)
    VBuf = bs.readBytes(VBuffer)
    rapi.rpgBindPositionBufferOfs(VBuf, noesis.RPGEODATA_FLOAT, 16, 0)   #position of vertices
    bs.seek(NOffset, NOESEEK_ABS)
    NBuf = bs.readBytes(NBuff)
    #NBuf = rapi.decodeNormals32(NBuf, 4, -10, -10, -10, NOE_BIGENDIAN) #????
    #rapi.rpgBindNormalBufferOfs(NBuf, noesis.RPGEODATA_FLOAT, 12, 0)   #normals
    bs.seek(UVOffset, NOESEEK_ABS)
    UVBuf = bs.readBytes(UVBuff)
    rapi.rpgBindUV1BufferOfs(UVBuf, noesis.RPGEODATA_HALFFLOAT, 4, 0)   #UV1
    bs.seek(FIOffset, NOESEEK_ABS)
    FCount = bs.readUInt()
    IBuf = bs.readBytes(FCount * 4)
    checkTri = int(FCount % 3)         #check if FCount is evenly divisible by 3
    if checkTri == 0:
        rapi.rpgCommitTriangles(IBuf, noesis.RPGEODATA_INT, FCount, noesis.RPGEO_TRIANGLE, 1) 
    else:
        rapi.rpgCommitTriangles(IBuf, noesis.RPGEODATA_INT, FCount, noesis.RPGEO_TRIANGLE_STRIP, 1) 
    mdl = rapi.rpgConstructModel()                                                          
    mdlList.append(mdl)
    rapi.rpgClearBufferBinds()
    return 1