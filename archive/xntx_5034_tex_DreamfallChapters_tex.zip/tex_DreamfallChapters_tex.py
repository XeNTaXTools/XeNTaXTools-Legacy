from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Dreamfall Chapters", ".tex")
	noesis.setHandlerTypeCheck(handle, noeCheckGeneric)
	noesis.setHandlerLoadRGBA(handle, DCLoadRGBA)
	#noesis.logPopup()
	return 1

def DCLoadRGBA(data, texList):
    datasize = len(data) - 0x3C
    bs = NoeBitStream(data)
    imgHeight = bs.readInt()                    
    imgWidth = bs.readInt() 
    imgData = bs.readInt()
    imgFmt = bs.readInt()
    bs.seek(0x3C, NOESEEK_ABS)
    data = bs.readBytes(datasize)  
    #DXT1
    if imgFmt == 0x0A:
        rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_DXT1)
        texFmt = noesis.NOESISTEX_DXT1
    #DXT5
    elif imgFmt == 0x0C:
        rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_DXT5)
        texFmt = noesis.NOESISTEX_DXT5
    #unknown, not handled
    else:
        print("WARNING: Unhandled image format")
        return None
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1