bsp2obj for Italian Job by dcxdemo.

.NET Framework 4.5 is required.

use as a command line tool by passing bsp file name as an argument or simply drag drop bsp file on the tool. selecting the tool in "open bsp with..." will work too.

OBJ is exported with vertex colors, which is not officially supported by the format (v x y z r g b). Use MeshLab to read vertex color data.

Low lod is a part of the same model, you can split mesh by materials and remove the low lod objects manually.

Import tested in meshlab and blender.

Create new textures folder in the same folder where your obj is located and extract all textures from txd container in PNG format. You can use common GTA tools to operate txd containers (renderware too). Refer to the generated MTL file if unsure.