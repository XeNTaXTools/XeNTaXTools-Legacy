
#include "human.h"
#include "stage.h"

//+---------------------------------------------------------> 

bool main()
{
 //  	cHuman stg;
	//if(!stg.Load("z:/capcom/dmc4/model/demo/pl008/pl008_01.mod"))
	////if(!stg.Load("z:/capcom/lostplanet/scr/stage1/s102/s102_10.mod"))
	//	return false;
	//stg.Export("c:/out.obj");
	//stg.Delete();
	
	float x = 0.0f;
	char strFile[128] = {0};
	char strOut[128] = {0};

	printf("\n| Achouration Devil May Cry 4 & Lostplanet Model converter 2 In One\n");
	printf("| Juillet 2009			    \t\t\n\n");

	printf("model filename: ");
	scanf("%s", &strFile);
	sprintf(strOut, "%s.obj", strFile);

	FILE *pFile = fopen(strFile, "rb");
	if(!pFile)
	{
		printf("Can't open this file !\n");
		return false;
	}

	// read the bone count
	unsigned short us;
	fseek(pFile, 6, SEEK_SET);
	fread(&us, 2, 1, pFile);
    
	if(us)
	{
		cHuman hum;
		if(!hum.Load(strFile))
			return false;
		hum.Export(strOut);
		hum.Delete();
	}
	else
	{
		// from st105-m84-Ltower
		cStage stg;
		if(!stg.Load(strFile))
			return false;
		stg.Export(strOut);
		stg.Delete();
	}
	return true;
}

//+---------------------------------------------------------> 