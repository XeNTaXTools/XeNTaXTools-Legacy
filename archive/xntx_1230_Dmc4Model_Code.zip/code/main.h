
#ifndef _MAIN_H
#define _MAIN_H

#include <stdio.h>
#include <d3dx9.h>
#pragma comment(lib, "d3dx9.lib")

#endif