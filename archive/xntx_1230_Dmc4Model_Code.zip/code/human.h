
#ifndef _HUMAN_H
#define _HUMAN_H

//+---------------------------------------------------------> Headers

#include "main.h"

//+---------------------------------------------------------> cBoneInfo

struct cBoneInfo
{
	char					cId;
	char					cParent;			// -1 means no parents
	char					cChild;				// child id
	char					cUnknown;
	float					fData[2];			// maybe forces?
	D3DXVECTOR3				vTrans;				// translation vector
};

//+---------------------------------------------------------> cBoneTransform

struct cBoneTransform
{
	D3DXMATRIX				mTransform1;		// maybe local and world transforms
	D3DXMATRIX				mTransform2;
};

//+---------------------------------------------------------> cTexture

struct cTexture
{
	char					strName[64];
};

//+---------------------------------------------------------> cMaterial

struct cMaterial
{
	unsigned int			uiUnknown[6];
	unsigned int			uiLayer0;			// tex0: base 1, 0 means no bind
	unsigned int			uiLayer1;			// tex1
	unsigned int			uiLayer2;			// tex2
	unsigned int			uiLayers[5];		// tex3 ... tex8
	float					fColors[26];		// ambient, diffuse, specular, shininess, ...
};

//+---------------------------------------------------------> cObject

struct cObject
{
	unsigned short			usId;				// id from the indes table
	unsigned short			usMatId;			// material Id
	unsigned short			usFlag[8];			// 0xFF01, 0, the 3rd flag determines what vertex declaration to use
	unsigned int			uiBase1;			// base multiple of 32
	unsigned int			uiZero;
	unsigned int			uiStart;			// start index
	unsigned int			uiCount;			// faces (indices - 2)
	unsigned int			uiBase;
	unsigned int			uiInconnu[3];
};

//+---------------------------------------------------------> cVertex

struct cVertex
{
	//	0	D3DDECLTYPE_SHORT4N		POSITION
	//	8	D3DDECLTYPE_UBYTE4		BLENDINDICES
	//	12	D3DDECLTYPE_UBYTE4N		BLENDWEIGHT
	//	16	D3DDECLTYPE_UBYTE4N		NORMAL
	//	20	D3DDECLTYPE_UBYTE4N		TANGENT
	//	24	D3DDECLTYPE_FLOAT16_2	TEXCOORD
	//	28	D3DDECLTYPE_FLOAT16_2	TEXCOORD

	short	x, y, z, w;			// w always 0x7FFF (32767, divisor?)
	BYTE	bone[4];
	BYTE	weight[4];
	char	nx, ny, nz, nw;
	char	tx, ty, tz, tw;		// tangent not textures !!
	short	u0, v0;
	short	u1, v1;				// seems to be always 0xFFFF 0xFFFF

	// another vertex declaration
	// 0	D3DDECLTYPE_SHORT4N		POSITION
	// 8	D3DDECLTYPE_UBYTE4		BLENDINDICES
	// 12	D3DDECLTYPE_UBYTE4		BLENDINDICES	index1, null all the times
	// 16	D3DDECLTYPE_UBYTE4N		BLENDWEIGHT
	// 20	D3DDECLTYPE_UBYTE4N		BLENDWEIGHT		index1, null all the time
	// 24	D3DDECLTYPE_UBYTE4N		NORMAL
	// 28	D3DDECLTYPE_FLOAT16_2	TEXCOORD
};

//+---------------------------------------------------------> cHuman

class cHuman
{
public:
							cHuman();

	bool					Load(const char *strModel);
	bool					Export(const char *strModel);
	void					Delete();

private:

	unsigned int			m_uiTag;			// "MOD"
	unsigned short			m_usVersion;		// 0x99
	unsigned short			m_usBoneNum;		// bone count
	unsigned short			m_usObjectNum;		// object count
	unsigned short			m_usMaterialNum;	// material count
	unsigned int			m_uiVertexNum;		// vertex count
	unsigned int			m_uiIndexNum;		// index count
	unsigned int			m_uiIII1;
	unsigned int			m_uiVertexDataSize;	// in bytes of course
	unsigned int			m_uiIII2;			// usually 0;
	unsigned int			m_uiTextureNum;		// texture count
	unsigned int			m_uiIII3;			// sometimes matches the first bone count
	unsigned int			m_uiIII4;
	unsigned int			m_uiBoneOffset;		// usually 144
	unsigned int			m_uiBoneOffset2;
	unsigned int			m_uiTextureOffset;
	unsigned int			m_uiObjectOffset;
	unsigned int			m_uiVertexOffset;
	unsigned int			m_uiIII5;			// 0
	unsigned int			m_uiIndexOffset;
	unsigned int			m_uiIII6;			// 0
	unsigned int			m_uiIII7;			// 0
	D3DXVECTOR4				m_vBSphere;			// bounding sphere: center + radius
	D3DXVECTOR4				m_vBBoxMin;
	D3DXVECTOR4				m_vBBoxMax;			// bounding box, w components are unused
	unsigned int			m_uiIII8[4];		// always 1000, 3000, 2 and a float

	cBoneInfo				*m_pBoneInfo;
	cBoneTransform			*m_pBoneTransform;
	cTexture				*m_pTexture;
	cMaterial				*m_pMaterial;
	cObject					*m_pObject;
	cVertex					*m_pVertex;
	WORD					*m_pIndex;
};

#endif