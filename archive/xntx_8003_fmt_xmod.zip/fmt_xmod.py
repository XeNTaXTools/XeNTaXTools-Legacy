from inc_noesis import *
import rapi

def registerNoesisTypes():
   handle = noesis.register("mesh", ".xmod")
   noesis.setHandlerTypeCheck(handle, noepyCheckType)
   noesis.setHandlerLoadModel(handle, noepyLoadModel)
   noesis.logPopup()
   return 1

def noepyCheckType(data):
    if len(data) < 0x80:
        return 0
    bs = NoeBitStream(data)
    if noeAsciiFromBytes(bs.readBytes(4)) != 'XVAM':
        return 0
    return 1       

def noepyLoadModel(data, mdlList):
    bs = NoeBitStream(data)
    head = noeAsciiFromBytes(bs.readBytes(4))
    type_model = bs.readInt()
    ver = bs.readInt64()
    
    if type_model == 4099:
        bs.seek(12, NOESEEK_REL)
        
    strSize = bs.readInt()
    File_Name = noeAsciiFromBytes(bs.readBytes(strSize))
    
    print(File_Name,"Type_model:",type_model)
    
    Unk0 = bs.readInt()
    Unk1 = bs.readInt()
    bs.seek(28, NOESEEK_REL)
    Node_count = bs.readInt()#not node, Child count
    print(" Unk0:",Unk0,"Unk1:",Unk1,"Node_count:",Node_count)
    
    meshes = []
    
    for node in range(Node_count):
        strSize = bs.readInt()
        Node_Name = noeAsciiFromBytes(bs.readBytes(strSize))
        
        Unk3 = bs.readInt()
        Type1 = bs.readShort()
        Type2 = bs.readShort()
        
        
        if Unk3 == 3:
            bs.seek(40, NOESEEK_REL)
        else:
            bs.seek(68, NOESEEK_REL)
        Mesh_count = bs.readInt()
        print("     Node_Name:",Node_Name,"Mesh_count:",Mesh_count)
        print("     Type1:",Type1,"Type2:",Type2)
        
        if Mesh_count > 0:
            #read mesh
            for m in range(Mesh_count):
                vert, norm, face, uv, tx = [], [], [], [], []
                weight, boneMap, boneName = [], [], []
                
                strSize = bs.readInt()
                meshName = noeAsciiFromBytes(bs.readBytes(strSize))
                meshID = bs.readInt()
                #Unk4 = bs.readInt()
                print("         ",[bs.readByte() for x in range(4)])
                vCount = bs.readInt()
                
                print("         meshName:",meshName,"meshID:",meshID,"vCount:",vCount)
                if vCount > 65000:
                    return 0
                
                #mesh type 1 (32)byte
                if Type1 == 4101:
                    for x in range(vCount):
                        vert.append(NoeVec3.fromBytes(bs.readBytes(12)))
                        norm.append(NoeVec3.fromBytes(bs.readBytes(12)))
                        uv.append(NoeVec3([bs.readFloat(), bs.readFloat(), 0.0]))
                
                #mesh type 2 (56)byte
                if Type1 == 5381:
                    for x in range(vCount):
                        vert.append(NoeVec3.fromBytes(bs.readBytes(12)))
                        norm.append(NoeVec3.fromBytes(bs.readBytes(12)))
                        bi = NoeVec3.fromBytes(bs.readBytes(12))
                        t = NoeVec3.fromBytes(bs.readBytes(12))
                        uv.append(NoeVec3([bs.readFloat(), bs.readFloat(), 0.0]))
                
                #mesh type 3 (60)byte
                if Type1 == 5397:
                    for x in range(vCount):
                        vert.append(NoeVec3.fromBytes(bs.readBytes(12)))
                        norm.append(NoeVec3.fromBytes(bs.readBytes(12)))
                        bi = NoeVec3.fromBytes(bs.readBytes(12))
                        t = NoeVec3.fromBytes(bs.readBytes(12))
                        uv.append(NoeVec3([bs.readFloat(), bs.readFloat(), 0.0]))
                        bs.read.Float()
                
                #face
                fCount = bs.readInt()
                face = [bs.readUShort() for x in range(fCount)]
                
                """
                ...???...
                BoneMap ?(count byte)?
                Bones ?(count byte)?
                Materials ?(count byte)?
                ...???...
                """

                mesh = NoeMesh(face, vert, meshName, "mat_0")
                mesh.setUVs(uv)
                mesh.setNormals(norm)
                meshes.append(mesh)
                break
            #load only 1 mesh
            if len(meshes) > 0:
                break
    
    mdl = NoeModel(meshes)
    mdl.setModelMaterials(NoeModelMaterials([], [NoeMaterial("mat_0","")]))
    mdlList.append(mdl)
 
    return 1