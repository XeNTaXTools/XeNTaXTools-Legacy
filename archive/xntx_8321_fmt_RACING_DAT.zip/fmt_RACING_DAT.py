from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("iRacing", ".dat")
    noesis.setHandlerExtractArc(handle, axpExtractArc)
    return 1

def axpExtractArc(fileName, fileLen, justChecking):
    if fileLen < 16:
        return 0
        
    if justChecking: #it's valid
            return 1

    data = rapi.loadIntoByteArray(fileName)
    bs = NoeBitStream(data)
    
    bs.seek(2)
    numFiles = bs.readInt()
    DataOfs = bs.readInt()
    
    for x in range(numFiles):
        ztype = bs.readUShort()
        size = bs.readInt()
        zsize = bs.readInt()
        offset = bs.readInt()
        name = noeAsciiFromBytes(bs.readBytes(bs.readByte() + 1))
        print(ztype, size, zsize, offset, name)
        curPos = bs.getOffset()
        bs.seek(offset)
        
        if ztype == 2821:
            s = 'deflate_\\'
        elif ztype == 3333:
            s = 'unkCompress_\\'
        else:
            s = ''
        
        export_data = bs.readBytes(zsize)
        rapi.exportArchiveFile(s+name, export_data)
        bs.seek(curPos)
        print("export", name)

    print("Extracting", numFiles, "files.")
    return 1