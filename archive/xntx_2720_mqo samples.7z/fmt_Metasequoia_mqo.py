from inc_noesis import *
import noesis
import rapi
from struct import *

def registerNoesisTypes():
    '''Register the plugin. Just change the Game name and extension.'''
    
    handle = noesis.register("Metasequoia", ".mqo")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)
    return 1

def noepyCheckType(data):
    '''Verify that the format is supported by this plugin. Default yes'''
    
    return 1

def noepyLoadModel(data, mdlList):
    '''Build the model, set materials, bones, and animations. You do not
    need all of them as long as they are empty lists (they are by default)'''
    
    ctx = rapi.rpgCreateContext()
    
    parser = SanaeParser(data)
    parser.parse_file()
    mdl = rapi.rpgConstructModel()
    mdl.setModelMaterials(NoeModelMaterials(parser.texList, parser.matList))
    mdl.setBones(parser.boneList)
    mdl.setAnims(parser.animList)
    mdlList.append(mdl)
    return 1

class SanaeParser(object):
    
    def __init__(self, data):    
        '''Initialize some data. Refer to Sanae.py to see what is already
        initialized'''
        
        self.inFile = NoeBitStream(data)
        self.animList = []
        self.texList = []
        self.matList = []
        self.boneList = []
        
    def get_value(self, line, start, end):
        
        start = line.find(start) + 1
        end = line.find(end, start)
        return line[start:end]
        
    def skip_lines(self, string):
        '''Skip lines until it starts with string'''
        
        line = self.inFile.readline()
        while not line.strip().startswith(string):
            line = self.inFile.readline()
        return line
        
    def parse_material(self, numMat):
        
        pass
    
    def parse_faces(self, numFaces):
        
        numTris = 0
        numQuads = 0
        triBuff = bytes()
        quadBuff = bytes()
        for i in range(numFaces):
            line = self.inFile.readline().strip()
            numVerts = int(line[0])
            verts = self.get_value(line, "(", ")").split()           
            
            if numVerts == 3:
                triBuff += struct.pack("3L", *map(int, verts))
                numTris += 3
            elif numVerts == 4:
                quadBuff += struct.pack("4L", *map(int, verts))
                numQuads += 4
                
        print("%d tris, %d quads" %(numTris, numQuads))
        if numTris:
            rapi.rpgCommitTriangles(triBuff, noesis.RPGEODATA_UINT, numTris, noesis.RPGEO_TRIANGLE, 1)
        if numQuads:
            rapi.rpgCommitTriangles(quadBuff, noesis.RPGEODATA_UINT, numQuads, noesis.RPGEO_QUAD, 1)
    
    def parse_vertices(self, numVerts):
        
        vertBuff = bytes()
        for i in range(numVerts):
            coords = self.inFile.readline().strip().split()
            vertBuff += struct.pack("3f", *map(float, coords))
        
        rapi.rpgBindPositionBuffer(vertBuff, noesis.RPGEODATA_FLOAT, 12)
        rapi.rpgCommitTriangles(None, noesis.RPGEODATA_UINT, numVerts, noesis.RPGEO_POINTS, 1)
    
    def parse_mesh(self, line):

        meshName = self.get_value(line, '"', '"')
        line = self.skip_lines("vertex")
        numVerts = int(line.split()[1])
        self.parse_vertices(numVerts)

        line = self.skip_lines("face")
        numFaces = int(line.split()[1])
        self.parse_faces(numFaces)
        
    def parse_file(self):
        '''Main parser method'''
        
        line = self.inFile.readline()
        print(type(line))
        while line:
            line = line.strip()
            if line.startswith("Scene"):
                print("scene")
            elif line.startswith("Material"):
                print('material')
            elif line.startswith("Object"):
                self.parse_mesh(line)
                #print("object", line)
            line = self.inFile.readline()
        