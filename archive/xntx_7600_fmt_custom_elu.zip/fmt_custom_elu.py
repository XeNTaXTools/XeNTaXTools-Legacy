# costom elu importer by Bigchillghost

import rapi
from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("costom elu", ".elu;")
	noesis.setHandlerTypeCheck(handle, checkType)
	noesis.setHandlerLoadModel(handle, convModel)
	
	#noesis.logPopup()
	return 1

#check if it's this type based on the data
def checkType(data):
	if len(data) < 0x80:
		return 0
	bs = NoeBitStream(data)
	Magic = bs.readUInt()
	if Magic != 0x107F060:
		return 0
	bs.seek(8, NOESEEK_ABS)
	Count = bs.readUInt()
	if Count != 0xFFFFFFFF:
		return 0
	return 1

#convert the model to obj
def convModel(data, mdlList):
	#noesis.logPopup()
	bs = NoeBitStream(data)
	bs.seek(4, NOESEEK_ABS)
	version = bs.readUInt()
	bs.seek(0x10, NOESEEK_ABS)
	meshCnt = bs.readUShort()
	if version > 0:
		unk = bs.readUByte()
		for i in range(0,2):
			Len = bs.readUShort()
			bs.seek(Len, NOESEEK_REL)
		bs.seek(8, NOESEEK_REL)
			
	outName = rapi.getInputName().replace("elu","obj")
	ObjFile = open(outName, "wb")
	ObjFile.write(b'# Wavefront OBJ\n\n')
	accIndexBase = 1
	accByPolyVertIdx = 1
	meshIdx = 0
	while meshIdx < meshCnt:
		Len = bs.readUShort()
		meshName = "mesh%d"%meshIdx
		if Len > 0:
			meshName = noeStrFromBytes(bs.readBytes(Len))
			Len = bs.readUShort()
			bs.seek(Len, NOESEEK_REL)
		bs.seek(0x26C, NOESEEK_REL)
		vertCnt = bs.readUInt()
		posStream = NoeBitStream()
		for j in range(0, vertCnt):
			x,y,z = bs.readFloat(),bs.readFloat(),bs.readFloat()
			posStream.writeString('v %f %f %f\n'%(x,y,z), 0)
		posStream.writeString('# %d vertices\n\n'%vertCnt, 0)
			
		polyCnt = bs.readUInt()
		polyStream = NoeBitStream()
		uvStream = NoeBitStream()
		polyStream.writeString('g %s\n'%meshName, 0)
		for j in range(0, polyCnt):
			polyStream.writeString('f', 0)
			for k in range(0, 3):
				vertIdx = bs.readInt() + accIndexBase
				polyStream.writeString(' %d/%d/%d'%(vertIdx, accByPolyVertIdx, accByPolyVertIdx), 0)
				accByPolyVertIdx += 1
			polyStream.writeString('\n', 0)
			for k in range(0, 3):
				u,v,w = bs.readFloat(),bs.readFloat(),bs.readFloat()
				uvStream.writeString('vt %f %f\n'%(u,1.0-v), 0)
			bs.seek(8, NOESEEK_REL)
		accIndexBase += vertCnt
		uvStream.writeString('# %d texture coordinates\n\n'%(polyCnt*3), 0)
		polyStream.writeString('# %d triangles\n\n'%polyCnt, 0)
		
		nmStream = NoeBitStream()
		for j in range(0, polyCnt):
			bs.seek(12, NOESEEK_REL)
			for k in range(0, 3):
				x,y,z  = bs.readFloat(),bs.readFloat(),bs.readFloat()
				nmStream.writeString('vn %f %f %f\n'%(x,y,z), 0)
		nmStream.writeString('# %d normals\n\n'%(polyCnt*3), 0)
		
		ObjFile.write(posStream.getBuffer())
		ObjFile.write(nmStream.getBuffer())
		ObjFile.write(uvStream.getBuffer())
		ObjFile.write(polyStream.getBuffer())
		
		bs.seek(8, NOESEEK_REL)
		blendInfoCnt = bs.readUInt()
		for j in range(0, blendInfoCnt):
			weightNum = bs.readUByte()
			for k in range(0, weightNum):
				boneID = bs.readInt()
				weight = bs.readFloat()
				bs.seek(12, NOESEEK_REL)
				boneNameLen = bs.readUShort()
				bs.seek(boneNameLen, NOESEEK_REL)
		if meshIdx == 0 and blendInfoCnt > 0:
			boneCnt = 0
			sharedStr = ""
			while True:
				curPos = bs.tell()
				boneNameLen = bs.readUShort()
				boneName = noeStrFromBytes(bs.readBytes(boneNameLen))
				if boneCnt == 0:
					sharedStr = boneName
				parentBoneNameLen = bs.readUShort()
				bs.seek(parentBoneNameLen, NOESEEK_REL)
				if not boneName.startswith(sharedStr):
					bs.seek(curPos, NOESEEK_ABS)
					break
				bs.seek(0x26C, NOESEEK_REL)
				cnt = bs.readInt()
				bs.seek(cnt*12, NOESEEK_REL)
				cnt2 = bs.readInt()
				bs.seek(cnt2*0x38, NOESEEK_REL)
				bs.seek(cnt2*0x30+0xC, NOESEEK_REL)
				boneCnt += 1
			meshCnt -= boneCnt
		meshIdx += 1
	ObjFile.close()
	return 0