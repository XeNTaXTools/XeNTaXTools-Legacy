import newGameLib
reload(newGameLib)
from newGameLib import *
import Blender	


def xtexParser(filename,g):
	texPath=None
	g.seek(25)
	g.word(g.H(1)[0]*2)
	g.seek(16,1)
	a,b,c,d,e=g.H(5)
	g.B(5)
	format=g.word(4)
	g.i(1)
	img=imageLib.Image()
	if c==2 and e==2:
		img.szer=512
		img.wys=512
		img.format=format
		img.name=filename.lower().replace('.xtex','.dds')
		img.data=g.read(g.fileSize()-g.tell())
		img.draw()
		texPath=img.name
	elif c==2 and e==4:
		img.szer=512
		img.wys=1024
		img.format=format
		img.name=filename.lower().replace('.xtex','.dds')
		img.data=g.read(g.fileSize()-g.tell())
		img.draw()
		texPath=img.name
	elif c==4 and e==2:
		img.szer=1024
		img.wys=512
		img.format=format
		img.name=filename.lower().replace('.xtex','.dds')
		img.data=g.read(g.fileSize()-g.tell())
		img.draw()
		texPath=img.name
	elif c==2 and e==1:
		img.szer=512
		img.wys=256
		img.format=format
		img.name=filename.lower().replace('.xtex','.dds')
		img.data=g.read(g.fileSize()-g.tell())
		img.draw()
		texPath=img.name
	elif c==1 and e==2:
		img.szer=256
		img.wys=512
		img.format=format
		img.name=filename.lower().replace('.xtex','.dds')
		img.data=g.read(g.fileSize()-g.tell())
		img.draw()
		texPath=img.name
	elif c==1 and e==1:
		img.szer=256
		img.wys=256
		img.format=format
		img.name=filename.lower().replace('.xtex','.dds')
		img.data=g.read(g.fileSize()-g.tell())
		img.draw()
		texPath=img.name
	elif c==0 and e==0:
		img.szer=128
		img.wys=128
		img.format=format
		img.name=filename.lower().replace('.xtex','.dds')
		img.data=g.read(g.fileSize()-g.tell())
		img.draw()
		texPath=img.name
	else:
		print 'WARNING:unknow image size for:',a,b,c,d,e
	return texPath	

def xskinParser(filename,g):
	print '-'*10,'xskinParser:',filename
	g.word(8)
	g.B(17)
	model=g.word(g.H(1)[0]*2)
	g.B(3)
	g.i(2)
	g.f(6)
	strideType,unk,vertCount,indiceCount=g.i(4)
	strideSize=None
	uvOffset=None
	print 'strideType:',strideType
	if strideType==65874:strideSize=52;uvOffset=28
	elif strideType==66066:strideSize=48;uvOffset=28
	elif strideType==65810:strideSize=48;uvOffset=24
	elif strideType==594:strideSize=44;uvOffset=28
	elif strideType==530:strideSize=40
	elif strideType==274:strideSize=32;uvOffset=24
	elif strideType==338:strideSize=36;uvOffset=28
	else:
		print 'WARNING:unknow strideType:',strideType
	if strideSize is not None:
		mesh=Mesh()
		mesh.name=model
		for m in range(vertCount):
			t=g.tell()
			if uvOffset is not None:
				g.seek(t+uvOffset)
				mesh.vertUVList.append(g.f(2))
			g.seek(t+strideSize)
		for m in range(indiceCount/3):mesh.faceList.append(g.H(3))
		matCount=g.i(1)[0]
		print 'mat count:',matCount
		for m in range(matCount):
			mat=Mat()
			mat.name=g.word(g.H(1)[0]*2)
			g.H(1)
			mesh.matList.append(mat)	
		count=g.i(1)[0]
		for m in range(count):
			mat=mesh.matList[m]
			mat.TRIANGLE=True
			faceCount,matID=g.i(2)
			print m,mat.name,matID
			#if 'blood' not in mat.name and 'ice' not in mat.name:
			if str(matID) in matList.keys():
					diffuse=matList[str(matID)].diffuse
					if os.path.exists(diffuse)==True:
						if '.xtex' in diffuse.lower():
							xtexfile=open(diffuse,'rb')
							p=BinaryReader(xtexfile)
							texPath=xtexParser(diffuse,p)
							xtexfile.close()
							if texPath is not None:
								mat.diffuse=texPath
								
					normal=matList[str(matID)].normal
					if os.path.exists(normal)==True:
						if '.xtex' in normal.lower():
							xtexfile=open(normal,'rb')
							p=BinaryReader(xtexfile)
							texPath=xtexParser(normal,p)
							xtexfile.close()
							if texPath is not None:
								mat.normal=texPath
			else:
				mat.ZTRANS=True
				
				
				
			for n in range(faceCount):
				mesh.matIDList.append(matID)
		mesh.SPLIT=True			
		g.B(9)
		vertCount=g.i(1)[0]
		skinIndiceList,skinWeightList,vertPosList=[],[],[]
		for m in range(vertCount):
			vertPosList.append(g.f(3))
			groupCount=g.B(1)[0]	
			skinIndiceList.append(g.i(groupCount))
			skinWeightList.append(g.f(groupCount))	
		vertCount=g.i(1)[0]
		for m in range(vertCount):
			id=g.i(1)[0]
			mesh.vertPosList.append(vertPosList[id])
			mesh.skinIndiceList.append(skinIndiceList[id])
			mesh.skinWeightList.append(skinWeightList[id])	
		skin=Skin()
		mesh.skinList.append(skin)
		mesh.TRIANGLE=True	
		mesh.BINDSKELETON='armature'
		mesh.draw()	
	
def xsktParser(filename,g):
	print '-'*10,'xsktParser:',filename
	#g.debug=True
	g.word(8)
	g.B(17)
	g.word(g.H(1)[0]*2)
	g.B(3)
	g.i(2)
	skeleton=Skeleton()
	skeleton.BONESPACE=True
	skeleton.NICE=True
	boneCount=g.i(1)[0]
	for m in range(boneCount):
		#print
		bone=Bone()
		bone.parentID=g.i(1)[0]
		name=g.word(g.H(1)[0]*2)
		bone.name=str(m)
		g.H(1)
		bone.posMatrix=VectorMatrix(g.f(3))
		bone.rotMatrix=QuatMatrix(g.f(4))
		g.f(9)
		flag=g.i(1)[0]
		if flag==1:
			g.seek(60,1)
		elif flag==0:pass	
		else:break	
		skeleton.boneList.append(bone)
	skeleton.BINDMESH=True	
	skeleton.draw()	
	g.tell()
		
def xactParser(filename,g):

	action=Action()
	action.BONESPACE=True
	#action.ARMATURESPACE=True
	action.BONESORT=True
	action.skeleton='armature'
	g.word(8)
	g.B(17)
	g.word(g.H(1)[0]*2)
	g.B(3)
	g.i(2)
	boneCount=g.i(1)[0]
	

	for i in range(boneCount):
		animflag=g.B(1)[0]
		bone=ActionBone()
		bone.name=str(i)
		if animflag==1:
			A=g.B(11)
			posFlag=A[8]
			rotFlag=A[9]
			if posFlag==1:
				for m in range(A[4]):
					bone.posFrameList.append(m*2+1)
					bone.posKeyList.append(VectorMatrix(g.f(3)))
			if rotFlag==1:		
				for m in range(A[4]):
					bone.rotFrameList.append(m*2+1)
					bone.rotKeyList.append(QuatMatrix(g.f(4)).resize4x4())
					
		bone.posFrameList.append(0)
		bone.posKeyList.append(VectorMatrix(g.f(3)))
		bone.rotFrameList.append(0)
		bone.rotKeyList.append(QuatMatrix(g.f(4)).resize4x4())
		g.f(3)
		g.B(4)
		action.boneList.append(bone)	
	g.f(4)		
	action.draw()
	action.setContext()
			
	
def xchrParser(filename,g):
	print '-'*10,'xchrParser:',filename
	g.B(25)
	g.word(g.H(1)[0]*2)
	g.seek(195,1)
	a=g.i(1)[0]
	for m in range(a):
		b=g.i(1)[0]
		g.B(13)
		g.word(g.H(1)[0]*2)
		if b==1:
			g.seek(56,1)
		if b==2:
			g.seek(56,1)
		if b==3:	
			g.seek(56,1)
			g.word(g.H(1)[0]*2)
			g.word(g.H(1)[0]*2)
	g.i(2)		
	xsktFile=g.word(g.H(1)[0]*2)
	g.tell()
		
	xsktPath=os.path.dirname(filename)+os.sep+xsktFile
	if os.path.exists(xsktPath)==True:
		xsktfile=open(xsktPath,'rb')
		p=BinaryReader(xsktfile)
		xsktParser(xsktPath,p)
		xsktfile.close()
		
	g.H(3)		
	xskinFile=g.word(g.H(1)[0]*2)
	g.tell()
		
	xskinPath=os.path.dirname(filename)+os.sep+xskinFile
	if os.path.exists(xskinPath)==True:
		xskinfile=open(xskinPath,'rb')
		p=BinaryReader(xskinfile)
		xskinParser(xskinPath,p)
		xskinfile.close()
		
def nlsParser(filename,file):
	print '-'*10,'nlsParser'
	global matList
	
	lines=file.readlines()
	new=open(filename.replace('.nls','utf8.nls'),'w')
	for line in lines:new.write(line.replace('\x00',''))
	new.close()
	
	new=open(filename.replace('.nls','utf8.nls'),'r')	
	xml=Xml()
	xml.input=new
	xml.parse()	
	new.close()
	os.remove(filename.replace('.nls','utf8.nls'))
	root=xml.root
	
	TexReplaceCount=xml.get(root,'TexReplaceCount')
	texCount=int(TexReplaceCount.values)
	matList={}
	for m in range(texCount):
		data=xml.get(root,'Data-'+str(m))
		File=xml.get(data,'File')
		if len(File.values)>0:
		
			MtlIdx=xml.get(data,'MtlIdx').values
			if MtlIdx not in matList.keys():
				matList[MtlIdx]=Mat()
				
			Texture_Stage=xml.get(data,'Texture_Stage')
			if 	Texture_Stage.values=='0':
				matList[MtlIdx].diffuse=os.path.dirname(filename)+os.sep+File.values
				print MtlIdx,os.path.dirname(filename)+os.sep+File.values
			if 	Texture_Stage.values=='1':
				matList[MtlIdx].normal=os.path.dirname(filename)+os.sep+File.values
	
	BodyFile=xml.get(root,'BodyFile')
	xchrPath=os.path.dirname(filename)+os.sep+BodyFile.values
	if os.path.exists(xchrPath)==True:
		xchrfile=open(xchrPath,'rb')
		g=BinaryReader(xchrfile)
		xchrParser(xchrPath,g)
		xchrfile.close()
	
def Parser():	
	global matList
	matList={}
	filename=input.filename
	print
	print filename
	print
	ext=filename.split('.')[-1].lower()	
	
	if ext=='xskin':
		file=open(filename,'rb')
		g=BinaryReader(file)
		xskinParser(filename,g)
		file.close()
	
	if ext=='xskt':
		file=open(filename,'rb')
		g=BinaryReader(file)
		xsktParser(filename,g)
		file.close()
	
	if ext=='xact':
		file=open(filename,'rb')
		g=BinaryReader(file)
		xactParser(filename,g)
		file.close()
	
	if ext=='xchr':
		file=open(filename,'rb')
		g=BinaryReader(file)
		xchrParser(filename,g)
		file.close()
	
	if ext=='nls':
		file=open(filename,'r')
		nlsParser(filename,file)
		file.close()
 
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
	
	
Blender.Window.FileSelector(openFile,'import','Kingdom Online: nls,xact') 