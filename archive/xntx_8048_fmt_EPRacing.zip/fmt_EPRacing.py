from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Enthusia Professional Racing", ".dat")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)
    noesis.logPopup()
    return 1
       
def noepyCheckType(data):
    bs = NoeBitStream(data)
    if bs.readInt() != 33571664:#PC..
        return 0
    return 1

def noepyLoadModel(data, mdlList):
    bs = NoeBitStream(data)
    offset_submesh = [(i+4) for i in findall(b'\x00\x04\x00\x40', data)]
    
    ctx = rapi.rpgCreateContext()
    
    vbuffer = []
    for x in offset_submesh:
        bs.seek(x)
        vCount, unk = bs.readByte(), bs.readByte()
        if vCount:
            vbuffer = bs.readBytes(vCount*12)
            
            rapi.rpgBindPositionBuffer(vbuffer, noesis.RPGEODATA_FLOAT, 12)
            rapi.rpgCommitTriangles(None, noesis.RPGEODATA_USHORT, len(vbuffer)//12, noesis.RPGEO_POINTS)
            rapi.rpgClearBufferBinds()
        
    mdl = rapi.rpgConstructModel()
    mdlList.append(mdl)
    return 1
    
def findall(p, s):
    i = s.find(p)
    while i != -1:
        yield i
        i = s.find(p, i+1)