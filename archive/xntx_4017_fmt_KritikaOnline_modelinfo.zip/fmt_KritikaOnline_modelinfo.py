from inc_noesis import *
import noesis
import rapi
import os


class Node:
	def __init__(self):
		self.ID=None
		self.name=None		
		self.parent=None#name albo [] albo id albo str
		self.children=[]
		self.parentID=None
		self.key=None
		self.values=None
		self.line=None
		self.chunks=None
		


class Xml():
	def __init__(self):
		self.nodes=[]
		self.input=None
		self.keys=[]
		self.root=None
		self.DRAWCONSOLE=False
		
		
		
	def chunks(self,lineID):
		line = lines[lineID]
		sep = line.split('"')
		chunk_list = {} 
		for id in range(len(sep)):
			m=sep[id]
			if '=' in m:
				chunk_name  = m.split('=')[0].split()[-1]
				chunk_value = sep[id+1]
				chunk_list[chunk_name] = chunk_value
		return chunk_list
		
		
	def tree(self,n,parentNode):
		global lineID
		n+=4
		while(True):
			if lineID >= len(lines):
				break
			line = lines[lineID]
			count_open = line.count('<')
			count_close_1= line.count('/>')
			count_close_2= line.count('</')*2
			eta = count_open-(count_close_1+count_close_2)
			node=Node()
			node.ID=lineID
			node.parentID=parentNode.ID
			node.chunks=self.chunks(lineID)
			node.line=line
			node.key=''
			lineID+=1
			if eta == -1:
				break
			if eta ==1:
				sep = line.split() 
				key = sep[0].split('<')[1]
				key = key.split('>')[0]
				if key not in self.keys:
					self.keys.append(key)
				node.key=key
				self.tree(n,node)	
			if eta ==0:
				if '<' in line:
					sep = line.split() 
					key = sep[0].split('<')[1]
					key = key.split('>')[0]
					node.key=key
					node.values=line.split('>')[1].split('</')[0]
				else:
					node.values=line.strip()					
			parentNode.children.append(node)		
		
	def parse(self):
		global lineID
		global lines
		if self.input is not None:
			lines=self.input.readlines()
			lineID = 0
			node=Node()
			self.root=node
			node.ID=lineID
			node.parentID=-1
			n=0  
			self.tree(n,node)
			
	def nextnode(self,node,key):
		children=node.children
		for child in children:
			child.key
			if child.key!=key:self.nextnode(child,key)
			else:list.append(child)			
			
	def find(self,node,key):
		global list
		list=[]
		children=node.children
		for child in children:
			child.key
			if child.key!=key:self.nextnode(child,key)
			else:list.append(child)
		return list	
			
	def get(self,node,key):
		global list
		list=[]
		children=node.children
		for child in children:
			child.key
			if child.key!=key:self.nextnode(child,key)
			else:list.append(child)				
		if len(list)==0:
			return None
		else:	
			return list[0]		


def registerNoesisTypes():
	handle = noesis.register("KritikaOnline", ".modelinfo")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadModel(handle, noepyLoadModel)
	return 1

def noepyCheckType(data):
	return 1


def meshParser(filename,g):
	g.read('14i')
	noeStrFromBytes(g.readBytes(g.read('i')[0]))
	w=g.read('13i')
	mesh=Mesh()
	mesh.indiceList=g.readBytes(w[1]*2)
	if w[3]==1:g.read('3i');mesh.vertPosList=g.readBytes(w[0]*12)
	if w[4]==1:g.read('3i');mesh.vertNormList=g.readBytes(w[0]*12)
	if w[5]==1:g.read('3i');[g.read('4f') for i in range(w[0])]
	if w[6]==1:g.read('3i');mesh.vertUVList=g.readBytes(w[0]*8)
	if w[7]==1:g.read('3i');[g.read('2f') for i in range(w[0])]
	if w[8]==1:
		g.read('3i')
		for i in range(w[0]):
			g.read('3i')
			u=g.read('i')[0]
			g.read('3i')
			for j in range(4):	
				if j<u:mesh.skinIndiceList+=noePack('H',g.read('i')[0])
				else:mesh.skinIndiceList+=noePack('H',0)
			g.read('3i')
			for j in range(4):	
				if j<u:mesh.skinWeightList+=noePack('f',g.read('f')[0])
				else:mesh.skinWeightList+=noePack('f',0)
		g.read('3i')
		for i in range(w[9]):
			g.read('3i')
			matrix=NoeMat44.fromBytes(g.readBytes(64)).toMat43()
		
	rapi.rpgBindPositionBufferOfs(mesh.vertPosList, noesis.RPGEODATA_FLOAT,12,0)
	rapi.rpgBindUV1BufferOfs(mesh.vertUVList, noesis.RPGEODATA_FLOAT,8,0)
	
	if len(mesh.skinIndiceList)>0 and len(mesh.skinWeightList)>0:
		rapi.rpgBindBoneIndexBuffer(mesh.skinIndiceList, noesis.RPGEODATA_USHORT,8,4)
		rapi.rpgBindBoneWeightBuffer(mesh.skinWeightList, noesis.RPGEODATA_FLOAT,16,4)
	texName=mat.diffuse
	if texName is None:texName='empty'
	rapi.rpgSetMaterial(texName)
	rapi.rpgCommitTriangles(mesh.indiceList, noesis.RPGEODATA_USHORT,w[1],noesis.RPGEO_TRIANGLE,1)
	
			
class Mesh():
	
	def __init__(self):
		self.vertPosList=bytes()
		self.vertNormList=bytes()		
		self.indiceList=bytes()
		self.skinWeightList=bytes()
		self.skinIndiceList=bytes()
		
class Mat:
	def __init__(self):
		self.name=None		
		self.diffuse=None
		self.normal=None
		self.specular=None
		
	
class Bone:
	def __init__(self):
		self.ID=None
		self.name=None
		self.parentID=None
		self.parentName=None
		self.matrix=None
		self.children=[]
	


class Skeleton:
	def __init__(self):
		self.boneList=[]
		self.boneNameList=[] 
	
def boneParser(g):
	skeleton=Skeleton()
	u=g.read('8i')
	t=g.tell()
	if u[0]==1040676:
		g.read('4i')
		sum=12
		while(True):
			bone=Bone()
			len=g.read('i')[0]
			bone.name=noeStrFromBytes(g.readBytes(len).replace(b'\x00',b''))
			g.read('i')[0]
			sum+=len+8	
			skeleton.boneList.append(bone)
			if sum==u[7]:break
		g.seek(t+u[7])
		g.tell()
		w=g.read('5i')
		sum=12
		while(True):
			bone=skeleton.boneList[(sum-12)//116]
			matrix=NoeMat44()
			v=g.read('5i')
			g.read('2i')
			matrix[0]=g.read('4f')
			g.read('2i')
			matrix[1]=g.read('4f')
			g.read('2i')
			matrix[2]=g.read('4f')
			g.read('2i')
			matrix[3]=g.read('4f')
			sum+=116
			bone.matrix=matrix.toMat43()
			if sum==w[1]:break
		w=g.read('5i')
		sum=12
		while(True):
			bone=skeleton.boneList[(sum-12)//12]
			v=g.read('3i')
			bone.parentID=v[2]
			sum+=12	
			if sum==w[1]:break
		g.tell()			
			
	
	elif u[0]==1040678:
		g.seek(u[1])
		u=g.read('8i')
		nameOffset=None
		transOffset=None
		parentOffset=None
		for i in range(u[7]):
			w=g.read('5i')
			back=g.tell()
			g.seek(w[3])
			if w[4]==0:
				g.read('3i')
				nameOffset=g.tell()
			if w[4]==1:
				g.read('3i')
				transOffset=g.tell()
			if w[4]==2:
				g.read('3i')
				parentOffset=g.tell()
			g.seek(back)
		u=g.read('5i')
		if nameOffset is not None:
			g.seek(nameOffset)
			for i in range(u[4]):
				bone=Bone()
				len=g.read('i')[0]
				bone.name=noeStrFromBytes(g.readBytes(len).replace(b'\x00',b''))
				skeleton.boneList.append(bone)
		if transOffset is not None:
			g.seek(transOffset)
			for i in range(u[4]):
				bone=skeleton.boneList[i]
				g.read('3i')
				matrix=NoeMat44.fromBytes(g.readBytes(64)).toMat43()
				bone.matrix=matrix
		if parentOffset is not None:
			g.seek(parentOffset)
			for i in range(u[4]):
				bone=skeleton.boneList[i]
				bone.parentID=g.read('i')[0]
		g.tell()
	else:
		print ('bone file not supported:',u[0])
	for m,bone in enumerate(skeleton.boneList):		
		bone=NoeBone(m,bone.name,bone.matrix,None,bone.parentID)
		boneList.append(bone)
		
	
def meshInfoParser(filename,g):
	global mat
	
	g.seek(2)
	data=g.readBytes(g.dataSize-2).replace(b'\x00',b'')
	new=open(filename+'.txt','wb')
	new.write(data)
	new.close()
	
	xml=Xml()
	xml.input=open(filename+'.txt','r')
	xml.parse()
	MeshInfoList=xml.find(xml.root,'MeshInfo')
	for MeshInfo in MeshInfoList:
		
		
		textureFilename=xml.get(MeshInfo,'Texture')
		chunks=textureFilename.chunks
		textureFile=chunks['value']
		texturePath=os.path.dirname(filename)+os.sep+textureFile
		texturePath=texturePath.replace(os.sep,'/')
		mat=Mat()
		if os.path.exists(texturePath)==True:
			mat.diffuse=texturePath
		
		meshFilename=xml.get(MeshInfo,'Filename')
		chunks=meshFilename.chunks
		meshFile=chunks['value']
		
		meshPath=os.path.dirname(filename)+os.sep+meshFile
		if (rapi.checkFileExists(meshPath)):
			meshData = rapi.loadIntoByteArray(meshPath)
			p = NoeBitStream(meshData)	
			meshParser(meshPath,p)
		
	
def modelParser(g):
	global meshList
	meshList=[]
	
	
	g.seek(2)
	data=g.readBytes(g.dataSize-2).replace(b'\x00',b'')
	new=open(rapi.getInputName()+'.txt','wb')
	new.write(data)
	new.close()
	
	xml=Xml()
	xml.input=open(rapi.getInputName()+'.txt','r')
	xml.parse()
	ModelInfoList=xml.find(xml.root,'ModelInfo')
	for ModelInfo in ModelInfoList:
		SkeletonFilename=xml.get(ModelInfo,'SkeletonFilename')
		chunks=SkeletonFilename.chunks
		skeletonFile=chunks['value']
		
		skeletonPath=os.path.dirname(rapi.getInputName())+os.sep+skeletonFile
		if (rapi.checkFileExists(skeletonPath)):
			skeletonData = rapi.loadIntoByteArray(skeletonPath)
			p = NoeBitStream(skeletonData)	
			boneParser(p)
		
		DefaultMesh=xml.get(ModelInfo,'DefaultMesh')
		itemList=xml.find(DefaultMesh,'item')
		for item in itemList:
			chunks=item.chunks
			MeshInfoFile=chunks['value']
			
			MeshInfoPath=os.path.dirname(rapi.getInputName())+os.sep+MeshInfoFile
			if (rapi.checkFileExists(MeshInfoPath)):
				meshInfoData = rapi.loadIntoByteArray(MeshInfoPath)
				p = NoeBitStream(meshInfoData)	
				meshInfoParser(MeshInfoPath,p)


	
	
def noepyLoadModel(data, mdlList):
	global texList,meshList,matList,boneList
	texList=[]
	meshList=[]
	matList=[]
	boneList=[]
	ext=rapi.getInputName().split('.')[-1].lower()
	
	noesis.logPopup()
	
	
	if ext=='modelinfo':
		ctx = rapi.rpgCreateContext()
		g = NoeBitStream(data)	
		modelParser(g)
			
		
	if ext=='mesh':
		sys=Sys(filename)
		bonePath=sys.dir+os.sep+sys.base.split('_')[0]+'.bone'
		if os.path.exists(bonePath)==True:
			file=open(bonePath,'rb')
			g=BinaryReader(file)
			boneParser(bonePath,g)
			file.close()
		
		file=open(filename,'rb')
		g=BinaryReader(file)
		meshParser(filename,g)
		file.close()
		mdl = NoeModel()
	
	mdl = rapi.rpgConstructModel()	
	mdl.setModelMaterials(NoeModelMaterials(texList, matList))
	if len(boneList)>0: 	
		mdl.setBones(boneList)
	mdlList.append(mdl)		
 
	
	return 1 
	