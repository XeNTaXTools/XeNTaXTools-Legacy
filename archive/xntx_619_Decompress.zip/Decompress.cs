using System;
using System.Collections.Generic;
using System.Text;

namespace GWDat
{
    public class Decompress
    {
        private byte[] FileToDecompress = null;
        private Int32 ArraySize;
        private Int32 OriginalFileSize;
        UInt32 tmpvarEAX, tmpvarECX, tmpvarEBX, tmpvarEDX, tmpvarEDI;
        Int32 compressedBufferLoc = 8;
        Int32 newcompressedBufferLoc;
        Int32 cntDecompress = 0;
        Int32 newStorageTableSize;
        Int32 originalStorageTableSize;
        uint cx, ax, dx;
        bool boolNotUsed;
        Int32 varEBPminus4, varEBPminus10, varEBPminusC, varEBPminus18, varESIplusC, varESIplus8, varESIplus10;
        Int32 varEBPminus8, varEBPminus14, varEBPplus8;
        Int32 varEBPminus20 = 0x00;
        Int32 varEBPminus1c = 0x00;
        Int32 varEBPminus24 = 0x00;
        Int32 varEBPminus28 = 0x00;
        Int32 varECXplus920 = 0x00;
        Int32 varEDIplus4 = 0x00;
        Int32 varEDIplus8 = 0x00;
        Int32 varEAXplus804 = 0x00;
        Int32 cntSmallArray = 0x00;

        Int32 varEAX, varEBX, varECX, varEDX, varEDI, varESI;
        byte[] buffer = new byte[4];
        byte[] DecompressedData;
        Int32 StorageTablecnt;
        Int32[] StorageTable;
        Int32[] tmpArray;
        Int32[] tmpArray1;
        Int32[] SmallArray = new Int32[0x800];
        Int32[] SmallArray1 = new Int32[0x800];

        UInt32[] TableUsed = new UInt32[14] {0xa0000000, 0x60000000, 0x40000000, 0x20000000, 0x12000000, 0x0C000000, 
                                                 0x07000000, 0x03000000, 0x01600000, 0x00ff0000, 0x00c00000, 0x00b00000, 
                                                 0x00a00000, 0x00000000};

        uint[] TableUsed1 = new uint[14] {0x02, 0x06, 0x0a, 0x12, 0x19, 0x1f, 0x29, 0x39, 0x46, 0x4d, 0x53, 0x57,
                                              0x5F, 0xFF};

        uint[] TableUsed2 = new uint[256] {0x08, 0x09, 0x0A, 0x00, 0x07, 0x0B, 0x0C, 0x06,
                                               0x29, 0x2A, 0xE0, 0x04, 0x05, 0x20, 0x28, 0x2B,
                                               0x2C, 0x40, 0x4A, 0x03, 0x0D, 0x25, 0x26, 0x27,
                                               0x48, 0x49, 0x24, 0x47, 0x4B, 0x4C, 0x69, 0x6A,
                                               0x23, 0x46, 0x60, 0x63, 0x67, 0x68, 0x88, 0x89,
                                               0xA0, 0xE8, 0x01, 0x02, 0x2D, 0x43, 0x44, 0x45,
                                               0x65, 0x66, 0x80, 0x87, 0x8A, 0xA8, 0xA9, 0xC0,
                                               0xC9, 0xE9, 0x0E, 0x4D, 0x64, 0x6B, 0x6C, 0x84,
                                               0x85, 0x8B, 0xA4, 0xA5, 0xAA, 0xC8, 0xE5, 0x83,
                                               0x86, 0xA6, 0xA7, 0xC7, 0xCA, 0xE7, 0x22, 0x2E,
                                               0x8C, 0xC4, 0xE4, 0xE6, 0x4E, 0x6D, 0xC6, 0xEC,
                                               0x0F, 0x10, 0x11, 0x8D, 0xAB, 0xAC, 0xCC, 0xEA,
                                               0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19,
                                               0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F, 0x21, 0x2F,
                                               0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37,
                                               0x38, 0x39, 0x3A, 0x3B, 0x3C, 0x3D, 0x3E, 0x3F,
                                               0x41, 0x42, 0x4F, 0x50, 0x51, 0x52, 0x53, 0x54,
                                               0x55, 0x56, 0x57, 0x58, 0x59, 0x5A, 0x5B, 0x5C,
                                               0x5D, 0x5E, 0x5F, 0x61, 0x62, 0x6E, 0x6F, 0x70,
                                               0x71, 0x72, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78,
                                               0x79, 0x7A, 0x7B, 0x7C, 0x7D, 0x7E, 0x7F, 0x81,
                                               0x82, 0x8E, 0x8F, 0x90, 0x91, 0x92, 0x93, 0x94,
                                               0x95, 0x96, 0x97, 0x98, 0x99, 0x9A, 0x9B, 0x9C,
                                               0x9D, 0x9E, 0x9F, 0xA1, 0xA2, 0xA3, 0xAD, 0xAE,
                                               0xAF, 0xB0, 0xB1, 0xB2, 0xB3, 0xB4, 0xB5, 0xB6,
                                               0xB7, 0xB8, 0xB9, 0xBA, 0xBB, 0xBC, 0xBD, 0xBE,
                                               0xBF, 0xC1, 0xC2, 0xC3, 0xC5, 0xCB, 0xCD, 0xCE,
                                               0xCF, 0xD0, 0xD1, 0xD2, 0xD3, 0xD4, 0xD5, 0xD6,
                                               0xD7, 0xD8, 0xD9, 0xDA, 0xDB, 0xDC, 0xDD, 0xDE,
                                               0xDF, 0xE1, 0xE2, 0xE3, 0xEB, 0xED, 0xEE, 0xEF,
                                               0xF0, 0xF1, 0xF2, 0xF3, 0xF4, 0xF5, 0xF6, 0xF7,
                                               0xF8, 0xF9, 0xFA, 0xFB, 0xFC, 0xFD, 0xFE, 0xFF };

        uint[] TableUsed3 = new uint[0x194] {  0x18, 0x18, 0x18, 0x18, 0x19, 0x19, 0x19, 0x19, 
                                               0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 
                                               0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 
                                               0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 0x19, 
                                               0x19, 0x19, 0x19, 0x19, 0x1A, 0x1A, 0x1A, 0x1A, 
                                               0x1A, 0x1A, 0x1A, 0x1A, 0x1A, 0x1A, 0x1A, 0x1A, 
                                               0x1A, 0x1A, 0x1A, 0x1A, 0x1A, 0x1A, 0x1A, 0x1A, 
                                               0x1A, 0x1A, 0x1A, 0x1A, 0x1A, 0x1A, 0x1A, 0x1A, 
                                               0x1A, 0x1A, 0x1A, 0x1A, 0x1B, 0x1B, 0x1B, 0x1B, 
                                               0x1B, 0x1B, 0x1B, 0x1B, 0x1B, 0x1B, 0x1B, 0x1B, 
                                               0x1B, 0x1B, 0x1B, 0x1B, 0x1B, 0x1B, 0x1B, 0x1B, 
                                               0x1B, 0x1B, 0x1B, 0x1B, 0x1B, 0x1B, 0x1B, 0x1B, 
                                               0x1B, 0x1B, 0x1B, 0x1C, 0x00, 0x00, 0x00, 0x00, 
                                               0x01, 0x01, 0x02, 0x02, 0x03, 0x03, 0x04, 0x04, 
                                               0x05, 0x05, 0x06, 0x06, 0x07, 0x07, 0x08, 0x08, 
                                               0x09, 0x09, 0x0A, 0x0A, 0x0B, 0x0B, 0x0C, 0x0C, 
                                               0x0D, 0x0D, 0x0E, 0x0E, 0x00, 0x00, 0x00, 0x00, 
                                               0x00, 0x00, 0x00, 0x00, 0x01, 0x01, 0x01, 0x01, 
                                               0x02, 0x02, 0x02, 0x02, 0x03, 0x03, 0x03, 0x03, 
                                               0x04, 0x04, 0x04, 0x04, 0x05, 0x05, 0x05, 0x05, 
                                               0x06, 0x06, 0x06, 0x06, 0x07, 0x07, 0x07, 0x07, 
                                               0x08, 0x08, 0x08, 0x08, 0x09, 0x09, 0x09, 0x09, 
                                               0x0A, 0x0A, 0x0A, 0x0A, 0x0B, 0x0B, 0x0B, 0x0B, 
                                               0x0C, 0x0C, 0x0C, 0x0C, 0x0D, 0x0D, 0x0D, 0x0D, 
                                               0x0E, 0x0E, 0x0E, 0x0E, 0x0F, 0x0F, 0x0F, 0x0F, 
                                               0x10, 0x10, 0x10, 0x10, 0x11, 0x11, 0x11, 0x11, 
                                               0x12, 0x12, 0x12, 0x12, 0x13, 0x13, 0x13, 0x13, 
                                               0x14, 0x14, 0x14, 0x14, 0x15, 0x15, 0x15, 0x15, 
                                               0x16, 0x16, 0x16, 0x16, 0x17, 0x17, 0x17, 0x17, 
                                               0x18, 0x18, 0x18, 0x18, 0x19, 0x19, 0x19, 0x19, 
                                               0x1A, 0x1A, 0x1A, 0x1A, 0x1B, 0x1B, 0x1B, 0x1B, 
                                               0x1C, 0x1C, 0x1C, 0x1C, 0x1D, 0x1D, 0x1D, 0x1D, 
                                               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                                               0x01, 0x01, 0x01, 0x01, 0x02, 0x02, 0x02, 0x02, 
                                               0x03, 0x03, 0x03, 0x03, 0x04, 0x04, 0x04, 0x04, 
                                               0x05, 0x05, 0x05, 0x05, 0x00, 0x00, 0x00, 0x00, 
                                               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xA0, �
                                               0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x60, 
                                               0x06, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x40, 
                                               0x0A, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x20, 
                                               0x12, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x12, 
                                               0x19, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x0C, 
                                               0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x07, 
                                               0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x03, 
                                               0x39, 0x00, 0x00, 0x00, 0x00, 0x00, 0x60, 0x01, 
                                               0x46, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF0, 0x00, 
                                               0x4D, 0x00, 0x00, 0x00, 0x00, 0x00, 0xC0, 0x00, 
                                               0x53, 0x00, 0x00, 0x00, 0x00, 0x00, 0xB0, 0x00, 
                                               0x57, 0x00, 0x00, 0x00, 0x00, 0x00, 0xA0, 0x00, 
                                               0x5F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
                                               0xFF, 0x00, 0x00, 0x00};
        
        uint[] TableUsed4 = new uint[0x1DC] {  0x80, 0x80, 0x80, 0x80,
                                               0x80, 0x80, 0x80, 0x99, 0x89, 0x80, 0x80, 0x40,
                                               0x80, 0x40, 0x55, 0x80, 0x42, 0x80, 0x80, 0x50,
                                               0x80, 0x98, 0x80, 0x42, 0x80, 0x52, 0x80, 0x80,
                                               0x80, 0x80, 0x80, 0x80, 0x55, 0x88, 0x42, 0x80,
                                               0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80,
                                               0x5A, 0x80, 0x80, 0x52, 0x80, 0x80, 0x80, 0x80,
                                               0x92, 0x80, 0x80, 0x40, 0x80, 0x42, 0x80, 0x55,
                                               0x80, 0x40, 0x5A, 0x80, 0x80, 0x80, 0x80, 0x80,
                                               0x40, 0x80, 0x80, 0x80, 0x80, 0x80, 0x99, 0x99,
                                               0x80, 0x80, 0x89, 0x88, 0x40, 0x40, 0x99, 0x80,
                                               0x8A, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x90,
                                               0x90, 0x90, 0x90, 0x99, 0x9A, 0x99, 0x84, 0x98,
                                               0x80, 0x80, 0x9A, 0x99, 0x80, 0x80, 0x99, 0x80,
                                               0x99, 0x80, 0x80, 0x80, 0x80, 0x80, 0x9A, 0x80,
                                               0x80, 0x80, 0x8A, 0x99, 0x80, 0x80, 0x80, 0x80,
                                               0x80, 0x80, 0x80, 0x40, 0x40, 0x80, 0x80, 0x40,
                                               0x40, 0x40, 0x40, 0x40, 0x40, 0x40, 0x40, 0x40,
                                               0x40, 0x95, 0x80, 0x80, 0x91, 0x90, 0x80, 0x80,
                                               0x92, 0x99, 0x80, 0x80, 0x80, 0x40, 0x40, 0x40,
                                               0x99, 0x8A, 0x80, 0x40, 0x4A, 0x80, 0x80, 0x80,
                                               0x80, 0x80, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00,
                                               0x05, 0x00, 0x00, 0x00, 0x07, 0x00, 0x00, 0x00,
                                               0x0B, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00,
                                               0x05, 0x00, 0x00, 0x00, 0x07, 0x00, 0x00, 0x00,
                                               0x00, 0x00, 0x01, 0x00, 0x02, 0x00, 0x03, 0x00,
                                               0x04, 0x00, 0x06, 0x00, 0x08, 0x00, 0x0C, 0x00,
                                               0x10, 0x00, 0x18, 0x00, 0x20, 0x00, 0x30, 0x00,
                                               0x40, 0x00, 0x60, 0x00, 0x80, 0x00, 0xC0, 0x00, 
                                               0x00, 0x01, 0x80, 0x01, 0x00, 0x02, 0x00, 0x03,
                                               0x00, 0x04, 0x00, 0x06, 0x00, 0x08, 0x00, 0x0C,
                                               0x00, 0x10, 0x00, 0x18, 0x00, 0x20, 0x00, 0x30,
                                               0x00, 0x40, 0x00, 0x60, 0x00, 0x01, 0x02, 0x03,
                                               0x04, 0x05, 0x06, 0x07, 0x08, 0x0A, 0x0C, 0x0E,
                                               0x10, 0x14, 0x18, 0x1C, 0x20, 0x28, 0x30, 0x38,
                                               0x40, 0x50, 0x60, 0x70, 0x80, 0xA0, 0xC0, 0xE0,
                                               0xFF, 0x00, 0x00, 0x00, 0x00, 0x01, 0x02, 0x03,
                                               0x04, 0x04, 0x05, 0x05, 0x06, 0x06, 0x06, 0x06,
                                               0x07, 0x07, 0x07, 0x07, 0x08, 0x08, 0x08, 0x08,
                                               0x08, 0x08, 0x08, 0x08, 0x09, 0x09, 0x09, 0x09,
                                               0x09, 0x09, 0x09, 0x09, 0x00, 0x01, 0x02, 0x03,
                                               0x04, 0x05, 0x06, 0x07, 0x08, 0x08, 0x09, 0x09,
                                               0x0A, 0x0A, 0x0B, 0x0B, 0x0C, 0x0C, 0x0C, 0x0C,
                                               0x0D, 0x0D, 0x0D, 0x0D, 0x0E, 0x0E, 0x0E, 0x0E,
                                               0x0F, 0x0F, 0x0F, 0x0F, 0x10, 0x10, 0x10, 0x10,
                                               0x10, 0x10, 0x10, 0x10, 0x11, 0x11, 0x11, 0x11,
                                               0x11, 0x11, 0x11, 0x11, 0x12, 0x12, 0x12, 0x12,
                                               0x12, 0x12, 0x12, 0x12, 0x13, 0x13, 0x13, 0x13,
                                               0x13, 0x13, 0x13, 0x13, 0x14, 0x14, 0x14, 0x14,
                                               0x14, 0x14, 0x14, 0x14, 0x14, 0x14, 0x14, 0x14,
                                               0x14, 0x14, 0x14, 0x14, 0x15, 0x15, 0x15, 0x15,
                                               0x15, 0x15, 0x15, 0x15, 0x15, 0x15, 0x15, 0x15,
                                               0x15, 0x15, 0x15, 0x15, 0x16, 0x16, 0x16, 0x16,
                                               0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16,
                                               0x16, 0x16, 0x16, 0x16, 0x17, 0x17, 0x17, 0x17,
                                               0x17, 0x17, 0x17, 0x17, 0x17, 0x17, 0x17, 0x17,
                                               0x17, 0x17, 0x17, 0x17, 0x18, 0x18, 0x18, 0x18,
                                               0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18,                                                0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18,
                                               0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18};


        UInt32[] HuffmanTree  = new UInt32[0x800];
        UInt32[] HuffmanTree2 = new UInt32[0x800];
        UInt32[] HuffmanNode  = new UInt32[0x100];

        public Decompress()
        {
            //empty constructor for now
        }

        public byte[] DecompressFile(byte[] FileToDecompress)
        {
            if (FileToDecompress.Length < 1)
            {
                throw new ArgumentOutOfRangeException();
            }

            this.FileToDecompress = FileToDecompress;

            ArraySize = this.FileToDecompress.Length;

            //Get size of uncompressed file.  It is the last int32 of the File.
            buffer[0] = this.FileToDecompress[ArraySize - 4];
            buffer[1] = this.FileToDecompress[ArraySize - 3];
            buffer[2] = this.FileToDecompress[ArraySize - 2];
            buffer[3] = this.FileToDecompress[ArraySize - 1];

            OriginalFileSize = GWConvert.byte2int32(buffer, 0);

            ArraySize = (ArraySize - 8);  //Don't need those last 8 bytes anymore.

            Int32 MiddleSize = ArraySize >> 2;
            ArraySize = (MiddleSize * 4);  //This isn't really necessary to do; the executable does this as another error check.

            buffer[0] = this.FileToDecompress[0];
            buffer[1] = this.FileToDecompress[1];
            buffer[2] = this.FileToDecompress[2];
            buffer[3] = this.FileToDecompress[3];

            varECX = GWConvert.byte2int32(buffer, 0);
            varEDX = varECX;
            tmpvarEDX = (uint)varEDX >> 0x1c;
            varEDX = (int)tmpvarEDX;
            tmpvarECX = (uint)varECX << 0x04;
            varECX = (int)tmpvarECX;
            varEBPminus10 = varECX;
            //varESIplusC = varEBPminus10;

            buffer[0] = this.FileToDecompress[4];
            buffer[1] = this.FileToDecompress[5];
            buffer[2] = this.FileToDecompress[6];
            buffer[3] = this.FileToDecompress[7];

            varESI = GWConvert.byte2int32(buffer, 0);
            varEAX = varESI;

            tmpvarEAX = (uint)varEAX >> 0x1c;
            varEAX = (int)tmpvarEAX;
            varECX = varEBPminus10 | varEAX;
            tmpvarEDI = (uint)varESI << 0x04;
            varESI = (int)tmpvarEDI;
            varEBPminus10 = varECX;
            varEBPminusC = varESI;

            DecompressedData = new byte[OriginalFileSize]; //Space for our decompressed data

            varEAX = varEBPminus10;
            varECX = varEAX;

            tmpvarECX = (uint)varECX >> 0x1c;
            varEBPminus18 = (int)tmpvarECX;

            varECX = varEBPminusC;
            varEDI = varECX;

            tmpvarEDI = (uint)varEDI >> 0x1c;
            varEDI = (int)tmpvarEDI;
            tmpvarEAX = ((uint)varEAX << 4);
            varEAX = (int)tmpvarEAX;
            varESIplusC = (varEDI | varEAX);

            if (varEAX < 4)
            {
              //load another record
            }
            tmpvarECX = (uint)varECX << 0x04;
            
            varESIplus10 = (int)tmpvarECX;

            varESIplus8 = 0x1c - 0x04;

            labeljumphere:
            boolNotUsed = SetupNodesandTree(0);
            boolNotUsed = SetupNodesandTree(1);

            newcompressedBufferLoc = ArraySize;

            varECX = varESIplus10;
            varEAX = varESIplusC;
            varEDX = varECX;
            varEDI = varEAX;
            tmpvarEDX = (uint)varEDX >> 0x1c;
            varEDX = (int)tmpvarEDX;
            tmpvarEAX = (uint)varEAX << 4;
            varEAX = (int)tmpvarEAX;

            varEDX = varEDX | varEAX;
            varESIplusC = varEDX;
            varEDX = varESIplus8;

            tmpvarEDI = (uint)varEDI >> 0x1c;
            varEDI = (int)tmpvarEDI;

            varEBPminusC = varEDI;

            if (varEDX < 4)
            {

                varEAX = compressedBufferLoc;
                varECX = newcompressedBufferLoc;

                if (varEAX >= varECX)
                {
                    goto label56fd58;
                }

                buffer[0] = this.FileToDecompress[compressedBufferLoc];
                buffer[1] = this.FileToDecompress[compressedBufferLoc + 1];
                buffer[2] = this.FileToDecompress[compressedBufferLoc + 2];
                buffer[3] = this.FileToDecompress[compressedBufferLoc + 3];
                varECX = GWConvert.byte2int32(buffer, 0);
                compressedBufferLoc += 4;

                varEDI = varEDX + 0x1c;
                varEAX = varECX;
                varESIplus10 = varECX;
                varEBX = varEAX;
                varECX = varEDI;
                tmpvarEBX = (uint)varEBX >> varECX; //CL
                varEBX = (int)tmpvarEBX;

                varECX = varESIplusC;
                varESIplus8 = varEDI;
                varEDI = varEBPminusC;

                varECX = varECX | varEBX;
                varESIplusC = varECX;

                varECX = 4;
                varECX = varECX - varEDX;
                tmpvarEAX = (uint)varEAX << varECX;  //CL
                varEAX = (int)tmpvarEAX;

                varEBX = 0;
                varESIplus10 = varEAX;
                goto label56fc4e;

            label56fd58:
                varESIplus8 = varEBX;
            }
            else
            {
            //label56fd5e:
                tmpvarECX = (uint)varECX << 0x04;
                varECX = (int)tmpvarECX;
                varEDX = varEDX - 0x04;
                varESIplus10 = varECX;
                varESIplus8 = varEDX;
                goto label56fc4e;
            }
            
            label56fc4e:
            varEAX = varEDI + 1;
            tmpvarEAX = (uint)varEAX << 0x0c;
            varEAX = (int)tmpvarEAX;
            varEDX = varEAX;
            varEAX = varEAX - 1;
            varEBPminusC = varEAX;

            if (varEDX == 0)
            {
                return DecompressedData;
            }
            
            varEBPminusC = varEAX;
            goto label56fd76;
        label56fd74:
            varEBX = 0;
        label56fd76:
            varEAX = cntDecompress;
            varECX = OriginalFileSize;

            if (varEAX >= varECX)
            {
                goto label570173;
            }

            varEAX = varESIplusC;  
            varECX = varEAX;
            tmpvarECX = (uint)varECX >> 0x18;
            varECX = (int)tmpvarECX;

            varEDI = (int)HuffmanTree[varECX * 8];
            varEBX = (int)HuffmanTree[varECX * 8 + 4];
            varECX = varECX * 8; //address
            varEBPminus4 = varEBX;
        
            label56fd08:
            if (varEDI != -1)
            {
                if (varEDI > 20)
                {
                    //Throw error
                }

                if (varEDI == 0)
                {
                    goto label56fe34;
                }
            
                varEAX = varESIplus10;
                varEDX = varESIplusC;

                varECX = 0x20;
                varECX = varECX - varEDI;
                tmpvarEAX = (uint)varEAX >> varECX;
                varEAX = (int)tmpvarEAX;
                varECX = varEDI;
                tmpvarEDX = (uint)varEDX << varECX; //CL
                varEDX = (int)tmpvarEDX;
                varEAX = varEAX | varEDX;
                varESIplusC = varEAX;
            label56fe34:
                varEDX = varESIplus8;

                if (varEDI > varEDX)
                {
                    goto label56fe4c;
                }

                varEAX = varESIplus10;
                varECX = varEDI;
                tmpvarEAX = (uint)varEAX << varECX;
                varEAX = (int)tmpvarEAX;

                varEDX = varEDX - varEDI;
                varESIplus8 = varEDX;
                varESIplus10 = varEAX;

                goto label56fe94;

            label56fe4c:
                //load next compressed double word
                varEAX = compressedBufferLoc;
                varECX = ArraySize;

                if (varEAX >= varECX)
                {
                    goto label570173;
                }

                buffer[0] = this.FileToDecompress[compressedBufferLoc];
                buffer[1] = this.FileToDecompress[compressedBufferLoc + 1];
                buffer[2] = this.FileToDecompress[compressedBufferLoc + 2];
                buffer[3] = this.FileToDecompress[compressedBufferLoc + 3];
                varECX = GWConvert.byte2int32(buffer, 0);
                compressedBufferLoc += 4;
                varEAX = varEDX;
                varEAX = varEAX - varEDI;
                varESIplus10 = varECX;
                varECX = varEAX + 0x20;
                varEAX = varESIplus10;
                varEBX = varEAX;
                varEBPminus8 = varECX;
                tmpvarEBX = (uint)varEBX >> varECX;
                varEBX = (int)tmpvarEBX;
                varECX = varESIplusC;
                varECX = varECX | varEBX;
                varEBX = varEBPminus4;
                varESIplusC = varECX;
                varECX = varEDI;
                varECX = varECX - varEDX;
                tmpvarEAX = (uint)varEAX << varECX;
                varEAX = (int)tmpvarEAX;
                varECX = varEBPminus8;
                varESIplus8 = varECX;
                varESIplus10 = varEAX;

            label56fe94:
                if (varEBX < 0x100)
                {
                    varEAX = varEBPplus8; //This is our decompressed array
                    DecompressedData[cntDecompress] = (byte)varEBX;
                    cntDecompress += 1;
                    varEBPplus8 = cntDecompress;
                    varEAX = varEBPminusC;
                    varECX = varEAX;
                    varEAX = varEAX - 1;
                    varEBPminusC = varEAX;

                    if (varECX != 0)
                    {
                        goto label56fd74;
                    }
                }
                else
                {
                    varEAX = 0;
                    varEDX = 0;
                    ax = TableUsed3[varEBX];
                    dx = TableUsed4[varEBX];
                    varEAX = (int)ax;
                    varEDX = (int)dx;
                    varEDI = varEAX;
                    varEBPminus4 = varEDX;

                    if (varEDI == 0)
                    {
                        goto label56ff50;
                    }

                    varEDX = varESIplusC;
                    varEBX = 0x20;
                    varEBX = varEBX - varEDI;
                    varECX = varEBX;
                    tmpvarEDX = (uint)varEDX >> varECX;
                    varEDX = (int)tmpvarEDX;
                    varECX = varEBPminus4;
                    varECX = varECX | varEDX;

                    varEBPminus4 = varECX;

                    if (varEDI > 0x20)
                    {
                        //Throw error
                    }

                    varEDX = varESIplus10;
                    varECX = varEBX;
                    varEBX = varESIplusC;
                    varEAX = varEDX;
                    tmpvarEAX = (uint)varEAX >> varECX;
                    varEAX = (int)tmpvarEAX;
                    varECX = varEDI;
                    tmpvarEBX = (uint)varEBX << varECX;
                    varEBX = (int)tmpvarEBX;
                    varEAX = varEAX | varEBX;
                    varESIplusC = varEAX;
                    varEAX = varESIplus8;

                    if (varEDI > varEAX)
                    {
                        goto label56ff0e;
                    }

                    tmpvarEDX = (uint)varEDX << varECX;
                    varEDX = (int)tmpvarEDX;

                    varEAX = varEAX - varEDI;
                    varESIplus10 = varEDX;
                    goto label56ff4d;

                label56ff0e:
                    varECX = compressedBufferLoc;
                    varEDX = ArraySize;

                    if (varEDX == varECX)
                    {
                        goto label56ff48;
                    }

                    buffer[0] = this.FileToDecompress[compressedBufferLoc];
                    buffer[1] = this.FileToDecompress[compressedBufferLoc + 1];
                    buffer[2] = this.FileToDecompress[compressedBufferLoc + 2];
                    buffer[3] = this.FileToDecompress[compressedBufferLoc + 3];
                    varEDX = GWConvert.byte2int32(buffer, 0);
                    compressedBufferLoc += 4;
                    varECX = varEAX;
                    varECX = varECX - varEDI;
                    varEBX = varEDX;
                    varECX = varECX + 0x20;
                    varESIplus10 = varEDX;
                    tmpvarEBX = (uint)varEBX >> varECX;
                    varEBX = (int)tmpvarEBX;
                    varEBPminus8 = varECX;
                    varECX = varESIplusC;
                    varECX = varECX | varEBX;
                    varESIplusC = varECX;
                    varECX = varEDI;
                    varECX = varECX - varEAX;
                    tmpvarEDX = (uint)varEDX << varECX;
                    varEDX = (int)tmpvarEDX;
                    varESIplus10 = varEDX;
                    varEDX = varEBPminus8;
                    varESIplus8 = varEDX;
                    goto label56ff50;
                label56ff48:
                    varEAX = 0;
                    varESIplus10 = varEAX;
                label56ff4d:
                    varESIplus8 = varEAX;
                label56ff50:
                    varEAX = 2; // varEBPminus18;
                    varECX = varEBPminus4;
                    varEDX = varECX + varEAX + 1;
                    varEAX = varESIplusC;
                    varECX = varEAX;
                    varEBPminus1c = varEDX;
                    tmpvarECX = (uint)varECX >> 0x18;
                    varECX = (int)tmpvarECX;

                    varEDI = (int)HuffmanTree2[varECX * 8];
                    varEBX = (int)HuffmanTree2[varECX * 8 + 4];
                    varECX = varECX * 8;

                    varEBPminus4 = varEBX;

                    if (varEDI == -1)
                    {
                        varECX = SmallArray1[0x00]; //check this
                        varEDX = 0;

                        if (varEAX < varECX)
                        {
                            while (varEAX < varECX)
                            {
                                varEDX = varEDX + 4;
                                varECX = SmallArray1[varEDX + 0x0c];
                                varEDX = varEDX + 0x0c;
                            }
                        }

                        varECX = SmallArray1[varEDX];
                        varEDI = SmallArray1[varEDX + 8];
                        varEAX = varEAX - varECX;
                        varEBX = SmallArray1[varEDX + 4];
                        varECX = 0x20;
                        varECX = varECX - varEDI;
                        tmpvarEAX = (uint)varEAX >> varECX;
                        varEAX = (int)tmpvarEAX;
                        varEBX = varEBX - varEAX;
                        varEAX = varEBPminus20;
                        if (varEBX > varEAX)
                        {
                            //Throw Error
                        }

                        varEBX = tmpArray1[varEBX * 4];
                        varEBPminus4 = varEBX;

                        if (varEDI > 0x20)
                        {
                            //Throw error
                        }

                        goto labeljump;
                    }

                    if (varEDI > 20)
                    {
                        //Throw error
                    }

                    if (varEDI == 0)
                    {
                        goto label570007;
                    }

                    varEAX = varESIplus10;
                    varEDX = varESIplusC;
                    varECX = 0x20;
                    varECX = varECX - varEDI;
                    tmpvarEAX = (uint)varEAX >> varECX;
                    varEAX = (int)tmpvarEAX;
                    varECX = varEDI;
                    tmpvarEDX = (uint)varEDX << varECX;
                    varEDX = (int)tmpvarEDX;
                    varEAX = varEAX | varEDX;

                    varESIplusC = varEAX;
                label570007:
                    varEDX = varESIplus8;

                    if (varEDI > varEDX)
                    {
                        goto label57001f;
                    }

                    varEAX = varESIplus10;
                    varECX = varEDI;
                    tmpvarEAX = (uint)varEAX << varECX;
                    varEAX = (int)tmpvarEAX;
                    varEDX = varEDX - varEDI;
                    varESIplus8 = varEDX;
                    varESIplus10 = varEAX;
                    goto label570067;

                label570028:
                    if (compressedBufferLoc >= ArraySize)
                    {
                        goto label57005f;
                    }

                    buffer[0] = this.FileToDecompress[compressedBufferLoc];
                    buffer[1] = this.FileToDecompress[compressedBufferLoc + 1];
                    buffer[2] = this.FileToDecompress[compressedBufferLoc + 2];
                    buffer[3] = this.FileToDecompress[compressedBufferLoc + 3];
                    varECX = GWConvert.byte2int32(buffer, 0);
                    compressedBufferLoc += 4;

                    varEAX = varEDX;
                    varEAX = varEAX - varEDI;
                    varESIplus10 = varECX;

                    varECX = varEAX + 0x20;
                    varEAX = varESIplus10;
                    varEBX = varEAX;
                    varEBPminus8 = varECX;
                    tmpvarEBX = (uint)varEBX >> varECX;
                    varEBX = (int)tmpvarEBX;
                    varECX = varESIplusC;
                    varECX = varECX | varEBX;

                    varEBX = varEBPminus4;
                    varESIplusC = varECX;
                    varECX = varEDI;
                    varECX = varECX - varEDX;
                    tmpvarEAX = (uint)varEAX << varECX;
                    varEAX = (int)tmpvarEAX;
                    varECX = varEBPminus8;
                    varESIplus8 = varECX;
                    varESIplus10 = varEAX;

                    goto label570067;

                label57001f:
                    varEAX = compressedBufferLoc;
                    varECX = ArraySize;

                    if (varEAX >= varECX)
                    {
                        goto label57005f;
                    }

                    goto label570028;

                label57005f:
                    varEAX = 0;
                    varESIplus10 = varEAX;
                    varESIplus8 = varEAX;

                label570067:
                    varEAX = 0;
                    varEDX = 0;

                    ax = TableUsed3[varEBX + 0x64];
                    dx = TableUsed4[varEBX * 2 + 0xc4];

                    if (varEBX > 0x0f)
                    {
                        byte[] newbuffer = new byte[4];
                        newbuffer[0] = (byte)TableUsed4[(varEBX * 2 + 0xc4)];
                        newbuffer[1] = (byte)TableUsed4[(varEBX * 2 + 0xc4) + 1];
                        newbuffer[2] = 0x00;
                        newbuffer[3] = 0x00;
                        varEDX = GWConvert.byte2int16(newbuffer, 0);
                    }
                    else
                    {
                        varEDX = (int)dx;

                    }

                    varEAX = (int)ax;
                    varEDI = varEAX;

                    if (varEDI == 0)
                    {
                        goto label570116;
                    }

                    varEAX = varESIplusC;
                    varEBX = 0x20;
                    varEBX = varEBX - varEDI;
                    varECX = varEBX;

                    tmpvarEAX = (uint)varEAX >> varECX;
                    varEAX = (int)tmpvarEAX;
                    varEDX = varEDX | varEAX;

                    varEBPminus4 = varEDX;

                    if (varEDI > 0x20)
                    {
                        //Throw Error
                    }

                    varEDX = varESIplus10;
                    varECX = varEBX;
                    varEBX = varESIplusC;
                    varEAX = varEDX;
                    tmpvarEAX = (uint)varEAX >> varECX;
                    varEAX = (int)tmpvarEAX;
                    varECX = varEDI;
                    tmpvarEBX = (uint)varEBX << varECX;
                    varEBX = (int)tmpvarEBX;
                    varEAX = varEAX | varEBX;
                    varESIplusC = varEAX;
                    varEAX = varESIplus8;

                    if (varEDI > varEAX)
                    {
                        goto label5700d1;
                    }

                    tmpvarEDX = (uint)varEDX << varECX;
                    varEAX = varEAX - varEDI;
                    varESIplus10 = (int)tmpvarEDX;

                    goto label570110;
                label5700d1:
                    varECX = compressedBufferLoc;
                    varEDX = newcompressedBufferLoc;

                    if (varECX >= varEDX)
                    {
                        goto label57010b;
                    }

                    buffer[0] = this.FileToDecompress[compressedBufferLoc];
                    buffer[1] = this.FileToDecompress[compressedBufferLoc + 1];
                    buffer[2] = this.FileToDecompress[compressedBufferLoc + 2];
                    buffer[3] = this.FileToDecompress[compressedBufferLoc + 3];
                    varEDX = GWConvert.byte2int32(buffer, 0);
                    compressedBufferLoc += 4;

                    varECX = varEAX;
                    varECX = varECX - varEDI;
                    varEBX = varEDX;

                    varECX = varECX + 0x20;
                    varESIplus10 = varEDX;
                    tmpvarEBX = (uint)varEBX >> varECX;
                    varEBX = (int)tmpvarEBX;
                    varEBPminus8 = varECX;
                    varECX = varESIplusC;
                    varECX = varECX | varEBX;
                    varESIplusC = varECX;
                    varECX = varEDI;
                    varECX = varECX - varEAX;
                    tmpvarEDX = (uint)varEDX << varECX;
                    varEDX = (int)tmpvarEDX;
                    varESIplus10 = varEDX;
                    varEDX = varEBPminus8;
                    varESIplus8 = varEDX;
                    goto label570113;
                label57010b:
                    varEAX = 0;
                    varESIplus10 = varEAX;
                label570110:
                    varESIplus8 = varEAX;
                label570113:
                    varEDX = varEBPminus4;
                label570116:
                    varECX = varEBPminus1c;
                    varEAX = cntDecompress;
                    varEBX = OriginalFileSize;
                    varEDI = varECX + varEAX;

                    if (varEDI > varEBX)
                    {
                        goto label5701c5;
                    }

                    varEBX = 0;  //Beginning of decompressed buffer
                    varEDI = varEAX;
                    varEDI = varEDI - varEBX;

                    if (varEDX >= varEDI)
                    {
                        goto label5701c5;
                    }

                    varEAX = varEAX - varEDX;
                    varEDX = varECX;
                    varEAX = varEAX - 1;
                    varECX = varECX - 1;

                    if (varEDX == 0)
                    {
                        goto label570160;
                    }

                    varEDI = varECX + 1;

                    while (varEDI > 0)
                    {
                        varECX = cntDecompress; 
                        tmpvarEDX = DecompressedData[varEAX];
                        DecompressedData[varECX] = (byte)tmpvarEDX;
                        varECX = varECX + 1;
                        varEAX = varEAX + 1;
                        varEDI = varEDI - 1;
                        cntDecompress = varECX;
                        varEBPplus8 = varECX;
                    }

                label570160:
                    varEAX = varEBPminusC;
                    varECX = varEAX;
                    varEAX = varEAX - 1;

                    if (varECX != 0)
                    {
                        goto label56fd74;
                    }

                    varEBX = 0; //Check this
                    varECX = varEBPminus28;

                    if (varECX != varEBX)
                    {
                      //Call allocate more mem
                    }

                    varEBPminus20 = varEBX;
                    varEBPminus24 = varEBX;

                    goto labeljumphere;
                }
            }
            else
            {
                varECX = SmallArray[0x00];
                varEDX = 0;

                if (varEAX < varECX)
                {
                    while (varEAX < varECX)
                    {
                        varEDX = varEDX + 4;
                        varECX = SmallArray[varEDX + 0x0c];
                        varEDX = varEDX + 0x0c;
                    }
                }

                varECX = SmallArray[varEDX];
                varEDI = SmallArray[varEDX + 8];
                varEAX = varEAX - varECX;
                varEBX = SmallArray[varEDX + 4];
                varECX = 0x20;
                varECX = varECX - varEDI;
                tmpvarEAX = (uint)varEAX >> varECX;
                varEAX = (int)tmpvarEAX;
                varEBX = varEBX - varEAX;
                varEAX = varEDIplus4; 
                if (varEBX > varEAX)
                {
                  //Throw Error
                }

                varEBX = tmpArray[varEBX * 4];
                varEBPminus4 = varEBX;

                if (varEDI > 0x20)
                {
                  //Throw error
                }

                goto labeljump;
            }
            return DecompressedData;
        labeljump:
            goto label56fd08;
        label570173:
            varECX = varEBPminus28;
            return DecompressedData;
        label5701c5:
            varECX = varEBPminus28;
            varEAX = 0;
            return DecompressedData;
        }

        public bool SetupNodesandTree(uint ArrayToProcess)
        {
            //Set up Huffman Nodes and Tree
            varECX = varESIplus10;
            varEAX = varESIplusC;
            
            varEDX = varECX;
            varEDI = varEAX;

            tmpvarEDX = (uint)varEDX >> 0x10;
            varEDX = (int)tmpvarEDX;
            tmpvarEAX = (uint)varEAX << 0x10;
            varEAX = (int)tmpvarEAX;

            varEDX = varEAX | varEDX;

            varEAX = varESIplus8;

            tmpvarEDI = (uint)varEDI >> 0x10;
            varEDI = (int)tmpvarEDI;

            varEBPminus14 = varEDI;
            varESIplusC = varEDX;

            if (varEAX < 0x10) 
            {
                varECX = compressedBufferLoc;
                varEDX = ArraySize;

                if (varECX == varEDX)
                {
                    goto label58829e;  
                }
                buffer[0] = this.FileToDecompress[compressedBufferLoc];
                buffer[1] = this.FileToDecompress[compressedBufferLoc + 1];
                buffer[2] = this.FileToDecompress[compressedBufferLoc + 2];
                buffer[3] = this.FileToDecompress[compressedBufferLoc + 3];
                varEDX = GWConvert.byte2int32(buffer, 0);
                compressedBufferLoc += 4;
                varECX = varEAX + 0x10;
                varEBX = varEDX;
                varEBPplus8 = varECX;
                tmpvarEBX = (uint)varEBX >> varECX;
                varEBX = (int)tmpvarEBX;
                varECX = varESIplusC;
                varESIplus10 = varEDX;
                varECX = varECX | varEBX;
                varESIplusC = varECX;
                varECX = 0x10;
                varECX = varECX - varEAX;
                varEAX = varEBPplus8;
                tmpvarEDX = (uint)varEDX << varECX;
                varEDX = (int)tmpvarEDX;
                varESIplus8 = varEAX;
                varEBX = 0;
                varESIplus10 = varEDX;
                goto label5882a4;
            label58829e:
                varESIplus10 = varEBX;
                varESIplus8 = varEBX;
                goto label5882a4;
            }

            varECX = varESIplus10;
         
            tmpvarECX = (uint)varECX << 0x10;
            varECX = (int)tmpvarECX;
            varEAX = varEAX + (-0x10);

            varESIplus10 = varECX;
            varESIplus8 = varEAX;
  
          label5882a4:
            varEAX = varEDI * 4 + 3;
            varEAX = varEAX - 3;

            //Set up a Huffman node
            if (ArrayToProcess == 0)
            {
                StorageTable = new Int32[varEAX];
                originalStorageTableSize = varEAX;
            }
            else
            {
                newStorageTableSize = varEAX;
            }

            varEDX = 0x80;
            varEBPminus1c = varEBX;
            varECX = varEDX >> 2;

            uint i = 0x80;
            uint cnt = 0x00;
            while (i != 0)
            {
                HuffmanNode[cnt] = 0x00000000;
                i--;
                cnt++;
            }

            i = 0x80;
            while (i != 0)
            {
                HuffmanNode[cnt] = 0xFFFFFFFF;
                i--;
                cnt++;
            }

            varEBX = varEDI - 1;
            varEBPminus10 = varEBX;
            varEBPminus8 = varEBX;

            while (varEBX < varEBPminus14) 
            {
                if (varEBX < 0)
                {
                    bool thiscodereallyworks = ProcessHuffmanTree(ArrayToProcess);
                    return true;
                }

            label1:
                tmpvarEAX = (UInt32)varESIplusC;
                tmpvarECX = TableUsed[0];

                i = 0;
                if (tmpvarEAX < tmpvarECX)
                {
                    while (tmpvarEAX < tmpvarECX)
                    {
                        i++;
                        tmpvarECX = TableUsed[i];
                    }
                }

                tmpvarEAX = tmpvarEAX - TableUsed[i];

                varEDX = (Int32)tmpvarEAX;
                varEAX = (Int32)tmpvarEAX;
                varEDI = varEDX;
                varEDI = (Int32)i * 8; //Size of record.  This is an address subtraction in the exc. 

                varECX = 0x20;
                varEDI = varEDI + 0x18; 
                tmpvarEDI = (uint)varEDI >> 3; // In the exec, this is a SAR instruction.  So, this might need to be changed.
                varEDI = (int)tmpvarEDI;
                varECX = varECX - varEDI;
                tmpvarEAX = (uint)varEAX >> varECX; //This is only supposed to be one byte (CL), so this might need changed later as well.
                varEAX = (int)tmpvarEAX;
                varEBPminus4 = varECX;
                varECX = (Int32)TableUsed1[i];
                varECX = varECX - varEAX; 
                varEAX = 0;

                cx = (uint)varECX; 
                ax = TableUsed2[cx];
                varEBPplus8 = (int)ax; 

                if (varEDI > 0x20)
                {
                    //Throw Error
                }

                if (varEDI < 0)
                {
                    goto labelesiplus8;
                }

                varEDX = varESIplus10;
                varECX = varEBPminus4;
                varEAX = varESIplusC;

                tmpvarEDX = (uint)varEDX >> varECX; //Supposed to be CL; 
                varEDX = (int)tmpvarEDX;
                varECX = varEDI;
                tmpvarEAX = (uint)varEAX << varECX; //CL again.
                varEAX = (int)tmpvarEAX;
                varEDX = varEDX | varEAX;

                varEAX = varEBPplus8; 
                varESIplusC = varEDX;
            labelesiplus8:
                varEDX = varESIplus8; 

                if (varEDI > varEDX)
                {
                    varECX = compressedBufferLoc;

                    if (varECX == ArraySize)
                    {
                        varECX = 0;
                        varESIplus10 = varECX;
                        varESIplus8 = varECX;
                        goto label572c95;
                    }
                    
                    buffer[0] = this.FileToDecompress[compressedBufferLoc];
                    buffer[1] = this.FileToDecompress[compressedBufferLoc + 1];
                    buffer[2] = this.FileToDecompress[compressedBufferLoc + 2];
                    buffer[3] = this.FileToDecompress[compressedBufferLoc + 3];
                    varEAX = GWConvert.byte2int32(buffer, 0);
                    compressedBufferLoc += 4;
                    varECX = varEDX;
                    varECX = (varECX - varEDI) + 0x20;
                    varEBX = varEAX;
                    varESIplus10 = varEAX;
                    tmpvarEBX = (uint)varEBX >> varECX; //CL
                    varEBX = (int)tmpvarEBX;
                    varEBPminus4 = varECX;
                    varECX = varESIplusC;
                    varECX = varECX | varEBX;
                    varEBX = varEBPminus8; 
                    varESIplusC = varECX;
                    varECX = varEDI;
                    varECX = varECX - varEDX;
                    varEDX = varEBPminus4;
                    tmpvarEAX = (uint)varEAX << varECX;
                    varEAX = (int)tmpvarEAX;
                    varESIplus8 = varEDX;
                    varESIplus10 = varEAX;
                    varEAX = varEBPplus8;
                }
                else
                {
                    varEDI = varECX;
                    tmpvarEDI = (uint)varESIplus10 << varECX; //CL again
                    varESIplus10 = (int)tmpvarEDI;

                    varEDX = varEDX - varEDI;
                    varESIplus8 = varEDX;
                }

            label572c95:
                varEDI = varEAX; 
                varEAX = varEAX & 0x1F; 

                tmpvarEDI = (uint)varEDI >> 0x05;
                varEDI = (int)tmpvarEDI;

                varEBPplus8 = varEAX;

                if (varEAX > 0x1F)
                {
                    //Throw error
                }

                if (varEDI > varEBX)
                {
                    varESI = varEBPminusC;
                    varECX = varESI;
                    varEAX = varESI;
                    //call 573190
                    return true;
                }

                if (varEAX < 1)
                {
                    if (varEBPminus14 > 2)
                    {
                        varEAX = varEAX - 1; 
                        varEAX = varEAX - varEDI;
                        varEBX = varEBX + varEAX;
                        varEBPminus8 = varEBX;

                        if (varEBX < 0)
                        {
                            bool irock = ProcessHuffmanTree(ArrayToProcess);
                            return true;
                        }
                        else
                        {
                            continue;
                        }
                    }

                    varEDX = (int)HuffmanNode[varEAX * 4];
                    varECX = varEDI + 1;
                    varEDX = varEDX + varECX;
                    HuffmanNode[varEAX * 4] = (uint)varEDX;
                    varEDX = varEBPminus1c;
                    tmpvarEAX = (uint)((0x100 + (varEAX * 4) - 0x88) - 8);
                    varECX = varEDX + varEDI + 1;
                    varEDX = varEBPminus20;
                    varEBPminus1c = varECX;
                    varEBPminus4 = (int)tmpvarEAX;
                    varECX = varEDX + varEBX * 4;
                    varEBPplus8 = varECX;

                label99:
                    if (varEBX > varEBPminus14)
                    {
                      //Throw Error
                    }

                    varECX = varEBPplus8;
                    
                    varEDX = (int)HuffmanNode[varEAX];
                    HuffmanNode[varECX] = (uint)varEDX;
                    
                    varECX = varECX - 4;
                    HuffmanNode[varEAX] = (uint)varEBX;

                    varEBPplus8 = varECX;
                    varEBX = varEBX - 1;
                    varECX = varEDI;
                    varEDI = varEDI - 1;
                    varEBPminus8 = varEBX;

                    if (varECX == 0)
                    {
                        continue;
                    }

                    if (varEBX == -1)
                    {
                        goto label1;
                    }
                    else
                    {
                        goto label99;
                    }
                }

                varEDX = (int)HuffmanNode[(varEAX * 4)]; 
                varECX = varEDI + 1;

                varEDX = varEDX + varECX;

                HuffmanNode[(varEAX * 4)] = (uint)varEDX;
                varEDX = varEBPminus1c;
                tmpvarEAX = (uint)((varEAX * 4) + 0x80);
                varECX = varEDX + varEDI + 1;

            //label5:
                if (ArrayToProcess == 0)
                {
                    varEDX = 0x00;
                }
                else
                {
                    varEDX = originalStorageTableSize - newStorageTableSize;
                }
                varEBPminus1c = varECX;
                varEBPminus4 = (int)tmpvarEAX;

                StorageTablecnt = (varEBX * 4 + varEDX);
                varEBPplus8 = StorageTablecnt; //varECX
            
            labelEBPminus14:    
                if (varEBX < varEBPminus14)
                    {
                        varECX = varEBPplus8;

                        varEDX = (int)HuffmanNode[tmpvarEAX]; 
                        
                        tmpvarECX = (uint)varEDX;
                        StorageTable[StorageTablecnt] = (int)tmpvarECX;
                        StorageTablecnt = StorageTablecnt - 4;
                       
                        HuffmanNode[tmpvarEAX] = (uint)varEBX; 
                        varEBPplus8 = (int)StorageTablecnt;
                        varEBX = varEBX - 1;
                        varECX = varEDI;
                        varEDI = varEDI - 1;
                        varEBPminus8 = varEBX;

                        if (varECX < 1)
                        {
                            continue;
                        }

                        if (varEBX < 0)
                        {
                            bool thiscodeisgreat = ProcessHuffmanTree(ArrayToProcess);
                        }
                        goto labelEBPminus14;
                    }
                    else
                    {
                        //Throw error
                    }
                varEBX = varEBPminus1c;

                if (varEBX > varEDI)
                {
                    //Throw Error
                }

                if (varEBX == varEDI)
                {
                    varEAX = varEBPminusC;
                    return true;
                }
                else
                {
                    //Do something else
                }
            }
            return true;
        }

        public bool ProcessHuffmanTree(uint ArrayToProcess)
        {

           uint cnt;
           varEBX = varEBPminus10;
           varEDI = varEBPminus14;

            if (varEDI == 0)
            {
                goto label572d12;
            }

            varEAX = varEBPminus1c;
            
            if (varEAX == 0)
            {
                varEAX = varEBPminus20;
                varEDX = 0x80;
                //Huffmantree or node = varEDX;
                varEAX = 1;
                //Huffman tree or node = varEBX;
                //Huffmantree or node = varEAX;
            }

            label572d12:                
            varECX = varEBPminusC; //Huffmantree pointer
            varEDX = 0x800;

            for (cnt = 0; cnt < 0x800; cnt++)
            {
                if (ArrayToProcess == 0)
                {
                    HuffmanTree[cnt] = 0x00;
                }
                else
                {
                    HuffmanTree2[cnt] = 0x00;
                }
            }

            varESI = 0;
            varEDI = 0;
            varEDX = 0;

            varECX = 0x80;

            varEBPplus8 = varESI;
            varEBPminus24 = varEDI;
            varEBPminus8 = varEDX;
            varEBPminus4 = 8;
            varEBPminus18 = varECX;
            goto label572ed8;

            label3:
            varEDX = varEBPminus8;
            label572ed8:
            varEAX = varEBPminus18;
            
            varEBX = (int)HuffmanNode[varEAX];
                        
            if (varEBX < 0)
            {
                goto label2;
            }

            varEAX = 1;
            varECX = varESI;
            tmpvarEAX = (uint)varEAX << varECX;
            varEAX = (int)tmpvarEAX;
                            
            varEBPminus10 = varEAX;

            label6:
 
            if (varEAX < varEDX)
            {
                varESI = varEBPminusC;
                varECX = varESI;
                //call 573070
                varEAX = varESI;
                return false;
            }

            if (varEBX > varEBPminus14)
            {
                varESI = varEBPminusC;
                varECX = varESI;
                //call 573070
                varEAX = varESI;
                return false;
            }


            varECX = varEBPminus4;
            
            varEDI = 1;
            
            tmpvarEDI = (uint)varEDI << varECX;
            varEDI = (int)tmpvarEDI;
            varECX = varEDI;
            varEDI = varEDI - 1;

            if (varECX == 0)
            {
                goto label572e3f;
            }

            varECX = 8;
            varECX = varECX - varESI;
            if (varEDX < 0)
            {
                int stopme3 = 0;
            }
            tmpvarEDX = (uint)varEDX << varECX;
            varEDX = (int)tmpvarEDX;
            varEBPminus28 = varEDX;
                            
            label572f20:
            varESI = varEDX;
            varESI = varESI | varEDI;

            if (varESI > 0x100)
            {
                //Throw Error
            }

            varEAX = varEBPminusC;  //Huffman tree base address.  Not actually needed.
            varECX = varEBPplus8;

            if (ArrayToProcess == 0)
            {
                HuffmanTree[varESI * 8] = (uint)varECX;
                HuffmanTree[varESI * 8 + 4] = (uint)varEBX;
            }
            else
            {
                HuffmanTree2[varESI * 8] = (uint)varECX;
                HuffmanTree2[varESI * 8 + 4] = (uint)varEBX;
            }
         
            varEAX = varEDI;
            varEDI = varEDI - 1;

            if (varEAX > 0)
            {
                goto label572f20;
            }

            varEDX = varEBPminus8;
            varEAX = varEBPminus10;
            varESI = varECX;

            label572e3f:                
            varECX = varEBPminus20;

            if (ArrayToProcess == 0)
            {
                varEBX = StorageTable[varEBX * 4];
            }
            else
            {
                varEBX = StorageTable[(originalStorageTableSize - newStorageTableSize) + varEBX * 4];
            }
                            
            varECX = varEBPminus24;
            varECX = varECX + 1;
            varEDX = varEDX - 1;
            varEBPminus24 = varECX;
            varEBPminus8 = varEDX;

            if (varEBX >= 0)
            {
                goto label6;
            }

           
            //label7:
            varEDI = varECX;
            label2:
            
            varEBX = varEBPminus18;
            varECX = varEBPminus4;
            varESI = varESI + 1;
            varEBX = varEBX + 4;
            varECX = varECX - 1;
            varEDX = varEDX + varEDX + 1;
            varEBPplus8 = varESI;
            varEBPminus18 = varEBX;
            varEBPminus4 = varECX;
            varEBPminus8 = varEDX;

            if (varESI <= 8)
            {
                goto label3;
            }

            varEBX = varEBPminus1c;

            if (varEDI > varEBX)
            {
                //Throw Error
            }

            if (varEBX == varEDI)
            {
                varEAX = varEBPminusC;
                return true;
            }

            varECX = 0; //base address of huffman table
            varEBX = varEBX - varEDI;
            varEAX = varEBX;
            varEDI = varECXplus920;
            varEBPminus10 = varEAX;

            if (varEAX >= varEDIplus8)
            {
                goto label572eba;
            }

            varEDIplus8 = varEAX;

            label572eba:
            if (varEAX == varEDIplus4)
            {
                goto label572f2a;
            }

            varEDX = varEAX * 4;
            varEAX = varEDI;

            if (ArrayToProcess == 0)
            {
                tmpArray = new Int32[varEDX];
            }

            varEDX = varEDI;
            varEBX = 0;  //base address of new array
            varEBPminus4 = varEDX;

            if (varEBX != varEDX)
            {
                goto label572f20next;
            }

            varEAX = varEDIplus8;
            tmpvarEAX = (uint)varEAX << 0x02;
            varEAX = (int)tmpvarEAX;
            varEBPminus28 = varEAX;

            varECX = varEAX + varEBX; //varebx is pointer to new array

            //Zero out memory
            varECX = varEDI; 

            if (varECX != 0)
            {
              //Throw Error
            }
        label572f20next:
            varEDX = varEBPminus10;
            varEDI = varEBX;
            varEDIplus4 = varEDX;
            varEAX = varEDX;
        
            label572f2a:

            if (varEDIplus8 >= varEAX)
            {
                goto label572f32;
            }
            
            varEDIplus8 = varEAX;
        label572f32: 
            varEBX = 0;

            if (varESI > 0x1f)
            {
                varEAX = varEBPminusC;
                return true;
            }

            varEAX = (varESI * 4) + 0x80; //Huffman Node
            varEBPminus4 = varEAX;
            varEAX = 0;  //Start of Huffman Table
            varEDX = varEAXplus804;
            varEBPminus18 = varEDX;
            label572f53:
            varECX = varEBPminus4;
            varECX = (int)HuffmanNode[varECX];

            if (varECX < 0)
            {
                goto label573028;
            }

            varESI = varECX;

            if (varESI < 0)
            {
                goto label573023;            
            }

            varECX = varEBPplus8;
            varEDX = 1;
            tmpvarEDX = (uint)varEDX << varECX;
            varEDX = (int)tmpvarEDX;
            varEBPminus10 = varEDX;
            goto label572f99;
        label572f96:
            varEDX = varEBPminus10;
        label572f99:
            varEDI = varEBPminus8;

            if (varEDI > varEDX)
            {
                varECX = varEAX;
                //call 573070
                varEAX = varEBPminusC;
                return false;
            }

            if (varESI > varEBPminus14)
            {
                varECX = varEAX;
                //call 573070
                varEAX = varEBPminusC;
                return false;
            }

            varEDX = varEBPplus8;
            varECX = varEDX - 0x08;
            varEDX = varEDI;
            if (varEDX < 0)
            {
                int stopme3 = 0;
            }
            tmpvarEDX = (uint)varEDX >> varECX;
            varEDX = (int)tmpvarEDX;
            if (ArrayToProcess == 0)
            {

                HuffmanTree[varEDX * 8] = 0xFFFFFFFF;
            }
            else
            {
                HuffmanTree2[varEDX * 8] = 0xFFFFFFFF;
            }

            varECX = varEDIplus4;  

            if (varEBX > varECX)
            {
              //Throw error
            }

            varECX = 0; //beginning of tmparray
            varEDI = varEDI - 1;
            tmpArray[varEBX * 4] = varESI;
            varESI = (int)StorageTable[varESI * 4];
            varEBX = varEBX + 1;
            varEBPminus8 = varEDI;

            if (varESI != -1)
            {
                goto label572f96;
            }

            varEDX = cntSmallArray + 4;
            
        label572ffb:
            varESI = varEBPplus8;
            varECX = 0x20;
            varECX = varECX - varESI;
            varESI = varEDI + 1;
            tmpvarEDI = (uint)varESI << varECX;
            varESI = (int)tmpvarEDI;
            varECX = varEBX - 1;
            varEDX = varEDX + 0x0c;
            cntSmallArray = varEDX;
            
            SmallArray[varEDX - 0x10] = varESI;
            SmallArray[varEDX - 0x0c] = varECX;
            varECX = varEBPplus8;
            SmallArray[varEDX - 0x08] = varECX;
            varESI = varECX;
            goto label57302b;

        label573023:
            varEDI = varEBPminus8;
            goto label572ffb;

        label573028:
            varEDI = varEBPminus8;
        label57302b:
            varECX = varEBPminus4;
            varESI = varESI + 1;
            varECX = varECX + 4;
            varEBPminus4 = varECX;
            varECX = varEDI + varEDI + 1;
            varEBPplus8 = varESI;
            varEBPminus8 = varECX;

            if (varESI <= 0x1f)
            {
                goto label572f53;
            }
            else
            {
                //copy/resize array?
                return true;
            }
      }
    }
  }
        
      
