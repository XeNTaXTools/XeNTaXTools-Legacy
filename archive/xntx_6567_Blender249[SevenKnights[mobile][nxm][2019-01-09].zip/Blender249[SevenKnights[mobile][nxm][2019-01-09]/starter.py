import newGameLib
from newGameLib import *
import Blender	

def parseType(g,n):
	flag=True
	t=g.tell()
	unk,hash,size=g.i(3)
	write(txt,[unk,hash,size],n)
	n+=4
	if unk==1:
		g.i(1)[0]
		localSize=16
		while(True):
			localSize+=parseType(g,n)			
			if localSize>=size:break
		g.seek(t+4+size)
		write(txt,[g.tell()],n)
		print unk,hash,size,g.tell()
	return size	
	
	
def getLoop(hash,size,g,n,model,parentBoneName,parent,localsize):
	parent[hash]=[]
	parent["offset"]=g.tell()
	parentName=parentBoneName
	if hash==1358766115:
		loop1358766115(size,g,n,model,parentName,parent[hash])
	elif hash==1358249996:
		m1=Matrix4x4(g.f(16))
		m2=Matrix4x4(g.f(16))
		m3=Matrix4x4(g.f(16))
		write(txt,m1,n+4)
		write(txt,m2,n+4)
		write(txt,m3,n+4)
		g.f(2)
		#A=g.f(50)
		#write(txt,[A],n+4)
		A=g.B(1)[0]
		#write(txt,[A],n+4)
		A=g.word(g.i(1)[0])
		#print A,parentName
		bone=Bone()
		bone.matrix=m3#.invert()
		bone.parentName=parentName
		bone.name=A
		model.skeleton.boneList.append(bone)
		parentName=A
		write(txt,[A],n)
		
		n+=4	
		while(True):
			count=g.i(1)[0]
			write(txt,[count],n)
			t=g.tell()
			hash1,size1=g.i(2)
			write(txt,[t+8,":",hash1,size1,t+size1],n)
			if size1>=8:
				node={}
				parent[hash].append(node)
				getLoop(hash1,t+size1,g,n,model,parentBoneName,node,size1)
			g.seek(t+size1)
			if g.tell()>=size:break	
		
		
		
	elif hash==1358401564:
		#A=g.B(6)
		#write(txt,[A],0)
		#A=g.word(g.i(1)[0])
		#write(txt,[A],0)
		
		n+=4	
		while(True):
			count=g.i(1)[0]
			write(txt,[count],n)
			t=g.tell()
			hash1,size1=g.i(2)
			write(txt,[t+8,":",hash1,size1,t+size1],n)
			if size1>=8:
				node={}
				parent[hash].append(node)
				getLoop(hash1,t+size1,g,n,model,parentBoneName,node,size1)
			g.seek(t+size1)
			if g.tell()>=size:break	
		
	elif hash==1358315540:
		A=g.i(3)
		write(txt,g.B(localsize-8),n)
		
		
	elif hash==1358311440:
		parentName=loop1358311440(size,g,n,model,parentName,parent[hash])
	elif hash==1358249997:
		loop1358249997(size,g,n,model,parentName,parent[hash])
	elif hash==1358249998:
		loop1358249998(size,g,n,model,parentName,parent[hash])
	elif hash==1358315537:
		loop1358315537(size,g,n,model,parentName,parent[hash])
	elif hash==1358315541:
		loop1358315541(size,g,n,model,parentName,parent[hash])
	elif hash==1358319641:
		loop1358319641(size,g,n,model,parentName,parent[hash])
	else:
		pass#print 'unknow hash:',hash
		write(txt,['XXXXXXXXXXXXXXXXXXXXXXXXXXXXX'],n)
		write(txt,[localsize,g.B(localsize-8)],n)
	return parentName	
	
	
def loop1358319641(offset,g,n,model,parentBoneName,parent):
	unk1,unk2,count=g.i(3)
	write(txt,[unk1,unk2,count],n)
	n+=4	
	for m in range(count):
		t=g.tell()
		hash,size=g.i(2)
		write(txt,[t,':',"hash:",hash,"size:",size,"end offset:",t+size,"end parent offset:",offset],n)
		if size>12:
			node={}
			parent.append(node)
			getLoop(hash,t+size,g,n,model,parentBoneName,node,size)
		g.seek(t+size)
	
def loop1358315541(offset,g,n,model,parentBoneName,parent):
	n+=4
	
	model.mesh=Mesh()	
	model.meshList.append(model.mesh)
	while(True):
		count=g.i(1)[0]
		write(txt,[count],n)
		for m in range(count):
			t=g.tell()
			hash,size=g.i(2)
			write(txt,[t,':',"hash:",hash,"size:",size,"end offset:",t+size,"end parent offset:",offset],n)
			if size>12:
				node={}
				parent.append(node)
				getLoop(hash,t+size,g,n,model,parentBoneName,node,size)
			g.seek(t+size)
		if g.tell()>=offset:break	
		
	
def loop1358315537(offset,g,n,model,parentBoneName,parent):
	unk=g.i(1)
	write(txt,[unk],n)
	n+=4	
	while(True):
		count=g.i(1)[0]
		write(txt,[count],n)
		for m in range(count):
			t=g.tell()
			hash,size=g.i(2)
			write(txt,[t,':',"hash:",hash,"size:",size,"end offset:",t+size,"end parent offset:",offset],n)
			if size>12:
				node={}
				parent.append(node)
				getLoop(hash,t+size,g,n,model,parentBoneName,node,size)
			g.seek(t+size)
		if g.tell()>=offset:break	
	
def loop1358766115(offset,g,n,model,parentBoneName,parent):
	unk,count=g.i(2)
	write(txt,[unk,count],n)
	n+=4	
	for m in range(count):
		t=g.tell()
		hash,size=g.i(2)
		write(txt,[t,':',"hash:",hash,"size:",size,"end offset:",t+size,"end parent offset:",offset],n)
		if size>12:
			node={}
			parent.append(node)
			getLoop(hash,t+size,g,n,model,parentBoneName,node,size)
		g.seek(t+size)
		
	
		
def loop1358311440(offset,g,n,model,parentBoneName,parent):
	unk,count=g.i(2)
	write(txt,[unk,count],n)
	n+=4	
	parentName=parentBoneName	
	while(True):
	#for m in range(count):
		t=g.tell()
		hash,size=g.i(2)
		write(txt,[t,':',"hash:",hash,"size:",size,"end offset:",t+size,"end parent offset:",offset],n)
		if size>12:
			node={}
			parent.append(node)
			parentName=getLoop(hash,t+size,g,n,model,parentName,node,size)
		g.seek(t+size)
		if g.tell()>=offset:break
	write(txt,["parentName:",parentName],n)
	#if g.tell()<g.fileSize()-16:
	#	write(txt,g.i(3),n)
	return 	parentName
	
def loop1358249997(offset,g,n,model,parentBoneName,parent):
	unk=g.i(1)[0]
	write(txt,[unk],n)
	n+=4		
	while(True):
		count=g.i(1)[0]
		write(txt,[count],n)
		for m in range(count):
			t=g.tell()
			hash,size=g.i(2)
			write(txt,[t,':',"hash:",hash,"size:",size,"end offset:",t+size,"end parent offset:",offset],n)
			if size>=8:
				node={}
				parent.append(node)
				getLoop(hash,t+size,g,n,model,parentBoneName,node,size)
			g.seek(t+size)
		if g.tell()>=offset:break	
		
	
def loop1358249998(offset,g,n,model,parentBoneName,parent):
	n+=4	
	while(True):
		count=g.i(1)[0]
		write(txt,[count],n)
		for m in range(count):
			t=g.tell()
			hash,size=g.i(2)
			write(txt,[t,':',"hash:",hash,"size:",size,"end offset:",t+size,"end parent offset:",offset],n)
			if size>=8:
				node={}
				parent.append(node)
				getLoop(hash,t+size,g,n,model,parentBoneName,node,size)
			g.seek(t+size)
		if g.tell()>=offset:break	
		
		
def nxmParser(filename,g):

	count=g.i(1)[0]
	n=0
	class Model:pass
	model=Model()
	model.mesh=None
	model.meshList=[]
	model.skeleton=Skeleton()
	model.skeleton.ARMATURESPACE=True
	model.skeleton.NICE=True
	parentBoneName=None
	root={}
		
	for m in range(count):
		hash,size=g.i(2)
		write(txt,[hash,size],n)
		tm=g.tell()
		#node={}
		getLoop(hash,size,g,n,model,parentBoneName,root,size)
	model.skeleton.draw()
	
	for mesh in model.meshList:
		mesh.TRIANGLE=True
		mesh.BINDSKELETON=model.skeleton.name
		#mesh.draw()
	#print root	
	meshList=[]
	n=0
	def getKeys(node,n):	
		n+=4
		for key in node:
			if key!="offset":
				#print ' '*n,key
				
				if 1358315537 in node:
					mesh=Mesh()
					mesh.skins=[]
					meshList.append(mesh)
					print key
					for item in node[key]:
						print ' '*4,item.keys()
						
						for key1 in item.keys():
							if key1!="offset":
								for item1 in item[key1]:
									print ' '*8,item1.keys()
									if 1358315540 in item1.keys():
										#print item1[1358315540]
										offset=item1['offset']
										g.seek(offset)
										print offset
										A=g.i(5)
										print A
										mat=Mat()
										mat.A=A
										mat.TRIANGLE=True
										mesh.matList.append(mat)
										mat.IDStart=A[3]*3
										mat.IDCount=A[4]*3
				
									
									if 1358315541 in item1.keys():
										#mesh.TRIANGLE=True
										skin=Skin()
										mesh.skinList.append(skin)
										for item in item1[1358315541]:
											#getKeys(item,n)
											print ' '*12,item.keys()
											for key1 in item.keys():
												if key1!="offset":
												#getKeys(item,n)
													for item1 in item[key1]:
														print ' '*16,item1.keys()
														if 1358315544 in item1.keys():
															g.seek(item1["offset"])
															g.B(6)
															g.i(13)
															g.f(21)
															g.B(1)
															g.i(7)
															name=g.word(g.i(1)[0])
															print name
															mat.diffuse=sys.dir+os.sep+name
															if os.path.exists(mat.diffuse)==True:
																mat.ZTRANS=True
															
														if 1369964687 in item1.keys():
															#print item1["offset"]
															g.seek(item1["offset"])
															A=g.i(3)
															for m in range(A[0]/A[2]):
																mesh.vertPosList.append(g.f(3))
															A=g.i(3)
															A=g.i(3)
															for m in range(A[0]/A[2]):
																mesh.vertUVList.append(g.f(2))	
																
															A=g.i(3)
															for m in range(A[0]/A[2]):
																mesh.skinWeightList.append(g.B(A[2]))
														if 1358315540 in item1.keys():
															#print item1["offset"]
															g.seek(item1["offset"])
															A=g.i(3)
															mesh.indiceList=g.H(A[1])
														if 1369964688 in item1.keys():
															g.seek(item1["offset"])
															count=g.i(1)[0]
															B=[]
															for n in range(count):
																skinIndiceList=[]
																A=g.i(3)
																write(txt,A,n)
																#print A
																#b=g.B(A[0])
																#B.append(b)
																for m in range(A[0]/A[2]):
																	skinIndiceList.append(g.B(A[2]))
																mesh.skins.append(skinIndiceList)		
																	
																#break	
															#for n in range(100):
															#	print B[0][n],B[1][n]
					mesh.SPLIT=True	
					print len(mesh.skins)
					for m in range(len(mesh.vertPosList)):
						mesh.skinIDList.append([0]*len(mesh.matList))
						#mesh.skinWeightList.append([])
						mesh.skinIndiceList.append([])
					for m in range(len(mesh.matList)):
						mat=mesh.matList[m]
						for n in range(mat.IDStart,mat.IDStart+mat.IDCount):
							id=mesh.indiceList[n]
						#for n in range(mat.A[1],mat.A[2]):
							mesh.skinIDList[id][m]=1
							mesh.skinIndiceList[id]=mesh.skins[m][id]
					#mesh.boneNameList=model.skeleton.boneNameList	
					#mesh.BINDSKELETON=model.skeleton.name	
					mesh.draw()			
									
				for item in node[key]:
					getKeys(item,n)
					
			
	getKeys(root,n)
	
	
	print g.tell()
	
def Parser(filename):
	global txt,sys
	os.system('cls')
	txt=open("log.txt","w")
	sys=Sys(filename)
	if sys.ext=='nxm':sys.parseFile(nxmParser,'rb',log=0)
	txt.close()
 
 
	
Blender.Window.FileSelector(Parser,'import','.nxm' ) 
	