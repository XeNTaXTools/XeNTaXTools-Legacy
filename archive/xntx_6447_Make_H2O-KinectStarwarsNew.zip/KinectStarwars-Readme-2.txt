
There's a dll required for Make_H2O and a python script for importing multiple obj into blender,
get them from the zip here:
https://forum.xentax.com/viewtopic.php?f=16&t=11436&p=111156&hilit=who+would+request#p111156


Example smf to obj conversion:
------------------------------
- start Make_H2O
- File/open sail_barge.smf

- change 0xDA4 to 0xDB0 in the lower left editbox (refer to picture in post)

- File/open sail_barge.smf AGAIN (yes, prefer to waste your time rather than mine;-)

- Creates 9 H2O files then




 Part3: How to create and import the obj files
-------

If you don't have hex2obj so far be sure to get 0.24d (exe only) AND the 0.24c-zip (dlls) from here:
http://forum.xentax.com/viewtopic.php?f=29&t=10894&p=142434&hilit=+actual#p142434


start Make_H2O.exe and load *.smf. (poorly tested on 3 smf only!)
H2O files should be created.

In hex2obj_0.24d load the model *.smf then choose File "SaveAs Mmesh" (multiple mesh)
to create obj files from all contained submeshes.

After hex2obj processed the H2O files there should exist the same amount of obj files 
in the model's folder named from *_0.obj to *_xx.obj.

When executing load_multi_obj_blender2.69.py in a blender Text Editor window with alt-p
make sure to have set "path_to_obj_dir" to YOUR model directory.

Also be sure that there are no obj files in a maybe contained subdirectory.
(they would be loaded, too)

Best choice would be to have a separate folder for each smf and its obj files.

Keep in mind that x.obj is NOT created from x.H2O! 
First line in an obj reveals its H2O-source.

shak-otay, September 2018