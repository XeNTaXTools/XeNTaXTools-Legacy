from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Marvel Ultimate Alliance 2", ".igz")
	noesis.setHandlerTypeCheck(handle, MUA2CheckType)
	noesis.setHandlerLoadRGBA(handle, MUA2LoadRGBA)
	#noesis.logPopup()
	return 1

def MUA2CheckType(data):
    bs = NoeBitStream(data)
    Magic = bs.readBytes(4).decode("ASCII")
    if Magic != "IGZ\x01":
        return 0
    return 1   

def MUA2LoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.setEndian(NOE_BIGENDIAN)
    bs.seek(0x32, NOESEEK_ABS)
    imgHeadOffs = bs.readShort()    
    bs.seek(imgHeadOffs - 0x1A4, NOESEEK_ABS)
    imgFmt = bs.readBytes(8)
    bs.seek(0x12C, NOESEEK_REL)
    imgWidth = bs.readShort()
    imgHeight = bs.readShort()
    junkSkip = imgHeadOffs + 0x1000
    datasize = len(data) - junkSkip
    bs.seek(junkSkip, NOESEEK_ABS)
    data = bs.readBytes(datasize)
    #diffuse dxt1 and dxt5
    if imgFmt == b'\xb7/i\xd4\xc79H\xbc':
        data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 8)
        texFmt = noesis.NOESISTEX_DXT1
    elif imgFmt == b'\x88\xf4\xd6W?\xf1\xdf\xf0':
        data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 16)
        texFmt = noesis.NOESISTEX_DXT5
	#normal maps
    elif imgFmt == b'\x94\xec\xfd\x01e\xff\xc0\x1b':
        data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 16)
        data = rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_ATI2)
        texFmt = noesis.NOESISTEX_RGBA32
	#unknown, not handled
    else:
        print("WARNING: Unhandled image format")
        return None
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1