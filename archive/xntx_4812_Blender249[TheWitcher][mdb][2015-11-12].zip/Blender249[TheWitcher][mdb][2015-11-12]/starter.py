import newGameLib
from newGameLib import *
import Blender	

def addMesh97(data,name,g,n):
	txt.write('MESH'+'\n')
	var=g.i(4)#;print var,plik.tell()
	
	txt.write(' '*n+str(g.tell())+':'+str(data)+'\n')
	txt.write(' '*n+str(g.tell())+':'+str(var)+'\n')
	
	g.seek(var[2])
	ta=g.tell()
	A=g.i(9)
	txt.write(' '*n+str(ta)+':'+str(A)+'\n')
	mesh=Mesh()
	mesh.bonename=name
	print name,"addMesh97"
	meshList.append(mesh)
	for m in range(11):
		ta=g.tell()
		var = g.i(3);print m,var
		txt.write(' '*n+str(ta)+':'+str(var)+'\n')
		t=g.tell()
		if m==0:#vertex
			g.seek(var[0]+32)
			for i in range(var[1]):
				mesh.vertPosList.append(g.f(3))
			#print plik.tell()
		if m==4:#uv
			g.seek(var[0]+32)
			#print f(10)
			for i in range(var[1]):
				mesh.vertUVList.append(g.f(2))
				#print uvlist[n]
		if m==9:#triangles  
			g.seek(var[0]+32)
			for i in range(var[1]):
				d=g.tell()
				g.seek(d+20)
				mesh.faceList.append(g.i(3))
				g.seek(d+32)
		if m==10:
			g.seek(var[0]+32)
			for m in range(5):
				B=g.i(1)+g.H(4)
				txt.write(str(B)+'\n')
			ta=g.tell()
			B=g.f(17)
			txt.write(' '*n+str(ta)+':'+str(B)+'\n')
			ta=g.tell()
			B=g.i(8)
			txt.write(' '*n+str(ta)+':'+str(B)+'\n')
			ta=g.tell()
			B=g.word(64)
			txt.write(' '*n+str(ta)+':'+str(B)+'\n')
			
			#for i in range(var[1]):
			#	i,g.i(4)  
		g.seek(t)
	#print plik.tell()
	chunk=g.word(4)
	txt.write(chunk+'\n')
	count=g.i(5)#;print 'count',count
	
	txt.write(' '*n+str(count)+'\n')
	
	vert_w=g.i(3)
	vert_i=g.i(3) 
	#print vert_w,vert_i
	
	g.seek(vert_w[0]+32)
	w_count=vert_w[1]/count[0]
	vert_w_list=[]
	for m in range(count[0]):
		mesh.skinWeightList.append(g.f(w_count))
	
	g.seek(vert_i[0]+32)
	i_count=vert_i[1]/count[0]
	vert_i_list=[]
	list=[]
	for m in range(count[0]):
		indiceList=g.b(i_count)
		mesh.skinIndiceList.append(indiceList)
		for indice in indiceList:
			if indice not in list:
				list.append(indice)
	skin=Skin()
	mesh.skinList.append(skin)	
	
		
	g.seek(header[6]+32+A[3])
	#print g.tell()
	wordCount=g.i(1)[0]
	g.i(1)
	mat=Mat()
	mesh.matList.append(mat)
	for m in range(wordCount):
		string=g.find('\x00')
		#print string.strip()
		if 'texture ' in string:
			if 'texture0 ' in string:
				mat.diffuse=g.dirname.replace('_meshes00','_textures00')+os.sep+string.split()[2].strip()+'.dds'
				mat.normal=g.dirname.replace('_meshes00','_textures00')+os.sep+string.split()[2].strip()+'_n.dds'
				#mat.ao=g.dirname.replace('_meshes00','_textures00')+os.sep+string.split()[2].strip()+'_n.dds'
				mat.ZTRANS=True
				if os.path.exists(mat.diffuse)==False:
					mat.diffuse=g.dirname.replace('_localized00','_textures00')+os.sep+string.split()[2].strip()+'.dds'
					
			if 'tex ' in string:
				mat.diffuse=g.dirname.replace('_meshes00','_textures00')+os.sep+string.split()[2].strip()+'.dds'
				mat.normal=g.dirname.replace('_meshes00','_textures00')+os.sep+string.split()[2].strip()+'_n.dds'
				mat.ZTRANS=True	
				if os.path.exists(mat.diffuse)==False:
					mat.diffuse=g.dirname.replace('_localized00','_textures00')+os.sep+string.split()[2].strip()+'.dds'
				
	g.seek(header[6]+32+A[5])
	g.i(1)
	for m in range(A[6]):
		t=g.tell()
		string=g.find('\x00')
		txt.write(string+'\n')
		mesh.boneNameList.append(string)
		g.seek(t+96)
	#print 'bind:',g.tell()
	
def addMesh65537(data,bone,g,n):#speed tree file
		txt.write('MESH'+'\n')
		var=g.i(10)#;print var,plik.tell()
		
		txt.write(' '*n+str(g.tell())+':'+str(var)+'\n')
		
		

def addMesh32769(data,bone,g,n):
		txt.write('MESH'+'\n')
		var=g.i(4)#;print var,plik.tell()
		txt.write(' '*n+str(g.tell())+':'+str(var)+'\n')
		
		mesh=Mesh()
		g.seek(var[0]+32)
		countList=[]
		mat=Mat()
		mesh.matList.append(mat)
		#mat.ZTRANS=True
		stringList=[]
		for m in range(var[1]):
			tm=g.tell()
			txt.write(str(g.i(2))+' ')
			t1=g.tell()
			string=g.find('\00')+'.dds'
			stringList.append(string)
			txt.write(string+' ')
			g.seek(t1+36)
			a=g.i(2)
			countList.append(a[0])
			txt.write(str(a)+'\n')
			g.seek(tm+52)
		if len(stringList)>0:
			mat.diffuse=g.dirname.replace('_meshes00','_textures00')+os.sep+stringList[0]
			if os.path.exists(mat.diffuse)==False:
				mat.diffuse=g.dirname.replace('_meshes00','_textures01')+os.sep+stringList[0]
			
			
		strongList=[]	
		for count in countList:
			strongList.append(g.f(count))
		for id in range(a[1]):
			sum=0
			for list in strongList:
				sum+=list[id]
			#print sum,	
				
		#for m in range(1540):
		#	txt.write(str(g.tell())+':'+str(g.f(4))+'\n')
		ta=g.tell()
		A=g.i(1)
		txt.write(' '*n+str(ta)+':'+str(A)+'\n')
		mesh.bonename=bone.name
		print name
		meshList.append(mesh)
		for m in range(18):
			ta=g.tell()
			var = g.i(3);print m,var
			txt.write(' '*n+str(m)+':'+str(ta)+':'+str(var)+'\n')
			t=g.tell()
			if m==0:#vertex
				g.seek(var[0]+32)
				for i in range(var[1]):
					mesh.vertPosList.append(g.f(3))
				#print plik.tell()
			if m==4:#uv
				g.seek(var[0]+32)
				#print f(10)
				for i in range(var[1]):
					mesh.vertUVList.append(g.f(2))
					#print uvlist[n]
			if m==9:#triangles  
				g.seek(var[0]+32)
				for i in range(var[1]):
					d=g.tell()
					#g.seek(d+20)
					mesh.faceList.append(g.i(3))
					g.seek(d+80)
			if m==11:
				g.seek(var[0]+32)
				for m in range(data[6]):
					B=g.i(1)+g.H(4)
					txt.write(str(B)+'\n')
			g.seek(t)
		
def addMesh33(type,data,name,g,n):
		txt.write('MESH'+'\n')
		
		mesh=Mesh()
		var=g.i(4)
		txt.write(' '*n+str(g.tell()-16)+':'+str(var)+'\n')
		
		R1=g.f(12)
		txt.write(' '*n+str(g.tell()-48)+':'+str(R1)+'\n')
		R2=g.i(6)
		txt.write(' '*n+str(g.tell()-24)+':'+str(R2)+'\n')
		R3=g.f(12)
		txt.write(' '*n+str(g.tell()-48)+':'+str(R3)+'\n')
		R4=g.i(3)
		txt.write(' '*n+str(g.tell()-12)+':'+str(R4)+'\n')
		mat=Mat()
		mat.ZTRANS=True
		mesh.matList.append(mat)
		if R4[0]==1:
			t=g.tell()
			stringA=g.find('\x00')
			g.seek(t+64)
			t=g.tell()
			stringB=g.find('\x00')
			g.seek(t+64)
			txt.write(stringB+'\n')
			#if data[6]==5:
			string=stringB
			#else:string=stringA
			mat.diffuse=g.dirname.replace('_meshes00','_textures00')+os.sep+string+'.dds'
			mat.normal=g.dirname.replace('_meshes00','_textures00')+os.sep+string+'_n.dds'
			#mat.ao=g.dirname.replace('_meshes00','_textures00')+os.sep+string.split()[2].strip()+'_n.dds'
			#mat.ZTRANS=True
			if os.path.exists(mat.diffuse)==False:
				mat.diffuse=g.dirname.replace('_localized00','_textures00')+os.sep+string+'.dds'
			if os.path.exists(mat.diffuse)==False:
				mat.diffuse=g.dirname.replace('_meshes00','_textures01')+os.sep+string+'.dds'

		
		
		g.seek(var[2])
		ta=g.tell()
		A=g.i(9)
		txt.write(' '*n+str(ta)+':'+str(A)+'\n')
		mesh.bonename=name
		print name
		if R4[0]>0:
			meshList.append(mesh)
		n+=4
		for m in range(13):
			ta=g.tell()
			var = g.i(3)#;print m,var
			txt.write(' '*n+str(m)+':'+str(ta)+':'+str(var)+'\n')
			t=g.tell()
			if m==0:#vertex
				g.seek(var[0]+32)
				for i in range(var[1]):
					mesh.vertPosList.append(g.f(3))
			#if type==-1:
			if R4[0]==1:
				if m==57777:#uv
					g.seek(var[0]+32)
					for i in range(var[1]):
						mesh.vertUVList.append(g.f(2))
			#else:
			if m==4:#uv
					g.seek(var[0]+32)
					for i in range(var[1]):
						mesh.vertUVList.append(g.f(2))
				
			if m==9:#triangles  
				g.seek(var[0]+32)
				for i in range(var[1]):
					d=g.tell()
					g.seek(d+20)
					mesh.faceList.append(g.i(3))
					g.seek(d+32)
			if m==10:
				g.seek(var[0]+32)
				for m in range(data[6]):
					B=g.i(1)+g.H(4)
					txt.write(' '*n+str(B)+'\n')
				
			g.seek(t)
			
		if R4[0]==1:
			g.seek(header[6]+32+A[7])
			wordCount=g.i(1)[0]
			off=g.i(1)
			print wordCount,off
			for m in range(wordCount):
				string=g.find('\x00')
				#print string.strip()
				if 'texture ' in string:
					if 'texture0 ' in string:
						mat.diffuse=g.dirname.replace('_meshes00','_textures00')+os.sep+string.split()[2].strip()+'.dds'
						mat.normal=g.dirname.replace('_meshes00','_textures00')+os.sep+string.split()[2].strip()+'_n.dds'
						#mat.ao=g.dirname.replace('_meshes00','_textures00')+os.sep+string.split()[2].strip()+'_n.dds'
						mat.ZTRANS=True
						if os.path.exists(mat.diffuse)==False:
							mat.diffuse=g.dirname.replace('_localized00','_textures00')+os.sep+string.split()[2].strip()+'.dds'
							
					if 'tex ' in string:
						mat.diffuse=g.dirname.replace('_meshes00','_textures00')+os.sep+string.split()[2].strip()+'.dds'
						mat.normal=g.dirname.replace('_meshes00','_textures00')+os.sep+string.split()[2].strip()+'_n.dds'
						mat.ZTRANS=True	
						if os.path.exists(mat.diffuse)==False:
							mat.diffuse=g.dirname.replace('_localized00','_textures00')+os.sep+string.split()[2].strip()+'.dds'
	
def addAnimBoneData(flag,B,g,n,bone):
	n+=4
	txt.write(' '*n+str(g.tell())+':position'+'\n')
	d=g.f(B[0])
	p.i([B[0]])
	p.f(d)
	txt.write(' '*n+str(d)+'\n')
	#bone.posFrameList=d
	for m in range(B[0]):
		d=g.f(3)
		p.f(d)
		txt.write(' '*n+str(d)+'\n')
		#bone.posKeyList.append(VectorMatrix(d))
	txt.write(' '*n+str(g.tell())+':rotation'+'\n')
	if flag==2:
		d=g.f(B[6])
		p.i([B[6]])
		p.f(d)
		txt.write(' '*n+str(d)+'\n')
		#bone.rotFrameList=d
		for m in range(B[6]):
			d=g.f(4)
			p.f(d)
			txt.write(' '*n+str(d)+'\n')
			#bone.rotKeyList.append(QuatMatrix(d).resize4x4())
	if flag==1:
		p.i([0])

def addAnimBone(data,bone,g,n):
		g.seek(data[5]+32)
		flag=g.i(1)[0]
		txt.write(' '*n+str(flag)+'\n')
		if data[6]==2:
			if flag==84:
				B=g.H(10)
				txt.write(' '*n+str(B)+'\n')
				if sectionFlag=='anim':
					g.seek(data[8]+32)
					addAnimBoneData(2,B,g,n,bone)
			if flag==96:
				if sectionFlag=='anim':
					p.i([0,0])
					
		if data[6]==1:
			if flag==84:
				B=g.H(4)
				txt.write(' '*n+str(B)+'\n')
				if sectionFlag=='anim':
					g.seek(data[8]+32)
					addAnimBoneData(1,B,g,n,bone)
			if flag==96:
				if sectionFlag=='anim':
					p.i([0,0])
					
		if data[6]==0:
			if sectionFlag=='anim':
				p.i([0,0])

def addBone(data,bone,g,n):
	txt.write('BONE'+'\n')
	n+=4
	if data[5]!=0 and data[8]!=0:
		g.seek(data[8]+32)
		g.f(1)
		d=g.f(3)
		txt.write(' '*n+str(g.tell()-16)+':position'+'\n')
		txt.write(' '*n+str(d)+'\n')
		bone.posMatrix=VectorMatrix(d)
		g.f(1)
		d=g.f(4)
		txt.write(' '*n+'rotation'+'\n')
		txt.write(' '*n+str(d)+'\n')
		bone.rotMatrix=QuatMatrix(d)

def animTree(parent,n,g):
	C=g.i(8)
	txt.write(' '*n+str(C)+'\n')			
	bone=Bone()
	#skeleton.boneList.append(bone)
	t=g.tell()
	name=g.find('\x00')
	actionFile.write(name+'\x00')
	txt.write(' '*n+str(t)+':'+name+'\n')
	g.seek(t+64)
	t=g.tell()
	A=g.i(17)
	txt.write(' '*n+str(t)+':'+str(A)+'\n')
	g.seek(A[2]+32)
	t=g.tell()
	offList=g.i(A[3])
	txt.write(' '*n+str(t)+':'+str(offList)+'\n')
	n+=4
	if sectionFlag=='anim':
		addAnimBone(A,bone,g,n)
	for off in offList:		
		g.seek(off+32)
		animTree(bone,n,g)
	
		
	
def skeletonTree(parent,n,g):
	C=g.i(8)
	txt.write(' '*n+str(C)+'\n')			
	bone=Bone()
	skeleton.boneList.append(bone)
	if parent is not None:bone.parentName=parent.name
	t=g.tell()
	name=g.find('\x00')[-25:]
	newname=name
	if name in skeleton.nameList:
		newname=name+'_'+str(skeleton.nameList.count(name))
	skeleton.nameList.append(name)
	bone.name=newname
	txt.write(' '*n+str(t)+':'+newname+'\n')
	g.seek(t+64)
	t=g.tell()
	A=g.i(17)
	#print A[2],A[5],A[8],A[15],A[16],newname
	txt.write(' '*n+str(t)+':'+str(A)+'\n')
	
	#if C[0]==8610112:addMesh8610112(A,bone,g,n)#skin
	#if C[0]==8570160:addMesh8610112(A,bone,g,n)#skin
	#if C[0]==8596896:addMesh8610112(A,bone,g,n)#skin
	#if C[0]==8551760:addMesh8551760(A,bone,g,n)#static
	#if C[0]==8512304:addMesh8551760(A,bone,g,n)#static
	#if C[0]==8586720:addMesh8551760(A,bone,g,n)#static
	#if C[0]==8512304:addMesh8551760(A,bone,g,n)#static
	#if C[0]==8512304:addMesh8551760(A,bone,g,n)#static
	if A[-1]==32769:addMesh32769(A,bone,g,n)#static
	if A[-1]==33 and A[15]==-1:addMesh33(-1,A,newname,g,n)#static
	if A[-1]==33 and A[15]==2:addMesh33(2,A,newname,g,n)#static
	if A[-1]==33 and A[15]==5:addMesh33(5,A,newname,g,n)#static
	if A[-1]==97:addMesh97(A,newname,g,n)#static
	if A[-1]==65537:addMesh65537(A,bone,g,n)#static
	#if A[-1]==65537:addMesh32769(A,bone,g,n)#static
		
	g.seek(A[2]+32)
	t=g.tell()
	offList=g.i(A[3])
	txt.write(' '*n+str(t)+':'+str(offList)+'\n')
	n+=4
	addBone(A,bone,g,n)
	for off in offList:		
		g.seek(off+32)
		skeletonTree(bone,n,g)

		
def readAnim(g):
	global actionFile,p
	
	animDir=g.dirname+os.sep+g.basename.split('.')[0]+'_animfiles'
	try:os.makedirs(animDir)
	except:pass
	
	t=g.tell()
	name=g.find('\x00')
	#print name
	actionFile=open(animDir+os.sep+name+'.action','wb')
	p=BinaryReader(actionFile)
	txt.write(name+'\n')
	g.seek(t+64)
	B=g.i(9)
	txt.write(str(B)+'\n')
	c=g.B(4)+g.f(2)
	txt.write(str(c)+'\n')
	t=g.tell()
	name=g.find('\x00')
	txt.write(name+'\n')
	g.seek(t+64)
	a=g.f(7)
	b=g.f(7)
	n=0
	g.seek(B[0]+32)
	animTree(None,n,g)	
	actionFile.close()
		
	
def actionParser(filename,g):
	#g.debug=True
	#g.logOpen()
	action=Action()
	action.BONESPACE=True
	action.BONESORT=True
	action.skeleton='armature'
	while(True):
		if g.tell()>=g.fileSize():break
		bone=ActionBone()
		action.boneList.append(bone)
		bone.name=g.find('\x00')
		posCount=g.i(1)[0]		
		for m in range(posCount):
			bone.posFrameList.append(g.f(1)[0]*33)
		for m in range(posCount):
			bone.posKeyList.append(VectorMatrix(g.f(3)))
		rotCount=g.i(1)[0]		
		for m in range(rotCount):
			bone.rotFrameList.append(g.f(1)[0]*33)
		for m in range(rotCount):
			bone.rotKeyList.append(QuatMatrix(g.f(4)).resize4x4())
	action.draw()
	action.setContext()	
	
	#g.logClose()	
	
def mbaParser(filename,g):
	global txt,sectionFlag
	sectionFlag='anim'
	txt=open(g.dirname+os.sep+'tree.txt','w')
	data=g.read(g.fileSize())
	offsetList=[]
	while(True):
		flag=data.find('\x60\xfa\x88\x00')	
		#print flag,len(data)
		if flag>0:
			data=data[flag+4:]
			offsetList.append(g.fileSize()-len(data))
		else:
			break
	print 'znaleziono anim chunk:',offsetList	
	for offset in offsetList:
		g.seek(offset)		
		readAnim(g)
		
	g.seek(0)
	data=g.read(g.fileSize())
	offsetList=[]
	while(True):
		flag=data.find('\x10\x09\x89\x00')	
		#print flag,len(data)
		if flag>0:
			data=data[flag+4:]
			offsetList.append(g.fileSize()-len(data))
		else:
			break
	print 'znaleziono anim chunk:',offsetList	
	for offset in offsetList:
		g.seek(offset)		
		readAnim(g)
	
	g.seek(0)	
	header=g.i(10)
	g.seek(104)
	g.seek(g.i(1)[0]+32)
	n=0	
	meshList=[]	
	sectionFlag='skeleton'
	skeleton=Skeleton()
	skeleton.BONESPACE=True
	skeleton.NICE=True
	skeletonTree(None,n,g)
	#skeleton.draw()
	for mesh in meshList:
		#mesh.boneNameList=skeleton.boneNameList
		mesh.BINDSKELETON=skeleton.name
		mesh.draw()
		mesh.object.setMatrix(skeleton.object.getData().bones[mesh.name].matrix['ARMATURESPACE'])
		
	txt.close()
	
	
def mdbParser(filename,g):
	global txt,skeleton,sectionFlag,meshList,header
	#g.debug=True
	sectionFlag='anim'
	txt=open(g.dirname+os.sep+'tree.txt','w')
	data=g.read(g.fileSize())
	offsetList=[]
	while(True):
		flag=data.find('\x00\x6b\x88\x00')	
		#print flag,len(data)
		if flag>0:
			data=data[flag+4:]
			offsetList.append(g.fileSize()-len(data))
		else:
			break
	print 'znaleziono anim chunk:',len(offsetList),offsetList	
	for offset in offsetList:
		g.seek(offset)		
		try:readAnim(g)
		except:print 'WARNING:readAnim'
	
	g.seek(0)	
	header=g.i(10)
	print header
	g.seek(104)
	g.seek(g.i(1)[0]+32)
	n=0	
	meshList=[]	
	sectionFlag='skeleton'
	skeleton=Skeleton()
	skeleton.nameList=[]
	skeleton.BONESPACE=True
	skeleton.NICE=True
	skeletonTree(None,n,g)
	skeleton.draw()
	for meshID in range(len(meshList)):
		mesh=meshList[meshID]
		#print meshID,'/',len(meshList),':',mesh.name
		#mesh.boneNameList=skeleton.boneNameList
		mesh.BINDSKELETON=skeleton.name
		mesh.draw()
		mesh.object.setMatrix(skeleton.object.getData().bones[mesh.bonename].matrix['ARMATURESPACE'])
		
	txt.close()
	
	
def actionParser(filename,g):
	#g.debug=True
	#g.logOpen()
	action=Action()
	action.BONESPACE=True
	action.BONESORT=True
	action.skeleton='armature'
	while(True):
		if g.tell()>=g.fileSize():break
		bone=ActionBone()
		action.boneList.append(bone)
		bone.name=g.find('\x00')
		posCount=g.i(1)[0]		
		for m in range(posCount):
			bone.posFrameList.append(g.f(1)[0]*33)
		for m in range(posCount):
			bone.posKeyList.append(VectorMatrix(g.f(3)))
		rotCount=g.i(1)[0]		
		for m in range(rotCount):
			bone.rotFrameList.append(g.f(1)[0]*33)
		for m in range(rotCount):
			bone.rotKeyList.append(QuatMatrix(g.f(4)).resize4x4())
	action.draw()
	action.setContext()	
	
	#g.logClose()	
	
def Parser(filename):	
	#filename=input.filename
	ext=filename.split('.')[-1].lower()	
	print
	print filename
	print
	if ext=='mdb':
		file=open(filename,'rb')
		g=BinaryReader(file)
		mdbParser(filename,g)
		#mbaParser(filename,g)
		file.close()
		
	if ext=='mba':
		file=open(filename,'rb')
		g=BinaryReader(file)
		mbaParser(filename,g)
		file.close()
		
	if ext=='action':
		file=open(filename,'rb')
		g=BinaryReader(file)
		actionParser(filename,g)
		file.close()
 
	
 
	
Blender.Window.FileSelector(Parser,'import','The Witcher files: mdb-model, mba-animation container, action-single animation') 
	