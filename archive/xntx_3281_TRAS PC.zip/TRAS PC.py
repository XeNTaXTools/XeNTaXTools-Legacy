#Noesis Python model import+export test module, imports/exports some data from/to a made-up format
#Tomb Raider 2013 PC Script by MrNightmareTM
#Special thanks: Chrrox!! ;]
#v1.0

from inc_noesis import *

import noesis

#rapi methods should only be used during handler callbacks
import rapi

#registerNoesisTypes is called by Noesis to allow the script to register formats.
#Do not implement this function in script files unless you want them to be dedicated format modules!
def registerNoesisTypes():
   handle = noesis.register("Tomb Raider 2013 [PC]", ".mesh")
   noesis.setHandlerTypeCheck(handle, noepyCheckType)
   noesis.setHandlerLoadModel(handle, noepyLoadModel) #see also noepyLoadModelRPG
       #noesis.setHandlerWriteModel(handle, noepyWriteModel)
       #noesis.setHandlerWriteAnim(handle, noepyWriteAnim)
   noesis.logPopup()
       #print("The log can be useful for catching debug prints from preview loads.\nBut don't leave it on when you release your script, or it will probably annoy people.")
   return 1

NOEPY_HEADER = ""

#check if it's this type based on the data
def noepyCheckType(data):
	bs = NoeBitStream(data)
	FILE_VER = bs.readInt()
	if FILE_VER != 0x06:
		print("Unsupported Version")
		return 0     
	return 1

#load the model
def noepyLoadModel(data, mdlList):
	ctx = rapi.rpgCreateContext()
	bs = NoeBitStream(data)
	
	FILE_TYPE = bs.readInt() 							
	bs.seek(0xC, NOESEEK_REL) 							
	
	NUM_UNK00 = bs.readInt()							
	UNK00 = bs.readInt()								
	PTR_MESH_START = bs.readInt()						
	UNK02 = bs.readInt()								
	UNK03 = bs.readInt()								
	UNK04 = bs.readInt()								
	UNK05 = bs.readInt()								
	UNK06 = bs.readInt()								
	UNK07 = bs.readInt()								
	UNK08 = bs.readInt()								
	UNK09 = bs.readInt()								
	UNK10 = bs.readInt()								
	UNK11 = bs.readInt()								
	
	for i in range(0, NUM_UNK00):						
		bs.seek(0x4, NOESEEK_REL)
		
	TEMP  = bs.tell()
	bs.seek(UNK08 - 4, NOESEEK_REL)						
	BONE_COUNT = bs.readInt()
	bs.seek(0x4, NOESEEK_REL)							
	
	BONE_LIST = []

	for i in range(0, BONE_COUNT):
		bs.seek(0x20, NOESEEK_REL)
		BONE_XPOS = bs.readFloat()
		BONE_YPOS = bs.readFloat()
		BONE_ZPOS = bs.readFloat()
		bs.seek(0xC, NOESEEK_REL)
		BONE_PID = bs.readInt()
		bs.seek(0x4, NOESEEK_REL)
		quat = NoeQuat([0, 0, 0, 1])
		mat = quat.toMat43()
		mat[3] = [BONE_XPOS, BONE_YPOS, BONE_ZPOS]
		BONE_LIST.append(NoeBone(i, "bone%03i"%i, mat, None, BONE_PID))
	
	bs.seek(TEMP + PTR_MESH_START, NOESEEK_ABS) 		

	MESH_START = bs.tell()								
	bs.seek(0xC, NOESEEK_REL)							
	FCOUNT = bs.readInt()								
	bs.seek(0x64, NOESEEK_REL)							
	
	PTR_MAT_TABLE = bs.readInt()						
	PTR_MESH_TBL00 = bs.readInt() 						
	PTR_MESH_TBL01 = bs.readInt() 						
	PTR_MESH_BONES = bs.readInt() 						
	PTR_MESH_FACE = bs.readInt() 						
	
	NUM_UNK01 = bs.readShort()							
	NUM_MESH = bs.readShort()							
	NUM_UNK02 = bs.readShort()							
	NUM_BONES = bs.readShort()							
	
	bs.seek(MESH_START + PTR_MESH_TBL00, NOESEEK_ABS)	
	
	MESH = []											
	for i in range(0, NUM_MESH):
		MESH_UNK00 = bs.readInt()						
		MESH_GROUP = bs.readShort()						
		MESH_UNK = bs.readShort()						
		MESH_UNK01 = bs.readInt()						
		MESH_VERT_OFF = bs.readInt()					
		
		MESH_UNK02 = bs.readInt()						
		MESH_UNK03 = bs.readInt()						
		MESH_UNK04 = bs.readInt()						
		MESH_FVF_OFF = bs.readInt()						
		
		MESH_VCOUNT = bs.readInt()						
		MESH_UNK05 = bs.readInt()						
		MESH_FACE_OFF = bs.readInt() 					
		MESH_FCOUNT = bs.readInt()						
		MESH.append([MESH_UNK00, MESH_GROUP, MESH_UNK, MESH_UNK01, MESH_VERT_OFF, MESH_UNK02, MESH_UNK03, MESH_UNK04, MESH_FVF_OFF, MESH_VCOUNT, MESH_UNK05, MESH_FACE_OFF, MESH_FCOUNT])
	

	for i in range(0, NUM_MESH):
		rapi.rpgSetName("MESH_" + str(i))
		bs.seek(MESH_START + MESH[i][8], NOESEEK_ABS)	
		bs.seek(0x8, NOESEEK_REL)						
		MESH_FVF = bs.readShort()						
		MESH_VERT_STRIDE = bs.readShort()				
					
		bs.seek(MESH_START + MESH[i][4], NOESEEK_ABS)	
		
		VBUFFER = bs.readBytes(MESH[i][9] * MESH_VERT_STRIDE)
		rapi.rpgBindPositionBufferOfs(VBUFFER, noesis.RPGEODATA_FLOAT, MESH_VERT_STRIDE, 0)
		
		bs.seek(MESH_START + PTR_MESH_FACE, NOESEEK_ABS) 
		bs.seek(MESH[i][11] * 2, NOESEEK_REL)
		FBUFFER = bs.readBytes(MESH[i][12] * 0x3 * 0x2)
		
		rapi.rpgCommitTriangles(FBUFFER, noesis.RPGEODATA_USHORT, MESH[i][12] * 0x3, noesis.RPGEO_TRIANGLE, 1)
	BONE_LIST = rapi.multiplyBones(BONE_LIST)
	mdl = rapi.rpgConstructModel()
	mdlList.append(mdl) #important, don't forget to put your loaded model in the mdlList
	mdl.setBones(BONE_LIST)
	rapi.rpgClearBufferBinds()
	return 1