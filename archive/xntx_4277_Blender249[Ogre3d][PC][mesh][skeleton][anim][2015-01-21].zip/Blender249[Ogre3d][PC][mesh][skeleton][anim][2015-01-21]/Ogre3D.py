import newGameLib
reload(newGameLib)
from newGameLib import *
import Blender
	

def xmlParser(filename):
	matFile=filename+'_data'+os.sep+'materials_dead.xml'
	if os.path.exists(matFile)==True:
		materials={}
		xml=Xml()
		xml.input=open(matFile,'r')
		xml.parse()	
		materialNodeList=xml.find(xml.root,'Material')
		for materialNode in materialNodeList:
			chunks=materialNode.chunks
			materials[chunks['name']]={}
			materials[chunks['name']]['diffuse']=None
			materials[chunks['name']]['normalmap']=None
			materials[chunks['name']]['specularmap']=None
			if 'diffuse' in chunks:
				materials[chunks['name']]['diffuse']=chunks['diffuse']
			if 'normalmap' in chunks:	
				materials[chunks['name']]['normalmap']=chunks['normalmap']
			if 'specularmap' in chunks:	
				materials[chunks['name']]['specularmap']=chunks['specularmap']
		return materials
	else:
		return None

def matParser(g,matName):
	mat=None#torchlight 2, garshasp
	matPath=g.dirname+os.sep+g.basename+'.material'
	flag=False
	texDir=g.dirname
	if os.path.exists(matPath)==True:
		matFile=open(matPath,'r')
		for line in matFile.readlines():
			stripLine=line.strip()
			if 'material' in stripLine:
				splitLine=stripLine.split()
				if splitLine[0]=='material':
					if splitLine[1]==matName:
						mat=Mat()
						mat.name=splitLine[1]
						flag=True
			if	flag==True:
				if 'texture' in stripLine:
					splitLine=stripLine.split()
					print splitLine
					if splitLine[0]=='texture':
						if mat is not None:
							mat.diffuse=g.dirname+os.sep+splitLine[1].replace('.png','.dds')
							break
				if 'DiffMap0' in stripLine:
						splitLine=stripLine.split()
						if mat is not None:
							mat.diffuse=texDir+os.sep+splitLine[2]
							print mat.diffuse
				if 'diffuse_map' in stripLine:
						splitLine=stripLine.split('"')
						if mat is not None:
							mat.diffuse=texDir+os.sep+splitLine[1]
							print mat.diffuse
				if 'SpecMap' in stripLine:
						splitLine=stripLine.split()
						if mat is not None:
							mat.specular=texDir+os.sep+splitLine[2]
							print mat.diffuse
				if 'NormMap' in stripLine:
						splitLine=stripLine.split()
						if mat is not None:
							mat.normal=texDir+os.sep+splitLine[2]
							print mat.diffuse
				if flag==True and '}' in stripLine:		
							flag=False
							break
	else:				
		flag=False
		texDir=g.dirname.split('media')[0]+os.sep+'media-opt\\shared\\characters\\textures'
		matPath=g.dirname.replace('meshes','materials')+os.sep+g.basename+'.material'
		if os.path.exists(matPath)==True:
			matFile=open(matPath,'r')
			for line in matFile.readlines():
				stripLine=line.strip()
				if 'material' in stripLine:
					splitLine=stripLine.split()
					if splitLine[0]=='material':
						if splitLine[1]==matName:
							mat=Mat()
							mat.name=splitLine[1]
							flag=True
				if 'diffuse_map' in stripLine:
					splitLine=stripLine.split('"')
					if mat is not None:
						for imagePath in input.imageList:
							if splitLine[1] in imagePath:
								break
						mat.diffuse=texDir+os.sep+splitLine[1]
						#mat.diffuse=imagePath
						print mat.diffuse
				if 'specular_map' in stripLine:
					splitLine=stripLine.split('"')
					if mat is not None:
						for imagePath in input.imageList:
							if splitLine[1] in imagePath:
								break
						mat.specular=texDir+os.sep+splitLine[1]
						#mat.specular=imagePath
				if 'normal_map' in stripLine:
					splitLine=stripLine.split('"')
					if mat is not None:
						for imagePath in input.imageList:
							if splitLine[1] in imagePath:
								break
						#mat.normal=texDir+os.sep+splitLine[1]
						#mat.normal=imagePath
				if flag==True and '}' in stripLine:		
						flag=False
						break
		else:		
			flag=False
			texDir=g.dirname
			matPath=g.dirname+os.sep+'baked.material'
			print matPath
			if os.path.exists(matPath)==True:
				matFile=open(matPath,'r')
				for line in matFile.readlines():
					print line
					stripLine=line.strip()
					if 'material' in stripLine and flag==True:
						break
					if 'material' in stripLine and flag==False:
						splitLine=stripLine.split()
						if splitLine[0]=='material':
							if splitLine[1]==matName:
								mat=Mat()
								mat.name=splitLine[1]
								flag=True
					if 'texture_alias' in stripLine:					
						splitLine=stripLine.split()
						texType=splitLine[1]
						if mat is not None:
							print splitLine
							if texType=='DecalTexture':
								mat.diffuse=texDir+os.sep+splitLine[2]
							if texType=='NormalMap':
								mat.normal=texDir+os.sep+splitLine[2]
							if texType=='SpecMap':
								mat.specular=texDir+os.sep+splitLine[2]
			else:
				print 'WARNING: not exist',matPath	
	return mat			
				
				
		
		
def x4000(g,t):
	startSection=g.tell()-2
	
	size=g.i(1)[0]
	matName=g.find('\x0a')
	matList.append(matName)
	print matName
	A=g.B(1)[0]	
	B=g.i(1)[0]
	C=g.B(1)[0]
	offset=g.tell()
	indiceList.append([A,B,C,offset])
	g.seek(B*2,1)
	
	endSection=g.tell()
	usedSizeSection=endSection-startSection
		
		
def x5000(g,t):
	startSection=g.tell()-2
	
	size=g.i(1)[0]
	submesh.vertCount=g.i(1)[0]
	
	endSection=g.tell()
	usedSizeSection=endSection-startSection
		
		
def x5100(g,t):
	startSection=g.tell()-2
	
	size=g.i(1)[0]
	
	endSection=g.tell()
	usedSizeSection=endSection-startSection
		
		
def x5110(g,t):
	startSection=g.tell()-2
	
	info=Declaration()
	size=g.i(1)[0]
	info.streamID=g.H(1)[0]
	info.format=g.H(1)[0]
	info.type=g.H(1)[0]
	info.offset=g.H(1)[0]
	unk=g.H(1)[0]
	
	endSection=g.tell()
	usedSizeSection=endSection-startSection
	
	submesh.infoList.append(info)
		
		
def x5200(g,t):
	startSection=g.tell()-2
	
	size=g.i(1)[0]
	stream.ID=g.H(1)[0]
	stream.stride=g.H(1)[0]
	stream.offset=g.tell()
	
	endSection=g.tell()
	usedSizeSection=endSection-startSection
		
		
def x5210(g,t):
	startSection=g.tell()-2
	
	size=g.i(1)[0]
	stream.offset=g.tell()
	
	endSection=g.tell()
	usedSizeSection=endSection-startSection
	
	g.seek(t+size)
		
		
def x4010(g,t):
	startSection=g.tell()-2
	
	size=g.i(1)[0]
	unk=g.h(1)[0]
	
	endSection=g.tell()
	usedSizeSection=endSection-startSection
		
		
def x4100(g,t):
	startSection=g.tell()-2
	
	size=g.i(1)[0]
	ID=g.H(1)[0]
	unk=g.H(2)
	weight=g.f(1)[0]
	
	endSection=g.tell()
	usedSizeSection=endSection-startSection
	submesh.skin.append([ID,unk[1],weight])
		
		
def x6000(g,t):
	startSection=g.tell()-2
	
	size=g.i(1)[0]
	name=g.find('\x0a')
	
	endSection=g.tell()
	usedSizeSection=endSection-startSection
	
	g.seek(t+size)
		
		
def x7000(g,t):
	startSection=g.tell()-2
	size=g.i(1)[0]
	ID=g.H(1)[0]
	unk=g.H(2)
	weight=g.f(1)[0]
	submesh.skin.append([ID,unk[1],weight])
	
	endSection=g.tell()
	usedSizeSection=endSection-startSection
		
def x9000(g,t):
	startSection=g.tell()-2
	size=g.i(1)[0]
	unk=g.f(7)
	endSection=g.tell()
	
	usedSizeSection=endSection-startSection
	g.seek(t+size)
	
	
		
def xa000(g,t):
	startSection=g.tell()-2
	size=g.i(1)[0]
	
	endSection=g.tell()
	usedSizeSection=endSection-startSection
		
def xa100(g,t):
	startSection=g.tell()-2
	
	size=g.i(1)[0]
	g.H(1)[0],
	g.find('\x0a')
	
	endSection=g.tell()
	usedSizeSection=endSection-startSection
	
	g.seek(t+size)
		
	
		

class Declaration:
	def __init__(self):
		self.streamID=None
		self.format=None
		self.type=None
		self.offset=None
		
		
class Submesh:
	def __init__(self):
		self.infoList=[]
		self.streamList=[]	
		self.indiceList=[]
		self.material=None	
		self.vertCount=None	
		self.skin=[]
		
class Stream:
	def __init__(self):
		self.ID=None
		self.stride=None
		self.offset=None		
		

def meshParser(filename,g):
	global matList
	global submesh
	global indiceList
	global stream
	matList=[]
	submeshList=[]
	indiceList=[]
	g.seek(32)
	
	while(True):
		if g.tell()>=g.fileSize():
			print 'DONE.ALL PARSED'
			break
		t=g.tell()
		chunk=g.H(1)[0]
		if chunk==0x4000:x4000(g,t)
		elif chunk==0x5000:
			submesh=Submesh()
			submeshList.append(submesh)
			x5000(g,t)
		elif chunk==0x5100:x5100(g,t)
		elif chunk==0x5110:x5110(g,t)
		elif chunk==0x5200:
			stream=Stream()
			submesh.streamList.append(stream)
			x5200(g,t)
		elif chunk==0x5210:x5210(g,t)
		elif chunk==0x4010:x4010(g,t)
		elif chunk==0x4100:x4100(g,t)
		elif chunk==0x6000:x6000(g,t)
		elif chunk==0x7000:x7000(g,t)
		elif chunk==0x9000:x9000(g,t)
		elif chunk==0xa000:xa000(g,t)
		elif chunk==0xa100:xa100(g,t)
		else:
			print 'WARNING: unknow',hex(chunk),'offset=',g.tell()
				
			break
		
	
	g.tell()
	print 'indiceList count=',len(indiceList)
	print 'submeshList count=',len(submeshList)
	if len(indiceList)==len(submeshList):
		for m in range(len(matList)):
			mesh=Mesh()
			mesh.TRIANGLE=True
			matName=matList[m]	
			mat=matParser(g,matName)
			if mat is not None:
				mat.TRIANGLE=True
				mat.ZTRANS=True
				mesh.matList.append(mat)
			indice=indiceList[m]
			g.seek(indice[3])
			mesh.indiceList=g.H(indice[1])
			submesh=submeshList[m]
			print 'skin',len(submesh.skin)
			for info in submesh.infoList:
				if info.type==1:#vertPos
					for stream in submesh.streamList:
						if stream.ID==info.streamID:
							g.seek(stream.offset)
							for n in range(submesh.vertCount):
								t=g.tell()
								g.seek(t+info.offset)
								if info.format==2:#float
									mesh.vertPosList.append(g.f(3))
								g.seek(t+stream.stride)
				if info.type==7:#vertUV
					for stream in submesh.streamList:
						if stream.ID==info.streamID:
							g.seek(stream.offset)
							for n in range(submesh.vertCount):
								t=g.tell()
								g.seek(t+info.offset)
								if info.format==1:#float
									mesh.vertUVList.append(g.f(2))
								g.seek(t+stream.stride)
			skin=Skin()	
			for n in range(submesh.vertCount):
				mesh.skinIndiceList.append([])
				mesh.skinWeightList.append([])
			for n in range(len(submesh.skin)):
				mesh.skinIndiceList[submesh.skin[n][0]].append(submesh.skin[n][1])	
				mesh.skinWeightList[submesh.skin[n][0]].append(submesh.skin[n][2])	
			mesh.skinList.append(skin)	
			mesh.BINDSKELETON='armature'	
			mesh.draw()
	else:	
		for m in range(len(submeshList)):
			mesh=Mesh()
			mesh.TRIANGLE=True
			submesh=submeshList[m]
			print 'skin',len(submesh.skin)
			for info in submesh.infoList:
				if info.type==1:#vertPos
					for stream in submesh.streamList:
						if stream.ID==info.streamID:
							g.seek(stream.offset)
							for n in range(submesh.vertCount):
								t=g.tell()
								g.seek(t+info.offset)
								if info.format==2:#float
									mesh.vertPosList.append(g.f(3))
								g.seek(t+stream.stride)
				if info.type==7:#vertUV
					for stream in submesh.streamList:
						if stream.ID==info.streamID:
							g.seek(stream.offset)
							for n in range(submesh.vertCount):
								t=g.tell()
								g.seek(t+info.offset)
								if info.format==1:#float
									mesh.vertUVList.append(g.f(2))
								g.seek(t+stream.stride)
			sum=0					
			for n in range(len(indiceList)):
				indice=indiceList[n]
				matName=matList[n]	
				print matName
				mat=matParser(g,matName)
				mat.IDStart=sum
				mat.IDCount=indice[1]
				mat.TRIANGLE=True
				mat.ZTRANS=True
				g.seek(indice[3])
				mesh.indiceList.extend(g.H(indice[1]))
				sum+=indice[1]
				mesh.matList.append(mat)
			skin=Skin()	
			for n in range(submesh.vertCount):
				mesh.skinIndiceList.append([])
				mesh.skinWeightList.append([])
			for n in range(len(submesh.skin)):
				mesh.skinIndiceList[submesh.skin[n][0]].append(submesh.skin[n][1])	
				mesh.skinWeightList[submesh.skin[n][0]].append(submesh.skin[n][2])	
			mesh.skinList.append(skin)	
			mesh.BINDSKELETON='armature'					
			mesh.draw()						
		
def skeletonParser(filename,g):
	g.B(2)
	g.find('\x0a')
	
	
	sys=Sys(filename)
	sys.addDir(sys.base+'_animfiles')
	boneList=[]
	animFlag=True
	while(True):
		pos=g.tell()
		chunk = g.H(1)[0]
		#print hex(chunk),g.tell()
		if chunk==0x2000:
			bone=Bone()
			size  = g.i(1)[0]
			name = g.find('\x0a')
			bone.ID=g.H(1)[0]
			bone.posmatrix=VectorMatrix(g.f(3))
			bone.rotmatrix=QuatMatrix(g.f(4)).resize4x4()
			bone.matrix=bone.rotmatrix*bone.posmatrix
			if size==48:print g.f(3)
			boneList.append(bone)
		elif chunk==0x3000:
			size=g.i(1)[0]
			var=g.H(2)
			boneList[var[0]].parentID=var[1]
		elif chunk==0x4000:
			animFlag=True
			size=g.i(1)[0] 
			animName=g.find('\x0a')
			lenght=g.f(1)[0]
			print animName,lenght
			animPath=g.dirname+os.sep+sys.base+'_animfiles'+os.sep+animName+'.anim'
			animFile=open(animPath,'wb')
			p=BinaryReader(animFile)
			p.i([len(boneList)])
			for i,bone in enumerate(boneList):
				if bone.parentID is None:bone.parentID=-1
				p.i([bone.parentID])
				p.f(bone.rotmatrix[0])
				p.f(bone.rotmatrix[1])
				p.f(bone.rotmatrix[2])
				p.f(bone.rotmatrix[3])
				p.f(bone.posmatrix[0])
				p.f(bone.posmatrix[1])
				p.f(bone.posmatrix[2])
				p.f(bone.posmatrix[3])
		elif chunk==0x4100:	
			p.i([chunk])
			a,b,c=g.H(3)
			p.i([c])				
		elif chunk==0x4110:	
			size=g.i(1)[0]
			p.i([chunk])
			if size==38:animFile.write(g.read(32))
			elif size==50:
				animFile.write(g.read(32))
				g.f(3)
			else:
				print 'WARNING:unknow size:',size
				break
			g.seek(pos+size)
		elif chunk==0x5000:
			g.debug=True
			size=g.i(1)[0]
			name = g.find('\x0a')
			g.f(1)
			g.seek(pos+size)
		else:
			print 'unknow chunk',hex(chunk),g.tell()
			break
		if g.tell()==g.fileSize():
			break
	if animFlag==True:	
		skeleton=Skeleton()
		skeleton.SORT=True
		#skeleton.BONESPACE=True
		skeleton.ARMATURESPACE=True
		skeleton.BINDMESH=True
		skeleton.NICE=True
		skeleton.boneList=boneList
		skeleton.draw()
		
	g.logClose()		
	
def animParser(filename,g):
	
	
	skeleton=Skeleton()
	skeleton.BONESPACE=True
	skeleton.BINDMESH=True
	skeleton.NICE=True
	boneCount=g.i(1)[0]
	for m in range(boneCount):
		bone=Bone()
		bone.parentID=g.i(1)[0]
		rotMatrix=Matrix4x4(g.f(16))
		posMatrix=Matrix4x4(g.f(16))
		bone.posMatrix=posMatrix
		bone.rotMatrix=rotMatrix
		skeleton.boneList.append(bone)
	#skeleton.draw()
	
	action=Action()
	action.skeleton='armature'
	action.BONESORT=True
	action.BONESPACE=True
	while(True):
		chunk = g.i(1)[0]
		if chunk==0x4100:
			abone=ActionBone()
			id=g.i(1)[0]
			abone.name=str(id)
			action.boneList.append(abone)
			rotMatrix=skeleton.boneList[id].rotMatrix
			posMatrix=skeleton.boneList[id].posMatrix
		elif chunk==0x4110:	
			time=g.f(1)[0]*30
			abone.posFrameList.append(time)
			abone.rotFrameList.append(time)
			matrix=QuatMatrix(g.f(4)).resize4x4()*rotMatrix
			abone.rotKeyList.append(matrix)
			matrix=VectorMatrix(g.f(3))*posMatrix
			abone.posKeyList.append(matrix)
		if g.tell()==g.fileSize():
			break		
	action.draw()
	action.setContext()
	
		
def Parser():
	filename=input.filename
	print
	print filename
	print
	ext=filename.split('.')[-1].lower()
	
		
	if ext=='mesh':
		file=open(filename,'rb')
		g=BinaryReader(file)
		meshParser(filename,g)
		file.close()
		
	if ext=='skeleton':
		file=open(filename,'rb')
		g=BinaryReader(file)
		skeletonParser(filename,g)
		file.close()
		
	if ext=='anim':
		file=open(filename,'rb')
		g=BinaryReader(file)
		animParser(filename,g)
		file.close()
		
	
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
	
Blender.Window.FileSelector(openFile,'import','Ogre3d .mesh, .skeleton, .anim') 