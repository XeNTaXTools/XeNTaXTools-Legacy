#pragma once

bool __stdcall decrypt(void *decrypted, void *encrypted, DWORD unpacked, DWORD packed, DWORD param);
