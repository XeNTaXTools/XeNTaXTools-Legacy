#include <windows.h>
#include <stdio.h>
#include "decrypt.h"

bool extract(char *name, BYTE *ptr, DWORD size)
{
	DWORD num;
	BYTE *pos, *start;

	start = ptr + size;

	num = 0;
	pos = start;

	__try
	{
		while(true)
		{
			DWORD packed, unpacked;

			pos -= 8;

			packed = *(DWORD *)pos & 0xFFFFFFF;
			if (packed == 0) break;

			unpacked = *(DWORD *)(pos + 4) & 0x1FFFFFFF;

			pos -= packed;
			num++;
		}
	}
	__except(EXCEPTION_EXECUTE_HANDLER)
	{
		return false;
	}

	pos = start;

	for (DWORD i = 0; i < num; i++)
	{
		DWORD packed, unpacked, type, param, written;
		BYTE *decrypted;
		char dumpname[1000];
		HANDLE dump;

		pos -= 8;

		packed = *(DWORD *)pos & 0xFFFFFFF;
		type = (*(DWORD *)pos & 0xF0000000) >> 28;
		unpacked = *(DWORD *)(pos + 4) & 0x1FFFFFFF;
		param = *(DWORD *)(pos + 4) >> 0x1D;

		pos -= packed;

		decrypted = new BYTE[unpacked];

		if (!decrypt(decrypted, pos, unpacked, packed, param))
		{
			printf("\ndecrypt error at %08X (type=%01X), skipping\n", pos, type);
			delete[] decrypted;
			continue;
		}

		switch(type)
		{
			case 0x00:
			case 0x01:
			case 0x04:
			case 0x05:
			case 0x08:
				{
					FILETIME time;

					sprintf(dumpname, "%s_%02X_driver_%01X.sys", name, i, type);
					dump = CreateFile(dumpname, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
					WriteFile(dump, decrypted + 8, unpacked - 8, &written, NULL);

					time.dwLowDateTime = *(DWORD *)decrypted;
					time.dwHighDateTime = *(DWORD *)(decrypted + 4);
					SetFileTime(dump, &time, &time, &time);

					CloseHandle(dump);
				}
				break;

			case 0x0D:
				{
					sprintf(dumpname, "%s_%02X_vm", name, i);
					dump = CreateFile(dumpname, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
					WriteFile(dump, decrypted, unpacked, &written, NULL);
					CloseHandle(dump);
				}
				break;

			case 0x0E:
				{
					sprintf(dumpname, "%s_%02X_sfstat.exe", name, i);
					dump = CreateFile(dumpname, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
					WriteFile(dump, decrypted, unpacked, &written, NULL);
					CloseHandle(dump);
				}
				break;

			case 0x0F:
				{
					DWORD fontsize;

					fontsize = *(DWORD *)(decrypted + 0x14);

					sprintf(dumpname, "%s_%02X_fontstuff", name, i);
					dump = CreateFile(dumpname, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
					WriteFile(dump, decrypted, fontsize, &written, NULL);
					CloseHandle(dump);

					sprintf(dumpname, "%s_%02X_menu.bmp", name, i);
					dump = CreateFile(dumpname, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
					WriteFile(dump, decrypted + fontsize, unpacked - fontsize, &written, NULL);
					CloseHandle(dump);
				}
				break;

			default:
				{
					sprintf(dumpname, "%s_%02X_%01X", name, i, type);
					dump = CreateFile(dumpname, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
					WriteFile(dump, decrypted, unpacked, &written, NULL);
					CloseHandle(dump);
				}
				break;
		}

		delete[] decrypted;

		printf("\r%u files found, extracting (%.1f%%)...", num, (float)(i + 1) * 100.0f / (float)num);
	}

	return true;
}

void extract(char *name)
{
	HANDLE file, mapping;
	BYTE *ptr;
	DWORD size;

	file = CreateFile(name, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);

	if (file == INVALID_HANDLE_VALUE)
	{
		printf("%s not found\n");
		return;
	}

	size = GetFileSize(file, NULL);

	mapping = CreateFileMapping(file, NULL, PAGE_READONLY, 0, 0, NULL);
	ptr = (BYTE *)MapViewOfFile(mapping, FILE_MAP_READ, 0, 0, 0);

	if (!extract(name, ptr, size))
	{
		printf("invalid archive\n");
	}

	UnmapViewOfFile(ptr);
	CloseHandle(mapping);
	CloseHandle(file);
}

int main(int argc, char **args)
{
	if (argc == 1)
	{
		printf("usage:\nsfextract <yo.dll>\n", args[0]);
	}
	else
	{
		extract(args[1]);
	}

	return 0;
}
