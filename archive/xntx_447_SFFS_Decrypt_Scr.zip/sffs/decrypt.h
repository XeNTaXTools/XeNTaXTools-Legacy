#pragma once

void __stdcall reverseName(wchar_t *name, int len);
void __stdcall makeKeyBuf(void *dest, void *key, int len);
DWORD64 __stdcall decryptBuf(void *key, void *dest, DWORD lenLow, DWORD lenHigh, DWORD filePosLow, DWORD filePosHigh);
