#pragma once

extern const BYTE *unk_1E3A0, *unk_1E3E8, *unk_1F3E8;
