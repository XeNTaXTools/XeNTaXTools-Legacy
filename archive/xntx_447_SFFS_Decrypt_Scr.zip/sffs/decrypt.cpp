#include <windows.h>
#include "decrypt_buf.h"

extern "C" DWORD _allmul(DWORD, DWORD, DWORD, DWORD);

void __declspec(naked) __stdcall sub_1BDEE()
{
	__asm
	{
                xor     edx, edx
                mov     dl, cl
                push    ebx
                mov     eax, 0FFh
                shr     ecx, 8
                push    edi
                and     edx, eax
                mov     edi, edx
                xor     edx, edx
                mov     dl, cl
                shr     ecx, 8
                mov     ebx, ecx
                and     ecx, eax
                shr     ebx, 8
                and     ebx, eax
                and     edx, eax
                mov     eax, [esi+ebx*4+48h]
                add     eax, [esi+ecx*4+448h]
                movzx   ecx, dx
                xor     eax, [esi+ecx*4+848h]
                movzx   ecx, di
                add     eax, [esi+ecx*4+0C48h]
                pop     edi
                pop     ebx
                retn
	}
}

void __declspec(naked) __stdcall sub_1BE34()
{
	__asm
	{
                push    ebp
                mov     ebp, esp
                push    ecx
                mov     eax, [ebp+10h]
                push    ebx
                mov     ebx, [ebp+0Ch]
                mov     ecx, [ebx]
                push    esi
                mov     esi, [ebp+8]
                push    edi
                mov     edi, [eax]
                mov     [ebp+0Ch], esi
                mov     dword ptr [ebp+8], 10h

loc_1BE52:                              ; CODE XREF: sub_1BE34+39j
                mov     eax, [ebp+0Ch]
                xor     ecx, [eax]
                mov     [ebp-4], ecx
                call    sub_1BDEE
                add     dword ptr [ebp+0Ch], 4
                xor     eax, edi
                dec     dword ptr [ebp+8]
                mov     edi, [ebp-4]
                mov     ecx, eax
                jnz     loc_1BE52
                mov     eax, [esi+40h]
                xor     eax, ecx
                mov     ecx, [esi+44h]
                xor     ecx, edi
                mov     [ebx], ecx
                mov     ecx, [ebp+10h]
                pop     edi
                pop     esi
                mov     [ecx], eax
                pop     ebx
                leave
                retn    0Ch
	}
}

void __declspec(naked) __stdcall sub_1BE88()
{
	__asm
	{
                push    ebp
                mov     ebp, esp
                push    ecx
                mov     eax, [ebp+0Ch]
                mov     ecx, [eax]
                mov     eax, [ebp+10h]
                push    ebx
                mov     ebx, [eax]
                push    esi
                mov     esi, [ebp+8]
                push    edi
                lea     edi, [esi+44h]
                mov     dword ptr [ebp+8], 10h

loc_1BEA6:                              ; CODE XREF: sub_1BE88+35j
                xor     ecx, [edi]
                mov     [ebp-4], ecx
                call    sub_1BDEE
                xor     eax, ebx
                mov     ebx, [ebp-4]
                sub     edi, 4
                dec     dword ptr [ebp+8]
                mov     ecx, eax
                jnz     loc_1BEA6
                mov     eax, [esi+4]
                mov     edx, [ebp+0Ch]
                xor     eax, ecx
                mov     ecx, [esi]
                xor     ecx, ebx
                pop     edi
                mov     [edx], ecx
                mov     ecx, [ebp+10h]
                pop     esi
                mov     [ecx], eax
                pop     ebx
                leave
                retn    0Ch
	}
}

//.text:0001BEDA sub_1BEDA       proc near               ; CODE XREF: sub_15FFC+2B6p
void __declspec(naked) __stdcall makeKeyBuf(void *dest, void *key, int len)
{
	__asm
	{
                push    ebp
                mov     ebp, esp
                push    ecx
                push    ebx
                push    esi
                push    edi
                mov     edi, [ebp+8]
                push    4
				mov     eax, dword ptr [unk_1E3E8]
                lea     ecx, [edi+48h]
                pop     ebx

loc_1BEEF:                              ; CODE XREF: sub_1BEDA+2Aj
                mov     edx, 100h

loc_1BEF4:                              ; CODE XREF: sub_1BEDA+23j
                mov     esi, [eax]
                mov     [ecx], esi
                add     eax, ebx
                add     ecx, ebx
                dec     edx
                jnz     loc_1BEF4
                cmp     eax, dword ptr [unk_1F3E8]
                jl      loc_1BEEF
                mov     edx, dword ptr [unk_1E3A0]
                xor     ecx, ecx
                mov     eax, edi
                sub     edx, edi
                mov     dword ptr [ebp-4], 12h

loc_1BF18:                              ; CODE XREF: sub_1BEDA+6Bj
                xor     esi, esi
                mov     [ebp+8], ebx

loc_1BF1D:                              ; CODE XREF: sub_1BEDA+5Aj
                mov     ebx, [ebp+0Ch]
                movzx   ebx, byte ptr [ecx+ebx]
                shl     esi, 8
                or      esi, ebx
                inc     ecx
                cmp     ecx, [ebp+10h]
                jl      loc_1BF31
                xor     ecx, ecx

loc_1BF31:                              ; CODE XREF: sub_1BEDA+53j
                dec     dword ptr [ebp+8]
                jnz     loc_1BF1D
                mov     ebx, [edx+eax]
                xor     ebx, esi
                mov     [eax], ebx
                push    4
                pop     ebx
                add     eax, ebx
                dec     dword ptr [ebp-4]
                jnz     loc_1BF18
                xor     esi, esi
                mov     [ebp+8], esi
                mov     [ebp+0Ch], esi

loc_1BF4F:                              ; CODE XREF: sub_1BEDA+95j
                lea     eax, [ebp+0Ch]
                push    eax
                lea     eax, [ebp+8]
                push    eax
                push    edi
                call    sub_1BE34
                mov     eax, [ebp+8]
                mov     [edi+esi*4], eax
                mov     eax, [ebp+0Ch]
                mov     [edi+esi*4+4], eax
                inc     esi
                inc     esi
                cmp     esi, 12h
                jl      loc_1BF4F
                lea     esi, [edi+4Ch]
                mov     [ebp+10h], ebx

loc_1BF77:                              ; CODE XREF: sub_1BEDA+C4j
                mov     ebx, 80h

loc_1BF7C:                              ; CODE XREF: sub_1BEDA+BFj
                lea     eax, [ebp+0Ch]
                push    eax
                lea     eax, [ebp+8]
                push    eax
                push    edi
                call    sub_1BE34
                mov     eax, [ebp+8]
                mov     [esi-4], eax
                mov     eax, [ebp+0Ch]
                mov     [esi], eax
                add     esi, 8
                dec     ebx
                jnz     loc_1BF7C
                dec     dword ptr [ebp+10h]
                jnz     loc_1BF77
                pop     edi
                pop     esi
                pop     ebx
                leave
                retn    0Ch
	}
}

//.text:0001C996 sub_1C996       proc near               ; CODE XREF: sub_15FFC+2A7p
void __declspec(naked) __stdcall reverseName(wchar_t *name, int len)
{
	__asm
	{
                push    ebp
                mov     ebp, esp
                mov     ecx, [ebp+0Ch]
                test    ecx, ecx
                jz      loc_1C9D1
                mov     eax, ecx
                cdq
                sub     eax, edx
                sar     eax, 1
                push    esi
                xor     esi, esi
                test    eax, eax
                mov     [ebp+0Ch], eax
                jle     loc_1C9D0
                push    edi
                mov     edi, [ebp+8]
                lea     ecx, [edi+ecx*2-2]

loc_1C9B9:                              ; CODE XREF: sub_1C996+37j
                mov     ax, [ecx]
                mov     dx, [edi+esi*2]
                mov     [edi+esi*2], ax
                mov     [ecx], dx
                inc     esi
                dec     ecx
                dec     ecx
                cmp     esi, [ebp+0Ch]
                jl      loc_1C9B9
                pop     edi

loc_1C9D0:                              ; CODE XREF: sub_1C996+19j
                pop     esi

loc_1C9D1:                              ; CODE XREF: sub_1C996+8j
                pop     ebp
                retn    8
	}
}

//.text:0001BFA8 sub_1BFA8       proc near               ; CODE XREF: sub_1646C+BBp
DWORD64 __declspec(naked) __stdcall decryptBuf(void *key, void *dest, DWORD lenLow, DWORD lenHigh, DWORD filePosLow, DWORD filePosHigh)
{
	__asm
	{
                push    ebp
                mov     ebp, esp
                push    ecx
                push    ecx
                mov     edx, [ebp+10h]
                mov     eax, edx
                and     eax, 7
                xor     ecx, ecx
                or      eax, ecx
                jnz     locret_1C031
                push    ebx
                push    edi
                mov     edi, [ebp+14h]
                shrd    edx, edi, 2
                xor     ebx, ebx
                shr     edi, 2
                mov     [ebp-4], ecx
                mov     [ebp+10h], edx
                ja      loc_1BFD5
                cmp     edx, ecx
                jbe     loc_1C02F

loc_1BFD5:                              ; CODE XREF: sub_1BFA8+27j
                push    esi

loc_1BFD6:                              ; CODE XREF: sub_1BFA8+7Dj
                                        ; sub_1BFA8+84j
                mov     esi, [ebp+0Ch]
                lea     eax, [esi+ebx*4]
                lea     ecx, [eax+4]
                push    ecx
                push    eax
                push    dword ptr [ebp+8]
                call    sub_1BE88
                cmp     dword ptr [ebp+18h], 0
                jnz     loc_1BFF5
                cmp     dword ptr [ebp+1Ch], 0
                jz      loc_1C01B

loc_1BFF5:                              ; CODE XREF: sub_1BFA8+45j
                mov     ecx, [ebp-4]
                push    0
                push    4
                push    dword ptr [ebp-4]
                mov     eax, ebx
                shrd    eax, ecx, 1
                push    ebx
                shr     ecx, 1
                lea     esi, [esi+eax*8]
                call    _allmul
                add     eax, [ebp+18h]
                adc     edx, [ebp+1Ch]
                xor     [esi], eax
                xor     [esi+4], edx

loc_1C01B:                              ; CODE XREF: sub_1BFA8+4Bj
                add     ebx, 2
                adc     dword ptr [ebp-4], 0
                cmp     [ebp-4], edi
                jb      loc_1BFD6
                ja      loc_1C02E
                cmp     ebx, [ebp+10h]
                jb      loc_1BFD6

loc_1C02E:                              ; CODE XREF: sub_1BFA8+7Fj
                pop     esi

loc_1C02F:                              ; CODE XREF: sub_1BFA8+2Bj
                pop     edi
                pop     ebx

locret_1C031:                           ; CODE XREF: sub_1BFA8+11j
                leave
                retn    18h
	}
}
