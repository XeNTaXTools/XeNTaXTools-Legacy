[SCE CONFIDENTIAL DOCUMENT]
PLAYSTATION(R)3 Programmer Tool Runtime Library 192.001
                  Copyright (C) 2006 Sony Computer Entertainment Inc.
                                                 All Rights Reserved.

dds2gtf.exe

  - This is a tool to perform offline conversion of a DDS file to a
    GTF file.
  - It is located under samples/gtf/bin.


<GTF File Format>

  The GTF file format does not have a fixed pixel format. It corresponds to
  texture data saved in the DDS format that has been rearranged in a layout
  that can be easily handled by RSX(TM).

  Texture data is packed in DDS. To use with RSX(TM), its memory layout 
  must be changed on the CELL side. 
  GTF stores texture data exactly in the layout by which it is to be used 
  within RSX(TM). Thus, such a file can be directly referenced as a texture
  by merely placing it on memory.

  A sample library of the loader for loading GTF files is provided in the
  following location. Note that you must perform build.

  /samples/common/ppu/gtf/


  For details on the GTF file format, refer to GTF-Specifications_j.pdf.


  For details on texture formats that can be handled by RSX(TM), refer to 
  RSX_Texture_j.pdf.


<DDS File Formats that Can Be Converted>

  Basically, any texture data for which bit width and format are known can
  be rearranged.
  Note that data in the DDS format but not in the format that can be 
  directly referenced by RSX(TM) cannot be used even if it is rearranged.


<DDS Formats Corresponding to Formats that Can Be Used by RSX(TM)>

 +----------------------------------------+----------------+
 | Texture Format Used by GCM             | DDS Format     |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_B8                    | A8             |
 |                                        | L8             |
 |                                        | P8             |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_A1R5G5B5              | A1R5G5B5       |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_A4R4G4B4              | A4R4G4B4       |
 |                                        | X4R4G4B4       |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_R5G6B5                | R5G6B5         |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_A8R8G8B8              | R8G8B8 (24bit) |
 |                                        | A8B8G8R8       |
 |                                        | A8R8G8B8       |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_COMPRESSED_DXT1       | DXT1           |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_COMPRESSED_DXT23      | DXT2           |
 |                                        | DXT3           |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_COMPRESSED_DXT45      | DXT4           |
 |                                        | DXT5           |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_G8B8                  | A8L8           |
 |                                        | A8P8           |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_R6G5B5                | L6V5U5         |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_DEPTH24_D8            | N/A            |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_DEPTH24_D8_FLOAT      | N/A            |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_DEPTH16               | N/A            |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_DEPTH16_FLOAT         | R16F           |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_X16                   | L16            |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_Y16_X16               | G16R16         |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_R5G5B5A1              | N/A            |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_COMPRESSED_HILO8      | N/A            |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_COMPRESSED_HILO_S8    | N/A            |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_W16_Z16_Y16_X16_FLOAT | A16B16G16R16F  |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_W32_Z32_Y32_X32_FLOAT | A32B32G32R32F  |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_X32_FLOAT             | R32F           |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_D1R5G5B5              | X1R5G5B5       |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_D8R8G8B8              | X8B8G8R8       |
 |                                        | X8R8G8B8       |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_Y16_X16_FLOAT         | G16R16F        |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_COMPRESSED_R8B8R8G8   | G8R8_G8B8      |
 |                                        | UYVY           |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_COMPRESSED_B8R8_G8R8  | R8G8_B8G8      |
 |                                        | YUY2           |
 +----------------------------------------+----------------+
 
A DDS file not in one of the above formats will still be rearranged based on
its bit width. 
In this case, specify remap suitable for that format from the application
side and perform swizzle-access within the shader.


<Swizzle Conversion>

 By specifying the -s option in dds2gtf.exe, texture data can be converted
 to the swizzle format. Note that there are formats that are not applicable
 for swizzle conversion.

 [Conditions Enabling Swizzle Conversion with dds2gtf]
  - Width and height are both a power of 2
  - Has texel width of 4 bytes (such as ARGB8)

  When specifying the -s option as the input format for data on which 
  swizzle conversion is not possible, the converter will arrange the data
  in the linear format without performing the conversion.

<Using the Converter>

	Usage: dds2gtf [options] file(s)
	Options:
	 -o <file>    Output to <file>
	 -f <file>    Takes input DDS file list from file 
	              (delimiter = CARRIAGE RETURN/ENTER)
	 -s           Convert to swizzle format
	 -u           Unnormalize flag on
	 -v           Show detail information about texture
	 -z           More detailed information on conversion
	 -p           packed allocation in file
	 -a <pitch>   specify pitch of linear texture
	 -64          align pitch of linear texture to 64 bytes
	 -h           Print this message

<Notes>

  Attribute format and remap of a GTF file output by the converter are not
  always correct. When order of the RGBA components of the input DDS is
  special, or when you want to customize them, load them on the application
  side and make applicable changes upon use.

          Example) When you want to perform input to the shader with the
                   layout as ARGB for what is actually in the RGBA layout
                   within the file


<Restrictions>

  Swizzle conversion of 2D textures in the FP16 and FP32 formats, and cube
  map textures, is not currently supported.

  Swizzle conversion of 3D textures in the FP16 and FP32 formats is not
  currently supported.


