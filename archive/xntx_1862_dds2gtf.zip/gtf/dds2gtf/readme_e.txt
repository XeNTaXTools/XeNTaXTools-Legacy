
[SCE CONFIDENTIAL DOCUMENT]
PLAYSTATION(R)3 Programmer Tool Runtime Library 192.001
                      Copyright (C) 2007 Sony Computer Entertainment Inc.
                                                     All Rights Reserved

dds2gtf.exe

  - This is a tool to perform offline conversion of a DDS file to a GTF 
    file.
  - This tool is provided under cell/samples/util/gtf/bin.
  - The source code is provided under cell/samples/util/gtf/dds2gtf/dds2gtf.


<GTF File Format>

  Pixel format for the GTF file format is not predetermined. The RSX(TM)
  remaps the layout of the texture data that is stored in the DDS format
  for easy handling. 

  Because texture data is packed in the DDS format, its memory layout must 
  be changed on the Cell side in order for the RSX(TM) to use it.
  And because the GTF stores texture data in the exact layout by which it 
  will be used within RSX(TM), it can be referenced as a texture just by
  placing the file on memory.

  For more details, refer to the document on the GTF file format.


<Convertable DDS File Formats>

  Basically, if the bit width and format of the texture data is known, the
  file layout of any file can be remapped.
  However, if the RSX(TM) cannot directly reference it, the file cannot be
  used even if it exists in the DDS format and its layout can be 
  redesigned.


<DDS Formats corresponding to a Format Usable by RSX(TM)>

 +----------------------------------------+----------------+
 | Texture Format Handled by GCM          | DDS Format     |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_B8                    | A8             |
 |                                        | L8             |
 |                                        | P8             |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_A1R5G5B5              | A1R5G5B5       |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_A4R4G4B4              | A4R4G4B4       |
 |                                        | X4R4G4B4       |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_R5G6B5                | R5G6B5         |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_A8R8G8B8              | R8G8B8 (24bit) |
 |                                        | A8B8G8R8       |
 |                                        | A8R8G8B8       |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_COMPRESSED_DXT1       | DXT1           |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_COMPRESSED_DXT23      | DXT2           |
 |                                        | DXT3           |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_COMPRESSED_DXT45      | DXT4           |
 |                                        | DXT5           |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_G8B8                  | A8L8           |
 |                                        | A8P8           |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_R6G5B5                | L6V5U5         |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_DEPTH24_D8            | N/A            |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_DEPTH24_D8_FLOAT      | N/A            |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_DEPTH16               | N/A            |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_DEPTH16_FLOAT         | R16F           |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_X16                   | L16            |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_Y16_X16               | G16R16         |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_R5G5B5A1              | N/A            |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_COMPRESSED_HILO8      | N/A            |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_COMPRESSED_HILO_S8    | N/A            |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_W16_Z16_Y16_X16_FLOAT | A16B16G16R16F  |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_W32_Z32_Y32_X32_FLOAT | A32B32G32R32F  |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_X32_FLOAT             | R32F           |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_D1R5G5B5              | X1R5G5B5       |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_D8R8G8B8              | X8B8G8R8       |
 |                                        | X8R8G8B8       |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_Y16_X16_FLOAT         | G16R16F        |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_COMPRESSED_R8B8_R8G8  | G8R8_G8R8      |
 |                                        | UYVY           |
 +----------------------------------------+----------------+
 | CELL_GCM_TEXTURE_COMPRESSED_B8R8_G8R8  | R8G8_B8G8      |
 |                                        | YUY2           |
 +----------------------------------------+----------------+
 
A DDS file that is not in one of the formats above can still be remapped
according to its bit width. 
In such a case, specify remapping that is appropriate to its format from
the application side, or perform a swizzle conversion within the shader.


<Swizzle Conversion>

 A texture data can be converted into the swizzle format by specifying the 
 -s option to dds2gtf.exe. Note, however, that there are formats for which
 the swizzle conversion is unsupported. Conditions and combinations that
 currently support swizzle conversions are as follows.

  - The width and height must both be a power of 2.
  - The file cannot be in the DXT format.
  - Texel widths of 4, 8, and 16 bytes are supported.

  When the -s option is specified for an input format on which a swizzle
  conversion cannot be performed, the converter will remap its layout in
  the linear format instead of performing a conversion.
  In this case, a warning will be output if the -v option has been
  specified.

  A swizzle conversion cannot be performed on 
  CELL_GCM_TEXTURE_COMPRESSED_{R8B8_R8G8|B8R8_G8R8}.

  Swizzle conversion on the FP16 and FP32 formats is supported from 
  version 1.1.0.

<Running the Converter>

	Usage: dds2gtf.exe [options] file(s)
	Options:
	 -o <file>    Output to <file>
	 -s           Convert to the swizzle format
	 -f <file>          Takes input DDS file list from file
	 -v           Show detailed information about the texture
	 -u           Unnormalize flag on
	 -z           Show more detailed information on the conversion
	 -a <pitch>   Specify pitch size of the linear texture
	 -64          Align pitch of the linear texture to 64 bytes
	 -h           Print this message


	*  Format of the file list to be specified for the -f option should
           be as follows.
		
	==========================================================================

	# Strings starting with a sharp are handled as comments.
	images/sample1.dds
	images/sample2.dds

	# Empty lines are ignored.

	images/sample3.dds

	# <EOF>
	==========================================================================


<Notes>

  The attribute format and remap of the GTF file that is output from the
  converter are not always correct. If the RGBA layout of the 
  input DDS is unique, or if you want to customize it, load it onto the
  application and then change it upon its use.

	Example) When a file has a RGBA layout that you want to input as 
                 ARGB to the shader


