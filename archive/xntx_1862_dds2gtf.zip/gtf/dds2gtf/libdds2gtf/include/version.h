/*   SCE CONFIDENTIAL                                       */
/*   PLAYSTATION(R)3 Programmer Tool Runtime Library 192.001 */
/*   Copyright (C) 2007 Sony Computer Entertainment Inc.    */
/*   All Rights Reserved.                                   */

#ifndef __VERSION_H__
#define __VERSION_H__

#if defined(__cplusplus)
extern "C" {
#endif 

#define VERSION  0x01080000     // 1.2.0.0  (20070416)

#if defined(__cplusplus)
}
#endif 


#endif // __VERSION_H__
