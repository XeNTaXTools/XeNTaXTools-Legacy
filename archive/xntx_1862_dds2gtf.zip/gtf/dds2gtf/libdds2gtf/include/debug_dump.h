/*   SCE CONFIDENTIAL                                       */
/*   PLAYSTATION(R)3 Programmer Tool Runtime Library 192.001 */
/*   Copyright (C) 2007 Sony Computer Entertainment Inc.    */
/*   All Rights Reserved.                                   */

#ifndef __DEBUG_DUMP_H__
#define __DEBUG_DUMP_H__

#include <assert.h>
#include <stdio.h>

#include "ddsfile.h"

#if defined(__cplusplus)
extern "C" {
#endif 

typedef enum {
	PPM_P3,
	PPM_P6
} DebugDumpFormat;


// Function Prototype
void debugDump( uint8_t* data, char* infile, CellUtilDDSTexture* dds, CellGtfTextureAttribute* attrib );

#if defined(__cplusplus)
}
#endif 

#endif //  __DEBUG_DUMP_H__
