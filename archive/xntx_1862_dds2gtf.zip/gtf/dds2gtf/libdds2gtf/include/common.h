/*   SCE CONFIDENTIAL                                       */
/*   PLAYSTATION(R)3 Programmer Tool Runtime Library 192.001 */
/*   Copyright (C) 2007 Sony Computer Entertainment Inc.    */
/*   All Rights Reserved.                                   */

#ifndef __COMMON_H__ // [
#define __COMMON_H__

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef WIN32 // [
#include <tchar.h>
#include "type_def.h"
#else       // ] [
#include <unistd.h>
#endif       // ]

#include "gtftexture_offline.h"  // gtf file format definition
#include "error.h"	 // g_Error
#include "gcm_info.h"
#include "ddsfile.h"


// alignment for begging of texture data in GTF file
#define ALIGNMENT_TO_TEXTUREDATA_IN_GTF 128
// alignment for address of each cubemap face of 2D texture
#define ALIGNMENT_CUBE_FACE 128
// alignment for address of each volume texture face of 3D texture
#define ALIGNMENT_3D_VTC_VOL  1
#define ALIGNMENT_3D_SWIZZLE_VOL  1
#define ALIGNMENT_3D_LINEAR_VOL  1
// alignment for address of begining of each mimap of 3D texture
#define ALIGNMENT_3D_VTC_MIP 128 
#define ALIGNMENT_3D_SWIZZLE_MIP 1 
#define ALIGNMENT_3D_LINEAR_MIP 1 

#define DUMMY_ALPHA 0xFF

// Debug message output target
#define STDOUT stdout
#define STDERR stdout

typedef enum {
	// cancel swizzling even if swizzle option is set.
	// but put linear texture in memory as swizzle layout.
	CANCEL_SWIZZLE = 0,  

    // do swizzle conversion if swizzle option is set and is swizzlable.
	ALLOW_SWIZZLE = 1,

	// force swizzling even if swizzle option is not set.
	// please use with care (it may crash).
	FORCE_SWIZZLE = 2,

	// force linear layout, even if swizzle option is set and is swizzlable.
	FORCE_LINEAR = 3,

} texConvSwizzleOption;

#if defined(__cplusplus)
extern "C" {
#endif 

#ifdef __DEBUG__ // [
#	define DEBUG_LINE \
		fprintf( STDERR, "File %s: Line %d\n", __FILE__, __LINE__ ); \
		fflush( STDERR );
#	define dprintf(x) printf("dp %s %d:",__FILE__,__LINE__);printf x
#else  // ][
#	define DEBUG_LINE 
#	define dprintf(x)
#endif // ]

static inline uint8_t* Pad_ptr( uint8_t* x, uint32_t pad ) 
{
	assert( pad != 0 );	
	return (uint8_t*)((((uint32_t)x+pad-1)/pad) * pad);
}

static inline uint32_t Pad_uint( uint32_t x, uint32_t pad ) 
{
	assert( pad != 0 );	
	return (((x+pad-1)/pad) * pad);
}

#if defined(__cplusplus)
}
#endif 

#endif  // __COMMON_H__ ]
