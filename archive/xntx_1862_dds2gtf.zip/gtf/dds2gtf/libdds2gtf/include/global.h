/*   SCE CONFIDENTIAL                                       */
/*   PLAYSTATION(R)3 Programmer Tool Runtime Library 192.001 */
/*   Copyright (C) 2007 Sony Computer Entertainment Inc.    */
/*   All Rights Reserved.                                   */

#ifndef __GLOBAL_H__ // {
#define __GLOBAL_H__

#if defined(__cplusplus)
extern	"C" {
#endif //

// Global flag & variables
extern uint8_t g_FlagSwizzle;
extern uint8_t g_FlagPack;
extern uint8_t g_FlagUnnormalize;
extern uint8_t g_VerboseMode;
extern uint8_t g_DetailedVerboseMode;
extern uint8_t g_FlagForcePitch64;
extern uint8_t g_ErrorReport;
extern uint8_t g_DebugDump;
extern uint8_t g_FlagAlignPitch;

extern uint32_t g_AlignPitchSize;
extern uint32_t g_OriginalAlignPitchSize;

#if defined(__cplusplus)
}
#endif //

#endif  // } __GLOBAL_H__
