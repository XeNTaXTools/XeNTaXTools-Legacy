/*   SCE CONFIDENTIAL                                       */
/*   PLAYSTATION(R)3 Programmer Tool Runtime Library 192.001 */
/*   Copyright (C) 2007 Sony Computer Entertainment Inc.    */
/*   All Rights Reserved.                                   */

#ifndef __GCM_INFO_H__
#define __GCM_INFO_H__

#include <assert.h>
#include <stdio.h>
#include "gtftexture_offline.h"

#ifdef __PPU__
#include <PSGL/psgl.h>
#include <PSGL/psglu.h>
#else
#define _GDI32_
#define WINGDIAPI
#define APIENTRY
#endif

#include "ddsfile.h"

#if defined(__cplusplus)
extern "C" {
#endif 

#define GTF_TRUE  CELL_GCM_TRUE
#define GTF_FALSE CELL_GCM_FALSE

typedef struct {
	uint32_t  dds_format;
	uint8_t   gcm_format;
} FormatMatchingTable;

// Function Prototype
void setupHeaderAndAttribute( CellGtfFileHeader* gtf_header, CellGtfTextureAttribute* gtf_attrib, 
		   uint8_t format, uint8_t swizzle, uint8_t mipmap, uint8_t cubemap, uint32_t remap,
		   uint16_t width, uint16_t height, uint16_t depth, uint16_t bytePerPixel, uint8_t isDXT );
uint32_t getRemap( CellUtilDDSTexture* dds );
uint8_t getGcmFormat( uint32_t dds_format );
int countBit( uint32_t bits );
uint32_t toPowOf2( uint32_t x );

#if defined(__cplusplus)
}
#endif 

#endif  //__GCM_INFO_H__
