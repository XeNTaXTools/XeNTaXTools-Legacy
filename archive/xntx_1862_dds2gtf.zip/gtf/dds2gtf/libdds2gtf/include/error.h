/*   SCE CONFIDENTIAL                                       */
/*   PLAYSTATION(R)3 Programmer Tool Runtime Library 192.001 */
/*   Copyright (C) 2007 Sony Computer Entertainment Inc.    */
/*   All Rights Reserved.                                   */

#ifndef __ERROR_H__
#define __ERROR_H__

#include <stdio.h>        // for printf()
#include "gtftexture_offline.h"  // gtf file format definition

#if defined(__cplusplus)
extern "C" {
#endif 

// Application wide variable
extern uint32_t g_Error;

// Function Prototypes
void analyzeError();
void verbosePrintHeader( CellGtfFileHeader* header, CellGtfTextureAttribute* attrib);
const char* getFormatString(uint8_t format);

// Error macro
#define GTF_UNKNOWN_OPTION     ( 1 << 0 )
#define GTF_UNKNOWN_INPUT_FILE ( 1 << 1 )
#define GTF_3_COMPONENT_INPUT  ( 1 << 2 )

#if defined(__cplusplus)
}
#endif 

#endif // __ERROR_H__
