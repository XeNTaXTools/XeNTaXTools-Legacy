/*   SCE CONFIDENTIAL                                       */
/*   PLAYSTATION(R)3 Programmer Tool Runtime Library 192.001 */
/*   Copyright (C) 2007 Sony Computer Entertainment Inc.    */
/*   All Rights Reserved.                                   */

#ifndef __DDS_LOADER_H__
#define __DDS_LOADER_H__

#include "type_def.h"

#if defined(__cplusplus)
extern "C" {
#endif

// surface description flags
#define 	DDSF_MAX_MIPMAPS	16
#define 	DDSF_MAX_VOLUME	    512
#define 	DDSF_MAX_TEXTURES	16		

#define		DDSF_CAPS           0x00000001
#define 	DDSF_HEIGHT         0x00000002
#define 	DDSF_WIDTH          0x00000004
#define 	DDSF_PITCH          0x00000008
#define 	DDSF_PIXELFORMAT    0x00001000
#define 	DDSF_MIPMAPCOUNT    0x00020000
#define 	DDSF_LINEARSIZE     0x00080000
#define 	DDSF_DEPTH			0x00800000

// pixel format flags
#define		DDSF_ALPHAPIXELS	0x00000001
#define		DDSF_FOURCC			0x00000004
#define		DDSF_RGB			0x00000040
#define		DDSF_RGBA			0x00000041
#define		DDSF_LUMINANCE		0x00020000
#define		DDSF_BUMPDUDV		0x00080000

// dwCaps1 flags
#define DDSF_COMPLEX			0x00000008
#define DDSF_TEXTURE			0x00001000
#define DDSF_MIPMAP				0x00400000

// dwCaps2 flags
#define DDSF_CUBEMAP			0x00000200l
#define DDSF_CUBEMAP_POSITIVEX  0x00000400l
#define DDSF_CUBEMAP_NEGATIVEX  0x00000800l
#define DDSF_CUBEMAP_POSITIVEY  0x00001000l
#define DDSF_CUBEMAP_NEGATIVEY  0x00002000l
#define DDSF_CUBEMAP_POSITIVEZ  0x00004000l
#define DDSF_CUBEMAP_NEGATIVEZ  0x00008000l
#define DDSF_CUBEMAP_ALL_FACES  0x0000FC00l
#define DDSF_VOLUME				0x00200000l

// format that will be used in TexConv lib
// compressed texture types
#define FOURCC_DXT1				0x31545844
#define FOURCC_DXT3				0x33545844
#define FOURCC_DXT5				0x35545844

#define FOURCC_R16F             0x6F
#define FOURCC_G16R16F          0x70
#define FOURCC_A16B16G16R16F    0x71
#define FOURCC_R32F             0x72
#define FOURCC_A32B32G32R32F    0x74

#define FOURCC_YVYU             0x59565955
#define FOURCC_YUY2             0x32595559
#define FOURCC_R8G8_B8G8        0x47424752
#define FOURCC_G8R8_G8B8        0x42475247

// DDS format
// NOTE: These enums are not generic.
//       Only used in this library.
//
enum {
	FORMAT_B8=0xC0FFEE,
	FORMAT_A1R5G5B5,// EF
	FORMAT_Y16_X16, // F0
	FORMAT_G8B8,    // F1
	FORMAT_R6G5B5,  // F2
	FORMAT_A4R4G4B4, // F3
	FORMAT_ABGR,// F4
	FORMAT_ARGB,// F5
	FORMAT_X16,
	FORMAT_D8R8G8B8,
	FORMAT_R5G6B5,
	FORMAT_RGB,
	FORMAT_GBAR,
	FORMAT_BGRA,
	FORMAT_RABG,
	FORMAT_RGBA,
	FORMAT_X1R5G5B5,
};

typedef struct {
	unsigned short col0;
	unsigned short col1;
	unsigned char row[4];
} CellUtilDXTCColBlock;

typedef struct {
	unsigned short row[4];
} CellUtilDXTC3AlphaBlock;

typedef struct {
	unsigned char alpha0;
	unsigned char alpha1;
	unsigned char row[6];
} CellUtilDXTC5AlphaBlock;

typedef struct {
	uint32_t size;
	uint32_t flags;
	uint32_t fourCC;
	uint32_t rgbBitCount;
	uint32_t rbitMask;
	uint32_t gbitMask;
	uint32_t bbitMask;
	uint32_t abitMask;
} CellUtilDDSPixelFormat;

typedef struct {
	uint32_t size;
	uint32_t flags;
	uint32_t height;
	uint32_t width;
	uint32_t pitchOrLinearSize;
	uint32_t depth;
	uint32_t mipMapCount;
	uint32_t reserved1[11];
	CellUtilDDSPixelFormat ddspf;
	uint32_t caps1;
	uint32_t caps2;
	uint32_t reserved2[3];
} CellUtilDDSHeader;

typedef enum {
	TEXTURE_NONE,
	TEXTURE_FLAT,    // 1D, 2D, and rectangle textures
	TEXTURE_3D,
	TEXTURE_CUBEMAP
} CellUtilTextureType;

typedef struct {
	unsigned char *pixels[DDSF_MAX_MIPMAPS];		//the mip map images 
} CellUtilDDSImage;

typedef struct {
	unsigned char	*buffer;	// pointer to loaded dds file
	uint32_t		size;		// file size
	uint32_t		format;		// compression used or pixel format
	uint32_t		components; // number of channels 
	uint32_t		width;		// width of base image in pixels
	uint32_t		height;		// height of based image in pixels
	uint32_t        depth;      // depth of texture (only 3D texture)
	uint32_t		mips;		// number of mip levels
	uint32_t		surfaces;	// number of surfaces (1: texture, 6: cube map)
	CellUtilDDSImage image[6];
	CellUtilDDSPixelFormat ddspf;
	// For 3D texture
	CellUtilDDSImage vol_image[DDSF_MAX_VOLUME];
	// For texture with border 
	uint32_t        border;     // non-zero if border is available
} CellUtilDDSTexture;

void cellUtilSetCallback(void (*func)(void *func, const char *string));
int cellUtilDDSRead(const char *filename, CellUtilDDSTexture *texture);
int cellUtilDDSUpdate(const char *filename, CellUtilDDSTexture *texture);

int32_t getImageSize(uint32_t w, uint32_t h,
					 uint32_t components, uint32_t format);

#ifdef __PPU__
extern GLuint cellUtilPSGLLoadDDSTexture(const char *filename);
extern GLuint cellUtilPSGLLoadDDSTextureCubeMap(const char *filename);
extern GLuint cellUtilPSGLCreateTextureFromFile(const char *filename);
#endif

#if defined(__cplusplus)
}
#endif

#endif /* __DDS_LOADER_H__ */
