/*   SCE CONFIDENTIAL                                       */
/*   PLAYSTATION(R)3 Programmer Tool Runtime Library 192.001 */
/*   Copyright (C) 2007 Sony Computer Entertainment Inc.    */
/*   All Rights Reserved.                                   */

#ifndef __TEXCONV_H__
#define __TEXCONV_H__

/* Macros for conversion option */
#define CELL_TEXCONV_FLAG_SWIZZLIZE        ( 1 << 0 )
#define CELL_TEXCONV_FLAG_ERROR_REPORT     ( 1 << 1 )
#define CELL_TEXCONV_FLAG_VERBOSE          ( 1 << 2 )
#define CELL_TEXCONV_FLAG_DEBUG_DUMP       ( 1 << 3 )
#define CELL_TEXCONV_FLAG_UNNORMALIZE      ( 1 << 4 )
#define CELL_TEXCONV_FLAG_PACKED           ( 1 << 5 )
#define CELL_TEXCONV_FLAG_DETAILED_VERBOSE ( 1 << 6 )
#define CELL_TEXCONV_FLAG_USER_GIVEN_PITCH ( 1 << 7 )
#define CELL_TEXCONV_FLAG_ALIGN_PITCH_64   ( 1 << 8 )

/* Error defined in this library */
#define CELL_TEXCONV_ERROR -1
#define CELL_TEXCONV_OK     0

#if defined(__cplusplus) // [
extern	"C" {
#endif // ]

#ifndef __PPU__ // [
typedef signed   char      GTF_INT8_T;
typedef signed   short     GTF_INT16_T;
typedef signed   int       GTF_INT32_T;
typedef signed   long long GTF_INT64_T;
typedef unsigned char      GTF_UINT8_T;
typedef unsigned short     GTF_UINT16_T;
typedef unsigned int       GTF_UINT32_T;
typedef unsigned long long GTF_UINT64_T;
#endif // ]

int dds2gtf_output_to_file
(
	char** inputFilenames,
	GTF_INT32_T inputFileCount,
	const char* outputFilename,
	GTF_UINT32_T option
);

int dds2gtf_output_to_file_with_id
(
	char* inputFilename,
	const char* outputFilename,
	GTF_UINT32_T id,
	GTF_UINT32_T option
);

void dds2gtf_set_pitch_size( GTF_UINT32_T pitch_size );

#if defined(__cplusplus) // [
}
#endif // ]


#endif //  __TEXCONV_H__
