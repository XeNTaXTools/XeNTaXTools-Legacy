/*   SCE CONFIDENTIAL                                       */
/*   PLAYSTATION(R)3 Programmer Tool Runtime Library 192.001 */
/*   Copyright (C) 2007 Sony Computer Entertainment Inc.    */
/*   All Rights Reserved.                                   */

/* 
 *  Header for swizzle functions
 */

#ifndef __SWIZZLE_H__
#define __SWIZZLE_H__

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "type_def.h"

#if defined(__cplusplus)
extern	"C" {
#endif //

int convertLinearToSwizzle(uint8_t *dst, 
                           const uint8_t *src,
						   const uint32_t width,
						   const uint32_t height,
						   const uint32_t depth,
						   const uint32_t bytesPerPixel);

#if defined(__cplusplus)
}
#endif //

#endif //  __SWIZZLE_H__
