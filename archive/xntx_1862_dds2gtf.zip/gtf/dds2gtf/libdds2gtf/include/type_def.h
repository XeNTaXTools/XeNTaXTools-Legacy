/*   SCE CONFIDENTIAL                                       */
/*   PLAYSTATION(R)3 Programmer Tool Runtime Library 192.001 */
/*   Copyright (C) 2007 Sony Computer Entertainment Inc.    */
/*   All Rights Reserved.                                   */

#ifndef __TYPE_DEF_H__
#define __TYPE_DEF_H__

//#define NULL (0)
#if defined(__cplusplus)
extern "C" {
#endif 

#ifndef __PPU__ // {
typedef signed   char      int8_t;
typedef signed   short     int16_t;
typedef signed   int       int32_t;
typedef signed   long long int64_t;
typedef unsigned char      uint8_t;
typedef unsigned short     uint16_t;
typedef unsigned int       uint32_t;
typedef unsigned long long uint64_t;
#endif // __PPU__ // }

#if defined(__cplusplus)
}
#endif 

#endif // __TYPE_DEF_H__

