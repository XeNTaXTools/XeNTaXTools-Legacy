/*   SCE CONFIDENTIAL                                       */
/*   PLAYSTATION(R)3 Programmer Tool Runtime Library 192.001 */
/*   Copyright (C) 2007 Sony Computer Entertainment Inc.    */
/*   All Rights Reserved.                                   */

/* 
 *  Utility functions for TexConv lib.
 */ 

#ifndef __UTILS_H__ // {
#define __UTILS_H__

#include "type_def.h"
#include "ddsfile.h"

#if defined(__cplusplus)
extern "C" {
#endif

int isPowOf2( uint32_t x );
int isLittleEndianMachine();
void swap( uint32_t* x );
void endianSwap( uint8_t* dst, uint32_t imageSize, uint32_t bytesPerElem );
void swapEndianHeader( CellGtfFileHeader* gtf_header );
void swapEndianAttribute( CellGtfTextureAttribute* gtf_attrib );
void headerAttribEndianSwap( CellGtfFileHeader* gtf_header, CellGtfTextureAttribute gtf_attrib[] );
uint32_t clz(uint32_t x);
uint32_t log2(uint32_t x);
int isS3TC( const CellUtilDDSTexture* dds ) ;
int isDimensionPowerOf2( const CellUtilDDSTexture* dds ) ;
int isDepthPowerOf2( const CellUtilDDSTexture* dds ) ;
int isSwizzlable( const CellUtilDDSTexture* dds );
int isFloatTexture( uint32_t format );
uint32_t getGTFOutputFilesize( CellUtilDDSTexture* dds, uint32_t dummy_component );
int testPitch( CellUtilDDSTexture* dds );
uint32_t getPitch( uint8_t is_linear, CellUtilDDSTexture* dds );
void setupFileHeader( CellGtfFileHeader* header, uint32_t Version, uint32_t Size, uint32_t numAttribute );
void setupTextureHeader( CellGtfTextureAttribute* gtf_attrib, CellUtilDDSTexture *dds,
                       uint32_t index, uint32_t OffsetToTex, uint32_t textureSize,
                       uint8_t swizzle, uint8_t unnormalize );
uint32_t getTotalHeaderSize( int fileCount );
uint32_t getOffsetToTex( int fileCount, uint32_t output_texturesize );


#if defined(__cplusplus)
}
#endif

#endif  // } __UTILS_H__
