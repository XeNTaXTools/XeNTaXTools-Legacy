/*   SCE CONFIDENTIAL                                       */
/*   PLAYSTATION(R)3 Programmer Tool Runtime Library 192.001 */
/*   Copyright (C) 2007 Sony Computer Entertainment Inc.    */
/*   All Rights Reserved.                                   */

#include "error.h"

// Globally accessed variable for error recording
uint32_t g_Error;

typedef struct {
	const char* string;
	uint8_t format;
} FormatStringPair;

const FormatStringPair sFormatTable[] = {
	{"CELL_GCM_TEXTURE_B8",                    0x81 }, 
	{"CELL_GCM_TEXTURE_A1R5G5B5",              0x82 },
	{"CELL_GCM_TEXTURE_A4R4G4B4",              0x83 },
	{"CELL_GCM_TEXTURE_R5G6B5",                0x84 },
	{"CELL_GCM_TEXTURE_A8R8G8B8",              0x85 },
	{"CELL_GCM_TEXTURE_COMPRESSED_DXT1",       0x86 },
	{"CELL_GCM_TEXTURE_COMPRESSED_DXT23",      0x87 },
	{"CELL_GCM_TEXTURE_COMPRESSED_DXT45",      0x88 },
	{"CELL_GCM_TEXTURE_G8B8",                  0x8B },
	{"CELL_GCM_TEXTURE_R6G5B5",                0x8F },
	{"CELL_GCM_TEXTURE_DEPTH24_D8",            0x90 },
	{"CELL_GCM_TEXTURE_DEPTH24_D8_FLOAT",      0x91 },
	{"CELL_GCM_TEXTURE_DEPTH16",               0x92 },
	{"CELL_GCM_TEXTURE_DEPTH16_FLOAT",         0x93 },
	{"CELL_GCM_TEXTURE_X16",                   0x94 },
	{"CELL_GCM_TEXTURE_Y16_X16",               0x95 },
	{"CELL_GCM_TEXTURE_R5G5B5A1",              0x97 },
	{"CELL_GCM_TEXTURE_COMPRESSED_HILO8",      0x98 },
	{"CELL_GCM_TEXTURE_COMPRESSED_HILO_S8",    0x99 },
	{"CELL_GCM_TEXTURE_W16_Z16_Y16_X16_FLOAT", 0x9A },
	{"CELL_GCM_TEXTURE_W32_Z32_Y32_X32_FLOAT", 0x9B },
	{"CELL_GCM_TEXTURE_X32_FLOAT",             0x9C },
	{"CELL_GCM_TEXTURE_D1R5G5B5",              0x9D },
	{"CELL_GCM_TEXTURE_D8R8G8B8",              0x9E },
	{"CELL_GCM_TEXTURE_Y16_X16_FLOAT",         0x9F },
	{"CELL_GCM_TEXTURE_B8R8_G8R8",             0x8D },
	{"CELL_GCM_TEXTURE_R8B8_R8G8",             0x8E },
	{"Unknown format",                         0x00 },
};


const char* getFormatString(uint8_t format) 
{
	uint32_t i=0;
	for( i=0; i<sizeof(sFormatTable)/sizeof(sFormatTable[0]); i++ ) {
		if( format == sFormatTable[i].format )
			break;
	}
	return sFormatTable[i].string;
}

void analyzeError( void ) 
{
	#ifdef _DEBUG_
	printf( "g_Error: 0x%08x\n", g_Error );
	#endif // _DEBUG_
 
	if( g_Error & GTF_UNKNOWN_OPTION )
	{ printf("Warning: Unknown command line option.\n" ); }
	if( g_Error & GTF_UNKNOWN_INPUT_FILE )
	{ printf("Warning: Unknown image format. Only PNG and DDS file are supported.\n"); }

}

void verbosePrintHeader( CellGtfFileHeader* gtf_header, CellGtfTextureAttribute gtf_attrib[] )
{
	printf( "GTF FileHeader & TextureAttribute:\n" );
	// header
	printf( "  Version:            0x%08x\n", gtf_header->version );
	printf( "  Size:               %d (0x%x)\n", gtf_header->size, gtf_header->size);
	printf( "  Number of Textures: %d\n", gtf_header->numTexture );
	for( uint32_t i=0; i<gtf_header->numTexture; i++ ) {
		printf( "  [Texture %d Attirbute Header]\n", i );

		//
		// attribute
		//
		printf( "    id:           0x%x\n", gtf_attrib[i].id );
		printf( "    OffsetToTex   %d\n",   gtf_attrib[i].offsetToTex );
		printf( "    TextureSize   %d (0x%x)\n", gtf_attrib[i].textureSize, gtf_attrib[i].textureSize);

		//
		// tex attribute
		//
		printf( "    Format:       0x%x  texture(0x%x) %s\n", 
		         gtf_attrib[i].tex.format, gtf_attrib[i].tex.format & 0x9f, 
			     getFormatString(gtf_attrib[i].tex.format & 0x9f) );
		printf( "    mipmap:       0x%x\n", gtf_attrib[i].tex.mipmap );
		printf( "    dimension:    0x%x\n", gtf_attrib[i].tex.dimension );
		printf( "    cubemap:      0x%x\n", gtf_attrib[i].tex.cubemap );
		printf( "    remap:        0x%x\n", gtf_attrib[i].tex.remap );
		printf( "    width:        0x%x\n", gtf_attrib[i].tex.width );
		printf( "    height:       0x%x\n", gtf_attrib[i].tex.height );
		printf( "    depth:        0x%x\n", gtf_attrib[i].tex.depth );
		printf( "    pitch:        0x%x\n", gtf_attrib[i].tex.pitch );
		printf( "    location:     0x%x\n", gtf_attrib[i].tex.location );
		printf( "    offset:       0x%x\n", gtf_attrib[i].tex.offset );
	}
}

