/*   SCE CONFIDENTIAL                                       */
/*   PLAYSTATION(R)3 Programmer Tool Runtime Library 192.001 */
/*   Copyright (C) 2007 Sony Computer Entertainment Inc.    */
/*   All Rights Reserved.                                   */

/* 
 *  Utility functions for TexConv lib.
 */ 

#include <stdio.h>
#include <stdlib.h>
#include <string.h> // for memcpy()

#include "common.h"
#include "type_def.h"
#include "gcm_info.h"
#include "ddsfile.h"
#include "utils.h"
#include "global.h"

int isPowOf2( uint32_t x )
{
	return ((x & (x-1)) == 0);
}

int isLittleEndianMachine() {
	int n=1;
	if( *(char*)&n ) return 1;
	else return 0;
}

void swap( uint32_t* x ) {
	*x = (*x << 16) | (*x >> 16);
}

// 
// Function Name: endianSwap
//
// Description:
//   swap endianness of input memory area
// 
void endianSwap( uint8_t* dst, uint32_t imageSize, uint32_t bytesPerElem ) 
{
	uint8_t* traverser = dst;

	assert( bytesPerElem <= 4 );

	if( bytesPerElem > 2 ) {
		char tmp_buf[4] = {0};

		for( uint32_t i=0; i<imageSize; i+=bytesPerElem ) {
			memcpy( tmp_buf, traverser, bytesPerElem );

			for( int j=bytesPerElem-1; j>=0; j-- ) {
				//printf( "i=%d, j=%d, bytesPerElem-j-1 = %d\n", i, j, bytesPerElem-j-1 );
				traverser[j] = tmp_buf[bytesPerElem-j-1];
			}
			traverser += bytesPerElem;
		}
	}
	else {
		for( uint32_t i=0; i<imageSize; i+=bytesPerElem ) {
			swab( (char*)traverser, (char*)traverser, bytesPerElem );	
			traverser += bytesPerElem;
		}
	}
}

#define CONV(x) {                           \
	swab( (char*)&x, (char*)&x, sizeof(x)); \
	if( sizeof(x) == 4 )                    \
		swap( (uint32_t*) &x );             \
} 

void swapEndianHeader( CellGtfFileHeader* gtf_header )
{
	CONV( gtf_header->version );
	CONV( gtf_header->size );
	CONV( gtf_header->numTexture );
}

void swapEndianAttribute( CellGtfTextureAttribute* gtf_attrib )
{
	CONV( gtf_attrib->id );
	CONV( gtf_attrib->offsetToTex );
	CONV( gtf_attrib->textureSize );

	// tex attribute
	CONV( gtf_attrib->tex.format );
	CONV( gtf_attrib->tex.mipmap );
	CONV( gtf_attrib->tex.dimension );
	CONV( gtf_attrib->tex.cubemap );
	CONV( gtf_attrib->tex.remap );
	CONV( gtf_attrib->tex.width );
	CONV( gtf_attrib->tex.height );
	CONV( gtf_attrib->tex.depth );
	CONV( gtf_attrib->tex.pitch );
	CONV( gtf_attrib->tex.location );
	CONV( gtf_attrib->tex.offset );
}

// 
// Function Name: headerAttribEndianSwap
//
// Description:
//  Swap endianness of GTF header and attribute.
//
void headerAttribEndianSwap( CellGtfFileHeader* gtf_header, CellGtfTextureAttribute gtf_attrib[] )
{
	int numAttrib = gtf_header->numTexture;

	// header
	swapEndianHeader( gtf_header );

	// attribute
	for( int i=0; i< numAttrib; i++ ) {
		swapEndianAttribute( &gtf_attrib[i] );
	}
}

uint32_t clz(uint32_t x)
{
	uint32_t y;
	uint32_t n = 32;

	y = x >> 16; if (y != 0) { n = n - 16; x = y; }
	y = x >>  8; if (y != 0) { n = n -  8; x = y; }
	y = x >>  4; if (y != 0) { n = n -  4; x = y; }
	y = x >>  2; if (y != 0) { n = n -  2; x = y; }
	y = x >>  1; if (y != 0) { return n - 2; }
	return n - x;
}

uint32_t log2(uint32_t x)
{
	return 31 - clz(x);
}


// Function name: isS3TC
//
// Description:
//  returns 1 if format is DXT1.
//  returns 3 if format is DXT3.
//  returns 5 if format is DXT5.
//  returns zero if format is not S3TC compressed texture.
//
int isS3TC( const CellUtilDDSTexture* dds ) 
{

	switch(dds->format) {
	case 0x83F1: // GL_COMPRESSED_RGBA_S3TC_DXT1_EXT
		return 1;
	case 0x83F2: // GL_COMPRESSED_RGBA_S3TC_DXT3_EXT
		return 3;
	case 0x83F3: // GL_COMPRESSED_RGBA_S3TC_DXT5_EXT
		return 5;
	default:
		return 0;
	}
}

// Function name: isDimensionPowerOf2
//
// Description:
//  returns non-zero if given DDS dimension is power of 2
//  returns zero if given DDS dimension is not power of 2
//
int isDimensionPowerOf2( const CellUtilDDSTexture* dds ) 
{
	// DXT format requires width and height to be multiple of 4
	if( isPowOf2(dds->width) && isPowOf2(dds->height) )
		return 1;
	else
		return 0;
}

int isDepthPowerOf2( const CellUtilDDSTexture* dds ) 
{
	// DXT format requires width and height to be multiple of 4
	if( isPowOf2(dds->depth) )
		return 1;
	else
		return 0;
}



// Function Name: isSwizzlable
// 
// 
// Description:
//  Returns 1 if format can be converted to swizzle.
//  Returns 0 otherwize.
//
int isSwizzlable( const CellUtilDDSTexture* dds )
{
	// Can't convert S3TC format
	// NOTE: Although you need to set Swizzle flag if S3TC format's
	//       width and height are power of 2
	//
	if( isS3TC( dds )) return 0;

	// Maybe add check for VTC compressed format??
	//

	// width, height, and depth must be power of 2
	if( !isDimensionPowerOf2( dds ))
		return 0;
	if( !isDepthPowerOf2( dds ) )
		return 0;

	switch( dds->format ) {
	case FOURCC_A16B16G16R16F:
	case FOURCC_A32B32G32R32F:
	case FOURCC_R32F:
	case FORMAT_RABG:
	case FORMAT_RGBA:
	case FORMAT_ARGB:
	case FORMAT_ABGR:
	case FORMAT_BGRA:
	case FORMAT_GBAR:
	case FORMAT_D8R8G8B8:
	case FORMAT_B8:
	case FORMAT_A4R4G4B4:
	case FORMAT_A1R5G5B5:
	case FORMAT_R5G6B5:
	case FOURCC_G16R16F:
		return 1;
	case FORMAT_RGB: // ??
	case FORMAT_R6G5B5:
	case FOURCC_R16F:
	case FORMAT_X16:
	case FORMAT_Y16_X16:
	case FORMAT_G8B8:
	case FOURCC_YVYU:
	case FOURCC_R8G8_B8G8:
	case FOURCC_G8R8_G8B8:
	default:
		return 0;
	}
}

// Function name: isFloatTexture
// 
// Description:
//   Returns 1 if format is float texture
//   Returns 0 otherwise.
//
int isFloatTexture( uint32_t format )
{
	switch(format) {
	case FOURCC_A16B16G16R16F:	// compnents is 8
	case FOURCC_A32B32G32R32F:	// compnents is 16 
	case FOURCC_R16F:
	case FOURCC_G16R16F:
	case FOURCC_R32F:
		return 1;
	default:
		return 0;
	}
}

uint32_t getGTFOutputFilesize( CellUtilDDSTexture* dds, uint32_t dummy_component )
{
	uint32_t filesize = 0;
	uint32_t width, height;
	uint32_t stride;
	
	assert( dds->surfaces > 0 );
	assert( dds->mips > 0 );
	assert( dummy_component != 3 );

	stride = dds->width;

	// Huge branch if texture is volume texture
	//
	if( dds->depth > 0 ) {
		//
		// Texture is 3D texture
		//
		uint32_t depth = dds->depth;
		width = dds->width;
		height = dds->height;

		for( uint32_t mip=0; mip<dds->mips; mip++ ) {

			int dxt_type = isS3TC(dds);

			for( uint32_t vol=0; vol<depth; vol++ ) {

				// TODO: check if this file size calculation is correct for all format(linear/swizzle/s3tc)
				// 
				if( dxt_type > 0) {
					// If S3TC is linear dimension (non power of 2), use stride instead of width 
					// to calculate required memory size.
					//
					if( isDimensionPowerOf2(dds)) {
						// Power of 2 S3TC format
						filesize += getImageSize(width, height, dummy_component, dds->format);
						filesize = Pad_uint( filesize, ALIGNMENT_3D_VTC_VOL ); 
					}
					else {
						// Linear S3TC format
						// Stride is used instead of width.
						filesize += getImageSize(Pad_uint(stride,4), Pad_uint(height,4), dummy_component, dds->format);
					}
				}
				else {
					// texture is not dxt
					//
					// NOTE: 
					//   If linear texture, there's no alignment restriction.
					// 
					if( g_FlagSwizzle && isSwizzlable(dds)) {
						filesize += getImageSize(width, height, dummy_component, dds->format);
						filesize = Pad_uint( filesize, ALIGNMENT_3D_SWIZZLE_VOL ); 
					}
					else {
						filesize += getImageSize(stride, height, dummy_component, dds->format);
						filesize = Pad_uint( filesize, ALIGNMENT_3D_LINEAR_VOL ); 
					}
				}
			}		// loop over each depth

			// NOTE: 
			//   If linear texture, there's no alignment restriction.
			// 

			if(isS3TC(dds) && (!isDimensionPowerOf2(dds))) {
				// Each volume start at 128 byte alignment
				// NOTE: 
				//   Should the padding be filesize = Pad_uint( filesize, stride )  ??
				//
				uint32_t block_size = (dxt_type==1)? 8: 16;
				uint32_t pitch_size = ((Pad_uint(stride,4)+3)/4) * block_size;

				filesize = Pad_uint( filesize, pitch_size );
			}
			else if (g_FlagSwizzle && isSwizzlable(dds))
				filesize = Pad_uint( filesize, ALIGNMENT_3D_SWIZZLE_MIP ); 
			else
				filesize = Pad_uint( filesize, ALIGNMENT_3D_LINEAR_MIP ); 

			if (width != 1) { width /= 2; }
			if (height != 1) { height /= 2; }
			if (depth != 1) { depth /= 2; }

		}		// loop over each mip
		
		// SimonB: removed this line
		//filesize = Pad_uint( filesize, ALIGNMENT_TO_TEXTUREDATA_IN_GTF); 
	}
	else {
		// 
		// Texture is 2D texture
		//

		for( uint32_t face=0; face < dds->surfaces; face++ ) {	// each face
			width = dds->width;
			height = dds->height;

			// pad the face to the proper alignment
			if( face > 0 ) {
				// 128 byte alignment required for swizzle
				if( (g_FlagSwizzle && isSwizzlable(dds)) || isS3TC(dds))
					filesize = Pad_uint( filesize, ALIGNMENT_CUBE_FACE ); 
			}

			for( uint32_t mip=0; mip < dds->mips; mip++ ) {	// each mipmaps
				
				int dxt_type;

				// TODO: check if this file size calculation is correct for all format(linear/swizzle/s3tc)
				// 
				if((dxt_type = isS3TC(dds)) > 0) {

					// If S3TC is linear dimension (non power of 2), use stride instead of width 
					// to calculate required memory size.
					//
					if( isDimensionPowerOf2(dds)) {
						// Power of 2 S3TC format
						filesize += getImageSize(width, height, dummy_component, dds->format);
					}
					else {
						// Linear S3TC format
						// Stride is used instead of width.
						if( g_FlagAlignPitch ) 
							filesize += g_AlignPitchSize * (Pad_uint(height,4)+3)/4;
						else 
							filesize += getImageSize(Pad_uint(stride,4), Pad_uint(height,4), dummy_component, dds->format);
					}
				}
				else {
					if(g_FlagSwizzle && isSwizzlable(dds)) {
						filesize += getImageSize(width, height, dummy_component, dds->format);
					}
					else {
						if( g_FlagAlignPitch )
							filesize += g_AlignPitchSize * height;
						else 
							filesize += getImageSize(stride, height, dummy_component, dds->format);
					}
				}

				if( width != 1 )  width /= 2;
				if( height != 1 )  height /= 2;
			}

		}
	}

	return filesize;
}

// 
// Function Name getTexFormat
//
// Descritpion:
//  Given DDS format, compute the texture format used in GCM.
// 
// Return valude:
//  Gcm texture format computed from DDS format.
//
static uint8_t getTexFormat( CellUtilDDSTexture* dds, uint8_t swizzle, uint8_t unnormalize ) 
{
	uint8_t ret;

	// Data format?
	ret = getGcmFormat( dds->format );

	// Swizzle? Linear?
	if(isS3TC(dds)) {
		//
		// If format is S3TC, swizzle flag must be set if width and height are power of 2.
		// If width and height are not power of 2, then linear flag must be set.
		//
		if(isDimensionPowerOf2(dds))
			ret |= CELL_GCM_TEXTURE_SZ;
		else 
			ret |= CELL_GCM_TEXTURE_LN;
	}
	else {
		if(swizzle && isSwizzlable(dds))
			ret |= CELL_GCM_TEXTURE_SZ;
		else
			ret |= CELL_GCM_TEXTURE_LN;
	}

	// Normalized? Unnormalized?
	if( unnormalize )
		ret |= CELL_GCM_TEXTURE_UN;
	else 
		ret |= CELL_GCM_TEXTURE_NR;

	return ret;
}

// 
// Function Name: testPitch
//
// Description:
//   Compare the original texture pitch [org pitch] size against what user specified [user pitch].
//  
// Return value:
//   less than 0   : if [org pitch] <  [user pitch]
//   0             : if [org pitch] == [user pitch]
//   greater than 0: if [org pitch] >  [user pitch]
//
int testPitch( CellUtilDDSTexture* dds )
{
	int org_pitch = 0;
	int user_pitch = g_AlignPitchSize;
	int dummy_components = 0;
	int dxt_type = 0;	

	assert( dds != NULL );
	assert( user_pitch > 0 );

	// fake components because RSX doesn't support 3 components texture
	if( dds->components == 3 ) 
		dummy_components = 4;
	else
		dummy_components = dds->components;

	// Block size: DXT1   =  8 bytes
	//             DXT3/5 = 16 bytes
	//
	if((dxt_type=isS3TC(dds)) > 0) {
		uint32_t block_size = (dxt_type == 1)? 8:16;
		org_pitch = ((dds->width+3)/4) * block_size;
	}
	else
		org_pitch = dds->width*dummy_components;

	assert( org_pitch > 0 );
	return org_pitch - user_pitch;
}

// 
// Function Name getPitch
//
// Descritpion:
//	If GCM format is swizzled, then pitch must be 0. 
//  If user-spcified pitch size (if any) is smaller than
//  what this dds requires, we overwrite the user-specified
//  pitch size.
// 
// Return valude:
//  Gcm texture pitch.
//
uint32_t getPitch( uint8_t is_linear, CellUtilDDSTexture* dds )
{
	uint32_t ret = 0;
	uint32_t dummy_components = 0;

	// 
	// NOTE: CELL_GCM_TEXTURE_SZ is 0
	//
	if( is_linear > 0 ) {
		int dxt_type;	

		// fake components because RSX doesn't support 3 components texture
		if( dds->components == 3 ) 
			dummy_components = 4;
		else
			dummy_components = dds->components;

		// Block size: DXT1   =  8 bytes
		//             DXT3/5 = 16 bytes
		//
		if((dxt_type=isS3TC(dds)) > 0) {
			uint32_t block_size = (dxt_type == 1)? 8:16;
			ret = ((dds->width+3)/4) * block_size;
		}
		else
			ret = dds->width*dummy_components;

		if( g_FlagAlignPitch ) {
			assert( g_AlignPitchSize > 0 );
			
			// only if user-specified pitch size is bigger than texture's pitch.
			if( g_AlignPitchSize > ret ) 
				ret = g_AlignPitchSize;
		}

		// if force pitch to 64 bytes flag is up, align pitch size to 64.
		if( g_FlagForcePitch64 ) {
			if( g_DetailedVerboseMode && (ret & 63)) {
				fprintf( STDERR, "Adding %d bytes of padding to pitch size\n", 
				         64 - (ret & 63));
			}
			ret = Pad_uint( ret, 64 );
		}
	}
	else
		ret = 0;

	g_AlignPitchSize = ret;
	return ret;
}

//
// Function name: setupFileHader
//
// Description:
//  Just assign value to file header structure 
//
void setupFileHeader( CellGtfFileHeader* header, uint32_t Version, uint32_t Size, uint32_t numAttribute ) 
{
	// define GTF header for texture
	if( g_FlagPack )
		header->version = CELL_GTF_PACKED_VERSION;
	else 
		header->version = Version;

	header->size = Size;
	header->numTexture = numAttribute;
}

// 
// Function Name: setupTextureHeader 
// 
// Description:
//  setup texture header by given dds texture format header.
// toPowOf2
// 
void setupTextureHeader( CellGtfTextureAttribute* gtf_attrib, CellUtilDDSTexture *dds,
                              uint32_t index, uint32_t OffsetToTex, uint32_t textureSize,
							  uint8_t swizzle, uint8_t unnormalize )
{
	// assign each information to GTF attribute
	gtf_attrib->id = index;
	gtf_attrib->offsetToTex = OffsetToTex;
	gtf_attrib->textureSize = textureSize;

	// set up texture format (swizzle/normalizaed/etc)
	gtf_attrib->tex.format = getTexFormat( dds, swizzle, unnormalize );

	gtf_attrib->tex.mipmap    = dds->mips;
	gtf_attrib->tex.dimension = (dds->depth>0)? CELL_GCM_TEXTURE_DIMENSION_3:CELL_GCM_TEXTURE_DIMENSION_2;
	gtf_attrib->tex.cubemap   = (dds->surfaces == 6)? GTF_TRUE: GTF_FALSE;
	gtf_attrib->tex.remap     = getRemap(dds);
	gtf_attrib->tex.width     = dds->width;
	gtf_attrib->tex.height    = dds->height;
	gtf_attrib->tex.depth     = (dds->depth>0)? dds->depth: 1; 
	gtf_attrib->tex.pitch     = getPitch((gtf_attrib->tex.format & CELL_GCM_TEXTURE_LN), dds);
	gtf_attrib->tex.location  = CELL_GCM_LOCATION_LOCAL;
	gtf_attrib->tex._padding  = 0;
	gtf_attrib->tex.offset    = 0;	// we set this member at runtime
}

// Function Name: getTotalHeaderSize
//
// Description:
//  Returns size of header and texture attributes including padding zone.
//  
uint32_t getTotalHeaderSize( int fileCount )
{
	uint32_t ret = 0;

	assert( fileCount > 0 );
	
	ret += sizeof( CellGtfFileHeader );
	ret += fileCount * sizeof( CellGtfTextureAttribute );

	// Create padding space so that texture data starts at 128 byte
	// boundary relative to begining of File.
	// If pack option is specified, we won't put any padding.
	if( ! g_FlagPack )
		ret = Pad_uint( ret, ALIGNMENT_TO_TEXTUREDATA_IN_GTF );

	return ret;
}

//  Function name: getOffsetToTex
//  Description: 
//   By given filecount and output_texturesize (offset), calculate the offset to 
//   actual texture data within file.
//
uint32_t getOffsetToTex( int fileCount, uint32_t output_texturesize )
{
	uint32_t ret = 0;
	
	ret = getTotalHeaderSize( fileCount );
	ret += output_texturesize;

	return ret;
}

