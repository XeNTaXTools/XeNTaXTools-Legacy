/*   SCE CONFIDENTIAL                                       */
/*   PLAYSTATION(R)3 Programmer Tool Runtime Library 192.001 */
/*   Copyright (C) 2007 Sony Computer Entertainment Inc.    */
/*   All Rights Reserved.                                   */

// TexConv.cpp
//

#include "common.h"
#include "dds2gtf.h"
#include "debug_dump.h"
#include "swizzle.h"
#include "utils.h"
#include "global.h"

#include "version.h"

static void outputToGtfFile( const char* outfile, 
                             CellGtfFileHeader* gtf_header, 
                             CellGtfTextureAttribute gtf_attribs[], 
							 int count,
                             uint8_t* converted_image, uint32_t size ) 
{
	uint32_t nwrite;
	FILE* fp;
	uint32_t header_written = 0;

	assert( count > 0 );
	assert( size > 0 );


	// open file for writing
	fp = fopen( outfile, "wb" );
	if( fp == NULL ) {
		perror( "fopen" );
		exit(1);
	}

	// write gtf header
	nwrite = fwrite( gtf_header, 1, sizeof(CellGtfFileHeader), fp );
	if( nwrite < sizeof(CellGtfFileHeader) ) {
		fprintf( STDERR, "%s line %d: fwrite failed...\n", __FUNCTION__, __LINE__ );
		return;
	}
	header_written += nwrite;

	// wirte gtf attribute
	for( int i=0; i<count; i++ ) {
		nwrite = fwrite( &gtf_attribs[i], 1, sizeof(CellGtfTextureAttribute), fp );
		if( nwrite < sizeof(CellGtfTextureAttribute) ) {
			fprintf( STDERR, "%s line %d: fwrite failed...\n", __FUNCTION__, __LINE__ );
			return;
		}
		header_written += nwrite;
	}

	// make padding space here (between end of attribute and actual texture data ) 
	if( ! g_FlagPack ) {
		int padding;
		padding = 128 - (header_written % 128);

		if( padding != 128 ) {
			for( int i=0; i < padding; i++ ) {
				char c = 'P';
				header_written += fwrite( &c, 1, 1, fp );
			}
		}
		assert( (header_written % 128) == 0 );
	}

	// wirte image data
	nwrite = fwrite( converted_image, 1, size, fp );
	if( nwrite < size ) {
		fprintf( STDERR, "%s line %d: fwrite failed...\n", __FUNCTION__, __LINE__ );
		return;
	}

	// close file
	fclose( fp );
}

// Function name: convertSurfaceToGtfFormat 
//
// Description:
//   Used by convertFrom{2D|3D}dds2gtf.
// 
// Return Value:
//   Returns the image size of the surface actually written into GTF file.
// 
static uint32_t convertSurfaceToGtfFormat( CellUtilDDSTexture* dds, uint8_t* src_ptr, 
                                    uint32_t width, uint32_t height, uint32_t depth, uint32_t stride, 
									uint8_t* dst, uint32_t offset, uint32_t dummy_components, 
									texConvSwizzleOption swizzleOption)
{
	uint32_t imageSize;
	int dxt_type;

	// Do swizzle conversion if:
	//   - swizzleOption enum is FORCE_SWIZZLE.
	//       == OR  ==
	//   - swizzle option is specified from command line.
	//        == AND ==
	//   - format supports swizzle layout.
	//        == AND ==
	//   - swizzleOption enum is not FORCE_LINEAR.
	//
	// NOTE: If texture is swizzlabe but 3D texture, swizzling happens later.
	//       If 3D texture, swizzleOption flag should be false for first round.
	//
	if( (swizzleOption == FORCE_SWIZZLE) || 
	    (g_FlagSwizzle && isSwizzlable(dds) && (swizzleOption != FORCE_LINEAR))) 
	{
		// get image size of current surface
		imageSize = getImageSize(width, height, dummy_components /* no 3 */, dds->format);
		assert( imageSize > 0 );

		// check swizzle option parameter
		if( (swizzleOption == FORCE_SWIZZLE) || (swizzleOption == ALLOW_SWIZZLE) ) {

			// Display verbose message to tell swizzle conversion is happening
			if( g_DetailedVerboseMode ) {
				printf( "Swizzle Conversion:\n" );
				printf( "  width:        %4d\n", width );
				printf( "  height:       %4d\n", height );
				printf( "  depth:        %4d\n", depth );
				printf( "  components:   %4d\n", dds->components );
				printf( "  offset:   %8d\n", offset );
				printf( "  dst:    0x%08x\n", (uint32_t)&dst[offset] );
				printf( "  src:    0x%08x\n", (uint32_t)src_ptr );
				printf( "  size:     %8d\n", imageSize );
				dprintf(( "  swizzleOption:   %d\n", swizzleOption ));
			}

			// this conversion also support 3 compontnets to 4 components conversion
			if( convertLinearToSwizzle(&dst[offset], src_ptr, width, height, depth, dds->components) < 0 ) {
				dprintf(( "Failed to convert to swizzle format\n" ));
				exit( -1 );
			}
		}
		else if (swizzleOption == CANCEL_SWIZZLE ) {
			// this will put unswizzled texture 
			memcpy( &dst[offset], src_ptr, imageSize );
		}
		else {
			// just stop execution
			assert( 0 && "swizzle option is invalid\n" );
		}

		// Do endian swap because half/float is multi-byte data type.
		if( isLittleEndianMachine()) {
			switch(dds->format) {
			case FOURCC_A16B16G16R16F:	// compnents is 8
			case FOURCC_A32B32G32R32F:	// compnents is 16 
				endianSwap( &dst[offset], imageSize, dummy_components/4 );
				break;
			default:
				endianSwap( &dst[offset], width*dummy_components*height, dummy_components );
			}
		}
	}
	else if( (swizzleOption != FORCE_LINEAR) && (dxt_type = isS3TC(dds)) > 0) {

		// S3TC compressed texture 
		// Linear/Swizzle restriction applied as well.
		
		if(isDimensionPowerOf2(dds)) {
			// just add image size. Each mipmap images are packed if swizzle format.
			//
			imageSize = getImageSize(width, height, dummy_components /* no 3 */, dds->format);
			memcpy( &dst[offset], src_ptr, imageSize );
		}
		else {
			// Linear format
			// Use stride instead of width.
			//
			// NOTE: line by line copy
			//
			//     If DXT1, copy 8 bytes/block.
			//     If DXT3/5, copy 16 bytes/block.
			//
			uint32_t block_size = (dxt_type==1)? 8: 16;
			uint32_t line_size  = (Pad_uint(width,4)+3)/4 * block_size;
			uint32_t pitch_size;
			pitch_size = g_FlagAlignPitch? 
			                 g_AlignPitchSize:
							 (Pad_uint(stride,4)+3)/4 * block_size;

			for( uint32_t y=0; y<((Pad_uint(height,4)+3)/4); y++ ) {
				memcpy( &dst[offset+(pitch_size*y)], src_ptr, line_size );
				src_ptr += line_size;
			}

			if( g_FlagAlignPitch )
				imageSize = pitch_size * ((Pad_uint(height,4)+3)/4);
			else 
				imageSize = getImageSize(Pad_uint(stride,4), Pad_uint(height,4), 
										 dummy_components /* no 3 */, dds->format);
		}
	}
	else {  
		// linear layout
		// Mipmap for linear format is aligned to stride instead of width.
			
		if( g_DetailedVerboseMode ) {
			printf( "Linear Conversion:\n" );
			printf( "  width:        %4d\n", width );
			printf( "  height:       %4d\n", height );
			printf( "  depth:        %4d\n", depth );
			printf( "  components:   %4d\n", dds->components );
			printf( "  offset:   %8d\n", offset );
			printf( "  dst:    0x%08x\n", (uint32_t)&dst[offset] );
			printf( "  src:    0x%08x\n", (uint32_t)src_ptr );
		}

		// Byte by byte copy
		for( uint32_t y=0; y<height; y++ ) {
			for( uint32_t x=0; x<width; x++ ) {
			
				uint32_t index = 0;

				if( dds->components == 3 ) {
					
					// if dds->component is 3, then need to swap endianess at this point.
					// BGR -> RGB
					if( g_FlagAlignPitch ) 
						index = offset + (g_AlignPitchSize*y + dummy_components*x);
					else 
						index = offset + (dummy_components*(stride*y+x));

					if( isLittleEndianMachine()) {
						dst[index+3] = DUMMY_ALPHA;       // A -> A
						dst[index+0] = *src_ptr++; // R -> R
						dst[index+1] = *src_ptr++; // G -> G
						dst[index+2] = *src_ptr++; // B -> B
					}
					else {
						dst[index+0] = DUMMY_ALPHA;       // A -> A
						dst[index+3] = *src_ptr++; // B -> R
						dst[index+2] = *src_ptr++; // G -> G
						dst[index+1] = *src_ptr++; // R -> B
					}

				}
				else {
					for( uint32_t c=dummy_components; c > 0; c-- ) {
						
						// if pitch size is specified, adjust index 
						if( g_FlagAlignPitch ) 
							index = offset + (g_AlignPitchSize*y+x*dummy_components)+(dummy_components-c);
						else
							index = offset + (dummy_components*(stride*y+x))+(dummy_components-c);

						// dds->components could be 1, 2, 3, or 4, but dummy_components 
						// never be 3.
						if(c <= dds->components) {
							dst[index] = *src_ptr++;
						}
						else {
							dst[index] = DUMMY_ALPHA; // dummy alpha
						}
					}
				}
			}
		}

		if( isLittleEndianMachine()) {
			uint32_t conv_size;
			if( g_FlagAlignPitch ) 
				conv_size = g_AlignPitchSize * height;
			else
				conv_size = stride * dummy_components * height;

			// 
			switch(dds->format) {
			case FOURCC_A16B16G16R16F:	// dummy_compnents is 8
				endianSwap( &dst[offset], conv_size, 2 );
				break;
			case FOURCC_A32B32G32R32F:	// dummy_compnents is 16 
				endianSwap( &dst[offset], conv_size, 4 );
				break;
			case FOURCC_R32F:
				endianSwap( &dst[offset], conv_size, 4 );
				break;
			case FOURCC_R16F:
			case FOURCC_G16R16F:
				endianSwap( &dst[offset], conv_size, 2 );
				break;
			case FOURCC_YVYU:
			case FOURCC_YUY2:
			case FOURCC_R8G8_B8G8:
			case FOURCC_G8R8_G8B8:
			default:
				endianSwap( &dst[offset], conv_size, dummy_components );
			}
		}
		// alignment
		// Next mipmap level texture must be aligned to stride*y boundary
		// If pack option is specified, aligned width*y boundary (no padding)
		//
		if( g_FlagAlignPitch )
			imageSize = g_AlignPitchSize * height;
		else
			imageSize = stride * height * dummy_components;
	}

	return imageSize;
} 

//  Function name: convertFrom2Ddds2gtf
//
//  Description:
//    Called from getImageConvertedToGTFformat.
//    This function will convert the dds file to gtf file, laying out so that the gtf file image
//    is exactly same as RSX texture layout on actual hardware.
//    This function is for 2D texture only.
//  
//  Return value: 
//	  number of byte converted.
//
static uint32_t convertFrom2Ddds2gtf(uint8_t* dst, CellUtilDDSTexture* dds, uint32_t dummy_components)
{
	uint32_t stride;
	uint8_t* src_ptr;
	uint32_t width, height;
	uint32_t offset = 0;

	// set stride
	stride = dds->width;

	// if dds.surface is 6, then it's a cubemap
	for( uint32_t face=0; face< dds->surfaces; face++ ) { 
		width = dds->width;
		height = dds->height;
		
		for( uint32_t mips=0; mips< dds->mips; mips++ ) {

			// set source image
			src_ptr = dds->image[face].pixels[mips];

			// Add image size to offset
			offset += convertSurfaceToGtfFormat( dds, src_ptr, width, height, 1 /* depth */, 
			                                     stride, dst, offset, dummy_components, ALLOW_SWIZZLE );

			// for next mip level
			if(  width != 1 ) width /= 2;  
			if( height != 1 ) height /= 2;

		}	// loop over mipmaps

		// Swizzled Cubemap must be aligned to 128 byte boundary
		// If pack option is specified, don't put padding
		if( ! g_FlagPack ) {
			if( (g_FlagSwizzle && isSwizzlable(dds)) || isS3TC(dds)) {
				// this is swizzle, so pad 128 byte alignment
				offset = Pad_uint(offset, ALIGNMENT_CUBE_FACE);
			}
		}
		
	} // loop over cube faces

	//
	assert( (offset & 127) == 0 );
	return offset;
}


//  Function name: convertFrom3Ddds2gtf
//
//  Description:
//    Called from getImageConvertedToGTFformat.
//    This function will convert the dds file to gtf file, laying out so that the gtf file image
//    is exactly same as RSX texture layout on actual hardware.
//    But this function is called against 3D texture (volume texture).
//  
//  Return value: 
//	  number of byte converted.
//
static uint32_t convertFrom3Ddds2gtf(uint8_t* dst, CellUtilDDSTexture* dds, uint32_t dummy_components)
{
	uint32_t offset = 0;
	uint32_t stride;
	uint8_t* src_ptr;
	uint32_t width, height, depth;
	bool     bVtcMode = false;
	uint32_t iVtcOutLoopNum;
	uint32_t iVtcInLoopNum;

	bool     bPowerOf2Depth;
	
	//uint32_t iDxtcWidth  = ((Pad_uint(width,4)+3)/4);
	//uint32_t iDxtcHeight = ((Pad_uint(height,4)+3)/4);

	// This array will store the offset for each mipmap.
	// mip_offset[0] is always 0 (because level 1 is always at top).
	// mip_offset[1] is for mip level 2.
	//
	// The size of array is 14+1, which can contain up to level 14 (4092x4092), 
	// additional one is just for safety...( oh well )
	//
	uint32_t mip_offsets[14+1] = {0};  
		
	// set stride
	stride = dds->width;

	// initial dimension
	width  = dds->width;
	height = dds->height;
	depth  = dds->depth;

	// check VTC
	if( (dds->ddspf.fourCC == FOURCC_DXT1) 
			| (dds->ddspf.fourCC == FOURCC_DXT3)
			| (dds->ddspf.fourCC == FOURCC_DXT5) )
	{
		bVtcMode = true;
	}
	else
	{
		bVtcMode = false;
	}


	iVtcOutLoopNum = Pad_uint(depth, 4) / 4; // @VTC4x4x2, equal 1, definitely. :-)
	iVtcInLoopNum = depth % 4;
	if (iVtcInLoopNum == 0)
	{
		iVtcInLoopNum = 4;
	}	
	dprintf(("bVtcMode=%d depth=%d iVtcOutLoopNum=%d iVtcInLoopNum =%d\n",
				bVtcMode,
				depth,
				iVtcOutLoopNum,
				iVtcInLoopNum));


	// check power of 2 loop num
	if(isDepthPowerOf2(dds))
	{
		dprintf(("depth is PO2\n"));
		bPowerOf2Depth = true;
	}
	else
	{
		bPowerOf2Depth = false;
	}

	
	// memory allocation depends on wheather it's VTC or not.
	if( bVtcMode )
	{
		dprintf(("VTC CONVERSION MODE.\n"));
	
		//int imageSize = 0;
		int dxt_type = isS3TC(dds);
		
		// 
		// Huge branch case:
		//   if case:   VTC dds dimension is power of 2.
		//   else case: VTC dds dimension is notpower of 2.
		//
		if(isDimensionPowerOf2(dds))
		{
			for( uint32_t mip=0; mip<dds->mips; mip++ ) {

				for( uint32_t vol_out=0; vol_out<iVtcOutLoopNum; vol_out++ ) {
						
					// S3TC compressed texture 
					dprintf(("linear dxtc \n"));

					if(isDepthPowerOf2(dds))
					{
						// VTC is either: 4x4x1 or 4x4x2 or 4x4x4.
						// else we don't know what to do...
						//
						if( iVtcInLoopNum == 1 || iVtcInLoopNum == 2 || iVtcInLoopNum == 4 )
						{
							// NOTE: block_size copy 
							//
							//     If DXT1, copy 8 bytes/block.
							//     If DXT3/5, copy 16 bytes/block.
							//
							uint32_t block_size = (dxt_type==1)? 8: 16;
							//uint32_t line_size  = (Pad_uint(width, 4)+3)/4 * block_size;
							//uint32_t pitch_size = (Pad_uint(stride,4)+3)/4 * block_size;
								
							uint32_t iDxtcWidth  = ((Pad_uint(width,4)+3)/4);
							uint32_t iDxtcHeight = ((Pad_uint(height,4)+3)/4);

							for( uint32_t y=0; y<iDxtcHeight; y++ )
							{
								for( uint32_t x=0; x<iDxtcWidth; x++ )
								{
									for( uint32_t z=0; z<iVtcInLoopNum; z++ )
									{
										src_ptr = dds->vol_image[z + vol_out*iVtcInLoopNum].pixels[mip];
										src_ptr += block_size * (x + y*iDxtcWidth);

										memcpy( &dst[offset], src_ptr, block_size);
										offset += block_size;

										dprintf(( "\tx=%d y=%d z=%d offset=0x%x (%d), block_size=%d\n", 
												x, y, z, offset, offset, block_size ));

									}
								}
							}
						}
						else
						{
							dprintf(("ERROR: wrong iVtcInLoop. \n"));
							assert( 0 );
						}
					}
					else
					{ 
						dprintf(("Not VTC, but VTC function called error. (0x%x)\n", dds->format));
						assert(0);
					}

				}	// loop over each volume

				if (width != 1)  { width /= 2; }
				if (height != 1) { height /= 2; }
				if (depth != 1)
				{
					depth /= 2;
					iVtcOutLoopNum = Pad_uint(depth, 4) / 4; // @VTC4x4x2, equal 1, definitely. :-)
					iVtcInLoopNum = depth % 4;
					if (iVtcInLoopNum == 0)
					{
						iVtcInLoopNum = 4;
					}	
					dprintf(("depth=%d iVtcOutLoopNum=%d iVtcInLoopNum =%d\n",
							depth,
							iVtcOutLoopNum,
							iVtcInLoopNum));
				}

			}	// loop over each mipmaps

			//
			offset = Pad_uint( offset, ALIGNMENT_TO_TEXTUREDATA_IN_GTF); 
		}
		else	
		{
			dprintf(( "Non Power of 2 branch!\n" ));
			// Non pow of 2 volume width.
			//
			// 
			if(isDepthPowerOf2(dds))
			{
				// NOTE: block_size copy 
				//
				//     If DXT1, copy 8 bytes/block.
				//     If DXT3/5, copy 16 bytes/block.
				//
				uint32_t block_size = (dxt_type==1)? 8: 16;
				uint32_t pitch_size = (Pad_uint(stride,4)+3)/4 * block_size;
					
				for( uint32_t mip=0; mip<dds->mips; mip++ ) {

					dprintf(( "mip: %d\n", mip ));

					for(uint32_t z=0; z<depth; z++) {

						// get texture for current depth 
						src_ptr = dds->vol_image[z].pixels[mip]; 

						uint32_t line_size  = (Pad_uint(width, 4)+3)/4 * block_size;
						uint32_t iDxtcHeight = ((Pad_uint(height,4)+3)/4);

						for(uint32_t y=0; y<iDxtcHeight; y++) {

							dprintf(("mip=%d, z=%d, y=%d, line_size=%d, pitch_size=%d: memcpy( 0x%x, 0x%x, %d)\n", 
									  mip, z, y, line_size, pitch_size, &dst[offset], src_ptr, line_size ));

							memcpy( &dst[offset], src_ptr, line_size );

							src_ptr += line_size;
							offset += pitch_size;
						}
						// may not be necessary...
						offset = Pad_uint( offset, pitch_size );
					}

					// divide dimension to get to next mip level
					if (width != 1)  { width /= 2; }
					if (height != 1) { height /= 2; }
					if (depth != 1)  { depth /= 2; }

				}  // loop over mipmaps

				// 
				offset = Pad_uint( offset, ALIGNMENT_TO_TEXTUREDATA_IN_GTF); 

			}
			else {
				assert( 0 && "non pow of 2 depth not supported..." );
			}
		}
	}
	else //#### not VTC, normal 3d texture memory allocation
	{
		for( uint32_t mip=0; mip<dds->mips; mip++ ) {

			mip_offsets[mip] = offset;

			for( uint32_t vol=0; vol<depth; vol++ ) {
				
				// set source ptr
				src_ptr = dds->vol_image[vol].pixels[mip];

				//printf( "LINE %d: volume %d, mip %d, address 0x%x\n", __LINE__, vol, mip, src_ptr );

				// Add image size to offset.
				// 
				//  1) if FORCE_LINEAR is set, texture will not be converted to swizzle format, 
				//     and memory layout is as if it is linear texture.
				//
				//  2) if CANCEL_SWIZZLE is set, texture will not be converted to swizzle format, 
				//     and memory layout is as if it is swizzle texture.
				//
				offset += convertSurfaceToGtfFormat(dds, src_ptr, width, height, depth, stride, 
				                                    dst, offset, dummy_components, CANCEL_SWIZZLE );

				// each volume beginning address must be at 128 byte boundary
				// NOTE: 
				//   If linear texture, there's no alignment restriction.
				//
				if( g_FlagSwizzle && isSwizzlable(dds)) 
					offset = Pad_uint(offset, ALIGNMENT_3D_SWIZZLE_VOL);
				else 
					offset = Pad_uint(offset, ALIGNMENT_3D_LINEAR_VOL);

			}	// loop over each volume

			// NOTE: 
			//   If linear texture, there's no alignment restriction.
			//
			if( g_FlagSwizzle && isSwizzlable(dds)) 
				offset = Pad_uint(offset, 1);
			else 
				offset = Pad_uint(offset, 1);

			// divide by 2 to get next mipmap size
			if (width != 1) { width /= 2; }
			if (height!= 1) { height/= 2; }
			if (depth != 1) { depth /= 2; }

		}	// loop over each mipmaps

		// 
		{{
			// put final offset at end of offset table
			mip_offsets[dds->mips] = offset;

			// 
			offset = Pad_uint( offset, ALIGNMENT_TO_TEXTUREDATA_IN_GTF); 
		}}

		// re-organize swizzle texture
		//
		if( g_FlagSwizzle && isSwizzlable(dds)) {
			
			// calculate the size of texture
			uint32_t textureSize = mip_offsets[1] - mip_offsets[0];

			// create temporary buffer
			//
			uint8_t* tmp_buffer = (uint8_t*) malloc( textureSize );
			if( ! tmp_buffer ) {
				fprintf( STDERR, "Error allocating temporary buffer: size=%d bytes\n", textureSize );
				assert( 0 );
			}

			// Show some useful message.
			if( g_DetailedVerboseMode ) {
				printf( "3D texture swizzling:\n" );
				printf( "  Temporary Buffer allocated at: 0x%08x\n", (uint32_t)tmp_buffer );
				printf( "  Number of Bytes allocated:    %d bytes\n", textureSize );
				printf( "  Bytes per pixel:              %d bytes\n", dummy_components );
				printf( "  Progress:\n" );
			}

			uint32_t tmp_width = dds->width;
			uint32_t tmp_height = dds->height;
			uint32_t tmp_depth = dds->depth;

			for( uint32_t i=0; i<dds->mips; i++ ) {

				uint8_t* tmp_dst = &dst[mip_offsets[i]];

				// convert and copy current 3D texture mip level to temporay buffer
				// 
				if( convertLinearToSwizzle(tmp_buffer,         // uint8_t *dst 
									   tmp_dst,                // uint8_t *src
									   tmp_width,         // uint32_t width
									   tmp_height,        // uint32_t height
									   tmp_depth,         // uint32_t depth
									   dummy_components )<0) // uint32_t bytesPerPixel
				{
					dprintf(( "Failed to convert to swizzle format\n" ));
					exit( -1 );
				}

				// copy back temporary buffer to original buffer
				int32_t size = mip_offsets[i+1] - mip_offsets[i];

				assert( size > 0 );

				if( g_DetailedVerboseMode ) {
					printf( "    Converting %d bytes of mip %d\n", 
							  size, i );
				}
			
				//memcpy( tmp_dst, tmp_buffer, textureSize );
				memcpy( tmp_dst, tmp_buffer, size );

				// divide by 2 to get next mipmap size
				if (tmp_width != 1) { tmp_width /= 2; }
				if (tmp_height!= 1) { tmp_height/= 2; }
				if (tmp_depth != 1) { tmp_depth /= 2; }
			}

			// free allocated buffer area
			free( tmp_buffer );
		}
	}

	// 
	assert( (offset & 127) == 0 );
	return offset;
}

//  Function name: getImageConvertedToGTFformat
//
//  Description:
//   Returns number of byte converted.
//   Also set pointer (dst) to image that are copied/aligned for GTF texture format
//   Returns number of byte converted.
//
static uint32_t getImageConvertedToGTFformat(uint8_t* dst, CellUtilDDSTexture* dds, uint32_t dummy_components)
{
	// RSX doesn't support 3 components texture
	assert( dummy_components != 3 );

	// Huge branch if the texture is 3D!
	//
	if( dds->depth > 0 ) 
		return convertFrom3Ddds2gtf( dst, dds, dummy_components ); 
	else
		return convertFrom2Ddds2gtf( dst, dds, dummy_components ); 
}

//
// Description:
//   Checks simple validity check for texture.
//
// Return value:
//   0 on success
//  -1 on failure
//
static int checkDDSValidity( CellUtilDDSTexture* dds )
{
	// check cubemap validity
	if( dds->surfaces != 1 ) {

		// Requires 6 cubemap faces
		if( dds->surfaces != 6 ) {
			fprintf( STDERR, "ERROR: Cubemap surface must be 6.\n" );
			fprintf( STDERR, "       This DDS has %d surfaces.", dds->surfaces );
			return -1;
		}

		// Requires width == height
		if( dds->width != dds->height ) {
			fprintf( STDERR, "ERROR: RSX requires cubemap to have same width and height\n" );
			fprintf( STDERR, "       This DDS has width of %d and height of %d.", dds->width, dds->height );
			return -1;
		}

	}
	return 0;
}

//
// Function: convertDDSMultipleDds2gtf
// Description: 
//   Convert multiple input files to one GTF file.
//
// Return Value:
//	Returns CELL_TEXCONV_OK on success.
//	Returns CELL_TEXCONV_ERROR on failure.
// 
static int convertDDSMultipleDds2gtf( char **infiles, int fileCount, const char *outfile, uint32_t id)
{
	uint32_t *dummy_components;
	uint32_t output_texturesize = 0;
	uint32_t offset_to_tex = 0;
	CellGtfFileHeader gtf_header;
	CellGtfTextureAttribute *gtf_attribs;
	CellUtilDDSTexture *dds;
	uint8_t* converted_image;
	//uint8_t* traverser;

	// allocate texture attribute for number of input files
	gtf_attribs = (CellGtfTextureAttribute*) malloc( fileCount * sizeof(CellGtfTextureAttribute));
	if( gtf_attribs == NULL ) {
		fprintf( STDERR, "Error: Allocating texture attribute header\n" );
		return CELL_TEXCONV_ERROR;
	}

	// allocate DDS texture structures
	dds = (CellUtilDDSTexture*) malloc( fileCount * sizeof(CellUtilDDSTexture) );
	if( dds == NULL ) {
		fprintf( STDERR, "Error: Allocating DDS header structure\n" );
		return CELL_TEXCONV_ERROR;
	}

	// allocate dummy_components
	dummy_components = (uint32_t*) malloc( fileCount * sizeof(uint32_t) );
	if( dummy_components == NULL ) {
		fprintf( STDERR, "Error: Allocating Dummy_Components\n" );
		return CELL_TEXCONV_ERROR;
	}

	// Loop through each input files to get DDS texture
	for( int i=0; i<fileCount; i++ ) {

		if (cellUtilDDSRead(infiles[i], &dds[i]) != 0) {
			printf("cellUtilDDSLoad failed (%s)\n", infiles[i]);
			return CELL_TEXCONV_ERROR;
		}

		if( g_VerboseMode ) {
			printf("DDS File information: %s\n", infiles[i] );
			printf("  width:             %u\n", dds[i].width);
			printf("  height:            %u\n", dds[i].height);
			printf("  depth:             %u\n", dds[i].depth);
			printf("  components:        %u\n", dds[i].components);
			printf("  size:              %u\n", dds[i].size);
			printf("  mipmaps:           %u\n", dds[i].mips);
			printf("  surfaces:          %u\n", dds[i].surfaces);
			printf("  format:            0x%x\n", dds[i].format);
			printf("  Pixel format:\n" );
			printf("    size:        %d\n", dds[i].ddspf.size );
			printf("    flags:       0x%x\n", dds[i].ddspf.flags );
			printf("    fourCC:      0x%x ('%c%c%c%c')\n", dds[i].ddspf.fourCC,
						  (dds[i].ddspf.fourCC >> 24) & 0xFF, 
						  (dds[i].ddspf.fourCC >> 16) & 0xFF, 
						  (dds[i].ddspf.fourCC >>  8) & 0xFF, 
						  (dds[i].ddspf.fourCC >>  0) & 0xFF );
			printf("    rgbBitCount: %d\n", dds[i].ddspf.rgbBitCount );
			printf("    rbitMask:    0x%08x\n", dds[i].ddspf.rbitMask );
			printf("    gbitMask:    0x%08x\n", dds[i].ddspf.gbitMask );
			printf("    bbitMask:    0x%08x\n", dds[i].ddspf.bbitMask );
			printf("    abitMask:    0x%08x\n", dds[i].ddspf.abitMask );
		}

		// check validity for cubemap
		if( checkDDSValidity( &dds[i] ) < 0 ) {
			return CELL_TEXCONV_ERROR;
		}

		// RSX doesn't support 3 components texture format, so we dummy 4th one
		dummy_components[i] = (dds[i].components == 3? 4: dds[i].components );

		assert( dds[i].mips > 0 );
		assert( dds[i].surfaces > 0 );

		// Get offset to texture data IN FILE
		offset_to_tex = getOffsetToTex( fileCount, output_texturesize );

		// Test user specified pitch size
		if( g_FlagAlignPitch ) {
			if( testPitch(&dds[i]) > 0 ) {
				fprintf( STDERR, "The pitch size needs to be bigger than original pitch size.\n");
				fprintf( STDERR, "Pitch size you specified ignored.\n");
			}
		}

		// if user-specified pitch size is invalid, correct it
		getPitch(1, &dds[i]);

		// get all total size of output file 
		uint32_t this_textureSize = getGTFOutputFilesize( &dds[i], dummy_components[i] );

		output_texturesize += Pad_uint( this_textureSize, ALIGNMENT_TO_TEXTUREDATA_IN_GTF );

		// If only single file is input, then assigned specific id to texture id
		uint32_t _this_id;
		_this_id = ( fileCount == 1 )? id: i; 

		// If normalize option is on, set bool value for normalize
		uint8_t this_unnormalize_flag;
		this_unnormalize_flag = (g_FlagUnnormalize)? true: false;

		// set up file header and texture attribute header
		setupTextureHeader( &gtf_attribs[i], &dds[i], _this_id, offset_to_tex, 
		                  this_textureSize, g_FlagSwizzle, this_unnormalize_flag ); 

		// Restore pitch size for next file
		g_AlignPitchSize = g_OriginalAlignPitchSize;
	}

	// Setup File Header 
	setupFileHeader( &gtf_header, VERSION, output_texturesize, fileCount );

	// allocate memory for output image 
	converted_image = (uint8_t*) malloc(output_texturesize);
	if( converted_image == NULL ) {
		perror( "malloc(converted_image)" );
		return CELL_TEXCONV_ERROR;
	}

	memset((void*)converted_image, 0xC0FFEE, output_texturesize);

	if( g_VerboseMode ) {
		printf( "GTF FileSize Estimate:\n" );
		printf( "  Output GTF File Size: %d    Total Texture Size: %d\n", 
		          getTotalHeaderSize( fileCount ) + output_texturesize, 
				  output_texturesize );
		verbosePrintHeader( &gtf_header, gtf_attribs );
	}

	// convert each dds image to converted image
	// Note: converted_image is layed out same as memory layout
	uint32_t total_written = 0;

	for( int i=0; i<fileCount; i++ ) {
		uint32_t written = 0;

		// Get/Correct pitch size 
		getPitch(1, &dds[i]);

		// Warn if swizzle conversion is not possible, but swizzle option is 
		// provided (only when -v option)
		//
		if( g_VerboseMode ) {
			if( g_FlagSwizzle && (! isSwizzlable(&dds[i]))) {
				printf("\n");
				printf("WARNING: This DDS format can't be converted to swizzle format: %s\n", infiles[i]);
				printf("\n");
			}
		}

		// Do the conversion!!
		written = getImageConvertedToGTFformat( &converted_image[total_written], &dds[i], dummy_components[i] );

		// must be 128 byte aligned size
		written = Pad_uint( written, ALIGNMENT_TO_TEXTUREDATA_IN_GTF );

		if( written == 0 ) {
			fprintf( STDERR, "Failed to convert image: %s\n", infiles[i] );
			assert(0);
		}

		#if 1 // {
		// Dump converted image to PPM file
		if( g_DebugDump ) {
			if( isS3TC( &dds[i] )) {
				fprintf( STDERR, "file %d: Cannot dump S3TC file\n", i );
				assert(0);
			}
			else {
				debugDump( &converted_image[total_written], infiles[i], &dds[i], &gtf_attribs[i] );
			}
		}
		#endif // }

		total_written += written;

		// Restore pitch size for next file
		g_AlignPitchSize = g_OriginalAlignPitchSize;
	}
	
	// Output texture size calculated must be equal to actual texture size converted.
	//
	if( g_DetailedVerboseMode ) {
		printf( "Conversion Result Info:\n" );
		printf( "  Total Bytes Acutually Converted: %d bytes\n", total_written );
		printf( "  Calculated Ouput Texture Size:   %d bytes\n", output_texturesize );
	}

	// make sure total_written is same as what we calculated.
	//
	assert( total_written == output_texturesize );

	// endian swap if runs on little-endian machine
	if( isLittleEndianMachine()) {
		if( g_VerboseMode ) {
			printf( "Endian Info:\n" );
			printf( "  Your machine is a little endian machine.\n" );
		}
		headerAttribEndianSwap( &gtf_header, gtf_attribs );
	}
	else {
		if( g_VerboseMode ) {
			printf( "Endian Info:\n" );
			printf( "  Your machine is a big endian machine.\n" );
			printf( "  So, you don't need to swap endian for RSX texture\n" );
		}
	}

	// do file write here
	outputToGtfFile( outfile, &gtf_header, gtf_attribs, 
	                 fileCount, converted_image, output_texturesize );
	
	// Clearn up memory
	free( dummy_components );
	for( int i=0; i<fileCount; i++ ) free( dds[i].buffer );
	free( dds );
	free( gtf_attribs );
	free( converted_image );

	return CELL_TEXCONV_OK;
}

// Function Name: setConversionOptions
// 
// Description:
//  Set global flag option
//
static void setConversionOptions( uint32_t option ) 
{
	// swizzle option
	if( option & CELL_TEXCONV_FLAG_SWIZZLIZE )
		g_FlagSwizzle = 1;
	else 
		g_FlagSwizzle = 0;

	// pack/unpack option
	// NOTE: default is 'unpack'
	if( option & CELL_TEXCONV_FLAG_PACKED )
		g_FlagPack = 1;
	else 
		g_FlagPack = 0;

	// normalize option
	if( option & CELL_TEXCONV_FLAG_UNNORMALIZE )
		g_FlagUnnormalize = 1;
	else 
		g_FlagUnnormalize = 0;

	// verbose mode
	if( option & CELL_TEXCONV_FLAG_VERBOSE )
		g_VerboseMode = 1;
	else
		g_VerboseMode = 0;

	// very detailed verbose mode
	if( option & CELL_TEXCONV_FLAG_DETAILED_VERBOSE )
		g_DetailedVerboseMode = 1;
	else
		g_DetailedVerboseMode = 0;
	
	// Error report on/off
	if( option & CELL_TEXCONV_FLAG_ERROR_REPORT )
		g_ErrorReport = 1;
	else	
		g_ErrorReport = 0;

	// Align pitch to 64 bytes ?
	if( option & CELL_TEXCONV_FLAG_ALIGN_PITCH_64 )
		g_FlagForcePitch64 = 1;
	else	
		g_FlagForcePitch64 = 0;

	// Error report on/off
	if( option & CELL_TEXCONV_FLAG_USER_GIVEN_PITCH ) {
		g_FlagAlignPitch = 1;

		// pitch size must be sepcified before hand
		assert( g_AlignPitchSize > 0 );
	}
	else {
		g_FlagAlignPitch = 0;

		// 0 means pitch size is depends on DDS information
		g_AlignPitchSize = 0;
	}

	// Error report on/off
	// XXX not yet implemented
	if( option & CELL_TEXCONV_FLAG_DEBUG_DUMP )
		g_DebugDump   = 1;
	else
		g_DebugDump   = 0;
}

// Function name: dds2gtf_set_pitch_size()
// 
// Description:
//  - Set pitch size to specifed number by user
//  - The option CELL_TEXCONV_FLAG_ALIGN_PITCH must be set
// 
void dds2gtf_set_pitch_size( uint32_t pitch_size ) 
{
	assert( pitch_size > 0 );

	// This variable will change by following matters
	//  - user specified pitch size is smaller than what texture needs
	//  - ForcePitch64 option is set
	//
	g_AlignPitchSize = pitch_size;

	// This variable will not be changed by any means
	g_OriginalAlignPitchSize = pitch_size;
}

// Function name: dds2gtf_output_to_file()
// 
// Description:
//  - Returns error on failure.
//  - Convert input files to GTF files.
//
int dds2gtf_output_to_file( char** inputFilenames, // array of input files
                             int inputFileCount,      // number of input files
							 const char* outputFilename,   // output filename
							 uint32_t option )               // conversion options
{
	// Error check 
	if( inputFileCount == 0 ) {
		fprintf( STDERR, "Error: input file count is zero\n" );
		return CELL_TEXCONV_ERROR;
	}
															DEBUG_LINE
	if( outputFilename[0] == 0 ) {
		fprintf( STDERR, "Error: Output filename is null\n" );
		return CELL_TEXCONV_ERROR;
	}
															DEBUG_LINE

	// initialize global setting
	g_Error = 0;

	// set conversion options
	setConversionOptions(option);
															DEBUG_LINE
	
	if( g_VerboseMode ) {
		printf( "Conversion File Infomation:\n" );
		for( int i=0; i<inputFileCount; i++ ) 
			printf( "  Input File %3d:  %s\n", i, inputFilenames[i]  );
		printf( "  Output File: %s\n", outputFilename );
		printf( "  Convert to Swizzle:  %d\n", g_FlagSwizzle );
		printf( "  Unnormalize:         %d\n", g_FlagUnnormalize );
	}
															DEBUG_LINE

	// Filename validation
	for( int i=0; i<inputFileCount; i++ ) {
		const char* in_file = inputFilenames[i];
		if( strcmp(&in_file[strlen(in_file)-4], ".dds")) {
			fprintf( STDERR, "Only dds file extension supported\n" );
			return CELL_TEXCONV_ERROR;
		}
	}
															DEBUG_LINE

	// Start conversion
	convertDDSMultipleDds2gtf( inputFilenames, inputFileCount, outputFilename, 0 );
															DEBUG_LINE

	if( g_Error ) {
		fprintf( STDERR, "Log: Conversion may not complete successfully.\n");
		if( g_ErrorReport ) analyzeError();
	}
															DEBUG_LINE

	return CELL_TEXCONV_OK;
}

// Function name: dds2gtf_output_to_file_with_id()
// 
// Description:
//  - Win32 Library function.
//  - Returns error on failure.
//  - Convert single input file to single GTF file.
//  - Convert to GTF file with specified ID.
//
int dds2gtf_output_to_file_with_id( char* inputFilename,    // input filename
							 const char* outputFilename,   // output filename
							 uint32_t id,                  // specific id
							 uint32_t option )             // conversion options
{
	// Error check 
	if( outputFilename == NULL || outputFilename[0] == 0 ) {
		fprintf( STDERR, "Error: Output filename is null\n" );
		return CELL_TEXCONV_ERROR;
	}

	// initialize global setting
	// Note: not multi-thread safe
	//
	g_Error = 0;

	// set conversion options
	setConversionOptions(option);
	
	// Filename validation
	if( strcmp(&inputFilename[strlen(inputFilename)-4], ".dds")) {
		fprintf( STDERR, "Only dds file extension supported\n" );
		return CELL_TEXCONV_ERROR;
	}

	// Start conversion
	convertDDSMultipleDds2gtf( &inputFilename, 1, outputFilename, id );

	if( g_Error ) {
		fprintf( STDERR, "Log: Conversion may not complete successfully.\n");
		if( g_ErrorReport ) analyzeError();
	}
	else {
		fprintf( STDERR, "Log: Conversion completes successfully.\n");
	}

	return CELL_TEXCONV_OK;
}

