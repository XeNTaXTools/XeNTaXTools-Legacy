/*   SCE CONFIDENTIAL                                       */
/*   PLAYSTATION(R)3 Programmer Tool Runtime Library 192.001 */
/*   Copyright (C) 2007 Sony Computer Entertainment Inc.    */
/*   All Rights Reserved.                                   */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <math.h>
#include <errno.h>

#include "common.h"
#include "gcm_info.h"
#include "ddsfile.h"

typedef void (*CellUtilCallback)(void *, const char *);

static void cellUtilDefaultCallback(void *func, const char *errorString)
{
	printf("celUtil error: at address 0x%p\n", func);
	if (errorString) {
		printf("celUtil error: %s\n", errorString);
	}
	exit(1);
}

static CellUtilCallback cellUtilErrorCallback = cellUtilDefaultCallback;

void cellUtilSetCallback(CellUtilCallback func)
{
	cellUtilErrorCallback = func;
}

//-----------------------------------------------------------------------------
// Description: Swap the bytes in a 32 bit value
// Parameters:	
// Returns:
// Notes:
// PCs, PS2 and PSP are little endian.  PS3 is big endian so need to swap 
// endian for some of the data
//-----------------------------------------------------------------------------
static inline void swapEndian(void *val)
{
	unsigned int *ival = (unsigned int *)val;
    *ival = ((*ival >> 24) & 0x000000ff) |
		((*ival >>  8) & 0x0000ff00) |
		((*ival <<  8) & 0x00ff0000) |
		((*ival << 24) & 0xff000000);
}

//-----------------------------------------------------------------------------
// uint32_t getFileLen(char *filename)
// Description: 
// returns the length of the file in bytes
// Returns: 
// 0 on length of file
// Notes:
//-----------------------------------------------------------------------------
static uint32_t getFileLen(const char *filename)
{
	FILE* fp;
	uint32_t fileLen;

	if ((fp = fopen(filename,"rb")) == NULL) {
		return 0;
	}

	if (fseek(fp, 0, SEEK_END)!=0) {
		return 0;
	}

	fileLen = ftell(fp);
	fclose(fp);

	return fileLen;
}


//-----------------------------------------------------------------------------
// int LoadFile(const char *filename,unsigned int bytes,unsigned char *buffer)
// Description: 
// loads bytes amount of data into buffer from filename
// Returns: 
// 0 on failure or the number of bytes read
// Notes:
//-----------------------------------------------------------------------------
static int loadFile(const char *filename,	//name of file to read	
					unsigned int bytes,		//number of bytes to read
					unsigned char *buffer)	//load the file here
{
	FILE* fp;

	if ((fp = fopen(filename, "rb")) == NULL) {
		return EINVAL;
	}

	if (fread(buffer, 1, bytes, fp)!= bytes) {
		return EINVAL;
	}

	fclose(fp);

	return 0;
}


//-----------------------------------------------------------------------------
// int32_t getImageSizePacked(uint32_t w,uint32_t h,uint32_t components,uint32_t format)
// Description: 
// returns the size of a texture buffer IN DDS FILE
// header
// Returns: 
// Notes:
//-----------------------------------------------------------------------------
int32_t getImageSizePacked(uint32_t w, uint32_t h,
					 uint32_t components, uint32_t format)
{
	int32_t ret = 0;

	assert( w > 0 );
	assert( h > 0 );
	assert(components > 0 );
	assert( format > 0 );

	switch(format) {
	case 0x83F1: // GL_COMPRESSED_RGBA_S3TC_DXT1_EXT
		ret = ((w+3)/4) * ((h+3)/4)* 8;   
	    break;
	case 0x83F2: // GL_COMPRESSED_RGBA_S3TC_DXT3_EXT
	case 0x83F3: // GL_COMPRESSED_RGBA_S3TC_DXT5_EXT
		ret = ((w+3)/4) * ((h+3)/4)* 16;   
		break;
	default:
		ret = w*h*components;         
	}
	assert( ret > 0 );

	return ret;
}

//-----------------------------------------------------------------------------
// int32_t getImageSize(uint32_t w,uint32_t h,uint32_t components,uint32_t format)
// Description: 
// returns the size of a texture buffer with consideration of result texture size
// header
// Returns: 
// Notes:
//-----------------------------------------------------------------------------
int32_t getImageSize(uint32_t w, uint32_t h,
					 uint32_t components, uint32_t format)
{
	int32_t ret = 0;

	assert( w > 0 );
	assert( h > 0 );
	assert(components > 0 );
	assert( format > 0 );

	switch(format) {
	case 0x83F1: // GL_COMPRESSED_RGBA_S3TC_DXT1_EXT
		ret = ((w+3)/4) * ((h+3)/4)* 8;   
	    break;
	case 0x83F2: // GL_COMPRESSED_RGBA_S3TC_DXT3_EXT
	case 0x83F3: // GL_COMPRESSED_RGBA_S3TC_DXT5_EXT
		ret = ((w+3)/4) * ((h+3)/4)* 16;   
		break;
	default:
		ret = w*h*components;         
	}
	assert( ret > 0 );

	return ret;
}

//-----------------------------------------------------------------------------
// int getImageSpec(CellUtilDDSHeader *ddsh, uint32_t *format,uint32_t *components)
// Description: 
// helper function that returns the format and number of components in a dds
// header
// Returns: 
// 0 on failure
// Notes:
//-----------------------------------------------------------------------------

static int getImageSpec(CellUtilDDSHeader *ddsh, uint32_t *format,
					 uint32_t *components)
{
	assert(format);
	assert(components);

	// NOTE: components is really a byte per pixel

	if (ddsh->ddspf.flags & DDSF_FOURCC) {
		switch(ddsh->ddspf.fourCC) {
		case FOURCC_DXT1:
			*format = 0x83F1;  // GL_COMPRESSED_RGBA_S3TC_DXT1_EXT
            *components = 3;
            break;
		case FOURCC_DXT3:
			*format = 0x83F2;  // GL_COMPRESSED_RGBA_S3TC_DXT3_EXT
            *components = 4;
            break;
        case FOURCC_DXT5:
			*format = 0x83F3;  // GL_COMPRESSED_RGBA_S3TC_DXT5_EXT
            *components = 4;
            break;
		// TODO: support A16B16G16R16F & A32B32G32R32F
		case FOURCC_A16B16G16R16F: 
			*format = ddsh->ddspf.fourCC;
			*components = 8;
			break;
		case FOURCC_R32F:
			*format = ddsh->ddspf.fourCC;
			*components = 4;
			break;
		case FOURCC_A32B32G32R32F:
			*format = ddsh->ddspf.fourCC;
			*components = 16;
			break;
		case FOURCC_R16F: 	 
			*format = ddsh->ddspf.fourCC;
			*components = 2;
			break;
		case FOURCC_G16R16F:
			*format = ddsh->ddspf.fourCC;
			*components = 4;
			break;
		case FOURCC_YVYU:
		case FOURCC_YUY2:
		case FOURCC_R8G8_B8G8:
		case FOURCC_G8R8_G8B8:
			*format = ddsh->ddspf.fourCC;
			*components = 2;
			break;
        default:
			printf( "fourCC: 0x%x not supported\n", ddsh->ddspf.fourCC );
			assert(0 && "ERROR: Uses a compressed texture of unsupported type\n");
			return -1;
		}
    }
	else {
		if((ddsh->ddspf.flags & DDSF_RGB) &&
		   (ddsh->ddspf.flags & DDSF_ALPHAPIXELS) &&
			ddsh->ddspf.rgbBitCount == 32) 
		{
			if(countBit(ddsh->ddspf.abitMask) == 8 ) {
				*format = FORMAT_ARGB; 
				*components = 4;
			}
			else {
				assert( 0 && "Unknown format" );
				return -1;
			}
		}
		else if (ddsh->ddspf.flags == DDSF_RGBA &&
			     ddsh->ddspf.rgbBitCount == 16) {
			if(countBit(ddsh->ddspf.abitMask) == 1) {
				*format = FORMAT_A1R5G5B5; 
				*components = 2;
			}
			else if(countBit(ddsh->ddspf.abitMask) == 4) {
				*format = FORMAT_A4R4G4B4; 
				*components = 2;
			}
			else  {
				assert( 0 && "Unknown format" );
				return -1;
			}
		}
		else if ((ddsh->ddspf.flags & DDSF_RGB) &&
				 ddsh->ddspf.rgbBitCount == 32) {
			if(countBit(ddsh->ddspf.abitMask) == 0) {
				*format = FORMAT_D8R8G8B8;
				*components = 4;
			}
			else if(countBit(ddsh->ddspf.rbitMask) == 8) {
				*format = FORMAT_ARGB;
				*components = 4;
			}
			else if(countBit(ddsh->ddspf.rbitMask) == 16) {
				*format = FORMAT_Y16_X16; 
				*components = 4;
			}
			else {
				assert( 0 && "Unknown format" );
				return -1;
			}
		}
		else if (ddsh->ddspf.flags == DDSF_RGB  &&
				 ddsh->ddspf.rgbBitCount == 24) {
			*format = FORMAT_RGB; 
			*components = 3;
		}
		else if((ddsh->ddspf.flags & DDSF_LUMINANCE) &&
				 ddsh->ddspf.rgbBitCount == 16) {
			if(countBit(ddsh->ddspf.rbitMask) == 16) {
				*format = FORMAT_X16; 
				*components = 2;
			}
			else if(countBit(ddsh->ddspf.rbitMask) == 8) {
				*format = FORMAT_G8B8; 
				*components = 2;
			}
			else {
				assert( 0 && "Unknown format" );
				return -1;
			}
		}
		else if( (ddsh->ddspf.flags & 0x40000 ) &&
				 ddsh->ddspf.rgbBitCount == 16) {
			*format = FORMAT_R6G5B5; 
			*components = 2;
		}
		else if( ddsh->ddspf.flags == DDSF_RGB  &&
				 ddsh->ddspf.rgbBitCount == 16) {
			if( countBit(ddsh->ddspf.gbitMask) == 6 ) {
				*format = FORMAT_R5G6B5; 
				*components = 2;
			}
			else if(countBit(ddsh->ddspf.gbitMask) == 5 ) {
				*format = FORMAT_X1R5G5B5; 
				*components = 2;
			}
			else {
				assert( 0 && "Unknown Format." );
				return -1;
			}
		}
		else if (ddsh->ddspf.rgbBitCount == 8) {
			*format = FORMAT_B8; 
			*components = 1;
		}
		else if (ddsh->ddspf.flags & DDSF_BUMPDUDV ) {
			*format = FORMAT_Y16_X16; 
			*components = 4;
		}
		// If any of above condition weren't met, check dwFlag's DDSD_PIXELFORMAT bit.
		// If DDSD_PIXELFORMAT bit is on, try to GUESS it's format.
		else if ( ddsh->flags & DDSF_PIXELFORMAT ) {
			// we are not sure what this pixel format is.
			// Print out error message, and suggest user to set up their own format header.
			// 
			// TODO: write code to guess what the format is.
			printf( "Unsupported Texture format: guessing it's format by pixel format.\n" );
			printf( "                            Suggest to define texture header by yourself.\n" );
			
			// not implemented, so assert
			assert( 0 && "Couldn't guess what kind of pixel format it is." );
			return -1;
		}
		else {
			printf( "======= pixel format  ==================\n" );
			printf( "	size:        %d\n", ddsh->ddspf.size );
			printf( "	flags:       0x%x\n", ddsh->ddspf.flags );
			printf( "	fourCC:      0x%x ('%c%c%c%c')\n", ddsh->ddspf.fourCC,
						  (ddsh->ddspf.fourCC >> 24) & 0xFF, 
						  (ddsh->ddspf.fourCC >> 16) & 0xFF, 
						  (ddsh->ddspf.fourCC >>  8) & 0xFF, 
						  (ddsh->ddspf.fourCC >>  0) & 0xFF );
			printf( "	rgbBitCount: %d\n", ddsh->ddspf.rgbBitCount );
			printf( "	rbitMask:    0x%08x\n", ddsh->ddspf.rbitMask );
			printf( "	gbitMask:    0x%08x\n", ddsh->ddspf.gbitMask );
			printf( "	bbitMask:    0x%08x\n", ddsh->ddspf.bbitMask );
			printf( "	abitMask:    0x%08x\n", ddsh->ddspf.abitMask );
			assert(0 && "ERROR: Uses a texture of unsupported type");
			return -1;
		}
	}

	return 0;
}

int cellUtilTextureMemorySize(uint32_t width, uint32_t height, uint32_t depth,
							  uint32_t format, uint32_t isCubemap)
{
	return 0;
}

//-----------------------------------------------------------------------------
// int tutorialDdsLoad(char *filename,CellUtilDDSTexture* dds)
// Description: 
// loads a dds texture file and fills out the dds structure
// Returns: 
//  0 on success
//  non-zero on failure
// Notes:
//-----------------------------------------------------------------------------
int cellUtilDDSRead(const char *filename, CellUtilDDSTexture *dds)
{
	uint32_t fileLen;

	//load the file
	fileLen = getFileLen(filename);
	if (!fileLen) {
		return EINVAL;
	}

	//unsigned char *buffer;
	unsigned char *buffer = (unsigned char*)malloc(fileLen);
	if (!buffer) {
		return ENOMEM;
	}

	int ret = loadFile(filename, fileLen, buffer);
	if (ret != 0) {
		return ret;
	}
	unsigned char *buff = buffer;

	// read in file marker, make sure its a DDS file
	if (strncmp((char*)buff, "DDS ", 4) != 0) {
		free(buffer);
		return EINVAL;
	}
	buff+=4;  //skip over header 

	//read the dds header data
	CellUtilDDSHeader *ddsh;
	ddsh = (CellUtilDDSHeader*)buff;
	buff += sizeof(CellUtilDDSHeader);

	#ifdef DEBUG // {
	printf( "ddsh->pitchOrLinearSize=0x%x, ddsh->flags=0x%x\n", ddsh->pitchOrLinearSize, ddsh->flags );
	#endif //  } DEBUG

	memcpy( &dds->ddspf, &ddsh->ddspf, sizeof(CellUtilDDSPixelFormat));

#ifdef __PPU__
	uint32_t *tmp = (uint32_t*)ddsh;
	for (unsigned int count = 0;
		 count < sizeof(CellUtilDDSHeader)/sizeof(uint32_t); count++) {
		swapEndian(tmp + count);
	}
#endif

	CellUtilTextureType type = TEXTURE_FLAT;
	if (ddsh->caps2 & DDSF_CUBEMAP) {
		type = TEXTURE_CUBEMAP;
	}
	#if 0 // {
	// check if image is a volume texture
	if ((ddsh->caps2 & DDSF_VOLUME) && (ddsh->depth > 0)) {
		printf("ERROR: volume texture is not supported (%s)\n",filename);
		return EINVAL;
	}
	#endif // }

	// get the format of the image
	uint32_t	format;
	uint32_t	components;

	//get the texture format and number of color channels
	if( getImageSpec(ddsh, &format, &components)<0) {
		fprintf( STDERR, "Couldn't recognize DDS file.\n" );	
		return -1;
	}

	uint32_t width, height, depth;
	width  = ddsh->width;
	height = ddsh->height;
	depth  = ddsh->depth;

	dds->buffer		= buffer;
	dds->size		= fileLen;
	dds->format		= format;
	dds->components = components;
	dds->height		= height;
	dds->width		= width;
	dds->depth      = depth;
	dds->border		= 0;

	if (ddsh->mipMapCount == 0) {
		ddsh->mipMapCount++;
	}

	dds->mips		= ddsh->mipMapCount;

	dds->surfaces = 1;
	if (type == TEXTURE_CUBEMAP) {
		dds->surfaces = 6;
	}

	dprintf(("format:     0x%x\n", format));
	dprintf(("components: 0x%x\n", components));
	dprintf(("height:     0x%x\n", height));
	dprintf(("width:      0x%x\n", width));
	dprintf(("depth:      0x%x\n", depth));
	dprintf(("mips:       0x%x\n", dds->mips));
	dprintf(("surfaces:   0x%x\n", dds->surfaces));

	//get pointers to the pixel data
	uint32_t i, j;

	// Huge branch here if the texture is 3D texture
	//
	if( dds->depth > 0 ) {
		
		// for each mipmap 
		for( i=0; i<dds->mips; i++ ) {

			// for each volume
			for( j=0; j<depth; j++ ) {
				dds->vol_image[j].pixels[i] = buff;
				dprintf(("Volume %d mip%d: 0x%x\n", j, i, (uint32_t)buff));

				buff += getImageSize( width, height,components, format );
			}

			if (width != 1) { width /= 2; }
			if (height != 1){ height /= 2;}
			if (depth != 1) { depth /= 2; }
		}
		
	}
	else {
		// Not 3D texture 
		// Either cubemap or 2D texture
		//
		for (i = 0; i < dds->surfaces; i++) {
			height = dds->height;
			width = dds->width;

			for (j = 0; j < ddsh->mipMapCount; j++) {
				dds->image[i].pixels[j] = buff;
				dprintf(("mips addr: 0x%x\n", (uint32_t)buff));
				buff += getImageSize(width,height,components,format);

				if (width != 1) {
					width /= 2;
				}
				if (height != 1) {
					height /= 2;
				}
			}
		}
	}


	return 0;
}

int cellUtilDDSUpdate(const char *filename, CellUtilDDSTexture *dds)
{
	FILE* fp;

	if ((fp = fopen(filename, "wb")) == NULL) {
		return EINVAL;
	}

	if (fwrite(dds->buffer, 1, dds->size, fp)!= dds->size) {
		return EINVAL;
	}

	fclose(fp);

	return 0;
}
