/*   SCE CONFIDENTIAL                                       */
/*   PLAYSTATION(R)3 Programmer Tool Runtime Library 192.001 */
/*   Copyright (C) 2007 Sony Computer Entertainment Inc.    */
/*   All Rights Reserved.                                   */

#include "type_def.h"

#if defined(__cplusplus)
extern	"C" {
#endif //

// Global flag & variables
uint8_t g_FlagSwizzle;
uint8_t g_FlagPack;
uint8_t g_FlagUnnormalize;
uint8_t g_VerboseMode;
uint8_t g_DetailedVerboseMode;
uint8_t g_ErrorReport;
uint8_t g_FlagForcePitch64;
uint8_t g_FlagAlignPitch;
uint8_t g_DebugDump;

// Global pitch size
uint32_t g_AlignPitchSize;
uint32_t g_OriginalAlignPitchSize;

#if defined(__cplusplus)
}
#endif //
