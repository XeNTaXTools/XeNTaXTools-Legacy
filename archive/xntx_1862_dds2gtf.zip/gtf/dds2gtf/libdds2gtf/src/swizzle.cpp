/*   SCE CONFIDENTIAL                                       */
/*   PLAYSTATION(R)3 Programmer Tool Runtime Library 192.001 */
/*   Copyright (C) 2007 Sony Computer Entertainment Inc.    */
/*   All Rights Reserved.                                   */

#include "common.h"
#include "swizzle.h"

//#define SWIZZLE_DEBUG
//#define MY_VERSION

// Compute the floor of the log base 2 of a unsigned integer
uint32_t _log2(const uint32_t n)
{
   uint32_t i;
   for(i = 1; (n >> i) > 0; i++)
   {
       // empty
   }
   return i-1;
}

// NOTE:
//   - cpu swizzle: straight forward and good to understand but terrible slow
//   - gpu swizzle: does not handle all cases, but is much faster
//
static uint32_t calcSwizzledAddress
(
    uint32_t u,
    uint32_t v,
    uint32_t p, 
    uint32_t log2depth,
    uint32_t log2height, 
    uint32_t log2width) 
{
    uint32_t offsetBitPos = 0;
    uint32_t offset = 0;

    while (log2depth + log2height + log2width)
    {
        if (log2width)
        {
            log2width--;
            offset |= (u & 1) << offsetBitPos;
            u >>= 1;
            offsetBitPos++;
        }
        if (log2height)
        {
            log2height--;
            offset |= (v & 1) << offsetBitPos;
            v >>= 1;
            offsetBitPos++;
        }
        if (log2depth)
        {
            log2depth--;
            offset |= (p & 1) << offsetBitPos;
            p >>= 1;
            offsetBitPos++;
        }
    }
    
    return offset;
}

//  Function name: convertLinearToSwizzle
//
//  Description:
//    This function converts linear format texture to swizzled texture.
//    Simply calls SwizzleDataCPU inside.
//
//  Note: 
//    To convert 2D texture, set depth to 1.
//    To convert 3D texture, set depth to > 1.
//  
//  Return value:
//   0 on success.
//  -1 on failure.
// 
//  Restriction:
//
int convertLinearToSwizzle(uint8_t *dst_tex, 
                            const uint8_t *src_tex,
						    const uint32_t WIDTH,
						    const uint32_t HEIGHT,
						    const uint32_t DEPTH,
						    const uint32_t bytesPerPixel)
{
    uint32_t texel = 0;
    uint32_t dstU, dstV, dstP;
    uint32_t srcU, srcV, srcP;

	uint32_t dstWidth;
	uint32_t dstHeight;
	uint32_t dstDepth;
	uint32_t srcWidth;
	uint32_t srcHeight;
	uint32_t srcDepth;

	int      bytesToCopy; 

	uint32_t dstLog2cdepth = bytesPerPixel==3? 2: _log2(bytesPerPixel);

    assert(dstLog2cdepth <= 5 );


	// Check if texture is FP32 texture
	// - Upper and lower 64 bits of FP32 texel is treated separately.
	//   
	switch( dstLog2cdepth ) {
	case 0:  //   8 bit
		dstWidth  = WIDTH;
		dstHeight = HEIGHT;
		dstDepth  = DEPTH;
		srcWidth  = WIDTH;
		srcHeight = HEIGHT;
		srcDepth  = DEPTH;
		bytesToCopy = 1;
		break;
	case 1:  //  16 bit
		dstWidth  = WIDTH;
		dstHeight = HEIGHT;
		dstDepth  = DEPTH;
		srcWidth  = WIDTH;
		srcHeight = HEIGHT;
		srcDepth  = DEPTH;
		bytesToCopy = 2;
		break;
	case 2:  //  32 bit (ARGB8)
		dstWidth  = WIDTH;
		dstHeight = HEIGHT;
		dstDepth  = DEPTH;
		srcWidth  = WIDTH;
		srcHeight = HEIGHT;
		srcDepth  = DEPTH;
		bytesToCopy = 4;
		break;
	case 3:  //  64 bit (FP16)
		dstWidth  = WIDTH  << 1;
		dstHeight = HEIGHT;
		dstDepth  = DEPTH;
		srcWidth  = WIDTH << 1;
		srcHeight = HEIGHT;
		srcDepth  = DEPTH;
		dstLog2cdepth = 2;
		bytesToCopy = 4;
		break;
	case 4:  // 128 bit (FP32)
		dstWidth  = WIDTH << 2;
		dstHeight = HEIGHT;
		dstDepth  = DEPTH;
		srcWidth  = WIDTH << 2;
		srcHeight = HEIGHT;
		srcDepth  = DEPTH;
		dstLog2cdepth = 2;
		bytesToCopy = 4;
		break;
	default:
		return -1;
	}

    uint32_t dstLog2Width  = _log2(dstWidth);
    uint32_t dstLog2Height = _log2(dstHeight);
    uint32_t dstLog2Depth  = _log2(dstDepth);

    srcP = 0;
    dstP = 0;

    while (srcP < srcDepth)
    {
        srcV = 0;
        dstV = 0;

        while (srcV < srcHeight)
        {
            srcU = 0;
            dstU = 0;

            while (srcU < srcWidth)
            {
				uint32_t newTexel;

				newTexel = calcSwizzledAddress(dstU, dstV, dstP,
											  dstLog2Depth, 
											  dstLog2Height, 
											  dstLog2Width) << dstLog2cdepth;

				texel = ((srcP * srcWidth * srcHeight) 
				       + (srcV * srcWidth) 
					   + (srcU)) << dstLog2cdepth;

				// copy texel
				unsigned char *src = (unsigned char *)&src_tex[texel];
				unsigned char *dst = (unsigned char *)&dst_tex[newTexel];
				for (int k=0; k < bytesToCopy; k++)
				{
					dst[k] = src[k];
				}

                // Increment the src/dst location
				srcU++;
                dstU++;
            }

			// Increment the src/dst location
            srcV++;
            dstV++;
        }

        srcP++;
        dstP++;
    }
	return 0;
}
