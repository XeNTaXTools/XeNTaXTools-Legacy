/*   SCE CONFIDENTIAL                                       */
/*   PLAYSTATION(R)3 Programmer Tool Runtime Library 192.001 */
/*   Copyright (C) 2007 Sony Computer Entertainment Inc.    */
/*   All Rights Reserved.                                   */

#include "common.h"
#include "debug_dump.h"

extern int32_t getImageSize(uint32_t w, uint32_t h,
							uint32_t components, uint32_t format);

// Function name: getPixelByRemap
//
// Description:
//  
static uint32_t getPixelByRemap( uint16_t remap, uint32_t color ) 
{
	uint32_t ret = 0;
	uint8_t check = 0;
	
#define A_SHIFT (24)
#define R_SHIFT (16)
#define G_SHIFT ( 8)
#define B_SHIFT ( 0)
	for( int i=0; i<4; i++ ) {
		switch( remap & 0x3 ) {
		case 0: 	// A channel
			ret |= ((color & 0xFF) << A_SHIFT);
			check |= 0x1;
			break;

		case 1: 	// R channel
			ret |= ((color & 0xFF) << R_SHIFT);
			check |= 0x2;
			break;

		case 2: 	// G channel
			ret |= ((color & 0xFF) << G_SHIFT);
			check |= 0x4;
			break;

		case 3: 	// Fall though!
		default:    // B channel
			check |= 0x8;
			ret |= ((color & 0xFF) << B_SHIFT);
		}
		remap >>= 2;	
		color >>= 8;
	}
#undef A_SHIFT 
#undef R_SHIFT 
#undef G_SHIFT 
#undef B_SHIFT 

	if( check != 0xF ) {
		fprintf( STDERR, "WARNING: Invalid remap\n" );
	}

	return ret;
}

// Function name: debugDumpWithFormat
// Description:
//  Dump raw image to PPM file format
// 
// Return Value:
//   0 - success
//  -1 - failure
//
static int debugDumpWithFormat( char* filename, uint8_t* data, int width, int height, 
                                uint16_t remap, DebugDumpFormat format )
{
	FILE* fp;
	int x, y;
	uint8_t a, r, g, b;	// for RGB color ( a will be skipped )
	uint8_t* traverser = data;
	
	assert( width > 0 );
	assert( height > 0 );

	// Open file for write
	fp = fopen( filename, "wb" );
	if( fp == NULL ) {
		fprintf( STDERR, "Error: fopen failed\n" );
		return -1;
	}

	// TODO: fix bug in PPM_P6
	if( format == PPM_P6 ) {
		// PPM Header part
		fprintf( fp, "P6\n" );
		fprintf( fp, "%d %d\n", width, height );
		fprintf( fp, "255\n" );

		// PPM Image data part
		for( y=0; y<height; y++ ) {
			for( x=0; x<width; x++ ) {

				uint32_t _color = *((uint32_t*)traverser);
				uint16_t _remap = remap;

				_color = getPixelByRemap( _remap, _color );
				traverser += sizeof( uint32_t );

				a = (uint8_t)((_color >> 24) & 0xFF); 
				r = (uint8_t)((_color >> 16) & 0xFF); 
				g = (uint8_t)((_color >>  8) & 0xFF); 
				b = (uint8_t)((_color >>  0) & 0xFF); 
				fputc( r, fp );
				fputc( g, fp );
				fputc( b, fp );
			}
		}
	}
	else if( format == PPM_P3 ) {
		// PPM Header part
		fprintf( fp, "P3\n" );
		fprintf( fp, "%d %d\n", width, height );
		fprintf( fp, "255\n" );

		// PPM Image data part
		for( y=0; y<height; y++ ) {
			for( x=0; x<width; x++ ) {

				uint32_t _color = *((uint32_t*)traverser);
				uint16_t _remap = remap;

				_color = getPixelByRemap( _remap, _color );
				traverser += sizeof( uint32_t );

				a = (uint8_t)((_color >> 24) & 0xFF); 
				r = (uint8_t)((_color >> 16) & 0xFF); 
				g = (uint8_t)((_color >>  8) & 0xFF); 
				b = (uint8_t)((_color >>  0) & 0xFF); 
				fprintf( fp, "%3d %3d %3d ", r, g, b );
			}
			fprintf( fp, "\n" );
		}
	}
	else {
		fprintf( STDERR, "Unsupported format for debug dump\n" );
		return -1;
	}

	fclose( fp );
	return 0;
}

// Function name debugDump
// 
//
void debugDump( uint8_t* data, char* infile, CellUtilDDSTexture* dds, CellGtfTextureAttribute* attrib ) 
{
	int width, height;
	char filename[255];

	uint8_t* _data = data;

	// for number of surface
	for( int surface=0; surface < (int)dds->surfaces; surface++ ) {

		width = dds->width;
		height = dds->height;

		for( int mip=0; mip < (int)dds->mips; mip++ ) {

			// dump p3
			#if 0 // {
			sprintf( filename, "%s_id%d_w%d_h%d_m%d_s%d_p3.ppm", infile,
					 attrib->Id, width, height, mip, surface );
			
			if( debugDumpWithFormat( filename, _data, width, height, attrib->tex.remap, PPM_P3 ) < 0 ) {
				fprintf( STDERR, "Error: dump to PPM(p3)\n" );
			}
			#endif // }

			// dump p6
			sprintf( filename, "%s_id%d_w%d_h%d_m%d_s%d_p6.ppm", 
			             infile, attrib->id, width, height, mip, surface );

			if( debugDumpWithFormat( filename, _data, width, height, attrib->tex.remap, PPM_P6 ) < 0 ) {
				fprintf( STDERR, "Error: dump to PPM(p6)\n" );
			}

			// adjust size for next mip level
			if( width  != 1 )  width  >>= 1;
			if( height != 1 )  height >>= 1;

			_data += getImageSize( width, height, 4, dds->format );

		} // for over mips

		_data = Pad_ptr( _data, 128 );

	}     // for over surfaces 

}
