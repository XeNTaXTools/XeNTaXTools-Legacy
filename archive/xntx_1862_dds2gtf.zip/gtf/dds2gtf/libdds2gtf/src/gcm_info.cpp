/*   SCE CONFIDENTIAL                                       */
/*   PLAYSTATION(R)3 Programmer Tool Runtime Library 192.001 */
/*   Copyright (C) 2007 Sony Computer Entertainment Inc.    */
/*   All Rights Reserved.                                   */

#include "common.h"
#include "gcm_info.h"

static const FormatMatchingTable sFormatTable[] = 
{
	{ FORMAT_B8,            CELL_GCM_TEXTURE_B8 },
	{ FORMAT_A1R5G5B5,      CELL_GCM_TEXTURE_A1R5G5B5 },
	{ FORMAT_A4R4G4B4,      CELL_GCM_TEXTURE_A4R4G4B4 },
	{ FORMAT_R5G6B5,        CELL_GCM_TEXTURE_R5G6B5 },
	{ FORMAT_RABG,          CELL_GCM_TEXTURE_A8R8G8B8 },
	{ FORMAT_RGBA,          CELL_GCM_TEXTURE_A8R8G8B8 },
	{ FORMAT_RGB,           CELL_GCM_TEXTURE_D8R8G8B8 },
	{ FORMAT_ARGB,          CELL_GCM_TEXTURE_A8R8G8B8 },
	{ FORMAT_ABGR,          CELL_GCM_TEXTURE_A8R8G8B8 },
	{ FORMAT_BGRA,          CELL_GCM_TEXTURE_A8R8G8B8 },
	{ FORMAT_GBAR,          CELL_GCM_TEXTURE_A8R8G8B8 },
	{ 0x83F1,               CELL_GCM_TEXTURE_COMPRESSED_DXT1 },
	{ 0x83F2,               CELL_GCM_TEXTURE_COMPRESSED_DXT23 },
	{ 0x83F3,               CELL_GCM_TEXTURE_COMPRESSED_DXT45 },
	{ FORMAT_G8B8,          CELL_GCM_TEXTURE_G8B8 },
	{ FORMAT_R6G5B5,        CELL_GCM_TEXTURE_R6G5B5 },
	{ (uint32_t)NULL,       CELL_GCM_TEXTURE_DEPTH24_D8 },
	{ (uint32_t)NULL,       CELL_GCM_TEXTURE_DEPTH24_D8_FLOAT },
	{ (uint32_t)NULL,       CELL_GCM_TEXTURE_DEPTH16 },
	{ FOURCC_R16F,          CELL_GCM_TEXTURE_DEPTH16_FLOAT },
	{ FORMAT_X16,           CELL_GCM_TEXTURE_X16 },
	{ FORMAT_Y16_X16,       CELL_GCM_TEXTURE_Y16_X16 },
	{ (uint32_t)NULL,       CELL_GCM_TEXTURE_R5G5B5A1 },
	{ (uint32_t)NULL,       CELL_GCM_TEXTURE_COMPRESSED_HILO8 },
	{ (uint32_t)NULL,       CELL_GCM_TEXTURE_COMPRESSED_HILO_S8 },
	{ FOURCC_A16B16G16R16F, CELL_GCM_TEXTURE_W16_Z16_Y16_X16_FLOAT },
	{ FOURCC_A32B32G32R32F, CELL_GCM_TEXTURE_W32_Z32_Y32_X32_FLOAT },
	{ FOURCC_R32F,          CELL_GCM_TEXTURE_X32_FLOAT },
	{ FORMAT_X1R5G5B5,      CELL_GCM_TEXTURE_D1R5G5B5 },
	{ FORMAT_D8R8G8B8,      CELL_GCM_TEXTURE_D8R8G8B8 },
	{ FOURCC_G16R16F,       CELL_GCM_TEXTURE_Y16_X16_FLOAT },
	{ FOURCC_YUY2,          CELL_GCM_TEXTURE_COMPRESSED_B8R8_G8R8 },
	{ FOURCC_YVYU,          CELL_GCM_TEXTURE_COMPRESSED_R8B8_R8G8 },
	{ FOURCC_R8G8_B8G8,     CELL_GCM_TEXTURE_COMPRESSED_B8R8_G8R8 },
	{ FOURCC_G8R8_G8B8,     CELL_GCM_TEXTURE_COMPRESSED_R8B8_R8G8 },
};

// 
#if 0 // [
static uint8_t shiftBitRemap( uint32_t mask ) {
	uint8_t i = 6;
	uint32_t work_mask = mask;

	if( mask == 0 ) return 0xFF;

	while( work_mask <<= 8 ) {
		i-=2;
	} 
	#ifdef _DEBUG_
	fprintf( STDERR, "============ Testing shiftBitRemap() =============\n" );
	fprintf( STDERR, "Input: 0x%08x   Output: %d\n", mask, i );
	#endif  // _DEBUG_

	return i;
}

//
static int getRemapBit(CellUtilDDSPixelFormat* pf, uint32_t mask ) 
{
	#ifdef _DEBUG_ // {
	if( mask & pf->rbitMask ) printf("0x%08x: R\n", mask );
	else if( mask & pf->gbitMask ) printf("0x%08x: G\n", mask );
	else if( mask & pf->bbitMask ) printf("0x%08x: B\n", mask );
	else if( mask & pf->abitMask ) printf("0x%08x: A\n", mask );
	else printf( "0x%08x: ZERO\n", mask );
	#endif // _DEBUG_ }

	if( mask & pf->rbitMask ) return CELL_GCM_TEXTURE_REMAP_FROM_R;
	if( mask & pf->gbitMask ) return CELL_GCM_TEXTURE_REMAP_FROM_G;
	if( mask & pf->bbitMask ) return CELL_GCM_TEXTURE_REMAP_FROM_B;
	if( mask & pf->abitMask ) return CELL_GCM_TEXTURE_REMAP_FROM_A;
	return CELL_GCM_TEXTURE_REMAP_ZERO;
}
#endif // ]

static uint32_t getRemapFromBitMask( CellUtilDDSPixelFormat* pf ) 
{
	uint32_t remap = 0;

	// order
	uint32_t mask[4];
	char c[4] = {'\0'};
	int order[4] = {0};

	//struct rgba_set rgba[4];

	mask[0] = pf->abitMask; c[0] = 'a';
	mask[1] = pf->rbitMask; c[1] = 'r';
	mask[2] = pf->gbitMask; c[2] = 'g';
	mask[3] = pf->bbitMask; c[3] = 'b';

	// find biggest bitmask among rgba bit flag.
	// The color of the biggest one is the one on the most left side in bit order.
	//

	if( ! (pf->flags & 0x01)) {	
		// no alpha is contained. So need to figure out pixel format by looking at 
		// bit mask.
		// We have two cases here, 16 bit texels and 32 bit texels. 
		// And usually alpha bits are put at most-left or most-right side.
		//
		// TODO: handle alpha bits located at unusual bit location.
		//
		// if other rgb color bits covers LSB, then we assume 
		// alpha bits to use them. 
		if( (pf->rbitMask & 1) |
			(pf->gbitMask & 1) |
			(pf->bbitMask & 1) )
		{
			//mask[0] = 1 << (pf->rgbBitCount-1);
			mask[0] = 1 << 31;
		}
		else {
			mask[0] = 0;
		}
	}

	// NOTE: only need the order of rgba element. 
	//       no sorting required.
	//
	for( int i=0; i<4; i++ ) { // each rgba
		for( int j=0; j<4; j++ ) {
			if( i != j ) {
				if( mask[i] < mask[j] )
					order[i] += 1;
			}
		}
	}

	#ifdef DEBUG // {
	printf( "==========================>>\n" );
	for( int i=0; i<4; i++ ) {
		printf( "Color '%c' (mask=0x%08X): %d\n", c[i], mask[i], order[i] );
	}
	printf( "<<==========================\n" );
	#endif  // } DEBUG

	remap |= 
		CELL_GCM_TEXTURE_REMAP_REMAP << (6 + 8) |   // remap
		CELL_GCM_TEXTURE_REMAP_REMAP << (4 + 8) | 
		CELL_GCM_TEXTURE_REMAP_REMAP << (2 + 8) | 
		CELL_GCM_TEXTURE_REMAP_REMAP << (0 + 8);

	for( int i=0; i<4; i++ ) {
		switch(order[i]) {
		case 0:
			remap |= (CELL_GCM_TEXTURE_REMAP_FROM_A << (i*2));

			// if 'no alpha' flag is on, we set REMAP_ONE to remap.
			if( ! (pf->flags & 0x01)) {	

				// zero clear on alpha bits field
				remap &= ~(0x3 << (i*2+8));

				// put REMAP_ONE to alpha bits field
				remap |= (CELL_GCM_TEXTURE_REMAP_ONE << (i*2+8));
			}
			break;
		case 1:
			remap |= (CELL_GCM_TEXTURE_REMAP_FROM_R << (i*2));
			break;
		case 2:
			remap |= (CELL_GCM_TEXTURE_REMAP_FROM_G << (i*2));
			break;
		case 3:
			remap |= (CELL_GCM_TEXTURE_REMAP_FROM_B << (i*2));
			break;
		default:
			assert(0);
		}
	}

	#if 0 // {
	// overwrite temporary remap setting
	remap = 
		CELL_GCM_TEXTURE_REMAP_REMAP << (6 + 8) |   // remap
		CELL_GCM_TEXTURE_REMAP_REMAP << (4 + 8) | 
		CELL_GCM_TEXTURE_REMAP_REMAP << (2 + 8) | 
		CELL_GCM_TEXTURE_REMAP_ZERO << (0 + 8) |
		CELL_GCM_TEXTURE_REMAP_FROM_R << 6 | 
		CELL_GCM_TEXTURE_REMAP_FROM_G << 4 | 
		CELL_GCM_TEXTURE_REMAP_FROM_B << 2 | 
		CELL_GCM_TEXTURE_REMAP_FROM_A; 

	#endif // }
	
	return remap;
}

//
// Get remap configuration from dds header attribute.
//
//
static uint32_t getRemapFromDDS( CellUtilDDSPixelFormat* pf ) 
{
	uint32_t remap = 0;

	assert( pf != NULL );

	switch( pf->flags ) {
	case 0x00000004: 	// dwFourCC is valid 
		switch( pf->fourCC ) {
		case 0x31545844: 	// '1TXD'
		case 0x32545844: 	// '2TXD'
		case 0x33545844: 	// '3TXD'
		case 0x34545844: 	// '4TXD'
		case 0x35545844: 	// '5TXD'
		case FOURCC_A16B16G16R16F:
		case FOURCC_A32B32G32R32F:
		case FOURCC_R16F:
		case FOURCC_G16R16F:
		case FOURCC_R32F:
			// Remap must be straight-forward for float16/32 texture
			remap = 
				CELL_GCM_TEXTURE_REMAP_REMAP << 14 |   // remap
				CELL_GCM_TEXTURE_REMAP_REMAP << 12 | 
				CELL_GCM_TEXTURE_REMAP_REMAP << 10 | 
				CELL_GCM_TEXTURE_REMAP_REMAP <<  8 | 
				CELL_GCM_TEXTURE_REMAP_FROM_B << 6 | 
				CELL_GCM_TEXTURE_REMAP_FROM_G << 4 | 
				CELL_GCM_TEXTURE_REMAP_FROM_R << 2 | 
				CELL_GCM_TEXTURE_REMAP_FROM_A; 
			break;
		case FOURCC_R8G8_B8G8: 
		case FOURCC_G8R8_G8B8: 
			remap = 
				CELL_GCM_TEXTURE_REMAP_REMAP << 14 |   // remap
				CELL_GCM_TEXTURE_REMAP_REMAP << 12 | 
				CELL_GCM_TEXTURE_REMAP_REMAP << 10 | 
				CELL_GCM_TEXTURE_REMAP_REMAP <<  8 | 
				CELL_GCM_TEXTURE_REMAP_FROM_G << 6 | 
				CELL_GCM_TEXTURE_REMAP_FROM_R << 4 | 
				CELL_GCM_TEXTURE_REMAP_FROM_B << 2 | 
				CELL_GCM_TEXTURE_REMAP_FROM_A; 
			break;
		case FOURCC_YVYU:
		case FOURCC_YUY2:
			remap = 
				CELL_GCM_TEXTURE_REMAP_REMAP << 14 |   // remap
				CELL_GCM_TEXTURE_REMAP_REMAP << 12 | 
				CELL_GCM_TEXTURE_REMAP_REMAP << 10 | 
				CELL_GCM_TEXTURE_REMAP_REMAP <<  8 | 
				CELL_GCM_TEXTURE_REMAP_FROM_G << 6 | 
				CELL_GCM_TEXTURE_REMAP_FROM_B << 4 | 
				CELL_GCM_TEXTURE_REMAP_FROM_R << 2 | 
				CELL_GCM_TEXTURE_REMAP_FROM_A; 
			break;	
		default:
			fprintf( STDERR, "Pixel format not supported: dwFourCC\n" );
		}
		break;
	case 0x00000040:	  // dwRGBBitCount, RGBBitMask are defined
	case 0x00000041:      // alpha is also defined
	case 0x00000002:      // Only Alpha (1 component)
	case 0x00020000:      // expand 1 ch data to RGB      
	case 0x00020001:      // contains alpha        
	case 0x00040000:      // r6g5b5
	case DDSF_BUMPDUDV:   // X16Y16 bumpmap
		remap = 0;

		// in case of any of color bits is more than 8 bits long.
		if( (countBit( pf->rbitMask ) == 16) | (countBit( pf->gbitMask ) == 16) |
		    (countBit( pf->bbitMask ) == 16) | (countBit( pf->abitMask ) == 16) ) 
		{
			// TODO: Remap order.... Allow user to pick XXXY and XYXY?
			remap |= CELL_GCM_TEXTURE_REMAP_ORDER_XYXY << (16);

			remap |= CELL_GCM_TEXTURE_REMAP_REMAP << (6+8) |
					 CELL_GCM_TEXTURE_REMAP_REMAP << (4+8) |
				     CELL_GCM_TEXTURE_REMAP_REMAP << (2+8) |
			         CELL_GCM_TEXTURE_REMAP_REMAP << (0+8);

			remap |= 
				(CELL_GCM_TEXTURE_REMAP_FROM_B << 6) | 
				(CELL_GCM_TEXTURE_REMAP_FROM_G << 4) |
				(CELL_GCM_TEXTURE_REMAP_FROM_R << 2) |
				(CELL_GCM_TEXTURE_REMAP_FROM_A);
		}
		else if( pf->rgbBitCount == 8 )
		{
			// SimonB: handle L8 or A8 textures manually as we need a custom remap
			if( pf->rbitMask )
			{
				// L8 format (B-B-B-1)
				remap = CELL_GCM_TEXTURE_REMAP_REMAP << ( 6 + 8 )
					| CELL_GCM_TEXTURE_REMAP_REMAP << ( 4 + 8 )
					| CELL_GCM_TEXTURE_REMAP_REMAP << ( 2 + 8 )
					| CELL_GCM_TEXTURE_REMAP_ONE << ( 0 + 8 )
					| CELL_GCM_TEXTURE_REMAP_FROM_B << 6
					| CELL_GCM_TEXTURE_REMAP_FROM_B << 4 
					| CELL_GCM_TEXTURE_REMAP_FROM_B << 2
					| CELL_GCM_TEXTURE_REMAP_FROM_B;
			}
			else
			{
				// A8 format (0-0-0-B)
				remap = CELL_GCM_TEXTURE_REMAP_ZERO << ( 6 + 8 )
					| CELL_GCM_TEXTURE_REMAP_ZERO << ( 4 + 8 )
					| CELL_GCM_TEXTURE_REMAP_ZERO << ( 2 + 8 )
					| CELL_GCM_TEXTURE_REMAP_REMAP << ( 0 + 8 )
					| CELL_GCM_TEXTURE_REMAP_FROM_B << 6
					| CELL_GCM_TEXTURE_REMAP_FROM_B << 4 
					| CELL_GCM_TEXTURE_REMAP_FROM_B << 2
					| CELL_GCM_TEXTURE_REMAP_FROM_B;
			}
		}
		// if rgb bits are not null (defined)
		else if ( pf->rbitMask | pf->gbitMask | pf->bbitMask | pf->abitMask ) {
			remap = getRemapFromBitMask( pf );
		}
		else {
			remap |= 
				CELL_GCM_TEXTURE_REMAP_REMAP << (6 + 8) |   // remap
				CELL_GCM_TEXTURE_REMAP_REMAP << (4 + 8) | 
				CELL_GCM_TEXTURE_REMAP_REMAP << (2 + 8) | 
				CELL_GCM_TEXTURE_REMAP_REMAP << (0 + 8);

			remap |= 
				(CELL_GCM_TEXTURE_REMAP_FROM_A << 6) | 
				(CELL_GCM_TEXTURE_REMAP_FROM_R << 4) |
				(CELL_GCM_TEXTURE_REMAP_FROM_G << 2) |
				(CELL_GCM_TEXTURE_REMAP_FROM_B);
		}
		break;
	default:
		fprintf( STDERR, "ERROR: Pixel format not supported: dwPfFlags\n" );
		printf( "	pf->size:        %d\n", pf->size );
		printf( "	pf->flags:       0x%x\n", pf->flags );
		printf( "	pf->fourCC:      0x%x ('%c%c%c%c')\n", pf->fourCC,
					  (pf->fourCC >> 24) & 0xFF, 
					  (pf->fourCC >> 16) & 0xFF, 
					  (pf->fourCC >>  8) & 0xFF, 
					  (pf->fourCC >>  0) & 0xFF );
		printf( "	pf->rgbBitCount: %d\n", pf->rgbBitCount );
		printf( "	pf->rbitMask:    0x%08x\n", pf->rbitMask );
		printf( "	pf->gbitMask:    0x%08x\n", pf->gbitMask );
		printf( "	pf->bbitMask:    0x%08x\n", pf->bbitMask );
		printf( "	pf->abitMask:    0x%08x\n", pf->abitMask );

	}  // switch ( pf->flags )

	assert( remap );
	return remap;
}

// Description:
//   Returns remap for pixel format.
//   If parameter is NULL, then it assumes input pixel format is RGBA.
//
uint32_t getRemap( CellUtilDDSTexture* dds ) 
{
	return getRemapFromDDS( &dds->ddspf );
}

/* 
 * returns Gcm format that corresponds to dds format
 */
uint8_t getGcmFormat( uint32_t dds_format ) 
{
	uint32_t i;
	for( i=0; i< sizeof(sFormatTable)/sizeof(sFormatTable[0]); i++ ) {
		if( sFormatTable[i].dds_format == dds_format )
			return sFormatTable[i].gcm_format;
	}
	printf( "log: DDS format not supported. Try to encode in A8R8G8B8.\n" );
	return CELL_GCM_TEXTURE_A8R8G8B8;
}

// Description:
//   Count number of on-bit in bits  
//
int countBit( uint32_t bits )
{
	int ret = 0;
	int i;

	for( i=0; i<32; i++ ) {
		if( (bits>>i) & 0x1 ) ret++;
	}
	return ret;
}

// Description:
//  get x's closeset power of 2 value
// 
uint32_t toPowOf2( uint32_t x ) 
{
	int i=0;

	if((x & (x-1)) == 0 ) // is pow of 2
		return x;

	while((x >> i) != 0 ) i++;
	return (1 << i);
}
