/*   SCE CONFIDENTIAL                                       */
/*   PLAYSTATION(R)3 Programmer Tool Runtime Library 192.001 */
/*   Copyright (C) 2007 Sony Computer Entertainment Inc.    */
/*   All Rights Reserved.                                   */

#include <stdio.h>
#include <stdlib.h>
#include <string.h> // strcmp(), strncmp(), strlen()
#include <ctype.h>  // tolower()

// avoid build break on Linux
#ifdef WIN32 //[
#include <excpt.h>
#endif // ]

#include "dds2gtf.h"

#ifdef WIN32	
#define PROG_NAME "dds2gtf.exe"
#else 
#define PROG_NAME "dds2gtf"
#endif

#define STDERR stderr

#define VERSION  0x01010000   // 1.1.0  (20070326)

// String to print at -v option is given 
//
#define ETC_STRING "SCE Original build"

static const GTF_UINT32_T MAX_INPUT_FILES     = 65536;
static const GTF_UINT32_T MAX_FILENAME_LENGTH = 1024;

class GTFConverter 
{
	public:
		// Constructor
		GTFConverter( void );
		GTFConverter( int argc, char** argv);

		void outputToFile( void );
		void setInputFileName( const char* );
		void parseInputFileList( const char* );
		void setOutputFileName( const char* );
		void setPitchSize( const char* );

		void printVersion( void );
		void printUsage(void);

		GTF_UINT32_T my_pow( GTF_UINT32_T x, GTF_UINT32_T p );
		GTF_UINT32_T my_atoh( const char* hex );

	private:

		char mOutputFileName[MAX_FILENAME_LENGTH];
		GTF_UINT32_T mOption;
		// maximum of  input files are supported
		char* mInputFiles[MAX_INPUT_FILES];

		GTF_UINT32_T mPitchSize; 
		
		GTF_UINT32_T mNumInputFiles;

		int handleOption( int argc, char** argv );
		int validateFileNames( void );
};

// Constructor with no argument
GTFConverter::GTFConverter( void ) 
{
	mOutputFileName[0] = 0;
	mNumInputFiles = 0;
	mOption = 0;
	mPitchSize = 0;
}

// Constructor with int and char** argument
GTFConverter::GTFConverter( int argc, char** argv ) 
{
	mOutputFileName[0] = 0;
	mNumInputFiles = 0;
	mOption = 0;
	mPitchSize = 0;

	if( handleOption( argc, argv ) < 0 ) {
		printUsage();
		exit(0);
	}
}

static int isNumber( char a )
{
	return ((a >= '0') && (a <= '9'));
}

// Function: handleOption
//
// Description:
//   handle command line option character
// 
int GTFConverter::handleOption( int argc, char** argv ) 
{
	int ret = 0;
	int arg_index;
	size_t opt_index;

	if( argc == 1 ) ret = -1;

	for( arg_index=1; arg_index<argc; arg_index++ ) {

		// check if this argument is option
		if( argv[arg_index][0] == '-' )	{	

			// handle option that takes secondary argument
			if( argv[arg_index][1] == 'o' ) {
				
				// must be '-o'
				if( strcmp( argv[arg_index], "-o" )) {
					printf( "WARNING: Unknown option: %s\n", argv[arg_index] );
				}
				else {
					// increment argment index by 1 to point to next argument
					arg_index++;

					// set output filename
					if( arg_index < argc )
						setOutputFileName( argv[arg_index] );
					else
						printf( "WARNING: Output Filename is missing...\n" );
				}

			}
			else if( argv[arg_index][1] == 'a' ) {

				// must be '-a'
				if( strcmp( argv[arg_index], "-a" )) {
					printf( "WARNING: Unknown option: %s\n", argv[arg_index] );
				}
				else {
					// increment argment index by 1 to point to next argument
					arg_index++;

					// set output filename
					if( arg_index < argc ) {
						mOption |= CELL_TEXCONV_FLAG_USER_GIVEN_PITCH;
						setPitchSize( argv[arg_index] );
					}
					else {
						printf( "Error: Alignment number is missing...\n" );
						ret = -1;
					}
				}
				
			}
			else if( argv[arg_index][1] == 'f' ) {

				// must be '-f'
				if( strcmp( argv[arg_index], "-f" )) {
					printf( "WARNING: Unknown option: %s\n", argv[arg_index] );
				}
				else {
					// increment argment index by 1 to point to next argument
					arg_index++;

					// set output filename
					if( arg_index < argc )
						parseInputFileList(argv[arg_index]);
					else
						printf( "WARNING: Input Filename is missing...\n" );
				}
			}
			else if( isNumber(argv[arg_index][1]) ) {
				GTF_UINT32_T number = atoi( &argv[arg_index][1] );

				switch( number ) {
				case 64:
					mOption |= CELL_TEXCONV_FLAG_ALIGN_PITCH_64;
					break;
				default:
					printf( "WARNING: Unknown option: %s\n", argv[arg_index] );
				}
			}
			else {	 

				// check option (string) by 1 character at a time
				for( opt_index=1; opt_index < strlen(argv[arg_index]); opt_index++ ) {
					switch( argv[arg_index][opt_index] ) {
					case 's': // swizzle
						mOption |= CELL_TEXCONV_FLAG_SWIZZLIZE;
						break;
					case 'u': // unnormalize
						mOption |= CELL_TEXCONV_FLAG_UNNORMALIZE;
						break;
					case 'v': // verbose
						mOption |= CELL_TEXCONV_FLAG_VERBOSE;
						break;
					case 'z': // very detailed
						mOption |= CELL_TEXCONV_FLAG_DETAILED_VERBOSE;
						break;
					case 'p': // packed ( not used )
						mOption |= CELL_TEXCONV_FLAG_PACKED;
						break;
					case 'h': // Help (usage) message
						ret = -1;
						break;
					//case 'd': // Debug Dump
					//	mOption |= CELL_TEXCONV_FLAG_DEBUG_DUMP;
					//	break;
					case 'e': // Error Report
						mOption |= CELL_TEXCONV_FLAG_ERROR_REPORT;
						break;
					default:  
						printf( "WARNING: Unknown option: %c\n", argv[arg_index][opt_index] );
						ret = -1;
					}
				}
			}

		}
		else {	// then this argument is input file
			setInputFileName( argv[arg_index] );
		}
	}
	return ret;
}

// Parse input file list
void GTFConverter::parseInputFileList( const char* file)
{
	FILE* fp;
	char inputFileList[MAX_FILENAME_LENGTH];

	// Open file
	fp = fopen( file, "r" );
	{
		if( fp == NULL ) {
			printf( "Error: Opening input file list (%s)\n", file );
			printf( "       Ignore reading input file list.\n" );
			return;
		}

		// until EOF
		while( ! feof( fp ) ) {

			char* buf = inputFileList;

			// getline
			fgets( buf, MAX_FILENAME_LENGTH, fp );
			
			// remove padded spaces before filename
			for(size_t i=0; i<strlen(buf); i++ ) {
				if( buf[i] != ' ' ) {
					buf += i;
					break;
				}
			}

			// treat comment/null line
			if( buf[0] == '#' || buf[0] == '\n' ) {
				continue;
			}

			// set input file name
			sscanf( buf, "%s", buf );
			setInputFileName( buf );
		}
	}
	// Close file
	fclose( fp );
}

// Set input filename
void GTFConverter::setInputFileName( const char* name ) 
{
	static bool errorOnce = false;

	if( mNumInputFiles >= MAX_INPUT_FILES ) {
		// print error message only once
		if( ! errorOnce ) {
			printf( "Warning: Total number of input texture exceeded the max number of texture supported.\n" );
			printf( "Only %d files can be converted into one GTF file\n", MAX_INPUT_FILES );
			errorOnce = true;
		}
	}
	else {
		mInputFiles[mNumInputFiles] = strdup( name );		
		mNumInputFiles++;
	}
}

// Set output filename
void GTFConverter::setOutputFileName( const char* name ) 
{
	strcpy( mOutputFileName, name );
}

GTF_UINT32_T GTFConverter::my_pow( GTF_UINT32_T x, GTF_UINT32_T p )
{
	GTF_UINT32_T ret = 1;

	for( GTF_UINT32_T i=0; i<p; i++ )
	{
		ret *= x;
	}
	return ret;
}

GTF_UINT32_T GTFConverter::my_atoh( const char* hex )
{
	GTF_UINT32_T dec = 0;

	// loop for each character
	for( size_t i=0; i < strlen(hex); i++ ) {

		// begin with 1's
		char c = tolower(hex[i]);

		// is hex number?
		if('0' <= c && c <= '9') {
			dec <<= 4;
			dec += (c-'0');
		}
		else if('a' <= c && c <= 'f') {
			dec <<= 4;
			dec += (c-'a'+10);
		}
		else {
			printf( "Invalid Hex character found\n" );
		}
	}
	return dec;
}


// Set pitch size
void GTFConverter::setPitchSize( const char* pitch )
{
	GTF_UINT32_T  pitch_size;

	// Branch for handling HEX or DEC 
	if(strncmp( pitch, "0x", 2 ) == 0)
		pitch_size = my_atoh( &pitch[2] );
	else
		pitch_size = atoi( pitch );

	mPitchSize = pitch_size;
}

int GTFConverter::validateFileNames( void ) 
{
	// check number of input files
	if( mNumInputFiles == 0 ) {
		printf( "ERROR: No Input file\n" );
		return -1;
	}


	// check file extension of input file
	for( GTF_UINT32_T i=0; i<mNumInputFiles; i++ ) {
		if( strcmp( &mInputFiles[i][strlen(mInputFiles[i])-4], ".dds" )) {
			printf( "Input file must be DDS file. Force rename %s to %s.dds\n", 
						   mInputFiles[i], mInputFiles[i]);
			strcat( mInputFiles[i], ".dds" );
		}
	}

	// Set output file if not specified
	if( mOutputFileName[0] == 0 ) {
		size_t len = strlen(mInputFiles[0])-4;
		strncpy( mOutputFileName, mInputFiles[0], len);
		strcpy( mOutputFileName + len, ".gtf" );
	}

	return 0;
}

void GTFConverter::outputToFile( void )
{
	// File name check before conversion
	if( validateFileNames() < 0 ) {
		printUsage();
	}
	else {

		// if pitch size is specified, tell it to library function 
		if( (mOption | CELL_TEXCONV_FLAG_USER_GIVEN_PITCH) && (mPitchSize > 0)) {
			dds2gtf_set_pitch_size( mPitchSize );
		}

		// Start Conversion by calling TexConv library function
		dds2gtf_output_to_file( mInputFiles, mNumInputFiles, mOutputFileName, mOption );

	}
}

void GTFConverter::printVersion( void )
{
	int ver0, ver1, ver2, ver3;
	ver0 = (VERSION >> 24) & 0xFF;
	ver1 = (VERSION >> 16) & 0xFF;
	ver2 = (VERSION >>  8) & 0xFF;
	ver3 = (VERSION >>  0) & 0xFF;
	
	printf( "%s  Version %d.%d.%d.%d", PROG_NAME, ver0, ver1, ver2, ver3 );

	if( strlen(ETC_STRING) != 0 ) 
		printf( " (%s)", ETC_STRING );

	printf( "\n\n" );
}

void GTFConverter::printUsage( void ) 
{
	printVersion();

	printf( "Usage: %s [options] file(s)\n", PROG_NAME );
		printf( "Options:\n" );
		printf( " -o <file>    Output to <file>\n" );
		printf( " -f <file>    Takes input DDS file list from file\n" );
		printf( "              (delimiter = CARRIAGE RETURN/ENTER)\n" );
		printf( " -s           Convert to swizzle format\n" );
		printf( " -u           Unnormalize flag on\n" );
		printf( " -v           Show detail information about texture\n" );
		printf( " -z           More detailed information on conversion\n" );
		printf( " -p           packed allocation in file\n" );
		printf( " -a <pitch>   specify pitch of linear texture\n" );
		printf( " -64          align pitch of linear texture to 64 bytes\n" );
		printf( " -h           Print this message\n" );
}

int main( int argc, char** argv ) 
{
	// Instantiate class object
	GTFConverter conv( argc, argv );

	// Use SEH to handle conversion errors
# ifdef WIN32 // [
    __try {
# endif // ]

		conv.outputToFile();

# ifdef WIN32 // [
	}
	__except( EXCEPTION_EXECUTE_HANDLER ) {
		fprintf( STDERR, "exception occurred, this is probably due to a corrupt DDS file!\n" );
		return 1;
	}
# endif // ]

	return 0;
}
