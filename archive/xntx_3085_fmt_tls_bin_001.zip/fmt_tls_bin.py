#Noesis Python model import+export test module, imports/exports some data from/to a made-up format
#version 0.01

from inc_noesis import *
import xml.dom.minidom as xd

import noesis

#rapi methods should only be used during handler callbacks
import rapi

#registerNoesisTypes is called by Noesis to allow the script to register formats.
#Do not implement this function in script files unless you want them to be dedicated format modules!
def registerNoesisTypes():
	handle = noesis.register("Love Tore Sweet", ".bin")
	noesis.setHandlerTypeCheck(handle, ltsCheckType)
	noesis.setHandlerLoadModel(handle, ltsLoadModel) #see also noepyLoadModelRPG
	#noesis.setHandlerWriteModel(handle, ltsWriteModel)
	#noesis.setHandlerWriteAnim(handle, ltsWriteAnim)

	#noesis.logPopup()
	#print("The log can be useful for catching debug prints from preview loads.\nBut don't leave it on when you release your script, or it will probably annoy people.")
	return 1

#check if it's this type based on the data
def ltsCheckType(data):
	if len(data) < 8:
		return 0
	bs = NoeBitStream(data)

	return 1

#load the model
def ltsLoadModel(data, mdlList):
	ctx = rapi.rpgCreateContext()
	bs = NoeBitStream(data)
	bs.setEndian(NOE_BIGENDIAN)
	rapi.rpgSetOption(noesis.RPGOPT_BIGENDIAN, 1)
	#Create the root XML node ans set attributes
	doc = xd.Document()
	while True:
		nodeStart = bs.tell()
		nodeType = bs.readBytes(4).decode("ASCII").rstrip("\0")
		#print(nodeType)
		if nodeType == "AGHX":
			AGHX_node = doc.createElement("AGHX")
			AGHX_header = bs.read(">" + "H" * 6)
			doc.appendChild(AGHX_node)
			AGHX_node.setAttribute("version", str(AGHX_header[0]))
			bs.seek((nodeStart + AGHX_header[2]), NOESEEK_ABS)
		elif nodeType == "SCEN":
			SCEN_node = doc.createElement("SCEN")
			SCEN_header = bs.read(">" + "H" * 6)
			bs.seek(nodeStart + SCEN_header[2], NOESEEK_ABS)
			AGHX_node.appendChild(SCEN_node)
			SCEN_node.setAttribute("count?", str(SCEN_header[1]))
			for a in range(0, 2):
				sSize = bs.read(">" + "H" * 2)
				SCEN_string = bs.readBytes(sSize[1]).decode("ASCII").rstrip("\0")
				sub_SCEN_node = doc.createTextNode(SCEN_string)
				SCEN_node.appendChild(sub_SCEN_node)
		elif nodeType == "ANIM":
			ANIM_node = doc.createElement("ANIM")
			ANIM_header = bs.read(">" + "H" * 6)
			bs.seek(nodeStart + ANIM_header[2], NOESEEK_ABS)
			AGHX_node.appendChild(ANIM_node)
			ANIM_node.setAttribute("count1?", str(ANIM_header[1]))
		elif nodeType == "ANTR":
			ANTR_node = doc.createElement("ANTR")
			ANTR_header = bs.read(">" + "H" * 6)
			bs.seek(nodeStart + ANTR_header[2], NOESEEK_ABS)
			ANIM_node.appendChild(ANTR_node)
			ANTR_node.setAttribute("count1?", str(ANTR_header[1]))
			ANTR_node.setAttribute("count2?", str(ANTR_header[3]))
			for a in range(0, 1):
				sSize = bs.read(">" + "H" * 2)
				ANTR_string = bs.readBytes(sSize[1]).decode("ASCII").rstrip("\0")
				ANTR_node.setAttribute("name", ANTR_string)
		elif nodeType == "ANTM":
			ANTM_node = doc.createElement("ANTM")
			ANTM_header = bs.read(">" + "H" * 6)
			bs.seek(nodeStart + ANTM_header[2], NOESEEK_ABS)
			ANTR_node.appendChild(ANTM_node)
			ANTM_node.setAttribute("count1?", str(ANTM_header[1]))
			bs.seek(4 * ANTM_header[1], NOESEEK_REL)
		elif nodeType == "ANVL":
			ANVL_node = doc.createElement("ANVL")
			ANVL_header = bs.read(">" + "H" * 6)
			bs.seek(nodeStart + ANVL_header[2], NOESEEK_ABS)
			ANTR_node.appendChild(ANVL_node)
			ANVL_node.setAttribute("count1?", str(ANVL_header[1]))
			bs.seek((4 * ANVL_header[1]) + 16, NOESEEK_REL)
		elif nodeType == "IMGH":
			IMGH_node = doc.createElement("IMGH")
			IMGH_header = bs.read(">" + "H" * 6)
			bs.seek(nodeStart + IMGH_header[2], NOESEEK_ABS)
			AGHX_node.appendChild(IMGH_node)
			IMGH_node.setAttribute("count?", str(IMGH_header[1]))
			for a in range(0, (IMGH_header[1] * 2)):
				sSize = bs.read(">" + "H" * 2)
				IMGH_string = bs.readBytes(sSize[1]).decode("ASCII").rstrip("\0")
				sub_IMGH_node = doc.createTextNode(IMGH_string)
				IMGH_node.appendChild(sub_IMGH_node)
		elif nodeType == "BMAT":
			BMAT2_node = doc.createElement("BMAT")
			BMAT_header = bs.read(">" + "H" * 6)
			bs.seek(nodeStart + BMAT_header[2], NOESEEK_ABS)
			AGHX_node.appendChild(BMAT2_node)
			BMAT2_node.setAttribute("count", str(BMAT_header[1]))
			for i in range(0, BMAT_header[1]):
				sSize = bs.read(">" + "H" * 2)
				BMAT_string = bs.readBytes(sSize[1]).decode("ASCII").rstrip("\0")
				BMAT_node = doc.createElement(BMAT_string)
				BMAT2_node.appendChild(BMAT_node)
				BMAT_Sub_header = bs.read(">" + "I" * 2)
				for a in range(0, BMAT_Sub_header[1]):
					sSize = bs.read(">" + "H" * 2)
					BMAT_string = bs.readBytes(sSize[1]).decode("ASCII").rstrip("\0")
					sub_BMAT_node = doc.createElement(BMAT_string)
					BMAT_node.appendChild(sub_BMAT_node)
					BMAT_Sub2_header = bs.read(">" + "I" * 2)
					if BMAT_Sub2_header[0] == 3:
						bs.seek((4 * BMAT_Sub2_header[1]), NOESEEK_REL)
					elif BMAT_Sub2_header[0] == 5:
						sSize = bs.read(">" + "H" * 2)
						BMAT_string = bs.readBytes(sSize[1]).decode("ASCII").rstrip("\0")
						sub_BMAT_node.setAttribute("name", BMAT_string)
		elif nodeType == "MATD":
			MATD_node = doc.createElement("MATD")
			MATD_header = bs.read(">" + "H" * 6)
			bs.seek(nodeStart + MATD_header[2], NOESEEK_ABS)
			AGHX_node.appendChild(MATD_node)
			MATD_node.setAttribute("count", str(MATD_header[1]))
			for a in range(0, MATD_header[1]):
				for b in range(0, 2):
					sSize = bs.read(">" + "H" * 2)
					MATD_string = bs.readBytes(sSize[1]).decode("ASCII").rstrip("\0")
					sub_MATD_node = doc.createTextNode(MATD_string)
					MATD_node.appendChild(sub_MATD_node)
				MATD_Sub_header = bs.read(">" + "I" * 2)
				for b in range(0, MATD_Sub_header[1]):
					sSize = bs.read(">" + "H" * 2)
					MATD_string = bs.readBytes(sSize[1]).decode("ASCII").rstrip("\0")
					sub_MATD_node = doc.createElement(MATD_string)
					MATD_node.appendChild(sub_MATD_node)
					MATD_Sub2_header = bs.read(">" + "I" * 2)
					if MATD_Sub2_header[0] == 3:
						bs.seek((4 * MATD_Sub2_header[1]), NOESEEK_REL)
		elif nodeType == "LIGH":
			LIGH_node = doc.createElement("LIGH")
			LIGH_header = bs.read(">" + "H" * 6)
			bs.seek(nodeStart + LIGH_header[2], NOESEEK_ABS)
			AGHX_node.appendChild(LIGH_node)
			LIGH_node.setAttribute("count?", str(LIGH_header[1]))
		elif nodeType == "GEOM":
			GEOM_node = doc.createElement("GEOM")
			GEOM_header = bs.read(">" + "H" * 6)
			bs.seek(nodeStart + GEOM_header[2], NOESEEK_ABS)
			AGHX_node.appendChild(GEOM_node)
			GEOM_node.setAttribute("count", str(GEOM_header[1]))
			for a in range(0, GEOM_header[1]):
				sSize = bs.read(">" + "H" * 2)
				MESH_string = bs.readBytes(sSize[1]).decode("ASCII").rstrip("\0")
				MESH_node = doc.createElement(MESH_string)
				GEOM_node.appendChild(MESH_node)
				fvf_table = []
				while True:
					nodeStart = bs.tell()
					nodeType = bs.readBytes(4).decode("ASCII").rstrip("\0")
					if nodeType == "TRLS":
						TRLS_node = doc.createElement("TRLS")
						TRLS_header = bs.read(">" + "H" * 6)
						bs.seek(nodeStart + TRLS_header[2], NOESEEK_ABS)
						MESH_node.appendChild(TRLS_node)
						TRLS_Sub_header = bs.read(">" + "I" * 2)
						TRLS_node.setAttribute("count", str(TRLS_Sub_header[1]))
						sSize = bs.read(">" + "H" * 2)
						TRLS_string = bs.readBytes(sSize[1]).decode("ASCII").rstrip("\0")
						TRLS_node.setAttribute("name", TRLS_string)
					elif nodeType == "VELM":
						VELM_node = doc.createElement("VELM")
						VELM_header = bs.read(">" + "H" * 6)
						bs.seek(nodeStart + VELM_header[2], NOESEEK_ABS)
						MESH_node.appendChild(VELM_node)
						for i in range(0, VELM_header[1]):
							VELM_Offset = bs.readInt()
							VLEM_Type = bs.readBytes(4).decode("ASCII").rstrip("\0")
							VELM_Count = bs.readInt()
							VELM_sub_node = doc.createElement(VLEM_Type)
							VELM_node.appendChild(VELM_sub_node)
							VELM_sub_node.setAttribute("offset", str(VELM_Offset))
							VELM_sub_node.setAttribute("count", str(VELM_Count))
							fvf_table.append([VLEM_Type,VELM_Offset,VELM_Count])
						vSize = fvf_table[VELM_header[1] - 1][1] + (4 * fvf_table[VELM_header[1] - 1][2])
						#print(fvf_table)
					elif nodeType == "INDX":
						INDX_node = doc.createElement("INDX")
						INDX_header = bs.read(">" + "IHHHH")
						bs.seek(nodeStart + INDX_header[1], NOESEEK_ABS)
						MESH_node.appendChild(INDX_node)
						INDX_node.setAttribute("count", str(INDX_header[0]))
						facebuff = bs.readBytes(INDX_header[0] * 2)
						tp = bs.tell()
						test = bs.readUInt()
						#print(test)
						if test != 1447383636:
							unk01 = bs.readUInt()
							sSize = bs.read(">" + "H" * 2)
							INDX_string = bs.readBytes(sSize[1]).decode("ASCII").rstrip("\0")
							INDX_sub_node = doc.createTextNode(INDX_string)
							INDX_node.appendChild(INDX_sub_node)
						else:
								bs.seek(tp, NOESEEK_ABS)						
					elif nodeType == "VERT":
						VERT_node = doc.createElement("VERT")
						VERT_header = bs.read(">" + "IHHHH")
						bs.seek(nodeStart + VERT_header[1], NOESEEK_ABS)
						MESH_node.appendChild(VERT_node)
						VERT_node.setAttribute("count", str(VERT_header[0]))
						vertbuff = bs.readBytes(VERT_header[0] * 4)
					elif nodeType == "BUND":
						BUND_node = doc.createElement("BUND")
						BUND_header = bs.read(">" + "IHHHH")
						bs.seek(nodeStart + BUND_header[1], NOESEEK_ABS)
						MESH_node.appendChild(BUND_node)
						BUND_node.setAttribute("count", str(VERT_header[0]))
						BUND_Info = bs.readInt()
						rapi.rpgSetName(MESH_string)
						for i in range(0, len(fvf_table)):
							if fvf_table[i][0] == "POSI":
								rapi.rpgBindPositionBufferOfs(vertbuff, noesis.RPGEODATA_FLOAT, vSize, fvf_table[i][1])
							elif fvf_table[i][0] == "NORM":
								rapi.rpgBindNormalBufferOfs(vertbuff, noesis.RPGEODATA_FLOAT, vSize, fvf_table[i][1])
							elif fvf_table[i][0] == "TEXC":
								rapi.rpgBindUV1BufferOfs(vertbuff, noesis.RPGEODATA_FLOAT, vSize, fvf_table[i][1])
						rapi.rpgCommitTriangles(facebuff, noesis.RPGEODATA_USHORT, INDX_header[0], noesis.RPGEO_TRIANGLE, 1)
						break

		else:
			break
	#print(doc.toprettyxml())
	#print(nodeType)
	mdl = rapi.rpgConstructModel()
	mdlList.append(mdl)
	rapi.rpgClearBufferBinds()	
	return 1