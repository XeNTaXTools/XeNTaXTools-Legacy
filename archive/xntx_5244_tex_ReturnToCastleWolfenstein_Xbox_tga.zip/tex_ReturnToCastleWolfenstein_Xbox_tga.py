from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Return to Castle Wolfenstein (Xbox)", ".tga")
	noesis.setHandlerTypeCheck(handle, RTCWCheckType)
	noesis.setHandlerLoadRGBA(handle, RTCWLoadRGBA)
	#noesis.logPopup()
	return 1

def RTCWCheckType(data):
    bs = NoeBitStream(data)
    bs.seek(len(data) - 0x12, NOESEEK_ABS)
    Magic = bs.readBytes(4).decode("ASCII")
    if Magic == "TRUE":
        return 0
    return 1   
	
def RTCWLoadRGBA(data, texList):
	datasize = len(data)
	bs = NoeBitStream(data)
	data = bs.readBytes(datasize)
	#morton order swizzled raw with alpha - Xbox
	if datasize == 21844:
		imgWidth = 64                   #set image width
		imgHeight = 64                  #set image height
		untwid = bytearray()
		for x in range(0, imgWidth):
			for y in range(0, imgHeight):
				idx = noesis.morton2D(x, y)
				untwid += data[idx*4:idx*4+4]
		data = rapi.imageDecodeRaw(untwid, imgWidth, imgHeight, "r8g8b8a8")
		texFmt = noesis.NOESISTEX_RGBA32
	texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
	return 1