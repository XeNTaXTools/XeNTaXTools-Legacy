import newGameLib
from newGameLib import *
import Blender	

def getImagePath(filename,tex):

	imagePath=None	
	imageDir=filename.lower().split('animations')[0]+'images'
	if os.path.exists(imageDir)==True:
		search=Searcher()
		search.dir=imageDir
		search.what=tex
		search.run()
		list=search.list
		if len(list)>0:
			imagePath=list[0]
			sys=Sys(imagePath)
			if sys.ext=='_ximg':
				file=open(imagePath,'rb')
				p=BinaryReader(file)
				p.seek(265)
				imagePath=imagePath.replace('._ximg','.dds')
				new=open(imagePath,'wb')
				new.write(p.read(p.fileSize()-265))
				new.close()
	return imagePath

def _xmacParser(filename,g):
	g.logOpen()
	g.word(8)
	g.seek(146)
	if g.B(1)[0]==1:
		g.endian='>'
	else:
		g.endian='<'
	g.seek(176)
	g.word(g.i(1)[0])
	g.word(g.i(1)[0])
	g.word(g.i(1)[0])
	
	############	
	#bones	
	############
	w=g.i(6)
	skeleton=Skeleton()
	skeleton.NICE=True
	skeleton.BONESPACE=True
	for i in range(w[4]):
		bone=Bone()
		bone.rotMatrix=QuatMatrix(g.f(4))
		g.f(4)
		bone.posMatrix=VectorMatrix(g.f(3))
		g.f(3)
		g.f(3)
		v=g.i(4)
		if v[2]!=-1:
			bone.parentID=v[2]
		g.B(4)
		g.f(4)
		g.f(4)
		g.f(4)
		g.f(4)
		g.f(1)
		bone.name=g.word(g.i(1)[0])[-25:]
		skeleton.boneList.append(bone)
	skeleton.draw()
	
	
	############	
	#materials
	############
	w=g.i(6)
	matList=[]
	for m in range(w[3]):#material list
		mat=Mat()
		mat.TRIANGLE=True
		g.i(3)
		g.f(20)
		chunk=g.i(1)[0]	
		if chunk==4587520:
			g.word(g.i(1)[0])
		elif chunk==21364736:	
			g.word(g.i(1)[0])
			g.f(6)
			g.H(2)	
			tex=g.word(g.i(1)[0]).lower()
			mat.diffuse=getImagePath(filename,tex)
					
		elif chunk==38141952:	
			g.word(g.i(1)[0])
			g.f(6)
			g.H(2)	
			tex=g.word(g.i(1)[0]).lower()
			mat.diffuse=getImagePath(filename,tex)
			g.f(6)
			g.H(2)	
			tex=g.word(g.i(1)[0]).lower()
			mat.normal=getImagePath(filename,tex)
					
		elif chunk==17922:	
			g.word(g.i(1)[0])
			g.f(6)
			g.H(2)	
			tex=g.word(g.i(1)[0]).lower()
			mat.diffuse=getImagePath(filename,tex)
			g.f(6)
			g.H(2)	
			tex=g.word(g.i(1)[0]).lower()
			mat.normal=getImagePath(filename,tex)
		elif chunk==54919168:	
			g.word(g.i(1)[0])
			g.f(6)
			g.H(2)	
			tex=g.word(g.i(1)[0]).lower()
			mat.diffuse=getImagePath(filename,tex)
			g.f(6)
			g.H(2)	
			tex=g.word(g.i(1)[0]).lower()
			mat.normal=getImagePath(filename,tex)
			g.f(6)
			g.H(2)	
			tex=g.word(g.i(1)[0]).lower()
			mat.specular=getImagePath(filename,tex)
		elif chunk==17923:	
			g.word(g.i(1)[0])
			g.f(6)
			g.H(2)	
			tex=g.word(g.i(1)[0]).lower()
			mat.diffuse=getImagePath(filename,tex)
			g.f(6)
			g.H(2)	
			tex=g.word(g.i(1)[0]).lower()
			mat.normal=getImagePath(filename,tex)
			g.f(6)
			g.H(2)	
			tex=g.word(g.i(1)[0]).lower()
			mat.specular=getImagePath(filename,tex)
		else:
			print 'WARNING:',chunk
		matList.append(mat)	
	g.logClose()	
	
	
	############	
	#meshes
	############
	for j in range(2):#lod list L1,L2 - delete break if want all lods
		w=g.i(10)
		count=w[4]
		vertPosList=[]
		vertUVList=[]
		skinIDList=[]
		for i in range(w[8]):
			section=g.i(3)	
			for m in range(w[5]):
				ts=g.tell()
				
				if section[0]==0:vertPosList.append(g.f(3))
				if section[0]==3:vertUVList.append(g.f(2))
				if section[0]==5:skinIDList.append(g.i(1)[0])
				if section[0]==2:g.f(4)
				
				g.seek(ts+section[1])
				
		vertIDStart=0
		meshList=[]
		subMeshInfoList=[]
		subMeshCount=w[7]
		for i in range(subMeshCount):
			mesh=Mesh()
			mesh.TRIANGLE=True	
			mesh.BINDSKELETON=skeleton.name	
			v=g.i(4)
			mesh.matList.append(matList[v[2]])
			subMeshInfoList.append(v)
			mesh.indiceList=list(g.i(v[0]))
			mesh.vertPosList=vertPosList[vertIDStart:vertIDStart+v[1]]
			mesh.vertUVList=vertUVList[vertIDStart:vertIDStart+v[1]]
			boneMap=g.i(v[3])
			skin=Skin()
			vertIDStart+=v[1]
			skin.boneMap=skeleton.boneNameList
			mesh.skinList.append(skin)
			meshList.append(mesh)
			
		w=g.i(7)
		listA=[]
		for i in range(w[5]):listA.append([g.f(1)[0],g.B(4)])
		listB=[]#skin list	
		ID=0
		for i in range(count):
			v=g.i(2)
			indiceList=[]
			weightList=[]
			for m in range(v[1]):
				indiceList.append(listA[ID][1][0])
				weightList.append(listA[ID][0])
				ID+=1
			listB.append([indiceList,weightList])
		
		vertIDStart=0
		for i in range(subMeshCount):
			mesh=meshList[i]
			for m in range(vertIDStart,vertIDStart+subMeshInfoList[i][1]):
				mesh.skinIndiceList.append(listB[skinIDList[m]][0])
				mesh.skinWeightList.append(listB[skinIDList[m]][1])
			vertIDStart+=subMeshInfoList[i][1]
			mesh.draw()
			
		
		
		break	

def _xmotParser(filename,g):

	action=Action()
	action.BONESPACE=True
	action.BONESORT=True
	
	try:
		g.find('Bone_ROOT')
		g.seek(-145,1)
		while(True):
			if g.tell()>=g.fileSize():break
			for i in range(4):
				g.f(4)
			for i in range(2):
				g.f(3)
				g.f(3)
				
			countList=g.i(4)
			time=g.f(1)	
			
			bone=ActionBone()
			bone.name=g.word(g.i(1)[0])
			for i in range(countList[0]):
				bone.posKeyList.append(VectorMatrix(g.f(3)))
				bone.posFrameList.append(int(g.f(1)[0]*30))
			for i in range(countList[1]):
				bone.rotKeyList.append(QuatMatrix(g.f(4)).resize4x4())
				bone.rotFrameList.append(int(g.f(1)[0]*30))
			for i in range(countList[3]):g.f(5)
			for i in range(countList[2]):g.f(4)
			action.boneList.append(bone)
		action.draw()
		action.setContext()	
	except:
		pass
		
	
def Parser(filename):	
	print filename
	ext=filename.split('.')[-1].lower()	
	
	if ext=='_xmac':
		file=open(filename,'rb')
		g=BinaryReader(file)
		_xmacParser(filename,g)
		file.close()
	
	if ext=='_xmot':
		file=open(filename,'rb')
		g=BinaryReader(file)
		_xmotParser(filename,g)
		file.close()
 
 
	
Blender.Window.FileSelector(Parser,'import','select: _xmac,_xmot') 
	