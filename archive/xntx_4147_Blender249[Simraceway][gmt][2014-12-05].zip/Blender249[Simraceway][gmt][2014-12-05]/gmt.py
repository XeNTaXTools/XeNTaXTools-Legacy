import newGameLib
reload(newGameLib)
from newGameLib import *
import Blender

def masParser(filename,g):
	g.logOpen()
	g.debug=True
	g.seek(16)
	unk,files,baseoff=g.i(3)
	for m in range(files):
		g.i(1)
		fileName=g.word(236)
		off,size,zsize,unk=g.i(4)
		t=g.tell()
		g.seek(g.fileSize()-baseoff+off)
		sys=Sys(filename)
		sys.addDir(sys.base)
		filePath=sys.dir+os.sep+sys.base+os.sep+fileName
		new=open(filePath,'wb')
		data=zlib.decompress(g.read(size))
		new.write(data)
		new.close()
		
		g.seek(t)
	g.tell()
	g.logClose()
	
	
def gmtParser(filename,g):

	matOffset=g.i(1)[0]
	g.seek(matOffset+4)
	matCount=g.i(1)[0]
	matList=[]
	print 'material count:',matCount
	for i in range(matCount):
		mat=Mat()
		g.word(64)
		g.f(20)
		for m in range(3):
			g.i(2)
			g.word(256)
		g.i(8)	
		texCount=g.i(1)[0]
		for m in range(texCount):
			t=g.tell()
			name=g.find('\x00')
			g.seek(t+64)
			#print name
			if m==0:mat.diffuse=g.dirname+os.sep+name
			flag=g.i(7)
			if flag[2]==2:g.seek(t+192)
			elif flag[2]==1:g.seek(t+172)
			else:print 'WARNING:flag:',flag
		matList.append(mat)	
		
	g.seek(296)
	matrix=VectorMatrix(g.f(3))	
	g.seek(368)
	A=g.i(9)
	g.word(64)	
	g.seek(A[4])
	
	g.seek(A[2])
	for m in range(A[1]):
		B=g.i(33)
		print B
		pos=g.tell()
		mesh=Mesh()
		mesh.TRIANGLE=True
		g.seek(B[2]+4)
		for n in range(B[7]):
			mesh.vertPosList.append(g.f(3))
			g.f(3)
			g.i(2)		
		g.seek(B[4]+4)
		for n in range(B[7]):
			mesh.vertUVList.append(g.f(2))
			g.f(6)		
		g.seek(B[10]+4)
		mesh.indiceList=g.H(B[9])
		g.seek(pos)
		mat=matList[B[15]]
		mat.TRIANGLE=True
		mesh.matList.append(mat)
		mesh.matrix=matrix
		mesh.draw()
	
		
	
def Parser():	
	filename=input.filename
	imageList=input.imageList
	ext=filename.split('.')[-1].lower()	
	
	if ext=='mas':
		file=open(filename,'rb')
		g=BinaryReader(file)
		masParser(filename,g)
		file.close()
	
	if ext=='gmt':
		file=open(filename,'rb')
		g=BinaryReader(file)
		gmtParser(filename,g)
		file.close()
 
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
	
Blender.Window.FileSelector(openFile,'import','gmt - model')