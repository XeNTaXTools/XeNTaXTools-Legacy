import numpy

#Datatypes
BOOL_DTYPE = '?'
SCHAR_DTYPE = 'b'
UCHAR_DTYPE = 'B'
SSHORT_DTYPE = 'h'
USHORT_DTYPE = 'H'
SINT_DTYPE  = 'i'
UINT_DTYPE = 'I'
SLONGINT_DTYPE = 'q'
ULONGINT_DTYPE = 'Q'
FLOAT_DTYPE = 'f'
DOUBLE_DTYPE = 'd'

def GetMinimum(datatype):
    if BOOL_DTYPE in datatype:
        return 0
    return __GetTypeInfo(datatype).min

def GetMaximum(datatype):
    if BOOL_DTYPE in datatype:
        return 1
    return __GetTypeInfo(datatype).max

def GetNumberBytes(datatype):
    return __GetDataCast(datatype).itemsize

def GetNumberBits(datatype):
    return GetNumberBytes(datatype) * 8

def __IsFloatDatatype(datatype):
    return FLOAT_DTYPE in datatype or \
           DOUBLE_DTYPE in datatype

def __GetTypeInfo(datatype):
    datacast = __GetDataCast(datatype)
    if __IsFloatDatatype(datatype):
        return numpy.finfo(datacast.type)
    else:
        return numpy.iinfo(datacast.type)

def __GetDataCast(datatype):
    return numpy.dtype(datatype)

#Bool
BOOL_DTYPE_BIG = '!' + BOOL_DTYPE
BOOL_BYTES = GetNumberBytes(BOOL_DTYPE)
BOOL_BITS = GetNumberBits(BOOL_DTYPE)
BOOL_MIN = GetMinimum(BOOL_DTYPE)
BOOL_MAX = GetMaximum(BOOL_DTYPE)

#Char
SCHAR_DTYPE_BIG = '!' + SCHAR_DTYPE
SCHAR_BYTES = GetNumberBytes(SCHAR_DTYPE)
SCHAR_BITS = GetNumberBits(SCHAR_DTYPE)
SCHAR_MIN = GetMinimum(SCHAR_DTYPE)
SCHAR_MAX = GetMaximum(SCHAR_DTYPE)

UCHAR_DTYPE_BIG = '!' + UCHAR_DTYPE
UCHAR_BYTES = GetNumberBytes(UCHAR_DTYPE)
UCHAR_BITS = GetNumberBits(UCHAR_DTYPE)
UCHAR_MIN = GetMinimum(UCHAR_DTYPE)
UCHAR_MAX = GetMaximum(UCHAR_DTYPE)

#Short
SSHORT_DTYPE_BIG = '!' + SSHORT_DTYPE
SSHORT_BYTES = GetNumberBytes(SSHORT_DTYPE)
SSHORT_BITS  = GetNumberBits(SSHORT_DTYPE)
SSHORT_MIN   = GetMinimum(SSHORT_DTYPE)
SSHORT_MAX   = GetMaximum(SSHORT_DTYPE)

USHORT_DTYPE_BIG = '!' + USHORT_DTYPE
USHORT_BYTES = GetNumberBytes(USHORT_DTYPE)
USHORT_BITS  = GetNumberBits(USHORT_DTYPE)
USHORT_MIN   = GetMinimum(USHORT_DTYPE)
USHORT_MAX   = GetMaximum(USHORT_DTYPE)

#Integer
SINT_DTYPE_BIG = '!' + SINT_DTYPE
SINT_BYTES  = GetNumberBytes(SINT_DTYPE)
SINT_BITS   = GetNumberBits(SINT_DTYPE)
SINT_MIN    = GetMinimum(SINT_DTYPE)
SINT_MAX    = GetMaximum(SINT_DTYPE)

UINT_DTYPE_BIG = '!' + UINT_DTYPE
UINT_BYTES = GetNumberBytes(UINT_DTYPE)
UINT_BITS  = GetNumberBits(UINT_DTYPE)
UINT_MIN   = GetMinimum(UINT_DTYPE)
UINT_MAX   = GetMaximum(UINT_DTYPE)

#Double Integer
SLONGINT_DTYPE_BIG = '!' + SLONGINT_DTYPE
SLONGINT_BYTES  = GetNumberBytes(SLONGINT_DTYPE)
SLONGINT_BITS   = GetNumberBits(SLONGINT_DTYPE)
SLONGINT_MIN    = GetMinimum(SLONGINT_DTYPE)
SLONGINT_MAX    = GetMaximum(SLONGINT_DTYPE)

ULONGINT_DTYPE_BIG = '!' + ULONGINT_DTYPE
ULONGINT_BYTES = GetNumberBytes(ULONGINT_DTYPE)
ULONGINT_BITS  = GetNumberBits(ULONGINT_DTYPE)
ULONGINT_MIN   = GetMinimum(ULONGINT_DTYPE)
ULONGINT_MAX   = GetMaximum(ULONGINT_DTYPE)

#Float
FLOAT_DTYPE_BIG = '!' + FLOAT_DTYPE
FLOAT_BYTES = GetNumberBytes(FLOAT_DTYPE)
FLOAT_BITS  = GetNumberBits(FLOAT_DTYPE)
FLOAT_MIN   = GetMinimum(FLOAT_DTYPE)
FLOAT_MAX   = GetMaximum(FLOAT_DTYPE)

#Double
DOUBLE_DTYPE_BIG = '!' + DOUBLE_DTYPE
DOUBLE_BYTES = GetNumberBytes(DOUBLE_DTYPE)
DOUBLE_BITS  = GetNumberBits(DOUBLE_DTYPE)
DOUBLE_MIN   = GetMinimum(DOUBLE_DTYPE)
DOUBLE_MAX   = GetMaximum(DOUBLE_DTYPE)
