import locale
locale.setlocale(locale.LC_ALL, '')

import time


class Super:
    def __init__(self, *args, **kwargs):
        self.instanceTime = time.time()        
        self.iterationList = []
        self.index = 0
        self.wzID = '0'

    def SetID(self, wzID):
        self.wzID = str(int(wzID))

    def GetID(self):
        return self.wzID

    @classmethod
    def Define(cls, wzID, *args, **kwargs):
        obj = cls(*args, **kwargs)
        obj.SetID(wzID)
        return obj

    @classmethod
    def Blank(cls, *args, **kwargs):
        obj = cls(*args, **kwargs)
        return obj

    def __iter__(self):
        return self

    def __contains__(self, item):
        return item in self.iterationList

    def __equals__(self, otherObj):
        return otherObj.iterationList == self.iterationList

    def __len__(self):
        return len(self.iterationList)

    def next(self):
        if self.index < len(self.iterationList):
            indexValue = self.iterationList[self.index]
            self.index += 1
            return indexValue
        else:
            self.index = 0
            raise StopIteration 
