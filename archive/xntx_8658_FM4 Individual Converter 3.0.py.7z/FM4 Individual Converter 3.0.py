import os, re

class Variables:
    VertsPerFace = BytesPerFaceVert = FacePadding = FacesInMesh = VertCount = VertsOffset = vert = 0
    meshes = [] # Must initialize lists separately or they'll all share the same data.
    UVs = []
    verts = []
          
def Find_Verts_Offset(stretch, SearchStartOffset):
    match = re.search(b'............\x00\x00\x80\?', file.read(stretch)) # The vert block starts with at least two lines ending in 00 00 80 3F
    if match.end() % 16 == 0: # Ensure the match resides on a single line. 
        file.seek(SearchStartOffset + match.end(), 0) 
        if re.search(b'............\x00\x00\x80\?', file.read(16)) != None: # Check if the next line also ends with 00 00 80 3F
            var.VertsOffset = SearchStartOffset + match.start()
            # return SearchStartOffset + match.start() This line doesn't work properly due to the quirks of recursion.   
        else: Find_Verts_Offset(FileSize - file.tell(), file.tell()) # Recursively search again, starting from the end of the line read in above. 
    else: 
        file.seek((SearchStartOffset + match.end()) - match.end() % 16, 0) # Seek backwards to restart the search properly, some lines may actually contain 00 00 80 3F twice. 
        Find_Verts_Offset(FileSize - file.tell(), file.tell()) # Recursively search again, starting from the beginning of the line contained within the false positive.           

def Read_Header():
    if headers.group()[1] == 10: 
        var.VertsPerFace = 3
        var.BytesPerFaceVert = 2
        var.FacePadding = 6

    elif headers.group()[1] == 11: 
        var.VertsPerFace = 4
        var.BytesPerFaceVert = 2
        var.FacePadding = 8               

    elif headers.group()[1] == 12: 
        var.VertsPerFace = 3
        var.BytesPerFaceVert = 1
        var.FacePadding = 5
        
    else: # 13 
        var.VertsPerFace = 4
        var.BytesPerFaceVert = 1
        var.FacePadding = 4    

    var.FacesInMesh = headers.group()[2]
    file.seek(CurrentFileOffset + headers.end(), 0)  

def Read_Faces():
    face = []

    for x in range(var.VertsPerFace):
        face.append(int.from_bytes(file.read(var.BytesPerFaceVert), 'little'))
        if face[x] >= var.VertCount: var.VertCount = face[x] + 1 # Get the number of verts used by the model while reading faces. 
    var.meshes[len(var.meshes) - 1].append(face)
    file.seek(var.FacePadding, 1)

def Read_UVs():
    for x in range(var.VertsPerFace):
        UVCoords = []
        UVCoords.append(int.from_bytes(file.read(2), 'little', signed = 'True') / 4096)
        UVCoords.append(1 - (int.from_bytes(file.read(2), 'little', signed = 'True') / 4096))
        var.UVs [len(var.UVs) - 1].append(UVCoords)    

def Read_Verts():
    file.seek(var.VertsOffset + 1600, 0) # Jump 100 lines down and check if floats are still present. 

    if re.search(b'\x00\x00\x80\?', file.read(16)) != None: # If so, they're actually verts. 
        CoordBytes = CoordPadding = 4
        file.seek(var.VertsOffset, 0)
       
    else:
        CoordBytes = CoordPadding = 2
        file.seek(var.VertsOffset + 32, 0) # Jump past the first two 00 00 80 3f lines.
        SearchStartOffset = file.tell()
        match = re.search(b'......\x00\x10......\x00\x10', file.read(FileSize - SearchStartOffset))
        file.seek(SearchStartOffset + match.start(), 0) # Find and jump to the start of the signed shorts, they're the verts.

    for x in range(var.VertCount):
        coords = []
        for y in range(3): coords.append(int.from_bytes(file.read(CoordBytes), 'little', signed = 'True') / 818.8) # Divide by 818.8 to get canonical scale. 
        var.verts.append(coords)
        file.seek(CoordPadding, 1)

    if CoordBytes == 4: # Skip past the rest of the floats in preparation for a pontential second component.  
        SearchStartOffset = file.tell()
        match = re.search(b'......\x00\x10......\x00\x10', file.read(FileSize - SearchStartOffset))
        file.seek(SearchStartOffset + match.start(), 0)

def Write_Verts():
    for x in range(len(var.meshes[0])):
        for y in range(len(var.meshes[0][0])):
            obj.write('v ')
            for z in range(3): obj.write(str(var.verts[var.meshes[0][x][y]][z]) + ' ')
            obj.write('\n')

def Write_UVs():
    for x in range(len(var.UVs[0])):
        obj.write('vt ')
        for y in range(2): obj.write(str(var.UVs[0][x][y]) + ' ')
        obj.write('\n')

def Write_Faces():
    for x in range(len(var.meshes[0])): 
        obj.write('f ')
        for y in range(3): # Create a triangle.
            var.vert += 1
            obj.write(str(var.vert) + '/' + str(var.vert) + ' ')
        obj.write('\n')           

        if len(var.meshes[0][0]) == 4: # Create its complement if neccessary. The approach below ensures the faces don't need to be flipped once imported into a modeling program.  
            obj.write('f ')
            var.vert += 1
            for z in range(3):
                obj.write(str(var.vert) + '/' + str(var.vert) + ' ')
                var.vert -= 1   
            var.vert += 3
            obj.write('\n')

path = 
name = 
var = Variables()

with open(path + name,'rb') as file:
    with open(path + name + '.obj' , 'w') as obj:
        FileSize = os.path.getsize(path + name)
        components = 1
        MeshCount = 0 
        for x in range(components): # Certain files break models into sequential chunks. 
            CurrentFileOffset = file.tell()
            Find_Verts_Offset(FileSize - CurrentFileOffset, CurrentFileOffset) # Isolate the stretch of data containing the faces by first finding the offset of the verts.
            file.seek(CurrentFileOffset, 0) # Jump back to the start offset of the search after finding the vert block.
            for headers in re.finditer(b'[\x00-\x09][\x0c\r][\x01-\xff][\x00-\x09][\x00-\x09]\x00[\x00-\x09]\x00|[\x00-\x20b]\x00[\n\x0b][\x01-\xff][\x00-\x09][\x00-\x1c]\x00[\x00-\x1c]\x00', file.read(var.VertsOffset)): # Jump to every mesh header in the stretch.  -\x20b'[\x00][\n\x0b\x0c\r][\x01-\xff][\x00-\x09][\x00-\x1c]\x00[\x00-\x1c]\x00
                Read_Header()           
                var.meshes.append([])
                var.UVs.append([])
                for y in range(var.FacesInMesh):
                    Read_Faces()
                    Read_UVs()
            Read_Verts()
            while len(var.meshes) > 0:
                MeshCount += 1
                obj.write('object Mesh ' + str(MeshCount) + '\n')
                Write_Verts()
                Write_UVs()
                Write_Faces()
                var.meshes.pop(0)
                var.UVs.pop(0)
            var.verts.clear() # Must manually reset these var variables, reinitializing the class within the components loop didn't work.
            var.VertCount = 0 
