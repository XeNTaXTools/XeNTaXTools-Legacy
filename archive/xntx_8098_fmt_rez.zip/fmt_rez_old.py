#by Durik256 for xentax.com
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Winter X-Games: Snocross", ".rez")
    noesis.setHandlerExtractArc(handle, spExtractArc)
    return 1

def spExtractArc(fileName, fileLen, justChecking):
    if fileLen < 16:
        return 0
        
    if justChecking: #it's valid
            return 1

    f = open(fileName, "rb")
    data = NoeFileStream(f)

    count = data.readUInt()
    data.seek(12)
    
    for i in range(count):
        name = str(i)+'.'+noeAsciiFromBytes(data.readBytes(4))[:-1]
        size = data.readUInt()

        export_data = data.readBytes(size)
        rapi.exportArchiveFile(name, export_data)
        print("export", name)

    print("Extracting", count, "files.")
    return 1