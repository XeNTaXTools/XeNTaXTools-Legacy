﻿import os
import urllib.request
import struct
import numpy

manifest = None
lastFileSize = 0

def readManifest(version): 
	"""Reads the manifest file for the specified version."""
	readFile = open(str(version), "rb")

	readFileSize = os.stat(str(version)).st_size
	
	data = numpy.fromfile(readFile, dtype="<L")

	print("Processed manifest.")
	
	return data

def downloadFiles():
	"""Downloads the files from the manifest in order. No resume."""
	print("Downloading files from manifest")
	filePath = "/program/102/0/0/"
	global manifest
	global lastFileSize
	data = None
	headers = { "Cookie" : "authCookie=access=/latest/*!/manifest/program/*!/program/*~md5=4e51ad868f87201ad93e428ff30c6691" }
	
	for fileNum in manifest:
		url = "http://assetcdn.102.arenanetworks.com"+filePath+str(fileNum)+"/"
		if fileNum != lastFileSize:
			request = urllib.request.Request(url,data,headers)
			try:
				res = urllib.request.urlopen(request)
				procFile = processFile(res)
				if not os.path.exists(procFile[0]):
					os.mkdir(procFile[0])
				file = open(procFile[0]+"/"+str(fileNum)+"."+procFile[1], "wb")
				file.write(procFile[2])
				file.close();
				lastFileSize = os.stat(procFile[0]+"/"+str(fileNum)+"."+procFile[1]).st_size
			except urllib.error.HTTPError as err:
				print(err.code)
				print(err.read())
			

def downloadManifest(version):
	"""Downloads the manifest file for the specified version."""
	print("Downloading manifest for build "+str(version))
	manifestPath = "/manifest/program/102/"
	url = "http://assetcdn.102.arenanetworks.com"+manifestPath+str(version)
	print(url);
	data = None
	headers = { "Cookie" : "authCookie=access=/latest/*!/manifest/program/*!/program/*~md5=4e51ad868f87201ad93e428ff30c6691" }
	
	request = urllib.request.Request(url,data,headers)	
	
	try:
		res = urllib.request.urlopen(request)
		file = open(str(version), "wb")
		file.write(res.read())
	except urllib.error.HTTPError as err:
		print(err.code)
		print(err.read())

def processFile(res):
	"""Reads and categorizes the files to make reading easier."""
	format = "unknown"
	extension = "UNK"
	
	data2 = res.read(250);
	data = str(data2)
	if "ASND" in data:
		format = "sound"
		if "LAME" in data:
			extension = "MP3"
		else:
			extension = "SND"
			
	elif "asnd" in data:
		format = "sound"
		if "LAME" in data:
			extension = "MP3"
		else:
			extension = "SND"
	
	elif "ATE" in data:
		format = "texture"
		if "DXT1" in data:
			extension = "DXT1.DDS"
		elif "DXT2" in data:
			extension = "DXT2.DDS"
		elif "DXT3" in data:
			extension = "DXT3.DDS"
		elif "DXT4" in data:
			extension = "DXT4.DDS"
		elif "DXT5" in data:
			extension = "DXT5.DDS"
		else:
			extension = "UNKNOWN.DDS" #For Unknown DXT files. like ATEX3DCX
	
	elif "dx9s" in data:
		format = "surface"
		extension = "DX9S"
		
	elif "AMAT" in data:
		format = "material"
		extension = "GRMT"
	
	elif "ABNK" in data:
		format = "unmapped"
		extension = "BNKBKCK"
	
	elif "abff" in data:
		format = "sound"
		extension = "AIF"
	
	elif "vorbis" in data:
		format = "sound"
		extension = "ogg"
	
	elif "strs" in data:
		format = "text"
		extension = "TXT"
	
	elif "ARMFMFST" in data:
		format = "manifest"
		extension = "MFST"
	
	elif "AMSP" in data:
		format = "unmapped"
		extension = "AMP"
	
	elif "CINPC" in data:
		format = "unmapped"
		extension = "CINPC"
		
	elif "hvkChav" in data:
		format = "unmapped"
		extension = "HVKCHAV"
		
	elif "PIMGPG" in data :
		format = "unmapped"
		extension = "PIMGPG"
	
	elif "MODL" in data:
		format = "model"
		extension = "MODL"
		if "MODLANIM" in data:
			extension = "ANIM"
		
	elif "DDS" in data:
		format = "texture"
		extension = "DDS"
	
	elif "===" in data:
		format = "text"
		extension = "TXT"
	
	elif "***" in data:
		format = "text"
		extension = "TXT"
	elif "mapcparm" in data:
		format = "unmapped"
		extension = "MAPCPARM"
	
	data2 += res.read();
	
	if format == "unknown":
		data3 = str(data2[-250:-1])
		if "LAME" in data3:
			format = "sound"
			extension = "MP3"
	
	return [format,extension,data2]

def main():
	"""Downloads manifest and all files in the manifest uncompressed."""
	version = 13782
	downloadManifest(version)
	global manifest
	manifest = readManifest(version)
	downloadFiles()

if __name__=="__main__":
	main()