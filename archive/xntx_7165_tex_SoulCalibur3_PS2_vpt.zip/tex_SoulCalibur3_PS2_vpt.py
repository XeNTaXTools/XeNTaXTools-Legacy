from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Soul Calibur III [PS2]", ".vpt")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup(); print("The logPopup command is still on in tex_SoulCalibur3_PS2_vpt.py")
    return 1

def noepyCheckType(data):
    return 1

def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.seek(0x18c)
    imgWidth = bs.readUShort()
    imgHeight = bs.readUShort()
    print(imgWidth, "x", imgHeight)
    bs.seek(0x200)
    palette = bs.readBytes(0x400)
    data = bs.readBytes(imgWidth * imgHeight)
    #data = unswizzle8(data, imgWidth, imgHeight)
    data = rapi.imageUntwiddlePS2(data, imgWidth, imgHeight, 8)
    data = rapi.imageDecodeRawPal(data, palette, imgWidth, imgHeight, 8, "r8 g8 b8 p8", noesis.DECODEFLAG_PS2SHIFT)
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, noesis.NOESISTEX_RGBA32))
    return 1
    
def unswizzle8(buf, width, height):
    swizzled = bytearray(width * height)
    swizzled[0 : (width * height)] = buf[0 : (width * height)]
    out = bytearray(width * height)
    for y in range(height):
        for x in range(width):
            block_location = (y & (~0xf)) * width + (x & (~0xf)) * 2
            swap_selector = (((y + 2) >> 2) & 0x1) * 4
            posY = (((y & (~3)) >> 1) + (y & 1)) & 0x7
            column_location = posY * width * 2 + ((x + swap_selector) & 0x7) * 4
            byte_num = ((y >> 1) & 1) + ((x >> 2) & 2) # 0,1,2,3
            out[(y * width) + x] = swizzled[block_location + column_location + byte_num]
    return out