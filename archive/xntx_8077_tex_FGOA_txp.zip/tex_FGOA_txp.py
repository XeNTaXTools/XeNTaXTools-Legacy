from ast import For
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Fate/Grand Order Arcade Textures", ".txp")
    noesis.setHandlerTypeCheck(handle, texCheckType)
    noesis.setHandlerLoadRGBA(handle, texLoadTexSet)
    noesis.logPopup()
    return 1


def texCheckType(data):
    bs = NoeBitStream(data)
    fileMagic = bs.readUInt()
    if fileMagic == 0x04505854:
        return 1
    else:
        return 1

def getTextureFormat(format):
    if format == 98:
        return "a8"
    elif format == 99:
        return "r8g8b8"
    elif format == 100:
        return "r8g8b8a8"
    elif format == 101:
        return "r5g5b5"
    elif format == 102:
        return "r5g5b5a1"
    # elif format == 103:
    #     return "r4g4b4a4"
    elif format == 103:
        return noesis.FOURCC_DXT1
    elif format == 104:
        return noesis.FOURCC_DXT1
    elif format == 105:
        return noesis.FOURCC_DXT1
    elif format == 107:
        return noesis.FOURCC_DXT3
    elif format == 109:
        return noesis.FOURCC_DXT5
    elif format == 110:
        return noesis.FOURCC_DXT5
    elif format == 112:
        return noesis.FOURCC_ATI1
    elif format == 115:
        return noesis.FOURCC_ATI2
    elif format == 130:
        return noesis.FOURCC_BC7
    elif format == 131:
        return noesis.FOURCC_BC7



def texLoadTexSet(data, texList):
    bs = NoeBitStream(data)
    magic = bs.readUInt()
    mipCount = bs.readUInt()
    mipCount2 = bs.readByte()
    mipslice = bs.readByte()
    bs.seek(2,1)
    offsets = []
    for _ in range(mipCount):
        offsets.append(bs.readUInt())
    slices = []
    for B in range(0, mipslice):
        # print((B*mipCount2))
        slices.append(offsets[(B*mipCount2)])
    bs.seek(slices[0])
    if mipslice > 1:
        texList.append(texLoadARGB(bs, slices, 1))
    else:
        texList.append(texLoadARGB(bs, slices, 0))
    return 1
def texLoadARGB(bs, loc, C):
    pix = bytearray()
    for E in range(0, len(loc)):
        bs.seek(loc[E])
        magic = bs.readUInt()
        width = max(bs.readUInt(),4)
        height = max(bs.readUInt(),4)
        formatInt = bs.readUInt()
        Format = getTextureFormat(formatInt)
        print(formatInt)
        id = bs.readUInt()
        length = bs.readUInt()
        ugh = bs.readBytes(length)
        if formatInt < 103:
            pix+=rapi.imageDecodeRaw(ugh,width,height,Format)
        else:
            pix+=rapi.imageDecodeDXT(ugh,width,height,Format)
    if C:
        U = NoeTexture(rapi.getInputName(), width, height, pix, noesis.NOESISTEX_RGBA32)
        U.setFlags(noesis.NTEXFLAG_CUBEMAP)
        U.setMipCount(1)
        return U
    else:
        return NoeTexture(rapi.getInputName(), width, height, pix, noesis.NOESISTEX_RGBA32)