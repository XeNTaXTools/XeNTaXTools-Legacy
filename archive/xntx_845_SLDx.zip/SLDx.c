/* Outbreak SLD decompressor
 * Original source by Alera
 * translated to C by James
 * 
 * For Alera's C++ source PM or Email me @ stoopiehead@hotmail.com
 * Also Accessible through contact of Alera.
 * Any questions, contact me.
 * 
 * Coded for Decompression of Outbreaks SLDs
 * Odd Decompression, Improper flag of ITs as of yet.
 * I took it upon myself to edit Alera's method, no offense;
 * It was simply beyond my level, and seemed to use a lot of C++ features.
 * Syntax Errors in Output Remain
 *                                                          -James
 */
#include <stdio.h>
#include <stdlib.h>

//def unsigned types
typedef unsigned int uint;
typedef unsigned short ushrt;

/*get shorts from chars
ushrt GETSHRT(char *ptr) {
	return((ushrt)((ptr[1]<<8)|(ptr[0])));
}
*/

//get filesize
uint filesize(FILE *fil) {
	int size;
	
	fseek(fil, 0, SEEK_END);
	size = ftell(fil);
	fseek(fil, 0, SEEK_SET);
	return(size);
}

//variable ptr used instead of IT
//Reason is ptr is not necessarily an IT
//it's being validated
char Validate(char *ptr) {
	char cushion = 0;
	char valid = 1;
	char input_size = -1;
	char output_size = -1;
	
	cushion = ptr[0]&0x10;  //00010000 Cushion Flag
	input_size = ptr[0]&0x0F; //Input buffer size 00001111
	output_size = (ptr[1]&0x7c)>>2; //01111100 Output Buffer size
	input_size *= 2; //always in pairs, counted by byte
	//output isn't in pairs
	
	//Validate to see if it works
	if ((ptr[0]&0xE0) != 0) valid = 0;  //if there's data on the cushion marker
    if((ptr[1] & 0x83) != 0) valid = 0;   //if there's extra data on output
    if(output_size % 2) valid = 0; //output_size must be a multiple of 2
    if(input_size == 0) valid = 0;  //if no input
    if(output_size == 0) valid = 0; //if no output
    return(valid);
}

/*
 * returns offset because I had plans for a more complicated function
 * It still leaves room for open ended edits too
 */
uint decompress(char *buffer, uint offset, FILE *fo) {
	char *IT = buffer + offset;  //IT
	//get IT values
	int cushion = IT[0]&0x10;  //00010000 Cushion Flag
	int input_size = IT[0]&0x0F; //Input buffer size 00001111
	int output_size = (IT[1]&0x7c)>>2; //01111100 Output Buffer size
	//input_size *= 2; //counted by bytes, always in pairs
	
	//output
	int i;  //for loop
	char *output;
	if (!(cushion)) {  //if it's not a cushion
		output = buffer+(offset-input_size);   //output gets the value
		for (i=0; i<output_size; i+=input_size) {  //for loop for the repetition
			fwrite(output, 1, input_size, fo);  //write to file
		}
	} else {
		for (i=0; i<output_size; i++, output++) { //balance out offset
			fwrite(&"\00", 1, 1, fo);  //write null
		}
	}
	return(offset);
}

int main(int argc, char *argv[]) {
	printf("\n=================================\nResident Evil Outbreak\nSLD Decompressor\nvBETA\nCoded by James\nOrginal Source by Alera\n=================================\n---------------------------------\n\n");
	
	//names and inputs
	char *sld_file, tm2_file[512];  //characters are max 512
	if (argc<2) {
		printf("Usage: %s [sld file] {outfile}\nif no outfile given, output is [sld file].tm2\n", argv[0]);
		return(-1);
	} else {
		sld_file = argv[1];  //inputfile
		if (argc>2) {
			snprintf(tm2_file, sizeof(tm2_file), "%s", argv[2]);
		} else {
			snprintf(tm2_file, sizeof(tm2_file), "%s.tm2", sld_file);
		}
	}
	
	//Try and open sld
	FILE *sld_open;
	printf("Opening: %s\n", sld_file);
	if (!(sld_open = fopen(sld_file, "rb"))) {
		printf("Error Opening %s\n", sld_file);
		return(-1);
	}
	
	//get file size
	uint size;
	if (!(size = filesize(sld_open))) {
		printf("Error Getting Filesize of %s\n", sld_file);
		return(-1);
	}
	
	//allocate memory
	char *buffer;
	if (!(buffer = malloc(size))) {
		printf("Not Enough Memory!\n");
		return(-1);
	}
	
	//read from file
	printf("Reading: %s\n", sld_file);
	if (!(fread(buffer, 1, size, sld_open))) {
		printf("Error Reading %s\n", sld_file);
		return(-1);
	}
	fclose(sld_open); //close file
	
	//open output
	FILE *tm2_open;
	printf("\nOpening: %s\n", tm2_file);
	if (!(tm2_open = fopen(tm2_file, "wb"))) {
		printf("Error Opening %s\n", tm2_file);
		return(-1);
	}
	
	//write uncompressed "TIM2" header
	printf("Writing: %s\n", tm2_file);
	if (!(fwrite(buffer+2, 1, 4, tm2_open))) {
		printf("Error Writing %s\n", tm2_file);
		return(-1);
	}
	
	uint offset = 0x6; //skip string and first block
	uint block = offset + 28;  //next block location (note: compensating for offset)
	while(offset < size) {
		if (offset == block) {  //ignore block instruction
			block += 32;
		} else if (Validate(buffer+offset)) {
			offset = decompress(buffer, offset, tm2_open);
		} else {
			fwrite(buffer+offset, 1, 2, tm2_open);
		}
		offset += 2;   //next values
	}
	//done
	printf("\nAll Done!\n");
	return(0);
}
