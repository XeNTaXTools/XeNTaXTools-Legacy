#!BPY
# -*- coding: utf-8 -*-

""" Registration info for Blender menus:
Name: 'Valkyria Chronicles (.hmdl)...'
Blender: 249
Group: 'Import'
Tip: 'Import .hmdl models from Valkyria Chronicles.'
"""
__author__ = "Chrrox, Gomtuu"
__url__ = ("")
__email__="gomtuu:gmail*com"
__version__ = "0.1.1"

__bpydoc__ = """
Imports .hmdl models from Valkyria Chronicles.
"""

import Blender, bpy
from struct import pack, unpack

def readlong(F):
    return unpack('<i', F.read(4))[0]

def ReadBElong(F):
    return unpack('>i', F.read(4))[0]

def ReadBEword(F):
    return unpack('>h', F.read(2))[0]

def ReadBEfloat(F):
    return unpack('>f', F.read(4))[0]

def convertTo32(inputAsInt):
    sign = inputAsInt >> 15
    exponent = ((inputAsInt & 0x7C00) >> 10) - 16
    fraction = inputAsInt & 0x03FF
    exponentF = exponent + 127
    # Ouput 32 bit integer representing a 32 bit float
    outputAsFloat = pack('>i', (sign << 31) | (exponentF << 23) | (fraction << 13))
    # Output Check
    return unpack('>f', outputAsFloat)[0]

def ReadBEHalfFloat(F):
    return convertTo32(ReadBEword(F))


def printoffset(offset):
    print 'Offset 0x%x' % offset

def open_file(filename):
    KFMS_Array = []
    POF0_Array = []
    ENRS_Array = []
    CCRS_Array = []
    MTXS_Array = []
    EOFC_Array = []
    KFMG_Array = []

    F = open(filename, 'rb')
    F.seek(0x20)
    idstring = F.read(4)
    totalfilesize = readlong(F)
    headersize = readlong(F)
    F.seek(headersize)
    while F.tell() < totalfilesize:
        SecStart = F.tell()
        idstring = F.read(4)
        print idstring
        printoffset(SecStart)
        SecSize = readlong(F)
        HeaderSize = readlong(F)
        Count1 = ReadBElong(F)
        Count2 = readlong(F)
        PartSize = readlong(F)

        if idstring == 'KFMS':
            KFMS_Array.append(SecStart)
        elif idstring == 'POF0':
            POF0_Array.append(SecStart)
        elif idstring == 'ENRS':
            ENRS_Array.append(SecStart)
        elif idstring == 'CCRS':
            CCRS_Array.append(SecStart)
        elif idstring == 'MTXS':
            MTXS_Array.append(SecStart)
        elif idstring == 'EOFC':
            EOFC_Array.append(SecStart)
        elif idstring == 'KFMG':
            KFMG_Array.append(SecStart)

        F.seek(SecStart + HeaderSize + PartSize)

    print KFMS_Array
    F.seek(KFMS_Array[0] + 0x40)
    PosOffCount = ReadBElong(F)
    PosOffTbl = ReadBElong(F)
    V1OffCount = ReadBElong(F)
    V1OffTbl = ReadBElong(F)
    V2OffCount = ReadBElong(F)
    V2OffTbl = ReadBElong(F)
    F.seek(KFMS_Array[0] + 0x80)
    FVFinfo = ReadBElong(F)
    F.seek(KFMS_Array[0] + FVFinfo)
    unk01 = readlong(F)
    vertsize = ReadBElong(F)
    Null01 = ReadBElong(F)
    FaceCount = ReadBElong(F)
    UnkCount = ReadBElong(F)
    VertCount = ReadBElong(F)
    printoffset(vertsize)
    printoffset(VertCount)
    printoffset(FaceCount)
    F.seek(KFMS_Array[0] + V2OffTbl)

    Vert_Info_Array = []
    for a in range(V2OffCount):
        Vert_Info_Array.append({
            'u01': ReadBEword(F),
            'u02': ReadBEword(F),
            'u03': ReadBEword(F),
            'VCount': ReadBEword(F),
            'FCount': ReadBEword(F),
            'n01': ReadBElong(F),
            'u04': ReadBEword(F),
            'VPos': ReadBElong(F),
            'FPos': ReadBElong(F),
            'n02': ReadBElong(F),
            'n03': ReadBElong(F),
            })
    print Vert_Info_Array

    F.seek(KFMG_Array[0] + 0x20)
    FaceStart = F.tell()
    FaceEnd1 = FaceStart + (2 * FaceCount)
    F.seek(FaceEnd1)
    if F.tell() % 16 != 0:
        F.seek(16 - F.tell() % 16, True)
    VertStart = F.tell()
    editmode = Blender.Window.EditMode()
    if editmode: Blender.Window.EditMode(0)
    for a in range(V2OffCount):
        Vert_array = []
        Normal_array = []
        UV_array = []
        Face_array = []

        F.seek(FaceStart + (2 * Vert_Info_Array[a]['FPos']))
        FaceEnd = F.tell() + (2 * Vert_Info_Array[a]['FCount'])
        StartDirection = -1
        f1 = ReadBEword(F)
        f2 = ReadBEword(F)
        FaceDirection = StartDirection
        while F.tell() < FaceEnd:
            f3 = ReadBEword(F)
            if f3 == 0xFFFF:
                f1 = ReadBEword(F)
                f2 = ReadBEword(F)
                FaceDirection = StartDirection
            else:
                FaceDirection *= -1
                if f1 != f2 and f2 != f3 and f3 != f1:
                    if FaceDirection > 0:
                        Face_array.append((f3, f1, f2))
                    else:
                        Face_array.append((f3, f2, f1))
                f1 = f2
                f2 = f3

        F.seek(VertStart + (vertsize * Vert_Info_Array[a]['VPos']))
        for b in range(Vert_Info_Array[a]['VCount']):
            if vertsize == 44:
                vx = ReadBEfloat(F)
                vy = ReadBEfloat(F)
                vz = ReadBEfloat(F)
                nx = ReadBEfloat(F)
                ny = ReadBEfloat(F)
                nz = ReadBEfloat(F)
                wx = ReadBEfloat(F)
                wy = ReadBEfloat(F)
                tu = ReadBEHalfFloat(F) * 2
                tv = ReadBEHalfFloat(F) * -2
                wz = ReadBEfloat(F)
                yy = ReadBEfloat(F)
            elif vertsize == 48:
                vx = ReadBEfloat(F)
                vy = ReadBEfloat(F)
                vz = ReadBEfloat(F)
                nx = ReadBEfloat(F)
                ny = ReadBEfloat(F)
                nz = ReadBEfloat(F)
                tu = ReadBEHalfFloat(F) * 2
                tv = ReadBEHalfFloat(F) * -2
                wx = ReadBEfloat(F)
                wy = ReadBEfloat(F)
                wz = ReadBEfloat(F)
                yy = ReadBEfloat(F)
                yz = ReadBEfloat(F)
            elif vertsize == 80:
                vx = ReadBEfloat(F)
                vy = ReadBEfloat(F)
                vz = ReadBEfloat(F)
                nx = ReadBEfloat(F)
                ny = ReadBEfloat(F)
                nz = ReadBEfloat(F)
                wx = ReadBEfloat(F)
                wy = ReadBEfloat(F)
                wz = ReadBEfloat(F)
                yy = ReadBEfloat(F)
                yz = ReadBEfloat(F)
                ax = ReadBEfloat(F)
                ay = ReadBEfloat(F)
                az = ReadBEfloat(F)
                tu = ReadBEfloat(F)
                tv = ReadBEfloat(F) * -1

                F.seek(0x10, True)
            Vert_array.append((vx,vy,vz))
            #Normal_array.append((nx,ny,nz))
            UV_array.append(Blender.Mathutils.Vector(tu,tv,0))

        # Build Mesh

        msh = bpy.data.meshes.new('myMesh')

        msh.verts.extend(Vert_array)
        #msh.faces.extend(Face_array)

        for i, face in enumerate(Face_array):
            msh.faces.extend(face)
            msh.faces[i].uv = [UV_array[face[0]], UV_array[face[1]], UV_array[face[2]]]

        msh.calcNormals()

        scn = bpy.data.scenes.active
        ob = scn.objects.new(msh, 'myObj')
    if editmode: Blender.Window.EditMode(1)
    Blender.Redraw()
    settings['prev_filename'] = filename
    Blender.Registry.SetKey('hmdl_import', settings, True)

settings = Blender.Registry.GetKey('hmdl_import', True) or {}
if settings:
    Blender.Window.FileSelector(open_file, 'Open File', settings['prev_filename'])
else:
    Blender.Window.FileSelector(open_file, 'Open File')
