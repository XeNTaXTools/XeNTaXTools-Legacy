import newGameLib
from newGameLib import *
import Blender	

def apakParser(filename,g):
	g.debug=True
	g.endian='>'
	g.word(4)
	A=g.i(5)
	fileCount=A[1]
	sys=Sys(filename)
	sys.addDir(sys.base+'_files')
	for m in safe(fileCount):
		mA=g.i(8)
		name=g.word(32)
		t=g.tell()
		g.seek(mA[1])
		new=open(sys.dir+os.sep+sys.base+"_files"+os.sep+name,'wb')
		new.write(g.read(mA[2]))
		new.close()
		g.seek(t)

def check(g):
	t=g.tell()
	size=g.i(1)[0]
	g.seek(t+size)
	g.i(40)
	g.seek(t+4)
	return t+size
	
def getList(g,items):
	value=[]
	split=items.split('+')
	for item in split:
		if 'i' in item:
			a=int(item.split('i')[0])
			for n in safe(a):
				tn=g.tell()
				value.append([tn,g.i(1)[0]])
		if 'B' in item:
			a=int(item.split('B')[0])
			for n in safe(a):
				tn=g.tell()
				value.append([tn,g.B(1)[0]])
		if 'H' in item:
			a=int(item.split('H')[0])
			for n in safe(a):
				tn=g.tell()
				value.append([tn,g.H(1)[0]])
		if 'f' in item:
			a=int(item.split('f')[0])
			for n in safe(a):
				tn=g.tell()
				value.append([tn,g.f(1)[0]])
		if 's' in item:
			a=int(item.split('s')[0])
			tn=g.tell()
			value.append([tn,g.word(int(a))])
	return value
	
def getName(offset,g):
	t=g.tell()
	g.seek(offset-4)
	name=g.word(g.i(1)[0])
	g.seek(t)
	return name
	
def findOffset(value,g):
	pos=g.tell()
	g.seek(0)
	while(True):
		if g.tell()>=g.fileSize():break
		t=g.tell()
		size=g.i(1)[0]
		if t+size==value:print 'mam:',t,size
	g.seek(pos)	
	
	
def setOffset(g):
	t=g.tell()
	size=g.i(1)[0]
	g.seek(t+size)
	return t+4
		
	
def setItemOffset(item,g):
	back=g.tell()
	g.seek(item[0]+item[1])
	return back



	
class Stream:
	def __init__(self):
		self.itemSize=None
		self.itemCount=None
		self.size=None
		self.offset=None
	
class VertItem:
	def __init__(self):
		self.type=None
		self.format=None
		self.offset=None
		self.streamID=None
	
def FVTX(mesh,g):


	mesh.streamList=[]
	mesh.vertItemList=[]

	listC=getList(g,'4s+4B+1i+4B+4i')
	for i,item in enumerate(listC):
		if i==0:mesh.FVTXoffset=item[0]
		if i==2:streamDataCount=item[1]
		if i==11:
			back=setItemOffset(item,g)
			unk,count=g.i(2)
			list=g.B(16)	
			for m in safe(count):
				t=g.tell()				
				list11=getList(g,'4H+2i')
				for j,item in enumerate(list11):
					if j==5:
						backj5=setItemOffset(item,g)
						list5=getList(g,'1i+8B')
						vertItem=VertItem()
						mesh.vertItemList.append(vertItem)
						for k,item in enumerate(list5):
							if k==0:
								backk0=setItemOffset(item,g)
								name=getName(item[0]+item[1],g)
								vertItem.name=name
								g.seek(backk0)
							if k==1:vertItem.streamID=item[1]
							if k==4:vertItem.offset=item[1]
							if k==8:vertItem.format=item[1]								
						g.seek(backj5)	
			g.seek(back)
			
		if i==12:
			back=setItemOffset(item,g)
			for m in safe(streamDataCount):
				list12=getList(g,'3i+2H+2i')
				stream=Stream()
				mesh.streamList.append(stream)
				for j,item in enumerate(list12):
					if j==1:stream.size=item[1]
					if j==3:stream.itemSize=item[1]
					if j==6:stream.offset=item[0]+item[1]
			g.seek(back)
	
	
	
def FSHP(g):
	unk,count=g.i(2)
	list=g.B(16)	
	for m in safe(count):
		t=g.tell()		
		list11=getList(g,'4H+2i')
		mesh=Mesh()
		meshList.append(mesh)
		for j,item in enumerate(list11):
			if j==4:
				name=getName(item[0]+item[1],g)
				mat=Mat()
				mat.matName=name
				mat.TRIANGLE=True
				mesh.matList.append(mat)
			if j==5:
				FSHPoffset=item[0]+item[1]
				backi7=setItemOffset(item,g)
				chunk=g.word(4)
				list5=getList(g,'14H+12i')
				for i,item in enumerate(list5):	
					if i==8:
						boneMapItemCount=item[1]
					if i==14:	
						backi14=setItemOffset(item,g)
						FVTX(mesh,g)
						g.seek(backi14)
						
					if i==16:
						boneMapItemOffset=item[0]+item[1]
						backi16=g.tell()
						g.seek(boneMapItemOffset)
						boneMap=g.H(boneMapItemCount)
						g.seek(backi16)
						skin=Skin()
						#skin.boneMap=boneMap
						mesh.skinList.append(skin)
					if i==18:
						backi18=setItemOffset(item,g)
						bb=g.f(12)
						listi18=getList(g,'8i')
						for k,item in enumerate(listi18):	
							if k==1:mesh.indiceCount=item[1]
							if k==7:mesh.indiceOffset=item[0]+item[1]
						g.seek(mesh.indiceOffset)
						mesh.indiceList=g.H(mesh.indiceCount)
						g.seek(backi18)
				g.seek(backi7)
				
				
	
	
def FSKL(g):
	listC=getList(g,'4s+6H+5i')	
	for i,item in enumerate(listC):	
		if i==3:boneCount=item[1]
		if i==8:
			backi8=setItemOffset(item,g)
			skeleton.boneMap=[]
			for m in safe(boneCount):
				bone=Bone()
				skeleton.boneList.append(bone)
				t=g.tell()
				size=g.i(1)[0]
				bone.name=getName(t+size,g)
				mA=g.h(8)
				bone.mA=mA
				if mA[2]!=-1:
					skeleton.boneMap.append(bone.name)
				bone.parentID=mA[1]
				g.f(3)
				x=degrees(g.f(1)[0])
				y=degrees(g.f(1)[0])
				z=degrees(g.f(1)[0])
				g.f(1)
				rotMatrix=Euler([x,y,z]).toMatrix().resize4x4()
				posMatrix=VectorMatrix(g.f(3))
				matrix=rotMatrix*posMatrix
				bone.matrix=matrix#.invert()
				g.i(1)
			
			
			
			g.seek(backi8)
	
	
def FMDL(g):

	
	listB=getList(g,'4s+7i+4H+2i')
	FVTXoffset,FVTXcount=None,None
	FSHPcount,FSHPoffset=None,None
	for i,item in enumerate(listB):	
		if i==1:
			name=getName(item[0]+item[1],g)
		if i==2:
			name=getName(item[0]+item[1],g)
		if i==3:
			FSKLoffset=item[0]+item[1]
			backi3=setItemOffset(item,g)
			FSKL(g)
			g.seek(backi3)
			#break
		if i==4:
			FVTXoffset=item[0]+item[1]
			
		if i==5:#7
			FSHPoffset=item[0]+item[1]
			backi7=setItemOffset(item,g)
			FSHP(g)
			g.seek(backi7)
			
		if i==8:
			FVTXcount=item[1]
			g.seek(FVTXoffset)
			#for m in safe(FVTXcount):
			#	FVTX(g)
			
			
			
		
				

def bfresParser(filename,g):

	global meshList,skeleton
	meshList=[]
	#g.logskip=True
	
	
	skeleton=Skeleton()
	skeleton.BONESPACE=True
	skeleton.NICE=True
	
	g.endian='>'
	#findOffset(19540,g)
	#g.debug=True
	chunk=g.word(4)
	A=g.B(8)
	
	g.i(2)
	name=getName(g.tell()+g.i(1)[0],g)
	g.i(1)
	name=getName(g.tell()+g.i(1)[0],g)
	
	#model
	back0=setOffset(g)
	listA=getList(g,'10i')
	for i,item in enumerate(listA):
		if i==9:
			back1=setItemOffset(item,g)
			FMDL(g)
			g.seek(back1)
	g.seek(back0)
	
	back0=setOffset(g)
	listA=getList(g,'10i')
	g.seek(back0)
	
	
	skeleton.draw()	
	for i,mesh in enumerate(meshList):
		#break
		mesh.boneName=None
		mesh.BINDSKELETON=skeleton.name
		mesh.boneNameList=skeleton.boneMap
		print 'mesh'
		for item in mesh.vertItemList:
			print item.name,item.format,item.streamID,item.offset
			if item.name=='_p0':
				stream=mesh.streamList[item.streamID]
				g.seek(stream.offset)
				itemCount=stream.size/stream.itemSize
				#print item.format,itemCount,stream.offset,item.streamID,stream.itemSize,item.offset
				for m in safe(itemCount):
					t=g.tell()
					g.seek(t+item.offset)
					if item.format==17:mesh.vertPosList.append(g.f(3))
					if item.format==15:mesh.vertPosList.append(g.half(3))
					g.seek(t+stream.itemSize)
			if item.name=='_u0':
				stream=mesh.streamList[item.streamID]
				g.seek(stream.offset)
				itemCount=stream.size/stream.itemSize
				#print item.format,itemCount,stream.offset,item.streamID,stream.itemSize,item.offset
				for m in safe(itemCount):
					t=g.tell()
					g.seek(t+item.offset)
					if item.format==7:mesh.vertUVList.append(g.short(2,'H',16))
					if item.format==8:mesh.vertUVList.append(g.half(2))
					g.seek(t+stream.itemSize)
			if item.name=='_i0':
				#print stream.offset
				stream=mesh.streamList[item.streamID]
				g.seek(stream.offset)
				itemCount=stream.size/stream.itemSize
				#print item.format,itemCount,stream.offset,item.streamID,stream.itemSize,item.offset
				mesh.skinIndiceList2=[]
				mesh.idList=[]
				for m in safe(itemCount):
					t=g.tell()
					g.seek(t+item.offset)
					#print g.tell(),
					if item.format==4:mesh.skinIndiceList.append(g.B(2))
					if item.format==10:mesh.skinIndiceList.append(g.B(3))
					if item.format==0:
						id=g.B(1)[0]
						if id not in mesh.idList:
							mesh.idList.append(id)
						mesh.skinIndiceList2.append(id)
						mesh.skinWeightList.append([1.0])
					g.seek(t+stream.itemSize)
				if item.format==0:	
					boneListA={}
					for id in mesh.idList:
						for bone in skeleton.boneList:
							if id==bone.mA[3]:
								boneListA[id]=bone.name
					for id in mesh.skinIndiceList2:						
						mesh.skinGroupList.append([boneListA[id]])
						
					if len(mesh.idList)==1:
						for bone in skeleton.boneList:
							if mesh.idList[0]==bone.mA[3]:
								mesh.boneName=bone.name
								break
			if item.name=='_w0':
				stream=mesh.streamList[item.streamID]
				g.seek(stream.offset)
				itemCount=stream.size/stream.itemSize
				#print item.format,itemCount,stream.offset,item.streamID,stream.itemSize,item.offset
				for m in safe(itemCount):
					t=g.tell()
					g.seek(t+item.offset)
					if item.format==4:mesh.skinWeightList.append(g.B(2))
					if item.format==10:mesh.skinWeightList.append(g.B(3))
					g.seek(t+stream.itemSize)
		#print mesh.skinList[0].boneMap	
			
		mesh.draw()
		if mesh.boneName is not None:
			mesh.setBoneMatrix(skeleton.name,mesh.boneName)
		#break
		

def Parser(filename):	
	global log
	ext=filename.split('.')[-1].lower()
	
	if ext=='apak':
		file=open(filename,'rb')
		g=BinaryReader(file)
		apakParser(filename,g)
		file.close()
	
	if ext=='bfres':
		file=open(filename,'rb')
		g=BinaryReader(file)
		bfresParser(filename,g)
		file.close()
 
 
	
Blender.Window.FileSelector(Parser,'import','select files: *.apak, *.bfres') 
	