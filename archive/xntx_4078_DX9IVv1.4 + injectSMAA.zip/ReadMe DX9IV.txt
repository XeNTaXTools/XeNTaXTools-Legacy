Directx 9 image viewer v1.3

by default it will open a picture named screenshot.bmp in the same folder

you can drag and drop an other screenshot on the exe to open it

it will use the resolution of the 1st monitor so you need a screenshot of the same resolution

unpack the sweetfx archive in the same folder 