import sys
import os
import struct

in_file = sys.argv[1]

name, ext = os.path.splitext(in_file)
out_file = name + '_out.obj'

def halfFloat(h):
    s = int((h >> 15) & 0x00000001)
    e = int((h >> 10) & 0x0000001f)
    f = int(h & 0x000003ff)
    
    if e == 0:
        if f == 0:
            return int(s << 31)
        else:
            while not (f & 0x00000400):
                f = f << 1
                e -= 1
            e += 1
            f &= ~0x00000400
    elif e == 31:
        if f == 0:
            return int((s << 31) | 0x7f800000)
        else:
            return int((s << 31) | 0x7f800000 | (f << 13))
    
    e = e + (127 -15)
    f = f << 13
    
    temp = int((s << 31) | (e << 23) | f)
    str = struct.pack('I',temp)
    return struct.unpack('f',str)[0]

with open(in_file, "rb") as bs: 
    if bs.read(8)[1:] != b'MESSIAH':
        sys.exit("This file not Diablo Immortal *.mesh !")
    with open(out_file, "w") as obj:
        
        bs.seek(18)
        submesh = struct.unpack('H', bs.read(2))[0]
        vnum, inum = struct.unpack('II', bs.read(8))
    
        attrib = [bs.read(struct.unpack('H', bs.read(2))[0]) for x in range(4)]
        
        uv_stride = 12 if attrib[1] == b'Q4H_T2H' else 16
        
        bs.seek(40,1)
        
        for x in range(submesh):
            bs.seek(16,1)#4i
        
        ibuf = []
        for x in range(inum//3):
            ibuf.append(struct.unpack('3H', bs.read(6)))
        
        vbuf = []
        for x in range(vnum):
            vbuf.append(struct.unpack('3f', bs.read(12)))

        uvbuf = []
        for x in range(vnum):
            bs.seek(8,1)
            uvbuf.append([halfFloat(struct.unpack('H', bs.read(2))[0]),halfFloat(struct.unpack('H', bs.read(2))[0])])
            bs.seek(uv_stride-12,1)
        
        obj.write('#Durik256 Diablo exporter\n')
        obj.write('mtllib default.mtl\n')
        
        for x in vbuf:
            obj.write('v %f %f %f \n' % x)
        
        for x in uvbuf:
            obj.write('vt %f %f \n' % (x[0],x[1]))
        
        obj.write('usemtl Material\n')
        
        for x in ibuf:
            a,b,c = x[0]+1,x[2]+1,x[1]+1
            obj.write('f %d/%d %d/%d %d/%d \n' % (a,a, b,b, c,c))

print('out_file:', out_file)
os.system('pause')