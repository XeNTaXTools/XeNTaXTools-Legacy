from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Toy Soldiers War Chest", ".pngb")
	noesis.setHandlerTypeCheck(handle, noeCheckGeneric)
	noesis.setHandlerLoadRGBA(handle, TSWCLoadRGBA)
	#noesis.logPopup()
	return 1

def TSWCLoadRGBA(data, texList):
	bs = NoeBitStream(data)
	bs.seek(0x6C, NOESEEK_ABS)         #goto address 0x6C to get the custom header length
	imgData = bs.readInt()             #read integer to find where image data starts
	datasize = len(data) - imgData     #length of file data minus custom header
	bs.seek(0x70, NOESEEK_ABS)         #goto address 0x70 to get imgFmt
	imgFmt = bs.readByte()             #read byte to get image size: 0B - 1024x1024 / 0A - 512x512
	bs.seek(0x78, NOESEEK_ABS)         #goto address 0x78 to get texFmt
	texFmt = bs.readByte()             #read byte to get type: 03 - dxt5 01 - dxt1
	bs.seek(imgData, NOESEEK_ABS)      #goto address 0x118 - 280 byte custom header or 0x108 - 264
	data = bs.readBytes(datasize)      #read file data minus custom header
	#DXT1
	if imgFmt == 10 and texFmt == 1:
         imgWidth = 512            
         imgHeight = 512
         rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_DXT1)
         texFmt = noesis.NOESISTEX_DXT1
	elif imgFmt == 11 and texFmt == 1:
         imgWidth = 1024            
         imgHeight = 1024
         rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_DXT1)
         texFmt = noesis.NOESISTEX_DXT1
	#DXT5
	elif imgFmt == 10 and texFmt == 3:
         imgWidth = 512            
         imgHeight = 512
         rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_DXT5)
         texFmt = noesis.NOESISTEX_DXT5
	elif imgFmt == 11 and texFmt == 3:
         imgWidth = 1024            
         imgHeight = 1024
         rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_DXT5)
         texFmt = noesis.NOESISTEX_DXT5
		 #unknown, not handled
	else:
		print("WARNING: Unhandled image format")
		return None
	texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
	return 1