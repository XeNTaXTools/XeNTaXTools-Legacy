/***************************************************
** Author: Jos� Antonio R�os Couto                **
** Date: 05/24/2009                               **
** Purpose: View a CMP image file                 **  
** License: Use code/utility freely               ** 
** Notes: Link against: -lmingw32 -lSDLmain -lSDL **
****************************************************/

#include "SDL.h"

SDL_Surface *mainSurface;
SDL_Event event1;
SDL_Rect destRect;
FILE *file1;

int main( int argc, char *argv[] )
{
    // Declare some variables
    unsigned long cmpSize;
    unsigned short width, height;
    Uint32 colour;
	Uint8 red, green, blue;
	unsigned char pixel;
	unsigned long position;
    
	if( SDL_Init( SDL_INIT_VIDEO ) != 0 )
	{
		fprintf( stderr, "SDL Error while attemping to initialize video subsystem: %s", SDL_GetError() );
		exit( 1 );
	}
	else
	{
		fprintf( stdout, "SDL video subsystem initialized properly!" );
		atexit( SDL_Quit );
	}

    file1 = fopen( "GIRL0.CMP", "rb" );
	if( !file1 )
	{
		fprintf( stderr, "Error while attemping to open GIRL0.CMP!");
		exit( 1 );
	}

	fread( &cmpSize, sizeof( cmpSize ), 1, file1 );
	fread( &width, sizeof(width), 1, file1 );
	fread( &height, sizeof(height), 1, file1 );
	fseek( file1, 206, SEEK_SET );

	mainSurface = SDL_SetVideoMode( width, height, 32, SDL_ANYFORMAT );
	if( !mainSurface )
	{
		fprintf( stderr, "SDL Error while attemping to Set Video Mode: %s", SDL_GetError() );
		exit( 1 );
	}
	
	// Initialize rectangle
	destRect.w = 1;
	destRect.h = 1;
	
	// Loop for representing the pixels of the image
	for( int i = 0; i < width*height; i++ )
	{
		fread( &pixel, sizeof( pixel ), 1, file1 ); // Read a pixel
		position = ftell( file1 ); // Remember position for reading next pixel
		fseek( file1, (pixel*3)+11, SEEK_SET ); // Position cursor on the palette colour for the pixel

		fread( &red, sizeof( red ), 1, file1 ); // Read colour components
		fread( &green, sizeof( green ), 1, file1 );
		fread( &blue, sizeof( blue ), 1, file1 );
		colour = SDL_MapRGB( mainSurface->format, red, green, blue ); // Compose colour
		
		destRect.x = i%width; // Choose destination
		destRect.y = i/width;

		SDL_FillRect( mainSurface, &destRect, colour ); // Fill the rectangle 
		
		fseek( file1, position, SEEK_SET ); // Finally, return to the position to read the next pixel
	}

    SDL_Flip( mainSurface ); // Update screen to see the changes
    
	for( ;; ) // Main loop
	{
		if( SDL_WaitEvent( &event1 ) == 0 ) // If there's an error waiting for an event
		{
			fprintf( stderr, "Error while waiting for an event!\n" );
			exit( 1 );
		}
		
		if( event1.type == SDL_QUIT ) // If the application is told to close
		{
            fprintf( stdout, "Quit event has occurred.\n" );
		    break;
        }		
	}

	fclose( file1 );
	fprintf( stdout, "Terminating program normally.\n" );
	return 0;
}
