﻿
RE txtres tool
--------------

Tested with mes_us.txtres only. No ingame test since I don't owe the game.
So don't blame me if it doesn't work as expected.


 *** instructions ***

- open a txtres file

- to create a stringtable file press button go1
it will complain about an import.txt file open error
but that's ok atm because it doesn't exist

- close the exe and search for export.txt in the folder where the txtres resides

- copy/rename the export.txt to import.txt

- do your translation of the contained lines

- save edited import.txt as ANSI txt file!

 #########################################
 Don't add any line, don't erase any line!

 #########################################

start the exe, open the same txtres file as before,
then press go1 again.

A _mes_us.txtres will be created in the above mentioned folder.

Have fun,
shak-otay, Sept. 2014


note:
Be sure to save the import.txt as ANSI txt file (NOT UTF-8).

UTF-8 and UNICODE files created by notepad have a 3 byte binary signature 
at their beginning which will disturb the stringtable on reimport.


But saving as ANSI will cause a problem with some chars.

For example

Offset  0  1  2  3  4  5  6  7   8  9  A  B  C  D  E  F

0824B0 20 72 69 64 20 00 74 68  65 20 77 6F 72 6C 64 20    rid .the world 
0824C0 6F 66 20 73 75 63 68 20  70 6F 77 65 72 E2 80 A6   of such power…
0824D0 3F 00 56 4F 5F 33 30 36  35 31 37 36 00 59 6F 75   ?.VO_3065176.You

other chars affected:

special sign "TM": E2 99 -> ? (3F)
CE A0
CE A3
E2 98
CE 91

As you know I don't owe the game so I don't
intend to waste more time on solving this, sry.

