import newGameLib
from newGameLib import *
import Blender	


def bndParser(filename,g):
	g.i(1)
	g.word(g.i(1)[0])
	count=g.i(1)[0]
	skeleton=Skeleton()
	skeleton.BONESPACE=True
	skeleton.name=g.basename.split('.')[0]
	skeleton.NICE=True
	for m in range(count):
		if g.tell()>=g.fileSize():break
		bone=Bone()
		bone.ID=g.i(1)[0]
		bone.parentID=g.i(1)[0]
		if len(skeleton.boneList)==0:
			bone.parentID=-1
		bone.posMatrix=VectorMatrix(g.f(3))
		bone.rotMatrix=QuatMatrix(g.f(4)).resize4x4()
		skeleton.boneList.append(bone)
	skeleton.BINDMESH=True	
	skeleton.draw()
	
def motParser(filename,g):
	action=Action()
	action.BONESORT=True
	action.MIXSPACE=True
	action.skeleton='g'+g.basename.split('-')[0]
	g.i(2)
	action.name=g.word(g.i(1)[0])
	frameCount=g.i(1)[0]
	boneCount=g.i(1)[0]
	for m in range(boneCount):
		bone=ActionBone()
		bone.name=str(g.i(1)[0])
		for n in range(g.i(1)[0]):
			posMatrix=VectorMatrix(g.f(3))
			rotMatrix=QuatMatrix(g.f(4)).resize4x4()
			bone.matrixFrameList.append(n*2)
			matrix=rotMatrix*posMatrix
			bone.matrixKeyList.append(matrix)
		action.boneList.append(bone)	
	action.draw()
	action.setContext()	
	
	

def sknParser(filename,g):
	sknID,bindID=g.i(2)
	g.word(g.i(1)[0])
	a=g.i(1)[0]
	mesh=Mesh()
	for m in range(a):
		face=[]
		faceUV=[]
		for n in range(3):
			t=g.tell()
			face.append(g.i(1)[0])
			faceUV.append(Vector(g.f(2)))
		mesh.faceList.append(face)
		mesh.faceUVList.append(faceUV)	
		mesh.skinIndiceList.append([])
		mesh.skinWeightList.append([])
		mesh.skinIDList.append([1])
	count=g.i(1)[0]
	skin=Skin()
	mesh.skinList.append(skin)
	for m in range(count):
		g.seek(12,1)
		mesh.vertPosList.append(g.f(3))
	count=g.i(1)[0]
	for m in range(count):
		vertID,i,w=g.i(2)+g.f(1)
		mesh.skinIndiceList[vertID].append(i)
		mesh.skinWeightList[vertID].append(w)
		
	txtPath=filename.split('skin')[0]+'skin.txt'
	tex256256Dir=filename.split('skin')[0]+'tex256256'	
	tex256512Dir=filename.split('skin')[0]+'tex256512'	
	tex512512Dir=filename.split('skin')[0]+'tex512512'		
	tex10241024Dir=filename.split('skin')[0]+'tex10241024'
	mat=Mat()
	mat.ZTRANS=True
	mat.TRIANGLE=True	
	if os.path.exists(txtPath)==True:
		file=open(txtPath,'r')
		for line in file.readlines()[1:]:
			A=line.split()
			if A[4]==str(sknID):
				texID=A[5]
				print 'texture:',texID
				if texID+'.png' in os.listdir(tex256256Dir):mat.diffuse=tex256256Dir+os.sep+texID+'.png'
				if texID+'.dds' in os.listdir(tex256256Dir):mat.diffuse=tex256256Dir+os.sep+texID+'.dds'				
				if texID+'.png' in os.listdir(tex256512Dir):mat.diffuse=tex256512Dir+os.sep+texID+'.png'
				if texID+'.dds' in os.listdir(tex256512Dir):mat.diffuse=tex256512Dir+os.sep+texID+'.dds'				
				if texID+'.png' in os.listdir(tex512512Dir):mat.diffuse=tex512512Dir+os.sep+texID+'.png'				
				if texID+'.png' in os.listdir(tex10241024Dir):mat.diffuse=tex10241024Dir+os.sep+texID+'.png'				
		file.close()
	mesh.matList.append(mat)	
	mesh.draw()	
	
	
	bindDir=filename.split('skin')[0]+'bind'
	bindPath=bindDir+os.sep+'g'+str(bindID)+'.bnd'
	if os.path.exists(bindPath)==True:
		file=open(bindPath,'rb')
		p=BinaryReader(file)
		bndParser(bindPath,p)
		file.close()
		
	txtPath=filename.split('skin')[0]+'actormotion.txt'	
	if os.path.exists(txtPath)==True:
		file=open(txtPath,'r')
		for line in file.readlines()[1:]:
			A=line.split()
			if A[2]==str(bindID):
				motIDList=A[15:]
				motDir=filename.split('skin')[0]+'mot'
				for i,motID in enumerate(motIDList):
					motPath=motDir+os.sep+'g'+motID+'.mot'
					if os.path.exists(motPath)==True:
						motfile=open(motPath,'rb')
						p=BinaryReader(motfile)					
						try:os.makedirs(blendDir+os.sep+'anim_files')
						except:pass
						new=open(blendDir+os.sep+'anim_files'+os.sep+str(bindID)+'-'+str(i)+'.mot','wb')
						new.write(p.read(p.fileSize()))
						new.close()
						motfile.close()
				
		file.close()
		
	
	
def Parser():	
	filename=input.filename
	print filename
	ext=filename.split('.')[-1].lower()	
	
	if ext=='skn':
		file=open(filename,'rb')
		g=BinaryReader(file)
		sknParser(filename,g)
		file.close()
	
	if ext=='mot':
		file=open(filename,'rb')
		g=BinaryReader(file)
		motParser(filename,g)
		file.close()
 
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
	
Blender.Window.FileSelector(openFile,'import','Do Online files: *.skn - model, mot - animation') 
	