from inc_noesis import *
import noesis
import rapi
import os


def registerNoesisTypes():
	handle = noesis.register("Phyre", ".phyre")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadModel(handle, noepyLoadModel)
	return 1

def noepyCheckType(data):
	return 1

def version3541(g):
	noeStrFromBytes(g.readBytes(4))
	X=g.read('>32i')
	A=[]
	for i in range(X[21]):
		A.append(g.read('>9i'))
	B=[]	
	for i in range(X[22]):
		B.append(g.read('>6i'))
	offA=g.tell()
	C=[]
	for i,a in enumerate(A):
		g.seek(offA+a[2])
		chunk=g.readString()
		C.append([i,a,chunk])
	D=[]	
	for i,b in enumerate(B):
		g.seek(offA+b[0])
		chunk=g.readString()
		D.append([i,b,chunk])
	g.seek(offA+X[23])
	E=[]
	for i in range(X[0]):
		e=g.read('>9i')
		E.append(e)
	offE=g.tell()
	
	for e in E:
		#print(e)
		if e[0]==10:
			g.seek(offE)
			count=e[3]//4
			data=g.read('>'+str(count)+'i')	
			#print(data)		
			szer=data[7]
			wys=data[8]
			size=data[23]
			if data[0]==-1933358832:format='DXT5'
			elif data[0]==1690519824:format='DXT1'
			else:format='unk'
		if e[0]==1:
			g.seek(offE)
			count=e[3]//4
			g.read('>'+str(count)+'i')
			name=os.path.basename(noeStrFromBytes(g.readBytes(e[4])))
			#print (name)
		offE+=e[2]
	g.seek(offE)
	noeStrFromBytes(g.readBytes(16))
	g.readBytes(37)	
	size=g.dataSize-g.tell()
	#print('tell:',g.tell(),format,size)
	imgData=g.readBytes(size)	
	if format == "DXT1":texFmt = noesis.NOESISTEX_DXT1
	elif format == "DXT3":texFmt = noesis.NOESISTEX_DXT3
	elif format == "DXT5":texFmt = noesis.NOESISTEX_DXT5
	else:texFmt = noesis.NOESISTEX_RGBA32
	tex = NoeTexture(name, szer, wys, imgData, texFmt)
	texList.append(tex)

def parseInfo(g):
	noeStrFromBytes(g.readBytes(4))
	X=g.read('>43i')
	A=[]
	for i in range(X[21]):
		A.append(g.read('>9i'))
	B=[]	
	for i in range(X[22]):
		B.append(g.read('>6i'))
	offA=g.tell()
	C=[]
	for i,a in enumerate(A):
		g.seek(offA+a[2])
		chunk=g.readString()
		C.append([i,a,chunk])
	D=[]	
	for i,b in enumerate(B):
		g.seek(offA+b[0])
		chunk=g.readString()
		D.append([i,b,chunk])
	g.seek(offA+X[23])
	E=[]
	for i in range(X[0]):
		e=g.read('>9i')
		E.append(e)
	offE=g.tell()
	return A,B,C,D,E	
	
	
def version30639(g):
	noeStrFromBytes(g.readBytes(4))
	X=g.read('>45i')
	A=[]
	for i in range(X[21]):
		A.append(g.read('>9i'))
	B=[]	
	for i in range(X[22]):
		B.append(g.read('>6i'))
	offA=g.tell()
	C=[]
	for i,a in enumerate(A):
		g.seek(offA+a[2])
		chunk=g.readString()
		C.append([i,a,chunk])
	D=[]	
	for i,b in enumerate(B):
		g.seek(offA+b[0])
		chunk=g.readString()
		D.append([i,b,chunk])
	g.seek(offA+X[23])
	E=[]
	for i in range(X[0]):
		e=g.read('>9i')
		E.append(e)
	offE=g.tell()
	indiceInfo=[]
	vertInfo=[]
	matCount=None
	off=g.tell()
	for e in E:	
		g.seek(offE)
		#print(g.tell(),e)
		if e[0]==28:
			count=e[3]//80
			for i in range(count):
				vertInfo.append(g.read('>20i'))
				#print(i,vertInfo[i])
		if e[0] in [68]:#69
			count=e[3]//124
			matCount=count
			for i in range(count):
				indiceInfo.append(g.read('>31i'))
				
		if e[0]==31:
			F=[]
			count=e[3]//24
			for i in range(count):
				F.append(g.read('>6i'))
				#print (F[i])
			for i in range(count):
				g.seek(F[i][0]*F[i][1],1)
					
		offE+=e[2]
		
		
	g.seek(off+X[10])	
	
	offE=g.tell()
	g.seek(offE+X[9])
	for i in range(X[8]):
		g.read('>3i')
	sum=0
	for i in range(X[11]):
		sum+=g.read('>i')[0]
	list=[]
	for i in range(X[12]):
		h=g.read('>4i')
		list.append(h[1])
		
	#from here is abracadabra	
		
	t=g.tell()
	bdata=g.data[t:g.dataSize]
	g.seek(t+bdata.find(b'\x00\x00\x00\x01\x00\x02\x00'))
	vertOff=g.tell()
	indiceOff=vertOff
	List=[]
	if matCount is not None:
		for i in range(matCount):
			#print (i,g.tell(),indiceInfo[i])
			g.seek(indiceOff+indiceInfo[i][20])
			idxList=g.read('>'+str(indiceInfo[i][18]//2)+'H')
			List.append(idxList)
		g.read('>2i')
		for i in range(matCount):
			#print('stream offset:',g.tell())
			
			posList=[]
			uvList=[]
			skinWeightList=[]
			skinIndiceList=[]
			for j in range(len(vertInfo)//matCount):
				t=g.tell()
				info=vertInfo[j+i*(len(vertInfo)//matCount)]
				#print(j+i*(len(vertInfo)//matCount),g.tell())
				g.seek(vertOff+info[9])
				if j==0:
					for k in range(0, info[1]):	
						posList.append(NoeVec3(g.read('>3f')))
				else:		
					if info[0]==8:
						for k in range(info[1]):
							uv=NoeVec3()
							uv[:2]=g.read('>2f')
							uvList.append(uv)
					elif info[0]==16:
						for k in range(info[1]):skinWeightList.append(g.read('>4f'))
					elif info[0]==4:
						for k in range(info[1]):skinIndiceList.append(g.read('>4B'))
					elif info[0]==12:
						for k in range(info[1]):g.seek(12,1)#12
					
			idxList=List[i]
			#print(idxList)
			material = NoeMaterial('material',texList[0].name)
			#material.setTexture(texList[0].name) 
			rapi.rpgSetMaterial(material.name)
			matList.append(material)
			mesh = NoeMesh(idxList, posList, 'model', material.name)	
			mesh.uvs=uvList
			meshList.append(mesh)
			#print('stream end:',g.tell())
			#break
		
	
	
def version29382(g):
	noeStrFromBytes(g.readBytes(4))
	X=g.read('>45i')
	A=[]
	for i in range(X[21]):
		A.append(g.read('>9i'))
	B=[]	
	for i in range(X[22]):
		B.append(g.read('>6i'))
	offA=g.tell()
	C=[]
	for i,a in enumerate(A):
		g.seek(offA+a[2])
		chunk=g.readString()
		C.append([i,a,chunk])
	D=[]	
	for i,b in enumerate(B):
		g.seek(offA+b[0])
		chunk=g.readString()
		D.append([i,b,chunk])
	g.seek(offA+X[23])
	E=[]
	for i in range(X[0]):
		e=g.read('>9i')
		E.append(e)
	offE=g.tell()
	indiceInfo=[]
	vertInfo=[]
	matCount=None
	off=g.tell()
	for e in E:	
		g.seek(offE)
		#print(g.tell(),e)
		if e[0]==24:
			count=e[3]//80
			for i in range(count):
				vertInfo.append(g.read('>20i'))
		if e[0]==63:
			count=e[3]//124
			matCount=count
			for i in range(count):
				indiceInfo.append(g.read('>31i'))
		if e[0]==29:
			count=e[3]//64
			for i in range(count):
				NoeMat43.fromBytes(g.readBytes(64))
		if e[0]==27:
			F=[]
			count=e[3]//24
			for i in range(count):
				F.append(g.read('>6i'))
			for i in range(count):
				g.seek(F[i][0]*F[i][1],1)
					
		offE+=e[2]
		
		
	g.seek(off+X[10])	
	
	offE=g.tell()
	g.seek(offE+X[9])
	for i in range(X[8]):
		g.read('>3i')
	sum=0
	for i in range(X[11]):#??????????????????????????	
		sum+=g.read('>i')[0]
	list=[]
	for i in range(X[12]):
		h=g.read('>4i')
		list.append(h[1])
		
		
		
	t=g.tell()
	bdata=g.data[t:g.dataSize]
	g.seek(t+bdata.find(b'\x00\x00\x00\x01\x00\x02\x00'))
	vertOff=g.tell()
	indiceOff=vertOff
	if matCount is not None:
		for i in range(matCount):
			posList=[]
			uvList=[]
			skinWeightList=[]
			skinIndiceList=[]
			for j in range(len(vertInfo)//matCount):
				info=vertInfo[j+i*(len(vertInfo)//matCount)]
				if j==0:
					g.seek(vertOff+info[9])
					for j in range(0, info[1]):	
						posList.append(NoeVec3(g.read('>3f')))
				if info[0]==8:
					g.seek(vertOff+info[9])
					for k in range(info[1]):
						uv=NoeVec3()
						uv[:2]=g.read('>2f')
						uvList.append(uv)
				if info[0]==16:
					g.seek(vertOff+info[9])
					for k in range(info[1]):
						skinWeightList.append(g.read('>4f'))
				if info[0]==4:
					g.seek(vertOff+info[9])
					for k in range(info[1]):
						skinIndiceList.append(g.read('>B'))
					
			g.seek(indiceOff+indiceInfo[i][20])
			#print(g.tell())
			idxList=g.read('>'+str(indiceInfo[i][18]//2)+'H')	
			material = NoeMaterial('material',texList[0].name)
			#material.setTexture(texList[0].name) 
			rapi.rpgSetMaterial(material.name)
			matList.append(material)
			mesh = NoeMesh(idxList, posList, 'model', material.name)	
			mesh.uvs=uvList
			meshList.append(mesh)
		
	
def version27968(g):
	noeStrFromBytes(g.readBytes(4))
	X=g.read('>43i')
	A=[]
	for i in range(X[21]):
		A.append(g.read('>9i'))
	B=[]	
	for i in range(X[22]):
		B.append(g.read('>6i'))
	offA=g.tell()
	C=[]
	for i,a in enumerate(A):
		g.seek(offA+a[2])
		chunk=g.readString()
		C.append([i,a,chunk])
	D=[]	
	for i,b in enumerate(B):
		g.seek(offA+b[0])
		chunk=g.readString()
		D.append([i,b,chunk])
	g.seek(offA+X[23])
	E=[]
	for i in range(X[0]):
		e=g.read('>9i')
		E.append(e)
	offE=g.tell()
	indiceInfo=[]
	vertInfo=[]
	matCount=None
	off=g.tell()
	for e in E:	
		g.seek(offE)
		if e[0]==12:
			count=e[3]//80
			for i in range(count):
				vertInfo.append(g.read('>20i'))
			#	print(i,vertInfo[i])
		if e[0]==15:
			count=e[3]//24
			#for i in range(count):
			#	vertInfo.append(g.read('>6i'))
			#	print(i,vertInfo[i])
		if e[0]==52:
			count=e[3]//124
			matCount=count
			for i in range(count):
				indiceInfo.append(g.read('>31i'))
		if e[0]==66:
			count=e[3]//4
			g.read('>'+str(count)+'i')
		if e[0]==72:
			count=e[3]//16
			for i in range(count):
				g.read('>4i')
		if e[0]==140:
			count=e[3]//2
			g.read('>'+str(count)+'H')
		if e[0]==29:
			count=e[3]//64
			for i in range(count):
				NoeMat43.fromBytes(g.readBytes(64))
		if e[0]==75:
			count=e[3]//96
			for i in range(count):
				wi=g.read('>8H')
				if wi[1]==0:
					name=str(wi[2])
					parentID=-1
				else:	
					if wi[3]!=0:
						name=str(wi[1])
						parentID=-1
					else:	
						if wi[0]!=0:
							name=str(wi[0])
							parentName=str(wi[1])
						else:	
							name=str(wi[2])
							parentName=str(wi[1])
				NoeMat43.fromBytes(g.readBytes(64))
				g.read('>8H')
		if e[0]==152:
			count=e[3]//12
			for i in range(count):
				g.read('>12B')	
		if e[0]==142:
			count=e[3]//4
			for i in range(count):
				g.read('>4B')
			noeStrFromBytes(bs.readBytes(e[4]))
		if e[0]==37:
			count=e[3]
			g.read('>'+str(count)+'B')
			noeStrFromBytes(bs.readBytes(e[4]))
		if e[0]==30:
			count=e[3]//8
			for i in range(count):
				g.read('>8B')
			count=e[4]//4
			for i in range(count):
				parentID=g.i(1)[0]
		if e[0]==139:
			for i in range(e[2]/16):
				g.read('>3f')
				g.read('>i')
		if e[0]==1:
			for i in range(7):
				g.read('>40B')
		if e[0]==47:
			count=e[3]//124
			matCount=count
			for i in range(count):
				indiceInfo.append(g.read('>31i'))
		if e[0]==8:
			count=e[3]//80
			#for i in range(count):
			#	vertInfo.append(g.read('>20i'))
			#	print(i,vertInfo[i])
		if e[0]==11:
			F=[]
			count=e[3]//24
			for i in range(count):
				F.append(g.read('>6i'))
			for i in range(count):
				g.seek(F[i][0]*F[i][1],1)
					
		offE+=e[2]
	
	g.seek(off+X[10])	
	
	offE=g.tell()
	g.seek(offE+X[9])
	for i in range(X[8]):
		g.read('>3i')
	sum=0
	for i in range(X[11]):#??????????????????????????	
		sum+=g.read('>i')[0]
	list=[]
	for i in range(X[12]):
		h=g.read('>4i')
		list.append(h[1])
	
	t=g.tell()
	
	bdata=g.data[t:g.dataSize]
	g.seek(t+bdata.find(b'\x00\x00\x00\x01\x00\x02\x00'))
	vertOff=g.tell()
	indiceOff=vertOff#+12
	List=[]
	if matCount is not None:
		for i in range(matCount):
			#print (i,indiceInfo[i][18])
			g.seek(indiceOff+indiceInfo[i][20])
			idxList=g.read('>'+str(indiceInfo[i][18]//2)+'H')
			List.append(idxList)
		g.read('>2i')
		for i in range(matCount):
			#print('stream offset:',g.tell())
			
			posList=[]
			uvList=[]
			skinWeightList=[]
			skinIndiceList=[]
			for j in range(len(vertInfo)//matCount):
				t=g.tell()
				info=vertInfo[j+i*(len(vertInfo)//matCount)]
				#print(j+i*(len(vertInfo)//matCount),g.tell())
				g.seek(vertOff+info[9])
				if j==0:
					for k in range(0, info[1]):	
						posList.append(NoeVec3(g.read('>3f')))
				else:		
					if info[0]==8:
						for k in range(info[1]):
							uv=NoeVec3()
							uv[:2]=g.read('>2f')
							uvList.append(uv)
					elif info[0]==16:
						for k in range(info[1]):skinWeightList.append(g.read('>4f'))
					elif info[0]==4:
						for k in range(info[1]):skinIndiceList.append(g.read('>4B'))
					elif info[0]==12:
						for k in range(info[1]):g.seek(12,1)#12
					
			idxList=List[i]
			#print(idxList)
			material = NoeMaterial('material',texList[0].name)
			#material.setTexture(texList[0].name) 
			rapi.rpgSetMaterial(material.name)
			matList.append(material)
			mesh = NoeMesh(idxList, posList, 'model', material.name)	
			mesh.uvs=uvList
			meshList.append(mesh)
			#print('stream end:',g.tell())
			#break
		
		
	
def version26711(g):
	noeStrFromBytes(g.readBytes(4))
	X=g.read('>43i')
	A=[]
	for i in range(X[21]):
		A.append(g.read('>9i'))
	B=[]	
	for i in range(X[22]):
		B.append(g.read('>6i'))
	offA=g.tell()
	C=[]
	for i,a in enumerate(A):
		g.seek(offA+a[2])
		chunk=g.readString()
		C.append([i,a,chunk])
	D=[]	
	for i,b in enumerate(B):
		g.seek(offA+b[0])
		chunk=g.readString()
		D.append([i,b,chunk])
	g.seek(offA+X[23])
	E=[]
	for i in range(X[0]):
		e=g.read('>9i')
		E.append(e)
	offE=g.tell()
	indiceInfo=[]
	vertInfo=[]
	matCount=None
	boneCount=None
	off=g.tell()
	for e in E:	
		g.seek(offE)
		if e[0]==47:
			count=e[3]//124
			matCount=count
			for i in range(count):
				indiceInfo.append(g.read('>31i'))
		if e[0]==8:
			count=e[3]//80
			for i in range(count):
				vertInfo.append(g.read('>20i'))
		if e[0]==11:
			F=[]
			count=e[3]//24
			for i in range(count):
				F.append(g.read('>6i'))
			for i in range(count):
				g.seek(F[i][0]*F[i][1],1)
					
		offE+=e[2]
		
		
		
	g.seek(off+X[10])	
	
	offE=g.tell()
	g.seek(offE+X[9])
	for i in range(X[8]):
		g.read('>3i')
	sum=0
	for i in range(X[11]):#??????????????????????????	
		sum+=g.read('>i')[0]
	list=[]
	for i in range(X[12]):
		h=g.read('>4i')
		list.append(h[1])
		
	t=g.tell()
	bdata=g.data[t:g.dataSize]
	g.seek(t+bdata.find(b'\x00\x00\x00\x01\x00\x02\x00'))
	#print('streamData:',g.tell()) 
	vertOff=g.tell()
	indiceOff=vertOff
	if matCount is not None:
		for i in range(matCount):
			posList=[]
			uvList=[]
			skinWeightList=[]
			skinIndiceList=[]
			for j in range(len(vertInfo)//matCount):
				info=vertInfo[j+i*(len(vertInfo)//matCount)]
				if j==0:
					g.seek(vertOff+info[9])
					for j in range(0, info[1]):	
						posList.append(NoeVec3(g.read('>3f')))
				if info[0]==8:
					g.seek(vertOff+info[9])
					for k in range(info[1]):
						uv=NoeVec3()
						uv[:2]=g.read('>2f')
						uvList.append(uv)
				if info[0]==16:
					g.seek(vertOff+info[9])
					for k in range(info[1]):
						skinWeightList.append(g.read('>4f'))
				if info[0]==4:
					g.seek(vertOff+info[9])
					for k in range(info[1]):
						skinIndiceList.append(g.read('>B'))
					
			g.seek(indiceOff+indiceInfo[i][20])
			idxList=g.read('>'+str(indiceInfo[i][18]//2)+'H')	
			material = NoeMaterial('material',texList[0].name)
			#material.setTexture(texList[0].name) 
			rapi.rpgSetMaterial(material.name)
			matList.append(material)
			mesh = NoeMesh(idxList, posList, 'model', material.name)	
			mesh.uvs=uvList
			meshList.append(mesh)
	

def parsePhyre(data):	
	ctx = rapi.rpgCreateContext()
	g = NoeBitStream(data)
	g.setEndian(NOE_BIGENDIAN)
	rapi.rpgSetOption(noesis.RPGOPT_BIGENDIAN, 1)
	
	
	g.seek(0)
	noeStrFromBytes(g.readBytes(4))
	unk,version=g.read('>2i')
	print('version:',version)
	if version==3541:version3541(g)		
	elif version in [29382]:version29382(g)
	elif version in [27968]:version27968(g)		
	elif version in [26711]:version26711(g)
	elif version in [30639]:version30639(g)
	else:print ('version not supported:',version)
		
	
def noepyLoadModel(data, mdlList):
	global texList,meshList,matList,bones
	texList=[]
	meshList=[]
	matList=[]
	bones=[]
	
	noesis.logPopup()
	
	ddsPath=rapi.getInputName().replace('mdl','tex').replace('.dae','.dds')
	if (rapi.checkFileExists(ddsPath)):
		#print ('exists:',ddsPath)
		ddsData = rapi.loadIntoByteArray(ddsPath)
		parsePhyre(ddsData)
		
	parsePhyre(data)
		
	try:
		mdl = rapi.rpgConstructModel()
	except:
		mdl = NoeModel()
	mdl = NoeModel(meshList, bones, [])
	#print (texList)
	mdl.setModelMaterials(NoeModelMaterials(texList, matList))
	mdlList.append(mdl)
	rapi.setPreviewOption("setAngOfs", "0 -90 -90") 
		
	
	return 1 
		
	
