//////////////////////////////////////////////////////////////////
// Program pre extrakciu textov hry Velvet Assassin     		//	
// Copyright (c) 2009 Slappy - slappy@pobox.sk					//
// fri.uniza.sk			                						//
// Program vznikol ako pomocka pre zacinajucich prekladatelov	//
// Viac v na www.slovenciny.com / www.slovenciny.eu		        //
//////////////////////////////////////////////////////////////////
// (c) 2009 Preklad hry - Slappy - www.slovencny.com			//
//////////////////////////////////////////////////////////////////

// HLAVICKOVE SUBORY //
#include "stdafx.h"
#include <stdio.h>
#include <iostream>
#include <fstream> 
using namespace std;

// Otvori .loc subor a prevedie ho do .txt
// Vrati:
// -1: chyba!
//  0: OK
int ExtractFromLoc(char* locFile, char* txtFile)
{
	ifstream VstupnySubor(locFile,ios_base::binary);				  // .LOC subor
	ofstream VystupnySubor(txtFile, ios_base::out | ios_base::trunc); // .TXT subor

	// OTVORENIE SUBORA //
	if(!VstupnySubor.is_open())
	{
		// Nepodarilo sa otvorit subor
		cerr << "Cannot open input files!\n";
		return -1;
	}
	// Vypis...
	cout << "Extracting '" << locFile << "' >> ";
	cout << "'" << txtFile << "'...\n";

	// DEKLARACIA PREMENNYCH //
	unsigned char Znak;				// Jeden znak v subore
	unsigned int KolkoPoloziek = 0; // Pocet poloziek v subore
	unsigned int Pocet = 0;			// Aktualne spracovavana polozka
	unsigned int DlzkaID = 0;		// Dlzka identifikatora
	unsigned int DlzkaTextu = 0;	// Dlzka textu
	char* ID_TEXTU;					// Retazec - identifikator
	char* engText;					// Retazec - samotny text

	// Nacitanie hlavicky subora: znak "B"
	VstupnySubor.read((char*)&(Znak), sizeof(char));

	// Pocet poloziek v subore
	VstupnySubor.read((char*)&(KolkoPoloziek), sizeof(unsigned int));

	// HLAVNY CYKLUS //
	while(Pocet != KolkoPoloziek ) // Citame kym neprecitame tolko poloziek, kolko ich je v subore
	{
		// Vypis...
		cout << "{" << ++Pocet << "/" << KolkoPoloziek << "} ";
		
		if(Pocet == 463) 
			getchar();

		// Nacitanie ID_TEXTU
		VstupnySubor.read((char*)&(DlzkaID), sizeof(unsigned int)); // Dlzka
		ID_TEXTU = new char[DlzkaID];
		VstupnySubor.read(ID_TEXTU, DlzkaID); // Znaky
		ID_TEXTU[DlzkaID] = 0;
		cout << ID_TEXTU << endl;

		// Samotny text	
		VstupnySubor.read((char*)&(DlzkaTextu), sizeof(unsigned int)); // Dlzka
		engText = new char[DlzkaTextu]; // Znaky
		
		// Skopirovanie textu do retazca
		for(int i = 0; i!= DlzkaTextu; i++)
		{
			// Precitame 2 znaky: kvoli UNICODE kodovaniu
			VstupnySubor.read((char*)&(Znak), sizeof(char)); // 1.		
			// Osetrenie novych riadkov
			if((int)Znak == 10)
				Znak = '@';
			engText[i] = Znak;	
			VstupnySubor.read((char*)&(Znak), sizeof(char)); // 2.
		}
		engText[DlzkaTextu] = 0;

		// Zapis do subora, kazde na novy riadok
		VystupnySubor << ID_TEXTU << endl;
		VystupnySubor << engText << endl;
		// Dealokovanie pamate
		//delete ID_TEXTU;
		//delete engText;
	}

	// ZATVORIME SUBORY //
	VstupnySubor.close();
	VystupnySubor.close();

	// Vsetko prebehlo OK
	cout << "\nExtracting successfull!\n";
	return 0;
}

// Otvori .txt subor a prevedie ho do .loc
// Vrati:
// -1: chyba!
//  0: OK
int PackToLoc(char* txtFile, char* locFile)
{
	ifstream VstupnySubor(txtFile,ios_base::binary);				  // .TXT subor
	ofstream VystupnySubor(locFile, ios_base::out | ios_base::trunc); // .LOC subor

	// OTVORENIE SUBORA //
	if(!VstupnySubor.is_open() && !VystupnySubor.is_open())
	{
		// Chyba!
		cerr << "Cannot open input files!\n";
		return -1;
	}
	// Vypis...
	cout << "Packing '" << locFile << "' << ";
	cout << "'" << txtFile << "'...\n";


	// DEKLARACIA PREMENNYCH //
	char* Znak = new char[1];		// Jeden znak v subore
	char* Pole = new char[1024];    // Jeden riadok textu
	unsigned int KolkoPoloziek = 0; // Pocet poloziek v subore
	unsigned int Pocet = 0;			// Aktualne spracovavana polozka
	unsigned int DlzkaID = 0;		// Dlzka identifikatora
	unsigned int DlzkaTextu = 0;	// Dlzka textu
	char* ID_TEXTU;					// Retazec - identifikator
	char* engText;					// Retazec - samotny text

	// Zapis hlavicky subora: znak "B"
	VystupnySubor.write("B",1);

	// Pocet poloziek v subore - musi byt vzdy rovnaky!
	KolkoPoloziek = 1564;
	VystupnySubor.write((char*)&(KolkoPoloziek), sizeof(unsigned int));

	// HLAVNY CYKLUS //
	while(Pocet != KolkoPoloziek ) // Zapiseme vsetky polozky
	{
		// Vypis...
		cout << "{" << ++Pocet << "/" << KolkoPoloziek << "}\n";
		
		// Zapis identifikatora
		for(int i = 0; i!= 1024; i++)
		{
			// Nacitame cely riadok, ale maximalne 1024 znakov [malo by stacit]
			VstupnySubor.read(Znak, 1);
			if((int)Znak[0] == 13)
			{
				// Skoncime na konci riadku
				VstupnySubor.read(Znak, 1);
				Pole[i] = 0;
				DlzkaID = i;
				break;
			}
			// Osetrenie novych riadkov
			if(Znak[0] == '@')
				Znak[0] = 10;
			Pole[i] = Znak[0];			
		}
		// Zapis dlzky identifikatora
		VystupnySubor.write((char*)&(DlzkaID), sizeof(unsigned int));
		ID_TEXTU = new char[DlzkaID];
		strcpy(ID_TEXTU, Pole);
		// Zapisannie samotneho identifikatora
		VystupnySubor.write(ID_TEXTU, DlzkaID);

		// Samotny text - obsahuje aj informaciu o zvuku medzi | a |
		for(int i = 0; i!= 1024; i++)
		{
			// Nacitame cely riadok, ale maximalne 1024 znakov [malo by stacit]
			VstupnySubor.read(Znak, 1);
			if((int)Znak[0] == 13)
			{
				VstupnySubor.read(Znak, 1);
				if((int)Znak[0] == 10)
				{
					// Skoncime na konci riadku
					Pole[i] = 0;
					DlzkaTextu = i;
					break;
				}
				else
				{
					// Osetrenie nespravneho znaku
					Znak[0] = 32;
				}
			}
			// Osetrenie novych riadkov
			if(Znak[0] == '@')
				Znak[0] = 10;
			Pole[i] = Znak[0];	
		}
		// Zapis dlzky textu
		VystupnySubor.write((char*)&(DlzkaTextu), sizeof(unsigned int));
		engText = new char[DlzkaTextu*2];
		Znak[0] = '\0';
		// Zapis samotneho textu ako UNICODE retazca
		// Mala finta: staci za kazdym znakom zapisat znak '\0'
		for(int k=0; k!= DlzkaTextu; k++)
		{
			Znak[0] = Pole[k];
			VystupnySubor.write(Znak, 1);
			Znak[0] = 0;
			VystupnySubor.write(Znak, 1);
		}

	}

	// ZATVORIME SUBORY //
	VstupnySubor.close();
	VystupnySubor.close();

	// Vsetko OK
	cout << "\nPacking successfull!\n";
	return 0;
}

int main(int argc, char* argv[])
{
	// INFO O PROGRAME //
	cout << "###########################################\n";
	cout << "# Velvet Assassin .loc -> .txt converter  #\n"
		 << "# (c) 2009 Slappy (slappy@pobox.sk)       #\n" 
		 << "# www.slovenciny.com                      #\n";
	cout << "###########################################\n\n";

	// KONTROLA PARAMETROV //
	if(argc != 4)
	{
		cerr << "Wrong input format!\n";
		cerr << "Use:\n -x file.LOC file.TXT for eXtracting text from .loc !or!\n";
		cerr << " -p file.TXT file.LOC for Packing texts back to .loc\n";
		exit(1);
	}

	// Ide o extrakciu alebo zbalenie textu?
	if(strcmp(argv[1], "-x") == 0 || strcmp(argv[1], "x") == 0)
		ExtractFromLoc(argv[2], argv[3]);
	else if(strcmp(argv[1], "-p") == 0 || strcmp(argv[1], "p") == 0)
		PackToLoc(argv[2], argv[3]);
	else
	{
		// Nespravne zadane parametre!
		cerr << "Wrong input format!\n";
		cerr << "Use:\n -x file.LOC file.TXT for eXtracting text from .loc !or!\n";
		cerr << " -p file.TXT file.LOC for Packing texts back to .loc\n";
		system("PAUSE");
		exit(1);
	}
}

// Koniec subora //
