import struct
import Blender
import os
import traceback
import StringIO

import itertools
from itertools import *


"""
byte=0x2
byte = bin(byte)[2:].rjust(8, '0')
print byte
"""
# self.xorKey = [0x33, 0x56 ...]


	
def HalfToFloat(h):
	s = int((h >> 15) & 0x00000001) # sign
	e = int((h >> 10) & 0x0000001f) # exponent
	f = int(h & 0x000003ff)   # fraction

	if e == 0:
	   if f == 0:
		  return int(s << 31)
	   else:
		  while not (f & 0x00000400):
			 f <<= 1
			 e -= 1
		  e += 1
		  f &= ~0x00000400
		  #print s,e,f
	elif e == 31:
	   if f == 0:
		  return int((s << 31) | 0x7f800000)
	   else:
		  return int((s << 31) | 0x7f800000 | (f << 13))

	e = e + (127 -15)
	f = f << 13
	return int((s << 31) | (e << 23) | f)

	
def converthalf2float(h):
	id = HalfToFloat(h)
	str = struct.pack('I',id)
	return struct.unpack('f', str)[0]

	
class BinaryReader(file):
	"""general BinaryReader
	"""
	def __init__(self, inputFile):
		self.inputFile=inputFile
		self.endian='<'
		self.debug=False
		self.stream={}
		self.logfile=None
		self.log=False
		self.dirname=Blender.sys.dirname(self.inputFile.name)
		self.basename=Blender.sys.basename(self.inputFile.name).split('.')[0]
		self.ext=Blender.sys.basename(self.inputFile.name).split('.')[-1]
		self.xorKey=None
		self.xorOffset=0
		self.xorData=''
		self.logskip=False
		
	def close(self):
		self.inputFile.close()
		
	def XOR(self,data):
			self.xorData=''
			for m in range(len(data)):
				ch=ord(	chr(data[m] ^ self.xorKey[self.xorOffset])	)
				self.xorData+=struct.pack('B',ch)
				if self.xorOffset==len(self.xorKey)-1:
					self.xorOffset=0
				else:
					self.xorOffset+=1	
		
		
	def logOpen(self):	
		logDir='log'
		if os.path.exists(logDir)==False:os.makedirs(logDir)
		self.log=True
		self.logfile=open(logDir+os.sep+os.path.basename(self.inputFile.name)+'.log','w')
	def logClose(self):
		self.log=False
		if self.logfile is not None:
			self.logfile.close()
	def logWrite(self,data):
		if self.logfile is not None:
			self.logfile.write(str(data)+'\n')
		else:
			print 'WARNING: no log'
			
	def dirname(self):
		return Blender.sys.dirname(self.inputFile.name)
	def basename(self):
		return Blender.sys.basename(self.inputFile.name).split('.')[0]
	def ext(self):
		return Blender.sys.basename(self.inputFile.name).split('.')[-1]
		
		
	def q(self,n):
		offset=self.inputFile.tell()
		data=struct.unpack(self.endian+n*'q',self.inputFile.read(n*8))
		if self.debug==True:
			print 'q',data
		if self.log==True:
			if self.logfile is not None and self.logskip is not True:
				self.logfile.write('offset '+str(offset)+'	'+str(data)+'\n')
		return data
		
	def i(self,n):
		if self.inputFile.mode=='rb':
			offset=self.inputFile.tell()
			if self.xorKey is None:
				data=struct.unpack(self.endian+n*'i',self.inputFile.read(n*4))
			else:
				data=struct.unpack(self.endian+n*4*'B',self.inputFile.read(n*4))
				self.XOR(data)
				data=struct.unpack(self.endian+n*'i',self.xorData)	
					
			if self.debug==True:
				print 'i',data
			if self.log==True:
				if self.logfile is not None and self.logskip is not True:
					self.logfile.write('offset '+str(offset)+'	'+str(data)+'\n')
			return data
		if self.inputFile.mode=='wb':
			for m in range(len(n)):
				data=struct.pack(self.endian+'i',n[m])
				self.inputFile.write(data)
	
	def I(self,n):
		offset=self.inputFile.tell()
		if self.xorKey is None:
			data=struct.unpack(self.endian+n*'I',self.inputFile.read(n*4))
		else:
			data=struct.unpack(self.endian+n*4*'B',self.inputFile.read(n*4))
			self.XOR(data)
			data=struct.unpack(self.endian+n*'I',self.xorData)	
		if self.debug==True:
			print 'I',data
		if self.log==True:
			if self.logfile is not None and self.logskip is not True:
				self.logfile.write('offset '+str(offset)+'	'+str(data)+'\n')
		return data
	
	def B(self,n):
		if self.inputFile.mode=='rb':
			offset=self.inputFile.tell()
			if self.xorKey is None:
				data=struct.unpack(self.endian+n*'B',self.inputFile.read(n))
			else:
				data=struct.unpack(self.endian+n*'B',self.inputFile.read(n))
				self.XOR(data)
				data=struct.unpack(self.endian+n*'B',self.xorData)	
			if self.debug==True:
				print 'B',data
			if self.log==True:
				if self.logfile is not None and self.logskip is not True:
					self.logfile.write('offset '+str(offset)+'	'+str(data)+'\n')
			return data
		if self.inputFile.mode=='wb':
			for m in range(len(n)):
				data=struct.pack(self.endian+'B',n[m])
				self.inputFile.write(data)
	def b(self,n):
		if self.inputFile.mode=='rb':
			offset=self.inputFile.tell()
			if self.xorKey is None:
				data=struct.unpack(self.endian+n*'b',self.inputFile.read(n))
			else:
				data=struct.unpack(self.endian+n*'b',self.inputFile.read(n))
				self.XOR(data)
				data=struct.unpack(self.endian+n*'b',self.xorData)	
			if self.debug==True:
				print 'b',data
			if self.log==True:
				if self.logfile is not None and self.logskip is not True:
					self.logfile.write('offset '+str(offset)+'	'+str(data)+'\n')
			return data
		if self.inputFile.mode=='wb':
			for m in range(len(n)):
				data=struct.pack(self.endian+'b',n[m])
				self.inputFile.write(data)
	def h(self,n):
		if self.inputFile.mode=='rb':
			offset=self.inputFile.tell()
			if self.xorKey is None:
				data=struct.unpack(self.endian+n*'h',self.inputFile.read(n*2))
			else:
				data=struct.unpack(self.endian+n*2*'B',self.inputFile.read(n*2))
				self.XOR(data)
				data=struct.unpack(self.endian+n*'h',self.xorData)	
			if self.debug==True:
				print 'h',data
			if self.log==True:
				if self.logfile is not None and self.logskip is not True:
					self.logfile.write('offset '+str(offset)+'	'+str(data)+'\n')
			return data
		if self.inputFile.mode=='wb':
			for m in range(len(n)):
				data=struct.pack(self.endian+'h',n[m])
				self.inputFile.write(data)
	def H(self,n):
		if self.inputFile.mode=='rb':
			offset=self.inputFile.tell()
			if self.xorKey is None:
				data=struct.unpack(self.endian+n*'H',self.inputFile.read(n*2))
			else:
				data=struct.unpack(self.endian+n*2*'B',self.inputFile.read(n*2))
				self.XOR(data)
				data=struct.unpack(self.endian+n*'H',self.xorData)	
			if self.debug==True:
				print 'H',data
			if self.log==True:
				if self.logfile is not None and self.logskip is not True:
					self.logfile.write('offset '+str(offset)+'	'+str(data)+'\n')
			return data
		if self.inputFile.mode=='wb':
			for m in range(len(n)):
				data=struct.pack(self.endian+'H',n[m])
				self.inputFile.write(data)
	def f(self,n):
		if self.inputFile.mode=='rb':
			offset=self.inputFile.tell()
			if self.xorKey is None:
				data=struct.unpack(self.endian+n*'f',self.inputFile.read(n*4))
			else:
				data=struct.unpack(self.endian+n*4*'B',self.inputFile.read(n*4))
				self.XOR(data)
				data=struct.unpack(self.endian+n*'f',self.xorData)	
			if self.debug==True:
				print 'f',data
			if self.log==True:
				if self.logfile is not None and self.logskip is not True:
					self.logfile.write('offset '+str(offset)+'	'+str(data)+'\n')
			return data
		if self.inputFile.mode=='wb':
			for m in range(len(n)):
				data=struct.pack(self.endian+'f',n[m])
				self.inputFile.write(data)
	def d(self,n):
		if self.inputFile.mode=='rb':
			offset=self.inputFile.tell()
			if self.xorKey is None:
				data=struct.unpack(self.endian+n*'d',self.inputFile.read(n*8))
			else:
				data=struct.unpack(self.endian+n*4*'B',self.inputFile.read(n*8))
				self.XOR(data)
				data=struct.unpack(self.endian+n*'d',self.xorData)	
			if self.debug==True:
				print 'd',data
			if self.log==True:
				if self.logfile is not None and self.logskip is not True:
					self.logfile.write('offset '+str(offset)+'	'+str(data)+'\n')
			return data
		if self.inputFile.mode=='wb':
			for m in range(len(n)):
				data=struct.pack(self.endian+'d',n[m])
				self.inputFile.write(data)
	def half(self,n,h='h'):
		array = [] 
		offset=self.inputFile.tell()
		for id in range(n): 
			#array.append(converthalf2float(struct.unpack(self.endian+'H',self.inputFile.read(2))[0]))
			array.append(converthalf2float(struct.unpack(self.endian+h,self.inputFile.read(2))[0]))
		if self.debug==True:
			print 'half',array
		if self.log==True:
			if self.logfile is not None and self.logskip is not True:
				self.logfile.write('offset '+str(offset)+'	'+str(array)+'\n')
		return array
		
	def short(self,n,h='h',exp=12):
		array = [] 
		offset=self.inputFile.tell()
		for id in range(n): 
			array.append(struct.unpack(self.endian+h,self.inputFile.read(2))[0]*2**-exp)
			#array.append(self.H(1)[0]*2**-exp)
		if self.debug==True:
			print 'short',array
		if self.log==True:
			if self.logfile is not None and self.logskip is not True:
				self.logfile.write('offset '+str(offset)+'	'+str(array)+'\n')
		return array
		
	def i12(self,n):
		array = [] 
		offset=self.inputFile.tell()
		for id in range(n): 
			if self.endian=='>':
				var='\x00'+self.inputFile.read(3)
			if self.endian=='<':
				var=self.inputFile.read(3)+'\x00'
			array.append(struct.unpack(self.endian+'i',var)[0])
		if self.debug==True:
			print array
		if self.log==True:
			if self.logfile is not None and self.logskip is not True:
				self.logfile.write('offset '+str(offset)+'	'+str(array)+'\n')
		return array
	
	def find1(self,var,size=999): 
		
		start=self.inputFile.tell()
		s=''
		while(True):
			data=self.inputFile.read(size)
			off=data.find(var)
			#print off
			if off>=0:
				s+=data[:off]
				self.inputFile.seek(start+off+len(var))
				#print 'znaleziono',var,'offset=',self.inputFile.tell()
				break
			else:
				s+=data
				start+=size
			#print self.inputFile.tell()	,self.fileSize()
			if self.inputFile.tell()>=self.fileSize():break	
		if self.debug==True:
			print s
		if self.log==True:
			if self.logfile is not None and self.logskip is not True:
				self.logfile.write('offset '+str(start)+'	'+s+'\n')
		return s	
		
	def find(self,var): 
		
		start=self.inputFile.tell()
		s=''
		data=self.inputFile.read()
		off=data.find(var)
		if off>=0:
			s+=data[:off]
			self.inputFile.seek(start+off+len(var))
		if self.log==True:
			if self.logfile is not None and self.logskip is not True:
				self.logfile.write('offset '+str(start)+'	'+s+'\n')
		return s	
	
	def findAll(self,var,size=100): 
		list=[]
		while(True):
			start=self.inputFile.tell()
			data=self.inputFile.read(size)
			off=data.find(var)
			#print off,self.inputFile.tell()
			if off>=0:
				list.append(start+off)
				#print start+off
				self.inputFile.seek(start+off+len(var))
				#if self.debug==True:
				#	print start+off
			else:
				start+=size
				self.inputFile.seek(start)
			if 	self.inputFile.tell()>self.fileSize():
				break
		return list	
		
		
	def findchar(self,var):
		offset=self.inputFile.find(var)
		if self.debug==True:
			print var,'znaleziono',offset
		if self.log==True:
			if self.logfile is not None and self.logskip is not True:
				self.logfile.write(var+' znaleziono '+str(offset)+'\n')
		return offset	
		
		
	def fileSize(self):
		back=self.inputFile.tell()
		self.inputFile.seek(0,2)
		tell=self.inputFile.tell()
		#self.inputFile.seek(0)
		self.inputFile.seek(back)
		return tell
		
	def seek(self,off,a=0):
		self.inputFile.seek(off,a)
	
	def seekpad(self,pad,type=0):
		''' 16-byte chunk alignment'''
		size=self.inputFile.tell()
		seek = (pad - (size % pad)) % pad
		if type==1:
			if seek==0:
				seek+=pad
		self.inputFile.seek(seek, 1)
		
	def read(self,count):
		back=self.inputFile.tell()
		if self.xorKey is None:
			return self.inputFile.read(count)
		else:
			data=struct.unpack(self.endian+count*'B',self.inputFile.read(count))
			self.XOR(data)
			return self.xorData
			
	def unpack(values):
		"5i6hi"
		for value in values:
			if type(value)==integer:
				pass
			
	
		
	def write(self,string):
		self.inputFile.write(string)
		
	def tell(self):
		val=self.inputFile.tell()
		if self.debug==True:
			print 'current offset is',val
		return val	
		
	def word(self,long):
		if long<10000:
			if self.inputFile.mode=='rb': 
				offset=self.inputFile.tell()
				s=''
				for j in range(0,long): 
					
					
					if self.xorKey is None:
						lit =  struct.unpack('c',self.inputFile.read(1))[0]
						#data=struct.unpack(self.endian+n*'i',self.inputFile.read(n*4))
					else:
						data=struct.unpack(self.endian+'B',self.inputFile.read(1))
						self.XOR(data)
						lit=struct.unpack(self.endian+'c',self.xorData)[0]
					
						#lit =  struct.unpack('c',self.inputFile.read(1))[0]
					
					
					
					if ord(lit)!=0:
						s+=lit
				if self.debug==True:
					print s
				if self.log==True:
					if self.logfile is not None and self.logskip is not True:
						self.logfile.write('offset '+str(offset)+'	'+s+'\n')
				return s
			if self.inputFile.mode=='wb':
				#data=self.inputFile.read(long)
				self.inputFile.write(long)
			#return 0	
		else:
			if self.debug==True:
				print 'WARNING:too long'
			#return 1
		
		
		
	def s(self,long):
		if long<10000:
			if self.inputFile.mode=='rb': 
				offset=self.inputFile.tell()
				s=''
				for j in range(0,long): 
					
					
					if self.xorKey is None:
						lit =  struct.unpack('c',self.inputFile.read(1))[0]
						#data=struct.unpack(self.endian+n*'i',self.inputFile.read(n*4))
					else:
						data=struct.unpack(self.endian+'B',self.inputFile.read(1))
						self.XOR(data)
						lit=struct.unpack(self.endian+'c',self.xorData)[0]
					
						#lit =  struct.unpack('c',self.inputFile.read(1))[0]
					
					
					
					if ord(lit)!=0:
						s+=lit
				if self.debug==True:
					print s
				if self.log==True:
					if self.logfile is not None and self.logskip is not True:
						self.logfile.write('offset '+str(offset)+'	'+s+'\n')
				return s
			if self.inputFile.mode=='wb':
				#data=self.inputFile.read(long)
				self.inputFile.write(long)
			#return 0	
		else:
			if self.debug==True:
				print 'WARNING:too long'
			#return 1
		
		
	def Stream(self,stream_name,element_count,element_size):
		self.inputFile.seek(element_count*element_size,1)
		self.stream[stream_name]['offset']=offset
		self.stream[stream_name]['element_count']=element_count	
		self.stream[stream_name]['element_size']=element_size	
		
	#def getFrom(self,stream_name,)	
	
class New:
	def __init__(self,path,mode,sys):
		self.mode=mode
		self.path=path
		self.file=None
		self.sys=sys
		self.data=None
	def open(self):
		drive,tail=os.path.splitdrive(self.path)
		g=None
		
		if len(drive)==0 and len(tail)!=0:
			path=self.sys.dir+os.sep+self.sys.base+os.sep+self.path
			dirpath=os.path.dirname(path)
			if os.path.exists(dirpath)==False:
				os.makedirs(dirpath)
			
		if len(drive)!=0 and len(tail)!=0:
			dirpath=os.path.dirname(self.path)
			path=self.path
			if os.path.exists(dirpath)==False:
				os.makedirs(dirpath)
			
		self.file=open(path,self.mode)
		if self.mode=='wb':
			g=BinaryReader(self.file)
		if self.mode=='rb':
			g=BinaryReader(self.file)
		if self.mode=='w':
			g=self.file
		return g	
			
	def close(self):
		if self.file:self.file.close()
		
		
class Searcher():
	def __init__(self):
		self.dir=None
		self.list=[]
		self.part=None#ext,dir,base
		self.what=None
	def run(self):
		dir=self.dir	
		def tree(dir):
			listDir = os.listdir(dir)
			olddir = dir
			for file in listDir:
				if self.part=='ext':
					if self.what.lower() in file.lower().split('.')[-1]:				
						if os.path.isfile(olddir+os.sep+file)==True:
							self.list.append(olddir+os.sep+file)
							
				else:			
					if self.what.lower() in file.lower():				
						if os.path.isfile(olddir+os.sep+file)==True:
							self.list.append(olddir+os.sep+file)
						
				if os.path.isdir(olddir+os.sep+file)==True:
					dir = olddir+os.sep+file
					tree(dir)
		tree(dir)	
		

class Sys(object):
	def __init__(self,input):
		self.input=input.lower()
		#if os.path.exists(self.input):	
		self.dir=os.path.dirname(self.input)
		self.base=os.path.basename(self.input)
		if '.' in os.path.basename(self.input):
			self.ext=os.path.basename(self.input).split('.')[-1].lower()
			#self.base=self.base.split(self.ext)[0].replace('.','')	
		else:
			self.ext=None
		self.blendPath=Blender.Get('filename')
		self.log=False
		self.newFile=None
		
	#def new(self,path,mode):
	#	self.newFile=New(path,mode,self)
	#	g=self.newFile.open()
	#	return g
		
	#def close(self):
	#	if self.newFile:self.newFile.close()
		
	def	addDir(self,name):
		newDir=self.dir+os.sep+name
		if os.path.exists(newDir)==False:
			os.makedirs(newDir)
			
	def getFiles(self,what,part=None):
		search=Searcher()
		search.dir=self.dir
		search.what=what
		search.part=part
		search.run()
		if self.log==True:
			print 'znaleziono',len(search.list),what
		return search.list
		
		
	
	def parseFile(self,function,mode='rb',log=0):
		os.system('cls')
		if os.path.exists(self.input)==True:
			if mode=='rb':
				readFile=open(self.input,'rb')
				g=BinaryReader(readFile)
				if log==True:g.logOpen()
				try:function(self.input,g)
				except:
					fp = StringIO.StringIO()
					traceback.print_exc(file=fp)
					message = fp.getvalue()
					print message					
					values=message.split('File ')					
					lines=values[-1].replace('\n','|')
					Blender.Draw.PupMenu(lines)		
				if log==True:g.logClose()
				readFile.close()				
			if mode=='r':
				g=open(self.input,'r')
				function(self.input,g)
				g.close()
		else:
			
			Blender.Draw.PupMenu('ten plik nie istnieje'+'|'+self.input)
			
	
	def parseFiles(self,function,files,mode='rb',log=0):	
		for i,filePath in enumerate(files):
			if self.log==True:
				print 'file:',i,'from',len(files),os.path.basename(filePath)
			if mode=='rb':
				os.system('cls')
				readFile=open(filePath,'rb')
				g=BinaryReader(readFile)
				if log==True:g.logOpen()
				try:function(filePath,g)
				except:pass
				if log==True:g.logClose()
				readFile.close()
				
	def join(self,path):
		returnPath=None
		if path is not None:
			path=path.lower()
			if os.path.isabs(path)==False:
				path=os.path.relpath(path)
				split2=path.split(os.sep)	
				split1=self.dir.split(os.sep)	
				for m in range(len(split1)):				
					result1=combinations(split1,m+1)
					for item1 in result1:
						for n in range(len(split2)):				
							result2=combinations(split2,n+1)
							for item2 in result2:
								path=str(item1+item2).replace("('",'').replace("')",'').replace("', '",os.sep)
								#print path
								if os.path.exists(path)==True and split2[-1] in path:
									print path,'True'
									returnPath=path
					
				
				#returnPath=self.input.split(splitpath[0])[0]+os.sep+path
			else:			
				drive,tail=os.path.splitdrive(path)
				if len(drive)>0 and os.path.exists(path)==True:
					returnDir=path
				elif len(drive)==0:
					returnPath=os.path.normpath(self.dir+os.sep+tail)
		return returnPath
