import newGameLib
from newGameLib import *
import Blender	


def indicesToFaces(indicesList):
	StartDirection = -1
	id=0
	f1 = indicesList[id]
	id+=1
	f2 = indicesList[id]
	FaceDirection = StartDirection
	faceList=[]
	while(True):
		id+=1
		f3 = indicesList[id]
		FaceDirection *= -1
		if (f1!=f2) and (f2!=f3) and (f3!=f1):
			if FaceDirection > 0:faceList.append([(f1),(f2),(f3)])
			else:faceList.append([(f1),(f3),(f2)])
		f1 = f2
		f2 = f3
		if id==len(indicesList)-1:break
	return 	faceList
			
def mdlParser(filename,g):
	
	
	g.endian='>'
	while(True):
		A=g.i(2)
		if A[1]==0:break
		t=g.tell()
		g.word(16)
		if A[0]==2:#mesh section, 1-image section
			B=g.i(5)
			g.word(16)
			g.word(16)
			g.word(16)
			mesh=Mesh()			
			off=g.tell()
			g.seek(t+B[1])
			for m in safe(B[0]):
				mesh.vertPosList.append(g.short(3))
				mesh.vertNormList.append(g.short(3))
				mesh.vertUVList.append([])
			g.seek(off)			
			for m in safe(B[2]):
				C=g.i(19)
				tm=g.tell()
				g.seek(t+C[16])
				while(True):
					flag=g.B(1)[0]
					if flag==152:
						count=g.H(1)[0]
						for n in safe(count):
							index1,index2=g.H(2)
							u,v=g.B(1)[0],g.B(1)[0]
							mesh.vertUVList[index1]=[u,v]
					if g.tell()==t+C[15]+C[16]:break
				g.seek(t+C[18])
				while(True):
					flag=g.B(1)[0]
					if flag==152:
						list=g.H(g.H(1)[0])
						faces=indicesToFaces(list)
						mesh.faceList.extend(faces)
					if g.tell()==t+C[18]+C[17]:break
				g.seek(tm)	
			mesh.draw()			
		g.seek(t+A[1])
	g.debug=True
	g.tell()
	
def Parser(filename):
	sys=Sys(filename)
	if sys.ext=='ucp':sys.parseFile(mdlParser,'rb',log=0)
 
	
Blender.Window.FileSelector(Parser,'import','*.ucp files')
	