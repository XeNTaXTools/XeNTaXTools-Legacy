#Binary parser TalesOfFantasy_smlate

import os, sys
from .lib.ModelObject import Model3D
from .lib.StructReader import StructReader

class TalesOfFantasy_sm(Model3D):
    '''Replace 'TalesOfFantasy_sm' with a suitable name of your choice. Try to follow
    the standard: GameName_FormatExt'''
    
    def __init__(self, obj3D=None, outFile=None, inFile=None):
        
        super(TalesOfFantasy_sm,self).__init__("XAC")
        self.obj3D = obj3D
        self.inFile = inFile
        self.outFile = outFile
        
    def parse_file(self):
        '''Main parser method. Can be replaced'''
        
        meshName = "temp"
        self.create_object(meshName)
        
        numVerts = self.inFile.read_long()
        for i in range(numVerts):            
            vx, vz, vy = self.inFile.read_float(3)
            
            self.create_vertex(meshName, i)
            self.add_coords(meshName, i, [vx, vy, vz])
        
        numVerts = self.inFile.read_long()
        for i in range(numVerts):
            nx, ny, nz = self.inFile.read_float(3)
            
        numVerts = self.inFile.read_long()
        for i in range(numVerts):
            tu, tv = self.inFile.read_float(2)
            
        numVerts = self.inFile.read_long()
        for i in range(numVerts):
            self.inFile.read_float(3)
            
        numFaces =self.inFile.read_long() / 3
        for i in range(numFaces):
            v1, v2, v3 = self.inFile.read_short(3)
            self.create_face(meshName, i)
            self.add_face_verts(meshName, i, [v1, v2, v3])
def read_file(path):
    '''Read the file'''
    
    openFile = StructReader(open(path, 'rb'))
    obj = TalesOfFantasy_sm(inFile=openFile)
    obj.parse_file()
    openFile.close()
    return obj

def write_file(path):
    
    pass

def definitions():
    '''Return the header, extension, and a description of the format'''
    
    return "", "SM", "Tales of Fantasy sm"

if __name__ == '__main__':
    
    file1 = "CH_I_dizi.sm"
    read_file(file1)