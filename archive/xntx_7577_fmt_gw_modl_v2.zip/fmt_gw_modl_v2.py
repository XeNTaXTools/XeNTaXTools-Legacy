# Guild Wars - MODL viewer
# Noesis script by Dave, 2021

from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Guild Wars",".modl")
	noesis.setHandlerTypeCheck(handle, bcCheckType)
	noesis.setHandlerLoadModel(handle, bcLoadModel)
	return 1


# Check file type

def bcCheckType(data):
	bs = NoeBitStream(data)
	file_id = bs.readUInt()
	bs.readUInt()
	file_type = bs.readUInt()

	if file_id != 0x00014650:
		return 0

	elif file_type != 0x4c444f4d:
		return 0

	else:
		return 1


# Read the model data

def bcLoadModel(data, mdlList):
	bs = NoeBitStream(data)
	ctx = rapi.rpgCreateContext()

	file_end = len(data)
	chunk_start = 0x0c
	mesh_number = 0

	while chunk_start != file_end:
		bs.seek(chunk_start)
		chunk_name = bs.readBytes(4).decode("utf-8")
		chunk_size = bs.readUInt()

		if chunk_name == "MODL":								# meshes without bones
			bs.seek(chunk_start + 0x2c)
			mesh_count = bs.readUInt()
			mesh_info = bs.tell() + bs.readUInt()

			for m in range(mesh_count):
				bs.seek(mesh_info + (m * 0xa6) + 0x24)
				vert_size = bs.readUInt()
				vert_start = bs.tell() + bs.readUInt()
				face_count = bs.readUInt()
				face_data = bs.tell() + bs.readUInt()
				vert_count = bs.readUInt()
				vert_stride = int(vert_size / vert_count)

				bs.seek(vert_start)
				vertices = bs.readBytes(vert_count * vert_stride)
				bs.seek(face_data)
				faces = bs.readBytes(face_count * 2)

				rapi.rpgSetName("Mesh_" + str(mesh_number))
				rapi.rpgBindPositionBuffer(vertices, noesis.RPGEODATA_FLOAT, vert_stride)
				rapi.rpgBindUV1BufferOfs(vertices, noesis.RPGEODATA_FLOAT, vert_stride, 0x0c)
				rapi.rpgCommitTriangles(faces, noesis.RPGEODATA_USHORT, face_count, noesis.RPGEO_TRIANGLE)

				mesh_number += 1


		if chunk_name == "GEOM":								# meshes with bones
			bs.seek(chunk_start + 0x10)
			mesh_count = bs.readUInt()
			bs.readUInt()
			mesh_info = bs.tell()

			for m in range(mesh_count):
				bs.seek(mesh_info + (m * 4))
				bs.seek(bs.tell() + bs.readUInt() + 0x54)
				bs.seek(bs.tell() + bs.readUInt())
				vert_count = bs.readUInt()
				bs.readUInt()
				vert_size = bs.readUInt()
				vert_stride = int(vert_size / vert_count)
				vert_start = bs.tell() + bs.readUInt()
				face_count = bs.readUInt()
				face_start = bs.tell() + bs.readUInt()

				bs.seek(vert_start)
				vertices = bs.readBytes(vert_count * vert_stride)
				bs.seek(face_start)
				faces = bs.readBytes(face_count * 2)

				rapi.rpgSetName("Mesh_" + str(mesh_number))
				rapi.rpgBindPositionBuffer(vertices, noesis.RPGEODATA_FLOAT, vert_stride)
				rapi.rpgBindUV1BufferOfs(vertices, noesis.RPGEODATA_HALFFLOAT, vert_stride, 0x20)
				rapi.rpgCommitTriangles(faces, noesis.RPGEODATA_USHORT, face_count, noesis.RPGEO_TRIANGLE)

				mesh_number += 1

		chunk_start += chunk_size + 8

	mdl = rapi.rpgConstructModel()
	mdlList.append(mdl)

	return 1


