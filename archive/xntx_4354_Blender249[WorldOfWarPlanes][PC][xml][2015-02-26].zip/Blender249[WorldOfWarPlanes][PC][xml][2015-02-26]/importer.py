import newGameLib
from newGameLib import *
import Blender
	
import math
from math import *





class Plane:
	def __init__(self):
		self.name=None
		self.skeletonRootList=[]
		self.partList=[]

		
def partDraw(filename,g,part):
		print '-'*70
		print filename
		print
		if part.skeleton is not None:
			part.skeleton.draw()
			values=part.mountPoint.split('/')
			if len(values)==1:		
				scene = bpy.data.scenes.active
				for object in scene.objects:
					if object.getType()=='Armature':
						armature = object.getData()
						if part.mountPoint in armature.bones.keys():
							part.skeleton.object.setMatrix(armature.bones[part.mountPoint].matrix['ARMATURESPACE']*object.matrixWorld)
			if len(values)==2:		
				scene = bpy.data.scenes.active
				for object in scene.objects:
					if object.getType()=='Armature':
						if object.name==values[0]:
							armature = object.getData()
							if values[1] in armature.bones.keys():
								part.skeleton.object.setMatrix(armature.bones[values[1]].matrix['ARMATURESPACE']*object.matrixWorld)
								


		modelName=part.name		
		streamList={}
		primitivesPath=filename.lower().replace('.visual','.primitives')
		if os.path.exists(primitivesPath)==True:
			file=open(primitivesPath,'rb')
			g=BinaryReader(file)
			streamList=primitivesParser(primitivesPath,g)
			file.close()				
		print streamList.keys()	
	
	
		
		mesh=Mesh()
		mesh.TRIANGLE=True
		streamName=part.vertices
		if streamName in streamList.keys():			
			primitivesPath=filename.lower().replace('.visual','.primitives')
			if os.path.exists(primitivesPath)==True:
				file=open(primitivesPath,'rb')
				g=BinaryReader(file)
				g.seek(streamList[streamName][0])
				getStream(mesh,g)
				file.close()
				
				
		streamName=part.primitive
		if streamName in streamList.keys():			
			primitivesPath=filename.lower().replace('.visual','.primitives')
			if os.path.exists(primitivesPath)==True:
				file=open(primitivesPath,'rb')
				g=BinaryReader(file)
				g.seek(streamList[streamName][0])
				getStream(mesh,g)
				file.close()
				


				
		mesh.name=part.name
		if part.skeleton is not None:	
			mesh.BINDSKELETON=part.skeleton.name	
		for i,mat in enumerate(mesh.matList):
			if len(part.matList)-1>=i:
				if part.matList[i].diffuse is not None:
					mat.diffuse=gameDir+os.sep+part.matList[i].diffuse
		mesh.draw()		
			
			
def Parser():
	global streamList,skeleton,gameDir	
	filename=input.filename
	print
	print filename
	print 
	ext=filename.split('.')[-1].lower()	
	gameDir="E:\\World of Planes"
	
	if ext=='xml':
		plane=Plane()
		file=open(filename,'rb')
		g=BinaryReader(file)			
		root=xmlParser(filename,g)
		planeParser(filename,g,root,plane)		
		file.close()
		
		#draw parts with no parent
		for part in plane.partList:
			for state in part.stateList:
				if len(part.mountPoint)==0:
					if state.health==1.0:
						if len(state.model)>0:
							visualPath=gameDir+os.sep+state.model.replace('.model','.visual')
							if 	os.path.exists(visualPath)==True:
								file=open(visualPath,'rb')
								g=BinaryReader(file)
								root=xmlParser(visualPath,g)
								visualParser(visualPath,g,root,part)
								partDraw(visualPath,g,part)	
								file.close()
				
			
		#draw parts with  parent 
		for part in plane.partList:
			for state in part.stateList:
				if len(part.mountPoint)>0:
					itemArmature=None
					if state.health==1.0:
						if len(state.model)>0:
							visualPath=gameDir+os.sep+state.model.replace('.model','.visual')
							if 	os.path.exists(visualPath)==True:
								file=open(visualPath,'rb')
								g=BinaryReader(file)
								root=xmlParser(visualPath,g)
								visualParser(visualPath,g,root,part)
								partDraw(visualPath,g,part)	
								file.close()
										

									
		#draw sub items from parts 
		for part in plane.partList:
			#print part.ID,part.name,part.mountPoint
			for state in part.stateList:
				if len(part.mountPoint)>0:
					itemArmature=None
					if state.health==1.0:
						if len(state.model)>0:
							visualPath=gameDir+os.sep+state.model.replace('.model','.visual')
							if 	os.path.exists(visualPath)==True:								
								for item in state.subItemList:
									visualPath=gameDir+os.sep+item.model.replace('.model','.visual')
									if 	os.path.exists(visualPath)==True:
										file=open(visualPath,'rb')
										g=BinaryReader(file)
										root=xmlParser(visualPath,g)
										item.mountPoint=part.name+'/'+item.mountPoint
										item.name=os.path.basename(item.model).split('.')[0]
										visualParser(visualPath,g,root,item)
										partDraw(visualPath,g,item)	
										file.close()			
				
 
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
	
Blender.Window.FileSelector(openFile,'import','World of WarPlanes Online files: *.xml')