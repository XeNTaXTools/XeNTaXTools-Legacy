import myLibraries
from myLibraries import *
import gameParser
reload(gameParser)
from gameParser import *