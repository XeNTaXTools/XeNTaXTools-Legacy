bl_info = {
    "name": "Ninja Gaiden Sigma PS3 AFS",
    "description": "Import models for NGS PS3 version",
    "author": "chzhang316",
    "version": (0, 44),
    "blender": (2, 83, 0),
    "location": "File > Import",
    "tracker_url": "https://forum.xentax.com/viewtopic.php?f=16&t=24020",
    "category": "Import",
}

import bpy
import os
import struct


def read_afs_data(context, filepath, efflag,armdeformflag):
    global bufdata
    global effimpflag
    global rigflag
#    global findtexflag

    effimpflag = efflag
    rigflag = armdeformflag
    with open(filepath,'rb') as bufdata:   
    # would normally load the data here
        ReadFile(filepath)
        return {'FINISHED'}


# ImportHelper is a helper class, defines filename and
# invoke() function which calls the file selector.
from bpy_extras.io_utils import ImportHelper
from bpy.props import StringProperty, BoolProperty, EnumProperty
from bpy.types import Operator


class ImportSomeData(Operator, ImportHelper):
    """This appears in the tooltip of the operator and in the generated docs"""
    bl_idname = "import_ngs.afs"  # important since its how bpy.ops.import_test.some_data is constructed
    bl_label = "Import NGS .afs"

    # ImportHelper mixin class uses this
    filename_ext = ".afs"

    filter_glob: StringProperty(
        default="*.afs",
        options={'HIDDEN'},
        maxlen=255,  # Max internal buffer length, longer would be clamped.
    )

    # List of operator properties, the attributes will be assigned
    # to the class instance from the operator settings before calling.
    effflag: BoolProperty(
        name="Import Eff (type 6)",
        description="Import effect models",
        default=False,
    )
    misstexflag: BoolProperty(
        name="Find Missing Eff Texture",
        description="This is actually useless, just to remind you when turn \"Import Eff\" ON for chr_aruma or chr_s_aru, make sure the \"chr_m_vap.afs\" file is in the same location, otherwise you'll get wrong textures",
        default=True,
    )
    armdeformflag: BoolProperty(
        name="Armature Deform",
        description="So you don't need to do it yourself",
        default=True,
    )

#    type: EnumProperty(
#        name="unused Enum",
#        description="Choose between two useless items",
#        items=(
#            ('blah', "blahblah", "blahblahblah"),
#            ('blah', "blahblah", "blahblahblah"),
#        ),
#        default='blah',
#    )

    def execute(self, context):
        return read_afs_data(context, self.filepath, self.effflag,self.armdeformflag)


# Only needed if you want to add into a dynamic menu
def menu_func_import(self, context):
    self.layout.operator(ImportSomeData.bl_idname, text="Ninja Gaiden Sigma PS3 (.afs)")


def register():
    bpy.utils.register_class(ImportSomeData)
    bpy.types.TOPBAR_MT_file_import.append(menu_func_import)


def unregister():
    bpy.utils.unregister_class(ImportSomeData)
    bpy.types.TOPBAR_MT_file_import.remove(menu_func_import)

def __init__(self,idx):
    self.id = idx

def AddClass(self,classname):
    
    newclass = type(str.upper(classname),(object,),dict(__init__ = __init__,addclass=AddClass))
    try:
        listclass = getattr(self,classname)
        self.idx += 1
    except AttributeError:
        setattr(self,classname,[])
        listclass = getattr(self,classname)
        self.idx = 0
        
    new = newclass(self.idx)
    listclass.append(new)
    return new

def ReadTMCHeader(offheader):
    bufdata.seek(offheader)
    # TellPointer()
    chunkid = ReadString(bufdata.read(8))
    # print(chunkid)
    unkcode, headersize = struct.unpack('>2I',bufdata.read(8))
    secsize, count1, count2, empty = struct.unpack('>4I',bufdata.read(0x10))
    listoff = struct.unpack('>4I',bufdata.read(0x10))
    if headersize != 0x30:
        print('--------------------------------- unknown header size',hex(headersize))
    if count1 != count2:
        print('---------------------------------count1 != count2',count1,count2)
    return [count1,listoff]

def ReadList(offlist,count):
    bufdata.seek(offlist)
    listoff1 = struct.unpack('>'+str(count)+'I',bufdata.read(4*count))
    return listoff1

def WriteTexture(bufstr,offset,type,height,width):
    # print(hex(offset),'type',hex(type))
    bystr1 = b'\x44\x44\x53\x20\x7C\x00\x00\x00\x07\x10\x00\x00'
    bystr2 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x20\x00\x00\x00'
    # 0x85: big endian RGBA32 with morton swizzle
    # 0xa5: normal rgba32 without swizzle
    if type in [0x85,0xa5]:
        texbit = 0x40
        bystr3 = b'\x41\x00\x00\x00\x00\x00\x00\x00\x20\x00\x00\x00\x00\x00\xFF\x00\x00\xFF\x00\x00\xFF\x00\x00\x00\x00\x00\x00\xFF\x00\x10\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    # DXT1
    elif type == 0x86:
        texbit = 0x8
        bystr3 = b'\x04\x00\x00\x00\x44\x58\x54\x31\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x10\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    # DXT3
    elif type == 0x87:
        texbit = 0x10
        bystr3 = b'\x04\x00\x00\x00\x44\x58\x54\x33\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x10\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    # DXT5
    elif type == 0x88:
        texbit = 0x10
        bystr3 = b'\x04\x00\x00\x00\x44\x58\x54\x35\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x10\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'

    texsize = height*width*texbit//0x10
    bystrhw = struct.pack('<2I',height,width)
    bufstr.seek(offset)
    
    
    if type == 0x85:
        # raw = bufdata.read(texsize)
        listm = SwizzleMorton(height,width)
        texraw = b''
        # print('length listm',len(listm),'width',width,'height',height)
        for m in listm:
            
            # m = listm[i]
        #     if i == 0x40000:
        #         print(m)
            bufstr.seek(offset+m*4)
            # a,r,g,b = struct.unpack('4B',bufdata.read(4))
            a,b,g,r = bufdata.read(4)
            texraw += struct.pack('4B',r,g,b,a)
            # texraw += t
    # elif type = 0xa5:
    #     raw = 

        
    else:
        texraw = bufstr.read(texsize)
        
    outputraw = bystr1 + bystrhw + bystr2 + bystr3 + texraw
    return outputraw
    
def SwizzleMorton(height,width):
    listmorton = []
    scale = height // width
    if scale == 0:
        scale += 1
        singleheight = height
    else:
        singleheight = height // scale

    mortonbase = 0

    for a in range(scale):
        mortonbase = a * pow(singleheight,2)
        for h in range(singleheight):
            # listrow = []
            # print('h',h)
            for w in range(width):
                # print('w',w)
                morton = 0
                for i in range(max(h.bit_length(),w.bit_length())):
                    bitw = w >> i & 0x1
                    bith = h >> i & 0x1 
                    morton |= (bith << i+1 | bitw << i) << i
                listmorton.append(morton+mortonbase)
            # listmorton.append(listrow)
    # convertedraw = b''
    # # print(raw[0:8])
    # for i in range(height*width):
    #     morton = listmorton[i]
    # # for morton in listmorton:
    #     # print(i,morton)
    #     a,r,g,b = raw[morton*4:morton*4+4]
    #     # if morton in[0,1]:
    #         # print(a,r,g,b)
    #     convertedraw += struct.pack('4B',b,g,r,255)
    #     convertedraw += raw[morton:morton+4]
    # return convertedraw
    return listmorton

def NormInt2Float(input):
    sbitx = input >> 10 & 0x1
    if sbitx:
        intx = (input & 0x3FF ^ 0x3FF) * -1 
    else:
        intx = input & 0x3FF

    sbity = input >> 21 & 0x1
    if sbity:
        inty = (input >> 11 & 0x3FF ^ 0x3FF) * -1    
    else:
        inty = input >> 11 & 0x3FF

    sbitz = input >> 31 
    if sbitz:
        intz = (input >> 22 & 0x1FF ^ 0x1FF) * -1
    else:
        intz = input >> 22 & 0x1FF

    return [intx / 0x3FF, inty / 0x3FF, intz / 0x1FF]

def ReadString(dat):
    try:
        return str(dat,encoding='utf-8').strip(b'\x00'.decode())
    except UnicodeDecodeError:
        return str(dat,encoding='shift-jis').strip(b'\x00'.decode())

def TellPointer():
    print(hex(bufdata.tell()))



def ReadAFS(filename):
    global afs
    global ttglflag
    global modelnamelist
    global modelnamedupcount
    global checkflag
    

    modelnamelist = []
    modelnamedupcount = 1
    #header
    countfile = struct.unpack('<I',bufdata.read(4))[0]
    # print('file number: ',filenum)
    # afs = AFS(filename)
    AFS = type('AFS',(object,),dict(addclass=AddClass))
    afs = AFS()
    afs.splitname = os.path.splitext(filename)[0]
    
    list_afsfile = []
    for i in range(countfile):
        off_file,size_file = struct.unpack('<2I',bufdata.read(8))
        list_afsfile.append(off_file)
    # print(list_afsfile)
    afs.filecount = countfile
    afs.filelist = list_afsfile
    
    for i in range(countfile):
        offfile = list_afsfile[i]
        bufdata.seek(offfile)
        # TellPointer()
        
        header = bufdata.read(8)
        header2 = bufdata.read(8)
        if header2 == b'\x45\xce\xed\x39\x00\x00\x00\x00':
            print('----------------------------------------------------------------------found',i)
        # print(i,header,hex(bufdata.tell()))
         
        if header == b'TMC\x00\x00\x00\x00\x00':
            # print('TMC')
            ReadTMC(offfile)
        elif header == b'chr_dat\x00':
            ReadANM(offfile)
        elif header == b'itm_dat2':
            ReadITM(offfile)



def ReadTMC(off0):
    global modelnamedupcount
    global tmc
    
    hieflag = 0
    
    bufdata.seek(off0)
    chunkid = ReadString(bufdata.read(8))
    # TellPointer()
    # myst always 0xff000100, unk1 always 0x30, header size?
    myst, unk1 = struct.unpack('>2I',bufdata.read(8))
    size, count1, count2, empty = struct.unpack('>4I',bufdata.read(0x10))
    offsection,empty2,emytp3,empty4 = struct.unpack('>4I',bufdata.read(0x10))
    # unk2 unknown, some models are not 0x9
    unk2,unk3,unk4,unk5 = struct.unpack('>4I',bufdata.read(0x10))

    name_model = ReadString(bufdata.read(0x10))
    listunkfloat = struct.unpack('>12f',bufdata.read(0x30))
    listtypesection = struct.unpack('>'+str(count1)+'I',bufdata.read(4*count1))
    bufdata.seek(offsection+off0)
    listoffsection = struct.unpack('>'+str(count1)+'I',bufdata.read(4*count1))
    # print(listoffsection)
    
#    countdupmodel = 1
#    print(name_model,modelnamelist)
    if name_model not in modelnamelist:
        modelnamelist.append(name_model)
    else:
#        print('name duplicated')
        while True:
            name_dupmodel = name_model+ '_' + str(modelnamedupcount)
#            print('new name',name_dupmodel)
            if name_dupmodel not in modelnamelist:
#                print('proper name found')
                modelnamelist.append(name_dupmodel)
                name_model = name_dupmodel
                break
            else:
#                print('duplicated again')
                modelnamedupcount += 1
#        modelnamelist.append(name_model)
#    print(name_model)
    tmc =  afs.addclass('tmc')
    tmc.name = name_model.replace('*','#')
    tmc.effflag = 0
    # print(tmc.name)
#    if flagmodelname == 1:
#        print('----------------------------------------------------------model name:',name_model)
    for i in range(count1):
        typesec = listtypesection[i]
        offsec = listoffsection[i]
        # print(hex(offsec))
        bufdata.seek(offsec+off0)
        secid = ReadString(bufdata.read(8))
        # 80000001 MdlGeo
        # 80000002 TTG
        # 80000003 VtxLay
        # 80000004 IdxLay
        # 80000005 MtrCol
        # 80000006 MdlInfo
        # 80000010 HieLay
        # 00000000 COLLIDE
        # 00000001 OBJ_TYPE
        # 00000002 MDL_TYPE
        # 00000003 VtxBInfo
        # 00000010 AcsPack
        # 00000011 MPH_LYR
        # 00000012 OBJHIT
        # 00000013 MULTI_CL
        # 00000014 EFFSCR
        # 00000015 EXTMCOL
        # 00000020 MISCDATA
        # 00000eff EMCinfo
        if typesec == 0x80000001:
            ReadMdlGeo(offsec+off0)
        elif typesec == 0x80000002:
            ReadTTG(offsec+off0)
        elif typesec == 0x80000003:
            ReadVtxLay(offsec+off0)
        elif typesec == 0x80000004:
            ReadIdxLay(offsec+off0)
        elif typesec == 0x80000005:
            ReadMtrCol(offsec+off0)
        elif typesec == 0x80000006:
            ReadMdlInfo(offsec+off0)
        elif typesec == 0x80000010:
            hieflag = 1
            ReadHieLay(offsec+off0)
        elif typesec == 0x00000001:
            ReadOBJ_TYPE(offsec+off0)
        elif typesec == 0x00000002:
            ReadMDL_TYPE(offsec+off0)
        elif typesec == 0x00000003:
            pass
            # ReadVtxBInfo(offsec+off0)
        elif typesec == 0x00000011:
            ReadMPH_LYR(offsec+off0)
        elif typesec == 0x00000eff:
            tmc.effflag = 1
            for i in range(tmc.countobj):
                tmc.obj[i].type = 6
            

    Blenderimport(hieflag)


    
def ReadMdlGeo(off1):
    pass
    countobj,listoffsec = ReadTMCHeader(off1)
    listoff = ReadList(listoffsec[0]+off1,countobj)
    
    tmc.countobj = countobj
    
    for off in listoff:
        ReadObjGeo(off+off1)

def ReadObjGeo(off2):
    global obj

    countmtl,listoffsec = ReadTMCHeader(off2)
    ### unknumber: 9 for majority, 8 for areas and some characters, 7,6,5 for very rare cases
    ### unk2: most time 2 for characters, 0 for areas, 1 for rare cases
    ### jointflag is the same as one in MdlInfo section
    unknumber, objid, jointflag,unk2 = struct.unpack('>4I',bufdata.read(0x10))
    name_obj = ReadString(bufdata.read(0x10))

    obj = tmc.addclass('obj')
    obj.name =name_obj
    obj.weightflag = jointflag
    # obj.unkflag1 = unknumber
    ###################################################################################################
    if 0:
        print(name_obj,unknumber, objid, jointflag,unk2)

    #### mesh info
    ReadGeoDecl(listoffsec[2]+off2)

    #### material info
    listoffmtl = ReadList(listoffsec[0]+off2,countmtl)
    # print('count mtl',countmtl,'list',listoffmtl)
    for offmtl in listoffmtl:
        geomtl = obj.addclass('geomtl')
        
        bufdata.seek(offmtl+off2)
        mtlid, mtlindex, geobelong, empty = struct.unpack('>4I',bufdata.read(0x10))
        # layerflag: an unknown flag, when 0x70 there is no offset index for every layer,
        # but there are still empty-layer-like data 
        idxstart,idxsize,countlayer,layerflag = struct.unpack('>4I',bufdata.read(0x10))
        # print('countlayer',countlayer,'objbelong',geobelong,'mtlid',mtlid,geomtl.id)

        if layerflag != 0x70:
            
            listofflayer = struct.unpack('>4I',bufdata.read(0x10))
        else:
            pass
            # print('no layer offset')
            # print('------------myth24',hex(myth24))
        # myth41: unknown code-like data: i_gamov 0x23304000, mukad 0x12000000, scar 0x10008000, s_dai 0x02000000
        # myth42: something related to myth1, 0 or 1
        empty1,empty2,vtxstart,vtxcount = struct.unpack('>4I',bufdata.read(0x10))
        
        ### this is the id for MtrCol section, not mesh's material
        geomtl.mtrindex = mtlindex

        geomtl.geobelong = geobelong
        ### in NGS idx were stroed by count instead of size in NGB, means the count need to *2 to get the size
        geomtl.idxstart = idxstart
        geomtl.idxcount = idxsize
        geomtl.vtxstart = vtxstart
        geomtl.vtxcount = vtxcount

        geomtl.countlayer = countlayer
        # print('object',obj.id,'material',mtlid,geomtl.id,'belong to mesh',geobelong,'vtxcount',obj.geo[geobelong].countvtx,'vtx start',vtxstart,'vtx size',vtxcount)
#        print('object',obj.id,'material',mtlid,geomtl.id,'belong to mesh',geobelong,'vtxcount',obj.geo[geobelong].countvtx,'idx start',hex(idxstart),'idx size',hex(idxsize))

        if layerflag != 0:
            bufdata.read(0x40)
            geomtl.alphaflag = 0
            for i in range(countlayer):
                layerid,layertype,texid,unk3 = struct.unpack('>4I',bufdata.read(0x10))
                line2 = struct.unpack('>4I',bufdata.read(0x10))
                line3 = struct.unpack('>4I',bufdata.read(0x10))
                line4 = struct.unpack('>4I',bufdata.read(0x10))
                line5 = struct.unpack('>4I',bufdata.read(0x10))
                
                layer = geomtl.addclass('layer')

                layer.texid = texid
                layer.type = layertype
                # print('++++++++++++layerid',layerid)
        else:
            mythtype,myth52,myth53,myth54 = struct.unpack('>4I',bufdata.read(0x10))
            ### alphaflag: 1 when use texture with alpha channel
            ### myth62: anm related, anm texture or eff anm? 0 or 0xFF
            ### mythflag: if 0, rest part length 0x40, if 0x20,0xc0 or 0x1a, 
            alphaflag,myth62,mythflag,myth64 = struct.unpack('>4I',bufdata.read(0x10))
            # myth72: same to "alphaflag"
            myth71,myth72,myth73,myth74 = struct.unpack('>4I',bufdata.read(0x10))
            myth81,myth82,myth83,myth84 = struct.unpack('>4I',bufdata.read(0x10))
            myth91,myth92,mythflag2 = struct.unpack('>3I',bufdata.read(0xc))
            if mythflag2 == 0:
                restline = struct.unpack('>5I',bufdata.read(0x14))
            elif mythflag2 == 1:
                restline = struct.unpack('>9I',bufdata.read(0x24))
            else:
                print('------------------------------------------------')
            
            geomtl.alphaflag = alphaflag
            
            # if listofflayer[0] not in [0xb0]:
            #     if mythflag2 not in [1]:
            #         print(listofflayer,'mtlid',mtlid,hex(bufdata.tell()),'mythflag2',hex(mythflag2))
            # if countuvlayer not in [1,2,3,4]:
                # print(line3,'count uv layer',countuvlayer)
            for i in range(countlayer):
                offlayer = listofflayer[i]
                bufdata.seek(offlayer+offmtl+off2)
                layerid,layertype,texid,unk3 = struct.unpack('>4I',bufdata.read(0x10))
                
                mtl3line = struct.unpack('>12I',bufdata.read(0x30))
                mtl4line = struct.unpack('>16I',bufdata.read(0x40))
                
                layer = geomtl.addclass('layer')

                layer.texid = texid
                layer.type = layertype
                # if unk1 == 3:
                # if mtl3line[0] not in [5,3,4,0,1]:
                if mtl3line[1] not in [1,2]:
                    print('--------------------------mtl',mtlid,'layer',layerid,'unk1',unk1,'mtlindex',mtlindex,'texture',hex(texid),unk3)
                    print('----------------------------------------------------------',mtl3line)
                # print('++++++++',mtl4line)
    # TellPointer()


def ReadGeoDecl(off3):
    
    countgeo,listoffgeodecl = ReadTMCHeader(off3)

    obj.countgeo = countgeo

    # if count1 != 1:
    if 0:
        print('countmesh',countgeo,listoffgeodecl)
        # TellPointer()
    offgeodecl = ReadList(listoffgeodecl[0]+off3,countgeo)
    # print(offgeodecl)
    for offgeo in offgeodecl:
        geo = obj.addclass('geo')
        bufdata.seek(offgeo+off3)
        # TellPointer()
        # unk1 some kind of size, always 0x30;
        # unk2 mostly 1, one case 2, two cases 14 in unused.afs
        # meshid1 not equal to meshid only in unused.afs
        
        unk1,unk2,meshid,countidx = struct.unpack('>4I',bufdata.read(0x10))
        countvtx,countuv,empty1,empty2 = struct.unpack('>4I',bufdata.read(0x10))
        emptyline = struct.unpack('>4I',bufdata.read(0x10))

        
        ### from here, same data with in vtxbinfo
        ### data type: 0 coordinate; 1 weight,2 normal(int),3 vertex color?,4 ???(i_gam),6 ???,8 uv; 9,14 tangent(int)
        ### data class: 2 float32; 3 float16; 6 int; 4 byte
        meshid1,sizefvf,countline,empty3 = struct.unpack('>4I',bufdata.read(0x10))
        geo.meshid = meshid
        geo.countuv = countuv
        geo.countvtx = countvtx
        geo.fvfsize = sizefvf
        # print('meshid',meshid,'geoid',geo.id,'countuv',countuv)
        for i in range(countline):
            offstart,datatype,datacount,dataclass = struct.unpack('>4I',bufdata.read(0x10))
            vtxdata = geo.addclass('vtxdata')
            vtxdata.type = datatype
            vtxdata.dataclass = dataclass
            vtxdata.count = datacount
            vtxdata.offstart = offstart

            # print(offstart,datatype,datacount,dataclass)
        # unkline = struct.unpack('>4I',bufdata.read(0x10))
        # print(unkline)
        # TellPointer()
        
    
def ReadTTG(off1):
    global ttglflag
    global ttglcheck,checkid,ttglcheck2
    global checkflag
    # global tmc
    pass
    bufdata.seek(off1)
    # print(afs.splitname,'TTG',hex(bufdata.tell()))
    
    secname = ReadString(bufdata.read(8))
    # if afs.splitname == 'demo':
    #     bufdata.read(8)
    #     size = struct.unpack('>I',bufdata.read(4))[0]
    countttg,listoff = ReadTMCHeader(off1)
    if countttg == 0:
        return
    # print('count ttg',countttg)
    if secname == 'TTG':
        if listoff[0] == 0x40:
            countexttg,sizeexttg,unkttg1,unkttg2 = struct.unpack('>4I',bufdata.read(0x10))
        else:
            countexttg = 0

        if countexttg != 0:
            ttglflag = 1
            ttglcheck = struct.pack('>2I',countexttg,sizeexttg)
            ttglcheck2 = struct.pack('>2I',unkttg1,unkttg2)
            checkflag = 1
            checkid = tmc.id
            # print('+++++++++++++++++exttg')
        else:
            ttglflag = 0
            checkflag = 0
        
        # print(count1,listoff)
        # print(hex(unk1),hex(unk2),hex(unk3),hex(unk4))
        listoffbuffer = ReadList(listoff[0]+off1,countttg)
        bufdata.seek(listoff[2]+off1)
        # read ttg info
        for i in range(countttg):
            ttgtype,unk1,unk2,unk3,unk6,width,height,unk4,exflag,unk5 = struct.unpack('>3BIB3H2B',bufdata.read(0x10))
            empty = struct.unpack('>2I',bufdata.read(0x8))
            # TellPointer()
            ttgname = ReadString(bufdata.read(0x8))
            # if afs.splitname == 'demo':
            #     exflag = 1
            # if ttgtype not in [0x85,0x86,0x88,0x87]:
            
            # if unk1 not in [1,2,3,4,5,6,7,8,9,10,11,12]:
            # unk2 fixed 0x2, unk3 fixed 0xAA, unk5 fixed 0xE4, unk4 fixed 0x1, unk5 fixed 0
            # if unk5 not in [0]:
            # if ttgtype == 0x85:
            ttg =  tmc.addclass('ttg')
            ttg.name = ttgname
            ttg.type = ttgtype
            ttg.flag = exflag
            ttg.height = height
            ttg.width = width
            # ttg.check = 1
            ############################################
            
        # read ttg buffer within tmc
        if 0:
        # if ttgtype == 0x85:
            # print('-----------------rgba32',tmc.name,ttgname)
            # TellPointer()
            print(ttgname)
            print('tex',i,hex(ttgtype),unk1,width,height,exflag,hex(bufdata.tell()),hex(listoffbuffer[i]+off1))
        ttgdir = fpath + '/ttg/' + afs.splitname + '/' + tmc.name + '/'
#        print(ttgdir)
        tmc.ttgdir = ttgdir
        if not os.path.exists(ttgdir):
            os.makedirs(ttgdir)
            # print('ttgdir created')

        # find the exttg in within tmc by rescannig the afs file list, if the exttg still not
        # within afs of the character itself, print result
        mvapflag = 0
        if tmc.name in ['ef_ch_aruma','ef_ch_s_aru']:
            file = 'chr_m_vap.afs'
            try:
                with open(fpath+'/'+file,'rb') as misbuf:
                    chunkid = misbuf.read(4)
                    countmisfile = struct.unpack('<I',misbuf.read(4))[0]
                    
                    list_misfile = []
                    for i in range(countmisfile):
                        off_misfile,size_file = struct.unpack('<2I',misbuf.read(8))
                        list_misfile.append(off_misfile)

                    for i in range(countmisfile):
                        offafs = list_misfile[i]
                        misbuf.seek(offafs)
                        bycheck1 = misbuf.read(8)
                        bycheck2 = misbuf.read(8)
                        if bycheck1 == ttglcheck and bycheck2 == ttglcheck2:
                            # print('----------------------------texture found',i)
                            ttglflag = 0
                            offex = offafs
                            break
                    for ttg in tmc.ttg:
                    
                        offstart = offex
                        ttg.offttgl = listoffbuffer[ttg.id]

                        outputname = afs.splitname + '-' + tmc.name + '-' + str(ttg.id) + '-' + ttg.name
                        if not os.path.exists(ttgdir+outputname+'.dds'):
                            texoutraw = WriteTexture(misbuf,listoffbuffer[ttg.id]+offstart,ttg.type,ttg.height,ttg.width)
                            texf = open(ttgdir+outputname+'.dds','wb')
                            texf.write(texoutraw)
                            texf.close()
                mvapflag = 1
            except FileNotFoundError:
                pass
        if mvapflag == 0:
            if ttglflag == 1:
                for i in range(afs.filecount):
                    offafs = afs.filelist[i]
                    bufdata.seek(offafs)
                    bycheck1 = bufdata.read(8)
                    bycheck2 = bufdata.read(8)
                    if bycheck1 == ttglcheck and bycheck2 == ttglcheck2:
                        # print('----------------------------texture found',i)
                        ttglflag = 0
                        offex = offafs
                        break
                if ttglflag == 1:
                    # print('--------------------------------------------texture not found within afs',tmc.id,tmc.name,ttglcheck2)
                    offex = 0
                    # FindTex(bycheck1+bycheck2)
            
                

            for ttg in tmc.ttg:
                
                if ttg.flag == 1:
                    offstart = off1
                    
                else:
                    offstart = offex
                    ttg.offttgl = listoffbuffer[ttg.id]
                    # print('offttgl',ttg.id)
                        # print('texture existed')
                    # print(ttg.id) 
                
                outputname = afs.splitname + '-' + tmc.name + '-' + str(ttg.id) + '-' + ttg.name
                if not os.path.exists(ttgdir+outputname+'.dds'):
                    texoutraw = WriteTexture(bufdata,listoffbuffer[ttg.id]+offstart,ttg.type,ttg.height,ttg.width)
                    texf = open(ttgdir+outputname+'.dds','wb')
                    texf.write(texoutraw)
                    texf.close()
                    # print('dds created',ttg.id)

    elif secname == 'TexLay':
        ttglflag == 0
        listoffttg = ReadList(listoff[0]+off1,countttg)
        for offttg in listoffttg:
            bufdata.seek(offttg+off1)
            ttgtype,unk1,unk2,unk3,unk6,width,height,unk4,exflag,unk5 = struct.unpack('>3BIB3H2B',bufdata.read(0x10))
            # unksec[0] not 0 for a texture of i_gam
            unksec = struct.unpack('>20I',bufdata.read(0x50))
            ttgname = ReadString(bufdata.read(0x10))
            unksec2 = struct.unpack('>4I',bufdata.read(0x10))
            # offbufferstart = bufdata.tell()

            ttg =  tmc.addclass('ttg')
            ttg.name = ttgname
            # ttg.type = ttgtype
            # ttg.flag = exflag
            # ttg.height = height
            # ttg.width = width

            if ttgoutflag == 1:
                ttgdir = fpath + 'ttg/' + afs.splitname + '/' + tmc.name + '/'
                tmc.ttgdir = ttgdir
                if not os.path.exists(ttgdir):
                    os.makedirs(ttgdir)
                    # print('ttgdir created')
                else:
                    pass
                    # print('dir existed')
            
                
                outputname = afs.splitname + '-' + tmc.name + '-' + str(ttg.id) + '-' + ttgname
                if not os.path.exists(ttgdir+outputname+'.dds'):
                    
                    texoutraw = WriteTexture(offttg+off1+0x80,ttgtype,height,width)
                    texf = open(ttgdir+outputname+'.dds','wb')
                    texf.write(texoutraw)
                    texf.close()
            # TellPointer()
            # if ttgtype not in [0x86,0xa5]:
            # 0xa5 type: unknown, half size of dds1 with same res, sample: 0xff808040,0xff80803f
            #####################################################
            if 0:
                print(hex(ttgtype),unk1,unk2,unk3,hex(unk6),height,width,unk4,exflag,unk5,hex(offttg+off1+0x80))
                # print(ttgname,hex(bufdata.tell()))
                # print(unksec)
        # print('---------------------',secname)

def ReadVtxLay(off1):
    ### vtxlay match with mesh(geo) count
    countvtxlay,listoffvtxlay = ReadTMCHeader(off1)
    listoffvtxbuf = ReadList(listoffvtxlay[0]+off1,countvtxlay)
    for obj in tmc.obj:
        # print('obj',obj.name)
        for geo in obj.geo:
            meshid = geo.meshid
            offvtxbuf = listoffvtxbuf[meshid]
            
            for vtxdata in geo.vtxdata:
                # print('vtxdata',vtxdata.id)
                vtxdata.listvtxbuf = []
                # ed = '>'
                if vtxdata.dataclass == 2:
                    readtype = 'f'
                    datasize = 4
                elif vtxdata.dataclass == 3:
                    readtype = 'e'
                    datasize = 2
                elif vtxdata.dataclass == 6:
                    readtype = 'I'
                    datasize = 4
                elif vtxdata.dataclass == 4:
                    readtype = 'B'
                    datasize = 1
                
                for i in range(geo.countvtx):
                    bufdata.seek(i*geo.fvfsize+vtxdata.offstart+offvtxbuf+off1)
                    data = struct.unpack('>'+str(vtxdata.count)+readtype,bufdata.read(vtxdata.count*datasize))
                    vtxdata.listvtxbuf.append(data)
#    print('countvtxlay',countvtxlay)
    pass

def ReadIdxLay(off1):
    countidxlay,listoffidxlay = ReadTMCHeader(off1)
    listoffidxbuf = ReadList(listoffidxlay[0]+off1,countidxlay)

    for obj in tmc.obj:
        # print('obj',obj.name)
        for geomtl in obj.geomtl:
            meshid = obj.geo[geomtl.geobelong].meshid
            offidxbuf = listoffidxbuf[meshid]
            bufdata.seek(offidxbuf+off1+geomtl.idxstart*2)
            # print(hex(offidxbuf+off1+geomtl.idxstart),hex(geomtl.idxstart),hex(geomtl.idxsize))
            # TellPointer()
            geomtl.idxbuf = struct.unpack('>'+str(geomtl.idxcount)+'H',bufdata.read(geomtl.idxcount*2))
            # print('obj',obj.id,'mtl',geomtl.id,'meshid',meshid)

            pass
            # offidxbuf = 

#    print('countidxlay',countidxlay)
    pass

def ReadMtrCol(off1):
    countmtr,listoffmtrcol = ReadTMCHeader(off1)
    listoffmtr = ReadList(listoffmtrcol[0]+off1,countmtr)
    for i in range(countmtr):
        offmtr = listoffmtr[i]
        bufdata.seek(offmtr+off1)
        # TellPointer()
        Rdif,Gdif,Bdif,Adif = struct.unpack('>4f',bufdata.read(0x10))
        Ramb,Gamb,Bamb,Aamb = struct.unpack('>4f',bufdata.read(0x10))
        Rspe,Gspe,Bspe,Aspe = struct.unpack('>4f',bufdata.read(0x10))
        Remm,Gemm,Bemm,Aemm = struct.unpack('>4f',bufdata.read(0x10))
        specularpower,unkcolor,unkcol2,unkcol3 = struct.unpack('>4f',bufdata.read(0x10))
        mtrid,countobj = struct.unpack('>2I',bufdata.read(0x8))
        # print('----------------------------------------------material number',i,mtrid,countobj)
        if afs.splitname == 'chr_i_gam' and tmc.name == 'gamgr_1':
            pass
        elif afs.splitname == 'chr_mukad':
            pass
        elif afs.splitname == 'chr_scar' and tmc.name == 'swm_blt':
            pass
        elif afs.splitname == 'chr_s_dai' and tmc.name == 'sdai_blt_1':
            pass
        else:
            for j in range(countobj):
                # mtrflag: unknown, 2 for effect
                objid,mtrflag = struct.unpack('>2I',bufdata.read(0x8))
                # if mtrflag not in [1,2,3]:
                if 0:
                    print('-------------------object',objid,'material statues',mtrflag,afs.splitname,tmc.name)
        
    pass
    # count1,listoff = ReadTMCHeader(off1)
    # print(count1,listoff)

    
def ReadMdlInfo(off1):
    countmdlinfo,listmdlinfo = ReadTMCHeader(off1)
    listoffmdlinfo = ReadList(listmdlinfo[0]+off1,countmdlinfo)
    for i in range(countmdlinfo):
        offmdlinfo = listoffmdlinfo[i]
        countobjinfo,listobjinfo = ReadTMCHeader(offmdlinfo+off1)
        ### jointflag is the same as "countvtxweight" in ObjGeo section
        unk1,objid,unk2,jointflag = struct.unpack('>4I',bufdata.read(0x10))
        # unk5 empty
        unk4,unk5,unk6,unk7 = struct.unpack('>4I',bufdata.read(0x10))
        # unk10, unk11 empty
        unk8,unk9,unk10,unk11 = struct.unpack('>4I',bufdata.read(0x10))
        line456 = struct.unpack('>12f',bufdata.read(0x30))
        if jointflag == 2:
            # exline tells which 2 bones the joint is connected with
            bone1,bone2,empty1,empty2 = struct.unpack('>4I',bufdata.read(0x10))
            tmc.obj[i].weightgroup = [bone1,bone2]
            # print(i,exline)
        # print('-----------------------object',i)
        # if unk1 not in [9,6,3]:
        # if unk4 not in [0,1]:
        # if unk7 not in [1,2,4,6,7,8,10,14,16,26]:
        # if unk8 not in [0,1]:
        # if unk9 not in [0,1,2,3,6,7]:

        listoffobjinfo = ReadList(listobjinfo[0]+offmdlinfo+off1,countobjinfo)
        for offobjinfo in listoffobjinfo:
            bufdata.seek(offobjinfo+offmdlinfo+off1)
            mtlid,unkmtl1,unkmtl2,unkmtl3 = struct.unpack('>4I',bufdata.read(0x10))
            ### unkmtl6,unkmyl7 are empty
            unkmtl4,unkmtl5,unkmtl6,unkmtl7 = struct.unpack('>4I',bufdata.read(0x10))
            mtlline345 = struct.unpack('>12f',bufdata.read(0x30))
            # if unkmtl1 not in [1,0]:
            # if unkmtl2 not in [1,2,4,8,16]:
            # if unkmtl3 not in [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,17,20,21,22,23,24,25]:
            # if unkmtl4 not in [0,1] :  
            # if unkmtl5 not in [0,1,2,4]:
            # if unkmtl7 not in [0]:
                # print('--------------',unkmtl4,unkmtl5,unkmtl6,unkmtl7)

        

        # print(line456)
        # if unk11 not in [0]:
            # print('---------------',unk8,unk9,unk10,unk11)

    pass
    # count1,listoff = ReadTMCHeader(off1)
    # print(count1,listoff)

def ReadHieLay(off1):
    counthie,listoffheader = ReadTMCHeader(off1)
    
    bufdata.seek(listoffheader[2]+off1)
    countbase,empty1,epmty2,empty3 = struct.unpack('>4I',bufdata.read(0x10))
    listbase = struct.unpack('>'+str(countbase)+'I',bufdata.read(countbase*4))

    tmc.listbase = listbase
    tmc.countbase = countbase

    listoffhie = ReadList(listoffheader[0]+off1,counthie)
    
    
    for offhie in listoffhie:
        bufdata.seek(offhie+off1)
        # matrix 4x4
        line1 = struct.unpack('>4f',bufdata.read(0x10))
        line2 = struct.unpack('>4f',bufdata.read(0x10))
        line3 = struct.unpack('>4f',bufdata.read(0x10))
        locx,locy,locz,mtx44 = struct.unpack('>4f',bufdata.read(0x10))
        parentid,countconnect,unk1,unk2 = struct.unpack('>4I',bufdata.read(0x10))
        listconnect = struct.unpack('>'+str(countconnect)+'I',bufdata.read(countconnect*4))
        
        hie = tmc.addclass('hie')
        hie.loc = [locx,locz*-1,locy]
        hie.countconnect = countconnect
        hie.parentid = parentid
        hie.listconnect = listconnect
        
        if 0:
            print('------------------',hex(parentid),countconnect,unk1,unk2)
            print(listconnect)
    # count1,listoff = ReadTMCHeader(off1)
    # print(count1,listoff)

def ReadOBJ_TYPE(off1):
    #### do not fit the general header format
    bufdata.seek(off1)
    chunkid = ReadString(bufdata.read(0x10))
    # print(chunkid)
    # unk1,unk2 fixed 0x2
    unk1,size,unk2,empty1 = struct.unpack('>4I',bufdata.read(0x10))
    # unk4 fixed 0x7
    offsec1,countofftype,offsec2,countobj,offsec3,empty2,empty3,empty4 = struct.unpack('>8I',bufdata.read(0x20))
    # print(unk4,unk5,unk6,unk7)
    ### type section 1
    listofftype = ReadList(offsec1+off1,countofftype)
    for offtype in listofftype:
        bufdata.seek(offtype+offsec1+off1)
        typeobj,counttype = struct.unpack('>2I',bufdata.read(0x8))
        listobj = struct.unpack('>'+str(counttype)+'I',bufdata.read(counttype*4))
        # print('obj type',typeobj,'count',counttype,listobj)
    ### type section 2
    listsec2 = ReadList(offsec2+off1,countobj)
    for i in range(tmc.countobj):
        tmc.obj[i].type = listsec2[i]
    # print(listsec2)
    ### type section 3
    listoffsec3 = ReadList(offsec3+off1,countobj)
    for offs3 in listoffsec3:
        bufdata.seek(offs3+offsec3+off1)
        # unk4 fixed 0x10
        unk3,unk4,unk5,empty = struct.unpack('>4I',bufdata.read(0x10))
        # if unk3 not in [0,1,2,4,5,6,8,9,11]:
        # if unk5 not in[0,4,12,80]:


def ReadMDL_TYPE(off1):
    pass
    #### do not fit the general header format
    # count1,listoff = ReadTMCHeader(off1)
    # print(count1,listoff)

def ReadVtxBInfo(off1):
    pass
    count1,listoffsec = ReadTMCHeader(off1)
    unk1,unk2,unk3,unk4 = struct.unpack('>4I',bufdata.read(0x10))
    if unk4 != 0x0:
        print('---------',hex(unk1),hex(unk2),hex(unk3),hex(unk4))
    # print(count1,listoffsec)
    listoff = ReadList(listoffsec[0]+off1,count1)
    for off in listoff:
        bufdata.seek(off+off1)
        numbermesh, sizefvf, countsecline, headersize = struct.unpack('>4I',bufdata.read(0x10))
        unkline2 = struct.unpack('>4I',bufdata.read(0x10))
        # data type: 0 coordinate; 1 weight,2 normal(int),3 vertex color?,4 ???(i_gam),6 ???,8 uv; 9,14 tangent(int)
        # data class: 2 float32; 3 float16; 6 int; 4 byte
        # print(numbermesh, sizefvf, countsecline, hex(headersize),unkline2[0])
        for i in range(countsecline):
            offstart, datatype, datacount, dataclass = struct.unpack('>4I',bufdata.read(0x10))
            # if dataclass not in [2,3,6,4]:
            # if datatype == 4:
            if 0:
                print(numbermesh, sizefvf, countsecline, hex(headersize),unkline2[0])
                # print('data start',offstart,'type',datatype,'count',datacount,'class',dataclass)
                
        if headersize != 0x20:
            
            print(unkline2)

    # print(listoff)


def ReadMPH_LYR(off1):
    ### header check, in case of unexpected alternate header like TTG section
    # bufdata.seek(off1)
    # chunkid = ReadString(bufdata.read(0x8))
    # if chunkid != 'MtrCol':
    #     print('------------------',chunkid)
    pass
    # count1,listoff = ReadTMCHeader(off1)
    # print(count1,listoff)

def ReadANM(off0):
    pass

def ReadITM(off0):
    pass



def Blenderimport(hieflag):
    global bpy
    global bmesh
    global mathutils
    import bpy
    import bmesh
    import mathutils
    
    global afsname
    global tmcname
    global coltmc
    global arm,obarm
#    global effflag
    
    listimp = [0,1,4,5]
    if effimpflag == 1:
        listimp.append(6)
    
    afsname = afs.splitname
    col = bpy.data.collections
#    print('-----afs',afsname)
    if afsname not in col:
        colafs = bpy.data.collections.new(afsname)
        bpy.context.scene.collection.children.link(colafs)
    else:
        colafs = col[afsname]
    
    if not (tmc.effflag == 1 and effimpflag == 0):
        tmcname = tmc.name
    #    print('+++++kmd',kmdname) 
        coltmc = bpy.data.collections.new(tmcname)
        colafs.children.link(coltmc)
        
        if hieflag == 1:
            for baseid in tmc.listbase:
                if tmc.obj[baseid].type in listimp:
                    armname = afsname+'-'+tmcname+'-'+'armature'+'-'+str(baseid)
                    
                    arm = bpy.data.armatures.new(armname)
                    obarm = bpy.data.objects.new(armname,arm)
                    coltmc.objects.link(obarm)
                    bpy.context.view_layer.objects.active = obarm
                    bpy.ops.object.mode_set(mode='EDIT')
                    
                    BuildHie(baseid)
                    bpy.ops.object.mode_set(mode='OBJECT')
    
            
def BuildHie(boneid):
    
    hie = tmc.hie[boneid]
#    print('---------build bone',boneid,'parent',hex(hie.parentid),hie.listconnect)
#    if len(hie.listconnect) == 0 or hie.parentid == 0xFFFFFFFF:
    if tmc.obj[boneid].weightflag == 0:
        boneflag = 1
        bonename = afsname+'-'+tmcname+'-'+str(boneid)
        bone = arm.edit_bones.new(bonename)
        
    else:
        boneflag = 0
        
    
    if hie.parentid == 0xFFFFFFFF:
        parentflag = 0
        bone.head =  mathutils.Vector(hie.loc)
        bone.tail = bone.head
        bone.tail.z += 0.1
    else:
        parentflag = 1
        if boneflag == 1:
            parentbonename = afsname+'-'+tmcname+'-'+str(hie.parentid)
            parentbone = arm.edit_bones[parentbonename]
            bone.parent = parentbone
            bone.head = parentbone.head + mathutils.Vector(hie.loc)
            bone.tail = bone.head
            bone.tail.z += 0.1
        
    BuildObject(boneid)
#    print('parentflag',parentflag,'boneflag',boneflag)
    bonestr = afsname + '-' + tmcname + '-' + str(boneid) + '-'
    for object in coltmc.objects:
        if bonestr in object.name:
#            if parentflag == 1:
            if boneflag == 0:
                bonename = afsname+'-'+tmcname+'-'+str(hie.parentid)
                
            else:
                bonename = afsname+'-'+tmcname+'-'+str(boneid)
#            print(bonename)
            bone = arm.edit_bones[bonename]
            object.location = bone.head

                
#            print('------before',object.location,hie.loc)
            if boneflag == 0:
                object.location += mathutils.Vector(hie.loc)
            ### add weight, but need to test if it's possible to add weight
            ### directly in bmesh
            obj = tmc.obj[boneid]
            geoid = int(object.name[-1])
#            print(object.name,geoid)
            geo = obj.geo[geoid]
            if obj.weightflag == 0:
                groupname = afsname+'-'+tmcname+'-'+str(boneid)
                object.vertex_groups.new(name=groupname)
                
                for i in range(geo.countvtx):
                    object.vertex_groups[groupname].add([i],1,'REPLACE')
            elif obj.weightflag == 2:
                group1name = afsname+'-'+tmcname+'-'+str(obj.weightgroup[0])
                group2name = afsname+'-'+tmcname+'-'+str(obj.weightgroup[1])
                object.vertex_groups.new(name=group1name)
                object.vertex_groups.new(name=group2name)
                
                for i in range(geo.countvtx):
                    for vtxdata in geo.vtxdata:
                        if vtxdata.type == 1:
                            weight1 = vtxdata.listvtxbuf[i][0]
                            weight2 = vtxdata.listvtxbuf[i][1]
                            object.vertex_groups[group1name].add([i],weight1,'REPLACE')
                            object.vertex_groups[group2name].add([i],weight2,'REPLACE')
            if rigflag == 1:
                object.modifiers.new(name = 'Armature', type = 'ARMATURE')
                object.modifiers['Armature'].object = obarm
                object.parent = obarm
#            print(object.name,object.location)

            

            
    for childid in hie.listconnect:
        BuildHie(childid)
            

def BuildObject(objid):
    obj = tmc.obj[objid]
#        print(obj.name)
    for i in range(obj.countgeo):
#        for i in [0]:
        geo = obj.geo[i]
        me = bpy.data.meshes.new(afsname+'-'+tmcname+'-'+str(obj.id)+'-'+obj.name+'-'+str(geo.id))
        ob = bpy.data.objects.new(afsname+'-'+tmcname+'-'+str(obj.id)+'-'+obj.name+'-'+str(geo.id),me)
        coltmc.objects.link(ob)
    
        bm = bmesh.new()       
        geo.smoothflag = 0
        for j in range(geo.countvtx):
            for vtxdata in geo.vtxdata:
                if vtxdata.type == 0:
                    corx = vtxdata.listvtxbuf[j][0]
                    cory = vtxdata.listvtxbuf[j][1]
                    corz = vtxdata.listvtxbuf[j][2]
                    vert = bm.verts.new([corx,corz*-1,cory])
        
                elif vtxdata.type == 2:
                    geo.smoothflag = 1
                    normx,normy,normz = NormInt2Float(vtxdata.listvtxbuf[j][0])
                    vert.normal = mathutils.Vector([normx,normz*-1,normy])
##############################            
        bm.verts.ensure_lookup_table()
        ### faces,materials part
        matid = 0
        for geomtl in obj.geomtl: 
            if geomtl.geobelong == i:
                ### creat uv layers
                for layer in geomtl.layer:
                    layername = 'UV'+'-'+str(layer.id)     
                    if layername not in bm.loops.layers.uv:
                        uv_layer = bm.loops.layers.uv.new(layername)
                    layer.name = layername
                ### import face,uv data
                cw = False
                for k in range(geomtl.idxcount):      
                    if geomtl.idxbuf[k] == 0xffff:
                        cw = False
                        continue
                    else:
                        try:
                            if not cw:
                                idxa = k
                                idxb = k+1
                                idxc = k+2
                            else:
                                idxa = k
                                idxb = k+2
                                idxc = k+1               
                            face = bm.faces.new((bm.verts[geomtl.idxbuf[idxa]],bm.verts[geomtl.idxbuf[idxb]],bm.verts[geomtl.idxbuf[idxc]]))
                            ### convert uv coordinate from vtxbuf
                            for numuv in range(geo.countuv):
                                if numuv in [0,1]:
                                    uvtype = 8
                                elif numuv in [2,3]:
                                    uvtype = 9
                                for vtxdata in geo.vtxdata:
                                    if vtxdata.type == uvtype:
                                        listuv = vtxdata.listvtxbuf
                                        ### it's a little complex here as u and v are not converted yet
                                        f = 0
                                        for idx in [idxa,idxb,idxc]:
                                            ### layer 0 and 2, coors are [0] and [1] of each vtxbuf list
                                            if numuv in [0,2]:
                                                uvu = listuv[geomtl.idxbuf[idx]][0]
                                                uvv = listuv[geomtl.idxbuf[idx]][1]
                                            ### layer 1 and 3, [2][3] instead 
                                            elif numuv in [1,3]:
                                                uvu = listuv[geomtl.idxbuf[idx]][2]
                                                uvv = listuv[geomtl.idxbuf[idx]][3]
                                            cooruv = [uvu,1-uvv]
                                            uvlayername = geomtl.layer[numuv].name
                                            uvlayer = bm.loops.layers.uv[uvlayername]
                                            face.loops[f][uvlayer].uv = cooruv
                                            f+=1
                                            
                        except IndexError:
                            cw = not cw
                            continue
                        except ValueError:
                            cw = not cw
                            continue
                        cw = not cw
                        
                        face.material_index = matid
                            
        #                            print(face.smooth)
                        if geo.smoothflag == 1:
                            face.smooth = True
#                            print(face.smooth)
### solution: set a id for materials within each geo, using this method, when joining
### all the parts, the model still display the material correctly (not fully tested)
                matid += 1
                #### creat material
#                    matname = afsname+'-'+tmcname+'-'+str(geomtl.mtrindex)+'-'+str(geomtl.layer[0].texid)
#                    matname = afsname+'-'+tmcname+'-'+str(geomti.id)+'-'+str(geomtl.layer[0].texid)
                matname = afsname+'-'+tmcname+'-'+str(geomtl.layer[0].texid)+'-'+str(geomtl.id)
                material = bpy.data.materials
                if matname in material:
                    mtl = bpy.data.materials[matname]
                else:
                    mtl = bpy.data.materials.new(matname)
                
                    mtl.use_nodes = True
                    nodes = mtl.node_tree.nodes
                    links = mtl.node_tree.links
                    bsdf = nodes['Principled BSDF']
                    for layer in geomtl.layer:
                        texid = layer.texid
    #                    print('object',obj.id,'mesh',geo.meshid,'layer',layer.id,'tex',texid)
                        if texid != 0xffffffff:
                            nodeTex = nodes.new(type='ShaderNodeTexImage')
                            nodeTex.location = (-500,300+layer.id*-300)
                            
                            nodeUVMap = nodes.new(type='ShaderNodeUVMap')
                            nodeUVMap.location = (-700,100+layer.id*-300)
                            nodeUVMap.uv_map = layer.name
                            
                            texpath = fpath + '/ttg/'+afsname+'/'+tmcname+'/'
                            texname = afsname+'-'+tmcname+'-'+str(texid)+'-'+tmc.ttg[texid].name+'.dds'
                            images = bpy.data.images
                            if texname not in images:
                                img = bpy.data.images.load(texpath+texname)
                            if texname != nodeTex.image:
                                nodeTex.image = images[texname]
                            if layer.id == 0:
                                links.new(nodeTex.outputs['Color'], bsdf.inputs['Base Color'])
                                links.new(nodeTex.outputs['Alpha'], bsdf.inputs['Alpha'])
                            links.new(nodeUVMap.outputs['UV'],nodeTex.inputs['Vector'])
                    if geomtl.alphaflag == 1:
                        pass
                        mtl.blend_method = 'BLEND'
                    mtl.show_transparent_back = False
                me.materials.append(mtl)
#                    mtl.use_backface_culling = True
        
        
        bm.to_mesh(me)
        bm.free

# main
def ReadFile(filepath):
    
    global fpath
    
    fpath,file = os.path.split(filepath)
    
    chunkid = bufdata.read(4)
    if chunkid == b'AFS\x00':
        ReadAFS(file)
        




if __name__ == "__main__":
    register()

    # test call
    bpy.ops.import_ngs.afs('INVOKE_DEFAULT')
