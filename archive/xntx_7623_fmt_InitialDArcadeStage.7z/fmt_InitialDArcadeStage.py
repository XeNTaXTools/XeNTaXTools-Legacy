from inc_noesis import *
import noesis
import rapi
import binascii


def registerNoesisTypes():
    handle = noesis.register("Initial D", ".efo")
    noesis.setHandlerTypeCheck(handle, efoCheckType)
    noesis.setHandlerLoadModel(handle, efoLoadModel)

    #noesis.logPopup()
    return 1


NOEPY_HEADER = "YABX"

def efoCheckType(data):
    bs = NoeBitStream(data)
    if len(data) < 4:
        return 0
    if bs.readBytes(4).decode("ASCII").rstrip("\0") != NOEPY_HEADER:
        return 0
    return 1


class SHAPE:
    def __init__(self):
        self.shapeName = ""
        self.geomName = ""

        self.buffer = None
        self.shader = None

        # _sSerial::_sPrimitiveList
        self.primitiveType = 0
        self.primitiveNumber = 0
        self.indexStart = 0
        self.indexNumber = 0
        self.startNumber = 0
        self.endNumber = 0
        self.vertexNumber = 0

        self.subBuffers = []


class BUFFER:
    def __init__(self):
        self.buffer = None
        self.bufferName = None

        # _sSerial::_sGeometry
        self.vertexDesc = 0
        self.vertexNumber = 0
        self.vertexSize = 0
        self.strideSize = 0
        self.vertexArray = 0
        self.userVertexArray = 0
        self.userVertexArrayElementNumber = 0
        self.flag = 0

class SHADER:
    def __init__(self):
        self.shaderName = ""
        self.materialName = ""
        self.textures = []

        self.fillType = 0
        self.alphaRef = 0

        self.depthTest = 0
        self.depthBias = 0
        self.depthBiasRate = 0
        self.depthBiasSlope = 0

        self.cullMode = 0
        self.lightingModel = 0
        self.maxInfluence = 0
        self.uvSet = 0

        self.blendMode = 0
        self.blendSrc = 0
        self.blendDst = 0

        self.shininess = 0
        self.opacity = 0
        self.ambient = 0
        self.diffuse = 0
        self.specular = 0
        self.emission = 0
        self.constant = 0

        self.shaderDesc = 0
        self.extrashaderDesc = 0

        self.shaderParameter0 = 0
        self.shaderParameter1 = 0


class TEXTURE:
    def __init__(self):
        self.textureName = ""
        self.dds = None


class DDS:
    def __init__(self):
        self.ddsName = ""

        self.height = 0
        self.width = 0

        self.fourCC = 0

        self.buffer = None


class SKELETON:
    def __init__(self):
        self.boneList = []


class BONE :
    def __init__(self):
        self.boneName = ""
        self.index = 0

        self.parentName = 0

        self.parentIndex = 0
        self.blendIndex = 0
        self.shapeHeaderIndex = 0

        self.parent = 0
        self.child = 0
        self.sibling = 0

        self.boneMatrix = None


class DDSPixelFormat :
    def __init__(self):
        self.size = 0
        self.flags = 0
        self.fourCC = 0
        self.RGBBitCount = 0
        self.RBitMask = 0
        self.GBitMask = 0
        self.BBitMask = 0
        self.ABitMask = 0

# EFO

class efoFile:
    def __init__(self, bs):
        self.bs = bs

        self.boneList = []
        self.texList = []
        self.matList = []

    def load(self, bs):
        self.header = efoHeader(self.bs)
        if "_sSerial::_sShapeHeader" in self.header._sSerial: # TEST
            self.shape = efoShape(self.bs, self.header)
            self.skeleton = efoSkeleton(self.bs, self.header, self.boneList)
            print(self.bs.tell())

            self.buildModel()
            self.buildSkeleton()
        else:
            self.loadTextures(len(self.header.ddsSignatures))

    def buildModel(self):
        for shape in self.header.shapeDictionary.values():
            print(shape.buffer.strideSize)

            rapi.rpgSetName(shape.geomName)

            # Set textures
            if len(shape.shader.textures) != 0:
                texFmt = None
                if shape.shader.textures[0].dds.fourCC == 827611204:
                    texFmt = noesis.NOESISTEX_DXT1
                elif shape.shader.textures[0].dds.fourCC == 894720068:
                    texFmt = noesis.NOESISTEX_DXT5
                else:
                    texFmt = noesis.NOESISTEX_RGBA32

                texture = NoeTexture(shape.shader.textures[0].dds.ddsName, shape.shader.textures[0].dds.width, shape.shader.textures[0].dds.height, shape.shader.textures[0].dds.buffer, texFmt)
                self.texList.append(texture)

            # Set material
            rapi.rpgSetMaterial(shape.shader.materialName)
            material = NoeMaterial(shape.shader.materialName, "")
            if len(shape.shader.textures) != 0:
                material.setTexture(shape.shader.textures[0].dds.ddsName)
            self.matList.append(material)

            # Set vertex
            if shape.buffer.strideSize == 12:
                rapi.rpgBindPositionBufferOfs(shape.buffer.buffer, noesis.RPGEODATA_FLOAT, 12, 0)
                rapi.rpgBindNormalBufferOfs(bytes(len(shape.buffer.buffer)), noesis.RPGEODATA_FLOAT, 12, 0)
                rapi.rpgBindUV1BufferOfs(bytes(len(shape.buffer.buffer)), noesis.RPGEODATA_FLOAT, 12, 0)
            elif shape.buffer.strideSize == 16:
                rapi.rpgBindPositionBufferOfs(shape.buffer.buffer, noesis.RPGEODATA_FLOAT, 16, 0)
                rapi.rpgBindNormalBufferOfs(bytes(len(shape.buffer.buffer)), noesis.RPGEODATA_FLOAT, 12, 0)
                rapi.rpgBindUV1BufferOfs(bytes(len(shape.buffer.buffer)), noesis.RPGEODATA_FLOAT, 16, 0)
            elif shape.buffer.strideSize == 20:
                rapi.rpgBindPositionBufferOfs(shape.buffer.buffer, noesis.RPGEODATA_FLOAT, 20, 0)
            elif shape.buffer.strideSize == 24:
                rapi.rpgBindPositionBufferOfs(shape.buffer.buffer, noesis.RPGEODATA_FLOAT, 24, 0)
                rapi.rpgBindNormalBufferOfs(shape.buffer.buffer, noesis.RPGEODATA_BYTE, 24, 12)
                rapi.rpgBindUV1BufferOfs(shape.buffer.buffer, noesis.RPGEODATA_FLOAT, 24, 0)
            elif shape.buffer.strideSize == 28:
                rapi.rpgBindPositionBufferOfs(shape.buffer.buffer, noesis.RPGEODATA_FLOAT, 28, 0)
                rapi.rpgBindNormalBufferOfs(shape.buffer.buffer, noesis.RPGEODATA_FLOAT, 28, 12)
                rapi.rpgBindUV1BufferOfs(shape.buffer.buffer, noesis.RPGEODATA_FLOAT, 28, 20)
            elif shape.buffer.strideSize == 32:
                rapi.rpgBindPositionBufferOfs(shape.buffer.buffer, noesis.RPGEODATA_FLOAT, 32, 0)
                rapi.rpgBindNormalBufferOfs(shape.buffer.buffer, noesis.RPGEODATA_FLOAT, 32, 12)
                rapi.rpgBindUV1BufferOfs(shape.buffer.buffer, noesis.RPGEODATA_FLOAT, 32, 24)
            elif shape.buffer.strideSize == 36:
                rapi.rpgBindPositionBufferOfs(shape.buffer.buffer, noesis.RPGEODATA_FLOAT, 36, 0)
                rapi.rpgBindNormalBufferOfs(shape.buffer.buffer, noesis.RPGEODATA_FLOAT, 36, 12)
                rapi.rpgBindUV1BufferOfs(shape.buffer.buffer, noesis.RPGEODATA_FLOAT, 36, 28) # 24 for character
            elif shape.buffer.strideSize == 40:
                rapi.rpgBindPositionBufferOfs(shape.buffer.buffer, noesis.RPGEODATA_FLOAT, 40, 0)
            elif shape.buffer.strideSize == 44:
                rapi.rpgBindPositionBufferOfs(shape.buffer.buffer, noesis.RPGEODATA_FLOAT, 44, 0)
                rapi.rpgBindNormalBufferOfs(shape.buffer.buffer, noesis.RPGEODATA_FLOAT, 44, 12)
                rapi.rpgBindUV1BufferOfs(shape.buffer.buffer, noesis.RPGEODATA_FLOAT, 44, 28)

            # Set faces
            rapi.rpgCommitTriangles(self.header.faceBuffer[(shape.indexStart * 2):], noesis.RPGEODATA_USHORT, shape.indexNumber, noesis.RPGEO_TRIANGLE_STRIP, 1)

            #if shape.subBuffers != []:
                #for i in range(len(shape.subBuffers)):

                    #rapi.rpgSetName(shape.subBuffers[i].bufferName)

                    #if shape.subBuffers[i].strideSize == 24:
                        #rapi.rpgBindPositionBufferOfs(shape.subBuffers[i].buffer, noesis.RPGEODATA_FLOAT, 24, 0)
                        #rapi.rpgBindNormalBufferOfs(shape.subBuffers[i].buffer, noesis.RPGEODATA_BYTE, 24, 12)
                        #rapi.rpgBindUV1BufferOfs(shape.subBuffers[i].buffer, noesis.RPGEODATA_FLOAT, 24, 16)

                    #rapi.rpgCommitTriangles(self.header.faceBuffer[(shape.indexStart * 2):], noesis.RPGEODATA_USHORT,shape.indexNumber, noesis.RPGEO_TRIANGLE_STRIP, 1)

    def buildSkeleton(self):
        i = 0
        for skeleton in self.header.skeletonDictionary:
            for bone in self.header.skeletonDictionary[skeleton].__dict__["boneList"]:
                self.boneList.append(NoeBone(i, bone[1].boneName, bone[1].boneMatrix, bone[1].parentName, bone[1].parentIndex))
                i += 1

        for a in range(len(self.boneList)):

            j = self.boneList[a].parentIndex
            if j != -1:
                self.boneList[a].setMatrix(self.boneList[a].getMatrix().__mul__(self.boneList[j].getMatrix()))

    def loadTextures(self, textureCount):
        for i in range(textureCount):
            self.texture = efoDDS(self.bs, self.header)

            texFmt = None
            if self.texture.fourCC == 827611204:
                texFmt = noesis.NOESISTEX_DXT1
            elif self.texture.fourCC == 894720068:
                texFmt = noesis.NOESISTEX_DXT5
            else:
                texFmt = noesis.NOESISTEX_RGBA32
                if self.texture.pixelFormat.RBitMask == 0xf00 and self.texture.pixelFormat.GBitMask == 0xf0 and self.texture.pixelFormat.BBitMask == 0xf and self.texture.pixelFormat.ABitMask == 0xf000:
                    self.texture.buffer = rapi.imageDecodeRaw(self.texture.buffer, self.texture.width, self.texture.height, "b4g4r4a4 ")
                else:
                    self.texture.buffer = rapi.imageDecodeRaw(self.texture.buffer, self.texture.width, self.texture.height, "b5g5r5a1 ")

            texture = NoeTexture(self.texture.ddsName, self.texture.width, self.texture.height, self.texture.buffer, texFmt)
            self.texList.append(texture)


class efoHeader:
    def __init__(self, bs):
        self.bs = bs

        self._sSerial = {}

        self.skeletonDictionary = {}
        self.shapeDictionary = {}
        self.bufferDictionary = {}
        self.shaderDictionary = {}
        self.textureDictionary = {}
        self.ddsDictionary = {}

        self.skeletonSignatures = []
        self.shaderSignatures = []
        self.bufferSignatures = []
        self.shapeSignatures = []
        self.textureSignatures = []
        self.unknownSignatures = []
        self.ddsSignatures = []

        self.faceBuffer = None

        self.texturesPath = []
        self.texturesName = []

        self.loadHeader()

    def loadHeader(self):
        magic = noeStrFromBytes(self.bs.readBytes(4))
        self.bs.seek(4, 1)
        fileSize = self.bs.readInt()
        self.bs.seek(4, 1)
        unknown = self.bs.readByte()
        if unknown == 6:
            self.bs.seek(4, 1)
        else:
            self.bs.seek(-1, 1)

        self.bs.seek(1, 1)  # unknown byte
        self.bs.seek(self.bs.readShort(), 1)  # _sSerial::_sSceneDatabase
        self.bs.seek(1, 1)  # zero

        noeStrFromBytes(self.bs.readBytes(self.bs.readByte()))
        noeStrFromBytes(self.bs.readBytes(self.bs.readByte()))  # yabukita

        self.bs.seek(4, 1)  # 0x3ED (unknown)

        noeStrFromBytes(self.bs.readBytes(self.bs.readByte()))  # _sSerial

        self.bs.readBytes(4)  # unknown array of bytes 0x4
        self.bs.seek(1, 1)  # zero

        noeStrFromBytes(self.bs.readBytes(self.bs.readByte()))  # yabukita::Object

        self.bs.readInt()  # 0x1 (unknown)

        # Read _sSerial
        self.get_sSerial()

        if "_sSerial::_sShapeHeader" in self._sSerial:
            self.bs.seek(1, 1)  # zero

            # Read textures path
            self.getTexturesPath()
        else:
            self.getTextures()

            self.bs.seek(1, 1)  # zero


        self.bs.seek(2, 1)  # unknown 0x2
        self.bs.seek(2, 1)  # unknown 0x2

        self.bs.readInt()  # size of essd

        noeStrFromBytes(self.bs.readBytes(4))

        self.bs.seek(4, 1)  # zeros

        self.bs.readBytes(4)  # 0x4112904

        skip = self.bs.readInt()

        if skip == 2:
            self.bs.seek(skip, 1)
        elif skip == 3:
            self.bs.seek(skip, 1)
        elif skip == 23:
            noeStrFromBytes(self.bs.readBytes(self.bs.readShort())).replace("\0", "")
        else:
            self.bs.seek(-4, 1)

        self.bs.readInt()  # unknown 0x1

        # Read Signatures
        self.getSignatures()

        # unknown 0x18
        self.bs.readInt()
        self.bs.readInt()
        self.bs.readInt()
        self.bs.readInt()
        self.bs.readInt()
        self.bs.readInt()

        self.bs.readInt()  # size of texture names list (and infos ?)
        self.bs.readInt()  # unknown
        self.bs.readInt()  # size of texture names list
        textureNamesCount = self.bs.readInt()
        for i in range(textureNamesCount):
            self.texturesName.append(noeStrFromBytes(self.bs.readBytes(self.bs.readInt())))

        if textureNamesCount != 0:
            self.bs.readInt()  # size of textbl path
            self.bs.readInt()  # count of textbl path ?
            noeStrFromBytes(self.bs.readBytes(self.bs.readShort()))  # textbl path

        self.bs.readInt()  # size of model name
        noeStrFromBytes(self.bs.readBytes(self.bs.readShort()))  # model name
        self.bs.readInt()  # size of info model name
        noeStrFromBytes(self.bs.readBytes(self.bs.readShort()))  # info model name

    def get_sSerial(self): # Read the information at the start
        while True:
            _sSerialName = noeStrFromBytes(self.bs.readBytes(self.bs.readByte())).replace("\0", "")
            if "_sSerial::" in _sSerialName:
                self.bs.seek(3, 1)  # zeros
                self._sSerial[_sSerialName] = {}
                while True:
                    name = noeStrFromBytes(self.bs.readBytes(self.bs.readByte())).replace("\0", "")
                    if name == "":
                        break
                    self._sSerial[_sSerialName][name] = (self.bs.readByte(), self.bs.readByte())
                    self.bs.seek(1, 1)  # zero
            else:
                break

    def getTexturesPath(self):
        while True:
            texturePath = noeStrFromBytes(self.bs.readBytes(self.bs.readByte())).replace("\0", "")
            if texturePath == "":
                break
            self.texturesPath.append(texturePath)

    def getTextures(self):
        while True:
            texture = noeStrFromBytes(self.bs.readBytes(self.bs.readByte())).replace("\0", "")
            if texture == "":
                break
            textureSignature = self.bs.readShort()

    def getSignatures(self):

        # skeleton signatures
        self.bs.readInt()  # size of signature
        count = self.bs.readInt()  # skeleton signatures count
        for i in range(count):
            self.skeletonSignatures.append(self.bs.readShort())

        # shader signatures
        self.bs.readInt()  # size of signature
        count = self.bs.readInt()  # shader signatures count
        for i in range(count):
            self.shaderSignatures.append(self.bs.readShort())
        self.shaderSignatures.sort()

        # buffer signatures
        self.bs.readInt()  # size of signature
        count = self.bs.readInt()  # buffer signatures count
        for i in range(count):
            self.bufferSignatures.append(self.bs.readShort())

        # shape signatures
        self.bs.readInt()  # size of signature
        count = self.bs.readInt()  # shape signatures count
        for i in range(count):
            self.shapeSignatures.append(self.bs.readShort())

        # texture signatures
        self.bs.readInt()  # size of signature
        count = self.bs.readInt()  # texture signatures count
        for i in range(count):
            self.textureSignatures.append(self.bs.readShort())
        self.textureSignatures.sort()

        # unknown signatures
        self.bs.readInt()  # size of signature
        count = self.bs.readInt()  # unknown signatures count
        for i in range(count):
            self.unknownSignatures.append(self.bs.readShort())

        # dds signatures
        self.bs.readInt()  # size of signature
        count = self.bs.readInt()  # dds signatures count
        for i in range(count):
            self.ddsSignatures.append(self.bs.readShort())
        self.ddsSignatures.sort()


class efoShape:
    def __init__(self, bs, header):
        self.bs = bs

        self.geom = None
        self.shader = None

        self.stateNameList = []
        self.textureNameList = []

        self.unknownSignatures = []

        self.header = header

        self.shaderCheck = False
        self.shapeCheck = False
        self.faceSkip = False

        self.shaderSignature = 0
        self.shapeSignature = 0

        self.load()

    def load(self):
        self.bs.readShort()  # unknown 0x2
        self.bs.readInt()  # size of shape
        self.bs.seek(4, 1)  # zeros
        self.bs.readInt()  # size of stateName(?) signatures
        unknownSignatureCount = self.bs.readInt()  # count of stateName(?) signatures
        for i in range(unknownSignatureCount):
            self.unknownSignatures.append(self.bs.readBytes(2))

        ########## _sSerial::_sShapeHeader ##########
        BSphere = NoeVec4.fromBytes(self.bs.readBytes(16))
        BBoxCenter = NoeVec3.fromBytes(self.bs.readBytes(12))
        BBoxSize = NoeVec3.fromBytes(self.bs.readBytes(12))

        sortGroup = self.bs.readShort()
        self.bs.readInt() # size of stateName list
        stateNameCount = self.bs.readInt() # count of stateName
        for i in range(stateNameCount):
            self.stateNameList.append(noeStrFromBytes(self.bs.readBytes(self.bs.readShort())).replace("\0", ""))

        self.bs.readInt() # size of textureName list
        textureNameCount = self.bs.readInt() # count of textureName
        for i in range(textureNameCount):
            self.textureNameList.append(noeStrFromBytes(self.bs.readBytes(self.bs.readShort())).replace("\0", ""))
        #############################################

        self.bs.readInt()
        noeStrFromBytes(self.bs.readBytes(self.bs.readShort())).replace("\0", "")
        self.bs.readInt()
        noeStrFromBytes(self.bs.readBytes(self.bs.readShort())).replace("\0", "")

        print(len(self.header.shapeSignatures))
        for i in range(len(self.header.shapeSignatures)):
            self.readShape()
            print(self.bs.tell())

        count = len(self.header.shaderSignatures) - len(self.header.shaderDictionary)
        signaturesRemaining = len(self.header.shaderDictionary)
        for a in range(count):
            signature = self.header.shaderSignatures[signaturesRemaining - a]
            self.header.shaderDictionary[signature] = SHADER()
            self.shader = efoShader(self.bs, self.header, self.shaderSignature)
            material = efoMaterial(self.bs, self.header, self.shader)
            for i in range(self.shader.textureSignatureCount):
                texture = efoTexture(self.bs, self.header, self.shader)

        count = len(self.header.textureSignatures) - len(self.header.textureDictionary)
        signaturesRemaining = len(self.header.textureDictionary)
        for a in range(count):
            signature = self.header.textureSignatures[signaturesRemaining - a]
            self.header.textureDictionary[signature] = TEXTURE()
            texture = efoTexture(self.bs, self.header, self.shader)


    def readShape(self):
        self.shaderCheck = False
        self.shapeCheck = False
        self.faceSkip = False

        self.readShapeInfo()

        if not self.shaderCheck: # if the shader signature already been assigned
            self.shader = efoShader(self.bs, self.header, self.shaderSignature)
            material = efoMaterial(self.bs, self.header, self.shader)
            for i in range(self.shader.textureSignatureCount):
                texture = efoTexture(self.bs, self.header, self.shader)
        if not self.shapeCheck:
            self.geom = efoGeom(self.bs, self.header, self.shapeSignature)

        if self.faceSkip:
            self.header.shapeDictionary[self.header.shapeSignatures[0]] = SHAPE()
            self.geom = efoGeom(self.bs, self.header, self.header.shapeSignatures[0])

    def readShapeInfo(self): # _sSerial::_sShape
        state = self.bs.readShort()
        if state == 4: # ???
            self.bs.readBytes(self.bs.readInt())
            state = self.bs.readShort()

        self.bs.readInt() # size of shape

        # shader
        self.shaderSignature = self.bs.readShort() # shader signature
        if not self.shaderSignature in self.header.shaderDictionary:
            self.header.shaderDictionary[self.shaderSignature] = SHADER()
        else:
            self.shaderCheck = True

        # shape
        self.shapeSignature = self.bs.readShort() # shape signature
        if not self.shapeSignature in self.header.shapeDictionary:
            self.header.shapeDictionary[self.shapeSignature] = SHAPE()
        else:
            self.shapeCheck = True

        # Check : if the shape signature read isn't the first shape signature and if the first shape signature hasn't been read (first shape signature = the one with the face buffer)
        if self.shapeSignature != self.header.shapeSignatures[0] and self.header.shapeSignatures[
            0] not in self.header.shapeDictionary:
            self.faceSkip = True

        if "BSphere" in self.header._sSerial["_sSerial::_sShape"] and "BBoxCenter" in self.header._sSerial[
            "_sSerial::_sShape"] and "BBoxSize" in self.header._sSerial["_sSerial::_sShape"]:
            BSphere = NoeVec4.fromBytes(self.bs.readBytes(16))
            BBoxCenter = NoeVec3.fromBytes(self.bs.readBytes(12))
            BBoxSize = NoeVec3.fromBytes(self.bs.readBytes(12))

        self.bs.readInt() # size of shape name
        noeStrFromBytes(self.bs.readBytes(self.bs.readShort())).replace("\0", "") # shape name
        self.bs.readInt() # size of info shape name
        noeStrFromBytes(self.bs.readBytes(self.bs.readShort())).replace("\0", "") # info shape name

        # add shader linked to the shape
        self.header.shapeDictionary[self.shapeSignature].__dict__["shader"] = self.header.shaderDictionary[self.shaderSignature]


class efoShader:
    def __init__(self, bs, header, shaderSignature):
        self.bs = bs

        self.header = header

        self.shaderSignature = shaderSignature
        self.textureSignatureCount = 0
        self.textureSignatures = []

        self.bs.readShort()
        self.bs.readInt() # size of material information

        self.readShaderInformation(bs)

    def readShaderInformation(self, bs):  # _sSerial::_sState

        self.bs.readByte()  # fillType
        self.bs.readByte()  # alphaRef

        self.bs.readByte()  # depthTest
        self.bs.readByte()  # depthBias
        self.bs.readFloat()  # depthBiasRate
        self.bs.readFloat()  # depthBiasSlope

        self.bs.readByte()  # cullMode
        self.bs.readByte()  # lightingModel
        self.bs.readByte()  # maxInfluence
        self.bs.readByte()  # uvSet

        self.bs.readByte()  # blendMode
        self.bs.readByte()  # blendSrc
        self.bs.readByte()  # blendDst

        self.bs.readFloat()  # shininess
        self.bs.readByte()  # opacity
        self.bs.readFloat()  # ambient
        self.bs.readFloat()  # diffuse
        self.bs.readFloat()  # specular
        self.bs.readFloat()  # emission
        self.bs.readFloat()  # constant

        self.bs.readInt()  # shaderDesc
        self.bs.readInt()  # extrashaderDesc

        self.bs.readInt() # size of shader name
        shaderName = noeStrFromBytes(self.bs.readBytes(self.bs.readShort())).replace("\0", "") # shader name

        self.header.shaderDictionary[self.shaderSignature].__dict__["shaderName"] = shaderName

        self.bs.readInt()  # size of texture signatures name
        textureSignatureCount = self.bs.readInt()  # texture signatures count

        for i in range(textureSignatureCount):
            textureSignature = self.bs.readShort() # texture signature

            if textureSignature not in self.header.textureDictionary:
                self.textureSignatures.append(textureSignature)
                self.header.textureDictionary[textureSignature] = TEXTURE()
            else:
                self.header.shaderDictionary[self.shaderSignature].textures.append(self.header.textureDictionary[textureSignature])

        self.textureSignatureCount = len(self.textureSignatures)  # refresh count to remove the textures who have been already read

        self.bs.readBytes(self.bs.readInt())  # unknown 0x8

        self.bs.readBytes(16)  # shaderParameter0
        self.bs.readBytes(16)  # shaderParameter1


class efoMaterial:
    def __init__(self, bs, header, shader):
        self.bs = bs

        self.header = header
        self.shader = shader

        self.load()

    def load(self):
        self.bs.readInt() # size of shading information
        count = self.bs.readInt() # shading count

        for i in range(count):
            noeStrFromBytes(self.bs.readBytes(self.bs.readShort())).replace("\0", "") # shading name
            self.bs.readBytes(4) # unknown 0x4
            self.bs.readBytes(8) # zeros(?)
            shading = NoeVec3.fromBytes(self.bs.readBytes(12))
            self.bs.readBytes(4) # zeros(?)

        self.bs.readInt() # size of material name
        materialName = noeStrFromBytes(self.bs.readBytes(self.bs.readShort())).replace("\0", "") # material name
        self.bs.readInt() # size of info material name
        noeStrFromBytes(self.bs.readBytes(self.bs.readShort())).replace("\0", "") # info material name

        self.header.shaderDictionary[self.shader.shaderSignature].__dict__["materialName"] = materialName


class efoTexture:
    def __init__(self, bs, header, shader):
        self.bs = bs

        self.header = header
        self.shader = shader

        self.textureImage = 0

        self.readTextureInformation()

        if self.textureImage > 0 and self.header.ddsDictionary[self.textureImage].__dict__["buffer"] is None:

            dds = efoDDS(bs, header)

            self.header.ddsDictionary[self.textureImage].__dict__["height"] = dds.height
            self.header.ddsDictionary[self.textureImage].__dict__["width"] = dds.width
            self.header.ddsDictionary[self.textureImage].__dict__["fourCC"] = dds.fourCC
            self.header.ddsDictionary[self.textureImage].__dict__["buffer"] = dds.buffer
            self.header.ddsDictionary[self.textureImage].__dict__["ddsName"] = dds.ddsName

            #self.readTextureImage()

    def readTextureInformation(self): # _sSerial::_sTexture
        self.bs.readShort()
        self.bs.readInt() # size of texture information

        self.bs.readByte() # alphaRef
        self.bs.readShort() # height
        self.bs.readShort() # width
        self.bs.readByte() # format
        self.bs.readByte() # alphaMode
        self.bs.readByte() # wrapU
        self.bs.readByte() # wrapV
        self.bs.readByte() # minFilter
        self.bs.readByte() # magFilter
        self.bs.readByte() # mipFilter
        self.bs.readByte() # useMipmap
        self.bs.readByte() # maxMipmapLevel
        self.bs.readByte() # anisoNumber
        self.bs.readByte() # preserveFormat
        self.bs.readInt() # lodBias

        self.bs.readInt() # size of dds name
        ddsName = noeStrFromBytes(self.bs.readBytes(self.bs.readShort())).replace("\0", "") # dds name

        # unknown
        self.bs.readInt()
        noeStrFromBytes(self.bs.readBytes(self.bs.readShort())).replace("\0", "")
        if "plugName" in self.header._sSerial["_sSerial::_sTexture"]:
            self.bs.readInt()
            noeStrFromBytes(self.bs.readBytes(self.bs.readShort())).replace("\0", "")

        uvScale = (self.bs.readFloat(), self.bs.readFloat())
        uvOffset = (self.bs.readFloat(), self.bs.readFloat())

        self.bs.readByte() # uvSetIndex
        self.bs.readByte() # textureType
        self.bs.readByte() # textureID
        self.textureImage = self.bs.readShort() # textureImage

        if self.textureImage not in self.header.ddsDictionary:
            self.header.ddsDictionary[self.textureImage] = DDS()

        if self.shader.textureSignatures != []: # TEST
            self.header.shaderDictionary[self.shader.shaderSignature].__dict__["textures"].append(self.header.textureDictionary[self.shader.textureSignatures[0]])

            self.header.textureDictionary[self.shader.textureSignatures[0]].__dict__["dds"] = self.header.ddsDictionary[self.textureImage]

            self.header.ddsDictionary[self.textureImage].__dict__["ddsName"] = ddsName

        self.bs.readBytes(self.bs.readInt()) # unknown 0x8
        if "userParameter" in self.header._sSerial["_sSerial::_sTexture"]:
            self.bs.readBytes(self.bs.readInt()) # unknown 0x8

        self.bs.readInt() # size of texture name
        textureName = noeStrFromBytes(self.bs.readBytes(self.bs.readShort())).replace("\0", "") # texture name
        self.bs.readInt() # size of info texture name
        noeStrFromBytes(self.bs.readBytes(self.bs.readShort())).replace("\0", "") # info texture name

        if self.shader.textureSignatures != []: # TEST
            self.header.textureDictionary[self.shader.textureSignatures[0]].__dict__["textureName"] = textureName

            del self.shader.textureSignatures[0] # remove the texture signature

    def readTextureImage(self):
        self.bs.readShort() # state
        self.bs.readInt() # size of texture information
        ddsSize = self.bs.readInt()  # size of dds image
        noeStrFromBytes(self.bs.readBytes(4)) # DDS
        size = self.bs.readInt()
        flags = self.bs.readInt()
        self.header.ddsDictionary[self.textureImage].__dict__["height"]  = self.bs.readInt()
        self.header.ddsDictionary[self.textureImage].__dict__["width"] = width = self.bs.readInt()
        pitchOrLinearSize = self.bs.readInt()
        depth = self.bs.readInt()
        mipMapCount = self.bs.readInt()
        reserved1 = [0 for i in range(11)]
        for i in range(11):
            reserved1[i] = self.bs.readInt()

        pixelFormat = DDSPixelFormat()
        pixelFormat.size = self.bs.readInt()
        pixelFormat.flags = self.bs.readInt()
        pixelFormat.fourCC = self.bs.readInt()
        pixelFormat.RGBBitCount = self.bs.readInt()
        pixelFormat.RBitMask = self.bs.readInt()
        pixelFormat.GBitMask = self.bs.readInt()
        pixelFormat.BBitMask = self.bs.readInt()
        pixelFormat.ABitMask = self.bs.readInt()

        self.header.ddsDictionary[self.textureImage].__dict__["fourCC"] = pixelFormat.fourCC

        caps1 = self.bs.readInt()
        caps2 = self.bs.readInt()
        caps3 = self.bs.readInt()
        caps4 = self.bs.readInt()
        reserved2 = self.bs.readInt()

        self.header.ddsDictionary[self.textureImage].__dict__["buffer"] = self.bs.readBytes(ddsSize - 128)

        self.bs.readByte() # maxMipmapLevel (?)

        self.bs.readInt() # size of dds name
        noeStrFromBytes(self.bs.readBytes(self.bs.readShort())).replace("\0", "")  # dds name

        if ("flag" in self.header._sSerial["_sSerial::_sTextureImage"]): # TEST
            self.bs.readInt()

        self.bs.readBytes(8)

        self.bs.readInt() # size of texture name
        noeStrFromBytes(self.bs.readBytes(self.bs.readShort())).replace("\0", "")  # texture name
        self.bs.readInt() # size of info texture name
        noeStrFromBytes(self.bs.readBytes(self.bs.readShort())).replace("\0", "")  # info texture name


class efoDDS:
    def __init__(self, bs, header):
        self.bs = bs
        self.header = header

        self.buffer = None

        self.height = 0
        self.width = 0

        self.fourCC = 0

        self.ddsName = ""

        self.pixelFormat = DDSPixelFormat()

        self.readTextureImage()

    def readTextureImage(self):
        self.bs.readShort() # state
        self.bs.readInt() # size of texture information
        ddsSize = self.bs.readInt()  # size of dds image
        noeStrFromBytes(self.bs.readBytes(4)) # DDS
        size = self.bs.readInt()
        flags = self.bs.readInt()
        self.height  = self.bs.readInt()
        self.width = self.bs.readInt()
        pitchOrLinearSize = self.bs.readInt()
        depth = self.bs.readInt()
        mipMapCount = self.bs.readInt()
        reserved1 = [0 for i in range(11)]
        for i in range(11):
            reserved1[i] = self.bs.readInt()

        #pixelFormat = DDSPixelFormat()
        self.pixelFormat.size = self.bs.readInt()
        self.pixelFormat.flags = self.bs.readInt()
        self.pixelFormat.fourCC = self.bs.readInt()
        self.pixelFormat.RGBBitCount = self.bs.readInt()
        self.pixelFormat.RBitMask = self.bs.readInt()
        self.pixelFormat.GBitMask = self.bs.readInt()
        self.pixelFormat.BBitMask = self.bs.readInt()
        self.pixelFormat.ABitMask = self.bs.readInt()

        self.fourCC = self.pixelFormat.fourCC

        caps1 = self.bs.readInt()
        caps2 = self.bs.readInt()
        caps3 = self.bs.readInt()
        caps4 = self.bs.readInt()
        reserved2 = self.bs.readInt()

        self.buffer = self.bs.readBytes(ddsSize - 128)

        self.bs.readByte() # maxMipmapLevel (?)

        self.bs.readInt() # size of dds name
        noeStrFromBytes(self.bs.readBytes(self.bs.readShort())).replace("\0", "")  # dds name

        if ("flag" in self.header._sSerial["_sSerial::_sTextureImage"]): # TEST
            self.bs.readInt()

        self.bs.readBytes(8)

        self.bs.readInt() # size of texture name
        self.ddsName = noeStrFromBytes(self.bs.readBytes(self.bs.readShort())).replace("\0", "")  # texture name
        self.bs.readInt() # size of info texture name
        noeStrFromBytes(self.bs.readBytes(self.bs.readShort())).replace("\0", "")  # info texture name


class efoGeom:
    def __init__(self, bs, header, shapeSignature):
        self.bs = bs
        self.shapeSignature = shapeSignature

        self.header = header

        self.bufferSignature = 0
        self.subBufferSignatures = []

        self.strideSize = 0
        self.bufferCount = 0

        self.load()

    def load(self):
        state = self.bs.readShort()

        self.bs.readInt() # size of geom data
        self.bufferSignature = self.bs.readShort() # buffer signature

        self.bs.readBytes(self.bs.readInt()) # unknown signature

        self.bs.readInt() # size of buffer list (?)
        self.bufferCount = self.bs.readInt()
        for i in range(self.bufferCount):
            self.subBufferSignatures.append(self.bs.readShort())

        if self.bufferCount == 0:
            self.bufferCount = 1
        else:
            self.bufferCount += 1

        if self.bufferSignature not in self.header.bufferDictionary:
            self.header.bufferDictionary[self.bufferSignature] = BUFFER()

        # check : if the buffer signature read is the face buffer
        if self.bufferSignature == self.header.bufferSignatures[0]:
            # check : if the shape read is the first signature (first shape signature = the one with the face buffer)
            if self.shapeSignature == self.header.shapeSignatures[0]:
                # check : if the face buffer hasn't been assigned yet
                if self.header.faceBuffer is None:
                    self.readFaceData()
                else:
                    self.bs.readBytes(self.bs.readInt()) # unknown 0x8
                    self.bs.readShort() # geom signature
            else:
                self.bs.readBytes(self.bs.readInt())  # unknown 0x8
                self.bs.readShort()  # geom signature
        else:
            self.bs.readBytes(self.bs.readInt()) # unknown 0x8
            self.bs.readShort() # geom signature

        self.bs.readInt() # unknown 0x4

        self.bs.readInt() # size of mesh name
        geomName = noeStrFromBytes(self.bs.readBytes(self.bs.readShort())).replace("\0", "") # mesh name
        self.bs.readInt() # size of info mesh name
        noeStrFromBytes(self.bs.readBytes(self.bs.readShort())).replace("\0", "") # info mesh name

        self.header.shapeDictionary[self.shapeSignature].__dict__["geomName"] = geomName
        self.header.shapeDictionary[self.shapeSignature].__dict__["buffer"] = self.header.bufferDictionary[self.bufferSignature]

        # check : if the vertex buffer hasn't been assigned yet (TEST : OR if it's the vertex buffer after the face buffer : || faceBuffer)
        if self.header.bufferDictionary[self.bufferSignature].__dict__["buffer"] is None:
            for i in range(self.bufferCount):
                if i == 1:
                    self.readPrimitiveList()

                if i >= 1:
                    self.bufferSignature = self.subBufferSignatures[i - 1]
                    self.header.bufferDictionary[self.bufferSignature] = BUFFER()
                    self.header.shapeDictionary[self.shapeSignature].subBuffers.append(self.header.bufferDictionary[self.bufferSignature])

                self.readVertexData()

                self.bs.readInt()
                self.header.bufferDictionary[self.bufferSignature].bufferName = noeStrFromBytes(self.bs.readBytes(self.bs.readShort())).replace("\0", "")
                self.bs.readInt()
                noeStrFromBytes(self.bs.readBytes(self.bs.readShort())).replace("\0", "")

                self.readVertexBuffer()

        if self.bufferCount == 1:
            self.readPrimitiveList()

    def readFaceData(self):
        indicesTotalCount = self.bs.readInt() # indices total count
        indicesCount = self.bs.readInt() # indices count
        self.header.faceBuffer = self.bs.readBytes(indicesCount * 2)
        self.bs.readShort() # unknown 0x2

    def readVertexData(self): # _sSerial::_sGeometry
        self.bs.readShort()
        self.bs.readInt() # size of geometry data
        self.header.bufferDictionary[self.bufferSignature].__dict__["vertexDesc"] = self.bs.readInt() # vertexDesc
        self.header.bufferDictionary[self.bufferSignature].__dict__["vertexNumber"] = self.bs.readInt() # vertexNumber
        self.header.bufferDictionary[self.bufferSignature].__dict__["vertexSize"] = self.bs.readInt() # vertexSize
        self.strideSize = self.bs.readInt() # strideSize
        self.header.bufferDictionary[self.bufferSignature].__dict__["strideSize"] = self.strideSize # vertexArray
        self.header.bufferDictionary[self.bufferSignature].__dict__["vertexArray"] = self.bs.readShort() # vertexArray
        if "userVertexArray" in self.header._sSerial["_sSerial::_sGeometry"]:
            self.header.bufferDictionary[self.bufferSignature].__dict__["userVertexArray"] = self.bs.readShort() # userVertexArray
        if "userVertexArrayElementNumber" in self.header._sSerial["_sSerial::_sGeometry"]:
            self.header.bufferDictionary[self.bufferSignature].__dict__["userVertexArrayElementNumber"] = self.bs.readInt() # userVertexArrayElementNumber
        self.header.bufferDictionary[self.bufferSignature].__dict__["flag"] = self.bs.readByte() # flag

    def readVertexBuffer(self):
        self.bs.readShort()
        self.bs.readInt() # size of vertex buffer
        self.bs.readInt() # size of vertex buffer
        vertexCount = self.bs.readInt() # vertex count
        self.header.bufferDictionary[self.bufferSignature].__dict__["buffer"] = self.bs.readBytes(vertexCount * self.strideSize)

    def readPrimitiveList(self): # _sSerial::_sPrimitiveList
        self.bs.readShort()
        self.bs.readInt() # size of primitive list data
        self.header.shapeDictionary[self.shapeSignature].__dict__["primitiveType"] = self.bs.readInt() # primitiveType
        self.header.shapeDictionary[self.shapeSignature].__dict__["primitiveNumber"] = self.bs.readInt() # primitiveNumber
        self.header.shapeDictionary[self.shapeSignature].__dict__["indexStart"] = self.bs.readInt() # indexStart
        self.header.shapeDictionary[self.shapeSignature].__dict__["indexNumber"] = self.bs.readInt() # indexNumber
        self.header.shapeDictionary[self.shapeSignature].__dict__["startNumber"] = self.bs.readInt() # startNumber
        self.header.shapeDictionary[self.shapeSignature].__dict__["endNumber"] = self.bs.readInt() # endNumber
        self.header.shapeDictionary[self.shapeSignature].__dict__["vertexNumber"] = self.bs.readInt() # vertexNumber
        self.bs.readBytes(self.bs.readInt()) # unknown data
        self.bs.readBytes(self.bs.readInt()) # unknown data


class efoSkeleton:

    def __init__(self, bs, header, boneList):
        self.bs = bs
        self.header = header
        self.boneList = boneList

        self.boneSignatures = []
        self.boneDictionary = {}

        self.skeletonCount = 0
        self.skeletonSignatureCheck = False

        self.load()

    def load(self):

        count = 0
        self.skeletonCount = len(self.header.skeletonSignatures)

        while count < self.skeletonCount:
            state = self.bs.readShort() # state
            self.bs.readInt() # skeleton information header size
            self.bs.readInt() # size of skeleton signatures
            boneSignaturesCount = self.bs.readInt()
            for i in range(boneSignaturesCount):
                self.boneSignatures.append(self.bs.readShort())

            self.bs.readInt()  # zeros
            self.bs.readInt() # size of header skeleton name
            noeStrFromBytes(self.bs.readBytes(self.bs.readShort())).replace("\0", "") # header skeleton name
            self.bs.readInt() # size of header info skeleton name
            noeStrFromBytes(self.bs.readBytes(self.bs.readShort())).replace("\0", "") # info header skeleton name

            for i in range(boneSignaturesCount):
                self.readBone(self.boneSignatures[i], i)
                if self.skeletonSignatureCheck == True:
                    count += 1

    def readBone(self, boneSignature, index):
        self.boneDictionary[boneSignature] = BONE()
        self.boneDictionary[boneSignature].index = index

        self.bs.readShort()  # state
        self.bs.readInt()  # size of bone

        shapeHeader = self.bs.readShort()  # shapeHeader
        if(shapeHeader not in self.header.skeletonDictionary):
            self.header.skeletonDictionary[shapeHeader] = SKELETON()
            if shapeHeader != 0:
                self.skeletonSignatureCheck = True
        self.bs.readInt()  # size of parent name
        self.boneDictionary[boneSignature].parentName = noeStrFromBytes(self.bs.readBytes(self.bs.readShort())).replace("\0", "") # parent name
        self.bs.readByte()

        mtxLocal = NoeMat43.fromBytes(self.bs.readBytes(48))
        mtxDefault = NoeMat43.fromBytes(self.bs.readBytes(48))

        self.boneDictionary[boneSignature].parentIndex = self.bs.readInt() # parentIndex
        self.boneDictionary[boneSignature].blendIndex = self.bs.readInt() # blendIndex
        self.boneDictionary[boneSignature].shapeHeaderIndex = self.bs.readInt() # shapeHeaderIndex
        self.bs.readByte() # isInstance
        self.boneDictionary[boneSignature].parent = self.bs.readShort() # parent
        self.boneDictionary[boneSignature].child = self.bs.readShort() # child
        self.boneDictionary[boneSignature].sibling = self.bs.readShort() # sibling

        # ???
        self.bs.readInt()  # size of ?
        unknownCount = self.bs.readInt()  # ? count

        for i in range(unknownCount):
            noeStrFromBytes(self.bs.readBytes(self.bs.readShort())).replace("\0", "")
            self.bs.readInt()
            self.bs.readByte()
            self.bs.readInt()
            self.bs.readBytes(19) # ?
        #

        scale = NoeVec3.fromBytes(self.bs.readBytes(12))
        if "rotation" in self.header._sSerial["_sSerial::_sBone"]:
            rotation = NoeVec3.fromBytes(self.bs.readBytes(12))
        quaternion = NoeQuat.fromBytes(self.bs.readBytes(16))
        translation = NoeVec3.fromBytes(self.bs.readBytes(12))

        self.boneDictionary[boneSignature].boneMatrix = quaternion.toMat43(transposed = 1)
        self.boneDictionary[boneSignature].boneMatrix[3] = translation

        self.bs.readInt()  # size of bone name
        noeStrFromBytes(self.bs.readBytes(self.bs.readShort())).replace("\0", "") # bone name
        self.bs.readInt()  # size of info bone name
        self.boneDictionary[boneSignature].boneName = noeStrFromBytes(self.bs.readBytes(self.bs.readShort())).replace("\0", "") # info bone name

        self.header.skeletonDictionary[shapeHeader].__dict__["boneList"].append((boneSignature, self.boneDictionary[boneSignature]))


def efoLoadModel(data, mdlList):
    ctx = rapi.rpgCreateContext()
    efo = efoFile(NoeBitStream(data))
    efo.load(efo.bs)
    try:
        mdl = rapi.rpgConstructModel()
    except:
        mdl = NoeModel()
    mdl.setModelMaterials(NoeModelMaterials(efo.texList, efo.matList))
    mdlList.append(mdl); mdl.setBones(efo.boneList)
    return 1
