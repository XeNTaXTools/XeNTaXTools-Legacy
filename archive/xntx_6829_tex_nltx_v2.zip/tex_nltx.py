from inc_noesis import *
from inc_switchunswizzling import *

# debug level
# 0 - info/warn/error messages (hidden)
# 1 - 0 + pop up Noesis Debug Log
DEBUGLEVEL = 0
#-------------------------------------------------------------------------------
def registerNoesisTypes():
    handle = noesis.register("NLTX", ".nltx")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    if DEBUGLEVEL >= 1: noesis.logPopup()
    return 1
#-------------------------------------------------------------------------------
def noepyCheckType(data):
    bs = NoeBitStream(data)
    if bs.readBytes(8) == b"NMPLTEX1": return 1
    else: print("[x] Wrong magic bytes."); return 0
    return 1
#-------------------------------------------------------------------------------
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.seek(0x8, 0)
    DUMMY = bs.readUInt() # 0x8
    DUMMY = bs.readUInt() # 0xC
    DUMMY = bs.readUInt() # 0x10, =0x64?
    mode = bs.readUShort() # 0x14, mode? format? flags?
    DUMMY = bs.readUShort() # 0x16
    width = bs.readUInt() # 0x18
    height = bs.readUInt() # 0x1C
    DUMMY = bs.readUByte() # 0x20
    DUMMY = bs.readUByte() # 0x21, bits per pixel?
    paletteColours = min(bs.readUShort(), 0x100) # 0x22
    DUMMY = bs.readUShort() # 0x24
    DUMMY = bs.readUShort() # 0x26
    DUMMY = bs.readUInt() # 0x28, unknown
    dataSize = bs.readUInt() # 0x2C
    block_height_log2 = bs.readUByte() # 0x30
    DUMMY = bs.readUByte() # 0x31, block_width_log2?

    dataStart = 0x80
    bs.seek(dataStart, 0)
    if bs.readBytes(8) == b"YKCMP_V1":
        print("[i] YKCMP_V1 compression.")
        DUMMY = bs.readUInt() # +0x8, seems to always be 4
        compSize = bs.readUInt() # +0xC, size from "YKCMP_V1" to EOF
        bs.seek(dataStart, 0)
        compData = bs.readBytes(compSize)
        decompData = NoeBitStream(decompYKCMP_V1(compData))
        if mode == 1: palette = decompData.readBytes(paletteColours * 4)
        data = decompData.readBytes(dataSize)
    else:
        bs.seek(dataStart, 0)
        if mode == 1: palette = bs.readBytes(paletteColours * 4)
        data = bs.readBytes(dataSize)

    print("[i] Mode: "+repr(mode)+"; WxH: "+repr(width)+"x"+repr(height)+"; data start: "+hex(dataStart + paletteColours * 4)+"; data size: "+repr(dataSize)+" B.")
    block_height = 1 << block_height_log2
    print("[DEBUG] Calculated block_height (may be incorrect): "+repr(block_height))

    if mode == 1:
        print("[i] Format: RGBA8 (palletized). Palette contains "+repr(paletteColours)+" colours.")
        data = rapi.imageDecodeRawPal(data, palette, width, height, 8, "r8g8b8a8")
        data = imageUnswizzleSwitch(data, width, height, 4, block_height)
    elif mode == 2:
        print("[i] Format: RGBA8")
        data = rapi.imageDecodeRaw(data, width, height, "r8g8b8a8")
    elif mode == 3:
        print("[i] Format: BC3")
        data = imageUnswizzleSwitch(data, width>>2, height>>2, 16, block_height, block_height)
        data = rapi.imageDecodeDXT(data, width, height, noesis.NOESISTEX_DXT5)

    texList.append(NoeTexture(rapi.getInputName(), width, height, data, noesis.NOESISTEX_RGBA32))
    return 1
#-------------------------------------------------------------------------------
# implementation of YKCMP_V1 decompression
# thanks to Xkeeper, iltrof, and aluigi
# https://github.com/Xkeeper0/disgaea-pc-tools/blob/master/disgaea/compressionhandler.php
# https://github.com/iltrof/ykcmp/tree/master/ykcmp
# https://zenhax.com/viewtopic.php?p=38224#p38224

def decompYKCMP_V1(data):
    data = NoeBitStream(data)
    if data.readBytes(8) != b"YKCMP_V1": return None
    DUMMY = data.readUInt() # 0x08
    compSize = data.readUInt() - 20 # 0x0C
    decompSize = data.readUInt() # 0x10
    print("[i] Decompressed size: "+repr(decompSize)+" B.")
    data.seek(0x14, 0)
    compData = bytearray(data.readBytes(compSize))
    decompData = bytearray(decompSize)
    InPos = 0
    OutPos = 0
    
    while InPos in range(compSize):
        TMP = compData[InPos]

        if TMP < 0x80: # literal
           InPos += 1
           decompData[OutPos:OutPos+TMP] = compData[InPos:InPos+TMP]
           InPos += TMP
           OutPos += TMP
        else:
           if TMP < 0xC0: # 1b flag, 3b for length, 4b for backstep
               B = compData[InPos]
               COPYAMOUNT = ((B & 0x70) >> 4) + 1
               BACKSTEP = (B & 0xF) + 1
               InPos += 1
           elif TMP < 0xE0: # 2b flag, 6b for length, 8b for backstep
               B = (compData[InPos] << 8) + compData[InPos+1]
               COPYAMOUNT = ((B & 0x3F00) >> 8) + 2
               BACKSTEP = (B & 0xFF) + 1
               InPos += 2
           else: # 3b flag, 9b for length, 12b for backstep
               B = (compData[InPos] << 16) + (compData[InPos+1] << 8) + compData[InPos+2]
               COPYAMOUNT = ((B & 0x1FF000) >> 12) + 3
               BACKSTEP = (B & 0xFFF) + 1
               InPos += 3

           decompData[OutPos:OutPos+COPYAMOUNT] = decompData[OutPos-BACKSTEP:OutPos-BACKSTEP+COPYAMOUNT]
           OutPos += COPYAMOUNT

    return decompData
#-------------------------------------------------------------------------------