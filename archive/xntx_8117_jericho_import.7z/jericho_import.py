# 2011-01-22 Glogow Poland Mariusz Szkaradek
dir = 'C:\\Users\\Glaster\\Desktop\\testcrap\\files\\'
import bpy,struct,os
import Blender
from Blender import *
from struct import *
from Blender.Mathutils import *
from Blender import Armature as A
import math

def word(long): 
   s=''
   for j in range(0,long): 
       lit =  struct.unpack('c',plik.read(1))[0]
       if ord(lit)!=0:
           s+=lit
           if len(s)>100:
               break
   return s

bigendian    = 0
littleendian = 1


if littleendian == True:
    def b(n):
        return struct.unpack(n*'b', plik.read(n))
    def B(n):
        return struct.unpack(n*'B', plik.read(n))
    def h(n):
        return struct.unpack(n*'h', plik.read(n*2))
    def H(n):
        return struct.unpack(n*'H', plik.read(n*2))
    def i(n):
        return struct.unpack(n*'i', plik.read(n*4))
    def f(n):
        return struct.unpack(n*'f', plik.read(n*4))


def read_faces():
    faceslist=[]
    data = i(3)
    word(data[2])
    data = i(2)
    for m in range(data[0]):
         v = H(3)
         faceslist.append(v)
    return faceslist

def read_vertexes():
    vertexes = []
    uvcoord =[]
    data = i(6)
    print data
    if data[4] == 48:
        for m in range(data[5]):
            v = f(3)
            vertexes.append(v)
            f(3)
            u = f(1)[0]
            v = f(1)[0]
            uvcoord.append([u,1-v])
            f(4)
                 
    if data[4] == 80:
        for m in range(data[5]):
            v = f(3)
            vertexes.append(v)
            f(3)
            u = f(1)[0]
            v = f(1)[0]
            uvcoord.append([u,1-v])
            f(6)
            f(2) 
            f(4) 

    return vertexes,uvcoord

def drawmesh(name): 
    global obj,mesh
    mesh = bpy.data.meshes.new(name)
    mesh.verts.extend(vertexy)
    mesh.faces.extend(faceslist,ignoreDups=True)
    if len(uvcoord)!=0:
        uv()
    scene = bpy.data.scenes.active
    obj = scene.objects.new(mesh,name)
    mesh.recalcNormals()
    mesh.update()
    Redraw()

def uv():
    for faceID in range(0,len(mesh.faces)):
            face = mesh.faces[faceID]
            index1 = faceslist[faceID][0]
            index2 = faceslist[faceID][1]
            index3 = faceslist[faceID][2]
            uv1 = Vector(uvcoord[index1])
            uv2 = Vector(uvcoord[index2])
            uv3 = Vector(uvcoord[index3])
            face.uv = [uv1, uv2, uv3]
            face.smooth=True



def make_armature(filename):
    namefile = filename.split(os.sep)[-1].split('.')[0]
    global armobj,newarm
    armobj=None
    newarm=None
    scn = Scene.GetCurrent()
    scene = bpy.data.scenes.active
    for object in scene.objects:
        if object.getType()=='Armature':
            if object.name == namefile+'-armobj':
                scn.unlink(object)
    for object in bpy.data.objects:
        if object.name == namefile+'-armobj':
            armobj = Blender.Object.Get(namefile+'-armobj')
            newarm = armobj.getData()
            newarm.makeEditable()         
            for bone in newarm.bones.values():
                del newarm.bones[bone.name]
            newarm.update()
    if armobj==None: 
        armobj = Blender.Object.New('Armature',namefile+'-armobj')
    if newarm==None: 
        newarm = Armature.New(namefile+'-arm')
        armobj.link(newarm)
    scn.link(armobj)
    newarm.drawType = Armature.STICK

def make_vertex_group():
    for v_id in range(len(grupy)):
        data_id = grupy[v_id]
        data = groups[data_id]          
        for m in range(data[0]): 
            gr = data[1][m]
            try:
                gr = bonenames[gr] 
            except:
                gr = str(gr)
                pass 
            w  = data[2][m] 
            if gr not in mesh.getVertGroupNames():
                mesh.addVertGroup(gr)          
                mesh.update()
            mesh.assignVertsToGroup(gr,[v_id],w,1)
    mesh.update()

def create_material(m):
    global mat
    word(8),i(1)#MAT
    print 'MATERIAL ', word(i(1)[0])
    try:
        mat = Material.Get('mat-'+str(m))
    except:
        mat = Material.New('mat-'+str(m))
    B(44),i(3)#NOTHING  

def create_texture_diffuse(m):
    try:
        tex = Texture.Get('tex-'+str(m))
    except:
        tex = Texture.New('tex-'+str(m))
    tex.setType('Image')
    try:
        img = Blender.Image.Load(dir_images+name_image+'.dds')                          
        tex.image = img 
        mat.setTexture(0,tex,Texture.TexCo.UV,Texture.MapTo.COL) 
    except:
        pass

def create_texture_specular(m):
    try:
        tex_alpha = Texture.Get('tex_alpha-'+str(m))
    except:
        tex_alpha = Texture.New('tex_alpha-'+str(m))
    tex_alpha.setType('Image')
    try:
        img = Blender.Image.Load(dir_images+name_image+'.alpha.dds')                      
        tex_alpha.image = img 
        mat.setTexture(1,tex_alpha,Texture.TexCo.UV,Texture.MapTo.COL) 
    except:
        pass

def create_texture_normal(m):
    try:
        tex_norm = Texture.Get('tex_norm-'+str(m))
    except:
        tex_norm = Texture.New('tex_norm-'+str(m))
    tex_norm.setType('Image')
    tex_norm.setImageFlags('NormalMap')  
    try:
        img = Blender.Image.Load(dir_images+name_image+'.dds')                      
        tex_norm.image = img 
        mat.setTexture(2,tex_norm,Texture.TexCo.UV,Texture.MapTo.NOR) 
    except:
        pass

def read_materials(): 
    global dir_images,name_image
    dir_images = sys.dirname(filename)+os.sep+'dds'+os.sep
    dir_images = dir_images.lower()
    num_mat = i(1)[0]
    print 'num_mat =',num_mat
    for m in range(num_mat):
        create_material(m)
        while(True):
            data = i(1)[0]
            if data == 0:
                pass 
            elif data ==1: 
                word(8),i(1) 
                name_image = word(i(1)[0]).split('/')[-1].split('.')[0]
                name_image = name_image.lower() 
                #print name_image
                if '-d' in name_image:
                    create_texture_diffuse(m)
                if '-m' in name_image:
                    create_texture_specular(m)
                if '-b' in name_image:
                    create_texture_normal(m)

                data = i(4)
                if data[3]!=0:
                    break 
                B(11) 
            else:
                seek = plik.tell()
                plik.seek(seek-4)
                break      

def make_bones(m):
    global namebone 
    newarm.makeEditable()
    data = i(6)
    print data
    namebone = word(i(1)[0])[-25:]
    #print namebone
    bonenames[data[1]] = namebone
    eb = A.Editbone() 
    newarm.bones[namebone] = eb
    newarm.update()
    newarm.makeEditable()
    nameparent = word(i(1)[0])[-25:]        
    if len(nameparent)>0:
        parent = newarm.bones[nameparent]
        newarm.bones[namebone].parent = parent
    f(8)
    bonematrix = Matrix(f(4),f(4),f(4),f(4))
    f(23)
    newarm.update()
    newarm.makeEditable()
    bone = newarm.bones[namebone]
    bone.matrix = bonematrix
    newarm.update()

def read_mesh_data(num):
    global grupy
    grupy = []
    print namebone+'='+str(num)
    meshes[namebone+'='+str(num)]=[]
    print 'ADD FACES'
    meshes[namebone+'='+str(num)].append(read_faces())
    word(4)
    print 'ADD VERTEXES UVCOORD'
    meshes[namebone+'='+str(num)].append(read_vertexes())
    #print 'ADD GROUPS'
    meshes[namebone+'='+str(num)].append(groups)
    data = i(2) 
    print namebone+'='+str(num) 
    print 'ADD GROUPS',data
    for k in range(data[0]):
        gr =  H(1)[0]
        grupy.append(gr)
    print 'ADD GRUPY'
    meshes[namebone+'='+str(num)].append(grupy)
    i(2),i(2),i(2),i(2)
    data = i(2)
    if data[1]==0:
        data1 = i(2)
        print 'making limited groups',data1
        for m in range(data1[0]):
            num_gr = B(1)[0]
            gr = B(3) 
            w  = f(3) 
            #print num,gr,w
            groups.append([num_gr,gr,w])    
    data = i(2)
    for m in range(data[0]):
        B(data[1])
    data = i(2)
    i(1) 
    objectmatrix = f(16)
    print id_object
    meshes[namebone+'='+str(num)].append(objectmatrix)
    #add id_mat
    meshes[namebone+'='+str(num)].append(0)

def readdata():
    global bonenames,meshes,id_object
    bonenames = []
    meshes = {}
    id_object = 0
    word(8),B(12),word(4),i(3),word(i(1)[0]),i(1),word(4)
    data = i(3)
    print data
    for m in range(data[2]):
        long = i(1)[0]
        print word(long)
    print f(15) 
    read_materials()#----------------MATERIALS
    seek = plik.tell()
    plik.seek(seek-36)
    print plik.tell()  
    data = i(2)
    print  
    print '==== MAKING NODES ===='
    print
    print 'begin----------',data[0]
    print 'num nodes------',data[1]
    for m in range(data[1]):
        bonenames.append('')
    for m in range(data[1]):
    #for m in range(10):
        make_bones(m)
        long =  i(1)[0]
        for n in range(long):
            word(4)
            data = i(3)
            for k in range(data[2]):
                long = i(1)[0]
                word(long)
        long = i(1)[0]
        for n in range(long):
            id_object+=1
            i(1)
            num = 0 
            global groups
            groups = []
            while(True):
                name = word(4)
                if name == 'CAM':
                    i(5),f(14)
                    break
                elif name == 'MD3D':
                    read_mesh_data(num)
                    data = i(1)[0]
                    if data==0:
                        break
                    num+=1
                else: 
                    break
    print struct.unpack('i',plik.read(4))[0]
    print 'KONIEC AT OFFSET ',plik.tell()


def make_right_mesh_position(): 
    name = mesh_name.split('=')[0]
    obj_matrix = obj.matrixWorld
    bones= newarm.bones.values()
    for bone in bones:
        if bone.name == name:
            bone_mat= bone.matrix['ARMATURESPACE']
            bone_mat_world= bone_mat*obj_matrix
    return bone_mat_world




def draw_all():
    global mesh_name,faceslist,vertexy,uvcoord,groups,grupy
    for mesh_name in meshes:
        mesh_data = meshes[mesh_name]
        faceslist = mesh_data[0]
        vertexy   = mesh_data[1][0]
        uvcoord   = mesh_data[1][1]
        groups    = mesh_data[2] 
        grupy     = mesh_data[3]
        mat_id    = mesh_data[5]
        drawmesh(mesh_name)
        if len(groups) == 0:
            matrix = make_right_mesh_position()
            obj.setMatrix(matrix)
            Redraw()
            armobj.makeParentBone([obj],mesh_name.split('=')[0],0,0) 
        else:
            make_vertex_group()
            armobj.makeParentDeform([obj],1,0)
        mesh.materials+=[Material.Get('mat-'+str(mat_id))]
        Redraw()
  



#=========== open file ======================
global plik,filename
extends=['sm3']
g = os.listdir(dir)
bool={}
draw={}  
block=[] 
for plik in g:
  extend = plik[plik.lower().find('.')+1:]
  if extend.lower() in extends: 
      bool[plik] = False
      draw[plik] = Draw.Create(bool[plik])
      block.append((plik,draw[plik]))
Draw.PupBlock("sm3 files",block) 
for file in bool:
        bool[file] = draw[file].val
        if bool[file]==True: 
            filename = dir+os.sep+file
            print '===================================='
            print file
            print '===================================='    
            plik = open(filename,'rb')
            make_armature(filename)
            readdata()
            draw_all()
        else:
            Draw.Exit()