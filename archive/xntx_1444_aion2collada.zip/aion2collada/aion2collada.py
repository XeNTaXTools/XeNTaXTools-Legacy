import datetime, math
import collada
from pyffi.formats.cgf import CgfFormat

debugMode = False


def IRGB2List(irgb):
	return [irgb.r / 255.0, irgb.g / 255.0, irgb.b / 255.0, 1.0]

def QuatToMatrix(q):
	mat = CgfFormat.Matrix33()
	xx = 1 - 2.0 * q.x * q.x
	yy = 2.0 * q.y * q.y
	xw = 2.0 * q.x * q.w
	xy = 2.0 * q.x * q.y
	yz = 2.0 * q.y * q.z
	yw = 2.0 * q.y * q.w
	xz = 2.0 * q.x * q.z
	zz = 2.0 * q.z * q.z
	zw = 2.0 * q.z * q.w
	mat.m11 = 1.0 - yy - zz
	mat.m12 = xy - zw
	mat.m13 = xz + yw
	mat.m21 = xy + zw
	mat.m22 = xx - zz
	mat.m23 = yz - xw
	mat.m31 = xz - yw
	mat.m32 = yz + xw
	mat.m33 = xx - yy
	return mat

	
def GetValidID(str):
	return str.replace(' ', '_').replace('/', '_').replace(')', '_').replace('(', '_')

def GetValidTexturePath(str):
	return str.replace('\\', '/').replace('/mesh/', '/%s/' % texturePath)



class Converter(object):
	def __init__(self, debugMode):
		self.debugMode = debugMode
		self.ids = []
	
		
	def CreateID(self, name, typeName = None):
		if len(name) > 0 and not name[0].isalpha():
			name = "i" + name
		if name in self.ids:
			name = name + typeName
			if name in self.ids:
				raise AssertionError, "id conflict %s" % name
		self.ids.append(name)
		return name
	

	def GetChunk(self, chunkType):
		for chunk in self.data.chunks:
			if isinstance(chunk, chunkType):
				return chunk
		return None
		
	def IterChunk(self, chunkType):
		for chunk in self.data.chunks:
			if isinstance(chunk, chunkType):
				yield chunk


	def Reset(self):
		# Create a new Collada document
		self.colladaDocument = collada.DaeDocument(debugMode)
		daeAsset = collada.DaeAsset()
		daeAsset.upAxis = 'Z_UP'
		daeAsset.created = datetime.datetime.today()
		daeAsset.modified = datetime.datetime.today()
		daeAsset.unit = collada.DaeUnit()
		daeAsset.unit.name = 'centimeter'
		daeAsset.unit.meter = '0.01'
		daeContributor = collada.DaeContributor()
		daeContributor.author = 'microkong'
		daeContributor.authoringTool = 'cgf2collada'
		daeContributor.sourceData = ''
		daeAsset.contributors.append(daeContributor)
		
		self.colladaDocument.asset = daeAsset
		
		daeScene = collada.DaeScene()

		daeInstanceVisualScene = collada.DaeVisualSceneInstance()
		daeInstanceVisualScene.object = self.CreateScene()
		
		daeScene.iVisualScenes.append(daeInstanceVisualScene)
		
		self.colladaDocument.scene = daeScene

		self.ids = []
		self.boneMap = {}

		
	def CreateScene(self):
		self.daeVisualScene = collada.DaeVisualScene()
		self.daeVisualScene.id = self.daeVisualScene.name = self.CreateID("CGF",'-Scene')
		self.colladaDocument.visualScenesLibrary.AddItem(self.daeVisualScene)
		return self.daeVisualScene
		
	
	def ReadCgf(self, cgfPath):
		stream = open(cgfPath, 'rb')
		self.data = CgfFormat.Data()
		self.data.read(stream)
		stream.close()
		if self.debugMode:
			opath = cgfPath[cgfPath.rfind('\\')+1:]+'.txt'
			ostream = open(opath, 'wb')
			for chunk in self.data.chunks:
				ostream.write(str(chunk))
				ostream.write('\n')
			ostream.close()
		
		
	def AddSkeleton(self, cgfPath, addScene = True):
		print "Adding Skeleton"
		self.ReadCgf(cgfPath)
		daeNodes = self.ImportSkeleton()
		if addScene:
			self.daeVisualScene.nodes.append(daeNodes[0])
	
	
	def AddMesh(self, name, cgfPath):
		print "Adding Mesh", name
		self.ReadCgf(cgfPath)
		self.name = name
		self.hasAnimation = self.GetChunk(CgfFormat.BoneNameListChunk)
		daeNode = self.ImportNode()
		self.daeVisualScene.nodes.append(daeNode)
	
	
	def AddAnimation(self, name, cafPath):
		print "Adding Animation", name
		self.ReadCgf(cafPath)
		self.name = name
		self.ImportAnimations()
		
		
	def Save(self, fileName):
		self.colladaDocument.SaveDocumentToFile(fileName)
	
	
	def ImportNode(self):
		daeNode = collada.DaeNode()
		daeNode.id = daeNode.name = self.CreateID(self.name,'-Node')
		
		# Get the transformations
		mat = [[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]]
		daeNode.transforms.append([collada.DaeSyntax.MATRIX, mat])
		
		# Get the instance
		instance = collada.DaeGeometryInstance()
		daeGeometry = self.ImportMeshNode()
		bindMaterials = self.ImportMaterials()
		instance.object = daeGeometry
		instance.bindMaterials = bindMaterials
		
		if not self.hasAnimation:
			daeNode.iGeometries.append(instance)

		else:
			daeController = self.ImportSkinController(daeGeometry.id)
			
			instanceController = collada.DaeControllerInstance()
			instanceController.object = daeController
			daeNode.transforms = []
			daeNode.transforms.append([collada.DaeSyntax.TRANSLATE, [0,0,0]])
			
			daeNode.transforms.append([collada.DaeSyntax.ROTATE, [1,0,0,0]])
			daeNode.transforms.append([collada.DaeSyntax.ROTATE, [0,1,0,0]])
			daeNode.transforms.append([collada.DaeSyntax.ROTATE, [0,0,1,0]])
			
			daeNode.transforms.append([collada.DaeSyntax.SCALE, [1,1,1]])

			boneNameListChunk = self.GetChunk(CgfFormat.BoneNameListChunk)
			instanceController.skeletons.append(GetValidID(boneNameListChunk.names[0]))
			instanceController.bindMaterials = bindMaterials
			
			daeNode.iControllers.append(instanceController)
		
		# Export layer information.
		daeNode.layer = ['CGF-Layer']
		
		return daeNode
	
		
	def ImportMeshNode(self):
		daeGeometry = collada.DaeGeometry()
		daeGeometry.id = self.CreateID(self.name,'-Geometry')
		
		daeMesh = collada.DaeMesh() 			   
		
		meshChunk = self.GetChunk(CgfFormat.MeshChunk)
		
		daeSource = collada.DaeSource()
		daeSource.id = self.CreateID(daeGeometry.id,'-Position')
		daeFloatArray = collada.DaeFloatArray()
		daeFloatArray.id = self.CreateID(daeSource.id,'-array')
		daeSource.source = daeFloatArray
		daeSource.techniqueCommon = collada.DaeSource.DaeTechniqueCommon()
		accessor = collada.DaeAccessor()
		daeSource.techniqueCommon.accessor = accessor
		accessor.source = daeFloatArray.id
		accessor.count = meshChunk.numVertices
		accessor.AddParam('X','float')
		accessor.AddParam('Y','float')
		accessor.AddParam('Z','float')		  
		
		daeSourceNormals = collada.DaeSource()
		daeSourceNormals.id = self.CreateID(daeGeometry.id,'-Normals')
		daeFloatArrayNormals = collada.DaeFloatArray()
		daeFloatArrayNormals.id = self.CreateID(daeSourceNormals.id,'-array')
		daeSourceNormals.source = daeFloatArrayNormals
		daeSourceNormals.techniqueCommon = collada.DaeSource.DaeTechniqueCommon()
		accessorNormals = collada.DaeAccessor()
		daeSourceNormals.techniqueCommon.accessor = accessorNormals
		accessorNormals.source = daeFloatArrayNormals.id
		accessorNormals.count = meshChunk.numVertices
		accessorNormals.AddParam('X','float')
		accessorNormals.AddParam('Y','float')
		accessorNormals.AddParam('Z','float') 
		
		daeSourceTextures = collada.DaeSource()
		daeSourceTextures.id = self.CreateID(daeGeometry.id,'-UV')
		daeFloatArrayTextures = collada.DaeFloatArray()
		daeFloatArrayTextures.id = self.CreateID(daeSourceTextures.id,'-array')
		daeSourceTextures.source = daeFloatArrayTextures
		daeSourceTextures.techniqueCommon = collada.DaeSource.DaeTechniqueCommon()
		accessorTextures = collada.DaeAccessor()
		daeSourceTextures.techniqueCommon.accessor = accessorTextures
		accessorTextures.source = daeFloatArrayTextures.id
		accessorTextures.count = meshChunk.numUvs
		accessorTextures.AddParam('S','float')
		accessorTextures.AddParam('T','float');
		
		
		daeVertices = collada.DaeVertices()
		daeVertices.id = self.CreateID(daeGeometry.id,'-Vertex')
		daeInput = collada.DaeInput()
		daeInput.semantic = 'POSITION'
		daeInput.source = daeSource.id
		daeVertices.inputs.append(daeInput)
		daeInputNormals = collada.DaeInput()
		daeInputNormals.semantic = 'NORMAL'
		daeInputNormals.source = daeSourceNormals.id
		daeInputNormals.offset = 1
		## daeVertices.inputs.append(daeInputNormals)
		daeMesh.vertices = daeVertices
		
		hasColor = False
		#Vertex colors:
		if False :
			hasColor = True
			daeSourceColors = collada.DaeSource()
			daeSourceColors.id = self.CreateID(daeGeometry.id,'-color')
			daeFloatArrayColors = collada.DaeFloatArray()
			daeFloatArrayColors.id = self.CreateID(daeSourceColors.id,'-array')
			daeSourceColors.source = daeFloatArrayColors
			daeSourceColors.techniqueCommon = collada.DaeSource.DaeTechniqueCommon()
			accessorColors = collada.DaeAccessor()
			daeSourceColors.techniqueCommon.accessor = accessorColors
			accessorColors.source = daeFloatArrayColors.id
			accessorColors.count = meshChunk.numVertices
			accessorColors.AddParam('R','float')
			accessorColors.AddParam('G','float');
			accessorColors.AddParam('B','float');
			accessorColors.AddParam('A','float');
		
		for vert in meshChunk.getVertices():
			daeFloatArray.data.append(vert.x)
			daeFloatArray.data.append(vert.y)
			daeFloatArray.data.append(vert.z)
		
		for normal in meshChunk.getNormals():
			daeFloatArrayNormals.data.append(normal.x)
			daeFloatArrayNormals.data.append(normal.y)
			daeFloatArrayNormals.data.append(normal.z)
		
		for uv in meshChunk.getUVs():
			daeFloatArrayTextures.data.append(uv[0])
			daeFloatArrayTextures.data.append(uv[1])
		
		if hasColor:
			for color in meshChunk.getColors():
				daeFloatArrayColors.data.append(color[0] / 255.0)
				daeFloatArrayColors.data.append(color[1] / 255.0)
				daeFloatArrayColors.data.append(color[2] / 255.0)
				daeFloatArrayColors.data.append(color[3] / 255.0)
			
		daeTrianglesDict = dict()
		
		# Loop trough all the faces
		meshFaces = meshChunk.getTriangles()
		meshMaterialIndices = meshChunk.getMaterialIndices()
		meshUVTriangles = meshChunk.getUVTriangles()
		for faceIdx in xrange(meshChunk.getNumTriangles()):
			face = meshFaces.next()
			matIndex = meshMaterialIndices.next()
			uvFace = meshUVTriangles.next()
			
			# Create a new function which adds vertices to a list.
			def AddVerts(verts, prlist):
				prevVert = None
				lastVert = verts[-1]
				for v_index in range(len(verts)):
					# Get the vertice
					vert = verts[v_index]
					# Add the vertice to the end of the list.
					prlist.append(vert)
					prlist.append(vert)
					if hasColor:
						prlist.append(vert)
					prlist.append(uvFace[v_index])
					
					# Update the prevVert vertice.
					prevVert = vert
					
			# Iff a Triangle Item for the current material not exists, create one.
			daeTrianglesDict.setdefault(matIndex, collada.DaeTriangles())
			# Add al the vertices to the triangle list.
			AddVerts(face, daeTrianglesDict[matIndex].triangles)
			# Update the vertice count for the trianglelist.
			daeTrianglesDict[matIndex].count += 1
		
		daeInput = collada.DaeInput()
		daeInput.semantic = 'VERTEX'
		daeInput.offset = 0
		daeInput.source = daeVertices.id
		
		daeInputUV = collada.DaeInput()
		daeInputUV.semantic = 'TEXCOORD'
		daeInputUV.offset = 2
		daeInputUV.source = daeSourceTextures.id

		if hasColor:
			daeInputColor = collada.DaeInput()
			daeInputColor.semantic = 'COLOR'
			daeInputColor.offset = 3
			daeInputColor.source = daeSourceColors.id

		
		meshMtls = []			
		for chunk in self.IterChunk(CgfFormat.MtlChunk):
			meshMtls.append(chunk)
		
		for k, daeTriangles in daeTrianglesDict.iteritems():
			daeTriangles.material = GetValidID(meshMtls[k].name)

			offsetCount = 0
			daeInput.offset = offsetCount			
			daeTriangles.inputs.append(daeInput)			
			offsetCount += 1
			
			daeInputNormals.offset = offsetCount
			daeTriangles.inputs.append(daeInputNormals)
			offsetCount += 1
			
			daeInputUV.offset = offsetCount				
			daeTriangles.inputs.append(daeInputUV)
			offsetCount += 1
			if hasColor:
				daeInputColor.offset = offsetCount
				daeTriangles.inputs.append(daeInputColor)
				offsetCount += 1
			daeMesh.primitives.append(daeTriangles)
		
		daeMesh.sources.append(daeSource)
		daeMesh.sources.append(daeSourceNormals)		
		daeMesh.sources.append(daeSourceTextures)
		if hasColor:
			daeMesh.sources.append(daeSourceColors)
		
		daeGeometry.data = daeMesh
		
		self.colladaDocument.geometriesLibrary.AddItem(daeGeometry)
		return daeGeometry

		
	def ImportMaterials(self):
		bindMaterials = []
		daeBindMaterial = collada.DaeFxBindMaterial()

		for mtlChunk in self.IterChunk(CgfFormat.MtlChunk):
			if mtlChunk.name.find("nouvmap") != -1:
				continue
			instance = collada.DaeFxMaterialInstance()
			daeMaterial = self.colladaDocument.materialsLibrary.FindObject(GetValidID(mtlChunk.name))
			if daeMaterial is None:
				daeMaterial = self.ImportMaterial(mtlChunk)
			instance.object = daeMaterial
			daeBindMaterial.techniqueCommon.iMaterials.append(instance)

		# now we have to add this bindmaterial to the intance of this geometry
		bindMaterials.append(daeBindMaterial)

		return bindMaterials
	

	def ImportMaterial(self, mtlChunk):
		daeMaterial = collada.DaeFxMaterial()
		mtlName = mtlChunk.name
		if mtlName.find('(') != -1:
			mtlName = mtlName[:mtlName.find('(')]
		mtlName = GetValidID(mtlName)
		daeMaterial.id = daeMaterial.name = self.CreateID(mtlName, '-Material')
		
		instance = collada.DaeFxEffectInstance()
		daeEffect = self.colladaDocument.effectsLibrary.FindObject(mtlName+'-fx')
		if daeEffect is None:
			daeEffect = collada.DaeFxEffect()
			daeEffect.id = daeEffect.name = self.CreateID(mtlName, '-fx')

			tex_name = mtlName + "-texD"
			self.AddImageTexture(daeEffect, tex_name, mtlChunk.texD)
			
			shader = self.GenerateShader(mtlChunk, daeEffect.profileCommon.technique.shader)
			daeEffect.AddShader(shader)
			
			self.colladaDocument.effectsLibrary.AddItem(daeEffect) 		   
		instance.object = daeEffect
		
		daeMaterial.iEffects.append(instance)
		
		self.colladaDocument.materialsLibrary.AddItem(daeMaterial)
		return daeMaterial


	def AddImageTexture(self, daeEffect, tex_name, texture):
		#creating surface
		daeSurfaceParam = collada.DaeFxNewParam()
		surfaceId = self.CreateID(tex_name,'-surface')
		daeSurfaceParam.sid = surfaceId

		daeSurface = collada.DaeFxSurface()
		daeSurfaceParam.surface = daeSurface
		daeSurface.initfrom = tex_name + "-img"
		daeEffect.profileCommon.newParams.append(daeSurfaceParam)

		#creating Sampler
		daeSamplerParam = collada.DaeFxNewParam()
		samplerId = self.CreateID(tex_name,'-sampler')
		daeSamplerParam.sid = samplerId

		daeSampler = collada.DaeFxSampler2D()

		daeSamplerParam.sampler = daeSampler
		daeSampler.source.value = surfaceId
		daeEffect.profileCommon.newParams.append(daeSamplerParam)

		shader = collada.DaeFxShadeLambert()
		daeImage = self.colladaDocument.imagesLibrary.FindObject(tex_name)
		if daeImage is None: # Create the image
			daeImage = collada.DaeImage()
			daeImage.id = daeImage.name = tex_name + "-img"

			daeImage.initFrom = GetValidTexturePath(texture.longName)
			self.colladaDocument.imagesLibrary.AddItem(daeImage)
			daeTexture = collada.DaeFxTexture()
			daeTexture.texture = samplerId
			shader.AddValue(collada.DaeFxSyntax.DIFFUSE, daeTexture)

		daeEffect.AddShader(shader)
		return

		
	def GenerateShader(self, mtlChunk, updateShader):
		shader = updateShader
		previousDiffuse = None

		if shader != None:
			try:
				previousDiffuse = shader.diffuse;
			except:
				pass
		
		shader = collada.DaeFxShadePhong()
		shader.AddValue(collada.DaeFxSyntax.DIFFUSE, IRGB2List(mtlChunk.colD))
		shader.AddValue(collada.DaeFxSyntax.TRANSPARENCY, mtlChunk.opacity)
		shader.AddValue(collada.DaeFxSyntax.TRANSPARENT, [1,1,1,1])

		shader.AddValue(collada.DaeFxSyntax.SPECULAR, IRGB2List(mtlChunk.colS))
		shader.AddValue(collada.DaeFxSyntax.SHININESS, mtlChunk.specShininess)

#		shader.AddValue(collada.DaeFxSyntax.EMISSION, [col * bMaterial.getEmit() for col in white] + [1])
		shader.AddValue(collada.DaeFxSyntax.AMBIENT, IRGB2List(mtlChunk.colA))
#		shader.AddValue(collada.DaeFxSyntax.REFLECTIVE, bMaterial.getMirCol() + [1])
#		shader.AddValue(collada.DaeFxSyntax.REFLECTIVITY, bMaterial.getRayMirr())

		if previousDiffuse != None:
			shader.diffuse = previousDiffuse

		return shader

	
	def ImportSkinController(self, meshName):
		meshChunk = self.GetChunk(CgfFormat.MeshChunk)
		boneNameListChunk = self.GetChunk(CgfFormat.BoneNameListChunk)
		boneInitialPosChunk = self.GetChunk(CgfFormat.BoneInitialPosChunk)
		
		daeController = collada.DaeController()
		daeController.id = self.CreateID(meshName,"-skin")
		# Create a skin
		daeController.skin = daeSkin = collada.DaeSkin()
		daeSkin.source = meshName
		
		# Set the bindshapematrix
		mat = [[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]]
		daeSkin.bindShapeMatrix = mat
		
		# Create the joints elements
		daeSkin.joints = collada.DaeJoints()
		# Create the vertexWeights element
		daeSkin.vertexWeights = collada.DaeVertexWeights()
		
		# Create the source for the joints
		jointSource = collada.DaeSource()
		jointSource.id = self.CreateID(daeController.id, "-joints")
		jointSource.techniqueCommon = collada.DaeSource.DaeTechniqueCommon()
		jointSource.source = jointSourceArray = collada.DaeIDREFArray()
		jointSourceArray.id = self.CreateID(jointSource.id, "-array")
		jointSource.techniqueCommon.accessor = jointAccessor = collada.DaeAccessor()		
		jointAccessor.AddParam("JOINT",collada.DaeSyntax.IDREF)
		jointAccessor.source = jointSource.id
		daeSkin.sources.append(jointSource)
		# And the input for the joints
		jointInput = collada.DaeInput()
		jointInput.semantic = "JOINT"
		jointInput.source = jointSource.id
		jointInput.offset = 0
		
		jointInput2 = collada.DaeInput()
		jointInput2.semantic = "JOINT"
		jointInput2.source = jointSource.id
		
		# Create the source for the weights
		weightSource = collada.DaeSource()
		weightSource.id = self.CreateID(daeController.id, "-weights")
		weightSource.techniqueCommon = collada.DaeSource.DaeTechniqueCommon()
		weightSource.source = weightSourceArray = collada.DaeFloatArray()
		weightSourceArray.id = self.CreateID(weightSource.id, "-array")
		weightSource.techniqueCommon.accessor = weightAccessor = collada.DaeAccessor()		
		weightAccessor.AddParam("WEIGHT","float")
		weightAccessor.source = weightSource.id
		daeSkin.sources.append(weightSource)
		# And the input for the weights
		weightInput = collada.DaeInput()
		weightInput.semantic = "WEIGHT"
		weightInput.source = weightSource.id
		weightInput.offset = 1
		
		daeSkin.joints.inputs.append(jointInput2)
		daeSkin.vertexWeights.inputs.append(jointInput)
		daeSkin.vertexWeights.inputs.append(weightInput)
		
		poseSource = collada.DaeSource()
		poseSource.id = self.CreateID(daeController.id,"-poses")
		poseSource.techniqueCommon = collada.DaeSource.DaeTechniqueCommon()
		poseSource.source = poseSourceArray = collada.DaeFloatArray()
		poseSourceArray.id = self.CreateID(poseSource.id,"-array")
		poseSource.techniqueCommon.accessor = poseAccessor = collada.DaeAccessor()
		poseAccessor.AddParam("","float4x4")
		poseAccessor.stride = 16
		poseAccessor.source = poseSource.id
		daeSkin.sources.append(poseSource)
		# Add the input for the poses
		poseInput = collada.DaeInput()
		poseInput.semantic = "INV_BIND_MATRIX"
		poseInput.source = poseSource.id
		
		# Add this input to the joints
		daeSkin.joints.inputs.append(poseInput)
		
		for name in boneNameListChunk.names:
			adjustedName = GetValidID(name)
			if len(adjustedName) > 0 and not adjustedName[0].isalpha():
				adjustedName = "i"+adjustedName
			jointSourceArray.data.append(adjustedName)
			jointAccessor.count += 1
		
		for matrix in boneInitialPosChunk.initialPosMatrices:
			invBindMatrix = CgfFormat.Matrix44()
			invBindMatrix.setIdentity()
			invBindMatrix.setMatrix33(matrix.rot)
			invBindMatrix.setTranslation(matrix.pos)
			invBindMatrix = invBindMatrix.getInverse().getTranspose()
			poseSourceArray.data.extend(invBindMatrix.asList())
			poseAccessor.count += 1
		
		weightIndex = 0
		for vertexWeight in meshChunk.vertexWeights:
			if vertexWeight.numBoneLinks == 0:
				continue
			
			daeSkin.vertexWeights.count += 1
			daeSkin.vertexWeights.vcount.append(vertexWeight.numBoneLinks)
			
			for boneLink in vertexWeight.boneLinks:
				daeSkin.vertexWeights.v.append(boneLink.bone)
				daeSkin.vertexWeights.v.append(weightIndex)				
				weightSourceArray.data.append(boneLink.blending)
				weightAccessor.count += 1
				weightIndex += 1
				
		self.colladaDocument.controllersLibrary.AddItem(daeController)
		return daeController


	def ImportSkeleton(self):
		boneAnimChunk = self.GetChunk(CgfFormat.BoneAnimChunk)
		boneNameListChunk = self.GetChunk(CgfFormat.BoneNameListChunk)
		boneInitialPosChunk = self.GetChunk(CgfFormat.BoneInitialPosChunk)
		daeNodes = []

		# Get the root bones
		rootBones = []
		boneChildren = [[] for i in xrange(boneAnimChunk.numBones)]
		for bone in boneAnimChunk.bones:
			if bone.parentId == -1:
				rootBones.append(bone)
			else:
				boneChildren[bone.parentId].append(bone.boneId)
		
		def ImportBone(boneId):
			bone = boneAnimChunk.bones[boneId]
			daeNode = collada.DaeNode()
			boneName = GetValidID(boneNameListChunk.names[boneId])
			daeNode.id = daeNode.name = daeNode.sid = self.CreateID(boneName,'-Joint')
			daeNode.type = collada.DaeSyntax.TYPE_JOINT
			daeNode.layer = ['CGF-Layer']
			self.boneMap[bone.boneNameCrc32] = daeNode
			
			mat = CgfFormat.Matrix44()
			mat.setIdentity()
			mat.setMatrix33(boneInitialPosChunk.initialPosMatrices[boneId].rot)
			mat.setTranslation(boneInitialPosChunk.initialPosMatrices[boneId].pos)
			if bone.parentId != -1:
				invParentRot = boneInitialPosChunk.initialPosMatrices[bone.parentId].rot.getInverse()
				relPos = boneInitialPosChunk.initialPosMatrices[boneId].pos - boneInitialPosChunk.initialPosMatrices[bone.parentId].pos
				relPos = relPos * invParentRot
				relRot = boneInitialPosChunk.initialPosMatrices[boneId].rot * invParentRot
				mat = CgfFormat.Matrix44()
				mat.setIdentity()
				mat.setMatrix33(relRot)
				mat.setTranslation(relPos)
			mat = mat.getTranspose()
			daeNode.transforms.append([collada.DaeSyntax.MATRIX, mat.asList()])
			
			if bone.numChildren > 0:
				for childBone in boneChildren[boneId]:
					daeNode.nodes.append(ImportBone(childBone))
			return daeNode
		
		# Only take the first root and ignore it.
		if len(rootBones) > 0 and rootBones[0].numChildren > 0:			
			daeNodes.append(ImportBone(rootBones[0].boneId))

		if len(rootBones) > 1:
			print "Please use only a single root for proper export"
			
		return daeNodes
	
	
	def ImportAnimations(self):
		boneNameListChunk = self.GetChunk(CgfFormat.BoneNameListChunk)
		timingChunk = self.GetChunk(CgfFormat.TimingChunk)
		self.secsPerTick = timingChunk.secsPerTick
		
		controllerBoneSet = set()
		i = -1
		for controllerChunk in self.IterChunk(CgfFormat.ControllerChunk):
			i += 1
			boneName = GetValidID(boneNameListChunk.names[i])
			boneNode = None
			if controllerChunk.ctrlId in self.boneMap:
				boneNode = self.boneMap[controllerChunk.ctrlId]
			else:
				for b in self.boneMap.itervalues():
					if b.name == boneName:
						boneNode = b
						break
			if boneNode == None:
#				print i, controllerChunk.ctrlId, boneNameListChunk.names[i], "Warning! Bone not found."
				continue
			controllerBoneSet.add(boneNode)
			
			keyCount = controllerChunk.numKeys
			if controllerChunk.keys[0].time != 0:
				keyCount += 1

			daeAnimation = collada.DaeAnimation()
			daeAnimation.id = daeAnimation.name = self.CreateID(boneNode.id+'-matrix','-Animation')
			
			daeSourceInput = collada.DaeSource()
			daeSourceInput.id = self.CreateID(daeAnimation.id,'-input')
			daeFloatArrayInput = collada.DaeFloatArray()
			daeFloatArrayInput.id = self.CreateID(daeSourceInput.id,'-array')
			daeSourceInput.source = daeFloatArrayInput
			daeSourceInput.techniqueCommon = collada.DaeSource.DaeTechniqueCommon()
			accessorInput = collada.DaeAccessor()
			daeSourceInput.techniqueCommon.accessor = accessorInput
			accessorInput.source = daeFloatArrayInput.id
			accessorInput.count = keyCount
			accessorInput.AddParam('TIME','float')
			
			daeSourceOutput = collada.DaeSource()
			daeSourceOutput.id = self.CreateID(daeAnimation.id,'-output')
			outputArray = collada.DaeFloatArray()
			outputArray.id = self.CreateID(daeSourceOutput.id,'-array')
			daeSourceOutput.source = outputArray
			daeSourceOutput.techniqueCommon = collada.DaeSource.DaeTechniqueCommon()
			accessorOutput = collada.DaeAccessor()
			daeSourceOutput.techniqueCommon.accessor = accessorOutput
			accessorOutput.source = outputArray.id
			accessorOutput.count = keyCount
			accessorOutput.stride = 16
			
			daeSourceInterpolation = collada.DaeSource()
			daeSourceInterpolation.id = self.CreateID(daeAnimation.id,'-interpolation')
			interpolationArray = collada.DaeNameArray()
			interpolationArray.id = self.CreateID(daeSourceInterpolation.id,'-array')
			daeSourceInterpolation.source = interpolationArray
			daeSourceInterpolation.techniqueCommon = collada.DaeSource.DaeTechniqueCommon()
			accessorInterpolation = collada.DaeAccessor()
			daeSourceInterpolation.techniqueCommon.accessor = accessorInterpolation
			accessorInterpolation.source = interpolationArray.id
			accessorInterpolation.count = keyCount
			
			accessorOutput.AddParam('TRANSFORM','float4x4')
			accessorInterpolation.AddParam('INTERPOLATION','name')

			daeAnimation.sources.append(daeSourceInput)
			daeAnimation.sources.append(daeSourceOutput)
			daeAnimation.sources.append(daeSourceInterpolation)
			
			if controllerChunk.keys[0].time != 0:
				daeFloatArrayInput.data.append(0)
				outputArray.data.append(boneNode.transforms[0])
				interpolationArray.data.append('LINEAR')
				
			for key in controllerChunk.keys:
				daeFloatArrayInput.data.append(key.time * self.secsPerTick)
				mat = CgfFormat.Matrix44()
				mat.setIdentity()
				mat.setMatrix33(QuatToMatrix(key.relQuat))
				mat.setTranslation(key.relPos)
				mat = mat.getTranspose()
				for vec in mat.asList():
					for v in vec:
						outputArray.data.append(v)
				interpolationArray.data.append('LINEAR')
			
			daeSampler = collada.DaeSampler()
			daeSampler.id = self.CreateID(daeAnimation.id,"-sampler")
			daeAnimation.samplers.append(daeSampler)
			
			daeInputInput = collada.DaeInput()
			daeInputInput.semantic = 'INPUT'
			daeInputInput.source = daeSourceInput.id
			daeSampler.inputs.append(daeInputInput)
			
			daeInputOutput = collada.DaeInput()
			daeInputOutput.semantic = 'OUTPUT'
			daeInputOutput.source = daeSourceOutput.id
			daeSampler.inputs.append(daeInputOutput)
			
			daeInputInterpolation = collada.DaeInput()
			daeInputInterpolation.semantic = 'INTERPOLATION'
			daeInputInterpolation.source = daeSourceInterpolation.id
			daeSampler.inputs.append(daeInputInterpolation)
			
			daeChannel = collada.DaeChannel()
			daeChannel.source = daeSampler
			
			daeChannel.target = collada.StripString(boneNode.id) +'/matrix'
			daeAnimation.channels.append(daeChannel)
			
			self.colladaDocument.animationsLibrary.AddItem(daeAnimation)



def ConvertMesh():
	converter = Converter(debugMode)
	converter.Reset()
	converter.AddSkeleton(skeletonFile)
	for name in meshNames:
		converter.AddMesh(name, r"%s\%s.cgf" % (meshPath, name))
	converter.Save(outputMeshFile)

def ConvertAnimation(name):
	converter = Converter(debugMode)
	converter.Reset()
	converter.AddMesh(character, skeletonFile)
	converter.AddSkeleton(skeletonFile)
	converter.AddAnimation(name, r"%s\%s.caf" % (animationPath, name))
	converter.Save(r"%s\%s.dae" % (outputPath, name))

def ConvertHair(name):
	converter = Converter(debugMode)
	converter.Reset()
	converter.AddSkeleton(skeletonFile)
	boneNameListChunk = converter.GetChunk(CgfFormat.BoneNameListChunk)
	boneInitialPosChunk = converter.GetChunk(CgfFormat.BoneInitialPosChunk)
	for i in xrange(boneNameListChunk.numNames):
		if boneNameListChunk.names[i] == "Bip01 Head":
			headInitialPos = boneInitialPosChunk.initialPosMatrices[i].pos
			break
	print "Bip01 Head initial pos", headInitialPos
	converter.Reset()
	converter.AddSkeleton(r"%s\%s.cgf" % (meshPath, name))
	converter.AddMesh(name, r"%s\%s.cgf" % (meshPath, name))
	converter.Save(r"%s\%s.dae" % (outputPath, name))

def ConvertMeshAnimation(animName):
	converter = Converter(debugMode)
	converter.Reset()
	converter.AddSkeleton(skeletonFile)
	for name in meshNames:
		converter.AddMesh(name, r"%s\%s.cgf" % (meshPath, name))
	converter.AddAnimation(animName, r"%s\%s.caf" % (animationPath, animName))
	converter.Save(outputMeshFile)


aionPath = r"E:\3D\AION"
outputPath = r"E:\3D\AION"
character = "lf"
characterPath = r"%s\Objects\pc\%s" % (aionPath, character)
meshPath = characterPath + r"\mesh"
animationPath = characterPath + r"\animation"
texturePath = "mesh_textures"	# the meshes+textures in "mesh" folder is too huge, so i put textures to "mesh_textures"
skeletonFile = r"%s\%s.cgf" % (meshPath, character)
outputMeshFile = r"%s\%s.dae" % (outputPath, character)

meshNames = [
	"lf001_head",
#	"lf001_emblem", 
#	"lfrb_c001_body", "lfrb_c001_leg", "lfrb_c001_hand", "lfrb_c001_foot", "lfrb_c001_shoulder",
#	"lfrb_c001_helmet",
	"lfrb_r105a_body", "lfrb_r105a_leg", "lfrb_r105a_hand", "lfrb_r105a_foot", "lfrb_r105a_shoulder",
#	"lfch_c105_body", "lfch_c105_leg", "lfch_c105_hand", "lfch_c105_foot", "lfch_c105_shoulder", 
#	"lflt_r104_body", "lflt_r104_leg", "lflt_r104_hand", "lflt_r104_foot", "lflt_r104_shoulder",
#	"lfpl_r102_body", "lfpl_r102_leg", "lfpl_r102_hand", "lfpl_r102_foot", "lfpl_r102_shoulder", 
]

animationNames = [
#	"lf_nidle_001_loop",
#	"lf_nidle_002_loop",
#	"lf_nwalk_001_loop", 
#	"lf_nrun_001_loop",
#	"lf_ndance_001",
#	"lf_ndance_002"
#	"lf_cattack_2hand_001",
#	"lf_cidle_staff_001_loop",
#	"lf_cidle_1hand_001_loop",
#	"lf_cidle_hth_001_loop"
]

# Convert some meshes with skin
#ConvertMesh()

# Convert hair
#ConvertHair("lf001_hair")

# Convert animations, one .dae per animation
#for name in animationNames:
#	ConvertAnimation(name)

# Convert some meshes and one animation to a single .dae
ConvertMeshAnimation("lf_nidle_001_loop")
