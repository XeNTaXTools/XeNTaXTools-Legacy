from inc_noesis import *


def registerNoesisTypes():
	handle = noesis.register("Fate Grand Order Arcade", "_obj.bin")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadModel(handle, noepyLoadModel)
	return 1


def noepyCheckType(data):
	if len(data) < 8:
		return 0
	bs = NoeBitStream(data)

	if bs.readInt() != int(84288768):
		return 0
	else:
		return 1

class ObjData:
    def __init__(self) -> None:
        self.UNK4LOC = int()
        self.UNK4Count = int()
        self.AttribLOC = int()
        self.VLOC = int()
        self.FLOC = int()
        self.SubCount = int()
        self.SkelLOC = int()

class Attribs:
    def __init__(self) -> None:
        self.VertexPush = int()
        self.VertexCount = int()
        self.FacePush = int()
        self.FaceCount = int()
        self.UNKInt = []
        self.UNKF = []

class UNK4Data:
    def __init__(self) -> None:
        self.UNK1 = int()
        self.UNK2 = int()
        self.DataType = int()
        self.VStride = int()

def GetNames(bs, LOC, C):
    Names = []
    bs.seek(LOC)
    for Z in range(0, C):
        M = bs.readInt64()
        B = bs.tell()
        bs.seek(M)
        Names.append(bs.readString())
        bs.seek(B)
    return Names

def GetUNK4(bs, LOC, Count):
    bs.seek(LOC)
    UNK4List = []
    for X in range(0, Count):
        U = UNK4Data()
        #Blank = bs.readInt64()
        bs.seek(12, 1)
        U.UseCount = bs.readInt()
        U.UNK2 = bs.readInt64()
        U.DataType = bs.readInt()
        U.VStride = bs.readInt()
        bs.seek(48, 1)
        UNK4List.append(U)
    return UNK4List

def GetAttrib(bs, LOC, Count):
    AList = []
    bs.seek(LOC)
    for Q in range(0, Count):
        A = Attribs()
        Blank = bs.readInt()
        VertexPush = bs.readInt()
        FaceCount = bs.readInt()
        FacePush = bs.readInt()
        VertexCount = bs.readInt()
        A.UNKInt = bs.read(2*'I')
        A.UNKF = bs.read(4*'f')
        bs.seek(164,1)
        A.VertexCount = VertexCount
        A.VertexPush = VertexPush
        A.FaceCount = FaceCount
        A.FacePush = FacePush
        AList.append(A)
        #print(A.__dict__)
    return AList

def GetSkel(bs, LOC):
    boneList = []
    bs.seek(LOC)
    BoneCount = bs.readInt()
    strc = bs.readInt()
    pad = (4 - strc % 4) % 4
    SkelSource = bs.readBytes(strc).decode("ASCII").rstrip("\0")
    bs.seek(pad, 1)
    MatList = []
    BoneNames = []
    ParentList = []
    Sort = []
    Sort2 = []
    for B in range(0, BoneCount):
        rot = NoeQuat.fromBytes(bs.readBytes(16)).transpose()
        bs.seek(0, 1)
        pos = NoeVec3.fromBytes(bs.readBytes(12))
        pos[0] = pos[0]
        pos[1] = pos[1]
        pos[2] = pos[2]
        mat = rot.toMat43()
        mat.__setitem__(3,(pos[0],pos[1],pos[2]))
        MatList.append(mat)
        bs.seek(76, 1)
        #MatList.append(bs.readBytes(104))
    for P in range(0, BoneCount):
        Parent = bs.readInt()
        ParentList.append(Parent)
        #print(Parent)
    for PP in range(0, BoneCount):
        ID = bs.readInt()
        Sort.append(ID)
    for K in range(BoneCount):
        print(ParentList[K], Sort[K])
    for N in range(0, BoneCount):
        BID = bs.readInt()
        BoneC = bs.readInt()
        BoneName = bs.readBytes(BoneC).decode("ASCII").rstrip("\0")
        bs.seek((4 - BoneC % 4) % 4, 1)
        BoneNames.append(BoneName)
        print(BoneName, BID)
        Sort2.append(BID)
    # for Z in range(0, BoneCount):
    #     T = Sort[Z]
    #     print(BoneNames[T])
    for Q in range(0, BoneCount):
        CB = Sort2[Q]
        CCB = Sort[Q] - 1
        boneList.append(NoeBone(Q, "bone_"+str(Q), MatList[Q], None, ParentList[Q]))
    return boneList
    

def noepyLoadModel(data, mdlList):
    bs = NoeBitStream(data)
    ctx = rapi.rpgCreateContext()
    bs.seek(4)
    ObjCount = bs.readInt()
    ObjDataTableLoc = bs.readInt64()
    NameLoc = bs.readInt64()
    Names = GetNames(bs, NameLoc, ObjCount)
    bs.seek(ObjDataTableLoc)
    ObjTables = []
    for Z in range(0, ObjCount):
        ObjTables.append(bs.readInt64())
    #print(ObjTables, Names)
    ObjList = []
    for M in range(0, len(ObjTables)):
        BlockLOC = ObjTables[M]
        bs.seek(BlockLOC)
        UNK0 = bs.readInt64()
        UNK1 = bs.readInt64()
        UNK2 = bs.readInt64()
        UNK4Count = bs.readInt64()
        UNK4 = bs.readInt64()+BlockLOC
        UNK5 = bs.readInt64()
        AttribLOC = bs.readInt64()+BlockLOC
        UNK7 = bs.readInt64()
        VertexLOC = bs.readInt64()+BlockLOC
        UNK9 = bs.readInt64()
        FaceLOC = bs.readInt64()+BlockLOC
        bs.seek(80, 1)
        Skel = bs.readInt64()+BlockLOC
        #print(Names[M], UNK4, AttribLOC, VertexLOC, FaceLOC)
        O = ObjData()
        O.AttribLOC = AttribLOC
        O.UNK4LOC = UNK4
        O.UNK4Count = UNK4Count
        O.VLOC = VertexLOC
        O.FLOC = FaceLOC
        O.SubCount = UNK5
        O.SkelLOC = Skel
        ObjList.append(O)
        print(O.__dict__)
    for M in range(0, len(ObjList)):
        C = ObjList[Z]
        U = GetUNK4(bs, C.UNK4LOC, C.UNK4Count)
        A = GetAttrib(bs, C.AttribLOC, C.SubCount)
        boneList = GetSkel(bs, C.SkelLOC)
        Add = -1
        for B in range(0, len(U)):
            UC = U[B]
            print(UC.__dict__)
            for X in range(0, UC.UseCount):
                Add += 1
                CA = A[Add]
                print(CA.__dict__)
                bs.seek(C.VLOC+CA.VertexPush)
                VertBlock = bs.readBytes(CA.VertexCount*UC.VStride)
                bs.seek(C.FLOC+CA.FacePush)
                FaceBlock = bs.readBytes(CA.FaceCount*2)
                #print(CA.FaceCount, CA.VertexCount)
                print(M, Add)
                rapi.rpgSetName(Names[M]+"_"+str(Add))
                # normals = bytearray()
                # for n in range(0, CA.VertexCount):
                #     m_normal = VertBlock[n*UC.VStride+12:n*UC.VStride+12+4]
                #     m_normal = int.from_bytes(m_normal, "little")
                #     X = (m_normal << 22) >> 22
                #     Y = (m_normal << 12) >> 22
                #     Z = (m_normal << 2) >> 22 
                #     normals+=X.to_bytes(4, 'little')
                #     normals+=Y.to_bytes(4, 'little')
                #     normals+=Z.to_bytes(4, 'little')
                #     #normals+= VertBlock[x*UC.VStride+12:x*UC.VStride+12+4]
                # #norm = rapi.decodeNormals32(normals, 4, 10, 10, 10, NOE_LITTLEENDIAN)
                # norm = normals
                # rapi.rpgBindNormalBuffer(norm, noesis.RPGEODATA_HALFFLOAT, 12)
                rapi.rpgBindPositionBufferOfs(VertBlock, noesis.RPGEODATA_FLOAT, UC.VStride, 0)
                #rapi.rpgBindNormalBufferOfs(VertBlock, noesis.RPGEODATA_UBYTE, UC.VStride, 14)
                if UC.VStride > 20:
                    UV = []
                    for n in range(0, CA.VertexCount):
                        UVU = int.from_bytes(VertBlock[n*UC.VStride+20:n*UC.VStride+20+2], 'little')
                        UVV = int.from_bytes(VertBlock[n*UC.VStride+22:n*UC.VStride+22+2], 'little')
                        UVU = UVU/65535
                        UVV = UVV/65535
                        UV.append(UVU)
                        UV.append(UVV)
                    UV = struct.pack('f'*len(UV), *UV)
                    rapi.rpgBindUV1Buffer(UV, noesis.RPGEODATA_FLOAT, 8)
                    # rapi.rpgSetUVScaleBias((CA.UNKInt[0]/255,CA.UNKInt[1]/255,float(0)), None)
                if UC.VStride > 25:
                    pass
                    # rapi.rpgBindColorBufferOfs(VertBlock, noesis.RPGEODATA_UBYTE, UC.VStride, 24, 4)
                else:
                    VCOL = []
                    for v in range(0, CA.VertexCount):
                        VCOL.append(float(0.0))
                        VCOL.append(float(0.0))
                        VCOL.append(float(0.0))
                        VCOL.append(float(0.0))
                    VCB = struct.pack('f'*len(VCOL), *VCOL)
                    # rapi.rpgBindColorBuffer(VCB, noesis.RPGEODATA_FLOAT, 16, 4)
                rapi.rpgCommitTriangles(FaceBlock, noesis.RPGEODATA_USHORT, CA.FaceCount, noesis.RPGEO_TRIANGLE_STRIP, 1)




    




    



    mdl = rapi.rpgConstructModel()
    boneList = rapi.multiplyBones(boneList)
    mdl.setBones(boneList)
    # mdl.setAnims(Anim)
    mdlList.append(mdl)
    return 1