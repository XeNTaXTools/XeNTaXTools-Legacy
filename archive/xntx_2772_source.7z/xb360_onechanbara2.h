#ifndef __XENTAX_ONECHANBARA2_H
#define __XENTAX_ONECHANBARA2_H

#define XB360_ONECHANBARA2_BEGIN namespace XB360 { namespace Onechanbara2 {
#define XB360_ONECHANBARA2_END }};

XB360_ONECHANBARA2_BEGIN

bool extract(void);
bool extract(const char* pathname);

XB360_ONECHANBARA2_END

#endif
