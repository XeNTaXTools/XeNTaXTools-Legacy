#ifndef __PS3_NI_NO_KUNI_H
#define __PS3_NI_NO_KUNI_H

#define PS3_NINOKUNI_BEGIN namespace PS3 { namespace NiNoKuni {
#define PS3_NINOKUNI_END }};

PS3_NINOKUNI_BEGIN

bool extract(void);
bool extract(const char* pathname);

PS3_NINOKUNI_END

#endif
