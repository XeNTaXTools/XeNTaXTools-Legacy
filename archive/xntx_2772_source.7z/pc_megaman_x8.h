#ifndef __XENTAX_MEGAMAN_X8_H
#define __XENTAX_MEGAMAN_X8_H

#define PC_MEGAMAN_X8_BEGIN namespace PC { namespace MegaManX8 {
#define PC_MEGAMAN_X8_END }};

PC_MEGAMAN_X8_BEGIN

bool extract(void);
bool extract(const char* pathname);

PC_MEGAMAN_X8_END

#endif
