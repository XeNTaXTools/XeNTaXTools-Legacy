#ifndef __XENTAX_HEROESPHANTASIA_H
#define __XENTAX_HEROESPHANTASIA_H

#define PSP_HEROESPHANTASIA_BEGIN namespace PSP { namespace HeroesOfPhantasia {
#define PSP_HEROESPHANTASIA_END }};

PSP_HEROESPHANTASIA_BEGIN

bool extract(void);
bool extract(const char* pathname);

PSP_HEROESPHANTASIA_END

#endif
