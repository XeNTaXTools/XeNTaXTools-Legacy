#ifndef __XENTAX_ZLIB_H
#define __XENTAX_ZLIB_H

bool CompressZLIB(std::ifstream& ifile, std::ofstream& ofile);
bool CompressZLIB(std::ifstream& ifile, std::ofstream& ofile, int level);

bool DecompressZLIB(std::ifstream& ifile, std::ofstream& ofile);
bool DecompressZLIB(std::ifstream& ifile, std::ofstream& ofile, int windowBits);
bool DecompressZLIB(std::ifstream& ifile, size_t n, std::ofstream& ofile, int windowBits);

#endif
