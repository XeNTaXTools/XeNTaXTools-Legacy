#include "xentax.h"
#include "x_amc.h"

bool GeometryToLWO(const char* path, const char* name, const ADVANCEDMODELCONTAINER& data)
{
 return true;
}