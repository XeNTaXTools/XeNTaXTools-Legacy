#ifndef __XENTAX_PREVIEW_H
#define __XENTAX_PREVIEW_H

BOOL PreviewDialog(void);

#endif
