#ifndef __XENTAX_OBJ_H
#define __XENTAX_OBJ_H

//bool GeometryToOBJ(const char* path, const char* name, const SIMPLEMODELCONTAINER& data);

#endif
