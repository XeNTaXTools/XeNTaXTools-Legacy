#ifndef __XENTAX_FILE_H
#define __XENTAX_FILE_H

/*
** FILENAME FUNCTIONS
*/

std::string GetModulePathname(void);
std::string GetShortFilename(const std::string& filename);
std::string GetShortFilenameWithoutExtension(const std::string& filename);
std::string GetPathnameFromFilename(const std::string& filename);
std::string GetExtensionFromFilename(const std::string& filename);
bool HasExtension(const std::string& filename, const std::string& extension);

/*
** FILE LISTING FUNCTIONS
** (1) LOOKS IN PATH OF EXE
** (2) LOOKS IN PATH OF CHOICE
*/

bool BuildFilenameList(std::deque<std::string>& namelist, const char* fext);
bool BuildFilenameList(std::deque<std::string>& namelist, const char* fext, const char* rootname);

/*
** FILE SEARCHING FUNCTIONS
*/
bool SearchFileForSignature(std::ifstream& ifile, const char* signature, size_t sigsize, std::deque<uint64>& offsets);
bool SearchFileForSignature(std::ifstream& ifile, const char* signature, size_t sigsize, size_t alignment, std::deque<uint64>& offsets);

#endif
