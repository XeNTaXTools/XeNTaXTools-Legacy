#ifndef __XENTAX_GUNDAM_CROSSFIRE_H
#define __XENTAX_GUNDAM_CROSSFIRE_H

#define PS3_GUNDAM_CROSSFIRE_BEGIN namespace PS3 { namespace GundamCrossfire {
#define PS3_GUNDAM_CROSSFIRE_END }};

PS3_GUNDAM_CROSSFIRE_BEGIN

bool extract(void);
bool extract(const char* pathname);

PS3_GUNDAM_CROSSFIRE_END

#endif
