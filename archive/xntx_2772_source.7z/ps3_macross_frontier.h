#ifndef __XENTAX_MACROSS_FRONTIER_H
#define __XENTAX_MACROSS_FRONTIER_H

#define PS3_MACROSS_FRONTIER_BEGIN namespace PS3 { namespace MacrossFrontier {
#define PS3_MACROSS_FRONTIER_END }};

PS3_MACROSS_FRONTIER_BEGIN

bool extract(void);
bool extract(const char* pathname);

PS3_MACROSS_FRONTIER_END

#endif
