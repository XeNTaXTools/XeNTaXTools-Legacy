from inc_noesis import *
import noesis
import rapi
import os

def registerNoesisTypes():
    handle = noesis.register("Unity model", ".43")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    return 1   

def noepyLoadModel(data, mdlList):
    ctx = rapi.rpgCreateContext()
    rapi.setPreviewOption("setAngOfs","0 90 0")        #set the default preview angle        
    bs = NoeBitStream(data)
    bs.seek(0x50, NOESEEK_ABS)                        
    FCount = bs.readUInt() // 2                           #indices count
    print(FCount, "face count")
    IBuf = bs.readBytes(FCount * 2)                       #multiply by 2 for word, 4 for dword indices 
    bs.seek(0x30, NOESEEK_REL)                        
    VCount = bs.readUInt() // 48                               #face indices count
    print(VCount, "vertex count")
    VBytes = 48                                       #vertex stride
    VBuf = bs.readBytes(VCount * VBytes)
    rapi.rpgBindPositionBufferOfs(VBuf, noesis.RPGEODATA_FLOAT, VBytes, 0)   #position of vertices
    rapi.rpgBindNormalBufferOfs(VBuf, noesis.RPGEODATA_FLOAT, VBytes, 12)   #normals -optional
    rapi.rpgBindUV1BufferOfs(VBuf, noesis.RPGEODATA_FLOAT, VBytes, 24)   #UVs
    checkTri = int(FCount % 3)                            #check if FCount is evenly divisible by 3,
    print(checkTri, "div by 3 check")
    if checkTri != 0:                                     
        rapi.rpgCommitTriangles(IBuf, noesis.RPGEODATA_SHORT, FCount, noesis.RPGEO_TRIANGLE_STRIP, 1)
    else:
        rapi.rpgCommitTriangles(IBuf, noesis.RPGEODATA_SHORT, FCount, noesis.RPGEO_TRIANGLE, 1)
    mdl = rapi.rpgConstructModel()                                                          
    mdlList.append(mdl)
    rapi.rpgClearBufferBinds()
    return 1