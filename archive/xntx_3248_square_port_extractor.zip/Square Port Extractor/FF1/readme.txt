======================================================
        FF1 PSX file extractor/compressor 1.0
                        by Mat
                      17/08/2004
======================================================
------------------------------------------------------
0 - INDEX 
------------------------------------------------------

1 - Intro
2 - Usage
3 - Technical Notes
4 - Progress
5 - Future Progresses
6 - Thanks
7 - Disclaimer


------------------------------------------------------
1 - INTRO
------------------------------------------------------

This program was written to extract and compress the
compressed files of Final Fantasy I PSX (for example
SHOP.PAK), if you want to translate completely these
games this is the program for you! ;)

NOTE: the language of the program is Italian, if you
      have any problem whit program messages email me
      at mattia.d.r@libero.it


------------------------------------------------------
2 - USAGE
------------------------------------------------------

This is a command line tool used with the DOS prompt
(Start\Programs or Start\Programs\Accessories).


SHOW THE HELP
 
 Run the program without parameters


EXTRACT A FILE

 To extract a file type:
  extFF1 -e source destination


COMPRESS A FILE

 To compress a file type:
  extFF1 -c source destination


------------------------------------------------------
3 - TECHNICAL NOTES
------------------------------------------------------

The compression is a LZSS variant.
The compression of this program is slow, but is
the maximum possible.


------------------------------------------------------
4 - PROGRESS
------------------------------------------------------

Version 1.0

- First public version


Versions 0.9beta
- Not public version


------------------------------------------------------
5 - FUTURE PROGRESS
------------------------------------------------------

- Bugs Correction
- Translation of the program and source comments
  in English

------------------------------------------------------
6 - THANKS
------------------------------------------------------

^Anyone who will use or publish this program :)
^Gemini for asking me to write this compressor


------------------------------------------------------
7 - DISCLAIMER
------------------------------------------------------

This program must be used only for LEGAL intents!
Use this program to your risk and danger :).
This program can be freely distributed. I only
recommend to distribute it in the state in
which it is (don't modify the readme etc etc).
Thanks.

Final Fantasy I, Squaresoft and the relative names
are trademarks of the relative owners.


Mat
mattia.d.r@libero.it
http://www.matzone.altervista.org/
Member of SadNES cITy: http://www.sadnescity.it/
