/* FF1 PSX file extractor/compressor 1.0 by Mat

ENGLISH

This program was written to extract and compress the
compressed files of Final Fantasy I PSX, for example
the file SHOP.PAK.
For more information see the readme.

This program must be used only for LEGAL intents!
Use this program to your risk and danger :).
This program can be freely distributed. I only
recommend to distribute it in the state in
which it is (don't modify the readme etc etc).
Thanks.

Final Fantasy I, Squaresoft and the relative names
are trademarks of the relative owners.

Mat - 21/09/2003
E-mail: mattia.d.r@libero.it
Sito:   http://www.matzone.altervista.org
Membro dei SadNES cITy: http://www.sadnescity.it
Public Release: 17/08/2004


ITALIANO

Questo programma e' stato scritto per estrarre e comprimere i file compressi
di Final Fantasy I PSX, per esempio il file SHOP.PAK.
Il codice e stato scritto facendo in modo che le funzioni siano riutilizzabili
e gestiscano gli errori delle system call.
Penso di aver scritto un codice decente (a parte i numerosi sprechi di memoria)
anche se i commenti non sono molti e non spiegano granche' (ho questa cattiva
abitudine). Se qualche riga e' poco chiara contattami.
Questo programma e' stato scritto con Dev-C++ e compilato con gcc, e una
richiesta fondamentale per il funzionamento e' che i dati siano Little Endian
e che gli int siano a 4 byte,gli short a 2 byte e i char a 1 byte (e' per
questo che nelle funzioni non ho usato sizeof(int), perche' se la dimensione
fosse diversa il programma non funzionerebbe comunque).

NOTE SULLA COMPRESSIONE
Sia nella decompressione che nella compressione sono implementati 2 trick:
- overlap
- negative jump
I miei algoritmi non sono il massimo in quanto a velocita' e a consumo di
memoria, pero' dovrebbero garantire la massima compressione possibile.


Questo programma deve essere usato solo per scopi LEGALI!
Usa questo programma a tuo rischio e pericolo :).
Questo programma puo' essere liberamente distribuito.
Ti raccomando solo di distribuirlo nello stato in cui si trova.
Grazie.

Final Fantasy I, Squaresoft ed i relativi nomi sono
marchi registrati dei relativi proprietari.


Mat
mattia.d.r@libero.it
http://www.matzone.altervista.org/
Membro dei SadNES cITy: http://www.sadnescity.it/

Mat - 26/08/2003
E-mail: mattia.d.r@libero.it
Sito:   http://www.matzone.altervista.org
Membro dei SadNES cITy: http://www.sadnescity.it
Public Release: 17/08/2004
*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Grandezza del buffer per la decompressione
#define BUFFSIZE 32768

// Caratteristiche della compressione
// Grandezza di massima di una stringa compressa
#define FF1_MAXLINEA 17
// Grandezza massima del salto (11 bit)
#define FF1_JUMPMAX 2047
// Massimo recupero 3 + 31 (5 bit)
#define FF1_MREC 34
// Recupero massimo per una stringa 8 * MREC
#define FF1_RECMAX 272

int FF1_decomprimi_file(FILE *orig, FILE *dest);
/* Decomprime un file compresso di FF1 PSX
    infile:  file pointer del file compresso (verra' messo il seek a 0)
    outfile: file pointer su cui verranno accodati i dati decompressi
    
    Valore di ritorno:
    0 in caso di successo
    2 in caso di errore di lettura o di seek
    3 in caso di errore di scrittura
    
    NOTA: La funzione non chiude i file pointer passati e muove il seek
    NOTA2: La funzione stampa su stdout un avviso se la dimensione indicata
           all'inizio del file e quella del file scompresso non coincidono
*/

int FF1_comprimi_file(FILE *orig, FILE *dest);
/* Comprime un file nel formato di FF1 PSX
    infile:  file pointer del file sorgente (verra' messo il seek a 0)
    outfile: file pointer su cui verranno accodati i dati compressi
    
    Valore di ritorno:
    0 in caso di successo
    -1 nel caso di errori all'allocazione della memoria
    2 in caso di errore di lettura o di seek
    3 in caso di errore di scrittura
    
    NOTA: La funzione non chiude i file pointer passati e muove il seek
*/

int FF1_cercaprec(unsigned char *poslet, unsigned char *posiniz, unsigned char *posmax);
/* Cerca un match uguale nei byte precedenti, overlap OK
    poslet:  posizione in cui c'e' la stringa che dobbiamo cercare
    posiniz: posizione fino a cui possiamo ritornare alla ricerca di un match
    posmax:  posizione entro la quale dobbiamo fermarci nella lettura della stringa di input
    
    Valore di ritorno:
    -1 se non trova un match di almeno 3 byte
    0 - 0xFFFF nel caso trovi un match
      il valore corrisponde a (jump << 5) | (recupero - 3)
*/

int main(int argc, char *argv[]) {
   FILE *letto, *scritto;
   int err;
   
   if(argc == 4) {  // 4 argomenti richiesti
      if(!(strcmpi(argv[1], "-e") && (err = strcmpi(argv[1], "-c")))) {  // opzioni supportate
         if((letto = fopen(argv[2], "rb")) == NULL) {  // apre il file in lettura
            printf("Impossibile aprire %s\n", argv[2]);
            exit(2);  // uscita con errore
         }
         if((scritto = fopen(argv[3], "wb")) == NULL) {  // apre il file in scrittura
            printf("Impossibile aprire %s\n", argv[3]);
            fclose(letto);
            exit(2);  // uscita con errore
         }
         if(err) err = FF1_decomprimi_file(letto, scritto);  // decomprime se l'opzione non e' -c
         else err = FF1_comprimi_file(letto, scritto);  // altrimenti comprime
         fclose(letto);  // chiude i file
         fclose(scritto);
         
         if(err) {  // se c'e' un errore
            unlink(argv[3]);  // elimina il file destinazione
            if(err == -1) printf("Errore nell'allocazione della memoria");
            else if(err == 2) printf("Impossibile leggere il file %s", argv[2]);
            else printf("Impossibile scrivere il file %s", argv[3]);
            printf(" - Operazione non riuscita\n");
            exit(2);  // uscita con errore
         }
         printf("FF1 PSX file extractor/compressor 1.0 by Mat - Operazione riuscita\n");
         exit(0);  // uscita corretta
      }
   }      
   printf("FF1 PSX file extractor/compressor 1.0 by Mat - USO:\nextFF1 -e origine destinazione\t(estrae un file)\nextFF1 -c origine destinazione\t(comprime un file)\n\nMat - 26/08/2003\nE-mail:\tmattia.d.r@libero.it\nSito:\thttp://www.matzone.altervista.org\nMembro dei SadNES cITy: http://www.sadnescity.it\nPublic Release: 17/08/2004\n");
   exit(1);  // // uscita con errore per mancanza di parameti
}

int FF1_decomprimi_file(FILE *orig, FILE *dest) {

   unsigned char buffer[BUFFSIZE] = {'\0'};  // buffer di scrittura
   int dimheader, dimext;
   int flag, i, j, pos = FF1_JUMPMAX, salto, nbyte, inverso, posinv;
   // pos = JUMPMAX perche' i primi byte servono per il salto 
   
   if(fseek(orig, 0, SEEK_SET)) return 2;  // si posiziona all'inizio
   if(fread(&dimheader, 4, 1, orig) != 1) return 2;  // legge l'header del file compresso
   
   while(1) {
      if((flag = getc(orig)) == EOF) break;  // legge il riconoscitore
      for(i = 1; i & 255; i <<= 1) {
        if(flag & i) {  // normale
           if(fread(buffer + pos, 1, 1, orig) != 1) break;  // legge un byte direttamente
           ++pos;  // incrementa il numero di dati da scrivere
        }
        else {  // compresso
           if((nbyte = getc(orig)) == EOF) break;  // legge la coppia salto + recupero
           if((salto = getc(orig)) == EOF) break;
           salto = (salto << 3) | (nbyte >> 5);  // calcola il salto
           nbyte = (nbyte & 31) + 3;  // calcola il recupero
           for(j = 0; j < nbyte; ++j) buffer[pos] = buffer[pos++ - salto];  // copia i dati da recuperare
        }
      }
      if(pos >= (BUFFSIZE - FF1_RECMAX)) {  // buffer a rischio nel prossimo ciclo
         pos -= FF1_JUMPMAX;  // numero di byte da scrivere
         if(fwrite(buffer + FF1_JUMPMAX, pos, 1, dest) != 1) return 3;  // scrive il buffer su file
         for(j = 0; j < FF1_JUMPMAX; ++j) buffer[j] = buffer[j + pos];  // sposta gli ultimi JUMPMAX byte all'inizio del buffer (per eventuali recuperi)
         pos = FF1_JUMPMAX;  // setta la posizione iniziale in cui scriveremo nel buffer
      }
   }
   if(ferror(orig)) return 2;  // se c'e' stato errore ritorna
   if(fwrite(buffer + FF1_JUMPMAX, pos - FF1_JUMPMAX, 1, dest) != 1) return 3;  // scrive il contenuto del buffer
   if((dimext = ftell(dest)) == -1) return 2;  // ottiene la dimensione del file decompresso
   // la confronta con quella letta dal file compresso
   if(dimheader != dimext) printf("La dimensione nell'header del file non corrisponde con la dimesione del file\nestratto: %d != %d\n", dimheader, dimext);
   return 0;
}

int FF1_comprimi_file(FILE *orig, FILE *dest) {
   #define FF1_uscita(num) { free(buflet); return(num); }
   unsigned char bufcomp[FF1_MAXLINEA];  // buffer di compressione
   unsigned char *buflet;  // conterra' i dati del file da comprimere
   int filesize;  // grandezza dei dati da comprimere 
   int ciclo = 0;  // variabile boleana
   int poslet = FF1_JUMPMAX, poscomp, flag, i;
   
   if(fseek(orig, 0, SEEK_END)) return 2;  // fine del file
   if((filesize = ftell(orig)) == -1) return 2;  // dimensione del file
   if(fwrite(&filesize, 4, 1, dest) != 1) return 3;  // scrive la dimensione del file da comprimere
   if(fseek(orig, 0, SEEK_SET)) return 2;  // ritorna all'inizio
   if(!(buflet = calloc(1, filesize + FF1_JUMPMAX))) return -1;  // alloca la memoria necessaria per il file
   if(fread(buflet + FF1_JUMPMAX, filesize, 1, orig) != 1) FF1_uscita(2);  // legge il contenuto del file
   filesize += FF1_JUMPMAX;
   while(!ciclo) {  // inizio della compressione
      bufcomp[0] = 0xFF;  // setta la il byte dei salti a FF provvisoriamente
      poscomp = 1;  // i dati vanno dopo il flag
      for(i = 1; i & 255; i <<= 1) {  // ripete il ciclo 8 volte
         if((flag = FF1_cercaprec(buflet + poslet, buflet + poslet - FF1_JUMPMAX, buflet + filesize)) == -1) {  // nessun match
            bufcomp[poscomp++] = buflet[poslet++];  // scrive il byte direttamente
         }
         else { // abbiamo trovato un match
            *((short*)(bufcomp + poscomp)) = flag;  // scrive il flag nel buffer di scrittura
            poscomp += 2;  // aumentiamo l'indice dei byte compressi
            bufcomp[0] ^= i;  // imposta il bit relativo a questo byte a 0
            poslet += (flag & 31) + 3; // aumenta la posizione di lettura
         }
         if(ciclo = poslet >= filesize) {
            if(poslet != filesize) printf("Errore! Credo proprio di aver sbagliato qualcosa nell'algoritmo senza\naccorgermene (non ho mai ottenuto questo errore)!\n");
            break;
         }
         // c'e' solo per scrupolo
      }
      if(fwrite(bufcomp, poscomp, 1, dest) != 1) FF1_uscita(3);  // scrive il buffer nel file
   }
   free(buflet);  // libera la memoria allocata
   return 0;  // finalmente abbiamo finito!!!
}

int FF1_cercaprec(unsigned char *poslet, unsigned char *posiniz, unsigned char *posmax) {
   int i, count = 0, max = 2, maxpos;
   unsigned char *poscur;
   
   for(poscur = poslet - 1; poscur >= posiniz; --poscur) {  // inizia a cercare un match
      for(i = 0; i < FF1_MREC; ++i) { // cicla per un massimo di FF1_MREC byte
         if((poslet + i) >= posmax) break;  // evita di uscire dal buffer
         if(poscur[i] == poslet[i]) ++count;  // un byte uguale
         else break;  // usciamo dal ciclo
      }
      if(count > max) { // abbiamo un recupero maggiore del precedente
         max = count;  // nuovo massimo
         maxpos = poslet - poscur;  // posizione in cui abbiamo il massimo recupero
      }
      if(count == FF1_MREC) break;  // e' inutile continuare a cercare, abbiamo gia' il massimo recupero
      count = 0;  // rimette il contatore a 0 per il prossimi ciclo
   }
   if(max == 2) return -1;  // non abbiamo trovato una stringa di almeno due byte
   return ((maxpos << 5) | (max - 3));  // ritorna il flag corrispondete alla posizione a ai byte recuperati
}
