======================================================
       Squaresoft's portings file extractor 0.9
                        by Mat
                      17/08/2004
======================================================
------------------------------------------------------
0 - INDEX 
------------------------------------------------------

1 - Intro
2 - Usage
3 - Technical Notes
4 - Progress
5 - Future Progresses
6 - Thanks
7 - Disclaimer


------------------------------------------------------
1 - INTRO
------------------------------------------------------

This program was written to extract and compress the
compressed files of Final Fantasy VI PSX, furthermore
it also works with Final Fantasy V PSX and Chrono 
Trigger PSX. If you want to translate completely these
games this is the program for you! ;)

For example you can extract the FF6 MENU.BIN file or
CT KOK.BIN file, however in this case is a multi-file
(two compressed files attacjed together), therefore
must break the file into two with a hex editor:
- first file 0 - 213044dec
- second file 215040dec - 344530dec
The offset were obtained with the -a option.


NOTE: the language of the program is Italian, if you
      have any problem whit program messages email me
      at mattia.d.r@libero.it

------------------------------------------------------
2 - USAGE
------------------------------------------------------

This is a command line tool used with the DOS prompt
(Start\Programs or Start\Programs\Accessories).


SHOW THE HELP
 
 Run the program without parameters


EXTRACT A FILE

 To extract a file type:
  sqprtext -e source destination


COMPRESS A FILE

 To extract a file type:
  sqprtext -c source destination


ANALYSE A FILE

 To analyse a file type:
  sqprtext -a source


------------------------------------------------------
3 - TECHNICAL NOTES
------------------------------------------------------

The compression is a LZSS variant.
The compression of this program is slow, but is
the maximum possible.


------------------------------------------------------
4 - PROGRESS
------------------------------------------------------

Version 0.9

- First public version, not automatically manage the
  CT psx multi-file.


Various versions 0.9beta
- Not public versions


------------------------------------------------------
5 - FUTURE PROGRESS
------------------------------------------------------

- Bugs Correction
- Add management of the multiple file CT
- Translation of the program and source comments
  in English

------------------------------------------------------
6 - THANKS
------------------------------------------------------

^Anyone who will use or publish this program :)
^Gemini for asked me to write this compressor (but
 next time give me correct info ;) and have signalled
 me the problems with CT 
^Mickey to have signalled me the problems with CT


------------------------------------------------------
7 - DISCLAIMER
------------------------------------------------------

This program must be used only for LEGAL intents!
Use this program to your risk and danger :).
This program can be freely distributed. I only
recommend to distribute it in the state in
which it is (don't modify the readme etc etc).
Thanks.

Final Fantasy V, Final Fantasy VI, Chrono Trigger, and
the relative names are trademarks of Square.


Mat
mattia.d.r@libero.it
http://www.matzone.altervista.org/
Member of SadNES cITy: http://www.sadnescity.it/
