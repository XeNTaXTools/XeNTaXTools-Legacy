/* Squaresoft's portings file extractor 0.9 by Mat

ENGLISH

This program was written to extract and compress the
compressed files of Final Fantasy VI PSX, furthermore
it also works with Final Fantasy V PSX and Chrono 
Trigger PSX.
For more information see the readme.

This program must be used only for LEGAL intents!
Use this program to your risk and danger :).
This program can be freely distributed. I only
recommend to distribute it in the state in
which it is (don't modify the readme etc etc).
Thanks.

Final Fantasy V, Final Fantasy VI, Chrono Trigger, and
the relative names are trademarks of Square.

Mat - 21/09/2003
E-mail: mattia.d.r@libero.it
Sito:   http://www.matzone.altervista.org
Membro dei SadNES cITy: http://www.sadnescity.it
Public Release: 17/08/2004


ITALIAN

Questo programma e' stato scritto per estrarre e comprimere i file compressi
di Final Fantasy VI PSX, inoltre funziona anche con Final Fantasy V PSX e
Chrono Trigger PSX.
Per maggiori informazioni vi rimando al readme.
Il codice e stato scritto facendo in modo che le funzioni siano riutilizzabili
e gestiscano gli errori delle system call.
Penso di aver scritto un codice decente anche se per faticare di meno non ho
scritto tutto al meglio. I commenti non sono dettagliati al massimo (indico
quello che faccio, ma non non perche' lo faccio).
Se qualche riga e' poco chiara contattami.
Questo programma e' stato scritto con Dev-C++ e compilato con gcc, e una
richiesta fondamentale per il funzionamento e' che i dati siano Little Endian
e che gli int siano a 4 byte e gli short a 2 byte (e' per questo che nelle 
funzioni non ho usato sizeof(int), perche' se la dimensione fosse diversa il
programma non funzionerebbe comunque).

NOTE SULLA COMPRESSIONE
Sia nella decompressione che nella compressione sono implementati 2 trick:
- overlap
- negative jump
I miei algoritmi non sono il massimo in quanto a velocita' e a consumo di
memoria, pero' dovrebbero garantire la massima compressione possibile.

Questo programma deve essere usato solo per scopi LEGALI!
Usa questo programma a tuo rischio e pericolo :).
Questo programma puo' essere liberamente distribuito.
Ti raccomando solo di distribuirlo nello stato in cui si trova.
Grazie.

Mat - 21/09/2003
E-mail: mattia.d.r@libero.it
Sito:   http://www.matzone.altervista.org
Membro dei SadNES cITy: http://www.sadnescity.it
Public Release: 17/08/2004
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Grandezza del buffer per la decompressione
#define FF6_BUFFSIZE 32768

// Caratteristiche della compressione
// Grandezza di una stringa compressa in short
#define FF6_LINEA 9
// Grandezza massima del salto (11 bit)
#define FF6_JUMPMAX 2047
// Massimo recupero 2 + 31 (5 bit)
#define FF6_MREC 33
// Recupero massimo per una stringa 8 * MREC
#define FF6_RECMAX 264

int FF6_analisi_file(FILE *orig);
/* Analizza un file compresso
    orig:  file pointer del file compresso (verra' messo il seek a 0)
    
    Valore di ritorno:
    0 in caso di successo
    2 in caso di errore di lettura o di seek
    
    NOTA: La funzione non chiude i file pointer passati e muove il seek
    NOTA2: La funzione stampa su stdout il risulato dell'analisi
*/

int FF6_decomprimi_file(FILE *orig, FILE *dest);
/* Decomprime un file compresso di FF6 PSX
    infile:  file pointer del file compresso (verra' messo il seek a 0)
    outfile: file pointer su cui verranno accodati i dati decompressi
    
    Valore di ritorno:
    0 in caso di successo
    2 in caso di errore di lettura o di seek
    3 in caso di errore di scrittura
    
    NOTA: La funzione non chiude i file pointer passati e muove il seek
    NOTA2: La funzione stampa su stdout un avviso se la dimensione indicata
           all'inizio del file e quella del file scompresso non coincidono
*/

int FF6_comprimi_file(FILE *orig, FILE *dest);
/* Comprime un file nel formato di FF6 PSX
    infile:  file pointer del file sorgente (verra' messo il seek a 0)
    outfile: file pointer su cui verranno accodati i dati compressi
    
    Valore di ritorno:
    0 in caso di successo
    -1 nel caso di errori all'allocazione della memoria
    2 in caso di errore di lettura o di seek
    3 in caso di errore di scrittura
    
    NOTA: La funzione non chiude i file pointer passati e muove il seek
*/

int FF6_cercaprec(unsigned short *poslet, unsigned short *posiniz, unsigned short *posmax);
/* Cerca un match uguale nei byte precedenti, overlap OK
    poslet:  posizione in cui c'e' la stringa che dobbiamo cercare
    posiniz: posizione fino a cui possiamo ritornare alla ricerca di un match
    posmax:  posizione entro la quale dobbiamo fermarci nella lettura della stringa di input
    
    Valore di ritorno:
    -1 se non trova un match di almeno 2 short
    0 - 0xFFFF nel caso trovi un match
      il valore corrisponde a (jump << 5) | (recupero - 2)
*/

int main(int argc, char *argv[]) {
   FILE *letto, *scritto;
   int c, err;
   
   if((argc == 3) || (argc == 4)) {  // 3 o4 argomenti richiesti
      if(!strcmpi(argv[1], "-a") && (argc == 3)) {
         if((letto = fopen(argv[2], "rb")) == NULL) {  // apre il file in lettura
            printf("Impossibile aprire %s\n", argv[2]);
            exit(2);  // uscita con errore
         }
         err = FF6_analisi_file(letto);
         fclose(letto);
         if(err) {  // se c'e' un errore
            printf("Impossibile leggere il file %s", argv[2]);
            exit(2);  // uscita con errore
         }
      }
      else if((!(strcmpi(argv[1], "-e") && (c = strcmpi(argv[1], "-c")))) && (argc == 4)) {  // opzioni supportate
         if((letto = fopen(argv[2], "rb")) == NULL) {  // apre il file in lettura
            printf("Impossibile aprire %s\n", argv[2]);
            exit(2);  // uscita con errore
         }
         if((scritto = fopen(argv[3], "wb")) == NULL) {  // apre il file in scrittura
            printf("Impossibile aprire %s\n", argv[3]);
            fclose(letto);
            exit(2);  // uscita con errore
         }
         if(c) err = FF6_decomprimi_file(letto, scritto);  // decomprime se l'opzione non e' -c
         else err = FF6_comprimi_file(letto, scritto);  // altrimenti comprime
         fclose(letto);  // chiude i file
         fclose(scritto);
         
         if(err) {  // se c'e' un errore
            unlink(argv[3]);  // elimina il file destinazione
            if(err == -1) printf("Errore nell'allocazione della memoria");
            if(err == 2) printf("Impossibile leggere il file %s", argv[2]);
            else printf("Impossibile scrivere il file %s", argv[3]);
            printf(" - Operazione non riuscita\n");
            exit(2);  // uscita con errore
         }
      }
   }
   if(err) {
      printf("Squaresoft's portings file extractor 0.9 by Mat - USO:\nsqprtext -e origine destinazione  (estrae un file)\nsqprtext -c origine destinazione  (comprime un file)\nsqprtext -a origine\t\t  (analizza un file)\n\nMat - 15/09/2003\nE-mail:\tmattia.d.r@libero.it\nSito:\thttp://www.matzone.altervista.org\nMembro dei SadNES cITy: http://www.sadnescity.it\nPublic Release: 17/08/2004\n");
      exit(1);  // uscita con errore per mancanza di parameti
   }
   printf("Squaresoft's portings file extractor 0.9 by Mat - Operazione riuscita\n");
   exit(0);  // uscita corretta
}

int FF6_analisi_file(FILE *orig) {

   unsigned short linea[FF6_LINEA];  // una linea compressa
   unsigned short buffer[FF6_BUFFSIZE] = {0};  // buffer di scrittura
   int dimheader, dimext;
   int i, j, pos = FF6_JUMPMAX, nletti, salto, nrec;
   // pos = JUMPMAX perche' i primi short servono per il salto 
   int dimextract = 0;
   
   if(fseek(orig, 0, SEEK_SET)) return 2;  // si posiziona all'inizio
   if(fread(&dimheader, 4, 1, orig) != 1) return 2;  // legge la dimensione dei dati estratti specificata nell'header
   
   while(dimextract < dimheader) {  // finche' non raggiungiamo la dimensione specificata nell'header
      if((nletti = fread(linea, 2, FF6_LINEA, orig)) <= 0) break;  // termina il ciclo se siamo a fine file
      for(i = 1; i < nletti; ++i) {  // per gli altri 8 short
         if((*linea >> (i - 1)) & 1) dimextract += 2;  // dati normali
         else dimextract += ((linea[i] & 31) + 2) << 1;  // dati compressi
         if(dimextract >= dimheader) break;  // abbiamo raggiunto la dimensione specificata nell'header
      }
   }
   if(ferror(orig)) return 2;
   i = ftell(orig) - ((8 - i) << 1); // calcola la posizione nel file compresso
   // stampa il risulatato
   printf("Dati estratti:\n dimensione nell'header: %Xh - %ddec\n dimensione calcolata:   %Xh - %ddec\nOffset corrispondente nel file compresso: %Xh - %ddec\n\n", dimheader, dimheader, dimextract, dimextract, i, i);
   return 0;
}

int FF6_decomprimi_file(FILE *orig, FILE *dest) {

   unsigned short linea[FF6_LINEA];  // una linea compressa
   unsigned short buffer[FF6_BUFFSIZE] = {0};  // buffer di scrittura
   int dimheader, dimext;
   int i, j, pos = FF6_JUMPMAX, nletti, salto, nrec;
   // pos = JUMPMAX perche' i primi short servono per il salto 
   
   if(fseek(orig, 0, SEEK_SET)) return 2;  // si posiziona all'inizio
   if(fread(&dimheader, 4, 1, orig) != 1) return 2;
   
   while(1) {
      if((nletti = fread(linea, 2, FF6_LINEA, orig)) <= 0) break;  // termina il ciclo se siamo a fine file
      for(i = 1; i < nletti; ++i) {  // per gli altri 8 short
        if((*linea >> (i - 1)) & 1) { // dati normali
           buffer[pos++] = linea[i];  // copia uno short
        }
        else {  // dati compressi
          salto = linea[i] >> 5;
          nrec = (linea[i] & 31) + 2;
          for(j = 0; j < nrec; ++j) buffer[pos] = buffer[pos++ - salto];  // scrive i byte recuperati (overlap ok - no memcpy)
        }
      }
     
      if(pos >= (FF6_BUFFSIZE - FF6_RECMAX)) {  // buffer a rischio nel prossimo ciclo
         pos -= FF6_JUMPMAX;  // numero di short da scrivere
         if(fwrite(buffer + FF6_JUMPMAX, pos, 2, dest) != 2) return 3;  // scrive il buffer su file
         for(j = 0; j < FF6_JUMPMAX; ++j) buffer[j] = buffer[j + pos];  // sposta gli ultimi JUMPMAX short all'inizio del buffer (per eventuali recuperi)
         pos = FF6_JUMPMAX;  // setta la posizione iniziale in cui scriveremo nel buffer
      }
   }
   if(ferror(orig)) return 2;  // se c'e' stato errore ritorna
   if(fwrite(buffer + FF6_JUMPMAX , pos - FF6_JUMPMAX, 2, dest) != 2) return 3;  // scrive il contenuto del buffer
   if((dimext = ftell(dest)) == -1) return 2;  // ottiene la dimensione del file decompresso
   // la confronta con quella letta dal file compresso
   if(dimheader != dimext) printf("ATTENZIONE!!! Dati estratti:\n dimensione nell'header:   %Xh - %ddec\n dimensione file estratto: %Xh - %ddec\nUsa l'opzione -a per analizzare il file\n\n", dimheader, dimheader, dimext, dimext);
   return 0;  // torniamo al main
}

int FF6_comprimi_file(FILE *orig, FILE *dest) {

   unsigned short bufcomp[FF6_LINEA];  // una linea compressa
   unsigned short *buflet;  // conterra' i dati del file da comprimere
   int filesize;  // grandezza del file da comprimere
   int datasize;  // numero di short da allocare
   int ciclo = 0;  // variabile boleana
   int poslet = FF6_JUMPMAX, poscomp, flag, i;
   
   if(fseek(orig, 0, SEEK_END)) return 2;  // fine del file
   if((filesize = ftell(orig)) == -1) return 2;  // dimensione del file
   if(fwrite(&filesize, 4, 1, dest) != 1) return 3;  // scrive la dimensione del file scompresso nel file compresso
   if(fseek(orig, 0, SEEK_SET)) return 2;  // ritorna all'inizio
   datasize = ((filesize + 1) >> 1) + FF6_JUMPMAX;  // numero di short da allocare
   if(!(buflet = calloc(datasize, 2))) return -1;  // alloca la memoria necessaria per il file
   if(fread(buflet + FF6_JUMPMAX, filesize, 1, orig) != 1) {free(buflet); return(2);}  // legge il contenuto del file
   while(!ciclo) {  // inizio della compressione
      bufcomp[0] = 0xFF;  // setta lo short dei salti a 0xFF provvisoriamente
      poscomp = 1;  // i dati vanno dopo il flag
      for(i = 1; i & 255; i <<= 1) {  // ripete il ciclo 8 volte
         // ricerca un match uguale di almeno 2 short
         if((flag = FF6_cercaprec(buflet + poslet, buflet + poslet - FF6_JUMPMAX, buflet + datasize)) == -1) {  // nessun match
            bufcomp[poscomp++] = buflet[poslet++];  // scrive lo short direttamente
         }
         else { // abbiamo trovato un match
            bufcomp[poscomp++] = flag;  // scrive il flag nel buffer di scrittura
            bufcomp[0] ^= i;  // imposta il bit relativo a questo short a 0
            poslet += (flag & 31) + 2; // aumenta la posizione di lettura
         }
         if(ciclo = poslet >= datasize) {
            if(poslet != datasize) printf("Errore! Credo proprio di aver sbagliato qualcosa nell'algoritmo senza\naccorgermene (non ho mai ottenuto questo errore)!\n");
            // c'e' solo per scrupolo
            break;  // a fine file lasciamo il ciclo for
         }
      }
      if(fwrite(bufcomp, poscomp, 2, dest) != 2) {free(buflet); return(3);}  // scrive il buffer nel file
   }
   free(buflet);  // libera la memoria allocata
   return 0;  // finalmente abbiamo finito!!!
}

int FF6_cercaprec(unsigned short *poslet, unsigned short *posiniz, unsigned short *posmax) {
   int i, count = 0, max = 1, maxpos;
   unsigned short *poscur;
   
   for(poscur = poslet - 1; poscur >= posiniz; --poscur) {  // inizia a cercare un match
      for(i = 0; i < FF6_MREC; ++i) { // cicla per un massimo di MREC short
         if((poslet + i) >= posmax) break;  // evita di uscire dal buffer
         if(poscur[i] == poslet[i]) ++count;  // uno short uguale
         else break;  // usciamo dal ciclo
      }
      if(count > max) { // abbiamo un recupero maggiore del precedente
         max = count;  // nuovo massimo
         maxpos = poslet - poscur;  // posizione in cui abbiamo il massimo recupero
      }
      if(count == FF6_MREC) break;  // e' inutile continuare a cercare, abbiamo gia' il massimo recupero
      count = 0;  // rimette il contatore a 0 per il prossimi ciclo
   }
   if(max == 1) return -1;  // non abbiamo trovato una stringa di almeno due short
   return (maxpos << 5) | (max - 2);
   // ritorna il flag corrispondete alla posizione e al numero di short recuperati
}
