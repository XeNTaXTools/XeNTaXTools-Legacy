#by Durik256 for xentax
#only for '0000.jboy'
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Pacific rim", ".jboy")
    noesis.setHandlerTypeCheck(handle, CheckType)
    noesis.setHandlerLoadModel(handle, LoadModel)
    return 1

def CheckType(data):

    return 1
    
def LoadModel(data, mdlList):
    bs = NoeBitStream(data)
    ctx = rapi.rpgCreateContext()
    
    #0-off_vbuf;1-num_vert;2-off_ibuf;3-num_ind
    data = [[982436,536,1012464,1543],[943096,556,978692,1395],[755440,2169,928972,6245],
            [639908,1471,745832,3987],[473204,1926,627296,5490],[3360,5469,440892,15339],
            [1017180,642,1053144,1862],[1058500,1163,1123640,3127],[1131528,263,1146268,677]]

    for x in data:
        bs.seek(x[2])
        ibuf = bs.readBytes(x[3]*2)
        bs.seek(x[0])
        vbuf = bs.readBytes(x[1]*28)
        
        rapi.rpgSetEndian(1)
        rapi.rpgBindPositionBuffer(vbuf, noesis.RPGEODATA_FLOAT, 28)
        rapi.rpgCommitTriangles(ibuf, noesis.RPGEODATA_USHORT, len(ibuf)//2, noesis.RPGEO_TRIANGLE_STRIP)
    
    mdl = rapi.rpgConstructModel()
    mdlList.append(mdl)
    return 1