import newGameLib
reload(newGameLib)
from newGameLib import *
import Blender





def aemParser(filename,g):
	# textury
	list_0={}
	for m in range(g.i(1)[0]):
		data1=g.i(2)
		data2=g.B(1)[0]
		data3=g.i(12)
		list_0[str(data1[0])]=data3[11]
	list_1={}   
	for m in range(g.i(1)[0]):
		data1=g.i(1)
		data2=g.f(20)
		data3=g.i(1)[0]
		data4=g.f(6)
		list_1[str(data1[0])]=data3
	list_2={}   
	for m in range(g.i(1)[0]):
		data1=g.i(2)
		data2=g.H(5)
		data3=g.i(2)
		list_2[str(data1[0])]=data2
	count = g.i(1)[0]
	for m in range(count):
		g.H(8)
	data = g.i(3)	
	skeleton=Skeleton()
	skeleton.ARMATURESPACE=True	
	skeleton.NICE=True
	boneNameList=[]
	for m in range(data[2]):
		bone=Bone()
		var = g.i(2);print m,var,
		bone.name=str(var[0])
		boneNameList.append(bone.name)	
		g.f(9)
		g.f(3) 
		g.B(1)
		g.f(16)
		bone.matrix = Matrix(g.f(4),g.f(4),g.f(4),g.f(4))
		matrix = Matrix(g.f(4),g.f(4),g.f(4),g.f(4))
		g.i(2)	#1,0	
		g.f(20)
		parentID=g.i(1)[0]
		if parentID!=0:
			bone.parentName=str(parentID)
		skeleton.boneList.append(bone)	
	skeleton.draw()
	matList={}
	for id in list_0.keys():
		print 'mat:',id
		id_0=list_0[id]
		mat=Mat()#Material.New(str(model_id)+'-mat-'+str(id))
		matList[id]=mat
		if id_0!=0:
			id_1=list_1[str(id_0)]
			if id_1!=0:
				id_2=list_2[str(id_1)]
				dds_name='t_00'+str(id_2[0])
				if 99>=id_2[1]>9:
					dds_name+='_0'+str(id_2[1])+'_00'+str(id_2[2])+'_00'+str(id_2[3])
				elif id_2[1]>99:
					dds_name+='_'+str(id_2[1])+'_00'+str(id_2[2])+'_00'+str(id_2[3])
				if 9>=id_2[1]:
					dds_name+='_00'+str(id_2[1])+'_00'+str(id_2[2])+'_00'+str(id_2[3])			
				if id_2[4]>9:
					dds_name+='_0'+str(id_2[4])+'.dds'
				else:   
					dds_name+='_00'+str(id_2[4])+'.dds'
				#print dds_name
				try:
					#img=Blender.Image.Load(g.dirname+os.sep+dds_name)
					#diffuse_and_alpha(model_id,mat,id_0,img)
					mat.diffuse=g.dirname+os.sep+dds_name
				except:pass	
				
				id_2=list_2[str(id_1)]
				dds_name='t_00'+str(id_2[0])
				if 99>=id_2[1]>9:
					dds_name+='_0'+str(id_2[1])+'_00'+str(id_2[2])+'_00'+str(id_2[3])
				elif id_2[1]>99:
					dds_name+='_'+str(id_2[1])+'_00'+str(id_2[2])+'_00'+str(id_2[3])
				if 9>=id_2[1]:
					dds_name+='_00'+str(id_2[1])+'_00'+str(id_2[2])+'_00'+str(id_2[3])			
				if id_2[4]+1>9:
					dds_name+='_0'+str(id_2[4]+1)+'.dds'
				else:   
					dds_name+='_00'+str(id_2[4]+1)+'.dds'
				#print dds_name
				try:
					#img=Blender.Image.Load(dirname+os.sep+dds_name)
					#fac=1
					#normal(model_id,mat,id_0,img,fac)
					mat.normal=g.dirname+os.sep+dds_name
					mat.NORMALSTRONG=1.0
				except:pass	
				
				id_2=list_2[str(id_1)]
				dds_name='t_00'+str(id_2[0])
				if 99>=id_2[1]>9:
					dds_name+='_0'+str(id_2[1])+'_00'+str(id_2[2])+'_00'+str(id_2[3])
				elif id_2[1]>99:
					dds_name+='_'+str(id_2[1])+'_00'+str(id_2[2])+'_00'+str(id_2[3])
				if 9>=id_2[1]:
					dds_name+='_00'+str(id_2[1])+'_00'+str(id_2[2])+'_00'+str(id_2[3])			
				if id_2[4]+2>9:
					dds_name+='_0'+str(id_2[4]+2)+'.dds'
				else:   
					dds_name+='_00'+str(id_2[4]+2)+'.dds'
				#print dds_name
				try:
					#img=Blender.Image.Load(dirname+os.sep+dds_name)
					#specular(model_id,mat,id_0,img)
					mat.specular=g.dirname+os.sep+dds_name
				except:pass	
	
	
	meshList=[]
	nMesh = g.i(1)[0]
	for m in range(nMesh):
		data1 = g.i(7)
		print data1
		data2 = g.H(3)
		mesh=Mesh()
		mesh.TRISTRIP=True
		for n in range(data1[3]):
			back = g.tell()
			mesh.vertPosList.append(g.f(3))
			
			if data1[4]==69:
				g.seek(back+24)
				mesh.vertUVList.append(g.f(2))  
				mesh.skinWeightList.append([1.0])
				mesh.skinIndiceList.append([0]) 
				g.seek(back+32)
			elif data1[4]==4456516:
				mesh.skinWeightList.append(g.f(4))
				mesh.skinIndiceList.append(g.B(4))  
				g.seek(back+44)
				mesh.vertUVList.append(g.f(2))  
				g.seek(back+52)
			else:
				break
		mesh.indiceList=g.H(data2[0])
		g.f(4) 		
		#mat=Material.Get(str(model_id)+'-mat-'+str(data1[1]))
		
		mat=Mat()
		mat.diffuse=matList[str(data1[2])].diffuse
		mat.normal=matList[str(data1[2])].normal
		mat.specular=matList[str(data1[2])].specular
		mat.TRISTRIP=True
		mesh.matList.append(mat)
		meshList.append(mesh)
		
	for m in range(g.i(1)[0]):
		mesh=meshList[m]
		data = g.i(6)
		boneMap=g.i(data[5])
		g.i(16)
		matrix=skeleton.object.getData().bones[str(data[4])].matrix['ARMATURESPACE']*skeleton.object.mat
		mesh.matrix=matrix
		skin=Skin()
		if data[5]==0:
			skin.boneMap=[boneNameList.index(str(data[4]))]
			mesh.boneNameList=boneNameList
		else:
			skin.boneMap=boneMap		
		mesh.skinList.append(skin)			
		mesh.draw()
	
	skeletonObject=skeleton.object
	scene = bpy.data.scenes.active
	for object in scene.objects:
		if object.type=='Mesh':
			skeletonObject.makeParentDeform([object],0,0)
			Blender.Window.RedrawAll	

def aeaParser(filename,g):

	action=Action()
	#action.ARMATURESPACE=True
	action.BONESPACE=True
	action.BONESORT=True
	action.skeleton='armature'
	#action.UPDATE=False
	g.i(3)
	boneCount=g.i(1)[0]
	for i in range(boneCount):
		bone=ActionBone()
		unk,count=g.i(2)
		bone.name=str(unk/10)	
		print i,unk
		for n in range(count):
			a,b,c,d=g.i(4)
			print a,b,c,d
			for m in range(g.i(1)[0]):
				t,x,y,z=g.f(4)
				if a==5:
					bone.rotFrameList.append(int(t))
					bone.rotKeyList.append(Euler(x,y,z).toMatrix().resize4x4())
		action.boneList.append(bone)
	action.draw()
	action.setContext()	

	
def gtfParser(filename):
	file=open(filename,'rb')
	g=BinaryReader(file)
	data = g.B(33)
	img=imageLib.Image()
	if data[24]==136:
		img.format='DXT5'
	elif data[24]==134:
		img.format='DXT1'
	else:
		print 'UNKNOW DXT',dxt  
	if data[32]==0:
		img.szer=128
	elif data[32]==1:
		img.szer=256
	elif data[32]==2:
		img.szer=512
	elif data[32]==4:
		img.szer=1024
	img.wys=g.i(1)[0]
	img.name=os.path.dirname(filename)+os.sep+os.path.basename(filename).split('.')[0]+'.dds'
	g.seek(128)
	img.data=g.read(g.fileSize()-g.tell())
	img.draw()
	
	file.close()
			
def Parser():	
	filename=input.filename
	print
	print filename
	print
	ext=filename.split('.')[-1].lower()
	
		
	if ext=='aem':
		for file in os.listdir(os.path.dirname(filename)):   
				if file.split('.')[-1] == 'gtf':
					gtfParser(os.path.dirname(filename)+os.sep+file)
		file=open(filename,'rb')
		g=BinaryReader(file)
		aemParser(filename,g)
		file.close()
		
	if ext=='aea':
		file=open(filename,'rb')
		g=BinaryReader(file)
		g.logOpen()
		aeaParser(filename,g)
		g.logClose()
		file.close()
		
	
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
	
Blender.Window.FileSelector(openFile,'import','Last Rebellion files *.aem') 
	