# by Durik for xentax.com 
from inc_noesis import *

def registerNoesisTypes():
   handle = noesis.register("Front Mission", ".cl5")
   noesis.setHandlerTypeCheck(handle, CheckType)
   noesis.setHandlerLoadModel(handle, LoadModel)
   return 1

def CheckType(data):

    return 1

def LoadModel(data, mdlList):
    bs = NoeBitStream(data)
    ctx = rapi.rpgCreateContext()
    
    bs.seek(4)#header
    bs.seek(bs.readInt())#offset_mesh
    
    while bs.readInt() == 65536:# >> mesh header[00 00 01 00]
        curPos = bs.getOffset()-4
        #0-size;1-off_face?;2-off_vert;3-off_unk?;4-offset_name?;5-off_mat?;6-off_rot?
        off_info = [bs.readInt() for x in range(7)]
        print('off_info:',off_info)
        
        #0-unk;1-vert_num?;2-unk_num(uv?);3-unk(1);4-num_mat;5-zero
        mesh_info = [bs.readShort() for x in range(6)]
        print('mesh_info:',mesh_info)
        
        bs.seek(curPos+off_info[2])#vert_offset
        vbuf = bs.readBytes(mesh_info[1]*8)#vert_count, 8 - stride
        
        bs.seek(curPos+off_info[1])#indices_offset
        unk, num_group = bs.readShort(), bs.readShort()
        
        rapi.rpgSetName('mesh_'+str(curPos))
        for x in range(num_group):
            type, count, unk0, unk1 = [bs.readShort() for x in range(4)]
            print(x,'submesh >> type:',type,'face:',count, 'unk:', unk0, unk1)
            
            ibuf = read_ibuf(bs, count, type)
            
            #rapi.rpgSetName('mesh_'+str(x))
            rapi.rpgBindPositionBuffer(vbuf, noesis.RPGEODATA_SHORT, 8)
            rapi.rpgCommitTriangles(ibuf, noesis.RPGEODATA_SHORT, len(ibuf)//2, noesis.RPGEO_TRIANGLE)
        
        bs.seek(curPos+off_info[0])
        
    mdl = rapi.rpgConstructModel()
    mdlList.append(mdl)
    return 1

def read_ibuf(bs, count, type):
    ibuf = b''
    
    if type == 3328:
        for x in range(count):
            face = [bs.readUByte() for x in range(4)]
            
            for i in face[:3]:
                ibuf +=(i).to_bytes(2, 'little')
            
            for i in face[1:][::-1]:
                ibuf +=(i).to_bytes(2, 'little')
            
            bs.seek(20, 1)
    
    elif type == 3072:
        for x in range(count):
            face = [bs.readUByte() for x in range(3)]
            
            for i in face[:3]:
                ibuf +=(i).to_bytes(2, 'little')
            
            bs.seek(17, 1)
    return ibuf