from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Datang Online", ".tex")
	noesis.setHandlerTypeCheck(handle, HNRCheckType)
	noesis.setHandlerLoadRGBA(handle, HNRLoadRGBA)
	#noesis.logPopup()
	return 1

#check if it's this type based on the data
def HNRCheckType(data):
	bs = NoeBitStream(data)
	Header = bs.readBytes(4).decode("ASCII")
	if Header != 'TEX\x00':
		return 0
	return 1
	
def HNRLoadRGBA(data, texList):
	datasize = len(data) - 0x4c        
	bs = NoeBitStream(data)
	bs.seek(0x0c, NOESEEK_ABS)
	imgFmt = bs.readByte()
	bs.seek(0x14, NOESEEK_ABS)
	imgWidth = bs.readInt()            
	imgHeight = bs.readInt()           
	bs.seek(0x4c, NOESEEK_ABS)        
	data = bs.readBytes(datasize)      
	#DXT1
	if imgFmt == 0x00:
		texFmt = noesis.NOESISTEX_DXT1
	#DXT5
	elif imgFmt == 0x01:
		texFmt = noesis.NOESISTEX_DXT5
	#rgba?
	elif imgFmt == 0x03:
		data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "b8 g8 r8 a8")
		texFmt = noesis.NOESISTEX_RGBA32
	#unknown, not handled
	else:
		print("WARNING: Unhandled image format")
		return None
	texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
	return 1