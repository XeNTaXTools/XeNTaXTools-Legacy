from inc_noesis import *
from inc_switchunswizzling import *

# debug level
# 0 - info/warn/error messages (hidden)
# 1 - 0 + pop up Noesis Debug Log
DEBUGLEVEL = 0
#-------------------------------------------------------------------------------
def registerNoesisTypes():
    handle = noesis.register("JD2020 (NS) CKD Image", ".ckd")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    if DEBUGLEVEL >= 1: noesis.logPopup()
    return 1
#-------------------------------------------------------------------------------
def noepyCheckType(data):
    bs = NoeBitStream(data)
    bs.setEndian(0)
    if bs.readBytes(8) == b"\x00\x00\x00\x09TEX\x00": return 1
    else: print("[x] Wrong magic bytes."); return 0
#-------------------------------------------------------------------------------
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.setEndian(0)
    bs.seek(0x60, 0)
    dataSize = bs.readUInt()
    dataStart = 0x22C
    bs.seek(0x6C, 0)
    width = bs.readUInt()
    height = bs.readUInt()
    bs.seek(0x7C, 0)
    TEXFMT = bs.readUInt()
    bs.seek(0xCC, 0)
    block_height_log2 = bs.readUByte()
    block_height = 1 << block_height_log2

    if TEXFMT == 0x42: fmtText = "DXT1"; texFmt = noesis.NOESISTEX_DXT1; bpp = 8
    elif TEXFMT == 0x44: fmtText = "DXT5"; texFmt = noesis.NOESISTEX_DXT5; bpp = 16
    else: fmtText = "unknown"

    bs.seek(dataStart, 0)
    data = bs.readBytes(dataSize)

    print("[i] Format: "+fmtText+"; WxH: "+repr(width)+"x"+repr(height)+"; data start: "+hex(dataStart)+"; data size: "+repr(dataSize)+" B.")
    if fmtText == "unknown": return 0

    data = imageUnswizzleSwitch(data, width>>2, height>>2, bpp, block_height)
    texList.append(NoeTexture(rapi.getExtensionlessName(rapi.getInputName()), width, height, data, texFmt))
    return 1
#-------------------------------------------------------------------------------