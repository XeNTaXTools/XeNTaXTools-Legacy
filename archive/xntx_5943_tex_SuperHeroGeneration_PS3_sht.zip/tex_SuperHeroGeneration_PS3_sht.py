from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Super Hero Generation (PS3)", ".sht")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    Magic = bs.readBytes(4).decode("ASCII")
    print(Magic)
    if Magic != "SSHT":
        return 0
    return 1
    
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data, NOE_BIGENDIAN)
    bs.seek(0x14, NOESEEK_ABS)         
    entrySize = bs.readUInt()
    numEntries = bs.readUInt()
    endStringTable = bs.readUInt()
    tableInfo = endStringTable + 12
    tableInfoandDataSize = bs.readInt()
    if numEntries > 6:
        dataStart = endStringTable + 0x180
    else:
        dataStart = endStringTable + 0x100
    for i in range(numEntries):
        stringOff = bs.readUInt()
        tmp = bs.tell()
        bs.seek(stringOff, NOESEEK_ABS)
        texName = bs.readString()
        print(texName)
        bs.seek(tableInfo, NOESEEK_ABS)
        fileNum = bs.readUInt()
        unk = bs.readInt()
        datasize = bs.readUInt()
        unk = bs.readInt()
        imgFmt = bs.readInt()
        print(hex(imgFmt), ":imgFmt")
        imgWidth = bs.readUShort()            
        imgHeight = bs.readUShort()
        print(imgWidth, "x", imgHeight)
        skip = bs.readBytes(12)
        tableInfo = bs.tell()
        bs.seek(dataStart, NOESEEK_ABS)
        data = bs.readBytes(datasize)      
        dataStart = bs.tell()
        #DXT5
        if imgFmt == 0xaae4:
            texFmt = noesis.NOESISTEX_DXT5
        #morton order swizzled raw 
        elif imgFmt == 0xa9e4:
            untwid = bytearray()
            for x in range(imgWidth):
                for y in range(imgHeight):
                    idx = noesis.morton2D(x, y)
                    untwid += data[idx * 4:idx * 4 + 4]
            data = rapi.imageDecodeRaw(untwid, imgWidth, imgHeight, "a8r8g8b8") #a8g8b8r8
            texFmt = noesis.NOESISTEX_RGBA32
        #unknown, not handled
        else:
            print("WARNING: Unhandled image format")
            return None
        bs.seek(tmp, NOESEEK_ABS)
        texList.append(NoeTexture(texName, imgWidth, imgHeight, data, texFmt))
    return 1