Bomberman Jetters audio extractor (Nintendo GameCube)
v1.0 by Dave, 2019

This program will extract the audio files from the jetters.samp archive.

Make sure that the files "file_table" and "jetters.samp" are in the same folder as this program.

From the command prompt, type "bj_samp" to view some basic info about usage.

Type "bj_samp x" to extract the audio files into a folder called "output".  There should be 854 files extracted.  These will be in .DSP format and can be played with foobar/vgmstream.

