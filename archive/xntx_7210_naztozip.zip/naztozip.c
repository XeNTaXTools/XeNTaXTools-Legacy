#include <stdio.h>
#include <stdlib.h>
#include <windows.h>

#ifdef GCC32HACK
#include "win32gcc.h"
#endif

#define NAZ_HEAD 0x16ED5B50
#define NAZ_LIST 0x0406F370

#define ZIP_HEAD 0x06054B50
#define ZIP_LIST 0x02014B50
#define ZIP_ITEM 0x04034B50

/*
https://users.cs.jmu.edu/buchhofp/forensics/formats/pkzip-printable.html
zip -X -R -0 -D test.zip *.ogg
*/

#pragma pack(push, 1)
typedef struct {
  DWORD magic;
  WORD  dknum;
  WORD  dkcds;
  WORD  ditem;
  WORD  titem;
  DWORD dsize;
  DWORD doffs;
  WORD  csize;
} zip_head;

typedef struct {
  DWORD magic;
  WORD  cvers;
  WORD  nvers;
  WORD  flags;
  WORD  compr;
  WORD  mtime;
  WORD  mdate;
  DWORD crc32;
  DWORD psize;
  DWORD usize;
  WORD  nsize;
  WORD  isize;
  WORD  csize;
  WORD  dstrt;
  WORD  iattr;
  DWORD eattr;
  DWORD hoffs;
} zip_list;

typedef struct {
  DWORD magic;
  WORD  nvers;
  WORD  flags;
  WORD  compr;
  WORD  mtime;
  WORD  mdate;
  DWORD crc32;
  DWORD psize;
  DWORD usize;
  WORD  nsize;
  WORD  isize;
} zip_item;

typedef struct {
  DWORD magic;
  /* 1-2 block in .ZIP must be here */
  WORD  mtime;
  WORD  mdate;
  DWORD crc32;
  DWORD psize;
  DWORD usize;
  WORD  nsize;
  WORD  isize; /* only 1 byte: 0x98 - videos, 0x98 - everthing else - what is it? */
  WORD  csize;
  WORD  dstrt;
  WORD  iattr;
  DWORD eattr;
  DWORD hoffs;
  /* 1 */
  WORD  cvers;
  WORD  nvers;
  WORD  flags; /* 8 - ignore crc32, usize and psize - must be read from local header */
  WORD  compr;
  /* 2 */
} naz_list;
#pragma pack(pop)

void CRC32BuildTable(DWORD *r) {
DWORD i, j;
  if (r) {
    for (i = 0; i < 256; i++) {
      *r = i;
      for (j = 0; j < 8; j++) {
        *r = (*r >> 1) ^ (0xEDB88320 * (*r & 1));
      }
      r++;
    }
  }
}

/* must be below 3Kb because it's stack variable */
#define MAX_BLOCK 0x800

DWORD CRC32File(FILE *fl, DWORD sz) {
DWORD crctab[256], crc, i, l;
BYTE b[MAX_BLOCK];
  CRC32BuildTable(crctab);
  crc = (DWORD) -1;
  while (sz) {
    l = (sz < MAX_BLOCK) ? sz : MAX_BLOCK;
    fread(b, 1, l, fl);
    for (i = 0; i < l; i++) {
      crc = crctab[LOBYTE(crc ^ b[i])] ^ (crc >> 8);
    }
    sz -= l;
  }
  return(crc ^ ((DWORD) -1));
}

void NAZNameDecrypt(FILE *fl, DWORD sz) {
BYTE b[MAX_BLOCK];
DWORD i, l, o;
  o = ftell(fl);
  while (sz) {
    l = (sz < MAX_BLOCK) ? sz : MAX_BLOCK;
    fseek(fl, o, SEEK_SET);
    fread(b, l, 1, fl);
    for (i = 0; i < l; i++) {
      b[i] = ((b[i] << 2) | (b[i] >> 6));
    }
    fseek(fl, o, SEEK_SET);
    fwrite(b, l, 1, fl);
    o += l;
    sz -= l;
  }
}

void NAZCopyBlocks(FILE *fl, DWORD sz, DWORD o1, DWORD o2) {
BYTE b[MAX_BLOCK];
DWORD l;
  while (sz) {
    l = (sz < MAX_BLOCK) ? sz : MAX_BLOCK;
    fseek(fl, o1, SEEK_SET);
    fread(b, l, 1, fl);
    fseek(fl, o2, SEEK_SET);
    fwrite(b, l, 1, fl);
    o1 += l;
    o2 += l;
    sz -= l;
  }
}

char *basename(char *s) {
char *r;
  if (s) {
    for (r = s; *r; r++) {
      if ((*r == '/') || (*r == '\\')) {
        s = &r[1];
      }
    }
  }
  return(s);
}

void newext(char *name, char *ext) {
char *p;
  if (name && ext) {
    for (; (*name == '.'); name++);
    for (p = NULL; *name; name++) {
      if (*name == '.') {
        p = name;
      }
    }
    strcpy(p ? p : name, ext);
  }
}

int main(int argc, char *argv[]) {
zip_head zh;
zip_list zl;
zip_item zi;
naz_list nl;
FILE *fl;
DWORD i, j;
char s[MAX_PATH];
  printf("Total Overdose .NAZ to .ZIP converter v1.0\n(c) CTPAX-X Team 2018\nhttp://www.CTPAX-X.org/\n\n");
  if (argc != 2) {
    printf("Usage: naztozip <filename.naz>\n\n");
    return(1);
  }
  fl = fopen(argv[1], "rb");
  if (!fl) {
    printf("Error: can't open input file.\n\n");
    return(2);
  }
  /* check minimal file size */
  fseek(fl, 0, SEEK_END);
  i = ftell(fl);
  if (i <= sizeof(zh)) {
    fclose(fl);
    printf("Error: input file not a .NAZ archive (file too small).\n\n");
    return(3);
  }
  /* read ZIP central directory */
  memset(&zh, 0, sizeof(zh));
  j = i - sizeof(zh);
  fseek(fl, j, SEEK_SET);
  fread(&zh, sizeof(zh), 1, fl);
  fclose(fl);
  /* check magic numbers */
  if ((zh.magic ^ NAZ_HEAD) || (zh.ditem ^ zh.titem)) {
    printf("Error: input file not a .NAZ archive (invalid header).\n\n");
    return(4);
  }
  /* create output file */
  strcpy(s, basename(argv[1]));
  printf("%s => ", s);
  newext(s, ".zip");
  printf("%s\n\n", s);
  printf("1/2 Copying file");
  i = CopyFile(argv[1], s, FALSE);
  printf("\n");
  /* create archive copy */
  if (i) {
    /* just in case strip read-only attributes */
    SetFileAttributes(s, FILE_ATTRIBUTE_NORMAL);
    /* open and fix output file */
    fl = fopen(s, "rb+");
    if (fl) {
      /* fix magic of the central directory */
      fseek(fl, j, SEEK_SET);
      zh.magic = ZIP_HEAD;
      /* write central directory */
      fwrite(&zh, sizeof(zh), 1, fl);
      zl.magic = ZIP_LIST;
      zi.magic = ZIP_ITEM;
      printf("2/2 Decrypting file");
      for (i = 0; i < zh.titem; i++) {
        /* go to list */
        fseek(fl, zh.doffs, SEEK_SET);
        /* read and fix list */
        fread(&nl, sizeof(nl), 1, fl);
        /* check for error */
        if (nl.magic != NAZ_LIST) { break; }
        /* fix header */
        zl.cvers = nl.cvers;
        zl.nvers = nl.nvers;
        zl.flags = nl.flags;
        zl.compr = nl.compr;
        zl.mtime = nl.mtime;
        zl.mdate = nl.mdate;
        zl.crc32 = nl.crc32;
        zl.psize = nl.psize;
        zl.usize = nl.usize;
        zl.nsize = nl.nsize;
        zl.isize = nl.isize;
        zl.csize = nl.csize;
        zl.dstrt = nl.dstrt;
        zl.iattr = nl.iattr;
        zl.eattr = nl.eattr;
        zl.hoffs = nl.hoffs;
        /* fix CRC32 */
        fseek(fl, zl.hoffs + sizeof(zi) + zl.nsize + zl.isize, SEEK_SET);
        nl.crc32 = CRC32File(fl, zl.usize);
        /*
          http://pkware.cachefly.net/webdocs/casestudies/APPNOTE.TXT

          Official documentation states:

          > 4.3.9.3 Although not originally assigned a signature, the value
          > 0x08074b50 has commonly been adopted as a signature value
          > for the data descriptor record.  Implementers should be
          > aware that ZIP files may be encountered with or without this
          > signature marking data descriptors and SHOULD account for
          > either case when reading ZIP files to ensure compatibility.

          But WinZIP and Info-ZIP didn't follow this and strictly check for signature.
          Files can be extracting just fine (at least in WinZIP, Info-ZIP and WinRAR)
          but archive integrity check still may fail.

          fix CRC32 in data descriptor (old format without PK signature)
        */
        fwrite(&nl.crc32, 4, 1, fl);
        /* write fixed header */
        zl.crc32 = nl.crc32;
        fseek(fl, zh.doffs, SEEK_SET);
        fwrite(&zl, sizeof(zl), 1, fl);
        zh.doffs += sizeof(zl);
        /* decrypt name */
        NAZNameDecrypt(fl, zl.nsize);
        /*
          zap_item (zip_item) filled with junk or encrypted
          but the game never actually reads it or decrypt
          so we forced to restore whole .ZIP local header manually
        */
        zi.nvers = nl.nvers;
        zi.flags = nl.flags;
        zi.compr = nl.compr;
        zi.mtime = nl.mtime;
        zi.mdate = nl.mdate;
        zi.crc32 = nl.crc32;
        zi.psize = nl.psize;
        zi.usize = nl.usize;
        zi.nsize = nl.nsize;
        zi.isize = nl.isize;
        /* fix item */
        fseek(fl, zl.hoffs, SEEK_SET);
        fwrite(&zi, sizeof(zi), 1, fl);
        /* copy name and additional data if any */
        NAZCopyBlocks(fl, zl.nsize + zl.isize, zh.doffs, ftell(fl));
        /* next item offset */
        zh.doffs += zl.nsize + zl.isize + zl.csize;
      }
      fclose(fl);
      printf("\n\n");
      if (i >= zh.titem) {
        printf("done\n\n");
        i = 0;
      } else {
        printf("Error: invalid input file data.\n\n");
        i = 7;
      }
    } else {
      printf("Error: can't open output file.\n\n");
      i = 6;
    }
  } else {
    printf("Error: can't create output file.\n\n");
    i = 5;
  }
  /* error - delete partial file */
  if (i) { DeleteFile(s); }
  return(i);
}
