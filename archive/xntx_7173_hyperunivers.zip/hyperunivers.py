﻿import os
import time
import glob
import csv
import shutil
from itertools import cycle
import codecs

start = time.time()
print('starting python session')

###############################################################################
## <Functions>

## xor de-/encoder
def xore(data, key):
    return bytes(a ^ b for a, b in zip(data, cycle(key)))

def xor_result(my_input, my_key):
    my_key = my_key.encode('utf-8')
    my_input = my_input.replace(' ','')
    my_input = codecs.decode(my_input, 'hex_codec')
    return codecs.encode(xore( my_input, my_key ), 'hex')

def csv2list(csv_file):
    with open(csv_file, 'r', encoding='utf-8-sig') as f:
        csv_reader = csv.reader(f, delimiter='\t', quotechar='"')
        my_list = list(csv_reader)
        return my_list

## </Functions>
###############################################################################
counter = 0

## read csv file without the first 2 lines
data_csv = csv2list('hyperunivers.txt')[2:]
os.makedirs('/succes_original', exist_ok=True)
## path of current py file
dir_path = os.path.dirname(os.path.realpath(__file__))
## create succes folder '/succes_original/' to move old decrypted file
succes_folder = dir_path + '/succes_original/'
os.makedirs( succes_folder, exist_ok=True)

#for iter_i in range(0,2):
for iter_i in range(len( data_csv )):
    old_file_name = data_csv[iter_i][0]
    new_directory = data_csv[iter_i][1]
    my_key = data_csv[iter_i][2]
    try:
        ##read file
        with open(old_file_name, 'rb') as f:
            data_file_old = f.read()
    except Exception:
        print("error opening file: " + old_file_name + ", continuing")
        continue
    key_len = len(my_key)
    my_input = codecs.encode(data_file_old[7 * 16: 7 * 16 + key_len], 'hex')
    my_xor = xor_result(my_input.decode('utf-8'), my_key)
    my_replace = bytes.fromhex(my_xor.decode('utf-8'))
    #data_file_new = data_file_old[0: 112] + my_replace + data_file_old[112 + key_len:]
    ## optionally replace cabstring
    cab_replace_text = my_key + ((36 - key_len) * ' ')
    data_file_new = data_file_old[0: 75] + cab_replace_text.encode('utf-8') + data_file_old[111: 112] + my_replace + data_file_old[112 + key_len:]
    ## make sure direcory exist,then write file
    os.makedirs(new_directory, exist_ok=True)
    ## create file with same name as xor string
    new_file_path = new_directory + '/' + my_key
    with open(new_file_path, 'wb') as fw:
        fw.write(data_file_new)
    ## move old decrypted file to succes folder '/succes_original/'
    shutil.move(dir_path + '/' + old_file_name, succes_folder + old_file_name)
    counter += 1

print("processed files:" + str(counter))
finished = time.time() - start
print('My python Script Finished in: {0:d} min and {1:.3f} sec .'.format( int(finished // 60), finished % 60))

