// BaoExtr.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Scan.h"

// The action to be taken
enum EAction
{
	EACT_EXTRACT,
	EACT_LIST
};

// The arguments sent to the application
struct SArguments
{
	SArguments() :
		Action(EACT_EXTRACT),
		ShowBanner(true),
		ShowUsage(false),
		InputFilename(""),
		InputOffset(0),
		InputSize(0),
		DataOffset(81),
		OutputDir(""),
		OutputOverwrite(false)
	{
	};

	EAction Action;
	bool ShowBanner;
	bool ShowUsage;
	std::string InputFilename;
	std::streamoff InputOffset;
	std::streamsize InputSize;
	std::streamoff DataOffset;
	std::string OutputDir;
	bool OutputOverwrite;
};

// Parse the arguments sent to the program
bool ParseArguments(SArguments& Args, unsigned long Argc, _TCHAR* Argv[])
{
	// Go through each of the arguments sent
	for(unsigned long i=1;i<Argc;)
	{
		std::string Arg(Argv[i++]);
		
		// Check it
		if(Arg=="-b" || Arg=="--no-banner")
		{
			Args.ShowBanner=false;
		}
		else if(Arg=="-E" || Arg=="--extract")
		{
			Args.Action=EACT_EXTRACT;
		}
		else if(Arg=="-L" || Arg=="--list")
		{
			Args.Action=EACT_LIST;
		}
		else if(Arg=="-o" || Arg=="--output")
		{
			if(i>=Argc)
			{
				return false;
			}
			Args.OutputDir=std::string(Argv[i++]);
		}
		else if(Arg=="-w" || Arg=="--overwrite")
		{
			Args.OutputOverwrite=true;
		}
		else if(Arg=="-n" || Arg=="--no-overwrite")
		{
			Args.OutputOverwrite=false;
		}
		else if(Arg=="-i" || Arg=="--offset")
		{
			if(i>=Argc)
			{
				return false;
			}
			Args.InputOffset=atol(Argv[i++]);
		}
		else if(Arg=="-s" || Arg=="--size")
		{
			if(i>=Argc)
			{
				return false;
			}
			Args.InputSize=atol(Argv[i++]);
		}
		else if(Arg=="-d" || Arg=="--data-offset")
		{
			if(i>=Argc)
			{
				return false;
			}
			Args.DataOffset=atol(Argv[i++]);
		}
		else
		{
			Args.InputFilename=Arg;
		}
	}
	return true;
}

int Extract(SArguments& Args)
{
	// Check the arguments
	if(Args.InputFilename=="")
	{
		std::cerr << "Input file not specified." << std::endl;
		return 1;
	}

	// Open the input stream
	std::ifstream Input;
	Input.open(Args.InputFilename.c_str(), std::ios_base::in | std::ios_base::binary);
	if(!Input.is_open())
	{
		std::cerr << "Unable to open input file '" << Args.InputFilename << "'." << std::endl;
		return 2;
	}

	// If the size is not specified, compute it
	if(Args.InputSize==0)
	{
		Input.seekg(0, std::ios_base::end);
		if(Args.InputOffset<=Input.tellg())
		{
			Args.InputSize=(std::streamoff)Input.tellg()-Args.InputOffset;
		}
		Input.seekg(0);
	}

	// Scan for BAOs
	std::vector<SBaoFile> Files;
	Input.seekg(Args.InputOffset);
	if(!Scan(Input, Args.InputOffset+Args.InputSize, Files))
	{
		Input.close();
		return 3;
	}

	// Figure out the right output dir
	if(Args.OutputDir.empty())
	{
		Args.OutputDir=".\\";
	}
	if(Args.OutputDir.at(Args.OutputDir.size()-1)!='\\' || \
		Args.OutputDir.at(Args.OutputDir.size()-1)!='\\')
	{
		Args.OutputDir.append("\\");
	}

	// Extract the BAOs
	for(std::vector<SBaoFile>::const_iterator Iter=Files.begin();Iter!=Files.end();++Iter)
	{
		// Open the output file
		std::string Filename=Args.OutputDir+Iter->Filename;
		if(Args.OutputOverwrite==false && GetFileAttributes(Filename.c_str())!=INVALID_FILE_ATTRIBUTES)
		{
			std::cout << "The file '" << Filename << "' already exists, not overwriting." << std::endl;
			continue;
		}
		std::ofstream Output;
		Output.open(Filename.c_str(), std::ios_base::out | std::ios_base::binary | std::ios_base::trunc);
		if(!Output.is_open())
		{
			std::cout << "The file '" << Filename << "' could not be created." << std::endl;
		}

		// Read from the input file
		Input.seekg(Iter->Offset+Args.DataOffset);
		const unsigned long InputBufferLength=65535;
		unsigned char* Buffer=new unsigned char[InputBufferLength];
		std::streamsize BytesLeft=Iter->Size-Args.DataOffset;

		// The scanning loop
		while(BytesLeft)
		{
			// Calculate the amount of data that needs to be read
			std::streamsize NextRead;
			std::streamoff CurrentOffset=Input.tellg();
			if(BytesLeft>InputBufferLength)
			{
				NextRead=InputBufferLength;
			}
			else
			{
				NextRead=BytesLeft;
			}

			// This should not happen, but we'll check for it anyways
			if(!NextRead)
			{
				break;
			}

			// Read the data
			Input.read((char*)Buffer, (std::streamsize)NextRead);
			BytesLeft-=NextRead;

			// Write the data
			Output.write((char*)Buffer, (std::streamsize)NextRead);
		}

		// Close the output file
		delete[] Buffer;
		Output.close();
	}

	// Close the files
	Input.close();
	return 0;
}

int List(SArguments& Args)
{
	// Check the arguments
	if(Args.InputFilename=="")
	{
		std::cerr << "Input file not specified." << std::endl;
		return 1;
	}

	// Open the input stream
	std::ifstream Input;
	Input.open(Args.InputFilename.c_str(), std::ios_base::in | std::ios_base::binary);
	if(!Input.is_open())
	{
		std::cerr << "Unable to open input file '" << Args.InputFilename << "'." << std::endl;
		return 2;
	}

	// If the size is not specified, compute it
	if(Args.InputSize==0)
	{
		Input.seekg(0, std::ios_base::end);
		if(Args.InputOffset<=Input.tellg())
		{
			Args.InputSize=(std::streamoff)Input.tellg()-Args.InputOffset;
		}
		Input.seekg(0);
	}

	// Scan for BAOs
	std::vector<SBaoFile> Files;
	Input.seekg(Args.InputOffset);
	if(!Scan(Input, Args.InputOffset+Args.InputSize, Files))
	{
		Input.close();
		return 3;
	}

	// List the BA0s
	for(std::vector<SBaoFile>::const_iterator Iter=Files.begin();Iter!=Files.end();++Iter)
	{
		std::cout << Iter->Filename << ", " << Iter->Offset+Args.DataOffset << ", " << Iter->Size-Args.DataOffset << std::endl;
	}

	// Close the files
	Input.close();
	return 0;
}

int _tmain(int Argc, _TCHAR* Argv[])
{
	// Parse the arguments
	SArguments Args;
	if(Argc==1)
	{
		Args.ShowUsage=true;
	}
	bool ArgParse=ParseArguments(Args, Argc, Argv);

	// Display banner
	if(Args.ShowBanner)
	{
		std::cerr << "Assassin's Creed BAO Extractor" << std::endl << std::endl;
	}

	// Display usage
	if(Args.ShowUsage)
	{
		std::cout << "Usage: BaoExtr InputFilename [Options]" << std::endl;
		std::cout << std::endl;
		std::cout << "Extract: (-E, --extract) (default)" << std::endl;
		std::cout << "  -i, --offset Number   Specify the offset to start scanning for BAOs" << std::endl;
		std::cout << "  -s, --size Number     Specify the number of bytes to scan" << std::endl;
		std::cout << "  -d, --data-offset Num Specify the offset of the data from after the filename" << std::endl;
		std::cout << "  -o, --output Dir      Specify the output directory" << std::endl;
		std::cout << "  -w, --overwrite       Overwrite existing files" << std::endl;
		std::cout << "  -n, --no-overwrite    Don't overwrite existing files" << std::endl;
		std::cout << std::endl;
		std::cout << "List All Files: (-L, --list)" << std::endl;
		std::cout << "  -i, --offset Number   Specify the offset to start scanning for BAOs" << std::endl;
		std::cout << "  -s, --size Number     Specify the number of bytes to scan" << std::endl;
		std::cout << "  -d, --data-offset Num Specify the offset of the data from after the filename" << std::endl;
		std::cout << std::endl;
	}

	// Check for errors
	if(!ArgParse)
	{
		std::cerr << "The arguments are not valid." << std::endl;
		return 1;
	}

	// Process it based on the action required
	int ReturnValue=1;
	switch(Args.Action)
	{
		case EACT_EXTRACT:
			ReturnValue=Extract(Args);
		break;
		case EACT_LIST:
			ReturnValue=List(Args);
		break;
	}
	return ReturnValue;
}

