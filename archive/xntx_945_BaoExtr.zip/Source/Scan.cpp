/*
  Scan.h
  Functions for scanning containers for BAO files
*/

#include "stdafx.h"
#include "Scan.h"

// Do the actual scanning, to figure out roughly when the file is
static bool DoScan(std::istream& Input, std::streamoff EndOffset, std::streamsize& BytesRead, std::string& Filename)
{
	// Just check first
	if(Input.tellg()>=EndOffset)
	{
		return false;
	}

	// Some variables
	const unsigned long InputBufferLength=65535;
	unsigned char* Buffer=new unsigned char[InputBufferLength];
	std::streamsize BytesLeft=EndOffset-Input.tellg();
	std::streamoff StartOffset=Input.tellg();
	Filename="";

	// The scanning loop
	while(Input.tellg()<EndOffset)
	{
		// Calculate the amount of data that needs to be read
		std::streamsize NextRead;
		std::streamoff CurrentOffset=Input.tellg();
		if(BytesLeft>InputBufferLength)
		{
			NextRead=InputBufferLength;
		}
		else
		{
			NextRead=BytesLeft;
		}

		// This should not happen, but we'll check for it anyways
		if(!NextRead)
		{
			break;
		}

		// Read the data
		Input.read((char*)Buffer, (std::streamsize)NextRead);
		BytesLeft-=NextRead;

		// Process the data in a for loop
		std::streamoff OffsetReset=Input.tellg();
		for(unsigned long i=0;i<(unsigned long)NextRead;i++)
		{
			// Store some variables
			const std::streamoff ChunkStart=(std::streamoff)CurrentOffset+i;

			if(Buffer[i]=='B')
			{
				// Speed optimization
				if(i+1<(unsigned long)NextRead && Buffer[i+1]!='A')
				{
					continue;
				}
				if(i+2<(unsigned long)NextRead && Buffer[i+2]!='O')
				{
					continue;
				}
				if(i+3<(unsigned long)NextRead && Buffer[i+3]!='_')
				{
					continue;
				}

				// Seek if we really have something here
				Input.seekg(ChunkStart);
				char Sig[4];
				Input.read(Sig, 4);
				if(memcmp(Sig, "BAO_", 4)!=0)
				{
					continue;
				}

				// Get the filename
				Filename="BAO_";
				for(unsigned long i=4;i<32;i++)
				{
					char C;
					Input.read(&C, 1);
					if(!C)
					{
						break;
					}
					Filename.append(1, C);
				}

				// The file is valid so far, so return success
				Input.seekg(ChunkStart);
				BytesRead=ChunkStart-StartOffset;
				delete [] Buffer;
				return true;
			}
		}

		// Reset back
		Input.seekg(OffsetReset);
	}

	// Clean up
	delete[] Buffer;
	return false;
}

bool Scan(std::istream& Input, std::streamoff EndOffset, std::vector<SBaoFile>& List)
{
	// Set up some things
	unsigned long NumberFound=0;
	std::streamsize BytesRead;
	std::string PrevFilename;
	std::string Filename;

	// Scan for the first file
	bool Found=DoScan(Input, EndOffset, BytesRead, PrevFilename);

	// Loop, until we could find no more files
	while(Found)
	{
		// Save the offset of the current file (already found)
		std::streamoff ChunkOffset=Input.tellg();

		// Seek past the current chunk, saving the current chunk size
		std::streamsize ChunkSize;
		ChunkSize=0;
		Input.seekg(32, std::ios_base::cur);

		// Scan for the next chunk
		Found=DoScan(Input, EndOffset, BytesRead, Filename);
		if(Found)
		{
			// We already passed the header so we don't find it again
			//BytesRead+=28;
		}
		else
		{
			// Assume it goes to the end of the file
			BytesRead=EndOffset-ChunkOffset;
		}

		// Make sure the chunk has some reasonable size
		/*if(!ChunkSize && BytesRead<48)
		{
			// Assume it is a simple chunk
			// Skip to the next file; this one is too small
			// The next file cannot start at the next byte
			Input.seekg(29, std::ios_base::cur);
			Found=DoScan(Input, EndOffset, BytesRead, SizeReadFromFile);
			continue;
		}*/

		// Set some variables
		if(!ChunkSize)
		{
			ChunkSize=BytesRead;
		}

		//std::cout << PrevFilename << "\t" << ChunkOffset+81 << "\t" << ChunkSize-81;
		//NumberFound++;
		SBaoFile File;
		File.Filename=PrevFilename;
		File.Offset=ChunkOffset;
		File.Size=ChunkSize;
		List.push_back(File);

		/*unsigned char Char[36];
		std::streamoff Prev=Input.tellg();
		Input.seekg(ChunkOffset);
		Input.read((char*)Char, 36);
		std::cout << "\t";
		for(unsigned long j=0;j<36;j++)
		{
			std::cout << (int)Char[j] << "\t";
		}
		Input.seekg(Prev);*/
		PrevFilename=Filename;

		//std::cout << std::endl;
	}
	//std::cerr << "Found: " << NumberFound << std::endl;
	return true;
}
