/*
  stdafx.h
  Precompiled header
*/

#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <tchar.h>

#define VC_EXTRALEAN
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
