/*
  Scan.h
  Functions for scanning containers for BAO files
*/

#pragma once

// Required headers
#include <iostream>
#include <vector>
#include <string>

// A bao file
struct SBaoFile
{
	std::string Filename;
	std::streamoff Offset;
	std::streamsize Size;
};

// Functions
bool Scan(std::istream& Input, std::streamoff EndOffset, std::vector<SBaoFile>& List);
