#!/usr/bin/python

# Extracts files inside an IZCA file.
#
# Author: gomtuu
# Version: 1.0

import os, sys, struct

SEEK_RELATIVE = True

try:
    IZCA = open(sys.argv[1], 'rb')
except:
    print 'Please specify input file.'
    print 'Usage: izca_split <infile.IZCA> <outdir>'
    sys.exit(1)

try:
    output_dir = sys.argv[2]
except IndexError:
    print 'Please specify output directory.'
    print 'Usage: izca_split <infile.IZCA> <outdir>'
    sys.exit(1)

def read_int(F):
    return struct.unpack('<I', F.read(4))[0]

ext = IZCA.read(4)
assert ext == 'IZCA', 'File is not an IZCA archive.'
block_length = read_int(IZCA)
header_length = read_int(IZCA)
IZCA.seek(header_length)
# Files in IZCA file are divided into sections for an unknown reason.
# This is the number of sections:
section_count = read_int(IZCA)
IZCA.seek(4, SEEK_RELATIVE)
sections_toc = []
pieces = []
for section in range(section_count):
    toc_pointer = read_int(IZCA)
    toc_entries = read_int(IZCA)
    sections_toc.append((section, toc_pointer, toc_entries))
for (section, toc_pointer, toc_entries) in sections_toc:
    IZCA.seek(toc_pointer)
    for j in range(toc_entries):
        piece_pointer = read_int(IZCA)
        pieces.append((section, j, piece_pointer))
for (section, i, piece_pointer) in pieces:
    IZCA.seek(piece_pointer)
    ext = IZCA.read(4)
    piece_length = read_int(IZCA)
    header_length = read_int(IZCA)
    print '%u 0x%x 0x%x %s' % (section, piece_pointer, piece_length + header_length, ext)
    IZCA.seek(piece_pointer)
    piece = IZCA.read(piece_length + header_length)
    filename = 's%02u_f%03u.%s' % (section, i, ext)
    OUT = open(os.path.join(output_dir, filename), 'wb')
    OUT.write(piece)
    OUT.close()
