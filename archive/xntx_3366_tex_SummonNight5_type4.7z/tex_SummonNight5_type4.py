from inc_noesis import *
import noesis
import rapi

texList = []

def registerNoesisTypes():
	handle = noesis.register("SN5 Textures", ".type4")
	noesis.setHandlerTypeCheck(handle, SN5CheckType)
	noesis.setHandlerLoadRGBA(handle, SN5LoadRGBA)
	#noesis.logPopup()
	return 1

def SN5CheckType(data):
	bs = NoeBitStream(data)
	magic = bs.readUInt()
	if magic != 0x10003101:
		return 0
	return 1

def SN5LoadRGBA(data, texList):
	bs = NoeBitStream(data)
	header = bs.read("12I")
	#print(header)
	texPal = []
	for a in range(0, header[4]):
		texPal.append(bs.read("8I"))
	#print(texPal)
	bs.seek(header[7], NOESEEK_ABS)
	texInfo = []
	texCount = bs.readUInt()
	for a in range(0, texCount):
		texInfo.append(bs.read("4H4I4H"))
	#print(texInfo)

	bs.seek(header[8], NOESEEK_ABS)
	palInfo = []
	palCount = bs.readUInt()
	for a in range(0, palCount):
		palInfo.append(bs.read("5I"))
	#print(palInfo)
	bigTex = bytearray()
	bigWidth = 0
	bigHeight = 0
	for a in range(0, texCount):
		bs.seek(texInfo[a][4], NOESEEK_ABS)
		texData = bs.readBytes(texInfo[a][5])
		bs.seek(palInfo[(texPal[a][2])][0], NOESEEK_ABS)
		palData = bs.readBytes(palInfo[(texPal[a][2])][1])
		if texInfo[a][6] == 5:
			pix = rapi.imageUntwiddlePSP(texData, texInfo[a][11], texInfo[a][1], 8)
			pix = rapi.imageDecodeRawPal(pix, palData, texInfo[a][11], texInfo[a][1], 8, "r8g8b8a0p8")
			texList.append(NoeTexture(str(a), texInfo[a][11], texInfo[a][1], pix, noesis.NOESISTEX_RGBA32))
		if texInfo[a][6] == 4:
			pix = rapi.imageUntwiddlePSP(texData, texInfo[a][0], texInfo[a][1], 4)
			pix = rapi.imageDecodeRawPal(pix, palData, texInfo[a][0], texInfo[a][1], 4, "r8g8b8a8")
			texList.append(NoeTexture(str(a), texInfo[a][0], texInfo[a][1], pix, noesis.NOESISTEX_RGBA32))
		if texInfo[a][6] == 3:
			pix = rapi.imageUntwiddlePSP(texData, texInfo[a][0], texInfo[a][1], 32)
			texList.append(NoeTexture(str(a), texInfo[a][0], texInfo[a][1], pix, noesis.NOESISTEX_RGBA32))
		bigTex += pix
	for a in range(0, header[5]):
		bigWidth += texInfo[a][11]
		#print(texInfo[a][11])
	for a in range(0, texCount, texCount // header[6]):
		bigHeight += texInfo[a][1]
		#print(texInfo[a][1])
	#print(bigWidth, bigHeight)
	#texList.append(NoeTexture(str(35), bigWidth, bigHeight, bigTex, noesis.NOESISTEX_RGBA32))
	return 1