#by Durik256 for xentax
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Aerial Strike: The Yager Missions", ".yod")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)
    return 1

def noepyCheckType(data):
    if data[:3] != b'YOD':
        return 0
    return 1   
	
def noepyLoadModel(data, mdlList):
    bs = NoeBitStream(data)
    ctx = rapi.rpgCreateContext()
    
    bs.seek(4)#YOD
    file_size, file_unk, num_mesh = bs.readInt(), bs.readInt(), bs.readInt()
    
    name_mdl = searchString(bs)
    for x in range(num_mesh):
        bs.seek(4,1)#MESH
        curPos = bs.getOffset() + 4
        size_mesh, vert, lod, mat = [bs.readInt() for x in range(4)]
        name_mesh = searchString(bs)
        print('MESH',name_mesh)
        bs.seek(4,1)#VERT
        size_vert, vnum, stride, vunk = [bs.readInt() for x in range(4)]
        print('vnum',vnum,'stride',stride)
        vbuf = bs.readBytes(vnum * stride)
        bs.seek(4,1)#LOD
        lod_size, lnum = bs.readInt(), bs.readInt()#num?
        bs.seek(4,1)#TRIS
        tris_size, tunk, face_num = bs.readInt(), bs.readInt(), bs.readInt()
        print('face_num',face_num)
        ibuf = bs.readBytes(face_num * 6)
        
        rapi.rpgSetName(name_mesh)
        rapi.rpgBindPositionBuffer(vbuf, noesis.RPGEODATA_FLOAT, stride)
        if stride > 24:
            rapi.rpgBindUV1BufferOfs(vbuf, noesis.RPGEODATA_FLOAT, stride, stride-8)
        rapi.rpgCommitTriangles(ibuf, noesis.RPGEODATA_USHORT, face_num * 3, noesis.RPGEO_TRIANGLE)
        
        bs.seek(4,1)#ATTR
        attr_size, anum = bs.readInt(), bs.readInt()
        for x in range(anum):
            ATTR = [bs.readInt() for x in range(5)]
            #print('ATTR',ATTR)
        
        bs.seek(4,1)#BNDV
        bs.seek(bs.readInt(),1)
        if mat:
            bs.seek(4,1)#MTRL
            mat_size, mnum = bs.readInt(), bs.readInt()
            for x in range(mnum):
                munk = [bs.readInt() for x in range(6)]
                mname = searchString(bs)
    
        bs.seek(curPos + size_mesh)

    mdl = rapi.rpgConstructModel()
    #mdl.setModelMaterials(NoeModelMaterials([],[NoeMaterial('mat0','')]))
    mdlList.append(mdl)
    return 1
    
def searchString(bs):
    bytes = []
    byte = None
    while byte != 0:
        byte = bs.readUByte()
        bytes.append(byte)
    return noeAsciiFromBytes(bytes)