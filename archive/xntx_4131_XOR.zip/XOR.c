/*
 * SD Gundam Mobile - PNG XOR Tool
 * by herbert3000
 * Nov 29 2014
 * http://forum.xentax.com/viewtopic.php?f=18&t=12264
*/

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>

const char *szCommand = "<not yet set>";
static FILE *fp = (FILE *) 0;

static int xorArray[16] = { 99, 199, 246, 235, 32, 40, 110, 148, 40, 209, 27, 162, 36, 84, 20, 9 };
// PNG header =  89 50 4E 47 0D 0A 1A 0A 00 00 00 0D 49 48 44 52

void BailOut(const char *szMessage);

void PrintError(const char *szMessage)
{
	if (errno != 0)
	{
		(void) fprintf(stderr, "%s: %s - %s\n", szCommand, szMessage, strerror(errno));
	}
	else
	{
		(void) fprintf(stderr, "%s: %s\n", szCommand, szMessage);
	}
}

void closeFile(void)
{
	if (fp = (FILE *) 0)
	{
		if (fclose((FILE *) fp) == EOF)
		{
			fp = (FILE *) 0;
			BailOut("Cannot close file!");
		}
		fp = (FILE *) 0;
	}
}

void FreeResources(void)
{
	closeFile();
}

void BailOut(const char *szMessage)
{
	if (szMessage != (const char *) 0)
	{
		PrintError(szMessage);
	}
	FreeResources();
	exit(EXIT_FAILURE);
}

void Usage(void)
{
	fprintf(stderr, "USAGE: %s <filename> [<filename> ...]\n", szCommand);
	BailOut((const char *) 0);
}

int main(int argc, char **argv)
{
	szCommand = argv[0];

    if(argc < 2)
	{
        Usage();
    }

	int j;
	for (j = 1; j < argc; j ++)
	{
		char *filename = argv[j];

		int filesize;
		unsigned char *buffer;

		// open file for reading
		if ((fp = fopen(filename, "rb")) == NULL ) {
			(void) fprintf(stderr, "%s: cannot open %s: %s\n", szCommand, filename, strerror(errno));
			exit(EXIT_FAILURE);
		}

		fseek(fp, 0, SEEK_END); // seek to end of file
		filesize = ftell(fp);   // get current file pointer
		fseek(fp, 0, SEEK_SET); // seek back to beginning of file

		buffer = malloc(filesize);

		// read from file
		if (fread(buffer, 1, filesize, fp) != filesize) {
			BailOut("Error reading from file!");
	    }

		closeFile();

		// XOR the file
		int i;
		for (i = 0; i < filesize; i ++)
		{
			buffer[i] = buffer[i] ^ xorArray[i % 16];
		}

		// open file for writing
		if ((fp = fopen(filename, "wb")) == NULL ) {
			(void) fprintf(stderr, "%s: cannot open %s: %s\n", szCommand, filename, strerror(errno));
			exit(EXIT_FAILURE);
		}

		// write to file
		if (fwrite(buffer, 1, filesize, fp) != filesize) {
			BailOut("Error writing to file!");
	    }

		free(buffer);
		closeFile();
	}

    exit(EXIT_SUCCESS);

	return 0; // not reached
}
