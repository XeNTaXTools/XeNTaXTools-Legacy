﻿# Fantasy Tennis dat importer by Bigchillghost

import rapi
from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Fantasy Tennis", ".dat")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadModel(handle, noepyLoadModel)
	#noesis.logPopup()
	return 1

#check if it's this type based on the data
def noepyCheckType(data):
	if len(data) < 0x80:
		return 0
	bs = NoeBitStream(data)
	bs.seek(0xC, NOESEEK_ABS)
	Magic = bs.readUInt()
	if Magic != 2:		# experimental type check
		return 0
	return 1

#load the model
def noepyLoadModel(data, mdlList):
	bs = NoeBitStream(data)
	bs.seek(0x10, NOESEEK_ABS)
	boneCount = bs.readInt()
	bs.seek(4, NOESEEK_REL)
	ObjectCount = bs.readInt()
	bs.seek(4, NOESEEK_REL)
	ObjectMeshCnt = []
	Offset = bs.tell()
	IdxSum = 0
	for i in range(0, ObjectCount):
		bs.seek(4, NOESEEK_REL)
		ObjectID = bs.readInt()
		allFields = bs.readInt()
		bs.seek(0x40, NOESEEK_REL)
		Cnt = 0
		IdxSum += 1
		while 1:
			Test1 = bs.readInt()
			Test2 = bs.readInt()
			bs.seek(-8, NOESEEK_REL)
			if Test1 > 0xFFFF or (allFields > 0 and Test1 == 1 and Test2 - 1 == ObjectID):
				break
			if allFields > 0:
				bs.seek(4, NOESEEK_REL)
				BoneIdCnt = bs.readInt()
				if BoneIdCnt > 0:
					bs.seek(BoneIdCnt*4+8, NOESEEK_REL)
			VCnt = bs.readInt()
			FaceCnt = bs.readInt()
			Flag = bs.readInt()
			if Flag == 0:
				bs.seek(VCnt*0x24, NOESEEK_REL)
			elif Flag == 2:
				bs.seek(VCnt*0x38, NOESEEK_REL)
			elif Flag == 4:
				bs.seek(VCnt*0x20, NOESEEK_REL)
			IdxSum += FaceCnt + 2
			Cnt += 1
		ObjectMeshCnt.append(Cnt)
	
	bones = []
	for i in range(0, boneCount):
		boneName = bs.readString()
		bs.seek(0x1F - len(boneName), NOESEEK_REL)
		bs.readBytes(0x20) # parentBoneName
		bs.seek(0x20, NOESEEK_REL) # Skip Trans[4] + Rot[4]
		MatWorld = NoeMat44.fromBytes( bs.readBytes(0x40) )
		boneMat = MatWorld.toMat43() #.inverse()
		bs.seek(0x80, NOESEEK_REL) # Skip MatLocal[16] + MatWorldInverse[16]
		parentID = bs.readInt()
		bs.seek(0xC, NOESEEK_REL)
		bones.append( NoeBone(i, boneName, boneMat, None, parentID) )
	
	hasAnim = bs.readInt()
	if hasAnim == 1:
		bs.seek(8, NOESEEK_REL)
		for i in range(0, boneCount):
			FramesCnt = bs.readInt()
			bs.seek(FramesCnt*0xC, NOESEEK_REL)
			FramesCnt = bs.readInt()
			bs.seek(FramesCnt*0x10+4, NOESEEK_REL)
	
	bs.seek(2, NOESEEK_REL)
	IdxOffset = bs.tell()
	bs.seek(IdxSum*2, NOESEEK_REL)
	NameLen = 0x1CD
	NameType1 = bs.readUShort()
	if NameType1 != 1:
		NameType2 = bs.readUShort()
		if NameType1 == 0 and NameType2 == 1:
			NameLen = 0x8D
	ObjectNames = []
	for i in range(0, ObjectCount):
		ObjectID = bs.readUByte()
		ObjectName = bs.readString()
		if i + 1 < ObjectCount:
			bs.seek(NameLen - len(ObjectName), NOESEEK_REL)
		ObjectNames.append(ObjectName)
	
	bs.seek(Offset, NOESEEK_ABS)
	
	ctx = rapi.rpgCreateContext()
	for i in range(0, ObjectCount):
		meshCount = ObjectMeshCnt[i]
		IdxOffset += 2
		bs.seek(8, NOESEEK_REL)
		allFields = bs.readInt()
		bs.seek(0x40, NOESEEK_REL)
		for j in range(0, meshCount):
			meshName = ObjectNames[i] + '_mesh%d'%j
			if allFields > 0:
				bs.seek(4, NOESEEK_REL)
				BoneIdCnt = bs.readInt()
				if BoneIdCnt > 0:
					bs.seek(BoneIdCnt*4+8, NOESEEK_REL)
			Vcount = bs.readInt()
			FaceCnt = bs.readInt()
			Flag = bs.readInt()
			sizeofV = 0x20
			if Flag == 0:
				sizeofV += 4
			elif Flag == 2:
				sizeofV += 0x18
			Vsize = Vcount * sizeofV
			FIcount = FaceCnt + 2
			Vdata = bs.readBytes(Vsize)
			nextMeshOffset = bs.tell()
			bs.seek(IdxOffset, NOESEEK_ABS)
			idxData = bs.readBytes(FIcount*2)
			IdxOffset = bs.tell()
			bs.seek(nextMeshOffset, NOESEEK_ABS)
	
			rapi.rpgSetName(meshName)
			rapi.rpgBindPositionBuffer(Vdata, noesis.RPGEODATA_FLOAT, sizeofV)
			rapi.rpgBindNormalBufferOfs(Vdata, noesis.RPGEODATA_FLOAT, sizeofV, 0xC)
			rapi.rpgBindUV1BufferOfs(Vdata, noesis.RPGEODATA_FLOAT, sizeofV, 0x18)
			rapi.rpgCommitTriangles(idxData, noesis.RPGEODATA_USHORT, FIcount, noesis.RPGEO_TRIANGLE_STRIP, 1)
			rapi.rpgClearBufferBinds()
			
	mdl = rapi.rpgConstructModel()
	mdl.setBones(bones)
	mdlList.append(mdl)
	
	return 1

