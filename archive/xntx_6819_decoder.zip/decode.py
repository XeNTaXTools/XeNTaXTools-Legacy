from PIL import Image

def restore_channel(atlas, x_index, y_index, a_index):
    result = Image.new("RGB", (1024, 1024))

    insert_x = 0
    insert_y = 0
    for x, y, a in zip(x_index.getdata(),
                       y_index.getdata(),
                       a_index.getdata()):

        result.paste(atlas[a].crop((x * 32,
                                    y * 32,
                                    (x + 1) * 32,
                                    (y + 1) * 32)),
                     (insert_x, insert_y))

        insert_x += 32

        if insert_x == 1024:
            insert_x = 0
            insert_y += 32

    return result

if __name__ == "__main__":
    # Number of atlases (change if needed)
    atlases_cnt = 15
    # Number of indices (change if needed)
    indices_cnt = 7

    # Add shift pairs (change if needed)
    add_shifts = {288: 2}

    # Atlas name format (change if needed)
    atlas_name = "./atlas/atlas_{}.png"
    # Index name format (change if needed)
    index_name = "./index/index_{}.png"
    # Out file name format (change if needed)
    out_name = "./unpacked/tex_{}.png"
    
    atlas = [Image.open(atlas_name.format(i)) for i in range(atlases_cnt)]
    index = [Image.open(index_name.format(i)) for i in range(indices_cnt)]

    # Additional shift for unused tiles
    add_shift = 0
    # For all images
    for i in range(indices_cnt * 512 // 12):
        channels = []

        print("Image", i)

        if i in add_shifts:
            add_shift = add_shifts[i]

        # For all channels
        for j in range(4):
            masks = []

            # For all index masks
            for k in range(3):
                x = (i * 12 + j * 3 + k + add_shift) % 512 % 64
                y = (i * 12 + j * 3 + k + add_shift) % 512 // 64
                a = (i * 12 + j * 3 + k + add_shift) // 512
    
                masks.append(index[a].crop((x * 32, y * 32,
                                            (x + 1) * 32, (y + 1) * 32)))

            channels.append(restore_channel(atlas, masks[0], masks[1], masks[2]))

        res = Image.new("RGBA", (1024, 1024))

        res.putdata([pix for pix in zip(channels[0].getdata(0),
                                        channels[1].getdata(0),
                                        channels[2].getdata(0),
                                        channels[3].getdata(0))])
    
        res.save(out_name.format(i))
