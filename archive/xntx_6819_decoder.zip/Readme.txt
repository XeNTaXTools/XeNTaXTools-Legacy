For execution of this script you need Python 3 with module Pillow:

pip3 install pillow

Input images must be in Pillow's supported format (png, bmp).

Change number of atlases/indices, name formats if needed.