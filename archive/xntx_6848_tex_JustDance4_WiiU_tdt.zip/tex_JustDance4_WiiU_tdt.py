from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Just Dance 4 [Wii U]", ".tdt")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
	#noesis.logPopup()
	return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    Magic = bs.readByte()
    print(Magic, "magic")
    if Magic != 2:
        if Magic != 16:
            if Magic != 20:
                return 0
    return 1   
	
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.seek(0x0C, NOESEEK_ABS)         
    imgWidth = bs.readUShort()         
    imgHeight = bs.readUShort()        
    bs.seek(0x10, NOESEEK_ABS)         
    datasize = len(data) - 0x10
    data = bs.readBytes(datasize)      
    texFmt = noesis.NOESISTEX_DXT1
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1