from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Final Fantasy X HD (PC)", ".phyre")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
	#noesis.logPopup()
	return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    Magic = bs.readBytes(4).decode("ASCII")
    if Magic != "RYHP":
        return 0
    return 1
	
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.seek(0x8, NOESEEK_ABS)
    skipOFF = bs.readInt()
    bs.seek(0x44, NOESEEK_REL)
    datasize = bs.readInt()
    bs.seek(skipOFF + 0x70, NOESEEK_REL)
    texNameAndPath = bs.readString()
    print(texNameAndPath)
    tmp = bs.tell()
    myString = bs.readBytes(200)
    myIndex = myString.find(b"\x00\x00\x50\x54\x65\x78\x74\x75\x72\x65\x32\x44")
    print(hex(myIndex))
    bs.seek((myIndex + tmp) - 0x56, NOESEEK_ABS)
    imgWidth = bs.readInt()            
    imgHeight = bs.readInt() 
    print(imgWidth, "x", imgHeight, ":width and height" )
    bs.seek(myIndex + tmp + 13, NOESEEK_ABS)
    imgFmt = bs.readString()
    print(imgFmt, ":format")
    bs.seek(0x25, NOESEEK_REL)        
    data = bs.readBytes(datasize)      
    #DXT1
    if imgFmt == "DXT1":
        texFmt = noesis.NOESISTEX_DXT1
    #DXT5
    elif imgFmt == "DXT5":
        texFmt = noesis.NOESISTEX_DXT5
    #ARGB
    elif imgFmt == "ARGB8":
        data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "b8 g8 r8 a8")
        texFmt = noesis.NOESISTEX_RGBA32
    #unknown, not handled
    else:
        print("WARNING: Unhandled image format " + repr(imgFmt) + " - " + repr(imgWidth) + "x" + repr(imgHeight) + " - " + repr(len(data)))
        return None
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1