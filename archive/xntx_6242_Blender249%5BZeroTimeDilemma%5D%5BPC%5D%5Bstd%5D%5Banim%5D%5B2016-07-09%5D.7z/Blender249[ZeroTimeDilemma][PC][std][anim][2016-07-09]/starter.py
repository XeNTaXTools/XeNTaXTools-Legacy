import newGameLib
from newGameLib import *
import Blender	

import gzip

def ungzip(filename):
	
	f = gzip.open(filename, 'rb')
	file_content = f.read()
	f.close()
	new=open(filename+'.dec','wb')
	new.write(file_content)
	new.close()
	

	
def cfsiParser(filename,g):
	g.i(1)
	g.B(1)
	g.word(g.B(1)[0])
	A=g.i(2)
	fileList=[]
	while(True):
		dirName=g.word(g.B(1)[0])
		if len(dirName)==0:break
		dirPath=g.dirname+os.sep+'files'+os.sep+dirName
		if os.path.exists(dirPath)==False:
			os.makedirs(dirPath)
		count=g.B(1)[0]
		for n in safe(count):
			fileName=g.word(g.B(1)[0])
			B=g.i(2)
			fileList.append([dirPath+fileName,B])
	g.seekpad(16)		
	start=g.tell()	
	for i,file in enumerate(fileList):
		print i,start+file[1][0]*16
		if '.orb' in file[0].lower():
			g.seek(start+file[1][0]*16+4)
			new=open(file[0],'wb')
			new.write(g.read(file[1][1]-4))
			new.close()		
			ungzip(file[0])
			os.remove(file[0])
		else:
			g.seek(start+file[1][0]*16)
			new=open(file[0],'wb')
			new.write(g.read(file[1][1]))
			new.close()		
		#if i==10:break
			
			
		
	
	
	
	
def animParser(filename,g):
	action=Action()
	action.skeleton='armature'
	action.BONESPACE=True
	action.BONESORT=True
	boneCount=g.i(1)[0]
	for m in safe(boneCount):
		bone=ActionBone()
		action.boneList.append(bone)
		bone.name=g.find('\x00')
		posFrameCount=g.i(1)[0]/8
		for n in safe(posFrameCount):
			bone.posFrameList.append(int(g.half(1)[0]))
			bone.posKeyList.append(VectorMatrix(g.half(3)))
		rotFrameCount=g.i(1)[0]/10
		for n in safe(rotFrameCount):
			bone.rotFrameList.append(int(g.half(1)[0]))
			bone.rotKeyList.append(QuatMatrix(g.half(4)).resize4x4())
	action.draw()
	action.setContext()	

	
	
def getSize(value,g):
	if value==253:size=g.i(1)[0]
	elif value==252:size=g.H(1)[0]
	else:size=value
	return size
		

def section22(filename,g):
	meshCount=g.B(1)[0]
	for i in safe(meshCount):
		g.f(3)
		F=g.H(4)
		count=g.B(1)[0]
		off=0
		uvOff=None
		skinIndiceOff=None
		skinWeightOff=None
		for n in safe(count):
			C=g.B(5)
			if C[0]==3:uvOff=off
			if C[0]==7:skinIndiceOff=off
			if C[0]==6:skinWeightOff=off
			if n<count:off+=C[2]*C[3]			
		size=getSize(C[4],g)			
		vertCount=size/C[3]	
		mesh=Mesh()
		mesh.boneID=F[2]
		mesh.matID=F[3]
		if skeleton is not None:
			mesh.BINDSKELETON=skeleton.name
		model.meshList.append(mesh)
		for n in safe(vertCount):
			t=g.tell()
			mesh.vertPosList.append(g.f(3))
			if uvOff is not None:
				g.seek(t+uvOff)
				mesh.vertUVList.append(g.f(2))	
			if skinIndiceOff is not None:
				g.seek(t+skinIndiceOff)
				mesh.skinIndiceList.append(g.B(4))		
			if skinWeightOff is not None:
				g.seek(t+skinWeightOff)
				mesh.skinWeightList.append(g.f(4))	
			g.seek(t+C[3])
		B=g.B(6)
		count=getSize(B[5],g)
		mesh.indiceList=g.H(count)			
		boneMap=g.B(g.B(1)[0])
		g.B(1)
		mesh.TRIANGLE=True
		if len(mesh.skinIndiceList)>0 and len(mesh.skinWeightList)>0:
			if skeleton is not None:mesh.boneNameList=skeleton.boneNameList
			skin=Skin()
			skin.boneIDMap=boneMap
			mesh.skinList.append(skin)
		else:
			if skeleton is not None:mesh.boneNameList=skeleton.boneNameList
			skin=Skin()
			skin.boneMap=[mesh.boneID]
			skin.boneIDMap=boneMap
			mesh.skinList.append(skin)
			for n in range(vertCount):
				mesh.skinIndiceList.append([0])
				mesh.skinWeightList.append([1.0])
	
def section23(filename,g):
	boneCount=g.B(1)[0]
	for m in range(boneCount):
		A=g.B(2)		
		H=g.H(3)
		bone=Bone()
		bone.ID=H[0]
		skeleton.boneList.append(bone)
		if H[1]!=65535:bone.parentID=H[1]
		bone.name=g.word(g.B(1)[0])
		bone.posMatrix=VectorMatrix(g.f(3))
		bone.rotMatrix=QuatMatrix(g.f(4))
		g.f(3)
		g.B(12)
		g.f(2)
		count=g.B(1)[0]
		bone.boneMap=g.H(count)
		g.B(1)
		for n in safe(count):
			g.f(12)
		bb=g.f(3*8)
			
		if A[0]==132:g.B(4)
		if A[0]==212:g.f(10)
		if A[0]==244:g.f(10)
		
	
def section21(filename,g):
	matCount=g.B(1)[0]					
	for m in range(matCount):
		g.word(g.B(1)[0])
		g.B(8)
		diffuseMapIDList.append(-1)
		while(True):
			flag=g.B(1)[0]
			if flag==12:g.word(g.B(1)[0]);g.B(8)
			elif flag==6:g.word(g.B(1)[0]);g.f(4)
			elif flag==7:g.word(g.B(1)[0]);g.f(4)
			elif flag==8:
				name=g.word(g.B(1)[0])
				mapID=g.i(1)[0]
				if name=='diffuseTexture':
					diffuseMapIDList[-1]=mapID
			elif flag==9:g.word(g.B(1)[0]);g.f(4);g.i(1)[0]
			elif flag==2:g.word(g.B(1)[0]);g.B(4)
			elif flag==3:g.word(g.B(1)[0]);g.word(g.B(1)[0])
			elif flag==1:g.word(g.B(1)[0]);g.B(4)
			elif flag==0:
				g.H(g.B(1)[0])
				break								
			else:
				break	
	
def section20(filename,g):
	texCount=g.B(1)[0]
	for m in range(texCount):
		map=g.word(g.B(1)[0]).replace('.tex','.dds')
		mapList.append(map)
	
	
def section60(filename,g):
	animDir=g.dirname+os.sep+g.basename+'_animfiles'
	if os.path.exists(animDir)==False:
		os.makedirs(animDir)
	animCount=g.B(1)[0]
	for i in safe(animCount):
		g.H(2)
		size=g.i(1)[0]
		ta=g.tell()
		animName=g.word(g.B(1)[0])
		print '-'*4,'animation:',animName		
		new=open(animDir+os.sep+animName+'.anim','wb')
		p=BinaryReader(new)		
		g.i(4)
		S=g.B(6)
		if S[5]==128:
			g.B(g.B(1)[0])
		g.B(9)	
		boneCount=g.B(1)[0]
		p.i([boneCount])
		for m in safe(boneCount):
			boneName=g.word(g.B(1)[0])
			new.write(boneName+'\x00')
			g.H(6)
			g.B(4)
			tsize=g.i(1)[0]
			tt=g.tell()
			secCount=g.B(1)[0]
			
			C=g.B(5)
			if C[4]==252:csize=g.H(1)[0]								
			else:csize=C[4]
			p.i([csize])
			new.write(g.read(csize))
			C=g.B(5)
			if C[4]==252:csize=g.H(1)[0]								
			else:csize=C[4]
			p.i([csize])
			new.write(g.read(csize))
			g.seek(tt+tsize)
		g.seek(ta+size)
		new.close()
			
	
def decParser(filename,g):
	global model,skeleton,diffuseMapIDList,mapList
	g.seek(189)
	g.word(g.B(1)[0])
	g.seek(36,1)
	model=None
	skeleton=None
	diffuseMapIDList=None
	mapList=None
	while(True):	
		A=g.B(4)				
		size=g.i(1)[0]
		t=g.tell()
		if A[0]==23:
			if size!=1:
				skeleton=Skeleton()
				skeleton.BONESPACE=True
				skeleton.NICE=True
				section23(filename,g)	
		if A[0]==22:
			if size!=1:
				model=Model(filename)
				section22(filename,g)	
		if A[0]==21:
			if size!=1:
				diffuseMapIDList=[]
				section21(filename,g)				
		if A[0]==20:
			if size!=1:
				mapList=[]
				section20(filename,g)				
		if A[0]==60:
			if size!=1:
				mapList=[]
				section60(filename,g)
		g.seek(t+size)
		if g.tell()>=g.fileSize():break
	
	
	if skeleton is not None:
		skeleton.draw()
	if model is not None:
		for mesh in model.meshList:
			mat=Mat()
			mat.TRIANGLE=True
			if diffuseMapIDList is not None:
				mapID=diffuseMapIDList[mesh.matID]
				if mapID!=-1:
					if mapList is not None:
						if mapID<len(mapList):
							mat.diffuse=g.dirname+os.sep+mapList[mapID]
				else:
					mat.ZTRANS=True
			mesh.matList.append(mat)
			for bone in skeleton.boneList:
				if mesh.boneID==bone.ID:
					if len(mesh.skinList)==1:
						for id in mesh.skinList[0].boneIDMap:
							mesh.skinList[0].boneMap.append(bone.boneMap[id])
					break
		model.getMat()
		model.draw()
		model.setMat()
		for mesh in model.meshList:
			mesh.setBoneMatrix('armature',skeleton.boneList[mesh.boneID].name)
	
	
	
	
def Parser(filename):
	print '='*70
	print filename
	print '='*70
	ext=filename.split('.')[-1].lower()
	
	
	
	if ext=='std':
		file=open(filename,'rb')
		g=BinaryReader(file)
		decParser(filename,g)
		file.close()
	
	if ext=='dec':
		file=open(filename,'rb')
		g=BinaryReader(file)
		decParser(filename,g)
		file.close()
	
	if ext=='cfsi':
		file=open(filename,'rb')
		g=BinaryReader(file)
		cfsiParser(filename,g)
		file.close()
	
	if ext=='anim':
		file=open(filename,'rb')
		g=BinaryReader(file)
		animParser(filename,g)
		file.close()
 
	
Blender.Window.FileSelector(Parser,'import','select files: *.std, *.anim') 
	