#sample class
from inc_noesis import *
import struct

def registerNoesisTypes():
	handle = noesis.register("300 Heroes .x", ".x")
	noesis.setHandlerTypeCheck(handle, X300CheckType)
	noesis.setHandlerLoadModel(handle, X300LoadModel)
	noesis.logPopup()
	return 1

def X300CheckType(data):
	td = NoeBitStream(data)
	magic = b'JUMPX V5.01     WWW.JUMPW.COM   \xb4\xac\xb3\xa4  \xb0\xd1\xba\xda\xb6\xb4\xd7\xb0\xd4\xda\xc6\xbf\xd7\xd3\xc0\xef\xb5\xc4\xc8\xcb!WEIBO.COM/WUYAXIT\x00\x00\x00\x00'
	if td.data[0:80] == magic:
		return 1
	else:
		return 0



class X300File: 
         
	def __init__(self, bs):
		#rapi.rpgSetPosScaleBias(NoeVec3((-1,1,1)),NoeVec3((0,0,0)))
		#rapi.rpgSetOption(noesis.RPGOPT_TRIWINDBACKWARD, 1)
		self.texList   = []
		self.vtxList   = []
		self.matList   = []
		self.boneList  = []
		self.cDict     = {}
		self.loadAll(bs)

	def loadAll(self, bs):
		baseName = rapi.getExtensionlessName(rapi.getLocalFileName(rapi.getLastCheckedName()))
		bs.seek(0x50,NOESEEK_ABS)
		(unk00, tblSize), tblStart = bs.read("2I"), bs.tell()
		#print(unk00, tblSize, tblStart)
		while bs.tell() < (tblSize+ tblStart):
			cMagic, cSize = bs.readBytes(4).decode("ASCII").rstrip("\0"), bs.readUInt()
			cData = bs.read("I" * (cSize // 4))[0]
			self.cDict[cMagic] = cData
			#print(cMagic,self.cDict[cMagic])
		(b0Size,b1Size,b0zSize,b1cSize),zBase = bs.read("4I"), bs.tell()
		#print(b0Size,b1Size,b0zSize,b1cSize,zBase)
		buff0 = rapi.decompInflate(bs.data[zBase:zBase + b0zSize],b0Size)
		buff1 = rapi.decompInflate(bs.data[zBase + b0zSize:zBase + b0zSize + b1cSize],b1Size)
		self.loadModelInfo(NoeBitStream(buff0),NoeBitStream(buff1))
	def loadModelInfo(self, bs, vd):
		sInfo = bs.readString()
		tmp = bs.tell()
		t1 = bs.readString()
		if t1 == '':
			bs.seek(tmp,NOESEEK_ABS)
		info = bs.read("I" * (self.cDict['ntex'] * 2))
		texInfo = []
		for i in range(1,self.cDict['ntex'] * 2,2):
			bs.seek(info[i],NOESEEK_ABS)
			texInfo.append(ReadNString(bs))
			print(texInfo[len(texInfo) - 1])
		matInfo = []
		#print("Mat Info")
		for i in range(0,self.cDict['nmtl']):
			matInfo.append(bs.read("6I4f4BI"))
			#print(matInfo[i],matInfo[i][11])
			mat = NoeMaterial('mat_' + str(i), "")
			mat.setFlags(noesis.NMATFLAG_TWOSIDED)
			mat.setFlags(0, 1) 
			mat.setTexture(texInfo[matInfo[i][3]])
			self.matList.append(mat)
		#print('Problem Spot ' + str(bs.tell()))

		offInfo2 = (bs.read("I" * 11))
		tmp = bs.tell()
		t1,t2 = bs.read("2I")
		bs.seek(tmp,NOESEEK_ABS)
		if t2 != 0x40:
			offInfo1 = (bs.read("I" * self.cDict['nmtl']))
		mInfo = []
		mName = []
		for i in range(0,self.cDict['ngeo']):
			mInfo.append(bs.read("24I6fI"))
			#print(mInfo[i])
		for i in range(0,self.cDict['ngeo']):
			bs.seek(mInfo[i][2],NOESEEK_ABS)
			#print('mInfo Name Off ' + str(bs.tell()))
			mName.append(ReadNString(bs))
		bInfo = []
		bMtx  = []
		bInfo2 = []
		#print('Bone Info Off ' + str(bs.tell()))
		for i in range(0,self.cDict['nbon']):
			bInfo.append(bs.read("3I3i"))
			Matrix = bs.read("16f")
			bMtx.append(NoeMat43( [(Matrix[0],Matrix[4],Matrix[8]), (Matrix[1],Matrix[5],Matrix[9]), (Matrix[2],Matrix[6],Matrix[10]), (Matrix[12],Matrix[13],Matrix[14])] ).inverse() )
			#bMtx.append(NoeMat44.fromBytes(bs.readBytes(64)).toMat43().orthogonalize().inverse())
			bInfo2.append(bs.read("6f15I"))
		for i in range(0,self.cDict['nbon']):
			bs.seek(bInfo[i][2],NOESEEK_ABS)
			boneName = ReadNString(bs) + '_' + str(i)
			#print(boneName)
			self.boneList.append(NoeBone(i, boneName, bMtx[i], None, bInfo[i][3]))
		for i in range(0,self.cDict['ngeo']):
			#print(mInfo[i])
			rapi.rpgSetName(mName[i]  + '_' + str(i))
			rapi.rpgSetMaterial('mat_' + str(mInfo[i][4]))
			vd.seek((mInfo[i][9] - 1000000000),NOESEEK_ABS)
			vertBuff = vd.readBytes(mInfo[i][7] * 12)
			vd.seek((mInfo[i][11] - 1000000000),NOESEEK_ABS)
			normalBuff = vd.readBytes(mInfo[i][7] * 12)
			vd.seek((mInfo[i][13] - 1000000000),NOESEEK_ABS)
			uvBuff = vd.readBytes(mInfo[i][7] * 8)
			vd.seek((mInfo[i][19] - 1000000000),NOESEEK_ABS)
			faceBuff = vd.readBytes(mInfo[i][8] * 6)
			vd.seek((mInfo[i][23] - 1000000000),NOESEEK_ABS)
			#print(vd.tell())
			wghtBuff = vd.readBytes(mInfo[i][7] * 0x18)
			rapi.rpgBindPositionBuffer(vertBuff, noesis.RPGEODATA_FLOAT, 12)
			rapi.rpgBindNormalBuffer(normalBuff, noesis.RPGEODATA_FLOAT, 12)
			rapi.rpgBindUV1Buffer(uvBuff, noesis.RPGEODATA_FLOAT, 8)
			rapi.rpgBindBoneIndexBufferOfs(wghtBuff, noesis.RPGEODATA_UBYTE, 0x18, 1, 4)
			rapi.rpgBindBoneWeightBufferOfs(wghtBuff, noesis.RPGEODATA_FLOAT, 0x18, 8, 4)
			rapi.rpgCommitTriangles(faceBuff, noesis.RPGEODATA_USHORT, (mInfo[i][8] * 3), noesis.RPGEO_TRIANGLE, 1)


classLoaderDict = {

	}

def ReadNString(bs):
	c = -1
	resultString = b''
	while(c != 0):
		c = bs.readBytes(1)
		if c == b'\x00':
			return resultString.decode('latin-1')
		else:
			resultString += c

def dataAlign(pos,pad):
	if (pos % pad) > 0:
		return((pad - (pos) % pad))
	else:
		return(0)	


def X300LoadModel(data, mdlList):
	ctx = rapi.rpgCreateContext()
	X300 = X300File(NoeBitStream(data))
	rapi.setPreviewOption('setAngOfs',"0 -90 0")
	try:
		mdl = rapi.rpgConstructModel()
	except:
		mdl = NoeModel()
	mdl.setModelMaterials(NoeModelMaterials(X300.texList, X300.matList))
	mdlList.append(mdl); mdl.setBones(X300.boneList)	
	return 1

