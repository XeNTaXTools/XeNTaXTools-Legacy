#  ShumenOL boss143.eva importer by Bigchillghost
from inc_noesis import *
import copy

def registerNoesisTypes():
	handle = noesis.register("boss143", ".eva")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadModel(handle, noepyLoadModel)
	#noesis.logPopup()
	return 1

#check if it's this type based on the data
def noepyCheckType(data):
	if len(data) < 0x80:
		return 0
	bs = NoeBitStream(data)
	bs.seek(3, NOESEEK_ABS)
	Tag = noeStrFromBytes(bs.readBytes(8), "ASCII")
	if Tag != 'EV_Actor':
		return 0
	return 1

#load the model
def noepyLoadModel(data, mdlList):
	#noesis.logPopup()
	bs = NoeBitStream(data)
	bs.seek(0xAED, NOESEEK_ABS)
	# bone info
	boneCount = bs.readInt()
	bones = []
	matList = []
	for i in range(0, boneCount):
		NameLen = bs.readInt()
		boneName = noeStrFromBytes(bs.readBytes(NameLen), "ASCII")
		NameLen = bs.readInt()
		parentName = noeStrFromBytes(bs.readBytes(NameLen), "ASCII")
		bs.seek(1, NOESEEK_REL)
		frameCnt = bs.readInt()
		if frameCnt > 0:
			targetFrame = 0 # 0-142
			bs.seek(targetFrame*0x30, NOESEEK_REL)
			boneMat = NoeMat43.fromBytes(bs.readBytes(48))
			bs.seek((frameCnt-targetFrame-1)*0x30, NOESEEK_REL)
			boneMat = boneMat.transpose()
			unkCnt = bs.readInt()
			for j in range(0, unkCnt):
				bs.seek(2, NOESEEK_REL)
				polygonCnt = bs.readInt()
				bs.seek(polygonCnt*6, NOESEEK_REL)
		else:
			boneMat = NoeMat43()
		bs.seek(1, NOESEEK_REL)
		bones.append( NoeBone(i, boneName, boneMat, parentName) )
		matList.append(boneMat)
	
	# meshes
	bs.seek(0x333EB6, NOESEEK_ABS)
	idxCount = bs.readInt()
	idxData = bs.readBytes(idxCount*2)
	bs.seek(0x33679D, NOESEEK_ABS)
	idxCount2 = bs.readInt()
	idxData2 = bs.readBytes(idxCount2*2)
	PolygonIndex1 = rapi.dataToIntList(idxData, idxCount, noesis.RPGEODATA_USHORT, NOE_LITTLEENDIAN)
	PolygonIndex2 = rapi.dataToIntList(idxData2, idxCount2, noesis.RPGEODATA_USHORT, NOE_LITTLEENDIAN)
	bs.seek(0x3388D3, NOESEEK_ABS)
	Vcount = 0x7AE #bs.readInt()
	Positions = []
	Normals = []
	TexCoords = []
	vertWeightList = []
	for i in range(0, Vcount):
		bs.seek(12, NOESEEK_REL) # tangents
		meshCnt = bs.readInt()
		boneID = bs.readUByte()
		bs.seek(4, NOESEEK_REL)
		position = NoeVec3.fromBytes(bs.readBytes(12))
		normal = NoeVec3.fromBytes(bs.readBytes(12))
		bs.seek(1, NOESEEK_REL)
		if meshCnt > 1:
			bs.seek(0x1E, NOESEEK_REL)
		TexCoords.append(NoeVec3([bs.readFloat(), -bs.readFloat(), 0.0]))
		bs.seek(1, NOESEEK_REL)
		position = matList[boneID]*position
		rotMat = copy.copy(matList[boneID])
		rotMat[3] = NoeVec3((0.0, 0.0, 0.0))
		normal = rotMat*normal
		Positions.append(position)
		Normals.append(normal)
		vertWeightList.append(NoeVertWeight([boneID], [1.0]))
	
	meshes = []
	meshName = rapi.getInputName().split("\\")[-1].split(".")[0]
	meshName1 = meshName + "_1"
	mesh1 = NoeMesh(PolygonIndex1, Positions, meshName1, meshName1)
	mesh1.setUVs(TexCoords)
	mesh1.setNormals(Normals)
	mesh1.weights = vertWeightList
	meshes.append(mesh1)
	
	meshName2 = meshName + "_2"
	mesh2 = NoeMesh(PolygonIndex2, Positions, meshName2, meshName2)
	mesh2.setUVs(TexCoords)
	mesh2.setNormals(Normals)
	mesh2.weights = vertWeightList
	meshes.append(mesh2)
	
	mdl = NoeModel(meshes)
	mdl.setBones(bones)
	mdlList.append(mdl)
	rapi.setPreviewOption("setAngOfs", "0 -90 0")
	
	return 1
