# Star Wars: Episode III – Revenge of the Sith (Xbox) mesh importer by Bigchillghost

import rapi
from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Star Wars: Episode III - Revenge of the Sith", ".msh")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadModel(handle, noepyLoadModel)
	#noesis.logPopup()
	return 1

#check if it's this type based on the data
def noepyCheckType(data):
	if len(data) < 0x200:
		return 0
	bs = NoeBitStream(data)
	Magic = bs.readUInt()
	if Magic != 0xF8C203A1:
		return 0
	return 1

def debugPrint(str):
	#print(str)
	pass

#load the model
def noepyLoadModel(data, mdlList):
	#noesis.logPopup()
	bs = NoeBitStream(data)
	bs.seek(4, NOESEEK_ABS)
	flag = bs.readInt()
	bs.seek(4, NOESEEK_REL)
	chunkCnt = bs.readInt()
	groupNum = []
	for i in range(0, chunkCnt):
		Len = bs.readInt()
		bs.seek(Len+4, NOESEEK_REL)
		cnt = bs.readInt()
		for j in range(0, cnt):
			Len = bs.readInt()
			bs.seek(Len, NOESEEK_REL)
		groupNum.append(cnt)
	bs.seek(8, NOESEEK_REL)
	debugPrint("beg at %#x"%bs.tell())
	
	idx = 0
	bones = []
	accBoneIdx = 0
	baseName = rapi.getInputName().split('\\')[-1].split('.')[0]
	ctx = rapi.rpgCreateContext()
	for i in range(0, chunkCnt):
		debugPrint("chunk %d at %#x"%(i,bs.tell()))
		Len = bs.readInt()
		bs.seek(Len+8, NOESEEK_REL)
		cnt = groupNum[i]
		debugPrint("group cnt %d"%cnt)
		result = parseData(bs, bones, idx, accBoneIdx, flag, baseName, cnt, 4)
		idx = result[0]
		accBoneIdx = result[1]
		debugPrint(" ")
	fileSize = bs.getSize()
	if bs.tell() + 8 < fileSize:
		bs.seek(4, NOESEEK_REL)
		debugPrint("read isEndOfMeshes at %#x"%bs.tell())
		isEndOfMeshes = bs.readInt()
		if isEndOfMeshes == 0:
			Skip = 0x10 - bs.tell() % 0x10
			bs.seek(Skip, NOESEEK_REL)
			debugPrint("search from %#x"%bs.tell())
			Test = 0
			while bs.tell() < fileSize and Test == 0:
				Test = bs.readUInt()
			debugPrint("search end %#x"%bs.tell())
			if bs.tell() < fileSize:
				Offset = bs.tell() - 4
				Test = bs.readUInt()
				if Test == 1:
					bs.seek(-8, NOESEEK_REL)
					debugPrint("find pixel at %#x"%Offset)
					while bs.readUInt() > 0:
						bs.seek(0xC, NOESEEK_REL)
						cnt = bs.readUInt()
						bs.seek(cnt*4, NOESEEK_REL)
						cnt = bs.readUInt()
						cnt2 = bs.readUInt()
						bs.seek(cnt+cnt2+8, NOESEEK_REL)
					debugPrint("pixel end at %#x"%bs.tell())
					Skip = bs.tell() - Offset
					Skip = 0x800 - Skip % 0x800
					bs.seek(Skip, NOESEEK_REL)
					debugPrint("new mesh chunk at %#x"%bs.tell())
					parseData(bs, bones, idx, accBoneIdx, flag, baseName)
	mdl = rapi.rpgConstructModelSlim()
	mdl.setBones(bones)
	mdlList.append(mdl)
	return 1
	
#load the model
def parseData(bs, bones, idx, accBoneIdx, flag, baseName, cnt = 1, extraBytes = 0):
	for i in range(0, cnt):
		debugPrint("    group %d at %#x"%(i,bs.tell()))
		bs.seek(0x5C + extraBytes, NOESEEK_REL)
		objectNum = bs.readInt()
		debugPrint("    objectNum %#x"%objectNum)
		for j in range(0, objectNum):
			debugPrint("        obj %d at %#x"%(j,bs.tell()))
			bs.seek(0x4D, NOESEEK_REL)
			bs.seek(0xB*2, NOESEEK_REL)
			debugPrint("        posArr at %#x"%bs.tell())
			posArr = bs.readBytes(0xB)
			attrNum = bs.readUByte()
			stride = bs.readUByte()
			Vcnt = bs.readInt()
			vertData = bs.readBytes(Vcnt*stride)
			bs.seek(4, NOESEEK_REL)
			subMeshNum = bs.readInt()
			debugPrint("        subMeshNum %#x"%subMeshNum)
			debugPrint("        mesh %d - %d"%(idx, idx+subMeshNum))
			refferedBoneNum = [0]*subMeshNum
			IdxCnt = [0]*subMeshNum
			isStrip = [0]*subMeshNum
			subMeshVCnt = [0]*subMeshNum
			idxDataArrays = []
			boneRefArrays = []
			for k in range(0, subMeshNum):
				debugPrint("            mesh %d subMesh %d at %#x"%(idx,k,bs.tell()))
				bs.seek(4, NOESEEK_REL)
				refferedBoneNum[k] = bs.readInt()
				boneRefArray = []
				for m in range(0, refferedBoneNum[k]):
					boneRefArray.append(bs.readShort())
				#debugPrint("            " + str(boneRefArray))
				if len(boneRefArray) > 0:
					debugPrint("            boneRefArray min %#x, max %#x"%(min(boneRefArray),max(boneRefArray)))
					boneRefArrays.append(boneRefArray)
				bs.seek(4, NOESEEK_REL)
				IdxCnt[k] = bs.readInt()
				idxData = bs.readBytes(IdxCnt[k]*2)
				idxDataArrays.append(idxData)
				isStrip[k] = bs.readInt()
				bs.seek(4, NOESEEK_REL)
				subMeshVCnt[k] = bs.readUShort()
				debugPrint("            flag %#x seek at %#x"%(flag,bs.tell()))
				if flag == 0x90019:
					bs.seek(4, NOESEEK_REL)
				elif flag < 0x90012 or flag > 0x90014:
					bs.seek(6, NOESEEK_REL)
				debugPrint(" ")
			
			if Vcnt == 0:
				continue
			if posArr[6] != 0xFF: # weights
				boneIdxList = [0]*(Vcnt*4)
				debugPrint("            len(boneIdxList) %d"%len(boneIdxList))
				if len(boneRefArrays) > 0: # using reference tables
					accVertIdx = 0
					boneIdxPos = posArr[7]
					for k in range(0, subMeshNum):
						numVert = subMeshVCnt[k]
						boneRefArray = boneRefArrays[k]
						debugPrint("            refferedBoneNum %#x"%refferedBoneNum[k])
						debugPrint("            numVert %#x"%numVert)
						for L in range(0, numVert):
							lBonePos = stride*accVertIdx+boneIdxPos
							lDstPos = accVertIdx*4
							for m in range(0,4):
								try:
									boneIdxList[lDstPos+m] = accBoneIdx + boneRefArray[vertData[lBonePos+m]//3]
								except:
									debugPrint("            vertID %#x, boneID %d, src %#x, dst %#x"%(accVertIdx, m, lDstPos+m,lBonePos+m))
									return 0
							accVertIdx += 1
						debugPrint(" ")
				else:
					for k in range(0, Vcnt*4):
						boneIdxList[k] = accBoneIdx
				boneIdxArray = struct.pack("<" + 'H'*len(boneIdxList), *boneIdxList)
			for k in range(0, subMeshNum):
				indexEncoding = noesis.RPGEO_TRIANGLE_STRIP
				if isStrip[k] == 0:
					indexEncoding = noesis.RPGEO_TRIANGLE
				rapi.rpgSetName("%s_mesh%d"%(baseName,idx))
				rapi.rpgBindPositionBuffer(vertData, noesis.RPGEODATA_FLOAT, stride)
				if posArr[1] != 0xFF:
					rapi.rpgBindNormalBufferOfs(vertData, noesis.RPGEODATA_UBYTE, stride, posArr[1])
				if posArr[3] != 0xFF:
					rapi.rpgBindUV1BufferOfs(vertData, noesis.RPGEODATA_FLOAT, stride, posArr[3])
				if posArr[6] != 0xFF: # weights
					rapi.rpgBindBoneIndexBuffer(boneIdxArray, noesis.RPGEODATA_USHORT, 8, 4)
					rapi.rpgBindBoneWeightBufferOfs(vertData, noesis.RPGEODATA_UBYTE, stride, posArr[6], 4)
				
				rapi.rpgSetPosScaleBias(NoeVec3([-1,1,1]), NoeVec3([0,0,0]))
				rapi.rpgCommitTriangles(idxDataArrays[k], noesis.RPGEODATA_USHORT, IdxCnt[k], indexEncoding, 1)
				rapi.rpgClearBufferBinds()
				idx += 1
		debugPrint("    mat at %#x"%bs.tell())
		for j in range(0, 2):
			debugPrint("        strBlock %d at %#x"%(j,bs.tell()))
			bs.seek(8, NOESEEK_REL)
			StrBufLen = bs.readInt()
			bs.seek(4, NOESEEK_REL)
			StrCnt = bs.readInt()
			bs.seek(StrCnt*4+StrBufLen, NOESEEK_REL)
		bs.seek(0xC, NOESEEK_REL)
		matNum = bs.readInt()
		bs.seek(matNum*0x38+0x20, NOESEEK_REL)
		debugPrint(" ")
	bs.seek(8, NOESEEK_REL)
	debugPrint("boneCnt at %#x"%bs.tell())
	boneCnt = bs.readInt()
	debugPrint("boneCnt %#x"%boneCnt)
	for i in range(0, boneCnt):
		pos = bs.tell() + 0x20
		boneName = bs.readString() + "_%d"%(accBoneIdx+i)
		bs.seek(pos, NOESEEK_ABS)
		boneMat = NoeMat43.fromBytes(bs.readBytes(48)).transpose().inverse()
		boneMat = boneMat.swapHandedness(0) # convert to right-handed matrix
		bonePIndex = bs.readShort()
		if bonePIndex != -1:
			bonePIndex += accBoneIdx
		bones.append(NoeBone(accBoneIdx + i, boneName, boneMat, None, bonePIndex))
	accBoneIdx += boneCnt
	bs.seek(0x68, NOESEEK_REL)
	debugPrint("   chunk end at %#x"%bs.tell())
	return [idx, accBoneIdx]