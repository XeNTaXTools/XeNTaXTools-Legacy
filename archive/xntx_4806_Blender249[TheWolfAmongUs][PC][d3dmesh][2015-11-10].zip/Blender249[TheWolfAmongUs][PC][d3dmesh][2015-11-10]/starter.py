import newGameLib
from newGameLib import *
import Blender	

def section14(filename,v,g):
	g.debug=False
	sum=0
	for m in range(v[1]):
		mat=Mat()
		mat.TRIANGLE=True
		t=g.tell()
		g.i(8)
		g.f(6)
		g.i(2)
		g.f(3)
		g.i(14)
		IDCount=g.i(1)[0]
		mat.IDStart=sum
		mat.IDCount=IDCount
		#print mat.IDStart,IDCount
		sum+=IDCount
		g.f(24)
		g.i(11)
		g.seek(t+276)
		matList.append(mat)
		
	#g.debug=False
	g.tell()


class Vert:
	def __init__(self):
		self.posOffset=None
		self.uvOffset=None
		self.weightOffset=None
		self.indiceOffset=None






def d3dmesh_parser(filename,g):
	global matList
	matList=[]
	#g.debug=True
	g.i(1)
	g.word(g.i(1)[0])
	count=g.i(1)[0]
	print '#'*30
	g.H(2)
	g.f(3)
	g.f(3)
	g.i(1)
	g.f(4)
	
		
	t=g.tell()
	v=g.i(2)
	section14(filename,v,g)
	g.seek(t+v[0])
	
	t=g.tell()
	v=g.i(2)
	g.seek(t+v[0])
	
	t=g.tell()
	v=g.i(2)
	g.seek(t+v[0])
	
	t=g.tell()
	v=g.i(2)
	g.seek(t+v[0])
	
	t=g.tell()
	v=g.i(2)
	g.seek(t+v[0])
	g.i(4)
	
	t=g.tell()
	v=g.i(2)
	g.seek(t+v[0])
	
	g.f(8)
	
	v=g.i(4)
	g.B(1)
	v=g.i(4)
	t=g.tell()
	#g.seek(t+v[1]*2)
	g.debug=False
	indices=g.H(v[1])	
	#g.debug=True
	v=g.i(6)
	vert=Vert()	
	for m in range(12):
		w=g.i(3)
		print w
		if m==0:
			vert.posOffset=w[0]
		if m==1:
			vert.uvOffset=w[0]
		if m==3:
			vert.weightOffset=w[0]
		if m==4:
			vert.indiceOffset=w[0]
	g.debug=False
	mesh=Mesh()
	#mesh.name=str(model_id)+'-model'
	mesh.TRIANGLE=True
	skin=Skin()	
	for m in range(v[0]):	
		t=g.tell()
		g.seek(t+vert.posOffset)
		mesh.vertPosList.append(g.f(3))
		g.seek(t+vert.weightOffset)
		mesh.skinWeightList.append(g.f(3))
		g.seek(t+vert.indiceOffset)
		mesh.skinIndiceList.append(g.B(3))
		g.seek(t+vert.uvOffset)
		mesh.vertUVList.append(g.short(2,'H',15))
		g.seek(t+v[1])
	#mesh.skinList.append(skin)	
	mesh.indiceList=indices	
	mesh.matList=matList
	mesh.SPLIT=True
	mesh.draw()	
	g.debug=True
	g.tell()
	
	
									
	
def d3dtx_parser(filename,g):
	g.debug=True
	g.seek(154)
	count=g.i(1)[0]
	g.seek(92)
	v=g.i(6)
	g.seek(116)
	g.word(g.i(1)[0])
	g.seek(89,1)
	size=g.i(1)[0]
	
	if v[5]==35:
		sum=g.tell()
		for m in range(12):
			print m,sum
			w=g.i(4)
			t=g.tell()
			if w[0]==0:
				img=Image()
				img.format='tga'
				img.wys=w[3]/2
				img.szer=w[3]/2
				#img.name=filename+'-'+str(m)+'.dds'
				img.name=filename+'.tga'
				g.seek(sum)
				img.data=g.read(w[2])
				img.draw()
				
			sum+=w[2]
			g.seek(t)
	
	elif v[5]==29:
	
		sum=g.tell()
		for m in range(count):
			print m,sum
			w=g.i(4)
			t=g.tell()
			if w[0]==0:
				img=Image()
				img.format='DXT1'
				img.wys=w[3]/2
				img.szer=w[3]/2
				#img.name=filename+'-'+str(m)+'.dds'
				img.name=filename+'.dds'
				g.seek(sum)
				img.data=g.read(w[2])
				img.draw()
				
			sum+=w[2]	
			g.seek(t)
	
	elif v[5]==39:
	
		sum=g.tell()
		for m in range(8):
			print m,sum
			w=g.i(4)
			t=g.tell()
			if w[0]==0:
				img=Image()
				img.format='DXT1'
				img.wys=w[3]/4
				img.szer=w[3]/4
				#img.name=filename+'-'+str(m)+'.dds'
				img.name=filename+'.dds'
				g.seek(sum)
				img.data=g.read(w[2])
				img.draw()
				
			sum+=w[2]	
			g.seek(t)
	
	elif v[5]==30:
	
		sum=g.tell()
		for m in range(9):
			print m,sum
			w=g.i(4)
			t=g.tell()
			if w[0]==0:
				img=Image()
				img.format='DXT1'
				img.wys=w[3]/2
				img.szer=w[3]/2
				#img.name=filename+'-'+str(m)+'.dds'
				img.name=filename+'.dds'
				g.seek(sum)
				img.data=g.read(w[2])
				img.draw()
				print filename
				
			sum+=w[2]	
			g.seek(t)
	else:
		print 'WARNING: unknow image type',v[5]		
	
	
	g.tell()	
			
def Parser(filename):
	global skeleton,used_bones
	skeleton=None
	used_bones=None
	#filename=input.filename
	
	ext=filename.split('.')[-1].lower()
	
	if ext=='d3dmesh':
		file=open(filename,'rb')
		g=BinaryReader(file)
		d3dmesh_parser(filename,g)
		file.close()
	
	if ext=='d3dtx':
		file=open(filename,'rb')
		g=BinaryReader(file)
		d3dtx_parser(filename,g)
		file.close()
	
	
Blender.Window.FileSelector(Parser,'import','The Wolf Among Us files: *.d3dmesh - model,*.d3dtx - texture') 
	