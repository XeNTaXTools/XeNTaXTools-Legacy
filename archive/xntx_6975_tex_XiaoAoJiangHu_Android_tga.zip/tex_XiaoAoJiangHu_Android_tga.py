from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Xiao_Ao_Jiang_Hu [Android]", ".tga")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    if bs.readBytes(4) != b'\x45\x52\x41\x00': return 0
    return 1
    
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.seek(0x4)
    imgWidth = bs.readUInt()
    imgHeight = bs.readUInt()
    imgDepth = bs.readUInt()
    unk = bs.readUInt()
    unk2 = bs.readUInt()
    unk3 = bs.readUInt()
    mips = bs.readUInt()
    bs.seek(0xa8)
    data = bs.readBytes(bs.getSize() - bs.tell())
    data = rapi.callExtensionMethod("astc_decoderaw32", data, 6, 6, 1, imgWidth, imgHeight, imgDepth)
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, noesis.NOESISTEX_RGBA32))
    return 1

