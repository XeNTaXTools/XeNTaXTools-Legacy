# Bully: Anniversary Edition
# Noesis script by Dave, 2022


from inc_noesis import *


def registerNoesisTypes():
	handle = noesis.register("Bully: Anniversary Edition",".msh")
	noesis.setHandlerTypeCheck(handle, bcCheckType)
	noesis.setHandlerLoadModel(handle, bcLoadModel)
	return 1


# Check file type

def bcCheckType(data):
	return 1


# Read the model data

def bcLoadModel(data, mdlList):
	bs = NoeBitStream(data)
	ctx = rapi.rpgCreateContext()

	bs.seek(0x14)
	mesh_data = bs.readUInt()
	bs.seek(mesh_data)
	mesh_count = bs.readUInt()						# number of main meshes
	mesh_offset = bs.tell()						# start of first mesh


# Draw a mesh - need a loop here to draw other meshes, if there are any.

	DrawMesh(bs, mesh_offset)


	try:
		mdl = rapi.rpgConstructModel()
	except:
		mdl = NoeModel()

	mdlList.append(mdl)

	return 1


# Draw all submeshes for one complete mesh

def DrawMesh(bs, offset):
	print("Drawing mesh")
	bs.seek(offset)
	text_len = bs.readUInt()
	mesh_name = bs.readBytes(text_len).decode("ascii")

	bs.readUShort()
	vert_count = bs.readUInt()

	while vert_count == 0:						# sometimes some blank bytes before vert_count info
		vert_count = bs.readUInt()

	face_total = bs.readUInt()
	face_data = bs.tell()
	vert_info = face_data + (face_total * 2)

	bs.seek(vert_info)
	vertex_parts = bs.readUInt()						# number of parts in each vertex entry - need to calculate properly
	vert_data = vert_info + (vertex_parts * 0x0a) + 4
	bs.seek(vert_data)
	vertices = bs.readBytes(vert_count * 0x1c)				# not always 0x1c, calculate from vertex parts above
	submesh_count = bs.readUInt()
	submesh_info = bs.tell()

	rapi.rpgBindPositionBuffer(vertices, noesis.RPGEODATA_FLOAT, 0x1c)

# Read the face data for each submesh

	for a in range(submesh_count):
		bs.seek(submesh_info + (a * 0x10))
		start_face = bs.readUInt()
		face_count = bs.readUInt()
		material_num = bs.readUInt()					# material index from table at start of file
		unk1 = bs.readUInt()

		bs.seek(face_data + (start_face * 2))				# start of face data for submesh
		faces = bs.readBytes(face_count * 2)

		rapi.rpgSetName(mesh_name + "_" + str(a))			# split each submesh with a unique name
		rapi.rpgSetMaterial("Material_" + str(material_num))
		rapi.rpgCommitTriangles(faces, noesis.RPGEODATA_USHORT, face_count, noesis.RPGEO_TRIANGLE)

	return 1

