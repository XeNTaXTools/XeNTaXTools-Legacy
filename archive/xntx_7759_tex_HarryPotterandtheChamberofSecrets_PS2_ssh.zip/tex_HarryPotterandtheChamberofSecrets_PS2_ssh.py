from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Harry Potter and the Chamber of Secrets [PS2]", ".ssh")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    if noeStrFromBytes(bs.readBytes(4)) != "SHPS": return 0
    return 1

def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    magic = noeStrFromBytes(bs.readBytes(4))
    sshsize = bs.readUInt()
    files = bs.readUInt()
    G359 = noeStrFromBytes(bs.readBytes(4))
    tmp = bs.tell()
    for i in range(files):
        bs.seek(tmp)
        bs.readBytes(4)
        imgOffset = bs.readUInt()
        tmp = bs.tell()
        bs.seek(imgOffset)
        format = bs.readByte() 
        datasize = int.from_bytes(bs.readBytes(3), byteorder = 'little')
        imgWidth = bs.readUShort()
        imgHeight = bs.readUShort()
        print(imgWidth, "x", imgHeight)
        bs.readUInt()
        bs.readUInt()
        tmp2 = bs.tell()
        data = bs.readBytes(datasize - 0x10)
        data = rapi.imageUntwiddlePS2(data, imgWidth, imgHeight, 8)
        paletteType = bs.readByte() #??
        paletteSize = int.from_bytes(bs.readBytes(3), byteorder = 'little')
        colors = bs.readUShort()
        bs.readShort()
        bs.readShort()
        bs.readShort()
        bs.readByte()
        bs.readByte()
        bs.readByte()
        bs.readByte()
        palette = bs.readBytes(paletteSize - 0x10)
        if colors < 256:            
            data = rapi.imageDecodeRawPal(data, palette, imgWidth, imgHeight, 8, "r8 g8 b8 a8")
        elif colors == 256:
            data = rapi.imageDecodeRawPal(data, palette, imgWidth, imgHeight, 8, "r8 g8 b8 p8", noesis.DECODEFLAG_PS2SHIFT)
        texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, noesis.NOESISTEX_RGBA32))
        return 1