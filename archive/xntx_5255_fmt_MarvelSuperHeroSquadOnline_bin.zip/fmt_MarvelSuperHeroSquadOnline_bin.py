from inc_noesis import *
import noesis
import rapi

def registerNoesisTypes():
   handle = noesis.register("Marvel Super Hero Squad Online", ".bin")
   noesis.setHandlerTypeCheck(handle, noeCheckGeneric)
   noesis.setHandlerLoadModel(handle, noepyLoadModel)
   return 1

def noepyLoadModel(data, mdlList):
	ctx = rapi.rpgCreateContext()
	rapi.setPreviewOption("setAngOfs","0 -90 0")      #set the default preview angle        
	bs = NoeBitStream(data)
	bs.seek(0x0, NOESEEK_ABS)
	meshNamelength = bs.readInt()
	meshName = bs.readBytes(meshNamelength).decode("ASCII")
	rapi.rpgSetName(meshName)
	bs.seek(0x84, NOESEEK_ABS)
	FCount = bs.readInt()                                #face indices count
	IBuf = bs.readBytes(FCount)                                   #divide length by 2 for word indices 
	FCount = int(FCount / 2)
	VCount = bs.readInt()
	VBuf = bs.readBytes(VCount * 12)
	rapi.rpgBindPositionBufferOfs(VBuf, noesis.RPGEODATA_FLOAT, 12, 0)     #position of vertices
	unkCount = bs.readInt()
	unkBuf = bs.readBytes(unkCount * 32)
	unkCount2 = bs.readInt()
	unk2Buf = bs.readBytes(unkCount2 * 64)
	UVCount = bs.readInt()
	UVBuf = bs.readBytes(VCount * 8)
	rapi.rpgBindUV1BufferOfs(UVBuf, noesis.RPGEODATA_FLOAT, 8, 0)           #UVs
	rapi.rpgCommitTriangles(IBuf, noesis.RPGEODATA_SHORT, FCount, noesis.RPGEO_TRIANGLE_STRIP, 1) #SHORT for word 
	mdl = rapi.rpgConstructModel()                                                                
	mdlList.append(mdl)
	rapi.rpgClearBufferBinds()
	return 1