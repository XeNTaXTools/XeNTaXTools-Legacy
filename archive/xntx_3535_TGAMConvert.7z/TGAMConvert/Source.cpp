#include <Windows.h>
#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>


inline UINT32 NextPow2(UINT32 v){
	v--;
	v |= v >> 1;
	v |= v >> 2;
	v |= v >> 4;
	v |= v >> 8;
	v |= v >> 16;
	return ++v;
}

template<typename T> bool fread_t(T&obj, FILE*f){
	return fread(&obj, 1, sizeof(T), f) == sizeof(T);
}
template<typename T> bool fwrite_t(T&obj, FILE*f){
	return fwrite(&obj, 1, sizeof(T), f) == sizeof(T);
}


#define SIG_A	'TGAM'
#define SIG_B	'TGAm'

#pragma pack(push, 1)

typedef struct {
	char	IDLength; //0
	char	ColorMapType; //1
	char	DataTypecode; //2
	short	ColorMapOrigin; //3
	short	ColorMapLength; //5
	char	ColorMapDepth; //7
	short	XOrigin; //8
	short	YOrigin; //A
	short	Width; //C
	short	Height; //E
	char	BitsPerPixel; //10
	char	Flags; //11
} TGAHeader;

#pragma pack(pop)

void GenerateTGAHeader(TGAHeader *pHdr, UINT16 width, UINT16 height){
	memset(pHdr, 0, sizeof(TGAHeader));
	pHdr->DataTypecode = 2;
	pHdr->Width = width;
	pHdr->Height = height;
	pHdr->BitsPerPixel = 32;
	pHdr->Flags |= 8;
}

void GenerateGreyscaleTGAHeader(TGAHeader *pHdr, UINT16 width, UINT16 height){
	memset(pHdr, 0, sizeof(TGAHeader));
	pHdr->DataTypecode = 3;
	pHdr->Width = width;
	pHdr->Height = height;
	pHdr->BitsPerPixel = 8;
}

struct STGABGRAPixel {
	UINT8	B;
	UINT8	G;
	UINT8	R;
	UINT8	A;
};

struct SRGBAPixel {
	UINT8	R;
	UINT8	G;
	UINT8	B;
	UINT8	A;
	SRGBAPixel &operator=(STGABGRAPixel &b){
		R = b.R;
		G = b.G;
		B = b.B;
		A = b.A;
		return *this;
	}
};


class CTGA{
protected:
	UINT16	m_Width;
	UINT16	m_Height;
	PUINT8	m_pData;
	bool	m_Invert;
public:
	CTGA() : m_pData(NULL){
	}
	~CTGA(){
		if (m_pData)
			free(m_pData);
	}
	bool Load(const char* pPath){
		FILE* f;
		TGAHeader hdr;
		if (fopen_s(&f, pPath, "rb") != 0)
			return false;
		if (!fread_t(hdr, f))
			return fclose(f), false;
		if (hdr.BitsPerPixel != 32 || hdr.DataTypecode != 2 || hdr.ColorMapLength != 0)
			return false;
		if (hdr.IDLength)
			fseek(f, hdr.IDLength, SEEK_CUR);
		m_Width = hdr.Width;
		m_Height = hdr.Height;
		if (m_pData)
			free(m_pData);
		m_pData = (PUINT8)malloc(m_Width*m_Height*4);
		if (!m_pData)
			return fclose(f), false;
		if (fread(m_pData, 1, m_Width*m_Height*4, f) != m_Width*m_Height*4)
			return fclose(f), false;
		
		fclose(f);
		m_Invert = (hdr.Flags & 0x20) == 0;
		return true;
	}
	PUINT8 GetRow(UINT32 r){
		if (m_Invert)
			return m_pData+(m_Height-r-1)*m_Width*4;
		else
			return m_pData+r*m_Width*4;
	}
	PUINT8 GetRowI(UINT32 r){
		if (!m_Invert)
			return m_pData+(m_Height-r-1)*m_Width*4;
		else
			return m_pData+r*m_Width*4;
	}
	inline UINT16 Width(){ return m_Width; };
	inline UINT16 Height(){ return m_Height; };
};

class CSampler {
protected:
	PUINT8	m_pData;
	UINT16	m_Width;
	UINT16	m_Height;
	UINT32	m_BitsPerRow;
	UINT32	m_RowsPerBit;
public:
	CSampler(PUINT8 pData, UINT16 w, UINT16 h, UINT8 rpb) : m_pData(pData), m_Width(w), m_Height(h), m_RowsPerBit(rpb){
		m_BitsPerRow = (UINT32)ceil((double)w/(double)rpb);
	}
	UINT8 Get(UINT32 x, UINT32 y){
		UINT32 idx;
		UINT8 b;
		//y = m_Height-y;
		idx = y/m_RowsPerBit*m_BitsPerRow+x/m_RowsPerBit;
		b = m_pData[idx >> 3];
		return (b >> (7-(idx & 7))) & 1;
	}
	void Set(UINT32 x, UINT32 y, bool v){
		UINT32 idx;
		UINT8 b;
		//y = m_Height-y;
		idx = y/m_RowsPerBit*m_BitsPerRow+x/m_RowsPerBit;
		if (v)
			m_pData[idx >> 3] |= (UINT8)(1 << (7-(idx & 7)));
		else
			m_pData[idx >> 3] &= ~(UINT8)(1 << (7-(idx & 7)));
	}
};

template<int l> inline PUINT8 TGARowI(PUINT8 pData, UINT32 w, UINT32 h, UINT32 r){
	return pData+(h-r-1)*w*l;
}

template<int l> inline PUINT8 TGARow(PUINT8 pData, UINT32 w, UINT32 h, UINT32 r){
	return pData+r*w*l;
}

void DumpOtherData(PUINT8 pOtherData, UINT16 w, UINT16 h, UINT8 rpb, const char* pPath){
	PUINT8 pImageData, pRow;
	FILE* f;
	UINT32 x, y;
	TGAHeader hdr;
	char lBuf[1024];
	CSampler s(pOtherData, w, h, rpb);
	pImageData = (PUINT8)malloc(w*h);
	for (y = 0; y < h; y++){
		pRow = TGARow<1>(pImageData, w, h, y);
		for (x = 0; x < w; x++){
			pRow[x] = s.Get(x, y)*255;
			if (pRow[x] != 0)
				printf("%u %u\n", x, y);
			//pRow[x] = (y & 1) * 255;
		}
	}
	sprintf_s(lBuf, "%s.od.tga", pPath);
	GenerateGreyscaleTGAHeader(&hdr, w, h);
	if (fopen_s(&f, lBuf, "wb") == 0){
		fwrite_t(hdr, f);
		fwrite(pImageData, 1, w*h, f);
		fclose(f);
	}
	free(pImageData);	
}

inline void TGASwitchChannels(PUINT8 pPixel){
	UINT8 r;
	r = pPixel[0];
	pPixel[0] = pPixel[2];
	pPixel[2] = r;
}

UINT32 CalcOtherSize(UINT32 w, UINT32 h, UINT8 rpb){
	UINT32 bpr = (UINT32)ceil((double)w/(double)rpb);
	return (((h-1)/rpb*bpr+(w-1)/rpb)+7)/8+1;
}

void GenerateTGAM(const char* pTGAPath, const char* pOutPath, UINT8 rpb, UINT8 aref){
	CTGA tga;
	FILE* f;
	//-
	PUINT8 pImageData;
	UINT32 imagesize;
	PUINT8 pOtherData;
	UINT32 othersize;
	UINT32 sig;
	UINT16 width;
	UINT16 height;

	//!-
	PUINT8 pRow, pDest;

	UINT32 w, h, x, y, x2, y2, wp, hp;
	UINT8 ma;


	if (!tga.Load(pTGAPath))
		return;

	if (fopen_s(&f, pOutPath, "wb") != 0)
		return;

	sig = rpb == 1 ? SIG_A : SIG_B;

	width = tga.Width();
	height = tga.Height();
	w = NextPow2(width);
	h = NextPow2(height);

	imagesize = w*h*4;

	othersize = CalcOtherSize(width, height, rpb);
	pImageData = (PUINT8)malloc(imagesize);
	pOtherData = (PUINT8)malloc(othersize);

	if (!fwrite_t(sig, f) || !fwrite_t(width, f) || !fwrite_t(height, f) || !fwrite_t(imagesize, f) || !fwrite_t(othersize, f))
		return fclose(f), free(pImageData), free(pOtherData);
	if (rpb != 1){
		if (!fwrite_t(rpb, f))
			return fclose(f), free(pImageData), free(pOtherData);
	}
	memset(pImageData, 0, imagesize);
	memset(pOtherData, 0, othersize);

	
	for (y = 0; y < height; y++){
		pRow = tga.GetRow(y);
		pDest = pImageData+y*w*4;
		memcpy(pDest, pRow, width*4);
		for (x = 0; x < width; x++, pDest += 4){
			TGASwitchChannels(pDest);
		}
	}

	CSampler s(pOtherData, width, height, rpb);

	//s.Set(15, 15, 1);
	//y= s.Get(15, 15);

	for (y = 0; y < height; y += rpb){
		hp = min(height-y, 3);
		for (x = 0; x < width; x += rpb){
			wp = min(width-x, 3);			
			ma = 0;
			for (y2 = y; y2 < y+hp; y2++){
				pRow = tga.GetRowI(y2)+x*4;
				for (x2 = x; x2 < x+wp; x2++, pRow+=4){
					ma = max(ma, pRow[3]);
				}
			}
			if (ma >= aref)
				s.Set(x, y, true);
		}
	}

	if (fwrite(pImageData, 1, imagesize, f) != imagesize)
		return fclose(f), free(pImageData), free(pOtherData);

	if (fwrite(pOtherData, 1, othersize, f) != othersize)
		return fclose(f), free(pImageData), free(pOtherData);

	fclose(f), free(pImageData), free(pOtherData);
}


#define DPRINT	

void MakeTGAM(char**argv, int argc){
	const char* pPath, *pPathOut = NULL;
	UINT32 aref = 32;
	UINT32 rpb = 3;
	int i;
	char lBuf[MAX_PATH];
	if (argc < 1){
		DPRINT("argc < 1\n");
		return;
	}
	pPath = argv[0];

	for (i = 1; i < argc; i++){
		if (_stricmp(argv[i], "-aref") == 0){
			if (++i == argc)
				return;
			aref = (UINT32)atof(argv[i]);
			if (aref > 255)
				return;
		}
		if (_stricmp(argv[i], "-out") == 0){
			if (++i == argc)
				return;
			pPathOut = argv[i];
		}
		if (_stricmp(argv[i], "-rpb") == 0){
			if (++i == argc)
				return;
			rpb = (UINT32)atof(argv[i]);
			if (rpb < 1 || rpb > 255)
				return;
		}
	}
	if (!pPathOut){
		sprintf_s(lBuf, "%s.tgam", pPath);
		pPathOut = lBuf;
	}
	GenerateTGAM(pPath, pPathOut, (UINT8)rpb, (UINT8)aref);
}

void DumpTGAM(char**argv, int argc){
	//TGAM data
	UINT32 sig;
	UINT16 width;
	UINT16 height;
	UINT32 imagesize;
	UINT32 othersize;
	UINT8 frames; //?, optional
	PUINT8 pImageData;
	PUINT8 pOtherData;
	//!TGAM data
	FILE* f;
	PUINT8 pOutData, pRow;
	UINT32 w, h, yscan, xscan;
	TGAHeader hdr;
	pImageData = pOtherData = pOutData = NULL;
	
	const char* pPath, *pPathOut = NULL;
	UINT32 aref = 32;
	UINT32 rpb = 3;
	int i;
	char lBuf[MAX_PATH];
	if (argc < 1)
		return;
	pPath = argv[0];

	for (i = 1; i < argc; i++){
		if (_stricmp(argv[i], "-out") == 0){
			if (++i == argc){
				DPRINT("-out no arg\n");
				return;
			}
			pPathOut = argv[i];
		}
	}
	if (!pPathOut){
		sprintf_s(lBuf, "%s.tga", pPath);
		pPathOut = lBuf;
	}

	//sprintf_s(lBuf, "%s.tga", argv[1]);

	if (fopen_s(&f, pPath, "rb") == 0){
		if (!fread_t(sig, f))
			goto __failread;
		if (!fread_t(width, f))
			goto __failread;
		if (!fread_t(height, f))
			goto __failread;
		if (!fread_t(imagesize, f))
			goto __failread;
		if (!fread_t(othersize, f))
			goto __failread;
		if (sig == SIG_A)
			frames = 1;
		else if (sig != SIG_B || !fread_t(frames, f))
			goto __failread;
		pImageData = (PUINT8)malloc(imagesize);
		pOtherData = (PUINT8)malloc(othersize);
		pOutData = (PUINT8)malloc(width*height*4);
		if (fread(pImageData, 1, imagesize, f) != imagesize)
			goto __failread;
		if (fread(pOtherData, 1, othersize, f) != othersize)
			goto __failread;
		fclose(f);
			

		w = NextPow2(width);
		h = NextPow2(height);

		for (yscan = 0; yscan < height; yscan++){
			memcpy(pRow = (pOutData+((height-yscan-1)*width*4)), pImageData+yscan*w*4, width*4);
			for (xscan = 0; xscan < width; xscan++, pRow+=4){
				TGASwitchChannels(pRow);
			}
		}

		GenerateTGAHeader(&hdr, width, height);
		if (fopen_s(&f, pPathOut, "wb") == 0){
			fwrite_t(hdr, f);
			fwrite(pOutData, 1, width*height*4, f);
			//DumpOtherData(pOtherData, width, height, frames, argv[1]);
		} else
			f = NULL;

__failread:
		if (f)
			fclose(f);
	}
	if (pImageData)
		free(pImageData);
	if (pOtherData)
		free(pOtherData);
	if (pOutData)
		free(pOutData);
}

int main(int argc, char**argv, char**env){
	if (argc < 2){
		printf("TGAMConvert.exe <-tga|-tgam>\n");
		printf("-tga: convert tga to tgam, options:\n\t[-aref <alpha ref, 0-255>] [-out <output path>] [-rpb <rows per bit, 1-255>].\n\n");
		printf("-tgam: convert tgam to tga, options:\n\t[-out <output path>].\n\n");
		return 0;
	}

	if (_stricmp(argv[1], "-tga") == 0)
		MakeTGAM(argv+2, argc-2);
	else if (_stricmp(argv[1], "-tgam") == 0)
		DumpTGAM(argv+2, argc-2);

	return 0;
}