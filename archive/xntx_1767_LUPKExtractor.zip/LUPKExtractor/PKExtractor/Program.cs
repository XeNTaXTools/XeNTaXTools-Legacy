﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Management;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security;
using System.Security.Permissions;
using System.Text;
using Microsoft.Win32;

namespace System.Runtime.CompilerServices
{
    [AttributeUsage(AttributeTargets.Method)]
    public class ExtensionAttribute : Attribute
    { }
}

namespace PKExtractor
{
    public static class Extensions
    {
        public static T[] Merge<T>(this T[] first, T[] second)
        {
            if (second == null || second.Length == 0)
                return first;

            T[] combined = new T[first.Length + second.Length];

            first.CopyTo(combined, 0);
            second.CopyTo(combined, first.Length);

            return combined;
        }
    }

    struct PackageContentInfo
    {
        public int DataSize;
        public string HashID;
        public int DataOffset;
    }

    enum Overwrite
    {
        None= 0,
        All,
        DifferentSize,
        DifferentContents
    }

    class Program
    {
        [DllImport("user32.dll")]
        static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

        [DllImport("user32.dll")]
        static extern bool FlashWindow(IntPtr hWnd, bool bInvert);

        [DllImport("kernel32.dll")]
        public static extern int DeviceIoControl(
            IntPtr hDevice,
            int dwIoControlCode,
            ref short lpInBuffer,
            int nInBufferSize,
            IntPtr lpOutBuffer,
            int nOutBufferSize,
            ref int lpBytesReturned,
            IntPtr lpOverlapped);

        private const int FSCTL_SET_COMPRESSION = 0x9C040;
        private const short COMPRESSION_FORMAT_DEFAULT = 1;


        private static Overwrite g_fileReplaceDemand = Overwrite.None;

        private static bool removeClientRes = false;
        private static bool overwriteAll = false;
        private static int bytesWritten = 0;


        //------------------------------------------------------------------------------------------------------------------------

        static void Main(string[] args)
        {
			Console.Title = "PKExtractor";
		
            WriteLine("LEGO Universe PK Archive Extractor 1.0 (for Windows)", ConsoleColor.Cyan);
            WriteLine("Copyright (C) 2010 by Thomas J. Hatfield\n");
            
            if (args.Length == 0)
                PromptForInputPath();
            else
            {
                WriteLine(args[0] + "\n");

                if (!Directory.Exists(args[0]))
                    WriteLine("The specified path does not exist.", ConsoleColor.Yellow);
                else
                    ImportHashTables(args[0]);
            }

			IntPtr hwnd = FindWindow(null, Console.Title);

			FlashWindow(hwnd, false);
			
            WriteLine("\n" + new string('_', 40), ConsoleColor.White);
            WriteLine("Press any key to quit.", ConsoleColor.White);

            Console.ReadKey();
        } // Main

        //------------------------------------------------------------------------------------------------------------------------

        private static void PromptForInputPath()
        {
            string basePath = String.Empty;

            while (true)
            {
                WriteLine("Please enter the LEGO Universe application directory or 'exit' to quit.");
                WriteLine("(Leave blank to use the default installation path.)");
                Write("> ");

                basePath = Console.ReadLine();

                if (String.Equals(basePath, "exit", StringComparison.OrdinalIgnoreCase))
                    return;

                if (String.IsNullOrEmpty(basePath))
                {
                    if (((string)Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Control\Session Manager\Environment").GetValue("PROCESSOR_ARCHITECTURE", "x86")).Contains("64"))
                        basePath = @"C:\Program Files (x86)";
                    else
                        basePath = @"C:\Program Files";

                    basePath += @"\LEGO Software\LEGO Universe";
                }

                if (!Directory.Exists(basePath))
                {
                    WriteLine("\nThe specified path does not exist.");
                }
                else
                    break;
            }

            ImportHashTables(basePath);

        } // PromptForInputPath

        //------------------------------------------------------------------------------------------------------------------------

        private static void ImportHashTables(string appPath)
        {
            WriteLine("\nImporting hash tables...\n");

            string hashPath = appPath + @"\versions";

            if (!Directory.Exists(hashPath))
            {
                WriteLine("Invalid path structure. Could not find hash tables.", ConsoleColor.Red);
                return;
            }

            string[] hashTables = Directory.GetFiles(hashPath, "*.txt", SearchOption.TopDirectoryOnly);

            if (hashTables.Length == 0)
            {
                WriteLine("Could not locate any hash tables.", ConsoleColor.Yellow);
                return;
            }

            
            Dictionary<string, string> hashRecords = new Dictionary<string, string>();

            for (int i = 0; i < hashTables.Length; i++)
            {
                string table = hashTables[i];

                FileStream fs = new FileStream(table, FileMode.Open, FileAccess.Read, FileShare.Read);

                if (fs == null)
                {
                    WriteLine("Could not open " + Path.GetFileName(table) + ".", ConsoleColor.Red);
                    continue;
                }

                StreamReader reader = new StreamReader(fs);

                Write("  " + Path.GetFileName(table) + "... ");

                // First, locate [files] section.

                while (!reader.EndOfStream)
                {
                    string entry = reader.ReadLine();

                    if (String.Equals(entry, "[files]", StringComparison.OrdinalIgnoreCase))
                        break;
                }

                int count = 0;

                while (!reader.EndOfStream)
                {
                    string entry = reader.ReadLine();

                    string[] elements = entry.Split(',');

                    if (elements.Length < 3)
                        continue;

                    // elements[0] = filename
                    // elements[1] = data length
                    // elements[2] = hash id

                    hashRecords[elements[2]] = elements[0].Replace('/', '\\');
                    // This overwrites duplicate hash records.

                    count++;
                }

                reader.Close();
                fs.Dispose();

                WriteLine(count.ToString() + " records.");
            }

            WriteLine("\nFound a total of " + hashRecords.Count.ToString("#,##0") + " hash records.\n");

            Write("Do you want to view these records? (y/N) ");

            ConsoleKeyInfo showRecords = Console.ReadKey();

            switch (showRecords.Key)
            {
                case ConsoleKey.Y:
                    PrintHashRecords(hashRecords);
                    break;

                default:
                    Console.WriteLine();
                    break;
            }

            ScanPackages(appPath, hashRecords);

        } // ImportHashTables

        //------------------------------------------------------------------------------------------------------------------------

        private static void PrintHashRecords(Dictionary<string, string> records)
        {
            WriteLine();

            foreach (KeyValuePair<string, string> item in records)
            {
                WriteLine(item.Value);
            }
        } // PrintHashRecords

        //------------------------------------------------------------------------------------------------------------------------

        private static void ScanPackages(string appPath, Dictionary<string, string> hashRecords)
        {
            WriteLine("\nThe extraction process may take several minutes.");
            Write("Proceed with package extraction? (Y/n) ");

            ConsoleKeyInfo proceed = Console.ReadKey();

            switch (proceed.Key)
            {
                case ConsoleKey.Y:
                case ConsoleKey.Enter:
                    break;

                default:
                    return;
            }

            WriteLine("\n");
            WriteLine("Enter the output path where files will be saved or 'exit' to quit.");
            WriteLine("(Leave blank to use the application path.)");
            Write("> ");

            string outputPath = Console.ReadLine();

            WriteLine("\n");

            if (String.Equals(outputPath, "exit", StringComparison.OrdinalIgnoreCase))
                return;

            if (!Directory.Exists(outputPath))
            {
                Write("Creating output directory... ");

                Directory.CreateDirectory(outputPath);

                if (!Directory.Exists(outputPath))
                {
                    WriteLine("FAILED\n", ConsoleColor.Red);
                    return;
                }

                WriteLine("done!\n");

                DriveInfo dinfo = new DriveInfo(Path.GetPathRoot(outputPath));

                //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
                //  NTFS Compression Stuff
                //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
                if (dinfo.DriveFormat == "NTFS")
                {
                    outputPath = outputPath.Replace('\\', '/');

                    DirectoryInfo outputPathInfo = new DirectoryInfo(outputPath);

                    // See if the output folder is already compressed.
                    if ((outputPathInfo.Attributes & FileAttributes.Compressed) != FileAttributes.Compressed)
                    {
                        // If not, offer to compress it.
                        WriteLine("The target file system supports file and folder compression.");
                        Write("Do you want to compress this folder? (Y/n) ");

                        ConsoleKeyInfo key = Console.ReadKey();

                        WriteLine();

                        if (key.Key == ConsoleKey.Y || key.Key == ConsoleKey.Enter)
                        {
                            // Elevate file permissions.
                            new FileIOPermission(PermissionState.Unrestricted).Assert();

                            // Set management object path.
                            string mgmtObjectString = "Win32_Directory.Name=\"" + outputPath + "\"";

                            try
                            {
                                // Create management object using the path above.
                                using (ManagementObject obj = new ManagementObject(mgmtObjectString))
                                {
                                    // Invoke the WMI Compress method.
                                    ManagementBaseObject outParams = obj.InvokeMethod("Compress", null, null);

                                    // See if the method was successful.
                                    if ((uint)outParams.Properties["ReturnValue"].Value != 0)
                                        WriteLine("WMI was unable to compress the output folder.\n", ConsoleColor.DarkYellow);
                                }
                            }
                            catch
                            {
                                WriteLine("Error: unable to create management object.", ConsoleColor.Red);
                                WriteLine("The folder will not be compressed.\n");
                            }

                            // Revert file permissions.
                            FileIOPermission.RevertAssert();
                        }
                    }
                }
            }
            else
            {
                // Prompt for overwrite policy.

                WriteLine("The specified directory exists. Please select an option below.");
                WriteLine("(a) Overwrite all duplicates");
                WriteLine("(b) Overwrite if sizes differ (fast)");
                WriteLine("(c) Overwrite if contents differ (slow)");
                WriteLine("(D) Do not overwrite");
                Write("Select one: (a/b/c/D) ");

                ConsoleKeyInfo key = Console.ReadKey();

                WriteLine("\n");

                switch (key.Key)
                {
                    case ConsoleKey.A:
                        g_fileReplaceDemand = Overwrite.All;
                        break;

                    case ConsoleKey.B:
                        g_fileReplaceDemand = Overwrite.DifferentSize;
                        break;

                    case ConsoleKey.C:
                        g_fileReplaceDemand = Overwrite.DifferentContents;
                        break;

                    default:
                        break;
                }
            }

            WriteLine("Do you want to ignore the leading \"\\client\\res\" path? (Y/n) ");

            ConsoleKeyInfo k = Console.ReadKey();

            WriteLine("\n");

            switch (k.Key)
            {
                case ConsoleKey.Y:
                case ConsoleKey.Enter:
                    removeClientRes = true;
                    break;

                default:
                    removeClientRes = false;
                    break;
            }

            Write("\nScanning packages... ");

            string packagePath = appPath + @"\client\res\pack";

            string[] packages = Directory.GetFiles(packagePath, "*.pk", SearchOption.TopDirectoryOnly);

            WriteLine(packages.Length.ToString("#,##0") + " found.\n");
                
            if (packagePath.Length == 0)
                return;
            
            int totalFiles = 0;

            for (int i = 0; i < packages.Length; i++)
            {
                string package = packages[i];

                Write("  Reading " + Path.GetFileName(package) + "... ");

                totalFiles += ExtractPackageContents(package, outputPath, hashRecords);
            }

            WriteLine("\n" + totalFiles.ToString("#,##0") + " total files (" + bytesWritten.ToString("#,##0") + " Bytes) have been extracted.");

        } // ScanPackages

        //------------------------------------------------------------------------------------------------------------------------

        private static int ExtractPackageContents(string packagePath, string outputPath, Dictionary<string, string> hashRecords)
        {
            FileStream fs = new FileStream(packagePath, FileMode.Open, FileAccess.Read, FileShare.Read);

            BinaryReader reader = new BinaryReader(fs, Encoding.ASCII);

            // -- Get record table position.

            fs.Seek(fs.Length - 8, SeekOrigin.Begin);

            int tableOffset = reader.ReadInt32();

            fs.Seek((long)tableOffset, SeekOrigin.Begin);

            // -- Read record table.

            int recordCount = reader.ReadInt32();

            WriteLine("found " + recordCount.ToString() + " records.");

            List<PackageContentInfo> contentList = new List<PackageContentInfo>(recordCount);

            for (int i = 0; i < recordCount; i++)
            {
                PackageContentInfo contentInfo = new PackageContentInfo();

                reader.ReadBytes(4);
                reader.ReadBytes(4);
                reader.ReadBytes(4);
                contentInfo.DataSize = reader.ReadInt32();
                contentInfo.HashID = new string(reader.ReadChars(32));
                reader.ReadBytes(4);
                reader.ReadBytes(4);    // compressed size
                reader.ReadBytes(32);   // alt. hash id
                reader.ReadBytes(4);
                contentInfo.DataOffset = reader.ReadInt32();
                reader.ReadBytes(4);

                contentList.Add(contentInfo);
            }

            // -- Sort records by file offset.

            contentList.Sort(
                (PackageContentInfo a, PackageContentInfo b) =>
                {
                    return (a.DataOffset < b.DataOffset ? -1 : 1);
                });

            Write("    Extracting contents...");

            int succeeded = 0;

            for (int i = 0; i < contentList.Count; i++)
            {
                PackageContentInfo item = contentList[i];

                fs.Seek((long)item.DataOffset, SeekOrigin.Begin);

                byte[] data = reader.ReadBytes(item.DataSize);

                try
                {
                    string hashID = String.Empty;

                    hashRecords.TryGetValue(item.HashID, out hashID);

                    if (String.IsNullOrEmpty(hashID))
                    {
                        Write("?", ConsoleColor.Yellow);
                    }
                    else
                    {
                        string filename = outputPath + "\\" + hashRecords[item.HashID];

                        if (removeClientRes)
                            filename = filename.Replace("client\\res\\", "");

                        int temp = SaveDataToFile(data, filename);

                        if (temp != 0)
                        {
                            bytesWritten += temp;
                            succeeded++;
                        }
                    }
                }
                catch (KeyNotFoundException)
                {
                    Write("X", ConsoleColor.Red);
                }
                catch (Exception ex)
                {
                    WriteLine("\n" + ex.Message);
                }
            }

            WriteLine(" done!\n");

            return succeeded;

        } // ExtractPackageContents
        
        //------------------------------------------------------------------------------------------------------------------------

        static int SaveDataToFile(byte[] data, string filename)
        {
            if (data == null || data.Length == 0 || String.IsNullOrEmpty(filename))
            {
                Write("X");
                return 0;
            }

            bool match = false;

            if (File.Exists(filename))
            {
                if (g_fileReplaceDemand == Overwrite.None)
                {
                    return 0;
                }
                if (g_fileReplaceDemand == Overwrite.DifferentSize)
                {
                    if (new FileInfo(filename).Length == data.Length)
                        return 0;
                }
                else if (g_fileReplaceDemand == Overwrite.DifferentContents)
                {
                    FileInfo info = new FileInfo(filename);

                    // Only bother computing hash if sizes are equal.

                    if (info.Length == data.Length)
                    {
                        match = true;

                        FileStream existing = null;
                        BinaryReader reader = null;

                        try
                        {
                            existing = info.OpenRead();
                            reader = new BinaryReader(existing);

                            byte[] data2 = reader.ReadBytes(data.Length);

                            reader.Close();
                            existing.Dispose();

                            int iterations = data.Length / sizeof(Int64);

                            for (int i = 0; i < iterations; i++)
                            {
                                if (BitConverter.ToInt64(data, i * sizeof(Int64)) != BitConverter.ToInt64(data2, i * sizeof(Int64)))
                                {
                                    match = false;
                                    break;
                                }
                            }

                            if (match)
                            {
                                // Finish the last few bytes.
                                for (int k = iterations * sizeof(Int64); k < data.Length; k++)
                                {
                                    if (data[k] != data2[k])
                                    {
                                        match = false;
                                        break;
                                    }
                                }
                            }
                        }
                        catch
                        {
                            Write("X", ConsoleColor.Red);
                        }
                        finally
                        {
                            if (reader != null)
                                reader.Close();
                            if (existing != null)
                                existing.Dispose();
                        }
                    }
                }

                // Prompt user to overwrite existing file.

                if (match) return 0;

                if (!overwriteAll)
                {
                    WriteLine("\nThe file '" + Path.GetFileName(filename) + "' already exists.");
                    Write("Do you wish to replace the existing file? (Y/n/a/c) ");

                    ConsoleKeyInfo replace = Console.ReadKey();

                    WriteLine();

                    switch (replace.Key)
                    {
                        case ConsoleKey.Y:
                        case ConsoleKey.Enter:
                            break;

                        case ConsoleKey.A:
                            overwriteAll = true;
                            break;

                        case ConsoleKey.C:
                            throw new Exception();

                        default:
                            return 0;
                    }

                    Write("    ");
                }
            }

            CreateDirectory(Path.GetDirectoryName(filename));

            FileStream fs = new FileStream(filename, FileMode.Create, FileAccess.Write, FileShare.None);

            BinaryWriter writer = new BinaryWriter(fs, Encoding.ASCII);

            writer.Write(data);

            writer.Close();

            fs.Dispose();

            // Confirm data was written.

            if (File.Exists(filename))
            {
                Write(".");
                return data.Length;
            }
            else
            {
                Write("X");
                return 0;
            }
        } // SaveDataToFile

        //------------------------------------------------------------------------------------------------------------------------

        static void CreateDirectory(string fullPath)
        {
            if (Directory.Exists(fullPath))
                return;

            // Because Directory.CreateDirectory does not create
            // nested directories, we must create them manually.

            if (String.IsNullOrEmpty(fullPath))
                throw new ArgumentNullException("Path cannot be null or empty.");
            
            string[] parts = fullPath.Split('\\');

            string path = String.Empty;

            for (int i = 0; i < parts.Length; i++)
            {
                path += parts[i] + "\\";

                if (!Directory.Exists(path))
                    Directory.CreateDirectory(path);
            }

        } // CreateDirectory

        //------------------------------------------------------------------------------------------------------------------------

        //================================================================================
        //  Console Shortcuts
        //================================================================================
        #region Console Shortcuts

        private static void Write(string text, ConsoleColor color)
        {
            if (Console.ForegroundColor != color)
                Console.ForegroundColor = color;

            Console.Write(text);
        }

        private static void Write(string text)
        {
            Write(text, ConsoleColor.Gray);
        }

        private static void WriteLine(string text, ConsoleColor color)
        {
            Write(text + "\n", color);
        }

        private static void WriteLine(string text)
        {
            Write(text + "\n", ConsoleColor.Gray);
        }

        private static void WriteLine()
        {
            Console.WriteLine();
        }
        #endregion Console Shortcuts
    } // class

} // namespace