import sys
import zlib
import util

def unzip(data):
	r = util.get_getter(data, "<")
	ret = []
	while r.offset < r.size:
		# print ("offset=%x" % r.offset)
		mark = r.get("I")
		zsize = mark & 0x7FFF
		isCompressedBLock = (mark & 0x8000) > 0
		if isCompressedBLock:
			ret.append(zlib.decompress(r.get_raw(zsize)))
		else:
			ret.append(r.get_raw(zsize))
		r.align(0x10)
	r.assert_end()
	return "".join(ret)

def unzipFile(inFile, outFile):
	with open(inFile, "rb") as fin:
		data = fin.read()
		data2 = unzip(data)
		with open(outFile, "wb") as fout:
			fout.write(data2)

if __name__ == "__main__":
	unzipFile(sys.argv[1], sys.argv[1] + ".unzip")