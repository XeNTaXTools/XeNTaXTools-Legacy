import decrypt
import key_map
import os

def testHash():
	####################################
	# test hash
	# obtain test data:
	# input:
	#	bp 7ff6a8176cb8-0x87ed0000 "? @rbx"
	# output:
	#	bp 7ff6a8176d01-0x87ed0000 "? @r8; ? @r9"
	ret = decrypt.hash(0xd90fae15)
	assert ret == 0xa3e459c62c1e7423, "wrong value 0x%x" % ret

	ret = decrypt.hash(0xb079248)
	assert ret == 0xe6b4a85c9177a762, "wrong value 0x%x" % ret

	ret = decrypt.hash(0xe936cc5c)
	assert ret == 0xad4c94a1e72a36bf, "wrong value 0x%x" % ret	

	ret = decrypt.hash(0xedf3d35e)
	assert ret == 0x471b5f0c010586fd, "wrong value 0x%x" % ret

def testCalcHashBuffer2():
	####################################
	# test calcHashBuffer2
	# obtain test data:
	# input:
	# 	bp 7ff6a816702f-0x87ed0000 "? @r8d; gc"
	# output:
	#	bp 7ff6a81670c6-0x87ed0000 "? poi(@rbp+7); db @rbp+f L4; gc"
	ret = decrypt.calcHashBuffer2(0x9f67)
	assert ret == "\x06\xbc\x71", "wrong value %s" % repr(ret)

	ret = decrypt.calcHashBuffer2(0xbe0cd6)
	assert ret == "\x08\x07\xff\x39", "wrong value %s" % repr(ret)

if __name__ == "__main__":
	testCalcHashBuffer2()
	testDecryptFile()