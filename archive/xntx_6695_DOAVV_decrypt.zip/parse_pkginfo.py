import sys
import util

def parse(data):
	r = util.get_getter(data, "<")
	r.seek(0x34)

	btifOffset = r.get("I")

	fourCC = r.get("4s", offset=btifOffset)
	assert fourCC == "btif"

	r.seek(btifOffset + 0x8)
	fileCount = r.get("I")

	# However, it seems like the orignal file names are stripped in the GAME
	# we can only restore orignal file names from the LAUNCHER
	r.seek(btifOffset + 0x18)
	origFileTableOff = r.get("I") + 0xc
	origFileTableOff += r.offset

	r.seek(btifOffset + 0x1c)
	realFileTableOff = r.get("I") + 0x8
	realFileTableOff += r.offset

	ret = {}

	if btifOffset == 0x60:
		fileInfoSize = 0x20
	else:
		fileInfoSize = 0x24

	for i in xrange(fileCount):
		r.seek(btifOffset + 0x20 + i * fileInfoSize + 0x10)
		origFileOff = origFileTableOff + r.get("I")
		realFileOff = realFileTableOff + r.get("I")
		encryptFlag = r.get("I")
		decodeKey = r.get("I")

		r.seek(realFileOff)
		realFile = r.get_cstring().replace("/", "\\")
		r.seek(origFileOff)
		origFile = r.get_cstring().replace("/", "\\")

		ret[realFile] = {
			"origFile": origFile,
			"key": decodeKey,
			"encrypted": encryptFlag not in (0x0, 0xe0000000, 0x80000000),
			"compressed": encryptFlag not in (0x0, 0xe0000000, 0x80000000, 0xa0000000)
		}

		# showDetail = "b7993ca70ece01053ae17308dd41288888dba442f2615753f29f850095a72ae1" in realFile
		showDetail = False
		if showDetail:
			print "offset:", hex(btifOffset + 0x20 + i * fileInfoSize)
			print realFile
			print origFile
			print

		# Really need more investigation on this flag
		assert encryptFlag in (0x0, 0xc0000000, 0xe0000000, 0xa0000000, 0x80000000)

	return ret