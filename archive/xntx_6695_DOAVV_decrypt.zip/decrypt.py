import os
import sys
import struct
import atexit

import decompress
import parse_pkginfo
import util

from util import writeErrorLog

USE_ORIG_NAME = True	# restore original file name
DECRYPT_ONLY = False	# do not decompress, debug only, do not apply to pkgInfo file

HASH_BUFFER1 = None
HASH_BUFFER1_GAME = None
HASH_BUFFER1_INITED = False

PKG_INFO = {}

def initHashBuffer1():
	global HASH_BUFFER1_INITED
	if HASH_BUFFER1_INITED:
		return

	global HASH_BUFFER1
	with open("hashbuffer1.bin", "rb") as f:
		HASH_BUFFER1 = f.read()

	global HASH_BUFFER1_GAME
	with open("hashbuffer1_game.bin", "rb") as f:
		HASH_BUFFER1_GAME = f.read()		

	HASH_BUFFER1_INITED = True

def getHashBuffer(isLauncher=True):
	return isLauncher and HASH_BUFFER1 or HASH_BUFFER1_GAME

def readPkgInfo(pkgInfoPath):
	global PKG_INFO
	if pkgInfoPath in PKG_INFO:
		return PKG_INFO[pkgInfoPath]
	print "reading pkginfo", pkgInfoPath
	with open(pkgInfoPath, "rb") as f:
		data = f.read()
		data = decryptPkgInfo(data, testIsLauncher(pkgInfoPath))
		ret = parse_pkginfo.parse(data)
		PKG_INFO[pkgInfoPath] = ret
		return ret

def decrypt(buff, hashbuffer1, hashbuffer2):
	l1 = len(hashbuffer1)
	l2 = len(hashbuffer2)
	assert l1 == 0x158
	assert 1 <= l2 <= 4
	ret = []
	for i in xrange(len(buff)):
		ch = buff[i]
		v = ord(ch)
		x = ord(hashbuffer1[i % l1])
		y = ord(hashbuffer2[i % l2])
		z = x ^ y
		if v == 0 or v == z:
			ret.append(ch)
		else:
			ret.append(chr(v ^ z))
	return "".join(ret)

def calcHashBuffer2(arg):
	x = arg * 0x77
	# print hex(x)
	c = 0x2e8ba2e8ba2e8ba3
	# print hex(x * c)
	rdx = (x * c) >> 64
	# print hex(rdx)
	rdx >>= 1
	# print hex(rdx)
	edx = rdx & 0xFFFFFFFF
	# print hex(edx)
	buff = struct.pack(">I", edx).replace("\x00", "")
	return buff

def maybePkgInfoFile(fpath):
	with open(fpath, "rb") as f:
		f.seek(2)
		if f.read(2) != "\x00\x00":
			return False
		f.seek(4)
		if f.read(2) != "\x00\x00":
			return False
		return True

def decryptFile(fpath, outroot):
	initHashBuffer1()

	pkgInfoPath = getPkgInfoPath(fpath)
	if pkgInfoPath == fpath:
		return

	pkgInfo = readPkgInfo(pkgInfoPath)
	_, locPath, isLauncher, isDL = parsePath(fpath)

	fileinfo = pkgInfo.get(locPath)
	# I guess these files are no more needed and got removed from pkginfo
	# but somehow remain on the disk
	if fileinfo is None:	
		writeErrorLog("can't find fileinfo for %s" % fpath)
		if maybePkgInfoFile(fpath):
			writeErrorLog("!!!!!!!!!!!!! potential pkgInfo file!!!")
		return

	arg = fileinfo["key"]

	fout = os.path.join(
		outroot, 
		isLauncher and "Launcher_data" or "DX11_data", 
		isDL and "DL" or "", 
		USE_ORIG_NAME and fileinfo["origFile"] or locPath)

	directory = os.path.split(fout)[0]
	if not os.path.exists(directory):
		os.makedirs(directory)

	hashbuffer2 = calcHashBuffer2(arg)

	with open(fpath, "rb") as f1:
		buff = f1.read()
		with open(fout, "wb") as f2:
			if fileinfo["encrypted"]:
				buffDecrypt = decrypt(buff, getHashBuffer(isLauncher), hashbuffer2)
				if fileinfo["compressed"] and (not DECRYPT_ONLY):
					buffDecrypt = decompress.unzip(buffDecrypt)
			else:	# file not encryped
				buffDecrypt = buff
			f2.write(buffDecrypt)

def decryptPkgInfo(data, isLauncher=True):
	initHashBuffer1()

	key = struct.unpack("<I", data[:4])[0]
	hashbuffer2 = calcHashBuffer2(key)
	hashbuffer1 = getHashBuffer(isLauncher)
	buffDecrypt = decrypt(data[4:], hashbuffer1, hashbuffer2)
	buffDecrypt = decompress.unzip(buffDecrypt)
	return buffDecrypt

def decryptPkgInfoFile(fpath, fout):
	with open(fpath, "rb") as f1:
		data = f1.read()
		data2 = decryptPkgInfo(data, testIsLauncher(fpath))
		with open(fout, "wb") as f2:
			f2.write(data2)

def testIsLauncher(fpath):
	return "launcher_data" in fpath.lower()

# returns basePath, localPath, isLauncher, isDL
def parsePath(fpath):
	isLauncher = testIsLauncher(fpath)
	
	fpathL = fpath.lower()
	if isLauncher:
		index = fpathL.find("launcher_data") + len("launcher_data")
		basePath = fpath[:index]
		return basePath, fpath[index + 1:], True, False
	else:
		index = fpathL.find("dx11_data") + len("dx11_data")
		basePath = fpath[:index]
		rem = fpathL[index + 1:]
		if rem.startswith("dl"):
			return basePath, fpath[index + len("\\dl\\"):], False, True
		else:
			return basePath, fpath[index + 1:], False, False

def getPkgInfoPath(fpath):
	basePath, locPath, isLauncher, isDL = parsePath(fpath)
	locPathU = locPath.upper()
	if isLauncher:
		if locPathU.startswith("COMMON"):
			return os.path.join(basePath, "COMMON\\4be7efcc93f64e14d7bd7984ef6eeb2ef5ad802ea74cf12ad50a4d39bab71798")
		else:
			raise Exception("Can't Find PkgInfo for LAUNCHER file %s" % fpath)
	else:
		if locPathU.startswith("COMMON"):
			return os.path.join(basePath, "COMMON\\4be7efcc93f64e14d7bd7984ef6eeb2ef5ad802ea74cf12ad50a4d39bab71798")
		elif locPathU.startswith("HIGH"):
			return os.path.join(basePath, "HIGH\\9b2d39b6d57f8613d9a316d8c3e6120886640a5762ea23c8fcc88d8acc7563b4")
		else:
			raise Exception("Can't Find PkgInfo for LAUNCHER file %s" % fpath)

# not used
def hash(v):
	x = (~v) & 0xFFFFFFFFFFFFFFFF
	# print hex(x)
	y = (v << 0x15) & 0xFFFFFFFFFFFFFFFF
	# print hex(y)
	z = x + y
	z &= 0xFFFFFFFFFFFFFFFF
	# print hex(z)
	w = (z >> 0x18) ^ z
	# print hex(w)
	p = (w * 0x109) & 0xFFFFFFFFFFFFFFFF
	# print hex(p)
	q = p >> 0xE
	# print hex(q)
	a = p ^ q
	# print hex(a)
	b = (a * 0x15) & 0xFFFFFFFFFFFFFFFF
	# print hex(b)
	magic = 0x80000001

	hsh = ((b >> 0x1C) ^ b) * magic
	hsh &= 0xFFFFFFFFFFFFFFFF
	# print hex(hsh)
	return hsh

def decryptAll(gameRootDir, outroot):
	# launcher
	launcherDir = os.path.join(gameRootDir, "Launcher_data")
	for filepath in util.iter_path(launcherDir):
		print "==> decrypting %s" % filepath
		decryptFile(filepath, outroot)

	# game
	gameRootDir = os.path.join(gameRootDir, "DX11_data")
	for subDir in ("COMMON", "DL", "HIGH"):
		for filepath in util.iter_path(os.path.join(gameRootDir, subDir)):
			print "==> decrypting %s" % filepath
			decryptFile(filepath, outroot)

if __name__ == "__main__":
	decryptAll(sys.argv[1], sys.argv[2])