import os
import struct
import collections
import math
import numpy
from io import IOBase
import os
import atexit

# BC1
DXT1_HEADER_TEMPLATE = "DDS |\x00\x00\x00\x07\x10\x00\x00\x00\x02\x00\x00\x00\x02\x00\x00\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00 \x00\x00\x00\x04\x00\x00\x00DXT1\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x08\x10@\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
# BC2
DXT3_HEADER_TEMPLATE = "DDS |\x00\x00\x00\x07\x10\x00\x00\x00\x08\x00\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00 \x00\x00\x00\x04\x00\x00\x00DXT3\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x02\x10\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
# BC3
DXT5_HEADER_TEMPLATE = "DDS |\x00\x00\x00\x07\x10\x00\x00\x00\x02\x00\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00 \x00\x00\x00\x04\x00\x00\x00DXT5\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x08\x10@\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

def gen_dxt1_header(width, height):
	header = DXT1_HEADER_TEMPLATE
	return header[:0xc] + struct.pack("<II", height, width) + header[0x14:]

def gen_dxt3_header(width, height):
	header = DXT3_HEADER_TEMPLATE
	return header[:0xc] + struct.pack("<II", height, width) + header[0x14:]

def gen_dxt5_header(width, height):
	header = DXT5_HEADER_TEMPLATE
	return header[:0xc] + struct.pack("<II", height, width) + header[0x14:]
	
# makes parsing data a lot easier
def get_getter(data, endian, coverage_test=False):
	return getter(data, endian, coverage_test)

class getter(object):
	
	def __init__(self, data, endian, coverage_test):
		self.data = data
		self.endian = endian
		self.coverage = []
		self.last_coverage = 0
		self.coverage_test = coverage_test
		self.is_file = isinstance(self.data, file)
		if self.is_file:
			self.offset = self.data.tell()
			self.data.seek(0, 2)
			self.size = self.data.tell()
			self.data.seek(self.offset, os.SEEK_SET)
		else:
			self.offset = 0
			self.size = len(data)
	
	def seek(self, offset, whence=0):
		assert whence in (0, 1, 2)
		if self.is_file:
			self.data.seek(offset, whence)
			self.offset = self.data.tell()
		else:
			if whence == 0:
				self.offset = offset
			elif whence == 1:
				self.offset += offset
			elif whence == 2:
				self.offset = len(self.data) - offset
	
	def skip(self, size):
		self.seek(size, 1)

	def pad(self, size, pad_pattern=b"\x00"):
		pad_data = self.get_raw(size)
		pattern_size = len(pad_pattern)
		for i in range(size // pattern_size):
			assert pad_pattern.startswith(pad_data[i * pattern_size: (i + 1) * pattern_size])
	
	def align(self, size):
		rem = self.offset % size
		if rem:
			self.pad(size - rem)
	
	def get_raw(self, size):
		if self.is_file:
			data_seg = self.data.read(size)
		else:
			data_seg = self.data[self.offset: self.offset + size]
		self._add_coverage(self.offset, size)
		self.offset += size
		return data_seg

	def print_coverage(self):
		print "coverage:"
		last = 0
		for i, (l, r) in enumerate(self.coverage):
			space = l - last
			print i, "cover [0x%x, 0x%x)" % (l, r)
			if space > 0:
			 	print "+%d" % space
			last = r

	def _add_coverage(self, offset, size):
		if not self.coverage_test:
			return
		# print
		# print "before ======="
		# self.print_coverage()
		# print "add coverage 0x%x, 0x%x" % (offset, size)
		coverage_cnt = len(self.coverage)
		if coverage_cnt == 0 or offset > self.coverage[-1][1]:
			self.coverage.append([offset, offset + size])
			# print "after ======"
			# self.print_coverage()
			# self._check_coverage()
			return

		start_i = -1
		lo = 0
		hi = coverage_cnt
		while lo < hi:
			mid = (lo + hi) // 2
			# print "\t", lo, hi, mid
			secl = self.coverage[mid][0]
			secr = self.coverage[mid][1]
			if secl <= offset <= secr:
				start_i = mid
				break
			if offset > secl:
				lo = mid + 1
			else:
				hi = mid
				start_i = mid

		assert start_i != -1
		if offset < self.coverage[start_i][0]:
			self.coverage.insert(start_i, [offset, offset + 1])

		# print "start_i", start_i

		end_i = start_i
		for i in xrange(start_i, len(self.coverage)):
			secl = self.coverage[i][0]
			secr = self.coverage[i][1]
			# print "checking", i, hex(secl), hex(secr)
			if offset + size < secl:
				break
			end_i = i
			if offset + size < secr:
				break
		# print "end_i", end_i
		end = max(offset + size, self.coverage[end_i][1])
		for i in xrange(end_i, start_i, -1):
			self.coverage.pop(i)
		self.coverage[start_i][1] = end

		# print "after ======"
		# self.print_coverage()
		# self._check_coverage()

	def _check_coverage(self):
		v = -1
		tot_sz = 0
		for l, r in self.coverage:
			if l >= r or v >= l:
				print ("error!")
				import sys
				sys.exit(0)
			v = r + 1
			tot_sz += r - l
		c = tot_sz * 1.0 / self.size
		if c < self.last_coverage:
			import sys
			print "error size!"
			sys.exit(0)
		self.last_coverage = c

	def get_coverage(self):
		tot_sz = 0
		for l, r in self.coverage:
			tot_sz += r - l
		return tot_sz * 1.0 / self.size

	def get(self, fmt, offset=None, force_tuple=False):
		if offset is not None:
			self.seek(offset)
		size = struct.calcsize(fmt)
		data_seg = self.get_raw(size)
		res = struct.unpack(self.endian + fmt, data_seg)
		if not force_tuple and len(res) == 1:
			return res[0]
		return res
	
	def get_cstring(self):
		s = b""
		ch = b""
		while ch != b"\x00":
			ch = self.get_raw(1)
			s += ch
		return s.rstrip(b"\x00")
			
	def block(self, size, endian=None, coverage_test=None):
		data = self.get_raw(size)
		if endian is None:
			endian = self.endian
		if coverage_test is None:
			coverage_test = self.coverage_test
		return getter(data, endian, coverage_test)
	
	def assert_end(self):
		assert self.offset == self.size
		
	def dump(self, title, offset, size, fmt):
		dump_bin(title, self, offset, size, fmt)
		self.seek(offset)

def iter_path(path):
	if isinstance(path, str):
		if os.path.isdir(path):
			for top, dirs, files in os.walk(path):
				for fname in files:
					yield os.path.join(top, fname)
		else:
			yield path
	elif callable(path):
		for _path in path():
			yield iter_path(_path)
	else:
		for _path in path:
			yield iter_path(_path)

# for quick verify
def export_obj(vb, ib, flip_v=False, outpath=None, smooth=True, mtl_file=None,
			   mtllib=None, usemtl=None, v_offset=1, vt_offset=1, vn_offset=1):
	lines = []
	if smooth:
		lines.append("s 1")
	if mtllib is not None:
		lines.append("mtllib " + mtllib)
	if usemtl is not None:
		lines.append("usemtl " + usemtl)
	if len(vb[0]) >= 3:
		for v in vb:
			lines.append("v %f %f %f" % (v[0], v[1], v[2]))
	if len(vb[0]) >= 5:
		for v in vb:
			u, v = v[3:5]
			if flip_v: v = 1.0 - v
			lines.append("vt %f %f" % (u, v))
	if len(vb[0]) >= 8:
		for v in vb:
			lines.append("vn %f %f %f" % (v[5], v[6], v[7]))
	for i in range(len(ib) // 3):
		i1, i2, i3 = ib[i * 3: i * 3 + 3]
		if len(vb[0]) <= 3:	
			lines.append("f %d %d %d" % (i1 + v_offset, i2 + v_offset, i3 + v_offset))
		elif len(vb[0]) <= 5:
			lines.append("f %d/%d %d/%d %d/%d" % (i1 + v_offset, i1 + vt_offset,
												  i2 + v_offset, i2 + vt_offset,
												  i3 + v_offset, i3 + vt_offset))
		elif len(vb[0]) <= 8:
			lines.append("f %d/%d/%d %d/%d/%d %d/%d/%d" % (i1 + v_offset, i1 + vt_offset, i1 + vn_offset,
														   i2 + v_offset, i2 + vt_offset, i2 + vn_offset,
														   i3 + v_offset, i3 + vt_offset, i3 + vn_offset))
	if outpath is not None:
		f = open(outpath, "w")
		f.write("\n".join(lines))
		f.close()
	return lines

def is_valid_float(v):
	return not math.isnan(v) and not math.isinf(v)

def dump_bin(title, fp, offset, size, fmt):
	unit_size = struct.calcsize(fmt)
	cnt = size / unit_size
	if cnt * unit_size != size:
		cnt += 1
	print ("============= %s @0x%x =============" % (title, offset))
	line_cnt = 0x10 / unit_size
	values = fp.get("%d%s" % (cnt, fmt), offset=offset, force_tuple=True)
	val_fmt = "%" + ("0%dx" % (unit_size * 2))
	fmt_func = lambda v: val_fmt % v
	for i in xrange(0, len(values), line_cnt):
		print " ".join(map(fmt_func, values[i: i + line_cnt]))

# if we interleave different v/vt/vn block and f block then 3dsmax will import incorrectly
def fixObjFor3dsmax(lines):
	def isVLine(l):
		return l.startswith("v ") or l.startswith("vn ") or l.startswith("vt ")

	vLines = list(filter(isVLine, lines))
	firstVLineNo = 0
	for i, l in enumerate(lines):
		if isVLine(l):
			firstVLineNo = i
			break

	nonVLines = list(filter(lambda l: not isVLine(l), lines))
	retLines = nonVLines[:firstVLineNo] + vLines + nonVLines[firstVLineNo:]
	return retLines

def get_filename_without_ext(path):
	return os.path.split(os.path.splitext(path)[0])[1]

PRINT_ERR_TO_CONSOLE = False
FP_ERR = None
def writeErrorLog(s):
	global FP_ERR
	if FP_ERR is None:
		FP_ERR = open("err.log", "w")
		atexit.register(finishErrorLog)
	FP_ERR.write(s + "\n")
	if PRINT_ERR_TO_CONSOLE:
		print s

def finishErrorLog():
	global FP_ERR
	if FP_ERR is not None:
		FP_ERR.close()
		FP_ERR = None