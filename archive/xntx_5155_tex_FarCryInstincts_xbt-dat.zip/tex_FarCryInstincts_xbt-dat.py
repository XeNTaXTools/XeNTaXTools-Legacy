from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Far Cry Instincts", ".xbt;.dat")
	noesis.setHandlerTypeCheck(handle, noeCheckGeneric)
	noesis.setHandlerLoadRGBA(handle, FCLoadRGBA)
	#noesis.logPopup()
	return 1


def FCLoadRGBA(data, texList):
    datasize = len(data) - 0x20         
    bs = NoeBitStream(data)
    bs.seek(0x04, NOESEEK_ABS)
    imgWidth = bs.readInt()
    imgHeight = bs.readInt()
    imgSize = bs.readInt()
    imgFmt = bs.readInt()
    bs.seek(0x20, NOESEEK_ABS)         
    #DXT1
    if imgFmt == 0x10:
        data = bs.readBytes(datasize)
        texFmt = noesis.NOESISTEX_DXT1
    #DXT5
    elif imgFmt == 0x12 or imgFmt == 0x11:
        data = bs.readBytes(datasize)
        texFmt = noesis.NOESISTEX_DXT5
    #morton order swizzled raw ????
    #elif imgFmt == 0x0E:
    #    untwid = bytearray()
    #    for x in range(0, imgWidth):
    #        for y in range(0, imgHeight):
    #            idx = noesis.morton2D(x, y)
    #            untwid += data[idx*4:idx*4+4]
    #    data = rapi.imageDecodeRaw(untwid, imgWidth, imgHeight, "a8g8b8r8")
    #    texFmt = noesis.NOESISTEX_RGBA32
	    
        #unknown, not handled
    else:
        print("WARNING: Unhandled image format")
        return None
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1