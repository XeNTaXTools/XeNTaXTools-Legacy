#by Durik256
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("My Little Pony Gameloft", ".rk")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)
    return 1
    
def noepyCheckType(data):
    if data[:8] != b'RKFORMAT':
        return 0
    return 1
    
def noepyLoadModel(data, mdlList):
    bs = NoeBitStream(data)
    ctx = rapi.rpgCreateContext()
    bs.seek(80)
    
    vinf = [bs.readUInt() for x in range(4)]
    iinf = [bs.readUInt() for x in range(4)]
    
    bs.seek(vinf[1])
    VBUF = bs.readBytes(vinf[3])
    stride = vinf[3]//vinf[2]
    rapi.rpgBindPositionBuffer(VBUF, noesis.RPGEODATA_FLOAT, stride)
    rapi.rpgBindUV1BufferOfs(VBUF, noesis.RPGEODATA_SHORT, stride, 12)
    
    bs.seek(iinf[1])
    IBUF = bs.readBytes(iinf[3])
    rapi.rpgCommitTriangles(IBUF, noesis.RPGEODATA_USHORT, iinf[2], noesis.RPGEO_TRIANGLE)
    

    #uv.append(NoeVec3([bs.readShort()/32768, bs.readShort()/32768]+[0]))
  

    mdl = rapi.rpgConstructModel()
    mdl.setModelMaterials(NoeModelMaterials([], [NoeMaterial("default","")]))
    mdlList.append(mdl)
    rapi.setPreviewOption("setAngOfs", "0 -90 -90")
    return 1