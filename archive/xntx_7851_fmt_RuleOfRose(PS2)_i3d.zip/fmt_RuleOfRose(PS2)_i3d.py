#  Rule of Rose (PS2) i3d bone importer by Bigchillghost
from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Rule of Rose (PS2)", ".i3d")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadModel(handle, noepyLoadModel)
	#noesis.logPopup()
	return 1

#check if it's this type based on the data
def noepyCheckType(data):
	if len(data) < 0x80:
		return 0
	bs = NoeBitStream(data)
	if bs.readInt() == 0x5F443349:
		return 1
	return 1

#load the model
def noepyLoadModel(data, mdlList):
	noesis.logPopup()
	bs = NoeBitStream(data)
	bs.seek(0x10, NOESEEK_ABS)
	boneChunkAddress = bs.readInt()
	boneChunkAddress += 0x10
	bs.seek(boneChunkAddress, NOESEEK_ABS)
	bs.seek(0x28, NOESEEK_REL)
	invMatrixCount = bs.readUShort()
	matrixCount = bs.readUShort()
	texCount = bs.readUShort()
	boneCount = bs.readUShort()
	bs.seek(0x10, NOESEEK_REL)
	invMatrixList = []
	for i in range(0, boneCount):
		Mat44 = NoeMat44.fromBytes( bs.readBytes(0x40) )
		invMatrixList.append(Mat44.toMat43())
	matrixList = []
	for i in range(0, boneCount):
		Mat44 = NoeMat44.fromBytes( bs.readBytes(0x40) )
		matrixList.append(Mat44.toMat43())
	bs.seek(texCount * 4, NOESEEK_REL)
	boneNameOffsets = [0]*boneCount
	for i in range(0, boneCount):
		boneNameOffsets[i] = bs.readInt() + boneChunkAddress
	boneIDs = [0]*boneCount
	for i in range(0, boneCount):
		boneIDs[i] = bs.readUShort()
	boneNames = [""]*boneCount
	for i in range(0, boneCount):
		bs.seek(boneNameOffsets[i], NOESEEK_ABS)
		boneNames[boneIDs[i]] = bs.readString()
	bones = []
	for i in range(0, boneCount):
		bones.append( NoeBone(i, boneNames[i], matrixList[i], None, -1) )
	
	mdl = NoeModel()
	mdl.setBones(bones)
	mdlList.append(mdl)
	rapi.setPreviewOption("setAngOfs", "0 90 -90")
	
	return 1
