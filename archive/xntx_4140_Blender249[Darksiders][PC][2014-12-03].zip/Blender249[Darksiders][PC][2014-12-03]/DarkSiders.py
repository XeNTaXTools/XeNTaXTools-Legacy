import newGameLib
reload(newGameLib)
from newGameLib import *
import Blender

def oppcParser(filename,g):
	g.logOpen()

	sys=Sys(filename)
	sys.addDir(sys.base)
	
	g.word(4)
	g.seek(14,1)
	NSTRUCTPOINTER,DATAPOINTER=g.i(2)
	
	ESTRUCTCOUNT=g.i(1)[0]
	nameList={}
	for i in range(ESTRUCTCOUNT):
		chunk=g.i(2)
		nameList[chunk]=g.word(g.i(1)[0])
		
	NSTRUCTCOUNT=g.i(1)[0]
	for i in range(NSTRUCTCOUNT):
		chunk=g.i(2)
		nameList[chunk]=g.word(g.i(1)[0])
		
	pos=g.tell()
	unk_offs,NSTRUCTCOUNT2=g.i(2)
	for i in range(NSTRUCTCOUNT2):
		chunk=g.i(2)
		nameList[chunk]=g.word(g.i(1)[0])
		
		
	g.seek(pos+unk_offs+4)	
	
	count=g.i(1)[0]
	list=[]
	for i in range(count):
		chunk=g.i(2)
		ext=nameList[chunk]
		list.append([ext,g.i(1)[0]])
		
	fileList=[]	
	for i in range(count):
		ext=list[i][0]
		print ext
		print list[i]
		if ext=='o3d':
			for j in range(list[i][1]):
				fileName=nameList[g.i(2)]
				a,b=g.i(2)
				g.B(5)
				fileList.append([fileName,ext,a])
		elif ext=='dds':
			for j in range(list[i][1]):
				fileName=nameList[g.i(2)]
				a,b,c,d=g.i(4)
				fileList.append([fileName,ext,a])
		elif ext=='bmat':
			for j in range(list[i][1]):
				fileName=nameList[g.i(2)]
				a,b=g.i(2)
				g.B(5)
				fileList.append([fileName,ext,a])
		elif ext=='physpack':
			for j in range(list[i][1]):
				fileName=nameList[g.i(2)]
				a,b=g.i(2)
				g.B(5)
				fileList.append([fileName,ext,a])
		elif ext=='anm':
			for j in range(list[i][1]):
				fileName=nameList[g.i(2)]
				a,b=g.i(2)
				g.B(5)
				fileList.append([fileName,ext,a])
		elif ext=='meshpack':
			for j in range(list[i][1]):
				fileName=nameList[g.i(2)]
				a,b=g.i(2)
				g.B(5)
				fileList.append([fileName,ext,a])
		else:
			print 'WARNING:unknow ext:',ext,g.tell()
			for j in range(list[i][1]):
				fileName=nameList[g.i(2)]
				a,b=g.i(2)
				g.B(5)
				fileList.append([fileName,ext,a])
			#break
	
	DATASTART = DATAPOINTER
	DATASTART += NSTRUCTPOINTER
	g.seek(DATASTART)

	unpSIZE=g.i(1)[0]
	#new=open(filename+'.dec','wb')
	#new.write(zlib.decompress(g.read(g.fileSize()-g.tell())))
	#new.close()
	data=zlib.decompress(	g.read(g.fileSize()-g.tell())	)
	
	pos=0
	for file in fileList:
		new=open(sys.dir+os.sep+sys.base+os.sep+file[0]+'.'+file[1],'wb')
		new.write(data[pos:pos+file[2]])
		new.close()
		pos+=file[2]
		
	g.logClose()	
	
def meshpackParser(filename,g):
	g.debug=True
	A=g.B(9)
	for i in range(A[1]):
		pos=g.tell()
		g.B(3)
		a,b=g.i(2)
		g.seek(a+15)
		data=g.read(b-15)
		new=open(filename+str(i)+'.mesh','wb')
		new.write(zlib.decompress(data))
		new.close()
		g.seek(pos+11)
	"""g.find('MSH')
	g.i(3)
	data=zlib.decompress(g.read(g.fileSize()-g.tell()))
	new=open(filename+'.dec','wb')
	new.write(data)
	new.close()"""
	g.tell()
	
	
def bmatParser(filename,g,mat):
	print filename
	start=g.tell()
	data=g.read(g.fileSize()-start)
	off=data.find('DiffuseMap')
	if off>0:
		g.seek(start+off+10)
		g.seek(30,1)
		mat.diffuse=g.dirname+os.sep+g.word(g.H(1)[0])+'.dds'
	off=data.find('DiffMap')
	if off>0:
		g.seek(start+off+7)
		g.seek(30,1)
		mat.diffuse=g.dirname+os.sep+g.word(g.H(1)[0])+'.dds'
		
		
	off=data.find('NormalMap')
	if off>0:
		g.seek(start+off+9)
		g.seek(30,1)
		mat.normal=g.dirname+os.sep+g.word(g.H(1)[0])+'.dds'
		
	off=data.find('SpecularMap')
	if off>0:
		g.seek(start+off+11)
		g.seek(52,1)
		mat.specular=g.dirname+os.sep+g.word(g.H(1)[0])+'.dds'
		
		
	
	
def bmatOpen(matName,dir):
	mat=Mat()
	mat.TRIANGLE=True
	matPath=dir+os.sep+matName+'.bmat'
	if 	os.path.exists(matPath)==True:
		file=open(matPath,'rb')
		g=BinaryReader(file)
		try:bmatParser(matPath,g,mat)
		except:pass
		file.close()
		
	return mat
	

def meshParser(filename,g):
	g.logOpen()
	#g.debug=True
	print g.H(g.i(1)[0])
	g.seek(0x18,1)
	
	meshCount=g.i(1)[0]
	print 'meshCount:',meshCount
	Start=g.tell()
	
	meshList=[]
	for i in range(meshCount):
		mesh=Mesh()
		meshList.append(mesh)
		mesh.TRIANGLE=True
		Unk1 = g.i(1)[0]
		Unk2 = g.i(1)[0]

		MByte = g.B(1)[0]
		mesh.name=g.word(g.H(1)[0])
		
		mat=bmatOpen(mesh.name,g.dirname)
		mesh.matList.append(mat)
		
		g.i(1)[0]
		
		VertCount = g.i(1)[0]	
		for m in range(VertCount):mesh.vertPosList.append(g.f(3))
		
		VertCount = g.i(1)[0]	
		g.seek(VertCount*12,1)
		VertCount = g.i(1)[0]	
		g.seek(VertCount*16,1)
		VertCount = g.i(1)[0]	
		g.seek(VertCount*12,1)
		
		VertCount = g.i(1)[0]	
		for m in range(VertCount):
			mesh.vertUVList.append(g.f(2))
			g.seek(4,1)
			
		VertCount = g.i(1)[0]	
		g.seek(VertCount*12,1)	
		VertCount = g.i(1)[0]	
		g.seek(VertCount*16,1)
		VertCount = g.i(1)[0]	
		print VertCount,g.tell()
		g.seek(VertCount*16,1)	
		print g.B(4),g.tell()
		
		VertCount = g.i(1)[0]	
		for m in range(VertCount):
			indiceList=[]
			weightList=[]
			for n in range(4):
				indiceList.append(g.i(1)[0])
				weightList.append(g.f(1)[0])
			mesh.skinIndiceList.append(indiceList)
			mesh.skinWeightList.append(weightList)	
		
		indiceCount=g.i(1)[0]
		mesh.indiceList=g.i(indiceCount)
		print g.tell()
		
	skeleton=Skeleton()
	skeleton.ARMATURESPACE=True
	a,b=g.i(2)	
	for i in range(a):
		g.B(1)
		bone=Bone()
		bone.name=g.word(g.H(1)[0])
		bone.matrix=Matrix4x4(g.f(16))
		g.i(1)
		skeleton.boneList.append(bone)
	skeleton.draw()	
	for mesh in meshList:
		skin=Skin()
		mesh.skinList.append(skin)
		mesh.boneNameList=skeleton.boneNameList
		mesh.BINDSKELETON='armature'		
		mesh.draw()
		
		
	g.tell()	
	g.logClose()
	
def anmParser(filename,g):
	action=Action()
	action.ARMATURESPACE=True
	#action.BONESPACE=True
	action.BONESORT=True
	action.skeleton='armature'
	g.logOpen()
	#g.debug=True
	A=g.i(16)
	print A
	g.seek(64)
	for i in range(87):
		bone=ActionBone()
		pos=g.tell()
		g.f(1)
		B=g.H(2)
		C=g.i(7)
		print i,B,C
		g.seek(A[9]+C[1])
		bone.name=g.find('\x00')
		
		g.seek(A[11]+C[2])
		g.logWrite('position')
		for j in range(B[0]):
			#g.H(4)
			bone.posFrameList.append(g.H(1)[0]/32)
			bone.posKeyList.append(VectorMatrix(g.short(3,'h',8)).invert())
			
		g.seek(A[11]+C[3])
		g.logWrite('rotation')
		for j in range(B[1]):
			bone.rotFrameList.append(g.H(1)[0]/32)
			bone.rotKeyList.append(QuatMatrix(g.short(4,'h',15)).invert().resize4x4())
		action.boneList.append(bone)
		g.seek(pos+36)
	print g.tell()	
	action.draw()
	action.setContext()
	g.logClose()
	
def boneTree(parent,n):
	global id
	n+=4
	for i in range(parent.childCount):
		child=skeleton.boneList[id]
		child.parentName=parent.name
		print '-'*n,id,child.name
		id+=1
		boneTree(child,n)
	
def o3dParser(filename,g):
	global skeleton,id
	g.logOpen()
	g.find('Node3D')
	
	skeleton=Skeleton()
	#skeleton.ARMATURESPACE=True
	skeleton.BONESPACE=True
	skeleton.NICE=True
	while(True):
		bone=Bone()
		g.logWrite('BONE-------------------------------------------')
		g.B(19)
		bone.name=g.word(g.H(1)[0])[-25:]
		pos=g.tell()
		g.B(10)
		
		g.B(1)
		x=g.f(1)[0]
		g.B(1)
		y=g.f(1)[0]
		g.B(1)
		z=g.f(1)[0]
		bone.posMatrix=VectorMatrix([x,y,z])
		print bone.posMatrix
		
		g.B(10)
		g.B(1)
		x=g.f(1)[0]
		g.B(1)
		y=g.f(1)[0]
		g.B(1)
		z=g.f(1)[0]
		bone.rotMatrix=Euler(x,y,z).toMatrix().resize4x4()
		
		g.B(10)
		g.B(1),g.f(1)
		g.B(1),g.f(1)
		g.B(1),g.f(1)
		A=g.B(22)
		bone.childCount=A[6]
		g.seek(pos+116-19)
		skeleton.boneList.append(bone)
		if A[11]!=7:break
	g.tell()
	g.logClose()
	for i,bone in enumerate(skeleton.boneList):
		bone.ID=i
	boneCount=len(skeleton.boneList)
	id=0
	n=0
	while(True):
		bone=skeleton.boneList[id]
		print id,bone.name
		id+=1
		boneTree(bone,n)
		if id==boneCount:break
		
	skeleton.draw()	
		
			
	
	
def Parser():	
	filename=input.filename
	imageList=input.imageList
	ext=filename.split('.')[-1].lower()	
	
	if ext=='oppc':
		file=open(filename,'rb')
		g=BinaryReader(file)
		oppcParser(filename,g)
		file.close()
	
	if ext=='meshpack':
		file=open(filename,'rb')
		g=BinaryReader(file)
		meshpackParser(filename,g)
		file.close()
	
	if ext=='mesh':
		file=open(filename,'rb')
		g=BinaryReader(file)
		meshParser(filename,g)
		file.close()
	
	if ext=='anm':
		file=open(filename,'rb')
		g=BinaryReader(file)
		anmParser(filename,g)
		file.close()
	
	if ext=='o3d':
		file=open(filename,'rb')
		g=BinaryReader(file)
		o3dParser(filename,g)
		file.close()
		
		
 
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
	 
Blender.Window.FileSelector(openFile,'import','oppc - file container, meshpack - mesh container, mesh - skinned mesh, o3d - skeleton')