// Main.cpp : Defines the entry point for the console application
//

#include "stdafx.h"

static unsigned long CheckInterleaved(std::istream& Input)
{
	unsigned long Sig;
	Input.read((char*)&Sig, 4);
	if(Sig!=3)
	{
		return 0;
	}

	Input.seekg(4, std::ios_base::cur);

	unsigned long SizeSum=0;

	for(unsigned long i=0;i<32;i++)
	{
		unsigned long NextSize;
		Input.read((char*)&NextSize, 4);
		std::streamoff CurOffset=Input.tellg();
		if(NextSize==0)
		{
			return 0;
		}
		if(NextSize>0xFFFFFFFF-CurOffset)
		{
			return 0;
		}
		SizeSum+=NextSize;
		if(SizeSum>0xFFFFFFFF-CurOffset)
		{
			return 0;
		}
		Input.seekg(CurOffset+SizeSum);

		Sig=0;
		Input.read((char*)&Sig, 4);
		if(Sig==3)
		{
			return i+1;
		}
		Input.seekg(CurOffset);
	}
	return 0;
}

static bool ProcessInterleaved(std::istream& Input, std::ostream& Output, unsigned char Channels)
{
	unsigned long NumberLayers=0;
	unsigned char Buffer[65536];
	while(!Input.eof())
	{
		std::streamoff OldPos=Input.tellg();
		Input.read((char*)Buffer, 65536);
		//Input.clear();
		std::streamoff NewPos=Input.tellg();
		std::streamsize Read=NewPos-OldPos;
		if(Read==0)
		{
			break;
		}
		for(std::streamoff i=0;i<Read;i++)
		{
			if(Buffer[i]==3)
			{
				if(Read-i>=4 && (Buffer[i+1]!=0 || Buffer[i+2]!=0 || Buffer[i+3]!=0))
				{
					continue;
				}
				Input.seekg(OldPos+i);
				NumberLayers=CheckInterleaved(Input);
				if(NumberLayers)
				{
					Input.seekg(OldPos+i);
					break;
				}
				Input.seekg(NewPos);
			}
		}
		if(NumberLayers)
		{
			break;
		}
	}

	if(!NumberLayers)
	{
		return false;
	}

	std::cerr << "Layers: " << NumberLayers << std::endl;

	// Add the header
	unsigned long Temp=0;
	Output.put(8);
	Output.write((char*)&Temp, 3);
	Output.write((char*)&Temp, 4);
	Output.put((unsigned char)NumberLayers);
	Output.write((char*)&Temp, 3);
	Output.put(254);
	Output.put(255);
	Output.put(255);
	Output.put(255);
	Output.write((char*)&Temp, 4);
	Output.write((char*)&Temp, 4);
	Output.write((char*)&Temp, 4);
	for(unsigned long i=0;i<NumberLayers;i++)
	{
		Output.put(28);
		Output.write((char*)&Temp, 3);
	}
	for(unsigned long i=0;i<NumberLayers;i++)
	{
		Output.put(5);
		Output.write((char*)&Temp, 3);
		Output.write((char*)&Temp, 4);
		Output.write((char*)&Temp, 4);
		Output.write((char*)&Temp, 2);
		Output.put(10);
		Output.put(0);
		Output.write((char*)&Temp, 4);
		Output.write((char*)&Temp, 4);
		Output.write((char*)&Temp, 4);
	}
	Output.put(3);
	Output.write((char*)&Temp, 3);
	Output.write((char*)&Temp, 4);
	for(unsigned long i=0;i<NumberLayers;i++)
	{
		Output.put(Channels==1 ? 20 : 40);
		Output.write((char*)&Temp, 3);
	}
	for(unsigned long i=0;i<NumberLayers;i++)
	{
		if(Channels==1)
		{
			for(unsigned long i=0;i<10;i++)
			{
				Output.write((char*)&Temp, 2);
			}
		}
		else if(Channels==2)
		{
			for(unsigned long i=0;i<10;i++)
			{
				Output.write((char*)&Temp, 4);
			}
		}
	}
	return true;
}

static bool ProcessSimple(std::istream& Input, std::ostream& Output, unsigned char Channels)
{
	std::streamoff StartOffset=Input.tellg();
	// If the chunk is valid don't write a header
	unsigned char Char[28];
	bool ChunkValid=false;

	// Read in the characters
	Input.read((char*)Char, 28);

	// Check the characters
	if(Char[0]==5 && Char[9]==0 && Char[10]==0 && Char[11]==0 && Char[18]<89 && \
		/*(Char[19]==0 || Char[19]==119) &&*/ Char[22]<89 /*&& Char[23]<5*/)
	{
		ChunkValid=true;
	}

	// Check some other conditions
	if(ChunkValid && (Char[0]==3))
	{
		if(Char[14]!=0 || Char[15]!=10)
		{
			ChunkValid=false;
		}
	}
	else if(ChunkValid && (Char[0]==5))
	{
		if(Char[14]!=10 || Char[15]!=0)
		{
			ChunkValid=false;
		}
	}

	Input.seekg(StartOffset);

	// If the chunk is not valid
	if(!ChunkValid)
	{
		unsigned long Temp=0;
		Output.put(5);
		Output.write((char*)&Temp, 3);
		Output.write((char*)&Temp, 4);
		Output.write((char*)&Temp, 4);
		Output.write((char*)&Temp, 2);
		Output.put(10);
		Output.put(0);
		Output.write((char*)&Temp, 4);
		Output.write((char*)&Temp, 4);
		Output.write((char*)&Temp, 4);
		if(Channels==1)
		{
			for(unsigned long i=0;i<10;i++)
			{
				Output.write((char*)&Temp, 2);
			}
		}
		else if(Channels==2)
		{
			for(unsigned long i=0;i<10;i++)
			{
				Output.write((char*)&Temp, 4);
			}
		}
	}
	return true;
}

int _tmain(int Argc, _TCHAR* Argv[])
{
	if(Argc<4)
	{
		std::cerr << "Usage: AddUbiHeader InputFile OutputFile Channels [Offset (default 36)]" << std::endl << std::endl;
		return 1;
	}

	// The infomation from the command line
	std::string InputFilename(Argv[1]);
	std::string OutputFilename(Argv[2]);
	unsigned char Channels=atoi(Argv[3]);
	std::streamoff InputOffset=36;

	if(Argc>4)
	{
		InputOffset=atoi(Argv[4]);
	}

	if(Channels<1 || Channels>2)
	{
		std::cerr << "Invalid number of channels" << std::endl;
		return 1;
	}

	// Open the input file
	std::ifstream Input;
	Input.open(InputFilename.c_str(), std::ios_base::in | std::ios_base::binary);
	if(!Input.is_open())
	{
		std::cerr << "Unable to open input file '" << InputFilename << "'." << std::endl;
		return 2;
	}

	// Open the output file
	std::ofstream Output;
	Output.open(OutputFilename.c_str(), std::ios_base::out | std::ios_base::trunc | std::ios_base::binary);
	if(!Output.is_open())
	{
		std::cerr << "Unable to open output file '" << OutputFilename << "'." << std::endl;
		return 3;
	}

	std::cerr << "Searching for interleaved stream..." << std::endl;
	Input.seekg(InputOffset);
	if(!ProcessInterleaved(Input, Output, Channels))
	{
		std::cerr << "Searching for simple stream..." << std::endl;
		Input.clear();
		Input.seekg(InputOffset);
		if(!ProcessSimple(Input, Output, Channels))
		{
			return 4;
		}
	}

	// Write the rest of the file
	std::cerr << "Writing the rest of the file..." << std::endl;
	unsigned char Buffer[65536];
	while(!Input.eof())
	{
		std::streamoff OldPos=Input.tellg();
		Input.read((char*)Buffer, 65536);
		std::streamsize Read=Input.tellg()-OldPos;
		if(Read==0)
		{
			break;
		}
		Output.write((char*)Buffer, Read);
	}

	// Clean up
	Input.close();
	Output.close();
	return 0;
}
