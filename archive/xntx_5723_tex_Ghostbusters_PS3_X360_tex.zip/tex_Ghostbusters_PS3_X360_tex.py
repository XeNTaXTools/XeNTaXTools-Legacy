from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Ghostbusters (X360 & PS3)", ".tga;.tex")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
	#noesis.logPopup()
	return 1

#check if it's this type based on the data
def noepyCheckType(data):
    bs = NoeBitStream(data)
    Magic = bs.readInt()
    if Magic != 7:
        return 0
    return 1
	
def noepyLoadRGBA(data, texList):
    datasize = len(data) - 0x34        
    bs = NoeBitStream(data)
    fileName = rapi.getLocalFileName(rapi.getInputName()) #get file name & ext without path
    bs.seek(0x18, NOESEEK_ABS)
    imgFmt = bs.readInt()
    imgWidth = bs.readInt()           
    imgHeight = bs.readInt()          
    if ".tga" in fileName:
        imgWidth = imgWidth // 2           
        imgHeight = imgHeight // 2          
    bs.seek(0x34, NOESEEK_ABS)        
    data = bs.readBytes(datasize)      
    if imgFmt == 0x28:
        data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 8)
        texFmt = noesis.NOESISTEX_DXT1
    elif imgFmt == 0x30:
        pass
        noesis.logPopup()
        print("\n" "bump textures (0x30) are unsupported at this time" "\n")
    elif imgFmt == 0x34 or imgFmt == 0x32:
        texFmt = noesis.NOESISTEX_DXT5
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1