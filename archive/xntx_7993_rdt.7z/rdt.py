import collections
import io
import struct


def align(ins, size):
    rem = ins.tell() % size
    if rem != 0:
        ins.read(size - rem)


def peek(ins, size):
    data = ins.read(size)
    ins.seek(-size, io.SEEK_CUR)
    return data


def verify_chunk_id(chunk_id, archive_id):
    # The least significant nibble of a chunk id is either the archive id,
    # or 1.
    if chunk_id & 15 not in (1, archive_id):
        raise ValueError('Bad chunk id')


class ChunkHeader:
    def __init__(self, ins, archive_id):
        self.chunk_id, self.size, self.zero, self.type, num_extras = \
            struct.unpack('<5L', ins.read(20))
        verify_chunk_id(self.chunk_id, archive_id)
        # These - sometimes? - seem to be links from one chunk within
        # an RDA2 directory to other chunks in that directory, by index
        # in its chunk_ids list.
        self.extras = [struct.unpack('<L', ins.read(4))[0]
                       for _ in range(num_extras)]

    def __str__(self):
        return f'ChunkHeader(id=0x{self.chunk_id:08X}, type=0x{self.type:X})'


class RDA2Chunk:
    def __init__(self, ins, archive_id):
        # Payload size is the sum of sizes of all referenced chunks.
        magic, count, self.payload_size = struct.unpack('<8s2L', ins.read(16))
        assert magic == b'RDA2   \0'
        self.table = struct.unpack('<20000L', ins.read(80000))
        # Verify trailing zero entries are indeed zero then throw them away:
        assert all(n == 0 for n in self.table[count:])
        self.chunk_ids = self.table[:count]
        # Verify all chunk ids:
        for chunk_id in self.chunk_ids:
            verify_chunk_id(chunk_id, archive_id)


class RDTFile:
    def __init__(self, filename, archive_id):
        with open(filename, 'rb') as inf:
            data = inf.read()

        ins = io.BytesIO(data)

        # Load all chunks sequentially, ignoring substructure for now:
        self.chunks = []  # list of (ChunkHeader, RDA2Chunk|bytes)
        while ins.tell() < len(data):
            header = ChunkHeader(ins, archive_id)
            if peek(ins, 4) == b'RDA2':
                payload = RDA2Chunk(ins, archive_id)
            else:
                payload = ins.read(header.size)
            self.chunks.append((header, payload))
            align(ins, 4)  # dword aligned


# Let's do some simple tests


res = RDTFile('res.rdt', 5)
disk1 = RDTFile('disk1.rdt', 9)
disk2 = RDTFile('disk2.rdt', 13)

chunks_by_id = {}
for archive in (res, disk1, disk2):
    for header, payload in archive.chunks:
        chunks_by_id[header.chunk_id] = (header, payload)


# File stats:
print('Chunk count for res:', len(res.chunks))
print('Chunk count for disk1:', len(disk1.chunks))
print('Chunk count for disk2:', len(disk2.chunks))

# Test for all those empty 16-byte "link" chunks:
links = [chunk for chunk in res.chunks
         if isinstance(chunk[1], bytes)
         and all(c == 0 for c in chunk[1])]
print('res empty link count:', len(links))


# Random test: fullscreen images seem to have size 0x96000, so let's
# see how many there are:
fullscreens = []
for archive in (res, disk1, disk2):
    for header, payload in archive.chunks:
        if header.size == 0x96000:
            fullscreens.append(header.chunk_id)
print('full screens:', len(fullscreens))


# Collect all type fields in the ChunkHeaders:
all_types = []
for archive in (res, disk1, disk2):
    for header, payload in archive.chunks:
        all_types.append(header.type)
print('Header type fields and their frequencies:')
for k, v in collections.Counter(all_types).items():
    print(hex(k), v)

