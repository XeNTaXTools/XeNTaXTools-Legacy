from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("game?", ".xmesh")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)
    noesis.logPopup()
    return 1
       
def noepyCheckType(data):
    if len(data) < 0x80:
        return 0
    bs = NoeBitStream(data)
    Tag = bs.readInt64()
    if Tag != 281487861612561:
        return 0
    return 1
    
meshes = []
bones = []
animList = []
UVs_type = 0

def noepyLoadModel(data, mdlList):
    global meshes, bones
    meshes, bones, animList = [], [], []
    bs = NoeBitStream(data)
    header = bs.readInt64()
    lenName = bs.readInt()
    Name = noeAsciiFromBytes(bs.readBytes(lenName))
    sizeFile = bs.readInt()#end offset
    unk0 = [bs.readInt() for x in range(9)]
    bs.seek(0x18, NOESEEK_REL)
    unk1 = bs.readInt()
    bone_count = bs.readInt()
    
    print("bones:", bone_count, "Start", bs.getOffset())
    bones = []
    for x in range(bone_count):
        len_bName = bs.readInt()
        nameBone = noeAsciiFromBytes(bs.readBytes(len_bName))
        parent = bs.readInt()
        pos = NoeVec3.fromBytes(bs.readBytes(12));
        rot = NoeAngles.fromBytes(bs.readBytes(12));
        scl = NoeVec3.fromBytes(bs.readBytes(12));
        bs.seek(0x1, NOESEEK_REL)
        mat = rot.toMat43()
        mat[3] = pos
        for i in range(3):
            mat[i][i] = scl[i]
        bones.append(NoeBone(len(bones), nameBone, mat , None, parent))
        #print(bones[-1])
    print("end bones/",bs.getOffset())    
    checkType(bs)

    mdl = NoeModel(meshes)
    mdl.setBones(bones)
    #mdl.setAnims(animList)
    mdl.setModelMaterials(NoeModelMaterials([], [NoeMaterial("default","")]))
    mdlList.append(mdl)
    return 1
    
def checkType(bs):
    type = bs.readInt()
    print(type,bs.getOffset())
    if type == 1040 or type == 21 or type == 1104:
        checkType(bs)
    elif type == 1041 or type == 1042 or type == 1105 or type == 1106:
        skipName(bs)
    elif type == 1043:#add
        bs.seek(0x140, NOESEEK_REL)
        checkType(bs)
    elif type == 1107:#add
        bs.seek(0x120, NOESEEK_REL)
        checkType(bs)
    elif type == 262:
        skipName(bs)
    elif type == 277:
        lenString = bs.readInt()
        string = noeAsciiFromBytes(bs.readBytes(lenString))
        bs.seek(32, NOESEEK_REL)
        checkType(bs)
    elif type == 288:
        skipName(bs)
    elif type == 289:
        bs.seek(1, NOESEEK_REL)
        checkType(bs)
    elif type == 256:
        skipName(bs)
    elif type == 257:
        skipName(bs)
    elif type == 286:
        type286(bs)
    elif type == 515:
        create_mesh(bs)
    elif type == 17:#anim
        create_anim(bs)
    elif type == 2771:
        skipName(bs)
    return 1
    
def skipName(bs):
    lenString = bs.readInt()
    string = noeAsciiFromBytes(bs.readBytes(lenString))
    
    checkType(bs)
    return 1
    
def type286(bs):
    global UVs_type
    print("Unk 286 Start:",bs.getOffset())
    bs.seek(0x25, NOESEEK_REL)
    print(bs.getOffset(),bs.getSize())
    size = bs.getSize()
    while bs.getOffset() < size:
        if bs.readUByte() == 35:
            if bs.readUInt() == 1:
                print("end unk/",bs.getOffset())
                bs.seek(-6, NOESEEK_REL)
                UVs_type = bs.readUByte()
                print("###################UVs_type????",UVs_type)
                bs.seek(5, NOESEEK_REL)
                checkType(bs)
                break
            else:
                bs.seek(-4, NOESEEK_REL)
    return 1
    
def create_mesh(bs):
    global meshes
    print("Create_mesh Start:",bs.getOffset())
    count = bs.readInt()

    print("UVs",count,"Start:",bs.getOffset())
    UVs = []
    for x in range(count):
        UVs.append(NoeVec3([bs.readFloat(),bs.readFloat()]+[0]))
        bs.seek(8, NOESEEK_REL)
        if UVs_type == 1:
            bs.seek(4, NOESEEK_REL)
    
    
    f_type = bs.readInt()#517
    f_count = bs.readInt()*3
    
    print("Face",f_count,"Start:",bs.getOffset())
    face = [bs.readInt() for x in range(f_count)]
    
    v_type = bs.readInt()#519
    v_count = int(bs.readInt()/3)
    print("Vert",v_count,"Start:",bs.getOffset())
    
    vert = []
    weight = []

    for x in range(v_count):
        #weight
        bId, bW = [], []
        bId += [bs.readInt()]
        bW += [bs.readFloat()]
        bs.seek(12, NOESEEK_REL)
        bId += [bs.readInt()]
        bW += [bs.readFloat()]
        bs.seek(12, NOESEEK_REL)
        bId += [bs.readInt()]
        bW += [bs.readFloat()]
        weight.append(NoeVertWeight(bId, bW))

        v = NoeVec3.fromBytes(bs.readBytes(12))
        
        #for bi in bId:
            #v *= bones[bi].getMatrix();
        vert.append(v)

    mesh = NoeMesh(face,vert,"mesh_"+str(len(meshes)))
    #mesh.setNormals(normal)
    mesh.setUVs(UVs)
    mesh.setWeights(weight)
    meshes.append(mesh)
    print(meshes[-1])
    print("END create_mesh",bs.getOffset())
    checkType(bs)
    return 1
    
def create_anim(bs):
    unk = bs.readInt()
    lenName = bs.readInt()
    name = noeAsciiFromBytes(bs.readBytes(lenName))
    
    size = bs.readInt()
    unk = [bs.readInt() for x in range(9)]
    frame_count = unk[3]
    
    bs.seek((len(bones)*4)+5, NOESEEK_REL)#parent

    print("Anim",name,"Start:",bs.getOffset())
    print("frame count:",frame_count)
    
    AnimMat = []
    for x in range(frame_count):
        type_anim = bs.readInt()#35
        frame_index = bs.readInt()
        for y in range(len(bones)):
            #rot = NoeQuat.fromBytes(bs.readBytes(16))
            
            rot = NoeAngles.fromBytes(bs.readBytes(12))
            pos = NoeVec3.fromBytes(bs.readBytes(12))
            bs.seek(4, NOESEEK_REL)
            scl = NoeVec3.fromBytes(bs.readBytes(12))
            
            mat = rot.toMat43()
            mat[3] = pos
            for i in range(3):
                mat[i][i] = scl[i]
            AnimMat.append(mat)
    print("END animations",bs.getOffset())
        
    noeAnim = NoeAnim(name, bones, frame_count, AnimMat, 30.0)
    global animList
    animList.append(noeAnim)
    return 1