from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("EA Skate 3 PSG (1.1) [PS3]", ".psg")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
	#noesis.logPopup()
	return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    Magic = bs.readBytes(7)
    if Magic != b'\x89\x52\x57\x34\x70\x73\x33':
        return 0
    return 1
	
def noepyLoadRGBA(data, texList):
    datasize = len(data) - 0x248
    bs = NoeBitStream(data)
    bs.setEndian(NOE_BIGENDIAN)
    bs.seek(0x15C, NOESEEK_ABS)
    imgFmt = bs.readUByte()
    print(imgFmt, "imgFmt")
    bs.seek(0x164, NOESEEK_ABS)
    imgWidth = bs.readUShort()
    imgHeight  = bs.readUShort()
    bs.seek(0x248, NOESEEK_ABS)        
    data = bs.readBytes(datasize)
    #DXT1
    if imgFmt == 0xA6 or imgFmt == 0x86:
        texFmt = noesis.NOESISTEX_DXT1
    #DXT3
    elif imgFmt == 0x87:
        texFmt = noesis.NOESISTEX_DXT3
    #DXT5
    elif imgFmt == 0x88:
        texFmt = noesis.NOESISTEX_DXT5
    #RGBA8888
    elif imgFmt == 0xa5:
        texFmt = noesis.NOESISTEX_RGBA32
    #unknown, not handled
    else:
        print("WARNING: Unhandled image format")
        return None

    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1
