from struct import *
from BodyShopUtils import *

fileNameSource = 'source.TMC'               #<-- Change this to the TMC you want to change
fileNameTarget = 'target.TMC'               #<-- Change this to the TMC that has the values to use

sourceFile = open(fileNameSource,'rb')
targetFile = open(fileNameTarget,'rb')

sourceBoneNames = ReadBoneNamesToArray(sourceFile)
targetBoneNames = ReadBoneNamesToArray(targetFile)

###########
#Data Reads
###########

#LHeaderOffset - Source
sourceFile.seek(348)
lHeaderOffsetSource = ConvertByteStringToInt(sourceFile.read(4))

#LHeaderOffset - Target
targetFile.seek(348)
lHeaderOffsetTarget = ConvertByteStringToInt(targetFile.read(4))

#cplOffset - source
sourceFile.seek(364)
cplOffsetSource = ConvertByteStringToInt(sourceFile.read(4))

#HieLayOffset - Source
sourceFile.seek(344)
hieLayOffsetSource = ConvertByteStringToInt(sourceFile.read(4))
sourceFile.seek(hieLayOffsetSource + 20)
hieLayCountSource = ConvertByteStringToInt(sourceFile.read(4))

sourceFile.seek(hieLayOffsetSource + 48)
hieLayIndexBytesSource = sourceFile.read(hieLayCountSource * 4)
hieLayIndexByteArraySource = ConvertChunkToByteArray(hieLayIndexBytesSource)
hieLayIndexByteArrayBESource = FlipData(hieLayIndexByteArraySource, 4, True)
hieLayIndexIntSource = ConvertByteArrayToIntArray(hieLayIndexByteArrayBESource)

hieLayDataBytesSource = []

#HieLayData - Source
hieLayCounter = 0
for offset in hieLayIndexIntSource:

    if ((hieLayCounter + 1) == len(hieLayIndexIntSource)):
        lengthOffset = lHeaderOffsetSource
    else:
        lengthOffset = hieLayOffsetSource + hieLayIndexIntSource[hieLayCounter + 1]

    sourceFile.seek(hieLayOffsetSource + offset)
    length = lengthOffset - (hieLayOffsetSource + offset)
    hieLayDataBytesSource.append(sourceFile.read(length))
    hieLayCounter += 1
    

#HieLayOffset - Target
targetFile.seek(344)
hieLayOffsetTarget = ConvertByteStringToInt(targetFile.read(4))
targetFile.seek(hieLayOffsetTarget + 20)
hieLayCountTarget = ConvertByteStringToInt(targetFile.read(4))

targetFile.seek(hieLayOffsetTarget + 48)
hieLayIndexBytesTarget = targetFile.read(hieLayCountTarget * 4)
hieLayIndexByteArrayTarget = ConvertChunkToByteArray(hieLayIndexBytesTarget)
hieLayIndexByteArrayBETarget = FlipData(hieLayIndexByteArrayTarget, 4, True)
hieLayIndexIntTarget = ConvertByteArrayToIntArray(hieLayIndexByteArrayBETarget)

hieLayDataBytesTarget = []

#HieLayData - Target
hieLayCounter = 0
for offset in hieLayIndexIntTarget:

    if ((hieLayCounter + 1) == len(hieLayIndexIntTarget)):
        lengthOffset = lHeaderOffsetTarget
    else:
        lengthOffset = hieLayOffsetTarget + hieLayIndexIntTarget[hieLayCounter + 1]
    
    targetFile.seek(hieLayOffsetTarget + offset)
    length = lengthOffset - (hieLayOffsetTarget + offset)
    hieLayDataBytesTarget.append(targetFile.read(length))
    hieLayCounter += 1
    
#BnOfsMtx - Source
sourceFile.seek(360)
bnOfsMtxOffsetSource = ConvertByteStringToInt(sourceFile.read(4))
sourceFile.seek(bnOfsMtxOffsetSource + 20)
bnOfsMtxCountSource = ConvertByteStringToInt(sourceFile.read(4))

sourceFile.seek(bnOfsMtxOffsetSource + 48)
bnOfsMtxIndexBytesSource = sourceFile.read(bnOfsMtxCountSource * 4)
bnOfsMtxIndexByteArraySource = ConvertChunkToByteArray(bnOfsMtxIndexBytesSource)
bnOfsMtxIndexByteArrayBESource = FlipData(bnOfsMtxIndexByteArraySource, 4, True)
bnOfsMtxIndexIntSource = ConvertByteArrayToIntArray(bnOfsMtxIndexByteArrayBESource)

bnOfsMtxDataBytesSource = []

#BnOfsMtxData - Source
for offset in bnOfsMtxIndexIntSource:
    sourceFile.seek(bnOfsMtxOffsetSource + offset)
    bnOfsMtxDataBytesSource.append(sourceFile.read(64))

#BnOfsMtx - Target
targetFile.seek(360)

bnOfsMtxOffsetTarget = ConvertByteStringToInt(targetFile.read(4))
targetFile.seek(bnOfsMtxOffsetTarget + 20)
bnOfsMtxCountTarget = ConvertByteStringToInt(targetFile.read(4))

targetFile.seek(bnOfsMtxOffsetTarget + 48)
bnOfsMtxIndexBytesTarget = targetFile.read(bnOfsMtxCountTarget * 4)
bnOfsMtxIndexByteArrayTarget = ConvertChunkToByteArray(bnOfsMtxIndexBytesTarget)
bnOfsMtxIndexByteArrayBETarget = FlipData(bnOfsMtxIndexByteArrayTarget, 4, True)
bnOfsMtxIndexIntTarget = ConvertByteArrayToIntArray(bnOfsMtxIndexByteArrayBETarget)

bnOfsMtxDataBytesTarget = []

#BnOfsMtxData - Source
for offset in bnOfsMtxIndexIntTarget:
    targetFile.seek(bnOfsMtxOffsetTarget + offset)
    bnOfsMtxDataBytesTarget.append(targetFile.read(64))

###########
#Processing
###########

hieLayCounter = 0
hieLayBytesModified = []

for offset in hieLayIndexIntSource:

    #HieLay have Variables Lengths
    #If next value does not exceed array length
    #Use next value as length offset
    #Else
    #Use lHeader value as length offset
    if ((hieLayCounter + 1) == len(hieLayIndexIntSource)):
        lengthOffset = lHeaderOffsetSource
    else:
        lengthOffset = hieLayOffsetSource + hieLayIndexIntSource[hieLayCounter + 1]

    sourceFile.seek(hieLayOffsetSource + offset)
    length = lengthOffset - (hieLayOffsetSource + offset)
    hieLay = sourceFile.read(length)

    boneNameSource = sourceBoneNames[hieLayCounter]['boneName']

    #Only Change if OPT or MOT
    if (boneNameSource[0:3] != 'WGT'):
        boneTargetId = ReturnMatchingBoneNameIndex(boneNameSource, targetBoneNames)
        hieLayTarget = hieLayDataBytesTarget[boneTargetId][0:64]

        #First 64 Bytes from Target + Remainder from Source
        hieLayModified = hieLayTarget + hieLay[64:]
    else:
        hieLayModified = hieLay

    #Array of Modified Values
    hieLayBytesModified.append(hieLayModified)
    
    hieLayCounter += 1

bnOfsMtxCounter = 0
bnOfsMtxBytesModified = []

for offset in bnOfsMtxIndexIntSource:

    sourceFile.seek(bnOfsMtxOffsetSource + offset)

    bnOfsMtx = sourceFile.read(64)

    boneNameSource = sourceBoneNames[bnOfsMtxCounter]['boneName']

    #Only Change if OPT or MOT
    if (boneNameSource[0:3] != 'WGT'):
        boneTargetId = ReturnMatchingBoneNameIndex(boneNameSource, targetBoneNames)
        bnOfsMtxModified = bnOfsMtxDataBytesTarget[boneTargetId][0:64]
    else:
        bnOfsMtxModified = bnOfsMtx

    #Array of Modified Values
    bnOfsMtxBytesModified.append(bnOfsMtxModified)
    
    bnOfsMtxCounter += 1


#######
#Output
#######
    
hieLayStart = hieLayOffsetSource + hieLayIndexIntSource[0]
bnOfsMtxStart = bnOfsMtxOffsetSource + bnOfsMtxIndexIntSource[0]

sourceFile.seek(0)
fileModifiedHead = sourceFile.read(hieLayStart)

fileModifiedMiddle1 = b''

for hieLayModified in hieLayBytesModified:
    fileModifiedMiddle1 = fileModifiedMiddle1 + hieLayModified

#Complete Read from end of HieLay to Start of BnOfsMtxData
hieLayEnd = lHeaderOffsetSource
sourceFile.seek(hieLayEnd)
fileModifiedMiddle2 = sourceFile.read(bnOfsMtxStart - hieLayEnd)

fileModifiedMiddle3 = b''

for bnOfsMtxModified in bnOfsMtxBytesModified:
    fileModifiedMiddle3 = fileModifiedMiddle3 + bnOfsMtxModified

#Read from BnOfsMtx End to End of File
bnOfsMtxEnd = cplOffsetSource
sourceFile.seek(bnOfsMtxEnd)

fileModifiedTail = sourceFile.read(ReturnFileSize(fileNameSource) - cplOffsetSource)

fileBytesOut = fileModifiedHead
fileBytesOut += fileModifiedMiddle1
fileBytesOut += fileModifiedMiddle2
fileBytesOut += fileModifiedMiddle3
fileBytesOut += fileModifiedTail

WriteBytesToFile(fileBytesOut,fileNameSource,'patched','TMC')


########
#Cleanup
########

sourceFile.close()
targetFile.close()
