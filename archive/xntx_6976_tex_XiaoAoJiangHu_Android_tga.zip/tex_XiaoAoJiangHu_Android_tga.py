from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Xiao_Ao_Jiang_Hu [Android]", ".tga")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)

    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    
    if bs.readBytes(4) != b'\x45\x52\x41\x00':
        return 0
    else:
        return 1
    
def noepyLoadRGBA(data, texList):
    block_formats = [
        (4, 4, 1),   # 0
        (5, 4, 1),   # 1
        (5, 5, 1),   # 2
        (6, 5, 1),   # 3
        (6, 6, 1),   # 4
        (8, 5, 1),   # 5
        (8, 6, 1),   # 6
        (8, 8, 1),   # 7
        (10, 5, 1),  # 8
        (10, 6, 1),  # 9
        (10, 8, 1),  # 10
        (10, 10, 1), # 11
        (12, 10, 1), # 12
        (12, 12, 1), # 13
        (3, 3, 3),   # 14
        (4, 3, 3),   # 15
        (4, 4, 3),   # 16
        (4, 4, 4),   # 17
        (5, 4, 4),   # 18
        (5, 5, 4),   # 19
        (5, 5, 5),   # 20
        (6, 5, 5),   # 21
        (6, 6, 5),   # 22
        (6, 6, 6)    # 23
        ]
    
    bs = NoeBitStream(data)
    bs.seek(0x4)
    
    width = bs.readUInt()  # x
    height = bs.readUInt() # y
    depth = bs.readUInt()  # z
    
    mips = bs.readUInt()
    x_tiles = bs.readUInt()
    y_tiles = bs.readUInt()
    pixel_format = bs.readUInt()
    flags = bs.readUInt()
    unk = bs.readUInt()
    block_type = bs.readUInt()
    bs.seek(0xA8)
    
    block_x, block_y, block_z = block_formats[block_type]
    
    if flags & 1:
        faces_count = 6 # cubemap
    else:
        faces_count = x_tiles * y_tiles # atlas
    
    assert((bs.getSize() - 0xA8) % faces_count == 0)
    
    face_start = 0xA8 # Skip header
    face_size = 16 * ((width + block_x - 1) // block_x) * \
                     ((height + block_y - 1) // block_y) * \
                     ((depth + block_z - 1) // block_z) # 0-mip size
    face_offset = (bs.getSize() - 0xA8) // faces_count # all mips of face
    
    for i in range(faces_count):
        bs.seek(face_start + i * face_offset)
        data = bs.readBytes(face_size)
        data = rapi.callExtensionMethod("astc_decoderaw32", data,
                                        block_x, block_y, block_z,
                                        width, height, depth)
        texList.append(NoeTexture(rapi.getInputName(),
                                  width, height,
                                  data, noesis.NOESISTEX_RGBA32))
    
    return 1

