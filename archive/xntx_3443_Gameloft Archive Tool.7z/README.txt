Usage:

Load in a gameloft archive (.gla) and hit extract!

