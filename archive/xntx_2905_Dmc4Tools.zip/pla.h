
#ifndef _PLA_H
#define _PLA_H

#include "main.h"

//+-----------------------------------------------------------> Defines

#define PLA_TYPE_ROOT			0x00000001
#define PLA_TYPE_ENTRY			0x00000004
#define PLA_TYPE_BOOL			0x00000006
#define PLA_TYPE_INT			0x00000007
#define PLA_TYPE_FLOAT			0x00000008
#define PLA_TYPE_VEC3			0x00000009
#define PLA_TYPE_INT2			0x0000000A
#define PLA_TYPE_FILENAME		0x0000000B

//+-----------------------------------------------------------> cPlaHeader

struct cPlaHeader
{
	unsigned int				uiTag;			// 0x00414C50, 'PLA'
	unsigned short				usVersion;		// 17
	unsigned short				usEntryNum;
	unsigned int				uiInconnu;		// zero
	unsigned int				uiNameTableOffset;
};

//+-----------------------------------------------------------> cPlaEntry

struct cPlaEntry
{
	unsigned int				uiType;
	unsigned int				uiInconnu;		// ??
	unsigned int				uiParent;		// only valid if the entry is not root
	unsigned int				uiAttrib;		// for parent entries: 9, the rest is 0
	unsigned int				uiNameOffset;	// relative to name bloc start
	unsigned int				uiId;			// valid only for sub entries
	unsigned int				uiDataOffset;	// related data offset (absolute)
};

//+-----------------------------------------------------------> 

bool ProcessPla(const char *strPla);

#endif