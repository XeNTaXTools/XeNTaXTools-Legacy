
#include "pla.h"

//+-----------------------------------------------------------> ProcessPla()

bool ProcessPla(const char *strPla)
{
	// open the file
	FILE *pFile = fopen(strPla, "rb");
	if(!pFile)
	{
		printf("Can't open PLA file [%s] !\n", strPla);
		return false;
	}

	// read the header
	cPlaHeader hdr;
	fread(&hdr, sizeof(cPlaHeader), 1, pFile);
	if(hdr.uiTag != 0x00414C50)
	{
		printf("Invalid PLA file [%s] !\n", strPla);
		return false;
	}

	// create the output file
	char strFile[128] = {0};
	sprintf(strFile, "%s.txt", strPla);
	FILE *bFile = fopen(strFile, "wt");

	// read the entries
	cPlaEntry *pEntry = new cPlaEntry[hdr.usEntryNum];
	fread(pEntry, sizeof(cPlaEntry), hdr.usEntryNum, pFile);

	// this is to keep track on the parent/child struct when outputing data
	char *pTab = new char[hdr.usEntryNum];

	// go through all the entries and read them
	for(unsigned short a = 0; a < hdr.usEntryNum; a++)
	{
		char strEntryName[128] = {0};

		// read the entry name
		fseek(pFile, hdr.uiNameTableOffset + pEntry[a].uiNameOffset, SEEK_SET);
		ReadString(pFile, strEntryName);

		// set the tab info
		pTab[a] = 0;
		if(pEntry[a].uiParent)
		{
			pTab[a]++;
			pTab[a] += pTab[pEntry[a].uiParent];
		}
		if(a && (pTab[a] > pTab[a - 1]))
		{
			for(unsigned short b = 0; b < pTab[a] - 1; b++)
				fprintf(bFile, "\t");
			fprintf(bFile, "{\n");
		}
		else if(a && (pTab[a] < pTab[a - 1]))
		{
			for(unsigned short b = 0; b < pTab[a]; b++)
				fprintf(bFile, "\t");
			fprintf(bFile, "}\n");
		}
		for(unsigned short b = 0; b < pTab[a]; b++)
			fprintf(bFile, "\t");

		int i = 0;
		float f = 0.0f;
		D3DXVECTOR3 v3;
		char strData[64] = {0};
		if(pEntry[a].uiDataOffset)
		{
			fseek(pFile, pEntry[a].uiDataOffset, SEEK_SET);
			switch(pEntry[a].uiType)
			{

			case PLA_TYPE_BOOL:
				{
					fread(&i, 4, 1, pFile);
					if(i)
						fprintf(bFile, "%s: true\n", strEntryName);
					else
						fprintf(bFile, "%s: false\n", strEntryName);
				}
				break;
			case PLA_TYPE_INT:
			case PLA_TYPE_INT2:
				{
					fread(&i, 4, 1, pFile);
					fprintf(bFile, "%s: %d\n", strEntryName, i);
				}
				break;

			case PLA_TYPE_FLOAT:
				{
					fread(&f, 4, 1, pFile);
					fprintf(bFile, "%s: %f\n", strEntryName, f);
				}
				break;

			case PLA_TYPE_VEC3:
				{
					fread(&v3, 12, 1, pFile);
					fprintf(bFile, "%s: %f %f %f\n", strEntryName, v3.x, v3.y, v3.z);
				}
				break;

			case PLA_TYPE_FILENAME:
				{
					// read the extension and filename
					fread(&i, 4, 1, pFile);
					fseek(pFile, hdr.uiNameTableOffset + i, SEEK_SET);
					fread(&i, 4, 1, pFile);
					ReadString(pFile, strData);
					fprintf(bFile, "%s: %s\n", strEntryName, strData);
				}
				break;

			default:
				{
					printf("Yet this is an unknown type [%s: %d] !\n", strEntryName, pEntry[a].uiType);
					return false;
				}
				break;
			}
		}
		else
			fprintf(bFile, "%s\n", strEntryName);
	}

	// we're done here !!
	delete[] pTab;
	pTab = NULL;
	delete[] pEntry;
	pEntry = NULL;
	fclose(bFile);
	fclose(pFile);
	return true;
}