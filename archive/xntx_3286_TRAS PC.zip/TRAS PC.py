#Noesis Python model import+export test module, imports/exports some data from/to a made-up format

from inc_noesis import *

import noesis
#rapi methods should only be used during handler callbacks
import rapi


#registerNoesisTypes is called by Noesis to allow the script to register formats.
#Do not implement this function in script files unless you want them to be dedicated format modules!
def registerNoesisTypes():
   handle = noesis.register("Tomb Raider 2013 [PC]", ".mesh")
   noesis.setHandlerTypeCheck(handle, noepyCheckType)
   noesis.setHandlerLoadModel(handle, noepyLoadModel) #see also noepyLoadModelRPG
       #noesis.setHandlerWriteModel(handle, noepyWriteModel)
       #noesis.setHandlerWriteAnim(handle, noepyWriteAnim)
   noesis.logPopup()
       #print("The log can be useful for catching debug prints from preview loads.\nBut don't leave it on when you release your script, or it will probably annoy people.")
   return 1

NOEPY_HEADER = ""

#check if it's this type based on the data
def noepyCheckType(data):
	bs = NoeBitStream(data)
	FILE_VER = bs.readInt()
	if FILE_VER != 0x06:
		print("Unsupported Version")
		return 0     
	return 1

#load the model
def noepyLoadModel(data, mdlList):
	ctx = rapi.rpgCreateContext()
	bs = NoeBitStream(data)
	
	FILE_TYPE = bs.readInt() 								#0x6 - TR MESH VERSION/TYPE
	bs.seek(0xC, NOESEEK_REL) 								#Skip past 0xC, Padding?
	
	NUM_UNK00 = bs.readInt()								#Seems to increment based on the amount below
	bs.seek(0x4, NOESEEK_REL)								#Skip past unknown 0x4
	PTR_MESH_START = bs.readInt()							#Points to "MESH" start
	bs.seek(0x18, NOESEEK_REL) 								#Skip past unknown 0x18
	PTR_BONE_START = bs.readInt()							#Read Bone pointer
	bs.seek(0xC, NOESEEK_REL)								#Skip past unknown 0xC
	
	for i in range(0, NUM_UNK00):							#Skip past 0x4 for each NUM_UNK00
		bs.seek(0x4, NOESEEK_REL)
		
	TEMP  = bs.tell()
	bs.seek(PTR_BONE_START - 4, NOESEEK_REL)				#Skip to bone start offset
	
	BONE_COUNT = bs.readInt()								#Read Bone Count
	bs.seek(0x4, NOESEEK_REL)								#Skip past 0xEBBEEBBE
	
	BONE_LIST = []

	for i in range(0, BONE_COUNT):							#For each bone
		bs.seek(0x20, NOESEEK_REL)							#Skip 0x20
		BONE_XPOS = bs.readFloat()							#Read Bone X Position
		BONE_YPOS = bs.readFloat()							#Read Bone Y Position
		BONE_ZPOS = bs.readFloat()							#Read Bone Z Position
		bs.seek(0xC, NOESEEK_REL)							#Skip 0xC
		BONE_PID = bs.readInt()								#Read Bone Parent ID
		bs.seek(0x4, NOESEEK_REL)							#Skip 0x4
		quat = NoeQuat([0, 0, 0, 1])						
		mat = quat.toMat43()
		mat[3] = [BONE_XPOS, BONE_YPOS, BONE_ZPOS]
		BONE_LIST.append(NoeBone(i, "bone%03i"%i, mat, None, BONE_PID))
	BONE_LIST = rapi.multiplyBones(BONE_LIST)
	
	bs.seek(TEMP + PTR_MESH_START, NOESEEK_ABS) 			#Skip past 0x54 unknown data

	MESH_START = bs.tell()									#Save Mesh base position
	bs.seek(0xC, NOESEEK_REL)								#Skip past unknown 0xC
	MESH_FACE_SIZE = bs.readInt()							#Size of all the faces (for each mesh)
	bs.seek(0x64, NOESEEK_REL)								#Skip past 0x64 unknown data
	
	PTR_PIECE_TABLE = bs.readInt()							#Mesh Base Position + This = Offset for mesh piece table.
	PTR_MESH_TBL00 = bs.readInt() 							#Mesh Base Position + This = Offset for Mesh Table
	PTR_MESH_TBL01 = bs.readInt() 							#The same as above???
	PTR_MESH_BONES = bs.readInt() 							#Mesh Base Position + This = Offset for Bones Data
	PTR_MESH_FACE = bs.readInt() 							#Mesh Base Position + This = Offset for Face Data
	
	NUM_MESH_PIECES = bs.readShort()						#Number Of Mesh Pieces
	NUM_MESH = bs.readShort()								#Number Of Meshes
	NUM_UNK02 = bs.readShort()								#Unknown, always 0?
	NUM_BONES = bs.readShort()								#Number Of Bones
	
	bs.seek(MESH_START + PTR_MESH_TBL00, NOESEEK_ABS)		#Skip to Mesh Table
	
	MESH = []												#Create Mesh Array
	for i in range(0, NUM_MESH):
		MESH_PIECES = bs.readInt()							#Mesh Pieces, Number of pieces to read
		MESH_GROUP = bs.readShort()							#Mesh Group for lods?
		MESH_UNK = bs.readShort()							#???
		MESH_UNK01 = bs.readInt()							#???
		MESH_VERT_OFF = bs.readInt()						#points to vert offset "MESH" str val + this offset
		MESH_UNK02 = bs.readInt()							#???
		MESH_UNK03 = bs.readInt()							#???
		MESH_UNK04 = bs.readInt()							#???
		MESH_FVF_OFF = bs.readInt()							#Mesh Base Position + This = Offset to FVF table
		MESH_VCOUNT = bs.readInt()							#Mesh Vert Count; Vert Size = Vert Count * Vert Stride
		MESH_UNK05 = bs.readInt()							#???
		MESH_FACE_OFF = bs.readInt() 						#Mesh Face Offset; Pointer into the face data
		MESH_FCOUNT = bs.readInt()							#Mesh Face Count; Face Size = Face Count * 0x3
		MESH.append([MESH_PIECES, MESH_GROUP, MESH_UNK, MESH_UNK01, MESH_VERT_OFF, MESH_UNK02, MESH_UNK03, MESH_UNK04, MESH_FVF_OFF, MESH_VCOUNT, MESH_UNK05, MESH_FACE_OFF, MESH_FCOUNT])
					#     0          1          2          3             4            5           6            7           8             9            10           11           12
	

	for i in range(0, NUM_MESH):
		VERT_SIZE2 = 0
		bs.seek(MESH_START + MESH[i][8], NOESEEK_ABS)	#Skip to FVF Table
		bs.seek(0x8, NOESEEK_REL)						#Skip past unknown 0x8
		MESH_NUM_UNK01 = bs.readShort()					#FVF id?
		MESH_VERT_STRIDE = bs.readShort()				#Vert Stride

		NULL01 = bs.readInt()

		for j in range(0, MESH_NUM_UNK01):
			HASH = bs.readUInt()
			if HASH == 0x8317902A:
				MESH_UV_INFO = bs.readShort()
				bs.seek(0x2, NOESEEK_REL)
			else:
				bs.seek(0x4, NOESEEK_REL)
		bs.seek(MESH_START + PTR_PIECE_TABLE, NOESEEK_ABS)	#skip to mesh piece table offset
		
		
		PIECE = []
		for j in range(0, MESH[i][0]):			#each piece
			bs.seek(0x10, NOESEEK_REL)
			PIECE_OFFSET = bs.readInt()
			PIECE_FCOUNT = bs.readInt()
			PIECE_VCOUNT = bs.readInt()
			PIECE.append([PIECE_OFFSET, PIECE_FCOUNT, PIECE_VCOUNT])
			bs.seek(0x34, NOESEEK_REL)
			PTR_PIECE_TABLE += 0x50
		
		
		for j in range(0, MESH[i][0]):
			rapi.rpgSetName("MESH_" + str(i) + "_PIECE_" + str(j)) #
			bs.seek(MESH_START + MESH[i][4] + VERT_SIZE2, NOESEEK_ABS)	#seek to vert start offset
			VERT_SIZE2 += PIECE[j][2] * MESH_VERT_STRIDE
			VBUFFER = bs.readBytes(PIECE[j][2] * MESH_VERT_STRIDE)
			
			bs.seek(MESH_START + PTR_MESH_FACE, NOESEEK_ABS) #Face start
			bs.seek(PIECE[j][0] * 0x2, NOESEEK_REL) #Face start
			TEMP2 = bs.tell()
			VERT_START = bs.readUShort()
			bs.seek(TEMP2, NOESEEK_ABS)
			faceData = []
			for a in range(0, PIECE[j][1] * 0x3):
				face = bs.readUShort() 
				face -= VERT_START
				faceData.append(face)
				if face < 0:
					face += VERT_START
					print("this is dafuqqin error why is it fuqqin minus z_z")
					print(face)
			FBUFFER = struct.pack("<" + 'H'*len(faceData), * faceData)
			
			rapi.rpgBindPositionBufferOfs(VBUFFER, noesis.RPGEODATA_FLOAT, MESH_VERT_STRIDE, 0)
			rapi.rpgBindUV1BufferOfs(VBUFFER, noesis.RPGEODATA_USHORT, MESH_VERT_STRIDE, MESH_UV_INFO)
			rapi.rpgSetUVScaleBias(NoeVec3 ((32, 32, 1.0)), NoeVec3 ((1.0, 1.0, 1.0)))
			rapi.rpgCommitTriangles(None, noesis.RPGEODATA_USHORT, PIECE[j][2], noesis.RPGEO_POINTS, 1)
			rapi.rpgCommitTriangles(FBUFFER, noesis.RPGEODATA_USHORT, PIECE[j][1] * 0x3, noesis.RPGEO_TRIANGLE, 1)
			
	mdl = rapi.rpgConstructModel()
	mdlList.append(mdl) #important, don't forget to put your loaded model in the mdlList
	mdl.setBones(BONE_LIST)
	rapi.rpgClearBufferBinds()
	return 1