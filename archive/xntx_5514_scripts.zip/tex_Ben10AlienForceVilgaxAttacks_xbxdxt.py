from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Ben 10 Alien Force: Vilgax Attacks (X360)", ".xbxdxt")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

#Ben 10 Alien Force: Vilgax Attacks (X360)
def noepyCheckType(data):
    bs = NoeBitStream(data)
    Magic = bs.readBytes(6)
    if Magic != b'\x00\x00\x00\x01\x01\x3c':
        return 0
    return 1
	
def noepyLoadRGBA(data, texList):
    datasize = len(data) - 0x80        
    bs = NoeBitStream(data, NOE_BIGENDIAN)
    bs.seek(0x06, NOESEEK_ABS)
    imgWidth = bs.readUShort()            
    imgHeight = bs.readUShort()           
    bs.seek(0x80, NOESEEK_ABS)
    data = bs.readBytes(datasize)      
    data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 8)
    texFmt = noesis.NOESISTEX_DXT1
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1