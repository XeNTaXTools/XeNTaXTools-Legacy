import json
import struct

def file_exists(filename):
    """Return true if file exists and is accessible for reading.

    Should be safer than just testing for existence due to links and
    permissions magic on Unix filesystems.

    @rtype: boolean
    """

    try:
        f = open(filename, 'r')
        f.close()
        return True
    except IOError:
        return False

def pick_fmt2(size):
    fmt='<'
    if(size == 1):
        fmt = fmt + 'bb'
    elif(size == 2):
        fmt = fmt + 'hh'
    elif(size == 4):
        fmt = fmt + 'ff'
    else:
        print("Eroare la format2, size este: ", size);
    return fmt

def pick_fmt3(size):
    fmt='<'
    if(size == 1):
        fmt = fmt + 'bbb'
    elif(size == 2):
        fmt = fmt + 'hhh'
    elif(size == 4):
        fmt = fmt + 'fff'
    else:
        print("Eroare la format3, size este: ", size);
    return fmt

def pick_index_fmt(size):
    fmt = ''
    if(size == 1):
        fmt = 'B'
    elif(size == 2):
        fmt = 'H'
    elif(size == 4):
        fmt = 'I'
    else:
        print("Eroare la format index3, size este: ", size);

    return fmt

def repeat_str(string, nr):
    rfmt=''
    
    for i in range(nr):
        rfmt = rfmt+string
    return rfmt
    

def skip_padding(position, n):
    if n % 4:
        position = position + (4 - n % 4)
    return position

def read_faces_group(bin_content, position, v_fmt, uv_fmt, n_fmt, m_fmt, nr):
    v_size = struct.calcsize(v_fmt)
    uv_size = struct.calcsize(uv_fmt)
    n_size = struct.calcsize(n_fmt)
    m_size = struct.calcsize(m_fmt)

    vi = []
    uvi = []
    ni = []
    m = []

    for i in range(nr):
        vi.append(struct.unpack_from(v_fmt, bin_content, position))
        position = position + v_size

    if(n_size > 0):
        for i in range(nr):
            ni.append(struct.unpack_from(n_fmt, bin_content, position))
            position = position + n_size

    if(uv_size > 0):
        for i in range(nr):
            uvi.append(struct.unpack_from(uv_fmt, bin_content, position))
            position = position + uv_size

    #skip material if any
    if(len(vi) > 0):
        position = position + nr*m_size

    if(len(ni) > 0):
        vi=[a+b for (a,b) in zip(vi,ni)]

    if(len(uvi) > 0):
        vi=[a+b for (a,b) in zip(vi,uvi)]

    return position, vi
            
def read_bin_file(bin_file):
    input = open(bin_file, "rb")
    bin_content = input.read()
    input.close();

    position = 0;
    sign_fmt = '<12s'
    signature = struct.unpack_from(sign_fmt, bin_content)
    position = position + struct.calcsize(sign_fmt)
    
    bdata_fmt = '<BBBBBBBB'
    header_bytes, vertex_coordinate_bytes, normal_coordinate_bytes, uv_coordinate_bytes, vertex_index_bytes, normal_index_bytes, uv_index_bytes, material_index_bytes = struct.unpack_from(bdata_fmt, bin_content, position)
    position = position + struct.calcsize(bdata_fmt);

    ndata_fmt = '<IIIIIIIIIII'
    len_vertices, nnormals, len_uvs, ntri_flat, ntri_smooth, ntri_flat_uv, ntri_smooth_uv, nquad_flat, nquad_smooth, nquad_flat_uv, nquad_smooth_uv = struct.unpack_from(ndata_fmt, bin_content, position)
    position = position + struct.calcsize(ndata_fmt);

    print(signature)
    print("header_bytes, vertex_coordinate_bytes, normal_coordinate_bytes, uv_coordinate_bytes, vertex_index_bytes, normal_index_bytes, uv_index_bytes, material_index_bytes")
    print(header_bytes, vertex_coordinate_bytes, normal_coordinate_bytes, uv_coordinate_bytes, vertex_index_bytes, normal_index_bytes, uv_index_bytes, material_index_bytes)
    print("len_vertices, nnormals, len_uvs, ntri_flat, ntri_smooth, ntri_flat_uv, ntri_smooth_uv, nquad_flat, nquad_smooth, nquad_flat_uv, nquad_smooth_uv")
    print(len_vertices, nnormals, len_uvs, ntri_flat, ntri_smooth, ntri_flat_uv, ntri_smooth_uv, nquad_flat, nquad_smooth, nquad_flat_uv, nquad_smooth_uv)

    # 1. Vertex coordinates
    # 1. vertices
    # ------------
    # x float   4
    # y float   4
    # z float   4
    vertex_fmt = pick_fmt3(vertex_coordinate_bytes)
    print(vertex_fmt)
    vertex_size = struct.calcsize(vertex_fmt)
    vertices = []
    print("Nr vertices:", len_vertices)
    for i in range(len_vertices):
        vertices.append(struct.unpack_from(vertex_fmt, bin_content, position))
        position = position + vertex_size

    #de ce nu o skipa paddingu pe vertex ? misterele vietii ...

    # 2. Normals
    # 2. normals - format orientativ doar
    # ---------------
    # x signed char 1
    # y signed char 1
    # z signed char 1
    normal_fmt = pick_fmt3(normal_coordinate_bytes)
    print(normal_fmt)
    normal_size = struct.calcsize(normal_fmt)
    normals = []
    print("Nr normals:", nnormals)
    for i in range(nnormals):
        normals.append(struct.unpack_from(normal_fmt, bin_content, position))
        position = position + normal_size

    position = skip_padding(position, nnormals * 3)

    # 3. UV coords
    # 3. uvs
    # -----------
    # u float   4
    # v float   4
    uvs_fmt = pick_fmt2(uv_coordinate_bytes)
    print(uvs_fmt)
    uvs_size = struct.calcsize(uvs_fmt)
    uvs = []
    print("Nr uvs:", len_uvs)
    for i in range(len_uvs):
        uvs.append(struct.unpack_from(uvs_fmt, bin_content, position))
        position = position + uvs_size

    #nici aici skip. funny

    # Fatetele horror - TODO
    vi_fmt = pick_index_fmt(vertex_index_bytes)
    ni_fmt = pick_index_fmt(normal_index_bytes)
    uvi_fmt = pick_index_fmt(uv_index_bytes)
    mi_fmt = pick_index_fmt(material_index_bytes)
    material_fmt = '<'+mi_fmt

    material_size = struct.calcsize(material_fmt);

    print("Material format ", material_fmt)

    tv_fmt = '<' + repeat_str(vi_fmt,3)
    tn_fmt = '<' + repeat_str(ni_fmt,3)
    tuv_fmt = '<' + repeat_str(uvi_fmt,3)
    qv_fmt = '<' + repeat_str(vi_fmt,4)
    qn_fmt = '<' + repeat_str(ni_fmt,4)
    quv_fmt = '<' + repeat_str(uvi_fmt,4)

    faces = {}

    # 4. flat triangles (vertices + materials)
    # ------------------
    # a unsigned int   4
    # b unsigned int   4
    # c unsigned int   4
    # ------------------
    # m unsigned short 2
    position, faces_now = read_faces_group(bin_content, position, tv_fmt, '', '', material_fmt, ntri_flat)
    faces['triangles_flat'] = faces_now
    position = skip_padding(position, ntri_flat * material_size)

    # 5. smooth triangles (vertices + materials + normals)
    # -------------------
    # a  unsigned int   4
    # b  unsigned int   4
    # c  unsigned int   4
    # -------------------
    # na unsigned int   4
    # nb unsigned int   4
    # nc unsigned int   4
    # -------------------
    # m  unsigned short 2
    position, faces_now = read_faces_group(bin_content, position, tv_fmt, '', tn_fmt, material_fmt, ntri_smooth)
    faces['triangles_smooth'] = faces_now
    position = skip_padding(position, ntri_smooth * material_size)

    # 6. flat triangles uv (vertices + materials + uvs)
    # --------------------
    # a  unsigned int    4
    # b  unsigned int    4
    # c  unsigned int    4
    # --------------------
    # ua unsigned int    4
    # ub unsigned int    4
    # uc unsigned int    4
    # --------------------
    # m  unsigned short  2
    position, faces_now = read_faces_group(bin_content, position, tv_fmt, tuv_fmt, '', material_fmt, ntri_flat_uv)
    faces['triangles_flat_uv'] = faces_now
    position = skip_padding(position, ntri_flat_uv * material_size)

    # 7. smooth triangles uv (vertices + materials + normals + uvs)
    # ----------------------
    # a  unsigned int    4
    # b  unsigned int    4
    # c  unsigned int    4
    # --------------------
    # na unsigned int    4
    # nb unsigned int    4
    # nc unsigned int    4
    # --------------------
    # ua unsigned int    4
    # ub unsigned int    4
    # uc unsigned int    4
    # --------------------
    # m  unsigned short  2
    position, faces_now = read_faces_group(bin_content, position, tv_fmt, tuv_fmt, tn_fmt, material_fmt, ntri_smooth_uv)
    faces['triangles_smooth_uv'] = faces_now
    position = skip_padding(position, ntri_smooth_uv * material_size)

    # 8. flat quads (vertices + materials)
    # ------------------
    # a unsigned int   4
    # b unsigned int   4
    # c unsigned int   4
    # d unsigned int   4
    # --------------------
    # m unsigned short 2
    position, faces_now = read_faces_group(bin_content, position, qv_fmt, '', '', material_fmt, nquad_flat)
    faces['quads_flat'] = faces_now
    position = skip_padding(position, nquad_flat * material_size)

    # 9. smooth quads (vertices + materials + normals)
    # -------------------
    # a  unsigned int   4
    # b  unsigned int   4
    # c  unsigned int   4
    # d  unsigned int   4
    # --------------------
    # na unsigned int   4
    # nb unsigned int   4
    # nc unsigned int   4
    # nd unsigned int   4
    # --------------------
    # m  unsigned short 2
    position, faces_now = read_faces_group(bin_content, position, qv_fmt, '', qn_fmt, material_fmt, nquad_smooth)
    faces['quads_smooth'] = faces_now
    position = skip_padding(position, nquad_smooth * material_size)

    # 10. flat quads uv (vertices + materials + uvs)
    # ------------------
    # a unsigned int   4
    # b unsigned int   4
    # c unsigned int   4
    # d unsigned int   4
    # --------------------
    # ua unsigned int  4
    # ub unsigned int  4
    # uc unsigned int  4
    # ud unsigned int  4
    # --------------------
    # m unsigned short 2
    position, faces_now = read_faces_group(bin_content, position, qv_fmt, quv_fmt, '', material_fmt, nquad_flat_uv)
    faces['quads_flat_uv'] = faces_now
    position = skip_padding(position, nquad_flat_uv * material_size)

    # 11. smooth quads uv
    # -------------------
    # a  unsigned int   4
    # b  unsigned int   4
    # c  unsigned int   4
    # d  unsigned int   4
    # --------------------
    # na unsigned int   4
    # nb unsigned int   4
    # nc unsigned int   4
    # nd unsigned int   4
    # --------------------
    # ua unsigned int   4
    # ub unsigned int   4
    # uc unsigned int   4
    # ud unsigned int   4
    # --------------------
    # m  unsigned short 2
    position, faces_now = read_faces_group(bin_content, position, qv_fmt, quv_fmt, qn_fmt, material_fmt, nquad_smooth_uv)
    faces['quads_smooth_uv'] = faces_now
    position = skip_padding(position, nquad_smooth_uv * material_size)

    return vertices, normals, uvs, faces

def write_obj(vertices, normals, uvs, faces, obj_out):
    output = open(obj_out, "wt")

    for v in vertices:
        output.write("v "+str(float(v[0]))+" "+str(float(v[1]))+" "+str(float(v[2]))+"\n")

    for v in normals:
        output.write("vn "+str(v[0])+" "+str(v[1])+" "+str(v[2])+"\n")

    # invert back V if any
    for v in uvs:
        output.write("vt "+str(v[0])+" "+str(-v[1])+"\n")

    
    output.write("# faces triangles_flat\n")
    for v in faces['triangles_flat']:
        output.write("f "+str(v[0]+1)+" "+str(v[1]+1)+" "+str(v[2]+1)+"\n")

    output.write("# faces triangles_smooth\n")
    for v in faces['triangles_smooth']:
        output.write("f "+str(v[0]+1)+"//"+str(v[3]+1)+" "
                         +str(v[1]+1)+"//"+str(v[4]+1)+" "
                         +str(v[2]+1)+"//"+str(v[5]+1)+"\n")

    output.write("# faces triangles_flat_uv\n")
    for v in faces['triangles_flat_uv']:
        string = "f "+str(v[0]+1)+"/"+str(v[3]+1)+" " +str(v[1]+1)+"/"+str(v[4]+1)+" " +str(v[2]+1)+"/"+str(v[5]+1)+"\n"
        output.write(string)

    output.write("# faces triangles_smooth_uv\n")
    for v in faces['triangles_smooth_uv']:
        output.write("f "+str(v[0]+1)+"/"+str(v[6]+1)+"/"+str(v[3]+1)+" "
                         +str(v[1]+1)+"/"+str(v[7]+1)+"/"+str(v[4]+1)+" "
                         +str(v[2]+1)+"/"+str(v[8]+1)+"/"+str(v[5]+1)+"\n")
    

    
    output.write("# faces quads_flat\n")
    for v in faces['quads_flat']:
        output.write("f "+str(v[0]+1)+" "+str(v[1]+1)+" "+str(v[2]+1)+" "+str(v[3]+1)+"\n")

    output.write("# faces quads_smooth\n")
    for v in faces['quads_smooth']:
        output.write("f "+str(v[0]+1)+"//"+str(v[4]+1)+" "
                         +str(v[1]+1)+"//"+str(v[5]+1)+" "
                         +str(v[2]+1)+"//"+str(v[6]+1)+" "
                         +str(v[3]+1)+"//"+str(v[7]+1)+"\n")

    output.write("# faces quads_flat_uv\n")
    for v in faces['quads_flat_uv']:
        output.write("f "+str(v[0]+1)+"/"+str(v[4]+1)+" "
                         +str(v[1]+1)+"/"+str(v[5]+1)+" "
                         +str(v[2]+1)+"/"+str(v[6]+1)+" "
                         +str(v[3]+1)+"/"+str(v[7]+1)+"\n")

    output.write("# faces quads_smooth_uv\n")
    for v in faces['quads_smooth_uv']:
        output.write("f "+str(v[0]+1)+"/"+str(v[8]+1)+"/"+str(v[4]+1)+" "
                         +str(v[1]+1)+"/"+str(v[9]+1)+"/"+str(v[5]+1)+" "
                         +str(v[2]+1)+"/"+str(v[10]+1)+"/"+str(v[6]+1)+" "
                         +str(v[3]+1)+"/"+str(v[11]+1)+"/"+str(v[7]+1)+"\n")

    output.close();

def convert_me_back(js_file, obj_out):
    if not file_exists(js_file):
        print("Couldn't find [%s]" % js_file)
        return
	
    """ must extract: faces, vertices, uvs, normals, materials, mtllib """

    #input = open(js_file, "r")
    #js_string = input.read()
    #input.close();
	
    #data = json.loads(js_string)
    #bin_file = data["buffers"]

    vertices, normals, uvs, faces = read_bin_file(js_file)

    write_obj(vertices, normals, uvs, faces, obj_out)


convert_me_back("three.js", "export.obj")
