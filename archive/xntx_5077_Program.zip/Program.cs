﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace TalesOfExtractor
{
    class Program
    {
        static void decodeTextures()
        {
            string basePath1 = @"D:\WinApp\Steam\steamapps\common\Tales of Zestiria\032_extract\TOTEXB_D\";
            string basePath2 = @"D:\WinApp\Steam\steamapps\common\Tales of Zestiria\032_extract\TOTEXP_P\";
            foreach (var fileName in Directory.EnumerateFiles(basePath1))
            {
                if (Path.GetExtension(fileName) != ".dpd")
                    continue;

                FileStream f = File.OpenRead(fileName);
                f.Seek(0x20, SeekOrigin.Begin);
                byte[] nameBuffer = new byte[f.Length];
                int numBytes = f.Read(nameBuffer, 0, (int)f.Length);
                string realName = Encoding.UTF8.GetString(nameBuffer, 0, numBytes);
                realName = realName.TrimEnd(new char[] { (char)0 });
                f.Close();

                // 0000000000000da6 -> 0000000000000da7
                string nextName = Path.GetFileNameWithoutExtension(fileName);
                long fileNumber = long.Parse(nextName, NumberStyles.HexNumber) + 1;
                string numberFormat = "{0:X" + nextName.Length + "}";
                nextName = string.Format(numberFormat, fileNumber);

                string dataFileName = basePath2 + nextName;
                FileStream df = null;
                if (File.Exists(dataFileName + ".dat"))
                    df = File.OpenRead(dataFileName + ".dat");
                else if (File.Exists(dataFileName + ".lib"))
                    df = File.OpenRead(dataFileName + ".lib");
                else
                    continue;
                df.Seek(0x4, SeekOrigin.Begin);
                FileStream of = File.OpenWrite(basePath2 + realName + ".dds");
                df.CopyTo(of);
                df.Close();
                of.Close();
            }
        }

        static uint readInt32(byte[] b)
        {
            return (uint) (b[0] + (b[1] << 8) + (b[2] << 16) + (b[3] << 24));
        }

        public static int PatternAt(byte[] source, byte[] pattern)
        {
            for (int i = 0; i < source.Length; i++)
            {
                if (source.Skip(i).Take(pattern.Length).SequenceEqual(pattern))
                {
                    return i;
                }
            }
            return -1;
        }

        static void decodeModels()
        {
            string basePath1 = @"D:\WinApp\Steam\steamapps\common\Tales of Zestiria\032_extract\TOMDLB_D\";
            string basePath2 = @"D:\WinApp\Steam\steamapps\common\Tales of Zestiria\032_extract\TOMDLP_P\";
            foreach (var fileName in Directory.EnumerateFiles(basePath1))
            {
                if (Path.GetExtension(fileName) != ".dpd")
                    continue;

                // Get header size
                FileStream f = File.OpenRead(fileName);
                f.Seek(0x14, SeekOrigin.Begin);
                byte[] valueBuffer = new byte[4];
                f.Read(valueBuffer, 0, 4);
                uint headerSize = readInt32(valueBuffer);

                // Read header
                byte[] header = new byte[headerSize-4];
                f.Read(header, 0, (int) (headerSize - 4));
                // Search for animation file.
                int fileExtPos = PatternAt(header, Encoding.UTF8.GetBytes(".toanmb"));
                while (header[fileExtPos] != 0)
                    fileExtPos--;
                int endPos = ++fileExtPos;
                while (header[endPos] != 0)
                    ++endPos;
                string animationName = Encoding.UTF8.GetString(header, fileExtPos, endPos - fileExtPos);
                // Search for model file.
                fileExtPos = PatternAt(header, Encoding.UTF8.GetBytes(".tomdlp_p"));
                while (header[fileExtPos] != 0)
                    fileExtPos--;
                endPos = ++fileExtPos;
                while (header[endPos] != 0)
                    ++endPos;
                string modelName = Encoding.UTF8.GetString(header, fileExtPos, endPos - fileExtPos);

                // Copy data.
                FileStream of = File.OpenWrite(basePath2 + animationName);
                f.CopyTo(of);
                of.Close();
                f.Close();

                // 0000000000000da6 -> 0000000000000da7
                string nextName = Path.GetFileNameWithoutExtension(fileName);
                long fileNumber = long.Parse(nextName, NumberStyles.HexNumber) + 1;
                string numberFormat = "{0:X" + nextName.Length + "}";
                nextName = string.Format(numberFormat, fileNumber);

                string dataFileName = basePath2 + nextName;
                FileStream df = null;
                if (File.Exists(dataFileName + ".dat"))
                    df = File.OpenRead(dataFileName + ".dat");
                else if (File.Exists(dataFileName + ".dc5"))
                    df = File.OpenRead(dataFileName + ".dc5");
                else
                    continue;

                // Isolate vertex and index data.
                int geometrySet = 0;
                while (df.Position < df.Length)
                {
                    geometrySet++;

                    df.Read(valueBuffer, 0, 4);
                    long vertexPosition = df.Position - 4;
                    // Skip vertices.
                    while (df.Position < df.Length)
                    {
                        int i0 = valueBuffer[0] + (valueBuffer[1] << 8);
                        int i1 = valueBuffer[2] + (valueBuffer[3] << 8);
                        if (i0 <= 2048 && i1 <= 2048 && !(i0 == 0 && i1 == 0))
                            break;
                        df.Read(valueBuffer, 0, 4);
                    }
                    // Skip indices.
                    long indexPosition = df.Position - 4;
                    int maxVertex = 0;
                    while (df.Position < df.Length)
                    {
                        int i0 = valueBuffer[0] + (valueBuffer[1] << 8);
                        int i1 = valueBuffer[2] + (valueBuffer[3] << 8);
                        if (i0 > 2048 || i1 > 2048)
                            break;
                        maxVertex = Math.Max(Math.Max(maxVertex, i0), i1);
                        df.Read(valueBuffer, 0, 4);
                    }
                    long endIndexPos = df.Position >= df.Length ? df.Position : df.Position - 4;
                    long indexBufferSize = (endIndexPos - indexPosition) / 2;
                    long vertexBufferSize = (indexPosition - vertexPosition)/4;
                    int vertexCount = maxVertex + 1;
                    int vertexElements = (int) (vertexBufferSize/vertexCount);

                    if (vertexElements == 0 || indexBufferSize == 0)
                        continue;
 
                    // Write vertex data.
                    StreamWriter writer = File.CreateText(basePath2 + modelName + geometrySet + ".obj");
                    df.Position = vertexPosition;
                    byte[] vertexData = new byte[vertexElements*4];
                    float[] vertexD = new float[vertexElements];
                    for (int v = 0; v < vertexCount; ++v)
                    {
                        df.Read(vertexData, 0, vertexElements*4);
                        int invalidPos = -1;
                        for (int i = 0; i < vertexElements; ++i)
                        {
                            vertexD[i] = System.BitConverter.ToSingle(vertexData, i*4);
                            if (float.IsNaN(vertexD[i]))
                                invalidPos = i;
                        }
                        if (invalidPos == 6)
                            writer.Write("v {0:0.##############} {1:0.##############} {2:0.##############}\n", vertexD[0], vertexD[1], vertexD[2]);
                    }
                    df.Position = vertexPosition;
                    for (int v = 0; v < vertexCount; ++v)
                    {
                        df.Read(vertexData, 0, vertexElements * 4);
                        int invalidPos = -1;
                        for (int i = 0; i < vertexElements; ++i)
                        {
                            vertexD[i] = System.BitConverter.ToSingle(vertexData, i * 4);
                            if (float.IsNaN(vertexD[i]))
                                invalidPos = i;
                        }
                        if (vertexElements >= 9)
                            writer.Write("vt {0:0.##############} {1:0.##############}\n", vertexD[7], vertexD[8]);
                    }
                    df.Position = vertexPosition;
                    for (int v = 0; v < vertexCount; ++v)
                    {
                        df.Read(vertexData, 0, vertexElements * 4);
                        int invalidPos = -1;
                        for (int i = 0; i < vertexElements; ++i)
                        {
                            vertexD[i] = System.BitConverter.ToSingle(vertexData, i * 4);
                            if (float.IsNaN(vertexD[i]))
                                invalidPos = i;
                        }
                        if (invalidPos == 6)
                            writer.Write("vn {0:0.##############} {1:0.##############} {2:0.##############}\n", vertexD[3], vertexD[4], vertexD[5]);
                    }
                    // Check index data for triangle strips.
                    df.Position = indexPosition;
                    byte[] indexData = new byte[3*2];
                    bool useTriangleStrip = indexBufferSize % 3 != 0;
                    if (!useTriangleStrip)
                    {
                        for (int i = 0; i < indexBufferSize/3; ++i)
                        {
                            df.Read(indexData, 0, 3*2);
                            int i0 = indexData[0] + (indexData[1] << 8);
                            int i1 = indexData[2] + (indexData[3] << 8);
                            int i2 = indexData[4] + (indexData[5] << 8);
                            if (i0 == i1 || i0 == i2 || i1 == i2)
                            {
                                useTriangleStrip = true;
                                break;
                            }
                        }
                    }
                    df.Position = indexPosition;
                    // Triangulate.
                    if (useTriangleStrip)
                    {
                        df.Read(indexData, 0, 2 * 2);
                        int i0 = indexData[0] + (indexData[1] << 8) + 1;
                        int i1 = indexData[2] + (indexData[3] << 8) + 1;
                        for (int i = 0; i < indexBufferSize - 2; ++i)
                        {
                            df.Read(indexData, 2*2, 2);
                            int i2 = indexData[4] + (indexData[5] << 8) + 1;
                            if (i0 != i1 && i0 != i2 && i1 != i2)
                            {
                                if ((i & 1) != 0)
                                    writer.Write("f {0}/{1}/{2} {3}/{4}/{5} {6}/{7}/{8}\n", i0, i0, i0, i1, i1, i1, i2, i2, i2);
                                else
                                    writer.Write("f {0}/{1}/{2} {3}/{4}/{5} {6}/{7}/{8}\n", i0, i0, i0, i2, i2, i2, i1, i1, i1);
                            }
                            i0 = i1;
                            i1 = i2;
                        }    
                    }
                    else
                    {
                        for (int i = 0; i < indexBufferSize/3; ++i)
                        {
                            df.Read(indexData, 0, 3 * 2);
                            int i0 = indexData[0] + (indexData[1] << 8) + 1;
                            int i1 = indexData[2] + (indexData[3] << 8) + 1;
                            int i2 = indexData[4] + (indexData[5] << 8) + 1;
                            writer.Write("f {0}/{1}/{2} {3}/{4}/{5} {6}/{7}/{8}\n", i0,i0,i0, i1,i1,i1, i2,i2,i2);
                        }
                    }
                    writer.Close();

                    // If we are not at even boundary, read dummy.
                    if (df.Position % 4 != 0)
                        df.Read(indexData, 0, 2);
                }
            }
        }

        static void Main(string[] args)
        {
            decodeTextures();
            decodeModels();
        }
    }
}
