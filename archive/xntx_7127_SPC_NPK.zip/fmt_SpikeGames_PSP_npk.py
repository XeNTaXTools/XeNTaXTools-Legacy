#Noesis import plugin. Written by Andy97 - Hiroshi

from inc_noesis import *
import noesis
import rapi

ENDIAN = 0 #0 - Little, 1 - Big

SKL_SIGN = b'$SKL'
VTX_SIGN = b'$VTX'
MAT_SIGN = b'$MAT'
MSH_SIGN = b'$MSH'
SCN_SIGN = b'$SCN'

def registerNoesisTypes():
    '''Register the plugin. Just change the Game name and extension.'''
    
    handle = noesis.register("Spike Chunsoft PSP .NPK", ".npk")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)
    return 1
    
def noepyCheckType(data):
    '''Verify that the format is supported by this plugin. Default yes'''
    bs = NoeBitStream(data)
    if len(data) < 2:
        return 0
    return 1   

def noepyLoadModel(data, mdlList):
    '''Build the model, set materials, bones, and animations. You do not
    need all of them as long as they are empty lists (they are by default)'''
    
    ctx = rapi.rpgCreateContext()
    parser = NPK(data)
    parser.parse_file()
    mdl = rapi.rpgConstructModel()
    #mdl.setModelMaterials(NoeModelMaterials(parser.texList, parser.matList))
    mdl.setBones(parser.boneList)
    mdlList.append(mdl)
    rapi.rpgClearBufferBinds()
    
    return 1

class NPK(object):
    def __init__(self, data):    
        '''Initialize some data'''
        self.inFile = NoeBitStream(data, ENDIAN)            #Read NPK
        
        self.inFileNPKI = self.loadNPKIFile()        #Read NPKI

        self.bufferData = data

        self.boneList = []

        self.boneDict = {}

        self.texPath = rapi.getDirForFilePath(rapi.getLastCheckedName())  #Get path of the textures

    def loadNPKIFile(self):
        if (rapi.checkFileExists(rapi.getExtensionlessName(rapi.getInputName()) + ".npki")):
            npkiData = rapi.loadIntoByteArray(rapi.getExtensionlessName(rapi.getInputName()) + ".npki")
            return NoeBitStream(npkiData, ENDIAN)
    
    def skip_dummy0(self):
        dummy = self.inFile.tell() % 16
        if dummy:
            self.inFile.seek(16 - dummy, NOESEEK_REL)

    def skip_dummy_bytes(self, meshId):
        if (meshId == 516):
            self.inFile.seek(52, NOESEEK_REL)
        elif (meshId == 517):
            self.inFile.seek(60, NOESEEK_REL)
        elif (meshId == 518):
            self.inFile.seek(68, NOESEEK_REL)
        elif (meshId == 519):
            self.inFile.seek(76, NOESEEK_REL)
        elif (meshId == 520):
            self.inFile.seek(84, NOESEEK_REL)

    def get_VTX_ofs(self, vtxBuff):
        bs = NoeBitStream(vtxBuff, ENDIAN)
            
        vtxOfs = []

        while (True):
            unk = bs.readBytes(4)
            if unk == VTX_SIGN:
                vtxOfs.append(bs.tell() - 4)
            if (bs.tell() == len(vtxBuff)):
                break
        return vtxOfs

    def getBindBoneList(self, start, end):
        bb = []
        self.inFile.seek(start, NOESEEK_ABS)
        while (self.inFile.tell() < end):
            name = self.inFile.readString()
            if name not in ["map1", "damage_00", "damage_00(0)", "UVMap", "Col", "map11", "map12"]:
                bb.append(name)
        return bb

    def parse_bone(self):
        SKLOfs = self.bufferData.index(SKL_SIGN)
        self.inFile.seek(SKLOfs + 22, NOESEEK_ABS)
        boneCount = self.inFile.readUShort()
        self.inFile.seek(4, NOESEEK_REL)
        lastFlag = 255
        boneData = [0] * 100

        for i in range (0, boneCount):
            boneNameOfs = self.inFile.readUShort() + 0x10
            self.inFile.seek(2, NOESEEK_REL)
            currentOfs = self.inFile.tell()
            self.inFile.seek(SKLOfs + boneNameOfs, NOESEEK_ABS)
            boneName = self.inFile.readString()
            self.inFile.seek(currentOfs, NOESEEK_ABS)
            currentId = self.inFile.read(">h")[0]
            parentId = currentId - 1
            currentFlag = self.inFile.readShort()
            Matrix = []
            for j in range (0, 12):
                Matrix.append(self.inFile.readFloat())
            boneMat = NoeMat43( [(Matrix[0],Matrix[1],Matrix[2]),
                                 (Matrix[3],Matrix[4],Matrix[5]),
                                 (Matrix[6],Matrix[7],Matrix[8]),
                                 (Matrix[9],Matrix[10],Matrix[11])
                                 ] ).transpose().swapHandedness()
            boneData[currentId] = i

            self.inFile.seek(48, NOESEEK_REL)   #World space
            if lastFlag != 255:
                self.boneList.append(NoeBone(i, boneName, boneMat, None, boneData[parentId]))
            else:
                self.boneList.append(NoeBone(i, boneName, boneMat, None, i - 1))
            self.inFile.seek(24, NOESEEK_REL)
            lastFlag = currentFlag

        for i in range (boneCount):
            j = self.boneList[i].parentIndex
            if j != -1:
                self.boneList[i].setMatrix(self.boneList[i].getMatrix() * self.boneList[j].getMatrix())

        for i in range (boneCount):
            self.boneDict[self.boneList[i].name] = i    
    
    def parse_vertices(self, submeshId, vertCount, vertStride, uvStride, vertStartOfs, bindBoneList):
        self.inFileNPKI.seek(vertStartOfs, NOESEEK_ABS)
 
        #---Vertices---
        vertBuff = self.inFileNPKI.readBytes(vertCount * vertStride)
        rapi.rpgBindPositionBufferOfs(vertBuff, noesis.RPGEODATA_FLOAT, vertStride, 0)
        
        #---Weights + Indices---
        bwgtBuff = []
        bidxBuff = []
        if (submeshId not in [516, 517]):
            for i in range (vertCount):
                for j in range (4):
                    bwgtBuff.append(self.inFileNPKI.readFloat())
                for j in range (4):                                     #PSP Platform
                    bidxBuff.append(self.inFileNPKI.readUByte())
                self.inFileNPKI.seek(12, NOESEEK_REL)
            
            for i in range (len(bidxBuff)):
                acutalIdx = self.boneDict[bindBoneList[bidxBuff[i]]]
                bidxBuff[i] = acutalIdx
            bidxList = struct.pack("iiii"*vertCount, *bidxBuff)
            bwgtList = struct.pack("ffff"*vertCount, *bwgtBuff)
            rapi.rpgBindBoneIndexBuffer(bidxList, noesis.RPGEODATA_INT, 16, 4)
            rapi.rpgBindBoneWeightBuffer(bwgtList, noesis.RPGEODATA_FLOAT, 16, 4)   
        else:
            bidxList = struct.pack("i"*vertCount, *[0]*vertCount)
            bwgtList = struct.pack("f"*vertCount, *[1.0]*vertCount)
            rapi.rpgBindBoneIndexBuffer(bidxList, noesis.RPGEODATA_INT, 4, 1)
            rapi.rpgBindBoneWeightBuffer(bwgtList, noesis.RPGEODATA_FLOAT, 4, 1)

        #---UV + Normals---
        if (submeshId not in [516, 517]):
            uvBuff = self.inFileNPKI.readBytes(vertCount * uvStride)
            rapi.rpgBindNormalBufferOfs(vertBuff, noesis.RPGEODATA_FLOAT, vertStride, 16)
            rapi.rpgBindUV1BufferOfs(uvBuff, noesis.RPGEODATA_HALFFLOAT, uvStride, 0)       #PSP Platform
        else:
            rapi.rpgBindNormalBufferOfs(vertBuff, noesis.RPGEODATA_FLOAT, vertStride, 12)
            rapi.rpgBindUV1BufferOfs(vertBuff, noesis.RPGEODATA_FLOAT, uvStride, 24)

    def parse_faces(self, faceStartOfs, faceBlockLength):
        #---Face---
        self.inFileNPKI.seek(faceStartOfs, NOESEEK_ABS)
        faceIndexCount = (int)(faceBlockLength/2)
        faceBuff = self.inFileNPKI.readBytes(faceBlockLength)
        rapi.rpgCommitTriangles(faceBuff, noesis.RPGEODATA_USHORT, faceIndexCount, noesis.RPGEO_TRIANGLE, 1)

    def parse_file(self):
        '''Main parser method'''            
        self.parse_bone()   #Parsing bone
        vtxBuff = self.bufferData[:self.bufferData.index(SCN_SIGN)]
        vtxOfsList = self.get_VTX_ofs(vtxBuff)

        for i in range(len(vtxOfsList)):
            
            self.inFile.seek(vtxOfsList[i], NOESEEK_ABS)
            self.inFile.seek(4, NOESEEK_REL)
            vtxDataLength = self.inFile.read(">i")[0]
            self.inFile.seek(8, NOESEEK_REL)
            dataStartOfs = self.inFile.tell()
            self.inFile.seek(6, NOESEEK_REL) #unknown bytes
            submeshId = self.inFile.read("h")[0]
            vertCount = self.inFile.readUInt()
            self.skip_dummy_bytes(submeshId)
            vertStride = self.inFile.readUInt()          # 30 00 00 00  = 48
            if submeshId != 516:
                vweightOfs = self.inFile.readUInt()
                vweightStride = self.inFile.readUInt()   # 20 00 00 00  = 32
                uvOfs = self.inFile.readUInt()
                uvStride = self.inFile.readUInt()        # 10 00 00 00  = 16 or 08 00 00 00 = 8
            self.inFile.seek(2, NOESEEK_REL)
            bindboneListOfs = self.inFile.readUShort()
            if bindboneListOfs:
                bindBoneList = self.getBindBoneList(dataStartOfs + bindboneListOfs, dataStartOfs + vtxDataLength)
            else:
                self.inFile.seek(dataStartOfs + vtxDataLength, NOESEEK_ABS)
            self.skip_dummy0()
            self.inFile.seek(32, NOESEEK_REL)
            vertStartOfs = self.inFile.readUInt()
            vertStartOfs = vertStartOfs & 0x0FFFFFFF
            self.inFile.seek(12, NOESEEK_REL)
            faceStartOfs = self.inFile.readUInt()
            faceStartOfs = faceStartOfs & 0x0FFFFFFF
            faceBlockLength = self.inFile.readUInt()

            self.inFile.seek(8, NOESEEK_REL)
            submeshName = self.inFile.readString()
            rapi.rpgSetName(submeshName)

            self.parse_vertices(submeshId, vertCount, vertStride, uvStride, vertStartOfs, bindBoneList)
            self.parse_faces(faceStartOfs, faceBlockLength)

        rapi.rpgSetOption(noesis.RPGOPT_SWAPHANDEDNESS, 1)
        pass
