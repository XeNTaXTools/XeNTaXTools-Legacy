Andy - Hiroshi97
-----------------
=====EXTRACT FILES=====
- Use QuickBMS and cmp_scz to decompressed the original files (npk, npki, npkv)
- Rename files to their original name (including extension)

=====OPEN MODELS IN NOESIS======
- Put fmt_SpikeGames_npk.py to ../Noesis/python/plugins
- Navigate to the location of files, and open .npk file

======GET 2ND MODEL======
- Drag & drop .npk file to NPKCutter.exe
- The extracted .npk file (xxx_2nd_model.npk) are ready to open
Note: If nothing happened, it doesn't have 2nd model

======EXTRACT TEXTURE======
- Drag & drop .npk file to NPKVExtractor.exe
- The textures will be extracted

Note: Make sure that all required file with the corresponding name are in the same folder with .npk file
-----------------
Andy - Hiroshi97