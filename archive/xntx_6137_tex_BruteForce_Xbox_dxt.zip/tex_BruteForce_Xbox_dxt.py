from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Brute Force [Xbox]", ".dxt")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
	#noesis.logPopup()
	return 1

def noepyCheckType(data):
    return 1
	
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    texInfo = rapi.getLocalFileName(rapi.getInputName())
    print(texInfo)    
    imgWidth = int(texInfo[16:20])
    print(imgWidth)
    imgHeight = int(texInfo[21:25])
    print(imgHeight)
    imgFmt = texInfo[26:28]
    print(imgFmt)
    #DXT3
    if imgFmt == "0e":
        texFmt = noesis.NOESISTEX_DXT3
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1