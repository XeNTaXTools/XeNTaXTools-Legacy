from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Atelier Nelke [PS Vita]", ".g1t")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    if noeStrFromBytes(bs.readBytes(8)) != 'GT1G0600': return 0
    return 1
    
def noepyLoadRGBA(data, texList):
    rapi.processCommands("-texnorepfn")
    bs = NoeBitStream(data)
    bs.seek(0x8, NOESEEK_ABS)
    filesize = bs.readUInt()
    tableOffset = bs.readInt()
    print(hex(tableOffset), "table offset")
    numTexs = bs.readUInt() #0x10
    print(numTexs, "numTexs")
    bs.seek(tableOffset, NOESEEK_ABS)
    baseOffset = bs.tell()
    for i in range(numTexs):
        if numTexs > 1:
            texName = i + 1
            texName = rapi.getExtensionlessName(rapi.getInputName()) + "_" + str(texName)
        else:
            texName = rapi.getInputName()
        offset = bs.readUInt()
        offset += baseOffset 
        tmp = bs.tell()
        bs.seek(offset, NOESEEK_ABS)
        unk = bs.readByte()
        imgFmt = bs.readUByte()
        #print(hex(imgFmt), ":format")
        width = bs.readBits(4)
        height = bs.readBits(4)
        #print(hex(width), "width")
        #print(hex(height), "height")
        imgWidth = 2 ** width
        imgHeight = 2 ** height
        print(imgWidth, "x", imgHeight, ":", hex(imgFmt), "imgFmt", "-", i)
        bs.seek(0x4, NOESEEK_REL)
        check = bs.readUByte()
        if check == 0x10:
            bs.seek(0xc, NOESEEK_REL)
        #DXT1
        if imgFmt == 0x10:
            datasize = (imgWidth * imgHeight) // 2
        #DXT5
        elif imgFmt == 0x12:
            datasize = imgWidth * imgHeight
        print(hex(datasize), "datasize")
        data = bs.readBytes(datasize)      
        #DXT1
        if imgFmt == 0x10:
            data = rapi.imageFromMortonOrder(data, imgWidth >> 1, imgHeight >> 2, 4)
            data = rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_DXT1) #DXT1 BC1
            texFmt = noesis.NOESISTEX_RGBA32
        #DXT5
        elif imgFmt == 0x12:
            data = rapi.imageFromMortonOrder(data, imgWidth >> 1, imgHeight >> 2, 8)
            data = rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_DXT5) #DXT1 BC1
            texFmt = noesis.NOESISTEX_RGBA32
        texList.append(NoeTexture(texName, imgWidth, imgHeight, data, texFmt))
        bs.seek(tmp, NOESEEK_ABS)
    return 1