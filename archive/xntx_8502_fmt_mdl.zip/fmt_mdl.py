#by Durik 256
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Macross PS2", ".mdl")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, LoadModel)
    return 1

def noepyCheckType(data):
    if data[:4] != b'GFX2':
        return 0
    return 1
    
def LoadModel(data, mdlList):
    bs = NoeBitStream(data)
    ctx = rapi.rpgCreateContext()
    
    result = [(i+27) for i in findall(b'\xC0\x03\x6E\x00\x00\x00', data)]

    for x in result:
        bs.seek(x)
        num = bs.readUInt()
        print('num:',num)
        bs.seek(4,1)
        vbuf = bs.read(num*32)
                
        rapi.rpgBindPositionBuffer(vbuf, noesis.RPGEODATA_FLOAT, 32)
        #rapi.rpgBindUV1BufferOfs(vbuf, noesis.RPGEODATA_FLOAT, 32, 24)
        rapi.rpgCommitTriangles(None, noesis.RPGEODATA_UINT, num, noesis.RPGEO_TRIANGLE_STRIP)
    
    mdl = rapi.rpgConstructModel()
    mdl.setModelMaterials(NoeModelMaterials([], [NoeMaterial('mat0','')]))
    mdlList.append(mdl)
    return 1


def findall(p, s):
    i = s.find(p)
    while i != -1:
        yield i
        i = s.find(p, i+1)