#by Durik256 for xentax
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("The Strongest Hero", ".axmd")
    noesis.setHandlerTypeCheck(handle, CheckType)
    noesis.setHandlerLoadModel(handle, LoadModel)
    return 1

def CheckType(data):
    bs = NoeBitStream(data)
    if bs.readBytes(4) != b'AXMD':
        return 0
    return 1
    
def LoadModel(data, mdlList):
    bs = NoeBitStream(data)
    ctx = rapi.rpgCreateContext()
    
    bs.seek(32)#AXMD,4097, 24 bytes unk
    
    attrib, zero = bs.readInt(), bs.readInt()
    model_name = noeAsciiFromBytes(bs.readBytes(bs.readInt()))
    
    attrib = [[noeAsciiFromBytes(bs.readBytes(4)), bs.readInt()] for x in range(attrib)]
    print(attrib)
    
    for name,offset in attrib:
        if name == 'MESH':
            bs.seek(offset)
            submesh = [[noeAsciiFromBytes(bs.readBytes(bs.readInt())), bs.readInt(), bs.readInt()] for x in range(bs.readInt())]
            stride = 40 if bs.readInt() > 2 else 36
            print('stride:',stride,submesh)
            
            if len(attrib) > 3:
                for x in range(len(submesh)):
                    bs.seek(bs.readInt(),1)
            
            all_v = sum([x[1] for x in submesh])
            vbuf = bs.readBytes(all_v*stride)

            for name,vnum,inum in submesh:
                ibuf = read_ibuf(bs, all_v, inum)#bs.readBytes(inum*2)
                
                rapi.rpgSetName(name)
                rapi.rpgBindPositionBuffer(vbuf, noesis.RPGEODATA_FLOAT, stride)
                rapi.rpgCommitTriangles(ibuf, noesis.RPGEODATA_USHORT, inum, noesis.RPGEO_TRIANGLE)
    
    mdl = rapi.rpgConstructModel()
    mdlList.append(mdl)
    return 1
    
def read_ibuf(bs, all_v, inum):
    ibuf = b''
    for x in range(inum):
        i = bs.readShort()
        if i > all_v: i = 0
        ibuf +=(i).to_bytes(2, 'little')
    return ibuf