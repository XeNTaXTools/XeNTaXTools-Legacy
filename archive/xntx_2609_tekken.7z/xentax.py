import struct
import math
import array

#
# WRITING LITTLE ENDIAN
#

def LE_write_uint32(ofile, x):
    ofile.write(struct.pack("<I", x));

def LE_write_uint64(ofile, x):
    ofile.write(struct.pack("<Q", x));
	
#
# READING LITTLE ENDIAN
#

def LE_read_sint08(ifile):
    return struct.unpack('<b', ifile.read(1))[0];
	
def LE_read_uint08(ifile):
    return struct.unpack('<B', ifile.read(1))[0];
	
def LE_read_sint16(ifile):
    return struct.unpack('<h', ifile.read(2))[0];
	
def LE_read_uint16(ifile):
    return struct.unpack('<H', ifile.read(2))[0];

def LE_read_sint32(ifile):
    return struct.unpack('<i', ifile.read(4))[0];
	
def LE_read_uint32(ifile):
    return struct.unpack('<I', ifile.read(4))[0];
	
def LE_read_sint64(ifile):
    return struct.unpack('<q', ifile.read(8))[0];
	
def LE_read_uint64(ifile):
    return struct.unpack('<Q', ifile.read(8))[0];

def LE_read_float16(ifile):

    # read unsigned short
    value = struct.unpack('<H', ifile.read(2))[0]; # read unsigned short

    # parse unsigned short into floating-point components
    temp = array.array('H', [0, 0, 0])
    temp[0] = (value & 0x8000);       # sign
    temp[1] = (value & 0x7C00) >> 10; # exponent
    temp[2] = (value & 0x03FF);       # mantissa

    # set sign constant
    sgn = 0.0;
    if temp[0] == 0:
       sgn = +1.0
    else:
       sgn = -1.0

    # if exponent is 0
    if temp[1] == 0:
       if temp[2] == 0:
          return 0.0
       else:
          return sgn*(math.pow(2.0, -14.0)*(temp[2]/1024.0));

    # if exponent is less than 32
    if temp[1] < 32:
       return sgn*math.pow(2.0, temp[1] - 15.0)*(1.0 + (temp[2]/1024.0));

    # half-float is invalid
    if temp[2] == 0:
       return math.NaN;

    # half-float is invalid
    return math.NaN;

def LE_read_float32(ifile):
    return struct.unpack('<f', ifile.read(4))[0];
	
def LE_read_float64(ifile):
    return struct.unpack('<d', ifile.read(8))[0];
	
#
# TRIANGLE FACE FUNCTIONS
#

def is_face_flipped(v1, v2, v3, n1, n2, n3):

    # compute a
    a = [ v2[0] - v1[0], v2[1] - v1[1], v2[2] - v1[2] ]
    da = math.sqrt(a[0]*a[0] + a[1]*a[1] + a[2]*a[2]);
    if da == 0: return False;
    a[0] /= da;
    a[1] /= da;
    a[2] /= da;
    
    # compute b
    b = [ v3[0] - v1[0], v3[1] - v1[1], v3[2] - v1[2] ];
    db = math.sqrt(b[0]*b[0] + b[1]*b[1] + b[2]*b[2]);
    if db == 0: return False;
    b[0] /= db;
    b[1] /= db;
    b[2] /= db;
    
    # compute c
    c = [ a[1]*b[2] - a[2]*b[1], a[2]*b[0] - a[0]*b[2], a[0]*b[1] - a[1]*b[0] ];
    dc = math.sqrt(c[0]*c[0] + c[1]*c[1] + c[2]*c[2]);
    if dc == 0: return False;
    c[0] /= dc;
    c[1] /= dc;
    c[2] /= dc;
    
    # compute average of vertex normals
    q = [ (n1[0] + n2[0] + n3[0])/3.0, (n1[1] + n2[1] + n3[1])/3.0, (n1[2] + n2[2] + n3[2])/3.0 ];
    dq = math.sqrt(q[0]*q[0] + q[1]*q[1] + q[2]*q[2]);
    if dq == 0: return False;
    q[0] /= dq;
    q[1] /= dq;
    q[2] /= dq;
    
    # now compute angle between two normals
    angle = math.acos((c[0]*q[0] + c[1]*q[1] + c[2]*q[2]));
    angle = angle*(180.0/3.1415);
	
	# return flipped status
    if angle > 90.0: return True;
    return False;
	
#
# DDS FUNCTIONS
#
def WriteUncompressedDDSHeader(ofile, dx, dy, mipmaps, maskR, maskG, maskB, maskA):

    # DDS constants
    DDSD_CAPS        = 0x00000001;
    DDSD_HEIGHT      = 0x00000002;
    DDSD_WIDTH       = 0x00000004;
    DDSD_PITCH       = 0x00000008;
    DDSD_PIXELFORMAT = 0x00001000;
    DDSD_MIPMAPCOUNT = 0x00020000;
    DDSD_LINEARSIZE  = 0x00080000;

    # DDS pixel formats
    DDPF_ALPHAPIXELS = 0x00000001;
    DDPF_ALPHA       = 0x00000002;
    DDPF_FOURCC      = 0x00000004;
    DDPF_RGB         = 0x00000040;

    # DDS capabilities
    DDSCAPS_COMPLEX  = 0x00000008;
    DDSCAPS_TEXTURE  = 0x00001000;
    DDSCAPS_MIPMAP   = 0x00400000;

	# flags
    flags = DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH | DDSD_PITCH | DDSD_PIXELFORMAT;
    caps1 = DDSCAPS_TEXTURE;
    caps2 = 0;
    if mipmaps != 0: caps2 = DDSCAPS_COMPLEX | DDSCAPS_MIPMAP;

    # pixel format
    format = DDPF_RGB
    if maskA != 0: format = format | DDPF_ALPHAPIXELS;
	
    # compute bits per pixel
    bpp = 0;
    if maskR != 0: bpp += 8;
    if maskG != 0: bpp += 8;
    if maskB != 0: bpp += 8;
    if maskA != 0: bpp += 8;
    pitch = int((bpp*dx + 7)/8);
 
    # save header
    ofile.write(bytes('DDS ', 'ascii')); # DDS
    LE_write_uint32(ofile, 124);         # dwSize
    LE_write_uint32(ofile, flags);       # dwFlags
    LE_write_uint32(ofile, dy);          # dwHeight
    LE_write_uint32(ofile, dx);          # dwWidth
    LE_write_uint32(ofile, pitch);       # dwPitchOrLinearSize
    LE_write_uint32(ofile, 0);           # dwDepth
    LE_write_uint32(ofile, mipmaps);     # dwMipMapCount
    LE_write_uint32(ofile, 0);           # dwReserved01
    LE_write_uint32(ofile, 0);           # dwReserved02
    LE_write_uint32(ofile, 0);           # dwReserved03
    LE_write_uint32(ofile, 0);           # dwReserved04
    LE_write_uint32(ofile, 0);           # dwReserved05
    LE_write_uint32(ofile, 0);           # dwReserved06
    LE_write_uint32(ofile, 0);           # dwReserved07
    LE_write_uint32(ofile, 0);           # dwReserved08
    LE_write_uint32(ofile, 0);           # dwReserved09
    LE_write_uint32(ofile, 0);           # dwReserved10
    LE_write_uint32(ofile, 0);           # dwReserved11
    LE_write_uint32(ofile, 32);          # pf.dwSize
    LE_write_uint32(ofile, format);      # pf.dwFlags
    LE_write_uint32(ofile, 0);           # pf.dwFourCC
    LE_write_uint32(ofile, bpp);         # pf.dwRGBBitCount
    LE_write_uint32(ofile, maskR);       # pf.dwRBitMask
    LE_write_uint32(ofile, maskG);       # pf.dwGBitMask
    LE_write_uint32(ofile, maskB);       # pf.dwBBitMask
    LE_write_uint32(ofile, maskA);       # pf.dwABitMask
    LE_write_uint32(ofile, caps1);       # dwCaps1
    LE_write_uint32(ofile, caps2);       # dwCaps2
    LE_write_uint32(ofile, 0);           # dwCaps3
    LE_write_uint32(ofile, 0);           # dwCaps4
    LE_write_uint32(ofile, 0);           # dwReserved12