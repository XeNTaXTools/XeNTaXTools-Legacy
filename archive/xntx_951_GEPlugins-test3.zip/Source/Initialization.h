/*
  Initialization.h
  Performs the initialization for GEPlugins
*/

#pragma once

// Required headers
#include "RPMCommon.h"
#include "Cache.h"

// Make sure we have the right JNI header
#ifndef JNI_VERSION_1_6
#error "Java/JNI 1.6 or higher is required!"
#endif

// Internal Structures
struct geEnvironment
{
	geEnvironment() :
		LastError(pERROR_OK),
		Initialized(false),
		//FlushCache(true),
		Cache(NULL),
		JvmBinaryHandle(NULL),
		Jvm(NULL),
		Env(NULL)
	{
	}

	// The last error code
	mpErrorCode LastError;

	// Current paths
	std::string JreBinary;
	std::string GESystemPath;
	std::string GEPluginPath;

	// Initialization state
	bool Initialized;
	//std::string CacheFilename; // TODO: What will happen to the cache?
	//bool FlushCache; // TODO: What will happen to the cache?
	geCache* Cache; // TODO: What will happen to the cache?

	// Java VM
	HMODULE JvmBinaryHandle;
	JavaVM* Jvm;
    JNIEnv* Env;
};

// Declarations for Helper Functions
bool InitializeEnvironment();
std::string FindJavaVM();
void UninitializeEnvironment();
bool InitializeJavaVM();
void UninitializeJavaVM();
void RetrievePluginInfo(std::string PluginName, geCache& Cache);
bool IsFile(const std::string& Filename);
bool IsZipFile(const std::string& Filename);
bool IsDirectory(const std::string& Path);
bool FindPlugins(const std::string& Path, std::vector<std::string>& ClassNames);

// The environment
extern geEnvironment g_Env;
