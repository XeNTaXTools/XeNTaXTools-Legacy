/*
  Archive.cpp
  A Game Extractor archive
*/

#include "stdafx.h"
#include "Archive.h"

// Constructors
geArchive::geArchive(JNIEnv* Env) :
	m_Env(Env),
	m_Resources(NULL)
{
	// FAIL! Creating archives is not yet supported.
	// TODO: Support creating archives
	return;
}

geArchive::geArchive(JNIEnv* Env, jobjectArray Resources) :
	m_Env(Env),
	m_Resources(Resources)
{
	// Create the name/index map
	CreateNameIndexMap();
	return;
}

geArchive::~geArchive()
{
	// Unref the resources
	if(m_Env && m_Resources)
	{
		m_Env->DeleteLocalRef(m_Resources);
		m_Resources=NULL;
	}
	return;
}

// General Methods
bool geArchive::IsOkay() const
{
	return m_Env && m_Resources ? true : false;
}

// Management
unsigned long geArchive::GetResourceCount() const
{
	// Make sure we're okay
	if(!IsOkay())
	{
		return 0;
	}

	// Get the number of elements in the array
	unsigned long NumberElements;
	NumberElements=m_Env->GetArrayLength(m_Resources);
	if(m_Env->ExceptionCheck())
	{
		m_Env->ExceptionClear();
		return 0;
	}
	return NumberElements;
}

geResource geArchive::GetResource(unsigned long Index) const
{
	// Make sure we're okay
	if(!IsOkay())
	{
		return geResource(m_Env);
	}

	// Get the array element
	jobject Resource;
	Resource=m_Env->GetObjectArrayElement(m_Resources, Index);
	if(!Resource)
	{
		m_Env->ExceptionClear();
		return geResource(m_Env);
	}
	return geResource(m_Env, Resource);
}

geResource geArchive::GetResource(const std::string& Name) const
{
	// Make sure we're okay
	if(!IsOkay())
	{
		return geResource(m_Env);
	}

	// Find the resource's index
	geNameIndexMap::const_iterator Iter;
	Iter=m_NameIndexMap.find(Name);
	if(Iter==m_NameIndexMap.end())
	{
		return geResource(m_Env);
	}

	// Get the resource by its index
	return GetResource(Iter->second);
}

/*void geArchive::SetResource(unsigned long Index, const geResource& NewResource)
{
	// TODO: Implement function SetResource
	return;
}*/

bool geArchive::CreateNameIndexMap()
{
	// Go through each file
	for(unsigned long i=0;i<GetResourceCount();i++)
	{
		// Get its name
		std::string Name;
		Name=GetResource(i).GetName();

		// Add it to the map
		geNameIndexMap::value_type Item(Name, i);
		m_NameIndexMap.insert(Item);
	}
	return true;
}

