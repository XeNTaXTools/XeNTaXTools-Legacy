/*
  Cache.cpp
  Cache for the plugin information
*/

#include "stdafx.h"
#include "Cache.h"

#define CACHE_SIGNATURE "GEPlugins Cache 1.0"

void WriteULong(std::ostream& Output, unsigned long Number)
{
	Output.write((char*)&Number, sizeof(unsigned long));
	return;
}

void WriteString(std::ostream& Output, const std::string& String)
{
	WriteULong(Output, (unsigned long)String.length());
	Output << String;
	return;
}

geCache::geCache()
{
	return;
}

geCache::geCache(const std::string& Filename)
{
	Load(Filename);
	return;
}

geCache::~geCache()
{
	return;
}

bool geCache::Load(const std::string& Filename)
{
	// TODO: Function Load
	return false;
}

bool geCache::Save(const std::string& Filename) const
{
	// Open the file
	std::ofstream Output;
	Output.open(Filename.c_str(), std::ios_base::out | std::ios_base::binary | std::ios_base::trunc);
	if(!Output.is_open())
	{
		return false;
	}

	// Write the signature
	Output.write(CACHE_SIGNATURE, sizeof(CACHE_SIGNATURE));

	// TODO: Function Save
	WriteULong(Output, GetCount());

	for(unsigned long i=0;i<GetCount();i++)
	{
		WriteString(Output, Get(i).Class);
		WriteString(Output, Get(i).GameName);
		WriteULong(Output, (unsigned long)Get(i).Extensions.size());
		for(std::vector<std::string>::const_iterator Iter=Get(i).Extensions.begin();Iter!=Get(i).Extensions.end();++Iter)
		{
			WriteString(Output, *Iter);
		}
	}
	return false;
}

unsigned long geCache::Add(const gePluginInfo& Info)
{
	m_Plugins.push_back(Info);
	m_Plugins.back().ExtensionList=GenerateExtensionList(m_Plugins.back().Extensions);
	m_Plugins.back().MexComDisplayString=m_Plugins.back().GameName+" [GE] ";
	return (unsigned long)m_Plugins.size()-1;
}

const geCache::gePluginInfo& geCache::Get(unsigned long Index) const
{
	assert(Index<GetCount());
	return m_Plugins[Index];
}

void geCache::Remove(unsigned long Index)
{
	assert(Index<GetCount());
	std::vector<gePluginInfo>::iterator Iter=m_Plugins.begin()+Index;
	m_Plugins.erase(Iter);
	return;
}

void geCache::Clear()
{
	m_Plugins.clear();
	return;
}

unsigned long geCache::GetCount() const
{
	return (unsigned long)m_Plugins.size();
}

unsigned long geCache::AddReal(const geRealPluginInfo& Info)
{
	m_RealPlugins.push_back(Info);
	return (unsigned long)m_RealPlugins.size()-1;
}

const geCache::geRealPluginInfo& geCache::GetReal(unsigned long Index) const
{
	assert(Index<GetCountReal());
	return m_RealPlugins[Index];
}

void geCache::RemoveReal(unsigned long Index)
{
	assert(Index<GetCountReal());
	std::vector<geRealPluginInfo>::iterator Iter=m_RealPlugins.begin()+Index;
	m_RealPlugins.erase(Iter);
	return;
}

void geCache::ClearReal()
{
	m_RealPlugins.clear();
	return;
}

unsigned long geCache::GetCountReal() const
{
	return (unsigned long)m_RealPlugins.size();
}


std::string geCache::GenerateExtensionList(const std::vector<std::string>& Extensions) const
{
	std::string String;
	bool First=true;
	for(std::vector<std::string>::const_iterator Iter=Extensions.begin();Iter!=Extensions.end();++Iter)
	{
		if(!First)
		{
			String.append("; ");
		}
		else
		{
			First=false;
		}
		String.append("*.");
		String.append(*Iter);
	}
	return String;
}
