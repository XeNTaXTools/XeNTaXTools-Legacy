/*
  GEPlugins.h
  Plugin for using Game Extractor Plugins with MexCom
*/

#pragma once

// Forward declarations
class geArchive;

// Find data
struct mpFindData
{
	geArchive* Archive;
	std::string FileMask;
	unsigned long CurrentPosition;
};
