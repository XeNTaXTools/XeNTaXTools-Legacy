/*
  VB.h
  The Visual Basic interface
*/

#include "stdafx.h"
#include "VB.h"
#include "Initialization.h"
#include "Plugin.h"

// Helper functions
BSTR OleString(const std::string& String)
{
	// Create an Ole string
	BSTR OleString;
	OleString=SysAllocStringByteLen(String.c_str(), (UINT)String.size());
	return OleString;
}

std::string NormalString(const BSTR String)
{
	return std::string((const char*)String, SysStringByteLen(String));
}

// Implementation

longbool _stdcall geIsInited()
{
	return g_Env.Initialized;
}

BSTR _stdcall geFindJavaVM()
{
	return OleString(FindJavaVM());
}

BSTR _stdcall geGetJavaVMPath()
{
	return OleString(g_Env.JreBinary);
}

longbool _stdcall geSetJavaVMPath(const BSTR Path)
{
	// Convert
	std::string JvmPath;
	JvmPath=NormalString(Path);

	// If we're already initialized, this could cause some problems
	if(g_Env.Initialized)
	{
		return false;
	}
	else
	{
		g_Env.JreBinary=JvmPath;
	}
	return true;
}

BSTR _stdcall geGetGESystemPath()
{
	return OleString(g_Env.GESystemPath);
}

longbool _stdcall geSetGESystemPath(const BSTR Path)
{
	// Convert
	std::string SysPath;
	SysPath=NormalString(Path);

	// Make sure it exists
	if(!IsZipFile(SysPath) && !IsDirectory(SysPath))
	{
		return false;
	}

	// If we're already initialized, this could cause some problems
	if(g_Env.Initialized)
	{
		// TODO: This
		g_Env.GESystemPath=SysPath;
	}
	else
	{
		g_Env.GESystemPath=SysPath;
	}
	return true;
}

BSTR _stdcall geGetGEPluginPath()
{
	return OleString(g_Env.GEPluginPath);
}

longbool _stdcall geSetGEPluginPath(const BSTR Path)
{
	// Convert
	std::string PlugPath;
	PlugPath=NormalString(Path);

	// Make sure it exists
	if(!IsZipFile(PlugPath) && !IsDirectory(PlugPath))
	{
		return false;
	}

	// If we're already initialized, this could cause some problems
	if(g_Env.Initialized)
	{
		// TODO: This
		g_Env.GEPluginPath=PlugPath;
	}
	else
	{
		g_Env.GEPluginPath=PlugPath;
	}
	return true;
}

unsigned long _stdcall geGetPluginCount()
{
	// Make sure we're initialized
	if(!InitializeEnvironment())
	{
		return 0;
	}
	return g_Env.Cache->GetCountReal();
}

longbool _stdcall geGetPluginInfo(unsigned long Index, gePluginInfo_OLE& Info)
{
	// Make sure we're initialized
	if(!InitializeEnvironment())
	{
		return false;
	}

	// Check the argument
	if(Index>=g_Env.Cache->GetCountReal())
	{
		return false;
	}

	// Check the size
	if(Info.SizeOfThis!=sizeof(gePluginInfo_OLE))
	{
		return false;
	}

	// Clear the structure
	memset(&Info, 0, sizeof(gePluginInfo_OLE));
	Info.SizeOfThis=sizeof(gePluginInfo_OLE);

	// Set the class
	const geCache::geRealPluginInfo& Plugin=g_Env.Cache->GetReal(Index);
	Info.Class=OleString(Plugin.Class);

	// Create the games array
	SAFEARRAYBOUND Bounds[1];
	Bounds[0].lLbound=0;
	Bounds[0].cElements=(unsigned long)Plugin.Games.size();
	Info.Games=SafeArrayCreate(VT_BSTR, 1, Bounds);
	if(Info.Games)
	{
		if(!FAILED(SafeArrayLock(Info.Games)))
		{
			// Fill this array with strings
			BSTR* Data=(BSTR*)Info.Games->pvData;
			for(unsigned long i=0;i<(unsigned long)Plugin.Games.size();i++)
			{
				Data[i]=OleString(Plugin.Games[i]);
			}
			SafeArrayUnlock(Info.Games);
			Info.GameCount=(unsigned long)Plugin.Games.size();
		}
	}

	// Create the extensions array
	Bounds[0].lLbound=0;
	Bounds[0].cElements=(unsigned long)Plugin.Extensions.size();
	Info.Extensions=SafeArrayCreate(VT_BSTR, 1, Bounds);
	if(Info.Extensions)
	{
		if(!FAILED(SafeArrayLock(Info.Extensions)))
		{
			// Fill this array with strings
			BSTR* Data=(BSTR*)Info.Extensions->pvData;
			for(unsigned long i=0;i<(unsigned long)Plugin.Extensions.size();i++)
			{
				Data[i]=OleString(Plugin.Extensions[i]);
			}
			SafeArrayUnlock(Info.Extensions);
			Info.ExtensionCount=(unsigned long)Plugin.Extensions.size();
		}
	}
	return true;
}

struct SMatchRating
{
	long Rating;
	unsigned long Index;
};

struct SBetterMatch : public std::binary_function <SMatchRating, SMatchRating, bool> 
{
	bool operator()(const SMatchRating& _Left, const SMatchRating& _Right) const
	{
		return _Left.Rating>_Right.Rating ? true : false;
	}
};

longbool _stdcall geOpenArchiveByAny(mpArchiveHandle& ArchiveHandle, BSTR Filename, mpOpenFlags Flags, BSTR& ClassName)
{
	// Make sure we're initialized
	if(!InitializeEnvironment())
	{
		return false;
	}

	// Clear some values
	ArchiveHandle=NULL;
	ClassName=NULL;

	// Check the flags
	if(Flags & OPENFLAG_CREATENEW)
	{
		// TODO: Creating a new archive is not supported
		return false;
	}
	if(Flags & OPENFLAG_FORIMPORT)
	{
		// TODO: Editing an existing archive is not supported
		return false;
	}

	// Load the archive
	if((Flags & OPENFLAG_OPENALWAYS) || (Flags & OPENFLAG_FOREXPORT))
	{
		// Make sure this file exists
		std::string ArchiveFilename;
		ArchiveFilename=NormalString(Filename);

		// Get all the match ratings
		std::list<SMatchRating> Ratings;
		for(unsigned long i=0;i<g_Env.Cache->GetCountReal();i++)
		{
			// Create the plugin
			gePlugin Plugin(g_Env.Env, g_Env.Cache->GetReal(i).Class);
			if(!Plugin.IsOkay())
			{
				return false;
			}

			// Get the match rating
			SMatchRating Match;
			Match.Index=i;
			Match.Rating=Plugin.GetMatchRating(ArchiveFilename);
			Ratings.push_back(Match);
		}
		Ratings.sort(SBetterMatch());

		// Discover what plugin can load this file
		geArchive* Archive=NULL;
		for(std::list<SMatchRating>::const_iterator Iter=Ratings.begin();Iter!=Ratings.end();++Iter)
		{
			// Check the match rating
			const SMatchRating& Match=*Iter;
			if(Match.Rating<25)
			{
				break;
			}

			// Create a new plugin
			gePlugin Plugin(g_Env.Env, g_Env.Cache->GetReal(Match.Index).Class);
			if(!Plugin.IsOkay())
			{
				return false;
			}

			// Read the archive
			Archive=Plugin.Read(ArchiveFilename);
			if(Archive)
			{
				ClassName=OleString(g_Env.Cache->GetReal(Match.Index).Class);
				break;
			}
		}

		// Couldn't find anything
		if(!Archive)
		{
			MessageBox(0, "The archive could not be loaded.", "Error", MB_ICONSTOP);
			mpSetLastError(pERROR_ARCHIVE_READ_ERROR);
			return false;
		}

		// Set this as the archive
		ArchiveHandle=Archive;
	}
	return true;
}

longbool _stdcall geOpenArchiveByClass(mpArchiveHandle& ArchiveHandle, BSTR ClassName, BSTR Filename, mpOpenFlags Flags)
{
	// Make sure we're initialized
	if(!InitializeEnvironment())
	{
		return false;
	}

	// Clear some values
	ArchiveHandle=NULL;

	// Check the flags
	if(Flags & OPENFLAG_CREATENEW)
	{
		// TODO: Creating a new archive is not supported
		return false;
	}
	if(Flags & OPENFLAG_FORIMPORT)
	{
		// TODO: Editing an existing archive is not supported
		return false;
	}

	// Load the archive
	if((Flags & OPENFLAG_OPENALWAYS) || (Flags & OPENFLAG_FOREXPORT))
	{
		// Create a new plugin
		gePlugin Plugin(g_Env.Env, NormalString(ClassName));
		if(!Plugin.IsOkay())
		{
			return false;
		}

		// Read the archive
		geArchive* Archive;
		Archive=Plugin.Read(NormalString(Filename));
		if(!Archive)
		{
			MessageBox(0, "The archive could not be loaded.", "Error", MB_ICONSTOP);
			mpSetLastError(pERROR_ARCHIVE_READ_ERROR);
			return false;
		}

		// Set this as the archive
		ArchiveHandle=Archive;
	}
	return true;
}

longbool _stdcall geOpenArchiveByIndex(mpArchiveHandle& ArchiveHandle, unsigned long PluginIndex, BSTR Filename, mpOpenFlags Flags)
{
	// Make sure we're initialized
	if(!InitializeEnvironment())
	{
		return false;
	}

	// Check the arguments
	if(PluginIndex>=g_Env.Cache->GetCountReal())
	{
		return false;
	}

	// Clear some values
	ArchiveHandle=NULL;

	// Check the flags
	if(Flags & OPENFLAG_CREATENEW)
	{
		// TODO: Creating a new archive is not supported
		return false;
	}
	if(Flags & OPENFLAG_FORIMPORT)
	{
		// TODO: Editing an existing archive is not supported
		return false;
	}

	// Load the archive
	if((Flags & OPENFLAG_OPENALWAYS) || (Flags & OPENFLAG_FOREXPORT))
	{
		// Create a new plugin
		gePlugin Plugin(g_Env.Env, g_Env.Cache->GetReal(PluginIndex).Class);
		if(!Plugin.IsOkay())
		{
			return false;
		}

		// Read the archive
		geArchive* Archive;
		Archive=Plugin.Read(NormalString(Filename));
		if(!Archive)
		{
			MessageBox(0, "The archive could not be loaded.", "Error", MB_ICONSTOP);
			mpSetLastError(pERROR_ARCHIVE_READ_ERROR);
			return false;
		}

		// Set this as the archive
		ArchiveHandle=Archive;
	}
	return true;
}
