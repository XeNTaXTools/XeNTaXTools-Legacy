/*
  Cache.h
  Cache for the plugin information
*/

#pragma once

// The cache
class geCache
{
public:
	struct geRealPluginInfo
	{
		std::string Class;
		std::vector<std::string> Games;
		std::vector<std::string> Extensions;
	};

	struct gePluginInfo
	{
		// General Information
		std::string Class;
		std::string GameName;
		std::vector<std::string> Extensions;

		// Automatically Generated
		std::string MexComDisplayString;
		std::string ExtensionList;
	};

public:
	geCache();
	geCache(const std::string& Filename);
	virtual ~geCache();
	virtual bool Load(const std::string& Filename);
	virtual bool Save(const std::string& Filename) const;
	virtual unsigned long Add(const gePluginInfo& Info);
	virtual const gePluginInfo& Get(unsigned long Index) const;
	virtual void Remove(unsigned long Index);
	virtual void Clear();
	virtual unsigned long GetCount() const;
	
	virtual unsigned long AddReal(const geRealPluginInfo& Info);
	virtual const geRealPluginInfo& GetReal(unsigned long Index) const;
	virtual void RemoveReal(unsigned long Index);
	virtual void ClearReal();
	virtual unsigned long GetCountReal() const;

protected:
	virtual std::string GenerateExtensionList(const std::vector<std::string>& Extentions) const;

private:
	std::vector<gePluginInfo> m_Plugins;
	std::vector<geRealPluginInfo> m_RealPlugins;
};
