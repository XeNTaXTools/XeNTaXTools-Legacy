/*
  VB.h
  The Visual Basic interface
*/

#pragma once

// Required headers
#include "Initialization.h"

// All structures defined here are packed to one byte
#pragma pack(push, 1)

// Check if we are initialized
longbool _stdcall geIsInited();

// Find the Java VM
BSTR _stdcall geFindJavaVM();

// Get the path to the Java VM (currently saved path; different from geFindJavaVM)
BSTR _stdcall geGetJavaVMPath();

// Set the path to the Java VM
longbool _stdcall geSetJavaVMPath(const BSTR Path);

// Get the Game Extractor system (GameExtractor.jar) path
BSTR _stdcall geGetGESystemPath();

// Set the Game Extractor system path
longbool _stdcall geSetGESystemPath(const BSTR Path);

// Get the Game Extractor plugin path
BSTR _stdcall geGetGEPluginPath();

// Set the Game Extractor plugin path
longbool _stdcall geSetGEPluginPath(const BSTR Path);

// Get the total number of plugins
unsigned long _stdcall geGetPluginCount();

// Plugin information
struct gePluginInfo_OLE
{
	unsigned long SizeOfThis;
	BSTR Class;
	unsigned long GameCount;
	SAFEARRAY* Games;
	unsigned long ExtensionCount;
	SAFEARRAY* Extensions;
};

// Get infomation about a particular plugin
longbool _stdcall geGetPluginInfo(unsigned long Index, gePluginInfo_OLE& Info);

// Load an archive using any plugin
longbool _stdcall geOpenArchiveByAny(mpArchiveHandle& ArchiveHandle, BSTR Filename, mpOpenFlags Flags, BSTR& ClassName);

// Load an archive using a plugin class name
longbool _stdcall geOpenArchiveByClass(mpArchiveHandle& ArchiveHandle, BSTR ClassName, BSTR Filename, mpOpenFlags Flags);

// Load an archive using a plugin index
longbool _stdcall geOpenArchiveByIndex(mpArchiveHandle& ArchiveHandle, unsigned long PluginIndex, BSTR Filename, mpOpenFlags Flags);

// End of header
#pragma pack(pop)
