import os,struct,glob,codecs

def get_text(offset,new):
    fl.seek(offset)
    start2 = fl.tell()
    while 1:
        test, = struct.unpack('B',fl.read(1))
        if test == 0:
            end2 = fl.tell()
            break
    fl.seek(start2)
    text = fl.read(end2-start2).decode('cp932').rstrip('\x00')
    text = text.replace('\r','\\r')
    text = text.replace('\n','\\n')
    new.write(text)
    new.write('\r\n')

srcfiles = glob.iglob('mail.cat_unpacked\\*.bin')

for src in srcfiles:
    fl = open(src,'rb')
    dirname = os.path.dirname(src)
    testname = dirname.split('_')[0]
    filename = os.path.basename(src)
    basename,extname = os.path.splitext(filename)
    
    if os.path.isdir(testname+'_txt\\') == False:
        os.mkdir(testname+'_txt\\')
        
    new = codecs.open(testname+'_txt\\'+basename+'.txt','wb','utf16')
    print(testname+'_txt\\'+basename+'.txt')
    
    fl.seek(0x4)
    offset, = struct.unpack('>I',fl.read(4))
    start = offset - 4
    get_text(offset,new)
    
    fl.seek(0x8)
    offset, = struct.unpack('>I',fl.read(4))
    get_text(offset,new)
    
    fl.seek(0x14)
    
    for i in range(6):
        offset, = struct.unpack('>I',fl.read(4))
        breakpoint = fl.tell()
        get_text(offset,new)
        fl.seek(breakpoint)
        
    fl.seek(start)
    offset, = struct.unpack('>I',fl.read(4))
    get_text(offset,new)
    
    fl.close()
    new.close()
    