import io,os,struct,glob

srcfiles = glob.iglob('*.cat')

for src in srcfiles:
    fl = open(src,'rb')
    filename = os.path.basename(src)

    if os.path.isdir(filename+'_unpacked\\') == False:
        os.mkdir(filename+'_unpacked\\')

    fl.seek(0xC)
    value1, = struct.unpack('>I',fl.read(4))
    fl.seek(0x24)
    files, = struct.unpack('>I',fl.read(4))
    value2 = files
    value2 *= 4
    value2 += 0x34

    fl.seek(0x34)

    for i in range(files):
        offset, = struct.unpack('>I',fl.read(4))
        offset += value1
        breakpoint = fl.tell()
        fl.seek(value2)
        size, = struct.unpack('>I',fl.read(4))
        value2 = fl.tell()
        name = ('%08d' % i)
        new = open(filename+'_unpacked\\'+str(name)+'.bin','wb')
        print(filename+' >> '+str(name)+'.bin')
        fl.seek(offset)
        new.write(fl.read(size))
        new.close()

        fl.seek(breakpoint)

        
    fl.close()
