import os,struct,glob,codecs

srcfiles = glob.iglob('script*.cat_unpacked\\*.bin')

for src in srcfiles:
    fl = open(src,'rb')
    dirname = os.path.dirname(src)
    testname = dirname.split('_')[0]
    filename = os.path.basename(src)
    basename,extname = os.path.splitext(filename)
    
    if os.path.isdir(testname+'_txt\\') == False:
        os.mkdir(testname+'_txt\\')
        
    new = codecs.open(testname+'_txt\\'+basename+'.txt','wb','utf16')
    print(testname+'_txt\\'+basename+'.txt')
    
    fl.seek(0x10)
    start1, = struct.unpack('>I',fl.read(4))
    fl.seek(start1)
    end1, = struct.unpack('>I',fl.read(4))
    fl.seek(start1)
    files = (end1-start1)//4

    for i in range(files):
        offset, = struct.unpack('>I',fl.read(4))
        breakpoint = fl.tell()
        if offset == 0:
            break
        else:
            fl.seek(offset)
            start2 = fl.tell()
            while 1:
                test, = struct.unpack('B',fl.read(1))
                if test == 0:
                    end2 = fl.tell()
                    break
            fl.seek(start2)
            text = fl.read(end2-start2).decode('cp932').rstrip('\x00')
            new.write(text)
            new.write('\r\n')
            fl.seek(breakpoint)
    
    fl.close()
    new.close()
    