/*

	SPF file dumper
	WRS (xentax.com)

	main.c
	0.2
		Updated my recursive directory function
	0.1
		Finished parsing the filenames recursively
*/

#include <windows.h>
#include <stdio.h>

void parseSpf( char *, unsigned int );

char *getRunningName( char *arg )
{
	if( !( *arg ) )
		return 0;

	// to last char
	while( *arg ) ++arg; --arg;
	
	// find last backslash
	while( *arg && !(*arg=='\\') ) --arg;
	if( *arg ) ++arg;
	
	return arg;
}

void makeDir( char *str )
{
	if( str )
		CreateDirectory( str, NULL );
}

void createDirRec( char *str )
{
	char *pstr;
	
	if( !str ) return;
	
	pstr = str;
	
	while( *str )
	{
		// swap slashes
		
		if( *str == '\\' )
			*str = '/';
	
		// whitelist characters (default to underscore)
	
		if( !(	// a..z
				(*str >= 'a' && *str <= 'z')
				// A..Z
				|| (*str >= 'A' && *str <= 'Z')
				// 0..9
				|| (*str >= '0' && *str <= '9')
				// period
				|| (*str == '.')
				// slash
				|| (*str == '/')
				// underscore
				|| (*str == '_')
			)
		)
			*str = '_';
		
		// make all directories
		
		if( *str == '/' && str-pstr > 1 )
		{
			*str = 0;
			// cut leading slash
			makeDir( (*pstr=='/') ? pstr+1 : pstr );
			*str = '/';
		}
		
		++str;
	}
}

int main( int argc, char **argv )
{
	char *buf;
	unsigned int len;
	FILE *pFile;

	printf( "SPF file dumper - WRS (xentax.com)\n\n" );
	
	switch( argc )
	{
		case 2:
		{
			break;
		}
		default:
		{
			printf( " Usage:\n" );
			printf( "\t%s <spf filename>\n", getRunningName( argv[0] ) );
			printf( " NOTE:\n\tFiles are outputted to the same directory\n\n" );
			
			return 0;
		}
	}
	
	if( !(pFile = fopen( argv[ 1 ], "rb" )) )
	{
		printf( "Cannot open \"%s\"\n", argv[ 1 ] );
		return 0;
	}
	
	fseek( pFile, 0, SEEK_END );
	len = ftell( pFile );
	fseek( pFile, 0, SEEK_SET );

	if( len == 0 )
	{
		printf( "Empty file\n" );
		return 0;
	}

	if( (buf = (char *)malloc( len )) )
	{
		if( fread( buf, 1, len, pFile ) != len )
		{
			free( buf );
			
			printf( "Error reading data\n" );
			return 0;
		}
		
		fclose( pFile );
		
		parseSpf( buf, len );
		
		free( buf );
		return 1;
	}
	else
	{
		printf( "Error allocating %u bytes\n", len );
		return 0;
	}
}

//
// SPF-specific
//

char **g_filenames;

void parseStr( char *, char *, const unsigned int );
void initFilenames( unsigned int );
void freeFilenames( unsigned int );
void addFilename( char *, unsigned int );

const char SPF_HEAD[] = "SGDP Package File.";

typedef struct spf_offset
{
	unsigned int fnames;
	unsigned int fpositions;
	unsigned int fother;
};

//typedef unsigned long SPF_FNCHUNK;

typedef struct spf_fnhead
{
	char fn_data[ 4 ];
	//SPF_FNCHUNK fn_data;	
	unsigned int fn_offset;
};

typedef struct spf_fohead
{
	unsigned int fo_offset;
	unsigned int fo_size;
};

int testHeader( char *totest )
{
	int i;
	
	i = 0;
	
	while( i < sizeof( SPF_HEAD ) -1 )
	{
		if( !( totest[ i ] == SPF_HEAD[ i ] ) )
			return 0;
		++i;
	}

	return 1;
}

#define spf_get(src,buf,len){ memcpy(buf,src,len); src+=len; }
#define spf_geti(src,i){ i = *(unsigned int *)src; src+=sizeof(unsigned int); }

void parseSpf( char *data, unsigned int len )
{
	char head[ 0x20 ];
	struct spf_offset offsets;
	struct spf_fohead foffsets;
	unsigned int fcount;
	unsigned int i;
	char * const pdata = data;
	
	#define spf_pos (data-pdata)
	#define spf_skip(x){ data+=x; }
	#define spf_seek(x){ data=pdata+x; }
	
	spf_get( data, head, sizeof( head ) );
	
	if( testHeader( &head ) == 0 )
	{
		printf( "Unrecognized SPF format\n" );
		return;
	}
	
	spf_skip( 4 ); // DUMMY
	spf_skip( 4 ); // DUMMY
	
	spf_get( data, &offsets, sizeof( struct spf_offset ) );
	spf_geti( data, fcount );
	
	spf_skip( 4 ); // CRC ?
	
	//
	// filenames!
	//
	
	initFilenames( fcount );
	
	spf_seek( offsets.fnames );
	
	// arg1 = current position
	// arg2 = pointer to string buffer
	// arg3 = pointer to start of offset data (happens to be the current position)
	
	parseStr( data, NULL, (unsigned int)data );
	
	/*
	printf( "Ordered file list:\n\n" );
	
	for( i = 0; i < fcount; ++i )
		if( g_filenames[ i ] )
			printf( "%i\t%s\n", i+1, g_filenames[ i ] );
	*/
	
	//
	// data!
	//
	
	spf_seek( offsets.fpositions );
	
	for( i = 0; i < fcount; ++i )
	{
		FILE *fOutFile;
		
		spf_get( data, &foffsets, sizeof( struct spf_fohead ) );
		
		// check there is a filename stored (should be)
		
		if( g_filenames[ i ] == NULL )
		{
			char tmpName[8 +5];
			
			// create a temporary name
			
			sprintf( tmpName, "%08X.dat\0", i );
			
			printf( "%s..", tmpName );
			
			fOutFile = fopen( tmpName, "wb" );
		}
		else
		{
			char *fn;
			
			fn = g_filenames[ i ];
			if( *fn == '/' ) ++fn;
			
			createDirRec( fn );
			
			printf( "%s..", fn );
			
			fOutFile = fopen( fn, "wb" );
		}
		
		if( fOutFile )
		{
			// try writing the file data
			
			fwrite( (pdata + foffsets.fo_offset + 4), 1, foffsets.fo_size, fOutFile );
			fclose( fOutFile );
			
			printf(" done!\n" );
		}
		else
		{
			printf( " problem creating file\n" );
		}
	}
	
	freeFilenames( fcount );
	
}

/*
	Recursive function to parse the filenames, which are stored as a binary tree
	Each node has 4-bytes of data, followed by a either:
		A branch offset to the next node
		OR
		The filename index and the byte FFh
*/
void parseStr( char *data, char *namebuf, const unsigned int offset )
{
	unsigned int nlen;
	unsigned int count;
	unsigned int i;
	struct spf_fnhead fnhead;
	
	// may be null (first instance)
	nlen = namebuf ? strlen( namebuf ) : 0; // todo: just the size
	
	spf_geti( data, count );
	
	for( i = 0; i < count; ++i )
	{
		char *n_namebuf;

		// not freed when being added the g_filenames buffer
		n_namebuf = (char *)malloc( nlen + 5 );
		
		// may be null
		if( namebuf ) memcpy( n_namebuf, namebuf, nlen );
		
		spf_get( data, &fnhead, sizeof( struct spf_fnhead ) );	

		memcpy( n_namebuf + nlen, fnhead.fn_data, 4 );
		
		n_namebuf[ nlen + 4 ] = 0;		
		
		//
		// check that fn_offset is either another offset or a end-of-node marker
		// FF xx xx xx
		// ^^          marker
		//    ^^ ^^ ^^ file index
		//
		if( fnhead.fn_data[0] == 0 || fnhead.fn_offset >= (0xFF << 24) )
		{
			
			addFilename( n_namebuf, (unsigned int)(fnhead.fn_offset & 0xFFFFFF) );
			
		}
		else
		{
			// 'offset' is the data offset to the buffer
			
			parseStr( (char *)(offset + fnhead.fn_offset), n_namebuf, offset );
			
			// the name buffer is freed here because it is copied into the new buffer in the parseStr call
			free( n_namebuf );
		}
	}
	
}

void initFilenames( unsigned int fnCount )
{
	unsigned int i;
	
	if( g_filenames ) return;
	
	if( !( g_filenames = (char **)malloc( sizeof( char * ) * fnCount ) ) )
	{
		printf( "Error allocating memory\n" );
		return;
	}
	
	for( i = 0; i < fnCount; ++i )
		g_filenames[ i ] = NULL;
}

void freeFilenames( unsigned int fnCount )
{
	int i;
	
	if( !g_filenames ) return;
	if( !g_filenames[0] ) return;
	
	for( i = 0; i < fnCount; ++i )
	{
		free( g_filenames[ i ] );
		g_filenames[ i ] = NULL;
	}
	
	free( g_filenames );
	g_filenames = NULL;
}

void addFilename( char *fnStr, unsigned int fnIndex )
{
	if( !g_filenames ) return;
	
	g_filenames[ fnIndex ] = fnStr;
}

