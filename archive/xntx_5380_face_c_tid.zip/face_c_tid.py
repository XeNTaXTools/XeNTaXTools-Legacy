from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("face_c", ".tid")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

#check if it's this type based on the data
def noepyCheckType(data):
    bs = NoeBitStream(data)
    fileName = rapi.getLocalFileName(rapi.getInputName())
    if "face_c" not in fileName:
        return 0
    return 1
	
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.seek(0x44, NOESEEK_ABS)
    imgWidth = bs.readInt()            
    imgHeight = bs.readInt()           
    bs.seek(0x80, NOESEEK_ABS)        
    datasize = len(data) - 0x80        
    data = bs.readBytes(datasize)      
    data = rapi.imageFromMortonOrder(data, imgWidth>>1, imgHeight>>2, 4)
    texFmt = noesis.NOESISTEX_DXT1
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1