from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Mobile Suit Gundam Side Stories", ".bin")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
	#noesis.logPopup()
	return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    Magic = bs.readBytes(4)
    if Magic != b'\x02\x01\x01\x00':
        return 0
    return 1   
	
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.setEndian(NOE_BIGENDIAN)
    while bs.getOffset() < bs.getSize():
        tmp = bs.tell()
        print(hex(bs.tell()), ":start header")
        bs.seek(0x4, NOESEEK_REL) 
        nextTexOffset = bs.readUInt() + 0x80        
        bs.seek(0xc, NOESEEK_REL)
        datasize = bs.readUInt()
        print(hex(datasize), ":datasize")
        imgFmt = bs.readUByte()
        print(imgFmt, ":imgFmt")
        bs.seek(0x7, NOESEEK_REL)         
        imgWidth = bs.readUShort()         
        print(imgWidth, ":imgWidth")
        imgHeight = bs.readUShort()        
        print(imgHeight, ":imgHeight")
        bs.seek(0x5c, NOESEEK_REL)         
        print(hex(bs.tell()), ":start data")
        data = bs.readBytes(datasize)      
        if imgFmt == 0x86:
            texFmt = noesis.NOESISTEX_DXT1
        elif imgFmt == 0x88:
            texFmt = noesis.NOESISTEX_DXT5
        texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
        bs.seek(nextTexOffset + tmp, NOESEEK_ABS)
    return 1