from inc_noesis import *

#Version 1.0

# =================================================================
# Plugin Options
# =================================================================

bLoadCollisionMeshes = False					# Loads collision meshes if True

# =================================================================
# Misc
# =================================================================

#The noesis function necessary to declare the plugin
def registerNoesisTypes():
	handle = noesis.register("star",".smf")
	noesis.setHandlerTypeCheck(handle, CheckType)
	noesis.setHandlerLoadModel(handle, LoadModel)	
	return 1
	
#The noesis checktype function, just verify if the file is valid
def CheckType(data):
	bs = NoeBitStream(data)
	if len(data) < 16:
		print("Invalid file, too small")
		return 0
	return 1
	
# =================================================================
# Helper functions
# =================================================================	

#A helper function to place the binary reader correctly
def Align(bs, n):
	value = bs.tell() % n
	if (value):
		bs.seek(n - value, 1)

#Same but place reader at beginning, not end	
def AlignReverse(bs,n):
	value = bs.tell() % n
	if (value):
		bs.seek(bs.tell() - value)

#A "cheat" function to jump to indices directly	
def findIndices(bs):
	indexFlag = b'\x00\x00\x00\x01\x00\x02\x00'
	a=True
	while a:
		checkPoint = bs.tell()
		temp = bs.readBytes(0x7)
		if temp == indexFlag:
			bs.seek(checkPoint)
			a = False
		else :
			bs.seek(checkPoint+1)
	return 1

#Better cheat function for nested buffers, more consistent
def findIndices2(bs):
	a=0
	while not a:
		a=bs.readByte()
	AlignReverse(bs,0x10)
	return 1

# =================================================================
# Model loading
# =================================================================

#The actual model loading function
def LoadModel(data, mdlList):
	
	#Initialize context, set up the stream reader and its endianess
	ctx = rapi.rpgCreateContext()
	bs = NoeBitStream(data)
	bs.setEndian(NOE_LITTLEENDIAN)
	
	#Some helper lists, collision meshes are at the beginning, followed by the actual meshes.
	colMeshvBuffers = []
	colMeshidxBuffers = []
	vBuffers = []
	vBuffersLengths = []
	idxBuffers = []
	colMeshfCounts = []
	vcounts = []
	fcounts = []
	subMeshesNames = []
	colMeshNames = []
	meshBufferSizes = []
	
	#header
	bs.readBytes(0x28)
	subMeshCount = bs.readUInt()
	colMeshCount = bs.readUInt()
	stringCount = bs.readUInt()
	filenameCount = bs.readUInt()
	bs.readBytes(0x8)
		
	#Some material info is there sometimes, to avoid parsing it we just look for filenames directly, checking if there's '\' in the name
	#to avoid false positives (ex: "diffuse", "params" etc)
	filenameList = []
	while len(filenameList) < filenameCount:
		checkPoint = bs.tell()
		try:
			a = bs.readString()
			if '\\' in a:
				filenameList.append(a)
			Align(bs,4)
			checkPoint = bs.tell()
		except:
			bs.seek(checkPoint+4)
			checkPoint = bs.tell()
			
	#Filenames have been read, collision mesh section starts	
	for _ in range(colMeshCount):
		checkPoint = bs.tell()
		colMeshNames.append(bs.readString())
		bs.seek(checkPoint+56)
		vcount = bs.readUInt()
		fcount = bs.readUInt()
		posBuffer = bytes()
		idxBuffer = bytes()
		for _ in range(vcount):
			posBuffer += bs.readBytes(0xC)
		for _ in range(fcount*3):
			idxBuffer += bs.readBytes(0x2)
		colMeshvBuffers.append(posBuffer)
		colMeshidxBuffers.append(idxBuffer)
		colMeshfCounts.append(fcount)
		#unknown stuff that we skip
		bs.readBytes(fcount)
		bs.readUInt()
		bs.readUInt()
		count = bs.readUInt()
		for _ in range(count*2-1):
			bs.readBytes(0x18)
			flag = bs.readUInt()
			if not flag:
				count1 = bs.readUShort()
				count2 = bs.readUShort()
				bs.readBytes(0xC * count1)
				bs.readBytes(0x4 * count2)
	#Blocks with strings of fixed size (48 bytes), number in the header so we can skip easily	
	bs.readBytes(stringCount*0x30)
	#Unknown data before the names
	bs.readBytes(0x18) 
	#Submesh info section, has the name and some other info, we put all of that in some helper lists
	for _ in range(subMeshCount):
		checkPoint = bs.tell()
		subMeshesNames.append(bs.readString())
		bs.seek(checkPoint+40)
		bs.readBytes(0x2C)
		meshBufferSizes.append(bs.readUInt())
		bs.readBytes(0x84)
		vBuffersLengths.append(bs.readUInt()+4)
		bs.readBytes(0x80)
		vcounts.append(bs.readUInt())
		fcounts.append(bs.readUInt())
		bs.readBytes(0x8)
	
	#Cheating to find the beginning, didn't find an offset or something like that. Must be one somewhere but that works for now
	#Find the first index buffer with the function at the top of the file
	findIndices(bs)
	#jump back till we find the FF value
	a=0
	while a != -1:
		bs.seek(-2,1)
		a=bs.readByte()
	#we found the end of the vbuffer, just need to jump back to the beginning. We can now parse everything properly.
	bs.seek(-vBuffersLengths[0]*vcounts[0],1)
	
	#Parsing the vertex and index buffers for every submesh
	for vc,vl,fc,mshbSize in zip(vcounts,vBuffersLengths,fcounts,meshBufferSizes):
		checkpoint = bs.tell()
		vb = noesis.swapEndianArray(bs.readBytes(vl*vc),4)
		Align(bs,0x10)
		findIndices2(bs) #sometimes padding, sometimes not, probably a flag somewhere. We cheat jumping to the indices directly
		ib = noesis.swapEndianArray(bs.readBytes(2*3*fc),2)
		vBuffers.append(vb)
		idxBuffers.append(ib)
		bs.seek(checkpoint+mshbSize)
	
	#feeding the data to noesis for rendering, first the submeshes
	for name,vl,fc,vb,ib in zip(subMeshesNames,vBuffersLengths,fcounts,vBuffers,idxBuffers):
		#we only keep the highest LOD, just remove these two lines to get everything
		rapi.rpgClearBufferBinds()
		rapi.rpgSetName(name)
		rapi.rpgBindPositionBuffer(vb, noesis.RPGEODATA_FLOAT,vl)
		rapi.rpgBindUV1BufferOfs(vb,noesis.RPGEODATA_HALFFLOAT,vl,0x10)
		rapi.rpgCommitTriangles(ib, noesis.RPGEODATA_USHORT, fc*3, noesis.RPGEO_TRIANGLE)	
	
	# Load collision meshes if true
	if bLoadCollisionMeshes:
		for name,vb,ib,fc in zip(colMeshNames,colMeshvBuffers,colMeshidxBuffers,colMeshfCounts):
			rapi.rpgClearBufferBinds()
			rapi.rpgSetName(name)
			rapi.rpgBindPositionBuffer(vb, noesis.RPGEODATA_FLOAT,0xC)
			rapi.rpgCommitTriangles(ib, noesis.RPGEODATA_USHORT, fc*3, noesis.RPGEO_TRIANGLE)	
	try:
		mdl = rapi.rpgConstructModel()
	except:
		mdl = NoeModel()
	
	mdlList.append(mdl)
		
	return 1
	
	