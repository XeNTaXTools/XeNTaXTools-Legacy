﻿using System;
using System.IO;
using System.Text;

namespace DOB2OBJ
{
    internal class Program
    {
        static string a = "by Durik256";
        
        static void Main(string[] args)
        {
            Console.WriteLine($"[dob to obj] {a}");
            
            if (args.Length > 0)
            {
                StringBuilder OBJ = new StringBuilder($"#{a}\n");

                using (BinaryReader br = new BinaryReader(File.OpenRead(args[0])))
                {
                    uint magic = br.ReadUInt32();

                    if (magic != 123)
                    {
                        Console.WriteLine($"Bad [.dob] file: '{args[0]}'!");
                        return;
                    }

                    int mt_num = br.ReadInt32();

                    int obj_ofs = br.ReadInt32();
                    int obj_num = br.ReadInt32();

                    Console.WriteLine($"num submesh: {obj_num}");

                    br.BaseStream.Seek(obj_ofs, SeekOrigin.Begin);
                    int f = 0;
                    for (int x = 0; x < obj_num; x++)
                    {
                        br.ReadInt16();//HH
                        string name = new string(br.ReadChars(8)).Replace("\0", string.Empty);
                        OBJ.AppendLine($"g {name}");

                        byte[] inf = br.ReadBytes(10);
                        int vnum = br.ReadInt16();
                        br.BaseStream.Seek(26, SeekOrigin.Current);
                        int vofs = br.ReadInt32();
                        int stride = inf[1] != 0 ? 22 : 14;

                        long curPos = br.BaseStream.Position;
                        br.BaseStream.Seek(vofs, SeekOrigin.Begin);
                        
                        //vert block (32768/64=512)
                        for (int i = 0; i < vnum; i++)
                        {
                            if(stride > 14)
                            {
                                br.BaseStream.Seek(8, SeekOrigin.Current);
                                OBJ.AppendLine($"vt {br.ReadInt16() / 512f} {br.ReadInt16() / 512f}".Replace(',', '.'));
                                br.BaseStream.Seek(4, SeekOrigin.Current);
                            }
                            else
                            {
                                OBJ.AppendLine("vt 0 0");
                                br.BaseStream.Seek(stride - 6, SeekOrigin.Current);//16
                            }  

                            OBJ.AppendLine($"v {br.ReadInt16() / 512f} {br.ReadInt16() / 512f} {br.ReadInt16() / 512f}".Replace(',','.'));
                        }

                        br.BaseStream.Seek(curPos, SeekOrigin.Begin);

                        //faces
                        OBJ.AppendLine($"usemtl default");
                        for (int i = 1; i < vnum - 1; i++)
                        {
                            int a = i + f;
                            int b = i + 1 + f;
                            int c = i + 2 + f;

                            if (i % 2 == 0)
                                OBJ.AppendLine($"f {a}/{a} {b}/{b} {c}/{c}");
                            else
                                OBJ.AppendLine($"f {c}/{c} {b}/{b} {a}/{a}");
                        }

                        f += vnum;
                        Console.WriteLine($"meshName: {name}, vert: {vnum}, indices: {(vnum - 2) * 3}");
                    }
                    File.WriteAllText(Path.ChangeExtension(args[0], ".obj"), OBJ.ToString());
                    Console.ReadKey();
                }
            }
            else
            {
                Console.WriteLine($"DragNDrop any dop on this exe for convert.");
            }
        }
    }
}