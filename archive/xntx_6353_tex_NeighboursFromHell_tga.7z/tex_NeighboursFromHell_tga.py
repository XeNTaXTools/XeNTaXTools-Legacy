#source: http://forum.xentax.com/viewtopic.php?f=18&t=18243
from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Neighbours From Hell", ".tga")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
	#noesis.logPopup()
	return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    global mode
    testData = bs.readBytes(18)
    if testData.find(b'\x10\x24',16,18) != -1:
        mode = "b4 g4 r4 a4"
    elif testData.find(b'\x10\x20',16,18) != -1:
        mode = "b5 g6 r5"
    else:
        return 0
    return 1
	
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    global mode
    bs.seek(0xc, 0)
    imgWidth = bs.readUShort()
    imgHeight = bs.readUShort()
    bs.readShort()
    data = bs.readBytes(bs.getSize() - bs.tell())
    data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, mode)
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, noesis.NOESISTEX_RGBA32))
    return 1