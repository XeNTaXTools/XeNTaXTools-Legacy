from inc_noesis import *
import noewin

window = 0
def registerNoesisTypes():
    window = noesis.registerTool("test", testToolMethod)
    handle = noesis.register("test", ".@")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)
    return 1

def noepyCheckType(data):
    testToolMethod(window)
    return 1

def noepyLoadModel(data, mdlList):
    global modelList
    modelList = mdlList
    modelList.append(NoeModel())
    return 1

def AddModel(noeWnd, controlId, wParam, lParam):
    modelList.append(NoeModel())
    print("count model",len(modelList))
    return True

def testToolMethod(toolIndex):
    noeWnd = noewin.NoeUserWindow("test", "test", 105, 80)

    if not noeWnd.createWindow():
        pass

    noeWnd.setFont("Arial", 14)
    buttonAddModel = noeWnd.createButton("add model", 5, 5, 90, 30, AddModel)
    return 0
