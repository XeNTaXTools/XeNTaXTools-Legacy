from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Sonic Jump", ".sdd")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
	#noesis.logPopup()
	return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    Magic = bs.readBytes(4)
    if Magic != b'\x54\x58\x06\x00':
        return 0
    return 1

def noepyLoadRGBA(data, texList):
	bs = NoeBitStream(data)
	bs.seek(0x4, NOESEEK_ABS)         
	imgWidth = bs.readUShort()            
	imgHeight = bs.readUShort()           
	datasize = bs.readInt()       
	bs.seek(0xc, NOESEEK_ABS)         
	data = bs.readBytes(datasize)     
	#DXT5
	texFmt = noesis.NOESISTEX_DXT5
	texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
	return 1