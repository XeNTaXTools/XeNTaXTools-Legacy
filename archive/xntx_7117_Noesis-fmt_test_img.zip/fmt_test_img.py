from inc_noesis import *
import noesis
import rapi

def registerNoesisTypes():
    handle = noesis.register("TestScriptGame", ".img")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)
    #noesis.logPopup()
    print("The log can be useful for catching debug prints from preview loads.\nBut don't leave it on when you release your script, or it will probably annoy people.")
    return 1

NOEPY_HEADER = "IMGE"
   
def noepyCheckType(data):
   bs = NoeBitStream(data)
   if len(data) < 8:
      print("File is too short!")
      return 0
   if bs.readBytes(4).decode("ASCII").rstrip("\0") != NOEPY_HEADER:
      print("Signature 'IMGE' missing at file's start!")
      return 0
   return 1  

def noepyLoadModel(data, mdlList):
    ctx = rapi.rpgCreateContext()
    bs = NoeBitStream(data)
    #fileName = rapi.getLocalFileName(rapi.getInputName()).rstrip(".img")
    #rapi.rpgSetName(fileName)
    #print(fileName)
    bs.seek(0xFE3, NOESEEK_ABS)

    #FIcount = bs.readUInt() // 2
    FIcount = 513
    IBuf = bs.readBytes(FIcount * 2) 

    bs.seek(0x20C0, NOESEEK_ABS)
    FVFsize = 36            
    #vertexCount = bs.readUInt() // FVFsize
    vertexCount = 200
    VBuf = bs.readBytes(vertexCount * FVFsize)
    #skip = bs.readBytes(8)

    rapi.rpgBindPositionBufferOfs(VBuf, noesis.RPGEODATA_FLOAT, FVFsize, 0)   
    rapi.rpgBindUV1BufferOfs(VBuf, noesis.RPGEODATA_SHORT, FVFsize, 28)   
    rapi.rpgCommitTriangles(IBuf, noesis.RPGEODATA_USHORT, FIcount, noesis.RPGEO_TRIANGLE_STRIP, 1) #SHORT for word indices
    mdl = rapi.rpgConstructModel()                                                          
    mdlList.append(mdl)          #important, don't forget to put your loaded model in the mdlList
    rapi.rpgClearBufferBinds()
    return 1