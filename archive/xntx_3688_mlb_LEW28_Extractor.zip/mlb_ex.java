

import java.io.*;
import java.util.*;

public class mlb_ex {
  
  public static int readUnsignedInt(DataInputStream in) throws IOException {
    return (in.readUnsignedByte() | in.readUnsignedByte() << 8 |
	        in.readUnsignedByte() << 16 | in.readUnsignedByte() << 24); 
  }
  
  public static void main (String [] args) {
    
    try {
	  
	  String filename;
	  
	  Scanner scan = new Scanner(System.in);
	  if (args.length!=1) {
	    System.out.print("\n>");
	    filename = scan.next();
	  } else {
	    filename = args[0];
	  }
	  
	  File file = new File(filename);
	  if (!file.exists()) {
	    filename = filename + ".mlb_LEW28";
	    file = new File(filename);
		if (!file.exists()) {
			System.out.println("\nFile "+filename+" doesn't exist!");
			System.exit(1);
		}
	  }
	  
	  filename = file.getAbsolutePath();
	  String filename_short = file.getName();
	  
	  DataInputStream dis = new DataInputStream(new BufferedInputStream(new FileInputStream(filename)));
	  
	  byte dxt[] = new byte[128];
	  dxt[0] = 0x44;
	  dxt[1] = 0x44;
	  dxt[2] = 0x53;
	  dxt[3] = 0x20;
	  dxt[4] = 0x7C;
	  dxt[8] = 0x07;
	  dxt[9] = 0x10;
	  dxt[10] = 0x02;
	  dxt[76] = 0x20;
	  dxt[80] = 0x04;
	  dxt[84] = 0x44;
	  dxt[85] = 0x58;
	  dxt[86] = 0x54;
	  dxt[87] = 0x35;
	  dxt[108] = 0x08;
	  dxt[109] = 0x10;
	  dxt[110] = 0x40;
	  
	  dis.skipBytes(0x60);
	  
	  int numFiles = readUnsignedInt(dis);
	  dis.skipBytes(0x74 * numFiles);
	  
	  for (int i=0; i<numFiles; i++) {
	    //System.out.println((i+1) + "/" + numFiles);
	    
		String name;
		int width;
		int height;
		int mipMapCount;
		int dxtIdentifier;
		int mipMapsSize;
	    
	    dis.skipBytes(4);
		
		byte name_tmp[] = new byte[32];
		dis.read(name_tmp);
		name = new String(name_tmp);
		name = name.substring(0, name.indexOf('\0'));
		if (name.length() == 0x1F) {
		  // this step is necessary because otherwiese some textures would have the same name
		  name = name + "_" + i;
		}
		
		dis.skipBytes(12);
		
		width  = readUnsignedInt(dis);
		height = readUnsignedInt(dis);
		dxtIdentifier = readUnsignedInt(dis);
		mipMapsSize   = readUnsignedInt(dis);
		mipMapCount   = readUnsignedInt(dis);
		
		dis.skipBytes(0x2C);
		
		// create file (incl. path)
		String dds_name = new File(filename).getParent() +"\\"+filename_short+".FILES\\"+ name + ".dds";
		File dds_file = new File(dds_name);
		File directory = new File(dds_file.getParentFile().getAbsolutePath());
		directory.mkdirs();
		dds_file.createNewFile();
		
		// set dxt header
		dxt[12] = (byte) (height & 0xFF);
		dxt[13] = (byte) ((height & 0xFF00) >> 8);
		dxt[16] = (byte) (width & 0xFF);
		dxt[17] = (byte) ((width & 0xFF00) >> 8);
		
		// open file for writing
		BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(dds_file));
		
		// write dxt header
		bos.write(dxt);
		
		// read pixel data
		int buffer_size = 0;
		int dim = width*height;
		for (int j=0; j<mipMapCount; j++) {
		  buffer_size += dim/Math.pow(4, j);
		}
		
		byte buffer[] = new byte[buffer_size];
		dis.read(buffer);
		
		// write dxt pixel data
		bos.write(buffer);
		
		// close file
		bos.close();
		
		dis.skipBytes(0x34);
		
	  }
	  
	  dis.close();
	  
    } catch (IOException e) {
      e.printStackTrace();
    } 
  }
}