#include <windows.h>
#include <iostream>
#include <vector>
#include <fstream>
#include <string>

using namespace std;

class TSectionHeader
{
public:
	DWORD iLength;  // Length of the section
	DWORD iNULL;    // Always null
	DWORD iType;    // Bits
	DWORD iID;      // ID of this section / file
	TSectionHeader() :
		iLength ( 0 ),
		iNULL ( 0 ),
		iType ( 0 ),
		iID ( 0 )
	{
		//Constructor is empty
	}
};

class TCamSegment
{
public:
    TCamSegment()
     : iSegmentLength( 0 )
    {
        // Constructor is empty
    }
    WORD iSegmentLength;    // The length of the data in this segment
    vector< WORD > iData;   // The compressed pixels for this segment
};


class CCamParser
{
public:
    bool LoadCamFile( const string aFileName );
    void DecryptPixels();
private:
    TSectionHeader iHeader;
    vector< TCamSegment > iSegments;
    TSectionHeader iLastHeader;
};

// End of file
