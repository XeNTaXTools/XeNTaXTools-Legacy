#include "Main.hpp"

bool CCamParser::LoadCamFile( const string aFileName )
{
    // Open the file
    ifstream file;
    file.open( aFileName.c_str(), ios::binary );
    if ( !file.is_open() )
    {
        return false;
    }

    // Read the header
    file.read( reinterpret_cast < char* > ( &iHeader.iLength ), sizeof( DWORD ) ); 
    file.read( reinterpret_cast < char* > ( &iHeader.iNULL   ), sizeof( DWORD ) );
    file.read( reinterpret_cast < char* > ( &iHeader.iType   ), sizeof( DWORD ) );
    file.read( reinterpret_cast < char* > ( &iHeader.iID     ), sizeof( DWORD ) );

    // Number of segments
    const int segWidth = 16;
    const int imageWidth = 640;
    const int numSegs = imageWidth / segWidth;

    // Resize the array
    iSegments.resize( numSegs );

    // Each segment is 16x240

    // Read the segments
    for ( unsigned int i=0; i<numSegs; i++ )
    {
        // Get the segment length
        file.read( reinterpret_cast < char* > ( &iSegments[i].iSegmentLength ), sizeof( WORD ) );
        // Read the compressed/encrypted pixels for this segment
        iSegments[i].iData.resize( iSegments[i].iSegmentLength /2 ); // /2 for num WORDS, not bytes
        file.read( reinterpret_cast < char* > ( &iSegments[i].iData[0] ), iSegments[i].iSegmentLength );
    }

    // Read the last section header (should be "End!" but could be something else
    // as some files have fonts etc appended after the "Bits" data)
    file.read( reinterpret_cast < char* > ( &iLastHeader.iLength ), sizeof( DWORD ) ); 
    file.read( reinterpret_cast < char* > ( &iLastHeader.iNULL   ), sizeof( DWORD ) );
    file.read( reinterpret_cast < char* > ( &iLastHeader.iType   ), sizeof( DWORD ) );
    file.read( reinterpret_cast < char* > ( &iLastHeader.iID     ), sizeof( DWORD ) );

    return true;
}

void CCamParser::DecryptPixels()
{
    for ( unsigned int i=0; i<iSegments.size(); i++ )
    {
        TCamSegment& section = iSegments[i];
        // Loop through the pixels in the current segment
        for ( unsigned int j=0; j<section.iSegmentLength; j++ )
        {
            // Okay, so what exactly needs to be done to 
            // decrypt/uncompress these elements??
            WORD curWord = section.iData[ j ];
            cout << "Don't know how to decrypt this :(\n";
            exit( -1 );
        }
    }
}

int main( void )
{
    // Load the segments of the cam file
    CCamParser camfile;
    const string camfileName( "MIP02C16.CAM" );

    if ( camfile.LoadCamFile( camfileName ) )
    {
        // Decrypt / uncompress the pixels in each segment of the image
        camfile.DecryptPixels();
        cout << "Decoded " << camfileName << "\n";
    }
    else
    {
        cout << "Failed to load " << camfileName << "\n";
    }
    return 0;
}

// End of file
