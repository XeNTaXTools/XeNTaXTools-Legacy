# FatCatMesh Exporter by Bigchillghost

from inc_noesis import *
import rapi

def registerNoesisTypes():
	handle = noesis.register("FatCatMesh v1.0", ".mesh")
	noesis.setHandlerWriteModel(handle, writeFatCatMesh)
	return 1

def writeFatCatMesh(mdl, bs):
	commentNote = '''/*
 *
 * FatCatMesh v1.0
 *
 */

 '''
	meshStream = NoeBitStream()
	meshStream.writeString(commentNote, 0)
	meshName = rapi.getOutputName().split('\\')[-1].split('.')[0]
	meshStream.writeString('mesh %s\n{\n'%meshName, 0)
	
	subMeshCnt = len(mdl.meshes)
	meshStream.writeString('\tnumSubMeshes=%d;\n\n'%subMeshCnt, 0)
	
	subMeshStream = NoeBitStream()
	
	bboxMin = [ 0.0 ]*3
	bboxMax = [ 0.0 ]*3
	hasInited = False
	
	for mesh in mdl.meshes:
		vertCnt = len(mesh.positions)
		faceCnt = len(mesh.indices) // 3
		subMeshStream.writeString('\tsubMesh %s\n\t{\n'%mesh.name, 0)
		subMeshStream.writeString('\t\tvertexCount=%d;\n'%vertCnt, 0)
		subMeshStream.writeString('\t\tfaceCount=%d;\n'%faceCnt, 0)
		subMeshStream.writeString('\t\tnumSubsets=1;\n', 0)
		subMeshStream.writeString('\t\tuvChannelsCount=1;\n', 0)
		subMeshStream.writeString('\t\tnumMaterials=1;\n', 0)
		subMeshStream.writeString('\t\tmaterial="%s.material";\n\n'%mesh.matName, 0)
		
		vertexDeclaration = '''		vertexDeclaration
		{
			numElements=3;
			FLOAT3 position;
			FLOAT3 normal;
			FLOAT2 texcoord0;
		}

'''
		subMeshStream.writeString(vertexDeclaration, 0)
		firstPos = mesh.positions[0]
		subBboxMin = [ firstPos[0],firstPos[1],firstPos[2] ]
		subBboxMax = [ firstPos[0],firstPos[1],firstPos[2] ]
		for pos in mesh.positions:
			for i in range(0, 3):
				if pos[i] < subBboxMin[i]:
					subBboxMin[i] = pos[i]
				elif pos[i] > subBboxMax[i]:
					subBboxMax[i] = pos[i]
		subMeshStream.writeString('\t\tbbox\n\t\t{\n', 0)
		subMeshStream.writeString('\t\t\t%f,%f,%f,\n'%(subBboxMin[0],subBboxMin[1],subBboxMin[2]), 0)
		subMeshStream.writeString('\t\t\t%f,%f,%f,\n\t\t}\n\n'%(subBboxMax[0],subBboxMax[1],subBboxMax[2]), 0)
		
		subMeshStream.writeString('\t\tvertices\n\t\t{\n', 0)
		subMeshStream.writeString('\t\t\tsize=3;\n', 0)
		for pos in mesh.positions:
			subMeshStream.writeString('\t\t\t%f,%f,%f,\n'%(pos[0],pos[1],pos[2]), 0)
		subMeshStream.writeString('\t\t}\n\n', 0)
		
		idx = 0
		subMeshStream.writeString('\t\tindices\n\t\t{\n', 0)
		for i in range(0, faceCnt):
			subMeshStream.writeString('\t\t\t', 0)
			for j in range(0, 3):
				subMeshStream.writeString('%d,'%mesh.indices[idx], 0)
				idx += 1
			subMeshStream.writeString('\n', 0)
		subMeshStream.writeString('\t\t}\n\n', 0)
		
		subMeshStream.writeString('\t\tnormals\n\t\t{\n', 0)
		subMeshStream.writeString('\t\t\tsize=3;\n', 0)
		for nm in mesh.normals:
			subMeshStream.writeString('\t\t\t%f,%f,%f,\n'%(nm[0],nm[1],nm[2]), 0)
		subMeshStream.writeString('\t\t}\n\n', 0)
		
		subMeshStream.writeString('\t\ttextureCoords 0\n\t\t{\n', 0)
		subMeshStream.writeString('\t\t\tsize=2;\n', 0)
		for uv in mesh.uvs:
			subMeshStream.writeString('\t\t\t%f,%f,\n'%(uv[0],uv[1]), 0)
		subMeshStream.writeString('\t\t}\n\n', 0)
		
		subMeshStream.writeString('\t\tsubset subset1\n\t\t{\n', 0)
		subMeshStream.writeString('\t\t\tvertexStart=0;\n', 0)
		subMeshStream.writeString('\t\t\tvertexCount=%d;\n'%vertCnt, 0)
		subMeshStream.writeString('\t\t\tindexStart=0;\n', 0)
		subMeshStream.writeString('\t\t\tfaceCount=%d;\n'%faceCnt, 0)
		subMeshStream.writeString('\t\t\tmaterialID=0;\n', 0)
		subMeshStream.writeString('\t\t}\n\n', 0)
		
		subMeshStream.writeString('\t}\n\n', 0)
		
		if not hasInited:
			for i in range(0, 3):
				bboxMin[i] = subBboxMin[i]
				bboxMax[i] = subBboxMax[i]
			hasInited = True
		else:
			for i in range(0, 3):
				if subBboxMin[i] < bboxMin[i]:
					bboxMin[i] = subBboxMin[i]
				elif subBboxMax[i] > bboxMax[i]:
					bboxMax[i] = subBboxMax[i]
	meshStream.writeString('\tbbox\n\t{\n', 0)
	meshStream.writeString('\t\t%f,%f,%f,\n'%(bboxMin[0],bboxMin[1],bboxMin[2]), 0)
	meshStream.writeString('\t\t%f,%f,%f,\n\t}\n\n'%(bboxMax[0],bboxMax[1],bboxMax[2]), 0)
	
	bs.writeBytes(meshStream.getBuffer())
	bs.writeBytes(subMeshStream.getBuffer())
	bs.writeString('}', 0)
	
	return 1
