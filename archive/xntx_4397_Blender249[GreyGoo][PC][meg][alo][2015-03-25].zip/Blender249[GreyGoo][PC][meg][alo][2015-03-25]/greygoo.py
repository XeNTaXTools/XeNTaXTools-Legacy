
import newGameLib
from newGameLib import *
import Blender	

boneNameFlag=1 # 0- bone names as numbers, 1- bone names as strings


def megParser(filename,g):
	A=g.i(6)
	t=g.tell()
	nameList=[]
	for m in range(A[3]):
		nameList.append(g.word(g.H(1)[0]))
	g.seek(t+A[5])
	for m in range(A[3]):
		a,b,c,d,e,f=g.H(1)+g.I(4)+g.H(1)
		print m,a,b,c,d,e,f
		filePath=g.dirname+os.sep+nameList[f]
		try:os.makedirs(os.path.dirname(filePath))
		except:pass
		
		new=open(filePath,'wb')
		t=g.tell()
		g.seek(e)
		data=g.read(d)
		try:data=zlib.decompress(data)
		except:pass
		new.write(data)
		new.close()
		g.seek(t)


def twig(parent,n,g):
	n+=4
	for m in range(parent.childCount):
		node=Node()
		node.children=[]
		parent.children.append(node)
		node.chunk=g.i(1)[0]
		node.childCount=g.H(1)[0]
		t=g.H(1)[0]
		print ' '*n,node.chunk,t,g.tell() 
		if t==32768:
			twig(node,n,g)  
		else:
			g.seek(g.tell()-4)
			node.offset=g.tell()+4
			g.seek(g.i(1)[0],1)

			
def aloParser(filename,g):
	g.seek(36)
	new=open(filename+'.dec','wb')
	data=zlib.decompress(g.read(g.fileSize()-36))
	new.write(data)
	new.close()



class Node:pass
		
def decParser(filename,g):	
	global skeleton,nodeList
	root=Node()
	root.children=[]
	while(True):
		if g.tell()==g.fileSize():break
		node=Node()
		root.children.append(node)
		node.children=[]
		node.chunk=g.i(1)[0]
		node.childCount=g.H(1)[0]
		t=g.H(1)[0]
		n=0
		print ' '*n,node.chunk,t,g.tell() 
		if t==32768:
			twig(node,n,g)	 
		else:
			g.seek(g.tell()-4)
			node.offset=g.tell()+4
			g.seek(g.i(1)[0],1)
	
	
	if '.ala.' in filename.lower():
		action=Action()
		sum=0
		for child in root.children:
			if child.chunk==4096:
				for child1 in child.children:				
					if child1.chunk==4097:
						g.seek(child1.offset)
						#skeleton.boneCount=g.i(1)[0]				
					if child1.chunk==4098:
						bone=ActionBone()
						action.boneList.append(bone)
						for child2 in child1.children:
							if child2.chunk==4099:
								g.seek(child2.offset)
								g.logWrite('')
								a,b=g.B(2)
								name=g.word(g.H(1)[0])[:25]
								#print name,
								g.B(2)
								g.b(12)
								g.f(3)
								g.B(2)
								g.f(3)
								g.B(2)
								g.f(3)
								g.B(2)
								g.f(3)
								print g.b(12)
								g.B(8)
								g.B(10)
								sum+=b
							if child2.chunk==4224:
								g.logWrite('')
								g.seek(child2.offset)
								g.B(8)
							if child2.chunk==4103:
								g.logWrite('')
								g.seek(child2.offset)
								g.B(8)		
					if child1.chunk==4106:
						g.seek(child1.offset-4)
						size=g.i(1)[0]
						keyCount=size/6
						print 'keyCount:',keyCount
						for m in range(keyCount):
							g.short(3)
		print len(action.boneList)	
		print 'sum:',sum				
	
	if '.alo.' in filename.lower():
		meshList=[]
		skeleton=Skeleton()
		for child in root.children:
			if child.chunk==512:
				for child1 in child.children:				
					if child1.chunk==513:
						g.seek(child1.offset)
						skeleton.boneCount=g.i(1)[0]				
					if child1.chunk==514:
						bone=Bone()
						skeleton.boneList.append(bone)
						for child2 in child1.children:
							if child2.chunk==515:
								g.seek(child2.offset)
								if boneNameFlag==1:
									bone.name=g.word(g.H(1)[0])[:25]
									#print bone.name
							if child2.chunk==518:
								g.seek(child2.offset)
								A=g.i(3)
								bone.parentID=A[0]
								bone.matrix=Matrix4x4(g.f(12)+(0,0,0,1)).transpose()
						
				
			if child.chunk==1024:
				mesh=Mesh()
				mesh.boneMap=[]
				meshList.append(mesh)
				for child1 in child.children:				
					if child1.chunk==65792:
						mat=Mat()
						mesh.matList.append(mat)
						for child2 in child1.children:
							if child2.chunk==65797:
								g.seek(child2.offset)
								tex_type=g.H(1)[0]
								texType=g.word(g.H(1)[0])
								g.H(1)[0]
								imgName=g.word(g.H(1)[0]).lower().replace('.tga','.dds')				
								print '  ',texType,imgName
								texDir=filename.lower().split(os.sep+'art')[0]
								srgbDir=texDir+os.sep+'art'+os.sep+'textureshdr'+os.sep+'srgb'
								linearDir=texDir+os.sep+'art'+os.sep+'textureshdr'+os.sep+'linear'
								if texType=='BaseTexture':
									mat.diffuse=srgbDir+os.sep+imgName
									print mat.diffuse,
									print os.path.exists(mat.diffuse)
								if texType=='SpecularTexture':
									mat.specular=srgbDir+os.sep+imgName
									print mat.specular,
									print os.path.exists(mat.specular)
								if texType=='NormalTexture':
									mat.normal=linearDir+os.sep+imgName
									print mat.normal,
									print os.path.exists(mat.normal)
					
					if child1.chunk==65536:
						for child2 in child1.children:
							if child2.chunk==65538:
								g.seek(child2.offset)
								mesh.vertItem=g.word(g.H(1)[0])
								print mesh.vertItem
							if child2.chunk==65537:
								g.seek(child2.offset)
								mesh.vertCount=g.i(1)[0]
								mesh.faceCount=g.i(1)[0]
							if child2.chunk==65543:
								mesh.vertStreamOffset=child2.offset
							if child2.chunk==65544:
								mesh.vertStreamOffset=child2.offset
							if child2.chunk==65540:
								mesh.indiceStreamOffset=child2.offset
							if child2.chunk==65542:
								g.seek(child2.offset-4)
								count=g.i(1)[0]/4
								mesh.boneMap=g.i(count)
								
								
		skeleton.BONESPACE=True
		skeleton.NICE=True
		skeleton.draw()
								
		for mesh in meshList:
			g.seek(mesh.vertStreamOffset-4)
			streamSize=g.i(1)[0]
			vertStride=streamSize/mesh.vertCount
			print vertStride
			for m in range(mesh.vertCount):
				t=g.tell()
				mesh.vertPosList.append(g.f(3))
				if mesh.vertItem=='alD3dVertNU2U3U3U2C':
					g.seek(t+24)
					mesh.vertUVList.append(g.f(2))
				if mesh.vertItem=='alD3dVertNU2C':
					g.seek(t+24)
					mesh.vertUVList.append(g.f(2))
				if mesh.vertItem=='alD3dVertB4I4NU2U3U3U2C':
					g.seek(t+12)		
					mesh.skinWeightList.append(g.f(4))		
					mesh.skinIndiceList.append(g.B(4))
					g.seek(t+44)
					mesh.vertUVList.append(g.f(2))
				if mesh.vertItem=='alD3dVertB4I4NU2U3U3':
					g.seek(t+12)		
					mesh.skinWeightList.append(g.f(4))		
					mesh.skinIndiceList.append(g.B(4))
					g.seek(t+44)
					mesh.vertUVList.append(g.f(2))
				if mesh.vertItem=='alD3dVertRSkinNU2U3U3U2C':
					g.seek(t+18)	
					mesh.skinWeightList.append([1.0])		
					mesh.skinIndiceList.append(g.B(4))
					g.seek(t+20)
					mesh.vertUVList.append(g.f(2))
				g.seek(t+vertStride)
				
			g.seek(mesh.indiceStreamOffset-4)
			streamSize=g.i(1)[0]
			for m in range(mesh.faceCount):
				mesh.faceList.append(g.H(3))
			skin=Skin()
			skin.boneMap=mesh.boneMap
			mesh.skinList.append(skin)	
			if boneNameFlag==1:mesh.boneNameList=skeleton.boneNameList
			if mesh.vertItem!='alD3dVertN':
				mesh.BINDSKELETON=skeleton.name
				mesh.draw()	
			
	

def Parser():	
	filename=input.filename
	print
	print filename
	print
	
	ext=filename.split('.')[-1].lower()	
	
	
	if ext=='dec':
		file=open(filename,'rb')
		g=BinaryReader(file)
		decParser(filename,g)
		file.close()
	
	
	if ext=='alo':
		file=open(filename,'rb')
		g=BinaryReader(file)
		aloParser(filename,g)
		file.close()
		filename+='.dec'
		
		file=open(filename,'rb')
		g=BinaryReader(file)
		decParser(filename,g)
		file.close()
	
	if ext=='ala':
		file=open(filename,'rb')
		g=BinaryReader(file)
		aloParser(filename,g)
		file.close()
	
	if ext=='meg':
		file=open(filename,'rb')
		g=BinaryReader(file)
		megParser(filename,g)
		file.close()
 
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
	 
Blender.Window.FileSelector(openFile,'import','Grey Goo files: meg - container file, alo - meshes') 