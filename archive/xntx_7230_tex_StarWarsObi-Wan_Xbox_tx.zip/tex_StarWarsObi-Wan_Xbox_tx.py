from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Star Wars: Obi-Wan [Xbox]", ".tx")
    noesis.setHandlerTypeCheck(handle, noeCheckGeneric)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyLoadRGBA(data, texList):
    rapi.processCommands("-texnorepfn")
    bs = NoeBitStream(data)
    tableSize = bs.readUInt()
    tableOffset = bs.readUInt()
    tmp = bs.tell()
    bs.seek(tableOffset)
    numFiles = tableSize // 0x14
    unk = bs.readInt()
    unk2 = bs.readInt()
    offset = []
    nextOffset = []
    format = []
    width = []
    height = []
    for i in range(numFiles):
        flag1 = bs.readUShort()
        flag2 = bs.readUShort()
        off1 = bs.readUInt()
        zero = bs.readUInt()
        unk3 = bs.readByte()
        imgFmt = bs.readUByte()
        mips = bs.readBits(4)
        width1 = bs.readBits(4)
        height1 = bs.readBits(4)
        imgWidth = 2 ** width1
        imgHeight = 2 ** height1
        zero2 = bs.readBits(4)
        zero3 = bs.readInt()
        format.append(imgFmt) 
        width.append(imgWidth)
        height.append(imgHeight)
        tmp2 = bs.tell()
        bs.seek(4, 1)
        nextOff = bs.readUInt() + 8
        nextOffset.append(nextOff)
        off = off1 + tmp
        offset.append(off)
        bs.seek(tmp2)
    unk4 = bs.readUInt()
    files = bs.readUInt()
    texName = []
    for i in range(numFiles):
        strLength = bs.readUInt()
        tex = noeStrFromBytes(bs.readBytes(strLength))
        texName.append(tex)
    for i in range(numFiles):
        bs.seek(offset[i])
        if i + 1 == numFiles:
            datasize = tableOffset - offset[i]        
        else:
            datasize = nextOffset[i] - offset[i]
        data = bs.readBytes(datasize)
        #DXT1
        if  format[i] == 0xc:
            texFmt = noesis.NOESISTEX_DXT1
        #DXT3
        elif format[i] == 0xe:
            texFmt = noesis.NOESISTEX_DXT3
        #RGBA8888 #??
        elif format[i] == 0x6:
            texFmt = noesis.NOESISTEX_RGBA32
        texList.append(NoeTexture(texName[i], width[i], height[i], data, texFmt))
    return 1