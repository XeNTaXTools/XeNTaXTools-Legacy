from inc_noesis import *
import noesis
import rapi
import os
import glob

# Texture Directory
# 	Set this to the location of the uncompressed textures (.dds)
textureDirectory = 'Z:\\data\\BDO\\character\\texture\\'


def registerNoesisTypes():
	handle = noesis.register("Black Desert", ".pab;.pac")
	noesis.setHandlerTypeCheck(handle, BDCheckType)
	noesis.setHandlerLoadModel(handle, BDLoadModel) #see also noepyLoadModelRPG
	#noesis.logPopup()
	return 1

def BDCheckType(data):
	bs = NoeBitStream(data)
	idMagic = bs.readInt()
	if idMagic != 0x20524150:
		return 0
	return 1

find = lambda searchList, elem: [[i for i, x in enumerate(searchList) if x == e] for e in elem]


def BDLoadModel(data, mdlList):
	ctx = rapi.rpgCreateContext()
	bs = NoeBitStream(data)
	rapi.setPreviewOption('setAngOfs',"0 90 90")
	texList = []; matList = []; matNames = []; boneList = []; boneNames = []; boneTable = {}
	idMagic = bs.readInt(); parVer = bs.readUShort()
	bs.seek(0x10, NOESEEK_ABS)
	if parVer == 515 or parVer == 771:
		bs.seek(0x14, NOESEEK_ABS) 

	if parVer == 513:
		boneCount = bs.readUShort()
		for i in range(0, boneCount):
			boneHash = bs.readUInt()
			boneNameSize = bs.readUByte()
			boneName = bs.readBytes(boneNameSize).decode("ASCII").rstrip("\0")
			boneParent = bs.readInt()
			boneMtx             = NoeMat44.fromBytes(bs.readBytes(64)).toMat43()
			boneMtxInverse      = NoeMat44.fromBytes(bs.readBytes(64)).toMat43().inverse()
			boneMtxLocal        = NoeMat44.fromBytes(bs.readBytes(64)).toMat43()
			boneMtxLocalInverse = NoeMat44.fromBytes(bs.readBytes(64)).toMat43().inverse()
			boneScale           = NoeVec3.fromBytes(bs.readBytes(12))
			BoneQuat            = NoeQuat.fromBytes(bs.readBytes(16))
			BonePos             = NoeVec3.fromBytes(bs.readBytes(12))
			bs.seek(0x2, NOESEEK_REL)
			newBone = NoeBone(i, boneName, boneMtx, None, boneParent)
			boneList.append(newBone)
		mdl = NoeModel()
		mdlList.append(mdl); mdl.setBones(boneList)
	elif parVer == 259 or parVer == 515 or parVer == 771:
		boneCount     = bs.readUByte()					# 0x00000010: 64'
		bonehashList  = bs.read("I" * boneCount)		# 0x
		usedBoneCount = bs.readUByte()
		usedBones     = bs.read("B" * usedBoneCount)

		totalVert, totalFace, meshCount = bs.read("IIH")
		test = rapi.getDirForFilePath(rapi.getInputName())
		os.chdir(test)
		test = glob.glob("*.pab")
		try:
			skelfile = rapi.getDirForFilePath(rapi.getInputName()) + test[0]
		except:
			skelfile = ""
		if (rapi.checkFileExists(skelfile)):
			ss = rapi.loadIntoByteArray(skelfile)
			ss = NoeBitStream(ss)
			ss.seek(0x10, NOESEEK_ABS)
			boneCount1 = ss.readUShort()
			for i in range(0, boneCount1):
				boneHash = ss.readUInt()
				boneNameSize = ss.readUByte()
				boneName = ss.readBytes(boneNameSize).decode("ASCII").rstrip("\0")
				boneTable[str(boneHash)] = boneName
				boneNames.append(boneName)
				boneParent = ss.readInt()
				boneMtx             = NoeMat44.fromBytes(ss.readBytes(64)).toMat43()
				boneMtxInverse      = NoeMat44.fromBytes(ss.readBytes(64)).toMat43().inverse()
				boneMtxLocal        = NoeMat44.fromBytes(ss.readBytes(64)).toMat43()
				boneMtxLocalInverse = NoeMat44.fromBytes(ss.readBytes(64)).toMat43().inverse()
				boneScale           = NoeVec3.fromBytes(ss.readBytes(12))
				BoneQuat            = NoeQuat.fromBytes(ss.readBytes(16))
				BonePos             = NoeVec3.fromBytes(ss.readBytes(12))
				ss.seek(0x2, NOESEEK_REL)
				newBone = NoeBone(i, boneName, boneMtx, None, boneParent)
				boneList.append(newBone)

			BoneMap = []
			for a in range(0, len(bonehashList)):
				for i, j in enumerate(boneNames):
					if j == boneTable[str(bonehashList[a])]:
						BoneMap.append(i)
			rapi.rpgSetBoneMap(BoneMap)


		for a in range(0, meshCount):
			meshNameSize = bs.readUByte()
			meshName = 'Mesh_' + str(a).zfill(3)
			matName = bs.readBytes(meshNameSize).decode("ASCII").rstrip("\0")
			flag = bs.readUShort()

			matName = textureDirectory + matName + '.dds'
			material = NoeMaterial(matName, "")
			material.setTexture(matName)
			#material.setFlags(0, 1)
			matList.append(material)
			matNames.append(matName)

			for b in range(0, 3):
				rapi.rpgSetName(meshName + "_LOD_" + str(b))
				rapi.rpgSetMaterial(matNames[a])
				
				vertCount = bs.readUShort()
				vertBuff = bs.readBytes(0x20 * vertCount)
				faceCount = bs.readUInt()
				faceBuff = bs.readBytes(0x2 * faceCount)

				if vertCount > 0:
					rapi.rpgBindPositionBufferOfs(vertBuff, noesis.RPGEODATA_FLOAT, 0x20, 0)
					#rapi.rpgBindNormalBufferOfs(vertBuff, noesis.RPGEODATA_UBYTE, 0x20, 12)
					rapi.rpgBindUV1BufferOfs(vertBuff, noesis.RPGEODATA_HALFFLOAT, 0x20, 16)
					#rapi.rpgBindColorBufferOfs(vertBuff, noesis.RPGEODATA_UBYTE, 0x20, 20, 4)
					rapi.rpgBindBoneIndexBufferOfs(vertBuff, noesis.RPGEODATA_UBYTE, 0x20, 24, 4)
					rapi.rpgBindBoneWeightBufferOfs(vertBuff, noesis.RPGEODATA_UBYTE, 0x20, 28, 4)
					if b < 1:
						rapi.rpgCommitTriangles(faceBuff, noesis.RPGEODATA_USHORT, faceCount, noesis.RPGEO_TRIANGLE, 1)
		mdl = rapi.rpgConstructModel()
		mdl.setModelMaterials(NoeModelMaterials(texList, matList))
		mdlList.append(mdl); mdl.setBones(boneList)	
	return 1