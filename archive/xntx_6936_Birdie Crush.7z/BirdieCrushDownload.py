#https://image-glb.qpyou.cn/g2/Jenkins/AssetBundles/rev52831/Android/bundle_default_character_d01_m010_bundle
import xml.etree.ElementTree as ET
from urllib.request import ProxyHandler, build_opener, install_opener, urlopen
from itertools import islice
from multiprocessing.dummy import Pool as ThreadPool
import os
import io
import struct
pool = ThreadPool(10)

if not os.path.exists("BirdieCrush"):
    os.makedirs("BirdieCrush")
#proxy = urllib.request.ProxyHandler({'http': 'http://192.168.1.91:8888'})
proxy = ProxyHandler({})
opener = build_opener(proxy)
opener.addheaders = []
install_opener(opener)

def geturl(name, name2):
	try:
		fldr = 'BirdieCrush'
		if os.path.exists(fldr + '/' + name + '.unity3d'):
			pass
		else:
			print('Downlaoding',name)
			print(fldr + '/' + name + '.unity3d')
			dl = URL + '/Android/' + name
			print(dl)
			myFile = urlopen(dl).read()
			with open(fldr + '/' + name + '.unity3d', 'wb') as f:
				f.write(myFile)
		
	except:
		pass



tree = ET.parse('ResourcePatchInfo.xml')
root = tree.getroot()
print(root)
VER = ''
URL = ''
FNAME = []
for child in root:
	print(child.tag, child.attrib)
	for item in child:
		if child.tag == 'Info':
			#print(item.attrib['Ver'])
			VER = item.attrib['Ver']
		if child.tag == 'PatchInfo':
			#print(item.attrib['URL'])
			URL = item.attrib['URL']
		if child.tag == 'Asset':
			#print(item.attrib['FileName'])
			FNAME.append(item.attrib['FileName'])
pool.starmap(geturl,  zip(FNAME,FNAME))