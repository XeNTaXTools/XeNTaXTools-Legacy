Run unpakke.exe without parameters to get help.

Latest version can be found here: http://nullsecurity.org/unpakke/