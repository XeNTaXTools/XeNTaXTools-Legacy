# Playground: Marvel Studios' Avengers: Endgame lullmodel importer by Bigchillghost

import rapi
from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Playground: Marvel Studios' Avengers: Endgame", ".lullmodel")
	noesis.setHandlerTypeCheck(handle, lullmodelCheckType)
	noesis.setHandlerLoadModel(handle, lullmodelLoadModel)
	#noesis.logPopup()
	return 1

#check if it's this type based on the data
def lullmodelCheckType(data):
	if len(data) < 0x80:
		return 0
	bs = NoeBitStream(data)
	Magic = bs.readBytes(4)
	if Magic != b'\x1C\x00\x00\x00':
		noesis.logPopup()
		return 0
	return 1

#load the model
def lullmodelLoadModel(data, mdlList):
	bs = NoeBitStream(data)
	bs.seek(0x20, NOESEEK_ABS)
	SkipSize = bs.readUInt()
	MtlChunkOffset = bs.tell()
	MtlChunkOffset += bs.readUInt()
	bs.seek(MtlChunkOffset + 4, NOESEEK_ABS)
	SkipSize = bs.readUInt()
	bs.seek(SkipSize - 4, NOESEEK_REL)
	SkipSize = bs.readUInt()
	bs.seek(SkipSize - 0xC, NOESEEK_REL)
	
	meshNumOffset = bs.tell()
	meshNumOffset += bs.readUInt()
	
	FIoffset = bs.tell()
	FIoffset += bs.readUInt()
	
	Voffset = bs.tell()
	Voffset += bs.readUInt()
	
	bs.seek(4, NOESEEK_REL)
	Vcount = bs.readUInt()
	
	bs.seek(meshNumOffset, NOESEEK_ABS)
	meshNum = bs.readUInt()
	FInum = []
	startId = []
	for i in range(0, meshNum):
		startId.append(bs.readUInt())
		FInum.append(bs.readUInt() - startId[i])
	
	bs.seek(FIoffset, NOESEEK_ABS)
	FIcount = bs.readUInt()
	TypeSize = 2
	if Vcount > 0xFFFF:
		TypeSize = 4
	FIoffset += 4
	
	bs.seek(Voffset, NOESEEK_ABS)
	Vsize = bs.readUInt()
	structSize = Vsize // Vcount
	SkipSize = 0
	if structSize == 0x3C:
		SkipSize += 4
	Voffset += 4
	
	meshes = []
	
	prevVertID = 0
	for i in range(0, meshNum):
		idxList = []
		FIcount = FInum[i]
		bs.seek(FIoffset + startId[i]*TypeSize, NOESEEK_ABS)
		if TypeSize == 4:
			for j in range(0, FIcount):
				idxList.append(bs.readUInt() - prevVertID)
		else:
			for j in range(0, FIcount):
				idxList.append(bs.readUShort() - prevVertID)
		
		Vcount = max(idxList) - min(idxList) + 1
		prevVertID += Vcount
		
		Positions = []
		TexCoords = []
		Normals = []
		bs.seek(Voffset, NOESEEK_ABS)
		for j in range(0, Vcount):
			Positions.append(NoeVec3.fromBytes(bs.readBytes(12)))
			bs.seek(SkipSize, NOESEEK_REL)
			TexCoords.append(NoeVec3([bs.readFloat(), bs.readFloat(), 0.0]))
			Normals.append(NoeVec3.fromBytes(bs.readBytes(12)))
			bs.seek(0x18, NOESEEK_REL)
		Voffset += Vcount * structSize
		mesh = NoeMesh(idxList, Positions, 'mesh%d'%(i+1))
		mesh.setUVs(TexCoords)
		mesh.setNormals(Normals)
		meshes.append(mesh)
	mdl = NoeModel(meshes)
	mdlList.append(mdl)
	#rapi.setPreviewOption("setAngOfs", "0 -90 0")
	return 1
