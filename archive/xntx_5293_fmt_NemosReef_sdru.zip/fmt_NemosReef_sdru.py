from inc_noesis import *
import noesis
import rapi

def registerNoesisTypes():
   handle = noesis.register("Nemo's Reef", ".sdru")
   noesis.setHandlerTypeCheck(handle, NRCheckType)
   noesis.setHandlerLoadModel(handle, NRLoadModel)
   #noesis.logPopup()
   return 1

def NRCheckType(data):
	bs = NoeBitStream(data)
	Magic = bs.readBytes(4).decode("ASCII")
	print(Magic)
	if Magic != 'SDRU': 
		return 0
	return 1   
   
def NRLoadModel(data, mdlList):
	ctx = rapi.rpgCreateContext()
	#rapi.setPreviewOption("setAngOfs","0 0 0")      #set the default preview angle        
	bs = NoeBitStream(data)
	bs.seek(0x0B, NOESEEK_ABS)
	VCount = bs.readInt()                            #vertex count
	VBytes = bs.readInt()                            #FVF/vertex stride
	print(VBytes, "stride")
	VBuf = bs.readBytes(VCount * VBytes)
	rapi.rpgBindPositionBufferOfs(VBuf, noesis.RPGEODATA_FLOAT, VBytes, 0)   #position of vertices
	#rapi.rpgBindNormalBufferOfs(VBuf, noesis.RPGEODATA_FLOAT, VBytes, 12)   #normals -optional
	rapi.rpgBindUV1BufferOfs(VBuf, noesis.RPGEODATA_FLOAT, VBytes, 12)       #UVs
	FCount = bs.readInt()
	bs.seek(0x01, NOESEEK_REL)
	IBuf = bs.readBytes(FCount * 2)                                          #multiply by 2 for word 
	rapi.rpgCommitTriangles(IBuf, noesis.RPGEODATA_SHORT, FCount, noesis.RPGEO_TRIANGLE_STRIP, 1) #SHORT for word 
	mdl = rapi.rpgConstructModel()
	mdlList.append(mdl)
	rapi.rpgClearBufferBinds()
	return 1