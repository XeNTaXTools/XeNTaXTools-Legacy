import re
headers = []

#Determines if a file is new or a duplicate.
def Header_Checker():

    #Loop through an array of previously seen headers, return true if its within the array.
    for i in range(len(headers)):
        if headers[i] == header:
            return True

    #Add this new header to the array.
    headers.append(header)
    return False

def Tag_Checker():

    #Jump to and read in the last twenty lines of the file, remember that one line has already been consumed.
    DAT.seek((size - 16) - 320, 1)
    bottom = str(DAT.read(320))

    #Check for model tags.
    if re.search('md[0-8]_|arms[1-12]', bottom) != None:
        return True

    else:
        return False
    
with open('C:\Archive\Papercrafting\Front Mission\DATs\FM4.DAT','rb') as DAT:
    with open('C:\Archive\Papercrafting\Front Mission\DATs\FM4.POS','rb') as POS:

        #Calculate the start of the offsets and jump to them.
        OffsetsLocation = (int.from_bytes(POS.read(4), 'little') * 4) + 8 
        POS.seek(OffsetsLocation, 0)

        #Read from the POS until EOF.   
        while POS.read(4):

            #Jump back.    
            POS.seek(-4,1)

            #Get the offset of a file within the DAT and its size. 
            offset = int.from_bytes(POS.read(4), 'little') * 2048
            size = int.from_bytes(POS.read(4), 'little')

            #Jump to offset within the DAT and get the files header.
            DAT.seek(offset, 0)
            header = str(DAT.read(16))

            #Check the files header.
            duplicate = Header_Checker()

            #if this is a new file, determine if it's a model file. 
            if duplicate == False:
                PossibleModel = Tag_Checker()

                if PossibleModel == True:

                    #Write the model to a separate file     
                    with open('C:\Archive\Papercrafting\Front Mission\DAT Extracts\\' + str(offset), 'wb') as model:
                        DAT.seek(offset, 0)
                        model.write(DAT.read(size)) 

                
       

            

            
        
        

