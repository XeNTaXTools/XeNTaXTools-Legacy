import newGameLib
from newGameLib import *
import Blender	
		
def varcParser(filename,g):
	g.word(16)
	w=g.i(4)
	ext=Extractor()
	print dir(ext)
	ext.source=filename
	ext.destination=g.dirname
	ext.filecount=w[0]
	ext.ZLIB=True
	for m in range(w[0]):
		g.H(1)
		v=g.i(3)
		ext.fileoffsetlist.append(v[2])
		ext.filesizelist.append(v[0])
	for m in range(w[0]):
		ext.filenamelist.append(g.find('\x00'))
	g.debug=True
	g.tell()
	ext.extract()
	
	
	
def xmlParser(filename):
	matFile=filename+'_data'+os.sep+'materials.xml'
	if os.path.exists(matFile)==True:
		materials={}
		xml=Xml()
		xml.input=open(matFile,'r')
		xml.parse()	
		materialNodeList=xml.find(xml.root,'Material')
		for materialNode in materialNodeList:
			chunks=materialNode.chunks
			materials[chunks['name']]={}
			materials[chunks['name']]['diffuse']=None
			materials[chunks['name']]['normalmap']=None
			materials[chunks['name']]['specularmap']=None
			if 'diffuse' in chunks:
				materials[chunks['name']]['diffuse']=chunks['diffuse']
			if 'normalmap' in chunks:	
				materials[chunks['name']]['normalmap']=chunks['normalmap']
			if 'specularmap' in chunks:	
				materials[chunks['name']]['specularmap']=chunks['specularmap']
		return materials
	else:
		return None
	
def modelParser(filename,g):
	matList=[]
	
	g.seek(8)
	mesh=None
	skeleton=None
	skin=None
	material=None
	while(True):
		chunk = g.i(1)[0]
		if chunk==0:
			name = g.word(4)
			#print name,g.tell()
			seek = g.i(1)[0]
			back = g.tell() 
			if name=='SRTM':
				materials=xmlParser(filename)				
				g.tell()
				g.debug=True
				matCount=g.i(1)[0]
				for m in range(matCount):
					material=Mat()
					g.i(1)
					g.word(4)
					g.i(1)
					g.H(1)
					matName=g.word(g.i(1)[0])
					#print matName
					g.i(1)
					g.seek(26,1)
					texDir=g.dirname
					diffuse=texDir+os.sep+g.word(g.i(1)[0])
					specular=texDir+os.sep+g.word(g.i(1)[0])
					normal=texDir+os.sep+g.word(g.i(1)[0])
					g.tell()
					#g.seek(605,1)
					g.i(1)
					g.word(g.i(1)[0])
					g.i(7)
					g.word(g.i(1)[0])
					g.word(g.i(1)[0])
					g.read(g.i(1)[0])
					g.i(4)
					g.tell()
					if materials!=None:
						texDir=g.dirname
						if matName in materials:
							if materials[matName]['diffuse'] is not None:
								material.diffuse=texDir+os.sep+materials[matName]['diffuse']
								#print 'diffuse=',diffuse
							
							if materials[matName]['normalmap'] is not None:
								material.normal=texDir+os.sep+materials[matName]['normalmap']
								#print 'normal=',normal
							
							
							if materials[matName]['specularmap'] is not None:
								material.specular=texDir+os.sep+materials[matName]['specularmap']
								#print 'specular=',specular
							
					matList.append(material)
					g.word(4)
				g.debug=False
			if name == 'HSMV':
				g.debug=True
				g.word(4)
				g.i(1)[0],g.f(1)[0],g.i(1)[0]
				v=g.B(15*4)
				nVerts = g.i(1)[0]
				g.B(13)
				nFaces = g.i(1)[0] 
				g.debug=False
				g.seek(back+108)
				mesh=Mesh()
				mesh.TRIANGLE=True
				for m in range(nVerts):
					t=g.tell()
					mesh.vertPosList.append(g.f(3))
					g.seek(t+v[16])
					mesh.vertUVList.append(g.f(2))
					g.seek(t+v[8])
				mesh.indiceList=g.H(nFaces*3)
			if name == 'LEKS':
				skeleton=Skeleton()
				skeleton.BONESPACE=True
				skeleton.NICE=True
				g.H(1)[0]
				nBones = g.H(1)[0]
				for m in range(nBones):
					bone=Bone()
					bone.name=g.word(g.i(1)[0])[-25:]
					bone.parentID=g.h(1)[0]
					g.f(3)
					g.f(4)
					bone.posMatrix=TranslationMatrix(Vector(g.f(3)))
					qx,qy,qz,qw = g.f(4)
					bone.rotMatrix=Quaternion(qw,qx,qy,qz).toMatrix().invert()
					skeleton.boneList.append(bone)
				skeleton.draw()	
			if name == 'THGW':
				g.H(2)
				skin=Skin()
				for m in range(nVerts):
					nGr = g.H(1)[0]
					indices=[]
					weights=[]
					for n in range(nGr):
						indices.append(g.H(1)[0])
						g.B(1)
						weights.append(g.B(1)[0]/255.0)
					mesh.skinIndiceList.append(indices)
					mesh.skinWeightList.append(weights)
					
			if name=='MBUS':
				#g.debug=True
				g.i(3)
				for m in range(g.i(1)[0]):
					print m
					v=g.i(8)
					g.f(6)
					w=g.i(2)
					matID=w[0]
					if len(matList)!=0:
						material=matList[matID]
						material.TRIANGLE=True
						material.IDStart=v[0]
						material.IDCount=v[1]
						mesh.matList.append(material)
				g.debug=False		
						
				
			g.seek(back+seek)
			g.i(1)[0]
			g.word(4)
		elif chunk==-1:break
		else:
			print 'unknow chunk',chunk
			break 
		
		
	if mesh is not None:
		if skeleton is not None:
			if skin is not None:
				skin.boneMap=skeleton.boneNameList
				mesh.skinList.append(skin)	
		if skeleton is not None:
			mesh.BINDSKELETON='armature'
		#if material is not None:	
		#	mesh.facesgroupslist.append(material)		
		mesh.draw()	
	print g.tell()
	
	
def XBSV(g):
	g.i(1)[0]
	name = g.word(4)
	seek = g.i(1)[0]
	back = g.tell()
	for m in range(g.i(1)[0]):
		g.f(7)
	g.seek(back+seek)
	g.i(1)[0]
	g.word(4)
	
	
def ATDO(g):
	g.i(1)[0]
	name = g.word(4)
	seek = g.i(1)[0]
	back = g.tell()
	g.H(1)
	for m in range(g.i(1)[0]):
		g.f(4)
	g.seek(back+seek)
	g.i(1)[0]
	g.word(4)
	
def SOPB(g):
	g.debug=True
	g.i(1)[0]
	name = g.word(4)
	seek = g.i(1)[0]
	back = g.tell()
	g.i(5)
	for m in range(100):
		g.f(3)
		g.f(4)
	g.seek(back+seek)
	g.i(1)[0]
	g.word(4)
		
	
def INAB(g):
	g.H(3)
	animName=g.word(g.i(1)[0])
	
	XBSV(g)
	ATDO(g)
	SOPB(g)
	 
	g.i(1)
	name = g.word(4)
	seek = g.i(1)[0]
	back = g.tell()
	g.seek(back+seek)
	g.i(1)[0]
	g.word(4)
		
	
	
def tree(g):
	print
	g.H(1)
	while(True):
		chunk = g.i(1)[0]
		if chunk==1:
			name = g.word(4)
			seek = g.i(1)[0]
			back = g.tell() 
			if name=='INAB':
				INAB(g)
				break
			
			
			g.seek(back+seek)
			g.i(1)[0]
			name = g.word(4)
			#print name
		else:
			break

def animParser(filename,g):
	#g.debug=True
	g.seek(8)
	while(True):
		chunk = g.i(1)[0]
		if chunk==0:
			name = g.word(4)
			seek = g.i(1)[0]
			back = g.tell()
			tree(g)	
			#break	
			g.seek(back+seek)
			g.i(1)[0]
			g.word(4)
		elif chunk==-1:break
		else:
			print 'unknow chunk',chunk
			break 
	g.tell()
	
	
def animParser1(filename,g):
	g.debug=True
	g.seek(6)
	g.H(1)
	chunk = g.i(1)[0]
	name = g.word(4)
	seek = g.i(1)[0]
	back = g.tell()
	
	print
	
	g.H(1)
	print
	chunk1 = g.i(1)[0]
	name1 = g.word(4)
	seek1 = g.i(1)[0]
	back1 = g.tell()	
	g.seek(back1+seek1)
	g.i(1)[0]
	g.word(4)
	print
	chunk1 = g.i(1)[0]
	name1 = g.word(4)
	seek1 = g.i(1)[0]
	back1 = g.tell()	
	g.seek(back1+seek1)
	g.i(1)[0]
	g.word(4)
	print
	chunk1 = g.i(1)[0]
	name1 = g.word(4)
	seek1 = g.i(1)[0]
	back1 = g.tell()
	
	
	print
	g.H(1)
	chunk2 = g.i(1)[0]
	seek2 = g.i(1)[0]
	back2 = g.tell()	
	g.seek(back2+seek2)
	g.i(1)[0]
	g.word(4)
	g.i(3)
	
		
	g.seek(back1+seek1)
	g.i(1)[0]
	g.word(4)
	
	
	print
				
	g.seek(back+seek)
	g.i(1)[0]
	g.word(4)
	g.tell()
			
			
	
def Parser(filename):	
	ext=filename.split('.')[-1].lower()	
	
	
		
	if ext=='varc':
		file=open(filename,'rb')
		g=BinaryReader(file)
		varcParser(filename,g)
		file.close()
		
	if ext=='model':
		file=open(filename,'rb')
		g=BinaryReader(file)
		modelParser(filename,g)
		file.close()
	
	if ext=='anim':
		file=open(filename,'rb')
		g=BinaryReader(file)
		animParser(filename,g)
		file.close()

 
	
Blender.Window.FileSelector(Parser,'import','Soul Worker files: *.model') 
	