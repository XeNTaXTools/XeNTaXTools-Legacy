#by Durik256 for xentax
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Aerial Strike: The Yager Missions", ".yod")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)
    return 1

def noepyCheckType(data):
    if data[:3] != b'YOD':
        return 0
    return 1   
	
def noepyLoadModel(data, mdlList):
    bs = NoeBitStream(data)
    ctx = rapi.rpgCreateContext()
    
    bs.seek(4)#YOD
    file_size, file_unk, num_mesh = bs.readInt(), bs.readInt(), bs.readInt()
    materials = []
    
    
    name_mdl = searchString(bs)
    for x in range(num_mesh):
        bs.seek(4,1)#MESH
        curPos = bs.getOffset() + 4
        size_mesh, vert, lod, mat = [bs.readInt() for x in range(4)]
        name_mesh = searchString(bs)
        rapi.rpgSetName(name_mesh)
        print('MESH',name_mesh)
        bs.seek(4,1)#VERT
        size_vert, vnum, stride, vunk = [bs.readInt() for x in range(4)]
        print('vnum',vnum,'stride',stride)
        vbuf = bs.readBytes(vnum * stride)
        bs.seek(4,1)#LOD
        lod_size, lnum = bs.readInt(), bs.readInt()#num?
        bs.seek(4,1)#TRIS
        tris_size, tunk, face_num = bs.readInt(), bs.readInt(), bs.readInt()
        print('face_num',face_num)
        ibuf = bs.readBytes(face_num * 6)
        
        #rapi.rpgSetName(name_mesh)
        #rapi.rpgBindPositionBuffer(vbuf, noesis.RPGEODATA_FLOAT, stride)
        #if stride > 24:
        #    rapi.rpgBindUV1BufferOfs(vbuf, noesis.RPGEODATA_FLOAT, stride, stride-8)
        #rapi.rpgCommitTriangles(ibuf, noesis.RPGEODATA_USHORT, face_num * 3, noesis.RPGEO_TRIANGLE)
        
        bs.seek(4,1)#ATTR
        attr_size, anum = bs.readInt(), bs.readInt()
        for x in range(anum):
            #0-mat_id;1-face_start;2-face_count;3-vert_start;4-vert_count;
            ATTR = [bs.readInt() for x in range(5)]
            print('ATTR',ATTR)
            
            rapi.rpgSetMaterial('mat_%d_%s' % (x, name_mesh))
            rapi.rpgBindPositionBuffer(vbuf, noesis.RPGEODATA_FLOAT, stride)
            if stride > 24:
                rapi.rpgBindUV1BufferOfs(vbuf, noesis.RPGEODATA_FLOAT, stride, stride-8)
            rapi.rpgCommitTriangles(ibuf[(ATTR[1]*6):(ATTR[1]*6)+(ATTR[2]*6)], noesis.RPGEODATA_USHORT, ATTR[2] * 3, noesis.RPGEO_TRIANGLE)
        
        bs.seek(4,1)#BNDV
        bs.seek(bs.readInt(),1)
        
        
        if mat:
            tx_dir = os.path.abspath(os.path.join(rapi.getDirForFilePath(rapi.getInputName()), '../texture/'))
            bs.seek(4,1)#MTRL
            mat_size, mnum = bs.readInt(), bs.readInt()
            print('mat_num',mnum)
            for x in range(mnum):
                munk = [bs.readInt() for x in range(6)]
                mname = searchString(bs)
                #----find texture----
                for file in os.listdir(tx_dir):
                    if mname in file:
                        mname = file
                        break
                #--------------------
                materials.append(NoeMaterial('mat_%d_%s' % (x, name_mesh), os.path.join(tx_dir, mname)))
        else:
            materials.append(NoeMaterial('mat_0', ''))
        bs.seek(curPos + size_mesh)

    mdl = rapi.rpgConstructModel()
    mdl.setModelMaterials(NoeModelMaterials([], materials))
    mdlList.append(mdl)
    return 1
    
def searchString(bs):
    bytes = []
    byte = None
    while byte != 0:
        byte = bs.readUByte()
        bytes.append(byte)
    return noeAsciiFromBytes(bytes)