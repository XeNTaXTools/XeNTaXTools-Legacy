
First of all:

##########################################################################
the exe may freeze and produce large files (about 260 MBytes for example.)

So if you don't know how to kill a task on your system then 
PLEASE don't use Make_H2O-ForzaHor3.exe!
##########################################################################

You have been warned.

In most cases it's one modelbin file in the list that causes the issue
so you might simply delete that entry in the modelbins.txt.


Make_H2O-ForzaHor3.exe doesn't create H2O files, no.
It directly logs wavefront obj data but it needs a filelist as input.

Copy dir_modelbin.cmd to a modelbin folder and execute it
(or doubleclick it in the explorer).

This will create a modelbins.txt file with a filelist.
Then open that txt file with the exe.

Make_FH3.obj is the log file that has to be renamed then
so that it's not overwritten in the next run.


(older exe versions: after blender import you should press 's', then 0.02 [ENTER]
 to scale the whole thing down.)

------------------------------------------------------
I'd recommend to use separate *modelbins.txt files for
the subfolders of \exterior for example.
------------------------------------------------------

This way you'll get separate log/obj files (not all-in-one).

Blender will slow down on selection for example with hundreds of outliner entries!

I strongly recommend to delete SLOD lines such as
D:\models\CAD_ATSV_16\scene\Exterior\BumperF\bumperF_a__SLOD.modelbin
from your modelbins.txt files (maybe copy them to a SLOD_modelbins.txt file).

You have been WARNED (again), so don't blame me

have fun (maybe) amd thx for your feedbacks!

shak-otay, 3/2017


special thanks to Andrakann for his "titanic" work
and minime891 for feedbacks
--------------------------------------------------


btw: if you want to use the example modelbins.txt file then be sure to rename/replace
"D:\models\" so that the path matches your folder hierarchy.


versions: -gc: grouping check, first brute force grouping
          -j2: grouping via magic table
         -j2l: x mirrored (+ face winding reversed) and mesh scaled, Lod names
	 -jm4:  materialnames, bugfix for lower lods
	 -jm7: AMC improved

obsolete: -jq: (two versions to select)
            j: improved brute force grouping
	    q: quicksorted face indices, groups derived from uv-sections
	       forced modulo 1000 grouping for meshes > 2000 vertices

---------------------------------------------------------------------------


issues:
-------

o all lods separated, but must be selected then dragged manually

o wrong position for moveable parts (hood, door) 
o steeringWheel wrong scale?
o suspension, pos/scale, wip
o some uv maps wrong
o most UVB28 missing/wrong/too small

o wheel has to be duplicated and scaled/positioned manually
o doorHandleLF_a must be placed manually


FAQs:
-----
Q: "doors, wipers position is not valid!?"
A: All moveable parts such as hoods, too, which seem to be bound to the skeleton
   might require to get their (relative) positions from a skeletal hierarchy

version -gc:
Q: "some wrong lod parts/vertices attached to body_a"
A: yeah, what do you expect from a brute force face grouping algorithm?;-)



---------------------------
thoughts about uv layering
---------------------------

As you may know Standard wavefront obj doesn't support multiple uv channels
(see manual choosing at file's end).

For this reason it would be usefull to export to FBX or DAE which do.

Sadly I've spent to many hours on this project meanwhile so will have to live 
with the unconvenience of creating 5 obj files (one per channel)
or wait for a pro to care for the problem.

I experienced the manual selection with default offsets of 4 4 4 4 4 4 4 (4)
providing most uv maps needed.


--------------------------------
using extracted obj with blender
--------------------------------

blender is a little bit tricky (but it's free!) especially when it comes to outliner selections.

THE REASON WHY it doesn't seem to work "custom" is that it takes care of which object was selected first.
Which other apps don't do in most cases.

So here we go:

(be sure nothing is selected neither in the outliner nor in 3D view, 
press A to select/deselect everything)

Press B in the outliner
use the rectangled box to select all LodS0 groups for example
(left MB clicked, then release)

right click into selected box, chose select

in 3D view see what happens
---------------------------

with mouse cursor in 3D view press G and move selected

once you've understood the philosophy behind it it works like a charm!
(You might be required to unselect the highlighted (white) groupname.)

---------------------------
you might use this script in a text window to select unwanted lods
then delete them; verry slow!
---------------------------
import bpy

for obj in bpy.context.scene.objects:
    bpy.ops.object.select_pattern(pattern="L02*")
    bpy.ops.object.select_pattern(pattern="L03*")
    bpy.ops.object.select_pattern(pattern="L04*")
    bpy.ops.object.select_pattern(pattern="L05*")



---------------------------------------------

Remarks: choosing uv offsets manually
---------------------------------------------

I've included uv-sizes into the obj files such as
# uv-sizes bumperF_a.modelbin, 20 24 24 28 28 32 32 36 36 

so you can get an idea which uv channels to care for (see below table).

I use this table which sadly doesn't apply to all models:
(uvbs= size of uv block in bytes)

uvbs 12 16 20 24 28 32 36
      4  4  4  4  4  4  4 (channel 1)
      8  8  8  8  8  8  8
      0  0 12 12 12 12 12
      0  0  0(16)16 16 16
      0  0  0  0(20 20)20 (channel 5) 

      0  0  0  0  0(24 24) (experimental)


This means uvb12 having uvs at offsets 4 and 8 (channels 1, 2)
and uvb36 having the whole set of 5 channels

The first zero for uvb12 means: it has only two uv channels.
For the first zero of uvb16 I'm not sure; so you might try replacing the 0 by a 12.

Standard wavefront obj doesn't support multiple uv channels.

For this reason there must be a zero fill (vt 0.0 0.0) if you chose uv channel 3 for example
(  0  0 12 12 12 12 12). This is NOT a bug.

But there's a problem with assigining the channels, though:

"There's 2 different layouts for 32 byte block size, and if you read them with settings 32 - 4,
 you got UV2 for some meshes and UV1 for some other meshes." (Andrakann)

