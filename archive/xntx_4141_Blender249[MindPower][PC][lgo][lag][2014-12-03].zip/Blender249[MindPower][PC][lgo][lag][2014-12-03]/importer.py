import newGameLib
reload(newGameLib)
from newGameLib import *
import Blender

def lgoParser(filename,g):
	#g.logOpen()
	#g.debug=True
	
	g.i(4)
	Matrix4x4(g.f(16))
	A=g.i(7)
	print A
	pos=g.tell()
	g.seek(120)
	texCount=g.i(1)[0]
	texList=[]
	for m in range(texCount):
		t=g.tell()
		#g.f(14)
		g.seek(t+216)
		texList.append(g.word(16))
		#g.i(193)
		g.seek(t+1004)
	
	
	g.seek(pos+A[6])
	B=g.i(37)
	print B
	for m in range(4):
		g.H(4)
	g.i(2)	
	g.debug=False
	mesh=Mesh()
	for m in range(B[5]):mesh.vertPosList.append(g.f(3))
	g.seek(B[5]*12,1)
	for m in range(B[5]):mesh.vertUVList.append(g.f(2))	
	for m in range(B[5]):
		mesh.skinIndiceList.append(g.B(4))
		mesh.skinWeightList.append(g.f(4))
	skin=Skin()	
	skin.boneMap=g.i(B[8])
	mesh.skinList.append(skin)
	mesh.TRIANGLE=True
	mesh.indiceList=g.i(B[6])
		
	
	#g.debug=True
	for m in range(texCount):
		mat=Mat()
		mat.TRIANGLE=True
		a,b,c,d=g.i(4)
		mat.IDStart=b
		mat.IDCount=a*3
		mat.diffuse=g.dirname.replace('model','texture')+os.sep+texList[m]
		#print mat.diffuse
		mesh.matList.append(mat)
		
	mesh.draw()
	
	g.tell()
	#g.logClose()
	
def labParser(filename,g):
	#g.logOpen()
	#g.debug=True
	A=g.i(5)
	
	if A[4]==1:
		g.debug=False
		skeleton=Skeleton()
		skeleton.ARMATURESPACE=True
		for m in range(A[1]):		
			bone=Bone()
			pos=g.tell()
			name=g.find('\x00')
			bone.name=str(m)
			g.seek(pos+64)
			bone.ID,bone.parentID=g.i(2)
			skeleton.boneList.append(bone)
		for m in range(A[1]):		
			skeleton.boneList[m].matrix=Matrix4x4(g.f(16)).invert()
		skeleton.NICE=True	
		skeleton.draw()	
		#g.debug=True
		action=Action()
		action.BONESPACE=True
		action.BONESORT=True	
		for m in range(A[3]):
			g.i(2)
			g.f(4)
			g.f(4)
			g.f(4)
			g.f(4)
		for n in range(A[1]):
			#g.logWrite(n)
			bone=ActionBone()
			bone.name=skeleton.boneList[n].name
			for m in range(A[2]):
				
				bone.matrixFrameList.append(m)
				rotMatrix=Matrix3x3(g.f(9)).resize4x4()
				posMatrix=VectorMatrix(g.f(3))
				matrix=rotMatrix*posMatrix
				bone.matrixKeyList.append(matrix)
			action.boneList.append(bone)		
		action.draw()
		action.setContext()	
		#g.debug=True
		print g.tell(),g.fileSize()	
			
	
	if A[4]==3:
		g.debug=False
		skeleton=Skeleton()
		skeleton.BINDMESH=True
		skeleton.ARMATURESPACE=True
		for m in range(A[1]):		
			bone=Bone()
			pos=g.tell()
			name=g.find('\x00')
			bone.name=str(m)
			g.seek(pos+64)
			bone.ID,bone.parentID=g.i(2)
			if m==0:
				bone.parentID=-1
			skeleton.boneList.append(bone)
		for m in range(A[1]):		
			skeleton.boneList[m].matrix=Matrix4x4(g.f(16)).invert()
		skeleton.NICE=True	
		skeleton.draw()	
		#g.debug=True
		for m in range(A[3]):
			g.i(2)
			g.f(4)
			g.f(4)
			g.f(4)
			g.f(4)
			
		action=Action()
		action.BONESPACE=True
		action.BONESORT=True	
		for n in range(A[1]):
			bone=ActionBone()
			bone.name=skeleton.boneList[n].name
			#g.logWrite('pos')	
			if n==0:
				for m in range(A[2]):	
					#g.logWrite(m)
					bone.posFrameList.append(m)
					bone.posKeyList.append(VectorMatrix(g.f(3)))
			else:
				if 	A[0]==1:
					for m in range(1):	
						#g.logWrite(m)
						bone.posFrameList.append(m)
						bone.posKeyList.append(VectorMatrix(g.f(3)))
				else:		
					for m in range(A[2]):	
						#g.logWrite(m)
						bone.posFrameList.append(m)
						bone.posKeyList.append(VectorMatrix(g.f(3)))
			#g.logWrite('rot')	
			for m in range(A[2]):		
				#g.logWrite(m)
				bone.rotFrameList.append(m)
				bone.rotKeyList.append(QuatMatrix(g.f(4)).resize4x4())
			action.boneList.append(bone)	
		action.draw()
		action.setContext()	
		#print g.f(8)	
		print g.tell(),g.fileSize()	
		
	g.tell()	
	#g.logClose()
	
def Parser():	
	filename=input.filename
	imageList=input.imageList
	ext=filename.split('.')[-1].lower()		
	
	
	if ext=='lgo':
		file=open(filename,'rb')
		g=BinaryReader(file)
		lgoParser(filename,g)
		file.close()
	
	if ext=='lab':
		file=open(filename,'rb')
		g=BinaryReader(file)
		labParser(filename,g)
		file.close()
 
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
	
Blender.Window.FileSelector(openFile,'import','lgo - skinned mesh, lag - animation')