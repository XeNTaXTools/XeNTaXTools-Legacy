/*
 * DMC3 Mod to SMD Converter
 * Coded by James
 * 
 * Originally converted to OBJ
 * Weights were discovered and the swap didn't take much
 * 
 * James
 */

#include "main.h"
#include "Get.h"

static uint vert_count;
static uint face_count;

uint BodyOBJ(uchr *buffer, uint offset, FILE *fo, uchr fname[MAX], int index);
int headOBJ(uchr *buffer, FILE *fo, uchr *mod_file);
int headSMD(uchr *buffer, FILE *fo, uchr *mod_file);

double GETCHOR(uchr *ptr) {
	int x = ptr[0];
	double f;
	if ( x>127 ) x -= 256;
	f = (double)x/256;
	return((double)f);
}

float GETCOOR(uchr *ptr) {
	int x = (ptr[1]<<8)|ptr[1];
	if ( x>32767 ) x -= 65536;
	return((float)x/65536);
}

/*
 * SMD converter
 * Go past main to see the obj converter
 */
uint BodySMD(uchr *buffer, uint offset, FILE *fo) {
	uint count = GETSHRT(buffer+offset);
	uint verts = GETINT(buffer+offset+0xC);     //vertices
	uint texts = GETINT(buffer+offset+0x10);    //UVs
	uint weights = GETINT(buffer+offset+0x14);  //weiths, unused
	uint norms = GETINT(buffer+offset+0x18);    //normals
	uint last_offset = GETINT(buffer+offset+0x1C); //unknown
	int i;
	
	if ( !(count) || !(verts) || !(texts) || !(weights) || !(norms) || !(last_offset) ) {
		return(0);
	}
	
	float x, y, z;             //Global position
	double nx, ny, nz;         //normals, doubles for single char reasons
	float tu, tv;              //UV coords
	float w0, w1;              //weights, unused atm
	for ( i=0; i<count; i++ ) {
		//Verts
		x = GETFLT(buffer+verts);
		y = GETFLT(buffer+verts+4);
		z = GETFLT(buffer+verts+8);
		verts+= 12;
		
		nx = GETCHOR(buffer+norms+1);
		ny = GETCHOR(buffer+norms+2);
		nz = GETCHOR(buffer+norms+3);
		norms += 4;
			
		tu = GETFLT(buffer+texts);
		tv = GETFLT(buffer+texts+4);
		texts += 12;   //unused float in there
			
		w0 = GETCOOR(buffer+weights);
		w1 = GETCOOR(buffer+weights+2);
		weights += 4;
		
		if ( !(i%3) ) fprintf(fo, "NULL\n");
		fprintf(fo, "\t-1 %.8f %.8f %.8f %.8f %.8f %.8f %.8f %.8f 2 %d %.8f %d %.8f\n", x, y, z, nx, ny, nz, tu, tv, 0, w0, 1, w1);
	}
	return(1);
}

//MAIN
int main(int argc, char *argv[]) {
	//greeting
	printf("\n=================================\nDevil May Cry 3 \nMOD to SMD/OBJ converter\nvBETA\nCoded by James aka Jamesuminator\n=================================\n---------------------------------\n\n");
	uchr *mod_file, smd_file[MAX], mtl_file[MAX];
	uchr NoExt[MAX]; //no extentsion
	
	//get files, or print usage
	if (argc < 2) {
		printf("Usage: %s [file] {outfile}\nif no outfile given, output is [file].obj\n", argv[0]);
		return(-1);
	} else {
		mod_file = argv[1];
		if (argc>2) {
			snprintf(smd_file, sizeof(smd_file), "%s", argv[2]);
			NOEXT(argv[2], NoExt);
			snprintf(mtl_file, sizeof(mtl_file), "%s.mtl", NoExt);
		} else {
			NOEXT(argv[1], NoExt);
			snprintf(smd_file, sizeof(smd_file), "%s.obj", NoExt);
			snprintf(mtl_file, sizeof(mtl_file), "%s.mtl", NoExt);
		}
	}

	//printf("%s\n%s\n\n%s\n%s\n", mod_file, argv[1], smd_file, mtl_file);
	
	int size;
	char *buffer;
	FILE *smd_open;
	FILE *fi;
	
	printf("Opening: %s\n", mod_file);
	if ( !(fi = fopen(mod_file, "rb")) ) {
		printf("Error Opening %s\n", mod_file);
		return(0);
	}
	
	if ( !(size = filesize(fi)) ) {
		printf("Error Getting Size\n");
		return(0);
	}
	
	if ( !(buffer = malloc(size)) ) {
		printf("Not Enough Memory\n");
		return(0);
	}
	
	printf("Reading: %s\n", mod_file);
	if ( !(fread(buffer, 1 , size, fi)) ) {
		printf("Error Reading %s\n", mod_file);
		return(0);
	}
	fclose(fi);
	
	printf("\nOpening: %s\n", smd_file);
	if ( !(smd_open = fopen(smd_file, "wb")) ) {
		printf("Error Opening %s\n", smd_file);
		return(0);
	}
	
	if ( GETFLT(buffer+4) != (float)1.01 ) {
		printf("Invalid Mod File\n");
		printf("%f\n", GETFLT(buffer+4));
		return(-1);
	}
	
	/*
	 * Smd or Obj option below
	 * comment out OBJ for SMD
	 * and vice versa
	 * 
	 * Default is OBJ
	 * 
	 * NOTE:
	 * if only 2 arguments are given
	 * the file is always [file].obj
	 * unless you go to line 101 and change 
	 * "%s.obj" to "%s.smd".
	 *                   -James
	 */
	
	if ( !(headOBJ(buffer, smd_open, mod_file)) ) return(-1);   //Comment out for SMD
	//if ( !(headSMD(buffer, smd_open, mod_file)) ) return(-1); //Uncomment for SMD
	
	printf("\nAll Done!\n");
	return(0);
}

//Work Function for OBJ
uint BodyOBJ(uchr *buffer, uint offset, FILE *fo, uchr fname[], int index) {
	int  count = GETSHRT(buffer+offset);
	uint verts = GETINT(buffer+offset+0xC);     //vertices
	uint texts = GETINT(buffer+offset+0x10);    //UVs
	uint weights = GETINT(buffer+offset+0x14);  //weiths, unused
	uint norms = GETINT(buffer+offset+0x18);    //normals
	uint last_offset = GETINT(buffer+offset+0x1C); //unknown
	int i;
	
	//printf("\n%d %d %d %d %d %d\n", count, verts, texts, weights, norms, last_offset);
	
	if ( !(count) || !(verts) || !(texts) || !(weights) || !(norms) || !(last_offset) ) {
		return(0);
	}
	
	fprintf(fo, "\n# %.3d Vertices\n", count);
	float x, y, z;             //Global position
	double nx, ny, nz;         //normals, doubles for single char reasons
	float tu, tv;              //UV coords
	float w0, w1;              //weights, unused atm
	for ( i=0; i<count; i++ ) {
		//Verts
		x = GETFLT(buffer+verts);
		y = GETFLT(buffer+verts+4);
		z = GETFLT(buffer+verts+8);
		verts+= 12;
		
		nx = GETCHOR(buffer+norms+1);
		ny = GETCHOR(buffer+norms+2);
		nz = GETCHOR(buffer+norms+3);
		norms += 4;
			
		tu = GETFLT(buffer+texts);
		tv = GETFLT(buffer+texts+4);
		texts += 12;   //unused float in there
			
		w0 = GETCOOR(buffer+weights);
		w1 = GETCOOR(buffer+weights+2);
		weights += 4;

		if ( !(fprintf(fo, "v %f %f %f\nvn %f %f %f\nvt %f %f 0.0\n", x, y, z, nx, ny, nz, tu, tv)) ) return(0);
		//fprintf(fo, "v %f %f %f\nvn %f %f %f\nvt %f %f 0.0\n", x, y, z, nx, ny, nz, tu, tv);
	}
	//faces
	fprintf(fo, "\ng %s_%.3d\n#%d Faces\n", fname, index, count);
	for ( i=vert_count; i<count+vert_count; i++ ) {
		fprintf(fo, "f %d/%d/%d %d/%d/%d %d/%d/%d\n", i+1, i+1, i+1, i+1, i+1, i+1, i+1, i+1, i+1);
		face_count += 1;
	}
	
	offset = last_offset+(count*2);
	while ( offset%0x10 ) {
		offset += 1;
	}
	
	vert_count += count;
	return(1);
}

//OBJ HEADER FUNC
int headOBJ(uchr *buffer, FILE *fo, uchr *mod_file) {
	uint num_mod = buffer[0x10];
	uint OFFSETS[num_mod];
	uint offset = 0x30;
	int i;
	
	for ( i=0; i<num_mod; i++ ) {
		OFFSETS[i] = GETINT(buffer+offset+4);
		offset += 0x30;
	}
	
	//watermark
	fprintf(fo, "#DMC3 MOD to OBJ\n#Coded by James\n\n#On to the file...\n");
	
	printf("Parsing  %s...", mod_file);
	uchr fname[MAX];
	NOEXT(mod_file, fname);
	for ( i=0; i<num_mod; i++ ) {

		if ( !(offset = BodyOBJ(buffer, OFFSETS[i], fo, fname, i)) ) {
			printf("\nError Parsing %s\n", mod_file);
			return(0);
		}
	}
	printf("Done\n");
	
	return(1);
}


//SMD HEADER FUNC
int headSMD(uchr *buffer, FILE *fo, uchr *mod_file) {
	uint num_mod = buffer[0x10];
	uint OFFSETS[num_mod];
	uint offset = 0x30;
	int i;
	
	float x, y, z;    //xyz coords of each bone
	fprintf(fo, "version 1\n\nnodes\n");
	for ( i=0; i<num_mod; i++ ) {
		fprintf(fo, "\t%d \"%.3d_%s\" -1\n", i, i, mod_file);
	}
	fprintf(fo, "end\n\nskeleton\ntime 0\n");
	
	for ( i=0; i<num_mod; i++ ) {
		x = GETFLT(buffer+offset+0x24);
		y = GETFLT(buffer+offset+0x28);
		z = GETFLT(buffer+offset+0x2C);
		
		OFFSETS[i] = GETINT(buffer+offset+4);
		offset += 0x30;
		fprintf(fo, "\t%d %f %f %f %f -%f %f\n", i, x, y, z, (float)0.0, (float)0.0, (float)0.0);
	}
	fprintf(fo, "end\n\n");
	
	fprintf(fo, "triangles\n");
	printf("Parsing  %s...", mod_file);
	uchr fname[MAX];
	NOEXT(mod_file, fname);
	for ( i=0; i<num_mod; i++ ) {

		if ( !(BodySMD(buffer, OFFSETS[i], fo)) ) {
			printf("Error Parsing %s\n", mod_file);
			return(0);
		}

	}
	printf("Done\n");
	fprintf(fo, "end\n");  //more smd stuff
	
	return(1);
}
