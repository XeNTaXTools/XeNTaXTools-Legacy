#include <stdlib.h>
#include <stdio.h>

#define MAX 512

//do the laborous task
int GETALL(char *buffer, int size, char inp[MAX], char out[MAX], FILE *fo) {
	
	FILE *fi;
	printf("Opening: %s\n", inp);
	if ( !(fi = fopen(inp, "rb")) ) {
		printf("Error Opening %s\n", inp);
		return(0);
	}
	
	if ( !(size = filesize(fi)) ) {
		printf("Error Getting Size\n");
		return(0);
	}
	
	if ( !(buffer = malloc(size)) ) {
		printf("Not Enough Memory\n");
		return(0);
	}
	
	printf("Reading: %s\n", inp);
	if ( !(fread(buffer, 1 , size, fi)) ) {
		printf("Error Reading %s\n");
		return(0);
	}
	fclose(fi);
	
	printf("\nOpening: %s\n", out);
	if ( !(fo = fopen(out, "wb")) ) {
		printf("Error Opening %s\n", out);
		return(0);
	}
	
	return(size);
}


//get file size
int filesize(FILE *fil) {
	int size;
	
	fseek(fil, 0, SEEK_END);
	size = ftell(fil);
	fseek(fil, 0, SEEK_SET);
	return(size);
}

//no extension
int NOEXT(char *name, char new_name[]) {
	int i;
	for ( i=0; name[i] != '.'; i++ ) {
		new_name[i] = name[i];
	}
	new_name[i] = '\00';  //null tag
	return(1);
}

//get lines
int getLines( char *line, int MAXCHR, FILE *fi ) {
	int i;
	char CHR;
	for ( i=0; i<MAXCHR; i++ ) {
		CHR = fgetc( fi );
		if ( CHR != '\n' && CHR != 0 ) {
			line[i] = CHR;
		} else if ( CHR == 0 && i == 0) {
			return(0);
		} else {
			break;
		}
	}
	line[i] = 0;  //null terminate
	return(1);
}

int getFiles(char FILES[][MAX], FILE *fi) {
	int i=0;
	while ( fgets(FILES[i], 512, fi) != NULL ) {
		FILES[i][strlen(FILES[i])-1] = 0;
		printf("%s\n", FILES[i]);
		i++;
	}
	FILES[i][0] = EOF;
	return(1);
}

