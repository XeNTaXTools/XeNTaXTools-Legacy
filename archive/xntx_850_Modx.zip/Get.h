typedef unsigned long uint;
typedef unsigned short int ushrt;
typedef unsigned char uchr;

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#define swp16(a) a = ((a&0x00ff)<<8)|((a&0xff00)>>8)
#define swp32(a) a = ((a&0xff000000)>>24)|((a&0x00ff0000)>>8)|((a&0x0000ff00)<<8)|((a&0x000000ff)<<24)

//get unsigned int,
uint GETINT(uchr *ptr) {
	return((uint)((ptr[3] << 24)|(ptr[2] << 16)|(ptr[1] << 8)|(ptr[0])));
}

//get unsigned short,
ushrt GETSHRT(uchr *ptr) {
	return((ushrt)((ptr[1]<<8)|(ptr[0])));
}

//get float
float GETFLT(uchr *ptr) {
	float f;
	memcpy(&f, ptr, sizeof(float));
	return((float)f);
}

//get char
uchr GETCHR( uchr *ptr ) {
	return((uchr)(ptr[0]));
}

//Big Endian
//get unsigned int,
uint GETBNT(uchr *ptr) {
	uint x = ((ptr[3] << 24)|(ptr[2] << 16)|(ptr[1] << 8)|(ptr[0]));
	swp32(x);
	return((uint)(x));
}

//get unsigned short,
ushrt GETBHRT(uchr *ptr) {
	ushrt x = ((ptr[1]<<8)|(ptr[0]));
	swp16(x);
	return((ushrt)(x));
}

//get float
float GETBLT(uchr *ptr) {
	int x;
	float f;
	memcpy(&x, ptr, sizeof(float));
	swp32(x);
	memcpy(&f, &x, sizeof(float));
	return((float)f);
}


