import newGameLib
from newGameLib import *
import Blender	

def rdmParser(matList,filename,g):
	g.read(4)
	H=g.i(18)
	
	
	count,size=g.i(2)
	t=g.tell()
	g.seek(t+size*count)
	
	count,size=g.i(2)
	t=g.tell()
	g.seek(t+size*count)
	
	count,size=g.i(2)
	t=g.tell()
	g.seek(t+size*count)
	
	count,size=g.i(2)
	t=g.tell()
	g.seek(t+size*count)
	
	count,size=g.i(2)
	t=g.tell()
	g.seek(t+size*count)
	
	count,size=g.i(2)
	t=g.tell()
	g.seek(t+size*count)
	
	count,size=g.i(2)
	t=g.tell()
	g.seek(t+size*count)
	
	count,size=g.i(2)
	t=g.tell()
	posOff=None
	uvOff=None
	skinIndiceOff=None
	skinWeightOff=None
	off=0
	for m in range(count):
		A=g.i(4)
		if A[0]==0:posOff=off	
		if A[0]==4:uvOff=off
		if A[0]==7:skinIndiceOff=off
		if A[0]==6:skinWeightOff=off
		
		if A[3]==4:off+=8
		if A[3]==2:off+=4
		if A[3]==1:off+=4
		
	g.seek(t+size*count)
	
	count,size=g.i(2)
	t=g.tell()
	g.seek(t+size*count)
	
	mesh=Mesh()	
	count,size=g.i(2)
	t=g.tell()
	for m in range(count):
		mat=Mat()
		mat.TRIANGLE=True
		A=g.i(7)
		mat.IDStart=A[0]
		mat.IDCount=A[1]
		mat.ID=A[2]
		mesh.matList.append(mat)
	g.seek(t+size*count)
	
	
	count,size=g.i(2)
	t=g.tell()
	for m in range(count):
		tm=g.tell()
		mesh.vertPosList.append(g.half(3))
		g.seek(tm+uvOff)
		mesh.vertUVList.append(g.half(2))
		if skinIndiceOff is not None:
			g.seek(tm+skinIndiceOff)
			mesh.skinIndiceList.append(g.B(4))
			if skinWeightOff is not None:
				g.seek(tm+skinWeightOff)
				mesh.skinWeightList.append(g.B(4))	
			else:			
				mesh.skinWeightList.append([1,0,0,0])
		g.seek(tm+size)
	skin=Skin()
	mesh.skinList.append(skin)	
	g.seek(t+size*count)
	
	count,size=g.i(2)
	t=g.tell()
	if size==2:
		mesh.indiceList=g.H(count)
	g.seek(t+size*count)
	matNameList=[]
	if H[8]!=0:
	
		count,size=g.i(2)
		t=g.tell()
		g.i(7)
		g.seek(t+size*count)
		
		for m in range(count):
			count1,size1=g.i(2)
			t=g.tell()
			list=g.i(12)
			g.seek(t+size1*count1)	
			
			for i,item in enumerate(list):
				if item!=0:
					count1,size1=g.i(2)
					t=g.tell()
					if i==0:
						name=g.word(count1)
						print 'mat:',name
						matNameList.append(name)
					
					g.seek(t+size1*count1)	

	skeleton=None				
	if H[9]!=0:
		count,size=g.i(2)
		t=g.tell()
		g.i(8)
		g.seek(t+size*count)	
		
		count,size=g.i(2)
		t=g.tell()
		skeleton=Skeleton()
		skeleton.ARMATURESPACE=True
		skeleton.NICE=True
		for m in range(count):
			bone=Bone()
			g.i(1)
			#g.f(7)
			posMatrix=VectorMatrix(g.f(3))
			rotMatrix=QuatMatrix(g.f(4)).resize4x4().invert()
			matrix=rotMatrix*posMatrix
			bone.matrix=matrix.invert()
			bone.parentID=g.i(1)[0]
			posMatrix=VectorMatrix(g.f(3))
			posMatrix=VectorMatrix(g.f(3))
			g.f(6)
			skeleton.boneList.append(bone)
		g.seek(t+size*count)
		
		for m in range(count):	
			count1,size1=g.i(2)
			t=g.tell()
			name=g.word(count1)
			skeleton.boneList[m].name=name
			g.seek(t+size1*count1)	
		skeleton.draw()	
	
	for meshMat in mesh.matList:
		name=matNameList[meshMat.ID]
		for mat in matList:
			if mat.name==name:
				meshMat.diffuse=mat.diffuse
	if skeleton is not None:
		mesh.BINDSKELETON=skeleton.name
		mesh.boneNameList=skeleton.boneNameList
	mesh.draw()
	
def cfgParser(filename,lines):
	matList=[]
	fileDir=os.path.dirname(filename)
	for line in lines:
		if '<m_Materials>' in line:
			mat=Mat()
			matList.append(mat)
			mat.name=line.split('<m_Name>')[1].split('</m_Name>')[0]
		if '<m_DiffuseTexture>' in line:
			diffuse=line.split('<m_DiffuseTexture>')[1].split('</m_DiffuseTexture>')[0]
			mat.diffuse=fileDir+os.sep+'maps'+os.sep+os.path.basename(diffuse).split('.')[0]+'_0.dds'
	return matList		
	
	
	
def animParser(filename,g):
	g.read(4)
	H=g.i(18)
	
	
	count,size=g.i(2)
	t=g.tell()
	g.seek(t+size*count)
	
	count,size=g.i(2)
	t=g.tell()
	g.seek(t+size*count)
	
	count,size=g.i(2)
	t=g.tell()
	g.seek(t+size*count)
	
	count,size=g.i(2)
	t=g.tell()
	g.seek(t+size*count)
	
	count,size=g.i(2)
	t=g.tell()
	g.seek(t+size*count)
	
	count,size=g.i(2)
	t=g.tell()
	g.seek(t+size*count)
	
	action=Action()
	action.BONESPACE=True
	action.BONESORT=True
	action.skeleton='armature'
	for m in range(count):
		bone=ActionBone()
		action.boneList.append(bone)
		count1,size1=g.i(2)
		t1=g.tell()
		name=g.word(count1)
		bone.name=name
		g.seek(t1+size1*count1)	
		count1,size1=g.i(2)
		t1=g.tell()
		for m in range(count1):
			bone.rotKeyList.append(QuatMatrix(g.f(4)).invert().resize4x4())
			bone.posKeyList.append(VectorMatrix(g.f(3)))
			frame=g.f(1)[0]*33
			bone.rotFrameList.append(frame)
			bone.posFrameList.append(frame)
		g.seek(t1+size1*count1)
		action.draw()
		action.setContext()

	
	
def Parser(filename):	
	print '='*70
	print filename
	print '='*70
	ext=filename.split('.')[-1].lower()	
	
	if ext=='rdm':
		if 'anim' in filename.lower():
			file=open(filename,'rb')
			g=BinaryReader(file)
			animParser(filename,g)
			file.close()
		else:
			file=open(filename,'rb')
			g=BinaryReader(file)
			rdmParser([],filename,g)
			file.close()
		
	if ext=='cfg':
		file=open(filename,'rb')
		g=file.readlines()
		matList=cfgParser(filename,g)
		file.close()
		
		dirname=os.path.dirname(filename)
		basename=os.path.basename(filename)
		filename=dirname+os.sep+'rdm'+os.sep+basename.replace('.cfg','_lod2.rdm')	
		if os.path.exists(filename)==False:
			filename=dirname+os.sep+'rdm'+os.sep+basename.replace('.cfg','_lod1.rdm')	
		if os.path.exists(filename)==True:
			file=open(filename,'rb')
			g=BinaryReader(file)
			rdmParser(matList,filename,g)
			file.close()
		
 
	
Blender.Window.FileSelector(Parser,'import','Anno 2070 files: *.cfg - textured model, *.rdm - model, animation') 
	