from inc_noesis import *
import noesis
import rapi

texList = []

def registerNoesisTypes():
	handle = noesis.register("Dragons Crown PS3 Textures", ".ftx")
	noesis.setHandlerTypeCheck(handle, FTXCheckType)
	noesis.setHandlerLoadRGBA(handle, FTXLoadRGBA)
	#noesis.logPopup()
	return 1

def FTXCheckType(data):
	bs = NoeBitStream(data)
	magic = bs.readBytes(4).decode("ASCII")
	if magic != 'FTEX':
		return 0
	return 1

def FTXLoadRGBA(data, texList):
	ctx = rapi.rpgCreateContext()
	bs = NoeBitStream(data)
	header = bs.read("8I")
	TexNames = []
	for a in range(0, header[3]):
		texName = bs.readBytes(32).decode("ASCII").rstrip("\0")
		texInfo = bs.read("4I")
		TexNames.append(texName)
	bs.seek(header[2], NOESEEK_ABS)
	for a in range(0, header[3]):
		bs.seek(0x40, NOESEEK_REL)
		texInfo = bs.read(">" + "8I3H")
		bs.seek(0x5A, NOESEEK_REL)
		data = bs.readBytes(texInfo[5])
		imgWidth, imgHeight = texInfo[8], texInfo[9]
		texFmt = 0
		#DXT1
		if texInfo[6] == 0x86010200:
			texFmt = noesis.NOESISTEX_DXT1
		#DXT3
		elif texInfo[6] == 0x87010200:
			texFmt = noesis.NOESISTEX_DXT3
		#DXT5
		elif texInfo[6] == 0x88010200:
			texFmt = noesis.NOESISTEX_DXT5
		#raw
		elif texInfo[6] == 0x85010200:
			texFmt = noesis.NOESISTEX_RGBA32
		#unknown, not handled
		else:
			#print("WARNING: Unhandled image format " + repr(texInfo[6] ) + " - " + repr(imgWidth) + "x" + repr(imgHeight) + " - " + repr(len(data)))
			return None

		tex1 = NoeTexture(TexNames[a], imgWidth, imgHeight, data, texFmt)
		texList.append(tex1)

	mbsFileName = rapi.getExtensionlessName(rapi.getInputName()) + ".mbs"
	#print(mbsFileName)
	if (rapi.checkFileExists(mbsFileName)):
		#print("Yes")
		data = rapi.loadIntoByteArray(mbsFileName)
		bs = NoeBitStream(data)
		bs.seek(0x50, NOESEEK_ABS)
		fmbsCount = bs.read(">" + "16H")
		fmbsOff = bs.read(">" + "12I")
		#print(fmbsCount, fmbsOff)
	return 1