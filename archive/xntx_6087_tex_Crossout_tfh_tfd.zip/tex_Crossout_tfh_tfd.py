from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Crossout", ".tfh")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    return 1
    
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.readBits(4)
    imgWidth = bs.readBits(12)
    imgHeight = bs.readUShort() // 4
    print(imgWidth, "x", imgHeight)
    numMips = bs.readBits(4)
    print(numMips, ":numMips")
    bs.readBits(4)
    imgFmt2 = bs.readUByte()
    print(hex(imgFmt2), ":imgFmt2")
    imgFmt = bs.readUByte()
    bs.readByte()
    print(hex(imgFmt), ":imgFmt")
    tfdFile = rapi.getExtensionlessName(rapi.getInputName()) + ".tfd"
    print(tfdFile, ":tfd file")
    bs2 = NoeBitStream(rapi.loadIntoByteArray(tfdFile))
    #DXT1
    if imgFmt == 0x3b or imgFmt == 0x38 or imgFmt == 0x5b or imgFmt2 == 0x7 or imgFmt2 == 0xb:
        datasize = imgWidth * imgHeight // 2
        texFmt = noesis.NOESISTEX_DXT1 
        print("DXT1")
    #DXT5
    elif imgFmt == 0x53 or imgFmt == 0x50 or imgFmt2 == 0xa: 
        datasize = imgWidth * imgHeight
        texFmt = noesis.NOESISTEX_DXT5
        print("DXT5")
        #DXT5
    #RGBA32
    elif imgFmt == 0x28 or imgFmt == 0x0 or imgFmt2 == 0x5 or imgFmt2 == 0x8:
        datasize = imgWidth * imgHeight * 4
        texFmt = noesis.NOESISTEX_RGBA32
        print("RGBA32")

    if numMips == 1:
        bs2.seek(0, NOESEEK_ABS)        
    else:
        bs.seek((numMips * 12) - 12, NOESEEK_REL)
        mainMipOffset = bs.readUInt()
        print(hex(mainMipOffset), ":mainMipOffset")
        datasize = bs.readUInt()
        imgSize = bs.readUInt() #??
        bs2.seek(mainMipOffset, NOESEEK_ABS)        
    print(hex(datasize), ":datasize")
    data = bs2.readBytes(datasize)      
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1