Final Fantasy Type-0 HD PC Decryptor + Encryptor
By AyuanX, v1.0, 2015-09-14

Usage: FFType0HD_Cryptor.exe [-d] [-e] INPUT_FILE [OUTPUT_FILE]
  -d            (Decryption)
  -e            (Encryption)
  OUTPUT_FILE   (Optional, can be omitted)

Examples:
  FFType0HD_Cryptor.exe -d EPSC01.hxmf
  FFType0HD_Cryptor.exe -e TYPE0SYS.BIN

-----------------------------------------------------------------

PS:
There are two kinds of files that are encrypted in FFType-0 HD PC:
A) All save data files (e.g. TYPE0SYS.BIN / TYPE0DAT.BIN)
   They are meaningful binary files after decryption.

B) All pre-rendered movie files (e.g. *.hxmf)
   They are standard MP4/H264 files after decryption.

PPS:
This tool is capable to encrypt modified files back to the game.
Both x86 and x64 versions are provided.
Minimum operating system: Windows Vista and later, up to Windows 10.