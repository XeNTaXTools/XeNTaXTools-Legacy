import newGameLib
from newGameLib import *
import Blender	
import math
from math import *

def mdlParser(filename,file):
	#g.debug=True
	lines=file.readlines()
	id=0
	#for id in range len(lines):
	skeleton=Skeleton()
	skeleton.BONESPACE=True
	skeleton.NICE=True
	#skeleton.BONESORT=True
	meshList=[]
	while(True):
	
		if id==len(lines):break
		else:
			line=lines[id]
			
			if 'node ' in line and 'endnode' not in line and ' dummy ' in line:
				#print line
				bone=Bone()
				bone.name=line.strip().split()[2]
				skeleton.boneList.append(bone)
				matrix=Matrix()
				
			if 'node ' in line and 'endnode' not in line and ' trimesh ' in line:
				#print line
				bone=Bone()
				bone.name=line.strip().split()[2]
				skeleton.boneList.append(bone)
				mesh=Mesh()
				mesh.render=0
				#print 'mesh'
				mesh.boneName=bone.name
				meshList.append(mesh)
				matrix=Matrix()
				
			if 'node ' in line and 'endnode' not in line and ' danglymesh ' in line:
				#print line
				bone=Bone()
				bone.name=line.strip().split()[2]
				skeleton.boneList.append(bone)
				mesh=Mesh()
				mesh.render=0
				#print 'mesh'
				mesh.boneName=bone.name
				meshList.append(mesh)
				matrix=Matrix()
				
			if 'bitmap ' in line:
				mat=Mat()
				mat.TRIANGLE=True
				mat.diffuse=os.path.dirname(filename)+os.sep+line.strip().split()[1]+'.tga'
				print mat.diffuse
				mesh.matList.append(mat)
				
			if 'parent ' in line:
				bone.parentName=line.strip().split()[1]
				if bone.parentName=='NULL':
					bone.parentName=None
					
			if 'render ' in line:
				mesh.render=int(line.strip().split()[1])
				
			if 'position ' in line:
				#bone.matrix=Matrix()
				matrix=VectorMatrix(map(float,line.strip().split()[1:4]))
				#bone.matrix*=posMatrix#.invert()
				
			if 'orientation ' in line:
				#matrix=Matrix()
				nwangle=map(float,line.strip().split()[1:5])
				#print nwangle       
				phi2 = 0.5 * nwangle[3]			
				tmp = math.sin(phi2)
				qx = nwangle[0]*tmp
				qy = nwangle[1]*tmp
				qz = nwangle[2]*tmp
				qw = math.cos(phi2)
				rotMatrix=QuatMatrix([qx,qy,qz,qw]).resize4x4()#.invert()
				matrix=rotMatrix*matrix
					
					
			if 'endnode' in line:
				#print
				#print matrix
				bone.matrix=matrix
				
			if ' verts ' in line:
				vertCount=int(line.split()[1])
				for m in range(vertCount):
					id+=1
					line=lines[id]
					mesh.vertPosList.append(map(float,line.strip().split()))
			if 'faces ' in line:
				faceCount=int(line.split()[1])
				for m in range(faceCount):
					id+=1
					line=lines[id]
					mesh.faceList.append(map(int,line.strip().split()[:3]))
				#print matrix	
				#mesh.matrix=matrix	
				#mesh.draw()
				#mesh.object.setMatrix(matrix)				
			if ' tverts ' in line:
				vertCount=int(line.split()[1])
				for m in range(vertCount):
					id+=1
					line=lines[id]
					u,v=map(float,line.strip().split()[:2])
					mesh.vertUVList.append([u,1-v])
				
			id+=1	
	#g.tell()
	skeleton.draw()
	for mesh in meshList:
		if len(mesh.vertUVList)>0:
			#print len(mesh.vertPosList),len(mesh.vertUVList),mesh.boneName
			print len(mesh.vertPosList),len(mesh.vertUVList),mesh.boneName,mesh.name
			if mesh.render==1:
				mesh.draw()
				#print len(mesh.vertPosList),len(mesh.vertUVList),mesh.boneName,mesh.name
				Blender.Window.RedrawAll()
				mesh.object.setMatrix(skeleton.object.getData().bones[mesh.boneName].matrix['ARMATURESPACE'])
	
def Parser(filename):	
	print '='*70
	print filename
	print '='*70
	ext=filename.split('.')[-1].lower()	
	
	if ext=='mdl':
		file=open(filename,'r')
		#g=BinaryReader(file)
		#g.logOpen()
		#g=file.readlines
		mdlParser(filename,file)
		#g.logClose()
		file.close()
 
	
Blender.Window.FileSelector(Parser,'import','... files: *.... - model') 
	