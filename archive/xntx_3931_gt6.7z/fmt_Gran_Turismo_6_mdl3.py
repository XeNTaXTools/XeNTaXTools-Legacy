#Gran Turismo 6
from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Gran Turismo 6", ".mdl3")
	noesis.setHandlerTypeCheck(handle, mdl3modCheckType)
	noesis.setHandlerLoadModel(handle, mdl3modLoadModel)

	#noesis.logPopup()

	return 1


def mdl3modCheckType(data):
	td = NoeBitStream(data)
	return 1


class mdl3File: 
         
	def __init__(self, bs):
		self.bs = bs
		self.texList  = []
		self.matList  = [] 
		self.boneList = []
		self.boneMap  = []
		self.fvfTable = []
		self.offsetList = []
		self.meshOffsets = []

	def loadAll(self, bs):
		self.loadHeader(bs)
		if self.zlibOffset != 0:
			print("Compressed")
			self.loadZlibHeader(bs)
		else:
			print("Not Compressed")
		self.loadTxs3(bs)
		self.loadSkel(bs)
		self.loadfvf(bs)

	def loadHeader(self, bs):
		#0x0
		MDL3magic, totalSize, null00, unkE = bs.read(">" + "4I")
		self.count00, self.count01, self.count02, self.count03 = bs.read(">" + "4H")
		self.fvfCount, self.boneCount, count06, self.count07 = bs.read(">" + "4H")
		count08, count09, count10, count11 = bs.read(">" + "4H")
		count12, self.count13, count14, count15 = bs.read(">" + "4H")

		#0x30
		self.offst00, self.offst01, self.offst02, self.offst03 = bs.read(">" + "4i")
		self.fvfOffst, offst05, self.txs3Offst, self.shdsOffst = bs.read(">" + "4I")
		self.boneOffst, self.offst09, self.offst10, offst11 = bs.read(">" + "4I")
		self.countOffst13, self.offst13, offst14, offst15 = bs.read(">" + "4I")

		#0x70
		unkData00 = bs.read(">" + "27I")

		#0xDC
		self.zlibOffset, Null = bs.read(">" + "2I")
		count16, count17, unk02, count18, count19 = bs.read(">" + "2H2BH")
		offst16, offst17, offst18, offst19        = bs.read(">" + "4I")


	def loadZlibHeader(self, bs):
		bs.seek(self.zlibOffset, NOESEEK_ABS)
		baseName = (rapi.getExtensionlessName(rapi.getLocalFileName(rapi.getInputName()))) + "_s"
		filePath = rapi.getDirForFilePath(rapi.getInputName()) + baseName + ".multiZlib"
		self.decompData = bytearray()
		if (rapi.checkFileExists(filePath)):
			multiZlib = rapi.loadIntoByteArray(filePath)
			bd = NoeBitStream(multiZlib)
		zlibInfo1 = bs.read(">" + "4H2I")
		for a in range(0, zlibInfo1[1]):
			bs.seek(zlibInfo1[4] + (0xC * a), NOESEEK_ABS)
			zlibHId, zlibHCount, zlibHoff = bs.read(">" + "3I")
			#print("Section " + str(a))
			for b in range(0, zlibHCount):
				bs.seek(zlibHoff + (0x18 * b), NOESEEK_ABS)
				null00, chunkStart, chunkCount00, chunkCount01 = bs.read(">" + "2I2H")
				chunkInfoOff00, chunkCount02, chunkCount03, chunkInfoOff01 = bs.read(">" + "IHHI")
				#print("Chunk1")
				#print("chunkStart - " + str(chunkStart))
				for c in range(0, (chunkCount00 + chunkCount01)):
					bs.seek(chunkInfoOff00 + (0x8 * c), NOESEEK_ABS)
					zFlag, zSize, uSize = bs.read(">" + "2HI")
					bd.seek(chunkStart, NOESEEK_ABS)
					cmpData = bd.readBytes(zSize)
					if zFlag == 0:
						self.decompData += cmpData
					else:
						self.decompData += rapi.decompInflate(cmpData, uSize, -15)

					chunkStart += zSize
					#print([zFlag, zSize, uSize])
				#print("Chunk2")
				for c in range(0, (chunkCount02 + chunkCount03)):
					bs.seek(chunkInfoOff01 + (0x10 * c), NOESEEK_ABS)
					null00, chunkStart2, chunkCount04, chunkCount05, zlibHoff2 = bs.read(">" + "2I2HI")
					#print("chunk2Start - " + str(chunkStart2))
					for d in range(0, (chunkCount04 + chunkCount05)):
						bs.seek(zlibHoff2 + (0x8 * d), NOESEEK_ABS)
						zFlag, zSize, uSize = bs.read(">" + "2HI")

						bd.seek(chunkStart2, NOESEEK_ABS)
						cmpData = bd.readBytes(zSize)

						if zFlag == 0:
							self.decompData += cmpData
						else:
							self.decompData += rapi.decompInflate(cmpData, uSize, -15)

						chunkStart2 += zSize
						#print([zFlag, zSize, uSize])
		self.bd = NoeBitStream(self.decompData, NOE_BIGENDIAN)
		self.compHeader = self.bd.read(">" + "5I2H2I")
		#print(len(decompData))
		#baseName = (rapi.getExtensionlessName(rapi.getLocalFileName(rapi.getInputName()))) + "_s"
		#filePath = (rapi.getDirForFilePath(rapi.getInputName()).replace('\\','/')) + baseName + ".deCompressed"
		#f = open(filePath, 'wb');
		#f.write(decompData)
		#f.close()


	def loadTxs3(self, bs):
		bs.seek(self.txs3Offst, NOESEEK_ABS)
		txs3header = bs.read(">" + "9I")
		texInfo = []
		for a in range(0, txs3header[5]):
			bs.seek(txs3header[7] + (a * 0x20), NOESEEK_ABS)
			txs3Data = bs.read(">" + "2I4B4H3I")
			texInfo.append(txs3Data)
			if txs3Data[0] != 0:
				bs.seek(txs3Data[0], NOESEEK_ABS)
				texData = bs.readBytes(txs3Data[1])
				texFmt = noesis.NOESISTEX_RGBA32
				if txs3Data[3] == 133:
					texData = rapi.imageFromMortonOrder(texData, txs3Data[6], txs3Data[7])
					texFmt = noesis.NOESISTEX_RGBA32
				elif txs3Data[3] == 134:
					texFmt = noesis.NOESISTEX_DXT1
				elif txs3Data[3] == 135:
					texFmt = noesis.NOESISTEX_DXT3
				elif txs3Data[3] == 136:
					texFmt = noesis.NOESISTEX_DXT5
				elif txs3Data[3] == 165:
					texFmt = noesis.NOESISTEX_RGBA32
				self.texList.append(NoeTexture(str(a), txs3Data[6], txs3Data[7], texData, texFmt))
		if self.zlibOffset != 0:
			print(self.compHeader)
			for a in range(0, self.compHeader[6]):
				self.bd.seek(self.compHeader[8] + (0x10 * a), NOESEEK_ABS)
				index, offset = self.bd.read(">" + "2I")
				self.bd.seek(offset, NOESEEK_ABS)
				texData = self.bd.readBytes(texInfo[index][1])
				#print(txs3Data)
				texFmt = noesis.NOESISTEX_RGBA32
				if texInfo[index][3] == 133:
					texData = rapi.imageFromMortonOrder(texData, texInfo[index][6], texInfo[index][7])
					texFmt = noesis.NOESISTEX_RGBA32
				elif texInfo[index][3] == 134:
					texFmt = noesis.NOESISTEX_DXT1
				elif texInfo[index][3] == 135:
					texFmt = noesis.NOESISTEX_DXT3
				elif texInfo[index][3] == 136:
					texFmt = noesis.NOESISTEX_DXT5
				elif texInfo[index][3] == 165:
					texFmt = noesis.NOESISTEX_RGBA32
				self.texList.append(NoeTexture(str(a), texInfo[index][6], texInfo[index][7], texData, texFmt))

			self.bd.seek(self.compHeader[2], NOESEEK_ABS)
			compBase = self.bd.tell()
			self.compHeader = self.bd.read(">" + "5I2H2I")
			for a in range(0, self.compHeader[6]):
				self.bd.seek(compBase + self.compHeader[8] + (0x10 * a), NOESEEK_ABS)
				index, offset = self.bd.read(">" + "2I")
				self.bd.seek(offset + compBase, NOESEEK_ABS)
				texData = self.bd.readBytes(texInfo[index][1])
				#print(txs3Data)
				texFmt = noesis.NOESISTEX_RGBA32
				if texInfo[index][3] == 133:
					texData = rapi.imageFromMortonOrder(texData, texInfo[index][6], texInfo[index][7])
					texFmt = noesis.NOESISTEX_RGBA32
				elif texInfo[index][3] == 134:
					texFmt = noesis.NOESISTEX_DXT1
				elif texInfo[index][3] == 135:
					texFmt = noesis.NOESISTEX_DXT3
				elif texInfo[index][3] == 136:
					texFmt = noesis.NOESISTEX_DXT5
				elif texInfo[index][3] == 165:
					texFmt = noesis.NOESISTEX_RGBA32
				self.texList.append(NoeTexture(str(a) + str(a), texInfo[index][6], texInfo[index][7], texData, texFmt))



	def loadSkel(self, bs):
		for a in range(0, self.boneCount):
			bs.seek(self.boneOffst + (a * 0x48), NOESEEK_ABS)
			boneMtx = NoeMat44.fromBytes(bs.readBytes(64), NOE_BIGENDIAN).toMat43().inverse()
			boneNameoff = bs.readUInt()
			bMirror, bParent, unk, bId = bs.read(">" + "4B")
			bs.seek(boneNameoff, NOESEEK_ABS)
			boneName = bs.readString()
			newBone = NoeBone(bId, boneName, boneMtx, None, bParent)
			self.boneList.append(newBone)


	def loadfvf(self, bs):
		#FVF Table
		for a in range(0, self.fvfCount):
			bs.seek(self.fvfOffst + (a * 0x78), NOESEEK_ABS)
			print(bs.tell())
			fvfData = bs.read(">" + "6I4B23I")
			print(fvfData)
			bs.seek(fvfData[0], NOESEEK_ABS)
			myString = bs.readString()
			print([str(a), myString, fvfData[7]])
			tmp = []
			for b in range(0, fvfData[6]):
				bs.seek(fvfData[2] + (b * 8), NOESEEK_ABS)
				fvfData3 = bs.read(">" + "I4B")#comp name, comp start, comp count, data type
				#print(fvfData3)
				bs.seek(fvfData3[0], NOESEEK_ABS)
				myString = bs.readString()
				print([myString, fvfData3])
				tmp.append([myString, fvfData3, fvfData[7]])
			self.fvfTable.append(tmp)


vertexLoaderDict = {

}

def mdl3modLoadModel(data, mdlList):
	ctx = rapi.rpgCreateContext()
	mdl3 = mdl3File(NoeBitStream(data, NOE_BIGENDIAN))
	rapi.rpgSetOption(noesis.RPGOPT_BIGENDIAN, 1)
	mdl3.loadAll(mdl3.bs)
	try:
		mdl = rapi.rpgConstructModel()
	except:
		mdl = NoeModel()
	mdl.setModelMaterials(NoeModelMaterials(mdl3.texList, mdl3.matList))
	mdlList.append(mdl); mdl.setBones(mdl3.boneList)	
	return 1