#pragma once

#include "../../../Engine/Core/File.h"

namespace RainbowSixSiege
{
	const unsigned int FORGE_VERSION = 29;

#pragma pack(push, 1)//We don't want the compiler to pad these structs since we directly read memory into them and use their original sizes to do so.

	struct CompressedEntryInfo
	{
		unsigned short m_uncompressedSize;
		unsigned short m_compressedSize;
	};

	struct CompressedChunkInfo
	{
		unsigned short m_unk00;
		unsigned short m_unk01;
		unsigned short m_unk02;
		unsigned short m_unk03;

		unsigned int m_numChunks;
	};

	struct CompressedChunk
	{
		unsigned int m_magic;//0x57FBAA33
		unsigned int m_unk00;
		unsigned short m_unk01;
		unsigned short m_unk02;
		unsigned char m_unk03;
		unsigned short m_unk04;
		unsigned int m_unk05;

		unsigned short m_unknownLength;
		unsigned short m_unknownLength2;//Duplicate

		unsigned int m_unk06;
		unsigned short m_unk07;
		unsigned int m_unk08;
		unsigned char m_unk09;

		//char[m_unknownLength2];
	};

	struct FileEntry
	{
		unsigned long long m_fileDataOffset;//Current offset?
		unsigned int m_unk00;
		unsigned int m_numCompressedChunks;//Compression flag/numcompressed chunks?
		unsigned int m_fileDataLength;
	};

	struct NameTable
	{
		unsigned int m_currentOffset;//No?
		unsigned long long m_fileHash;
		unsigned int m_unk00;

		unsigned int m_unk01;
		unsigned int m_unk02;
		unsigned int m_unk03;

		unsigned int m_currentArrayIndex;//Current index+1
		unsigned int m_unk05;//prevfilecount
		unsigned int m_unk06;
		unsigned int m_timeStamp;

		char m_fileName[256];

		unsigned int m_unk07;
		unsigned int m_unk08;
		unsigned int m_unk09;
		unsigned int m_unk10;
		unsigned int m_unk11;
	};

	struct ArchiveInfo2
	{
		unsigned int m_numFiles;
		unsigned int m_unk00;
		unsigned int m_offsetIndexTable;
		unsigned int m_unk01;

		int m_unk02;
		int m_unk03;
		unsigned int m_unk04;
		unsigned int m_unk05;
		unsigned long long m_offsetNameTable;
		unsigned long long m_offsetUnk00;
	};

	struct ArchiveInfo
	{
		unsigned int m_numFiles;
		unsigned int m_unk00;
		unsigned int m_unk01;
		unsigned int m_unk02;

		unsigned int m_unk03;
		int m_unk04;
		int m_unk05;
		unsigned int m_unk06;//m_numFiles +2 may include first two files GlobalMetaFile and the other...
		unsigned int m_unk07;

		unsigned long long m_offsetArchiveInfo2;
	};

	struct ForgeHeader
	{
		char m_magic[9]; //"scimitar "
		unsigned int m_fileVersion;
		unsigned long long m_offsetArchiveInfo;
		unsigned long long m_unk00;
		unsigned char m_unk01;
	};

#pragma pack(pop)

	void loadArchive(CFileIO& io);
};