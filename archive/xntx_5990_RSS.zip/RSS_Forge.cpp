#include "RSS_Forge.h"

#include "../../../Engine/Core/Compression/Compression_lzo.h"
#include "../../../Engine/Resource/MemoryBuffer.h"

#include <iostream>
#include <cassert>
#include <vector>

void RainbowSixSiege::loadArchive(CFileIO& io)
{
	RainbowSixSiege::ForgeHeader forgeHeader;
	io.read(reinterpret_cast<char*>(&forgeHeader), sizeof(RainbowSixSiege::ForgeHeader));

	RainbowSixSiege::ArchiveInfo archiveInfo;
	io.seek(forgeHeader.m_offsetArchiveInfo, SEEK_ABSOLUTE);
	io.read(reinterpret_cast<char*>(&archiveInfo), sizeof(RainbowSixSiege::ArchiveInfo));

	RainbowSixSiege::ArchiveInfo2 archiveInfo2;
	io.seek(archiveInfo.m_offsetArchiveInfo2, SEEK_ABSOLUTE);
	io.read(reinterpret_cast<char*>(&archiveInfo2), sizeof(RainbowSixSiege::ArchiveInfo2));

	for (unsigned int i = 0; i < archiveInfo2.m_numFiles; i++)
	{
		//Read file entry info
		RainbowSixSiege::FileEntry fileEntry;
		io.seek(archiveInfo2.m_offsetIndexTable + (i * sizeof(RainbowSixSiege::FileEntry)) , SEEK_ABSOLUTE);
		io.read(reinterpret_cast<char*>(&fileEntry), sizeof(RainbowSixSiege::FileEntry));

		//Read name table info
		io.seek(archiveInfo2.m_offsetNameTable + (i * sizeof(RainbowSixSiege::NameTable)), SEEK_ABSOLUTE);
		RainbowSixSiege::NameTable nameTable;
		io.read(reinterpret_cast<char*>(&nameTable), sizeof(RainbowSixSiege::NameTable));

		io.seek(fileEntry.m_fileDataOffset, SEEK_ABSOLUTE);

#if _DEBUG
		std::cout << "File Entry Offset: " << fileEntry.m_fileDataOffset << std::endl;
#endif

		CFileIO out(nameTable.m_fileName, CFIO_WRITE_NEW, false);

		if (fileEntry.m_numCompressedChunks > 0)//No? maybe comp flag?
		{
			//Decompress file
			RainbowSixSiege::CompressedChunk compressedChunk;
			io.read(reinterpret_cast<char*>(&compressedChunk), sizeof(RainbowSixSiege::CompressedChunk));

			io.seek(compressedChunk.m_unknownLength, SEEK_RELATIVE);

			RainbowSixSiege::CompressedChunkInfo compressedChunkInfo;
			io.read(reinterpret_cast<char*>(&compressedChunkInfo), sizeof(RainbowSixSiege::CompressedChunkInfo));
			
#if _DEBUG
			std::cout << "Compressed Entry Info Offset: " << io.getPos() << std::endl;
#endif
			std::vector<RainbowSixSiege::CompressedEntryInfo> compressedEntryInfo;
			for (unsigned int j = 0; j < compressedChunkInfo.m_numChunks; j++)
			{
				compressedEntryInfo.emplace_back();
				io.read(reinterpret_cast<char*>(&compressedEntryInfo.back()), sizeof(RainbowSixSiege::CompressedEntryInfo));
			}
			
			for (unsigned int j = 0; j < compressedChunkInfo.m_numChunks; j++)
			{
				io.seek(4, SEEK_RELATIVE);//probably checksum
				RainbowSixSiege::CompressedEntryInfo& entryInfo = compressedEntryInfo[j];

				char* compressedData = new char[entryInfo.m_compressedSize];
#if _DEBUG
				std::cout << "Compressed Chunk Data Offset: " << io.getPos() << std::endl;
#endif		
				io.read(compressedData, entryInfo.m_compressedSize);
#if _DEBUG
				std::cout << "Compressed Chunk End Offset: " << io.getPos() << std::endl;
#endif

				if (entryInfo.m_compressedSize == entryInfo.m_uncompressedSize)//Not compressed
				{
					out.write(compressedData, entryInfo.m_compressedSize);
				}
				else
				{
					LzoCompression lzoDecomp(compressedData, entryInfo.m_compressedSize, entryInfo.m_uncompressedSize);
					CMemoryBuffer* memBuff = lzoDecomp.decompressData();
					out.write(memBuff->getBuffer(), entryInfo.m_uncompressedSize);
				}
				delete[] compressedData;
			}

			

#if _DEBUG
			std::cout << "End of compressed data: " << io.getPos() << std::endl;
#endif
		}
		else
		{
			char* fileData = new char[fileEntry.m_fileDataLength];
			io.read(fileData, fileEntry.m_fileDataLength);
			out.write(fileData, fileEntry.m_fileDataLength);
			delete[] fileData;
		}

		out.close();
	}
}