#Noesis python importer - Skate 3 .rx2 files
from inc_noesis import *
import noesis
#rapi methods should only be used during handler callbacks
import rapi
#registerNoesisTypes is called by Noesis to allow the script to register formats.
#Do not implement this function in script files unless you want them to be dedicated format modules!
def registerNoesisTypes():
	handle = noesis.register("Skate 3 (X360)", ".rx2")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadModel(handle, noepyLoadModel)
	noesis.logPopup()
	#print("The log can be useful for catching debug prints from preview loads.\nBut don't leave it on when you release your script, or it will probably annoy people.")
	return 1
#check if it's this type based on the data
def noepyCheckType(data):
    bs = NoeBitStream(data)
    Magic = bs.readBytes(7)
    if Magic != b'\x89\x52\x57\x34\x78\x62\x32':
        return 0
    return 1  

#load the model
def noepyLoadModel(data, mdlList):
   VInfo = []
   VOff = []
   VBufferSize = []
   FInfo = []   
   FOff = []
   FBufferSize = []
   
   ctx = rapi.rpgCreateContext()
   bs = NoeBitStream(data, NOE_BIGENDIAN)
   bs.seek(0x20, NOESEEK_ABS)
   fileCount = bs.read(">i")
   bs.seek(12, NOESEEK_REL)
   fileTable = bs.read(">i")
   bs.seek(16, NOESEEK_REL)
   hdrSize = bs.read(">i")  
   bs.seek(fileTable[0], NOESEEK_ABS)
   meshCount = 0
   
   for i in range(0, fileCount[0]):
	    fileInfo = bs.read(">iiiii")
	    fileType = bs.readBytes(4)
	    
	    if fileType == b'\x00\x02\x00\xEA':
	   		bs.seek(-48, NOESEEK_REL)
	   		info = bs.read(">iiiiiiiiiiii")
	   		VOff.append([info[0]])
	   		VBufferSize.append([info[2]])
	   		VInfo.append([info[6]])
	   		meshCount +=1
	   				 			   		
	    elif fileType == b'\x00\x02\x00\xEB':
	   		bs.seek(-48, NOESEEK_REL)
	   		info = bs.read(">iiiiiiiiiiii")
	   		FOff.append([info[0]])
	   		FBufferSize.append([info[2]])
	   		FInfo.append([info[6]])	   						 			   		
   
   for i in range(0, meshCount):
   		bs.seek(VInfo[i][0] + 32, NOESEEK_ABS) #Seek to vertices info
   		VData = bs.read(">i")
   		VBsize = 0x1C
   		VCount = VData[0] / VBsize
   		bs.seek(FInfo[i][0] + 32, NOESEEK_ABS) #Seek to faces info  
   		FCount = bs.read(">i")   
   		
   		#Seek to Vertices Start
   		bs.seek(VOff[i][0] + hdrSize[0], NOESEEK_ABS)
   		VertBuff = bs.readBytes(VBufferSize[i][0])
   		rapi.rpgSetOption(noesis.RPGOPT_BIGENDIAN, 1)
   		rapi.rpgBindPositionBufferOfs(VertBuff, noesis.RPGEODATA_SHORT, VBsize, 0)
   		rapi.rpgBindUV1BufferOfs(VertBuff, noesis.RPGEODATA_SHORT, VBsize, 8)	
   		#Seek to Faces Start	
   		bs.seek(FOff[i][0] + hdrSize[0], NOESEEK_ABS)
   		FaceBuff = bs.readBytes(FBufferSize[i][0])
   		rapi.rpgCommitTriangles(FaceBuff, noesis.RPGEODATA_USHORT, FCount[0], noesis.RPGEO_TRIANGLE, 1)
   		mdl = rapi.rpgConstructModel()
   		mdlList.append(mdl)         #important, don't forget to put your loaded model in the mdlList
   		rapi.rpgClearBufferBinds()
   		rapi.rpgReset()   
 
   return 1