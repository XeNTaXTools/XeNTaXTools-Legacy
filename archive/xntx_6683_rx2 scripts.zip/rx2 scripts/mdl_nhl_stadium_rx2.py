#Noesis python importer - EA NHL games .rx2 stadium container files,  - version 1.0 
from inc_noesis import *
import noesis
#rapi methods should only be used during handler callbacks
import rapi
#registerNoesisTypes is called by Noesis to allow the script to register formats.
#Do not implement this function in script files unless you want them to be dedicated format modules!
def registerNoesisTypes():
	handle = noesis.register("NHL Legacy (X360) stadium models", ".rx2")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadModel(handle, noepyLoadModel)
	noesis.logPopup()
	#print("The log can be useful for catching debug prints from preview loads.\nBut don't leave it on when you release your script, or it will probably annoy people.")
	return 1
#check if it's this type based on the data
def noepyCheckType(data):
    bs = NoeBitStream(data)
    Magic = bs.readBytes(7)
    if Magic != b'\x89\x52\x57\x34\x78\x62\x32':
        return 0
    return 1  

#load the model
def noepyLoadModel(data, mdlList):
   VInfo = []
   VOff = []
   VBufferSize = []
   FInfo = []   
   FOff = []
   FBufferSize = []
   TexInfo = []
   TexOff = []
   TexBufferSize = []
   NameInfo = []
   
   ctx = rapi.rpgCreateContext()
   bs = NoeBitStream(data, NOE_BIGENDIAN)
   bs.seek(0x20, NOESEEK_ABS)
   fileCount = bs.read(">i")
   bs.seek(12, NOESEEK_REL)
   fileTable = bs.read(">i")
   bs.seek(16, NOESEEK_REL)
   hdrSize = bs.read(">i")  
   bs.seek(fileTable[0], NOESEEK_ABS)
   meshCount = 0
   texCount = 0
   
   for i in range(0, fileCount[0]):
	    fileInfo = bs.read(">iiiii")
	    fileType = bs.readBytes(4)
	   			    
	    if fileType == b'\x00\x02\x00\x05':
	   		bs.seek(-48, NOESEEK_REL)
	   		info = bs.read(">iiiiiiiiiiii")
	   		VOff.append([info[0]])
	   		VBufferSize.append([info[2]])
	   		VInfo.append([info[6]])
	   				 			   		
	    elif fileType == b'\x00\x02\x00\x07':
	   		bs.seek(-48, NOESEEK_REL)
	   		info = bs.read(">iiiiiiiiiiii")
	   		FOff.append([info[0]])
	   		FBufferSize.append([info[2]])
	   		FInfo.append([info[6]])	   		
	    
	    elif fileType == b'\x00\x02\x00\x09':
	   		meshCount +=1
   
   for i in range(0, meshCount):
   		bs.seek(VInfo[i][0] + 32, NOESEEK_ABS) #Seek to vertices info
   		VData = bs.read(">HHi") #Read WORD, WORD, DWORD in big endian
   		VBsize = VData[0]
   		if VBsize == 28:
   			UVpos = 16
   		elif VBsize == 32:
   			UVpos = 12
   		elif VBsize == 24:
   			UVpos = 12
   		else:
   			UVpos = 16
			  					
   		VCount = VData[2]
   		bs.seek(FInfo[i][0] + 32, NOESEEK_ABS) #Seek to faces info  
   		FCount = bs.read(">HH")   
   		
   		bs.seek(VOff[i][0] + hdrSize[0], NOESEEK_ABS) #Seek to Vertices Start
   		VertBuff = bs.readBytes(VBufferSize[i][0])
   		rapi.rpgSetOption(noesis.RPGOPT_BIGENDIAN, 1)
   		rapi.rpgBindPositionBufferOfs(VertBuff, noesis.RPGEODATA_FLOAT, VBsize, 0)
   		rapi.rpgBindUV1BufferOfs(VertBuff, noesis.RPGEODATA_FLOAT, VBsize, UVpos)
   		bs.seek(FOff[i][0] + hdrSize[0], NOESEEK_ABS) #Seek to Faces Start
   		FaceBuff = bs.readBytes(FBufferSize[i][0])
   		rapi.rpgCommitTriangles(FaceBuff, noesis.RPGEODATA_USHORT, FCount[1], noesis.RPGEO_TRIANGLE, 1)
   		mdl = rapi.rpgConstructModel()
   		mdlList.append(mdl)         #important, don't forget to put your loaded model in the mdlList
   		rapi.rpgClearBufferBinds()
   		rapi.rpgReset()   
 
   return 1