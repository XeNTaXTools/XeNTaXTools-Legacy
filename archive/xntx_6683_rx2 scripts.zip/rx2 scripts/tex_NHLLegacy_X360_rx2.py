#Noesis Python model import+export test module, imports/exports some data from/to a made-up format
from inc_noesis import *
import noesis
#rapi methods should only be used during handler callbacks
import rapi
#registerNoesisTypes is called by Noesis to allow the script to register formats.
#Do not implement this function in script files unless you want them to be dedicated format modules!
def registerNoesisTypes():
	handle = noesis.register("NHL Legacy (X360) v1.1", ".rx2") #Support Skate 3 and Def Jam textures also
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
	noesis.logPopup()
	#print("The log can be useful for catching debug prints from preview loads.\nBut don't leave it on when you release your script, or it will probably annoy people.")
	return 1
#check if it's this type based on the data
def noepyCheckType(data):
    bs = NoeBitStream(data)
    Magic = bs.readBytes(7)
    if Magic != b'\x89\x52\x57\x34\x78\x62\x32':
        return 0
    return 1  

texList = []
def noepyLoadRGBA(data, texList):
   baseName = rapi.getExtensionlessName(rapi.getLocalFileName(rapi.getLastCheckedName()))
   TexInfo = []
   TexOff = []
   TexBufferSize = []
   NameInfo = []
   NameOff = []
   TexNames = []
   bs = NoeBitStream(data, NOE_BIGENDIAN)   
   bs.seek(0x10, NOESEEK_ABS)
   version = bs.readBytes(3)
   bs.seek(13, NOESEEK_REL)   
   fileCount = bs.read(">i")
   bs.seek(12, NOESEEK_REL)
   fileTable = bs.read(">i")
   bs.seek(16, NOESEEK_REL)
   hdrSize = bs.read(">i")
   bs.seek(fileTable[0], NOESEEK_ABS)
   texCount = 0
   names = 0
   #check file types and file info		   			   		
   for i in range(0, fileCount[0]):
   		fileInfo = bs.read(">iiiii")
   		fileType = bs.readBytes(4)
   		if fileType == b'\x00\x02\x00\x03':
	   		bs.seek(-48, NOESEEK_REL)
	   		info = bs.read(">iiiiiiiiiiii")
	   		TexOff.append([info[0]])
	   		TexBufferSize.append([info[2]])
	   		TexInfo.append([info[6] + 33])
	   		texCount +=1
	   	elif fileType == b'\x00\xEC\x00\x10':
	   		bs.seek(-24, NOESEEK_REL)
	   		info = bs.read(">iiiiii")
	   		NameInfo.append([info[0]])
	   		names += 1
	   	elif fileType == b'\x00\xEB\x00\x0B':
	   		bs.seek(-24, NOESEEK_REL)
	   		info = bs.read(">iiiiii")
	   		NameInfo.append([info[0]])
	   		names += 1	
	   	elif fileType == b'\x00\x02\x00\xE8':
	   		bs.seek(-48, NOESEEK_REL)
	   		info = bs.read(">iiiiiiiiiiii")
	   		TexOff.append([info[0]])
	   		TexBufferSize.append([info[2]])
	   		TexInfo.append([info[6] + 33])
	   		texCount +=1 	
	   			   	
   #Read all textures in texList		   			   		
   for i in range(0, texCount):
   		bs.seek(TexInfo[i][0], NOESEEK_ABS) #Seek to texture info
   		TexData = bs.read(">HBHHiii") #Read WORD, BYTE, WORD, WORD, DWORD, DWORD, DWORD in Big endian
   		imgFmt = TexData[1]
   		imgHeight = (TexData[2] + 1) * 8
   		imgWidth = (TexData[3] + 1) & 0x1FFF
   		
   		#Read texture names or read file basename if there are no texture names in the table
   		if names > 0: 
   			bs.seek(NameInfo[0][0], NOESEEK_ABS)
   			nameCount = bs.read(">HH")	
   			bs.seek(4, NOESEEK_REL)
   		
   			for j in range(0, nameCount[1]):
   				NameAddr = bs.read(">i")
   				NameType = bs.readBytes(4)
   				NameIndex = bs.read(">i")
   			
   				if NameType != b'\x00\x00\x00\x00':
   					NameOff.append([NameAddr[0]])
   				else:
   					NameOff.append([NameInfo[0][0] + NameAddr[0]])
   				
   			bs.seek(NameOff[i][0], NOESEEK_ABS)
   			TexNames.append(bs.readString())
   		else:
   			TexNames.append(baseName)
   		
   		print(TexNames)

   		bs.seek(TexOff[i][0] + hdrSize[0], NOESEEK_ABS) #Seek to file start address
   		data = bs.readBytes(TexBufferSize[i][0]) #Read texture buffer
   		texFmt = 0
   		#DXT1
   		if imgFmt == 0x52:
   			data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 8)
   			texFmt = noesis.NOESISTEX_DXT1
   		#DXT3
   		elif imgFmt == 0x53:
   			data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 16)
   			texFmt = noesis.NOESISTEX_DXT3
   		#DXT5
   		elif imgFmt == 0x54:
   			data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 16)
   			texFmt = noesis.NOESISTEX_DXT5
   		#DXT5 packed normal map
   		elif imgFmt == 0x71:
   			data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 16)
   			data = rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_ATI2)
   			texFmt = noesis.NOESISTEX_RGBA32
   		#DXT1 packed normal map
   		elif imgFmt == 0x7C:
   			data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 8)
   			data = rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_DXT1NORMAL)
   			texFmt = noesis.NOESISTEX_RGBA32	
   		#raw a8r8g8b8
   		elif imgFmt == 0x86:
   			data = rapi.imageUntile360Raw(data, imgWidth, imgHeight, 4)
   			data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "a8r8g8b8")
   			texFmt = noesis.NOESISTEX_RGBA32
   		#raw b5g6r5
   		elif imgFmt == 0x44:
   			data = rapi.imageUntile360Raw(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 2)
   			data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "b5g6r5")
   			texFmt = noesis.NOESISTEX_RGBA32

   		#unknown, not handled
   		else:
   			print("WARNING: Unhandled image format " + repr(imgFmt) + " - " + repr(imgWidth) + "x" + repr(imgHeight) + " - " + repr(len(data)))
   			return None
   				   			    			  	   					 		
   		tex1 = NoeTexture(TexNames[i], imgWidth, imgHeight, data, texFmt)
   		texList.append(tex1)
   return 1
