from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Bully (Android)", ".tex")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
	#noesis.logPopup()
	return 1

#check if it's this type based on the data
def noepyCheckType(data):
    bs = NoeBitStream(data)
    Magic = bs.readByte()
    print(Magic)
    if Magic != 7:
        return 0
    return 1
	
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.seek(0x14, NOESEEK_ABS)
    headOff = bs.readInt()             
    print(headOff, "headOff")
    bs.seek(headOff, NOESEEK_ABS)
    skip = bs.readInt()
    imgWidth = bs.readInt()            
    print(imgWidth, "imgwidth")
    imgHeight = bs.readInt()           
    print(imgHeight, "imgheight")
    imgFmt = bs.readInt()              
    print(imgFmt, "imgfmt")
    datasize = bs.readInt()        
    data = bs.readBytes(datasize)      
    #DXT1
    if imgFmt == 9:
        rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_DXT1)
        texFmt = noesis.NOESISTEX_DXT1
    #Alpha 1/8 ?
    elif imgFmt == 11:
        data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "r0 g0 b0 a8")
        texFmt = noesis.NOESISTEX_RGBA32
    #unknown, not handled
    else:
        print("WARNING: Unhandled image format")
        return None
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1