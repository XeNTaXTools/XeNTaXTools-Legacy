#ifndef EMAView_H
#define EMAView_H

#include "D3DView.h"
#include "EMGView.h"
#include "EMAData.h"
#include "EMBChunk.h"
#include "resource.h"
#include <string.h>
#include <stdio.h>
#include <string>


#define D3DFVF_MY_VERTEX ( D3DFVF_XYZ | D3DFVF_DIFFUSE )
struct EMAVertex
{
	float p[3]; // Position of vertex in 3D space
    DWORD color;   // Color of vertex
};
class EMAView : public D3DView, public ViewActionable
{
    EMAData emaData;
    LPDIRECT3DVERTEXBUFFER9 m_skelettonLinesVertexBuffer;
    unsigned long m_primitiveCount;

    POINT ptLastMousePosit;
    POINT ptCurrentMousePosit;
    float m_fSpinX;
    float m_fSpinY;
    float m_zoom;
public:
    EMAView (LPDIRECT3DDEVICE9 d3dDevice)
    : D3DView (d3dDevice)
    , m_primitiveCount(0)
    {       
        m_fSpinX = 0.0f;
        m_fSpinY = 0.0f;
        m_zoom = 2.0f;

        m_skelettonLinesVertexBuffer     = NULL;
    }
    ~EMAView ()
    {
        invalidateDeviceObjects();
        clear();
    }
    void clear()
    {     
    }

    bool setup(std::string const& filePath, EMBChunk const&emaChunk, EMBChunk const&animationChunk)
    {
        if(emaChunk.blockType == "#EMA" && animationChunk.blockType == "Animation")
        {

            invalidateDeviceObjects();

            emaData.load(filePath, emaChunk, animationChunk);

            restoreDeviceObjects();

            return true;
            
        }
        return false;
    }
    void render()
    {
        D3DXMATRIX matTrans;
        D3DXMatrixTranslation( &matTrans, 0.0f, 0.0f, m_zoom );

        D3DXMATRIX matRot;
        D3DXMatrixRotationYawPitchRoll( &matRot,
                                        D3DXToRadian(m_fSpinX),
                                        D3DXToRadian(m_fSpinY),
                                        0.0f );

        D3DXMATRIX matProj;
        D3DXMatrixPerspectiveFovLH( &matProj, D3DXToRadian( 45.0f ), 
                                    viewHeight() == 0 ? 1.f :viewWidth() / (float)viewHeight(), 0.1f, 100.0f );
        D3DXMATRIX worldView = matRot * matTrans;
    
        d3dDevice()->SetTransform( D3DTS_WORLD, &worldView );

        
        d3dDevice()->SetTransform( D3DTS_PROJECTION, &matProj );

        if( m_skelettonLinesVertexBuffer )
        {
            d3dDevice()->SetVertexShader(NULL);
            d3dDevice()->SetPixelShader(NULL);

            d3dDevice()->BeginScene();
		    d3dDevice()->SetStreamSource( 0, m_skelettonLinesVertexBuffer, 0, sizeof(EMAVertex) );
		    d3dDevice()->SetFVF( D3DFVF_MY_VERTEX );
		    d3dDevice()->DrawPrimitive( D3DPT_LINELIST, 0, m_primitiveCount);
            d3dDevice()->EndScene();
        }
    }
    void invalidateDeviceObjects()
    {
        if( m_skelettonLinesVertexBuffer != NULL )
        {
            m_skelettonLinesVertexBuffer->Release();
            m_skelettonLinesVertexBuffer = NULL;
        }
        m_primitiveCount = 0;

    }

    void restoreDeviceObjects()
    {
        emaData.setupFrame(0);
        EMAData::SkelettonNodePerNumberMap &skelettonNodes = emaData.m_skelettonNodes;

        m_primitiveCount = skelettonNodes.size();
        EMAVertex* lineListBuffer = new EMAVertex[2*m_primitiveCount];
        unsigned int i = 0;
        for(EMAData::SkelettonNodePerNumberMap::const_iterator it=skelettonNodes.begin();
                it!=skelettonNodes.end();it++, i++)
        {
            EMAData::EMASkelettonNode const& node = it->second;

            D3DXMATRIX matrix(node.animatedMatrix);
            D3DXMATRIX parent;
            D3DXMatrixIdentity(&parent);

            
            unsigned short parentNumber = node.parent;
            EMAData::SkelettonNodePerNumberMap::const_iterator parentIt = skelettonNodes.find(parentNumber);
            while ( skelettonNodes.end() != parentIt && parentNumber != 0xFFFF)
            {
                EMAData::EMASkelettonNode const& nodeParent = parentIt->second;
                if(parentNumber != nodeParent.number || nodeParent.number == nodeParent.parent)
                {
                    break;
                }

                D3DXMATRIX currentParent(nodeParent.animatedMatrix);

                D3DXMATRIX tempMatrix;
                D3DXMatrixMultiply(&tempMatrix, &matrix, &currentParent);
                matrix = tempMatrix;                                     
                                                                         
                D3DXMatrixMultiply(&tempMatrix, &parent, &currentParent);
                parent = tempMatrix;

                parentNumber = nodeParent.parent;
                parentIt = skelettonNodes.find(parentNumber);

            }

            D3DXVECTOR3 zero(0, 0, 0);
            D3DXVECTOR4 selfPos;
            D3DXVECTOR4 parentPos;
            D3DXVec3Transform(&selfPos, &zero, &matrix);
            D3DXVec3Transform(&parentPos, &zero, &parent);

            lineListBuffer[2*i].p[0] = selfPos.x;
            lineListBuffer[2*i].p[1] = selfPos.y;
            lineListBuffer[2*i].p[2] = selfPos.z;
            lineListBuffer[2*i].color = D3DCOLOR_COLORVALUE( 1.0, 0.0, 0.0, 1.0 );
            lineListBuffer[2*i+1].p[0] = parentPos.x;
            lineListBuffer[2*i+1].p[1] = parentPos.y;
            lineListBuffer[2*i+1].p[2] = parentPos.z;
            lineListBuffer[2*i+1].color = D3DCOLOR_COLORVALUE( 1.0, 0.0, 0.0, 1.0 );
            
        };
	    d3dDevice()->CreateVertexBuffer( 2*m_primitiveCount*sizeof(EMAVertex), 0, D3DFVF_MY_VERTEX,
									      D3DPOOL_DEFAULT, &m_skelettonLinesVertexBuffer,
									      NULL );

        if(m_skelettonLinesVertexBuffer)
        {
	        void* pVertices = NULL;
	        m_skelettonLinesVertexBuffer->Lock( 0, 2*m_primitiveCount*sizeof(EMAVertex), (void**)&pVertices, 0 );
            memcpy( pVertices, lineListBuffer, 2*m_primitiveCount*sizeof(EMAVertex) );
            m_skelettonLinesVertexBuffer->Unlock();
        }
        delete[] lineListBuffer;

    }
        
    void onKeyDown( short keyCode )
    {
    }

    void onKeyUp(short keyCode)
    {

    }
    void onMouseDrag(short x, short y, int button)
    {
        ptCurrentMousePosit.x = x;
        ptCurrentMousePosit.y = y;

        {
            if(mxEvent::MouseRightButton==button)
            {
                m_zoom += (ptCurrentMousePosit.y - ptLastMousePosit.y) / (float)1000;
            }
            else
            {
                m_fSpinX -= (ptCurrentMousePosit.x - ptLastMousePosit.x);
                m_fSpinY -= (ptCurrentMousePosit.y - ptLastMousePosit.y);
            }
            
        }

        ptLastMousePosit.x = ptCurrentMousePosit.x;
        ptLastMousePosit.y = ptCurrentMousePosit.y;

    }
    void onMouseMove(short x, short y, int button)
    {
    }
    void onMouseButtonUp(void)
    {

    }
    void onMouseButtonDown(short x, short y)
    {
        ptLastMousePosit.x = ptCurrentMousePosit.x = x;
        ptLastMousePosit.y = ptCurrentMousePosit.y = y;

    }
    
};
#endif //EMAView_H