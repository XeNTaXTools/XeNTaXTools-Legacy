#ifndef MATH_HELPERS_H
#define MATH_HELPERS_H

#include <stdio.h>

#include <d3dx9.h>//matrix operations...

namespace MathHelpers
{
    /*
    float getPitch(D3DXQUATERNION const& q)
    {
        return (float)atan2l(2*(q.y*q.z + q.w*q.x), q.w*q.w - q.x*q.x - q.y*q.y + q.z*q.z);
    }

    float getYaw(D3DXQUATERNION const& q)
    {
        return (float)asinl(-2*(q.x*q.z - q.w*q.y));
    }

    float getRoll(D3DXQUATERNION const& q)
    {
        return (float)atan2l(2*(q.x*q.y + q.w*q.z), q.w*q.w + q.x*q.x - q.y*q.y - q.z*q.z);
    }
    
    float getRX(D3DXQUATERNION const& q)
    {
	    return (float)atan2l(2.0 * ( q.y * q.z + q.x * q.w ) , ( -q.x * q.x - q.y * q.y + q.z * q.z + q.w * q.w ));
    }
    float getRY(D3DXQUATERNION const& q)
    {
	    return (float)asinl(-2.0 * ( q.x * q.z - q.y * q.w ));
    }
    float getRZ(D3DXQUATERNION const& q)
    {
	    return (float)atan2l(2.0 * ( q.x * q.y + q.z * q.w ) , (  q.x * q.x - q.y * q.y - q.z * q.z + q.w * q.w ));
    }

    float getRX_(D3DXQUATERNION const& q)
    {
	    return (float)atan2l(2.0 * ( q.y * q.z + q.x * q.w ) , ( -q.x * q.x - q.y * q.y + q.z * q.z + q.w * q.w ));
    }
    float getRY_(D3DXQUATERNION const& q)
    {
	    return (float)asinl(-2.0 * ( q.x * q.z - q.y * q.w ));
    }
    float getRZ_(D3DXQUATERNION const& q)
    {
	    return (float)atan2l(2.0 * ( q.x * q.y + q.z * q.w ) , (  q.x * q.x - q.y * q.y - q.z * q.z + q.w * q.w ));
    }
    
    float getRX__(D3DXQUATERNION const& q)
    {
        if(q.x*q.y + q.z*q.w == 0.5) 
        { 
            return (float)(2 * atan2l(q.x,q.w)); 
        } 

        else if(q.x*q.y + q.z*q.w == -0.5) 
        { 
            return (float)(-2 * atan2l(q.x, q.w)); 
        } 
        else
        {
            return (float)atan2l 
                ( 
                2 * q.y * q.w - 2 * q.x * q.z,  
                1 - 2 * q.y * q.y - 2 * q.z * q.z 
                ); 
        }
    }
    float getRY__(D3DXQUATERNION const& q)
    {
        return (float)asinl 
            ( 
            2*q.x*q.y + 2*q.z*q.w 
            ); 
    }
    float getRZ__(D3DXQUATERNION const& q)
    {
        return (fabs(q.x*q.y + q.z*q.w) == 0.5) ? 0.f :(float)atan2l 
            ( 
            2*q.x*q.w-2*q.y*q.z, 
            1 - 2 * q.x * q.x - 2 * q.z * q.z 
            ); 
    }

    */
    
    //BEGIN Wild magic RIPOFF:

    #define M_PI 3.141592653589793238462643
    #define HALF_PI (0.5*M_PI)

    //----------------------------------------------------------------------------
    template <class Real>
    void leftHandToEulerAnglesZYX (const Real m[16], Real& rfZAngle, Real& rfYAngle, Real& rfXAngle)
    {
        // +-           -+   +-                                        -+
        // | r00 r01 r02 |   |  cy*cz           -cy*sz            sy    |
        // | r10 r11 r12 | = |  cz*sx*sy+cx*sz   cx*cz-sx*sy*sz  -cy*sx |
        // | r20 r21 r22 |   | -cx*cz*sy+sx*sz   cz*sx+cx*sy*sz   cx*cy |
        // +-           -+   +-                                        -+

        if (m[2] < (Real)1.0)
        {
            if (m[2] > -(Real)1.0)
            {
                // y_angle = asin(r02)
                // x_angle = atan2(-r12,r22)
                // z_angle = atan2(-r01,r00)
                rfYAngle = (Real)asin((double)m[2]);
                rfXAngle = (Real)atan2l(-m[6],m[10]);
                rfZAngle = (Real)atan2l(-m[1],m[0]);
                return;// EA_UNIQUE
            }
            else
            {
                // y_angle = -pi/2
                // z_angle - x_angle = atan2(r10,r11)
                // WARNING.  The solution is not unique.  Choosing z_angle = 0.
                rfYAngle = -(Real)HALF_PI;
                rfXAngle = -(Real)atan2l(m[4],m[5]);
                rfZAngle = (Real)0.0;
                return;// EA_NOT_UNIQUE_DIF
            }
        }
        else
        {
            // y_angle = +pi/2
            // z_angle + x_angle = atan2(r10,r11)
            // WARNING.  The solutions is not unique.  Choosing z_angle = 0.
            rfYAngle = (Real)HALF_PI;
            rfXAngle = (Real)atan2l(m[4],m[5]);
            rfZAngle = (Real)0.0;
            return;// EA_NOT_UNIQUE_SUM
        }
    }
    //----------------------------------------------------------------------------
    template <class Real>
    void leftHandToEulerAnglesYZX (const Real m[16], Real& rfYAngle, Real& rfZAngle, Real& rfXAngle)
    {
        // +-           -+   +-                                        -+
        // | r00 r01 r02 |   |  cy*cz           -sz      cz*sy          |
        // | r10 r11 r12 | = |  sx*sy+cx*cy*sz   cx*cz  -cy*sx+cx*sy*sz |
        // | r20 r21 r22 |   | -cx*sy+cy*sx*sz   cz*sx   cx*cy+sx*sy*sz |
        // +-           -+   +-                                        -+

        if (m[1] < (Real)1.0)
        {
            if (m[1] > -(Real)1.0)
            {
                // z_angle = asin(-r01)
                // x_angle = atan2(r21,r11)
                // y_angle = atan2(r02,r00)
                rfZAngle = (Real)asin(-(double)m[1]);
                rfXAngle = (Real)atan2l(m[9],m[5]);
                rfYAngle = (Real)atan2l(m[2],m[0]);
                return;// EA_UNIQUE
            }
            else
            {
                // z_angle = +pi/2
                // y_angle - x_angle = atan2(-r20,r22)
                // WARNING.  The solution is not unique.  Choosing y_angle = 0.
                rfZAngle = (Real)HALF_PI;
                rfXAngle = -(Real)atan2l(-m[8],m[10]);
                rfYAngle = (Real)0.0;
                return;// EA_NOT_UNIQUE_DIF
            }
        }
        else
        {
            // z_angle = -pi/2
            // y_angle + x_angle = atan2(-r20,r22)
            // WARNING.  The solution is not unique.  Choosing y_angle = 0.
            rfZAngle = -(Real)HALF_PI;
            rfXAngle = (Real)atan2l(-m[8],m[10]);
            rfYAngle = (Real)0.0;
            return;// EA_NOT_UNIQUE_SUM
        }
    }
    //----------------------------------------------------------------------------
    template <class Real>
    void leftHandToEulerAnglesZXY (const Real m[16], Real& rfZAngle, Real& rfXAngle, Real& rfYAngle)
    {
        // +-           -+   +-                                       -+
        // | r00 r01 r02 |   |  cy*cz+sx*sy*sz  cz*sx*sy-cy*sz   cx*sy |
        // | r10 r11 r12 | = |  cx*sz           cx*cz           -sx    |
        // | r20 r21 r22 |   | -cz*sy+cy*sx*sz  cy*cz*sx+sy*sz   cx*cy |
        // +-           -+   +-                                       -+

        if (m[6] < (Real)1.0)
        {
            if (m[6] > -(Real)1.0)
            {
                // x_angle = asin(-r12)
                // y_angle = atan2(r02,r22)
                // z_angle = atan2(r10,r11)
                rfXAngle = (Real)asin(-(double)m[6]);
                rfYAngle = (Real)atan2l(m[2],m[10]);
                rfZAngle = (Real)atan2l(m[4],m[5]);
                return;// EA_UNIQUE
            }
            else
            {
                // x_angle = +pi/2
                // z_angle - y_angle = atan2(-r01,r00)
                // WARNING.  The solution is not unique.  Choosing z_angle = 0.
                rfXAngle = (Real)HALF_PI;
                rfYAngle = -(Real)atan2l(-m[1],m[0]);
                rfZAngle = (Real)0.0;
                return;// EA_NOT_UNIQUE_DIF
            }
        }
        else
        {
            // x_angle = -pi/2
            // z_angle + y_angle = atan2(-r01,r00)
            // WARNING.  The solution is not unique.  Choosing z_angle = 0.
            rfXAngle = -(Real)HALF_PI;
            rfYAngle = (Real)atan2l(-m[1],m[0]);
            rfZAngle = (Real)0.0;
            return;// EA_NOT_UNIQUE_SUM
        }
    }
    //----------------------------------------------------------------------------
    template <class Real>
    void leftHandToEulerAnglesXZY (const Real m[16], Real& rfXAngle, Real& rfZAngle, Real& rfYAngle)
    {
        // +-           -+   +-                                       -+
        // | r00 r01 r02 |   |  cy*cz  sx*sy-cx*cy*sz   cx*sy+cy*sx*sz |
        // | r10 r11 r12 | = |  sz     cx*cz           -cz*sx          |
        // | r20 r21 r22 |   | -cz*sy  cy*sx+cx*sy*sz   cx*cy-sx*sy*sz |
        // +-           -+   +-                                       -+

        if (m[4] < (Real)1.0)
        {
            if (m[4] > -(Real)1.0)
            {
                // z_angle = asin(r10)
                // y_angle = atan2(-r20,r00)
                // x_angle = atan2(-r12,r11)
                rfZAngle = (Real)asin((double)m[4]);
                rfYAngle = (Real)atan2l(-m[8],m[0]);
                rfXAngle = (Real)atan2l(-m[6],m[5]);
                return;// EA_UNIQUE
            }
            else
            {
                // z_angle = -pi/2
                // x_angle - y_angle = atan2(r21,r22)
                // WARNING.  The solution is not unique.  Choosing x_angle = 0.
                rfZAngle = -(Real)HALF_PI;
                rfYAngle = -(Real)atan2l(m[9],m[10]);
                rfXAngle = (Real)0.0;
                return;// EA_NOT_UNIQUE_DIF
            }
        }
        else
        {
            // z_angle = +pi/2
            // x_angle + y_angle = atan2(r21,r22)
            // WARNING.  The solution is not unique.  Choosing x_angle = 0.
            rfZAngle = (Real)HALF_PI;
            rfYAngle = (Real)atan2l(m[9],m[10]);
            rfXAngle = (Real)0.0;
            return;// EA_NOT_UNIQUE_SUM
        }
    }
    //----------------------------------------------------------------------------

    template <class Real>
    void leftHandToEulerAnglesYXZ (const Real m[16], Real& rfYAngle, Real& rfXAngle, Real& rfZAngle)
    {
        // +-           -+   +-                                        -+
        // | r00 r01 r02 |   |  cy*cz-sx*sy*sz  -cx*sz   cz*sy+cy*sx*sz |
        // | r10 r11 r12 | = |  cz*sx*sy+cy*sz   cx*cz  -cy*cz*sx+sy*sz |
        // | r20 r21 r22 |   | -cx*sy            sx      cx*cy          |
        // +-           -+   +-                                        -+

        if (m[9] < (Real)1.0)
        {
            if (m[9] > -(Real)1.0)
            {
                // x_angle = asin(r21)
                // z_angle = atan2(-r01,r11)
                // y_angle = atan2(-r20,r22)
                rfXAngle = (Real)asin((double)m[9]);
                rfZAngle = (Real)atan2l(-m[1],m[5]);
                rfYAngle = (Real)atan2l(-m[8],m[10]);
                return;// EA_UNIQUE
            }
            else
            {
                // x_angle = -pi/2
                // y_angle - z_angle = atan2(r02,r00)
                // WARNING.  The solution is not unique.  Choosing y_angle = 0.
                rfXAngle = -(Real)HALF_PI;
                rfZAngle = -(Real)atan2l(m[2],m[0]);
                rfYAngle = (Real)0.0;
                return;// EA_NOT_UNIQUE_DIF
            }
        }
        else
        {
            // x_angle = +pi/2
            // y_angle + z_angle = atan2(r02,r00)
            // WARNING.  The solution is not unique.  Choosing y_angle = 0.
            rfXAngle = (Real)HALF_PI;
            rfZAngle = (Real)atan2l(m[2],m[0]);
            rfYAngle = (Real)0.0;
            return;// EA_NOT_UNIQUE_SUM
        }
    }
    //----------------------------------------------------------------------------
    template< class Real>
    void leftHandToEulerAnglesXYZ (const Real m[16], Real& rfXAngle, Real& rfYAngle, Real& rfZAngle)
    {
        // +-           -+   +-                                      -+
        // | r00 r01 r02 |   |  cy*cz  cz*sx*sy-cx*sz  cx*cz*sy+sx*sz |
        // | r10 r11 r12 | = |  cy*sz  cx*cz+sx*sy*sz -cz*sx+cx*sy*sz |
        // | r20 r21 r22 |   | -sy     cy*sx           cx*cy          |
        // +-           -+   +-                                      -+

        if (m[8] < (Real)1.0)
        {
            if (m[8] > -(Real)1.0)
            {
                // y_angle = asin(-r20)
                // z_angle = atan2(r10,r00)
                // x_angle = atan2(r21,r22)
                rfYAngle = (Real)asin(-(double)m[8]);
                rfZAngle = atan2(m[4],m[0]);
                rfXAngle = atan2(m[9],m[10]);
                return ;//EA_UNIQUE
            }
            else
            {
                // y_angle = +pi/2
                // x_angle - z_angle = atan2(r01,r02)
                // WARNING.  The solution is not unique.  Choosing x_angle = 0.
                rfYAngle = (Real)HALF_PI;
                rfZAngle = -atan2(m[1],m[2]);
                rfXAngle = (Real)0.0;
                return ;//EA_NOT_UNIQUE_DIF
            }
        }
        else
        {
            // y_angle = -pi/2
            // x_angle + z_angle = atan2(-r01,-r02)
            // WARNING.  The solution is not unique.  Choosing x_angle = 0;
            rfYAngle = -(Real)HALF_PI;
            rfZAngle = atan2(-m[1],-m[2]);
            rfXAngle = (Real)0.0;
            return ;//EA_NOT_UNIQUE_SUM
        }
    }

    void decomposeMatrix (float rotation[3], float scale[3], float translation[3], const float matrix[16])
    {
        if(matrix == NULL)
        {
            return;
        }
        D3DXMATRIX originalMatrix(matrix);
        D3DXQUATERNION q;
        D3DXVECTOR3 originalScale;
        D3DXVECTOR3 originalTrans;
        D3DXMatrixDecompose(&originalScale, &q, &originalTrans, &originalMatrix);

        memcpy(translation, (float*)originalTrans, 3*sizeof(float));
        memcpy(scale, (float*)originalScale, 3*sizeof(float));
        
        D3DXMATRIX m;
        D3DXMatrixTranspose(&m, &originalMatrix);
        leftHandToEulerAnglesXYZ<float>(m, rotation[0], rotation[1], rotation[2]);
        //leftHandToEulerAnglesXZY<float>(m, rotation[0], rotation[2], rotation[1]);
        //leftHandToEulerAnglesYXZ<float>(m, rotation[1], rotation[0], rotation[2]);
        //leftHandToEulerAnglesYZX<float>(m, rotation[1], rotation[2], rotation[0]);
        //leftHandToEulerAnglesZYX<float>(m, rotation[2], rotation[1], rotation[0]);
        //leftHandToEulerAnglesZXY<float>(m, rotation[2], rotation[0], rotation[1]);
        
        rotation[0] *= (float)(180. / M_PI);
        rotation[1] *= (float)(180. / M_PI);
        rotation[2] *= (float)(180. / M_PI);
    }
    void composeMatrix (float rotation[3], float scale[3], float translation[3], float matrix[16])
    {
        if(matrix == NULL)
        {
            return;
        }
        
        D3DXMATRIX translationMatrix, scalingMatrix, rotationMatrix;
        D3DXMatrixTranslation(&translationMatrix, translation[0], translation[1], translation[2]);
        D3DXMatrixScaling(&scalingMatrix, scale[0], scale[1], scale[2]);


        //quaternion
        //float qw = 1.0f - (rotation[0] * rotation[0]) - (rotation[1] * rotation[1]) - (rotation[2] * rotation[2]);
        //D3DXQUATERNION quat(rotation[0], rotation[1], rotation[2], (qw < 0.0f)?0.0f:-sqrt (qw));
        //D3DXMatrixRotationQuaternion(&rotationMatrix, &quat);

        rotation[0] *= (float)(M_PI / 180.);
        rotation[1] *= (float)(M_PI / 180.);
        rotation[2] *= (float)(M_PI / 180.);

        //Euler
        D3DXMATRIX rotationOxMatrix, rotationOyMatrix, rotationOzMatrix;
        D3DXMatrixRotationX(&rotationOxMatrix, rotation[0]);
        D3DXMatrixRotationY(&rotationOyMatrix, rotation[1]);
        D3DXMatrixRotationZ(&rotationOzMatrix, rotation[2]);
        
        rotationMatrix = rotationOxMatrix * rotationOyMatrix * rotationOzMatrix;
        //rotationMatrix = rotationOxMatrix * rotationOzMatrix * rotationOyMatrix;
        //rotationMatrix = rotationOyMatrix * rotationOxMatrix * rotationOzMatrix;
        //rotationMatrix = rotationOyMatrix * rotationOzMatrix * rotationOxMatrix;
        //rotationMatrix = rotationOzMatrix * rotationOyMatrix * rotationOxMatrix;
        //rotationMatrix = rotationOzMatrix * rotationOxMatrix * rotationOyMatrix;


        //store result
        D3DXMATRIX fullMatrix =  translationMatrix * scalingMatrix * rotationMatrix;
        memcpy(matrix, (float*)fullMatrix, 16*sizeof(float));
    }
}
#endif //MATH_HELPERS_H