from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Star Wars: Episode 3 - Revenge of the Sith [Xbox]", ".stx")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
	#noesis.logPopup()
	return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    if noeStrFromBytes(bs.readBytes(3)) != 'STX': return 0
    return 1
	
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.seek(0x08)
    imgFmt = bs.readUInt()
    imgWidth = bs.readUInt()            
    imgHeight = bs.readUInt()           
    bs.seek(0x184)        
    data = bs.readBytes(bs.getSize() - bs.tell())      
    #DXT1
    if imgFmt == 3:
        texFmt = noesis.NOESISTEX_DXT1
    #DXT5
    elif imgFmt == 4:
        texFmt = noesis.NOESISTEX_DXT5
    #morton order swizzled raw with alpha??
    elif imgFmt == 0:
        untwid = bytearray()
        for x in range(0, imgWidth):
            for y in range(0, imgHeight):
                idx = noesis.morton2D(x, y)
                untwid += data[idx * 4 : idx * 4 + 4]
        data = rapi.imageDecodeRaw(untwid, imgWidth, imgHeight, "r8 g8 b8 a8")
        texFmt = noesis.NOESISTEX_RGBA32
    #unknown, not handled
    else:
        print("WARNING: Unhandled image format " + repr(imgFmt) + " - " + repr(imgWidth) + "x" + repr(imgHeight) + " - " + repr(len(data)))
        return None
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1