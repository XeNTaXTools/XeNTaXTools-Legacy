#Noesis Python model import+export test module, imports/exports some data from/to a made-up format
from inc_noesis import *

import noesis

#rapi methods should only be used during handler callbacks
import rapi

#registerNoesisTypes is called by Noesis to allow the script to register formats.
#Do not implement this function in script files unless you want them to be dedicated format modules!
def registerNoesisTypes():
   handle = noesis.register(".mga", ".mga")
   noesis.setHandlerTypeCheck(handle, noepyCheckType)
   noesis.setHandlerLoadModel(handle, noepyLoadModel) #see also noepyLoadModelRPG
       #noesis.setHandlerWriteModel(handle, noepyWriteModel)
       #noesis.setHandlerWriteAnim(handle, noepyWriteAnim)
   noesis.logPopup()
       #print("The log can be useful for catching debug prints from preview loads.\nBut don't leave it on when you release your script, or it will probably annoy people.")
   return 1

def noepyCheckType(data):
    '''Verify that the format is supported by this plugin. Default yes'''
    
    return 1   

#load the model
def noepyLoadModel(data, mdlList):
   ctx = rapi.rpgCreateContext()
   bs = NoeBitStream(data)
   faces = []
   vertices = []
   uv = []
   normals = []
   bs.seek(0x17, NOESEEK_ABS) #Seek to header info
   hdrInfo = bs.read("iiiiii")
   print(hdrInfo)
   # Grab Data end
   DataEnd = hdrInfo[0] + 27
   print('End of Data: ', DataEnd)
   # Grab Vertices count
   VCount = hdrInfo[1]
   print('Vertex count: ', VCount)
   # Grab Faces count
   FCount = hdrInfo[2]
   print('Faces count: ', FCount)
   bs.seek(0x79, NOESEEK_ABS) #Seek to File Start

   Facesstart = DataEnd - ( FCount * 6 )
   print('Faces Sart: ', Facesstart)

   # blocked model 
   # verts 3x4 = 12 bytes
   # normals 3x4 = 12 bytes
   # uv 4x2 = 8 bytes
   # uv padding = vert padding + 4 
   # end of rest of data = EndofFaces - faces number x 6

   bs.seek(Facesstart, NOESEEK_ABS) #Seek to Faces Start
   for i in range(0, FCount):
      faces.append (bs.readBytes(6).decode('ascii').rstrip('\0'))
      faces.append (bs.readBytes(6))
   #print(faces)



   rapi.rpgClearBufferBinds()   
   return 1