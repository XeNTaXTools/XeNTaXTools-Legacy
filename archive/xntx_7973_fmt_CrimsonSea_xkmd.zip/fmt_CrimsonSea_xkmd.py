#  Crimson Sea XKMD importer by Bigchillghost
from inc_noesis import *
import copy

def registerNoesisTypes():
	handle = noesis.register("Crimson Sea XKMD", ".XKMD")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadModel(handle, noepyLoadModel)
	#noesis.logPopup()
	return 1

#check if it's this type based on the data
def noepyCheckType(data):
	if len(data) < 0x80:
		return 0
	bs = NoeBitStream(data)
	if bs.readBytes(4) != b'XKMD':
		return 0
	return 1

def debugPrint(str):
	#print(str)
	pass

#load the model
def noepyLoadModel(data, mdlList):
	#noesis.logPopup()
	bs = NoeBitStream(data)
	bs.seek(8, NOESEEK_ABS)
	fileSize = bs.readUInt()
	headerSize = bs.readUInt()
	bs.seek(8, NOESEEK_REL)
	bs.seek(0x18, NOESEEK_REL) # BBox
	matrixCount = bs.readUInt()
	matrixAddress = bs.readUInt()
	boneCount = bs.readUInt()
	boneAddress = bs.readUInt() # stride == 40
	for i in range(0, 2):
		bs.seek(4, NOESEEK_REL)
		meshInfoTableAddress = bs.readUInt() # stride == 44
	meshCount = bs.readUInt()
	subMesh1Count = bs.readUInt()
	subMesh2Count = bs.readUInt()
	subMeshCount = subMesh1Count + subMesh2Count
	
	vertAttrFlag = [0]*meshCount
	vertStride = [0]*meshCount
	vertCount = [0]*meshCount
	vertAddress = [0]*meshCount
	indexCount = [0]*meshCount
	indexAddress = [0]*meshCount
	for i in range(0, meshCount):
		vertAttrFlag[i] = bs.readUInt()
		vertStride[i] = bs.readUInt()
		vertCount[i] = bs.readUInt()
		vertAddress[i] = bs.readUInt()
		bs.seek(0x10, NOESEEK_REL)
		indexCount[i] = bs.readUInt()
		indexAddress[i] = bs.readUInt()
		bs.seek(0xC, NOESEEK_REL)
	recAddress = [0]*subMeshCount
	for i in range(0, subMeshCount):
		recAddress[i] = bs.readUInt()
	
	# transform matrix
	matList = []
	debugPrint('matrixAddress %x'%matrixAddress)
	bs.seek(matrixAddress, NOESEEK_ABS)
	for i in range(0, matrixCount):
		boneMat = NoeMat44.fromBytes(bs.readBytes(0x40)).toMat43().inverse()
		#debugPrint(boneMat)
		matList.append(boneMat)
	primaryLinkTable = [0]*matrixCount
	for i in range(0, matrixCount):
		boneIndex = bs.readUShort()
		parentIndex = bs.readUShort()
		if parentIndex == 0xFFFF:
			primaryLinkTable[i] = boneIndex
		else:
			primaryLinkTable[i] = parentIndex
	
	# bone info
	bones = []
	debugPrint('boneAddress %x'%boneAddress)
	bs.seek(boneAddress, NOESEEK_ABS)
	for i in range(0, boneCount):
		boneName = "bone%d"%i
		boneIndex = bs.readUShort()
		parentIndex = bs.readUShort()
		if parentIndex == 0xFFFF: parentIndex = -1
		bs.seek(0xC, NOESEEK_REL) # scale
		rot = NoeAngles.fromBytes(bs.readBytes(12))
		tran = NoeVec3.fromBytes(bs.readBytes(12))
		boneMat = rot.toDegrees().toMat43_XYZ()
		boneMat[3] = tran
		bones.append( NoeBone(boneIndex, boneName, boneMat, None, parentIndex) )
	# Converting local matrix to world space
	for i in range(0, boneCount):
		j = bones[i].parentIndex
		if j != -1:
			bones[i].setMatrix( bones[i].getMatrix() * bones[j].getMatrix() )
	#for i in range(boneCount, matrixCount):
	#	boneName = "bone%d"%i
	#	parentIndex = primaryLinkTable[i]
	#	if parentIndex == 0xFFFF: parentIndex = -1
	#	bones.append( NoeBone(i, boneName, matList[i], None, parentIndex) )
	rawIdxChunks = []
	for i in range(0, meshCount):
		debugPrint('indexAddress[%d] %x, indexCount %x'%(i, indexAddress[i], indexCount[i]))
		bs.seek(indexAddress[i], NOESEEK_ABS)
		idxChunk = bs.readBytes(indexCount[i]*2)
		rawIdxChunks.append(idxChunk)
	rawVertChunks = []
	for i in range(0, meshCount):
		debugPrint('vertAddress[%d] %x'%(i, vertAddress[i]))
		bs.seek(vertAddress[i], NOESEEK_ABS)
		vertChunk = bs.readBytes(vertStride[i]*vertCount[i])
		rawVertChunks.append(vertChunk)
	
	submeshRec = []
	for i in range(0, subMeshCount):
		debugPrint('recAddress[%d] %x'%(i, recAddress[i]))
		bs.seek(recAddress[i], NOESEEK_ABS)
		boneID = bs.readUShort()
		blendWgtCnt = bs.readUByte()
		matrixStride = bs.readUByte()
		bs.seek(4, NOESEEK_REL)
		matIds = [0]*4
		for j in range(0, 4):
			matIds[j] = bs.readUShort()
		meshGroupID = bs.readUInt()
		bs.seek(8, NOESEEK_REL)
		begVertOffset = bs.readUInt()
		subMeshIndexCount = bs.readUInt()
		begIndexOffset = bs.readUInt()
		faceCount = bs.readUInt()
		submeshRec.append([meshGroupID, begVertOffset, \
		begIndexOffset, subMeshIndexCount, boneID, blendWgtCnt, matIds])
	submeshRec.sort(key=lambda x:(x[0],x[1]))
	debugPrint('sorted:')
	for i in range(0, subMeshCount):
		debugPrint(submeshRec[i])
	
	idx = 0
	idxChunks = []
	vertChunks = []
	# meshes
	ctx = rapi.rpgCreateContext()
	for i in range(0, meshCount):
		vbs = NoeBitStream(rawVertChunks[i])
		ibs = NoeBitStream(rawIdxChunks[i])
		posData = bytearray()
		nmData = bytearray()
		uvData = bytearray()
		stride = vertStride[i]
		skipBytes = stride - 0x20
		idxData = bytearray()
		indexCnt = 0
		vSum = 0
		blendWgtData = bytearray()
		blendIdxData = bytearray()
		while idx < subMeshCount:
			if submeshRec[idx][0] != i:
				break
			begVertOffset = submeshRec[idx][1]
			if idx + 1 < subMeshCount and submeshRec[idx+1][0] == i:
				usedVertCnt = submeshRec[idx+1][1]-begVertOffset
			else:
				usedVertCnt = vertCount[i]-begVertOffset
			vSum += usedVertCnt
			debugPrint('usedVertCnt %d, vSum %d'%(usedVertCnt,vSum))
			bid = submeshRec[idx][4]
			blendWgtCnt = submeshRec[idx][5]
			# vert attrs flag
			# 1 01010010 pos[3], norm[3], marker, uv[2]
			# 1 01010110 pos[3], weight, norm[3], marker, uv[2]
			# 1 01011010 pos[3], weight[3], norm[3], marker, uv[2]
			debugPrint('blendWgtCnt %d'%blendWgtCnt)
			if bid > 0:
				lMat = bones[bid].getMatrix()
				rotMat = copy.copy(lMat)
				rotMat[3] = NoeVec3()
				for j in range(0, usedVertCnt):
					position = NoeVec3.fromBytes(vbs.readBytes(12))
					if blendWgtCnt > 0: # should be implicit weight, just in case
						vbs.seek((blendWgtCnt-1)*4, NOESEEK_REL)
					normal = NoeVec3.fromBytes(vbs.readBytes(12))
					vbs.seek(4, NOESEEK_REL)
					uvData += NoeVec3([vbs.readFloat(), vbs.readFloat(), 0.0]).toBytes()
					position = lMat * position
					normal = rotMat * normal
					posData += position.toBytes()
					nmData += normal.toBytes()
				blendIdxData += struct.pack('<H', bid) * usedVertCnt
				blendWgtData += b'\x00\x00\x80\x3F' * usedVertCnt
				blendWgtCnt = 1
			else:
				for j in range(0, usedVertCnt):
					posData += vbs.readBytes(12)
					wgts = []
					implicitW = 1.0
					cnt = blendWgtCnt-1
					for k in range(0, cnt):
						weight = vbs.readFloat()
						implicitW -= weight
						wgts.append(weight)
					wgts.append(implicitW)
					nmData += vbs.readBytes(12)
					vbs.seek(4, NOESEEK_REL)
					uvData += NoeVec3([vbs.readFloat(), vbs.readFloat(), 0.0]).toBytes()
					blendWgtData += struct.pack("<" + 'f'*blendWgtCnt, *wgts)
				matIds = submeshRec[idx][6]
				bIds = [0]*blendWgtCnt
				for j in range(0, blendWgtCnt):
					bIds[j] = primaryLinkTable[matIds[j]]
				blendIdxData += struct.pack("<" + 'H'*blendWgtCnt, *bIds ) * usedVertCnt
			begIndexOffset = submeshRec[idx][2]*2
			subMeshIndexCount = submeshRec[idx][3]
			debugPrint('[%d][%d] begIndexOffset %x, subMeshIndexCount %x'%(i, idx, begIndexOffset,subMeshIndexCount))
			ibs.seek(begIndexOffset, NOESEEK_ABS)
			idxData += ibs.readBytes(subMeshIndexCount*2)
			idxData += b'\xFF\xFF'
			indexCnt += subMeshIndexCount + 1
			idx += 1
		debugPrint('new indexCount[%d] %x'%(i, indexCnt))
		rapi.rpgSetName("mesh%d"%i)
		rapi.rpgBindPositionBuffer(posData, noesis.RPGEODATA_FLOAT, 0xC)
		rapi.rpgBindNormalBuffer(nmData, noesis.RPGEODATA_FLOAT, 0xC)
		rapi.rpgBindUV1Buffer(uvData, noesis.RPGEODATA_FLOAT, 0xC)
		rapi.rpgBindBoneIndexBuffer(blendIdxData, noesis.RPGEODATA_USHORT, 2, blendWgtCnt)
		rapi.rpgBindBoneWeightBuffer(blendWgtData, noesis.RPGEODATA_FLOAT, 4, blendWgtCnt)
		rapi.rpgCommitTriangles(idxData, noesis.RPGEODATA_USHORT, indexCnt, noesis.RPGEO_TRIANGLE_STRIP, 1)
		rapi.rpgClearBufferBinds()
	
	mdl = rapi.rpgConstructModelSlim()
	mdl.setBones(bones)
	mdlList.append(mdl)
	#rapi.setPreviewOption("setAngOfs", "0 -90 0")
	
	return 1
