from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Tony Hawks Project 8 (1.0) [X360]", ".thp8")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
	#noesis.logPopup()
	return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    Magic = bs.readBytes(2)
    if Magic != b'\x0A\x28':
        return 0
    return 1
	
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data, NOE_BIGENDIAN)
    bs.seek(0x20, NOESEEK_ABS)
    datasize = bs.readInt()
    bs.seek(0x4B, NOESEEK_ABS)
    imgFmt = bs.readByte()
    size = bs.readInt()
    print(size, ":size")
    imgHeight = ((size >> 13) & 0x1FFF) + 1
    imgWidth  = (size + 1) & 0x1FFF
    print((imgHeight), ":imgHeight")
    print((imgWidth), ":imgWidth")
    bs.seek(0x5C, NOESEEK_ABS)        
    data = bs.readBytes(datasize)      
    if imgFmt == 0x52:
        data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 8)
        texFmt = noesis.NOESISTEX_DXT1
    elif imgFmt == 0x53:
        data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 16)
        texFmt = noesis.NOESISTEX_DXT3
    elif imgFmt == 0x54:
        data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 16)
        texFmt = noesis.NOESISTEX_DXT5
    elif imgFmt == 0x71:
        data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 16)
        data = rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_ATI2)
        texFmt = noesis.NOESISTEX_RGBA32
    elif imgFmt == 0x7C:
        data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 83)
        data = rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_DXT1NORMAL)
        texFmt = noesis.NOESISTEX_RGBA32
    elif imgFmt == 0x86:
        data = rapi.imageUntile360Raw(data, imgWidth, imgHeight, 4)
        data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "a8r8g8b8")
        texFmt = noesis.NOESISTEX_RGBA32
    elif imgFmt == 0x44:
        data = rapi.imageUntile360Raw(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 2)
        data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "b5g6r5")
        texFmt = noesis.NOESISTEX_RGBA32
    else:
        print("WARNING: Unhandled image format")
        return None
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1

