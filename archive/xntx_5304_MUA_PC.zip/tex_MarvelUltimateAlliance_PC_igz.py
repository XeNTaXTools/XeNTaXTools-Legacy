from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Marvel Ultimate Alliance texture (PC)", ".igz")
	noesis.setHandlerTypeCheck(handle, MUACheckType)
	noesis.setHandlerLoadRGBA(handle, MUALoadRGBA)
	#noesis.logPopup()
	return 1

def MUACheckType(data):
	bs = NoeBitStream(data)
	Magic = bs.readBytes(4)
	print(Magic, "magic")
	if Magic != b'\x01ZGI': 
		return 0
	bs.seek(0x570, NOESEEK_ABS) 
	imageCheck = bs.readBytes(32)
	if b'\x49\x6d\x61\x67\x65' not in imageCheck:
		return 0
	return 1   

def MUALoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.seek(0x30, NOESEEK_ABS)
    imgHeadOffs = bs.readInt()    
    bs.seek(imgHeadOffs - 0x1F8, NOESEEK_ABS)
    imgFmt = bs.readBytes(8)
    print(imgFmt, "imgFmt")
    bs.seek(0x158, NOESEEK_REL)
    imgWidth = bs.readShort()
    print(imgWidth, "imgWidth")
    imgHeight = bs.readShort()
    print(imgHeight, "imgHeight")
    junkSkip = imgHeadOffs + 4
    datasize = len(data) - junkSkip
    bs.seek(junkSkip, NOESEEK_ABS)
    data = bs.readBytes(datasize)
    #DXT1
    if imgFmt == b'\xb2E<\x88K\x84\xcc\xe2':
        texFmt = noesis.NOESISTEX_DXT1
    #DXT5
    elif imgFmt == b'\x1eG\x18\xb7\xb9\xea\xd8\xa9':
        texFmt = noesis.NOESISTEX_DXT5
	#ATI2 normal maps
    elif imgFmt == b'\x05\xd8\xec\x05\xb31n\xeb':
        data = rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_ATI2)
        texFmt = noesis.NOESISTEX_RGBA32
	#unknown, not handled
    else:
        print("WARNING: Unhandled image format")
        return None
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1