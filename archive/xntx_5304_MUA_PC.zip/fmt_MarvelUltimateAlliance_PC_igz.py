from inc_noesis import *
import noesis
import rapi

def registerNoesisTypes():
   handle = noesis.register("Marvel Ultimate Alliance model (PC)", ".igz")
   noesis.setHandlerTypeCheck(handle, MUACheckType)
   noesis.setHandlerLoadModel(handle, MUALoadModel)
   #noesis.logPopup()
   return 1

def MUACheckType(data):
	bs = NoeBitStream(data)
	Magic = bs.readBytes(4)
	print(Magic, "magic")
	if Magic != b'\x01ZGI': 
		return 0
	bs.seek(0x570, NOESEEK_ABS) 
	vertexCheck = bs.readBytes(32)
	if b'\x56\x65\x72\x74\x65\x78' not in vertexCheck:
		return 0
	return 1   

def MUALoadModel(data, mdlList):
	ctx = rapi.rpgCreateContext()
	rapi.setPreviewOption("setAngOfs","0 180 0")      #set the default preview angle        
	bs = NoeBitStream(data)
	bs.seek(0x40, NOESEEK_ABS)
	addOffset = bs.readInt()
	print(addOffset, "add to offset")
	if addOffset + 20 > len(data):
		bs.seek(0x30, NOESEEK_ABS) #0x30
		addOffset = bs.readInt()
		print("using 0x30")
	bs.seek(0x82c, NOESEEK_ABS)
	skip = bs.readInt()
	bs.seek(skip - 4, NOESEEK_REL)
	skip = bs.readInt()
	bs.seek(skip - 4, NOESEEK_REL)
	skip = bs.readInt()
	bs.seek(skip - 4, NOESEEK_REL)
	skip = bs.readInt()
	bs.seek(skip - 4, NOESEEK_REL)
	tablelength = bs.readInt()
	print(tablelength, "table length")
	bs.seek(0x04, NOESEEK_REL)
	print(bs.tell(), "start table")
	numSubmesh = tablelength - 0x18
	numSubmesh = numSubmesh // 0x20 
	print(numSubmesh, "num submeshes")
	for i in range(numSubmesh):
		rapi.rpgSetName(str(i))
		VertBuf = bs.readBytes(3)
		VertBuf = int.from_bytes(VertBuf, 'little')
		print(VertBuf, "vertex block")
		bs.seek(0x05, NOESEEK_REL)
		gotoVBlock = bs.readBytes(3)
		gotoVBlock = int.from_bytes(gotoVBlock, 'little')
		VBlockLoc = gotoVBlock + addOffset
		bs.seek(0x05, NOESEEK_REL)
		IndBuf = bs.readInt()
		print(IndBuf, "indices buffer")
		FCount = IndBuf // 2
		print(FCount, "face count")
		bs.seek(0x04, NOESEEK_REL)
		FIndBuf = bs.readBytes(3)
		FIndBuf = int.from_bytes(FIndBuf, 'little')
		skip = bs.readBytes(5)
		savedPos = bs.tell()
		print(savedPos, "saved position")
		bs.seek(VBlockLoc, NOESEEK_ABS)
		VBuf = bs.readBytes(VertBuf)
		list = []
		for i in range(FCount):
			blah = bs.readUShort()    
			list.append(blah)
		vCount = max(list) + 1
		vStride = VertBuf // vCount
		print(vStride, "vertex stride")
		bs.seek(VBlockLoc, NOESEEK_ABS)
		VBuf = bs.readBytes(VertBuf)
		print(bs.tell(), "end of vertex block")
		if vStride == 44:
			rapi.rpgBindPositionBufferOfs(VBuf, noesis.RPGEODATA_FLOAT, vStride, 0)   #position of vertices
			#rapi.rpgBindNormalBufferOfs(VBuf, noesis.RPGEODATA_FLOAT, vStride, 12)   #normals -optional
			#rapi.rpgBindUV1BufferOfs(VBuf, noesis.RPGEODATA_FLOAT, vStride, 24)      #UVs
		if vStride == 76:
			rapi.rpgBindPositionBufferOfs(VBuf, noesis.RPGEODATA_FLOAT, vStride, 0)   #position of vertices
			#rapi.rpgBindNormalBufferOfs(VBuf, noesis.RPGEODATA_FLOAT, vStride, 12)   #normals -optional
			rapi.rpgBindUV1BufferOfs(VBuf, noesis.RPGEODATA_FLOAT, vStride, 24)       #UVs
		if vStride == 80:
			rapi.rpgBindPositionBufferOfs(VBuf, noesis.RPGEODATA_FLOAT, vStride, 0)   #position of vertices
			#rapi.rpgBindNormalBufferOfs(VBuf, noesis.RPGEODATA_FLOAT, vStride, 12)   #normals -optional
			rapi.rpgBindUV1BufferOfs(VBuf, noesis.RPGEODATA_FLOAT, vStride, 28)       #UVs
		IBuf = bs.readBytes(IndBuf)
		checkTri = int(FCount % 3)
		print(checkTri, "is this evenly divisible by 3")
		if checkTri == 1:
			FCount = FCount - 1
		rapi.rpgCommitTriangles(IBuf, noesis.RPGEODATA_SHORT, FCount, noesis.RPGEO_TRIANGLE, 1)  
		bs.seek(savedPos, NOESEEK_ABS)
	mdl = rapi.rpgConstructModel()                                                          
	mdlList.append(mdl)
	rapi.rpgClearBufferBinds()
	return 1