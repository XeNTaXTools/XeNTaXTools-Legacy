﻿using System;
using System.IO;

namespace FCL_Grin
{
    class Program
    {
        public static void CopyStreamUnpack(Stream input, Stream output)
        {
            byte[] buffer = new byte[65536];
            int len;
            while ((len = input.Read(buffer, 0, 65536)) > 0)
            {
                output.Write(buffer, 0, len);
            }
            output.Flush();
        }

        public static void CopyStream(Stream input, Stream output)
        {
            byte[] buffer = new byte[2000];
            int len;
            while ((len = input.Read(buffer, 0, 2000)) > 0)
            {
                output.Write(buffer, 0, len);
            }
            output.Flush();
        }

        private static void CompressFile(string inFile, string outFile)
        {
            FileStream outFileStream = new FileStream(outFile, FileMode.Create);
            zlib.ZOutputStream outZStream = new zlib.ZOutputStream(outFileStream, zlib.zlibConst.Z_DEFAULT_COMPRESSION);
            FileStream inFileStream = new FileStream(inFile, FileMode.Open);		
            try
            {
                CopyStream(inFileStream, outZStream);
            }
            finally
            {
                outZStream.Close();
                outFileStream.Close();
                inFileStream.Close();
            }
        }

        private static void DecompressFile(string inFile, string outFile)
        {
            System.IO.FileStream outFileStream = new System.IO.FileStream(outFile, System.IO.FileMode.Create);
            zlib.ZOutputStream outZStream = new zlib.ZOutputStream(outFileStream);
            System.IO.FileStream inFileStream = new System.IO.FileStream(inFile, System.IO.FileMode.Open);
            try
            {
                CopyStreamUnpack(inFileStream, outZStream);
            }
            finally
            {
                outZStream.Close();
                outFileStream.Close();
                inFileStream.Close();
            }
        }

        private static int Darabol(string inFile)
        {
            FileInfo file = new FileInfo(inFile);
            Console.WriteLine("Filesize: " + file.Length);

            FileStream ins = File.OpenRead(inFile);

            int i = (int)file.Length;
            int db = 0;
            byte[] b = new byte[65536];
            while (i != 0)
            {
                FileStream outs = File.OpenWrite(@"temp\" + db + ".dat");
                if (i < 65536)
                {
                    ins.Read(b, 0, i);
                    i = 0;
                    outs.Write(b, 0, i);
                }
                else
                {
                    ins.Read(b, 0, 65536);
                    i = i - 65536;
                    outs.Write(b, 0, 65536);
                }
                db++;
                outs.Flush();
                outs.Close();
            }
            ins.Close();
            return db;
        }

        static void Repack(string inFile)
        {
            if (Directory.Exists("temp"))
                Directory.Delete("temp", true);
            Directory.CreateDirectory("temp");
            File.Delete(inFile + "2");
            int db = Darabol(inFile);
            //db--;
            Console.WriteLine("pieces: " + db);

            //tömörítés
            for (int j = 0; j < db; j++)
            {
                CompressFile(@"temp\" + j + ".dat", @"temp\" + j + ".zl");
                File.Delete(@"temp\" + j + ".dat");
            }

            //tömörített fájlok méreteinek olvasása, és a fejléc újraszámolása
            int[] FileData = new int[db];
            for (int j = 0; j < db; j++)
            {
                FileInfo file = new FileInfo(@"temp\" + j + ".zl");
                FileData[j] = (int)file.Length;
            }
            //fejléc beírása + fájlok beírása
            FileStream outs = File.OpenWrite(inFile + "2");
            byte[] b = new byte[4];
            b = BitConverter.GetBytes(db);
            outs.Write(b, 0, 4);
            b = BitConverter.GetBytes(65536);
            outs.Write(b, 0, 4);
            b = BitConverter.GetBytes((db * 8) + 8);
            outs.Write(b, 0, 4);
            int FileBegin = 0;
            for (int j = 0; j < db; j++)
            {
                if (j != 0)
                {
                    b = BitConverter.GetBytes(FileBegin + FileData[j] + 4); //kezdése
                    outs.Write(b, 0, 4);
                }
                b = BitConverter.GetBytes(FileData[j] + 4); //mérete
                outs.Write(b, 0, 4);
            }

            byte[] a = new byte[70000];
            for (int j = 0; j < db; j++)
            {
                FileStream ins = File.OpenRead(@"temp\" + j + ".zl");
                //teljes zl fájl beírása IDE
                ins.Read(a, 0, FileData[j]);
                Console.WriteLine("filedata" + j + ": " + FileData[j]);
                outs.Write(a, 0, FileData[j]);
                b = BitConverter.GetBytes(65536);
                outs.Write(b, 0, 4);
                ins.Close();
                File.Delete(@"temp\" + j + ".zl");
            }
            outs.Flush();
            outs.Close();
            Directory.Delete("temp", true);
        }

        static void Unpack(string inFile)
        {
            if (Directory.Exists("temp"))
                Directory.Delete("temp", true);
            Directory.CreateDirectory("temp");
            byte[] a = new byte[2];
            byte[] b = new byte[4];
            FileStream ins = File.OpenRead(inFile);
            ins.Read(b, 0, 4); //db
            int db = BitConverter.ToInt32(b, 0);
            ins.Read(b, 0, 4); //tömörítetlen méretek
            //int hossz = BitConverter.ToInt32(b, 0);

            //fejléc
            int[] offset = new int[db];
            int[] fileChunk = new int[db];
            for (int i = 0; i < db; i++)
            {
                ins.Read(b, 0, 4);
                offset[i] = BitConverter.ToInt32(b, 0);
                ins.Read(b, 0, 4);
                fileChunk[i] = BitConverter.ToInt32(b, 0) - 4;
            }
            
            //fájlkezelés
            FileStream outs2;
            for (int i = 0; i < db; i++)
            {
                ins.Seek(offset[i], SeekOrigin.Begin);
                ins.Read(a, 0, 2);
                ins.Seek(-2, SeekOrigin.Current); //Zlib header check
                byte[] fileSize = new byte[fileChunk[i]];
                outs2 = File.OpenWrite(@"temp\" + i + ".zl");
                ins.Read(fileSize, 0, fileChunk[i]);
                outs2.Write(fileSize, 0, fileChunk[i]);
                outs2.Close();
                if (a[0] == 0x78 && a[1] == 0x9c)
                {
                    DecompressFile(@"temp\" + i + ".zl", @"temp\" + i + ".dat");
                    File.Delete(@"temp\" + i + ".zl");
                    Console.WriteLine(db + " \\ " + i);
                }
                else { Console.WriteLine(db + " \\ " + i + " -skip"); File.Move(@"temp\" + i + ".zl", @"temp\" + i + ".dat"); }
            }
            ins.Close();

            FileStream outs = File.OpenWrite(inFile + "_unp");
            for (int i = 0; i < db; i++)
            {
                ins = File.OpenRead(@"temp\" + i + ".dat");
                FileInfo f = new FileInfo(@"temp\" + i + ".dat");
                byte[] fullFile = new byte[(int)f.Length];
                ins.Read(fullFile, 0, (int)f.Length);
                outs.Write(fullFile, 0, (int)f.Length);
                ins.Close();
            }
            outs.Close();
            Directory.Delete("temp",true);
        }

        static void Main(string[] args)
        {
            Console.Clear();
            Console.WriteLine("Grin .fcl unpacker/repacker\nTom Evin 2012.11.04.");
            if (args.Length < 1)
            {
                Console.WriteLine("\nError:\nMissing argument.\n\nUsage: FCL_Grin filename.ext");
                Console.WriteLine("\nIf extension of file is fcl -> Unpack\nIf not fcl -> Repack");
                Console.WriteLine("\nPress Enter to exit");
                Console.Read();
            }
            else
            {
                if (Path.GetExtension(args[0]).ToLower() == ".fcl") Unpack(args[0]);
                else Repack(args[0]);
            }
        }
    }
}
