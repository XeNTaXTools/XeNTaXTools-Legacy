import subprocess

import struct
import os
import shutil
import datetime

input_path = "C:\\my_programs\\acv\\4"
output_path = "C:\\my_programs\\acv\\4"
out_folrmat = "acvlhtex"
array_tex=[]
export_textures = True

if(export_textures):
	#textures
	print("WORK WITH TEXTURES")
	#MIPMAP = 491489187
	#TEXTURE_SET = 3608045168,   
	#TEXTURE_MAP = 2729961751
	array_tex=["2729961751"]
	mip_dir = "491489187"


	#logfile.write("WORK WITH TEXTURES" + "\n")
	#logfile.flush()

	for ftype in array_tex:
		
		local_in_root = os.path.join(input_path, ftype)
		#local_out_root = os.path.join(output_path, ftype)
		local_out_root = os.path.join(output_path, out_folrmat)
		if (not os.path.exists(local_out_root)): os.makedirs(local_out_root)

		for root, dirs, files in os.walk(input_path):
			#print("watch to " + root)
			if(os.path.basename(root) == ftype ):
				#print("found " + ftype)			
				for name in files:
					if(name.endswith("acvlh_" + str(ftype)) ):
						print("found texture set " + name)
						texture_set = os.path.join(root,name)
						print("	set:  " + texture_set)
						mip_folder = os.path.join(os.path.dirname(root), (mip_dir))
						mip0 = ""
						mip1 = ""
						
						tmp_str = os.path.join(mip_folder,  name[:-(len(ftype) + 7)] + "_TopMip_0" + ".acvlh_" + (mip_dir))
						if(os.path.exists(tmp_str)): mip0 = tmp_str
						
						tmp_str = os.path.join(mip_folder,  name[:-(len(ftype) + 7)] + "_TopMip_1" + ".acvlh_" + (mip_dir))
						if(os.path.exists(tmp_str)): mip1 = tmp_str
						
						print("	mip0: " + mip0)
						print("	mip1: " + mip1)
						
						if(mip0 != ""):
							print("		JOIN:")
							new_file_name = os.path.join(local_out_root, name[:-(len(ftype) + 7)] + "." + out_folrmat )
							with open(new_file_name, "wb") as filetex:
								with open(texture_set, "rb") as fileset:
									filetex.write(fileset.read())
								with open(mip0, "rb") as filemip:
									filetex.write(filemip.read())
						else:
							print("		UNFOUND MIP0, just copy:")
							old_name = texture_set
							new_name = os.path.join(local_out_root, name + "." + out_folrmat )
							print("		copy " + old_name  + " to " + new_name)
							if(not os.path.exists(new_name)):
								shutil.copyfile(old_name, new_name) 
								print("		done")
							else:
								print("		already exists, skipped")
						print("")
						''' TopMip
						try:
							if((sort_tex(os.path.join(root, name))) or (export_without_sort)):#name.startswith("CE_")):
								
								fullname = os.path.join(root, name)
								if fullname.endswith('.raw'):
									print(fullname)
									execut_str = '\"' + bms_binary_path + '\" -K -d -R -Q '
									execut_str = execut_str + '\"' + script_path + '\" '
									execut_str = execut_str + '\"' + fullname + '\"  '	
									execut_str = execut_str + '\"' + local_out_root + '\"  '
									subprocess.call(execut_str, shell=False)
									
									execut_str = '\"' + bms_binary_path + '\" -K -d -R -Q '
									execut_str = execut_str + '\"' + script_path + '\" '
									execut_str = execut_str + '\"' + os.path.join(os.path.dirname(root), mip_dir , name[:-4] + "_TopMip_0.raw") + '\"  '	
									execut_str = execut_str + '\"' + local_out_root + '\"  '
									subprocess.call(execut_str, shell=False)					
									
									
									
									
									loc_old_name1 = os.path.join(local_out_root,name, name[:-4], "1.dat")
									loc_old_name2 = os.path.join(local_out_root, (name[:-4] + "_TopMip_0.raw"), (name[:-4] + "_TopMip_0"), "1.dat")
									
									loc_new_name = os.path.join(local_out_root, name[:-4])+ "." + game +"tex"
									print(loc_old_name1)
									print(loc_old_name2)
									print(loc_new_name)
									
									#if(os.path.exists(loc_new_name)): os.remove(loc_new_name)

									if(os.path.exists(loc_old_name1)):
										if(replase_files):
											if(os.path.exists(loc_new_name)): os.remove(loc_new_name)
										if(not replase_files):
											while(os.path.exists(loc_new_name)): 
												loc_new_name = loc_new_name[: -len("." + game +"tex" ) ] + "_" + "." + game +"tex" 
												print(loc_new_name)
										#os.rename(loc_old_name, loc_new_name)
										os.rename(loc_old_name1, loc_new_name)
									else:
										logfile.write("ERROR_2:: not exists " + loc_old_name1 + "\n")
										logfile.flush()
										print("ERROR:: not exists " + loc_old_name1)
										
									if(not os.path.exists(loc_new_name)): 
										print("ERROR:: not exists " + loc_new_name)
										logfile.write("ERROR_3:: not exists " + loc_new_name + "\n")
										logfile.flush()
									elif(not os.path.exists(loc_old_name2)): 
										print("WARNING_4:: not exists " + loc_old_name2)
										logfile.write("WARNING_4:: not exists " + loc_old_name2 + "\n")
										logfile.flush()
									else:
										print("All fine " + loc_new_name)
										logfile.write("All fine " + loc_old_name2 + "\n")
										logfile.flush()										
										with open(loc_new_name, "ab") as myfile, open(loc_old_name2, "rb") as file2:
											myfile.write(file2.read())
											
									if(os.path.exists(os.path.join(local_out_root,name))): shutil.rmtree(os.path.join(local_out_root,name))
									if(os.path.exists(os.path.join(local_out_root,(name[:-4] + "_TopMip_0.raw")))): shutil.rmtree(os.path.join(local_out_root,(name[:-4] + "_TopMip_0.raw")))
						except Exception:
							logfile.write("ERROR_5:: except error " + root + " " +name + "\n")'''
						
print("finall")
