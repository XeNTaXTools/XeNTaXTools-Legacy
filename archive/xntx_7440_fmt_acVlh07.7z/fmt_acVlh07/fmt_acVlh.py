# Assassin's Creed: Origins model plugin for Noesis
# Version 1.0
# by theawesomecoder61 (pineapples721)
#
# Version 1.0 (3/27/2019):
# - initial version

from inc_noesis import *
import math
import os
import struct

MDL_MAGIC = 1096652136
MSH_DATA =  105229237

class submeshObj(object):
	def __init__(self):

		self.vertices = []
		self.faces = []
		self.normals = []
		self.uvs = []
		self.uvs2 = []
		self.uvs3 = []
		self.uvs4 = []
		self.boneIndices = []
		self.boneIndices2 = []
		self.boneWeights = []
		self.boneWeights2 = []
		self.VertexCount = 0
		self.numIndices = 0
		self.vertexOffset = 0
		self.faceOffset = 0
		self.FaceCount = 0
		self.IndexCount = 0
		self.MinFaceIndex = 99999999
		self.MaxFaceIndex = 0
		self.vertArrayB = []
		self.UvArrayB1 = []
		self.UvArrayB2 = []
		self.UvArrayB3 = []
		self.UvArrayB4 = []
		self.faceArrayB = []
		self.TextureIndex = 0
		self.id = 0
		self.num = 0
		self.NumOfVerticesBeforeMe = 0
		self.vertex_offset = 0

def registerNoesisTypes():
	#handle = noesis.register("Assassin's Creed: Odyssey model", ".dat1")
	handle = noesis.register("Assassin's Creed: Odyssey model", ".acvlh_1096652136")
	noesis.setHandlerTypeCheck(handle, mdlValidate)
	noesis.setHandlerLoadModel(handle, mdlLoadModel)

	noesis.logPopup()
	return 1

def mdlValidate(data):
	bs = NoeBitStream(data)
	#print(bs)
	loc_mgic = bs.readInt()
	print("magic " + hex(loc_mgic))
	if loc_mgic != MDL_MAGIC:
		print("Not a model file")
		return 1
	return 1

def fnd4byte (bs, bytes_ar):
	old_offest = bs.tell()
	byte1 = bs.readUByte()
	byte2 = bs.readUByte()
	byte3 = bs.readUByte()
	byte4 = bs.readUByte()
	
	
	val2 = 0
	val = byte1 + byte2 * 0x100 + byte3 * 0x10000 + byte4 * 0x1000000
	if(val == bytes_ar):
		bs.seek(old_offest, NOESEEK_ABS)
		return old_offest	

	while(val != bytes_ar):
		old_offest1 = bs.tell()
		byte1 = bs.readUByte()
		byte2 = bs.readUByte()
		byte3 = bs.readUByte()
		byte4 = bs.readUByte()
		
		val = byte1 + byte2 * 0x100 + byte3 * 0x10000 + byte4 * 0x1000000
		
		#str1 = hex(val)[2:]
		#while (len(str1) < 8): str1 = "0" + str1
		#print("0x" + str1)
		bs.seek(-3 , NOESEEK_REL)
		val2 = val2 +1 
		old_offest2 = bs.tell()
		if(old_offest1 == old_offest2): 
			bs.seek(old_offest, NOESEEK_ABS)
			return -1
	
	
	new_offest = bs.tell()
	bs.seek(old_offest, NOESEEK_ABS)	
	return new_offest - 1

	

def mdlLoadModel(data, mdlList):

	ctx = rapi.rpgCreateContext()
	bs = NoeBitStream(data)
	submeshes = []
	meshes = []
	meshes2 = []
	vertex_pos = 0
	face_pos = 0
	WatchUV = False

	print("")
	print("")
	print("")
	print("New File")

	print("cur_offset1: " + hex(bs.tell()))

	ResourceIdentifier = bs.readUInt()
	FileSize = bs.readUInt()
	FileNameSize = bs.readUInt()
	
	print("New File")
	print("ResourceIdentifier: " + hex(ResourceIdentifier) + "  " + str(ResourceIdentifier) )
	print("FileSize: " +  hex(FileSize) + "  " + str(FileSize) )
	print("FileNameSize: " +  hex(FileNameSize) + "  " + str(FileNameSize) )

	FileName = NoeBitStream(bs.readBytes(FileNameSize)).readString()
	print("FileName: " +  FileName )
	print("")
	
	


									
	#					reader.BaseStream.Seek(10, SeekOrigin.Current);
    #                    reader.BaseStream.Seek(3, SeekOrigin.Current);
    # #                   meshBlock.ModelType = reader.ReadInt32();
    #                    meshBlock.ACount = reader.ReadInt32();
	
	bs.seek(10 + 3, NOESEEK_REL)
	print("cur_offset2: " + hex(bs.tell()))

	ModelType = bs.readUInt()
	ACount = bs.readUInt()
		
	print("ModelType: " +  hex(ModelType) + "  " + str(ModelType) )
	print("ACount: " +  hex(ACount) + "  " + str(ACount) )
	
	print("cur_offset2: " + hex(bs.tell()))
	
	
	
	
	
	
	
	
	val2 = fnd4byte(bs, 4238218645)
	print("magic model start offset : " + hex(val2))
	dtest = 0

	while(val2 > 0):# and (dtest < 200):
		#try:
			meshes2 = []
			dtest = dtest + 1
			print("")
			bs.seek(val2, NOESEEK_ABS)
			print("cur_offset3: " + hex(bs.tell()))

			 
			loc_mgic2 = bs.readUInt()
			print("	magic model vlaue: " + hex(loc_mgic2))
			
			
			
			
			print("	Model " +  FileName + ":   "+ str(dtest))		
			
			#NEXT 9 bytes:
			# 5 unknown bytes, pervye 4 - 0, 5 - chislo
			#sleduushie 4 - 01 00 f8 fb;     f8 fb  - povtoryaetsa, pohoje na razmetky
			#sleduushie 4 - 00
			print("")	
			tstr = ""
			for tt in range (5):
				val = bs.readUByte()
				if val < 16:
					tstr = tstr + "0" + str(hex(val))[2:] + "    "
				else:
					tstr = tstr +  str(hex(val))[2:] + "    "
			print("	val0:     " + tstr)
			
			indexF8FB = 0
			indexF8FB_2 = 0
			tstr = ""
			tmp_arr0 = []
			for tt in range (12):
				
				val = bs.readUByte()
				tmp_arr0.append(val)
				if(tt == 0): indexF8FB = val
				if val < 16:
					tstr = tstr + "0" + str(hex(val))[2:] + "    "
				else:
					tstr = tstr +  str(hex(val))[2:] + "    "
			print("	val0:     " + tstr)	
			print("	indexF8FB: " + str(indexF8FB))	
			print("")	
			
			
			table_len = 0
			if 		((tmp_arr0[8] == 0x43 ) and (tmp_arr0[9] == 0xee ) and (tmp_arr0[10] == 0x51 ) and (tmp_arr0[11] == 0xc3 )):
				table_len = 5
			elif 	((tmp_arr0[8] == 0xb5 ) and (tmp_arr0[9] == 0xab ) and (tmp_arr0[10] == 0x45 ) and (tmp_arr0[11] == 0x06 )):
				table_len = 2
			else:
				print("")
				print("		UNFOUND HASH0:	" + hex(tmp_arr0[8]) + "	" + hex(tmp_arr0[9]) + "	" + hex(tmp_arr0[10]) + "	" + hex(tmp_arr0[11]) + "	offset: " + hex(bs.tell() - 12)) 
				print("")
			
			
			
			
			
			print("")
			bs.seek(table_len, NOESEEK_REL)
			print("	cur_offset41: " + hex(bs.tell()))
			compiledMesh_VertexTableSize = bs.readUInt()
			compiledMesh_Unknown1 = bs.readUInt()
			compiledMesh_Unknown2 = bs.readUInt()			
			print("	compiledMesh_VertexTableSize: " + hex(compiledMesh_VertexTableSize) + "  " + str(compiledMesh_VertexTableSize) )
			print("	compiledMesh_Unknown1: " +  hex(compiledMesh_Unknown1) + "  " + str(compiledMesh_Unknown1) )
			print("	compiledMesh_Unknown2: " +  hex(compiledMesh_Unknown2) + "  " + str(compiledMesh_Unknown2) )			
			actualVertexTableSize = compiledMesh_Unknown1
			if((compiledMesh_VertexTableSize != 8) and 
				(compiledMesh_VertexTableSize != 16) ): actualVertexTableSize = compiledMesh_VertexTableSize #?????
			print("	actualVertexTableSize: " +  hex(actualVertexTableSize) + "  " + str(actualVertexTableSize) )			
			print("")			
			
			
			
			
			
			
			indexF8FB = indexF8FB + 1
			fnd_value = indexF8FB *0x01+ (00)*0x100 + 0xf8 * 0x10000 + 0xfb * 0x1000000
			print("	fnd_value " + hex(fnd_value))
			tableoffset = fnd4byte(bs, fnd_value)
			print("	tableoffset " + hex(tableoffset))
			print("	delta       " + hex(tableoffset - bs.tell()))
			print("")

			
			
			
			
			
			
			
			
			
				
			
			
			
			
			

			bs.seek(tableoffset - 4, NOESEEK_ABS)			
			entits_count = bs.readUInt()		

			print("	entits_count: " + hex(entits_count) + "  " + str(entits_count) )

			# write header
			tstr = ""
			for tt in range (52):
				val = tt
				if val < 16:
					tstr = tstr + "0" + str(hex(val))[2:] + "    "
				else:
					tstr = tstr +  str(hex(val))[2:] + "    "
			print("		test:		" + tstr)
			print("		   _____________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________" )			
			
			
			entites_buffer = []			
			Entries_FaceOffset = []
			Entries_VertexOffset = []
			for i in range (0, min([entits_count, 40])):


				tmp_arr = []
				tstr = ""
				
				for tt in range (12):
					val = bs.readUByte()
					tmp_arr.append(val)
					if val < 16:
						tstr = tstr + "0" + str(hex(val))[2:] + "    "
					else:
						tstr = tstr +  str(hex(val))[2:] + "    "
				
				table_len = 0
				if 		((tmp_arr[8] == 0x87 ) and (tmp_arr[9] == 0x9a ) and (tmp_arr[10] == 0xb1 ) and (tmp_arr[11] == 0x07 )):
					table_len = 52 - 12
				elif 	((tmp_arr[8] == 0xef ) and (tmp_arr[9] == 0x87 ) and (tmp_arr[10] == 0x73 ) and (tmp_arr[11] == 0xa5 )):
					table_len = 0x24 - 12
				else:
					print("")
					print("		UNFOUND HASH1:	" + hex(tmp_arr[8]) + "	" + hex(tmp_arr[9]) + "	" + hex(tmp_arr[10]) + "	" + hex(tmp_arr[11]) + "	offset: " + hex(bs.tell() - 12)) 
					print("")
					
				
				
	
				for tt in range (table_len):
					val = bs.readUByte()
					tmp_arr.append(val)
					if val < 16:
						tstr = tstr + "0" + str(hex(val))[2:] + "    "
					else:
						tstr = tstr +  str(hex(val))[2:] + "    "
	
	
				print("		tsr0:		" + str(tstr))
				Entries_VertexOffset.append (tmp_arr[0x14] * 0x01+ tmp_arr[0x15]*0x100 + tmp_arr[0x16] * 0x10000 + tmp_arr[0x17] * 0x1000000)	#(tmp_arr[0x10] * 0x01+ tmp_arr[0x11]*0x100 + tmp_arr[0x12] * 0x10000 + tmp_arr[0x13] * 0x1000000)
				Entries_FaceOffset.append (tmp_arr[0x10] * 0x01+ tmp_arr[0x11]*0x100 + tmp_arr[0x12] * 0x10000 + tmp_arr[0x13] * 0x1000000)		
				indexF8FB_2 = tmp_arr[0]
			table_end_offset = bs.tell()
			print("	table_end_offset: " + hex(table_end_offset))
			
			for i in range (len(Entries_FaceOffset)):
				print("	vertex offset " + hex(Entries_VertexOffset[i]) + "  ||  " + str (Entries_VertexOffset[i]) +  "		face offset " +  hex(Entries_FaceOffset[i]) + "  ||  " + str (Entries_FaceOffset[i]))
			
			
			
			
			
			
			
			
			
			
			
			
			mesh_ = 0
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			extUV_offset = 0
			extUV_offset_len = 0
			ext_uv_record = 0
			bs.seek(0x10, NOESEEK_REL)	
			
			UvArrayB2 = []
			
			if(compiledMesh_Unknown2 != 0):        # WATCH HERE!!!! May be  compiledMesh_Unknown2 - size of one vertex????
				print(	"\n		EXTERNAL UV!!!")
				
				
				extUV_offset_len = bs.readUInt()
				extUV_offset = (bs.tell())
				print("		extUV_offset: " + hex(extUV_offset))
				print("		extUV_offset_len: " + hex(extUV_offset_len))
				bs.seek(extUV_offset_len, NOESEEK_REL)
				'''
				arr_len = unknown0DataSize // 8
				for i in range(arr_len):
					skp = bs.readUInt()
					u = bs.readShort()
					v = bs.readShort()
						
					u = float(u) /65535 * 32
					v = float(v) /65535 * 32
					UvArrayB2.append(u)
					UvArrayB2.append(v)
					UvArrayB2.append(0)
					'''
				print("")
				
			


	



			#VERTEX DATA
			print("")
			print("	VERTEX DATA")
			print("	cur_offset8 (vertices): " + hex(bs.tell())) # uv_external				
			len_vertex_block_array = bs.readUInt()
			Entries_VertexOffset.append(len_vertex_block_array)
			print("	len_vertex_block_array: " + hex(len_vertex_block_array)) # uv_external	
			VertexGlobalOffset = bs.tell()
			print("	VertexGlobalOffset : " + hex(bs.tell())) # uv_external			
			bs.seek(len_vertex_block_array, NOESEEK_REL)
			print("	VertexGlobalEND : " + hex(bs.tell())) # uv_external
			
			print("")
			print("	UNKNOWN DATA2")			
			print("	cur_offset11 (UNKNOWN): " + hex(bs.tell())) # uv_external	
			len_unknown_data2 = bs.readUInt()
			print("	len_unknown_data2: " + hex(len_unknown_data2) + "  //  " + str(len_unknown_data2)   ) 
			print("	UnknownData2GlobalOffset : " + hex(bs.tell())) # uv_external	
			bs.seek(len_unknown_data2, NOESEEK_REL)
			print("	UnknownData2END : " + hex(bs.tell())) # uv_external
			
			
			
			print("")
			print("	UNKNOWN DATA22")			
			print("	cur_offset12 (UNKNOWN): " + hex(bs.tell())) # uv_external	
			len_unknown_data22 = bs.readUInt()
			print("	len_unknown_data22: " + hex(len_unknown_data22) + "  //  " + str(len_unknown_data22)   ) 
			print("	UnknownData22GlobalOffset : " + hex(bs.tell())) # uv_external	
			bs.seek(len_unknown_data22, NOESEEK_REL)
			print("	UnknownData22END : " + hex(bs.tell())) # uv_external
			
			
			#FACE DATA
			
			
			if(len_unknown_data2 == 0): bs.seek(4, NOESEEK_REL)
			else: bs.seek(0, NOESEEK_REL)
			
			print("")
			print("	FACE DATA")
			print("	cur_offset9 (faces): " + hex(bs.tell())) # uv_external				
			len_face_block_array = bs.readUInt()
			Entries_FaceOffset.append(len_face_block_array)
			print("	len_face_block_array: " + hex(len_face_block_array) + "  //  " + str(len_face_block_array)   ) 			
			FaceGlobalOffset = bs.tell()
			print("	FaceGlobalOffset:   " + hex(FaceGlobalOffset) + "   " + str(FaceGlobalOffset))
			bs.seek(len_face_block_array, NOESEEK_REL)
			print("	FacesGlobalEND : " + hex(bs.tell())) # uv_external
			print("")


			print("	UNKNOWN DATA3")			
			print("	cur_offset12 (UNKNOWN): " + hex(bs.tell())) # uv_external	
			len_unknown_data3 = bs.readUInt()
			print("	len_unknown_data3: " + hex(len_unknown_data3) + "  //  " + str(len_unknown_data3)   ) 
			print("	UnknownData3GlobalOffset : " + hex(bs.tell())) # uv_external	
			bs.seek(len_unknown_data3, NOESEEK_REL)
			print("	UnknownData3END : " + hex(bs.tell())) # uv_external
			
			print("")
			print("	UNKNOWN DATA4")			
			print("	cur_offset14 (UNKNOWN): " + hex(bs.tell())) # uv_external	
			len_unknown_data4 = bs.readUInt()
			print("	len_unknown_data4: " + hex(len_unknown_data4) + "  //  " + str(len_unknown_data4)   ) 
			print("	UnknownData4GlobalOffset : " + hex(bs.tell())) # uv_external	
			bs.seek(len_unknown_data4, NOESEEK_REL)
			print("	UnknownData4END : " + hex(bs.tell())) # uv_external			
			
			
			print("")
			print("	UNKNOWN DATA5")			
			print("	cur_offset15 (UNKNOWN): " + hex(bs.tell())) # uv_external	
			len_unknown_data5 = bs.readUInt()
			print("	len_unknown_data5: " + hex(len_unknown_data5) + "  //  " + str(len_unknown_data5)   ) 
			print("	UnknownData5GlobalOffset : " + hex(bs.tell())) # uv_external	
			bs.seek(len_unknown_data5, NOESEEK_REL)
			print("	UnknownData5END : " + hex(bs.tell())) # uv_external					
			
			val2 = fnd4byte(bs, 4238218645)
			
			print("")
			indexF8FB_2 = indexF8FB_2 + 1
			print("	found F8FB pattern: " + hex(indexF8FB_2))
			fnd_value = indexF8FB_2 *0x01+ (00)*0x100 + 0xf8 * 0x10000 + 0xfb * 0x1000000
			print("	fnd_value " + hex(fnd_value))
			submeshesoffset = fnd4byte(bs, fnd_value)
			print("	submeshesoffset " + hex(submeshesoffset))
			print("	delta       " + hex(submeshesoffset - bs.tell()))
			print("")
			
			
			
			
			print("	SUBMESHES")
			bs.seek(submeshesoffset, NOESEEK_ABS)
			tstr = ""
			for tt in range (52):
				val = tt
				if val < 16:
					tstr = tstr + "0" + str(hex(val))[2:] + "    "
				else:
					tstr = tstr +  str(hex(val))[2:] + "    "
			print("		test:		" + tstr)
			print("		   _____________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________" )			
			
			summ_vertex = 0
			totalVertices = 0;
			submeshes = []
			for i in range (entits_count + 1):


				tmp_arr = []
				tstr = ""
				
				for tt in range (12):
					val = bs.readUByte()
					tmp_arr.append(val)
					if val < 16:
						tstr = tstr + "0" + str(hex(val))[2:] + "    "
					else:
						tstr = tstr +  str(hex(val))[2:] + "    "
				
				table_len = 0
				if 		((tmp_arr[8] == 0xb5 ) and (tmp_arr[9] == 0xab ) and (tmp_arr[10] == 0x45 ) and (tmp_arr[11] == 0x06)):
					table_len = 0x1e - 12
				elif 	((tmp_arr[8] == 0xef ) and (tmp_arr[9] == 0x87 ) and (tmp_arr[10] == 0x73 ) and (tmp_arr[11] == 0xa5 )):
					table_len = 0x24 - 12
				else:
					print("")
					print("		UNFOUND HASH1:	" + hex(tmp_arr[8]) + "	" + hex(tmp_arr[9]) + "	" + hex(tmp_arr[10]) + "	" + hex(tmp_arr[11]) + "	offset: " + hex(bs.tell() - 12)) 
					print("")
					
				
				
	
				for tt in range (table_len):
					val = bs.readUByte()
					tmp_arr.append(val)
					if val < 16:
						tstr = tstr + "0" + str(hex(val))[2:] + "    "
					else:
						tstr = tstr +  str(hex(val))[2:] + "    "
	
	
				print("		tsr0:		" + str(tstr))
				#Entries_VertexOffset.append (tmp_arr[0x10] * 0x01+ tmp_arr[0x11]*0x100 + tmp_arr[0x12] * 0x10000 + tmp_arr[0x13] * 0x1000000)
				#Entries_FaceOffset.append (tmp_arr[0x14] * 0x01+ tmp_arr[0x15]*0x100 + tmp_arr[0x16] * 0x10000 + tmp_arr[0x17] * 0x1000000)			

				
				if(i > 0):
					msh = submeshObj()
					msh.id 	= tmp_arr[0x0d]
					msh.num = i - 1
					msh.vertex_offset = summ_vertex
					print("			mesh: " + str(msh.num) + "	 id: "  + hex(msh.id) + "  " + str(msh.id) )
					print("			mesh: " + str(msh.num) + "	 vertex_offset: "  + hex(msh.vertex_offset) + "  " + str(msh.vertex_offset) )
					msh.VertexCount = tmp_arr[0x14] *0x01+ tmp_arr[0x15]*0x100 + tmp_arr[0x16] * 0x10000 + tmp_arr[0x17] * 0x1000000
					print("			VertexCount: " + hex(msh.VertexCount) + "  " + str(msh.VertexCount) )
					summ_vertex = summ_vertex + msh.VertexCount
					#bs.seek(4, NOESEEK_REL)


					msh.FaceCount = tmp_arr[0x1c] *0x01+ tmp_arr[0x1d]*0x100 + tmp_arr[0x1e] * 0x10000 + tmp_arr[0x1f] * 0x1000000
					print("			FaceCount: " + hex(msh.FaceCount) + "  " + str(msh.FaceCount) )
					msh.IndexCount = msh.FaceCount * 3;
					print("			IndexCount: " + hex(msh.IndexCount) + "  " + str(msh.IndexCount) )
					msh.MinFaceIndex = 65535
					msh.TextureIndex = tmp_arr[0x20] *0x01+ tmp_arr[0x21]*0x100 + tmp_arr[0x22] * 0x10000 + tmp_arr[0x23] * 0x1000000
					print("			TextureIndex: " + hex(msh.TextureIndex) + "  " + str(msh.TextureIndex) )
					submeshes.append(msh)
					
				indexF8FB_2 = indexF8FB_2 + 1			
				fnd_value = indexF8FB_2 *0x01+ (00)*0x100 + 0xf8 * 0x10000 + 0xfb * 0x1000000				
				read_value = bs.readUInt()
				bs.seek(-4, NOESEEK_REL)
				if(read_value != fnd_value):
					break
			print("	SUBMESHES END : " + hex(bs.tell())) # uv_external
			print("	summ_vertex : " + hex(summ_vertex)) # uv_external
			
			if(extUV_offset_len > 0) : 
				ext_uv_record = extUV_offset_len // summ_vertex
				print("	ext_uv_record : " + hex(ext_uv_record)) # uv_external

			
			
			for mesh in submeshes:
				print("")
				print("		MESH num:" + str (mesh.num)) 
				#reader.BaseStream.Seek(vertexOffset + (submeshBlock.Entries[i].VertexOffset * actualVertexTableSize), SeekOrigin.Begin);
	
	
				print("		VertexGlobalOffset:" + hex (VertexGlobalOffset))
				print("		Entries_VertexOffset:" + hex (Entries_VertexOffset[mesh.num]))	
				print("		actualVertexTableSize:" + hex (actualVertexTableSize))				
				real_vertex_offset = VertexGlobalOffset + (Entries_VertexOffset[mesh.num] * actualVertexTableSize)
				print("		go to vertex buffer, offset: " + hex(real_vertex_offset) + ", VertexCount: " + hex(mesh.VertexCount) + "  " + str(mesh.VertexCount) + ", actualVertexTableSize: " + hex(actualVertexTableSize) + "  " + str(actualVertexTableSize))


				bs.seek(real_vertex_offset, NOESEEK_ABS)
			
				for j in range (0, mesh.VertexCount):
					st_offset = bs.tell()
					#bs.readShort()
					#bs.readShort()
					#bs.readShort()
					#bs.readShort()
					#bs.readShort()
					#bs.readShort()
					#bs.readShort()
					#bs.readShort()
					#bs.seek(-4, NOESEEK_REL)
					x = float(bs.readShort())/65535 * 100
					y = float(bs.readShort())/65535 * 100
					z = float(bs.readShort())/65535 * 100


					scl = bs.readByte()

					

					if (scl<0):
						x = -x
						y = -y
						z = -z

					mesh.vertArrayB.append(x)
					mesh.vertArrayB.append(y)
					mesh.vertArrayB.append(z)
					
					
					bs.seek(st_offset + actualVertexTableSize -4, NOESEEK_ABS)
					u = bs.readShort()
					v = bs.readShort()
						
					u = float(u) /65535 * 32
					v = float(v) /65535 * 32
					mesh.UvArrayB1.append(u)
					mesh.UvArrayB1.append(v)
					mesh.UvArrayB1.append(0)
					bs.seek(st_offset + actualVertexTableSize, NOESEEK_ABS)
				print("		vertex end  " + hex(bs.tell()) )
				print("")
				
				if (mesh.num > 0):
					mesh.NumOfVerticesBeforeMe = totalVertices;
					totalVertices = totalVertices + mesh.VertexCount;

				print("		NumOfVerticesBeforeMe " + hex(mesh.NumOfVerticesBeforeMe) + "  " + str(mesh.NumOfVerticesBeforeMe))
				
				
				#print(len(mesh.vertArrayB))
				#print(len(mesh.UvArrayB1))
						

					
			
			
				real_face_offset = FaceGlobalOffset + Entries_FaceOffset[mesh.num] * 2
				
				print("		go to face buffer, offset: " + hex(real_face_offset) + ", FaceCount: " + hex(mesh.FaceCount) + "  " + str(mesh.FaceCount) )
				bs.seek(real_face_offset, NOESEEK_ABS)
				
				for i in range (0, mesh.FaceCount):
					v1 = bs.readUShort() #+ mesh.NumOfVerticesBeforeMe
					v2 = bs.readUShort() #+ mesh.NumOfVerticesBeforeMe
					v3 = bs.readUShort() #+ mesh.NumOfVerticesBeforeMe
					if((v1 != v2) and (v2 != v3) and (v1 != v3)):
						if (v1 < mesh.MinFaceIndex):  mesh.MinFaceIndex = v1 
						if (v1 < mesh.MinFaceIndex):  mesh.MinFaceIndex = v2 
						if (v1 < mesh.MinFaceIndex):  mesh.MinFaceIndex = v3
						
						if (v1 > mesh.MaxFaceIndex):  mesh.MaxFaceIndex = v1
						if (v2 > mesh.MaxFaceIndex):  mesh.MaxFaceIndex = v2
						if (v3 > mesh.MaxFaceIndex):  mesh.MaxFaceIndex = v3
						
						#mesh.faces.append([v1, v2, v3])#extend
						mesh.faces.extend([v1, v2, v3])
						mesh.faceArrayB.append(v1)
						mesh.faceArrayB.append(v2)
						mesh.faceArrayB.append(v3)
				print("		faces end  " + hex(bs.tell()) )
				print("		MinFaceIndex: " + hex(mesh.MinFaceIndex) + "  " + str(mesh.MinFaceIndex) )
				print("		MaxFaceIndex: " + hex(mesh.MaxFaceIndex) + "  " + str(mesh.MaxFaceIndex) )		
				print("		len faces: " + hex(len(mesh.faces)) + "  " + hex(len(mesh.faces)) )		
				print("		len vertices: " + hex(len(mesh.vertices)) + "  " + str(len(mesh.vertices)) )	




				if(extUV_offset != 0):
					bs.seek(extUV_offset, NOESEEK_ABS)
					bs.seek(mesh.vertex_offset * ext_uv_record, NOESEEK_REL)
					
					for j in range (0, mesh.VertexCount):
						st_offset = bs.tell()
						bs.readShort()
						bs.readShort()
						
						u = bs.readShort()
						v = bs.readShort()
							
						u = float(u) /65535 * 32
						v = 1 - float(v) /65535 * 32
						mesh.UvArrayB2.append(u)
						mesh.UvArrayB2.append(v)
						mesh.UvArrayB2.append(0)
						bs.seek(st_offset + ext_uv_record, NOESEEK_ABS)
					print("		External UV end  " + hex(bs.tell()) )
					print("")
					
					if (mesh.num > 0):
						mesh.NumOfVerticesBeforeMe = totalVertices;
						totalVertices = totalVertices + mesh.VertexCount;

					print("		NumOfVerticesBeforeMe " + hex(mesh.NumOfVerticesBeforeMe) + "  " + str(mesh.NumOfVerticesBeforeMe))
					
					
					#print(len(mesh.vertArrayB))
					#print(len(mesh.UvArrayB1))					
					
					
					

				print("		CreateGeometry")
				rapi.rpgSetName(FileName +"__"+ str(mesh.num) )
				
				bVertBuf = struct.pack("<" + 'f'*len(mesh.vertArrayB), *mesh.vertArrayB)
				bFaceBuf = struct.pack("<" + 'I'*len(mesh.faceArrayB), *mesh.faceArrayB)
				
				rapi.rpgBindPositionBuffer(bVertBuf, noesis.RPGEODATA_FLOAT, 12)				
				
				bUVBuf = struct.pack("<" + 'f'*len(mesh.UvArrayB1), *mesh.UvArrayB1)
				rapi.rpgBindUV1Buffer(bUVBuf, noesis.RPGEODATA_FLOAT, 12)
										
				if(len(mesh.UvArrayB2) > 0 ):
					bUVBuf = struct.pack("<" + 'f'*len(mesh.UvArrayB2), *mesh.UvArrayB2)
					rapi.rpgBindUV2Buffer(bUVBuf, noesis.RPGEODATA_FLOAT, 12)				
				rapi.rpgSetStripEnder(0x0fffffff)
				
				

				
				rapi.rpgCommitTriangles(bFaceBuf, noesis.RPGEODATA_INT, len(mesh.faceArrayB) , noesis.RPGEO_TRIANGLE, 1)	
				rapi.rpgClearBufferBinds()		
				#rapi.rpgCommitTriangles(None, noesis.RPGEODATA_USHORT, (len(mesh.vertArrayB))//3, noesis.RPGEO_POINTS, 0x1)		

				
				#mdl = rapi.rpgConstructModel()

				#mdlList.append(mdl)
			
				#					
			'''
			fnd_value = indexF8FB_2 *0x01+ (00)*0x100 + 0xf8 * 0x10000 + 0xfb * 0x1000000
			submeshesoffset = fnd4byte(bs, fnd_value)			
			
			
			print("	submeshesoffset " + hex(submeshesoffset))
			bs.seek(submeshesoffset - 4, NOESEEK_ABS)
			entits_count2 = bs.readUInt()
			
			for i in range (entits_count2):


				tmp_arr = []
				tstr = ""
				
				for tt in range (12):
					val = bs.readUByte()
					tmp_arr.append(val)
					if val < 16:
						tstr = tstr + "0" + str(hex(val))[2:] + "    "
					else:
						tstr = tstr +  str(hex(val))[2:] + "    "
				
				table_len = 0
				if 		((tmp_arr[8] == 0xc1 ) and (tmp_arr[9] == 0x34 ) and (tmp_arr[10] == 0x1d ) and (tmp_arr[11] == 0x0b)):
					table_len = 0x1e - 12
				elif 	((tmp_arr[8] == 0xef ) and (tmp_arr[9] == 0x87 ) and (tmp_arr[10] == 0x73 ) and (tmp_arr[11] == 0xa5 )):
					table_len = 0x24 - 12
				else:
					print("")
					print("		UNFOUND HASH1:	" + hex(tmp_arr[8]) + "	" + hex(tmp_arr[9]) + "	" + hex(tmp_arr[10]) + "	" + hex(tmp_arr[11]) + "	offset: " + hex(bs.tell() - 12)) 
					print("")
					
				
				
	
				for tt in range (table_len):
					val = bs.readUByte()
					tmp_arr.append(val)
					if val < 16:
						tstr = tstr + "0" + str(hex(val))[2:] + "    "
					else:
						tstr = tstr +  str(hex(val))[2:] + "    "
	
	
				print("		tsr0:		" + str(tstr))
				#Entries_VertexOffset.append (tmp_arr[0x10] * 0x01+ tmp_arr[0x11]*0x100 + tmp_arr[0x12] * 0x10000 + tmp_arr[0x13] * 0x1000000)
				#Entries_FaceOffset.append (tmp_arr[0x14] * 0x01+ tmp_arr[0x15]*0x100 + tmp_arr[0x16] * 0x10000 + tmp_arr[0x17] * 0x1000000)			
				indexF8FB_2 = indexF8FB_2 + 1			
				fnd_value = indexF8FB_2 *0x01+ (00)*0x100 + 0xf8 * 0x10000 + 0xfb * 0x1000000
				
				read_value = bs.readUInt()
				bs.seek(-4, NOESEEK_REL)
				if(read_value != fnd_value):
					break
			print("	SUBMESHES END : " + hex(bs.tell())) # uv_external			
			
			
			
			
			print("	entits_count2 " + hex(entits_count2))
			'''
			'''
			if(val2 < 0):
				#indexF8FB_2 = indexF8FB_2 + 1

				if(submeshesoffset > 0): print("\n\n	WARNING!!! found " + hex(fnd_value) + " in " + hex(submeshesoffset))
			else:
				#indexF8FB_2 = indexF8FB_2 + 1
				fnd_value = indexF8FB_2 *0x01+ (00)*0x100 + 0xf8 * 0x10000 + 0xfb * 0x1000000
				submeshesoffset = fnd4byte(bs, fnd_value)
				if((submeshesoffset > 0) and (submeshesoffset < val2)): print("\n\n	WARNING!!! found " + hex(fnd_value) + " in " + hex(submeshesoffset))
			'''
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			'''
			print("")
			print("	mesh: " + str(mesh_))
			
			len_vertex_count = (Entries_VertexOffset[mesh_ + 1] - Entries_VertexOffset[mesh_ ])// actualVertexTableSize		
			print("		len_vertex_count " + str(len_vertex_count) + "	( " +  str(Entries_VertexOffset[mesh_ + 1]) + " - " + str(Entries_VertexOffset[mesh_ ]) + " ) // " + str (actualVertexTableSize) )
			
			bs.seek(VertexGlobalOffset + Entries_VertexOffset[mesh_] , NOESEEK_ABS)
			print("		goto vertex " + hex(bs.tell()) + "	( " +  hex(VertexGlobalOffset) + " + " + hex(Entries_VertexOffset[mesh_]) + " )")
								
		
			UvArrayB1 = []
			vertArrayB = []
			
			
			for j in range (0, len_vertex_count):
				st_offset = bs.tell()
				#bs.readShort()
				#bs.readShort()
				#bs.readShort()
				#bs.readShort()
				#bs.readShort()
				#bs.readShort()
				#bs.readShort()
				#bs.readShort()
				#bs.seek(-4, NOESEEK_REL)
				x = float(bs.readShort())/65535 * 100
				y = float(bs.readShort())/65535 * 100
				z = float(bs.readShort())/65535 * 100


				scl = bs.readByte()

				

				if (scl<0):
					x = -x
					y = -y
					z = -z

				vertArrayB.append(x)
				vertArrayB.append(y)
				vertArrayB.append(z)
				
				
				bs.seek(st_offset + actualVertexTableSize -4, NOESEEK_ABS)
				u = bs.readShort()
				v = bs.readShort()
					
				u = float(u) /65535 * 32
				v = float(v) /65535 * 32
				UvArrayB1.append(u)
				UvArrayB1.append(v)
				UvArrayB1.append(0)
				bs.seek(st_offset + actualVertexTableSize, NOESEEK_ABS)
			print("		vertex end  " + hex(bs.tell()) )
			print("")

			


			
			
			
			
			
			
			
			
			
			
			
			
			
			faces_len = (Entries_FaceOffset[mesh_ + 1] - Entries_FaceOffset[mesh_ ])// 6
			print("		faces_len " + str(faces_len) + "	( " +  str(Entries_FaceOffset[mesh_ + 1]) + " - " + str(Entries_FaceOffset[mesh_ ]) + " ) // " + str (6) )
			faceArrayB = []
			
			
			
			bs.seek(FaceGlobalOffset + Entries_FaceOffset[mesh_] ,NOESEEK_ABS)
			print("		goto faces " + hex(bs.tell()) + "	( " +  hex(FaceGlobalOffset) + " + " + hex(Entries_FaceOffset[mesh_]) + " )")
			
			min_face = 99999999999
			max_face = 0
			for j in range (0, 0x490):	
				v1 = bs.readUShort() 
				v2 = bs.readUShort() 
				v3 = bs.readUShort() 	
				faceArrayB.append(int(v1))
				faceArrayB.append(int(v2))
				faceArrayB.append(int(v3))
				if(v1 < min_face): min_face = v1
				if(v1 > max_face): max_face = v1
				if(v2 < min_face): min_face = v2
				if(v2 > max_face): max_face = v2
				if(v2 < min_face): min_face = v3
				if(v2 > max_face): max_face = v3				
			print("		faces end  " + hex(bs.tell()) )
			print("		min_face: " + str(min_face)) 
			print("		max_face: " + str(max_face)) 
			print("")



























			
			

			print(len(vertArrayB))
			print(len(UvArrayB1))
			bVertBuf = struct.pack("<" + 'f'*len(vertArrayB), *vertArrayB)
			rapi.rpgBindPositionBuffer(bVertBuf, noesis.RPGEODATA_FLOAT, 12)					

			bUVBuf = struct.pack("<" + 'f'*len(UvArrayB1), *UvArrayB1)
			rapi.rpgBindUV1Buffer(bUVBuf, noesis.RPGEODATA_FLOAT, 12)
									
			if(len(UvArrayB2) > 0 ):
				bUVBuf = struct.pack("<" + 'f'*len(UvArrayB2), *UvArrayB2)
				rapi.rpgBindUV2Buffer(bUVBuf, noesis.RPGEODATA_FLOAT, 12)
			bFaceBuf = struct.pack("<" + 'I'*len(faceArrayB), *faceArrayB)
			rapi.rpgCommitTriangles(bFaceBuf, noesis.RPGEODATA_INT, len(faceArrayB) , noesis.RPGEO_TRIANGLE, 1)			
			#rapi.rpgCommitTriangles(None, noesis.RPGEODATA_USHORT, (len(vertArrayB))//3, noesis.RPGEO_POINTS, 0x1)		
				
			
			mdl = rapi.rpgConstructModel()

			mdlList.append(mdl)
		
			rapi.rpgClearBufferBinds()				
			
					'''		
			
			
	
			#Nmesh = NoeMesh(vertArray, [], noesis.RPGEO_POINTS)	
			#meshes.append( Nmesh)		
					
			#bs.seek(end_of_mesh_data, NOESEEK_ABS)		
			#print("	End of Model Data: " + hex(end_of_mesh_data))
			
			print("	next magic model offset: " + hex(val2))
			
			break
		#except RuntimeError  :
		#	print("ERROR")
		#	val2 = -1
	
					
					
					
				
				

	
	#if(len(meshes) > 0):		
	#	mdl = NoeModel(meshes)
	#	
	#	mdlList.append(mdl)
			
	mdl = rapi.rpgConstructModelSlim()

	mdlList.append(mdl)
	print("")
	print("FINAL!!!")
	print("")
	print("")
	return 1
	
