#Killer Instinct [PC] - ".kitex" Loader
#By Zaramot
#v1.0

from inc_noesis import *
import subprocess

def registerNoesisTypes():
	handle = noesis.register("Killer Instinct [PC]", ".kitex")
	noesis.setHandlerTypeCheck(handle, texCheckType)
	noesis.setHandlerLoadRGBA(handle, texLoadDDS)
	noesis.logPopup()
	return 1
		
def texCheckType(data):
	bs = NoeBitStream(data)
	fileMagic = bs.readUInt()
	if fileMagic == 0x3:
		return 1
	else: 
		print("Fatal Error: Unknown file magic: " + str(hex(fileMagic) + " expected 0x3!"))
		return 0

def texLoadDDS(data, texList):
    bs = NoeBitStream(data)
	
    fileMagic = bs.readUInt()
    bs.seek(0x8, NOESEEK_ABS) 
    DataOff = bs.readUInt()
    bs.seek(0x40, NOESEEK_ABS) 
    DataStride = bs.readUShort()
    bs.seek(0x80, NOESEEK_ABS) #Texture DXT1 or DXT5
    TexID = bs.readUShort()
    bs.seek(0x6C, NOESEEK_ABS) 
    if TexID == 0: 
         TWidth = bs.readUInt()
         Height = bs.readUInt()
    elif TexID == 1: 
         TWidth = bs.readUInt()
         Height = bs.readUInt()
    elif TexID == 5: 
         TWidth = bs.readUInt()
         Height = bs.readUInt()
    elif TexID == 6: 
         TWidth = bs.readUInt()
         Height = bs.readUInt()
    #DXT1
    if TexID == 0:
        ddsSize = (TWidth * Height) * 4
    #DXT1
    elif TexID == 1:
        ddsSize = (TWidth * Height) // 2
    #DXT3
    elif TexID == 5:
        ddsSize = (TWidth * Height)
    #DXT5
    elif TexID == 6:
        ddsSize = (TWidth * Height)
    ddsName = rapi.getLocalFileName(rapi.getInputName())
    print (ddsName)
    print (TWidth)
    print (Height)
    print (TexID)
    print (ddsSize)
    DataStart = ((DataOff+DataStride)+12)
    print (DataStart) 
    bs.seek(DataStart, NOESEEK_ABS) #Texture start
    ddsData = bs.readBytes(ddsSize)
    #DXT1 packed normal map
    if TexID == 0:
	    ddsData = rapi.imageDecodeRaw(ddsData, TWidth, Height, "a8r8g8b8")
	    texFmt = noesis.NOESISTEX_RGBA32
    #DXT1
    elif TexID == 1:
        texFmt = noesis.NOESISTEX_DXT1
    #DXT1
    elif TexID == 6:
	    ddsData = rapi.imageDecodeDXT(ddsData, TWidth, Height, noesis.FOURCC_ATI2)
	    texFmt = noesis.NOESISTEX_RGBA32
    #DXT5
    elif TexID == 5:
        texFmt = noesis.NOESISTEX_DXT5
    tex1 = (NoeTexture(ddsName, TWidth, Height, ddsData, texFmt))
    texList.append(tex1)

    return 1
	