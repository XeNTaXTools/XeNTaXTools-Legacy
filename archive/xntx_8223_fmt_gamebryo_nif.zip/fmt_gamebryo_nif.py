#by Durik256
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Epic Mickey", ".nif")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)   
    return 1
    
def noepyCheckType(data):
    if data.find(b'\x15\x02\x01\x00') < 0:
        return 0
    return 1

def noepyLoadModel(bs, mdlList):
    #vert_ofsset = bs.find(b'\x01\x00\x00\x00\x37\x04\x03\x00') - 4
    face_ofsset = bs.find(b'\x15\x02\x01\x00') - 25
    '''
    15 02 01 00 - 2  (face)
    10 01 04 00 - 4  (color) 
    36 04 02 00 - 8  (uvs)
    38 04 04 00 - 16 (tangens)
    37 04 03 00 - 12 (vert/normals)
    '''
    
    
    bs = NoeBitStream(bs)
    ctx = rapi.rpgCreateContext()
    bs.seek(face_ofsset)
    vert = False
    while not 0:
        if bs.getOffset() >= bs.getSize()-9:
            break
        
        bs.seek(1,1)
        size = bs.readInt()
        bs.seek(12,1)
        num = bs.readInt()
        len_attr = bs.readInt()
        
        
        if len_attr == 1:
            attr = bs.readBytes(4)

            if attr == b'\x15\x02\x01\x00':
                IBUF = bs.readBytes(size)
            elif attr == b'\x37\x04\x03\x00':
                if not vert:
                    VBUF = bs.readBytes(size)
                    rapi.rpgBindPositionBuffer(VBUF, noesis.RPGEODATA_FLOAT, 12)
                    vert = True
                else:
                    bs.seek(size,1)
            elif attr == b'\x36\x04\x03\x00':
                UVBUF = bs.readBytes(size)
                rapi.rpgBindUV1Buffer(UVBUF, noesis.RPGEODATA_FLOAT, 8)
            else:
                bs.seek(size,1)
        else:
            uv,ofs, stride = None,0, 0
            for x in range(len_attr):
                t, s, c, z = [bs.readByte() for x in range(4)]
                if t == 54: 
                    ofs = stride
                    uv = True
                stride += s*c
            if uv:
                print(stride, ofs)
                UVBUF = bs.readBytes(size)
                rapi.rpgBindUV1BufferOfs(UVBUF, noesis.RPGEODATA_FLOAT, stride, ofs)
            else:
                bs.seek(size,1)
    '''
    bs.seek(face_ofsset)
    inum = bs.readInt()
    bs.seek(8, 1)
    IBUF = bs.readBytes(inum*2)
    print(bs.getOffset())

    bs.seek(vert_ofsset)
    vnum = bs.readInt()
    bs.seek(8, 1)
    VBUF = bs.readBytes(vnum*12)
    
    #VBUF = bs.readBytes(vnum*12)
    
    
    rapi.rpgBindPositionBuffer(VBUF, noesis.RPGEODATA_FLOAT, 12)
    #rapi.rpgBindUV1BufferOfs(UVBUF, noesis.RPGEODATA_FLOAT, 12, 4)
    '''
    rapi.rpgCommitTriangles(IBUF, noesis.RPGEODATA_SHORT, len(IBUF)//2, noesis.RPGEO_TRIANGLE)
    
    mdl = rapi.rpgConstructModel()
    mdlList.append(mdl)
    return 1