﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using forgelib.Nodes;
using forgelib;

namespace forgeview
{
    public class RealDirectoryInfo : IFileSystemInfo
    {
        public int Index { get; set; }
        public int NumReadFiles { get { return 0; } }
        
        DirectoryInfo _info;

        public bool IsKnownResource { get { return false; } }
        public bool IsDirectory { get { return true; } }

        public RealDirectoryInfo(string dirName)
        {
            _info = new DirectoryInfo(dirName);
        }

        public RealDirectoryInfo(DirectoryInfo info)
        {
            _info = info;
        }
        
        public List<IFileSystemInfo> GetFilesystemInfos()
        {
            List<IFileSystemInfo> list = new List<IFileSystemInfo>();
            try
            {
                int index = 0;
                foreach (var i in _info.EnumerateDirectories())
                {
                    var rdi = new RealDirectoryInfo(i);
                    rdi.Index = index;
                    list.Add(rdi);
                    index++;
                }
                foreach (var i in _info.EnumerateFiles())
                {
                    if (Path.GetExtension(i.Name).ToLower() == ".forge")
                    {
                        try
                        {
                            ForgeFile f = new ForgeFile(i.FullName);
                            f.Index = index;
                            list.Add(f);
                            index++;
                        }
                        catch { }
                    }
                    else
                    {
                        var rfi = new RealFileInfo(i);
                        rfi.Index = index;
                        list.Add(rfi);
                        index++;
                    }
                }
            }
            catch (UnauthorizedAccessException)
            {

            }
            if (list.Count == 0) return null;
            return list;
        }

        public List<IFileSystemInfo> GetFiles()
        {
            List<IFileSystemInfo> list = new List<IFileSystemInfo>();
            try
            {
                int index = 0;
                foreach (var i in _info.EnumerateFiles())
                {
                    var rfi = new RealFileInfo(i);
                    rfi.Index = index;
                    list.Add(rfi);
                    index++;
                }
            }
            catch (UnauthorizedAccessException)
            {

            }
            if (list.Count == 0) return null;
            return list;
        }

        public List<IFileSystemInfo> GetDirectories()
        {
            List<IFileSystemInfo> list = new List<IFileSystemInfo>();
            try
            {
                int index = 0;
                foreach (var i in _info.EnumerateDirectories())
                {
                    var rdi = new RealDirectoryInfo(i);
                    rdi.Index = index;
                    list.Add(rdi);
                    index++;
                }
                foreach (var i in _info.EnumerateFiles())
                {
                    if (Path.GetExtension(i.Name).ToLower() == ".forge")
                    {
                        try
                        {
                            ForgeFile f = new ForgeFile(i.FullName);
                            f.Index = index;
                            list.Add(f);
                            index++;
                        }
                        catch { }
                    }
                }
            }
            catch (UnauthorizedAccessException)
            {

            }
            if (list.Count == 0) return null;
            return list;
        }

        public string Name
        {
            get { return _info.Name; }
        }

        public long Length
        {
            get { return -1; }
        }

        public string Type
        {
            get { return "Directory"; }
        }


        public IFileSystemInfo FindDependencyById(uint id)
        {
            return null;
        }
    }
}
