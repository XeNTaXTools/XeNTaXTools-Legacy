﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using forgelib.Nodes;
using forgelib;
using forgelib.Resources;

namespace forgeview
{
    public partial class MainForm : Form
    {
        private List<IFileSystemInfo> _list = null;
        private ListViewItem[] _lviCache = new ListViewItem[0];
        private FileSystemInfoComparer sorter;
        object lastSelected;

        public MainForm()
        {
            InitializeComponent();
            Text = string.Format("{0} - {1}", Application.ProductName, Application.ProductVersion);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Activate();

            string dir = GameDirHelper.GetGameDirectory();
            if (dir == null)
            {
                MessageBox.Show("No Game Directory found. Exiting.", "Error",  MessageBoxButtons.OK, MessageBoxIcon.Error);
                Close();
            }

            IFileSystemInfo node = new RealDirectoryInfo(dir);

            TreeNode root = new TreeNode();
            root.Tag = node;
            root.Text = node.Name;
            root.Name = node.Name;
            root.Nodes.Add(new TreeNode());

            treeView1.Nodes.Add(root);

            sorter = new FileSystemInfoComparer();
        }

        private void treeView1_BeforeExpand(object sender, TreeViewCancelEventArgs e)
        {
            if (e.Node.Nodes[0].Tag == null)
            {
                Cursor = Cursors.WaitCursor;
                e.Node.TreeView.BeginUpdate();
                e.Node.Nodes.RemoveAt(0);

                IFileSystemInfo info = (IFileSystemInfo)e.Node.Tag;
                
                foreach (var fsn in info.GetDirectories())
                {
                    TreeNode root = new TreeNode();
                    root.Tag = fsn;
                    root.Text = fsn.Name;
                    root.Name = fsn.Name;
                    root.Nodes.Add(new TreeNode());

                    if (!(fsn is RealDirectoryInfo))
                    {
                        root.SelectedImageIndex = 3;
                        root.ImageIndex = 3;
                    }
                    e.Node.Nodes.Add(root);
                }
                e.Node.TreeView.EndUpdate();
                Cursor = Cursors.Default;
            }
        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            IFileSystemInfo info = ((IFileSystemInfo)e.Node.Tag);
            
            _list = info.GetFilesystemInfos();
            
            if (_list == null || _list.Count == 0)
            {
                _lviCache = new ListViewItem[0];
                listView1.VirtualListSize = 0;
            }
            else
            {
                _lviCache = new ListViewItem[_list.Count];
                listView1.VirtualListSize = 0;
                listView1.VirtualListSize = _list.Count;
            }

            // clear old sort for performance reasons...
            if (sorter.sortColumn != -1 && sorter.sortOrder != SortOrder.None)
            {
                sorter.sortOrder = SortOrder.None;
                ListViewHelper.ShowSortIndicator(listView1, listView1.Columns[sorter.sortColumn], sorter.sortOrder);
                sorter.sortColumn = -1;
            }

            if (info.IsDirectory)
            {
                toolStripStatusLabel1.Text = string.Format("Selected: {0} Entries: {1}", info.Type, _list.Count);
            }
            else
            {
                toolStripStatusLabel1.Text = "";
            }
        }

        private void listView1_RetrieveVirtualItem(object sender, RetrieveVirtualItemEventArgs e)
        {
            if (_list != null && e.ItemIndex >= 0 && e.ItemIndex < _list.Count)
            {
                if (e.ItemIndex < _lviCache.Length && _lviCache[e.ItemIndex] != null)
                {
                    e.Item = _lviCache[e.ItemIndex];
                    if (lastSelected != null && e.Item.Tag == lastSelected)
                    {
                        e.Item.Selected = true;
                        lastSelected = null;
                    }
                    return;
                }

                if (_list[e.ItemIndex] is FileEntry)
                {
                    ((FileEntry)_list[e.ItemIndex]).ReadResourceData();
                }

                e.Item = new ListViewItem(_list[e.ItemIndex].Name);
                e.Item.Tag = _list[e.ItemIndex];

                e.Item.SubItems.Add(_list[e.ItemIndex].Type);
                e.Item.SubItems.Add(_list[e.ItemIndex].Length != -1 ? NativeMethods.StrFormatByteSize(_list[e.ItemIndex].Length) : "");

                if (_list[e.ItemIndex].IsDirectory)
                {
                    if (_list[e.ItemIndex] is RealDirectoryInfo)
                    {
                        e.Item.ImageIndex = 0;
                    }
                    else
                    {
                        e.Item.ImageIndex = 3;
                    }
                }
                else if (_list[e.ItemIndex].IsKnownResource)
                {
                    e.Item.ImageIndex = 1;
                    //e.Item.BackColor = Color.PaleGreen;
                }
                else
                {
                    e.Item.ImageIndex = 2;
                }

                _lviCache[e.ItemIndex] = e.Item;
            }
        }

        private void listView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {

            var lvi = listView1.FocusedItem;

            if (lvi != null)
            {
                if (((IFileSystemInfo)lvi.Tag).IsDirectory)
                {
                    treeView1.SelectedNode.Expand();
                    var newnode = treeView1.SelectedNode.Nodes.Find(((IFileSystemInfo)lvi.Tag).Name, false);

                    if (newnode.Length == 1)
                    {
                        treeView1.SelectedNode = newnode[0];
                    }
                }
                else
                {
                    ResourceBase res = null;

                    // get resourcebase
                    if (lvi.Tag is FileEntry)
                    {
                        var fi = (FileEntry)lvi.Tag;
                        if (fi.ResourceData != null && fi.ResourceData.Resource != null)
                        {
                            res = fi.ResourceData.Resource;
                        }
                    }
                    else if (lvi.Tag is ResourceBase)
                    {
                        res = lvi.Tag as ResourceBase;
                    }

                    // open viewer...
                    if (res != null)
                    {
                        if (res is TextureMap)
                        {
                            DDSFile dds = ((TextureMap)res).GetData() as DDSFile;
                            if (dds != null)
                            {
                                Viewer.TextureViewer frm = new Viewer.TextureViewer(dds);
                                frm.ShowDialog();
                            }
                        }
                        else if (res is LocalizationPackage)
                        {
                            CompressedLocalizationData data = ((LocalizationPackage)res).GetData() as CompressedLocalizationData;
                            if (data != null)
                            {
                                Viewer.LocalizationViewer frm = new Viewer.LocalizationViewer(data);
                                frm.ShowDialog();
                            }
                        }
                        else if (res is Mesh)
                        {
                            Mesh data = ((Mesh)res).GetData() as Mesh;
                            if (data != null)
                            {
                                Viewer.MeshViewer frm = new Viewer.MeshViewer(data);
                                frm.ShowDialog();
                            }
                        }
                        else if (res is ResourceBase)
                        {
                            object _data = ((ResourceBase)res).GetData();
                            byte[] data = _data as byte[];
                            if (data != null)
                            {
                                Viewer.HexViewer frm = new Viewer.HexViewer(data);
                                frm.ShowDialog();
                            }
                            else if (_data != null)
                            {
                                Viewer.ObjectViewer frm = new Viewer.ObjectViewer(_data);
                                frm.ShowDialog();
                            }
                        }
                    }
                }
            }
        }

        private void listView1_ColumnClick(object sender, ColumnClickEventArgs e)
        {
            if (e.Column != sorter.sortColumn)
            {
                sorter.sortOrder = SortOrder.Ascending;
                sorter.sortColumn = e.Column;
            }
            else
            {
                if (sorter.sortOrder == SortOrder.Ascending) sorter.sortOrder = SortOrder.Descending;
                else if (sorter.sortOrder == SortOrder.Descending) sorter.sortOrder = SortOrder.None;
                else sorter.sortOrder = SortOrder.Ascending;
            }

            if (listView1.SelectedIndices.Count == 1)
            {
                lastSelected = _list[listView1.SelectedIndices[0]];
            }

            //listView1.SelectedIndices.Clear();
            _list.Sort(sorter);
            listView1.VirtualListSize = 0;
            _lviCache = new ListViewItem[_list.Count];
            listView1.VirtualListSize = _list.Count;

            ListViewHelper.ShowSortIndicator(listView1, listView1.Columns[sorter.sortColumn], sorter.sortOrder);
        }

        private void listView1_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Right && listView1.FocusedItem != null)
            {
                IFileSystemInfo info = listView1.FocusedItem.Tag as IFileSystemInfo;
                if (info != null && !info.IsDirectory)
                {
                    contextMenuStrip1.Show(listView1, e.X, e.Y);
                }
            }
        }

        private string sanitizeFilename(string name)
        {
            char[] invalid = Path.GetInvalidFileNameChars();
            if (string.IsNullOrEmpty(name)) return "";
            StringBuilder sb = new StringBuilder();
            foreach (var c in name)
            {
                if (!invalid.Contains(c))
                {
                    sb.Append(c);
                }
            }
            return sb.ToString();
        }

        private void toolStripMenuItemExport_Click(object sender, EventArgs e)
        {
            var lvi = listView1.FocusedItem;

            if (lvi != null)
            {
                if (!((IFileSystemInfo)lvi.Tag).IsDirectory)
                {
                    ResourceBase res = null;

                    // get resourcebase
                    if (lvi.Tag is FileEntry)
                    {
                        var fi = (FileEntry)lvi.Tag;
                        if (fi.ResourceData != null && fi.ResourceData.Resource != null)
                        {
                            res = fi.ResourceData.Resource;
                        }
                    }
                    else if (lvi.Tag is ResourceBase)
                    {
                        res = lvi.Tag as ResourceBase;
                    }

                    if (res != null)
                    {
                        object data = res.GetData();
                        if (data != null)
                        {
                            SaveFileDialog dlg = new SaveFileDialog();
                            dlg.FileName = sanitizeFilename(res.Name);

                            if (data is DDSFile)
                            {
                                dlg.Filter = "DirectDraw Surface (*.dds)|*.dds";
                                dlg.DefaultExt = "dds";
                                if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                                {
                                    ((DDSFile)data).WriteFile(File.OpenWrite(dlg.FileName));
                                    return;
                                }
                            }
                            else if (data is CompressedLocalizationData)
                            {
                                dlg.Filter = "Text file (*.txt)|*.txt";
                                dlg.DefaultExt = "txt";
                                if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                                {
                                    ((CompressedLocalizationData)data).WriteToFile(dlg.FileName);
                                    return;
                                }
                            }
                            if (res is FireData)
                            {
                                dlg.Filter = "Flash Movie (*.swf)|*.swf";
                                dlg.DefaultExt = "swf";
                            }
                            else
                            {
                                dlg.Filter = "*.dat|Unknown";
                                dlg.DefaultExt = "dat";
                            }
                            
                            if (data is byte[])
                            {
                                if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                                {
                                    File.WriteAllBytes(dlg.FileName, (byte[])data);
                                }
                            }
                        }
                    }
                }
            }
        }

        private void listView1_SearchForVirtualItem(object sender, SearchForVirtualItemEventArgs e)
        {
            if (_list != null && e.StartIndex >= 0 && e.StartIndex <= _list.Count)
            {
                for (int i = e.StartIndex; i < _list.Count; i++)
                {
                    if (e.IsPrefixSearch)
                    {
                        if (_list[i].Name.IndexOf(e.Text, StringComparison.InvariantCultureIgnoreCase) >= 0)
                        {
                            e.Index = i;
                            return;
                        }
                    }
                    else
                    {
                        if (_list[i].Name.StartsWith(e.Text, StringComparison.InvariantCultureIgnoreCase))
                        {
                            e.Index = i;
                            return;
                        }
                    }
                }
            }
        }

        private void toolStripTextBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = doSearch();
                e.Handled = true;
            }
        }

        private bool doSearch()
        {
            bool handled = false;
            if (!string.IsNullOrEmpty(toolStripTextBox1.Text))
            {
                int startIndex = 0;
                if (listView1.SelectedIndices.Count == 1)
                {
                    startIndex = listView1.SelectedIndices[0];
                }

                var lvi = listView1.FindItemWithText(toolStripTextBox1.Text, false, startIndex + 1, true);
                if (lvi != null)
                {
                    listView1.FocusedItem = lvi;
                    lvi.Selected = true;
                    lvi.EnsureVisible();
                    handled = true;
                }
            }
            return handled;
        }
    }
}
