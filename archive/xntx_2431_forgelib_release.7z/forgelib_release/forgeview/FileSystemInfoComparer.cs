﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using forgelib.Nodes;
using System.Windows.Forms;
using forgelib;

namespace forgeview
{
    public class FileSystemInfoComparer : IComparer<IFileSystemInfo>
    {
        public int sortColumn = -1;
        public SortOrder sortOrder;
        
        public int Compare(IFileSystemInfo x, IFileSystemInfo y)
        {
            int dir = 0;
            if (sortOrder == SortOrder.Ascending) dir = 1;
            else if (sortOrder == SortOrder.Descending) dir = -1;

            if (dir == 0) return x.Index.CompareTo(y.Index);

            switch (sortColumn)
            { 
                case 0:
                    //return x.Name.CompareTo(y.Name) * dir;
                    return string.Compare(x.Name, y.Name, true) * dir;

                case 1:
                    return x.Type.CompareTo(y.Type) * dir;

                case 2:
                    return x.Length.CompareTo(y.Length) * dir;
                
                default:
                    return x.Index.CompareTo(y.Index);
            }
        }
    }
}
