using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Drawing;

namespace forgeview {
    public static class ListViewHelper {
        private const string SORT_INDICATOR_UP_KEY = "sort-indicator-up";
        private const string SORT_INDICATOR_DOWN_KEY = "sort-indicator-down";

        public static void SelectAllItems( ListView list ) {
            NativeMethods.SetItemState( list, -1, 2, 2 );
        }

        public static void DeselectAllItems( ListView list ) {
            NativeMethods.SetItemState( list, -1, 2, 0 );
        }

        public static void ShowSortIndicator( ListView lv, ColumnHeader columnToSort, SortOrder sortOrder ) {
            int imageIndex = -1;

            if ( !NativeMethods.HasBuiltinSortIndicators()) {
                // If we can't use builtin image, we have to make and then locate the index of the
                // sort indicator we want to use. SortOrder.None doesn't show an image.
                if ( lv.SmallImageList == null || !lv.SmallImageList.Images.ContainsKey( SORT_INDICATOR_UP_KEY ) )
                    lv.SmallImageList = MakeSortIndicatorImages(lv.SmallImageList);

                if ( sortOrder == SortOrder.Ascending )
                    imageIndex = lv.SmallImageList.Images.IndexOfKey( SORT_INDICATOR_UP_KEY );
                else if ( sortOrder == SortOrder.Descending )
                    imageIndex = lv.SmallImageList.Images.IndexOfKey( SORT_INDICATOR_DOWN_KEY );
            }

            // Set the image for each column
            for ( int i = 0; i < lv.Columns.Count; i++ ) {
                if ( i == columnToSort.Index )
                    NativeMethods.SetColumnImage( lv, i, sortOrder, imageIndex );
                else
                    NativeMethods.SetColumnImage( lv, i, SortOrder.None, -1 );
            }
        }

        private static Bitmap MakeTriangleBitmap( Size sz, Point[] pts ) {
            Bitmap bm = new Bitmap( sz.Width, sz.Height );
            Graphics g = Graphics.FromImage( bm );
            g.FillPolygon( SystemBrushes.ControlLight, pts );
            g.DrawPolygon(SystemPens.ControlDark, pts);
            return bm;
        }

        private static ImageList MakeSortIndicatorImages( ImageList il ) {
            if ( il == null ) {
                il = new ImageList();
                il.ImageSize = new Size( 16, 16 );
            }

            // This arrangement of points works well with (16,16) images, and OK with others
            int midX = il.ImageSize.Width / 2;
            int midY = ( il.ImageSize.Height / 2 ) - 1;
            int deltaX = midX - 2;
            int deltaY = deltaX / 2;

            if ( il.Images.IndexOfKey( SORT_INDICATOR_UP_KEY ) == -1 ) {
                Point pt1 = new Point( midX - deltaX, midY + deltaY );
                Point pt2 = new Point( midX, midY - deltaY - 1 );
                Point pt3 = new Point( midX + deltaX, midY + deltaY );
                il.Images.Add( SORT_INDICATOR_UP_KEY, MakeTriangleBitmap( il.ImageSize, new Point[] { pt1, pt2, pt3 } ) );
            }

            if ( il.Images.IndexOfKey( SORT_INDICATOR_DOWN_KEY ) == -1 ) {
                Point pt1 = new Point( midX - deltaX, midY - deltaY );
                Point pt2 = new Point( midX, midY + deltaY );
                Point pt3 = new Point( midX + deltaX, midY - deltaY );
                il.Images.Add( SORT_INDICATOR_DOWN_KEY, MakeTriangleBitmap( il.ImageSize, new Point[] { pt3, pt1, pt2 } ) );
            }

            return il;
        }

        internal class NativeMethods {
            private const int LVM_FIRST = 0x1000;
            private const int LVM_GETHEADER = LVM_FIRST + 31;
            private const int LVM_SETITEMSTATE = LVM_FIRST + 43;

            private const int HDM_FIRST = 0x1200;
            private const int HDM_GETITEM = HDM_FIRST + 11;
            private const int HDM_SETITEM = HDM_FIRST + 12;

            private const int HDI_FORMAT = 0x0004;
            private const int HDI_IMAGE = 0x0020;

            private const int HDF_BITMAP = 0x2000;
            private const int HDF_SORTUP = 0x0400;
            private const int HDF_SORTDOWN = 0x0200;
            private const int HDF_IMAGE = 0x0800;
            private const int HDF_BITMAP_ON_RIGHT = 0x1000;

            [DllImport( "user32.dll", CharSet = CharSet.Auto )]
            public static extern IntPtr SendMessage( IntPtr hWnd, int msg, int wParam, int lParam );
            [DllImport( "user32.dll", EntryPoint = "SendMessage", CharSet = CharSet.Auto )]
            private static extern IntPtr SendMessageHDItem( IntPtr hWnd, int msg, int wParam, ref HDITEM hdi );            
            [DllImport( "user32.dll", EntryPoint = "SendMessage", CharSet = CharSet.Auto )]
            private static extern IntPtr SendMessageLVItem( IntPtr hWnd, int msg, int wParam, ref LVITEM lvi );

            [StructLayout( LayoutKind.Sequential )]
            public struct HDITEM {
                public int mask;
                public int cxy;
                public IntPtr pszText;
                public IntPtr hbm;
                public int cchTextMax;
                public int fmt;
                public IntPtr lParam;
                public int iImage;
                public int iOrder;
                //if (_WIN32_IE >= 0x0500)
                public int type;
                public IntPtr pvFilter;
            }

            [StructLayout( LayoutKind.Sequential, CharSet = CharSet.Auto )]
            private struct LVITEM {
                public int mask;
                public int iItem;
                public int iSubItem;
                public int state;
                public int stateMask;
                [MarshalAs( UnmanagedType.LPTStr )]
                public string pszText;
                public int cchTextMax;
                public int iImage;
                public IntPtr lParam;
                // These are available in Common Controls >= 0x0300
                public int iIndent;
                // These are available in Common Controls >= 0x056
                public int iGroupId;
                public int cColumns;
                public IntPtr puColumns;
            };

            public static IntPtr GetHeaderControl( ListView list ) {
                return SendMessage( list.Handle, LVM_GETHEADER, 0, 0 );
            }

            public static void SetItemState( ListView list, int itemIndex, int mask, int value ) {
                LVITEM lvItem = new LVITEM();
                lvItem.stateMask = mask;
                lvItem.state = value;
                SendMessageLVItem( list.Handle, LVM_SETITEMSTATE, itemIndex, ref lvItem );
            }

            public static bool HasBuiltinSortIndicators() {
                return (Application.RenderWithVisualStyles) && (OSFeature.Feature.GetVersionPresent( OSFeature.Themes ) != null);
            }
            
            public static void SetColumnImage( ListView list, int columnIndex, SortOrder order, int imageIndex ) {
                IntPtr hdrCntl = NativeMethods.GetHeaderControl( list );
                if ( hdrCntl.ToInt32() == 0 )
                    return;

                HDITEM item = new HDITEM();
                item.mask = HDI_FORMAT;
                IntPtr result = SendMessageHDItem( hdrCntl, HDM_GETITEM, columnIndex, ref item );

                item.fmt &= ~( HDF_SORTUP | HDF_SORTDOWN | HDF_IMAGE | HDF_BITMAP_ON_RIGHT );

                if ( NativeMethods.HasBuiltinSortIndicators() ) {
                    if ( order == SortOrder.Ascending )
                        item.fmt |= HDF_SORTUP;
                    if ( order == SortOrder.Descending )
                        item.fmt |= HDF_SORTDOWN;
                } else {
                    item.mask |= HDI_IMAGE;
                    item.fmt |= ( HDF_IMAGE | HDF_BITMAP_ON_RIGHT );
                    item.iImage = imageIndex;
                }

                result = SendMessageHDItem( hdrCntl, HDM_SETITEM, columnIndex, ref item );
            }
        }


    }
}
