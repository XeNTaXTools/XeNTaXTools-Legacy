﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using forgelib.Nodes;

namespace forgeview
{
    public class RealFileInfo : IFileSystemInfo
    {
        public int Index { get; set; }
        public int NumReadFiles { get { return 0; } }
        
        FileInfo _info;

        public RealFileInfo(FileInfo info)
        {
            _info = info;
        }
        
        public string Name
        {
            get { return _info.Name; }
        }

        public long Length
        {
            get { return _info.Length; }
        }

        public string Type
        {
            get { return "File"; }
        }

        public bool IsKnownResource { get { return false; } }

        public bool IsDirectory
        {
            get { return false; }
        }


        public List<IFileSystemInfo> GetFiles()
        {
            throw new NotImplementedException();
        }

        public List<IFileSystemInfo> GetFilesystemInfos()
        {
            throw new NotImplementedException();
        }

        public List<IFileSystemInfo> GetDirectories()
        {
            throw new NotImplementedException();
        }


        public IFileSystemInfo FindDependencyById(uint id)
        {
            return null;
        }
    }
}
