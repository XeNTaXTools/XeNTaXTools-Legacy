﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using forgelib.Resources;

namespace forgeview.Viewer
{
    public partial class LocalizationViewer : Form
    {
        public LocalizationViewer(CompressedLocalizationData data)
        {
            InitializeComponent();
            foreach(var st in data.StringTables)
            {
                listBox1.Items.Add(st);
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            listView1.Items.Clear();
            
            if (listBox1.SelectedItem != null)
            {
                CompressedLocalizationData.StringTableEntryCollection table = listBox1.SelectedItem as CompressedLocalizationData.StringTableEntryCollection;
                if (table != null)
                {
                    foreach (var et in table.Entries)
                    {
                        ListViewItem lvi = new ListViewItem();
                        lvi.Tag = et;
                        lvi.Text = string.Format("0x{0:x8}", et.Id);
                        lvi.SubItems.Add(et.DecodedString);

                        listView1.Items.Add(lvi);
                    }
                }
            }
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            label3.Text = "";
            if (listView1.SelectedItems != null && listView1.SelectedItems.Count == 1)
            {
                CompressedLocalizationData.StringTableEntry entry = listView1.SelectedItems[0].Tag as CompressedLocalizationData.StringTableEntry;
                if (entry != null)
                {
                    label3.Text = entry.DecodedString;
                }
            }
        }
    }
}
