﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using forgelib.Resources;
using System.Windows.Media.Media3D;
using System.Windows.Media;

namespace forgeview.Viewer
{
    public partial class MeshViewer : Form
    {
        double positionQuant = 2048f;
        double uvQuant = 2048f;
        private Mesh mesh;

        public MeshViewer(Mesh mesh)
        {
            InitializeComponent();

            this.mesh = mesh;
            updateModel();
        }

        private void updateModel()
        {
            //var possibleTextures = ModelGenerator.GetPossibleTextures(mesh);
            model3DView1.Model = ModelGenerator.GetModel(mesh, positionQuant, uvQuant);
        }
    }
}
