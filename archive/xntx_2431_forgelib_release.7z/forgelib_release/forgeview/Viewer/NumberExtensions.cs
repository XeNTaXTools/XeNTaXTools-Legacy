﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace forgeview.Viewer
{
    public static class NumberExtensions
    {
        public static Int64 Swap(this Int64 value)
        {
            byte[] buf = BitConverter.GetBytes(value);
            return BitConverter.ToInt64(buf.Reverse().ToArray(), 0);
        }
        
        public static Int32 Swap(this Int32 value)
        {
            byte[] buf = BitConverter.GetBytes(value);
            return BitConverter.ToInt32(buf.Reverse().ToArray(), 0);
        }

        public static Int16 Swap(this Int16 value)
        {
            byte[] buf = BitConverter.GetBytes(value);
            return BitConverter.ToInt16(buf.Reverse().ToArray(), 0);
        }

        public static UInt64 Swap(this UInt64 value)
        {
            byte[] buf = BitConverter.GetBytes(value);
            return BitConverter.ToUInt64(buf.Reverse().ToArray(), 0);
        }

        public static UInt32 Swap(this UInt32 value)
        {
            byte[] buf = BitConverter.GetBytes(value);
            return BitConverter.ToUInt32(buf.Reverse().ToArray(), 0);
        }

        public static UInt16 Swap(this UInt16 value)
        {
            byte[] buf = BitConverter.GetBytes(value);
            return BitConverter.ToUInt16(buf.Reverse().ToArray(), 0);
        }

        public static Single Swap(this Single value)
        {
            byte[] buf = BitConverter.GetBytes(value);
            return BitConverter.ToSingle(buf.Reverse().ToArray(), 0);
        }

        public static Double Swap(this Double value)
        {
            byte[] buf = BitConverter.GetBytes(value);
            return BitConverter.ToDouble(buf.Reverse().ToArray(), 0);
        }
    }

}