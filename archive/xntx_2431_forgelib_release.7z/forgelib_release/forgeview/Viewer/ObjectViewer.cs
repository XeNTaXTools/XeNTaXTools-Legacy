﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace forgeview.Viewer
{
    public partial class ObjectViewer : Form
    {
        public ObjectViewer(object obj)
        {
            InitializeComponent();

            propertyGrid1.SelectedObject = obj;
        }
    }
}
