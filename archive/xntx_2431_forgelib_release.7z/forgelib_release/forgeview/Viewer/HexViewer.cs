﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace forgeview.Viewer
{
    public partial class HexViewer : Form
    {
        [TypeConverter(typeof(ExpandableObjectConverter))]
        private class HexDisplay
        {
            private bool bigEndian;
            private byte[] data;

            public int offset;

            [DisplayName("byte")]
            public string _Byte
            {
                get
                {
                    if (offset >= 0 && offset < data.Length)
                    {
                        return data[offset].ToString();
                    }
                    return "";
                }
                set { }
            }
            public bool ShouldSerialize_Byte() { return false; }

            [DisplayName("sbyte")]
            public string _SByte
            {
                get
                {
                    if (offset >= 0 && offset < data.Length)
                    {
                        return ((sbyte)data[offset]).ToString();
                    }
                    return "";
                }
                set { }
            }
            public bool ShouldSerialize_SByte() { return false; }

            [DisplayName("int16")]
            public string _Int16
            {
                get
                {
                    if (offset >= 0 && offset < data.Length - 1)
                    {
                        short value = BitConverter.ToInt16(data, offset);
                        if (bigEndian) value = value.Swap();
                        return value.ToString();
                    }
                    return "";
                }
                set { }
            }
            public bool ShouldSerialize_Int16() { return false; }

            [DisplayName("uint16")]
            public string _UInt16
            {
                get
                {
                    if (offset >= 0 && offset < data.Length - 1)
                    {
                        ushort value = BitConverter.ToUInt16(data, offset);
                        if (bigEndian) value = value.Swap();
                        return value.ToString();
                    }
                    return "";
                }
                set { }
            }
            public bool ShouldSerialize_UInt16() { return false; }

            [DisplayName("int32")]
            public string _Int32
            {
                get
                {
                    if (offset >= 0 && offset < data.Length - 3)
                    {
                        int value = BitConverter.ToInt32(data, offset);
                        if (bigEndian) value = value.Swap();
                        return value.ToString();
                    }
                    return "";
                }
                set { }
            }
            public bool ShouldSerialize_Int32() { return false; }

            [DisplayName("uint32")]
            public string _UInt32
            {
                get
                {
                    if (offset >= 0 && offset < data.Length - 3)
                    {
                        uint value = BitConverter.ToUInt32(data, offset);
                        if (bigEndian) value = value.Swap();
                        return value.ToString();
                    }
                    return "";
                }
                set { }
            }
            public bool ShouldSerialize_UInt32() { return false; }

            [DisplayName("int64")]
            public string _Int64
            {
                get
                {
                    if (offset >= 0 && offset < data.Length - 7)
                    {
                        long value = BitConverter.ToInt64(data, offset);
                        if (bigEndian) value = value.Swap();
                        return value.ToString();
                    }
                    return "";
                }
                set { }
            }
            public bool ShouldSerialize_Int64() { return false; }

            [DisplayName("uint64")]
            public string _UInt64
            {
                get
                {
                    if (offset >= 0 && offset < data.Length - 7)
                    {
                        ulong value = BitConverter.ToUInt64(data, offset);
                        if (bigEndian) value = value.Swap();
                        return value.ToString();
                    }
                    return "";
                }
                set { }
            }
            public bool ShouldSerialize_UInt64() { return false; }

            [DisplayName("float")]
            public string _Single
            {
                get
                {
                    if (offset >= 0 && offset < data.Length - 3)
                    {
                        float value = BitConverter.ToSingle(data, offset);
                        if (bigEndian) value = value.Swap();
                        return value.ToString();
                    }
                    return "";
                }
                set { }
            }
            public bool ShouldSerialize_Single() { return false; }

            [DisplayName("double")]
            public string _Double
            {
                get
                {
                    if (offset >= 0 && offset < data.Length - 7)
                    {
                        double value = BitConverter.ToDouble(data, offset);
                        if (bigEndian) value = value.Swap();
                        return value.ToString();
                    }
                    return "";
                }
                set { }
            }
            public bool ShouldSerialize_Double() { return false; }

            [DisplayName("time_t")]
            public string _time_t
            {
                get 
                {
                    if (offset >= 0 && offset < data.Length - 3)
                    {
                        int value = BitConverter.ToInt32(data, offset);
                        if (bigEndian) value = value.Swap();

                        return new DateTime(1970, 1, 1).AddSeconds(value).ToString();
                    }
                    return "";
                }
                set { }
            }
            public bool ShouldSerialize_time_t() { return false; }
            

            public HexDisplay(byte[] data, bool bigendian)
            {
                bigEndian = bigendian;
                this.data = data;
            
            }
        
        }
        
        
        private byte[] data;
        private int bytesPerLine = 16;
        private long currentLine;
        private long positionInLine;
        private int offset
        {
            get
            {
                return (int)(currentLine * bytesPerLine + positionInLine);
            }
        }

        private HexDisplay displayLittleEndian;
        private HexDisplay displayBigEndian;

        public HexViewer(byte[] data)
        {
            this.data = data;
            InitializeComponent();

            hexBox1.BytesPerLine = bytesPerLine;
            hexBox1.ByteProvider = new Be.Windows.Forms.DynamicByteProvider(data);

            initDisplay();
            toolStripStatusLabel2.Text = string.Format("Length: {0}", data.Length);
            toolStripStatusLabel3.Text = "";
        }


        private void hexBox1_CurrentLineChanged(object sender, EventArgs e)
        {
            currentLine = hexBox1.CurrentLine - 1;
            updateOffset();
        }

        private void hexBox1_CurrentPositionInLineChanged(object sender, EventArgs e)
        {
            positionInLine = hexBox1.CurrentPositionInLine - 1;
            updateOffset();
        }

        void initDisplay()
        {
            if (displayLittleEndian == null) displayLittleEndian = new HexDisplay(data, false);
            if (displayBigEndian == null) displayBigEndian = new HexDisplay(data, true);
        }

        void updateOffset()
        {
            initDisplay();

            toolStripStatusLabel1.Text = string.Format("Offset: {0} ({0:x8}h)", offset);
            


            displayLittleEndian.offset = offset;
            displayBigEndian.offset = offset;
            if (propertyGrid1.SelectedObject == null) propertyGrid1.SelectedObject = displayLittleEndian;
            else propertyGrid1.Refresh();
            if (propertyGrid2.SelectedObject == null) propertyGrid2.SelectedObject = displayBigEndian;
            else propertyGrid2.Refresh();
        }

        private void hexBox1_SelectionLengthChanged(object sender, EventArgs e)
        {
            if (hexBox1.SelectionLength != 0) toolStripStatusLabel3.Text = string.Format("Selected: {0}", hexBox1.SelectionLength);
            else toolStripStatusLabel3.Text = "";
        }

        private void hexBox1_Leave(object sender, EventArgs e)
        {
            if(offset >= 0 && offset < data.Length) hexBox1.Select(offset, 1);
        }
    }
}
