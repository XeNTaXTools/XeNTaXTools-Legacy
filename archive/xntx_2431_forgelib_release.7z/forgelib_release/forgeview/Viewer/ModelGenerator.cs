﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Media.Media3D;
using forgelib.Resources;
using System.Windows.Media;
using forgelib.Resources.Geometry;

namespace forgeview.Viewer
{
    class ModelGenerator
    {
        static uint[] DefaultColorCodes = new uint[]
        {
            0xffffffff,
            0xffff7f7f,
            0xff7fff7f,
            0xff7f7fff,
            0xffffff7f,
            0xffff7fff,
            0xff7fffff,
            0xff7f7f7f,
            0xfff99f99,
            0xff99ff99,
            0xff9999ff,
            0xffffff99,
            0xffff99ff,
            0xff99ffff,
            0xff999999
        };

        public static List<Dictionary<string, TextureMap>> GetPossibleTextures(Mesh mesh)
        {
            List<Dictionary<string, TextureMap>> list = new List<Dictionary<string, TextureMap>>();
            for (int i = 0; i < mesh.primitives1.Length; i++)
            {
                Dictionary<string, TextureMap> tex = new Dictionary<string, TextureMap>();
                var instancingdata = mesh.meshInstancingData[i];
                if (instancingdata.Material.Type != 3)
                {
                    var matdep = mesh.Materials[i];
                    if (matdep != null)
                    {
                        var matres = matdep.Resource as forgelib.Resources.Material;
                        if (matres != null)
                        {
                            if (!matres.IsLoaded) matres.Load();
                            foreach (var param in matres.Parameters)
                            {
                                if (param is forgelib.Resources.Material.TextureSelector)
                                {
                                    var texSel = param as forgelib.Resources.Material.TextureSelector;
                                    if (texSel.TextureMapDependency.Resource != null)
                                    {
                                        var texmapres = texSel.TextureMapDependency.Resource as TextureMap;
                                        if (texmapres != null)
                                        {
                                            if (texmapres.Name != null &&
                                                texmapres.Name != "" &&
                                                !tex.ContainsKey(texmapres.Name)) tex.Add(texmapres.Name, texmapres);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                list.Add(tex);
            }
            return list;
        }

        public static Model3D GetModel(Mesh mesh, double positionQuant, double uvQuant)
        {
            if(mesh.primitives1 == null || mesh.primitives1.Length == 0) return null;

            Model3DGroup group = new Model3DGroup();

            var materials = GetPossibleTextures(mesh);

            for(int i = 0; i < mesh.primitives1.Length; i++)
            {
                System.Windows.Media.Media3D.Material material = null;
                
                var primitive = mesh.primitives1[i];
                int start = primitive.StartVert;
                int end = start + primitive.NumVerts;

                #region ....stupid way of finding a suitable texture....
                TextureMap diffuse = null;
                if(i < materials.Count)
                {
                    Dictionary<string, TextureMap> textures = materials[i];
                    foreach(string key in textures.Keys)
                    {
                        if(key.IndexOf("Diffuse") >= 0)
                        {
                            diffuse = textures[key];
                            break;
                        }
                    }
                }

                if (diffuse != null)
                {
                    var dds = diffuse.GetData() as DDSFile;
                    if (dds != null)
                    {
                        var bmp = GetBitmap(dds);
                        if (bmp != null)
                        {
                            material = new DiffuseMaterial(CreateDefaultTexmap(bmp, 0));

                        }
                    }
                }
                if (material == null)
                {
                    material = new DiffuseMaterial(CreateDefaultTexmap(null, i));
                }
                #endregion

                MeshGeometry3D geo = new MeshGeometry3D();

                #region verts
                for (int j = start; j < end; j++)
                {
                    var p = mesh.VertexBuffer.GetElement(VertexBufferAccess.Semantic.Position, j);
                    var n = mesh.VertexBuffer.GetElement(VertexBufferAccess.Semantic.Normal, j);
                    var uv = mesh.VertexBuffer.GetElement(VertexBufferAccess.Semantic.UV0, j);

                    geo.Positions.Add(new Point3D(p.X, p.Y, p.Z));
                    geo.Normals.Add(new Vector3D(n.X, n.Y, n.Z));
                    geo.TextureCoordinates.Add(new System.Windows.Point(uv.X, uv.Y));
                }
                #endregion

                int indexStart = primitive.StartIndex;
                int indexEnd = primitive.NumFaces * 3 + indexStart;

                for (int j = indexStart; j < indexEnd; j++)
                {
                    geo.TriangleIndices.Add(mesh.indexBuffer[j] - primitive.StartVert);
                }
                var model3D = new GeometryModel3D(geo, material);
                group.Children.Add(model3D);
            }

            return group;
        }

        internal static Brush CreateDefaultTexmap(System.Drawing.Bitmap bmp, int index)
        {
            if (bmp == null)
            {
                bmp = new System.Drawing.Bitmap(512, 512);
                var g = System.Drawing.Graphics.FromImage(bmp);

                int colorIndex = index % DefaultColorCodes.Length;
                System.Drawing.Color backColor = System.Drawing.Color.FromArgb((int)DefaultColorCodes[colorIndex]);
                g.Clear(backColor);
                var pen = new System.Drawing.Pen(System.Drawing.Color.Red);

                for (var x = 0; x < 512; x += 16)
                {
                    g.DrawLine(pen, 0, x, bmp.Width, x);
                }
                for (var x = 0; x < 512; x += 16)
                {
                    g.DrawLine(pen, x, 0, x, bmp.Height);
                }

                g.Dispose();
            }

            var bitmapSource = System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(
                bmp.GetHbitmap(),
                IntPtr.Zero,
                System.Windows.Int32Rect.Empty,
                System.Windows.Media.Imaging.BitmapSizeOptions.FromEmptyOptions());

            // For memory leak work around
            bitmapSource.Freeze();

            Brush brush = new ImageBrush(bitmapSource);
            (brush as ImageBrush).ViewportUnits = BrushMappingMode.Absolute;
            (brush as ImageBrush).TileMode = TileMode.Tile;

            bmp.Dispose();

            return brush;
        }

        static System.Drawing.Bitmap GetBitmap(DDSFile dds)
        {
            byte[] compBuffer = dds.GetFirstMipData();
            byte[] outbuffer = null;
            switch (dds.header.sPixelFormat.dwFourCC)
            {
                case DDSFile.FOUR_CC.DXT1:
                    DXTTools.FOUR_CC fourcc = DXTTools.FOUR_CC.DXT1;
                    if ((dds.header.sPixelFormat.dwFlags & DDSFile.DDPF_FLAGS.DDPF_ALPHAPIXELS) == DDSFile.DDPF_FLAGS.DDPF_ALPHAPIXELS)
                    {
                        fourcc = DXTTools.FOUR_CC.DXT1A;
                    }
                    outbuffer = DXTTools.DecompressImage(false, dds.header.dwWidth, dds.header.dwHeight, compBuffer, fourcc);
                    break;
                case DDSFile.FOUR_CC.DXT3:
                    outbuffer = DXTTools.DecompressImage(false, dds.header.dwWidth, dds.header.dwHeight, compBuffer, DXTTools.FOUR_CC.DXT3);
                    break;
                case DDSFile.FOUR_CC.DXT5:
                    outbuffer = DXTTools.DecompressImage(false, dds.header.dwWidth, dds.header.dwHeight, compBuffer, DXTTools.FOUR_CC.DXT5);
                    break;
                case DDSFile.FOUR_CC.None:
                    if ((dds.header.sPixelFormat.dwFlags & DDSFile.DDPF_FLAGS.DDPF_RGB) == DDSFile.DDPF_FLAGS.DDPF_RGB
                        && dds.header.sPixelFormat.dwRGBBitCount == 32)
                    {
                        outbuffer = compBuffer;
                    }
                    else if ((dds.header.sPixelFormat.dwFlags & DDSFile.DDPF_FLAGS.DDPF_RGB) != DDSFile.DDPF_FLAGS.DDPF_RGB &&
                        (dds.header.sPixelFormat.dwFlags & DDSFile.DDPF_FLAGS.DDPF_ALPHAPIXELS) == DDSFile.DDPF_FLAGS.DDPF_ALPHAPIXELS
                        && dds.header.sPixelFormat.dwRGBBitCount == 8)
                    {
                        outbuffer = new byte[compBuffer.Length * 4];
                        for (int i = 0; i < compBuffer.Length; i++)
                        {
                            outbuffer[i * 4 + 3] = compBuffer[i];
                        }
                    }
                    else
                    {
                        throw new NotSupportedException();
                    }
                    break;
            }

            if (outbuffer != null)
            {
                System.Drawing.Imaging.PixelFormat format = System.Drawing.Imaging.PixelFormat.Format32bppArgb;
                System.Drawing.Bitmap bmp = new System.Drawing.Bitmap((int)dds.header.dwWidth, (int)dds.header.dwHeight, format);
                System.Drawing.Imaging.BitmapData data = bmp.LockBits(new System.Drawing.Rectangle(0, 0, bmp.Width, bmp.Height), System.Drawing.Imaging.ImageLockMode.ReadWrite, format);
                System.Runtime.InteropServices.Marshal.Copy(outbuffer, 0, data.Scan0, outbuffer.Length);
                bmp.UnlockBits(data);

                return bmp;
            }

            return null;
        }    
    }
}
