/* Portions copied from the squish library:
 * http://sjbrown.co.uk/?code=squish
 * licence below...
/* -----------------------------------------------------------------------------

	Copyright (c) 2006 Simon Brown                          si@sjbrown.co.uk
	Copyright (c) 2007 Ignacio Castano                   icastano@nvidia.com

	Permission is hereby granted, free of charge, to any person obtaining
	a copy of this software and associated documentation files (the 
	"Software"), to	deal in the Software without restriction, including
	without limitation the rights to use, copy, modify, merge, publish,
	distribute, sublicense, and/or sell copies of the Software, and to 
	permit persons to whom the Software is furnished to do so, subject to 
	the following conditions:

	The above copyright notice and this permission notice shall be included
	in all copies or substantial portions of the Software.

	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
	OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF 
	MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
	IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY 
	CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, 
	TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
	SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
	
   -------------------------------------------------------------------------- */


using System;

namespace forgeview.Viewer
{
    public static class DXTTools
    {

        public enum FOUR_CC
        {
            DXT1,
            DXT1A,
            DXT3,
            DXT5,
        }

        public static void DecompressAlphaDxt3(byte[] rgba, byte[] block, int srcOffset)
        {
            // unpack the alpha values pairwise
            for (int i = 0; i < 8; i++)
            {
                // quantise down to 4 bits
                byte quant = block[(srcOffset + i)];

                // unpack the values
                byte lo = (byte)(quant & 0x0f);
                byte hi = (byte)(quant & 0xf0);

                // convert back up to bytes
                rgba[8 * i + 3] = (byte)(lo | (lo << 4));
                rgba[8 * i + 7] = (byte)(hi | (hi >> 4));
            }
        }

        public static void DecompressDxt5Alpha(byte[] rgba, byte[] block, int sourceOffset, int numTargetChannels, int channelOffset)
        {

            // get the two alpha values
            int alpha0 = block[sourceOffset];
            int alpha1 = block[sourceOffset + 1];

            // compare the values to build the codebook
            byte[] codes = new byte[8];
            codes[0] = (byte)alpha0;
            codes[1] = (byte)alpha1;

            if (alpha0 <= alpha1)
            {
                // use 5-alpha codebook

                for (int j = 1; j < 5; j++)
                {
                    codes[(j + 1)] = (byte)Math.Round(((5 - j) * alpha0 + j * alpha1) / 5f);
                }
                codes[6] = 0;
                codes[7] = 255;
            }
            else
            {
                // use 7-alpha codebook
                for (int j = 1; j < 7; j++)
                {
                    codes[(j + 1)] = (byte)Math.Round(((7 - j) * alpha0 + j * alpha1) / 7f);
                }
            }

            // decode the indices
            byte[] indices = new byte[16];
            int src = sourceOffset + 2;
            int dest = 0;
            for (int j = 0; j < 2; j++)
            {
                // grab 3 bytes
                int value = 0;

                for (int k = 0; k < 3; k++)
                {
                    int _byte = block[src];
                    src++;
                    int shift = 8 * k;
                    int shifted = _byte << shift;
                    value = value | shifted;
                }

                // unpack 8 3-bit values from it
                for (int k = 0; k < 8; k++)
                {
                    int shift = 3 * k;
                    int shifted = value >> shift;
                    int index = shifted & 0x7;
                    indices[dest] = (byte)index;
                    dest++;
                }
            }

            // write out the indexed codebook values
            for (int j = 0; j < 16; j++)
            {
                rgba[numTargetChannels * j + channelOffset] = codes[indices[j]];
            }
        }

        public static int Unpack565(byte[] packed, int pidx, byte[] color, int cidx)
        {
            // build the packed value
            int value = (int)packed[pidx] | ((int)packed[(pidx + 1)] << 8);

            // get the components in the stored range
            byte blue = (byte)((value >> 11) & 0x1f);
            byte green = (byte)((value >> 5) & 0x3f);
            byte red = (byte)(value & 0x1f);

            // scale up to 8 bits
            color[(cidx + 0)] = (byte)((blue << 3) | (blue >> 2));
            color[(cidx + 1)] = (byte)((green << 2) | (green >> 4));
            color[(cidx + 2)] = (byte)((red << 3) | (red >> 2));
            color[(cidx + 3)] = 255;

            // return the value
            return value;
        }

        public static void DecompressColor(byte[] bgra, byte[] block, int srcOffset, bool isDxt1a)
        {
            // unpack the endpoints
            byte[] codes = new byte[16];

            int a = Unpack565(block, srcOffset + 0, codes, 0);
            int b = Unpack565(block, srcOffset + 2, codes, 4);

            // generate the midpoints
            for (int i = 0; i < 3; i++)
            {
                int c = codes[i];
                int d = codes[(4 + i)];

                if (isDxt1a && a <= b)
                {
                    codes[8 + i] = (byte)Math.Round(((double)c + (double)d) / 2d);
                    codes[12 + i] = 0;
                }
                else
                {
                    codes[8 + i] = (byte)Math.Round((2d * (double)c + (double)d) / 3d);
                    codes[12 + i] = (byte)Math.Round(((double)c + 2d * (double)d) / 3d);
                }
            }

            // fill in alpha for the intermediate values
            codes[8 + 3] = 255;
            codes[12 + 3] = (byte)((isDxt1a && a <= b) ? 0 : 255);

            // unpack the indices
            byte[] indices = new byte[16];
            for (int i = 0; i < 4; i++)
            {
                int ind = 4 * i;
                byte packed = block[(srcOffset + 4 + i)];

                indices[ind] = (byte)(packed & 0x3);
                indices[(ind + 1)] = (byte)((packed >> 2) & 0x3);
                indices[(ind + 2)] = (byte)((packed >> 4) & 0x3);
                indices[(ind + 3)] = (byte)((packed >> 6) & 0x3);
            }

            // store out the colours
            for (int i = 0; i < 16; i++)
            {
                byte offset = (byte)(4 * indices[i]);
                for (int j = 0; j < 4; j++)
                    bgra[4 * i + j] = codes[offset + j];
            }
        }

        public static byte[] DecompressImage(bool keepChannelOrder, uint width, uint height, byte[] blocks, FOUR_CC four_cc)
        {
            int sourceBlock = 0;
            int bytesPerBlock = (four_cc == FOUR_CC.DXT1 || four_cc == FOUR_CC.DXT1A) ? 8 : 16;

            int compressedSize = (int)(Math.Ceiling(width / 4f) * Math.Ceiling(height / 4f) * bytesPerBlock);
            if (compressedSize > blocks.Length)
            {
                throw new ArgumentException("insufficient length", "blocks");
            }

            byte[] bgra = new byte[width * height * 4];

            // loop over blocks
            for (int y = 0; y < height; y += 4)
            {
                for (int x = 0; x < width; x += 4)
                {
                    // decompress the block

                    byte[] targetBgra = new byte[64];
                    if (four_cc == FOUR_CC.DXT1A)
                    {
                        DecompressColor(targetBgra, blocks, sourceBlock, true);
                    }
                    else if (four_cc == FOUR_CC.DXT1)
                    {
                        DecompressColor(targetBgra, blocks, sourceBlock, false);
                    }
                    else if (four_cc == FOUR_CC.DXT3)
                    {
                        DecompressColor(targetBgra, blocks, sourceBlock + 8, false);
                        DecompressAlphaDxt3(targetBgra, blocks, sourceBlock);
                    }
                    else
                    { // four_cc == FOUR_CC.DXT5
                        DecompressColor(targetBgra, blocks, sourceBlock + 8, false);
                        DecompressDxt5Alpha(targetBgra, blocks, sourceBlock, 4, 3);
                    }

                    // write the decompressed pixels to the correct image locations
                    int sourcePixel = 0;
                    for (int py = 0; py < 4; py++)
                    {
                        for (int px = 0; px < 4; px++)
                        {
                            // get the target location
                            int sx = x + px;
                            int sy = y + py;
                            if (sx < width && sy < height)
                            {
                                int targetPixel = (int)(4 * (width * sy + sx));

                                for (int i = 0; i < 4; i++)
                                {
                                    bgra[targetPixel] = targetBgra[sourcePixel];
                                    targetPixel++;
                                    sourcePixel++;
                                }

                                if (!keepChannelOrder)
                                {
                                    byte tmp = bgra[targetPixel - 4];
                                    bgra[targetPixel - 4] = bgra[targetPixel - 2];  // blue => red
                                    //rgba[targetPixel - 3]                         // green
                                    bgra[targetPixel - 2] = tmp;   //rot            // red => blue
                                    //rgba[targetPixel - 1]                         // alpha
                                }

                            }
                            else
                            {
                                // skip this pixel as its outside the image
                                sourcePixel += 4;
                            }
                        }
                    }

                    // advance
                    sourceBlock += bytesPerBlock;
                }
            }
            return bgra;
        }
    }
}
