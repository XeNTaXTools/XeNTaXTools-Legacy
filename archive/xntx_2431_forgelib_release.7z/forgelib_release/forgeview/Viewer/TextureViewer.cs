﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using forgelib;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using forgelib.Resources;

namespace forgeview.Viewer
{
    public partial class TextureViewer : Form
    {
        public enum DisplayMode
        { 
            Normal,
            NoAlpha,
            InverseAlpha,
            AlphaOnly,
            NormalMapTest
        }
        
        private DDSFile dds;
        private DisplayMode mode;
        bool flippedx = false;
        bool flippedy = true;
        int faceIndex = 0;

        public TextureViewer(DDSFile dds)
        {
            this.dds = dds;
            InitializeComponent();
            displayDDS();
        }

        bool mouseDown = false;
        Point mousePos;
        Point scrollPos;

        void displayDDS()
        {
            string formatStr = "";
            byte[] compBuffer;
            if (dds.header.sCaps.dwCaps2.HasFlag(DDSFile.DDSCAPS2_FLAGS.DDSCAPS2_CUBEMAP))
            {
                formatStr += "CubeMap ";
                compBuffer = dds.GetFirstMipData(faceIndex);
            }
            else
            {
                toolStripSplitButton2.Visible = false;
                compBuffer = dds.GetFirstMipData();
            }
            
            byte[] outbuffer = null;
            switch (dds.header.sPixelFormat.dwFourCC)
            { 
                case DDSFile.FOUR_CC.DXT1:
                    formatStr += "DXT1";
                    DXTTools.FOUR_CC fourcc = DXTTools.FOUR_CC.DXT1;
                    if ((dds.header.sPixelFormat.dwFlags & DDSFile.DDPF_FLAGS.DDPF_ALPHAPIXELS) == DDSFile.DDPF_FLAGS.DDPF_ALPHAPIXELS)
                    {
                        fourcc = DXTTools.FOUR_CC.DXT1A;
                        formatStr += "A";
                    }
                    outbuffer = DXTTools.DecompressImage(false, dds.header.dwWidth, dds.header.dwHeight, compBuffer, fourcc);
                    break;
                case DDSFile.FOUR_CC.DXT3:
                    outbuffer = DXTTools.DecompressImage(false, dds.header.dwWidth, dds.header.dwHeight, compBuffer, DXTTools.FOUR_CC.DXT3);
                    formatStr += "DXT3";
                    break;
                case DDSFile.FOUR_CC.DXT5:
                    outbuffer = DXTTools.DecompressImage(false, dds.header.dwWidth, dds.header.dwHeight, compBuffer, DXTTools.FOUR_CC.DXT5);
                    formatStr += "DXT5";
                    bc5ToolStripMenuItem.Visible = true;
                    break;
                case DDSFile.FOUR_CC.None:
                    if ((dds.header.sPixelFormat.dwFlags & DDSFile.DDPF_FLAGS.DDPF_RGB) == DDSFile.DDPF_FLAGS.DDPF_RGB
                        && dds.header.sPixelFormat.dwRGBBitCount == 32)
                    {
                        bc5ToolStripMenuItem.Visible = true;
                        formatStr += "R8G8B8A";
                        outbuffer = compBuffer;
                    }
                    else if ((dds.header.sPixelFormat.dwFlags & DDSFile.DDPF_FLAGS.DDPF_RGB) != DDSFile.DDPF_FLAGS.DDPF_RGB &&
                        (dds.header.sPixelFormat.dwFlags & DDSFile.DDPF_FLAGS.DDPF_ALPHAPIXELS) == DDSFile.DDPF_FLAGS.DDPF_ALPHAPIXELS
                        && dds.header.sPixelFormat.dwRGBBitCount == 8)
                    {
                        formatStr += "A8";
                        outbuffer = new byte[compBuffer.Length * 4];
                        for (int i = 0; i < compBuffer.Length; i++)
                        {
                            outbuffer[i * 4 + 3] = compBuffer[i];
                        }
                    }
                    else
                    {
                        throw new NotSupportedException("unsupported format...");
                    }
                    break;
            }

            if (mode == DisplayMode.NormalMapTest)
            {
                // z = (1 - x ^ 2 - y ^ 2) ^ 1 / 2
                for (int i = 0; i < outbuffer.Length; i += 4)
                {
                    byte r = outbuffer[i];
                    byte g = outbuffer[i + 1];
                    byte b = outbuffer[i + 2];
                    byte a = outbuffer[i + 3];

                    int lum = (r + r + r + b + g + g + g + g) >> 3;

                    double dr = lum / 255d; // or r
                    double da = a / 255d;
                    dr = dr * 2 - 1;
                    da = da * 2 - 1;

                    double r2 = dr * dr;
                    double a2 = da * da;
                    double d = Math.Sqrt(1d - r2 - a2);
                    byte z = (byte)(255 * d);

                    outbuffer[i] = z;
                    outbuffer[i + 1] = (byte)lum; // or r
                    outbuffer[i + 2] = a;
                    outbuffer[i + 3] = 255;
                }
            }
            
            if (outbuffer != null)
            {
                if (mode == DisplayMode.NoAlpha)
                {
                    for (int i = 0; i < outbuffer.Length; i+=4)
                    {
                        outbuffer[i + 3] = 255;
                    }
                }
                else if (mode == DisplayMode.InverseAlpha)
                {
                    for (int i = 0; i < outbuffer.Length; i += 4)
                    {
                        outbuffer[i + 3] = (byte)(255 - outbuffer[i + 3]);
                    }
                }
                else if (mode == DisplayMode.AlphaOnly)
                {
                    for (int i = 0; i < outbuffer.Length; i += 4)
                    {
                        outbuffer[i + 0] = 0;
                        outbuffer[i + 1] = 0;
                        outbuffer[i + 2] = 0;
                    }
                }
                
                PixelFormat format = PixelFormat.Format32bppArgb;
                Bitmap bmp = new Bitmap((int)dds.header.dwWidth, (int)dds.header.dwHeight, format);
                BitmapData data = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.ReadWrite, format);
                Marshal.Copy(outbuffer, 0, data.Scan0, outbuffer.Length);
                bmp.UnlockBits(data);

                if (flippedx)
                {
                    bmp.RotateFlip(RotateFlipType.RotateNoneFlipX);
                }
                if (flippedy)
                {
                    bmp.RotateFlip(RotateFlipType.RotateNoneFlipY);
                }

                pictureBox1.Width = bmp.Width;
                pictureBox1.Height = bmp.Height;
                pictureBox1.Image = bmp;
            }

            toolStripStatusLabel1.Text = string.Format("{0} {1}x{2}", formatStr, dds.header.dwWidth, dds.header.dwHeight);
        }

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            mouseDown = false;
            Cursor = Cursors.Default;
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            mouseDown = true;
            Cursor = Cursors.SizeAll;
            mousePos = pictureBox1.PointToScreen(e.Location);
            scrollPos = new Point(panel1.HorizontalScroll.Value, panel1.VerticalScroll.Value);
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (mouseDown)
            {
                int maxx = pictureBox1.Parent.ClientSize.Width - pictureBox1.Width;
                int maxy = pictureBox1.Parent.ClientSize.Height - pictureBox1.Height;
                
                Point p1 = pictureBox1.PointToScreen(e.Location);
                
                int newLocX = Math.Min(Math.Max(scrollPos.X + mousePos.X - p1.X, 0), panel1.HorizontalScroll.Maximum);
                int newLocY = Math.Min(Math.Max(scrollPos.Y + mousePos.Y - p1.Y, 0), panel1.VerticalScroll.Maximum);

                panel1.HorizontalScroll.Value = newLocX;
                panel1.VerticalScroll.Value = newLocY;
            }
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            ColorDialog dlg = new ColorDialog();
            dlg.Color = pictureBox1.BackColor;
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                pictureBox1.BackColor = dlg.Color;
            }
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            flippedy = !flippedy;
            toolStripButton2.Checked = flippedy;
            if (pictureBox1.Image != null)
            {
                pictureBox1.Image.RotateFlip(RotateFlipType.RotateNoneFlipY);
                pictureBox1.Invalidate();
            }
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            flippedx = !flippedx;
            toolStripButton3.Checked = flippedx;
            if (pictureBox1.Image != null)
            {
                pictureBox1.Image.RotateFlip(RotateFlipType.RotateNoneFlipX);
                pictureBox1.Invalidate();
            }
        }

        private void toolStripSplitButton1_DropDownItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            foreach (var i in toolStripSplitButton1.DropDown.Items)
            {
                if (i == e.ClickedItem)
                {
                    DisplayMode newMode;

                    if (Enum.TryParse<DisplayMode>((string)((ToolStripMenuItem)i).Tag, out newMode))
                    {
                        if (newMode != mode)
                        {
                            mode = newMode;
                            displayDDS();

                            toolStripSplitButton1.Text = ((ToolStripMenuItem)i).Text;
                        }
                    }
                        
                    ((ToolStripMenuItem)i).Checked = true;
                }
                else ((ToolStripMenuItem)i).Checked = false;
            }
        }

        private void toolStripSplitButton2_DropDownItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            foreach (var i in toolStripSplitButton2.DropDown.Items)
            {
                if (i == e.ClickedItem)
                {
                    faceIndex = int.Parse((string)((ToolStripMenuItem)i).Tag);
                    displayDDS();
                    toolStripSplitButton2.Text = ((ToolStripMenuItem)i).Text;

                    ((ToolStripMenuItem)i).Checked = true;
                }
                else ((ToolStripMenuItem)i).Checked = false;
            }
        }

        private void speichernToolStripButton_Click(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                string filename = saveFileDialog1.FileName;
                string ext = System.IO.Path.GetExtension(filename).ToLower();
                if (ext.EndsWith("png"))
                {
                    pictureBox1.Image.Save(filename, ImageFormat.Png);
                }
                else if (ext.EndsWith("dds"))
                {
                    dds.WriteFile(System.IO.File.OpenWrite(filename));
                }
            }
        }
    }
}
