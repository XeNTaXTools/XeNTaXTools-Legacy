﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Win32;
using System.Windows.Forms;

namespace forgeview
{
    public class GameDirHelper
    {
        static string[] keys = new string[] 
        {
            @"Ubisoft\Assassin's Creed Brotherhood",
            @"Wow6432Node\Ubisoft\Assassin's Creed Brotherhood"
        };
        
        public static string GetGameDirectory()
        {
            string dir = null;

            foreach (var s in keys)
            {
                try
                {
                    var key = Registry.LocalMachine.OpenSubKey("SOFTWARE").OpenSubKey(s);
                    if (key != null)
                    {
                        dir = key.GetValue("InstallDir") as string;
                        if (dir != null) break;
                    }
                }
                catch { 
                
                }
            }

            if (dir == null)
            {
                FolderBrowserDialog dlg = new FolderBrowserDialog();
                dlg.Description = "Couldn't find Game dir. Choose manually...";
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    dir = dlg.SelectedPath;
                }
            }
            
            return dir;
        }
    }
}
