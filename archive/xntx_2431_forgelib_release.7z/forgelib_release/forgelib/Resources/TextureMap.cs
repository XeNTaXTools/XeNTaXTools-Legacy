﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using forgelib.Nodes;
using forgelib.Utils;

namespace forgelib.Resources
{
    [KnownTypeRegistry.KnownType("TextureMap")]
    public class TextureMap : ResourceBase
    {
        public enum PixelFormatType
        {
            RGBA8888,
            RGBA8888Signed, // ???
            DXT1,           // no alpha
            DXT1A,          // 1bit alpha
            DXT3,
            DXT5,


            DXN,            // not used by acb ?
            A8,
            I8,             // not used by acb ?
            I16,            // not used by acb ?
            A8I8            // not used by acb ?
        }

        public enum TextureFormatType
        {
            Tex1D,
            Tex2D,
            TexCubeMap
        }

        public int Width { get; private set; }
        public int Height { get; private set; }

        int unkint1;
        public PixelFormatType PixelFormat { get; private set; }
        public TextureFormatType TextureFormat { get; private set; }
        int unkint4;
        public int MipLevels { get; private set; }
        int unkint6;

        int unkint7;
        int unkint8;
        int unkint9;
        int unkint10;
        int unkint11;
        int unkint12;
        int unkint13;

        byte unkbyte14;
        byte unkbyte15;
        byte unkbyte16;
        byte unkbyte17;

        int unkint18;

        int compiledTextureLength;

        private long surfaceDataOffset;

        static readonly uint CONST_CompiledTextureMap = CRC32.ComputeHash("CompiledTextureMap");

        public TextureMap(ResourceBase other)
            : base(other)
        {

        }

        public override void Load()
        {
            _baseStream.Position = dataOffset;
            BinaryReader r = new BinaryReader(_baseStream);
            Width = r.ReadInt32();
            Height = r.ReadInt32();

            unkint1 = r.ReadInt32();        // 1
            PixelFormat = (PixelFormatType)r.ReadInt32();
            if ((int)PixelFormat > 5 && PixelFormat != PixelFormatType.A8)
            {
                throw new NotSupportedException(string.Format("Unexpected PixelFormat: {0}", PixelFormat));
            }

            TextureFormat = (TextureFormatType)r.ReadInt32();

            unkint4 = r.ReadInt32();        // 0, 1

            MipLevels = r.ReadInt32();      // 0, 1, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12

            unkint6 = r.ReadInt32();        // 0, 2

            unkint7 = r.ReadInt32();       // 0, 2
            unkint8 = r.ReadInt32();       // 0, 2

            unkint9 = r.ReadInt32();        // 0, 1
            unkint10 = r.ReadInt32();        // 0, 1
            unkint11 = r.ReadInt32();       // 1, 2

            unkint12 = r.ReadInt32();       // 0, 1, 2, 10
            unkint13 = r.ReadInt32();       // 0, 1, 2, 4

            unkbyte14 = r.ReadByte();     // 
            unkbyte15 = r.ReadByte();     // 
            unkbyte16 = r.ReadByte();     // 
            unkbyte17 = r.ReadByte();     // 

            unkint18 = r.ReadInt32();      // 0

            // start of new class
            r.ReadInt32();       // 0
            uint dataformatid = r.ReadUInt32();
            if (dataformatid != CONST_CompiledTextureMap)
            {
                throw new NotSupportedException(string.Format("expected dataformat id: 0x{0:x8}, got: 0x{1:x8}", CONST_CompiledTextureMap, dataformatid));
            }
            compiledTextureLength = r.ReadInt32();

            DDSFile tmpSurface = createSurface();
            surfaceDataOffset = r.BaseStream.Position;
            IsLoaded = true;
        }

        public override void Unload()
        {
            IsLoaded = false;
        }

        private DDSFile createSurface()
        {
            DDSFile surface = new DDSFile();
            if (TextureFormat == TextureFormatType.TexCubeMap)
            {
                surface.SetSpecialTexture(DDSFile.DDSCAPS2_FLAGS.DDSCAPS2_CUBEMAP);
            }

            switch (PixelFormat)
            {
                case PixelFormatType.DXT1:
                    surface.SetPixelFormat("PF_DXT1");
                    break;
                case PixelFormatType.DXT1A:
                    surface.SetPixelFormat("PF_DXT1A");
                    break;
                case PixelFormatType.DXT3:
                    surface.SetPixelFormat("PF_DXT3");
                    break;
                case PixelFormatType.DXT5:
                    surface.SetPixelFormat("PF_DXT5");
                    break;
                case PixelFormatType.RGBA8888:
                case PixelFormatType.RGBA8888Signed:
                    surface.SetPixelFormat("PF_A8R8G8B8");
                    break;
                case PixelFormatType.A8:
                    surface.SetPixelFormat("PF_A8");
                    break;
                default:
                    throw new NotSupportedException("unsupported pixelformat");
            }
            surface.SetSizeAndMipmapCount((uint)Width, (uint)Height, (uint)Math.Max(MipLevels, 1));
            if (compiledTextureLength != surface.RequiredMipSizeAll)
            {
                throw new NotSupportedException("unexpected texture size...");
            }

            return surface;
        }

        public override object GetData()
        {
            if (!IsLoaded) Load();
            DDSFile returnValue = createSurface();
            _baseStream.Position = surfaceDataOffset;
            byte[] data = new byte[compiledTextureLength];
            _baseStream.Read(data, 0, compiledTextureLength);
            returnValue.SetData(data);
            return returnValue;
        }
    }
}