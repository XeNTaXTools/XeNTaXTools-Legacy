﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using forgelib.Nodes;

namespace forgelib.Resources
{
    [KnownTypeRegistry.KnownType("FireData")]
    public class FireData : ResourceBase
    {
        private byte[] _data;
        
        public FireData(ResourceBase other)
            : base(other)
        {

        }

        public override void Load()
        {
            _baseStream.Position = dataOffset;
            BinaryReader r = new BinaryReader(_baseStream);
            int fileLength = r.ReadInt32();

            _data = r.ReadBytes(fileLength + 4);
            if (!(_data[0] == 0x55 && _data[1] == 0x45 && _data[2] == 0x46))
            {
                throw new NotSupportedException("unexpected SWF header magic...");
            }
            _data[0] = 0x46;
            _data[1] = 0x57;
            _data[2] = 0x53;
            IsLoaded = true;
        }

        public override void Unload()
        {
            _data = null;
            IsLoaded = false;
        }

        public override object GetData()
        {
            if (!IsLoaded) Load();
            return _data;
        }
    }
}
