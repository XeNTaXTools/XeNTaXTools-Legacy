﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using forgelib.Nodes;
using forgelib.Utils;
using System.ComponentModel;

namespace forgelib.Resources
{
    [KnownTypeRegistry.KnownType("Material")]
    [TypeConverter(typeof(ExpandableObjectConverter))]
    public class Material : ResourceBase
    {
        [TypeConverter(typeof(ExpandableObjectConverter))]
        public class Mask
        {
            static readonly uint CONST_Mask = CRC32.ComputeHash("Mask");

            public byte Unknown01 { get; private set; }
            public int Unknown02 { get; private set; }
            public byte[] Unknown03 { get; private set; }
            ResourceDependency AdditionalMaterial;

            public Mask(BinaryReader r)
            {
                Read(r);
            }

            public void Read(BinaryReader r)
            {
                r.ReadInt32(); // 0
                uint magic = r.ReadUInt32();
                if (magic != CONST_Mask)
                {
                    throw new NotSupportedException(string.Format("expected id: 0x{0:x8}, got: 0x{1:x8}", CONST_Mask, magic));
                }

                Unknown01 = r.ReadByte();
                Unknown02 = r.ReadInt32();

                Unknown03 = r.ReadBytes(26);

                AdditionalMaterial = new ResourceDependency(r);
            }
        }

        [TypeConverter(typeof(ExpandableObjectConverter))]
        public class Mask16
        {
            static readonly uint CONST_Mask16 = CRC32.ComputeHash("Mask16");

            public byte[] Unknown01 { get; private set; }
            public int Unknown02 { get; private set; }

            public Mask16(BinaryReader r)
            {
                Read(r);
            }

            public void Read(BinaryReader r)
            {
                r.ReadInt32(); // 0
                uint magic = r.ReadUInt32();
                if (magic != CONST_Mask16)
                {
                    throw new NotSupportedException(string.Format("expected id: 0x{0:x8}, got: 0x{1:x8}", CONST_Mask16, magic));
                }
                Unknown01 = r.ReadBytes(16);
                Unknown02 = r.ReadInt32();
            }
        }

        #region parameter subclasses

        public enum ParameterElementType
        {
            Float = 0x000A0000,
            Vector = 0x000D0000,
            Quaternion = 0x000E0000,
            Struct = 0x00130000
        }

        [TypeConverter(typeof(ExpandableObjectConverter))]
        public class MaterialParameter
        {
            public uint NameHash { get; private set; }
            public string Name { get { return Hash.HashLookup.GetHashedString(NameHash); } }
            public uint StructTypeID { get; private set; }
            public string StructName { get { return Hash.HashLookup.GetHashedString(StructTypeID); } }
            public ParameterElementType ElementType { get; private set; }

            public MaterialParameter(MaterialParameter param)
            {
                NameHash = param.NameHash;
                StructTypeID = param.StructTypeID;
                ElementType = param.ElementType;
            }

            public MaterialParameter(BinaryReader r)
            {
                Read(r);
            }

            public virtual void Read(BinaryReader r)
            {
                NameHash = r.ReadUInt32();
                StructTypeID = r.ReadUInt32();
                ElementType = (ParameterElementType)r.ReadUInt32();
            }
        }

        public class TextureSelector : MaterialParameter
        {
            public static readonly uint ID = CRC32.ComputeHash("TextureSelector");

            public uint Unknown01 { get; private set; }
            public uint Unknown02 { get; private set; }

            public ResourceDependency Unknown03 { get; private set; }
            public ResourceDependency TextureMapDependency { get; private set; }

            public TextureSelector(BinaryReader r, MaterialParameter param)
                : base(param)
            {
                Read(r);
            }

            public override void Read(BinaryReader r)
            {
                r.ReadByte(); // 0
                r.ReadUInt32(); // 0
                uint magic = r.ReadUInt32();
                if (magic != ID)
                {
                    throw new NotSupportedException(string.Format("expected id: 0x{0:x8}, got: 0x{1:x8}", ID, magic));
                }
                Unknown01 = r.ReadUInt32();
                Unknown02 = r.ReadUInt32();
                Unknown03 = new ResourceDependency(r);
                TextureMapDependency = new ResourceDependency(r);
            }
        }

        public class UVTransform : MaterialParameter
        {
            public static readonly uint ID = CRC32.ComputeHash("UVTransform");

            public float U1 { get; private set; }
            public float U2 { get; private set; }
            public float U3 { get; private set; }
            public float U4 { get; private set; }
            public float U5 { get; private set; }
            public float U6 { get; private set; }
            public float U7 { get; private set; }
            public float U8 { get; private set; }
            public short U9 { get; private set; }

            public UVTransform(BinaryReader r, MaterialParameter param)
                : base(param)
            {
                Read(r);
            }

            public override void Read(BinaryReader r)
            {
                r.ReadUInt32(); // 0
                uint magic = r.ReadUInt32();
                if (magic != ID)
                {
                    throw new NotSupportedException(string.Format("expected id: 0x{0:x8}, got: 0x{1:x8}", ID, magic));
                }
                U1 = r.ReadSingle();
                U2 = r.ReadSingle();
                U3 = r.ReadSingle();
                U4 = r.ReadSingle();
                U5 = r.ReadSingle();
                U6 = r.ReadSingle();
                U7 = r.ReadSingle();
                U8 = r.ReadSingle();
                U9 = r.ReadInt16();
            }
        }

        public class TimeOscillatorData : MaterialParameter
        {
            public static readonly uint ID = CRC32.ComputeHash("TimeOscillatorData");

            public uint U1 { get; private set; }
            public float U2 { get; private set; }
            public float U3 { get; private set; }
            public uint U4 { get; private set; }

            public TimeOscillatorData(BinaryReader r, MaterialParameter param)
                : base(param)
            {
                Read(r);
            }

            public override void Read(BinaryReader r)
            {
                r.ReadUInt32(); // 0
                uint magic = r.ReadUInt32();
                if (magic != ID)
                {
                    throw new NotSupportedException(string.Format("expected id: 0x{0:x8}, got: 0x{1:x8}", ID, magic));
                }
                U1 = r.ReadUInt32();
                U2 = r.ReadSingle();
                U3 = r.ReadSingle();
                U4 = r.ReadUInt32();
            }
        }

        public class FloatParameter : MaterialParameter
        {
            public float Value { get; private set; }

            public FloatParameter(BinaryReader r, MaterialParameter param)
                : base(param)
            {
                Read(r);
            }

            public override void Read(BinaryReader r)
            {
                Value = r.ReadSingle();
            }
        }

        public class VectorParameter : MaterialParameter
        {
            public float X { get; private set; }
            public float Y { get; private set; }
            public float Z { get; private set; }
            public float W { get; private set; }

            public VectorParameter(BinaryReader r, MaterialParameter param)
                : base(param)
            {
                Read(r);
            }

            public override void Read(BinaryReader r)
            {
                X = r.ReadSingle();
                Y = r.ReadSingle();
                Z = r.ReadSingle();
                W = r.ReadSingle();
            }
        }

        public class QuaternionParameter : MaterialParameter
        {
            public float X { get; private set; }
            public float Y { get; private set; }
            public float Z { get; private set; }
            public float W { get; private set; }

            public QuaternionParameter(BinaryReader r, MaterialParameter param)
                : base(param)
            {
                Read(r);
            }

            public override void Read(BinaryReader r)
            {
                X = r.ReadSingle();
                Y = r.ReadSingle();
                Z = r.ReadSingle();
                W = r.ReadSingle();
            }
        }
        #endregion

        public ResourceDependency MaterialTemplateDependency { get; private set; }
        public ResourceDependency TextureSetDependency { get; private set; }

        public Mask MaskObject { get; private set; }
        public Mask16 Mask16Object { get; private set; }
        public MaterialParameter[] Parameters { get; private set; }

        public Material(ResourceBase other)
            : base(other)
        {

        }

        public override void Load()
        {
            _baseStream.Position = dataOffset;
            BinaryReader r = new BinaryReader(_baseStream);
            MaterialTemplateDependency = new ResourceDependency(r);
            TextureSetDependency = new ResourceDependency(r);

            MaskObject = new Mask(r);
            Mask16Object = new Mask16(r);

            int count = r.ReadInt32();
            Parameters = new MaterialParameter[count];
            for (int i = 0; i < count; i++)
            {
                MaterialParameter p = new MaterialParameter(r);
                switch (p.ElementType)
                {
                    case ParameterElementType.Float:
                        p = new FloatParameter(r, p);
                        break;
                    case ParameterElementType.Vector:
                        p = new VectorParameter(r, p);
                        break;
                    case ParameterElementType.Quaternion:
                        p = new QuaternionParameter(r, p);
                        break;
                    case ParameterElementType.Struct:
                        if (p.StructTypeID == UVTransform.ID) p = new UVTransform(r, p);
                        else if (p.StructTypeID == TextureSelector.ID)
                        {
                            var texsel = new TextureSelector(r, p);
                            texsel.Unknown03.Resolve(this);
                            texsel.TextureMapDependency.Resolve(this);
                            p = texsel;
                        }
                        else if (p.StructTypeID == TimeOscillatorData.ID) p = new TimeOscillatorData(r, p);
                        else throw new NotSupportedException(string.Format("unknown struct parameter type: 0x{0:x8}", p.StructTypeID));
                        break;
                    default:
                        throw new NotSupportedException(string.Format("unknown parameter elementtype type: 0x{0:x8}", p.ElementType));
                }
                Parameters[i] = p;
            }

            TextureSetDependency.Resolve(this);
            MaterialTemplateDependency.Resolve(this);

            IsLoaded = true;
        }

        public override void Unload()
        {
            MaskObject = null;
            Mask16Object = null;
            Parameters = null;
            IsLoaded = false;
        }

        public override object GetData()
        {
            if (!IsLoaded) Load();
            return this;
        }
    }
}