﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using forgelib.Nodes;
using forgelib.Utils;

namespace forgelib.Resources
{
    [KnownTypeRegistry.KnownType("LocalizationPackage")]
    public class LocalizationPackage : ResourceBase
    {
        #region const & enums

        public enum LocalizationLanguageId : int
        {
            English_US = 1,
            French_France = 2,
            Spanish_Spain = 3,
            Polish = 4,
            German = 5,
            Chinese_PRC = 6,
            Hungarian = 7,
            Italian = 8,
            Japanese = 9,
            Czech = 10,
            Korean = 11,
            Russian = 12,
            Dutch = 13,
            Danish = 14,
            Norwegian = 15,
            Swedish = 16,
            Portuguese = 17,
            Turkish = 18
        }

        public enum LocalizationPackageType
        {
            General,
            Subtitles,
            EManual
        }
        #endregion

        static readonly uint CONST_CompressedLocalizationData = CRC32.ComputeHash("CompressedLocalizationData");

        public LocalizationPackageType PackageType { get; private set; }
        public LocalizationLanguageId LanguageId { get; private set; }

        CompressedLocalizationData _data;

        public LocalizationPackage(ResourceBase other)
            : base(other)
        {

        }

        public override void Load()
        {
            _baseStream.Position = dataOffset;
            BinaryReader r = new BinaryReader(_baseStream);

            PackageType = (LocalizationPackageType)r.ReadInt32();
            LanguageId = (LocalizationLanguageId)r.ReadInt32();

            r.ReadInt32(); // 0

            // start of new class
            r.ReadInt32(); // 0
            uint dataFormatId = r.ReadUInt32();
            if (dataFormatId == CONST_CompressedLocalizationData)
            {
                int _dataLength = r.ReadInt32();
                if (_dataLength != 0)
                {
                    byte[] buf = new byte[_dataLength];
                    _baseStream.Read(buf, 0, buf.Length);
                    _data = new CompressedLocalizationData(new MemoryStream(buf));
                }
            }
            else
            {
                throw new NotSupportedException(string.Format("expected data format id: 0x{0:x8}, got: 0x{1:x8}", CONST_CompressedLocalizationData, dataFormatId));
            }
            IsLoaded = true;
        }

        public override void Unload()
        {
            _data = null;
            IsLoaded = false;
        }

        public override object GetData()
        {
            if (!IsLoaded) Load();
            return _data;
        }
    }
}