﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using forgelib.Nodes;

namespace forgelib.Resources
{
    public class ResourceBase : IFileSystemInfo
    {
        struct unkStruct1
        {
            /* hash for:
            AnimTrackEvent, EventSeed, ContactEventSeed, ContactEvent, EventSeedLinkData, PlayFacialCustomActionEventSeed, PlayFacialCustomActionEvent, AudioEventSeed, AudioEvent, SoundSetEventSeed, SoundSetEvent, FXEventSeed, FXEvent, SpeechEventSeed, SpeechEvent, DropObjectEventSeed, DropObjectEvent, BloodSplatterEventSeed, BloodSplatterEvent, AnimSyncDieEventSeed, AnimSyncDieEvent, AnimSyncFallEventSeed, AnimSyncFallEvent, AnimTimingEventSeed, AnimTimingEvent, ThrowMoneyEventSeed, ThrowMoneyEvent, WeaponSwitchToRightHandEventSeed, WeaponHandSwitchEvent, WeaponSwitchToLeftHandEventSeed, ProxyTexture, NavMesh, NavMeshTriangle, NavMeshMetaLink, NavMeshTriangleRef, ObjectWayPoint, NavMeshRef, WayPoint
            unknown: 0x3410ddbd, 0x676df79d, 0xf995e858, 0x18080c2a, 0xe827db0a, 0x1eb22b44
            */
            public uint Unknown1;
            public uint Unknown2;
            public uint Unknown3;
        }

        protected Stream _baseStream;

        protected IFileSystemInfo _container;

        public uint TypeId { get; private set; }

        public virtual string Name { get; private set; }
        public virtual uint EntryId { get; private set; }

        private long _rawDataOffset;
        protected long dataOffset;
        private uint length;

        unkStruct1[] unkStructArray;

        public virtual bool IsLoaded { get; protected set; }

        // is child of resourcecollection
        public ResourceBase(ResourceCollection container)
        {
            _container = container;
        }

        // is child of fileentry or is resourcecollection
        public ResourceBase(FileEntry container)
        {
            _container = container;
        }

        // copy .ctor for known resources
        public ResourceBase(ResourceBase other)
        {
            _baseStream = other._baseStream;
            _container = other._container;
            TypeId = other.TypeId;
            Name = other.Name;
            EntryId = other.EntryId;
            _rawDataOffset = other._rawDataOffset;
            dataOffset = other.dataOffset;
            length = other.length;
            NumReadFiles = other.NumReadFiles;
            IsLoaded = false;
        }

        public void Read(Stream input)
        {
            _baseStream = input;
            BinaryReader r = new BinaryReader(input);
            TypeId = r.ReadUInt32();

            length = r.ReadUInt32(); // after name and next structure

            int strlen = r.ReadInt32();
            Name = Encoding.ASCII.GetString(r.ReadBytes(strlen));

            byte unkByte1 = r.ReadByte();
            if (unkByte1 != 0)
            {
                if (unkByte1 == 1)
                {
                    r.ReadByte(); // 2
                    r.ReadInt16(); // 0
                    int count = r.ReadInt32();
                    unkStructArray = new unkStruct1[count];
                    for (int i = 0; i < count; i++)
                    {
                        unkStructArray[i] = new unkStruct1()
                        {
                            Unknown1 = r.ReadUInt32(),
                            Unknown2 = r.ReadUInt32(),
                            Unknown3 = r.ReadUInt32()
                        };
                    }
                }
                else
                {
                    throw new Exception("couldn't read resource...");
                }
            };
            
            _rawDataOffset = r.BaseStream.Position;

            r.ReadByte();  // 1, numEntryIds ???

            EntryId = r.ReadUInt32();

            if (string.IsNullOrEmpty(Name)) Name = string.Format("0x{0:x8}", EntryId);

            uint typehash2 = r.ReadUInt32();
            if (typehash2 != TypeId)
            {
                throw new NotSupportedException(string.Format("expected type id: 0x{0:x8}, got: 0x{1:x8}", TypeId, typehash2));
            }
            dataOffset = r.BaseStream.Position;
            IsLoaded = true;
            NumReadFiles = 1;
        }

        public virtual void Load()
        { 
            // override in known resources
        }

        public virtual void Unload()
        {
            // override in known resources
        }

        public virtual object GetData()
        {
            _baseStream.Position = _rawDataOffset;
            byte[] buffer = new byte[length];
            _baseStream.Read(buffer, 0, buffer.Length);
            return buffer;
        }

        public virtual int Index { get; set; }

        public virtual int NumReadFiles { get; private set; }

        public virtual long Length
        {
            get { return length; }
        }

        public virtual string Type
        {
            get 
            {
                return forgelib.Hash.HashLookup.GetHashedString(TypeId);
            }
        }

        public bool IsKnownResource
        {
            get { return KnownTypeRegistry.IsKnownType(TypeId); }
        }

        public virtual bool IsDirectory
        {
            get { return false; }
        }

        public virtual List<IFileSystemInfo> GetFiles()
        {
            throw new NotImplementedException();
        }

        public virtual List<IFileSystemInfo> GetFilesystemInfos()
        {
            throw new NotImplementedException();
        }

        public virtual List<IFileSystemInfo> GetDirectories()
        {
            throw new NotImplementedException();
        }

        public override string ToString()
        {
            return string.Format("{0} 0x{1:x8} {2}", Type, EntryId, Name);
        }


        public virtual IFileSystemInfo FindDependencyById(uint id)
        {
            if (id == EntryId) return this;
            return _container.FindDependencyById(id);
        }
    }
}
