﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using forgelib.Utils;

namespace forgelib.Resources
{
    public class ResourceDirectoryTable
    {
        public class DataLayerFilterTable
        {
            static readonly uint CONST_DataLayerFilterTable = CRC32.ComputeHash("DataLayerFilterTable");

            DataLayerFilter[] Filters;

            public DataLayerFilterTable(BinaryReader r)
            {
                Read(r);
            }
            
            public void Read(BinaryReader r)
            {
                r.ReadInt16(); // 0
                r.ReadInt32(); // 0
                uint magic = r.ReadUInt32();
                if (magic != CONST_DataLayerFilterTable)
                {
                    throw new NotSupportedException(string.Format("expected id 0x{0}, got 0x{1}", CONST_DataLayerFilterTable, magic));
                }
                ushort count = r.ReadUInt16();
                Filters = new DataLayerFilter[count];
                for (int i = 0; i < count; i++)
                {
                    Filters[i] = new DataLayerFilter(r);
                }
            }
        }

        public class DataLayerFilter
        {
            static readonly uint CONST_DataLayerFilter = CRC32.ComputeHash("DataLayerFilter");

            DataLayerAction[] Actions;

            public DataLayerFilter(BinaryReader r)
            {
                Read(r);
            }

            public void Read(BinaryReader r)
            {
                r.ReadInt16(); // 0
                r.ReadInt32(); // 0
                uint magic = r.ReadUInt32();
                if (magic != CONST_DataLayerFilter)
                {
                    throw new NotSupportedException(string.Format("expected id 0x{0}, got 0x{1}", CONST_DataLayerFilter, magic));
                }
                ushort count = r.ReadUInt16();
                Actions = new DataLayerAction[count];
                for (int i = 0; i < count; i++)
                {
                    Actions[i] = new DataLayerAction(r);
                }
            }
        }

        public class DataLayerAction
        {
            static readonly uint CONST_DataLayerAction = CRC32.ComputeHash("DataLayerAction");

            uint U1;
            short U2;

            public DataLayerAction(BinaryReader r)
            {
                Read(r);
            }

            public void Read(BinaryReader r)
            {
                r.ReadInt16(); // 0
                r.ReadInt32(); // 0
                uint magic = r.ReadUInt32();
                if (magic != CONST_DataLayerAction)
                {
                    throw new NotSupportedException(string.Format("expected id 0x{0}, got 0x{1}", CONST_DataLayerAction, magic));
                }
                r.ReadByte(); // 0
                U1 = r.ReadUInt32();
                U2 = r.ReadInt16(); // 0 | 1
            }
        }

        public class ResourceDirectoryEntry
        {
            public uint EntryId { get; private set;}
            public int Length { get; private set; }
            short U3;

            public ResourceDirectoryEntry(BinaryReader r)
            {
                Read(r);
            }

            public void Read(BinaryReader r)
            {
                EntryId = r.ReadUInt32();
                Length = r.ReadInt32();
                U3 = r.ReadInt16();            
            }

            public override string ToString()
            {
                return string.Format("0x{0:x8} {1} 0x{2:x4}", EntryId, Length, U3);
            }
        }

        public ResourceDirectoryEntry[] Entries;
        public DataLayerFilterTable FilterTable;
        
        public int Length { get; private set; }

        public void Read(Stream input)
        {
            BinaryReader r = new BinaryReader(input);
            ushort count = r.ReadUInt16();
            Entries = new ResourceDirectoryEntry[count];

            Length = 0;
            for (int i = 0; i < count; i++)
            {
                Entries[i] = new ResourceDirectoryEntry(r);
                Length += Entries[i].Length;
            }

            count = r.ReadUInt16();
            if (count != 0)
            {
                MemoryStream mfs = new MemoryStream(r.ReadBytes(count));
                FilterTable = new DataLayerFilterTable(new BinaryReader(mfs));
            }

            r.ReadUInt16(); // count = 0
        }
    }
}
