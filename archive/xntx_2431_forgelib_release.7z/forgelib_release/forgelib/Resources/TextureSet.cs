﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using forgelib.Nodes;

namespace forgelib.Resources
{
    [KnownTypeRegistry.KnownType("TextureSet")]
    public class TextureSet : ResourceBase
    {
        public ResourceDependency[] Textures { get; private set; }
        public byte U1 { get; private set; }
        public uint U2 { get; private set; }

        public TextureSet(ResourceBase other)
            : base(other)
        {

        }

        public override void Load()
        {
            _baseStream.Position = dataOffset;
            BinaryReader r = new BinaryReader(_baseStream);
            Textures = new ResourceDependency[11];
            for (int i = 0; i < Textures.Length; i++) Textures[i] = new ResourceDependency(r);
            U1 = r.ReadByte();
            U2 = r.ReadUInt32();
            
            for(int i = 0; i < Textures.Length; i++)
            {
                Textures[i].Resolve(this);
            }
        }

        public override void Unload()
        {
            Textures = null;
            IsLoaded = false;
        }

        public override object GetData()
        {
            if (!IsLoaded) Load();
            return this;
        }
    }
}
