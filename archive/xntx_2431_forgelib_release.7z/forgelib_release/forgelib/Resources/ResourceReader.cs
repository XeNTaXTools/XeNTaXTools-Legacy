﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using forgelib.Nodes;

namespace forgelib.Resources
{
    public class ResourceReader
    {
        public static ResourceBase ReadResource(ResourceBase baseResource, bool multi)
        {
            // skip for now...
            //if (multi && baseResource.Type == "Skeleton") return baseResource;
            
            Type t = KnownTypeRegistry.GetType(baseResource.TypeId);
            if (t != null)
            {
                try
                {
                    baseResource = (ResourceBase)Activator.CreateInstance(t, baseResource);
                }
                catch(Exception ex)
                {
                    throw ex.InnerException;
                }
            }
            return baseResource;
        }

        public static ResourceCollection ReadResourceCollection(Stream stream, ResourceDirectoryTable table, FileEntry container, bool multi)
        {
            ResourceCollection coll = null;
            if (table != null && table.Entries.Length > 1)
            {
                coll = new ResourceCollection(table, container);
                int offset = 0;
                for (int i = 0; i < table.Entries.Length; i++)
                {
                    stream.Position = offset;
                    ResourceBase res = new ResourceBase(coll);
                    res.Read(stream);
                    stream.Position = offset;
                    res = ReadResource(res, multi);
                    res.Index = i;
                    offset += table.Entries[i].Length;
                    coll.AddResource(res);
                }
            }

            return coll;
        }
    }
}
