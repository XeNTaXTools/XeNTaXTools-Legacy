﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using forgelib.Nodes;
using forgelib.Utils;

namespace forgelib.Resources
{
    public static class KnownTypeRegistry
    {
        public class KnownTypeAttribute : Attribute
        {
            public readonly string Name;
            public readonly uint Id;

            public KnownTypeAttribute(string name)
            {
                this.Name = name;
                Id = CRC32.ComputeHash(name);
            }
        }

        static Dictionary<uint, Type> registeredTypes;
        
        public static bool IsKnownType(uint id)
        {
            return registeredTypes.ContainsKey(id);
        }

        private static void buildTypeLookup()
        {
            registeredTypes = new Dictionary<uint, Type>();

            foreach (Type type in System.Reflection.Assembly.GetAssembly(typeof(KnownTypeRegistry)).GetTypes())
            {
                if (type.IsSubclassOf(typeof(ResourceBase)) == true)
                {
                    object[] attributes = type.GetCustomAttributes(typeof(KnownTypeAttribute), false);
                    if (attributes.Length == 1)
                    {
                        KnownTypeAttribute attribute = (KnownTypeAttribute)attributes[0];
                        registeredTypes.Add(attribute.Id, type);
                    }
                }
            }
        }

        public static Type GetType(uint id)
        {
            if (registeredTypes == null) buildTypeLookup();
            
            if (registeredTypes.ContainsKey(id))
            {
                return registeredTypes[id];
            }
            return null;
        }
    }
}
