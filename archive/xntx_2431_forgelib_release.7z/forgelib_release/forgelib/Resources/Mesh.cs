﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using forgelib.Nodes;
using forgelib.Utils;
using forgelib.Resources.Geometry;

namespace forgelib.Resources
{
    [KnownTypeRegistry.KnownType("Mesh")]
    public class Mesh : ResourceBase
    {
        public class SubMesh
        {
            static readonly uint CONST_SubMesh = CRC32.ComputeHash("SubMesh");
            static readonly uint CONST_UVChannel = CRC32.ComputeHash("UVChannel");
            
            public SubMesh(BinaryReader r)
            { 
                Read(r);
            }

            short U01;
            uint Id;

            int[] U02;
            int[] U03;
            int[] U04;
            
            byte[] U05;
            
            VectorFloat3[] U06;
            VectorFloat3[] U07;
            VectorFloat3[] U08;
            VectorFloat3[] U09;
            
            int[] U10;
            PackedVectorByte4[] Color1;
            PackedVectorByte4[] Color2;
            
            VectorFloat4[] BlendWeights;
            sbyte[][] BlendIndices;
            int[] U15;

            byte U16;
            VectorFloat2[] UVCoords;
            int[] U17;

            public void Read(BinaryReader r)
            {
                U01 = r.ReadInt16();   // 0x0004, 0x0100
                
                // start of new class
                Id = r.ReadUInt32();

                uint submesh_magic = r.ReadUInt32();
                if (submesh_magic != CONST_SubMesh) throw new ResourceReadException(CONST_SubMesh, submesh_magic);

                r.ReadInt32(); // 0

                int count = r.ReadInt32();
                U02 = new int[count];       // possible indexbuffer (3 indices)
                for (int i = 0; i < U02.Length; i++) U02[i] = r.ReadInt32();

                count = r.ReadInt32();
                U03 = new int[count];
                for (int i = 0; i < U03.Length; i++) U03[i] = r.ReadInt32();

                r.ReadInt32(); // 0
                
                count = r.ReadInt32();
                U04 = new int[count];
                for (int i = 0; i < U04.Length; i++) U04[i] = r.ReadInt32();
                
                count = r.ReadInt32();
                U05 = r.ReadBytes(count);
                
                count = r.ReadInt32();
                U06 = new VectorFloat3[count];
                for (int i = 0; i < U06.Length; i++) U06[i] = new VectorFloat3(r);
                
                count = r.ReadInt32();
                U07 = new VectorFloat3[count];
                for (int i = 0; i < U07.Length; i++) U07[i] = new VectorFloat3(r);
                
                count = r.ReadInt32();
                U08 = new VectorFloat3[count];
                for (int i = 0; i < U08.Length; i++) U08[i] = new VectorFloat3(r);
                
                count = r.ReadInt32();
                U09 = new VectorFloat3[count];
                for (int i = 0; i < U09.Length; i++) U09[i] = new VectorFloat3(r);

                count = r.ReadInt32();
                U10 = new int[count];
                for (int i = 0; i < U10.Length; i++) U10[i] = r.ReadInt32();

                count = r.ReadInt32();
                Color1 = new PackedVectorByte4[count];
                for (int i = 0; i < Color1.Length; i++) Color1[i] = new PackedVectorByte4(r, true);
                
                count = r.ReadInt32();
                Color2 = new PackedVectorByte4[count];
                for (int i = 0; i < Color2.Length; i++) Color2[i] = new PackedVectorByte4(r, true);

                count = r.ReadInt32();
                BlendWeights = new VectorFloat4[count];
                for (int i = 0; i < BlendWeights.Length; i++) BlendWeights[i] = new VectorFloat4(r);
                
                count = r.ReadInt32();
                byte[] buf = r.ReadBytes(count);
                BlendIndices = new sbyte[buf.Length / 4][];
                for (int i = 0, j = 0; i < count; i += 4, j++)
                {
                    BlendIndices[j] = new sbyte[4];
                    BlendIndices[j][0] = (sbyte)buf[i];
                    BlendIndices[j][1] = (sbyte)buf[i + 1];
                    BlendIndices[j][2] = (sbyte)buf[i + 2];
                    BlendIndices[j][3] = (sbyte)buf[i + 3];
                }
                
                
                count = r.ReadInt32();
                U15 = new int[count];
                for (int i = 0; i < U15.Length; i++) U15[i] = r.ReadInt32();
                r.ReadInt32(); // 1

                // start of new class
                r.ReadUInt32(); // 0
                uint uvchannel_magic = r.ReadUInt32();
                if (uvchannel_magic != CONST_UVChannel) throw new ResourceReadException(CONST_UVChannel, uvchannel_magic);
                
                r.ReadUInt32(); // 0

                U16 = r.ReadByte();
               
                count = r.ReadInt32();

                UVCoords = new VectorFloat2[count];
                for (int i = 0; i < UVCoords.Length; i++) UVCoords[i] = new VectorFloat2(r);

                count = r.ReadInt32();
                U17 = new int[count];
                for (int i = 0; i < U17.Length; i++) U17[i] = r.ReadInt32();

            }
        }

        public class SubMeshInstanceData
        {
            public SubMeshInstanceData(BinaryReader r)
            {
                Read(r);
            }

            SubMesh U01;
            ResourceDependency U02;
            byte U03;
            SubMesh U04;
            ResourceDependency U05;
            byte U06;

            public void Read(BinaryReader r)
            {
                U01 = new SubMesh(r);
                U02 = new ResourceDependency(r);

                U03 = r.ReadByte();         // 0 | 1

                U04 = new SubMesh(r);
                U05 = new ResourceDependency(r);
                
                U06 = r.ReadByte();         // 0 | 1
                r.ReadByte();               // 3
            }
        }

        public class MeshBone
        {
            public short ui01 { get; private set; }
            public short ui02 { get; private set; }
            public short ui03 { get; private set; }
            public short ui04 { get; private set; }
            public short ui05 { get; private set; }
            public short ui06 { get; private set; }
            public short ui07 { get; private set; }
            public short ui08 { get; private set; }
            public short ui09 { get; private set; }
            public short ui10 { get; private set; }
            // known: Spine2, RightForeArm, RightHand, RightArm, LeftArm, LeftForeArm, LeftHand, Spine, Spine1, Hips, LeftUpLeg, RightUpLeg, LeftFoot, LeftFootThumb1, LeftLeg, RightFoot, RightFootThumb1, RightLeg, Neck, Head, RightHandIndex1, RightHandIndex2, RightHandIndex3, RightHandMiddle1, RightHandMiddle2, RightHandMiddle3, RightHandPinky1, RightHandPinky2, RightHandPinky3, RightHandRing1, RightHandRing2, RightHandRing3, RightHandThumb1, RightHandThumb2, RightHandThumb3, LeftHandIndex1, LeftHandIndex2, LeftHandIndex3, LeftHandMiddle1, LeftHandMiddle2, LeftHandMiddle3, LeftHandPinky1, LeftHandPinky2, LeftHandPinky3, LeftHandRing1, LeftHandRing2, LeftHandRing3, LeftHandThumb1, LeftHandThumb2, LeftHandThumb3, Object, Reference
            public uint boneNameHash;

            static readonly uint CONST_MeshBone = CRC32.ComputeHash("MeshBone");
            static readonly uint CONST_PackedOrthonormalMatrix = CRC32.ComputeHash("PackedOrthonormalMatrix");

            public MeshBone(BinaryReader r)
            {
                Read(r);    
            }

            public void Read(BinaryReader r)
            {
                // start of new class
                r.ReadInt32(); // 0
                uint magic = r.ReadUInt32();
                if (magic != CONST_MeshBone) throw new ResourceReadException(CONST_MeshBone, magic);

                // start of new class
                r.ReadInt32(); // 0
                magic = r.ReadUInt32();
                if (magic != CONST_PackedOrthonormalMatrix) throw new ResourceReadException(CONST_PackedOrthonormalMatrix, magic);
                
                ui01 = r.ReadInt16();
                ui02 = r.ReadInt16();
                ui03 = r.ReadInt16();
                ui04 = r.ReadInt16();
                ui05 = r.ReadInt16();
                ui06 = r.ReadInt16();
                ui07 = r.ReadInt16();
                ui08 = r.ReadInt16();
                ui09 = r.ReadInt16();
                ui10 = r.ReadInt16();

                /*
                double f01 = ui01 / 32767f;
                double f02 = ui02 / 32767f;
                double f03 = ui03 / 32767f;
                
                double f04 = ui04 / 32767f;
                double f05 = ui05 / 32767f;
                double f06 = ui06 / 32767f;
                
                double f07 = ui07 / 32767f;
                double f08 = ui08 / 32767f;
                double f09 = ui09 / 32767f;
                
                double f10 = ui10 / 32767f;

                double len01 = Math.Sqrt(f01 * f01 + f02 * f02 + f03 * f03); // ~1.0
                double len02 = Math.Sqrt(f04 * f04 + f05 * f05 + f06 * f06); // ~1.0
                */

                boneNameHash = r.ReadUInt32();
            }
        }

        public class MeshPrimitive
        {
            uint meshprimitive_magic;
            public int StartVert { get; private set; }
            public int NumVerts { get; private set; }
            public int StartIndex { get; private set; }
            public int NumFaces { get; private set; }

            static readonly uint CONST_MeshPrimitive = CRC32.ComputeHash("MeshPrimitive");

            public MeshPrimitive(BinaryReader r)
            {
                Read(r);
            }

            public void Read(BinaryReader r)
            {
                r.ReadInt32(); // 0
                meshprimitive_magic = r.ReadUInt32();
                if (meshprimitive_magic != CONST_MeshPrimitive) throw new ResourceReadException(CONST_MeshPrimitive, meshprimitive_magic);

                StartVert = r.ReadInt32();
                r.ReadInt32(); // 0

                NumVerts = r.ReadInt32();
                StartIndex = r.ReadInt32();
                NumFaces = r.ReadInt32();
                r.ReadInt32(); // 1
            }
        }

        public class MeshInstancingData
        {
            public class MaterialReference
            {
                public byte Type;
                public uint Ref;

                public MaterialReference(BinaryReader r)
                {
                    Type = r.ReadByte(); // 1, 3
                    if (Type != 3)
                    {
                        Ref = r.ReadUInt32();
                    }
                }
            }
            
            byte ub3;
            public byte numBones { get; private set; }
            short us4;
            short numVerts;
            public MaterialReference Material { get; private set; }
            public byte[] bones { get; private set; }

            static readonly uint CONST_MeshInstancingData = CRC32.ComputeHash("MeshInstancingData");
            
            public MeshInstancingData(BinaryReader r)
            {
                Read(r);
            }

            public void Read(BinaryReader r)
            {
                r.ReadInt32(); // 0
                uint magic = r.ReadUInt32();
                if (magic != CONST_MeshInstancingData) throw new ResourceReadException(CONST_MeshInstancingData, magic);
                ub3 = r.ReadByte(); // 0 | 1
                numBones = r.ReadByte();
                us4 = r.ReadInt16();
                numVerts = r.ReadInt16();
                Material = new MaterialReference(r);
                bones = r.ReadBytes(42);
            }
        }
        
        int U01;
        SubMeshInstanceData[] submeshes;
        public MeshBone[] bones { get; private set; }
        public MeshPrimitive[] primitives1 { get; private set; }

        // 20 0x0400
        // 20 0x0401
        // 24 0x0300
        // 32 0x0000
        public ushort vertexFlags { get; private set; }
        public byte VertexStride { get; private set; }

        public MeshPrimitive[] primitives2 { get; private set; }

        public byte[] vertexBufferRaw { get; private set; }
        public VertexBufferAccess VertexBuffer { get; private set; }
        
        public ushort[] indexBuffer { get; private set; }

        public MeshInstancingData[] meshInstancingData { get; private set; }
        public ResourceDependency[] Materials { get; private set; }

        short us9;
        short us10;
        short ui11;
        uint ui12;
        uint ui13;

        static readonly uint CONST_CompiledMesh = CRC32.ComputeHash("CompiledMesh");
        static readonly uint CONST_MeshData = CRC32.ComputeHash("MeshData");

        public Mesh(ResourceBase other)
            : base(other)
        {

        }

        public override void Load()
        {
            _baseStream.Position = dataOffset;
            BinaryReader r = new BinaryReader(_baseStream);

            U01 = r.ReadInt32();    // 0 | 1 | 2 | 4
            r.ReadByte(); // 0

            int count = r.ReadInt32();
            submeshes = new SubMeshInstanceData[count];
            for (int i = 0; i < count; i++)
            {
                submeshes[i] = new SubMeshInstanceData(r);
            }

            count = r.ReadInt32();
            bones = new MeshBone[count];
            for (int i = 0; i < count; i++) bones[i] = new MeshBone(r);

            r.ReadByte();   // 0

            // start of new class
            r.ReadInt32();  // 0
            uint magic = r.ReadUInt32();
            if (magic != CONST_CompiledMesh) throw new ResourceReadException(CONST_CompiledMesh, magic);
            
            r.ReadUInt32(); // 0

            // start of new class
            r.ReadUInt32(); // 0
            magic = r.ReadUInt32();
            if (magic != CONST_MeshData) throw new ResourceReadException(CONST_MeshData, magic);

            vertexFlags = r.ReadUInt16();
            VertexStride = r.ReadByte();
            /*****
             * stride == 32 && vertexFormat = 0
             *  0, 2, 4 = position short floats (unknown quant) maybe 1024f
             *  6 ???
             *   8,  9, 10, 11 = normal packed vector (/127f - 1f)
             *  12, 13, 14, 15 ? tangent | binormal packed vector (/127f - 1f)
             *  16, 17, 18, 19 ? tangent | binormal packed vector (/127f - 1f)
             *  20, 22 = uv short floats quant = 2048f
             *  24 = blendindices 
             *  28 = blendweights
             **********/

            count = r.ReadInt32();
            primitives1 = new MeshPrimitive[count];
            for (int i = 0; i < count; i++)
            {
                primitives1[i] = new MeshPrimitive(r);
            }

            count = r.ReadInt32();
            primitives2 = new MeshPrimitive[count];
            for (int i = 0; i < count; i++)
            {
                primitives2[i] = new MeshPrimitive(r);
            }

            count = r.ReadInt32();
            vertexBufferRaw = r.ReadBytes(count);

            VertexBuffer = new VertexBufferAccess(vertexBufferRaw, VertexStride);
            switch (VertexStride)
            { 
                case 20:
                    VertexBuffer.AddElement(0, VertexBufferAccess.ElementType.PackedShort3, VertexBufferAccess.Semantic.Position);
                    // short ??
                    VertexBuffer.AddElement(8, VertexBufferAccess.ElementType.PackedByte4, VertexBufferAccess.Semantic.Normal);
                    VertexBuffer.AddElement(12, VertexBufferAccess.ElementType.PackedByte4, VertexBufferAccess.Semantic.Tangent);
                    VertexBuffer.AddElement(16, VertexBufferAccess.ElementType.PackedShort2, VertexBufferAccess.Semantic.UV0);
                    break;
                case 24:
                    VertexBuffer.AddElement(0, VertexBufferAccess.ElementType.PackedShort3, VertexBufferAccess.Semantic.Position);
                    // short ??
                    VertexBuffer.AddElement(8, VertexBufferAccess.ElementType.PackedByte4, VertexBufferAccess.Semantic.Normal);
                    VertexBuffer.AddElement(12, VertexBufferAccess.ElementType.PackedByte4, VertexBufferAccess.Semantic.Tangent);
                    VertexBuffer.AddElement(16, VertexBufferAccess.ElementType.PackedByte4, VertexBufferAccess.Semantic.Binormal);
                    VertexBuffer.AddElement(20, VertexBufferAccess.ElementType.PackedShort2, VertexBufferAccess.Semantic.UV0);
                    break;
                case 32:
                    VertexBuffer.AddElement(0, VertexBufferAccess.ElementType.PackedShort3, VertexBufferAccess.Semantic.Position);
                    // short ??
                    VertexBuffer.AddElement(8, VertexBufferAccess.ElementType.PackedByte4, VertexBufferAccess.Semantic.Normal);
                    VertexBuffer.AddElement(12, VertexBufferAccess.ElementType.PackedByte4, VertexBufferAccess.Semantic.Tangent);
                    VertexBuffer.AddElement(16, VertexBufferAccess.ElementType.PackedByte4, VertexBufferAccess.Semantic.Binormal);
                    VertexBuffer.AddElement(20, VertexBufferAccess.ElementType.PackedShort2, VertexBufferAccess.Semantic.UV0);
                    VertexBuffer.AddBlendIndicesElement(24);
                    VertexBuffer.AddElement(28, VertexBufferAccess.ElementType.PackedByte4U, VertexBufferAccess.Semantic.BlendWeights);
                    break;
                default:
                    throw new NotSupportedException("unexpected vertex stride");
            }

            count = r.ReadInt32();
            byte[] _ib = r.ReadBytes(count);
            indexBuffer = new ushort[count / 2];
            for(int i = 0,j=0; i < count; i+= 2,j++)
            {
                indexBuffer[j] = BitConverter.ToUInt16(_ib, i);
            }
            _ib = null;

            r.ReadInt32(); // 0
            r.ReadInt32(); // 0
            r.ReadInt32(); // 0
            r.ReadInt32(); // 0

            count = r.ReadInt32();
            meshInstancingData = new MeshInstancingData[count];
            for (int i = 0; i < count; i++) meshInstancingData[i] = new MeshInstancingData(r);

            r.ReadInt32(); // 36
            r.ReadInt32(); // 32

            count = r.ReadInt32();
            Materials = new ResourceDependency[count];
            for (int i = 0; i < count; i++)
            {
                Materials[i] = new ResourceDependency(r);
                Materials[i].Resolve(this);
            }

            us9 = r.ReadInt16();    // 0x0000, 0x0001, 0x0100
            us10 = r.ReadInt16();   // = 0 if us9 == 0x0000 | 0x0001
            ui11 = r.ReadInt16();   // = 0x0010 if us9 != 0x0000 | 0x0001
            ui12 = r.ReadUInt32();
            ui13 = r.ReadUInt32();

            IsLoaded = true;
        }

        public override void Unload()
        {
            submeshes = null;
            bones = null;
            primitives1 = null;
            primitives2 = null;
            meshInstancingData = null;
            Materials = null;
            vertexBufferRaw = null;
            indexBuffer = null;
            IsLoaded = false;
        }

        public override object GetData()
        {
            if (!IsLoaded) Load();
            return this;
        }
    }
}
