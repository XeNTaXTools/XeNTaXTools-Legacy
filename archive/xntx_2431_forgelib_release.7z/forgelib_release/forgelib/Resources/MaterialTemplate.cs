﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using forgelib.Nodes;
using forgelib.Utils;
using forgelib.Hash;
using System.ComponentModel;

namespace forgelib.Resources
{
    [KnownTypeRegistry.KnownType("MaterialTemplate")]
    [TypeConverter(typeof(ExpandableObjectConverter))]
    public class MaterialTemplate : ResourceBase
    {
        public enum ShaderFragmentType
        {
            PixelShader,
            VertexShader
        }

        #region class lookup
        public class KnownMaterialTemplateClassAttribute : Attribute
        {
            public readonly string Name;
            public readonly uint Id;

            public KnownMaterialTemplateClassAttribute(string name)
            {
                this.Name = name;
                Id = CRC32.ComputeHash(name);
            }
        }

        static class KnownMaterialTemplateClassRegistry
        {
            static Dictionary<uint, Type> typeLookup;
            static Dictionary<uint, string> typeNameLookup;

            private static void buildTypeLookup()
            {
                typeLookup = new Dictionary<uint, Type>();
                typeNameLookup = new Dictionary<uint, string>();

                foreach (Type type in System.Reflection.Assembly.GetAssembly(typeof(KnownMaterialTemplateClassRegistry)).GetTypes())
                {
                    if (type.IsSubclassOf(typeof(MaterialTemplateClass)) == true)
                    {
                        object[] attributes = type.GetCustomAttributes(typeof(KnownMaterialTemplateClassAttribute), false);
                        if (attributes.Length == 1)
                        {
                            KnownMaterialTemplateClassAttribute attribute = (KnownMaterialTemplateClassAttribute)attributes[0];
                            typeLookup.Add(attribute.Id, type);
                            typeNameLookup.Add(attribute.Id, attribute.Name);
                        }
                    }
                }
            }

            public static string GetTypeName(uint typeId)
            {
                if (typeNameLookup == null)
                {
                    buildTypeLookup();
                }

                if (typeNameLookup.ContainsKey(typeId))
                {
                    return typeNameLookup[typeId];
                }

                return null;
            }

            public static Type GetType(uint typeId)
            {
                if (typeLookup == null)
                {
                    buildTypeLookup();
                }

                if (typeLookup.ContainsKey(typeId))
                {
                    return typeLookup[typeId];
                }

                return null;
            }
        }
        #endregion
        /// <summary>
        /// base class
        /// </summary>
        [TypeConverter(typeof(ExpandableObjectConverter))]
        public class MaterialTemplateClass
        {
            public uint Id { get; private set; }
            
            [Browsable(false)]
            public uint TypeId { get; private set; }

            public string Type { get { return KnownMaterialTemplateClassRegistry.GetTypeName(TypeId); } }

            protected ClassReader reader;

            public MaterialTemplateClass(MaterialTemplateClass other)
            {
                Id = other.Id;
                TypeId = other.TypeId;
                reader = other.reader;
            }

            public MaterialTemplateClass(BinaryReader r, ClassReader p)
            {
                reader = p;
                Read(r);
            }

            public void Read(BinaryReader r)
            {
                Id = r.ReadUInt32();
                TypeId = r.ReadUInt32();
            }

            public override string ToString()
            {
                return string.Format("0x{0:x8} {1}", Id, Type);
            }
        }

        #region known classes

        [KnownMaterialTemplateClass("CompiledMaterialTemplate")]
        public class CompiledMaterialTemplate : MaterialTemplateClass
        {
            public uint EntryId { get; private set; }
            public ushort US01 { get; private set; }     // 26
            public ushort US02 { get; private set; }     // 111 | 116
            public uint US03 { get; private set; }       // hash
            public uint US04 { get; private set; }       // hash
            public uint US05 { get; private set; }       // 01000100 | 01010100
            public uint US06 { get; private set; }      // 01000000 | 01000100 | 01010100

            public ShaderPermutation[] VertexShaderFragments { get; private set; }
            public ShaderPermutation[] PixelShaderFragments { get; private set; }
            public LightingShaderPermutation[] PixelShaderFragmentsLighting { get; private set; }

            public CompiledMaterialTemplate(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                r.ReadByte(); // 1 numEntryIds ?
                EntryId = r.ReadUInt32();

                US01 = r.ReadUInt16();
                US02 = r.ReadUInt16();

                r.ReadUInt32(); // 32
                US03 = r.ReadUInt32();
                US04 = r.ReadUInt32();
                US05 = r.ReadUInt32();
                US06 = r.ReadUInt32();

                // vertex
                uint count = r.ReadUInt32();
                VertexShaderFragments = new ShaderPermutation[count];
                for (int i = 0; i < count; i++)
                {
                    r.ReadByte(); // 0
                    VertexShaderFragments[i] = reader.ReadProperty<ShaderPermutation>(r);
                }

                // pixel
                count = r.ReadUInt32();
                PixelShaderFragments = new ShaderPermutation[count];
                for (int i = 0; i < count; i++)
                {
                    r.ReadByte(); // 0
                    PixelShaderFragments[i] = reader.ReadProperty<ShaderPermutation>(r);
                }

                // pixel
                count = r.ReadUInt32();
                PixelShaderFragmentsLighting = new LightingShaderPermutation[count];
                for (int i = 0; i < count; i++)
                {
                    r.ReadByte(); // 0
                    PixelShaderFragmentsLighting[i] = reader.ReadProperty<LightingShaderPermutation>(r);
                }
            }
        }

        [KnownMaterialTemplateClass("ShaderParameter")]
        public class ShaderParameter : MaterialTemplateClass
        {
            public enum ParameterValueType
            { 
                ConstantFloat,
                ConstantVector,
                TextureObject,
                CubeMapObject,
                UVTransform
            }
            
            public uint ParamNameHash { get; private set; } // linked to an editablematerialproperty name...
            public string ParamName { get { return HashLookup.GetHashedString(ParamNameHash); } }
            
            public int Register { get; private set; }
            public int U01 { get; private set; }
            public ParameterValueType ValueType { get; private set; }
            public byte U02 { get; private set; }
            public byte U03 { get; private set; }
            public uint U04 { get; private set; }

            public ShaderParameter(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                ParamNameHash = r.ReadUInt32();
                Register = r.ReadInt32();
                U01 = r.ReadInt32();
                ValueType = (ParameterValueType)r.ReadInt32();
                U02 = r.ReadByte(); 
                U03 = r.ReadByte();
                U04 = r.ReadUInt32();
            }
        }

        [KnownMaterialTemplateClass("ShaderPermutation")]
        public class ShaderPermutation : MaterialTemplateClass
        {
            private Stream _baseStream;
            private long _dataOffset;
            private int _dataSize;

            // pixel  00 00 XX XX 00 00 XX XX XX XX XX XX XX XX XX XX XX XX 00 00 00 00 00 XX 00
            // vertex 00 00 01 00 00 01 00 00 XX 00 00 00 00 00 00 00 00 00 XX 00 00 00 00 00 00
            // XX = 00 | 01
            public byte[] U01 { get; private set; }
            public ushort U02 { get; private set; }
            public ushort U03 { get; private set; }

            public ShaderParameter[] parameters { get; private set; }

            public uint U04 { get; private set; }
            public uint U05 { get; private set; }

            public ShaderFragmentType FragmentType { get; private set; }

            public ShaderPermutation(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                _baseStream = r.BaseStream;
                U01 = r.ReadBytes(25);
                U02 = r.ReadUInt16();
                U03 = r.ReadUInt16();

                _dataSize = r.ReadInt32();
                _dataOffset = r.BaseStream.Position;

                uint type = r.ReadUInt32();
                /*
                // ffff0300 pixel
                // fffe0300 vertex
                if (type != 0xffff0300 && type != 0xfffe0300)
                {
                    System.Diagnostics.Debugger.Break();
                }
                */
                FragmentType = (type == 0xffff0300) ? ShaderFragmentType.PixelShader : ShaderFragmentType.VertexShader;

                r.BaseStream.Position += _dataSize - 4;

                int count = r.ReadInt32();
                parameters = new ShaderParameter[count];
                for (int i = 0; i < count; i++)
                {
                    parameters[i] = reader.ReadProperty<ShaderParameter>(r);
                }

                U04 = r.ReadUInt32();
                U05 = r.ReadUInt32();
            }
        }

        [KnownMaterialTemplateClass("LightingShaderPermutation")]
        public class LightingShaderPermutation : MaterialTemplateClass
        {
            private Stream _baseStream;
            private long _dataOffset;
            private int _dataSize;

            public short us1 { get; private set; } // always 1
            public short us2 { get; private set; } // 0 - 5
            public uint ui15 { get; private set; } // 0 - 210
            public uint ui16 { get; private set; }
            public uint ui17 { get; private set; }

            public ShaderFragmentType FragmentType { get; private set; }

            public LightingShaderPermutation(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                _baseStream = r.BaseStream;

                us1 = r.ReadInt16();
                us2 = r.ReadInt16();
                ui15 = r.ReadUInt32();

                _dataSize = r.ReadInt32();
                _dataOffset = r.BaseStream.Position;

                uint type = r.ReadUInt32();
                /*
                // ffff0300 pixel
                // fffe0300 vertex
                if (type != 0xffff0300 && type != 0xfffe0300)
                {
                    System.Diagnostics.Debugger.Break();
                }
                */
                FragmentType = (type == 0xffff0300) ? ShaderFragmentType.PixelShader : ShaderFragmentType.VertexShader;

                r.BaseStream.Position += _dataSize - 4;

                ui16 = r.ReadUInt32();
                ui17 = r.ReadUInt32();
            }
        }

        [KnownMaterialTemplateClass("IColor")]
        public class IColor : MaterialTemplateClass
        {
            public int color { get; private set; }

            public IColor(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                color = r.ReadInt32();
            }

            public override string ToString()
            {
                return string.Format("#{0:x8}", color);
            }
        }

        [KnownMaterialTemplateClass("MetaOperator")]
        public class MetaOperator : MaterialTemplateClass
        {
            [TypeConverter(typeof(ExpandableObjectConverter))]
            public class MaterialProperty
            {
                public ushort us1 { get; private set; }
                public MaterialTemplateClass property { get; private set; }

                public MaterialProperty(BinaryReader r, ClassReader p)
                {
                    us1 = r.ReadUInt16();
                    property = p.ReadProperty(r);
                }

                public override string ToString()
                {
                    return string.Format("0x{0:x4} {1}", us1, property);
                }
            }

            public MaterialProperty[] properties { get; private set; }
            public EditableMaterialProperty[] editables { get; private set; }

            public MetaOperator(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                int count = r.ReadInt32();

                properties = new MaterialProperty[count];
                for (int i = 0; i < count; i++)
                {
                    properties[i] = new MaterialProperty(r, reader);
                }

                count = r.ReadInt32();
                editables = new EditableMaterialProperty[count];
                for (int i = 0; i < count; i++)
                {
                    editables[i] = new EditableMaterialProperty(r, reader);
                }
            }
        }

        [KnownMaterialTemplateClass("EditableMaterialProperty")]
        public class EditableMaterialProperty : MaterialTemplateClass
        {
            public InputConnector connector { get; private set; }
            public uint propertyType { get; private set; }

            public string Name1 { get; private set; }
            public string Name2 { get; private set; }

            public Dictionary<string, string> Annotations { get; private set; }

            static readonly uint CONST_Value = CRC32.ComputeHash("Value");
            static readonly uint CONST_Texture = CRC32.ComputeHash("Texture");
            static readonly uint CONST_Parameters = CRC32.ComputeHash("Parameters");

            public EditableMaterialProperty(BinaryReader r, ClassReader p)
                : base(r, p)
            {
                reader = p;

                connector = new InputConnector(r, reader);

                propertyType = r.ReadUInt32();
                if (!(propertyType == CONST_Value || propertyType == CONST_Texture || propertyType == CONST_Parameters))
                {
                    throw new NotSupportedException(string.Format("unknown editablematerial property: 0x{0:x8}", propertyType));
                }

                Name1 = readString(r);
                Name2 = readString(r);

                int count = r.ReadInt32();
                string[] _annotationNames = new string[count];
                if (count > 0)
                {
                    for (int i = 0; i < count; i++)
                    {
                        _annotationNames[i] = readString(r);
                    }
                }

                count = r.ReadInt32();
                string[] _annotationValues = new string[count];
                if (count > 0)
                {
                    for (int i = 0; i < count; i++)
                    {
                        _annotationValues[i] = readString(r);
                    }
                }
                if (count != 0)
                {
                    Annotations = new Dictionary<string, string>();
                    for (int i = 0; i < count; i++)
                    {
                        Annotations.Add(_annotationNames[i], _annotationValues[i]);
                    }
                }
            }

            private static string readString(BinaryReader r)
            {
                int strlen = r.ReadInt32();
                if (strlen != 0)
                {
                    return Encoding.ASCII.GetString(r.ReadBytes(strlen + 1)).TrimEnd('\0');
                }
                return null;
            }

            public override string ToString()
            {
                return string.Format("{0} '{1}'", connector.ConnectedOutput.Type, Name1);
            }
        }

        [KnownMaterialTemplateClass("ConstantFloatValue")]
        public class ConstantFloatValue : MaterialTemplateClass
        {
            public uint U1 { get; private set; }
            public byte U2 { get; private set; }
            public FloatOutput U3 { get; private set; }
            public float x { get; private set; }

            public ConstantFloatValue(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                U1 = r.ReadUInt32(); // 0
                U2 = r.ReadByte(); // 0 | 1
                U3 = reader.ReadProperty<FloatOutput>(r);
                x = r.ReadSingle();
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2:x8} {3:x2} {4} {5:0.000000})", Id, Type, U1, U2, U3, x);
            }
        }

        [KnownMaterialTemplateClass("ConstantQuaternionValue")]
        public class ConstantQuaternionValue : MaterialTemplateClass
        {
            public uint U1 { get; private set; }
            public byte U2 { get; private set; }
            public QuaternionOutput U3 { get; private set; }
            public float x { get; private set; }
            public float y { get; private set; }
            public float z { get; private set; }
            public float w { get; private set; }

            public ConstantQuaternionValue(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                U1 = r.ReadUInt32(); // 0
                U2 = r.ReadByte(); // 0 | 1
                U3 = reader.ReadProperty<QuaternionOutput>(r);
                x = r.ReadSingle();
                y = r.ReadSingle();
                z = r.ReadSingle();
                w = r.ReadSingle();
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2:x8} {3:x2} {4} {5:0.000000} {6:0.000000} {7:0.000000} {8:0.000000})", Id, Type, U1, U2, U3, x, y, z, w);
            }
        }

        [KnownMaterialTemplateClass("ConstantVectorValue")]
        public class ConstantVectorValue : MaterialTemplateClass
        {
            public uint U1 { get; private set; }
            public byte U2 { get; private set; }
            public VectorOutput U3 { get; private set; }
            public float x { get; private set; }
            public float y { get; private set; }
            public float z { get; private set; }
            public float w { get; private set; }

            public ConstantVectorValue(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                U1 = r.ReadUInt32(); // 0
                U2 = r.ReadByte(); // 0 | 1
                U3 = reader.ReadProperty<VectorOutput>(r);
                x = r.ReadSingle();
                y = r.ReadSingle();
                z = r.ReadSingle();
                w = r.ReadSingle();
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2:x8} {3:x2} {4} {5:0.000000} {6:0.000000} {7:0.000000} {8:0.000000})", Id, Type, U1, U2, U3, x, y, z, w);
            }
        }

        [KnownMaterialTemplateClass("CubeMapInput")]
        public class CubeMapInput : MaterialTemplateClass
        {
            public InputConnector U1 { get; private set; }

            public CubeMapInput(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                U1 = new InputConnector(r, reader);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2})", Id, Type, U1);
            }
        }

        [KnownMaterialTemplateClass("CubeMapObject")]
        public class CubeMapObject : MaterialTemplateClass
        {
            public CubeMapOutput cubemapOutput { get; private set; }
            public byte U1 { get; private set; }
            public TextureSelector textureSelector { get; private set; }

            public CubeMapObject(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                cubemapOutput = reader.ReadProperty<CubeMapOutput>(r);
                U1 = r.ReadByte();
                textureSelector = reader.ReadProperty<TextureSelector>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3} {4})", Id, Type, cubemapOutput, U1, textureSelector);
            }
        }

        [KnownMaterialTemplateClass("CubeMapOutput")]
        public class CubeMapOutput : MaterialTemplateClass
        {
            public CubeMapOutput(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {

            }

            public override string ToString()
            {
                return "(" + base.ToString() + ")";
            }
        }

        [KnownMaterialTemplateClass("CubeMapSource")]
        public class CubeMapSource : MaterialTemplateClass
        {
            public VectorOutput vectorOutput1 { get; private set; }
            public FloatOutput floatOutput1 { get; private set; }
            public FloatOutput floatOutput2 { get; private set; }
            public FloatOutput floatOutput3 { get; private set; }
            public FloatOutput floatOutput4 { get; private set; }
            public CubeMapInput cubemapInput { get; private set; }
            public VectorInput vectorInput1 { get; private set; }

            public CubeMapSource(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                vectorOutput1 = reader.ReadProperty<VectorOutput>(r);
                floatOutput1 = reader.ReadProperty<FloatOutput>(r);
                floatOutput2 = reader.ReadProperty<FloatOutput>(r);
                floatOutput3 = reader.ReadProperty<FloatOutput>(r);
                floatOutput4 = reader.ReadProperty<FloatOutput>(r);
                cubemapInput = reader.ReadProperty<CubeMapInput>(r);
                vectorInput1 = reader.ReadProperty<VectorInput>(r);
            }
            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3} {4} {5} {6} {7} {8})", Id, Type, vectorOutput1, floatOutput1, floatOutput2, floatOutput3, floatOutput4, cubemapInput, vectorInput1);
            }
        }

        [KnownMaterialTemplateClass("CubeReflection")]
        public class CubeReflection : MaterialTemplateClass
        {
            public CubeMapInput cubemapInput { get; private set; }
            public VectorOutput vectorOutput1 { get; private set; }
            public FloatOutput floatOutput1 { get; private set; }
            public FloatOutput floatOutput2 { get; private set; }
            public FloatOutput floatOutput3 { get; private set; }
            public FloatOutput floatOutput4 { get; private set; }

            public CubeReflection(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                cubemapInput = reader.ReadProperty<CubeMapInput>(r);
                vectorOutput1 = reader.ReadProperty<VectorOutput>(r);
                floatOutput1 = reader.ReadProperty<FloatOutput>(r);
                floatOutput2 = reader.ReadProperty<FloatOutput>(r);
                floatOutput3 = reader.ReadProperty<FloatOutput>(r);
                floatOutput4 = reader.ReadProperty<FloatOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3} {4} {5})",
                    Id,
                    Type,
                    cubemapInput,
                    vectorOutput1,
                    floatOutput1,
                    floatOutput2,
                    floatOutput3,
                    floatOutput4);
            }
        }

        [KnownMaterialTemplateClass("DepthBufferSource")]
        public class DepthBufferSource : MaterialTemplateClass
        {
            public FloatOutput floatoutput1 { get; private set; }
            public FloatOutput floatoutput2 { get; private set; }
            public VectorOutput vectoroutput { get; private set; }

            public DepthBufferSource(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                floatoutput1 = reader.ReadProperty<FloatOutput>(r);
                floatoutput2 = reader.ReadProperty<FloatOutput>(r);
                vectoroutput = reader.ReadProperty<VectorOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3} {4})", Id, Type, floatoutput1, floatoutput2, vectoroutput);
            }
        }

        [KnownMaterialTemplateClass("FloatInput")]
        public class FloatInput : MaterialTemplateClass
        {
            public InputConnector U1 { get; private set; }

            public FloatInput(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                U1 = new InputConnector(r, reader);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2})", Id, Type, U1);
            }
        }

        [KnownMaterialTemplateClass("FloatToVector")]
        public class FloatToVector : MaterialTemplateClass
        {
            public VectorOutput vectorOutput { get; private set; }
            public FloatInput floatInput1 { get; private set; }
            public FloatInput floatInput2 { get; private set; }
            public FloatInput floatInput3 { get; private set; }
            public FloatInput floatInput4 { get; private set; }

            public FloatToVector(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                vectorOutput = reader.ReadProperty<VectorOutput>(r);
                floatInput1 = reader.ReadProperty<FloatInput>(r);
                floatInput2 = reader.ReadProperty<FloatInput>(r);
                floatInput3 = reader.ReadProperty<FloatInput>(r);
                floatInput4 = reader.ReadProperty<FloatInput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3} {4} {5} {6})",
                    Id,
                    Type,
                    vectorOutput,
                    floatInput1,
                    floatInput2,
                    floatInput3,
                    floatInput4);
            }
        }

        [KnownMaterialTemplateClass("FloatOutput")]
        public class FloatOutput : MaterialTemplateClass
        {
            public FloatOutput(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {

            }

            public override string ToString()
            {
                return "(" + base.ToString() + ")";
            }
        }

        [KnownMaterialTemplateClass("LightingDiffuse")]
        public class LightingDiffuse : MaterialTemplateClass
        {
            public VectorInput vectorinput { get; private set; }
            public TextureInput textureinput { get; private set; }

            public LightingDiffuse(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                vectorinput = reader.ReadProperty<VectorInput>(r);
                textureinput = reader.ReadProperty<TextureInput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3})", Id, Type, vectorinput, textureinput);
            }
        }

        [KnownMaterialTemplateClass("LightingEmissive")]
        public class LightingEmissive : MaterialTemplateClass
        {
            public VectorInput vector1 { get; private set; }
            public byte U1 { get; private set; }

            public LightingEmissive(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                vector1 = reader.ReadProperty<VectorInput>(r);
                U1 = r.ReadByte();
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3:X2})", Id, Type, vector1, U1);
            }
        }

        [KnownMaterialTemplateClass("LightingHairAnisotropic")]
        public class LightingHairAnisotropic : MaterialTemplateClass
        {
            public FloatInput float1 { get; private set; }
            public FloatInput float2 { get; private set; }
            public FloatInput float3 { get; private set; }
            public VectorInput vector1 { get; private set; }
            public FloatInput float4 { get; private set; }
            public VectorInput vector2 { get; private set; }
            public FloatInput float5 { get; private set; }

            public LightingHairAnisotropic(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                float1 = reader.ReadProperty<FloatInput>(r);
                float2 = reader.ReadProperty<FloatInput>(r);
                float3 = reader.ReadProperty<FloatInput>(r);
                vector1 = reader.ReadProperty<VectorInput>(r);
                float4 = reader.ReadProperty<FloatInput>(r);
                vector2 = reader.ReadProperty<VectorInput>(r);
                float5 = reader.ReadProperty<FloatInput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3} {4} {5} {6} {7} {8})",
                    Id,
                    Type,
                    float1, float2, float3,
                    vector1, float4, vector2, float5);
            }
        }

        [KnownMaterialTemplateClass("LightingOrenNayar")]
        public class LightingOrenNayar : MaterialTemplateClass
        {
            public FloatInput float1 { get; private set; }

            public LightingOrenNayar(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                float1 = reader.ReadProperty<FloatInput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2})", Id, Type, float1);
            }
        }

        [KnownMaterialTemplateClass("LightingRim")]
        public class LightingRim : MaterialTemplateClass
        {
            public VectorInput vector1 { get; private set; }
            public FloatInput float1 { get; private set; }

            public LightingRim(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                vector1 = reader.ReadProperty<VectorInput>(r);
                float1 = reader.ReadProperty<FloatInput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3})", Id, Type, vector1, float1);
            }
        }

        [KnownMaterialTemplateClass("LightingRimPerLight")]
        public class LightingRimPerLight : MaterialTemplateClass
        {
            public VectorInput vector1 { get; private set; }
            public FloatInput float1 { get; private set; }

            public LightingRimPerLight(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                vector1 = reader.ReadProperty<VectorInput>(r);
                float1 = reader.ReadProperty<FloatInput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3})", Id, Type, vector1, float1);
            }
        }

        [KnownMaterialTemplateClass("LightingSpecular")]
        public class LightingSpecular : MaterialTemplateClass
        {
            public VectorInput vector1 { get; private set; }
            public FloatInput float1 { get; private set; }
            public FloatInput float2 { get; private set; }
            public FloatInput float3 { get; private set; }
            int U1;

            public LightingSpecular(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                vector1 = reader.ReadProperty<VectorInput>(r);
                float1 = reader.ReadProperty<FloatInput>(r);
                float2 = reader.ReadProperty<FloatInput>(r);
                float3 = reader.ReadProperty<FloatInput>(r);
                U1 = r.ReadInt32(); // 1
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3} {4} {5} {6:x8})", Id, Type, vector1, float1, float2, float3, U1);
            }
        }

        [KnownMaterialTemplateClass("LightingStack")]
        public class LightingStack : MaterialTemplateClass
        {
            public VectorInput vector1 { get; private set; }
            public VectorInput vector2 { get; private set; }
            public VectorInput vector3 { get; private set; }
            public FloatInput float1 { get; private set; }
            public FloatInput float2 { get; private set; }
            public FloatInput float3 { get; private set; }
            public InputConnector[] inputs { get; private set; }
            public int U1 { get; private set; }

            public LightingStack(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                vector1 = reader.ReadProperty<VectorInput>(r);
                vector2 = reader.ReadProperty<VectorInput>(r);
                vector3 = reader.ReadProperty<VectorInput>(r);

                float1 = reader.ReadProperty<FloatInput>(r);
                float2 = reader.ReadProperty<FloatInput>(r);
                float3 = reader.ReadProperty<FloatInput>(r);
                int count = r.ReadInt32();
                inputs = new InputConnector[count];
                for (int i = 0; i < count; i++)
                {
                    inputs[i] = new InputConnector(r, reader);
                }
                U1 = r.ReadInt32();
            }

            public override string ToString()
            {
                string[] tmp = new string[inputs.Length];
                for (int i = 0; i < tmp.Length; i++) tmp[i] = inputs[i].ToString();

                return string.Format("(0x{0:x8} {1} {2} {3} {4} {5} {6} {7} {8} {9:x8})",
                    Id,
                    Type,
                    vector1,
                    vector2,
                    vector3,
                    float1,
                    float2,
                    float3,
                    string.Join(" ", tmp),
                    U1);
            }
        }

        [KnownMaterialTemplateClass("LightingTranslucency")]
        public class LightingTranslucency : MaterialTemplateClass
        {
            public VectorInput vector1 { get; private set; }

            public LightingTranslucency(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                vector1 = reader.ReadProperty<VectorInput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2})",
                    Id,
                    Type,
                    vector1);
            }
        }

        [KnownMaterialTemplateClass("LightingSubSurface")]
        public class LightingSubSurface : MaterialTemplateClass
        {
            public FloatInput float1 { get; private set; }
            public FloatInput float2 { get; private set; }
            public FloatInput float3 { get; private set; }
            public VectorInput vector1 { get; private set; }

            public LightingSubSurface(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                float1 = reader.ReadProperty<FloatInput>(r);
                float2 = reader.ReadProperty<FloatInput>(r);
                float3 = reader.ReadProperty<FloatInput>(r);
                vector1 = reader.ReadProperty<VectorInput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3} {4} {5})",
                    Id,
                    Type,
                    float1, float2, float3, vector1);
            }
        }

        [KnownMaterialTemplateClass("MeshModifier")]
        public class MeshModifier : MaterialTemplateClass
        {
            public VectorInput vectorInput1 { get; private set; }
            public VectorInput vectorInput2 { get; private set; }
            public VectorInput vectorInput3 { get; private set; }
            public VectorInput vectorInput4 { get; private set; }
            public VectorInput vectorInput5 { get; private set; }
            public VectorInput vectorInput6 { get; private set; }
            public VectorInput vectorInput7 { get; private set; }

            public MeshModifier(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                vectorInput1 = reader.ReadProperty<VectorInput>(r);
                vectorInput2 = reader.ReadProperty<VectorInput>(r);
                vectorInput3 = reader.ReadProperty<VectorInput>(r);
                vectorInput4 = reader.ReadProperty<VectorInput>(r);
                vectorInput5 = reader.ReadProperty<VectorInput>(r);
                vectorInput6 = reader.ReadProperty<VectorInput>(r);
                vectorInput7 = reader.ReadProperty<VectorInput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3} {4} {5} {6} {7} {8})",
                    Id,
                    Type,
                    vectorInput1,
                    vectorInput2,
                    vectorInput3,
                    vectorInput4,
                    vectorInput5,
                    vectorInput6,
                    vectorInput7);
            }
        }

        [KnownMaterialTemplateClass("MeshSource")]
        public class MeshSource : MaterialTemplateClass
        {
            public VectorOutput vectorOutput1 { get; private set; }
            public VectorOutput vectorOutput2 { get; private set; }
            public VectorOutput vectorOutput3 { get; private set; }
            public VectorOutput vectorOutput4 { get; private set; }
            public VectorOutput vectorOutput5 { get; private set; }
            public VectorOutput vectorOutput6 { get; private set; }
            public VectorOutput vectorOutput7 { get; private set; }
            public VectorOutput vectorOutput8 { get; private set; }
            public FloatOutput floatOutput { get; private set; }
            public int U1 { get; private set; }
            public byte U2 { get; private set; }

            public MeshSource(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                vectorOutput1 = reader.ReadProperty<VectorOutput>(r);
                vectorOutput2 = reader.ReadProperty<VectorOutput>(r);
                vectorOutput3 = reader.ReadProperty<VectorOutput>(r);
                vectorOutput4 = reader.ReadProperty<VectorOutput>(r);
                vectorOutput5 = reader.ReadProperty<VectorOutput>(r);
                vectorOutput6 = reader.ReadProperty<VectorOutput>(r);
                vectorOutput7 = reader.ReadProperty<VectorOutput>(r);
                vectorOutput8 = reader.ReadProperty<VectorOutput>(r);
                floatOutput = reader.ReadProperty<FloatOutput>(r);
                U1 = r.ReadInt32();
                U2 = r.ReadByte();
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3} {4} {5} {6} {7} {8} {9} {10} 0x{11:x8} 0x{12:x2})",
                    Id,
                    Type,
                    vectorOutput1,
                    vectorOutput2,
                    vectorOutput3,
                    vectorOutput4,
                    vectorOutput5,
                    vectorOutput6,
                    vectorOutput7,
                    vectorOutput8,
                    floatOutput,
                    U1, U2);
            }
        }

        [KnownMaterialTemplateClass("OperatorBiasVector")]
        public class OperatorBiasVector : MaterialTemplateClass
        {
            public VectorInput input { get; private set; }
            public VectorOutput output { get; private set; }

            public OperatorBiasVector(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                input = reader.ReadProperty<VectorInput>(r);
                output = reader.ReadProperty<VectorOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3})", Id, Type, input, output);
            }
        }

        [KnownMaterialTemplateClass("OperatorBlendFloats")]
        public class OperatorBlendFloats : MaterialTemplateClass
        {
            public FloatInput float1 { get; private set; }
            public FloatInput float2 { get; private set; }
            public FloatInput float3 { get; private set; }
            public FloatOutput output { get; private set; }

            public OperatorBlendFloats(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                float1 = reader.ReadProperty<FloatInput>(r);
                float2 = reader.ReadProperty<FloatInput>(r);
                float3 = reader.ReadProperty<FloatInput>(r);
                output = reader.ReadProperty<FloatOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3} {4} {5})", Id, Type, float1, float2, float3, output);
            }
        }

        [KnownMaterialTemplateClass("OperatorBlendVectors")]
        public class OperatorBlendVectors : MaterialTemplateClass
        {
            public VectorInput vectorInput1 { get; private set; }
            public VectorInput vectorInput2 { get; private set; }
            public FloatInput float1 { get; private set; }
            public VectorOutput outputVector { get; private set; }

            public OperatorBlendVectors(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                vectorInput1 = reader.ReadProperty<VectorInput>(r);
                vectorInput2 = reader.ReadProperty<VectorInput>(r);
                float1 = reader.ReadProperty<FloatInput>(r);
                outputVector = reader.ReadProperty<VectorOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3} {4} {5})", Id, Type, vectorInput1, vectorInput2, float1, outputVector);
            }
        }

        [KnownMaterialTemplateClass("OperatorCeilFloat")]
        public class OperatorCeilFloat : MaterialTemplateClass
        {
            public FloatInput float1 { get; private set; }
            public FloatOutput output { get; private set; }

            public OperatorCeilFloat(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                float1 = reader.ReadProperty<FloatInput>(r);
                output = reader.ReadProperty<FloatOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3})", Id,

                    Type, float1, output);
            }
        }

        [KnownMaterialTemplateClass("OperatorDeBiasVector")]
        public class OperatorDeBiasVector : MaterialTemplateClass
        {
            public VectorInput input { get; private set; }
            public VectorOutput output { get; private set; }

            public OperatorDeBiasVector(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                input = reader.ReadProperty<VectorInput>(r);
                output = reader.ReadProperty<VectorOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3})", Id, Type, input, output);
            }
        }

        [KnownMaterialTemplateClass("OperatorDistance")]
        public class OperatorDistance : MaterialTemplateClass
        {
            public VectorInput vector1 { get; private set; }
            public VectorInput vector2 { get; private set; }
            public FloatOutput output { get; private set; }

            public OperatorDistance(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                vector1 = reader.ReadProperty<VectorInput>(r);
                vector2 = reader.ReadProperty<VectorInput>(r);
                output = reader.ReadProperty<FloatOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3} {4})", Id, Type, vector1, vector2, output);
            }
        }

        [KnownMaterialTemplateClass("OperatorDot3")]
        public class OperatorDot3 : MaterialTemplateClass
        {
            public VectorInput vector1 { get; private set; }
            public VectorInput vector2 { get; private set; }
            public FloatOutput output { get; private set; }

            public OperatorDot3(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                vector1 = reader.ReadProperty<VectorInput>(r);
                vector2 = reader.ReadProperty<VectorInput>(r);
                output = reader.ReadProperty<FloatOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3} {4})", Id, Type, vector1, vector2, output);
            }
        }

        [KnownMaterialTemplateClass("OperatorFloatAbs")]
        public class OperatorFloatAbs : MaterialTemplateClass
        {
            public FloatInput float1 { get; private set; }
            public FloatOutput output { get; private set; }

            public OperatorFloatAbs(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                float1 = reader.ReadProperty<FloatInput>(r);
                output = reader.ReadProperty<FloatOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3})", Id, Type, float1, output);
            }
        }

        [KnownMaterialTemplateClass("OperatorFloatAdd")]
        public class OperatorFloatAdd : MaterialTemplateClass
        {
            public FloatInput float1 { get; private set; }
            public FloatInput float2 { get; private set; }
            public FloatOutput output { get; private set; }

            public OperatorFloatAdd(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                float1 = reader.ReadProperty<FloatInput>(r);
                float2 = reader.ReadProperty<FloatInput>(r);
                output = reader.ReadProperty<FloatOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3} {4})", Id, Type, float1, float2, output);
            }
        }

        [KnownMaterialTemplateClass("OperatorFloatClamp")]
        public class OperatorFloatClamp : MaterialTemplateClass
        {
            public FloatInput float1 { get; private set; }
            public FloatInput float2 { get; private set; }
            public FloatInput float3 { get; private set; }
            public FloatOutput output { get; private set; }

            public OperatorFloatClamp(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                float1 = reader.ReadProperty<FloatInput>(r);
                float2 = reader.ReadProperty<FloatInput>(r);
                float3 = reader.ReadProperty<FloatInput>(r);
                output = reader.ReadProperty<FloatOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3} {4} {5})", Id, Type, float1, float2, float3, output);
            }
        }

        [KnownMaterialTemplateClass("OperatorFloatCos")]
        public class OperatorFloatCos : MaterialTemplateClass
        {
            public FloatInput float1 { get; private set; }
            public FloatOutput output { get; private set; }

            public OperatorFloatCos(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                float1 = reader.ReadProperty<FloatInput>(r);
                output = reader.ReadProperty<FloatOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3})", Id, Type, float1, output);
            }
        }

        [KnownMaterialTemplateClass("OperatorFloatDiv")]
        public class OperatorFloatDiv : MaterialTemplateClass
        {
            public FloatInput float1 { get; private set; }
            public FloatInput float2 { get; private set; }
            public FloatOutput output { get; private set; }

            public OperatorFloatDiv(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                float1 = reader.ReadProperty<FloatInput>(r);
                float2 = reader.ReadProperty<FloatInput>(r);
                output = reader.ReadProperty<FloatOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3} {4})", Id, Type, float1, float2, output);
            }
        }

        [KnownMaterialTemplateClass("OperatorFloatExp")]
        public class OperatorFloatExp : MaterialTemplateClass
        {
            public FloatInput float1 { get; private set; }
            public FloatInput float2 { get; private set; }
            public FloatOutput output { get; private set; }

            public OperatorFloatExp(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                float1 = reader.ReadProperty<FloatInput>(r);
                float2 = reader.ReadProperty<FloatInput>(r);
                output = reader.ReadProperty<FloatOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3} {4})", Id, Type, float1, float2, output);
            }
        }

        [KnownMaterialTemplateClass("OperatorFloatInvert")]
        public class OperatorFloatInvert : MaterialTemplateClass
        {
            public FloatInput floatInput { get; private set; }
            public FloatOutput floatOutput { get; private set; }

            public OperatorFloatInvert(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                floatInput = reader.ReadProperty<FloatInput>(r);
                floatOutput = reader.ReadProperty<FloatOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3})", Id, Type, floatInput, floatOutput);
            }
        }

        [KnownMaterialTemplateClass("OperatorFloatMax")]
        public class OperatorFloatMax : MaterialTemplateClass
        {
            public FloatInput float1 { get; private set; }
            public FloatInput float2 { get; private set; }
            public FloatOutput output { get; private set; }

            public OperatorFloatMax(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                float1 = reader.ReadProperty<FloatInput>(r);
                float2 = reader.ReadProperty<FloatInput>(r);
                output = reader.ReadProperty<FloatOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3} {4})", Id, Type, float1, float2, output);
            }
        }

        [KnownMaterialTemplateClass("OperatorFloatMin")]
        public class OperatorFloatMin : MaterialTemplateClass
        {
            public FloatInput float1 { get; private set; }
            public FloatInput float2 { get; private set; }
            public FloatOutput output { get; private set; }

            public OperatorFloatMin(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                float1 = reader.ReadProperty<FloatInput>(r);
                float2 = reader.ReadProperty<FloatInput>(r);
                output = reader.ReadProperty<FloatOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3} {4})", Id, Type, float1, float2, output);
            }
        }

        [KnownMaterialTemplateClass("OperatorFloatMul")]
        public class OperatorFloatMul : MaterialTemplateClass
        {
            public FloatInput float1 { get; private set; }
            public FloatInput float2 { get; private set; }
            public FloatOutput output { get; private set; }

            public OperatorFloatMul(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                float1 = reader.ReadProperty<FloatInput>(r);
                float2 = reader.ReadProperty<FloatInput>(r);
                output = reader.ReadProperty<FloatOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3} {4})", Id, Type, float1, float2, output);
            }
        }

        [KnownMaterialTemplateClass("OperatorFloatNegate")]
        public class OperatorFloatNegate : MaterialTemplateClass
        {
            public FloatInput floatInput { get; private set; }
            public FloatOutput floatOutput { get; private set; }

            public OperatorFloatNegate(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                floatInput = reader.ReadProperty<FloatInput>(r);
                floatOutput = reader.ReadProperty<FloatOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3})", Id, Type, floatInput, floatOutput);
            }
        }

        [KnownMaterialTemplateClass("OperatorFloatSub")]
        public class OperatorFloatSub : MaterialTemplateClass
        {
            public FloatInput floatInput1 { get; private set; }
            public FloatInput floatInput2 { get; private set; }
            public FloatOutput floatOutput1 { get; private set; }

            public OperatorFloatSub(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                floatInput1 = reader.ReadProperty<FloatInput>(r);
                floatInput2 = reader.ReadProperty<FloatInput>(r);
                floatOutput1 = reader.ReadProperty<FloatOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3} {4})", Id, Type, floatInput1, floatInput2, floatOutput1);
            }
        }

        [KnownMaterialTemplateClass("OperatorFloatSin")]
        public class OperatorFloatSin : MaterialTemplateClass
        {
            public FloatInput floatInput1 { get; private set; }
            public FloatOutput floatOutput1 { get; private set; }

            public OperatorFloatSin(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                floatInput1 = reader.ReadProperty<FloatInput>(r);
                floatOutput1 = reader.ReadProperty<FloatOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3})", Id, Type, floatInput1, floatOutput1);
            }
        }

        [KnownMaterialTemplateClass("OperatorFloorFloat")]
        public class OperatorFloorFloat : MaterialTemplateClass
        {
            public FloatInput float1 { get; private set; }
            public FloatOutput output { get; private set; }

            public OperatorFloorFloat(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                float1 = reader.ReadProperty<FloatInput>(r);
                output = reader.ReadProperty<FloatOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3})", Id, Type, float1, output);
            }
        }

        [KnownMaterialTemplateClass("OperatorFracFloat")]
        public class OperatorFracFloat : MaterialTemplateClass
        {
            public FloatInput float1 { get; private set; }
            public FloatOutput output { get; private set; }

            public OperatorFracFloat(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                float1 = reader.ReadProperty<FloatInput>(r);
                output = reader.ReadProperty<FloatOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3})", Id, Type, float1, output);
            }
        }

        [KnownMaterialTemplateClass("OperatorFracVector")]
        public class OperatorFracVector : MaterialTemplateClass
        {
            public VectorInput vectorInput { get; private set; }
            public VectorOutput vectorOutput { get; private set; }

            public OperatorFracVector(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                vectorInput = reader.ReadProperty<VectorInput>(r);
                vectorOutput = reader.ReadProperty<VectorOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3})", Id, Type, vectorInput, vectorOutput);
            }
        }

        [KnownMaterialTemplateClass("OperatorFresnelFactor")]
        public class OperatorFresnelFactor : MaterialTemplateClass
        {
            public FloatOutput output { get; private set; }
            public VectorInput vectorInput1 { get; private set; }
            public VectorInput vectorInput2 { get; private set; }
            public FloatInput floatInput1 { get; private set; }

            public OperatorFresnelFactor(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                output = reader.ReadProperty<FloatOutput>(r);
                vectorInput1 = reader.ReadProperty<VectorInput>(r);
                vectorInput2 = reader.ReadProperty<VectorInput>(r);
                floatInput1 = reader.ReadProperty<FloatInput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3} {4} {5})",
                    Id,
                    Type,
                    output,
                    vectorInput1,
                    vectorInput2,
                    floatInput1);
            }
        }

        [KnownMaterialTemplateClass("OperatorLength")]
        public class OperatorLength : MaterialTemplateClass
        {
            public VectorInput vectorInput { get; private set; }
            public FloatOutput floatOutput { get; private set; }

            public OperatorLength(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                vectorInput = reader.ReadProperty<VectorInput>(r);
                floatOutput = reader.ReadProperty<FloatOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3})", Id, Type, vectorInput, floatOutput);
            }
        }

        [KnownMaterialTemplateClass("OperatorModuloFloat")]
        public class OperatorModuloFloat : MaterialTemplateClass
        {
            public FloatInput floatInput1 { get; private set; }
            public FloatInput floatInput2 { get; private set; }
            public FloatOutput floatOutput1 { get; private set; }

            public OperatorModuloFloat(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                floatInput1 = reader.ReadProperty<FloatInput>(r);
                floatInput2 = reader.ReadProperty<FloatInput>(r);
                floatOutput1 = reader.ReadProperty<FloatOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3} {4})", Id, Type, floatInput1, floatInput2, floatOutput1);
            }
        }

        [KnownMaterialTemplateClass("OperatorMultiBlender")]
        public class OperatorMultiBlender : MaterialTemplateClass
        {
            public VectorInput vectorInput1 { get; private set; }
            public VectorInput vectorInput2 { get; private set; }
            public VectorInput vectorInput3 { get; private set; }
            public VectorInput vectorInput4 { get; private set; }
            public VectorOutput vectorOutput { get; private set; }

            public OperatorMultiBlender(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                vectorInput1 = reader.ReadProperty<VectorInput>(r);
                vectorInput2 = reader.ReadProperty<VectorInput>(r);
                vectorInput3 = reader.ReadProperty<VectorInput>(r);
                vectorInput4 = reader.ReadProperty<VectorInput>(r);
                vectorOutput = reader.ReadProperty<VectorOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3} {4} {5} {6})",
                    Id,
                    Type,
                    vectorInput1, vectorInput2, vectorInput3, vectorInput4,
                    vectorOutput);
            }
        }

        [KnownMaterialTemplateClass("OperatorMultiBlender3")]
        public class OperatorMultiBlender3 : MaterialTemplateClass
        {
            public VectorInput vectorInput1 { get; private set; }
            public VectorInput vectorInput2 { get; private set; }
            public VectorInput vectorInput3 { get; private set; }
            public VectorInput vectorInput4 { get; private set; }
            public VectorInput vectorInput5 { get; private set; }
            public VectorOutput vectorOutput { get; private set; }

            public OperatorMultiBlender3(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                vectorInput1 = reader.ReadProperty<VectorInput>(r);
                vectorInput2 = reader.ReadProperty<VectorInput>(r);
                vectorInput3 = reader.ReadProperty<VectorInput>(r);
                vectorInput4 = reader.ReadProperty<VectorInput>(r);
                vectorInput5 = reader.ReadProperty<VectorInput>(r);
                vectorOutput = reader.ReadProperty<VectorOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3} {4} {5} {6} {7})",
                    Id,
                    Type,
                    vectorInput1, vectorInput2, vectorInput3, vectorInput4, vectorInput5,
                    vectorOutput);
            }
        }

        [KnownMaterialTemplateClass("OperatorNormalize")]
        public class OperatorNormalize : MaterialTemplateClass
        {
            public VectorInput vectorInput { get; private set; }
            public VectorOutput vectorOutput { get; private set; }

            public OperatorNormalize(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                vectorInput = reader.ReadProperty<VectorInput>(r);
                vectorOutput = reader.ReadProperty<VectorOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3})", Id, Type, vectorInput, vectorOutput);
            }
        }

        [KnownMaterialTemplateClass("OperatorParallaxMapping")]
        public class OperatorParallaxMapping : MaterialTemplateClass
        {
            public TextureInput textureInput { get; private set; }
            public FloatInput floatInput1 { get; private set; }
            public FloatInput floatInput2 { get; private set; }
            public VectorInput vectorInput1 { get; private set; }
            public VectorOutput ouput { get; private set; }

            public OperatorParallaxMapping(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                textureInput = reader.ReadProperty<TextureInput>(r);
                floatInput1 = reader.ReadProperty<FloatInput>(r);
                floatInput2 = reader.ReadProperty<FloatInput>(r);
                vectorInput1 = reader.ReadProperty<VectorInput>(r);
                ouput = reader.ReadProperty<VectorOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3})",
                    Id,
                    Type,
                    textureInput,
                    floatInput1,
                    floatInput2,
                    vectorInput1,
                    ouput);
            }
        }

        [KnownMaterialTemplateClass("OperatorReciprocalFloat")]
        public class OperatorReciprocalFloat : MaterialTemplateClass
        {
            public FloatInput floatInput { get; private set; }
            public FloatOutput floatOutput { get; private set; }

            public OperatorReciprocalFloat(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                floatInput = reader.ReadProperty<FloatInput>(r);
                floatOutput = reader.ReadProperty<FloatOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3})", Id, Type, floatInput, floatOutput);
            }
        }

        [KnownMaterialTemplateClass("OperatorReflect")]
        public class OperatorReflect : MaterialTemplateClass
        {
            public VectorInput vector1 { get; private set; }
            public VectorInput vector2 { get; private set; }
            public VectorOutput output { get; private set; }

            public OperatorReflect(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                vector1 = reader.ReadProperty<VectorInput>(r);
                vector2 = reader.ReadProperty<VectorInput>(r);
                output = reader.ReadProperty<VectorOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3} {4})", Id, Type, vector1, vector2, output);
            }
        }

        [KnownMaterialTemplateClass("OperatorSaturateFloat")]
        public class OperatorSaturateFloat : MaterialTemplateClass
        {
            public FloatInput float1 { get; private set; }
            public FloatOutput output { get; private set; }

            public OperatorSaturateFloat(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                float1 = reader.ReadProperty<FloatInput>(r);
                output = reader.ReadProperty<FloatOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3})", Id, Type, float1, output);
            }
        }

        [KnownMaterialTemplateClass("OperatorSaturateVector")]
        public class OperatorSaturateVector : MaterialTemplateClass
        {
            public VectorInput input { get; private set; }
            public VectorOutput output { get; private set; }

            public OperatorSaturateVector(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                input = reader.ReadProperty<VectorInput>(r);
                output = reader.ReadProperty<VectorOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3})", Id, Type, input, output);
            }
        }

        [KnownMaterialTemplateClass("OperatorStepFloat")]
        public class OperatorStepFloat : MaterialTemplateClass
        {
            public FloatInput input1 { get; private set; }
            public FloatInput input2 { get; private set; }
            public FloatOutput output { get; private set; }

            public OperatorStepFloat(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                input1 = reader.ReadProperty<FloatInput>(r);
                input2 = reader.ReadProperty<FloatInput>(r);
                output = reader.ReadProperty<FloatOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3} {4})", Id, Type, input1, input2, output);
            }
        }

        [KnownMaterialTemplateClass("OperatorVectorAbs")]
        public class OperatorVectorAbs : MaterialTemplateClass
        {
            public VectorInput vector1 { get; private set; }
            public VectorOutput output { get; private set; }

            public OperatorVectorAbs(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                vector1 = reader.ReadProperty<VectorInput>(r);
                output = reader.ReadProperty<VectorOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3})", Id, Type, vector1, output);
            }
        }

        [KnownMaterialTemplateClass("OperatorVectorAdd")]
        public class OperatorVectorAdd : MaterialTemplateClass
        {
            public VectorInput vector1 { get; private set; }
            public VectorInput vector2 { get; private set; }
            public VectorOutput output { get; private set; }

            public OperatorVectorAdd(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                vector1 = reader.ReadProperty<VectorInput>(r);
                vector2 = reader.ReadProperty<VectorInput>(r);
                output = reader.ReadProperty<VectorOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3} {4})", Id, Type, vector1, vector2, output);
            }
        }

        [KnownMaterialTemplateClass("OperatorVectorClamp")]
        public class OperatorVectorClamp : MaterialTemplateClass
        {
            public VectorInput vector1 { get; private set; }
            public VectorInput vector2 { get; private set; }
            public VectorInput vector3 { get; private set; }
            public VectorOutput output { get; private set; }

            public OperatorVectorClamp(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                vector1 = reader.ReadProperty<VectorInput>(r);
                vector2 = reader.ReadProperty<VectorInput>(r);
                vector3 = reader.ReadProperty<VectorInput>(r);
                output = reader.ReadProperty<VectorOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3} {4} {5})",
                    Id,
                    Type,
                    vector1,
                    vector2,
                    vector3,
                    output);
            }
        }

        [KnownMaterialTemplateClass("OperatorVectorFloatMultiply")]
        public class OperatorVectorFloatMultiply : MaterialTemplateClass
        {
            public VectorInput vectorInput1 { get; private set; }
            public FloatInput float1 { get; private set; }
            public VectorOutput vectorOutput1 { get; private set; }

            public OperatorVectorFloatMultiply(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                vectorInput1 = reader.ReadProperty<VectorInput>(r);
                float1 = reader.ReadProperty<FloatInput>(r);
                vectorOutput1 = reader.ReadProperty<VectorOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3} {4})", Id, Type, vectorInput1, float1, vectorOutput1);
            }
        }

        [KnownMaterialTemplateClass("OperatorVectorMax")]
        public class OperatorVectorMax : MaterialTemplateClass
        {
            public VectorInput vector1 { get; private set; }
            public VectorInput vector2 { get; private set; }
            public VectorOutput output { get; private set; }

            public OperatorVectorMax(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                vector1 = reader.ReadProperty<VectorInput>(r);
                vector2 = reader.ReadProperty<VectorInput>(r);
                output = reader.ReadProperty<VectorOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3} {4})", Id, Type, vector1, vector2, output);
            }
        }

        [KnownMaterialTemplateClass("OperatorVectorMin")]
        public class OperatorVectorMin : MaterialTemplateClass
        {
            public VectorInput vector1 { get; private set; }
            public VectorInput vector2 { get; private set; }
            public VectorOutput output { get; private set; }

            public OperatorVectorMin(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                vector1 = reader.ReadProperty<VectorInput>(r);
                vector2 = reader.ReadProperty<VectorInput>(r);
                output = reader.ReadProperty<VectorOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3} {4})", Id, Type, vector1, vector2, output);
            }
        }

        [KnownMaterialTemplateClass("OperatorVectorNegate")]
        public class OperatorVectorNegate : MaterialTemplateClass
        {
            public VectorInput input { get; private set; }
            public VectorOutput output { get; private set; }

            public OperatorVectorNegate(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                input = reader.ReadProperty<VectorInput>(r);
                output = reader.ReadProperty<VectorOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3})", Id, Type, input, output);
            }
        }

        [KnownMaterialTemplateClass("OperatorVectorSub")]
        public class OperatorVectorSub : MaterialTemplateClass
        {
            public VectorInput vector1 { get; private set; }
            public VectorInput vector2 { get; private set; }
            public VectorOutput output { get; private set; }

            public OperatorVectorSub(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                vector1 = reader.ReadProperty<VectorInput>(r);
                vector2 = reader.ReadProperty<VectorInput>(r);
                output = reader.ReadProperty<VectorOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3} {4})", Id, Type, vector1, vector2, output);
            }
        }

        [KnownMaterialTemplateClass("OperatorDot")]
        public class OperatorDot : MaterialTemplateClass
        {
            public VectorInput vector1 { get; private set; }
            public VectorInput vector2 { get; private set; }
            public FloatOutput floatOutput { get; private set; }

            public OperatorDot(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                vector1 = reader.ReadProperty<VectorInput>(r);
                vector2 = reader.ReadProperty<VectorInput>(r);
                floatOutput = reader.ReadProperty<FloatOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3} {4})", Id, Type, vector1, vector2, floatOutput);
            }
        }

        [KnownMaterialTemplateClass("OperatorVectorMultiply")]
        public class OperatorVectorMultiply : MaterialTemplateClass
        {
            public VectorInput vector1 { get; private set; }
            public VectorInput vector2 { get; private set; }
            public VectorOutput output { get; private set; }

            public OperatorVectorMultiply(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                vector1 = reader.ReadProperty<VectorInput>(r);
                vector2 = reader.ReadProperty<VectorInput>(r);
                output = reader.ReadProperty<VectorOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3} {4})", Id, Type, vector1, vector2, output);
            }
        }

        [KnownMaterialTemplateClass("QuaternionOutput")]
        public class QuaternionOutput : MaterialTemplateClass
        {
            public QuaternionOutput(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {

            }
            public override string ToString()
            {
                return "(" + base.ToString() + ")";
            }
        }

        [KnownMaterialTemplateClass("ReflectionSource")]
        public class ReflectionSource : MaterialTemplateClass
        {
            public VectorInput vector1 { get; private set; }
            public VectorInput vector2 { get; private set; }
            public VectorOutput output { get; private set; }

            public ReflectionSource(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                vector1 = reader.ReadProperty<VectorInput>(r);
                vector2 = reader.ReadProperty<VectorInput>(r);
                output = reader.ReadProperty<VectorOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3} {4})", Id, Type, vector1, vector2, output);
            }
        }

        [KnownMaterialTemplateClass("ShadeConstantEntityToCameraDistance")]
        public class ShadeConstantEntityToCameraDistance : MaterialTemplateClass
        {
            public FloatOutput output { get; private set; }

            public ShadeConstantEntityToCameraDistance(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                output = reader.ReadProperty<FloatOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2})", Id, Type, output);
            }
        }

        [KnownMaterialTemplateClass("ShadeConstantEntityVisualScaleFactor")]
        public class ShadeConstantEntityVisualScaleFactor : MaterialTemplateClass
        {
            public FloatOutput output { get; private set; }

            public ShadeConstantEntityVisualScaleFactor(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                output = reader.ReadProperty<FloatOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2})", Id, Type, output);
            }
        }

        [KnownMaterialTemplateClass("ShadeConstantEntityWorldPosition")]
        public class ShadeConstantEntityWorldPosition : MaterialTemplateClass
        {
            VectorOutput output;

            public ShadeConstantEntityWorldPosition(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                output = reader.ReadProperty<VectorOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2})", Id, Type, output);
            }
        }

        [KnownMaterialTemplateClass("ShadeConstantEyeDirection")]
        public class ShadeConstantEyeDirection : MaterialTemplateClass
        {
            public VectorOutput output { get; private set; }

            public ShadeConstantEyeDirection(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                output = reader.ReadProperty<VectorOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2})", Id, Type, output);
            }
        }

        [KnownMaterialTemplateClass("ShadeConstantEyePosition")]
        public class ShadeConstantEyePosition : MaterialTemplateClass
        {
            public VectorOutput output { get; private set; }

            public ShadeConstantEyePosition(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                output = reader.ReadProperty<VectorOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2})", Id, Type, output);
            }
        }

        [KnownMaterialTemplateClass("ShadeConstantLayeredSkyUserColor")]
        public class ShadeConstantLayeredSkyUserColor : MaterialTemplateClass
        {
            public VectorOutput output { get; private set; }

            public ShadeConstantLayeredSkyUserColor(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                output = reader.ReadProperty<VectorOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2})", Id, Type, output);
            }
        }

        [KnownMaterialTemplateClass("ShadeConstantLayeredSkyUserColor1")]
        public class ShadeConstantLayeredSkyUserColor1 : MaterialTemplateClass
        {
            public VectorOutput output { get; private set; }

            public ShadeConstantLayeredSkyUserColor1(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                output = reader.ReadProperty<VectorOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2})", Id, Type, output);
            }
        }

        [KnownMaterialTemplateClass("ShadeConstantLayeredSkyUserColor2")]
        public class ShadeConstantLayeredSkyUserColor2 : MaterialTemplateClass
        {
            public VectorOutput output { get; private set; }

            public ShadeConstantLayeredSkyUserColor2(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                output = reader.ReadProperty<VectorOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2})", Id, Type, output);
            }
        }

        [KnownMaterialTemplateClass("ShadeConstantLayeredSkyUserColor3")]
        public class ShadeConstantLayeredSkyUserColor3 : MaterialTemplateClass
        {
            public VectorOutput output { get; private set; }

            public ShadeConstantLayeredSkyUserColor3(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                output = reader.ReadProperty<VectorOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2})", Id, Type, output);
            }
        }

        [KnownMaterialTemplateClass("ShadeConstantLayeredSkyUserColor4")]
        public class ShadeConstantLayeredSkyUserColor4 : MaterialTemplateClass
        {
            public VectorOutput output { get; private set; }

            public ShadeConstantLayeredSkyUserColor4(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                output = reader.ReadProperty<VectorOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2})", Id, Type, output);
            }
        }

        [KnownMaterialTemplateClass("ShadeConstantLODBlendFactor")]
        public class ShadeConstantLODBlendFactor : MaterialTemplateClass
        {
            public VectorOutput output1 { get; private set; }
            public FloatOutput output2 { get; private set; }

            public ShadeConstantLODBlendFactor(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                output1 = reader.ReadProperty<VectorOutput>(r);
                output2 = reader.ReadProperty<FloatOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3})", Id, Type, output1, output2);
            }
        }

        [KnownMaterialTemplateClass("ShadeConstantScreenPosition")]
        public class ShadeConstantScreenPosition : MaterialTemplateClass
        {
            public VectorOutput output { get; private set; }

            public ShadeConstantScreenPosition(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                output = reader.ReadProperty<VectorOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2})", Id, Type, output);
            }
        }

        [KnownMaterialTemplateClass("ShadeConstantSunColor")]
        public class ShadeConstantSunColor : MaterialTemplateClass
        {
            public VectorOutput output { get; private set; }

            public ShadeConstantSunColor(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                output = reader.ReadProperty<VectorOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2})", Id, Type, output);
            }
        }

        [KnownMaterialTemplateClass("ShadeConstantSunDirection")]
        public class ShadeConstantSunDirection : MaterialTemplateClass
        {
            public VectorOutput output { get; private set; }

            public ShadeConstantSunDirection(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                output = reader.ReadProperty<VectorOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2})", Id, Type, output);
            }
        }

        [KnownMaterialTemplateClass("ShadeConstantTimeOfDay")]
        public class ShadeConstantTimeOfDay : MaterialTemplateClass
        {
            public FloatOutput output { get; private set; }

            public ShadeConstantTimeOfDay(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                output = reader.ReadProperty<FloatOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2})", Id, Type, output);
            }
        }

        [KnownMaterialTemplateClass("ShadeConstantWorldNormal")]
        public class ShadeConstantWorldNormal : MaterialTemplateClass
        {
            public VectorOutput output { get; private set; }

            public ShadeConstantWorldNormal(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                output = reader.ReadProperty<VectorOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2})", Id, Type, output);
            }
        }

        [KnownMaterialTemplateClass("ShadeConstantWorldNormalUnperturbed")]
        public class ShadeConstantWorldNormalUnperturbed : MaterialTemplateClass
        {
            public VectorOutput output { get; private set; }

            public ShadeConstantWorldNormalUnperturbed(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                output = reader.ReadProperty<VectorOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2})", Id, Type, output);
            }
        }

        [KnownMaterialTemplateClass("ShadeConstantWorldPosition")]
        public class ShadeConstantWorldPosition : MaterialTemplateClass
        {
            public VectorOutput output { get; private set; }

            public ShadeConstantWorldPosition(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                output = reader.ReadProperty<VectorOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2})", Id, Type, output);
            }
        }

        [KnownMaterialTemplateClass("ShadeConstantWorldTangent")]
        public class ShadeConstantWorldTangent : MaterialTemplateClass
        {
            public VectorOutput output { get; private set; }

            public ShadeConstantWorldTangent(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                output = reader.ReadProperty<VectorOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2})", Id, Type, output);
            }
        }

        [KnownMaterialTemplateClass("ShaderLODOperatorVector")]
        public class ShaderLODOperatorVector : MaterialTemplateClass
        {
            public VectorOutput output { get; private set; }
            public VectorInput input1 { get; private set; }
            public VectorInput input2 { get; private set; }

            public ShaderLODOperatorVector(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                output = reader.ReadProperty<VectorOutput>(r);
                input1 = reader.ReadProperty<VectorInput>(r);
                input2 = reader.ReadProperty<VectorInput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3} {4})", Id, Type, output, input1, input2);
            }
        }

        [KnownMaterialTemplateClass("ShaderLODOperatorFloat")]
        public class ShaderLODOperatorFloat : MaterialTemplateClass
        {
            public FloatOutput output { get; private set; }
            public FloatInput input1 { get; private set; }
            public FloatInput input2 { get; private set; }

            public ShaderLODOperatorFloat(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                output = reader.ReadProperty<FloatOutput>(r);
                input1 = reader.ReadProperty<FloatInput>(r);
                input2 = reader.ReadProperty<FloatInput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3} {4})", Id, Type, output, input1, input2);
            }
        }

        [KnownMaterialTemplateClass("TextureInput")]
        public class TextureInput : MaterialTemplateClass
        {
            public InputConnector U1 { get; private set; }

            public TextureInput(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                U1 = new InputConnector(r, reader);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2})", Id, Type, U1);
            }
        }

        [KnownMaterialTemplateClass("TextureObject")]
        public class TextureObject : MaterialTemplateClass
        {
            public VectorOutput vectorOutput1 { get; private set; }
            public FloatOutput floatOutput1 { get; private set; }
            public FloatOutput floatOutput2 { get; private set; }
            public FloatOutput floatOutput3 { get; private set; }
            public FloatOutput floatOutput4 { get; private set; }
            public VectorOutput vectorOutput2 { get; private set; }
            public VectorOutput vectorOutput3 { get; private set; }
            public TextureOutput textureOutput1 { get; private set; }
            public VectorInput vectorInput1 { get; private set; }
            public byte U1 { get; private set; }
            public TextureSelector textureSelector1 { get; private set; }

            public TextureObject(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                vectorOutput1 = reader.ReadProperty<VectorOutput>(r);
                floatOutput1 = reader.ReadProperty<FloatOutput>(r);
                floatOutput2 = reader.ReadProperty<FloatOutput>(r);
                floatOutput3 = reader.ReadProperty<FloatOutput>(r);
                floatOutput4 = reader.ReadProperty<FloatOutput>(r);
                vectorOutput2 = reader.ReadProperty<VectorOutput>(r);
                vectorOutput3 = reader.ReadProperty<VectorOutput>(r);
                textureOutput1 = reader.ReadProperty<TextureOutput>(r);
                vectorInput1 = reader.ReadProperty<VectorInput>(r);
                U1 = r.ReadByte();
                textureSelector1 = reader.ReadProperty<TextureSelector>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3} {4} {5} {6} {7} {8} {9} {10} {11})",
                    Id,
                    Type,
                    vectorOutput1,
                    floatOutput1,
                    floatOutput2,
                    floatOutput3,
                    floatOutput4,
                    vectorOutput2,
                    vectorOutput3,
                    vectorInput1,
                    U1,
                    textureSelector1);
            }
        }

        [KnownMaterialTemplateClass("TextureOutput")]
        public class TextureOutput : MaterialTemplateClass
        {
            public TextureOutput(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {

            }
            public override string ToString()
            {
                return "(" + base.ToString() + ")";
            }
        }

        [KnownMaterialTemplateClass("TextureSelector")]
        public class TextureSelector : MaterialTemplateClass
        {
            public uint U1 { get; private set; }
            public uint U2 { get; private set; }
            public ResourceDependency dependency1 { get; private set; }
            public ResourceDependency dependency2 { get; private set; }

            public TextureSelector(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                U1 = r.ReadUInt32();
                U2 = r.ReadUInt32();
                dependency1 = new ResourceDependency(r);
                dependency2 = new ResourceDependency(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3} {4} {5})",
                    Id,
                    Type,
                    U1, U2, dependency1, dependency2);
            }
        }

        [KnownMaterialTemplateClass("TextureSource")]
        public class TextureSource : MaterialTemplateClass
        {
            public VectorOutput vectorOutput1 { get; private set; }
            public FloatOutput floatOutput1 { get; private set; }
            public FloatOutput floatOutput2 { get; private set; }
            public FloatOutput floatOutput3 { get; private set; }
            public FloatOutput floatOutput4 { get; private set; }
            public TextureInput texInput { get; private set; }
            public byte U1 { get; private set; }
            public VectorInput vectorInput1 { get; private set; }

            public TextureSource(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                vectorOutput1 = reader.ReadProperty<VectorOutput>(r);
                floatOutput1 = reader.ReadProperty<FloatOutput>(r);
                floatOutput2 = reader.ReadProperty<FloatOutput>(r);
                floatOutput3 = reader.ReadProperty<FloatOutput>(r);
                floatOutput4 = reader.ReadProperty<FloatOutput>(r);
                texInput = reader.ReadProperty<TextureInput>(r);
                U1 = r.ReadByte();
                vectorInput1 = reader.ReadProperty<VectorInput>(r);
            }
            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3} {4} {5} {6} {7} {8:X2} {9})", Id, Type, vectorOutput1, floatOutput1, floatOutput2, floatOutput3, floatOutput4, U1, texInput, vectorInput1);
            }
        }

        [KnownMaterialTemplateClass("TimeOscillator")]
        public class TimeOscillator : MaterialTemplateClass
        {
            public FloatOutput output { get; private set; }
            public TimeOscillatorData data { get; private set; }

            public TimeOscillator(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                output = reader.ReadProperty<FloatOutput>(r);
                data = reader.ReadProperty<TimeOscillatorData>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3})",
                    Id,
                    Type,
                    output, data);
            }
        }

        [KnownMaterialTemplateClass("TimeOscillatorData")]
        public class TimeOscillatorData : MaterialTemplateClass
        {
            public uint U1 { get; private set; }
            public float U2 { get; private set; }
            public float U3 { get; private set; }
            public uint U4 { get; private set; }

            public TimeOscillatorData(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                U1 = r.ReadUInt32();
                U2 = r.ReadSingle();
                U3 = r.ReadSingle();
                U4 = r.ReadUInt32();
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3:0.000000} {4:0.000000} {5})",
                    Id,
                    Type,
                    U1, U2, U3, U4);
            }
        }

        [KnownMaterialTemplateClass("UVTransformOperator")]
        public class UVTransformOperator : MaterialTemplateClass
        {
            public VectorOutput output { get; private set; }
            public VectorInput input { get; private set; }
            public UVTransform transform { get; private set; }

            public UVTransformOperator(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                output = reader.ReadProperty<VectorOutput>(r);
                input = reader.ReadProperty<VectorInput>(r);
                transform = reader.ReadProperty<UVTransform>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3} {4})",
                    Id,
                    Type,
                    output, input, transform);
            }
        }

        [KnownMaterialTemplateClass("UVTransform")]
        public class UVTransform : MaterialTemplateClass
        {
            public float U1 { get; private set; }
            public float U2 { get; private set; }
            public float U3 { get; private set; }
            public float U4 { get; private set; }
            public float U5 { get; private set; }
            public float U6 { get; private set; }
            public float U7 { get; private set; }
            public float U8 { get; private set; }
            public short U9 { get; private set; }

            public UVTransform(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                U1 = r.ReadSingle();
                U2 = r.ReadSingle();
                U3 = r.ReadSingle();
                U4 = r.ReadSingle();
                U5 = r.ReadSingle();
                U6 = r.ReadSingle();
                U7 = r.ReadSingle();
                U8 = r.ReadSingle();
                U9 = r.ReadInt16();
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2:0.000000} {3:0.000000} {4:0.000000} {5:0.000000} {6:0.000000} {7:0.000000} {8:0.000000} {9:0.000000} 0x{10:x4})",
                    Id,
                    Type,
                    U1, U2, U3, U4, U5, U6, U7, U8, U9);
            }
        }

        [KnownMaterialTemplateClass("VectorInput")]
        public class VectorInput : MaterialTemplateClass
        {
            public InputConnector U1 { get; private set; }

            public VectorInput(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                U1 = new InputConnector(r, reader);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2})", Id, Type, U1);
            }
        }

        [KnownMaterialTemplateClass("VectorOutput")]
        public class VectorOutput : MaterialTemplateClass
        {
            public VectorOutput(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {

            }
            public override string ToString()
            {
                return "(" + base.ToString() + ")";
            }
        }

        [KnownMaterialTemplateClass("VectorToFloat")]
        public class VectorToFloat : MaterialTemplateClass
        {
            public VectorInput input { get; private set; }

            public FloatOutput output1 { get; private set; }
            public FloatOutput output2 { get; private set; }
            public FloatOutput output3 { get; private set; }
            public FloatOutput output4 { get; private set; }

            public VectorToFloat(MaterialTemplateClass b, BinaryReader r)
                : base(b)
            {
                input = reader.ReadProperty<VectorInput>(r);
                output1 = reader.ReadProperty<FloatOutput>(r);
                output2 = reader.ReadProperty<FloatOutput>(r);
                output3 = reader.ReadProperty<FloatOutput>(r);
                output4 = reader.ReadProperty<FloatOutput>(r);
            }

            public override string ToString()
            {
                return string.Format("(0x{0:x8} {1} {2} {3} {4} {5} {6})", Id, Type, input, output1, output2, output3, output4);
            }
        }

        [TypeConverter(typeof(ExpandableObjectConverter))]
        public class InputConnector
        {
            public byte type { get; private set; }
            public uint Ref { get; private set; }

            ClassReader reader;

            public MaterialTemplateClass ConnectedOutput
            {
                get
                {
                    if (reader != null && Ref != 0xffffffff) return reader.GetProperty(Ref);
                    return null;
                }
            }

            public InputConnector(BinaryReader r, ClassReader p)
            {
                Ref = 0xffffffff;
                reader = p;
                Read(r);
            }

            public void Read(BinaryReader r)
            {
                type = r.ReadByte();
                if (type == 2 || type == 5)
                {
                    Ref = r.ReadUInt32();
                }
                else if (type != 3)
                {
                    //System.Diagnostics.Debugger.Break();
                }
            }
            public override string ToString()
            {
                if (Ref == 0xffffffff) return type.ToString();
                else return string.Format("{0} 0x{1:x8}", type, Ref);
            }
        }

        #endregion

        public class ClassReader
        {
            private Dictionary<uint, MaterialTemplateClass> readProperties = new Dictionary<uint, MaterialTemplateClass>();

            public MaterialTemplateClass GetProperty(uint id)
            {
                if (readProperties.ContainsKey(id)) return readProperties[id];
                return null;
            }

            public T ReadProperty<T>(BinaryReader r)
                where T : MaterialTemplateClass
            {
                MaterialTemplateClass p = ReadProperty(r);
                T returnValue = p as T;
                if (returnValue == null)
                {
                    throw new Exception("couldn't read property...");

                }
                return returnValue;
            }

            public MaterialTemplateClass ReadProperty(BinaryReader r)
            {
                MaterialTemplateClass p = new MaterialTemplateClass(r, this);
                Type t = KnownMaterialTemplateClassRegistry.GetType(p.TypeId);
                if (t != null)
                {
                    try
                    {
                        p = (MaterialTemplateClass)System.Activator.CreateInstance(t, p, r);
                    }
                    catch (Exception ex)
                    {
                        throw ex.InnerException;
                    }
                }
                else
                {
                    throw new Exception("couldn't read property...");
                }

                if (p != null && p.Id != 0) readProperties.Add(p.Id, p);

                return p;
            }
        }

        ClassReader classReader;

        public byte ub1 { get; private set; }
        public MetaOperator template { get; private set; }
        public byte[] uba2 { get; private set; }
        public CompiledMaterialTemplate compiledTemplate { get; private set; }
        public IColor color1 { get; private set; }
        public IColor color2 { get; private set; }

        public MaterialTemplate(ResourceBase other)
            : base(other)
        {

        }

        public override void Load()
        {
            _baseStream.Position = dataOffset;
            BinaryReader r = new BinaryReader(_baseStream);
            long endpos = r.BaseStream.Position + (Length - 9);
            /* 
            BinaryReader r = new BinaryReader(input);
            r.ReadByte();
            r.ReadUInt32();
            r.ReadUInt32();
            long endpos = r.BaseStream.Length;
            */
            ub1 = r.ReadByte(); // 0 | 1

            classReader = new ClassReader();
            template = classReader.ReadProperty<MetaOperator>(r);

            // PADDING TO REALIGN!!!
            if ((endpos - r.BaseStream.Position) % 2 == 0) r.ReadByte();

            // XX 00 00 XX XX XX XX XX 00
            // XX = 00 | 01
            uba2 = r.ReadBytes(9);

            compiledTemplate = classReader.ReadProperty<CompiledMaterialTemplate>(r);

            r.ReadByte(); // 3

            color1 = classReader.ReadProperty<IColor>(r);
            color2 = classReader.ReadProperty<IColor>(r);
            IsLoaded = true;
        }

        public override void Unload()
        {
            classReader = null;
            template = null;
            compiledTemplate = null;
            color1 = null;
            color2 = null;
            IsLoaded = false;
        }

        public override object GetData()
        {
            if (!IsLoaded) Load();
            return this;
        }
    }
}