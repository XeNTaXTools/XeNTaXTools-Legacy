﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace forgelib.Resources.Geometry
{
    public struct VectorFloat4
    {
        public float X;
        public float Y;
        public float Z;
        public float W;

        public VectorFloat4(float x, float y, float z, float w)
            : this()
        {
            X = x;
            Y = y;
            Z = z;
            W = w;
        }

        public VectorFloat4(BinaryReader r)
            : this()
        {
            X = r.ReadSingle();
            Y = r.ReadSingle();
            Z = r.ReadSingle();
            W = r.ReadSingle();
        }

        public float[] ToArray()
        {
            return new float[] { X, Y, Z, W };
        }

        public override string ToString()
        {
            return string.Format(System.Globalization.CultureInfo.InvariantCulture,
                "{0:0.000000} {1:0.000000} {2:0.000000} {3:0.000000}", X, Y, Z, W);
        }
    
    }
}
