﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace forgelib.Resources.Geometry
{
    public struct VectorFloat2
    {
        public float X;
        public float Y;

        public VectorFloat2(float x, float y)
            : this()
        {
            X = x;
            Y = y;
        }

        public VectorFloat2(BinaryReader r)
            : this()
        {
            X = r.ReadSingle();
            Y = r.ReadSingle();
        }

        public override string ToString()
        {
            return string.Format(System.Globalization.CultureInfo.InvariantCulture,
                "{0:0.000000} {1:0.000000}", X, Y);
        }
    
    }
}
