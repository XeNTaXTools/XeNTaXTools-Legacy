﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace forgelib.Resources.Geometry
{
    public struct PackedVectorByte4
    {
        public float X;
        public float Y;
        public float Z;
        public float W;

        public PackedVectorByte4(uint color)
            : this(color, false)
        { }

        public PackedVectorByte4(uint color, bool unsigned)
            : this()
        {
            byte[] data = BitConverter.GetBytes(color);
            decompress(data, 0, unsigned);
        }

        public PackedVectorByte4(byte[] data, int offset)
            : this(data, offset, false)
        { }

        public PackedVectorByte4(byte[] data, int offset, bool unsigned)
            : this()
        {
            decompress(data, offset, unsigned);
        }

        public PackedVectorByte4(BinaryReader r)
            : this(r, false)
        { }

        public PackedVectorByte4(BinaryReader r, bool unsigned)
            : this()
        {
            byte[] data = r.ReadBytes(4);
            decompress(data, 0, unsigned);
        }

        private void decompress(byte[] data, int offset, bool unsigned)
        {
            if (unsigned)
            {
                X = data[offset] / 255f;
                Y = data[offset + 1] / 255f;
                Z = data[offset + 2] / 255f;
                W = data[offset + 3] / 255f;
            }
            else
            {
                X = data[offset] / 127.5f - 1f;
                Y = data[offset + 1] / 127.5f - 1f;
                Z = data[offset + 2] / 127.5f - 1f;
                W = data[offset + 3] / 127.5f - 1f;
            }
        }

        public override string ToString()
        {
            return string.Format(System.Globalization.CultureInfo.InvariantCulture,
                "{0:0.000000} {1:0.000000} {2:0.000000} {3:0.000000}", X, Y, Z, W);
        }
    
    }
}
