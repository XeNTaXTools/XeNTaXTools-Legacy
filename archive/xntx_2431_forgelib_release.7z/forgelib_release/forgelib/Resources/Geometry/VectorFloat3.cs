﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace forgelib.Resources.Geometry
{
    public struct VectorFloat3
    {
        public float X;
        public float Y;
        public float Z;

        public VectorFloat3(float x, float y, float z)
            : this()
        {
            X = x;
            Y = y;
            Z = z;
        }

        public VectorFloat3(BinaryReader r)
            : this()
        {
            X = r.ReadSingle();
            Y = r.ReadSingle();
            Z = r.ReadSingle();
        }

        public override string ToString()
        {
            return string.Format(System.Globalization.CultureInfo.InvariantCulture,
                "{0:0.000000} {1:0.000000} {2:0.000000}", X, Y, Z);
        }
    
    }
}
