﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace forgelib.Resources.Geometry
{
    public struct PackedVectorShort2
    {
        public float X;
        public float Y;

        public PackedVectorShort2(byte[] data, int offset)
            : this(data, offset, 2048f)
        { }

        public PackedVectorShort2(byte[] data, int offset, float quant)
            : this()
        {
            decompress(data, offset, quant);
        }

        public PackedVectorShort2(BinaryReader r)
            : this(r, 2048f)
        { }

        public PackedVectorShort2(BinaryReader r, float quant)
            : this()
        {
            byte[] data = r.ReadBytes(4);
            decompress(data, 0, quant);
        }

        private void decompress(byte[] data, int offset, float quant)
        {
            X = BitConverter.ToInt16(data, offset) / quant;
            Y = BitConverter.ToInt16(data, offset + 2) / quant;
        }

        public override string ToString()
        {
            return string.Format(System.Globalization.CultureInfo.InvariantCulture,
                "{0:0.000000} {1:0.000000}", X, Y);
        }
    
    }
}
