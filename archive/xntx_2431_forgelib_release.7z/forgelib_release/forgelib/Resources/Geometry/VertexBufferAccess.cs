﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace forgelib.Resources.Geometry
{
    public class VertexBufferAccess
    {
        public enum ElementType
        {
            PackedShort2,
            PackedShort3,
            PackedByte4,
            PackedByte4U
        }

        public enum Semantic
        { 
            Position,
            Normal,
            Tangent,
            Binormal,
            UV0,
            BlendWeights,
        }

        int stride;
        byte[] buffer;
        Dictionary<Semantic, int> offsets = new Dictionary<Semantic, int>();
        Dictionary<Semantic, ElementType> types = new Dictionary<Semantic, ElementType>();

        public bool HasBlendData { get; private set; }
        int blendIndexOffset;

        public VertexBufferAccess(byte[] buffer, int stride)
        {
            this.stride = stride;
            this.buffer = buffer;
        }

        public void AddElement(int offset, ElementType type, Semantic semantic)
        {
            types.Add(semantic, type);
            offsets.Add(semantic, offset);
        }

        public void AddBlendIndicesElement(int offset)
        {
            HasBlendData = true;
            blendIndexOffset = offset;
        }

        public int[] GetBlendIndices(int index)
        {
            if (!HasBlendData) return new int[0];
            int offset = index * stride + blendIndexOffset;
            List<int> tmp = new List<int>();
            for (int i = 0; i < 4; i++)
            {
                sbyte b = (sbyte)buffer[offset + i];
                if (b >= 0) tmp.Add(b);
            }
            return tmp.ToArray();
        }

        public VectorFloat4 GetElement(Semantic semantic, int index)
        {
            if (types.ContainsKey(semantic))
            {
                int offset = index * stride + offsets[semantic];
                switch (types[semantic])
                {
                    case ElementType.PackedByte4:
                        {
                            PackedVectorByte4 tmp = new PackedVectorByte4(buffer, offset);
                            return new VectorFloat4(tmp.X, tmp.Y, tmp.Z, tmp.W);
                        }
                    
                    case ElementType.PackedByte4U:
                        {
                            PackedVectorByte4 tmp = new PackedVectorByte4(buffer, offset, true);
                            return new VectorFloat4(tmp.X, tmp.Y, tmp.Z, tmp.W);
                        }
                    
                    case ElementType.PackedShort2:
                        {
                            PackedVectorShort2 tmp = new PackedVectorShort2(buffer, offset);
                            return new VectorFloat4(tmp.X, tmp.Y, 0, 0);
                        }

                    case ElementType.PackedShort3:
                        {
                            PackedVectorShort3 tmp = new PackedVectorShort3(buffer, offset);
                            return new VectorFloat4(tmp.X, tmp.Y, tmp.Z, 0);
                        }
                }
            }
        
            return new VectorFloat4();
        }

    }
}
