﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.ComponentModel;
using forgelib.Nodes;

namespace forgelib.Resources
{
    [TypeConverter(typeof(ExpandableObjectConverter))]
    public class ResourceDependency
    {
        public short DependencyFlag { get; private set; } // 3 = no dependency, 0x0001, 0x0201 dependency
        public uint RequiredResourceId { get; private set; }

        public ResourceBase Resource { get; set; }

        public ResourceDependency(BinaryReader r)
        {
            DependencyFlag = r.ReadInt16();
            RequiredResourceId = r.ReadUInt32();
        }

        public override string ToString()
        {
            if (Resource != null) return Resource.ToString();
            return string.Format("0x{0:x4} 0x{1:x8}", DependencyFlag, RequiredResourceId);
        }

        public void Resolve(IFileSystemInfo container)
        {
            if (DependencyFlag != 3) Resource = container.FindDependencyById(RequiredResourceId) as ResourceBase;
        }
    }
}
