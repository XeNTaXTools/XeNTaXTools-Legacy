﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using forgelib.Nodes;
using forgelib.Utils;
using forgelib.Hash;
using System.ComponentModel;

namespace forgelib.Resources
{
    [KnownTypeRegistry.KnownType("Skeleton")]
    [TypeConverter(typeof(ExpandableObjectConverter))]
    public class Skeleton : ResourceBase
    {
        static readonly uint CONST_SkeletonPoseGroup = CRC32.ComputeHash("SkeletonPoseGroup");
        static readonly uint CONST_SkeletonPose = CRC32.ComputeHash("SkeletonPose");
        static readonly uint CONST_SkeletonPoseBone = CRC32.ComputeHash("SkeletonPoseBone");
        static readonly uint CONST_IKData = CRC32.ComputeHash("IKData");
        
        public class KnownBoneModifierAttribute : Attribute
        {
            public readonly string Name;
            public readonly uint Id;

            public KnownBoneModifierAttribute(string name)
            {
                this.Name = name;
                Id = CRC32.ComputeHash(name);
            }
        }

        static class KnownBoneModifierRegistry
        {
            static Dictionary<uint, Type> typeLookup;
            static Dictionary<uint, string> typeNameLookup;

            private static void buildTypeLookup()
            {
                typeLookup = new Dictionary<uint, Type>();
                typeNameLookup = new Dictionary<uint, string>();
                foreach (Type type in System.Reflection.Assembly.GetAssembly(typeof(KnownBoneModifierRegistry)).GetTypes())
                {
                    if (type.IsSubclassOf(typeof(BoneModifier)) == true)
                    {
                        object[] attributes = type.GetCustomAttributes(typeof(KnownBoneModifierAttribute), false);
                        if (attributes.Length == 1)
                        {
                            KnownBoneModifierAttribute attribute = (KnownBoneModifierAttribute)attributes[0];
                            typeLookup.Add(attribute.Id, type);
                            typeNameLookup.Add(attribute.Id, attribute.Name);
                        }
                    }
                }
            }

            public static Type GetType(uint typeId)
            {
                if (typeLookup == null)
                {
                    buildTypeLookup();
                }

                if (typeLookup.ContainsKey(typeId))
                {
                    return typeLookup[typeId];
                }

                return null;
            }

            public static string GetTypeName(uint typeId)
            {
                if (typeNameLookup == null)
                {
                    buildTypeLookup();
                }

                if (typeNameLookup.ContainsKey(typeId))
                {
                    return typeNameLookup[typeId];
                }

                return null;
            }
        }

        public class BoneModifierReader
        {
            public static BoneModifier ReadModifier(BinaryReader r)
            {
                BoneModifier m = new BoneModifier(r);
                Type t = KnownBoneModifierRegistry.GetType(m.TypeId);
                if (t != null)
                {
                    try
                    {
                        m = (BoneModifier)System.Activator.CreateInstance(t, m, r);
                    }
                    catch (Exception ex)
                    {
                        throw ex.InnerException;
                    }
                }
                else
                {
                    throw new NotSupportedException("Unknown Bone Modifier...");
                }
                return m;
            }
        }

        public interface IHasId
        {
            uint Id { get;}
        }

        [TypeConverter(typeof(ExpandableObjectConverter))]
        public class Reference
        {
            public byte Type { get; private set; }
            public uint RefId { get; private set; }
            public bool IsShortReference { get; private set; }

            public object Ref { get; private set; }

            public Reference(byte type, uint _ref)
            {
                Type = type;
                RefId = _ref;
            }

            public void Resolve(IEnumerable<IHasId> container)
            {
                if(Type != 3) Ref = container.SingleOrDefault(c => c.Id == RefId);
            }

            public Reference(BinaryReader r)
            {
                Type = r.ReadByte();
                if (Type == 2)
                {
                    RefId = r.ReadUInt32();
                }
                else if (Type != 3)
                {
                    // multiplayer uses different type....
                    r.BaseStream.Position -= 1;
                    int test = r.ReadInt32();
                    if (test == -1)
                    {
                        Type = 3;
                    }
                    else
                    {
                        Type = 2;
                        RefId = (uint)test;
                    }
                    IsShortReference = true;
                }
            }

            public override string ToString()
            {
                if (Ref != null) return Ref.ToString();
                if (Type == 3) return "NULL";
                return string.Format("0x{0:x8}", RefId);
            }
        }

        [TypeConverter(typeof(ExpandableObjectConverter))]
        public class BoneModifier : IHasId
        {
            byte U1;
            public uint Id { get; private set; }
            public uint TypeId;
            Reference U2;
            byte U3;

            public BoneModifier(BoneModifier other)
            {
                U1 = other.U1;
                Id = other.Id;
                U2 = other.U2;
                U3 = other.U3;
            }

            public BoneModifier(BinaryReader r)
            {
                U1 = r.ReadByte(); // 0
                Id = r.ReadUInt32();
                TypeId = r.ReadUInt32();
                U2 = new Reference(r);
                U3 = r.ReadByte();
            }

            public override string ToString()
            {
                return string.Format("{0} {1}", KnownBoneModifierRegistry.GetTypeName(TypeId), U2);
            }
        }

        [KnownBoneModifier("HingeBoneModifier")]
        public class HingeBoneModifier : BoneModifier
        {
            [TypeConverter(typeof(ExpandableObjectConverter))]
            public class Hinge : IHasId
            {
                public uint Id { get; private set; }
                public Reference U1 { get; private set; }
                public float[] U2 { get; private set; }
                public bool v2 { get; private set; }

                static readonly uint CONST_Hinge = CRC32.ComputeHash("Hinge");

                public Hinge(BinaryReader r, bool _v2)
                {
                    Id = r.ReadUInt32();
                    uint magic = r.ReadUInt32();
                    if (magic != CONST_Hinge)
                    {
                        throw new ResourceReadException(CONST_Hinge, magic);
                    }

                    v2 = _v2;
                    if (v2)
                    {
                        uint test = r.ReadUInt32();
                        if (test == 0xffffffff)
                        {
                            U1 = new Reference(3, 0);
                        }
                        else
                        {
                            U1 = new Reference(2, test);
                        }
                    }
                    else
                    {
                        U1 = new Reference(r);
                        this.v2 = U1.IsShortReference;
                    }
                    
                    if (v2)
                    {
                        U2 = new float[20];
                        for (int i = 0; i < U2.Length; i++) U2[i] = r.ReadSingle();
                    }
                    else
                    {
                        U2 = new float[12];
                        for (int i = 0; i < U2.Length; i++) U2[i] = r.ReadSingle();
                    }
                }
            }

            public float[] U4 { get; private set; }
            public Reference U5 { get; private set; }
            public float U6 { get; private set; }
            public uint U7 { get; private set; }
            public uint U8 { get; private set; }
            public Hinge[] Hinges { get; private set; }

            public float U9 { get; private set; }
            public float U10 { get; private set; }
            public float U11 { get; private set; }
            public float U12 { get; private set; }
            
            public HingeBoneModifier(BoneModifier other, BinaryReader r)
                : base(other)
            {
                U4 = new float[6];
                for(int i = 0; i < U4.Length; i++) U4[i] = r.ReadSingle();
                U5 = new Reference(r);
                U6 = r.ReadSingle();
                U7 = r.ReadUInt32();
                U8 = r.ReadUInt32();
                int count = r.ReadInt32();
                Hinges = new Hinge[count];

                bool hingeV2 = false;
                for (int i = 0; i < count; i++)
                {
                    Hinges[i] = new Hinge(r, hingeV2);
                    hingeV2 = Hinges[i].v2;
                }
                U9 = r.ReadSingle();
                U10 = r.ReadSingle();
                U11 = r.ReadSingle();
                U12 = r.ReadSingle();
            }
        }

        [KnownBoneModifier("LookAtBoneModifier")]
        public class LookAtBoneModifier : BoneModifier
        {
            public Reference U5 { get; private set; }
            public Reference U6 { get; private set; }
            public int U7 { get; private set; }
            public int U8 { get; private set; }
            public int U9 { get; private set; }
            public int U10 { get; private set; }
            public float U11 { get; private set; }
            public float U12 { get; private set; }
            public int U14 { get; private set; }
            public int U15 { get; private set; }
            public int U16 { get; private set; }
            public int U17 { get; private set; }
            public int U18 { get; private set; }

            public bool v2 { get; private set; }

            public LookAtBoneModifier(BoneModifier other, BinaryReader r)
                : base(other)
            {
                U5 = new Reference(r);
                if (U5.IsShortReference)
                {
                    v2 = true;
                    
                    uint test = r.ReadUInt32();
                    if (test == 0xffffffff)
                    {
                        U6 = new Reference(3, 0);
                    }
                    else
                    {
                        U6 = new Reference(2, test);
                    }
                }
                else
                {
                    U6 = new Reference(r);
                }

                U7 = r.ReadInt32();
                U8 = r.ReadInt32();
                U9 = r.ReadInt32();
                U10 = r.ReadInt32();
                U11 = r.ReadSingle();
                U12 = r.ReadSingle();
                U14 = r.ReadInt32();
                U15 = r.ReadInt32();
                U16 = r.ReadInt32();
                U17 = r.ReadInt32();
                U18 = r.ReadInt32();
            }
        }

        [KnownBoneModifier("RotationPasteModifier")]
        public class RotationPasteModifier : BoneModifier
        {
            public Reference U5 { get; private set; }

            public RotationPasteModifier(BoneModifier other, BinaryReader r)
                : base(other)
            {
                U5 = new Reference(r);
            }
        }

        [KnownBoneModifier("RollBoneModifier")]
        public class RollBoneModifier : BoneModifier
        {
            public uint U4 { get; private set; }
            public float U5 { get; private set; }
            public Reference U6 { get; private set; }

            public RollBoneModifier(BoneModifier other, BinaryReader r)
                : base(other)
            {
                U4 = r.ReadUInt32();
                U5 = r.ReadSingle();
                U6 = new Reference(r);
            }
        }

        [KnownBoneModifier("SpringBoxModifier")]
        public class SpringBoxModifier : BoneModifier
        {
            public float[] U4 { get; private set; }

            public SpringBoxModifier(BoneModifier other, BinaryReader r)
                : base(other)
            {
                U4 = new float[15];
                for (int i = 0; i < U4.Length; i++) U4[i] = r.ReadSingle();
            }
        }

        [KnownBoneModifier("PendulumBoneModifier")]
        public class PendulumBoneModifier : BoneModifier
        {
            public uint U4 { get; private set; }
            public float[] U5 { get; private set; }

            public PendulumBoneModifier(BoneModifier other, BinaryReader r)
                : base(other)
            {
                U4 = r.ReadUInt32();
                U5 = new float[14];
                for (int i = 0; i < U5.Length; i++) U5[i] = r.ReadSingle();
            }
        }

        [KnownBoneModifier("CompressBoneModifier")]
        public class CompressBoneModifier : BoneModifier
        {
            public float[] U4 { get; private set; }
            public Reference U5 { get; private set; }
            public Reference U6 { get; private set; }
            public float[] U7 { get; private set; }
            public uint U8 { get; private set; }
            public float[] U9 { get; private set; }
            public uint U10 { get; private set; }
            public byte U11 { get; private set; }
            public byte U12 { get; private set; }

            public CompressBoneModifier(BoneModifier other, BinaryReader r)
                : base(other)
            {
                U4 = new float[2];
                for (int i = 0; i < U4.Length; i++) U4[i] = r.ReadSingle();
                U5 = new Reference(r);
                U6 = new Reference(r);
                U7 = new float[11];
                for (int i = 0; i < U7.Length; i++) U7[i] = r.ReadSingle();
                U8 = r.ReadUInt32(); // 0
                U9 = new float[3];
                for (int i = 0; i < U9.Length; i++) U9[i] = r.ReadSingle();
                U10 = r.ReadUInt32(); // 0
                U11 = r.ReadByte();
                U12 = r.ReadByte();
            }
        }

        [TypeConverter(typeof(ExpandableObjectConverter))]
        public class Bone : IHasId
        {
            static readonly uint CONST_Bone = CRC32.ComputeHash("Bone");

            byte U01;
            public uint Id { get; private set; }
            public uint NameHash { get; private set; }
            
            [Browsable(false)]
            public Reference _parentBoneRef { get; private set; }

            public Bone ParentBone { get { return _parentBoneRef.Ref as Bone; } }
            
            public Reference U03 { get; private set; }
            public float[] Transform { get; private set; }
            public byte U04 { get; private set; }
            public uint U05 { get; private set; }
            public BoneModifier[] Modifiers { get; private set; }

            public byte Index { get; private set; }
            public byte NumAllChildren { get; private set; }

            private IEnumerable<Bone> boneList;
            public Bone[] Children
            {
                get
                {
                    if (boneList == null) return new Bone[0];
                    return new List<Bone>(boneList.Where(c => c.ParentBone == this)).ToArray();
                }
            }

            public Bone(BinaryReader r, IEnumerable<Bone> boneList)
            {
                this.boneList = boneList;
                
                U01 = r.ReadByte(); // 0
                Id = r.ReadUInt32();
                uint magic = r.ReadUInt32();
                if (magic != CONST_Bone) throw new ResourceReadException(CONST_Bone, magic);

                NameHash = r.ReadUInt32();
                _parentBoneRef = new Reference(r);
                U03 = new Reference(r);
                Transform = new float[16];
                for (int i = 0; i < Transform.Length; i++) Transform[i] = r.ReadSingle();

                U04 = r.ReadByte();
                U05 = r.ReadUInt32();
                uint Count2 = r.ReadUInt32();
                Modifiers = new BoneModifier[Count2];
                for (int i = 0; i < Count2; i++)
                {
                    BoneModifier m = BoneModifierReader.ReadModifier(r);
                    Modifiers[i] = m;
                }
                Index = r.ReadByte();
                NumAllChildren = r.ReadByte();
            }

            public override string ToString()
            {
                return string.Format("0x{0:x8} {1}", Id, HashLookup.GetHashedString(NameHash));
            }
        
        }

        [TypeConverter(typeof(ExpandableObjectConverter))]
        public class SkeletonPoseBone
        {
            public uint Id { get; private set; }
            public uint PoseNameHash { get; private set; }
            public uint U1 { get; private set; }
            public uint U2 { get; private set; }
            public uint U3 { get; private set; }
           
            public SkeletonPoseBone(BinaryReader r)
            {
                Read(r);
            }

            public void Read(BinaryReader r)
            {
                Id = r.ReadUInt32();
                uint magic = r.ReadUInt32();
                if (magic != CONST_SkeletonPoseBone) throw new ResourceReadException(CONST_SkeletonPoseBone, magic);
                PoseNameHash = r.ReadUInt32();
                U1 = r.ReadUInt32();
                U2 = r.ReadUInt32();
                U3 = r.ReadUInt32();
            }
        }

        [TypeConverter(typeof(ExpandableObjectConverter))]
        public class SkeletonPose
        {
            public uint Id { get; private set; }
            public uint U1 { get; private set; }
            public SkeletonPoseBone[] Bones { get; private set; }

            public SkeletonPose(BinaryReader r)
            {
                Read(r);
            }

            public void Read(BinaryReader r)
            {
                Id = r.ReadUInt32();
                uint magic = r.ReadUInt32();
                if (magic != CONST_SkeletonPose) throw new ResourceReadException(CONST_SkeletonPose, magic);
                U1 = r.ReadUInt32();
                int count = r.ReadInt32();
                Bones = new SkeletonPoseBone[count];
                for (int i = 0; i < count; i++) Bones[i] = new SkeletonPoseBone(r);
            }
        }

        [TypeConverter(typeof(ExpandableObjectConverter))]
        public class SkeletonPoseGroup
        {
            public uint Id { get; private set; }
            public SkeletonPose[] Poses { get; private set; }

            public SkeletonPoseGroup(BinaryReader r)
            {
                Read(r);
            }

            public void Read(BinaryReader r)
            {
                Id = r.ReadUInt32();
                uint magic = r.ReadUInt32();
                if (magic != CONST_SkeletonPoseGroup) throw new ResourceReadException(CONST_SkeletonPoseGroup, magic);
                int count = r.ReadInt32();
                Poses = new SkeletonPose[count];
                for (int i = 0; i < count; i++) Poses[i] = new SkeletonPose(r);
            }
        }

        [TypeConverter(typeof(ExpandableObjectConverter))]
        public class COMData
        {
            static readonly uint CONST_COMData = CRC32.ComputeHash("COMData");

            public uint Id { get; private set; }

            public float[] U1 { get; private set; }

            public COMData(BinaryReader r)
            {
                Read(r);
            }

            public void Read(BinaryReader r)
            {
                Id = r.ReadUInt32();
                uint magic = r.ReadUInt32();
                if (magic != CONST_COMData) throw new ResourceReadException(CONST_COMData, magic);
                U1 = new float[8];
                for (int i = 0; i < U1.Length; i++) U1[i] = r.ReadSingle();
            }
        }

        public uint U1 { get; private set; }

        private Bone[] _bones;
        private Reference _rootBoneRef;
        public Bone RootBone { get { return _rootBoneRef.Ref as Bone; } }

        public float[] U3 { get; private set; }
        public ResourceDependency U4 { get; private set; }
        public SkeletonPoseGroup[] PoseGroups { get; private set; }
        public uint IKData { get; private set; }
        public COMData U5 { get; private set; }
        public uint U6 { get; private set; }

        public Skeleton(ResourceBase other)
            : base(other)
        {

        }

        public override void  Load()
        {
            _baseStream.Position = dataOffset;
            BinaryReader r = new BinaryReader(_baseStream);

            U1 = r.ReadUInt32();
            int count = r.ReadInt32();
            _bones = new Bone[count];
            for (int i = 0; i < count; i++)
            {
                Bone b = new Bone(r, _bones);
                _bones[i] = b;
            }
            for (int i = 0; i < count; i++)
            {
                //Bones[i].U03.Resolve(Bones); // => StackOverflow....
                _bones[i]._parentBoneRef.Resolve(_bones);
            }

            _rootBoneRef = new Reference(r);
            _rootBoneRef.Resolve(_bones);

            U3 = new float[8];
            for (int i = 0; i < U3.Length; i++) U3[i] = r.ReadSingle();
            U4 = new ResourceDependency(r);

            count = r.ReadInt32();
            PoseGroups = new SkeletonPoseGroup[count];
            for (int i = 0; i < count; i++)
            {
                PoseGroups[i] = new SkeletonPoseGroup(r);
            }

            byte flag = r.ReadByte();
            if (flag == 0)
            {
                uint _id = r.ReadUInt32();
                uint magic = r.ReadUInt32();
                if (magic != CONST_IKData) throw new ResourceReadException(CONST_IKData, magic);
                IKData = _id;
            }
            //else if (flag != 3) System.Diagnostics.Debugger.Break();

            flag = r.ReadByte();
            if (flag == 0)
            {
                U5 = new COMData(r);
            }
            //else if (flag != 3) System.Diagnostics.Debugger.Break();

            r.ReadBytes(6); // 030000000000
            U6 = r.ReadUInt32();

            U4.Resolve(this);
            
            IsLoaded = true;
        }

        public override void Unload()
        {
            _bones = null;
            _rootBoneRef = null;
            U3 = null;
            U4 = null;
            PoseGroups = null;
            U5 = null;
        }

        public override object GetData()
        {
            if (!IsLoaded) Load();
            return this;
        }
    }
}
