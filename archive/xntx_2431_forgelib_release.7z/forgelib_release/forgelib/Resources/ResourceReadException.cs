﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace forgelib.Resources
{
    public class ResourceReadException : Exception
    {
        public ResourceReadException(uint expected, uint got)
              : base(string.Format("Expected Resource Id 0x{0:x8}, Got: 0x{1:x8}"))
        { 
        
        }
    }
}
