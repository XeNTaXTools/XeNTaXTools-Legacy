﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using forgelib.Nodes;

namespace forgelib.Resources
{
    [KnownTypeRegistry.KnownType("TextureMapSpec")]
    public class TextureMapSpec : ResourceBase
    {
        public TextureMapSpec(ResourceBase other)
            : base(other)
        {
            ReadTmp(_baseStream);
        }

        public void ReadTmp(Stream input)
        {
            /*
            BinaryReader r = new BinaryReader(input);

            long endpos = r.BaseStream.Position + (Length - 9);
            int rest = (int)(endpos - r.BaseStream.Position);
            byte[] buf = r.ReadBytes(rest);
            DebugStringCollector.ParseForStrings(buf);
            */
        }
    }
}
