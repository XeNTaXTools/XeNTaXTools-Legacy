﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using forgelib.Utils;

namespace forgelib.Resources
{
    public class CompressedLocalizationData
    {
        private class CompressedStringFragment
        {
            private ushort rightIndexOrChar; // if LeftIndex == 0  => value is char, else value is index
            private ushort leftIndex;

            private string rightValue = null;
            private string leftValue = null;

            public string Value { get; private set; }

            public CompressedStringFragment()
            { 

            }

            public CompressedStringFragment(BinaryReader r)
            {
                Read(r);
            }

            public void Read(BinaryReader r)
            { 
                rightIndexOrChar = r.ReadUInt16();
                leftIndex = r.ReadUInt16();
            }

            public void Resolve(CompressedStringFragment[] list)
            {
                if(Value == null) Value = resolveString(list);
            }

            private string resolveString(CompressedStringFragment[] list)
            {
                // linked list index == 0
                if (leftIndex == 0 && rightIndexOrChar == 0) return "";
                
                // is character
                if (leftIndex == 0) return Encoding.Unicode.GetString(BitConverter.GetBytes(rightIndexOrChar));

                // is linked list element
                if (rightValue == null && rightIndexOrChar >= 0 && rightIndexOrChar < list.Length)
                {
                    list[rightIndexOrChar].Resolve(list);
                    rightValue = list[rightIndexOrChar].Value;
                }
                if (leftValue == null && leftIndex >= 0 && leftIndex < list.Length)
                {
                    list[leftIndex].Resolve(list);
                    leftValue = list[leftIndex].Value;
                }

                return leftValue + rightValue;
            }

            public override string ToString()
            {
                return Value;
            }
        }
        
        public class StringTableEntry
        {
            public uint Id { get; private set; }
            public ushort Offset { get; private set; }

            public string DecodedString { get; set; }

            public StringTableEntry(uint id, ushort offset)
            {
                Id = id;
                Offset = offset;
            }

            public override string ToString()
            {
                return string.Format("[0x{0:x8}] {1}", Id, DecodedString);
            }
        }

        public class StringTableEntryCollection
        {
            public uint FirstEntryId { get; private set; }
            public uint EntryHeadersOffset { get; private set; }
            public uint EntriesDataOffset { get; private set; }

            public StringTableEntry[] Entries { get; set; }

            public StringTableEntryCollection()
            { 
            
            }

            public StringTableEntryCollection(BinaryReader r)
            {
                Read(r);
            }

            public void Read(BinaryReader r)
            { 
                FirstEntryId = r.ReadUInt32();
                EntryHeadersOffset = r.ReadUInt32();
                EntriesDataOffset = r.ReadUInt32();
            }

            public override string ToString()
            {
                return string.Format("StartID: 0x{0:x8}, ({1:0000} Entries)", FirstEntryId, Entries.Length);
            }
        }
        
        private ushort maxStringFragmentIndex;
        private int stringFragmentIndexMask; // computed: maxStringFragmentIndex * 255
        private ushort numStringFrags;

        public StringTableEntryCollection[] StringTables { get; private set; }
        
        public CompressedLocalizationData(Stream input)
        {
            read(input);
        }

        private void read(Stream input)
        {
            BinaryReader r = new BigEndianBinaryReader(input);

            #region read linked list structure of chars & string fragments
            maxStringFragmentIndex = r.ReadUInt16();

            // used for indexing (2 byte index)
            // explanation: 
            //  - fragments are indexed by byte values. 
            //  - if an index > maxStringFragmentIndex => read next byte, interpret as ushort, substract mask and you have your index...
            //  - special case: index == 255 => read next to bytes and interpret as ushort index
            stringFragmentIndexMask = maxStringFragmentIndex * 255;

            numStringFrags = r.ReadUInt16();
            
            // read list
            CompressedStringFragment[] stringFragments = new CompressedStringFragment[numStringFrags];
            for (int i = 0; i < numStringFrags; i++)
            {
                stringFragments[i] = new CompressedStringFragment(r);
            }

            // resolve list
            for (int i = 0; i < numStringFrags; i++)
            {
                stringFragments[i].Resolve(stringFragments);
            }
            #endregion

            ushort tablesCount = r.ReadUInt16();
            StringTables = new StringTableEntryCollection[tablesCount];
            for (int i = 0; i < tablesCount; i++)
            {
                StringTables[i] = new StringTableEntryCollection(r);
            }

            for (int i = 0; i < tablesCount; i++)
            {
                r.BaseStream.Position = StringTables[i].EntriesDataOffset;

                ushort entryCount = r.ReadUInt16();
                
                StringTables[i].Entries = new StringTableEntry[entryCount + 1];
                StringTables[i].Entries[0] = new StringTableEntry(StringTables[i].FirstEntryId, r.ReadUInt16());
                
                for (int j = 1; j < entryCount + 1; j++)
                {
                    uint id = (StringTables[i].FirstEntryId + r.ReadUInt16());
                    StringTables[i].Entries[j] = new StringTableEntry(id, r.ReadUInt16());
                }

                r.BaseStream.Position = StringTables[i].EntryHeadersOffset;

                int numConsumedCodes = 0;
                
                for (int j = 0; j < StringTables[i].Entries.Length; j++)
                {
                    int endOffset = StringTables[i].Entries[j].Offset;
                    StringTables[i].Entries[j].DecodedString = decodeString(r, stringFragments, endOffset, ref numConsumedCodes);
                }
            }
        }

        private string decodeString(BinaryReader r, CompressedStringFragment[] stringFragments, int endOffset, ref int numConsumedCodes)
        {

            StringBuilder sb = new StringBuilder();
            #region index reading magic...
            while (numConsumedCodes < endOffset)
            {

                byte b = r.ReadByte();
                numConsumedCodes++;
                if (b < maxStringFragmentIndex)
                {
                    sb.Append(stringFragments[b + 1].ToString());
                }
                else if (b == 255)
                {
                    int decIndex = r.ReadInt16();
                    sb.Append(stringFragments[decIndex + 1].ToString());
                    numConsumedCodes += 2;
                }
                else
                {
                    int decIndex = b << 8;
                    b = r.ReadByte();
                    decIndex |= b;
                    numConsumedCodes++;

                    decIndex -= stringFragmentIndexMask;

                    sb.Append(stringFragments[decIndex + 1].ToString());
                }
            }
            #endregion

            return sb.ToString();
        }

        public void WriteToFile(string filename)
        {
            if (StringTables == null || StringTables.Length == 0) return;
            using (StreamWriter w = new StreamWriter(filename))
            {
                foreach (var t in StringTables)
                {
                    foreach (var e in t.Entries)
                    {
                        w.WriteLine(string.Format("[0x{0:x8}]", e.Id));
                        w.WriteLine(e.DecodedString);
                        w.WriteLine();
                    }
                }
            }
        }
    }
}
