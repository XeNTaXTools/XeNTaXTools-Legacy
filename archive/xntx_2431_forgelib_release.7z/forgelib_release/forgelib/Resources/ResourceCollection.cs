﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using forgelib.Nodes;

namespace forgelib.Resources
{
    public class ResourceCollection : ResourceBase, IList<ResourceBase>
    {
        public override string Name { get { return resources[0].Name; } }
        public override uint EntryId { get { return resources[0].EntryId; } }

        protected ResourceDirectoryTable resDirectory;
        private readonly List<ResourceBase> resources = new List<ResourceBase>();

        public ResourceCollection(ResourceDirectoryTable directory, FileEntry container)
            : base(container)
        {
            resDirectory = directory;
        }

        public void AddResource(ResourceBase res)
        {
            resources.Add(res);
        }

        public override void Load()
        {
            foreach (var r in resources)
            {
                if(!r.IsLoaded) r.Load();
            }
        }

        public override void Unload()
        {
            foreach (var r in resources)
            {
                if (r.IsLoaded) r.Unload();
            }
        }

        public override int Index { get; set; }

        public override int NumReadFiles
        {
            get
            {
                int numReads = 0;
                if (resources != null && resources.Count != 0)
                {
                    foreach (var r in resources)
                    {
                        numReads += r.NumReadFiles;
                    }
                }
                return numReads;
            }
        }

        public override long Length
        {
            get { return resDirectory.Length; }
        }

        public override string Type
        {
            get { return string.Format("Resource Collection ({0})", resources[0].Type); }
        }

        public override bool IsDirectory
        {
            get { return resources != null && resources.Count != 0; }
        }

        public override List<IFileSystemInfo> GetFiles()
        {
            throw new NotImplementedException();
        }

        public override List<IFileSystemInfo> GetFilesystemInfos()
        {
            return new List<IFileSystemInfo>(resources);
        }

        public override List<IFileSystemInfo> GetDirectories()
        {
            throw new NotImplementedException();
        }

        public override IFileSystemInfo FindDependencyById(uint id)
        {
            foreach (var r in resources)
            {
                if (r.EntryId == id) return r;
            }
            return _container.FindDependencyById(id);
        }

        #region IList<ResourceBase>

        public int IndexOf(ResourceBase item)
        {
            return resources.IndexOf(item);
        }

        public void Insert(int index, ResourceBase item)
        {
            throw new NotImplementedException();
        }

        public void RemoveAt(int index)
        {
            throw new NotImplementedException();
        }

        public ResourceBase this[int index]
        {
            get
            {
                return resources[index];
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public void Add(ResourceBase item)
        {
            throw new NotImplementedException();
        }

        public void Clear()
        {
            throw new NotImplementedException();
        }

        public bool Contains(ResourceBase item)
        {
            return resources.Contains(item);
        }

        public void CopyTo(ResourceBase[] array, int arrayIndex)
        {
            resources.CopyTo(array, arrayIndex);
        }

        public int Count
        {
            get { return resources.Count; }
        }

        public bool IsReadOnly
        {
            get { return true; }
        }

        public bool Remove(ResourceBase item)
        {
            throw new NotImplementedException();
        }

        public IEnumerator<ResourceBase> GetEnumerator()
        {
            return resources.GetEnumerator();
        }

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
        #endregion
    }
}
