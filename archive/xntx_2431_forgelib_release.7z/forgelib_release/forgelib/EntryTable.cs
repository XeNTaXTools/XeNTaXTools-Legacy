﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Diagnostics;
using forgelib.Resources;

namespace forgelib
{
    public class EntryTable
    {
        public ForgeFile ForgeFile { get; private set; }
        
        private int numEntries;
        private int numDirectories;

        private long firstEntryPtr;
        public long NextEntryTablePtr  { get; private set; }
        private int startIndex;
        private int endIndex;

        private long entryMetadataTablePtr;
        
        private long directoryPtr; // ???

        public FileEntry[] FileEntries { get; private set; }
        public DirectoryEntry[] DirEntries { get; private set; }

        public EntryTable(BinaryReader r, ForgeFile container)
        {
            ForgeFile = container;
            read(r);
        }

        private void read(BinaryReader r)
        {
            numEntries = r.ReadInt32();             // == Math.Min(maxEntriesPerTable, entryCount)
            numDirectories = r.ReadInt32();             

            firstEntryPtr = r.ReadInt64();          // ptr
            NextEntryTablePtr = r.ReadInt64();      // entryCount == 1 ? -1 : ptr
            
            startIndex = r.ReadInt32();             // 0
            endIndex = r.ReadInt32();               // maxEntriesPerTable - 1

            entryMetadataTablePtr = r.ReadInt64();

            directoryPtr = r.ReadInt64();            

            r.BaseStream.Position = firstEntryPtr;
            FileEntries = new FileEntry[numEntries];
            for (int i = 0, j = startIndex; i < numEntries; i++, j++)
            {
                FileEntries[i] = new FileEntry(r, j, this);
            }

            r.BaseStream.Position = entryMetadataTablePtr;
            for (int i = 0; i < numEntries; i++)
            {
                FileEntries[i].ReadMetadata();
            }

            r.BaseStream.Position = directoryPtr;
            DirEntries = new DirectoryEntry[numDirectories];
            for (int i = 0; i < numDirectories; i++)
            {
                DirEntries[i] = new DirectoryEntry(r, this);
            }
        }
    }
}
