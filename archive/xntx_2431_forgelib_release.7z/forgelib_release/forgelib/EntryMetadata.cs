﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace forgelib
{
    public class EntryMetadata
    {
        public int Size { get; private set; }
        public ulong EntryId { get; private set; }

        private int unkint2;                        // 0
        
        public uint TypeId { get; private set; }
        
        private int unkint4;                        // 0
        private int unkint5;                        // 0

        public int NextIndex { get; private set; }
        public int PreviousIndex { get; private set; }
        
        private int unkint8;                        // 0

        public DateTime Timestamp { get; private set; }

        public string Name { get; private set; }

        private int unkint9;
        private int unkint10;
        private int unkint11;
        
        public int DirectoryIndex { get; private set; }

        public bool IsGlobalMetadata
        {
            get { return unkint9 == 2; }
        }

        public EntryMetadata(BinaryReader r)
        {
            read(r);
        }

        private void read(BinaryReader r)
        {
            Size = r.ReadInt32();
            EntryId = r.ReadUInt64();
            unkint2 = r.ReadInt32(); // 0
            TypeId = r.ReadUInt32(); // hash?
            unkint4 = r.ReadInt32(); // 0
            unkint5 = r.ReadInt32(); // 0
           
            NextIndex = r.ReadInt32();
            PreviousIndex = r.ReadInt32();
            unkint8 = r.ReadInt32(); // 0

            Timestamp = new DateTime(1970, 1, 1).AddSeconds(r.ReadInt32());

            Name = Encoding.UTF8.GetString(r.ReadBytes(128)).TrimEnd('\0');

            unkint9 = r.ReadInt32(); // 2 | 4   2 == GlobalMetadata
            unkint10 = r.ReadInt32(); // 0
            unkint11 = r.ReadInt32(); // == unkint9
            DirectoryIndex = r.ReadInt32(); // 0 | 1 directory ?
        }
    }
}
