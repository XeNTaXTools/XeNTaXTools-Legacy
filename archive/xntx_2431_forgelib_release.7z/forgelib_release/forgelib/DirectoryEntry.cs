﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace forgelib
{
    public class DirectoryEntry
    {
        EntryTable _container;

        public int NumFiles { get; private set; }
        private int unkint2;
        private int unkint3;
        private int unkint4;
        private int unkint5;

        private string name;

        private int unkint6;
        private int unkint7;
        private int unkint8;
        private int unkint9;

        public DirectoryEntry(BinaryReader r, EntryTable container)
        {
            _container = container;
            read(r);
        }

        private void read(BinaryReader r)
        {
            NumFiles = r.ReadInt32();
            unkint2 = r.ReadInt32();
            unkint3 = r.ReadInt32();
            unkint4 = r.ReadInt32();
            unkint5 = r.ReadInt32();

            name = Encoding.UTF8.GetString(r.ReadBytes(128)).TrimEnd('\0');

            unkint6 = r.ReadInt32();
            unkint7 = r.ReadInt32();
            unkint8 = r.ReadInt32();
            unkint9 = r.ReadInt32();
        }
    }
}
