﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Reflection;
using forgelib.Utils;

namespace forgelib.Hash
{
    public static class HashLookup
    {
        static Dictionary<uint, string> knownStrings;

        public static string GetHashedString(uint id)
        {
            ensureLookup();

            if (knownStrings.ContainsKey(id)) return knownStrings[id];
            return string.Format("0x{0:x8}", id);
        }

        private static void ensureLookup()
        {
            if (knownStrings == null)
            {
                buildLookup();
            }
        }

        private static void buildLookup()
        {
            knownStrings = new Dictionary<uint, string>();
            using (StreamReader r = new StreamReader(Assembly.GetAssembly(typeof(HashLookup)).GetManifestResourceStream("forgelib.Hash.Hashes.txt")))
            {
                while (!r.EndOfStream)
                {
                    string l = r.ReadLine();
                    if (!string.IsNullOrEmpty(l))
                    {
                        uint hash = CRC32.ComputeHash(l);
                        if (!knownStrings.ContainsKey(hash)) knownStrings.Add(hash, l);
                    
                    }
                }
            }
        }
    }
}
