﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using forgelib.Utils;

namespace forgelib.Nodes
{
    public class FileEntryCollection : IList<FileEntry>
    {
        private ForgeFile _container;

        public FileEntryCollection(ForgeFile container)
        {
            _container = container;
        }

        #region IList<Entry> Members

        public int IndexOf(FileEntry item)
        {
            throw new NotImplementedException();
        }

        public void Insert(int index, FileEntry item)
        {
            throw new NotImplementedException();
        }

        public void RemoveAt(int index)
        {
            throw new NotImplementedException();
        }

        public FileEntry this[int index]
        {
            get
            {
                return _container.GetEntry(index);
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public void Add(FileEntry item)
        {
            throw new NotImplementedException();
        }

        public void Clear()
        {
            throw new NotImplementedException();
        }

        public bool Contains(FileEntry item)
        {
            return this.SingleOrDefault(c => c == item) != null;
        }

        public void CopyTo(FileEntry[] array, int arrayIndex)
        {
            throw new NotImplementedException();
        }

        public int Count
        {
            get { return _container.NumFileEntries; }
        }

        public bool IsReadOnly
        {
            get { return true; }
        }

        public bool Remove(FileEntry item)
        {
            throw new NotImplementedException();
        }

        public IEnumerator<FileEntry> GetEnumerator()
        {
            return new DefaultListEnumerator<FileEntry>(this);
        }

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }

        #endregion
    }
}
