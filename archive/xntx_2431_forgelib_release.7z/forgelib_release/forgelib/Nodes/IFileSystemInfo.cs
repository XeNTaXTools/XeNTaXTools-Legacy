﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace forgelib.Nodes
{
    public interface IFileSystemInfo
    {
        int Index { get; set; }

        int NumReadFiles { get; }

        string Name { get; }
        long Length { get; }
        string Type { get; }

        bool IsDirectory { get; }
        bool IsKnownResource { get; }

        List<IFileSystemInfo> GetFiles();
        List<IFileSystemInfo> GetFilesystemInfos();
        List<IFileSystemInfo> GetDirectories();

        IFileSystemInfo FindDependencyById(uint id);
    }
}
