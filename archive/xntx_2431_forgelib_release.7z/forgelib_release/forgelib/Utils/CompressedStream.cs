﻿using System;
using System.Collections.Generic;
using System.IO;

namespace forgelib.Utils
{
    class CompressedStream: Stream
    {
        private readonly Stream _baseStream;
        const long HEADER_MAGIC = 0x1004fa9957fbaa33;

        private class Chunk
        {
            private readonly Stream _baseStream;

            private readonly int _offset;
            private readonly int _size;
            private readonly int _compressedOffset;
            private readonly int _compressedSize;

            private byte algo;
            
            private WeakReference _dataRef;
            
            public Chunk(Stream s, int offset, int size, int compressedOffset, int compressedSize, byte compressionAlgo)
            {
                _baseStream = s;
                
                _offset = offset;
                _size = size;
                _compressedSize = compressedSize;
                _compressedOffset = compressedOffset;

                algo = compressionAlgo;
            }

            internal bool Contains(long position)
            {
                return position >= _offset && position < _offset + _size;
            }

            internal byte[] decompressBlock()
            {
                byte[] _data = null;
                
                if(_dataRef != null && _dataRef.IsAlive) _data = _dataRef.Target as byte[];
                
                if (_data == null)
                {
                    _baseStream.Position = _compressedOffset;
                    byte[] compressedData = new byte[_compressedSize];
                    _baseStream.Read(compressedData, 0, _compressedSize);
                    if (_size != _compressedSize)
                    {
                        _data = new byte[_size];
                        int res = 0;
                        switch (algo)
                        {
                            case 1:
                                res = LZODecompressor.lzo1x_decompress(compressedData, _data);
                                break;
                            case 2:
                                res = LZODecompressor.lzo2a_decompress(compressedData, _data);
                                break;
                            default:
                                throw new NotSupportedException("unexpected compression algorithm");

                        }

                        if (res != 0)
                        {
                            throw new Exception("Error decompressing lzo stream...");
                        }

                    }
                    else
                    {
                        _data = compressedData;
                    }

                    _dataRef = new WeakReference(_data);
                }

                return _data;
            }

            internal int Read(Stream s, long offsetInFile, byte[] buffer, int offset, int count)
            {
                int offsetInChunk = (int) (offsetInFile - _offset);
                int bytesRead = 0;
                while (offsetInChunk < _size)
                {
                    int sizeInBlock = Math.Min(count-bytesRead, _size - offsetInChunk);
                    Array.ConstrainedCopy(decompressBlock(), offsetInChunk, buffer, offset, sizeInBlock);
                    bytesRead += sizeInBlock;
                    if (bytesRead == count) break;
                    offset += sizeInBlock;
                    offsetInChunk += sizeInBlock;
                }
                return bytesRead;
            }
        }

        private byte compressionAlgoritm;
        private int length;
        public long OffsetAfterConsume = 0;

        private readonly List<Chunk> _chunks = new List<Chunk>();
        private Chunk _curChunk;

        public CompressedStream(Stream baseStream)
        {
            _baseStream = baseStream;
        }

        public static Stream GetStream(Stream input) 
        {
            long pos = input.Position;

            BinaryReader r = new BinaryReader(input);

            // not compressed, return original
            if (r.ReadInt64() != HEADER_MAGIC)
            {
                input.Position = pos;
                return input;
            }

            ushort unkshort1 = r.ReadUInt16();
            byte ca = r.ReadByte();
            ushort unkshort2 = r.ReadUInt16();
            ushort unkshort3 = r.ReadUInt16();

            short chunkCount = r.ReadInt16();

            if (!(ca == 1 || ca == 2))
            {
                throw new NotSupportedException(string.Format("unknown compression: {0}", ca));
            }

            CompressedStream chunkedStream = new CompressedStream(input);
            chunkedStream.compressionAlgoritm = ca;

            int compressedOffset = (int)r.BaseStream.Position + chunkCount * 4 + 4;
            int uncompressedOffset = 0;
            chunkedStream.length = 0;

            for (int i = 0; i < chunkCount; i++)
            {
                int uncompressedSize = r.ReadUInt16();
                chunkedStream.length += uncompressedSize;
                int compressedSize = r.ReadUInt16();
                chunkedStream.AddChunk(uncompressedOffset, uncompressedSize, compressedOffset, compressedSize, ca);
                compressedOffset += compressedSize + 4;
                uncompressedOffset += uncompressedSize;
            }
            chunkedStream.OffsetAfterConsume = compressedOffset - 4;

            input.Position = pos;

            return chunkedStream;        
        }

        public void AddChunk(int offset, int size, int compressedOffset, int compressedSize, byte compressionAlgo)
        {
            _chunks.Add(new Chunk(_baseStream, offset, size, compressedOffset, compressedSize, compressionAlgo));
        }

        public override void Flush()
        {
            _baseStream.Flush();
        }

        public override long Seek(long offset, SeekOrigin origin)
        {
            switch (origin)
            {
                case SeekOrigin.Begin:
                    Position = offset;
                    break;
                case SeekOrigin.Current:
                    Position += offset;
                    break;
                case SeekOrigin.End:
                    throw new NotImplementedException();
            }
            return Position;
        }

        public override void SetLength(long value)
        {
            throw new System.NotImplementedException();
        }

        [System.Diagnostics.DebuggerStepThrough()]
        public override int Read(byte[] buffer, int offset, int count)
        {
            int curBytesRead = 0;
            int totalBytesRead = 0;
            while(count > 0)
            {
                LoadChunk(Position);
                curBytesRead = _curChunk.Read(_baseStream, Position, buffer, offset, count);
                Position += curBytesRead;
                offset += curBytesRead;
                totalBytesRead += curBytesRead;
                count -= curBytesRead;
            }
            return totalBytesRead;
        }
        
        [System.Diagnostics.DebuggerStepThrough()]
        public override int ReadByte()
        {
            byte[] b = new byte[1];
            Read(b, 0, 1);
            return b[0];
        }

        private void LoadChunk(long position)
        {
            if (_curChunk != null && _curChunk.Contains(position))
                return;
            _curChunk = _chunks.Find(c => c.Contains(position));
        }

        public override void Write(byte[] buffer, int offset, int count)
        {
            throw new System.NotImplementedException();
        }

        public override bool CanRead
        {
            get { return true; }
        }

        public override bool CanSeek
        {
            get { return true; }
        }

        public override bool CanWrite
        {
            get { return false; }
        }

        public override long Length
        {
            get { return length; }
        }

        public override long Position { get; set; }
    }
}
