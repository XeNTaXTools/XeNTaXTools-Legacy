﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace forgelib.Utils
{
    public static class CRC32
    {
        static long[] pTable = new long[256];

        static long Poly = 0xEDB88320;

        static CRC32()
        {
            long CRC;
            int i, j;

            for (i = 0; i < 256; i++)
            {
                CRC = i;

                for (j = 0; j < 8; j++)
                {
                    if ((CRC & 0x1) == 1)
                    {
                        CRC = (CRC >> 1) ^ Poly;
                    }
                    else
                    {
                        CRC = (CRC >> 1);
                    }
                }
                pTable[i] = CRC;
            }

        }

        public static uint ComputeHash(string input)
        {
            return ComputeHash(Encoding.ASCII.GetBytes(input));

        }

        public static uint ComputeHash(byte[] Buffer)
        {
            long CRC;

            CRC = 0xFFFFFFFF;

            for (int i = 0; i < Buffer.Length; i++)
            {
                CRC = ((CRC & 0xFFFFFF00) / 0x100) & 0xFFFFFF ^ pTable[Buffer[i] ^ CRC & 0xFF];
            }

            CRC = (-(CRC)) - 1; // !(CRC)

            return (uint)CRC;
        }

    }
}
