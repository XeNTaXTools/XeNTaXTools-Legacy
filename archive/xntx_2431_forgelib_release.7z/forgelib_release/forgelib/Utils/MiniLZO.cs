/* 
   This file is based on code from the LZO real-time data compression library.

   Copyright (C) 2011 Markus Franz Xaver Johannes Oberhumer
   Copyright (C) 2010 Markus Franz Xaver Johannes Oberhumer
   Copyright (C) 2009 Markus Franz Xaver Johannes Oberhumer
   Copyright (C) 2008 Markus Franz Xaver Johannes Oberhumer
   Copyright (C) 2007 Markus Franz Xaver Johannes Oberhumer
   Copyright (C) 2006 Markus Franz Xaver Johannes Oberhumer
   Copyright (C) 2005 Markus Franz Xaver Johannes Oberhumer
   Copyright (C) 2004 Markus Franz Xaver Johannes Oberhumer
   Copyright (C) 2003 Markus Franz Xaver Johannes Oberhumer
   Copyright (C) 2002 Markus Franz Xaver Johannes Oberhumer
   Copyright (C) 2001 Markus Franz Xaver Johannes Oberhumer
   Copyright (C) 2000 Markus Franz Xaver Johannes Oberhumer
   Copyright (C) 1999 Markus Franz Xaver Johannes Oberhumer
   Copyright (C) 1998 Markus Franz Xaver Johannes Oberhumer
   Copyright (C) 1997 Markus Franz Xaver Johannes Oberhumer
   Copyright (C) 1996 Markus Franz Xaver Johannes Oberhumer
   All Rights Reserved.

   The LZO library is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License as
   published by the Free Software Foundation; either version 2 of
   the License, or (at your option) any later version.

   The LZO library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with the LZO library; see the file COPYING.
   If not, write to the Free Software Foundation, Inc.,
   51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.

   Markus F.X.J. Oberhumer
   <markus@oberhumer.com>
   http://www.oberhumer.com/opensource/lzo/
 */

namespace forgelib.Utils
{
    /// <summary>
    /// LZO 1x & 2a decompression
    /// - managed but unsafe (works with 32 & 64 bit)
    /// - still fast enough... but no error checking. Be sure too use on valid input data....
    /// </summary>
    static class LZODecompressor
    {
        public unsafe static int lzo1x_decompress(byte[] src, byte[] dst)
        {
            uint t = 0;
            fixed (byte* input = src, output = dst)
            {
                int in_len = src.Length;
                int out_len = dst.Length;
                byte* op;
                byte* ip;

                byte* m_pos;
                byte* ip_end = input + in_len;

                op = output;
                ip = input;

                if (*ip > 17)
                {
                    t = (uint)(*ip++ - 17);
                    if (t < 4)
                        goto match_next;
                    do *op++ = *ip++; while (--t > 0);
                    goto first_literal_run;
                }

            loop1:
                t = *ip++;
                if (t >= 16)
                    goto match;
                if (t == 0)
                {
                    while (*ip == 0)
                    {
                        t += 255;
                        ip++;
                    }
                    t += (uint)(15 + *ip++);
                }

                *(uint*)(op) = *(uint*)(ip);
                op += 4; ip += 4;
                if (--t > 0)
                {
                    if (t >= 4)
                    {
                        do
                        {
                            *(uint*)(op) = *(uint*)(ip);
                            op += 4; ip += 4; t -= 4;
                        } while (t >= 4);
                        if (t > 0) do *op++ = *ip++; while (--t > 0);
                    }
                    else
                        do *op++ = *ip++; while (--t > 0);
                }

            first_literal_run:

                t = *ip++;
                if (t >= 16)
                    goto match;

                m_pos = op - (1 + 0x0800);
                m_pos -= t >> 2;
                m_pos -= *ip++ << 2;

                *op++ = *m_pos++; *op++ = *m_pos++; *op++ = *m_pos;

                goto match_done;

            loop2:
            match:
                if (t >= 64)
                {
                    m_pos = op - 1;
                    m_pos -= (t >> 2) & 7;
                    m_pos -= *ip++ << 3;
                    t = (t >> 5) - 1;

                    //goto copy_match;
                    *op++ = *m_pos++; *op++ = *m_pos++;
                    do *op++ = *m_pos++; while (--t > 0);
                    goto match_done;

                }
                else if (t >= 32)
                {
                    t &= 31;
                    if (t == 0)
                    {
                        while (*ip == 0)
                        {
                            t += 255;
                            ip++;
                        }
                        t += (uint)(31 + *ip++);
                    }

                    m_pos = op - 1;
                    m_pos -= (*(ushort*)ip) >> 2;

                    ip += 2;
                }
                else if (t >= 16)
                {

                    m_pos = op;
                    m_pos -= (t & 8) << 11;

                    t &= 7;
                    if (t == 0)
                    {
                        while (*ip == 0)
                        {
                            t += 255;
                            ip++;
                        }
                        t += (uint)(7 + *ip++);
                    }

                    m_pos -= (*(ushort*)ip) >> 2;

                    ip += 2;
                    if (m_pos == op)
                        goto eof_found;
                    m_pos -= 0x4000;

                }
                else
                {
                    m_pos = op - 1;
                    m_pos -= t >> 2;
                    m_pos -= *ip++ << 2;

                    *op++ = *m_pos++; *op++ = *m_pos;

                    goto match_done;
                }

                if (t >= 2 * 4 - (3 - 1) && (op - m_pos) >= 4)
                {

                    *(uint*)(op) = *(uint*)(m_pos);
                    op += 4; m_pos += 4; t -= 4 - (3 - 1);
                    do
                    {
                        *(uint*)(op) = *(uint*)(m_pos);
                        op += 4; m_pos += 4; t -= 4;
                    } while (t >= 4);
                    if (t > 0) do *op++ = *m_pos++; while (--t > 0);
                }
                else
                {
                    *op++ = *m_pos++; *op++ = *m_pos++;
                    do *op++ = *m_pos++; while (--t > 0);
                }

            match_done:

                t = (uint)(ip[-2] & 3);

                if (t == 0)
                    goto loop1;

            match_next:

                *op++ = *ip++;
                if (t > 1) { *op++ = *ip++; if (t > 2) { *op++ = *ip++; } }

                t = *ip++;
                goto loop2;

            eof_found:
                return (ip == ip_end ? 0 : (ip < ip_end ? (-8) : (-4)));
            }
        }

        public static unsafe int lzo2a_decompress(byte[] src, byte[] dst)
        {
            fixed (byte* input = src, output = dst)
            {
                int in_len = src.Length;
                int out_len = dst.Length;

                byte* op;
                byte* ip;
                byte* m_pos;

                ulong t;
                byte* ip_end = input + in_len;

                uint b = 0;
                int k = 0;

                op = output;
                ip = input;

                while (true)
                {
                    { if (k < (1)) { b |= ((uint)(*ip++)) << k; k += 8; } };
                    if ((b & ((((uint)1 << (1)) - 1))) == 0)
                    {
                        { b >>= (1); k -= (1); };

                        *op++ = *ip++;
                        continue;
                    }
                    { b >>= (1); k -= (1); };

                    { if (k < (1)) { b |= ((uint)(*ip++)) << k; k += 8; } };
                    if ((b & ((((uint)1 << (1)) - 1))) == 0)
                    {
                        { b >>= (1); k -= (1); };

                        { if (k < (2)) { b |= ((uint)(*ip++)) << k; k += 8; } };
                        t = 2 + (ulong)(b & ((((uint)1 << (2)) - 1)));
                        { b >>= (2); k -= (2); };

                        m_pos = op - 1 - *ip++;

                        do *op++ = *m_pos++; while (--t > 0);
                        continue;
                    }
                    { b >>= (1); k -= (1); };

                    t = *ip++;
                    m_pos = op;
                    m_pos -= (t & 31) | (((ulong)*ip++) << 5);
                    t >>= 5;
                    if (t == 0)
                    {

                        t = 10 - 1;

                        while (*ip == 0)
                        {
                            t += 255;
                            ip++;

                        }
                        t += *ip++;
                    }
                    else
                    {

                        if (m_pos == op)
                            goto eof_found;

                        t += 2;
                    }

                    do *op++ = *m_pos++; while (--t > 0);
                }

            eof_found:

                return (ip == ip_end ? 0 :
                       (ip < ip_end ? (-8) : (-4)));

            }
        }
    }
}