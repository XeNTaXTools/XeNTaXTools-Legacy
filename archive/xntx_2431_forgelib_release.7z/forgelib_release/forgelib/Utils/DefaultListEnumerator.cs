﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace forgelib.Utils
{
    public class DefaultListEnumerator<T> : IEnumerator<T> where T : class
    {
        int index = -1;
        T current = null;
        IList<T> _list;

        public DefaultListEnumerator(IList<T> list)
        {
            this._list = list;
        }

        public T Current
        {
            get { return current; }
        }

        public void Dispose()
        {
            current = null;
            index = -1;
        }

        object System.Collections.IEnumerator.Current
        {
            get { return current; }
        }

        public bool MoveNext()
        {
            index++;
            if (index >= 0 && index < _list.Count)
            {
                current = _list[index];
                return true;
            }
            current = null;
            return false;
        }

        public void Reset()
        {
            index = -1;
        }
    }
}
