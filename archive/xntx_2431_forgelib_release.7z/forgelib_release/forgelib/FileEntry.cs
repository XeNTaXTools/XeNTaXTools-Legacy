﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using forgelib.Nodes;
using forgelib.Resources;
using forgelib.Hash;

namespace forgelib
{
    public class FileEntry : IFileSystemInfo
    {
        private EntryTable _container;

        private int _index;
        public int Index 
        {
            get { return _index; }
            set { throw new NotSupportedException(); }
        }

        public int NumReadFiles
        {
            get
            {
                if (ResourceData != null && ResourceData.Resource != null) return ResourceData.Resource.NumReadFiles;
                return 0;
            }
        }

        public bool MultiPlayer { get { return _container.ForgeFile.MultiPlayer; } }

        private Stream _baseStream;
        
        public long DataPtr { get; private set; }
        public uint EntryId { get; private set; }
        public int SizeOnDisk { get; private set; }

        public EntryMetadata Metadata { get; private set; }
        public EntryResourceData ResourceData { get; private set; }

        private string getName()
        {
            string n = Metadata.Name;
            if (string.IsNullOrEmpty(n))
            {
                if (ResourceData == null) ReadResourceData();
                
                if (ResourceData != null)
                {
                    n = ResourceData.Name;
                    if (string.IsNullOrEmpty(n))
                    {
                        if (ResourceData.Resource != null)
                        {
                            n = ResourceData.Resource.Name;
                        }
                    }
                }
            }

            if (string.IsNullOrEmpty(n))
            {
                n = string.Format("0x{0:x8}", EntryId);
            }
            return n;
        }

        private string getTypeName()
        {
            if (Metadata.IsGlobalMetadata) return "GlobalMetaFile";

            //if (Metadata.TypeId == 0)
            {

                if (ResourceData == null) ReadResourceData();

                if (ResourceData != null)
                {
                    if (ResourceData.Resource != null) return ResourceData.Resource.Type;
                    return HashLookup.GetHashedString(ResourceData.TypeId);
                }
            }
            return HashLookup.GetHashedString(Metadata.TypeId);
        }

        public string Name
        { 
            get
            {
                return getName();
            }
        }
        
        public long Length 
        {
            get
            {
                if(ResourceData != null && ResourceData.Resource != null)
                {
                    return ResourceData.Resource.Length;
                }
                return SizeOnDisk;
            }
        }
        
        public string Type
        {
            get { return getTypeName(); }
        }

        public bool IsDirectory 
        {
            get 
            {
                if (ResourceData == null) ReadResourceData();
                if (ResourceData != null) return ResourceData.IsCollection;
                return false;
            }
        }

        public bool IsKnownResource
        {
            get
            {
                if (ResourceData == null) ReadResourceData();
                if (ResourceData != null && ResourceData.Resource != null) return KnownTypeRegistry.IsKnownType(ResourceData.Resource.TypeId);
                return false;
            }
        }

        public bool? Compressed 
        {
            get {
                if (ResourceData == null) return null;
                return ResourceData.Compressed;
            }
        }

        public FileEntry(BinaryReader r, int index, EntryTable container)
        {
            _container = container;
            _index = index;
            read(r);
        }

        private void read(BinaryReader r)
        {
            _baseStream = r.BaseStream;
            
            DataPtr = r.ReadInt64();
            EntryId = r.ReadUInt32();
            SizeOnDisk = r.ReadInt32();
        }

        public void ReadMetadata()
        {
            Metadata = new EntryMetadata(new BinaryReader(_baseStream));
        }

        public void ReadResourceData()
        {
            if (ResourceData != null) return;

            _baseStream.Position = DataPtr;
            ResourceData = new EntryResourceData(this);
            ResourceData.ReadHeader(_baseStream);
            ResourceData.ReadData(_baseStream);
        }

        public object GetData()
        {
            if (ResourceData == null) return null;
            return ResourceData.GetData();
        }

        public List<IFileSystemInfo> GetFiles()
        {
            throw new NotImplementedException();
        }

        public List<IFileSystemInfo> GetFilesystemInfos()
        {
            if (ResourceData == null) ReadResourceData();
            if (ResourceData != null && ResourceData.Resource != null) return ResourceData.Resource.GetFilesystemInfos();
            return null;
        }

        public List<IFileSystemInfo> GetDirectories()
        {
            return new List<IFileSystemInfo>(0);
        }

        public IFileSystemInfo FindDependencyById(uint id)
        {
            var child = _container.ForgeFile.FindDependencyById(id);
            if (child == null)
            {
                child = _container.ForgeFile.FindChildById(this, id);
            }
            else
            {
                if (child is FileEntry)
                {
                    var fe = ((FileEntry)child);
                    if (fe.ResourceData == null || fe.ResourceData.Resource == null) fe.ReadResourceData();
                    return fe.ResourceData.Resource;
                }
            }
            return child;
        }
    }
}
