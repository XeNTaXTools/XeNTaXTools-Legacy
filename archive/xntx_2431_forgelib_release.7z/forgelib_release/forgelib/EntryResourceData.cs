﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using forgelib.Utils;
using forgelib.Resources;

namespace forgelib
{
    public class EntryResourceData
    {
        private class UnknownStruct1
        {
            public uint Unknown1;
            public int Unknown2;

            public UnknownStruct1(BinaryReader r)
            {
                Read(r);
            }

            public void Read(BinaryReader r)
            {
                Unknown1 = r.ReadUInt32();
                Unknown2 = r.ReadInt32();
            }

            public override string ToString()
            {
                return string.Format("0x{0:x8} {1}", Unknown1, Unknown2);
            }
        }

        private FileEntry _container;

        public string Name { get; private set; } // 128 bytes, '\0' padded
        
        private int _filedata_id;

        public int SizeOnDisk { get; private set; } // == Entry.SizeOnDisk
        public ulong EntryId { get; private set; }// == EntryMetadata.EntryId, not used...
        
        private long _filedata_unklong1; // 0
        private int _filedata_unkint1; // 0 | 1
        private int _filedata_unkint2; // 2 | 4
        private int _filedata_unkint3; // 2 | 4
        private int _filedata_unkint4; // 0

        public DateTime Timestamp { get; private set; }

        public uint TypeId { get; private set; }

        public bool Compressed { get; private set; }

        public bool IsCollection { get; private set; }

        private List<UnknownStruct1> unknownStructArray1;
        private long _dataOffset;

        private Stream resourceDataStream;

        private long _dataOffsetIfNotCompressed;
        private int _dataLengthIfNotCompressed;

        public ResourceBase Resource { get; private set; }

        public EntryResourceData(FileEntry container)
        {
            _container = container;
        }

        public void ReadHeader(Stream input)
        {
            BinaryReader r = new BinaryReader(input);
            string _filedata_magic = Encoding.ASCII.GetString(r.ReadBytes(8));
            if (_filedata_magic != "FILEDATA")
            {
                throw new NotSupportedException("expected 'FILEDATA' idenfifier.");
            }

            Name = Encoding.ASCII.GetString(r.ReadBytes(128)).TrimEnd('\0');
            r.ReadBytes(255);
            
            _filedata_id = r.ReadInt32();
            SizeOnDisk = r.ReadInt32();
            EntryId = r.ReadUInt64();
            _filedata_unklong1 = r.ReadInt64();
            _filedata_unkint1 = r.ReadInt32();
            _filedata_unkint2 = r.ReadInt32();
            _filedata_unkint3 = r.ReadInt32();
            _filedata_unkint4 = r.ReadInt32();
            Timestamp = new DateTime(1970, 1, 1).AddSeconds(r.ReadInt32());
            r.ReadByte();
            TypeId = r.ReadUInt32();
            _dataOffset = r.BaseStream.Position;
        }

        public void ReadData(Stream input)
        {
            BinaryReader r = new BinaryReader(input);
            r.BaseStream.Position = _dataOffset;
            long endpos = r.BaseStream.Position + SizeOnDisk;
            
            int unkstructCount = r.ReadInt32();
            if (unkstructCount != 0)
            {
                unknownStructArray1 = new List<UnknownStruct1>();
                for (int i = 0; i < unkstructCount; i++)
                {
                    unknownStructArray1.Add(new UnknownStruct1(r));
                }
            }
            _dataOffsetIfNotCompressed = r.BaseStream.Position;
            _dataLengthIfNotCompressed = (int)(endpos - _dataOffsetIfNotCompressed);

            Stream cs = CompressedStream.GetStream(r.BaseStream);
            Stream resourceDictionaryStream = null;
            
            if (cs is CompressedStream)
            {
                Compressed = true;
                resourceDictionaryStream = cs;

                r.BaseStream.Position = ((CompressedStream)resourceDictionaryStream).OffsetAfterConsume;
                resourceDataStream = CompressedStream.GetStream(r.BaseStream);
                
                /*
                if(endpos > ((CompressedStream)resourceDataStream).OffsetAfterConsume)
                {
                    System.Diagnostics.Debugger.Break();
                }*/
            }

            if (Compressed)
            {
                resourceDictionaryStream.Position = 0;
                ResourceDirectoryTable directory = new ResourceDirectoryTable();
                directory.Read(resourceDictionaryStream);
                resourceDictionaryStream = null;

                /*
                if (directory.Entries[0].EntryId != _container.EntryId)
                {
                    System.Diagnostics.Debugger.Break();
                }
                */

                if (directory.Entries.Length > 1)
                {
                    IsCollection = true;
                    Resource = ResourceReader.ReadResourceCollection(resourceDataStream, directory, _container, _container.MultiPlayer);
                }
                else
                {
                    Resource = new ResourceBase(_container);
                    Resource.Read(resourceDataStream);
                    resourceDataStream.Position = 0;
                    Resource = ResourceReader.ReadResource(Resource, _container.MultiPlayer);
                }
            }
        }

        public object GetData()
        {
            return Resource.GetData();
        }
    }
}
