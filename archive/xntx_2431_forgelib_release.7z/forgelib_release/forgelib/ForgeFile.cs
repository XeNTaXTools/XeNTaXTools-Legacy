﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Diagnostics;
using forgelib.Nodes;
using forgelib.Resources;

namespace forgelib
{
    public class ForgeFile : IFileSystemInfo
    {
        private string _filename;
        private long _length;

        private int version;
        private int indexTablePtr;
        public int NumFileEntries;

        private int _unkint1;
        private int _unkint2;
        private int _unkint3;
        private int _unkint4;
        private int _unkint5;

        private int maxEntriesPerTable;

        private int numEntryTables;
        private long firstEntryTablePtr;

        private EntryTable[] entryTables;

        public FileEntryCollection FileEntries { get; private set; }

        public bool MultiPlayer { get; set; }

        public ForgeFile(string filename)
        {
            read(filename);
            FileEntries = new FileEntryCollection(this);
            MultiPlayer = Path.GetDirectoryName(filename).IndexOf("multi") >= 0;
        }

        private void read(string filename)
        {
            _filename = filename;
            BinaryReader r = new BinaryReader(File.OpenRead(_filename));
            _length = r.BaseStream.Length;
            string magic = Encoding.ASCII.GetString(r.ReadBytes(9)).TrimEnd('\0');
            if (magic != "scimitar")
            {
                throw new NotSupportedException("not a forge file");
            }
            
            version = r.ReadInt32();
            if (version != 25)
            {
                throw new NotSupportedException("unsupported version");
            }
            
            indexTablePtr = r.ReadInt32();

            r.BaseStream.Position = indexTablePtr;
            NumFileEntries = r.ReadInt32();

            _unkint1 = r.ReadInt32();               // always 2
            _unkint2 = r.ReadInt32();               // always 0
            _unkint3 = r.ReadInt32();               // always 0
            _unkint4 = r.ReadInt32();               // always -1
            _unkint5 = r.ReadInt32();               // always -1
            maxEntriesPerTable = r.ReadInt32();     // always 5000
            numEntryTables = r.ReadInt32();         // entryCount / maxFileCount
            firstEntryTablePtr = r.ReadInt64();     // == r.BaseStream.Position

            entryTables = new EntryTable[numEntryTables];
            for (int i = 0; i < numEntryTables; i++)
            {
                if (i == 0) r.BaseStream.Position = firstEntryTablePtr;
                else
                {
                    r.BaseStream.Position = entryTables[i - 1].NextEntryTablePtr;
                }
                entryTables[i] = new EntryTable(r, this);

            }
        }

        public FileEntry GetEntry(int index)
        {
            if (index < 0 || index > NumFileEntries) return null;
            int tableIndex = index / maxEntriesPerTable;
            index = index % maxEntriesPerTable;
            return entryTables[tableIndex].FileEntries[index];
        }

        public int Index { get; set; }

        public int NumReadFiles
        {
            get
            {
                int numReads = 0;
                for (int i = 0; i < entryTables.Length; i++)
                {
                    for (int j = 0; j < entryTables[i].FileEntries.Length; j++)
                    {
                        if (entryTables[i].FileEntries[j].ResourceData != null &&
                            entryTables[i].FileEntries[j].ResourceData.Resource != null)
                        {
                            numReads += entryTables[i].FileEntries[j].ResourceData.Resource.NumReadFiles;
                        }
                    }
                }
                return numReads;
            }
        }

        public bool IsKnownResource { get { return false; } }

        public bool IsDirectory { get { return true; } }

        public string Name
        {
            get
            {
                return Path.GetFileNameWithoutExtension(_filename);
            }
        }

        public long Length
        {
            get { return _length; }
        }

        public string Type
        {
            get
            {
                return string.Format("Forge file (V{0})", version);
            }
        }

        public List<IFileSystemInfo> GetFiles()
        {
            return new List<IFileSystemInfo>(FileEntries);
        }

        public List<IFileSystemInfo> GetFilesystemInfos()
        {
            return new List<IFileSystemInfo>(FileEntries);
        }

        public List<IFileSystemInfo> GetDirectories()
        {
            return new List<IFileSystemInfo>(FileEntries.Where(c => c.IsDirectory));
        }


        public IFileSystemInfo FindDependencyById(uint id)
        {
            for (int i = 0; i < entryTables.Length; i++)
            {
                for (int j = 0; j < entryTables[i].FileEntries.Length; j++)
                {
                    if (entryTables[i].FileEntries[j].EntryId == id) return entryTables[i].FileEntries[j];
                }
            }
            return null;
        }

        internal IFileSystemInfo FindChildById(FileEntry excludeFromSearch, uint id)
        {
            for (int i = 0; i < entryTables.Length; i++)
            {
                for (int j = 0; j < entryTables[i].FileEntries.Length; j++)
                {
                    if (entryTables[i].FileEntries[j].EntryId != excludeFromSearch.EntryId)
                    {
                        if (entryTables[i].FileEntries[j].ResourceData == null ||
                            entryTables[i].FileEntries[j].ResourceData.Resource == null)
                        {
                            entryTables[i].FileEntries[j].ReadResourceData();
                        }
                        if (entryTables[i].FileEntries[j].ResourceData != null &&
                            entryTables[i].FileEntries[j].ResourceData.Resource != null)
                        {
                            if(entryTables[i].FileEntries[j].ResourceData.IsCollection)
                            {
                                foreach (var item in ((ResourceCollection)entryTables[i].FileEntries[j].ResourceData.Resource))
                                {
                                    if (item.EntryId == id) return item;
                                }
                            }
                        }
                    }
                }
            }
            return null;
        }
    }
}
