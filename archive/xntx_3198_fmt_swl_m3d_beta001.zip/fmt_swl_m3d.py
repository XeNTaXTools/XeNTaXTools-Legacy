#Noesis Python model import+export test module, imports/exports some data from/to a made-up format

from inc_noesis import *

import noesis

#rapi methods should only be used during handler callbacks
import rapi

#registerNoesisTypes is called by Noesis to allow the script to register formats.
#Do not implement this function in script files unless you want them to be dedicated format modules!
def registerNoesisTypes():
	handle = noesis.register("Star Trek Legacy", ".m3d")
	noesis.setHandlerTypeCheck(handle, m3dCheckType)
	noesis.setHandlerLoadModel(handle, m3dLoadModel) #see also noepyLoadModelRPG
	#noesis.setHandlerWriteModel(handle, m3dWriteModel)
	#noesis.setHandlerWriteAnim(handle, m3dWriteAnim)
	#noesis.logPopup()
	return 1

#check if it's this type based on the data

def m3dCheckType(data):
	bs = NoeBitStream(data)
	idMagic = bs.readBytes(8).decode("ASCII")
	if idMagic != "Mad3D_SW":
		return 0
	return 1       

#load the model
def m3dLoadModel(data, mdlList):
	ctx = rapi.rpgCreateContext()
	bs = NoeBitStream(data)
	rapi.rpgSetOption(noesis.RPGOPT_TRIWINDBACKWARD, 1)
	idMagic = bs.readBytes(8).decode("ASCII")
	version = bs.readBytes(6)
	meshCount = bs.readUShort()
	for i in range(0, meshCount):
		meshNameSize = bs.readUShort()
		meshName = bs.readBytes(meshNameSize).decode("ASCII")
		bs.seek(0x30, NOESEEK_REL)#mesh position?
		#print(meshName)
	nodeCount = bs.readUShort()
	for i in range(0, nodeCount):
		nodeNameSize = bs.readUShort()
		nodeName = bs.readBytes(nodeNameSize).decode("ASCII")
		count01 = bs.readUInt()
		nodeType = bs.readUShort()
		count02 = bs.readUInt()
		nodeMatrix = bs.readBytes(0x30)
		#print(nodeName)
		if nodeType == 1:
			nodeInfo = bs.read("H" * 7)
			#print(nodeInfo)
			vertBuff = bs.readBytes(12 * nodeInfo[3])
			normalBuff = bs.readBytes(12 * nodeInfo[4])
			uvBuff = bs.readBytes(8 * nodeInfo[5])
			faceCount = bs.readUShort()
			matNameSize = bs.readUShort()
			matName = bs.readBytes(matNameSize).decode("ASCII")
			texNameSize = bs.readUShort()
			texName = bs.readBytes(texNameSize).decode("ASCII")
			if nodeInfo[0] == 16:
				bs.seek(0x1C, NOESEEK_REL)#null?
			elif nodeInfo[0] == 18:
				bs.seek(0x4, NOESEEK_REL)#null?
				matNameSize1 = bs.readUShort()
				matName1 = bs.readBytes(matNameSize1).decode("ASCII")
				bs.seek(0x4, NOESEEK_REL)#null?
				texNameSize1 = bs.readUShort()
				texName1 = bs.readBytes(texNameSize1).decode("ASCII")
				bs.seek(0x10, NOESEEK_REL)#null?
			matNameSize2 = bs.readUShort()
			matName2 = bs.readBytes(matNameSize2).decode("ASCII")
			bs.seek(2, NOESEEK_REL)#null?
			faceBuff = bs.readBytes(6 * faceCount)
			faceCount2 = bs.readUInt()
			faceBuff2 = bs.readBytes(6 * faceCount2)
			if nodeInfo[0] == 18:
				bs.seek(0x18 * nodeInfo[3], NOESEEK_REL)#weights?
			bs.seek(0x18, NOESEEK_REL)#?
			nodeInfo2 = bs.read("I" * 4)
			faceBuff3 = bs.readBytes(2 * nodeInfo2[3])
			rapi.rpgSetName(str(i))
			rapi.rpgBindPositionBuffer(vertBuff, noesis.RPGEODATA_FLOAT, 12)
			rapi.rpgBindNormalBuffer(normalBuff, noesis.RPGEODATA_FLOAT, 12)
			rapi.rpgBindUV1Buffer(uvBuff, noesis.RPGEODATA_FLOAT, 8)
			rapi.rpgCommitTriangles(faceBuff, noesis.RPGEODATA_USHORT, faceCount * 3, noesis.RPGEO_TRIANGLE, 1)
			bs.seek(3, NOESEEK_REL)#null?
			#break
	mdl = rapi.rpgConstructModel()
	mdlList.append(mdl)
	#print(bs.tell())
	rapi.rpgClearBufferBinds()	
	return 1