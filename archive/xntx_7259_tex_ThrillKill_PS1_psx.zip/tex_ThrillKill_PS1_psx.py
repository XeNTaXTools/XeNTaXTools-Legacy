from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Thrill Kill [PS1]", ".psx")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
	#noesis.logPopup()
	return 1

def noepyCheckType(data):
    return 1
	
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    if bs.getSize() == 0x14000:
        imgWidth = 320            
        imgHeight = 128           
    elif bs.getSize() == 0x80000:
        imgWidth = 512            
        imgHeight = 512           
    data = bs.readBytes(bs.getSize())      
    data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "r5 g5 b5 p1")
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, noesis.NOESISTEX_RGBA32))
    return 1