import newGameLib
reload(newGameLib)
from newGameLib import *
import Blender



def pakParser(filename,g):
	g.word(4)
	a,b=g.i(2)
	sys=Sys(filename)
	sys.addDir(sys.base+'_files')
	for m in range(b):
		t=g.tell()
		name=g.find('\x00')
		print name
		g.seek(t+128)
		offset,size=g.i(2)
		back=g.tell()
		g.seek(offset)
		new=open(sys.dir+os.sep+sys.base+'_files'+os.sep+name,'wb')
		new.write(g.read(size))
		new.close()
		g.seek(back)
	
	
	
def skmParser(filename,g):
	skinMeshCount=g.i(1)[0]
	for k in range(skinMeshCount):
		mesh=Mesh()
		vertPosList=[]
		g.word(g.i(1)[0])	
		indiceCount=g.i(1)[0]
		mesh.indiceList=g.H(indiceCount)
		vertCount=g.i(1)[0]
		for m in range(vertCount):
			vertPosList.append(g.f(3))
		mesh.TRIANGLE=True	
		count=g.i(1)[0]
		g.seek(count*12,1)
		count=g.i(1)[0]
		for m in range(count):
			mesh.vertUVList.append(g.f(2))
		count=g.i(1)[0]
		skin={}
		for m in range(count):
			a,b=g.i(2)
			for n in range(a,b):
				skin[n]=m
		count=g.i(1)[0]
		for m in range(count):
			a=g.H(1)[0]
			mesh.vertPosList.append(vertPosList[a])
			mesh.skinIndiceList.append([skin[a]])
			mesh.skinWeightList.append([1.0])
		count=g.i(1)[0]
		for m in range(count):
			a,b=g.H(2)
			mesh.vertPosList.append(vertPosList[a])
			mesh.skinIndiceList.append([skin[a],skin[b]])
			mesh.skinWeightList.append(g.f(2))
		count=g.i(1)[0]
		for m in range(count):
			a,b,c,d=g.H(4)
			mesh.vertPosList.append(vertPosList[a])
			mesh.skinIndiceList.append([skin[a],skin[b],skin[c]])
			mesh.skinWeightList.append(g.f(3))
		count=g.i(1)[0]
		for m in range(count):
			a,b,c,d=g.H(4)
			mesh.vertPosList.append(vertPosList[a])
			mesh.skinIndiceList.append([skin[a],skin[b],skin[c],skin[d]])
			mesh.skinWeightList.append(g.f(4))
		count=g.i(1)[0]
		for m in range(count):
			mat=Mat()
			g.f(17)
			mat.diffuse=g.dirname+os.sep+g.word(g.i(1)[0])
			mat.TRIANGLE=True	
			mat.IDStart=g.H(1)[0]
			mesh.matList.append(mat)
		for m in range(count-1):
			mesh.matList[m].IDCount=mesh.matList[m+1].IDStart-mesh.matList[m].IDStart
		mesh.matList[-1].IDCount=len(mesh.indiceList)-mesh.matList[-1].IDStart
		skin=Skin()
		mesh.skinList.append(skin)	
		mesh.draw()	
		g.i(1)	
	count=g.i(1)[0]
	for n in range(count):
		mesh=Mesh()
		mesh.TRIANGLE=True
		g.word(g.i(1)[0]),g.tell()
		vertCount=g.i(1)[0]
		for m in range(vertCount):
			mesh.vertPosList.append(g.f(3))
			g.seek(12,1)	
			mesh.vertUVList.append(g.f(2))
		indiceCount=g.i(1)[0]
		mesh.indiceList=g.H(indiceCount)
		count=g.i(1)[0]
		for m in range(count):
			mat=Mat()
			g.f(17)
			mat.diffuse=g.dirname+os.sep+g.word(g.i(1)[0])
			mat.TRIANGLE=True	
			mat.IDStart=g.H(1)[0]
			mesh.matList.append(mat)
		for m in range(count-1):
			mesh.matList[m].IDCount=mesh.matList[m+1].IDStart-mesh.matList[m].IDStart
		mesh.matList[-1].IDCount=len(mesh.indiceList)-mesh.matList[-1].IDStart
		g.i(1)
		mesh.draw()
		
	#count=g.i(1)[0]
	#for m in range(count):
	#	print g.f(12)
		
	g.tell()
	
	
def trkParser(file):
	lines=file.readlines()
	for line in lines:
		print line
			
			
def skaParser(filename,g):
	#g.debug=True
	count=g.i(1)[0]
	print g.B(1)
	
	skeleton=Skeleton()
	skeleton.ARMATURESPACE=True
	skeleton.NICE=True
	for k in range(count):
		boneCount,frameCount=g.i(2)
		for m in range(frameCount):
			g.logWrite('frame'+str(m))
			for n in range(boneCount):
				#g.logWrite('bone'+str(n))
				rot=g.f(3)
				pos=g.f(3)
				if m==0:
					print pos
					bone=Bone()
					bone.rotMatrix=Euler(rot).toMatrix().resize4x4()
					bone.posMatrix=VectorMatrix(pos)
					skeleton.boneList.append(bone)		
				
		#break		
	#skeleton.draw()	
	g.tell()	
			
def Parser():	
	filename=input.filename
	print
	print filename
	print
	ext=filename.split('.')[-1].lower()
	
		
	if ext=='pak':
		file=open(filename,'rb')
		g=BinaryReader(file)
		pakParser(filename,g)
		file.close()	
		
	if ext=='skm':
		file=open(filename,'rb')
		g=BinaryReader(file)
		skmParser(filename,g)
		file.close()
		
	if ext=='trk':
		file=open(filename,'r')
		trkParser(file)
		file.close()		
		
	if ext=='ska':
		file=open(filename,'rb')
		g=BinaryReader(file)
		skaParser(filename,g)
		file.close()	
	
		
	
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
	
Blender.Window.FileSelector(openFile,'import','Valkyrie files *.pak, *.skm') 
	