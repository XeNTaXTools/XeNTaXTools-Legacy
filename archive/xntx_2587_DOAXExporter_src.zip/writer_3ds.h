
#ifndef __WRITER_3DS__
#define __WRITER_3DS__


typedef struct {
	FLOAT	r;
	FLOAT	g;
	FLOAT	b;
	FLOAT	a;
} ST_WRITER_3DS_RGBA_COLOR;

typedef struct {
	ST_WRITER_3DS_RGBA_COLOR	stDiffuse;	// Diffuse color
	ST_WRITER_3DS_RGBA_COLOR	stAmbient;	// Ambient color
	ST_WRITER_3DS_RGBA_COLOR	stSpecular;	// Specular color
	ST_WRITER_3DS_RGBA_COLOR	stEmissive;	// Emissive color
	FLOAT	fSpecularPower;					// Specular glow power
} ST_WRITER_3DS_MATCOLOR;

typedef struct {
	FLOAT x, y, z;
} ST_WRITER_3DS_VERTEX;

typedef struct {
	FLOAT u, v;
} ST_WRITER_3DS_TXTCOORD;

typedef struct {
	WORD wIndex1;
	WORD wIndex2;
	WORD wIndex3;
} ST_WRITER_3DS_FACE;


BOOL WRITER_3DS_Open( CHAR * szObjName, DWORD dwNumMesh, DWORD dwNumMat );
BOOL WRITER_3DS_Close();
BOOL WRITER_3DS_SetMaterial( CHAR * szMatName, CHAR * szTxtName, ST_WRITER_3DS_MATCOLOR * pMatColor );
BOOL WRITER_3DS_SetMesh( CHAR * szMeshName, DWORD dwNumVertices, DWORD dwNumFaces, DWORD dwNumMat );
BOOL WRITER_3DS_SetVerCoord( DWORD dwNumVerCoord, ST_WRITER_3DS_VERTEX * pVerCoordList );
BOOL WRITER_3DS_SetTxtCoord( DWORD dwNumTxtCoord, ST_WRITER_3DS_TXTCOORD * pTxtCoordList );
BOOL WRITER_3DS_SetFaces( DWORD dwNumFaces, ST_WRITER_3DS_FACE * pFaceList );
BOOL WRITER_3DS_SetMatFaces( CHAR * szMatName, DWORD dwNumMatFace, WORD * pMatFaceList );


#endif  // __WRITER_3DS__
