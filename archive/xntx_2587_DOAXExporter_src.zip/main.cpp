
#include <windows.h>
#include "resource.h"

#include <stdio.h>

#include "xpr.h"
#include "writer_3ds.h"



// GLOBAL VARIABLES
ST_MY_MDL		*g_pModel;

BOOL			g_bObjLoaded = FALSE;

DWORD			g_dwObjNo;

CHAR			g_szAppName[MAX_PATH];


// FUNCTIONS
INT CALLBACK	MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );
BOOL	OpenFileDialog( HWND hWnd, CHAR *szFileName, CHAR *szFileTitle );
VOID	WriteTextures( CHAR * szBaseName );
VOID	WriteObjects( CHAR * szBaseName );
DWORD	CreateVerCoordListFromVBuf( ST_MY_MDL * pModel, ST_MY_SUBOBJ * pObject, ST_WRITER_3DS_VERTEX ** pVertexList );
DWORD	CreateTxtCoordListFromVBuf( ST_MY_MDL * pModel, ST_MY_SUBOBJ * pObject, ST_WRITER_3DS_TXTCOORD ** pTxtCoordList );
DWORD	CreateFaceListFromIBuf( ST_MY_MDL * pModel, ST_MY_SUBOBJ * pObject, DWORD * pdwNumFace, DWORD ** pdwNumMatFace, ST_WRITER_3DS_FACE ** pFaceList, WORD *** ppMatFaceList );



//-----------------------------------------------------------------------------
// Name: WinMain()
// Desc: The application's entry point
//-----------------------------------------------------------------------------
INT WINAPI WinMain( HINSTANCE hInstance, HINSTANCE, LPSTR, INT )
{
	LoadString( hInstance, IDS_STRING1, g_szAppName, MAX_PATH );

    // Create the application's dialog
	DialogBox( hInstance, MAKEINTRESOURCE(IDD_DIALOG1), NULL, MsgProc );
		
	
    return 0;
}



//-----------------------------------------------------------------------------
// Name: MsgProc()
// Desc: The window's message handler
//-----------------------------------------------------------------------------
INT CALLBACK MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
    switch( uMsg )
    {
	case WM_INITDIALOG:
		SetWindowText( hWnd, g_szAppName );

		HICON hIcon;
		hIcon = LoadIcon( (HINSTANCE)GetWindowLong(hWnd, GWL_HINSTANCE), MAKEINTRESOURCE(IDI_ICON1) );
		PostMessage( hWnd, WM_SETICON, ICON_BIG,   (LPARAM)hIcon );  // Set big icon
		PostMessage( hWnd, WM_SETICON, ICON_SMALL, (LPARAM)hIcon );  // Set small icon
		break;

	case WM_CLOSE:
		if( g_bObjLoaded )
			XPR_Close( g_pModel );
		EndDialog( hWnd, 0 );
		return 0;
		
	case WM_COMMAND:
		switch( LOWORD(wParam) )
		{
		case IDC_EXPORT:
			char szFileName[MAX_PATH];
			char szFileTitle[MAX_PATH];
			if( OpenFileDialog( hWnd, szFileName, szFileTitle ) )
			{
				if( g_bObjLoaded )
					XPR_Close( g_pModel );
				g_pModel = XPR_Open( szFileName );
				if( g_pModel )
					g_bObjLoaded = TRUE;
				else
					g_bObjLoaded = FALSE;

				if( g_bObjLoaded )
				{
					// Remove file extension
					DWORD i = 0;
					while(szFileTitle[i] != 0 && szFileTitle[i] != '.')
						i++;
					if( szFileTitle[i] == '.' )
						szFileTitle[i] = 0;
					// Name can't have a lenght more than 5
					szFileTitle[5] = 0;

					// Write textures
					WriteTextures( szFileTitle );
					// Write objects
					WriteObjects( szFileTitle );

					// Show ending message
					CHAR szText[MAX_PATH];
					sprintf( szText, "%d object(s)\n%d texture(s)", g_pModel->dwNumObj, g_pModel->dwNumTxt );
					MessageBox( hWnd, szText, "Finished", MB_OK );
				}
			}
			break;
		}
		break;

		default:
			return FALSE;
	}
	
    return TRUE;
}



//-----------------------------------------------------------------------------
// Name: OpenFileDialog()
// Desc: 
//-----------------------------------------------------------------------------
BOOL OpenFileDialog( HWND hWnd, CHAR * szFileName, CHAR * szFileTitle )
{
	szFileName[0]  = 0;
	szFileTitle[0] = 0;
	OPENFILENAME ofn = { sizeof(OPENFILENAME), hWnd, NULL, "XPR Files (*.xpr)\0*.xpr\0", NULL, 0, 1, 
		szFileName, MAX_PATH, szFileTitle, MAX_PATH, NULL, NULL,
		OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_HIDEREADONLY };

	if( GetOpenFileName( &ofn ) )
	{
		return TRUE;
	}

	return FALSE;
}


//-----------------------------------------------------------------------------
// Name: WriteTextures()
// Desc: 
//-----------------------------------------------------------------------------
VOID WriteTextures( CHAR * szBaseName )
{
	DWORD	dwTxtNo;
	CHAR	szTxtName[MAX_PATH];


	for( dwTxtNo = 0; dwTxtNo < g_pModel->dwNumTxt; dwTxtNo++ )
	{
		sprintf( szTxtName, "%s%03d.dds", szBaseName, dwTxtNo ); // Texture name
		DDS_Write( &g_pModel->pTxtList[dwTxtNo], szTxtName );
	}
}


//-----------------------------------------------------------------------------
// Name: WriteObjects()
// Desc: 
//-----------------------------------------------------------------------------
VOID WriteObjects( CHAR * szBaseName )
{
	ST_MY_OBJ		*pObject;
	ST_MY_SUBOBJ	*pSubObject;
	ST_MY_MAT		*pMaterial;
	DWORD	dwObjNo, dwSubobjNo, dwMatNo;
	CHAR	szObjName[MAX_PATH];
	CHAR	szMatName[MAX_PATH];
	CHAR	szTxtName[MAX_PATH];
	CHAR	szMeshName[MAX_PATH];

	DWORD	dwNumMat, dwNumVerCoord, dwNumTxtCoord, dwNumFaces;
	ST_WRITER_3DS_VERTEX	*pVerCoordList = NULL;
	ST_WRITER_3DS_TXTCOORD	*pTxtCoordList = NULL;
	ST_WRITER_3DS_FACE		*pFaceList = NULL;
	DWORD					*pdwNumMatFace = NULL;
	WORD					**ppMatFaceList = NULL;
		

	for( dwObjNo = 0; dwObjNo < g_pModel->dwNumObj; dwObjNo++ )
	{
		pObject = &g_pModel->pObjList[dwObjNo];

		dwNumMat = 0;
		for( dwSubobjNo = 0; dwSubobjNo < pObject->dwNumSubobj; dwSubobjNo++ )
			dwNumMat += pObject->pSubobjList[dwSubobjNo].dwNumMat;

		sprintf( szObjName, "%s%03d.3ds", szBaseName, dwObjNo ); // Object name
		WRITER_3DS_Open( szObjName, pObject->dwNumSubobj, dwNumMat );


		// Material blocs
		dwNumMat = 0;
		for( dwSubobjNo = 0; dwSubobjNo < pObject->dwNumSubobj; dwSubobjNo++ )
		{
			pSubObject = &pObject->pSubobjList[dwSubobjNo];
			for( dwMatNo = 0; dwMatNo < pSubObject->dwNumMat; dwMatNo++ )
			{
				pMaterial = &pSubObject->pMatList[dwMatNo];
				sprintf( szMatName, "mat%02d", dwNumMat );
				dwNumMat++;
				if( !pMaterial->dwNumTxt || pMaterial->pdwTxtList[0] == 0x888 )
					WRITER_3DS_SetMaterial( szMatName, NULL, (ST_WRITER_3DS_MATCOLOR * )&pMaterial->stColor );
				else
				{
					sprintf( szTxtName, "%s%03d.dds", szBaseName, pMaterial->pdwTxtList[0] ); // Material texture name
					WRITER_3DS_SetMaterial( szMatName, szTxtName, (ST_WRITER_3DS_MATCOLOR * )&pMaterial->stColor );
				}
			}
		}


		// Mesh blocs
		dwNumMat = 0;
		for( dwSubobjNo = 0; dwSubobjNo < pObject->dwNumSubobj; dwSubobjNo++ )
		{
			dwNumVerCoord = CreateVerCoordListFromVBuf( g_pModel, &pObject->pSubobjList[dwSubobjNo], &pVerCoordList );
			dwNumTxtCoord = CreateTxtCoordListFromVBuf( g_pModel, &pObject->pSubobjList[dwSubobjNo], &pTxtCoordList );
			CreateFaceListFromIBuf( g_pModel, &pObject->pSubobjList[dwSubobjNo], &dwNumFaces, &pdwNumMatFace, &pFaceList, &ppMatFaceList );

			if( pObject->dwNumSubobj == 1 )
				sprintf( szMeshName, "mesh%02d", dwObjNo ); // Mesh name
			else
				sprintf( szMeshName, "mesh%02d%c", dwObjNo, 'a'+dwSubobjNo ); // Mesh name
			WRITER_3DS_SetMesh( szMeshName, dwNumVerCoord, dwNumFaces, pObject->pSubobjList[dwSubobjNo].dwNumMat );
			WRITER_3DS_SetVerCoord( dwNumVerCoord, pVerCoordList );
			WRITER_3DS_SetTxtCoord( dwNumTxtCoord, pTxtCoordList );
			WRITER_3DS_SetFaces( dwNumFaces, pFaceList );

			// Material assignement
			pSubObject = &pObject->pSubobjList[dwSubobjNo];
			for( dwMatNo = 0; dwMatNo < pSubObject->dwNumMat; dwMatNo++ )
			{
				pMaterial = &pSubObject->pMatList[dwMatNo];
				sprintf( szMatName, "mat%02d", dwNumMat );
				dwNumMat++;
				WRITER_3DS_SetMatFaces( szMatName, pdwNumMatFace[dwMatNo], ppMatFaceList[dwMatNo] );
				delete[] ppMatFaceList[dwMatNo];
			}

			delete[] pVerCoordList;
			delete[] pTxtCoordList;
			delete[] pFaceList;
			delete[] pdwNumMatFace;
			delete[] ppMatFaceList;
		}


		WRITER_3DS_Close();
	}
}


//-----------------------------------------------------------------------------
// Name: CreateVertexListFromVBuf()
// Desc: 
//-----------------------------------------------------------------------------
DWORD CreateVerCoordListFromVBuf( ST_MY_MDL * pModel, ST_MY_SUBOBJ * pSubObject, ST_WRITER_3DS_VERTEX ** pVerCoordList )
{
	DWORD	dwVBufNo, dwVertexNo;
	DWORD	dwNumVerCoord, dwVertexSize, dwPos;
	BYTE	*pVertexList;
	
	
	dwVBufNo = pSubObject->dwVBufNo;
	dwVertexSize = pModel->pVBufList[dwVBufNo].dwVertexSize;
	dwNumVerCoord = pModel->pVBufList[dwVBufNo].dwNumVertices;
	pVertexList = (BYTE *)pModel->pVBufList[dwVBufNo].pVertexList;

	*pVerCoordList = new ST_WRITER_3DS_VERTEX[dwNumVerCoord];

	dwPos = 0;  // Vertex coordinate are at the start of the vertex
	for( dwVertexNo = 0; dwVertexNo < dwNumVerCoord; dwVertexNo++ )
	{
		memcpy( &((*pVerCoordList)[dwVertexNo]), &pVertexList[dwPos], sizeof(ST_WRITER_3DS_VERTEX) );
		dwPos += dwVertexSize;
	}


	return dwNumVerCoord;
}


//-----------------------------------------------------------------------------
// Name: CreateTxtCoordListFromVBuf()
// Desc: 
//-----------------------------------------------------------------------------
DWORD CreateTxtCoordListFromVBuf( ST_MY_MDL * pModel, ST_MY_SUBOBJ * pSubObject, ST_WRITER_3DS_TXTCOORD ** pTxtCoordList )
{
	DWORD	dwVBufNo, dwVertexNo;
	DWORD	dwNumTxtCoord, dwVertexSize, dwVertexType, dwPos;
	BYTE	*pVertexList;
	
	
	dwVBufNo = pSubObject->dwVBufNo;
	dwVertexSize = pModel->pVBufList[dwVBufNo].dwVertexSize;
	dwVertexType = pModel->pVBufList[dwVBufNo].dwVertexType;
	dwNumTxtCoord = pModel->pVBufList[dwVBufNo].dwNumVertices;
	pVertexList = (BYTE *)pModel->pVBufList[dwVBufNo].pVertexList;

	*pTxtCoordList = new ST_WRITER_3DS_TXTCOORD[dwNumTxtCoord];

	dwPos = dwVertexSize - sizeof(ST_WRITER_3DS_TXTCOORD);  // Texture coordinate are at the end of the vertex
	if( dwVertexType & 0x00000200 )  // D3DFVF_TEX2
		dwPos -= sizeof(ST_WRITER_3DS_TXTCOORD);
	for( dwVertexNo = 0; dwVertexNo < dwNumTxtCoord; dwVertexNo++ )
	{
		memcpy( &((*pTxtCoordList)[dwVertexNo]), &pVertexList[dwPos], sizeof(ST_WRITER_3DS_TXTCOORD) );
		(*pTxtCoordList)[dwVertexNo].v *= -1.0f; // On inverse v
		dwPos += dwVertexSize;
	}


	return dwNumTxtCoord;
}


//-----------------------------------------------------------------------------
// Name: CreateFaceListFromIBuf()
// Desc: 
//-----------------------------------------------------------------------------
DWORD CreateFaceListFromIBuf( ST_MY_MDL * pModel, ST_MY_SUBOBJ * pSubObject, DWORD * pdwNumFace, DWORD ** pdwNumMatFace, ST_WRITER_3DS_FACE ** pFaceList, WORD *** ppMatFaceList )
{
	DWORD	dwMatNo, dwIBufNo, dwFaceNo;
	DWORD	dwTotalNumFaces, dwIBufPos;
	DWORD	dwFacePos, dwMatFacePos;
	WORD	wIndex1, wIndex2, wIndex3;


	// Find number of faces
	dwTotalNumFaces = 0;
	for( dwMatNo = 0; dwMatNo < pSubObject->dwNumMat; dwMatNo++ )
		dwTotalNumFaces += pSubObject->pMatList[dwMatNo].pdwStripList[0].dwIndexCount;

	// Allocate face list
	*pFaceList = new ST_WRITER_3DS_FACE[dwTotalNumFaces];
	// Allocate material faces
	*pdwNumMatFace = new DWORD[pSubObject->dwNumMat];
	*ppMatFaceList = new WORD*[pSubObject->dwNumMat];

	// Write face and material face list
	dwFacePos = 0;
	for( dwMatNo = 0; dwMatNo < pSubObject->dwNumMat; dwMatNo++ )
	{
		// Allocate material face list
		(*ppMatFaceList)[dwMatNo] = new WORD[pSubObject->pMatList[dwMatNo].pdwStripList[0].dwIndexCount];

		dwIBufNo  = pSubObject->pMatList[dwMatNo].dwIBufNo;
		dwIBufPos = pSubObject->pMatList[dwMatNo].pdwStripList[0].dwIndexStart;

		dwMatFacePos = 0;
		wIndex1 = pModel->pIBufList[dwIBufNo].pIndexList[dwIBufPos];	dwIBufPos++;
		wIndex2 = pModel->pIBufList[dwIBufNo].pIndexList[dwIBufPos];	dwIBufPos++;
		for( dwFaceNo = 0; dwFaceNo < pSubObject->pMatList[dwMatNo].pdwStripList[0].dwIndexCount; dwFaceNo++ )
		{
			if( !(dwFaceNo%2) )
			{	wIndex3 = pModel->pIBufList[dwIBufNo].pIndexList[dwIBufPos];	dwIBufPos++;	}
			else
			{	wIndex2 = pModel->pIBufList[dwIBufNo].pIndexList[dwIBufPos];	dwIBufPos++;	}
			// Store face only if it's not degenerated ( 2 identical vertices )
			if( wIndex1 != wIndex2 && wIndex1 != wIndex3 && wIndex2 != wIndex3 )
			{
				// Store face
				(*pFaceList)[dwFacePos].wIndex1 = wIndex1;
				(*pFaceList)[dwFacePos].wIndex2 = wIndex2;
				(*pFaceList)[dwFacePos].wIndex3 = wIndex3;
				// Store material face
				(*ppMatFaceList)[dwMatNo][dwMatFacePos] = (WORD)dwFacePos;
				// Increase index
				dwFacePos++;
				dwMatFacePos++;
			}
			if( !(dwFaceNo%2) )
				wIndex1 = wIndex2;
			else
				wIndex1 = wIndex3;
		}
		// Material face count
		(*pdwNumMatFace)[dwMatNo] = dwMatFacePos;
	}
	// Face count
	*pdwNumFace = dwFacePos;


	return TRUE;
}
