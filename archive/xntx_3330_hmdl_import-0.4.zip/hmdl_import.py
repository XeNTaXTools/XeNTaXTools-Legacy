#!BPY
# -*- coding: utf-8 -*-

bl_info = {
        "name": "Valkyria Chronicles (.mlx, .izca, .hmdl)",
        "description": "Imports model files from Valkyria Chronicles (PS3)",
        "author": "Chrrox, Gomtuu",
        "version": (0, 4),
        "blender": (2, 63, 0),
        "location": "File > Import",
        "warning": "",
        "category": "Import-Export",
        }

#import Blender, bpy
import bpy, mathutils, os.path
from bpy_extras.io_utils import ImportHelper
from struct import pack, unpack
from math import radians

tmpdir = bpy.app.tempdir
model_filename = None
tex_images = []
layers_used = 0
SCN = None

def readbyte(F):
    return unpack('B', F.read(1))[0]

def readlong(F):
    return unpack('<i', F.read(4))[0]

def ReadBElong(F):
    return unpack('>i', F.read(4))[0]

def ReadBEword(F):
    return unpack('>h', F.read(2))[0]

def ReadBEfloat(F):
    return unpack('>f', F.read(4))[0]

def convertTo32(inputAsInt):
    sign = inputAsInt >> 15
    exponent = ((inputAsInt & 0x7C00) >> 10) - 16
    fraction = inputAsInt & 0x03FF
    exponentF = exponent + 127
    # Ouput 32 bit integer representing a 32 bit float
    outputAsFloat = pack('>i', (sign << 31) | (exponentF << 23) | (fraction << 13))
    # Output Check
    return unpack('>f', outputAsFloat)[0]

def ReadBEHalfFloat(F):
    return convertTo32(ReadBEword(F))

def read_header(IN):
    extension = IN.read(4)
    size = readlong(IN)
    header_size = readlong(IN)
    return (extension, size, header_size)

def read_sections(IZCA):
    sec_count = readlong(IZCA)
    unknown = readlong(IZCA)
    sections = []
    for i in range(sec_count):
        print("Section", i)
        list_offset = readlong(IZCA)
        list_size = readlong(IZCA)
        old_offset = IZCA.tell()
        IZCA.seek(list_offset)
        section = []
        for j in range(list_size):
            file_offset = readlong(IZCA)
            section.append(InnerFile(IZCA, file_offset))
        IZCA.seek(old_offset)
        sections.append(section)
    return sections

def read_mxtl(sections, s, f):
    mxtl = sections[s][f]
    all_htsfs = find_files(b'HTSF', sections)
    old_offset = mxtl.IZCA.tell()
    mxtl.IZCA.seek(mxtl.offset + mxtl.header_size)
    hmdl_count = readlong(mxtl.IZCA)
    models = []
    for i in range(hmdl_count):
        section_start = mxtl.IZCA.tell()
        unk1 = readlong(mxtl.IZCA)
        assert unk1 == 8
        htsf_count = readlong(mxtl.IZCA)
        textures = []
        for j in range(htsf_count):
            filename_offset = readlong(mxtl.IZCA)
            unk2 = readlong(mxtl.IZCA)
            htsf_index = readlong(mxtl.IZCA)
            textures.append(all_htsfs[htsf_index])
        models.append(textures)
    return models

def find_files(extension, sections):
    found = []
    for s, section in enumerate(sections):
        for f, innerfile in enumerate(section):
            if innerfile.extension == extension:
                found.append((s, f))
    return found


class InnerFile:
    def __init__(self, IZCA, offset):
        self.IZCA = IZCA
        self.offset = offset
        old_offset = self.IZCA.tell()
        self.IZCA.seek(offset)
        (self.extension, self.size, self.header_size) = read_header(self.IZCA)
        print("0x{0:08x} 0x{1:08x} {2}".format(self.offset, self.size, self.extension.decode()))
        self.IZCA.seek(old_offset)

    def read_file(self):
        old_offset = self.IZCA.tell()
        self.IZCA.seek(self.offset)
        self.data = self.IZCA.read(self.size + self.header_size)
        self.IZCA.seek(old_offset)


def create_oneside():
    oneside = bpy.data.textures.new("OneSide", type='BLEND')
    oneside.use_color_ramp = True
    oneside.color_ramp.elements[0].color = (0.0, 0.0, 0.0, 1.0)
    oneside.color_ramp.elements[1].color = (1.0, 1.0, 1.0, 1.0)
    ele = oneside.color_ramp.elements.new(0.5)
    ele.color = (0.0, 0.0, 0.0, 1.0)
    ele = oneside.color_ramp.elements.new(0.501)
    ele.color = (1.0, 1.0, 1.0, 1.0)
    return oneside

def read_materials(F, kfms_offset, matlist_offset, mat_count):
    materials = {}
    if not tex_images:
        return materials
    oneside = None
    F.seek(kfms_offset + matlist_offset)
    for i in range(mat_count):
        F.seek(kfms_offset + matlist_offset + i * 0xa0)
        offset_key = F.tell() - kfms_offset
        # Read info from material list
        unk01 = ReadBElong(F)
        flags = ReadBElong(F)
        unk02 = ReadBElong(F)
        unk03 = ReadBElong(F)
        texture_pos = ReadBElong(F)
        normal_pos = ReadBElong(F)
        # Go look up image numbers for image and normal
        if texture_pos:
            F.seek(kfms_offset + texture_pos + 4)
            image_num = ReadBEword(F)
        if normal_pos:
            F.seek(kfms_offset + normal_pos + 4)
            normal_num = ReadBEword(F)
        # Create the material and textures
        use_alpha = bool(flags & 0x40)
        use_backface_culling = bool(flags & 0x400)
        mat = bpy.data.materials.new("Material")
        mat.game_settings.use_backface_culling = use_backface_culling
        if texture_pos:
            image_tex = bpy.data.textures.new("Texture", type = 'IMAGE')
            image_tex.image = tex_images[image_num]
            image_tex.use_alpha = use_alpha
            slot0 = mat.texture_slots.add()
            slot0.texture = image_tex
            slot0.texture_coords = 'UV'
        if use_alpha:
            if texture_pos:
                slot0.use_map_alpha = True
                slot0.alpha_factor = 1.0
            mat.use_transparency = True
            mat.transparency_method = 'Z_TRANSPARENCY'
            mat.alpha = 0.0
        if normal_pos:
            normal_tex = bpy.data.textures.new("Texture", type = 'IMAGE')
            normal_tex.image = tex_images[normal_num]
            normal_tex.use_normal_map = True
            slot1 = mat.texture_slots.add()
            slot1.texture = normal_tex
            slot1.texture_coords = 'UV'
            slot1.use_map_color_diffuse = False
            slot1.use_map_normal = True
        if use_backface_culling:
            # Use a trick to make backface culling work when rendering
            slot2 = mat.texture_slots.add()
            if oneside is None:
                oneside = create_oneside()
            slot2.texture = oneside
            slot2.texture_coords = 'NORMAL'
            slot2.use_map_color_diffuse = False
            slot2.use_map_alpha = True
            slot2.mapping_x = 'Z'
            slot2.mapping_y = 'NONE'
            slot2.mapping_z = 'NONE'
            slot2.default_value = 0.0
            slot2.use_rgb_to_intensity = True
        mat.specular_intensity = 0.0
        materials[offset_key] = mat
    return materials

def layer_list(layer_num):
    global layers_used
    max_layers = 20
    clamped_layer_num = layer_num % max_layers
    if clamped_layer_num + 1 > layers_used:
        layers_used = clamped_layer_num + 1
    layers_before = [False] * clamped_layer_num
    layers_after = [False] * (max_layers - 1 - clamped_layer_num)
    return layers_before + [True] + layers_after

def create_lamp(SCN):
    lampdata = bpy.data.lamps.new("Default Lamp", 'HEMI')
    lamp = bpy.data.objects.new("Default Lamp", lampdata)
    lamp.layers = [True] * layers_used + [False] * (20 - layers_used)
    lamp.location = (0.0, 20.0, 15.0)
    lamp.rotation_mode = 'AXIS_ANGLE'
    lamp.rotation_axis_angle = (radians(-22.0), 1.0, 0.0, 0.0)
    SCN.objects.link(lamp)
    SCN.update()

def open_hmdl_file(filename):
    KFMS_Array = []
    POF0_Array = []
    ENRS_Array = []
    CCRS_Array = []
    MTXS_Array = []
    EOFC_Array = []
    KFMG_Array = []

    F = open(filename, 'rb')
    idstring = F.read(4)
    totalfilesize = readlong(F)
    F.seek(0x20)
    idstring = F.read(4)
    kfmd_filesize = readlong(F)
    headersize = readlong(F)
    F.seek(headersize)
    print("Reading parts of HMDL file:", filename)
    print("{0:10s} {1:10s} {2}".format("start", "size", "type"))
    while F.tell() < totalfilesize:
        SecStart = F.tell()
        idstring = F.read(4)
        SecSize = readlong(F)
        print("0x{0:08x} 0x{1:08x} {2}".format(SecStart, SecSize, idstring.decode()))
        HeaderSize = readlong(F)
        Count1 = ReadBElong(F)
        Count2 = readlong(F)
        PartSize = readlong(F)

        if idstring == b'KFMS':
            KFMS_Array.append(SecStart)
        elif idstring == b'POF0':
            POF0_Array.append(SecStart)
        elif idstring == b'ENRS':
            ENRS_Array.append(SecStart)
        elif idstring == b'CCRS':
            CCRS_Array.append(SecStart)
        elif idstring == b'MTXS':
            MTXS_Array.append(SecStart)
        elif idstring == b'EOFC':
            EOFC_Array.append(SecStart)
        elif idstring == b'KFMG':
            KFMG_Array.append(SecStart)

        F.seek(SecStart + HeaderSize + PartSize)

    for kfms_i in range(len(KFMS_Array)):
        F.seek(KFMS_Array[kfms_i] + 0x20)
        F.read(4)
        bone_count = ReadBElong(F)
        count2 = ReadBElong(F)
        F.read(4)
        model_height = ReadBEfloat(F)
        bone_list_pos = ReadBElong(F)
        ReadBElong(F)
        init_xform_pos = ReadBElong(F)
        material_count = ReadBElong(F)
        material_list_pos = ReadBElong(F)
        object_count = ReadBElong(F)
        object_list_pos = ReadBElong(F)
        mesh_count = ReadBElong(F)
        mesh_list_pos = ReadBElong(F)
        F.seek(KFMS_Array[kfms_i] + 0x80)
        FVFinfo = ReadBElong(F)
        F.seek(KFMS_Array[kfms_i] + FVFinfo)
        unk01 = readlong(F)
        vertsize = ReadBElong(F)
        Null01 = ReadBElong(F)
        FaceCount = ReadBElong(F)
        UnkCount = ReadBElong(F)
        VertCount = ReadBElong(F)
        print("KFMS {}: {} materials,\n\t{} bones?, {} objects, {} meshes,\n\t{} faces, and {} vertices".format(
            kfms_i, material_count, bone_count, object_count, mesh_count, FaceCount, VertCount))
        materials = read_materials(F, KFMS_Array[kfms_i], material_list_pos, material_count)

        F.seek(KFMS_Array[kfms_i] + bone_list_pos)
        Bone_Info_Array =[]
        for i in range(bone_count):
            row = {}
            row['ptr'] = F.tell() - KFMS_Array[kfms_i]
            F.read(4)
            row['id'] = ReadBEword(F)
            row['parent_id'] = ReadBEword(F)
            row['dim1'] = ReadBEfloat(F)
            row['dim2'] = ReadBEfloat(F)
            row['parent_ptr'] = ReadBElong(F)
            row['fav_child_ptr'] = ReadBElong(F)
            row['unk_bone_ptr2'] = ReadBElong(F)
            row['bound_box_ptr'] = ReadBElong(F)
            F.read(4)
            F.read(4)
            row['count2'] = ReadBEword(F)
            row['is_part_of_count2'] = ReadBEword(F)
            row['object_ptr1'] = ReadBElong(F)
            row['object_ptr2'] = ReadBElong(F)
            row['object_ptr3'] = ReadBElong(F)
            row['ptr2'] = ReadBElong(F)
            row['deform_ptr'] = ReadBElong(F)
            F.read(32)
            Bone_Info_Array.append(row)
            row['parent'] = None
            row['children'] = []
            row['fav_child'] = None
            if row['parent_id'] != row['id']:
                parent_bone = Bone_Info_Array[row['parent_id']]
                row['parent'] = parent_bone
                parent_bone['children'].append(row)
                print("Comparing", row['ptr'], "to", parent_bone['fav_child_ptr'])
                if row['ptr'] == parent_bone['fav_child_ptr'] and row['ptr'] > 0:
                    parent_bone['fav_child'] = row
        F.seek(KFMS_Array[kfms_i] + init_xform_pos)
        for bone in Bone_Info_Array:
            bone['location'] = [ReadBEfloat(F) for x in range(3)]
            F.read(4)
            bone['rotation'] = [ReadBEfloat(F) for x in range(4)]
            bone['rotation'] = bone['rotation'][3:] + bone['rotation'][:3]
            bone['scale'] = [ReadBEfloat(F) for x in range(3)]
            F.read(4)
            print("{:03d} {:03d} ({:7.4f}, {:7.4f}, {:7.4f}) ({:7.4f}, {:7.4f}, {:7.4f}, {:7.4f})".format(bone["id"], bone["parent_id"],
                *(bone["location"] + bone["rotation"])))
        deform_bones = {}
        for bone in Bone_Info_Array:
            if bone['deform_ptr'] == 0:
                continue
            F.seek(KFMS_Array[kfms_i] + bone['deform_ptr'])
            matrix_ptr = ReadBElong(F) # pointer to some kind of transform?
            bone['deform_id'] = ReadBElong(F)
            deform_bones[bone['deform_id']] = bone
            #F.seek(KFMS_Array[kfms_i] + matrix_ptr)
            #bone['matrix'] = mathutils.Matrix((
            #    (ReadBEfloat(F), ReadBEfloat(F), ReadBEfloat(F), ReadBEfloat(F)),
            #    (ReadBEfloat(F), ReadBEfloat(F), ReadBEfloat(F), ReadBEfloat(F)),
            #    (ReadBEfloat(F), ReadBEfloat(F), ReadBEfloat(F), ReadBEfloat(F)),
            #    (ReadBEfloat(F), ReadBEfloat(F), ReadBEfloat(F), ReadBEfloat(F))
            #    ))
            #bpy.ops.object.add(type = 'EMPTY')
            #em = bpy.context.object
            #em.name = "DeformEmpty.{:02x}".format(bone['deform_id'])
            #em.empty_draw_size = 0.1
            #em.location = bone['matrix'].to_quaternion() * bone['matrix'].transposed().to_translation()
        bpy.ops.object.add(type = 'ARMATURE', enter_editmode = True)
        arm_obj = bpy.context.object
        arm_obj.name = "Armature"
        arm = arm_obj.data
        for bone in Bone_Info_Array:
            if 'deform_id' in bone:
                bone['name'] = "Deform.{:02x}".format(bone['deform_id'])
            else:
                bone['name'] = "Bone.{:02x}".format(bone['id'])
            bone['bpy'] = arm.edit_bones.new(bone['name'])
            bone['bpy'].use_connect = True
            if bone['parent']:
                bone['bpy'].parent = bone['parent']['bpy']
                bone['bpy'].head = bone['parent']['bpy'].tail
                bone['accum_rotation'] = bone['parent']['accum_rotation']
                bone['bpy'].tail = bone['bpy'].head + bone['accum_rotation'] * mathutils.Vector(bone['location'])
                bone['tail'] = bone['bpy'].tail.copy()
                # There's your problem:
                # (This should be done to determine the tail's location.)
                bone['accum_rotation'] *= mathutils.Quaternion(bone['rotation'])
            else:
                bone['bpy'].head = (0, 0, 0)
                bone['accum_rotation'] = mathutils.Quaternion(bone['rotation'])
                bone['bpy'].tail = bone['bpy'].head + bone['accum_rotation'] * mathutils.Vector(bone['location'])
                bone['tail'] = bone['bpy'].tail.copy()
        if bpy.context.edit_object:
            bpy.ops.object.editmode_toggle()
        arm_obj.layers = layer_list(kfms_i)

        F.seek(KFMS_Array[kfms_i] + object_list_pos)
        Group_Info_Array = []
        for a in range(object_count):
            Group_Info_Array.append({
                'index': ReadBElong(F),
                'u01': ReadBEword(F),
                'parent_bone_id': ReadBEword(F),
                'material_ptr': ReadBElong(F),
                'obj_mesh_count': ReadBElong(F),
                'mesh_ptr': ReadBElong(F),
                'VPosBytes?': ReadBElong(F),
                'VCount': ReadBEword(F),
                'n01': ReadBEword(F),
                'n02': ReadBEword(F),
                'n03': ReadBEword(F),
                })

        Vert_Info_Array = []
        for group in Group_Info_Array:
            F.seek(KFMS_Array[kfms_i] + group['mesh_ptr'])
            for a in range(group['obj_mesh_count']):
                Vert_Info_Array.append({
                    'vert_group_count': ReadBEword(F),
                    'u02': ReadBEword(F),
                    'u03': ReadBEword(F),
                    'VCount': ReadBEword(F),
                    'FCount': ReadBEword(F),
                    'n01': ReadBElong(F),
                    'vert_group_ptr': ReadBEword(F),
                    'VPos': ReadBElong(F),
                    'FPos': ReadBElong(F),
                    'n02': ReadBElong(F),
                    'n03': ReadBElong(F),
                    'material': group['material_ptr'],
                    'parent_bone': Bone_Info_Array[group['parent_bone_id']],
                    })

        F.seek(KFMG_Array[kfms_i] + 0x20)
        FaceStart = F.tell()
        FaceEnd1 = FaceStart + (2 * FaceCount)
        F.seek(FaceEnd1)
        if F.tell() % 16 != 0:
            F.seek(16 - F.tell() % 16, True)
        VertStart = F.tell()
        if bpy.context.edit_object:
            bpy.ops.object.editmode_toggle()
        deforms = {}
        for a in range(mesh_count):
            Vert_array = []
            Normal_array = []
            UV_array = []
            Face_array = []

            F.seek(FaceStart + (2 * Vert_Info_Array[a]['FPos']))
            FaceEnd = F.tell() + (2 * Vert_Info_Array[a]['FCount'])
            StartDirection = -1
            f1 = ReadBEword(F)
            f2 = ReadBEword(F)
            FaceDirection = StartDirection
            while F.tell() < FaceEnd:
                f3 = ReadBEword(F)
                if f3 == 0xFFFF:
                    f1 = ReadBEword(F)
                    f2 = ReadBEword(F)
                    FaceDirection = StartDirection
                else:
                    FaceDirection *= -1
                    if f1 != f2 and f2 != f3 and f3 != f1:
                        if FaceDirection > 0:
                            Face_array.append([f3, f1, f2, 0])
                        else:
                            Face_array.append([f3, f2, f1, 0])
                    f1 = f2
                    f2 = f3

            F.seek(VertStart + (vertsize * Vert_Info_Array[a]['VPos']))
            vertex_groups = {}
            for b in range(Vert_Info_Array[a]['VCount']):
                if vertsize == 44:
                    vx = ReadBEfloat(F)
                    vy = ReadBEfloat(F)
                    vz = ReadBEfloat(F)
                    nx = ReadBEfloat(F)
                    ny = ReadBEfloat(F)
                    nz = ReadBEfloat(F)
                    wx = ReadBEfloat(F)
                    wy = ReadBEfloat(F)
                    tu = ReadBEHalfFloat(F) * 2
                    tv = ReadBEHalfFloat(F) * -2
                    wz = ReadBEfloat(F)
                    yy = ReadBEfloat(F)
                elif vertsize == 48:
                    vx = ReadBEfloat(F)
                    vy = ReadBEfloat(F)
                    vz = ReadBEfloat(F)
                    vgroup1 = readbyte(F)
                    vgroup2 = readbyte(F)
                    vgroup3 = readbyte(F)
                    vgroup4 = readbyte(F)
                    weight1 = ReadBEHalfFloat(F) * 2
                    weight2 = ReadBEHalfFloat(F) * 2
                    nz = ReadBEfloat(F)
                    tu = ReadBEHalfFloat(F) * 2
                    tv = ReadBEHalfFloat(F) * -2
                    wx = ReadBEfloat(F)
                    wy = ReadBEfloat(F)
                    wz = ReadBEfloat(F)
                    yy = ReadBEfloat(F)
                    yz = ReadBEfloat(F)
                    if vgroup1 not in vertex_groups:
                        vertex_groups[vgroup1] = []
                    vertex_groups[vgroup1].append([b, weight1])
                    if vgroup2 not in vertex_groups:
                        vertex_groups[vgroup2] = []
                    vertex_groups[vgroup2].append([b, weight2])
                elif vertsize == 80:
                    vx = ReadBEfloat(F)
                    vy = ReadBEfloat(F)
                    vz = ReadBEfloat(F)
                    nx = ReadBEfloat(F)
                    ny = ReadBEfloat(F)
                    nz = ReadBEfloat(F)
                    wx = ReadBEfloat(F)
                    wy = ReadBEfloat(F)
                    wz = ReadBEfloat(F)
                    yy = ReadBEfloat(F)
                    yz = ReadBEfloat(F)
                    ax = ReadBEfloat(F)
                    ay = ReadBEfloat(F)
                    az = ReadBEfloat(F)
                    tu = ReadBEfloat(F)
                    tv = ReadBEfloat(F) * -1

                    F.seek(0x10, True)
                Vert_array.append(vx)
                Vert_array.append(vy)
                Vert_array.append(vz)
                #Normal_array.append(nx)
                #Normal_array.append(ny)
                #Normal_array.append(nz)
                UV_array.append((tu, tv))

            # Build Mesh

            msh = bpy.data.meshes.new('myMesh')

            msh.vertices.add(len(Vert_array) // 3)
            msh.tessfaces.add(len(Face_array))

            msh.vertices.foreach_set("co", Vert_array)
            #msh.vertices.foreach_set("normal", Normal_array)
            face_verts = []
            for v1, v2, v3, v4 in Face_array:
                face_verts.extend([v1, v2, v3, v4])
            msh.tessfaces.foreach_set("vertices_raw", face_verts)

            material_key = Vert_Info_Array[a]['material']
            if material_key and materials:
                mat = materials[material_key]
                msh.materials.append(mat)
                if hasattr(mat.texture_slots[0], "texture"):
                    msh.tessface_uv_textures.new()
                    uv_faces = msh.tessface_uv_textures.active.data[:]
                    img = mat.texture_slots[0].texture.image
                    for i, face in enumerate(Face_array):
                        msh.tessfaces[i].use_smooth = 1
                        uv_faces[i].uv1 = UV_array[face[0]]
                        uv_faces[i].uv2 = UV_array[face[1]]
                        uv_faces[i].uv3 = UV_array[face[2]]
                        uv_faces[i].image = img

            msh.update()
            #msh.mode |= Blender.Mesh.Modes['NOVNORMALSFLIP']
            # Add mesh to scene on an appropriate layer
            ob = bpy.data.objects.new('myObj', msh)
            ob.parent = arm_obj

            F.seek(KFMS_Array[kfms_i] + Vert_Info_Array[a]['vert_group_ptr'])
            #print("Reading {} vertex group mappings from {}")
            for i in range(Vert_Info_Array[a]['vert_group_count']):
                deform_id = ReadBEword(F)
                vgroup_id = ReadBEword(F)
                deforms[vgroup_id] = deform_id
            for group_id, vert_info in vertex_groups.items():
                if group_id not in deforms:
                    continue
                if deforms[group_id] not in deform_bones:
                    continue
                name_bone = deform_bones[deforms[group_id]]
                if name_bone['fav_child'] and 'deform_id' in name_bone['fav_child']:
                    print("Using", name_bone['fav_child']['deform_id'], "instead of", name_bone['deform_id'])
                    name_bone = name_bone['fav_child']
                vgroup_name = "Deform.{:02x}".format(name_bone['deform_id'])
                if vgroup_name in ob.vertex_groups:
                    group = ob.vertex_groups[vgroup_name]
                else:
                    group = ob.vertex_groups.new(vgroup_name)
                for vert_id, weight in vert_info:
                    group.add([vert_id], weight, 'ADD')

            layers = layer_list(kfms_i)
            ob.layers = layers
            if Vert_Info_Array[a]['parent_bone']['id']:
                ob.rotation_mode = 'QUATERNION'
                m1q = arm.bones[Vert_Info_Array[a]['parent_bone']['name']].matrix.to_quaternion()
                m2q = ob.matrix_world.to_quaternion()
                axis_correction = m1q.rotation_difference(m2q)
                ob.rotation_mode = 'QUATERNION'
                ob.rotation_quaternion = axis_correction * Vert_Info_Array[a]['parent_bone']['accum_rotation']
                ob.parent_type = 'BONE'
                ob.parent_bone = Vert_Info_Array[a]['parent_bone']['name']
            else:
                ob.parent_type = 'ARMATURE'
            SCN.objects.link(ob)
            SCN.update()

def unique_image_name(i):
    import random
    images = [os.path.basename(x.filepath) for x in bpy.data.images]
    r = random.randint(0, 0xffffffff)
    fmt_str = "{:02d}-{:08x}.dds"
    while (fmt_str.format(i, r)) in images:
        r = random.randint(0, 1000000000)
    return fmt_str.format(i, r)

def write_tmp_file(sections, s, f):
    innerfile = sections[s][f]
    innerfile.read_file()
    tmp_path = os.path.join(tmpdir, 's{0:02d}_f{1:03d}.{2}'.format(s, f, innerfile.extension.decode()))
    tmp_file = open(tmp_path, 'wb')
    tmp_file.write(innerfile.data)
    tmp_file.close()
    return tmp_path

def write_tmp_dds(IN, start_offset, i):
    from bpy_extras.image_utils import load_image
    global tex_images
    IN.seek(start_offset)
    extension, size, header_size = read_header(IN)
    assert extension == b'HTSF', 'HTSF data not found where expected.'
    IN.seek(start_offset + header_size)
    dds_data = IN.read(size)
    # Remove zero padding
    dds_start = dds_data.find(b'DDS |')
    dds_data = dds_data[dds_start:]
    dds_path = os.path.join(tmpdir, unique_image_name(i))
    print("Loading image:", dds_path)
    DDS = open(dds_path, 'wb')
    DDS.write(dds_data)
    DDS.close()
    image = load_image(dds_path)
    image.pack()
    tex_images.append(image)
    return dds_path

def open_htex_file(filename):
    HTEX = open(filename, 'rb')
    ext = HTEX.read(4)
    assert ext == b'HTEX', 'Selected file was not an HTEX file.'
    filesize = readlong(HTEX)
    headersize = readlong(HTEX)
    HTEX.seek(headersize)
    i = 0
    while True:
        start_offset = HTEX.tell()
        ext = HTEX.read(4)
        if ext == b'' or ext == b'EOFC':
            break
        write_tmp_dds(HTEX, start_offset, i)
        i += 1

def open_pjnt_file(filename):
    F = open(filename, 'rb')
    F.seek(0x20)
    unk1 = ReadBElong(F)
    bone_count = ReadBElong(F)
    unk2 = ReadBElong(F)
    unk3 = ReadBElong(F)
    table0 = []
    mylayer = layers_used
    for i in range(bone_count):
        label = F.read(4)
        print(label)
        F.seek(0x0c, True)
        t0ptr0 = ReadBElong(F) # points to table1
        F.seek(0x2c, True)
        table0.append([t0ptr0])
    table1 = []
    for row in table0:
        print("%x" % row[0])
        F.seek(row[0])
        unk4 = ReadBElong(F)
        t1ptr0 = ReadBElong(F) # points to table2
        t1ptr1 = ReadBElong(F) # points to table2
        unk5 = ReadBElong(F)
        t1ptr2 = ReadBElong(F) # points to table3
        unk6 = ReadBElong(F)
        t1ptr3 = ReadBElong(F) # points to table3
        t1ptr4 = ReadBElong(F) # points to table3
        t1ptr5 = ReadBElong(F) # points to table3
        t1ptr6 = ReadBElong(F) # points to table3
        t1ptr7 = ReadBElong(F) # points to table4
        t1ptr8 = ReadBElong(F) # points to table5
        t1ptr9 = ReadBElong(F) # points to table5
        t1ptr10 = ReadBElong(F) # points to table5
        t1ptr11 = ReadBElong(F) # points to table5
        t1ptr12 = ReadBElong(F) # points to table5
        t1ptr13 = ReadBElong(F) # points to table5
        t1ptr14 = ReadBElong(F) # points to table5
        t1ptr15 = ReadBElong(F) # points to table5
        t1ptr16 = ReadBElong(F) # points to table5
        t1ptr17 = ReadBElong(F) # points to table5
        table1.append(t1ptr0)
        table1.append(t1ptr1)
    table2 = []
    for t2pointer in table1:
        F.seek(t2pointer)
        unk7 = ReadBElong(F)
        t2ptr0 = ReadBElong(F) # points to coordinate list
        t2ptr1 = ReadBElong(F) # points to coordinate list
        t2ptr2 = ReadBElong(F) # points to coordinate list
        table2.append(t2ptr0)
        table2.append(t2ptr1)
        table2.append(t2ptr2)
    for coordpointer in table2:
        F.seek(coordpointer)
        x = ReadBEfloat(F)
        y = ReadBEfloat(F)
        z = ReadBEfloat(F)
        empty = bpy.data.objects.new('EMPTY', None)
        empty.name = os.path.basename(filename)
        empty.layers = layer_list(mylayer)
        empty.empty_draw_size = 0.1
        #empty.empty_draw_type = 'SINGLE_ARROW'
        SCN.objects.link(empty)
        empty.location = (x, y, z)
    F.close()

def open_ccol_file(filename):
    F = open(filename, 'rb')
    F.seek(0x20)
    unk1 = ReadBElong(F)
    bone_count = ReadBElong(F)
    unk2 = ReadBElong(F)
    unk3 = ReadBElong(F)
    table0 = []
    mylayer = layers_used
    for i in range(bone_count):
        label = F.read(4)
        print(label)
        F.seek(0x08, True)
        t0count0 = ReadBElong(F) # how many rows to read from coordinate list?
        t0ptr0 = ReadBElong(F) # points to coordinate list
        F.seek(0x2c, True)
        table0.append([t0count0, t0ptr0])
    for (row_count, coordpointer) in table0:
        F.seek(coordpointer)
        for i in range(row_count + 2):
            x = ReadBEfloat(F)
            y = ReadBEfloat(F)
            z = ReadBEfloat(F)
            empty = bpy.data.objects.new('EMPTY', None)
            empty.name = os.path.basename(filename)
            empty.layers = layer_list(mylayer)
            empty.empty_draw_size = 0.1
            #empty.empty_draw_type = 'SINGLE_ARROW'
            SCN.objects.link(empty)
            empty.location = (x, y, z)
    F.close()

def open_izca_file(IZCA):
    global tex_images
    print("Reading parts of IZCA file.")
    print("{0:10s} {1:10s} {2}".format("start", "size", "type"))
    sections = read_sections(IZCA)
    assert sections != [], 'No sections found in IZCA file.'
    mxtl_index = find_files(b'MXTL', sections)
    if mxtl_index == []:
        # deduce HMDL/HTEX associations
        hmdls = find_files(b'HMDL', sections)
        htexs = find_files(b'HTEX', sections)
        assert len(hmdls) == len(htexs), 'Unable to deduce model/texture associates.'
        for hmdl, htex in zip(hmdls, htexs):
            tex_images = []
            htex_path = write_tmp_file(sections, htex[0], htex[1])
            print("Opening HTEX file:", htex_path)
            open_htex_file(htex_path)
            hmdl_path = write_tmp_file(sections, hmdl[0], hmdl[1])
            print("Opening HMDL file:", hmdl_path)
            open_hmdl_file(hmdl_path)
        pjnts = find_files(b'PJNT', sections)
        #for pjnt in pjnts:
        #    pjnt_path = write_tmp_file(sections, pjnt[0], pjnt[1])
        #    open_pjnt_file(pjnt_path)
        ccols = find_files(b'CCOL', sections)
        #for ccol in ccols:
        #    ccol_path = write_tmp_file(sections, ccol[0], ccol[1])
        #    open_ccol_file(ccol_path)
    else:
        # read HMDL/HTSF associations
        hmdls = find_files(b'HMDL', sections)
        htsf_sets = read_mxtl(sections, mxtl_index[0][0], mxtl_index[0][1])
        for hmdl, htsf_set in zip(hmdls, htsf_sets):
            tex_images = []
            for i, htsf in enumerate(htsf_set):
                write_tmp_dds(IZCA, sections[htsf[0]][htsf[1]].offset, i)
            hmdl_path = write_tmp_file(sections, hmdl[0], hmdl[1])
            open_hmdl_file(hmdl_path)

def set_model_filename(filename):
    global model_filename
    global SCN
    model_filename = filename
    model = open(model_filename, 'rb')
    (extension, size, header_size) = read_header(model)
    SCN = bpy.data.scenes.new(os.path.basename(model_filename))
    for screen in bpy.data.screens:
        screen.scene = SCN
        for area in screen.areas:
            if area.type == 'VIEW_3D':
                for space in area.spaces:
                    if space.type == 'VIEW_3D':
                        space.viewport_shade = 'TEXTURED'
                        if hasattr(space, 'show_backface_culling'):
                            space.show_backface_culling = True
    if extension == b'HMDL':
        model.close()
        open_hmdl_file(model_filename)
        #if 'prev_htex_filename' in settings:
        #    Blender.Window.FileSelector(set_htex_filename, 'Open HTEX Texture Set', settings['prev_htex_filename'])
        #else:
        #    Blender.Window.FileSelector(set_htex_filename, 'Open HTEX Texture Set')
    elif extension == b'IZCA' or extension == b'MLX':
        model.seek(header_size)
        open_izca_file(model)
    SCN.layers = layer_list(0)
    create_lamp(SCN)
    SCN.game_settings.material_mode = 'GLSL'

def set_htex_filename(filename):
    htex_filename = filename
    open_htex_file(htex_filename)
    open_hmdl_file(model_filename)


class ImportValkyria(bpy.types.Operator, ImportHelper):
    bl_idname = 'import_scene.import_valkyria'
    bl_label = 'Valkyria Chronicles (.mlx, .izca, .hmdl)'
    filename_ext = "*.izca"
    filter_glob = bpy.props.StringProperty(
            default = "*.mlx;*.izca;*.hmd",
            options = {'HIDDEN'},
            )

    def execute(self, context):
        set_model_filename(self.filepath)
        return {'FINISHED'}


def menu_func(self, context):
    self.layout.operator(ImportValkyria.bl_idname)

def register():
    bpy.utils.register_class(ImportValkyria)
    bpy.types.INFO_MT_file_import.append(menu_func)

def unregister():
    bpy.utils.unregister_class(ImportValkyria)
    bpy.types.INFO_MT_file_import.remove(menu_func)
