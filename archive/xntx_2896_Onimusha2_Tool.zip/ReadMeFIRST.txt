+-_--------------------------------_-+
  | Onimusha 2 : Samurai's Destiny |
  |				   |
  |	TOOL BY : SNOOP2K2	   |
  |			    	   |
+-|--------------------------------|-+
  _
+-_-+
Will extract and rebuild BGM.DAT and VOICE_E.DAT
+-_-+



---WHEN USING THE TOOL---

There are 2 seperate files named "eofbgm.dat" and "eofvoice.dat" included with the tool, make sure these 2 files are present in the same directory as the tool when extracting/rebuilding.

So for example.. you will extract C:\Onimusha2\DAT\BGM.DAT ...

Put the tool, eofbgm.dat, and eofvoice.dat in C:\Onimusha2\DAT\

-------------------------


The tool has 1 bug.. in between operations, close, and reopen the tool.

+-_-+ snOop2k2 +-_-+