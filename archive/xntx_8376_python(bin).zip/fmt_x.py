#by Durik256
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("unk_game", ".x")
    noesis.setHandlerTypeCheck(handle, CheckType)
    noesis.setHandlerLoadModel(handle, LoadModel)
    return 1

def CheckType(data):
    return 1

def LoadModel(raw, mdlList):
    global data, bones
    data, bones, anims = raw.decode().split('\n'), [], []
    ctx = rapi.rpgCreateContext()
    
    x = 0
    while x < len(data):
        param = data[x].split()+[None]
        
        if param[0] == 'Frame':
            br = bracket(x+1)
            ParseFrame(param[1], None, br[0], br[1])
            x = br[1]
        elif param[0] == 'AnimationSet':
            br = bracket(x+1)
            anim = ParseAnimSet(param[1], br[0], br[1])
            anims.append(anim)
            x = br[1]
        x+=1
    
    if bones:
        bones = rapi.multiplyBones(bones)
    
    try: mdl = rapi.rpgConstructModel()
    except: mdl = NoeModel()
    mdl.setAnims(anims)
    mdl.setBones(bones)
    mdlList.append(mdl)
    return 1

def ParseFrame(name, parent, x, end):
    print(name)
    matrix = NoeMat43()
    bones.append(NoeBone(len(bones),name,matrix,parent))
    while x < end:
        param = data[x].split()+[None]
        if param[0] == 'Frame':
            br = bracket(x+1)
            ParseFrame(param[1], name, br[0], br[1])
            x = br[1]
        elif param[0] == 'FrameTransformMatrix':
            br = bracket(x+1)
            matrix = ParseMatrix(br[0], br[1])
            bones[-1].setMatrix(matrix)#.swapHandedness(0)
            x = br[1]
        elif param[0] == 'Mesh':
            br = bracket(x+1)
            ParseMesh(param[1], br[0], br[1])
            x = br[1]
        x+=1
    return 1
    
def ParseMesh(name, x, end):
    print(">>>>>>>>>>>>>>>>>>>>>>>>..",name)
    rapi.rpgSetName(name)
    vnum = int(data[x].split(';')[0])
    x += 1
    vbuf = b''
    for i in range(x, x+vnum):
        vbuf += noePack('3f', *[float(v) for v in data[x].split(';')[:3]])
        x += 1
    rapi.rpgBindPositionBuffer(vbuf, noesis.RPGEODATA_FLOAT, 12)
    inum = int(data[x].split(';')[0])
    x += 1
    ibuf = b''
    for i in range(x, x+inum):
        ibuf += noePack('3H', *[int(v) for v in data[x].split(';')[1].split(',')])
        x += 1
    weight = []
    for i in range(vnum):
        weight.append([[],[]])

    #x = 0
    while x < end:
        param = data[x].split()+[None]
        if param[0] == 'MeshTextureCoords':
            br = bracket(x+1)
            uvnum = int(data[x+1].split(';')[0])
            uvbuf = b''
            for i in range(x+2, x+uvnum+2):
                uvbuf += noePack('2f', *[float(v) for v in data[i].split(';')[:2]])
                rapi.rpgBindUV1Buffer(uvbuf, noesis.RPGEODATA_FLOAT, 8)
            x = br[1]
        elif param[0] == 'SkinWeights':
            br = bracket(x+1)
            idBone = getBoneIndex(data[x+1].split('"')[1])
            print(idBone, data[x+1].split('"')[1])
            wnum = int(data[x+2].split(';')[0])
            for i in range(x+3, x+wnum+3):
                index = int(data[i].replace(';','').replace(',',''))
                weight[index][0].append(idBone)
                weight[index][1].append(float(data[i+wnum].replace(';','').replace(',','')))
            x = br[1]
        x+=1
    
    #create weight
    wbuf = b''
    for w in weight:
        w[0] = w[0] + [0]*(4-len(w[0]))
        w[1] = w[1] + [0]*(4-len(w[1]))
        wbuf += noePack('4H', *w[0])
        wbuf += noePack('4f', *w[1])
    
    rapi.rpgBindBoneIndexBuffer(wbuf, noesis.RPGEODATA_USHORT, 24, 4)
    rapi.rpgBindBoneWeightBufferOfs(wbuf, noesis.RPGEODATA_FLOAT, 24, 8, 4)
    
    rapi.rpgCommitTriangles(ibuf, noesis.RPGEODATA_USHORT, inum*3, noesis.RPGEO_TRIANGLE)
    return 1
    
def ParseAnimSet(name, x, end):
    #x = 0
    animBones = []
    while x < end:
        param = data[x].split()+[None]
        if param[0] == 'Animation':
            br = bracket(x+1)
            ParseAnimation(animBones, br[0], br[1])
            x = br[1]
        x+=1

    anim = NoeKeyFramedAnim(name, bones, animBones, 30)
    return anim

def ParseAnimation(animBones, x, end):
    bnName = None
    rotList = []
    posList = []

    while x < end:
        param = data[x].split()+[None]
        if param[0] == '{':
            bnName = param[1]
        elif param[0] == 'AnimationKey':
            br = bracket(x+1)
            AnimKey(rotList,posList,br[0], br[1])
            x = br[1]
        x+=1
    if bnName:
        keyBone = NoeKeyFramedBone(getBoneIndex(bnName))
        keyBone.setRotation(rotList)
        keyBone.setTranslation(posList)
        animBones.append(keyBone)
    return 1
    
def AnimKey(rotList,posList,x, end):
    type, numFrame = int(data[x].split(';')[0]), int(data[x+1].split(';')[0])

    for i in range(x+2, x+2+numFrame):
        param = data[i].split(';')
        time = int(param[0])/4800#tick
        size = int(param[1])
        matrix = NoeMat44.fromBytes(struct.pack('16f', *[float(x) for x in param[2].split(',')])).toMat43()
        rotList.append(NoeKeyFramedValue(time, matrix.toQuat()))
        posList.append(NoeKeyFramedValue(time, matrix[3]))
    return 1
    
def getBoneIndex(name):
    for i,bone in enumerate(bones):
        if name == bone.name:
            return bone.index
    return -1   
    
def ParseMatrix(start, end):
    s = ' '.join(data[start:end])
    s = struct.pack('16f', *[float(x) for x in s[s.find("{")+1:s.find(";")].split(',')])
    return NoeMat44.fromBytes(s).toMat43()

def bracket(start):
    br = 1
    for i in range(start, len(data)):
        if '{' in data[i]:
            br += 1
        if '}' in data[i]:
            br -= 1
        if not br:
            return [start, i]