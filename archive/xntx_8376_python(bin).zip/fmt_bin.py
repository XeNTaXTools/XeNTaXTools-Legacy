#by Durik256
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("directx", ".bin")
    noesis.setHandlerTypeCheck(handle, CheckType)
    noesis.setHandlerLoadModel(handle, LoadModel)
    return 1

def CheckType(data):
    return 1

def LoadModel(data, mdlList):
    bs = NoeBitStream(data)
    bs.seek(128)
    ver = bs.readInt()
    print(ver)
    
    global bones, anims
    bones = []
    anims = []
    
    if ver == 256:
        load_100(bs)
    elif ver == 257:
        load_101(bs)
    elif ver == 258:
        load_102(bs)
    elif ver == 259:
        load_103(bs)
    elif ver == 260:
        load_104(bs)
    else:
        return 0

    mdl = NoeModel()
    mdl.setAnims(anims)
    mdl.setBones(bones)
    mdlList.append(mdl)
    return 1
    
def Load_old(bs, ver):
    animBones = []
    while bs.getOffset() < bs.getSize():
        numBones = bs.readInt()
        print('>>>>>>>>>',numBones)
        for x in range(numBones):
            VERSION = bs.readInt()
            m_cPositionKeys = bs.readInt()
            m_cRotateKeys = bs.readInt()
            m_cScaleKeys = bs.readInt()
            if ver == 257: m_cMatrixKeys = bs.readInt()
            m_cQuatPosKeys = bs.readInt()
            #-------------
            rotList = []
            posList = []
            sclList = []
            #-------------
            for x in range(m_cQuatPosKeys):
                time = bs.readInt()/4800
                rot, pos, scl = BinMat43(bs)
                rotList.append(NoeKeyFramedValue(time, rot))
                posList.append(NoeKeyFramedValue(time, pos))
                sclList.append(NoeKeyFramedValue(time, scl))
            
            m_strBone = noeStrFromBytes(bs.readBytes(bs.readInt()))
            id = getBoneIndex(m_strBone, bones)
            if id == -1:
                id = len(bones)
            bones.append(NoeBone(id,m_strBone,NoeMat43()))
            #---------
            keyBone = NoeKeyFramedBone(id)#getBoneIndex(m_strBone, bones)
            keyBone.setRotation(rotList)
            keyBone.setTranslation(posList)
            keyBone.setScale(sclList, noesis.NOEKF_SCALE_VECTOR_3)
            animBones.append(keyBone)
            #---------
            print(id, m_strBone, VERSION)

    anim = NoeKeyFramedAnim('anim_0', bones, animBones, 30)
    anims.append(anim)
    return 1
    
def Load_new(bs, ver):
    animBones = []
    while bs.getOffset() < bs.getSize():
        numBones = bs.readInt()
        print('>>>>>>>>>',numBones)
        for x in range(numBones):
            VERSION = bs.readInt()
            m_strBone = noeStrFromBytes(bs.readBytes(bs.readInt()))
            m_cRotateKeys = bs.readInt()
            dwGabageData = bs.readInt()#m_strBone.length()
            m_cPositionKeys = bs.readInt()
            m_cQuatPosKeys = bs.readInt()
            #-------------
            rotList = []
            posList = []
            sclList = []
            #-------------
            for x in range(m_cQuatPosKeys):
                time = bs.readInt()/4800
                rot, pos, scl = BinMat43(bs)
                rotList.append(NoeKeyFramedValue(time, rot))
                posList.append(NoeKeyFramedValue(time, pos))
                sclList.append(NoeKeyFramedValue(time, scl))
            
            id = getBoneIndex(m_strBone, bones)
            if id == -1: 
                id = len(bones)
            bones.append(NoeBone(id,m_strBone,NoeMat43()))
            #---------
            keyBone = NoeKeyFramedBone(id)#getBoneIndex(m_strBone, bones)
            keyBone.setRotation(rotList)
            keyBone.setTranslation(posList)
            keyBone.setScale(sclList, noesis.NOEKF_SCALE_VECTOR_3)
            animBones.append(keyBone)
            #---------
            
            m_cMatrixKeys = bs.readInt()
            dwGabageData = bs.readInt()#m_strBone.length() + VERSION
            m_cScaleKeys = bs.readInt()
            
            print(id, m_strBone, VERSION)
        if ver == 259: bs.readInt()
    
    anim = NoeKeyFramedAnim('anim_0', bones, animBones, 30)
    anims.append(anim)
    return 1
        
def BinMat43(bs):
    scl = NoeVec3.fromBytes(bs.readBytes(12))
    pos = NoeVec3.fromBytes(bs.readBytes(12))
    rot = (DecompressionQuaternion([bs.readUInt(),bs.readUInt()])).transpose()
    #-----------------swapHandedness
    mat = rot.toMat43()
    mat[3] = pos
    mat = mat.swapHandedness(2)
    rot = mat.toQuat()
    pos = mat[3]
    #--------------------------------
    return rot, pos, scl
    
def BinMat44(bs):
    unk = NoeVec3.fromBytes(bs.readBytes(12))
    mat = NoeMat44.fromBytes(bs.readBytes(64)).toMat43()
    #-----------------swapHandedness
    mat = mat.swapHandedness(2)
    rot = mat.toQuat()
    pos = mat[3]
    scl = NoeVec3()
    scl[0] = mat[0][0]
    scl[1] = mat[1][1]
    scl[2] = mat[2][2]
    #--------------------------------
    return rot, pos, scl
        
def DecompressionQuaternion(t):
    vOut = NoeQuat()

    nTemp = t[0] >> 16
    nTemp -= 32767
    vOut[0] = nTemp * 0.000030517578125

    nTemp = t[0] & 0xffff
    nTemp -= 32767
    vOut[1] = nTemp * 0.000030517578125

    nTemp = t[1] >> 16
    nTemp -= 32767
    vOut[2] = nTemp * 0.000030517578125

    nTemp = t[1] & 0xffff
    vOut[3] = nTemp * 0.000015259021896
    return vOut
        
def getBoneIndex(name, bones):
    for bone in bones:
        if name == bone.name:
            return bone.index
    return -1
    
def load_100(bs):#256
    animBones = []
    
    while bs.getOffset() < bs.getSize():#one?
        dwNumAni = bs.readInt()
        for x in range(dwNumAni):
            ver = bs.readInt()
            m_cPositionKeys = bs.readInt()
            m_cRotateKeys = bs.readInt()
            m_cScaleKeys = bs.readInt()
            m_cMatrixKeys = bs.readInt()
            #-------------
            rotList = []
            posList = []
            sclList = []
            #-------------
            for x in range(m_cMatrixKeys):
                time = bs.readInt()/4800
                rot, pos, scl = BinMat44(bs)
                rotList.append(NoeKeyFramedValue(time, rot))
                posList.append(NoeKeyFramedValue(time, pos))
                #sclList.append(NoeKeyFramedValue(time, scl))
            
            m_strBone = noeStrFromBytes(bs.readBytes(bs.readInt()))
            
            id = getBoneIndex(m_strBone, bones)
            if id == -1: 
                id = len(bones)
            bones.append(NoeBone(id,m_strBone,NoeMat43()))
            #---------
            keyBone = NoeKeyFramedBone(id)
            keyBone.setRotation(rotList)
            keyBone.setTranslation(posList)
            #keyBone.setScale(sclList, noesis.NOEKF_SCALE_VECTOR_3)
            animBones.append(keyBone)
            #---------
    
    anim = NoeKeyFramedAnim('anim_0', bones, animBones, 30)
    anims.append(anim)
    return 1
   
def load_101(bs):#257
    animBones = []
    
    while bs.getOffset() < bs.getSize():#two?
        dwNumAni = bs.readInt()
        for x in range(dwNumAni):
            ver = bs.readInt()
            m_cPositionKeys = bs.readInt()
            m_cRotateKeys = bs.readInt()
            m_cScaleKeys = bs.readInt()
            m_cMatrixKeys = bs.readInt()
            m_cQuatPosKeys = bs.readInt()
            #-------------
            rotList = []
            posList = []
            sclList = []
            #-------------
            for x in range(m_cQuatPosKeys):
                time = bs.readInt()/4800
                rot, pos, scl = BinMat43(bs)
                rotList.append(NoeKeyFramedValue(time, rot))
                posList.append(NoeKeyFramedValue(time, pos))
                sclList.append(NoeKeyFramedValue(time, scl))
            
            m_strBone = noeStrFromBytes(bs.readBytes(bs.readInt()))
            
            id = getBoneIndex(m_strBone, bones)
            if id == -1: 
                id = len(bones)
            bones.append(NoeBone(id,m_strBone,NoeMat43()))
            #---------
            keyBone = NoeKeyFramedBone(id)
            keyBone.setRotation(rotList)
            keyBone.setTranslation(posList)
            keyBone.setScale(sclList, noesis.NOEKF_SCALE_VECTOR_3)
            animBones.append(keyBone)
            #---------
    
    anim = NoeKeyFramedAnim('anim_0', bones, animBones, 30)
    anims.append(anim)
    return 1

def load_102(bs):#258
    animBones = []
    
    while bs.getOffset() < bs.getSize():#two?
        dwNumAni = bs.readInt()
        for x in range(dwNumAni):
            ver = bs.readInt()
            m_strBone = noeStrFromBytes(bs.readBytes(bs.readInt()))
            m_cRotateKeys = bs.readInt()
            m_cPositionKeys = bs.readInt()
            dwGabageValue = bs.readInt()
            m_cQuatPosKeys = bs.readInt()
            #-------------
            rotList = []
            posList = []
            sclList = []
            #-------------
            for x in range(m_cQuatPosKeys):
                time = bs.readInt()/4800
                rot, pos, scl = BinMat43(bs)
                rotList.append(NoeKeyFramedValue(time, rot))
                posList.append(NoeKeyFramedValue(time, pos))
                sclList.append(NoeKeyFramedValue(time, scl))
                
            id = getBoneIndex(m_strBone, bones)
            if id == -1: 
                id = len(bones)
            bones.append(NoeBone(id,m_strBone,NoeMat43()))
            #---------
            keyBone = NoeKeyFramedBone(id)
            keyBone.setRotation(rotList)
            keyBone.setTranslation(posList)
            keyBone.setScale(sclList, noesis.NOEKF_SCALE_VECTOR_3)
            animBones.append(keyBone)
            #---------
            
            dwGabageValue = bs.readInt()
            m_cMatrixKeys = bs.readInt()
            m_cScaleKeys = bs.readInt()
    
    anim = NoeKeyFramedAnim('anim_0', bones, animBones, 30)
    anims.append(anim)
    return 1

def load_103(bs):#259
    animBones = []
    
    while bs.getOffset() < bs.getSize():#two?
        dwNumAni = bs.readInt()
        for x in range(dwNumAni):
            ver = bs.readInt()
            m_strBone = noeStrFromBytes(bs.readBytes(bs.readInt()))
            m_cRotateKeys = bs.readInt()
            dwGabageValue = bs.readInt()
            m_cPositionKeys = bs.readInt()
            m_cQuatPosKeys = bs.readInt()
            #-------------
            rotList = []
            posList = []
            sclList = []
            #-------------
            for x in range(m_cQuatPosKeys):
                time = bs.readInt()/4800
                rot, pos, scl = BinMat43(bs)
                rotList.append(NoeKeyFramedValue(time, rot))
                posList.append(NoeKeyFramedValue(time, pos))
                sclList.append(NoeKeyFramedValue(time, scl))
                
            id = getBoneIndex(m_strBone, bones)
            if id == -1: 
                id = len(bones)
            bones.append(NoeBone(id,m_strBone,NoeMat43()))
            #---------
            keyBone = NoeKeyFramedBone(id)
            keyBone.setRotation(rotList)
            keyBone.setTranslation(posList)
            keyBone.setScale(sclList, noesis.NOEKF_SCALE_VECTOR_3)
            animBones.append(keyBone)
            #---------
            
            m_cMatrixKeys = bs.readInt()
            dwGabageValue = bs.readInt()
            m_cScaleKeys = bs.readInt()
            
        dwGarbage = bs.readInt()
        
    anim = NoeKeyFramedAnim('anim_0', bones, animBones, 30)
    anims.append(anim)
    return 1

def load_104(bs):#260
    animBones = []
    
    while bs.getOffset() < bs.getSize():#three?
        dwNumAni = bs.readInt()
        for x in range(dwNumAni):
            ver = bs.readInt()
            m_strBone = noeStrFromBytes(bs.readBytes(bs.readInt()))
            m_cRotateKeys = bs.readInt()
            dwGabageValue = bs.readInt()
            m_cPositionKeys = bs.readInt()
            m_cQuatPosKeys = bs.readInt()
            #-------------
            rotList = []
            posList = []
            sclList = []
            #-------------
            for x in range(m_cQuatPosKeys):
                time = bs.readInt()/4800
                rot, pos, scl = BinMat43(bs)
                rotList.append(NoeKeyFramedValue(time, rot))
                posList.append(NoeKeyFramedValue(time, pos))
                sclList.append(NoeKeyFramedValue(time, scl))
                
            id = getBoneIndex(m_strBone, bones)
            if id == -1: 
                id = len(bones)
            bones.append(NoeBone(id,m_strBone,NoeMat43()))
            #---------
            keyBone = NoeKeyFramedBone(id)
            keyBone.setRotation(rotList)
            keyBone.setTranslation(posList)
            keyBone.setScale(sclList, noesis.NOEKF_SCALE_VECTOR_3)
            animBones.append(keyBone)
            #---------
            
            m_cMatrixKeys = bs.readInt()
            dwGabageValue = bs.readInt()
            m_cScaleKeys = bs.readInt()
    
    anim = NoeKeyFramedAnim('anim_0', bones, animBones, 30)
    anims.append(anim)
    return 1
