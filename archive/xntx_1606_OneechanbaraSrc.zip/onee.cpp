
#include "onee.h"

//+----------------------------------------------------------------> cOneechan()

cOneechan::cOneechan()
{
}

//+----------------------------------------------------------------> Delete()

void cOneechan::Delete()
{
	if(m_pModel)
	{
		for(unsigned int a = 0; a < m_uiModelNum; a++)
		{
			for(unsigned int b = 0; b < m_pModel[a].uiObjectNum; b++)
			{
				if(m_pModel[a].pObject[b].pV36)		delete[] m_pModel[a].pObject[b].pV36;
				if(m_pModel[a].pObject[b].pV60)		delete[] m_pModel[a].pObject[b].pV60;
				if(m_pModel[a].pObject[b].pV84)		delete[] m_pModel[a].pObject[b].pV84;
				if(m_pModel[a].pObject[b].pV108)	delete[] m_pModel[a].pObject[b].pV108;
				if(m_pModel[a].pObject[b].pIndex)	delete[] m_pModel[a].pObject[b].pIndex;
			}
			m_pModel[a].pObject.clear();
		}
		delete[] m_pModel;
		m_pModel = NULL;
	}

	if(m_pTexture)
	{
		delete[] m_pTexture;
		m_pTexture = NULL;
	}
	if(m_pBoneGroup)
	{
		for(unsigned int a = 0; a < m_uiBoneGroupNum; a++)
		{
			if(m_pBoneGroup[a].pBoneId)
			{
				delete[] m_pBoneGroup[a].pBoneId;
				m_pBoneGroup[a].pBoneId = NULL;
			}
		}
		delete[] m_pBoneGroup;
		m_pBoneGroup = NULL;
	}
	if(m_pBone)
	{
		for(unsigned int a = 0; a < m_uiBoneNum; a++)
		{
			if(m_pBone[a].uiChildNum && m_pBone[a].pChild)
			{
				delete[] m_pBone[a].pChild;
				m_pBone[a].pChild = NULL;
			}
		}
		delete[] m_pBone;
		m_pBone = NULL;
	}
}

//+----------------------------------------------------------------> Load()

bool cOneechan::Load(const char *strOneechan)
{
	// open the file in question
	FILE *pFile = fopen(strOneechan, "rb");
	if(!pFile)
	{
		printf("Can't open file [%s] !\n", strOneechan);
		return false;
	}

	// read the header and check the signature
	fread(this, 32, 1, pFile);
	if(m_uiTag != 0x20464754)
	{
		printf("Invalid TGF file !!\n");
		return false;
	}
	Moto2Intel(m_uiModelNum);
	Moto2Intel(m_uiInfoOffset);
	Moto2Intel(m_uiTextureOffset);
	Moto2Intel(m_uiBoneNum);
	Moto2Intel(m_uiBoneOffset);
	Moto2Intel(m_uiBoneGroupOffset);

	// read the models info
	m_pModel = new cOneechanModel[m_uiModelNum];
	for(unsigned int a = 0; a < m_uiModelNum; a++)
	{
		fseek(pFile, 4, SEEK_CUR);
		fread(&m_pModel[a].uiOffset, 4, 1, pFile);
		fseek(pFile, 4, SEEK_CUR);
		Moto2Intel(m_pModel[a].uiOffset);
		m_pModel[a].uiObjectNum = 0;
	}

	// get the size of each model
	unsigned int a = 0;
	unsigned int *pSize = new unsigned int[m_uiModelNum];
	for(a = 0; a < m_uiModelNum - 1; a++)
		pSize[a] = m_pModel[a + 1].uiOffset - m_pModel[a].uiOffset;
	pSize[a] = m_uiTextureOffset - m_pModel[a].uiOffset;

	// go through all the models and read them
	for(unsigned int a = 0; a < m_uiModelNum; a++)
	{
		unsigned int uiModelSize = 0;
		fseek(pFile, m_pModel[a].uiOffset, SEEK_SET);
		cOneechanObject obj;
		while(int(pSize[a] - uiModelSize) > 100)
		{
			printf("object_%d_%d\t", a, m_pModel[a].uiObjectNum);
			if(!ReadObject(pFile, obj))
				return false;
			uiModelSize += obj.uiBytesRead;
			m_pModel[a].pObject.push_back(obj);
			m_pModel[a].uiObjectNum++;
		}
	}
	delete[] pSize;

	// read the texture info
	fseek(pFile, m_uiTextureOffset, SEEK_SET);
	fread(&m_uiTextureNum, 4, 1, pFile);
	Moto2Intel(m_uiTextureNum);
	m_pTexture = new cOneechanTexture[m_uiTextureNum];
	for(unsigned int a = 0; a < m_uiTextureNum; a++)
	{
		fread(&m_pTexture[a].uiOffset, 4, 1, pFile);
		Moto2Intel(m_pTexture[a].uiOffset);
		fseek(pFile, 4, SEEK_CUR);
	}
	for(unsigned int a = 0; a < m_uiTextureNum; a++)
	{
		fseek(pFile, m_pTexture[a].uiOffset, SEEK_SET);
		fread(m_pTexture[a].strName, 24, 1, pFile);
		//printf("%d\t%s\n", a, m_pTexture[a].strName);
	}

	// there another chunk here, might be materials, list-like that ends up with 0xFFFFFFFF

	// read the bones
	m_pBone = new cOneechanBone[m_uiBoneNum];
	fseek(pFile, m_uiBoneOffset, SEEK_SET);
	fread(m_pBone, sizeof(cOneechanBone), m_uiBoneNum, pFile);
	for(unsigned int a = 0; a < m_uiBoneNum; a++)
	{
		Moto2Intel(m_pBone[a].uiParent);
		Moto2Intel(m_pBone[a].mTransform._11);
		Moto2Intel(m_pBone[a].mTransform._12);
		Moto2Intel(m_pBone[a].mTransform._13);
		Moto2Intel(m_pBone[a].mTransform._14);
		Moto2Intel(m_pBone[a].mTransform._21);
		Moto2Intel(m_pBone[a].mTransform._22);
		Moto2Intel(m_pBone[a].mTransform._23);
		Moto2Intel(m_pBone[a].mTransform._24);
		Moto2Intel(m_pBone[a].mTransform._31);
		Moto2Intel(m_pBone[a].mTransform._32);
		Moto2Intel(m_pBone[a].mTransform._33);
		Moto2Intel(m_pBone[a].mTransform._34);
		Moto2Intel(m_pBone[a].mTransform._41);
		Moto2Intel(m_pBone[a].mTransform._42);
		Moto2Intel(m_pBone[a].mTransform._43);
		Moto2Intel(m_pBone[a].mTransform._44);
	}

	// read the bone groups
	fseek(pFile, m_uiBoneGroupOffset, SEEK_SET);
	fread(&m_uiBoneGroupNum, 4, 1, pFile);
	Moto2Intel(m_uiBoneGroupNum);
	m_pBoneGroup = new cOneechanBoneGroup[m_uiBoneGroupNum];
	for(unsigned int a = 0; a < m_uiBoneGroupNum; a++)
	{
		fread(&m_pBoneGroup[a].uiBoneNum, 4, 1, pFile);
		fread(&m_pBoneGroup[a].uiOffset, 4, 1, pFile);

		Moto2Intel(m_pBoneGroup[a].uiBoneNum);
		Moto2Intel(m_pBoneGroup[a].uiOffset);
	}
	for(unsigned int a = 0; a < m_uiBoneGroupNum; a++)
	{
		m_pBoneGroup[a].pBoneId = new WORD[m_pBoneGroup[a].uiBoneNum];
		fseek(pFile, m_pBoneGroup[a].uiOffset, SEEK_SET);
		fread(m_pBoneGroup[a].pBoneId, 2, m_pBoneGroup[a].uiBoneNum, pFile);
		for(unsigned int b = 0; b < m_pBoneGroup[a].uiBoneNum; b++)
			Moto2Intel(m_pBoneGroup[a].pBoneId[b]);
	}

	fclose(pFile);
	return true;
}

//+----------------------------------------------------------------> ReadModel()

bool cOneechan::ReadObject(FILE *pFile, cOneechanObject &p)
{
	// read the different counts this way
	unsigned int uiFlag = 0;
	fread(&uiFlag, 4, 1, pFile);
	Moto2Intel(uiFlag);
	p.uiBytesRead = 4;
	if(!uiFlag)
	{
		// if the object has textures then read their Id's, otherwise, this object will take the precedent's id's
		// except for iTex3
		unsigned int uiCount = 0;
		fread(&uiCount, 4, 1, pFile);
		Moto2Intel(uiCount);
		fseek(pFile, 4, SEEK_CUR);
		if(uiCount)
		{
			fread(&p.iTex0, 4, 1, pFile);
			Moto2Intel(p.iTex0);
			if(uiCount > 1)
			{
				fread(&p.iTex1, 4, 1, pFile);
				Moto2Intel(p.iTex1);
				if(uiCount > 2)
				{
					fread(&p.iTex2, 4, 1, pFile);
					Moto2Intel(p.iTex2);
					if(uiCount > 3)
					{
						fread(&p.iTex3, 4, 1, pFile);
						Moto2Intel(p.iTex3);
					}
					else
						p.iTex3 = -1;
				}
			}
		}
		fseek(pFile, 4, SEEK_CUR);
		//fseek(pFile, 8 + (uiCount * 4), SEEK_CUR);
		p.uiBytesRead += 12 + (uiCount * 4);
	}

	unsigned int zz = ftell(pFile);
	zz = 0;

	fread(&p.uiFaceNum, 4, 1, pFile);
	fread(&p.uiVertexSize, 4, 1, pFile);
	Moto2Intel(p.uiFaceNum);
	Moto2Intel(p.uiVertexSize);
	p.uiBytesRead += 8;

	fseek(pFile, 4, SEEK_CUR);
	fread(&p.uiGroupId, 4, 1, pFile);
	fread(&p.uiVertexNum, 4, 1, pFile);
	Moto2Intel(p.uiGroupId);
	Moto2Intel(p.uiVertexNum);
	p.uiBytesRead += 12;

	fseek(pFile, 12, SEEK_CUR);
	fread(&p.uiIndexNum, 4, 1, pFile);
	Moto2Intel(p.uiIndexNum);
	p.uiBytesRead += 16;

	fseek(pFile, 12, SEEK_CUR);
	p.uiBytesRead += 12;
	printf("stride: %d\tverts: %d\tindices: %d\n", p.uiVertexSize, p.uiVertexNum, p.uiIndexNum);

	// read the vertex data
	p.pV36 = NULL;
	p.pV60 = NULL;
	p.pV84 = NULL;
	p.pV108 = NULL;
	switch(p.uiVertexSize)
	{
	case 36:
		{
			p.pV36 = new cOneechanVertex36[p.uiVertexNum];
			fread(p.pV36, 36, p.uiVertexNum, pFile);
			p.uiBytesRead += 36 * p.uiVertexNum;
			for(unsigned int a = 0; a < p.uiVertexNum; a++)
			{
				Moto2Intel(p.pV36[a].x);
				Moto2Intel(p.pV36[a].y);
				Moto2Intel(p.pV36[a].z);
				Moto2Intel(p.pV36[a].nx);
				Moto2Intel(p.pV36[a].ny);
				Moto2Intel(p.pV36[a].nz);
				Moto2Intel(p.pV36[a].u0);
				Moto2Intel(p.pV36[a].v0);
				Moto2Intel(p.pV36[a].fWeight);
				Moto2Intel(p.pV36[a].uiBoneId);
			}
		}
		break;

	case 60:
		{
			p.pV60 = new cOneechanVertex60[p.uiVertexNum];
			fread(p.pV60, 60, p.uiVertexNum, pFile);
			p.uiBytesRead += 60 * p.uiVertexNum;
			for(unsigned int a = 0; a < p.uiVertexNum; a++)
			{
				Moto2Intel(p.pV60[a].x);
				Moto2Intel(p.pV60[a].y);
				Moto2Intel(p.pV60[a].z);
				Moto2Intel(p.pV60[a].nx);
				Moto2Intel(p.pV60[a].ny);
				Moto2Intel(p.pV60[a].nz);
				Moto2Intel(p.pV60[a].u0);
				Moto2Intel(p.pV60[a].v0);
				Moto2Intel(p.pV60[a].fWeight[0]);
				Moto2Intel(p.pV60[a].fWeight[1]);
				Moto2Intel(p.pV60[a].uiBoneId[0]);
				Moto2Intel(p.pV60[a].uiBoneId[1]);
			}
		}
		break;
		
	case 84:
		{
			p.pV84 = new cOneechanVertex84[p.uiVertexNum];
			fread(p.pV84, 84, p.uiVertexNum, pFile);
			p.uiBytesRead += 84 * p.uiVertexNum;
			for(unsigned int a = 0; a < p.uiVertexNum; a++)
			{
				Moto2Intel(p.pV84[a].x);
				Moto2Intel(p.pV84[a].y);
				Moto2Intel(p.pV84[a].z);
				Moto2Intel(p.pV84[a].nx);
				Moto2Intel(p.pV84[a].ny);
				Moto2Intel(p.pV84[a].nz);
				Moto2Intel(p.pV84[a].u0);
				Moto2Intel(p.pV84[a].v0);
				Moto2Intel(p.pV84[a].fWeight[0]);
				Moto2Intel(p.pV84[a].fWeight[1]);
				Moto2Intel(p.pV84[a].fWeight[2]);
				Moto2Intel(p.pV84[a].uiBoneId[0]);
				Moto2Intel(p.pV84[a].uiBoneId[1]);
				Moto2Intel(p.pV84[a].uiBoneId[2]);
			}
		}
		break;

	case 108:
		{
			p.pV108 = new cOneechanVertex108[p.uiVertexNum];
			fread(p.pV108, 108, p.uiVertexNum, pFile);
			p.uiBytesRead += 108 * p.uiVertexNum;
			for(unsigned int a = 0; a < p.uiVertexNum; a++)
			{
				Moto2Intel(p.pV108[a].x);
				Moto2Intel(p.pV108[a].y);
				Moto2Intel(p.pV108[a].z);

				Moto2Intel(p.pV108[a].nx);
				Moto2Intel(p.pV108[a].ny);
				Moto2Intel(p.pV108[a].nz);

				Moto2Intel(p.pV108[a].fWeight[0]);
				Moto2Intel(p.pV108[a].fWeight[1]);
				Moto2Intel(p.pV108[a].fWeight[2]);
				Moto2Intel(p.pV108[a].fWeight[3]);

				Moto2Intel(p.pV108[a].uiBoneId[0]);
				Moto2Intel(p.pV108[a].uiBoneId[1]);
				Moto2Intel(p.pV108[a].uiBoneId[2]);
				Moto2Intel(p.pV108[a].uiBoneId[3]);

				Moto2Intel(p.pV108[a].u0);
				Moto2Intel(p.pV108[a].v0);
			}
		}
		break;

	default:
		{
			printf("Unknown vertex size [%d] at [%d] !!\n", p.uiVertexSize, ftell(pFile));
			return false;
		}
	}

	// read the index data
	p.pIndex = new WORD[p.uiIndexNum];
	fread(p.pIndex, 2, p.uiIndexNum, pFile);
	p.uiBytesRead += 2 * p.uiIndexNum;
	for(unsigned int a = 0; a < p.uiIndexNum; a++)
		Moto2Intel(p.pIndex[a]);

	// pad to x4
	unsigned int uiSkip = p.uiIndexNum / 2;
	uiSkip = p.uiIndexNum - (uiSkip * 2);
	fseek(pFile, uiSkip * 2, SEEK_CUR);
	p.uiBytesRead += uiSkip * 2;

	return true;
}

//+----------------------------------------------------------------> Export()

bool cOneechan::Export(const char *strOneechan)
{
	FILE *pFile = fopen(strOneechan, "wt");
	unsigned int uiIndex = 1;

	//// prepare the matrices
	//m_pBone[0].uiParent = -1;
	//for(unsigned int a = 0; a < m_uiBoneNum; a++)
	//{
	//	if(m_pBone[a].uiParent != -1)
	//		D3DXMatrixMultiply(&m_pBone[a].mTransform, &m_pBone[m_pBone[a].uiParent].mTransform, &m_pBone[a].mTransform);
	//}

	for(unsigned int a = 0; a < m_uiModelNum; a++)
	{
		for(unsigned int b = 0; b < m_pModel[a].uiObjectNum; b++)
		{
			D3DXVECTOR3 *pVertex = new D3DXVECTOR3[m_pModel[a].pObject[b].uiVertexNum];
			D3DXVECTOR2 *pTex = new D3DXVECTOR2[m_pModel[a].pObject[b].uiVertexNum];
			switch(m_pModel[a].pObject[b].uiVertexSize)
			{
			case 36:
				{
					for(unsigned int c = 0; c < m_pModel[a].pObject[b].uiVertexNum; c++)
					{
						WORD pV[3] = {m_pModel[a].pObject[b].pV36[c].x, m_pModel[a].pObject[b].pV36[c].y, m_pModel[a].pObject[b].pV36[c].z};
						D3DXFLOAT16 *pV16 = (D3DXFLOAT16*)pV;
						float pVF[3];
						D3DXFloat16To32Array(pVF, pV16, 3);

						// apply skinning
						D3DXVECTOR3 v3 = D3DXVECTOR3(pVF[0], pVF[1], pVF[2]);
						unsigned int uiRealBoneId = m_pBoneGroup[m_pModel[a].pObject[b].uiGroupId].pBoneId[m_pModel[a].pObject[b].pV36[c].uiBoneId];
						D3DXMATRIX mat = m_pBone[uiRealBoneId].mTransform;
						D3DXVECTOR3 v3s;
						pVertex[c].x = v3.x + mat._41;
						pVertex[c].y = v3.y + mat._42;
						pVertex[c].z = v3.z + mat._43;
					}
					for(unsigned int c = 0; c < m_pModel[a].pObject[b].uiVertexNum; c++)
					{
						WORD pV[2] = {m_pModel[a].pObject[b].pV36[c].u0, m_pModel[a].pObject[b].pV36[c].v0};
						D3DXFLOAT16 *pV16 = (D3DXFLOAT16*)pV;
						float pVF[2];
						D3DXFloat16To32Array(pVF, pV16, 2);
						pTex[c] = D3DXVECTOR2(pVF[0], pVF[1]);
					}
					//for(unsigned int b = 0; b < m_pModel[a].uiVertexNum; b++)
					//	fprintf(pFile, "v %f %f %f\n", m_pModel[a].pV36[b].x * SCALE, m_pModel[a].pV36[b].y * SCALE, m_pModel[a].pV36[b].z * SCALE);
				}
				break;

			case 60:
				{
					for(unsigned int c = 0; c < m_pModel[a].pObject[b].uiVertexNum; c++)
					{
						WORD pV[3] = {m_pModel[a].pObject[b].pV60[c].x, m_pModel[a].pObject[b].pV60[c].y, m_pModel[a].pObject[b].pV60[c].z};
						D3DXFLOAT16 *pV16 = (D3DXFLOAT16*)pV;
						float pVF[3];
						D3DXFloat16To32Array(pVF, pV16, 3);

						// apply skinning
						D3DXVECTOR3 v3 = D3DXVECTOR3(pVF[0], pVF[1], pVF[2]);
						
						unsigned int uiRealBoneId0 = m_pBoneGroup[m_pModel[a].pObject[b].uiGroupId].pBoneId[m_pModel[a].pObject[b].pV60[c].uiBoneId[0]];
						unsigned int uiRealBoneId1 = m_pBoneGroup[m_pModel[a].pObject[b].uiGroupId].pBoneId[m_pModel[a].pObject[b].pV60[c].uiBoneId[1]];

						float fWeight0 = m_pModel[a].pObject[b].pV60[c].fWeight[0];
						float fWeight1 = m_pModel[a].pObject[b].pV60[c].fWeight[1];

						D3DXMATRIX mat0 = m_pBone[uiRealBoneId0].mTransform;
						D3DXMATRIX mat1 = m_pBone[uiRealBoneId1].mTransform;

						D3DXVECTOR3 v3s;
						pVertex[c].x = (fWeight0 * mat0._41) +  (fWeight1 * mat1._41);
						pVertex[c].y = (fWeight0 * mat0._42) +  (fWeight1 * mat1._42);
						pVertex[c].z = (fWeight0 * mat0._43) +  (fWeight1 * mat1._43);
					}
					for(unsigned int c = 0; c < m_pModel[a].pObject[b].uiVertexNum; c++)
					{
						WORD pV[2] = {m_pModel[a].pObject[b].pV60[c].u0, m_pModel[a].pObject[b].pV60[c].v0};
						D3DXFLOAT16 *pV16 = (D3DXFLOAT16*)pV;
						float pVF[2];
						D3DXFloat16To32Array(pVF, pV16, 2);
						pTex[c] = D3DXVECTOR2(pVF[0], pVF[1]);
					}
					//for(unsigned int b = 0; b < m_pModel[a].uiVertexNum; b++)
					//	fprintf(pFile, "v %f %f %f\n", m_pModel[a].pV60[b].x * SCALE, m_pModel[a].pV60[b].y * SCALE, m_pModel[a].pV60[b].z * SCALE);
				}
				break;


			case 84:
				{
					for(unsigned int c = 0; c < m_pModel[a].pObject[b].uiVertexNum; c++)
					{
						WORD pV[3] = {m_pModel[a].pObject[b].pV84[c].x, m_pModel[a].pObject[b].pV84[c].y, m_pModel[a].pObject[b].pV84[c].z};
						D3DXFLOAT16 *pV16 = (D3DXFLOAT16*)pV;
						float pVF[3];
						D3DXFloat16To32Array(pVF, pV16, 3);

						// apply skinning
						D3DXVECTOR3 v3 = D3DXVECTOR3(pVF[0], pVF[1], pVF[2]);
						
						unsigned int uiRealBoneId0 = m_pBoneGroup[m_pModel[a].pObject[b].uiGroupId].pBoneId[m_pModel[a].pObject[b].pV84[c].uiBoneId[0]];
						unsigned int uiRealBoneId1 = m_pBoneGroup[m_pModel[a].pObject[b].uiGroupId].pBoneId[m_pModel[a].pObject[b].pV84[c].uiBoneId[1]];
						unsigned int uiRealBoneId2 = m_pBoneGroup[m_pModel[a].pObject[b].uiGroupId].pBoneId[m_pModel[a].pObject[b].pV84[c].uiBoneId[2]];

						float fWeight0 = m_pModel[a].pObject[b].pV84[c].fWeight[0];
						float fWeight1 = m_pModel[a].pObject[b].pV84[c].fWeight[1];
						float fWeight2 = m_pModel[a].pObject[b].pV84[c].fWeight[2];

						D3DXMATRIX mat0 = m_pBone[uiRealBoneId0].mTransform;
						D3DXMATRIX mat1 = m_pBone[uiRealBoneId1].mTransform;
						D3DXMATRIX mat2 = m_pBone[uiRealBoneId2].mTransform;

						D3DXVECTOR3 v3s;
						//pVertex[c].x = (fWeight0 * mat0._41) + (fWeight1 * mat1._41) + (fWeight2 * mat2._41);
						//pVertex[c].x = (fWeight0 * mat0._41) + (fWeight1 * mat1._41) + (fWeight2 * mat2._41);
						//pVertex[c].x = (fWeight0 * mat0._41) + (fWeight1 * mat1._41) + (fWeight2 * mat2._41);
						pVertex[c].x = v3.x;
						pVertex[c].y = v3.y;
						pVertex[c].z = v3.z;
					}
					for(unsigned int c = 0; c < m_pModel[a].pObject[b].uiVertexNum; c++)
					{
						WORD pV[2] = {m_pModel[a].pObject[b].pV84[c].u0, m_pModel[a].pObject[b].pV84[c].v0};
						D3DXFLOAT16 *pV16 = (D3DXFLOAT16*)pV;
						float pVF[2];
						D3DXFloat16To32Array(pVF, pV16, 2);
						pTex[c] = D3DXVECTOR2(pVF[0], pVF[1]);
					}
					//for(unsigned int b = 0; b < m_pModel[a].uiVertexNum; b++)
					//	fprintf(pFile, "v %f %f %f\n", m_pModel[a].pV84[b].x * SCALE, m_pModel[a].pV84[b].y * SCALE, m_pModel[a].pV84[b].z * SCALE);
				}
				break;


			case 108:
				{
					for(unsigned int c = 0; c < m_pModel[a].pObject[b].uiVertexNum; c++)
					{
						WORD pV[3] = {m_pModel[a].pObject[b].pV108[c].x, m_pModel[a].pObject[b].pV108[c].y, m_pModel[a].pObject[b].pV108[c].z};
						D3DXFLOAT16 *pV16 = (D3DXFLOAT16*)pV;
						float pVF[3];
						D3DXFloat16To32Array(pVF, pV16, 3);
						pVertex[c] = D3DXVECTOR3(pVF[0], pVF[1], pVF[2]);
					}
					for(unsigned int c = 0; c < m_pModel[a].pObject[b].uiVertexNum; c++)
					{
						WORD pV[2] = {m_pModel[a].pObject[b].pV108[c].u0, m_pModel[a].pObject[b].pV108[c].v0};
						D3DXFLOAT16 *pV16 = (D3DXFLOAT16*)pV;
						float pVF[2];
						D3DXFloat16To32Array(pVF, pV16, 2);
						pTex[c] = D3DXVECTOR2(pVF[0], pVF[1]);
					}
					//for(unsigned int b = 0; b < m_pModel[a].uiVertexNum; b++)
					//	fprintf(pFile, "v %f %f %f\n", m_pModel[a].pV108[b].x * SCALE, m_pModel[a].pV108[b].y * SCALE, m_pModel[a].pV108[b].z * SCALE);
				}
				break;
			}

			//if(m_pModel[a].pObject[b].uiVertexSize == 108)
			//{
			for(unsigned int c = 0; c < m_pModel[a].pObject[b].uiVertexNum; c++)
				fprintf(pFile, "v %f %f %f\n", pVertex[c].x, pVertex[c].y, pVertex[c].z);

			for(unsigned int c = 0; c < m_pModel[a].pObject[b].uiVertexNum; c++)
				fprintf(pFile, "vt %f %f %f\n", pTex[c].x, 1.0f - pTex[c].y, 0.5f);

			fprintf(pFile, "g hoho_stride_%d_%d_%d_id:%d\n", m_pModel[a].pObject[b].uiVertexSize, a, b, m_pModel[a].pObject[b].uiGroupId);
			bool bBackface = true;
			for(unsigned int c = 0; c < m_pModel[a].pObject[b].uiIndexNum; c += 3)
			{
				WORD i0 = m_pModel[a].pObject[b].pIndex[c];
				WORD i1 = m_pModel[a].pObject[b].pIndex[c + 1];
				WORD i2 = m_pModel[a].pObject[b].pIndex[c + 2];
				if(bBackface)
					fprintf(pFile, "f %d/%d %d/%d %d/%d\n", i0 + uiIndex, i0 + uiIndex, i2 + uiIndex,i2 + uiIndex, i1 + uiIndex, i1 + uiIndex);
				else
					fprintf(pFile, "f %d/%d %d/%d %d/%d\n", i0 + uiIndex, i0 + uiIndex, i1 + uiIndex, i1 + uiIndex, i2 + uiIndex,i2 + uiIndex);
				bBackface = !bBackface;
			}
			fprintf(pFile, "g\n\n");
			
			uiIndex += m_pModel[a].pObject[b].uiVertexNum;
			//}
			delete[] pVertex;
		}
	}
	fclose(pFile);

	// export bones
	pFile = fopen("d:/out.ms", "wt");
	m_pBone[0].uiParent = -1;
	//for(unsigned int a = 0; a < m_uiBoneNum; a++)
	//{
	//	if(m_pBone[a].uiParent != -1)
	//		D3DXMatrixMultiply(&m_pBone[a].mTransform, &m_pBone[m_pBone[a].uiParent].mTransform, &m_pBone[a].mTransform);
	//}

	for(unsigned int a = 0; a < m_uiBoneNum; a++)
	{
		float x = m_pBone[a].mTransform._41;
		float y = m_pBone[a].mTransform._42;
		float z = m_pBone[a].mTransform._43;

		fprintf(pFile, "newbone%d = point()\n", a);
		fprintf(pFile, "newbone%d.pos = [%f,%f,%f]\n", a, x, -z, y);
		fprintf(pFile, "newbone%d.name = \"bone_%d\"\n", a, a);
		fprintf(pFile, "newbone%d.centermarker = true\n", a);
		fprintf(pFile, "newbone%d.box = true\n", a);
		fprintf(pFile, "newbone%d.axistripod = false\n", a);
		fprintf(pFile, "newbone%d.cross = false\n", a);
		fprintf(pFile, "newbone%d.size = 5\n", a);

		if(m_pBone[a].uiParent != -1)
			fprintf(pFile, "newbone%d.parent = newbone%d\n", a, m_pBone[a].uiParent);
	}

	//fclose(pFile);
	return true;
}

//+----------------------------------------------------------------> Export:s()

bool cOneechan::ExportMs(const char *strOneechan)
{
	FILE *pFile = fopen(strOneechan, "wt");
	fprintf(pFile, "disableSceneRedraw()\n");
	unsigned int uiIndex = 1;

	// export bones
	m_pBone[0].uiParent = -1;
	for(unsigned int a = 0; a < m_uiBoneNum; a++)
	{
		if(m_pBone[a].uiParent != -1)
			D3DXMatrixMultiply(&m_pBone[a].mTransform, &m_pBone[m_pBone[a].uiParent].mTransform, &m_pBone[a].mTransform);
	}

	for(unsigned int a = 0; a < m_uiBoneNum; a++)
	{
		float x = m_pBone[a].mTransform._41;
		float y = m_pBone[a].mTransform._42;
		float z = m_pBone[a].mTransform._43;

		fprintf(pFile, "newbone%d = point()\n", a);
		fprintf(pFile, "newbone%d.pos = [%f,%f,%f]\n", a, x, -z, y);
		fprintf(pFile, "newbone%d.name = \"bone_%d\"\n", a, a);
		fprintf(pFile, "newbone%d.centermarker = true\n", a);
		fprintf(pFile, "newbone%d.box = true\n", a);
		fprintf(pFile, "newbone%d.axistripod = false\n", a);
		fprintf(pFile, "newbone%d.cross = false\n", a);
		fprintf(pFile, "newbone%d.size = 5\n", a);

		if(m_pBone[a].uiParent != -1)
			fprintf(pFile, "newbone%d.parent = newbone%d\n", a, m_pBone[a].uiParent);
	}

	// mesh data
	for(unsigned int a = 0; a < m_uiModelNum; a++)
	{
		for(unsigned int b = 0; b < m_pModel[a].uiObjectNum; b++)
		{
			D3DXVECTOR3 *pVertex = new D3DXVECTOR3[m_pModel[a].pObject[b].uiVertexNum];
			D3DXVECTOR3 *pNormal = new D3DXVECTOR3[m_pModel[a].pObject[b].uiVertexNum];
			D3DXVECTOR2 *pTex = new D3DXVECTOR2[m_pModel[a].pObject[b].uiVertexNum];
			switch(m_pModel[a].pObject[b].uiVertexSize)
			{
			case 36:
				{
					for(unsigned int c = 0; c < m_pModel[a].pObject[b].uiVertexNum; c++)
					{
						// convert to float32
						WORD pV[8] = {m_pModel[a].pObject[b].pV36[c].x, m_pModel[a].pObject[b].pV36[c].y, m_pModel[a].pObject[b].pV36[c].z, m_pModel[a].pObject[b].pV36[c].nx, m_pModel[a].pObject[b].pV36[c].ny, m_pModel[a].pObject[b].pV36[c].nz, m_pModel[a].pObject[b].pV36[c].u0, m_pModel[a].pObject[b].pV36[c].v0};
						D3DXFLOAT16 *pV16 = (D3DXFLOAT16*)pV;
						float pVF[8];
						D3DXFloat16To32Array(pVF, pV16, 8);

						// fill the data
						unsigned int uiRealBoneId0 = m_pBoneGroup[m_pModel[a].pObject[b].uiGroupId].pBoneId[m_pModel[a].pObject[b].pV36[c].uiBoneId];
						pVertex[c].x = pVF[0] + m_pBone[uiRealBoneId0].mTransform._41;
						pVertex[c].y = pVF[1] + m_pBone[uiRealBoneId0].mTransform._42;
						pVertex[c].z = pVF[2] + m_pBone[uiRealBoneId0].mTransform._43;
						pNormal[c] = D3DXVECTOR3(pVF[3], pVF[4], pVF[5]);
						pTex[c] = D3DXVECTOR2(pVF[6], pVF[7]);
						
					}
				}
				break;

			case 60:
				{
					for(unsigned int c = 0; c < m_pModel[a].pObject[b].uiVertexNum; c++)
					{
						// convert to float32
						WORD pV[8] = {m_pModel[a].pObject[b].pV60[c].x, m_pModel[a].pObject[b].pV60[c].y, m_pModel[a].pObject[b].pV60[c].z, m_pModel[a].pObject[b].pV60[c].nx, m_pModel[a].pObject[b].pV60[c].ny, m_pModel[a].pObject[b].pV60[c].nz, m_pModel[a].pObject[b].pV60[c].u0, m_pModel[a].pObject[b].pV60[c].v0};
						D3DXFLOAT16 *pV16 = (D3DXFLOAT16*)pV;
						float pVF[8];
						D3DXFloat16To32Array(pVF, pV16, 8);

						// fill the data
						unsigned int uiRealBoneId0 = m_pBoneGroup[m_pModel[a].pObject[b].uiGroupId].pBoneId[m_pModel[a].pObject[b].pV60[c].uiBoneId[0]];
						pVertex[c].x = pVF[0] + m_pBone[uiRealBoneId0].mTransform._41;
						pVertex[c].y = pVF[1] + m_pBone[uiRealBoneId0].mTransform._42;
						pVertex[c].z = pVF[2] + m_pBone[uiRealBoneId0].mTransform._43;
						pNormal[c] = D3DXVECTOR3(pVF[3], pVF[4], pVF[5]);
						pTex[c] = D3DXVECTOR2(pVF[6], pVF[7]);
					}
				}
				break;
			case 84:
				{
					for(unsigned int c = 0; c < m_pModel[a].pObject[b].uiVertexNum; c++)
					{
						// convert to float32
						WORD pV[8] = {m_pModel[a].pObject[b].pV84[c].x, m_pModel[a].pObject[b].pV84[c].y, m_pModel[a].pObject[b].pV84[c].z, m_pModel[a].pObject[b].pV84[c].nx, m_pModel[a].pObject[b].pV84[c].ny, m_pModel[a].pObject[b].pV84[c].nz, m_pModel[a].pObject[b].pV84[c].u0, m_pModel[a].pObject[b].pV84[c].v0};
						D3DXFLOAT16 *pV16 = (D3DXFLOAT16*)pV;
						float pVF[8];
						D3DXFloat16To32Array(pVF, pV16, 8);

						// fill the data
						unsigned int uiRealBoneId0 = m_pBoneGroup[m_pModel[a].pObject[b].uiGroupId].pBoneId[m_pModel[a].pObject[b].pV84[c].uiBoneId[0]];
						pVertex[c].x = pVF[0] + m_pBone[uiRealBoneId0].mTransform._41;
						pVertex[c].y = pVF[1] + m_pBone[uiRealBoneId0].mTransform._42;
						pVertex[c].z = pVF[2] + m_pBone[uiRealBoneId0].mTransform._43;
						pNormal[c] = D3DXVECTOR3(pVF[3], pVF[4], pVF[5]);
						pTex[c] = D3DXVECTOR2(pVF[6], pVF[7]);
					}
				}
				break;
			case 108:
				{
					for(unsigned int c = 0; c < m_pModel[a].pObject[b].uiVertexNum; c++)
					{
						// convert to float32
						WORD pV[8] = {m_pModel[a].pObject[b].pV108[c].x, m_pModel[a].pObject[b].pV108[c].y, m_pModel[a].pObject[b].pV108[c].z, m_pModel[a].pObject[b].pV108[c].nx, m_pModel[a].pObject[b].pV108[c].ny, m_pModel[a].pObject[b].pV108[c].nz, m_pModel[a].pObject[b].pV108[c].u0, m_pModel[a].pObject[b].pV108[c].v0};
						D3DXFLOAT16 *pV16 = (D3DXFLOAT16*)pV;
						float pVF[8];
						D3DXFloat16To32Array(pVF, pV16, 8);

						// fill the data
						unsigned int uiRealBoneId0 = m_pBoneGroup[m_pModel[a].pObject[b].uiGroupId].pBoneId[m_pModel[a].pObject[b].pV108[c].uiBoneId[0]];
						pVertex[c].x = pVF[0] + m_pBone[uiRealBoneId0].mTransform._41;
						pVertex[c].y = pVF[1] + m_pBone[uiRealBoneId0].mTransform._42;
						pVertex[c].z = pVF[2] + m_pBone[uiRealBoneId0].mTransform._43;
						pNormal[c] = D3DXVECTOR3(pVF[3], pVF[4], pVF[5]);
						pTex[c] = D3DXVECTOR2(pVF[6], pVF[7]);
					}
				}
				break;
			}

			// verts
			fprintf(pFile, "mnode_%d_%d = mesh vertices:#(", a, b);
			unsigned int c = 0;
			for(c = 0; c < m_pModel[a].pObject[b].uiVertexNum - 1; c++)
				fprintf(pFile, "[%f,%f,%f],", pVertex[c].x, -pVertex[c].z, pVertex[c].y);
			fprintf(pFile, "[%f,%f,%f])", pVertex[c].x, -pVertex[c].z, pVertex[c].y);

			// faces
			bool bBackface = true;
			fprintf(pFile, " faces:#(");
			for(c = 0; c < m_pModel[a].pObject[b].uiIndexNum - 3; c += 3)
			{
				WORD i0 = m_pModel[a].pObject[b].pIndex[c];
				WORD i1 = m_pModel[a].pObject[b].pIndex[c + 1];
				WORD i2 = m_pModel[a].pObject[b].pIndex[c + 2];
				fprintf(pFile, "[%d,%d,%d],", i0 + 1, i2 + 1, i1 + 1);
			}
			WORD i0 = m_pModel[a].pObject[b].pIndex[c];
			WORD i1 = m_pModel[a].pObject[b].pIndex[c + 1];
			WORD i2 = m_pModel[a].pObject[b].pIndex[c + 2];
			fprintf(pFile, "[%d,%d,%d])\n", i0 + 1, i2 + 1, i1 + 1);

			// set the name
			char strName[128] = {0};
			sprintf(strName, "try_%d_%d_[%s]", a, b, m_pTexture[m_pModel[a].pObject[b].iTex0].strName);
			fprintf(pFile, "mnode_%d_%d.name = \"%s\"\n", a, b, strName);

			// normals
			for(c = 0; c < m_pModel[a].pObject[b].uiVertexNum; c++)
				fprintf(pFile, "setNormal mnode_%d_%d %d [%f, %f, %f]\n", a, b, c + 1, pNormal[c].x, -pNormal[c].z, pNormal[c].y);

			// skin data
			fprintf(pFile, "gc()\n");
			fprintf(pFile, "max modify mode\n");
			fprintf(pFile, "select mnode_%d_%d\n", a, b);
			fprintf(pFile, "theskin_%d_%d = skin()\n", a, b);
			fprintf(pFile, "addmodifier mnode_%d_%d theskin_%d_%d\n", a, b, a, b);
			
			// add the bones
			unsigned int uiGroupId = m_pModel[a].pObject[b].uiGroupId;
			for(unsigned int c = 0; c < m_pBoneGroup[uiGroupId].uiBoneNum; c++)
				fprintf(pFile, "skinops.addbone theskin_%d_%d newbone%d 0\n", a, b, m_pBoneGroup[uiGroupId].pBoneId[c]);
			fprintf(pFile, "update mnode_%d_%d\n", a, b);
			fprintf(pFile, "modpanel.setcurrentobject theskin_%d_%d\n", a, b);

			switch(m_pModel[a].pObject[b].uiVertexSize)
			{
			case 36:
				{
					for(unsigned int c = 0; c < m_pModel[a].pObject[b].uiVertexNum; c++)
					{
						unsigned int uiId0 = m_pModel[a].pObject[b].pV36[c].uiBoneId;
						float fWeight0 = m_pModel[a].pObject[b].pV36[c].fWeight;

						fprintf(pFile, "bonearray_%d_%d_%d = #(%d)\n", a, b, c, uiId0);
						fprintf(pFile, "weightarray_%d_%d_%d = #(%f)\n", a, b, c, fWeight0);
						fprintf(pFile, "skinops.replacevertexweights theskin_%d_%d %d bonearray_%d_%d_%d weightarray_%d_%d_%d\n", a, b, c + 1, a, b, c, a, b, c);
					}
				}
				break;

			case 60:
				{
					for(unsigned int c = 0; c < m_pModel[a].pObject[b].uiVertexNum; c++)
					{
						unsigned int uiId0 = m_pModel[a].pObject[b].pV60[c].uiBoneId[0] + 1;
						unsigned int uiId1 = m_pModel[a].pObject[b].pV60[c].uiBoneId[1] + 1;

						float fWeight0 = m_pModel[a].pObject[b].pV60[c].fWeight[0];
						float fWeight1 = m_pModel[a].pObject[b].pV60[c].fWeight[1];

						fprintf(pFile, "bonearray_%d_%d_%d = #(%d,%d)\n", a, b, c, uiId0, uiId1);
						fprintf(pFile, "weightarray_%d_%d_%d = #(%f,%f)\n", a, b, c, fWeight0, fWeight1);
						fprintf(pFile, "skinops.replacevertexweights theskin_%d_%d %d bonearray_%d_%d_%d weightarray_%d_%d_%d\n", a, b, c + 1, a, b, c, a, b, c);
					}
				}
				break;

			case 84:
				{
					for(unsigned int c = 0; c < m_pModel[a].pObject[b].uiVertexNum; c++)
					{
						unsigned int uiId0 = m_pModel[a].pObject[b].pV84[c].uiBoneId[0] + 1;
						unsigned int uiId1 = m_pModel[a].pObject[b].pV84[c].uiBoneId[1] + 1;
						unsigned int uiId2 = m_pModel[a].pObject[b].pV84[c].uiBoneId[2] + 1;

						float fWeight0 = m_pModel[a].pObject[b].pV84[c].fWeight[0];
						float fWeight1 = m_pModel[a].pObject[b].pV84[c].fWeight[1];
						float fWeight2 = m_pModel[a].pObject[b].pV84[c].fWeight[2];

						fprintf(pFile, "bonearray_%d_%d_%d = #(%d,%d,%d)\n", a, b, c, uiId0, uiId1, uiId2);
						fprintf(pFile, "weightarray_%d_%d_%d = #(%f,%f,%f)\n", a, b, c, fWeight0, fWeight1, fWeight2);
						fprintf(pFile, "skinops.replacevertexweights theskin_%d_%d %d bonearray_%d_%d_%d weightarray_%d_%d_%d\n", a, b, c + 1, a, b, c, a, b, c);
					}
				}
				break;

			case 108:
				{
					for(unsigned int c = 0; c < m_pModel[a].pObject[b].uiVertexNum; c++)
					{
						unsigned int uiId0 = m_pModel[a].pObject[b].pV108[c].uiBoneId[0] + 1;
						unsigned int uiId1 = m_pModel[a].pObject[b].pV108[c].uiBoneId[1] + 1;
						unsigned int uiId2 = m_pModel[a].pObject[b].pV108[c].uiBoneId[2] + 1;
						unsigned int uiId3 = m_pModel[a].pObject[b].pV108[c].uiBoneId[3] + 1;

						float fWeight0 = m_pModel[a].pObject[b].pV108[c].fWeight[0];
						float fWeight1 = m_pModel[a].pObject[b].pV108[c].fWeight[1];
						float fWeight2 = m_pModel[a].pObject[b].pV108[c].fWeight[2];
						float fWeight3 = m_pModel[a].pObject[b].pV108[c].fWeight[3];

						fprintf(pFile, "bonearray_%d_%d_%d = #(%d,%d,%d,%d)\n", a, b, c, uiId0, uiId1, uiId2, uiId3);
						fprintf(pFile, "weightarray_%d_%d_%d = #(%f,%f,%f,%f)\n", a, b, c, fWeight0, fWeight1, fWeight2, fWeight3);
						fprintf(pFile, "skinops.replacevertexweights theskin_%d_%d %d bonearray_%d_%d_%d weightarray_%d_%d_%d\n", a, b, c + 1, a, b, c, a, b, c);
					}
				}
				break;
			}
			delete[] pTex;
			delete[] pNormal;
			delete[] pVertex;
		}
	}
	fprintf(pFile, "enableSceneRedraw()\n");
	fclose(pFile);
	return true;
}

//+----------------------------------------------------------------> ExportCollada()

bool cOneechan::ExportCollada(const char *strOneechan, const char *strFriendly)
{
	// get the base name
	char strBaseName[128] = {0};
	sprintf(strBaseName, "%s", strFriendly);

	// create the material list
	unsigned int uiMaterialNum = 0;
	vector<cOneechanMaterial> pMaterial;
	for(unsigned int a = 0; a < m_uiModelNum; a++)
	{
		// go through all the objects
		for(unsigned int b = 0; b < m_pModel[a].uiObjectNum; b++)
		{
			// the object's material might be a new one, check against the list
			bool bNew = true;
			for(unsigned int c = 0; c < uiMaterialNum; c++)
			{
				if(m_pModel[a].pObject[b].iTex0 == pMaterial[c].iTex0)
				{
					bNew = false;
					m_pModel[a].pObject[b].uiMaterialId = c;
					break;
				}
			}

			// if the material is new then add it to the list
			if(bNew)
			{
				cOneechanMaterial mat;
				mat.iTex0 = m_pModel[a].pObject[b].iTex0;
				mat.iTex1 = m_pModel[a].pObject[b].iTex1;
				mat.iTex2 = m_pModel[a].pObject[b].iTex2;
				sprintf(mat.strName, "mat_%d", uiMaterialNum);
				pMaterial.push_back(mat);
				m_pModel[a].pObject[b].uiMaterialId = uiMaterialNum;
				uiMaterialNum++;
			}
		}
	}

	FILE *pFile = fopen(strOneechan, "wt");

	// prepare matrices
	cOneechanBone *pBone = new cOneechanBone[m_uiBoneNum];
	pBone[0].uiParent = -1;
	m_pBone[0].uiParent = -1;
	for(unsigned int a = 0; a < m_uiBoneNum; a++)
		pBone[a] = m_pBone[a];
	for(unsigned int a = 0; a < m_uiBoneNum; a++)
	{
		if(pBone[a].uiParent != -1)
			D3DXMatrixMultiply(&pBone[a].mTransform, &pBone[pBone[a].uiParent].mTransform, &pBone[a].mTransform);
	}
	for(unsigned int a = 0; a < m_uiBoneNum; a++)
	{
		m_pBone[a].uiId = a;
		//if(m_pBone[a].uiParent != -1)
		//	D3DXMatrixMultiply(&m_pBone[a].mTransform, &m_pBone[m_pBone[a].uiParent].mTransform, &m_pBone[a].mTransform);

		// get the child list
		m_pBone[a].uiChildNum = 0;
		for(unsigned int b = 0; b < m_uiBoneNum; b++)
		{
			if(m_pBone[b].uiParent == a)
				m_pBone[a].uiChildNum++;
		}
		unsigned int uiChild = 0;
		m_pBone[a].pChild = new int[m_pBone[a].uiChildNum];
		for(unsigned int b = 0; b < m_uiBoneNum; b++)
		{
			if(m_pBone[b].uiParent == a)
			{
				m_pBone[a].pChild[uiChild] = b;
				uiChild++;
			}
		}
	}

	// asset
	fprintf(pFile, "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n");
	fprintf(pFile, "<COLLADA xmlns=\"http://www.collada.org/2005/11/COLLADASchema\" version=\"1.4.1\">\n");
	fprintf(pFile, "  <asset>\n");
	fprintf(pFile, "    <contributor>\n");
	fprintf(pFile, "      <author>Administrateur</author>\n");
	fprintf(pFile, "      <authoring_tool>OpenCOLLADA for 3ds Max;  Version: 1.2.4;  Revision: 832;  Platform: Win32;  Configuration: Release Max8</authoring_tool>\n");
	fprintf(pFile, "    </contributor>\n");
	fprintf(pFile, "    <created>2010-04-03T12:00:37</created>\n");
	fprintf(pFile, "    <modified>2010-04-03T12:00:37</modified>\n");
	fprintf(pFile, "    <unit name=\"centimeter\" meter=\"0.01\"/>\n");
	fprintf(pFile, "    <up_axis>Z_UP</up_axis>\n");
	fprintf(pFile, "  </asset>\n");

	// effects

	fprintf(pFile, "  <library_effects>\n");
	for(unsigned int a = 0; a < uiMaterialNum; a++)
	{
		char strTex0[32] = {0};
		char strTex1[32] = {0};
		char strTex2[32] = {0};
		strcpy(strTex0, m_pTexture[pMaterial[a].iTex0].strName);
		strcpy(strTex1, m_pTexture[pMaterial[a].iTex1].strName);
		strcpy(strTex2, m_pTexture[pMaterial[a].iTex2].strName);
		strTex0[strlen(strTex0) - 4] = '\0';
		strTex1[strlen(strTex1) - 4] = '\0';
		strTex2[strlen(strTex2) - 4] = '\0';

		fprintf(pFile, "    <effect id=\"%s\">\n", pMaterial[a].strName);
		fprintf(pFile, "      <profile_COMMON>\n");
		fprintf(pFile, "        <newparam sid=\"%s_dds-surface\">\n", strTex0);
		fprintf(pFile, "          <surface type=\"2D\">\n");
		fprintf(pFile, "            <init_from>%s_dds</init_from>\n", strTex0);
		fprintf(pFile, "          </surface>\n");
		fprintf(pFile, "        </newparam>\n");
		fprintf(pFile, "        <newparam sid=\"%s_dds-sampler\">\n", strTex0);
		fprintf(pFile, "          <sampler2D>\n");
		fprintf(pFile, "            <source>%s_dds-surface</source>\n", strTex0);
		fprintf(pFile, "          </sampler2D>\n");
		fprintf(pFile, "        </newparam>\n");
		fprintf(pFile, "        <newparam sid=\"%s_dds-surface\">\n", strTex2);
		fprintf(pFile, "          <surface type=\"2D\">\n");
		fprintf(pFile, "            <init_from>%s_dds</init_from>\n", strTex2);
		fprintf(pFile, "          </surface>\n");
		fprintf(pFile, "        </newparam>\n");
		fprintf(pFile, "        <newparam sid=\"%s_dds-sampler\">\n", strTex2);
		fprintf(pFile, "          <sampler2D>\n");
		fprintf(pFile, "            <source>%s_dds-surface</source>\n", strTex2);
		fprintf(pFile, "          </sampler2D>\n");
		fprintf(pFile, "        </newparam>\n");
		fprintf(pFile, "        <newparam sid=\"%s_dds-surface\">\n", strTex1);
		fprintf(pFile, "          <surface type=\"2D\">\n");
		fprintf(pFile, "            <init_from>%s_dds</init_from>\n", strTex1);
		fprintf(pFile, "          </surface>\n");
		fprintf(pFile, "        </newparam>\n");
		fprintf(pFile, "        <newparam sid=\"%s_dds-sampler\">\n", strTex1);
		fprintf(pFile, "          <sampler2D>\n");
		fprintf(pFile, "            <source>%s_dds-surface</source>\n", strTex1);
		fprintf(pFile, "          </sampler2D>\n");
		fprintf(pFile, "        </newparam>\n");
		fprintf(pFile, "        <technique sid=\"common\">\n");
		fprintf(pFile, "          <blinn>\n");
		fprintf(pFile, "            <emission>\n");
		fprintf(pFile, "              <color>0 0 0 1</color>\n");
		fprintf(pFile, "            </emission>\n");
		fprintf(pFile, "            <ambient>\n");
		fprintf(pFile, "              <color>0.5882353 0.5882353 0.5882353 1</color>\n");
		fprintf(pFile, "            </ambient>\n");
		fprintf(pFile, "            <diffuse>\n");
		fprintf(pFile, "              <texture texture=\"%s_dds-sampler\" texcoord=\"CHANNEL1\"/>\n", strTex0);
		fprintf(pFile, "            </diffuse>\n");
		fprintf(pFile, "            <specular>\n");
		fprintf(pFile, "              <texture texture=\"%s_dds-sampler\" texcoord=\"CHANNEL1\"/>\n", strTex2);
		fprintf(pFile, "            </specular>\n");
		fprintf(pFile, "            <shininess>\n");
		fprintf(pFile, "              <float>9.999999</float>\n");
		fprintf(pFile, "            </shininess>\n");
		fprintf(pFile, "            <reflective>\n");
		fprintf(pFile, "              <color>0 0 0 1</color>\n");
		fprintf(pFile, "            </reflective>\n");
		fprintf(pFile, "            <transparent opaque=\"A_ONE\">\n");
		fprintf(pFile, "              <color>1 1 1 1</color>\n");
		fprintf(pFile, "            </transparent>\n");
		fprintf(pFile, "            <transparency>\n");
		fprintf(pFile, "              <float>1</float>\n");
		fprintf(pFile, "            </transparency>\n");
		fprintf(pFile, "          </blinn>\n");
		fprintf(pFile, "          <extra>\n");
		fprintf(pFile, "            <technique profile=\"OpenCOLLADA_3dsMax\">\n");
		fprintf(pFile, "              <bump>\n");
		fprintf(pFile, "                <texture texture=\"%s_dds-sampler\" texcoord=\"CHANNEL1\"/>\n", strTex1);
		fprintf(pFile, "              </bump>\n");
		fprintf(pFile, "            </technique>\n");
		fprintf(pFile, "          </extra>\n");
		fprintf(pFile, "        </technique>\n");
		fprintf(pFile, "      </profile_COMMON>\n");
		fprintf(pFile, "      <extra>\n");
		fprintf(pFile, "        <technique profile=\"OpenCOLLADA_3dsMax\">\n");
		fprintf(pFile, "          <extended_shader>\n");
		fprintf(pFile, "            <apply_reflection_dimming>0</apply_reflection_dimming>\n");
		fprintf(pFile, "            <dim_level>0</dim_level>\n");
		fprintf(pFile, "            <falloff_type>0</falloff_type>\n");
		fprintf(pFile, "            <index_of_refraction>1.5</index_of_refraction>\n");
		fprintf(pFile, "            <opacity_type>0</opacity_type>\n");
		fprintf(pFile, "            <reflection_level>3</reflection_level>\n");
		fprintf(pFile, "            <wire_size>1</wire_size>\n");
		fprintf(pFile, "            <wire_units>0</wire_units>\n");
		fprintf(pFile, "          </extended_shader>\n");
		fprintf(pFile, "          <shader>\n");
		fprintf(pFile, "            <ambient_diffuse_lock>1</ambient_diffuse_lock>\n");
		fprintf(pFile, "            <ambient_diffuse_texture_lock>1</ambient_diffuse_texture_lock>\n");
		fprintf(pFile, "            <diffuse_specular_lock>0</diffuse_specular_lock>\n");
		fprintf(pFile, "            <soften>0.1</soften>\n");
		fprintf(pFile, "            <use_self_illum_color>0</use_self_illum_color>\n");
		fprintf(pFile, "          </shader>\n");
		fprintf(pFile, "        </technique>\n");
		fprintf(pFile, "      </extra>\n");
		fprintf(pFile, "    </effect>\n");
	}
	fprintf(pFile, "    <effect id=\"ColorEffectR228G214B153\">\n");
	fprintf(pFile, "      <profile_COMMON>\n");
	fprintf(pFile, "        <technique sid=\"common\">\n");
	fprintf(pFile, "          <phong>\n");
	fprintf(pFile, "            <ambient>\n");
	fprintf(pFile, "              <color>0.8941176 0.8392157 0.6 1</color>\n");
	fprintf(pFile, "            </ambient>\n");
	fprintf(pFile, "            <diffuse>\n");
	fprintf(pFile, "              <color>0.8941176 0.8392157 0.6 1</color>\n");
	fprintf(pFile, "            </diffuse>\n");
	fprintf(pFile, "            <specular>\n");
	fprintf(pFile, "              <color>1 1 1 1</color>\n");
	fprintf(pFile, "            </specular>\n");
	fprintf(pFile, "            <shininess>\n");
	fprintf(pFile, "              <float>10</float>\n");
	fprintf(pFile, "            </shininess>\n");
	fprintf(pFile, "            <reflective>\n");
	fprintf(pFile, "              <color>0 0 0 1</color>\n");
	fprintf(pFile, "            </reflective>\n");
	fprintf(pFile, "            <transparent>\n");
	fprintf(pFile, "              <color>1 1 1 1</color>\n");
	fprintf(pFile, "            </transparent>\n");
	fprintf(pFile, "            <transparency>\n");
	fprintf(pFile, "              <float>1</float>\n");
	fprintf(pFile, "            </transparency>\n");
	fprintf(pFile, "          </phong>\n");
	fprintf(pFile, "        </technique>\n");
	fprintf(pFile, "      </profile_COMMON>\n");
	fprintf(pFile, "    </effect>\n");
	fprintf(pFile, "  </library_effects>\n");

	// material library
	fprintf(pFile, "  <library_materials>\n");
	for(unsigned int a = 0; a < uiMaterialNum; a++)
	{
		fprintf(pFile, "    <material id=\"%s-material\" name=\"%s-material\">\n", pMaterial[a].strName, pMaterial[a].strName);
		fprintf(pFile, "      <instance_effect url=\"#%s\"/>\n", pMaterial[a].strName);
		fprintf(pFile, "    </material>\n");
	}
	fprintf(pFile, "    <material id=\"ColorEffectR228G214B153-material\" name=\"ColorEffectR228G214B153-material\">\n");
	fprintf(pFile, "      <instance_effect url=\"#ColorEffectR228G214B153\"/>\n");
	fprintf(pFile, "    </material>\n");
	fprintf(pFile, "    <material id=\"ColorEffectR88G177B26-material\" name=\"ColorEffectR88G177B26-material\">\n");
	fprintf(pFile, "      <instance_effect url=\"#ColorEffectR88G177B26\"/>\n");
	fprintf(pFile, "    </material>\n");
	fprintf(pFile, "  </library_materials>\n");

	// geometries
	fprintf(pFile, "  <library_geometries>\n");
	for(unsigned int a = 0; a < m_uiModelNum; a++)
	{
		for(unsigned int b = 0; b < m_pModel[a].uiObjectNum; b++)
		{
			char strName[128] = {0};
			//sprintf(strName, "%s_%d_%d_[%s]", strBaseName, a, b, m_pTexture[m_pModel[a].pObject[b].iTex0].strName);
			sprintf(strName, "%s_%d_%d", strBaseName, a, b);
			fprintf(pFile, "    <geometry id=\"geom-%s\" name=\"%s\">\n", strName, strName);
			fprintf(pFile, "      <mesh>\n");
			
			// go through the verts and write them
			unsigned int uiVertexNum = m_pModel[a].pObject[b].uiVertexNum;

			// generate the verts
			D3DXVECTOR3 *pVertex = new D3DXVECTOR3[uiVertexNum];
			D3DXVECTOR3	*pNormal = new D3DXVECTOR3[uiVertexNum];
			D3DXVECTOR2	*pTex0 = new D3DXVECTOR2[uiVertexNum];
			switch(m_pModel[a].pObject[b].uiVertexSize)
			{
			case 36:
				{
					for(unsigned int c = 0; c < uiVertexNum; c++)
					{
						WORD pV[8] = {m_pModel[a].pObject[b].pV36[c].x, m_pModel[a].pObject[b].pV36[c].y, m_pModel[a].pObject[b].pV36[c].z, m_pModel[a].pObject[b].pV36[c].nx, m_pModel[a].pObject[b].pV36[c].ny, m_pModel[a].pObject[b].pV36[c].nz, m_pModel[a].pObject[b].pV36[c].u0, m_pModel[a].pObject[b].pV36[c].v0};
						D3DXFLOAT16 *pV16 = (D3DXFLOAT16*)pV;
						float pVF[8];
						D3DXFloat16To32Array(pVF, pV16, 8);

						unsigned int uiRealBoneId0 = m_pBoneGroup[m_pModel[a].pObject[b].uiGroupId].pBoneId[m_pModel[a].pObject[b].pV36[c].uiBoneId];
						pVertex[c].x = pVF[0] + pBone[uiRealBoneId0].mTransform._41;
						pVertex[c].y = pVF[1] + pBone[uiRealBoneId0].mTransform._42;
						pVertex[c].z = pVF[2] + pBone[uiRealBoneId0].mTransform._43;
						pNormal[c] = D3DXVECTOR3(pVF[3], pVF[4], pVF[5]);
						pTex0[c] = D3DXVECTOR2(pVF[6], pVF[7]);
					}
				}
				break;

			case 60:
				{
					for(unsigned int c = 0; c < uiVertexNum; c++)
					{
						WORD pV[8] = {m_pModel[a].pObject[b].pV60[c].x, m_pModel[a].pObject[b].pV60[c].y, m_pModel[a].pObject[b].pV60[c].z, m_pModel[a].pObject[b].pV60[c].nx, m_pModel[a].pObject[b].pV60[c].ny, m_pModel[a].pObject[b].pV60[c].nz, m_pModel[a].pObject[b].pV60[c].u0, m_pModel[a].pObject[b].pV60[c].v0};
						D3DXFLOAT16 *pV16 = (D3DXFLOAT16*)pV;
						float pVF[8];
						D3DXFloat16To32Array(pVF, pV16, 8);

						unsigned int uiRealBoneId0 = m_pBoneGroup[m_pModel[a].pObject[b].uiGroupId].pBoneId[m_pModel[a].pObject[b].pV60[c].uiBoneId[0]];
						pVertex[c].x = pVF[0] + pBone[uiRealBoneId0].mTransform._41;
						pVertex[c].y = pVF[1] + pBone[uiRealBoneId0].mTransform._42;
						pVertex[c].z = pVF[2] + pBone[uiRealBoneId0].mTransform._43;
						pNormal[c] = D3DXVECTOR3(pVF[3], pVF[4], pVF[5]);
						pTex0[c] = D3DXVECTOR2(pVF[6], pVF[7]);
					}
				}
				break;

			case 84:
				{
					for(unsigned int c = 0; c < uiVertexNum; c++)
					{
						WORD pV[8] = {m_pModel[a].pObject[b].pV84[c].x, m_pModel[a].pObject[b].pV84[c].y, m_pModel[a].pObject[b].pV84[c].z, m_pModel[a].pObject[b].pV84[c].nx, m_pModel[a].pObject[b].pV84[c].ny, m_pModel[a].pObject[b].pV84[c].nz, m_pModel[a].pObject[b].pV84[c].u0, m_pModel[a].pObject[b].pV84[c].v0};
						D3DXFLOAT16 *pV16 = (D3DXFLOAT16*)pV;
						float pVF[8];
						D3DXFloat16To32Array(pVF, pV16, 8);

						unsigned int uiRealBoneId0 = m_pBoneGroup[m_pModel[a].pObject[b].uiGroupId].pBoneId[m_pModel[a].pObject[b].pV84[c].uiBoneId[0]];
						pVertex[c].x = pVF[0] + pBone[uiRealBoneId0].mTransform._41;
						pVertex[c].y = pVF[1] + pBone[uiRealBoneId0].mTransform._42;
						pVertex[c].z = pVF[2] + pBone[uiRealBoneId0].mTransform._43;
						pNormal[c] = D3DXVECTOR3(pVF[3], pVF[4], pVF[5]);
						pTex0[c] = D3DXVECTOR2(pVF[6], pVF[7]);
					}
				}
				break;

			case 108:
				{
					for(unsigned int c = 0; c < uiVertexNum; c++)
					{
						WORD pV[8] = {m_pModel[a].pObject[b].pV108[c].x, m_pModel[a].pObject[b].pV108[c].y, m_pModel[a].pObject[b].pV108[c].z, m_pModel[a].pObject[b].pV108[c].nx, m_pModel[a].pObject[b].pV108[c].ny, m_pModel[a].pObject[b].pV108[c].nz, m_pModel[a].pObject[b].pV108[c].u0, m_pModel[a].pObject[b].pV108[c].v0};
						D3DXFLOAT16 *pV16 = (D3DXFLOAT16*)pV;
						float pVF[8];
						D3DXFloat16To32Array(pVF, pV16, 8);

						unsigned int uiRealBoneId0 = m_pBoneGroup[m_pModel[a].pObject[b].uiGroupId].pBoneId[m_pModel[a].pObject[b].pV108[c].uiBoneId[0]];
						pVertex[c].x = pVF[0] + pBone[uiRealBoneId0].mTransform._41;
						pVertex[c].y = pVF[1] + pBone[uiRealBoneId0].mTransform._42;
						pVertex[c].z = pVF[2] + pBone[uiRealBoneId0].mTransform._43;
						pNormal[c] = D3DXVECTOR3(pVF[3], pVF[4], pVF[5]);
						pTex0[c] = D3DXVECTOR2(pVF[6], pVF[7]);
					}
				}
				break;
			}

			// write the verts
			fprintf(pFile, "        <source id=\"geom-%s-positions\">\n", strName);
			fprintf(pFile, "          <float_array id=\"geom-%s-positions-array\" count=\"%d\">", strName, uiVertexNum * 3);
			for(unsigned int c = 0; c < uiVertexNum; c++)
				fprintf(pFile, "%f %f %f ", pVertex[c].x, -pVertex[c].z, pVertex[c].y);
			fprintf(pFile, "</float_array>\n");
			fprintf(pFile, "          <technique_common>\n");
			fprintf(pFile, "            <accessor source=\"#geom-%s-positions-array\" count=\"%d\" stride=\"3\">\n", strName, uiVertexNum);
			fprintf(pFile, "              <param name=\"X\" type=\"float\"/>\n");
			fprintf(pFile, "              <param name=\"Y\" type=\"float\"/>\n");
			fprintf(pFile, "              <param name=\"Z\" type=\"float\"/>\n");
			fprintf(pFile, "            </accessor>\n");
			fprintf(pFile, "          </technique_common>\n");
			fprintf(pFile, "        </source>\n");
			
			// write the normals
			fprintf(pFile, "        <source id=\"geom-%s-normals\">\n", strName);
			fprintf(pFile, "          <float_array id=\"geom-%s-normals-array\" count=\"%d\">", strName, uiVertexNum * 3);
			for(unsigned int c = 0; c < uiVertexNum; c++)
				fprintf(pFile, "%f %f %f ", pNormal[c].x, -pNormal[c].z, pNormal[c].y);
			fprintf(pFile, "</float_array>\n");
			fprintf(pFile, "          <technique_common>\n");
			fprintf(pFile, "            <accessor source=\"#geom-%s-normals-array\" count=\"%d\" stride=\"3\">\n", strName, uiVertexNum);
			fprintf(pFile, "              <param name=\"X\" type=\"float\"/>\n");
			fprintf(pFile, "              <param name=\"Y\" type=\"float\"/>\n");
			fprintf(pFile, "              <param name=\"Z\" type=\"float\"/>\n");
			fprintf(pFile, "            </accessor>\n");
			fprintf(pFile, "          </technique_common>\n");
			fprintf(pFile, "        </source>\n");

			// tex coord 0
			fprintf(pFile, "        <source id=\"geom-%s-map-channel1\">\n", strName);
			fprintf(pFile, "          <float_array id=\"geom-%s-map-channel1-array\" count=\"%d\">", strName, uiVertexNum * 3);
			for(unsigned int c = 0; c < uiVertexNum; c++)
				fprintf(pFile, "%f %f %f ", pTex0[c].x, 1.0f - pTex0[c].y, 0.5f);
			fprintf(pFile, "</float_array>\n");
			fprintf(pFile, "          <technique_common>\n");
			fprintf(pFile, "            <accessor source=\"#geom-%s-map-channel1-array\" count=\"%d\" stride=\"3\">\n", strName, uiVertexNum);
			fprintf(pFile, "              <param name=\"S\" type=\"float\"/>\n");
			fprintf(pFile, "              <param name=\"T\" type=\"float\"/>\n");
			fprintf(pFile, "              <param name=\"P\" type=\"float\"/>\n");
			fprintf(pFile, "            </accessor>\n");
			fprintf(pFile, "          </technique_common>\n");
			fprintf(pFile, "        </source>\n");

			// done with verts
			delete[] pVertex;
			delete[] pNormal;
			delete[] pTex0;

			// faces
			unsigned int uiFaceNum = 0;
			for(unsigned int c = 0; c < m_pModel[a].pObject[b].uiIndexNum; c += 3)
			{
				WORD i0 = m_pModel[a].pObject[b].pIndex[c];
				WORD i1 = m_pModel[a].pObject[b].pIndex[c + 1];
				WORD i2 = m_pModel[a].pObject[b].pIndex[c + 2];
				if((i0 != i1) && (i1 != i2) && (i0 != i2))
					uiFaceNum++;
			}
			fprintf(pFile, "        <vertices id=\"geom-%s-vertices\">\n", strName);
			fprintf(pFile, "          <input semantic=\"POSITION\" source=\"#geom-%s-positions\"/>\n", strName);
			fprintf(pFile, "        </vertices>\n");
			fprintf(pFile, "        <triangles material=\"%s\" count=\"%d\">\n", pMaterial[m_pModel[a].pObject[b].uiMaterialId].strName, uiFaceNum);
			fprintf(pFile, "          <input semantic=\"VERTEX\" source=\"#geom-%s-vertices\" offset=\"0\"/>\n", strName);
			fprintf(pFile, "          <input semantic=\"NORMAL\" source=\"#geom-%s-normals\" offset=\"1\"/>\n", strName);
			fprintf(pFile, "          <input semantic=\"TEXCOORD\" source=\"#geom-%s-map-channel1\" offset=\"2\" set=\"1\"/>\n", strName);
			fprintf(pFile, "          <p>");
			
			bool bBackface = true;
			for(unsigned int c = 0; c < m_pModel[a].pObject[b].uiIndexNum; c += 3)
			{
				WORD i0 = m_pModel[a].pObject[b].pIndex[c];
				WORD i1 = m_pModel[a].pObject[b].pIndex[c + 1];
				WORD i2 = m_pModel[a].pObject[b].pIndex[c + 2];
				if((i0 != i1) && (i1 != i2) && (i0 != i2))
				{
					if(bBackface)
						fprintf(pFile, "%d %d %d %d %d %d %d %d %d ", i0, i0, i0, i2, i2, i2, i1, i1, i1);
					else
						fprintf(pFile, "%d %d %d %d %d %d %d %d %d ", i0, i0, i0, i2, i2, i2, i1, i1, i1);
				}
				bBackface = !bBackface;
			}
			fprintf(pFile, "</p>\n");
			fprintf(pFile, "        </triangles>\n");

			fprintf(pFile, "      </mesh>\n");
			fprintf(pFile, "    </geometry>\n");
		}
	}
	fprintf(pFile, "  </library_geometries>\n");

	// controllers
	fprintf(pFile, "  <library_controllers>\n");
	for(unsigned int a = 0; a < m_uiModelNum; a++)
	{
		for(unsigned int b = 0; b < m_pModel[a].uiObjectNum; b++)
		{
			char strName[128] = {0};
			sprintf(strName, "%s_%d_%d", strBaseName, a, b);
			//sprintf(strName, "%s_%d_%d_%d", strBaseName, a, b, m_pModel[a].pObject[b].uiVertexSize);
			unsigned int uiGroupId = m_pModel[a].pObject[b].uiGroupId;
			unsigned int uiBoneNum = m_pBoneGroup[uiGroupId].uiBoneNum;
			
			fprintf(pFile, "    <controller id=\"geom-%s-skin1\">\n", strName);
			fprintf(pFile, "      <skin source=\"#geom-%s\">\n", strName);
			fprintf(pFile, "        <source id=\"geom-%s-skin1-joints\">\n", strName);
			fprintf(pFile, "          <Name_array id=\"geom-%s-skin1-joints-array\" count=\"%d\">", strName, m_pBoneGroup[uiGroupId].uiBoneNum);
			for(unsigned int c = 0; c < m_pBoneGroup[uiGroupId].uiBoneNum; c++)
				fprintf(pFile, "%sjoint%d ", strFriendly, m_pBone[m_pBoneGroup[uiGroupId].pBoneId[c]].uiId);
			fprintf(pFile, "</Name_array>\n");
			fprintf(pFile, "          <technique_common>\n");
			fprintf(pFile, "            <accessor source=\"#geom-%s-skin1-joints-array\" count=\"%d\" stride=\"1\">\n", strName, m_pBoneGroup[uiGroupId].uiBoneNum);
			fprintf(pFile, "              <param name=\"JOINT\" type=\"name\"/>\n");
			fprintf(pFile, "            </accessor>\n");
			fprintf(pFile, "          </technique_common>\n");
			fprintf(pFile, "        </source>\n");
			
			// bind poses
			fprintf(pFile, "        <source id=\"geom-%s-skin1-bind_poses\">\n", strName);
			fprintf(pFile, "          <float_array id=\"geom-%s-skin1-bind_poses-array\" count=\"%d\">", strName, uiBoneNum * 16);
			for(unsigned int c = 0; c < uiBoneNum; c++)
				fprintf(pFile, "1 0 0 %f 0 1 0 %f 0 0 1 %f 0 0 0 1 ", -pBone[m_pBoneGroup[uiGroupId].pBoneId[c]].mTransform._41, pBone[m_pBoneGroup[uiGroupId].pBoneId[c]].mTransform._43, -pBone[m_pBoneGroup[uiGroupId].pBoneId[c]].mTransform._42);
			fprintf(pFile, "</float_array>\n");
			fprintf(pFile, "          <technique_common>\n");
			fprintf(pFile, "            <accessor source=\"#geom-%s-skin1-bind_poses-array\" count=\"%d\" stride=\"16\">\n", strName, uiBoneNum);
			fprintf(pFile, "              <param name=\"TRANSFORM\" type=\"float4x4\"/>\n");
			fprintf(pFile, "            </accessor>\n");
			fprintf(pFile, "          </technique_common>\n");
			fprintf(pFile, "        </source>\n");

			switch(m_pModel[a].pObject[b].uiVertexSize)
			{
			case 36:
				{
					unsigned int uiVertexNum = m_pModel[a].pObject[b].uiVertexNum;
					// weights
					fprintf(pFile, "        <source id=\"geom-%s-skin1-weights\">\n", strName);
					fprintf(pFile, "          <float_array id=\"geom-%s-skin1-weights-array\" count=\"%d\">", strName, uiVertexNum);
					for(unsigned int c = 0; c < uiVertexNum; c++)
						fprintf(pFile, "%f ", 1.0f);
					fprintf(pFile, "</float_array>\n");
					fprintf(pFile, "          <technique_common>\n");
					fprintf(pFile, "            <accessor source=\"#geom-%s-skin1-weights-array\" count=\"%d\" stride=\"1\">\n", strName, uiVertexNum);
					fprintf(pFile, "              <param name=\"WEIGHT\" type=\"float\"/>\n");
					fprintf(pFile, "            </accessor>\n");
					fprintf(pFile, "          </technique_common>\n");
					fprintf(pFile, "        </source>\n");

					// joints
					fprintf(pFile, "        <joints>\n");
					fprintf(pFile, "          <input semantic=\"JOINT\" source=\"#geom-%s-skin1-joints\"/>\n", strName);
					fprintf(pFile, "          <input semantic=\"INV_BIND_MATRIX\" source=\"#geom-%s-skin1-bind_poses\"/>\n", strName);
					fprintf(pFile, "        </joints>\n");

					// vertex weights
					fprintf(pFile, "        <vertex_weights count=\"%d\">\n", uiVertexNum);
					fprintf(pFile, "          <input semantic=\"JOINT\" source=\"#geom-%s-skin1-joints\" offset=\"0\"/>\n", strName);
					fprintf(pFile, "          <input semantic=\"WEIGHT\" source=\"#geom-%s-skin1-weights\" offset=\"1\"/>\n", strName);
					fprintf(pFile, "          <vcount>");
					for(unsigned int c = 0; c < uiVertexNum; c++)
						fprintf(pFile, "%d ", 1);
					fprintf(pFile, "</vcount>\n");
					fprintf(pFile, "          <v>");
					for(unsigned int c = 0; c < uiVertexNum; c++)
						fprintf(pFile, "%d %d ", m_pModel[a].pObject[b].pV36[c].uiBoneId, c);
					fprintf(pFile, "</v>\n");
					fprintf(pFile, "        </vertex_weights>\n");
				}
				break;

			case 60:
				{
					unsigned int uiVertexNum = m_pModel[a].pObject[b].uiVertexNum;

					// weights
					fprintf(pFile, "        <source id=\"geom-%s-skin1-weights\">\n", strName);
					fprintf(pFile, "          <float_array id=\"geom-%s-skin1-weights-array\" count=\"%d\">", strName, uiVertexNum * 2);
					for(unsigned int c = 0; c < uiVertexNum; c++)
						fprintf(pFile, "%f %f ", m_pModel[a].pObject[b].pV60[c].fWeight[0], m_pModel[a].pObject[b].pV60[c].fWeight[1]);
					fprintf(pFile, "</float_array>\n");
					fprintf(pFile, "          <technique_common>\n");
					fprintf(pFile, "            <accessor source=\"#geom-%s-skin1-weights-array\" count=\"%d\" stride=\"1\">\n", strName, uiVertexNum * 2);
					fprintf(pFile, "              <param name=\"WEIGHT\" type=\"float\"/>\n");
					fprintf(pFile, "            </accessor>\n");
					fprintf(pFile, "          </technique_common>\n");
					fprintf(pFile, "        </source>\n");

					// joints
					fprintf(pFile, "        <joints>\n");
					fprintf(pFile, "          <input semantic=\"JOINT\" source=\"#geom-%s-skin1-joints\"/>\n", strName);
					fprintf(pFile, "          <input semantic=\"INV_BIND_MATRIX\" source=\"#geom-%s-skin1-bind_poses\"/>\n", strName);
					fprintf(pFile, "        </joints>\n");

					// vertex weights
					fprintf(pFile, "        <vertex_weights count=\"%d\">\n", uiVertexNum);
					fprintf(pFile, "          <input semantic=\"JOINT\" source=\"#geom-%s-skin1-joints\" offset=\"0\"/>\n", strName);
					fprintf(pFile, "          <input semantic=\"WEIGHT\" source=\"#geom-%s-skin1-weights\" offset=\"1\"/>\n", strName);
					fprintf(pFile, "          <vcount>");
					for(unsigned int c = 0; c < uiVertexNum; c++)
						fprintf(pFile, "%d ", 2);
					fprintf(pFile, "</vcount>\n");
					fprintf(pFile, "          <v>");
					for(unsigned int c = 0; c < uiVertexNum; c++)
					{
						for(unsigned int d = 0; d < 2; d++)
							fprintf(pFile, "%d %d ", m_pModel[a].pObject[b].pV60[c].uiBoneId[d], (c * 2) + d);
					}
					fprintf(pFile, "</v>\n");
					fprintf(pFile, "        </vertex_weights>\n");
				}
				break;

			case 84:
				{
					unsigned int uiVertexNum = m_pModel[a].pObject[b].uiVertexNum;

					// weights
					fprintf(pFile, "        <source id=\"geom-%s-skin1-weights\">\n", strName);
					fprintf(pFile, "          <float_array id=\"geom-%s-skin1-weights-array\" count=\"%d\">", strName, uiVertexNum * 3);
					for(unsigned int c = 0; c < uiVertexNum; c++)
						fprintf(pFile, "%f %f %f ", m_pModel[a].pObject[b].pV84[c].fWeight[0], m_pModel[a].pObject[b].pV84[c].fWeight[1], m_pModel[a].pObject[b].pV84[c].fWeight[2]);
					fprintf(pFile, "</float_array>\n");
					fprintf(pFile, "          <technique_common>\n");
					fprintf(pFile, "            <accessor source=\"#geom-%s-skin1-weights-array\" count=\"%d\" stride=\"1\">\n", strName, uiVertexNum * 3);
					fprintf(pFile, "              <param name=\"WEIGHT\" type=\"float\"/>\n");
					fprintf(pFile, "            </accessor>\n");
					fprintf(pFile, "          </technique_common>\n");
					fprintf(pFile, "        </source>\n");

					// joints
					fprintf(pFile, "        <joints>\n");
					fprintf(pFile, "          <input semantic=\"JOINT\" source=\"#geom-%s-skin1-joints\"/>\n", strName);
					fprintf(pFile, "          <input semantic=\"INV_BIND_MATRIX\" source=\"#geom-%s-skin1-bind_poses\"/>\n", strName);
					fprintf(pFile, "        </joints>\n");

					// vertex weights
					fprintf(pFile, "        <vertex_weights count=\"%d\">\n", uiVertexNum);
					fprintf(pFile, "          <input semantic=\"JOINT\" source=\"#geom-%s-skin1-joints\" offset=\"0\"/>\n", strName);
					fprintf(pFile, "          <input semantic=\"WEIGHT\" source=\"#geom-%s-skin1-weights\" offset=\"1\"/>\n", strName);
					fprintf(pFile, "          <vcount>");
					for(unsigned int c = 0; c < uiVertexNum; c++)
						fprintf(pFile, "%d ", 3);
					fprintf(pFile, "</vcount>\n");
					fprintf(pFile, "          <v>");
					for(unsigned int c = 0; c < uiVertexNum; c++)
					{
						for(unsigned int d = 0; d < 3; d++)
							fprintf(pFile, "%d %d ", m_pModel[a].pObject[b].pV84[c].uiBoneId[d], (c * 3) + d);
					}
					fprintf(pFile, "</v>\n");
					fprintf(pFile, "        </vertex_weights>\n");
				}
				break;

			case 108:
				{
					unsigned int uiVertexNum = m_pModel[a].pObject[b].uiVertexNum;

					// weights
					fprintf(pFile, "        <source id=\"geom-%s-skin1-weights\">\n", strName);
					fprintf(pFile, "          <float_array id=\"geom-%s-skin1-weights-array\" count=\"%d\">", strName, uiVertexNum * 4);
					for(unsigned int c = 0; c < uiVertexNum; c++)
						fprintf(pFile, "%f %f %f %f ", m_pModel[a].pObject[b].pV108[c].fWeight[0], m_pModel[a].pObject[b].pV108[c].fWeight[1], m_pModel[a].pObject[b].pV108[c].fWeight[2], m_pModel[a].pObject[b].pV108[c].fWeight[3]);
					fprintf(pFile, "</float_array>\n");
					fprintf(pFile, "          <technique_common>\n");
					fprintf(pFile, "            <accessor source=\"#geom-%s-skin1-weights-array\" count=\"%d\" stride=\"1\">\n", strName, uiVertexNum * 4);
					fprintf(pFile, "              <param name=\"WEIGHT\" type=\"float\"/>\n");
					fprintf(pFile, "            </accessor>\n");
					fprintf(pFile, "          </technique_common>\n");
					fprintf(pFile, "        </source>\n");

					// joints
					fprintf(pFile, "        <joints>\n");
					fprintf(pFile, "          <input semantic=\"JOINT\" source=\"#geom-%s-skin1-joints\"/>\n", strName);
					fprintf(pFile, "          <input semantic=\"INV_BIND_MATRIX\" source=\"#geom-%s-skin1-bind_poses\"/>\n", strName);
					fprintf(pFile, "        </joints>\n");

					// vertex weights
					fprintf(pFile, "        <vertex_weights count=\"%d\">\n", uiVertexNum);
					fprintf(pFile, "          <input semantic=\"JOINT\" source=\"#geom-%s-skin1-joints\" offset=\"0\"/>\n", strName);
					fprintf(pFile, "          <input semantic=\"WEIGHT\" source=\"#geom-%s-skin1-weights\" offset=\"1\"/>\n", strName);
					fprintf(pFile, "          <vcount>");
					for(unsigned int c = 0; c < uiVertexNum; c++)
						fprintf(pFile, "%d ", 4);
					fprintf(pFile, "</vcount>\n");
					fprintf(pFile, "          <v>");
					for(unsigned int c = 0; c < uiVertexNum; c++)
					{
						for(unsigned int d = 0; d < 4; d++)
							fprintf(pFile, "%d %d ", m_pModel[a].pObject[b].pV108[c].uiBoneId[d], (c * 4) + d);
					}
					fprintf(pFile, "</v>\n");
					fprintf(pFile, "        </vertex_weights>\n");
				}
				break;
			}

			fprintf(pFile, "      </skin>\n");
			fprintf(pFile, "    </controller>\n");
		}
	}
	fprintf(pFile, "  </library_controllers>\n");

	// lights
	fprintf(pFile, "  <library_lights>\n");
	fprintf(pFile, "    <light id=\"EnvironmentAmbientLight\" name=\"EnvironmentAmbientLight\">\n");
	fprintf(pFile, "      <technique_common>\n");
	fprintf(pFile, "        <ambient>\n");
	fprintf(pFile, "          <color>0 0 0</color>\n");
	fprintf(pFile, "        </ambient>\n");
	fprintf(pFile, "      </technique_common>\n");
	fprintf(pFile, "    </light>\n");
	fprintf(pFile, "  </library_lights>\n");

	// images
	fprintf(pFile, "  <library_images>\n");
	for(unsigned int a = 0; a < uiMaterialNum; a++)
	{
		char strTex0[32] = {0};
		char strTex1[32] = {0};
		char strTex2[32] = {0};
		strcpy(strTex0, m_pTexture[pMaterial[a].iTex0].strName);
		strcpy(strTex1, m_pTexture[pMaterial[a].iTex1].strName);
		strcpy(strTex2, m_pTexture[pMaterial[a].iTex2].strName);
		strTex0[strlen(strTex0) - 4] = '\0';
		strTex1[strlen(strTex1) - 4] = '\0';
		strTex2[strlen(strTex2) - 4] = '\0';

		fprintf(pFile, "    <image id=\"%s_dds\">\n", strTex0);
		fprintf(pFile, "      <init_from>./tex/%s</init_from>\n", m_pTexture[pMaterial[a].iTex0].strName);
		fprintf(pFile, "    </image>\n");

		fprintf(pFile, "    <image id=\"%s_dds\">\n", strTex1);
		fprintf(pFile, "      <init_from>./tex/%s</init_from>\n", m_pTexture[pMaterial[a].iTex1].strName);
		fprintf(pFile, "    </image>\n");

		fprintf(pFile, "    <image id=\"%s_dds\">\n", strTex2);
		fprintf(pFile, "      <init_from>./tex/%s</init_from>\n", m_pTexture[pMaterial[a].iTex2].strName);
		fprintf(pFile, "    </image>\n");
	}
	fprintf(pFile, "  </library_images>\n");

	// visual scenes
	fprintf(pFile, "  <library_visual_scenes>\n");
	fprintf(pFile, "    <visual_scene id=\"MaxScene\">\n");
	fprintf(pFile, "      <node name=\"EnvironmentAmbientLight\">\n");
	fprintf(pFile, "        <instance_light url=\"#EnvironmentAmbientLight\"/>\n");
	fprintf(pFile, "      </node>\n");
	for(unsigned int a = 0; a < m_uiModelNum; a++)
	{
		for(unsigned int b = 0; b < m_pModel[a].uiObjectNum; b++)
		{
			char strName[128] = {0};
			//sprintf(strName, "%s_%d_%d_[%s]", strBaseName, a, b, m_pTexture[m_pModel[a].pObject[b].iTex0].strName);
			sprintf(strName, "%s_%d_%d", strBaseName, a, b);
			//sprintf(strName, "%s_%d_%d_%d", strBaseName, a, b, m_pModel[a].pObject[b].uiVertexSize);

			fprintf(pFile, "      <node id=\"node-%s\" name=\"%s\">\n", strName, strName);
			fprintf(pFile, "        <instance_controller url=\"#geom-%s-skin1\">\n", strName);
			fprintf(pFile, "          <skeleton>#node-%sBone0</skeleton>\n", strFriendly);
			fprintf(pFile, "          <bind_material>\n");
			fprintf(pFile, "            <technique_common>\n");
			fprintf(pFile, "              <instance_material symbol=\"%s\" target=\"#%s-material\"/>\n", pMaterial[m_pModel[a].pObject[b].uiMaterialId].strName, pMaterial[m_pModel[a].pObject[b].uiMaterialId].strName);
			fprintf(pFile, "            </technique_common>\n");
			fprintf(pFile, "          </bind_material>\n");
			fprintf(pFile, "        </instance_controller>\n");
			fprintf(pFile, "      </node>\n");
		}
	}
	// bone now
	if(!ExportColladaBone(pFile, m_pBone[0], strFriendly))
		return false;

	fprintf(pFile, "    </visual_scene>\n");
	fprintf(pFile, "  </library_visual_scenes>\n");


	// closing
	fprintf(pFile, "  <scene>\n");
	fprintf(pFile, "    <instance_visual_scene url=	\"#MaxScene\"/>\n");
	fprintf(pFile, "  </scene>\n");
	fprintf(pFile, "</COLLADA>\n");

	// we're done here
	delete[] pBone;
	fclose(pFile);
	return true;
}

//+----------------------------------------------------------------> ExportColladaBone()

bool cOneechan::ExportColladaBone(FILE *pFile, cOneechanBone &p, const char *strFriendly)
{
	float x = p.mTransform._41;
	float y = p.mTransform._42;
	float z = p.mTransform._43;
	fprintf(pFile, "      <node id=\"node-%sBone%d\" name=\"%sBone%d\" sid=\"%sjoint%d\" type=\"JOINT\">\n", strFriendly, p.uiId, strFriendly, p.uiId, strFriendly, p.uiId);
	fprintf(pFile, "        <translate>%f %f %f</translate>\n", x, -z, y);
	if(p.uiChildNum)
	{
		for(unsigned int a = 0; a < p.uiChildNum; a++)
			ExportColladaBone(pFile, m_pBone[p.pChild[a]], strFriendly);
	}
	fprintf(pFile, "      </node>\n");
	return true;
}

//+----------------------------------------------------------------> 