
#ifndef _ONEECHAN_H
#define _ONEECHAN_H

#include "main.h"

//+----------------------------------------------------------------> cOneechanVertex36

struct cOneechanVertex36
{
	short					x, y, z, w;	
	short					nx, ny, nz, nw;
	char					strData0[8];

	unsigned int			uiBoneId;
	float					fWeight;			// 1.0f. one bone per vertex
	short					u0, v0;
};

//+----------------------------------------------------------------> cOneechanVertex60

struct cOneechanVertex60
{
	short					x, y, z, w;	
	char					strData0[8];
	short					nx, ny, nz, nw;
	char					strData1[8];

	short					da, dr, dg, db;		// ARGB color
	unsigned int			uiBoneId[2];		// 2 bones per vertex
	float					fWeight[2];
	short					u0, v0;
};

//+----------------------------------------------------------------> cOneechanVertex84

struct cOneechanVertex84
{
	short					x, y, z, w;	
	char					strData0[16];
	short					nx, ny, nz, nw;
	char					strData1[16];

	short					da, dr, dg, db;		// ARGB color
	unsigned int			uiBoneId[3];		// 3 bones per vertex
	float					fWeight[3];
	short					u0, v0;
};

//+----------------------------------------------------------------> cOneechanVertex108

struct cOneechanVertex108
{
	short					x, y, z, w;	
	char					strData0[24];
	short					nx, ny, nz, nw;
	char					strData1[24];

	short					da, dr, dg, db;		// ARGB color
	unsigned int			uiBoneId[4];		// 4 bones per vertex
	float					fWeight[4];
	short					u0, v0;
};

//+----------------------------------------------------------------> 

struct cOneechanObject
{
	unsigned int			uiGroupId;
	unsigned int			uiVertexNum;
	unsigned int			uiVertexSize;
	unsigned int			uiIndexNum;
	unsigned int			uiFaceNum;
	unsigned int			uiBytesRead;

	unsigned int			uiMaterialId;
	int						iTex0;
	int						iTex1;
	int						iTex2;
	int						iTex3;

	WORD					*pIndex;
	cOneechanVertex36		*pV36;
	cOneechanVertex60		*pV60;
	cOneechanVertex84		*pV84;
	cOneechanVertex108		*pV108;
};

//+----------------------------------------------------------------> cOneechanModelInfo

struct cOneechanModel
{
	unsigned int			uiObjectNum;		// divide by 2
	unsigned int			uiOffset;
	vector<cOneechanObject>	pObject;
};

//+----------------------------------------------------------------> cOneechanTexture

struct cOneechanTexture
{
	unsigned int			uiOffset;
	char					strName[24];
};

//+----------------------------------------------------------------> cOneechanBoneGroup

struct cOneechanBoneGroup
{
	unsigned int			uiBoneNum;
	unsigned int			uiOffset;
	WORD					*pBoneId;
};

//+----------------------------------------------------------------> cOneechanMaterial

struct cOneechanMaterial
{
	int						iTex0;				// diffuse
	int						iTex1;				// normal
	int						iTex2;				// specular
	char					strName[32];
};

//+----------------------------------------------------------------> cOneechanBone

struct cOneechanBone
{
	D3DXMATRIX				mTransform;
	int						uiParent;
	unsigned int			uiChildNum;
	int						*pChild;
	unsigned int			uiId;
};

//+----------------------------------------------------------------> cOneechan

class cOneechan
{
public:
							cOneechan();

	bool					Load(const char *strOneechan);
	bool					Export(const char *strOneechan);
	bool					ExportMs(const char *strOneechan);
	bool					ExportCollada(const char *strOneechan, const char *strFriendly);
	void					Delete();

private:

	bool					ReadObject(FILE *pFile, cOneechanObject &p);
	bool					ExportColladaBone(FILE *pFile, cOneechanBone &p, const char *strFriendly);

	unsigned int			m_uiTag;			// TGF
	unsigned int			m_uiModelNum;
	unsigned int			m_uiInfoOffset;
	unsigned int			m_uiTextureOffset;
	unsigned int			m_uiInconnu;
	unsigned int			m_uiBoneNum;
	unsigned int			m_uiBoneOffset;
	unsigned int			m_uiBoneGroupOffset;

	unsigned int			m_uiTextureNum;
	unsigned int			m_uiBoneGroupNum;

	cOneechanModel			*m_pModel;
	cOneechanBone			*m_pBone;
	cOneechanBoneGroup		*m_pBoneGroup;
	cOneechanTexture		*m_pTexture;
};

#endif