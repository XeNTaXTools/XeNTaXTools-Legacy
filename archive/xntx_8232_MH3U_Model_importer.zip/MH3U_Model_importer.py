bl_info = {
    "name": "MH3U Model importer",
    "category": "Import-Export",
    "author": "stetsVerneint",
    "location": "File > Import"
}
 
import bpy
 
# ImportHelper is a helper class, defines filename and
# invoke() function which calls the file selector.
from bpy_extras.io_utils import ImportHelper
from bpy.props import StringProperty, BoolProperty, EnumProperty
from bpy.types import Operator
from mathutils import Vector, Matrix, Euler
import bmesh
 
import struct
from struct import Struct
from collections import namedtuple
 
from math import radians
 
ushort_struct = Struct('>H')
uint_struct = Struct('>I')
float_struct = Struct('>f')
def read_half_float(source, offset):
    hf = ushort_struct.unpack_from(buff, offset)
    sign = hf >> 15
    exp = ((hf & 0x7c00) >> 10) - 16
    frac = hf & 0x03ff
    expF = exp + 127
    fl = uint_struct.pack((sign << 31) | (expF << 23) | (frac << 13))
    fl = float_struct.unpack(fl)
    return fl
 
 
class ImportMH3U(Operator, ImportHelper):
    """Import a model file from Monster Hunter 3 Ultimate with Bones and UV coordinates."""
    bl_idname = "custom_import.import_mh3u"
    bl_label = "Load MH3U MOD file (.mod)"
 
    # ImportHelper mixin class uses this
    filename_ext = ".mod"
 
    filter_glob = StringProperty(default="*.mod", options={'HIDDEN'}, maxlen=255)
 
    import_hitbox = BoolProperty(name="Import Hitboxes", description="Enable to import hitbox models",
        default=False)
 
    def execute(self, context):
        mod = None
        with open(self.filepath, 'rb') as mod_file:
            mod = mod_file.read()
 
        if mod[:4] != (0x00444f4d).to_bytes(4, byteorder='big'):
            self.report({'ERROR'}, 'Invalid file header, specified file is not valid mod file.')
            return {'CANCELLED'}
 
        ############### HEADER #################
        # Header structure
        # address type   field            Rathian value
        # 0x4     ushort unknown          230
        # 0x6     ushort num_bones        44
        # 0x8     ushort num_meshes       26
        # 0xa     ushort unknown          4
        # 0xc     uint   num_vertices     6481
        # 0x10    uint   unknown          16442 edges?
        # 0x14    uint   num_faces        5472
        # 0x18    uint   vert_size        233316 (0x38f64)
        # 0x1c    uint   unknown          0
        # 0x20    uint   unknown          11
        # 0x24    uint   used_bone_count  4
        # 0x28    uint   bone_offset      0x80
        # 0x2c    uint   unknown          0x1c10
        # 0x30    uint   unknown          0x1d70
        # 0x34    uint   item_offset      0x1f70
        # 0x38    uint   vertex_offset    0x2454
        # 0x3c    uint   face_offset      0x3b3b8
        # 0x40    uint   file_end  ?      0
 
        header = struct.unpack_from('>4H14I', mod, 4)
        
        _, num_bones, num_meshes, _, num_vertices, _, num_faces, vert_size, \
        _, _, used_bone_count, bone_offset, _, _, item_offset, vertex_offset, \
        face_offset, file_end = header
 
        print("Meshes: {}, Bones: {}, Vertices: {}".format(num_meshes, num_bones, num_vertices))
 
        ############### UNKNOWN VALUES #################
        # for Rathian, we now have 60 bytes of unknown (15 values)
        # address type   Rathian value
        # 0x44    float  - 180.0
        # 0x48    float      6.9
        # 0x4c    float    810.7 model dimensions
        # 0x50    float  - 783.5 shift x
        # 0x54    float  - 530.7 shift y
        # 0x58    float  - 614.3 shift z
        # 0x5c    ?          0
        # 0x60    float    783.5
        # 0x64    float    170.5
        # 0x68    float    628.0
        # 0x6c    ?          0
        # 0x70    uint    1000
        # 0x74    uint    3000
        # 0x78    uint       1
        # 0x7c    ?          0
 
        mvalues = struct.unpack_from('>10f5I', mod, 68)
        print("Mysterious Values:")
        print(mvalues)
        shift = Vector((mvalues[7], mvalues[9], mvalues[8])) / -200
        #shift = Vector((mvalues[3], mvalues[5], mvalues[4])) / 200
        model_scale = mvalues[2] / 100
 
        ################ BONES ###############
        # Bone header:
        # type   field
        # ushort id
        # ushort parent_id
        # ushort child_id ?
        # ushort unknown
        # float  unknown
        # float  bone length
        # float  bone_x
        # float  bone_y
        # float  bone_z
        # (bone_x, bone_y, bone_z) describe offset of head to tail
        #
        # bone matrix1: 16 floats, line by line 4x4 transformation matrix
        # transformation from head to tail. redundant information
        #
        # bone matrix2: same as above
        # transformation from origin to bone tail
        #
        # Rathian memory bounds:
        # header from 0x80 to 0x49f
        # mat1 from 0x4a0 to 0xf9f
        # mat2 from 0xfa0 to 0x1aa0
 
        Bone = namedtuple('Bone', ['id', 'parent_id', 'child_id', 'unknown_id', 'float_A', 'float_B',
            'bone_x', 'bone_y', 'bone_z'])
        bones = {}
        bones_seq = []
        bone_struct = Struct('>4B5f')
 
        for i in range(num_bones):
            bone_values = bone_struct.unpack_from(mod, bone_offset + i * bone_struct.size)
            b = Bone(*bone_values)
            bones[b.id] = b
            bones_seq.append(b)
        print("Read {} Bones.".format(len(bones)))
        
        mat_location = bone_offset + num_bones * bone_struct.size
 
        bone_mat_struct = Struct('>16f')
        mat1 = []
 
        for i in range(num_bones):
            bone_mat = bone_mat_struct.unpack_from(mod, mat_location + i * bone_mat_struct.size)
            mat = Matrix((bone_mat[:3], bone_mat[8:11], bone_mat[4:7], bone_mat[12:15]))
            mat1.append(mat)
 
        mat2_location = bone_offset + num_bones * bone_struct.size + num_bones * bone_mat_struct.size
        mat2 = []
 
        for i in range(num_bones):
            bone_mat = bone_mat_struct.unpack_from(mod, mat2_location + i * bone_mat_struct.size)
            mat = Matrix((bone_mat[:3], bone_mat[8:11], bone_mat[4:7], bone_mat[12:15]))
            mat2.append(mat)
 
        bpy.ops.object.add(type='ARMATURE',enter_editmode=True,location=(0,0,0))
        arm_ob = context.object
        arm_ob.show_x_ray = True
        arm_ob.name = "Armature"
        amt = arm_ob.data
        amt.name = arm_ob.name+'Amt'
 
        bpy.ops.object.mode_set(mode='EDIT')
        for i in range(num_bones):
            b = bones_seq[i]
            bone = amt.edit_bones.new(str(b.id))
            bone.head = mat2[i].row[3]
            bone.tail = mat2[i].row[3] - 50 * mat1[i].row[3].normalized()
            if bone.head == bone.tail:
                bone.tail = mat2[i].row[3] + Vector((0, -100, 0))
            bone.align_roll(mat2[i].row[2])
            bone.transform(mat2[i].to_3x3().inverted() * -1)
            bone.head *= model_scale
            bone.head += shift
            bone.tail *= model_scale
            bone.tail += shift
        for b in bones.values():
            if b.parent_id != 0xff:
                bone = amt.edit_bones[str(b.id)]
                parent_bone = amt.edit_bones[str(bones_seq[b.parent_id].id)]
                bone.parent = parent_bone
        for b in bones.values():
            bone = amt.edit_bones[str(b.id)]
            if len(bone.children) == 1:
                child = bone.children[0]
                bone.tail = child.head
                child.use_connect = True
 
 
        bpy.ops.object.mode_set(mode='OBJECT')
 
        """transform_matrix = Matrix(((1, 0, 0, 0),
                                   (0, 0, 1, 0),
                                   (0, 1, 0, 0),
                                   (0, 0, 0, 1)))
        arm_ob.matrix_world = transform_matrix"""
        arm_ob.select = False
 
        # The next 256 bytes contain the mapping between the ids used by parent_id
        # and bone id. We don't need this, as the bones are sequentially defined
        # and we already have this information.
        # Rathian location 0x1aa0
        strange_map_start = mat2_location + num_bones * bone_mat_struct.size
 
        # Next part seems important, but I don't know why yet.
        # Several arrays of indices
        # Rathian location 0x1ba0
        bone_map_start = strange_map_start + 256
        bone_map = []
        pos = bone_map_start
        for i in range(used_bone_count): #probably not a good name?
            count = struct.unpack_from('>I', mod, pos)[0]
            bmap = struct.unpack_from('{}B'.format(count), mod, pos+4)
            bone_map.append(bmap)
            pos += 28
 
        # Next part is unknown, lots of 0s, some float infinity, some indices
        # and several strings, possibly shaders?
        # Rathian has XfB_N__E_m00_body, XfBAN__E0__m02_wing_l,
        # XfBAN__E0__m01_wing_r and XfB__m03_eye
        # Rathian location 0x1c10
 
        ################## MESH INFORMATION ###################
        # for each mesh
        # type   field         Rathian value for mesh 1
        # ushort unknown       0xefdf
        # ushort vertex_count  18
        # ushort unknown       48
        # ushort unknown       0x00ff
        # ubyte  VId2          132
        # ubyte  VId           0
        # ubyte  VSize         36
        # ubyte  VType         14
        # uint   VertStart     0
        # ushort unknown       0
        # ushort unknown       0
        # uint   unknown       0xf606f017
        # uint   FacePos       0
        # uint   FaceCount     54
        # uint   unknown       0
        # ushort MeshID        0 (+1?)
        # ushort bone0         1 (+1?)
        # ushort Vstart        0
        # ushort VEnd          0
        # uint   Mshj          0x0772bfc8
        #
        # Rathian location 0x1f60
 
        mesh_info_struct = Struct('>4H4BI2H4I4HI')
        MeshInfo = namedtuple('MeshInfo', ['unk1', 'vertex_count', 'unk2', 'unk3',
            'VId2', 'VId', 'vertex_size', 'vertex_type', 'vertex_index_start', 'unk4',
            'unk5', 'unk6', 'face_pos', 'face_count', 'unk7', 'mesh_id', 'bone0',
            'v_start', 'v_end', 'Mshj'])
        mesh_info = []
 
        for i in range(num_meshes):
            info = MeshInfo(*mesh_info_struct.unpack_from(mod, item_offset + i * mesh_info_struct.size))
            mesh_info.append(info)
            print(info)
 
        ################ VERTEX INFORMATION ################
        # depends on different formats
        # vertex_size = 12:
        # short  x
        # short  y
        # short  z
        # ubyte  bone1
        # ubyte  bone2
        # hfloat u
        # hfloat v
        # bone weights implicitly 0 and 1. Why even have two bones?
        #
        # vertex_size = 16:
        # short  x
        # short  y
        # short  z
        # short  weight1
        # hfloat u
        # hfloat v
        # ubyte  unknown
        # ubyte  bone1
        # ubyte  unknown
        # ubyte  bone2
        # weight2 is 1 - weight1
        #
        # vertex_size = 20, vertex_type in (12,14,16,18)
        # short  x
        # short  y
        # short  z
        # ubyte  bone1
        # ubyte  bone2
        # 8 byte unknown
        # hfloat u
        # hfloat v
        # weights are implicitly 0 and 1. this is an odd one.
        #
        # vertex_size = 20, vertex_type in (15,19)
        # short  x
        # short  y
        # short  z
        # short  p1 ?
        # ubyte  bone1
        # ubyte  bone2
        # ubyte  bone3
        # ubyte  bone4
        # ubyte  weight1
        # ubyte  weight2
        # ubyte  weight3
        # ubyte  weight4
        # hfloat u
        # hfloat v
        #
        # vertex_size = 24, VId2 = 129
        # short  x
        # short  y
        # short  z
        # ubyte  bone1
        # ubyte  bone2
        # 8 bytes unknown
        # hfloat u
        # hfloat v
        # 4 bytes unknown
        #
        # vertex_size = 24, VId2 = 130
        # short  x
        # short  y
        # short  z
        # short  weight1 signed? that doesn't sound right.
        # 8 bytes unknown
        # hfloat u
        # hfloat v
        # hfloat bone1
        # hfloat bone2 downcast to int wtfbbq
        # weight2 is 1 - weight1
        #
        # vertex_size = 28, vertex_type = 16, VId2 != 132
        # OR
        # vertex_size = 28, VId2 in (131, 132)
        # short  x
        # short  y
        # short  z
        # short  weight1
        # 8 bytes unknown
        # ubyte  bone1
        # ubyte  bone2
        # ubyte  bone3
        # ubyte  bone4
        # hfloat u
        # hfloat v
        # hfloat weight2
        # hfloat weight3
        # weight4 is 1-(weight1+weight2+weight3)
        #
        # vertex_size = 28, VId = 128
        # float  x
        # float  y
        # float  z
        # 8 bytes unknown
        # hfloat u
        # hfloat v
        # ubyte weight1
        # ubyte weight2
        # ubyte weight3
        # ubyte weight4
        # bone implicit?
        #
        # vertex_size = 28, VId in (129, 130)
        # short  x
        # short  y
        # short  z
        # short  weight1
        # 8 bytes unknown
        # hfloat u
        # hfloat v
        # hfloat bone1
        # hfloat bone2 downcast to int...
        # 4 bytes unknown
        # weight2 is 1-weight1
        #
        # vertex_size = 28, vertex_type = 19,
        # short  x
        # short  y
        # short  z
        # 2 bytes unknown
        # ubyte  boneid x8
        # ubyte  weight x8
        # hfloat u
        # hfloat v
        #
        # vertex_size = 32
        # short  x
        # short  y
        # short  z
        # short  weight1
        # 8 bytes unknown
        # ubyte  boneid x4
        # hfloat u
        # hfloat v
        # hfloat weight2
        # hfloat weight3
        # 4 bytes unknown
        # weight4 is 1-(weight1+weight2+weight3)
        #
        # vertex_size = 36, vertex_type = 14 <- Rathian has such vertices
        # float  x
        # float  y
        # float  z
        # 24 bytes unknown
        # I'm not even kidding, that's it.
        #
        # vertex_size = 36, vertex_type = 12 <- Rathian has such vertices
        # float  x
        # float  y
        # float  z
        # 4 bytes unknown
        # float  u
        # flaot  v
        # ubyte  bone1
        # ubyte  bone2
        # ubyte  weight1
        # ubyte  weight2
        # 8 bytes unknown
        #
        # Rathian location 0x2454
 
        # The importer is currently only being tested with Rathian, so only the
        # last two are supported right now.
        t14_struct = Struct('>3f24B')
        t12_struct = Struct('>6f4B8B')
 
        face_struct = Struct('>3H')
 
        Vertex = namedtuple('Vertex', ['x', 'y', 'z', 'u', 'v', 'weights'])
 
        vert_pos = vertex_offset
        face_pos = face_offset
 
        for i in range(num_meshes):
            mesh = mesh_info[i]
            if mesh.vertex_type == 14 and not self.import_hitbox:
                vert_pos += mesh.vertex_size * mesh.vertex_count
                face_pos += face_struct.size * mesh.face_count // 3
                continue
            verts = []
            for j in range(mesh.vertex_count):
                if mesh.vertex_size == 36 and mesh.vertex_type == 14:
                    data = t14_struct.unpack_from(mod, vert_pos)
                    vert = Vertex(data[0], data[1], data[2], 0, 0, [])
                    verts.append(vert)
                elif mesh.vertex_size == 36 and mesh.vertex_type == 12:
                    data = t12_struct.unpack_from(mod, vert_pos)
                    vert = Vertex(data[0], data[1], data[2], data[4], data[5],
                        ((data[6], data[8] / 255.0), (data[7], data[9] / 255.0)))
                    verts.append(vert)
                else:
                    raise RuntimeError(("Unknown vertex format. vertex_size {}, "
                        "vertex_type {}, VId2 {}, VId {}").format(mesh.vertex_size, 
                            mesh.vertex_type, mesh.VId2, mesh.VId))
                vert_pos += mesh.vertex_size
 
            fcs = []
            for j in range(mesh.face_count // 3):
                data = face_struct.unpack_from(mod, face_pos)
                f1 = data[0] - mesh.vertex_index_start# +1 ?
                f2 = data[1] - mesh.vertex_index_start
                f3 = data[2] - mesh.vertex_index_start
                fcs.append((f1, f2, f3))
                face_pos += face_struct.size
 
            me = bpy.data.meshes.new(str(i))
            ob = bpy.data.objects.new(str(i), me)
            ob.location = (0,0,0)
            bpy.context.scene.objects.link(ob)
            me.from_pydata([Vector((v.x, v.z, v.y)) * model_scale + shift for v in verts], [], fcs)
            me.update(calc_edges=True)
 
            ob.parent = arm_ob
            ob.select = True
            bpy.ops.object.shade_smooth()
            ob.select = False
 
            if mesh.vertex_type != 14:
                me.uv_textures.new("UV")
                bm = bmesh.new()
                bm.from_mesh(me)
                bm.faces.ensure_lookup_table()
 
                uv_layer = bm.loops.layers.uv[0]
                for i in range(mesh.face_count // 3):
                    face = fcs[i]
                    for x in range(3):
                        bm.faces[i].loops[x][uv_layer].uv = \
                            (verts[face[x]].u, verts[face[x]].v)
                bm.to_mesh(me)
                bm.free()
 
                vgroups = {}
                def addv(group, vertex, weight):
                    if group not in vgroups:
                        vgroups[group] = []
                    vgroups[group].append((vertex, weight))
                for i in range(mesh.vertex_count):
                    v = verts[i]
                    for ind, w in v.weights:
                        if w != 0.0:
                            b = bones_seq[bone_map[mesh.mesh_id][ind]].id
                            addv(b, i, w)
                for name, vgroup in vgroups.items():
                    grp = ob.vertex_groups.new(str(name))
                    for (v, w) in vgroup:
                        grp.add([v], w, 'REPLACE')
 
                modifier = ob.modifiers.new('Armature', 'ARMATURE')
                modifier.object = arm_ob
                modifier.use_bone_envelopes = False
                modifier.use_vertex_groups = True
 
 
        return {'FINISHED'}
 
 
# Only needed if you want to add into a dynamic menu
def menu_func_import(self, context):
    self.layout.operator(ImportMH3U.bl_idname, text="MH3U MOD (.mod)")
 
 
def register():
    bpy.utils.register_class(ImportMH3U)
    bpy.types.INFO_MT_file_import.append(menu_func_import)
 
 
def unregister():
    bpy.utils.unregister_class(ImportMH3U)
    bpy.types.INFO_MT_file_import.remove(menu_func_import)
 
 
if __name__ == "__main__":
    try:
        unregister()
    except:
        pass
    register()