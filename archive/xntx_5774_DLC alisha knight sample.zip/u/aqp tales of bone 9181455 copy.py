# coding=gbk
class switch(object):
	def __init__(self, value):
		self.value = value
		self.fall = False

	def __iter__(self):
		"""Return the match method once, then stop"""
		yield self.match
		raise StopIteration
    
	def match(self, *args):
		"""Indicate whether or not to enter a case suite"""
		if self.fall or not args:
			return True
		elif self.value in args: # changed for v1.5, see below
			self.fall = True
			return True
		else:
			return False
from inc_noesis import *

import noesis

#rapi methods should only be used during handler callbacks
import rapi

#registerNoesisTypes is called by Noesis to allow the script to register formats.
#Do not implement this function in script files unless you want them to be dedicated format modules!
def registerNoesisTypes():
	handle = noesis.register("Tales of Zestiria", ".dpd")
	noesis.setHandlerTypeCheck(handle, talesofCheckType)
	noesis.setHandlerLoadModel(handle, talesofLoadModel)
	#noesis.setHandlerWriteModel(handle, pso2WriteModel)
	#noesis.setHandlerWriteAnim(handle, pso2WriteAnim)
	#noesis.logPopup()
	print("The log can be useful for catching debug prints from preview loads.\nBut don't leave it on when you release your script, or it will probably annoy people.")
	print("check mode on")
	return 1

#check if it's this type based on the data

def talesofCheckType(data):
	bs = NoeBitStream(data)
	aqoMagic = bs.readInt()
	if aqoMagic != 0x46445044:
		return 0
	return 1       

#load the model
def talesofLoadModel(data, mdlList):
	ctx = rapi.rpgCreateContext()
	bs = NoeBitStream(data)
	Bones = []
	BonePallet_Test = []
	Bone_Pallet = []
	Bone_Matrix = []
	Bone_Name = []
	Bone_Parent = []
	vertSize = []
	vertCount = []
	vtxeOffset = []
	vtxlOffset = []
	psetOffset = []
	Weight_pos = []
	BoneIndex_pos = []
	UV_pos = []
	UV2_pos = []
	Face_Count = []
	Vert_Buff = []
	vertgroupbuff_Startoffset = []
	x = []

	###
	texList = []
	matList = []
	###


	#bs.seek(0xb8 ,NOESEEK_REL)
	#BoneParent = bs.readInt()
	#Bone_Parent.append(BoneParent)
	print("Tales of Zestiria")
	print(" Model Boners preview")
	

	#boneFileName = rapi.getDirForFilePath(rapi.getInputName()) + rapi.getLocalFileName(rapi.getInputName()).rstrip(".aqo") + ".aqn"
	boneFileName = "00000064.dpd"
	#print("name=",[boneFileName])
	#if (rapi.checkFileExists(boneFileName)):
                #boneData = rapi.loadIntoByteArray(boneFileName)
                #if boneData is not None:
                        #bd = NoeBitStream(boneData)

	boneData = rapi.loadIntoByteArray(boneFileName)
	bd = NoeBitStream(boneData)

	bd.seek(0x14,NOESEEK_ABS)
	tale_offset_goto_toanimefile_start = bd.readInt()
	bd.seek(-0x4,NOESEEK_REL)
	bd.seek(tale_offset_goto_toanimefile_start,NOESEEK_REL)
	
	bd.seek(0x14,NOESEEK_REL)
	bonechunknumber = bd.readInt()
	bonechunknumber_1st = []
	bonechunknumber_1st = bonechunknumber
	bd.seek(-0x18,NOESEEK_REL)

	bd.seek(0x40,NOESEEK_REL)
	tale_offset_goto_bone_m_start = bd.readInt()
	tales_bone_m_start = []
	tales_bone_m_start = bd.tell()+tale_offset_goto_bone_m_start-4
	bd.seek(-0x44,NOESEEK_REL)
	print("tales_bone_m at",hex(tales_bone_m_start))
	
	bd.seek(0x68,NOESEEK_REL)
	bd.seek(0x20,NOESEEK_REL)
	print("bonechunknumber=",[bonechunknumber])
	print("bone pin at",hex(bd.tell()))

	tales_bone_pin_index_start = []
	tales_bone_pin_index_start = bd.tell()
	bd.seek(0x8*bonechunknumber,NOESEEK_REL)
	print("tales_BONE_parent_start at",hex(bd.tell()))
	tales_BONE_parent_start = []
	tales_BONE_parent_start = bd.tell()
	chunkStart = []
	chunkStart = bd.tell()

	bd.seek(0x8*bonechunknumber,NOESEEK_REL)
	tale_bone_NameOffset_start = []
	tale_bone_NameOffset_start = bd.tell()
	bd.seek(0x4*bonechunknumber,NOESEEK_REL)
	print("tales_bone_name_start at",hex(bd.tell()))
	tales_bone_name_start = []
	tales_bone_name_start = bd.tell()

	
	#return 0
	##########################################
	#tales_bone_pin_index_start = 0x118    ## [?? 28 00 00]
	#tales_BONE_parent_start = 0x360
	#bd.seek(tales_BONE_parent_start, NOESEEK_ABS)   ##BONE parent start
	#tales_bone_m_start = []
	#tales_bone_m_start = 0xA10
	###tales_bone_m.inverse()_start = 0x23f0

	#tales_bone_name_start = []
	#tales_bone_name_start = 0x6CC
	#chunkStart = bd.tell()
	#start = bd.tell()
	#print("START=",[hex(start)])
	#chunkStart = bd.tell() - 0x4
	#bd.seek(chunkStart - 0x20,NOESEEK_ABS)
	#bonechunknumber =  73
	#print("bonechunknumber=",[bonechunknumber])
	########################################

	tales_bone_pins = []
	bd.seek(tales_bone_pin_index_start, NOESEEK_ABS)
	for i_read_bonepin in range(0,bonechunknumber):
                tales_bone_pins.append(bd.readInt())
	print("tales_bone_pins=",tales_bone_pins)
	
	bd.seek(tales_BONE_parent_start, NOESEEK_ABS)   ##BONE parent start
	
	#bd.seek(chunkStart -0x3C ,NOESEEK_ABS)
	#ABS =JUMP TO THE address
	#bonechunksize =  bd.readUByte()
	#print("bonechunksize=",[0xb0])
	# bonechunksize at address 0x74,  0xb0=176
	#bit start from aqo, after = ,the first seek start from bd

	
	
	ii = 0
	while ii < bonechunknumber:
                bd.seek(chunkStart + ii*0x8 +0x4 ,NOESEEK_ABS)
                ##print("chunkStart1",hex(chunkStart))
                #nexts =  bd.tell()
                #print("nexts =",[hex(nexts)])
                print("bd at",hex(bd.tell()))
                BoneParent = bd.readShort()

                Bone_Parent.append(BoneParent)
                #print("  boneparent=",[Bone_Parent])
                
                
                
                

                bd.seek(tales_bone_m_start+ ii*0x40,NOESEEK_ABS)
                
                #print("readint=",[hex(bd.readInt())])
                #print("readint=",[hex(bd.readInt())])
                #print("readint=",[hex(bd.readInt())])
                #print("readint=",[hex(bd.readInt())])
                #print("test=",[hex(test)])
                #>4 ^3 MAT43,log show ( , , ,)rotation 90 o
                BoneMatrix = NoeMat44.fromBytes(bd.readBytes(64)).toMat43()
                #bd.seek(-0x40 ,NOESEEK_REL)
                #print("to mat44=",NoeMat44.fromBytes(bd.readBytes(64)))
                #matrix {^4 x >4} 64byte
                #print("BoneMatrix=",[BoneMatrix])
                #Bone_Matrix.append(BoneMatrix.inverse())
                
                #############
                Bone_Matrix.append(BoneMatrix)
                ### in"Tales of Zestiria", the first series bone matrix donnt need to inverse
                ###                            second series            is bone_matri.inverse()
                ###############
                #matrix array after inverse
                #print("inverse BoneMatrix =",[BoneMatrix.inverse()])
                print("xyz =",[Bone_Matrix[ii][3]])
                #print("[0]=",BoneMatrix[0])
                #print("[0][1]=",BoneMatrix[0][1])
                #return 0
        
                bd.seek(tales_bone_name_start,NOESEEK_ABS) 
                bonenamestart = bd.tell()
                while bd.readByte() != 0:
                        if bd.readByte() == 0:
                                break
                bonenameend = bd.tell()
                while bd.readByte() == 0:
                        skipblock=1
                tales_bone_name_start = bd.tell()-1
                #print("next name start at",hex(tales_bone_name_start))
                bd.seek(bonenamestart,NOESEEK_ABS)

                boneName = bd.readBytes(int(bonenameend-bonenamestart) - 1).decode("ASCII")
                print("  bonename=",[boneName])
                Bone_Name.append(boneName)
                #chunkStart = chunkStart + 0xb0
                #                       + bonechunksize
                ii = ii + 1
        
	print("length bone_matrix=",len(Bone_Matrix))
	print("len Bone_Parent=",len(Bone_Parent))
	print("len Bone_Name=",len(Bone_Name))
	############################################
	#for a in range(0,len(Bone_Matrix)):
                
                #bn = NoeBone(a, Bone_Name[a], Bone_Matrix[a], None, Bone_Parent[a])
                #Bones.append(bn)
	###########################################
	#print("length bone_matrix=",len(Bone_Matrix))
	#mdl = rapi.rpgConstructModel()
	#mdl.setBones(Bones)
	
	#########################################----#  THE SECONDE .dpd file
	boneFileName = "00000a7e.dpd"
	boneData = rapi.loadIntoByteArray(boneFileName)
	bd = NoeBitStream(boneData)
	#########################################----#
	###**********************************************###############copy above code
	bd.seek(0x14,NOESEEK_ABS)
	tale_offset_goto_toanimefile_start = bd.readInt()
	bd.seek(-0x4,NOESEEK_REL)
	bd.seek(tale_offset_goto_toanimefile_start,NOESEEK_REL)
	
	bd.seek(0x14,NOESEEK_REL)
	bonechunknumber = bd.readInt()
	bd.seek(-0x18,NOESEEK_REL)
	
	bd.seek(0x40,NOESEEK_REL)
	tale_offset_goto_bone_m_start = bd.readInt()
	tales_bone_m_start = []
	tales_bone_m_start = bd.tell()+tale_offset_goto_bone_m_start-4
	bd.seek(-0x44,NOESEEK_REL)
	print("tales_bone_m at",hex(tales_bone_m_start))
	
	bd.seek(0x68,NOESEEK_REL)
	bd.seek(0x20,NOESEEK_REL)
	print("bonechunknumber=",[bonechunknumber])
	print("bone pin at",hex(bd.tell()))

	tales_bone_pin_index_start = []
	tales_bone_pin_index_start = bd.tell()
	bd.seek(0x4*bonechunknumber,NOESEEK_REL)
	print("tales_BONE_parent_BonePin_version_start at",hex(bd.tell()))
	tales_BONE_parent_BonePin_version_start = []
	tales_BONE_parent_BonePin_version_start = bd.tell()
	
	bd.seek(tales_bone_pin_index_start,NOESEEK_ABS)
	bd.seek(0x8*bonechunknumber,NOESEEK_REL)
	print("tales_BONE_parent_start at",hex(bd.tell()))
	tales_BONE_parent_start = []
	tales_BONE_parent_start = bd.tell()
	chunkStart = []
	chunkStart = bd.tell()

	bd.seek(0x8*bonechunknumber,NOESEEK_REL)
	tale_bone_NameOffset_start = []
	tale_bone_NameOffset_start = bd.tell()
	bd.seek(0x4*bonechunknumber,NOESEEK_REL)
	print("tales_bone_name_start at",hex(bd.tell()))
	tales_bone_name_start = []
	tales_bone_name_start = bd.tell()

	bd.seek(tales_bone_pin_index_start, NOESEEK_ABS)
	for i_read_bonepin in range(0,bonechunknumber):
                tales_bone_pins.append(bd.readInt())
	print("tales_bone_pins=",tales_bone_pins)
	
	bd.seek(tales_BONE_parent_start, NOESEEK_ABS) 
	ii = 0
	while ii < bonechunknumber:
                bd.seek(tales_BONE_parent_BonePin_version_start + ii*0x4,NOESEEK_ABS)
                BoneParent_BonePin_version = []
                BoneParent_BonePin_version = bd.readInt()      #####the second .dpd file ,its bone parent+ 1st bonenumber ,ubless parent != -1
                if BoneParent_BonePin_version != -1:
                        BoneParent = tales_bone_pins.index(BoneParent_BonePin_version)
                else:
                        BoneParent = BoneParent_BonePin_version

                Bone_Parent.append(BoneParent)
                bd.seek(tales_bone_m_start+ ii*0x40,NOESEEK_ABS)
                BoneMatrix = NoeMat44.fromBytes(bd.readBytes(64)).toMat43()
                Bone_Matrix.append(BoneMatrix)
                bd.seek(tales_bone_name_start,NOESEEK_ABS) 
                bonenamestart = bd.tell()
                while bd.readByte() != 0:
                        if bd.readByte() == 0:
                                break
                bonenameend = bd.tell()
                while bd.readByte() == 0:
                        skipblock=1
                tales_bone_name_start = bd.tell()-1
                bd.seek(bonenamestart,NOESEEK_ABS)

                boneName = bd.readBytes(int(bonenameend-bonenamestart) - 1).decode("ASCII")
                print("  bonename=",[boneName])
                Bone_Name.append(boneName)
                ii = ii + 1
	print("length bone_matrix=",len(Bone_Matrix))
	print("len Bone_Parent=",len(Bone_Parent))
	print("len Bone_Name=",len(Bone_Name))

	##2222222#######################################
	for a in range(0,len(Bone_Matrix)):
                
                bn = NoeBone(a, Bone_Name[a], Bone_Matrix[a], None, Bone_Parent[a])
                Bones.append(bn)
	##2222222##################################
	###**********************************************################^^^^^^^^^^^
	bd.seek(0x2c,NOESEEK_ABS)
	tale_JumpMeshNumber_start= bd.readInt()
	bd.seek(-0x4+tale_JumpMeshNumber_start,NOESEEK_REL)
	bd.seek(0x1c,NOESEEK_REL)
	print("Mesh_number at",hex(bd.tell()))
	tale_Mesh_number = []
	tale_Mesh_number = bd.readInt()
	print("Mesh_number =",tale_Mesh_number)

	Mesh_Bone_Maps_start = []
	Mesh_Bone_Maps_start_JumpOffset = bd.readInt()
	Mesh_Bone_Maps_start  = Mesh_Bone_Maps_start_JumpOffset+bd.tell() - 4
	print("Mesh_Bone_Maps_start at",hex(Mesh_Bone_Maps_start))
	Mesh_Bone_Maps_number= []
	Mesh_Bone_Maps_number = bd.readInt()
	print("Mesh_Bone_Maps_number =",Mesh_Bone_Maps_number)
	#return 0
	bd.seek(-0x28,NOESEEK_REL)
	bd.seek(0x30,NOESEEK_REL)
	print("bd0 at",hex(bd.tell()))

	while bd.readInt() == 0:               #move down 0x10 each time
                bd.seek(0xc,NOESEEK_REL)
	bd.seek(-0x4,NOESEEK_REL)
	print("bd at",hex(bd.tell()))
	bd.seek(0x1c*tale_Mesh_number,NOESEEK_REL)
	print("tale_mesh_name_start at",hex(bd.tell()))
	tale_mesh_name_start = []
	tale_mesh_name_start = bd.tell()
	#return 0
	########################################

                
	dpd_dat_Name = "00000a7f.dc5"
	#dpd_dat_Name = "00000a64.dat"
	dpd_dat_Data = rapi.loadIntoByteArray(dpd_dat_Name)
	bs = NoeBitStream(dpd_dat_Data)
	#tale_mesh_name_start = []
	#tale_mesh_name_start = 0x564
	bd.seek(tale_mesh_name_start,NOESEEK_ABS)
	print("bd at",hex(bd.tell()))
	Mesh_NANES = []
	tale_v_number = []  ####this_mesh_vertice_number
	tale_f_lenth  = []  ####this mesh face_vIndex lenth
	tale_uv_message_start = []   ### for TYPE "character"  model,
	tale_f_index_start = []      

	tale_v_1b_number = []   ### vertices belong to one v_group ,affect by onle one bone
	tale_v_2b_number = []
	tale_v_3b_number = []
	tale_v_4b_number = []

	tale_VertBuff = []
	tale_UVBuff   = []
	tale_FaceBuff = []
	#for rapi
	tale_Position = []
	tale_POSITIONS = []

	#tale_Mesh_number = 6

	#tales_mesh_bone_map_start = 0x2B898
	bd.seek(Mesh_Bone_Maps_start,NOESEEK_ABS)
	
	print("bd find bone map at=",hex(bd.tell()))
	#bd.seek(tales_mesh_bone_map_start,NOESEEK_ABS)
	Mesh_Bone_Maps = []
	read_mesh_bone_map = []
	for i_read_maps in range(0,Mesh_Bone_Maps_number):
                read_mesh_bone_map = bd.readInt()
                Mesh_Bone_Maps.append(read_mesh_bone_map)
                #i_read_maps+=1
	
	print("Mesh_Bone_Maps=",[hex(i_print) for i_print in Mesh_Bone_Maps])
	print("len()=",len(Mesh_Bone_Maps))
	#print("TURE Bone Order is",[tales_bone_pins.index(i) for i in Mesh_Bone_Maps])   ##bone order for the mesh ,only
	bone_pallet = []
	bone_pallet = [tales_bone_pins.index(i) for i in Mesh_Bone_Maps]
	print("bone_pallet=",bone_pallet)

	bd.seek(tale_mesh_name_start,NOESEEK_ABS)
	#return 0
	#tale_Mesh_number = 6 #6
	for i_mesh_number in range(0,tale_Mesh_number):
                mesh_name= bd.readString()
                print("mesh name=",mesh_name)
                Mesh_NANES.append(mesh_name)
                print("bd at",hex(bd.tell()))
                while bd.readByte() == 0:
                        skipblock=1
                bd.seek(-1,NOESEEK_REL)
                print("MOVE check bd",hex(bd.tell()))
                tale_v_number = bd.readUShort()
                tale_f_lenth = bd.readUShort()
                tale_uv_message_start = bd.readInt()
                tale_f_index_start = bd.readInt()
                tale_v_1b_number = bd.readInt()
                tale_v_2b_number = bd.readInt()
                tale_v_3b_number = bd.readInt()
                tale_v_4b_number = bd.readInt()
                tale_v_1234b_number = []
                tale_v_1234b_number = (tale_v_1b_number,tale_v_2b_number,tale_v_3b_number,tale_v_4b_number)
                
                print("give =",hex(tale_v_number),hex(tale_f_lenth),hex(tale_uv_message_start),hex(tale_f_index_start))
                print("v divide",hex(tale_v_1b_number),hex(tale_v_2b_number),hex(tale_v_3b_number),hex(tale_v_4b_number))
                #tale_vertSize_1b = 0x1c
                #tale_vertSize_2b = 0x20
                #tale_vertSize_3b = 0x24
                #tale_vertSize_4b = 0x28
                tale_vertSize_1234b = []
                tale_vertSize_1234b = (0x1c,0x20,0x24,0x28)
                #print("1234 FVF=",tale_vertSize_1234b,"example[1] =",tale_vertSize_1234b[1])
                #tale_VertBuff = bs.readBytes((tale_vertSize_1b*tale_v_1b_number))
                #rapi.rpgBindPositionBufferOfs(VertBuff, noesis.RPGEODATA_FLOAT, tale_vertSize_1b, 0)
                
                ###move .dat to read uv , default read the 1st uv floor  (in all ,there are 3 uv floor, 6 float+float0 >> 4*7bytes ,FVFsize=0x1c)
                bs.seek(tale_uv_message_start,NOESEEK_ABS)
                print("bs at",hex(bs.tell()))

                tale_UVBuff_1234b = []
                read_back = []
                tale_POSITIONS=bytearray()
                tale_Position=bytearray()

                vwList = [] ##copy from example
                mark_maxbone_index_inweight =[]            ##for checking Bone_Pallet number and data address
                mark_maxbone_index_inweight = 0
                
                for i_set1234 in range(0,4):
                        #read_v_pos_1234 = []
                        #read_v_pos_1234 = bd.tell()
                        address_from_read_VertBuff = []
                        address_from_read_VertBuff = bd.tell()
                        tale_VertBuff = bd.readBytes((tale_vertSize_1234b[i_set1234]*tale_v_1234b_number[i_set1234]))
                        for i_cut in range (0,tale_v_1234b_number[i_set1234]):
                                tale_Position.extend(tale_VertBuff[(0+tale_vertSize_1234b[i_set1234]*i_cut):(24+tale_vertSize_1234b[i_set1234]*i_cut)])
                                if i_set1234 >=0:

                                        address_before_readweight = []
                                        address_before_readweight = bd.tell()
                                        vwNum = i_set1234 + 1 ########bs.readInt()
                                        #print("vwNum=",vwNum)
                                        numWeights = tale_v_1234b_number[i_set1234]
                                        bd.seek(address_from_read_VertBuff+tale_vertSize_1234b[i_set1234]*i_cut+24,NOESEEK_ABS)
                                        #print("r=",hex(bd.tell()))
                                        #return 0
                                        bidx = []
                                        bwgt = []
                                        for k in range(0, vwNum):
                                                bidx.append(bd.readUByte())
                                                mark_maxbone_index_inweight = max(mark_maxbone_index_inweight,bidx[-1])
                                                #bidx.append(bd.readUByte()+0x27)
                                                #print("bidx=",type(bidx[-1]))
                                                #return 0
                                        bd.seek(0x3-i_set1234,NOESEEK_REL)
                                        #for k_add_0 in range(vwNum,4):
                                                #bidx.append(0)
                                                #print("bidx=",type(bidx[-1]))
                                                #return 0
                                        weight_tobe = []
                                        weight_tobe = 0.0
                                        for k in range(0, vwNum):
                                                if k == vwNum -1:
                                                        bwgt.append(1.0-weight_tobe)
                                                else:
                                                        bwgt.append(bd.readFloat())
                                                        #print("weigh2=,",bwgt[-1])
                                                        weight_tobe = weight_tobe+bwgt[-1]
                                                #print("read weight wrong",bwgt[-1])
                                                if bwgt[-1] >1 or bwgt[-1]<0:
                                                        print("read weight wrong,",bwgt)
                                                        print("dead at",hex(bd.tell()))
                                                        return 0
                                        #for k_add0 in range(vwNum,4):
                                                #bwgt.append(0.0)
                                        #print("id=",Bone_Name[bidx[0]],"//",Bone_Name[bidx[1]],"//",Bone_Name[bidx[2]],"//",Bone_Name[bidx[3]])
                                        #print("id=",bidx[0],"//",bidx[1],"//",bidx[2],"//",bidx[3])
                                        #print("bidx=",type(bidx[-1]),"bidx=",bidx)
                                        #return 0
                                        #print("weight,",bwgt)
                                        vwList.append(NoeVertWeight(bidx,bwgt))
                                        #print("weight number",vwList[-1].numWeights())
                                        bd.seek(address_before_readweight,NOESEEK_ABS)
                        print("position +",hex(len(tale_Position)))
                        print("maxbone_index WEIGHT=",mark_maxbone_index_inweight)
                        
                rapi.rpgBindPositionBufferOfs(tale_Position, noesis.RPGEODATA_FLOAT, 0x18, 0)
                rapi.rpgBindNormalBufferOfs(tale_Position, noesis.RPGEODATA_FLOAT, 0x18,12)
                #rapi.rpgBindPositionBufferOfs(tale_POSITIONS, noesis.RPGEODATA_FLOAT, 12, 0)

                fw = NoeFlatWeights(vwList)
                print("   kkk=",fw.weightsPerVert,".indices=",fw.numWeights)  #==1,skip 4 int or bytes
                rapi.rpgBindBoneIndexBuffer(fw.flatW[:fw.weightValOfs], noesis.RPGEODATA_INT, 4*fw.weightsPerVert, fw.weightsPerVert)
                rapi.rpgBindBoneWeightBuffer(fw.flatW[fw.weightValOfs:], noesis.RPGEODATA_FLOAT, 4*fw.weightsPerVert, fw.weightsPerVert)
                        
                tale_UVBuff   = bs.readBytes((tale_v_number*0x1c))   ## default 4*6+4=0x1c
                rapi.rpgBindUV1BufferOfs(tale_UVBuff, noesis.RPGEODATA_FLOAT,0x1c, 0x4)
                print("bs at",hex(bs.tell()))

                #######################
                rapi.rpgSetName(Mesh_NANES[i_mesh_number])
                rapi.rpgSetMaterial(str(i_set1234))
                #######################
                        
                bs.seek(tale_f_index_start,NOESEEK_ABS)  #bs.seek(tale_f_index_start+0x2,NOESEEK_ABS)
                print("bs at",hex(bs.tell()))
                tale_FaceBuff = bs.readBytes((tale_f_lenth* 2))
                print("bs at",hex(bs.tell()))
                #tale_Face_Count = 0x411
                tale_Face_Count = int(tale_f_lenth/1)
                print("tofind f_count = ",tale_f_lenth," /3=",tale_f_lenth/3,"int()=",tale_Face_Count)
                
                if len(bone_pallet) > 0:
                        rapi.rpgSetBoneMap(bone_pallet)
                        print("pallet set")
                                
                #rapi.rpgCommitTriangles(tale_FaceBuff, noesis.RPGEODATA_USHORT, tale_Face_Count,0)
                rapi.rpgCommitTriangles(tale_FaceBuff, noesis.RPGEODATA_USHORT, tale_Face_Count, noesis.RPGEO_TRIANGLE_STRIP, 1)
                print("bs at",hex(bs.tell()),type(noesis.RPGEO_TRIANGLE_STRIP),noesis.RPGEO_TRIANGLE_STRIP)

                #mdl = rapi.rpgConstructModel()
                #mdl.setBones(Bones)
                #mdlList.append(mdl)
                #rapi.rpgClearBufferBinds()
                #return 1
                #return 0
	
	#return 0
        ##########tales of ,code end##############
	mdl = rapi.rpgConstructModel()
	mdl.setBones(Bones)
	mdlList.append(mdl)
	rapi.rpgClearBufferBinds()
	return 1
