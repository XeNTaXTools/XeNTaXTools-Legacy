#  default.e3m importer by Bigchillghost
from inc_noesis import *
import copy

def registerNoesisTypes():
	handle = noesis.register("default.e3m", ".e3m")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadModel(handle, noepyLoadModel)
	#noesis.logPopup()
	return 1

#check if it's this type based on the data
def noepyCheckType(data):
	if len(data) < 0x80:
		return 0
	bs = NoeBitStream(data)
	if bs.readUByte() != 0xA:
		return 0
	return 1

#load the model
def noepyLoadModel(data, mdlList):
	#noesis.logPopup()
	bs = NoeBitStream(data)
	bs.seek(1, NOESEEK_ABS)
	boneCount = bs.readUByte()
	meshCount = bs.readUByte()
	# bone info
	bones = []
	matList = []
	for i in range(0, boneCount):
		boneName = noeStrFromBytes(bs.readBytes(0x20), "936")
		parentIndex = bs.readUByte()
		tran = NoeVec3.fromBytes(bs.readBytes(12))
		rot = NoeQuat3.fromBytes(bs.readBytes(12))
		boneMat = rot.toQuat().toMat43()
		boneMat[3] = tran
		bones.append( NoeBone(i, boneName, boneMat, None, parentIndex) )
		matList.append(boneMat)
	
	# meshes
	meshes = []
	baseName = rapi.getInputName().split("\\")[-1].split(".")[0]
	for i in range(0, meshCount):
		meshName = noeStrFromBytes(bs.readBytes(0x20), "936")
		uvCount = bs.readUShort()
		TexCoords = []
		vertIDs = [0]*uvCount
		weightNum = [0]*uvCount
		for j in range(0, uvCount):
			bs.seek(2, NOESEEK_REL)
			TexCoords.append(NoeVec3([bs.readFloat(), bs.readFloat(), 0.0]))
			vertIDs[j] = bs.readUShort()
			weightNum[j] = bs.readUByte()
		idxCount = bs.readUShort()
		idxData = bs.readBytes(idxCount*2)
		idxList = rapi.dataToIntList(idxData, idxCount, noesis.RPGEODATA_USHORT, NOE_LITTLEENDIAN)
		vertCount = bs.readUShort()
		splitPositions = []
		splitBlendIdxList = [0]*vertCount
		splitWeightList = [0.0]*vertCount
		for j in range(0, vertCount):
			bs.seek(2, NOESEEK_REL)
			boneID = bs.readUByte()
			weight = bs.readFloat()
			position = NoeVec3.fromBytes(bs.readBytes(12))
			position = matList[boneID]*position
			splitPositions.append(position)
			splitBlendIdxList[j] = boneID
			splitWeightList[j] = weight
		
		Positions = []
		vertWeightList = []
		for j in range(0, uvCount):
			vertID = vertIDs[j]
			weightCnt = weightNum[j]
			Positions.append(splitPositions[vertID])
			boneIDs = [0]*weightCnt
			weights = [0.0]*weightCnt
			for k in range(0, weightCnt):
				boneIDs[k] = splitBlendIdxList[vertID+k]
				weights[k] = splitWeightList[vertID+k]
			vertWeightList.append(NoeVertWeight(boneIDs, weights))
		mesh = NoeMesh(idxList, Positions, meshName, baseName)
		mesh.setUVs(TexCoords)
		mesh.weights = vertWeightList
		meshes.append(mesh)
	
	mdl = NoeModel(meshes)
	mdl.setBones(bones)
	mdlList.append(mdl)
	rapi.setPreviewOption("setAngOfs", "0 -90 0")
	
	return 1
