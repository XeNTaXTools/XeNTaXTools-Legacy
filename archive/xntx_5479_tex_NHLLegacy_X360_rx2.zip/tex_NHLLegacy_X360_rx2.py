from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("NHL Legacy (X360)", ".rx2")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
	#noesis.logPopup()
	return 1

#check if it's this type based on the data
def noepyCheckType(data):
    bs = NoeBitStream(data)
    Magic = bs.readBytes(7)
    if Magic != b'\x89\x52\x57\x34\x78\x62\x32':
        return 0
    return 1
	
def noepyLoadRGBA(data, texList):
    datasize = len(data) - 0x1000        
    bs = NoeBitStream(data, NOE_BIGENDIAN)
    #bs.seek(0x0, NOESEEK_ABS)
    imgWidth = 1024 #bs.readInt()            
    imgHeight = 1024 #bs.readInt()           
    bs.seek(0x1000, NOESEEK_ABS)        
    data = bs.readBytes(datasize)      
    data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 8)
    texFmt = noesis.NOESISTEX_DXT1
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1