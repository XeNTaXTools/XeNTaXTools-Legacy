It is a free importer for textured models from game Risen 3 on PC.

It requires Blender 249 and Python 26.

How use:
1.unpack importer.
2.run Blender249.blend

Steps for pak files:
1.in Blender Text Window press alt+p and select 0_na_imag.pak
2.in Blender Text Window press alt+p and select	0_na_mat.pak
3.in Blender Text Window press alt+p and select	0_na_skn.pak

Steps for skn files:
1.in Blender Text Window press alt+p and select	skn file
		
It don't import weighting and skeletons.