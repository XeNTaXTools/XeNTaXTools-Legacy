import newGameLib
reload(newGameLib)
from newGameLib import *
import Blender

	
def romParser(filename,g):
	data=g.read(g.fileSize())
	new=open(filename+'.dec','wb')
	try:data=zlib.decompress(data)
	except:print 'not zlib archive'
	new.write(data)
	new.close()
	
def getImagePath(filename,imgName):	
	
	Tex=None
	imgDir=gameDir+os.sep+'0_na_img'
	search=Searcher()
	search.dir=imgDir
	if imgName is not None:
		search.what=imgName.lower()
		search.run()
		if len(search.list)>0:
			texFile=search.list[0]
			file=open(texFile,'rb')
			p=BinaryReader(file)
			p.seek(44)
			Tex=texFile+'.dds'
			new=open(Tex,'wb')
			new.write(p.read(p.fileSize()-44))
			new.close()
			file.close()
			
			"""if os.path.exists(Tex.replace('.dds','.png'))==False:
				cmd=Cmd()
				cmd.input=Tex
				cmd.PNG=True
				cmd.run()
			Tex=Tex.replace('.dds','.png')"""
			
			
	if Tex is not None:
		print '    image:',imgName
	return Tex			
		
	
def matParser(filename,g):
	diffTex,normTex,specTex=None,None,None
	g.seek(44)
	g.word(4)
	w=g.i(12)
	g.seek(94)
	if w[3]==-1211053656:
		g.seek(172,1)
		imgName=g.word(g.H(1)[0])
		diffTex=getImagePath(filename,imgName)
		imgName=g.word(g.H(1)[0])
		normTex=getImagePath(filename,imgName)
		imgName=g.word(g.H(1)[0])
		specTex=getImagePath(filename,imgName)
	if w[3]==729966182:
		imgName=g.word(g.H(1)[0])
		diffTex=getImagePath(filename,imgName)
		g.seek(34,1)
		imgName=g.word(g.H(1)[0])
		normTex=getImagePath(filename,imgName)
		g.seek(34,1)
		imgName=g.word(g.H(1)[0])
		specTex=getImagePath(filename,imgName)
		g.seek(34,1)
		
	if w[3]==997074178:
		imgName=g.word(g.H(1)[0])
		diffTex=getImagePath(filename,imgName)
		g.seek(34,1)
		imgName=g.word(g.H(1)[0])
		normTex=getImagePath(filename,imgName)
		g.seek(34,1)
		imgName=g.word(g.H(1)[0])
		specTex=getImagePath(filename,imgName)
		g.seek(34,1)
		
	return diffTex,normTex,specTex
	

def decParser(filename,g):
	g.logOpen()
	skeleton=Skeleton()
	skeleton.draw()

	if '0_na_skn' in filename.lower():		
		gameDir=filename.lower().split(os.sep+'0_na_skn')[0]
		DBFile=gameDir+os.sep+'0_na_skn'+os.sep+'w_skn_0_na.db'
	elif '0_na_msh' in filename.lower():
		gameDir=filename.lower().split(os.sep+'0_na_msh')[0]
		DBFile=gameDir+os.sep+'0_na_msh'+os.sep+'w_msh_0_na.db'
	else:DBFile=None
	print 'DBFile:',DBFile
	matList=[]
	if DBFile is not None:
		file=open(DBFile,'rb')
		p=BinaryReader(file)
		allMatList=dbParser(DBFile,p)
		file.close()
		
		base=filename.split(os.sep)[-1].lower().split('.')[0]
		print base
		#print allMatList
		if base.lower() in allMatList:
			print 'mesh:',base
			
			for i in range(len(allMatList[base])):
				mat=Mat()
				mat.ZTRANS=True
				mat.TRIANGLE=True
				mat.name=allMatList[base][i][0]	
				print 'mat:',mat.name
				mat.IDStart=allMatList[base][i][1]
				mat.IDCount=allMatList[base][i][2]
				matDir=gameDir+os.sep+'0_na_mat'
				search=Searcher()
				search.dir=matDir
				search.what=allMatList[base][i][0]
				search.run()
				if len(search.list)>0:
					matFile=search.list[0]
					
					file=open(matFile,'rb')
					p=BinaryReader(file)
					mat.diffuse,mat.normal,mat.specular=matParser(matFile,p)
					print mat.diffuse
					file.close()
				matList.append(mat)
				#break
	else:
		print 'WARNING:db:',DBFile
	
			
	
	g.word(8)
	g.i(9)
	g.word(4)
	w=g.i(4)
	print w
	if w[1]==0:
		skeleton=Skeleton()
		#skeleton.SORT=True
		skeleton.ARMATURESPACE=True
		#skeleton.BONESPACE=True
		skeleton.NICE=True
		g.debug=True
		g.seek(0)
		g.word(8)
		g.i(9)
		offStart=g.tell()
		g.f(4)
		g.f(4)
		g.f(4)
		g.f(3)
		g.i(2)
		g.word(12)
		w=g.i(10)
		g.word(8)
		g.f(2)
		g.i(1)
		g.f(1)
		g.i(3)
		g.debug=False
		offsetList=g.i(w[7])
		bone=Bone()
		bone.name='root'
		skeleton.boneList.append(bone)
		for i in range(w[7]):
			bone=Bone()
			g.seek(offStart+offsetList[i])
			matrixA=Matrix4x4(g.f(16))
			matrixB=Matrix4x4(g.f(16))
			rot=matrixA.rotationPart()#.invert()#*matrixB.rotationPart().invert()
			pos=matrixA.translationPart()
			#matrix=TranslationMatrix(pos)*rot.resize4x4()
			matrix=rot.resize4x4()*TranslationMatrix(pos)
			
			bone.matrix=matrix#*matrixB.rotationPart().invert().resize4x4()
			u=g.i(7)
			print u
			bone.parentID=u[1]
			g.f(4)
			v=g.i(2)
			if v[0]==212:
				bone.name=g.word(32).replace('\xcd','')
				g.f(10)
				g.i(2)
				g.word(12)
			elif v[0]==208:
				bone.name=g.word(28).replace('\xcd','')
				g.f(9)
				g.i(3)
			elif v[0]==220:
				bone.name=g.word(40).replace('\xcd','')
				g.f(9)
				g.i(3)
				g.word(4)
			else:
				print 'WARNING:',v[0]
				break
			print bone.name	
			skeleton.boneList.append(bone)
		skeleton.draw()		
		#g.debug=True
		"""for i in range(w[6]):
			bone=Bone()
			t=g.tell()
			g.f(4)
			g.f(4)
			g.f(4)
			g.f(3)
			u=g.i(5)
			print u
			g.word(8)
			v=g.i(10)
			print v
			tv=g.tell()
			
			g.seek(offStart+v[8])			
			name=g.find('\x00')
			g.seek(offStart+v[9])			
			bone.name=g.find('\x00')
			nextOff=g.tell()
			
			g.seek(offStart+v[1])			
			print g.f(2)
			print g.i(2)
			
			g.seek(offStart+v[2])
			matrix=Matrix4x4(g.f(16))
			print matrix
			print g.f(3)
			print g.i(1)
			print g.f(2)
			print g.tell()
			
			print name,bone.name
			g.seek(tv)
			g.seek(t+128)
		g.seek(nextOff)
		g.find('\xcd'*12)
		g.debug=True
		g.i(2)"""
		
		g.tell()
	
	if w[1]==101:
		#g.debug=True
		mesh=Mesh()
		sys=Sys(filename)
		mesh.name=sys.base
		mesh.TRIANGLE=True
		mesh.indiceList=g.H(w[2]/2)
		w=g.i(4)
		print w
		for i in range(w[3]):
			print g.H(4)
		for i in range(w[0]/w[1]):
			t=g.tell()
			mesh.vertPosList.append(g.f(3))
			if w[1]==48:
				g.seek(t+24)
				mesh.vertUVList.append(g.f(2))
			if w[1]==56:
				g.seek(t+24)
				mesh.vertUVList.append(g.f(2))
			g.seek(t+w[1])
		mesh.matList=matList	
		#mesh.SPLIT=True
		mesh.BINDSKELETON=skeleton
		mesh.draw()	
	if w[1]==102:
		mesh=Mesh()
		sys=Sys(filename)
		mesh.name=sys.base
		mesh.TRIANGLE=True
		mesh.indiceList=g.i(w[2]/4)
		w=g.i(4)
		for i in range(w[3]):g.H(4)
		#g.seek(w[0],1)	
		for i in range(w[0]/w[1]):
			t=g.tell()
			mesh.vertPosList.append(g.f(3))
			if w[1]==56:
				g.seek(t+52)
				mesh.vertUVList.append(g.half(2))
			g.seek(t+w[1])
		mesh.matList=matList	
		#mesh.SPLIT=True
		mesh.BINDSKELETON=skeleton
		mesh.draw()	
		g.debug=True
		"""g.f(6)
		for i in range(18):
			g.f(3)
			g.i(1)
		g.H(112)	
		g.i(11)"""
	g.tell()
	g.logClose()
	
def csvParser(filename,file):
	lines=file.readlines()
	hashList={}
	for line in lines[1:]:
		line=line.strip().split('|')
		hash=line[0]
		name=line[1]
		hashList[hash]=name
	search=Searcher()
	sys=Sys(filename)
	search.dir=sys.dir
	search.what='.rom'
	search.run()
	for file in search.list:
		sys=Sys(file)
		if sys.ext=='rom':
			hash=sys.base.split('_')[-1]
			if hash in hashList:
				os.rename(file,sys.dir+os.sep+hashList[hash]+'.rom')
				
def dbParser(filename,g):
	
	g.logOpen()
	allMatList={}

	g.word(8)
	g.word(4)
	g.seek(16)
	g.word(4)
	fileCount=g.i(1)[0]
	
	for i in range(fileCount):
		g.debug=False	
		g.i(8)
		file=g.word(g.i(1)[0]).lower()
		#print file
		allMatList[file]=[]
		
		t=g.tell()
		size=g.i(1)[0]
		g.i(10)
		g.seek(t+size)
		
		t=g.tell()
		size=g.i(1)[0]
		g.word(4)
		g.i(6)
		
		matCount=g.i(1)[0]
		for m in range(matCount):
			g.word(4)
			g.i(6)
			matName=g.word(g.H(1)[0])
			for j in range(8):
				v=g.i(4)
				if j==3:IDStart=v[0]
				if j==4:IDCount=v[0]
				
			g.i(3)
			g.H(1)
			g.i(1)
			count=g.i(1)[0]
			#g.logWrite('count')
			g.debug=False
			for j in range(count):
				tj=g.tell()	
				g.seek(tj+32)
			#g.debug=True
			g.tell()
			allMatList[file].append([matName,IDStart,IDCount])
			
		g.seek(t+size)
		
		g.i(1)
	
	g.tell()
	g.logClose()
	return allMatList
	
def pakParser(filename,g):
	#g.debug=True
	
	hashList={}
	
	sys=Sys(filename)
	sys.addDir(sys.base)
	
	g.i(1)[0]
	g.word(4)
	w=g.I(10)
	print w
	g.seek(w[6])
	
	print g.i(9)
	while(True):
		if g.tell()>=g.fileSize():break
		chunk=g.B(4)
		if chunk==(32,8,2,0):
			name=g.word(g.i(1)[0])
			g.B(1)[0]
			w=g.i(13)
			back=g.tell()
			g.seek(w[0])
			
			if len(hashList.keys())!=0:
				hash=name.split('.')[0].split('_')[-1]
				if hash in hashList:
					name=hashList[hash]
				
			
			filePath=sys.dir+os.sep+sys.base+os.sep+name
			new=open(filePath,'wb')
			new.write(zlib.decompress(g.read(w[11])))
			new.close()
			if '.csv' in name:
				file=open(filePath,'r')
				lines=file.readlines()
				for line in lines[1:]:
					line=line.strip().split('|')
					hash=line[0]
					name=line[1]
					hashList[hash]=name
				
			
			g.seek(back)
		elif chunk==(16,0,2,0):
			g.word(g.i(1)[0])
			g.B(33)
			#break
		elif chunk==(32,0,2,0):
			name=g.word(g.i(1)[0])
			g.B(1)[0]
			w=g.I(13)
			back=g.tell()
			g.seek(w[0])
			
			if len(hashList.keys())!=0:
				hash=name.split('.')[0].split('_')[-1]
				if hash in hashList:
					name=hashList[hash]
				
			filePath=sys.dir+os.sep+sys.base+os.sep+name
			new=open(filePath,'wb')
			new.write(g.read(w[11]))
			new.close()
			if '.csv' in name:
				file=open(filePath,'r')
				lines=file.readlines()
				for line in lines[1:]:
					line=line.strip().split('|')
					hash=line[0]
					name=line[1]
					hashList[hash]=name
				
			
			g.seek(back)
			print name,g.tell()
			
		else:
			print chunk			
			break		
				
			
	g.debug=True
	g.tell()	
	
	
def Parser():
	global gameDir
	filename=input.filename
	ext=filename.split('.')[-1].lower()	
	gameDir=filename.lower().split(os.sep+'0_na_skn')[0]
	
	if ext=='rom':
		file=open(filename,'rb')
		g=BinaryReader(file)
		romParser(filename,g)
		file.close()
		
		file=open(filename+'.dec','rb')
		g=BinaryReader(file)
		decParser(filename,g)
		file.close()	
	
	elif ext=='bin':
		file=open(filename,'rb')
		g=BinaryReader(file)
		romParser(filename,g)
		file.close()	
	
	elif ext=='pak':
		file=open(filename,'rb')
		g=BinaryReader(file)
		pakParser(filename,g)
		file.close()
	
	elif ext=='dec':
		file=open(filename,'rb')
		g=BinaryReader(file)
		decParser(filename,g)
		file.close()
	
	elif ext=='db':
		file=open(filename,'rb')
		g=BinaryReader(file)
		romParser(filename,g)
		file.close()
		file=open(filename+'.dec','rb')
		g=BinaryReader(file)
		dbParser(filename,g)
		file.close()
	
	elif ext=='csv':
		file=open(filename,'rb')
		g=BinaryReader(file)
		romParser(filename,g)
		file.close()
		file=open(filename+'.dec','r')
		csvParser(filename,file)
		file.close()
		
	else:
		file=open(filename,'rb')
		g=BinaryReader(file)
		decParser(filename,g)
		file.close()
		
 
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
	
Blender.Window.FileSelector(openFile,'import','pak - container, get files from folder 0_na_skn, skn - model files') 