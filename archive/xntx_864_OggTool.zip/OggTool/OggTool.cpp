// OggTool.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

static bool FoundOgg(std::istream& Input, const std::string& ShortFilename)
{
	char Buffer[4];
	std::streamoff Offset=Input.tellg();
	Input.read(Buffer, 4);
	if(memcmp(Buffer, "OggS", 4)!=0)
	{
		return false;
	}

	if(Input.get()!=0)
	{
		return false;
	}

	if(Input.get()>7)
	{
		return false;
	}

	Input.seekg(8, std::ios_base::cur);
	unsigned long Serial;
	Input.read((char*)&Serial, 4);
	unsigned long Index;
	Input.read((char*)&Index, 4);
	if(Index>10000)
	{
		return false;
	}
	std::cout << ShortFilename.c_str() << ", " << Offset << ", " << Serial;
	std::cout << ", " << Index << std::endl;
	return true;
}

static bool ProcessFile(const std::string& Filename, const std::string& ShortFilename)
{
	// Open the input stream
	std::ifstream Input;
	Input.open(Filename.c_str(), std::ios_base::in | std::ios_base::binary);
	if(!Input.is_open())
	{
		return false;
	}

	unsigned char Buffer[65536];
	while(!Input.eof())
	{
		std::streamoff OldPos=Input.tellg();
		Input.read((char*)Buffer, 65536);
		std::streamoff NewPos=Input.tellg();
		std::streamsize Read=NewPos-OldPos;
		if(Read==0)
		{
			break;
		}
		for(std::streamoff i=0;i<Read;i++)
		{
			if(Buffer[i]=='O')
			{
				if(Read-i>=4 && (Buffer[i+1]!='g' || Buffer[i+2]!='g' || Buffer[i+3]!='S'))
				{
					continue;
				}
				Input.seekg(OldPos+i);
				FoundOgg(Input, ShortFilename);
				Input.seekg(NewPos);
			}
		}
	}

	Input.close();
	return true;
}

int _tmain(int Argc, _TCHAR* Argv[])
{
	if(Argc<2)
	{
		std::cerr << "Invalid arguments" << std::endl;
		return 1;
	}
	std::string InputDir(Argv[1]);
	if(!InputDir.size())
	{
		InputDir="./";
	}
	if(InputDir[0]=='"')
	{
		InputDir.erase(InputDir.begin());
	}
	if(InputDir[InputDir.size()-1]=='"')
	{
		InputDir.erase(--InputDir.end());
	}
	if(InputDir[InputDir.size()-1]!='/' && InputDir[InputDir.size()-1]!='\\')
	{
		InputDir.append("/");
	}
	std::string InputSearch;
	InputSearch.append(InputDir);
	InputSearch.append("*");

	_finddata_t FileInfo;
    intptr_t FindHandle;

    /* Find first .c file in current directory */
    if((FindHandle=_findfirst(InputSearch.c_str(), &FileInfo))==-1L)
	{
		std::cerr << "No files found." << std::endl;
		return 1;
	}
	do
	{
		std::string Filename(InputDir);
		Filename.append(FileInfo.name);
		ProcessFile(Filename, std::string(FileInfo.name));
	} while(_findnext(FindHandle, &FileInfo)==0);
	_findclose(FindHandle);
	return 0;
}

