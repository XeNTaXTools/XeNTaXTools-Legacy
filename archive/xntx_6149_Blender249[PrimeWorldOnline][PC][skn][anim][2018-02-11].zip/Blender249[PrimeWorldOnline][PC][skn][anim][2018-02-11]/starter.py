import newGameLib
from newGameLib import *
import Blender	

def skinParser(filename,g):


	boneNameList=[]
	if os.path.exists('bones.txt')==True:
		file=open('bones.txt','r')
		lines=file.readlines()
		for line in lines:boneNameList.append(line.strip())
		file.close()

	skeleton=Skeleton()
	skelPath=g.dirname+os.sep+g.basename+".skel"
	if os.path.exists(skelPath)==True:
		file=open(skelPath,'rb')
		p=BinaryReader(file)
		skeleton=skelParser(filename,p)
		boneNameList=skeleton.boneNameList
		file.close()
	else:	
		skelPath=g.dirname+os.sep+g.basename+"root.skel"
		if os.path.exists(skelPath)==True:
			file=open(skelPath,'rb')
			p=BinaryReader(file)
			skeleton=skelParser(filename,p)
			boneNameList=skeleton.boneNameList
			file.close()
		
	header = g.i(9)
	tblOff = g.tell()
	meshCount, mTableOff = g.i(2)
	g.seek(tblOff + mTableOff, 0)
	meshInfo = []
	for a in range(0, meshCount):meshInfo.append([g.i(10), (g.tell() - 4)])
	meshFVF = []
	for a in range(0, meshCount):
		tmp = []
		g.seek(meshInfo[a][1] + meshInfo[a][0][9], 0)
		for b in range(0, meshInfo[a][0][8]):
			tmp.append(g.i(5))
		meshFVF.append(tmp)
	BoneInfo = []
	for a in range(0, meshCount):
		g.seek(header[7] + 0x10 + (8 * a), 0)
		BoneInfo.append([g.tell(), g.i(1)[0], g.i(1)[0]])
		
		
	for a in range(0, meshCount):
		mesh=Mesh()	
		g.seek(BoneInfo[a][0] + BoneInfo[a][2], 0)
		boneMap = g.H(BoneInfo[a][1])
		skin=Skin()
		mesh.skinList.append(skin)
		skin.boneMap=boneMap
		mat = Mat()
		mat.diffuse=g.dirname+os.sep+g.basename+'.dds'
		mat.specular=g.dirname+os.sep+g.basename+'spc.dds'
		mat.trans=g.dirname+os.sep+g.basename+'rcl.dds'
		mat.TRIANGLE=True
		mesh.matList.append(mat)
		for b in range(0, meshInfo[a][0][8]):
			g.seek(header[5] + (meshInfo[a][0][0] * meshInfo[a][0][1]), 0)
			if meshFVF[a][b][2] == 0:
				for m in safe(meshInfo[a][0][3]):
					t=g.tell()
					g.seek(t+meshFVF[a][b][0])
					mesh.vertPosList.append(g.f(3))
					g.seek(t+meshInfo[a][0][0])
			if meshFVF[a][b][2] == 5:
				for m in safe(meshInfo[a][0][3]):
					t=g.tell()
					g.seek(t+meshFVF[a][b][0])
					mesh.vertUVList.append(g.f(2))
					g.seek(t+meshInfo[a][0][0])
			if meshFVF[a][b][2] == 1:
				for m in safe(meshInfo[a][0][3]):
					t=g.tell()
					g.seek(t+meshFVF[a][b][0])
					mesh.skinWeightList.append(g.f(4))
					g.seek(t+meshInfo[a][0][0])
			if meshFVF[a][b][2] == 2:
				for m in safe(meshInfo[a][0][3]):
					t=g.tell()
					g.seek(t+meshFVF[a][b][0])
					mesh.skinIndiceList.append(g.B(4)[0:3][-1::])
					g.seek(t+meshInfo[a][0][0])
		g.seek(header[6] + (meshInfo[a][0][4] * 4), 0)
		mesh.indiceList=g.i(meshInfo[a][0][5]*3)
		mesh.boneNameList=boneNameList
		mesh.BINDSKELETON=skeleton.name
		mesh.draw()
	g.debug=True
	g.tell()

def skelParser(filename,g):
	bones=open('bones.txt','w')
	skeleton=Skeleton()
	skeleton.ARMATURESPACE=True
	sdHeader = g.i(9)
	
	g.seek(28 + sdHeader[8], 0)
	nameIDList=g.i(sdHeader[7])	
	g.seek(0xC + sdHeader[4], 0)
	for a in range(0, sdHeader[3]):
		bone=Bone()
		skeleton.boneList.append(bone)
		bone.parentID=g.i(1)[0]
	g.seek(0x14 + sdHeader[6], 0)
	boneName = []
	for a in range(sdHeader[5]):
		g.seek(0x14 + sdHeader[6] + (8 * a), 0)
		info = [g.tell(), g.i(1)[0], g.i(1)[0]]
		g.seek(info[0] + info[1], 0)
		name=g.find('\x00')
		boneName.append(name)
	g.seek(0x4 + sdHeader[2], 0)
	for a in range(0, sdHeader[1]):
		r1=g.f(4)
		r2=g.f(4)
		r3=g.f(4)
		r4=(0,0,0,1)
		matrix=Matrix(r1,r2,r3,r4).invert().transpose()
		skeleton.boneList[a].matrix=matrix
		skeleton.boneList[a].name=boneName[nameIDList.index(a)]
		bones.write(boneName[nameIDList.index(a)]+'\n')
	skeleton.draw()	
	bones.close()
	return skeleton
	
def animParser(filename,g):
	skl=None
	if os.path.exists('bones.txt')==True:
		objects=Blender.Object.GetSelected()
		if len(objects)>0:
			skl=objects[0]
			if skl:
				action=Action()
				action.BONESPACE=True
				action.BONESORT=True
				file=open('bones.txt','r')
				lines=file.readlines()
				bones=[]
				for line in lines:bones.append(line.strip())
				file.close()
				g.word(4)
				g.f(2)
				A=g.i(5)
				g.seek(12+A[1])	
				for m in safe(A[0]):
					bone=ActionBone()
					bone.name=bones[m]
					action.boneList.append(bone)
					t=g.tell()
					B=g.i(6)
					g.seek(t+B[1])
					for n in safe(B[0]):
						bone.posKeyList.append(VectorMatrix(g.f(3)))
						bone.posFrameList.append(n)
					g.seek(t+B[3]+8)
					for n in safe(B[2]):
						bone.rotKeyList.append(QuatMatrix(g.f(4)).resize4x4())
						bone.rotFrameList.append(n)
					g.seek(t+24)
				action.draw()
				action.setContext()	
					
				g.debug=True
				g.tell()	
	else:
		print 'import .skel first'
		Blender.Draw.PupMenu( 'import .skel first')
	
def Parser(filename):
	os.system('cls')
	sys=Sys(filename)
	if sys.ext=='skin':sys.parseFile(skinParser,'rb',log=0)
	if sys.ext=='skel':sys.parseFile(skelParser,'rb',log=0)
	if sys.ext=='anim':sys.parseFile(animParser,'rb',log=0)
 
	
Blender.Window.FileSelector(Parser,'import','Prime World files: *.skin - model, *.anim - action') 
	