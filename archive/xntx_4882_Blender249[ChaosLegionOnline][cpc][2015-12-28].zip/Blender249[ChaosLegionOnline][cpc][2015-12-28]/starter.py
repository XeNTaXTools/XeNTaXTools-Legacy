import newGameLib
from newGameLib import *
import Blender	

	


	
				
				
		


def cpcParser(filename,g):
	
	v0=g.i(20)
	print v0
	g.seek(v0[9]+16)
		
		
	v1=g.i(22);print v1
	print g.tell()
	print
	list_0=[]
	start=v1[20]
	skeleton=Skeleton()
	skeleton.BONESPACE=True
	skeleton.NICE=True
	for m in range(v1[1]):
		bone=Bone()
		skeleton.boneList.append(bone)
		t1=g.tell()
		name=g.word(136)
		bone.name=name
		v2=g.i(8)
		bone.matrix=Matrix4x4(g.f(16))
		bone.parentID=v2[2]
		print name#,v2[3]-start,v2[0],v2[3]
		print v2
		list_0.append(v2[3]-start)
		g.seek(t1+232)
		start=v2[3]
	skeleton.draw()	
	for m in range(v1[5]):#675			
		t1=g.tell()
		v2=g.i(7)
		#print v1[2],
		g.seek(t1+28)
	print	
		
	g.seek(1872,1)
	for m in range(1,v1[1]):
		t=g.tell()
		print g.tell(),g.i(10)
		g.seek(t+list_0[m])
	g.seek(list_0[0],1)
	
	for m in range(v1[5]):#43
		t=g.tell()
		#print f(81)
		g.seek(t+36)
		
	v2=g.i(20);print v2
	mesh=Mesh()
	skin=Skin()
	mesh.skinList.append(skin)
	#mesh.name=str(model_id)+'-model'
	for m in range(v2[12]): 
		t=g.tell()
		mesh.vertPosList.append(g.f(3))
		if v2[18]==88:
			g.seek(t+12)
			mesh.skinWeightList.append(g.f(3))
			mesh.skinIndiceList.append(g.B(3))
			g.seek(t+40)
			mesh.vertUVList.append(g.f(2))
		if v2[18]==80:
			g.seek(t+32)
			mesh.vertUVList.append(g.f(2))
		if v2[18]==76:
			g.seek(t+28)
			mesh.vertUVList.append(g.f(2))
			
		g.seek(t+v2[18])
	#for m in range(v2[14]/3):
	mesh.indiceList=g.H(v2[14])
	#skin.boneMap=g.H(v2[12])
	#print skin.boneMap
	for m in range(v2[12]):
		g.H(1)[0]
	for m in range(3):
		print m
		t=g.tell()
		print g.f(63)
		g.seek(t+252)
	print g.B(20)	
	g.seek(v0[13]+16)
	dirname=Blender.sys.dirname(filename)
	basename=Blender.sys.basename(filename)
	image_path=dirname+os.sep+basename.split('.')[0]+'.tga'
	new=open(image_path,'wb')
	new.write(g.read(g.fileSize()-g.tell()))
	new.close()
	print g.tell()	
	
	#mesh.TRISTRIP=False
	material=Mat()
	material.TRIANGLE=True
	#material.name=str(model_id)+'-mat'
	material.ZTRANS=True
	material.diffuse=image_path
	mesh.matList.append(material)
	mesh.boneNameList=skeleton.boneNameList
	mesh.BINDSKELETON=skeleton.name
	mesh.draw()
	

	
	
def Parser(filename):	
	print '='*70
	print filename
	print '='*70
	ext=filename.split('.')[-1].lower()	
	
	if ext=='cpc':
		file=open(filename,'rb')
		g=BinaryReader(file)
		g.logOpen()
		cpcParser(filename,g)
		g.logClose()
		file.close()
 
	
Blender.Window.FileSelector(Parser,'import','Chaos Legion files: *.cpc - model') 
	