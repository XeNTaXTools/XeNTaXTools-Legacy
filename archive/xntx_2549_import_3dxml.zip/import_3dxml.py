#!BPY
"""
Name: '3dXML...'
Blender: 249
Group: 'Import'
Tooltip: 'Import 3dxml'
"""
__author__ = "Anthony D'Agostino"
__url__ = ("blender","elysiun","Author's homepage, http://chronosphere.home.comcast.net")
__version__ = "1.0"
__bpydoc__ = ""

import Blender, zipfile, base64, struct, os, sys, time
import xml.etree.ElementTree as etree

def load_meshes(filename):
	tree = etree.parse(filename)
	images = tree.find("//{http://www.3ds.com/xsd/3DXML}ImageSet")
	numimages = len(images)
	print "Number of images:", numimages
	imgs = []
	for i in tree.findall("//{http://www.3ds.com/xsd/3DXML}Pixel"):
		img = write_tga(i, numimages)
		imgs.append(img)
	imgidxs = []
	for i in tree.findall("//{http://www.3ds.com/xsd/3DXML}Material"):
		imgidx = i.attrib["texture"]
		imgidx = int(imgidx.split(":")[-1])
		imgidxs.append(imgidx)
		#print "Image Idx:", imgidx
	allverts = []
	for i in tree.findall("//{http://www.3ds.com/xsd/3DXML}Positions"):
		verts = unflatten(i.text, float, 3)
		allverts.append(verts)
		#print "NumVerts:", len(verts)
	alltxuvs = []
	for i in tree.findall("//{http://www.3ds.com/xsd/3DXML}TextureCoordinates"):
		uvcos = unflatten(i.text, float, 2)
		alltxuvs.append(uvcos)
		#print "NumUVs:", len(uvcos)
	allfaces = []
	for i in tree.findall("//{http://www.3ds.com/xsd/3DXML}Faces"):
		fdict = i[1].attrib
		if "triangles" in fdict:
			faces = fdict["triangles"]
			faces = unflatten(faces, int, 3)
			#print "NumFaces:", len(faces)
		elif "fans" in fdict:
			faces = fdict["fans"]
			faces = unflatten(faces, int, 4)
			#print "NumFans:", len(faces)
		else:
			print "err", fdict
		allfaces.append(faces)
	objs = zip(allverts, alltxuvs, allfaces)
	assert len(objs) == len(imgidxs)
	if len(objs) != len(imgidxs):
		print "len(objs) != len(imgidxs)", len(objs), len(imgidxs)
	print "Number of objects:", len(objs)
	for (objidx,obj) in enumerate(objs):
		verts, txuvs, faces = obj
		create_mesh(verts, faces, objidx, txuvs, imgs, imgidxs)

def create_mesh(verts, faces, objidx, uvs, imgs, imgidxs):
	if len(verts) != len(uvs):
		print objidx,
		print "len(verts) != len(uvs)", len(verts), len(uvs),
		print "resetting the uv list"
		uvs = [uvs[0]]*len(verts)
	numobjs = len(imgidxs)
	size = len(`numobjs`)
	objname = str("Mesh-%0"+`size`+"d") % (objidx+1)
	mesh = Blender.Mesh.New(objname)
	mesh.vertexUV = 1
	mesh.verts.extend(verts)
	mesh.faces.extend(faces)
	for i in range(len(verts)):
		mesh.verts[i].uvco = Blender.Mathutils.Vector(uvs[i])
	for face in mesh.faces:
		face.smooth = 0
		face.image = imgs[imgidxs[objidx]-1]
	#print objname, imgidxs[objname]-1, imgs[imgidxs[objname]-1]
	pervertuv_to_perfaceuv(mesh)
	scn = Blender.Scene.GetCurrent()
	obj = scn.objects.new(mesh)
	obj.sel = True
	mesh.remDoubles(0.0)
	Blender.Redraw()

def pervertuv_to_perfaceuv(mesh):
	for face in mesh.faces:
		face.uv = [vert.uvco for vert in face.verts]
		#face.mode |= Blender.Mesh.FaceModes.TWOSIDE
	mesh.vertexUV = 0

def unflatten(seq, func, step):
	if step == 2: seq = seq.replace(",", "")
	seq = seq.split()
	seq = list(map(func, seq))
	nseq = len(seq)
	if step == 2:
		return [(seq[i],seq[i+1]) for i in range(0, nseq, step)]
	elif step == 3:
		return [(seq[i],seq[i+1],seq[i+2]) for i in range(0, nseq, step)]
	elif step == 4:
		return [(seq[i],seq[i+1],seq[i+2],seq[i+3]) for i in range(0, nseq, step)]
	else:
		return None

def write_tga(image, numimages):
	h = int(image.attrib["height"])
	w = int(image.attrib["width"])
	fmt = image.attrib["format"]
	pixels = image[0].text
	size = len(`numimages`)
	imgidx = image.attrib["id"]
	imgidx = str("Map-%0"+`size`+"d") % int(imgidx)
	filename = imgidx + ".tga"
	bits = 32 if "A" in fmt else 24
	alpha = 8 if "A" in fmt else 0
	dirname = "textures"
	if not os.path.exists(dirname): os.mkdir(dirname)
	pathname = os.path.join(dirname, filename)
	if not os.path.exists(pathname):
		print "writing %s (%dx%d) %s" % (pathname, w, h, fmt.lower())
		with open(pathname, "wb") as file:
			file.write(struct.pack("12B", 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0))
			file.write(struct.pack("HH", w, h))
			file.write(struct.pack("BB", bits, alpha))
			pixels = base64.b64decode(pixels) #$base64.b64decode(bytes(pixels, "utf-8"))
			pixels = rgb_to_bgr(pixels, fmt)
			file.write(pixels)
	image = Blender.Image.Load(pathname)
	image.makeCurrent()
	Blender.Window.RedrawAll()
	return(image)

def rgb_to_bgr(pixels, fmt):
	pixels = list(pixels)
	npixels = len(pixels)
	step = 4 if "A" in fmt else 3
	for i in range(0, npixels, step):
		pixels[i],pixels[i+2] = pixels[i+2],pixels[i]
	#$pixels = map(chr, pixels)
	pixels = "".join(pixels)
	#$pixels = bytes(pixels, "latin-1")
	return pixels


def read(filename):
	time1 = time.time()
	path = os.path.dirname(filename)
	os.chdir(path)
	print path
	os.system("cls") if "nt" in os.name else os.system("clear")
	if zipfile.is_zipfile(filename):
		zf = zipfile.ZipFile(filename, "r")
		member = zf.namelist()[1]
		filename = zf.open(member)
		print "Unzipping", member
	load_meshes(filename)
	time2 = time.time()
	print "Total import time is: %.2f seconds." % (time2 - time1)

if __name__=="__main__":
	Blender.Window.FileSelector(read, "Import 3dXML", "*.3dxml")
