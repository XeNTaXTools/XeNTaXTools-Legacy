from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Tron 2.0", ".dtx")
	noesis.setHandlerTypeCheck(handle, Tron2CheckType)
	noesis.setHandlerLoadRGBA(handle, Tron2LoadRGBA)
	#noesis.logPopup()
	return 1

#check if it's this type based on the data
def Tron2CheckType(data):
	bs = NoeBitStream(data)
	bs.seek(0x04, NOESEEK_ABS)
	Magic = bs.readBytes(4)
	print(Magic)
	if Magic != b'\xFB\xFF\xFF\xFF':
		return 0
	return 1
	
def Tron2LoadRGBA(data, texList):
	datasize = len(data) - 0xa4        
	bs = NoeBitStream(data)
	bs.seek(0x08, NOESEEK_ABS)
	imgWidth = bs.readShort()            
	imgHeight = bs.readShort()           
	bs.seek(0xa4, NOESEEK_ABS)        
	data = bs.readBytes(datasize)      
	#DXT5
	texFmt = noesis.NOESISTEX_DXT5
	texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
	return 1