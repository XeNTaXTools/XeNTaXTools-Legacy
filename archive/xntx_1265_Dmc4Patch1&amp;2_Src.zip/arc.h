
#ifndef _ARC_H
#define _ARC_H

#include "main.h"

//+-----------------------------------------------------------> Defines

#define ARCEXT_MODEL			0x1041BD9E			// MOD		.mod
#define ARCEXT_TEXTURE			0x3CAD8076			// TEX		.tex
#define ARCEXT_RTEXTURE			0x27CE98F6			// RTX		.rtex
#define ARCEXT_SHADER			0x4E32817C			// BFX		.bfx
#define ARCEXT_XML				0x21034C90			// ARCS		.xml
#define ARCEXT_SCHEDULE			0x44E79B6E			// SDL		.sdl
#define ARCEXT_SPRITEMAP		0x34A8C353			// XFS		.sprmap
#define ARCEXT_ANIMATION		0x55A8FB34			// ANM		.anm

#define ARCEXT_SBCOLLISION		0x3900DAD0			// SBC1
#define ARCEXT_COLLISION		0x4EA4E09A			// COL

#define ARCEXT_EFFECT_EAN		0x5E7D6A45			// EAN
#define ARCEXT_EFFECT_EFL		0x294488A8			// EFL
#define ARCEXT_EFFECT_EFS		0x528770DF			// EFS
#define ARCEXT_EFFECT_E2D		0x76AA6987			// E2D

#define ARCEXT_SOUND_OGG		0x3821B94D			// OggS
#define ARCEXT_SOUND_STRQ		0x07D5909F			// STRQ
#define ARCEXT_SOUND_SPAC		0x33AE5307			// SPAC
#define ARCEXT_SOUND_DNRS		0x29948FBA			// DNRS
#define ARCEXT_SOUND_SREQ		0x6C1D2073			// SREQ
#define ARCEXT_SOUND_SCST		0x094973CF			// SCST
#define ARCEXT_SOUND_SDST		0x340F49F9			// SDST
#define ARCEXT_SOUND_XFS1		0x0C88D5D1			// XFS
#define ARCEXT_SOUND_XFS2		0x0CA6AED4			// XFS
#define ARCEXT_SOUND_XFS3		0x5D5CBBCE			// XFS
#define ARCEXT_SOUND_XFS4		0x1D076492			// XFS
#define ARCEXT_SOUND_XFS5		0x16640CD4			// XFS
#define ARCEXT_SOUND_XFS6		0x2E47C723			// XFS
#define ARCEXT_SOUND_XFS7		0x7A038F4C			// XFS
#define ARCEXT_SOUND_XFS8		0x39F8A71D			// XFS

#define ARCEXT_MOTION			0x139EE51D			// LMT
#define ARCEXT_ATTACK			0x652A93A4			// ATK		attack behaviour
#define ARCEXT_DEFEND			0x27F3C33D			// DFD		defend behaviour
#define ARCEXT_CHARTABLE		0x19DDF06A			// .CTN
#define ARCEXT_PLAYERPROPERTIES	0x7A5DCF86			// PLP
#define ARCEXT_TEXT				0x470745CB
#define ARCEXT_PHYSIQUE			0x4D990996			// XFS		physique file for model
#define ARCEXT_XFS01			0x3001BEC4			// XFS
#define ARCEXT_CAMERA			0x5EF1FB52			// LCM
#define ARCEXT_STAGECAMERA		0x743FE170			// XFS
#define ARCEXT_MESSAGE			0x4CDF60E9			// MSG2
#define ARCEXT_NULLS			0x5E4C723C			// NLS
#define ARCEXT_VIBRATION		0x0D7DA737			// VIB

#define ARCEXT_PLAY				0x3F5955F1			// PLA
#define ARCEXT_LEAFANIMATION	0x46771E81			// RLA
#define ARCEXT_MISSION_XFS1		0x2B93C4AD			// XFS
#define ARCEXT_MISSION_XFS2		0x4D52E593			// XFS
#define ARCEXT_MISSION_XFS3		0x6125D9CD			// XFS

//+-----------------------------------------------------------> cArcHeader

struct cArcHeader
{
	unsigned int				uiTag;
	unsigned short				usVersion;
	unsigned short				usFileNum;
};

//+-----------------------------------------------------------> cArcFile

struct cArcFileInfo
{
	char						strName[64];
	unsigned int				uiExtension;
	unsigned int				uiSize1;
	unsigned int				uiSize2;
	unsigned int				uiOffset;
};

//+-----------------------------------------------------------> 

bool PatchArcFilenames(const char *strArc);
void PatchAllArcFilenames(char *rep);
bool PatchArcExtensions(const char *strArc);
void PatchAllArcExtensions(char *rep);

#endif