
#ifndef _MAIN_H
#define _MAIN_H

#include <stdio.h>
#include <windows.h>
#include <d3dx9.h>
//#include <vector>

//using namespace std;
void ReadString(FILE *pFile, char *strString);

#endif