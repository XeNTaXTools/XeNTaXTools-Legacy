
#include "arc.h"

//---------------------------------------------------------> main()

bool main()
{
	//+------------------------------------------------------------------------------> Dmc4Patch_01

	//printf("\n| Surveyor's Devil May Cary 4 ARC Extension Patcher 01\n");
	//printf("| Aout 2009\n\n");

	//char strDir[512] = {0};
	//GetCurrentDirectory(unsigned int(strlen(strDir) - 1), strDir);
	//PatchAllArcExtensions(strDir);

	//+------------------------------------------------------------------------------> Dmc4Patch_02

	printf("\n| Surveyor's Devil May Cary 4 ARC Filename Patcher 02\n");
	printf("| Aout 2009\n\n");

	char strDir[512] = {0};
	GetCurrentDirectory(unsigned int(strlen(strDir) - 1), strDir);
	PatchAllArcFilenames(strDir);

	return true;
}

//---------------------------------------------------------> ReadString()
// reads a string and stops at the NULL char

void ReadString(FILE *pFile, char *strString)
{
	int index = 0;
	
	fread(strString, 1, 1, pFile);

	while(*(strString + index++) != NULL)
	{
		fread(strString + index, 1, 1, pFile);
	}
}