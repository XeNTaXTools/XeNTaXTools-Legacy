
#include "arc.h"

//+-----------------------------------------------------------> PatchArcExtensions()
// will patch the filenames inside the arc so that they'll have
// extensions, if a filename already has an extension then nothing
// will happen to it. after a file got an extension, the 61st byte of its
// filename will be altered to mark it as modified.

bool PatchArcExtensions(const char *strArc)
{
	// open the file
	FILE *pFile = fopen(strArc, "rb+wb");
	if(!pFile)
	{
		printf("Can't open ARC file [%s] !\n", strArc);
		return false;
	}

	// read the header
	cArcHeader hdr;
	fread(&hdr, sizeof(cArcHeader), 1, pFile);
	if(hdr.uiTag != 0x00435241)
	{
		fclose(pFile);
		return true;
	}
	printf("%s\n", strArc);

	// read the file info
	cArcFileInfo *pInfo = new cArcFileInfo[hdr.usFileNum];
	fread(pInfo, sizeof(cArcFileInfo), hdr.usFileNum, pFile);

	// go through all the files
	for(unsigned short a = 0; a < hdr.usFileNum; a++)
	{
		if(!pInfo[a].strName[61])
		{
			// get the extension
			char strExt[8] = {0};
			switch(pInfo[a].uiExtension)
			{
			case ARCEXT_MODEL:			sprintf(strExt, ".mod");	break;		// ---
			case ARCEXT_TEXTURE:		sprintf(strExt, ".tex");	break;		// ---
			case ARCEXT_RTEXTURE:		sprintf(strExt, ".rtex");	break;		// ---
			case ARCEXT_SHADER:			sprintf(strExt, ".bfx");	break;		// ---
			case ARCEXT_ANIMATION:		sprintf(strExt, ".anm");	break;		// ---
			case ARCEXT_SCHEDULE:		sprintf(strExt, ".sdl");	break;		// ---
			case ARCEXT_XML:			sprintf(strExt, ".xml");	break;
			case ARCEXT_SPRITEMAP:		sprintf(strExt, ".sprmap");	break;
			case ARCEXT_SBCOLLISION:	sprintf(strExt, ".sbc");	break;
			case ARCEXT_COLLISION:		sprintf(strExt, ".col");	break;

			case ARCEXT_EFFECT_EAN:		sprintf(strExt, ".ean");	break;
			case ARCEXT_EFFECT_EFL:		sprintf(strExt, ".efl");	break;
			case ARCEXT_EFFECT_EFS:		sprintf(strExt, ".efs");	break;
			case ARCEXT_EFFECT_E2D:		sprintf(strExt, ".e2d");	break;

			case ARCEXT_SOUND_OGG:		sprintf(strExt, ".sngw");	break;		// ----
			case ARCEXT_SOUND_STRQ:		sprintf(strExt, ".stq");	break;		// ----
			case ARCEXT_SOUND_SPAC:		sprintf(strExt, ".spac");	break;
			case ARCEXT_SOUND_DNRS:		sprintf(strExt, ".dnrs");	break;
			case ARCEXT_SOUND_SREQ:		sprintf(strExt, ".sreq");	break;
			case ARCEXT_SOUND_SCST:		sprintf(strExt, ".scst");	break;
			case ARCEXT_SOUND_SDST:		sprintf(strExt, ".sdst");	break;
			case ARCEXT_SOUND_XFS1:		sprintf(strExt, ".sxfs1");	break;
			case ARCEXT_SOUND_XFS2:		sprintf(strExt, ".sxfs2");	break;
			case ARCEXT_SOUND_XFS3:		sprintf(strExt, ".sxfs3");	break;
			case ARCEXT_SOUND_XFS4:		sprintf(strExt, ".sxfs4");	break;
			case ARCEXT_SOUND_XFS5:		sprintf(strExt, ".sxfs5");	break;
			case ARCEXT_SOUND_XFS6:		sprintf(strExt, ".sxfs6");	break;
			case ARCEXT_SOUND_XFS7:		sprintf(strExt, ".sxfs7");	break;
			case ARCEXT_SOUND_XFS8:		sprintf(strExt, ".sxfs8");	break;

			case ARCEXT_ATTACK:			sprintf(strExt, ".atk");	break;
			case ARCEXT_DEFEND:			sprintf(strExt, ".dfd");	break;
			case ARCEXT_CHARTABLE:		sprintf(strExt, ".chrtbl");	break;
			case ARCEXT_PLAYERPROPERTIES:	sprintf(strExt, ".plp");	break;
			case ARCEXT_TEXT:			sprintf(strExt, ".txt");	break;
			case ARCEXT_MOTION:			sprintf(strExt, ".lmt");	break;
			case ARCEXT_PHYSIQUE:		sprintf(strExt, ".phs");	break;
			case ARCEXT_XFS01:			sprintf(strExt, ".sth");	break;
			case ARCEXT_CAMERA:			sprintf(strExt, ".lcm");	break;
			case ARCEXT_STAGECAMERA:	sprintf(strExt, ".stc");	break;
			case ARCEXT_MESSAGE:		sprintf(strExt, ".msg");	break;
			case ARCEXT_NULLS:			sprintf(strExt, ".nls");	break;
			case ARCEXT_VIBRATION:		sprintf(strExt, ".vib");	break;

			case ARCEXT_LEAFANIMATION:	sprintf(strExt, ".rla");	break;
			case ARCEXT_PLAY:			sprintf(strExt, ".pla");	break;
			case ARCEXT_MISSION_XFS1:	sprintf(strExt, ".miss1");	break;
			case ARCEXT_MISSION_XFS2:	sprintf(strExt, ".miss2");	break;
			case ARCEXT_MISSION_XFS3:	sprintf(strExt, ".miss3");	break;
				break;

			default:
				{
					printf("\tunknown file format %d, %s!!\n", a, pInfo[a].strName);
					return false;
				}
			}

			// add the extension to the filename
			unsigned int start = unsigned int(strlen(pInfo[a].strName));
			for(unsigned int b = 0; b < unsigned int(strlen(strExt)); b++)
				pInfo[a].strName[start + b] = strExt[b];

			// mark the filename as modified
			pInfo[a].strName[61] = 1;
		}
	}

	// write back the modified header data
	fseek(pFile, 8, SEEK_SET);
	fwrite(pInfo, sizeof(cArcFileInfo), hdr.usFileNum, pFile);
	fclose(pFile);

	delete[] pInfo;
	pInfo = NULL;
	return true;
}

//+-----------------------------------------------------------> PatchAllArcExtensions()

void PatchAllArcExtensions(char *rep)
{
    WIN32_FIND_DATA FindFileData;
    char path[MAX_PATH];
    strcpy(path,rep);
	//printf("%s\n", rep);
    strcat(path,"\\*.*");
    HANDLE hFind = FindFirstFile(path, &FindFileData);
    if (hFind==INVALID_HANDLE_VALUE)
        return;
	// if we found a directory then process this directory right away
    if(strcmp(FindFileData.cFileName,".")!=0 && strcmp(FindFileData.cFileName,"..")!=0)
    {
        strcpy(path, rep);
        strcat(path, "\\");
        strcat(path, FindFileData.cFileName);
        PatchAllArcExtensions(path);
    }
	// find all the files in this directory
    DWORD a = 0;
    while(a != ERROR_NO_MORE_FILES)
    {
        if(!FindNextFile(hFind, &FindFileData))
            a = GetLastError();
        else
        {
            if(strcmp(FindFileData.cFileName,".")!=0 && strcmp(FindFileData.cFileName,"..")!=0)
            {
                strcpy(path,rep);
                strcat(path,"\\");
                strcat(path,FindFileData.cFileName);
                if (FindFileData.dwFileAttributes == FILE_ATTRIBUTE_DIRECTORY)
                    PatchAllArcExtensions(path);
                else
                {
					char strData[512] = {0};
					sprintf(strData, "%s\\%s", rep, FindFileData.cFileName);
					PatchArcExtensions(strData);
                }
            }
        }
    }
    FindClose(hFind);
}

//+-----------------------------------------------------------> PatchArcFilnames()
// will patch the filenames inside the arc so that they'll no longer
// be loaded by the game exe, instead the extracted files will be 
// used. the way it's done is simple: replace the 1st filename character
// by # and mark the filename as patched in the 61st char, the 62nd char
// will hold the altered 1st char for further restitution purposes

bool PatchArcFilenames(const char *strArc)
{
	// open the file
	FILE *pFile = fopen(strArc, "rb+wb");
	if(!pFile)
	{
		printf("Can't open ARC file [%s] !\n", strArc);
		return false;
	}

	// read the header
	cArcHeader hdr;
	fread(&hdr, sizeof(cArcHeader), 1, pFile);
	if(hdr.uiTag != 0x00435241)
	{
		fclose(pFile);
		return true;
	}
	printf("%s\n", strArc);

	// read the file info
	cArcFileInfo *pInfo = new cArcFileInfo[hdr.usFileNum];
	fread(pInfo, sizeof(cArcFileInfo), hdr.usFileNum, pFile);

	// go through all the files
	for(unsigned short a = 0; a < hdr.usFileNum; a++)
	{
		if(!pInfo[a].strName[61])
		{
			// get the extension
			char strExt[8] = {0};
			switch(pInfo[a].uiExtension)
			{
			case ARCEXT_MODEL:
			case ARCEXT_TEXTURE:
			case ARCEXT_RTEXTURE:
			case ARCEXT_SHADER:
			case ARCEXT_ANIMATION:
			case ARCEXT_SCHEDULE:
			case ARCEXT_SOUND_OGG:
			case ARCEXT_SOUND_STRQ:
			case ARCEXT_SBCOLLISION:
			case ARCEXT_PLAY:
			case ARCEXT_MOTION:
			case ARCEXT_CAMERA:
				{
					// save the 1st char in the 62nd position
					pInfo[a].strName[62] = pInfo[a].strName[0];

					// alter the 1st char
					pInfo[a].strName[0] = '#';

					// mark the filename as modified
					pInfo[a].strName[61] = 1;
				}
				break;
			}


			//case ARCEXT_XML:
			//case ARCEXT_SPRITEMAP:
			//case ARCEXT_COLLISION:

			//case ARCEXT_EFFECT_EAN:
			//case ARCEXT_EFFECT_EFL:
			//case ARCEXT_EFFECT_EFS:
			//case ARCEXT_EFFECT_E2D:

			//case ARCEXT_SOUND_SPAC:
			//case ARCEXT_SOUND_DNRS:
			//case ARCEXT_SOUND_SREQ:
			//case ARCEXT_SOUND_SCST:
			//case ARCEXT_SOUND_SDST:
			//case ARCEXT_SOUND_XFS1:
			//case ARCEXT_SOUND_XFS2:
			//case ARCEXT_SOUND_XFS3:
			//case ARCEXT_SOUND_XFS4:
			//case ARCEXT_SOUND_XFS5:
			//case ARCEXT_SOUND_XFS6:
			//case ARCEXT_SOUND_XFS7:
			//case ARCEXT_SOUND_XFS8:

			//case ARCEXT_ATTACK:
			//case ARCEXT_DEFEND:
			//case ARCEXT_CHARTABLE:
			//case ARCEXT_PLAYERPROPERTIES:
			//case ARCEXT_TEXT:
			//case ARCEXT_PHYSIQUE:
			//case ARCEXT_XFS01:
			//case ARCEXT_STAGECAMERA:
			//case ARCEXT_MESSAGE:
			//case ARCEXT_NULLS:
			//case ARCEXT_VIBRATION:

			//case ARCEXT_LEAFANIMATION:
			//case ARCEXT_MISSION_XFS1:
			//case ARCEXT_MISSION_XFS2:
			//case ARCEXT_MISSION_XFS3:
			//	break;
		}
	}

	// write back the modified header data
	fseek(pFile, 8, SEEK_SET);
	fwrite(pInfo, sizeof(cArcFileInfo), hdr.usFileNum, pFile);
	fclose(pFile);

	delete[] pInfo;
	pInfo = NULL;
	return true;
}

//+-----------------------------------------------------------> PatchAllArcFilenames()

void PatchAllArcFilenames(char *rep)
{
    WIN32_FIND_DATA FindFileData;
    char path[MAX_PATH];
    strcpy(path,rep);
	//printf("%s\n", rep);
    strcat(path,"\\*.*");
    HANDLE hFind = FindFirstFile(path, &FindFileData);
    if (hFind==INVALID_HANDLE_VALUE)
        return;
	// if we found a directory then process this directory right away
    if(strcmp(FindFileData.cFileName,".")!=0 && strcmp(FindFileData.cFileName,"..")!=0)
    {
        strcpy(path, rep);
        strcat(path, "\\");
        strcat(path, FindFileData.cFileName);
        PatchAllArcFilenames(path);
    }
	// find all the files in this directory
    DWORD a = 0;
    while(a != ERROR_NO_MORE_FILES)
    {
        if(!FindNextFile(hFind, &FindFileData))
            a = GetLastError();
        else
        {
            if(strcmp(FindFileData.cFileName,".")!=0 && strcmp(FindFileData.cFileName,"..")!=0)
            {
                strcpy(path,rep);
                strcat(path,"\\");
                strcat(path,FindFileData.cFileName);
                if (FindFileData.dwFileAttributes == FILE_ATTRIBUTE_DIRECTORY)
                    PatchAllArcFilenames(path);
                else
                {
					char strData[512] = {0};
					sprintf(strData, "%s\\%s", rep, FindFileData.cFileName);
					PatchArcFilenames(strData);
                }
            }
        }
    }
    FindClose(hFind);
}

//+-----------------------------------------------------------> Lost Planet Related
//		case 0x234D7104:	// model (CDF)
//			sprintf(strExt, "cdf");
//			break;
//		case 0x264087B8:	// facial animation event (FCA)
//			sprintf(strExt, "fca");
//			break;
//		case 0x4F6FFDDC:	// facial pattern event (FCP)
//			sprintf(strExt, "fcp");
//			break;
//		case 0x34A8C353:	// .spr_map
//			sprintf(strExt, "spr_map");
//			break;
//// COLLISION
//		case 0x11C82587:	// collision om file (OBJA)
//			sprintf(strExt, "obja");
//			break;
//		case 0x1D35Af2B:	// collision2 om file (HIT)
//			sprintf(strExt, "hit");
//			break;
//// EFFECT
//		case 0x03FAE282:	// effect1 (EFA)
//			sprintf(strExt, "efa");
//			break;
//		case 0x482B5B95:	// effect3 (ESL)
//			sprintf(strExt, "esl");
//			break;
//// HAVOK
//		case 0x6C3B4904:	// HAVOK link collision file, header: XFS
//			sprintf(strExt, "hav_link");
//			break;
//		case 0x57BAE388:	// HAVOK constraint file, header: XFS
//			sprintf(strExt, "hav_const");
//			break;
//		case 0x5435D27B:	// HAVOK file, contains nothing but padding, no header
//			sprintf(strExt, "hav");
//			break;
//		case 0x1AEB54D1:	// HAVOK vertex file, xml based, only 2 of them in the whole packages!
//			sprintf(strExt, "hav_xml");
//			break;
//		case 0x3C3D0C05:	// png format HUD files, but something else for stages, HAVOK related, header: 0x75e0e075
//			sprintf(strExt, "hav_png");
//			break;
//// SOUND
//		case 0x3D007115:	// .spc sound, header: WED
//			sprintf(strExt, "spc");
//			break;
//		case 0x5A3CED86:	// .srd sound, header: RRD
//			sprintf(strExt, "srd");
//			break;
//		case 0x48459606:	// .srq sound seq_bgs file, header: seq0
//			sprintf(strExt, "srq");
//			break;
//// MISSION
//		case 0x338C1FEC:	// mission tool 1, header: XFS
//			sprintf(strExt, "miss1");
//			break;
//		case 0x54503672:	// mission tool 2, header: XFS
//			sprintf(strExt, "miss2");
//			break;
//		case 0x0D3BE7B5:	// mission tool 3, header: XFS
//			sprintf(strExt, "miss3");
//			break;
//		case 0x652071B0:	// mission tool 4, header: XFS
//			sprintf(strExt, "miss4");
//			break;
//		case 0x71D6A0D4:	// mission tool 5, header: OSF
//			sprintf(strExt, "miss5");
//			break;
//		default:
//			{
//				printf("Unknown filetype [%d] at file [%d] !\n", pInfo[a].uiExtension, a);
//				sprintf(strExt, "unk");
//				//return false;
//			}
//		}
