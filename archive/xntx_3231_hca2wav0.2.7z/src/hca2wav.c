#include "stdio.h"
#include "stdlib.h"

void* __cdecl decode_init();
int __cdecl Read_Header(void *Decoder_struct, void *Src, int MaxCount, void *Src2,	int	MaxCount2, void	*data_start_ptr);
int __cdecl Decode(void *Decoder_struct, void *out_buf);

struct spectrum_str{
	char data1[0x200];
	char data2[0x200];
	char readed_floor[0x80];
	char quant[0x80];
	int dummy1,dummy2;
	void *ench_data_ptr;
	int dummy3;
	char ench_data[0x600];
};

struct dec_struct{
	int	max_channels;
	int channels;
	int freq;
	char dummy0a[0x20];
	int frame_len;
	char dummy0b[0x14];
	char dummy1[0x80];
	struct spectrum_str *spectrum_buf1;
	struct spectrum_str *spectrum_buf2;
	struct spectrum_str *spectrum_buf3;
	struct spectrum_str *spectrum_buf4;
	struct spectrum_str *spectrum_buf5;
	struct spectrum_str *spectrum_buf6;
	char dummy2[0x30];
	int counter;
	void* in_buf;
	int max_buf_len;
	int cur_in_bits_len;
	char dummy3[0x64];
};

#define max_buf 16384

int main(int argc, char *argv[]) {
	int size,ret, i, j, out_len,res;
	unsigned int data_len;
	void *buf,*out_buf;
	short *end_buf,*end_cur_ptr;
	float *cur_ptr1, *cur_ptr2, sample, *out_buf_ptr[6];
	FILE *file,*file2;
	struct dec_struct *decoder;
	char header[44];
	memset(header,0,44);
	if (argc!=3) {
		printf("hca2wav v 0.1 by ProFrager\nUsage: hca2wav.exe infile.hca outfile.wav\n");
		return 1;
	}
	printf("Decoding %s ...\n",argv[1]);
	file=fopen(argv[1],"rb");
	if (!file){
		printf("Cant open input file\n");
		return -1;
	}
	file2=fopen(argv[2],"wb");
	if (!file2){
		printf("Cant create output file\n");
		return -1;
	}
	buf=malloc(max_buf);
	end_buf=malloc(0x1000);
	decoder=decode_init();
	fread(buf,1,max_buf,file);
	res=Read_Header(decoder,buf,max_buf,NULL,0,&out_len);
	if (res){
		if (decoder->channels>2){
			printf("This decoder not support more than 6 channels\n");
			return -3;
		} else{
			printf("Error reading HCA header\n");
			return -2;
		}
	}
	printf("Channels : %u\n",decoder->channels);
	printf("Frequency: %u Hz\n",decoder->freq);
	printf("Bitrate  : %4.1f Kbit/s\n",((((float)decoder->freq) / 1024) * (float)decoder->frame_len)/125);


	for (i=0;i<decoder->channels;i++){
		out_buf=malloc(0x200);
		out_buf_ptr[i]=out_buf;
	}
	fseek(file,out_len,SEEK_SET);
	printf("...");
	fwrite(header,1,44,file2);
	data_len=0;
	ret=0;
	do{
		res=fread(decoder->in_buf,1,decoder->frame_len,file);
		if (res!=decoder->frame_len) {
			if (res){
				printf("Unexpected end of file\n",res);
				ret=-4;
			}
			break;
		}
		while (decoder->counter<0x0B){
			res=Decode(decoder,out_buf_ptr);
			if (res) {
				printf("Decoder return error code: %u\n",res);
				ret=-5;
				break;
			}
			end_cur_ptr=end_buf;
			if (decoder->channels==1){
				cur_ptr1=out_buf_ptr[0];
				for (;end_cur_ptr<end_buf+0x80;){
					sample=((*cur_ptr1++) * 30000);
					*end_cur_ptr++=(short)sample;
				}
				fwrite(end_buf,1,0x100,file2);
				data_len+=0x100;
			}else if (decoder->channels==2){
				cur_ptr1=out_buf_ptr[0];
				cur_ptr2=out_buf_ptr[1];
				for (;end_cur_ptr<end_buf+0x100;){
					sample=((*cur_ptr1++) * 30000);
					*end_cur_ptr++=(short)sample;
					sample=((*cur_ptr2++) * 30000);
					*end_cur_ptr++=(short)sample;
				}
				fwrite(end_buf,1,0x200,file2);
				data_len+=0x200;
			} else{
				for (i=0;i<0x80;i++){
					for (j=0;j<decoder->channels;j++){
						sample=((out_buf_ptr[j][i]) * 30000);
						*end_cur_ptr++=(short)sample;
					}
				}
				size=(end_cur_ptr-end_buf)*sizeof(short);
				fwrite(end_buf,1,size,file2);
				data_len+=size;
			}

		}
		decoder->counter=1;
		decoder->cur_in_bits_len=0;
	}while (!res);
	fclose(file);
	fseek(file2,0,SEEK_SET);
	*(unsigned int*)header=0x46464952;
	*(unsigned int*)(header+4)=data_len+44;
	*(unsigned int*)(header+8)=0x45564157;
	*(unsigned int*)(header+12)=0x20746d66;
	*(unsigned int*)(header+16)=16;
	*(unsigned short*)(header+20)=1;
	*(unsigned short*)(header+22)=decoder->channels;
	*(unsigned int*)(header+24)=decoder->freq;
	*(unsigned int*)(header+28)=(decoder->freq)*(decoder->channels)*2;
	*(unsigned short*)(header+32)=(decoder->channels)*2;
	*(unsigned short*)(header+34)=16;
	*(unsigned int*)(header+36)=0x61746164;
	*(unsigned int*)(header+40)=data_len;

	fwrite(header,1,44,file2);
	fclose(file2);
	if (!ret){
		printf("\rAll OK!\n\n",res);
	}
	return ret;
}
