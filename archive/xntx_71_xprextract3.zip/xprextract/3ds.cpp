#include "stdafx.h"
#include <stdio.h>
#include <stdlib.h>
#include <io.h>
#include <fcntl.h>
#include <sys\types.h>
#include <sys\stat.h>
#include "3ds.h"

enum aiw_3ds_chunks_
{
    CHUNK_RGBF      = 0x0010,
    CHUNK_RGBB      = 0x0011,
    CHUNK_RBGB2     = 0x0012,
    CHUNK_AMOUNTOF  = 0x0030,
    CHUNK_PRJ       = 0xC23D,
    CHUNK_MLI       = 0x3DAA,
    CHUNK_MAIN      = 0x4D4D,
        CHUNK_OBJMESH   = 0x3D3D,
            CHUNK_BKGCOLOR  = 0x1200,
            CHUNK_AMBCOLOR  = 0x2100,
            CHUNK_OBJBLOCK  = 0x4000,
                CHUNK_TRIMESH   = 0x4100,
                    CHUNK_VERTLIST  = 0x4110,
                    CHUNK_VERTFLAGS = 0x4111,
                    CHUNK_FACELIST  = 0x4120,
                    CHUNK_FACEMAT   = 0x4130,
                    CHUNK_MAPLIST   = 0x4140,
                    CHUNK_SMOOLIST  = 0x4150,
                    CHUNK_TRMATRIX  = 0x4160,
                    CHUNK_MESHCOLOR = 0x4165,
                    CHUNK_TXTINFO   = 0x4170,
                CHUNK_LIGHT     = 0x4600,
                    CHUNK_SPOTLIGHT = 0x4610,
                    CHUNK_LIGHTOFF  = 0x4620,
                CHUNK_CAMERA    = 0x4700,
                CHUNK_HIERARCHY = 0x4F00,
        CHUNK_VIEWPORT  = 0x7001,
        CHUNK_MATERIAL  = 0xAFFF,
            CHUNK_MATNAME      = 0xA000,
            CHUNK_AMBIENT      = 0xA010,
            CHUNK_DIFFUSE      = 0xA020,
            CHUNK_SPECULAR     = 0xA030,
            CHUNK_SHININESS    = 0xA040,
            CHUNK_SHINSTRENGTH = 0xA041,
            CHUNK_TRANSPARENCY = 0xA050,
            CHUNK_TRANSFALLOFF = 0xA052,
            CHUNK_REFBLUR      = 0xA053,
            CHUNK_TWOSIDED     = 0xA081,
            CHUNK_TRANSADD     = 0xA083,
            CHUNK_SELFILLUM    = 0xA084,
            CHUNK_WIREON       = 0xA085,
            CHUNK_WIRETHICK    = 0xA087,
            CHUNK_SOFTEN       = 0xA08C,
            CHUNK_MATTYPE      = 0xA100,
            CHUNK_TEXTURE1     = 0xA200,
            CHUNK_SPECMAP      = 0xA204,
            CHUNK_OPACMAP      = 0xA210,
            CHUNK_REFLECTION   = 0xA220,
            CHUNK_BUMPMAP      = 0xA230,
            CHUNK_MAPFILE      = 0xA300,
            CHUNK_TEXTURE2     = 0xA33A,
            CHUNK_SHINEMAP     = 0xA33C,
            CHUNK_SILLUMMAP    = 0xA33D,
            CHUNK_MAPFLAGS     = 0xA351,
            CHUNK_MAPUSCALE    = 0xA354,
            CHUNK_MAPVSCALE    = 0xA356,
            CHUNK_MAPUOFFSET   = 0xA358,
            CHUNK_MAPVOFFSET   = 0xA35A,
            CHUNK_MAPROTANGLE  = 0xA35C,
        CHUNK_KEYFRAMER = 0xB000,
            CHUNK_AMBIENTKEY  = 0xB001,
            CHUNK_TRACKINFO   = 0xB002,
            CHUNK_TRACKCAMERA = 0xB003,
            CHUNK_TRACKCAMTGT = 0xB004,
            CHUNK_TRACKLIGHT  = 0xB005,
            CHUNK_TRACKLIGTGT = 0xB006,
            CHUNK_TRACKSPOTL  = 0xB007,
            CHUNK_FRAMES      = 0xB008,
                CHUNK_TRACKOBJNAME  = 0xB010,
                CHUNK_DUMMYNAME     = 0xB011,
                CHUNK_TRACKPIVOT    = 0xB013,
                CHUNK_TRACKPOS      = 0xB020,
                CHUNK_TRACKROTATE   = 0xB021,
                CHUNK_TRACKSCALE    = 0xB022,
                CHUNK_TRACKFOV      = 0xB023,
                CHUNK_TRACKROLL     = 0xB024,
                CHUNK_TRACKCOLOR    = 0xB025,
                CHUNK_TRACKMORPH    = 0xB026,
                CHUNK_TRACKHIDE     = 0xB029,
                CHUNK_OBJNUMBER     = 0xB030,
};


typedef struct
{
    word  chunk_id;
    dword chunk_size;
} c_CHUNK;


typedef struct
{
    word id;
    int  sub;
    int  (*func) (FILE *f);
} c_LISTKEY, c_LISTWORLD;


static int read_NULL         (FILE *f);
static int read_RGBF         (FILE *f);
static int read_RGBB         (FILE *f);
static int read_AMOUNTOF     (FILE *f);
static int read_ASCIIZ       (FILE *f);
static int read_TRIMESH      (FILE *f);
static int read_VERTLIST     (FILE *f);
static int read_FACELIST     (FILE *f);
static int read_FACEMAT      (FILE *f);
static int read_MAPLIST      (FILE *f);
static int read_TRMATRIX     (FILE *f);
static int read_LIGHT        (FILE *f);
static int read_SPOTLIGHT    (FILE *f);
static int read_CAMERA       (FILE *f);
static int read_MATERIAL     (FILE *f);
static int read_MATNAME      (FILE *f);
static int read_FRAMES       (FILE *f);
static int read_OBJNUMBER    (FILE *f);
static int read_TRACKOBJNAME (FILE *f);
static int read_DUMMYNAME    (FILE *f);
static int read_TRACKPIVOT   (FILE *f);
static int read_TRACKPOS     (FILE *f);
static int read_TRACKCOLOR   (FILE *f);
static int read_TRACKROT     (FILE *f);
static int read_TRACKSCALE   (FILE *f);
static int read_TRACKFOV     (FILE *f);
static int read_TRACKROLL    (FILE *f);
static int read_TRACKMORPH   (FILE *f);
static int read_TRACKHIDE    (FILE *f);
static int read_MATTYPE      (FILE *f);
static int read_MATTWOSIDED  (FILE *f);
static int read_MATSOFTEN    (FILE *f);
static int read_MATWIRE      (FILE *f);
static int read_MATTRANSADD  (FILE *f);
static int read_MAPFLAGS     (FILE *f);
static int read_MAPFILE      (FILE *f);
static int read_MAPUSCALE    (FILE *f);
static int read_MAPVSCALE    (FILE *f);
static int read_MAPUOFFSET   (FILE *f);
static int read_MAPVOFFSET   (FILE *f);
static int read_MAPROTANGLE  (FILE *f);


static c_LISTWORLD world_chunks[] =
{
    { CHUNK_RGBF,         0, read_RGBF },
    { CHUNK_RGBB,         0, read_RGBB },
    { CHUNK_AMOUNTOF,     0, read_AMOUNTOF },
    { CHUNK_PRJ,          1, read_NULL },
    { CHUNK_MLI,          1, read_NULL },
    { CHUNK_MAIN,         1, read_NULL },
    { CHUNK_OBJMESH,      1, read_NULL },
    { CHUNK_BKGCOLOR,     1, read_NULL },
    { CHUNK_AMBCOLOR,     1, read_NULL },
    { CHUNK_OBJBLOCK,     1, read_ASCIIZ },
    { CHUNK_TRIMESH,      1, read_TRIMESH },
    { CHUNK_VERTLIST,     0, read_VERTLIST },
    { CHUNK_VERTFLAGS,    0, read_NULL },
    { CHUNK_FACELIST,     1, read_FACELIST },
    { CHUNK_MESHCOLOR,    0, read_NULL },
    { CHUNK_FACEMAT,      0, read_FACEMAT },
    { CHUNK_MAPLIST,      0, read_MAPLIST },
    { CHUNK_TXTINFO,      0, read_NULL },
    { CHUNK_SMOOLIST,     0, read_NULL },
    { CHUNK_TRMATRIX,     0, read_TRMATRIX },
    { CHUNK_LIGHT,        1, read_LIGHT },
    { CHUNK_SPOTLIGHT,    0, read_SPOTLIGHT },
    { CHUNK_CAMERA,       0, read_CAMERA },
    { CHUNK_HIERARCHY,    1, read_NULL },
    { CHUNK_VIEWPORT,     0, read_NULL },
    { CHUNK_MATERIAL,     1, read_MATERIAL },
    { CHUNK_MATNAME,      0, read_MATNAME },
    { CHUNK_AMBIENT,      1, read_NULL },
    { CHUNK_DIFFUSE,      1, read_NULL },
    { CHUNK_SPECULAR,     1, read_NULL },
    { CHUNK_TEXTURE1,     1, read_NULL },
    { CHUNK_TEXTURE2,     1, read_NULL },
    { CHUNK_BUMPMAP,      1, read_NULL },
    { CHUNK_REFLECTION,   1, read_NULL },
    { CHUNK_MAPFILE,      0, read_MAPFILE },
    { CHUNK_MAPFLAGS,     0, read_MAPFLAGS },
    { CHUNK_MAPUSCALE,    0, read_MAPUSCALE },
    { CHUNK_MAPVSCALE,    0, read_MAPVSCALE },
    { CHUNK_MAPUOFFSET,   0, read_MAPUOFFSET },
    { CHUNK_MAPVOFFSET,   0, read_MAPVOFFSET },
    { CHUNK_MAPROTANGLE,  0, read_MAPROTANGLE },
    { CHUNK_SHININESS,    1, read_NULL },
    { CHUNK_SHINSTRENGTH, 1, read_NULL },
    { CHUNK_TRANSPARENCY, 1, read_NULL },
    { CHUNK_TRANSFALLOFF, 1, read_NULL },
    { CHUNK_REFBLUR,      1, read_NULL },
    { CHUNK_SELFILLUM,    1, read_NULL },
    { CHUNK_TWOSIDED,     0, read_MATTWOSIDED },
    { CHUNK_TRANSADD,     0, read_MATTRANSADD },
    { CHUNK_WIREON,       0, read_MATWIRE },
    { CHUNK_SOFTEN,       0, read_MATSOFTEN },
    { CHUNK_MATTYPE,      0, read_MATTYPE }
};


static c_LISTKEY key_chunks[] =
{
    { CHUNK_MAIN,         1, read_NULL },
    { CHUNK_KEYFRAMER,    1, read_NULL },
    { CHUNK_AMBIENTKEY,   1, read_NULL },
    { CHUNK_TRACKINFO,    1, read_NULL },
    { CHUNK_FRAMES,       0, read_FRAMES },
    { CHUNK_TRACKOBJNAME, 0, read_TRACKOBJNAME },
    { CHUNK_DUMMYNAME,    0, read_DUMMYNAME },
    { CHUNK_TRACKPIVOT,   0, read_TRACKPIVOT },
    { CHUNK_TRACKPOS,     0, read_TRACKPOS },
    { CHUNK_TRACKCOLOR,   0, read_TRACKCOLOR },
    { CHUNK_TRACKROTATE,  0, read_TRACKROT },
    { CHUNK_TRACKSCALE,   0, read_TRACKSCALE },
    { CHUNK_TRACKMORPH,   0, read_TRACKMORPH },
    { CHUNK_TRACKHIDE,    0, read_TRACKHIDE },
    { CHUNK_OBJNUMBER,    0, read_OBJNUMBER },
    { CHUNK_TRACKCAMERA,  1, read_NULL },
    { CHUNK_TRACKCAMTGT,  1, read_NULL },
    { CHUNK_TRACKLIGHT,   1, read_NULL },
    { CHUNK_TRACKLIGTGT,  1, read_NULL },
    { CHUNK_TRACKSPOTL,   1, read_NULL },
    { CHUNK_TRACKFOV,     0, read_TRACKFOV },
    { CHUNK_TRACKROLL,    0, read_TRACKROLL }
};

static int   c_chunk_last;
static int   c_chunk_prev;
static int   c_chunk_curr;
static int   c_id;
static char  c_string[64];
static void *c_node;

static int read_NULL(FILE *f)
{
    return 1;
}

static int read_VERTLIST(FILE *f)
{
    c_OBJECT *obj = (c_OBJECT *)c_node;
    c_VERTEX *v;
    float c[3];
    word nv;

    if(fread(&nv, sizeof(nv), 1, f) != 1) return 0;
    v = (c_VERTEX *)base_allocate(nv * sizeof(c_VERTEX));
    obj->vertices = v;
    obj->numverts = nv;
    while(nv-- > 0)
    {
        if(fread(c, sizeof(c), 1, f) != 1) return 0;
        vec_make(c[0], c[1], c[2], &v->vert);
        vec_swap(&v->vert);
        v++;
    }

    return 1;
}

static int read_FRAMES(FILE *f)
{
    dword c[2];
    if(fread(c, sizeof(c), 1, f) != 1) return 0;
    aiw_scene->f_start = c[0];
    aiw_scene->f_end = c[1];
    return 1;
}

static int read_OBJNUMBER(FILE *f)
{
    word n;
    if(fread(&n, sizeof(n), 1, f) != 1) return 0;
    c_id = n;
    return 1;
}

static int read_CHUNK(FILE *f, c_CHUNK *h)
{
    if(fread(&h->chunk_id, sizeof(word), 1, f) != 1) return 0;
    if(fread(&h->chunk_size, sizeof(dword), 1, f) != 1) return 0;
    return 1;
}

static int ChunkReaderWorld(FILE *f, long p, word parent)
{
    c_CHUNK h;
    long pc;
    int n, i, error;

    c_chunk_last = parent;
    while((pc = ftell(f)) < p)
    {
        if(read_CHUNK(f, &h) != 0) return 0;
        c_chunk_curr = h.chunk_id;
        n = -1;
        for(i = 0; i < sizeof(world_chunks) / sizeof(world_chunks[0]); i++)
        {
            if(h.chunk_id == world_chunks[i].id)
            {
                n = i;
                break;
            }
        }
        if(n < 0)
            fseek(f, pc + h.chunk_size, SEEK_SET);
        else
        {
            pc = pc + h.chunk_size;
            if((error = world_chunks[n].func(f)) != 0) return error;
            if(world_chunks[n].sub)
                if((error = ChunkReaderWorld(f, pc, h.chunk_id)) != 0)
                    return error;
            fseek(f, pc, SEEK_SET);
            c_chunk_prev = h.chunk_id;
        }
        if(ferror(f)) return 0;
    }

    return 1;
}

int aiw_load_mesh_3DS(FILE *f)
{
    byte version;
    long length;

    c_id = 0;
    fseek(f, 0, SEEK_END);
    length = ftell(f);
    fseek(f, 28L, SEEK_SET);
    if(fread(&version, sizeof(byte), 1, f) != 1) return 0;
    if(version < 2) return 0;
    fseek(f, 0, SEEK_SET);

    return ChunkReaderWorld(f, length, 0);
}