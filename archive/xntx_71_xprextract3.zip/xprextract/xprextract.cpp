// XPR texture/meshdata rip tool. Mirage 2003-03-04
// Feel free to modify whatever you want

#include "stdafx.h"
#include <stdio.h>
#include <stdlib.h>
#include <windows.h>

#include <io.h>
#include <fcntl.h>
#include <sys\types.h>
#include <sys\stat.h>

typedef unsigned char  byte;
typedef unsigned short word;
typedef unsigned int   dword;

#define MAX_NUM_RESOURCES 1024

#define D3DCOMMON_TYPE_MASK				0x00070000
#define D3DCOMMON_TYPE_SHIFT			16
#define D3DCOMMON_TYPE_VERTEXBUFFER		0x00000000
#define D3DCOMMON_TYPE_INDEXBUFFER		0x00010000
#define D3DCOMMON_TYPE_PUSHBUFFER		0x00020000
#define D3DCOMMON_TYPE_PALETTE			0x00030000
#define D3DCOMMON_TYPE_TEXTURE			0x00040000
#define D3DCOMMON_TYPE_SURFACE			0x00050000
#define D3DCOMMON_TYPE_FIXUP			0x00060000

#define D3DFORMAT_RESERVED1_MASK        0x00000003      // Must be zero
                                        
#define D3DFORMAT_DMACHANNEL_MASK       0x00000003
#define D3DFORMAT_DMACHANNEL_A          0x00000001      // DMA channel A - the default for all system memory
#define D3DFORMAT_DMACHANNEL_B          0x00000002      // DMA channel B - unused
#define D3DFORMAT_CUBEMAP               0x00000004      // Set if the texture if a cube map
#define D3DFORMAT_BORDERSOURCE_COLOR    0x00000008
#define D3DFORMAT_DIMENSION_MASK        0x000000F0      // # of dimensions
#define D3DFORMAT_DIMENSION_SHIFT       4
#define D3DFORMAT_FORMAT_MASK           0x0000FF00
#define D3DFORMAT_FORMAT_SHIFT          8
#define D3DFORMAT_MIPMAP_MASK           0x000F0000
#define D3DFORMAT_MIPMAP_SHIFT          16
#define D3DFORMAT_USIZE_MASK            0x00F00000      // Log 2 of the U size of the base texture
#define D3DFORMAT_USIZE_SHIFT           20
#define D3DFORMAT_VSIZE_MASK            0x0F000000      // Log 2 of the V size of the base texture
#define D3DFORMAT_VSIZE_SHIFT           24
#define D3DFORMAT_PSIZE_MASK            0xF0000000      // Log 2 of the P size of the base texture
#define D3DFORMAT_PSIZE_SHIFT           28

#define FMT_SWIZZLED					0x1
#define FMT_LINEAR						0x2
#define FMT_COMPRESSED					0x4

#define DDSD_CAPS						0x00000001
#define DDSD_HEIGHT						0x00000002
#define DDSD_WIDTH						0x00000004
#define DDSD_PITCH						0x00000008
#define DDSD_PIXELFORMAT				0x00001000
#define DDSD_MIPMAPCOUNT				0x00020000
#define DDSD_LINEARSIZE					0x00080000
#define DDSD_DEPTH						0x00800000

#define DDPF_ALPHAPIXELS				0x00000001
#define DDPF_FOURCC						0x00000004
#define DDPF_RGB						0x00000040

#define DDSCAPS_COMPLEX					0x00000008
#define DDSCAPS_TEXTURE					0x00001000
#define DDSCAPS_MIPMAP					0x00400000

#define DDSCAPS2_CUBEMAP				0x00000200
#define DDSCAPS2_CUBEMAP_POSITIVEX		0x00000400
#define DDSCAPS2_CUBEMAP_NEGATIVEX		0x00000800
#define DDSCAPS2_CUBEMAP_POSITIVEY		0x00001000
#define DDSCAPS2_CUBEMAP_NEGATIVEY		0x00002000
#define DDSCAPS2_CUBEMAP_POSITIVEZ		0x00004000
#define DDSCAPS2_CUBEMAP_NEGATIVEZ		0x00008000
#define DDSCAPS2_VOLUME					0x00200000


const struct TEXTUREFORMAT
{
    char* name;
    dword id;
    dword type;
} g_TextureFormats[] =
{
    { "D3DFMT_A8R8G8B8",        0x00000006 /* D3DFMT_A8R8G8B8 */,      FMT_SWIZZLED    },
    { "D3DFMT_LIN_A8R8G8B8",    0x00000012 /* D3DFMT_LIN_A8R8G8B8 */,  FMT_LINEAR      },
    { "D3DFMT_X8R8G8B8",        0x00000007 /* D3DFMT_X8R8G8B8 */,      FMT_SWIZZLED    },
    { "D3DFMT_LIN_X8R8G8B8",    0x0000001E /* D3DFMT_LIN_X8R8G8B8 */,  FMT_LINEAR      },
    { "D3DFMT_R5G6B5",          0x00000005 /* D3DFMT_R5G6B5 */,        FMT_SWIZZLED    },
    { "D3DFMT_LIN_R5G6B5",      0x00000011 /* D3DFMT_LIN_R5G6B5 */,    FMT_LINEAR      },
    { "D3DFMT_A1R5G5B5",        0x00000002 /* D3DFMT_A1R5G5B5 */,      FMT_SWIZZLED    },
    { "D3DFMT_LIN_A1R5G5B5",    0x00000010 /* D3DFMT_LIN_A1R5G5B5 */,  FMT_LINEAR      },
    { "D3DFMT_A4R4G4B4",        0x00000004 /* D3DFMT_A4R4G4B4 */,      FMT_SWIZZLED    },
    { "D3DFMT_LIN_A4R4G4B4",    0x0000001D /* D3DFMT_LIN_A4R4G4B4 */,  FMT_LINEAR      },
    { "D3DFMT_DXT1",            0x0000000C /* D3DFMT_DXT1 */,          FMT_COMPRESSED  },
    { "D3DFMT_DXT2",            0x0000000E /* D3DFMT_DXT2 */,          FMT_COMPRESSED  },
    { "D3DFMT_DXT4",            0x0000000F /* D3DFMT_DXT4 */,          FMT_COMPRESSED  },
    { "",                       0,                                     0               },
};

dword exptbl[] = {1,2,4,8,16,32,64,128,256,512,1024,2048,4096,0,0,0,0,0,0};

enum chunks3DS
{
	CHUNK_0002       = 0x0002,
    CHUNK_RGBF      = 0x0010,
    CHUNK_RGBB      = 0x0011,
    CHUNK_RBGB2     = 0x0012,
    CHUNK_AMOUNTOF  = 0x0030,
	CHUNK_0100      = 0x0100,
    CHUNK_PRJ       = 0xC23D,
    CHUNK_MLI       = 0x3DAA,
	CHUNK_3D3E      = 0x3D3E,
    CHUNK_MAIN      = 0x4D4D,
        CHUNK_OBJMESH   = 0x3D3D,
            CHUNK_BKGCOLOR  = 0x1200,
            CHUNK_AMBCOLOR  = 0x2100,
            CHUNK_OBJBLOCK  = 0x4000,
                CHUNK_TRIMESH   = 0x4100,
                    CHUNK_VERTLIST  = 0x4110,
                    CHUNK_VERTFLAGS = 0x4111,
                    CHUNK_FACELIST  = 0x4120,
                    CHUNK_FACEMAT   = 0x4130,
                    CHUNK_MAPLIST   = 0x4140,
                    CHUNK_SMOOLIST  = 0x4150,
                    CHUNK_TRMATRIX  = 0x4160,
                    CHUNK_MESHCOLOR = 0x4165,
                    CHUNK_TXTINFO   = 0x4170,
                CHUNK_LIGHT     = 0x4600,
                    CHUNK_SPOTLIGHT = 0x4610,
                    CHUNK_LIGHTOFF  = 0x4620,
                CHUNK_CAMERA    = 0x4700,
                CHUNK_HIERARCHY = 0x4F00,
        CHUNK_VIEWPORT  = 0x7001,
        CHUNK_MATERIAL  = 0xAFFF,
            CHUNK_MATNAME      = 0xA000,
            CHUNK_AMBIENT      = 0xA010,
            CHUNK_DIFFUSE      = 0xA020,
            CHUNK_SPECULAR     = 0xA030,
            CHUNK_SHININESS    = 0xA040,
            CHUNK_SHINSTRENGTH = 0xA041,
            CHUNK_TRANSPARENCY = 0xA050,
            CHUNK_TRANSFALLOFF = 0xA052,
            CHUNK_REFBLUR      = 0xA053,
            CHUNK_TWOSIDED     = 0xA081,
            CHUNK_TRANSADD     = 0xA083,
            CHUNK_SELFILLUM    = 0xA084,
            CHUNK_WIREON       = 0xA085,
            CHUNK_WIRETHICK    = 0xA087,
            CHUNK_SOFTEN       = 0xA08C,
            CHUNK_MATTYPE      = 0xA100,
            CHUNK_TEXTURE1     = 0xA200,
            CHUNK_SPECMAP      = 0xA204,
            CHUNK_OPACMAP      = 0xA210,
            CHUNK_REFLECTION   = 0xA220,
            CHUNK_BUMPMAP      = 0xA230,
            CHUNK_MAPFILE      = 0xA300,
            CHUNK_TEXTURE2     = 0xA33A,
            CHUNK_SHINEMAP     = 0xA33C,
            CHUNK_SILLUMMAP    = 0xA33D,
            CHUNK_MAPFLAGS     = 0xA351,
            CHUNK_MAPUSCALE    = 0xA354,
            CHUNK_MAPVSCALE    = 0xA356,
            CHUNK_MAPUOFFSET   = 0xA358,
            CHUNK_MAPVOFFSET   = 0xA35A,
            CHUNK_MAPROTANGLE  = 0xA35C,
        CHUNK_KEYFRAMER = 0xB000,
            CHUNK_AMBIENTKEY  = 0xB001,
            CHUNK_TRACKINFO   = 0xB002,
            CHUNK_TRACKCAMERA = 0xB003,
            CHUNK_TRACKCAMTGT = 0xB004,
            CHUNK_TRACKLIGHT  = 0xB005,
            CHUNK_TRACKLIGTGT = 0xB006,
            CHUNK_TRACKSPOTL  = 0xB007,
            CHUNK_FRAMES      = 0xB008,
                CHUNK_TRACKOBJNAME  = 0xB010,
                CHUNK_DUMMYNAME     = 0xB011,
                CHUNK_TRACKPIVOT    = 0xB013,
                CHUNK_TRACKPOS      = 0xB020,
                CHUNK_TRACKROTATE   = 0xB021,
                CHUNK_TRACKSCALE    = 0xB022,
                CHUNK_TRACKFOV      = 0xB023,
                CHUNK_TRACKROLL     = 0xB024,
                CHUNK_TRACKCOLOR    = 0xB025,
                CHUNK_TRACKMORPH    = 0xB026,
                CHUNK_TRACKHIDE     = 0xB029,
                CHUNK_OBJNUMBER     = 0xB030,
};

void xprextract(char *filename)
{
	dword magic, filesize, headersize, offset, texturetype, i, j, j2, j3, y;
    dword dwFmt, dwDim, dwU, dwV, dwP, dwLevels, dwCube;
	word numverts;
    char eight[32], three[32], fndds[32], fn3ds[32];
	FILE *fpxpr, *fpdds, *fp3ds;

	sscanf(filename, "%[^'.'].%[^'.']", &eight, &three);
	
	if(!(fpxpr = fopen(filename, "rb")))
	{
		printf("\nNo such file.\n");
		return;
	}

	printf("\nReading file: %s\n\n", filename);

	fread(&magic, sizeof(dword), 1, fpxpr);
    fread(&filesize, sizeof(dword), 1, fpxpr);
    fread(&headersize, sizeof(dword), 1, fpxpr);

	printf("XPR0 magic header: %x\n", magic);
	printf("Filesize:          %d (0x%x)\n", filesize, filesize);
	printf("Headersize:        %d (0x%x)\n", headersize, headersize);
	
	int fh = _open(filename, _O_RDONLY);
	filesize = filelength(fh);
	printf("Actual filesize:   %d", filesize);

	printf("\n");

    byte *headerdata = new byte[headersize-3*sizeof(dword)];
    fread(headerdata, headersize-3*sizeof(dword), 1, fpxpr);

	byte *xprdata = new byte[filesize-headersize];
    fread(xprdata, filesize-headersize, 1, fpxpr);

	fclose(fpxpr);

    byte *pbCurrent = headerdata;
	byte *skip;
	j = 0; j2 = 0; j3 = 0;
    for(i = 0; i < MAX_NUM_RESOURCES; i++)
    {
        dword type = *((dword *)pbCurrent);

		if((type != 0x80000000 /* D3DCOMMON_TYPE_VERTEXBUFFER */) &&
           (type != 0x00040001 /* D3DCOMMON_TYPE_TEXTURE */) &&
           (type != 0x00800001 /* D3DCOMMON_TYPE_INDEXBUFFER */))
            break;

		skip = pbCurrent+4;
		offset = *((dword *)skip);
		texturetype = *((dword *)(pbCurrent+12));

		// find out texture details
		dwFmt = (texturetype & D3DFORMAT_FORMAT_MASK) >> D3DFORMAT_FORMAT_SHIFT;
		for(int x=0; g_TextureFormats[x].id != 0; x++)
			if(g_TextureFormats[x].id == dwFmt)
				break;
		if(g_TextureFormats[x].id != 0)
		{
			dwDim    = (texturetype & D3DFORMAT_DIMENSION_MASK) >> D3DFORMAT_DIMENSION_SHIFT;
			dwLevels = (texturetype & D3DFORMAT_MIPMAP_MASK) >> D3DFORMAT_MIPMAP_SHIFT;
			dwCube   = (texturetype & D3DFORMAT_CUBEMAP);

			// assuming all texture are compressed (not linear)
			dwU = exptbl[(texturetype & D3DFORMAT_USIZE_MASK) >> D3DFORMAT_USIZE_SHIFT];
			dwV = exptbl[(texturetype & D3DFORMAT_VSIZE_MASK) >> D3DFORMAT_VSIZE_SHIFT];
			dwP = exptbl[(texturetype & D3DFORMAT_PSIZE_MASK) >> D3DFORMAT_PSIZE_SHIFT];
		}

		// if it's a texture, write dds to disk
		if((type & D3DCOMMON_TYPE_MASK) == D3DCOMMON_TYPE_TEXTURE)
		{
			sprintf(fndds, "%s%d.dds", eight, j);
			printf("%s: t:%s f:%x d:%d l:%d c:%d u:%d v:%d p:%d\n",
				fndds, g_TextureFormats[x].name, texturetype, dwDim, dwLevels, dwCube, dwU, dwV, dwP);

			if(!(fpdds = fopen(fndds, "wb"))) printf("Filecreation failed\n");

			// first write the DDS header
			char ddsmagic[5] = "DDS ";
			dword ddsheadersize = 124;
			dword ddscaps = DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH | DDSD_PIXELFORMAT | DDSD_LINEARSIZE;
			dword imagesize = (dwU*dwV);
			if(g_TextureFormats[x].id == 0x0000000C /*DXT1*/) imagesize /= 2;
			dword depth = 0; // this is no volume texture
			dword mipmapcount = 0;
			dword reserved = 0;
			dword pixelformat = 0;
			
			fwrite(&ddsmagic, 4, 1, fpdds);
			fwrite(&ddsheadersize, sizeof(dword), 1, fpdds);
			fwrite(&ddscaps, sizeof(dword), 1, fpdds);
			fwrite(&dwV, sizeof(dword), 1, fpdds);
			fwrite(&dwU, sizeof(dword), 1, fpdds);
			fwrite(&imagesize, sizeof(dword), 1, fpdds);
			fwrite(&depth, sizeof(dword), 1, fpdds);
			fwrite(&mipmapcount, sizeof(dword), 1, fpdds);
			for(y=0; y<11; y++) fwrite(&reserved, sizeof(dword), 1, fpdds);

			// next up, the DDPIXELFORMAT structure
			dword ddpfsize = 32;
			dword ddpfflags = DDPF_FOURCC; // DDPF_RGB = non-compressed
			char ddpffourcc[5];
			sprintf(ddpffourcc, "%s", "DXT4");
			if(g_TextureFormats[x].id == 0x0000000C) sprintf(ddpffourcc, "%s", "DXT1");
			else if(g_TextureFormats[x].id == 0x0000000E) sprintf(ddpffourcc, "%s", "DXT2");
			dword ddpfrgbbitcount = 0; // all doa textures seem to be dxt1/dxt4 textures,
			dword ddpfrgbrmask = 0; // so i'm not bothered with DDPF_RGB flags
			dword ddpfrgbgmask = 0;
			dword ddpfrgbbmask = 0;
			dword ddpfrgbamask = 0;

			fwrite(&ddpfsize, sizeof(dword), 1, fpdds);
			fwrite(&ddpfflags, sizeof(dword), 1, fpdds);
			fwrite(&ddpffourcc, 4, 1, fpdds);
			fwrite(&ddpfrgbbitcount, sizeof(dword), 1, fpdds);
			fwrite(&ddpfrgbrmask, sizeof(dword), 1, fpdds);
			fwrite(&ddpfrgbgmask, sizeof(dword), 1, fpdds);
			fwrite(&ddpfrgbbmask, sizeof(dword), 1, fpdds);
			fwrite(&ddpfrgbamask, sizeof(dword), 1, fpdds);

			// finally the DDCAPS2 structure
			dword caps1 = DDSCAPS_TEXTURE; // expecting no mipmaps
			dword caps2 = 0; // cubemaps are a no-go

			fwrite(&caps1, sizeof(dword), 1, fpdds);
			fwrite(&caps2, sizeof(dword), 1, fpdds);
			for(y=0; y<3; y++) fwrite(&reserved, sizeof(dword), 1, fpdds);

		    if(!fwrite(xprdata+offset, imagesize, 1, fpdds)) printf("Write failed\n");

			fclose(fpdds);

			j++;
		}

		// it's an indexbuffer
		if(type == 0x80000000)
		{
			j2++;
		}

		// it's a vertexbuffer
		if(type == 0x00800001)
		{
			numverts = 1860;

			sprintf(fn3ds, "%s%d.3ds", eight, j3);
			printf("%s\n",fn3ds);

			if(!(fp3ds = fopen(fn3ds, "wb"))) printf("Filecreation failed\n");

			word chunkmain = CHUNK_MAIN;
			word chunk0002 = CHUNK_0002;
			word chunkobjmesh = CHUNK_OBJMESH;
			word chunk3d3e = CHUNK_3D3E;
			word chunk0100 = CHUNK_0100;
			word chunkobjblock = CHUNK_OBJBLOCK;
			word chunktrimesh = CHUNK_TRIMESH;
			word chunkvertlist = CHUNK_VERTLIST;
			word chunktrmatrix = CHUNK_TRMATRIX;
			word chunkkeyframer = CHUNK_KEYFRAMER;

			dword chunkmainsize = 341 + 3*numverts*sizeof(float);
			dword chunk0002size = 0x0000000A;
			dword chunk0002data = 0x00000003;
			dword chunkobjmeshsize = 106 + 3*numverts*sizeof(float);
			dword chunk3d3esize = 0x0000000A;
			dword chunk3d3edata = 0x00000003;
			dword chunk0100size = 0x0000000A;
			dword chunk0100data = 0x3F800000;
			dword chunkobjblocksize = 80 + 3*numverts*sizeof(float);
			char point[6] = "point";
			dword chunktrimeshsize = 68 + 3*numverts*sizeof(float);
			dword chunkvertlistsize = 8 + 3*numverts*sizeof(float);
			dword chunktrmatrixsize = 0x00000036;
			byte chunktrmatrixdata[48] = {
				0x00, 0x00, 0x80, 0x3F, 0x00, 0x00, 0x00, 0x00,
				0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
				0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x80, 0x3F,
				0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x80, 0xBF,
				0x00, 0x00, 0x00, 0x00, 0xF8, 0x73, 0x3F, 0x41,
				0xA6, 0xF2, 0x55, 0xB3, 0x80, 0xDE, 0x91, 0x3F,
			};
			dword chunkkeyframersize = 0x000000DB;
			byte chunkkeyframerdata[213] = {
				0x0A, 0xB0, 0x15, 0x00, 0x00, 0x00, 0x05, 0x00,
				0x4D, 0x41, 0x58, 0x53, 0x43, 0x45, 0x4E, 0x45,
				0x00, 0x64, 0x00, 0x00, 0x00, 0x08, 0xB0, 0x0E,
				0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x64,
				0x00, 0x00, 0x00, 0x09, 0xB0, 0x0A, 0x00, 0x00,
				0x00, 0x00, 0x00, 0x00, 0x00, 0x02, 0xB0, 0xA8,
				0x00, 0x00, 0x00, 0x30, 0xB0, 0x08, 0x00, 0x00,
				0x00, 0x00, 0x00, 0x10, 0xB0, 0x12, 0x00, 0x00,
				0x00, 0x70, 0x6F, 0x69, 0x6E, 0x74, 0x00, 0x00,
				0x00, 0x40, 0x00, 0xFF, 0xFF, 0x13, 0xB0, 0x12,

				0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x80, 0x00,
				0x00, 0x00, 0x80, 0x00, 0x00, 0x00, 0x80, 0x20,
				0xB0, 0x26, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
				0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01,
				0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
				0x00, 0xF8, 0x73, 0x3F, 0x41, 0xA6, 0xF2, 0x55,
				0xB3, 0x80, 0xDE, 0x91, 0x3F, 0x21, 0xB0, 0x2A,
				0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
				0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00,
				0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xDB,

				0x0F, 0xC9, 0x3F, 0x00, 0x00, 0x80, 0xBF, 0x00,
				0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x22,
				0xB0, 0x26, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
				0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01,
				0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
				0x00, 0x00, 0x00, 0x80, 0x3F, 0x00, 0x00, 0x80,
				0x3F, 0x00, 0x00, 0x80, 0x3F
			};

			fwrite(&chunkmain, sizeof(word), 1, fp3ds);
			fwrite(&chunkmainsize, sizeof(dword), 1, fp3ds);
			fwrite(&chunk0002, sizeof(word), 1, fp3ds);
			fwrite(&chunk0002size, sizeof(dword), 1, fp3ds);
			fwrite(&chunk0002data, sizeof(dword), 1, fp3ds);
			fwrite(&chunkobjmesh, sizeof(word), 1, fp3ds);
			fwrite(&chunkobjmeshsize, sizeof(dword), 1, fp3ds);
			fwrite(&chunk3d3e, sizeof(word), 1, fp3ds);
			fwrite(&chunk3d3esize, sizeof(dword), 1, fp3ds);
			fwrite(&chunk3d3edata, sizeof(dword), 1, fp3ds);
			fwrite(&chunk0100, sizeof(word), 1, fp3ds);
			fwrite(&chunk0100size, sizeof(dword), 1, fp3ds);
			fwrite(&chunk0100data, sizeof(dword), 1, fp3ds);
			fwrite(&chunkobjblock, sizeof(word), 1, fp3ds);
			fwrite(&chunkobjblocksize, sizeof(dword), 1, fp3ds);
			fwrite(&point, sizeof(point), 1, fp3ds);
			fwrite(&chunktrimesh, sizeof(word), 1, fp3ds);
			fwrite(&chunktrimeshsize, sizeof(dword), 1, fp3ds);
			fwrite(&chunkvertlist, sizeof(word), 1, fp3ds);
			fwrite(&chunkvertlistsize, sizeof(dword), 1, fp3ds);
			fwrite(&numverts, sizeof(word), 1, fp3ds);

			for(y=0; y<numverts; y++)
			{
				dword vertexsize = 10;
				// printf("%8x %f\n", ((dword *)xprdata+(offset/4)+y)[0], ((float *)xprdata+(offset/4)+y)[0]);

				float v1 = 100.0f * ((float *)xprdata+(offset/4)+0+vertexsize*y)[0];
				float v2 = 100.0f * ((float *)xprdata+(offset/4)+0+vertexsize*y)[1];
				float v3 = 100.0f * ((float *)xprdata+(offset/4)+0+vertexsize*y)[2];
				
				fwrite(&v1, sizeof(float), 1, fp3ds);
				fwrite(&v2, sizeof(float), 1, fp3ds);
				fwrite(&v3, sizeof(float), 1, fp3ds);
			}

			fwrite(&chunktrmatrix, sizeof(word), 1, fp3ds);
			fwrite(&chunktrmatrixsize, sizeof(dword), 1, fp3ds);
			fwrite(&chunktrmatrixdata, sizeof(chunktrmatrixdata), 1, fp3ds);

			fwrite(&chunkkeyframer, sizeof(word), 1, fp3ds);
			fwrite(&chunkkeyframersize, sizeof(dword), 1, fp3ds);
			fwrite(&chunkkeyframerdata, sizeof(chunkkeyframerdata), 1, fp3ds);

			j3++;
		}

		if(type == 0x80000000) pbCurrent = pbCurrent + 8 + *((dword *)skip);
			else if(type == 0x00800001) pbCurrent += 12;
				else pbCurrent += 20;
    }
}

int main(int argc, char* argv[])
{
	WIN32_FIND_DATA FileData;
	HANDLE hSearch;
	BOOL bFinished = FALSE;

	printf("\nXPR-texture-chunk exporter by Mirage (2003-03-04)\n");
	printf("Currently only DXT1/2/4 textures are supported\n");

	if(argc < 2)
	{
		printf("\nUsage: xprextract [file.xpr]\n");
		exit(1);
	}

	hSearch = FindFirstFile (TEXT(argv[1]), &FileData);
	if (hSearch == INVALID_HANDLE_VALUE)
	{
		printf("\nNo files found.\n");
		return 0;
	}

	while (!bFinished)
	{
		xprextract(FileData.cFileName);

		if (!FindNextFile (hSearch, &FileData)) bFinished = TRUE;
	}

	dword hrmpf[3];
	hrmpf[0] = 0x3b9b9610;
	hrmpf[1] = 0x3d0e005b;
	hrmpf[2] = 0x3e262d19;
	printf("%f\n", ((float *)hrmpf)[0]);
	printf("%f\n", ((float *)hrmpf)[1]);
	printf("%f\n", ((float *)hrmpf)[2]);

	return 0;
}
