import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class fontToRaw {
	
	private static final int charWidth = 19;
	private static final int charHeight = 36;
	
	private static int atlasWidth = 1024;
	private int atlasHeight;
	private int numCharacters;

	class Character {
		byte[][] bitmap = new byte[charHeight][charWidth];
	}

	public static void main(String[] args) {
		// Usage: java fontToRaw <inputFile> [ <atlasWidth> ]
		
		String filename;
		
		if (args.length == 0) {
			// if no arguments: get filename from console
			Scanner sc = new Scanner(System.in);
			System.out.print("Enter filename: ");
			filename = sc.next();
		} else {
			filename = args[0];
			if (args.length == 2) {
				atlasWidth = Integer.parseInt(args[1]);
			}
		}
		
		new fontToRaw(filename);
	}

	public fontToRaw(String filename) {
		File fileIn = new File(filename);
		
		try {
			BufferedInputStream in = new BufferedInputStream(new FileInputStream(fileIn));
			
			in.skip(12); // skip header
			
			numCharacters = (in.read() & 0xFF) | (in.read() & 0xFF) << 8; in.skip(2);
			
			// skip font table
			int toSkip = numCharacters * 12;
			while (toSkip > 0) {
				toSkip -= in.skip(toSkip);
			}
			
			Character[] list = new Character[numCharacters];
			
			// read in all font characters
			for (int i = 0; i < numCharacters; i++) {
				
				Character c = new Character();
				
				for (int h = 0; h < charHeight; h++) {
					for (int w = 0; w < charWidth; w++) {
						c.bitmap[h][w] = (byte)in.read();
					}
				}
				in.skip(4);
				
				list[i] = c;
			}
			
			in.close();
			
			// create texture atlas
			int charsPerRow = atlasWidth / charWidth;
			atlasHeight = charHeight * (int)Math.ceil((double)numCharacters / charsPerRow);
			byte[][] atlas = new byte[atlasHeight][atlasWidth];
			
			int height = 0;
			int width = 0;
			
			// write characters to texture atlas
			for (Character c : list) {
				for (int h = 0; h < charHeight; h++) {
					for (int w = 0; w < charWidth; w++) {
						atlas[height * charHeight + h][width * charWidth + w] = c.bitmap[h][w];
					}
				}
				width++;
				if (width == charsPerRow) {
					width = 0;
					height++;
				}
			}
			
			// create output file
			File fileOut = new File(filename + "_" + atlasWidth + "x" + atlasHeight + ".raw");
			
			// write texture atlas to output file
			BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(fileOut));
			for (int h = 0; h < atlasHeight; h++) {
				for (int w = 0; w < atlasWidth; w++) {
					out.write(atlas[h][w]);
				}
			}
			
			out.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}