from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Star Wars: Jedi Starfighter [PS2]", ".tex")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    if noeStrFromBytes(bs.readBytes(4))  != "YATF": return 0
    return 1

def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.seek(0x4)
    bs.readUShort()
    unk1 = bs.readByte()
    unk2 = bs.readByte()
    bs.readByte()
    bs.readByte()
    bs.readByte()
    bs.readByte()
    imgHeight = bs.readUInt()
    imgWidth = bs.readUInt()
    if unk1 == 0x1:
        palette = bs.readBytes(0x400)
        data = bs.readBytes(bs.getSize() - bs.tell())
        data = rapi.imageDecodeRawPal(data, palette, imgWidth, imgHeight, 8, "r8 g8 b8 a8")
    elif unk1 == 0x3:
        data = bs.readBytes(bs.getSize() - bs.tell())
        data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "r8 g8 b8")
    elif unk1 == 0x5:
        palette = bs.readBytes(0x40)
        data = bs.readBytes(bs.getSize() - bs.tell())
        data = rapi.imageDecodeRawPal(data, palette, imgWidth, imgHeight, 4, "r8 g8 b8 a8")
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, noesis.NOESISTEX_RGBA32))
    return 1