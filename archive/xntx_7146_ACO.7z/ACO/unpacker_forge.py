import subprocess

import struct
import os

array_tex=[]

#manual_mode = True
#manual_format="DXT5"
#path_Directory = "D:\\Program Files\\Middle-earth. Shadow of Mordor\\Arch05\\!!Unpack\\models\\weapons\\player_weapons\\player_sword01\\"
path_Directory = 'G:\\SteamLibrary\\steamapps\\common\\Assassins Creed Odyssey' #raw_input("Path to the directory? (finish on the \"\\\") ")


for root, dirs, files in os.walk(path_Directory):
    for name in files:
        fullname = os.path.join(root, name)

        if fullname.endswith('.forge'):

           #-- try:
           #print '"G:\\SteamLibrary\\steamapps\\acu\\quickbms\\quickbms_4gb_files.exe" -K ' + '"' + path_Directory + 'assassin_creed_raw.bms" ' + '"' + fullname + '" ' + '"' + fullname + 'folder' + '" '
           str__ = '\"G:\\quickbms\\quickbms_4gb_files.exe\" -K -d '
           str__ = str__ + '\"G:\\SteamLibrary\\steamapps\\acu\\AC_O_Odyssey_UPD2a.bms\"  '
           str__ = str__ + '\"' + fullname  + '"  '
           str__ = str__ + '\"' + fullname + 'folder'  + '"  '
           if not os.path.exists(fullname + 'folder'):
               os.makedirs(fullname + 'folder')
           #str__ = 
           #str__ = 

           print(str__)


		   
           subprocess.call(str__)
print ("end of dds creating")

input()
print ("end of dds creating")
