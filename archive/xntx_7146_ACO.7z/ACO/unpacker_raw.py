import subprocess

import struct
import os
import shutil
import datetime


array_tex=[]


game = "acod" # for AssassinsCreedOrigins -  "acor", AssassinsCreedOdyssey "acod"
input_path = 'G:\\SteamLibrary\\steamapps\\common\\sorted_all'
output_path = 'G:\\AssassinsCreedOdyseyUNP'
bms_binary_path = 'G:\\quickbms\\quickbms_4gb_files.exe'
script_path =  'G:\\SteamLibrary\\steamapps\\acu\\assassin_creed_raw.bms'
export_without_sort = False
export_mesh = 	True
export_textures = False
replase_files = False


def sort_mesh(path_and_file):
	path, file = os.path.split(path_and_file)
	if(file.lower().startswith("acd_ch")): return True
	return False
	if(file.find("(") >= 0): return False
	if(file.lower().find("lod0") >= 0): return True
	if(file.lower().find("lod") >= 0): return False
	return True

def sort_tex(path_and_file):
	path, file = os.path.split(path_and_file)
	if(file.find("(") >= 0): return False
	return True


	
	
	
	
	
	
	
	
	
	
	
	
	
	
#2535097390

print(output_path)
if (not os.path.exists(output_path)): os.makedirs(output_path)

path_logfile = os.path.join(output_path, "errors.log")
logfile = 0
if(not os.path.exists(path_logfile)): logfile = open(path_logfile,'w')
else: 
	logfile = open(path_logfile,'a')

now = datetime.datetime.now()
logfile.write("\n\n\nstart script: " + str(now) + "\n")
logfile.flush()
#section 1 for mesh

#LOD_SELECTOR = 1373399936,
#BUILD_TABLE = 585940579,
#MESH = 1096652136,
#skeleton 615435132
if(export_mesh):
	mesh_dirs = ["1373399936", "585940579", "1096652136"]

	logfile.write("WORK WITH MESH" + "\n")
	logfile.flush()

	for ftype in mesh_dirs:
		local_in_root = os.path.join(input_path, ftype)
		local_out_root = os.path.join(output_path, ftype)
		if (not os.path.exists(local_out_root)): os.makedirs(local_out_root)

		for root, dirs, files in os.walk(local_in_root):
			for name in files:
				try:
					if((sort_mesh(os.path.join(root, name)) ) or (export_without_sort)):							
						fullname = os.path.join(root, name)
						if fullname.endswith('.raw'):
							print(fullname)
							execut_str = '\"' + bms_binary_path + '\" -K -d '
							execut_str = execut_str + '\"' + script_path + '\" '
							execut_str = execut_str + '\"' + fullname + '\"  '	
							execut_str = execut_str + '\"' + local_out_root + '\"  '
							subprocess.call(execut_str)
							loc_old_name = os.path.join(local_out_root,name, name[:-4],"1.dat")
							loc_new_name = os.path.join(local_out_root, name[:-4]) + "." + game +"mesh"
							
							print(loc_old_name)
							print(loc_new_name)

							if(os.path.exists(loc_old_name)):
								if(replase_files):
									if(os.path.exists(loc_new_name)): os.remove(loc_new_name)
								if(not replase_files):
									while(os.path.exists(loc_new_name)): loc_new_name = loc_new_name[: -len("." + game +"mesh" ) ] + "_" + "." + game +"mesh" 
								os.rename(loc_old_name, loc_new_name)

								print("")
							else:
								print("ERROR:: not exists " + loc_old_name)
								logfile.write("ERROR_1:: not exists " + loc_old_name + "\n")
								logfile.flush()
							print("remove " + os.path.join(local_out_root,name))
							if(os.path.exists(os.path.join(local_out_root,name))):
								shutil.rmtree(os.path.join(local_out_root,name))
							#else:
							#	print("ERROR:: not exists " + os.path.join(local_out_root,name))
							#	logfile.write("ERROR:: not exists " + os.path.join(local_out_root,name) + "\n")
				except Exception:
					logfile.write("ERROR_6:: except error " + root + " "+ name + "\n")



if(export_textures):
	#textures

	#MIPMAP = 491489187
	#TEXTURE_SET = 3608045168,   
	#TEXTURE_MAP = 2729961751
	array_tex=["2729961751"]
	mip_dir = "491489187"


	logfile.write("WORK WITH TEXTURES" + "\n")
	logfile.flush()

	for ftype in array_tex:
		local_in_root = os.path.join(input_path, ftype)
		local_out_root = os.path.join(output_path, ftype)
		if (not os.path.exists(local_out_root)): os.makedirs(local_out_root)

		for root, dirs, files in os.walk(local_in_root):
			for name in files:
				try:
					if((sort_tex(os.path.join(root, name))) or (export_without_sort)):#name.startswith("CE_")):
						
						fullname = os.path.join(root, name)
						if fullname.endswith('.raw'):
							print(fullname)
							execut_str = '\"' + bms_binary_path + '\" -K -d '
							execut_str = execut_str + '\"' + script_path + '\" '
							execut_str = execut_str + '\"' + fullname + '\"  '	
							execut_str = execut_str + '\"' + local_out_root + '\"  '
							subprocess.call(execut_str)
							
							execut_str = '\"' + bms_binary_path + '\" -K -d '
							execut_str = execut_str + '\"' + script_path + '\" '
							execut_str = execut_str + '\"' + os.path.join(input_path, mip_dir , name[:-4] + "_TopMip_0.raw") + '\"  '	
							execut_str = execut_str + '\"' + local_out_root + '\"  '
							subprocess.call(execut_str)					
							
							
							
							
							loc_old_name1 = os.path.join(local_out_root,name, name[:-4], "1.dat")
							loc_old_name2 = os.path.join(local_out_root, (name[:-4] + "_TopMip_0.raw"), (name[:-4] + "_TopMip_0"), "1.dat")
							
							loc_new_name = os.path.join(local_out_root, name[:-4])+ "." + game +"tex"
							print(loc_old_name1)
							print(loc_old_name2)
							print(loc_new_name)
							
							#if(os.path.exists(loc_new_name)): os.remove(loc_new_name)

							if(os.path.exists(loc_old_name1)):
								if(replase_files):
									if(os.path.exists(loc_new_name)): os.remove(loc_new_name)
								if(not replase_files):
									while(os.path.exists(loc_new_name)): 
										loc_new_name = loc_new_name[: -len("." + game +"tex" ) ] + "_" + "." + game +"tex" 
										print(loc_new_name)
								#os.rename(loc_old_name, loc_new_name)
								os.rename(loc_old_name1, loc_new_name)
							else:
								logfile.write("ERROR_2:: not exists " + loc_old_name1 + "\n")
								logfile.flush()
								print("ERROR:: not exists " + loc_old_name1)
								
							if(not os.path.exists(loc_new_name)): 
								print("ERROR:: not exists " + loc_new_name)
								logfile.write("ERROR_3:: not exists " + loc_new_name + "\n")
								logfile.flush()
							elif(not os.path.exists(loc_old_name2)): 
								print("ERROR:: not exists " + loc_old_name2)
								logfile.write("WARNING_4:: not exists " + loc_old_name2 + "\n")
								logfile.flush()
							else:
								with open(loc_new_name, "ab") as myfile, open(loc_old_name2, "rb") as file2:
									myfile.write(file2.read())
									
							if(os.path.exists(os.path.join(local_out_root,name))): shutil.rmtree(os.path.join(local_out_root,name))
							if(os.path.exists(os.path.join(local_out_root,(name[:-4] + "_TopMip_0.raw")))): shutil.rmtree(os.path.join(local_out_root,(name[:-4] + "_TopMip_0.raw")))
				except Exception:
					logfile.write("ERROR_5:: except error " + root + " " +name + "\n")
					
print("finall")

logfile.write("script: complete" + str(now) + "\n\n\n\n")
logfile.flush()