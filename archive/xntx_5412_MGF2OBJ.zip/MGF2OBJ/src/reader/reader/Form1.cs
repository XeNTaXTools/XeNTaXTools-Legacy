﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace reader
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            NumberFormatInfo nfi = new NumberFormatInfo();
            nfi.NumberDecimalSeparator = ".";
            UInt32 oidx = 1480870223; //face indexes block
            UInt32 ovtx = 1481922127; //vertices block
            UInt32 omdl = 1279544655; //parts names

            openFileDialog1.ShowDialog();
            Stream input = File.Open(openFileDialog1.FileName, FileMode.Open);
            BinaryReader r = new BinaryReader(input);
            var guid = Guid.NewGuid();
            var baseDir = Path.GetDirectoryName(openFileDialog1.FileName);
            var inputFilename = Path.GetFileNameWithoutExtension(openFileDialog1.FileName);
            System.IO.StreamWriter fFile = new StreamWriter(baseDir + "/faces" + guid.ToString());
            System.IO.StreamWriter vFile = new StreamWriter(baseDir + "/vertices" + guid.ToString());
            System.IO.StreamWriter uvFile = new StreamWriter(baseDir + "/uv" + guid.ToString());
            System.IO.StreamWriter mFile = new StreamWriter(baseDir + "/" + inputFilename + ".mtl");
            fFile.WriteLine("mtllib " + inputFilename + ".mtl");
            int omdlCnt = 0;
            int[] omdls = new int[9999];
            int i;
            UInt32 tmp;

            input.Seek(60, SeekOrigin.Begin);
            int hashesStart = r.ReadInt32();
            int hashesCount = r.ReadInt32();
            input.Seek(hashesStart, SeekOrigin.Begin);
            Dictionary<int, int> hashes = new Dictionary<int, int>();
            for (int h = 0; h < hashesCount; h++)
            {
                hashes.Add(r.ReadInt32(), h);
            }

            for (i = 0; i < input.Length - 16; i++)
            {
                input.Seek(i, SeekOrigin.Begin);
                tmp = r.ReadUInt32();
                if (tmp == omdl)
                {
                    omdls[omdlCnt] = i + 32;
                    omdlCnt++;
                }
            }
            int diff = 0;
            for (int o = 0; o < omdlCnt; o++)
            {
                int oidxSize = 0;
                int ovtxSize = 0;
                int vBlockSize = 0;
                int oidxPos = 0, ovtxPos1 = 0, ovtxPos = 0, omdlPos = omdls[o];
                for (i = omdls[o]; i < input.Length - 16; i++)
                {
                    input.Seek(i, SeekOrigin.Begin);
                    tmp = r.ReadUInt32();
                    if (tmp == oidx)
                    {
                        oidxPos = i;
                        oidxSize = r.ReadInt32() / 6;
                        if (ovtxPos > 0 && omdlPos > 0)
                            break;
                    }
                    else if (tmp == ovtx)
                    {
                        ovtxPos = i + 32;
                        ovtxPos1 = i + 32;

                        if (oidxPos > 0 && omdlPos > 0)
                            break;
                    }
                }
                input.Seek(omdlPos, SeekOrigin.Begin);
                r.ReadBytes(24);
                int partsCnt = r.ReadInt32();
                r.ReadInt32();
                int matcount = r.ReadInt32();
                int matStart = r.ReadInt32() + omdlPos - 32;
                r.ReadBytes(72);
                vBlockSize = r.ReadInt32();
                long pos1 = input.Position;
                input.Seek(ovtxPos + 4 - 32, SeekOrigin.Begin);
                ovtxSize = r.ReadInt32() / vBlockSize;
                input.Seek(pos1, SeekOrigin.Begin);

                string[] names = new string[partsCnt];
                int[] vCount = new int[partsCnt + 1];
                int[] fCount = new int[partsCnt + 1];
                int[] fOffset = new int[partsCnt + 1];
                int[] matIndex = new int[partsCnt + 1];
                string[] matnames = new string[partsCnt + 1];

                for (int pn = 0; pn < partsCnt; pn++)
                {
                    r.ReadBytes(116);
                    names[pn] = System.Text.Encoding.Default.GetString(r.ReadBytes(64)).Trim('\0');
                    r.ReadBytes(36);
                }
                r.ReadBytes(16);
                r.ReadBytes(4);
                int test = r.ReadInt32();
                input.Seek(-8, SeekOrigin.Current);

                if (test != 0)
                {
                    input.Seek(8, SeekOrigin.Current);
                }
                for (int pn = 0; pn <= partsCnt; pn++)
                {
                    fCount[pn] = r.ReadInt32() / 3;
                    fOffset[pn] = r.ReadInt32();
                    input.Seek(-40, SeekOrigin.Current);
                    matIndex[pn] = r.ReadInt32();
                    input.Seek(36, SeekOrigin.Current);
                    r.ReadBytes(104);
                }
                for (int mc = 0; mc < matcount; mc++)
                {

                    input.Seek(matStart + mc * 0x4B0 + 0x430, SeekOrigin.Begin);
                    matnames[mc] = System.Text.Encoding.Default.GetString(r.ReadBytes(64));
                    input.Seek(matStart + mc * 0x4B0, SeekOrigin.Begin);
                    r.ReadBytes(8);
                    r.ReadBytes(8);
                    mFile.WriteLine("newmtl " + (matnames[mc]).Trim('\0') + o.ToString());
                    mFile.WriteLine("kd 1.0 1.0 1.0");
                    int mathash;
                    for (int b = 0; b < 1; b++)
                    {
                        r.ReadBytes(8);
                        mathash = r.ReadInt32();
                        if (hashes.ContainsKey(mathash))
                        {
                            mFile.WriteLine("map_Kd " + hashes[mathash] + "_0.png");
                        }
                    }


                }

                int max = -1;
                input.Seek(oidxPos + 5 * 4, SeekOrigin.Begin);
                UInt32 chunkSize = r.ReadUInt32();
                input.Seek(8, SeekOrigin.Current);
                int facesRead = 0;
                int vertRead = 0;
                for (int pc = 0; pc < partsCnt; pc++)
                {
                    fFile.WriteLine("g " + names[pc]);
                    fFile.Write("usemtl ");
                    fFile.Write(matnames[matIndex[pc]].Trim('\0') + o.ToString());
                    fFile.WriteLine("");
                    max = -1;
                    input.Seek(oidxPos + 32, SeekOrigin.Begin);
                    input.Seek(fOffset[pc], SeekOrigin.Current);

                    for (int f = 0; f < fCount[pc]; f++)
                    {
                        facesRead++;
                        UInt16 v1 = (UInt16)(r.ReadUInt16() + 1);
                        UInt16 v2 = (UInt16)(r.ReadUInt16() + 1);
                        UInt16 v3 = (UInt16)(r.ReadUInt16() + 1);
                        if (v1 > max) max = v1;
                        if (v2 > max) max = v2;
                        if (v3 > max) max = v3;
                        fFile.WriteLine("f " + (v1 + diff).ToString(nfi) + "/" + (v1 + diff).ToString(nfi) + " " + (v2 + diff).ToString(nfi) + "/" + (v2 + diff).ToString(nfi) + " " + (v3 + diff).ToString(nfi) + "/" + (v3 + diff).ToString(nfi));
                    }

                    diff += max;
                    long pos = input.Position;
                    input.Seek(ovtxPos, SeekOrigin.Begin);

                    for (int p = 0; p < max; p++)
                    {
                        vertRead++;
                        float f1 = (float)(r.ReadSingle());
                        float f2 = (float)(r.ReadSingle());
                        float f3 = (float)(r.ReadSingle());
                        r.ReadBytes(16);
                        byte[] _uvs = r.ReadBytes(4);
                        Half uv1 = Half.ToHalf(_uvs, 0);
                        Half uv2 = Half.ToHalf(_uvs, 2);
                        if (vBlockSize == 56)
                        {
                            r.ReadBytes(24);
                        }
                        else
                        {
                            r.ReadBytes(12);
                        }
                        uvFile.WriteLine("vt " + uv1.ToString(nfi) + " " + uv2.ToString(nfi));
                        vFile.WriteLine("v " + f1.ToString(nfi) + " " + f2.ToString(nfi) + " " + f3.ToString(nfi));
                    }
                    ovtxPos += vBlockSize * max;
                    input.Seek(pos, SeekOrigin.Begin);
                }
                if (facesRead < (oidxSize - 2))
                {
                    
                    input.Seek(oidxPos + 32, SeekOrigin.Begin);
                    input.Seek(fOffset[partsCnt], SeekOrigin.Current);
                    fFile.WriteLine("g ____Group____" + o.ToString());
                    for (int f = 0; f < fCount[partsCnt]; f++)
                    {
                        facesRead++;
                        UInt16 v1 = (UInt16)(r.ReadUInt16() + 1);
                        UInt16 v2 = (UInt16)(r.ReadUInt16() + 1);
                        UInt16 v3 = (UInt16)(r.ReadUInt16() + 1);
                        if (v1 > max) max = v1;
                        if (v2 > max) max = v2;
                        if (v3 > max) max = v3;
                        fFile.WriteLine("f " + (v1 ).ToString(nfi) + "/" + (v1).ToString(nfi) + " " + (v2).ToString(nfi) + "/" + (v2).ToString(nfi) + " " + (v3 ).ToString(nfi) + "/" + (v3).ToString(nfi));
                    }
                }
                if (vertRead < ovtxSize)
                {
                    ovtxPos = ovtxPos1 + vertRead * vBlockSize;
                    input.Seek(ovtxPos, SeekOrigin.Begin);

                    for (int p = 0; p < ovtxSize - vertRead; p++)
                    {
                        float f1 = (float)(r.ReadSingle());
                        float f2 = (float)(r.ReadSingle());
                        float f3 = (float)(r.ReadSingle());
                        r.ReadBytes(16);
                        byte[] _uvs = r.ReadBytes(4);
                        Half uv1 = Half.ToHalf(_uvs, 0);
                        Half uv2 = Half.ToHalf(_uvs, 2);
                        if (vBlockSize == 56)
                        {
                            r.ReadBytes(24);
                        }
                        else
                        {
                            r.ReadBytes(12);
                        }
                        uvFile.WriteLine("vt " + uv1.ToString(nfi) + " " + uv2.ToString(nfi));
                        vFile.WriteLine("v " + f1.ToString(nfi) + " " + f2.ToString(nfi) + " " + f3.ToString(nfi));
                    }

                }

            }

            fFile.Close();
            vFile.Close();
            uvFile.Close();
            mFile.Close();
            StreamReader vs = new StreamReader(baseDir + "/vertices" + guid.ToString());
            StreamReader uvs = new StreamReader(baseDir + "/uv" + guid.ToString());
            StreamReader fs = new StreamReader(baseDir + "/faces" + guid.ToString());
            StreamWriter combined = new StreamWriter(baseDir + "/" + inputFilename + ".obj", false);
            vs.BaseStream.CopyTo(combined.BaseStream);
            uvs.BaseStream.CopyTo(combined.BaseStream);
            fs.BaseStream.CopyTo(combined.BaseStream);
            vs.Close();
            fs.Close();
            uvs.Close();
            combined.Close();
            File.Delete(baseDir + "/vertices" + guid.ToString());
            File.Delete(baseDir + "/uv" + guid.ToString());
            File.Delete(baseDir + "/faces" + guid.ToString());
            Application.Exit();
        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }
    }
}