class TQUAT __thiscall tagPackedQUAT::operator TQUAT( void * this )
{
    short v1;
    short v2;
    void * eax; // eax
    void * esp; // esp
    unsigned int v3; // zmm0
    unsigned int v4; // zmm1
    unsigned int v5; // zmm2
    int v8; // zmm1
    unsigned int v10; // zmm1
    int v6; // zmm3
    unsigned int v9; // zmm0
    int v7; // zmm3

    __asm.cvtsi2ss( *this );
    v1 = *((unsigned char *)this + 2);
    v2 = *((unsigned char *)this + 4);
    v3 = __asm.mulss( 0 );
    __asm.cvtsi2ss( v1 );
    v4 = __asm.mulss( 0 );
    __asm.cvtsi2ss( v2 );
    v5 = __asm.mulss( 0 );
    v6 = __asm.mulss( v3 );
    __asm.subss( v6 );
    v7 = __asm.mulss( v4 );
    v8 = __asm.mulss( v5 );
    __asm.subss( v7 );
    v9 = __asm.subss( v8 );
    v10 = __asm.xorps( v8 );
    __asm.comiss( v9, v10 );
    if( esp > 16 ) {
        __asm.fld( v9 );
        __asm.fsqrt();
        __asm.fstp( v9 );
    } else {
        v9 = v10;
    }
    *eax = v3;
    *((unsigned char *)eax + 4) = v4;
    *((unsigned char *)eax + 8) = v5;
    *((unsigned char *)eax + 12) = v9;
    return (unsigned char *)esp + 4 + 4;
}
