unsigned int __thiscall TPacked3DVECTOR::operator T3DVECTOR const( void * this )
{
    int v1;
    int v3;
    int v6;
    unsigned int v7;
    unsigned int stack_0x4; // [esp+4]
    unsigned int stack_0x8; // [esp+8]
    int ebx; // ebx
    int edi; // edi
    unsigned int v9; // zmm1
    unsigned int v10; // zmm1
    int v2; // edx
    unsigned int v11; // zmm1
    int v4; // esi
    int v8; // esi
    int v5; // cc_dst

    v1 = (unsigned short)(edi & 0xFFFF0000 | *(stack_0x4 + 4)) >> 10 & 0x1F;
    if( (v1 > 10 | v1 == 10) != 1 ) {
        v2 = ((unsigned short)(edi & 0xFFFF0000 | *(stack_0x4 + 4)) & 0x3FF) >> (10 - v1 & 0x1F);
    } else {
        v2 = ((unsigned short)(edi & 0xFFFF0000 | *(stack_0x4 + 4)) & 0x3FF) << (-(10 - v1) & 0x1F);
    }
    if( v1 != 0 ) {
        v2 |= 1 << ((unsigned short)(edi & 0xFFFF0000 | *(stack_0x4 + 4)) >> 10 & 0x1F);
    }
    if( ((edi & 0xFFFF0000 | *(stack_0x4 + 4)) & 0x8000) != 0 ) {
        v2 = -v2;
    }
    v3 = (unsigned short)(ebx & 0xFFFF0000 | *(stack_0x4 + 2)) >> 10 & 0x1F;
    if( (v3 > 10 | v3 == 10) != 1 ) {
        v4 = ((unsigned short)(ebx & 0xFFFF0000 | *(stack_0x4 + 2)) & 0x3FF) >> (10 - v3 & 0x1F);
    } else {
        v4 = ((unsigned short)(ebx & 0xFFFF0000 | *(stack_0x4 + 2)) & 0x3FF) << (-(10 - v3) & 0x1F);
    }
    if( v3 != 0 ) {
        v4 |= 1 << ((unsigned short)(ebx & 0xFFFF0000 | *(stack_0x4 + 2)) >> 10 & 0x1F);
    }
    v5 = (unsigned short)(ebx & 0xFFFF0000 | *(stack_0x4 + 2)) >> 8 & (unsigned short)(ebx & 0xFFFF0000 | *(stack_0x4 + 2)) >> 8;
    if( (char)v5 < 0 ) {
        v4 = -v4;
    }
    v6 = (unsigned short)(ebx & 0xFFFF0000 | *(stack_0x4 + 2)) & 0xFFFF0000 | *stack_0x4;
    v7 = (v6 >> 10 & 0x1F) > 10 | (v6 >> 10 & 0x1F) == 10;
    if( v7 != 1 ) {
        v8 = (v6 & 0x3FF) >> (10 - (v6 >> 10 & 0x1F) & 0x1F);
    } else {
        v8 = (v6 & 0x3FF) << (-(10 - (v6 >> 10 & 0x1F)) & 0x1F);
    }
    if( (v6 >> 10 & 0x1F) != 0 ) {
        v8 |= 1 << (v6 >> 10 & 0x1F);
    }
    if( (char)(v6 >> 8 & v6 >> 8) < 0 ) {
        v8 = -v8;
    }
    __asm.cvtsi2ss( v8 );
    v9 = __asm.mulss( 0 );
    *stack_0x8 = v9;
    __asm.cvtsi2ss( v4 );
    v10 = __asm.mulss( 0 );
    *(stack_0x8 + 4) = v10;
    __asm.cvtsi2ss( v2 );
    v11 = __asm.mulss( 0 );
    *(stack_0x8 + 8) = v11;
    return stack_0x8;
}
