Version 1.0.2014.05.14
 * Added support for [PS3] Sengoku Musou 4

Version 1.0.2014.05.08
 * Added support for [PS3] Soul Calibur: Lost Swords

Version 1.0.2014.04.21
 * Updated TTT2 and TR (fixed weight bug).
 * Updated smcimport.py (fixed weight bug).

Version 1.0.2014.04.11
 * Fixed a bug involving weights for [PS3] Kagero: Darkside Princess
 * Please let me know if the update screws up other Dynasty Warrior engine games.

Version 1.0.2014.04.07
 * Added support for [PS3] Trinity: Souls of Zill O'll

Version 1.0.2014.04.06
 * Initial private release.
 * Do not release to public.
 * Program is still in beta and may be buggy.
 * Added support for [PS3] Kagero: Darkside Princess



