import newGameLib
from newGameLib import *
import Blender	

def getnext(list,node,chunk):
	for child in node.children:
		if child.chunk==chunk:
			list.append(child)
		else:
			getnext(list,child,chunk)

def get(node,chunk):
	list=[]
	for child in node.children:
		if child.chunk==chunk:
			list.append(child)
		else:
			getnext(list,child,chunk)
	return list		
	

class Node:
	def __init__(self):
		self.chunk=None
		self.offset=None
		self.children=[]
		self.nodeSize=None
		self.info=None

def nextnode(parent,g,n):
	n+=4
	sum=0
	while(True):
		node=Node()
		parent.children.append(node)
		node.chunk=g.word(8)
		node.info=g.i(5)
		print ' '*n,node.chunk,node.info,g.tell()
		sum+=28	
		t=g.tell()
		node.offset=t
		g.seek(t+node.info[2])
		t=g.tell()
		if node.chunk=='FOLDMESH':nextnode(node,g,n)
		if node.chunk=='FOLDMGRP':nextnode(node,g,n)
		if node.chunk=='FOLDMRGM':nextnode(node,g,n)
		if node.chunk=='FOLDBIMP':nextnode(node,g,n)
		if node.chunk=='FOLDMTRL':nextnode(node,g,n)
		if node.chunk=='FOLDTXTR':nextnode(node,g,n)
		if node.chunk=='FOLDDXTC':nextnode(node,g,n)
		if node.chunk=='FOLDSKEL':nextnode(node,g,n)
		if node.chunk=='FOLDANIM':nextnode(node,g,n)
		if node.chunk=='FOLDCMPS':nextnode(node,g,n)
		g.seek(t+node.info[1])
		sum+=node.info[1]
		sum+=node.info[2]
		if sum==parent.info[1]:break

		
		
def rgtParser(filename,g):
	g.word(12)
	g.i(6)
	g.word(8)
	g.i(5)
	g.word(13)
	g.word(g.i(1)[0])
	g.i(1)
	g.word(g.i(1)[0])
	g.word(g.i(1)[0])
	count=g.i(1)[0]
	for m in range(count):
		g.word(g.i(1)[0])
		g.i(2)
	n=0
	root=Node()
	root.chunk=g.word(8)	
	#print root.chunk
	if root.chunk=='FOLDTSET':
		root.info=g.i(5)
		t=g.tell()
		root.offset=t
		g.seek(t+root.info[2])
		nextnode(root,g,n)
		
	FOLDTXTRList = get(root,'FOLDTXTR')	
	for FOLDTXTR in FOLDTXTRList:
		g.seek(FOLDTXTR.offset)
		#print g.find('\x00')
		FOLDDXTCList=get(FOLDTXTR,'FOLDDXTC')
		img=imageLib.Image()
		img.data=''
		zlibList=[]
		for FOLDDXTC in FOLDDXTCList:
		
			DATATFMTList=get(FOLDDXTC,'DATATFMT')
			for DATATFMT in DATATFMTList:
				g.seek(DATATFMT.offset)
				A=g.i(6)
				print A
				img.szer=A[0]
				img.wys=A[1]
				if A[4]==22:
					img.name=filename.lower().replace('.rgt','.dds')
					img.format='DXT1'
				if A[4]==15:
					img.name=filename.lower().replace('.rgt','.dds')
					img.format='DXT3'
				if A[4]==13:
					img.name=filename.lower().replace('.rgt','.dds')
					img.format='DXT1'
				
			DATATMANList=get(FOLDDXTC,'DATATMAN')
			for DATATMAN in DATATMANList:
				g.seek(DATATMAN.offset)
				count=g.i(1)[0]
				sum=0
				for m in range(count):
					B=g.i(2)
					sum+=B[1]
					zlibList.append(B)
				#print 'sum:',sum	
				
			DATATDATList=get(FOLDDXTC,'DATATDAT')
			for DATATDAT in DATATDATList:
				g.seek(DATATDAT.offset)				
				for item in zlibList:
					data=g.read(item[1])
					if item[0]==item[1]:
						img.data=data
					else:
						img.data=zlib.decompress(data)
		img.draw()		
		
			
		
	
	
	
def byte2float(r,g,b,a):
	scale = 1.0/32.0
	x = b/255.0
	y = 1.0 - (g/255.0)
	z = r / 255.0
	w = a / 255.0
	
	w = 1.0 - w	
	x = x + (z * scale)
	y = y + (w * scale)
	return [x,1-y]

	
		

def rgmParser(filename,g):
	global artDir
	artDir=filename.split('art')[0]
	if os.path.exists(artDir)==False:
		artDir=g.dirname
	g.word(12)
	g.i(6)
	g.word(8)
	g.i(5)
	g.word(13)
	g.word(g.i(1)[0])
	g.i(1)
	g.word(g.i(1)[0])
	g.word(g.i(1)[0])
	g.i(1)
	n=0
	root=Node()
	root.chunk=g.word(8)	
	print root.chunk
	if root.chunk=='FOLDMODL':
		root.info=g.i(5)
		t=g.tell()
		root.offset=t
		g.seek(t+root.info[2])
		nextnode(root,g,n)
		
		
		
	FOLDSKELList = get(root,'FOLDSKEL')	
	for i,FOLDSKEL in enumerate(FOLDSKELList):
		DATABONEList = get(FOLDSKEL,'DATABONE')	
		skeleton=Skeleton()
		skeleton.NICE=True
		skeleton.BONESPACE=True
		skeleton.name='pose-'+str(i)
		for DATABONE in DATABONEList:
			g.seek(DATABONE.offset)
			bone=Bone()
			bone.name=g.find('\x00')[-25:]
			bone.parentID,unk=g.i(2)
			rotMatrix=Matrix3x3(g.f(9)).resize4x4()
			posMatrix=VectorMatrix(g.f(3))
			matrix=rotMatrix*posMatrix
			bone.matrix=matrix#.invert()
			g.f(2)
			skeleton.boneList.append(bone)
		skeleton.draw()	
			
		
		
		
	FOLDTSETList = get(root,'FOLDTSET')	
	for FOLDTSET in FOLDTSETList:
		g.seek(FOLDTSET.offset)
		name=g.find('\x00')+'.rgt'
		print ' '*n,name
		rgtPath=artDir+os.sep+name
		if os.path.exists(rgtPath)==True:
			file=open(rgtPath,'rb')
			p=BinaryReader(file)
			rgtParser(rgtPath,p)
			file.close()
	FOLDMTRLList = get(root,'FOLDMTRL')	
	matList={}
	for FOLDMTRL in FOLDMTRLList:
		mat=Mat()		
		g.seek(FOLDMTRL.offset)
		mat.name=g.find('\x00')
		matList[mat.name]=mat
		print 'material name:',mat.name
		DATAVARList = get(FOLDMTRL,'DATAVAR')	
		for DATAVAR in DATAVARList:
			g.seek(DATAVAR.offset)
			t=g.tell()	
			g.find('\x00')
			g.seek(t+DATAVAR.info[2])
			type=g.word(g.i(1)[0])
			g.i(1)
			name=g.word(g.i(1)[0])
			if type=='diffusetex':mat.diffuse=artDir+os.sep+name+'.dds'
			if type=='normalmap':mat.normal=artDir+os.sep+name+'.dds'
			if type=='speculartex':mat.specular=artDir+os.sep+name+'.dds'
			
			
		
		
	FOLDMRGMList = get(root,'FOLDMRGM')	
	for i,FOLDMRGM in enumerate(FOLDMRGMList):
		g.seek(FOLDMRGM.offset)
		model=g.find('\x00')
		DATADATAList=get(FOLDMRGM,'DATADATA')
		for DATADATA in DATADATAList:
			g.seek(DATADATA.offset)
			print g.tell()
			if DATADATA.info[3]==2:
				mesh=Mesh()
				g.B(1)
				a=g.i(1)[0]
				for m in range(a):
					b=g.i(1)[0]
					indiceList=g.H(b)
					g.f(3)
					g.B(1)
					name=g.word(g.i(1)[0])
					#print name
					mesh.indiceList.extend(indiceList)
				#g.debug=True
				count=g.i(1)[0]
				mesh.vertPosOff=None
				mesh.vertUVOff=None
				mesh.skinIndiceOff=None
				mesh.skinWeightOff=None
				off=0
				for m in range(count):	
					a,b,c=g.i(3)
					print a,b,c
					if a==8:mesh.vertUVOff=off
					if a==1:mesh.skinIndiceOff=off
					if a==2:mesh.skinWeightOff=off
					if c==4:off+=12
					if c==2:off+=4
				g.tell()
				a,stride=g.i(2)
				print a,stride
				g.debug=False
				for m in range(a):	
					t=g.tell()
					mesh.vertPosList.append(g.f(3))
					mesh.skinIDList.append([1])
					if mesh.skinIndiceOff is not None:
						g.seek(t+mesh.skinIndiceOff)
						mesh.skinIndiceList.append(g.B(4))
					if mesh.skinWeightOff is not None:
						g.seek(t+mesh.skinWeightOff)
						mesh.skinWeightList.append(g.B(4))
					if mesh.vertUVOff is not None:
						g.seek(t+mesh.vertUVOff)
						x,y,z,w=g.B(4)
						mesh.vertUVList.append(byte2float(x,y,z,w))
					g.seek(t+stride)
				mesh.TRIANGLE=True	
				skin=Skin()
				mesh.skinList.append(skin)
				g.i(1)
				mat=Mat()
				mat.TRIANGLE=True
				mat.name=g.word(g.i(1)[0])
				mat.diffuse=matList[mat.name].diffuse
				mat.normal=matList[mat.name].normal
				mat.specular=matList[mat.name].specular
				mesh.matList.append(mat)
				boneCount=g.i(1)[0]
				skeleton=Skeleton()
				skeleton.ARMATURESPACE=True
				skeleton.NICE=True
				skeleton.name='model-'+str(i)
				for m in range(boneCount):
					bone=Bone()
					rotMatrix=Matrix3x3(g.f(9)).resize4x4()
					posMatrix=VectorMatrix(g.f(3))
					matrix=rotMatrix*posMatrix
					bone.matrix=matrix#.invert()
					g.f(12)
					bone.name=g.word(g.i(1)[0])[-25:]
					skeleton.boneList.append(bone)
				skeleton.draw()	
				mesh.boneNameList=skeleton.boneNameList
				mesh.BINDSKELETON=skeleton.name
				mesh.draw()	
				print 'end:',g.tell()
				
		
	
	
	
	
	

def rgaParser(filename,g):
	global artDir
	artDir=filename.split('art')[0]
	if os.path.exists(artDir)==False:
		artDir=g.dirname
	g.word(12)
	g.i(6)
	g.word(8)
	g.i(5)
	g.word(13)
	g.word(g.i(1)[0])
	g.i(1)
	g.word(g.i(1)[0])
	g.word(g.i(1)[0])
	g.i(1)
	n=0
	root=Node()
	root.chunk=g.word(8)	
	print root.chunk
	if root.chunk=='FOLDMODL':
		root.info=g.i(5)
		t=g.tell()
		root.offset=t
		g.seek(t+root.info[2])
		nextnode(root,g,n)
	#g.debug=True	
	FOLDANIMList = get(root,'FOLDANIM')	
	for FOLDANIM in FOLDANIMList:
		g.seek(FOLDANIM.offset)
		g.logWrite('')
		name=g.find('\x00')+'.anim'
		print name
		path=g.dirname+os.sep+name
		dir=os.path.dirname(path)
		try:os.makedirs(dir)
		except:pass
		new=open(path,'wb')
		
		print ' '*n,name
		DATACHRCList = get(FOLDANIM,'DATACHRC')	
		for DATACHRC in DATACHRCList:		
			g.seek(DATACHRC.offset+DATACHRC.info[2])
			boneCount=g.i(1)[0]
			size=g.i(1)
			action=Action()
			for m in range(boneCount):
				bone=ActionBone()
				bone.name=g.word(g.i(1)[0]).split(':')[1][-25:]	
				bone.info=g.i(4)
				bone.float=g.f(1)[0]
				action.boneList.append(bone)
			start=g.tell()	
			for bone in action.boneList:
				new.write(bone.name)
				new.write('\x00')
				g.seek(start+bone.info[2])
				new.write(struct.pack('i',bone.info[0]))
				if bone.info[0]==3:
					new.write(struct.pack('i',bone.info[1]))
					for m in range(bone.info[1]):
						new.write(g.read(16))
				if bone.info[0]==4:
					new.write(struct.pack('i',bone.info[1]))
					for m in range(bone.info[1]):
						new.write(g.read(28))
				if bone.info[0]==5:
					new.write(g.read(16))
					g.f(4)
					new.write(g.read(12))
					g.B(4)
					g.B(bone.info[1]*4)
					g.f(bone.info[1])
		new.close()			
		
	

def animParser(filename,g):
	g.endian='<'
	action=Action()
	action.BONESPACE=True
	action.BONESORT=True
	action.skeleton='pose-0'
	while(True):
		bone=ActionBone()
		action.boneList.append(bone)
		bone.name=g.find('\x00')
		print bone.name
		type=g.i(1)[0]
		if type==3:
			count=g.i(1)[0]
			for m in range(count):
				bone.rotFrameList.append(1+m)
				bone.rotKeyList.append(QuatMatrix(g.f(4)).resize4x4())
		if type==4:
			count=g.i(1)[0]
			for m in range(count):
				bone.rotFrameList.append(1+m)
				bone.rotKeyList.append(QuatMatrix(g.f(4)).resize4x4())
				bone.posFrameList.append(1+m)
				bone.posKeyList.append(VectorMatrix(g.f(3)))
		if type==5:
			for m in range(1):
				bone.rotFrameList.append(1+m)
				bone.rotKeyList.append(QuatMatrix(g.f(4)).resize4x4())
				bone.posFrameList.append(1+m)
				bone.posKeyList.append(VectorMatrix(g.f(3)))
		if g.tell()>=g.fileSize():break	
	action.draw()
	action.setContext()		
	
def Parser():	
	filename=input.filename
	print
	print filename
	print
	ext=filename.split('.')[-1].lower()	
	
	if ext=='rgm':
		file=open(filename,'rb')
		g=BinaryReader(file)
		rgmParser(filename,g)
		file.close()
	
	if ext=='rga':
		file=open(filename,'rb')
		g=BinaryReader(file)
		rgaParser(filename,g)
		file.close()
	
	if ext=='rgt':
		file=open(filename,'rb')
		g=BinaryReader(file)
		rgtParser(filename,g)
		file.close()
	
	if ext=='anim':
		file=open(filename,'rb')
		g=BinaryReader(file)
		animParser(filename,g)
		file.close()
 
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
	
Blender.Window.FileSelector(openFile,'import','Company of The Heroes 2 files: *.rgm - model, rga,anim - animation, rgt - texture') 
	