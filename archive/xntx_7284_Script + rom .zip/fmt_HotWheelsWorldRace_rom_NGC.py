from inc_noesis import *
import noesis
#import rapi

def registerNoesisTypes():
	handle = noesis.register("Hot Wheels - World Race",".rom")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadModel(handle, noepyLoadModel)
	return 1
	
NOEPY_HEADER = "ROM"

def noepyCheckType(data):
   bs = NoeBitStream(data)
   if len(data) < 3:
      return 0
   if bs.readBytes(3).decode("ASCII") != NOEPY_HEADER:
      print("'rom' not found!")
      return 0
   return 1  

def noepyLoadModel(data, mdlList):
	ctx = rapi.rpgCreateContext()
	bs = NoeBitStream(data)
	bs.setEndian(NOE_BIGENDIAN)
	rapi.rpgSetOption(noesis.RPGOPT_BIGENDIAN, 1)

	for i in range(1):
	      addr=bs.tell()
	      fileBuff = bs.data[addr:bs.dataSize]
	      addr1= fileBuff.find(b'\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF')
	      addr += addr1
	      #print("addr: ",hex(addr))
	      bs.seek(addr)
	      bs.seek(0xC, NOESEEK_REL)# skip signature

	      FCont = bs.readUInt()
	      print("FCont: ", FCont)
	      print("hex FCont: ",hex(FCont))

	      bs.seek(0x8, NOESEEK_REL)
	      VCont = bs.readUInt()
	      print("VCont, ", VCont)
	      print("hex VCont: ",hex(VCont))

	      bs.seek(0x10, NOESEEK_REL)
	      FAddress= bs.tell()
	      print("FAddress HEX:", hex(FAddress))

	      FVFsize = int(56)
	      Jump = FCont*12
	      print("Jump HEX: ",hex(Jump))
	      print("Jump: ",Jump)

	      bs.seek(Jump, NOESEEK_REL)
	      VAddress= bs.tell()
	      print("VAddress HEX:", hex(VAddress))

	      bs.seek(VAddress, NOESEEK_ABS)
	      VBSize = VCont * FVFsize
	      VBuff = bs.readBytes(VBSize)
	      rapi.rpgBindPositionBufferOfs(VBuff, noesis.RPGEODATA_FLOAT, FVFsize, 0)
	      rapi.rpgBindUV1BufferOfs(VBuff, noesis.RPGEODATA_FLOAT, FVFsize, 24)
	      bs.seek(FAddress, NOESEEK_ABS)
	      FBuff = bs.readBytes(FCont*6)
	      rapi.rpgCommitTriangles(FBuff, noesis.RPGEODATA_UINT, FCont*3, noesis.RPGEO_TRIANGLE, 1)

	mdl = rapi.rpgConstructModel()
	mdlList.append(mdl)
	rapi.rpgClearBufferBinds()
	return 