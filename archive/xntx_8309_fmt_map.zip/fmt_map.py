#by Durik256
#orig script:
#https://github.com/Murugo/Misc-Game-Research/blob/1f8891d4bdd05ac0201121754d95a307ec455edf/PS2/Silent%20Hill%202%2B3/Blender/addons/io_sh2_sh3/import_map.py#L11
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("SH2 (PS2)", ".map")
    noesis.setHandlerTypeCheck(handle, CheckType)
    noesis.setHandlerLoadModel(handle, test)
    return 1

def CheckType(data):
    if data[:4] != b'wwww': 
        return 0
    return 1   
   
def test(data, mdlList):
    bs = NoeBitStream(data)
    ctx = rapi.rpgCreateContext()
    
    submesh = [[400, 378], [6656, 334], [12208, 530]]
    
    for ofs, vnum in submesh:
        bs.seek(ofs)
        rapi.rpgSetName('mesh%i'%ofs)
        vbuf = b''
        ibuf = b''
        vnbuf = b''
        uvbuf = b''
        vcolbuf =  b''
        reverse = False
        for i in range(vnum):
            vbuf += bs.readBytes(6)
            vn_vcol_x = bs.readShort()
            uv_flag = [bs.readShort(), bs.readShort()]
            vn_vcol = (vn_vcol_x, bs.readShort(), bs.readShort())
            uvbuf += NoeVec3([uv_flag[0] / 0x8000, 1.0 - uv_flag[1] / 0x8000, 0]).toBytes()
            vnbuf += NoeVec3([(v & ~0x3F) / -0x8000 for v in vn_vcol]).normalize().toBytes()
            vcolbuf += NoeVec3([(v & 0x3F) / 0x20 for v in vn_vcol]).toBytes()
            flag = uv_flag[0] & 0x1
            if not flag:
                if reverse:
                    ibuf += struct.pack('3H', i, i - 1, i - 2)
                else:
                    ibuf += struct.pack('3H', i - 2, i - 1, i)
            reverse = not reverse
       
        rapi.rpgBindPositionBuffer(vbuf, noesis.RPGEODATA_SHORT, 6)
        rapi.rpgBindNormalBuffer(vnbuf, noesis.RPGEODATA_FLOAT, 12)
        rapi.rpgBindUV1Buffer(uvbuf, noesis.RPGEODATA_FLOAT, 12)
        rapi.rpgBindColorBuffer(vcolbuf, noesis.RPGEODATA_FLOAT, 12, 3)
        rapi.rpgCommitTriangles(ibuf, noesis.RPGEODATA_USHORT, len(ibuf)//2, noesis.RPGEO_TRIANGLE)
    
    mdl = rapi.rpgConstructModel()
    mdlList.append(mdl)
    return 1