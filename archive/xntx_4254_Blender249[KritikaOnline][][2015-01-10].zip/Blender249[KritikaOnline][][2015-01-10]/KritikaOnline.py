import newGameLib
reload(newGameLib)
from newGameLib import *
import Blender


import os

def meshParser(filename,g):
	g.i(14)
	g.word(g.i(1)[0])
	w=g.i(13)
	print w
	mesh=Mesh()
	mesh.TRIANGLE=True
	mesh.indiceList=g.H(w[1])
	if w[3]==1:
		g.i(3)
		for i in range(w[0]):
			mesh.vertPosList.append(g.f(3))
	if w[4]==1:
		g.i(3)
		for i in range(w[0]):
			g.f(3)
			#mesh.vertNormList.append(g.f(3))
	if w[5]==1:
		g.i(3)
		for i in range(w[0]):
			g.f(4)
	if w[6]==1:
		g.i(3)
		for i in range(w[0]):
			mesh.vertUVList.append(g.f(2))
	if w[7]==1:
		g.i(3)
		for i in range(w[0]):
			g.f(2)
	if w[8]==1:
		g.i(3)	
		for i in range(w[0]):	
			g.i(3)
			u=g.i(1)[0]
			g.i(3)
			mesh.skinIndiceList.append(g.i(u))
			g.i(3)
			mesh.skinWeightList.append(g.f(u)	)
		g.i(3)	
		for i in range(w[9]):
			g.i(3)
			Matrix4x4(g.f(16))
	g.debug=True
	g.tell()
	skin=Skin()
	mesh.skinList.append(skin)
	mesh.BINDSKELETON='armature'
	if len(skeleton.boneNameList)>0:
		mesh.boneNameList=skeleton.boneNameList
	mesh.matList.append(mat)	
	mesh.draw()
	
def boneParser(filename,g):
	global skeleton
	g.debug=True
	u=g.i(8)
	t=g.tell()
	g.debug=False
	if u[0]==1040676:
		skeleton=Skeleton()
		#skeleton.BONESPACE=True
		skeleton.ARMATURESPACE=True
		#skeleton.SORT=True
		#skeleton.IK=True
		skeleton.NICE=True
		g.i(4)
		sum=12
		while(True):
			bone=Bone()
			len=g.i(1)[0]
			bone.name=g.word(len)
			print bone.name
			g.i(1)[0]
			sum+=len+8	
			#print sum
			skeleton.boneList.append(bone)
			if sum==u[7]:break
		
		
		
		g.seek(t+u[7])
		g.tell()
		w=g.i(5)
		print w
		sum=12
		while(True):
			bone=skeleton.boneList[(sum-12)/116]
			bone.matrix=Matrix()
			v=g.i(5)
			g.i(2)
			bone.matrix[0]=g.f(4)
			g.i(2)
			bone.matrix[1]=g.f(4)
			g.i(2)
			bone.matrix[2]=g.f(4)
			g.i(2)
			bone.matrix[3]=g.f(4)
			sum+=116
			if sum==w[1]:break
		w=g.i(5)
		sum=12
		while(True):
			bone=skeleton.boneList[(sum-12)/12]
			v=g.i(3)
			bone.parentID=v[2]
			sum+=12	
			if sum==w[1]:break
		g.tell()	
		skeleton.draw()		
			
	
	elif u[0]==1040678:
		g.seek(u[1])
		u=g.i(8)
		nameOffset=None
		transOffset=None
		parentOffset=None
		for i in range(u[7]):
			w=g.i(5)
			print w
			back=g.tell()
			g.seek(w[3])
			if w[4]==0:
				g.i(3)
				nameOffset=g.tell()
			if w[4]==1:
				g.i(3)
				transOffset=g.tell()
			if w[4]==2:
				g.i(3)
				parentOffset=g.tell()
			g.seek(back)
		u=g.i(5)
		skeleton=Skeleton()
		#skeleton.BONESPACE=True
		skeleton.ARMATURESPACE=True
		#skeleton.IK=True
		#skeleton.SORT=True
		skeleton.NICE=True
		if nameOffset is not None:
			g.seek(nameOffset)
			for i in range(u[4]):
				bone=Bone()
				bone.name=g.word(g.i(1)[0])
				skeleton.boneList.append(bone)
		if transOffset is not None:
			g.seek(transOffset)
			for i in range(u[4]):
				bone=skeleton.boneList[i]
				g.i(3)
				matrix=Matrix4x4(g.f(16))
				bone.matrix=matrix
				#print matrix
		if parentOffset is not None:
			g.seek(parentOffset)
			for i in range(u[4]):
				bone=skeleton.boneList[i]
				bone.parentID=g.i(1)[0]
		skeleton.draw()		
		g.tell()
	else:
		print 'bone file not supported'
	
def meshInfoParser(filename,g):
	global mat
	
	g.seek(2)
	data=g.read(g.fileSize()-2).replace('\x00','')
	new=open(filename+'.txt','wb')
	new.write(data)
	new.close()
	
	xml=Xml()
	xml.input=open(filename+'.txt','r')
	#xml.DRAWCONSOLE=True
	xml.parse()
	MeshInfoList=xml.find(xml.root,'MeshInfo')
	for MeshInfo in MeshInfoList:
		
		
		textureFilename=xml.get(MeshInfo,'Texture')
		chunks=textureFilename.chunks
		textureFile=chunks['value']
		texturePath=g.dirname+os.sep+textureFile
		print 'texturePath:',texturePath
		mat=Mat()
		mat.TRIANGLE=True
		mat.ZTRANS=True
		if os.path.exists(texturePath)==True:
			mat.diffuse=texturePath
		
		meshFilename=xml.get(MeshInfo,'Filename')
		chunks=meshFilename.chunks
		meshFile=chunks['value']
		
		meshPath=g.dirname+os.sep+meshFile
		file=open(meshPath,'rb')
		p=BinaryReader(file)
		meshParser(meshPath,p)
		file.close()
		
		
		
def meshInfoBParser(filename,g):
	global mat
	g.debug=True
	g.i(7)
	matName=g.word(g.i(1)[0])
	meshFile=g.word(g.i(1)[0])
	textureFile=g.word(g.i(1)[0])
	texturePath=None
	if len(textureFile)>0:
		texturePath=g.dirname+os.sep+textureFile
	print 'texturePath:',texturePath
	mat=Mat()
	mat.TRIANGLE=True
	mat.ZTRANS=True
	if os.path.exists(texturePath)==True:
		mat.diffuse=texturePath
	
	meshPath=g.dirname+os.sep+meshFile
	if os.path.exists(meshPath)==True:
		file=open(meshPath,'rb')
		p=BinaryReader(file)
		meshParser(meshPath,p)
		file.close()
	
	"""g.seek(2)
	data=g.read(g.fileSize()-2).replace('\x00','')
	new=open(filename+'.txt','wb')
	new.write(data)
	new.close()
	
	xml=Xml()
	xml.input=open(filename+'.txt','r')
	#xml.DRAWCONSOLE=True
	xml.parse()
	MeshInfoList=xml.find(xml.root,'MeshInfo')
	for MeshInfo in MeshInfoList:
		
		
		textureFilename=xml.get(MeshInfo,'Texture')
		chunks=textureFilename.chunks
		textureFile=chunks['value']
		texturePath=g.dirname+os.sep+textureFile
		print 'texturePath:',texturePath
		mat=Mat()
		mat.TRIANGLE=True
		mat.ZTRANS=True
		if os.path.exists(texturePath)==True:
			mat.diffuse=texturePath
		
		meshFilename=xml.get(MeshInfo,'Filename')
		chunks=meshFilename.chunks
		meshFile=chunks['value']
		
		meshPath=g.dirname+os.sep+meshFile
		file=open(meshPath,'rb')
		p=BinaryReader(file)
		meshParser(meshPath,p)
		file.close()"""
	g.tell()	
		
		
def modelinfobParser(filename,g):
	global skeleton,meshList
	skeleton=Skeleton()
	meshList=[]
	g.debug=True
	g.i(5)
	skeletonFile=g.word(g.i(1)[0])
		
	skeletonPath=g.dirname+os.sep+skeletonFile
	if os.path.exists(skeletonPath)==True:
		file=open(skeletonPath,'rb')
		p=BinaryReader(file)
		boneParser(skeletonPath,p)
		file.close()
	#for m in range(20):	
	while(True):
		chunk=g.B(4)
		if chunk==(60,57,66,0):
			pass
		elif chunk==(0,0,1,0):
			break
		else:
			g.seek(-4,1)
			name=g.word(g.i(1)[0]).lower()
			ext=name.split('.')[-1]
			if ext=='meshinfo':
		
				MeshInfoBFile=name+'B'
				MeshInfoBPath=g.dirname+os.sep+MeshInfoBFile
				if os.path.exists(MeshInfoBPath)==True:
					file=open(MeshInfoBPath,'rb')
					p=BinaryReader(file)
					meshInfoBParser(MeshInfoBPath,p)
					g.tell()
	
	
	
def modelParser(filename,g):
	global meshList
	meshList=[]
	
	
	g.seek(2)
	data=g.read(g.fileSize()-2).replace('\x00','')
	new=open(filename+'.txt','wb')
	new.write(data)
	new.close()
	
	xml=Xml()
	xml.input=open(filename+'.txt','r')
	xml.parse()
	ModelInfoList=xml.find(xml.root,'ModelInfo')
	for ModelInfo in ModelInfoList:
		SkeletonFilename=xml.get(ModelInfo,'SkeletonFilename')
		chunks=SkeletonFilename.chunks
		skeletonFile=chunks['value']
		
		skeletonPath=g.dirname+os.sep+skeletonFile
		file=open(skeletonPath,'rb')
		p=BinaryReader(file)
		boneParser(skeletonPath,p)
		file.close()
		
		DefaultMesh=xml.get(ModelInfo,'DefaultMesh')
		itemList=xml.find(DefaultMesh,'item')
		for item in itemList:
			chunks=item.chunks
			MeshInfoFile=chunks['value']
			
			MeshInfoPath=g.dirname+os.sep+MeshInfoFile
			file=open(MeshInfoPath,'rb')
			p=BinaryReader(file)
			meshInfoParser(MeshInfoPath,p)
			file.close()


def animParser(filename,g):
	u=g.i(8)
	g.seek(u[1])
	u=g.i(8)
	nameOffset=None
	transOffset=None
	parentOffset=None
	for i in range(u[7]):
		w=g.i(5)
		print w,g.tell()
		back=g.tell()
		g.seek(w[3])
		if w[0]==977004:
			boneCount=g.i(1)[0]
		elif w[0]==34231528:
			g.i(3)
			g.f(6)		
		elif w[0]==4831592:	
			g.f(3)	
		elif w[0]==56946838:
			g.f(3)		
		elif w[0]==45797634:
			frameCount=g.i(1)[0]
			
				
		elif w[0]==9774227:
			g.i(1)[0]	
		elif w[0]==52981676:
			g.i(1)[0]	
		elif w[0]==50623191:
			g.i(1)[0]	
		elif w[0]==7986641:
			rotBoneCount=g.i(1)[0]	
		elif w[0]==33191686:
			posBoneCount=g.i(1)[0]	
		elif w[0]==50985350:
			sizeBoneCount=g.i(1)[0]	
		elif w[0]==61737251:
			g.i(1)[0]	
		elif w[0]==22942296:
			g.i(1)[0]	
		elif w[0]==20275060:
			boneCount=g.i(1)[0]	
		elif w[0]==12444261:
			g.i(1)[0]	
		elif w[0]==8448793:
			g.i(1)[0]	
		elif w[0]==16241451:
			g.i(3)
			g.logWrite('bone names:')
			#for m in range(boneCount):
			#	g.word(g.i(1)[0])
		elif w[0]==57217084:
			g.i(3)	
		elif w[0]==46964676:
			g.i(8)	
		elif w[0]==18854571:
			size=g.i(1)[0]
			quatKeyCount=size/16
			g.logWrite('quat keys:'+str(quatKeyCount))
			#for j in range(quatKeyCount):
			#	g.f(4)	
		elif w[0]==36183766:
			size=g.i(1)[0]
			posKeyCount=size/12
			g.logWrite('pos keys:'+str(posKeyCount))
			#for j in range(posKeyCount):
			#	g.logWrite(j)
			#	g.f(3)
		elif w[0]==18177110:
			g.i(1)[0]	
		elif w[0]==27595076:
			size=g.i(1)[0]
			sizeKeyCount=size/12
			g.logWrite('bone size keys:'+str(sizeKeyCount))
			#for j in range(sizeKeyCount):
			#	g.logWrite(j)
			#	g.f(3)	
		elif w[0]==10265881:
			size=g.i(1)[0]
			sizeKeyCount=size/16
			g.logWrite('bone size keys:'+str(sizeKeyCount))
			#for j in range(sizeKeyCount):
			#	g.logWrite(j)
			#	g.f(4)
		elif w[0]==25444520:
			size=g.i(1)[0]
			sizeKeyCount=size/12
			g.logWrite('bone size keys:'+str(sizeKeyCount))
			#for j in range(sizeKeyCount):
			#	g.logWrite(j)
			#	g.f(3)
		elif w[0]==30362205:
			size=g.i(1)[0]
			count=size/4
			g.logWrite('count:'+str(count))
			posKey=0
			rotKey=0
			Key=0
			for m in range(count):
				a,b,c,d=g.B(4)
				posKey+=b
				rotKey+=c
				Key+=d
				print a,b/4,c/4,d/4
			g.logWrite([posKey,rotKey,Key])	
			
		else:
			print 'WARNING:unknow w0:',w[0]#,g.i(10)
			
		
		
		g.seek(back)
	#g.seek(152834)
	#g.i(17)
	#for m in range(154):
	#	g.i(1)
	
		
	g.tell()	
	
	
def Parser():	
	filename=input.filename
	print
	print filename
	print
	imageList=input.imageList
	ext=filename.split('.')[-1].lower()	
	global skeleton
	skeleton=Skeleton()
	
	
	if ext=='anim':
		file=open(filename,'rb')
		g=BinaryReader(file)
		g.logOpen()
		animParser(filename,g)
		g.logClose()
		file.close()
	
	if ext=='bone':
		file=open(filename,'rb')
		g=BinaryReader(file)
		boneParser(filename,g)
		file.close()
	
	if ext=='modelinfo':
		file=open(filename,'rb')
		g=BinaryReader(file)		
		modelParser(filename,g)
		file.close()
	
	if ext=='modelinfob':
		file=open(filename,'rb')
		g=BinaryReader(file)		
		modelinfobParser(filename,g)
		file.close()
	
	if ext=='meshinfob':
		file=open(filename,'rb')
		g=BinaryReader(file)		
		meshInfoBParser(filename,g)
		file.close()
			
		
	if ext=='mesh':
		sys=Sys(filename)
		bonePath=sys.dir+os.sep+sys.base.split('_')[0]+'.bone'
		if os.path.exists(bonePath)==True:
			print bonePath
			file=open(bonePath,'rb')
			g=BinaryReader(file)
			boneParser(bonePath,g)
			file.close()
		
		file=open(filename,'rb')
		g=BinaryReader(file)
		meshParser(filename,g)
		file.close()
 
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
	
Blender.Window.FileSelector(openFile,'import','Kritika Online files - *.ModelInfoB, *.MeshInfoB') 