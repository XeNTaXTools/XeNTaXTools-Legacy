﻿Public Class Form1
    Private Structure FileInSBF
        Friend Name As String
        Friend Offset As Int32
        Friend Size As Int32
        Friend Type As UInt64
    End Structure

    Private SBFFiles() As FileInSBF
    Private Game As ULong
    Private SDevice As New DirectSound.Device
    Private SFormat As DirectSound.WaveFormat
    Private SBuffer As DirectSound.Buffer
    Private SBufferDesc As DirectSound.BufferDescription
    Private SSecBuffer As DirectSound.SecondaryBuffer
    Private PlaybackSoundNum As Integer
    Private CurrentSound() As Byte

    Private Sub ButtonOpen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonOpen.Click
        OpenSBFDialog.ShowDialog()
    End Sub

    Private Sub ButtonSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonSave.Click
        'If ListViewWAV.Items.Count = 0 Then
        '    MessageBox.Show("WAV output list has no music files", "Nothing to save")
        '    Exit Sub
        'End If
        'SaveWAVDialog.ShowDialog()
        If ListViewSBF.SelectedIndices.Count = 0 Then
            Exit Sub
        End If
        StopSound()
        Dim FB As New IO.BinaryReader(New IO.FileStream(OpenSBFDialog.FileName, IO.FileMode.Open))
        For Each i As Integer In ListViewSBF.SelectedIndices
            Dim curfile As FileInSBF = SBFFiles(ListViewSBF.SelectedIndices(i))
            FB.BaseStream.Position = curfile.Offset
            Dim FW As New IO.BinaryWriter(IO.File.Create(curfile.Name))
            FW.Write(FB.ReadBytes(curfile.Size))
            FW.Flush()
            FW.Close()
        Next
        FB.Close()
    End Sub

    Private Sub OpenSBFDialog_FileOk(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles OpenSBFDialog.FileOk
        StopSound()
        Dim FB As New IO.BinaryReader(New IO.FileStream(OpenSBFDialog.FileName, IO.FileMode.Open))
        Dim Sig1 As ULong = FB.ReadUInt64()
        Game = FB.ReadUInt64()
        Dim Sig2 As UInteger = FB.ReadUInt32()
        Dim GameName As String
        If (Sig1 <> 1100321538643) Or (Sig2 <> 24) Then
            MessageBox.Show("Invalid signature.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If
        If Game = 1 Then
            'Select Case Game
            'Case 1
            GameName = "DFLW"
        Else
            'Case 17
            '    GameName = "TTF"
            'Case Else
            MessageBox.Show("Unsupported game.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
            'End Select
        End If
        LabelFileName.Text = IO.Path.GetFileName(OpenSBFDialog.FileName) & " (" & GameName & ")"
        ListViewSBF.Items.Clear()
        ListViewWAV.Items.Clear()
        Dim FileNum As UInteger = FB.ReadUInt32()
        ReDim SBFFiles(Convert.ToInt32(FileNum))
        Dim i As Integer = 0
        While i < FileNum
            SBFFiles(i) = New FileInSBF()
            With SBFFiles(i)
                .Name = CStr(FB.ReadChars(16)).Split(Convert.ToChar(0))(0)
                .Offset = FB.ReadInt32()
                .Size = FB.ReadInt32()
                .Type = FB.ReadUInt64()
                ListViewSBF.Items.Add(New ListViewItem(New String(2) {CStr(i), .Name, Convert.ToString(Math.Floor(.Size / 44100))}))
            End With
            i += 1
        End While
        FB.BaseStream.Close()
    End Sub

    Private Sub ButtonLeft_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonLeft.Click
        For Each Item As ListViewItem In ListViewWAV.SelectedItems
            Item.Remove()
        Next
    End Sub

    Private Sub ButtonRight_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonRight.Click
        For Each Item As ListViewItem In ListViewSBF.SelectedItems
            ListViewWAV.Items.Add(CType(Item.Clone(), ListViewItem))
        Next
    End Sub

    Private Function ConvertSound(ByVal id As Integer) As Byte()
        Dim ClearSound(Convert.ToInt32(SBFFiles(id).Size / 2) + 9000000) As Byte
        Dim FB As New IO.BinaryReader(New IO.FileStream(OpenSBFDialog.FileName, IO.FileMode.Open))
        FB.BaseStream.Position = SBFFiles(id).Offset
        Dim blockcnt As Double = Math.Ceiling(SBFFiles(id).Size / 512)
        Dim i As Integer = 0
        While i < blockcnt
            If i Mod 2 = 0 Then
                'If i = blockcnt Then
                '    FB.ReadBytes(SBFFiles(id).Size Mod 1024).CopyTo(ClearSound, i * 1024)
                'Else
                FB.ReadBytes(512).CopyTo(ClearSound, Convert.ToInt32(i / 2 * 512))
                'End If
            Else
                FB.BaseStream.Position += 512
            End If
            i += 1
        End While
        FB.BaseStream.Close()
        Return ClearSound
    End Function

    Private Sub ButtonPlay_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonPlay.Click
        If ListViewSBF.SelectedIndices.Count = 0 Then
            Exit Sub
        End If
        StopSound()
        Dim FB As New IO.BinaryReader(New IO.FileStream(OpenSBFDialog.FileName, IO.FileMode.Open))
        With SBFFiles(ListViewSBF.SelectedIndices(0))
            FB.BaseStream.Position = .Offset
            CurrentSound = FB.ReadBytes(.Size)
        End With
        'CurrentSound = ConvertSound(ListViewSBF.SelectedIndices(0))
        SBufferDesc = New DirectSound.BufferDescription(SFormat)
        With SBufferDesc
            .BufferBytes = CurrentSound.Length
            .Flags = DirectSound.BufferDescriptionFlags.StaticBuffer
        End With
        SSecBuffer = New DirectSound.SecondaryBuffer(SBufferDesc, SDevice)
        SSecBuffer.Write(0, CurrentSound, DirectSound.LockFlag.EntireBuffer)
        SSecBuffer.Play(0, DirectSound.BufferPlayFlags.Default)
        FB.BaseStream.Close()
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        SDevice.SetCooperativeLevel(Me, DirectSound.CooperativeLevel.Priority)
        With SFormat
            .AverageBytesPerSecond = 44100
            .BitsPerSample = 8
            .BlockAlign = 2
            .Channels = 2
            .FormatTag = DirectSound.WaveFormatTag.Pcm
            .SamplesPerSecond = 22050
        End With
    End Sub

    Private Sub StopSound()
        If SSecBuffer IsNot Nothing Then
            SSecBuffer.Stop()
            SSecBuffer.SetCurrentPosition(0)
        End If
    End Sub

    Private Sub ButtonStop_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonStop.Click
        StopSound()
    End Sub
End Class
