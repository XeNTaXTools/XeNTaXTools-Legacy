﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.OpenSBFDialog = New System.Windows.Forms.OpenFileDialog
        Me.ButtonOpen = New System.Windows.Forms.Button
        Me.LabelFileName = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.SaveWAVDialog = New System.Windows.Forms.SaveFileDialog
        Me.ButtonLeft = New System.Windows.Forms.Button
        Me.ButtonRight = New System.Windows.Forms.Button
        Me.ButtonPlay = New System.Windows.Forms.Button
        Me.ButtonSave = New System.Windows.Forms.Button
        Me.ListViewSBF = New System.Windows.Forms.ListView
        Me.ColumnHeaderSBFID = New System.Windows.Forms.ColumnHeader
        Me.ColumnHeaderSBFName = New System.Windows.Forms.ColumnHeader
        Me.ToolTipButtons = New System.Windows.Forms.ToolTip(Me.components)
        Me.ButtonStop = New System.Windows.Forms.Button
        Me.ColumnHeaderSBFLength = New System.Windows.Forms.ColumnHeader
        Me.ListViewWAV = New System.Windows.Forms.ListView
        Me.ColumnHeader1 = New System.Windows.Forms.ColumnHeader
        Me.ColumnHeader2 = New System.Windows.Forms.ColumnHeader
        Me.ColumnHeader3 = New System.Windows.Forms.ColumnHeader
        Me.SuspendLayout()
        '
        'OpenSBFDialog
        '
        Me.OpenSBFDialog.FileName = ".sbf"
        Me.OpenSBFDialog.Filter = "SBF0|*.sbf|All files|*.*"
        '
        'ButtonOpen
        '
        Me.ButtonOpen.Font = New System.Drawing.Font("Wingdings", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.ButtonOpen.Location = New System.Drawing.Point(8, 8)
        Me.ButtonOpen.Name = "ButtonOpen"
        Me.ButtonOpen.Size = New System.Drawing.Size(24, 24)
        Me.ButtonOpen.TabIndex = 0
        Me.ButtonOpen.Text = "1"
        Me.ToolTipButtons.SetToolTip(Me.ButtonOpen, "Open SBF")
        Me.ButtonOpen.UseVisualStyleBackColor = True
        '
        'LabelFileName
        '
        Me.LabelFileName.AutoSize = True
        Me.LabelFileName.Location = New System.Drawing.Point(40, 16)
        Me.LabelFileName.Name = "LabelFileName"
        Me.LabelFileName.Size = New System.Drawing.Size(72, 13)
        Me.LabelFileName.TabIndex = 1
        Me.LabelFileName.Text = "No file loaded"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(8, 40)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(43, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "SBF file"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(208, 40)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(65, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "WAV output"
        '
        'SaveWAVDialog
        '
        Me.SaveWAVDialog.FileName = ".wav"
        Me.SaveWAVDialog.Filter = "PCM|*.wav|All files|*.*"
        '
        'ButtonLeft
        '
        Me.ButtonLeft.Font = New System.Drawing.Font("Wingdings 3", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.ButtonLeft.Location = New System.Drawing.Point(168, 56)
        Me.ButtonLeft.Name = "ButtonLeft"
        Me.ButtonLeft.Size = New System.Drawing.Size(32, 32)
        Me.ButtonLeft.TabIndex = 4
        Me.ButtonLeft.Text = "3"
        Me.ToolTipButtons.SetToolTip(Me.ButtonLeft, "Remove selected sounds from WAV")
        Me.ButtonLeft.UseVisualStyleBackColor = True
        '
        'ButtonRight
        '
        Me.ButtonRight.Font = New System.Drawing.Font("Wingdings 3", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.ButtonRight.Location = New System.Drawing.Point(168, 88)
        Me.ButtonRight.Name = "ButtonRight"
        Me.ButtonRight.Size = New System.Drawing.Size(32, 32)
        Me.ButtonRight.TabIndex = 4
        Me.ButtonRight.Text = "4"
        Me.ToolTipButtons.SetToolTip(Me.ButtonRight, "Add selected sounds to WAV")
        Me.ButtonRight.UseVisualStyleBackColor = True
        '
        'ButtonPlay
        '
        Me.ButtonPlay.Font = New System.Drawing.Font("Webdings", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.ButtonPlay.Location = New System.Drawing.Point(168, 120)
        Me.ButtonPlay.Name = "ButtonPlay"
        Me.ButtonPlay.Size = New System.Drawing.Size(32, 32)
        Me.ButtonPlay.TabIndex = 4
        Me.ButtonPlay.Text = "4"
        Me.ToolTipButtons.SetToolTip(Me.ButtonPlay, "Play first sound selected in SBF")
        Me.ButtonPlay.UseVisualStyleBackColor = True
        '
        'ButtonSave
        '
        Me.ButtonSave.Font = New System.Drawing.Font("Wingdings", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.ButtonSave.Location = New System.Drawing.Point(168, 184)
        Me.ButtonSave.Name = "ButtonSave"
        Me.ButtonSave.Size = New System.Drawing.Size(32, 32)
        Me.ButtonSave.TabIndex = 4
        Me.ButtonSave.Text = "="
        Me.ToolTipButtons.SetToolTip(Me.ButtonSave, "Save WAV")
        Me.ButtonSave.UseVisualStyleBackColor = True
        '
        'ListViewSBF
        '
        Me.ListViewSBF.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeaderSBFID, Me.ColumnHeaderSBFName, Me.ColumnHeaderSBFLength})
        Me.ListViewSBF.FullRowSelect = True
        Me.ListViewSBF.Location = New System.Drawing.Point(8, 56)
        Me.ListViewSBF.Name = "ListViewSBF"
        Me.ListViewSBF.Size = New System.Drawing.Size(152, 160)
        Me.ListViewSBF.TabIndex = 5
        Me.ListViewSBF.UseCompatibleStateImageBehavior = False
        Me.ListViewSBF.View = System.Windows.Forms.View.Details
        '
        'ColumnHeaderSBFID
        '
        Me.ColumnHeaderSBFID.Text = "ID"
        Me.ColumnHeaderSBFID.Width = 30
        '
        'ColumnHeaderSBFName
        '
        Me.ColumnHeaderSBFName.Text = "Name"
        '
        'ButtonStop
        '
        Me.ButtonStop.Font = New System.Drawing.Font("Wingdings", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.ButtonStop.Location = New System.Drawing.Point(168, 152)
        Me.ButtonStop.Name = "ButtonStop"
        Me.ButtonStop.Size = New System.Drawing.Size(32, 32)
        Me.ButtonStop.TabIndex = 4
        Me.ButtonStop.Text = "n"
        Me.ButtonStop.UseVisualStyleBackColor = True
        '
        'ColumnHeaderSBFLength
        '
        Me.ColumnHeaderSBFLength.Text = "Len"
        Me.ColumnHeaderSBFLength.Width = 30
        '
        'ListViewWAV
        '
        Me.ListViewWAV.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1, Me.ColumnHeader2, Me.ColumnHeader3})
        Me.ListViewWAV.FullRowSelect = True
        Me.ListViewWAV.Location = New System.Drawing.Point(208, 56)
        Me.ListViewWAV.Name = "ListViewWAV"
        Me.ListViewWAV.Size = New System.Drawing.Size(152, 160)
        Me.ListViewWAV.TabIndex = 5
        Me.ListViewWAV.UseCompatibleStateImageBehavior = False
        Me.ListViewWAV.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "ID"
        Me.ColumnHeader1.Width = 30
        '
        'ColumnHeader2
        '
        Me.ColumnHeader2.Text = "Name"
        '
        'ColumnHeader3
        '
        Me.ColumnHeader3.Text = "Len"
        Me.ColumnHeader3.Width = 30
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(364, 221)
        Me.Controls.Add(Me.ListViewWAV)
        Me.Controls.Add(Me.ListViewSBF)
        Me.Controls.Add(Me.ButtonSave)
        Me.Controls.Add(Me.ButtonStop)
        Me.Controls.Add(Me.ButtonPlay)
        Me.Controls.Add(Me.ButtonRight)
        Me.Controls.Add(Me.ButtonLeft)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.LabelFileName)
        Me.Controls.Add(Me.ButtonOpen)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.MaximizeBox = False
        Me.MinimumSize = New System.Drawing.Size(204, 212)
        Me.Name = "Form1"
        Me.Text = "Delta Force Music Extractor"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents OpenSBFDialog As System.Windows.Forms.OpenFileDialog
    Friend WithEvents ButtonOpen As System.Windows.Forms.Button
    Friend WithEvents LabelFileName As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents SaveWAVDialog As System.Windows.Forms.SaveFileDialog
    Friend WithEvents ButtonLeft As System.Windows.Forms.Button
    Friend WithEvents ButtonRight As System.Windows.Forms.Button
    Friend WithEvents ButtonPlay As System.Windows.Forms.Button
    Friend WithEvents ButtonSave As System.Windows.Forms.Button
    Friend WithEvents ListViewSBF As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeaderSBFID As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeaderSBFName As System.Windows.Forms.ColumnHeader
    Friend WithEvents ToolTipButtons As System.Windows.Forms.ToolTip
    Friend WithEvents ButtonStop As System.Windows.Forms.Button
    Friend WithEvents ColumnHeaderSBFLength As System.Windows.Forms.ColumnHeader
    Friend WithEvents ListViewWAV As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader3 As System.Windows.Forms.ColumnHeader

End Class
