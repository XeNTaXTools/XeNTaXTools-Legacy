from urllib.request import ProxyHandler, build_opener, install_opener, urlopen
from itertools import islice
from multiprocessing.dummy import Pool as ThreadPool
import os
import io
import struct
pool = ThreadPool(10)

if not os.path.exists("magicHS"):
    os.makedirs("magicHS")
#proxy = urllib.request.ProxyHandler({'http': 'http://192.168.1.91:8888'})
proxy = ProxyHandler({})
opener = build_opener(proxy)
opener.addheaders = []
install_opener(opener)

def geturl(name, url):
	try:
		fldr = 'magicHS'
		path = name.split('_')
		for a in range(0, (len(path)) - 1):
			fldr += '/'
			fldr += path[a]
			if not os.path.exists(fldr):
				os.makedirs(fldr)
				print(fldr)
		if os.path.exists(fldr + '/' + (path[-1]).rstrip('\n') + '.unity3d'):
			pass
		else:
			print('Downlaoding',name)
			print(fldr + '/' + (path[-1]).rstrip('\n') + '.unity3d')
			myFile = urlopen(url).read()
			with open(fldr + '/' + (path[-1]).rstrip('\n') + '.unity3d', 'wb') as f:
				f.write(myFile)
		
	except:
		pass

def chunk(it, size):
    it = iter(it)
    return iter(lambda: tuple(islice(it, size)), ())


with open('costume_list.txt', 'rt') as f:
	names = f.read().splitlines()

with open('url_list.txt', 'rt') as f:
	urls = f.read().splitlines()

pool.starmap(geturl, zip(names,urls))




