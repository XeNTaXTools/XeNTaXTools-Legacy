from urllib.request import ProxyHandler, build_opener, install_opener, urlopen
from itertools import islice
from multiprocessing.dummy import Pool as ThreadPool
import os
import io
import struct
import hashlib
import json

pool = ThreadPool(10)

if not os.path.exists("magicHS"):
    os.makedirs("magicHS")
#proxy = urllib.request.ProxyHandler({'http': 'http://192.168.1.91:8888'})
proxy = ProxyHandler({})
opener = build_opener(proxy)
opener.addheaders = []
install_opener(opener)

def geturl(name, url):
	try:
		fldr = 'magicHS'
		if os.path.exists(fldr + '/' + name + '.unity3d'):
			pass
		else:
			print('Downlaoding',name)
			print(fldr + '/' + name + '.unity3d')
			myFile = urlopen(url).read()
			with open(fldr + '/' + name + '.unity3d', 'wb') as f:
				f.write(myFile)
		
	except:
		pass

def geturl2(name, url):
	try:
		fldr = 'magicHS'
		if os.path.exists(fldr + '/' + name):
			pass
		else:
			print('Downlaoding',name)
			print(fldr + '/' + name)
			myFile = urlopen(url).read()
			with open(fldr + '/' + name, 'wb') as f:
				f.write(myFile)
		
	except:
		pass

with open('assetfiles.json', 'rt') as f:
	names = []
	urls  = []
	content = f.read()
	person_dict = json.loads(content)
	#print(person_dict['asset_key'])
	#print(person_dict['asset_value'])
	#print(person_dict['file_key'])
	#print(person_dict['file_value'])
	for i in range(0,len(person_dict['asset_key'])):
		hName = person_dict['asset_key'][i] + '.unity3d' + str(person_dict['asset_value'][i])
		m = hashlib.md5()
		m.update(hName.encode(encoding='UTF-16LE',errors='strict'))
		hash = m.hexdigest()
		url = 'http://cache.lostzeromagichs.jp/assets/7/android/' + hash[0:2] + '/' + hash
		urls.append(url)
		names.append(person_dict['asset_key'][i])
	pool.starmap(geturl, zip(names,urls))
	names = []
	urls  = []
	for i in range(0,len(person_dict['file_key'])):
		hName = person_dict['file_key'][i] + ".akb.bytes" + str(person_dict['file_value'][i])
		fName = person_dict['file_key'][i] + ".akb.bytes"
		if '.json' in person_dict['file_key'][i]:
			hName = person_dict['file_key'][i] + str(person_dict['file_value'][i])
			fName = person_dict['file_key'][i]
		m = hashlib.md5()
		m.update(hName.encode(encoding='UTF-8',errors='strict'))
		hash = m.hexdigest()
		url = 'http://cache.lostzeromagichs.jp/assets/7/android/' + hash[0:2] + '/' + hash
		urls.append(url)
		names.append(fName)
		tmp = person_dict['file_key'][i].split('/')[:-1]
		dir = 'magicHS/'
		for a in range(0,len(tmp)):
			dir = dir + tmp[a] + '/' 
			if not os.path.exists(dir):
				os.makedirs(dir)
	pool.starmap(geturl2, zip(names,urls))
