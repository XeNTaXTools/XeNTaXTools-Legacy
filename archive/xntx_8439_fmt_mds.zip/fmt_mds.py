#by Durik256 for xentax
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("PS4 Theme", ".MDS")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)
    
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    if not data[:9].decode() in '.MDS 1.00':
        return 0
    return 1
	
def noepyLoadModel(data, mdlList):
    data = data.decode().split('\n')
    #Parse File
    Bones, Parts, Materials, Textures, Motions = [], {}, [], [], []

    for i in range(len(data)):
        if "Bone" in data[i].split():
            Bones.append(parseBone(data, i, FindBracket(data, i)))
            Bones[-1].bone.index = len(Bones)-1
        if "Part" in data[i].split():
            Parts.update(parsePart(data, i, FindBracket(data, i)))
        if "Texture" in data[i].split():
            Textures.append(parseTexture(data, i, FindBracket(data, i)))
        if "Material" in data[i].split():
            Materials.append(parseMaterial(data, i, FindBracket(data, i)))
        if 'Motion' in data[i].split():
            Motions.append(parseMotion(data, i, FindBracket(data, i)))
    
    #setNamesTexture
    for mat in Materials:
        for tx in Textures:
            name, path = tx.split('::')
            if mat.texName == name:
                mat.setTexture(path)
                break
    
    #Create Skeleton
    ctx = rapi.rpgCreateContext()
    Armature = []
    
    for x in Bones:
        Armature.append(x.bone)
    
    if Armature:
        Armature = rapi.multiplyBones(Armature)
    
    #Create Mesh
    for x in Bones:
        if x.drawPart:
            #Create Mesh
            for mesh in Parts[x.drawPart]['meshes']:
                setArr = Parts[x.drawPart]['arrays'][mesh.setArr]
                stride, attr, count = setArr['stride'], setArr['attr'], setArr['count']
                vert, norm, color, uvs, weight, indices = setArr['vert'], setArr['norm'], setArr['color'], setArr['uvs'], setArr['weight'], setArr['indices']
                
                newVert = [NoeVec3()]*count
                uniqueIndices = set([int(i) for i in data[mesh.ibuf].split()[4:]])
                
                
                if not x.blendBones:
                    x.blendBones.append(NoeBone(x.bone.index,x.bone.name,NoeMat43()))
                    weight = [[1]]*count
                    
                bnum = len(weight[0])
                
                
                if x.blendBones:#Weight
                    if not mesh.bMap:
                        mesh.bMap = [v for v in range(len(x.blendBones))]
                        indices = [mesh.bMap]*count
                    
                    realBone = [getBoneId(Armature,x.blendBones[v].name) for v in mesh.bMap]
                    
                    for v in uniqueIndices:
                        for w in range(bnum):
                            newVert[v] += x.blendBones[mesh.bMap[indices[v][w]]].getMatrix()*Armature[realBone[indices[v][w]]].getMatrix()*weight[v][w]*vert[v]#NoeVec3()
                
                #else:
                #    newVert = vert
                
                wbuf, iwbuf = b'', b''
                vbuf = b''
                for v in range(count):
                    vbuf += newVert[v].toBytes()
                    wbuf += noePack("%if"%bnum, *weight[v])
                    iwbuf += noePack("%iH"%bnum, *indices[v])
                
                rapi.rpgSetName(x.drawPart+'_'+mesh.name)
                rapi.rpgSetMaterial(mesh.mat)
                rapi.rpgSetBoneMap(realBone)
                rapi.rpgBindPositionBuffer(vbuf, noesis.RPGEODATA_FLOAT, 12)
                #if attr[1]:
                #    rapi.rpgBindNormalBuffer(norm, noesis.RPGEODATA_FLOAT, 12)
                if attr[3]:
                    uvstiride = len(attr[3])//count
                    rapi.rpgBindUV1Buffer(uvs, noesis.RPGEODATA_FLOAT, uvstiride)

                rapi.rpgBindBoneIndexBuffer(iwbuf, noesis.RPGEODATA_USHORT, bnum*2, bnum)
                rapi.rpgBindBoneWeightBuffer(wbuf, noesis.RPGEODATA_FLOAT, bnum*4, bnum)
                
                ibuf = b''.join([noePack("i", int(x)) for x in data[mesh.ibuf].split()[4:]])
                rapi.rpgCommitTriangles(ibuf, noesis.RPGEODATA_INT, len(ibuf)//4, noesis.RPGEO_TRIANGLE)
                
    #Create Animations
    Animations = []
    for x in Motions:
        animBones = []
        for y in x.animate:
            b = NoeKeyFramedBone(getBoneId(Armature, y))
            if x.animate[y]['Translate']:
                b.setTranslation(x.animate[y]['Translate'])
            if x.animate[y]['Rotate']:
                b.setRotation(x.animate[y]['Rotate'])
            if x.animate[y]['Scale']:
                b.setScale(x.animate[y]['Scale'], 2)
            animBones.append(b)
        anim = NoeKeyFramedAnim(x.name, Armature, animBones, x.rate)
        Animations.append(anim)
    
    #Create Models
    try: mdl = rapi.rpgConstructModel()
    except: mdl = NoeModel()
    mdl.setBones(Armature)
    mdl.setAnims(Animations)
    mdl.setModelMaterials(NoeModelMaterials([], Materials))
    mdlList.append(mdl)
    return 1

def getBoneId(arr, name):
    for i,b in enumerate(arr):
        if name == b.name:
            return i
    return -1
  
def FindBracket(arr, start):
    bracket = 0
    for i in range(start,len(arr)):
        if '{' in arr[i]:
            bracket += 1
        if '}' in arr[i]:
            bracket -= 1
        if bracket==0:
            return i

def parseMaterial(arr, start, end):
    material = NoeMaterial('', '')
    material.name = arr[start].split('"')[1]
    
    for i in range(start,end):
        split = arr[i].split()
        if "SetTexture" in split:
            material.setTexture(arr[i].split('"')[1])
            break

    return material

def parseTexture(arr, start, end):
    name = arr[start].split('"')[1]
    FileName = ''
    
    for i in range(start,end):
        split = arr[i].split()
        if "FileName" in split:
            FileName = arr[i].split('"')[1]

    return name+'::'+FileName

def parseBone(arr, start, end):
    name = arr[start].split('"')[1]
    parentBone = None
    drawPart = None
    mat = NoeMat43()
    blendBones = []
    
    for i in range(start,end):
        split = arr[i].split()
        if "ParentBone" in split:
            parentBone = arr[i].split('"')[1]
        if "Translate" in split:
            mat[3] = NoeVec3([float(x) for x in arr[i].replace('Translate','').split()])
        if "Rotate" in split:
            pos = mat[3] 
            mat = NoeQuat([float(x) for x in arr[i].replace('Rotate','').split()]).toMat43()
            mat[3] = pos
        if "Scale" in split:
            scale = NoeVec3([float(x) for x in arr[i].replace('Scale','').split()])
            #for x in range(3): mat[x][x] = scale[x]
        if "BlendBone" in split:
            b_name = arr[i].split('"')[1]
            b_mat = NoeMat44([NoeVec4([float(y) for y in x.replace('\\','').split()]) for x in arr[i+1:i+5]])
            blendBones.append(NoeBone(len(blendBones), b_name, b_mat.toMat43()))
        if "DrawPart" in split:
            drawPart = arr[i].split('"')[1]
        bone = NoeBone(0, name, mat.transpose(), parentBone)
    return Bone(bone, drawPart, blendBones)

def parsePart(arr, start, end):
    name = arr[start].split('"')[1]
    meshes, arrays = [], {}
    
    for i in range(start,end):
        split = arr[i].split()
        if "Mesh" in split:
            m_name, bMap = split[1][1:-1], None
            for x in range(i+1,FindBracket(arr, i)):
                split = arr[x].split()
                if "SetArrays" in split:
                    setArr = arr[x].split('"')[1] 
                elif "DrawArrays" in split:
                    type = split[2]
                    ibuf = x#b''.join([struct.pack("i", int(x)) for x in split[4:]])
                elif "SetMaterial" in split:
                    mat = arr[x].split('"')[1] 
                elif "BlendIndices" in split:
                    bMap = [int(x) for x in split[2:]]
            meshes.append(Mesh(m_name, mat, setArr, type, ibuf, bMap))
        elif "Arrays" in split:
            a_name, attr, count = split[1][1:-1], split[2], int(split[-2])
            stride, attr = ParseAttribute(attr)
            vert, norm, color, uvs, weight, indices = [], b'', [], b'', [], []
            #parse array
            for i in range(i+1,i+count+1):
                split = arr[i].split()
                ofs = 0
                if attr[0]:#vert
                    vert.append(NoeVec3([float(x) for x in split[:3]]))
                    ofs += 3
                if attr[1]:#norm
                    norm += noePack('3f', *[float(x) for x in split[ofs:ofs+3]])
                    ofs += 3
                if attr[2]:#color
                    #color.append(NoeVec4([float(x) for x in split[ofs:ofs+4]]))
                    ofs += 4
                if attr[3]:#uvs
                    uvs += noePack('2f', *[float(x) for x in split[ofs:ofs+2]])
                    ofs += 2
                if attr[4]:#weight
                    num = attr[4]//4
                    weight.append([float(x) for x in split[ofs:ofs+num]])
                    ofs += num
                if attr[5]:#indices
                    num = attr[4]//4
                    indices.append([int(x) for x in split[ofs:ofs+num]])
                    ofs += num
            
            #vbuf = b''.join([struct.pack("f", float(x)) for x in ''.join(arr[i+1:i+count+1]).split()])
            arrays[a_name] = {'vert':vert, 'norm':norm, 'color':color, 'uvs':uvs, 'weight':weight, 'indices':indices, 'stride':stride, 'attr':attr, 'count':count}
            i += count
    return {name: {'meshes':meshes, 'arrays':arrays}}

def ParseAttribute(attr):
    attr = attr.split('|')
    size = [12,0,0,0,0,0]
    for x in attr:
        if 'POSITION' in x:
            size[0] = 12
        elif 'NORMAL' in x:
            size[1] += 12
        elif 'COLOR' in x:
            size[2] += 16
        elif 'TEXCOORD' in x:
            size[3] += 8
        elif 'WEIGHT' in x:
            try: num = int(x.replace('WEIGHT',''))
            except: num = 1
            size[4] += num*4
        elif 'INDICES' in x:
            size[5] += size[4]
    return sum(size), size 

def parseMotion(arr, start, end):
    name = arr[start].split('"')[1]
    numFrame = 0
    rate = 30.0
    animate, fCurve = {}, {}
    
    for i in range(start,end):
        split = arr[i].split()
        if "FrameLoop" in split:
            numFrame = int(float(split[2]))
        elif "FrameRate" in split:
            rate = float(split[1])
        elif "Animate" in split:
            split = arr[i].split('"')
            b_name = split[1][6:]
            if not b_name in animate: 
                animate[b_name] = {'Translate':None, 'Rotate':None, 'Scale':None}
            animate[b_name][split[2].split()[0]] = split[3]
        elif "FCurve" in split:
            f_name, type, count, data = split[1][1:-1], int(split[4]), int(split[5]), []
            for x in range(i+1,i+count+1):
                f_split = [float(y) for y in arr[x].split()]
                vec = NoeVec3(f_split[1:]) if type == 3 else NoeQuat(f_split[1:]).transpose()
                data.append(NoeKeyFramedValue(f_split[0]/rate, vec))
            i += count
            fCurve[f_name] = data
    
    for x in animate:
        t, r, s = animate[x]['Translate'], animate[x]['Rotate'], animate[x]['Scale']
        if t:
            animate[x]['Translate'] = fCurve[t]
        if r:
            animate[x]['Rotate'] = fCurve[r]
        if s:
            animate[x]['Scale'] = fCurve[s]
    return Motion(name, animate, rate)
    
class Bone:
    def __init__(self, bone, drawPart, blendBones):
        self.bone = bone
        self.drawPart = drawPart
        self.blendBones = blendBones

class Mesh:
    def __init__(self, name, mat, setArr, type, ibuf, bMap):
        self.name = name
        self.mat = mat
        self.setArr = setArr
        self.type = type
        self.ibuf = ibuf
        self.bMap = bMap

class Motion:
    def __init__(self, name, animate, rate):
        self.name = name
        self.animate = animate
        self.rate = rate