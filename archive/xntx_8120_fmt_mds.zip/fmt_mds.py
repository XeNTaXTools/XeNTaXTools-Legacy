#by Durik256 for xentax
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("PS4 Theme", ".MDS")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)
    
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    if not data[:9].decode() in '.MDS 1.00':
        return 0
    return 1
	
def noepyLoadModel(data, mdlList):
    data = data.decode().split('\n')
    #Parse File
    Bones, Parts, Materials, Textures, Motions = [], {}, [], [], []

    for i in range(len(data)):
        if "Bone" in data[i].split():
            Bones.append(parseBone(data, i, FindBracket(data, i)))
            Bones[-1].bone.index = len(Bones)-1
        if "Part" in data[i].split():
            Parts.update(parsePart(data, i, FindBracket(data, i)))
        if "Texture" in data[i].split():
            pass
        if "Material" in data[i].split():
            pass
        if 'Motion' in data[i].split():
            Motions.append(parseMotion(data, i, FindBracket(data, i)))
    
    #Bones[0].bone.setMatrix(NoeAngles([90,0,0]).toMat43())
    #Create Skeleton
    ctx = rapi.rpgCreateContext()
    Armature = []
    for x in Bones:
        if x.bone.parentName:
            pIndx = [i for i,b in enumerate(Bones) if x.bone.parentName == b.bone.name][0]
            x.bone.setMatrix(x.bone.getMatrix() * Bones[pIndx].bone.getMatrix())
        Armature.append(x.bone)
    
    #Create Mesh
    for x in Bones:
        if x.drawPart:
            #Create Mesh
            for mesh in Parts[x.drawPart]['meshes']:
                rapi.rpgSetName(x.drawPart+'_'+mesh.name)
                rapi.rpgSetMaterial(mesh.mat)
                setArr = Parts[x.drawPart]['arrays'][mesh.setArr]
                stride, vbuf, attr, vnum = setArr['stride'], setArr['vbuf'], setArr['attr'], setArr['count']
                print(x.drawPart,x.bone.index, )
                if mesh.bMap:
                    skin = []
                    for bb in range(len(Armature)):
                        skin.append(NoeBone(bb,str(bb),NoeMat43()))
                    print(0,mesh.bMap)
                    #print(0,x.blendBones)
                    for u in mesh.bMap:
                        skin[getBoneId(Armature,x.blendBones[u].name)].setMatrix((x.blendBones[u].getMatrix()*Armature[getBoneId(Armature,x.blendBones[u].name)].getMatrix()))# x.bone.getMatrix()= x.blendBones[u] 
                    mesh.bMap = [getBoneId(Armature,x.blendBones[v].name) for v in mesh.bMap]
                    print(1,mesh.bMap)
                    #print(1,Armature)
                    rapi.rpgSetBoneMap(mesh.bMap)
                else:
                    skin = Armature

                rapi.rpgBindPositionBuffer(vbuf, noesis.RPGEODATA_FLOAT, stride)
                off = attr[0]
                if attr[1]:#Normals
                    rapi.rpgBindNormalBufferOfs(vbuf, noesis.RPGEODATA_FLOAT, stride, off)
                    off += attr[1]
                if attr[2]: off += attr[2]#Color
                if attr[3]:#Textcoord
                    rapi.rpgBindUV1BufferOfs(vbuf, noesis.RPGEODATA_FLOAT, stride, off)
                    off += attr[3]
                if attr[4]:#Weight
                    rapi.rpgBindBoneWeightBufferOfs(vbuf, noesis.RPGEODATA_FLOAT, stride, off, attr[4]//4)
                    off += attr[4]
                else:
                    print(x.bone.index, x.bone.name,vnum)
                    rapi.rpgBindBoneWeightBuffer(bytes([255]*vnum), noesis.RPGEODATA_UBYTE, 1, 1)
                if attr[5]:#Indices    
                    rapi.rpgBindBoneIndexBufferOfs(vbuf, noesis.RPGEODATA_FLOAT, stride, off, attr[4]//4)
                else:
                   index = [getBoneId(Armature,b.name) for b in x.blendBones] if x.blendBones else [x.bone.index]
                   rapi.rpgBindBoneIndexBuffer(bytes(index*vnum), noesis.RPGEODATA_UBYTE, len(index), len(index))
                
                start = min([int(x) for x in data[mesh.ibuf].split()[4:]])
                ibuf = b''.join([struct.pack("i", int(x)) for x in data[mesh.ibuf].split()[4:]])
                rapi.rpgCommitTriangles(ibuf, noesis.RPGEODATA_INT, len(ibuf)//4, noesis.RPGEO_TRIANGLE)
                #rapi.rpgOptimize()

                
                rapi.rpgSkinPreconstructedVertsToBones(skin)
    

    #Create Animations
    Animations = []
    for x in Motions:
        animBones = []
        for y in x.animate:
            b = NoeKeyFramedBone(getBoneId(Armature, y))
            if x.animate[y]['Translate']:
                b.setTranslation(x.animate[y]['Translate'])
            if x.animate[y]['Rotate']:
                b.setRotation(x.animate[y]['Rotate'])
            if x.animate[y]['Scale']:
                b.setScale(x.animate[y]['Scale'], 2)
            animBones.append(b)
        anim = NoeKeyFramedAnim(x.name, Armature, animBones, x.rate)
        Animations.append(anim)
    
    #Create Models
    try: mdl = rapi.rpgConstructModel()
    except: mdl = NoeModel()
    mdl.setBones(Armature)
    mdl.setAnims(Animations)
    try:
        for x in mdl.meshes[0].weights:
            print(x.indices, x.weights)
    except: pass
    mdlList.append(mdl)
    return 1

def getBoneId(arr, name):
    for i,b in enumerate(arr):
        if name == b.name:
            return i
    return -1
  
def FindBracket(arr, start):
    bracket = 0
    for i in range(start,len(arr)):
        if '{' in arr[i]:
            bracket += 1
        if '}' in arr[i]:
            bracket -= 1
        if bracket==0:
            return i
            
def parseBone(arr, start, end):
    name = arr[start].split('"')[1]
    parentBone = None
    drawPart = None
    mat = NoeMat43()
    blendBones = []
    
    for i in range(start,end):
        split = arr[i].split()
        if "ParentBone" in split:
            parentBone = arr[i].split('"')[1]
        if "Translate" in split:
            mat[3] = NoeVec3([float(x) for x in arr[i].replace('Translate','').split()])
        if "Rotate" in split:
            pos = mat[3] 
            mat = NoeQuat([float(x) for x in arr[i].replace('Rotate','').split()]).toMat43()
            mat[3] = pos
        if "Scale" in split:
            scale = NoeVec3([float(x) for x in arr[i].replace('Scale','').split()])
            #for x in range(3): mat[x][x] = scale[x]
        if "BlendBone" in split:
            b_name = arr[i].split('"')[1]
            b_mat = NoeMat44([NoeVec4([float(y) for y in x.replace('\\','').split()]) for x in arr[i+1:i+5]])
            blendBones.append(NoeBone(len(blendBones), b_name, b_mat.toMat43()))
        if "DrawPart" in split:
            drawPart = arr[i].split('"')[1]
        bone = NoeBone(0, name, mat.transpose(), parentBone)
    return Bone(bone, drawPart, blendBones)

def parsePart(arr, start, end):
    name = arr[start].split('"')[1]
    meshes, arrays = [], {}
    
    for i in range(start,end):
        split = arr[i].split()
        if "Mesh" in split:
            m_name, bMap = split[1][1:-1], None
            for x in range(i+1,FindBracket(arr, i)):
                split = arr[x].split()
                if "SetArrays" in split:
                    setArr = arr[x].split('"')[1] 
                elif "DrawArrays" in split:
                    type = split[2]
                    ibuf = x#b''.join([struct.pack("i", int(x)) for x in split[4:]])
                elif "SetMaterial" in split:
                    mat = arr[x].split('"')[1] 
                elif "BlendIndices" in split:
                    bMap = [int(x) for x in split[2:]]
            meshes.append(Mesh(m_name, mat, setArr, type, ibuf, bMap))
        elif "Arrays" in split:
            a_name, attr, count = split[1][1:-1], split[2], int(split[-2])
            stride, attr = ParseAttribute(attr)
            vbuf = b''.join([struct.pack("f", float(x)) for x in ''.join(arr[i+1:i+count+1]).split()])
            arrays[a_name] = {'vbuf':vbuf, 'stride':stride, 'attr':attr, 'count':count}
            i += count
    return {name: {'meshes':meshes, 'arrays':arrays}}

def ParseAttribute(attr):
    attr = attr.split('|')
    size = [12,0,0,0,0,0]
    for x in attr:
        if 'POSITION' in x:
            size[0] = 12
        elif 'NORMAL' in x:
            size[1] += 12
        elif 'COLOR' in x:
            size[2] += 16
        elif 'TEXCOORD' in x:
            size[3] += 8
        elif 'WEIGHT' in x:
            try: num = int(x.replace('WEIGHT',''))
            except: num = 1
            size[4] += num*4
        elif 'INDICES' in x:
            size[5] += size[4]
    return sum(size), size 

def parseMotion(arr, start, end):
    name = arr[start].split('"')[1]
    numFrame = 0
    rate = 30.0
    animate, fCurve = {}, {}
    
    for i in range(start,end):
        split = arr[i].split()
        if "FrameLoop" in split:
            numFrame = int(float(split[2]))
        elif "FrameRate" in split:
            rate = float(split[1])
        elif "Animate" in split:
            split = arr[i].split('"')
            b_name = split[1][6:]
            if not b_name in animate: 
                animate[b_name] = {'Translate':None, 'Rotate':None, 'Scale':None}
            animate[b_name][split[2].split()[0]] = split[3]
        elif "FCurve" in split:
            f_name, type, count, data = split[1][1:-1], int(split[4]), int(split[5]), []
            for x in range(i+1,i+count+1):
                f_split = [float(y) for y in arr[x].split()]
                vec = NoeVec3(f_split[1:]) if type == 3 else NoeQuat(f_split[1:]).transpose()
                data.append(NoeKeyFramedValue(f_split[0]/rate, vec))
            i += count
            fCurve[f_name] = data
    
    for x in animate:
        t, r, s = animate[x]['Translate'], animate[x]['Rotate'], animate[x]['Scale']
        if t:
            animate[x]['Translate'] = fCurve[t]
        if r:
            animate[x]['Rotate'] = fCurve[r]
        if s:
            animate[x]['Scale'] = fCurve[s]
    return Motion(name, animate, rate)
    
class Bone:
    def __init__(self, bone, drawPart, blendBones):
        self.bone = bone
        self.drawPart = drawPart
        self.blendBones = blendBones

class Mesh:
    def __init__(self, name, mat, setArr, type, ibuf, bMap):
        self.name = name
        self.mat = mat
        self.setArr = setArr
        self.type = type
        self.ibuf = ibuf
        self.bMap = bMap

class Motion:
    def __init__(self, name, animate, rate):
        self.name = name
        self.animate = animate
        self.rate = rate