#include <ddraw.h>

typedef struct {
	char magic[4];
	DDSURFACEDESC2 s; 
} dds_header;

int txcount=1;

void DeswizzleDXT1(BYTE *raw, BYTE* dst, int width, int height, int size)
{

	memset(dst,0,size);
	int Position = 0;
	int dest=0;

    if (height <= 64)
    {
        int factor = (unsigned short)(128/height);
        height *= factor;
        width *= factor;
    }

    int sections, offset1, offset2, offset3, offset4, offset5, x;

    if (width >= 0x80) { sections = width / 0x80; }
    else { sections = 1; }

    offset1 = offset2 = offset3 = offset4 = offset5 = 0;
    x = 128;

    int bias = -8;

    for (int n = 0; n < (height / 64); n++)
    {
        for (int l = 0; l < 8; l++)
        {
            for (int k = 0; k < 2; k++)
            {
                for (int j = 0; j < sections; j++)
                {

                    int offset = offset1 + offset2 + offset3 + offset4 + offset5;

                    for (int i = 0; i < 0x10; i++)
                    {
                        int ofs1 = (-2 * ((i & 8) >> 3) + 1);
                        int ofs2 = ((l & 4) << 1);
                        int ofs3 = (i & 3) + 0xC * ((i & 2) >> 1);
                        Position = 0x10 * (i + bias + ofs1 * ofs2 + ofs3 + offset) + x;
						for (int zz=0;zz<16;zz++)
							dst[dest+zz]=raw[Position+zz];

						dest +=16;
                    }

                    offset1 += 0x200;
                }
                offset1 = 0;
                offset2 = 1;
            }
            offset2 = 0;
            offset3 += 0x20;
            offset4 += 0x80 * (l == 3 ? 1 : 0);
        }
        offset3 = 0;
        if ((n & 1) == 1)
        {
            offset4 = 0;
            offset5 += width * 4;
        }
    }

}


void TextureWrite(trbInMemTex_t *tex){
	dds_header h;
	BYTE *dst=0;
	dst = (BYTE*)malloc(tex->memSize);
	memset(&h,0,128);

	for (int i=0;i<tex->memSize/2; i++) {
		BYTE c=tex->mem[i*2];
		tex->mem[i*2] = tex->mem[i*2+1];
		tex->mem[i*2+1] = c;
	}

	h.magic[0] = 'D';
	h.magic[1] = 'D';
	h.magic[2] = 'S';
	h.magic[3] = ' ';

	h.s.dwSize = 124;
	h.s.dwFlags = DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH | DDSD_PIXELFORMAT | DDSD_MIPMAPCOUNT;
	h.s.dwHeight = tex->gt.height;
	h.s.dwWidth = tex->gt.width;
	h.s.dwMipMapCount = 0;

	h.s.ddpfPixelFormat.dwSize = 32;
	h.s.ddpfPixelFormat.dwFlags = DDPF_FOURCC;
	switch(tex->gt.imgFmt)
	{
	case 24:
//		compGLFormat = GL_COMPRESSED_RGBA_S3TC_DXT1_EXT;
		h.s.ddpfPixelFormat.dwFourCC = FOURCC_DXT1;
		DeswizzleDXT1(tex->mem,dst,tex->gt.width,tex->gt.height,tex->memSize);
		break;
	case 25:
//		compGLFormat = GL_COMPRESSED_RGBA_S3TC_DXT3_EXT;
		h.s.ddpfPixelFormat.dwFourCC = FOURCC_DXT3;
		break;
	case 26:
//		compGLFormat = GL_COMPRESSED_RGBA_S3TC_DXT5_EXT;
		h.s.ddpfPixelFormat.dwFourCC = FOURCC_DXT5;
		break;
	case 3:
//		notCompressed = true;
//		compGLFormat = GL_RGBA;
		h.s.ddpfPixelFormat.dwFourCC = DDPF_RGB | DDPF_ALPHAPIXELS;
		h.s.ddpfPixelFormat.dwFlags = 0;
		h.s.ddpfPixelFormat.dwRGBBitCount = 32;
		h.s.ddpfPixelFormat.dwRBitMask = 0x00FF0000;
		h.s.ddpfPixelFormat.dwGBitMask = 0x0000FF00;
		h.s.ddpfPixelFormat.dwBBitMask = 0x000000FF;
		h.s.ddpfPixelFormat.dwRGBAlphaBitMask = 0xff000000;
		break;
	default:
		break;
	}
	h.s.ddsCaps.dwCaps = DDSCAPS_COMPLEX | DDSCAPS_TEXTURE | DDSCAPS_MIPMAP;
	


	
	char txname[128];
	
	FILE *tx;
	sprintf(txname,"debug/texture%02d.dds",txcount);
	tx = fopen(txname,"wb");
	fwrite(&h,128,1,tx);
	fwrite(dst,tex->memSize,1,tx);
	fclose(tx);

	txcount++;

}

void Image_UntileRAW(BYTE* a, BYTE* b, int c, WORD d, WORD e, int f) {

}

void Image_UntileDXT(BYTE* a, BYTE* b, int c, WORD d, WORD e, int f) {

}