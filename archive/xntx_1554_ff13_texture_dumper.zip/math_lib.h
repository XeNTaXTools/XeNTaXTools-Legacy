#include <io.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>


void LittleBigSwap(BYTE *y, int count) {
	int i;
	unsigned char c;
	for (i=0;i<count/2;i++) {
		c=y[i];
		y[i]=y[count-i-1];
		y[count-i-1]=c;
	}
}

void LittleBigSwap(WORD *y, int count) {
	LittleBigSwap((BYTE*)y, count);
}

void LittleBigSwap(int *y, int count) {
	LittleBigSwap((BYTE*)y, count);
}

#define LITTLE_BIG_SWAP(x) LittleBigSwap((BYTE*)&x,sizeof(x))