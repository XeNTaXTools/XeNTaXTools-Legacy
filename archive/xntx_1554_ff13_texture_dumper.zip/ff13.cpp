// ff13.cpp : Defines the entry point for the console application.
//

#include <windows.h>		// Header File For Windows
#include "stdafx.h"
#include <io.h>
#include <stdio.h>
#include <tchar.h>
#include <stdlib.h>
#include <string.h>
//#include "funcs.h"
#include "math_lib.h"
#include "types.h"
#include "mem_lib.h"
#include "image_lib.h"

#define g_inFileName "debug/c001.x360.trb"
#define tryName "debug/c001.x360.imgb"



int Model_LoadTRB(BYTE *fileBuffer, int bufferLen)
{

	trbHdr_t *hdr = (trbHdr_t *)fileBuffer;

	int ofs = sizeof(trbHdr_t);
	trbResInfo_t *resInfo = (trbResInfo_t *)(fileBuffer + ofs);
	ofs += sizeof(trbResInfo_t)*hdr->numResources;

	printf("Processing TRB with %i resources.\n", hdr->numResources);

	FILE *imgBundle = NULL;
	bool imgBundleTried = false;


	int numBones = 0;

	trbTexName_t *texNames = NULL;
	char *extTable = NULL;
	int totalResSize = 0;
	for (int i = 0; i < hdr->numResources; i++)
	{
		trbResInfo_t *ri = &resInfo[i];
		if ((ofs + ri->ofs) >= bufferLen)
		{
			printf("Unexpected offset overflow.\n");
			break;
		}
		trbTypeHdr_t *typeHdr = (trbTypeHdr_t *)(fileBuffer + ofs + ri->ofs);
		totalResSize += ri->size;
		if (ri->resourceType <= 0)
		{
			if (!extTable)
			{
				extTable = (char *)typeHdr;
			}
			else if (!texNames)
			{
				texNames = (trbTexName_t *)typeHdr;
			}
			continue;
		}
		if (!memcmp(typeHdr->id, "SEDBtxb", 7))
		{ //texture
			if (!imgBundle && g_inFileName && !imgBundleTried)
			{
//				GetExtensionlessName(tryName, g_inFileName);
//				strcat(tryName, ".imgb");
				imgBundle = fopen(tryName, "rb");
				if (!imgBundle)
				{
					printf("Could not open image bundle '%s'.\n", tryName);
				}
				else
				{
					printf("Loaded '%s' successfully.\n", tryName);
				}
				imgBundleTried = true;
			}
			txbHdr_t *txb = (txbHdr_t *)typeHdr;
			BYTE *gtex = (BYTE *)typeHdr + 64;
			gtexHdr_t gt;
			memcpy(&gt, gtex, sizeof(gt));
			gtex += sizeof(gt);
			LittleBigSwap(&gt.unknownA, 2);
			LittleBigSwap(&gt.unknownC, 2);
			LittleBigSwap(&gt.width, 2);
			LittleBigSwap(&gt.height, 2);
			LittleBigSwap(&gt.unknownD, 2);
			LittleBigSwap(&gt.unknownE, 4);
			LittleBigSwap(&gt.unknownF, 4);

			int firstMipOfs = *((int *)gtex);
			LittleBigSwap(&firstMipOfs, 4);
			int realSize = *((int *)gtex + 1);
			LittleBigSwap(&realSize, 4);

			if (imgBundle)
			{
				int imgLen = realSize;
				BYTE *imgData = (BYTE *)unpooled_malloc(imgLen, 39392);
				fseek(imgBundle, firstMipOfs, SEEK_SET);
				fread(imgData, 1, imgLen, imgBundle);

				trbInMemTex_t inMemTex;
				memset(&inMemTex, 0, sizeof(inMemTex));
				inMemTex.gt = gt;
				inMemTex.mem = imgData;
				inMemTex.memSize = imgLen;
				inMemTex.resIdx = i;
				TextureWrite(&inMemTex);
				free(imgData);
//				textures.Append(inMemTex);
			}
		}
		else if (!memcmp(typeHdr->id, "SEDBshd", 7))
		{ /*
			trbInMemShader_t shd;
			memset(&shd, 0, sizeof(shd));
			shd.p = (BYTE *)typeHdr;
			shd.resIdx = i;
			shd.resSize = ri->size;
			shaders.Append(shd);
			*/
		}
		else if (!memcmp(typeHdr->id, "SEDBwrb", 7))
		{ //mesh data
//			Model_TRB_ParseModel(fileBuffer, ri, typeHdr, meshes);
		}
		else if (!memcmp(typeHdr->id, "SEDBSKL", 7))
		{ //skeletal data
//			sedbSklHdr_t *sklHdr = (sedbSklHdr_t *)typeHdr;
//			bones = Model_TRB_ParseSkeleton(fileBuffer, ri, sklHdr, numBones);
		}
	}

	if (imgBundle)
	{
		fclose(imgBundle);
	}


	return 0;
}


int _tmain(int argc, _TCHAR* argv[])
{
	FILE *in=fopen(g_inFileName,"rb");
	int len=filelength (fileno (in));

	BYTE *buf=(BYTE*)malloc(len);
	fread(buf,len,1,in);

	Model_LoadTRB(buf,len);
	system("pause");
	return 0;
}

