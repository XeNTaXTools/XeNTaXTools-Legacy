typedef struct trbTexName_s
{
	char			name[16];
} trbTexName_t;

typedef struct trbTypeHdr_s
{
	BYTE			id[8];

	//probably easy to figure out, but never bothered
	int				unknownA;
	int				unknownB;
	int				unknownC;
} trbTypeHdr_t;

typedef struct trbHdr_s
{
	trbTypeHdr_t	thdr;

	int				unknownB[7];
	int				numResources;
	int				unknownD;
	int				numResourcesB; //wut
	BYTE			brt[4]; //"brt\0"
} trbHdr_t;

typedef struct trbResInfo_s
{
	int				resNum;
	int				ofs;
	int				size;
	int				resourceType;
} trbResInfo_t;

typedef struct txbHdr_s
{
	BYTE			id[8];
	int				unknownA;
	int				unknownB;
	int				texSize; //seems like original size, does not include padding
	int				unknownC[7];
	int				unknownD;
	int				unknownE[3];
} txbHdr_t;
typedef struct gtexHdr_s
{
	BYTE			id[4];
	WORD			unknownA;
	BYTE			imgFmt; //i think
	BYTE			numMips;
	WORD			unknownC;
	WORD			width;
	WORD			height;
	WORD			unknownD;
	int				unknownE;
	int				unknownF;
} gtexHdr_t;

typedef struct trbInMemTex_s
{
	gtexHdr_t		gt;
	int				resIdx;
	BYTE			*mem;
	int				memSize;
	int				glTex;
} trbInMemTex_t;

/*
typedef struct trbBoneInMem_s
{
	int				idx;
	int				parentIdx;
	char			*name;
	modelMatrix_t	mat;

	int				transCount;
	modelMatrix_t	modMat;
	modelMatrix_t	transMat;

	bool			hasBasePoseMat;
	modelMatrix_t	basePoseMat;
	modelMatrix_t	invBasePoseMat;

	modelMatrix_t	baseLocalTrans;
} trbBoneInMem_t;

typedef struct sedbSklHdr_s
{
	char			id[8];
	int				unknownA[8];
	int				unknownB[3];
	int				boneDataSize;
	int				numStrings; //i dunno
	BYTE			lks[4]; //"lks\0"
	int				strIdx;
	int				unknownE;
	int				boneDataSizeB; //?!
	int				unknownG;
} sedbSklHdr_t;
typedef struct sedbSklBone_s
{
	int				stringIdx;
	int				unknownB;
	int				unknownC;
	int				unknownD;

	float			trans[3];
	float			q[4];
	float			scl[3];

	int				parentIdxA;
	int				boneIdxA;
	int				parentIdxB;
	int				boneIdxB;

	int				stuff[26];
} sedbSklBone_t;
*/
typedef struct wrbChunkHdr_s
{
	BYTE			id[4];
	int				unknownA;
	int				dataSize;
	int				nextChunkOfs;
} wrbChunkHdr_t;

typedef struct wrbStmsHdr_s
{
	int				dataDefNum;
	int				dataNum;
	int				dataSize;
	int				unknownB;
} wrbStmsHdr_t;

typedef struct wrbStmsDataDef_s
{
	WORD			unknownA;
	WORD			elemOfs;
	int				dataType; //i guess
	int				elemNum;
	WORD			type;
	WORD			unknownC;
} wrbStmsDataDef_t;

#define MAX_FF13_BONES_PER_VERT	8
typedef struct meshIntrVert_s
{
	float			pos[3];
	float			normal[3];
	float			binormal[3];
	float			tangent[3];
	float			uv[2];

	int				boneIdx[MAX_FF13_BONES_PER_VERT];
	float			boneWeights[MAX_FF13_BONES_PER_VERT];
} meshIntrVert_t;

typedef enum
{
	VTYPE_INDEX = 0,
	VTYPE_POS,
	VTYPE_NORMAL,
	VTYPE_BINORMAL,
	VTYPE_TANGENT,
	VTYPE_UV,
	VTYPE_BONEIDX,
	VTYPE_BONEWEIGHT,
	NUM_VTYPES
} meshVertType_e;

typedef enum
{
	TEXTYPE_NONE = 0,
	TEXTYPE_DIFFUSE,
	TEXTYPE_NORMAL,
	TEXTYPE_TRANSPARENCY,
	NUM_TEXTYPES
} shaderTexType_e;
typedef struct trbShaderTexRef_s
{
	int				idx;
	int				type;
	char			*name;
} trbShaderTexRef_t;

typedef struct trbInMemShader_s
{
	BYTE				*p;
	int					resIdx;
	int					resSize;
	char				refName[256];

	trbShaderTexRef_t	*texRefs;
	int					numTexRefs;

	int					diffuseIdx;
	int					maskIdx;
} trbInMemShader_t;

typedef struct trbBoneRef_s
{
	int					idx;
	char				*name;
} trbBoneRef_t;

typedef struct trbInMemMesh_s
{
	meshIntrVert_t		*verts;
	int					numVerts;

	WORD				*idx;
	int					numIdx;

	char				*name;
	char				*shaderName;

	trbInMemShader_t	*shader;

	float				*testTrans;

	trbBoneRef_t		*boneRefs;
	int					numBoneRefs;

	int					numBoneWeights;
} trbInMemMesh_t;
