from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("_BDAE_TEST", ".bdae")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)
    return 1

def noepyCheckType(data):
    if data[:4] != b'EADB':
        return 0
    return 1
    
def noepyLoadModel(data, mdlList):
    bs = NoeBitStream(data)
    #0,1-header;2-num_file?;3-mat_num;4-bone_num?;5-mesh_num?;6-submesh_num;7-zero;8-??;9,15-zero;
    #16-indices_num;17-mat_offset;18-bone_offset;19-mesh_offset??;20-unk;21-submesh_info?,22,23-unk_offset; 24-vert_offset;25-indies_offset
    info = [bs.readUInt() for x in range(26)]
    print(info)
    
    bs.seek(info[21])
    
    submesh = []
    for x in range(info[6]):
        #0-unk,1-stride?;2-vert_start;3-vert_num;4-ind_strat;5-ind_num;6-FFFF;7...-zero?
        sm_inf = [bs.readUInt() for x in range(13)]
        submesh.append([sm_inf[1], sm_inf[2], sm_inf[3], sm_inf[4], sm_inf[5]])
        print(submesh[-1], sm_inf)
    
    ctx = rapi.rpgCreateContext()
    
    bs.seek(info[25])
    ibuf = bs.readBytes(info[16]*2)

    bs.seek(info[24])
    vbuf = bs.readBytes((submesh[-1][1]+submesh[-1][2])*12)
    
    rapi.rpgBindPositionBuffer(vbuf, noesis.RPGEODATA_FLOAT, 12)
    rapi.rpgCommitTriangles(ibuf, noesis.RPGEODATA_USHORT, info[16], noesis.RPGEO_TRIANGLE_STRIP)
    
    mdl = rapi.rpgConstructModel()
    mdlList.append(mdl)
    return 1
    