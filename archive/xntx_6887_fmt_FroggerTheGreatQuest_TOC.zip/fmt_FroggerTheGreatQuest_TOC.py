# Frogger The Great Quest TOC map importer by Bigchillghost

import rapi
from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Frogger The Great Quest", ".TOC")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadModel(handle, noepyLoadModel)
	#noesis.logPopup()
	return 1

#check if it's this type based on the data
def noepyCheckType(data):
	if len(data) < 0x80:
		return 0
	bs = NoeBitStream(data)
	Magic = bs.readUInt()
	if Magic != 0x00434F54: # "TOC\0"
		return 0
	return 1

#load the model
def noepyLoadModel(data, mdlList):
	bs = NoeBitStream(data)
	Magic = bs.readUInt()
	while Magic != 0x0054544F: # "OTT\0"
		Offset = bs.tell() + 0x24
		Offset += bs.readInt()
		bs.seek(Offset, NOESEEK_ABS)
		Magic = bs.readUInt()
	bs.seek(0x30, NOESEEK_REL)
	SkipSize = bs.readInt()
	meshCount = bs.readInt()
	SkipSize += bs.readInt()
	bs.seek(SkipSize + 0x28, NOESEEK_REL)
	meshes = []
	for i in range(0, meshCount):
		bs.seek(0x44, NOESEEK_REL)
		structSize = bs.readInt()
		if structSize != 0x24:
			break
		bs.seek(4, NOESEEK_REL)
		Count = bs.readInt() * 3
		bs.seek(0x10, NOESEEK_REL)
		Positions = []
		Normals = []
		TexCoords = []
		PolygonIndex = []
		for j in range(0, Count):
			Positions.append(NoeVec3.fromBytes(bs.readBytes(12)))
			Normals.append(NoeVec3.fromBytes(bs.readBytes(12)))
			bs.seek(4, NOESEEK_REL)
			TexCoords.append(NoeVec3([bs.readFloat(),bs.readFloat(), 0.0]))
			PolygonIndex.append(j)
			
		mesh = NoeMesh(PolygonIndex, Positions)
		mesh.setName('Mesh_%04d'%i)
		mesh.setMaterial('Mat_%04d'%i)
		mesh.setNormals(Normals)
		mesh.setUVs(TexCoords)
		meshes.append(mesh)
	mdl = NoeModel(meshes)
	mdlList.append(mdl)
	return 1
