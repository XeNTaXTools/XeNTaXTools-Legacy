from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Wolfenstein The Old Blood", ".bimage")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
	#noesis.logPopup()
	return 1

	#check if it's this type based on the data
def noepyCheckType(data):
	bs = NoeBitStream(data)
	bs.seek(0x05, NOESEEK_ABS)
	Magic = bs.readBytes(3).decode("ASCII")
	if Magic != 'MIB':
		return 0
	return 1

def noepyLoadRGBA(data, texList):
    datasize = len(data) - 0x48        
    bs = NoeBitStream(data)
    bs.setEndian(NOE_BIGENDIAN)
    bs.seek(0x0c, NOESEEK_ABS)
    imgWidth = bs.readInt()
    imgHeight = bs.readInt()
    bs.seek(0x48, NOESEEK_ABS)        
    data = bs.readBytes(datasize)      
    print(datasize)
    data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "r0 g0 b0 a8")
    texFmt = noesis.NOESISTEX_RGBA32
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1