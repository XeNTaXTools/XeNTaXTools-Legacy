Notes about PakDecrypt.ini:
1. Set Debug to 1 to skip zip entries parsing which'll allow you to validate if the used key decrypted the entries correctly;
2. There's an initial key used by the program. Set OverwirteKey to 1 to overwrite the key from RSAKeyData.bin;
3. You can specify whether the key in RSAKeyData.bin is stored as binary data or textual hex sequence. Set AsciiKey to 1
and place the ascii key in RSAKeyData.bin as the following format: ABCDEF01020304...0809
no extra characters should be inserted at any place. The program will convert this ascii key to binary and store it in ConvKeyData.bin, which'll be used as the actual key for current execution.