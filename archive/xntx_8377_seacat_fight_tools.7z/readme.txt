Put files that you wish to dump into the same folder with these .exess and .bats then run the appropriate .bat for the file you want to decompress.
For example, putting BUP.BIN into the folder with the .exes and .bats and then running dumpbin.bat will create a folder named BUP with the files inside of it.
The .BIN extension is just a generic extension and in most cases it can be parsed if you run it through dumpbin.exe.

Invididual EXE usages:
dumpbin.exe BUP.BIN BUP
ozpdecomp.exe VSCRIPT.OZP VSCRIPT.OZ
decomplzlr.exe 00.LZR 00.BIN

Unless you have a reason to use a specific tool, I would recommend using the .bats as they will string together relevant programs.