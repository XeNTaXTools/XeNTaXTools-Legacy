#pragma once

bool extractFiles(const char* isoPath, const char *outputDirectory);
void printSupportedVersions();
