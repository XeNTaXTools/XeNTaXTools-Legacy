import newGameLib
reload(newGameLib)
from newGameLib import *
import Blender


	
def r3cmParser(filename,g):
	g.debug=False
	skeleton=Skeleton()
	mesh=Mesh() 
	mesh.BINDSKELETON='armature'
	#mesh.boneNameList=
	mesh.TRIANGLE=True
	
	dane = g.B(36)
	g.seek(1024,0)
	material=Mat()
	material.TRIANGLE=True
	material.ZTRANS=True
	material.name=str(model_id)+'-mat-'+str(0)
	texname=g.find('\x00')
	if len(texname)>0:
		material.diffuse=g.dirname+os.sep+texname#.replace('.dds','.png')
		material.normal=g.dirname+os.sep+texname.replace('.dds','_n.dds')	
		material.specular=g.dirname+os.sep+texname.replace('.dds','_sp.dds')	
	g.seek(1280,0)
	dane = g.i(2)
	numverts = dane[0]
	numindices = dane[1]
	
	g.debug=False
	skin=Skin()
	for id_vert in range(numverts):
		mesh.vertPosList.append(g.f(3))
		mesh.vertUVList.append(g.f(2))
		dane = g.f(3)
		mesh.skinIndiceList.append(g.B(4))
		mesh.skinWeightList.append(g.B(4))
	mesh.indiceList=g.H(numindices)
	boneMapCount=g.H(1)[0]
	skinFlag=g.H(1)[0]
	used_bones = g.B(boneMapCount)
	used_bones_fix=[]
	for m in range(len(used_bones)):
		used_bones_fix.append(used_bones[m])
	#skin.skeleton='armature'#used_bones_fix
	if skinFlag==0:
		skin.boneMap=used_bones_fix
	mesh.skinList.append(skin)
	mesh.matList.append(material)	
	mesh.draw()
			
	
def r3cbParser(filename,g):
	
	
	skeleton=Skeleton()
	skeleton.ARMATURESPACE=True
	skeleton.NICE=False
	skeleton.BINDMESH=True
	
	g.seek(1024)
	boneCount = g.i(1)[0] 	
	for id_bone in range(boneCount):
		t=g.tell()
		bonename = g.find('\x00')
		bonename=g.read(147-len(bonename))
		#bonename=g.word(147)
		#print bonename
		#if len(bonename)==0:bonename=None
		bonename = str(id_bone)
		bone=Bone()
		bone.name=bonename
		g.i(29)
		id = g.i(2)
		g.seek(t+276)
		bone.parentID=g.i(1)[0]
		matrixbone = Matrix(g.f(4),g.f(4),g.f(4),g.f(4))
		matrixparent = Matrix(g.f(4),g.f(4),g.f(4),g.f(4))
		g.f(10)
		id = g.i(1)[0]
		g.read(id*4)
		bone.posMatrix =  TranslationMatrix(matrixparent.translationPart())
		bone.rotMatrix = matrixparent.rotationPart().resize4x4()
		skeleton.boneList.append(bone)
	skeleton.draw()	


def r3ceParser(filename,g):   
	g.debug=False
	
	action=Action()
	action.name=Blender.sys.basename(filename).split('.')[0]
	action.BONESPACE=True
	action.BONESORT=True
		
	g.seek(260)
	v=g.i(3)
	poskeylist=[]
	rotkeylist=[]	
	for n in range(v[2]):
			poskeylist.append(TranslationMatrix(Vector(g.f(3))))
			rot = g.f(4)
			rotmatrix=Quaternion(rot[3],rot[0],rot[1],rot[2]).toMatrix().resize4x4()
			rotkeylist.append(rotmatrix)
	for m in range(v[0]):
		boneID=g.i(1)[0]
		if boneID!=-1:
			bonename = str(boneID) 
			abone=ActionBone()
			abone.name=bonename
			frameCount=g.i(1)[0]
			for n in range(frameCount):
				keyID=g.i(1)[0]
				abone.posFrameList.append(n)
				abone.rotFrameList.append(n)
				abone.posKeyList.append(poskeylist[keyID])
				abone.rotKeyList.append(rotkeylist[keyID])
			action.boneList.append(abone)	
			
			
	action.draw()
	action.setContext()
			
def Parser():	
	filename=input.filename
	global dirname
	global model_id
	
	model_id=ParseID()
	
	ext=filename.split('.')[-1].lower()
	dirname=Blender.sys.dirname(filename)
	basename=Blender.sys.basename(filename)
	
	
	all=True
	if ext=='r3cb':
			file=open(filename,'rb')
			g=BinaryReader(file)
			r3cbParser(filename,g)
			file.close()
			
	if ext=='r3ce':
			file=open(filename,'rb')
			g=BinaryReader(file)
			r3ceParser(filename,g)
			file.close()
			
	if ext=='r3cm':
		if all==False:
			meshList=[]
			matList=[]
			usedVertexList=None
			file=open(filename,'rb')
			g=BinaryReader(file)
			r3cmParser(filename,g)
			file.close()
		else:
			for file in os.listdir(dirname):
				if file.split('.')[-1]=='r3cm':
					print 'WCZYTUJE:',file
					filename=dirname+os.sep+file
					dirname=Blender.sys.dirname(filename)
					basename=Blender.sys.basename(filename)
					file=open(filename,'rb')
					g=BinaryReader(file)
					r3cmParser(filename,g)
					file.close()
			#sexport3DPACK('x:\\argo\\modele\\'+basename)
			

	
 
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
	
Blender.Window.FileSelector(openFile,'import','r3cm - skinned mesh,r3cb - skeleton file, r3ce - animation file') 