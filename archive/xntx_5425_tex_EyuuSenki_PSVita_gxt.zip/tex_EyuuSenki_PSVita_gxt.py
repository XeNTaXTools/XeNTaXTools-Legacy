from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Eyuu Senki (PSVita)", ".gxt")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    Magic = bs.readBytes(3).decode("ASCII")
    if Magic != 'GXT':
        return 0
    return 1
	
def noepyLoadRGBA(data, texList):
    datasize = len(data) - 0x40        
    bs = NoeBitStream(data)
    bs.seek(0x37 , NOESEEK_ABS)         
    imgFmt = bs.readUByte()
    width = bs.readUShort()        
    height = bs.readUShort()
    if width > 4 and width <= 16:
        imgWidth = 16
    if height > 4 and height <= 16:
        imgHeight = 16
    if width > 16 and width <= 32:
        imgWidth = 32
    if height > 16 and height <= 32:
        imgHeight = 32
    if width > 32 and width <= 64:
        imgWidth = 64
    if height > 32 and height <= 64:
        imgHeight = 64
    if width > 64 and width <= 128:
        imgWidth = 128
    if height > 64 and height <= 128:
        imgHeight = 128
    if width > 128 and width <= 256:
        imgWidth = 256
    if height > 128 and height <= 256:
        imgHeight = 256
    if width > 256 and width <= 512:
        imgWidth = 512
    if height > 256 and height <= 512:
        imgHeight = 512
    if width > 512 and width <= 1024:
        imgWidth = 1024
    if height > 512 and height <= 1024:
        imgHeight = 1024
    if width > 1024 and width <= 2048:
        imgWidth = 2048
    if height > 1024 and height <= 2048:
        imgHeight = 2048
    if width > 2048 and width <= 4096:
        imgWidth = 4096
    if height > 2048 and height <= 4096:
        imgHeight = 4096
    bs.seek(0x40, NOESEEK_ABS)
    data = bs.readBytes(datasize)      
    if imgFmt == 0x85:
        data = rapi.imageFromMortonOrder(data, imgWidth>>1, imgHeight>>2, 4)
        data = rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_DXT1)
        texFmt = noesis.NOESISTEX_RGBA32
    #unknown, not handled
    else:
        print("WARNING: Unhandled image format")
        return None
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1