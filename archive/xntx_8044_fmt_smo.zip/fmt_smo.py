from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Winx Club PC", ".smo")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)
    
    noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    if noeAsciiFromBytes(bs.readBytes(4)) != 'FFPS':
        return 0
    return 1   
    
def noepyLoadModel(data, mdlList):
    bs = NoeBitStream(data)
    data = [bs.readInt() for x in range(8)]
    #0-FFPS; 1-unk; 2-unk; 3-FileSize; 4-numTx; 5-data_offset; 6-data-size; 7-Bones/SBOO;
    print(data)
    
    submesh_info = []
    #texture_info = []
    bones = []
    
    for x in range(data[7]):
        id = bs.readInt()
        name = noeAsciiFromBytes(bs.readBytes(bs.readUShort()))
        print(id,name)
        info = [bs.readInt() for x in range(3)]#0-type; 1-offset; 2-size;
        print(info)
        #mesh-868437232; texture-2028603435; bone-1767640933
        if info[0] == 868437232:
            submesh_info.append(info[1]+data[5])
            print("mesh", submesh_info[-1])
        if info[0] == 1767640933:
            bones.append(NoeBone(len(bones),name, NoeMat43()))#info[1]+data[5]
            print("bones", bones[-1])
        if info[0] == 2028603435:
            saveImage(bs, info[1]+data[5], info[2])
            #texture_info.append(info[1]+data[5])
            print("texture", info[1]+data[5], info[2])
    print(bs.getOffset())
    
    ctx = rapi.rpgCreateContext()
    
    for x in submesh_info:
        bs.seek(x+8)
        type_info = bs.readUByte()
        
        if type_info == 224:
            #0-size; 1-typeFace?; 2-numIndices; 3-zero?;
            info = [bs.readInt() for x in range(4)]
            face_size = (info[2]*3)*2 if info[1] == 2 else info[2]*2
            face_count = int(face_size/2)
        else:
        #0-size; 1-type; 2-numVert; 3-sizeVert?; 4-sizeFace; 5-typeFace?; 6-numInd; 7-zero;
            info = [bs.readInt() for x in range(5)]
            bs.readByte()
            info += [bs.readInt() for x in range(3)]
            face_size = info[4]
            face_count = int(face_size/2)
        #bs.seek(4 ,NOESEEK_REL)
        faces = bs.readBytes(face_size)
        
        #2430=56;2368=36;2304=24;2048=12
        stride = bs.readUInt()
        #0-stride; 1-norm_offset; 2-uv_offset;
        if stride == 2430:stride = [56,24,48]
        elif stride == 2368:stride = [36,12,24]
        elif stride == 2304:stride = [24,0,16]
        elif stride == 2048:stride = [12,0,0]
        else: stride = [12,0,0]
        vert_count = bs.readUInt()
        bs.seek(4 ,NOESEEK_REL)
        vertices = bs.readBytes(vert_count * stride[0])
    
        rapi.rpgSetName("Mesh_0")
        rapi.rpgBindPositionBufferOfs(vertices, noesis.RPGEODATA_FLOAT, stride[0], 0)
        if stride[1]>0:
            rapi.rpgBindNormalBufferOfs(vertices, noesis.RPGEODATA_FLOAT, stride[0], stride[1])
        if stride[2]>0:
            rapi.rpgBindUV1BufferOfs(vertices, noesis.RPGEODATA_FLOAT, stride[0], stride[2])
        rapi.rpgCommitTriangles(faces, noesis.RPGEODATA_USHORT, face_count, noesis.RPGEO_TRIANGLE_STRIP)
        rapi.rpgClearBufferBinds()
    
    mdl = rapi.rpgConstructModel()
    mdl.setModelMaterials(NoeModelMaterials([], [NoeMaterial("default","")]))
    mdl.setBones(bones)
    mdlList.append(mdl)
    return 1
    
def searchString(bs):
    bytes = []
    byte = None
    while byte != 0:
        byte = bs.readUByte()
        bytes.append(byte)
    return noeAsciiFromBytes(bytes)

def saveImage(bs, offset, Size):
    curPos = bs.getOffset()
    
    bs.seek(offset+36)
    Width = bs.readInt()
    Height = bs.readInt()
    bs.seek(17, NOESEEK_REL)
    TexFile = NoeBitStream()
    TexFile.writeBytes(b"\x42\x4D\x36\xFC\x03\x00\x00\x00\x00\x00\x36\x00\x00\x00\x28\x00\x00\x00")
    TexFile.writeUInt(Width)
    TexFile.writeUInt(Height)
    TexFile.writeBytes(b"\x01\x00\x20\x00\x00\x00\x00\x00")
    TexFile.writeUInt(Size-61)
    TexFile.writeBytes(b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00")
    pixelData = bs.readBytes(Size-61)
    TexFile.writeBytes(pixelData)
    outName = rapi.getInputName().replace(".smo", str(curPos)+".bmp")
    
    if not rapi.checkFileExists(outName):
        Tex = open(outName, "wb")
        Tex.write(TexFile.getBuffer())
        Tex.close()
    bs.seek(curPos)
    return 1
    
class SubMesh:
    def __init__(self, name, offset):
        self.name=name
        self.offset=offset
        
        