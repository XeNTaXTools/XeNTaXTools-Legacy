#Script Version 1.0
#Dead or Alive 5

from inc_noesis import *

import noesis

#rapi methods should only be used during handler callbacks
import rapi

#registerNoesisTypes is called by Noesis to allow the script to register formats.
#Do not implement this function in script files unless you want them to be dedicated format modules!
def registerNoesisTypes():
	handle = noesis.register("Dead Or Alive 5", ".tmc;.gmd")
	noesis.setHandlerTypeCheck(handle, tmcCheckType)
	noesis.setHandlerLoadModel(handle, tmcLoadModel)
	#noesis.setHandlerWriteModel(handle, noepyWriteModel)
	#noesis.setHandlerWriteAnim(handle, noepyWriteAnim)
	#oesis.logPopup()
	return 1

#check if it's this type based on the data

def tmcCheckType(data):
	bs = NoeBitStream(data)
	IdMagic = bs.readBytes(3).decode("ASCII")
	if IdMagic != "TMC":
		return 0
	return 1       

#load the model
def tmcLoadModel(data, mdlList):
	ctx = rapi.rpgCreateContext()
	bs = NoeBitStream(data)
	bs.setEndian(NOE_BIGENDIAN)
	rapi.rpgSetOption(noesis.RPGOPT_BIGENDIAN, 1)
	tmcArray = []
	ObjGeo = []
	LHeader = []
	LHeader2 = []
	VtxLay = []
	VtxLay2 = []
	IdxLay = []
	IdxLay2 = []
	texList = []
	matList = []
	texNameList = []

	if (rapi.checkFileExists(rapi.getExtensionlessName(rapi.getInputName()) + ".TMCL")):
		tmclData = rapi.loadIntoByteArray(rapi.getExtensionlessName(rapi.getInputName()) + ".TMCL")
		tmclData = NoeBitStream(tmclData)
		tmclData.setEndian(NOE_BIGENDIAN)
	tmcMagic = bs.readBytes(8).decode("ASCII").rstrip("\0")
	versionMajor = bs.readUShort()
	versionMinor = bs.readUShort()
	headerSize = bs.readUInt()
	tmcHeader = bs.read(">" + "I" * 13)
	bs.seek(0x50, NOESEEK_ABS)
	modelName = bs.readBytes(16).decode("ASCII").rstrip("\0")
	bs.seek(tmcHeader[4], NOESEEK_ABS)
	for i in range(0, tmcHeader[1]):
		tmcOffset = bs.readInt()
		if tmcOffset != 0:
			tmcArray.append(tmcOffset)
	for i in range(0, len(tmcArray)):
		#print(tmcArray[i])
		bs.seek(tmcArray[i], NOESEEK_ABS)
		chunkType = bs.read(">" + "Q")
		#print(chunkType[0])
		if chunkType[0] == 5576701292491767808:#"MdlGeo"
			bs.seek(8, NOESEEK_REL)
			MdlGeoSize = bs.readInt()
			MdlGeoSubCount = bs.readInt()
			MdlGeoSubCount2 = bs.readInt()
			Null = bs.readInt()
			ObjGeoOffset = bs.readInt()
			bs.seek(tmcArray[i] + ObjGeoOffset, NOESEEK_ABS)
			for a in range(0, MdlGeoSubCount):
				Offset = bs.readInt()
				ObjGeo.append(Offset + tmcArray[i])
		elif chunkType[0] == 6076578554252886016:#"TTX"
			bs.seek(8, NOESEEK_REL)
			ttxSize = bs.readInt()
			ttxSubCount = bs.readInt()
			ttxSubCount2 = bs.readInt()
			Null = bs.readInt()
			ttxOffset = bs.readInt()
			bs.seek(tmcArray[i] + ttxOffset, NOESEEK_ABS)
			xprStart = bs.readInt()
			bs.seek(tmcArray[i] + xprStart, NOESEEK_ABS)
			XPR2 = bs.readBytes(4).decode("ASCII")
			xpr2Count = 0
			xpr2Size = 0
			for a in range(0, ttxSubCount2):
				xpr2SecSize = bs.readInt()
				xpr2Size = bs.readInt()
				xpr2Base = bs.tell()
				xpr2Count = bs.readInt()
			xpr = []
			xprInfo = []
			for a in range(0, xpr2Count):
				xpr2Type = bs.readBytes(4).decode("ASCII")
				xpr2InfoOff = bs.readInt()
				xpr234 = bs.readInt()
				xpr2NameOff = bs.readInt()
				xpr.append([xpr2Type,xpr2InfoOff,xpr234,xpr2NameOff])
			offsetBase = 0
			for a in range(0, xpr2Count):
				bs.seek(xpr2Base + xpr[a][3], NOESEEK_ABS)
				texName = bs.readString()
				bs.seek(xpr2Base + xpr[a][1], NOESEEK_ABS)
				bs.seek(0x20, NOESEEK_REL)
				x1 = bs.readUByte()
				x2 = bs.readUShort()
				if a == 0:
					offsetBase = offsetBase + (x2 + (0x10000 * x1))
				offset = (((x2 + (0x10000 * x1)) - offsetBase) * 0x100)
				type = bs.readUByte()
				width = ((bs.readUShort() & 0xFF) + 1) * 8
				height = (bs.readUShort() & 0x7FF) + 1
				xprInfo.append([texName, offset, type, width, height])
			xprInfo.append([0, xpr2Size,0, 0, 0])
			for a in range(0, xpr2Count):
				texSize = (xprInfo[(a + 1)][1] - xprInfo[a][1])
				bs.seek(xpr2Base + xpr[a][3], NOESEEK_ABS)
				#print(xprInfo[a])
				tmclData.seek(0x1000 + xprInfo[a][1], NOESEEK_ABS)
				data = tmclData.readBytes(texSize)
				imgHeight = xprInfo[a][3]
				imgWidth  = xprInfo[a][4]
				texName = xprInfo[a][0]
				texName = texName.replace("dds/","")
				texName = rapi.getExtensionlessName(texName)
				texFmt = 0
				#DXT1
				if xprInfo[a][2] == 0x52:
					data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 8)
					texFmt = noesis.NOESISTEX_DXT1
				#DXT3
				elif xprInfo[a][2] == 0x53:
					data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 16)
					texFmt = noesis.NOESISTEX_DXT3
				#DXT5
				elif xprInfo[a][2] == 0x54:
					data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 16)
					texFmt = noesis.NOESISTEX_DXT5
				#DXT5 packed normal map
				elif xprInfo[a][2] == 0x71:
					data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 16)
					data = rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_ATI2)
					texFmt = noesis.NOESISTEX_RGBA32
				#DXT1 packed normal map
				elif xprInfo[a][2] == 0x7C:
					data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 8)
					data = rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_DXT1NORMAL)
					texFmt = noesis.NOESISTEX_RGBA32
				#raw
				elif xprInfo[a][2] == 0x86:
					data = rapi.imageUntile360Raw(data, imgWidth, imgHeight, 4)
					data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "a8r8g8b8")
					texFmt = noesis.NOESISTEX_RGBA32
				#unknown, not handled
				else:
					print("WARNING: Unhandled image format " + repr(imgFmt) + " - " + repr(imgWidth) + "x" + repr(imgHeight) + " - " + repr(len(data)))
					return None
				tex1 = NoeTexture(texName, imgWidth, imgHeight, data, texFmt)
				texList.append(tex1)
				texNameList.append(texName)

		elif chunkType[0] == 6229736454008406016:#"VtxLay"
			bs.seek(8, NOESEEK_REL)
			VtxLaySize = bs.readInt()
			VtxLaySubCount = bs.readInt()
			VtxLaySubCount2 = bs.readInt()
			Null = bs.readInt()
			VtxLayOffset = bs.readInt()
			VtxLayOffset2 = bs.readInt()
			bs.seek(tmcArray[i] + VtxLayOffset, NOESEEK_ABS)
			for a in range(0, VtxLaySubCount):
				tmp = bs.readInt()
				VtxLay.append(tmp)
			bs.seek(tmcArray[i] + VtxLayOffset2, NOESEEK_ABS)
			for a in range(0, VtxLaySubCount):
				tmp = bs.readInt()
				VtxLay2.append(tmp)
		elif chunkType[0] == 5288484131887972352:#"IdxLay"
			bs.seek(8, NOESEEK_REL)
			IdxLaySize = bs.readInt()
			IdxLaySubCount = bs.readInt()
			IdxLaySubCount2 = bs.readInt()
			Null = bs.readInt()
			IdxLayOffset = bs.readInt()
			IdxLayOffset2 = bs.readInt()
			bs.seek(tmcArray[i] + IdxLayOffset, NOESEEK_ABS)
			for a in range(0, IdxLaySubCount):
				tmp = bs.readInt()
				IdxLay.append(tmp)
			bs.seek(tmcArray[i] + IdxLayOffset2, NOESEEK_ABS)
			for a in range(0, IdxLaySubCount):
				tmp = bs.readInt()
				IdxLay2.append(tmp)
		elif chunkType[0] == 5581211472176611328:#"MtrCol"
			bs.seek(8, NOESEEK_REL)
		elif chunkType[0] == 5576701301232135936:#"MdlInfo"
			bs.seek(8, NOESEEK_REL)
		elif chunkType[0] == 5217813022012669952:#"HieLay"
			bs.seek(8, NOESEEK_REL)
		elif chunkType[0] == 5496754814176293376:#"LHeader"
			bs.seek(8, NOESEEK_REL)
			LHeaderSize = bs.readInt()
			LHeaderSubCount = bs.readInt()
			LHeaderSubCount2 = bs.readInt()
			Null = bs.readInt()
			LHeaderOffset = bs.readInt()
			LHeaderOffset2 = bs.readInt()
			bs.seek(tmcArray[i] + LHeaderOffset, NOESEEK_ABS)
			for a in range(0, LHeaderSubCount):
				LH = bs.readInt()
				LHeader.append(LH)
			bs.seek(tmcArray[i] + LHeaderOffset2, NOESEEK_ABS)
			for a in range(0, LHeaderSubCount):
				LH = bs.readInt()
				LHeader2.append(LH)
		elif chunkType[0] == 5651846443609192704:#"NodeLay"
			bs.seek(8, NOESEEK_REL)
		elif chunkType[0] == 5146596691473102848:#"GlblMtx"
			bs.seek(8, NOESEEK_REL)
		elif chunkType[0] == 4786850755381130360:#"BnOfsMtx"
			bs.seek(8, NOESEEK_REL)
		elif chunkType[0] == 7165339157332492288:#"cpf"
			bs.seek(8, NOESEEK_REL)
		elif chunkType[0] == 5567365377308183296:#"MCAPACK"
			bs.seek(8, NOESEEK_REL)
		elif chunkType[0] == 5928230591102405376:#"RENPACK"
			bs.seek(8, NOESEEK_REL)
		elif chunkType[0] == 4702693984413351936:#"ACSCLS"
			bs.seek(8, NOESEEK_REL)
		else:
			pass
	meshes = []
	for i in range(0, len(ObjGeo)):
		ObjGeoSub = []
		ObjGeoOff = []
		ObjGeoMat = []
		VertSize = []
		fvfTable = []
		bs.seek(ObjGeo[i] + 0x10, NOESEEK_ABS)
		ObjGeoSize = bs.readInt()
		ObjGeoSubCount = bs.readInt()
		ObjGeoSubCount2 = bs.readInt()
		Null = bs.readInt()
		ObjGeoOffset = bs.readInt()
		Null = bs.readInt()
		ObjGeoOffset2 = bs.readInt()
		bs.seek(ObjGeo[i] + 0x50, NOESEEK_ABS)
		ObjGeoName = bs.readBytes(16).decode("ASCII").rstrip("\0")
		bs.seek(ObjGeo[i] + ObjGeoOffset, NOESEEK_ABS)
		for a in range(0, ObjGeoSubCount):
			tmp = bs.readInt()
			ObjGeoOff.append(tmp + ObjGeo[i])
		for a in range(0, ObjGeoSubCount):
			bs.seek(ObjGeoOff[a], NOESEEK_ABS)
			#print(bs.tell())
			bs.seek(0xC, NOESEEK_REL)
			matTexCount = bs.readInt()
			bs.seek(0x28, NOESEEK_REL)
			meshIndex = bs.readInt()
			bs.seek(0x34, NOESEEK_REL)
			vertStart = bs.readInt()
			vertCount = bs.readInt()
			faceStart = bs.readInt()
			faceCount = bs.readInt()
			ObjGeoMat.append([meshIndex,vertStart,vertCount,faceStart,faceCount])
			matName = ObjGeoName + "_" + str(a)
			#print(matName)
			bs.seek(0x50, NOESEEK_REL)
			material = NoeMaterial(matName, "")
			for b in range(0, matTexCount):
				texSlot = bs.readInt()
				texUnkown = bs.readInt()
				texId = bs.readInt()
				if texSlot == 0:
					material.setTexture(texNameList[texId])
					material.setDiffuseColor(NoeVec4([1.0, 1.0, 1.0, 0.0]))
					material.setDefaultBlend(0)
				elif texSlot == 1:
					if texUnkown == 0:
						material.setDefaultBlend(0)
					else:
						material.setSpecularTexture(texNameList[texId])
				elif texSlot == 2:
					if texUnkown == 1:
						material.setNormalTexture(texNameList[texId])
				elif texSlot == 3:
					material.setNormalTexture("")
				bs.seek(0x64, NOESEEK_REL)
			matList.append(material)
		#print("Here")
		#print(ObjGeoMat)
		bs.seek(ObjGeo[i] + ObjGeoOffset2, NOESEEK_ABS)
		GeoDeclStart = bs.tell()
		bs.seek(0x14, NOESEEK_REL)
		GeoDeclSubCount = bs.readInt()
		GeoDeclSubCount2 = bs.readInt()
		Null = bs.readInt()
		GeoDeclOffset = bs.readInt()
		bs.seek(GeoDeclStart + GeoDeclOffset, NOESEEK_ABS)
		GeoDecl = []
		for a in range(0, GeoDeclSubCount):
			tmp = bs.readInt()
			GeoDecl.append(tmp)
		for a in range(0, GeoDeclSubCount):
			bs.seek(GeoDeclStart + GeoDecl[a], NOESEEK_ABS)
			bs.seek(0xC, NOESEEK_REL)
			fvfId = bs.readInt()
			faceCount = bs.readInt()
			vertCount = bs.readInt()
			bs.seek(0x1C, NOESEEK_REL)
			vSize = bs.readInt()
			fvfCount = bs.readInt()
			null = bs.readInt()
			VertSize.append([fvfId,faceCount,vertCount,vSize])
			fvfTmp = []
			for b in range(0, fvfCount):
				fvf1 = bs.readInt()
				fvf2 = bs.readInt()
				fvf3 = bs.readInt()
				fvfTmp.append([fvf1,fvf2,fvf3])
			fvfTable.append(fvfTmp)
		#print(fvfTable)
		#print(VertSize)
		for a in range(0, ObjGeoSubCount):
			idxList = []
			posList = []
			uvList = []
			uvList2 = []
			meshName = ObjGeoName + "_" + str(a)
			vsize = VertSize[ObjGeoMat[a][0]][3]
			vindex = VertSize[ObjGeoMat[a][0]][0]
			fvftmp = fvfTable[ObjGeoMat[a][0]]
			vbase = VtxLay[vindex]
			tmclData.seek(LHeader[1] + vbase + (vsize * ObjGeoMat[a][3]), NOESEEK_ABS)
			vpos = tmclData.tell()
			for j in range(0, ObjGeoMat[a][4]):
				for b in range(0, len(fvftmp)):
					tmclData.seek(vpos + (j * vsize) + fvftmp[b][0],NOESEEK_ABS)
					if fvftmp[b][2] == 0:
						vx = tmclData.readFloat()
						vy = tmclData.readFloat()
						vz = tmclData.readFloat()
						posList.append(NoeVec3 ((vx, vy, vz)))
					elif fvftmp[b][2] == 327680:
						tu = tmclData.readHalfFloat()
						tv = tmclData.readHalfFloat()
						uvList.append(NoeVec3 ((tu, tv , 0)))
					elif fvftmp[b][2] == 327936:
						tu = tmclData.readHalfFloat()
						tv = tmclData.readHalfFloat()
						uvList2.append(NoeVec3 ((tu, tv , 0)))
			fbase = IdxLay[vindex]
			tmclData.seek(LHeader[2] + fbase + (2 * ObjGeoMat[a][1]), NOESEEK_ABS)
			fstart = tmclData.tell()
			StartDirection = -1
			f1 = tmclData.readUShort() - ObjGeoMat[a][3]
			f2 = tmclData.readUShort() - ObjGeoMat[a][3]
			FaceDirection = StartDirection
			while tmclData.tell() < (fstart + (2 * ObjGeoMat[a][2]) ):
				f3 = tmclData.readUShort()
				if f3 == 0xFFFF:
					f1 = tmclData.readUShort() - ObjGeoMat[a][3]
					f2 = tmclData.readUShort() - ObjGeoMat[a][3]
					FaceDirection = StartDirection   
				else:
					f3 -= ObjGeoMat[a][3]
					FaceDirection *= -1
					
					if (f1 != f2 and f1 != f3 and f3 != f2) : 
						if FaceDirection > 0:
							idxList.append(f1)
							idxList.append(f2)
							idxList.append(f3)
						else:
							idxList.append(f1)
							idxList.append(f3)
							idxList.append(f2)
					f1 = f2
					f2 = f3

			mesh = NoeMesh(idxList, posList, meshName, meshName)
			mesh.uvs = uvList
			mesh.lmUVs = uvList2
			meshes.append(mesh)

	mdl = NoeModel(meshes)
	mdl.setModelMaterials(NoeModelMaterials(texList, matList))
	mdlList.append(mdl)
	rapi.rpgClearBufferBinds()	
	return 1

