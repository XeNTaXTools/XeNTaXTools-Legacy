import os
import struct
import sys

dropped_file = sys.argv[1]
def main():
    infile = open(dropped_file, "rb")
    # find the starting point of the model, maybe the data wasn't unpacked properly
    contents = infile.read()
    start = contents.find(b'\x4b\x54\x4d\x44\x4c')
    if start == -1:
        print("ERROR: Not a KTMDL model file")
        return

    # assume little endian first
    byte_ordering = "Little Endian"
    format_string = "<I"
    
    infile.seek(start + 0x28)
    section_count_bytes = infile.read(4)
    section_count = struct.unpack(format_string, section_count_bytes )[0]
    if section_count > 100:
        # too many sections? definitely wrong, so big endian
        byte_ordering = "Big Endian"
        format_string = ">I"
        section_count = struct.unpack(format_string, section_count_bytes )[0]

    infile.seek(start + 0x34)
    pointer_bytes = infile.read(4) # or is it the header size?
    pointer = struct.unpack(format_string, pointer_bytes)[0]
    infile.seek(start + pointer)
    print("\n" + os.path.basename(dropped_file))
    print("-------------")
    print(byte_ordering)
    print("-------------")

    for x in range(section_count):
        v_offset_bytes = infile.read(4)
        v_count_bytes = infile.read(4)
        infile.read(1)
        fvf_size_byte = infile.read(1)
        infile.read(22)
        f_offset_bytes = infile.read(4)
        f_count_bytes = infile.read(4)
        
        v_offset = struct.unpack(format_string, v_offset_bytes)[0] + start
        v_count = struct.unpack(format_string, v_count_bytes)[0]
        fvf_size = struct.unpack("b", fvf_size_byte)[0]
        diff = fvf_size - (fvf_size % 16)
        if (diff == fvf_size):
            uv_position = fvf_size - 16
        else:
            uv_position = diff
        f_offset = struct.unpack(format_string, f_offset_bytes)[0] + start
        f_count = struct.unpack(format_string, f_count_bytes)[0]
        
        print("Section " + str(x))
        print("Face Indices: (Short, Strip)")
        print("  Offset           :" + str(hex(f_offset + pointer + 32 + (64 * x))))
        print("  Count            :" + str(f_count))
        print("Vertex Block:")
        print("  FVF Size         :" + str(fvf_size))
        print("  UV Position      :" + str(uv_position))
        print("Vertices:")
        print("  Offset           :" + str(hex(v_offset + pointer + (64 * x))))
        print("  Count            :" + str(v_count))
        print("FOR MODEL RESEARCHER:")
        print("  Vertices Padding :" + str(fvf_size - 12))
        print("  UVs Offset       :" + str(hex(v_offset + pointer + (64 * x) + uv_position)))
        print("  UVs Count        :" + str(v_count))
        print("  UVs Padding      :" + str(uv_position))
        if (fvf_size - uv_position) >= 8:
            print("  UVs Type         :Float")
        else:
            print("  UVs Type         :Half Float (probably)")
            
        print("\n")


main()
input("\nPress Enter to continue.")