from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Star Wars TCW Republic Heroes [PC]", ".tex")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    bs.seek(len(data) - 0x30, NOESEEK_ABS)
    Magic = bs.readBytes(4).decode("ASCII")
    if Magic != "MTPC":
        return 0
    return 1   

def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.seek(len(data) - 0x2C, NOESEEK_ABS)
    imgWidth = bs.readShort()
    imgHeight = bs.readShort()
    bs.seek(0x03, NOESEEK_REL)
    imgFmt = bs.readByte()              
    bs.seek(0)        
    #DXT1 diffuse and yellow normal maps
    if imgFmt == 0x09:
        texFmt = noesis.NOESISTEX_DXT1
   	#DXT5 diffuse maps
    elif imgFmt == 0x08:
        texFmt = noesis.NOESISTEX_DXT5
	#blue normal maps
    elif imgFmt == 0x20:
        data = rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_ATI2)
        texFmt = noesis.NOESISTEX_RGBA32
    #light maps
    elif imgFmt == 0x01:
        data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "r8 g8 b8 a8")
        texFmt = noesis.NOESISTEX_RGBA32
	#unknown, not handled
    else:
        print("WARNING: Unhandled image format")
        return None
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1