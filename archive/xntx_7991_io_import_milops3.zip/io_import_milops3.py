bl_info = {
    "name": "Import test for milo_ps3",
    "author": "Turk",
    "version": (1, 0, 2),
    "blender": (2, 79, 0),
    "location": "File > Import-Export",
    "description": "test",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
    "category": "Import-Export"}

import bpy
import zlib
import bmesh
import os
import io
import struct
import math
import mathutils
import numpy as np
from bpy.props import (BoolProperty,
                       FloatProperty,
                       StringProperty,
                       EnumProperty,
                       CollectionProperty
                       )
from bpy_extras.io_utils import ImportHelper
                       
                       
class MiloPs3Import(bpy.types.Operator, ImportHelper):
    bl_idname = "import_scene.milops3"
    bl_label = "Import"
    bl_options = {'PRESET', 'UNDO'}
    
    filter_glob = StringProperty(
            default="*.milo_ps3",
            options={'HIDDEN'},
            )
 
    filepath = StringProperty(subtype='FILE_PATH',)
    files = CollectionProperty(type=bpy.types.PropertyGroup)
    
    skip_low_lod_setting = BoolProperty(
        name="Skip Low LOD",
        description="Skip loading of lower LOD meshes",
        default=True,
        )
    extract_textures_setting = BoolProperty(
        name="Extract Textures",
        description="Extract the raw textures into the same folder as the mesh on load",
        default=False,
        )
        
    def draw(self, context):
        layout = self.layout
        layout.prop(self, "skip_low_lod_setting")
        layout.prop(self, "extract_textures_setting")
    def execute(self, context):
        CurFile = open(self.filepath,"rb")
        CurFile.seek(4)
        DataStartOffset = int.from_bytes(CurFile.read(4),byteorder='little')
        DataCount = int.from_bytes(CurFile.read(4),byteorder='little')
        CurFile.seek(4,1)
        sizeList = []
        tmpFile = bytes()
        for x in range(DataCount):
            sizeList.append(int.from_bytes(CurFile.read(4),byteorder='little'))
        CurFile.seek(DataStartOffset)
        for x in range(DataCount):
            tmpFile += zlib.decompress(CurFile.read(sizeList[x]),-15)
        CurFile.close()
        del CurFile
        
        tmpFile = io.BytesIO(tmpFile)
        tmpFile.seek(4)
        tmp = int.from_bytes(tmpFile.read(4),byteorder='big')
        tmpFile.seek(tmp,1)
        tmp = int.from_bytes(tmpFile.read(4),byteorder='big')
        tmpFile.seek(tmp+8,1)
        FileCount = int.from_bytes(tmpFile.read(4),byteorder='big')
        FileList = []
        for x in range(FileCount):
            tmp = int.from_bytes(tmpFile.read(4),byteorder='big')
            Type = tmpFile.read(tmp).decode('utf-8')
            tmp = int.from_bytes(tmpFile.read(4),byteorder='big')
            Name = tmpFile.read(tmp).decode('utf-8')
            FileList.append((Type,Name))
        tmpFile.seek(0)
        tmpRead = tmpFile.read()
        # tmp = 0
        # FileOffset = []
        # for x in range(FileCount+1):
            # tmp = tmpRead.find(b'\xad\xde\xad\xde',tmp)+4
            # FileOffset.append(tmp)
            
        tmp = 0
        FileOffset = []
        while tmp != -1:
            tmp = tmpRead.find(b'\xad\xde\xad\xde',tmp+4)
            FileOffset.append(tmp+4)
            
        for x in range(len(FileOffset)):
            tmpFile.seek(FileOffset[x])
            tmp = tmpFile.read(8)
            if tmp == b'\x00\x00\x00\x24\x00\x00\x00\x02':
                parseMesh(self,tmpFile,FileOffset[x])
            elif tmp == b'\x00\x00\x00\x0A\x00\x00\x00\x02':
                export_image(self,tmpFile,FileOffset[x],FileOffset[x+1]-4)
        # for x in range(FileCount):
            # FileType = FileList[x][0]
            # if FileType == "Mesh":
                # parseMesh(self,tmpFile,FileOffset[x])
            # elif FileType == "Tex":
                # if self.extract_textures_setting:
                    # export_image(self,tmpFile,FileOffset[x],FileOffset[x+1]-4)
                    
        # tstFile = open("C:\\Users\\Turk\\Desktop\\New folder\\Output","wb+")
        # tmpFile.seek(0)
        # tstFile.write(tmpFile.read())
        # tstFile.close()
        # del tstFile
        
        del tmpFile
        return {'FINISHED'}

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

def export_image(self,CurFile,FileStart,FileEnd):
    CurFile.seek(FileStart+0x1D)
    tmp = int.from_bytes(CurFile.read(4),byteorder='big')
    textureName = CurFile.read(tmp).decode('utf-8')
    textureName = textureName.strip("../")
    textureName = textureName.replace("/","_")
    if len(textureName) == 0:
        return
    #print(textureName)
    DataStart = CurFile.seek(0x29,1)
    tmpOutput = CurFile.read(FileEnd-DataStart)
    File = open(os.path.splitext(self.filepath)[0]+textureName,"wb+")
    File.write(tmpOutput)
    File.close()
    del File
    return
    
def parseMesh(self,CurFile,MeshStart):
    CurFile.seek(MeshStart+0x15)
    Scale = CurFile.read(4)
    CurFile.seek(MeshStart+0x25)
    Scale += CurFile.read(4)
    CurFile.seek(MeshStart+0x35)
    Scale += CurFile.read(4)
    Scale = struct.unpack('>fff',Scale)
    CurFile.seek(MeshStart+0x69)
    Pos = struct.unpack('>fff', CurFile.read(4*3))
    
    CurFile.seek(MeshStart+0x7e)
    tmp = int.from_bytes(CurFile.read(4),byteorder='big')
    CurFile.seek(tmp+0x19,1)
    tmp = int.from_bytes(CurFile.read(4),byteorder='big')
    MatName = CurFile.read(tmp).decode('utf-8')
    tmp = int.from_bytes(CurFile.read(4),byteorder='big')
    MeshName = CurFile.read(tmp).decode('utf-8')
    if self.skip_low_lod_setting:
        if (MeshName.find("lod01") > -1) or (MeshName.find("lod02") >-1):
            return
    CurFile.seek(0x9,1)
    VertCount = int.from_bytes(CurFile.read(4),byteorder='big')
    CurFile.seek(1,1)
    VertSize = int.from_bytes(CurFile.read(4),byteorder='big')
    VertStart = CurFile.seek(4,1)
    CurFile.seek(VertSize*VertCount+VertStart)
    FaceCount = int.from_bytes(CurFile.read(4),byteorder='big')
    FaceStart = CurFile.tell()
    
    VertTable = []
    UVTable = []
    FaceTable = []
    if VertSize == 0x24:
        for x in range(VertCount):
            CurFile.seek(VertStart+x*VertSize)
            tmpVert = struct.unpack('>fff', CurFile.read(4*3))
            TempUV = (np.fromstring(CurFile.read(2), dtype='>f2'),1-np.fromstring(CurFile.read(2), dtype='>f2'))
            VertTable.append(tmpVert)
            UVTable.append(TempUV)
    else:
        for x in range(VertCount):
            CurFile.seek(VertStart+x*VertSize)
            tmpVert = struct.unpack('>fff', CurFile.read(4*3))
            VertTable.append(tmpVert)
            TempUV = (np.fromstring(CurFile.read(2), dtype='>f2'),1-np.fromstring(CurFile.read(2), dtype='>f2'))
            UVTable.append(TempUV)
    CurFile.seek(FaceStart)
    for x in range(FaceCount):
        FaceTable.append(struct.unpack('>HHH', CurFile.read(2*3)))
        
    #lets build a mesh
    mesh1 = bpy.data.meshes.new("mesh")
    mesh1.use_auto_smooth = True
    obj = bpy.data.objects.new(MeshName, mesh1)
    scene = bpy.context.scene
    scene.objects.link(obj)
    scene.objects.active = obj
    obj.select = True 
    mesh = bpy.context.object.data
    bm = bmesh.new()
    
    for v in VertTable:
        bm.verts.new((v[0],v[1],v[2]))
    list = [v for v in bm.verts]
    
    for f in FaceTable:
        try:
            bm.faces.new((list[f[0]],list[f[1]],list[f[2]]))
        except:
            continue
    bm.to_mesh(mesh)
    
    uv_layer = bm.loops.layers.uv.verify()
    bm.faces.layers.tex.verify()
    for f in bm.faces:
        f.smooth=True
        for l in f.loops:
            luv = l[uv_layer]
            try:
                luv.uv = UVTable[l.vert.index]
            except:
                continue
    bm.to_mesh(mesh)
    
    bm.free()
    
    obj.scale = Scale
    obj.location = Pos
        
    return
    
def select_all(select):
    if select:
        actionString = 'SELECT'
    else:
        actionString = 'DESELECT'

    if bpy.ops.object.select_all.poll():
        bpy.ops.object.select_all(action=actionString)

    if bpy.ops.mesh.select_all.poll():
        bpy.ops.mesh.select_all(action=actionString)

    if bpy.ops.pose.select_all.poll():
        bpy.ops.pose.select_all(action=actionString)

def utils_set_mode(mode):
    if bpy.ops.object.mode_set.poll():
        bpy.ops.object.mode_set(mode=mode, toggle=False)

def menu_func_import(self, context):
    self.layout.operator(MiloPs3Import.bl_idname, text="(.Milo_Ps3)")

def register():
    bpy.utils.register_class(MiloPs3Import)
    bpy.types.INFO_MT_file_import.append(menu_func_import)


def unregister():
    bpy.utils.unregister_class(MiloPs3Import)
    bpy.types.INFO_MT_file_import.remove(menu_func_import)
       
if __name__ == "__main__":
    register()