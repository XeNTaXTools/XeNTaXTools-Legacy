import newGameLib
from newGameLib import *
import Blender	


	
		

def section8(g):
	count=g.i(1)[0]
	for m in range(count):
		A=g.i(14)
		g1m.meshInfoList.append(A)
		txt.write(' '*16+str(m)+':'+'meshinfo:'+str(A)+'\n')

		
def section7(g):
	count=g.i(1)[0]
	for m in range(count):
		stream=Stream()
		v=g.i(3)
		stream.elementCount=v[0]
		if v[1]==16:
			stream.strideSize=2
		elif v[1]==32:
			stream.strideSize=4
		else:
			print 'WARNING: nieznany rozmiar indice',v[1]   
		stream.offset=g.tell()  
		g.seek(stream.elementCount*stream.strideSize,1) 
		g1m.indiceStreamList.append(stream)
		txt.write(' '*16+'Indicestream:'+str(m)+' indice count:'+str(stream.elementCount)+'\n')

def section6(g):
	count=g.i(1)[0]
	for m in range(count):
		List=[]
		txt.write(' '*16+'offset:'+str(g.tell())+' '+str(m)+' bone map list:'+'\n')
		for n in range(g.i(1)[0]):
			t=g.tell()
			A=g.i(1)[0]
			#List.append(str(g.i(1)[0]))
			B=g.f(1)[0]
			C=g.H(2)
			List.append(str(C[0]))
			txt.write(' '*20+str(n)+':'+str(A)+' '+str(B)+' '+str(C)+'\n')
		g1m.boneMapList.append(List)	
	
class Stride:
	def __init__(self):
		self.count=None 
		self.list=[]
	
class VertElement:
	def __init__(self):
		self.streamID=None
		self.offset=None
		self.unk0=None
		self.unk1=None
		self.unk2=None
		self.unk3=None

def section5(g):
	count=g.i(1)[0]
	for m in range(count):
		txt.write(' '*16+str(m)+':'+'\n')
		streamList=g.i(g.i(1)[0])	
		txt.write(' '*20+'stream id list:'+str(streamList)+'\n')	
		stride=Stride() 
		count=g.i(1)[0]
		stride.count=count
		txt.write(' '*20+'vert element count:'+str(count)+'\n')
		for n in range(count):
			element=VertElement()
			element.streamID=streamList[g.H(1)[0]]
			element.offset=g.H(1)[0]
			element.unk0=g.b(1)[0]
			element.unk1=g.b(1)[0]
			element.unk2=g.b(1)[0]
			element.unk3=g.b(1)[0]
			stride.list.append(element)
			txt.write(' '*24+str(element.streamID)+':'+str(element.offset)+':'+str(element.unk0)+':'+str(element.unk1)+':'+str(element.unk2)+':'+str(element.unk3)+'\n')
		g1m.strideList.append(stride)
			
	
	
class Stream:
	def __init__(self):
		self.unk0=None
		self.strideSize=None
		self.elementCount=None
		self.unk1=None
		self.offset=None


def section4(g):
	count=g.i(1)[0]
	for m in range(count):
		stream=Stream()
		stream.unk0=g.i(1)[0]
		stream.strideSize=g.i(1)[0]
		stream.elementCount=g.i(1)[0]
		stream.unk1=g.i(1)[0]
		stream.offset=g.tell()
		g1m.vertStreamList.append(stream)
		g.seek(stream.elementCount*stream.strideSize,1)	
		txt.write(' '*16+str(m)+':'+'VERTSTREAM:'+'vert count:'+str(stream.elementCount)+' vert size:'+str(stream.strideSize)+'\n')

def section3(g):
	#g.debug=True
	g.tell()
	for n in range(g.i(1)[0]):
		#print 
		txt.write(' '*16+str(n)+':'+'\n')
		for m in range(g.i(1)[0]):
			t=g.tell()
			w=g.i(3)
			v=g.h(2)
			A=g.word(w[1])
			B=g.f(v[0])
			txt.write(' '*20+str(m)+':'+'offset:'+str(t)+' '+str(w)+str(v)+str(A)+str(B)+'\n')
			
	g.tell()	
	#print ghghgh	
	
	
def section2(g):
	count=g.i(1)[0]
	for m in range(count):
		w=g.i(4)
		mat=Mat()
		List=[]
		txt.write(' '*16+'material:'+str(m)+' '+str(w)+'\n')
		for n in range(w[1]):
			List.append(g.b(12))
			txt.write(' '*20+str(n)+' '+str(List[-1])+'\n')
			if n==0:
				mat.diffuse=g.dirname+os.sep+'textures'+os.sep+'1540_'+str(List[n][0])+'.dds'
				print m,mat.diffuse	
		#g1m.matList.append(mat)
		g1m.textureList.append(List)

	
def section1(g):
	count=g.i(1)[0]
	for m in range(count):
		data=g.b(4)+g.f(7)+g.b(4)+g.f(7)
		#print data
		txt.write(' '*16+str(data)+'\n')

def G1MGParser(g):
	chunk=g.word(4)
	A=g.f(7)
	count=g.i(1)[0]
	txt.write(' '*8+chunk+' '+str(A)+' '+str(count)+'\n')
	for k in range(count):
		t=g.tell()
		v=g.H(2)	
		size=g.i(1)[0]
		print k,v
		txt.write(' '*12+str(k)+' '+str(v)+'\n')
		if v[0]==1:
			section1(g)
		if v[0]==2:
			section2(g)
		#if v[0]==3:
		#	section3(g)
		if v[0]==4:
			section4(g)
		if v[0]==5:
			section5(g)
		if v[0]==6:
			section6(g)
		if v[0]==7:
			section7(g)
		if v[0]==8:
			section8(g)
		g.seek(t+size)	
	
class G1M:
	def __init__(self):
		self.meshCount=None 	
		self.boneMapList=[]
		self.meshList=[]
		self.matList=[]
		self.strideList=[]
		self.vertStreamList=[]
		self.indiceStreamList=[]
		self.meshInfoList=[]
		self.textureList=[]
		
		

def G1MSParser(back,g):
	offset=g.i(1)[0]
	w=g.H(6)
	#print offset,w,g.tell()
	#g.H(w[4])
	#g.H(2)
	#if w[0]!=0:
	g.seek(back+offset)
	#skeleton.DEL=False
	#print 'boneCount:',w[2]
	if w[2]==w[3]:
		for m in range(w[2]):
			bone=Bone()
			bone.name=str(m)
			g.f(3)
			bone.parentID=g.i(1)[0]
			#print m,bone.parentID
			#print g.f(1)
			w=g.f(4)
			bone.rotMatrix=Quaternion(w[3],w[0],w[1],w[2]).toMatrix().resize4x4()
			bone.posMatrix=TranslationMatrix(Vector(g.f(4)))
			g1m.skeleton.boneList.append(bone)
		g.tell()
		
		
		
def G1M_Parser(offset,filename,g):
	global g1m	
	

	g1m=G1M()
	g1mList.append(g1m)

	g1m.skeleton=Skeleton()
	g1m.skeleton.BONESPACE=True
	g1m.skeleton.NICE=True

	A=g.i(4)		
	g.seek(offset+A[1])
	for m in range(A[3]):
		start=g.tell()
		chunk=g.word(8)
		size=g.i(1)[0]
		#print chunk
		txt.write(' '*4+chunk+' '+'offset:'+str(start)+' size:'+str(size)+'\n')
		#if chunk=='G1MG0044':G1MGParser(g)
		if chunk=='GM1G4400':
			G1MGParser(g)
		#if chunk=='G1MF0023':
		if chunk=='FM1G3200':
				t=g.tell()
				w=g.i(36)
				g1m.meshCount=w[11]
				txt.write(' '*8+str(t)+' '+str(w)+'\n')
		#if chunk=='G1MS0032':
		if chunk=='SM1G2300':
		    G1MSParser(start,g)
		if chunk=='ONUN4200xxxx':
			#g.debug=True
			A=g.i(10)+g.f(2)+g.i(1)+g.f(9)+g.i(1)+g.f(6)
			txt.write(' '*4+str(A)+'\n')
			mesh=Mesh()
			for n in range(99):
				B=g.f(4)
				txt.write(' '*4+str(n)+':'+str(B)+'\n')
				mesh.vertPosList.append(B[:3])
			mesh.draw()	
			txt.write(' '*4+str(g.tell())+'\n')	
			for n in range(99):
				txt.write(str(n)+':'+str(g.i(4)+g.f(2))+'\n')
			txt.write(str(g.tell())+'\n')	
			clothSkeleton=Skeleton()	
			clothSkeleton.ARMATURESPACE=True
			clothSkeleton.NICE=True
			for n in range(9):
				bone=Bone()
				bone.name=str(n)
				clothSkeleton.boneList.append(bone)
				B=g.f(3)
				bone.posMatrix=VectorMatrix(B)
				C=g.f(4)
				bone.rotMatrix=QuatMatrix(C).resize4x4()
				txt.write(' '*4+str(n)+':'+str(B+C+g.i(5))+'\n')
			clothSkeleton.draw()	
			txt.write(str(g.tell())+'\n')
			
			txt.write(' '*4+str(n)+':'+str(g.f(0)+g.i(20))+'\n')
			txt.write(' '*4+str(g.tell())+'\n')	
			
			
			A=g.i(10)+g.f(2)+g.i(1)+g.f(9)+g.i(1)+g.f(2)
			txt.write(' '*4+str(A)+'\n')
			mesh=Mesh()
			for n in range(12):
				B=g.f(4)
				txt.write(' '*4+str(n)+':'+str(B)+'\n')
				mesh.vertPosList.append(B[:3])
			mesh.draw()	
			txt.write(' '*4+str(g.tell())+'\n')	
			for n in range(12):
				txt.write(' '*4+str(n)+':'+str(g.i(4)+g.f(2))+'\n')
			txt.write(' '*4+str(g.tell())+'\n')		
			for n in range(3):
				txt.write(' '*4+str(n)+':'+str(g.f(8)+g.i(4))+'\n')
			txt.write(' '*4+str(g.tell())+'\n')
			
			txt.write(' '*4+str(n)+':'+str(g.f(0)+g.i(20))+'\n')
			txt.write(' '*4+str(g.tell())+'\n')	
			
			
			#g.debug=False
			break
			
		if chunk=='LLOC2100xxxx':
			A=g.i(6)
			txt.write(' '*4+str(A)+'\n')
			for m in range(6):
				A=g.i(4)
				txt.write(' '*4+str(m)+':'+str(A)+'\n')
				A=g.f(4)
				txt.write(' '*4+str(m)+':'+str(A)+'\n')
				A=g.f(4)
				txt.write(' '*4+str(m)+':'+str(A)+'\n')
				A=g.f(4)
				txt.write(' '*4+str(m)+':'+str(A)+'\n')
				A=g.f(4)
				txt.write(' '*4+str(m)+':'+str(A)+'\n')
			txt.write(' '*4+str(g.tell())+'\n')	
		g.seek(start+size)
		
		
def FM1G_Parser(offset,filename,g):
	

	A=g.i(4)		
	g.seek(offset+A[1])
	for m in range(A[3]):
		start=g.tell()
		chunk=g.word(8)
		size=g.i(1)[0]
		#print chunk
		txt.write(' '*4+chunk+'\n')
		#if chunk=='G1MG0044':G1MGParser(g)
		#if chunk=='GM1G4400':G1MGParser(g)
		#if chunk=='G1MF0023':
		if chunk=='FM1G3200':
				t=g.tell()
				w=g.i(36)
				#print w
				g1m.meshCount=w[11]
				txt.write(' '*8+str(t)+' '+str(w)+'\n')
				#G1MFParser(g)
		#if chunk=='G1MS0032':
		if chunk=='SM1G2300':
		    G1MSParser(start,g)
			
		
		g.seek(start+size)
	
def g1mParser(filename,g):
	global g1mList,txt
	
	txt=open("log.txt","w")
	#g.endian='>'	
	g1mList=[]	
	sectionCount=g.i(1)[0]
	offsetList=g.i(sectionCount)
	txt.write(str(offsetList)+'\n')
	for i,offset in enumerate(offsetList):
		g.seek(offset)
		if i!=0:
			chunk=g.word(4)
			chunkA=g.word(4)
			txt.write(str(i-1)+':'+chunk+' '+chunkA+'\n')
			#if chunk=='G1M_':
			if chunk=='_M1G':G1M_Parser(offset,filename,g)
			#if chunk=='FM1G':FM1G_Parser(offset,filename,g)
	
	
	for i,g1m in enumerate(g1mList):		
		#ModelID=ParseID()
		print '='*20,i
		for meshID in range(g1m.meshCount):
			mesh=Mesh()
			mesh.usedskin=[]
			#mesh.name=str(ModelID)+'-mesh-'+str(meshID)
			g1m.meshList.append(mesh)
			
		for infoID in range(len(g1m.meshInfoList)):
			info=g1m.meshInfoList[infoID]
			mesh=g1m.meshList[info[1]]
			stride=g1m.strideList[info[1]]				
			mat=Mat()
			#mat.ZTRANS=TruediffID=g1m.textureList[info[6]][0][1]
			#print infoID,info[6],g1m.textureList[info[6]][0]
			try:
				diffID=g1m.textureList[info[6]][0][0]+1
				for file in os.listdir(os.path.dirname(filename)):
					if str(diffID)+'.dds' in file:
						mat.diffuse=os.path.dirname(filename)+os.sep+file
						break
			except:pass			
			
			"""diffID=g1m.textureList[info[6]][0][1]
			print g1m.textureList[info[6]]
			mat.diffuse=g.dirname+os.sep+'textures'+os.sep+str(diffID)+'.dds'
			if len(g1m.textureList[info[6]])==4:
				diffID1=g1m.textureList[info[6]][1][1]
				mat.diffuse1=g.dirname+os.sep+'textures'+os.sep+str(diffID1)+'.dds'
				#print mat.diffuse1
				diffID2=g1m.textureList[info[6]][3][1]
				mat.diffuse2=g.dirname+os.sep+'textures'+os.sep+str(diffID2)+'.dds'
				#print mat.diffuse2
			if len(g1m.textureList[info[6]])==3:
				aoID=g1m.textureList[info[6]][2][1]
				#mat.ao=g.dirname+os.sep+'textures'+os.sep+str(aoID)+'.dds'
				#print mat.ao
				specularID=g1m.textureList[info[6]][1][1]
				mat.specular=g.dirname+os.sep+'textures'+os.sep+str(specularID)+'.dds'
				#print mat.specular
				
			if len(g1m.textureList[info[6]])>1:
				ID=g1m.textureList[info[6]][4][1]
				mat.normal=g.dirname+os.sep+'textures'+os.sep+str(ID)+'.dds'
				#print mat.specular"""
				
			mat.IDStart=info[12]
			mat.IDCount=info[13]
			mat.TRISTRIP=True
			mesh.matList.append(mat)
					
			skinIndiceList=[]
			skinWeightList=[]	
			for m in range(stride.count):
				element=stride.list[m]
				if element.unk2==0:#vertPosList				 
					stream=g1m.vertStreamList[element.streamID]
					g.seek(stream.offset+info[10]*stream.strideSize)
					for n in range(info[11]):
						t=g.tell()
						g.seek(t+element.offset)
						if element.unk0==2:mesh.vertPosList.append(g.f(3))
						if element.unk0==11:mesh.vertPosList.append(g.half(3))
						if element.unk0==3:mesh.vertPosList.append(g.f(3))
						g.seek(t+stream.strideSize)
						
				if element.unk2==5:#vertUVList  
					if element.unk3==0:#layer 0			 
						stream=g1m.vertStreamList[element.streamID]
						g.seek(stream.offset+info[10]*stream.strideSize)
						for n in range(info[11]):
							t=g.tell()
							g.seek(t+element.offset)
							if element.unk0==1:mesh.vertUVList.append(g.f(2))
							g.seek(t+stream.strideSize)
				if element.unk2==1:#skinWeightList 
					#print 'skinweight:',info[11]
					if element.unk3==0:#layer 0			 
						stream=g1m.vertStreamList[element.streamID]
						g.seek(stream.offset+info[10]*stream.strideSize)
						for n in range(info[11]):
							t=g.tell()
							g.seek(t+element.offset)
							if element.unk0==2:#3float
								skinWeightList.append(g.f(3))
							elif element.unk0==0:
								w=g.f(1)[0]
								skinWeightList.append([w,1.0-w])
							elif element.unk0==3:
								skinWeightList.append(g.f(3))
							elif element.unk0==1:
								skinWeightList.append(g.f(2))
							elif element.unk0==13:#3float
								W1=g.B(1)[0]/255.0
								W2=g.B(1)[0]/255.0
								W3=g.B(1)[0]/255.0
								skinWeightList.append([W1,W2,W3])
							#else:
							#	print 'element:',element.unk0,g.tell(),g.f(4)
							g.seek(t+stream.strideSize)
				if element.unk2==2:#skinIndiceList  
					#print 'skinIndice:',info[11]
					if element.unk3==0:#layer 0			 
						stream=g1m.vertStreamList[element.streamID]
						g.seek(stream.offset+info[10]*stream.strideSize)
						for n in range(info[11]):
							t=g.tell()
							g.seek(t+element.offset)
							if element.unk0==5:
								ID1=g.B(1)[0]/3
								ID2=g.B(1)[0]/3
								ID3=g.B(1)[0]/3
								skinIndiceList.append([ID1,ID2,ID3])
							#else:
							#	print 'element:',element.unk0,g.tell(),g.i(4)
							g.seek(t+stream.strideSize) 
			
			indiceStream=g1m.indiceStreamList[info[1]]
			#print indiceStream.offset
			g.seek(indiceStream.offset+info[12]*indiceStream.strideSize)
			#if info[2] not in mesh.usedskin:
			#mesh.usedskin.append(info[2])
			
			#skin=Skin()			
			#skin.boneMap=g1m.boneMapList[info[2]]				
			#mesh.skinList.append(skin)
			#print g1m.boneMapList[info[2]]
			
			indiceList=[]
			for m in range(info[13]):
				if indiceStream.strideSize==2:
					id=g.H(1)[0]
					indiceList.append(id)
					#mesh.skinIDList[id][mesh.usedskin.index(info[2])]=1
				if indiceStream.strideSize==4:
					pass#mesh.indiceList.append(g.i(1)[0])
			mesh.indiceList.extend(indiceList)
			#print indiceList
			#mesh.skinIndiceList.extend(skinIndiceList)
			#mesh.skinWeightList.extend(skinWeightList)
			#for id in indiceList
			if len(skinIndiceList)==len(skinWeightList):
				if len(skinIndiceList)>0 and len(skinWeightList)>0:
					mesh.skinIndiceList.extend(skinIndiceList)
					mesh.skinWeightList.extend(skinWeightList)
				else:	
					for id in range(info[11]):
						mesh.skinIndiceList.append([0])
						mesh.skinWeightList.append([1.0])
			if len(skinIndiceList)!=0 and len(skinWeightList)==0:
					mesh.skinIndiceList.extend(skinIndiceList)
					for id in range(info[11]):
						#mesh.skinIndiceList.append([0])
						mesh.skinWeightList.append([1.0])
				
				
			skin=Skin()#mesh.skinList[0]
			skin.boneMap=g1m.boneMapList[info[2]]
			skin.IDStart=info[10]
			skin.IDCount=info[11]
			if len(mesh.skinIndiceList)>0:
				mesh.skinList.append(skin) 
			
		g1m.skeleton.name=str(i)+'-armature'
		#if i==0:	
		g1m.skeleton.draw()
		for mesh in g1m.meshList:
			txt.write(str(mesh.skinIndiceList)+'\n')
			print 'vertCount:',len(mesh.vertPosList),'indiceCount:',len(mesh.indiceList),'skinWeightCount:',len(mesh.skinWeightList),'skinIndiceCount:',len(mesh.skinIndiceList)
			mesh.BINDSKELETON=g1m.skeleton.name 
			#mesh.boneNameList=g1m.skeleton.boneNameList	
			#mesh.SPLIT=True
			#mesh.WARNING=True			
			try:mesh.draw()
			except:
				print '='*50
				print 'Problem z mesh.skinList'
				mesh.skinList=[]
				mesh.draw()
			
	#skeleton=Skeleton()
	#boneCount=0
	#for g1m in g1mList:
	#	if len(g1m.skeleton.boneList)>boneCount:
	#		skeleton=g1m.skeleton
	#skeleton.draw()		
	#for g1m in g1mList:
		#for mesh in g1m.meshList:
			#mesh.BINDSKELETON=skeleton.name 
			#mesh.boneNameList=g1m.skeleton.boneNameList	
			#mesh.SPLIT=True
			#mesh.WARNING=True			
			#mesh.draw()
	g.tell()
	txt.close()
	
	
def Parser(filename):	
	#global debug
	#filename=input.filename
	print
	print filename
	print
	ext=filename.split('.')[-1].lower()	
	#debug=0
	
	
			
	if ext=='g1m':
			file=open(filename,'rb')
			g=BinaryReader(file)
			#g.logOpen()
			g1mParser(filename,g)
			#g.logClose()
			
	else:
		
		for file in os.listdir(os.path.dirname(filename)):
			if '.' not in file:
					g1mFlag=False
					filePath=os.path.dirname(filename)+os.sep+file
					filedata=open(filePath,'rb')
					data=filedata.read()
					if data.find('_M1G')!=-1:
						print file
						g1mFlag=True
					filedata.close()	
					if g1mFlag==True:
						if os.path.exists(filePath+'.g1m')==False:
							os.rename(filePath,filePath+'.g1m')
					
			
			
 
	
Blender.Window.FileSelector(Parser,'import','One Piece Pirate Warriors 3 PC files: *.g1m - model') 
	