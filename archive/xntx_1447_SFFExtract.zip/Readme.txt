SFFExtract v0.1
Created by Crypton
-------------------------

Info:
Tool that simply unpacks .sff file (M.U.G.E.N Sprite) into .pcx files into folder.


Usage:

SFFExtract.exe "YourFile.sff"
