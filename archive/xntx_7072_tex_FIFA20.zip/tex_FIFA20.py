# FIFA20 texture importer by Bigchillghost
from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("FIFA20 Textures", ".f20t")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
	#noesis.logPopup()
	return 1

def noepyCheckType(data):
	if len(data) < 0x74:
		return 0
	return 1

def noepyLoadRGBA(data, texList):
	bs = NoeBitStream(data)
	bs.seek(0xC, NOESEEK_ABS)
	imgFmt = bs.readInt()
	bs.seek(6, NOESEEK_REL)
	Width = bs.readUShort()
	Height = bs.readUShort()
	bs.seek(4, NOESEEK_REL)
	mipNum = bs.readUShort()
	Hash1 = bs.readUInt()
	Hash2 = bs.readUShort()
	Hash3 = bs.readUShort()
	Hash4 = bs.readBytes(8)
	SrcDataFileName = "%08x-%04x-%04x-%02x%02x-%02x%02x%02x%02x%02x%02x"% \
	(Hash1,Hash2,Hash3, \
	Hash4[0],Hash4[1],Hash4[2],Hash4[3],Hash4[4],Hash4[5],Hash4[6],Hash4[7])
	SrcDataFileFullName = rapi.getDirForFilePath(rapi.getInputName()) + SrcDataFileName
	bs.seek(0x3C, NOESEEK_REL)
	dataSize = bs.readInt()
	try:
		PixelData = rapi.loadIntoByteArray(SrcDataFileFullName)
	except RuntimeError:
		noesis.messagePrompt("Error: no such file as %s"%SrcDataFileName)
		return 0
	if imgFmt == 0x12:
		PixelData = rapi.imageDecodeRaw(PixelData, Width, Height, "g8r8a8b8")
		texFmt = noesis.NOESISTEX_RGBA32
	elif imgFmt == 0x37:
		texFmt = noesis.NOESISTEX_DXT1
	elif imgFmt == 0x3E:
		PixelData = rapi.imageDecodeDXT(PixelData, Width, Height, noesis.FOURCC_ATI1)
		texFmt = noesis.NOESISTEX_RGBA32
	elif imgFmt == 0x43:
		PixelData = rapi.imageDecodeDXT(PixelData, Width, Height, noesis.FOURCC_BC7)
		texFmt = noesis.NOESISTEX_RGBA32
	else:
		noesis.messagePrompt("Error: unsupported image format: " + repr(imgFmt))
		return 0
	texList.append(NoeTexture(rapi.getInputName(), Width, Height, PixelData, texFmt))
	return 1