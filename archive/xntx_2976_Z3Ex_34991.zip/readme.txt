RaiderZ/GunZ2 FileSystem Dumper
By WRS


	Instructions
-------------------------------------------------------------------------------

	NOTE
	You need to patch the client executable (GunZ2.exe/Raiderz.exe) so it loads
	my Z3Ex.dll library before you can expect it to work


	
	Patching the client
-------------------------------------------------------------------------------

1) Extract these files into a folder:

	lpatch.dat
	lpatch.exe

2) Copy the client executable into the same folder as above

3) Run lpatch.exe
	Lame patcher will show you some details of the patch

4) Click 'Yes'
	Another message will popup saying it was a success
	
5) Click 'No' to the report
	Another message will popup with some of my comments


	
	Dumping the files
------------------------------------------------------------------------------

1) In your RaiderZ/GunZ 2 directory, rename the client executable

2) Copy over the patched executable

3) Extract 'Z3Ex.dll' and copy it over too

4) Run either Raiderz.exe or Gunz2.exe
	You should see a folder named 'datadump' created
	Once complete, a popup will show you how many files it extracted
	
	NOTE
	This might take a few minutes

	
	Contacting Me
-------------------------------------------------------------------------------

	Send a PM to
		WRS (forum.xentax.com)


	
	Lame Patcher
-------------------------------------------------------------------------------
	
	I make use of aluigi's 'lpatch.exe' to avoid redistributing the 15MB client
	
	To read more, visit
		http://aluigi.org/mytoolz.htm#lpatch

	