from inc_noesis import *

modelIndex = 0

def registerNoesisTypes():
	handle = noesis.register("Asterix XXL",".gen")
	noesis.setHandlerTypeCheck(handle, CheckType)
	noesis.setHandlerLoadModel(handle, LoadModel)	
	return 1
	
def CheckType(data):
	bs = NoeBitStream(data)
	if len(data) < 16:
		print("Invalid file, too small")
		return 0
	return 1
	
def findFlag(bs):
	indexFlag = b'\x22\x22\xBB\xAA\x11\x11\xBB\xAA'
	a=True
	while a:
		checkPoint = bs.tell()
		temp = bs.readBytes(0x8)
		if temp == indexFlag:
			bs.seek(checkPoint)
			a = False
		else :
			bs.seek(checkPoint+1)
	return 1
	
def findFlag2(bs):
	indexFlag = b'\x11\x11\xBB\xAA'
	a=True
	while a:
		checkPoint = bs.tell()
		temp = bs.readBytes(0x4)
		if temp == indexFlag:
			bs.seek(checkPoint)
			a = False
		else :
			bs.seek(checkPoint+1)
	return 1

def LoadModel(data, mdlList):
	
	ctx = rapi.rpgCreateContext()
	bs = NoeBitStream(data)
	bs.setEndian(NOE_LITTLEENDIAN)
	
	nameToIndex = {}
	
	findFlag(bs) #probably possible to parse the header correctly but it's completely useless, just jump to the relevant sections
	bs.readBytes(1)
	
	modelCount = 0
	skinIdBuffs = []
	skinWBuffs = []
	while True:
		findFlag(bs)	
		bs.readBytes(0x10) #tan header
		if bs.readBytes(0x8) != b'\x74\x61\x6E\x67\x65\x6E\x74\x00': #no tangent, end of the loop
			break
		tanCount = bs.readUInt()
		bs.readBytes(tanCount * 12) #tan data, we skip
		
		
		bs.readBytes(0x19) #binorm header
		binormCount = bs.readUInt() 
		bs.readBytes(binormCount * 12)#binorm data, we skip
		
		bs.readBytes(0x19) #skinning header	
		skinDataCount = bs.readUInt() #don't know why the vCount is always repeated since it must always be the exact same...
		skinIdBuffs.append(bytes())
		skinWBuffs.append(bytes())		
		for _ in range(skinDataCount * 4):
			skinIdBuffs[modelCount] += bs.readBytes(1)
			skinWBuffs[modelCount] += bs.readBytes(4)		
		#Exact same section, no clue why it's there, we skip
		skinDataCount = bs.readUInt()
		bs.seek(skinDataCount * 20,1)
		modelCount+=1
		
	print("There is/are %d model(s) in that file" % modelCount)	
	
	bs.seek(-0x18,1)
	findFlag2(bs)
	bs.readBytes(0x1)
	findFlag2(bs)
	bs.readBytes(0x1)
	findFlag2(bs)
	bs.readBytes(0xE)
	
	names = [[] for i in range(modelCount)]
	vBuffs = [bytes() for i in range(modelCount) ]
	iBuffs = [bytes() for i in range(modelCount) ]
	triCounts = []
	for i in range(modelCount):
		triCounts.append(bs.readUInt())
		iBuffs[i] = bs.readBytes(triCounts[i] * 12)
		bs.readBytes(1)
		vCount = bs.readUInt()
		vBuffs[i] = bs.readBytes(vCount*48)
		boneMapIDCount = bs.readUInt()
		for _ in range(boneMapIDCount):
			name = noeStrFromBytes(bs.readBytes(bs.readUInt()))
			names[i].append(name)
		findFlag(bs)
		bs.readBytes(0x10)
		if bs.readBytes(4) != b'\x11\x11\xBB\xAA':
			findFlag2(bs)
			bs.readBytes(0xE)
		else:
			bs.seek(-8,1)
	jointCount = bs.readUInt()
	bs.seek(-4,1)
	offset = 0
	joints = []
	for i in range(jointCount):
		bs.readBytes(0xC)
		name = noeStrFromBytes(bs.readBytes(bs.readUInt()))
		nameToIndex[name] = i
		bs.readBytes(bs.readUInt())
		mat1 = NoeMat44.fromBytes(bs.readBytes(0x40)).toMat43()
		mat2 = NoeMat44.fromBytes(bs.readBytes(0x40)).toMat43()
		mat3 = NoeMat44.fromBytes(bs.readBytes(0x40)).toMat43()
		joints.append(NoeBone(i, name, mat2, None, bs.readInt()))
	
	for i in range(modelCount):
		rapi.rpgBindPositionBuffer(vBuffs[i], noesis.RPGEODATA_FLOAT,0x30)
		rapi.rpgBindNormalBufferOfs(vBuffs[i], noesis.RPGEODATA_FLOAT,0x30,0xC)
		rapi.rpgBindUV1BufferOfs(vBuffs[i], noesis.RPGEODATA_FLOAT, 0x30, 0x18)
		rapi.rpgBindBoneIndexBuffer(skinIdBuffs[i], noesis.RPGEODATA_BYTE,0x4,0x4)
		rapi.rpgBindBoneWeightBuffer(skinWBuffs[i], noesis.RPGEODATA_FLOAT,0x10,0x4)
		
		boneMap = [nameToIndex[name] for name in names[i]]
		rapi.rpgSetBoneMap(boneMap)
				
		rapi.rpgCommitTriangles(iBuffs[i], noesis.RPGEODATA_UINT, triCounts[i]*3, noesis.RPGEO_TRIANGLE)
	
		try:
			mdl = rapi.rpgConstructModel()
		except:
			mdl = NoeModel()
		mdl.setBones(joints)
		mdlList.append(mdl)
	
	return 1
	
	