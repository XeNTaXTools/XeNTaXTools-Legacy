// stdafx.h : Precompiled header
//

#pragma once

#include <windows.h>
#include <iostream>
#include <fstream>
#include <string>
#include <tchar.h>
#include <stdio.h>
#include <zlib.h>
#include <assert.h>
