from inc_noesis import *
import noesis
import rapi


def registerNoesisTypes():
	handle = noesis.register("Tasogare no Sinsemilla Portable", ".pbn")
	noesis.setHandlerTypeCheck(handle, TSPCheckType)
	noesis.setHandlerLoadModel(handle, TSPLoadRGBA)
	#noesis.logPopup()
	return 1

def TSPCheckType(data):
	bs = NoeBitStream(data)
	magic = bs.readUInt()
	if magic != 0x48584554:
		return 0
	return 1

def TSPLoadRGBA(data, mdlList):
	texList = []
	bs = NoeBitStream(data)
	header = bs.read("8I")

	texInfo1 = []
	bs.seek(header[3], NOESEEK_ABS)
	for a in range(0, header[2]):
		texInfo1.append(bs.read("2B5H3I"))
	#print(texInfo1)

	texInfo2 = []
	bs.seek(header[5], NOESEEK_ABS)
	for a in range(0, header[4]):
		texInfo2.append(bs.read("4I"))
	#print(texInfo2)

	texInfo3 = []
	bs.seek(header[7], NOESEEK_ABS)
	for a in range(0, header[6]):
		texInfo3.append(bs.read("4B2I"))
	#print(texInfo3)

	texInfo4 = []
	for a in range(0, header[2]):
		bs.seek(texInfo1[a][9], NOESEEK_ABS)
		texInfo4.append(bs.read("4H"))
	#print(texInfo4)

	for a in range(0, header[2]):
		if texInfo1[a][6] == 5:
			width, height = texInfo1[a][2], texInfo4[a][3]
			if a != (header[2] - 1):
				texSize = texInfo1[(a + 1)][8] - texInfo1[a][8]
			else:
				texSize = len(data) - texInfo1[a][8]
			bs.seek(texInfo1[a][7], NOESEEK_ABS)
			palData = bs.readBytes(0x400)
			bs.seek(texInfo1[a][8], NOESEEK_ABS)
			texData = bs.readBytes(texSize)
			pix = rapi.imageUntwiddlePSP(texData, width, height, 8)
			pix = rapi.imageDecodeRawPal(pix, palData, width, height, 8, "r8g8b8a8p0")
			tex = NoeTexture(str(a), width, height, pix, noesis.NOESISTEX_RGBA32)
			tex.setFlags(noesis.NTEXFLAG_WRAP_CLAMP)
			texList.append(tex)
		elif texInfo1[a][6] == 4:
			pass
		elif texInfo1[a][6] == 3:
			pass
	meshes = []
	matList = []
	for a in range(0, header[2]):
		width, height = texInfo3[a][4], texInfo3[a][5]
		material = NoeMaterial(str(a), "")
		material.setTexture(str(a))
		material.setFlags(0, 1)
		matList.append(material)
		idxList = [1, 0, 2, 1, 2, 3]
		posList = [NoeVec3 ((width, -height, 0.0)), NoeVec3 ((width + texInfo4[a][2], -height, 0.0)), NoeVec3 ((width, -height + -texInfo4[a][3], 0.0)), NoeVec3 ((width + texInfo4[a][2], -height + -texInfo4[a][3], 0.0))]
		mesh = NoeMesh(idxList, posList, str(0), str(a))
		mesh.uvs = [NoeVec3 ((0.0, 0.0, 1.0)), NoeVec3 ((1.0, 0.0, 1.0)), NoeVec3 ((0.0, 1.0, 1.0)), NoeVec3 ((1.0, 1.0, 1.0))]
		meshes.append(mesh)
	mdl = NoeModel(meshes)
	mdl.setModelMaterials(NoeModelMaterials(texList, matList))
	mdlList.append(mdl)
	return 1