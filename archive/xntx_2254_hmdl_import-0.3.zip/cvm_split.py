#!/usr/bin/python

# Splits Valkyria Chronicles DATA.CVM file into pieces (without names)
# Made for US version, not tested with other versions
#
# Author: gomtuu
# Version: 1.0

import os, sys, struct, math

try:
    CVM = open(sys.argv[1], 'rb')
except IndexError:
    print 'Please specify path to input file (DATA.CVM).'
    print 'usage: cvm_split.py <inputfile> <outputdir>'
    sys.exit(1)

try:
    outdir = sys.argv[2]
except IndexError:
    print 'Please specify path to output directory.'
    print 'usage: cvm_split.py <inputfile> <outputdir>'
    sys.exit(1)

# CVM.seek(0x9800)
# Beginning of mystery header

CVM.seek(0x3d000)
# Read Files

SEEK_RELATIVE = True

i = 0
while True:
    start_offset = CVM.tell()
    ext = CVM.read(4)
    if ext == '':
        # No bytes read means we're done reading the file.
        break
    length = struct.unpack('<I', CVM.read(4))[0]
    header_length = struct.unpack('<I', CVM.read(4))[0]
    CVM.seek(start_offset)
    header_bytes = struct.unpack('B' * header_length, CVM.read(header_length))
    CVM.seek(start_offset + header_length)
    print 'Offset: 0x%08x\tExt: %s\tLength: 0x%08x\t' % (start_offset, ext, length),
    print ('Header: ' + '%02x' * 4 + ' ' + '%02x' * 4 + ' %02x' * (header_length - 4 - 4)) % header_bytes
    # Skip data
    CVM.seek(length, SEEK_RELATIVE)
    if ext == 'MTPA':
        # For some reason, the EOFC block doesn't appear in the expected
        # place for MTPA files. It appears header_length bytes too early.
        CVM.seek(-header_length, SEEK_RELATIVE)
        header_length = 0
    # Read EOFC
    eofc1 = CVM.read(4)
    if eofc1 != 'EOFC':
        raise AssertionError('EOFC not found at %x, %r found instead' % (CVM.tell() - 4, eofc1))
    CVM.seek(4, SEEK_RELATIVE)
    eof_length = struct.unpack('<I', CVM.read(4))[0]
    total_length = header_length + length + eof_length
    sector_length = int(math.ceil(total_length / 2048.0)) * 2048
    # Read entire chunk and write it to file
    CVM.seek(start_offset)
    data = CVM.read(sector_length)
    OUT = open(os.path.join(outdir, 'file%04u.%s' % (i, ext)), 'wb')
    OUT.write(data)
    OUT.close()
    i += 1
