#!BPY
# -*- coding: utf-8 -*-

""" Registration info for Blender menus:
Name: 'Valkyria Chronicles (.izca, .hmdl)...'
Blender: 249
Group: 'Import'
Tip: 'Import .izca or .hmdl models from Valkyria Chronicles.'
"""
__author__ = "Chrrox, Gomtuu"
__url__ = ("")
__email__="gomtuu:gmail*com"
__version__ = "0.3"

__bpydoc__ = """
Imports .hmdl models from Valkyria Chronicles.
"""

import Blender, bpy
from struct import pack, unpack

tmpdir = Blender.Get('tempdir')
model_filename = None
tex_images = []
materials = []
oneside = Blender.Texture.New('OneSide')
oneside.setType('Blend')
oneside.colorband = [ [1.0, 1.0, 1.0, 1.0, 0.0], [1.0, 1.0, 1.0, 1.0, 0.5], [0.0, 0.0, 0.0, 1.0, 0.501], [0.0, 0.0, 0.0, 1.0, 1.0] ]
oneside.flags |= Blender.Texture.Flags['COLORBAND']

def readlong(F):
    return unpack('<i', F.read(4))[0]

def ReadBElong(F):
    return unpack('>i', F.read(4))[0]

def ReadBEword(F):
    return unpack('>h', F.read(2))[0]

def ReadBEfloat(F):
    return unpack('>f', F.read(4))[0]

def convertTo32(inputAsInt):
    sign = inputAsInt >> 15
    exponent = ((inputAsInt & 0x7C00) >> 10) - 16
    fraction = inputAsInt & 0x03FF
    exponentF = exponent + 127
    # Ouput 32 bit integer representing a 32 bit float
    outputAsFloat = pack('>i', (sign << 31) | (exponentF << 23) | (fraction << 13))
    # Output Check
    return unpack('>f', outputAsFloat)[0]

def ReadBEHalfFloat(F):
    return convertTo32(ReadBEword(F))

def printoffset(offset):
    print 'Offset 0x%x' % offset

def read_header(IN):
    extension = IN.read(4)
    size = readlong(IN)
    header_size = readlong(IN)
    return (extension, size, header_size)

def read_sections(IZCA):
    sec_count = readlong(IZCA)
    unknown = readlong(IZCA)
    sections = []
    for i in range(sec_count):
        list_offset = readlong(IZCA)
        list_size = readlong(IZCA)
        old_offset = IZCA.tell()
        IZCA.seek(list_offset)
        section = []
        for j in range(list_size):
            file_offset = readlong(IZCA)
            section.append(InnerFile(IZCA, file_offset))
        IZCA.seek(old_offset)
        sections.append(section)
    return sections

def read_mxtl(sections, s, f):
    mxtl = sections[s][f]
    all_htsfs = find_files('HTSF', sections)
    old_offset = mxtl.IZCA.tell()
    mxtl.IZCA.seek(mxtl.offset + mxtl.header_size)
    hmdl_count = readlong(mxtl.IZCA)
    models = []
    for i in range(hmdl_count):
        section_start = mxtl.IZCA.tell()
        unk1 = readlong(mxtl.IZCA)
        assert unk1 == 8
        htsf_count = readlong(mxtl.IZCA)
        textures = []
        for j in range(htsf_count):
            filename_offset = readlong(mxtl.IZCA)
            unk2 = readlong(mxtl.IZCA)
            htsf_index = readlong(mxtl.IZCA)
            textures.append(all_htsfs[htsf_index])
        models.append(textures)
    return models

def find_files(extension, sections):
    found = []
    for s, section in enumerate(sections):
        for f, innerfile in enumerate(section):
            if innerfile.extension == extension:
                found.append((s, f))
    return found


class InnerFile:
    def __init__(self, IZCA, offset):
        self.IZCA = IZCA
        self.offset = offset
        old_offset = self.IZCA.tell()
        self.IZCA.seek(offset)
        (self.extension, self.size, self.header_size) = read_header(self.IZCA)
        self.IZCA.seek(old_offset)

    def read_file(self):
        old_offset = self.IZCA.tell()
        self.IZCA.seek(self.offset)
        self.data = self.IZCA.read(self.size + self.header_size)
        self.IZCA.seek(old_offset)


def open_hmdl_file(filename):
    KFMS_Array = []
    POF0_Array = []
    ENRS_Array = []
    CCRS_Array = []
    MTXS_Array = []
    EOFC_Array = []
    KFMG_Array = []

    F = open(filename, 'rb')
    idstring = F.read(4)
    totalfilesize = readlong(F)
    F.seek(0x20)
    idstring = F.read(4)
    kfmd_filesize = readlong(F)
    headersize = readlong(F)
    F.seek(headersize)
    while F.tell() < totalfilesize:
        SecStart = F.tell()
        idstring = F.read(4)
        print idstring
        printoffset(SecStart)
        SecSize = readlong(F)
        HeaderSize = readlong(F)
        Count1 = ReadBElong(F)
        Count2 = readlong(F)
        PartSize = readlong(F)

        if idstring == 'KFMS':
            KFMS_Array.append(SecStart)
        elif idstring == 'POF0':
            POF0_Array.append(SecStart)
        elif idstring == 'ENRS':
            ENRS_Array.append(SecStart)
        elif idstring == 'CCRS':
            CCRS_Array.append(SecStart)
        elif idstring == 'MTXS':
            MTXS_Array.append(SecStart)
        elif idstring == 'EOFC':
            EOFC_Array.append(SecStart)
        elif idstring == 'KFMG':
            KFMG_Array.append(SecStart)

        F.seek(SecStart + HeaderSize + PartSize)

    print KFMS_Array
    for kfms_i in range(len(KFMS_Array)):
        F.seek(KFMS_Array[kfms_i] + 0x40)
        PosOffCount = ReadBElong(F)
        PosOffTbl = ReadBElong(F)
        V1OffCount = ReadBElong(F)
        V1OffTbl = ReadBElong(F)
        V2OffCount = ReadBElong(F)
        V2OffTbl = ReadBElong(F)
        F.seek(KFMS_Array[kfms_i] + 0x80)
        FVFinfo = ReadBElong(F)
        F.seek(KFMS_Array[kfms_i] + FVFinfo)
        unk01 = readlong(F)
        vertsize = ReadBElong(F)
        Null01 = ReadBElong(F)
        FaceCount = ReadBElong(F)
        UnkCount = ReadBElong(F)
        VertCount = ReadBElong(F)
        printoffset(vertsize)
        printoffset(VertCount)
        printoffset(FaceCount)
        F.seek(KFMS_Array[kfms_i] + V1OffTbl)

        Group_Info_Array = []
        for a in range(V1OffCount):
            Group_Info_Array.append({
                'index': ReadBElong(F),
                'u01': ReadBElong(F),
                'PosOffTblPos': ReadBElong(F),
                'V2Count': ReadBElong(F),
                'V2Pos': ReadBElong(F),
                'VPosBytes?': ReadBElong(F),
                'VCount': ReadBEword(F),
                'n01': ReadBEword(F),
                'n02': ReadBEword(F),
                'n03': ReadBEword(F),
                })

        Vert_Info_Array = []
        for group in Group_Info_Array:
            F.seek(KFMS_Array[kfms_i] + group['PosOffTblPos'] + 0x10)
            TextureTblPos = ReadBElong(F)
            if TextureTblPos:
                F.seek(KFMS_Array[kfms_i] + TextureTblPos + 4)
                texture = ReadBEword(F)
            else:
                texture = None
            F.seek(KFMS_Array[kfms_i] + group['V2Pos'])
            for a in range(group['V2Count']):
                Vert_Info_Array.append({
                    'u01': ReadBEword(F),
                    'u02': ReadBEword(F),
                    'u03': ReadBEword(F),
                    'VCount': ReadBEword(F),
                    'FCount': ReadBEword(F),
                    'n01': ReadBElong(F),
                    'u04': ReadBEword(F),
                    'VPos': ReadBElong(F),
                    'FPos': ReadBElong(F),
                    'n02': ReadBElong(F),
                    'n03': ReadBElong(F),
                    'Texture': texture,
                    })
        print Vert_Info_Array

        F.seek(KFMG_Array[kfms_i] + 0x20)
        FaceStart = F.tell()
        FaceEnd1 = FaceStart + (2 * FaceCount)
        F.seek(FaceEnd1)
        if F.tell() % 16 != 0:
            F.seek(16 - F.tell() % 16, True)
        VertStart = F.tell()
        editmode = Blender.Window.EditMode()
        if editmode: Blender.Window.EditMode(0)
        for a in range(V2OffCount):
            Vert_array = []
            Normal_array = []
            UV_array = []
            Face_array = []

            F.seek(FaceStart + (2 * Vert_Info_Array[a]['FPos']))
            FaceEnd = F.tell() + (2 * Vert_Info_Array[a]['FCount'])
            StartDirection = -1
            f1 = ReadBEword(F)
            f2 = ReadBEword(F)
            FaceDirection = StartDirection
            while F.tell() < FaceEnd:
                f3 = ReadBEword(F)
                if f3 == 0xFFFF:
                    f1 = ReadBEword(F)
                    f2 = ReadBEword(F)
                    FaceDirection = StartDirection
                else:
                    FaceDirection *= -1
                    if f1 != f2 and f2 != f3 and f3 != f1:
                        if FaceDirection > 0:
                            Face_array.append((f3, f1, f2))
                        else:
                            Face_array.append((f3, f2, f1))
                    f1 = f2
                    f2 = f3

            F.seek(VertStart + (vertsize * Vert_Info_Array[a]['VPos']))
            for b in range(Vert_Info_Array[a]['VCount']):
                if vertsize == 44:
                    vx = ReadBEfloat(F)
                    vy = ReadBEfloat(F)
                    vz = ReadBEfloat(F)
                    nx = ReadBEfloat(F)
                    ny = ReadBEfloat(F)
                    nz = ReadBEfloat(F)
                    wx = ReadBEfloat(F)
                    wy = ReadBEfloat(F)
                    tu = ReadBEHalfFloat(F) * 2
                    tv = ReadBEHalfFloat(F) * -2
                    wz = ReadBEfloat(F)
                    yy = ReadBEfloat(F)
                elif vertsize == 48:
                    vx = ReadBEfloat(F)
                    vy = ReadBEfloat(F)
                    vz = ReadBEfloat(F)
                    nx = ReadBEfloat(F)
                    ny = ReadBEfloat(F)
                    nz = ReadBEfloat(F)
                    tu = ReadBEHalfFloat(F) * 2
                    tv = ReadBEHalfFloat(F) * -2
                    wx = ReadBEfloat(F)
                    wy = ReadBEfloat(F)
                    wz = ReadBEfloat(F)
                    yy = ReadBEfloat(F)
                    yz = ReadBEfloat(F)
                elif vertsize == 80:
                    vx = ReadBEfloat(F)
                    vy = ReadBEfloat(F)
                    vz = ReadBEfloat(F)
                    nx = ReadBEfloat(F)
                    ny = ReadBEfloat(F)
                    nz = ReadBEfloat(F)
                    wx = ReadBEfloat(F)
                    wy = ReadBEfloat(F)
                    wz = ReadBEfloat(F)
                    yy = ReadBEfloat(F)
                    yz = ReadBEfloat(F)
                    ax = ReadBEfloat(F)
                    ay = ReadBEfloat(F)
                    az = ReadBEfloat(F)
                    tu = ReadBEfloat(F)
                    tv = ReadBEfloat(F) * -1

                    F.seek(0x10, True)
                Vert_array.append((vx,vy,vz))
                #Normal_array.append((nx,ny,nz))
                UV_array.append(Blender.Mathutils.Vector(tu,tv,0))

            # Build Mesh

            msh = bpy.data.meshes.new('myMesh')

            msh.verts.extend(Vert_array)
            msh.faces.extend(Face_array)

            tex = Vert_Info_Array[a]['Texture']
            if tex != None:
                mat = materials[tex]
                msh.materials += [mat]
                msh.materials[0].getTextures()[0].texco = Blender.Texture.TexCo['UV']
                msh.materials[0].getTextures()[1].texco = Blender.Texture.TexCo['NOR']
                msh.materials[0].getTextures()[1].mapto = Blender.Texture.MapTo['ALPHA']
                msh.materials[0].getTextures()[1].xproj = Blender.Texture.Proj['Z']
                msh.materials[0].getTextures()[1].yproj = Blender.Texture.Proj['NONE']
                msh.materials[0].getTextures()[1].zproj = Blender.Texture.Proj['NONE']
                msh.materials[0].getTextures()[1].dvar = 0.0
                msh.materials[0].getTextures()[1].noRGB = True

            if tex != None:
                img = tex_images[tex]

            for i, face in enumerate(Face_array):
                msh.faces[i].smooth = 1
                if tex != None:
                    msh.faces[i].uv = [UV_array[face[0]], UV_array[face[1]], UV_array[face[2]]]
                    msh.faces[i].image = img

            msh.calcNormals()
            msh.mode |= Blender.Mesh.Modes['NOVNORMALSFLIP']

            scn = bpy.data.scenes.active
            ob = scn.objects.new(msh, 'myObj')
            ob.layers = [kfms_i + 1]
    if editmode: Blender.Window.EditMode(1)
    Blender.Redraw()

def unique_image_name(i):
    images = [x.getName() for x in Blender.Image.Get()]
    if ('%u.dds' % i) not in images:
        return '%u.dds' % i
    j = 0
    while ('%u.%04u.dds' % (i, j)) in images:
        j += 1
    return '%u.%04u.dds' % (i, j)

def write_tmp_file(sections, s, f):
    innerfile = sections[s][f]
    innerfile.read_file()
    tmp_path = Blender.sys.join(tmpdir, 's%02u_f%03u.%s' % (s, f, innerfile.extension))
    tmp_file = open(tmp_path, 'wb')
    tmp_file.write(innerfile.data)
    tmp_file.close()
    return tmp_path

def write_tmp_dds(IN, start_offset, i):
    global tex_images, materials
    IN.seek(start_offset)
    extension, size, header_size = read_header(IN)
    assert extension == 'HTSF', 'HTSF data not found where expected.'
    IN.seek(start_offset + header_size)
    dds_data = IN.read(size)
    # Remove zero padding
    dds_start = dds_data.find('DDS |')
    dds_data = dds_data[dds_start:]
    dds_path = Blender.sys.join(tmpdir, unique_image_name(i))
    DDS = open(dds_path, 'wb')
    DDS.write(dds_data)
    DDS.close()
    image = Blender.Image.Load(dds_path)
    image.pack()
    tex_images.append(image)
    mat = Blender.Material.New()
    tex = Blender.Texture.New()
    tex.setType('Image')
    tex.image = image
    tex.useAlpha = 0
    mat.setTexture(0, tex)
    mat.setTexture(1, oneside)
    mat.mode |= Blender.Material.Modes['ZTRANSP']
    materials.append(mat)
    return dds_path

def open_htex_file(filename):
    HTEX = open(filename, 'rb')
    ext = HTEX.read(4)
    assert ext == 'HTEX', 'Selected file was not an HTEX file.'
    filesize = readlong(HTEX)
    headersize = readlong(HTEX)
    HTEX.seek(headersize)
    i = 0
    while True:
        start_offset = HTEX.tell()
        ext = HTEX.read(4)
        if ext == '' or ext == 'EOFC':
            break
        write_tmp_dds(HTEX, start_offset, i)
        i += 1

def open_izca_file(IZCA):
    global tex_images, materials
    sections = read_sections(IZCA)
    assert sections != [], 'No sections found in IZCA file.'
    mxtl_index = find_files('MXTL', sections)
    if mxtl_index == []:
        # deduce HMDL/HTEX associations
        hmdls = find_files('HMDL', sections)
        htexs = find_files('HTEX', sections)
        assert len(hmdls) == len(htexs), 'Unable to deduce model/texture associates.'
        for hmdl, htex in zip(hmdls, htexs):
            tex_images = []
            materials = []
            htex_path = write_tmp_file(sections, htex[0], htex[1])
            open_htex_file(htex_path)
            hmdl_path = write_tmp_file(sections, hmdl[0], hmdl[1])
            open_hmdl_file(hmdl_path)
    else:
        # read HMDL/HTSF associations
        hmdls = find_files('HMDL', sections)
        htsf_sets = read_mxtl(sections, mxtl_index[0][0], mxtl_index[0][1])
        for hmdl, htsf_set in zip(hmdls, htsf_sets):
            tex_images = []
            materials = []
            for i, htsf in enumerate(htsf_set):
                write_tmp_dds(IZCA, sections[htsf[0]][htsf[1]].offset, i)
            hmdl_path = write_tmp_file(sections, hmdl[0], hmdl[1])
            open_hmdl_file(hmdl_path)

def set_model_filename(filename):
    global model_filename
    model_filename = filename
    settings['prev_model_filename'] = filename
    Blender.Registry.SetKey('hmdl_import', settings, True)
    model = open(model_filename, 'rb')
    (extension, size, header_size) = read_header(model)
    scn = Blender.Scene.New(Blender.sys.basename(filename))
    scn.makeCurrent()
    if extension == 'HMDL':
        model.close()
        if 'prev_htex_filename' in settings:
            Blender.Window.FileSelector(set_htex_filename, 'Open HTEX Texture Set', settings['prev_htex_filename'])
        else:
            Blender.Window.FileSelector(set_htex_filename, 'Open HTEX Texture Set')
    elif extension == 'IZCA':
        model.seek(header_size)
        open_izca_file(model)
        bpy.data.scenes.active.setLayers([1])

def set_htex_filename(filename):
    htex_filename = filename
    settings['prev_htex_filename'] = filename
    Blender.Registry.SetKey('hmdl_import', settings, True)
    open_htex_file(htex_filename)
    open_hmdl_file(model_filename)
    bpy.data.scenes.active.setLayers([1])

settings = Blender.Registry.GetKey('hmdl_import', True) or {}

if 'prev_model_filename' in settings:
    Blender.Window.FileSelector(set_model_filename, 'Open Model (HMDL or IZCA)', settings['prev_model_filename'])
else:
    Blender.Window.FileSelector(set_model_filename, 'Open Model (HMDL or IZCA)')
