#define WIN32_LEAN_AND_MEAN
#define WIN32_EXTRA_LEAN
#define VC_EXTRALEAN

#include <stdio.h>
#include <stdlib.h>
#include <string>

struct GTEXstruct {
	char magic[4];
	unsigned short unknown1; //Always 0x0203... part of magic?
	unsigned char format;
	unsigned char unknown2; //Don't know
	unsigned char numMipMaps; //According to mk64n's python script, however it seems that this always == 2
	unsigned short width;
	unsigned short height;
	unsigned char unknown3[11]; //Haven't looked at this
	unsigned int dataStart;
	unsigned int dataLength;
	// Shit after this point is not actually part of the IMGB file, I just have it here for coding ease.
	unsigned int dataEnd;
	unsigned int loc;
	GTEXstruct *next;
};

struct DDSstruct {
	char magic[4];
	unsigned int size;
	unsigned int flags;
	unsigned int height;
	unsigned int width;
	unsigned int pitchOrLinearSize;
	unsigned int depth;
	unsigned int mipMapCount;
	unsigned int reserved[11];
	unsigned int pixelFormat[8];
	unsigned int caps1;
	unsigned int caps2;
	unsigned int reserved2[3];
};

//Code below from GTA IV Xbox 360 Texture Editor @ http://forum.xentax.com/blog/?p=302
//Slightly modified to suit this application
static int XGAddress2DTiledX(int Offset, int Width, int TexelPitch)
{
	int AlignedWidth = (Width + 31) & ~31;

	int LogBpp = (TexelPitch >> 2) + ((TexelPitch >> 1) >> (TexelPitch >> 2));
	int OffsetB = Offset << LogBpp;
	int OffsetT = ((OffsetB & ~4095) >> 3) + ((OffsetB & 1792) >> 2) + (OffsetB & 63);
	int OffsetM = OffsetT >> (7 + LogBpp);

	int MacroX = ((OffsetM % (AlignedWidth >> 5)) << 2);
	int Tile = ((((OffsetT >> (5 + LogBpp)) & 2) + (OffsetB >> 6)) & 3);
	int Macro = (MacroX + Tile) << 3;
	int Micro = ((((OffsetT >> 1) & ~15) + (OffsetT & 15)) & ((TexelPitch << 3) - 1)) >> LogBpp;

	return Macro + Micro;
}

static int XGAddress2DTiledY(int Offset, int Width, int TexelPitch)
{
	int AlignedWidth = (Width + 31) & ~31;

	int LogBpp = (TexelPitch >> 2) + ((TexelPitch >> 1) >> (TexelPitch >> 2));
	int OffsetB = Offset << LogBpp;
	int OffsetT = ((OffsetB & ~4095) >> 3) + ((OffsetB & 1792) >> 2) + (OffsetB & 63);
	int OffsetM = OffsetT >> (7 + LogBpp);

	int MacroY = ((OffsetM / (AlignedWidth >> 5)) << 2);
	int Tile = ((OffsetT >> (6 + LogBpp)) & 1) + (((OffsetB & 2048) >> 10));
	int Macro = (MacroY + Tile) << 3;
	int Micro = ((((OffsetT & (((TexelPitch << 6) - 1) & ~31)) + ((OffsetT & 15) << 1)) >> (3 + LogBpp)) & ~1);

	return Macro + Micro + ((OffsetT & 16) >> 4);
}

void UntileXbox360Texture(const unsigned char* src, const unsigned char* dst, int width, int height, char format, unsigned int imgbOffset, unsigned int ddsOffset)
{
	unsigned int blockSize;
	unsigned int texelPitch;
	switch (format)
	{
	case 0x18:
		blockSize = 4;
		texelPitch = 8;
		break;
	default:
		printf("This texture format not yet supported by UntileXbox360Texture\n");
		return;
	}

	int blockWidth = width / blockSize;
	int blockHeight = height / blockSize;
	
	for (int j = 0; j < blockHeight; j++)
	{
		for (int i = 0; i < blockWidth; i++)
		{
			int blockOffset = j * blockWidth + i;
			int x = XGAddress2DTiledX(blockOffset, blockWidth, texelPitch);
			int y = XGAddress2DTiledY(blockOffset, blockWidth, texelPitch);
			
			int srcOffset = j * blockWidth * texelPitch + i * texelPitch + imgbOffset;
			int dstOffset = y * blockWidth * texelPitch + x * texelPitch + ddsOffset;
			
			memcpy((void*)(dst+dstOffset), src+srcOffset, texelPitch);
		}
	}
}

void TileXbox360Texture(const unsigned char* src, const unsigned char* dst, int width, int height, char format, unsigned int imgbOffset, unsigned int ddsOffset)
{
	unsigned int blockSize;
	unsigned int texelPitch;
	switch (format)
	{
	case 0x18:
		blockSize = 4;
		texelPitch = 8;
		break;
	default:
		printf("This texture format not yet supported by TileXbox360Texture\n");
		return;
	}

	int blockWidth = width / blockSize;
	int blockHeight = height / blockSize;
	
	for (int j = 0; j < blockHeight; j++)
	{
		for (int i = 0; i < blockWidth; i++)
		{
			int blockOffset = j * blockWidth + i;
			int x = XGAddress2DTiledX(blockOffset, blockWidth, texelPitch);
			int y = XGAddress2DTiledY(blockOffset, blockWidth, texelPitch);
			
			int srcOffset = j * blockWidth * texelPitch + i * texelPitch + imgbOffset;
			int dstOffset = y * blockWidth * texelPitch + x * texelPitch + ddsOffset;
			
			memcpy((void*)(dst+srcOffset), src+dstOffset, texelPitch);
		}
	}
}
//Code above from GTA IV Texture Editor @ http://forum.xentax.com/blog/?p=302

void byteSwap(unsigned char* buf, unsigned int len)
{
	//I'm fairly certain this code is shit, but it works...
	unsigned int i = 0;
	unsigned char b = 0;
	for (i=0;i<len;i+=2)
	{
		b = *(buf+i);
		*(buf+i) = *(buf+1+i);
		*(buf+1+i) = b;
	}
}

bool bDataCompare(const unsigned char* pData, const unsigned char* bMatch)
{
    for(;*bMatch;bMatch++,pData++){
        if(*pData!=*bMatch)
            return false;
	}
	return true;
}

void exportStuff(GTEXstruct *GTEXheaderRoot, unsigned char *imgbBuf, unsigned int imgbSize)
{
		GTEXstruct *GTEXheader = GTEXheaderRoot;
		DDSstruct *DDSheader = new DDSstruct;

		memcpy((void*)DDSheader,"\x44\x44\x53\x20\x7C\x00\x00\x00\x07\x10\x0A\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x04\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x20\x00\x00\x00\x04\x00\x00\x00\x44\x58\x54\x31\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x08\x10\x40\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00",128);
	
		if (GTEXheader != 0)
		{
			while (GTEXheader->next != 0)
			{
				//printf("Loc: %X\n  Format: %X\n  Mipmaps: %d\n  Dimensions: %dx%d\n  Data Start: 0x%.8X\n  Data Length: 0x%.8X\n", GTEXheader->loc, GTEXheader->format, GTEXheader->numMipMaps, GTEXheader->width, GTEXheader->height, GTEXheader->dataStart, GTEXheader->dataLength);

				if (GTEXheader->format == 0x18)
				{
					DDSheader->height = GTEXheader->height;
					DDSheader->width = GTEXheader->width;
					DDSheader->mipMapCount = GTEXheader->numMipMaps+1;
					unsigned char* ddsBuf;
					if ((ddsBuf = (unsigned char*)malloc(GTEXheader->dataLength)) == NULL) {
						printf("Failed to allocate memory for ddsBuf\n"); exit(2);
					}

					memset(ddsBuf,0xCC,GTEXheader->dataLength);
				
					//untile the main image
					int imgbOffset = GTEXheader->dataStart;
					int ddsOffset = 0;
					UntileXbox360Texture(imgbBuf, ddsBuf, GTEXheader->width, GTEXheader->height, GTEXheader->format, imgbOffset, ddsOffset);
			
					//untile the first mipmap
					imgbOffset += (GTEXheader->width)*GTEXheader->height/2;
					ddsOffset += (GTEXheader->width)*GTEXheader->height/2;
					UntileXbox360Texture(imgbBuf, ddsBuf, GTEXheader->width/2, GTEXheader->height/2, GTEXheader->format, imgbOffset, ddsOffset);
					//untile the second mipmap
					imgbOffset += (GTEXheader->width)*GTEXheader->height/8;
					ddsOffset += (GTEXheader->width)*GTEXheader->height/8;
					UntileXbox360Texture(imgbBuf, ddsBuf, (GTEXheader->width)/4, GTEXheader->height/4, GTEXheader->format, imgbOffset, ddsOffset);
					//This data just appears to be trash...
					//imgbOffset += (GTEXheader->width)*GTEXheader->height/32;
					//ddsOffset += (GTEXheader->width)*GTEXheader->height/32;
					//memcpy(ddsBuf+ddsOffset,imgbBuf+imgbOffset,GTEXheader->dataEnd-imgbOffset);
			
					byteSwap(ddsBuf, GTEXheader->dataLength);

					FILE *oDDS = 0;
					char fileName[16];
					sprintf(fileName, "0x%.8X.dds", GTEXheader->loc);
					if ((oDDS = fopen(fileName, "wb")) == NULL) {
						printf("Failed to open file %s for writing output.\n", fileName); exit(2);
					}
					fwrite((void*)DDSheader,1,128,oDDS);
					fwrite(ddsBuf, 1, GTEXheader->dataLength, oDDS);
					fclose(oDDS);
					free(ddsBuf);
					printf("Wrote texture to: %s\n", fileName);
				}

				GTEXheader = GTEXheader->next;
			}
		}
}

void importStuff(GTEXstruct *GTEXheaderRoot, unsigned char *imgbBuf, unsigned int imgbSize)
{
		GTEXstruct *GTEXheader = GTEXheaderRoot;
		if (GTEXheader != 0)
		{
			while (GTEXheader->next != 0)
			{
				if (GTEXheader->format == 0x18) 
				{
					FILE *iDDS = 0;
					char fileName[16];
					sprintf(fileName, "0x%.8X.dds", GTEXheader->loc);
					if ((iDDS = fopen(fileName, "rb")) != NULL)
					{
						fseek(iDDS, 0, SEEK_END);
						unsigned int ddsSize = ftell(iDDS) - 128;
						fseek(iDDS, 128, SEEK_SET); //Skip the DDS header

						unsigned char* ddsBuf;
						if ((ddsBuf = (unsigned char*)malloc(GTEXheader->dataLength)) == NULL) {
							printf("Failed to allocate memory for ddsBuf\n"); exit(2);
						}
					
						memset(ddsBuf, 0xCC, GTEXheader->dataLength);
						fread(ddsBuf, 1, ddsSize, iDDS);
					
						fclose(iDDS);

						byteSwap(ddsBuf, ddsSize);

						//Tile it back
						int imgbOffset = GTEXheader->dataStart;
						int ddsOffset = 0;
						TileXbox360Texture(ddsBuf, imgbBuf, GTEXheader->width, GTEXheader->height, GTEXheader->format, imgbOffset, ddsOffset);
					
						imgbOffset += (GTEXheader->width)*GTEXheader->height/2;
						ddsOffset += (GTEXheader->width)*GTEXheader->height/2;
						TileXbox360Texture(ddsBuf, imgbBuf, GTEXheader->width/2, GTEXheader->height/2, GTEXheader->format, imgbOffset, ddsOffset);

						imgbOffset += (GTEXheader->width)*GTEXheader->height/8;
						ddsOffset += (GTEXheader->width)*GTEXheader->height/8;
						TileXbox360Texture(ddsBuf, imgbBuf, (GTEXheader->width)/4, GTEXheader->height/4, GTEXheader->format, imgbOffset, ddsOffset);
					
						imgbOffset += (GTEXheader->width)*GTEXheader->height/32;
						ddsOffset += (GTEXheader->width)*GTEXheader->height/32;
						memcpy(imgbBuf+imgbOffset,ddsBuf+ddsOffset,ddsSize - ddsOffset);
						printf("Imported texture %s to location: %X\n", fileName, GTEXheader->loc);
					}
				}
				GTEXheader = GTEXheader->next;
			}
		}

		FILE *oIMGB = 0;
		if ((oIMGB = fopen("output.imgb", "wb")) == NULL)
		{
			printf("Failed to open output.imgb for writing\n"); exit(5);
		}
		fwrite(imgbBuf,1,imgbSize,oIMGB);
		fclose(oIMGB);
		printf("Wrote new imgb file to output.imgb\n");
}

int main(int argc, char *argv[])
{
	
	if (argc != 4 || (strcmp(argv[1], "-e") != 0 && strcmp(argv[1], "-i") != 0)) {
		printf("Usage: %s [-e|-i] [TRB File] [IMGB file]\n", argv[0]);
		return 3;
	}
		
	FILE *trbFile = 0;
	unsigned char *trbBuf;
	int trbSize;
	
	if (!(trbFile = fopen(argv[2], "rb"))) { printf("Failed to open file %s\n", argv[2]); return 1; } else { printf("Reading trb file: %s\n", argv[2]); }
	
	fseek(trbFile, 0, SEEK_END);
	trbSize = ftell(trbFile);
	rewind(trbFile);

	trbBuf = (unsigned char*)malloc(trbSize);

	fread(trbBuf,1,trbSize,trbFile);
	fclose(trbFile);

	char* GTEXID;
	if ((GTEXID = (char*)malloc(5)) == NULL) {
		printf("Failed to allocate memory for GTEXID\n"); return 2;
	}
	strcpy(GTEXID,"GTEX");

	GTEXstruct *GTEXheaderRoot = new GTEXstruct;
	GTEXstruct *GTEXheader = GTEXheaderRoot;

	for (int i=0; i<trbSize; i++)
	{
		if (bDataCompare(trbBuf+i,(unsigned char*)GTEXID)) {
			//printf("Found GTEX @ 0x%.8X\n", i);
			memcpy((void*)GTEXheader,trbBuf+i,0x20);
			
			GTEXheader->width -= 4; // Why does the GTEX structure always show this 4 higher?
			GTEXheader->dataStart = _byteswap_ulong(GTEXheader->dataStart);
			GTEXheader->dataLength = _byteswap_ulong(GTEXheader->dataLength);
			GTEXheader->dataEnd = GTEXheader->dataStart + GTEXheader->dataLength;
			GTEXheader->loc = i;

			GTEXheader->next = new GTEXstruct;
			GTEXheader = GTEXheader->next;
			GTEXheader->next = 0;
		}
	}

	free(GTEXID);
	free(trbBuf);

	//The entries are not in order and DO overlap. So adjust the length such that they do NOT overlap.
	GTEXheader = GTEXheaderRoot;
	GTEXstruct *GTEXheader2;

	if (GTEXheader != 0)
	{
		while (GTEXheader->next != 0)
		{
			GTEXheader2 = GTEXheaderRoot;
			if (GTEXheader2 != 0)
			{
				while(GTEXheader2->next != 0)
				{
					if (GTEXheader->loc != GTEXheader2->loc && GTEXheader2->dataStart < GTEXheader->dataEnd && GTEXheader2->dataStart > GTEXheader->dataStart)
					{
						GTEXheader->dataLength = GTEXheader2->dataStart - GTEXheader->dataStart;
					}
					GTEXheader2 = GTEXheader2->next;
				}
			}
			GTEXheader = GTEXheader->next;
		}
	}

	FILE *imgbFile = 0;
	unsigned char* imgbBuf;
	int imgbSize;
	
	if (!(imgbFile = fopen(argv[3], "rb"))) { printf("Failed to open file %s\n", argv[3]); return 1; } else { printf("Reading imgb file: %s\n", argv[3]); }
	
	fseek(imgbFile, 0, SEEK_END);
	imgbSize = ftell(imgbFile);
	rewind(imgbFile);
	
	if ((imgbBuf = (unsigned char*)malloc(imgbSize)) == NULL) {
		printf("Failed to allocate memory for imgbBuf\n"); return 2;
	}

	fread(imgbBuf,1,imgbSize,imgbFile);

	fclose(imgbFile);

	if (strcmp(argv[1], "-e") == 0)
	{
		exportStuff(GTEXheaderRoot, imgbBuf, imgbSize);
	}

	if (strcmp(argv[1], "-i") == 0)
	{
		importStuff(GTEXheaderRoot, imgbBuf, imgbSize);
	}

	printf("Done");
	free(imgbBuf);
	return 0;
}