/*
=============================================================================
Module Information
------------------
Name:			model_tpr.cpp
Author:			MrAdults
Description:	handling for tecmo tpr models
=============================================================================
*/

#include "main.h"
#include "glwrap.h"
#include "cnt_arraylist.h"

typedef struct tprHdr_s
{
	BYTE		id[4];
	int			dataOfs;
	int			subSize;
	int			numEntries;
} tprHdr_t;
typedef struct tprEntry_s
{
	BYTE		id[4];
	int			ofs;
	int			size;
	int			baseOfs;
} tprEntry_t;

typedef struct mdlInfoHdr_s
{
	BYTE		id[8]; //"MdlInfo\0"
	int			unknownA;
	int			unknownB;

	int			dataSize;
	int			numObjInfo;
	int			numObjInfoB;
	int			unknownF;

	int			unknownG;
	int			unknownH;
	int			unknownI;
	int			unknownJ;
} mdlInfoHdr_t;
typedef struct objInfoMeat_s
{
	int			unknownA;
	int			unknownB;
	int			unknownC;
	int			unknownD;

	int			unknownE;
	int			unknownF;
	int			unknownG;
	int			unknownH;

	float		fldata[12];
} objInfoMeat_t;
typedef struct objInfoHdr_s
{
	BYTE		id[8]; //"ObjInfo\0"
	int			unknownA;
	int			unknownB;

	int			dataSize;
	int			numEntries;
	int			numEntriesB;
	int			unknownF;

	int			meatOfsTableOfs;
	int			unknownH;
	int			unknownI;
	int			unknownJ;

	int			unknownXA;
	int			idx;
	int			unknownXB;
	int			unknownXC;

	objInfoMeat_t	firstMeat;
} objInfoHdr_t;

typedef struct tprVBufDecl_s
{
	int			unknownA;
	int			unknownB;
	int			unknownC;
	int			unknownD;

	int			unknownE;
	int			unknownF;
	int			dataOfs;
	int			dataSize;
} tprVBufDecl_t;
typedef struct tprIBufDecl_s
{
	WORD		unknownAA;
	WORD		unknownAB;
	int			unknownB;
	int			unknownC;
	int			unknownD;

	int			unknownE;
	int			unknownF;
	int			dataOfs;
	int			dataSize;
} tprIBufDecl_t;

typedef struct tprGeoHdr_s
{
	BYTE		id[8]; //"MdlGeo\0\0"
	int			unknownA;
	int			unknownB;
	int			unknownC;
	int			numObjects;
	int			numObjectsB; //???
	int			unknownD;
	int			unknownE;

	int			unknownF;
	int			unknownG;
	int			unknownH;

	//offset list for each object follows
} tprGeoHdr_t;

typedef struct tprGeoObj_s
{
	int			idx;
	int			unknownB;
	int			bufNum;
	int			unknownD;

	int			startIdx;
	int			numIdx;
	int			unknownG;
	int			unknownH;

	int			unknownI;
	int			unknownJ;
	int			unknownK;
	int			unknownL;

	int			unknownM;
	int			unknownN;
	int			unknownO;
	int			unknownP;

	int			unknownXA;
	int			unknownXB;
	int			unknownXC;
	int			unknownXD;

	int			unknownXE;
	int			unknownXF;
	int			unknownXG;
	int			unknownXH;

	int			unknownXI;
	int			unknownXJ;
	int			unknownXK;
	int			unknownXL;

	int			unknownXM;
	int			unknownXN;
	int			unknownXO;
	int			unknownXP;

	float		fdata[16];
} tprGeoObj_t;
typedef struct tprGeoObjHdr_s
{
	BYTE		id[8]; //"ObjGeo\0\0"
	int			unknownA;
	int			unknownB;

	int			dataSize;
	int			numOfs;
	int			numOfsB;
	int			unknownD;

	int			unknownE;
	int			unknownF;
	int			ofsToDecl;
	int			unknownG;

	int			unknownH;
	int			idx;
	int			unknownJ;
	int			unknownK;

	//offset list for each ? follows
} tprGeoObjHdr_t;

typedef struct tprGeoDecl_s
{
	BYTE		id[8]; //"GeoDecl\0"
	int			unknownA;
	int			unknownB;

	int			dataSize;
	int			numOfs;
	int			numOfsB;
	int			unknownD;

	int			unknownE;
	int			unknownF;
	int			unknownG;
	int			unknownH;

	//offset list for each decl follows
} tprGeoDecl_t;

typedef struct tprGeoElem_s
{
	WORD		morphIndex;
	WORD		elemOfs;
	short		unknownA;
	short		dataType;
	//int			dataOfs;
	short		elemID;
	short		unknownB;
} tprGeoElem_t;
typedef struct tprGeoElemHdr_s
{
	int			dataSize;
	int			numMorphs;
	int			idx;

	int			numIdx;
	int			numElems;
	int			numVerts;
	int			primIdxCount;
	int			unknownG;

	int			unknownH;
	int			unknownI;
	int			unknownJ;
	int			unknownK;

	//elem decls follow
} tprGeoElemHdr_t;

typedef struct gmdHdr_s
{
	BYTE			id[4]; //"GMD\0"
	int				unknownA;
	int				unknownB;
	int				unknownC;

	int				dataSize;
	int				unknownD;
	int				unknownE;
	int				unknownF;

	int				unknownG[4];

	int				unknownH;
	int				unknownI;
	int				xprOfs;
} gmdHdr_t;

//container for models and some other crap, used in ng2
static BYTE *Model_GetXPRFromGMD(BYTE *fileBuffer, int bufferLen, int &ofs)
{
	ofs = 0;
	if (bufferLen < sizeof(gmdHdr_t))
	{
		return NULL;
	}
	gmdHdr_t hdr = *((gmdHdr_t *)fileBuffer);
	if (memcmp(hdr.id, "GMD\0", 4))
	{
		return NULL;
	}
	LITTLE_BIG_SWAP(hdr.dataSize);
	LITTLE_BIG_SWAP(hdr.xprOfs);
	if (hdr.dataSize < 0 || hdr.xprOfs < 0 ||
		hdr.dataSize > bufferLen || hdr.xprOfs >= bufferLen)
	{
		return NULL;
	}

	ofs = hdr.xprOfs;
	return fileBuffer + ofs;
}

//check if it's a tpr model
bool Model_IsTPR(BYTE *fileBuffer, int bufferLen)
{
	if (bufferLen < sizeof(tprHdr_t))
	{
		return false;
	}

	int gmdOfs = 0;
	BYTE *gmdXpr = Model_GetXPRFromGMD(fileBuffer, bufferLen, gmdOfs);
	if (gmdXpr)
	{
		fileBuffer = gmdXpr;
		bufferLen -= gmdOfs;
	}

	tprHdr_t hdr = *((tprHdr_t *)fileBuffer);
	LITTLE_BIG_SWAP(hdr.dataOfs);
	LITTLE_BIG_SWAP(hdr.subSize);
	LITTLE_BIG_SWAP(hdr.numEntries);
	if (memcmp(hdr.id, "XPR2", 4))
	{
		return false;
	}
	if (hdr.numEntries <= 0)
	{
		return false;
	}
	if (hdr.numEntries*(int)sizeof(tprEntry_t) >= bufferLen)
	{
		return false;
	}

	return true;
}

typedef struct tprTexDec_s
{
	int					unknownA;
	int					unknownB;
	int					unknownC;
	int					unknownD;
	int					unknownE;
	int					unknownF;
	int					unknownG;
	WORD				width; //(width - 0x8000) / 2 ?
	WORD				unknownH;
	int					texOfs;
	WORD				height; //(height+1) * 8
	WORD				unknownK;
	BYTE				unknownL[4];
	int					unknownM;
	int					unknownN;
} tprTexDec_t;

typedef enum
{
	TEXTYPE_RAW = 0,
	TEXTYPE_DXT1,
	TEXTYPE_DXT3,
	TEXTYPE_DXT5,
	NUM_TEXTYPES
} tprTexType_e;
typedef struct tprTexInMem_s
{
	BYTE				*data;
	int					fmt;
	int					w;
	int					h;

	int					glTex;
} tprTexInMem_t;

static BYTE *Model_TPR_DecodeTex(tprTexInMem_t *tex)
{
	int w = tex->w;
	int h = tex->h;
	if (tex->fmt == TEXTYPE_RAW)
	{
		int bytesPP = 4;
		int mipSize = (w*h)*bytesPP;
		BYTE *imgData = tex->data;
		BYTE *imgDataFmt = (BYTE *)unpooled_malloc(mipSize, 93932);
		//memcpy(imgDataFmt, imgData, mipSize);
		Image_UntileRAW(imgDataFmt, imgData, mipSize, w, h, bytesPP);

		//now perform endian swap on the whole thing
		int swapCount = bytesPP;
		for (int i = 0; i < mipSize-swapCount; i += swapCount)
		{
			BYTE *dst = imgDataFmt+i;
			BYTE a = dst[0];
			dst[0] = dst[1];
			dst[1] = dst[2];
			dst[2] = dst[3];
			dst[3] = a;
			//LittleBigSwap(imgDataFmt+i, swapCount);
		}

		return imgDataFmt;
	}
	else if (tex->fmt == TEXTYPE_DXT1 || tex->fmt == TEXTYPE_DXT3 || tex->fmt == TEXTYPE_DXT5)
	{
		int dxtFmt = (tex->fmt == TEXTYPE_DXT1) ? 1 : 5;
		if (tex->fmt == TEXTYPE_DXT3)
		{
			dxtFmt = 3;
		}

		int mipSize = (dxtFmt == 1) ? (w*h)/2 : (w*h);
		BYTE *imgData = tex->data;
		BYTE *imgDataFmt = (BYTE *)unpooled_malloc(mipSize, 93932);
		//memcpy(imgDataFmt, imgData, mipSize);
		Image_UntileDXT(imgDataFmt, imgData, mipSize, w, h, (dxtFmt == 1) ? 8 : 16);

		//now perform endian swap on the whole thing
		int swapCount = 2;//(dxtFmt == 1) ? 2 : 4;
		for (int i = 0; i < mipSize-swapCount; i += swapCount)
		{
			LittleBigSwap(imgDataFmt+i, swapCount);
		}

		return imgDataFmt;
	}

	return NULL;
}

//export texture data
static void Model_TPR_WriteTextures(CArrayList<tprTexInMem_t> &textures)
{
	if (!g_outFileName)
	{
		return;
	}

	for (int i = 0; i < textures.Num(); i++)
	{
		tprTexInMem_t *tex = &textures[i];

		char fname[8192];
		GetDirForFilePath(fname, g_outFileName);
		char nameStr[512];
		sprintf(nameStr, ".\\%stprtex%03i", g_mo.texNamePrep, i);
		strcat(fname, nameStr);

		BYTE *decTex = Model_TPR_DecodeTex(tex);
		if (!decTex)
		{
			continue;
		}
		if (tex->fmt == TEXTYPE_RAW)
		{
			int bytesPerPixel = 4;
			strcat(fname, ".png");
			printf("Writing '%s'.\n", fname);
			Image_WriteRaw(decTex, tex->w, tex->h, (bytesPerPixel == 4) ? true : false, fname, -1);
		}
		else if (tex->fmt == TEXTYPE_DXT1 || tex->fmt == TEXTYPE_DXT3 || tex->fmt == TEXTYPE_DXT5)
		{
			int dxtFmt = (tex->fmt == TEXTYPE_DXT1) ? 1 : 5;
			if (tex->fmt == TEXTYPE_DXT3)
			{
				dxtFmt = 3;
			}

			strcat(fname, ".dds");
			printf("Writing '%s'.\n", fname);
			FILE *fw = fopen(fname, "wb");
			if (fw)
			{
				Image_WriteDDSData(fw, decTex, tex->w, tex->h, 0, dxtFmt);
				fclose(fw);
			}
		}

		unpooled_free(decTex);
	}
}

//upload texture data
static void Model_TPR_UploadTextures(CArrayList<tprTexInMem_t> &textures)
{
	if (!g_glExt.glCompressedTexImage2DARB)
	{
		return;
	}

	int texBase = 2;
	int numTex = 0;

	for (int i = 0; i < textures.Num(); i++)
	{
		tprTexInMem_t *tex = &textures[i];
		if (!tex->data)
		{
			continue;
		}

		int compGLFormat = -1;
		bool notCompressed = false;
		switch(tex->fmt)
		{
		case TEXTYPE_DXT1:
			compGLFormat = GL_COMPRESSED_RGBA_S3TC_DXT1_EXT;
			break;
		case TEXTYPE_DXT3:
			compGLFormat = GL_COMPRESSED_RGBA_S3TC_DXT3_EXT;
			break;
		case TEXTYPE_DXT5:
			compGLFormat = GL_COMPRESSED_RGBA_S3TC_DXT5_EXT;
			break;
		case TEXTYPE_RAW:
			notCompressed = true;
			compGLFormat = GL_RGBA;
			break;
		default:
			break;
		}
		if (compGLFormat == -1)
		{
			continue;
		}

		BYTE *decTex = Model_TPR_DecodeTex(tex);
		if (!decTex)
		{
			continue;
		}

		tex->glTex = texBase+numTex;
		numTex++;
		glBindTexture(GL_TEXTURE_2D, tex->glTex);

		int mipCount = 1;
		int w = tex->w;
		int h = tex->h;
		if (notCompressed)
		{
			glTexImage2D(GL_TEXTURE_2D, 0, compGLFormat, w, h, 0, compGLFormat, GL_UNSIGNED_BYTE, decTex);
		}
		else
		{
			int blockSize = (compGLFormat == GL_COMPRESSED_RGBA_S3TC_DXT1_EXT) ? 8 : 16;
			int offset = 0;
			int i = 0;
			while (i < mipCount)
			{
				if (!w)
				{
					w = 1;
				}
				if (!h)
				{
					h = 1;
				}

				int size = ((w+3)/4)*((h+3)/4)*blockSize;
				g_glExt.glCompressedTexImage2DARB(GL_TEXTURE_2D, i, compGLFormat, w, h,
					0, size, decTex+offset);
				offset += size;
				w = w/2;
				h = h/2;

				i++;
			}
		}

		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		if (mipCount <= 1)
		{
			glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
			glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		}
		else
		{
			glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
			glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		}

		unpooled_free(decTex);
	}
}

#define MAX_TECMO_WEIGHTS		4
typedef struct meshIntrVert_s
{
	float				pos[3];
	float				normal[3];
	float				uv[2];
	float				weights[MAX_TECMO_WEIGHTS];
} meshIntrVert_t;

typedef struct morphVerts_s
{
	int					bufNum;
	int					vertSize;

	meshIntrVert_t		*verts;
	int					numVerts;
} morphVerts_t;

typedef struct tprGeoElemInMem_s
{
	tprGeoElemHdr_t		hdr;
	tprGeoElem_t		*e;
	int					num;
	int					vertSize;
	int					vertBufNum;
	morphVerts_t		*morphInfo;
	int					numMorphs;

	meshIntrVert_t		*lerpedVerts;

	meshIntrVert_t		*verts;
	int					numVerts;
	WORD				*idx;
	int					numIdx;

	int					numWeights;

	bool				noUV;
} tprGeoElemInMem_t;

typedef struct tprMeshDrawSeg_s
{
	tprGeoObj_t			hdr;
	int					texIdx;
	int					unknownIdx;

	WORD				*segIdx;
	int					numIdx;
} tprMeshDrawSeg_t;

typedef struct tprHeiBone_s
{
	short				hieIdx;
	short				hieParent;
	modelMatrix_t		hieMat;
	modelMatrix_t		hieMatTrans;
	int					hieTCount;
} tprHeiBone_t;

typedef struct tprMeshInMem_s
{
	tprGeoDecl_t		hdr;
	objInfoHdr_t		infoHdr;

	tprGeoElemInMem_t	*elems;
	int					numElem;

	objInfoMeat_t		*infoMeats;
	int					numMeats;

	tprMeshDrawSeg_t	*drawSegs;
	int					numDrawSeg;

	int					hieBoneIdx;
} tprMeshInMem_t;

typedef struct tprHieHdr_s
{
	BYTE				id[8]; //"Hie\0\0\0\0\0"
	int					unknownA;
	int					unknownB;

	int					dataSize;
	int					numEntries;
	int					numEntriesB;
	int					unknownC;

	int					unknownD;
	int					unknownE;
	int					unknownF;
	int					unknownG;
} tprHieHdr_t;
//load hierarchy
static void Model_TPR_LoadMeshHierarchy(tprHdr_t *hdr, BYTE *fileBuffer, BYTE *declMem, CArrayList<tprMeshInMem_t> &meshes,
										CArrayList<tprHeiBone_t> &bones)
{
	int ofs = 0;
	tprHieHdr_t hieHdr = *((tprHieHdr_t *)(declMem+ofs));
	LITTLE_BIG_SWAP(hieHdr.unknownA);
	LITTLE_BIG_SWAP(hieHdr.unknownB);
	LITTLE_BIG_SWAP(hieHdr.dataSize);
	LITTLE_BIG_SWAP(hieHdr.numEntries);
	LITTLE_BIG_SWAP(hieHdr.numEntriesB);
	LITTLE_BIG_SWAP(hieHdr.unknownC);
	LITTLE_BIG_SWAP(hieHdr.unknownD);
	LITTLE_BIG_SWAP(hieHdr.unknownE);
	LITTLE_BIG_SWAP(hieHdr.unknownF);
	LITTLE_BIG_SWAP(hieHdr.unknownG);
	ofs += sizeof(tprHieHdr_t);

	/*
	typedef struct boneAffect_s
	{
		int				numAffects;
		int				affectIdx[MAX_TECMO_AFFECTBONES];
	} boneAffect_t;
	boneAffect_t *affects = (boneAffect_t *)unpooled_malloc(sizeof(boneAffect_t)*hieHdr.numEntries, 9291);
	*/

	for (int i = 0; i < hieHdr.numEntries; i++)
	{
		int infoOfs = *((int *)(declMem+ofs));
		LITTLE_BIG_SWAP(infoOfs);
		ofs += sizeof(int);
		BYTE *hierarchyBuf = declMem + infoOfs;
		float modelMat[16];
		memcpy(modelMat, hierarchyBuf, sizeof(modelMat));
		for (int j = 0; j < 16; j++)
		{
			LITTLE_BIG_SWAP(modelMat[j]);
		}

		BYTE *parData = hierarchyBuf + sizeof(modelMat);

		tprHeiBone_t bone;
		memset(&bone, 0, sizeof(bone));
		bone.hieIdx = GetBigWord(*((WORD *)(parData+0)));
		bone.hieParent = GetBigWord(*((WORD *)(parData+2)));
		Math_4x4ToModelMat((fourxMatrix_t *)modelMat, &bone.hieMat);
		bone.hieMatTrans = g_identityMatrix;

		if (bone.hieIdx >= 0 && bone.hieIdx < meshes.Num())
		{
			tprMeshInMem_t *mesh = &meshes[bone.hieIdx];
			mesh->hieBoneIdx = i;
			/*
			affects[i].numAffects = GetBigWord(*((WORD *)(parData+4)));
			if (affects[i].numAffects > 0)
			{
				for (int j = 0; j < affects[i].numAffects; j++)
				{
					int affectIdx = GetBigWord(*((WORD *)(parData+6 + j*2)));
					affects[i].affectIdx[j] = affectIdx;
				}
			}
			*/
		}
		bones.Append(bone);
	}

	/*
	for (int i = 0; i < hieHdr.numEntries; i++)
	{
		tprHeiBone_t &bone = bones[i];

		if (affects[i].numAffects <= 0)
		{
			continue;
		}

		bone.numAffecting = affects[i].numAffects;
		for (int j = 0; j < affects[i].numAffects; j++)
		{
			bone.affecting[j] = affects[i].affectIdx[j];
		}
	}

	unpooled_free(affects);
	*/
}

//swap the meats!
static void Model_TPR_MeatSwap(objInfoMeat_t &meat)
{
	LITTLE_BIG_SWAP(meat.unknownA);
	LITTLE_BIG_SWAP(meat.unknownB);
	LITTLE_BIG_SWAP(meat.unknownC);
	LITTLE_BIG_SWAP(meat.unknownD);
	LITTLE_BIG_SWAP(meat.unknownE);
	LITTLE_BIG_SWAP(meat.unknownF);
	LITTLE_BIG_SWAP(meat.unknownG);
	LITTLE_BIG_SWAP(meat.unknownH);
	for (int k = 0; k < 12; k++)
	{
		LITTLE_BIG_SWAP(meat.fldata[k]);
	}
}

//load infos
static void Model_TPR_LoadMeshInfos(tprHdr_t *hdr, BYTE *fileBuffer, BYTE *declMem, CArrayList<tprMeshInMem_t> &meshes)
{
	int ofs = 0;
	mdlInfoHdr_t mdlInfo = *((mdlInfoHdr_t *)(declMem+ofs));
	LITTLE_BIG_SWAP(mdlInfo.unknownA);
	LITTLE_BIG_SWAP(mdlInfo.unknownB);
	LITTLE_BIG_SWAP(mdlInfo.dataSize);
	LITTLE_BIG_SWAP(mdlInfo.numObjInfo);
	LITTLE_BIG_SWAP(mdlInfo.numObjInfoB);
	LITTLE_BIG_SWAP(mdlInfo.unknownF);
	LITTLE_BIG_SWAP(mdlInfo.unknownG);
	LITTLE_BIG_SWAP(mdlInfo.unknownH);
	LITTLE_BIG_SWAP(mdlInfo.unknownI);
	LITTLE_BIG_SWAP(mdlInfo.unknownJ);
	ofs += sizeof(mdlInfoHdr_t);
	if (mdlInfo.numObjInfo != meshes.Num())
	{
		printf("WARNING: Mesh info size mismatch!\n");
		return;
	}

	for (int i = 0; i < mdlInfo.numObjInfo; i++)
	{
		int infoOfs = *((int *)(declMem+ofs));
		LITTLE_BIG_SWAP(infoOfs);
		ofs += sizeof(int);
		BYTE *objInfoBuf = declMem + infoOfs;
		if (!memcmp(objInfoBuf, "ObjInfo\0", 8))
		{
			objInfoHdr_t objInfo = *((objInfoHdr_t *)objInfoBuf);
			LITTLE_BIG_SWAP(objInfo.unknownA);
			LITTLE_BIG_SWAP(objInfo.unknownB);
			LITTLE_BIG_SWAP(objInfo.dataSize);
			LITTLE_BIG_SWAP(objInfo.numEntries);
			LITTLE_BIG_SWAP(objInfo.numEntriesB);
			LITTLE_BIG_SWAP(objInfo.unknownF);
			LITTLE_BIG_SWAP(objInfo.meatOfsTableOfs);
			LITTLE_BIG_SWAP(objInfo.unknownH);
			LITTLE_BIG_SWAP(objInfo.unknownI);
			LITTLE_BIG_SWAP(objInfo.unknownJ);
			LITTLE_BIG_SWAP(objInfo.unknownXA);
			LITTLE_BIG_SWAP(objInfo.idx);
			LITTLE_BIG_SWAP(objInfo.unknownXB);
			LITTLE_BIG_SWAP(objInfo.unknownXC);
			Model_TPR_MeatSwap(objInfo.firstMeat);

			meshes[i].infoHdr = objInfo;
			meshes[i].numMeats = objInfo.numEntries;
			meshes[i].infoMeats = (objInfoMeat_t *)rcmalloc(sizeof(objInfoMeat_t)*objInfo.numEntries, 4021);
			for (int j = 0; j < objInfo.numEntries; j++)
			{
				int meatOfs = *((int *)(objInfoBuf+objInfo.meatOfsTableOfs + sizeof(int)*j));
				LITTLE_BIG_SWAP(meatOfs);
				BYTE *meatBuf = objInfoBuf + meatOfs;
				objInfoMeat_t meat = *((objInfoMeat_t *)meatBuf);
				Model_TPR_MeatSwap(meat);
				meshes[i].infoMeats[j] = meat;
			}
		}
	}
}


//load objects
static void Model_TPR_LoadMeshObjects(tprHdr_t *hdr, BYTE *fileBuffer, BYTE *declMem, CArrayList<tprMeshInMem_t> &meshes)
{
	int ofs = 0;
	int mdlBase = 0;
	tprGeoHdr_t mdlDec = *((tprGeoHdr_t *)(declMem+ofs));
	ofs += sizeof(tprGeoHdr_t);
	LITTLE_BIG_SWAP(mdlDec.unknownA);
	LITTLE_BIG_SWAP(mdlDec.unknownB);
	LITTLE_BIG_SWAP(mdlDec.unknownC);
	LITTLE_BIG_SWAP(mdlDec.numObjects);
	LITTLE_BIG_SWAP(mdlDec.numObjectsB);
	LITTLE_BIG_SWAP(mdlDec.unknownD);
	LITTLE_BIG_SWAP(mdlDec.unknownE);
	LITTLE_BIG_SWAP(mdlDec.unknownF);
	LITTLE_BIG_SWAP(mdlDec.unknownG);
	LITTLE_BIG_SWAP(mdlDec.unknownH);

	int *objOffsets = (int *)unpooled_malloc(sizeof(int)*mdlDec.numObjects, 9392);
	memcpy(objOffsets, declMem+ofs, sizeof(int)*mdlDec.numObjects);
	ofs += sizeof(int)*mdlDec.numObjects;
	for (int i = 0; i < mdlDec.numObjects; i++)
	{
		LITTLE_BIG_SWAP(objOffsets[i]);
		BYTE *objGeo = (BYTE *)(declMem+mdlBase+objOffsets[i]);
		if (!memcmp(objGeo, "ObjGeo\0\0", 8))
		{
			tprGeoObjHdr_t geo = *((tprGeoObjHdr_t *)objGeo);
			LITTLE_BIG_SWAP(geo.unknownA);
			LITTLE_BIG_SWAP(geo.unknownB);
			LITTLE_BIG_SWAP(geo.dataSize);
			LITTLE_BIG_SWAP(geo.numOfs);
			LITTLE_BIG_SWAP(geo.numOfsB);
			LITTLE_BIG_SWAP(geo.unknownD);
			LITTLE_BIG_SWAP(geo.unknownE);
			LITTLE_BIG_SWAP(geo.unknownF);
			LITTLE_BIG_SWAP(geo.ofsToDecl);
			LITTLE_BIG_SWAP(geo.unknownH);
			LITTLE_BIG_SWAP(geo.idx);
			LITTLE_BIG_SWAP(geo.unknownJ);
			LITTLE_BIG_SWAP(geo.unknownK);
			BYTE *geoDeclBuf = (BYTE *)(objGeo+geo.ofsToDecl);
			if (!memcmp(geoDeclBuf, "GeoDecl\0", 8))
			{
				tprMeshInMem_t dstMesh;
				memset(&dstMesh, 0, sizeof(tprMeshInMem_t));
				dstMesh.hieBoneIdx = -1;
				tprGeoDecl_t geoDecl = *((tprGeoDecl_t *)geoDeclBuf);
				LITTLE_BIG_SWAP(geoDecl.unknownA);
				LITTLE_BIG_SWAP(geoDecl.unknownB);
				LITTLE_BIG_SWAP(geoDecl.dataSize);
				LITTLE_BIG_SWAP(geoDecl.numOfs);
				LITTLE_BIG_SWAP(geoDecl.numOfsB);
				LITTLE_BIG_SWAP(geoDecl.unknownD);
				LITTLE_BIG_SWAP(geoDecl.unknownE);
				LITTLE_BIG_SWAP(geoDecl.unknownF);
				LITTLE_BIG_SWAP(geoDecl.unknownG);
				LITTLE_BIG_SWAP(geoDecl.unknownH);

				dstMesh.hdr = geoDecl;

				dstMesh.elems = (tprGeoElemInMem_t *)rcmalloc(sizeof(tprGeoElemInMem_t)*geo.numOfs, 992);
				memset(dstMesh.elems, 0, sizeof(tprGeoElemInMem_t)*geo.numOfs);

				int *geoOfsA = (int *)unpooled_malloc(sizeof(int)*geo.numOfs, 3334);
				memcpy(geoOfsA, objGeo+sizeof(tprGeoObjHdr_t), sizeof(int)*geo.numOfs);
				for (int j = 0; j < geo.numOfs; j++)
				{
					LITTLE_BIG_SWAP(geoOfsA[j]);
				}
				int *geoDeclOfs = (int *)unpooled_malloc(sizeof(int)*geoDecl.numOfs, 3334);
				memcpy(geoDeclOfs, geoDeclBuf+sizeof(tprGeoDecl_t), sizeof(int)*geoDecl.numOfs);

				dstMesh.elems = (tprGeoElemInMem_t *)rcmalloc(sizeof(tprGeoElemInMem_t)*geoDecl.numOfs, 3929);
				memset(dstMesh.elems, 0, sizeof(tprGeoElemInMem_t)*geoDecl.numOfs);
				for (int j = 0; j < geoDecl.numOfs; j++)
				{
					LITTLE_BIG_SWAP(geoDeclOfs[j]);
					BYTE *data = geoDeclBuf + geoDeclOfs[j];
					tprGeoElemHdr_t elemHdr = *((tprGeoElemHdr_t *)data);
					LITTLE_BIG_SWAP(elemHdr.dataSize);
					LITTLE_BIG_SWAP(elemHdr.numMorphs);
					LITTLE_BIG_SWAP(elemHdr.idx);
					LITTLE_BIG_SWAP(elemHdr.numIdx);
					LITTLE_BIG_SWAP(elemHdr.numElems);
					LITTLE_BIG_SWAP(elemHdr.numVerts);
					LITTLE_BIG_SWAP(elemHdr.primIdxCount);
					LITTLE_BIG_SWAP(elemHdr.unknownG);
					LITTLE_BIG_SWAP(elemHdr.unknownH);
					LITTLE_BIG_SWAP(elemHdr.unknownI);
					LITTLE_BIG_SWAP(elemHdr.unknownJ);
					LITTLE_BIG_SWAP(elemHdr.unknownK);

					tprGeoElemInMem_t *dstElem = &dstMesh.elems[dstMesh.numElem];
					dstMesh.numElem++;

					//BYTE *arData = geoDeclBuf + geoDecl.dataSize - 16*elemHdr.numMorphs;
					BYTE *arData = geoDeclBuf + geoDeclOfs[j] + elemHdr.dataSize;// - 16*elemHdr.numMorphs;
					int vertArNum = *((int *)(arData+0));
					int vertSize = *((int *)(arData+4));
					LITTLE_BIG_SWAP(vertArNum);
					LITTLE_BIG_SWAP(vertSize);
					dstElem->numMorphs = elemHdr.numMorphs-1;
					if (dstElem->numMorphs > 0)
					{
						dstElem->morphInfo = (morphVerts_t *)rcmalloc(sizeof(morphVerts_t)*dstElem->numMorphs, 9291);
						memset(dstElem->morphInfo, 0, sizeof(morphVerts_t)*dstElem->numMorphs);
						for (int i = 0; i < dstElem->numMorphs; i++)
						{
							//BYTE *morphArData = geoDeclBuf + geoDecl.dataSize - 16*elemHdr.numMorphs + 16*(i+1);
							BYTE *morphArData = geoDeclBuf + geoDeclOfs[j] + elemHdr.dataSize + 16*(i+1);
							int morphVertArNum = *((int *)(morphArData+0));
							int morphVertSize = *((int *)(morphArData+4));
							LITTLE_BIG_SWAP(morphVertArNum);
							LITTLE_BIG_SWAP(morphVertSize);

							morphVerts_t *mv = dstElem->morphInfo+i;
							mv->bufNum = morphVertArNum;
							mv->vertSize = morphVertSize;
						}
					}

					dstElem->vertSize = vertSize;
					dstElem->vertBufNum = vertArNum;
					dstElem->hdr = elemHdr;
					dstElem->e = (tprGeoElem_t *)rcmalloc(sizeof(tprGeoElem_t)*elemHdr.numElems, 9324);
					for (int k = 0; k < elemHdr.numElems; k++)
					{
						BYTE *elemData = geoDeclBuf + geoDeclOfs[j] + sizeof(tprGeoElemHdr_t) + sizeof(tprGeoElem_t)*k;
						tprGeoElem_t elem = *((tprGeoElem_t *)elemData);
						LITTLE_BIG_SWAP(elem.elemOfs);
						LITTLE_BIG_SWAP(elem.morphIndex);
						LITTLE_BIG_SWAP(elem.unknownA);
						LITTLE_BIG_SWAP(elem.dataType);
						LITTLE_BIG_SWAP(elem.elemID);
						LITTLE_BIG_SWAP(elem.unknownB);
						if (elem.unknownA == -1)
						{
							continue;
						}

						dstElem->e[dstElem->num] = elem;
						dstElem->num++;
					}
				}

				dstMesh.drawSegs = (tprMeshDrawSeg_t *)rcmalloc(sizeof(tprMeshDrawSeg_t)*geo.numOfs, 9392);
				memset(dstMesh.drawSegs, 0, sizeof(tprMeshDrawSeg_t)*geo.numOfs);
				dstMesh.numDrawSeg = geo.numOfs;
				for (int j = 0; j < geo.numOfs; j++)
				{
					BYTE *objData = objGeo + geoOfsA[j];
					tprGeoObj_t obj = *((tprGeoObj_t *)objData);
					LITTLE_BIG_SWAP(obj.idx);
					LITTLE_BIG_SWAP(obj.unknownB);
					LITTLE_BIG_SWAP(obj.bufNum);
					LITTLE_BIG_SWAP(obj.unknownD);

					LITTLE_BIG_SWAP(obj.startIdx);
					LITTLE_BIG_SWAP(obj.numIdx);
					LITTLE_BIG_SWAP(obj.unknownG);
					LITTLE_BIG_SWAP(obj.unknownH);

					LITTLE_BIG_SWAP(obj.unknownI);
					LITTLE_BIG_SWAP(obj.unknownJ);
					LITTLE_BIG_SWAP(obj.unknownK);
					LITTLE_BIG_SWAP(obj.unknownL);

					LITTLE_BIG_SWAP(obj.unknownM);
					LITTLE_BIG_SWAP(obj.unknownN);
					LITTLE_BIG_SWAP(obj.unknownO);
					LITTLE_BIG_SWAP(obj.unknownP);

					LITTLE_BIG_SWAP(obj.unknownXA);
					LITTLE_BIG_SWAP(obj.unknownXB);
					LITTLE_BIG_SWAP(obj.unknownXC);
					LITTLE_BIG_SWAP(obj.unknownXD);
					LITTLE_BIG_SWAP(obj.unknownXE);
					LITTLE_BIG_SWAP(obj.unknownXF);
					LITTLE_BIG_SWAP(obj.unknownXG);
					LITTLE_BIG_SWAP(obj.unknownXH);
					LITTLE_BIG_SWAP(obj.unknownXI);
					LITTLE_BIG_SWAP(obj.unknownXJ);
					LITTLE_BIG_SWAP(obj.unknownXK);
					LITTLE_BIG_SWAP(obj.unknownXL);
					LITTLE_BIG_SWAP(obj.unknownXM);
					LITTLE_BIG_SWAP(obj.unknownXN);
					LITTLE_BIG_SWAP(obj.unknownXO);
					LITTLE_BIG_SWAP(obj.unknownXP);

					for (int k = 0; k < 16; k++)
					{
						LITTLE_BIG_SWAP(obj.fdata[k]);
					}

					BYTE *texObjBuf = objData + obj.unknownH;
					int texIdx = *((int *)(texObjBuf+8));
					LITTLE_BIG_SWAP(texIdx);
					int unknownIdx = *((int *)(texObjBuf+4));
					LITTLE_BIG_SWAP(unknownIdx);

					dstMesh.drawSegs[j].hdr = obj;
					dstMesh.drawSegs[j].texIdx = texIdx;
					dstMesh.drawSegs[j].unknownIdx = unknownIdx;
				}

				meshes.Append(dstMesh);

				unpooled_free(geoOfsA);
				unpooled_free(geoDeclOfs);
			}
		}
	}

	unpooled_free(objOffsets);
}

//load texture declaration
static void Model_TPR_LoadTexDecl(tprHdr_t *hdr, BYTE *fileBuffer, BYTE *declMem,
								  CArrayList<tprTexInMem_t> &textures)
{
	tprTexDec_t texDec = *((tprTexDec_t *)declMem);
	LITTLE_BIG_SWAP(texDec.unknownA);
	LITTLE_BIG_SWAP(texDec.unknownB);
	LITTLE_BIG_SWAP(texDec.width);
	LITTLE_BIG_SWAP(texDec.unknownH);
	LITTLE_BIG_SWAP(texDec.texOfs);
	LITTLE_BIG_SWAP(texDec.height);
	LITTLE_BIG_SWAP(texDec.unknownK);
	//LITTLE_BIG_SWAP(texDec.unknownL);
	LITTLE_BIG_SWAP(texDec.unknownM);
	LITTLE_BIG_SWAP(texDec.unknownN);

	int ofs = hdr->dataOfs + texDec.texOfs - (texDec.texOfs%2048) + 12;

	int w = ((int)texDec.width - 0x8000) / 2;
	int h = ((int)texDec.height+1) * 8;
	int n = 57471-texDec.unknownK;
	//hell, i don't know, but it works
	w = (texDec.unknownK & (w-1)) + 1;

	tprTexInMem_t tex;
	memset(&tex, 0, sizeof(tex));
	tex.fmt = 0;
	int imgFmt = (texDec.texOfs%2048); //what the jesus
	tex.w = w;
	tex.h = h;
	if (imgFmt == 134)//texDec.unknownL[3] == 20)
	{
		tex.fmt = TEXTYPE_RAW;
	}
	else if (imgFmt == 84)
	{
		tex.fmt = TEXTYPE_DXT5;
	}
	else if (imgFmt == 83)
	{
		tex.fmt = TEXTYPE_DXT3;
	}
	else if (imgFmt == 82)
	{
		tex.fmt = TEXTYPE_DXT1;
	}
	else
	{
		tex.fmt = TEXTYPE_DXT1;
		printf("Unknown image format: %i\n", imgFmt);
		tex.w = 8;
		tex.h = 8;
	}
	tex.data = fileBuffer + ofs;
	textures.Append(tex);
}

//get elem by type
//god this is getting horrible, i should stop calling the unique sub-decl meshes "elements"
static tprGeoElem_t *Model_TPR_GetElemID(tprGeoElemInMem_t *elem, int id, int dataType, int ub, int morphIndex = 0);
static tprGeoElem_t *Model_TPR_GetElemID(tprGeoElemInMem_t *elem, int id, int dataType, int ub, int morphIndex)
{
	for (int j = 0; j < elem->num; j++)
	{
		tprGeoElem_t *e = elem->e+j;
		if (e->morphIndex == morphIndex && e->elemID == id && (e->dataType == dataType || dataType < 0) &&
			(e->unknownB == ub || !ub))
		{
			return e;
		}
	}
	return NULL;
}

//convert to float
static void Model_TPR_ConvertElemToFloat(BYTE *vertBase, float *dst, int numComponents, tprGeoElem_t *elem, bool scaleBias = false, bool flip = false);
static void Model_TPR_ConvertElemToFloat(BYTE *vertBase, float *dst, int numComponents, tprGeoElem_t *elem, bool scaleBias, bool flip)
{
	if (!elem)
	{
		memset(dst, 0, sizeof(float)*numComponents);
		return;
	}

	if (elem->dataType == 9125 || elem->dataType == 9145 || elem->dataType == 9126)
	{
		float *src = (float *)(vertBase + elem->elemOfs);
		memcpy(dst, src, sizeof(float)*numComponents);
		for (int i = 0; i < numComponents; i++)
		{
			LITTLE_BIG_SWAP(dst[i]);
		}
	}
	else if (elem->dataType == 8592)
	{
		assert(numComponents == 3);
		BYTE *src = (BYTE *)(vertBase + elem->elemOfs);
		DWORD r;
		memcpy(&r, src, sizeof(r));
		LITTLE_BIG_SWAP(r);
		int xBits = 11;
		int yBits = 11;
		int zBits = 10;
		int x = (r & ((1<<xBits)-1));
		int y = ((r>>xBits) & ((1<<yBits)-1));
		int z = ((r>>(xBits+yBits)) & ((1<<zBits)-1));
#if 0
		dst[0] = (float)x / (float)((1<<xBits)-1);
		dst[1] = (float)y / (float)((1<<yBits)-1);
		dst[2] = (float)z / (float)((1<<zBits)-1);
		dst[0] = (dst[0]*2.0f)-1.0f;
		dst[1] = (dst[1]*2.0f)-1.0f;
		dst[2] = (dst[2]*2.0f)-1.0f;
#else
		dst[0] = (float)SignedBits(x, xBits) / (float)((1<<(xBits-1))-1);
		dst[1] = (float)SignedBits(y, yBits) / (float)((1<<(yBits-1))-1);
		dst[2] = (float)SignedBits(z, zBits) / (float)((1<<(zBits-1))-1);
#endif
		Math_VecNorm(dst);
	}
	else if (0)//(elem->dataType == 8592)
	{
		short *src = (short *)(vertBase + elem->elemOfs);
		for (int i = 0; i < numComponents; i++)
		{
			short w = src[i];
			LITTLE_BIG_SWAP(w);
			dst[i] = (float)w / 32767.0f;
		}
	}
	else if (0)//elem->dataType == 8592)
	{
		WORD *src = (WORD *)(vertBase + elem->elemOfs);
		for (int i = 0; i < numComponents; i++)
		{
			WORD w = src[i];
			LITTLE_BIG_SWAP(w);
			dst[i] = (float)w / 65535.0f;
		}
	}
	else if (elem->dataType == 9055)
	{
		WORD *src = (WORD *)(vertBase + elem->elemOfs);
		for (int i = 0; i < numComponents; i++)
		{
			WORD w = src[i];
			LITTLE_BIG_SWAP(w);
			dst[i] = Math_GetFloat16(w);
		}
	}
	else if (elem->dataType == 10374)
	{
		BYTE *src = (BYTE *)(vertBase + elem->elemOfs);
		for (int i = 0; i < numComponents; i++)
		{
			BYTE c = src[i];
			dst[i] = (float)c / 255.0f;
		}
	}
	else if (0)//(elem->dataType == 8592)
	{
		char *src = (char *)(vertBase + elem->elemOfs);
		for (int i = 0; i < numComponents; i++)
		{
			char c = src[i];
			dst[i] = (float)c / 127.0f;
		}
	}

	if (scaleBias)
	{
		for (int i = 0; i < numComponents; i++)
		{
			dst[i] = (dst[i]*2.0f)-1.0f;
		}
	}
	if (flip)
	{
		for (int i = 0; i < numComponents; i++)
		{
			dst[i] = -dst[i];
		}
	}
}


//build a trilist for whichever index format the model's using
static void Model_TPR_BuildTriList(WORD *idxSrc, WORD *idxDst, int numSrcIdx, int &numDstIdx, int primType)
{
	numDstIdx = 0;
	int srcCount = 0;
	int contPrim = 0;
	bool flipFlag = false;
	while (srcCount < numSrcIdx)
	{
		if (primType == 1)
		{ //strips
			WORD *dst = idxDst + numDstIdx;
			WORD *src = idxSrc + srcCount;
			if (src[0] == 0xFFFF)
			{
				flipFlag = false;
				contPrim = 0;
				srcCount++;
				continue;
			}
			if (contPrim >= 3)
			{
				if (!flipFlag)
				{
					dst[2] = GetBigWord(src[-2]);
					dst[1] = GetBigWord(src[-1]);
					dst[0] = GetBigWord(src[0]);
				}
				else
				{
					dst[0] = GetBigWord(src[-2]);
					dst[1] = GetBigWord(src[-1]);
					dst[2] = GetBigWord(src[0]);
				}
				flipFlag = !flipFlag;
				numDstIdx += 3;
			}
			else
			{
				dst[0] = src[0];
				LITTLE_BIG_SWAP(dst[0]);
				numDstIdx++;
			}
			srcCount++;
			contPrim++;
		}
		else
		{ //list
			WORD *dst = idxDst + numDstIdx;
			WORD *src = idxSrc + srcCount;
			if (src[0] == 0xFFFF)
			{
				srcCount++;
				continue;
			}
			dst[0] = src[0];
			LITTLE_BIG_SWAP(dst[0]);
			srcCount++;
			numDstIdx++;
		}
	}
}

//transform bone
static void Model_TPR_TransformBone(CArrayList<tprHeiBone_t> &bones, tprHeiBone_t *bone, int tcount)
{
	if (bone->hieTCount == tcount)
	{
		return;
	}

	bone->hieTCount = tcount;
	if (bone->hieParent >= 0)
	{
		Model_TPR_TransformBone(bones, &bones[bone->hieParent], tcount);
	}

	if (bone->hieParent < 0)
	{
		bone->hieMatTrans = bone->hieMat;
	}
	else
	{
		Math_MatrixMultiply(&bones[bone->hieParent].hieMatTrans, &bone->hieMat, &bone->hieMatTrans);
	}
}

//assemble vertex/index buffers
static void Model_TPR_AssembleGeometry(BYTE *fileBuffer, CArrayList<tprMeshInMem_t> &meshes, CArrayList<tprTexInMem_t> &textures,
									CArrayList<tprVBufDecl_t> &vertBufs, CArrayList<tprIBufDecl_t> &idxBufs, CArrayList<tprHeiBone_t> &bones)
{
	for (int i = 0; i < meshes.Num(); i++)
	{
		tprMeshInMem_t *mesh = &meshes[i];
		if (mesh->hieBoneIdx >= 0)
		{
			Model_TPR_TransformBone(bones, &bones[mesh->hieBoneIdx], -1);
		}
		if (mesh->numElem <= 0)
		{
			continue;
		}
		for (int en = 0; en < mesh->numElem; en++)
		{
			tprGeoElemInMem_t *elem = mesh->elems+en;
			/*
			if (elem->hdr.primIdxCount != 3 && elem->hdr.primIdxCount != 1)
			{
				continue;
			}
			*/
			int bufIdx = elem->hdr.idx;
			int vertIdx = elem->vertBufNum;
			if (bufIdx >= idxBufs.Num() || vertIdx > vertBufs.Num())
			{
				printf("WARNING: Out of range buffer(s): %i/%i\n", bufIdx, vertIdx);
				continue;
			}

			tprGeoElem_t *posElem = Model_TPR_GetElemID(elem, 0/*9145*/, -1, 0);
			if (!posElem)
			{
				continue;
			}
			//10 == vertex color?
			tprGeoElem_t *uvElem = Model_TPR_GetElemID(elem, 5/*8592*/, -1, 0);
			tprGeoElem_t *nrmElem = Model_TPR_GetElemID(elem, 3/*8592*/, -1, 0);
			tprGeoElem_t *wgtElem = Model_TPR_GetElemID(elem, 1/*8592*/, -1, 0);
			if (!uvElem)
			{
				elem->noUV = true;
			}

			tprIBufDecl_t &idxBuf = idxBufs[bufIdx];
			tprVBufDecl_t &vertBuf = vertBufs[vertIdx];
			if (vertBuf.dataSize < elem->vertSize*elem->hdr.numVerts)
			{
				continue;
			}
			int idxOfs = idxBuf.dataOfs - (idxBuf.dataOfs%4);// + 57344; //16384
			int vertOfs = vertBuf.dataOfs - (vertBuf.dataOfs%4);// + 57344; //16384
			WORD *idxSrc = (WORD *)(fileBuffer+idxOfs);
			int vertSize = elem->vertSize;

			//int numTris = (elem->hdr.numIdx+1)/4;
			/*
			elem->numIdx = 0;
			int allocIdx = (elem->hdr.primIdxCount != 3) ? elem->hdr.numIdx*3 : elem->hdr.numIdx;
			elem->idx = (WORD *)rcmalloc(sizeof(WORD)*allocIdx, 8382);
			Model_TPR_BuildTriList(idxSrc, elem->idx, elem->hdr.numIdx, elem->numIdx, elem->hdr.primIdxCount);
			*/

			elem->numVerts = elem->hdr.numVerts;
			elem->verts = (meshIntrVert_t *)rcmalloc(sizeof(meshIntrVert_t)*elem->numVerts, 9390);
			memset(elem->verts, 0, sizeof(meshIntrVert_t)*elem->numVerts);
			for (int j = 0; j < elem->numVerts; j++)
			{
				BYTE *vertBase = (fileBuffer+vertOfs + vertSize*j);
				Model_TPR_ConvertElemToFloat(vertBase, elem->verts[j].pos, 3, posElem);
				Model_TPR_ConvertElemToFloat(vertBase, elem->verts[j].uv, 2, uvElem);
				Model_TPR_ConvertElemToFloat(vertBase, elem->verts[j].normal, 3, nrmElem);
				if (wgtElem)
				{
					if (wgtElem->dataType == 9125)
					{
						elem->numWeights = 2;
						Model_TPR_ConvertElemToFloat(vertBase, elem->verts[j].weights, 2, wgtElem);
					}
					else if (wgtElem->dataType == 9145)
					{
						elem->numWeights = 3;
						Model_TPR_ConvertElemToFloat(vertBase, elem->verts[j].weights, 3, wgtElem);
					}
					else if (wgtElem->dataType == 9126)
					{
						elem->numWeights = 4;
						Model_TPR_ConvertElemToFloat(vertBase, elem->verts[j].weights, 4, wgtElem);
					}
				}
				if (Math_VecLen(elem->verts[j].normal) <= 0.0f)
				{
					elem->verts[j].normal[0] = 0.0f;
					elem->verts[j].normal[1] = 0.0f;
					elem->verts[j].normal[2] = 1.0f;
				}
				Math_VecNorm(elem->verts[j].normal);

				assert(!FLOAT_IS_INVALID(elem->verts[j].pos[0]));
				assert(!FLOAT_IS_INVALID(elem->verts[j].pos[1]));
				assert(!FLOAT_IS_INVALID(elem->verts[j].pos[2]));
				//float t[3];
				//Math_VecCopy(elem->verts[j].pos, t);
				//Math_TransformPointByMatrix(&mesh->hieMat, t, elem->verts[j].pos);
			}

			for (int j = 0; j < elem->numMorphs; j++)
			{ //boobie morphs, teehee!
				morphVerts_t *mv = elem->morphInfo+j;
				tprGeoElem_t *posMorph = Model_TPR_GetElemID(elem, 0/*9145*/, -1, 0, /*j+1*/1);
				tprGeoElem_t *nrmMorph = Model_TPR_GetElemID(elem, 3/*8592*/, -1, 0, /*j+1*/1);
				if (mv->bufNum < 0 || mv->bufNum >= vertBufs.Num())
				{
					continue;
				}
				tprVBufDecl_t &morphBuf = vertBufs[mv->bufNum];
				if (morphBuf.dataSize < mv->vertSize*elem->hdr.numVerts)
				{
					continue;
				}
				int morphVertOfs = morphBuf.dataOfs - (morphBuf.dataOfs%4);

				mv->numVerts = elem->hdr.numVerts;
				mv->verts = (meshIntrVert_t *)rcmalloc(sizeof(meshIntrVert_t)*mv->numVerts, 9390);
				for (int j = 0; j < mv->numVerts; j++)
				{
					BYTE *vertBase = (fileBuffer+morphVertOfs + mv->vertSize*j);
					Model_TPR_ConvertElemToFloat(vertBase, mv->verts[j].pos, 3, posMorph);
					Model_TPR_ConvertElemToFloat(vertBase, mv->verts[j].normal, 3, nrmMorph);
					if (Math_VecLen(mv->verts[j].normal) <= 0.0f)
					{
						if (elem->numVerts == mv->numVerts)
						{ //share
							Math_VecCopy(elem->verts[j].normal, mv->verts[j].normal);
						}
						else
						{
							mv->verts[j].normal[0] = 0.0f;
							mv->verts[j].normal[1] = 0.0f;
							mv->verts[j].normal[2] = 1.0f;
						}
					}
					Math_VecNorm(mv->verts[j].normal);

					assert(!FLOAT_IS_INVALID(mv->verts[j].pos[0]));
					assert(!FLOAT_IS_INVALID(mv->verts[j].pos[1]));
					assert(!FLOAT_IS_INVALID(mv->verts[j].pos[2]));
				}
			}
		}

		for (int sn = 0; sn < mesh->numDrawSeg; sn++)
		{
			tprMeshDrawSeg_t *seg = mesh->drawSegs+sn;
			assert(seg->hdr.bufNum >= 0 && seg->hdr.bufNum < mesh->numElem);
			tprGeoElemInMem_t *elem = mesh->elems+seg->hdr.bufNum;
			tprIBufDecl_t &idxBuf = idxBufs[elem->hdr.idx];

			int idxOfs = idxBuf.dataOfs - (idxBuf.dataOfs%4);// + 57344; //16384
			WORD *idxSrc = (WORD *)(fileBuffer+idxOfs);

			seg->numIdx = 0;
			int allocIdx = seg->hdr.numIdx*3;
			seg->segIdx = (WORD *)rcmalloc(sizeof(WORD)*allocIdx, 8382);
			Model_TPR_BuildTriList(idxSrc+seg->hdr.startIdx, seg->segIdx, seg->hdr.numIdx, seg->numIdx, 1);
			assert(seg->numIdx < allocIdx);
		}
	}
}

//play with them boobies!
static void Model_TPR_FunWithBoobies(tprGeoElemInMem_t *elem, bool &newFrame)
{
	if (elem->numMorphs <= 0)
	{
		return;
	}
	if (elem->numMorphs < 6)
	{
		return;
	}
	//1 + 2 - in and out
	//0 + 3 - side to side
	//4 + 5 - up and down (like a pony would)
	static unsigned long lastAnimTime = 0;
	static float animFrac = 0.0f;
	static int pairType = 0;
	static unsigned long pairChangeTime = 0;
	if (newFrame)
	{
		unsigned long animTime = GetTickCount();
		if (!lastAnimTime)
		{
			lastAnimTime = animTime;
		}
		if (animTime > pairChangeTime)
		{
			pairChangeTime = animTime + 5000;
			pairType = (pairType+1)%3;
		}
		float dif = (float)animTime - (float)lastAnimTime;
		lastAnimTime = animTime;

		animFrac = fmodf(animFrac + dif*0.004f, (float)PI);
		newFrame = false;
	}

	int pairTable[3][2] =
	{
		{0, 3},
		{4, 5},
		{1, 2}
	};
	meshIntrVert_t *lerpFrom = elem->morphInfo[pairTable[pairType][0]].verts;
	meshIntrVert_t *lerpTo = elem->morphInfo[pairTable[pairType][1]].verts;
	if (!lerpFrom || !lerpTo)
	{
		return;
	}

	elem->lerpedVerts = (meshIntrVert_t *)rcmalloc(sizeof(meshIntrVert_t)*elem->numVerts, 9212);
	memset(elem->lerpedVerts, 0, sizeof(meshIntrVert_t)*elem->numVerts);
	float lerpFrac = fabsf(sinf(animFrac));
	for (int i = 0; i < elem->numVerts; i++)
	{
		float *dstPos = elem->lerpedVerts[i].pos;
		float *dstNrm = elem->lerpedVerts[i].normal;

		dstPos[0] = lerpFrom[i].pos[0] + (lerpTo[i].pos[0]-lerpFrom[i].pos[0])*lerpFrac;
		dstPos[1] = lerpFrom[i].pos[1] + (lerpTo[i].pos[1]-lerpFrom[i].pos[1])*lerpFrac;
		dstPos[2] = lerpFrom[i].pos[2] + (lerpTo[i].pos[2]-lerpFrom[i].pos[2])*lerpFrac;
		dstNrm[0] = lerpFrom[i].normal[0] + (lerpTo[i].normal[0]-lerpFrom[i].normal[0])*lerpFrac;
		dstNrm[1] = lerpFrom[i].normal[1] + (lerpTo[i].normal[1]-lerpFrom[i].normal[1])*lerpFrac;
		dstNrm[2] = lerpFrom[i].normal[2] + (lerpTo[i].normal[2]-lerpFrom[i].normal[2])*lerpFrac;
		Math_VecNorm(dstNrm);
	}
}

//convert model
static int Model_TPR_Convert(CArrayList<tprMeshInMem_t> &meshes, CArrayList<tprTexInMem_t> &textures,
									CArrayList<tprVBufDecl_t> &vertBufs, CArrayList<tprIBufDecl_t> &idxBufs,
									CArrayList<tprHeiBone_t> &bones)
{
	int totalMeshes = 0;
	modelMeshObject_t *rootObj = NULL;
	modelMeshObject_t **nobj = &rootObj;
	printf("Remapping TPR draw segments to unique surfaces...");
	for (int i = 0; i < meshes.Num(); i++)
	{
		tprMeshInMem_t *mesh = &meshes[i];
		if (mesh->numDrawSeg <= 0)
		{
			continue;
		}

		totalMeshes += mesh->numDrawSeg;
		for (int j = 0; j < mesh->numDrawSeg; j++)
		{
			tprMeshDrawSeg_t *seg = mesh->drawSegs+j;
			assert(seg->hdr.bufNum >= 0 && seg->hdr.bufNum < mesh->numElem);
			tprGeoElemInMem_t *elem = mesh->elems+seg->hdr.bufNum;
			if (seg->numIdx <= 0 || elem->numVerts <= 0)
			{
				continue;
			}

			int vertBase = 0;

			int *remappedVerts = (int *)unpooled_malloc(sizeof(int)*elem->numVerts, 3882);
			WORD *remappedIdx = (WORD *)unpooled_malloc(sizeof(WORD)*seg->numIdx, 3882);
			int numRemapped = 0;
			for (int k = 0; k < elem->numVerts; k++)
			{
				remappedVerts[k] = -1;
			}

			for (int k = 0; k < seg->numIdx; k++)
			{
				WORD *idx = seg->segIdx + k;//(mesh->idx + seg->idxStart*3 + k);
				WORD *newIdx = remappedIdx+k;
				bool alreadyHas = false;
				for (int n = 0; n < numRemapped; n++)
				{
					if (remappedVerts[n] == *idx)
					{
						assert(n < 65536);
						*newIdx = (WORD)n;
						alreadyHas = true;
						break;
					}
				}
				if (alreadyHas)
				{
					continue;
				}
				assert(numRemapped < elem->numVerts);
				remappedVerts[numRemapped] = *idx;
				*newIdx = (WORD)numRemapped;
				numRemapped++;
			}

			modelMeshObject_t *newMesh = (modelMeshObject_t *)rcmalloc(sizeof(modelMeshObject_t), 3925);
			memset(newMesh, 0, sizeof(modelMeshObject_t));
			if (seg->texIdx >= 0 && seg->texIdx < textures.Num())
			{
				sprintf(newMesh->meshData.skinName, "%stprtex%03i", g_mo.texNamePrep, seg->texIdx);
			}
			else
			{
				strcpy(newMesh->meshData.skinName, "tprtex000");
			}
			newMesh->meshData.numVerts = numRemapped;
			newMesh->meshData.numFaces = seg->numIdx/3;
			newMesh->meshData.vertData = (BYTE *)rcmalloc(sizeof(modelVert_t)*numRemapped, 3924);
			newMesh->meshData.uvCoord = (BYTE *)rcmalloc(sizeof(modelTexCoord_t)*numRemapped, 3924);
			newMesh->meshData.vertNormals = (float *)rcmalloc(sizeof(modelVert_t)*numRemapped, 3924);
			modelVert_t *dstPositions = (modelVert_t *)newMesh->meshData.vertData;
			modelTexCoord_t *dstUVs = (modelTexCoord_t *)newMesh->meshData.uvCoord;
			modelVert_t *dstNormals = (modelVert_t *)newMesh->meshData.vertNormals;
			modelVertWeight_t *dstWeights = NULL;
			modelVertWInfo_t *dstWInfos = NULL;
			int numWeights = 0;
			if (bones.Num() > 0)
			{
				newMesh->meshData.vertWeights = (modelVertWeight_t *)rcmalloc(sizeof(modelVertWeight_t)*elem->numVerts*4, 2912);
				dstWeights = newMesh->meshData.vertWeights;
				newMesh->meshData.vertWInfo = (modelVertWInfo_t *)rcmalloc(sizeof(modelVertWInfo_t)*elem->numVerts, 2833);
				dstWInfos = newMesh->meshData.vertWInfo;
			}
			for (int k = 0; k < numRemapped; k++)
			{
				meshIntrVert_t *src = elem->verts + remappedVerts[k];
				modelVert_t *dstPos = dstPositions + k;
				modelTexCoord_t *dstUV = dstUVs + k;
				modelVert_t *dstNrm = dstNormals + k;

				if (bones.Num() > 0)
				{
					Math_TransformPointByMatrix(&bones[mesh->hieBoneIdx].hieMatTrans, src->pos, &dstPos->x);
				}
				else
				{
					dstPos->x = src->pos[0];
					dstPos->y = src->pos[1];
					dstPos->z = src->pos[2];
				}
				dstUV->u = src->uv[0];
				dstUV->v = src->uv[1];
				dstNrm->x = src->normal[0];
				dstNrm->y = src->normal[1];
				dstNrm->z = src->normal[2];
				if (dstWeights)
				{
					modelVertWeight_t *dstWeight = dstWeights + numWeights;
					modelVertWInfo_t *dstWInfo = dstWInfos + k;
					dstWInfo->weightIndex = numWeights;
					dstWInfo->numWeights = 0;
					tprHeiBone_t *wBone = &bones[mesh->hieBoneIdx];
					int boneIdx[4] = {mesh->hieBoneIdx, -1, -1, -1};
					float boneWeights[4] = {1.0f, 0.0f, 0.0f, 0.0f};
					for (int n = 0; n < elem->numWeights; n++)
					{
						boneIdx[n] = mesh->hieBoneIdx;
						boneWeights[n] = src->weights[n];
					}
					float totalWeight = 0.0f;
					for (int w = 0; w < 4; w++)
					{
						if (boneIdx[w] < 0)
						{
							break;
						}
						dstWeight[w].boneIndex = boneIdx[w];
						dstWeight[w].index = numWeights;
						Math_VecCopy(&dstPos->x, dstWeight[w].pos);
						dstWeight[w].weightFactor = boneWeights[w];
						totalWeight += boneWeights[w];
						numWeights++;
						dstWInfo->numWeights++;
					}
					assert(fabsf(totalWeight-1.0f) < 0.01f);
				}
			}
			newMesh->meshData.numWeights = numWeights;
			newMesh->meshData.faceData = (BYTE *)rcmalloc(sizeof(modelTriFace_t)*(seg->numIdx/3), 9491);
			modelTriFace_t *dstFaces = (modelTriFace_t *)newMesh->meshData.faceData;
			for (int k = 0; k < seg->numIdx/3; k++)
			{
				WORD *srcIdx = remappedIdx + k*3;

				dstFaces[k].a = srcIdx[0];
				dstFaces[k].b = srcIdx[1];
				dstFaces[k].c = srcIdx[2];
				dstFaces[k].flag = 0;
			}

			*nobj = newMesh;
			nobj = &newMesh->next;

			unpooled_free(remappedVerts);
			unpooled_free(remappedIdx);
		}
	}
	printf("Done.\n");
	if (totalMeshes < 0 || !rootObj)
	{
		return -1;
	}

	if (bones.Num() > 0 && g_mo.exportSkeletal)
	{
		rootObj->meshData.numBones = bones.Num();
		rootObj->meshData.bones = (modelBone_t *)rcmalloc(sizeof(modelBone_t)*bones.Num(), 192);
		memset(rootObj->meshData.bones, 0, sizeof(modelBone_t)*bones.Num());

		for (int i = 0; i < bones.Num(); i++)
		{
			modelBone_t *dstBone = rootObj->meshData.bones+i;
			sprintf(dstBone->name, "bone%03i", i);
		}

		for (int i = 0; i < bones.Num(); i++)
		{ //copy/convert bones to universal format
			tprHeiBone_t *srcBone = &bones[i];
			modelBone_t *dstBone = rootObj->meshData.bones+i;
			dstBone->index = i;
			dstBone->mat = srcBone->hieMatTrans;
			//strcpy(dstBone->name, srcBone->name);

			if (g_mo.transformMatValid)
			{
				modelMatrix_t t;
				Math_MatrixMultiply(&g_mo.transformMat, &dstBone->mat, &t);
				dstBone->mat = t;
			}
			if (g_mo.posOffsetValid)
			{
				dstBone->mat.o[0] += g_mo.posOffset[0];
				dstBone->mat.o[1] += g_mo.posOffset[1];
				dstBone->mat.o[2] += g_mo.posOffset[2];
			}

			if (srcBone->hieParent >= 0)
			{
				strcpy(dstBone->parentName, rootObj->meshData.bones[srcBone->hieParent].name);
				dstBone->eData.parent = rootObj->meshData.bones+srcBone->hieParent;
			}
			else
			{
				dstBone->parentName[0] = 0;
			}
		}
	}

#ifdef _DEBUG //hax
	g_mo.noNeighbors = true;
#endif
	int rdmI = 0;
	Model_GenericExportPath(rootObj, rdmI);

	return rdmI;
}

//preview tpr
extern float g_objPos[3];
extern float g_objAng[3];
extern bool g_recenterModel;
extern float g_moveScale;
static bool g_enableTPRLighting = false;
static bool g_tprFaceCull = false;
extern char *g_inFileName;
bool g_tprTransparency = true;
static bool Model_TPR_CheckPreview(CArrayList<tprMeshInMem_t> &meshes, CArrayList<tprTexInMem_t> &textures,
									CArrayList<tprVBufDecl_t> &vertBufs, CArrayList<tprIBufDecl_t> &idxBufs,
									CArrayList<tprHeiBone_t> &bones)
{
	if (!g_mainGLInst)
	{
		return false;
	}

	if (meshes.Num() <= 0)
	{
		return false;
	}

	Model_TPR_UploadTextures(textures);

	printf("TPR preview mode.\n");

	g_zNear = 2.0f;
	g_zFar = 131072.0f;
	g_objPos[0] = 650.0f;
	g_objPos[2] = 200.0f;

	float baseAngles[3] = {0.0f, 270.0f, 0.0f};

	int frameCount = 0;

	g_recenterModel = true;

	float lightPos[4];
	float lightPosB[4];
	int overrideTex = -1;
	while (1)
	{
		frameCount++;
		if (frameCount == 0)
		{
			frameCount++;
		}

		if (g_recenterModel && meshes.Num() > 0)
		{
			//figure out size of model
			float modelMins[3], modelMaxs[3];
			modelMins[0] = modelMins[1] = modelMins[2] = 0.0f;
			modelMaxs[0] = modelMaxs[1] = modelMaxs[2] = 0.0f;
			bool hasBounds = false;
			int glTex = -1;

			float smpNrm[3];
			bool normalSame = true;

			for (int m = 0; m < meshes.Num(); m++)
			{
				tprMeshInMem_t *mesh = &meshes[m];
				if (mesh->numElem <= 0)
				{
					continue;
				}

				for (int en = 0; en < mesh->numElem; en++)
				{
					tprGeoElemInMem_t *elem = mesh->elems+en;
					if (elem->numVerts <= 0)
					{
						continue;
					}
					meshIntrVert_t *verts = elem->verts;
					if (!hasBounds)
					{
						smpNrm[0] = verts->normal[0];
						smpNrm[1] = verts->normal[1];
						smpNrm[2] = verts->normal[2];
						modelMins[0] = verts->pos[0];
						modelMins[1] = verts->pos[1];
						modelMins[2] = verts->pos[2];
						modelMaxs[0] = verts->pos[0];
						modelMaxs[1] = verts->pos[1];
						modelMaxs[2] = verts->pos[2];
						hasBounds = true;
					}
					for (int i = 0; i < elem->numVerts; i++)
					{
						if (verts[i].normal[0] != smpNrm[0] ||
							verts[i].normal[1] != smpNrm[1] ||
							verts[i].normal[2] != smpNrm[2])
						{
							normalSame = false;
						}
						Math_ExpandBounds(modelMins, modelMaxs, verts[i].pos, verts[i].pos);
					}
				}
			}

			float modelCenter[3];
			modelCenter[0] = modelMins[0] + (modelMaxs[0]-modelMins[0])*0.5f;
			modelCenter[1] = modelMins[1] + (modelMaxs[1]-modelMins[1])*0.5f;
			modelCenter[2] = modelMins[2] + (modelMaxs[2]-modelMins[2])*0.5f;
			float modelEx = Math_Max3(modelMaxs[0]-modelMins[0],
										modelMaxs[1]-modelMins[1],
										modelMaxs[2]-modelMins[2]);

			g_objPos[0] = modelCenter[0] + modelEx*3.5f;
			g_objPos[1] = modelCenter[1];
			g_objPos[2] = modelCenter[2];
			g_objAng[0] = 0.0f;
			g_objAng[1] = 0.0f;
			g_objAng[2] = 0.0f;

			g_moveScale = modelEx/512.0f;

			g_zNear = 2.0f * (modelEx/256.0f);
			g_zFar = modelEx*10.0f;

			float d[3];
			Math_VecSub(modelCenter, g_objPos, d);
			Math_VecToAngles(d, baseAngles);
			baseAngles[1] += 90.0f;

			lightPos[0] = modelCenter[0];
			lightPos[1] = modelCenter[1];
			lightPos[2] = modelCenter[2] + modelEx*20.0f;
			lightPos[3] = 1.0f;
			lightPosB[0] = modelCenter[0];
			lightPosB[1] = modelCenter[1];
			lightPosB[2] = modelCenter[2] - modelEx*20.0f;
			lightPosB[3] = 1.0f;
			if (!normalSame)
			{
				g_enableTPRLighting = true;
			}

			g_recenterModel = false;
		}

		//Window_ResetView();
		g_mainGLInst->ResetProjection(true);

		glClearColor(0.25f, 0.25f, 0.25f, 1.0f);
		//glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
		//glClearColor(1.0f, 0.5f, 0.75f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT|GL_STENCIL_BUFFER_BIT);

		glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
#if 0
		glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, texBase);
		glDepthMask(GL_FALSE);
		glDisable(GL_CULL_FACE);
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		float qz = 0.0f;
		float mins[2] = {0.0f, 0.0f};
		float maxs[2] = {256.0f, 256.0f};
		glBegin(GL_QUADS);
			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(mins[0], maxs[1], qz);
			glTexCoord2f(0.0f, 0.0f);
			glVertex3f(mins[0], mins[1], qz);
			glTexCoord2f(1.0f, 0.0f);
			glVertex3f(maxs[0], mins[1], qz);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(maxs[0], maxs[1], qz);
		glEnd();
		glDisable(GL_BLEND);
		glDepthMask(GL_TRUE);
		glDisable(GL_TEXTURE_2D);
#endif

		g_mainGLInst->ResetProjection(false);

		glLoadIdentity();
		if (g_tprFaceCull)
		{
			glCullFace(GL_BACK);
			glEnable(GL_CULL_FACE);
		}
		else
		{
			glDisable(GL_CULL_FACE);
		}

		float pos[3] = {g_objPos[0], g_objPos[1], g_objPos[2]};
		glRotatef((-baseAngles[0])+90, -1, 0, 0);
		glRotatef(baseAngles[2], 0, -1, 0);
		glRotatef(baseAngles[1]+180, 0, 0, -1);
		glTranslatef(-pos[0], -pos[1], -pos[2]);
		float objAng[3] = {g_objAng[0], g_objAng[1], g_objAng[2]};
		glRotatef(-objAng[1]+90.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(objAng[2], 0.0f, 1.0f, 0.0f);
		glRotatef(objAng[0]+90.0f, 1.0f, 0.0f, 0.0f);

		if (g_enableTPRLighting)
		{
			float ambMul = 0.45f;
			float difMul = 1.0f;
			float lightAmb[4] = {1.0f*ambMul, 1.0f*ambMul, 1.0f*ambMul, 1.0f};
			float lightDif[4] = {1.0f*difMul, 1.0f*difMul, 1.0f*difMul, 1.0f};
			float lightSpec[4] = {1.0f, 1.0f, 1.0f, 1.0f};					
			float spotDir[4] = {0.0f, 0.0f, -1.0f, 0.0f};

			glLightfv(GL_LIGHT0, GL_AMBIENT, lightAmb);
			glLightModelfv(GL_LIGHT_MODEL_AMBIENT, lightAmb);
			glLightfv(GL_LIGHT0, GL_DIFFUSE, lightDif);
			glLightfv(GL_LIGHT0, GL_SPECULAR, lightSpec);
			//glMaterialfv(GL_FRONT, GL_SPECULAR, lightSpec);
			glLightfv(GL_LIGHT0, GL_SPOT_DIRECTION, spotDir);
			//	glLightf(GL_LIGHT0, GL_SPOT_EXPONENT, 2.0f);
			//glMaterialf(GL_FRONT, GL_SHININESS, 2.0f);
			glLightf(GL_LIGHT0, GL_SPOT_CUTOFF, 180.0f);
			glLightf(GL_LIGHT0, GL_CONSTANT_ATTENUATION, 1.0f);
			glLightf(GL_LIGHT0, GL_LINEAR_ATTENUATION, 0.0f);
			glLightf(GL_LIGHT0, GL_QUADRATIC_ATTENUATION, 0.0f);
			glLightfv(GL_LIGHT0, GL_POSITION, lightPos);
			glEnable(GL_LIGHT0);
			glLightfv(GL_LIGHT1, GL_AMBIENT, lightAmb);
			glLightfv(GL_LIGHT1, GL_DIFFUSE, lightDif);
			glLightfv(GL_LIGHT1, GL_SPECULAR, lightSpec);
			glLightfv(GL_LIGHT1, GL_SPOT_DIRECTION, spotDir);
			//	glLightf(GL_LIGHT1, GL_SPOT_EXPONENT, 2.0f);
			glLightf(GL_LIGHT1, GL_SPOT_CUTOFF, 180.0f);
			glLightf(GL_LIGHT1, GL_CONSTANT_ATTENUATION, 1.0f);
			glLightf(GL_LIGHT1, GL_LINEAR_ATTENUATION, 0.0f);
			glLightf(GL_LIGHT1, GL_QUADRATIC_ATTENUATION, 0.0f);
			glLightfv(GL_LIGHT1, GL_POSITION, lightPosB);
			glEnable(GL_LIGHT1);
			glEnable(GL_LIGHTING);
		}

		glEnable(GL_DEPTH_TEST);
		glDepthMask(GL_TRUE);

		//draw the model
		//glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
#if 0
		glDisable(GL_TEXTURE_2D);
		glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
		for (int m = 0; m < meshes.Num(); m++)
		{
			tprMeshInMem_t *mesh = &meshes[m];
			if (mesh->numElem <= 0)
			{
				continue;
			}

			for (int en = 0; en < mesh->numElem; en++)
			{
				tprGeoElemInMem_t *elem = mesh->elems+en;
				if (elem->numVerts <= 0)
				{
					continue;
				}

				glPointSize(5.0f);
				glBegin(GL_POINTS);
				for (int i = 0; i < elem->numVerts; i++)
				{
					glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
					glVertex3fv(elem->verts[i].pos);
				}
				glEnd();
				glPointSize(1.0f);
			}
		}
#else
		glDisable(GL_TEXTURE_2D);
		glColor4f(1.0f, 1.0f, 1.0f, 1.0f);

		bool newFrame = true;
		for (int m = 0; m < meshes.Num(); m++)
		{
			tprMeshInMem_t *mesh = &meshes[m];
			if (mesh->numElem <= 0)
			{
				continue;
			}

#if 1
			glPushMatrix();
			if (mesh->hieBoneIdx >= 0)
			{
				float hieMat[16];
				Math_ModelMatToGL(&bones[mesh->hieBoneIdx].hieMatTrans, hieMat);
				//Math_ModelMatToGL(&meshes[mesh->hieIdx].hieMatTrans, hieMat);
				glMultMatrixf(hieMat);
			}
			for (int sn = 0; sn < mesh->numDrawSeg; sn++)
			{
				tprMeshDrawSeg_t *seg = mesh->drawSegs+sn;
				assert(seg->hdr.bufNum >= 0 && seg->hdr.bufNum < mesh->numElem);
				objInfoMeat_t *infoMeat = mesh->infoMeats+sn;
				tprGeoElemInMem_t *elem = mesh->elems+seg->hdr.bufNum;
				if (seg->numIdx <= 0 || elem->numVerts <= 0)
				{
					continue;
				}
				if (elem->noUV)
				{ //eh, fuck you then
					continue;
				}

#if 0
				if (elem->numMorphs > 0)
				{
					Model_TPR_FunWithBoobies(elem, newFrame);
				}
#endif

				if (seg->texIdx >= 0 && seg->texIdx < textures.Num() && !elem->noUV)
				{
					glEnable(GL_TEXTURE_2D);
					glBindTexture(GL_TEXTURE_2D, textures[seg->texIdx].glTex);
					if (g_tprTransparency)
					{
						glEnable(GL_BLEND);
						glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
						glEnable(GL_ALPHA_TEST);
						glAlphaFunc(GL_GREATER, 0.2f);
					}
				}

				glEnableClientState(GL_VERTEX_ARRAY);
				glEnableClientState(GL_NORMAL_ARRAY);
				glEnableClientState(GL_TEXTURE_COORD_ARRAY);

				if (elem->lerpedVerts)
				{
					glVertexPointer(3, GL_FLOAT, sizeof(meshIntrVert_t), elem->lerpedVerts->pos);
					glNormalPointer(GL_FLOAT, sizeof(meshIntrVert_t), elem->lerpedVerts->normal);
				}
				else
				{
					glVertexPointer(3, GL_FLOAT, sizeof(meshIntrVert_t), elem->verts->pos);
					glNormalPointer(GL_FLOAT, sizeof(meshIntrVert_t), elem->verts->normal);
				}
				glTexCoordPointer(2, GL_FLOAT, sizeof(meshIntrVert_t), elem->verts->uv);

				glDrawElements(GL_TRIANGLES, seg->numIdx, GL_UNSIGNED_SHORT, seg->segIdx);
				
				glDisableClientState(GL_VERTEX_ARRAY);
				glDisableClientState(GL_NORMAL_ARRAY);
				glDisableClientState(GL_TEXTURE_COORD_ARRAY);

				if (g_tprFaceCull)
				{
					glEnable(GL_CULL_FACE);
				}
				glDisable(GL_TEXTURE_2D);
				glDisable(GL_BLEND);
				glDisable(GL_ALPHA_TEST);
				glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
			}
			glPopMatrix();
#else
			for (int en = 0; en < mesh->numElem; en++)
			{
				tprGeoElemInMem_t *elem = mesh->elems+en;
				if (elem->numIdx <= 0 || elem->numVerts <= 0)
				{
					continue;
				}

				/*
				if (elem->texIdx >= 0 && elem->texIdx < textures.Num())
				{
					glEnable(GL_TEXTURE_2D);
					glBindTexture(GL_TEXTURE_2D, textures[elem->texIdx].glTex);
				}
				*/

				glEnableClientState(GL_VERTEX_ARRAY);
				glEnableClientState(GL_NORMAL_ARRAY);
				glEnableClientState(GL_TEXTURE_COORD_ARRAY);

				glVertexPointer(3, GL_FLOAT, sizeof(meshIntrVert_t), elem->verts->pos);
				glNormalPointer(GL_FLOAT, sizeof(meshIntrVert_t), elem->verts->normal);
				glTexCoordPointer(2, GL_FLOAT, sizeof(meshIntrVert_t), elem->verts->uv);

				glDrawElements(GL_TRIANGLES, elem->numIdx, GL_UNSIGNED_SHORT, elem->idx);
				
				glDisableClientState(GL_VERTEX_ARRAY);
				glDisableClientState(GL_NORMAL_ARRAY);
				glDisableClientState(GL_TEXTURE_COORD_ARRAY);

				if (g_tprFaceCull)
				{
					glEnable(GL_CULL_FACE);
				}
				glDisable(GL_TEXTURE_2D);
				glDisable(GL_BLEND);
				glDisable(GL_ALPHA_TEST);
				glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
			}
#endif
		}
#endif

		glDisable(GL_LIGHT1);
		glDisable(GL_LIGHT0);
		glDisable(GL_LIGHTING);

#if 0
		glDisable(GL_DEPTH_TEST);
		glDisable(GL_TEXTURE_2D);
		glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
		int totalMeat = 0;
		for (int m = 0; m < meshes.Num(); m++)
		{
			tprMeshInMem_t *mesh = &meshes[m];

			for (int n = 0; n < mesh->numMeats; n++)
			{
				totalMeat++;
				glPointSize(5.0f);
				glBegin(GL_POINTS);
				glVertex3fv(&mesh->infoMeats[n].fldata[8]);
				glEnd();
				glPointSize(1.0f);
			}
		}
		glEnable(GL_DEPTH_TEST);
#endif

#if 0
		glDisable(GL_DEPTH_TEST);
		glDisable(GL_TEXTURE_2D);
		glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
		for (int m = 0; m < bones.Num(); m++)
		{
			tprHeiBone_t *bone = &bones[m];

			glPointSize(5.0f);
			glBegin(GL_POINTS);
			glVertex3fv(bone->hieMatTrans.o);
			glEnd();
			glPointSize(1.0f);
		}
		glEnable(GL_DEPTH_TEST);
#endif

		Window_Frame();

		if (!Window_Valid())
		{
			//MainCleanup();
			//exit(0);
			return true;
		}

		Sleep(20);
	}

	return true;
}

//load tpr
int Model_LoadTPR(BYTE *fileBuffer, int bufferLen)
{
	if (!Model_IsTPR(fileBuffer, bufferLen))
	{
		return 0;
	}

	int gmdOfs = 0;
	BYTE *gmdXpr = Model_GetXPRFromGMD(fileBuffer, bufferLen, gmdOfs);
	if (gmdXpr)
	{
		fileBuffer = gmdXpr;
		bufferLen -= gmdOfs;
	}

	printf("GLORY BE TO ITAGAKI-SAMA.\n");
	printf("Loading TPR...\n");

	int ofs = 0;
	tprHdr_t hdr = *((tprHdr_t *)(fileBuffer+ofs));
	ofs += sizeof(tprHdr_t);
	LITTLE_BIG_SWAP(hdr.dataOfs);
	LITTLE_BIG_SWAP(hdr.subSize);
	LITTLE_BIG_SWAP(hdr.numEntries);

	CArrayList<tprTexInMem_t> textures;
	textures.SetGrowth(true);
	CArrayList<tprVBufDecl_t> vertBufs;
	vertBufs.SetGrowth(true);
	CArrayList<tprIBufDecl_t> idxBufs;
	idxBufs.SetGrowth(true);
	CArrayList<tprMeshInMem_t> meshes;
	meshes.SetGrowth(true);
	CArrayList<tprHeiBone_t> bones;
	bones.SetGrowth(true);

	for (int i = 0; i < hdr.numEntries; i++)
	{
		tprEntry_t entry = *((tprEntry_t *)(fileBuffer+ofs));
		ofs += sizeof(tprEntry_t);
		LITTLE_BIG_SWAP(entry.ofs);
		LITTLE_BIG_SWAP(entry.size);
		LITTLE_BIG_SWAP(entry.baseOfs);
		BYTE *data = fileBuffer + entry.ofs + 12;
		if (!memcmp(entry.id, "TX2D", 4))
		{
			Model_TPR_LoadTexDecl(&hdr, fileBuffer, data, textures);
		}
		else if (!memcmp(entry.id, "USER", 4))
		{
			if (!memcmp(data, "MdlGeo\0\0", 8))
			{
				Model_TPR_LoadMeshObjects(&hdr, fileBuffer, data, meshes);
			}
			else if (!memcmp(data, "MdlInfo\0", 8))
			{
				Model_TPR_LoadMeshInfos(&hdr, fileBuffer, data, meshes);
			}
			else if (!memcmp(data, "Hie\0\0\0\0\0", 8))
			{
				Model_TPR_LoadMeshHierarchy(&hdr, fileBuffer, data, meshes, bones);
			}
		}
		else if (!memcmp(entry.id, "VBUF", 4))
		{
			tprVBufDecl_t vbufDec = *((tprVBufDecl_t *)(data));
			LITTLE_BIG_SWAP(vbufDec.unknownA);
			LITTLE_BIG_SWAP(vbufDec.unknownB);
			LITTLE_BIG_SWAP(vbufDec.unknownC);
			LITTLE_BIG_SWAP(vbufDec.unknownD);
			LITTLE_BIG_SWAP(vbufDec.unknownE);
			LITTLE_BIG_SWAP(vbufDec.unknownF);
			LITTLE_BIG_SWAP(vbufDec.dataOfs);
			LITTLE_BIG_SWAP(vbufDec.dataSize);
			vbufDec.dataOfs += (hdr.dataOfs + 12);
			vertBufs.Append(vbufDec);
		}
		else if (!memcmp(entry.id, "IBUF", 4))
		{
			tprIBufDecl_t ibufDec = *((tprIBufDecl_t *)(data));
			LITTLE_BIG_SWAP(ibufDec.unknownAA);
			LITTLE_BIG_SWAP(ibufDec.unknownAB);
			LITTLE_BIG_SWAP(ibufDec.unknownB);
			LITTLE_BIG_SWAP(ibufDec.unknownC);
			LITTLE_BIG_SWAP(ibufDec.unknownD);
			LITTLE_BIG_SWAP(ibufDec.unknownE);
			LITTLE_BIG_SWAP(ibufDec.unknownF);
			LITTLE_BIG_SWAP(ibufDec.dataOfs);
			LITTLE_BIG_SWAP(ibufDec.dataSize);
			ibufDec.dataOfs += (hdr.dataOfs + 12);
			idxBufs.Append(ibufDec);
		}
	}

	printf("Loaded %i textures, %i meshes.\n", textures.Num(), meshes.Num());

	Model_TPR_AssembleGeometry(fileBuffer, meshes, textures, vertBufs, idxBufs, bones);

	int r = 0;
	if (!Model_TPR_CheckPreview(meshes, textures, vertBufs, idxBufs, bones) && !g_mainGLInst)
	{
		Model_TPR_WriteTextures(textures);
		r = Model_TPR_Convert(meshes, textures, vertBufs, idxBufs, bones);
	}

	textures.Clear();
	vertBufs.Clear();
	idxBufs.Clear();
	meshes.Clear();
	bones.Clear();

	return r;
}
