from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("train", ".model")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)
    
    noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    if bs.readUInt() != 2965044855:
        return 0
    return 1   

def noepyLoadModel(data, mdlList):
    result = [i for i in findall(b'SurfaceData', data)]
    bs = NoeBitStream(data)
    ctx = rapi.rpgCreateContext()
    
    dir = rapi.getDirForFilePath(rapi.getInputName())
    local_name = rapi.getLocalFileName(rapi.getInputName())
    
    vbuf_file = []
    files = os.listdir(dir)
    for file in files:
        if local_name in file and rapi.checkFileExt(file, '.vbuf'):
            vbuf_file.append(os.path.join(dir, file))
            print("vbuf_file>>",file)
    
    if len(vbuf_file) > 1:
        result = result[:1]
    
    vbuf_data = rapi.loadIntoByteArray(vbuf_file[0])#rapi.getInputName() + '.vb0.vbuf'

    if vbuf_data[0] == 4:
        print('>>>>>>>>>>>>>>>>>')
        stride = struct.unpack('I', vbuf_data[28:32])[0]
        vsize = struct.unpack('I', vbuf_data[32:36])[0]
        vbuf_data = vbuf_data[36:]
    else:
        print('<<<<<<<<<<<<<<<<')
        stride = struct.unpack('I', vbuf_data[40:44])[0]
        vsize = struct.unpack('I', vbuf_data[44:48])[0]
        vbuf_data = vbuf_data[48:]
    
    ibuf_data = rapi.loadIntoByteArray(rapi.getInputName() + '.ib0.ibuf')[5:]
    
    vbs = NoeBitStream(vbuf_data)
    ibs = NoeBitStream(ibuf_data)
    
    for x in result:
        bs.seek(x-37)
        inum = bs.readInt()
        print('inum:',inum)

        rapi.rpgSetName('mesh_%i'%x)
        IBUF = ibs.readBytes(inum*2)
        maxI = max(struct.unpack('%iH'%inum, IBUF))+1
        print('max_value:',maxI)
            
        VBUF = vbs.readBytes(maxI*stride)
        rapi.rpgBindPositionBuffer(VBUF, noesis.RPGEODATA_HALFFLOAT, stride)
        rapi.rpgBindUBufferOfs(VBUF, noesis.RPGEODATA_FLOAT, stride, 20)
        rapi.rpgCommitTriangles(IBUF, noesis.RPGEODATA_USHORT, inum, noesis.RPGEO_TRIANGLE)

        #ibs.seek(inum*2)
    rapi.rpgOptimize()
    mdl = rapi.rpgConstructModel()#NoeModel()
    mdl.setModelMaterials(NoeModelMaterials([], [NoeMaterial("mat_0","")]))
    mdlList.append(mdl)
    return 1
    
def findall(p, s):
    i = s.find(p)
    while i != -1:
        yield i
        i = s.find(p, i+1)