from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Terraria (PS3)", ".gtf")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    bs.setEndian(NOE_BIGENDIAN)
    Magic = bs.readBytes(4)
    print(Magic, "magic")
    if Magic != b'\x02\x02\x00\xff':
        return 0
    return 1
    
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.setEndian(NOE_BIGENDIAN)
    bs.seek(0x20, NOESEEK_ABS)         
    imgWidth = bs.readShort()            
    imgHeight = bs.readShort()
    print(imgWidth, "x", imgHeight)
    bs.seek(0x80, NOESEEK_ABS)         
    datasize = len(data) - 0x80        
    data = bs.readBytes(datasize)      
    #DXT1
    texFmt = noesis.NOESISTEX_DXT1
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1