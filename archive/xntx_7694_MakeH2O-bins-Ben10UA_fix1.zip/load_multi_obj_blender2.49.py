
import import_obj
import os

# http://blenderartists.org/forum/archive/index.php/t-123590.html

def fileList(path): # Would be nice is this was built into python!
	for dirpath, dirnames, filenames in os.walk(path):
		for filename in filenames:
			yield os.path.join(dirpath, filename)

#for f in fileList("/home/ideasman42"):
for f in fileList("D:\\Eigene Dateien\\Downloads"):
	if f.lower().endswith(".obj"):
		import_obj.load_obj(f)