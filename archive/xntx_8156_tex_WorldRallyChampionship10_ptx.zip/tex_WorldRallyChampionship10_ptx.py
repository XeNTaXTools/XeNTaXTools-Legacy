from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("World Rally Championship 10", ".ptx")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    if noeStrFromBytes(bs.readBytes(4)) != 'RIFF': return 0
    return 1
    
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.seek(0x3C, NOESEEK_ABS)         
    imgFmt = noeStrFromBytes(bs.readBytes(4))
    print(imgFmt, ":imgFmt")
    imgWidth = bs.readUInt()            
    imgHeight = bs.readUInt()
    print(imgWidth, "x", imgHeight)
    bs.readInt()
    mips = bs.readUInt()
    bs.seek(0x7a, NOESEEK_ABS)         
    #DXT1
    if imgFmt == 'DXT1':
        texFmt = noesis.NOESISTEX_DXT1
    #DXT5/BC3
    elif imgFmt == 'DXT5':
        texFmt = noesis.NOESISTEX_DXT5
    #ATI1/BC4
    #elif imgFmt == 'BC4 ':
    #    data = rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_ATI1)
    #    texFmt = noesis.NOESISTEX_RGBA32
    #    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    #    return 1
    elif imgFmt == 'RGBA':
        texFmt = noesis.NOESISTEX_RGBA32
    datasize = 0
    data = bytearray()
    while not bs.checkEOF():    
        Pixl = noeStrFromBytes(bs.readBytes(4))
        if Pixl != 'Pixl':
            break
        size = bs.readUInt()
        print(hex(bs.tell()), ":here1")
        data2 = bs.readBytes(size)
        print(hex(bs.tell()), ":here2")
        data += data2
        datasize += size
        print(hex(datasize), ":datasize")
    if imgFmt == 'BC4 ':
        #build dx10 dds header and append tex data
        ddsHeader = b'\x44\x44\x53\x20\x7C\x00\x00\x00\x07\x10\x00\x00'
        ddsHeader += bytearray(noePack("I", imgHeight))
        ddsHeader += bytearray(noePack("I", imgWidth))
        ddsHeader += bytearray(noePack("I", datasize))
        ddsHeader += b'\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x20\x00\x00\x00\x04\x00\x00\x00\x44\x58\x31\x30\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
        ddsHeader += b'\x50\x00\x00\x00'                 #type 80? 
        ddsHeader += b'\x03\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00'
        ddsHeader += data
        texList.append(rapi.loadTexByHandler(ddsHeader, ".dds"))
    elif imgFmt == 'BC5S':
        #build dx10 dds header and append tex data
        ddsHeader = b'\x44\x44\x53\x20\x7C\x00\x00\x00\x07\x10\x00\x00'
        ddsHeader += bytearray(noePack("I", imgHeight))
        ddsHeader += bytearray(noePack("I", imgWidth))
        ddsHeader += bytearray(noePack("I", datasize))
        ddsHeader += b'\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x20\x00\x00\x00\x04\x00\x00\x00\x44\x58\x31\x30\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
        ddsHeader += b'\x54\x00\x00\x00'                 #type 84 
        ddsHeader += b'\x03\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00'
        ddsHeader += data
        texList.append(rapi.loadTexByHandler(ddsHeader, ".dds"))
    else:
        texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1