

#include "StdAfx.h"


void main()
{
	TRB_CONVERTER Converter;
	TRB_MODEL Model;
	Converter.Load( "c001.x360.trb", &Model );
	ExportFBX( "c001.x360.fbx", &Model );

	//Converter.Load( "m001.x360.trb", &Model );
	//ExportFBX( "m001.x360.fbx", &Model );
}