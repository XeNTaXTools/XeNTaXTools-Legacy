#include "StdAfx.h"

#ifndef SINGULAR_HEADER

	#include "Vector.h"
#endif

//Vector 2 & 3 & 4


//*************
//Vector3
//*************

//Constructors
Vector3::Vector3()
{
	x=0;
	y=0;
	z=0;
}
Vector3::Vector3(float X, float Y, float Z) 
{ 
	x=X;
	y=Y;
	z=Z;
}
Vector3::Vector3(Vector2 *V2, float Z)
{
	x=V2->x;
	y=V2->y;
	z=Z;
}
Vector3 Vector3::operator=(Vector2* Vec2)
{
	Set(Vec2->x,Vec2->y,0);
	return *this;
}
//Operators with floats	
Vector3 Vector3::operator*(float num)
{
	return Vector3(x * num, y * num, z * num);
}
Vector3 Vector3::operator*=(float num)
{
	Set(x*num,y*num,z*num);
	return *this;
}
Vector3 Vector3::operator/(float num)
{
	return Vector3(x / num, y / num, z / num);
}
Vector3 Vector3::operator/=(float num)
{
	Set(x/num,y/num,z/num);
	return *this;
}
//operators with other vectors
Vector3 Vector3::operator+(Vector3 Vector)
{
	return Vector3(Vector.x + x, Vector.y + y, Vector.z + z);
}
Vector3 Vector3::operator+=(Vector3 Vector)
{//A+=B;
	Set(x+Vector.x,y+Vector.y,z+Vector.z);
	return *this;
}
Vector3 Vector3::operator-(Vector3 Vector)
{
	return Vector3(x - Vector.x, y - Vector.y, z - Vector.z);
}	
Vector3 Vector3::operator-=(Vector3 Vector)
{//A-=B;
	Set(x-Vector.x,y-Vector.y,z-Vector.z);
	return *this;
}
Vector3 Vector3::operator*(Vector3 Vector)
{
	return Vector3(x*Vector.x,y*Vector.y,z*Vector.z);
}
Vector3 Vector3::operator*=(Vector3 Vector)
{//A-=B;
	Set(x*Vector.x,y*Vector.y,z*Vector.z);
	return *this;
}
Vector3 Vector3::operator/(Vector3 Vector)
{
	return Vector3(x/Vector.x,y/Vector.y, z/Vector.z);
}
Vector3 Vector3::operator/=(Vector3 Vector)
{
	Set(x/Vector.x,y/Vector.y,z/Vector.z);
	return *this;
}
bool Vector3::operator==(Vector3 Vector)
{
	return (x==Vector.x && y==Vector.y && z==Vector.z);
}
bool Vector3::operator!=(Vector3 Vector)
{
	return (x!=Vector.x || y!=Vector.y || z!=Vector.z);
}
//Conversion from other Vector-s
/*
//can't use it because it's undeclared...
Vector3 operator=(Vector2 V2)
{
	return Vector3(V2.x,V2.y,0);		
}
Vector3 operator=(Vector4 V4)
{
	return Vector3(V4.x,V4.y,V4.z);		
}*/
//Functions
float Vector3::length()
{
	return (float)sqrt(x*x+y*y+z*z);
}
void Vector3::Set(float X, float Y, float Z)
{
	x=X;
	y=Y;
	z=Z;
}
void Vector3::Set(Vector3 V) 
{
	*this=V;
}
void Vector3::Add(float X, float Y, float Z)
{
	x+=X;
	y+=Y;
	z+=Z;
}
void Vector3::Add(Vector3 A)
{
	x+=A.x;
	y+=A.y;
	z+=A.z;
}

//*************
//Vector2
//*************

//Constructors
Vector2::Vector2()
{
	x=0;
	y=0;
};
Vector2::Vector2(float X,float Y)
{
	x=X;
	y=Y;
}
//Operators
Vector2 Vector2::operator+(Vector2 Vector)
{
	return Vector2(Vector.x + x, Vector.y + y);
}
Vector2 Vector2::operator-(Vector2 Vector)
{
	return Vector2(x - Vector.x, y - Vector.y);
}
Vector2 Vector2::operator*(float num)
{
	return Vector2(x * num, y * num);
}
Vector2 Vector2::operator/(float num)
{
	return Vector2(x / num, y / num);
}
Vector2 Vector2::operator+=(Vector2 Vector)
{//A+=B;
	Set(x+Vector.x,y+Vector.y);
	return *this;
}
Vector2 Vector2::operator-=(Vector2 Vector)
{//A-=B;
	Set(x-Vector.x,y-Vector.y);
	return *this;
}
Vector2 Vector2::operator*(Vector3 Vector)
{
	return Vector2(x*Vector.x,y*Vector.y);
}
Vector2 Vector2::operator* (Vector2 Vector)
{
	return Vector2(x*Vector.x,y*Vector.y);
}
Vector2 Vector2::operator*=(Vector2 Vector)
{//A-=B;
	Set(x*Vector.x,y*Vector.y);
	return *this;
}
Vector2 Vector2::operator/(Vector2 Vector)
{
	return Vector2(x/Vector.x,y/Vector.y);
}
bool Vector2::operator==(Vector2 Vector)
{
	return (x==Vector.x && y==Vector.y);
}
bool Vector2::operator!=(Vector2 V)
{
	return (V.x!=x || V.y!=y);		
};
//Functions
void Vector2::Set(float X,float Y)
{
	x=X;
	y=Y;
}
void Vector2::Set(Vector2 V) 
{
	*this=V;
}
void Vector2::Add(float X,float Y) 
{
	x+=X;
	y+=Y;
}

//*************
//Vector4
//*************

Vector4::Vector4()
{
	x=0;
	y=0;
	z=0;
	w=0;
};
Vector4::Vector4(float X, float Y, float Z,float W) 
{
	x=X;
	y=Y;
	z=Z;
	w=W;
}
Vector4::Vector4(Vector3 V) 
{
	x=V.x;
	y=V.y;
	z=V.z;
	w=0;
}
//V4+V4
Vector4 Vector4::operator+(Vector4 Vector)
{
	return Vector4(Vector.x + x, Vector.y + y, Vector.z + z, Vector.w + w);
}
//V4+V3
Vector4 Vector4::operator+(Vector3 Vector)
{
	return Vector4(Vector.x + x, Vector.y + y, Vector.z + z,w);
}
Vector4 Vector4::operator*(float num)
{
	return Vector4(x * num, y * num, z * num, w * num);
}
//Operators	
Vector4 Vector4::operator-(Vector4 Vector)
{
	return Vector4(x-Vector.x,y-Vector.y,z-Vector.z,w - Vector.w);
}
Vector4 Vector4::operator/(float num)
{
	return Vector4(x/num,y/num,z/num,w/num);
}
Vector4 Vector4::operator+=(Vector4 Vector)
{//A+=B;
	Set(x+Vector.x,y+Vector.y,z+Vector.z,w+Vector.w);
	return *this;
}
Vector4 Vector4::operator-=(Vector4 Vector)
{//A-=B;
	Set(x-Vector.x,y-Vector.y,z-Vector.z,w-Vector.w);
	return *this;
}
Vector4 Vector4::operator*(Vector4 Vector)
{
	return Vector4(x*Vector.x,y*Vector.y,z*Vector.z,w*Vector.w);
}
Vector4 Vector4::operator*=(Vector4 Vector)
{//A-=B;
	Set(x*Vector.x,y*Vector.y,z*Vector.z,w*Vector.w);
	return *this;
}
Vector4 Vector4::operator/(Vector4 Vector)
{
	return Vector4(x/Vector.x,y/Vector.y,z/Vector.z,w/Vector.w);
}
bool Vector4::operator==(Vector4 Vector)
{
	return (x==Vector.x && y==Vector.y && z==Vector.z && w==Vector.w);
}
//Functions
void Vector4::Set(float X, float Y, float Z,float W) 
{
	x=X;
	y=Y;
	z=Z;
	w=W;
}
void Vector4::Set(Vector4 V) 
{
	*this=V;
}
void Vector4::Add(float X, float Y, float Z,float W) 
{
	x+=X;
	y+=Y;
	z+=Z;
	w+=W;
}

//From anything to Vector3
Vector3 GetVector3(Vector2 V)
{
	return Vector3(V.x,V.y,0);
}
Vector3 GetVector3(Vector4 V)
{
	return Vector3(V.x,V.y,V.y);
}
//From anything to Vector2
Vector2 GetVector2(Vector3 V)
{
	return Vector2(V.x,V.y);
}
Vector2 GetVector2(Vector4 V)
{
	return Vector2(V.x,V.y);
}
//From anything to Vector4
Vector4 GetVector4(Vector3 V)
{
	return Vector4(V.x,V.y,V.y,0);
}
Vector4 GetVector4(Vector2 V)
{
	return Vector4(V.x,V.y,0,0);
}