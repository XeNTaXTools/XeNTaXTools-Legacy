
template< class TYPE >
class DYNAMIC_ARRAY
{
public:

	int Size;
	int Grow;
	int Allocated;

	TYPE *Array;

	DYNAMIC_ARRAY(int InitialSize = 0, int pGrow = 4)
	{
		if (InitialSize > 0)
		{
			Array = new TYPE[ InitialSize ];
		}
		else
			Array = NULL;

		Size = 0;
		Allocated = InitialSize;
		Grow = pGrow;
	}
	~DYNAMIC_ARRAY()
	{
		Clear();
	}
	void Add(TYPE New)
	{
		if (Size >= Allocated)
		{
			Allocate( Grow );
		}

		Array[ Size ] = New;
		Size++;
	}
	TYPE & AddEmpty()
	{
		if (Size >= Allocated)
		{
			Allocate( Grow );
		}
		
		Size++;
		return Array[ Size - 1 ];
	}
	void AddEmptyArray(int Amount)
	{
		int NewSize = Size + Amount;
		if (NewSize > Allocated)
			Allocate( NewSize - Allocated );

		Size = NewSize;
	}
	void Insert(TYPE New, int Index)
	{
		//Makes space for the new item
		AddEmpty();

		//Move the array forwards
		for(int y=Size - 2; y >= Index; y--)
		{
			Array[ y + 1 ] = Array[ y ];
		}

		Array[ Index ] = New;
	}
	void RemoveLast(bool Nulify = true)
	{
		if (Nulify)
			Array[ Size - 1] = NULL;

		Size--;
	}
	bool Remove( TYPE Var )
	{
		for(int y=0; y<Size; y++)
		{
			if (Array[y] == Var)
			{
				//Moves the array backwards
				for(int u=y; u<Size-1; u++)
				{
					Array[ u ] = Array[ u + 1 ];
				}

				Size--;

				return true;
			}
		}

		return false;
	}
	void Merge( DYNAMIC_ARRAY<TYPE> * Other )
	{
		for(int y=0; y<Other->Size; y++)
		{
			Add( (*Other)[y] );
		}

		Other->Clear();
	}
	bool Find( TYPE Val )
	{
		for(int y=0; y<Size; y++)
		{
			if (Array[y] == Val)
				return true;
		}

		return false;
	}
	bool RemoveAt( int Index )
	{		
		//Moves the array backwards
		for(int u=Index; u<Size-1; u++)
		{
			Array[ u ] = Array[ u + 1 ];
		}

		Size--;			

		return false;
	}
	//Use predominantly for pointer arrays to increase the allocated pointers, it does not modify size; for that use AddEmptyArray
	void Allocate( int Increase )
	{
		if (Increase <= 0)
			return;

		Allocated += Increase;
		TYPE *NewArray = new TYPE[ Allocated ];

		if ( Array )
		{
			//This way it works on DINGOO_PLATFORM too :D
			memcpy( (char*)NewArray, (char*)Array, Size * sizeof(TYPE));			

			delete[] Array;
		}

		Array = NewArray;
	}		
	TYPE & operator[](long index)
	{
		//On second I'd rather have it crash to detect the bug
		/*if ( index >= Allocated )
		{
			//In case the index is borked this shouldn't happen (it's going to increase to billions)
				//Creates leak but saves bogus application :D
			TYPE *Bogus = new TYPE;
			return *Bogus;
		}*/
		return Array[ index ];
	}
	TYPE & Last()
	{
		return Array[ Size - 1 ];
	}
	void Clear()
	{
		if (Array)
		{
			delete[] Array;
			Array = NULL;
			Allocated = 0;
			Size = 0;
		}
	}
	void Empty()
	{
		Size = 0;
	}
	
	void ClearAndDeallocate()
	{
		for(int y=0; y<Size; y++)
		{
			TYPE Pointer = Array[y];
			if (Pointer)
				delete Pointer;
		}

		Clear();
	}
	
};

class ARRAY_INDEX
{
public:
	BYTE IsPointer;
	void *Data;

	ARRAY_INDEX()
	{
		IsPointer = 0;
		Data = NULL;
	}
};

//This class should make it possible to allocate batches of elements into a dynamic array

template< class TYPE >
class DYNAMIC_ARRAY2 //: public DYNAMIC_ARRAY< ARRAY_INDEX >
{
public:
	DYNAMIC_ARRAY< ARRAY_INDEX > ArrayIndex;

	void Add(TYPE New)
	{
		if (ArrayIndex.Size >= ArrayIndex.Allocated)
		{
			ArrayIndex.Increase();
		}

		(*ArrayIndex[ Size ].Data) = New;
		ArrayIndex.Size++;
	}
	TYPE & operator[](long index)
	{
		/*if ( index >= Allocated )
		{
			//Make it available regardless
			while (index >= Allocated)
				Increase();
		}*/
		return *(TYPE*)ArrayIndex[ index ].Data;
	}
	DYNAMIC_ARRAY2(int InitialSize = 0, int pGrow = 4)
		//: DYNAMIC_ARRAY( InitialSize, pGrow)
	{
		if (InitialSize > 0)
		{
			TYPE *InitialPointer = new TYPE[ InitialSize ];

			ARRAY_INDEX Index;
			Index.IsPointer = 1;
			Index.Data = InitialPointer;

			ArrayIndex.Add( Index );

			//Form the pointers
			for(int y=1; y< InitialSize; y++)
			{
				Index.IsPointer = 0;
				Index.Data = &InitialPointer[ y ];
				ArrayIndex.Add( Index );
			}
		}
	}
	~DYNAMIC_ARRAY2()
	{
		//Delete only the pointers
		for(int y=0; y<ArrayIndex.Allocated; y++)
		{
			if (ArrayIndex[y].IsPointer)
			{
				TYPE *Pointer = (TYPE*)ArrayIndex[y].Data;
				delete[] Pointer;
			}
		}
	}
};

//I'm even wondering what I wanted with this class... ?
template< class TYPE >
class DYNAMIC_POINTER_ARRAY : public DYNAMIC_ARRAY< TYPE* >
{
public:
	void Add(TYPE & New)
	{
		DYNAMIC_ARRAY<TYPE*>::Add( &New );
	}
	DYNAMIC_POINTER_ARRAY(int InitialSize = 0, int pGrow = 4) : DYNAMIC_ARRAY< TYPE* >( InitialSize, pGrow)
	{
	}
};
