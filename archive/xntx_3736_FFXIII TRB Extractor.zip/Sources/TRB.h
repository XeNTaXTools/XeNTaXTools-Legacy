

// ffxiii2obj.cpp
//

#include <io.h>
#include <stdio.h>
#include <tchar.h>
#include <stdlib.h>
#include <string.h>

typedef unsigned char  uint8;
typedef unsigned short uint16;
typedef unsigned int   uint32;

class ELEMENT_DEF
{
public:
	void BigEndian();

	WORD Stream;
	WORD Offset;
	UINT Type;
	UINT Count;
	WORD Usage;
	WORD Index;
};

class BASE_BUFFER_HEADER
{
public:
	void BigEndian();

	char Marker[4];	 // STMS
	int  Zeros;		 // zeros
	int  ChunkSize1; // chunk size
	int  ChunkSize2; // chunk size again
	int  ElementDefs;//dcount	// chunk count
	int  Elements;	 // element count
	int  ElementSize;// element size	
};

class INTERMEDIATE_DATA
{
public:
	int UnknownA;
	int UnknownB;
	//WORD UnknownC;
	//WORD UnknownD;
	//WORD Unknown;
};

class BUFFER_HEADER : public BASE_BUFFER_HEADER
{
public:		

	int FileOffset;
	DYNAMIC_ARRAY< ELEMENT_DEF > ElementDef;
};

class BONE_INDICES
{
public:
	char Index[4];
};

class FACE
{
public:
	void BigEndian();

	WORD v1,v2,v3;
};

class SEDBSKL
{
public:

   char         id[8];
   int            unknownA[8];
   int            unknownB[3];
   int            boneDataSize;
   int            numBonesPlusOne; //i dunno
   char         lks[4]; //"lks\0"
   int            numBones;
   int            unknownE;
   int            boneDataSizeB; //?!
   int            unknownG;
};
class BONE
{
public:
   int            globalIdx;
   int            typeIndex;
   int            unknownC;
   int            unknownD;

   float         trans[3];
   float         q[4];
   float         scl[3];

   int            parent;
   int            child;
   int            sibling;
   int            index;

   int            stuff[26];
};

class TRB_BONE : public BONE
{
public:
	TRB_BONE()
	{
		Parent = NULL;
		Name[0] = 0;
		HadData = false;
	}

	char Name[255];
	TRB_BONE *Parent;
	bool HadData;

	D3DXMATRIXA16 Rotation;
};


class SEDB_HEADER
{
public:
	void BigEndian();

   char dataTag[8];   
   UINT dataSize;
   UINT nextOffset;
};

class GTEX
{
public:
	void BigEndian();
   BYTE         id[4];
   WORD         unknownA;
   BYTE         imgFmt;
   BYTE         numMips;
   WORD         unknownC;
   WORD         width;
   WORD         height;
   WORD         unknownD;
   int          unknownE;
   int          unknownF;
   int Padding[14];
} ;
class SEDB_TXB
{
public:
	void BigEndian();

   char         id[8];
   int            unknownA;
   int            unknownB;
   int            texSize; //seems like original size, does not include padding
   int            unknownC[7];
   int            unknownD;
   int            unknownE[3];

   GTEX Tex;
};

class SEDB_SHD_FILE
{
public:
	void BigEndian();

	char Id[8];
	int  UnknownC[5];
	//WORD UnknownD;
	char FileName[20];
};
class SEDB_SHD
{
public:
	void BigEndian();

	char id[8];
	WORD  Unknown[20];
	char SHD[4];
	WORD  UnknownB[14];

	SEDB_SHD_FILE FILE;
};

class MARKER_SIZE_48
{
public:
	void BigEndian();

	char id[8];
	int Size[2];
	int  Unknown[8];
};
class MARKER_SIZE_32
{
public:
	void BigEndian();

	char id[8];
	int Size[2];
	int Unknown[4];
};
class MARKER_STR
{
public:
	void BigEndian();

	char id[8];
	int  Unknown[2];
	char Name[16];
};

class MESH_HEADER
{
public:
	void BigEndian();

	char id[8];

	int Size[2];
	int Unknown[4];
};
class START_OBJECT_DATA
{
public:
	void BigEndian();

	MESH_HEADER    MESH;
	MARKER_SIZE_32 HEAD3;
	MARKER_STR     STR;
	MARKER_SIZE_32 RSID;
	MARKER_SIZE_32 RSTP;
	MARKER_SIZE_32 PRID;
	MARKER_SIZE_32 PRTP;
};
class SEDBWRB
{
public:
	void BigEndian();

	MARKER_SIZE_48 Header;
	MARKER_SIZE_32 WRB;
	MARKER_SIZE_32 MDLC;
	MARKER_SIZE_48 HEAD;
	MARKER_SIZE_32 MDL;
	MARKER_SIZE_32 NAME;
	MARKER_SIZE_48 HEAD2;

	START_OBJECT_DATA StartData;
};

class ELB_REPEAT
{
public:	
	void BigEndian();

	WORD Offset1;
	WORD Type1;
	WORD Offset2;
	WORD Type2;

	WORD A[12];
};
class SEDBelb
{
public:
	void BigEndian();

	char id[8];	
	WORD B[20];
	WORD Size;
	WORD C[5];
	BYTE A[3];	
};

class END_OBJECT_DATA
{
public:
	void BigEndian();

	MARKER_SIZE_32 AABB;
	MARKER_SIZE_48 AABB2;
};

class PRAM
{
public:
	void BigEndian();
	char id[8];
   WORD            unknownA;
   WORD            unknownB;
   int               unknownC;
   int               unknownD;
   int               unknownE;
   int               unknownF;
   int               numTextures;
   int               sampleDataOfs;
   int               sampleDataEnd;
   int               ofsTableEnd;
};


class ENVD_BASE
{
public:
	void BigEndian();
	SEDB_HEADER Header;

	WORD nameOffset;
	struct
	{
		WORD vertexCount;
		WORD indicesOffset;
		WORD weightsOffset;
	} dataInfo[2]; // not sure why this information repeats
};

class ENVD_INFO : public ENVD_BASE
{
public:
	char jointName[255];
   
	DYNAMIC_ARRAY< WORD > vertexIndices;
   
	DYNAMIC_ARRAY< float > vertexWeights;
};

class TRB_OBJECT 
{
public:
	BUFFER_HEADER VertexBuffer;
	BUFFER_HEADER IndexBuffer;

	DYNAMIC_ARRAY< D3DXVECTOR3 > VertexArray;
	DYNAMIC_ARRAY< D3DXVECTOR2 > TexcoordArray;
	DYNAMIC_ARRAY< D3DXVECTOR3 > NormalArray;
	DYNAMIC_ARRAY< D3DXVECTOR3 > ColorArray;
	DYNAMIC_ARRAY< FACE >        FaceArray;

	DYNAMIC_ARRAY< BONE_INDICES > BoneIndicesArray;
	DYNAMIC_ARRAY< D3DXVECTOR4 >  BoneWeightsArray;

	DYNAMIC_ARRAY< ENVD_INFO* > BoneMappings;
};

class TRB_MODEL
{
public:
	TRB_BONE *GetBone(int Index);
	int GetBoneIndex(char *Name);
	DYNAMIC_ARRAY< TRB_BONE* > Bones;

	DYNAMIC_ARRAY< TRB_OBJECT* > Object;
};


class VERTEX
{
public:
	void Prepare();

	short x,y,z;
	float hfx, hfy, hfz;
};

class HALF_FLOAT4
{
public:
	void Prepare();

	short x,y,z,w;
	float hfx, hfy, hfz, hfw;
};


unsigned int rev32u (unsigned int i);

unsigned short rev16u (unsigned short i);

short rev16s (unsigned short i);

union U {
    int i;
    float f;
};


float h2f(unsigned short y);

long find_string (unsigned char *buf, size_t start, size_t len, const char *s);


class TRB_CONVERTER
{
public:
	BYTE *Data;
	int  Offset;
	int FileSize;
	TRB_OBJECT *LastObject;

	void ReadObjectData( TRB_MODEL *Model );
	void Load( char *FileName, TRB_MODEL *Model );
};