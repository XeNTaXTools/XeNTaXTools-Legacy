

#undef UNICODE
#pragma warning(disable:4996)//PRAGMA DEPRECATED

//The MemoryLeak Detector
#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h>
//
#define WIN32_LEAN_AND_MEAN //faster builds ?

#include <stdio.h>
#include <stdlib.h>

#include <windows.h>
#include <commctrl.h>
#include <time.h>
#ifdef WIN32_LEAN_AND_MEAN
		#include <mmsystem.h>
		#include <commdlg.h>
#endif

#include <dbghelp.h.>

#include <float.h>
#include <math.h>
#include <d3dx9.h>

#include "DynamicArray.h"
#include "Vector.h"

//Hacking library
#include "..\..\HackLib\Hacklib.h"

#include "TRB.h"

int ExportFBX(char *File, TRB_MODEL *Model );