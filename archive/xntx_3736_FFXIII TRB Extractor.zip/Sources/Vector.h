#pragma once

//Vector 2 & 3 & 4

class Vector3;
class Vector2;
class Vector4;


class Vector3
{
public:
	float x,y,z;
	//Constructors
	Vector3();
	Vector3(float X, float Y, float Z);	

	//Operators with floats	
    Vector3 operator* (float num);
	Vector3 operator*=(float num);
    Vector3 operator/ (float num);
	Vector3 operator/=(float num);

	//Operators with self
	Vector3 operator+ (Vector3 Vector);
	Vector3 operator+=(Vector3 Vector);
	Vector3 operator- (Vector3 Vector);	
	Vector3 operator-=(Vector3 Vector);
	Vector3 operator* (Vector3 Vector);
	Vector3 operator*=(Vector3 Vector);
	Vector3 operator/ (Vector3 Vector);
	Vector3 operator/=(Vector3 Vector);	
	bool operator==(Vector3 Vector);	
	bool operator!=(Vector3 Vector);

	//Other vector interactions
	Vector3(Vector2 *V2, float Z=0);
	Vector3 operator=(Vector2* Vec2);

	//Functions
	float length();
	void Set(float X, float Y, float Z);	
	void Add(float X, float Y, float Z);
	void Set(Vector3 V);
	void Add(Vector3 A);	
};


class Vector2
{
public:
	float x,y;
	//Constructors
	Vector2();
	Vector2(float X,float Y);
	//Operators
	Vector2 operator*(float num);
    Vector2 operator/(float num);
	Vector2 operator+ (Vector2 Vector);
	Vector2 operator- (Vector2 Vector);	
	Vector2 operator+=(Vector2 Vector);
	Vector2 operator-=(Vector2 Vector);
	Vector2 operator* (Vector2 Vector);
	Vector2 operator*=(Vector2 Vector);
	Vector2 operator/ (Vector2 Vector);
	bool operator==(Vector2 Vector);
	bool operator!=(Vector2 Vector);
	//with other vectors
	Vector2 operator* (Vector3 Vector);
	//Functions
	void Set(float X,float Y);
	void Set(Vector2 V);
	void Add(float X,float Y);
};

class Vector4
{
public:
	float x,y,z,w;
	Vector4();
	Vector4(Vector3 Vector);
	Vector4(float X, float Y, float Z,float W);	
	Vector4 operator*(float num);
	Vector4 operator/(float num);
	//Operators
	Vector4 operator+ (Vector4 Vector);	
	Vector4 operator- (Vector4 Vector);
	Vector4 operator+=(Vector4 Vector);
	Vector4 operator-=(Vector4 Vector);
	Vector4 operator* (Vector4 Vector);
	Vector4 operator*=(Vector4 Vector);
	Vector4 operator/ (Vector4 Vector);
	bool operator==(Vector4 Vector);
	//with other vectors
	Vector4 operator+ (Vector3 Vector);
	//Functions
	void Set(float X, float Y, float Z,float W);	
	void Add(float X, float Y, float Z,float W);
	void Set(Vector4 V);
};

template<class TYPE>
class TEMPLATED_VECTOR3
{
public:
	TYPE x,y,z;
	//Constructors
	TEMPLATED_VECTOR3();
	TEMPLATED_VECTOR3(TYPE X, TYPE Y, TYPE Z);
	//Operators with floats	
    TEMPLATED_VECTOR3 operator* (TYPE num);
	TEMPLATED_VECTOR3 operator*=(TYPE num);
    TEMPLATED_VECTOR3 operator/ (TYPE num);
	TEMPLATED_VECTOR3 operator/=(TYPE num);
	//operators with other vectors
	TEMPLATED_VECTOR3 operator+ (TEMPLATED_VECTOR3 Vector);
	TEMPLATED_VECTOR3 operator+=(TEMPLATED_VECTOR3 Vector);
	TEMPLATED_VECTOR3 operator- (TEMPLATED_VECTOR3 Vector);	
	TEMPLATED_VECTOR3 operator-=(TEMPLATED_VECTOR3 Vector);
	TEMPLATED_VECTOR3 operator* (TEMPLATED_VECTOR3 Vector);
	TEMPLATED_VECTOR3 operator*=(TEMPLATED_VECTOR3 Vector);
	TEMPLATED_VECTOR3 operator/ (TEMPLATED_VECTOR3 Vector);
	TEMPLATED_VECTOR3 operator/=(TEMPLATED_VECTOR3 Vector);
	bool operator==(TEMPLATED_VECTOR3 Vector);	
	bool operator!=(TEMPLATED_VECTOR3 Vector);
	//Functions
	TYPE length();
	void Set(TYPE X, TYPE Y, TYPE Z);
	void Set(Vector3 V);
	void Add(TYPE X, TYPE Y, TYPE Z);
	void Add(TEMPLATED_VECTOR3 A);
};

//Vector Conversions
Vector3 GetVector3(Vector2 V);
Vector3 GetVector3(Vector4 V);

Vector2 GetVector2(Vector3 V);
Vector2 GetVector2(Vector4 V);

Vector4 GetVector4(Vector3 V);
Vector4 GetVector4(Vector2 V);

///////////////////////////////////////
//What should be : Templated Vector.cpp
///////////////////////////////////////

template<class TYPE>
TEMPLATED_VECTOR3<TYPE>::TEMPLATED_VECTOR3()
{
	x=0;
	y=0;
	z=0;
}
template<class TYPE>
TEMPLATED_VECTOR3<TYPE>::TEMPLATED_VECTOR3(TYPE X, TYPE Y, TYPE Z) 
{ 
	x=X;
	y=Y;
	z=Z;
}
//Operators with TYPEs
template<class TYPE>
TEMPLATED_VECTOR3<TYPE> TEMPLATED_VECTOR3<TYPE>::operator*(TYPE num)
{
	return TEMPLATED_VECTOR3<TYPE>(x * num, y * num, z * num);
}
template<class TYPE>
TEMPLATED_VECTOR3<TYPE> TEMPLATED_VECTOR3<TYPE>::operator*=(TYPE num)
{
	Set(x*num,y*num,z*num);
	return *this;
}
template<class TYPE>
TEMPLATED_VECTOR3<TYPE> TEMPLATED_VECTOR3<TYPE>::operator/(TYPE num)
{
	return TEMPLATED_VECTOR3(x / num, y / num, z / num);
}
template<class TYPE>
TEMPLATED_VECTOR3<TYPE> TEMPLATED_VECTOR3<TYPE>::operator/=(TYPE num)
{
	Set(x/num,y/num,z/num);
	return *this;
}
template<class TYPE>
TEMPLATED_VECTOR3<TYPE> TEMPLATED_VECTOR3<TYPE>::operator+(TEMPLATED_VECTOR3 Vector)
{
	return TEMPLATED_VECTOR3(Vector.x + x, Vector.y + y, Vector.z + z);
}
template<class TYPE>
TEMPLATED_VECTOR3<TYPE> TEMPLATED_VECTOR3<TYPE>::operator+=(TEMPLATED_VECTOR3 Vector)
{//A+=B;
	Set(x+Vector.x,y+Vector.y,z+Vector.z);
	return *this;
}
template<class TYPE>
TEMPLATED_VECTOR3<TYPE> TEMPLATED_VECTOR3<TYPE>::operator-(TEMPLATED_VECTOR3 Vector)
{
	return TEMPLATED_VECTOR3(x - Vector.x, y - Vector.y, z - Vector.z);
}
template<class TYPE>
TEMPLATED_VECTOR3<TYPE> TEMPLATED_VECTOR3<TYPE>::operator-=(TEMPLATED_VECTOR3 Vector)
{//A-=B;
	Set(x-Vector.x,y-Vector.y,z-Vector.z);
	return *this;
}
template<class TYPE>
TEMPLATED_VECTOR3<TYPE> TEMPLATED_VECTOR3<TYPE>::operator*(TEMPLATED_VECTOR3 Vector)
{
	return TEMPLATED_VECTOR3(x*Vector.x,y*Vector.y,z*Vector.z);
}
template<class TYPE>
TEMPLATED_VECTOR3<TYPE> TEMPLATED_VECTOR3<TYPE>::operator*=(TEMPLATED_VECTOR3 Vector)
{//A-=B;
	Set(x*Vector.x,y*Vector.y,z*Vector.z);
	return *this;
}
template<class TYPE>
TEMPLATED_VECTOR3<TYPE> TEMPLATED_VECTOR3<TYPE>::operator/(TEMPLATED_VECTOR3 Vector)
{
	return TEMPLATED_VECTOR3(x/Vector.x,y/Vector.y, z/Vector.z);
}
template<class TYPE>
TEMPLATED_VECTOR3<TYPE> TEMPLATED_VECTOR3<TYPE>::operator/=(TEMPLATED_VECTOR3 Vector)
{
	Set(x/Vector.x,y/Vector.y,z/Vector.z);
	return *this;
}
template<class TYPE>
bool TEMPLATED_VECTOR3<TYPE>::operator==(TEMPLATED_VECTOR3 Vector)
{
	return (x==Vector.x && y==Vector.y && z==Vector.z);
}
template<class TYPE>
bool TEMPLATED_VECTOR3<TYPE>::operator!=(TEMPLATED_VECTOR3 Vector)
{
	return (x!=Vector.x || y!=Vector.y || z!=Vector.z);
}
//Functions
template<class TYPE>
TYPE TEMPLATED_VECTOR3<TYPE>::length()
{
	return (TYPE)sqrt(x*x+y*y+z*z);
}
template<class TYPE>
void TEMPLATED_VECTOR3<TYPE>::Set(TYPE X, TYPE Y, TYPE Z)
{
	x=X;
	y=Y;
	z=Z;
}
/*template<class TYPE>
void TEMPLATED_VECTOR3<TYPE>::Set(TEMPLATED_VECTOR3<TYPE> V) 
{
	*this=V;
}*/
template<class TYPE>
void TEMPLATED_VECTOR3<TYPE>::Add(TYPE X, TYPE Y, TYPE Z)
{
	x+=X;
	y+=Y;
	z+=Z;
}
template<class TYPE>
void TEMPLATED_VECTOR3<TYPE>::Add(TEMPLATED_VECTOR3 A)
{
	x+=A.x;
	y+=A.y;
	z+=A.z;
}