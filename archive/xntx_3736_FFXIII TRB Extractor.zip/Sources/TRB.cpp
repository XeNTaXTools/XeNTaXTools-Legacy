

#include "StdAfx.h"

void ELEMENT_DEF::BigEndian()
{
	Stream = BigEndian16( Stream );
	Offset = BigEndian16( Offset );
	Type = BigEndian32( Type );
	Count = BigEndian32( Count );
	Usage = BigEndian16( Usage );
	Index = BigEndian16( Index );
}

void BASE_BUFFER_HEADER::BigEndian()
{
	Zeros = BigEndian32( Zeros );
	ChunkSize1 = BigEndian32( ChunkSize1 );
	ChunkSize2 = BigEndian32( ChunkSize2 );
	ElementDefs = BigEndian32( ElementDefs );
	Elements = BigEndian32( Elements );
	ElementSize = BigEndian32( ElementSize );
}

void FACE::BigEndian()
{
	v1 = BigEndian16( v1 );
	v2 = BigEndian16( v2 );
	v3 = BigEndian16( v3 );	
}

void VERTEX::Prepare()
{
	//x = BigEndian16(x );
	//D3DXFLOAT16 f = (D3DXFLOAT16*)&x;
	//float finalF = f;

	hfx = h2f( x );
	hfy = h2f( y );
	hfz = h2f( z );

	x = BigEndian16( x );
	y = BigEndian16( y );
	z = BigEndian16( z );	
}
void SEDB_HEADER::BigEndian()
{
	//unknown0x04 = BigEndian32( unknown0x04 );
	dataSize = BigEndian32( dataSize );
	nextOffset = BigEndian32( nextOffset );
}
void ENVD_BASE::BigEndian()
{
	Header.BigEndian();

	nameOffset = BigEndian16( nameOffset );
	for(int y=0; y<2; y++)
	{
		dataInfo[y].vertexCount= BigEndian16( dataInfo[y].vertexCount );
		dataInfo[y].indicesOffset= BigEndian16( dataInfo[y].indicesOffset );
		dataInfo[y].weightsOffset= BigEndian16( dataInfo[y].weightsOffset );
	}
}
void GTEX::BigEndian()
{	
	unknownA = BigEndian16(unknownA);   
	unknownC = BigEndian16(unknownC);
	width    = BigEndian16(width);
	height   = BigEndian16(height);
	unknownD = BigEndian16(unknownD);
	unknownE = BigEndian32(unknownE);
	unknownF = BigEndian32(unknownF);

	for(int y=0; y<14; y++)
		Padding[y] = BigEndian32( Padding[y] );
}
void SEDB_TXB::BigEndian()
{
	Tex.BigEndian();
	return;

	unknownA = BigEndian32(unknownA);
	unknownB = BigEndian32(unknownB);
	texSize = BigEndian32(texSize); //seems like original size, does not include padding

	for(int y=0;y<7;y++)
		unknownC[y] =  BigEndian32(unknownC[y]);

	unknownD =BigEndian32(unknownD);

	for(int y=0;y<3;y++)
		unknownE[y]=BigEndian32(unknownE[y]);
}
void SEDB_SHD_FILE::BigEndian()
{
	for(int y=0; y<5; y++)
		UnknownC[y] = BigEndian32(UnknownC[y]);	

	//UnknownD = BigEndian16(UnknownD);
}
void SEDB_SHD::BigEndian()
{
	for(int y=0; y<20; y++)
		Unknown[y] = BigEndian16(Unknown[y]);

	for(int y=0; y<14; y++)
		UnknownB[y] = BigEndian16(UnknownB[y]);	

	FILE.BigEndian();	
}
void PRAM::BigEndian()
{
	unknownA = BigEndian16( unknownA );
	unknownB = BigEndian16( unknownA );
	unknownC = BigEndian32( unknownC );
	unknownD = BigEndian32( unknownD );
	unknownE = BigEndian32( unknownE );
	unknownF = BigEndian32( unknownF );
	numTextures = BigEndian32( numTextures );
	sampleDataOfs = BigEndian32( sampleDataOfs );
	sampleDataEnd = BigEndian32( sampleDataEnd );
	ofsTableEnd = BigEndian32( ofsTableEnd );
}
void MARKER_SIZE_48::BigEndian()
{
	for(int y=0;y<2;y++)
		Size[y] = BigEndian32( Size[y] );

	for(int y=0;y<8;y++)
		Unknown[y] = BigEndian32( Unknown[y] );
};
void MARKER_SIZE_32::BigEndian()
{
	for(int y=0;y<2;y++)
		Size[y] = BigEndian32( Size[y] );

	for(int y=0;y<4;y++)
		Unknown[y] = BigEndian32( Unknown[y] );
};
void MARKER_STR::BigEndian()
{
	for(int y=0;y<2;y++)
		Unknown[y] = BigEndian32( Unknown[y] );
};
void SEDBWRB::BigEndian()
{
	Header.BigEndian();
	WRB.BigEndian();
	MDLC.BigEndian();
	HEAD.BigEndian();
	MDL.BigEndian();
	NAME.BigEndian();
	HEAD2.BigEndian();

	StartData.BigEndian();
}
void START_OBJECT_DATA::BigEndian()
{
	MESH.BigEndian();
	HEAD3.BigEndian();
	STR.BigEndian();
	RSID.BigEndian();
	RSTP.BigEndian();
	PRID.BigEndian();
	PRTP.BigEndian();
}
void END_OBJECT_DATA::BigEndian()
{
	AABB.BigEndian();
	AABB2.BigEndian();
}
void MESH_HEADER::BigEndian()
{
	for(int y=0; y<2; y++)
		Size[y] = BigEndian32( Size[y] );

	for(int y=0; y<4; y++)
		Unknown[y] = BigEndian32( Unknown[y] );
}
void ELB_REPEAT::BigEndian()
{
	Offset1 = BigEndian16( Offset1 );
	Type1 = BigEndian16( Type1 );
	Offset2 = BigEndian16( Offset2 );
	Type2 = BigEndian16( Type2 );	

	for(int y=0; y<12; y++)
		A[y] = BigEndian16( A[y] );
}
void SEDBelb::BigEndian()
{
	for(int y=0; y<26; y++)
		B[y] = BigEndian16( B[y] );	
}
TRB_BONE *TRB_MODEL::GetBone(int Index)
{
	for(int y=0; y<Bones.Size; y++)
	{
		if (Bones[y]->index == Index )
			return Bones[y];
	}

	return NULL;
}
int TRB_MODEL::GetBoneIndex(char *Name)
{
	for(int y=0; y<Bones.Size; y++)
	{
		if ( strcmp( Bones[y]->Name, Name ) ==0 )
			return y;
	}

	return -1;
}
unsigned int rev32u (unsigned int i)
{
	unsigned char b1, b2, b3, b4;
	b1 = i & 255;
	b2 = ( i >> 8 ) & 255;
	b3 = ( i>>16 ) & 255;
	b4 = ( i>>24 ) & 255;
	return ((unsigned int)b1 << 24) + ((unsigned int)b2 << 16) + ((unsigned int)b3 << 8) + b4;

}

unsigned short rev16u (unsigned short i)
{
	unsigned char b1, b2;
	b1 = i & 255;
	b2 = ( i >> 8 ) & 255;
	return ((unsigned short)b1 << 8) + b2;

}

short rev16s (unsigned short i)
{
	unsigned char b1, b2;
	b1 = i & 255;
	b2 = ( i >> 8 ) & 255;
	return ((short)b1 << 8) + b2;

}


float h2f(unsigned short y)
{

	y=rev16u(y);

	U value;

    int s = (y >> 15) & 0x00000001;
    int e = (y >> 10) & 0x0000001f;
    int m =  y        & 0x000003ff;

    if (e == 0)
    {
	if (m == 0)
	{
	    //
	    // Plus or minus zero
	    //

	    return s << 31;
	}
	else
	{
	    //
	    // Denormalized number -- renormalize it
	    //

	    while (!(m & 0x00000400))
	    {
		m <<= 1;
		e -=  1;
	    }

	    e += 1;
	    m &= ~0x00000400;
	}
    }
    else if (e == 31)
    {
	if (m == 0)
	{
	    //
	    // Positive or negative infinity
	    //

	    return (s << 31) | 0x7f800000;
	}
	else
	{
	    //
	    // Nan -- preserve sign and significand bits
	    //

	    return (s << 31) | 0x7f800000 | (m << 13);
	}
    }

    //
    // Normalized number
    //

    e = e + (127 - 15);
    m = m << 13;

    //
    // Assemble s, e and m.
    //

	value.i = (s << 31) | (e << 23) | m;
    return value.f;

}

long find_string (unsigned char *buf, size_t start,
						 size_t len, const char *s)
{
	long i, j;
	int slen = strlen(s);
	long imax = len - slen - 1;
	long ret = -1;
	int match;

	for (i=start; i<imax; i++) {
		match = 1;
		for (j=0; j<slen; j++) {
			if (buf[i+j] != s[j]) {
				match = 0;
				break;
			}
		}
		if (match) {
			ret = i;
			break;
		}
	}

	return ret;
}

void TRB_CONVERTER::ReadObjectData( TRB_MODEL *Model )
{	
	int  vhsize;//vertex header size
	ELEMENT_DEF  c;
	FACE *face;

	BUFFER_HEADER *f = NULL;
	BUFFER_HEADER *v = NULL;

	int LastValidOffset;

	while (Offset < FileSize)
	{
		LastValidOffset = Offset;
		Offset = find_string( Data, Offset, FileSize, "STMS") ;
		if (Offset == -1)
			break;
			
		LastObject = new TRB_OBJECT;
		Model->Object.Add( LastObject );

		f = &LastObject->IndexBuffer;
		v = &LastObject->VertexBuffer;
			
		// face list (start new mesh)
		//f = *(BASE_OBJECT_HEADER*)(buf+offs);
		memcpy( f, Data + Offset, sizeof( BASE_BUFFER_HEADER ) );
		f->FileOffset = Offset;	

		Offset = find_string( Data, Offset + 1, FileSize, "STMS") ;
			
		// vertices list
		//v = *(BASE_OBJECT_HEADER*)(buf+offs);
		memcpy( v, Data + Offset, sizeof( BASE_BUFFER_HEADER ) );

		v->BigEndian();
		f->BigEndian();
			
		vhsize = (v->ElementSize + 4) * 4;

		ELEMENT_DEF *VertexDef = NULL;
		ELEMENT_DEF *TexcordDef = NULL;

		ELEMENT_DEF *NormalDef = NULL;
		ELEMENT_DEF *UnknownDef = NULL;
		ELEMENT_DEF *ColorDef = NULL;

		ELEMENT_DEF *BoneIndexDef = NULL;
		ELEMENT_DEF *BoneWeightDef = NULL;

		v->ElementDef.AddEmptyArray( v->ElementDefs );

		int DefsSize = 4 + sizeof(ELEMENT_DEF) * v->ElementDefs;
		for (int j=0; j<v->ElementDefs; j++)
		{
			c = *(ELEMENT_DEF*)(Data + Offset + sizeof( BASE_BUFFER_HEADER ) + 4 +j* sizeof(ELEMENT_DEF) );
				
			c.BigEndian();
			v->ElementDef[j] = c;

			switch (c.Usage)
			{
				case 0 : VertexDef = &v->ElementDef[j]; break;
				case 2 : NormalDef = &v->ElementDef[j]; break;
				case 3 : ColorDef = &v->ElementDef[j]; break;
				case 8 : TexcordDef = &v->ElementDef[j];break;
				case 9 : //??
							break;
				case 13: UnknownDef = &v->ElementDef[j];break;
				case 15: BoneIndexDef = &v->ElementDef[j];break;
				case 14: BoneWeightDef = &v->ElementDef[j];break;
				default:
					break;
			}
			//c->Usage = BigEndian16( c->Usage );

		}
		Offset += DefsSize;

		WORD DifData[14];
		memcpy( DifData, Data + Offset, 28 );
		for(int y=0; y<14; y++)
			DifData[y] = BigEndian16( DifData[y] );
			
		Offset += 28;

		for (int i=0;i<v->Elements;i++)
		{				
			VERTEX vert;
			if (VertexDef)//Type 4
			{
				vert = *(VERTEX*)( Data + Offset + VertexDef->Offset +i*v->ElementSize);
				vert.Prepare();
				
				D3DXVECTOR3 V( vert.x, vert.y, vert.z );
				V = (V / 32768.0f);
				//V = (V / 65535.0f);

				if (LastObject->VertexArray.Size == 0)
					LastObject->VertexArray.Allocate( v->Elements );

				LastObject->VertexArray.Add( V );
			}

			if (TexcordDef)//Type 2
			{
				vert = *(VERTEX*)(Data + Offset + TexcordDef->Offset +i*v->ElementSize);
				vert.Prepare();
				
				D3DXVECTOR2 V( vert.hfx, vert.hfy );

				if (LastObject->TexcoordArray.Size == 0)
					LastObject->TexcoordArray.Allocate( v->Elements );

				LastObject->TexcoordArray.Add( V );			
			}

			if (NormalDef)//Type 3
			{
				BYTE *NormalByte = (BYTE*)(Data + Offset + NormalDef->Offset + i*v->ElementSize);
				float Normal[3];

				for(int y=0; y<3; y++)
					Normal[y] = ((float)NormalByte[y])/255.0f * 2 - 1;
						
				D3DXVECTOR3 Vec3( Normal[0], Normal[1], Normal[2] );
				float len = D3DXVec3Length( &Vec3 );

				D3DXVECTOR3 V( Normal[0], Normal[1], Normal[2] );

				if (LastObject->NormalArray.Size == 0)
					LastObject->NormalArray.Allocate( v->Elements );

				LastObject->NormalArray.Add( V );
			}
			if (ColorDef)//Type 3
			{
				BYTE *ByteVector  = (BYTE*)(Data + Offset + ColorDef->Offset + i*v->ElementSize);
				WORD *WordVector2 = (WORD*)(Data + Offset + ColorDef->Offset + i*v->ElementSize);

				float Vector[4];
				for(int y=0; y<4; y++)
				{
					Vector[y] = ((float)ByteVector[y])/255.0f;
				}										
				D3DXVECTOR3 Vec3( Vector[0], Vector[1], Vector[2] );

				if (LastObject->ColorArray.Size == 0)
					LastObject->ColorArray.Allocate( v->Elements );

				LastObject->ColorArray.Add( Vec3 );
			}
			if (UnknownDef)//Type 3
			{
				BYTE *ByteVector  = (BYTE*)(Data + Offset + UnknownDef->Offset + i*v->ElementSize);
				WORD *WordVector2 = (WORD*)(Data + Offset + UnknownDef->Offset + i*v->ElementSize);

				//float Texcoords[2]
				float Vector[4];
				for(int y=0; y<4; y++)
				{
					Vector[y] = ((float)ByteVector[y])/255.0f;// * 2 - 1;
				}										
				D3DXVECTOR4 Vec( Vector[0], Vector[1], Vector[2], Vector[3] );
			}
			if (BoneIndexDef)//Type 6
			{
				char *Indices = (char*)(Data + Offset + BoneIndexDef->Offset + i*v->ElementSize);				

				for(int y=0;y <4; y++)
				{
					//No BoneIndex is bigger than this, must mean that they're relative
					if (Indices[y] > 47)
						Indices[y] = Indices[y];
				}
				BONE_INDICES BIndices= { Indices[0],Indices[1], Indices[2], Indices[3] };

				if (LastObject->BoneIndicesArray.Size == 0)
					LastObject->BoneIndicesArray.Allocate( v->Elements );

				LastObject->BoneIndicesArray.Add( BIndices );
			}
			if (BoneWeightDef)//Type 3
			{
				BYTE *ByteWeights = (BYTE*)(Data + Offset + BoneWeightDef->Offset + i*v->ElementSize);
				float FloatWeights[4];

				for(int y=0; y<4; y++)
					FloatWeights [y] = ((float)ByteWeights[y])/255.0f;

				D3DXVECTOR4 V( FloatWeights[0], FloatWeights[1], FloatWeights[2], FloatWeights[3] );

				if (LastObject->BoneWeightsArray.Size == 0)
					LastObject->BoneWeightsArray.Allocate( v->Elements );

				LastObject->BoneWeightsArray.Add( V );
			}
		}


		LastObject->FaceArray.Allocate( f->Elements/3 );

		for (int i=0;i<f->Elements/3;i++)
		{
			face = (FACE*)(Data + f->FileOffset + 48 + i*6);

			face->BigEndian();
				
			LastObject->FaceArray.Add( *face );
		}
	
		Offset += v->ElementSize * v->Elements;
			
		ENVD_INFO *ENVD = new ENVD_INFO;

		int NewENVD   = find_string( Data, Offset , FileSize, "ENVD");
		int EndOffset = find_string( Data, Offset , FileSize, "AABB");

		if (NewENVD != -1 && ( NewENVD < EndOffset || EndOffset == -1))
		{
			Offset = NewENVD;
		}

		ENVD_BASE *p = ENVD;
		*p = *(ENVD_BASE*)(Data + Offset);
						
		while (strcmp( p->Header.dataTag, "ENVD") == 0)
		{
			LastObject->BoneMappings.Add( ENVD );
				
			ENVD->BigEndian();
			ENVD->vertexIndices.Clear();
			ENVD->vertexWeights.Clear();
			
			Offset += 16;
			char *Name = (char*)(Data + Offset + p->nameOffset );
			strcpy( ENVD->jointName, Name );

			WORD *Indices = (WORD*)(Data + Offset + p->dataInfo[0].indicesOffset );			
			BYTE *Weights = (BYTE*)(Data + Offset + p->dataInfo[0].weightsOffset );

			for(int y=0; y<p->dataInfo[0].vertexCount; y++)
			{
				Indices[y] = BigEndian16( Indices[y] );

				ENVD->vertexIndices.Add( Indices[y] );

				float W = (float)Weights[y]/255.0f;
				ENVD->vertexWeights.Add( W );
			}

			Offset += p->dataInfo[0].weightsOffset + p->dataInfo[0].vertexCount;

			NewENVD   = find_string( Data, Offset, FileSize, "ENVD");
			EndOffset = find_string( Data, Offset, FileSize, "AABB");

			if (NewENVD != -1 && ( NewENVD < EndOffset || EndOffset == -1))
			{
				Offset = NewENVD;
			}
			else
				break;

			ENVD = new ENVD_INFO;
			p = ENVD;
			*p = *(ENVD_BASE*)(Data + Offset);
		}

		if (EndOffset != -1)
		{
			END_OBJECT_DATA *EndData = (END_OBJECT_DATA*)(Data + EndOffset );
			EndData->BigEndian();

			EndOffset += sizeof( *EndData);

			START_OBJECT_DATA *StartData = (START_OBJECT_DATA*)(Data + EndOffset );
			StartData->BigEndian();
			StartData = StartData;
		}
	}
	Offset = LastValidOffset;
}
void TRB_CONVERTER::Load( char *FileName, TRB_MODEL *Model )
{
	FILE * in;	

	char stms[] = "STMS\0";

	LastObject = NULL;	

	Data = NULL;
	Offset = 0;

	in = fopen( FileName, "rb");

//	in = fopen("release/c001.x360.trb","rb");
	if (!in)
	{
		printf ("invalid input file\n");
		return;
	}

	FileSize = filelength (fileno (in));

	if (!FileSize)
	{
		printf ("invalid input file\n");
		return;
	}

	if (Data)
		delete[] Data;

	Data = new BYTE[ FileSize ];
	if (!Data)
	{
		printf ("not enough memory\n");
		return;
	}

	fread( Data, 1, FileSize, in);
	fclose (in);

	DYNAMIC_ARRAY< SEDB_TXB > TXBArray;

	BYTE *Test = (Data + 1440664 );

	while( Offset < FileSize)
	{
		Offset = find_string( Data, Offset, FileSize, "SEDB") ;
		if (Offset == -1)
			break;

		SEDB_HEADER *Header = (SEDB_HEADER*)(Data + Offset);
		//Header->BigEndian();

		if (strcmp(Header->dataTag, "SEDBtxb") == 0)
		{
			SEDB_TXB *TXB = (SEDB_TXB*)Header;
			TXB->BigEndian();
			TXBArray.Add( *TXB );
			Offset++;		
		}
		else if (strcmp(Header->dataTag, "SEDBshd") == 0)
		{
			SEDB_SHD *SHD = (SEDB_SHD*)Header;
			SHD->BigEndian();
			SEDB_SHD_FILE * FILE = &SHD->FILE;
			Offset+= sizeof(SEDB_SHD) - sizeof( SEDB_SHD_FILE );

			while ( strcmp( FILE->Id, "FILE") == 0)
			{
				Offset+= FILE->UnknownC[1];
				FILE = (SEDB_SHD_FILE*)(Data + Offset );
				FILE->BigEndian();			
			}

			Offset = find_string( Data, Offset, FileSize, "PRAM") ;

			PRAM *Param = (PRAM*)( Data + Offset );
			Param->BigEndian();
			
		}
		else if (strcmp( Header->dataTag, "SEDBwrb") == 0)
		{
			SEDBWRB *WRB = (SEDBWRB*)( Data + Offset );
			WRB->BigEndian();
			ReadObjectData( Model );
		}
		else if (strcmp( Header->dataTag, "SEDBelb") == 0)
		{
			SEDBelb *ELB = (SEDBelb*)( Data + Offset );
			Offset += sizeof( SEDBelb );
			ELB_REPEAT *ELB_STRUCT = (ELB_REPEAT*)( Data + Offset );

			for(int y=0; y<ELB->Size; y++)
				ELB_STRUCT[y].BigEndian();			
			
			Offset += sizeof(ELB_REPEAT) * ELB->Size;
			int *ExtraInfoI = (int*)( Data + Offset );
			Vector3 *ExtraInfoV = (Vector3*)( Data + Offset );
			//for(int y=0; y<ELB->Size * 3; y++)
				//ExtraInfo[y] = BigEndian32( ExtraInfo[y] );

			Offset += ELB->Size * 12;
			
			//ELB->BigEndian();
			ELB = ELB;
		}
		else if (strstr( Header->dataTag, "SEDBSKL"))
		{
			SEDBSKL *SkeletonHeader = (SEDBSKL*)(Data + Offset );
			if (strcmp( SkeletonHeader->lks, "lks") != 0)
			{
				goto ret;
			}
		
			DYNAMIC_ARRAY< TRB_BONE* > & Bones = Model->Bones;

			for(int t =0; t<1; t++)
			{
				Bones.Add( new TRB_BONE );
				strcpy( Bones[0]->Name, "Default" );
			}
			D3DXVECTOR3 Vec3( (float)SkeletonHeader->unknownA[0]/32768.0f,  
				(float)SkeletonHeader->unknownA[1]/32768.0f,  (float)SkeletonHeader->unknownA[2]/32768.0f );

			int numDataBones = SkeletonHeader->boneDataSize / sizeof(BONE);

			int numBoneNames = 0;
			int ofs = sizeof(SEDBSKL) + SkeletonHeader->boneDataSize;// + 16;
			//char **boneNamesAr = (char **)_alloca(sizeof(char **)*sklHdr->numBones);
			while (ofs < FileSize && numBoneNames < SkeletonHeader->numBones)
			{
				char *boneNames = (char *)SkeletonHeader + ofs;
				while (ofs < FileSize && !boneNames[0])
				{
					ofs++;
					boneNames = (char *)SkeletonHeader + ofs;
				}
				if (boneNames[0])
				{
					Bones.Add( new TRB_BONE );
					if (1)//numBoneNames >4)
					{
						strcpy( Bones[ numBoneNames + 1 ]->Name, boneNames );
						ofs += strlen( Bones[ numBoneNames + 1 ]->Name ) + 1;
					}
					else
					{
						strcpy( Bones[ numBoneNames ]->Name, boneNames );
						ofs += strlen( Bones[ numBoneNames ]->Name ) + 1;
					}
				
					numBoneNames++;
					boneNames = (char *)SkeletonHeader + ofs;					
				}
			}


			BONE *bones = (BONE *)(SkeletonHeader + 1);
			bones = (BONE*) ( Data + Offset + sizeof(*SkeletonHeader)  );
		
			for (int i = 0; i < numDataBones; i++)
			{
				BONE *bsrc = bones + i;
				int dstIdx = bsrc->globalIdx;
				TRB_BONE *Dest = Bones[ dstIdx ];
				BONE *BaseData = Dest;
				*BaseData = *bsrc;
				Dest->HadData = true;

				D3DXQUATERNION Quat( bsrc->q[0],bsrc->q[1], bsrc->q[2], bsrc->q[3] );
				D3DXMatrixRotationQuaternion( &Dest->Rotation, &Quat );
				if (bsrc->scl[0] != 1.0f || bsrc->scl[1] != 1.0f || bsrc->scl[2] != 1.0f)
				{
					bsrc = bsrc;
				}

				//Math_QuatToMat( bsrc->q, &bdst->mat, false, true);
				//Math_VecCopy(bsrc->trans, bdst->mat.o);
				//Math_VecScale(bdst->mat.x1, bsrc->scl[0]);
				//Math_VecScale(bdst->mat.x2, bsrc->scl[1]);
				//Math_VecScale(bdst->mat.x3, bsrc->scl[2]);
			
				if (bsrc->parent != -1)
					Dest->Parent = Model->GetBone( bsrc->parent );
				//Dest->parentIdx = (bsrc->parent != -1) ? Bones[ bsrc->parent ]->globalIdx : -1;
			}

			Offset += sizeof(BONE ) *numDataBones;
			Offset = Offset;
		}

		Offset++;
	}

	
ret:
	int I[10];
	I[0] = Model->GetBoneIndex("L_fing1a");
	I[1] = Model->GetBoneIndex("L_fing3a");//Lforearm	
	I[2] = Model->GetBoneIndex("L_fing1b");
	I[3] = Model->GetBoneIndex("L_fing3b");//Lforearm	
	I[4] = Model->GetBoneIndex("L_fing1c");
	I[5] = Model->GetBoneIndex("L_fing3c");//Lforearm	

}

