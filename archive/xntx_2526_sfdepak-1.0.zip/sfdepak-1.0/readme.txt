Star Wars Starfighter unpacker version 1.0
--------------------------------------------
programmed by Benjamin Haisch

WWW:    http://gamefileformats.virtualave.net/
e-mail: john_doe@techie.com

Well, well. So here it begins.
This little tool will extract the contents of the Pak resource files
used by Star Wars Starfighter.
It's quite simple to use:
On the command line, switch to the directory the Pak files are in
(usually your game directory, duh!).
Then, type "sfdepak Pak-file", where Pak-file is, of course, the name
of the Pak-file you want to extract. You can also supply an output
directory as a second parameter, but this is optional. By default
the output directory will be called like the Pak-file just without
the ".pak" extension.

If you encounter a bug, have other problems or just want to say hello,
just mail me (see above for my e-mail addy & website).

You may distribute this tool freely as long as you don't change this
file and only distribute the files (Exe+readme) together and
mention my name and preferably the address of my website as the source
of this tool, too.

I'll send the Pascal (don't kill me for using Pascal, but I don't have
the money to get VC++ right now...donations are welcome :) source code
by request (I might have to change it before as it uses some of my bigger
tool libraries I don't want to hand out).

Disclaimer:
Star Wars Stafighter is (c) LucasArts Entertainment Company, LLC.
I am in no way affiliated or related to LucasArts.
This program is solely my work and not authorised or supoorted by
LucasArts.
I am not responsible for any data loss or other damages caused by
this program.



To extract texture and model from pmdl file:
Open a command prompt then type
sfdepak.exe nameofpmdl.pmdl
