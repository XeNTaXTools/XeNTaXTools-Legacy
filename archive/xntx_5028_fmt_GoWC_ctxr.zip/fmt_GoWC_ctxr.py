from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("God Of War Collection 1", ".ctxr")
	noesis.setHandlerTypeCheck(handle, noeCheckGeneric)
	noesis.setHandlerLoadRGBA(handle, WTFLoadRGBA)
	#noesis.logPopup()
	return 1


def WTFLoadRGBA(data, texList):
	datasize = len(data) - 0x80        #length of data minus 128 byte custom header 
	bs = NoeBitStream(data)
	bs.seek(0x06, NOESEEK_ABS)
	height = bs.readInt()
	imgWidth = bs.readInt()
	imgHeight = height * 2
	bs.seek(0x80, NOESEEK_ABS)         #goto address 0x80 (128 bytes from start)
	data = bs.readBytes(datasize)      #read file data minus custom header
	
	#DXT1
	rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_DXT1)
	texFmt = noesis.NOESISTEX_DXT1
	#unknown, not handled
	print("WARNING: Unhandled image format")
	texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
	return 1