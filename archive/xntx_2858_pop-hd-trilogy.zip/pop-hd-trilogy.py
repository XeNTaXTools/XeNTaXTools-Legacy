#!/usr/bin/env python

import sys;
import os;
import os.path;
from struct import unpack;

if len(sys.argv) < 2:
	print("Usage: python pop-hd-trilogy.py sound.bf [directory]");
	exit();

filename = sys.argv[1];
basename = os.path.splitext(filename)[0];
outputdir = '.';

if len(sys.argv) >= 3:
	outputdir = sys.argv[2];

with open(filename, 'rb') as f:
	if f.read(16) != "[ GEAR BigFile ]":
		print("This file doesn't appear to be a GEAR BigFile");
		exit();
		
	# Initialize the output directory
	if not os.path.exists(outputdir):
		os.mkdir(outputdir);
		
	f.read(8);
	fileCount = unpack('<I', f.read(4))[0];
	f.read(4);
	offsets = [unpack('<Q', f.read(8))[0] for x in range(fileCount)];
	sizes = [unpack('<I', f.read(4))[0] for x in range(fileCount)];
	crcs = [unpack('<I', f.read(4))[0] for x in range(fileCount)];
	unknown = f.read(fileCount);
	
	all = sorted(zip(offsets, sizes, crcs), key=lambda x: x[0])
	
	index = 1;
	for offset, size, crc in all:
		outfile = os.path.join(outputdir, basename + '_' + str(index));
		index += 1;

		f.seek(offset);
		
		# How many bytes are there in an uncompressed block?
		decblocksize = 2 ** unpack('<B', f.read(1))[0];
		
		# Calculate the number of compressed blocks to read in
		blockcount = size / decblocksize;
		if size % decblocksize > 0:
			blockcount += 1;
			
		print('Extracting file ' + outfile + '...');
		
		blockoffsets = [0] + [unpack('<I', f.read(4))[0] for x in range(blockcount)];
		blocksizes = [blockoffsets[i] - blockoffsets[i - 1] for i in range(1, len(blockoffsets))];
		
		with open(outfile, 'wb') as g:
			for blocksize in blocksizes:
				g.write(f.read(blocksize).decode('zlib'));
				
		with open(outfile, 'rb') as g:
			if g.read(4) == "\x01\x26\x01\x02":
				with open(outfile + '_stripped', 'wb') as h:
					itemcount = unpack('<I', g.read(4))[0] / 8;
					g.read(56);
					headers = [unpack('<II', g.read(8)) for i in range(itemcount)];
					for id, size in headers:
						start = g.tell();
						if g.read(4) == "\x02\x26\x01\x02":
							g.read(36);
							if g.read(1) == "\x05":
								h.write("\x05");
								data = g.read(size - 40 - 1);
								h.write(data);
								# Major hack
								if data[-1] == "\x03":
									h.write("\x00");
						g.seek(start + size);
