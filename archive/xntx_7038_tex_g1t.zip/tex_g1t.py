from inc_noesis import *

# debug level
# 0 - info/warn/error messages (hidden)
# 1 - 0 + pop up Noesis Debug Log
DEBUGLEVEL = 0
#-------------------------------------------------------------------------------
def registerNoesisTypes():
    handle = noesis.register("G1T Image", ".g1t")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    if DEBUGLEVEL >= 1: noesis.logPopup()
    return 1
#-------------------------------------------------------------------------------
def noepyCheckType(data):
    bs = NoeBitStream(data)
    bs.setEndian(0)
    if bs.readBytes(4) == b"GT1G": return 1
    else: print("[x] Wrong magic bytes."); return 0
#-------------------------------------------------------------------------------
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.setEndian(0)
    bs.seek(0x4, 0)
    ID = bs.readBytes(4) # 0x4
    fileSize = bs.readUInt() # 0x8
    headerOffset = bs.readUInt() # 0xC, =0x20?
    files = bs.readUInt() # 0x10
    DUMMY = bs.readUInt() # 0x14, =0 or 0xA?

    bs.seek(headerOffset, 0)
    texOffsets = []
    for i in range(files): texOffsets.append(bs.readUInt())

    for i in range(files):
        bs.seek(headerOffset + texOffsets[i])
        DUMMY = bs.readUByte() # +0x00, =0x10?
#        print(repr(hex(bs.tell())))
        TEXFMT = bs.readUByte() # +0x01
        texWidthAndHeight_powOf2 = bs.readUByte() # +0x02
        width = 1 << (texWidthAndHeight_powOf2 & 0xF)
        height = 1 << ((texWidthAndHeight_powOf2 & 0xF0) >> 4)
        DUMMY = bs.readUByte() # +0x03, =0?
        DUMMY = bs.readUInt() # +0x04, =0x10211000, =0x00211000??
#        print(hex(DUMMY))

        if DUMMY & 0x10000000:
            DUMMY = bs.readUInt() # +0x08, rel_offset
            dataStart = bs.tell() + DUMMY - 4
        else: dataStart = bs.tell()

        if i < files-1: dataSize = headerOffset + texOffsets[i+1] - dataStart
        else: dataSize = fileSize - dataStart

        if texWidthAndHeight_powOf2 == 0:
            DUMMY = bs.readUInt() # +0x0C
            DUMMY = bs.readUInt() # +0x10
            width = bs.readUInt() # +0x14
            height = bs.readUInt() # +0x18

        bs.seek(dataStart, 0)
        data = bs.readBytes(dataSize)

        if TEXFMT == 1: fmtText = "RGBA8"; texFmt = noesis.NOESISTEX_RGBA32
        elif TEXFMT in (0x06,0x10,0x59): fmtText = "DXT1"; BytesPerBlock = 4; texFmt = noesis.NOESISTEX_DXT1
        elif TEXFMT in (0x08,0x12,0x5B): fmtText = "DXT5"; BytesPerBlock = 8; texFmt = noesis.NOESISTEX_DXT5
        elif TEXFMT == 0x5E: fmtText = "BC6H uf16"; texFmt = noesis.FOURCC_BC6H
        elif TEXFMT == 0x5F: fmtText = "BC7"; texFmt = noesis.FOURCC_BC7
#        elif TEXFMT == 0x60: fmtText = "unknown"
        else: fmtText = "unknown"

        print("[i] Texture #"+repr(i+1)+": format: "+fmtText+"; WxH: "+repr(width)+"x"+repr(height)+"; data start: "+hex(dataStart)+"; data size: "+repr(dataSize)+" B.")
        if fmtText == "unknown": return 0

        if TEXFMT in (0x10,0x12): data = rapi.imageFromMortonOrder(data, width>>1, height>>2, BytesPerBlock) # PSVita specific swizzling, thanks Acewell
        if TEXFMT in (0x5E,0x5F): data = rapi.imageDecodeDXT(data, width, height, texFmt); texFmt = noesis.NOESISTEX_RGBA32
        texList.append(NoeTexture(rapi.getExtensionlessName(rapi.getInputName())+"_"+repr(i), width, height, data, texFmt))

    return 1
#-------------------------------------------------------------------------------