from inc_noesis import *
import fmt_mesh as loadMesh
import fmt_skeleton as loadSkeleton

def registerNoesisTypes():
    handle = noesis.register("combine mesh with one skeleton", ".combine")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)
    noesis.logPopup()
    return 1

def noepyCheckType(data):
    file = data.decode().splitlines()
    
    if file[0] != "COMBINE":
        return 0
    return 1
    
def noepyLoadModel(data, mdlList):
    file = data.decode().splitlines()
    dirPath = rapi.getDirForFilePath(rapi.getInputName())
    
    skeleton_path=None
    mehses_path=[]
    #parse
    for line in file:
        split = line.split('=')
        if "mesh" in split[0]:
            mehses_path.append(os.path.join(dirPath, split[1]))
        if "skeleton" in split[0]:
            skeleton_path = os.path.join(dirPath, split[1])
    
    bones, meshes, materials, modelList = [], [], [], []
    if skeleton_path and os.path.exists(skeleton_path):
        with open(skeleton_path, "rb") as sklStream:
            data = sklStream.read()
            if loadSkeleton.noepyCheckType(data):
                loadSkeleton.noepyLoadModel(data, modelList)
                if modelList:
                    bones = modelList[0].bones
                    modelList = []
    for mesh in mehses_path:
        if mesh and os.path.exists(mesh):
            with open(mesh, "rb") as meshStream:
                data = meshStream.read()
                if loadMesh.noepyCheckType(data):
                    loadMesh.noepyLoadModel(data, modelList)

    for model in modelList:
        meshes+=model.meshes
    
    for i,mesh in enumerate(meshes):
        matName = "mat_"+str(i)
        mesh.setName("mesh_"+str(i))
        mesh.setMaterial(matName)
        materials.append(NoeMaterial(matName,""))
    
    mdl = NoeModel()
    mdl.setMeshes(meshes)
    mdl.setBones(bones)
    mdl.setModelMaterials(NoeModelMaterials([], materials))
    mdlList.append(mdl)
    return 1