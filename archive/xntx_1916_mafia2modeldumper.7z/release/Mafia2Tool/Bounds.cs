﻿namespace Mafia2Tool
{
    public struct Bounds
    {
        public Vector3 Min;
        public Vector3 Max;

        public Bounds(System.IO.BinaryReader r)
            : this()
        {
            Min = new Vector3(r);
            Max = new Vector3(r);
        }

        public override string ToString()
        {
            return string.Format("[{0}] [{1}]", Min, Max);
        }
    }
}
