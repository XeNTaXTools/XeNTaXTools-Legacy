﻿using System.IO;

namespace Mafia2Tool.DataFormats.FrameResources
{
    public class JointComponent : BaseComponent
    {
        public class unk_struct1
        {
            int unknown_01_int;
            Hash unknown_02_hash;
            Hash unknown_03_hash;

            public unk_struct1(BinaryReader r)
            {
                Read(r);
            }

            public void Read(BinaryReader r)
            {
                unknown_01_int = r.ReadInt32();
                unknown_02_hash = new Hash(r);
                unknown_03_hash = new Hash(r);
            }
        }

        protected byte unknown_07_byte;
        protected unk_struct1[] unknown_08_list;

        public JointComponent(BinaryReader r, FrameResourceEntryList list)
            : base(r, list)
        {

        }

        public override void Read(BinaryReader r)
        {
            base.Read(r);
            unknown_07_byte = r.ReadByte();

            if (unknown_07_byte != 0)
            {
                unknown_08_list = new unk_struct1[unknown_07_byte];
                for (int i = 0; i < unknown_08_list.Length; i++)
                {
                    unknown_08_list[i] = new unk_struct1(r);
                }
            }
        }

        public override string ToString()
        {
            return string.Format("Joint {0}", name.ToString());
        }
    }
}
