﻿using System.Collections.Generic;
using System.Linq;

namespace Mafia2Tool.DataFormats.FrameResources
{
    public class FrameResourceEntryList : IList<FrameResourceEntry>
    {
        List<FrameResourceEntry> _innerList;

        public FrameResourceEntryList(int capacity)
        {
            _innerList = new List<FrameResourceEntry>(capacity);
        }

        public List<MeshDataEntry> GetGeometries()
        {
            if (_innerList == null) return null;
            return new List<MeshDataEntry>(_innerList.OfType<MeshDataEntry>());
        }

        public List<BaseComponent> GetHierachyObjects()
        {
            if (_innerList == null) return null;
            return new List<BaseComponent>(_innerList.OfType<BaseComponent>());
        }
        
        #region IList

        public int IndexOf(FrameResourceEntry item)
        {
            return _innerList.IndexOf(item);
        }

        public void Insert(int index, FrameResourceEntry item)
        {
            _innerList.Insert(index, item);
        }

        public void RemoveAt(int index)
        {
            _innerList.RemoveAt(index);
        }

        public FrameResourceEntry this[int index]
        {
            get
            {
                if(_innerList != null && _innerList.Count > index && index >= 0) return _innerList[index];
                return null;
            }
            set
            {
                _innerList[index] = value;
            }
        }

        public void Add(FrameResourceEntry item)
        {
            _innerList.Add(item);
        }

        public void Clear()
        {
            _innerList.Clear();
        }

        public bool Contains(FrameResourceEntry item)
        {
            return _innerList.Contains(item);
        }

        public void CopyTo(FrameResourceEntry[] array, int arrayIndex)
        {
            _innerList.CopyTo(array, arrayIndex);
        }

        public int Count
        {
            get { return _innerList.Count; }
        }

        public bool IsReadOnly
        {
            get { return false; }
        }

        public bool Remove(FrameResourceEntry item)
        {
            return _innerList.Remove(item);
        }

        public IEnumerator<FrameResourceEntry> GetEnumerator()
        {
            return _innerList.GetEnumerator();
        }

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return _innerList.GetEnumerator();
        }
        
        #endregion
    }
}
