﻿using System.IO;

namespace Mafia2Tool.DataFormats.FrameResources
{
    public class CollisionComponent : BaseComponent
    {
        ulong hash;

        public CollisionComponent(BinaryReader r, FrameResourceEntryList list)
            : base(r, list)
        {

        }

        public override void Read(BinaryReader r)
        {
            base.Read(r);

            hash = r.ReadUInt64();
        }

        public override string ToString()
        {
            return string.Format("Collision {0}", name.ToString());
        }
    }
}
