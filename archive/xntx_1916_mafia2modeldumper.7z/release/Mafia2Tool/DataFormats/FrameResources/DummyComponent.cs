﻿using System.IO;

namespace Mafia2Tool.DataFormats.FrameResources
{
    public class DummyComponent : JointComponent
    {
        Bounds unknown_08_bounds;

        public DummyComponent(BinaryReader r, FrameResourceEntryList list)
            : base(r, list)
        {

        }

        public override void Read(BinaryReader r)
        {
            base.Read(r);

            unknown_08_bounds = new Bounds(r);
        }

        public override string ToString()
        {
            return string.Format("Dummy {0}", name.ToString());
        }
    }
}
