﻿namespace Mafia2Tool.DataFormats.FrameResources
{
    public class FrameResourceEntry
    {
        public int Index;
        protected FrameResourceEntryList _list;
        
        public FrameResourceEntry(FrameResourceEntryList list)
        {
            _list = list;
            Index = _list.Count;
        }

        protected T GetObject<T>(int index) where T : FrameResourceEntry
        {
            return _list[index] as T;
        }
    }
}
