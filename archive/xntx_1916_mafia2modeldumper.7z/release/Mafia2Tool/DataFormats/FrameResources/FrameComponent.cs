﻿using System.IO;

namespace Mafia2Tool.DataFormats.FrameResources
{
    public class FrameComponent : JointComponent
    {
        public Hash unknown_19_hash;

        public FrameComponent(BinaryReader r, FrameResourceEntryList list)
            : base(r, list)
        {

        }

        public override void Read(BinaryReader r)
        {
            base.Read(r);
            unknown_19_hash = new Hash(r);
        }

        public override string ToString()
        {
            return string.Format("Frame {0}", name.ToString());
        }
    }
}
