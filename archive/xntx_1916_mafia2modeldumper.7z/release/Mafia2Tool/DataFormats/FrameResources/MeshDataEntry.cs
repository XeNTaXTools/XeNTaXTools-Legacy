﻿using System.IO;

namespace Mafia2Tool.DataFormats.FrameResources
{
    public class MeshDataEntry : FrameResourceEntry
    {
        byte _numLods;
        short short_01;

        public Vector3 _positionOffset;
        public float _positionFactor;

        public GeometryDataEntry[] lods;

        public MeshDataEntry(BinaryReader r, FrameResourceEntryList list)
            : base(list)
        {
            Read(r);
        }

        public void Read(BinaryReader r)
        {
            _numLods = r.ReadByte();
            short_01 = r.ReadInt16(); // 0, 4
            _positionOffset = new Vector3(r);
            _positionFactor = r.ReadSingle();

            lods = new GeometryDataEntry[_numLods];
            for (int i = 0; i < lods.Length; i++)
            {
                lods[i] = new GeometryDataEntry(r);
            }
        }

        public override string ToString()
        {
            return string.Format("MeshData ({0})", Index);
        }
    }
}
