﻿using System.Collections.Generic;
using System.IO;

namespace Mafia2Tool.DataFormats.FrameResources
{
    public class MaterialInfoEntry : FrameResourceEntry
    {
        // per lod...
        public class Map
        {
            public int numFaces;
            public int startIndex;

            public ulong MaterialHash;

            int unk3; // numfaces or 0

            public Map(BinaryReader r)
            {
                Read(r);
            }

            public void Read(BinaryReader r)
            {
                numFaces = r.ReadInt32();
                startIndex = r.ReadInt32();
                MaterialHash = r.ReadUInt64();
                unk3 = r.ReadInt32();
            }
        }

        byte count;
        int[] counts;
        Bounds bounds;
        public List<Map[]> Maps;

        public MaterialInfoEntry(BinaryReader r, FrameResourceEntryList list)
            : base(list)
        {
            Read(r);
        }

        public void Read(BinaryReader r)
        {
            count = r.ReadByte();
            counts = new int[count];
            for (int i = 0; i < count; i++)
            {
                counts[i] = r.ReadInt32();
            }
            bounds = new Bounds(r);
            Maps = new List<Map[]>();
            for (int i = 0; i < count; i++)
            {
                Map[] tmp = new Map[counts[i]];
                for (int j = 0; j < tmp.Length; j++)
                {
                    tmp[j] = new Map(r);
                }
                Maps.Add(tmp);
            }
        }

        public override string ToString()
        {
            return string.Format("MaterialData ({0})", Index);
        }
    }
}
