﻿using System.IO;

namespace Mafia2Tool.DataFormats.FrameResources
{
    // mesh without skeleton
    public class SingleMeshComponent : JointComponent
    {
        int unknown_09_flags; // flags ?
        
        public Bounds Bounds;
        
        byte unknown_14_byte;
        
        public int MeshIndex;
        public int MaterialIndex;

        public MeshDataEntry Mesh
        {
            get { return GetObject<MeshDataEntry>(MeshIndex); }
        }

        public MaterialInfoEntry Material
        {
            get { return GetObject<MaterialInfoEntry>(MaterialIndex); }
        }

        Hash unknown_17_textureHash; // if (unknown_08_flags & 0x40000000) == 0x40000000;
        byte unknown_18_byte1;
        byte unknown_18_byte2;
        byte unknown_18_byte3;

        public SingleMeshComponent(BinaryReader r, FrameResourceEntryList list)
            : base(r, list)
        {

        }

        public override void Read(BinaryReader r)
        {
            base.Read(r);

            unknown_09_flags = r.ReadInt32();
            Bounds = new Bounds(r);
            unknown_14_byte = r.ReadByte();

            MeshIndex = r.ReadInt32();
            MaterialIndex = r.ReadInt32();

            unknown_17_textureHash = new Hash(r);
            unknown_18_byte1 = r.ReadByte();
            unknown_18_byte2 = r.ReadByte();
            unknown_18_byte3 = r.ReadByte();
        }

        public override string ToString()
        {
            return string.Format("Mesh {0}", name.ToString());
        }
    }
}
