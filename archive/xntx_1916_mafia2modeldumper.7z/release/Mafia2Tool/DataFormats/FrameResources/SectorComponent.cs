﻿using System.IO;

namespace Mafia2Tool.DataFormats.FrameResources
{
    public class SectorComponent : JointComponent
    {
        int unknown_08_int;
        int unknown_09_int;

        float[] unknown_10_floats; // matrix columns
        Bounds unknown_11_bounds;
        Vector3 unknown_13_vector3;
        Vector3 unknown_14_vector3;

        Hash unknown_15_hash;

        public SectorComponent(BinaryReader r, FrameResourceEntryList list)
            : base(r, list)
        {

        }

        public override void Read(BinaryReader r)
        {
            base.Read(r);

            unknown_08_int = r.ReadInt32(); // object id
            unknown_09_int = r.ReadInt32();
            unknown_10_floats = new float[unknown_09_int * 4];
            for (int i = 0; i < unknown_10_floats.Length; i++)
            {
                unknown_10_floats[i] = r.ReadSingle();
            }
            unknown_11_bounds = new Bounds(r);
            unknown_13_vector3 = new Vector3(r);
            unknown_14_vector3 = new Vector3(r);

            unknown_15_hash = new Hash(r);
        }

        public override string ToString()
        {
            return string.Format("Sector {0}", name.ToString());
        }
    }
}
