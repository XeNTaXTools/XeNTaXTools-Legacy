﻿using System.IO;

namespace Mafia2Tool.DataFormats.FrameResources
{
    public class FolderNameEntry : FrameResourceEntry
    {
        public Hash Name;

        public FolderNameEntry(BinaryReader r, FrameResourceEntryList list)
            : base(list)
        {
            Read(r);
        }

        public void Read(BinaryReader r)
        {
            Name = new Hash(r);
        }
    }
}
