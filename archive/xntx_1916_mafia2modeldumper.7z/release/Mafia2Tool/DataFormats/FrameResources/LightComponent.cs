﻿using System.IO;

namespace Mafia2Tool.DataFormats.FrameResources
{
    public class LightComponent : JointComponent
    {
        int unknown_09_int;
        float[] unknown_10_floats;
        int unknown_11_int;
        float[] unknown_12_floats;
        byte unknown_13_byte;
        float[] unknown_14_floats;
        byte unknown_15_byte;
        float[] unknown_16_floats;
        Hash unknown_17_hash;
        int unknown_18_int;
        float[] unknown_19_floats;
        Hash unknown_20_hash;
        Hash unknown_21_hash;
        Hash unknown_22_hash;
        Hash unknown_23_hash;
        Vector3 unknown_24_vector;
        Vector3 unknown_25_vector;

        byte unknown_26_byte;

        Vector3 unknown_27_vector;
        Vector3 unknown_28_vector;
        Vector3 unknown_29_vector;
        Vector3 unknown_30_vector;

        public LightComponent(BinaryReader r, FrameResourceEntryList list)
            : base(r, list)
        {

        }

        public override void Read(BinaryReader r)
        {
            base.Read(r);

            unknown_09_int = r.ReadInt32(); // object id
            unknown_10_floats = new float[7];
            for (int i = 0; i < 7; i++) unknown_10_floats[i] = r.ReadSingle();

            unknown_11_int = r.ReadInt32();
            unknown_12_floats = new float[5];
            for (int i = 0; i < 5; i++) unknown_12_floats[i] = r.ReadSingle();
            unknown_13_byte = r.ReadByte();
            unknown_14_floats = new float[17];
            for (int i = 0; i < 17; i++) unknown_14_floats[i] = r.ReadSingle();
            unknown_15_byte = r.ReadByte();
            unknown_16_floats = new float[5];
            for (int i = 0; i < 5; i++) unknown_16_floats[i] = r.ReadSingle();
            unknown_17_hash = new Hash(r);
            unknown_18_int = r.ReadInt32();

            unknown_19_floats = new float[20];
            for (int i = 0; i < 20; i++) unknown_19_floats[i] = r.ReadSingle();

            unknown_20_hash = new Hash(r);
            unknown_21_hash = new Hash(r);
            unknown_22_hash = new Hash(r);
            unknown_23_hash = new Hash(r);

            unknown_24_vector = new Vector3(r);
            unknown_25_vector = new Vector3(r);

            unknown_26_byte = r.ReadByte();

            unknown_27_vector = new Vector3(r);
            unknown_28_vector = new Vector3(r);
            unknown_29_vector = new Vector3(r);
            unknown_30_vector = new Vector3(r);
        }

        public override string ToString()
        {
            return string.Format("Light {0}", name.ToString());
        }
    }
}
