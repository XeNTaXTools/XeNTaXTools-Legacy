﻿using System.IO;

namespace Mafia2Tool.DataFormats.FrameResources
{
    public class TargetComponent : JointComponent
    {
        int unknown_09_int;
        int unknown_10_int;

        public TargetComponent(BinaryReader r, FrameResourceEntryList list)
            : base(r, list)
        {
            
        }

        public override void Read(BinaryReader r)
        {
            base.Read(r);

            unknown_09_int = r.ReadInt32();
            unknown_10_int = r.ReadInt32();
        }

        public override string ToString()
        {
            return string.Format("Target {0}", name.ToString());
        }
    }
}
