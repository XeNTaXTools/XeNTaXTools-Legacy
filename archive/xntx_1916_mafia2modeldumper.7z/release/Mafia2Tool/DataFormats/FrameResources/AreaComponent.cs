﻿using System.IO;

namespace Mafia2Tool.DataFormats.FrameResources
{
    public class AreaComponent : JointComponent
    {
        int unknown_09_int;
        int unknown_10_int;

        float[] unknown_11_floats; // matrix columns
        Bounds unknown_12_bounds;

        public AreaComponent(BinaryReader r, FrameResourceEntryList list)
            : base(r, list)
        {

        }

        public override void Read(BinaryReader r)
        {
            base.Read(r);

            unknown_09_int = r.ReadInt32();
            unknown_10_int = r.ReadInt32();
            unknown_11_floats = new float[unknown_10_int * 4];
            for (int i = 0; i < unknown_11_floats.Length; i++)
            {
                unknown_11_floats[i] = r.ReadSingle();
            }
            unknown_12_bounds = new Bounds(r);
        }

        public override string ToString()
        {
            return string.Format("Area {0}", name.ToString());
        }
    }
}
