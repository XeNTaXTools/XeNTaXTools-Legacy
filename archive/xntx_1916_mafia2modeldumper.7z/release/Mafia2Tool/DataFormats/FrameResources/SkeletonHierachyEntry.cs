﻿using System.IO;

namespace Mafia2Tool.DataFormats.FrameResources
{
    public class SkeletonHierachyEntry : FrameResourceEntry
    {
        public byte[] ParentIndices;
        public byte[] LastChildIndices;

        public SkeletonHierachyEntry(BinaryReader r, FrameResourceEntryList list)
            : base(list)
        {
            Read(r);
        }

        public void Read(BinaryReader r)
        {
            int count = r.ReadInt32();
            ParentIndices = r.ReadBytes(count);

            r.ReadByte(); // always 0

            LastChildIndices = r.ReadBytes(count);

            r.ReadBytes(count + 1); // always [count + 1, 1, 2, 3, ..., count, 0]
        }

        public override string ToString()
        {
            return string.Format("SkeletonHierachyEntry ({0})", Index);
        }
    }
}
