﻿using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Mafia2Tool.DataFormats.FrameResources
{
    public class BaseComponent : FrameResourceEntry
    {
        public Hash name;
        protected int unknown_00_int;           // flags
        public TransformMatrix unknown_02_matrix;

        protected short unknown_03_short;       // -1

        public int ParentIndex1;           // object index
        public int ParentIndex2;           // object index

        public BaseComponent ParentComponent1
        {
            get
            {
                return GetObject<BaseComponent>(ParentIndex1);
            }
        }
        public BaseComponent ParentComponent2
        {
            get
            {
                return GetObject<BaseComponent>(ParentIndex2);
            }
        }

        public List<BaseComponent> children1
        {
            get
            {
                var tmp = _list.GetHierachyObjects();
                if (tmp == null) return null;
                return new List<BaseComponent>(tmp.Where(c => c.ParentIndex1 == Index));
            }
        }

        public List<BaseComponent> children2
        {
            get
            {
                var tmp = _list.GetHierachyObjects();
                if (tmp == null) return null;
                return new List<BaseComponent>(tmp.Where(c => c.ParentIndex2 == Index));
            }
        }

        public string Path
        {
            get
            {
                if (ParentComponent1 != null) return ParentComponent1.Path + "." + name.ToString();
                return name.ToString();
            }
        }

        protected short unknown_06_int;         // -1

        public BaseComponent(BinaryReader r, FrameResourceEntryList list)
            : base(list)
        {
            Read(r);
        }

        public virtual void Read(BinaryReader r)
        {
            name = new Hash(r);

            unknown_00_int = r.ReadInt32();

            unknown_02_matrix = new TransformMatrix(r);
            unknown_03_short = r.ReadInt16();
            ParentIndex1 = r.ReadInt32();
            ParentIndex2 = r.ReadInt32();
            unknown_06_int = r.ReadInt16();
        }

        public override string ToString()
        {
            return string.Format("{0} ({1})", GetType().Name, name.ToString());
        }
    }
}
