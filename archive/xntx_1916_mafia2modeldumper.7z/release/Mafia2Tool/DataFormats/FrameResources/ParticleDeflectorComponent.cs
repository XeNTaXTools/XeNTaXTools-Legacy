﻿using System.IO;

namespace Mafia2Tool.DataFormats.FrameResources
{
    // ???????
    public class ParticleDeflectorComponent : JointComponent
    {
        public ParticleDeflectorComponent(BinaryReader r, FrameResourceEntryList list)
            : base(r, list)
        {

        }
    }
}
