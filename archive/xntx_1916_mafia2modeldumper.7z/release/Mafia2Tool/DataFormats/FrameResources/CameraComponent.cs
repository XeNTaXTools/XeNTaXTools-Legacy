﻿using System.IO;

namespace Mafia2Tool.DataFormats.FrameResources
{
    public class CameraComponent : JointComponent
    {
        class unk_struct2
        {
            float[] unknown_01_floats;
            Hash unknown_02_hash;

            public unk_struct2(BinaryReader r)
            {
                Read(r);
            }

            public void Read(BinaryReader r)
            {
                unknown_01_floats = new float[5];
                for (int i = 0; i < unknown_01_floats.Length; i++) unknown_01_floats[i] = r.ReadSingle();
                unknown_02_hash = new Hash(r);
            }
        }

        int unknown_08_int;
        unk_struct2[] unknown_09_list;

        public CameraComponent(BinaryReader r, FrameResourceEntryList list)
            : base(r, list)
        {

        }

        public override void Read(BinaryReader r)
        {
            base.Read(r);

            unknown_08_int = r.ReadInt32();
            if (unknown_08_int > 0)
            {
                unknown_09_list = new unk_struct2[unknown_08_int];
                for (int i = 0; i < unknown_08_int; i++)
                {
                    unknown_09_list[i] = new unk_struct2(r);
                }
            }
        }

        public override string ToString()
        {
            return string.Format("Camera {0}", name.ToString());
        }
    }
}
