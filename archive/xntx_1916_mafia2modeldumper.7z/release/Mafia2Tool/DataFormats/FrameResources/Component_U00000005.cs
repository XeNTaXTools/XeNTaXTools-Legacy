﻿using System.IO;

namespace Mafia2Tool.DataFormats.FrameResources
{
    public class Component_U00000005 : BaseComponent
    {
        protected int unknown_07_int;
        public Component_U00000005(BinaryReader r, FrameResourceEntryList list)
            : base(r, list)
        {

        }

        public override void Read(BinaryReader r)
        {
            base.Read(r);

            unknown_07_int = r.ReadInt32();
        }

        public override string ToString()
        {
            return string.Format("U00000005 {0}", name.ToString());
        }
    }
}
