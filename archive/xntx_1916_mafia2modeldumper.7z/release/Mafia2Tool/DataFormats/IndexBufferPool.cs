﻿using System.IO;

namespace Mafia2Tool.DataFormats
{
    public class IndexBufferPool
    {
        public class IndexBuffer
        {
            public ulong hash;
            int u;
            int len;
            public ushort[] data;

            public IndexBuffer(BinaryReader r)
            {
                Read(r);
            }

            public void Read(BinaryReader r)
            {
                hash = r.ReadUInt64();
                u = r.ReadInt32(); // 1

                len = r.ReadInt32();
                System.Diagnostics.Debug.Assert(len % 2 == 0);

                data = new ushort[len / 2];
                for (int i = 0, j = 0; i < len; i += 2, j++)
                {
                    data[j] = r.ReadUInt16();
                }
            }
        }
        
        byte version;
        int numbuffers;
        int size;
        public IndexBuffer[] buffers;

        public IndexBufferPool(BinaryReader r)
        {
            Read(r);
        }

        public void Read(BinaryReader r)
        {
            version = r.ReadByte();
            numbuffers = r.ReadInt32();
            size = r.ReadInt32();
            buffers = new IndexBuffer[numbuffers];
            for (int i = 0; i < numbuffers; i++)
            {
                IndexBuffer b = new IndexBuffer(r);
                buffers[i] = b;
            }
        }
    }
}
