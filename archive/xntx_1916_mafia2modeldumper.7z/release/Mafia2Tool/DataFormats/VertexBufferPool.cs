﻿using System.IO;

namespace Mafia2Tool.DataFormats
{
    public class VertexBufferPool
    {
        public class VertexBuffer
        {
            public ulong hash;
            int len;
            public byte[] data;

            public VertexBuffer(BinaryReader r)
            {
                Read(r);
            }

            public void Read(BinaryReader r)
            {
                hash = r.ReadUInt64();
                len = r.ReadInt32();
                data = r.ReadBytes(len);
            }
        }
        
        byte version;
        int numbuffers;
        int size;
        public VertexBuffer[] buffers;

        public VertexBufferPool(BinaryReader r)
        {
            Read(r);
        }

        public void Read(BinaryReader r)
        {
            version = r.ReadByte();
            numbuffers = r.ReadInt32();
            size = r.ReadInt32();
            buffers = new VertexBuffer[numbuffers];
            for (int i = 0; i < numbuffers; i++)
            {
                VertexBuffer b = new VertexBuffer(r);
                buffers[i] = b;
            }
        }
    }
}
