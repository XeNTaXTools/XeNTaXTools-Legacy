﻿using System;
using System.IO;

namespace Mafia2Tool.DataFormats
{
    public class Collisions
    {
        public struct section
        {
            int start;
            int len;
            int unk1;
            int unk2;

            public section(BinaryReader r)
                : this()
            {
                start = r.ReadInt32();
                len = r.ReadInt32();
                unk1 = r.ReadInt32();
                unk2 = r.ReadInt32();
            }
        }
        
        public class nxsMesh
        {
            public ulong hash;
            
            byte[] data;
            section[] sections;

            public nxsMesh(BinaryReader r)
            {
                Read(r);
            }

            public void Read(BinaryReader r)
            {
                hash = r.ReadUInt64();
                int size = r.ReadInt32();
                data = r.ReadBytes(size);

                int num = r.ReadInt32();
                sections = new section[num];
                for (int i = 0; i < num; i++) sections[i] = new section(r);
            }
        }

        public class unk_struct1
        {
            Vector3 v1;
            Vector3 v2;

            public ulong hash;
            int u1;
            byte u2;

            public unk_struct1(BinaryReader r)
            {
                v1 = new Vector3(r);
                v2 = new Vector3(r);
                hash = r.ReadUInt64();
                u1 = r.ReadInt32(); // 
                u2 = r.ReadByte();
            }
        }

        int ver;
        int unk1;

        public unk_struct1[] us1;
        public nxsMesh[] meshes;

        public Collisions(BinaryReader r)
        {
            Read(r);
        }

        public void Read(BinaryReader r)
        {
            ver = r.ReadInt32();
            if (ver != 17)
            {
                throw new Exception("unknown version");
            }
            unk1 = r.ReadInt32(); // 0
            int count = r.ReadInt32();
            us1 = new unk_struct1[count];
            for (int i = 0; i < count; i++) us1[i] = new unk_struct1(r);

            count = r.ReadInt32();
            meshes = new nxsMesh[count];
            for (int i = 0; i < count; i++) meshes[i] = new nxsMesh(r);
        }
    }
}
