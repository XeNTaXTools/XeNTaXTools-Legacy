﻿namespace Mafia2Tool
{
    public class Hash
    {
        public ulong hash;
        public string name;

        public Hash(System.IO.BinaryReader r)
        {
            Read(r);
        }

        public void Read(System.IO.BinaryReader r)
        {
            hash = r.ReadUInt64();

            short len = r.ReadInt16();

            byte[] data = r.ReadBytes(len);

            /*
            // uses different method on xbox360...
             
            if (len > 0)
            {
                ulong testhash = Gibbed.Illusion.FileFormats.FNV.Hash64(data, 0, len);
                if (testhash != hash)
                {
                    throw new NotSupportedException("invalid fnv hash");
                }
            }*/
            name = System.Text.Encoding.ASCII.GetString(data);
        }

        public override string ToString()
        {
            if (name == "")
            {
                if (hash != 0)
                {
                    string _name = SkeletonNameLookup.GetName(hash);
                    if (_name != null) return _name;
                }
                return hash.ToString();
            }
            
            return name;
            //return string.Format("{0} ({1:x16})", name, hash);
        }
    }
}
