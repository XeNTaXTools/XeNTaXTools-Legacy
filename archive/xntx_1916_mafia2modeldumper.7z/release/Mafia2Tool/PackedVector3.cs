﻿namespace Mafia2Tool
{
    // 3 shorts unsigned, 16:16:16
    public struct PackedVector3
    {
        private short _packedX;
        private short _packedY;
        private short _packedZ;

        private float _x;
        public float X
        {
            get { return _x; }
        }

        private float _y;
        public float Y
        {
            get { return _y; }
        }

        private float _z;
        public float Z
        {
            get { return _z; }
        }

        public PackedVector3(System.IO.BinaryReader r)
            : this()
        {
            _packedX = r.ReadInt16();
            _packedY = r.ReadInt16();
            _packedZ = r.ReadInt16();
        }

        public PackedVector3(short x, short y, short z)
            : this()
        {
            _packedX = x;
            _packedY = y;
            _packedZ = z;
        }

        public void Expand(Vector3 factor)
        {
            _x = _packedX * factor.X;
            _y = _packedY * factor.Y;
            _z = _packedZ * factor.Z;
        }

        public override string ToString()
        {
            return string.Format(
                System.Globalization.CultureInfo.InvariantCulture,
                "{0:0.000000} {1:0.000000} {2:0.000000}", X, Y, Z);
        }    
    }
}
