﻿using System.Collections.Generic;

namespace Mafia2Tool
{
    public class SkeletonNameLookup
    {
        static Dictionary<ulong, string> names;

        static SkeletonNameLookup()
        {
            buildLookup();
        }

        static void buildLookup()
        {
            names = new Dictionary<ulong, string>();
            
            // -- BASE --

            names[1] = "BaseRef";
            names[1007] = "Scale_dummy";
            names[1000] = "Trace";
            names[1004] = "Opposite";
            names[1510] = "CoatSim_Root";

            // -- BODY --

            names[1001] = "Blnd_dummy";
            names[1002] = "Aim_dummy";
            names[1003] = "Camera_dummy";
            names[1005] = "FootStep_L";
            names[1006] = "FootStep_R";
            names[101] = "Hips";
            names[102] = "Spine";
            names[103] = "Spine1";
            names[104] = "Spine2";
            names[105] = "Spine3";
            names[106] = "Spine4";
            names[107] = "Neck";
            names[108] = "Head";
            names[109] = "LeftBreast";
            names[110] = "RightBreast";


            // -- LEFT LEG --

            names[201] = "LeftUpLeg";
            names[202] = "LeftUpLegRoll";
            names[203] = "LeftLeg";
            names[204] = "LeftFoot";
            names[205] = "LeftToeBase";
            names[206] = "L_LegSleeve";
            names[207] = "LeftNates";

            // -- RIGHT LEG --

            names[301] = "RightUpLeg";
            names[302] = "RightUpLegRoll";
            names[303] = "RightLeg";
            names[304] = "RightFoot";
            names[305] = "RightToeBase";
            names[306] = "R_LegSleeve";
            names[307] = "RightNates";

            // -- LEFT ARM --

            names[401] = "LeftShoulder";
            names[402] = "LeftArm";
            names[403] = "LeftArmRoll";
            names[404] = "LeftForeArm";
            names[405] = "LeftForeArmRoll";

            // -- LEFT HAND --

            names[406] = "LeftHand";
            names[407] = "L_Sleeve";
            names[410] = "LeftHandThumb1";
            names[411] = "LeftHandThumb2";
            names[412] = "LeftHandThumb3";
            names[420] = "LeftInHandIndex";
            names[421] = "LeftHandIndex1";
            names[422] = "LeftHandIndex2";
            names[423] = "LeftHandIndex3";
            names[431] = "LeftHandMiddle1";
            names[432] = "LeftHandMiddle2";
            names[433] = "LeftHandMiddle3";
            names[441] = "LeftHandRing1";
            names[442] = "LeftHandRing2";
            names[443] = "LeftHandRing3";
            names[450] = "LeftInHandPinky";
            names[451] = "LeftHandPinky1";
            names[452] = "LeftHandPinky2";
            names[453] = "LeftHandPinky3";


            // -- RIGHT ARM --

            names[501] = "RightShoulder";
            names[502] = "RightArm";
            names[503] = "RightArmRoll";
            names[504] = "RightForeArm";
            names[505] = "RightForeArmRoll";

            // -- RIGHT HAND --

            names[506] = "RightHand";
            names[507] = "R_Sleeve";
            names[510] = "RightHandThumb1";
            names[511] = "RightHandThumb2";
            names[512] = "RightHandThumb3";
            names[520] = "RightInHandIndex";
            names[521] = "RightHandIndex1";
            names[522] = "RightHandIndex2";
            names[523] = "RightHandIndex3";
            names[531] = "RightHandMiddle1";
            names[532] = "RightHandMiddle2";
            names[533] = "RightHandMiddle3";
            names[541] = "RightHandRing1";
            names[542] = "RightHandRing2";
            names[543] = "RightHandRing3";
            names[550] = "RightInHandPinky";
            names[551] = "RightHandPinky1";
            names[552] = "RightHandPinky2";
            names[553] = "RightHandPinky3";

            // -- HEAD --

            names[601] = "Jaw";
            names[602] = "HairScale";
            names[603] = "Hat";
            names[604] = "Lo_MLip";
            names[605] = "Up_Mlip";
            names[606] = "Nose";
            names[607] = "Gathers";
            names[608] = "Hat_mesh";
            names[609] = "Tongue";
            names[842] = "Cigareta";
            names[843] = "Bryle";
            names[844] = "Scruff";
            names[845] = "Fmv_cigareta";

            // -- FACE LEFT --

            names[726] = "Brow2L";
            names[727] = "Brow1L";
            names[728] = "Lo_LidL";
            names[729] = "NostrilL";
            names[730] = "Up_CheekL";
            names[731] = "CheekL";
            names[732] = "Up_MLipL";
            names[733] = "Lo_MLipL";
            names[734] = "MCornerL";
            names[735] = "Up_LidL";
            names[736] = "EYE_L";


            // -- FACE RIGHT--

            names[826] = "Brow2R";
            names[827] = "Brow1R";
            names[828] = "Lo_LidR";
            names[829] = "NostrilR";
            names[830] = "Up_CheekR";
            names[831] = "CheekR";
            names[832] = "Up_MLipR";
            names[833] = "Lo_MLipR";
            names[834] = "MCornerR";
            names[835] = "Up_LidR";
            names[836] = "EYE_R";

            // -- WEAPONS LEFT --

            names[2014] = "GunHand_L";
            names[2001] = "WeaponBodyLeft";
            names[2002] = "ChangeMagazineLeft";
            names[2003] = "TriggerLeft";
            names[2004] = "FireLeft";
            names[2005] = "CapLeft";
            names[2006] = "UpshotLeft";
            names[2007] = "CylinderFireLeft";
            names[2008] = "CylinderOutLeft";
            names[2009] = "ReloadLeft";
            names[2010] = "UnloadLeft";
            names[2011] = "OpenLeft";
            names[2012] = "MuzzleLeft";
            names[2013] = "ShellLeft";
            names[2014] = "Handle_RLeft";
            names[2015] = "Handle_LLeft";

            // -- WEAPONS RIGHT --

            names[2101] = "WeaponBody";
            names[2102] = "ChangeMagazine";
            names[2103] = "Trigger";
            names[2104] = "Handle_L";
            names[2105] = "Shell";
            names[2106] = "Upshot";
            names[2107] = "CylinderFire";
            names[2108] = "CylinderOut";
            names[2109] = "Cap";
            names[2110] = "Unload";
            names[2111] = "Open";
            names[2112] = "Muzzle";
            names[2114] = "GunHand_R";
            names[2116] = "bipod";
            names[2117] = "Tripod";
            names[2118] = "TripodAxe";
            names[2119] = "WeaponAxe";
            names[2120] = "Handle_R";
            names[2121] = "$WeaponOffset";

            // -- COAT LEFT --

            names[1600] = "L_FrontCoat01";
            names[1601] = "L_FrontCoat02";
            names[1602] = "L_FrontCoat03";
            names[1603] = "L_FrontCoat04";
            names[1604] = "L_FrontCoat05";
            names[1605] = "L_FrontCoat06";
            names[1606] = "L_FrontCoat07";
            names[1610] = "L_sideCoat01";
            names[1611] = "L_sideCoat02";
            names[1612] = "L_sideCoat03";
            names[1613] = "L_sideCoat04";
            names[1614] = "L_sideCoat05";
            names[1620] = "L_BackCoat01";
            names[1621] = "L_BackCoat02";
            names[1622] = "L_BackCoat03";
            names[1623] = "L_BackCoat04";
            names[1624] = "L_BackCoat05";
            names[1625] = "L_BackCoat06";

            // -- COAT RIGHT --

            names[1650] = "R_FrontCoat01";
            names[1651] = "R_FrontCoat02";
            names[1652] = "R_FrontCoat03";
            names[1653] = "R_FrontCoat04";
            names[1654] = "R_FrontCoat05";
            names[1655] = "R_FrontCoat06";
            names[1656] = "R_FrontCoat07";
            names[1640] = "R_sideCoat01";
            names[1641] = "R_sideCoat02";
            names[1642] = "R_sideCoat03";
            names[1643] = "R_sideCoat04";
            names[1644] = "R_sideCoat05";
            names[1630] = "R_BackCoat01";
            names[1631] = "R_BackCoat02";
            names[1632] = "R_BackCoat03";
            names[1633] = "R_BackCoat04";
            names[1634] = "R_BackCoat05";
            names[1635] = "R_BackCoat06";

            // -- PROP SAKO --

            names[3000] = "Bone01";
            names[3001] = "Bone02";
            names[3002] = "Bone03";
            names[3003] = "Bone04";
            names[3004] = "Bone05";
            names[3005] = "Bone06";
            names[3006] = "Bone07";
            names[3007] = "Bone08";
            names[3008] = "Bone09";
            names[3009] = "Bone10";
            names[3010] = "Bone11";
            names[301] = "Bone12";
        }

        public static string GetName(ulong key)
        {
            if (names.ContainsKey(key))
            {
                return names[key];
            }
            return null;
        }
    }
}
