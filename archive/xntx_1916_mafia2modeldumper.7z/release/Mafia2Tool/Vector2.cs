﻿namespace Mafia2Tool
{
    public struct Vector2
    {
        public float X;
        public float Y;

        public Vector2(float x, float y)
            : this()
        {
            X = x;
            Y = y;
        }

        public override string ToString()
        {
            return string.Format(
                System.Globalization.CultureInfo.InvariantCulture,
                "{0} {1}", X, Y);
        }
    }
}
