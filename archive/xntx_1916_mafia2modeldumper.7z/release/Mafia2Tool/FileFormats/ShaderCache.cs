﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Ext.FileFormats
{
    public class ShaderCache
    {
        public enum TargetGPU : uint
        {
            None,
            ATF4 = 0x34465441,   // ATF4 = ATI_FETCH_4
            ATI = 0x5f495441,    // ATI_
            NVIDIA = 0x5f5f564e, // NV__
            UNKNOWN = 0x4e4b4e55 // UNKN
        }

        public enum ShaderType
        {
            VertexShader,
            PixelShader
        }

        const int MAGIC = 0x43534352; // RCSC

        public int version;
        public RDShaderCache rdsc;
        public SBShaderCache sbsc;

        public ShaderCache(BinaryReader r)
        {
            Read(r);
        }

        public void Read(BinaryReader r)
        {
            int magic = r.ReadInt32();
            version = r.ReadInt32();

            if (magic != MAGIC || version != 1)
            {
                throw new NotSupportedException("not a shadercache file or unknown version");
            }

            int sizeCommonCode = r.ReadInt32();
            rdsc = new RDShaderCache(new BinaryReader(new MemoryStream(r.ReadBytes(sizeCommonCode))));

            sbsc = new SBShaderCache(r);
        }
    }
}
