﻿namespace Mafia2Tool
{
    public struct TransformMatrix
    {
        public Matrix33 Rotation;
        public Vector3 Translation;
        
        public TransformMatrix(System.IO.BinaryReader r)
            : this()
        {
            Rotation = new Matrix33();
            Translation = new Vector3();

            Rotation.M11 = r.ReadSingle();
            Rotation.M12 = r.ReadSingle();
            Rotation.M13 = r.ReadSingle();
            Translation.X = r.ReadSingle();

            Rotation.M21 = r.ReadSingle();
            Rotation.M22 = r.ReadSingle();
            Rotation.M23 = r.ReadSingle();
            Translation.Y = r.ReadSingle();

            Rotation.M31 = r.ReadSingle();
            Rotation.M32 = r.ReadSingle();
            Rotation.M33 = r.ReadSingle();
            Translation.Z = r.ReadSingle();
        }

        public override string ToString()
        {
            return string.Format("Rot:{0} Trans:{1}", Rotation, Translation);
        }
    }
}
