﻿namespace Mafia2Tool
{
    public struct Matrix33
    {
        public float M11;
        public float M12;
        public float M13;

        public float M21;
        public float M22;
        public float M23;

        public float M31;
        public float M32;
        public float M33;

        public Matrix33(float m11, float m12, float m13, float m21, float m22, float m23, float m31, float m32, float m33)
        {
            M11 = m11; M12 = m12; M13 = m13;
            M21 = m21; M22 = m22; M23 = m23;
            M31 = m31; M32 = m32; M33 = m33;
        }

        public static Matrix33 Identity
        {
            get { return new Matrix33(1, 0, 0, 0, 1, 0, 0, 0, 1); }
        }

        public static Matrix33 operator *(Matrix33 m1, Matrix33 m2)
        {
            return new Matrix33(
                (((m1.M11 * m2.M11) + (m1.M12 * m2.M21)) + (m1.M13 * m2.M31)),
                (((m1.M11 * m2.M12) + (m1.M12 * m2.M22)) + (m1.M13 * m2.M32)),
                (((m1.M11 * m2.M13) + (m1.M12 * m2.M23)) + (m1.M13 * m2.M33)),
                
                (((m1.M21 * m2.M11) + (m1.M22 * m2.M21)) + (m1.M23 * m2.M31)),
                (((m1.M21 * m2.M12) + (m1.M22 * m2.M22)) + (m1.M23 * m2.M32)),
                (((m1.M21 * m2.M13) + (m1.M22 * m2.M23)) + (m1.M23 * m2.M33)),
                
                (((m1.M31 * m2.M11) + (m1.M32 * m2.M21)) + (m1.M33 * m2.M31)),
                (((m1.M31 * m2.M12) + (m1.M32 * m2.M22)) + (m1.M33 * m2.M32)),
                (((m1.M31 * m2.M13) + (m1.M32 * m2.M23)) + (m1.M33 * m2.M33))
             );
        }

        public void Transpose()
        {
            Matrix33 m = new Matrix33(M11, M21, M31, M12, M22, M32, M13, M23, M33);
            this = m;
        }

        public Vector3 Transform(Vector3 input)
        {
            float x = input.X;
            float y = input.Y;
            float z = input.Z;

            return new Vector3()
            {
                X = (((x * M11) + (y * M21)) + (z * M31)),
                Y = (((x * M12) + (y * M22)) + (z * M32)),
                Z = (((x * M13) + (y * M23)) + (z * M33))
            };
        }

        public override string ToString()
        {
            return string.Format(
                System.Globalization.CultureInfo.InvariantCulture,
                "{0:0.000000} {1:0.000000} {2:0.000000} {3:0.000000} {4:0.000000} {5:0.000000} {6:0.000000} {7:0.000000} {8:0.000000}",
                M11, M12, M13, M21, M22, M23, M31, M32, M33);
        }
    }
}
