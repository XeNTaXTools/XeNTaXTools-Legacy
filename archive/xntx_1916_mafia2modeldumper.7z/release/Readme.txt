Mafia 2 Model Dumper (proof of concept)

usage: Mafia2ModelDumper <sdsfile>

- uses gibbed's tools for sds access (thanks gibbed!!!)
- exports models with or without skeleton (Model and SingleMesh) as DAE (Collada)
- exported Vertex components: Position, Normal, Tangent, Binormal, UVs, BlendIndices/BlendWeights (Skeleton/Joint, Weights, ...)
- not exported: Materials (could be supported, see Mafia2Tool.FileFormats.MaterialLibrary... not complete)
- not exported: Shader (see Mafia2Tool.FileFormats.ShaderCache... very incomplete/wrong, a bit of a mess...)

Some technical infos:

The VertexBuffer format used by mafia2 is a bit strange: 
- Position is stored as 16:16:15 bit integer expanded by a scale factor and offset by a vector3
- Position also contains an additional 16bit part (2 bytes)
- Normal is stored as a Color (byte[4]) expanded by /127f - 1f
- Normal contains a w component which is actually the x component of Tangent
- the additional 2 bytes from Position are the y and z components of Tangent
- Binormal = cross product(Normal, Tangent), the unused bit from Position.z switches the direction of Binormal (because of overlapping uvs...)

Lots of the data structures are just guesses... the game uses some strange Matrix structures... lots of unknown stuff...

Use the app and source any way you like (at own risk)