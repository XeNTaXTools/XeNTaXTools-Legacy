﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Mafia2Tool;

namespace Mafia2ModelDumper
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length == 1 && File.Exists(args[0]))
            {
                string filename = args[0];

                try
                {
                    Mafia2Tool.Parsed.MeshParser ex = new Mafia2Tool.Parsed.MeshParser(filename);

                    if (ex._frameResource != null)
                    {
                        foreach (var m in ex._frameResource.Objects)
                        {
                            if (m is Mafia2Tool.DataFormats.FrameResources.SingleMeshComponent)
                            {
                                Mafia2Tool.Parsed.Model model = ex.GetModel((Mafia2Tool.DataFormats.FrameResources.SingleMeshComponent)m);
                                if (model.Lods != null && model.Lods.Length > 0)
                                {
                                    for (int i = 0; i < model.Lods.Length; i++)
                                    {

                                        string exfilename = string.Format("{0}.{1}.L{2}.dae", Path.GetFileNameWithoutExtension(filename), model.Path, i);

                                        Console.WriteLine(string.Format("extracting model: {0}", exfilename));

                                        var l = model.Lods[i];
                                        Mafia2Tool.Parsed.ColladaExporter.ExportModelLod(l, exfilename);
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        Console.WriteLine("sds file contains no frameResource...");
                    }
                }
                catch 
                {
                    Console.WriteLine("no sds or error extracting...");
                }
            }
            else
            {
                Console.WriteLine("usage: Mafia2ModelDumper <sdsfile>");
            }
        }
    }
}