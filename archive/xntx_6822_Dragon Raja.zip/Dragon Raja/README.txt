Usage:
1. Unzip apk;
2. Unpack *.png archives within the following path:
.\assets\res_base\package\

Note:
1. Currently Umodel doesn't work correctly with all the packages, which however has nothing to do with the script itself.
All the outputs are correct results so you might wait for the author of umodel to support this game in the future.
2. About the main.obb.png, which is not the same kind of archive as those supported by this script, but merely a simple
zip file. Remove the png extension or change it to zip and then you can unzip it with any ordinary file archiver like WinRAR.
