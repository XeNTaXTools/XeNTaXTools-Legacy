#CANVAS Engine
#By chrrox
from inc_noesis import *
import struct

def registerNoesisTypes():
	handle = noesis.register("CANVAS Engine model", ".mlx;.htf;.hmd;.htx")
	noesis.setHandlerTypeCheck(handle, canvasCheckType)
	noesis.setHandlerLoadModel(handle, canvasLoadModel)

	#handle = noesis.register("CANVAS Engine tex", ".testtex")
	#noesis.setHandlerTypeCheck(handle, canvasTexCheckType)
	#noesis.setHandlerLoadRGBA(handle, canvasTexLoadRGBA)
	#noesis.logPopup()

	return 1


def canvasCheckType(data):
	td = NoeBitStream(data)
	return 1

#def canvasTexCheckType(data):
#	td = NoeBitStream(data)
#	return 1

class canvasFile: 
         
	def __init__(self, bs):
		self.bs = bs
		self.lodLevel = 0
		self.texList  = []
		self.matList  = [] 
		self.boneList = []
		self.boneMap  = []
		self.offsetList = []
		self.meshOffsets = []

	def loadAll(self, bs):
		while not bs.checkEOF():
			self.load_CHNK(bs)


	def load_CHNK(self, bs):
		chunkStart = bs.tell()
		chunkMagic, chunkSize, chunkHeaderSize, chunkUnk = bs.read(4 * "i")
		print([chunkMagic, chunkSize, chunkHeaderSize, chunkUnk])
		if str(chunkMagic) in chunkLoaderDict:
			chunkLoaderDict[str(chunkMagic)](self, bs, [chunkStart, chunkSize, chunkHeaderSize])
		else:
			print("Unkown format found " +  str(chunkMagic) + "@ Offset " + str(bs.tell() - 16))
			bs.seek((chunkStart + chunkSize + chunkHeaderSize), NOESEEK_ABS)

	def load_POF0(self, bs, info):
		print("POFO")
		bs.seek((info[0] + info[1] + info[2]), NOESEEK_ABS)
		pass

	def load_EOFC(self, bs, info):
		print("EOFC")
		bs.seek((info[0] + info[1] + info[2]), NOESEEK_ABS)
		pass

	def load_HTEX(self, bs, info):
		print("HTEX")
		bs.seek((info[0] + info[2]), NOESEEK_ABS)
		while bs.tell() != (info[0] + info[1] + info[2]):
			self.load_CHNK(bs)

	def load_HTSF(self, bs, info):
		print("HTSF")
		type = bs.readUInt()
		if type == 1:
			bs.seek((info[0] + info[2]), NOESEEK_ABS)
			bs.seek(0x20, NOESEEK_REL)
			texData = bs.readBytes(info[1] - 0x20)
			texture = rapi.loadTexByHandler(texData, ".dds")
			texture.name = str(len(self.texList))
			self.texList.append(texture)
		else:
			bs.seek((info[0] + info[1] + info[2]), NOESEEK_ABS)


	def load_KFMS(self, bs, info):
		print("KFMS")
		self.bufList  = []
		self.mshList  = []
		self.facList  = []
		bs.seek((info[0] + info[2]), NOESEEK_ABS)
		kfsmCounts = bs.read("11i");	bs.seek(0x14, NOESEEK_REL)
		kfsmOffset = bs.read("17i");	bs.seek(0x2C, NOESEEK_REL)
		kfsmData2 = bs.read("4H8i")
		print(kfsmCounts)
		print(kfsmOffset)
		print(kfsmData2)

		for a in range(0, kfsmCounts[5]):
			bs.seek((info[0] + info[2] + kfsmOffset[6] + (0xF0 * a)), NOESEEK_ABS)
			print(bs.tell())
			material = NoeMaterial(str(kfsmOffset[6] + (0xF0 * a)), "")
			matInfo = bs.read("I4B9I4B16f13I")
			print(matInfo)
			#print(matInfo[15])
			#print(matInfo[34])
			#print(matInfo[38])
			#print(matInfo[40])
			#print(matInfo[42])
			#print(matInfo[44])
			#print(matInfo[46])
			bs.seek((info[0] + info[2] + matInfo[38]), NOESEEK_ABS)
			texInfo = bs.read("4H")
			print(texInfo)
			material.setTexture(str(texInfo[2]))
			self.matList.append(material)

		for a in range(0, kfsmCounts[6]):
			tmp = []
			bs.seek((info[0] + info[2] + kfsmOffset[8] + (0x40 * a)), NOESEEK_ABS)
			subInfo = bs.read("4H3I6H8I")
			bs.seek((info[0] + info[2] + subInfo[4]), NOESEEK_ABS)
			bs.seek((info[0] + info[2] + subInfo[13]), NOESEEK_ABS)
			for b in range(0, subInfo[9]):
				subInfo2 = bs.read("4H6I")
				tmp.append(subInfo2)
			self.mshList.append(subInfo)
			self.facList.append(tmp)

		for a in range(0, kfsmCounts[10]):
			bs.seek((info[0] + info[2] + kfsmOffset[16] + (0x80 * a)), NOESEEK_ABS)
			vtxTmp = bs.read("12I")
			vtxFmt = bs.readBytes(0x20).decode("ASCII").rstrip("\0")
			vtxTmp += (bs.readInt(),)
			self.bufList.append((vtxTmp, vtxFmt))
		bs.seek((info[0] + info[1] + info[2]), NOESEEK_ABS)
		#print(self.bufList)
		pass

	def load_KFMG(self, bs, info):
		print("KFMG")
		bs.seek(0x20, NOESEEK_REL)
		faceOff, faceSize, vtxOff, vtxSize = bs.read("4I")
		print([faceOff, faceSize, vtxOff, vtxSize])

		for a in range(0, len(self.mshList)):
			print(self.mshList[a])
			rapi.rpgSetMaterial(str(self.mshList[a][4]))
			rapi.rpgSetName("lod" + str(self.lodLevel) + " " + str(a))
			bs.seek((info[0] + info[2] + vtxOff + self.bufList[self.mshList[a][8]][0][4]), NOESEEK_ABS)
			bs.seek(self.mshList[a][6], NOESEEK_REL)
			vertBuff = bs.readBytes(self.mshList[a][7] * self.bufList[self.mshList[a][8]][0][1])
			rapi.rpgBindPositionBufferOfs(vertBuff, noesis.RPGEODATA_FLOAT, self.bufList[self.mshList[a][8]][0][1], 0)
			rapi.rpgBindNormalBufferOfs(vertBuff, noesis.RPGEODATA_FLOAT, self.bufList[self.mshList[a][8]][0][1], 12)
			#rapi.rpgBindColorBufferOfs(vertBuff, noesis.RPGEODATA_FLOAT, self.bufList[self.mshList[a][8]][0][1], 24, 4)
			rapi.rpgBindUV1BufferOfs(vertBuff, noesis.RPGEODATA_FLOAT, self.bufList[self.mshList[a][8]][0][1], 40)
			for b in range(0, len(self.facList[a])):
				print(self.facList[a][b])
				bs.seek((info[0] + info[2] + faceOff + self.bufList[self.mshList[a][8]][0][2]), NOESEEK_ABS)
				bs.seek(self.facList[a][b][6] * 2, NOESEEK_REL)
				faceData = []
				for c in range(0, self.facList[a][b][4]):
					face = bs.readUShort() + self.facList[a][b][7]
					faceData.append(face)
				faceBuff = struct.pack('H'*len(faceData), *faceData)
				rapi.rpgCommitTriangles(faceBuff, noesis.RPGEODATA_USHORT, self.facList[a][b][4], noesis.RPGEO_TRIANGLE_STRIP, 1)
				rapi.rpgClearBufferBinds()
		self.lodLevel += 1
		bs.seek((info[0] + info[1] + info[2]), NOESEEK_ABS)
		pass

	def load_HMDL(self, bs, info):
		print("HMDL")
		bs.seek((info[0] + info[2]), NOESEEK_ABS)
		while bs.tell() != (info[0] + info[1] + info[2]):
			self.load_CHNK(bs)

	def load_KFMD(self, bs, info):
		print("KFMD")
		bs.seek((info[0] + info[2]), NOESEEK_ABS)
		pass

	def load_IZCA(self, bs, info):
		print("IZCA")
		izcaHeader = bs.read("7I")
		print(izcaHeader)
		izcaOffset = bs.read(izcaHeader[5] * "I")
		print(izcaOffset)
		for a in range(0, izcaHeader[5]):
			bs.seek(info[0] + izcaOffset[a], NOESEEK_ABS)
			self.load_CHNK(bs)
		bs.seek((info[0] + info[1] + info[2]), NOESEEK_ABS)


chunkLoaderDict = {
	"809914192"		: canvasFile.load_POF0,
	"1128681285"		: canvasFile.load_EOFC,
	"1094933065"		: canvasFile.load_IZCA,
	"1480938568"		: canvasFile.load_HTEX,
	"1279544648"		: canvasFile.load_HMDL,
	"1145914955"		: canvasFile.load_KFMD,
	"1397573195"		: canvasFile.load_KFMS,
	"1196246603"		: canvasFile.load_KFMG,
	"1179866184"		: canvasFile.load_HTSF
}

def canvasLoadModel(data, mdlList):
	ctx = rapi.rpgCreateContext()
	canvas = canvasFile(NoeBitStream(data))
	canvas.loadAll(canvas.bs)
	try:
		mdl = rapi.rpgConstructModel()
	except:
		mdl = NoeModel()
	mdl.setModelMaterials(NoeModelMaterials(canvas.texList, canvas.matList))
	mdlList.append(mdl); mdl.setBones(canvas.boneList)	
	return 1


#def canvasTexLoadRGBA(data, texList):
#	td = NoeBitStream(data)
#	return 1