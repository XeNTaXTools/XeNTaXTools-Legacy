﻿using System;
using System.Collections.Generic;
using System.Text;
using SmiteTranlations.BL;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace SmiteTranslation
{
    [Serializable]
    public class TranslationProject
    {
        public Prefs Settings { get; set; }
        public BytesText Data { get; set; }

        public void SaveProject(string path)
        {
            if (this.Data.OriginalByteArray == null || this.Data.Values == null)
                return;
            using (var writer = File.Open(path, FileMode.Create))
            {
                var ser = new BinaryFormatter();
                ser.Serialize(writer, this);
            }
        }

        public static TranslationProject LoadProject(string path)
        {
            using (var reader = File.Open(path, FileMode.Open))
            {
                var ser = new BinaryFormatter();
                var bt = ser.Deserialize(reader) as TranslationProject;
                return bt;
            }
        }
    }
}
