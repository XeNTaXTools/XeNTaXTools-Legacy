﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace SmiteTranslation
{
    public class Dir
    {
        private string _path;

        public string Path
        {
            get { return _path; }
            set 
            { 
                _path = value;
                var files = Directory.GetFiles(value);
                foreach (var f in files)
                {
                    this.Files.Add(new DirFile(string.Format("{0}\\{1}", value, f)));
                }
            }
        }
        
        public List<DirFile> Files { get; private set; }

        public Dir(string path)
        {
            this.Path = path;
            this.Files = new List<DirFile>();
        }
    }
}
