﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SmiteTranslation
{
    [Serializable]
    public class Prefs
    {
        public const string FILTER_PROJECT = "SmiteTranslator project | *.stproj";
        public const string FILTER_FILES = "DAT files | *.dat";

        public string File { get; set; }
        //public Dir Source { get; set; }
    }
}
