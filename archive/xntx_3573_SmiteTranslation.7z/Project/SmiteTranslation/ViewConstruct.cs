﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace SmiteTranslation
{
    public static class ViewConstruct
    {

        public static SaveFileDialog CreateSaveFileDIalog(string filter = Prefs.FILTER_FILES)
        {
            var dialog = new SaveFileDialog();
            dialog.Filter = filter;
            return dialog;
        }

        public static OpenFileDialog CreateOpenFileDialog(string filter = Prefs.FILTER_FILES)
        {
            var dialog = new OpenFileDialog();
            dialog.Filter = filter;
            return dialog;
        }

        public static DataGridView ConstructDataView(EventHandler rowChange)
        {
            var dataView = new DataGridView();
            var leftColumn = new DataGridViewColumn();
            var rightColumn = new DataGridViewColumn();

            leftColumn.HeaderText = "Original";
            leftColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            rightColumn.HeaderText = "Translation";
            rightColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

            dataView.RowHeadersVisible = false;
            dataView.ReadOnly = false;
            dataView.AllowUserToAddRows = false;
            dataView.AllowUserToDeleteRows = false;
            dataView.Dock = DockStyle.Fill;
            dataView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataView.SelectionMode = DataGridViewSelectionMode.CellSelect;

            dataView.Columns.Add(leftColumn);
            dataView.Columns.Add(rightColumn);

            dataView.SelectionChanged += rowChange;

            return dataView;
        }
    }
}
