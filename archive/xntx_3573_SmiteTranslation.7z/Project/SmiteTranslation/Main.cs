﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using SmiteTranlations.BL;

namespace SmiteTranslation
{
    public partial class Main : Form
    {
        private Prefs _settings;
        private BytesText _vals;
        private int _lastSearchPos;
        private string _lastSeartchTxt;

        public Main()
        {
            InitializeComponent();
        }

        private void _getPathDialog()
        {
            var opFile = ViewConstruct.CreateOpenFileDialog();
            if (opFile.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                this._settings.File = opFile.FileName;
            }
        }

        private void _initWorkspace()
        {
            this._settings = new Prefs();
            this._lastSearchPos = -1;
            this._lastSeartchTxt = string.Empty;
            this.dataView.Rows.Clear();
        }

        private void _initDataView(bool isAddTranslations = false)
        {
            this.lblRowsVal.Text = this._vals.Values.Count.ToString("#,###");

            this.dataView.Rows.Clear();

            foreach (var item in this._vals.Values)
            {
                var row = new DataGridViewRow();
                row.CreateCells(this.dataView);
                row.Cells[0].Value = item.ToString();
                row.Cells[1].Value = isAddTranslations ? (item.TranslationToString().Length > 0 ? item.TranslationToString() : string.Empty) : string.Empty;
                this.dataView.Rows.Add(row);
            }
        }

        private void btnExtract_Click(object sender, EventArgs e)
        {
            try
            {
                this._getPathDialog();
                this._vals = new BytesText(this._settings.File);
                this._initDataView();
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Main_Load(object sender, EventArgs e)
        {
            this._initWorkspace();
        }

        private void exitMenu_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private List<byte> _generateOutput()
        {
            var output = new List<byte>();
            var index = 0;
            var isAdded = false;
            for (int i = 0; i < this._vals.OriginalByteArray.Length; i++)
            {
                if (this._vals.Values.Count <= index)
                    output.Add(this._vals.OriginalByteArray[i]);
                else if (i > this._vals.Values[index].Before && i < this._vals.Values[index].After && this.dataView.Rows[index].Cells[1].Value.ToString().Length > 0 && !isAdded)
                {
                    //var txt = Encoding.ASCII.GetString(Encoding.Default.GetBytes(this.dataView.Rows[index].Cells[1].Value.ToString()));
                    //var bs = Encoding.Default.GetBytes(txt);
                    var bs = Encoding.Default.GetBytes(this.dataView.Rows[index].Cells[1].Value.ToString());
                    foreach (var b in bs)
                    {
                        output.Add(b);
                    }
                    isAdded = true;
                }
                else if (i == this._vals.Values[index].After)
                {
                    output.Add(this._vals.OriginalByteArray[i]);
                    index++;
                    isAdded = false;
                }
                else if (isAdded)
                    continue;
                else
                    output.Add(this._vals.OriginalByteArray[i]);
            }
            return output;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                var dialog = ViewConstruct.CreateSaveFileDIalog();
                if (dialog.ShowDialog() != System.Windows.Forms.DialogResult.OK)
                    return;

                this._vals.Translated = this._generateOutput();
                this._vals.Save(dialog.FileName);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private byte[] _getBytes(string str)
        {
            byte[] bytes = new byte[str.Length * sizeof(char)];
            System.Buffer.BlockCopy(str.ToCharArray(), 0, bytes, 0, bytes.Length);
            return bytes;
        }

        private void dataView_SelectionChanged(object sender, EventArgs e)
        {
            lblCurRowVal.Text = (this.dataView.CurrentCell.RowIndex + 1).ToString();
        }

        private void btnFind_Click(object sender, EventArgs e)
        {
            if (txtFind.Text == string.Empty)
            {
                MessageBox.Show("No value to search");
                return;
            }
            if (txtFind.Text != this._lastSeartchTxt)
            {
                this._lastSeartchTxt = txtFind.Text;
                this._lastSearchPos = -1;
            }
            foreach (DataGridViewRow row in this.dataView.Rows)
            {
                if (row.Index <= this._lastSearchPos)
                    continue;
                if (row.Cells[0].Value.ToString().ToLower().IndexOf(txtFind.Text.ToLower()) >= 0)
                {
                    this._lastSearchPos = row.Index;
                    this.dataView.CurrentCell = row.Cells[0];
                    this.dataView.FirstDisplayedScrollingRowIndex = this.dataView.CurrentCell.RowIndex;
                    return;
                }
            }
            if (this._lastSearchPos > -1 && txtFind.Text == this._lastSeartchTxt)
            {
                this._lastSearchPos = -1;
                this.btnFind_Click(sender, e);
                return;
            }
            MessageBox.Show(string.Format("'{0}' is not found", txtFind.Text));
        }

        private void txtFind_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Return)
            {
                this.btnFind_Click(sender, e);
            }
        }

        private void saveProjectMenu_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < this.dataView.Rows.Count; i++)
            {
                var tr = this.dataView.Rows[i].Cells[1].Value;
                if (tr != null && tr.ToString().Length > 0)
                {
                    this._vals.Values[i].Translation = new List<byte>(Encoding.Default.GetBytes(tr.ToString()));
                }
            }
            var dialog = ViewConstruct.CreateSaveFileDIalog(Prefs.FILTER_PROJECT);
            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                try
                {
                    var proj = new TranslationProject();
                    proj.Data = this._vals;
                    proj.Settings = this._settings;
                    proj.SaveProject(dialog.FileName);
                    MessageBox.Show("The project is saved");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void openProjectMenu_Click(object sender, EventArgs e)
        {
            this._initWorkspace();
            var dialog = ViewConstruct.CreateOpenFileDialog(Prefs.FILTER_PROJECT);
            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                try
                {
                    var proj = TranslationProject.LoadProject(dialog.FileName);
                    this._settings = proj.Settings;
                    this._vals = proj.Data;
                    this._initDataView(true);
                }
                catch (Exception ex)
                {
                    this._initWorkspace();
                    MessageBox.Show(ex.Message);
                }
            }

        }

        private void resetMenu_Click(object sender, EventArgs e)
        {
            this._initWorkspace();
        }

        private void Main_FormClosing(object sender, FormClosingEventArgs e)
        {
            var result = MessageBox.Show("The programm will close now.\r\nAre you sure you want to do that?", "Program is closing", MessageBoxButtons.OKCancel);
            if (result != System.Windows.Forms.DialogResult.OK)
                e.Cancel = true;
        }
    }
}
