﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace SmiteTranslation
{
    public class DirFile
    {
        public string Extension { get; private set; }
        public string FileName { get; private set; }
        public string FullPath { get; private set; }

        public DirFile(string fullPath)
        {
            this.SetFile(fullPath);
        }

        public void SetFile(string fullPath)
        {
            this.FileName = Path.GetFileName(fullPath);
            this.FullPath = fullPath;
            this.Extension = Path.GetExtension(this.FullPath);
        }
    }
}
