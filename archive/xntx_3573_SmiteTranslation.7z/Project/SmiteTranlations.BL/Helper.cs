﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SmiteTranlations.BL
{
    public static class Helper
    {
        
    }
}
