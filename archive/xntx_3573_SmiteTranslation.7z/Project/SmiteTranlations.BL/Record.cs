﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SmiteTranlations.BL
{
    [Serializable]
    public class Record
    {
        public List<byte> Value { get; set; }
        public List<byte> Translation { get; set; }
        public int Before { get; set; }
        public int After { get; set; }

        public string TranslationToString()
        {
            if (this.Translation == null)
                return string.Empty;
            return Encoding.UTF8.GetString(this.Translation.ToArray());
        }

        public override string ToString()
        {
            if (this.Value == null)
                return string.Empty;
            return Encoding.UTF8.GetString(this.Value.ToArray());
        }
    }
}
