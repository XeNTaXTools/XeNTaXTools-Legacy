﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using IniParser;

namespace SmiteTranlations.BL
{
    [Serializable]
    public class BytesText
    {
        const int BEFORE = 0;
        const int AFTER = 1;

        private List<Record> _values;

        public List<byte> Translated { get; set; }
        public byte[] OriginalByteArray { get; private set; }
        public List<Record> Values
        {
            get
            {
                return this._values;
            }
        }

        public void Save(string path)
        {
            if (this.Translated == null || this.Translated.Count == 0)
                return;
            using (var stream = File.Open(path, FileMode.Create))
            using (var wrighter = new BinaryWriter(stream, Encoding.ASCII))
            {
                wrighter.Write(this.Translated.ToArray());
            }
        }

        public BytesText() { }

        public BytesText(string path)
        {
            this.CreateFromPath(path);
        }

        public void CreateFromPath(string path)
        {
            if (path == string.Empty)
                throw new Exception("Wrong file path");
            try
            {
                this._createFromDat(path);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void _createFromDat(string path)
        {
            using (var stream = File.Open(path, FileMode.Open))
            using (var reader = new BinaryReader(stream))
            {
                this.OriginalByteArray = reader.ReadBytes(int.Parse(stream.Length.ToString()));
            }
            this._values = new List<Record>();
            this._load();
        }

        private void _load()
        {
            int index = 0;
            bool isWriting = false;
            for (int i = 0; i < this.OriginalByteArray.Length; i++)
            {
                var f = i + 1;
                var s = i + 2;

                //If stream is ended
                if (i == this.OriginalByteArray.Length - 1)
                    break;

                //If string is ended
                var c = Convert.ToChar(this.OriginalByteArray[i]);
                if (isWriting && !(Char.IsLetterOrDigit(c) || Char.IsPunctuation(c) || Char.IsSeparator(c)))
                {
                    this._values[index].After = i;
                    isWriting = false;
                    index++;
                    continue;
                }

                //If need to add another char to collection
                if (isWriting && this.OriginalByteArray[i] != 1)
                {
                    this._values[index].Value.Add(this.OriginalByteArray[i]);
                    continue;
                }

                //If need to do nothing - May be not nessesery anymore
                if (this.OriginalByteArray[i] == 0 && this.OriginalByteArray[f] == 0)
                    continue;

                //If string started
                if (this.OriginalByteArray[i] == 0 && Char.IsLetterOrDigit(Convert.ToChar(this.OriginalByteArray[f])) && this.OriginalByteArray[s] != 0)
                {
                    isWriting = true;
                    this._values.Add(new Record());
                    this._values[index].Value = new List<byte>();
                    this._values[index].Before = i;
                }

            }
        }
    }
}
