from .lib.ModelObject import Model3D

class DirectX_Object(Model3D):
    '''.x text file format'''
    
    #hardcoding all templates I've seen so far. Haven't found a way to
    #skip over the definition of each template
    templates = set(("Frame", "FrameTransformMatrix", "Mesh", "MeshNormals", 
                 "MeshTextureCoords", "XSkinMeshHeader", "SkinWeights",
                 "MeshMaterialList", "Material", "TextureFilename", "template",
                 "AnimTicksPerSecond", "MeshFace", "MeshVertexColors",
                 "Animation", "AnimationSet", "TimedFloatKeys",
                 "AnimationKey", "VertexDuplicationIndices", "Header")
                 )
    
    def __init__(self, obj3D=None, inFile=None, outFile=None):
        
        super(DirectX_Object, self).__init__("X")
        self.obj3D = obj3D
        self.inFile = inFile
        self.outFile = outFile
        self.frameStack = []
        self.tempStack = []
        self.tempCount = 0
        self.xMats = []
        self.matReference = False
        
    def start_temp(self, template):
        
        self.tempStack.append(template)
        
    def get_temp(self):
        
        return self.tempStack[-1]
        
    def end_temp(self):
        
        self.tempStack.pop()
        
    def skip_blank(self):
        
        line = self.inFile.readline().strip()
        while not line or line == "{" or line == "}":
            line = self.inFile.readline()
        return line
    
    def parse_normals(self, objName):
        
        line = self.skip_blank()
        normCount = int(line.strip().strip(';'))

        if normCount == self.vert_count(objName):        
            for i in range(0, normCount):
                line = self.inFile.readline().strip().strip(',').strip(';')
                norms = line.split(";")
                
                self.add_vert_normals(objName, i, norms)
        else:
            for i in range(0, normCount):
                line = self.inFile.readline().strip().strip(',').strip(';')
    
    def parse_texture_coords(self, objName):
        
        line = self.skip_blank()
        texCount = int(line.strip().strip(';'))
        
        if texCount == self.vert_count(objName):
            for i in range(0, texCount):
                line = self.inFile.readline().strip().strip(',').strip(';')
                uv = line.split(";")
                
                self.add_vert_uv(objName, i, uv)
        else:
            for i in range(0, texCount):
                line = self.inFile.readline().strip().strip(',').strip(';')
                print line
    
    def parse_texture(self, matNum):
        
        line = self.inFile.readline()
        texName = line.strip().strip(";").replace('"', "")
        self.add_texture_name(matNum, texName)
    
    def parse_material(self, line):
        
        line = line.replace("{", "").split()
        matNum = self.mat_count()
        matName = line[1] if len(line) > 1 else \
                "material" + str(matNum)
        
        self.xMats.append(matName)

        
        rgba = self.inFile.readline().strip().strip(";;").split(";")
        power = self.inFile.readline().strip().strip(";")
        specular = self.inFile.readline().strip().strip(";;").split(";")
        emissive = self.inFile.readline().strip().strip(";;").split(";")
        
        self.create_material(matNum)
        self.add_material_name(matNum, matName)
        self.add_rgba(matNum, rgba)
        self.add_power(matNum, power)
        self.add_specular(matNum, specular)
        self.add_emissive(matNum, emissive)
        return matNum
    
    def parse_material_list(self, objName):
        
        matOffset = self.mat_count()
        
        #keep track of the material numbers
        matNumbers = []
        
        line = self.inFile.readline().strip().strip(";").split(";")
        
        #different ways to define material list
        
        if len(line) == 3:
            #matCount; FaceCount; MatNum;;
            matCount = int(line[0])
            
            faceCount = self.face_count(objName)
            matNum = int(line[2])
            
            for i in range(0, faceCount):
                self.add_face_material(objName, i, matNum)
        else:
            
            matCount = int(line[0])
            faceCount = int(self.inFile.readline().strip().strip(";"))
            #two cases: and without new line
            line = self.inFile.readline().strip().strip(',').strip(';')
            
            if len(line) == 1:                
                if faceCount != 1:
                    matNum = int(line.strip().strip(',').strip(';'))
                    matNumbers.append(matNum)
                    for i in range(1, faceCount):
                        line = self.inFile.readline()
                        matNum = int(line.strip().strip(',').strip(';'))
                        matNumbers.append(matNum)
                        #self.add_face_material(objName, i, matNum)
                else:
                    faceCount = self.face_count(objName)
                    matNum = int(line.strip().strip(',').strip(';'))
                    for i in range(0, faceCount):
                        matNumbers.append(matNum)
                        #self.add_face_material(objName, i, matNum)
            else:
                x = 0
                numbers = line.split(',')
                for matNum in numbers:
                    #self.add_face_material(objName, x, matNum)
                    matNumbers.append(matNum)
                    x += 1
                while x != faceCount:
                    line = self.inFile.readline().strip().strip(',').strip(';')
                    numbers = line.split(',')
                    for matNum in numbers:
                        matNumbers.append(matNum)
                        x += 1
                        
            #some x files define materials first
            if self.matReference:
                #get the materials used
                matUsed = []
                for i in range(matCount):
                    line = self.inFile.readline().strip()                
                    name = line[1:-1]
                    matIndex = self.xMats.index(name)
                    matUsed.append(matIndex)
                    
                #assign face material with updated index
                for i in range(faceCount):
                    self.add_face_material(objName, i, matUsed[int(matNumbers[i])])
            else:
                for i in range(faceCount):
                    self.add_face_material(objName, i, matNumbers[i])
            
            
    def parse_mesh(self, line):
        
        line = line.replace("{", "").split()
        objName = line[1] if len(line) > 1 else "obj" + str(len(self.get_objects()))
        self.create_object(objName)
        
        line = self.skip_blank()
        meshCount = int(line.strip().strip(";"))
        for i in range(0, meshCount):
            line = self.inFile.readline().strip().strip(";,")
            coords = line.split(";")
            
            coords[0] = float(coords[0]) * -1.0
            
            self.create_vertex(objName, i)
            self.add_coords(objName, i, coords)
        line = self.skip_blank()
        faceCount = int(line.replace(";", "").strip())
        
        for i in range(0, faceCount):
            line = self.inFile.readline().strip().strip(";,").split(";")
            numVerts = int(line[0])
            
            tempVerts = line[1:]
            if len(tempVerts) == numVerts:
                verts = tempVerts
            else:
                #uses commas to separate vertices
                verts = tempVerts[0].split(',')

            self.create_face(objName, i)
            self.add_face_verts(objName, i, verts)
        
        return objName            
    
    def parse_template(self):
        
        header, xversion, xtype = self.inFile.readline().split()
        #if xversion == "0302txt" and xtype == "0064":
            #self.matReference = True
        
        line = self.inFile.readline()
        while line:
            temp = line.strip().split()
            if not temp: 
                pass
            else:
                template = temp[0].strip("{")
                if template in self.templates:
                    #use template definition to check material referencing
                    if template == "Template" and temp[1] == "Material":
                        self.matReference = True
                    self.start_temp(template)
                    
                if line.find("{") != -1 and line.find("}") == -1:
                    #get current template
                    template = self.get_temp()
                    if template == "Frame":
                        pass
                    elif template == "SkinWeights":
                        pass
                    elif template == "Mesh":
                        objName = self.parse_mesh(line)
                    elif template == "MeshTextureCoords":
                        self.parse_texture_coords(objName)
                    elif template == "MeshNormals":                    
                        self.parse_normals(objName)
                    elif template == "MeshMaterialList":
                        self.parse_material_list(objName)
                    elif template == "Material":
                        matNum = self.parse_material(line)
                    elif template == "TextureFilename":
                        self.parse_texture(matNum)
                elif line.find("}") != -1 and line.find("{") == -1:
                    self.end_temp()      
            line = self.inFile.readline()

    def parse_file(self):
        
        self.parse_template()
        
def read_file(path):
    
    openFile = open(path, 'r')
    obj = DirectX_Object(inFile=openFile)
    obj.parse_file()
    openFile.close()
    return obj

def write_x(self):
    
    pass

def definitions():
    
    return "xof", "X", "Directx txt"
    
if __name__ == '__main__':
    
    name1 = "efc_fate_beem.x"
    name2 = "act_taiki.x"
    name3 = "C38b_02.x"
    name4 = "afterburner.x"
    obj = read_file(name3)