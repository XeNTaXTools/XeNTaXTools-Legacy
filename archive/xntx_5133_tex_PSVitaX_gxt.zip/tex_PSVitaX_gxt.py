from inc_noesis import *
import os

def registerNoesisTypes():
	handle = noesis.register("PSVita texture experiment", ".gxt")
	noesis.setHandlerTypeCheck(handle, noeCheckGeneric)
	noesis.setHandlerLoadRGBA(handle, NoepyLoadRGBA)
	noesis.logPopup()
	return 1

def NoepyLoadRGBA(data, texList):
	bs = NoeBitStream(data)
	imgWidth = 512                  #set image width
	imgHeight = 512                 #set image height
	fileName = os.path.basename(rapi.getInputName()) 
	if "_d" in fileName:
		print("\n", "Add 8 bytes to the end of the file to account for shift", "\n", "...but it still doesn't look right :(")
		datasize = len(data) - 0x7      #shift image data by this amount
		bs.seek(0x7, NOESEEK_ABS)       #go here to account for shift  
		data = bs.readBytes(datasize)      
		imgFmt = 1
	elif "_n" in fileName:
		imgFmt = 2    
		print("\n", "This one looks ok to me", "\n")
	elif "_s" in fileName:
		print("WARNING: Unhandled image format: Not yet implemented")	
		return 0
	#DXT1
	if imgFmt == 1:
		data = rapi.imageFromMortonOrder(data, imgWidth>>2, imgHeight>>2, 4) #text2_d, 512x512 ?, add 8 bytes to file and shift by 0x7 
		texFmt = noesis.NOESISTEX_DXT1
	#DXT1
	elif imgFmt == 2:
		data = rapi.imageFromMortonOrder(data, imgWidth>>1, imgHeight>>2, 4) #text2_n, 512x512, NO shift
		texFmt = noesis.NOESISTEX_DXT1
	#DXT5 unused so far
	#elif imgFmt == 3:
	#	data = rapi.imageFromMortonOrder(data, imgWidth>>1, imgHeight>>2, 8)
	#	texFmt = noesis.NOESISTEX_DXT5
	#unknown, not handled
	else:
		print("WARNING: Unhandled image format")
		return None
	texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
	return 1