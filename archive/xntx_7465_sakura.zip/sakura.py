from urllib.request import ProxyHandler, build_opener, install_opener, urlopen
from itertools import islice
from multiprocessing.dummy import Pool as ThreadPool
import os
import io
import struct
pool = ThreadPool(10)

if not os.path.exists("sakura"):
    os.makedirs("sakura")
#proxy = urllib.request.ProxyHandler({'http': 'http://192.168.1.91:8888'})
proxy = ProxyHandler({})
opener = build_opener(proxy)
opener.addheaders = [('X-Verification-Code','uXQW5TbmAQcv'),('X-Unity-Version','2019.4.2f1'),('User-Agent','User-Agent: UnityPlayer/2019.4.2f1 (UnityWebRequest/1.0, libcurl/7.52.0-DEV)')]
install_opener(opener)



def geturl(name):
	try:
		tmp = name[1].rsplit('/',1)
		#print(tmp)
		os.makedirs('sakura\\' + tmp[0])
		if os.path.exists('sakura\\' + name[1]):
			pass
		else:
			print('Downlaoding',tmp[1])
			myFile = urlopen(name[0]).read()
			with open('sakura\\' + name[1], 'wb') as f:
				f.write(myFile)
		
	except:
		pass


with open('sakura.txt', "r" ) as f:
	names = []
	lines = f.readlines()

	for line in lines:
		base,name = line.split('http://game-asset.sa-kakumei.jp/fold_L8F7OunPk5x54Q7N/Android/')
		#print(name)
		#print(line)
		names.append([line,name.rstrip('\n')])

	pool.map(geturl, names )

