takes in .bdae model files from worlds best driver (2013) and attempts to convert to .obj format

how to use
- drag and drop file onto .exe
- enter name of model/car(to name folder and .obj files)
- press enter

one issue is that the foramt consists of multiple submeshes and i havent taken the time to figure out how to combine submeshes into single mesh file. so it exports dozens of .obj files within a folder

the exporter is able to export texture coordinates, normal and position data to the .obj file

• uses small utility library for half precision floating point values
• much model format information has not been decoded
• what look to be the data to uniforms are read into memory but nothing is done with them

compile with c++17 (std::filesystem)

- TODO:
	- export as single mesh instead of dozens of seperate meshes
	- log uniforms to seperate plain text file?

the texture files (.brres) are just packed .dds files