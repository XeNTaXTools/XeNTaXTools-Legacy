#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <thread>
#include <filesystem>
#include <array>

// support for half precision floats
#include "FP16-master/include/fp16.h"

namespace fs = std::filesystem;

using u8	= unsigned char;
using u16	= unsigned short;
using u32	= unsigned int;
using u64	= unsigned long long;

using i8	= signed char;
using i16	= signed short;
using i32	= signed int;
using i64	= signed long long;

using f32	= float;
using f64	= double;

#define HeadSectionPos 0x8
#define HeadOffsetsPos 0x40

// 0x8
#pragma pack(1)
struct BDAE_HeadSection {
	u32 ukw0;	 			// 0x8
	u32 matNum;	 			// 0xC   (number of materials)
	u32 gNum;	 			// 0x10  (number of g_uniforms?)
	u32 boneNum; 			// 0x14  (number of bones)
	u32 subMeshNum; 	 	// 0x18  (number of submeshes)
	u32 ukw5;	 			// 0x1C
	u32 ukw6;	 			// 0x20
	char padding[28]; 		// 0x24
}; // 56 bytes

// 0x40
#pragma pack(1)
struct BDAE_HeadOffsets {
	u32 faceNum;			// 0x40  (number of faces)
	u32 matOffs;			// 0x44  (materials)	
	u32 gOffs;  			// 0x48  (g_uniform or vector?)
	u32 boneOffs; 			// 0x4C  (bones?)

	u32 bHireOffs;			// 0x50  (bone hirearchy?)
	u32 meshTableOffs;		// 0x54  (sub mesh table)
	u32 vStartOffs;			// 0x58  (vertices start yyyy)
	u32 vertOffs; 			// 0x5C  (vertices)

	u32 faceOffs; 			// 0x60  (faces/indices)
	u32 ukw9;				// 0x64
	u32 ukw10;				// 0x68
	u32 ukw11;				// 0x6C

	u32 ukw12;				// 0x70
	u32 ukw13;				// 0x74
	u32 ukw14;				// 0x78
	u32 ukw15;				// 0x7C
}; // 64 bytes



#pragma pack(1)
struct BDAE_Material {
	// (offsets from block start)

	char name[64];		   	// 0x0
	char texNames[10][32]; 	// 0x40 
	char padding[20];		// 0x180
	u32 ukw0;				// 0x194
	u32 ukw1;				// 0x198
	u32 ukw2;				// 0x19C
	u32 ukw3;				// 0x1A0
	u32 ukw4;				// 0x1A4
}; // 424 bytes


#pragma pack(1)
struct BDAE_SubMeshInfo {
	// (offsets from block start)

	u32 ukw0;			// 0x0
	u32 VertexStride;	// 0x4
	u32 VertexStart;	// 0x8
	u32 VertexCount;	// 0xC
	u32 IndexStart;		// 0x10
	u32 IndexCount;		// 0x14
	char padding[24];	// 0x18
}; // 48 bytes


#pragma pack(1)
struct BDAE_gUniform {
	// (offsets from block start)

	i8 name[32]; 		// 0x0
	i8 padding[44];		// 0x20
	u32 nComponents; 	// 0x4C // (number of components in vector (+ 1)?
	f32 values[4]; 		// 0x50
};


//// bone?
//#pragma pack(1)
//struct BDAE_Bone {
//	i8 name[32];
//	f32 matrix[3][3]; // matrix?
//};

#pragma pack(1)
struct BDAE_Pos {
	f32 x;
	f32 y;
	f32 z;
};

// half floats (use half float to float converter)
#pragma pack(1)
struct BDAE_Normal {
	u16 x;
	u16 y;
	u16 z;
};

// half floats (use half float to float converter)
#pragma pack(1)
struct BDAE_UV {
	u16 s;
	u16 t;
};

#pragma pack(1)
struct BDAE_Vertex {
	BDAE_Pos pos;
	BDAE_Normal normal;
	u16 pad;
	BDAE_UV uv;
};


// half float vec3
struct vec3hf {
	f32 x;
	f32 y;
	f32 z;
	vec3hf(u16 x, u16 y, u16 z)
	{
		this->x = fp16_ieee_to_fp32_value(x);
		this->y = fp16_ieee_to_fp32_value(y);
		this->z = fp16_ieee_to_fp32_value(z);
	}
};

// half float vec2
struct vec2hf {
	f32 x;
	f32 y;
	vec2hf(u16 x, u16 y)
	{
		this->x = fp16_ieee_to_fp32_value(x);
		this->y = fp16_ieee_to_fp32_value(y);
	}
};

struct BDAE_Mesh {
	BDAE_Vertex* vertexData;
	u16* indices;

	u32 indexCount;
	u32 vertexCount;

	BDAE_Mesh() : vertexData(nullptr), indices(nullptr), indexCount(0), vertexCount(0)
	{}

	~BDAE_Mesh()
	{
		delete[] vertexData;
		delete[] indices;
	}
};


void exit_condition(bool cond, const std::string& msg)
{
	if (cond)
	{
		std::cerr << msg << std::endl;
		std::this_thread::sleep_for(std::chrono::seconds(2));
		exit(1);
	}
}

bool is_bdae_file(std::ifstream& file)
{
	constexpr char len = 5;
	std::array<char, len + 1> buffer;
	file.read(buffer.data(), len);
	buffer[len] = '\0';

	if (std::string(buffer.data()) == "EADB$")
		return true;

	return false;
}

int main(int argc, char** argv)
{
	exit_condition(argc < 2, "no file input");

	// file argument
	const auto& farg = argv[1];

	exit_condition(!fs::exists(farg), "\"" + std::string(farg) + "\" file does not exist");
	fs::path filepath(farg);

	// check path is file and not directory
	exit_condition(fs::status(filepath).type() != fs::file_type::regular, "\"" + filepath.stem().string() + "\" is not a file");

	// input file
	std::ifstream file(farg, std::ios::binary);
	
	// check for bdae file signature
	exit_condition(!is_bdae_file(file), "unexpected header (not a bdae file from worlds best driver)");

	// have enter use model name for what do name the files
	std::string name, dirname, newdir;
	std::cout << "enter model name: ";
	std::cin >> name;

	// directory name	
	dirname = name + "_submeshes";
	// directory path
	newdir = filepath.remove_filename().string() + dirname;
	
	// if for some reason unable to create directory
	exit_condition(!fs::create_directory(newdir) && !fs::is_directory(newdir), "unable to create directory \"" + dirname + "\"");


	BDAE_HeadSection hs{};
	BDAE_HeadOffsets ho{};

	file.seekg(HeadSectionPos);

	// read HeaderSection and HeaderOffsets
	file.read((char*)&hs, sizeof(BDAE_HeadSection));
	file.read((char*)&ho, sizeof(BDAE_HeadOffsets));

	// allocate memory
	BDAE_Material* mats			= new BDAE_Material[hs.matNum];
	BDAE_gUniform* unif			= new BDAE_gUniform[hs.gNum];
	BDAE_SubMeshInfo* meshInfo	= new BDAE_SubMeshInfo[hs.subMeshNum];
	BDAE_Mesh* meshes			= new BDAE_Mesh[hs.subMeshNum];
	std::ofstream* outFiles		= new std::ofstream[hs.subMeshNum];



	// read materials
	file.seekg(ho.matOffs);
	for (int i = 0; i < hs.matNum; i++)
		file.read((char*)&mats[i], sizeof(BDAE_Material));


	// read uniforms?
	file.seekg(ho.gOffs);
	for (int i = 0; i < hs.gNum; i++)
		file.read((char*)&unif[i], sizeof(BDAE_gUniform));


	// read sub mesh info table
	file.seekg(ho.meshTableOffs);
	for (int i = 0; i < hs.subMeshNum; i++)
		file.read((char*)&meshInfo[i], sizeof(BDAE_SubMeshInfo));
	

	// loop over sub meshes and read their data
	for (int i = 0; i < hs.subMeshNum; i++)
	{
		const auto& mi = meshInfo[i];
		size_t offs = (mi.VertexStart * mi.VertexStride) + ho.vertOffs;
		file.seekg(offs);

		meshes[i].vertexData = new BDAE_Vertex[mi.VertexCount];
		meshes[i].indices = new u16[mi.IndexCount];

		meshes[i].indexCount = mi.IndexCount;
		meshes[i].vertexCount = mi.VertexCount;

		// read vertex data
		for (int j = 0; j < mi.VertexCount; j++)
		{
			file.read((char*)&meshes[i].vertexData[j], sizeof(BDAE_Vertex));
			file.seekg((int)file.tellg() + (mi.VertexStride - sizeof(BDAE_Vertex)));
		}

		// read face data
		file.seekg(ho.faceOffs + (mi.IndexStart * 2));
		file.read((char*)meshes[i].indices, mi.IndexCount * 2);
	}

	// open files
	for (int i = 0; i < hs.subMeshNum; i++) {
		outFiles[i].open(std::string(dirname + "/" + name + "_" + std::to_string(i) + ".obj"));		
	}

	// loop through submeshes and write submeshes to files
	for (int i = 0; i < hs.subMeshNum; i++) 
	{
		// write vertices
		for (int j = 0; j < meshes[i].vertexCount; j++)
		{
			outFiles[i] << "v " << meshes[i].vertexData[j].pos.x << " " << meshes[i].vertexData[j].pos.y << " " << meshes[i].vertexData[j].pos.z << "\n";
		}

		// write normals
		for (int j = 0; j < meshes[i].vertexCount; j++)
		{
			const auto& vnd = meshes[i].vertexData[j].normal;
			vec3hf n(vnd.x, vnd.y, vnd.z);
			outFiles[i] << "vn " << n.x << " " << n.y << " " << n.z << "\n";
		}

		// write texture coordinates
		for (int j = 0; j < meshes[i].vertexCount; j++)
		{
			const auto& vud = meshes[i].vertexData[j].uv;
			vec2hf uv(vud.s, vud.t);
			outFiles[i] << "vt " << uv.x << " " << uv.y << "\n";
		}

		// write faces
		u16 sub = meshes[i].indices[0];
		for (int j = 0; j < meshes[i].indexCount; j += 3) 
		{
			outFiles[i] << "f ";
			outFiles[i] << (meshes[i].indices[j] + 1) - sub << "/";
			outFiles[i] << (meshes[i].indices[j] + 1) - sub << "/";
			outFiles[i] << (meshes[i].indices[j] + 1) - sub << " ";
			
			outFiles[i] << (meshes[i].indices[j + 1] + 1) - sub << "/";
			outFiles[i] << (meshes[i].indices[j + 1] + 1) - sub << "/";
			outFiles[i] << (meshes[i].indices[j + 1] + 1) - sub << " ";
				
			outFiles[i] << (meshes[i].indices[j + 2] + 1) - sub << "/";
			outFiles[i] << (meshes[i].indices[j + 2] + 1) - sub << "/";
			outFiles[i] << (meshes[i].indices[j + 2] + 1) - sub << "\n";
		}
	}

	// close files
	for (int i = 0; i < hs.subMeshNum; i++)
		outFiles[i].close();


	// release memory 
	delete[] outFiles;
	delete[] meshes;
	delete[] mats;
	delete[] unif;
	delete[] meshInfo;
}