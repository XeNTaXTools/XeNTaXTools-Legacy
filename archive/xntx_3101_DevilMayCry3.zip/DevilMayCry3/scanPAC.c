#include <stdio.h>
#include <stdlib.h>
#define MAX 512

typedef unsigned int uint;

//get filesize
int filesize(FILE *fil) {
	int size;
	
	fseek(fil, 0, SEEK_END);
	size = ftell(fil);
	fseek(fil, 0, SEEK_SET);
	return(size);
}

//get unsigned int,
unsigned int GETINT(unsigned char *ptr) {
	return((unsigned int)((ptr[3]<<24)|(ptr[2]<<16)|(ptr[1]<<8)|ptr[0]));
}

//big endian
unsigned int TYPEINT(unsigned char *ptr) {	
	return((unsigned int)((ptr[0]<<24)|(ptr[1]<<16)|(ptr[2]<<8)|ptr[3]));
}

int getType(char *ptr, char *type) {
	//test for PTX
	uint ptx_count = GETINT(ptr);
	if ( !(GETINT(ptr + (ptx_count*4)+8)) || ptx_count == 511 || ptx_count == 512 ) {
		snprintf(type, 512, "%s", "PTX");
		return(1);
	}
	
	uint test = TYPEINT(ptr);
	switch( test ) {
	case 0x4D4F4420:
		//type = "MOD";
		sprintf(type, "%s", "MOD");
		break;
	case 0x54494D32:
		//type = "TIM2";
		sprintf(type, "%s", "TIM2");
		break;
	case 0x53485720:
		//type = "SHW";
		sprintf(type, "%s", "SHW");
		break;
	case 0x50000000:
		//type = "MOT";
		sprintf(type, "%s", "MOT");
		break;
	case 0x50414300:
		//type = "PAC";
		sprintf(type, "%s", "PAC");
		break;
	case 0x504E5354:
		//type = "PNST";
		sprintf(type, "%s", "PNST");
		break;
	case 0x4F676753:
		//type = "Ogg";
		sprintf(type, "%s", "OGG");
		break;
	case 0x424D3600:
		//type = "BM6";
		sprintf(type, "%s", "BM6");
		break;
	case 0x000001BA:
		//type = "MPG";
		sprintf(type, "%s", "MPG");
		break;
	case 0x4C494732:
		//type = "LIG2";
		sprintf(type, "%s", "LIG2");
		break;
	case 0x53454600:
		//type = "SEF";
		sprintf(type, "%s", "SEF");
		break;
	case 0x43414d00:
		//type = "CAM";
		sprintf(type, "%s", "CAM");
		break;
	case 0x45564500:
		//type = "EVE";
		sprintf(type, "%s", "EVE");
		break;
	case 0x504F5300:
		//type = "POS";
		sprintf(type, "%s", "POS");
		break;
	case 0xEFBBBF23:
		//type = "TXT";
		sprintf(type, "%s", "TXT");
		break;
	case 0x00000000:
		//type = "BD";
		sprintf(type, "%s", "BD");
		break;
	case 0x00000100:
		//type = "ICO";
		sprintf(type, "%s", "ICO");
		break;
	case 0x64627354:
		//type = "TSB";
		sprintf(type, "%s", "TSB");
		break;
	case 0x66662641:
		//type = "FF";
		sprintf(type, "%s", "FF");
		break;
	default:
		//type = "UKN";
		sprintf(type, "%s", "UKN");
		break;
	}

	return(1);
}

int main(int argc, char *argv[]) {
	//greeting
	printf("PAC scanner\nPrints out Contents of PAC\n\n");
	char *input, output[MAX];
	
	//get files, or print usage
	if (argc < 2) {
		printf("Usage: %s [file]\n", argv[0]);
		return(-1);
	} else {
		input = argv[1];
	}
	
	//if can't open file, exit
	FILE *fi;
	printf("Opening: %s\n", input);
	if (!(fi = fopen(input, "rb"))) {
		printf("Error opening %s\n", input);
		return(-1);
	}
	
	//if can't get file size, exit
	int size;
	if (!(size = filesize(fi))) {
		printf("Error Getting Filesize of %s\n", output);
		return(-1);
	}
	
	//if not enough memory, exit
	unsigned char *buffer;
	if (!(buffer = malloc(size))) {
		printf("Not Enough Memory\n");
		return(-1);
	}
	
	//if cannot read file, exit
	printf("Reading: %s\n", input);
	if (!(fread(buffer, 1, size, fi))) {
		printf("Error Reading %s\n", input);
		return(-1);
	}
	//END OPENING STATEMENTS
	
	uint num_files = GETINT(buffer+4);
	int i, ptr;
	char *type;
	uint offset = 8;
	printf("Scanning: %s\n", input);
	printf("\n INDEX ::    OFFSET    ::  FILE TYPE\n");
	for ( i=0; i<num_files; i++) {
		ptr = GETINT(buffer+offset);
		if (ptr) getType(buffer+ptr, type);
		else type = (NULL);
		printf("  %.3d  ::  0x%.8X  ::     %s\n", i, ptr, type);
		offset += 4;
	}
	
	return(0);
}
