=================================
Devil May Cry 3
Pac extractor
vBETA
Coded by James aka Jamesuminator
=================================
---------------------------------

Usage: PacExtract [file]
Extracts Contents of a DMC3 PAC

======================================================================
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

Pac Extractor
coded by James

Extracts PAC archives, the following filetypes have made up names
	so  (named after the the header, which is "60 00")

any other name is taken from the header.

----------------------

=================================
Devil May Cry 3
Pac Repacker
vBETA
Coded by James aka Jamesuminator
=================================
---------------------------------

Usage: PacRepack [folder] {outfile}
if no outfile given, outfile is [folder].pac

====================================================================
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

Pac Repacker
coded by James

Will not repack a "PNST" header
May have some errors on some files*
Trouble with some PTX's

*Very odd exceptions.

----------------------

=================================
Devil May Cry 3 
PAC Injector
vBETA
Coded by James aka Jamesuminator
=================================
---------------------------------

Usage: PacInject.exe [Pac File] [Inject File] [Position] {outfile}
if no outfile given, replaces [Pac File]

======================================================================
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

Pac Injector
coded by James

Works perfectly.
Has no support for TIM2 injection.
Must inject PTX archives.

NOTE: no Dlls needed, total stand alone


More Apps included
All Beta
