#PTX Repack
#coded by james
import sys
from struct import pack


#Another version of getFiles, for PTX usage
def getFilesPTX(index_file):
    line = index_file.readline().strip()
    files = []
    while line != "":
        print "\t%s" % line
        files.append(line)
        line = index_file.readline().strip()
    return files

#repacks a PTX archive
def PTX(file):
    print "\nRepacking PTX Archive: %s" % file
    
    try:
        index_file = open("%s\\%s.index" % (file, file), "r")
    except:
        print "Error Reading %s.index from PTX folder %s" % (file, file)
        return(-1)
    
    files = getFilesPTX(index_file)
    num_files = len(files)
    header = pack("<I", num_files)
    body = ""
    outfile = open("%s.ptx" % (file), "wb")
    
    for i in range(num_files):
        bin_open = open("%s\\%s" % (file, files[i]), "rb")
        bin_str = bin_open.read()
        header += pack("<I", len(bin_str)/1024/2)
        body += bin_str
    
    header += ("00000000".decode("hex"))*(511-num_files) #cushion
    outfile.write(header+body)
    return 0

def main():
    print "BETA PTX PYTHON REPACKER\nDMC3 Modding"
    
    if len(sys.argv) < 2:
        print "Usage: %s [folder]" % sys.argv[0]
        return(-1)
    else:
        PTX(sys.argv[1])
    return(0)

main()