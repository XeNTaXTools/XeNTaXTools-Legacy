import newGameLib
from newGameLib import *
import Blender	

def getValue(type,g):
	global tabCount
	value=None
	if type==1:value=g.i(1)[0]
	elif type==2:value=g.f(1)[0]
	elif type==6:pass#animation file
	elif type==7:pass#model file
	elif type==8:pass#mesh section !
	elif type==9:tabCount+=4
	elif type==10:tabCount-=4
	elif type==3:value=g.word(g.H(1)[0])
	return value	

def getValues(count,g):
	valueList=[]
	for m in range(count):
		type=g.B(1)[0]
		value=getValue(type,g)
		valueList.append(value)	
	return valueList	
	

def d3dmeshParser(filename,g):
	vertCount=0
	valueList=getValues(22,g)
	vertCount=valueList[3]
	mesh=Mesh()	
	meshList.append(mesh)	
	for m in range(vertCount):
		mesh.vertPosList.append(g.f(3))
		g.f(3)
		mesh.vertUVList.append(g.f(2))
	count=getValues(1,g)[0]
	for k in range(count):
		mat=Mat()
		mesh.matList.append(mat)
		valueList=getValues(3,g)
		faceCount=valueList[2]
		for m in range(faceCount):
			mesh.faceList.append(g.H(3))
			mesh.matIDList.append(k)
		type=g.B(1)[0]
	g.H(len(mesh.faceList))	
		

def dmeshParser(filename,g):			
			
	valueList=getValues(7,g)
	vertCount=valueList[2]
	vertType=valueList[5]			
			
	mesh=Mesh()	
	skin=Skin()
	mesh.skinList.append(skin)
	meshList.append(mesh)	
	for m in range(vertCount):
		if vertType==1034:valueList=getValues(8,g)
		if vertType==3082:valueList=getValues(10,g)
		mesh.vertPosList.append(valueList[:3])
		mesh.vertUVList.append(valueList[6:8])
		count=getValues(1,g)[0]
		mesh.skinIndiceList.append([])
		mesh.skinWeightList.append([])
		for k in range(count):#weights
			valueList=getValues(2,g)
			mesh.skinIndiceList[-1].append(valueList[0])
			mesh.skinWeightList[-1].append(valueList[1])
	count=getValues(1,g)[0]
	for k in range(count):
		mat=Mat()
		mesh.matList.append(mat)
		valueList=getValues(3,g)
		faceCount=valueList[2]
		for m in range(faceCount):
			mesh.faceList.append(g.H(3))
			mesh.matIDList.append(k)
		type=g.B(1)[0]
		
	type=g.B(1)[0]
	g.H(len(mesh.faceList))	
	
	
def getBones(g):
	while(True):
		if g.tell()==g.fileSize():break
		type=g.B(1)[0]
		value=getValue(type,g)
		if type==10 and tabCount==0:break
		if type==9:
			bone=Bone()
			skeleton.boneList.append(bone)
			bone.name=getValue(g.B(1)[0],g)[-25:]
			parentList[tabCount/4]=bone.name
			bone.ID=getValue(g.B(1)[0],g)
			m11,m12,m13,m14=getValue(g.B(1)[0],g),getValue(g.B(1)[0],g),getValue(g.B(1)[0],g),getValue(g.B(1)[0],g)
			m21,m22,m23,m24=getValue(g.B(1)[0],g),getValue(g.B(1)[0],g),getValue(g.B(1)[0],g),getValue(g.B(1)[0],g)
			m31,m32,m33,m34=getValue(g.B(1)[0],g),getValue(g.B(1)[0],g),getValue(g.B(1)[0],g),getValue(g.B(1)[0],g)
			bone.rotMatrix=Matrix([m11,m12,m13],[m21,m22,m23],[m31,m32,m33]).invert().resize4x4()
			bone.posMatrix=VectorMatrix([m14,m24,m34])
			bone.childCount=getValue(g.B(1)[0],g)			
			if tabCount/4-1>0:bone.parentName=parentList[tabCount/4-1]
		
	

def mdlParser(filename,g):
	global tabCount,skeleton,parentList,meshList
	parentList={}	
	meshList=[]
	skeleton=Skeleton()
	skeleton.BONESPACE=True
	skeleton.NICE=True	
	tabCount=0
	getBones(g)
	skeleton.draw()
	getValue(g.B(1)[0],g)
	meshCount=getValue(g.B(1)[0],g)
	for m in range(meshCount):
		meshName=getValue(g.B(1)[0],g)
		print 'meshName:',meshName
		meshType=getValue(g.B(1)[0],g)
		if meshType=="d3dmesh":
			d3dmeshParser(filename,g)
			getValue(g.B(1)[0],g)
			meshList[m].name=meshName
			meshList[m].type=meshType
		elif meshType=="dmesh":
			dmeshParser(filename,g)
			meshList[m].name=meshName
			meshList[m].type=meshType
		else:
			break	
		#break
		
	getValue(g.B(1)[0],g)
	meshCount=getValue(g.B(1)[0],g)
	for m in range(meshCount):
		meshName=getValue(g.B(1)[0],g)
		print 'meshName:',meshName
		boneName=getValue(g.B(1)[0],g)[-25:]
		values=getValues(13,g)
		#print values
		for mesh in meshList:
			if mesh.name==meshName:
				if mesh.type=="d3dmesh":
					skin=Skin()
					mesh.skinList.append(skin)
					for n in range(len(mesh.vertPosList)):
						mesh.skinGroupList.append([boneName])
						mesh.skinWeightList.append([1,0])
					mesh.BINDSKELETON=skeleton.name
					mesh.draw()
					mesh.object.setMatrix(skeleton.object.getData().bones[boneName].matrix["ARMATURESPACE"])
				if mesh.type=="dmesh":
					mesh.boneNameList=skeleton.boneNameList
					mesh.BINDSKELETON=skeleton.name
					mesh.draw()
		
		
def animParser(filename,g):
	global tabCount	
	
	action=Action()
	action.BONESORT=True
	action.BONESPACE=True
	
	
	tabCount=0
	values=getValues(10,g)	
	action.name=values[2]
	#print values
	boneCount=values[9]
	for n in range(boneCount):
		bone=ActionBone()
		action.boneList.append(bone)
		values=getValues(3,g)
		bone.name=values[1]
		posFrameCount=getValues(1,g)[0]
		for m in range(posFrameCount):
			values=getValues(4,g)
			bone.posFrameList.append(values[0]/192)
			bone.posKeyList.append(VectorMatrix(values[1:]))
		rotFrameCount=getValues(1,g)[0]
		for m in range(rotFrameCount):
			values=getValues(5,g)
			if values[1:]!=[0.0,0.0,0.0,0.0]:
				bone.rotFrameList.append(values[0]/192)
				x=values[1]
				y=values[2]
				z=values[3]
				a=degrees(values[4])
				bone.rotKeyList.append(Quaternion(a,(x,y,z)).toMatrix().invert().resize4x4())
			else:				
				bone.rotKeyList.append(Matrix().invert().resize4x4())
		scaleFrameCount=getValues(1,g)[0]
		for m in range(scaleFrameCount):
			values=getValues(4,g)
		values=getValues(1,g)	
		#print values
	action.draw()
	action.setContext()
	
def Parser(filename):
	print '='*70
	print filename
	print '='*70
	ext=filename.split('.')[-1].lower()	
	
	if ext=='mdl_bin':
		file=open(filename,'rb')
		g=BinaryReader(file)
		mdlParser(filename,g)
		file.close()
	
	if ext=='anim_bin':
		file=open(filename,'rb')
		g=BinaryReader(file)
		animParser(filename,g)
		file.close()
		
 
	
Blender.Window.FileSelector(Parser,'import','El Matador files: *.mdl_bin - model, *.anim_bin - action clip') 
	