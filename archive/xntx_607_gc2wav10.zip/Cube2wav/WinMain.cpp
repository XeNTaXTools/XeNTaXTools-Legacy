/*********************************************************************

        Nintendo GameCube ADPCM Decoder for Windows
        Author: Shinji Chiba <ch3@mail.goo.ne.jp>

*********************************************************************/
#include "Cube2wav.h"
#include "resource.h"

DWORD sf = 44100;
int ch = STEREO;

LRESULT CALLBACK Settings( HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam )
{
	switch( message )
	{
	case WM_COMMAND:
		switch( LOWORD( wParam ) )
		{
		case IDOK:
			{
				char str[16] = "";
				if ( IsDlgButtonChecked( hDlg, IDC_MONO ) == BST_CHECKED ) ch = MONO;
				else ch = STEREO;
				GetWindowText( GetDlgItem( hDlg, IDC_SF ), str, 15 );
				sf = (DWORD) atoi( str );
				EndDialog( hDlg, IDOK );
			}
			return TRUE;
		case IDCANCEL:
			EndDialog( hDlg, IDCANCEL );
			return TRUE;
		}
		break;
	case WM_INITDIALOG:
		{
			char str[16];
			wsprintf( str, "%d", sf );
			SetWindowText( GetDlgItem( hDlg, IDC_SF ), str );
			CheckRadioButton( hDlg, IDC_MONO, IDC_STEREO, ch + IDC_MONO - MONO );
		}
		return TRUE;
	}
	return FALSE;
}

BOOL Browse( HINSTANCE hInst, char *lpstrOpenFile, char *filter, BOOL readwrite )
{
	char szFile[MAX_PATH];
	char *lpstrOpenTmp;
	OPENFILENAME openfilename;
	BOOL retVal;

	lpstrOpenTmp = new char[MAX_PATH];

	ZeroMemory( lpstrOpenTmp, MAX_PATH );
	ZeroMemory( &openfilename, sizeof(OPENFILENAME) );
	openfilename.lStructSize = sizeof(OPENFILENAME);
	openfilename.hwndOwner = NULL;
	openfilename.hInstance = hInst;
	openfilename.lpstrFilter = filter;
	openfilename.nFilterIndex = 1;
	openfilename.lpstrFileTitle = szFile;
	openfilename.lpstrFile = lpstrOpenTmp;
	openfilename.nMaxFile = MAX_PATH;
	openfilename.lpstrFile = lpstrOpenFile;
	if ( readwrite )
	{
		openfilename.Flags = OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT;
		openfilename.lpstrDefExt = "wav";
		if ( retVal = GetSaveFileName( &openfilename ) ) strcpy( lpstrOpenFile, openfilename.lpstrFile );
	}
	else
	{
		openfilename.Flags = OFN_HIDEREADONLY | OFN_FILEMUSTEXIST;
		openfilename.lpstrDefExt = "adp";
		if ( retVal = GetOpenFileName( &openfilename ) ) strcpy( lpstrOpenFile, openfilename.lpstrFile );
	}
	delete lpstrOpenTmp;
	return retVal;
}

DWORD writeWaveHeader( HANDLE hOutFile, int c_size, DWORD fs, int ch )
{ 
	WAVEHEADER waveheader;
	DWORD dw;
	waveheader.riff = _FOURCC( 'RIFF' );
	waveheader.totalsize = c_size + (sizeof(WAVEHEADER) - 8);
	waveheader.wave = _FOURCC( 'WAVE' );
	waveheader.fmt = _FOURCC( 'fmt ' );
	waveheader.fmtsize = sizeof(WAVEFORMAT) + sizeof(WORD);
	waveheader.wfmt.wFormatTag = WAVE_FORMAT_PCM;
	waveheader.wfmt.nChannels = ch;
	waveheader.wfmt.nSamplesPerSec = fs;
	waveheader.wfmt.nAvgBytesPerSec = fs * _16BIT_DIV_8 * ch;
	waveheader.wfmt.nBlockAlign = _16BIT_DIV_8 * ch;
	waveheader.wBitsPerSample = _16BIT;
	waveheader.data = _FOURCC( 'data' );
	waveheader.datasize = c_size;
	SetFilePointer( hOutFile, 0, NULL, FILE_BEGIN );
	WriteFile( hOutFile, &waveheader, sizeof(WAVEHEADER), &dw, NULL );
	return dw;
}

int AnalyzeCommandLine( char *lpszCmd, char *szFile )
{
	int i, j;
	BOOL flag = FALSE;
	for( i = j = 0; ; i++ )
	{
		if ( lpszCmd[i] == '\0' )
		{
			szFile[j] = '\0';
			break;
		}
		if ( lpszCmd[i] == '\"' )
		{
			if ( flag ) flag = FALSE;
			else flag = TRUE;
			continue;
		}
		if ( lpszCmd[i] == ' ' && flag == FALSE )
		{
			szFile[j] = '\0';
			for( ; ; )
			{
				i++;
				if ( lpszCmd[i] != ' ' ) break;
			}
			break;
		}
		szFile[j++] = lpszCmd[i];
	}
	return i;
}

int APIENTRY WinMain( HINSTANCE hInstance, HINSTANCE, LPSTR lpszCmd, int )
{
	char szFile[MAX_PATH] = "";
	CUBE2WAV *cube2wav;
	HANDLE hInFile, hOutFile;
	DWORD dw;
	BOOL retVal;
	int analysis = 0;

	if ( lpszCmd[analysis] )
	{
		analysis = AnalyzeCommandLine( &lpszCmd[analysis], szFile );
		retVal = TRUE;
	}
	else retVal = Browse( hInstance, szFile, "GameCube ADPCM (*.adp)\0*.adp\0", FALSE );
	if ( retVal )
	{
		if ( hInFile = CreateFile( szFile, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL ) )
		{
			_splitpath( szFile, NULL, NULL, szFile, NULL );
			strcat( szFile, ".wav" );
			if ( lpszCmd[analysis] )
			{
				analysis += AnalyzeCommandLine( &lpszCmd[analysis], szFile );
				retVal = TRUE;
			}
			else retVal = Browse( hInstance, szFile, "Windows Wave (*.wav)\0*.wav\0", TRUE );
			if ( retVal )
			{
				retVal = FALSE;
				if ( lpszCmd[analysis] )
				{
					char str[256];
					analysis += AnalyzeCommandLine( &lpszCmd[analysis], str );
					sf = atoi( str );
					if ( lpszCmd[analysis] )
					{
						AnalyzeCommandLine( &lpszCmd[analysis], str );
						ch = atoi( str );
						if ( ch > STEREO ) ch = STEREO;
						else if ( ch < MONO ) ch = MONO;
					}
					retVal = TRUE;
				}
				else if ( DialogBox( hInstance, "Cube2wav", NULL, (DLGPROC) Settings ) == IDOK ) retVal = TRUE;
				if ( retVal )
				{
					if ( hOutFile = CreateFile( szFile, GENERIC_WRITE, FILE_SHARE_WRITE, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL ) )
					{
						cube2wav = new CUBE2WAV;
						WriteFile( hOutFile, WinMain, sizeof(WAVEHEADER), &dw, NULL );
						dw = cube2wav->DecodeFile( hInFile, hOutFile, ch );
						writeWaveHeader( hOutFile, dw, sf, ch );
						CloseHandle( hOutFile );
						delete cube2wav;
					}
				}
			}
			CloseHandle( hInFile );
		}
	}
	return 0;
}
