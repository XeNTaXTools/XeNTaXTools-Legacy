/*********************************************************************

        Nintendo GameCube ADPCM Decoder Sub Class
        Author: Shinji Chiba <ch3@mail.goo.ne.jp>

*********************************************************************/
#ifndef __CUBE2WAV_H__
#define __CUBE2WAV_H__

#include "NGCADPCM.H"

#define _16BIT			16
#define	_16BIT_DIV_8	(_16BIT / 8)
#define _FOURCC(A)		((A >> 24) | ((A >> 8) & 0xff00) | ((A & 0xff00) << 8) | (A << 24))

typedef struct {
	DWORD riff;
	DWORD totalsize;
	DWORD wave;
	DWORD fmt;
	DWORD fmtsize;
	WAVEFORMAT wfmt;
	WORD wBitsPerSample;
	DWORD data;
	DWORD datasize;
} WAVEHEADER;

class CUBE2WAV: public NGCADPCM
{
public:
	CUBE2WAV();
	DWORD DecodeFile( HANDLE, HANDLE, int );
};

#endif
