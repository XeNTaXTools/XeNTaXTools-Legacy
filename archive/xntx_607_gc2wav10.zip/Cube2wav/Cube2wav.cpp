/*********************************************************************

        Nintendo GameCube ADPCM Decoder Sub Class
        Author: Shinji Chiba <ch3@mail.goo.ne.jp>

*********************************************************************/
#include "Cube2wav.h"

CUBE2WAV::CUBE2WAV()
{
}

DWORD CUBE2WAV::DecodeFile( HANDLE hInFile, HANDLE hOutFile, int nch )
{
	BYTE adpcm[ONE_BLOCK_SIZE];
	short pcm[SAMPLES_PER_BLOCK * STEREO];
	DWORD pcmsize, dw;

	InitFilter();
	pcmsize = 0;
	nch = (nch - MONO) & MONO;

	for( ; ; )
	{
		ReadFile( hInFile, adpcm, ONE_BLOCK_SIZE, &dw, NULL );
		if ( dw < ONE_BLOCK_SIZE ) break;
		DecodeBlock( pcm, adpcm, nch );
		WriteFile( hOutFile, pcm, _16BIT_DIV_8 * STEREO * SAMPLES_PER_BLOCK, &dw, NULL );
		pcmsize += dw;
	}
	return pcmsize;
}
