#include <windows.h>
#include <stdio.h>
#include <vector>
#include "Libpng/png.h"
#include "zLib/zlib.h"
#include "AtexAsm.h"
#include <GdiPlus.h>	

#pragma pack(1)

union RGBA
{
	unsigned char c[4];
	struct { unsigned char r,g,b,a; }; 
	unsigned int dw;
}; 

union DXT1Color
{
	struct
	{
		unsigned	r1 :5,
					g1 :6,
					b1 :5,
					r2 :5,
					g2 :6,
					b2 :5;
	};
	struct { unsigned short c1,c2;};
};

struct DXT5Alpha
{
	unsigned char a0,a1;
	__int64 table;
};

void Dump_Image(unsigned char *Data, int XRes, int YRes, bool Alpha, char *Filename)
{
	
	FILE *fp = fopen(Filename, "w+b");
	if (!fp) { printf("ERROR: File %s could not be opened for writing\n", Filename); return; }
	
	png_structp png_ptr;
	png_infop info_ptr;
	png_bytep * row_pointers;

	row_pointers=new png_bytep[YRes];
	unsigned char *img=(unsigned char*)Data;
	for (int x=0; x<YRes; x++)
	{
		row_pointers[x]=new unsigned char[XRes*4];
		memcpy(row_pointers[x],img,XRes*4);
		if (!Alpha) for (int y=0; y<XRes; y++) row_pointers[x][y*4+3]=255;
		img+=XRes*4;
	}


	png_ptr = png_create_write_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
	if (!png_ptr) { printf("ERROR: [write_png_file] png_create_write_struct failed\n"); fclose(fp); return; }
	info_ptr = png_create_info_struct(png_ptr);
	if (!info_ptr) { printf("ERROR: [write_png_file] png_create_info_struct failed\n"); fclose(fp); return; }
	if (setjmp(png_jmpbuf(png_ptr))) { printf("ERROR: [write_png_file] Error during init_io\n"); fclose(fp); return; }
	png_init_io(png_ptr, fp);
	if (setjmp(png_jmpbuf(png_ptr))) { printf("ERROR: [write_png_file] Error during writing header\n"); fclose(fp); return; }
	png_set_IHDR(png_ptr, info_ptr, XRes, YRes,8, PNG_COLOR_TYPE_RGB_ALPHA, PNG_INTERLACE_NONE,PNG_COMPRESSION_TYPE_DEFAULT, PNG_FILTER_TYPE_BASE);
	png_write_info(png_ptr, info_ptr);
	if (setjmp(png_jmpbuf(png_ptr))) { printf("ERROR: [write_png_file] Error during writing bytes\n"); fclose(fp); return; }
	png_write_image(png_ptr, row_pointers);
	if (setjmp(png_jmpbuf(png_ptr))) { printf("ERROR: [write_png_file] Error during end of write\n"); fclose(fp); return; }
	png_write_end(png_ptr, NULL);
	png_destroy_write_struct(&png_ptr,&info_ptr);
	for (int y=0; y<YRes; y++) delete[] row_pointers[y];
	delete[] row_pointers;

	fclose(fp);

	printf("Success!\n",Filename);
}


RGBA *ProcessDXT1(unsigned char *data,int xr, int yr)
{
	DXT1Color *coltable=new DXT1Color[xr*yr/16];
	unsigned int *blocktable=new unsigned int[xr*yr/16];

	unsigned int *d=(unsigned int*)data;

	for (int x=0; x<xr*yr/16; x++)
	{
		coltable[x]=*(DXT1Color*)&d[x*2];
		blocktable[x]=d[x*2+1];
	}


	RGBA *image=new RGBA[xr*yr];
	memset(image,0,xr*yr*4);

	int p=0;
	for (int y=0; y<yr/4; y++)
		for (int x=0; x<xr/4; x++)
		{
			RGBA ctbl[4]; memset(ctbl,255,16);
			DXT1Color c=coltable[p];
			ctbl[0].r=c.r1<<3;
			ctbl[0].g=c.g1<<2;
			ctbl[0].b=c.b1<<3;
			ctbl[1].r=c.r2<<3;
			ctbl[1].g=c.g2<<2;
			ctbl[1].b=c.b2<<3;

			if (c.c1>c.c2)
			{
				ctbl[2].r=(int)((ctbl[0].r*2+ctbl[1].r)/3.);
				ctbl[2].g=(int)((ctbl[0].g*2+ctbl[1].g)/3.);
				ctbl[2].b=(int)((ctbl[0].b*2+ctbl[1].b)/3.);
				ctbl[3].r=(int)((ctbl[0].r+ctbl[1].r*2)/3.);
				ctbl[3].g=(int)((ctbl[0].g+ctbl[1].g*2)/3.);
				ctbl[3].b=(int)((ctbl[0].b+ctbl[1].b*2)/3.);
			}
			else
			{
				ctbl[2].r=(int)((ctbl[0].r+ctbl[1].r)/2.);
				ctbl[2].g=(int)((ctbl[0].g+ctbl[1].g)/2.);
				ctbl[2].b=(int)((ctbl[0].b+ctbl[1].b)/2.);
				ctbl[3].r=0;
				ctbl[3].g=0;
				ctbl[3].b=0;
				ctbl[3].a=0;
			}

			unsigned int t=blocktable[p];

			for (int b=0; b<4; b++)
				for (int a=0; a<4; a++)
				{
					image[x*4+a+(y*4+b)*xr]=ctbl[t&3];
					t=t>>2;
				}

			p++;
		}    

	delete[] coltable;
	delete[] blocktable;
	return image;
}

RGBA *ProcessDXT3(unsigned char *data,int xr, int yr)
{
	DXT1Color *coltable=new DXT1Color[xr*yr/16];
	__int64 *alphatable=new __int64[xr*yr/16];
	unsigned int *blocktable=new unsigned int[xr*yr/16];

	unsigned int *d=(unsigned int*)data;

	for (int x=0; x<xr*yr/16; x++)
	{
		alphatable[x]=((__int64*)d)[x*2];
		coltable[x]=*(DXT1Color*)&d[x*4+2];
		blocktable[x]=d[x*4+3];
	}


	RGBA *image=new RGBA[xr*yr];
	memset(image,0,xr*yr*4);

	int p=0;
	for (int y=0; y<yr/4; y++)
		for (int x=0; x<xr/4; x++)
		{
			RGBA ctbl[4]; memset(ctbl,255,16);
			DXT1Color c=coltable[p];
			ctbl[0].r=c.r1<<3;
			ctbl[0].g=c.g1<<2;
			ctbl[0].b=c.b1<<3;
			ctbl[1].r=c.r2<<3;
			ctbl[1].g=c.g2<<2;
			ctbl[1].b=c.b2<<3;

			ctbl[2].r=(int)((ctbl[0].r*2+ctbl[1].r)/3.);
			ctbl[2].g=(int)((ctbl[0].g*2+ctbl[1].g)/3.);
			ctbl[2].b=(int)((ctbl[0].b*2+ctbl[1].b)/3.);
			ctbl[3].r=(int)((ctbl[0].r+ctbl[1].r*2)/3.);
			ctbl[3].g=(int)((ctbl[0].g+ctbl[1].g*2)/3.);
			ctbl[3].b=(int)((ctbl[0].b+ctbl[1].b*2)/3.);

			unsigned int t=blocktable[p];
			__int64 k=alphatable[p];

			for (int b=0; b<4; b++)
				for (int a=0; a<4; a++)
				{
					image[x*4+a+(y*4+b)*xr]=ctbl[t&3];
					t=t>>2;
					image[x*4+a+(y*4+b)*xr].a=(unsigned char)((k&15)<<4);
					k=k>>4;
				}

				p++;
		}    

	delete[] coltable;
	delete[] blocktable;
	delete[] alphatable;
	return image;
}

RGBA *ProcessDXT5(unsigned char *data,int xr, int yr)
{
	DXT1Color *coltable=new DXT1Color[xr*yr/16];
	DXT5Alpha *alphatable=new DXT5Alpha[xr*yr/16];
	unsigned int *blocktable=new unsigned int[xr*yr/16];

	unsigned int *d=(unsigned int*)data;

	for (int x=0; x<xr*yr/16; x++)
	{
		alphatable[x]=*(DXT5Alpha*)&(((__int64*)d)[x*2]);
		coltable[x]=*(DXT1Color*)&d[x*4+2];
		blocktable[x]=d[x*4+3];
	}


	RGBA *image=new RGBA[xr*yr];
	memset(image,0,xr*yr*4);

	int p=0;
	for (int y=0; y<yr/4; y++)
		for (int x=0; x<xr/4; x++)
		{
			RGBA ctbl[4]; memset(ctbl,255,16);
			DXT1Color c=coltable[p];
			ctbl[0].r=c.r1<<3;
			ctbl[0].g=c.g1<<2;
			ctbl[0].b=c.b1<<3;
			ctbl[1].r=c.r2<<3;
			ctbl[1].g=c.g2<<2;
			ctbl[1].b=c.b2<<3;

			ctbl[2].r=(int)((ctbl[0].r*2+ctbl[1].r)/3.);
			ctbl[2].g=(int)((ctbl[0].g*2+ctbl[1].g)/3.);
			ctbl[2].b=(int)((ctbl[0].b*2+ctbl[1].b)/3.);
			ctbl[3].r=(int)((ctbl[0].r+ctbl[1].r*2)/3.);
			ctbl[3].g=(int)((ctbl[0].g+ctbl[1].g*2)/3.);
			ctbl[3].b=(int)((ctbl[0].b+ctbl[1].b*2)/3.);

			unsigned char atbl[8];
			DXT5Alpha l=alphatable[p];

			atbl[0]=l.a0;
			atbl[1]=l.a1;

			if (l.a0>l.a1)
			{
				for (int z=0; z<6; z++)
					atbl[z+2]=((6-z)*l.a0+(z+1)*l.a1)/7;
			}
			else
			{
				for (int z=0; z<4; z++)
					atbl[z+2]=((4-z)*l.a0+(z+1)*l.a1)/5;
				atbl[6]=0;
				atbl[7]=255;
			}

			unsigned int t=blocktable[p];
			__int64 k=alphatable[p].table;

			for (int b=0; b<4; b++)
				for (int a=0; a<4; a++)
				{
					image[x*4+a+(y*4+b)*xr]=ctbl[t&3];
					t=t>>2;
					image[x*4+a+(y*4+b)*xr].a=atbl[k&7];
					k=k>>3;
				}

				p++;
		}    

	delete[] coltable;
	delete[] blocktable;
	delete[] alphatable;
	return image;
}

//GW2 DXTA (Block Compression 4)
RGBA *ProcessBC4(unsigned char *data,int xr, int yr)
{
	DXT5Alpha *redtable=new DXT5Alpha[xr*yr/16];

	unsigned int *d=(unsigned int*)data;

	for (int x=0; x<xr*yr/16; x++)
	{
		redtable[x]=*(DXT5Alpha*)&(((__int64*)d)[x]);
	}


	RGBA *image=new RGBA[xr*yr];
	memset(image,0,xr*yr*4);

	int p=0;
	for (int y=0; y<yr/4; y++)
		for (int x=0; x<xr/4; x++)
		{
			//Read channel
			unsigned char rtbl[8];
			DXT5Alpha l1=redtable[p];

			rtbl[0]=l1.a0;
			rtbl[1]=l1.a1;

			if (l1.a0>l1.a1)
			{
				for (int z=0; z<6; z++) {
					rtbl[z+2]=((6-z)*l1.a0+(z+1)*l1.a1)/7;
				}
			}
			else
			{
				for (int z=0; z<4; z++) {
					rtbl[z+2]=((4-z)*l1.a0+(z+1)*l1.a1)/5;
				}
				rtbl[6]=0;
				rtbl[7]=255;
			}

			//Write to image
			__int64 k1=redtable[p].table;

			for (int b=0; b<4; b++)
				for (int a=0; a<4; a++)
				{
					image[x*4+a+(y*4+b)*xr].b= 0; 
					image[x*4+a+(y*4+b)*xr].g= 0;
					image[x*4+a+(y*4+b)*xr].r= 0;
					image[x*4+a+(y*4+b)*xr].a = rtbl[k1&7];
					k1=k1>>3;
				}

				p++;
		}    
	delete[] redtable;
	return image;
}

//GW2 3DCX (Block Compression 5)
RGBA *Process3DCX(unsigned char *data,int xr, int yr)
{
	DXT5Alpha *redtable=new DXT5Alpha[xr*yr/16];
	DXT5Alpha *greentable=new DXT5Alpha[xr*yr/16];

	unsigned int *d=(unsigned int*)data;

	for (int x=0; x<xr*yr/16; x++)
	{
		redtable[x]=*(DXT5Alpha*)&(((__int64*)d)[x*2]);
		greentable[x]=*(DXT5Alpha*)&(((__int64*)d)[x*2+1]);
	}


	RGBA *image=new RGBA[xr*yr];
	memset(image,0,xr*yr*4);

	int p=0;
	for (int y=0; y<yr/4; y++)
		for (int x=0; x<xr/4; x++)
		{
			//Read red channel
			unsigned char rtbl[8];
			DXT5Alpha l1=redtable[p];

			rtbl[0]=l1.a0;
			rtbl[1]=l1.a1;

			if (l1.a0>l1.a1)
			{
				for (int z=0; z<6; z++)
					rtbl[z+2]=((6-z)*l1.a0+(z+1)*l1.a1)/7.0f;
			}
			else
			{
				for (int z=0; z<4; z++)
					rtbl[z+2]=((4-z)*l1.a0+(z+1)*l1.a1)/5.0f;
				rtbl[6]=0.0f;
				rtbl[7]=1.0f;
			}
			//Read green channel
			unsigned char gtbl[8];
			DXT5Alpha l2=greentable[p];

			gtbl[0]=l2.a0;
			gtbl[1]=l2.a1;

			if (l2.a0>l2.a1)
			{
				for (int z=0; z<6; z++)
					gtbl[z+2]=((6-z)*l2.a0+(z+1)*l2.a1)/7.0f;
			}
			else
			{
				for (int z=0; z<4; z++)
					gtbl[z+2]=((4-z)*l2.a0+(z+1)*l2.a1)/5.0f;
				gtbl[6]=0.0f;
				gtbl[7]=1.0f;
			}

			//Write to image
			__int64 k1=redtable[p].table;
			__int64 k2=greentable[p].table;

			float varx = 0.0f;
			float vary = 0.0f;
			float varz = 0.0f;

			for (int b=0; b<4; b++)
				for (int a=0; a<4; a++)
				{
					//Bugfix: Apparently the struct is incorrect. red and blue were swapped in the RGBA struct.
					//Inverted all 3 channels
					//Channels used are red and green
					//ANET has swapped the red and green channels as well

					//A default pixel should be [0.5, 0.5, 1]
					
					//GREEN
					//image[x*4+a+(y*4+b)*xr].b=(1.0f-rtbl[k1&7])*255; //ori
					image[x*4+a+(y*4+b)*xr].g=(1.0f - (1.0f - rtbl[k1&7]))*255; 
					varx = (image[x*4+a+(y*4+b)*xr].g / 255.0f) * 2.0f - 1.0f;
					k1=k1>>3;

					//RED
					//image[x*4+a+(y*4+b)*xr].g=(1.0f-gtbl[k2&7])*255; //ori
					image[x*4+a+(y*4+b)*xr].b=(1.0f - gtbl[k2&7])*255;
					vary = (image[x*4+a+(y*4+b)*xr].b / 255.0f) * 2.0f - 1.0f;
					k2=k2>>3;
					
					//BLUE
					varz = sqrt(1.0f - varx*varx - vary*vary);
					image[x*4+a+(y*4+b)*xr].r = ((1.0f + varz) * 0.5f) * 255;

					//ALPHA
					image[x*4+a+(y*4+b)*xr].a=255;
				}

				p++;
		}    
	delete[] redtable;
	delete[] greentable;
	return image;
}

char fname[2048];

void ProcessImageFile(char *filename)
{
	int size;
	//Read file
	FILE *file = fopen(filename, "rb");
	if (!file)
	{
		printf("Error opening file %s - file not found\n",filename);
		return;
	}
	fseek(file, 0, SEEK_END);
	size = ftell(file); //Get size
	rewind (file);

	unsigned char *img = new unsigned char[size+1];
	fread(img, size, 1, file);
	if (!img)
	{
		printf("Error opening file %s\n",filename);
		return;
	}

	int id1,id2;
	id1=((unsigned int*)img)[0];
	id2=((unsigned int*)img)[1];

	

	//if (id1!='XTTA' && id1!='XETA' && id1!='PETA' && id1!='UETA' && id1!='CETA' && id1!='TETA')
	if ((id1&0xFFFFFF)!='TTA' && (id1&0xFFFFFF)!='ETA')
	{
		printf("File NOT an ATEX/ATTX/ATEP/ATEU/ATEC/ATET file!\n");
		//Cleanup
		fclose(file);
		delete[] img;
		return;
	}

	if ((id2&0xffffff)!='TXD' && (id2&0xffffff)!='CD3')
	{
		printf("File NOT DXT compressed!\n");
		//Cleanup
		fclose(file);
		delete[] img;
		return;
	}

	int cmptype=id2>>24;

	SImageDescriptor r;
	r.xres=*(unsigned short*)(img+8);
	r.yres=*(unsigned short*)(img+10);
	r.Data=img;
	r.imageformat=0xf;
	r.a=size;
	r.b=6;
	r.c=0;

	RGBA *output=new RGBA[r.xres*r.yres];
	r.image=(unsigned char*)output;

	RGBA *image;
	if (id1=='XTTA' || id1=='XETA' || id1=='PETA' || id1=='UETA') {
	switch (cmptype)
	{
	case '1':
		AtexDecompress((unsigned int*)img,size,0xf,r,(unsigned int*)output);
		image=ProcessDXT1((unsigned char*)output,r.xres,r.yres);
		break;
	case '2':
	case '3':
	case 'N':
		AtexDecompress((unsigned int*)img,size,0x11,r,(unsigned int*)output);
		image=ProcessDXT3((unsigned char*)output,r.xres,r.yres);
		break;
	case '4':
	case '5':
		AtexDecompress((unsigned int*)img,size,0x13,r,(unsigned int*)output);
		image=ProcessDXT5((unsigned char*)output,r.xres,r.yres);
		break;
	case 'L':
		AtexDecompress((unsigned int*)img,size,0x12,r,(unsigned int*)output);
		image=ProcessDXT5((unsigned char*)output,r.xres,r.yres);
		for (int x=0; x<r.xres*r.yres; x++)
		{
			image[x].r=(image[x].r*image[x].a)/255;
			image[x].g=(image[x].g*image[x].a)/255;
			image[x].b=(image[x].b*image[x].a)/255;
		}
		break;
	case 'A': //DXTA
		AtexDecompress((unsigned int*)img,size,0x14,r,(unsigned int*)output);
		image=ProcessBC4((unsigned char*)output,r.xres,r.yres);
		break;
	case 'X': //3DCX
		AtexDecompress((unsigned int*)img,size,0x13,r,(unsigned int*)output);
		image=Process3DCX((unsigned char*)output,r.xres,r.yres);
		break;
	default:
		printf("Unsupported compression format! (%c)\n",cmptype);
		//Exit, do not dump
		fclose(file);
		delete[] output;
		delete[] img;
		return;
	}
	}

	for (int z=0; z<r.xres*r.yres; z++)
	{
		int k=image[z].r;
		image[z].r=image[z].b;
		image[z].b=k;
	}
	Dump_Image((unsigned char*)image,r.xres,r.yres,true,fname);
	fclose(file);
	delete[] image;
	delete[] output;
	delete[] img;
}

int GetFileList(const char *searchkey, std::vector<std::string> &list)
{
    WIN32_FIND_DATA fd;
	if (strlen(searchkey) == 0)
		return 0;
	//Convert searchkey to LPCWSTR type
	int len = strlen(searchkey)+1;
	wchar_t *wText = new wchar_t[len];
	memset(wText,0,len);
	::MultiByteToWideChar(CP_ACP, NULL, searchkey, -1, wText,len );

	//Get directory
	/*
	char *dir;
	if (strrchr(searchkey,'\\')) {
		int dirsize = strrchr(searchkey,'\\')-searchkey+2; //include backslash and null terminator
		dir = new char[dirsize];
		memset(dir,0,dirsize);
		strncpy(dir,searchkey,dirsize-1); //Have null terminator
	}
	*/

    HANDLE h = FindFirstFile(wText,&fd);
    if(h == INVALID_HANDLE_VALUE)
    {
        return 0; // no files found
    }
    while(1)
    {
		//Convert WCHAR to char *
		wchar_t *orig = fd.cFileName;
		size_t origsize = wcslen(orig) + 1;
		const size_t newsize = 256;
		size_t convertedChars = 0;
		char nstring[newsize];
		wcstombs_s(&convertedChars, nstring, origsize, orig, _TRUNCATE);

		//Get full path
		/*
		int fullpathsize = strlen(nstring);
		if (dir) {
			fullpathsize += strlen(dir);
		}
		char *fullpath = new char[fullpathsize];
		memset(fullpath,0,fullpathsize);
		if (dir) {
			strcat(fullpath,dir);
		}
		strcat(fullpath,nstring);
		*/

        list.push_back(nstring);
		//list.push_back(fullpath);
        if(FindNextFile(h, &fd) == FALSE)
            break;
    }
	//delete dir;
    return list.size();
}

void main(int argc, char **argv)
{
	printf("ATEX -> PNG converter\n\n");
	if (argc<=1)
	{
		printf("usage: atex [filename]\n");
		return;
	}

	std::vector<std::string> list;
	int count = GetFileList(argv[1], list);

	if (!count)
	{
		printf("No files matching '%s' were found.\n",argv[1]);
		return;
	}

	int x = 1;
	for(std::vector<std::string>::const_iterator it = list.begin(); it != list.end(); ++it) {
		printf("Processing image %d/%d (%s) ",x++,count,it->c_str());
		sprintf(fname,"%s.png\0",it->c_str());
		ProcessImageFile((char *)it->c_str());
	}

}

