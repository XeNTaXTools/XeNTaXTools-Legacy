This application uses the following libraries:
* libpng (http://libpng.sourceforge.net/)
* zlib (http://www.zlib.net/)

libpng is not bundled with the application due to size constraints.
To add it to the application, download the sources from libpng and place the *.c and *.h files into the Libpng folder.