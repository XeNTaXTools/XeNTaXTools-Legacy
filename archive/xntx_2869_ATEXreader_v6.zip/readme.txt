This tool converts ATEX files into PNG files.

The following types are supported:
* DXT1 (BC1)
* DXT2/DXT3 (BC2)
* DXT4/DXT5 (BC3)
* DXTL (BC3)
* DXTA (BC4)
* 3DC (BC5)


For more information on BC (Block compression), refer to http://msdn.microsoft.com/en-us/library/bb694531%28v=vs.85%29.aspx

The tool must be located in the same folder as the ATEX files.
The resulting PNG files would be placed in the current directory.

To convert more than 1 ATEX file use the following command:

ATEXreader.exe *.atex
