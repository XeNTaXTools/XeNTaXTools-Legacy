!!!!! This is an exe that is modified crudely to view tiled images: palette + image tiles + indices into the image tiles.  This is so far only used for NDS background images.

!!!!! This exe is likely to crash if you put in weird values for tile size and tiled image offsets, use at your own risk!

Made for this thread:
http://forum.xentax.com/viewtopic.php?f=18&t=4291&start=0&st=0&sk=t&sd=a

the bin files are either 4 or 8bit tiled bgd images.

Format as follows:
0x0 is "CHBG"
0x4 is width
0x6 is height
0x8 is flags
0xA is #of tiles (I think)
0x10 is palette (variable size)

after palette is the image indices (width * height)/(tile area, ie: 8*8) in shorts (2 bytes)

after indices is the tiled images array

To set the tiled image offset, look under the graphics menu--there is a new item that lets you set the offset, and this is the only way to set it other than a binding file, no skipping/browsing.
To toggle the tiled image on/off use teh V key.
To add in the tiled image offset, add a line like: "tileoffset = readDWORD(0x20);" to the graphics binding

example:
width : 64
height : 128
8bits
109 tiles
0x10 @ 256 color palette 2bytes/color
0x210 @ image indices (64/8 * 128/8) = 128 = 0x80 => 0x100 bytes
0x310 @ image tiles

