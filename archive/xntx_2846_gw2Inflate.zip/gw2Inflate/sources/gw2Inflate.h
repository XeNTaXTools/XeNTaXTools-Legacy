#ifndef INFLATE_H
#define INFLATE_H 1

#include <stdint.h>

#define DLL_EXPORT __declspec(dllexport)

/** @Inputs:
 *    - i_input: Pointer to the buffer to inflate
 *    - i_inputSize: Size of the input buffer
 *  @Outputs:
 *    - io_outputSize: Pointer to the size of the outputBuffer
 *  @Return:
 *    - Pointer to the outputBuffer, NULL if it failed, client is responsible to free this pointer
 */
uint8_t* DLL_EXPORT inflate(uint32_t* i_input, uint32_t i_inputSize, uint32_t* io_outputSize);

#endif
