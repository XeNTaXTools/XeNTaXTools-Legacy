#  ShumenOL panda_mount.eva importer by Bigchillghost
from inc_noesis import *
import copy

def registerNoesisTypes():
	handle = noesis.register("panda_mount", ".eva")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadModel(handle, noepyLoadModel)
	#noesis.logPopup()
	return 1

#check if it's this type based on the data
def noepyCheckType(data):
	if len(data) < 0x80:
		return 0
	bs = NoeBitStream(data)
	bs.seek(3, NOESEEK_ABS)
	Tag = noeStrFromBytes(bs.readBytes(8), "ASCII")
	if Tag != 'EV_Actor':
		return 0
	return 1

#load the model
def noepyLoadModel(data, mdlList):
	#noesis.logPopup()
	bs = NoeBitStream(data)
	bs.seek(0x15, NOESEEK_ABS)
	totalFrameCount = bs.readInt()
	animTrackCount = bs.readInt()
	for i in range(0, animTrackCount):
		for j in range(0, 2):
			NameLen = bs.readInt()
			animName = noeStrFromBytes(bs.readBytes(NameLen), "ASCII")
		begFrameID = bs.readInt()
		endFrameID = bs.readInt()
		bs.seek(5, NOESEEK_REL)
	# bone info
	boneCount = bs.readInt()
	bones = []
	matList = []
	for i in range(0, boneCount):
		NameLen = bs.readInt()
		boneName = noeStrFromBytes(bs.readBytes(NameLen), "ASCII")
		NameLen = bs.readInt()
		parentName = noeStrFromBytes(bs.readBytes(NameLen), "ASCII")
		bs.seek(1, NOESEEK_REL)
		frameCnt = bs.readInt()
		if frameCnt > 0:
			targetFrame = 0 # 0-142
			bs.seek(targetFrame*0x30, NOESEEK_REL)
			boneMat = NoeMat43.fromBytes(bs.readBytes(48))
			bs.seek((frameCnt-targetFrame-1)*0x30+4, NOESEEK_REL)
			boneMat = boneMat.transpose()
		else:
			boneMat = NoeMat43()
		bs.seek(1, NOESEEK_REL)
		bones.append( NoeBone(i, boneName, boneMat, parentName) )
		matList.append(boneMat)
	
	# meshes
	bs.seek(0x6BDD0, NOESEEK_ABS)
	idxCount = bs.readInt()
	idxData = bs.readBytes(idxCount*2)
	PolygonIndex = rapi.dataToIntList(idxData, idxCount, noesis.RPGEODATA_USHORT, NOE_LITTLEENDIAN)
	bs.seek(0x78602, NOESEEK_ABS)
	Vcount = bs.readInt()
	Positions = []
	Normals = []
	TexCoords = []
	vertWeightList = []
	for i in range(0, Vcount):
		bs.seek(12, NOESEEK_REL) # tangents
		TexCoords.append(NoeVec3([bs.readFloat(), -bs.readFloat(), 0.0]))
		meshCnt = bs.readInt()
		boneID = bs.readUByte()
		bs.seek(4, NOESEEK_REL)
		position = NoeVec3.fromBytes(bs.readBytes(12))
		normal = NoeVec3.fromBytes(bs.readBytes(12))
		bs.seek(2, NOESEEK_REL)
		if meshCnt > 1:
			bs.seek(0x1E, NOESEEK_REL)
		position = matList[boneID]*position
		rotMat = copy.copy(matList[boneID])
		rotMat[3] = NoeVec3((0.0, 0.0, 0.0))
		normal = rotMat*normal
		Positions.append(position)
		Normals.append(normal)
		vertWeightList.append(NoeVertWeight([boneID], [1.0]))
	
	meshes = []
	meshName = rapi.getInputName().split("\\")[-1].split(".")[0]
	mesh = NoeMesh(PolygonIndex, Positions, meshName, meshName)
	mesh.setUVs(TexCoords)
	mesh.setNormals(Normals)
	mesh.weights = vertWeightList
	meshes.append(mesh)
	
	mdl = NoeModel(meshes)
	mdl.setBones(bones)
	mdlList.append(mdl)
	rapi.setPreviewOption("setAngOfs", "0 -90 0")
	
	return 1
