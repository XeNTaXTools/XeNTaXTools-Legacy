from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Backyard Wrestling: Don't try this at home  [PS2]", ".tex")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    if bs.readBytes(4) != b'\x50\x32\x4e\x00': return 0
    return 1

def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.seek(0x10)
    imgWidth = bs.readUInt()
    print(hex(imgWidth), ":width")
    imgHeight = bs.readUInt()
    print(hex(imgHeight), ":height")
    bitsperpixel = bs.readUInt()
    print(bitsperpixel, ":bitsperpixel")
    bs.seek(0x24)
    datasize = bs.readUInt()
    paletteSize = bs.readUInt()
    if paletteSize == 0x400:
        dothis = 8
    elif paletteSize == 0x80:
        dothis = 1
    unk = bs.readUInt()
    unk2 = bs.readUInt()
    dataStart = bs.readUInt()
    headerSize = bs.readUInt()
    unk3 = bs.readUInt()
    fileSize = bs.readUInt()
    unk4 = bs.readUInt()
    bs.seek(0x80)
    #palette = bs.readBytes(paletteSize)
    palData = []
    for i in range(dothis):
        for j in range(32):              #read 1st 32 byte block of palette
            read = bs.readUByte()
            palData.append(read)
        bs.seek(0x20, NOESEEK_REL)
        for j in range(32):              #read 3rd 32 byte block of palette
            read = bs.readUByte()
            palData.append(read)
        bs.seek(-0x40, NOESEEK_REL)
        for j in range(32):              #read 2nd 32 byte block of palette
            read = bs.readUByte()
            palData.append(read)
        bs.seek(0x20, NOESEEK_REL)
        for j in range(32):              #read 4th 32 byte block of palette
            read = bs.readUByte()
            palData.append(read)
    palette = bytearray(palData)
    #data = rapi.imageUntwiddlePS2(data, imgWidth, imgHeight, 8)
    data = bs.readBytes(bs.getSize() - bs.tell())
    if bitsperpixel == 8:
        data = rapi.imageDecodeRawPal(data, palette, imgWidth, imgHeight, 8, "r8 g8 b8 a8")
    elif bitsperpixel == 4:
        data = rapi.imageDecodeRawPal(data, palette, imgWidth, imgHeight, 4, "r8 g8 b8 a8")
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, noesis.NOESISTEX_RGBA32))
    return 1