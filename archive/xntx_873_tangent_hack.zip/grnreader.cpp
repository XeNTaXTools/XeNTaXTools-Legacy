#include <stdio.h>
#include <assert.h>
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <fstream>
#include <iostream>
#include <string>
#include <cstdlib>

#include "tga_io.h"

using namespace std;

#include "AutoGranny.h"
//#include "GR2Format.h"

#include "Granny.h"
typedef DWORD (WINAPI *PFNGRANNYCONVERTFILETORAWPROC) (const char* src, const char *dst); 
#pragma warning(disable:4996) // deprecated functions

GrannyStack stack;

void __cdecl log(int a, int b, char* msg)
{
	printf("-- Log (%d %d) %s\n", a, b, msg);
}
GrannyLogger logger = { &log, &log };

void dumpStruct(void* data, int n);
 
bool VertexWeight;

void OutputSMD(FILE* f, t_Meshes* mesh, string ArgName[100], int totalbones, int nverts = -1, int nindices = -1)
{
	

	if (nverts == -1)
		nverts = (*GrannyGetMeshVertexCount)(mesh);
	if (nindices == -1)
		nindices = (*GrannyGetMeshIndexCount)(mesh);

	
	//fprintf(f, "triangles \n");


		t_Indices16* indices = new t_Indices16[nindices];

		(*GrannyCopyMeshIndices)(mesh, 2, indices);


		int triplet_sensor = 0;
		//for (int i = initIND; i <  (initIND + finishIND)-1; ++i)


		printf("\nMMesh Name: %s\n", mesh->Name);
		printf("BoneBindings_count: %d\n", mesh->BoneBindings_count);
		printf("Groups_count: %d\n", mesh->PrimaryTopology->Groups_count);

		int NumGroup = 1;
		//if(mesh->BoneBindings_count > 1)
		//{
			NumGroup = mesh->PrimaryTopology->Groups_count;
		//}
	

		for(int iGroup = 0; iGroup < NumGroup; ++iGroup)  // for each surface
		{
			
			//fprintf(file, "g %s\n", mesh->MaterialBindings[triangleGroups_[iGroup].MaterialIndex].Material->Name);

			for(int iTriangle = 0; iTriangle <  mesh->PrimaryTopology->Groups[iGroup].TriCount; ++iTriangle) 
			{
				int index0 = (mesh->PrimaryTopology->Groups[iGroup].TriFirst + iTriangle) * 3;

				for(int roll = 0; roll < 3; roll++)
				{
					if (roll == 0)
					{
						int MatID = mesh->PrimaryTopology->Groups[iGroup].MaterialIndex;
						fprintf(f, "%s_%d\n", mesh->Name, MatID);
					}
				
					int tri1 = indices[index0 + roll].Int16;

					int bIndex = 0;

					int wIndex[4] = {0,0,0,0};
					int wIndex_size = 0;

					char MName[100] = {};

					string WName[4] = {};

					if(mesh->BoneBindings_count > 1)
					{
						if(VertexWeight)
						{
							for(int bi = 0; bi < 4; bi++)
							{
								if ( mesh->PrimaryVertexData->Vertices[tri1].BoneWeights[bi] != 0) 
								{
									wIndex[bi] = mesh->PrimaryVertexData->Vertices[tri1].BoneIndices[bi];
									WName[bi] = mesh->BoneBindings[wIndex[bi]].BoneName;
									wIndex_size++;
								}
							}
							bIndex = mesh->PrimaryVertexData->Vertices[tri1].BoneIndices[0]; 
							strcpy(MName, mesh->BoneBindings[bIndex].BoneName);
						}
						else
						{
							bIndex = mesh->PrimaryVertexData->Vertices[tri1].BoneIndices[0]; 
							strcpy(MName, mesh->BoneBindings[bIndex].BoneName);
							
						}
					}
					else
					{
						strcpy(MName, mesh->BoneBindings->BoneName);
					}

						//printf("%d: wIndex_size\n",wIndex_size);
						int RealIndex = -5; //dummy
						int WRealIndex[4] = {-5,-5,-5,-5};

						if( (RealIndex < -4) )
						{
							printf("Writing vertex %d out of %d - Group %d out of %d\n", iTriangle+1, mesh->PrimaryTopology->Groups[iGroup].TriCount, iGroup+1, NumGroup);
							if( (VertexWeight) && (mesh->BoneBindings_count > 1) )
							{
								for(int w = 0; w < totalbones; w++)
								{
									if (!strcmp(MName, ArgName[w].c_str()))
									{
										//printf("%d: MName %s, PName %s\n", w, MName, ArgName[w].c_str());
										//printf("Yes!");
										RealIndex = w;	

										fprintf(f, "%d %f %f %f %f %f %f %f %f", RealIndex,
											mesh->PrimaryVertexData->Vertices[tri1].Position[0], mesh->PrimaryVertexData->Vertices[tri1].Position[1], mesh->PrimaryVertexData->Vertices[tri1].Position[2],
											mesh->PrimaryVertexData->Vertices[tri1].Normal[0], mesh->PrimaryVertexData->Vertices[tri1].Normal[1], mesh->PrimaryVertexData->Vertices[tri1].Normal[2],
											mesh->PrimaryVertexData->Vertices[tri1].TextureCoordinates0[0], -mesh->PrimaryVertexData->Vertices[tri1].TextureCoordinates0[1]);

										fprintf(f, " %d ", wIndex_size);
										for (int windex = 0; windex < wIndex_size; windex++)
										{
											for(int r = 0; r < totalbones; r++)
											{
												char W_CNAme[100] = {};
												strcpy(W_CNAme, WName[windex].c_str() );
												if (!strcmp(W_CNAme, ArgName[r].c_str() ) )
												{
													//printf("%d: MName %s, PName %s\n", w, WName[windex].c_str(), ArgName[w].c_str());
													//printf("Yes!");
													//WRealIndex[windex] = w;
													int IntWeight;
													IntWeight = (int)mesh->PrimaryVertexData->Vertices[tri1].BoneWeights[windex];
													float FloatWeight = (float)IntWeight;

													fprintf(f, "%d %f ", r, FloatWeight/255);
												}
											}	
										}
										 //close line
										 fprintf(f, "\n");	
									}
								}
							}
							else
							{
								for(int w = 0; w < totalbones; w++)
								{

									if (!strcmp(MName, ArgName[w].c_str()))
									{
										//printf("%d: MName %s, PName %s\n", w, MName, ArgName[w].c_str());
										//printf("Yes!");
										RealIndex = w;	
										
										int IndexReveal = -10;

										
										if(mesh->BoneBindings_count > 1)
										{

											 fprintf(f, "%d %f %f %f %f %f %f %f %f\n", RealIndex,
												mesh->PrimaryVertexData->Vertices[tri1].Position[0], mesh->PrimaryVertexData->Vertices[tri1].Position[1], mesh->PrimaryVertexData->Vertices[tri1].Position[2],
												mesh->PrimaryVertexData->Vertices[tri1].Normal[0], mesh->PrimaryVertexData->Vertices[tri1].Normal[1], mesh->PrimaryVertexData->Vertices[tri1].Normal[2],
												mesh->PrimaryVertexData->Vertices[tri1].TextureCoordinates0[0], -mesh->PrimaryVertexData->Vertices[tri1].TextureCoordinates0[1]);
										}
										else
										{
											t_Vertex_PNT332* verts = new t_Vertex_PNT332[nverts];
											(*GrannyCopyMeshVertices)(mesh, GrannyPNT332VertexType, verts);
										
											fprintf(f, "%d %f %f %f %f %f %f %f %f\n", RealIndex,
												verts[tri1].Position[0], verts[tri1].Position[1], verts[tri1].Position[2],
												verts[tri1].Normal[0], verts[tri1].Normal[1], verts[tri1].Normal[2],
												verts[tri1].TextureCoordinates0[0], -verts[tri1].TextureCoordinates0[1]);

											delete[] verts;
										}
									}
								}	
							}
						}
					}
					
				}
			}
		

		delete[] indices;
		
	//fclose(f);
		//fprintf(f, "end\n");

}

//void OutputMax(const char* filename, t_Meshes* mesh, int nverts = -1, int nindices = -1)
void OutputMax(FILE* f, t_Meshes* mesh, int nverts = -1, int nindices = -1)
{
	

	if (nverts == -1)
		nverts = (*GrannyGetMeshVertexCount)(mesh);
	if (nindices == -1)
		nindices = (*GrannyGetMeshIndexCount)(mesh);

	//FILE* f = fopen(filename, "w");

	for (int e = 0; e < mesh->PrimaryTopology->Groups_count; e++)
	{

	

		fprintf(f, "fn create = (\ntemp = mesh numverts:%d numfaces:%d\n",
		nverts,
		nindices/3);

		fprintf(f, "setNumTVerts temp %d\nbuildTVFaces temp\n", nverts);

		t_Vertex_PNT332* verts = new t_Vertex_PNT332[nverts];
		(*GrannyCopyMeshVertices)(mesh, GrannyPNT332VertexType, verts);
		for (int i = 0; i < nverts; ++i)
		{
			fprintf(f, "setVert temp %d [%f,%f,%f]\n", i+1,
				verts[i].Position[0], verts[i].Position[1], verts[i].Position[2]);
			fprintf(f, "setTVert temp %d [%f,%f,%f]\n", i+1,
				verts[i].TextureCoordinates0[0], -verts[i].TextureCoordinates0[1], 0.0f);
			fprintf(f, "setNormal temp %d [%f,%f,%f]\n", i+1,
				verts[i].Normal[0], verts[i].Normal[1], verts[i].Normal[2]);


		}
		delete[] verts;

		t_Indices16* indices = new t_Indices16[nindices];

		(*GrannyCopyMeshIndices)(mesh, 2, indices);

		int initIND = mesh->PrimaryTopology->Groups[e].TriFirst;
		int finishIND = (mesh->PrimaryTopology->Groups[e].TriCount)-1;

		int indexIND = mesh->PrimaryTopology->Groups[e].MaterialIndex;

		
		//printf("init: %d, finish. %d, index: %d\n",  initIND, finishIND, indexIND);
		//for (int i = 0; i < nindices/3; ++i)
		for (int i = initIND; i <  (initIND + finishIND)+1; ++i)
		{
			fprintf(f, "setFace temp %d [%d,%d,%d]\n", i+1,
				indices[i*3+0].Int16+1,
				indices[i*3+1].Int16+1,
				indices[i*3+2].Int16+1);

			//printf("indices %d\n",  nindices*3);

			//printf("indices %d\n",  i);
			//fprintf(f, "setFaceMatID temp %d %d\n", i+1, indexIND);
			//IndexCount = i;
		}


		delete[] indices;

		fprintf(f, "for f = 1 to temp.numfaces do setTVFace temp f (getface temp f)\n");

		fprintf(f, ")\ncreate()\n");

	}
			
	//fclose(f);

}


int main(int argc, char** argv)
{
	if (argc != 2)
	{
		printf("Please run as something like '%s HC_cathedral.gr2'.\n", argv[0]);
		exit(-1);
	}

	LoadStuff();
	(*GrannySetLogCallback)(&logger);

	char* file = argv[1];
	GrannyFile* modelfile = (*GrannyReadEntireFile)(file);
	
	if (! modelfile)
	{
		printf("Couldn't read GR2 file '%s' - maybe it's not the right name, or not in the right folder.\n", modelfile);
		exit(-2);
	}

	t_FileInfo* modelinfo = (*GrannyGetFileInfo)(modelfile);
	if (! modelinfo)
	{
		printf("Couldn't get GR2 FileInfo. I have no idea why.\n");
		exit(-3);
	}
	
	if (! modelinfo->Meshes_count)
	{
		printf("Specified GR2 seems to have no meshes. I'll just give up.\n");
		exit(-4);
	}

	//First output .ms file just in case the SMD exporter could crash
	char ms_file[100] = {};
	strcat(ms_file, file);
	strcat(ms_file, ".ms");

	FILE* h = fopen(ms_file, "w");
	fprintf(h, "");
	fclose(h);

	
	FILE* f = fopen(ms_file, "w");

	for (int i = 0; i < modelinfo->Meshes_count; i++)
	{
		OutputMax(f, modelinfo->Meshes[i]);
	}
	
	fclose(f);

	printf("Created %s\n", ms_file);


	/**     Begin       **/
	char dat_file[100]={};
	strcat(dat_file, file);
	strcat(dat_file, ".dat");

	
	//1000 bones is enough?
	int numArray[1000] = {0};
	string strgArray[1000] = {};

	printf("\nSkeleton Nrs: %d\n", modelinfo->Skeletons_count);
	int hh = 0;
	string line;
	ifstream myfile (dat_file);
	
	if (myfile.is_open())
	{
		printf("Loaded Skeleton Data: %s\n",dat_file);
		while (! myfile.eof() )
		{
			getline (myfile,line);
			//cout << line << endl;
			hh++;
		}
		
		myfile.close();
	}
	
	ifstream inFile;
    
    inFile.open(dat_file);
	inFile.width();
	for (int x = 0; x <= hh; x++)
	{
		getline(inFile, strgArray[x]);
	}

    inFile.close();


	/**     End       **/

	
	
	
	char smd_file[100]={};
	strcat(smd_file, file);
	strcat(smd_file, ".smd");

	FILE* g = fopen(smd_file, "a");
	//int BBCount = modelinfo->Skeletons[0]->Bones_count;
	int BBCount = hh;
	fprintf(g, "triangles \n");

	VertexWeight = false;

	if (MessageBox(GetActiveWindow(), "Export all the Mesh Groups?", "GR2 Export", MB_YESNO)== IDYES )
	{
		if (MessageBox(GetActiveWindow(), "Enable SMD VertexWeight?", "GR2 Export", MB_YESNO)== IDYES )
		{
			VertexWeight = true;
		}
		for (int i = 0; i < modelinfo->Meshes_count; i++)
		{
			OutputSMD(g, modelinfo->Meshes[i], strgArray, BBCount);	
		}
	}
	else
	{
		if (MessageBox(GetActiveWindow(), "Enable SMD VertexWeight?", "GR2 Export", MB_YESNO)== IDYES )
		{
			VertexWeight = true;
		}
		for (int i = 0; i < modelinfo->Meshes_count; i++)
		{
			char MeshExportMessage[200] = {};
			strcpy(MeshExportMessage, "Export ");
			strcat(MeshExportMessage, modelinfo->Meshes[i]->Name);
			strcat(MeshExportMessage, "?");

			if (MessageBox(GetActiveWindow(), MeshExportMessage, "GR2 Export", MB_YESNO)== IDYES )
			{
				OutputSMD(g, modelinfo->Meshes[i], strgArray, BBCount);	
			}
		}
	}
	

	fprintf(g, "end\n");
	//int BBCount = modelinfo->Skeletons[0]->Bones_count;
	//OutputSMD(g, modelinfo->Meshes[0], strgArray, BBCount);
	fclose(g);

	printf("Created %s\n", smd_file);


	return 0;	
}
