from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Trials Fusion", ".tex")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
	#noesis.logPopup()
	return 1

#check if it's this type based on the data
def noepyCheckType(data):
    bs = NoeBitStream(data)
    Magic = bs.readBytes(3)
    print(Magic, "magic")
    if Magic != b'T5X':
        if Magic != b'T8X': 
            return 0
    return 1
	
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    fileName = rapi.getLocalFileName(rapi.getInputName()) #get file name with ext without path
    bs.seek(0x3, NOESEEK_ABS)
    check = bs.readUByte()
    print(check, "check")
    bs.seek(0x8, NOESEEK_ABS)
    unk = bs.readByte()
    numMips = bs.readUByte()
    print(numMips, "numMips")
    unk2 = bs.readByte()
    bs.seek(0x13, NOESEEK_ABS)
    imgWidth = bs.readUShort()           
    print(imgWidth, "imgwidth")
    imgHeight = bs.readUShort()          
    print(imgHeight, "imgheight")
    if "Event_Map.png.tex" in fileName:
        bs.seek(0x3, NOESEEK_ABS)
        imgWidth = bs.readUShort()           
        print(imgWidth, "imgwidth")
        imgHeight = bs.readUShort()          
        print(imgHeight, "imgheight")
    if check == 2:
        bs.seek(0x14, NOESEEK_ABS)
        imgWidth = bs.readUShort()           
        print(imgWidth, "imgwidth")
        imgHeight = bs.readUShort()          
        print(imgHeight, "imgheight")
    datasize = ((imgWidth * imgHeight) * 8) // 8           
    print(hex(datasize), "datasize")
    bs.seek(len(data) - datasize, NOESEEK_ABS)
    print(hex(bs.tell()), "here")
    if numMips == 1 and check != 2:
        bs.seek(0x1d, NOESEEK_ABS)
        print("seek to 0x1d")
    print(hex(bs.tell()), "start image data")
    data = bs.readBytes(datasize)      
    texFmt = noesis.NOESISTEX_DXT5
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1