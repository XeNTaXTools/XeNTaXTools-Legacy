#  GTArcade s3d importer by Bigchillghost
from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("GTArcade", ".s3d")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadModel(handle, noepyLoadModel)
	#noesis.logPopup()
	return 1

#check if it's this type based on the data
def noepyCheckType(data):
	if len(data) < 0x80:
		return 0
	bs = NoeBitStream(data)
	Len = bs.readShort() + 1
	Tag = noeStrFromBytes(bs.readBytes(Len), "ASCII")
	if Tag != 's3dMesh':
		return 0
	return 1

#load the model
def noepyLoadModel(data, mdlList):
	#noesis.logPopup()
	bs = NoeBitStream(data)
	Len = bs.readShort() + 5
	bs.seek(Len, NOESEEK_REL)
	
	# bone info
	boneCount = bs.readInt()
	bs.seek(4, NOESEEK_REL)
	bones = []
	for i in range(0, boneCount):
		NameLen = bs.readShort() + 1
		boneName = noeStrFromBytes(bs.readBytes(NameLen), "ASCII")
		#bs.seek(0x1C, NOESEEK_REL)
		bonePIndex = bs.readInt()
		tran = NoeVec3.fromBytes(bs.readBytes(12))
		rot = NoeVec3.fromBytes(bs.readBytes(12))
		boneMat = rot.toMat43()
		boneMat[3] = tran
		bones.append( NoeBone(i, boneName, boneMat, None, bonePIndex) )
	
	# meshes
	Len = bs.readShort() + 1
	meshName = noeStrFromBytes(bs.readBytes(Len), "ASCII")
	Vcount = bs.readInt()
	PositionIdx = []
	TexCoords = []
	
	for i in range(0, Vcount):
		bs.seek(4, NOESEEK_REL)
		TexCoords.append(NoeVec3([bs.readFloat(),bs.readFloat(), 0.0]))
		PositionIdx.append(bs.readInt())
		bs.seek(4, NOESEEK_REL)
	TrixCount = bs.readInt()
	PolygonIndex = []
	for i in range(0, TrixCount):
		bs.seek(4, NOESEEK_REL)
		for j in range(0, 3):
			PolygonIndex.append(bs.readInt())
	WeightCount = bs.readInt()
	Positions = []
	blockStart = bs.tell()
	for i in range(0, Vcount):
		Offset = blockStart + PositionIdx[i]*0x18 + 0xC
		bs.seek(Offset, NOESEEK_ABS)
		x = bs.readFloat()
		y = bs.readFloat()
		z = bs.readFloat()
		Positions.append(NoeVec3([-z,x,y])) #
	
	meshes = []
	
	mesh = NoeMesh(PolygonIndex, Positions, meshName, meshName)
	mesh.setUVs(TexCoords)
	meshes.append(mesh)
	
	mdl = NoeModel(meshes)
	mdl.setBones(bones)
	mdlList.append(mdl)
	return 1
