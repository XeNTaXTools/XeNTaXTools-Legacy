#by Durik256
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("test", ".geom")
    noesis.setHandlerTypeCheck(handle, CheckType)
    noesis.setHandlerLoadModel(handle, LoadModel)
    return 1

def CheckType(data):
    return 1

def LoadModel(data, mdlList):
    bs = NoeBitStream(data)
    ctx = rapi.rpgCreateContext()
    
    vofs = data.find(b'STRM')
    iofs = data.find(b'INDX')
    
    if vofs != -1:
        bs.seek(vofs+5)
        unk, vnum, stride, unk0 = bs.read('>4I')
        vbuf = bs.read(vnum*stride)
        
        rapi.rpgSetEndian(1)
        rapi.rpgBindPositionBuffer(vbuf, noesis.RPGEODATA_FLOAT, stride)
        if stride >= 24:
            rapi.rpgBindUV1BufferOfs(vbuf, noesis.RPGEODATA_HALFFLOAT, stride, 20)
    
        if iofs != -1:
            bs.seek(iofs+5)
            unk, inum, unk0 = bs.read('>3I')
            ibuf = bs.read(inum*2)
            rapi.rpgCommitTriangles(ibuf, noesis.RPGEODATA_USHORT, inum, noesis.RPGEO_TRIANGLE)
        else:
            rapi.rpgCommitTriangles(None, noesis.RPGEODATA_USHORT, vnum, noesis.RPGEO_TRIANGLE)
    
    try:
        mdl = rapi.rpgConstructModel()
    except:
        mdl = NoeModel()

    mdlList.append(mdl)
    return 1
    