import newGameLib
from newGameLib import *
import Blender


class Node:
	def __init__(self):
		self.ID=None
		self.parentID=None
		self.data=None
		self.childList=[]

		
def getNode(parent,n):
	n+=4
	print '-'*n,parent.name 
	for child in parent.childList:
		getNode(child,n)			

	
def gettwig(parentnode,value,key,value_type):
	if value is not None:
		childList=parentnode.childList
		for child in childList:
			name=child.name
			if name==key:
				if value_type=='list':
					value.append(child)
				if value_type=='data':					
					value.append(child.data)
			#else:
			gettwig(child,value,key,value_type)
					
						
def get(parentnode,key,value_type):
	if value_type=='list':
		value=[]
	elif value_type=='data':
		value=[]
	else:
		value=None
	
	gettwig(parentnode,value,key,value_type)
				
	return  value

def octParser(filename,g):
   #file_size = stream.size()
	g.logOpen()
	g.endian='<'
	w = g.i(6)
	g.seek(60)
	t=g.tell()
	strings = [""]

	s = ""
	g.seek(1,1)
	while(True):
		flag=g.read(1)
		if flag=='\x01':
			g.seek(-2,1)
			break
		else:
			g.seek(-1,1)
			s = g.find('\x00')
		strings.append(s)
	g.seek(t+w[3])

	parentIDList={}
	parentIDList[str(-1)]=-1

	nodeID=0
	#g.debug=True
	while(True):
	#for m in range(10): 
		if g.tell()==g.fileSize():break
		flag = g.H(1)[0]
		ID=g.H(1)[0]
		name = strings[ID]
		node=Node()
		node.name=name

		indent,format = divmod(flag,0x400)
		if txtFlag==True:
			txt.write("\t"*(indent) + name + ' '+str(hex(format))+'\n')
		data=None
		node.ID=nodeID
		parentIDList[str(indent)]=nodeID
		node.parentID=parentIDList[str(indent-1)]
		#node.parentID=parentID
		#print nodeID,node.parentID
		#print 'format:',format,g.tell(),name
		if format == 0x01:
			data='TREE'
			
		elif format == 0x05:
			ID=g.H(1)[0]
			data = strings[ID]
		elif format == 0x0A:
			count = g.B(1)[0]
			data = []
			for i in range(count):
				data.append(strings[g.H(1)[0]])
		elif format == 0x0B:
			data = strings[g.H(1)[0]]
		elif format == 0x12:
			count = g.B(1)[0]
			data = []
			for i in range(count):
				data.append(g.f(1)[0])
		elif format == 0x13:
			data = g.f(1)[0]
		elif format == 0x1A:
			count = g.B(1)[0]
			data = []
			for i in range(count):
				data.append(g.B(1)[0])
		elif format == 0x1B:
			data = g.B(1)[0]
		elif format == 0x23:
			count = g.B(1)[0]
			data = []
			for i in range(count):
				data.append(g.B(1)[0])
		elif format == 0x4A:
			count = g.H(1)[0]
			data = []
			for i in range(count):
				data.append(strings[g.H(1)[0]])
		elif format == 0x5A:
			count = g.H(1)[0]
			data = []
			for i in range(count):
				data.append(g.B(1)[0])
		elif format == 0x63: # binary data
			count = g.H(1)[0]
			#data = []
			#for i in range(count):
			#	data.append(g.B(1)[0])
			data=g.read(count)
		elif format == 0x11A:
			count = g.B(1)[0]
			data = []
			for i in range(count):
				data.append(g.H(1)[0])
		elif format == 0x11B:
			data = g.H(1)[0]
		elif format == 0x15A:
			count = g.H(1)[0]
			data = []
			for i in range(count):
				data.append(g.H(1)[0])
		elif format == 0x21A:
			count = g.B(1)[0]
			data = []
			for i in range(count):
				data.append(g.i12(1)[0])
		elif format == 0x21B:
			data = g.i12(1)[0]
		elif format == 0x31B:
			data = g.i(1)[0]
		elif format == 0x16:
			ID=g.H(1)[0]
			data = []
			data.append(strings[ID])
			count = g.B(1)[0]
			for i in range(count):
				data.append(g.f(1)[0])
		elif format == 0xa3:
			size = g.i12(1)[0]
			#g.seek(size,1)
			#g.i(1)
			data=g.read(size)
		else:
			print 'WARNING:unknow format:',hex(format)
			break
		if txtFlag==True:
			txt.write("\t"*(indent) +str(data)+'\n')
		node.data=data
		nodeList.append(node)
		nodeID+=1
		
	for ID in range(len(nodeList)):
		node=nodeList[ID]
		if node.parentID!=-1:
			parent=nodeList[node.parentID]
			parent.childList.append(node)
	g.logClose()	
	print g.tell(),g.fileSize()	
		
	
class Stream:
	def __init__(self):
		self.ID=None
		self.itemCount=None
		self.fileID=None
		self.offset=None
		self.type=None	
		self.elementStride=None
		self.elementList=[]
	
class Element:
	def __init__(self):	
		self.type=None
		self.name=None
		self.offset=None
		
class SceneComponent:
	def __init__(self):	
		self.type=None
		self.data=None
	
		
class SceneNode:
	def __init__(self):	
		self.type=None
		self.data=None		
		self.parentNodeID=None
		self.ID=None		
			
	
def draw(filename,g):
	#g.debug=True		
	rootNode=nodeList[0]
	
	
	TextureList=get(rootNode,'Texture','list')
	textureList=[]
	print
	for i,Texture in enumerate(TextureList):
		data=get(Texture,'Data','data')
		name=get(Texture,'Name','data')
		fileName=get(Texture,'SourceFilePath','data')
		#vertBuffFileNameList.append(fileName)
		#print i,name,fileName,data
		filePath=g.dirname+os.sep+os.path.basename(fileName[0]).replace('.png','.dds')
		if data[0] is not None:
			img=open(filePath,'wb')
			img.write(data[0])
			img.close()
		textureList.append(filePath)
			
	MaterialList=get(rootNode,'Material','list')
	matList=[]
	print
	for i,Material in enumerate(MaterialList):
		name=get(Material,'Name','data')
		print name
		texNodeList=get(Material,'TextureEntry','list')
		mat=Mat()
		mat.texID=None	
		mat.texType=None
		if len(texNodeList)>0:
			mat.texID=get(texNodeList[0],'TextureReference','data')[0]
			mat.texType=get(texNodeList[0],'Usage','data')[0]
			print mat.texID,mat.texType
		matList.append(mat)
		#textureList.append(filePath)
	
	
	vertBuffList=get(rootNode,'VertexBuffer','list')
	vertBuffFileNameList=[]
	#print
	for i,vertBuff in enumerate(vertBuffList):
		size=get(vertBuff,'Size','data')
		name=get(vertBuff,'Name','data')
		fileName=get(vertBuff,'FileName','data')
		vertBuffFileNameList.append(fileName)
		#print i,size,name,fileName
	#print	
	IndexBufferList=get(rootNode,'IndexBuffer','list')
	IndexBufferFileNameList=[]
	for i,IndexBuffer in enumerate(IndexBufferList):
		size=get(IndexBuffer,'Size','data')
		name=get(IndexBuffer,'Name','data')
		fileName=get(IndexBuffer,'FileName','data')
		IndexBufferFileNameList.append(fileName)
		#print i,size,name,fileName
	#print	
	indexStreamList=[]
	IndexStreamList=get(rootNode,'IndexStream','list')
	for i,IndexStream in enumerate(IndexStreamList):
		stream=Stream()
		stream.ID=i
		stream.itemCount=get(IndexStream,'Length','data')
		stream.fileID=get(IndexStream,'IndexBufferReference','data')
		stream.offset=get(IndexStream,'IndexBufferOffset','data')
		stream.type=get(IndexStream,'IndexStreamPrimitive','data')
		indexStreamList.append(stream)
	
	vertexStreamList=[]	
	VertexStreamList=get(rootNode,'VertexStream','list')
	for i,VertexStream in enumerate(VertexStreamList):
		stream=Stream()
		stream.ID=i
		stream.itemCount=get(VertexStream,'Length','data')
		stream.fileID=get(VertexStream,'VertexBufferReference','data')
		stream.offset=get(VertexStream,'VertexBufferOffset','data')
		stream.elementStride=get(VertexStream,'Width','data')
		ElementList=get(VertexStream,'Element','list')
		for j,ElementNode in enumerate(ElementList):
			element=Element()
			element.type=get(ElementNode,'Type','data')
			element.name=get(ElementNode,'Name','data')
			element.offset=get(ElementNode,'Offset','data')
			stream.elementList.append(element)
		vertexStreamList.append(stream)
		
	sceneComponentList=[]	
	SceneComponentList=get(rootNode,'SceneComponent','list')
	for i,SceneComponentNode in enumerate(SceneComponentList):
		component=SceneComponent()
		component.type=get(SceneComponentNode,'Type','data')
		component.data=get(SceneComponentNode,'RemapData','data')
		#print i,component.type,component.data
		sceneComponentList.append(component)
		
	
	"""mesh=Mesh()
	
	for vertexStream in vertexStreamList:
		#print '-----------stream'
		fileName=g.dirname+os.sep+vertBuffFileNameList[vertexStream.fileID[0]][0]
		file=open(fileName,'rb')
		#print fileName
		vs=BinaryReader(file)
		
		vs.seek(vertexStream.offset[0])
		for m in range(vertexStream.itemCount[0]):
			t=vs.tell()
			for element in vertexStream.elementList:
				#print element.name,element.offset
				if element.name[0]=='Position':
					vs.seek(t+element.offset[0])
					mesh.vertPosList.append(vs.f(3))
				if element.name[0]=='Uv1':
					vs.seek(t+element.offset[0])
					mesh.vertUVList.append(vs.f(3))
			vs.seek(t+vertexStream.elementStride[0])	
			
			
		file.close()"""
							
	skeleton=Skeleton()
	#skeleton.ARMATURESPACE=True	
	skeleton.BONESPACE=True	
	skeleton.NICE=True
	meshList={}	
	SceneTreeNodePoolList=get(rootNode,'SceneTreeNodePool','list')
	
	boneNameList=[]
	for SceneTreeNodePool in SceneTreeNodePoolList:
		locNodeList=get(SceneTreeNodePool,'Node','list')
		for node in locNodeList:
			bone=Bone()
			skeleton.boneList.append(bone)
			Type=get(node,'Type','data')
			if Type[0]=='Bone':
				bone.parentID=get(node,'ParentNodeReferences','data')[0][0]
				bone.name=get(node,'NodeName','data')[0]
				bone.matrix=Matrix4x4(get(node,'LocalToParentMatrix','data')[0])
				boneNameList.append(bone.name)
			
			if Type[0]=='Geometry':	
				print
				print 'Geometry'
				print
			if Type[0]in ['SubGeometry','SubGeometryLit'] :	
				nodeName=get(node,'NodeName','data')[0]
				#print nodeName
				vertStreamIDList=get(node,'VertexStreamReferences','data')[0]
				if str(vertStreamIDList) not in meshList.keys():
					mesh=Mesh()
					mesh.matrix=Matrix4x4(get(node,'LocalToParentMatrix','data')[0])
					print mesh.matrix
					#meshList[nodeName]=mesh
					meshList[str(vertStreamIDList)]=mesh
					for ID in vertStreamIDList:
						print '-----------stream',ID
						vertexStream=vertexStreamList[ID]
						fileName=g.dirname+os.sep+vertBuffFileNameList[vertexStream.fileID[0]][0]
						file=open(fileName,'rb')
						#print fileName
						vs=BinaryReader(file)
						
						vs.seek(vertexStream.offset[0])
						for m in range(vertexStream.itemCount[0]):
							t=vs.tell()
							for element in vertexStream.elementList:
								#print element.name,element.offset
								if element.name[0]=='Position':
									vs.seek(t+element.offset[0])
									mesh.vertPosList.append(vs.f(3))
									mesh.skinIDList.append(0)
								if element.name[0]=='Uv1':
									vs.seek(t+element.offset[0])
									mesh.vertUVList.append(vs.f(3))
								if element.name[0]=='BoneIndices':
									vs.seek(t+element.offset[0])
									mesh.skinIndiceList.append(vs.B(4))
								if element.name[0]=='BlendWeights':
									vs.seek(t+element.offset[0])
									mesh.skinWeightList.append(vs.B(4))
							vs.seek(t+vertexStream.elementStride[0])
							
							
						#file.close()
						#skin=Skin()
						#mesh.skinList.append(skin)
				mesh=meshList[str(vertStreamIDList)]		
				
				indexStreamID=get(node,'IndexStreamReference','data')[0]
				
				sceneComponentIDList=get(node,'SceneComponentReferences','data')
				if len(sceneComponentIDList)>0:
					sceneComponentID=sceneComponentIDList[0]
				else:	
					sceneComponentID=None
				#print sceneComponentID
				
				
				materialID=get(node,'MaterialReference','data')[0]
				
				material=matList[materialID]
				if material.texID is not None:
					texPath=textureList[material.texID]
					texType=material.texType
				
				#print vertStreamIDList
				
				
						
				#print indexStreamID
				
				indexStream=indexStreamList[indexStreamID]
				#print indexStream.fileID
				fileName=g.dirname+os.sep+IndexBufferFileNameList[indexStream.fileID[0]][0]
				file=open(fileName,'rb')
				#print fileName
				idx=BinaryReader(file)
				idx.seek(indexStream.offset[0])
				indiceList=idx.H(indexStream.itemCount[0])
				mesh.indiceList.extend(indiceList)
				#print indexStream.type
				if indexStream.type[0]=='TRIANGLES':
					if sceneComponentID is not None:
						skin=Skin()
						skin.boneMap=sceneComponentList[sceneComponentID[0]].data[0]
						print skin.boneMap
						for indice in indiceList:
							mesh.skinIDList[indice]=len(mesh.skinList)
						mesh.skinList.append(skin)
					
					mat=Mat()
					if material.texType is not None:
						if material.texType=='diffuseMapA1':
							mat.diffuse=texPath
					mat.TRIANGLE=True
					mat.ZTRANS=True
					mat.IDStart=len(mesh.indiceList)-indexStream.itemCount[0]
					mat.IDCount=indexStream.itemCount[0]
					mesh.matList.append(mat)
				file.close()
				
	skeleton.draw()			
	for key in meshList:
		mesh=meshList[key]
		mesh.SPLIT=True
		mesh.boneNameList=boneNameList
		mesh.BINDSKELETON=skeleton.name
		#mesh.TRIANGLE=True
		#mesh.WARNING=True
		mesh.draw()		
		
			

def Parser():	
	filename=input.filename
	ext=filename.split('.')[-1].lower()
	global meshList,nodeList
	global txt,txtFlag
	print
	print filename
	print
	nodeList=[]
	txtFlag=1
	ext=filename.split('.')[-1].lower()
	if txtFlag==True:
		txt=open(filename+'.txt','w')
		
	if ext=='oct':		
		file=open(filename,'rb')
		g=BinaryReader(file)
		octParser(filename,g)
		draw(filename,g)
		file.close()
		
	if txtFlag==True:	
		txt.close() 
		
	
 
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
	
Blender.Window.FileSelector(openFile,'import','oct - asset tree') 	