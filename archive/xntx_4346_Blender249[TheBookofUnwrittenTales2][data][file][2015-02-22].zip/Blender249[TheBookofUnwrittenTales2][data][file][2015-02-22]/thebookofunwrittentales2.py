import newGameLib
from newGameLib import *
import Blender		


	
	

def dataParser(filename,g):	
	filename=input.filename
	file=open(filename,'rb')
	g=BinaryReader(file)
	unity=Unity3D()
	unity.debugDir=filename+'Debug'
	unity.input=g
	unity.explorer()
	g.tell()
	
def noneParser(filename,g):	
	filename=input.filename
	file=open(filename,'rb')
	g=BinaryReader(file)
	unity=Unity3D()
	unity.debug=False
	unity.debugDir=filename+'Debug'
	unity.input=g
	unity.explorer()
	
	blockName='SkinnedMeshRenderer'
	blockList=blockParser(unity,blockName)
	for i,[block,blockInfo] in enumerate(blockList):
		skinnedMeshRendererInfo=SkinnedMeshRenderer(unity,block)
		drawblockSkinnedMeshRenderer(unity,skinnedMeshRendererInfo)
	
	
	
	
	
	
	
def Parser():	
	filename=input.filename
	print
	print filename
	print
	ext=filename.split('.')[-1].lower()	
	
	if ext=='data':
		file=open(filename,'rb')
		g=BinaryReader(file)
		dataParser(filename,g)
		file.close()
	else:	
		file=open(filename,'rb')
		g=BinaryReader(file)
		noneParser(filename,g)
		file.close()
 
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
	
Blender.Window.FileSelector(openFile,'import','The Book of Unwritten Tales 2 files: *.data, *.*') 
	