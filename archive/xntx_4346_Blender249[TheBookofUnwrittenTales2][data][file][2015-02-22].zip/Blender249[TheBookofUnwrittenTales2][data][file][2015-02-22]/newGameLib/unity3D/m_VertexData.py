 					
def m_VertexData(self,node,meshInfo):
	for child in node.children:			
		if child.name2=='m_CurrentChannels':
			meshInfo.currentChannel=child.data			
		if child.name2=='m_VertexCount':
			meshInfo.vertexCount=child.data	
			
		if child.name2=='m_Channels':
			for child1 in child.children:
				if child1.name2=='Array':
					for child2 in child1.children:
						if child2.name2=='data':
							for child3 in child2.children:
								channel={}
								for child4 in child3.children:
									channel[child4.name2]=child4.data
								meshInfo.channelList.append(channel)
						if child2.name2=='size':		
							meshInfo.channelCount=child2.data
								
			
			
		if child.name2=='m_Streams':
			for child1 in child.children:
				if child1.name2=='Array':
					for child2 in child1.children:
						if child2.name2=='size':
							meshInfo.streamCount=child2.data
						if child2.name2=='data':
							for child3 in child2.children:
								stream={}
								for child4 in child3.children:
									stream[child4.name2]=child4.data
								meshInfo.streamList.append(stream)
								
		if child.name2=='m_DataSize':
			for child1 in child.children:
				if child1.name2=='data':
					meshInfo.vertexOffset=child1.data
					
					
					
		if child.name2=='m_Streams[0]':
			stream={}
			for child1 in child.children:
				stream[child1.name2]=child1.data 
			meshInfo.streamList.append(stream)  
		if child.name2=='m_Streams[1]':
			stream={}
			for child1 in child.children:
				stream[child1.name2]=child1.data  
			meshInfo.streamList.append(stream)  
		if child.name2=='m_Streams[2]':
			stream={}
			for child1 in child.children:
				stream[child1.name2]=child1.data  
			meshInfo.streamList.append(stream)  
		if child.name2=='m_Streams[3]':
			stream={}
			for child1 in child.children:
				stream[child1.name2]=child1.data 
			meshInfo.streamList.append(stream) 
	if meshInfo.streamCount is None:		
		meshInfo.streamCount=len(meshInfo.streamList)			
	