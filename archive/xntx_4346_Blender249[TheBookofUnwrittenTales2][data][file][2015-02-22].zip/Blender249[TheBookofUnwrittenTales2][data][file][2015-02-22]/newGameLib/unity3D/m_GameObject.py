
		
def m_GameObject(self,data,info):
	for child in data.children:
		if child.name2=='m_Name':m_Name(self,child,info)
		if child.name2=='m_Component':m_Component(self,child,info)
		
def m_Name(self,child,info):
	for child1 in child.children:
		if child1.name2=='Array':
			for child2 in child1.children:
				if child2.name2=='data':
					info.name=child2.data
					#print info.name
		
def m_Component(self,child,info):
	for child1 in child.children:
		if child1.name2=='Array':
			for child2 in child1.children:
				if child2.name2=='size':
					count=child2.data
				if child2.name2=='data':
					if child2.name2=='data':
						for child3 in child2.children:
							for child4 in child3.children:
								#print child4.name2
								if child4.name2=='first':
									component=[]
									info.componentList.append(component)
									component.append(child4.data)
								if child4.name2=='second':
									for child5 in child4.children:
										if child5.name2=='m_FileID':component.append(child5.data)
										if child5.name2=='m_PathID':component.append(child5.data)
	#print 	info.componentList								