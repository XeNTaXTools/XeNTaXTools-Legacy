import newGameLib
from newGameLib import *
import Blender

import m_Vertices
#reload(m_Vertices)
from m_Vertices import *

import m_IndexBuffer
#reload(m_IndexBuffer)
from m_IndexBuffer import *

import m_UV
#reload(m_UV)
from m_UV import *

import m_SubMeshes
#reload(m_SubMeshes)
from m_SubMeshes import *

import m_VertexData
#reload(m_VertexData)
from m_VertexData import *

import m_Skin
#reload(m_Skin)
from m_Skin import *

import m_Name
#reload(m_Name)
from m_Name import *

import m_BindPose
#reload(m_BindPose)
from m_BindPose import *
	



class MeshInfo():
	def __init__(self):
		self.subMeshList=[]
		self.streamList=[]
		self.streamCount=None
		self.channelList=[]
		self.vertexCount=None
		self.vertexOffset=None
		self.indiceOffset=None
		self.indiceSize=None
		self.channelCount=None
		self.currentChannel=None
		self.vertPosList=[]
		self.vertUVList=[]
		self.subMeshCount=None
		self.skinIndiceList=[]
		self.skinWeightList=[]
		self.bindPoseMatrixList=[]
		
def m_Mesh(self,data):
	#pm(['blockMesh=====>blockMesh'],self.levelID)
	meshInfo=MeshInfo()
	for child in data.children:
		if child.name2=='m_Name':m_Name(self,child,meshInfo)
		#if child.name2=='m_Vertices':self.m_Vertices(child)
		if child.name2=='m_VertexData':m_VertexData(self,child,meshInfo)
		if child.name2=='m_SubMeshes':m_SubMeshes(self,child,meshInfo)
		if child.name2=='m_IndexBuffer':m_IndexBuffer(self,child,meshInfo)
		if child.name2=='m_Vertices':m_Vertices(self,child,meshInfo)
		if child.name2=='m_UV':m_UV(self,child,meshInfo)
		if child.name2=='m_Skin':m_Skin(self,child,meshInfo)
		if child.name2=='m_BindPose':m_BindPose(self,child,meshInfo)
	#print	
	return meshInfo	
	
			
			