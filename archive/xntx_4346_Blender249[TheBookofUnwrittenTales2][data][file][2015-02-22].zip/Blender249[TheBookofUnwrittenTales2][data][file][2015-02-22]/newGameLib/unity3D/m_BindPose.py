	
#from skeletonLib import *	
	
def m_BindPose(self,cell,Info):
	#skeleton=Skeleton()
	#skeleton.name='bindPose-'+str()
	#skeleton.NICE=True
	#skeleton.ARMATURESPACE=True
	for child1 in cell.children:
		if child1.name2=='Array':
			for child2 in child1.children:
				if child2.name2=='data':
					#boneID=0
					for child3 in child2.children:
						list=[]
						#bone=Bone()
						#bone.name=str(boneID)
						for child4 in child3.children:							
							if child4.name2=='e00':
								list.append(child4.data)						
							if child4.name2=='e01':
								list.append(child4.data)							
							if child4.name2=='e02':
								list.append(child4.data)							
							if child4.name2=='e03':
								list.append(child4.data)							
							if child4.name2=='e10':
								list.append(child4.data)							
							if child4.name2=='e11':
								list.append(child4.data)							
							if child4.name2=='e12':
								list.append(child4.data)							
							if child4.name2=='e13':
								list.append(child4.data)							
							if child4.name2=='e20':
								list.append(child4.data)							
							if child4.name2=='e21':
								list.append(child4.data)							
							if child4.name2=='e22':
								list.append(child4.data)							
							if child4.name2=='e23':
								list.append(child4.data)							
							if child4.name2=='e30':
								list.append(child4.data)							
							if child4.name2=='e31':
								list.append(child4.data)							
							if child4.name2=='e32':
								list.append(child4.data)							
							if child4.name2=='e33':
								list.append(child4.data)
						#Info.bindPoseMatrixList.append(list)
						#bone.matrix=Matrix4x4(list).transpose().invert()
						#print bone.matrix
						#skeleton.boneList.append(bone)
						#boneID+=1
						Info.bindPoseMatrixList.append(list)
	#skeleton.draw()					
						
		