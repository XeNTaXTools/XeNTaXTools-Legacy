
		
def MonoBehaviour(self,node,boneInfo):
	for child in node.children:
		#print child.name2
		if child.name2=='m_GameObject':m_GameObject(self,child,boneInfo)
		if child.name2=='m_Name':m_Name(self,child,boneInfo)
		
def m_GameObject(self,cell,boneInfo):
	scale=[]
	for child in cell.children:
		if child.name2=='m_FileID':
			boneInfo.m_GameObjectFileID=child.data
		if child.name2=='m_PathID':
			boneInfo.m_GameObjectPathID=child.data
		
def m_Name(self,child,info):
	for child1 in child.children:
		if child1.name2=='Array':
			for child2 in child1.children:
				if child2.name2=='data':
					info.name=child2.data
	
			
			