import newGameLib
from newGameLib import *
import Blender	

		
def m_Texture2D(self,data,info):
	#print 
	#pm(['blockTexture2D=====>blockTexture2D'],self.levelID+3)
	
	for node in data.children:
		if node.name2=='m_Name':
			for node1 in node.children:
				if node1.name2=='Array':
					for node2 in node1.children:
						if node2.name2=='size':values=node2.data
						if node2.name2=='data':
							info.m_Name=node2.data
							#pm(['Texture2D:',info.m_Name],self.levelID+3)
							
		if node.name2=='m_Width':info.m_Width  = node.data
		if node.name2=='m_Height':info.m_Height = node.data
		if node.name2=='m_TextureFormat':info.m_TextureFormat=node.data
		if node.name2=='image data':
			datasize=None
			dataoffset=None
			for node1 in node.children:
				if node1.name2=='data':dataoffset=node1.data
				if node1.name2=='size':datasize=node1.data
			self.input.seek(dataoffset)
			info.TypelessData=self.input.read(datasize)		
								
	"""if m_TextureFormat==10:
		image=Image()
		image.format='DXT1'
		image.name=self.debugDir+os.sep+m_Name+'.dds'
		image.szer=m_Width
		image.wys=m_Height
		image.data=TypelessData
		image.save()	
	elif m_TextureFormat==12:
		image=Image()
		image.format='DXT5'
		image.name=self.debugDir+os.sep+m_Name+'.dds'
		image.szer=m_Width
		image.wys=m_Height
		image.data=TypelessData
		image.save()	
	elif m_TextureFormat==2:
		image=Image()
		image.format='tga16'
		image.name=self.debugDir+os.sep+m_Name+'.dds'
		image.szer=m_Width
		image.wys=m_Height
		image.data=TypelessData
		image.save()	
	else:		
		image=Image()
		image.format='tga32'
		image.name=self.debugDir+os.sep+m_Name+'.dds'
		image.szer=m_Width
		image.wys=m_Height
		image.data=TypelessData
		image.save()	
	self.textureList.append(image.name)	
	return image.name"""
		