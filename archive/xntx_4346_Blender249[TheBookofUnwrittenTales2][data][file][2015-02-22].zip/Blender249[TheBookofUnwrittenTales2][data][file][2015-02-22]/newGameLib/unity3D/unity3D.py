import newGameLib
from newGameLib import *
import Blender	


import blockParser
from blockParser import *
	
class Chunk:
	def __init__(self):
		self.name1=None
		self.name2=None
		self.values=None
		self.offset=None
		self.ID=None
		self.children=[]
		self.info=None
		self.debugFile=None	
		
		
	
def twig(self,parent,j,chunk):
	j+=4
	for m in range(parent.info[5]):
		node=Node()
		parent.children.append(node)		
		node.name1=self.input.find('\x00')
		node.name2=self.input.find('\x00')
		node.info=self.input.i(6)		
		node.offset=self.input.tell()
		if self.debug==True:
			chunk.debugFile.write(' '*j+node.name1+'\n')
			chunk.debugFile.write(' '*j+node.name2+'\n')
			chunk.debugFile.write(' '*j+str(node.info)+'\n')	
		twig(self,node,j,chunk)

	
	
def getBlock(library,blockID):
	
	chunk=None
	blockInfo=None
	for Info in library.blockInfoList:
		if Info[0]==blockID:
			chunk=getChunk(library,Info[3])
			blockInfo=Info
	return blockInfo,chunk
	

class Unity3D:
	def __init__(self):
		self.input=None
		self.debug=False
		self.debugFile=None
		self.debugDir=None
		self.rootList=[]
		self.textureList=[]
		self.matList=[]
		self.meshList=[]
		self.chunkList=[]
		self.FLAG=False
		self.dataOffset=None
		self.blockInfoList=[]
		self.name1List=[]	
		self.cellList=[]
		self.format=None
		self.fileType=None
		self.version=None
		self.libraryList=[]
		self.levelID=0
		self.XNA=False
		self.PACK=False
		self.fromID=None
		self.toID=None
		
		self.meshInfoList=[]
		self.materialInfoList=[]
		self.texture2DInfo=[]
		self.SkinnedMeshRendererInfoList=[]	
	def explorer(self):
		if self.debug==True:
			if os.path.exists(self.debugDir)==False:
				os.makedirs(self.debugDir)
		
		
		self.input.endian='>'
		chunk=self.input.word(8)
		if chunk=='UnityWeb':
			self.unityWebParser()
		elif chunk=='UnityRaw':	
			self.unityRawParser()
		else:  	
			self.input.seek(0)
			v=self.input.i(5)
			stringVersion=self.input.word(8)
			self.input.i(1)[0]
			self.dataOffset=v[3]
			if v[2]==8:
				self.version=8
				pm(['Unity3D file type :unity3d'],self.levelID) 
				pm(['Header:',v],self.levelID)
				pm(['Unity3D file version :',v[2]],self.levelID)
				self.input.seek(-v[0],2)
				self.input.endian='<'
				self.input.B(1)
				stringVersion=self.input.word(8)
				self.input.i(1)[0]
				chunkListParser(self)
				blockListParser(self)
				libraryListParser(self)
			elif v[2]==9:
				#print 'Unity3D file version :',v[2]
				#print 'Unity3D version :',stringVersion
				#print 'Header:',v
				self.input.endian='<'
				self.chunkListParser()
				if len(self.chunkList)==0:parseChunksFromChunkList(self,stringVersion)
				self.blockListParser()
				self.libraryListParser()
		
	def draw(self,blockName='SkinnedMeshRenderer'):
		if blockName=='SkinnedMeshRenderer':
			blockParser(self,blockName)
			self.blockSkinnedMeshRenderer()
			#except:pass
		if blockName=='m_Mesh':
			blockParser(self,blockName)
			self.m_Mesh()
	def unityRawParser(self):
		#print 'Unity3D file format:UnityRaw'
		self.input.endian='>'
		self.input.seek(31)
		offset=self.input.i(1)[0]
		self.input.seek(offset)
		start=self.input.tell()
		assetCount=self.input.i(1)[0]
		for m in range(assetCount):
			string=self.input.find('\x00')
			print 'unpack:',string
			offset=self.input.i(1)[0]
			size=self.input.i(1)[0]
			back=self.input.tell()
			new=open(self.input.dirname+os.sep+string,'wb')
			self.input.seek(start+offset)
			new.write(self.input.read(size))			
			new.close()
			self.input.seek(back)
	
	def chunkListParser(self):
		#print 'chunkListParser=====>chunkListParser'
		self.input.endian='<'
		chunkCount=self.input.i(1)[0]
		#print 'parsing chunks:',chunkCount
		chunkListDir=self.debugDir+os.sep+'chunkList'
		try:os.makedirs(chunkListDir)
		except:pass
		#print 'chunkListDir:',chunkListDir
		for k in range(chunkCount): 
			chunk=Chunk()
			chunk.ID=self.input.i(1)[0]	
			if self.debug==True:
				chunk.debugFile=open(chunkListDir+os.sep+str(chunk.ID)+'.chunk.txt','w')	
			self.chunkList.append(chunk)			
			chunk.name1=self.input.find('\x00')
			chunk.name2=self.input.find('\x00')
			chunk.info=self.input.i(6)		
			chunk.offset=self.input.tell()
			j=0
			if self.debug==True:
				chunk.debugFile.write(' '*j+chunk.name1+'\n')
				chunk.debugFile.write(' '*j+chunk.name2+'\n')
				chunk.debugFile.write(' '*j+str(chunk.info)+'\n')	
			twig(self,chunk,j,chunk)
			if self.debug==True:	
				chunk.debugFile.close()
		self.input.i(1)
	

	def libraryListParser(self):
		if self.debug==True:
			self.debugFile=open(self.debugDir+os.sep+'libraryList.txt','w')
		#print 'libraryListParser=====>libraryListParser'
		libraryCount=self.input.i(1)[0]
		#print 'library count:',libraryCount
		for m in range(libraryCount):
			self.input.B(21)
			libraryName=self.input.find('\x00')
			self.libraryList.append(libraryName)
			if self.debug==True:
				self.debugFile.write('library'+str(m+1)+':'+libraryName+'\n')
			#pm(['library',m+1,':',libraryName],self.levelID)
		if self.debug==True:	
			self.debugFile.close()
		#print

	def blockListParser(self):
		#print 'blockListParser=====>blockListParser'		
		blockCount=self.input.i(1)[0]
		#print 'parsing blocks:',blockCount
		self.blockCount=blockCount
		if self.debug==True:
			self.debugFile=open(self.debugDir+os.sep+'blockList.txt','w')	
			#pm(['blockList:',self.debugFile.name],self.levelID)
		for m in range(blockCount):
			v=self.input.I(1)+self.input.i(4)#;print v
			t=self.input.tell()
			self.blockInfoList.append(v)
			if self.debug==True:
				self.debugFile.write(str(v)+'\n')
			self.input.seek(t)
		if self.debug==True:	
			self.debugFile.close()	
			
	def getBoneChildren(self,parent,SkinnedMeshRendererInfo,skeleton):	
		for child in parent.children:
			fileID=child[0]
			pathID=child[1]
			for bone in SkinnedMeshRendererInfo.boneList:
				if bone.fileID==fileID and bone.pathID==pathID:
					mybone=Bone()
					mybone.name=bone.name
					rotMatrix=QuatMatrix(bone.m_LocalRotation).resize4x4()
					posMatrix=VectorMatrix(bone.m_LocalPosition)
					mybone.matrix=rotMatrix*posMatrix
					mybone.parentName=parent.name
					skeleton.boneList.append(mybone)					
					self.getBoneChildren(bone,SkinnedMeshRendererInfo,skeleton)	
			
			
			
		
	def getBlockFromLibrary(self,libraryID,blockID):
		#print
		libraryName=self.libraryList[libraryID-1]
		#print 'draw=====>getBlockFromLibrary:',libraryName
		#print '='*20
		#print 'library:',libraryName
		#print '='*20
		libraryPath=self.input.dirname+os.sep+libraryName
		library=None
		file=None
		blockInfo=None
		chunk=None
		if os.path.exists(libraryPath)==True:
			file=open(libraryPath,'rb')
			g=BinaryReader(file)
			library=Unity3D()
			library.input=g
			library.debug=self.debug
			library.debugDir=g.inputFile.name+'Debug'
			library.explorer()
			blockInfo,chunk=getBlock(library,blockID)
		else:
			print 'WARNING:failed library:',libraryPath
		return	blockInfo,chunk,library,file
			
			
	def getData(self,library,fileID,pathID):
		#print 'getData'
		#print library,fileID,pathID
		#print
		data=None
		if fileID==0:
			blockInfo,chunk=getBlock(library,pathID)
			if blockInfo is not None:
				data=readBlock(library,blockInfo,chunk)
		else:
			blockInfo,chunk,library,file=self.getBlockFromLibrary(fileID,pathID)
			
			if library is not None and chunk is not None and blockInfo is not None:
				data=readBlock(library,blockInfo,chunk)
		return data,library		
			
			
			
			
			