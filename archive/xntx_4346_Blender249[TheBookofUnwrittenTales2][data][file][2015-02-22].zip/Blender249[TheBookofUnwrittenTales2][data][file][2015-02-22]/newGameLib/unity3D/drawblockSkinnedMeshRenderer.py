import newGameLib
from newGameLib import *
import Blender	
import m_Bone
from m_Bone import m_Bone	
import m_GameObject
from m_GameObject import m_GameObject	
import m_Material
from m_Material import m_Material	
import m_Texture2D
from m_Texture2D import m_Texture2D	
import m_Mesh
from m_Mesh import m_Mesh	
		
		
		
		
class mBoneInfo:
	def __init__(self):
		self.fileID=None
		self.pathID=None
		self.m_LocalRotation=None
		self.m_LocalPosition=None
		self.m_LocalScale=None
		self.m_Children=None
		self.m_Father=None
		self.m_GameObjectFileID=None
		self.m_GameObjectPathID=None
		self.m_FatherFileID=None
		self.m_FatherPathID=None
		self.debugFile=None
		self.data=None
		self.children=[]
		self.componentList=[]
	
def imageSave(self,texture):	
	image=Image()
	image.szer=texture.m_Width
	image.wys=texture.m_Height
	image.data=texture.TypelessData	
	if texture.m_TextureFormat==10:
		image.format='DXT1'
		image.name=self.debugDir+os.sep+texture.m_Name+'.dds'
		if os.path.exists(image.name)==False:image.draw()	
	elif texture.m_TextureFormat==12:
		image.format='DXT5'
		image.name=self.debugDir+os.sep+texture.m_Name+'.dds'
		if os.path.exists(image.name)==False:image.draw()	
	elif texture.m_TextureFormat==2:
		image.format='tga16'
		image.name=self.debugDir+os.sep+texture.m_Name+'.dds'
		if os.path.exists(image.name)==False:image.draw()	
	else:		
		image.format='tga32'
		image.name=self.debugDir+os.sep+texture.m_Name+'.dds'
		#image.draw()
	return image.name
					
	
	
def meshParser(self,meshInfo,matList,poseSkeleton,boneMap,meshID,rootBone):
			mesh=Mesh()
			mesh.name=str(meshID)+'-mesh'
			
			for i,channel in enumerate(meshInfo.channelList):
				dimension=channel['dimension']
				if dimension!=0:
					stream=meshInfo.streamList[channel['stream']]
					channelMask=stream['channelMask']
					stride=stream['stride']
					channelOffset=channel['offset']
					self.input.seek(meshInfo.vertexOffset+stream['offset'])
					if i==0:#vertPosList
						for m in range(meshInfo.vertexCount):
							t=self.input.tell()
							self.input.seek(t+channelOffset)
							mesh.vertPosList.append(self.input.f(3))
							self.input.seek(t+stride)
					if i==3:#vertUVList
						for m in range(meshInfo.vertexCount):
							t=self.input.tell()
							self.input.seek(t+channelOffset)
							mesh.vertUVList.append(self.input.f(2))
							self.input.seek(t+stride)
								
			self.input.seek(meshInfo.indiceOffset)
			mesh.indiceList=self.input.H(meshInfo.indiceSize/2)		
				
			for m in range(meshInfo.subMeshCount):
				mat=matList[m]
				submesh=meshInfo.subMeshList[m]		
				if submesh['topology']==0:
					mat.TRIANGLE=True
					mat.ZTRANS=True
				mat.IDStart=submesh['firstByte']/2
				mat.IDCount=submesh['indexCount']
				mesh.matList.append(mat)
			skin=Skin()
			mesh.skinList.append(skin)	
			mesh.skinIndiceList=meshInfo.skinIndiceList	
			mesh.skinWeightList=meshInfo.skinWeightList
			mesh.bindPoseMatrixList=meshInfo.bindPoseMatrixList
			
			
			if len(meshInfo.bindPoseMatrixList)>0:
				bindSkeleton=Skeleton()
				bindSkeleton.name='bindPose-'+mesh.name
				bindSkeleton.NICE=True
				bindSkeleton.ARMATURESPACE=True
				for ID in range(len(meshInfo.bindPoseMatrixList)):	
					bone=Bone()
					bone.name=boneMap[ID]		
					list=meshInfo.bindPoseMatrixList[ID]	
					bone.matrix=Matrix4x4(list).transpose().invert()				
					bindSkeleton.boneList.append(bone)
				for bone in bindSkeleton.boneList:
					bone.name=bone.name
				bindSkeleton.draw()	
			mesh.boneNameList=bindSkeleton.boneNameList		
			mesh.draw()	
			BINDPOSEFLAG=1
			if BINDPOSEFLAG==True:	
				bindSkeleton=Blender.Object.Get(bindSkeleton.name)
				meshObject=mesh.object
				bindPose(bindSkeleton,poseSkeleton,meshObject)
				scene = bpy.data.scenes.active	
				scene.objects.unlink(bindSkeleton)
				scene.update()
				scene = bpy.data.scenes.active	
				poseSkeleton.makeParentDeform([meshObject],0,0)

			
def	drawblockSkinnedMeshRenderer(self,SkinnedMeshRendererInfo):
	modelID=ParseID()
	rootBone=SkinnedMeshRendererInfo.rootBone
	if rootBone is not None:
		rootBoneData,boneLibrary=self.getData(self,rootBone.fileID,rootBone.pathID)
		if rootBoneData is not None:
			m_Bone(boneLibrary,rootBoneData,rootBone)
			gameObjectData,gameObjectLibrary=self.getData(boneLibrary,rootBone.m_GameObjectFileID,rootBone.m_GameObjectPathID)
			if gameObjectData is not None:				
				m_GameObject(gameObjectLibrary,gameObjectData,rootBone)			
		
	boneMap=[]
	for m in range(SkinnedMeshRendererInfo.boneCount):
		bone=SkinnedMeshRendererInfo.boneList[m]
		boneData,boneLibrary=self.getData(self,bone.fileID,bone.pathID)
		if boneData is not None:
			m_Bone(boneLibrary,boneData,bone)
			gameObjectData,gameObjectLibrary=self.getData(boneLibrary,bone.m_GameObjectFileID,bone.m_GameObjectPathID)
			if gameObjectData is not None:
				m_GameObject(gameObjectLibrary,gameObjectData,bone)
				boneMap.append(bone.name[-30:])
				
	def getBoneChildren(parent):	
		for child in parent.children:
			mBone=mBoneInfo()
			mBone.fileID=child[0]
			mBone.pathID=child[1]
			boneData,boneLibrary=self.getData(self,mBone.fileID,mBone.pathID)
			if boneData is not None:
				bone=Bone()
				skeleton.boneList.append(bone)
				m_Bone(boneLibrary,boneData,mBone)
				gameObjectData,gameObjectLibrary=self.getData(boneLibrary,mBone.m_GameObjectFileID,mBone.m_GameObjectPathID)
				if gameObjectData is not None:				
					m_GameObject(gameObjectLibrary,gameObjectData,mBone)
					bone.rotMatrix=QuatMatrix(mBone.m_LocalRotation)
					bone.posMatrix=VectorMatrix(mBone.m_LocalPosition)
					bone.name=mBone.name
					bone.parentName=parent.name	
					getBoneChildren(mBone)
		
	root=mBoneInfo()
		
	fatherList=[]	
	def getFatherOfFather(rootBone):	
		mBone=mBoneInfo()
		if  rootBone.m_FatherFileID is not None and rootBone.m_FatherPathID is not None:
			boneData,boneLibrary=self.getData(self,rootBone.m_FatherFileID,rootBone.m_FatherPathID)
			if boneData is not None and boneLibrary is not None:
				m_Bone(boneLibrary,boneData,mBone)
				gameObjectData,gameObjectLibrary=self.getData(boneLibrary,mBone.m_GameObjectFileID,mBone.m_GameObjectPathID)
				if gameObjectData is not None:	
					m_GameObject(gameObjectLibrary,gameObjectData,mBone)
				fatherList.append(mBone)	
				getFatherOfFather(mBone)		
		
				
		
	skeleton=Skeleton()
	skeleton.NICE=True
	skeleton.BONESPACE=True						
	if rootBone is not None:
		getFatherOfFather(rootBone)
		root=fatherList[-2]
		if root.m_GameObjectFileID is not None and root.m_GameObjectPathID is not None:
			for child in root.componentList:
				if child[0]==4:
					mBone=mBoneInfo()
					mBone.fileID=child[1]
					mBone.pathID=child[2]
					boneData,boneLibrary=gameObjectLibrary.getData(gameObjectLibrary,mBone.fileID,mBone.pathID)
					bone=Bone()
					m_Bone(boneLibrary,boneData,mBone)
					gameObjectData,gameObjectLibrary=gameObjectLibrary.getData(boneLibrary,mBone.m_GameObjectFileID,mBone.m_GameObjectPathID)
					if gameObjectData is not None:				
						m_GameObject(gameObjectLibrary,gameObjectData,mBone)
						bone.rotMatrix=QuatMatrix(mBone.m_LocalRotation)
						bone.posMatrix=VectorMatrix(mBone.m_LocalPosition)
						bone.name=mBone.name
						skeleton.name=mBone.name
					skeleton.boneList.append(bone)
					getBoneChildren(mBone)
					
		
		
		
	else:
		print 'WARNING:rootBone is None'
	
	for bone in skeleton.boneList:
		bone.name=bone.name[-30:]
		if bone.parentName is not None:
			bone.parentName=bone.parentName[-30:]
	skeleton.draw()
		
	#material
	matList=[]			
	for j,material in enumerate(SkinnedMeshRendererInfo.materialList):
			mat=Mat()
			materialData,matLibrary=self.getData(self,material.fileID,material.pathID)
			if materialData is not None:
				m_Material(matLibrary,materialData,material)				
				for texture in material.textureList:
					libraryID=texture.fileID
					blockID=texture.pathID
					type=texture.type
					textureData,texLibrary=matLibrary.getData(matLibrary,texture.fileID,texture.pathID)
					if textureData is not None and texLibrary is not None:
						m_Texture2D(texLibrary,textureData,texture)
						imagePath=imageSave(texLibrary,texture)
						if texture.type=='_MainTex':
							mat.diffuse=imagePath
						if texture.type=='_BumpMap':
							mat.normal=imagePath
						if texture.type=='_Illum':
							mat.specular=imagePath
						if texture.type=='_DifuseMap':
							mat.diffuse=imagePath
						if texture.type=='_SpecularMap':
							mat.specular=imagePath
			else:
				print 'Missing library:',matLibrary.input.basename
			matList.append(mat)			
				
				
	#mesh
	meshFileID=SkinnedMeshRendererInfo.m_MeshFileID
	meshPathID=SkinnedMeshRendererInfo.m_MeshPathID
	meshData,meshLibrary=self.getData(self,meshFileID,meshPathID)
	if meshData is not None:
		meshParser(meshLibrary,m_Mesh(self,meshData),matList,skeleton.object,boneMap,modelID,rootBone)
					