

def m_IndexBuffer(self,cell,meshInfo):
	for child in cell.children:
		if child.name2=='Array':
			for child1 in child.children:
				if child1.name2=='size':
					meshInfo.indiceSize=child1.data
				if child1.name2=='data':
					meshInfo.indiceOffset=child1.data			