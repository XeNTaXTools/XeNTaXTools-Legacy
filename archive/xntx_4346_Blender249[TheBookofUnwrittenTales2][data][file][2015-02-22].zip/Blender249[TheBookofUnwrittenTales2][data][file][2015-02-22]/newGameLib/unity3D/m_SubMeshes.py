

def m_SubMeshes(self,cell,meshInfo):
	for child in cell.children:
		if child.name2=='Array':
			for child1 in child.children:
				if child1.name2=='size':
					meshInfo.subMeshCount=child1.data
				if child1.name2=='data':
					for child2 in child1.children:
						submesh={}
						for child3 in child2.children:
							submesh[child3.name2]=child3.data
						meshInfo.subMeshList.append(submesh)
			