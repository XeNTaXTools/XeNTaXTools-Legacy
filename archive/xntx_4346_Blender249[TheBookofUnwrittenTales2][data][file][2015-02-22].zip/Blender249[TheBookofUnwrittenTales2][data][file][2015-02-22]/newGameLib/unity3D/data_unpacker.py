import Blender
import struct
def unityRawParser(input):
	input.seek(31)
	offset=struct.upnal('>i',input.read(4))[0]
	input.seek(offset)
	start=input.tell()
	assetCount=struct.upnal('>i',input.read(4))[0]
	for m in range(assetCount):
		string=self.input.find('\x00')
		offset=self.input.i(1)[0]
		size=self.input.i(1)[0]
		back=self.input.tell()
		new=open(self.input.dirname+os.sep+string,'wb')
		self.input.seek(start+offset)
		new.write(self.input.read(size))			
		new.close()
		self.input.seek(back)
		
def openFile(filename):
	ext=filename.lower().split('.')[-1]		
	if ext=='data':
		file=open(filename,'rb')
		unityRawParser(file)
		file.close()	
		
Blender.Window.FileSelector(openFile,'unpack','The Book of The Unwritten Tales files: data - archive')		
		
		