


def m_Vertices(self,cell,meshInfo):
	for child in cell.children:
		if child.name2=='Array':
			for child1 in child.children:
				if child1.name2=='size':
					meshInfo.vertPosCount=child1.data
				if child1.name2=='data':
					for child2 in child1.children:
						pos=[]
						for child3 in child2.children:
							if child3.name2=='x':
								pos.append(child3.data)
							if child3.name2=='y':
								pos.append(child3.data)
							if child3.name2=='z':
								pos.append(child3.data)
						meshInfo.vertPosList.append(pos)