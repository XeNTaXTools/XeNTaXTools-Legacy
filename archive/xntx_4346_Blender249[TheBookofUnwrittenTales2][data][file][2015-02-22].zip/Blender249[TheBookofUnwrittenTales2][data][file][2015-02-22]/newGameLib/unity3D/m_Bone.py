
		
def m_Bone(self,node,boneInfo):
	for child in node.children:
		if child.name2=='m_LocalRotation':m_LocalRotation(self,child,boneInfo)
		if child.name2=='m_LocalPosition':m_LocalPosition(self,child,boneInfo)
		#if child.name2=='m_LocalScale':m_LocalScale(self,child,boneInfo)
		if child.name2=='m_Father':m_Father(self,child,boneInfo)
		if child.name2=='m_GameObject':m_GameObject(self,child,boneInfo)
		if child.name2=='m_Children':m_Children(self,child,boneInfo)
		
def m_Children(self,cell,boneInfo):
	for child1 in cell.children:
		if child1.name2=='Array':
			for child2 in child1.children:
				if child2.name2=='data':
					for child3 in child2.children:
						list=[]
						for child4 in child3.children:							
							if child4.name2=='m_FileID':
								list.append(child4.data)
							if child4.name2=='m_PathID':
								list.append(child4.data)
						boneInfo.children.append(list)		
						
		
		
def m_LocalRotation(self,cell,boneInfo):
	quat=[]
	for child in cell.children:
		if child.name2=='x':
			quat.append(child.data)
		if child.name2=='y':
			quat.append(child.data)
		if child.name2=='z':
			quat.append(child.data)
		if child.name2=='w':
			quat.append(child.data)
	boneInfo.m_LocalRotation=quat		
		
def m_LocalPosition(self,cell,boneInfo):
	pos=[]
	for child in cell.children:
		if child.name2=='x':
			pos.append(child.data)
		if child.name2=='y':
			pos.append(child.data)
		if child.name2=='z':
			pos.append(child.data)
	boneInfo.m_LocalPosition=pos			
		
def m_Father(self,cell,boneInfo):
	scale=[]
	for child in cell.children:
		if child.name2=='m_FileID':
			boneInfo.m_FatherFileID=child.data
		if child.name2=='m_PathID':
			boneInfo.m_FatherPathID=child.data			
		
def m_GameObject(self,cell,boneInfo):
	scale=[]
	for child in cell.children:
		if child.name2=='m_FileID':
			boneInfo.m_GameObjectFileID=child.data
		if child.name2=='m_PathID':
			boneInfo.m_GameObjectPathID=child.data	
	
			
			