import newGameLib
from newGameLib import *
import Blender		

		
class MaterialInfo():
	def __init__(self):
		self.fileID=None
		self.pathID=None
		self.textureList=[]
		self.name=None
		self.shaderFileID=None
		self.shaderPathID=None
		
class m_Bone:
	def __init__(self):
		self.fileID=None
		self.pathID=None
		self.m_LocalRotation=None
		self.m_LocalPosition=None
		self.m_LocalScale=None
		self.m_Children=None
		self.m_Father=None
		self.m_GameObjectFileID=None
		self.m_GameObjectPathID=None
		self.m_FatherFileID=None
		self.m_FatherPathID=None
		self.debugFile=None
		self.data=None
		self.children=[]
		self.componentList=[]
		
		
		
class SkinnedMeshRendererInfo():
	def __init__(self):
		self.name=None
		self.m_Materials=[]
		self.fileID=None
		self.pathID=None
		self.m_GameObjectFileID=None
		self.m_GameObjectPathID=None
		self.m_MeshFileID=None
		self.m_MeshPathID=None
		self.boneList=[]
		self.materialList=[]
		self.materialCount=None
		self.debugFile=None
		self.rootBone=None
			
		

def SkinnedMeshRenderer(self,data):
	
	
	
	Info=SkinnedMeshRendererInfo()
	for child in data.children:
		if child.name2=='m_Materials':m_Materials(self,child,Info)
		if child.name2=='m_GameObject':m_GameObject(self,child,Info)
		if child.name2=='m_Mesh':m_Mesh(self,child,Info)
		if child.name2=='m_Bones':m_Bones(child,Info)
		if child.name2=='m_RootBone':m_RootBone(self,child,Info)
			
	return Info		
			

			
			
		
def m_RootBone(self,child,Info):
	bone=m_Bone()
	for node in child.children:
		if node.name2=='m_FileID':
			bone.fileID=node.data
		if node.name2=='m_PathID':
			bone.pathID=node.data
	Info.rootBone=bone
			
			
		
def m_Bones(child,Info):
	for node in child.children:
		if node.name2=='Array':
			for node1 in node.children:
				if node1.name2=='size':
					Info.boneCount=node1.data
				if node1.name2=='data':
					for node2 in node1.children:
						bone=m_Bone()
						for node3 in node2.children:
							if node3.name2=='m_FileID':
								bone.fileID=node3.data
								#print bone.fileID
							if node3.name2=='m_PathID':
								bone.pathID=node3.data
								#print bone.pathID		
						Info.boneList.append(bone)
						
		
def m_Materials(self,child,Info):
	for node in child.children:
		if node.name2=='Array':
			for node1 in node.children:
				if node1.name2=='size':
					Info.materialCount=node1.data
				if node1.name2=='data':
					for node2 in node1.children:
						material=MaterialInfo()
						for node3 in node2.children:
							if node3.name2=='m_FileID':
								material.fileID=node3.data
							if node3.name2=='m_PathID':
								material.pathID=node3.data
						Info.materialList.append(material)	
		
def m_GameObject(self,child,Info):
	for node in child.children:
		if node.name2=='m_FileID':
			Info.m_GameObjectFileID=node.data
		if node.name2=='m_PathID':
			Info.m_GameObjectPathID=node.data	
	#print 'sm_GameObject:',	Info.m_GameObjectFileID,Info.m_GameObjectPathID		
		
def m_Mesh(self,child,Info):
	for node in child.children:
		if node.name2=='m_FileID':
			Info.m_MeshFileID=node.data
		if node.name2=='m_PathID':
			Info.m_MeshPathID=node.data	
		