class TextureInfo:
	def __init__(self):
		self.type=None
		self.fileID=None
		self.pathID=None
		self.m_Name=None
		self.m_Width=None
		self.m_Height=None
		self.m_TextureFormat=None
		self.TypelessData=None


def m_Material(self,data,materialInfo):
	for child in data.children:
		if child.name2=='m_Name':m_Name(self,child,materialInfo)
		if child.name2=='m_SavedProperties':m_SavedProperties(self,child,materialInfo)
		if child.name2=='m_Shader':m_Shader(self,child,materialInfo)
		
def m_Name(self,child,materialInfo):
	for node in child.children:
		if node.name2=='Array':
			for node1 in node.children:
				if node1.name2=='data':
					materialInfo.name=node1.data
		
def m_Shader(self,child,materialInfo):
	for node in child.children:
		if node.name2=='m_FileID':
			materialInfo.shaderFileID=node.data
		if node.name2=='m_PathID':
			materialInfo.shaderPathID=node.data
	
def m_SavedProperties(self,child,materialInfo):
	for node in child.children:
		if node.name2=='m_TexEnvs':
			for node1 in node.children:
				if node1.name2=='Array':
					for node2 in node1.children:
						if node2.name2=='data':
							for node3 in node2.children:
								textureInfo=TextureInfo()
								materialInfo.textureList.append(textureInfo)
								for node4 in node3.children:
									if node4.name2=='first':
										for node5 in node4.children:
											if node5.name2=='name':
												for node6 in node5.children:
													if node6.name2=='Array':
														for node7 in node6.children:
															if node7.name2=='data':
																textureInfo.type=node7.data
									if node4.name2=='second':
										for node5 in node4.children:
											if node5.name2=='m_Texture':
												for node6 in node5.children:
													if node6.name2=='m_FileID':
														textureInfo.fileID=node6.data
													if node6.name2=='m_PathID':
														textureInfo.pathID=node6.data
											if node5.name2=='m_Scale':
												for node6 in node5.children:
													if node6.name2=='x':
														x=node6.data
													if node6.name2=='y':
														y=node6.data
											if node5.name2=='m_Offset':
												for node6 in node5.children:
													if node6.name2=='x':
														x=node6.data
													if node6.name2=='y':
														y=node6.data
	

							
				
				