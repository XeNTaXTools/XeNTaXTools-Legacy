import newGameLib
from newGameLib import *
import Blender		

class Cell:
	def __init__(self):
		self.name1=None
		self.name2=None
		self.data=None
		self.children=[]
		self.debugFile=None
		
def seek_padding(self,size,pad):
	''' 16-byte chunk alignment'''
	
	pad = (pad - (size % pad)) % pad
	##print pad
	self.input.seek(pad, 1)
	
	
def go_to_data(self,node,n,cell):
	if node.name1=='char':
		values=self.input.word(size)
		if self.debug==True:debugFile.write(' '*n+str(values)+'\n')
		node.values=values
		cell.data=values						
	elif node.name1=='MeshBlendShape':
		cell.data=size
		for m in range(size):
			newCell=Cell()
			cell.children.append(newCell)
			for child in node.children:getSection(self,child,n,cell)					
	elif node.name1=='UInt8':
		cell.data=self.input.tell()
		self.input.seek(size,1)					
	elif node.name1=='unsigned int':
			#values=self.input.i(size)
			if size==0:
				values=self.input.i(1) #only for the book of the unwritten tales
			else:	
				values=self.input.i(size)
			if self.debug==True:debugFile.write(' '*n+str(values)+'\n')
			node.values=values
			cell.data=values
											
	else:
		#print 'unknow node.name1',node.name1
		cell.data=size
		for m in range(size):
			newCell=Cell()
			cell.children.append(newCell)
			
			for child in node.children:getSection(self,child,n,newCell)
	
	
def go_to_size(self,node,n,cell):
	global size
	values=None
	if node.name1 not in self.name1List:self.name1List.append(node.name1)
	if node.name1=='SInt32':
		values=self.input.I(1)[0];
		size=values
		node.values=values
		cell.data=values			
	elif node.name1=='UInt32':
		values=self.input.i(1)[0]
		node.values=values
		cell.data=values			
	elif node.name1=='UInt16':
		values=self.input.H(1)[0]
		node.values=values	
		cell.data=values				
	elif node.name1=='SInt16':
		values=self.input.H(1)[0]
		node.values=values	
		cell.data=values		
	elif node.name1=='int':
		values=self.input.I(1)[0];
		size=values
		node.values=values
		cell.data=values			
	elif node.name1=='unsigned int':
		values=self.input.i(1)[0]
		node.values=values	
		cell.data=values		
	elif node.name1=='float':
		values=self.input.f(1)[0]
		node.values=values	
		cell.data=values		
	elif node.name1=='UInt8':
		values=self.input.B(1)[0]
		node.values=values	
		cell.data=values		
	elif node.name1=='bool':
		values=self.input.B(1)[0]
		#seek_padding(self,self.input.tell(),4)	
		node.values=values	
		cell.data=values		
	else:
		pass#print 'unknow',node.name1
	#seek_padding(self,self.input.tell(),4)	
	if self.debug==True:debugFile.write(' '*n+str(values)+'\n')
	#cell.data=values	
		
	
def getSection(self,node,n,cellParent):
	n+=4
	values=None
	cell=Cell()
	cellParent.children.append(cell)
	if self.debug==True:
		debugFile.write(' '*n+node.name1+'\n')
		debugFile.write(' '*n+node.name2+'\n')
		debugFile.write(' '*n+str(node.info)+'\n')
		debugFile.write(' '*n+'offset-'+str(self.input.tell())+'\n')
	node.offset=self.input.tell()
	cell.name1=node.name1
	cell.name2=node.name2
		  
	if node.name2!='data':
		if node.name1=='SInt32':go_to_size(self,node,n,cell)
		elif node.name1=='SInt16':go_to_size(self,node,n,cell)
		elif node.name1=='UInt32':go_to_size(self,node,n,cell)
		elif node.name1=='UInt16':go_to_size(self,node,n,cell)
		elif node.name1=='int':go_to_size(self,node,n,cell)
		elif node.name1=='unsigned int':go_to_size(self,node,n,cell)
		elif node.name1=='float':go_to_size(self,node,n,cell)
		elif node.name1=='UInt8':go_to_size(self,node,n,cell)
		elif node.name1=='bool':go_to_size(self,node,n,cell)		
		else:
			seek_padding(self,self.input.tell(),4)	
			children=node.children
			for child in children:
				getSection(self,child,n,cell)
			seek_padding(self,self.input.tell(),4)
		
		
	elif node.name2=='data':
		go_to_data(self,node,n,cell)	

	
def getChunk(self,chunkID):
	CHUNK=None
	for chunk in self.chunkList:
		#print chunk.ID
		if chunk.ID==chunkID:
			CHUNK=chunk
	return CHUNK		
		
		
def readBlock(self,info,chunk):
	#print 'readblock:',info
	global debugFile
	#print self.dataOffset,info[1]
	self.input.seek(self.dataOffset+info[1])
	
	if self.debug==True:
		debugFile=open(self.debugDir+os.sep+'block-'+str(info[0])+'-'+chunk.name1+'.debug.txt','w')
	n=0
	if self.debug==True:
		debugFile.write(' '*n+chunk.name1+'\n')
		debugFile.write(' '*n+chunk.name2+'\n')
		#self.debugFile.write(' '*n+str(block.info)+'\n')
	cell=Cell()	
	self.cellList=cell
	cell.name1=chunk.name1
	cell.name2=chunk.name2
	if self.debug==True:
		cell.debugFile=debugFile
	for node in chunk.children:
		getSection(self,node,n,cell)
	if self.debug==True:debugFile.close()		
	return cell
		
def blockParser(self,blockName):
	#print
	#print 'blockParser=====>blockParser:',blockName
	dataList=[]
	for i,blockInfo in enumerate(self.blockInfoList):
		#print blockInfo
		block=getChunk(self,blockInfo[3])
		if block is not None:
			if block.name1==blockName:
				data=readBlock(self,blockInfo,block)
				dataList.append([data,blockInfo])
	return dataList
	
				