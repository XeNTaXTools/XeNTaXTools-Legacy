


def m_Skin(self,cell,meshInfo):
	for child in cell.children:
		if child.name2=='Array':
			for child1 in child.children:
				if child1.name2=='size':
					meshInfo.skinCount=child1.data
				if child1.name2=='data':
					for child2 in child1.children:
						indiceList=[]
						weightList=[]
						for child3 in child2.children:
							if child3.name2=='weight[0]':
								weightList.append(child3.data)
							if child3.name2=='weight[1]':
								weightList.append(child3.data)
							if child3.name2=='weight[2]':
								weightList.append(child3.data)
							if child3.name2=='weight[3]':
								weightList.append(child3.data)
								
							if child3.name2=='boneIndex[0]':
								indiceList.append(child3.data)
							if child3.name2=='boneIndex[1]':
								indiceList.append(child3.data)
							if child3.name2=='boneIndex[2]':
								indiceList.append(child3.data)
							if child3.name2=='boneIndex[3]':
								indiceList.append(child3.data)
						meshInfo.skinIndiceList.append(indiceList)
						meshInfo.skinWeightList.append(weightList)
						#print indiceList