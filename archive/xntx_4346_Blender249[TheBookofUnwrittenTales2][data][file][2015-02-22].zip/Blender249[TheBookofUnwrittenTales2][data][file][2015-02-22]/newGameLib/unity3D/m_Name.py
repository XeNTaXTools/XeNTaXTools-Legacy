				
def m_Name(self,cell,meshInfo):
	for node in cell.children:
		if node.name2=='Array':
			for node1 in node.children:
				if node1.name2=='data':
					meshInfo.meshName=node1.data
					print 'mesh name:',	node1.data