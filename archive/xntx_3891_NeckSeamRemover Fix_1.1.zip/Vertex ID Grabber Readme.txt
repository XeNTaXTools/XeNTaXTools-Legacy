Vertex ID Grabber
==================
In 3DS Max, after selecting some vertices, run this script.
And then Script listener will disply the list of VertexID you selected.


<<Reminder>>
The IDs will be displayed in numerical order.
Not by geometrical.
Keep in mind that when you use this.