Neck Seam Remover
==================

1. Open Source & Target Files. This program will copy data "Source��Target" so, backup the target before.
2. Input 24 numbers in each "Reference Values" text-box (Look "Number-Input-Guide.png file")
3. Check both.
4. If both checked, you can push inject button, and the data will copied.


<<Reminder>>

This program can't remove neck seam alone.
Injecting MtrCol data and body texture from source will completely remove neck seam with this.


=============================================================

This application was created for educational & creative purposes.  This application is not to redistributed without explicit permission.  This application is not to be sold under any circumstances.

By using this application, the user acknowledges the above conditions and that he or she will not use it to create content that would cause a copyright infringement or damage the reputation of the intellectual property or owner of the content being modified.  The user also acknowledges that the author will not be held responsible for any damages to any files, software or hardware through use of this application.  