#by Durik256
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("WRC 10", ".p3d")
    noesis.setHandlerTypeCheck(handle, CheckType)
    noesis.setHandlerLoadModel(handle, LoadModel)
    return 1

def CheckType(data):
    if data[:4] != b'RIFF':
        return 0
    return 1

def LoadModel(data, mdlList):
    bs = NoeBitStream(data)
    ctx = rapi.rpgCreateContext()
    
    readChunk(bs)
    
    mdl = rapi.rpgConstructModel()
    mdlList.append(mdl)
    return 1

def readChunk(bs):
    global vnum, fnum#you can create a separate mesh class, and write information to it. and at the end build a mesh
    
    id = bs.readBytes(4)
    size = bs.readInt()
    eof = bs.getOffset() + size
    print(id, size)
    
    if id == b'RIFF':
        bs.seek(42,1)#header
    
    elif id == b'PhHe':
        bs.seek(size,1)#unk header
    
    elif id == b'LIST':
        list_id = bs.readBytes(8)
        list_size = bs.readInt()
        list_eof = bs.getOffset() + list_size
        print(list_id, list_size)
        
        if list_id == b'SGLiSuGe':
            unk, vnum, fnum = bs.readShort(), bs.readInt(), bs.readInt()
            rapi.rpgSetName('mesh_%i'%bs.getOffset())
            print(unk, vnum, fnum)
        
        bs.seek(list_eof)
        
    elif id == b'Strm':
        id_stream = bs.readBytes(4)
        print('>>',id_stream)
        
        if id_stream == b'vpos':
            buf = bs.readBytes(vnum*12)
            rapi.rpgBindPositionBuffer(buf, noesis.RPGEODATA_FLOAT, 12)
        
        elif id_stream == b'vuvs':
            buf = bs.readBytes(vnum*4)
            rapi.rpgBindUV1Buffer(buf, noesis.RPGEODATA_SHORT, 4)
        
        bs.seek(eof)#<< later del it
        
    elif id == b'indx':
        buf = bs.readBytes(fnum*6)
        rapi.rpgCommitTriangles(buf, noesis.RPGEODATA_USHORT, fnum*3, noesis.RPGEO_TRIANGLE)
    
    else:
        print('Skip unknow chunk:', id)
        bs.seek(eof)#skip read child
    
    while bs.getOffset() < eof:
        readChunk(bs)
    
    bs.seek(eof)#skip chunk