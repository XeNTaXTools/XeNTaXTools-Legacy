from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Star Wars: Kinect [X360]", ".tga;.tex")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    if bs.readUInt() != 8:  return 0
    return 1   

def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    texName = rapi.getLocalFileName(rapi.getInputName()).lower()
    bs.seek(0x18)
    imgFmt = bs.readInt()
    if ".tex" in texName:
        imgWidth = bs.readUInt()
        imgHeight = bs.readUInt()
    else:
        imgWidth = bs.readUInt() // 2
        imgHeight = bs.readUInt() // 2
        if imgHeight == 2:
            imgHeight = 4
    bs.readInt()
    bs.readInt()
    bs.seek(0x34)
    data = bs.readBytes(bs.getSize() - bs.tell())
    #DXT1
    if imgFmt == 0x28:
        data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 8)
        texFmt = noesis.NOESISTEX_DXT1
    #DXT5
    elif imgFmt == 0x33:
        data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 16)
        texFmt = noesis.NOESISTEX_DXT5
    #DXT5 packed normal map
    elif imgFmt == 0x1C:
        data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 16)
        data = rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_ATI2)
        texFmt = noesis.NOESISTEX_RGBA32
    #DXT5 packed normal map2
    elif imgFmt == 0x36:
        data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 16)
        data = rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_ATI1)
        texFmt = noesis.NOESISTEX_RGBA32
    #DXT1 packed normal map
    elif imgFmt == 0x16:
        data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 8)
        data = rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_DXT1NORMAL)
        texFmt = noesis.NOESISTEX_RGBA32
    #raw
    elif imgFmt == 0x1B:
        data = rapi.imageUntile360Raw(rapi.swapEndianArray(data, 4), imgWidth, imgHeight, 4)
        texFmt = noesis.NOESISTEX_RGBA32
    #unknown, not handled
    else:
        print("WARNING: Unhandled image format " + repr(imgFmt) + " - " + repr(imgWidth) + "x" + repr(imgHeight) + " - " + repr(len(data)))
        return None
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1