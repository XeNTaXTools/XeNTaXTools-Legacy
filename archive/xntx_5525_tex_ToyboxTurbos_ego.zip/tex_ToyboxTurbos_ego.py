from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Toybox Turbos", ".ego")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
	#noesis.logPopup()
	return 1

#check if it's this type based on the data
def noepyCheckType(data):
    bs = NoeBitStream(data)
    Magic = bs.readBytes(4).decode("ASCII")
    if Magic != 'TXPC':
        return 0
    return 1
	
def noepyLoadRGBA(data, texList):
    datasize = len(data) - 0x20        
    bs = NoeBitStream(data)
    bs.seek(0xc, NOESEEK_ABS)
    imgWidth = bs.readInt()            
    imgHeight = bs.readInt()           
    imgFmt = bs.readInt()    # 1 = dxt5 ?
    bs.seek(0x20, NOESEEK_ABS)        
    data = bs.readBytes(datasize)      
    texFmt = noesis.NOESISTEX_DXT5
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1