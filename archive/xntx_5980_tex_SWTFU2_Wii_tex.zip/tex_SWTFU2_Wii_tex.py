from inc_noesis import *
import lib_zq_nintendo_tex as nintex

def registerNoesisTypes():
    handle = noesis.register("Star Wars: The Force Unleashed 2 [Wii]", ".tex")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    bs.seek(0x30, NOESEEK_ABS)
    check = bs.readInt()
    if check != 0x14509cd8:
        return 0
    return 1
    
versions = {
    0x11: nintex.NINTEX_RGBA32,
    0x13: nintex.NINTEX_I8,
    0x35: nintex.NINTEX_I4,
    0x0b: nintex.NINTEX_CMPR,
}

def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.seek(0x18, NOESEEK_ABS)
    imgFmt = bs.readUInt()
    imgWidth = bs.readUInt()
    imgHeight = bs.readUInt()
    bs.seek(0x34, NOESEEK_ABS)
    texList.append(nintex.readTexture(bs, imgWidth, imgHeight, versions[imgFmt]))
    return 1