import bpy,struct,os
import Blender
from Blender import *
from Blender.Mathutils import *
import math



def find_0(): 
    s=''
    while(True):
        litera =  struct.unpack('c',plik.read(1))[0]
        if  litera=='\x00':
            break
        else:
            s+=litera
    return s


def vertexuv():
    mesh.vertexUV = 1
    for m in range(len(mesh.verts)):
        mesh.verts[m].uvco = Vector(uvlist[m])
    mesh.update() 
    mesh.faceUV = 1
    for fc in mesh.faces: fc.uv = [v.uvco for v in fc.verts];fc.smooth = 1
    mesh.update()   


def b(n):
    return struct.unpack(n*'b', plik.read(n))
def B(n):
    return struct.unpack(n*'B', plik.read(n))
def h(n):
    return struct.unpack(n*'h', plik.read(n*2))
def H(n):
    return struct.unpack(n*'H', plik.read(n*2))
def i(n):
    return struct.unpack(n*'i', plik.read(n*4))
def f(n):
    return struct.unpack(n*'f', plik.read(n*4))

def word(long): 
   s=''
   for j in range(0,long): 
       lit =  struct.unpack('c',plik.read(1))[0]
       if ord(lit)!=0:
           s+=lit
           if len(s)>300:
               break
   return s


def drawmesh(name): 
    global obj,mesh
    mesh = bpy.data.meshes.new(name)
    mesh.verts.extend(vertexlist)
    mesh.faces.extend(faceslist,ignoreDups=True)
    if len(uvlist)!=0:
        vertexuv()
    scene = bpy.data.scenes.active
    obj = scene.objects.new(mesh,name)
    mesh.recalcNormals()
    Redraw()


def bms():
    global vertexlist,faceslist,uvlist
    vertexlist = []
    faceslist = []
    uvlist = []
    print word(12)
    data = i(15);print data #15*4bytes
    print word(i(1)[0])
    print word(i(1)[0])

    #vertex section
    plik.seek(data[0])
    nVerts = i(1)[0];print 'nVerts =',nVerts #4 bytes
    for m in range(nVerts):
        back = plik.tell()
        vertexlist.append(f(3))#12 bytes
        plik.seek(back+24)
        uvlist.append([f(1)[0],1-f(1)[0]]) 
        if data[13]==0:
            plik.seek(back+44)            
        elif data[13]==1024:
            plik.seek(back+52)

    #faces section
    plik.seek(data[2])
    nFaces = i(1)[0];print 'nFaces =',nFaces
    for m in range(nFaces):
        faceslist.append(h(3))
        #print faceslist[m] 
    print plik.tell()


    drawmesh('model')
    Redraw()

def openfile(filename):
    global plik
    plik = open(filename,'rb')
    print '============================'
    print filename
    print '============================'
    bms()
   
     
Window.FileSelector (openfile)