from inc_noesis import *

#registerNoesisTypes is called by Noesis to allow the script to register formats.
#Do not implement this function in script files unless you want them to be dedicated format modules!
def registerNoesisTypes():
	handle = noesis.register("Precure 3DS X3D Files", ".x3d")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadModel(handle, noepyLoadModel) #see also noepyLoadModelRPG
	#noesis.setHandlerWriteModel(handle, noepyWriteModel)
	#noesis.setHandlerWriteAnim(handle, noepyWriteAnim)

	noesis.logPopup()
	#print("The log can be useful for catching debug prints from preview loads.\nBut don't leave it on when you release your script, or it will probably annoy people.")
	return 1

CINF_HEADER = 0x464e4943

def noepyCheckType(data):
	if len(data) < 4:
		return 0
	bs = NoeBitStream(data)

	if bs.readUInt() != CINF_HEADER:
		return 0

	return 1

def noepyLoadModel(data, mdlList):

	f = NoeBitStream(data)
	x3d = x3d_format()
	x3d.ReadFromFile(f)

	msh = []

	for i in range(len(x3d.verts)):
		msh.append(NoeMesh([],[],"mesh_"+str(i),"mat_"+str(i)))
		msh[i].setIndices(x3d.faces[i])
		msh[i].setPositions(x3d.verts[i])
		msh[i].setUVs(x3d.uvs[i])
		msh[i].setNormals(x3d.norms[i])
	mdlList.append(NoeModel(msh,[],[]))

	return 1

class x3d_format:
    def __init__(self):
        self.verts = []
        self.faces = []
        self.norms = []
        self.uvs = []
        self.mdlCount = 0
        self.subMdlCount = []
        self.vertCount = []
        self.faceCount = []
        self.meshCount = 0

    def ReadFromFile( self, f):
        f.seek(0x4,0)
        cinf_blockSize = f.readInt()
        f.seek(cinf_blockSize+12,1)
        shie_blockSize = f.readInt()
        f.seek(shie_blockSize+28,1)
        self.mdlCount = f.readInt()
        mdlHeadStart = f.tell()+8
        f.seek(mdlHeadStart,0)

        #Get Sub Model Counts
        for i in range( self.mdlCount):
            f.seek(64,1)
            self.subMdlCount.append(f.readInt())
            f.seek(12,1)

        #Get Sub Model Vertex and Face Counts
        for i in range(self.mdlCount):
            for j in range(self.subMdlCount[i]):
                f.seek(8,1)
                self.vertCount.append(f.readInt())
                f.seek(12,1)
                self.faceCount.append(f.readInt())
                f.seek(20,1)

        print("Vert Count: "+str(self.vertCount))
        print("Face Count: "+str(self.faceCount))
        #print("Start Vertex Offset: "+str(f.tellHex()))



        mc=0
        for i in range(self.mdlCount):
            for j in range(self.subMdlCount[i]):
                SubVertex = []
                SubNorms = []
                SubUVs = []
                for k in range(self.vertCount[mc]):
                    SubVertex.append(NoeVec3((f.readFloat(),f.readFloat(),f.readFloat())))
                    f.seek(4,1)
                    SubNorms.append(NoeVec3((f.readFloat(),f.readFloat(),f.readFloat())))
                    f.seek(8,1)
                    SubUVs.append(NoeVec3((f.readFloat(),f.readFloat(),0.0)))
                    f.seek(20,1)
                mc = mc+1
                self.verts.append(SubVertex)
                self.norms.append(SubNorms)
                self.uvs.append(SubUVs)

                #print("Face Offset: "+str(f.tellHex()))

        mc=0
        for i in range(self.mdlCount):
            for j in range(self.subMdlCount[i]):
                SubFaces = []
                tmpFaces = []
                tempFaces = []
                for k in range(self.faceCount[mc]):
                    face = f.readShort()
                    SubFaces.append(face)
                #while ((len(SubFaces)%3)>0):
                #    SubFaces.append(0)
                #tmpFaces = rapi.createTriStrip(SubFaces)
                #print(tmpFaces)
                #for k in tmpFaces:
                #    tempFaces.append(k)
                #while ((len(tempFaces)%3)>0):
                #    tempFaces.append(0)
                mc = mc+1
                #print((tmpFaces))
                self.faces.append(fixTriangles(SubFaces))

def fixTriangles(tris):
    fixedTris = []
    for i in range(2,len(tris)):
        if (i%2>0):
            fixedTris.append(tris[i-2])
            fixedTris.append(tris[i])
            fixedTris.append(tris[i-1])
        else:
            fixedTris.append(tris[i-2])
            fixedTris.append(tris[i-1])
            fixedTris.append(tris[i])
    return fixedTris
