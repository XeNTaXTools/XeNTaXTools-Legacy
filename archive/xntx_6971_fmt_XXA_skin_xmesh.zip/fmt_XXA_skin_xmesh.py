# XXA Mesh Formats (skin,lmesh,smesh,tmesh) Importer by Bigchillghost

import rapi
from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("XXA", ".skin;.lmesh;.smesh;.tmesh")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadModel(handle, noepyLoadModel)
	#noesis.logPopup()
	return 1

#check if it's this type based on the data
def noepyCheckType(data):
	if len(data) < 0x80:
		return 0
	bs = NoeBitStream(data)
	Magic = bs.readUInt()
	if Magic != 0xC8:
		return 0
	return 1

#load the model
def noepyLoadModel(data, mdlList):
	bs = NoeBitStream(data)
	bs.seek(4, NOESEEK_REL)
	meshCount = bs.readInt()
	ctx = rapi.rpgCreateContext()
	for i in range(0,meshCount):
		Len = bs.readUInt()
		meshName = noeStrFromBytes(bs.readBytes(Len), "UTF8")
		flag = bs.readInt()
		while 1:
			Len = bs.readUInt()
			if Len < 0xFF:
				bs.seek(Len, NOESEEK_REL)
			else:
				bs.seek(-4, NOESEEK_REL)
				break
		if flag == 0xA:
			bs.seek(0xC, NOESEEK_REL)
		flagArray = bs.readBytes(6)
		bs.seek(0x40, NOESEEK_REL)
		
		elementCount = 8
		elementSize = 2
		NMpos = 3
		UVpos = 6
		UV2pos = 8
		hasSecondUV = flagArray[4]
		dataType = noesis.RPGEODATA_HALFFLOAT
		if flagArray[0] == 0: # !isHalf
			dataType = noesis.RPGEODATA_FLOAT
			elementSize = 4
		if flagArray[1] == 1: # hasWeight
			skipSize = bs.readInt() * 4
			bs.seek(skipSize, NOESEEK_REL)
			if flagArray[0] == 1:
				elementCount += 5
			else:
				elementCount += 4
		if flagArray[3] == 1: # hasColor
			if flagArray[0] == 1:
				elementCount += 2
				UVpos += 2
				UV2pos += 2
			else:
				elementCount += 1
				UVpos += 1
				UV2pos += 1
		if flagArray[4] == 1: # hasSecondUV
			elementCount += 2
		if flagArray[5] == 1: # hasTangent
			elementCount += 6
		
		NMpos *= elementSize
		UVpos *= elementSize
		UV2pos *= elementSize
		structSize = elementCount * elementSize
		
		Vcount = bs.readInt()
		Vsize = Vcount * structSize
		Vbuf = bs.readBytes(Vsize)
		indexCount = bs.readInt() * 3
		idxList = bs.readBytes(indexCount * 2)
		bs.seek(0xC, NOESEEK_REL)
		rapi.rpgSetName(meshName)
		rapi.rpgBindPositionBuffer(Vbuf, dataType, structSize)
		rapi.rpgBindNormalBufferOfs(Vbuf, dataType, structSize, NMpos)
		rapi.rpgSetPosScaleBias(NoeVec3([-1,1,1]), None)
		rapi.rpgBindUV1BufferOfs(Vbuf, dataType, structSize, UVpos)
		if hasSecondUV == 1:
			rapi.rpgBindUV2BufferOfs(Vbuf, dataType, structSize, UV2pos)
		rapi.rpgCommitTriangles(idxList, noesis.RPGEODATA_USHORT, indexCount, noesis.RPGEO_TRIANGLE, 0)
		rapi.rpgClearBufferBinds()
	mdl = rapi.rpgConstructModel()
	mdlList.append(mdl)
	return 1
