from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Just Dance 3 [X360]", ".jd3")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
	#noesis.logPopup()
	return 1

def noepyCheckType(data):
    bs = NoeBitStream(data, NOE_BIGENDIAN)
    if bs.readBytes(4) != b'\xa2\xb7\xe9\x17': return 0
    return 1
	
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data, NOE_BIGENDIAN)
    bs.readBytes(4)
    # imgWidth = bs.readUInt()            
    # imgHeight = bs.readUInt()           
    bs.seek(0x68)
    imgFmt = bs.readUInt()
    print(hex(imgFmt), ":format")
    size = bs.readInt()
    print(hex(size), ":size")
    imgHeight = ((size >> 13) & 0x1FFF) + 1
    imgWidth  = (size + 1) & 0x1FFF
    print(imgWidth, "x", imgHeight)
    bs.seek(0x94)        
    datasize = bs.readUInt()
    data = bs.readBytes(datasize)      
    #DXT1
    if imgFmt == 0x52:
        data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 8)
        texFmt = noesis.NOESISTEX_DXT1
    #DXT3
    elif imgFmt == 0x53:
        data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 16)
        texFmt = noesis.NOESISTEX_DXT3
    #DXT5
    elif imgFmt == 0x54:
        data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 16)
        texFmt = noesis.NOESISTEX_DXT5
    #raw
    elif imgFmt == 0x86:
        data = rapi.imageUntile360Raw(data, imgWidth, imgHeight, 4)
        data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "a8r8g8b8")
        texFmt = noesis.NOESISTEX_RGBA32
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1