/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package unddsmerger_splsec;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

/**
 *
 * @author LH
 */
public class UnDDSMerger_SPLSEC
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        if(args.length>0)
        {
            //String filename = args[0];
            String filename = args[0];
            try
            {
                
                RandomAccessFile rf = new RandomAccessFile(filename, "r");
                //boolean SXET_ALT = false;
                //detect SXE variant
                char c1 = (char) rf.readUnsignedByte();
                char c2 = (char) rf.readUnsignedByte();
                char c3 = (char) rf.readUnsignedByte();
                char c4 = (char) rf.readUnsignedByte();
                String magix = ((Character)c1).toString()+((Character)c2).toString()+((Character)c3).toString()+((Character)c4).toString();
                System.out.println(magix);
                long i, b1,b2,b3,b4;
                if(magix.equals("SXET"))
                {
                    int j;
                    rf.seek(12);//hardcoded cause the first file offset lies there
                    b1 = rf.readUnsignedByte();
                    b2 = rf.readUnsignedByte()*256;
                    b3 = rf.readUnsignedByte()*256*256;
                    b4 = rf.readUnsignedByte()*256*256*256;
                    long headerSize = b1+b2+b3+b4;
                    b1 = rf.readUnsignedByte();
                    b2 = rf.readUnsignedByte()*256;
                    b3 = rf.readUnsignedByte()*256*256;
                    b4 = rf.readUnsignedByte()*256*256*256;
                    long filesPerArchive = b1+b2+b3+b4;
                    rf.seek(rf.getFilePointer()+16);//3 dwords of trash
                    b1 = rf.readUnsignedByte();
                    b2 = rf.readUnsignedByte()*256;
                    b3 = rf.readUnsignedByte()*256*256;
                    b4 = rf.readUnsignedByte()*256*256*256;
                    //long tailOffset = b1+b2+b3+b4+headerSize+12;
                    long start = headerSize+12;
                    String[] filenames = new String[(int)filesPerArchive];
                    long[] offsets = new long[(int)filesPerArchive];
                    long[] fileends = new long[(int)filesPerArchive];
                     
                    
                    rf.seek(rf.getFilePointer()+filesPerArchive*64);
                    //for (j = 0; j < filesPerArchive*64; j++)
                    //{
                        //b1 = rf.readUnsignedByte();//skip metadata
                        /*b1 = rf.readUnsignedByte();
                        b1 = rf.readUnsignedByte();
                        b1 = rf.readUnsignedByte();
                                b1 = rf.readUnsignedByte();
                                b2 = rf.readUnsignedByte()*256;
                                b3 = rf.readUnsignedByte()*256*256;
                                b4 = rf.readUnsignedByte()*256*256*256;
                                long id = b1+b2+b3+b4;
                        for (int k  = 0; k < 16; k++)
                        {
                        rf.readUnsignedByte();//skipping 4 dwords of trash;
                        }
                        */
                    //
                    
                    b1 = rf.readUnsignedByte();
                    b2 = rf.readUnsignedByte()*256;
                    b3 = rf.readUnsignedByte()*256*256;
                    b4 = rf.readUnsignedByte()*256*256*256;
                    long tailOffset = b1+b2+b3+b4+headerSize+12;
                    
                    rf.seek(rf.getFilePointer()+12);//3 dwords of trash
                    
                    for (j = 0; j < filesPerArchive; j++)
                    {        
                        
                          rf.seek(rf.getFilePointer()+8);
                        b1 = rf.readUnsignedByte();
                        b2 = rf.readUnsignedByte()*256;
                        b3 = rf.readUnsignedByte()*256*256;
                        b4 = rf.readUnsignedByte()*256*256*256;
                        offsets[j] = b1+b2+b3+b4+start+8;
                    }
                    for (j = 0; j < filesPerArchive-1; j++)
                    {
                        fileends[j] = offsets[j+1];
                    }
                    
                    
                    fileends[(int)filesPerArchive-1]=tailOffset;
                    rf.seek(tailOffset+8);
                    for (j = 0; j < filesPerArchive; j++)//getFileNames
                    {
                        rf.seek(rf.getFilePointer()+4);
                        b1 = rf.readUnsignedByte();
                        b2 = rf.readUnsignedByte()*256;
                        b3 = rf.readUnsignedByte()*256*256;
                        b4 = rf.readUnsignedByte()*256*256*256;
                        int stringsize= (int) (b1+b2+b3+b4);
                        String fn = "";
                        for (int k = 0; k < stringsize; k++)
                        {
                            fn += ((Character)((char) rf.readUnsignedByte())).toString();
                        }
                        filenames[j] = fn+".dds";
                    }
                    for (j = 0; j < offsets.length; j++)
                    {
                        RandomAccessFile rft = new RandomAccessFile(filename+"_"+filenames[j], "rw");
                        long fs = fileends[j]-offsets[j];
                        rf.seek(offsets[j]);
                        while(fs>1)
                        {
                            byte[] b = new byte[2048];
                            if(fs<2048)
                                b=new byte[(int)fs];
                            fs-=b.length;
                            rf.read(b);
                            rft.write(b);
                        }
                    }
                        System.out.println("HS"+headerSize);
                        System.out.printf("%8h", headerSize);
                        System.out.println();
                        System.out.println("FC"+filesPerArchive);
                        System.out.printf("%16h", filesPerArchive);
                        System.out.println();
                    
                    
                    
                /*
                }
                if(SXET_ALT)
                {    
                    while(!(rf.length()==rf.getFilePointer()))
                    {
                       long b1 = rf.readUnsignedByte();
                        long b2 = rf.readUnsignedByte()*256;
                        long b3 = rf.readUnsignedByte()*256*256;
                        long b4 = rf.readUnsignedByte()*256*256*256;
                        System.out.println(b1);
                        System.out.println(b2);
                        System.out.println(b3);
                        System.out.println(b4);
                        long i = b1+b2+b3+b4;  
                        boolean alternate=false;
                        if(i==0)
                        {
                            b1 = rf.readUnsignedByte();
                            b2 = rf.readUnsignedByte()*256;
                            b3 = rf.readUnsignedByte()*256*256;
                            b4 = rf.readUnsignedByte()*256*256*256;
                            System.out.println(b1);
                            System.out.println(b2);
                            System.out.println(b3);
                            System.out.println(b4);
                            i = b1+b2+b3+b4;     
                            alternate=true;
                        }
                        long fo = rf.getFilePointer();
                        if((((long)i)+fo)>rf.length())//SXe footer detector
                             break;
                        System.out.println(i);
                        System.out.printf("%8h", i);
                        System.out.println();
                        System.out.println(fo);
                        System.out.printf("%16h", fo);
                        System.out.println();
                        byte[] datadump = new byte[(int)i];
                        if(!alternate)
                        rf.seek(fo+4);
                        rf.read(datadump);
                        fo = rf.getFilePointer();
                        rf.seek(fo-4);
                        if(!alternate)
                            rf.seek(fo-8);
                        RandomAccessFile trg = new RandomAccessFile(filename+".id"+fo+".dds", "rw");
                        trg.write(datadump, 0, (int)i);
                        trg.close();
                    }
                  */  
                }
                else
                {
                    while(!(rf.length()==rf.getFilePointer()))
                    {
                        /*long */b1 = rf.readUnsignedByte();
                        /*long */b2 = rf.readUnsignedByte()*256;
                        /*long */b3 = rf.readUnsignedByte()*256*256;
                        /*long */b4 = rf.readUnsignedByte()*256*256*256;
                        System.out.println(b1);
                        System.out.println(b2);
                        System.out.println(b3);
                        System.out.println(b4);
                        /*long */ i = b1+b2+b3+b4;           
                        long fo = rf.getFilePointer();
                        if((((long)i)+fo)>rf.length())//SXe footer detector
                             break;
                        System.out.println(i);
                        System.out.printf("%8h", i);
                        System.out.println();
                        System.out.println(fo);
                        System.out.printf("%16h", fo);
                        System.out.println();
                        byte[] datadump = new byte[(int)i];
                        rf.read(datadump);
                        RandomAccessFile trg = new RandomAccessFile(filename+".id"+fo+".dds", "rw");
                        trg.write(datadump, 0, (int)i);
                        trg.close();
                    }
                }
            }
            catch (FileNotFoundException ex)
            {
                ex.printStackTrace();
            }
            catch (IOException ex)
            {
                ex.printStackTrace();
            }
            
        }
    }
}
