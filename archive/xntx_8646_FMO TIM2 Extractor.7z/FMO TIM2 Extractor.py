import os, re
TIM2s = []
FileCount = 0

def Duplicate_Check(TIM2s):
    for x in range(len(TIM2s)):
        if TIM2s[x] == IsolatedTIM2:
            return True

    TIM2s.append(IsolatedTIM2)
    return False

def Isolate_TIM2():
    PossibleTIM2.seek(match.start() + 16, 0)    
    size = int.from_bytes(PossibleTIM2.read(4), 'little')
    PossibleTIM2.seek(match.start(), 0)
    return PossibleTIM2.read(size + 16)    

def Write_To_New_File():
    with open('C:\Archive\Papercrafting\Front Mission\Textures\FMO PC Files' + '\\' + str(FileCount) + ' - ' + str(TIM2Count) + '.tm2', 'wb') as tm2: tm2.write(IsolatedTIM2)
  
for file in os.scandir('C:\Archive\Papercrafting\Front Mission\Textures\FMO PC Files'):
    if file.is_file and re.search('.tm2', file.name) == None:
        with open(file, 'rb') as PossibleTIM2:
            TIM2Count = 0
            FileCount += 1
            for match in re.finditer(b'TIM2', PossibleTIM2.read(file.stat().st_size)):
                IsolatedTIM2 = Isolate_TIM2()
                if Duplicate_Check(TIM2s) == False:
                    TIM2Count += 1
                    Write_To_New_File()
