﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Runtime.CompilerServices;
using System.Xml.Linq;

namespace wotunpack
{
    public partial class MainForm : Form
    {
        public string PackedFileName = "";

        public class DataDescriptor
        {
            public readonly int address;
            public readonly int end;
            public readonly int type;

            public DataDescriptor(int end, int type, int address)
            {
                this.end = end;
                this.type = type;
                this.address = address;
            }

            public override string ToString()
            {
                StringBuilder sb = new StringBuilder("[");
                sb.Append("0x");
                sb.Append(Convert.ToString(end, 16));
                sb.Append(", ");
                sb.Append("0x");
                sb.Append(Convert.ToString(type, 16));
                sb.Append("]@0x");
                sb.Append(Convert.ToString(address, 16));
                return sb.ToString();
            }
        }

        public class ElementDescriptor
        {
            public readonly int nameIndex;
            public readonly DataDescriptor dataDescriptor;

            public ElementDescriptor(int nameIndex, DataDescriptor dataDescriptor)
            {
                this.nameIndex = nameIndex;
                this.dataDescriptor = dataDescriptor;
            }

            public override string ToString()
            {
                StringBuilder sb = new StringBuilder("[");
                sb.Append("0x");
                sb.Append(Convert.ToString(nameIndex, 16));
                sb.Append(":");
                sb.Append(dataDescriptor);
                return sb.ToString();
            }
        }

        public static readonly Int32 Packed_Header = 0x62a14e45;
	
        public static readonly char[] intToBase64 = new char[]{'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '+', '/'};

        public const int MAX_LENGTH = 256;

        public XDocument xDoc;

        public MainForm(string args)
        {
            InitializeComponent();
            if (args.Length != 0)
            {
                //string[] FileList = (string[])e.Data.GetData(DataFormats.FileDrop, false);

                // Do something with the data...

                // For example add all files into a simple label control:
                    openPackedFile(args);
            }
        }

        public void verifyMagicNumber(BinaryReader reader)
        {
            Int32 head = reader.ReadInt32();
            if (head != Packed_Header)
            {
                throw new IOException("Invalid header");
            }
        }

        public string readStringTillZero(BinaryReader reader)
        {
            char[] work = new char[MAX_LENGTH];

            int i = 0;

            char c = reader.ReadChar();
            while (c != Convert.ToChar(0x00))
            {
                work[i++] = c;
                c = reader.ReadChar();
            }
            return new string(work, 0, i);

        }

        public List<string> readDictionary(BinaryReader reader)
        {
            List<string> dictionary = new List<string>();
            int counter = 0;
            string text = readStringTillZero(reader);

            while (!(text.Length == 0))
            {
                dictionary.Add(text);
                text = readStringTillZero(reader);
                counter++;
            }
            return dictionary;
        }

        public Int16 readLittleEndianShort(BinaryReader reader)
        {
            Int16 LittleEndianShort = reader.ReadInt16();
            return LittleEndianShort;
        }

        public Int32 readLittleEndianInt(BinaryReader reader)
        {
            Int32 LittleEndianInt = reader.ReadInt32();
            return LittleEndianInt;
        }

        public DataDescriptor readDataDescriptor(BinaryReader reader)
        {
            Int32 selfEndAndType = readLittleEndianInt(reader);
            return new DataDescriptor(selfEndAndType & 0x0fffffff, selfEndAndType >> 28, (int)reader.BaseStream.Position);
        }

        public ElementDescriptor[] readElementDescriptors(BinaryReader reader, int number)
        {
            ElementDescriptor[] elements = new ElementDescriptor[number];
            for (int i = 0; i < number; i++)
            {
                int nameIndex = readLittleEndianShort(reader);
                DataDescriptor dataDescriptor = readDataDescriptor(reader);
                elements[i] = new ElementDescriptor(nameIndex, dataDescriptor);
            }
            return elements;
        }

        public string readString(BinaryReader reader, int lengthInBytes)
        {
            char[] bytes = new char[lengthInBytes];

            for (int i = 0; i < lengthInBytes; i++)
            {
                bytes[i] = reader.ReadChar();
            }
            return new string(bytes, 0, lengthInBytes);
        }

        public int readNumber(BinaryReader reader, int lengthInBytes)
        {
            Int16[] bytes = new Int16[lengthInBytes];
            for (int i = 0; i < lengthInBytes; i++)
            {
                bytes[i] = reader.ReadSByte();
            }
            Int16 result = 0;
            for (int i = bytes.Length - 1; i >= 0; i--)
            {
                result <<= 8;
                result |= bytes[i];
            }
            return result;

        }

        public float readLittleEndianFloat(BinaryReader reader)
        {
            float LittleEndianFloat = reader.ReadSingle();         
            //Int32 result = 0;

            //result <<= 8;
            //result |= (Int32)LittleEndianFloat;

            return LittleEndianFloat;
        }

        public string readFloats(BinaryReader reader, int lengthInBytes)
        {
            int n = lengthInBytes / 4;
            
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < n; i++)
            {
                
                if (i != 0)
                {
                    sb.Append(" ");
                }
                //sb.Append(readLittleEndianFloat(reader));
                float rFloat = readLittleEndianFloat(reader);
                sb.Append(rFloat.ToString("0.000000"));
            }
            return sb.ToString();
        }
        

        public bool readBoolean(BinaryReader reader, int lengthInBytes)
        {
            bool @bool = lengthInBytes == 1;
            if (@bool)
            {
            if (reader.ReadSByte() != 1)
             {
                 throw new System.ArgumentException("Boolean error");
             }
            }

            return @bool;
        }

        private static string byteArrayToBase64(sbyte[] a)
        {
            int aLen = a.Length;
            int numFullGroups = aLen / 3;
            int numBytesInPartialGroup = aLen - 3 * numFullGroups;
            int resultLen = 4 * ((aLen + 2) / 3);
            StringBuilder result = new StringBuilder(resultLen);

            int inCursor = 0;
            for (int i = 0; i < numFullGroups; i++)
            {
                int byte0 = a[inCursor++] & 0xff;
                int byte1 = a[inCursor++] & 0xff;
                int byte2 = a[inCursor++] & 0xff;
                result.Append(intToBase64[byte0 >> 2]);
                result.Append(intToBase64[(byte0 << 4) & 0x3f | (byte1 >> 4)]);
                result.Append(intToBase64[(byte1 << 2) & 0x3f | (byte2 >> 6)]);
                result.Append(intToBase64[byte2 & 0x3f]);
            }

            if (numBytesInPartialGroup != 0)
            {
                int byte0 = a[inCursor++] & 0xff;
                result.Append(intToBase64[byte0 >> 2]);
                if (numBytesInPartialGroup == 1)
                {
                    result.Append(intToBase64[(byte0 << 4) & 0x3f]);
                    result.Append("==");
                }
                else
                {
                    // assert numBytesInPartialGroup == 2;
                    int byte1 = a[inCursor++] & 0xff;
                    result.Append(intToBase64[(byte0 << 4) & 0x3f | (byte1 >> 4)]);
                    result.Append(intToBase64[(byte1 << 2) & 0x3f]);
                    result.Append('=');
                }
            }

            return result.ToString();
        }

        public string readBase64(BinaryReader reader, int lengthInBytes)
        {
            sbyte[] bytes = new sbyte[lengthInBytes];
            for (int i = 0; i < lengthInBytes; i++)
            {
                bytes[i] = reader.ReadSByte();
            }
            return byteArrayToBase64(bytes);
        }

        public string readAndToHex(BinaryReader reader, int lengthInBytes)
        {
            sbyte[] bytes = new sbyte[lengthInBytes];
            for (int i = 0; i < lengthInBytes; i++)
            {
                bytes[i] = reader.ReadSByte();
            }
            StringBuilder sb = new StringBuilder("[ ");
            foreach (byte b in bytes)
            {
                sb.Append(Convert.ToString((b & 0xff), 16));
                sb.Append(" ");
            }
            sb.Append("]L:");
            sb.Append(lengthInBytes);

            return sb.ToString();
        }

        public int readData(BinaryReader reader, List<string> dictionary, XElement element, int offset, DataDescriptor dataDescriptor)
        {
            int lengthInBytes = dataDescriptor.end - offset;
            if (dataDescriptor.type == 0x0)
            {
                // Element                
                readElement(reader, element, dictionary);
            }
            else if (dataDescriptor.type == 0x1)
            {
                // String  
                element.Value = readString(reader, lengthInBytes);
            }
            else if (dataDescriptor.type == 0x2)
            {
                // Integer number
                element.Value = Convert.ToString(readNumber(reader, lengthInBytes));
            }
            else if (dataDescriptor.type == 0x3)
            {
                // Floats
                string str = readFloats(reader, lengthInBytes);

                string[] strData = str.Split(' ');
                if (strData.Length == 12)
                {
                    XElement row0 = new XElement("row0");
                    XElement row1 = new XElement("row1");
                    XElement row2 = new XElement("row2");
                    XElement row3 = new XElement("row3");
                    row0.Value = strData[0] + " " + strData[1] + " " + strData[2];
                    row1.Value = strData[3] + " " + strData[4] + " " + strData[5];
                    row2.Value = strData[6] + " " + strData[7] + " " + strData[8];
                    row3.Value = strData[9] + " " + strData[10] + " " + strData[11];
                    element.Add(row0);
                    element.Add(row1);
                    element.Add(row2);
                    element.Add(row3);
                }
                else
                {
                    element.Value = str;
                }
            }
            else if (dataDescriptor.type == 0x4)
            {
                // Boolean

                if (readBoolean(reader, lengthInBytes))
                {
                    element.Value = "true";
                }
                else
                {
                    element.Value = "false";
                }

            }
            else if (dataDescriptor.type == 0x5)
            {
                // Base64
                element.Value = readBase64(reader, lengthInBytes);
            }
            else
            {
                throw new System.ArgumentException("Unknown type of \"" + element.Name + ": " + dataDescriptor.ToString() + " " + readAndToHex(reader, lengthInBytes));
            }

            return dataDescriptor.end;
        }

        public void readElement(BinaryReader reader, XElement element, List<string> dictionary)
        {
            Int16 childrenNmber = readLittleEndianShort(reader);
            DataDescriptor selfDataDescriptor = readDataDescriptor(reader);
            ElementDescriptor[] children = readElementDescriptors(reader, childrenNmber);
            
            int offset = readData(reader, dictionary, element, 0, selfDataDescriptor);

            foreach (ElementDescriptor elementDescriptor in children)
            {
               XElement child = new XElement(dictionary[elementDescriptor.nameIndex]);               
               
               offset = readData(reader, dictionary, child, offset, elementDescriptor.dataDescriptor);
                   element.Add(child);
            }
            
        }

        public void DecodePackedFile(Stream stream)
        {
            BinaryReader reader = new BinaryReader(stream);
            verifyMagicNumber(reader);
            reader.ReadSByte();
            List<string> dictionary = readDictionary(reader);
   
            XElement xmlroot = new XElement("root");

            readElement(reader, xmlroot, dictionary);
            
            xDoc.Add(xmlroot);

            txtOut.AppendText(xDoc.ToString());            
        }

        public void openPackedFile(string file)
        {
            xDoc = new XDocument();
            txtOut.Clear();
            PackedFileName = Path.GetFileName(file);
            PackedFileName = PackedFileName.ToLower();
            FileStream F = new FileStream(file, FileMode.Open, FileAccess.Read);
            DecodePackedFile(F);
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (var ofd = new OpenFileDialog { Filter = "WoT Packed XML|*.xml;*.def;*.visual;*.model;*.animation;*.anca|All files|*.*" })
                if (DialogResult.OK == ofd.ShowDialog())
                {
                    openPackedFile(ofd.FileName);
                }
        }

        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (var sfd = new SaveFileDialog { Filter = "Unpacked XML|*.xml" })
                if (DialogResult.OK == sfd.ShowDialog())
                {
                    txtOut.SaveFile(sfd.FileName, RichTextBoxStreamType.UnicodePlainText);
                }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            // Add event handlers for the drag & drop functionality

            this.DragEnter += new DragEventHandler(MainForm_DragEnter);
            this.DragDrop += new DragEventHandler(MainForm_DragDrop);
        }

        void MainForm_DragEnter(object sender, DragEventArgs e)
        {
            // Check if the Dataformat of the data can be accepted
            // (we only accept file drops from Explorer, etc.)
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
                e.Effect = DragDropEffects.Copy; // Okay
            else
                e.Effect = DragDropEffects.None; // Unknown data, ignore it

        }

        // Occurs when the user releases the mouse over the drop target 
        void MainForm_DragDrop(object sender, DragEventArgs e)
        {
            // Extract the data from the DataObject-Container into a string list
            string[] FileList = (string[])e.Data.GetData(DataFormats.FileDrop, false);

            // Do something with the data...

            // For example add all files into a simple label control:
            foreach (string File in FileList)
                openPackedFile(File);
                //this.label.Text += File + "\n";
        }
    }
}
