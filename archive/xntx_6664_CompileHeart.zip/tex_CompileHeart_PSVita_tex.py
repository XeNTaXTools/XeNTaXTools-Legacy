from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Compile Heart [PS Vita]", ".tex")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    if noeStrFromBytes(bs.readBytes(8)) != "Texture ": return 0
    return 1

def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.seek(0x8, NOESEEK_ABS)
    filesize = bs.readUInt()
    imgFmt = bs.readUShort()
    flags = bs.readUShort()
    datasize = bs.readUInt()
    imgWidth = bs.readUInt()
    imgHeight = bs.readUInt()
    print(imgWidth, "x", imgHeight)
    data = bs.readBytes(imgWidth * imgHeight)
    palette = bs.readBytes(0x400)
    data = rapi.imageDecodeRawPal(data, palette, imgWidth, imgHeight, 8, "r8 g8 b8 a8")
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, noesis.NOESISTEX_RGBA32))
    return 1