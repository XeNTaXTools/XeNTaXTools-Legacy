
from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Oddworld Munch's Oddysee HD", ".PS3")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
	#noesis.logPopup()
	return 1

#check if it's this type based on the data
def noepyCheckType(data):
	bs = NoeBitStream(data)
	Magic = bs.readBytes(4)
	if Magic != b'FORM':
		return 0
	return 1
	
def noepyLoadRGBA(data, texList):
	bs = NoeBitStream(data)
	bs.seek(0x20, NOESEEK_ABS)
	imgWidth = bs.readUInt()
	bs.seek(0x8, NOESEEK_REL)
	imgHeight = bs.readUInt()
	bs.seek(0x14, NOESEEK_REL)
	MipmapNum = bs.readUInt()
	bs.seek(0x8, NOESEEK_REL)
	MapType = bs.readUInt()
	bs.seek(0x4, NOESEEK_REL)
	bs.setEndian(NOE_BIGENDIAN)
	dataSize = bs.readUInt()
	data = bs.readBytes(dataSize)
	if MapType == 0x25:
		texFmt = noesis.NOESISTEX_DXT5
	else:
		noesis.logPopup()
		print("Error: unhandled image format: %d"%MapType)
		return 0	
	tex = NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt)
	tex.setMipCount(MipmapNum)
	texList.append(tex)
	return 1