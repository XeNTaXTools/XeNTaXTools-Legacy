﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using GMWare.IO;

namespace GrafExtractorSkeleton
{
    /// <summary>
    /// Managed representation of a GRAF archive
    /// </summary>
    public sealed class GrafArch : IDisposable
    {
        /* To implement a GRAF extractor:
         * 
         * 1. Add the variables you need for reading the GRAF
         * 2. Change the FileEntry class to correspond to your GRAF format
         * 3. Modify ReadDirectory() to load the GRAF and read all FileEntrys
         * 
         * This skeleton is set up for the "Directory Archives" pattern as defined on the DGTEFF page on the Xentax Wiki.
         */

        /* To-do:
         * 
         * - Add overwrite confirmation to ExtractAll().
         */

        // Constants
        static readonly string MagicNumber = "GRAF"; // Format identifier at beginning of archive

        // IO objects
        Stream grafStream;
        BinaryReader grafReader; // BinaryReader is usually little endian. To read big endian, try this: http://bytes.com/topic/c-sharp/answers/454822-binarywriter-reader-big-endian#post1740375
        //BinaryWriter grafWriter; // For GRAF writing support

        // GRAF structural objects
        int archVersion;
        int dataOffset;
        List<FileEntry> files = new List<FileEntry>();
        bool disposed = false;

        // Properties
        /// <summary>
        /// Gets an enumerable collection of file entries.
        /// </summary>
        public IEnumerable<FileEntry> Files
        {
            get
            {
                if (disposed) throw new ObjectDisposedException(null);
                return files; // External code should not be modifying the files list directly, so return as IEnumerable
            }
        }

        /// <summary>
        /// Instantiate a new GRAF representation.
        /// </summary>
        /// <param name="archPath">Path to GRAF archive.</param>
        public GrafArch(string archPath)
        {
            if (string.IsNullOrEmpty(archPath)) throw new ArgumentNullException("archPath");
            Console.WriteLine("Opening {0}", archPath);
            grafStream = File.OpenRead(archPath); // Change to "File.Open(archPath, FileMode.OpenOrCreate, FileAccess.ReadWrite)" if you need writing
            grafReader = new BinaryReader(grafStream, Encoding.ASCII); // Remember to change encoding if the GRAF happens to not be using ASCII for file names
            //grafWriter = new BinaryWriter(grafStream, Encoding.ASCII);
        }

        /// <summary>
        /// Load existing files from GRAF.
        /// </summary>
        public void ReadDirectory()
        {
            if (disposed) throw new ObjectDisposedException(null);

            Console.WriteLine("Reading file table...");

            // Reset stream position; assuming seekable
            grafStream.Seek(0, SeekOrigin.Begin);
            files.Clear();

            // Check if this archive can be read
            if (new string(grafReader.ReadChars(MagicNumber.Length)) != MagicNumber) throw new FormatException("Archive does not have expected magic number.");
            archVersion = grafReader.ReadInt32();
            if (archVersion != 1) throw new FormatException(string.Format("Cannot read the archive's version of the format. (Archive version {0})", archVersion));

            // Read some header stuff
            int fileCount = grafReader.ReadInt32();
            dataOffset = grafReader.ReadInt32();

            // Read all file entries
            //Console.WriteLine("File name\tOffset\tLength"); // I usually like to output file entries as they're read. For debug only.
            for (int i = 0; i < fileCount; ++i)
            {
                FileEntry entry = new FileEntry();
                int nameLen = grafReader.ReadInt32();
                // Trick for reading non C# serialized strings: Read string as char[], then do "new string(charArr)".
                entry.FileName = new string(grafReader.ReadChars(nameLen));
                entry.Offset = grafReader.ReadInt32();
                entry.Length = grafReader.ReadInt32();
                files.Add(entry);
                //Console.WriteLine("{0}\t{1}\t{2}", entry.FileName, entry.Offset, entry.Length); // Debug
            }
            Console.WriteLine("Done reading file table.");
        }

        /// <summary>
        /// Extracts a file to disk.
        /// </summary>
        /// <param name="entry">Entry of file to extract</param>
        /// <param name="extractPath">Path to the extracted file</param>
        public void ExtractFile(FileEntry entry, string extractPath)
        {
            if (disposed) throw new ObjectDisposedException(null);
            if (entry == null) throw new ArgumentNullException("entry");
            if (string.IsNullOrEmpty(extractPath)) throw new ArgumentNullException("extractPath");

            Directory.CreateDirectory(Path.GetDirectoryName(extractPath)); // FileStream() will complain if the file's directory doesn't exist
            using (FileStream stream = File.Create(extractPath))
            {
                ExtractFile(entry, stream);
            }
        }

        /// <summary>
        /// Extracts a file to a stream.
        /// </summary>
        /// <param name="entry">Entry of file to extract</param>
        /// <param name="extractStream">Stream to write the file to</param>
        public void ExtractFile(FileEntry entry, Stream extractStream)
        {
            if (disposed) throw new ObjectDisposedException(null);
            if (entry == null) throw new ArgumentNullException("entry");
            if (extractStream == null) throw new ArgumentNullException("extractStream");

            if (!files.Contains(entry)) throw new ArgumentException("File entry is not in this archive.", "entry");

            grafStream.Seek(dataOffset + entry.Offset, SeekOrigin.Begin); // Seek to file start
            StreamUtils.StreamCopyWithLength(grafStream, extractStream, entry.Length); // Copy data to file stream
            extractStream.Flush();
        }

        /// <summary>
        /// Extracts all files to a directory.
        /// </summary>
        /// <param name="outputDir">Directory to extract file to</param>
        public void ExtractAll(string outputDir)
        {
            if (disposed) throw new ObjectDisposedException(null);
            if (string.IsNullOrEmpty(outputDir)) throw new ArgumentNullException("outputDir");

            foreach (FileEntry entry in files)
            {
                // Try to extract as many files as possible
                try
                {
                    Console.WriteLine("Extracting {0}", entry.FileName);
                    string outPath = Path.Combine(outputDir, entry.FileName);
                    ExtractFile(entry, outPath);
                }
                catch (Exception e)
                {
                    Console.WriteLine("Error extracting {0} ({1})", entry.FileName, e.Message);
                }
            }
        }

        #region IDisposable Members

        public void Dispose()
        {
            disposed = true;
            grafStream.Close();
        }

        #endregion
    }
}
