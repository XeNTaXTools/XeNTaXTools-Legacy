from inc_noesis import *
import noesis
import rapi

def registerNoesisTypes():
    handle = noesis.register("Just Cause 3", ".rbm")    #change this extension
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    bs.seek(0x4, NOESEEK_ABS)              
    Magic = bs.readBytes(5).decode("ASCII")
    print(Magic)
    if Magic != "RBMDL": 
        return 0
    return 1   

def noepyLoadModel(data, mdlList):
    ctx = rapi.rpgCreateContext()
    rapi.setPreviewOption("setAngOfs","0 -30 90")         #set the default preview angle        
    bs = NoeBitStream(data)
    bs.seek(0x5ca, NOESEEK_ABS)              
    numTextures = bs.readUInt()
    for i in range(numTextures):
        texPathNameSize = bs.readUInt() - 1
        texPathName = bs.readBytes(texPathNameSize).decode("ASCII")
        skipDelimiter = bs.readByte()
        print(texPathName, ":texture path")
        texName = texPathName.split("/")
        texName = texName[-1]
        print(texName, ":texture name")
    skip = bs.readBytes(16)
    VCount = bs.readUInt()
    VBuf = bs.readBytes(VCount * 12)
    UVCount = bs.readUInt()
    UVBuf = bs.readBytes(UVCount * 24)
    FCount = bs.readUInt()                                 #face indices count
    IBuf = bs.readBytes(FCount * 2)                       #multiply by 2 for word, 4 for dword indices 
    rapi.rpgBindPositionBufferOfs(VBuf, noesis.RPGEODATA_FLOAT, 12, 0)   #position of vertices
    rapi.rpgBindUV1BufferOfs(UVBuf, noesis.RPGEODATA_FLOAT, 24, 0)   #UV1
    checkTri = int(FCount % 3)                            #check if FCount is evenly divisible by 3,
    if checkTri == 0:
        rapi.rpgCommitTriangles(IBuf, noesis.RPGEODATA_SHORT, FCount, noesis.RPGEO_TRIANGLE, 1) #SHORT for word , INT for dword
    else:
        rapi.rpgCommitTriangles(IBuf, noesis.RPGEODATA_SHORT, FCount, noesis.RPGEO_TRIANGLE_STRIP, 1) #SHORT for word , INT for dword
    mdl = rapi.rpgConstructModel()                                                          
    mdlList.append(mdl)
    rapi.rpgClearBufferBinds()
    return 1