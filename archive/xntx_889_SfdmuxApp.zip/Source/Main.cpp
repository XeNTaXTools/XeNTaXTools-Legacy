// Mux.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Sfdmux.h"

long __stdcall Callback(void* UserData, void* Pointer)
{
	if(UserData==(void*)0xFFFFFFFF)
	{
		std::cout << (const char*)Pointer;
	}
	else
	{
		//std::cout << "Callback function called: " << UserData << ", " << Pointer << std::endl;
	}
	return 0;
}

int _tmain(int Argc, _TCHAR* Argv[])
{
	// String the arguments together
	std::string Arguments;
	for(unsigned long i=1;i<Argc;i++)
	{
		Arguments.append("\"");
		Arguments.append(Argv[i]);
		Arguments.append("\" ");
	}

	// Set up a callback function that will recieve the output strings (modified Sfdmux.dll)
	SFM::SetProgFunc(Callback, NULL);

	// Call the multiplexer
	SFM::ExecMultiplex(Arguments.c_str());
	return 0;
}

