// Sfdmux.h : Sfdmux

#include "stdafx.h"
#include "Sfdmux.h"

// Define the functions from the import library
extern "C" {
	long SFM_ExecMultiplex(const char* Filename);
	const char* SFM_GetVerStr();
	unsigned short SFM_GetVersion();
	void SFM_SetProgFunc(SFM::TCallback Function, void* UserData);
}

const char* SFM::GetVerStr()
{
	const char* ReturnValue;
	__asm
	{
		call SFM_GetVerStr
		mov ReturnValue, eax
	};
	return ReturnValue;
}

unsigned short SFM::GetVersion()
{
	unsigned short ReturnValue;
	__asm
	{
		call SFM_GetVersion
		mov ReturnValue, ax
	};
	return ReturnValue;
}

long SFM::ExecMultiplex(const char* Filename)
{
	long ReturnValue;
	__asm
	{
		push Filename
		call SFM_ExecMultiplex
		mov ReturnValue, eax
	};
	return ReturnValue;
}

void SFM::SetProgFunc(TCallback Function, void* UserData)
{
	__asm
	{
		push UserData
		push Function
		call SFM_SetProgFunc
	};
	return;
}
