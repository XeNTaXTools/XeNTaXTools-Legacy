// Sfdmux.h : Sfdmux

#pragma once

namespace SFM
{
	typedef long (__stdcall *TCallback)(void* UserData, void* Pointer);

	const char* GetVerStr();
	unsigned short GetVersion();
	long ExecMultiplex(const char* Filename);
	void SetProgFunc(TCallback Function, void* UserData);
};
