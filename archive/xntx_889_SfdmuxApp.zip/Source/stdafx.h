// stdafx.h : Precompiled header

#pragma once

#include <iostream>
#include <tchar.h>
