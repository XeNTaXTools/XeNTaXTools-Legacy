from inc_noesis import *
import collections

def registerNoesisTypes():
	handle = noesis.register("Natsuiro High School GTF Texture", ".gtf")
	noesis.setHandlerTypeCheck(handle, gtfCheckType)
	noesis.setHandlerLoadRGBA(handle, gtfLoadRGBA)
	#noesis.setHandlerWriteRGBA(handle, gtfWriteRGBA)
	return 1

GTF_HEADER_SIZE = 12

class GtfFile:
	def __init__(self, bs):
		self.bs = bs

	def parseImageInfo(self):
		bs = self.bs
		if bs.readUInt() != 0x020200FF:
			return 0
		if bs.dataSize < bs.readUInt():
			return 0
		return 1

	# Tex information
	texInfos = collections.namedtuple('texInfos', ' '.join((
		'texID',
		'texOffset',
		'texSize',
		'texType',
		'texMip',
		'tex2',
		'texUnk',
		'texWidth',
		'texHeight',
		'texDepth',
		'texFlag01',
		'texFlag02',
		'texFlag03'
	)))


def gtfCheckType(data):
	gtf = GtfFile(NoeBitStream(data, NOE_BIGENDIAN))
	if gtf.parseImageInfo() == 0:
		return 0
	return 1

def gtfLoadRGBA(data, texList):
	texInfo = []
	bs = NoeBitStream(data, NOE_BIGENDIAN)
	magic, dataSize, texCount = bs.read(">" + "3i")
	#print(magic, dataSize, texCount)
	for a in range(0, texCount):
		texInfo.append(GtfFile.texInfos(*bs.read(">3I2BI4H2IH")))
		#print(texInfo[a])
	for a in range(0, texCount):
		bs.seek(texInfo[a].texOffset, NOESEEK_ABS)
		if texInfo[a].texType == 133:
			texFmt = noesis.NOESISTEX_RGBA32
			#print("RGBA32")
		elif texInfo[a].texType == 134:
			texFmt = noesis.NOESISTEX_DXT1
			#print("DXT1")
		elif texInfo[a].texType == 135:
			texFmt = noesis.NOESISTEX_DXT3
			#print("DXT3")
		elif texInfo[a].texType == 136:
			texFmt = noesis.NOESISTEX_DXT5
			#print("DXT5")
		elif texInfo[a].texType == 158:
			texFmt = noesis.NOESISTEX_RGBA32
			#print("RGBA32")
		elif texInfo[a].texType == 166:
			texFmt = noesis.NOESISTEX_DXT1
			#print("DXT1")
		elif texInfo[a].texType == 167:
			texFmt = noesis.NOESISTEX_DXT3
			#print("DXT3")
		elif texInfo[a].texType == 168:
			texFmt = noesis.NOESISTEX_DXT5
			#print("DXT5")

		texData = bs.readBytes(texInfo[a].texSize)
		tex1 = NoeTexture(str(a), texInfo[a].texWidth, texInfo[a].texHeight, texData, texFmt)
		texList.append(tex1)
	return 1



def gtfWriteRGBA(data, width, height, bs):
	return 1





