﻿using Steamworks;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnityEngine;

public class Chapter1ScriptBehavior : BaseScriptBehavior
{
    private BuddyStatus currentStatus;
    private bool dislikesColdplay;

    private void AddBuddyListRowForSteamFriend(CSteamID steamID, EPersonaState state, int buddyIndex)
    {
        BuddyListBehavior instance = BuddyListBehavior.Instance;
        string friendPersonaName = SteamFriends.GetFriendPersonaName(steamID);
        BuddyInfoData buddyInfo = ChatBuddyInfos.GetBuddyInfo(buddyIndex);
        if (state == EPersonaState.k_EPersonaStateOnline)
        {
            instance.AddBuddyRow(friendPersonaName, buddyInfo.text, buddyInfo.color, BuddyStatus.Online, null);
        }
        else
        {
            instance.AddBuddyRow(friendPersonaName, buddyInfo.text, buddyInfo.color, BuddyStatus.Away, buddyInfo.awayText);
        }
    }

    private void AddSteamFriendsIfAvailable()
    {
        if (SteamManager.Initialized)
        {
            <AddSteamFriendsIfAvailable>c__AnonStorey25 storey = new <AddSteamFriendsIfAvailable>c__AnonStorey25();
            List<CSteamID> list = new List<CSteamID>();
            storey.coplayFriends = new List<CSteamID>();
            List<string> list2 = new List<string>();
            storey.friendStates = new Dictionary<CSteamID, EPersonaState>();
            storey.coplayTimes = new Dictionary<CSteamID, int>();
            for (int i = 0; i < SteamFriends.GetFriendCount(EFriendFlags.k_EFriendFlagImmediate); i++)
            {
                CSteamID friendByIndex = SteamFriends.GetFriendByIndex(i, EFriendFlags.k_EFriendFlagImmediate);
                string friendPersonaName = SteamFriends.GetFriendPersonaName(friendByIndex);
                if ((friendPersonaName.Length < 0x10) && !list2.Contains(friendPersonaName))
                {
                    list.Add(friendByIndex);
                    list2.Add(friendPersonaName);
                    storey.friendStates.Add(friendByIndex, SteamFriends.GetFriendPersonaState(friendByIndex));
                }
            }
            for (int j = 0; j < SteamFriends.GetCoplayFriendCount(); j++)
            {
                CSteamID coplayFriend = SteamFriends.GetCoplayFriend(j);
                storey.coplayFriends.Add(coplayFriend);
                storey.coplayTimes.Add(coplayFriend, SteamFriends.GetFriendCoplayTime(coplayFriend));
            }
            if (list.Count != 0)
            {
                if (list.Count > 2)
                {
                    list.Sort(new Comparison<CSteamID>(storey.<>m__3));
                }
                this.AddBuddyListRowForSteamFriend(list[0], storey.friendStates[list[0]], 0);
                if (list.Count > 1)
                {
                    this.AddBuddyListRowForSteamFriend(list[1], storey.friendStates[list[1]], UnityEngine.Random.Range(1, 3));
                }
            }
        }
    }

    [DebuggerHidden]
    private IEnumerator BuddyIconReplyRunner()
    {
        return new <BuddyIconReplyRunner>c__Iterator7 { <>f__this = this };
    }

    public override void DidPressInfoButton()
    {
        BuddyInfoBehavior.Instance.SetUp(ChatValues.OtherUsername, ChatValues.Script1BuddyInfo, Color.black, this.currentStatus, null);
        BuddyInfoBehavior.Instance.Show();
    }

    public override void DidPressTextButton(int index)
    {
        base.answer = index;
    }

    [DebuggerHidden]
    private IEnumerator GenericResponseRunner()
    {
        return new <GenericResponseRunner>c__Iterator6 { <>f__this = this };
    }

    public override void PlayScript()
    {
        TaskBarBehavior.Instance.SetState(TaskBarState.BuddyList);
        BuddyListBehavior.Instance.Show();
        DisplayManagerBehavior.Instance.SetBuddyIcons(ChatValues.GetPlayerBuddyIcon(), BuddyIconType.EmilyColdplay);
        base.StartCoroutine(this.ScriptRunner());
    }

    [DebuggerHidden]
    private IEnumerator ScriptRunner()
    {
        return new <ScriptRunner>c__Iterator8 { <>f__this = this };
    }

    public override void SetUpBuddyList()
    {
        try
        {
            this.AddSteamFriendsIfAvailable();
        }
        catch (Exception)
        {
        }
        BuddyListBehavior instance = BuddyListBehavior.Instance;
        instance.AddBuddyRow(ChatValues.OtherUsername, ChatValues.Script1BuddyInfo, Color.black, BuddyStatus.Offline, null);
        instance.AddBuddyRow(ChatValues.JulieUsername, ChatValues.Script1JulieInfo, ChatValues.ColorFromRGB(15, 0, 0x36), BuddyStatus.Online, null);
        instance.AddBuddyRow(ChatValues.TravisUsername, ChatValues.Script1TravisInfo, ChatValues.ColorFromRGB(0xac, 220, 0xff), BuddyStatus.Away, ChatValues.Script1TravisAway);
        instance.AddBuddyRow(ChatValues.BradUsername, ChatValues.Script1BradInfo, ChatValues.ColorFromRGB(0x27, 4, 4), BuddyStatus.Away, ChatValues.Script1BradAway);
        instance.AddOfflineOnlyBuddyRow("MaeNITW");
        instance.AddOfflineOnlyBuddyRow("BrookHorse7");
        instance.AddOfflineOnlyBuddyRow("Isaac666");
        instance.AddOfflineOnlyBuddyRow("JobBot");
        instance.AddOfflineOnlyBuddyRow("H3RST0RY");
    }

    [CompilerGenerated]
    private sealed class <AddSteamFriendsIfAvailable>c__AnonStorey25
    {
        internal List<CSteamID> coplayFriends;
        internal Dictionary<CSteamID, int> coplayTimes;
        internal Dictionary<CSteamID, EPersonaState> friendStates;

        internal int <>m__3(CSteamID friend1, CSteamID friend2)
        {
            EPersonaState state = this.friendStates[friend1];
            int num = 0;
            switch (state)
            {
                case EPersonaState.k_EPersonaStateAway:
                case EPersonaState.k_EPersonaStateSnooze:
                case EPersonaState.k_EPersonaStateBusy:
                    num = 1;
                    break;

                default:
                    if (state != EPersonaState.k_EPersonaStateOnline)
                    {
                        num = 2;
                    }
                    break;
            }
            EPersonaState state2 = this.friendStates[friend2];
            int num2 = 0;
            switch (state2)
            {
                case EPersonaState.k_EPersonaStateAway:
                case EPersonaState.k_EPersonaStateSnooze:
                case EPersonaState.k_EPersonaStateBusy:
                    num2 = 1;
                    break;

                default:
                    if (state2 != EPersonaState.k_EPersonaStateOnline)
                    {
                        num2 = 2;
                    }
                    break;
            }
            int num3 = num.CompareTo(num2);
            if (num3 != 0)
            {
                return num3;
            }
            if (this.coplayFriends.Contains(friend1) && this.coplayFriends.Contains(friend2))
            {
                int num4 = this.coplayTimes[friend2];
                return num4.CompareTo(this.coplayTimes[friend1]);
            }
            if (this.coplayFriends.Contains(friend1))
            {
                return -1;
            }
            if (this.coplayFriends.Contains(friend2))
            {
                return 1;
            }
            return ((UnityEngine.Random.Range(0, 2) != 0) ? 1 : -1);
        }
    }

    [CompilerGenerated]
    private sealed class <BuddyIconReplyRunner>c__Iterator7 : IEnumerator, IDisposable, IEnumerator<object>
    {
        internal object $current;
        internal int $PC;
        internal Chapter1ScriptBehavior <>f__this;
        internal bool <didMessUp>__2;
        internal EffectsBehavior <effects>__3;
        internal BuddyIconType <playerIcon>__1;
        internal string <text>__0;

        [DebuggerHidden]
        public void Dispose()
        {
            this.$PC = -1;
        }

        public bool MoveNext()
        {
            List<WaitingAction> list;
            uint num = (uint) this.$PC;
            this.$PC = -1;
            switch (num)
            {
                case 0:
                    this.<text>__0 = string.Empty;
                    this.<playerIcon>__1 = ChatValues.GetPlayerBuddyIcon();
                    if (this.<playerIcon>__1 != BuddyIconType.SecretEmily)
                    {
                        if (this.<playerIcon>__1 != BuddyIconType.SecretBrad)
                        {
                            if (this.<playerIcon>__1 != BuddyIconType.SecretTravis)
                            {
                                if (this.<playerIcon>__1 == BuddyIconType.SecretJulie)
                                {
                                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 1.5f) }));
                                    this.$PC = 0x1a;
                                }
                                else if (this.<playerIcon>__1 == BuddyIconType.SecretRobotLovesKitty)
                                {
                                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.GenericResponseRunner());
                                    this.$PC = 30;
                                }
                                else if (this.<playerIcon>__1 != BuddyIconType.SecretHJTenchi)
                                {
                                    if (this.<playerIcon>__1 != BuddyIconType.SecretChilledChaos)
                                    {
                                        if (this.<playerIcon>__1 == BuddyIconType.SecretKappa)
                                        {
                                            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 1.5f) }));
                                            this.$PC = 0x31;
                                        }
                                        else if (this.<playerIcon>__1 == BuddyIconType.SecretZelda)
                                        {
                                            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 1.5f) }));
                                            this.$PC = 0x35;
                                        }
                                        else if (this.<playerIcon>__1 == BuddyIconType.SecretMinecraft)
                                        {
                                            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 1.5f) }));
                                            this.$PC = 0x3a;
                                        }
                                        else if (this.<playerIcon>__1 != BuddyIconType.SecretHalflife)
                                        {
                                            if (this.<playerIcon>__1 != BuddyIconType.SecretFallout)
                                            {
                                                if (this.<playerIcon>__1 == BuddyIconType.SecretCibele)
                                                {
                                                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 1f) }));
                                                    this.$PC = 0x4c;
                                                }
                                                else if (this.<playerIcon>__1 == BuddyIconType.SecretSunlight)
                                                {
                                                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 2f) }));
                                                    this.$PC = 80;
                                                }
                                                else if (this.<playerIcon>__1 != BuddyIconType.SecretStanley)
                                                {
                                                    if (this.<playerIcon>__1 != BuddyIconType.SecretElegy)
                                                    {
                                                        if (this.<playerIcon>__1 == BuddyIconType.SecretDodgeball)
                                                        {
                                                            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 1.5f) }));
                                                            this.$PC = 0x69;
                                                        }
                                                        else if (this.<playerIcon>__1 == BuddyIconType.SecretJobSim)
                                                        {
                                                            this.<>f__this.dmb.ShowStatusLabel("this simulation will show you how to job as a human teenager");
                                                            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 2.5f), new WaitingAction(1, 1.5f) }));
                                                            this.$PC = 0x6d;
                                                        }
                                                        else if (this.<playerIcon>__1 == BuddyIconType.SecretGrimecraft)
                                                        {
                                                            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 1.5f) }));
                                                            this.$PC = 0x73;
                                                        }
                                                        else if (this.<playerIcon>__1 == BuddyIconType.SecretDFA1979)
                                                        {
                                                            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 1.5f) }));
                                                            this.$PC = 0x77;
                                                        }
                                                        else if (this.<playerIcon>__1 == BuddyIconType.SecretSnowPatrol)
                                                        {
                                                            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.GenericResponseRunner());
                                                            this.$PC = 0x7d;
                                                        }
                                                        else if (this.<playerIcon>__1 != BuddyIconType.SecretSigurRos)
                                                        {
                                                            if (this.<playerIcon>__1 != BuddyIconType.SecretDota)
                                                            {
                                                                if (this.<playerIcon>__1 == BuddyIconType.SecretDoge)
                                                                {
                                                                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 1f) }));
                                                                    this.$PC = 0x93;
                                                                }
                                                                else if (this.<playerIcon>__1 == BuddyIconType.SecretKreygasm)
                                                                {
                                                                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 1f) }));
                                                                    this.$PC = 0x99;
                                                                }
                                                                else if (this.<playerIcon>__1 != BuddyIconType.SecretUndertale)
                                                                {
                                                                    if (this.<playerIcon>__1 == BuddyIconType.SecretJackSepticEye)
                                                                    {
                                                                        this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f) }));
                                                                        this.$PC = 0xa8;
                                                                    }
                                                                    else if (this.<playerIcon>__1 != BuddyIconType.SecretPokemon)
                                                                    {
                                                                        if (this.<playerIcon>__1 == BuddyIconType.SecretDeathCab)
                                                                        {
                                                                            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.GenericResponseRunner());
                                                                            this.$PC = 0xba;
                                                                        }
                                                                        else if (this.<playerIcon>__1 == BuddyIconType.SecretFNAF)
                                                                        {
                                                                            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 1f) }));
                                                                            this.$PC = 0xc1;
                                                                        }
                                                                        else if (this.<playerIcon>__1 != BuddyIconType.SecretKindaFunny)
                                                                        {
                                                                            if (this.<playerIcon>__1 == BuddyIconType.SecretKingdomHearts)
                                                                            {
                                                                                this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 1f) }));
                                                                                this.$PC = 0xd1;
                                                                            }
                                                                            else if (this.<playerIcon>__1 == BuddyIconType.SecretCrash)
                                                                            {
                                                                                this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 1f) }));
                                                                                this.$PC = 0xd7;
                                                                            }
                                                                            else if (this.<playerIcon>__1 != BuddyIconType.SecretElderScrolls)
                                                                            {
                                                                                if (this.<playerIcon>__1 == BuddyIconType.SecretHotlineMiami)
                                                                                {
                                                                                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 1f) }));
                                                                                    this.$PC = 0xe7;
                                                                                }
                                                                                else if (this.<playerIcon>__1 == BuddyIconType.SecretJohnCena)
                                                                                {
                                                                                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 1f) }));
                                                                                    this.$PC = 240;
                                                                                }
                                                                                else if (this.<playerIcon>__1 != BuddyIconType.SecretClippy)
                                                                                {
                                                                                    if (this.<playerIcon>__1 != BuddyIconType.SecretASevenfold)
                                                                                    {
                                                                                        if (this.<playerIcon>__1 != BuddyIconType.SecretPewDiePie)
                                                                                        {
                                                                                            if (this.<playerIcon>__1 == BuddyIconType.SecretSSundee)
                                                                                            {
                                                                                                this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 1.5f) }));
                                                                                                this.$PC = 0x10f;
                                                                                            }
                                                                                            else if (this.<playerIcon>__1 == BuddyIconType.SecretDodger)
                                                                                            {
                                                                                                this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 1.5f) }));
                                                                                                this.$PC = 0x115;
                                                                                            }
                                                                                            else if (this.<playerIcon>__1 == BuddyIconType.SecretSqueezie)
                                                                                            {
                                                                                                this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 1f) }));
                                                                                                this.$PC = 0x11b;
                                                                                            }
                                                                                            else if (this.<playerIcon>__1 == BuddyIconType.SecretRust)
                                                                                            {
                                                                                                this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 1f) }));
                                                                                                this.$PC = 0x121;
                                                                                            }
                                                                                            else if (this.<playerIcon>__1 == BuddyIconType.SecretPortal)
                                                                                            {
                                                                                                this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 1f) }));
                                                                                                this.$PC = 0x129;
                                                                                            }
                                                                                            else if (this.<playerIcon>__1 != BuddyIconType.SecretTF2)
                                                                                            {
                                                                                                if (this.<playerIcon>__1 != BuddyIconType.SecretGTA)
                                                                                                {
                                                                                                    if (this.<playerIcon>__1 == BuddyIconType.SecretNyanCat)
                                                                                                    {
                                                                                                        this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 1f) }));
                                                                                                        this.$PC = 0x144;
                                                                                                    }
                                                                                                    else
                                                                                                    {
                                                                                                        this.$current = this.<>f__this.StartCoroutine(this.<>f__this.GenericResponseRunner());
                                                                                                        this.$PC = 0x152;
                                                                                                    }
                                                                                                }
                                                                                                else
                                                                                                {
                                                                                                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 1.5f) }));
                                                                                                    this.$PC = 0x139;
                                                                                                }
                                                                                            }
                                                                                            else
                                                                                            {
                                                                                                this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 1.5f) }));
                                                                                                this.$PC = 0x131;
                                                                                            }
                                                                                        }
                                                                                        else
                                                                                        {
                                                                                            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 1.5f) }));
                                                                                            this.$PC = 0x109;
                                                                                        }
                                                                                    }
                                                                                    else
                                                                                    {
                                                                                        this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 1.5f) }));
                                                                                        this.$PC = 0x103;
                                                                                    }
                                                                                }
                                                                                else
                                                                                {
                                                                                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 1f) }));
                                                                                    this.$PC = 250;
                                                                                }
                                                                            }
                                                                            else
                                                                            {
                                                                                this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 1f) }));
                                                                                this.$PC = 0xdd;
                                                                            }
                                                                        }
                                                                        else
                                                                        {
                                                                            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 1f) }));
                                                                            this.$PC = 0xc7;
                                                                        }
                                                                    }
                                                                    else
                                                                    {
                                                                        this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 1.5f) }));
                                                                        this.$PC = 0xb0;
                                                                    }
                                                                }
                                                                else
                                                                {
                                                                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 1.5f) }));
                                                                    this.$PC = 160;
                                                                }
                                                            }
                                                            else
                                                            {
                                                                this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 1.5f) }));
                                                                this.$PC = 0x8d;
                                                            }
                                                        }
                                                        else
                                                        {
                                                            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f) }));
                                                            this.$PC = 130;
                                                        }
                                                    }
                                                    else
                                                    {
                                                        this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 1.5f) }));
                                                        this.$PC = 0x5f;
                                                    }
                                                }
                                                else
                                                {
                                                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 2f) }));
                                                    this.$PC = 0x54;
                                                }
                                            }
                                            else
                                            {
                                                this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 1.5f) }));
                                                this.$PC = 70;
                                            }
                                        }
                                        else
                                        {
                                            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 1.5f) }));
                                            this.$PC = 0x3e;
                                        }
                                    }
                                    else
                                    {
                                        this.$current = this.<>f__this.StartCoroutine(this.<>f__this.GenericResponseRunner());
                                        this.$PC = 0x2a;
                                    }
                                }
                                else
                                {
                                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.GenericResponseRunner());
                                    this.$PC = 0x23;
                                }
                            }
                            else
                            {
                                this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 1f) }));
                                this.$PC = 0x12;
                            }
                        }
                        else
                        {
                            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 1f) }));
                            this.$PC = 8;
                        }
                    }
                    else
                    {
                        this.$current = this.<>f__this.StartCoroutine(this.<>f__this.GenericResponseRunner());
                        this.$PC = 1;
                    }
                    goto Label_7662;

                case 1:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 0.5f),
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 2;
                    goto Label_7662;

                case 2:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("oh wow, do we have the same buddy icon?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 3;
                    goto Label_7662;

                case 3:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("oh wow, yeah!", "what a coincidence", "i stole it from you :p"));
                    this.$PC = 4;
                    goto Label_7662;

                case 4:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "what a coincidence, i love coldplay!~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "i stole it from you :p~";
                        }
                        break;
                    }
                    this.<text>__0 = "oh wow, yeah we do! i love coldplay!~";
                    break;

                case 5:
                    if (this.<>f__this.answer == 3)
                    {
                        this.<text>__0 = "thats kinda flattering but aalso kinda weird";
                    }
                    else
                    {
                        this.<text>__0 = "thats so weirrd. i was just about to ask if you liked coldplay too";
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 2f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 6;
                    goto Label_7662;

                case 6:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 7;
                    goto Label_7662;

                case 7:
                case 0x11:
                case 0x19:
                case 0x1d:
                case 0x22:
                case 0x29:
                case 0x30:
                case 0x3d:
                case 0x4f:
                case 0x53:
                case 0x6c:
                case 0x72:
                case 0x76:
                case 0x7c:
                case 0x81:
                case 0x9f:
                case 0xaf:
                case 0xb9:
                case 0xc0:
                case 0xc6:
                case 0xd0:
                case 0xd6:
                case 220:
                case 230:
                case 0xef:
                case 270:
                case 0x114:
                case 0x11a:
                case 0x120:
                case 0x128:
                case 0x138:
                case 0x143:
                case 340:
                    goto Label_763F;

                case 8:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("yeah?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 9;
                    goto Label_7662;

                case 9:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 10;
                    goto Label_7662;

                case 10:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("oh wait, " + ChatValues.GetPlayerName().ToLower() + " is that you?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 11;
                    goto Label_7662;

                case 11:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 2f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 12;
                    goto Label_7662;

                case 12:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("i thought you were brad, did you know you two have the same icon?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 13;
                    goto Label_7662;

                case 13:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("thats so weird", "i had no idea", "oh, im sorry"));
                    this.$PC = 14;
                    goto Label_7662;

                case 14:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "i had no idea!~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "oh, im sorry~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "thats so weird!~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, true));
                    this.$PC = 15;
                    goto Label_7662;

                case 15:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "yeah, its just really confusing haha";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "its okay, just really confusing haha";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "yeah it really is";
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x10;
                    goto Label_7662;

                case 0x10:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x11;
                    goto Label_7662;

                case 0x12:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("hey travis!", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x13;
                    goto Label_7662;

                case 0x13:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 20;
                    goto Label_7662;

                case 20:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("oh wait, " + ChatValues.GetPlayerName().ToLower() + " is that you?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x15;
                    goto Label_7662;

                case 0x15:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("no.", "uh, yeah?", "whyd you think it was travis?"));
                    this.$PC = 0x16;
                    goto Label_7662;

                case 0x16:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "uh, yeah?~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "whyd you think it was travis?~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "no.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, true));
                    this.$PC = 0x17;
                    goto Label_7662;

                case 0x17:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "oh sorry, you two have the same buddy icon";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "sorry, you two have the same exact buddy icon";
                        }
                    }
                    else
                    {
                        this.<>f__this.dmb.ShowStatusLabel("you liar");
                        this.<text>__0 = "it totally is you! you two have the same buddy icon";
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x18;
                    goto Label_7662;

                case 0x18:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x19;
                    goto Label_7662;

                case 0x1a:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("hey! i thought you said you were coming over!", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x1b;
                    goto Label_7662;

                case 0x1b:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x1c;
                    goto Label_7662;

                case 0x1c:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("oh sorry " + ChatValues.GetPlayerName().ToLower() + ", i thought you were julie!", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x1d;
                    goto Label_7662;

                case 30:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x1f;
                    goto Label_7662;

                case 0x1f:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("oh wow, what a cute icon!", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x20;
                    goto Label_7662;

                case 0x20:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x21;
                    goto Label_7662;

                case 0x21:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("i bet that robot loves that kitty :3", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x22;
                    goto Label_7662;

                case 0x23:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x24;
                    goto Label_7662;

                case 0x24:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("nice icon! HJTenchi is like my favorite streamer", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x25;
                    goto Label_7662;

                case 0x25:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("oh really?", "whats a streamer?", "but its 2002"));
                    this.$PC = 0x26;
                    goto Label_7662;

                case 0x26:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "whats a streamer? twitch doesnt exist yet~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "but its 2002, twitch doesnt exist yet~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "oh really? but twitch doesnt exist yet~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, true));
                    this.$PC = 0x27;
                    goto Label_7662;

                case 0x27:
                    this.<>f__this.dmb.ShowStatusLabel("oh shit, youre right");
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 4f), new WaitingAction(1, 1.5f) }));
                    this.$PC = 40;
                    goto Label_7662;

                case 40:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("i mean, i totally dont know what that is", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x29;
                    goto Label_7662;

                case 0x2a:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x2b;
                    goto Label_7662;

                case 0x2b:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("nice icon! chilledchaos is my favorite lets player", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x2c;
                    goto Label_7662;

                case 0x2c:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("you sure?", "whats a lets play?", "but its 2002"));
                    this.$PC = 0x2d;
                    goto Label_7662;

                case 0x2d:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "whats a streamer? lets plays dont exist yet~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "but its 2002, lets plays dont exist yet~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "you sure? lets plays dont exist yet~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, true));
                    this.$PC = 0x2e;
                    goto Label_7662;

                case 0x2e:
                    this.<>f__this.dmb.ShowStatusLabel("oh shit, youre right");
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 4f), new WaitingAction(1, 1.5f) }));
                    this.$PC = 0x2f;
                    goto Label_7662;

                case 0x2f:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("i mean, i totally dont know what that is", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x30;
                    goto Label_7662;

                case 0x31:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("hey! like the icon", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 50;
                    goto Label_7662;

                case 50:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x33;
                    goto Label_7662;

                case 0x33:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("in kappa we trust", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x34;
                    goto Label_7662;

                case 0x34:
                    this.<>f__this.SetBuddyIconAchievement(BuddyIconType.SecretKappa);
                    goto Label_763F;

                case 0x35:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("its dangerous to go alone. take this!", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x36;
                    goto Label_7662;

                case 0x36:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x37;
                    goto Label_7662;

                case 0x37:
                    this.<>f__this.dmb.ShowStatusLabel("you received an unhealthy dose of nostalgia");
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 2f), new WaitingAction(1, 1.5f) }));
                    this.$PC = 0x38;
                    goto Label_7662;

                case 0x38:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("oops, not sure that helped.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x39;
                    goto Label_7662;

                case 0x39:
                    this.<>f__this.SetBuddyIconAchievement(BuddyIconType.SecretZelda);
                    goto Label_763F;

                case 0x3a:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("hey nice icon!", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x3b;
                    goto Label_7662;

                case 0x3b:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 60;
                    goto Label_7662;

                case 60:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("in retrospect, probably should have named the game emily-is-away-craft", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x3d;
                    goto Label_7662;

                case 0x3e:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("Hello " + ChatValues.GetPlayerName() + ". This is Gabe Newell.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x3f;
                    goto Label_7662;

                case 0x3f:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 2f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x40;
                    goto Label_7662;

                case 0x40:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("This has all been an elaborate ruse to get players for the Half Life 3 Beta.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x41;
                    goto Label_7662;

                case 0x41:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x42;
                    goto Label_7662;

                case 0x42:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("Congragulations.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x43;
                    goto Label_7662;

                case 0x43:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("im so excited", "thanks so much", "i knew this day would come"));
                    this.$PC = 0x44;
                    goto Label_7662;

                case 0x44:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "thanks so<<<<<<<<<lol jk~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "i knew this<<<<<<<<<<<lol jk~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "im so exc<<<<<<<<<lol jk~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, true));
                    this.$PC = 0x45;
                    goto Label_7662;

                case 0x45:
                    this.<>f__this.SetBuddyIconAchievement(BuddyIconType.SecretHalflife);
                    goto Label_763F;

                case 70:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("hey nice icon, love that game!", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x47;
                    goto Label_7662;

                case 0x47:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("war...", "where am i?", "wheres my son?"));
                    this.$PC = 0x48;
                    goto Label_7662;

                case 0x48:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "i was in the vault and now.. where am i?~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "wheres my boy shaun?!~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "war... war someti<<<<<<never changes.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, true));
                    this.$PC = 0x49;
                    goto Label_7662;

                case 0x49:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "a long way from diamond city thats for sure";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "im not going to spoil the game for you!";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "youve got that right";
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x4a;
                    goto Label_7662;

                case 0x4a:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x4b;
                    goto Label_7662;

                case 0x4b:
                    this.<>f__this.SetBuddyIconAchievement(BuddyIconType.SecretFallout);
                    goto Label_763F;

                case 0x4c:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("hey, glad youre online", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x4d;
                    goto Label_7662;

                case 0x4d:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 2f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x4e;
                    goto Label_7662;

                case 0x4e:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("that dungeon run in valtameri last night was really fun", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x4f;
                    goto Label_7662;

                case 80:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("hey, if you havent played actual sunlight you should", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x51;
                    goto Label_7662;

                case 0x51:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 2.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x52;
                    goto Label_7662;

                case 0x52:
                    this.<>f__this.dmb.ShowStatusLabel("you really should");
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f) }));
                    this.$PC = 0x53;
                    goto Label_7662;

                case 0x54:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("hey, hows it going?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x55;
                    goto Label_7662;

                case 0x55:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 2f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x56;
                    goto Label_7662;

                case 0x56:
                    this.<>f__this.dmb.ShowStatusLabel("when presented with three options " + ChatValues.GetPlayerName().ToLower() + " picked option one");
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 2.5f) }));
                    this.$PC = 0x57;
                    goto Label_7662;

                case 0x57:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("its going", "its NOT going", "potatoes!"));
                    this.$PC = 0x58;
                    goto Label_7662;

                case 0x58:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "its NOT going~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "potatoes!~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "its going~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, true));
                    this.$PC = 0x59;
                    goto Label_7662;

                case 0x59:
                    if (this.<>f__this.answer != 1)
                    {
                        this.<>f__this.dmb.ShowStatusLabel(ChatValues.GetPlayerName().ToLower() + " picked the wrong option, perhaps they were trying to be funny");
                        this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 3f), new WaitingAction(1, 1.5f) }));
                        this.$PC = 0x5b;
                    }
                    else
                    {
                        this.<>f__this.dmb.ShowStatusLabel(ChatValues.GetPlayerName().ToLower() + " chose the correct option because why wouldnt they");
                        this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 2f) }));
                        this.$PC = 90;
                    }
                    goto Label_7662;

                case 90:
                case 0x5e:
                    this.<>f__this.SetBuddyIconAchievement(BuddyIconType.SecretStanley);
                    goto Label_763F;

                case 0x5b:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("uh what?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x5c;
                    goto Label_7662;

                case 0x5c:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x5d;
                    goto Label_7662;

                case 0x5d:
                    this.<>f__this.dmb.ShowStatusLabel("it didnt work");
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f) }));
                    this.$PC = 0x5e;
                    goto Label_7662;

                case 0x5f:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("you find yourself on a distant world", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x60;
                    goto Label_7662;

                case 0x60:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 2f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x61;
                    goto Label_7662;

                case 0x61:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("a vibrant pink sky contrasts against the bright blue landscape", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x62;
                    goto Label_7662;

                case 0x62:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 2f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x63;
                    goto Label_7662;

                case 0x63:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("littered about are the enormous monuments of a bygone civilization", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 100;
                    goto Label_7662;

                case 100:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 2f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x65;
                    goto Label_7662;

                case 0x65:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("an overwhelming sense of inspiration overcomes you and you decide to write", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x66;
                    goto Label_7662;

                case 0x66:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("the sky...", "the monuments...", "this world..."));
                    this.$PC = 0x67;
                    goto Label_7662;

                case 0x67:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "the monuments are pretty cool~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "this world is pretty dead~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "the sky is pretty rad~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, true));
                    this.$PC = 0x68;
                    goto Label_7662;

                case 0x68:
                    this.<>f__this.SetBuddyIconAchievement(BuddyIconType.SecretElegy);
                    goto Label_763F;

                case 0x69:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("hey! i just got back from the robot roller disco dodgeball game", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x6a;
                    goto Label_7662;

                case 0x6a:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x6b;
                    goto Label_7662;

                case 0x6b:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("those robots sure know how to put on a show", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x6c;
                    goto Label_7662;

                case 0x6d:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("hello fellow human", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 110;
                    goto Label_7662;

                case 110:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x6f;
                    goto Label_7662;

                case 0x6f:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("pleased to be communicating with you", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x70;
                    goto Label_7662;

                case 0x70:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 2.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x71;
                    goto Label_7662;

                case 0x71:
                    this.<>f__this.dmb.ShowStatusLabel("displeasure detected, behavioral reformat commencing");
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 2f) }));
                    this.$PC = 0x72;
                    goto Label_7662;

                case 0x73:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("hey! nice coheed and cambria icon!", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x74;
                    goto Label_7662;

                case 0x74:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x75;
                    goto Label_7662;

                case 0x75:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("protect the keywork", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x76;
                    goto Label_7662;

                case 0x77:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("hey! i like the death from above icon", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 120;
                    goto Label_7662;

                case 120:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x79;
                    goto Label_7662;

                case 0x79:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("youre a woman, im a machine!", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x7a;
                    goto Label_7662;

                case 0x7a:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 2f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x7b;
                    goto Label_7662;

                case 0x7b:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("or wait, am i a woman and a machine?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x7c;
                    goto Label_7662;

                case 0x7d:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x7e;
                    goto Label_7662;

                case 0x7e:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("oh wow, i like your new snow patrol icon!", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x7f;
                    goto Label_7662;

                case 0x7f:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x80;
                    goto Label_7662;

                case 0x80:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("that album is one of my favorites", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x81;
                    goto Label_7662;

                case 130:
                    this.<>f__this.dmb.ShowStatusLabel("sigur ros icon selected, poorly translating dialogue to icelandic");
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 3f), new WaitingAction(1, 1.5f) }));
                    this.$PC = 0x83;
                    goto Label_7662;

                case 0x83:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("hallo", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x84;
                    goto Label_7662;

                case 0x84:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x85;
                    goto Label_7662;

                case 0x85:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("mer finnst sigur ros taknio", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x86;
                    goto Label_7662;

                case 0x86:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x87;
                    goto Label_7662;

                case 0x87:
                    this.<>f__this.dmb.ShowStatusLabel("do you confirm this language change?");
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f) }));
                    this.$PC = 0x88;
                    goto Label_7662;

                case 0x88:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("mer likar pao ekki", "eg vil ensku aftur", "nei takk"));
                    this.$PC = 0x89;
                    goto Label_7662;

                case 0x89:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "eg vil ensku aftur~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "nei takk~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "mer likar pao ekki~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, true));
                    this.$PC = 0x8a;
                    goto Label_7662;

                case 0x8a:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 0.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x8b;
                    goto Label_7662;

                case 0x8b:
                    this.<>f__this.dmb.ShowStatusLabel("translation declined, switching back to english");
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f) }));
                    this.$PC = 140;
                    goto Label_7662;

                case 140:
                    this.<>f__this.SetBuddyIconAchievement(BuddyIconType.SecretSigurRos);
                    goto Label_763F;

                case 0x8d:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("Relax, You're Doing Fine", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x8e;
                    goto Label_7662;

                case 0x8e:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("Well Played", "New Meta", "Game Is Hard"));
                    this.$PC = 0x8f;
                    goto Label_7662;

                case 0x8f:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "New Meta~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "Game Is Hard~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "Well Played~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, true));
                    this.$PC = 0x90;
                    goto Label_7662;

                case 0x90:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x91;
                    goto Label_7662;

                case 0x91:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("Space Created", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x92;
                    goto Label_7662;

                case 0x92:
                    this.<>f__this.SetBuddyIconAchievement(BuddyIconType.SecretDota);
                    goto Label_763F;

                case 0x93:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("Very Icon", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x94;
                    goto Label_7662;

                case 0x94:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x95;
                    goto Label_7662;

                case 0x95:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("Such Cool", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 150;
                    goto Label_7662;

                case 150:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x97;
                    goto Label_7662;

                case 0x97:
                    this.<>f__this.dmb.ShowStatusLabel("Wow");
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f) }));
                    this.$PC = 0x98;
                    goto Label_7662;

                case 0x98:
                    this.<>f__this.SetBuddyIconAchievement(BuddyIconType.SecretDoge);
                    goto Label_763F;

                case 0x99:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("hey, did you hear?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x9a;
                    goto Label_7662;

                case 0x9a:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x9b;
                    goto Label_7662;

                case 0x9b:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("theyre rerunning a bob ross season every monday!", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x9c;
                    goto Label_7662;

                case 0x9c:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x9d;
                    goto Label_7662;

                case 0x9d:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("Kreygasm", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x9e;
                    goto Label_7662;

                case 0x9e:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 0.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x9f;
                    goto Label_7662;

                case 160:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("uh hello, who are you? where am i?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xa1;
                    goto Label_7662;

                case 0xa1:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("im flowey, the flower!", "youre in the ruins", "it doesn't matter"));
                    this.$PC = 0xa2;
                    goto Label_7662;

                case 0xa2:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "youre in the ruins underground!~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "it doesnt matter now ;]~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "im flowey, the flower!~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, true));
                    this.$PC = 0xa3;
                    goto Label_7662;

                case 0xa3:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "i must have fallen, can you help me?";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "thaat was pretty creepy, can you help me?";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "oh okay, can you help me mr. flowey?";
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0xa4;
                    goto Label_7662;

                case 0xa4:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xa5;
                    goto Label_7662;

                case 0xa5:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("[fight]", "[compliment]", "[mercy]"));
                    this.$PC = 0xa6;
                    goto Label_7662;

                case 0xa6:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "you look great, how about grabbing some friendliness petals!~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "sure, but maybe i could interest you in some friendliness petals!~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "sure, just grab some of these friendliness petals!~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, true));
                    this.$PC = 0xa7;
                    goto Label_7662;

                case 0xa7:
                    this.<>f__this.SetBuddyIconAchievement(BuddyIconType.SecretUndertale);
                    goto Label_763F;

                case 0xa8:
                    this.<>f__this.dmb.ShowStatusLabel("woooosh CLAP");
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(1, 1f) }));
                    this.$PC = 0xa9;
                    goto Label_7662;

                case 0xa9:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("TOP OF THE MORNING TO YA LADDIES", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 170;
                    goto Label_7662;

                case 170:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0xab;
                    goto Label_7662;

                case 0xab:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("MY NAME IS JACK SEPTIC EYE", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xac;
                    goto Label_7662;

                case 0xac:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0xad;
                    goto Label_7662;

                case 0xad:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("AND WELCOME TO EMILY IS AWAY", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xae;
                    goto Label_7662;

                case 0xae:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 0.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0xaf;
                    goto Label_7662;

                case 0xb0:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("i wanna be the very best...", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xb1;
                    goto Label_7662;

                case 0xb1:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("like someone once was", "like no one ever was", "like no one just because"));
                    this.$PC = 0xb2;
                    goto Label_7662;

                case 0xb2:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "like no one ever was~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "like no one just because~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "like someone once was~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, true));
                    this.$PC = 0xb3;
                    goto Label_7662;

                case 0xb3:
                    this.<didMessUp>__2 = this.<>f__this.answer != 2;
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 1.5f) }));
                    this.$PC = 180;
                    goto Label_7662;

                case 180:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("to catch them is my real test...", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xb5;
                    goto Label_7662;

                case 0xb5:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("to shame them gives me pause", "to frame them in my jaws", "to train them is my cause"));
                    this.$PC = 0xb6;
                    goto Label_7662;

                case 0xb6:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "to frame them in my jaws~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "to train them is my cause~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "to shame them gives me pause~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, true));
                    this.$PC = 0xb7;
                    goto Label_7662;

                case 0xb7:
                    if (!this.<didMessUp>__2)
                    {
                        this.<didMessUp>__2 = this.<>f__this.answer != 3;
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0xb8;
                    goto Label_7662;

                case 0xb8:
                    if (!this.<didMessUp>__2)
                    {
                        this.<>f__this.dmb.ShowStatusLabel("POKEMON!");
                    }
                    else
                    {
                        this.<>f__this.dmb.ShowStatusLabel("pokemon?");
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 0.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0xb9;
                    goto Label_7662;

                case 0xba:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0xbb;
                    goto Label_7662;

                case 0xbb:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("wow i love the icon!", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xbc;
                    goto Label_7662;

                case 0xbc:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0xbd;
                    goto Label_7662;

                case 0xbd:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("the rhythm of my footsteps crossing flatlands to your door", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 190;
                    goto Label_7662;

                case 190:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 0.5f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0xbf;
                    goto Label_7662;

                case 0xbf:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("have been silenced forevermore", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xc0;
                    goto Label_7662;

                case 0xc1:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("Come on down to Freddy Fazbear's Pizza!", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xc2;
                    goto Label_7662;

                case 0xc2:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0xc3;
                    goto Label_7662;

                case 0xc3:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("We've got food and entertainment for the whole family!", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xc4;
                    goto Label_7662;

                case 0xc4:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0xc5;
                    goto Label_7662;

                case 0xc5:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("And you've never seen anything quite like our animatronics ;]", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xc6;
                    goto Label_7662;

                case 0xc7:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("hey, nice icon!", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 200;
                    goto Label_7662;

                case 200:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0xc9;
                    goto Label_7662;

                case 0xc9:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("kinda funny is the beest youtube channel", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xca;
                    goto Label_7662;

                case 0xca:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("youtube channel?", "its 2002", "what do you mean?"));
                    this.$PC = 0xcb;
                    goto Label_7662;

                case 0xcb:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "but its 2002, youtube isnt around yet~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "what do you mean youtube?~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "wait, whats a youtube channel~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, true));
                    this.$PC = 0xcc;
                    goto Label_7662;

                case 0xcc:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0xcd;
                    goto Label_7662;

                case 0xcd:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("oh uh...", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xce;
                    goto Label_7662;

                case 0xce:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0xcf;
                    goto Label_7662;

                case 0xcf:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("i mean, theyre the best break.tv channel", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xd0;
                    goto Label_7662;

                case 0xd1:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("hey, i love your icon!", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 210;
                    goto Label_7662;

                case 210:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0xd3;
                    goto Label_7662;

                case 0xd3:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("get hyped for the third one!", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xd4;
                    goto Label_7662;

                case 0xd4:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0xd5;
                    goto Label_7662;

                case 0xd5:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("at least square enix can count to three :p", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xd6;
                    goto Label_7662;

                case 0xd7:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("hey, i love your icon!", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xd8;
                    goto Label_7662;

                case 0xd8:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0xd9;
                    goto Label_7662;

                case 0xd9:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("those games are the best!", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xda;
                    goto Label_7662;

                case 0xda:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0xdb;
                    goto Label_7662;

                case 0xdb:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("the wrath of cortex just came out and it was aawesome", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 220;
                    goto Label_7662;

                case 0xdd:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("get up, you were dreaming.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xde;
                    goto Label_7662;

                case 0xde:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0xdf;
                    goto Label_7662;

                case 0xdf:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("even the storm last night couldn't wake you.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xe0;
                    goto Label_7662;

                case 0xe0:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0xe1;
                    goto Label_7662;

                case 0xe1:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("whats your name?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xe2;
                    goto Label_7662;

                case 0xe2:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("Player", "Jiub", "TurboTits"));
                    this.$PC = 0xe3;
                    goto Label_7662;

                case 0xe3:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "Jiub~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "TurboTits~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "Player~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, true));
                    this.$PC = 0xe4;
                    goto Label_7662;

                case 0xe4:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "well Jiub, welcome to Morrowind!";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "well TurboTits, welcome to Morrowind!";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "well Player, welcome to Morrowind!";
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0xe5;
                    goto Label_7662;

                case 0xe5:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 230;
                    goto Label_7662;

                case 0xe7:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("oh hello, who do we have here?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xe8;
                    goto Label_7662;

                case 0xe8:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0xe9;
                    goto Label_7662;

                case 0xe9:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("oh.. you dont know who you are?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xea;
                    goto Label_7662;

                case 0xea:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 2f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0xeb;
                    goto Label_7662;

                case 0xeb:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("are you sure you'd like to know? knowing oneself means being responsible for ones actions.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xec;
                    goto Label_7662;

                case 0xec:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 3f),
                        new WaitingAction(WaitingActionType.Typing, 1f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0xed;
                    goto Label_7662;

                case 0xed:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("suit yourself.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xee;
                    goto Label_7662;

                case 0xee:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0xef;
                    goto Label_7662;

                case 240:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("hey", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xf1;
                    goto Label_7662;

                case 0xf1:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0xf2;
                    goto Label_7662;

                case 0xf2:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("whats your name again?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xf3;
                    goto Label_7662;

                case 0xf3:
                    this.<effects>__3 = EffectsBehavior.Instance;
                    this.<effects>__3.SetBlocking(true);
                    this.$current = new WaitForSeconds(0.5f);
                    this.$PC = 0xf4;
                    goto Label_7662;

                case 0xf4:
                    SoundManagerBehavior.Instance.PlayJohnCena();
                    this.<>f__this.StartCoroutine(this.<effects>__3.FadeDimmer(3.5f, true));
                    this.$current = new WaitForSeconds(5.6f);
                    this.$PC = 0xf5;
                    goto Label_7662;

                case 0xf5:
                    this.<>f__this.StartCoroutine(this.<>f__this.dmb.ScriptedWriteText("m#6y#8#6#6 #4n#4a#4m#4e#6#6 #6i#5#5s#5#5 #9#9J#1O#1O#1O#1H#1N#1 #1C#1E#1E#1E#1E#1N#1A#1A#1A#1A#1~"));
                    this.$current = new WaitForSeconds(4.9f);
                    this.$PC = 0xf6;
                    goto Label_7662;

                case 0xf6:
                    this.<effects>__3.SetDimmer(false);
                    this.$current = new WaitForSeconds(3.3f);
                    this.$PC = 0xf7;
                    goto Label_7662;

                case 0xf7:
                    this.<>f__this.StartCoroutine(this.<>f__this.dmb.ScriptedWriteText("n#1a#1a#5 #1n#1a#4 #1n#1a#5 #1n#1a#1a#1a#4~"));
                    this.$current = new WaitForSeconds(2.6f);
                    this.$PC = 0xf8;
                    goto Label_7662;

                case 0xf8:
                    this.<effects>__3.SetBlocking(false);
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("uh, okay", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xf9;
                    goto Label_7662;

                case 0xf9:
                    this.<>f__this.SetBuddyIconAchievement(BuddyIconType.SecretJohnCena);
                    goto Label_763F;

                case 250:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("Looks like you're trying to instant message someone.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xfb;
                    goto Label_7662;

                case 0xfb:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0xfc;
                    goto Label_7662;

                case 0xfc:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("Would you like help with that?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xfd;
                    goto Label_7662;

                case 0xfd:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("Get help with the message", "Just type it without help", "Don't show this tip again"));
                    this.$PC = 0xfe;
                    goto Label_7662;

                case 0xfe:
                    if (this.<>f__this.answer == 1)
                    {
                        this.<>f__this.dmb.ShowStatusLabel("Try this message out.");
                    }
                    else
                    {
                        this.<>f__this.dmb.ShowStatusLabel("I'm sorry, I must insist.");
                    }
                    this.<text>__0 = "Dear Emily, Have you heard of Clippy? He's the best.~";
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, true));
                    this.$PC = 0xff;
                    goto Label_7662;

                case 0xff:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x100;
                    goto Label_7662;

                case 0x100:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("i always thought he was super annoying.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x101;
                    goto Label_7662;

                case 0x101:
                    this.$current = new WaitForSeconds(1f);
                    this.$PC = 0x102;
                    goto Label_7662;

                case 0x102:
                    this.<>f__this.dmb.ShowStatusLabel(":(");
                    this.<>f__this.SetBuddyIconAchievement(BuddyIconType.SecretClippy);
                    goto Label_763F;

                case 0x103:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("the man who makes a beast out of himself", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 260;
                    goto Label_7662;

                case 260:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x105;
                    goto Label_7662;

                case 0x105:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("gets rid of the pain...", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x106;
                    goto Label_7662;

                case 0x106:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("of being so tan", "of being a man", "of seeing a pan"));
                    this.$PC = 0x107;
                    goto Label_7662;

                case 0x107:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "of being a man~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "of seeing a pan~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "of being so tan~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, true));
                    this.$PC = 0x108;
                    goto Label_7662;

                case 0x108:
                    this.<>f__this.dmb.ShowStatusLabel("yeaaaaaahhh!");
                    goto Label_763F;

                case 0x109:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("hey, whats up bros!", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x10a;
                    goto Label_7662;

                case 0x10a:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x10b;
                    goto Label_7662;

                case 0x10b:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("my name is PeeeewDeePaaahhh", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x10c;
                    goto Label_7662;

                case 0x10c:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("brofist!", "i don't caare!", "falcon lovers.."));
                    this.$PC = 0x10d;
                    goto Label_7662;

                case 0x10d:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "i don't caaare!~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "falcon lovers, it has all come clear to me. i am a giraffe, remember to forget to subscribe.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "brofist!~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, true));
                    this.$PC = 270;
                    goto Label_7662;

                case 0x10f:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("This game is rated T for BAD WORDS!", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x110;
                    goto Label_7662;

                case 0x110:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x111;
                    goto Label_7662;

                case 0x111:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("Like poop!", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x112;
                    goto Label_7662;

                case 0x112:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x113;
                    goto Label_7662;

                case 0x113:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("But the.. bad version!", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x114;
                    goto Label_7662;

                case 0x115:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("Hi! This is Dodger, and you're watching my show!", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x116;
                    goto Label_7662;

                case 0x116:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x117;
                    goto Label_7662;

                case 0x117:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("I don't know what I'm about to get into..", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 280;
                    goto Label_7662;

                case 280:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x119;
                    goto Label_7662;

                case 0x119:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("But let's go on a game adventure!", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x11a;
                    goto Label_7662;

                case 0x11b:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("YO TOUT LE MONDE C'EST SQUEEZIE!", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x11c;
                    goto Label_7662;

                case 0x11c:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x11d;
                    goto Label_7662;

                case 0x11d:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("viens donc discuter", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x11e;
                    goto Label_7662;

                case 0x11e:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x11f;
                    goto Label_7662;

                case 0x11f:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("je suis super excite aujourd'hui on va jouer \x00e0 emily is away", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x120;
                    goto Label_7662;

                case 0x121:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("so you're going into the woods alone?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 290;
                    goto Label_7662;

                case 290:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x123;
                    goto Label_7662;

                case 0x123:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("here, take this rock", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x124;
                    goto Label_7662;

                case 0x124:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x125;
                    goto Label_7662;

                case 0x125:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("and i'll take your clothes", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x126;
                    goto Label_7662;

                case 0x126:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x127;
                    goto Label_7662;

                case 0x127:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("you're all set!", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x128;
                    goto Label_7662;

                case 0x129:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("Hello test subject 1209", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x12a;
                    goto Label_7662;

                case 0x12a:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x12b;
                    goto Label_7662;

                case 0x12b:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("This experiment will test the emotional imbalances of human teenagers", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 300;
                    goto Label_7662;

                case 300:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x12d;
                    goto Label_7662;

                case 0x12d:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("And at the end, there will be a party", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x12e;
                    goto Label_7662;

                case 0x12e:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x12f;
                    goto Label_7662;

                case 0x12f:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("with cake! :)", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x130;
                    goto Label_7662;

                case 0x130:
                    this.<>f__this.SetBuddyIconAchievement(BuddyIconType.SecretPortal);
                    goto Label_763F;

                case 0x131:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("Who's Emily? This is Heavy", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x132;
                    goto Label_7662;

                case 0x132:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x133;
                    goto Label_7662;

                case 0x133:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("Do you have Sandvich?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x134;
                    goto Label_7662;

                case 0x134:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("here it is!", "uh sure..", "nope"));
                    this.$PC = 0x135;
                    goto Label_7662;

                case 0x135:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "uh, sure..~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "nope, no sandvich here~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "yeah, here it is!~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, true));
                    this.$PC = 310;
                    goto Label_7662;

                case 310:
                    if (this.<>f__this.answer != 2)
                    {
                        if (this.<>f__this.answer == 1)
                        {
                            this.<text>__0 = "You are a loose cannon sandvich, but you're a damn good cop.";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "I have plan for you: more PAIN!";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "Sandvich makes me strong!";
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x137;
                    goto Label_7662;

                case 0x137:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x138;
                    goto Label_7662;

                case 0x139:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("Niko! My cousin!", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x13a;
                    goto Label_7662;

                case 0x13a:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x13b;
                    goto Label_7662;

                case 0x13b:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("I can't believe you're here.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x13c;
                    goto Label_7662;

                case 0x13c:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x13d;
                    goto Label_7662;

                case 0x13d:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("Welcome to Liberty City!", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x13e;
                    goto Label_7662;

                case 0x13e:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("niko?", "liberty city?", "thats from GTA IV.."));
                    this.$PC = 0x13f;
                    goto Label_7662;

                case 0x13f:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "wait, what? liberty city?~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "thats from GTA IV~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "niko? the names tommy vercetti~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, true));
                    this.$PC = 320;
                    goto Label_7662;

                case 320:
                    this.$current = new WaitForSeconds(0.5f);
                    this.$PC = 0x141;
                    goto Label_7662;

                case 0x141:
                    this.<>f__this.dmb.ShowStatusLabel("oh shit...");
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 0.5f), new WaitingAction(0, 1f), new WaitingAction(1, 1f) }));
                    this.$PC = 0x142;
                    goto Label_7662;

                case 0x142:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("I mean.. Welcome to Vice City!", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x143;
                    goto Label_7662;

                case 0x144:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("hey! love the icon!", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x145;
                    goto Label_7662;

                case 0x145:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x146;
                    goto Label_7662;

                case 0x146:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("hows that song go again?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x147;
                    goto Label_7662;

                case 0x147:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("na nyan..", "nyan nyan..", "nyan na.."));
                    this.$PC = 0x148;
                    goto Label_7662;

                case 0x148:
                    this.<text>__0 = "nyan nyan na nyan na nyan na nyan nyan~";
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, true));
                    this.$PC = 0x149;
                    goto Label_7662;

                case 0x149:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("nyan na..", "na nyan..", "nyan nyan.."));
                    this.$PC = 330;
                    goto Label_7662;

                case 330:
                    this.<text>__0 = "nyan nyan na na nyan nyan na na nyan~";
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, true));
                    this.$PC = 0x14b;
                    goto Label_7662;

                case 0x14b:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("nyan nyan..", "nyan na..", "na nyan.."));
                    this.$PC = 0x14c;
                    goto Label_7662;

                case 0x14c:
                    this.<text>__0 = "na nyan na nyan na nyan na nyan nyan~";
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, true));
                    this.$PC = 0x14d;
                    goto Label_7662;

                case 0x14d:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x14e;
                    goto Label_7662;

                case 0x14e:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("oh yeah! thats right!", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x14f;
                    goto Label_7662;

                case 0x14f:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x150;
                    goto Label_7662;

                case 0x150:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("i completely forgot the lyrics :p", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x151;
                    goto Label_7662;

                case 0x151:
                    this.<>f__this.SetBuddyIconAchievement(BuddyIconType.SecretNyanCat);
                    goto Label_763F;

                case 0x152:
                    if (this.<playerIcon>__1 != BuddyIconType.Blink182)
                    {
                        if (this.<playerIcon>__1 == BuddyIconType.RedHotChiliPeppers)
                        {
                            this.<text>__0 = "i like your new buddy icon, the red hot chili peppers are great!";
                        }
                        else if (this.<playerIcon>__1 == BuddyIconType.Eminem)
                        {
                            this.<text>__0 = "i like your new buddy icon, eminems the best!";
                        }
                        else if (this.<playerIcon>__1 == BuddyIconType.Avril)
                        {
                            this.<text>__0 = "i like your new buddy icon, sk8r bois my jam!";
                        }
                        else if ((this.<playerIcon>__1 == BuddyIconType.TheRing) || (this.<playerIcon>__1 == BuddyIconType.DaysLater))
                        {
                            this.<text>__0 = "i like your new buddy icon, that movie is so scary!";
                        }
                        else if ((this.<playerIcon>__1 == BuddyIconType.LordoftheRings) || (this.<playerIcon>__1 == BuddyIconType.HarryPotter))
                        {
                            this.<text>__0 = "i like your new buddy icon, i love those movies!";
                        }
                        else if (((this.<playerIcon>__1 == BuddyIconType.LogoWhite) || (this.<playerIcon>__1 == BuddyIconType.LogoBlue)) || ((this.<playerIcon>__1 == BuddyIconType.LogoGreen) || (this.<playerIcon>__1 == BuddyIconType.LogoBlack)))
                        {
                            this.<text>__0 = "i like your new buddy icon, so glad were seniors!";
                        }
                        else if (this.<playerIcon>__1 == BuddyIconType.SecretIsaac)
                        {
                            this.<text>__0 = "nice icon! biblethump";
                        }
                        else if (this.<playerIcon>__1 == BuddyIconType.SecretBorderlands)
                        {
                            this.<text>__0 = "nice icon vaulthunter!";
                        }
                        else if (this.<playerIcon>__1 == BuddyIconType.SecretBioshock)
                        {
                            this.<text>__0 = "welcome to rapture " + ChatValues.GetPlayerName().ToLower();
                        }
                        else if (this.<playerIcon>__1 == BuddyIconType.SecretWalkingDead)
                        {
                            this.<text>__0 = "nice icon! lee and clem forever";
                        }
                        else if (this.<playerIcon>__1 == BuddyIconType.SecretMushroom11)
                        {
                            this.<text>__0 = "i love your icon! mushroom 11 is terrific!";
                        }
                        else if (this.<playerIcon>__1 == BuddyIconType.SecretRadiohead)
                        {
                            this.<text>__0 = "nice radiohead icon! hail to the thief is a great album";
                        }
                        else if (this.<playerIcon>__1 == BuddyIconType.SecretNIN)
                        {
                            this.<text>__0 = "i like the nine inch nails icon! with teeth is a terrific album";
                        }
                        else if (this.<playerIcon>__1 == BuddyIconType.SecretProdigy)
                        {
                            this.<text>__0 = "nice prodigy icon! always outnumbered, never outgunned";
                        }
                        else if (this.<playerIcon>__1 == BuddyIconType.SecretInterpol)
                        {
                            this.<text>__0 = "i love the interpol icon! theyre one of my favorites";
                        }
                        else if (this.<playerIcon>__1 == BuddyIconType.SecretStrokes)
                        {
                            this.<text>__0 = "oh wow, nice icon! this is it by the strokes";
                        }
                        else if (this.<playerIcon>__1 == BuddyIconType.SecretModestMouse)
                        {
                            this.<text>__0 = "nice modest mouse icon! the moon and antartica is a great album";
                        }
                        else if (this.<playerIcon>__1 == BuddyIconType.SecretArcadeFire)
                        {
                            this.<text>__0 = "i like the arcade fire icon!";
                        }
                        else if (this.<playerIcon>__1 == BuddyIconType.SecretDaftPunk)
                        {
                            this.<text>__0 = "nice icon! i love their music";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "i like your new buddy icon, blink 182 is great!";
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 2f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x153;
                    goto Label_7662;

                case 0x153:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 340;
                    goto Label_7662;

                default:
                    goto Label_7660;
            }
            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, true));
            this.$PC = 5;
            goto Label_7662;
        Label_763F:
            if (this.<playerIcon>__1 == BuddyIconType.SecretIsaac)
            {
                this.<>f__this.SetBuddyIconAchievement(BuddyIconType.SecretIsaac);
            }
            this.$PC = -1;
        Label_7660:
            return false;
        Label_7662:
            return true;
        }

        [DebuggerHidden]
        public void Reset()
        {
            throw new NotSupportedException();
        }

        object IEnumerator<object>.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }

        object IEnumerator.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }
    }

    [CompilerGenerated]
    private sealed class <GenericResponseRunner>c__Iterator6 : IEnumerator, IDisposable, IEnumerator<object>
    {
        internal object $current;
        internal int $PC;
        internal Chapter1ScriptBehavior <>f__this;
        internal string <text>__0;

        [DebuggerHidden]
        public void Dispose()
        {
            this.$PC = -1;
        }

        public bool MoveNext()
        {
            uint num = (uint) this.$PC;
            this.$PC = -1;
            switch (num)
            {
                case 0:
                    this.<text>__0 = string.Empty;
                    if (this.<>f__this.answer != 3)
                    {
                        this.<text>__0 = "hi!";
                        break;
                    }
                    this.<text>__0 = "lol, howdy partner.";
                    break;

                case 1:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 2;
                    goto Label_00F4;

                case 2:
                    this.$PC = -1;
                    goto Label_00F2;

                default:
                    goto Label_00F2;
            }
            List<WaitingAction> actionList = new List<WaitingAction> {
                new WaitingAction(WaitingActionType.Idle, 1f),
                new WaitingAction(WaitingActionType.Typing, 1f)
            };
            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(actionList));
            this.$PC = 1;
            goto Label_00F4;
        Label_00F2:
            return false;
        Label_00F4:
            return true;
        }

        [DebuggerHidden]
        public void Reset()
        {
            throw new NotSupportedException();
        }

        object IEnumerator<object>.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }

        object IEnumerator.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }
    }

    [CompilerGenerated]
    private sealed class <ScriptRunner>c__Iterator8 : IEnumerator, IDisposable, IEnumerator<object>
    {
        internal object $current;
        internal int $PC;
        internal Chapter1ScriptBehavior <>f__this;
        internal string <secondaryText>__1;
        internal string <text>__0;

        [DebuggerHidden]
        public void Dispose()
        {
            this.$PC = -1;
        }

        public bool MoveNext()
        {
            List<WaitingAction> list;
            uint num = (uint) this.$PC;
            this.$PC = -1;
            switch (num)
            {
                case 0:
                    this.<text>__0 = string.Empty;
                    this.$current = new WaitForSeconds(2f);
                    this.$PC = 1;
                    goto Label_25ED;

                case 1:
                    TaskBarBehavior.Instance.SetState(TaskBarState.BuddyListChat);
                    BuddyListBehavior.Instance.Hide();
                    DisplayManagerBehavior.Instance.Show();
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(ChatValues.SignInText, ChatMessageType.OtherSignIn, 0f));
                    this.$PC = 2;
                    goto Label_25ED;

                case 2:
                    this.<>f__this.currentStatus = BuddyStatus.Online;
                    BuddyListBehavior.Instance.ChangeBuddyStatus(ChatValues.OtherUsername, BuddyStatus.Online, null, false);
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("hey", "hello", "howdy"));
                    this.$PC = 3;
                    goto Label_25ED;

                case 3:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "emily! hello~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "emily! howdy~";
                        }
                        break;
                    }
                    this.<text>__0 = "emily! hey~";
                    break;

                case 4:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.BuddyIconReplyRunner());
                    this.$PC = 5;
                    goto Label_25ED;

                case 5:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 6;
                    goto Label_25ED;

                case 6:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("so, whats up?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 7;
                    goto Label_25ED;

                case 7:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("nothing much", "the ceiling!", "talking to you!"));
                    this.$PC = 8;
                    goto Label_25ED;

                case 8:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "the ceiling! what are you up to?~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "talking to you! what are you up to?~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "nothing much, what are you up to?~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, true));
                    this.$PC = 9;
                    goto Label_25ED;

                case 9:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "lol, nothing really, just listening to music =]";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "lol, well no shit. im just listening to music =]";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "nothin, just listening to some music =]";
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 2.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 10;
                    goto Label_25ED;

                case 10:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 11;
                    goto Label_25ED;

                case 11:
                    if (ChatValues.GetPlayerBuddyIcon() == BuddyIconType.SecretEmily)
                    {
                        ChatValues.Chapter1DislikesColdplay = false;
                        this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 1f) }));
                        this.$PC = 0x13;
                    }
                    else
                    {
                        this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 2f) }));
                        this.$PC = 12;
                    }
                    goto Label_25ED;

                case 12:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("do you like coldplay?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 13;
                    goto Label_25ED;

                case 13:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("i dont know", "yeah, totally", "theyre shit"));
                    this.$PC = 14;
                    goto Label_25ED;

                case 14:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "yeah, totally, their ls<ast album was really good~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "oh, theyre shit, i hs<ate that kind of music~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "i dont really know, ive nr<ever really listened to them~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, true));
                    this.$PC = 15;
                    goto Label_25ED;

                case 15:
                    this.<>f__this.dmb.ShowRememberLabel();
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "it really was! im so glad you like them, theyre my favorite. their lyrics are in my info.";
                            ChatValues.Chapter1DislikesColdplay = false;
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "oh well, theyre like my favorite band, their lyrics are in my info.";
                            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 2f), new WaitingAction(1, 2f), new WaitingAction(0, 1.5f), new WaitingAction(2, 1f) }));
                            this.$PC = 0x10;
                            goto Label_25ED;
                        }
                    }
                    else
                    {
                        this.<text>__0 = "you should definitely listen to them! i really like them, their lyrics are in my info.";
                        ChatValues.Chapter1DislikesColdplay = false;
                    }
                    goto Label_07E5;

                case 0x10:
                    this.<>f__this.dislikesColdplay = true;
                    ChatValues.Chapter1DislikesColdplay = true;
                    goto Label_07E5;

                case 0x11:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x12;
                    goto Label_25ED;

                case 0x12:
                case 20:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 2f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x15;
                    goto Label_25ED;

                case 0x13:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("coldplay actually =p", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 20;
                    goto Label_25ED;

                case 0x15:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("are you going to travis's party tonight?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x16;
                    goto Label_25ED;

                case 0x16:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("maybe, i havent decided", "ugh, travis is such a dick", "depends on if youre going"));
                    this.$PC = 0x17;
                    goto Label_25ED;

                case 0x17:
                    if (this.<>f__this.answer == 1)
                    {
                        this.<text>__0 = "maybe, i havent decided~";
                    }
                    else if (this.<>f__this.answer == 2)
                    {
                        this.<text>__0 = "ugh, i might but travis is such a dick~";
                    }
                    else if (this.<>f__this.answer == 3)
                    {
                        this.<text>__0 = "depends on if youre going ;] <<<<~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x18;
                    goto Label_25ED;

                case 0x18:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "lol, thats true, but his parties are always fun!";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            if (!this.<>f__this.dislikesColdplay)
                            {
                                this.<text>__0 = "lol, well i am! so you should go.";
                            }
                            else
                            {
                                this.<text>__0 = "uh, i havent decided yet.";
                            }
                        }
                    }
                    else if (this.<>f__this.dislikesColdplay)
                    {
                        this.<text>__0 = "yeah, me either, i think its supposed to be pretty big.";
                    }
                    else
                    {
                        this.<text>__0 = "you should go! itd be no fun without you.";
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 2f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x19;
                    goto Label_25ED;

                case 0x19:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x1a;
                    goto Label_25ED;

                case 0x1a:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 0.5f),
                        new WaitingAction(WaitingActionType.Typing, 1f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x1b;
                    goto Label_25ED;

                case 0x1b:
                    BuddyListBehavior.Instance.ChangeBuddyStatus(ChatValues.BradUsername, BuddyStatus.Online, null, true);
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(1, 1.5f) }));
                    this.$PC = 0x1c;
                    goto Label_25ED;

                case 0x1c:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("its crazy that were already having end of school parties.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x1d;
                    goto Label_25ED;

                case 0x1d:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("time flew by this year", "i cant wait for school to be over", "travis is still a shit head"));
                    this.$PC = 30;
                    goto Label_25ED;

                case 30:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "i cant wait for high school to be over~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "yeah well, whats really crazy is how big a shit head travis is~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "yeah, time flew by this year, college is so close!~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x1f;
                    goto Label_25ED;

                case 0x1f:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "same here! i am so over this school =p";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "lol! i literally just burst out laughing! i am so over this school =p";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "i know it! im excited. i am so over this school =p";
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 2f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x20;
                    goto Label_25ED;

                case 0x20:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x21;
                    goto Label_25ED;

                case 0x21:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 3f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x22;
                    goto Label_25ED;

                case 0x22:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("like you know brad from our math class? he won't stop messaging me right now", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x23;
                    goto Label_25ED;

                case 0x23:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("what's he saying?", "just ignore him", "he's a dick too!"));
                    this.$PC = 0x24;
                    goto Label_25ED;

                case 0x24:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "you should just ignore him~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "hey he's a dick too!~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "what's he saying?~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x25;
                    goto Label_25ED;

                case 0x25:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "thats my plan! he keeps saying he wants to talk but maybe hell get the hint :p";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "lol, you're so funny! he keeps saying he wants to talk but maybe hell get the hint :p";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "that he wants to talk or something? im not really paying attention :p";
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 2f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x26;
                    goto Label_25ED;

                case 0x26:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x27;
                    goto Label_25ED;

                case 0x27:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 2f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 40;
                    goto Label_25ED;

                case 40:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("oh man, just one more month to graduation. were so old!", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x29;
                    goto Label_25ED;

                case 0x29:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("im so excited for college", "i still wish it was sooner", "its kind of weird"));
                    this.$PC = 0x2a;
                    goto Label_25ED;

                case 0x2a:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "haha, yeah i still wish it was sop<oner though, did you pick a school yet?~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "haha, its kind of wr<eird, did you pick a school yet?~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "haha, yeah im so excited for collr<ege, did you pick a school yet?~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x2b;
                    goto Label_25ED;

                case 0x2b:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 3f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x2c;
                    goto Label_25ED;

                case 0x2c:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("eh, i didnt get accepted into my reach school. so im just going to one of the others.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x2d;
                    goto Label_25ED;

                case 0x2d:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 2.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x2e;
                    goto Label_25ED;

                case 0x2e:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("but thats okay! anythings better than high school. where are you gonna go?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x2f;
                    goto Label_25ED;

                case 0x2f:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("an engineering school", "an art school", "a business school"));
                    this.$PC = 0x30;
                    goto Label_25ED;

                case 0x30:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "an art school, im not really sure like<<<<what i want to major in, but im sure ill figure it out :p~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "a business school, i want to like<<<<start a company but i dont really know where to start :p~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "an engineering school, im not sure like<<<<what kind of engineering i want to do, but im sure ill figure it out :p~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x31;
                    goto Label_25ED;

                case 0x31:
                    ChatValues.Chapter1TypeOfSchool = this.<>f__this.answer;
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<>f__this.dmb.ShowStatusLabel("you chose to attend an art school");
                            this.<text>__0 = "thats great! youve always been really talented. im sure whatever major you pick youll be great =]";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<>f__this.dmb.ShowStatusLabel("you chose to attend a business school");
                            this.<text>__0 = "thats crazy! if anyone could do it you could, im sure youll be really succesful.";
                        }
                    }
                    else
                    {
                        this.<>f__this.dmb.ShowStatusLabel("you chose to attend an engineering school");
                        this.<text>__0 = "thats awesome! youve always been super smart. im sure youll do really well!";
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 2f),
                        new WaitingAction(WaitingActionType.Typing, 2.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 50;
                    goto Label_25ED;

                case 50:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x33;
                    goto Label_25ED;

                case 0x33:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 2f),
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1f),
                        new WaitingAction(WaitingActionType.Deleting, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x34;
                    goto Label_25ED;

                case 0x34:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("even though we're going to different schools, do you promise you'll be there for me?", ChatMessageType.OtherMessage, 1f));
                    this.$PC = 0x35;
                    goto Label_25ED;

                case 0x35:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("absolutely", "ill do my best", "i cant promise"));
                    this.$PC = 0x36;
                    goto Label_25ED;

                case 0x36:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "ill do my best, i like having you in my life, youre my best<<<<<<<one of my best friends~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "i cant promise something like that, well see what happens, im sure ill be crazy busy once college starts~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "absolutely! nothing could ever keep me from talking to you, youre my best<<<<<<<one of my best friends~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x37;
                    goto Label_25ED;

                case 0x37:
                    this.<>f__this.dmb.ShowRememberLabel();
                    ChatValues.Chapter1DidPromise = this.<>f__this.answer != 3;
                    if (this.<>f__this.answer != 3)
                    {
                        goto Label_185E;
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 2f), new WaitingAction(1, 2f), new WaitingAction(2, 0.5f), new WaitingAction(1, 1f) }));
                    this.$PC = 0x38;
                    goto Label_25ED;

                case 0x38:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("oh okay, i just really like having you in my life. i dont want to lose that.", ChatMessageType.OtherMessage, 2f));
                    this.$PC = 0x39;
                    goto Label_25ED;

                case 0x39:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("you wont!", "im sure well be fine", "i like you in my life too"));
                    this.$PC = 0x3a;
                    goto Label_25ED;

                case 0x3a:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "im sure well be fine emily :], youre my best<<<<<<<one of my best friends~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "and i like having you in my life too, youre my best<<<<<<<one of my best friends~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "you wont! i want to be a part of you life :], youre my best<<<<<<<one of my best friends~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x3b;
                    goto Label_25ED;

                case 0x3b:
                    goto Label_185E;

                case 60:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("and youre one of mine too! you always will be " + ChatValues.GetPlayerName().ToLower() + " =]", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x3d;
                    goto Label_25ED;

                case 0x3d:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 0.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x3e;
                    goto Label_25ED;

                case 0x3e:
                    BuddyListBehavior.Instance.ChangeBuddyStatus(ChatValues.JulieUsername, BuddyStatus.Away, ChatValues.Script1JulieAway, true);
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 2f) }));
                    this.$PC = 0x3f;
                    goto Label_25ED;

                case 0x3f:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("oh wow, its getting late! i hope julie gets here soon so we can head to the party.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x40;
                    goto Label_25ED;

                case 0x40:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("julie who?", "i hope so too!", "are you leaving soon?"));
                    this.$PC = 0x41;
                    goto Label_25ED;

                case 0x41:
                    if (this.<>f__this.answer == 1)
                    {
                        this.<text>__0 = "julie who?~";
                    }
                    else if (this.<>f__this.answer == 2)
                    {
                        this.<text>__0 = "i hope so too!~";
                    }
                    else if (this.<>f__this.answer == 3)
                    {
                        this.<text>__0 = "are you leaving soon?~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x42;
                    goto Label_25ED;

                case 0x42:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "haha thanks, shes supposed to come over then were both heading to travs party";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "yeah, soon as julie gets here. then were both heading to travs party";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "julie miller! shes in our math class, once she gets here were both heading to travs party";
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 2f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x43;
                    goto Label_25ED;

                case 0x43:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x44;
                    goto Label_25ED;

                case 0x44:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x45;
                    goto Label_25ED;

                case 0x45:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("if youre coming too you should probably leave soon. will i see you there?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 70;
                    goto Label_25ED;

                case 70:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("definitely!", "i dont think so", "im just going to stay home"));
                    this.$PC = 0x47;
                    goto Label_25ED;

                case 0x47:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "i dont think so~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "i think im just going to stay home~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "yeah, definitely!~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x48;
                    goto Label_25ED;

                case 0x48:
                    ChatValues.Chapter1WentToParty = this.<>f__this.answer == 1;
                    if (this.<>f__this.answer != 1)
                    {
                        this.<>f__this.dmb.ShowStatusLabel("you chose to skip the party");
                        this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1.5f), new WaitingAction(1, 1f) }));
                        this.$PC = 0x4f;
                    }
                    else
                    {
                        this.<>f__this.dmb.ShowStatusLabel("you chose to attend the party");
                        this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 1.5f) }));
                        this.$PC = 0x49;
                    }
                    goto Label_25ED;

                case 0x49:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("awesome! im going to go get ready and wait for julie.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x4a;
                    goto Label_25ED;

                case 0x4a:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x4b;
                    goto Label_25ED;

                case 0x4b:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("hopefully brad stops messaging me once i put up my away message :p", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x4c;
                    goto Label_25ED;

                case 0x4c:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x4d;
                    goto Label_25ED;

                case 0x4d:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("see you soon!", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x4e;
                    goto Label_25ED;

                case 0x4e:
                case 0x5e:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("see ya", "later", "goodbye"));
                    this.$PC = 0x5f;
                    goto Label_25ED;

                case 0x4f:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("oh okay, thats too bad.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 80;
                    goto Label_25ED;

                case 80:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x51;
                    goto Label_25ED;

                case 0x51:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("but hey! if youre sticking around, could you help me figure out what to say to brad?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x52;
                    goto Label_25ED;

                case 0x52:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 2f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x53;
                    goto Label_25ED;

                case 0x53:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("he just said 'hed really like to talk' and i dont know what to say.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x54;
                    goto Label_25ED;

                case 0x54:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("tell him youll talk later", "just say you dont want to", "make up an excuse!"));
                    this.$PC = 0x55;
                    goto Label_25ED;

                case 0x55:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "just say you fon<<<dont want to~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "you could nak<<<make up an excuse!~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "tell him yoyll<<<ull just talk later~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x56;
                    goto Label_25ED;

                case 0x56:
                    this.<secondaryText>__1 = string.Empty;
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "okay, hopefully he doesnt get upset.";
                            this.<secondaryText>__1 = "he said alright, thanks for the advice =]";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "thats a good idea! ill just say julies here now";
                            this.<secondaryText>__1 = "he said we can talk later, thanks for the advice =]";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "oh, thats a good idea!";
                        this.<secondaryText>__1 = "he said okay! thanks for the advice =]";
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x57;
                    goto Label_25ED;

                case 0x57:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x58;
                    goto Label_25ED;

                case 0x58:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 4f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x59;
                    goto Label_25ED;

                case 0x59:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<secondaryText>__1, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 90;
                    goto Label_25ED;

                case 90:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("no problem", "anytime!", "youre welcome"));
                    this.$PC = 0x5b;
                    goto Label_25ED;

                case 0x5b:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "yeah anytime!~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "youre welcome~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "no problem~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x5c;
                    goto Label_25ED;

                case 0x5c:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x5d;
                    goto Label_25ED;

                case 0x5d:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("im gonna go get ready for the party, see you at school monday!", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x5e;
                    goto Label_25ED;

                case 0x5f:
                    if (this.<>f__this.answer == 1)
                    {
                        this.<text>__0 = "see ya~";
                    }
                    else if (this.<>f__this.answer == 2)
                    {
                        this.<text>__0 = "later~";
                    }
                    else if (this.<>f__this.answer == 3)
                    {
                        this.<text>__0 = "goodbye~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x60;
                    goto Label_25ED;

                case 0x60:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(ChatValues.AwayText, ChatMessageType.OtherAway, 2f));
                    this.$PC = 0x61;
                    goto Label_25ED;

                case 0x61:
                    this.<>f__this.currentStatus = BuddyStatus.Away;
                    BuddyListBehavior.Instance.ChangeBuddyStatus(ChatValues.OtherUsername, BuddyStatus.Away, null, false);
                    ChatValues.SetCurrentLevel(1);
                    this.<>f__this.SetCompletionAchievement(1);
                    this.$current = new WaitForSeconds(2.5f);
                    this.$PC = 0x62;
                    goto Label_25ED;

                case 0x62:
                    LoadingScreenBehavior.Instance.LoadMenuScene(false);
                    this.$PC = -1;
                    goto Label_25EB;

                default:
                    goto Label_25EB;
            }
            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, true));
            this.$PC = 4;
            goto Label_25ED;
        Label_07E5:
            list = new List<WaitingAction>();
            list.Add(new WaitingAction(WaitingActionType.Idle, 2f));
            list.Add(new WaitingAction(WaitingActionType.Typing, 2f));
            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
            this.$PC = 0x11;
            goto Label_25ED;
        Label_185E:
            list = new List<WaitingAction>();
            list.Add(new WaitingAction(WaitingActionType.Idle, 2f));
            list.Add(new WaitingAction(WaitingActionType.Typing, 2f));
            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
            this.$PC = 60;
            goto Label_25ED;
        Label_25EB:
            return false;
        Label_25ED:
            return true;
        }

        [DebuggerHidden]
        public void Reset()
        {
            throw new NotSupportedException();
        }

        object IEnumerator<object>.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }

        object IEnumerator.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }
    }
}

