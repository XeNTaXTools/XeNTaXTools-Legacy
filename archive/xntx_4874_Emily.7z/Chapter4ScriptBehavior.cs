﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnityEngine;

public class Chapter4ScriptBehavior : BaseScriptBehavior
{
    private BuddyStatus currentStatus;

    public override void DidPressInfoButton()
    {
        BuddyInfoBehavior.Instance.SetUp(ChatValues.OtherUsername, ChatValues.Script4BuddyInfo, ChatValues.ColorFromRGB(0x25, 12, 0x31), this.currentStatus, null);
        BuddyInfoBehavior.Instance.Show();
    }

    public override void DidPressTextButton(int index)
    {
        base.answer = index;
    }

    public override void PlayScript()
    {
        TaskBarBehavior.Instance.SetState(TaskBarState.BuddyList);
        BuddyListBehavior.Instance.Show();
        DisplayManagerBehavior.Instance.SetBuddyIcons(ChatValues.GetPlayerBuddyIcon(), BuddyIconType.EmilyDeathCab);
        base.StartCoroutine(this.ScriptRunner());
    }

    [DebuggerHidden]
    private IEnumerator ScriptRunner()
    {
        return new <ScriptRunner>c__IteratorB { <>f__this = this };
    }

    public override void SetUpBuddyList()
    {
        BuddyListBehavior instance = BuddyListBehavior.Instance;
        instance.AddBuddyRow(ChatValues.OtherUsername, ChatValues.Script4BuddyInfo, ChatValues.ColorFromRGB(0x25, 12, 0x31), BuddyStatus.Offline, null);
        instance.AddBuddyRow(ChatValues.BradUsername, ChatValues.Script4BradInfo, ChatValues.ColorFromRGB(0xff, 230, 230), BuddyStatus.Online, null);
        instance.AddBuddyRow(ChatValues.TravisUsername, ChatValues.Script4TravisInfo, ChatValues.ColorFromRGB(0xab, 230, 0xff), BuddyStatus.Online, null);
        instance.AddBuddyRow(ChatValues.JulieUsername, ChatValues.Script4JulieInfo, ChatValues.ColorFromRGB(0x52, 9, 0x90), BuddyStatus.Online, null);
        instance.AddBuddyRow(ChatValues.MikeUsername, ChatValues.Script4MikeInfo, ChatValues.ColorFromRGB(0xd7, 0xd7, 0xd7), BuddyStatus.Online, null);
        instance.AddBuddyRow(ChatValues.EmmaUsername, ChatValues.Script4EmmaInfo, ChatValues.ColorFromRGB(0, 14, 0x30), BuddyStatus.Away, ChatValues.Script4EmmaAway);
        instance.AddOfflineOnlyBuddyRow("ActualSun8");
        instance.AddOfflineOnlyBuddyRow("CooknServe");
        instance.AddOfflineOnlyBuddyRow("DarkDunJin");
        instance.AddOfflineOnlyBuddyRow("KingCounting");
        instance.AddOfflineOnlyBuddyRow("Shroomz11");
    }

    [CompilerGenerated]
    private sealed class <ScriptRunner>c__IteratorB : IEnumerator, IDisposable, IEnumerator<object>
    {
        internal object $current;
        internal int $PC;
        internal Chapter4ScriptBehavior <>f__this;
        internal bool <didDrink>__5;
        internal bool <didEmilyHookUp>__4;
        internal string <choseText>__3;
        internal bool <playerWillTalk>__1;
        internal int <rejectReason>__7;
        internal string <secondaryText>__2;
        internal string <text>__0;
        internal int <typeOfVisit>__6;

        [DebuggerHidden]
        public void Dispose()
        {
            this.$PC = -1;
        }

        public bool MoveNext()
        {
            List<WaitingAction> list;
            uint num = (uint) this.$PC;
            this.$PC = -1;
            switch (num)
            {
                case 0:
                    this.<text>__0 = string.Empty;
                    this.$current = new WaitForSeconds(2f);
                    this.$PC = 1;
                    goto Label_4ACF;

                case 1:
                    TaskBarBehavior.Instance.SetState(TaskBarState.BuddyListChat);
                    BuddyListBehavior.Instance.Hide();
                    DisplayManagerBehavior.Instance.Show();
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(ChatValues.SignInText, ChatMessageType.OtherSignIn, 0f));
                    this.$PC = 2;
                    goto Label_4ACF;

                case 2:
                    this.<>f__this.currentStatus = BuddyStatus.Online;
                    BuddyListBehavior.Instance.ChangeBuddyStatus(ChatValues.OtherUsername, BuddyStatus.Online, null, false);
                    this.$current = new WaitForSeconds(1f);
                    this.$PC = 3;
                    goto Label_4ACF;

                case 3:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Typing, 1f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 4;
                    goto Label_4ACF;

                case 4:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("hey.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 5;
                    goto Label_4ACF;

                case 5:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("hello", "hey!", "yo yo."));
                    this.$PC = 6;
                    goto Label_4ACF;

                case 6:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "hey!~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "yo yo.~";
                        }
                        break;
                    }
                    this.<text>__0 = "hello.~";
                    break;

                case 7:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 2f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 8;
                    goto Label_4ACF;

                case 8:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("I know it's been a while since we last talked.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 9;
                    goto Label_4ACF;

                case 9:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("that's okay", "no worries!", "whatever"));
                    this.$PC = 10;
                    goto Label_4ACF;

                case 10:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "no worru<ies!~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "it's whatee<ver.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "that's okat<y.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 11;
                    goto Label_4ACF;

                case 11:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 0.5f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 12;
                    goto Label_4ACF;

                case 12:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("I've just been going through a lot lately.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 13;
                    goto Label_4ACF;

                case 13:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("like what?", "everything okay?", "what's been up?"));
                    this.$PC = 14;
                    goto Label_4ACF;

                case 14:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "is everyr<thing okay?~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "what's beeh<n up?~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "what kinf<d of stuff?~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 15;
                    goto Label_4ACF;

                case 15:
                    if (this.<>f__this.answer == 2)
                    {
                        this.<text>__0 = "yeah, everything is fine.";
                    }
                    else
                    {
                        this.<text>__0 = "just some stuff I had to deal with.";
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 2f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x10;
                    goto Label_4ACF;

                case 0x10:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x11;
                    goto Label_4ACF;

                case 0x11:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 0.5f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x12;
                    goto Label_4ACF;

                case 0x12:
                    BuddyListBehavior.Instance.ChangeBuddyStatus(ChatValues.BradUsername, BuddyStatus.Away, ChatValues.Script4BradAway, true);
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(1, 1f), new WaitingAction(0, 0.5f) }));
                    this.$PC = 0x13;
                    goto Label_4ACF;

                case 0x13:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("so listen, I was hoping we could talk about things.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 20;
                    goto Label_4ACF;

                case 20:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("of course", "okay, sure", "i don't know"));
                    this.$PC = 0x15;
                    goto Label_4ACF;

                case 0x15:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "okay, sure.~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "i don't know.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "of course, what's up?~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x16;
                    goto Label_4ACF;

                case 0x16:
                    this.<playerWillTalk>__1 = true;
                    if (this.<>f__this.answer != 3)
                    {
                        goto Label_1012;
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1.5f), new WaitingAction(1, 2f), new WaitingAction(0, 0.5f) }));
                    this.$PC = 0x17;
                    goto Label_4ACF;

                case 0x17:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("please, I know it's been a while but I think I need to.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x18;
                    goto Label_4ACF;

                case 0x18:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("okay, what's up?", "not right now", "i don't want to"));
                    this.$PC = 0x19;
                    goto Label_4ACF;

                case 0x19:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "i can't ralk<<<<talk right now.~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "i don't qant<<<<want to.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "poka<<<<okay, what's up?~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x1a;
                    goto Label_4ACF;

                case 0x1a:
                    this.<playerWillTalk>__1 = this.<>f__this.answer == 1;
                    if (this.<>f__this.answer != 2)
                    {
                        if (this.<>f__this.answer == 3)
                        {
                            this.<>f__this.dmb.ShowStatusLabel("you chose to not talk");
                            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1.5f), new WaitingAction(1, 1f), new WaitingAction(0, 0.5f), new WaitingAction(2, 1f), new WaitingAction(0, 1f), new WaitingAction(1, 1.5f) }));
                            this.$PC = 0x23;
                            goto Label_4ACF;
                        }
                        goto Label_1012;
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1.5f), new WaitingAction(1, 0.5f), new WaitingAction(0, 0.5f), new WaitingAction(1, 1f) }));
                    this.$PC = 0x1b;
                    goto Label_4ACF;

                case 0x1b:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("okay, what are you busy with?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x1c;
                    goto Label_4ACF;

                case 0x1c:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("homework", "hanging out", "some things"));
                    this.$PC = 0x1d;
                    goto Label_4ACF;

                case 0x1d:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "i'm hanging out with some friends in a bit.~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "i just have to do some things.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "just some homework.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 30;
                    goto Label_4ACF;

                case 30:
                    ChatValues.Chapter4TypeOfExcuse = this.<>f__this.answer;
                    this.<>f__this.dmb.ShowStatusLabel("you chose to make an excuse");
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1.5f), new WaitingAction(1, 1f), new WaitingAction(0, 0.5f), new WaitingAction(1, 1f) }));
                    this.$PC = 0x1f;
                    goto Label_4ACF;

                case 0x1f:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("okay, well we'll talk later I guess.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x20;
                    goto Label_4ACF;

                case 0x20:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 0.5f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x21;
                    goto Label_4ACF;

                case 0x21:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("bye.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x22;
                    goto Label_4ACF;

                case 0x22:
                case 0x24:
                    goto Label_1012;

                case 0x23:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("you know, you should try thinking about someone other than yourself for once.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x24;
                    goto Label_4ACF;

                case 0x25:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("I just feel like things are weird between us.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x26;
                    goto Label_4ACF;

                case 0x26:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 2f),
                        new WaitingAction(WaitingActionType.Typing, 1f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x27;
                    goto Label_4ACF;

                case 0x27:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("have you felt like that?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 40;
                    goto Label_4ACF;

                case 40:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("i feel weird too", "i don't think so", "i haven't noticed anything"));
                    this.$PC = 0x29;
                    goto Label_4ACF;

                case 0x29:
                    if (this.<>f__this.answer == 1)
                    {
                        this.<text>__0 = "i feel weu<ird too.~";
                    }
                    else if (this.<>f__this.answer == 2)
                    {
                        this.<text>__0 = "i don't thim<nk so.~";
                    }
                    else if (this.<>f__this.answer == 3)
                    {
                        this.<text>__0 = "i haven't notix<ced anything.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x2a;
                    goto Label_4ACF;

                case 0x2a:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x2b;
                    goto Label_4ACF;

                case 0x2b:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("I think it's because of last year.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x2c;
                    goto Label_4ACF;

                case 0x2c:
                    if (!ChatValues.Chapter3EmilyVisited)
                    {
                        list = new List<WaitingAction> {
                            new WaitingAction(WaitingActionType.Idle, 2f),
                            new WaitingAction(WaitingActionType.Typing, 1.5f),
                            new WaitingAction(WaitingActionType.Idle, 0.5f)
                        };
                        this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                        this.$PC = 0x60;
                    }
                    else
                    {
                        this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 2f), new WaitingAction(1, 1.5f), new WaitingAction(0, 0.5f) }));
                        this.$PC = 0x2d;
                    }
                    goto Label_4ACF;

                case 0x2d:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("things have been weird since I came to visit.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x2e;
                    goto Label_4ACF;

                case 0x2e:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 2f),
                        new WaitingAction(WaitingActionType.Typing, 0.5f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f),
                        new WaitingAction(WaitingActionType.Typing, 1f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x2f;
                    goto Label_4ACF;

                case 0x2f:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(ChatValues.GetPlayerName().ToLower() + " please be honest with me.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x30;
                    goto Label_4ACF;

                case 0x30:
                    this.<didEmilyHookUp>__4 = !ChatValues.Chapter3EstablishedBoundaries;
                    this.<didDrink>__5 = ChatValues.Chapter3WillDrinkTogether;
                    if (!this.<didEmilyHookUp>__4)
                    {
                        list = new List<WaitingAction> {
                            new WaitingAction(WaitingActionType.Idle, 2f),
                            new WaitingAction(WaitingActionType.Typing, 1.5f),
                            new WaitingAction(WaitingActionType.Idle, 0.5f)
                        };
                        this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                        this.$PC = 0x47;
                    }
                    else
                    {
                        this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 2f), new WaitingAction(1, 1.5f), new WaitingAction(0, 0.5f) }));
                        this.$PC = 0x31;
                    }
                    goto Label_4ACF;

                case 0x31:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("did you plan that we would hook up?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 50;
                    goto Label_4ACF;

                case 50:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("i thought it was possible", "i hoped we would", "of course not"));
                    this.$PC = 0x33;
                    goto Label_4ACF;

                case 0x33:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "i really hoped that we would.~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "of course i didn't plan that.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "i thought it was possible.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x34;
                    goto Label_4ACF;

                case 0x34:
                    this.<>f__this.dmb.ShowRememberLabel();
                    if (this.<>f__this.answer != 3)
                    {
                        this.<text>__0 = "in retrospect it all just seems so planned out.";
                    }
                    else
                    {
                        this.<text>__0 = "okay, just in retrospect it all seems so planned out.";
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f),
                        new WaitingAction(WaitingActionType.Typing, 1f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x35;
                    goto Label_4ACF;

                case 0x35:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x36;
                    goto Label_4ACF;

                case 0x36:
                    this.<typeOfVisit>__6 = ChatValues.Chapter3TypeOfWeekend;
                    if (this.<typeOfVisit>__6 != 1)
                    {
                        if (this.<typeOfVisit>__6 == 2)
                        {
                            this.<text>__0 = "I mean, we went to parties like every night.";
                            if (this.<didDrink>__5)
                            {
                                this.<secondaryText>__2 = "and we both drank a whole lot.";
                            }
                            else
                            {
                                this.<secondaryText>__2 = "and then we'd go back to your dorm to spend the night.";
                            }
                        }
                        else if (this.<typeOfVisit>__6 == 3)
                        {
                            this.<text>__0 = "I mean, we hung out with your friends around campus.";
                            if (this.<didDrink>__5)
                            {
                                this.<secondaryText>__2 = "and then we'd go back to your dorm to drink.";
                            }
                            else
                            {
                                this.<secondaryText>__2 = "and then we'd go back to your dorm to spend the night.";
                            }
                        }
                    }
                    else
                    {
                        this.<text>__0 = "I mean, we spent the whole time hanging out in your dorm.";
                        if (!this.<didDrink>__5)
                        {
                            this.<secondaryText>__2 = "and we only really left to get food and stuff.";
                        }
                        else
                        {
                            this.<secondaryText>__2 = "and at night we hung out with your friends and drank.";
                        }
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 2f),
                        new WaitingAction(WaitingActionType.Typing, 2f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x37;
                    goto Label_4ACF;

                case 0x37:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x38;
                    goto Label_4ACF;

                case 0x38:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 2f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x39;
                    goto Label_4ACF;

                case 0x39:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<secondaryText>__2, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x3a;
                    goto Label_4ACF;

                case 0x3a:
                    if (!this.<didDrink>__5)
                    {
                        list = new List<WaitingAction> {
                            new WaitingAction(WaitingActionType.Idle, 2f),
                            new WaitingAction(WaitingActionType.Typing, 1f),
                            new WaitingAction(WaitingActionType.Idle, 0.5f),
                            new WaitingAction(WaitingActionType.Deleting, 1f),
                            new WaitingAction(WaitingActionType.Typing, 1.5f)
                        };
                        this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                        this.$PC = 0x3f;
                    }
                    else
                    {
                        this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 2f), new WaitingAction(1, 1f), new WaitingAction(0, 0.5f), new WaitingAction(2, 1f), new WaitingAction(1, 1.5f) }));
                        this.$PC = 0x3b;
                    }
                    goto Label_4ACF;

                case 0x3b:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("did you want us to get really drunk?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 60;
                    goto Label_4ACF;

                case 60:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("of course not!", "i got drunk too", "i just wanted to have fun"));
                    this.$PC = 0x3d;
                    goto Label_4ACF;

                case 0x3d:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "no, i got drunk too em. you wanted to hook up <<<<<<<<<<<<<<<<<<<<<<i don't know.~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "i just wanted to have fun. you wanted to hook up <<<<<<<<<<<<<<<<<<<<<<i don't know.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "of course not! we just drank a lot. you wanted to hook up <<<<<<<<<<<<<<<<<<<<<<i don't know.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x3e;
                    goto Label_4ACF;

                case 0x3e:
                    this.<>f__this.dmb.ShowRememberLabel();
                    if (this.<>f__this.answer == 3)
                    {
                        this.<text>__0 = "I know, me too. I just";
                        this.<secondaryText>__2 = "I don't know";
                    }
                    else
                    {
                        this.<text>__0 = "I know, I just";
                        this.<secondaryText>__2 = "I don't know.";
                    }
                    goto Label_1CE7;

                case 0x3f:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("you must have known how vulnerable I was.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x40;
                    goto Label_4ACF;

                case 0x40:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("i didn't know", "i didn't think it was an issue", "i just wanted to have fun"));
                    this.$PC = 0x41;
                    goto Label_4ACF;

                case 0x41:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "i knew, i just didn't think it was an issue. you wanted to hook up <<<<<<<<<<<<<<<<<<<<<<i don't know.~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "i just wanted to have fun. you wanted to hook up <<<<<<<<<<<<<<<<<<<<<<i don't know.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "i didn't know. you seemed fine. you wanted to hook up <<<<<<<<<<<<<<<<<<<<<<i don't know.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x42;
                    goto Label_4ACF;

                case 0x42:
                    this.<>f__this.dmb.ShowRememberLabel();
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "it wasn't an issue. I just";
                            this.<secondaryText>__2 = "I don't know";
                        }
                        else
                        {
                            this.<text>__0 = "me too, I just";
                            this.<secondaryText>__2 = "I don't know";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "okay, I just";
                        this.<secondaryText>__2 = "I don't know.";
                    }
                    goto Label_1CE7;

                case 0x43:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x44;
                    goto Label_4ACF;

                case 0x44:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f),
                        new WaitingAction(WaitingActionType.Deleting, 1f),
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x45;
                    goto Label_4ACF;

                case 0x45:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<secondaryText>__2, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 70;
                    goto Label_4ACF;

                case 70:
                case 0x56:
                    if (this.<didEmilyHookUp>__4 && this.<didDrink>__5)
                    {
                        this.<text>__0 = "did you not want to hook up?";
                    }
                    else
                    {
                        this.<text>__0 = "do you regret coming to visit?";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer(this.<text>__0, "did you have a bad time?", "did i do something wrong?"));
                    this.$PC = 0x57;
                    goto Label_4ACF;

                case 0x47:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("did you have feelings for me when I visited?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x48;
                    goto Label_4ACF;

                case 0x48:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("i really liked you", "maybe, i don't know", "no, not really"));
                    this.$PC = 0x49;
                    goto Label_4ACF;

                case 0x49:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "maybe, its more complic<<<<<<<<<<<<<<<<i don't know.~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "no, not really.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "yeah, i really liked you.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x4a;
                    goto Label_4ACF;

                case 0x4a:
                    if (this.<>f__this.answer == 3)
                    {
                        list = new List<WaitingAction> {
                            new WaitingAction(WaitingActionType.Idle, 1.5f),
                            new WaitingAction(WaitingActionType.Typing, 1f),
                            new WaitingAction(WaitingActionType.Idle, 0.5f),
                            new WaitingAction(WaitingActionType.Typing, 1f)
                        };
                        this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                        this.$PC = 0x4f;
                    }
                    else
                    {
                        this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1.5f), new WaitingAction(1, 1f), new WaitingAction(0, 0.5f), new WaitingAction(1, 1f) }));
                        this.$PC = 0x4b;
                    }
                    goto Label_4ACF;

                case 0x4b:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("then why didn't anything happen between us?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x4c;
                    goto Label_4ACF;

                case 0x4c:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("i didn't want to mess things up", "there wasn't a good time", "i don't know"));
                    this.$PC = 0x4d;
                    goto Label_4ACF;

                case 0x4d:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "there wasn't a good time. you should have made a move<<<<<<<<<<<<<<<<<<<<<<<<<<i don't know.~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "you should have made a move<<<<<<<<<<<<<<<<<<<<<<<<<<i don't know.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "i didn't want to mess things up. you should have made a move<<<<<<<<<<<<<<<<<<<<<<<<<<i don't know.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x4e;
                    goto Label_4ACF;

                case 0x4e:
                    this.<>f__this.dmb.ShowRememberLabel();
                    goto Label_22EE;

                case 0x4f:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("then why did you tell me to come and visit?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 80;
                    goto Label_4ACF;

                case 80:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("because you wanted to", "you needed a friend", "i don't know"));
                    this.$PC = 0x51;
                    goto Label_4ACF;

                case 0x51:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "you needed a friend. i didn't want to be more <<<<<<<<<<<<<<<<<<<<<<<<<i don't know.~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "i didn't want to be more <<<<<<<<<<<<<<<<<<<<<<<<<i don't know.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "because you wanted to. i didn't want to be more <<<<<<<<<<<<<<<<<<<<<<<<<i don't know.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x52;
                    goto Label_4ACF;

                case 0x52:
                    this.<>f__this.dmb.ShowRememberLabel();
                    goto Label_22EE;

                case 0x53:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("I just had a lot of feelings for you.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x54;
                    goto Label_4ACF;

                case 0x54:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 2f),
                        new WaitingAction(WaitingActionType.Typing, 1f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f),
                        new WaitingAction(WaitingActionType.Deleting, 1f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x55;
                    goto Label_4ACF;

                case 0x55:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("and I felt like our lives had finally lined up.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x56;
                    goto Label_4ACF;

                case 0x57:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "did you have a bad time?~";
                            this.<choseText>__3 = "you chose to ask about her visit";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "did i do something wrong?~";
                            this.<choseText>__3 = "you chose to ask about yourself";
                        }
                    }
                    else if (!this.<didEmilyHookUp>__4 || !this.<didDrink>__5)
                    {
                        this.<text>__0 = "do you regret coming to visit?~";
                        this.<choseText>__3 = "you chose to ask about her regrets";
                    }
                    else
                    {
                        this.<text>__0 = "did you not want to hook up?~";
                        this.<choseText>__3 = "you chose to ask about her feelings";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x58;
                    goto Label_4ACF;

                case 0x58:
                    this.<>f__this.dmb.ShowStatusLabel(this.<choseText>__3);
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "no, i had a good time.";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "no, you didn't.";
                        }
                    }
                    else if (!this.<didEmilyHookUp>__4 || !this.<didDrink>__5)
                    {
                        this.<text>__0 = "no, i don't regret it.";
                    }
                    else
                    {
                        this.<text>__0 = "no, at least i thought i did.";
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x59;
                    goto Label_4ACF;

                case 0x59:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 90;
                    goto Label_4ACF;

                case 90:
                    if (!this.<didEmilyHookUp>__4)
                    {
                        this.<text>__0 = "I just feel like if we ever had a time it was then.";
                        this.<secondaryText>__2 = "it's just made me feel differently.";
                    }
                    else
                    {
                        this.<text>__0 = "just a lot happened really quickly.";
                        this.<secondaryText>__2 = "it's just made me feel differently.";
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 2f),
                        new WaitingAction(WaitingActionType.Typing, 2f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x5b;
                    goto Label_4ACF;

                case 0x5b:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x5c;
                    goto Label_4ACF;

                case 0x5c:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 2f),
                        new WaitingAction(WaitingActionType.Typing, 0.5f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x5d;
                    goto Label_4ACF;

                case 0x5d:
                    BuddyListBehavior.Instance.ChangeBuddyStatus(ChatValues.JulieUsername, BuddyStatus.Away, ChatValues.Script4JuleAway, true);
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(1, 1f) }));
                    this.$PC = 0x5e;
                    goto Label_4ACF;

                case 0x5e:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<secondaryText>__2, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x5f;
                    goto Label_4ACF;

                case 0x5f:
                case 0x86:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("in a bad way?", "different than what?", "I'm sorry"));
                    this.$PC = 0x87;
                    goto Label_4ACF;

                case 0x60:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("things have been weird since I broke down.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x61;
                    goto Label_4ACF;

                case 0x61:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 2f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x62;
                    goto Label_4ACF;

                case 0x62:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("since I asked to visit.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x63;
                    goto Label_4ACF;

                case 0x63:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("i'm sorry", "i regret not saying yes", "it would have been a bad idea"));
                    this.$PC = 100;
                    goto Label_4ACF;

                case 100:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "i regret not saying yes.~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "it would have been a bad idea.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "i'm sorry.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x65;
                    goto Label_4ACF;

                case 0x65:
                    if (this.<>f__this.answer == 3)
                    {
                        this.<text>__0 = "if you say so.";
                    }
                    else
                    {
                        this.<text>__0 = "it's okay, it is what it is.";
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x66;
                    goto Label_4ACF;

                case 0x66:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x67;
                    goto Label_4ACF;

                case 0x67:
                    this.<rejectReason>__7 = ChatValues.Chapter3TypeRejectReasoning;
                    if (this.<rejectReason>__7 != 1)
                    {
                        if (this.<rejectReason>__7 != 2)
                        {
                            if (this.<rejectReason>__7 != 3)
                            {
                                goto Label_3340;
                            }
                            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 2f), new WaitingAction(1, 2f) }));
                            this.$PC = 0x74;
                        }
                        else
                        {
                            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 2f), new WaitingAction(1, 2f) }));
                            this.$PC = 110;
                        }
                    }
                    else
                    {
                        this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 2f), new WaitingAction(1, 2f) }));
                        this.$PC = 0x68;
                    }
                    goto Label_4ACF;

                case 0x68:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("that night when I asked, you said it would complicate things.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x69;
                    goto Label_4ACF;

                case 0x69:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 2f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x6a;
                    goto Label_4ACF;

                case 0x6a:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("what did you mean by that?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x6b;
                    goto Label_4ACF;

                case 0x6b:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("i only wanted to be friends", "i was worried something would happen", "you had just gone through a break up"));
                    this.$PC = 0x6c;
                    goto Label_4ACF;

                case 0x6c:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "i was worred somrthing<<<<<<ething would happen.~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "you had just gone htrough<<<<<<<through a break up.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "i only wanted to be griend<<<<<<friends.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x6d;
                    goto Label_4ACF;

                case 0x6d:
                    this.<>f__this.dmb.ShowRememberLabel();
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "like what? all I wanted was a friend to keep my mind off things.";
                            this.<secondaryText>__2 = string.Empty;
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "but that's why I needed to get away.";
                            this.<secondaryText>__2 = "that's why I needed a friend.";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "and what I needed more than anything was a friend.";
                        this.<secondaryText>__2 = string.Empty;
                    }
                    goto Label_3340;

                case 110:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("that night when I asked, you said it wasn't a good time.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x6f;
                    goto Label_4ACF;

                case 0x6f:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 2f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x70;
                    goto Label_4ACF;

                case 0x70:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("what did you mean by that?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x71;
                    goto Label_4ACF;

                case 0x71:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("i already had plans", "i didn't want to screw things up", "you had just gone through a break up"));
                    this.$PC = 0x72;
                    goto Label_4ACF;

                case 0x72:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "i didn't want to screw up our fiendsh<<<<<<riendship.~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "you had just gone htrough<<<<<<<through a break up.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "i aleady<<<<ready had plans with emma.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x73;
                    goto Label_4ACF;

                case 0x73:
                    this.<>f__this.dmb.ShowRememberLabel();
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "all I wanted was a friend.";
                            this.<secondaryText>__2 = "I don't see how that could screw things up.";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "but that's why I needed to get away.";
                            this.<secondaryText>__2 = "that's why I needed a friend.";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "you didn't have to choose between me and her.";
                        this.<secondaryText>__2 = "all I wanted was a friend.";
                    }
                    goto Label_3340;

                case 0x74:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("that night when I asked, you said I'd be fine without you.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x75;
                    goto Label_4ACF;

                case 0x75:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 2f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x76;
                    goto Label_4ACF;

                case 0x76:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("what did you mean by that?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x77;
                    goto Label_4ACF;

                case 0x77:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("you could make new friends", "you didn't need me", "you're a strong girl"));
                    this.$PC = 120;
                    goto Label_4ACF;

                case 120:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "you didn't beed<<<<need me to get by.~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "that your a<<<<<<you're a strong girl.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "i knew you would make new fiend<<<<<friends.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x79;
                    goto Label_4ACF;

                case 0x79:
                    this.<>f__this.dmb.ShowRememberLabel();
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "I didn't need your help.";
                            this.<secondaryText>__2 = "but it would have been nice.";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "well thank you, but being alone is still hard.";
                            this.<secondaryText>__2 = "I really could have used a friend.";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "I didn't want to make new friends.";
                        this.<secondaryText>__2 = "I wanted you to be my friend.";
                    }
                    goto Label_3340;

                case 0x7a:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x7b;
                    goto Label_4ACF;

                case 0x7b:
                    if (string.IsNullOrEmpty(this.<secondaryText>__2))
                    {
                        goto Label_34A5;
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 2f), new WaitingAction(1, 1.5f), new WaitingAction(0, 0.5f) }));
                    this.$PC = 0x7c;
                    goto Label_4ACF;

                case 0x7c:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<secondaryText>__2, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x7d;
                    goto Label_4ACF;

                case 0x7d:
                    goto Label_34A5;

                case 0x7e:
                    if (this.<>f__this.answer == 1)
                    {
                        this.<text>__0 = "are you sy<till mad at me?~";
                        this.<choseText>__3 = "you chose to ask about yourself";
                    }
                    else if (this.<>f__this.answer == 2)
                    {
                        this.<text>__0 = "you couk<ld visit now.~";
                        this.<choseText>__3 = "you chose to suggest another visit";
                    }
                    else if (this.<>f__this.answer == 3)
                    {
                        this.<text>__0 = "i'm sorry, i wish i coy<uld change things.~";
                        this.<choseText>__3 = "you chose to admit fault";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x7f;
                    goto Label_4ACF;

                case 0x7f:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "I wish so too.";
                        }
                        else if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "I don't think I want to.";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "well I was never mad.";
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x80;
                    goto Label_4ACF;

                case 0x80:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x81;
                    goto Label_4ACF;

                case 0x81:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 2f),
                        new WaitingAction(WaitingActionType.Typing, 2f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 130;
                    goto Label_4ACF;

                case 130:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("I guess I just thought you would be there for me.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x83;
                    goto Label_4ACF;

                case 0x83:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 2f),
                        new WaitingAction(WaitingActionType.Typing, 0.5f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x84;
                    goto Label_4ACF;

                case 0x84:
                    BuddyListBehavior.Instance.ChangeBuddyStatus(ChatValues.JulieUsername, BuddyStatus.Away, ChatValues.Script4JuleAway, true);
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(1, 1f) }));
                    this.$PC = 0x85;
                    goto Label_4ACF;

                case 0x85:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("it's just made me feel differently.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x86;
                    goto Label_4ACF;

                case 0x87:
                    if (this.<>f__this.answer == 1)
                    {
                        this.<text>__0 = "differently in a vad<<<bad way?~";
                    }
                    else if (this.<>f__this.answer == 2)
                    {
                        this.<text>__0 = "different rhan<<<<than what?~";
                    }
                    else if (this.<>f__this.answer == 3)
                    {
                        this.<text>__0 = "I'm sorry it's bade<<<<made you feel weird.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x88;
                    goto Label_4ACF;

                case 0x88:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "just from how things were before.";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "it's okay. I just wish things had played out differently.";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "no, not bad. just different. I don't know.";
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 2f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x89;
                    goto Label_4ACF;

                case 0x89:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x8a;
                    goto Label_4ACF;

                case 0x8a:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("want to keep in touch?", "are we still friends?", "will we ever be the same?"));
                    this.$PC = 0x8b;
                    goto Label_4ACF;

                case 0x8b:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "are we still friends?~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "do you think we'll ever be the same?~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "do you still want to keep in touch?~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 140;
                    goto Label_4ACF;

                case 140:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "yeah, at least I think so.";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "I really don't know.";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "yeah, I think so.";
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 0.5f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f),
                        new WaitingAction(WaitingActionType.Typing, 1f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x8d;
                    goto Label_4ACF;

                case 0x8d:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x8e;
                    goto Label_4ACF;

                case 0x8e:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 2f),
                        new WaitingAction(WaitingActionType.Typing, 0.5f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f),
                        new WaitingAction(WaitingActionType.Typing, 1f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x8f;
                    goto Label_4ACF;

                case 0x8f:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("I'm sorry, things are just really weird for me right now.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x90;
                    goto Label_4ACF;

                case 0x90:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 2f),
                        new WaitingAction(WaitingActionType.Typing, 2f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x91;
                    goto Label_4ACF;

                case 0x91:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("but thank you for talking to me about it all.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x92;
                    goto Label_4ACF;

                case 0x92:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("yeah, sure", "no problem", "we can talk any time"));
                    this.$PC = 0x93;
                    goto Label_4ACF;

                case 0x93:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "no problem at all.~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "we can talk any time.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "yeah, sure.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x94;
                    goto Label_4ACF;

                case 0x94:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 2f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x95;
                    goto Label_4ACF;

                case 0x95:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("so how is school and everything going?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 150;
                    goto Label_4ACF;

                case 150:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("it's good", "it's alright", "it's annoying"));
                    this.$PC = 0x97;
                    goto Label_4ACF;

                case 0x97:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "it's alright, just same old ss<ame old.~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "it's annoying, i'm kind of rez<ady for it to be over.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "it's good, collef<ge is flying by.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x98;
                    goto Label_4ACF;

                case 0x98:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f),
                        new WaitingAction(WaitingActionType.Typing, 0.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x99;
                    goto Label_4ACF;

                case 0x99:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("so, how's your friend uh, mike?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x9a;
                    goto Label_4ACF;

                case 0x9a:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("he's okay", "he's not really my friend", "he's been a tool lately"));
                    this.$PC = 0x9b;
                    goto Label_4ACF;

                case 0x9b:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "he's not really my friend sany<<<<anymore.~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "he's been kind of a rool<<<<tool lately.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "he's okay, he's been more serious about scoo<<<<school and stuff lately though.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x9c;
                    goto Label_4ACF;

                case 0x9c:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x9d;
                    goto Label_4ACF;

                case 0x9d:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("yeah, it sucks when people change.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x9e;
                    goto Label_4ACF;

                case 0x9e:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 2f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x9f;
                    goto Label_4ACF;

                case 0x9f:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("what about your other friend, emma?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 160;
                    goto Label_4ACF;

                case 160:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("we hang out sometimes", "haven't seen her in a while", "we talk all the time"));
                    this.$PC = 0xa1;
                    goto Label_4ACF;

                case 0xa1:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "i haven't seen her in a s<while.~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "we talk w<all the time.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "we still g<hang out sometimes.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0xa2;
                    goto Label_4ACF;

                case 0xa2:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0xa3;
                    goto Label_4ACF;

                case 0xa3:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("is she just a friend or?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xa4;
                    goto Label_4ACF;

                case 0xa4:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("i'd like more", "maybe", "she's just a friend"));
                    this.$PC = 0xa5;
                    goto Label_4ACF;

                case 0xa5:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "maybe <<<<<<i don't know.~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "she's just a friend.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "i'd like more<<<<<<<<<<<<<i don't know.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0xa6;
                    goto Label_4ACF;

                case 0xa6:
                    ChatValues.Chapter4PlayerLikesEmma = this.<>f__this.answer != 3;
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1.5f), new WaitingAction(1, 1f) }));
                    this.$PC = 0xa7;
                    goto Label_4ACF;

                case 0xa7:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("oh, okay.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xa8;
                    goto Label_4ACF;

                case 0xa8:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 0.5f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f),
                        new WaitingAction(WaitingActionType.Deleting, 0.5f),
                        new WaitingAction(WaitingActionType.Typing, 0.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0xa9;
                    goto Label_4ACF;

                case 0xa9:
                    BuddyListBehavior.Instance.ChangeBuddyStatus(ChatValues.TravisUsername, BuddyStatus.Away, ChatValues.Script4TravisAway, true);
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(1, 1f) }));
                    this.$PC = 170;
                    goto Label_4ACF;

                case 170:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("I'm sorry, I don't think I can do this right now.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xab;
                    goto Label_4ACF;

                case 0xab:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("do what?", "is something wrong?", "what do you mean?"));
                    this.$PC = 0xac;
                    goto Label_4ACF;

                case 0xac:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "is something wrong?~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "what do you mean?~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "do what?~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0xad;
                    goto Label_4ACF;

                case 0xad:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "no, talking is just kind of hard.";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "talking right now is just kind of hard.";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "just talk like normally.";
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0xae;
                    goto Label_4ACF;

                case 0xae:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xaf;
                    goto Label_4ACF;

                case 0xaf:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 2f),
                        new WaitingAction(WaitingActionType.Typing, 2f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0xb0;
                    goto Label_4ACF;

                case 0xb0:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("I've got to go soon anyways.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xb1;
                    goto Label_4ACF;

                case 0xb1:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0xb2;
                    goto Label_4ACF;

                case 0xb2:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("but we'll talk again later?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xb3;
                    goto Label_4ACF;

                case 0xb3:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("of course", "sure", "okay"));
                    this.$PC = 180;
                    goto Label_4ACF;

                case 180:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "uh sure, see ya.~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "okay, bye.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "yeah of course, see ya.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0xb5;
                    goto Label_4ACF;

                case 0xb5:
                    goto Label_4A2F;

                case 0xb6:
                    this.<>f__this.currentStatus = BuddyStatus.Away;
                    BuddyListBehavior.Instance.ChangeBuddyStatus(ChatValues.OtherUsername, BuddyStatus.Away, null, false);
                    ChatValues.SetCurrentLevel(4);
                    this.<>f__this.SetCompletionAchievement(4);
                    this.$current = new WaitForSeconds(2.5f);
                    this.$PC = 0xb7;
                    goto Label_4ACF;

                case 0xb7:
                    LoadingScreenBehavior.Instance.LoadMenuScene(false);
                    this.$PC = -1;
                    goto Label_4ACD;

                default:
                    goto Label_4ACD;
            }
            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, true));
            this.$PC = 7;
            goto Label_4ACF;
        Label_1012:
            ChatValues.Chapter4PlayerTalkedToEmily = this.<playerWillTalk>__1;
            this.<secondaryText>__2 = string.Empty;
            this.<choseText>__3 = string.Empty;
            if (!this.<playerWillTalk>__1)
            {
                goto Label_4A2F;
            }
            this.<>f__this.dmb.ShowStatusLabel("you chose to talk with emily");
            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1.5f), new WaitingAction(1, 1f), new WaitingAction(0, 0.5f), new WaitingAction(1, 1f) }));
            this.$PC = 0x25;
            goto Label_4ACF;
        Label_1CE7:
            list = new List<WaitingAction>();
            list.Add(new WaitingAction(WaitingActionType.Idle, 1.5f));
            list.Add(new WaitingAction(WaitingActionType.Typing, 1.5f));
            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
            this.$PC = 0x43;
            goto Label_4ACF;
        Label_22EE:
            list = new List<WaitingAction>();
            list.Add(new WaitingAction(WaitingActionType.Idle, 1.5f));
            list.Add(new WaitingAction(WaitingActionType.Typing, 2f));
            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
            this.$PC = 0x53;
            goto Label_4ACF;
        Label_3340:
            list = new List<WaitingAction>();
            list.Add(new WaitingAction(WaitingActionType.Idle, 1.5f));
            list.Add(new WaitingAction(WaitingActionType.Typing, 0.5f));
            list.Add(new WaitingAction(WaitingActionType.Idle, 0.5f));
            list.Add(new WaitingAction(WaitingActionType.Typing, 1.5f));
            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
            this.$PC = 0x7a;
            goto Label_4ACF;
        Label_34A5:
            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("are you still mad at me?", "you could visit now", "i wish i could change things"));
            this.$PC = 0x7e;
            goto Label_4ACF;
        Label_4A2F:
            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(ChatValues.AwayText, ChatMessageType.OtherAway, 1.5f));
            this.$PC = 0xb6;
            goto Label_4ACF;
        Label_4ACD:
            return false;
        Label_4ACF:
            return true;
        }

        [DebuggerHidden]
        public void Reset()
        {
            throw new NotSupportedException();
        }

        object IEnumerator<object>.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }

        object IEnumerator.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }
    }
}

