﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnityEngine;

public class Chapter2ScriptBehavior : BaseScriptBehavior
{
    private BuddyStatus currentStatus;

    public override void DidPressInfoButton()
    {
        string str = !ChatValues.Chapter1WentToParty ? "t" : "b";
        BuddyInfoBehavior.Instance.SetUp(ChatValues.OtherUsername, string.Format(ChatValues.Script2BuddyInfo, str), ChatValues.ColorFromRGB(0x40, 0x33, 0x42), this.currentStatus, null);
        BuddyInfoBehavior.Instance.Show();
    }

    public override void DidPressTextButton(int index)
    {
        base.answer = index;
    }

    public override void PlayScript()
    {
        TaskBarBehavior.Instance.SetState(TaskBarState.BuddyList);
        BuddyListBehavior.Instance.Show();
        DisplayManagerBehavior.Instance.SetBuddyIcons(ChatValues.GetPlayerBuddyIcon(), BuddyIconType.EmilySnowPatrol);
        base.StartCoroutine(this.ScriptRunner());
    }

    [DebuggerHidden]
    private IEnumerator ScriptRunner()
    {
        return new <ScriptRunner>c__Iterator9 { <>f__this = this };
    }

    public override void SetUpBuddyList()
    {
        BuddyListBehavior instance = BuddyListBehavior.Instance;
        bool flag = ChatValues.Chapter1WentToParty;
        instance.AddBuddyRow(ChatValues.OtherUsername, string.Format(ChatValues.Script2BuddyInfo, !flag ? "t" : "b"), ChatValues.ColorFromRGB(0x40, 0x33, 0x42), BuddyStatus.Offline, null);
        instance.AddBuddyRow(ChatValues.TravisUsername, string.Format(ChatValues.Script2TravisInfo, !flag ? ChatValues.Script2TravisInfoWithEmily : ChatValues.Script2TravisInfoNoEmily), ChatValues.ColorFromRGB(0xab, 0xcb, 0xff), BuddyStatus.Away, ChatValues.Script2TravisAway);
        instance.AddBuddyRow(ChatValues.BradUsername, string.Format(ChatValues.Script2BradInfo, !flag ? ChatValues.Script2BradInfoNoEmily : ChatValues.Script2BradInfoWithEmily), ChatValues.ColorFromRGB(0xf6, 150, 150), BuddyStatus.Away, ChatValues.Script2BradAway);
        instance.AddBuddyRow(ChatValues.JulieUsername, ChatValues.Script2JulieInfo, ChatValues.ColorFromRGB(0x55, 0x90, 0x2c), BuddyStatus.Away, ChatValues.Script2JulieAway);
        instance.AddBuddyRow(ChatValues.EmmaUsername, ChatValues.Script2EmmaInfo, ChatValues.ColorFromRGB(0, 0x30, 50), BuddyStatus.Online, null);
        instance.AddBuddyRow(ChatValues.MikeUsername, ChatValues.Script2MikeInfo, Color.black, BuddyStatus.Online, null);
        instance.AddOfflineOnlyBuddyRow("Elgy4DedWrld");
        instance.AddOfflineOnlyBuddyRow("ethancrtr8");
        instance.AddOfflineOnlyBuddyRow("Ether1");
        instance.AddOfflineOnlyBuddyRow("xSxOxMxAx");
        instance.AddOfflineOnlyBuddyRow("C1B3LE");
    }

    [CompilerGenerated]
    private sealed class <ScriptRunner>c__Iterator9 : IEnumerator, IDisposable, IEnumerator<object>
    {
        internal object $current;
        internal int $PC;
        internal Chapter2ScriptBehavior <>f__this;
        internal int <activityChoice>__6;
        internal string <activityString>__11;
        internal string <boyfriendsName>__7;
        internal string <clubName>__8;
        internal bool <dislikesColdplay>__3;
        internal string <emmaAway>__5;
        internal string <mikeAway>__4;
        internal BuddyIconType <playerIcon>__1;
        internal string <secondText>__9;
        internal bool <stoppedTalkingAboutIt>__10;
        internal string <text>__0;
        internal int <typeOfSchool>__2;

        [DebuggerHidden]
        public void Dispose()
        {
            this.$PC = -1;
        }

        public bool MoveNext()
        {
            List<WaitingAction> list;
            uint num = (uint) this.$PC;
            this.$PC = -1;
            switch (num)
            {
                case 0:
                    this.<text>__0 = string.Empty;
                    this.$current = new WaitForSeconds(2f);
                    this.$PC = 1;
                    goto Label_30D5;

                case 1:
                    TaskBarBehavior.Instance.SetState(TaskBarState.BuddyListChat);
                    BuddyListBehavior.Instance.Hide();
                    DisplayManagerBehavior.Instance.Show();
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(ChatValues.SignInText, ChatMessageType.OtherSignIn, 0f));
                    this.$PC = 2;
                    goto Label_30D5;

                case 2:
                    this.<>f__this.currentStatus = BuddyStatus.Online;
                    BuddyListBehavior.Instance.ChangeBuddyStatus(ChatValues.OtherUsername, BuddyStatus.Online, null, false);
                    this.$current = new WaitForSeconds(1f);
                    this.$PC = 3;
                    goto Label_30D5;

                case 3:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Typing, 1f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 4;
                    goto Label_30D5;

                case 4:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(ChatValues.GetPlayerName().ToLower() + "! hey!", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 5;
                    goto Label_30D5;

                case 5:
                    this.<playerIcon>__1 = ChatValues.GetPlayerBuddyIcon();
                    if (((this.<playerIcon>__1 != BuddyIconType.Koala) && (this.<playerIcon>__1 != BuddyIconType.Monkey)) && ((this.<playerIcon>__1 != BuddyIconType.LinkinPark) && (this.<playerIcon>__1 != BuddyIconType.Nemo)))
                    {
                        goto Label_0440;
                    }
                    if (this.<playerIcon>__1 != BuddyIconType.LinkinPark)
                    {
                        if (this.<playerIcon>__1 == BuddyIconType.Nemo)
                        {
                            this.<text>__0 = "i like your new icon! finding nemo is the beest.";
                        }
                        else
                        {
                            this.<text>__0 = "i like your new icon. it's so cute!";
                        }
                        break;
                    }
                    this.<text>__0 = "i like your new icon! linkin park's awesome.";
                    break;

                case 6:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 7;
                    goto Label_30D5;

                case 7:
                    goto Label_0440;

                case 8:
                    if (this.<>f__this.answer == 1)
                    {
                        this.<text>__0 = "hey! whats up?~";
                    }
                    else if (this.<>f__this.answer == 2)
                    {
                        this.<text>__0 = "hey! whatcha doin?~";
                    }
                    else if (this.<>f__this.answer == 3)
                    {
                        this.<text>__0 = "hey! hows it shaking?~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, true));
                    this.$PC = 9;
                    goto Label_30D5;

                case 9:
                    if (this.<>f__this.answer != 3)
                    {
                        goto Label_05CD;
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 0.5f), new WaitingAction(1, 0.5f), new WaitingAction(0, 1f), new WaitingAction(1, 1f) }));
                    this.$PC = 10;
                    goto Label_30D5;

                case 10:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("haha, it's shaking i guess?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 11;
                    goto Label_30D5;

                case 11:
                    goto Label_05CD;

                case 12:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("i'm just doing some homework and listening to music, you?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 13;
                    goto Label_30D5;

                case 13:
                    this.<typeOfSchool>__2 = ChatValues.Chapter1TypeOfSchool;
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("homework too", "just chilling", "video games"));
                    this.$PC = 14;
                    goto Label_30D5;

                case 14:
                    if (this.<>f__this.answer == 1)
                    {
                        this.<text>__0 = "just some hon<mework too, what music are you listening to?~";
                    }
                    else if (this.<>f__this.answer == 2)
                    {
                        this.<text>__0 = "im just chilling, what mi<usic are you listening to?~";
                    }
                    else if (this.<>f__this.answer == 3)
                    {
                        this.<text>__0 = "just plat<ying this video game, what music are you listening to?~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 15;
                    goto Label_30D5;

                case 15:
                    this.<dislikesColdplay>__3 = ChatValues.Chapter1DislikesColdplay;
                    if (!this.<dislikesColdplay>__3)
                    {
                        this.<text>__0 = "snow patrol! they just came out with their new album final straw, have you heard of it?";
                        this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 2f), new WaitingAction(0, 0.5f) }));
                        this.$PC = 0x11;
                    }
                    else
                    {
                        this.<text>__0 = "just this band. you probably wouldn't like them anyway. they're the same kind of music as coldplay.";
                        this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 1.5f), new WaitingAction(0, 0.5f), new WaitingAction(2, 1f), new WaitingAction(1, 1.5f) }));
                        this.$PC = 0x10;
                    }
                    goto Label_30D5;

                case 0x10:
                case 0x11:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x12;
                    goto Label_30D5;

                case 0x12:
                    if (this.<dislikesColdplay>__3)
                    {
                        goto Label_0C78;
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("yes! its great", "no, i dont think so", "i dont know"));
                    this.$PC = 0x13;
                    goto Label_30D5;

                case 0x13:
                    if (this.<>f__this.answer == 1)
                    {
                        this.<text>__0 = "yes! thats a great album.~";
                    }
                    else if (this.<>f__this.answer == 3)
                    {
                        this.<text>__0 = "i might have heard some songs off it?~";
                    }
                    else if (this.<>f__this.answer == 2)
                    {
                        this.<text>__0 = "no, i dont think i know it.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 20;
                    goto Label_30D5;

                case 20:
                    if (this.<>f__this.answer != 1)
                    {
                        this.<text>__0 = "you should listen to it. it's really good!";
                    }
                    else
                    {
                        this.<text>__0 = "you always know the best music! what's your favorite song off it?";
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x15;
                    goto Label_30D5;

                case 0x15:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x16;
                    goto Label_30D5;

                case 0x16:
                    if (this.<>f__this.answer != 1)
                    {
                        goto Label_0C78;
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("the anthem", "run", "clocks"));
                    this.$PC = 0x17;
                    goto Label_30D5;

                case 0x17:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "runs my favorite song on the album.~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "i think i like clocks the most.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "i really like the anthem.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x18;
                    goto Label_30D5;

                case 0x18:
                    this.<>f__this.dmb.ShowRememberLabel();
                    if (this.<>f__this.answer != 2)
                    {
                        this.<text>__0 = "what? that's not a song on that album. maybe were not thinking about the same thing.";
                        this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1.5f), new WaitingAction(1, 1f), new WaitingAction(0, 0.5f), new WaitingAction(2, 1f), new WaitingAction(1, 2.5f) }));
                        this.$PC = 0x1a;
                    }
                    else
                    {
                        this.<text>__0 = "i really like run too! my favorite is definitely spitting games though.";
                        this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1.5f), new WaitingAction(1, 2f) }));
                        this.$PC = 0x19;
                    }
                    goto Label_30D5;

                case 0x19:
                case 0x1a:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x1b;
                    goto Label_30D5;

                case 0x1b:
                    goto Label_0C78;

                case 0x1c:
                    BuddyListBehavior.Instance.ChangeBuddyStatus(ChatValues.JulieUsername, BuddyStatus.Online, null, true);
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(1, 0.5f), new WaitingAction(0, 1f), new WaitingAction(1, 1f) }));
                    this.$PC = 0x1d;
                    goto Label_30D5;

                case 0x1d:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("so how are you liking " + this.<text>__0 + "?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 30;
                    goto Label_30D5;

                case 30:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("its hard", "its fun", "its boring"));
                    this.$PC = 0x1f;
                    goto Label_30D5;

                case 0x1f:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "its fun! i lucked out and got somr<e really awesome people on my floor.~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "ugh, its so boring. i feel like i hab<vent learned anything so far.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "its hard. i always have alot of wp<ork, but at least im learning alot.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x20;
                    goto Label_30D5;

                case 0x20:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "thats great! my floor is fucking booring. i'll have to visit you sometime.";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "haha you're too smart for your own good! i'm struggling with some classes right now.";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "well that's good at least! my classes have all just been boring freshmen stuff.";
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 3f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x21;
                    goto Label_30D5;

                case 0x21:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x22;
                    goto Label_30D5;

                case 0x22:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 2f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x23;
                    goto Label_30D5;

                case 0x23:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("got any plans tonight?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x24;
                    goto Label_30D5;

                case 0x24:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("house party!", "hanging out with friends", "group project"));
                    this.$PC = 0x25;
                    goto Label_30D5;

                case 0x25:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "yeah, i have to go in a few. im ham<nging out with some people at my friend mikes dorm.~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "yeah, i have to go to the library in a few, n<massive group project due tomorrow.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "yeah, i have to go in a few. my fro<iend mikes throwing a massive house party!~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x26;
                    goto Label_30D5;

                case 0x26:
                    this.<mikeAway>__4 = string.Empty;
                    this.<emmaAway>__5 = string.Empty;
                    this.<activityChoice>__6 = this.<>f__this.answer;
                    ChatValues.Chapter2TypeOfActivity = this.<>f__this.answer;
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<>f__this.dmb.ShowStatusLabel("you chose to hang out with friends");
                            this.<text>__0 = "oh cool, what are you all going to do?";
                            this.<mikeAway>__4 = "havin some friends over";
                            this.<emmaAway>__5 = "hangin with some peeps";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<>f__this.dmb.ShowStatusLabel("you chose to work on a group project");
                            this.<text>__0 = "oh no! why did you wait until the last minute?";
                            this.<mikeAway>__4 = "group project time";
                            this.<emmaAway>__5 = "being a good student";
                        }
                    }
                    else
                    {
                        this.<>f__this.dmb.ShowStatusLabel("you chose to attend a house party");
                        this.<text>__0 = "oh wow, that sounds like fun! don't get too drunk!";
                        this.<mikeAway>__4 = "party at my house";
                        this.<emmaAway>__5 = "going out tonight";
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x27;
                    goto Label_30D5;

                case 0x27:
                    BuddyListBehavior.Instance.ChangeBuddyStatus(ChatValues.MikeUsername, BuddyStatus.Away, this.<mikeAway>__4, true);
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(1, 0.5f), new WaitingAction(0, 0.5f) }));
                    this.$PC = 40;
                    goto Label_30D5;

                case 40:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x29;
                    goto Label_30D5;

                case 0x29:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer != 2)
                        {
                            if (this.<>f__this.answer != 3)
                            {
                                goto Label_152C;
                            }
                            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("we put it off", "my group is shit", "it was just assigned"));
                            this.$PC = 0x2c;
                        }
                        else
                        {
                            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("having a few drinks", "going to see a movie", "going to a concert"));
                            this.$PC = 0x2b;
                        }
                    }
                    else
                    {
                        this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("im going to get wasted", "ill try my best!", "ill be careful"));
                        this.$PC = 0x2a;
                    }
                    goto Label_30D5;

                case 0x2a:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "lol ill try my best! derpends <<<<<<<pends on how crazy the party gets. do you have plans tonight?~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "dont wprry <<<<<orry, ill be careful. do you have plans tonight?~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "lol im gping <<<<<oing to get so. wasted. do you have plans tonight?~";
                    }
                    goto Label_152C;

                case 0x2b:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "were just going to see a mivie <<<<<ovie. final destination 2 came out a few weeks ago. do you have plans tonight?~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "were just going to a concert, some lkocal <<<<<<ocal band is playing at the bar down the street. do you have plans tonight?~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "just having a few drinks, listening to misic <<<<<usic and hanging out. do you have plans tonight?~";
                    }
                    goto Label_152C;

                case 0x2c:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "i just have the shittiest gfroup <<<<<<roup. do you have plans tonight?~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "its for my honors class, it was just asigned <<<<<<<ssigned like <<<<<yesterday. do you have plans tonight?~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "we just put it off until now. its the most bnoring <<<<<<<oring work. do you have plans tonight?~";
                    }
                    goto Label_152C;

                case 0x2d:
                    this.<boyfriendsName>__7 = !ChatValues.Chapter1WentToParty ? "travis" : "brad";
                    this.<clubName>__8 = !ChatValues.Chapter1WentToParty ? "surf club" : "band practice";
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1.5f), new WaitingAction(1, 2.5f) }));
                    this.$PC = 0x2e;
                    goto Label_30D5;

                case 0x2e:
                {
                    string[] textArray1 = new string[] { "nope, ", this.<boyfriendsName>__7, " has ", this.<clubName>__8, " so i'm just hanging out in my dorm." };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(string.Concat(textArray1), ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x2f;
                    goto Label_30D5;
                }
                case 0x2f:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("do i know " + this.<boyfriendsName>__7 + "?", this.<boyfriendsName>__7 + " who?", "sounds like a tool"));
                    this.$PC = 0x30;
                    goto Label_30D5;

                case 0x30:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = this.<boyfriendsName>__7 + " who?~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "wow, " + this.<clubName>__8 + "? sounds like a tool.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "do i know " + this.<boyfriendsName>__7 + "?~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x31;
                    goto Label_30D5;

                case 0x31:
                    if ((this.<>f__this.answer != 1) && (this.<>f__this.answer != 2))
                    {
                        this.<text>__0 = "haha, yeah he's a little weird but he's a great boyfriend. you remember him from high school right?";
                    }
                    else
                    {
                        this.<text>__0 = this.<boyfriendsName>__7 + "? he's my boyfriend. you remember him from high school right?";
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 2.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 50;
                    goto Label_30D5;

                case 50:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x33;
                    goto Label_30D5;

                case 0x33:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 2f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x34;
                    goto Label_30D5;

                case 0x34:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("we've been dating for a couple months now.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x35;
                    goto Label_30D5;

                case 0x35:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("oh, good", "im happy for you", "yeah, whatever"));
                    this.$PC = 0x36;
                    goto Label_30D5;

                case 0x36:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "im happy for you. how did you two get together anyways <<<<<<<<<?~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "yeah whatever. how did you two get together anyways <<<<<<<<<?~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "oh, good. how did you two get together anyways <<<<<<<<<?~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x37;
                    goto Label_30D5;

                case 0x37:
                    if (!ChatValues.Chapter1WentToParty)
                    {
                        list = new List<WaitingAction> {
                            new WaitingAction(WaitingActionType.Idle, 1f),
                            new WaitingAction(WaitingActionType.Typing, 3f)
                        };
                        this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                        this.$PC = 0x42;
                    }
                    else
                    {
                        this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 3f) }));
                        this.$PC = 0x38;
                    }
                    goto Label_30D5;

                case 0x38:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("well, remember that grad party we went to last year?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x39;
                    goto Label_30D5;

                case 0x39:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 2f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x3a;
                    goto Label_30D5;

                case 0x3a:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("while i was away brad sent me a ton of messages about how he felt.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x3b;
                    goto Label_30D5;

                case 0x3b:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 2.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 60;
                    goto Label_30D5;

                case 60:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("at first i thought it was really weird, but after a while i realized it was kind of brave.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x3d;
                    goto Label_30D5;

                case 0x3d:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 2.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x3e;
                    goto Label_30D5;

                case 0x3e:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("we started talking again over the summer and realized we were going to the same school.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x3f;
                    goto Label_30D5;

                case 0x3f:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 2.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x40;
                    goto Label_30D5;

                case 0x40:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("once we got here we just kind of hit it off.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x41;
                    goto Label_30D5;

                case 0x41:
                case 0x4b:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("whats he like?", "do you love him?", "is he your best friend?"));
                    this.$PC = 0x4c;
                    goto Label_30D5;

                case 0x42:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("well, remember that grad party travis threw last year?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x43;
                    goto Label_30D5;

                case 0x43:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 2.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x44;
                    goto Label_30D5;

                case 0x44:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("julie ended up running off with some junior so i was all alone.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x45;
                    goto Label_30D5;

                case 0x45:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 2.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 70;
                    goto Label_30D5;

                case 70:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("travis saw me and came over and honestly, i saw a side of him i'd never seen before.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x47;
                    goto Label_30D5;

                case 0x47:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 2.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x48;
                    goto Label_30D5;

                case 0x48:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("after the party we kept talking, then we realized we were going to the same school.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x49;
                    goto Label_30D5;

                case 0x49:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 2.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x4a;
                    goto Label_30D5;

                case 0x4a:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("once we got here we just kind of hit it off.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x4b;
                    goto Label_30D5;

                case 0x4c:
                    ChatValues.Chapter2TypeOfQuestion = this.<>f__this.answer;
                    if (this.<>f__this.answer == 1)
                    {
                        this.<text>__0 = "so, whats he like?~";
                    }
                    else if (this.<>f__this.answer == 2)
                    {
                        this.<text>__0 = "so, do you love him?~";
                    }
                    else if (this.<>f__this.answer == 3)
                    {
                        this.<text>__0 = "so, is he your best friend?~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x4d;
                    goto Label_30D5;

                case 0x4d:
                    this.<secondText>__9 = string.Empty;
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "oh, i don't know. love's a strong word.";
                            this.<secondText>__9 = "and sometimes he can be a jerk but when it's good it's really good.";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "yeah definitely. he knows me better than anyone.";
                            this.<secondText>__9 = "i mean sometimes he can be a jerk but when it's good it's really good.";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "well he's smart, and funny, and he understands me.";
                        this.<secondText>__9 = "sometimes he can be a jerk but when it's good it's really good.";
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 2f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x4e;
                    goto Label_30D5;

                case 0x4e:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x4f;
                    goto Label_30D5;

                case 0x4f:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 0.5f),
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 2f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 80;
                    goto Label_30D5;

                case 80:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<secondText>__9, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x51;
                    goto Label_30D5;

                case 0x51:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("a jerk?", "do you argue alot?", "is he ever mean to you?"));
                    this.$PC = 0x52;
                    goto Label_30D5;

                case 0x52:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "do you and " + this.<boyfriendsName>__7 + " as<rgue alot?~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "is " + this.<boyfriendsName>__7 + " evr<er mean to you?~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "wait, how is he a jr<erk to you?~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x53;
                    goto Label_30D5;

                case 0x53:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "i mean not alot, but we do argue.";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "he can get pretty nasty when we argue but that's it.";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "i just mean we get into arguments sometimes.";
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 2.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x54;
                    goto Label_30D5;

                case 0x54:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x55;
                    goto Label_30D5;

                case 0x55:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f),
                        new WaitingAction(WaitingActionType.Typing, 1f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x56;
                    goto Label_30D5;

                case 0x56:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("we're both very stubborn people so we can go back and forth alot.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x57;
                    goto Label_30D5;

                case 0x57:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 2f),
                        new WaitingAction(WaitingActionType.Typing, 3f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x58;
                    goto Label_30D5;

                case 0x58:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("but like i said, when things are good they're really good.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x59;
                    goto Label_30D5;

                case 0x59:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("you deserve better", "sounds like a bad relationship", "i guess thats normal"));
                    this.$PC = 90;
                    goto Label_30D5;

                case 90:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "honestly emily, that like<<<<sounds like a bad relationship.~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "i mean, i guess thats like<<<<normal. as long as you're okay.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "emily, you like<<<<deserve better than that.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x5b;
                    goto Label_30D5;

                case 0x5b:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "i think it's just a normal relationship. all couples argue alot.";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "i am! we just get loud when we argue is all.";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "i think you're blowing it out of proportion. he's not abusive or anything.";
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x5c;
                    goto Label_30D5;

                case 0x5c:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x5d;
                    goto Label_30D5;

                case 0x5d:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("i wouldn't treat you like that", "i just really care about you", "he sounds like an asshole"));
                    this.$PC = 0x5e;
                    goto Label_30D5;

                case 0x5e:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "okay, just know i really care about you. <<<<<<<<<<<<<<<<<<<<<<<<<there are people who really care about you.~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "he just sounds like a fucking asshole. <<<<<<<<<<<<<<<<<jerk.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "well, all i know is i wouldnt treat you like that. <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<you shouldnt be treated like that.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x5f;
                    goto Label_30D5;

                case 0x5f:
                    this.<>f__this.dmb.ShowRememberLabel();
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1.5f), new WaitingAction(1, 1f), new WaitingAction(0, 0.5f), new WaitingAction(2, 0.5f), new WaitingAction(1, 1.5f) }));
                    this.$PC = 0x60;
                    goto Label_30D5;

                case 0x60:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("listen, i think we're fine. i don't want to talk about this anymore.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x61;
                    goto Label_30D5;

                case 0x61:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("i'm sorry", "i just don't like him", "you should break up with him"));
                    this.$PC = 0x62;
                    goto Label_30D5;

                case 0x62:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "okay, i just don't lil<ke him. i want you to be happy.~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "i think you should rr<eally just break up with him.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "i'm sorry. i jud<st want you to be happy.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x63;
                    goto Label_30D5;

                case 0x63:
                    this.<stoppedTalkingAboutIt>__10 = false;
                    if ((this.<>f__this.answer != 1) && (this.<>f__this.answer != 2))
                    {
                        if (this.<>f__this.answer == 3)
                        {
                            this.<stoppedTalkingAboutIt>__10 = false;
                            this.<>f__this.dmb.ShowStatusLabel("you chose to keep talking about it");
                            this.<text>__0 = ChatValues.GetPlayerName().ToLower() + ", i can take care of myself.";
                            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1.5f), new WaitingAction(1, 0.5f), new WaitingAction(0, 0.5f), new WaitingAction(1, 1.5f) }));
                            this.$PC = 0x65;
                            goto Label_30D5;
                        }
                        goto Label_2AEB;
                    }
                    this.<stoppedTalkingAboutIt>__10 = true;
                    this.<>f__this.dmb.ShowStatusLabel("you chose to stop talking about it");
                    this.<text>__0 = "but i am happy! i promise.";
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1.5f), new WaitingAction(1, 2f) }));
                    this.$PC = 100;
                    goto Label_30D5;

                case 100:
                case 0x65:
                    goto Label_2AEB;

                case 0x66:
                    this.<activityString>__11 = string.Empty;
                    if (this.<activityChoice>__6 == 1)
                    {
                        this.<activityString>__11 = "go to that party";
                    }
                    else if (this.<activityChoice>__6 == 2)
                    {
                        this.<activityString>__11 = "go see your friends";
                    }
                    else if (this.<activityChoice>__6 == 3)
                    {
                        this.<activityString>__11 = "go meet your group";
                    }
                    if ((this.<>f__this.answer == 1) || (this.<>f__this.answer == 2))
                    {
                        this.<text>__0 = "oh wow, it's getting late. you need to " + this.<activityString>__11 + " don't you?";
                    }
                    else if (this.<>f__this.answer == 3)
                    {
                        this.<text>__0 = "you have to " + this.<activityString>__11 + " anyways, right?";
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 0.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x67;
                    goto Label_30D5;

                case 0x67:
                    BuddyListBehavior.Instance.ChangeBuddyStatus(ChatValues.EmmaUsername, BuddyStatus.Away, this.<emmaAway>__5, true);
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(1, 2f) }));
                    this.$PC = 0x68;
                    goto Label_30D5;

                case 0x68:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x69;
                    goto Label_30D5;

                case 0x69:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("i should go", "i dont know", "i can stay"));
                    this.$PC = 0x6a;
                    goto Label_30D5;

                case 0x6a:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "eh, i dont know.~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "i mean, i can stay.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "yeah, i should go.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x6b;
                    goto Label_30D5;

                case 0x6b:
                    if (this.<>f__this.answer != 1)
                    {
                        if ((this.<>f__this.answer == 2) || ((this.<>f__this.answer == 3) && !this.<stoppedTalkingAboutIt>__10))
                        {
                            this.<text>__0 = "you should go. i don't want you to miss it. i'll talk to you later.";
                            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 0.5f), new WaitingAction(0, 0.5f), new WaitingAction(1, 2f) }));
                            this.$PC = 0x6d;
                        }
                        else
                        {
                            this.<text>__0 = "haha, that's very nice of you but i don't want you to miss anything. i'll ttyl!";
                            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 2f) }));
                            this.$PC = 110;
                        }
                    }
                    else
                    {
                        this.<text>__0 = "okay, ill talk to you later.";
                        this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 2f) }));
                        this.$PC = 0x6c;
                    }
                    goto Label_30D5;

                case 0x6c:
                case 0x6d:
                case 110:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x6f;
                    goto Label_30D5;

                case 0x6f:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("see ya", "later", "bye"));
                    this.$PC = 0x70;
                    goto Label_30D5;

                case 0x70:
                    if (this.<>f__this.answer == 1)
                    {
                        this.<text>__0 = "see ya~";
                    }
                    else if (this.<>f__this.answer == 2)
                    {
                        this.<text>__0 = "later~";
                    }
                    else if (this.<>f__this.answer == 3)
                    {
                        this.<text>__0 = "bye~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x71;
                    goto Label_30D5;

                case 0x71:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(ChatValues.AwayText, ChatMessageType.OtherAway, 2f));
                    this.$PC = 0x72;
                    goto Label_30D5;

                case 0x72:
                    this.<>f__this.currentStatus = BuddyStatus.Away;
                    BuddyListBehavior.Instance.ChangeBuddyStatus(ChatValues.OtherUsername, BuddyStatus.Away, null, false);
                    ChatValues.SetCurrentLevel(2);
                    this.<>f__this.SetCompletionAchievement(2);
                    this.$current = new WaitForSeconds(2.5f);
                    this.$PC = 0x73;
                    goto Label_30D5;

                case 0x73:
                    LoadingScreenBehavior.Instance.LoadMenuScene(false);
                    this.$PC = -1;
                    goto Label_30D3;

                default:
                    goto Label_30D3;
            }
            list = new List<WaitingAction> {
                new WaitingAction(WaitingActionType.Idle, 1f),
                new WaitingAction(WaitingActionType.Typing, 1.5f)
            };
            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
            this.$PC = 6;
            goto Label_30D5;
        Label_0440:
            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("whats up?", "whatcha doin?", "hows it shaking?"));
            this.$PC = 8;
            goto Label_30D5;
        Label_05CD:
            list = new List<WaitingAction>();
            list.Add(new WaitingAction(WaitingActionType.Idle, 1f));
            list.Add(new WaitingAction(WaitingActionType.Typing, 1.5f));
            list.Add(new WaitingAction(WaitingActionType.Idle, 0.5f));
            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
            this.$PC = 12;
            goto Label_30D5;
        Label_0C78:
            if (this.<typeOfSchool>__2 == 1)
            {
                this.<text>__0 = "engineering school";
            }
            else if (this.<typeOfSchool>__2 == 2)
            {
                this.<text>__0 = "art school";
            }
            else if (this.<typeOfSchool>__2 == 3)
            {
                this.<text>__0 = "business school";
            }
            list = new List<WaitingAction> {
                new WaitingAction(WaitingActionType.Idle, 1f),
                new WaitingAction(WaitingActionType.Typing, 0.5f)
            };
            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
            this.$PC = 0x1c;
            goto Label_30D5;
        Label_152C:
            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
            this.$PC = 0x2d;
            goto Label_30D5;
        Label_2AEB:
            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
            this.$PC = 0x66;
            goto Label_30D5;
        Label_30D3:
            return false;
        Label_30D5:
            return true;
        }

        [DebuggerHidden]
        public void Reset()
        {
            throw new NotSupportedException();
        }

        object IEnumerator<object>.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }

        object IEnumerator.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }
    }
}

