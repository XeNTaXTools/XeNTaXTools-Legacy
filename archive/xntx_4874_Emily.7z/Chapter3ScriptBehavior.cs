﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnityEngine;

public class Chapter3ScriptBehavior : BaseScriptBehavior
{
    private BuddyStatus currentStatus;

    public override void DidPressInfoButton()
    {
        BuddyInfoBehavior.Instance.SetUp(ChatValues.OtherUsername, ChatValues.Script3BuddyInfo, ChatValues.ColorFromRGB(13, 0x1b, 50), this.currentStatus, null);
        BuddyInfoBehavior.Instance.Show();
    }

    public override void DidPressTextButton(int index)
    {
        base.answer = index;
    }

    public override void PlayScript()
    {
        TaskBarBehavior.Instance.SetState(TaskBarState.BuddyList);
        BuddyListBehavior.Instance.Show();
        DisplayManagerBehavior.Instance.SetBuddyIcons(ChatValues.GetPlayerBuddyIcon(), BuddyIconType.EmilyMuse);
        base.StartCoroutine(this.ScriptRunner());
    }

    [DebuggerHidden]
    private IEnumerator ScriptRunner()
    {
        return new <ScriptRunner>c__IteratorA { <>f__this = this };
    }

    public override void SetUpBuddyList()
    {
        BuddyListBehavior instance = BuddyListBehavior.Instance;
        instance.AddBuddyRow(ChatValues.OtherUsername, ChatValues.Script3BuddyInfo, ChatValues.ColorFromRGB(13, 0x1b, 50), BuddyStatus.Offline, null);
        instance.AddBuddyRow(ChatValues.EmmaUsername, ChatValues.Script3EmmaInfo, ChatValues.ColorFromRGB(0xb6, 0xff, 0xff), BuddyStatus.Away, ChatValues.Script3EmmaAway);
        instance.AddBuddyRow(ChatValues.MikeUsername, ChatValues.Script3MikeInfo, ChatValues.ColorFromRGB(0x2b, 0x2b, 0x2b), BuddyStatus.Online, null);
        instance.AddBuddyRow(ChatValues.JulieUsername, ChatValues.Script3JulieInfo, ChatValues.ColorFromRGB(0x11, 4, 0x2b), BuddyStatus.Away, ChatValues.Script3JulieAway);
        instance.AddBuddyRow(ChatValues.BradUsername, ChatValues.Script3BradInfo, ChatValues.ColorFromRGB(0x18, 0x18, 0x18), BuddyStatus.Away, ChatValues.Script3BradAway);
        instance.AddBuddyRow(ChatValues.TravisUsername, ChatValues.Script3TravisInfo, ChatValues.ColorFromRGB(0xff, 0xf9, 0xab), BuddyStatus.Away, ChatValues.Script3TravisAway);
        instance.AddOfflineOnlyBuddyRow("DiscoDodger");
        instance.AddOfflineOnlyBuddyRow("Grmrck1987");
        instance.AddOfflineOnlyBuddyRow("VaultDweller");
        instance.AddOfflineOnlyBuddyRow("SeaMinusSun");
        instance.AddOfflineOnlyBuddyRow("DahGunGeon");
    }

    [CompilerGenerated]
    private sealed class <ScriptRunner>c__IteratorA : IEnumerator, IDisposable, IEnumerator<object>
    {
        internal object $current;
        internal int $PC;
        internal Chapter3ScriptBehavior <>f__this;
        internal string <boyfriendsName>__7;
        internal string <concatination>__9;
        internal int <emilysQuestion>__6;
        internal int <firstChoice>__11;
        internal string <choseText>__8;
        internal string <lastYearActivity>__4;
        internal bool <playerLikesEmma>__1;
        internal string <playerMajor>__2;
        internal string <pronoun>__10;
        internal string <text>__0;
        internal int <typeOfActivity>__5;
        internal int <typeOfSchool>__3;

        [DebuggerHidden]
        public void Dispose()
        {
            this.$PC = -1;
        }

        public bool MoveNext()
        {
            List<WaitingAction> list;
            uint num = (uint) this.$PC;
            this.$PC = -1;
            switch (num)
            {
                case 0:
                    this.<text>__0 = string.Empty;
                    this.$current = new WaitForSeconds(2f);
                    this.$PC = 1;
                    goto Label_50B0;

                case 1:
                    TaskBarBehavior.Instance.SetState(TaskBarState.BuddyListChat);
                    BuddyListBehavior.Instance.Hide();
                    DisplayManagerBehavior.Instance.Show();
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(ChatValues.SignInText, ChatMessageType.OtherSignIn, 0f));
                    this.$PC = 2;
                    goto Label_50B0;

                case 2:
                    this.<>f__this.currentStatus = BuddyStatus.Online;
                    BuddyListBehavior.Instance.ChangeBuddyStatus(ChatValues.OtherUsername, BuddyStatus.Online, null, false);
                    this.$current = new WaitForSeconds(1f);
                    this.$PC = 3;
                    goto Label_50B0;

                case 3:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Typing, 1f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 4;
                    goto Label_50B0;

                case 4:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("hey " + ChatValues.GetPlayerName().ToLower() + "!", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 5;
                    goto Label_50B0;

                case 5:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("hello", "emily! hey!", "yo, what up?"));
                    this.$PC = 6;
                    goto Label_50B0;

                case 6:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "emily! hey!~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "yo, what up?~";
                        }
                        break;
                    }
                    this.<text>__0 = "hello.~";
                    break;

                case 7:
                    if (this.<>f__this.answer != 3)
                    {
                        goto Label_060F;
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 1.5f) }));
                    this.$PC = 8;
                    goto Label_50B0;

                case 8:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("haha, not much.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 9;
                    goto Label_50B0;

                case 9:
                    goto Label_060F;

                case 10:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("how's life? i feel like we haven't talked in a while.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 11;
                    goto Label_50B0;

                case 11:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("it's good", "pretty boring", "eh, it's whatever"));
                    this.$PC = 12;
                    goto Label_50B0;

                case 12:
                    if (this.<>f__this.answer == 1)
                    {
                        this.<text>__0 = "it's good. gow<<<how's yours?~";
                    }
                    else if (this.<>f__this.answer == 2)
                    {
                        this.<text>__0 = "it's pretty boring. gow<<<how's yours?~";
                    }
                    else if (this.<>f__this.answer == 3)
                    {
                        this.<text>__0 = "eh, it's whatever. gow<<<how's yours?~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 13;
                    goto Label_50B0;

                case 13:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 2f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 14;
                    goto Label_50B0;

                case 14:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("eh, it's fine. got any plans this weekend?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 15;
                    goto Label_50B0;

                case 15:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("hanging out", "warehouse party", "going to a show"));
                    this.$PC = 0x10;
                    goto Label_50B0;

                case 0x10:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "going to some secret warehoud<se party with my friend emma.~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "going to a show witj<h my friend emma.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "just hanginf<g out with my friend emma.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x11;
                    goto Label_50B0;

                case 0x11:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 2f),
                        new WaitingAction(WaitingActionType.Typing, 0.5f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f),
                        new WaitingAction(WaitingActionType.Typing, 1f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x12;
                    goto Label_50B0;

                case 0x12:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("that sounds like fun!", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x13;
                    goto Label_50B0;

                case 0x13:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 2f),
                        new WaitingAction(WaitingActionType.Typing, 1f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 20;
                    goto Label_50B0;

                case 20:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("who's emma?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x15;
                    goto Label_50B0;

                case 0x15:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("a friend", "just a girl", "a girl i like"));
                    this.$PC = 0x16;
                    goto Label_50B0;

                case 0x16:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "she's just a girl.~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "she's a girl that i have a thing for.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "oh, she's one of my friends.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x17;
                    goto Label_50B0;

                case 0x17:
                    if (this.<>f__this.answer != 3)
                    {
                        this.<text>__0 = "oh cool.";
                    }
                    else
                    {
                        this.<text>__0 = "oh wow!";
                    }
                    this.<playerLikesEmma>__1 = this.<>f__this.answer == 3;
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1.5f), new WaitingAction(1, 0.5f), new WaitingAction(0, 0.5f), new WaitingAction(1, 1f) }));
                    this.$PC = 0x18;
                    goto Label_50B0;

                case 0x18:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0 + " i don't think i've heard you talk about her before.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x19;
                    goto Label_50B0;

                case 0x19:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x1a;
                    goto Label_50B0;

                case 0x1a:
                    BuddyListBehavior.Instance.ChangeBuddyStatus(ChatValues.BradUsername, BuddyStatus.Online, null, true);
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 0.5f), new WaitingAction(0, 1f), new WaitingAction(1, 1f), new WaitingAction(0, 0.5f) }));
                    this.$PC = 0x1b;
                    goto Label_50B0;

                case 0x1b:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("how did you two meet?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x1c;
                    goto Label_50B0;

                case 0x1c:
                    this.<playerMajor>__2 = string.Empty;
                    this.<typeOfSchool>__3 = ChatValues.Chapter1TypeOfSchool;
                    if (this.<typeOfSchool>__3 != 1)
                    {
                        if (this.<typeOfSchool>__3 == 2)
                        {
                            this.<playerMajor>__2 = "an art";
                        }
                        else if (this.<typeOfSchool>__3 == 3)
                        {
                            this.<playerMajor>__2 = "a business";
                        }
                    }
                    else
                    {
                        this.<playerMajor>__2 = "an engineering";
                    }
                    this.<lastYearActivity>__4 = string.Empty;
                    this.<typeOfActivity>__5 = ChatValues.Chapter2TypeOfActivity;
                    if (this.<typeOfActivity>__5 == 1)
                    {
                        this.<lastYearActivity>__4 = "at his dorm";
                    }
                    else if (this.<typeOfActivity>__5 == 2)
                    {
                        this.<lastYearActivity>__4 = "at one of his parties";
                    }
                    else if (this.<typeOfActivity>__5 == 3)
                    {
                        this.<lastYearActivity>__4 = "during some class project";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("just in class", "at a party", "mike introduced us"));
                    this.$PC = 0x1d;
                    goto Label_50B0;

                case 0x1d:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "at some plarty<<<<<arty i think? i don't really remember.~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "my friend mike introdiced<<<<uced us " + this.<lastYearActivity>__4 + " last year.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "just in one of my clazses<<<<sses. she's " + this.<playerMajor>__2 + " student just like me.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 30;
                    goto Label_50B0;

                case 30:
                    this.<emilysQuestion>__6 = ChatValues.Chapter2TypeOfQuestion;
                    if (this.<emilysQuestion>__6 != 1)
                    {
                        if (this.<emilysQuestion>__6 != 2)
                        {
                            if (this.<emilysQuestion>__6 != 3)
                            {
                                goto Label_1438;
                            }
                            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1.5f), new WaitingAction(1, 1f), new WaitingAction(0, 0.5f) }));
                            this.$PC = 0x29;
                        }
                        else
                        {
                            this.<text>__0 = !this.<playerLikesEmma>__1 ? "like" : "love";
                            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1.5f), new WaitingAction(1, 1f), new WaitingAction(0, 0.5f) }));
                            this.$PC = 0x23;
                        }
                    }
                    else
                    {
                        this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1.5f), new WaitingAction(1, 1f), new WaitingAction(0, 0.5f) }));
                        this.$PC = 0x1f;
                    }
                    goto Label_50B0;

                case 0x1f:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("so, what's she like?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x20;
                    goto Label_50B0;

                case 0x20:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("she's kind", "she's funny", "she's hot"));
                    this.$PC = 0x21;
                    goto Label_50B0;

                case 0x21:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "she's so funny, she alwat<ys makes me laugh.~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "honestly, she's res<ally hot.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "oh she's just a sweer<theart.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x22;
                    goto Label_50B0;

                case 0x22:
                case 0x26:
                case 40:
                case 0x2c:
                    goto Label_1438;

                case 0x23:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("so, do you " + this.<text>__0 + " her?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x24;
                    goto Label_50B0;

                case 0x24:
                    if (!this.<playerLikesEmma>__1)
                    {
                        this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("definitely", "i don't know", "no, not really"));
                        this.$PC = 0x27;
                    }
                    else
                    {
                        this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("absolutely", "i wouldn't say love", "definitely not"));
                        this.$PC = 0x25;
                    }
                    goto Label_50B0;

                case 0x25:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "well i woy<uldn't say love, but i definitely cs<are about her alot.~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "oh definir<tely not, it's still way too eark<ly to use a word like that.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "absolutely, i've been hes<ad over heels in love with her sib<nce we met.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x26;
                    goto Label_50B0;

                case 0x27:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "oh i don't know, mayv<be i guess?~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "no, not really. she's jusr<t a good friend.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "yeah definitely, i've had a crua<sh on her for a while.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 40;
                    goto Label_50B0;

                case 0x29:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("so, is she your best friend?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x2a;
                    goto Label_50B0;

                case 0x2a:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("of course", "i don't know", "not really"));
                    this.$PC = 0x2b;
                    goto Label_50B0;

                case 0x2b:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "i don't know, i'm not sure who i would call my br<est friend.~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "not really, we're close but i woy<uldn't call her that.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "of course, she knoe<ws more about me than anyone.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x2c;
                    goto Label_50B0;

                case 0x2d:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 0.5f),
                        new WaitingAction(WaitingActionType.Typing, 1f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x2e;
                    goto Label_50B0;

                case 0x2e:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("wow " + ChatValues.GetPlayerName().ToLower() + ", sounds like things are going really well.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x2f;
                    goto Label_50B0;

                case 0x2f:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x30;
                    goto Label_50B0;

                case 0x30:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("that's just so great.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x31;
                    goto Label_50B0;

                case 0x31:
                    this.<boyfriendsName>__7 = !ChatValues.Chapter1WentToParty ? "travis" : "brad";
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("so hows everything?", "what are you up to tonight?", "do you have any plans this weekend?"));
                    this.$PC = 50;
                    goto Label_50B0;

                case 50:
                    if (this.<>f__this.answer == 1)
                    {
                        this.<text>__0 = "so hows everything?~";
                    }
                    else if (this.<>f__this.answer == 2)
                    {
                        this.<text>__0 = "what are you up to tonight?~";
                    }
                    else if (this.<>f__this.answer == 3)
                    {
                        this.<text>__0 = "do you have any plans this weekend?~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x33;
                    goto Label_50B0;

                case 0x33:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "tonight? me and " + this.<boyfriendsName>__7 + " were supposed to go to a party but that's not happening.";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "well me and " + this.<boyfriendsName>__7 + " were supposed to go to see a show but that's not happening.";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "everything kind of sucks.";
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 2f),
                        new WaitingAction(WaitingActionType.Typing, 1f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f),
                        new WaitingAction(WaitingActionType.Typing, 0.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x34;
                    goto Label_50B0;

                case 0x34:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x35;
                    goto Label_50B0;

                case 0x35:
                    this.<text>__0 = (this.<>f__this.answer != 1) ? "we broke up last week" : ("me and " + this.<boyfriendsName>__7 + " broke up last week.");
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 2f), new WaitingAction(1, 1f) }));
                    this.$PC = 0x36;
                    goto Label_50B0;

                case 0x36:
                    BuddyListBehavior.Instance.ChangeBuddyStatus(ChatValues.JulieUsername, BuddyStatus.Online, null, true);
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0.5f));
                    this.$PC = 0x37;
                    goto Label_50B0;

                case 0x37:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("i'm so sorry", "i had no idea", "good riddance"));
                    this.$PC = 0x38;
                    goto Label_50B0;

                case 0x38:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "oh emily, i had no idea. how are you?~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "good riddance, you deserve better anyways.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "oh emily, i'm so sorry. how are you?~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x39;
                    goto Label_50B0;

                case 0x39:
                    if ((this.<>f__this.answer != 1) && (this.<>f__this.answer != 2))
                    {
                        if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "well thanks. it's just been really weird since.";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "i'm okay. it's just been really weird since.";
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 2f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x3a;
                    goto Label_50B0;

                case 0x3a:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x3b;
                    goto Label_50B0;

                case 0x3b:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 2f),
                        new WaitingAction(WaitingActionType.Typing, 2f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 60;
                    goto Label_50B0;

                case 60:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("me and him had the same group of friends so things are messy.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x3d;
                    goto Label_50B0;

                case 0x3d:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x3e;
                    goto Label_50B0;

                case 0x3e:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("i just feel really alone, you know?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x3f;
                    goto Label_50B0;

                case 0x3f:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("i understand", "i'm here for you", "people are stupid"));
                    this.$PC = 0x40;
                    goto Label_50B0;

                case 0x40:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "well you know i'm here for you.~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "ugh, people can just be so stupid.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "i totally understand how you're feeling.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x41;
                    goto Label_50B0;

                case 0x41:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "i know and thank you for that. i just feel really abandoned.";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "seriously. it just really hurts. i feel really abandoned.";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "it's just so awful. i feel abandoned. it's like i have no friends here anymore.";
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 2f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x42;
                    goto Label_50B0;

                case 0x42:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x43;
                    goto Label_50B0;

                case 0x43:
                    this.<choseText>__8 = string.Empty;
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("why did you break up?", "they were shitty friends", "so how are classes?"));
                    this.$PC = 0x44;
                    goto Label_50B0;

                case 0x44:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "they sound like shitty friends.~";
                            this.<choseText>__8 = "you chose to call out her friends";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "so how are classes?~";
                            this.<choseText>__8 = "you chose to change the subject";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "why did you break up?~";
                        this.<choseText>__8 = "you chose to ask about the break up";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x45;
                    goto Label_50B0;

                case 0x45:
                    this.<>f__this.dmb.ShowStatusLabel(this.<choseText>__8);
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1.5f), new WaitingAction(1, 0.5f), new WaitingAction(0, 1f), new WaitingAction(1, 1f) }));
                            this.$PC = 0x4c;
                            goto Label_50B0;
                        }
                        if (this.<>f__this.answer == 3)
                        {
                            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1.5f), new WaitingAction(1, 0.5f), new WaitingAction(0, 1f), new WaitingAction(1, 1f) }));
                            this.$PC = 0x52;
                            goto Label_50B0;
                        }
                        goto Label_2507;
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1.5f), new WaitingAction(1, 0.5f), new WaitingAction(0, 1f), new WaitingAction(1, 1f) }));
                    this.$PC = 70;
                    goto Label_50B0;

                case 70:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("i guess we just kind of grew apart?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x47;
                    goto Label_50B0;

                case 0x47:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 2f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x48;
                    goto Label_50B0;

                case 0x48:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("i feel like " + this.<boyfriendsName>__7 + " changed a lot over the summer.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x49;
                    goto Label_50B0;

                case 0x49:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 2f),
                        new WaitingAction(WaitingActionType.Typing, 1f),
                        new WaitingAction(WaitingActionType.Deleting, 0.5f),
                        new WaitingAction(WaitingActionType.Typing, 1f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x4a;
                    goto Label_50B0;

                case 0x4a:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("and things were just different when we got back.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x4b;
                    goto Label_50B0;

                case 0x4b:
                case 0x51:
                case 0x57:
                    goto Label_2507;

                case 0x4c:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("yeah i guess so, but they were my only friends.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x4d;
                    goto Label_50B0;

                case 0x4d:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 2f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x4e;
                    goto Label_50B0;

                case 0x4e:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("and they would rather be friends with " + this.<boyfriendsName>__7 + ".", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x4f;
                    goto Label_50B0;

                case 0x4f:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 2f),
                        new WaitingAction(WaitingActionType.Typing, 1f),
                        new WaitingAction(WaitingActionType.Deleting, 0.5f),
                        new WaitingAction(WaitingActionType.Typing, 1f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 80;
                    goto Label_50B0;

                case 80:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("like what did i do wrong?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x51;
                    goto Label_50B0;

                case 0x52:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("my classes? they've been okay i guess.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x53;
                    goto Label_50B0;

                case 0x53:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 2f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x54;
                    goto Label_50B0;

                case 0x54:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("well " + this.<boyfriendsName>__7 + " is in one of my classes", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x55;
                    goto Label_50B0;

                case 0x55:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 2f),
                        new WaitingAction(WaitingActionType.Typing, 1f),
                        new WaitingAction(WaitingActionType.Deleting, 0.5f),
                        new WaitingAction(WaitingActionType.Typing, 1f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x56;
                    goto Label_50B0;

                case 0x56:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("so that's just going to suck now.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x57;
                    goto Label_50B0;

                case 0x58:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("oh man, now i'm starting to cry.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x59;
                    goto Label_50B0;

                case 0x59:
                    this.<concatination>__9 = (this.<>f__this.answer != 2) ? "he's" : "they're";
                    this.<pronoun>__10 = (this.<>f__this.answer != 2) ? "his" : "they're";
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("please don't cry", "i'm so sorry", this.<concatination>__9 + " not worth it"));
                    this.$PC = 90;
                    goto Label_50B0;

                case 90:
                    if (this.<>f__this.answer == 1)
                    {
                        this.<text>__0 = "awe em, please don't cry. it's " + this.<pronoun>__10 + " loss, you're amazing <<<<<<<<an amazing person.~";
                    }
                    else if (this.<>f__this.answer == 2)
                    {
                        this.<text>__0 = "i'm so sorry em. but it's " + this.<pronoun>__10 + " loss, you're amazing <<<<<<<<an amazing person.~";
                    }
                    else if (this.<>f__this.answer == 3)
                    {
                        this.<text>__0 = this.<concatination>__9 + " not worth it em. you're amazing <<<<<<<<an amazing person.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x5b;
                    goto Label_50B0;

                case 0x5b:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 2f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x5c;
                    goto Label_50B0;

                case 0x5c:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("thanks. i'm sorry for being such a mess.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x5d;
                    goto Label_50B0;

                case 0x5d:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("you're not a mess", "i'll always be here for you", "i care about you"));
                    this.$PC = 0x5e;
                    goto Label_50B0;

                case 0x5e:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "it's okay em, i'll alwas<ys be here for you.~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "it's okay em, you knoe<w i care about you.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "you're not a mess em. you're just sas<d and that's totally okay.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x5f;
                    goto Label_50B0;

                case 0x5f:
                    this.<>f__this.dmb.ShowRememberLabel();
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 2f), new WaitingAction(1, 2f) }));
                    this.$PC = 0x60;
                    goto Label_50B0;

                case 0x60:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("thank you, it's nice to be able to talk about this.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x61;
                    goto Label_50B0;

                case 0x61:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 2f),
                        new WaitingAction(WaitingActionType.Typing, 1f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x62;
                    goto Label_50B0;

                case 0x62:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("i haven't really had the chance to vent yet.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x63;
                    goto Label_50B0;

                case 0x63:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("well, of course", "no problem", "i know you'd do the same"));
                    this.$PC = 100;
                    goto Label_50B0;

                case 100:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "no problem at all.~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "i know you'd do the same for me.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "well, of course.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x65;
                    goto Label_50B0;

                case 0x65:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f),
                        new WaitingAction(WaitingActionType.Deleting, 0.5f),
                        new WaitingAction(WaitingActionType.Typing, 1f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x66;
                    goto Label_50B0;

                case 0x66:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("i want to ask you something, but i'm afraid you'll hate me after.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x67;
                    goto Label_50B0;

                case 0x67:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 2f),
                        new WaitingAction(WaitingActionType.Typing, 1f),
                        new WaitingAction(WaitingActionType.Deleting, 0.5f),
                        new WaitingAction(WaitingActionType.Typing, 0.5f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x68;
                    goto Label_50B0;

                case 0x68:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("promise me you won't hate me?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x69;
                    goto Label_50B0;

                case 0x69:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("i promise", "i could never hate you", "just ask the question"));
                    this.$PC = 0x6a;
                    goto Label_50B0;

                case 0x6a:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "i could nevr<er hate you.~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "just ask the quesr<tion.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "i promid<se, what is it?~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x6b;
                    goto Label_50B0;

                case 0x6b:
                    if (!ChatValues.Chapter1WentToParty)
                    {
                        list = new List<WaitingAction> {
                            new WaitingAction(WaitingActionType.Idle, 2f),
                            new WaitingAction(WaitingActionType.Typing, 2f)
                        };
                        this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                        this.$PC = 0x7e;
                    }
                    else
                    {
                        this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 2f), new WaitingAction(1, 2f) }));
                        this.$PC = 0x6c;
                    }
                    goto Label_50B0;

                case 0x6c:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("at travis's party senior year.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x6d;
                    goto Label_50B0;

                case 0x6d:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 2f),
                        new WaitingAction(WaitingActionType.Typing, 2f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 110;
                    goto Label_50B0;

                case 110:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("remember how we got bored and went for that walk?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x6f;
                    goto Label_50B0;

                case 0x6f:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 2f),
                        new WaitingAction(WaitingActionType.Typing, 2f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x70;
                    goto Label_50B0;

                case 0x70:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("we stopped at that playground for a bit.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x71;
                    goto Label_50B0;

                case 0x71:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 2f),
                        new WaitingAction(WaitingActionType.Typing, 2f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x72;
                    goto Label_50B0;

                case 0x72:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("and we just layed there and looked at the stars.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x73;
                    goto Label_50B0;

                case 0x73:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 2f),
                        new WaitingAction(WaitingActionType.Typing, 0.5f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f),
                        new WaitingAction(WaitingActionType.Deleting, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x74;
                    goto Label_50B0;

                case 0x74:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("well, why didn't you kiss me?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x75;
                    goto Label_50B0;

                case 0x75:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("i don't know", "i didn't want to screw things up", "i didn't know you felt that way"));
                    this.$PC = 0x76;
                    goto Label_50B0;

                case 0x76:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "i didn't want to screw things up.~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "i didn't know you felt that way.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "i don't know.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x77;
                    goto Label_50B0;

                case 0x77:
                    this.<>f__this.dmb.ShowRememberLabel();
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1.5f), new WaitingAction(1, 2f), new WaitingAction(0, 0.5f) }));
                    this.$PC = 120;
                    goto Label_50B0;

                case 120:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("i've just always wondered how things would be if you did.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x79;
                    goto Label_50B0;

                case 0x79:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 2f),
                        new WaitingAction(WaitingActionType.Typing, 1f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f),
                        new WaitingAction(WaitingActionType.Deleting, 0.5f),
                        new WaitingAction(WaitingActionType.Typing, 1f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x7a;
                    goto Label_50B0;

                case 0x7a:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("i don't know, it's kind of stupid i guess.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x7b;
                    goto Label_50B0;

                case 0x7b:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("i've wondered that too", "i wish i had kissed you", "you should have told me"));
                    this.$PC = 0x7c;
                    goto Label_50B0;

                case 0x7c:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "i wish i had kissed you.~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "you should have told me.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "i've wondered that too.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x7d;
                    goto Label_50B0;

                case 0x7d:
                case 0x8d:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x8e;
                    goto Label_50B0;

                case 0x7e:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("remember travis's party freshmen year?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x7f;
                    goto Label_50B0;

                case 0x7f:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 2f),
                        new WaitingAction(WaitingActionType.Typing, 2f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x80;
                    goto Label_50B0;

                case 0x80:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("i brought it up all the time when we talked.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x81;
                    goto Label_50B0;

                case 0x81:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 2f),
                        new WaitingAction(WaitingActionType.Typing, 0.5f),
                        new WaitingAction(WaitingActionType.Deleting, 0.5f),
                        new WaitingAction(WaitingActionType.Typing, 1f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 130;
                    goto Label_50B0;

                case 130:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("well, why didn't you want to go?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x83;
                    goto Label_50B0;

                case 0x83:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("i never liked travis", "i would have been out of place", "i hated high school parties"));
                    this.$PC = 0x84;
                    goto Label_50B0;

                case 0x84:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "i think i would have been out of place.~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "i hated high school parties.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "i never liked travis.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x85;
                    goto Label_50B0;

                case 0x85:
                    this.<>f__this.dmb.ShowRememberLabel();
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1.5f), new WaitingAction(1, 2f), new WaitingAction(0, 0.5f) }));
                    this.$PC = 0x86;
                    goto Label_50B0;

                case 0x86:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("i just really wanted you to go. i had this whole plan to ditch julie.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x87;
                    goto Label_50B0;

                case 0x87:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 2f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x88;
                    goto Label_50B0;

                case 0x88:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("i've just always wondered how things would be if you did.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x89;
                    goto Label_50B0;

                case 0x89:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 2f),
                        new WaitingAction(WaitingActionType.Typing, 1f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f),
                        new WaitingAction(WaitingActionType.Deleting, 0.5f),
                        new WaitingAction(WaitingActionType.Typing, 1f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x8a;
                    goto Label_50B0;

                case 0x8a:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("i don't know, it's kind of stupid i guess.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x8b;
                    goto Label_50B0;

                case 0x8b:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("i've wondered that too", "i regret not going", "you should have told me"));
                    this.$PC = 140;
                    goto Label_50B0;

                case 140:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "i regret not going.~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "you should have told me.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "i've wondered that too.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x8d;
                    goto Label_50B0;

                case 0x8e:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("hey! i have an idea.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x8f;
                    goto Label_50B0;

                case 0x8f:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 2f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x90;
                    goto Label_50B0;

                case 0x90:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("maybe i could come visit this weekend?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x91;
                    goto Label_50B0;

                case 0x91:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 2f),
                        new WaitingAction(WaitingActionType.Typing, 1f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x92;
                    goto Label_50B0;

                case 0x92:
                    BuddyListBehavior.Instance.ChangeBuddyStatus(ChatValues.TravisUsername, BuddyStatus.Online, null, true);
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(1, 1f) }));
                    this.$PC = 0x93;
                    goto Label_50B0;

                case 0x93:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("i could really use some time away from this school.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x94;
                    goto Label_50B0;

                case 0x94:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 2f),
                        new WaitingAction(WaitingActionType.Typing, 2f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x95;
                    goto Label_50B0;

                case 0x95:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("and we always said we would visit each other.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 150;
                    goto Label_50B0;

                case 150:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x97;
                    goto Label_50B0;

                case 0x97:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("what do you think?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x98;
                    goto Label_50B0;

                case 0x98:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("please come visit", "as long as it's just as friends", "not a good idea"));
                    this.$PC = 0x99;
                    goto Label_50B0;

                case 0x99:
                    if (this.<>f__this.answer == 1)
                    {
                        this.<text>__0 = "please come visit! i sould<<<<<would love to see you!~";
                        this.<choseText>__8 = "you chose to let emily visit";
                    }
                    else if (this.<>f__this.answer == 2)
                    {
                        this.<text>__0 = "as long as it's hust<<<<just as friends.~";
                        this.<choseText>__8 = "you chose to establish boundaries";
                    }
                    else if (this.<>f__this.answer == 3)
                    {
                        this.<text>__0 = "i don't tjink<<<<hink that's a good idea.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x9a;
                    goto Label_50B0;

                case 0x9a:
                    this.<firstChoice>__11 = this.<>f__this.answer;
                    if (this.<>f__this.answer == 3)
                    {
                        list = new List<WaitingAction> {
                            new WaitingAction(WaitingActionType.Idle, 1.5f),
                            new WaitingAction(WaitingActionType.Typing, 1.5f)
                        };
                        this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                        this.$PC = 0x9b;
                        goto Label_50B0;
                    }
                    this.<>f__this.dmb.ShowStatusLabel(this.<choseText>__8);
                    goto Label_3F4B;

                case 0x9b:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("awe, come on " + ChatValues.GetPlayerName().ToLower() + ".", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x9c;
                    goto Label_50B0;

                case 0x9c:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 2f),
                        new WaitingAction(WaitingActionType.Typing, 2f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x9d;
                    goto Label_50B0;

                case 0x9d:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("we haven't hung out in years.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x9e;
                    goto Label_50B0;

                case 0x9e:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("okay, i guess", "i'm sorry", "you can't come"));
                    this.$PC = 0x9f;
                    goto Label_50B0;

                case 0x9f:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "i'm sorry, i just don't think it's the best idea.~";
                            this.<choseText>__8 = "you chose to say no";
                            this.<firstChoice>__11 = 4;
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "listen, you can't come.~";
                            this.<choseText>__8 = "you chose to say no";
                            this.<firstChoice>__11 = 4;
                        }
                    }
                    else
                    {
                        this.<text>__0 = "okay, i guess it's alright~";
                        this.<choseText>__8 = "you chose to let emily visit";
                        this.<firstChoice>__11 = 3;
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 160;
                    goto Label_50B0;

                case 160:
                    this.<>f__this.dmb.ShowStatusLabel(this.<choseText>__8);
                    goto Label_3F4B;

                case 0xa1:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("thanks, i know i'm a mess right now.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xa2;
                    goto Label_50B0;

                case 0xa2:
                    this.<text>__0 = "it means a lot that you're there for me.";
                    goto Label_405F;

                case 0xa3:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xa4;
                    goto Label_50B0;

                case 0xa4:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 2f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0xa5;
                    goto Label_50B0;

                case 0xa5:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("oh what about your plans with emma?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xa6;
                    goto Label_50B0;

                case 0xa6:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("i'll make up some excuse", "i'll talk to her about it", "i can ditch her"));
                    this.$PC = 0xa7;
                    goto Label_50B0;

                case 0xa7:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "i'll talk to hee<r about it.~";
                            this.<choseText>__8 = "you chose to talk to emma";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "i can just dir<tch her.~";
                            this.<choseText>__8 = "you chose to ditch emma";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "i'm not worried. i'll make up some exx<cuse.~";
                        this.<choseText>__8 = "you chose to lie to emma";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0xa8;
                    goto Label_50B0;

                case 0xa8:
                    this.<>f__this.dmb.ShowStatusLabel(this.<choseText>__8);
                    ChatValues.Chapter3EmmaDecision = this.<>f__this.answer;
                    if (this.<>f__this.answer != 3)
                    {
                        this.<text>__0 = "okay, i just don't want to mess things up.";
                    }
                    else
                    {
                        this.<text>__0 = "okay, if you think that's best.";
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0xa9;
                    goto Label_50B0;

                case 0xa9:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 170;
                    goto Label_50B0;

                case 170:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 2f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0xab;
                    goto Label_50B0;

                case 0xab:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("what do you want to do this weekend?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xac;
                    goto Label_50B0;

                case 0xac:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("hang out in my dorm", "go to some parties", "some stuff around campus"));
                    this.$PC = 0xad;
                    goto Label_50B0;

                case 0xad:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "definitely go to some l<parties.~";
                            this.<choseText>__8 = "you chose to go to some parties";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "just whatever around camo<pus.~";
                            this.<choseText>__8 = "you chose some stuff around campus";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "just b<hang out in my dorm.~";
                        this.<choseText>__8 = "you chose to hang out in your dorm";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0xae;
                    goto Label_50B0;

                case 0xae:
                    this.<>f__this.dmb.ShowStatusLabel(this.<choseText>__8);
                    ChatValues.Chapter3TypeOfWeekend = this.<>f__this.answer;
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1.5f), new WaitingAction(1, 2f) }));
                    this.$PC = 0xaf;
                    goto Label_50B0;

                case 0xaf:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("sounds good to me! should i bring my alcohol?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xb0;
                    goto Label_50B0;

                case 0xb0:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("yeah definitely!", "i have some", "we don't need any"));
                    this.$PC = 0xb1;
                    goto Label_50B0;

                case 0xb1:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "nah i have dome<<<<some.~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "no, we don't need dany<<<<any.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "yeah definirely<<<<tely!~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0xb2;
                    goto Label_50B0;

                case 0xb2:
                    ChatValues.Chapter3WillDrinkTogether = this.<>f__this.answer != 3;
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 2f), new WaitingAction(1, 2f) }));
                    this.$PC = 0xb3;
                    goto Label_50B0;

                case 0xb3:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("okay, i'm so excited to finally come and visit.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 180;
                    goto Label_50B0;

                case 180:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 2f),
                        new WaitingAction(WaitingActionType.Typing, 2f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0xb5;
                    goto Label_50B0;

                case 0xb5:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("oh shit, i actually have to run.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xb6;
                    goto Label_50B0;

                case 0xb6:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0xb7;
                    goto Label_50B0;

                case 0xb7:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("but i'll see you this weekend, okay?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xb8;
                    goto Label_50B0;

                case 0xb8:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("of course!", "see you soon!", "talk to you later"));
                    this.$PC = 0xb9;
                    goto Label_50B0;

                case 0xb9:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "see you soon!~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "talk to you later.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "of course!~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0xba;
                    goto Label_50B0;

                case 0xba:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0xbb;
                    goto Label_50B0;

                case 0xbb:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("bye!", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xbc;
                    goto Label_50B0;

                case 0xbc:
                case 0xce:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(ChatValues.AwayText, ChatMessageType.OtherAway, 1f));
                    this.$PC = 0xcf;
                    goto Label_50B0;

                case 0xbd:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("oh, okay.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 190;
                    goto Label_50B0;

                case 190:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 0.5f),
                        new WaitingAction(WaitingActionType.Idle, 1f),
                        new WaitingAction(WaitingActionType.Typing, 1f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0xbf;
                    goto Label_50B0;

                case 0xbf:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("i just thought that", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xc0;
                    goto Label_50B0;

                case 0xc0:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f),
                        new WaitingAction(WaitingActionType.Typing, 0.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0xc1;
                    goto Label_50B0;

                case 0xc1:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("i guess it doesn't really matter.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xc2;
                    goto Label_50B0;

                case 0xc2:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("it'll complicate things", "it's not a good time", "you'll be fine"));
                    this.$PC = 0xc3;
                    goto Label_50B0;

                case 0xc3:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "i'm sorry, it's just not a good time.~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "you'll be fine without me.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "i don't want to complicate things.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0xc4;
                    goto Label_50B0;

                case 0xc4:
                    ChatValues.Chapter3TypeRejectReasoning = this.<>f__this.answer;
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1.5f), new WaitingAction(1, 0.5f) }));
                    this.$PC = 0xc5;
                    goto Label_50B0;

                case 0xc5:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("okay.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xc6;
                    goto Label_50B0;

                case 0xc6:
                    if (!ChatValues.Chapter1DidPromise)
                    {
                        list = new List<WaitingAction> {
                            new WaitingAction(WaitingActionType.Idle, 1f),
                            new WaitingAction(WaitingActionType.Typing, 1f)
                        };
                        this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                        this.$PC = 0xcb;
                    }
                    else
                    {
                        this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 2f), new WaitingAction(0, 0.5f) }));
                        this.$PC = 0xc7;
                    }
                    goto Label_50B0;

                case 0xc7:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("you know, when you promised to be there for me senior year, i really thought you meant it.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 200;
                    goto Label_50B0;

                case 200:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0xc9;
                    goto Label_50B0;

                case 0xc9:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("i'm just going to go.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xca;
                    goto Label_50B0;

                case 0xca:
                case 0xcc:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0xcd;
                    goto Label_50B0;

                case 0xcb:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("listen, i'm going to go.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xcc;
                    goto Label_50B0;

                case 0xcd:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("i'll ttyl.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0xce;
                    goto Label_50B0;

                case 0xcf:
                    this.<>f__this.currentStatus = BuddyStatus.Away;
                    BuddyListBehavior.Instance.ChangeBuddyStatus(ChatValues.OtherUsername, BuddyStatus.Away, null, false);
                    ChatValues.SetCurrentLevel(3);
                    this.<>f__this.SetCompletionAchievement(3);
                    this.$current = new WaitForSeconds(2.5f);
                    this.$PC = 0xd0;
                    goto Label_50B0;

                case 0xd0:
                    LoadingScreenBehavior.Instance.LoadMenuScene(false);
                    this.$PC = -1;
                    goto Label_50AE;

                default:
                    goto Label_50AE;
            }
            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, true));
            this.$PC = 7;
            goto Label_50B0;
        Label_060F:
            list = new List<WaitingAction>();
            list.Add(new WaitingAction(WaitingActionType.Idle, 1f));
            list.Add(new WaitingAction(WaitingActionType.Typing, 2f));
            list.Add(new WaitingAction(WaitingActionType.Idle, 0.5f));
            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
            this.$PC = 10;
            goto Label_50B0;
        Label_1438:
            this.<>f__this.dmb.ShowRememberLabel();
            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1.5f), new WaitingAction(1, 0.5f), new WaitingAction(0, 0.5f) }));
            this.$PC = 0x2d;
            goto Label_50B0;
        Label_2507:
            list = new List<WaitingAction>();
            list.Add(new WaitingAction(WaitingActionType.Idle, 2f));
            list.Add(new WaitingAction(WaitingActionType.Typing, 1.5f));
            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
            this.$PC = 0x58;
            goto Label_50B0;
        Label_3F4B:
            ChatValues.Chapter3EstablishedBoundaries = (this.<firstChoice>__11 == 2) || (this.<firstChoice>__11 == 4);
            if (this.<firstChoice>__11 == 4)
            {
                ChatValues.Chapter3EmilyVisited = false;
                this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1f), new WaitingAction(1, 0.5f), new WaitingAction(0, 0.5f), new WaitingAction(2, 0.5f), new WaitingAction(1, 1f) }));
                this.$PC = 0xbd;
                goto Label_50B0;
            }
            ChatValues.Chapter3EmilyVisited = true;
            if (this.<firstChoice>__11 == 1)
            {
                this.<text>__0 = "great! awe man now i'm really excited!";
            }
            else if (this.<firstChoice>__11 == 2)
            {
                this.<text>__0 = "oh of course! i'm not looking for anything like that.";
            }
            else if (this.<firstChoice>__11 == 3)
            {
                this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1.5f), new WaitingAction(1, 1.5f) }));
                this.$PC = 0xa1;
                goto Label_50B0;
            }
        Label_405F:
            list = new List<WaitingAction>();
            list.Add(new WaitingAction(WaitingActionType.Idle, 1.5f));
            list.Add(new WaitingAction(WaitingActionType.Typing, 1.5f));
            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
            this.$PC = 0xa3;
            goto Label_50B0;
        Label_50AE:
            return false;
        Label_50B0:
            return true;
        }

        [DebuggerHidden]
        public void Reset()
        {
            throw new NotSupportedException();
        }

        object IEnumerator<object>.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }

        object IEnumerator.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }
    }
}

