﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using UnityEngine;

public class Chapter5ScriptBehavior : BaseScriptBehavior
{
    private BuddyStatus currentStatus;

    public override void DidPressInfoButton()
    {
        BuddyInfoBehavior.Instance.SetUp(ChatValues.OtherUsername, ChatValues.Script5BuddyInfo, ChatValues.ColorFromRGB(11, 0x27, 0x30), this.currentStatus, null);
        BuddyInfoBehavior.Instance.Show();
    }

    public override void DidPressTextButton(int index)
    {
        base.answer = index;
    }

    public override void PlayScript()
    {
        TaskBarBehavior.Instance.SetState(TaskBarState.BuddyList);
        BuddyListBehavior.Instance.Show();
        DisplayManagerBehavior.Instance.SetBuddyIcons(ChatValues.GetPlayerBuddyIcon(), BuddyIconType.EmilySnowPatrol2);
        base.StartCoroutine(this.ScriptRunner());
    }

    [DebuggerHidden]
    private IEnumerator ScriptRunner()
    {
        return new <ScriptRunner>c__IteratorC { <>f__this = this };
    }

    public override void SetUpBuddyList()
    {
        bool flag = ChatValues.Chapter1WentToParty;
        BuddyListBehavior instance = BuddyListBehavior.Instance;
        instance.AddBuddyRow(ChatValues.OtherUsername, ChatValues.Script5BuddyInfo, ChatValues.ColorFromRGB(11, 0x27, 0x30), BuddyStatus.Offline, null);
        instance.AddBuddyRow(ChatValues.BradUsername, !flag ? ChatValues.Script5BradNoEmilyInfo : ChatValues.Script5BradWithEmilyInfo, ChatValues.ColorFromRGB(0x25, 4, 4), BuddyStatus.Away, ChatValues.Script5BradAway);
        instance.AddBuddyRow(ChatValues.TravisUsername, !flag ? ChatValues.Script5TravisWithEmilyInfo : ChatValues.Script5TravisNoEmilyInfo, ChatValues.ColorFromRGB(5, 0x10, 0x2e), BuddyStatus.Away, ChatValues.Script5TravisAway);
        instance.AddBuddyRow(ChatValues.MikeUsername, ChatValues.Script5MikeInfo, Color.white, BuddyStatus.Away, ChatValues.Script5MikeAway);
        instance.AddBuddyRow(ChatValues.EmmaUsername, ChatValues.Script5EmmaInfo, ChatValues.ColorFromRGB(0xbc, 0x94, 0xd9), BuddyStatus.Away, ChatValues.Script5EmmaAway);
        instance.AddBuddyRow(ChatValues.JulieUsername, ChatValues.Script5JulieInfo, ChatValues.ColorFromRGB(0xfd, 0xbb, 0xef), BuddyStatus.Away, ChatValues.Script5JulieAway);
        instance.AddOfflineOnlyBuddyRow("SirShovel7");
        instance.AddOfflineOnlyBuddyRow("RungleJumble");
        instance.AddOfflineOnlyBuddyRow("HexxSells");
        instance.AddOfflineOnlyBuddyRow("FR4C7x05C");
        instance.AddOfflineOnlyBuddyRow("KeepTalkin");
    }

    [CompilerGenerated]
    private sealed class <ScriptRunner>c__IteratorC : IEnumerator, IDisposable, IEnumerator<object>
    {
        internal object $current;
        internal int $PC;
        internal Chapter5ScriptBehavior <>f__this;
        internal string <boyfriendsName>__3;
        internal bool <playerLikesEmma>__4;
        internal bool <saidGoodbye>__5;
        internal string <secondText>__1;
        internal string <text>__0;
        internal int <typeOfExcuse>__2;

        [DebuggerHidden]
        public void Dispose()
        {
            this.$PC = -1;
        }

        public bool MoveNext()
        {
            List<WaitingAction> list;
            uint num = (uint) this.$PC;
            this.$PC = -1;
            switch (num)
            {
                case 0:
                    this.<text>__0 = string.Empty;
                    this.$current = new WaitForSeconds(2f);
                    this.$PC = 1;
                    goto Label_2836;

                case 1:
                    TaskBarBehavior.Instance.SetState(TaskBarState.BuddyListChat);
                    BuddyListBehavior.Instance.Hide();
                    DisplayManagerBehavior.Instance.Show();
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(ChatValues.SignInText, ChatMessageType.OtherSignIn, 0f));
                    this.$PC = 2;
                    goto Label_2836;

                case 2:
                    this.<>f__this.currentStatus = BuddyStatus.Online;
                    BuddyListBehavior.Instance.ChangeBuddyStatus(ChatValues.OtherUsername, BuddyStatus.Online, null, false);
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("hey", "hello", "howdy"));
                    this.$PC = 3;
                    goto Label_2836;

                case 3:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "hello.~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "howdy.~";
                        }
                        break;
                    }
                    this.<text>__0 = "hey.~";
                    break;

                case 4:
                    this.<secondText>__1 = string.Empty;
                    if (ChatValues.Chapter4PlayerTalkedToEmily)
                    {
                        list = new List<WaitingAction> {
                            new WaitingAction(WaitingActionType.Idle, 1.5f),
                            new WaitingAction(WaitingActionType.Typing, 1.5f)
                        };
                        this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                        this.$PC = 10;
                    }
                    else
                    {
                        this.<typeOfExcuse>__2 = ChatValues.Chapter4TypeOfExcuse;
                        if (this.<typeOfExcuse>__2 != 0)
                        {
                            this.<text>__0 = "Sorry I can't talk right now.";
                            if (this.<typeOfExcuse>__2 == 1)
                            {
                                this.<secondText>__1 = "I have some homework to do.";
                            }
                            else if (this.<typeOfExcuse>__2 == 2)
                            {
                                this.<secondText>__1 = "Some friends are coming over soon.";
                            }
                            else if (this.<typeOfExcuse>__2 == 3)
                            {
                                this.<secondText>__1 = "I have some things to do.";
                            }
                        }
                        else
                        {
                            this.<text>__0 = "I don't want to talk right now.";
                        }
                        list = new List<WaitingAction> {
                            new WaitingAction(WaitingActionType.Idle, 1.5f),
                            new WaitingAction(WaitingActionType.Typing, 0.5f),
                            new WaitingAction(WaitingActionType.Idle, 0.5f),
                            new WaitingAction(WaitingActionType.Typing, 1.5f)
                        };
                        this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                        this.$PC = 5;
                    }
                    goto Label_2836;

                case 5:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 6;
                    goto Label_2836;

                case 6:
                    if (string.IsNullOrEmpty(this.<secondText>__1))
                    {
                        goto Label_0500;
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 2f), new WaitingAction(1, 1.5f), new WaitingAction(0, 0.5f) }));
                    this.$PC = 7;
                    goto Label_2836;

                case 7:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<secondText>__1, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 8;
                    goto Label_2836;

                case 8:
                    goto Label_0500;

                case 9:
                    this.<>f__this.currentStatus = BuddyStatus.Away;
                    BuddyListBehavior.Instance.ChangeBuddyStatus(ChatValues.OtherUsername, BuddyStatus.Away, null, false);
                    goto Label_27F3;

                case 10:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("Hey " + ChatValues.GetPlayerName() + ".", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 11;
                    goto Label_2836;

                case 11:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("how are you?", "what's up?", "how's it shaking?"));
                    this.$PC = 12;
                    goto Label_2836;

                case 12:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "what's up?~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "how's it shaking?~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "how are you?~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 13;
                    goto Label_2836;

                case 13:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "Not much.";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "It's good.";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "I'm good.";
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 14;
                    goto Label_2836;

                case 14:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 15;
                    goto Label_2836;

                case 15:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x10;
                    goto Label_2836;

                case 0x10:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("How are you?", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x11;
                    goto Label_2836;

                case 0x11:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("I'm good", "I'm alright", "things could be better"));
                    this.$PC = 0x12;
                    goto Label_2836;

                case 0x12:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "I'm alright.~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "things could be better.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "I'm good.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x13;
                    goto Label_2836;

                case 0x13:
                    if (this.<>f__this.answer != 3)
                    {
                        this.<text>__0 = "Oh, good.";
                    }
                    else
                    {
                        this.<text>__0 = "Oh, I'm sorry to hear that.";
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 20;
                    goto Label_2836;

                case 20:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x15;
                    goto Label_2836;

                case 0x15:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("how's school?", "how've you been?", "how are things going?"));
                    this.$PC = 0x16;
                    goto Label_2836;

                case 0x16:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "how've you been?~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "how are things going?~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "how's school and everything?~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x17;
                    goto Label_2836;

                case 0x17:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 2f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x18;
                    goto Label_2836;

                case 0x18:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("Everythings been really good.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x19;
                    goto Label_2836;

                case 0x19:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("do you have any plans this weekend?", "what are you up to tonight?", "what's new in your life?"));
                    this.$PC = 0x1a;
                    goto Label_2836;

                case 0x1a:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "so, what are you up to tonight?~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "so, what's new in your life?~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "so, do you have any plans this weekend?~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x1b;
                    goto Label_2836;

                case 0x1b:
                    this.<boyfriendsName>__3 = !ChatValues.Chapter1WentToParty ? "Travis" : "Brad";
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "I don't know really. I'm going over " + this.<boyfriendsName>__3 + "'s house later.";
                            this.<secondText>__1 = "Oh, I don't know if you knew. Me and him got back together.";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "Not a whole lot really, just finishing up college.";
                            this.<secondText>__1 = "Oh, I don't know if you knew. Me and " + this.<boyfriendsName>__3 + " got back together.";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "Not really, I think me and " + this.<boyfriendsName>__3 + " might go to a concert or something.";
                        this.<secondText>__1 = "Oh, I don't know if you knew. Me and him got back together.";
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 2f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x1c;
                    goto Label_2836;

                case 0x1c:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x1d;
                    goto Label_2836;

                case 0x1d:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 2f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 30;
                    goto Label_2836;

                case 30:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<secondText>__1, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x1f;
                    goto Label_2836;

                case 0x1f:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("that's great!", "good for you", "even after that awful break up?"));
                    this.$PC = 0x20;
                    goto Label_2836;

                case 0x20:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "oh, good for you.~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "even after that awful break up?~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "oh, that's great!~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x21;
                    goto Label_2836;

                case 0x21:
                    if (this.<>f__this.answer == 3)
                    {
                        this.<text>__0 = "Well, it was so awful because we cared for each other so much.";
                        this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1.5f), new WaitingAction(1, 2.5f) }));
                        this.$PC = 0x23;
                    }
                    else
                    {
                        this.<text>__0 = "Thanks.";
                        this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(new List<WaitingAction> { new WaitingAction(0, 1.5f), new WaitingAction(1, 1f) }));
                        this.$PC = 0x22;
                    }
                    goto Label_2836;

                case 0x22:
                case 0x23:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x24;
                    goto Label_2836;

                case 0x24:
                    this.<playerLikesEmma>__4 = ChatValues.Chapter4PlayerLikesEmma;
                    if (this.<playerLikesEmma>__4)
                    {
                        this.<text>__0 = "How's your crush Emma doing?";
                    }
                    else
                    {
                        this.<text>__0 = "How's your friend Emma doing?";
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 2f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x25;
                    goto Label_2836;

                case 0x25:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x26;
                    goto Label_2836;

                case 0x26:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("not great", "I don't care", "well..."));
                    this.$PC = 0x27;
                    goto Label_2836;

                case 0x27:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "I don't care. ";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "well, ";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "not great. ";
                    }
                    if (ChatValues.Chapter3EmilyVisited)
                    {
                        if (ChatValues.Chapter3EmmaDecision == 2)
                        {
                            if (this.<playerLikesEmma>__4)
                            {
                                this.<text>__0 = this.<text>__0 + "she told me that she's always felt weird about you visiting.~";
                            }
                            else
                            {
                                this.<text>__0 = this.<text>__0 + "she started dating mike, so now I barely see her.~";
                            }
                        }
                        else if (ChatValues.Chapter3EmmaDecision == 1)
                        {
                            this.<text>__0 = this.<text>__0 + "she found out that I lied about you visiting that weekend.~";
                        }
                        else
                        {
                            this.<text>__0 = this.<text>__0 + "she found out that I ditched her that weekend you visited.~";
                        }
                    }
                    else if (this.<playerLikesEmma>__4)
                    {
                        this.<text>__0 = this.<text>__0 + "she told me she was tired of waiting for me.~";
                    }
                    else
                    {
                        this.<text>__0 = this.<text>__0 + "she started dating mike, so now I barely see her.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 40;
                    goto Label_2836;

                case 40:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x29;
                    goto Label_2836;

                case 0x29:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("Oh, I'm sorry.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x2a;
                    goto Label_2836;

                case 0x2a:
                    this.<text>__0 = !this.<playerLikesEmma>__4 ? "I have other friends" : "that ship has sailed";
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer(this.<text>__0, "it's whatever", "I couldn't care less"));
                    this.$PC = 0x2b;
                    goto Label_2836;

                case 0x2b:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "yeah, it's whatever.~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "I really couldn't care less.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = !this.<playerLikesEmma>__4 ? "it's okay, I have other friends.~" : "yeah, that ship has sailed.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x2c;
                    goto Label_2836;

                case 0x2c:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x2d;
                    goto Label_2836;

                case 0x2d:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("Well, college is almost over anyways.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x2e;
                    goto Label_2836;

                case 0x2e:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("will you miss it?", "can you believe we're almost adults?", "it flew by, don't you think?"));
                    this.$PC = 0x2f;
                    goto Label_2836;

                case 0x2f:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "can you believe we're almost adults?~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "it flew by, don't you think?~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "will you miss it?~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x30;
                    goto Label_2836;

                case 0x30:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "Nope, it definitely doesn't feel like it's been four years.";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "Yeah, it really did. Crazy to think we're almost like real adults.";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "Yeah, I guess so. But I'm excited to be done too.";
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 2f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x31;
                    goto Label_2836;

                case 0x31:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 50;
                    goto Label_2836;

                case 50:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("do you miss high school?", "we had some good times", "high school was so long ago"));
                    this.$PC = 0x33;
                    goto Label_2836;

                case 0x33:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "we had some good times in college.~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "high school was so long ago.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "do you miss high school at all?~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x34;
                    goto Label_2836;

                case 0x34:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "Yeah kind of.";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "Yeah it was.";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "Not really.";
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x35;
                    goto Label_2836;

                case 0x35:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x36;
                    goto Label_2836;

                case 0x36:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 2.5f),
                        new WaitingAction(WaitingActionType.Idle, 0.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x37;
                    goto Label_2836;

                case 0x37:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("I'd rather not think about the past though.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x38;
                    goto Label_2836;

                case 0x38:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("well, okay", "I'm sorry", "oh, sure"));
                    this.$PC = 0x39;
                    goto Label_2836;

                case 0x39:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "I'm sorry.~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "oh, sure.~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "well, okay.~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x3a;
                    goto Label_2836;

                case 0x3a:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 2f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x3b;
                    goto Label_2836;

                case 0x3b:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("I'm just tired of reliving memories.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 60;
                    goto Label_2836;

                case 60:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("so, any plans for graduation?", "so, all set for graduation?", "so, any big projects left?"));
                    this.$PC = 0x3d;
                    goto Label_2836;

                case 0x3d:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "so are you all set for graduation?~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "so do you have any big projects left?~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "so do you have plans for graduation?~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x3e;
                    goto Label_2836;

                case 0x3e:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "I think so, I still have to order my gown and stuff.";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "Just one, but it's almost done now.";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "Oh no, not really. I know my family's coming up and stuff.";
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 2.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x3f;
                    goto Label_2836;

                case 0x3f:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x40;
                    goto Label_2836;

                case 0x40:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("are you going to move back home?", "what's " + this.<boyfriendsName>__3.ToLower() + " doing after graduation?", "what are you doing this summer?"));
                    this.$PC = 0x41;
                    goto Label_2836;

                case 0x41:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "what's " + this.<boyfriendsName>__3.ToLower() + " doing after graduation?~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "what are you doing this summer?~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "are you going to move back home?~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x42;
                    goto Label_2836;

                case 0x42:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "I think me and him are going to stay here for the summer at least.";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "Just hang out here with " + this.<boyfriendsName>__3 + " and try to find a job.";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "Not immediately, I have this lease until August.";
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 2.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x43;
                    goto Label_2836;

                case 0x43:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x44;
                    goto Label_2836;

                case 0x44:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("how's your week been going?", "what'd you do last weekend?", "can we talk about things?"));
                    this.$PC = 0x45;
                    goto Label_2836;

                case 0x45:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "what'd you do last weekend?~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "can we talk about things<<<<<<<<<<<<<<<<<<<<<<<<do anything fun recently?~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "how's your week been going?~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 70;
                    goto Label_2836;

                case 70:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "Just work and stuff.";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "Not really, I've just been working.";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "It's been alright, pretty busy.";
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 2f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x47;
                    goto Label_2836;

                case 0x47:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x48;
                    goto Label_2836;

                case 0x48:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("what are you doing right now?", "what'd you do today?", "could I see you this summer?"));
                    this.$PC = 0x49;
                    goto Label_2836;

                case 0x49:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "what'd you do today?~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "could I see you this summer<<<<<<<<<<<<<<<<<<<<<<<<<<<are you doing homework?~";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "what are you doing right now?~";
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x4a;
                    goto Label_2836;

                case 0x4a:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "Just school and now homework.";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<text>__0 = "Yeah, just some stuff due tomorrow.";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "Just some homework.";
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 2f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x4b;
                    goto Label_2836;

                case 0x4b:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x4c;
                    goto Label_2836;

                case 0x4c:
                    this.<saidGoodbye>__5 = false;
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("so how's school?", "do you ever miss things?", "goodbye"));
                    this.$PC = 0x4d;
                    goto Label_2836;

                case 0x4d:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "do you ever miss <<<<<<<<<<<<<<<<<how are classes?~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<saidGoodbye>__5 = true;
                        }
                    }
                    else
                    {
                        this.<text>__0 = "so how's school?~";
                    }
                    if (this.<saidGoodbye>__5)
                    {
                        goto Label_231F;
                    }
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                    this.$PC = 0x4e;
                    goto Label_2836;

                case 0x4e:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "They're good. Same old same old.";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "It's good. Same old same old.";
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x4f;
                    goto Label_2836;

                case 0x4f:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 80;
                    goto Label_2836;

                case 80:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("gone to any concerts lately?", "do you miss me?", "goodbye"));
                    this.$PC = 0x51;
                    goto Label_2836;

                case 0x51:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "do you miss <<<<<<<<<<<<find any good music lately?~";
                        }
                        else if (this.<>f__this.answer == 3)
                        {
                            this.<saidGoodbye>__5 = true;
                        }
                    }
                    else
                    {
                        this.<text>__0 = "gone to any concerts lately?~";
                    }
                    goto Label_231F;

                case 0x52:
                    if (this.<>f__this.answer != 1)
                    {
                        if (this.<>f__this.answer == 2)
                        {
                            this.<text>__0 = "Not really, just listening to old stuff.";
                        }
                    }
                    else
                    {
                        this.<text>__0 = "Not really, I'm busy with school.";
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1.5f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x53;
                    goto Label_2836;

                case 0x53:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(this.<text>__0, ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x54;
                    goto Label_2836;

                case 0x54:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("will we ever be the way we were?", "goodbye", "goodbye"));
                    this.$PC = 0x55;
                    goto Label_2836;

                case 0x55:
                    if (this.<>f__this.answer != 1)
                    {
                        this.<saidGoodbye>__5 = true;
                    }
                    else
                    {
                        this.<text>__0 = "will we ever <<<<<<<<<<<<<watch any good movies lately?~";
                    }
                    goto Label_248D;

                case 0x56:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x57;
                    goto Label_2836;

                case 0x57:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("No, not really.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x58;
                    goto Label_2836;

                case 0x58:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("is this it for us?", "goodbye", "goodbye"));
                    this.$PC = 0x59;
                    goto Label_2836;

                case 0x59:
                    if (this.<>f__this.answer != 1)
                    {
                        this.<saidGoodbye>__5 = true;
                    }
                    else
                    {
                        this.<text>__0 = "is this it <<<<<<<<<<<how's the weather been there?~";
                    }
                    goto Label_25BD;

                case 90:
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x5b;
                    goto Label_2836;

                case 0x5b:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("It's been alright.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x5c;
                    goto Label_2836;

                case 0x5c:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.WaitOnAnswer("goodbye", "goodbye", "goodbye"));
                    this.$PC = 0x5d;
                    goto Label_2836;

                case 0x5d:
                    goto Label_26C5;

                case 0x5e:
                    if (this.<saidGoodbye>__5)
                    {
                        this.<>f__this.dmb.ShowStatusLabel("you chose to end the conversation");
                    }
                    list = new List<WaitingAction> {
                        new WaitingAction(WaitingActionType.Idle, 1.5f),
                        new WaitingAction(WaitingActionType.Typing, 1f),
                        new WaitingAction(WaitingActionType.Idle, 1f)
                    };
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.ShowWaitingActions(list));
                    this.$PC = 0x5f;
                    goto Label_2836;

                case 0x5f:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage("Okay, bye.", ChatMessageType.OtherMessage, 0f));
                    this.$PC = 0x60;
                    goto Label_2836;

                case 0x60:
                    this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(ChatValues.AwayText, ChatMessageType.PlayerAway, 1f));
                    this.$PC = 0x61;
                    goto Label_2836;

                case 0x61:
                    goto Label_27F3;

                case 0x62:
                    LoadingScreenBehavior.Instance.LoadMenuScene(true);
                    this.$PC = -1;
                    goto Label_2834;

                default:
                    goto Label_2834;
            }
            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, true));
            this.$PC = 4;
            goto Label_2836;
        Label_0500:
            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.SendChatMessage(ChatValues.AwayText, ChatMessageType.OtherAway, 1f));
            this.$PC = 9;
            goto Label_2836;
        Label_231F:
            if (!this.<saidGoodbye>__5)
            {
                this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                this.$PC = 0x52;
                goto Label_2836;
            }
        Label_248D:
            if (!this.<saidGoodbye>__5)
            {
                this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                this.$PC = 0x56;
                goto Label_2836;
            }
        Label_25BD:
            if (!this.<saidGoodbye>__5)
            {
                this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText(this.<text>__0, false));
                this.$PC = 90;
                goto Label_2836;
            }
        Label_26C5:
            this.$current = this.<>f__this.StartCoroutine(this.<>f__this.dmb.WriteText("okay, I think I'm going to go. goodbye.~", false));
            this.$PC = 0x5e;
            goto Label_2836;
        Label_27F3:
            ChatValues.SetCurrentLevel(5);
            this.<>f__this.SetCompletionAchievement(5);
            this.$current = new WaitForSeconds(2.5f);
            this.$PC = 0x62;
            goto Label_2836;
        Label_2834:
            return false;
        Label_2836:
            return true;
        }

        [DebuggerHidden]
        public void Reset()
        {
            throw new NotSupportedException();
        }

        object IEnumerator<object>.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }

        object IEnumerator.Current
        {
            [DebuggerHidden]
            get
            {
                return this.$current;
            }
        }
    }
}

