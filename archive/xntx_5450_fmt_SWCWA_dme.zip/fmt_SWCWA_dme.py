from inc_noesis import *
import noesis
import rapi

def registerNoesisTypes():
    handle = noesis.register("Star Wars: Clone Wars Adventures", ".dme")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    Magic = bs.readBytes(4).decode("ASCII")
    if Magic != "DMOD": 
        return 0
    return 1   

def noepyLoadModel(data, mdlList):
    ctx = rapi.rpgCreateContext()
    rapi.rpgSetOption(noesis.RPGOPT_TRIWINDBACKWARD, 1) #flip the normals
    bs = NoeBitStream(data)
    bs.seek(0x08, NOESEEK_ABS)
    hdrOff = bs.readUInt()
    bs.seek(0x08, NOESEEK_REL)
    texlistlen = bs.readUInt()
    texList = bs.readBytes(texlistlen).decode("ASCII").rstrip("\x00").split("\x00")
    for i in texList:
        if "_AO" in i:
            texList.remove(i)
    print(texList, "texture list")
    #texList = bs.readBytes(texlistlen).decode("ASCII").replace("\x00", "\n")
    fileName = rapi.getLocalFileName(rapi.getInputName())  #get file name + ext without path
    #print("\n" * 2, " * * *   ", fileName, "   * * *")  #model name
    #print(texNames, "\n" * 2)         #vertical list of textures for this model
    bs.seek(hdrOff + 0x24, NOESEEK_ABS)
    numSubmesh = bs.readUInt()
    for i in range(numSubmesh):
        rapi.rpgSetName("submesh_" + str(i))
        texID = bs.readUInt()
        print(texID, "texID")
        bs.seek(0xc, NOESEEK_REL)	
        VtxBytes = bs.readUInt()    
        VertCount = bs.readUInt()
        bs.seek(0x04, NOESEEK_REL)
        FaceCount = bs.readUInt()
        VertBuff = bs.readBytes(VertCount * VtxBytes)
        if VtxBytes == 16:
            rapi.rpgBindPositionBufferOfs(VertBuff, noesis.RPGEODATA_FLOAT, VtxBytes, 0)
            rapi.rpgBindUV1BufferOfs(VertBuff, noesis.RPGEODATA_HALFFLOAT, VtxBytes, 12) #?
            print("using 16 stride")
        elif VtxBytes == 24:
            rapi.rpgBindPositionBufferOfs(VertBuff, noesis.RPGEODATA_FLOAT, VtxBytes, 0)
            #rapi.rpgBindNormalBufferOfs(VertBuff, noesis.RPGEODATA_FLOAT, VtxBytes, 12) #?
            rapi.rpgBindUV1BufferOfs(VertBuff, noesis.RPGEODATA_FLOAT, VtxBytes, 16)
            print("using 24 stride")
        elif VtxBytes == 36 and "Wield_LightsaberBlade_Katana_LOD0.dme" in fileName: 
            rapi.rpgBindPositionBufferOfs(VertBuff, noesis.RPGEODATA_FLOAT, VtxBytes, 0)
            rapi.rpgBindUV1BufferOfs(VertBuff, noesis.RPGEODATA_FLOAT, VtxBytes, 28)
            print("using 36 stride and katana")
        elif VtxBytes == 36:
            rapi.rpgBindPositionBufferOfs(VertBuff, noesis.RPGEODATA_FLOAT, VtxBytes, 0)
            rapi.rpgBindNormalBufferOfs(VertBuff, noesis.RPGEODATA_FLOAT, VtxBytes, 12) #? 
            rapi.rpgBindUV1BufferOfs(VertBuff, noesis.RPGEODATA_FLOAT, VtxBytes, 28)
            print("using 36 stride")
        elif VtxBytes == 44:
            rapi.rpgBindPositionBufferOfs(VertBuff, noesis.RPGEODATA_FLOAT, VtxBytes, 0)
            rapi.rpgBindNormalBufferOfs(VertBuff, noesis.RPGEODATA_FLOAT, VtxBytes, 12) #?
            rapi.rpgBindUV1BufferOfs(VertBuff, noesis.RPGEODATA_FLOAT, VtxBytes, 36)
            #noesis.logPopup()
            print("using 44 stride")
        elif VtxBytes == 52:
            rapi.rpgBindPositionBufferOfs(VertBuff, noesis.RPGEODATA_FLOAT, VtxBytes, 0)
            rapi.rpgBindNormalBufferOfs(VertBuff, noesis.RPGEODATA_FLOAT, VtxBytes, 20) #?
            rapi.rpgBindUV1BufferOfs(VertBuff, noesis.RPGEODATA_FLOAT, VtxBytes, 44)
            #noesis.logPopup()
            print("using 52 stride")
        elif VtxBytes == 60:
            rapi.rpgBindPositionBufferOfs(VertBuff, noesis.RPGEODATA_FLOAT, VtxBytes, 0)
            rapi.rpgBindNormalBufferOfs(VertBuff, noesis.RPGEODATA_FLOAT, VtxBytes, 20) #?
            rapi.rpgBindUV1BufferOfs(VertBuff, noesis.RPGEODATA_FLOAT, VtxBytes, 44)
            print("using 60 stride")
            #noesis.logPopup()
        FaceBuff = bs.readBytes(FaceCount * 2)
        try:
            if texID == 0:
                texID = texList[0]
            elif texID == 1:
                texID = texList[1]
            elif texID == 2:
                texID = texList[2]
            elif texID == 3:
                texID = texList[3]
            elif texID == 4:
                texID = texList[4]
            elif texID == 5:
                texID = texList[5]
            elif texID == 6:
                texID = texList[6]
            rapi.rpgSetMaterial(texID)
        except:
            pass
        rapi.rpgCommitTriangles(FaceBuff, noesis.RPGEODATA_USHORT, FaceCount, noesis.RPGEO_TRIANGLE, 1)
    mdl = rapi.rpgConstructModel()
    mdlList.append(mdl)
    rapi.rpgClearBufferBinds()   
    return 1