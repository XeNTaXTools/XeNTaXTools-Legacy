#H:\Wii-u\so5\PCSG00632_VALKYRIE_01.00\Resource\Character\Cos\dlc_Cos_00_00
from inc_noesis import *
import rapi
import collections
import struct

def registerNoesisTypes():
	handle = noesis.register("Valkyrie Drive: BHIKKHUNI", ".mib;.msb")
	noesis.setHandlerTypeCheck(handle, vDriveCheckType)
	noesis.setHandlerLoadModel(handle, vDriveLoadModel)

	handle = noesis.register("Valkyrie Drive: BHIKKHUNI", ".mab")
	noesis.setHandlerTypeCheck(handle, vDriveCheckType)
	noesis.setHandlerLoadModel(handle, vDriveLoadAnim)
	
	noesis.logPopup()

	return 1


def vDriveCheckType(data):
	td = NoeBitStream(data)
	return 1


class vDriveFile: 
         
	def __init__(self, bs):
		self.bs = bs
		self.meshInfoList = []
		self.animInfoList = []
		self.texList      = []
		self.matList      = []
		self.boneList     = []
		self.boneDict     = {}

	def loadAll(self, bs):
		header = self.loadHeader(bs)
		for a in range(0, header.count):
			bs.seek(0x10 + (a * 4), NOESEEK_ABS)
			bs.seek(bs.readUInt(), NOESEEK_ABS)
			cHeader = self.vdChunkHeader(*((bs.tell(),) + bs.read("<3I2H")))
			#print(cHeader)
			if str(cHeader.type) in chunkLoaderDict:
				chunkLoaderDict[str(cHeader.type)](self, bs, cHeader)
		#for a in range(0, len(self.meshInfoList)):
		#print(len(self.meshInfoList))
		for a in range(0, len(self.meshInfoList)):
		#for a in range(0, 1):
			#print(self.meshInfoList[a], str(a))
			bs.seek(self.meshInfoList[a].base + 0x10, NOESEEK_ABS)
			vdMesh.loadMesh(self, bs, self.meshInfoList[a])
		try:
			mdl = rapi.rpgConstructModel()
		except:
			mdl = NoeModel()
		mdl.setModelMaterials(NoeModelMaterials(self.texList, self.matList))
		mdl.setBones(self.boneList)
		return mdl

	def loadHeader(self, bs):
		magic = bs.readBytes(4).decode("ascii")
		header = self.vdFileHeader(*((magic,) + bs.read("<2I2H")))
		print(header)
		return header
		
	def loadMeshNames(self, bs):
		pass

	# vd File Header
	vdFileHeader = collections.namedtuple('vdFileHeader', ' '.join((
		'magic', 'version', 'type', 'one', 'count')
		))
	# vd Chunk Header
	vdChunkHeader = collections.namedtuple('vdChunkHeader', ' '.join((
		'base', 'null', 'size', 'start', 'type', 'count')
		))	

class vdMaterial:
	def loadMaterial(self, bs, cHeader):
		#print(bs.tell())
		matFloat1 = bs.read("22I")
		matInfo = bs.read("2I8B")
		#print(matFloat1)
		#print(matInfo)
		bs.seek(cHeader.base + 0x10 + matInfo[0], NOESEEK_ABS)
		matName = bs.readString()
		material = NoeMaterial(matName, "")
		#print(matName)
		for a in range(0, matInfo[8]):
			texName = bs.readString()
			if a == 0:
				material.setTexture(texName)
			#print(texName)
		material.setFlags(noesis.NMATFLAG_TWOSIDED)
		self.matList.append(material)
		
class vdMesh:

	#All data is more of a best fit and does not quite work on all data
	def bindData(Format1,Format2,data,stride):
		offset=0
		types=0
		ecount=1
		esize=1
		#Position
		if(Format1& 3):
			if(Format2 & 0x40000):
				type = noesis.RPGEODATA_HALFFLOAT
				esize=2
			else:
				type = noesis.RPGEODATA_FLOAT
				esize=4
			if(Format1 & 1):
				ecount=3
			else:
				ecount=4
			rapi.rpgBindPositionBufferOfs(data,type,stride,offset)
			offset=offset+ecount*esize
		 #Normal
		if(Format1 & 0x20):
			if(Format2 & 0x80000):
				type = noesis.RPGEODATA_HALFFLOAT
				esize = 2
			elif(Format2 & 0x100000):
				type = noesis.RPGEODATA_BYTE
				esize=1
			else:
				type = noesis.RPGEODATA_FLOAT
				esize=4
			rapi.rpgBindNormalBufferOfs(data,type,stride,offset)
			offset=offset+4*esize
		elif(Format1 & 0x10):
			if(Format2 & 0x80000):
				rapi.rpgBindNormalBufferOfs(data,noesis.RPGEODATA_HALFFLOAT,stride,offset)
				offset=(offset + 9)&~3			
			elif(Format2 & 0x100000) :
				rapi.rpgBindNormalBufferOfs(data,noesis.RPGEODATA_BYTE,stride,offset)
				offset=(offset + 6)&~3

			else:
				rapi.rpgBindNormalBufferOfs(data, noesis.RPGEODATA_FLOAT,stride,offset)
				offset=(offset + 15)&~3
		#Tangnet
		if(Format1 & 0x200):
			if(Format2 & 0x80000):
				type = noesis.RPGEODATA_HALFFLOAT
				esize = 2
			elif(Format2 & 0x100000):
				type = noesis.RPGEODATA_BYTE
				esize=1
			else:
				type = noesis.RPGEODATA_FLOAT
				esize=4
			rapi.rpgBindTangentBuffer(data,type,stride,offset)
			offset=offset+4*esize
		elif(Format1 & 0x100):
			if(Format2 & 0x80000):
				offset=(offset + 9)&~3			
			elif(Format2 & 0x100000) :
				offset=(offset + 6)&~3
			else:
				offset=(offset + 15)&~3
		#Binormal
		if(Format1 & 0x800):
			if(Format2 & 0x80000):
				type = noesis.RPGEODATA_HALFFLOAT
				esize = 2
			elif(Format2 & 0x100000):
				type = noesis.RPGEODATA_BYTE
				esize=1
			else:
				type = noesis.RPGEODATA_FLOAT
				esize=4
			offset=offset+4*esize

		elif(Format1 & 0x400):
			if(Format2 & 0x80000):
				offset=(offset + 9)&~3			
			elif(Format2 & 0x100000) :
				offset=(offset + 6)&~3
			else:
				offset=(offset + 15)&~3
		#Whee this can only support 2 UVs

		if(Format2& 0x100):

			if(Format2 & 0x200000):
					
				rapi.rpgBindUV1BufferOfs(data,noesis.RPGEODATA_HALFFLOAT,stride,offset)
				rapi.rpgBindUV2BufferOfs(data,noesis.RPGEODATA_HALFFLOAT,stride,offset+4)
				offset=offset + 8
			else:
				rapi.rpgBindUV1BufferOfs(data,noesis.RPGEODATA_FLOAT,stride,offset)
				rapi.rpgBindUV2BufferOfs(data,noesis.RPGEODATA_FLOAT,stride,offset+4)
				offset=offset + 16
		elif(Format2 & 0x1):
			if(Format2 & 0x200000):
				esize=2
				type=noesis.RPGEODATA_HALFFLOAT
			else:
				type = noesis.RPGEODATA_FLOAT
				esize=4
			#rapi.rpgBindUV1BufferOfs(data,type,stride,offset)
			offset=offset+2*esize	


		if(Format2& 2):
			if(Format2 & 0x200000):
				esize=2
				type=noesis.RPGEODATA_HALFFLOAT
			else:
				type = noesis.RPGEODATA_FLOAT
				esize=4
			#rapi.rpgBindUV2BufferOfs(data,type,stride,offset)
			offset=offset+2*esize
		
		if(Format2& 4):
			if(Format2 & 0x200000):
				offset=offset + 4
			else:
				offset=offset + 8	
		if(Format2& 8):
			if(Format2 & 0x200000):
				offset=offset + 4
			else:
				offset=offset + 8
		#Color
		if(Format2&0x10000000):
			rapi.rpgBindColorBufferOfs(data, noesis.RPGEODATA_UBYTE, stride, offset, 4)
			offset=offset+4
		#Bone weights and indices
		if(Format2 & 0xF000000 ):
			bonecount=1
			if(Format2&0x400000 ):
				type=noesis.RPGEODATA_HALFFLOAT
				esize=2
			elif(Format2&0x800000):
				type=noesis.RPGEODATA_UBYTE
				esize=1
			else:
				type = noesis.RPGEODATA_FLOAT
				esize=4
			if(Format2 & 0x2000000):
				bonecount=2
			if(Format2 & 0x4000000):
				bonecount=3
			if(Format2 & 0x8000000):
				bonecount=4
			rapi.rpgBindBoneWeightBufferOfs(data,type,stride,offset,bonecount)
			offset=offset+(esize*bonecount)
			offset=(offset+3)&~3
			rapi.rpgBindBoneIndexBufferOfs(data, noesis.RPGEODATA_UBYTE, stride, offset, bonecount)
			offset=(offset+bonecount+3)&~3

			
	def calcStride(Format1,Format2):
		stride=0
		#position
		if(Format1& 1):
			if(Format2 & 0x40000):
				stride=stride + 6
			else:
				stride=stride + 12
		elif(Format1  & 2):
			if(Format2 & 0x40000):
				stride=stride + 8
			else:
				stride=stride + 16
		#Normals
		if(Format1 & 0x10):
			if(Format2 & 0x80000):
				stride=(stride + 9)&~3
			elif(Format2 & 0x100000) :
				stride=(stride + 6)&~3
			else:
				stride=(stride + 15)&~3
		elif(Format1 & 0x20):
			if(Format2 & 0x80000):
				stride=(stride + 8)
			elif(Format2 & 0x100000):
				stride=(stride + 4)
			else:
				stride=(stride + 16)
		#Tangnet
		if(Format1 & 0x100):
			if(Format2 & 0x80000):
				stride=(stride + 9)&~3
			elif(Format2 & 0x100000) :
				stride=(stride + 6)&~3
			else:
				stride=(stride + 15)&~3
		elif(Format1 & 0x200):
			if(Format2 & 0x80000):
				stride=(stride + 8)
			elif(Format2 & 0x100000):
				stride=(stride + 4)
			else:
				stride=(stride + 16)
		#Binormal
		if(Format1 & 0x400):
			if(Format2 & 0x80000):
				stride=(stride + 9)&~3
			elif(Format2 & 0x100000) :
				stride=(stride + 6)&~3
			else:
				stride=(stride + 15)&~3
		elif(Format1 & 0x800):
			if(Format2 & 0x80000):
				stride=(stride + 8)
			elif(Format2 & 0x100000):
				stride=(stride + 4)
			else:
				stride=(stride + 16)

		#UV1
		if(Format2 & 0x100):
			if(Format2 & 0x200000):
				stride=stride + 8
			else:
				stride=stride + 16
		elif(Format2 & 0x1):
			if(Format2 & 0x200000):
				stride=stride + 4
			else:
				stride=stride + 8
#UV2
		if(Format2 & 0x200):
			if(Format2 & 0x200000):
				stride=stride + 8
			else:
				stride=stride + 16
		elif(Format2 & 0x2):
			if(Format2 & 0x200000):
				stride=stride + 4
			else:
				stride=stride + 8
#UV3
		if(Format2& 4):
			if(Format2 & 0x200000):
				stride=stride + 4
			else:
				stride=stride + 8
		elif(Format2 & 0x400):
			if(Format2 & 0x200000):
				stride=stride + 8
			else:
				stride=stride + 16		
#UV4
		if(Format2& 8):
			if(Format2 & 0x200000):
				stride=stride + 4
			else:
				stride=stride + 8
		elif(Format2 & 0x800):
			if(Format2 & 0x200000):
				stride=stride + 8
			else:
				stride=stride + 16
	#Color
		if(Format2&0x10000000):
			stride=stride+4
	#Bone weights & indices
		if(Format2 & 0x1000000 ):
			if(Format2&0x400000 ):
				stride=stride+2
			elif(Format2&0x800000):
				stride=stride+1
			else:
				stride=stride+4
			stride=(stride+3)&~3
			stride=(stride+4)&~3
		elif(Format2 & 0x2000000 ):
			if(Format2&0x400000 ):
				stride=stride+4
			elif(Format2&0x800000):
				stride=stride+2
			else:
				stride=stride+8
			stride=(stride+3)&~3
			stride=(stride+5)&~3
		elif(Format2 & 0x4000000 ):
			if(Format2&0x400000 ):
				stride=stride+6
			elif(Format2&0x800000):
				stride=stride+3
			else:
				stride=stride+12
			stride=(stride+3)&~3
			stride=(stride+6)&~3
		elif(Format2 & 0x8000000 ):
			if(Format2&0x400000 ):
				stride=stride+8
			elif(Format2&0x800000):
				stride=stride+4
			else:
				stride=stride+16
			stride=(stride+4)

		return stride
	def chunk_str(str, chunk_size):
		return [str[i:i+chunk_size] for i in range(0, len(str), chunk_size)]
		
	def saveChunk(self, bs, cHeader):
		self.meshInfoList.append(cHeader)
	
	def loadMesh(self, bs, cHeader):
		#print(bs.tell())
		meshFloat1 = bs.read("14I")
		meshInfo = bs.read("2HI3h")
		#print(meshFloat1)
		#print(meshInfo)
		bs.seek(cHeader.base + 0x60, NOESEEK_ABS)
		meshName = bs.readString()
		print(meshName)
		rapi.rpgSetName(meshName)

		bs.seek(cHeader.base + 0x10 + meshInfo[2], NOESEEK_ABS)
		vInfo = []
		fInfo = []
		bInfo = []
		topology = [noesis.RPGEO_POINTS,noesis.RPGEO_NONE,noesis.RPGEO_NONE,noesis.RPGEO_TRIANGLE,noesis.RPGEO_TRIANGLE_STRIP]
		meshControl_1= 0
		meshControl_2= 0
		get_bin = lambda x, n: format(x, 'b').zfill(n)
		for a in range(0, meshInfo[0]):
			meshBase = bs.tell()
			meshFvf = bs.read(">Q")[0]
			bs.seek(meshBase, NOESEEK_ABS)
			meshControl_1=bs.readInt();
			meshControl_2=bs.readInt();
			#bs.seek(meshBase, NOESEEK_ABS)
			#print(bs.read("8B"))
			#print(get_bin(meshFvf, 64))
			#print(vdMesh.chunk_str(str(get_bin(meshFvf, 64)),4))
			vCount, vStart = bs.read("2I")
			vInfo.append([vCount, vStart, meshBase, vdMesh.chunk_str(str(get_bin(meshFvf, 64)),4)])
		for a in range(0, meshInfo[1]):
			faceBase = bs.tell()
			fCount, fStart = bs.read("2i")
			matID, fInfo2, fInfo3,topID, fInfo4 = bs.read("2HBBH")
			fInfo.append([fCount, fStart, faceBase, matID, fInfo2])
		for a in range(0, meshInfo[0]):
			bListBase = bs.tell()
			bListOff, bListCount = bs.read("2i")
			bInfo.append([bListBase, bListOff, bListCount])
		for a in range(0, meshInfo[0]):
			#print("Testing mesh " + str(a))
			tStride = vdMesh.calcStride(meshControl_1,meshControl_2)
			#rapi.rpgSetMaterial(self.matList[fInfo[a][4]].name)
			bs.seek(bInfo[a][0] + bInfo[a][1], NOESEEK_ABS)
			boneMap = bs.read(bInfo[a][2] * "H")
			rapi.rpgSetBoneMap(None)
			if len(boneMap) > 0:
				rapi.rpgSetBoneMap(boneMap)
			if a > 0:
				rapi.rpgSetName(meshName + "_" + str(a))
			bs.seek(vInfo[a][2] + vInfo[a][1], NOESEEK_ABS)
			vBuff = bs.readBytes(tStride * vInfo[a][0])
			vdMesh.bindData(meshControl_1,meshControl_2,vBuff,tStride)
			bs.seek(fInfo[a][2] + fInfo[a][1], NOESEEK_ABS)
			fBuff = bs.readBytes(2 * fInfo[a][0])
			#print(tStride) 
			rapi.rpgCommitTriangles(fBuff, noesis.RPGEODATA_USHORT, fInfo[a][0], topology[topID+3], 1)
			'''
			if vInfo[a][3][1] == '0010':
				print("4 float vertex")
				vpos = tStride
				tStride += 16
			if vInfo[a][3][1] == '0110':
				print("4 halffloat vertex")
				vpos = tStride
				tStride += 8
			if vInfo[a][3][13] == '0100':
				print("2nd Normals Present?")
				n2pos = tStride
				tStride += 6
			if vInfo[a][3][3] == '0101':
				print("2nd Normals Present?")
				n3pos = tStride
				tStride += 6
			if vInfo[a][3][0] == '0001':
				print("Normals Present")
				npos = tStride
				tStride += 3
			if vInfo[a][3][9] == '0001':
				print("UV1 Present")
				uvpos = tStride
				tStride += 4
			if vInfo[a][3][11] == '0001':
				print("UV2 Present")
				uv2pos = tStride
				tStride += 4
				
			#print("Mesh has 4 byte vertex colors")
			vColorPos = tStride
			tStride += 4
			bwPos = tStride
			#print("mesh has ", weightDict[vInfo[a][3][15]], "Weights per vertex")
			tStride += weightDict[vInfo[a][3][15]]
			biPos = tStride
			tStride += weightDict[vInfo[a][3][15]]
			print("the stride should be ", tStride, (tStride + 3) & ~3)
			tStride = (tStride + 3) & ~3
			#rapi.rpgSetName(meshName + "Lod_" + str(a))
			rapi.rpgSetMaterial(self.matList[fInfo[a][4]].name)
			bs.seek(bInfo[a][0] + bInfo[a][1], NOESEEK_ABS)
			boneMap = bs.read(bInfo[a][2] * "H")
			rapi.rpgSetBoneMap(None)
			if len(boneMap) > 0:
				rapi.rpgSetBoneMap(boneMap)
			if a > 0:
				rapi.rpgSetName(meshName + "_" + str(a))
			if fInfo[a][1] != -1:
				#print(vInfo[a][0:3])
				#print(fInfo[a])
				vStride = (((fInfo[a][1] + fInfo[a][2]) - (vInfo[a][1] + vInfo[a][2])) // vInfo[a][0]) & ~3
				#print(vStride)
				bs.seek(vInfo[a][2] + vInfo[a][1], NOESEEK_ABS)
				vBuff = bs.readBytes(tStride * vInfo[a][0])
				rapi.rpgBindPositionBufferOfs(vBuff, noesis.RPGEODATA_FLOAT, tStride, vpos)
				if vInfo[a][3][0] == '0001':
					rapi.rpgBindNormalBufferOfs(vBuff, noesis.RPGEODATA_BYTE, tStride, npos)
				rapi.rpgBindUV1BufferOfs(vBuff, noesis.RPGEODATA_HALFFLOAT, tStride, uvpos)
				rapi.rpgBindColorBufferOfs(vBuff, noesis.RPGEODATA_UBYTE, tStride, vColorPos, 4)
				if vInfo[a][3][15] != '0000':
					rapi.rpgBindBoneIndexBufferOfs(vBuff, noesis.RPGEODATA_UBYTE, tStride, biPos, weightDict[vInfo[a][3][15]])
					rapi.rpgBindBoneWeightBufferOfs(vBuff, noesis.RPGEODATA_UBYTE, tStride, bwPos, weightDict[vInfo[a][3][15]])
				bs.seek(fInfo[a][2] + fInfo[a][1], NOESEEK_ABS)
				fBuff = bs.readBytes(2 * fInfo[a][0])
				rapi.rpgCommitTriangles(fBuff, noesis.RPGEODATA_USHORT, fInfo[a][0], noesis.RPGEO_TRIANGLE, 1)
			else:
				#print(vInfo[a][0:3])
				if a == (meshInfo[0] - 1):
					vStride = (((cHeader.base + cHeader.size + (0x10 * (a + 1))) - (vInfo[a][2] + vInfo[a][1])) // vInfo[a][0]) & ~3
				else:
					vStride = ((vInfo[a + 1][1] - vInfo[a][1] + (0x10 * (a + 1))) // vInfo[a][0]) & ~3
				#print(vStride)
				bs.seek(vInfo[a][2] + vInfo[a][1], NOESEEK_ABS)
				vBuff = bs.readBytes(tStride * vInfo[a][0])
				rapi.rpgBindPositionBufferOfs(vBuff, noesis.RPGEODATA_HALFFLOAT, tStride, vpos)
				rapi.rpgBindUV1BufferOfs(vBuff, noesis.RPGEODATA_HALFFLOAT, tStride, uvpos)
				rapi.rpgBindColorBufferOfs(vBuff, noesis.RPGEODATA_UBYTE, tStride, vColorPos, 4)
				if vInfo[a][3][15] != '0000':
					rapi.rpgBindBoneIndexBufferOfs(vBuff, noesis.RPGEODATA_UBYTE, tStride, biPos, weightDict[vInfo[a][3][15]])
					rapi.rpgBindBoneWeightBufferOfs(vBuff, noesis.RPGEODATA_UBYTE, tStride, bwPos, weightDict[vInfo[a][3][15]])
				if vInfo[a][3][0] == '0001':
					rapi.rpgBindNormalBufferOfs(vBuff, noesis.RPGEODATA_BYTE, tStride, npos)
				rapi.rpgCommitTriangles(None, noesis.RPGEODATA_USHORT, vInfo[a][0], noesis.RPGEO_TRIANGLE, 1)
				'''
			rapi.rpgClearBufferBinds()

class gxtFile:

	def loadGXT(self, bs, cHeader):
		bs.seek(cHeader.base + 0x28, NOESEEK_ABS)
		texName = bs.readString()
		bs.seek(cHeader.base + cHeader.start, NOESEEK_ABS)
		type = bs.readInt()
		bs.seek(cHeader.base + cHeader.start, NOESEEK_ABS)
		print(texName)

		if(type!=5527623):
			bs.seek(cHeader.base + 20, NOESEEK_ABS)
			width=bs.readShort()
			bs.seek(cHeader.base + 22, NOESEEK_ABS)
			height=bs.readShort()
			bs.seek(cHeader.base + cHeader.start, NOESEEK_ABS)
			texData = bs.readBytes(cHeader.size)
			bs.seek(cHeader.base + 16, NOESEEK_ABS)
			ifrmt=bs.readInt()
			if(ifrmt==8):
				texData=rapi.imageDecodeDXT(texData,width,height,noesis.FOURCC_DXT1)
				tex1 = NoeTexture(texName, width, height, texData, noesis.NOESISTEX_RGBA32)
				self.texList.append(tex1)
			if(ifrmt==10):
				texData=rapi.imageDecodeDXT(texData,width,height,noesis.FOURCC_DXT5)
				tex1 = NoeTexture(texName, width, height, texData, noesis.NOESISTEX_RGBA32)
				self.texList.append(tex1)
		

		if(type==5527623):
			header = gxtFile.GXTHeader(*( \
			(noeStrFromBytes(bs.readBytes(4)),) \
			+ bs.read("7I")))
			texInfo = bs.read("5i4B2HI")

			texData = bs.readBytes(texInfo[1])
			
			texFmt = 0
			specData = b''
			if texInfo[8] == 0x80:
				#PVRT2BPP
				texFmt = noesis.NOESISTEX_RGBA32
				texData = rapi.imageDecodePVRTC(texData, texInfo[9], texInfo[10], 2, noesis.PVRTC_DECODE_PVRTC2)
			elif texInfo[8] == 0x81:
				#PVRT4BPP
				texFmt = noesis.NOESISTEX_RGBA32
				texData = rapi.imageDecodePVRTC(texData, texInfo[9], texInfo[10], 4, noesis.PVRTC_DECODE_PVRTC2)
			elif texInfo[8] == 0x82:
				#PVRTII2BPP
				texFmt = noesis.NOESISTEX_RGBA32
				texData = rapi.imageDecodePVRTC(texData, texInfo[9], texInfo[10], 2, noesis.PVRTC_DECODE_PVRTC2)
			elif texInfo[8] == 0x83:
				#PVRTII4BPP
				texFmt = noesis.NOESISTEX_RGBA32
				texData = rapi.imageDecodePVRTC(texData, texInfo[9], texInfo[10], 4, noesis.PVRTC_DECODE_PVRTC2)
				texData = rapi.imageDecodeRaw(texData, texInfo[9], texInfo[10], "b8g8r8a8")
			elif texInfo[8] == 0xC:
				#texFmt = noesis.NOESISTEX_DXT1
				texFmt = noesis.NOESISTEX_RGBA32
				#texData = rapi.imageFromMortonOrder(texData, texInfo[9], texInfo[10])
				texData = rapi.imageFromMortonOrder(texData, texInfo[9], texInfo[10], 32 // 8, 2)
				texData = rapi.imageDecodeRaw(texData, texInfo[9], texInfo[10], "b8g8r8a8")
			elif texInfo[8] == 0x0:
				texFmt = noesis.NOESISTEX_RGBA32
				#texData = rapi.imageFromMortonOrder(texData, texInfo[9], texInfo[10])
				texData = rapi.imageFromMortonOrder(texData, texInfo[9]>>1, texInfo[10]>>2, 4)
				texData = rapi.imageDecodeRaw(texData, texInfo[9], texInfo[10], "b8g8r8a8")
			elif texInfo[8] == 0x85:
				#texFmt = noesis.NOESISTEX_DXT1
				texFmt = noesis.NOESISTEX_RGBA32
				texData = rapi.imageFromMortonOrder(texData, texInfo[9]>>1, texInfo[10]>>2, 4)
				texData = rapi.imageDecodeDXT(texData, texInfo[9], texInfo[10], noesis.FOURCC_DXT1)
				texData = rapi.imageDecodeRaw(texData, texInfo[9], texInfo[10], "r8g8b8a8")
				#specData = rapi.imageEncodeRaw(texData, texInfo[9], texInfo[10], "p24r8")
				texData = rapi.imageDecodeRaw(texData, texInfo[9], texInfo[10], "r8g8b8p8")
			elif texInfo[8] == 0x86:
				#texFmt = noesis.NOESISTEX_DXT3
				texFmt = noesis.NOESISTEX_RGBA32
				texData = rapi.imageFromMortonOrder(texData, texInfo[9]>>1, texInfo[10]>>2, 8)
				texData = rapi.imageDecodeDXT(texData, texInfo[9], texInfo[10], noesis.FOURCC_DXT3)
				texData = rapi.imageDecodeRaw(texData, texInfo[9], texInfo[10], "r8g8b8a8")
				#specData = rapi.imageEncodeRaw(texData, texInfo[9], texInfo[10], "p24r8")
				texData = rapi.imageDecodeRaw(texData, texInfo[9], texInfo[10], "r8g8b8p8")
			elif texInfo[8] == 0x87:
				#texFmt = noesis.NOESISTEX_DXT5
				texFmt = noesis.NOESISTEX_RGBA32
				texData = rapi.imageFromMortonOrder(texData, texInfo[9]>>1, texInfo[10]>>2, 8)
				texData = rapi.imageDecodeDXT(texData, texInfo[9], texInfo[10], noesis.FOURCC_DXT5)
				texData = rapi.imageDecodeRaw(texData, texInfo[9], texInfo[10], "r8g8b8a8")
				specData = rapi.imageEncodeRaw(texData, texInfo[9], texInfo[10], "p24r8")
				texData = rapi.imageDecodeRaw(texData, texInfo[9], texInfo[10], "r8g8b8p8")
			elif texInfo[8] == 0x8B:
				texFmt = noesis.NOESISTEX_RGBA32
				texData = rapi.imageFromMortonOrder(texData, texInfo[9]>>1, texInfo[10]>>2, 8)
				#texData = rapi.imageDecodeDXT(texData, texInfo[9], texInfo[10], noesis.FOURCC_ATI2)
				#texData = rapi.swapEndianArray(texData, 2)
				#texData = rapi.imageDecodePVRTC(texData, texInfo[9], texInfo[10], 4, noesis.PVRTC_DECODE_PVRTC2)
				texData = rapi.imageDecodeRaw(texData, texInfo[9], texInfo[10], "b8g8r8a8")
			elif texInfo[8] == 0x95:
				texFmt = noesis.NOESISTEX_RGBA32
				texData = rapi.imageFromMortonOrder(texData, texInfo[9]>>1, texInfo[10]>>2, 8)
				texData = rapi.imageDecodeRaw(texData, texInfo[9], texInfo[10], "r8g8b8a8")
			elif texInfo[8] == 0x98:
				texFmt = noesis.NOESISTEX_RGBA32
				texData = rapi.imageFromMortonOrder(texData, texInfo[9], texInfo[10], 24 // 8, 2)
				texData = rapi.imageDecodeRaw(texData, texInfo[9], texInfo[10], "b8g8r8")
			#tex1 = NoeTexture(str(texInfo[8]), texInfo[9], texInfo[10], texData, texFmt)
			tex1 = NoeTexture(texName, texInfo[9], texInfo[10], texData, texFmt)
			#print(tex1)
			if texFmt == 0:
				print("ERROR NOT FOUND")
			for a in range(0, len(self.texList)):
				if self.texList[a].name == texName:
					tex1.name = texName + str(len(self.texList))
				
			self.texList.append(tex1)
			if specData != b'':
				self.texList.append(NoeTexture(tex1.name + "_Spec", texInfo[9], texInfo[10], specData, texFmt))
		
		
	# GXT Header
	GXTHeader = collections.namedtuple('GXTHeader', ' '.join((
		'magic',
		'version',
		'texCount',
		'texDataOff',
		'texDataSize',
		'P4Pallet',
		'P8Pallet',
		'pad0'
	)))
class Object(object):
    pass

def vDriveLoadAnim(data, mdlList):
	ctx = rapi.rpgCreateContext()
	otherNifData = rapi.loadPairedFile("VD MAB Model", ".msb")
	vDrive = vDriveFile(NoeBitStream(otherNifData))
	mdl = vDrive.loadAll(vDrive.bs)
	bs = NoeBitStream(data)
	boneList = mdl.bones
	bIdDict = {}
	for i in range(0, len(boneList)):
		bIdDict[boneList[i].name] = i
	sampleRate = 20.0
	kfBones = []
	test = Object()
	test.a = [0]
	test.b = [1]
	test.c = [2]
	print("Hello")
	print(test.a,test.b,test.c)
	kfBoneDict = {}
	print(bs.tell())
	magic = bs.readBytes(4).decode("ascii")
	header = vDriveFile.vdFileHeader(*((magic,) + bs.read("<2I2H")))
	bs.seek(bs.readUInt(), NOESEEK_ABS)
	cHeader = vDriveFile.vdChunkHeader(*((bs.tell(),) + bs.read("<3I2H")))
	print(cHeader)	
	print(boneList[11])
	print(noeSafeGet(boneList[11], "name"))
	#print(cHeader)
	animHeader = bs.read("5i")
	#print(animHeader)
	aCount = bs.readUInt() - 0x14
	bs.seek(cHeader.base + cHeader.start + 0x14, NOESEEK_ABS)
	aOffStart = bs.read((aCount // 4) * "i")
	kfAnims = []
	for a in range(0, len(aOffStart)):
		bs.seek(cHeader.base + cHeader.start + aOffStart[a], NOESEEK_ABS)
		cAnimPos = bs.tell()
		animInfo = bs.read("4i")
		bs.seek(cAnimPos + animInfo[3], NOESEEK_ABS)
		bName = bs.readString()
		#print(bName)
		if bName in bIdDict:
			if bName in kfBoneDict:
				pass
			else:
				kfBoneDict[bName] = NoeKeyFramedBone(bIdDict[bName])
			if bName in kfBoneDict:
				if animInfo[1] == 0:
					kfTran = []
					bs.seek(cAnimPos + 16, NOESEEK_ABS)
					kfTime = bs.read(animInfo[0] * "i")
					for b in range(0, animInfo[0]):
						posX, posY, posZ = bs.read("3f")
						kfTran.append(NoeKeyFramedValue(kfTime[b] / 10.0, ([posX, posY, posZ])))
						#print([posX, posY, posZ])
					kfBoneDict[bName].setTranslation(kfTran, noesis.NOEKF_TRANSLATION_VECTOR_3, noesis.NOEKF_INTERPOLATE_LINEAR)
					#print(kfTran)
				if animInfo[1] == 1:
					kfRot = []
					bs.seek(cAnimPos + 16, NOESEEK_ABS)
					kfTime = bs.read(animInfo[0] * "i")
					for b in range(0, animInfo[0]):
						rot = bs.read("4f")
						kfRot.append(NoeKeyFramedValue(kfTime[b] / 10.0, NoeQuat(rot).transpose()))
						#print(rot)
					kfBoneDict[bName].setRotation(kfRot, noesis.NOEKF_ROTATION_QUATERNION_4, noesis.NOEKF_INTERPOLATE_LINEAR)
					#print(kfTran)
				if animInfo[1] == 2:
					kfTran = []
					bs.seek(cAnimPos + 16, NOESEEK_ABS)
					kfTime = bs.read(animInfo[0] * "i")
					for b in range(0, animInfo[0]):
						posX, posY, posZ = bs.read("3f")
						kfTran.append(NoeKeyFramedValue(kfTime[b] / 10.0, ([posX, posY, posZ])))
						#print([posX, posY, posZ])
					kfBoneDict[bName].setTranslation([], noesis.NOEKF_TRANSLATION_VECTOR_3, noesis.NOEKF_INTERPOLATE_LINEAR)
					#print(kfTran)
		print(bName)
		print(animInfo)
	#print(kfBoneDict)
	for kfBone in kfBoneDict:
		kfBones.append(kfBoneDict[kfBone])
	#kfBone = NoeKeyFramedBone(11)
	#kfBone.setTranslation([NoeKeyFramedValue(0.0, (0.0, 20.0, 0.0)), NoeKeyFramedValue(1.0, (0.0, 40.0, 0.0))], noesis.NOEKF_TRANSLATION_VECTOR_3, noesis.NOEKF_INTERPOLATE_LINEAR)
	#kfBones.append(kfBone)
	kfAnims.append(NoeKeyFramedAnim("Test", mdl.bones, kfBones, sampleRate))
	mdl.setAnims(kfAnims)
	mdlList.append(mdl)
	return 1


		
class vdBone:
	
	def loadBone(self, bs, cHeader):
		print(bs.tell())
		for a in range(0, cHeader.count):
			bs.seek(cHeader.base + cHeader.start + (0x70 * a), NOESEEK_ABS)
			boneBase = bs.tell()
			boneMtx             = NoeMat44.fromBytes(bs.readBytes(64)).toMat43().inverse()
			BoneQuat            = NoeQuat.fromBytes(bs.readBytes(16))
			BoneQuat2           = NoeQuat.fromBytes(bs.readBytes(16))
			boneNameOff, boneParent = bs.read("Ih")
			boneType = bs.read("4B")
			if boneType[3] == 0:
				boneParent = -1
			bs.seek(boneBase + boneNameOff, NOESEEK_ABS)
			boneName = bs.readString()
			newBone = NoeBone(a, boneName, boneMtx, None, boneParent)
			self.boneDict[boneName] = a
			self.boneList.append(newBone)
	
chunkLoaderDict = {
	"0"			    : vdMesh.saveChunk,
	"1"			    : gxtFile.loadGXT,
#	"2"			    : mabFile.loadAdnim,
	"3"			    : vdMaterial.loadMaterial,
	"4"			    : vdBone.loadBone
	}

weightDict = {
	"0000"			    : 0,
	"0001"			    : 1,
	"0010"			    : 2,
	"0100"			    : 3,
	"1000"			    : 4
	}


def vDriveLoadModel(data, mdlList):
	ctx = rapi.rpgCreateContext()
	vDrive = vDriveFile(NoeBitStream(data))
	mdl = vDrive.loadAll(vDrive.bs)
	if mdl is not None:
		mdlList.append(mdl)
		return 1
	return 0