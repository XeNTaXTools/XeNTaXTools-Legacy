#by Durik256 for xentax.com 21.01.2022
#unpack .art from CrazyTaxi
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Crazy Taxi 3", ".art")
    noesis.setHandlerExtractArc(handle, spExtractArc)
    return 1

def spExtractArc(fileName, fileLen, justChecking):
    if fileLen < 16:
        return 0
        
    if justChecking: #it's valid
            return 1

    f = open(fileName, "rb")
    data = NoeFileStream(f)

    count = data.readUInt()
    offset = [data.readUInt() for x in range(count)]
    
    for i,img in enumerate(offset):
        name = "img_"+str(i)+".xgt"
        data.seek(img+8, NOESEEK_ABS)
        size_img = data.readUInt()+16
        data.seek(-12, NOESEEK_REL)
        export_data = data.readBytes(size_img)
        rapi.exportArchiveFile(name, export_data)
        print("export", name)

    print("Extracting", count, "files.")
    return 1