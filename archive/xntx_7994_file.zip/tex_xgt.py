from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Crazy Taxy 3", ".xgt")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    if noeStrFromBytes(bs.readBytes(4)) != "GXTX": return 0
    return 1
    
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.seek(0x4)

    imgWidth = bs.readUShort()
    imgHeight = bs.readUShort()
    datasize = bs.readUInt()
    unk = bs.readUShort()
    imgFmt = bs.readUShort()
    data = bs.readBytes(datasize) 
    
    print("imgFmt",imgFmt)
    #PVRTC
    if imgFmt == 0:    
        data = rapi.imageDecodePVRTC(data, imgWidth, imgHeight, 16)
        texFmt = noesis.NOESISTEX_RGBA32
    #unk
    elif imgFmt == 1:    
        data = rapi.imageDecodePVRTC(data, imgWidth, imgHeight, 16)
        texFmt = noesis.NOESISTEX_RGBA32
    #unk
    elif imgFmt == 4:    
        data = rapi.imageDecodePVRTC(data, imgWidth, imgHeight, 16)
        texFmt = noesis.NOESISTEX_RGBA32
    #unk
    elif imgFmt == 5:    
        data = rapi.imageDecodePVRTC(data, imgWidth, imgHeight, 16)
        texFmt = noesis.NOESISTEX_RGBA32
    #DXT3
    elif imgFmt == 11 or imgFmt == 3:
        texFmt = noesis.NOESISTEX_DXT3
    #DXT1
    elif imgFmt == 10:
        texFmt = noesis.NOESISTEX_DXT1
        
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1