# EA Los Angeles (PS2) ssh images Loader by Bigchillghost
from inc_noesis import *

gIsTwiddled = True # set this variable to True if the image looks wrong

def registerNoesisTypes():
	handle = noesis.register("Golde Eye Rogue Agent (PS2)", ".ssh")
	noesis.setHandlerTypeCheck(handle, sshCheckType)
	noesis.setHandlerLoadRGBA(handle, sshLoadImage)
	#noesis.logPopup()
	return 1

def sshCheckType(data):
	bs = NoeBitStream(data)
	Magic = bs.readUInt()
	if Magic != 0x53504853:
		return 0
	return 1

def sshLoadImage(data, texList):
	bs = NoeBitStream(data)
	bs.seek(8, NOESEEK_ABS)
	imageCnt = bs.readUInt()
	bs.seek(4, NOESEEK_REL)
	addressList = [0]*imageCnt
	for i in range(0, imageCnt):
		bs.seek(4, NOESEEK_REL)
		addressList[i] = bs.readUInt()
	baseName = rapi.getInputName().split('\\')[-1].split('.')[0]
	for i in range(0, imageCnt):
		bs.seek(addressList[i], NOESEEK_ABS)
		pixelTotalSize = bs.readUInt()
		bytePerPixel = (pixelTotalSize & 0xFF) - 1
		imgWidth = bs.readUShort()
		imgHeight = bs.readUShort()
		bs.seek(8, NOESEEK_REL)
		bitPerPixel = 8
		if bytePerPixel == 0:
			pixelSize = imgWidth*imgHeight // 2
			bitPerPixel = 4
		else:
			pixelSize = imgWidth*imgHeight*bytePerPixel
		pixelData = bs.readBytes(pixelSize)
		alignedSize = (pixelSize + 15) // 16 * 16
		bs.seek(alignedSize + addressList[i] + 0x10, NOESEEK_ABS)
		if bytePerPixel <= 1:
			paletteTotalSize = bs.readUInt()
			bytePerPalettePixel = (paletteTotalSize & 0xFF - 1) // 8
			paletteWidth = bs.readUShort()
			paletteHeight = bs.readUShort()
			bs.seek(8, NOESEEK_REL)
			paletteSize = paletteWidth*paletteHeight*bytePerPalettePixel
			paletteData = bs.readBytes(paletteSize)
			if bytePerPalettePixel == 4:
				if gIsTwiddled:
					pixelData = rapi.imageUntwiddlePS2(pixelData, imgWidth, imgHeight, bitPerPixel)
				pixelData = rapi.imageDecodeRawPal(pixelData, paletteData, imgWidth, imgHeight, bitPerPixel, "r8 g8 b8 a8", noesis.DECODEFLAG_PS2SHIFT)
			else:
				print("unsupported bytePerPalettePixel:%d"%bytePerPalettePixel)
				return 0
		elif bytePerPixel == 3:
			pixelData = rapi.imageDecodeRaw(pixelData, imgWidth, imgHeight, "r8 g8 b8")
		elif bytePerPixel != 4:
			print("unsupported bytePerPixel:%d"%bytePerPixel)
			return 0
		texFmt = noesis.NOESISTEX_RGBA32
		texName = "%s_%d" % (baseName,i)
		texList.append(NoeTexture(texName, imgWidth, imgHeight, pixelData, texFmt))
	return 1
