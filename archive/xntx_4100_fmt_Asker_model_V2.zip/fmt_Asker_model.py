#Asker Online Import Script
from inc_noesis import *
from bs4 import BeautifulSoup


def registerNoesisTypes():
	handle = noesis.register("Asker Online", ".model")
	noesis.setHandlerTypeCheck(handle, askermodCheckType)
	noesis.setHandlerLoadModel(handle, askermodLoadModel)

	#noesis.logPopup()

	return 1


def askermodCheckType(data):
	bs = NoeBitStream(data)
	idMagic = bs.readUInt()
	if idMagic == 0x4E494256:
		return 1
	return 0



class askerFile: 
         
	def __init__(self, bs):
		self.bs = bs
		self.texList    = []
		self.matList    = []
		self.meshList   = []
		self.boneList   = []
		self.offsetList = []
		self.meshInfo   = []
		self.hsmvInfo   = []
		self.weightBuff = 0

	def loadAll(self, bs):
		chunkCheck = 0
		VBIN = noeStrFromBytes(bs.readBytes(4))
		fileVersion = bs.readInt()
		while chunkCheck == 0:
			self.chunkCheck = bs.readInt()
			if self.chunkCheck == -1:
				break
			chunkType = noeStrFromBytes(bs.readBytes(4))
			chunkSize = bs.readUInt()
			chunkStart = bs.tell()
			bs.seek(chunkSize, NOESEEK_REL)
			chunkEnd, ChunkClose = bs.readUInt(), bs.readUInt()
			self.offsetList.append([chunkType, chunkStart, chunkSize])
		for i in range(0, len(self.offsetList)):
			#print(self.offsetList[i])
			if self.offsetList[i][0] in askerObjectLoaderDict:
				self.CurrentChunk = self.offsetList[i]
				askerObjectLoaderDict[self.offsetList[i][0]](self, bs)
			else:
				print("Unkown Chunk Found")
		self.buildModel(bs)

		
	def loadHSMV(self, bs):
		#print(self.CurrentChunk)
		bs.seek(self.CurrentChunk[1], NOESEEK_ABS)
		hsmvHeader = bs.read("6iH")
		fvfInfo = bs.read("12B")
		bs.seek(0x26, NOESEEK_REL)
		#print("Version " + str(hsmvHeader[3]))
		vertCount = bs.readUInt()
		bs.seek(5, NOESEEK_REL)
		if hsmvHeader[3] == 5:
			bs.seek(4, NOESEEK_REL)
		faceCount, unk1, unk2 = bs.readUInt(), bs.readUInt(), bs.readUInt()
		bs.seek(11, NOESEEK_REL)
		if hsmvHeader[3] == 5:
			bs.seek(2, NOESEEK_REL)
		#print(bs.tell())
		vertStart = bs.tell()
		bs.seek(hsmvHeader[6] * vertCount, NOESEEK_REL)
		#print(bs.tell())
		faceStart = bs.tell()
		self.hsmvInfo.append([hsmvHeader[6], vertStart, vertCount, faceStart, faceCount, fvfInfo])
		#print(self.hsmvInfo[0])

	def loadSRTM(self, bs):
		#print(self.CurrentChunk)
		bs.seek(self.CurrentChunk[1], NOESEEK_ABS)
		materialCount = bs.readUInt()

		for i in range(0, materialCount):
			subChnkFlag, LRTM, subChunkSize = bs.read("3I")
			subChnkStart = bs.tell()
			#print(subChnkStart)
			matVersion, meshNameSize = bs.readUShort(), bs.readUInt()
			meshName = noeStrFromBytes(bs.readBytes(meshNameSize))
			#print(matName)
			if matVersion == 2:
				bs.seek(0x12, NOESEEK_REL)
			if matVersion == 3:
				bs.seek(0x16, NOESEEK_REL)
			if matVersion == 4:
				bs.seek(0x1A, NOESEEK_REL)
			if matVersion == 5:
				bs.seek(0x1E, NOESEEK_REL)
			if matVersion == 6:
				bs.seek(0x1E, NOESEEK_REL)
			if matVersion == 8:
				bs.seek(0x22, NOESEEK_REL)
			dnNameSize = bs.readUInt()
			dnName = bs.readBytes(dnNameSize).decode("cp949")
			ssNameSize = bs.readUInt()
			ssName = bs.readBytes(ssNameSize).decode("cp949")
			noNameSize = bs.readUInt()
			noName = bs.readBytes(noNameSize).decode("cp949")
			bs.seek((subChnkStart + subChunkSize + 8), NOESEEK_ABS)
			#print(matName)
			#print([dnName, ssName, noName])
			self.meshList.append(meshName)


		matFileName = rapi.getInputName() + "_data\materials.xml"
		if (rapi.checkFileExists(matFileName)):
			#print("YES")
			matFileName = matFileName.replace("\\","/")
			#print(matFileName)
			myMat = open(matFileName).read()

			soup = BeautifulSoup(myMat)
			matVar = soup.findAll('material')
			for i in range(0, len(matVar)):
				#print(matVar[i].attrs)
				if 'name' in matVar[i].attrs:
					material = NoeMaterial(matVar[i]['name'], "")
				else:
					material = NoeMaterial(str(i), "")
				if 'diffuse' in matVar[i].attrs:
					texName = matVar[i]['diffuse'].replace("tga","dds")
					if (rapi.checkFileExists(rapi.getDirForFilePath(rapi.getInputName()) + texName)):
						myTex = noesis.loadImageRGBA(rapi.getDirForFilePath(rapi.getInputName()) + texName)
						myTex.name = rapi.getLocalFileName(texName)
						self.texList.append(myTex)
						material.setTexture(myTex.name)
				if 'normalmap' in matVar[i].attrs:
					texName = matVar[i]['normalmap'].replace("tga","dds")
					if (rapi.checkFileExists(rapi.getDirForFilePath(rapi.getInputName()) + texName)):
						myTex = noesis.loadImageRGBA(rapi.getDirForFilePath(rapi.getInputName()) + texName)
						myTex.name = rapi.getLocalFileName(texName)
						self.texList.append(myTex)
						material.setNormalTexture(myTex.name)
				if 'specularmap' in matVar[i].attrs:
					texName = matVar[i]['specularmap'].replace("tga","dds")
					if (rapi.checkFileExists(rapi.getDirForFilePath(rapi.getInputName()) + texName)):
						myTex = noesis.loadImageRGBA(rapi.getDirForFilePath(rapi.getInputName()) + texName)
						myTex.name = rapi.getLocalFileName(texName)
						self.texList.append(myTex)
						material.setSpecularTexture(myTex.name)
				self.matList.append(material)

	def loadMBUS(self, bs):
		#print(self.CurrentChunk)
		bs.seek(self.CurrentChunk[1], NOESEEK_ABS)
		unk1, unk2, unk3, meshCount = bs.readInt(), bs.readInt(), bs.readInt(), bs.readInt()
		for i in range(0, meshCount):
			self.meshInfo.append(bs.read("8i6f2i"))
			#print(self.meshInfo[i])

	def loadRPXE(self, bs):
		#print(self.CurrentChunk)
		pass

	def loadLEKS(self, bs): 
		#print(self.CurrentChunk)
		bs.seek(self.CurrentChunk[1], NOESEEK_ABS)
		unk1, boneCount = bs.readUShort(), bs.readUShort()
		for i in range(0, boneCount):
			boneNameSize = bs.readUInt()
			boneName = noeStrFromBytes(bs.readBytes(boneNameSize))
			boneParent = bs.readShort()
			boneFloats = bs.read("14f")
			bonePos = NoeVec3([boneFloats[7], boneFloats[8], boneFloats[9]])
			boneMtx = NoeQuat([boneFloats[10], boneFloats[11], boneFloats[12], boneFloats[13]]).toMat43()
			boneMtx[3] = bonePos
			#print([boneName, boneParent, boneFloats])
			newBone = NoeBone(i, boneName, boneMtx, None, boneParent)
			self.boneList.append(newBone)
		self.boneList = rapi.multiplyBones(self.boneList)

	def loadTHGW(self, bs):
		bI = []
		wI = []
		#print(self.CurrentChunk)
		bs.seek(self.CurrentChunk[1], NOESEEK_ABS)
		unk1 = bs.readUInt()
		while bs.tell() < self.CurrentChunk[1] + self.CurrentChunk[2]:
			weightCount = bs.readUShort()
			w1, w2, w3, w4 = 0, 0, 0, 0
			b1, b2, b3, b4 = 0, 0, 0, 0
			if weightCount == 1:
				b1, w1 = bs.read("2H")
			elif weightCount == 2:
				b1, w1, b2, w2 = bs.read("4H")
			elif weightCount == 3:
				b1, w1, b2, w2, b3, w3 = bs.read("6H")
			elif weightCount == 4:
				b1, w1, b2, w2, b3, w3, b4, w4 = bs.read("8H")
			bI.append(b1); bI.append(b2); bI.append(b3); bI.append(b4)
			wI.append(w1); wI.append(w2); wI.append(w3); wI.append(w4)
		self.weightBuff = struct.pack("<" + 'f'*len(wI), *wI)
		self.bindexBuff = struct.pack("<" + 'H'*len(bI), *bI)

	def loadXBBB(self, bs):
		#print(self.CurrentChunk)
		pass

	def loadRPBC(self, bs):
		#print(self.CurrentChunk)
		pass

	def loadSDNB(self, bs):
		#print(self.CurrentChunk)
		pass

	def buildModel(self, bs):
		bs.seek(self.hsmvInfo[0][1], NOESEEK_ABS)
		vertBuff = bs.readBytes(self.hsmvInfo[0][0] * self.hsmvInfo[0][2])
		#print(self.hsmvInfo[0][5])
		for i in range(0, len(self.hsmvInfo[0][5]) // 2):
			#print(self.hsmvInfo[0][5][(i * 2)])
			#print(self.hsmvInfo[0][5][(i * 2) + 1])
			if self.hsmvInfo[0][5][(i * 2)] != 255:
				if self.hsmvInfo[0][5][(i * 2) + 1] == 48:
					dataType = noesis.RPGEODATA_FLOAT
				elif self.hsmvInfo[0][5][(i * 2) + 1] == 0:
					dataType = noesis.RPGEODATA_BYTE
				if i == 0:
					rapi.rpgBindPositionBufferOfs(vertBuff, dataType, self.hsmvInfo[0][0], self.hsmvInfo[0][5][(i * 2)])
				elif i == 1:
					pass
					#rapi.rpgBindColorBufferOfs(vertBuff, dataType, self.hsmvInfo[0][0], self.hsmvInfo[0][5][(i * 2)], 4)
				elif i == 2:
					rapi.rpgBindNormalBufferOfs(vertBuff, dataType, self.hsmvInfo[0][0], self.hsmvInfo[0][5][(i * 2)])
				elif i == 3:
					rapi.rpgBindUV1BufferOfs(vertBuff, dataType, self.hsmvInfo[0][0], self.hsmvInfo[0][5][(i * 2)])
		if self.weightBuff != 0:
			rapi.rpgBindBoneIndexBuffer(self.bindexBuff, noesis.RPGEODATA_USHORT, 8, 4)
			rapi.rpgBindBoneWeightBuffer(self.weightBuff, noesis.RPGEODATA_FLOAT, 16, 4)
			

		for i in range(0, len(self.meshInfo)):
			bs.seek(self.hsmvInfo[0][3] + (2 * self.meshInfo[i][0]), NOESEEK_ABS)
			faceBuff = bs.readBytes(self.meshInfo[i][1] * 2)
			rapi.rpgSetName(self.meshList[self.meshInfo[i][14]])
			rapi.rpgSetMaterial(self.meshList[self.meshInfo[i][14]])
			rapi.rpgCommitTriangles(faceBuff, noesis.RPGEODATA_USHORT, self.meshInfo[i][1], noesis.RPGEO_TRIANGLE, 1)
			#print(self.meshInfo[i])

askerObjectLoaderDict = {
	"HSMV" : askerFile.loadHSMV,
	"SRTM" : askerFile.loadSRTM,
	"MBUS" : askerFile.loadMBUS,
	"RPXE" : askerFile.loadRPXE,
	"LEKS" : askerFile.loadLEKS,
	"THGW" : askerFile.loadTHGW,
	"XBBB" : askerFile.loadXBBB,
	"RPBC" : askerFile.loadRPBC,
	"SDNB" : askerFile.loadSDNB
}


def askermodLoadModel(data, mdlList):
	ctx = rapi.rpgCreateContext()
	asker = askerFile(NoeBitStream(data))
	asker.loadAll(asker.bs)
	rapi.setPreviewOption("setAngOfs", "0 -90 0")
	rapi.setPreviewOption("autoLoadNonDiffuse", "1")
	try:
		mdl = rapi.rpgConstructModel()
	except:
		mdl = NoeModel()
	mdl.setModelMaterials(NoeModelMaterials(asker.texList, asker.matList))
	mdlList.append(mdl); mdl.setBones(asker.boneList)	
	return 1

