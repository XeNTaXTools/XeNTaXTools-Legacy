from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Half-Life 2 [Xbox]", ".xtf")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    if noeStrFromBytes(bs.readBytes(3)) != 'XTF': return 0
    return 1
    
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.seek(0x14, NOESEEK_ABS)
    imgWidth = bs.readUShort()            
    imgHeight = bs.readUShort()
    bs.seek(0x1e, NOESEEK_ABS)
    dataStart = bs.readUShort()
    bs.seek(0x30, NOESEEK_ABS)
    imgFmt = bs.readUInt()
    print(hex(imgFmt), ":imgFmt")
    #DXT1
    if imgFmt == 0xd:
        bs.seek(dataStart, NOESEEK_ABS)         
        data = bs.readBytes(imgWidth * imgHeight // 2)
        texFmt = noesis.NOESISTEX_DXT1
    #DXT5
    elif imgFmt == 0xf:
        bs.seek(dataStart, NOESEEK_ABS)         
        data = bs.readBytes(imgWidth * imgHeight)
        texFmt = noesis.NOESISTEX_DXT5
    #RGBA8888 pal morton order ??
    elif imgFmt == 0x7:
        bs.seek(0x9, NOESEEK_REL)
        imgWidth = imgWidth // 2 #??
        imgHeight = imgHeight // 2 #??
        palette = bs.readBytes(1024)
        bs.seek(dataStart, NOESEEK_ABS)         
        data = bs.readBytes(len(data) - bs.tell())
        data = rapi.imageDecodeRawPal(data, palette, imgWidth, imgHeight, 8, "r8 g8 b8 a8")
        untwid = bytearray()
        for x in range(imgWidth):
            for y in range(imgHeight):
                idx = noesis.morton2D(x, y)
                untwid += data[idx * 4:idx * 4 + 4]
        data = rapi.imageDecodeRaw(untwid, imgWidth, imgHeight, "b8 g8 r8 a8") #??
        texFmt = noesis.NOESISTEX_RGBA32
    #RGBA8888 morton order ??
    elif imgFmt == 0x10:        
        bs.seek(dataStart, NOESEEK_ABS)         
        data = bs.readBytes(len(data) - bs.tell())
        untwid = bytearray()
        for x in range(imgWidth):
            for y in range(imgHeight):
                idx = noesis.morton2D(x, y)
                untwid += data[idx * 4:idx * 4 + 4]
        data = rapi.imageDecodeRaw(untwid, imgWidth, imgHeight, "r8 g8 b8 p8") 
        texFmt = noesis.NOESISTEX_RGBA32
    print(imgWidth, "x", imgHeight)
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1