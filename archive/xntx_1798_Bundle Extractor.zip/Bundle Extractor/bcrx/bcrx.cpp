#include "stdio.h"
#include <string>
#include <vector>
#include "io.h"

using namespace std;

struct dirnode;

struct node {
    string name;
    dirnode* parent;
    node(char const *name) : name(name), parent(0) {};
    virtual ~node () {};
    
    virtual void print() = 0;
    virtual void extract(FILE* file) = 0;
};

struct dirnode : public node {
    vector<node*> children;
    dirnode (char const *name) : node(name) {}
    virtual ~dirnode () {
        vector<node*>::iterator i;
        for ( i = children.begin() ; i != children.end(); ++i ) {
            delete (*i);
        }
    };

    void add(node *child) {
        children.push_back(child);
        child->parent = this;
    }
    virtual void print() {
        printf("[DIR] %s\n",name.c_str());
        vector<node*>::iterator i;
        for ( i = children.begin() ; i != children.end(); ++i ) {
            (*i)->print();
        }
        printf("[END] %s\n",name.c_str());
    }

    virtual void extract(FILE* file) {
        // TODO: Error checking?
        mkdir(name.c_str());
        chdir(name.c_str());
        vector<node*>::iterator i;
        for ( i = children.begin() ; i != children.end(); ++i ) {
            (*i)->extract(file);
        }
        chdir("..");
    }

};

struct filenode: public node {
    unsigned int start, size;
    static const unsigned int buf_size = 1024*1024;
    filenode (char const *name, unsigned int start, unsigned int size) : node(name), start(start), size(size) {}
    virtual ~filenode () {};

    virtual void print() {
        printf("[FILE] %s\n",name.c_str());
    }
    virtual void extract(FILE* file) {
        char buffer[buf_size];
        
        FILE* outfile = fopen (name.c_str(), "wb");
        // error testing
        if (outfile == NULL) {
            printf ("Error opening output file %s\n", name.c_str());
            return;
        }
        //printf ("Copying %08X - %08X to file: %s ", start, start+size, name.c_str());
        
        fseek( file, start, SEEK_SET );
        
        unsigned int len = size; // remaining data to copy
        int to_rw, have_rw; // amount of bytes we need to/have successfuly read or written
        do {
            to_rw = len < buf_size ? len : buf_size;
            have_rw = fread ( buffer, 1, to_rw, file );
            if (have_rw != to_rw) { printf("Read error!\n"); fclose(outfile); return; }
            have_rw = fwrite ( buffer, 1, to_rw, outfile );
            if (have_rw != to_rw) { printf("Write error!\n"); fclose(outfile); return; }
            len -= to_rw;
            //printf(".");
        } while (len > 0);
        fclose(outfile);
        //printf("\n");
    }
};

void process_bundle(FILE* file) {
}

class bundle {
    FILE* file;
    static const unsigned int buf_size = 1024;
    dirnode *root, *current;
    
    public:
    bundle(const char *filename) {
        root = 0; current = 0;
        file = fopen (filename, "rb");
        if (file != NULL) {
            printf("Opened file: %s\n\n", filename);
        }
        else {
            printf("Failed to open file: %s\n\n", filename);
        }
    }
    ~bundle() {
        fclose(file);
        printf("\nClosed file.\n");
    }

    void read_dir() {
        unsigned char c;
        char name[buf_size];
        char *p = name;
    
        // Read one byte ???
        fread(&c, 1, 1, file);
        
        // Read filename
        while (*p++ = fgetc(file)); // TODO: check for EOF
        //printf("[DIR - %02d] %s\n", dirlevel, name);
        //if (c != 1) printf("[ERROR] Expected 1\n");
        
        dirnode* newnode = new dirnode(name);
        current->add(newnode);
        current = newnode;
    }
    void read_enddir() {
        //printf("[ENDDIR - %02d]\n", dirlevel);
        current = current->parent;
    }
    void read_file() {
        unsigned char c;
        char name[buf_size];
        char *p = name;
        unsigned int pos, size, unknown; // start address, length, ???
        
        // Read position, ???, size, and ???
        fread(&pos, 4, 1, file);
        fread(&unknown, 4, 1, file);
        fread(&size, 4, 1, file);
        fread(&c, 1, 1, file);
    
        // Read filename
        while (*p++ = fgetc(file)); // TODO: check for EOF
        //printf("[FILE] %s\n", name);
        //if (unknown != 0) printf("Expected 0 for unknown\n");
        //if (c != 1) printf("Expected 1\n");
        
        filenode* newnode = new filenode(name, pos, size);
        current->add(newnode);
    }
    
    void process() {
        unsigned char c;
        unsigned int count = 0;
        bool done = false;
         
        // skip header. bytes 8-12 are the total size of the index data
        fseek ( file, 16, SEEK_SET );
        
        root = new dirnode("root");
        current = root;
        
        do {
            // Read type ID
            c = fgetc( file );
            ++count;
            switch (c) {
                case 1:
                    read_dir();
                    break;
                case 2:
                    read_file();
                    break;
                case 3:
                    read_enddir();
                    if (current == 0) done = true;
                    break;
                default:
                    printf("Invalid command: %02X\n",c);
                    done = true;
                    break;
            }
        } while (!done);
        printf("Commands processed: %u\n", count);
        
        //root->print();
        root->extract(file);
        
    }
};

int main(int argc, char *argv[])
{
    FILE* file;
    char *filename = "quick.bundle";

    bundle b(filename);
    b.process();
    
    return 0;
}
