#by Durik256 for xentax
from inc_noesis import *
import math

def registerNoesisTypes():
    handle = noesis.register("Aerial Strike: The Yager Missions", ".ylm")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)
    return 1

def noepyCheckType(data):
    if data[:3] != b'YLM':
        return 0
    return 1   
	
def noepyLoadModel(data, mdlList):
    bs = NoeBitStream(data)

    bs.seek(4)#YML
    texFmt = noesis.NOESISTEX_RGBA32
    
    file_size, unk, num_file = bs.readInt(), bs.readInt(), bs.readInt()

    bs.seek(4, 1)#MAP
    
    (size, unk, unk, x_terrain, y_terrain, x_chunk, y_chunk, unk, unk) = [bs.readInt() for x in range(9)]

    bs.seek((x_terrain*y_terrain)*4, 1)
    
    texList, meshes, materials = [], [], []
    '''
    for x in range(4):
        w, h = x_terrain//2, y_terrain//2
        data = bs.readBytes(w * h * 4)
        texList.append(NoeTexture('_small_%d' % x, w, h, data, texFmt))
    '''
    num_chunk = bs.readInt()
    start_chunk = bs.getOffset() + (x_terrain*y_terrain)*4
    
    for y in range(y_terrain):
        for x in range(x_terrain):
            
            
            offset, cutPos = bs.readInt(), bs.getOffset()
            data = b''
            if offset != -1:
                bs.seek(offset + start_chunk)
                data += bs.readBytes(1156)
                bs.seek(cutPos)
                
                texList.append(NoeTexture('tx_%d_%d' % (x,y), x_chunk + 1, y_chunk + 1, data, texFmt))
                materials.append(NoeMaterial('mat_%d_%d' % (x,y), 'tx_%d_%d' % (x,y)))
                meshes.append(quad('quad_%d_%d' % (x,y), 1, x, -y))
    
    '''
    bs.seek(4, 1)#NRML
    n_size, n_num = bs.readInt(), bs.readInt()
    for x in range(n_num):
        nbuf = bs.readBytes(n_num*12)
        
    bs.seek(4, 1)#TEX
    tx_size, tx_num = bs.readInt(), bs.readInt()
    for x in range(tx_num):
        tx_name = bs.readBytes(to the first zero)
    '''
    
    mdl = NoeModel(meshes)
    mdl.setModelMaterials(NoeModelMaterials(texList, materials))
    mdlList.append(mdl)
    return 1
    
def quad(name, size, offsetX=0, offsetY=0):
    vert = [NoeVec3([0+offsetX, 0+offsetY, 0]), NoeVec3([size+offsetX, 0+offsetY, 0]), NoeVec3([0+offsetX, size+offsetY, 0]), NoeVec3([size+offsetX, size+offsetY, 0])]
    uv = [NoeVec3([0, 0, 0]), NoeVec3([1, 0, 0]), NoeVec3([0, -1, 0]), NoeVec3([1, -1, 0])]
    tris = [1, 2, 0, 1, 3, 2]

    mesh = NoeMesh(tris, vert, name)
    mesh.setUVs(uv)
    mesh.setMaterial('mat_%d_%d' % (abs(offsetX),abs(offsetY)))#('mat')
    return mesh