'''Noesis import plugin. Written by Giay Nhap'''

from inc_noesis import *
import noesis
import rapi

def registerNoesisTypes():
    
    
    handle = noesis.register("Giay Nhap Read Model Truy Kick", ".wmdl")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)
    return 1

def noepyCheckType(data):
    '''Verify that the format is supported by this plugin.'''
    
    if len(data) < 9:
        return 0
    try:
        return 1
    except:
        return 0

def noepyLoadModel(data, List):
    

    ctx = rapi.rpgCreateContext()
    parser = SanaeParser(data)
    parser.parse_file()
    gnfile = rapi.rpgConstructModel()
    List.append(gnfile)
    return 1

class SanaeParser(object):
    
    def __init__(self, data):    
        self.inFile = NoeBitStream(data)
        self.dirpath = rapi.getDirForFilePath(rapi.getInputName())
        self.texpath = self.dirpath + "texture\\"
        
    def parse_mesh(self, data):
       
        self.inFile.seek(data,0)
        version = self.inFile.readUInt()
        self.inFile.seek(4, 1)
        numVerts = self.inFile.readUInt()
        self.inFile.seek(4, 1)
        sizeofvec = self.inFile.readUInt()
        self.inFile.seek(8, 1)
        ENDVERBUFF = self.inFile.readUInt()
        self.inFile.readUInt()
        START_NumIndx =self.inFile.readUInt()
        numIdx = self.inFile.readUInt()
        FileSize = self.inFile.readUInt()
        skipsize = self.inFile.readUInt()
        self.inFile.seek(8,1)
        EndMESH=self.inFile.readUInt()
        self.inFile.seek(12,1)
        EndFILE = self.inFile.readUInt()
        self.inFile.seek(4,1)
        STARTNEXTMESH = self.inFile.readUInt()
        self.inFile.seek(1,1)
        tub = self.inFile.read('1c')
        numunk = int(ord(tub[0]))
        self.inFile.seek(numunk,1)
        numvar = int((sizeofvec / numVerts) / 4) - 5;
        vertBuff = bytes()
        uvBuff = bytes()
        triBuff = bytes()
        for j in range(numVerts):
            vertBuff += self.inFile.readBytes(12)
            uvBuff += self.inFile.readBytes(8)
            self.inFile.read('%df' %numvar)
        self.inFile.seek(EndMESH - numIdx*3*4,0)
        for  j in range(numIdx*3):
           for k in range(4):
                triBuff=self.inFile.readBytes(1) +triBuff
        rapi.rpgBindPositionBuffer(vertBuff, noesis.RPGEODATA_FLOAT, 12)
        rapi.rpgBindUV1Buffer(uvBuff, noesis.RPGEODATA_FLOAT, 8)
        rapi.rpgCommitTriangles(triBuff, noesis.RPGEODATA_UINT,  numIdx*3, noesis.RPGEO_TRIANGLE, 1)
		
        return STARTNEXTMESH
    def parse_file(self):
     nextstart=0
     nextstart=  self.parse_mesh(nextstart)
     while nextstart != 0:
          nextstart=  self.parse_mesh(nextstart)