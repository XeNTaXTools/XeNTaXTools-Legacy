# author: Volfin
# 1.00 - Initial Release
# 1.10 - Added Materials, Bone weights, Vertice Colors, Rigged mesh support
# 1.11 - Fixed Flipped UV Maps
# 1.20 - Added skeleton import
# 1.21 - Flipped models on X axis for proper visualization
# 1.30 - Fixed flipped normals. streamlined code. Sort bone groups. Added split normal import if blender is 2.75 or above.
# 1.31 - fixed compatiblity with old blender versions (2.70/2.71)
# 1.32 - Fixed a problem with Scale/Rotation applying on LODs

bl_info = {
    "name": "Quantum Break WedMsh Importer",
    "author": "Volfin",
    "version": (1, 3, 2),
    "blender": (2, 7, 0),
    "location": "File > Import > WedMsh (Quantum Break Model)",
    "description": "Import WedMsh, io: mesh",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
    "category": "Import-Export"}
    
if "bpy" in locals():
    import imp
    if "import_WedMsh" in locals():
        imp.reload(import_WedMsh)
    if "export_WedMsh" in locals():
        imp.reload(export_WedMsh)

import bpy

from bpy.props import (StringProperty,
                       BoolProperty,
                       FloatProperty,
                       EnumProperty,
                       )

from bpy_extras.io_utils import (ImportHelper,path_reference_mode)

  
class WedMshImportOperator(bpy.types.Operator, ImportHelper):
    bl_idname = "import_scene.wedmsh"
    bl_label = "WedMsh Importer(.WedMsh)"
    
    filename_ext = ".wedmsh"
    skip_blank=False;

    randomize_colors = BoolProperty(\
        name="Random Material Colors",\
        description="Assigns a random color to each material",\
        default=True,\
        )

    import_vertcolors = BoolProperty(\
        name="Import Vertex Colors",\
        description="Import Vertex Colors",\
        default=False,\
        )
    
    use_layers = BoolProperty(\
        name="Seperate Mesh Layers",\
        description="Place Meshes on seperate layers",\
        default=True,\
        )
    mesh_scale = bpy.props.FloatProperty(
        name="Scale Factor",
        description="Mesh Import Scale Factor",
        default=3.0,
    )

    filter_glob = StringProperty(default="*.WedMsh") # , options={'HIDDEN'}
    filepath = bpy.props.StringProperty(subtype="FILE_PATH")        
    path_mode = path_reference_mode

    def execute(self, context):
        import os, sys
        print("Import Execute called")
        cmd_folder = os.path.dirname(os.path.abspath(__file__))
        if cmd_folder not in sys.path:
            sys.path.insert(0, cmd_folder)

        import import_WedMsh
        result=import_WedMsh.import_WedMsh(self.filepath, bpy.context,self.randomize_colors,self.import_vertcolors,self.skip_blank,self.use_layers,self.mesh_scale)

        # force back off
        #self.skip_blank=False
        #self.use_layers=False
        
        if result is not None:
            self.report({'ERROR'},result)

        return {'FINISHED'}

    def invoke(self, context, event):

        print("Import Invoke called")
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        col.label('Mesh Scale Factor')
        col.prop(self, "mesh_scale")
        row = layout.row(align=True)
        row.prop(self, "randomize_colors")
        row = layout.row(align=True)
        row.prop(self, "import_vertcolors")
        row = layout.row(align=True)
        row.prop(self, "use_layers")

#
# Registration
#
def menu_func_import(self, context):
    self.layout.operator(WedMshImportOperator.bl_idname, text="WedMsh(Quantum Break Model)(.WedMsh)",icon='PLUGIN')
   
def register():
    bpy.utils.register_module(__name__)
    bpy.types.INFO_MT_file_import.append(menu_func_import)
    
def unregister():
    bpy.utils.unregister_module(__name__)
    bpy.types.INFO_MT_file_import.remove(menu_func_import)
    
if __name__ == "__main__":
    register()