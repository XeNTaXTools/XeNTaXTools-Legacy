import struct
import zlib
import sys
import os

# ============ File Utility ==============
def safe_mkdir(dirName):
  try:
    os.mkdir(dirName)
  except OSError, (errno, strerror):
    if(errno != 17):
      print "%d: %s" % (errno, strerror)
      sys.exit(-1)

# ============ PNG/Image Routines ===========

def pack_chunk(tag,data):
  to_check = tag + data
  return struct.pack("!I",len(data)) + \
         to_check + \
         struct.pack("!I",zlib.crc32(to_check))

def dumpToPNG(width, height, data):
  raw_data = ""
  for y in range(height):
    raw_data += chr(0)
    raw_data += data[y*width*4:(y+1)*width*4]

  return struct.pack("8B", 137, 80, 78, 71, 13, 10, 26, 10) + \
         pack_chunk('IHDR',
           struct.pack("!IIBBBBB",width,height,8,6,0,0,0)) + \
         pack_chunk('IDAT', zlib.compress(raw_data,9)) + \
         pack_chunk('IEND', '')

def image16to32(width, height, data):
  buf = ""
  for i in range(width*height):
    p = struct.unpack("BB", data[i*2:i*2+2])

    a = p[1] / 16 ; a = a*16 + a
    r = p[1] % 16 ; r = r*16 + r
    g = p[0] / 16 ; g = g*16 + g
    b = p[0] % 16 ; b = b*16 + b

    buf += struct.pack("BBBB", r, g, b, a)
  return buf

# =========== Abort/Debug Routines ==========

def check(flag, val, f, msg="Default Error"):
  if(flag != val):
    print "<tr><td>Unknown: %s</td><td>Expecting: %s</td></tr>" % (repr(flag), repr(val))
    print "<tr><td>Error</td><td>%s</td></tr>" % msg
    dumpFileLoc(f)
    sys.exit(-1)

def checkA(flag, vals, f, msg="Default Error"):
  if(not flag in vals):
    print "<tr><td>Unknown:  %s</td><td>Expecting: %s</td></tr>" % (repr(flag), repr(vals))
    print "<tr><td>Error</td><td>%s</td></tr>" % msg
    dumpFileLoc(f)
    sys.exit(-1)

# =========== Basic File Reading ==========

def rU8 (f): return struct.unpack('B', f.read(1))[0]
def rU16(f): return struct.unpack('H', f.read(2))[0]
def rU32(f): return struct.unpack('I', f.read(4))[0]
def rU64(f): return struct.unpack('Q', f.read(8))[0]
def rF32(f): return struct.unpack('f', f.read(4))[0]
def rF64(f): return struct.unpack('d', f.read(8))[0]

# =========== Unsorted ==========

def dumpFileLoc(f):  print "<tr><td>FileLocation</td><td>%d</td></tr>" % f.tell()

def rPackNum(f):
  size = rU8(f)
  if(size == 0x80): size = rU32(f)
  return size

def transStr(str):
  s = ''
  p = 0xAA
  for cc in str:
    a = ord(cc)
    val = ((a & ~p) ^ (~a & p)) & 0xff
    s += struct.pack("B", val )
    p += 1
  return s

def rUStr(f):
  size = rU8(f)
  if(size == 0):
    return ""
  elif(size == 0x80):
    size = rU32(f)
    return transStr(f.read(size))
  else:
    return transStr(f.read(256 - size))

# ========== Header =========

def dumpHeader(f):
  ident  = f.read(4)
  size   = rU64(f)
  offset = rU32(f)
  copy   = f.read(offset - f.tell())

# ========== Directory / File Tree =========

def dumpDirInfo(f, sname):
  filename = rUStr(f)
  filesize = rPackNum(f)
  unknown1 = rPackNum(f)
  unknown2 = rU32(f)

def dumpLinkInfo(f, sname):
  fileloc  = rU32(f)

  pos = f.tell()
  f.seek(fileloc + 0x3c + 1, 0)
  filename = rUStr(f)
  f.seek(pos)

  filesize = rPackNum(f)
  unknown1 = rPackNum(f)
  unknown2 = rU32(f)

def dumpFileInfo(f, sname):
  filename = rUStr(f)
  filesize = rPackNum(f)
  unknown1 = rPackNum(f)
  unknown2 = rU32(f)

def dumpDirTree(f, sname):
  fileCount = rPackNum(f)

  for i in range(fileCount):
    fileType = rU8(f)   ; checkA(fileType, [2, 3, 4], f)
    if (fileType == 0x04): dumpFileInfo(f, sname + "[" + str(i) + "]")
    if (fileType == 0x03): dumpDirInfo(f, sname + "[" + str(i) + "]")
    if (fileType == 0x02): dumpLinkInfo(f, sname + "[" + str(i) + "]")

def dumpDirTrees(f):
  unknown = rU16(f)

  for i in range(45):
    dumpDirTree(f, "Dir[" + str(i) + "]")

# =========== Everything else ==========

def dumpImage(f, imageName):
  global dumpDir
  width  = rPackNum(f)
  height = rPackNum(f)
  val   = rPackNum(f)    ; checkA(val, [0, 1, 513], f)
  val2  = rU8(f)         ; checkA(val2, [0, 2, 4], f)
  nulls = f.read(4)      ; check(nulls, "\x00\x00\x00\x00", f, "Dump Image")
  bufSize = rU32(f) - 1
  flag = rU8(f)          ; check(flag,  0x00, f);

  obj = zlib.decompressobj()
  buf = obj.decompress(f.read(bufSize))
  g = open(dumpDir + "/" + imageName + ".png", "wb")
  g.write(dumpToPNG(width, height, image16to32(width, height, buf)))
  g.close()

iconDescs = [30, "origin", "z", "lt", "rb", "head", "delay", "map", "group", "a0", "a1"]
def dumpIcon(f, imageName):
  space = f.read(4)  ; check(space, "\x00\x01\x00\x00", f)
  count = rU8(f)
  for i in range(count):
    name = immedValue(f)  ; checkA(name, iconDescs, f)
    dumpBlock(f, imageName + "." + str(name))
  dumpImage(f, imageName)

def immedValue(f):
  type = rU8(f)  ; checkA(type, [0x00, 0x01], f, "ImmedValue type")
  if   (type == 0x00): value = rUStr(f)
  elif (type == 0x01): value = rU32(f)
  return value

def hexStr(s):
  str = ''
  for c in s:
    str += "\\x%02x" % ord(c)
  return str

def endMatches(str, values):
  for s in values:
    if(str[-len(s):] == s): return 1
  return 0

def dumpBlock(f, name):
  global dumpDir

  loc = f.tell()
  type = rU8(f)      ; checkA(type, [0, 1, 2, 3, 4, 5, 8, 9, 27, 115], f)
  if   (type == 0x00):
    value = rUStr(f)
    print "<tr><td>%s</td><td>%s</td></tr>" % (name, str(value))
  elif (type == 0x01):
    value = rU32(f)
    print "<tr><td>%s</td><td>%s</td></tr>" % (name, str(value))
  if (type == 0x02):
    value = rU16(f)
    print "<tr><td>%s</td><td>%s</td></tr>" % (name, str(value))
  if(type == 0x03):
    value = rPackNum(f)
    print "<tr><td>%s</td><td>%s</td></tr>" % (name, str(value))
  if(type == 0x04):
    type2 = rU8(f) ; checkA(type2, [0x00, 0x80], f, "Post 0x04 type")
    if(type2 == 0x80): value = rF32(f)
    if(type2 == 0x00): value = 0
    print "<tr><td>%s</td><td>%s</td></tr>" % (name, str(value))
  if(type == 0x05):
    value = rF64(f)
    print "<tr><td>%s</td><td>%s</td></tr>" % (name, str(value))    
  if(type == 0x08):
    type2 = rU8(f) ; checkA(type2, [0x00, 0x01], f, "Post 0x08 type")
    if(type2 == 0x00):
      type3 = rU8(f)
      if(type3 >= 0x80):
        f.seek(-1, 1)
        value = rUStr(f)
        print "<tr><td>%s</td><td>%s</td></tr>" % (name, value)
      if(type3  < 0x80):
        if(type3 == 0x7F): count = rU32(f)
        else:              count = type3
        value = []
        for j in range(count):
          value.append(rU16(f))
        print "<tr><td>%s</td><td>%s</td></tr>" % (name, str(value))
    if(type2 == 0x01):
      value = rU32(f)
      print "<tr><td>%s</td><td>%s</td></tr>" % (name, str(value))
  if(type == 0x09):
    size = rU32(f)
    dumpBlock(f, name)
  if(type == 0x1b):
    flag = rU8(f)  ; checkA(flag, [0x01, 0x1e, 0x29, 0x2b, 0x2c,
                                   0x2d, 0x33, 0x35, 0x38, 0x3c,
                                   0x3f, 0x40, 0x43, 0x45, 0x46,
                                   0x47, 0x48, 0x4c, 0x4d, 0x4f,
                                   0x52, 0x56, 0x59, 0x5a, 0x5d,
                                   0x60, 0x61, 0x62, 0x63, 0x66,
                                   0x6a, 0x6c, 0x70, 0x72, 0x7a,
                                   0x7c, 0x7d, 0x84, 0x8a, 0x8c,
                                   0x94, 0xe3, 0xfd], f)
    if(flag == 0x01):
      nils = f.read(5) ; check(nils, "\x00\x00\x00\x00\x00", f)
      descCount = rPackNum(f)
      for j in range(descCount):
        qname = immedValue(f)
        dumpBlock(f, name + "." + str(qname))
    # 0x43, 0x7a, 0x62
    # 0x7a: 1594 conflicts with 10
    if(flag in [0x1e, 0x29, 0x2b, 0x2c, 0x2d, 0x33, 0x35, 0x3c, 0x3f, 0x40,
                0x47, 0x48, 0x4c, 0x52, 0x60, 0x62, 0x63, 0x6a, 0x70, 0x72, 0xe3]):
      nils = f.read(4) ; checkA(nils, ["\x00\x00\x00\x00", "\x01\x00\x00\x00"], f)
      count = rU8(f)
      if(count):
        nil = rU16(f)           ; check(nil, 0, f)
        descCount = rU8(f)
        for j in range(descCount):
          qname = immedValue(f)
          dumpBlock(f, name + "." + str(qname))
      dumpImage(f, str(loc))
      print "<tr><td>%s</td><td><img src='../%s/%s.png'/></td></tr>" % (name, dumpDir, str(loc))
    if(flag in [0x38, 0x45, 0x46, 0x43, 0x4d, 0x4f, 0x56, 0x59, 0x5a, 0x5d, 0x61,
                0x6c, 0x7a, 0x7c, 0x7d, 0x66, 0x84, 0x8a, 0x8c, 0x94, 0xfd]):
      nils = f.read(3) ; checkA(nils, ['\x00\x00\x00', '\x01\x00\x00'], f)
      val1 = rPackNum(f)
      val2 = rPackNum(f)
  if(type == 0x73):
    iname = rUStr(f) ; checkA(iname, ["Canvas", "Shape2D#Vector2D", "UOL"], f)
    if(iname == "Shape2D#Vector2D"):
      val1 = rPackNum(f)
      val2 = rPackNum(f)
    if(iname == "Canvas"):
      dumpIcon(f, str(loc))
      print "<tr><td>%s</td><td><img src='../%s/%s.png'/></td></tr>" % (name, dumpDir, str(loc))
    if(iname == "UOL"):
      nil = rU8(f)
      image = immedValue(f)
      print "<tr><td>%s</td><td>Use Image %s</td></tr>" % (name, image)

def dumpEntryValue(f, name):
  global skipBlocks
  type = rU8(f) ; checkA(type, (0x00, 0x03, 0x08, 0x09), f)

  if (type == 0x09):
    blockSize = rU32(f)
    loc = f.tell()
    endOfBlock = f.tell() + blockSize

    if((not skipBlocks) or endMatches(name, ["info"])): dumpBlock(f, name)

    if(f.tell() != endOfBlock):
      f.seek(endOfBlock, 0)
      print "<tr><td>%s</td><td>SB: %d</td><tr>" % (name, blockSize)
  elif(type == 0x08):
    dumpBlock(f, name)
  elif(type == 0x00):
    pass
    print "<tr><td>%s</td><td>NIL</td></tr>" % name
  elif (type == 0x03):
    value = rPackNum(f)
    print "<tr><td>%s</td><td>%s</td></tr>" % (name, str(value))

def dumpFile(f, sname):
  flag = rU8(f)      ; check(flag, 0x73, f)
  imgName = rUStr(f) ; check(imgName, "Property", f)
  space = rU8(f)     ; check(space, 0x00, f, "File Outer Space")
  space = rU8(f)     ; check(space, 0x00, f, "File Outer Space 2")
  entries = rPackNum(f)
  
  for i in range(entries):
    #print "dumpFile immedValue"
    val = immedValue(f)
    dumpEntryValue(f, sname + "." + str(val))

def dumpHtmlHeader():
  print "<html>"
  print " <head>"
  print "  <title>data.wz File Dump</title>"
  print " </head>"
  print " <body>"
  print "  <a href='index.html'>Index</a><br />"
  print "  <table>"

def dumpHtmlFooter():
  print "  </table>"
  print "  <a href='index.html'>Index</a><br />"
  print " </body>"
  print "</html>"

def dump():
  global dumpDir, skipBlocks

  f = open("data.wz", "rb")

  origstdout = sys.stdout

  safe_mkdir("dump")  

  g = open("dump/header.html", "w")
  sys.stdout = g
  dumpHtmlHeader()
  dumpHeader(f)
  dumpHtmlFooter()
  g.close()

  g = open("dump/dirtree.html", "w")
  sys.stdout = g
  dumpHtmlHeader()
  dumpDirTrees(f)
  dumpHtmlFooter()
  g.close()

  for i in range(5991):
    sys.stdout = origstdout
    print "File %d of %d" % (i, 5991)

    filename = "dump/%d.html" % i
    dumpDir = "dump/%d" % i
    safe_mkdir(dumpDir)

    g = open(filename, "w")
    sys.stdout = g
    if(i > 1593):  skipBlocks = 1
    else:          skipBlocks = 0
    dumpHtmlHeader()
    dumpFile(f, "File[" + str(i) + "]")
    dumpHtmlFooter()
    g.close()

  sys.stdout = origstdout
  print f.tell()

skipBlocks = 0
dumpDir = "dump/"
dump()
