from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Battle Gear 4", ".txd")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
	#noesis.logPopup()
	return 1

#check if it's this type based on the data
def noepyCheckType(data):
    bs = NoeBitStream(data)
    Magic = bs.readBytes(4)
    if Magic != b'\x16\x00\x00\x00':
        return 0
    return 1
	
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.seek(0x0a, NOESEEK_ABS)
    numTex = bs.readByte()
    skip = bs.readBytes(5)
    check = 1; end = len(data)
    while check < end:
        tmp = bs.tell()
        bs.seek(0x2c, NOESEEK_REL)
        texName = bs.readString()             
        print(texName, "-texName")
        bs.seek(tmp + 112, NOESEEK_ABS)
        imgFmt = bs.readBytes(4).decode("ASCII")
        imgWidth = bs.readUShort()            
        print(imgWidth, "imgWidth")
        imgHeight = bs.readUShort()           
        print(imgHeight, "imgHeight")
        skip = bs.readByte()
        numMips = bs.readByte()
        skip = bs.readByte()
        skip = bs.readByte()
        for i in range(numMips):
            datasize = bs.readUInt()
            data = bs.readBytes(datasize)      
            #DXT1
            if imgFmt == "DXT1":
                texFmt = noesis.NOESISTEX_DXT1
            #DXT3
            elif imgFmt == "DXT3":
                texFmt = noesis.NOESISTEX_DXT3
            #DXT5
            elif imgFmt == "DXT5":
                texFmt = noesis.NOESISTEX_DXT5
            #RGBA32
            elif imgFmt == '\x15\x00\x00\x00' or imgFmt == '\x16\x00\x00\x00':
                data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "r8 g8 b8 a8")
                texFmt = noesis.NOESISTEX_RGBA32
            if i == 0:
                texList.append(NoeTexture(texName, imgWidth, imgHeight, data, texFmt))
                print(i, "mip level")
        check = bs.tell() + 0x18
        print(hex(check), "check")
    return 1