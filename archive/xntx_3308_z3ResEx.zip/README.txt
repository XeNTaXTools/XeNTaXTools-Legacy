z3ResEx
=======

Extracts the filesystem from **RaiderZ** and **GunZ: The Second Duel** clients.


## Sourcecode

https://github.com/x1nixmzeng/z3ResEx


## Latest Build

https://raw.github.com/x1nixmzeng/z3ResEx/master/src/Release/z3ResEx.exe


## Usage

    z3ResEx.exe DIR -v|-x|-l
    
     <DIR>                  * Initial directory
     -v (--verbose)         * Verbose log messages
     -x (--no-extraction)   * Do not extract files
     -l (--list-filesystem) * Show list of filenames (overrides -x)
                           (* optional argument)
    
    z3ResEx.exe             Extract from current directory)
    z3ResEx.exe C:\RaiderZ  Extract from C:\RaiderZ
    z3ResEx.exe . -l        List filesystem in current directory

### Advanced Usage

Create a filelist named `filelist.txt` from a RaiderZ filesystem:

    z3ResEx.exe "C:\Games\RaiderZ" -l > filelist.txt

List all models from a GunZ2 filesystem:

    z3ResEx.exe "C:\NetmarbleGunZ" -l | find ".elu "


## Credits

Researched and coded by x1nixmzeng.

Thanks to Sir Kane who identified the Crypto++ method, to the members of the XeNTaX community, and those who shared download links to various clients.


## Usage Terms

This tool was written for personal use only. Please respect that the content you extract is owned by somebody else and should not be re-distributed without legal permissions from the copyright owner.

