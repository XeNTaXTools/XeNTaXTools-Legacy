import sbtoc
import Bundle
import os
from binascii import hexlify,unhexlify
from struct import pack,unpack
from cStringIO import StringIO
import sys
import zlib

####Adjust paths here. The script doesn't overwrite existing files so set tocRoot to the patched files first, then run the script again with the unpatched ones to get all files at their most recent version.

catName=r"D:\Program Files\Origin Games\Battlefield 3\Data\cas.cat"
patchedCatName=r"D:\Program Files\Origin Games\Battlefield 3\Update\Patch\Data\cas.cat" #used only when tocRoot contains "Update"

##tocRoot=r"D:\Program Files\Origin Games\Battlefield 3\Update"
tocRoot=r"D:\Program Files\Origin Games\Battlefield 3\Data\Win32"

outputfolder="D:/bf3 dump/"


############
############


def zlibb(f, size):
    ###give back the data directly if it is not in zlib format
    v1,v2=unpack(">II",f.read(8))
    magic=f.read(2)
    f.seek(-10,1)
    if magic!="\x78\xda" and v1!=v2: return f.read(size)
    ###
    outStream=StringIO()
    pos0=f.tell()
    while f.tell()<pos0+size:
        uncompressedSize,compressedSize=unpack(">II",f.read(8)) #big endian
        if compressedSize!=uncompressedSize: outStream.write(zlib.decompress(f.read(compressedSize)))
        else:
            magic=f.read(2)
            f.seek(-2,1) #hope that no uncompressed part starts with 78da:
            if magic=="\x78\xda": outStream.write(zlib.decompress(f.read(compressedSize)))
            else:                 outStream.write(f.read(compressedSize))   
    data=outStream.getvalue()
    outStream.close()
    return data

def zlibIdata(bytestring):
    return zlibb(StringIO(bytestring),len(bytestring))


class Stub(): pass


class Cat:
    def __init__(self,catname):
        cat2=open(catname,"rb")
        cat=sbtoc.unXOR(cat2)

        self.casfolder=os.path.dirname(catname)+"\\"
        cat.seek(0,2)
        catsize=cat.tell()
        cat.seek(16)
        self.entries=dict()
        while cat.tell()<catsize:
            entry=Stub()
            sha1=cat.read(20)
            entry.offset, entry.size, entry.casnum = unpack("<III",cat.read(12))
            self.entries[sha1]=entry
        cat.close()
        cat2.close()
       
    def grabPayload(self,entry):
        cas=open(self.casfolder+"cas_"+("0"+str(entry.casnum) if entry.casnum<10 else str(entry.casnum))+".cas","rb")
        cas.seek(entry.offset)
        payload=cas.read(entry.size)
        cas.close()
        return payload
    def grabPayloadZ(self,entry):
        cas=open(self.casfolder+"cas_"+("0"+str(entry.casnum) if entry.casnum<10 else str(entry.casnum))+".cas","rb")
        cas.seek(entry.offset)
        payload=zlibb(cas,entry.size)
        cas.close()
        return payload
     
def open2(path,mode):
    #create folders if necessary and return the file handle
    folderPath=os.path.dirname(path)
    if not os.path.isdir(folderPath): os.makedirs(folderPath)
    return open(path,mode)

resTypes={
    0x5C4954A6:".itexture",
    0x2D47A5FF:".gfx",
    0x22FE8AC8:"",
    0x6BB6D7D2:".streamingstub",
    0x1CA38E06:"",
    0x15E1F32E:"",
    0x4864737B:".hkdestruction",
    0x91043F65:".hknondestruction",
    0x51A3C853:".ant",
    0xD070EED1:".animtrackdata",
    0x319D8CD0:".ragdoll",
    0x49B156D4:".mesh",
    0x30B4A553:".occludermesh",
    0x5BDFDEFE:".lightingsystem",
    0x70C5CB3E:".enlighten",
    0xE156AF73:".probeset",
    0x7AEFC446:".staticenlighten",
    0x59CEEB57:".shaderdatabase",
    0x36F3F2C0:".shaderdb",
    0x10F0E5A1:".shaderprogramdb"
}

def dump(tocName,outpath):
    try:
        toc=sbtoc.Superbundle(tocName)
    except IOError:
        return
    
    sb=open(toc.fullpath+".sb","rb")

    chunkPathToc=os.path.join(outpath,"chunks")+"/"
    #
    bundlePath=os.path.join(outpath,"bundles")+"/"
    ebxPath=bundlePath+"ebx/"
    dbxPath=bundlePath+"dbx/"       
    resPath=bundlePath+"res/"
    chunkPath=bundlePath+"chunks/"

    
    if "cas" in toc.entry.elems and toc.entry.elems["cas"].content==True:
        #deal with cas bundles => ebx, dbx, res, chunks. 
        for tocEntry in toc.entry.elems["bundles"].content: #id offset size, size is redundant
            sb.seek(tocEntry.elems["offset"].content)
            bundle=sbtoc.Entry(sb)

            for listType in ["ebx","dbx","res","chunks"]: #make empty lists for every type to get rid of key errors(=> less indendation)
                if listType not in bundle.elems:
                    bundle.elems[listType]=Stub()
                    bundle.elems[listType].content=[]
            
            for entry in bundle.elems["ebx"].content: #name sha1 size originalSize
                casHandlePayload(entry,ebxPath+entry.elems["name"].content+".ebx")
           
            for entry in bundle.elems["dbx"].content: #name sha1 size originalSize
                if "idata" in entry.elems: #dbx appear only idata if at all, they are probably deprecated and were not meant to be shipped at all.
                    out=open2(dbxPath+entry.elems["name"].content+".dbx","wb")
                    if entry.elems["size"].content==entry.elems["originalSize"].content:
                        out.write(entry.elems["idata"].content)
                    else:          
                        out.write(zlibIdata(entry.elems["idata"].content))
                    out.close()
           
            for entry in bundle.elems["res"].content: #name sha1 size originalSize resType resMeta
                if entry.elems["resType"].content in (0x4864737B,0x91043F65,0x49B156D4,0xE156AF73,0x319D8CD0): #these 5 require resMeta. OccluderMesh might too, but it's always 16*ff
                    casHandlePayload(entry,resPath+entry.elems["name"].content+" "+hexlify(entry.elems["resMeta"].content)+resTypes[entry.elems["resType"].content])
                else:
                    casHandlePayload(entry,resPath+entry.elems["name"].content+resTypes[entry.elems["resType"].content])
                
            for entryNum in xrange(len(bundle.elems["chunks"].content)): #id sha1 size, chunkMeta::meta
                entry=bundle.elems["chunks"].content[entryNum]
                entryMeta=bundle.elems["chunkMeta"].content[entryNum]
                if entryMeta.elems["meta"].content=="\x00":
                    firstMip=""
                else:
                    firstMip=" firstMip"+str(unpack("B",entryMeta.elems["meta"].content[10])[0])

                casHandlePayload(entry,chunkPath+hexlify(entry.elems["id"].content)+firstMip+".chunk")


        #deal with cas chunks defined in the toc. 
        for entry in toc.entry.elems["chunks"].content: #id sha1
            casHandlePayload(entry,chunkPathToc+hexlify(entry.elems["id"].content)+".chunk")

    else:
        #deal with noncas bundles
        for tocEntry in toc.entry.elems["bundles"].content: #id offset size, size is redundant
            sb.seek(tocEntry.elems["offset"].content)
            try:
                bundle=Bundle.Bundle(sb)
            except:
                print "Ignoring patched noncas bundle file from: "+toc.fullpath
                continue #

            for entry in bundle.ebxEntries:
                noncasHandlePayload(sb,entry,ebxPath+entry.name+".ebx")

            for entry in bundle.resEntries:
                if entry.resType in (0x4864737B,0x91043F65,0x49B156D4,0xE156AF73,0x319D8CD0):
                    noncasHandlePayload(sb,entry,resPath+entry.name+" "+hexlify(entry.resMeta)+resTypes[entry.resType])
                else:
                    noncasHandlePayload(sb,entry,resPath+entry.name+resTypes[entry.resType])


            for entry in bundle.chunkEntries:
                if entry.meta=="\x00":
                    firstMip=""
                else:
                    firstMip=" firstMip"+str(unpack("B",entry.meta[10])[0])
                noncasHandlePayload(sb,entry,chunkPath+hexlify(entry.id)+firstMip+".chunk")

        #deal with noncas chunks defined in the toc
        for entry in toc.entry.elems["chunks"].content: #id offset size
            entry.offset,entry.size = entry.elems["offset"].content,entry.elems["size"].content #to make the function work
            noncasHandlePayload(sb,entry,chunkPathToc+hexlify(entry.elems["id"].content)+".chunk")          

def noncasHandlePayload(sb,entry,outPath):
    if os.path.exists(outPath): return
    print outPath
    sb.seek(entry.offset)
    out=open2(outPath,"wb")
    if "originalSize" in vars(entry):
        if entry.size==entry.originalSize:
            out.write(sb.read(entry.size))
        else:
            out.write(zlibb(sb,entry.size))
    else:
        out.write(zlibb(sb,entry.size))
    out.close()



cat=Cat(catName)

if "Update" in tocRoot:
    cat2=Cat(patchedCatName)
    def casHandlePayload(entry,outPath): #this version searches the patched cat first
        if os.path.exists(outPath): return #don't overwrite existing files to speed up things
        print outPath
        if "originalSize" in entry.elems:
            compressed=False if entry.elems["size"].content==entry.elems["originalSize"].content else True #I cannot tell for certain if this is correct. I do not have any negative results though.
        else:
            compressed=True
        if "idata" in entry.elems:
            out=open2(outPath,"wb")
            if compressed: out.write(zlibIdata(entry.elems["idata"].content))
            else:          out.write(entry.elems["idata"].content)

        else:        
            try:
                catEntry=cat2.entries[entry.elems["sha1"].content]
                activeCat=cat2
            except:
                catEntry=cat.entries[entry.elems["sha1"].content]
                activeCat=cat
            out=open2(outPath,"wb") #don't want to create an empty file in case an error pops up
            if compressed: out.write(activeCat.grabPayloadZ(catEntry))
            else:          out.write(activeCat.grabPayload(catEntry))

        out.close()
        

else:
    def casHandlePayload(entry,outPath): #this version uses the unpatched cat only
        if os.path.exists(outPath): return #don't overwrite existing files to speed up things
        print outPath
        if "originalSize" in entry.elems:
            compressed=False if entry.elems["size"].content==entry.elems["originalSize"].content else True #I cannot tell for certain if this is correct. I do not have any negative results though.
        else:
            compressed=True
        if "idata" in entry.elems:
            out=open2(outPath,"wb")
            if compressed: out.write(zlibIdata(entry.elems["idata"].content))
            else:          out.write(entry.elems["idata"].content)
        else:        
            catEntry=cat.entries[entry.elems["sha1"].content]
            out=open2(outPath,"wb") #don't want to create an empty file in case an error pops up
            if compressed: out.write(cat.grabPayloadZ(catEntry))
            else:          out.write(cat.grabPayload(catEntry))
        out.close()

def main():
    for dir0, dirs, ff in os.walk(tocRoot):
        for fname in ff:
            if fname[-4:]==".toc":
                print fname
                fname=dir0+"\\"+fname
                dump(fname,outputfolder)        

main()
