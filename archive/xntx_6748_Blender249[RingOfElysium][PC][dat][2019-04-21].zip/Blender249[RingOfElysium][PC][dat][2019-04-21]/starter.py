import newGameLib
from newGameLib import *
import Blender	

def datParser(filename,g):
	B=g.H(3)
	if B[0]==0:
		for i in range(B[1]):
			g.H(1)
			A1=g.i(2)
			
			t1=g.tell()
			g.seek(t1+A1[0])
			
			A2=g.i(2)
			
			t2=g.tell()
			g.seek(t2+A2[0])
			
			g.B(4)
			#boneNameCount=g.i(1)[0]
			#for m in range(boneCount):
			g.word(g.B(1)[0]-192)
			g.H(1)
			A3=g.i(3)
			g.B(4)
			c=g.i(1)[0]
			vertexInfo=[]
			#skeleton=Skeleton()
			for m in range(c):
				vertexInfo.append(g.B(12))
			boneNameCount=g.i(1)[0]
			boneNameList=[]
			for m in range(boneNameCount):
				name=g.word(g.B(1)[0]-192)
				boneNameList.append(name)
				#bone=Bone()
				#bone.name=name
				#skeleton.boneList.append(bone)
			boneCount=g.i(1)[0]	
			for m in range(boneCount):
				g.f(15)
			g.f(10)	
			
			#g.logskip=True
			
			t3=g.tell()
			mesh=Mesh()
			mesh.boneNameList=boneNameList
			mesh.TRIANGLE=True
			skin=Skin()
			mesh.skinList.append(skin)
			g.seek(t1)
			if A1[1]==2:
				mesh.indiceList=g.H(A3[2]*3)
			if A1[1]==4:
				mesh.indiceList=g.i(A3[2]*3)
			for info in vertexInfo:
				g.seek(t2)
				if info[3]==0:
					for m in range(A3[1]):
						tm=g.tell()
						g.seek(tm+info[1])
						if info[2]==3:
							mesh.vertPosList.append(g.f(3))
						if info[2]==13:
							mesh.vertPosList.append(g.half(3))
						g.seek(tm+A2[1])
						
				if info[3]==1 and info[4]==0:#uv layer id 0
					for m in range(A3[1]):
						tm=g.tell()
						g.seek(tm+info[1])
						if info[2]==2:
							mesh.vertUVList.append(g.f(2))
						if info[2]==12:
							mesh.vertUVList.append(g.half(2))
						g.seek(tm+A2[1])
						
				if info[3]==3:
					for m in range(A3[1]):
						tm=g.tell()
						g.seek(tm+info[1])
						if info[2]==6:
							mesh.skinIndiceList.append(g.B(4))
						g.seek(tm+A2[1])
						
				if info[3]==2:
					for m in range(A3[1]):
						tm=g.tell()
						g.seek(tm+info[1])
						if info[2]==3:
							mesh.skinWeightList.append(g.f(3))
						g.seek(tm+A2[1])
			mesh.draw()
			g.seek(t3)
			
			#g.logskip=False
		
	else:
		skeleton=Skeleton()
		skeleton.NICE=True
		g.seek(0)
		flag=g.i(1)[0]
		if flag==25:
			g.i(59)
		elif flag==24:
			g.i(55)
		else:
			flag=None
			print "unknow filetype"
		if flag:	
			A=g.i(12)
			START=g.tell()
			for m in range(A[0]):
				g.i(4)
			B=g.i(2)
			for m in range(B[0]):
				bone=Bone()
				bone.parentID=g.i(1)[0]
				skeleton.boneList.append(bone)
			#g.i(B[0])
			C=g.i(4)	
			D=g.i(C[0])
			t=g.tell()
			for i,d in enumerate(D):
				g.seek(t+d)
				name=g.find('\x00')
				skeleton.boneList[i].name=name
				
			#g.seek(START+A[6])
			#t=g.tell()
			#A1=g.i(20)
			g.seekpad(16)
			g.i(4)
			A1=g.i(4)
			g.i(4)
			A2=g.i(2)
			g.i(A2[1])
			A3=g.i(8)
			g.seekpad(16)
			t=g.tell()
			for m in range(A1[2]):
				skeleton.boneList[m].posMatrix=VectorMatrix(g.f(4))
				#g.f(1)
			g.seek(t+A3[7]-A3[6])	
			for m in range(A1[2]):
				skeleton.boneList[m].rotMatrix=QuatMatrix(g.f(4))
			skeleton.draw()	
		
	
	g.debug=True
	g.tell()
	print g.fileSize()	
	
def Parser(filename):
	#os.system('cls')
	sys=Sys(filename)
	if sys.ext=='dat':sys.parseFile(datParser,'rb',log=1)
	if sys.ext=='dfont':sys.parseFile(datParser,'rb',log=1)
	if sys.ext=='out':sys.parseFile(datParser,'rb',log=1)
	if sys.ext=='qsg':sys.parseFile(datParser,'rb',log=1)
 
 
	
Blender.Window.FileSelector(Parser,'import','.dat files') 
	