import newGameLib
from newGameLib import *
import Blender	




def binParser(filename,g):
	g.logOpen()
	
	txt=open('log.txt','w')
	
	#g.debug=True
	A=g.i(11)
	g.seek(A[3])
	modelOffsetList=g.i(A[1])
	g.seek(A[4])
	offsetList=g.i(A[1])
	g.i(10)
	g.i(10)
	
	
	modelList=[]
	id=0
	for m in range(A[1]):
		print '='*30 
		#meshList=[]
		model=Model(filename)
		
		modelList.append(model)
		g.seek(modelOffsetList[m])
		txt.write('model-'+str(m)+':off:'+str(g.tell())+'\n')
		tt=g.tell()
		X=g.H(4)
		txt.write(' '*4+str(tt)+':'+str(X)+'\n')
		tt=g.tell()
		X=g.f(4)
		txt.write(' '*4+str(tt)+':'+str(X)+'\n')
		tt=g.tell()
		B=g.i(15)
		#txt.write(' '*4+str(B)+'\n')
		txt.write(' '*4+str(tt)+':'+str(B)+'\n')
		#mesh=Mesh()
		#meshList.append(mesh)
		t=g.tell()
		#print t
		for n in range(B[0]):
			mesh=Mesh()
			print n,
			model.meshList.append(mesh)
			txt.write(' '*4+'='*50+str(id)+'\n')
			id+=1
			#meshList.append(mesh)
			tt=g.tell()
			X=g.f(4)	
			txt.write(' '*8+str(tt)+':'+str(X)+'\n')
			tt=g.tell()
			A=g.i(5)
			txt.write(' '*8+str(tt)+':'+str(A)+'\n')
			mesh.start=modelOffsetList[m]+A[1]
			mesh.vertCount=A[4]
			tt=g.tell()
			mesh.offsetList=g.i(13)
			txt.write(' '*8+str(tt)+':'+str(mesh.offsetList)+'\n')
			#g.seek(60,1)
			tt=g.tell()
			X=g.i(15)
			txt.write(' '*8+str(tt)+':'+str(X)+'\n')
			X=g.word(68)
			print X
			txt.write(' '*8+str(tt)+':'+str(X)+'\n')
			t=g.tell()
			
			g.seek(mesh.start)
			#txt.write(' '*12+str(g.tell())+'\n')
			
			for o in range(A[0]):#mat count
				print ' '*4,o,
				mat=Mat()
				mesh.matList.append(mat)
				#id+=1
				tt=g.tell()
				floats=g.f(5)
				txt.write(' '*12+str(tt)+':'+str(floats)+'\n')
				#g.seek(modelOffsetList[m]+A[3])			
				#B=g.f(5)
				tt=g.tell()
				C=g.i(18)
				mat.C=C
				print C[0]
				#txt.write(' '*12+str(B)+'\n')
				txt.write(' '*12+str(tt)+':'+str(C)+'\n')
			for k in range(13):
				if mesh.offsetList[k]!=0:	
					g.seek(modelOffsetList[m]+mesh.offsetList[k])
					#print k,g.tell()
					txt.write(' '*16+str(k)+'\n')
					if k==0:		
						for a in range(mesh.vertCount):
							pos=g.f(3)
							#txt.write(' '*20+str(g.tell()-12)+' '+str(a)+' pos:'+str(pos)+'\n')
							mesh.vertPosList.append(pos)
							mesh.skinIDList.append([0]*A[0])
					if k==1:
						for a in range(mesh.vertCount):g.seek(12,1)
					if k==2:
						for a in range(mesh.vertCount):
							g.seek(16,1)
					if k==4:
						for a in range(mesh.vertCount):
							uv=g.f(2)
							#txt.write(' '*20+str(g.tell()-12)+' '+str(a)+' uv:'+str(uv)+'\n')
							mesh.vertUVList.append(uv)
					if k==10:
						for a in range(mesh.vertCount):
							#g.seek(16,1)
							X=g.f(4)
							#txt.write(' '*20+str(a)+':'+str(g.tell()-16)+' '+str(X)+'\n')
							mesh.skinWeightList.append(X)
					if k==11:
						for a in range(mesh.vertCount):
							#g.seek(16,1)
							X=g.f(4)
							X=map(int,X)#.replace(255,-1)
							#txt.write(' '*20+str(a)+':'+str(g.tell()-16)+' '+str(X)+'\n')
							#print X
							mesh.skinIndiceList.append([X[0]/3,X[1]/3,X[2]/3,X[3]/3])
							
							
							
			txt.write(' '*8+'end vert data:'+str(g.tell())+'\n')
			
			for idm,mat in enumerate(mesh.matList):
			
				g.seek(modelOffsetList[m]+mat.C[9])
				indiceList=g.H(mat.C[8])
				mesh.IDStart=len(mesh.indiceList)
				mesh.indiceList.extend(indiceList)
				mesh.IDCount=len(indiceList)
				mat.TRISTRIP=True
				for indice in indiceList:
					mesh.skinIDList[indice][idm]=1
							
				g.seek(modelOffsetList[m]+mat.C[4])
				skin=Skin()
				skin.boneMap=g.H(mat.C[3])
				mesh.skinList.append(skin)
				mat.ID=mat.C[0]
			
			g.seek(t)
			
		#g.debug=True
		model.texList=[]
		g.seek(modelOffsetList[m]+B[3])
		for r in range(B[2]):
			txt.write('material:'+str(r)+'\n')
			D=g.B(8)
			txt.write(str(D)+'\n')
			name=g.word(8)
			txt.write(name+'\n')
			print r,name,
			D=g.i(1)
			txt.write(str(D)+'\n')
			for p in range(8):
				D=g.h(6)#+g.i(2)
				#print p,D[2]-2703
				txt.write(str(D)+':')
				D=g.f(27)
				txt.write(str(D)+'\n')
				
			#print 'material:',D
			D1=g.i(1)+g.f(22)
			D2=g.word(64)
			print D2
			if 'body_' in D2:
				model.texList.append(1)
			elif 'face_' in D2:
				model.texList.append(6)
			elif 'eyes_' in D2:
				model.texList.append(3)
			elif 'nail_' in D2:
				model.texList.append(4)
			elif 'black_' in D2:
				model.texList.append(7)
			elif 'headphone_' in D2:
				model.texList.append(7)
			elif 'outer_' in D2:
				model.texList.append(23)
			elif 'boots_' in D2:
				model.texList.append(10)
			elif 'skirt_' in D2:
				model.texList.append(29)
			elif 'skrt_' in D2:
				model.texList.append(20)
			elif 'gloves_' in D2:
				model.texList.append(13)
			elif 'shorts_' in D2:
				model.texList.append(23)
			else:
				model.texList.append(None)
			D3=g.f(16)
			txt.write(str(D1)+str(D2)+str(D3)+'\n')
			#break
		g.tell()
		g.debug=False
		
	print
	#for offset in offsetList:
	skeletonList=[]
	boneCount=0
	for n in range(len(offsetList)):
		g.seek(offsetList[n])
		A=g.i(16)	
		g.seek(A[0])
		modelList[n].boneMap=g.i(A[4])
		g.seek(A[1])
		skeleton=Skeleton()
		skeletonList.append(skeleton)
		skeleton.ARMATURESPACE=True
		skeleton.NICE=True
		skeleton.name='armature-'+str(n)
		for m in range(A[4]):
			bone=Bone()
			boneCount+=1
			skeleton.boneList.append(bone)
			bone.matrix=Matrix4x4(g.f(16)).invert().transpose()
		g.seek(A[2])
		nameOffsetList=g.i(A[4])	
		#for nameOffset in nameOffsetList:
		
		for m in range(A[4]):
			g.seek(nameOffsetList[m])
			skeleton.boneList[m].name=g.find('\x00')
		skeleton.draw()	

	for m in range(len(modelList)):
		model=modelList[m]
		for i,mesh in enumerate(model.meshList):
			mesh.boneNameList=skeletonList[m].boneNameList
			mesh.BINDSKELETON=skeletonList[m].name
			#list=mesh.skinList[0].boneMap
			#print model.boneMap
			#print list
			#mesh.skinList[0].boneMap=[]
			#for m in range(len(list)):
			#	mesh.skinList[0].boneMap.append(model.boneMap[list[m]])
			#mesh.draw()
			for mat in mesh.matList:
				if model.texList[mat.ID] is not None:
					mat.diffuse=g.dirname+os.sep+g.basename.replace('_obj','_tex')+'_images'+os.sep+str(model.texList[mat.ID])+'.dds'
				print i,mat.diffuse
		#model.getMat()
		model.draw()
		#model.setMat()
		#model	
		
	txt.close()		
		
	g.debug=True	
	print 'boneCount:',boneCount
	
	
	g.tell()
	g.logClose()
	
	
def texParser(filename,g):
	g.debug=True
	g.word(4)
	A=g.i(2)	
	offsetList=g.i(A[0])
	for n in range(A[0]):
	#for offset in offsetList:
		g.seek(offsetList[n])
		g.word(4)
		B=g.i(1)+g.B(4)
		offsetBList=g.i(B[0])
		g.tell()
		for m in range(B[0]):
		#for offsetB in offsetBList:
			g.seek(offsetList[n]+offsetBList[m])
			g.word(4)
			C=g.i(5)
			if m==0:
				image=imageLib.Image()
				image.name=g.dirname+os.sep+g.basename+'_images'+os.sep+str(n)+'.dds'
				image.szer=C[0]
				image.wys=C[1]
				if C[2]==6:image.format='DXT1'
				if C[2]==7:image.format='DXT3'
				if C[2]==9:image.format='DXT5'
				image.data=g.read(C[4])
				image.draw()
			
		
	g.tell()
	
def Parser(filename):	
	print
	print filename
	print
	ext=filename.split('.')[-1].lower()	
	
	if ext=='bin':
	
		if '_obj.bin' in filename:
			file=open(filename,'rb')
			g=BinaryReader(file)
			binParser(filename,g)
			file.close()
			
		if '_tex.bin' in filename:
			file=open(filename,'rb')
			g=BinaryReader(file)
			texParser(filename,g)
			file.close()
 
	
Blender.Window.FileSelector(Parser,'import','Dreamy Theater PS3 files: *.bin') 
	