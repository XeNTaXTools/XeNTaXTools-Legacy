// WaveWriter.h : Functions for writing wave files
//

#pragma once

typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;

void PrepareWaveHeader(std::ostream& Output);
void WriteWaveHeader(std::ostream& Output, unsigned long SampleRate, \
					 unsigned char BitsPerSample, unsigned char Channels, \
					 unsigned long NumberSamples);
