
#include "mot.h"

//+----------------------------------------------------------------> cMot()

cMot::cMot()
{
}

//+----------------------------------------------------------------> Delete()

void cMot::Delete()
{
}

//+----------------------------------------------------------------> Load()

bool cMot::Load(const char *strMot)
{
	// open the file and check signature
	FILE *pFile = fopen(strMot, "rb");
	if(!pFile)
	{
		printf("Can't open MOT file [%s] !\n", strMot);
		return false;
	}
	fread(this, 16, 1, pFile);
	if((m_uiTag != 0x00746F6C) && (m_uiInfoOffset != 0x10000000))
	{
		printf("Invalid MOT file [%s] !\n", strMot);
		return false;
	}

	// the last track is never used
	Moto2Intel(m_usFrameNum);
	Moto2Intel(m_uiTrackNum);
	m_uiTrackNum--;

	// read all the tracks
	m_pTrack = new cMotTrack[m_uiTrackNum];
	fread(m_pTrack, sizeof(cMotTrack), m_uiTrackNum, pFile);

	// go through all the tracks
	for(unsigned int a = 0; a < m_uiTrackNum; a++)
	{
		Moto2Intel(m_pTrack[a].uiOffset);
	}

	//cMotTrackFake pTrack[255];
	//fread(pTrack, sizeof(cMotTrackFake), 255, pFile);

	//float pi = 3.141592653f;
	//FILE *bFile = fopen("d:/anim.txt", "wt");
	//for(unsigned int a = 0; a < m_uiTrackNum; a++)
	//{
	//	Moto2Intel(pTrack[a].fKey);
	//	Moto2Intel(pTrack[a].usBoneId);
	//	fprintf(bFile, "bone_%d:\t", pTrack[a].usBoneId);
	//	switch(pTrack[a].usType)
	//	{
	//	case 3:
	//		fprintf(bFile, "x: %f\t", pTrack[a].fKey * (180.0f / pi));
	//		break;
	//			
	//	case 4:
	//		fprintf(bFile, "z: %f\t", pTrack[a].fKey * (180.0f / pi));
	//		break;

	//	case 5:
	//		fprintf(bFile, "y: %f\t\n", -pTrack[a].fKey * (180.0f / pi));
	//		break;
	//	}
	//	fprintf(bFile, "\n");
	//}
	//fclose(bFile);

	//unsigned int zz = ftell(pFile);
	//zz = 0;

	fclose(pFile);
	return true;
}

//+----------------------------------------------------------------> 