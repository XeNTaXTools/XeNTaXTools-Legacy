
#ifndef _MOT_H
#define _MOT_H

#include "main.h"

//+----------------------------------------------------------------> cMotFrame
// in case of a coded frame

struct cMotFrameSub6
{
	BYTE					ucDuration;
	BYTE					ucData[3];
};

struct cMotFrame6
{
	short					fData[6];			// convert to float16
	cMotFrameSub6			*pSub;
};


struct cMotFrameSub4
{
	unsigned short			usId;				// current frame
	unsigned short			usData[3];
};

struct cMotFrame4
{
	float					fData[6];
	cMotFrameSub4			*pSub;
};

//+----------------------------------------------------------------> cMotTrack

struct cMotTrack
{
	unsigned short			usBoneId;
	BYTE					ucKeyId;			// 0, 1, 2, 3, 4, 5, 7, 8, 9 pos(x, y, z) rot(x, y, z) scale(x, y, z)
	BYTE					ucKeyType;			// 0: float and here, 4: offset to keyframe, 6: 
	unsigned short			usFrameNum;
	unsigned short			usInconnu;			// 0xFFFF
	unsigned int			uiOffset;
};

//+----------------------------------------------------------------> cMot

class cMot
{
public:
							cMot();

	bool					Load(const char *strMot);
	void					Delete();

private:

	unsigned int			m_uiTag;			// MOT
	unsigned short			m_usVersion;		// 0/1
	unsigned short			m_usFrameNum;		// frames in this animation
	unsigned int			m_uiInfoOffset;		// 16
	unsigned int			m_uiTrackNum;

	cMotTrack				*m_pTrack;
};

#endif