# author: Volfin

import bpy
import bmesh
import os
import sys
import mathutils
import math
import platform
import imp
import csv
from bpy_extras.io_utils import unpack_list
from struct import *
from mathutils import Vector, Matrix, Quaternion, Euler
import time
import random
from collections import Counter

debug = False;
MAGIC_SIG=0x2E; # file record signature
SKEL_SIG= 0x02; # skeleton sig
HEADER_OFFSET = 0x14; # data tables are just past header of this size
models_ptr = []  # list of model classes
objects_ptr = []  # list of object data structures.
model_data = [] # list of dictionaries of data for each model in the file.
material_data = [] # list of dictionaries of data for each material.
mat_instance_data = [] # list of dictionaries of data for each models materials.
phys_names = [] # list of breakable zone names
phys_area_defines = [] # if a breakable item, this list defines which vertices belong to which 'submesh' defined in an extra table.
highest_layer = 0 # keep track of highest layer used.

def to_blender_matrix(bl_mat):
    mat = mathutils.Matrix()
    for i, col in enumerate(bl_mat):
        for k, val in enumerate(col):
            mat[k][i] = val
    return mat

# ugly but necessary, the operation doesn't return the new object when splitting/separating a mesh,
# so you have to do this garbage to find out what the new object reference is.
# function assumes proper setup (blender is in edit mode, faces/edges/verts are pre-selected)
def my_mesh_separate():
    #get list of objects before splitting
    lo_b = [ob for ob in bpy.data.objects if ob.type == 'MESH']
    #split
    try:
        bpy.ops.mesh.separate(type="SELECTED")
    except:
        return ["FAIL"]
    #get list of objects after splitting
    lo_a = [ob for ob in bpy.data.objects if ob.type == 'MESH']

    #compare the two lists until we find what is new.
    for i in lo_b:
        lo_a.remove(i)
        
    return lo_a

# Who knew it took all this mess just to change the active layer?
def my_layer_change(nm=1,ext=False,togg=True):
    scene = bpy.context.scene
        
    for window in bpy.context.window_manager.windows:
        screen = window.screen
        
        for area in screen.areas:
            if area.type == 'VIEW_3D':
                override = {'window': window, 'screen': screen, 'scene': scene, 
                'area': area, 'region': area.regions[4],
                'blend_data': bpy.context.blend_data}

                bpy.ops.view3d.layers(override, nr=nm, extend=ext, toggle=togg)


def import_mesh(context, randomize_colors, import_vertcolors, use_layers, break_phys, mesh_scale, has_skeleton):
    
    global model_name,models_ptr,objects_ptr,model_data,material_data,mat_instance_data,phys_names,phys_area_defines
    SWAP_YZ_MATRIX = mathutils.Matrix.Rotation(math.radians(90.0), 4, 'X')

    # lets just do this to be sure    
    if bpy.ops.object.mode_set.poll():
        bpy.ops.object.mode_set(mode='OBJECT')
    #else:
    #    print("mode_set() context is incorrect, current mode is", bpy.context.mode)

    # read in mesh data
    models_ptr = []
    objects_ptr = []
    model_data = []
    material_data = []
    mat_instance_data = []
    phys_names = []
    phys_area_defines = []

    UV2=[]
    UV3=[]
    colors=[]
    colors2=[]

    first_table_len = BI(1)[0]
    second_table_len = BI(1)[0]
    third_table_len = BI(1)[0]
    index_size = BI(1)[0] # this is how many bytes per face index
    
    if debug:
        print("Param table size:"+str(first_table_len))
        print("Vertex table size:"+str(second_table_len))
        print("Face table size:"+str(third_table_len))
        
    print("Face index size:"+str(index_size))

    param_table_address = first_table_len+(second_table_len)+ (third_table_len * index_size); # table of bytes, table of floats, and table of face indices
    # param table is past data tables
    filehandle.seek(param_table_address,1) #SEEK_CUR

    #play the fun pick and choose data game
    phys_entries=BI(1)[0] # This table is defined on 'breakable' items and skinned items. for breakables it defines submeshes, for skinned it's bone groups.

    if phys_entries:
        if debug:
            print("\r\nBreakable Phys/Bone Table found.")
        for x in range(0, phys_entries):
            name = file_str(BI(1)[0])
            phys_names.extend([name])
            if debug:
                print("Phys/Bone entry:"+name)
            Bf(16)
            BI(1)
        
    BI(3) #skip
    BI(BI(1)[0]) # skip number of items stored here.
    BI(11) #skip

    model_count = BI(1)[0]
    material_count = BI(1)[0]
    print("\r\nBase Model Count:"+str(model_count)+" Base Material Count:"+str(material_count))
    for x in range(0, material_count):
        BI(3) #skip
        mat_name = file_str(BI(1)[0])
        print("\r\nMaterial Name:"+mat_name)
        mat_type = file_str(BI(1)[0])
        print("Material Type:"+ mat_type)
        mat_path = file_str(BI(1)[0])
        print("Material Path:"+ mat_path)
        BI(6) #skip
        shader_entry_count = BI(1)[0] # usually 0x10
        print("Shader parameter count:"+str(shader_entry_count))
        #there are many shader entry types, with different numbers of parameters. So, we have to check the type and act accordingly.

        material_data.append({'MAT_NAME':mat_name,'MAT_TYPE':mat_type,'MAT_PATH':mat_path}) # get the ball rolling on the dictionary entry

        for y in range(0,shader_entry_count):
            name_start = filehandle.tell()
            shader_name = file_str(BI(1)[0])
            shader_type = BI(1)[0]
            
            if shader_type == 0x0C: # Boolean
                v1 = BI(1)[0]
                print("Shader Param:"+shader_name+"\r\n     Boolean:"+str(v1))
                material_data[x].update({shader_name:v1})
            elif shader_type == 0x00: # Float
                v1 = Bf(1)[0]
                print("Shader Param:"+shader_name+"\r\n     Float:"+str(v1))
                material_data[x].update({shader_name:v1})
            elif shader_type == 0x01: # Range
                v1 = Bf(1)[0]
                v2 = Bf(1)[0]
                print("Shader Param:"+shader_name+"\r\n     Range:"+str(v1)+", "+str(v2))
                material_data[x].update({shader_type:str(v1)+","+str(v2)}) 
            elif shader_type == 0x03: #Color
                v2 = Bf(1)[0]
                v3 = Bf(1)[0]
                v4 = Bf(1)[0]
                v5 = Bf(1)[0]
                print("Shader Param:"+shader_name+"\r\n     Color: R:"+str(v2)+", G:"+str(v3)+", B:"+str(v4)+", A:"+str(v5))
                material_data[x].update({shader_type:str(v2)+","+str(v3)+","+str(v4)})
            elif shader_type == 0x02: #Vector
                v2 = Bf(1)[0]
                v3 = Bf(1)[0]
                v4 = Bf(1)[0]
                print("Shader Param:"+shader_name+"\r\n     Vector: X:"+str(v2)+", Y:"+str(v3)+", Z:"+str(v4))
                material_data[x].update({shader_type:str(v2)+","+str(v3)+","+str(v4)})            
            elif shader_type == 0x09: # Texture map
                v2 = BI(1)[0]
                path = file_str(v2)
                print("Shader Param:"+shader_name+"\r\n     Texture Map Path:"+path)  
                material_data[x].update({shader_type:path})
            elif shader_type == 0x08: # Texture Sampler
                if debug:
                    print("Shader Param:"+shader_name+"\r\n     Texture Sampler")
            else:
                print("Param:"+shader_name+" Shader Type:"+str(shader_type))
                print("Unknown shader type at "+str(name_start)+"!")
                return 3

        #print(material_data[x])

    if debug:
        print("End Materials:"+str(filehandle.tell()))
    # these are tables indexing what materials to use for what LOD instances
    mat_map_entry_count = BI(1)[0]
    material_map = BI(mat_map_entry_count) # skip number of items stored here.

    # a model can have alternate sets of materials (for instance the bicycle has green (default), blue, and red)
    # alternates are noted but not used for now.
    alt_material_count = BI(1)[0]
    if alt_material_count != 0:
        print ("\r\nFile contains alternante material maps:")
        for x in range(0, alt_material_count):
            print(" Alt:"+file_str(BI(1)[0]))
            print(" Map:"+str(BI(mat_map_entry_count)))
        
    BI(BI(1)[0]) # seems to be a duplicate material map but may need later.

    mat_table_entry_count=BI(1)[0]
    table_var_count = 0
    if debug:
        print("\r\nMaterial Table Entry Count:"+str(mat_table_entry_count))
    
    #the data in the upcoming table define what faces go to what material    
    for x in range(0,mat_table_entry_count):
        if debug:
            print("--- Entry:"+str(x))
            
        lod_num = BI(1)[0]
        vertice_count = BI(1)[0] #always the same for every material, not really used, as it's duplicated in model table.
        face_count = BI(1)[0] #number of faces belonging to this material
        param_table_offset = BI(1)[0] #not used for materials
        vertice_table_offset = BI(1)[0] #not used for materials
        face_table_offset = BI(1)[0] # defines where in the face table this material starts. (i suspect it's consecutive runs of faces anyway, so probably not needed. value is pre-multipled by 3 since 3 shorts per face.
        
        BI(12) #skip
        table_var_count = BH(1)[0] # variable count of data here
        if debug:
            print("Table variable count:"+str(table_var_count))
        BH(1) #skip (maybe another count?)
        ParamBlockHashes=BI(table_var_count) #these outline what can be found in the param data block, important!
        if debug:
            print("Shader Table:")
            for d,h in enumerate(ParamBlockHashes):
                print(str(d)+": "+hex(h))
        BI(1) #skip
        Bh(1) #skip
        Bf(1) #skip

        if debug:
            print("--------------------------")
            print('LOD_NUM:'+str(lod_num)+' VERT_CNT_NA:'+str(vertice_count)+' FACE_COUNT:'+str(face_count)+' PARAM_OFFN_NA:'+str(param_table_offset)+' VERT_OFF_NA:'+str(vertice_table_offset)+' FACE_OFFSET:'+str(face_table_offset)+' MAT_MAP:'+str(material_map[x]))
            print('BLOCK_HASHES:'+str(ParamBlockHashes))
            
        mat_instance_data.append({'LOD_NUM':lod_num,'VERT_COUNT':vertice_count,'FACE_COUNT':face_count,'PARAM_OFFSET':param_table_offset,'VERT_OFFSET':vertice_table_offset,'FACE_OFFSET':face_table_offset,'BLOCK_HASHES':ParamBlockHashes,'MAT_MAP':material_map[x]})
               

    if debug:
        print("--------------------------\r\n") 
        #print(str(mat_instance_data))
        
    #number of models stored in this file (likely LODs)
    entry2_count = BI(1)[0]
    print("Model table entry count:"+str(entry2_count))

    carpet_fix = False
    if entry2_count == 0 or True:
        print("Stupid carpet probably...")
        entry2_count = mat_table_entry_count
        carpet_fix = True

    #the data in the upcoming table define what faces go to what model
    #for now i just ignore the table at the end of mysterious floats.
    if debug:
        print("\r\n--------------------------") 
    last_lod_num = -1
    last_face_offset = 0
    last_face_count = 0
    for x in range(0,entry2_count):

        lod_num = 0
        vertice_count = 0
        face_count = 0
        param_table_offset = 0
        vertice_table_offset = 0
        face_table_offset = 0
        
        if carpet_fix:
            lod_num = mat_instance_data[x]['LOD_NUM']
            vertice_count = mat_instance_data[x]['VERT_COUNT']
            face_count = mat_instance_data[x]['FACE_COUNT']
            param_table_offset = mat_instance_data[x]['PARAM_OFFSET']
            vertice_table_offset = mat_instance_data[x]['VERT_OFFSET']
            face_table_offset = mat_instance_data[x]['FACE_OFFSET']
            ParamBlockHashes = mat_instance_data[x]['BLOCK_HASHES']
        else:
            lod_num = BI(1)[0]
            vertice_count = BI(1)[0]
            face_count = BI(1)[0]
            param_table_offset = BI(1)[0]
            vertice_table_offset = BI(1)[0]
            face_table_offset = BI(1)[0]
        
            BI(12) #skip
            table_var_count = BH(1)[0] # variable count of data here
            if debug:
                print("Table variable count:"+str(table_var_count))
            BH(1) #skip (maybe another count?)
            ParamBlockHashes=BI(table_var_count) #these outline what can be found in the param data block, important!        
            BI(1) #skip
            Bh(1) #skip
            Bf(1) #skip

        if lod_num == last_lod_num:
            # model entry is part of the same model, combine
            fudge_factor = 0
            # we have to check offsets against counts, because sometimes things get skipped?? Transparent items it seems
            if (face_table_offset - (last_face_count * 3)) != last_face_offset:
                #calculate how many extra faces to fudge in there
                false_offset = face_table_offset - (last_face_count * 3)
                fudge_factor = (false_offset - last_face_offset) // 3  # integer division
            
            curr_face_count = model_data[last_lod_num]['FACE_COUNT']
            model_data[last_lod_num].update({'FACE_COUNT':curr_face_count+face_count+fudge_factor})
            if debug:
                print('LOD_NUM:'+str(last_lod_num)+' ADDED:'+str(face_count)+' FACE_COUNT:'+str(curr_face_count+face_count))
                print("Fudge Factor:"+str(fudge_factor))
        else:
            if debug:
                print("--------------------------")
                print('LOD_NUM:'+str(lod_num)+' VERT_COUNT:'+str(vertice_count)+' FACE_COUNT:'+str(face_count)+' PARAM_OFFSET:'+str(param_table_offset)+' VERT_OFFSET:'+str(vertice_table_offset)+' FACE_OFFSET:'+str(face_table_offset))
                print('BLOCK_HASHES:'+str(ParamBlockHashes))
                
            model_data.append({'LOD_NUM':lod_num,'VERT_COUNT':vertice_count,'FACE_COUNT':face_count,'PARAM_OFFSET':param_table_offset,'VERT_OFFSET':vertice_table_offset,'FACE_OFFSET':face_table_offset,'BLOCK_HASHES':ParamBlockHashes})
            last_lod_num = lod_num

        last_face_offset = face_table_offset
        last_face_count = face_count

    if debug:
        print("--------------------------\r\n")

    #begin constructing meshes
    last_face_offset = 0
    
    for x in range(0,model_count):
        print("\r\nGenerating Model LOD "+str(x))

        # super kludge check here: some models don't seem to have a block entry for transparent/decal sections... we check to see if that's the case and if so we fake an entry.
        # this may fail spectacularly, only time will tell
        if model_data[x]['FACE_OFFSET'] != (last_face_offset):
            print("\r\nAdjusting for missing transparent faces")
            # most models start at the face table's start, so offset should be zero.
            #if not, then likely the first block of data is just being ignored!
            # so we copy the first block, modify it and tack it on the start as a new model block.

            if debug:
                print("Face Count:"+str(model_data[x]['FACE_COUNT'])+" face offset:"+str(model_data[x]['FACE_OFFSET'])+" Last face offset:"+str(last_face_offset))
            

            extra_face_count = ((model_data[x]['FACE_OFFSET'] // 3) - (last_face_offset // 3))
            model_data[x]['FACE_COUNT'] = model_data[x]['FACE_COUNT'] + extra_face_count
            model_data[x]['FACE_OFFSET'] = model_data[x]['FACE_OFFSET'] - (extra_face_count * 3)

            if debug:
                print("Extra faces:"+str(extra_face_count))
                print("New results: Face Count:"+str(model_data[x]['FACE_COUNT'] + extra_face_count)+" face offset:"+str(model_data[x]['FACE_OFFSET'] - (extra_face_count * 3)))

        last_face_offset = last_face_offset + (model_data[x]['FACE_COUNT'] * 3)

        #########################################
        ## VERTICES
        #########################################
        
        filehandle.seek(HEADER_OFFSET+first_table_len+model_data[x]['VERT_OFFSET'],0) #SEEK_SET  Jump to vertice table start
        if debug:
            print("Jumping to vertice table location:"+str(filehandle.tell()))
        
        vertex=[]
        phys_area_defines=[]
        w_count=[]
        m_weights=[]
        g_indices=[]

        # we check for certain types of param hashes (and how many, since it seems they can be used more than once to stack things
        # i.e. if the param hash for indices and weights appears twice, the model has 8 weight per vertice instead of 4.
        # 0x3040100 = tangents? (four bytes) (a given, always present)
        # 0x1080100 = binormals? (four shorts) (a given, always present)
        # 0x2070100 = uv mapping (two shorts)  (a given, always present)
        # 0x4040100 = unknown data (four bytes) (in param block after UVs)
        # 0x50F0000 = breakable/mechanical weights (four bytes)
        # 0x5050000 = Byte length Indices (four bytes)
        # 0x50d0000 = Short length Indices (four shorts)
        # 0x6050000 = byte length Weights (four bytes) (so far haven't seen that there's short length weights, probably aren't)
        
        counts=Counter(model_data[x]['BLOCK_HASHES'])
        if debug:
            print("Param Hash Counts:"+str(counts))

        is_breakable = False;
        is_skinned = False;
        is_short_indices = False; # false = byte, true = short
        weights_per_vert = 0; # 4 if single hash or 8 if double hashes or hell, 12 if three sets of hashes (Remedy may go there)
        has_extra_block = False; # some models have this block, feeding into vertice colors for now for examination. (but probably not vertex colors)

        if 0x50F0000 in counts:
            is_breakable = True
        if 0x6050000 in counts:
            is_skinned = True
            if 0x50d0000 in counts:
                is_short_indices = True
            weights_per_vert = 4 * counts[0x6050000] # who knows, some model could have more than 2 sets so lets be flexible
        if 0x4040100 in counts:
            has_extra_block = True;
            
        if debug:
            print("Final Configuration: is_breakable:"+str(is_breakable)+" is_skinned:"+str(is_skinned)+" is_short_indices:"+str(is_short_indices)+" weights_per_vert:"+str(weights_per_vert)+" has_extra_block:"+str(has_extra_block)+"\r\n")
            
        for y in range(0,model_data[x]['VERT_COUNT']):
            tmp=Bf(3)
            vertex.extend([(tmp[0]*-1,tmp[1],tmp[2])]) #flip on X Axis

            if is_breakable: # either mechanical rigging or breakable split, depending if there's a skeleton
                idx = BI(1)[0]                
                phys_area_defines.extend([idx])
            elif is_skinned: # fully rigged model, usually
                w_count.extend([weights_per_vert]) #track how many weights per vertice
                idx = []
                # models can have more than 256 bones, if so they use a short for bone indices instead of a byte.
                if is_short_indices:
                    idx= BH(weights_per_vert)
                else:
                    idx=BB(weights_per_vert)
                    
                weights = BB(weights_per_vert) # weights

                if weights_per_vert == 4:
                    g_indices.extend([(idx[0],idx[1],idx[2],idx[3])])
                    m_weights.extend([(weights[0]/255.0,weights[1]/255.0,weights[2]/255.0,weights[3]/255.0)])
                elif weights_per_vert == 8:
                    g_indices.extend([(idx[0],idx[1],idx[2],idx[3],idx[4],idx[5],idx[6],idx[7])])
                    m_weights.extend([(weights[0]/255.0,weights[1]/255.0,weights[2]/255.0,weights[3]/255.0,weights[4]/255.0,weights[5]/255.0,weights[6]/255.0,weights[7]/255.0)])
                else:
                    print("\r\nWe found a model that actually has more than 8 weights per vertex, failing for examination!")
                    return 4


        if debug:    
            print("Model "+str(x)+" vertex array length:"+str(len(vertex)))
        
        #########################################
        ## FACES
        #########################################
        
        filehandle.seek(HEADER_OFFSET+first_table_len+second_table_len+(model_data[x]['FACE_OFFSET']*index_size),0) #SEEK_SET  Jump to face table start
        if debug:
            print("Jumping to face table location:"+str(filehandle.tell()))
        
        faces=[]
        face_idx=[]
        for y in range(0,model_data[x]['FACE_COUNT']):

            if index_size == 2:
                tmp=BH(3) 
                faces.extend([(tmp[2],tmp[1],tmp[0])]) #flip normals
            elif index_size == 4:
                tmp=BI(3) 
                faces.extend([(tmp[2],tmp[1],tmp[0])])
                
            face_idx.extend([0]) #initialize for fill-in later

        if debug:
            print("Model "+str(x)+" faces array length:"+str(len(faces)))

        #########################################
        ## NORMALS AND UVs
        #########################################
        
        filehandle.seek(HEADER_OFFSET+model_data[x]['PARAM_OFFSET'],0) #SEEK_SET  Jump to parameter table start
        if debug:
            print("Jumping to parameter table location:"+str(filehandle.tell()))

        normals=[]
        uvs=[]
        for y in range(0,model_data[x]['VERT_COUNT']):
            #parameter block is 16 bytes long (not sure if this is constant)
            tmp=BB(4)
            tmp2=Bh(4) #skip
            uvdat=BH(2)            
            if bpy.app.version[1] > 74:
                na = ((tmp2[0]/32767.0),(tmp2[1]/32767.0),(tmp2[2]/32767.0))
                normals.extend([na])
            else:
                normals.extend([tmp[0],tmp[1],tmp[2]])
            
            uvs.extend([((uvdat[0]/4095.0), (1.0-(uvdat[1]/4095.0)))]) # v axis was flipped

            if has_extra_block:
                tmp2 = BB(4)
                colors.extend([((tmp2[0])/255.0,(tmp2[1])/255.0,(tmp2[2])/255.0)])

        if debug:
            print("Model "+str(x)+" normals array length:"+str(len(normals)))
            print("Model "+str(x)+" UV1 array length:"+str(len(uvs)))
        
        #########################################
        ## MODEL CONSTRUCTION
        #########################################
        
        #Build initial object here
        me = bpy.data.meshes.new(model_name+str(model_data[x]['LOD_NUM']))
        models_ptr.extend([me]) #store for later
        me_obj = bpy.data.objects.new(model_name+str(model_data[x]['LOD_NUM']),me)
        me_obj.select = True # makes selected

        objects_ptr.extend([me_obj]) #store for later
        context.scene.objects.link(me_obj)
        context.scene.objects.active = me_obj # makes active
        if debug:
            #print("vertices:"+str(vertex))
            #print("faces:"+str(faces))
            #print("normals"+str(normals))
            pass

        try:
            me.from_pydata(vertex,[],faces)
            #me.vertices.foreach_set("normal",normals) # add normals
        except:
            print("Failed mesh creation")
            #pass
            return 1

        ###############################################
        ## Do Normals
        ###############################################
        if bpy.app.version[1] > 74:
            #print("doing new normals thing")
            me.create_normals_split()
            me.use_auto_smooth = True
            me.auto_smooth_angle = 1.169370564  # 67 degrees
            me.show_edge_sharp = True
            #me.validate(clean_customdata = False) #seems to break some meshes.
            #me.normals_split_custom_set_from_vertices(normals) # comment out if not working
            me.free_normals_split()
            me.update()
            #me.vertices.foreach_set("normal",normalArray) # add normals
            #me.polygons.foreach_set("use_smooth", [True] * len(me.polygons))
        #else:    
        #    # set to smooth shaded	
        bpy.ops.object.shade_smooth()

        ###############################################
        ## Material Data
        ###############################################
        curr_slot_index = -1
        for y in range(0,mat_table_entry_count): #was material_count

            if debug:
                print(" - Checking Material "+str(y)+": LOD_NUM:"+str(mat_instance_data[y]['LOD_NUM'])+" against model num:"+str(x))
                
            if mat_instance_data[y]['LOD_NUM'] == x: # if it's for this model

                #record contains which material to use
                local_mat_num = mat_instance_data[y]['MAT_MAP']
                matName = material_data[local_mat_num]['MAT_NAME']

                mat = bpy.data.materials.new(matName)
                bpy.ops.object.material_slot_add()
                curr_slot_index = curr_slot_index + 1
                
                mat.diffuse_intensity = 1.0 #full bright

                me_obj.material_slots[curr_slot_index].material = mat
                print("setting materials slot "+str(curr_slot_index)+" to "+str(mat))

                count = mat_instance_data[y]['FACE_COUNT']
                start = (mat_instance_data[y]['FACE_OFFSET'] - model_data[x]['FACE_OFFSET']) // 3 # is in terms of face indices which are 3 per face (integer division)
                end_offset=int(start + count) # add start + offset
                if debug:
                    print("START:"+str(start)+" END:"+str(end_offset-1))

                for j in range(start,end_offset): # Start number, count (non-inclusive)
                    if debug:
                        #print("assigning material ",curr_slot_index," to index ",j)
                        pass
                    face_idx[j] = curr_slot_index

                if randomize_colors:
                    mat.diffuse_color = randomColor()

        # material index
        #print("Face_IDX:"+str(face_idx))
            
        me.polygons.foreach_set("material_index",face_idx) # should set multiple mat indexes.

        ###############################################
        ## Do UVs
        ###############################################
        if len(uvs) != 0:
            me.uv_textures.new(name='UV_0')
            uv_data = me.uv_layers[0].data
            for i in range(len(uv_data)):
                uv_data[i].uv = uvs[me.loops[i].vertex_index]
        if len(UV2) != 0:
            me.uv_textures.new(name='UV_1')
            uv_data = me.uv_layers[1].data
            for i in range(len(uv_data)):
                uv_data[i].uv = UV2[me.loops[i].vertex_index]
        if len(UV3) != 0:
            me.uv_textures.new(name='UV_2')
            uv_data = me.uv_layers[2].data
            for i in range(len(uv_data)):
                uv_data[i].uv = UV3[me.loops[i].vertex_index]

        ###############################################
        ## Do Vertex Color
        ###############################################

        if len(colors) != 0 and import_vertcolors:
            print("Doing Vertex Colors")
            me.vertex_colors.new(name='Color_Data')
            color_data = me.vertex_colors[0].data
            for i in range(len(color_data)):
                color_data[i].color = colors[me.loops[i].vertex_index]
        if len(colors2) != 0 and import_vertcolors:
            me.vertex_colors.new(name='Color_Data2')
            color_data = me.vertex_colors[1].data
            for i in range(len(color_data)):
                color_data[i].color = colors2[me.loops[i].vertex_index]

        ###############################################
        ## Finalize
        ###############################################

        # finalize mesh
        #print("finalize me:"+str(me)+" - "+str(me_obj))
        me.update(calc_edges=True)

        #scale
        scale_matrix = mathutils.Matrix.Scale(1.0*mesh_scale, 4)

        #global_trans = to_blender_matrix(mesh.global_transform())
        me_obj.matrix_basis = SWAP_YZ_MATRIX * scale_matrix#* global_trans
        
        # apply transforms (rotation) 
        bpy.ops.object.transform_apply(location=False,rotation=True,scale=True)

        if use_layers:
            # place mesh on incremental layer
            me_obj.layers[x] = True
            highest_layer = x
            
            #wipe other layers
            for i in range(20):
                # if there's ever more than 20 meshes, we are in trouble. But i doubt that happens.
                me_obj.layers[i] = (i == x)

        #if breakable mesh and splitting is enabled, split.
        # because phys indices are non-contiguous, i found the simplest way to handle this is to
        # assign the vertices to a vertex group based on their index, then split by vertex group.
        # this solves the fact that cutting non-contiguous sequences of vertices would cause vertex reordering and break subsequent lists.
        if is_breakable and break_phys:
            print("\r\nPhys: Breaking mesh into defined pieces")

            #we need to make this mesh's layer active or stuff fails
            my_layer_change(x+1,False,False)

            if debug:
                print("Iterating over "+str(len(phys_area_defines))+" entries in 'phys_area_defines'")
                print("'phys_names' length is "+str(len(phys_names)))
                
            for i,v in enumerate(phys_area_defines):
                #if debug:
                #    print("bone index for "+str(i)+" is "+str(v))
                bone_name = phys_names[v]
                group = None
                if bone_name in me_obj.vertex_groups.keys():
                    group = me_obj.vertex_groups[bone_name]
                    
                if group == None:
                    group = me_obj.vertex_groups.new(bone_name)

                group.add([i], 1.0, 'ADD') #add vertex to group

            #origin_name = bpy.context.active_object.name
            keys = bpy.context.object.vertex_groups.keys()
            split_objects = []

            bpy.ops.object.mode_set(mode="EDIT")
            for gr in keys:                
                # Set the vertex group as active
                bpy.ops.object.vertex_group_set_active(group=gr)

                # Deselect all verts and select only current VG
                bpy.ops.mesh.select_all(action='DESELECT')
                bpy.ops.object.vertex_group_select()

                new_obj = my_mesh_separate()
                if new_obj[0] == "FAIL":
                    print("Failed to split 'Breakable' mesh.")
                    return 2
                
                split_objects.append(new_obj[0])

            for i in range(0, len(split_objects)):
                split_objects[i].name = '{}.{}'.format(model_name, phys_names[i])
                split_objects[i].data.name = phys_names[i]
                
            bpy.ops.object.mode_set(mode='OBJECT')

            #delete empty original object            
            bpy.ops.object.select_all(action='DESELECT') # Deselect all
            me_obj.select = True

            #remove it from our list
            objects_ptr.remove(me_obj)
            bpy.ops.object.delete()

            #add split objects instead (also remove the vertex groups if no skeleton, they aren't needed anymore)
            for nu_ob in split_objects:
                if not has_skeleton:
                    for name in phys_names:
                        vg = nu_ob.vertex_groups.get(name)
                        if vg is not None:
                            nu_ob.vertex_groups.remove(vg)
                        
                objects_ptr.extend([nu_ob])                

        ##############################################
        ## Create regular bone groups
        ##############################################
        if is_skinned:
            for n, indices in enumerate(g_indices):
                for p,index in enumerate(indices):
                    
                    # name is index
                    bone_name = phys_names[index]
                    #print("p is:",p," index is:",index," Name is:",bone_name)
                    # use existing group or new
                    group = None
                    if bone_name in me_obj.vertex_groups.keys():
                        group = me_obj.vertex_groups[bone_name]
                    if group == None:
                        group = me_obj.vertex_groups.new(bone_name)
                    
                    # do weight                    
                    weight = m_weights[n][p]
                    if weight == 0: # no weight = no influence, so not acutally used
                        continue;
                    
                    group.add([n], weight, 'ADD')

        #reset selection
        me_obj.select = False

        #lets go back to first layer just to be consistent
        my_layer_change(1,False,False)


    return 0 # all fine

##################################################################

def createRig(name, origin, boneTable):

    # Create armature and object
    bpy.ops.object.add(
        type='ARMATURE', 
        enter_editmode=True,
        location=origin)
    
    ob = bpy.context.object
    ob.show_x_ray = True
    ob.data.draw_type = 'STICK'
    ob.name = name
    amt = ob.data
    amt.name = name+'Amt'
    amt.show_axes = False
 
    # Create bones
    bpy.ops.object.mode_set(mode='EDIT')
    for (bname, pname, vector) in boneTable:    
        bone = amt.edit_bones.new(bname)
        if pname:
            parent = amt.edit_bones[pname]
            bone.parent = parent
            bone.head = parent.tail
            bone.use_connect = False
            if vector[0]+vector[1]+vector[2] < 0.0001:
                vector = (0,0.0001,0) # try to prevent zero length bones
            (trans, rot, scale) = parent.matrix.decompose()
        else:
            bone.head = (0,0,0)
            if vector[0]+vector[1]+vector[2] < 0.0001:
                vector = (0,0.0001,0) # try to prevent zero length bones
            rot = Matrix.Translation((0,0,0))	# identity matrix
        bone.tail = rot * Vector(vector) + bone.head
    bpy.ops.object.mode_set(mode='OBJECT')
    return ob

def poseRig(context,rig, poseTable,use_layers,mesh_scale):

    SWAP_YZ_MATRIX = mathutils.Matrix.Rotation(math.radians(90.0), 4, 'X')
    bpy.context.scene.objects.active = rig
    bpy.ops.object.mode_set(mode='POSE')
 
    for (bname, loc,angle) in poseTable:
        
        pbone = rig.pose.bones[bname]

        pbone.matrix_basis.identity()
        # Set rotation mode to Euler XYZ, easier to understand
        # than default quaternions
        pbone.rotation_mode = 'XYZ'
        # Documentation bug: Euler.rotate(angle,axis):
        # axis in ['x','y','z'] and not ['X','Y','Z']
        #print("quat:",angle)
        quat = Quaternion((angle[3]*-1.0,angle[0]*-1.0,angle[1],angle[2])) # flip on axis, Negate axis, negate 'w'
        euler=quat.to_euler('XYZ')
        #pbone.rotation_euler.rotate_axis('X', euler[0])
        #pbone.rotation_euler.rotate_axis('Y', euler[2])
        #pbone.rotation_euler.rotate_axis('Z', euler[1])

        #########################
        pos = Vector([float(loc[0]), float(loc[1]), float(loc[2])])
        rot = Euler([float(euler[0]), float(euler[1]), float(euler[2])])
        
        kf = Matrix.Identity(4)
        kf = Matrix.Translation(pos) * rot.to_matrix().to_4x4()

        if pbone.parent:
            pbone.matrix = pbone.parent.matrix * kf
        else:
            pbone.matrix = kf
        
    bpy.ops.pose.armature_apply()

    #sphere
    bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=3,size=0.005)
    bone_vis = bpy.context.active_object
    bone_vis.data.name = bone_vis.name = "binfbx_bone_vis"
    bone_vis.use_fake_user = True
    bpy.context.scene.objects.unlink(bone_vis) # don't want the user deleting this
    
    bpy.context.scene.objects.active = rig
    ###########################

    # Calculate armature dimensions...Blender should be doing this!
    maxs = [0,0,0]
    mins = [0,0,0]
    for bone in rig.data.bones:
        for i in range(3):
            maxs[i] = max(maxs[i],bone.head_local[i])
            mins[i] = min(mins[i],bone.head_local[i])

    dimensions = []

    for i in range(3):
        dimensions.append(maxs[i] - mins[i])
        
    length = max(0.001, (dimensions[0] + dimensions[1] + dimensions[2]) / 600) # very small indeed, but a custom bone is used for display

    # Apply spheres
    bpy.ops.object.mode_set(mode='EDIT')
    for (bname, loc,angle) in poseTable:
        bone=rig.data.edit_bones[bname]
        bone.tail = bone.head + (bone.tail - bone.head).normalized() * length # Resize loose bone tails based on armature size
        rig.pose.bones[bone.name].custom_shape = bone_vis # apply bone shape
        rig.pose.bones[bone.name].use_custom_shape_bone_size = False
        rig.data.bones[bone.name].show_wire = True

    #pbone.rotation_quaternion = quat
    bpy.ops.object.mode_set(mode='OBJECT')

    #scale
    scale_matrix = mathutils.Matrix.Scale(1.0*mesh_scale, 4)

    global_trans = mathutils.Matrix.Translation((poseTable[0][1][0]*100.0,poseTable[0][1][1]*100.0,poseTable[0][1][2]*100.0))
    matrix_basis = SWAP_YZ_MATRIX * scale_matrix * global_trans
    rig.data.transform(matrix_basis)
    
    # apply transforms (rotation)
    bpy.ops.object.transform_apply(location=True,rotation=True,scale=True)

    
    #add armature modifier
    for cnt,ob_ptr in enumerate(objects_ptr):
        mod = ob_ptr.modifiers.new('RigModifier', 'ARMATURE')
        mod.object = rig
        mod.use_bone_envelopes = False
        mod.use_vertex_groups = True
        
        # sort by skeletal links
        if bpy.app.version[1] > 71:
            context.scene.objects.active = ob_ptr
            bpy.ops.object.vertex_group_sort(sort_type='BONE_HIERARCHY')

        # place armature on each layer as well
        if use_layers:
            for x in range(0,highest_layer+1):
                rig.layers[x] = True



 
##################################################################

def alignPosition(alignment):
	alignment = alignment - 1
	filehandle.seek(((filehandle.tell() + alignment) & ~alignment), 0) # SEEK_SET

def randomColor():
    randomR = random.random()
    randomG = random.random()
    randomB = random.random()
    return (randomR, randomG, randomB)

def file_str(long): 
   s=''
   for j in range(0,long): 
       lit =  unpack('c',filehandle.read(1))[0]
       #print("ord of "+str(lit)+" is "+str(ord(lit)))
       if ord(lit)!= 0:
           s+=lit.decode("utf-8")
       else:
           break;
   return s

def readcstr():
    buf = ''
    while True:
        b = unpack('c',filehandle.read(1))[0]
        #print("ord of "+str(b)+" is "+str(ord(b)))
        if b is None or ord(b) == 0:
            return buf
        else:
            buf+=b.decode("utf-8")

def BB(n): # Unsigned Char Default is < (little Endian)  > = Big-Endian
    array = [] 
    for id in range(n): 
        array.append(unpack('B', filehandle.read(1))[0])
    return array
def Bb(n): # Signed Char
    array = [] 
    for id in range(n): 
        array.append(unpack('b', filehandle.read(1))[0])
    return array
def BH(n): # Unsigned Short
    array = [] 
    for id in range(n): 
        array.append(unpack('H', filehandle.read(2))[0])
    return array
def Bh(n): # Signed Short
    array = [] 
    for id in range(n): 
        array.append(unpack('h', filehandle.read(2))[0])
    return array
def Bf(n): # Float
	array = [] 
	for id in range(n):
		nz=filehandle.read(4)
		#print("NZ:"+str(nz))
		array.append(unpack('f',nz )[0])
	return array
def Bi(n): # Signed Long Int
    array = [] 
    for id in range(n): 
        array.append(unpack('i', filehandle.read(4))[0])
    return array
def BI(n): # Unsigned Long Int
    array = [] 
    for id in range(n): 
        array.append(unpack('I', filehandle.read(4))[0])
    return array
def Bd(n): # Double float
    array = [] 
    for id in range(n): 
        array.append(unpack('d', filehandle.read(8))[0])
    return array
def Bl(n): # 64 bit integer
    array = [] 
    for id in range(n): 
        array.append(unpack('q', filehandle.read(8))[0])
    return array
def BL(n): # 64 bit unsigned integer
    array = [] 
    for id in range(n): 
        array.append(unpack('Q', filehandle.read(8))[0])
    return array

def views():
    """ Returns the set of 3D views.
    """
    rtn = []
    for a in bpy.data.screens["Default"].areas:
        if a.type == 'VIEW_3D':
            rtn.append(a)
    return rtn

def import_binFBX(file, context, randomize_colors, import_vertcolors, skip_blank, use_layers, break_phys, mesh_scale):

    global filehandle,skelhandle,fmt_table,model_name,objects_ptr
    report = None

    objects_ptr = [];

    time1 = time.time()
    print("start")

    workingpath=os.path.dirname(os.path.realpath(__file__))

     #adjust clipping mode
    view=views()
    print(view[0].spaces[0].type)  # should be VIEW_3D
    view[0].spaces[0].clip_end=10000

    # split off model name
    root, ext = os.path.splitext(file)    
    model_name=root.split("\\")[-1]
    print(model_name)

    ##################################
    ## Test for skeleton file
    ##################################

    has_skeleton = True
    
    # take root filename and add .binskeleton extension
    root = root + ".binskeleton"
    try:
        skelhandle = open(root, "rb")
    except:
        has_skeleton = False  

    ##################################
    try:
        filehandle = open(file, "rb")
    except:
        report="Error loading '"+model_name+".binFBX'\n"
        return report

    #get key data about the mesh
    signature = BI(1)[0]
    if signature != MAGIC_SIG:
        report=model_name+".binFBX signature is invalid:"+str(signature)+"\n"
        return report

    # unselect all   
    for item in bpy.context.selectable_objects:   
        item.select = False
    
    # at model start
    ####################################

    # do mesh and materials
    result=import_mesh(context, randomize_colors, import_vertcolors, use_layers, break_phys, mesh_scale, has_skeleton)

    if result is None:
        report = "Mesh Output Failed."
    elif result == 1:
        report = "Vertice counts didn't match, aborting!"
    elif result == 2:
        report = "Failed splitting breakable mesh, aborting!"
    elif result == 3:
        report = "Unknown Shader parameter type, aborting!"
    elif result == 4:
        report = "Found a crazy weighted model, aborting!"

    # should be at end of models, process last
    filehandle.close()
    
    #############################################
    ## Skeleton
    #############################################

    if has_skeleton:

        # all of our data reading functions use filehandle, so transfer the skeleton handle there
        filehandle = skelhandle
        
        print("\r\nSkeleton Detected")
        #get key data about the mesh
        signature = BI(1)[0]
        if signature != SKEL_SIG:
            report=model_name+".binskeleton signature is invalid:"+str(signature)+"\n"
            return report
        
        BI(4) #skip
        offset_to_names = BI(1)[0]
        print("offset_to_names:"+str(offset_to_names))
        BI(6) #skip
        
        offset_base = filehandle.tell() # offsets start from here
        print("Offset_base:"+str(offset_base))
        bone_count = BL(1)[0] # lot of doubles from here on out
        print("bone_count:"+str(bone_count))
        offset_to_params = BL(1)[0]
        offset_to_parents = BL(1)[0]
        offset_to_unknown = BL(1)[0]
        print("Offsets:"+str(offset_to_params)+" "+str(offset_to_parents)+" "+str(offset_to_unknown))

        #jump to start of name records
        filehandle.seek(offset_base+offset_to_names,0) #SEEK_SET
        alignPosition(16) # record has 16 byte alignment
        
        offset_name_to_data = BI(1)[0] # data area for names. we could use this to skip the stuff below but i parse it out anyway in case it's useful later
        print("Offset_name_to_data:"+str(offset_name_to_data))
        BI(1) # length of name block (is last so don't really care)

        #skip past block of integers that increments by 8 (use unknown) count is usually one more than the total bone count
        by_eight_len = BI(1)[0]
        print("by_eight_len:"+str(by_eight_len))
        BI(by_eight_len) # skip       
        alignPosition(16) # record has 16 byte alignment
        
        name_start=filehandle.tell()
        print("Name_start:"+str(name_start))
        
        BL(1) # skip
        names_offset_len = BL(1)[0]
        
        bone_names=[] # names array

        for y in range(0,names_offset_len):
            tmp=BL(1)[0] # name offset
            offsets_start=filehandle.tell()
            filehandle.seek(name_start+tmp,0) # SEEK_SET
            bone_names.append(readcstr())
            #print("name:",bone_names[y])
            filehandle.seek(offsets_start)

        # Now jump back up to read the bone parent index list
        filehandle.seek(offset_base+offset_to_parents,0) #SEEK_SET

        Bone_parents = []        
        for y in range(0,bone_count):
            parent = Bi(1)[0] # signed so root = -1
            #print("Bone "+str(y)+" parent:"+str(parent))
            Bone_parents.append(parent)  

        #Now get location/rotation data and build skeleton table as we go
        filehandle.seek(offset_base+offset_to_params,0) #SEEK_SET    
        Bone_Table=[]
        Pose_Table=[]

        for y in range(0,bone_count):
            loc_n_rot = Bf(8)

            parent_name = None
            parent_id=Bone_parents[y]
            if parent_id != -1:
                parent_name = bone_names[parent_id]                

            Bone_Table.extend([(bone_names[y],parent_name,(loc_n_rot[4]*-1,loc_n_rot[5],loc_n_rot[6]))]) # Flip on X Axis
            Pose_Table.extend([(bone_names[y],(loc_n_rot[4]*-1,loc_n_rot[5],loc_n_rot[6]),(loc_n_rot[0],loc_n_rot[1],loc_n_rot[2],loc_n_rot[3]))])



        # build the skeleton
        rig = createRig('Skeleton', Vector((0,0,0)), Bone_Table)
        poseRig(context,rig, Pose_Table,use_layers,mesh_scale)            

        filehandle.close()

    print("time is ", time.time() - time1)
    return report
