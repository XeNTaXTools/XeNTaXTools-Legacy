#UC gundam online DET parser

import os, sys
from .lib.ModelObject import Model3D
from .lib.StructReader import StructReader

class unk_DET(Model3D):
        
    def __init__(self, obj3D=None, outFile=None, inFile=None):
        
        super(unk_DET,self).__init__("DET")
        self.obj3D = obj3D
        self.inFile = inFile
        self.outFile = outFile
        self.meshList = []
        
    def make_faces(self, meshName, faces):
        
        for i in range(len(faces)):
            self.create_face(meshName, i)
            self.add_face_verts(meshName, i, faces[i])
        
    def parse_faces(self, meshName, numFaces):
        
        n = 0
        faces = []
        for i in range(numFaces):
            
            v1, v2, v3 = self.inFile.read_short(3)
            faces.append([v1, v2, v3])
            n = max(n, v1, v2, v3)
            
            #self.create_face(meshName, i)
            #self.add_face_verts(meshName, i, [v1, v2, v3])
        return faces, n
        
    def parse_vertices(self, meshName, numVerts):
        
        for i in range(numVerts):
            vx, vz, vy = self.inFile.read_float(3)
            nx, ny, nz = self.inFile.read_float(3) 
            tu, tv = self.inFile.read_float(2)
            
            vx = float(vx) * -1
            self.create_vertex(meshName, i)
            self.add_coords(meshName, i, [vx, vy, vz])
            
        
    def parse_file(self):
        '''Main parser method. Can be replaced'''
        
        self.inFile.read_short()
        self.inFile.read_short() #XR
        objNum = 0
        while 1:
            self.inFile.read_short()
            self.inFile.read_short()
            chunk = self.inFile.read_long()
            #print hex(chunk)
            if chunk == 0x01:
                vertChunks, faceChunks = self.inFile.read_long(2)
                print "%d vert chunks, %d face chunks" %(vertChunks, faceChunks)
                self.inFile.read_long(8)
            elif chunk in [0x04, 0x20]:
                self.inFile.seek(40, 1)
            elif chunk == 0x112:
                chunkSize = self.inFile.read_long()
                self.inFile.read_long(),
                numVerts = self.inFile.read_long()
                self.inFile.read_long(3)
                
                meshNum = self.mesh_count()
                meshName = "object[%d]" %meshNum
                
                self.create_object(meshName)
                self.parse_vertices(meshName, numVerts)
                key = self.inFile.read_short(2)
                self.meshList.append([meshName, numVerts])
                
            elif chunk == 0x65:
                chunkSize = self.inFile.read_long()
                self.inFile.read_long(),
                numFaces = self.inFile.read_long() / 3
                self.inFile.read_long(3)
                
                meshName = "object[%d]" %objNum
                faces, maxIndex = self.parse_faces(meshName, numFaces)
                key = self.inFile.read_short(2)
                
                while (maxIndex != self.meshList[objNum][1] - 1):
                    objNum += 1
                else:
                    self.make_faces(self.meshList[objNum][0], faces)
                    objNum += 1
                
            elif chunk in [0x0A, 0x08]:
                #just ignore anything after the face chunks
                break
        
def read_file(path):
    '''Read the file'''
    
    openFile = StructReader(open(path, 'rb'))
    obj = unk_DET(inFile=openFile)
    obj.parse_file()
    openFile.close()
    return obj

def write_file(path):
    
    pass

def definitions():
    '''Return the header, extension, and a description of the format'''
    
    return "", "DET", "Universal Century Gundam Online"