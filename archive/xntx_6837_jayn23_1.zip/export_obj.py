"""

Export a RenderMesh to Wavefront OBJ

"""

import io
import struct
import sys

from PyQt5 import QtWidgets

import dataid
import materialinstance
import materialmodifier
import rendermesh
import rendertexture
import respreloader
import surface


class Vertex:
    """
    Vertex with position, normal, texcoord, and other data.

    RenderMesh stores raw vertices for upload, so use this
    to parse them.

    """

    def __init__(self, ins, vertex_type):
        # Don't bother to read all attributes since we don't
        # need them; just grab position, normal, and texcoords.

        startpos = ins.tell()

        ins.seek(startpos + vertex_type.pos_offset())
        self.x, self.y, self.z = struct.unpack('<3f', ins.read(12))

        ins.seek(startpos + vertex_type.normal_offset())
        self.nx, self.ny, self.nz = struct.unpack('<3f', ins.read(12))

        ins.seek(startpos + vertex_type.texcoord_offset())
        self.u, self.v = struct.unpack('<2f', ins.read(8))

        # Forward to the next vertex:
        ins.seek(startpos + vertex_type.size())


def get_diffuse_map(mi_did):
    raw_mi = respreloader.fetch(mi_did)
    if raw_mi is None:
        print('Failed to find MaterialInstance')
        return None
    mi = materialinstance.MaterialInstance(raw_mi)

    for mm_did in mi.material_modifier_ids:
        raw_mm = respreloader.fetch(mm_did)
        if raw_mm is None:
            print('Failed to find MaterialModifier')
            return None
        mm = materialmodifier.MaterialModifier(raw_mm)
        for entry in mm.entries:
            if entry.material_property_id == 3000:
                if isinstance(entry.data, dataid.DataID):
                    return entry.data
    return None


def get_texture_surface(rt_did, index):
    raw_rt = respreloader.fetch(rt_did)
    if raw_rt is None:
        print('Failed to find RenderTexture')
        return None
    rt = rendertexture.RenderTexture(raw_rt)
    return rt.surfaces[index]


def main():
    # Parse command line for DataID:
    if len(sys.argv) != 2:
        print('Usage: python export_obj.py RenderMeshDataID')
        print()
        print('  RenderMeshDataID is decimal (e.g. 100671858) or hex (e.g. 0x06002172)')
        sys.exit(0)
    try:
        if sys.argv[1][:2].lower() == '0x':
            rm_did = int(sys.argv[1], 16)
        else:
            rm_did = int(sys.argv[1])
    except ValueError:
        print('Failed to parse {} as a DataID.'.format(sys.argv[1]))
        sys.exit(-1)

    # Load RenderMesh:
    try:
        raw_rm = respreloader.fetch(dataid.DataID(rm_did))
    except KeyError:
        print('{:08X} is not a RenderMesh DataID'.format(rm_did))
        sys.exit(-1)
    else:
        if raw_rm is None:
            print('Failed to find DataID {:08X}'.format(rm_did))
            sys.exit(-1)
    rm = rendermesh.RenderMesh(raw_rm)

    lod = 0

    # Grab DataID for the diffuse map:
    rt_did = get_diffuse_map(rm.materials[lod])
    rs_did = get_texture_surface(rt_did, 1)  # avoid highres lod 0

    # Parse raw vertices:
    vertices = []
    raw_vertices = rm.vertex_groups[lod].raw_vertices
    ins = io.BytesIO(raw_vertices)
    while ins.tell() != len(raw_vertices):
        v = Vertex(ins, rm.vertex_groups[lod].type)
        vertices.append(v)

    # The text lines to be exported to OBJ:
    lines = []

    # Prepare material library:
    lines.append('mtllib {:08X}.mtl\n'.format(rm_did))
    lines.append('usemtl {:08X}_diffuse_map\n'.format(rm_did))

    # Format vertex positions, normals, and texcoords:
    for v in vertices:
        lines.append('v {} {} {}\n'.format(v.x, v.y, v.z))
    for v in vertices:
        lines.append('vn {} {} {}\n'.format(v.nx, v.ny, v.nz))
    for v in vertices:
        lines.append('vt {} {}\n'.format(v.u, v.v))

    # Parse raw element array:
    raw_ea = rm.element_arrays[lod]
    ea = list(struct.iter_unpack('<3h', raw_ea))

    # Format element array:
    for e1, e2, e3 in ea:
        e1 += 1  # OBJ indexing starts at 1 not 0
        e2 += 1
        e3 += 1
        lines.append('f {}/{}/{} {}/{}/{} {}/{}/{}\n'.format(
            e3, e3, e3, e2, e2, e2, e1, e1, e1))

    # Write the OBJ file:
    obj_filename = '{:08X}.obj'.format(rm_did)
    print('Writing {}...'.format(obj_filename))
    with open(obj_filename, 'w') as outf:
        outf.writelines(lines)

    # Write the MTL file:
    mtl_filename = '{:08X}.mtl'.format(rm_did)
    print('Writing {}...'.format(mtl_filename))
    with open(mtl_filename, 'w') as outf:
        outf.write('newmtl {:08X}_diffuse_map\n'.format(rm_did))
        outf.write('map_Kd {:08X}.png\n'.format(rs_did.raw))

    # Export the diffuse map RenderSurface to PNG:
    raw_rs = respreloader.fetch(rs_did)
    if raw_rs is None:
        print('Failed to find RenderSurface {}'.format(rs_did))
        sys.exit(-1)
    # We need QApplication so that QImage can be used:
    app = QtWidgets.QApplication(sys.argv)
    pm = surface.convert_image(raw_rs)
    img = pm.toImage()
    img = img.mirrored(False, True)
    png_filename = '{:08X}.png'.format(rs_did.raw)
    print('Writing {}...'.format(png_filename))
    img.save(png_filename)
    app.quit()

    print('Job done!')


if __name__ == '__main__':
    main()
