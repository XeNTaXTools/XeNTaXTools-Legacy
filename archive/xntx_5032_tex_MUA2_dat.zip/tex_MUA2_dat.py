from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Marvel Ultimate Alliance 2", ".dat")
	noesis.setHandlerTypeCheck(handle, noeCheckGeneric)
	noesis.setHandlerLoadRGBA(handle, MUA2LoadRGBA)
	#noesis.logPopup()
	return 1

def MUA2LoadRGBA(data, texList):
    datasize = len(data) - 0x1000
    bs = NoeBitStream(data)
    bs.seek(0x1000, NOESEEK_ABS)
    data = bs.readBytes(datasize)
	#diffuse
    if datasize == 188416:
        imgHeight = 512
        imgWidth = 512
        data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 8)
        texFmt = noesis.NOESISTEX_DXT1
    elif datasize == 712704:
        imgHeight = 1024
        imgWidth = 1024
        data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 8)
        texFmt = noesis.NOESISTEX_DXT1
    #specular
    elif datasize == 57344:
        imgHeight = 256
        imgWidth = 256
        data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 8)
        texFmt = noesis.NOESISTEX_DXT1
	#normal
    elif datasize == 376832:
        imgHeight = 512
        imgWidth = 512
        data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 16)
        data = rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_ATI2)
        texFmt = noesis.NOESISTEX_RGBA32
	#unknown, not handled
    else:
        print("WARNING: Unhandled image format")
        return None
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1