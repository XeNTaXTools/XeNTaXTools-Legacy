from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Xenus 1/Boiling Point: Road to Hell *.RF2", ".rf2")
	noesis.setHandlerTypeCheck(handle, rf2CheckType)
	noesis.setHandlerLoadModel(handle, rf2LoadModel)

	return 1
	
# Header Signature
MODEL_SIG				= 0x4569

# Set to true to preview/export Hit Mesh
EXPORT_HITMESH			= 1

class RF2File: 
         
	def __init__(self, bs):
		self.bs = bs
		self.matList  = [] 
		self.boneList = []
		self.boneMap  = []
		self.boneGroups = []
		self.lodDistance = []
		self.BoundingBox = []
		self.meshList = []
		self.hitboxMeshList = []
		self.anim = NoeAnim()
		
	def printAll(self):
		print ( 'Sig: ' + str(hex(self.sig)) + '\n' +
				'Version: ' + str(self.version) + '\n' +
				'LODCount: ' + str(self.lodCount) + '\n' +
				'FramesCount: ' + str(self.framesCount) + '\n' +
				'Mat_Ptr: ' + str(hex(self.material_ptr)) + '\n'
				'Biped_Ptr: ' + str(hex(self.bones_ptr)) + '\n'
				'Skin_Ptr: ' + str(hex(self.skin_ptr)) + '\n'
				'MovementVector_Ptr: ' + str(hex(self.mvect_ptr)) + '\n'
				'Hitbox_Ptr: ' + str(hex(self.hitbox_ptr)) + '\n'
				'BonesGroup_Ptr: ' + str(hex(self.bonesgrp_ptr)) + '\n'
				'Collision_Ptr: ' + str(hex(self.collision_ptr)) + '\n'
				'FOV:' + str(self.fov) + '\n'
				'Flags:' + str(self.flags) + '\n'
				'Material Count: ' + str(self.materialCount)
				)
			
		print ('Parts Count: ' + str(self.groupCount))
		
		if (self.groupCount > 0):
			print('{0:>24}{1:>30}'.format('GroupID', 'Hideable'))
			for i in range(self.groupCount):
				print('{0:>24}{1:>30}'.format(self.boneGroups[i][0], self.boneGroups[i][1]))
			
	def loadAll(self, bs):
		# BEGIN Read TRF2Header
		self.sig = bs.readUShort()

		self.version, self.lodCount, self.framesCount = bs.readUByte(), bs.readUByte(), bs.readUShort();

 		# At least 1 frame if 0, according to RF2View
		if self.framesCount == 0:
			self.framesCount = 1
		
		# 4 bits. Array, but value is pointer.
		# Also indicates the end of the TRF2Header
		bs.seek(0x6, NOESEEK_ABS); 
		self.material_ptr, self.bones_ptr, self.skin_ptr, self.mvect_ptr, self.hitbox_ptr, self.bonesgrp_ptr, self.collision_ptr = bs.readUInt(), bs.readUInt(), bs.readUInt(), bs.readUInt(), bs.readUInt(), bs.readUInt(), bs.readUInt();
		
		bs.seek(0x22, NOESEEK_ABS);
		#self.mtxBoundingBox = NoeMat44.fromBytes(bs.readBytes(0x18)).toMat43();

		for i in range(2):
			vect = NoeVec3((bs.readFloat(), bs.readFloat(), bs.readFloat()));
			self.BoundingBox.append(vect);
			# Move to next
			bs.seek(0x0C, NOESEEK_REL);

		bs.seek(0x3A, NOESEEK_ABS)
		self.fov, self.flags = bs.readFloat(), bs.readUInt();
		
		bs.seek(0x42, NOESEEK_ABS)
		
		# Get lodDistance values
		# Note: last one is usually LODDistance[0]
		for i in range(6):
			self.lodDistance.append(bs.readFloat())
			
		# END Read TRF2Header

		self.loadMaterialNames(bs)
		
		# Skip if there's no bones
		self.loadBones(bs)
		self.loadBoneGroups(bs)
		self.printAll()
		self.loadMeshes(bs)
		
		# Hit mesh will add to the current mesh as "HIT_XX"
		if EXPORT_HITMESH == 1:
			self.loadHitMesh(bs)
		
	# Gather names of materialIDs
	def loadMaterialNames(self, bs):
		self.matList  = [] 
		
		bs.seek(self.material_ptr, NOESEEK_ABS)
		self.materialCount = bs.readUByte()
		bs.seek(0x1, NOESEEK_REL)

		for i in range(self.materialCount):
			# Next value is the length of the string
			length = bs.readUByte(); bs.pushOffset();	
			# Create a basic material for the meshes to use
			material = NoeMaterial(bs.readBytes(length).decode("ASCII").rstrip("\0"), "")
			self.matList.append(material)
	
	# Gather Groupings
	def loadBoneGroups(self, bs):
		self.boneGroups = []
		
		if (self.bonesgrp_ptr > bs.getSize()) or self.bonesgrp_ptr == 0:
			self.groupCount = 0
			return
			
		self.boneGroups = []
		
		bs.seek(self.bonesgrp_ptr, NOESEEK_ABS)
		self.groupCount = bs.readUByte()
		for a in range(0, self.groupCount):
			# That 0xFF needs to be dropped
			buff = bs.readBytes(0x15);
			
			# If last bit is set, it's hideable
			hideable = 0
			if buff[20] >= 0x01:
				hideable = 1
				buff = buff.replace(b'\x01', b'')
				buff = buff.replace(b'\xff', b'')
		
			groupID = buff.decode('ASCII', 'ignore').rstrip("\0")
			
			# store value
			self.boneGroups.append( [groupID, hideable] )
					
	# Gather Bones, Keyframe Animations	
	def loadBones(self, bs):
	
		if self.bones_ptr >= bs.getSize() or self.bones_ptr is 0x0:
			self.boneCount = 0
			return
	
		bs.seek(self.bones_ptr, NOESEEK_ABS)
		self.boneCount = bs.readUByte()
		
		# Bones: 
		# BoneCount (starts at pointer only): byte
		
		# Singleton:
		# BoneName: 0x14 bytes
		# bone Parent: 1 byte
		# bone Group: 1 byte
		# special Label: 1 byte (any GR_ named bones)
		# Memory Block Size: 4 bytes (Current Addr + offset to next bone)
		# 64 bytes: Bone Matrix 
		
		self.boneConstructList = []
		self.boneList = []
		self.kfAnim = []
		
		# Build matrices for every bone
		# ID is the order that they come in
		# Animations may come in a later date
		for boneIdx in range(0, self.boneCount):
			#print ('Current Offset: {0:x}'.format(bs.getOffset()))
			boneName = bs.readBytes(0x14).decode("ASCII").rstrip("\0") # Bone names have max 20 characters
			boneParent, boneGroup, specialLabel, blockSize = bs.readUByte(), bs.readUByte(), bs.readUByte(), bs.readInt()
			
			#print ('Name: {0}, ID: {1}, Parent: {2}, Group: {3}, Label: {4}'.format(boneName, boneIdx, boneParent, boneGroup, specialLabel))
			
			# Root
			# Fix the indexes so Noesis can read the skeleton proper
			noeBoneParent = -1
			if (boneParent == 255):
				noeBoneParent = -1
			else:
				noeBoneParent = boneParent
			
			self.boneConstructList.append([boneIdx, boneName, noeBoneParent])
			
			# Animation Frames 
			# TBD
			# Skip to the next block
			bs.seek(blockSize, NOESEEK_REL)
			
		# After all blocks have been exhausted, there are several 4x3 Matrices 48 bytes long. These repeat twice for each bone 
		# These are the original positions of each bone, and their inverses
		# Bone Order is the same as above
		for boneIdx in range(0, self.boneCount):
			boneMtxLocal1 = NoeMat44()
			boneMtxLocal2 = NoeMat44()

			boneMtxLocal1 = NoeMat44.fromBytes(bs.readBytes(0x40)).toMat43()
			
			# Copy of above but already inverted
			# Swap X handedness to fix bones having swapped positions (Bip01 L Hand on Right side, etc.)
			boneMtxLocal2 = NoeMat44.fromBytes(bs.readBytes(0x40)).toMat43().swapHandedness()
			
			# Swap Y with Z to correct the matrix
			swap = boneMtxLocal1[2]
			boneMtxLocal1[2] = boneMtxLocal1[1]
			boneMtxLocal1[1] = swap
			
			self.boneList.append(NoeBone(self.boneConstructList[boneIdx][0], self.boneConstructList[boneIdx][1], boneMtxLocal2, None, self.boneConstructList[boneIdx][2]))
			
		# Anim's framerate is controlled via resource.qrc in the Models section, so fall back to 30 FPS
		self.anim = NoeAnim('Master', self.boneList, self.framesCount, self.kfAnim, 30.0)

	def loadMeshes(self, bs):

		bs.seek(self.skin_ptr, NOESEEK_ABS)

		blocksize, self.t2count, self.ct1count, self.ntc2count = bs.readUInt(), bs.readUShort(), bs.readUShort(), bs.readUShort()
		
		self.nt1count, self.nt2count, self.nw1t1count, self.nw1t2count = bs.readUShort(), bs.readUShort(), bs.readUShort(), bs.readUShort()
		
		self.nw3t1count, self.nw3t2count, self.levelLODCount, self.skinnedLODCount = bs.readUShort(), bs.readUShort(), bs.readUShort(), bs.readUShort()
		
		print ('T2Count: {0}, CT1Count: {1}, NTC2count: {2}, NT1Count: {3}, NT2Count: {4}, NW1T1Count: {5}, NW1T1Count: {6}, NW1T2Count: {7}, NW3T1Count: {8}'.format(self.t2count, self.ct1count, self.ntc2count, self.nt1count, self.nt2count, self.nw1t1count, self.nw1t2count, self.nw3t1count, self.nw3t2count))
		
		# Vertex Color support
		#if (self.ct1count > 0)
		#	self.readCT1(bs, self.ct1count)
		
		# 36-byte TGEOMVERTEXNT1 (3D pos, char[4] bone matrix, 3D norm, 2D uv1)
		if self.nt1count > 0:
			self.readNTX(bs, self.nt1count, 0)

		# 44-byte TGEOMVERTEXNT1 (3D pos, char[4] bone matrix, 3D norm, 2D uv1, 2D uv2)
		if self.nt2count > 0:
			self.readNTX(bs, self.nt2count, 1)
		
		# 40-byte TGEOMVERTEXNT2 (3D pos, float weight1, char[4] bone matrix, 3D norm,  2D uv1)	
		if self.nw1t1count > 0:
			self.readNW1TX(bs, self.nw1t1count, 0)
		
		# 48-byte TGEOMVERTEXNW3T2 (3D pos, float weight1, char[4] bone matrix, 3D norm, 2D uv1, 2D uv2)	
		if self.nw1t2count > 0:
			self.readNW1TX(bs, self.nw1t2count, 1)

		# 44-byte TGEOMVERTEXNW3T1 (3D pos, float weight1, float weight2, char[4] bone matrix, 3D norm, 2D uv1)
		if self.nw3t1count > 0:
			self.readNW3TX(bs, self.nw3t1count, 0)
			
		# it may be un-implemented in-game, but the general idea is the same
		# 52-byte TGEOMVERTEXNW3T1 (3D pos, float weight1, float weight2, char[4] bone matrix, 3D norm, 2D uv1, 2D uv2)	
		if self.nw3t2count > 0:
			self.readNW3TX(bs, self.nw3t2count, 1)
		
	def readNTX(self, bs, count, uvs):
		# Iterate through NT1Count for meshes if available
		for a in range(0, count):
			#print ( "NT{0} Address Start: {1:x}".format(uvs + 1, bs.getOffset()) )
			
			matID, detMatID, opacity = bs.readUShort(), bs.readUShort(), bs.readUByte()
			miniRange, vertCount, relVertCount, facesCount =  bs.readUByte(), bs.readUShort(), bs.readUShort(), bs.readUShort()
			
			#print (matID, detMatID, opacity, miniRange, vertCount, relVertCount, facesCount)
			
			matrixPalette, paletteSize, usedMatrixMask = self.readMatrixPalette(bs);
	
			# Sometimes hitboxes gets into the model section. We should read those in anyways
			if facesCount == 0 and relVertCount != 0:
				offset = 36
			
				if uvs == 1:
					offset += 8
					
				bs.seek(offset * relVertCount, NOESEEK_REL);
				continue
						
			print ( "Faces Read Start Address: {0:x}, Faces Count: {1}".format(bs.getOffset(), facesCount))

			faceBuffer = self.readFaces(bs, facesCount)
			
			vertBuffer = []
			normBuffer = []
			uvBuffer1 = []
			uvBuffer2 = []
			weightBuffer = []
			
			print ( "Vertex Read Start Address: {0:x}, Vertex Count {1}".format(bs.getOffset(), relVertCount))
			
			# Vertex Buffer
			# -1 * posX, posY, posZ, bone matrices, nrmX, nrmY, nrmZ, U V
			for j in range(0, relVertCount):
				vx, vy, vz  = bs.readFloat(), bs.readFloat(), bs.readFloat()
				vertBuffer.append( NoeVec3((-1 * vx , vy, vz)) )
				
				# local indexes, used to get the actual boneID from the matrix palette
				matrixPaletteIdx = [bs.readByte(), bs.readByte(), bs.readByte(), bs.readByte()]

				# Some objects don't have bones, so don't add 
				if self.boneCount > 0:
					indexList = []
					weightList = []
					
					# Engine supports only 4 weights at a time, according to doc
					for k in range(4):
						weight = 0.000
						
						# Always 1.000 for first bone in NT1Count Vertex type	
						if k == 0:
							weight = 1.000

						# if k index has a boneID set, locate the bone from the matrix palette
						boneID = matrixPalette[matrixPaletteIdx[k]]
						indexList.append(boneID);
						weightList.append(weight);
						
					weightBuffer.append(NoeVertWeight(indexList, weightList))
				
				# Normals are read in ZYX order
				nx, ny, nz = bs.readFloat(), bs.readFloat(), bs.readFloat()

				normBuffer.append( NoeVec3((-1 * nx, ny, nz)) )
				uvBuffer1.append( NoeVec3((bs.readFloat(), bs.readFloat(), 0.0)) )
				
				if uvs is 1:
					uvBuffer2.append( NoeVec3((bs.readFloat(), bs.readFloat(), 0.0)) )		
			
			#print ( "Vertex Read End Address: {0:x}, Got Vertex Count {1}".format(bs.getOffset(), len(vertBuffer) ))

			# Set options before commiting the mesh to NoeModel	
			mesh = NoeMesh(faceBuffer, vertBuffer, 'submesh_NT{0}_{1}'.format(uvs + 1, a), self.matList[matID].name)
			mesh.setNormals(normBuffer)
			mesh.setUVs(uvBuffer1, 0)	
			
			if len(weightBuffer) > 0:
				mesh.setWeights(weightBuffer)
			
			if uvs is 1:
				mesh.setUVs(uvBuffer2, 1)
			
			self.meshList.append(mesh)
	
	def readNW1TX(self, bs, count, uvs):
		# Iterate through NW1TXCount for meshes if available
		for a in range(0, count):
			#print ( "NW1T{0} Address Start: {1:x}".format(uvs + 1, bs.getOffset()) )
			
			matID, detMatID, opacity = bs.readUShort(), bs.readUShort(), bs.readUByte()
			miniRange, vertCount, relVertCount, facesCount =  bs.readUByte(), bs.readUShort(), bs.readUShort(), bs.readUShort()
			
			#print (matID, detMatID, opacity, miniRange, vertCount, relVertCount, facesCount)
			
			matrixPalette, paletteSize, usedMatrixMask = self.readMatrixPalette(bs);
	
			# Sometimes hitboxes gets into the model section. We should read those in anyways
			if facesCount == 0 and relVertCount != 0:
				offset = 40
			
				if uvs == 1:
					offset += 8
			
				bs.seek(offset * relVertCount, NOESEEK_REL);
				
				continue
						
			#print ( "Faces Read Start Address: {0:x}, Faces Count: {1}".format(bs.getOffset(), facesCount))

			faceBuffer = self.readFaces(bs, facesCount)
			
			vertBuffer = []
			normBuffer = []
			uvBuffer1 = []
			uvBuffer2 = []
			weightBuffer = []
			
			#print ( "Vertex Read Start Address: {0:x}, Vertex Count {1}".format(bs.getOffset(), relVertCount))
			
			# Vertex Buffer
			# -1 * posZ posY -1 * posX nrmX nrmY U V
			for j in range(0, relVertCount):
				vx = bs.readFloat()
				vy = bs.readFloat()
				vz = bs.readFloat()
				vertBuffer.append( NoeVec3((-1 * vx , vy, vz)) )
				
				# Weight for first bone
				firstWeight = bs.readFloat()
				
				# local indexes, used to get the actual boneID from the matrix palette
				matrixPaletteIdx = [bs.readByte(), bs.readByte(), bs.readByte(), bs.readByte()]
				
				# Some objects don't have bones, so don't add 
				if self.boneCount > 0:
					indexList = []
					weightList = []
					
					# Engine supports only 4 weights at a time, according to doc
					for k in range(4):
						finalWeight = 0.000
						
						# First bone has the first weight, second is 1 - firstWeight
						if k == 0:
							finalWeight = firstWeight
						elif k == 1:
							finalWeight = 1 - firstWeight

						# if k index has a boneID set, locate the bone from the matrix palette
						boneID = matrixPalette[matrixPaletteIdx[k]]
						indexList.append(boneID);
						weightList.append(finalWeight);
						
					weightBuffer.append(NoeVertWeight(indexList, weightList))
				
				# Normals are read in XYZ order
				nx = bs.readFloat()
				ny = bs.readFloat()
				nz = bs.readFloat()

				normBuffer.append( NoeVec3(( -1 * nx, ny, nz)) )
				uvBuffer1.append( NoeVec3((bs.readFloat(), bs.readFloat(), 0.0)) )
				
				if uvs is 1:
					uvBuffer2.append( NoeVec3((bs.readFloat(), bs.readFloat(), 0.0)) )		
					
			#print ( "Vertex Read End Address: {0:x}, Got Vertex Count {1}".format(bs.getOffset(), len(vertBuffer) ))

			# Set options before commiting the mesh to NoeModel	
			mesh = NoeMesh(faceBuffer, vertBuffer, 'submesh_NW1T{0}_{1}'.format(uvs + 1, a), self.matList[matID].name)
			mesh.setNormals(normBuffer)
			mesh.setUVs(uvBuffer1, 0)	
	
			if len(weightBuffer) > 0:
				mesh.setWeights(weightBuffer)
	
			if uvs is 1:
				mesh.setUVs(uvBuffer2, 1)
			
			self.meshList.append(mesh)
			
	def readNW3TX(self, bs, count, uvs):
		# Iterate through NW3TXCount for meshes if available
		for a in range(0, count):
			#print ( "NW3T{0} Address Start: {1:x}".format(uvs + 1, bs.getOffset()) )
			
			matID, detMatID, opacity = bs.readUShort(), bs.readUShort(), bs.readUByte()
			miniRange, vertCount, relVertCount, facesCount =  bs.readUByte(), bs.readUShort(), bs.readUShort(), bs.readUShort()
			
			matrixPalette, paletteSize, usedMatrixMask = self.readMatrixPalette(bs);
	
			# Sometimes hitboxes gets into the model section. We should read those in anyways
			if facesCount == 0 and relVertCount != 0:
				offset = 44
			
				if uvs == 1:
					offset += 8
					
				bs.seek(offset * relVertCount, NOESEEK_REL);
				continue
						
			#print ( "Faces Read Start Address: {0:x}, Faces Count: {1}".format(bs.getOffset(), facesCount))

			faceBuffer = self.readFaces(bs, facesCount)
			
			vertBuffer = []
			normBuffer = []
			uvBuffer1 = []
			uvBuffer2 = []
			weightBuffer = []
			
			#print ( "Vertex Read Start Address: {0:x}, Vertex Count {1}".format(bs.getOffset(), relVertCount))
			
			# Vertex Buffer
			# -1 * posZ posY -1 * posX nrmX nrmY U V
			for j in range(0, relVertCount):
				vx = bs.readFloat()
				vy = bs.readFloat()
				vz = bs.readFloat()
				vertBuffer.append( NoeVec3((-1 * vx , vy, vz)) )
				
				# Unknown Floats
				firstWeight = bs.readFloat()
				secondWeight = bs.readFloat()
				
				# local indexes, used to get the actual boneID from the matrix palette
				matrixPaletteIdx = [bs.readByte(), bs.readByte(), bs.readByte(), bs.readByte()]

				# Some objects don't have bones, so don't add 
				if self.boneCount > 0:
					indexList = []
					weightList = []
					
					# Engine supports only 4 weights at a time, according to doc
					for k in range(4):
						finalWeight = 0.000
						
						# First bone has the first weight, second is second weight, third is 1 - sum of weights
						if k == 0:
							finalWeight = firstWeight
						elif k == 1:
							finalWeight = secondWeight							
						elif k == 2:
							finalWeight = 1 - (firstWeight + secondWeight)

						# if k index has a boneID set, locate the bone from the matrix palette
						boneID = matrixPalette[matrixPaletteIdx[k]]
						indexList.append(boneID);
						weightList.append(finalWeight);
						
					weightBuffer.append(NoeVertWeight(indexList, weightList))
				
				# Normals are read in XYZ order
				nx = bs.readFloat()
				ny = bs.readFloat()
				nz = bs.readFloat()

				normBuffer.append( NoeVec3((-1 * nx, ny, nz)) )
				uvBuffer1.append( NoeVec3((bs.readFloat(), bs.readFloat(), 0.0)) )
				
				if uvs is 1:
					uvBuffer2.append( NoeVec3((bs.readFloat(), bs.readFloat(), 0.0)) )		
					
			#print ( "Vertex Read End Address: {0:x}, Got Vertex Count {1}".format(bs.getOffset(), len(vertBuffer) ))

			# Set options before commiting the mesh to NoeModel	
			mesh = NoeMesh(faceBuffer, vertBuffer, 'submesh_NW3T{0}_{1}'.format(uvs + 1, a), self.matList[matID].name)
			mesh.setNormals(normBuffer)
			mesh.setUVs(uvBuffer1, 0)	

			if len(weightBuffer) > 0:
				mesh.setWeights(weightBuffer)		
				
			if uvs is 1:
				mesh.setUVs(uvBuffer2, 1)
				
			self.meshList.append(mesh)
		
	# Begin reading in the face indices. 6(2, 2, 2) bytes per face.
	# We will need to manually create the NoeModel by hand since RF2s have some junk data in it that causes the model to fail.
	def readFaces(self, bs, facesCount):
		faceIndices = []
		for i in range (0, facesCount):
			x, y, z = bs.readShort(), bs.readShort(), bs.readShort()
			faceIndices.append(x)
			faceIndices.append(y)
			faceIndices.append(z)
		return faceIndices
		
	def readMatrixPalette(self, bs):
		# Bone Palette
		# The size is fixed for every model so we'll need to keep reading in bytes to advance the buffer
		matrixPalette = []			
		paletteSize = bs.readUByte()
		for b in range(0x19):
			palette = bs.readUByte();
			if (len(matrixPalette) < paletteSize):
				matrixPalette.append(palette)
			
		usedMatrixMask = bs.readUInt()
		
		return matrixPalette, paletteSize, usedMatrixMask

	# Reads in Hitbox information and stores it in a separate submesh outside the main one
	# There is bone information but only the index in which the hitbox is linked to.
	def loadHitMesh(self, bs):
		bs.seek(self.hitbox_ptr, NOESEEK_ABS)
		count = bs.readShort()
		
		for i in range(0, count):
			#print ('Address start offset: {0:x}'.format(bs.getOffset()))		
			faceBuffer = []
			vertBuffer = []
			
			unk = bs.readByte()
			
			BoneIdx, faces, vertices = bs.readShort(), bs.readShort(), bs.readShort()
			
			faceBuffer = self.readFaces(bs, faces)
				
			for j in range(0, vertices):
				vertBuffer.append( NoeVec3((-1 * bs.readFloat(), bs.readFloat(), bs.readFloat())) )
				
			mesh = NoeMesh(faceBuffer, vertBuffer, 'HIT_{0}'.format(i))
				
			self.hitboxMeshList.append(mesh)
			

def rf2CheckType(data):
	bs = NoeBitStream(data)
	sig, version = bs.readUShort(), bs.readUByte()
	
	# Version 5s or lower are not supported
	if sig != MODEL_SIG or version != 6:
		return 0
	return 1

def rf2LoadModel(data, mdlList):
	#no need to explicitly free the context (created contexts are auto-freed after the handler), but DO NOT hold any references to it outside of this method
	ctx = rapi.rpgCreateContext()
	RF2 = RF2File(NoeBitStream(data))
	RF2.loadAll(RF2.bs)
	
	# Attempt to load the model
	mdl = NoeModel(RF2.meshList, RF2.boneList)
	mdl.setAnims(RF2.anim)
	mdlList.append(mdl)
	
	if len(RF2.hitboxMeshList) > 0:
		hitbox = NoeModel(RF2.hitboxMeshList, [])
		mdlList.append(hitbox)
	
	return 1
	