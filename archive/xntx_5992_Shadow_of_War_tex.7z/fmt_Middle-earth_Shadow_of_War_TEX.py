#Middle-earth: Shadow of War [PC] - ".TEX" Loader
#By Zaramot
#v1.0

from inc_noesis import *
import subprocess

def registerNoesisTypes():
	handle = noesis.register("Middle-earth: Shadow of War [PC]", ".tex")
	noesis.setHandlerTypeCheck(handle, texCheckType)
	noesis.setHandlerLoadRGBA(handle, texLoadDDS)
	noesis.logPopup()
	return 1
		
def texCheckType(data):
	bs = NoeBitStream(data, NOE_BIGENDIAN)
	fileMagic = bs.readUInt()
	if fileMagic == 0x54455852:
		return 1
	else: 
		print("Fatal Error: Unknown file magic: " + str(hex(fileMagic) + " expected 0x54455852!"))
		return 0

def texLoadDDS(data, texList):
    bs = NoeBitStream(data)
	
    fileMagic = bs.readUInt()
    bs.seek(0x10, NOESEEK_ABS) #Name-Path
    Path = bs.readUShort()
    PathData = bs.readBytes(Path)
    UnkId = bs.readUByte()
    TWidth2 = bs.readUShort() // 2
    Height2 = bs.readUShort()// 2
    bs.seek(0x1E, NOESEEK_REL) #Entry start
    Height = bs.readUInt()
    TWidth = bs.readUInt() 
    bs.seek(0x40, NOESEEK_REL) #Texture type
    TexID = bs.readString()
    ddsName = rapi.getLocalFileName(rapi.getInputName())
    #DXT1
    if TexID == "DXT1":
        ddsSize = TWidth * Height // 2 
        bs.seek(0x27, NOESEEK_REL) #Texture start 
    #DXT3
    elif TexID == "DXT3":
        ddsSize = TWidth * Height // 2
        bs.seek(0x27, NOESEEK_REL) #Texture start  
    #DXT5
    elif TexID == "DXT5":
        ddsSize = TWidth * Height * 2 // 2
        bs.seek(0x27, NOESEEK_REL) #Texture start   
    #DXT10
    elif TexID == "DX10":
        bs.seek(0x27, NOESEEK_REL) #Texture start 
        DX10Type = bs.readUInt() 
        if DX10Type == 83:
            ddsSize = TWidth * Height
        elif DX10Type == 80:
            ddsSize = TWidth * Height // 2
        bs.seek(0x10, NOESEEK_REL) #Texture start  
    #RAW
    elif TexID == "":
        ddsSize = TWidth * Height * 4
        bs.seek(0x27, NOESEEK_REL) #Texture start  
    print (PathData) 
    print (ddsName)
    print (TWidth)
    print (Height)
    print (TexID)
    #print (DX10Type)
    print (ddsSize)
    ddsData = bs.readBytes(ddsSize)
    #DXT1
    if TexID == "DXT1":
        texFmt = noesis.NOESISTEX_DXT1
    #DXT3
    elif TexID == "DXT3":
        texFmt = noesis.NOESISTEX_DXT3
    #DXT5
    elif TexID == "DXT5":
        texFmt = noesis.NOESISTEX_DXT5
    #DXT10
    elif TexID == "DX10":
        if DX10Type == 83:
            ddsData = rapi.imageDecodeDXT(ddsData, TWidth, Height, noesis.FOURCC_BC5)
            texFmt = noesis.NOESISTEX_RGBA32
        elif DX10Type == 80:
            ddsData = rapi.imageDecodeDXT(ddsData, TWidth, Height, noesis.FOURCC_ATI1)
            texFmt = noesis.NOESISTEX_RGBA32
    #RAW
    elif TexID == "":
        texFmt = noesis.NOESISTEX_RGBA32
    tex1 = (NoeTexture(ddsName, TWidth, Height, ddsData, texFmt))
    texList.append(tex1)

    return 1
	