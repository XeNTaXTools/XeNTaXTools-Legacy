#by Durik256
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Black Desert Online", ".pam")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)
    return 1

def noepyCheckType(data):
    if data[:4] != b'PAR ':
        return 0
    return 1
    
def noepyLoadModel(bs, mdlList):
    bs = NoeBitStream(bs)
    ctx = rapi.rpgCreateContext()
    bs.seek(4)
    ver = bs.readUShort()
    
    bs.seek(16)
    numMesh = bs.readUInt()
    bs.seek(1040)
    
    minf, mat = [], []
    for m in range(numMesh):
        curPos = bs.getOffset()
        info = [bs.readUInt() for x in range(4)]
        tx = searchString(bs)
        if ver == 1286:
            bs.seek(curPos+276)
        else:
            bs.seek(curPos+272)
        minf.append(info)
        mat.append(NoeMaterial('mat_%i'%m, tx))
    
    vsum = sum([x[0] for x in minf])
    isum = sum([x[1] for x in minf])
    stride = (bs.getSize()-bs.getOffset()-isum*2)//vsum
    
    vofs = bs.getOffset()
    iofs = vofs + vsum*stride
    print(iofs)
    
    for i,x in enumerate(minf):
        bs.seek(vofs+(x[2]*stride))
        rapi.rpgSetMaterial(mat[i].name)
        
        VBUF = bs.readBytes(x[0]*stride)
        rapi.rpgBindPositionBuffer(VBUF, noesis.RPGEODATA_FLOAT, stride)
        rapi.rpgBindUV1BufferOfs(VBUF, noesis.RPGEODATA_HALFFLOAT, stride, 16)
		
        bs.seek(iofs+(x[3]*2))
        IBUF = bs.readBytes(x[1]*2)
        rapi.rpgCommitTriangles(IBUF, noesis.RPGEODATA_USHORT, x[1], noesis.RPGEO_TRIANGLE)
    
    mdl = rapi.rpgConstructModel()
    mdl.setModelMaterials(NoeModelMaterials([], mat))
    mdlList.append(mdl)
    rapi.setPreviewOption("setAngOfs", "0 90 90")
    return 1
    
def searchString(bs):
    bytes = []
    byte = None
    while byte != 0:
        byte = bs.readUByte()
        bytes.append(byte)
    return noeAsciiFromBytes(bytes)