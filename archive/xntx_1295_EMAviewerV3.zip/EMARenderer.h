#ifndef EMARenderer_H
#define EMARenderer_H

// d3d
#define STRICT
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>
// d3d

#include "EMAData.h"
#include <string.h>
#include <stdio.h>
#include <string>
#include <stack>


#define D3DFVF_MY_VERTEX ( D3DFVF_XYZ | D3DFVF_DIFFUSE )
struct EMAVertex
{
    float p[3]; // Position of vertex in 3D space
    DWORD color;   // Color of vertex
};
/**
 * Naive animated skeleton rendering, will use a matrix palette and according shader when animation works
 */
class EMARenderer
{
    EMAData emaData;
    LPDIRECT3DVERTEXBUFFER9 m_skelettonLinesVertexBuffer;
    unsigned long m_primitiveCount;

public:
    EMARenderer ()
        : m_primitiveCount(0)
    {       
        m_skelettonLinesVertexBuffer     = NULL;
    }
    ~EMARenderer ()
    {
    }

    bool setup(LPDIRECT3DDEVICE9 d3dDevice, 
        std::string emaFileName, unsigned long emaBlockOffset, unsigned long emaBlockSize,
        std::string animationFileName, unsigned long animationBlockOffset, unsigned long animationBlockSize)
    {
        invalidateDeviceObjects(d3dDevice);

        bool ok = emaData.load(emaFileName, emaBlockOffset, emaBlockSize, animationFileName, animationBlockOffset, animationBlockSize);

        restoreDeviceObjects(d3dDevice);

        return ok;
    }
    void render(LPDIRECT3DDEVICE9 d3dDevice)
    {
        if( m_skelettonLinesVertexBuffer )
        {
            d3dDevice->SetVertexShader(NULL);
            d3dDevice->SetPixelShader(NULL);
	        d3dDevice->SetRenderState(D3DRS_LIGHTING, FALSE);
	        d3dDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);

            d3dDevice->BeginScene();
            d3dDevice->SetStreamSource( 0, m_skelettonLinesVertexBuffer, 0, sizeof(EMAVertex) );
            d3dDevice->SetFVF( D3DFVF_MY_VERTEX );
            d3dDevice->DrawPrimitive( D3DPT_LINELIST, 0, m_primitiveCount);
            d3dDevice->EndScene();
        }
    }
    void invalidateDeviceObjects(LPDIRECT3DDEVICE9 d3dDevice)
    {
        if( m_skelettonLinesVertexBuffer != NULL )
        {
            m_skelettonLinesVertexBuffer->Release();
            m_skelettonLinesVertexBuffer = NULL;
        }
        m_primitiveCount = 0;

    }

    #ifndef M_PI
    #define M_PI 3.141592653589793238462643
    #endif
    void composeMatrix (float const rotation[3], float const scale[3], float const translation[3], D3DXMATRIX &matrix)
    {
        
        D3DXMATRIX translationMatrix, scalingMatrix, rotationMatrix;
        D3DXMatrixTranslation(&translationMatrix, translation[0], translation[1], translation[2]);
        D3DXMatrixScaling(&scalingMatrix, scale[0], scale[1], scale[2]);

        //Euler
        D3DXMATRIX rotationOxMatrix, rotationOyMatrix, rotationOzMatrix;
        D3DXMatrixRotationX(&rotationOxMatrix, rotation[1] * (float)(M_PI / 180.));
        D3DXMatrixRotationY(&rotationOyMatrix, rotation[0] * (float)(M_PI / 180.));
        D3DXMatrixRotationZ(&rotationOzMatrix, rotation[2] * (float)(M_PI / 180.));
        
        rotationMatrix = rotationOxMatrix * rotationOyMatrix * rotationOzMatrix;
        //rotationMatrix = rotationOxMatrix * rotationOzMatrix * rotationOyMatrix;
        //rotationMatrix = rotationOyMatrix * rotationOxMatrix * rotationOzMatrix;
        //rotationMatrix = rotationOyMatrix * rotationOzMatrix * rotationOxMatrix;
        //rotationMatrix = rotationOzMatrix * rotationOyMatrix * rotationOxMatrix;
        //rotationMatrix = rotationOzMatrix * rotationOxMatrix * rotationOyMatrix;


        //store result
        matrix =  scalingMatrix * rotationMatrix * translationMatrix;
    }
    void restoreDeviceObjects(LPDIRECT3DDEVICE9 d3dDevice)
    {
        emaData.setupFrame(0);
        EMAData::SkelettonNodePerNumberMap &skelettonNodes = emaData.m_skelettonNodes;

        m_primitiveCount = skelettonNodes.size();
        EMAVertex* lineListBuffer = new EMAVertex[2*m_primitiveCount];
        unsigned int i = 0;
        for(EMAData::SkelettonNodePerNumberMap::const_iterator it=skelettonNodes.begin();
            it!=skelettonNodes.end();it++, i++)
        {
            EMAData::EMASkelettonNode const& node = it->second;

            D3DXMATRIX totalParent;
            D3DXMatrixIdentity(&totalParent);

            //local transforms at first child -> parent order
            std::stack<EMAData::SkelettonNodePerNumberMap::const_iterator> parentStack;
            unsigned short parentNumber = node.parent;
            EMAData::SkelettonNodePerNumberMap::const_iterator parentIt = skelettonNodes.find(parentNumber);
            while ( skelettonNodes.end() != parentIt && parentNumber != 0xFFFF)
            {
                EMAData::EMASkelettonNode const& nodeParent = parentIt->second;
                if(parentNumber != nodeParent.number || nodeParent.number == nodeParent.parent)
                {
                    break;
                }

                //store skeleton node for subsequent reversed parent -> child order processing
                parentStack.push(parentIt);

                //previous parent is now the current parent's child
                const D3DXMATRIX& child(totalParent);
                


                D3DXMATRIX currentParentInit(nodeParent.matrix);
                D3DXMATRIX currentParentLocalAnim;
                composeMatrix(nodeParent.animatedRotation, nodeParent.animatedScale, nodeParent.animatedTranslation, currentParentLocalAnim);
                totalParent = child * currentParentInit * currentParentLocalAnim;

                //find parent
                parentNumber = nodeParent.parent;
                parentIt = skelettonNodes.find(parentNumber);

            }

            //global transforms at last in parent -> child order
            while(!parentStack.empty())
            {
                EMAData::EMASkelettonNode const& nodeParent = parentStack.top()->second;
                
                D3DXMATRIX global;
                composeMatrix(nodeParent.animatedGlobalRotation, nodeParent.animatedGlobalScale, nodeParent.animatedGlobalTranslation, global);
                totalParent = totalParent * global;

                //alternative global transforms setup by "patching"/"overriding" transformation components
                //MathHelpers::patchMatrix(nodeParent.animatedGlobalRotation, nodeParent.animatedGlobalScale, nodeParent.animatedGlobalTranslation,
                //    nodeParent.animatedGlobalRotationFlag, nodeParent.animatedGlobalScaleFlag, nodeParent.animatedGlobalTranslationFlag, 
                //    (float*)totalParent);

                
                parentStack.pop();
            }

            D3DXMATRIX initMatrix(node.matrix);

            D3DXMATRIX localAnimMatrix;
            composeMatrix(node.animatedRotation, node.animatedScale, node.animatedTranslation, localAnimMatrix);

            D3DXMATRIX global;
            composeMatrix(node.animatedGlobalRotation, node.animatedGlobalScale, node.animatedGlobalTranslation, global);

            D3DXMATRIX matrix = initMatrix * localAnimMatrix * totalParent * global;

            //alternative global transforms setup by "patching"/"overriding" transformation components
            //MathHelpers::patchMatrix(node.animatedGlobalRotation, node.animatedGlobalScale, node.animatedGlobalTranslation,
            //    node.animatedGlobalRotationFlag, node.animatedGlobalScaleFlag, node.animatedGlobalTranslationFlag, 
            //    (float*)matrix);

            D3DXVECTOR3 zero(0, 0, 0);
            D3DXVECTOR4 selfPos;
            D3DXVECTOR4 parentPos;
            D3DXVec3Transform(&selfPos, &zero, &matrix);
            D3DXVec3Transform(&parentPos, &zero, &totalParent);

            lineListBuffer[2*i].p[0] = selfPos.x;
            lineListBuffer[2*i].p[1] = selfPos.y;
            lineListBuffer[2*i].p[2] = selfPos.z;
            lineListBuffer[2*i].color = D3DCOLOR_COLORVALUE( 1.0, 0.0, 0.0, 1.0 );
            lineListBuffer[2*i+1].p[0] = parentPos.x;
            lineListBuffer[2*i+1].p[1] = parentPos.y;
            lineListBuffer[2*i+1].p[2] = parentPos.z;
            lineListBuffer[2*i+1].color = D3DCOLOR_COLORVALUE( 1.0, 0.0, 0.0, 1.0 );

        };
        d3dDevice->CreateVertexBuffer( 2*m_primitiveCount*sizeof(EMAVertex), 0, D3DFVF_MY_VERTEX,
            D3DPOOL_DEFAULT, &m_skelettonLinesVertexBuffer,
            NULL );

        if(m_skelettonLinesVertexBuffer)
        {
            void* pVertices = NULL;
            m_skelettonLinesVertexBuffer->Lock( 0, 2*m_primitiveCount*sizeof(EMAVertex), (void**)&pVertices, 0 );
            memcpy( pVertices, lineListBuffer, 2*m_primitiveCount*sizeof(EMAVertex) );
            m_skelettonLinesVertexBuffer->Unlock();
        }
        delete[] lineListBuffer;

    }


};
#endif //EMARenderer_H