#ifndef EMAData_H
#define EMAData_H

#include <stdio.h>
#include <map>
#include <vector>
#include <assert.h>

struct EMAData
{

    #pragma pack(push)
    #pragma pack(1)
    struct EMAAnimationHeader
    {
        unsigned short duration;
        unsigned short cmdOffsetCount;
        unsigned long offset;
        unsigned long zero;
        unsigned long nameOffset;
        unsigned long nextHalfOffset;
    };
    struct EMAAnimationCommandHeader
    {
        unsigned short boneIndex;
        unsigned char transformType;//0 -> translation, 1 -> rotation, 2->scale
        unsigned char flags;//4bits : ? / 2bits: transform component ( a record has 0, the next 1, then 2 )
        unsigned short stepCount;
        unsigned short indicesOffset;
    };
    struct EMASkelettonHeader
    {
        unsigned short nodeCount;
        unsigned short unknown3;
        unsigned long unknown4;//small number
        unsigned long skeletonStartOffset;
        unsigned long skeletonNameAddressOffset;
        unsigned long unknown5;
        unsigned long unknown6;//0
        unsigned long unknown7;//address for bunch of FF's
        unsigned long matrixOffset;
    };
    struct EMASkelettonNodeTemp
    {
        unsigned short parent;//FFFF if root
        unsigned short child1;
        unsigned short child2;//FFFF if none
        unsigned short child3;//FFFF if none
        unsigned short child4;//FFFF if none
        unsigned short flags;
        unsigned long unknown4;//0
        float matrix[16];
    };
    struct EMASkelettonNode
    {
        unsigned short parent;//FFFF if root
        unsigned short number;
        float matrix[16];

        //runtime values (filled after a EAMData::setupFrame() call)
        float animatedRotation[3];
        float animatedScale[3];
        float animatedTranslation[3];

        float animatedGlobalRotation[3];
        float animatedGlobalScale[3];
        float animatedGlobalTranslation[3];

        bool animatedGlobalRotationFlag[3];
        bool animatedGlobalScaleFlag[3];
        bool animatedGlobalTranslationFlag[3];
    };
    #pragma pack(pop)


    struct EMAAnimationCommandStep
    {
        unsigned short timing;
        unsigned int index;
        unsigned int tangentIndex;
    };
    enum ETransformType
    {
         E_TRANSLATION = 0
        ,E_ROTATION
        ,E_SCALING
        ,E_NOP = -1
    };
    typedef std::vector<EMAAnimationCommandStep> CommandSequence;
    struct Commands
    {
        CommandSequence steps;
        bool absolute;
    };
    typedef std::map<unsigned char, Commands> CommandsPerComponent;
    typedef std::map<EMAData::ETransformType, CommandsPerComponent> CommandsPerComponentPerType;
    typedef std::map<unsigned short, CommandsPerComponentPerType> CommandsPerComponentPerTypePerBone;
    struct EMAAnimation
    {
        std::string name;
        unsigned short duration;
        std::vector<float> values;
        CommandsPerComponentPerTypePerBone commandsPerComponentPerTypePerBone;
    };
public:
    typedef std::map<unsigned short, EMASkelettonNode> SkelettonNodePerNumberMap;
    EMAAnimationHeader m_animationHeader;
    unsigned long m_nodeCount;
    SkelettonNodePerNumberMap m_skelettonNodes;
    std::map<unsigned short, std::string> m_skelettonNodeNames;
    float m_matrix[16];
    
    EMAAnimation m_animation;

    EMAData()
    {        
    }
    ~EMAData()
    {
        freeData();
    }

    void freeData()
    {
        m_nodeCount = 0;
        m_skelettonNodes.clear();
        m_skelettonNodeNames.clear();
    }
    std::string const& getName()const
    {   
        return m_animation.name;
    }

    void setupFrame(unsigned int frame)
    {

        for(EMAData::SkelettonNodePerNumberMap::iterator itNode=m_skelettonNodes.begin();
                itNode!=m_skelettonNodes.end();itNode++)
        {
            EMAData::EMASkelettonNode & node = itNode->second;
                    

            CommandsPerComponentPerTypePerBone::const_iterator boneCommandsIt = m_animation.commandsPerComponentPerTypePerBone.find( node.number );
            if ( m_animation.commandsPerComponentPerTypePerBone.end() != boneCommandsIt )
            {                
                CommandsPerComponentPerType const& commandsPerComponentPerType = boneCommandsIt->second;
                for(unsigned char component = 0;component<=2;component++)
                {
                    getTransform(boneCommandsIt->second, EMAData::E_ROTATION,      component, frame, node.animatedRotation[component],    node.animatedGlobalRotation[component],    node.animatedGlobalRotationFlag[component],    0.f);
                    getTransform(boneCommandsIt->second, EMAData::E_TRANSLATION,   component, frame, node.animatedTranslation[component], node.animatedGlobalTranslation[component], node.animatedGlobalTranslationFlag[component], 0.f);
                    getTransform(boneCommandsIt->second, EMAData::E_SCALING,       component, frame, node.animatedScale[component],       node.animatedGlobalScale[component],       node.animatedGlobalScaleFlag[component],       1.f);
                }
            }
            else
            {
                //no bone animation
                node.animatedRotation[0]=0.f;
                node.animatedRotation[1]=0.f;
                node.animatedRotation[2]=0.f;
                node.animatedTranslation[0]=0.f;
                node.animatedTranslation[1]=0.f;
                node.animatedTranslation[2]=0.f;
                node.animatedScale[0]=1.f;
                node.animatedScale[1]=1.f;
                node.animatedScale[2]=1.f;

                node.animatedGlobalRotation[0]=0.f;
                node.animatedGlobalRotation[1]=0.f;
                node.animatedGlobalRotation[2]=0.f;
                node.animatedGlobalTranslation[0]=0.f;
                node.animatedGlobalTranslation[1]=0.f;
                node.animatedGlobalTranslation[2]=0.f;
                node.animatedGlobalScale[0]=1.f;
                node.animatedGlobalScale[1]=1.f;
                node.animatedGlobalScale[2]=1.f;

                node.animatedGlobalRotationFlag[0]=false;
                node.animatedGlobalRotationFlag[1]=false;
                node.animatedGlobalRotationFlag[2]=false;
                node.animatedGlobalTranslationFlag[0]=false;
                node.animatedGlobalTranslationFlag[1]=false;
                node.animatedGlobalTranslationFlag[2]=false;
                node.animatedGlobalScaleFlag[0]=false;
                node.animatedGlobalScaleFlag[1]=false;
                node.animatedGlobalScaleFlag[2]=false;

            }
        }
    }
    void getTransform(CommandsPerComponentPerType const& commandsPerComponentPerType, EMAData::ETransformType type, unsigned char component, unsigned int frame, float &localValue, float& globalValue, bool& globalValueFlag, float defaultValue)
    {
        float value;
        if(getTransform(commandsPerComponentPerType, type, component, frame, value, globalValueFlag))
        {
            if(globalValueFlag)
            {
                localValue=defaultValue;
                globalValue=value;
            }
            else
            {
                localValue=value;
                globalValue=defaultValue;
            }
        }
        else
        {
            globalValueFlag = false;
            localValue=defaultValue;
            globalValue=defaultValue;
        }
            
    }
    bool getTransform(CommandsPerComponentPerType const& commandsPerComponentPerType, EMAData::ETransformType type, unsigned char component, unsigned int frame, float &value, bool& globalValueFlag)
    {
        CommandsPerComponentPerType::const_iterator itCommandsPerType=commandsPerComponentPerType.find(type);
        if(itCommandsPerType!=commandsPerComponentPerType.end())
        {           
            CommandsPerComponent const& commandsPerComponent(itCommandsPerType->second);
            CommandsPerComponent::const_iterator itCommandsPerComponent = commandsPerComponent.find(component);
            if(itCommandsPerComponent != commandsPerComponent.end())
            {
                Commands const& commands(itCommandsPerComponent->second);
                CommandSequence const& commandSequence(commands.steps);
                for(std::vector<EMAAnimationCommandStep>::const_iterator itStep = commandSequence.begin();
                    itStep != commandSequence.end();
                    ++itStep)
                {
                    if(itStep->timing >= frame)
                    {
                        //here we should interpolate.....
                        value = m_animation.values[itStep->index];
                        globalValueFlag = commands.absolute;
                        return true;
                    }
                }
            }
        }
        return false;
    }

    void dumpFile(FILE* dump) const
    {

        //dump header
        fprintf(dump, "\nduration: %d\n", m_animation.duration);

        //key frame timings and indices
        fprintf(dump, "\nanimation:\n");

        for ( CommandsPerComponentPerTypePerBone::const_iterator boneCommandsIt = m_animation.commandsPerComponentPerTypePerBone.begin();
            m_animation.commandsPerComponentPerTypePerBone.end() != boneCommandsIt ; ++boneCommandsIt )
        {
            unsigned short boneIndex = boneCommandsIt->first;
            CommandsPerComponentPerType const& commandsPerComponentPerType = boneCommandsIt->second;
            for(CommandsPerComponentPerType::const_iterator itCommandsPerType=commandsPerComponentPerType.begin();
                itCommandsPerType!=commandsPerComponentPerType.end() ; ++itCommandsPerType )
            {           
                EMAData::ETransformType transformType = itCommandsPerType->first;
                CommandsPerComponent const& commandsPerComponent = itCommandsPerType->second;
                for(CommandsPerComponent::const_iterator itCommandsPerComponent = commandsPerComponent.begin();
                    itCommandsPerComponent != commandsPerComponent.end();
                    ++itCommandsPerComponent)
                {
                    unsigned char transformComponent = itCommandsPerComponent->first;
                    Commands const& commands(itCommandsPerComponent->second);
                    CommandSequence const& commandSequence(commands.steps);
            
                    fprintf(dump, "bone:%3d %c%c %d (%s)", 
                        boneIndex, 
                        transformType==EMAData::E_TRANSLATION?'t':transformType==EMAData::E_ROTATION?'r':transformType==EMAData::E_SCALING?'s':'?',
                        transformComponent==0?'x':transformComponent==1?'y':transformComponent==2?'z':'?',
                        commandSequence.size(), commands.absolute?"absolute":"local");
                    fprintf(dump, ", timings:");
                    for(std::vector<EMAAnimationCommandStep>::const_iterator itStep = commandSequence.begin();
                        itStep != commandSequence.end();
                        ++itStep)
                    {
                        fprintf(dump, " %d", itStep->timing);
                    }
                    fprintf(dump, ", indices:");
                    for(std::vector<EMAAnimationCommandStep>::const_iterator itStep = commandSequence.begin();
                        itStep != commandSequence.end();
                        ++itStep)
                    {
                        fprintf(dump, " %d", itStep->index);
                    }
                    fprintf(dump, ", tangent indices:");
                    for(std::vector<EMAAnimationCommandStep>::const_iterator itStep = commandSequence.begin();
                        itStep != commandSequence.end();
                        ++itStep)
                    {
                        fprintf(dump, " %d", itStep->tangentIndex);
                    }
                    fprintf(dump, ", values:");
                    for(std::vector<EMAAnimationCommandStep>::const_iterator itStep = commandSequence.begin();
                        itStep != commandSequence.end();
                        ++itStep)
                    {
                        fprintf(dump, " %f", m_animation.values[itStep->index]);
                    }
                    fprintf(dump, ", tangents:");
                    for(std::vector<EMAAnimationCommandStep>::const_iterator itStep = commandSequence.begin();
                        itStep != commandSequence.end();
                        ++itStep)
                    {
                        if(itStep->tangentIndex != ~0)
                        {
                            fprintf(dump, " %f", m_animation.values[itStep->tangentIndex]);
                        }
                        else
                        {
                            fprintf(dump, " nop");
                        }
                    }
                    fprintf(dump, "\n");
                }
            }
        }

        //dump skel
        fprintf(dump, "\nvalues:\n");
        for(std::vector<float>::const_iterator it = m_animation.values.begin();it != m_animation.values.end();++it)
        {
            fprintf(dump, "%f\n", *it);
        }
        //dump skel
        fprintf(dump, "\nskeleton:\n");
        for(SkelettonNodePerNumberMap::const_iterator it = m_skelettonNodes.begin();it != m_skelettonNodes.end();++it)
        {
            
            fprintf(dump, "%3d parent: %d", it->first, it->second.parent);

            //float rotation[3], scale[3], translation[3];
            //MathHelpers::decomposeMatrix(rotation, scale, translation, it->second.matrix);
            //fprintf(dump, " r(");for(unsigned long i=0;i<3;i++)fprintf(dump, " %f", rotation     [i]);fprintf(dump, ")");
            //fprintf(dump, " s(");for(unsigned long i=0;i<3;i++)fprintf(dump, " %f", scale        [i]);fprintf(dump, ")");
            //fprintf(dump, " t(");for(unsigned long i=0;i<3;i++)fprintf(dump, " %f", translation  [i]);fprintf(dump, ")");
            fprintf(dump, " matrix(");for(unsigned long i=0;i<16;i++)fprintf(dump, " %f", it->second.matrix[i]);fprintf(dump, ")");
             
            std::map<unsigned short, std::string>::const_iterator itName = m_skelettonNodeNames.find( it->first ) ;
            if( itName != m_skelettonNodeNames.end() )
            {
                fprintf(dump, " name: %s", itName->second.c_str());
            }
            fprintf(dump, "\n");


        }
    }
    
    static std::string readString(FILE *file, unsigned char length)
    {
        std::string stdstring;
        char* str = new char[length+1];
        str[length] = 0;
        fread (str, sizeof (char), length, file);
        stdstring = str;
        delete[] str;
        return stdstring;
    }
    static std::string readZeroTerminatedString(FILE *file)
    {
        std::string s;
        char c;
        for(;;)
        {
            fread (&c, sizeof (char), 1, file);
            if(c)
            {
                s.push_back(c);
            }
            else
            {
                break;
            }
        }
        return s;
    }
	bool readAnimation (FILE *file, unsigned long animationBlockOffset, unsigned long animationBlockSize)
    {
        m_animation.commandsPerComponentPerTypePerBone.clear();
        m_animation.values.clear();

        fseek (file, animationBlockOffset, SEEK_SET);
	    fread (&m_animationHeader, sizeof (EMAAnimationHeader), 1, file);

        unsigned long* cmdOffsets = new unsigned long[m_animationHeader.cmdOffsetCount];
	    fread (cmdOffsets, sizeof (unsigned long), m_animationHeader.cmdOffsetCount, file);
      
        //second half of the animation (float values)
        unsigned int valueCount = (animationBlockSize - m_animationHeader.nextHalfOffset)/4;
        fseek (file, animationBlockOffset+m_animationHeader.nextHalfOffset, SEEK_SET);
        float* values = new float[valueCount];
	    fread (values, sizeof (float), valueCount, file);
        m_animation.values.reserve(valueCount);
        float* currentValue = values;
        for(unsigned long i=0;i<valueCount;i++, currentValue++)
        {
            m_animation.values.push_back(*currentValue);
        }
        delete[] values;

        m_animation.duration = m_animationHeader.duration;

        //animation name
        fseek (file, animationBlockOffset+m_animationHeader.nameOffset+10, SEEK_SET);

        unsigned char stringLen;
	    fread (&stringLen, sizeof (unsigned char), 1, file);
        m_animation.name = readString(file, stringLen);

        for(unsigned long i=0;i<m_animationHeader.cmdOffsetCount;i++)
        {

            int currentOffset = animationBlockOffset+cmdOffsets[i];
            int currentSize = ((i+1)<m_animationHeader.cmdOffsetCount ? cmdOffsets[i+1] : m_animationHeader.nextHalfOffset)-cmdOffsets[i];
            fseek (file, currentOffset, SEEK_SET);
            EMAAnimationCommandHeader commandHeader;
	        fread (&commandHeader, sizeof (EMAAnimationCommandHeader), 1, file);

            EMAData::ETransformType transformType = 
                commandHeader.transformType == 0 ? EMAData::E_TRANSLATION 
                : commandHeader.transformType == 1 ? EMAData::E_ROTATION 
                : commandHeader.transformType == 2 ? EMAData::E_SCALING 
                : EMAData::E_NOP;
            unsigned char transformComponent = commandHeader.flags & 0x03;
            CommandsPerComponentPerType &commandsPerComponentPerType = m_animation.commandsPerComponentPerTypePerBone[commandHeader.boneIndex];
            CommandsPerComponent &commandsPerComponent = commandsPerComponentPerType[transformType];
            Commands& commands = commandsPerComponent[transformComponent];
            CommandSequence& commandSequence(commands.steps);
            commands.absolute = (commandHeader.flags & 0x10)!=0;

            commands.steps.resize(commandHeader.stepCount);

            unsigned int readBytes =0;
            if( commandHeader.flags & 0x20 )
            {
                assert( m_animation.duration > 0xFF );
                for(CommandSequence::iterator itStep = commandSequence.begin();itStep != commandSequence.end();++itStep)
                {
                    unsigned short timing;
	                readBytes+=fread (&timing, sizeof (unsigned short), 1, file)*sizeof (unsigned short);
                    itStep->timing = timing;
                }
            }
            else
            {
                assert( m_animation.duration <= 0xFF );
                for(CommandSequence::iterator itStep = commandSequence.begin();itStep != commandSequence.end();++itStep)
                {
                    unsigned char timing8;
	                readBytes+=fread (&timing8, sizeof (unsigned char), 1, file)*sizeof (unsigned char);
                    itStep->timing = timing8;
                }
            }
            if(readBytes<commandHeader.indicesOffset)
            {
                fseek (file, currentOffset+commandHeader.indicesOffset, SEEK_SET);
            }

            if( commandHeader.flags & 0x40 )
            {
                assert( valueCount > 0x3FFF );
                for(CommandSequence::iterator itStep = commandSequence.begin();itStep != commandSequence.end();++itStep)
                {
                    unsigned long index;
	                fread (&index, sizeof (unsigned long), 1, file);
                    itStep->index = (index & 0x3FFFFFFF);
                    unsigned char highOrderBits = ((index >> 30)&0x03);
                    itStep->tangentIndex = highOrderBits == 0 ? ~0 : (itStep->index  + highOrderBits);
                }
            }
            else
            {
                assert( valueCount <= 0x3FFF );
                for(CommandSequence::iterator itStep = commandSequence.begin();itStep != commandSequence.end();++itStep)
                {
                    unsigned short index16;
	                fread (&index16, sizeof (unsigned short), 1, file);
                    itStep->index = (index16 & 0x3FFF);
                    unsigned char highOrderBits = ((index16 >> 14)&0x03);
                    itStep->tangentIndex = highOrderBits == 0 ? ~0 : (itStep->index  + highOrderBits);
                }
            }

        }
        delete[] cmdOffsets;
        return true;
    }
    
    bool load(std::string emaFileName, unsigned long emaBlockOffset, unsigned long emaBlockSize,
        std::string animationFileName, unsigned long animationBlockOffset, unsigned long animationBlockSize)
    {
        freeData();

        FILE *file = fopen (emaFileName.c_str(), "rb");
        if(file == 0)
        {
            return false;
        }
        char tokenEMA[5];
        tokenEMA[4] = 0;
        fseek (file, emaBlockOffset, SEEK_SET);
        fread (tokenEMA, sizeof (unsigned char), 4, file);
        if(strcmp("#EMA" , tokenEMA)!=0)
        {
            fclose (file);
            return false;
        }
            
        //#EMA -> base skeleton pose
        
        fseek (file, emaBlockOffset+6, SEEK_SET);
        unsigned short headerSize;
        fread (&headerSize, sizeof (unsigned short), 1, file);

        fseek (file, emaBlockOffset+12, SEEK_SET);
        unsigned long skeletonOffset;
        fread (&skeletonOffset, sizeof (unsigned long), 1, file);

        unsigned long skeletonAdress = emaBlockOffset + skeletonOffset;
        
        fseek (file, skeletonAdress, SEEK_SET);
        EMASkelettonHeader skelettonHeader;
        fread (&skelettonHeader, sizeof (EMASkelettonHeader), 1, file);
       
        m_nodeCount = skelettonHeader.nodeCount;
        
        unsigned int *skeletonNameAddresses = new unsigned int[m_nodeCount];
        fseek (file, skeletonAdress + skelettonHeader.skeletonNameAddressOffset, SEEK_SET);
        fread (skeletonNameAddresses, sizeof (unsigned int), m_nodeCount, file);

        std::vector<std::string> tempSkelettonNodeNames;
        for(unsigned int i=0;i<m_nodeCount;i++)
        {
            fseek (file, skeletonAdress + skeletonNameAddresses[i], SEEK_SET);
            tempSkelettonNodeNames.push_back( readZeroTerminatedString(file) );
        }
        delete[] skeletonNameAddresses;
        
        //Nodes
        std::vector<EMASkelettonNodeTemp> tempSkelettonNodes;
        fseek (file, skeletonAdress + skelettonHeader.skeletonStartOffset, SEEK_SET);
        for(unsigned int i=0;i<m_nodeCount;i++)
        {
            EMASkelettonNodeTemp skelettonNodeTemp;
            fread (&skelettonNodeTemp, sizeof (EMASkelettonNodeTemp), 1, file);
            tempSkelettonNodes.push_back( skelettonNodeTemp );

            EMASkelettonNode skelettonNode;
            skelettonNode.number = i;
            skelettonNode.parent = skelettonNodeTemp.parent;
            memcpy(skelettonNode.matrix, skelettonNodeTemp.matrix, 16*sizeof(float));
            
            m_skelettonNodes.insert(SkelettonNodePerNumberMap::value_type(i, skelettonNode));
            m_skelettonNodeNames.insert(std::map<unsigned short, std::string>::value_type(i, tempSkelettonNodeNames[i]));
        }


        //Matrix
        if(skelettonHeader.matrixOffset != 0)
        {
            fseek (file, skeletonAdress + skelettonHeader.matrixOffset, SEEK_SET);
            fread (m_matrix, 16*sizeof (float), 1, file);
            // [m00 m01 m02]
            // [m10 m11 m12]
            // [m20 m21 m22]
            // heading = Math.atan2(-m.m20,m.m00);
            // bank = Math.atan2(-m.m12,m.m11);
            // attitude = Math.asin(m.m10);
            float translation[] = {-m_matrix[12],m_matrix[14],m_matrix[13]};
            float rx = atan2( -m_matrix[2], m_matrix[0] );
            float ry = atan2( -m_matrix[9], m_matrix[5] );
            float rz = asin( m_matrix[1] );
        }
        else
        {
            memset(m_matrix, 0, 16*sizeof (float));
            m_matrix[0] = m_matrix[5] = m_matrix[10] = m_matrix[15] = 1.f;
        }


        if(animationFileName != emaFileName)
        {
            fclose (file);
            FILE *file = fopen (animationFileName.c_str(), "rb");
        }

        readAnimation(file, animationBlockOffset, animationBlockSize);

        fclose (file);


        return true;
    }
};


#endif //EMAData_H