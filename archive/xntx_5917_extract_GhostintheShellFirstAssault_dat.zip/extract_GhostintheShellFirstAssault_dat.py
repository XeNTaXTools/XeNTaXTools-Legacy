from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Ghost in the shell: First Assault", ".dat")
    noesis.setHandlerExtractArc(handle, pacExtractArc)
    #noesis.logPopup()
    return 1
    
def pacExtractArc(fileName, fileLen, justChecking):
    with open(fileName, "rb") as file:
        bs = NoeBitStream(file.read(fileLen))
    if justChecking:
        return 1
    bs.seek(bs.getSize() - 6, NOESEEK_ABS)
    tableOff = bs.readUInt()
    while True:
        bs.seek(tableOff, NOESEEK_ABS)
        idx_sig = bs.readUInt()
        if idx_sig != 0x2a2ceb87:
            break
        bs.seek(0x10, NOESEEK_REL)
        size = bs.readUInt()
        bs.seek(0x4, NOESEEK_REL)
        temp_namelength = bs.readUInt()
        bs.seek(0xA, NOESEEK_REL)
        file_offset = bs.readUInt()
        bs.seek(temp_namelength, NOESEEK_REL)
        tableOff = bs.tell()
        bs.seek(file_offset, NOESEEK_ABS)
        chunk_sig = bs.readUInt()
        bs.seek(0x16, NOESEEK_REL)
        nameSize = bs.readUShort()
        skip = bs.readUShort()
        fileName = bs.readBytes(nameSize).decode("ASCII")
        bs.seek(skip, NOESEEK_REL)
        rapi.exportArchiveFile(fileName, bs.readBytes(size))
    return 1