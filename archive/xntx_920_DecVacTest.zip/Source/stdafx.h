// stdafx.h : Precompiled header
//

#pragma once

#include <tchar.h>
#include <iostream>
#include <fstream>
#include <string>

#define WIN32_LEAN_AND_MEAN
#define VC_EXTRALEAN
#include <windows.h>
