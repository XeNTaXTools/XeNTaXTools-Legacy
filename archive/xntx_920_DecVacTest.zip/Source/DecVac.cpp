// DecVac.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "WaveWriter.h"

// Vox Library
typedef void* TInputFilterHandle;
typedef TInputFilterHandle (__stdcall *TOpenFilterInput)(const char* Filename, unsigned long* SampleRate, unsigned short* BitsPerSample, unsigned short* Channels, unsigned long Reserved, unsigned long* Pointer4);
typedef void (__stdcall *TCloseFilterInput)(TInputFilterHandle Handle);
typedef long (__stdcall *TReadFilterInput)(TInputFilterHandle Handle, void* Buffer, unsigned long BufferSize);

// The arguments sent to the application
struct SArguments
{
	SArguments() :
		ShowBanner(true),
		ShowUsage(false),
		InputFilename(""),
		OutputFilename(""),
		OuputWaveFile(true),
		OutputSampleRate(22050)
	{
	};

	bool ShowBanner;
	bool ShowUsage;
	std::string InputFilename;
	std::string OutputFilename;
	bool OuputWaveFile;
	unsigned long OutputSampleRate;
};

// Parse the arguments sent to the program
bool ParseArguments(SArguments& Args, unsigned long Argc, _TCHAR* Argv[])
{
	// Go through each of the arguments sent
	for(unsigned long i=1;i<Argc;)
	{
		std::string Arg(Argv[i++]);
		
		// Check it
		if(Arg=="-b" || Arg=="--no-banner")
		{
			Args.ShowBanner=false;
		}
		else if(Arg=="-o" || Arg=="--output")
		{
			if(i>=Argc)
			{
				return false;
			}
			Args.OutputFilename=std::string(Argv[i++]);
		}
		else if(Arg=="-w" || Arg=="--wave")
		{
			Args.OuputWaveFile=true;
		}
		else if(Arg=="-r" || Arg=="--raw")
		{
			Args.OuputWaveFile=false;
		}
		else if(Arg=="--sample-rate")
		{
			if(i>=Argc)
			{
				return false;
			}
			Args.OutputSampleRate=atoi(Argv[i++]);
		}
		else
		{
			Args.InputFilename=Arg;
		}
	}
	return true;
}

int _tmain(int Argc, _TCHAR* Argv[])
{
	// Parse the arguments
	SArguments Args;
	if(Argc==1)
	{
		Args.ShowUsage=true;
	}
	bool ArgParse=ParseArguments(Args, Argc, Argv);

	// Display banner
	if(Args.ShowBanner)
	{
		std::cerr << "StarTrek VAC Test-Decoder (Not guaranteed to work!)" << std::endl << std::endl;
	}

	// Display usage
	if(Args.ShowUsage)
	{
		std::cout << "Usage: DecVac InputFilename [Options]" << std::endl;
		std::cout << std::endl;
		std::cout << "  -o, --output File     Specify the output filename" << std::endl;
		std::cout << "  -w, --wave            Output a standard wave file (.wav)" << std::endl;
		std::cout << "  -r, --raw             Output raw data (no header)" << std::endl;
		std::cout << "  --sample-rate Rate    Force a specific sampling rate" << std::endl;
		std::cout << std::endl;
	}

	// Check for errors
	if(!ArgParse)
	{
		std::cerr << "The arguments are not valid." << std::endl;
		return 1;
	}
	if(Args.InputFilename.empty())
	{
		std::cerr << "You need to enter an input filename." << std::endl;
		return 1;
	}
	if(Args.OutputFilename.empty())
	{
		std::cerr << "You need to enter an output filename." << std::endl;
		return 1;
	}

	// Load the Vox Library
	HMODULE VoxLibrary;
	VoxLibrary=LoadLibrary("VOX.FLT");
	if(!VoxLibrary)
	{
		std::cerr << "Could not load VOX.FLT. ";
		std::cerr << "Make sure that it is in the same directory as this executable." << std::endl;
		return 1;
	}

	// Load the functions
	TOpenFilterInput OpenFilterInput;
	TCloseFilterInput CloseFilterInput;
	TReadFilterInput ReadFilterInput;
	OpenFilterInput=(TOpenFilterInput)GetProcAddress(VoxLibrary, "OpenFilterInput");
	CloseFilterInput=(TCloseFilterInput)GetProcAddress(VoxLibrary, "CloseFilterInput");
	ReadFilterInput=(TReadFilterInput)GetProcAddress(VoxLibrary, "ReadFilterInput");
	if(!OpenFilterInput || !CloseFilterInput || !ReadFilterInput)
	{
		std::cerr << "Incorrect VOX.FLT version." << std::endl;
		FreeLibrary(VoxLibrary);
		return 1;
	}

	// Load the input file
	std::ifstream Input;
	Input.open(Args.InputFilename.c_str(), std::ios_base::in | std::ios_base::binary);
	if(!Input.is_open())
	{
		std::cerr << "Could not open input file \"" << Args.InputFilename << "\"." << std::endl;
		FreeLibrary(VoxLibrary);
		return 1;
	}
	Input.close();

	// Load the output file
	std::ofstream Output;
	Output.open(Args.OutputFilename.c_str(), std::ios_base::out | std::ios_base::binary | std::ios_base::trunc);
	if(!Output.is_open())
	{
		std::cerr << "Could not open output file \"" << Args.OutputFilename << "\"." << std::endl;
		FreeLibrary(VoxLibrary);
		return 1;
	}

	// Prepare the wave header
	unsigned long NumberSamples=0;
	if(Args.OuputWaveFile)
	{
		PrepareWaveHeader(Output);
	}

	// Open the filter
	TInputFilterHandle Handle;
	unsigned long SampleRate=0;
	unsigned short BitsPerSample=0;
	unsigned short Channels=0;
	unsigned long BlockSize=0;
	Handle=OpenFilterInput(Args.InputFilename.c_str(), &SampleRate, &BitsPerSample, &Channels, 0, &BlockSize);

	// Loop through the data
	short OutputBuffer[1024];
	while(true)
	{
		unsigned long BytesDecoded;
		BytesDecoded=ReadFilterInput(Handle, OutputBuffer, sizeof(OutputBuffer));
		if(BytesDecoded==0)
		{
			break;
		}
		Output.write((char*)OutputBuffer, BytesDecoded);
		NumberSamples+=BytesDecoded/(BitsPerSample/8);
	}

	// Close the filter
	CloseFilterInput(Handle);
	Handle=NULL;

	// Write the wave header
	if(Args.OuputWaveFile)
	{
		Output.seekp(0);
		WriteWaveHeader(Output, Args.OutputSampleRate, 16, (unsigned char)Channels, NumberSamples);
	}

	// Free the library
	Output.close();
	FreeLibrary(VoxLibrary);
	return 0;
}

