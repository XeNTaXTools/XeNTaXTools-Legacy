#Noesis Python model import+export test module, imports/exports some data from/to a made-up format

from inc_noesis import *

import noesis

#rapi methods should only be used during handler callbacks
import rapi

#registerNoesisTypes is called by Noesis to allow the script to register formats.
#Do not implement this function in script files unless you want them to be dedicated format modules!
def registerNoesisTypes():
	handle = noesis.register("NHL Legacy (X360)", ".rx2")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
	noesis.logPopup()
	#print("The log can be useful for catching debug prints from preview loads.\nBut don't leave it on when you release your script, or it will probably annoy people.")
	return 1
#check if it's this type based on the data
def noepyCheckType(data):
    bs = NoeBitStream(data)
    Magic = bs.readBytes(7)
    if Magic != b'\x89\x52\x57\x34\x78\x62\x32':
        return 0
    return 1
texList = []
def noepyLoadRGBA(data, texList):
	bs = NoeBitStream(data)
	bs.seek(0x30, NOESEEK_ABS)
	LData = bs.read(">ii")
	bs.seek(0x50, NOESEEK_ABS)
	Header = bs.read(">iii")
	bs.seek(0x128, NOESEEK_ABS)
	LData2 = bs.read(">ii")
	Texcount = int(((LData2[0] - LData[0]) - 24) / 48)
	bs.seek(LData[0] + 24, NOESEEK_ABS)
	Tex = []
	NameOff = []
	TexNames = []
	TexData = []
	TexRange = []
	TexSize = []
	for i in range(0, Texcount):
		Data = bs.read(">iiii")
		bs.seek(32, NOESEEK_REL)
		Tex.append([Data[0]])
	bs.seek(320 + (64 * Texcount) + 8, NOESEEK_ABS)
	for i in range(0, Texcount):
		namedata = bs.read(">i")
		bs.seek(8, NOESEEK_REL)
		NameOff.append([namedata[0]])
	for i in range(0, Texcount):
		bs.seek(NameOff[i][0], NOESEEK_ABS)
		TexNames.append(bs.readString())	
	for i in range(0, Texcount):
		bs.seek(Tex[i][0] + 33, NOESEEK_ABS)
		Data = bs.read(">HBHHiii")
		TexData.append([Data[0], Data[1], Data[2], Data[3]])
	bs.seek(LData[0], NOESEEK_ABS)
	for i in range(0, Texcount):
		Data = bs.read(">i")
		bs.seek(44, NOESEEK_REL)
		TexRange.append([Data[0]])
	for i in range(0, Texcount):
		TexSize.append(len(data) - (TexRange[i][0] + 4096)) 
	for i in range(0, Texcount):
		bs.seek(TexRange[i][0] + Header[2], NOESEEK_ABS)
		imgHeight = (TexData[i][2] + 1) * 8
		imgWidth  = (TexData[i][3] + 1) & 0x1FFF
		data = bs.readBytes(TexSize[i])
		texFmt = 0
		#DXT1
		if TexData[i][1] == 0x52:
			data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 8)
			texFmt = noesis.NOESISTEX_DXT1
		#DXT3
		elif TexData[i][1] == 0x53:
			data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 16)
			texFmt = noesis.NOESISTEX_DXT3
		#DXT5
		elif TexData[i][1] == 0x54:
			data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 16)
			texFmt = noesis.NOESISTEX_DXT5
		#DXT5 packed normal map
		elif TexData[i][1] == 0x71:
			data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 16)
			data = rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_ATI2)
			texFmt = noesis.NOESISTEX_RGBA32
		#DXT1 packed normal map
		elif TexData[i][1] == 0x7C:
			data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 8)
			data = rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_DXT1NORMAL)
			texFmt = noesis.NOESISTEX_RGBA32
		#raw
		elif TexData[i][1] == 0x86:
			data = rapi.imageUntile360Raw(data, imgWidth, imgHeight, 4)
			data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "a8r8g8b8")
			texFmt = noesis.NOESISTEX_RGBA32
		#unknown, not handled
		else:
			print("WARNING: Unhandled image format " + repr(imgFmt) + " - " + repr(imgWidth) + "x" + repr(imgHeight) + " - " + repr(len(data)))
			return None
		tex1 = NoeTexture(TexNames[i], imgWidth, imgHeight, data, texFmt)
		texList.append(tex1)
		print(tex1)
	return 1