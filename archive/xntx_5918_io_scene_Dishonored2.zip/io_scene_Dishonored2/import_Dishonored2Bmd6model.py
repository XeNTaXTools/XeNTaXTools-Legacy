# author: Volfin

import bpy
import os
import sys
import mathutils
import math
import platform
import imp
import csv
import struct
from bpy_extras.io_utils import unpack_list
from struct import *
from mathutils import Vector, Matrix, Quaternion, Euler
import time
import random

objects_ptr = [];  # list of object data structures.

def to_blender_matrix(bl_mat):
    mat = mathutils.Matrix()
    for i, col in enumerate(bl_mat):
        for k, val in enumerate(col):
            mat[k][i] = val
    return mat

def import_mesh(context,randomize_colors,use_layers,mesh_scale,msh_count,alt_format):
    
    global model_name
    ROT_Z90_MATRIX = mathutils.Matrix.Rotation(math.radians(-90.0), 4, 'Z')
    ROT_Z180_MATRIX = mathutils.Matrix.Rotation(math.radians(180.0), 4, 'Z')
    
    # lets just do this to be sure    
    if bpy.ops.object.mode_set.poll():
        bpy.ops.object.mode_set(mode='OBJECT')
    #else:
    #    print("mode_set() context is incorrect, current mode is", bpy.context.mode)

    #get internal name and append
    internal_name = file_str(BI(1)[0])
    if alt_format:
        model_name2 = model_name +'_'+str(msh_count)
    else:
        model_name2 = model_name +'_'+ internal_name
    
    me = bpy.data.meshes.new(model_name2)
    me_obj = bpy.data.objects.new(model_name2,me)
    me_obj.select = True # makes selected

    objects_ptr.extend([me_obj]) #store for later
    context.scene.objects.link(me_obj)
    context.scene.objects.active = me_obj # makes active

    # read in mesh data
    vertex=[]
    normals=[]
    uvs=[]
    UV2=[]
    UV3=[]
    colors=[]
    colors2=[]
    bone_list=[]
    w_count=[]
    m_weights=[]
    g_indices=[]
    faces=[]
    face_idx=[]

    if not alt_format:
        #material file name
        print("material path: "+file_str(BI(1)[0]))

        #skip junk
        BB(5)

    #skip junk
    BB(4)
    print("model block header (should be BTRI): "+file_str(4))

    #more junk
    BI(1)
    block_flag=BI(1)[0]
    BI(11)
    
    #vert_count
    vert_count=BI(1)[0]

    #last junk
    BI(2)

    if not alt_format:
        # Vertex Block    
        for x in range(0,vert_count):
            tmp=Bf(3)
            vertex.extend([(tmp[0],tmp[1],tmp[2])])

        print("pre UV:"+str(filehandle.tell()))
        # UVs_block    
        for x in range(0,vert_count):
            tmp=BF(4)
            uvs.extend([(tmp[0], (1.0-tmp[1]))]) # v axis was flipped
            UV2.extend([(tmp[2], (1.0-tmp[3]))]) # v axis was flipped
            
        print("post UV:"+str(filehandle.tell()))
        #  normals_block ?  undetermined
        for x in range(0,vert_count):
            tmp=BB(8)
            #normals.extend([tmp[0],tmp[1],tmp[2]])
        print("post normals:"+str(filehandle.tell()))
        # weights block possibly    
        for x in range(0,vert_count):
            if (block_flag == 0x09):
                tmp=BB(8)
            else:
                tmp=BH(8)
    else:
         for x in range(0,vert_count):
            tmp=Bf(3)
            vertex.extend([(tmp[0],tmp[1],tmp[2])])
            tmp=BF(4)
            uvs.extend([(tmp[0], (1.0-tmp[1]))]) # v axis was flipped
            UV2.extend([(tmp[2], (1.0-tmp[3]))]) # v axis was flipped
            #skip junk
            BI(3)

    ####################################################################
        
    print("vertex array length:"+str(len(vertex)))
    print("normal array length:"+str(len(normals)))
    print("weights array length:"+str(len(m_weights)))
    print("index array length:"+str(len(g_indices)))
    print("UV1 array length:"+str(len(uvs)))
    print("UV2 array length:"+str(len(UV2)))
    print("UV3 array length:"+str(len(UV3)))
    print("Colors array length:"+str(len(colors)))

    #########################################
    ## FACES
    #########################################

    print("Reading FaceData:"+str(filehandle.tell()))

    #face_count
    face_count=BI(1)[0]
    face_count = face_count // 3 # 3 points per face
    print("Face Count:"+str(face_count))    
    # contains face block size, stride size (after data) usually 
    for x in range(0,face_count):
        tmp=BH(3)
        faces.extend([(tmp[2],tmp[1],tmp[0])]) # reverse order to flip faces
        face_idx.extend([0]) #initialize for fill-in later

    print("faces array length:"+str(len(faces)))
    print("# of faces found:"+str(face_count))

    try:
        me.from_pydata(vertex,[],faces)
        me.vertices.foreach_set("normal",normals) # add normals
    except:
        pass

    # set to smooth shaded	
    bpy.ops.object.shade_smooth()

    if use_layers:
        # place mesh on incremental layer
        me_obj.layers[msh_count] = True

        #wipe other layers
        for i in range(20):
            # if there's ever more than 20 meshes, we are in trouble. But i doubt that happens.
            me_obj.layers[i] = (i == msh_count)

    # skip some unused data
    BI(6)
    if not alt_format:
        BI(1)    
    
    ###############################################
    ## Material Data
    ###############################################
    material_count = BI(1)[0]
    if alt_format:
        footer_sig=file_str(4)
        print("Footer signature:"+footer_sig)

    for x in range(0,material_count):
        mat_num = BI(1)[0] # length of string
        matName = model_name2+'_mat_'+str(mat_num)

        mat_range_data=BI(2) # start and range data for material

        mat = bpy.data.materials.new(matName)
        bpy.ops.object.material_slot_add()
        me_obj.material_slots[x].material = mat
        print("setting materials slot ",x," to ",mat)

        end_offset=int(mat_range_data[0]//3 + mat_range_data[1] //3) # add start + offset
        print("START:"+str(mat_range_data[0]//3)+" END:"+str(end_offset))

        for j in range(mat_range_data[0]//3,end_offset): # Start number, count
            #print("assigning material ",x," to index ",j)
            face_idx[j]=x

        if randomize_colors:
            mat.diffuse_color = randomColor()
        #mat.specular_color = material.specular()
        #mat.mirror_color = material.emissive()
        #mat.alpha = material.transparency_factor()
        #mat.specular_intensity = material.shininess()
    
        # texture
        #for k, texture in enumerate(material.texture_list()):    
        #    try:
        #        tex = mat.texture_slots.create(k)
        #        tex.texture = bpy.data.textures.new(texture.name(), type='IMAGE')
        #        tex.texture_coords = 'UV'
        #        tex.use = True
        #        tex.use_map_color_diffuse = True
        #        fbx_base_path, fbx_file_name = os.path.split(file)
        #        fbx_texture_file_path = texture.file_name()
        #        fbx_garbage_path, fbx_texture_name = os.path.split(fbx_texture_file_path)
        #        base_norm = os.path.normpath(fbx_base_path)
        #        garbage_norm = os.path.normpath(fbx_garbage_path)
        #        if base_norm in garbage_norm and os.path.exists(fbx_texture_file_path):
        #            texture_file_path = fbx_texture_file_path
        #        else:
        #            texture_file_path = bpy.path.abspath(os.path.join(fbx_base_path, fbx_texture_name))
        #        texture_file_path = os.path.normpath(texture_file_path)
        #        if os.path.exists(texture_file_path):
        #            tex.texture.image = bpy.data.images.load(texture_file_path)
        #    except:
        #        pass

    # material index
    #print("Face_IDX:"+str(face_idx))
    me.polygons.foreach_set("material_index",face_idx) # should set multiple mat indexes.
    
    # post material data 
    bone_list_len = 0 #BI(1)[0]

    # may have bone list
    if bone_list_len != 0:
        for x in range(0,bone_list_len):
            bone_header=BI(7)
            name = file_str(bone_header[6]-1)
            #print("bone Name:",name," index:",x)
            bone_list.extend([name]) # bone_header contains name len + ending null
            BB(1) # read off the null terminator
            BI(25) # read off other data for now (bone location and rotation data)

    # end garbage
    if not alt_format:
        BI(12)
    # and done with this model...
    

    ###############################################
    if face_count > 0: # skip all this if no mesh

    ###############################################
    # Do UVs
    ###############################################
        if len(uvs) != 0:
            me.uv_textures.new(name='UV_0')
            uv_data = me.uv_layers[0].data
            for i in range(len(uv_data)):
                uv_data[i].uv = uvs[me.loops[i].vertex_index]
        if len(UV2) != 0:
            me.uv_textures.new(name='UV_1')
            uv_data = me.uv_layers[1].data
            for i in range(len(uv_data)):
                uv_data[i].uv = UV2[me.loops[i].vertex_index]
        if len(UV3) != 0:
            me.uv_textures.new(name='UV_2')
            uv_data = me.uv_layers[2].data
            for i in range(len(uv_data)):
                uv_data[i].uv = UV3[me.loops[i].vertex_index]

    ###############################################
    # Do Vertex Color
    ###############################################

        if len(colors) != 0 and import_vertcolors:
            me.vertex_colors.new(name='Color_Data')
            color_data = me.vertex_colors[0].data
            for i in range(len(color_data)):
                color_data[i].color = colors[me.loops[i].vertex_index]
        if len(colors2) != 0 and import_vertcolors:
            me.vertex_colors.new(name='Color_Data2')
            color_data = me.vertex_colors2[0].data
            for i in range(len(color_data)):
                color_data[i].color = colors2[me.loops[i].vertex_index]


    ###############################################
    # Finalize
    ###############################################

        # finalize mesh
        me.update(calc_edges=True)

        #scale
        scale_matrix = mathutils.Matrix.Scale(1.0*mesh_scale, 4)

        #global_trans = to_blender_matrix(mesh.global_transform())
        if not alt_format:
            me_obj.matrix_basis = ROT_Z90_MATRIX * scale_matrix#* global_trans
        else:
            me_obj.matrix_basis = ROT_Z180_MATRIX * scale_matrix#* global_trans
            
        # apply transforms (rotation)
        bpy.ops.object.transform_apply(location=False,rotation=True,scale=True)

    ##############################################
    # create bone group
    ##############################################
        if m_weights:
            for n, indices in enumerate(g_indices):
                for p,index in enumerate(indices):
                    
                    # name is index
                    bone_name = bone_list[index]
                    #print("p is:",p," index is:",index," Name is:",bone_name)
                    # use existing group or new
                    group = None
                    if bone_name in me_obj.vertex_groups.keys():
                        group = me_obj.vertex_groups[bone_name]
                    if group == None:
                        group = me_obj.vertex_groups.new(bone_name)
                    
                    # do weight                    
                    weight = m_weights[n][p]
                    if weight == 0: # no weight = no influence, so not acutally used
                        continue;
                    
                    group.add([n], weight, 'ADD')

    print("Finished Model")

    return 0 # all fine

##################################################################

def createRig(name, origin, boneTable):

    # Create armature and object
    bpy.ops.object.add(
        type='ARMATURE', 
        enter_editmode=True,
        location=origin)
    ob = bpy.context.object
    ob.show_x_ray = True
    ob.data.draw_type = 'STICK'
    ob.name = name
    amt = ob.data
    amt.name = name+'Amt'
    amt.show_axes = False
 
    # Create bones
    bpy.ops.object.mode_set(mode='EDIT')
    for (bname, pname, vector) in boneTable:    
        bone = amt.edit_bones.new(bname)
        if pname:
            parent = amt.edit_bones[pname]
            bone.parent = parent
            bone.head = parent.tail
            bone.use_connect = False
            if vector[0]+vector[1]+vector[2] < 0.0001:
                vector = (0,0.0001,0) # try to prevent zero length bones
            (trans, rot, scale) = parent.matrix.decompose()
        else:
            bone.head = (0,0,0)
            rot = Matrix.Translation((0,0,0))	# identity matrix
        bone.tail = rot * Vector(vector) + bone.head
    bpy.ops.object.mode_set(mode='OBJECT')
    return ob

def poseRig(rig, poseTable,use_layers,mesh_scale):

    SWAP_YZ_MATRIX = mathutils.Matrix.Rotation(math.radians(90.0), 4, 'X')
    bpy.context.scene.objects.active = rig
    bpy.ops.object.mode_set(mode='POSE')
 
    for (bname, loc,angle) in poseTable:
        
        pbone = rig.pose.bones[bname]

        pbone.matrix_basis.identity()
        # Set rotation mode to Euler XYZ, easier to understand
        # than default quaternions
        pbone.rotation_mode = 'XYZ'
        # Documentation bug: Euler.rotate(angle,axis):
        # axis in ['x','y','z'] and not ['X','Y','Z']
        print("quat:",angle)
        quat = Quaternion((angle[3]*-1.0,angle[0]*-1.0,angle[1],angle[2])) # flip on axis, Negate axis, negate 'w'
        euler=quat.to_euler('XYZ')
        #pbone.rotation_euler.rotate_axis('X', euler[0])
        #pbone.rotation_euler.rotate_axis('Y', euler[2])
        #pbone.rotation_euler.rotate_axis('Z', euler[1])

        #########################
        pos = Vector([float(loc[0]), float(loc[1]), float(loc[2])])
        rot = Euler([float(euler[0]), float(euler[1]), float(euler[2])])
        
        kf = Matrix.Identity(4)
        kf = Matrix.Translation(pos) * rot.to_matrix().to_4x4()

        if pbone.parent:
            pbone.matrix = pbone.parent.matrix * kf
        else:
            pbone.matrix = kf
        
    bpy.ops.pose.armature_apply()

    bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=3,size=2)
    bone_vis = bpy.context.active_object
    bone_vis.data.name = bone_vis.name = "HitmanDat_bone_vis"
    bone_vis.use_fake_user = True
    bpy.context.scene.objects.unlink(bone_vis) # don't want the user deleting this
    bpy.context.scene.objects.active = rig
    ###########################

    # Calculate armature dimensions...Blender should be doing this!
    maxs = [0,0,0]
    mins = [0,0,0]
    for bone in rig.data.bones:
        for i in range(3):
            maxs[i] = max(maxs[i],bone.head_local[i])
            mins[i] = min(mins[i],bone.head_local[i])

    dimensions = []

    for i in range(3):
        dimensions.append(maxs[i] - mins[i])
        
    length = max(0.001, (dimensions[0] + dimensions[1] + dimensions[2]) / 600) # very small indeed, but a custom bone is used for display

    # Apply spheres
    bpy.ops.object.mode_set(mode='EDIT')
    for (bname, loc,angle) in poseTable:
        bone=rig.data.edit_bones[bname]
        bone.tail = bone.head + (bone.tail - bone.head).normalized() * length # Resize loose bone tails based on armature size
        rig.pose.bones[bone.name].custom_shape = bone_vis # apply bone shape

    #pbone.rotation_quaternion = quat
    bpy.ops.object.mode_set(mode='OBJECT')

    #scale
    scale_matrix = mathutils.Matrix.Scale(1.0*mesh_scale, 4)

    global_trans = mathutils.Matrix.Translation((poseTable[0][1][0]*100.0,poseTable[0][1][1]*100.0,poseTable[0][1][2]*100.0))
    matrix_basis = SWAP_YZ_MATRIX * scale_matrix * global_trans
    rig.data.transform(matrix_basis)
    
    # apply transforms (rotation)
    bpy.ops.object.transform_apply(location=True,rotation=True,scale=True)

    
    #add armature modifier
    for cnt,ob_ptr in enumerate(objects_ptr):
        mod = ob_ptr.modifiers.new('RigModifier', 'ARMATURE')
        mod.object = rig
        mod.use_bone_envelopes = False
        mod.use_vertex_groups = True

        # place armature on each layer as well
        if use_layers:
            rig.layers[cnt] = True

 
##################################################################

def alignPosition(alignment):
	alignment = alignment - 1
	filehandle.seek(((filehandle.tell() + alignment) & ~alignment), 0) # SEEK_SET

def randomColor():
    randomR = random.random()
    randomG = random.random()
    randomB = random.random()
    return (randomR, randomG, randomB)

def HalfToFloat(h):
    s = int((h >> 15) & 0x00000001)    # sign
    e = int((h >> 10) & 0x0000001f)    # exponent
    f = int(h & 0x000003ff)            # fraction

    if e == 0:
       if f == 0:
          return int(s << 31)
       else:
          while not (f & 0x00000400):
             f <<= 1
             e -= 1
          e += 1
          f &= ~0x00000400
          #print (s,e,f)
    elif e == 31:
       if f == 0:
          return int((s << 31) | 0x7f800000)
       else:
          return int((s << 31) | 0x7f800000 | (f << 13))

    e = e + (127 -15)
    f = f << 13

    return int((s << 31) | (e << 23) | f)


def file_str(long): 
   s=''
   for j in range(0,long): 
       lit =  unpack('c',filehandle.read(1))[0]
       #print("ord of "+str(lit)+" is "+str(ord(lit)))
       if ord(lit)!= 0:
           s+=lit.decode("utf-8")
       else:
           break;
   return s

def readcstr():
    buf = ''
    while True:
        b = unpack('c',filehandle.read(1))[0]
        #print("ord of "+str(b)+" is "+str(ord(b)))
        if b is None or ord(b) == 0:
            return buf
        else:
            buf+=b.decode("utf-8")

def BB(n): # Unsigned Char Default is < (little Endian)  > = Big-Endian
    array = [] 
    for id in range(n): 
        array.append(unpack('B', filehandle.read(1))[0])
    return array
def Bb(n): # Signed Char
    array = [] 
    for id in range(n): 
        array.append(unpack('b', filehandle.read(1))[0])
    return array
def BH(n): # Unsigned Short
    array = [] 
    for id in range(n): 
        array.append(unpack('H', filehandle.read(2))[0])
    return array
def Bh(n): # Signed Short
    array = [] 
    for id in range(n): 
        array.append(unpack('h', filehandle.read(2))[0])
    return array
def Bf(n): # Float
	array = [] 
	for id in range(n):
		nz=filehandle.read(4)
		#print("NZ:"+str(nz))
		array.append(unpack('f',nz )[0])
	return array
def BF(n): # HALF FLoat
    array = [] 
    for id in range(n):
        nz=filehandle.read(2)
        #print("NZ:"+str(nz))
        v = struct.unpack('H', nz)
        x = HalfToFloat(v[0])
        # hack to coerce int to float
        str = struct.pack('I',x)
        f=struct.unpack('f', str)
        array.append(f[0])
    return array
def Bi(n): # Signed Long Int
    array = [] 
    for id in range(n): 
        array.append(unpack('i', filehandle.read(4))[0])
    return array
def BI(n): # Unsigned Long Int
    array = [] 
    for id in range(n): 
        array.append(unpack('I', filehandle.read(4))[0])
    return array
def Bd(n): # Double
    array = [] 
    for id in range(n): 
        array.append(unpack('d', filehandle.read(8))[0])
    return array

def views():
    """ Returns the set of 3D views.
    """
    rtn = []
    for a in bpy.data.screens["Default"].areas:
        if a.type == 'VIEW_3D':
            rtn.append(a)
    return rtn

def import_Dishonored2Bmd6model(file, context, randomize_colors,skip_blank,use_layers,mesh_scale):

    global filehandle,fmt_table,model_name
    report = None
    alt_format = False

    time1 = time.time()
    print("start")

    workingpath=os.path.dirname(os.path.realpath(__file__))

     #adjust clipping mode
    view=views()
    print(view[0].spaces[0].type)  # should be VIEW_3D
    view[0].spaces[0].clip_end=10000

    # split off model name
    root, ext = os.path.splitext(file)    
    model_name=root.split("\\")[-1]
    print(model_name)

    ##################################
    try:
        filehandle = open(file, "rb")
    except:
        report="Error loading '"+model_name+".Bmd6model'\n"
        return report

    #get key data about the mesh
    header_sig=file_str(4)
    print("Header signature:"+header_sig)
    if header_sig == '1LMB':
        alt_format = True
    if header_sig != 'MM6@' and header_sig !='1LMB' and header_sig !='MM6B':
        report=model_name+" is not a supported model file.\n"
        return report
    
    if alt_format:
        BI(1)
        
    skeleton_pathlen = BI(1)[0]
    print("skeleton path: "+file_str(skeleton_pathlen))

    if not alt_format:
        if skeleton_pathlen != 0:
            BI(1) # 4 bytes after
        else:
            BH(1) # 2 bytes after

        #skip junk
        BI(5)
        BH(1)

    # model count
    model_count = BI(1)[0]    
    print("model count:"+str(model_count))

    # unselect all   
    for item in bpy.context.selectable_objects:   
        item.select = False   

    
    # at model start
    ####################################
    for i in range(0,model_count): 
        # do mesh and materials
        result=import_mesh(context,randomize_colors,use_layers,mesh_scale,i,alt_format) 

        if result is None:
            report = "Mesh Output Failed."
        elif result == 1:
            report = "Vertice counts didn't match, aborting!"


    # should be at end of models, process last
    filehandle.close()
    
    #############################################
    ## Skeleton
    #############################################

    has_skeleton = True
    
    # take root filename and add .skel extension
    root = root + ".skel"
    try:
        filehandle = open(root, "rb")
    except:
        has_skeleton = False  

    if has_skeleton:
        print("HAS SKEL")
        #get key data about the mesh
        signature = BI(1)[0]
        if signature != MAGIC_SIG:
            report=model_name+".skel signature is invalid:"+str(signature)+"\n"
            return report
        
        filehandle.seek(0x18)
        bone_block_len = BI(1)[0]
        print("Bone block length:"+str(bone_block_len))

        name_start=filehandle.tell()
        filehandle.seek(bone_block_len,1) #SEEK_CUR
        
        print("ended at:"+str(filehandle.tell()))

        names_offset_len = BI(1)[0]
        
        bone_names=[] # names array

        for y in range(0,names_offset_len):
            tmp=BI(1)[0] # name offset
            offsets_start=filehandle.tell()
            filehandle.seek(name_start+tmp,0) # SEEK_SET
            bone_names.append(readcstr())
            print("name:",bone_names[y])
            filehandle.seek(offsets_start)

        
        # skip past hash list
        hashes_len = BI(1)[0]
        filehandle.seek(hashes_len*4,1) # 4 bytes per hash #SEEK_CUR

        # Now get bone parent index list
        parent_index_len = BI(1)[0]
        Bone_parents = []
        
        for y in range(0,parent_index_len):
            Bone_parents.append(Bi(1)[0])  # signed so root = -1

        #Now get location/rotation data and build skeleton table as we go
        bone_count = BI(1)[0]
        Bone_Table=[]
        Pose_Table=[]

        for y in range(0,bone_count):
            loc_n_rot = Bf(8)

            parent_name = None
            parent_id=Bone_parents[y]
            if parent_id != -1:
                parent_name = bone_names[parent_id]                

            Bone_Table.extend([(bone_names[y],parent_name,(loc_n_rot[0]*-1,loc_n_rot[1],loc_n_rot[2]))]) # Flip on X Axis
            Pose_Table.extend([(bone_names[y],(loc_n_rot[0]*-1,loc_n_rot[1],loc_n_rot[2]),(loc_n_rot[4],loc_n_rot[5],loc_n_rot[6],loc_n_rot[7]))])

        # build the skeleton
        rig = createRig('Skeleton', Vector((0,0,0)), Bone_Table)
        poseRig(rig, Pose_Table,use_layers,mesh_scale)            

        filehandle.close()

    print("time is ", time.time() - time1)
    return report
