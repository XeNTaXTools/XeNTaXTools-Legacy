# author: Volfin
# 1.00 - Initial Release
# 1.01 - validated to Blender version 2.70; added check for Object mode
# 1.02 - added support for Death of the Outsider.

bl_info = {
    "name": "Dishonored 2 Bmd6model Importer",
    "author": "Volfin",
    "version": (1, 0, 2),
    "blender": (2, 7, 0),
    "location": "File > Import > Dat (Dishonored 2 Model)",
    "description": "Import Dishonored2Bmd6model, io: mesh",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
    "category": "Import-Export"}
    
if "bpy" in locals():
    import imp
    if "import_Dishonored2Bmd6model" in locals():
        imp.reload(import_Dishonored2B6model)
    if "export_Dishonored2Bmd6model" in locals():
        imp.reload(export_Dishonored2B6model)

import bpy

from bpy.props import (StringProperty,
                       BoolProperty,
                       FloatProperty,
                       EnumProperty,
                       )

from bpy_extras.io_utils import (ImportHelper,path_reference_mode)

  
class Dishonored2Bmd6modelImportOperator(bpy.types.Operator, ImportHelper):
    bl_idname = "import_scene.dishonored2bmd6model"
    bl_label = "Dishonored 2 Importer(.bmd6model/.bmodel)"
    
    #filename_ext = ".bmd6model"
    skip_blank=False;

    randomize_colors = BoolProperty(\
        name="Random Material Colors",\
        description="Assigns a random color to each material",\
        default=True,\
        )

    use_layers = BoolProperty(\
        name="Seperate Mesh Layers",\
        description="Place Meshes on seperate layers",\
        default=False,\
        )
    mesh_scale = bpy.props.FloatProperty(
        name="Scale Factor",
        description="Mesh Import Scale Factor",
        default=1.0,
    )

    filter_glob = StringProperty(default="*.bmd6model;*.bmodel") # , options={'HIDDEN'}
    filepath = bpy.props.StringProperty(subtype="FILE_PATH")        
    path_mode = path_reference_mode

    def execute(self, context):
        import os, sys
        print("Import Execute called")
        cmd_folder = os.path.dirname(os.path.abspath(__file__))
        if cmd_folder not in sys.path:
            sys.path.insert(0, cmd_folder)

        import import_Dishonored2Bmd6model
        result=import_Dishonored2Bmd6model.import_Dishonored2Bmd6model(self.filepath, bpy.context,self.randomize_colors,self.skip_blank,self.use_layers,self.mesh_scale)

        # force back off
        #self.skip_blank=False
        #self.use_layers=False
        
        if result is not None:
            self.report({'ERROR'},result)

        return {'FINISHED'}

    def invoke(self, context, event):

        print("Import Invoke called")
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        col.label('Mesh Scale Factor')
        col.prop(self, "mesh_scale")
        row = layout.row(align=True)
        row.prop(self, "randomize_colors")
        row = layout.row(align=True)
        row.prop(self, "use_layers")

#
# Registration
#
def menu_func_import(self, context):
    self.layout.operator(Dishonored2Bmd6modelImportOperator.bl_idname, text="bmd6model(Dishonored 2 Model)(.bmd6model/.bmodel)",icon='PLUGIN')
   
def register():
    bpy.utils.register_module(__name__)
    bpy.types.INFO_MT_file_import.append(menu_func_import)
    
def unregister():
    bpy.utils.unregister_module(__name__)
    bpy.types.INFO_MT_file_import.remove(menu_func_import)
    
if __name__ == "__main__":
    register()