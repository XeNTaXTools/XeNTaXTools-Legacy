bl_info = {
    "name": "Guardians of the Galaxy PC (*.pc_prim)",
    "description": "Import Guardians of the Galaxy Models",
    "author": "kboykboy, Irastris",
    "category": "Import",
    "version": (1, 0),
    "blender": (2, 90, 0),
}

from math import log2
from struct import unpack

import bpy
from bpy.props import BoolProperty
from bpy.types import Operator, Panel
from bpy_extras.io_utils import ImportHelper

def unpackShort(prim):
    return unpack("<H", prim.read(2))[0]

def unpackLong(prim):
    return unpack("<I", prim.read(4))[0]

def unpackLongLong(prim):
    return unpack("<Q", prim.read(8))[0]

def unpackFloat(prim):
    return unpack("<f", prim.read(4))[0]

class GOTG_OT_ImportModel(Operator, ImportHelper):
    bl_label = "Import PRIM"
    bl_idname = "gotg.import_model"
    
    import_lods: BoolProperty(name="Import LODs", description="Whether or not to import all LODs or only LOD 0.", default=False)
    
    def execute(self, context):
        with open(self.filepath, "rb") as prim:
            headerLength = 12
            prim.seek(92)
            meshCount = unpackLong(prim)
            
            for n in range(meshCount):
                loc = prim.tell()
                meshLOD = int(log2(unpackLong(prim)))
                meshNum = unpackLong(prim)
                
                if meshLOD > 0:
                    if not self.import_lods:
                        prim.seek(loc+296)
                        continue
                
                prim.seek(64, 1)
                uScale, vScale, uOffset, vOffset = [unpackFloat(prim) for _ in range(4)]
                vertnum = unpackShort(prim)
                prim.seek(6, 1)
                vertloc = unpackLongLong(prim) + headerLength + 4
                prim.seek(8, 1)
                faceloc = unpackLongLong(prim) + headerLength + 4
                facenum = int(unpackLong(prim) / 3)
                prim.seek(vertloc + 6)
                if unpackShort(prim) == 15360:
                    vformat = "half"
                    FVF = 8
                else:
                    vformat = "float"
                    FVF = 12
                prim.seek(faceloc)
                faces = []
                for n in range(facenum):
                    index1, index2, index3 = [unpackShort(prim) for _ in range(3)]
                    faces.append([index1, index2, index3])
                prim.seek(vertloc)
                verts = []
                if vformat == "float":
                    for n in range(vertnum):
                        x, y, z = [unpack("<f", prim.read(4))[0] for _ in range(3)]
                        prim.seek(FVF - 12, 1)
                        verts.append([x, y, z])
                if vformat == "half":
                    for n in range(vertnum):
                        x, y, z = [unpack("<e", prim.read(2))[0] for _ in range(3)]
                        prim.seek(FVF - 6, 1)
                        verts.append([x, y, z])
                prim.seek(vertnum * 24, 1)
                uvloc = prim.tell()
                uvs = []
                for n in range(len(verts)):
                    x, y = [unpack("<h", prim.read(2))[0] for _ in range(2)]
                    x = ((x / 32768.0) * uScale) + uOffset
                    y = ((y / 32768.0) * vScale) + vOffset
                    uvs.append([x, y])
                
                mesh = bpy.data.meshes.new(f"Mesh{meshNum}-LOD{meshLOD}")
                obj = bpy.data.objects.new(mesh.name, mesh)
                bpy.context.collection.objects.link(obj)
                mesh.from_pydata(verts, [], faces)
                me = obj.data
                if uvs != 0:
                    uvlayer = me.uv_layers.new()
                    me.uv_layers.active = uvlayer
                    num = 0
                    for face in me.polygons:
                        for vert_idx, loop_idx in zip(face.vertices, face.loop_indices):
                            uv = uvs[vert_idx]
                            uvlayer.data[loop_idx].uv = (uv[0], uv[1])
                            num = num + 1
                
                print(f"{obj.name} {uvloc}")
                
                prim.seek(loc+296)
        
        return{'FINISHED'}

classes = (
    GOTG_OT_ImportModel,
)

def menu_import_draw(self, context):
    self.layout.operator(GOTG_OT_ImportModel.bl_idname, text="Guardians of the Galaxy (.prim)")

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.TOPBAR_MT_file_import.append(menu_import_draw)
    
def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
    bpy.types.TOPBAR_MT_file_import.remove(menu_import_draw)

if __name__=="__main__":
    register()