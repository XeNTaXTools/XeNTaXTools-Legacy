import os
from struct import pack, unpack

import click

FORMATS = {
    "BC1_UNORM": (827611204, 0, 71), 
    "BC3_UNORM": (894720068, 8, 77),
    "BC7_UNORM": (808540228, 8, 98)
}

def unpackShort(fh):
    return unpack("<H", fh.read(2))[0]

def unpackString(fh, length):
    string = ""
    for _ in range(length):
        for char in unpack("<c", fh.read(1)):
            if ord(char) == 0: break
            string += char.decode("utf-8")
    return string

def packLong(arg):
    return pack("<L", arg)

def readTEXT(filepath, tex_format):
    with open(filepath, "rb") as fh:
        magic = unpackString(fh, 4)
        if magic != "HXET":
            raise ImportError
        fh.seek(12)
        width = unpackShort(fh)
        height = unpackShort(fh)
        depth = unpackShort(fh)
        length = width * height * FORMATS[tex_format][1] // 8
        fh.seek(6, 1)
        data = fh.read(length)
    return width, height, depth, length, data

@click.group()
def cli():
    pass

@cli.command()
@click.option("-f", "--tex-format", required=True, help="Specify the texture format.")
@click.argument("filepath")
def extract(filepath, tex_format):
    """ Extract texture data from a given TEXT and save it as DDS """
    print(f"Processing {filepath}")
    
    try:
        width, height, depth, length, data = readTEXT(filepath, tex_format)
    except ImportError:
        return print(f"Input does not contain expected magic!")
    except FileNotFoundError:
        return print("Input does not exist!")
    except PermissionError:
        return print("Input can not be accessed!")

    if depth > 1:
        return print("Input not supported, depth is greater than 1.")
    
    with open(f"{os.path.splitext(filepath)[0]}.dds", "wb") as dds:
        dds.write(packLong(542327876))
        dds.write(packLong(124))
        dds.write(packLong(659463))
        dds.write(packLong(height))
        dds.write(packLong(width))
        dds.write(packLong(length))
        dds.write(packLong(depth))
        dds.write(packLong(1))
        dds.seek(44, 1)
        dds.write(packLong(32))
        dds.write(packLong(4))
        dds.write(packLong(FORMATS[tex_format][0]))
        dds.seek(20, 1)
        dds.write(packLong(4198408))
        dds.seek(16, 1)
        if FORMATS[tex_format][0] == 808540228:
            dds.write(packLong(FORMATS[tex_format][2]))
            dds.write(packLong(3))
            dds.write(packLong(0))
            dds.write(packLong(1))
            dds.write(packLong(0))
        dds.write(data)
    
    return

if __name__ == "__main__":
    cli()