
A WINDOWS CONSOLE application, for all those who DON'T know the difference between that and an MS-DOS program, heres the difference. IT WONT RUN UNDER MS-DOS. OK, onto the good stuff, it allows you to extract files from the BF file archive used in UBISoft games such as BGAE and POP.



Syntax for bfextractor.exe
  List Contents of Archive
    bfextractor.exe -l <archive filename>
  Extract Contents of Archive
    bfextractor.exe -x <archive filename> <filename to extract> [-wavpcm]
  Extract All Contents of Archive
    bfextractor.exe -a <archive filename> [-wavpcm]

Created By Rahly