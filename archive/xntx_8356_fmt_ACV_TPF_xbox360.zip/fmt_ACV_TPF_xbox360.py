#Armored Core V .TPF [X360] - ".TPF" Loader
#based on original script by Gh0stblade

from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Armored Core V textures [X360]", ".tpf")
	noesis.setHandlerTypeCheck(handle, tpfCheckType)
	noesis.setHandlerLoadRGBA(handle, tpfLoadDDS)
	noesis.logPopup()
	return 1
		
def tpfCheckType(data):
	bs = NoeBitStream(data, NOE_BIGENDIAN)
	if bs.readUInt() == 0x54504600:
		return 1
	else: 
		print("Fatal Error: Unknown file magic: expected 0x54504600!")
		return 0

def tpfLoadDDS(data, texList):
	bs = NoeBitStream(data, NOE_BIGENDIAN)
	
	fileMagic = bs.readUInt()
	fileUnk00  = bs.readUShort()
	fileUnk01  = bs.readUShort()
	numTextures  = bs.readUInt()
	fileUnk02  = bs.readUByte()
	fileUnk03  = bs.readUByte()
	fileUnk04  = bs.readUByte()
	fileUnk05  = bs.readUByte()
	
	print("Number of Textures: " + str(numTextures))
	
	for i in range (numTextures):
		bs.seek(0x10 + i * 0x1C, NOESEEK_ABS)

		ddsOffset = bs.readUInt()
		ddsSize = bs.readUInt()
		ddsType = bs.readUByte()
		ddsUnk00 = bs.readUByte()
		ddsUnk01 = bs.readUShort()
		ddsWidth = bs.readUShort()
		ddsHeight = bs.readUShort()
		
		ddsUnk01 = bs.readUInt()
		ddsNameOffset = bs.readUInt()
		ddsUnk02 = bs.readUInt()
		
		bs.seek(ddsNameOffset, NOESEEK_ABS)
		ddsName = str(i)
		
		bs.seek(ddsOffset, NOESEEK_ABS)
		ddsData = bs.readBytes(ddsSize)
		
		ddsFmt = None
		
		if ddsType == 0x0:
			ddsData = rapi.imageUntile360DXT(rapi.swapEndianArray(ddsData, 2), ddsWidth, ddsHeight, 8)
			ddsFmt = noesis.NOESISTEX_DXT1
		elif ddsType == 0x1:
			ddsData = rapi.imageUntile360DXT(rapi.swapEndianArray(ddsData, 2), ddsWidth, ddsHeight, 8)
			ddsFmt = noesis.NOESISTEX_DXT1
		elif ddsType == 0x5:
			ddsData = rapi.imageUntile360DXT(rapi.swapEndianArray(ddsData, 2), ddsWidth, ddsHeight, 16)
			ddsFmt = noesis.NOESISTEX_DXT5
		else:
			print("Fatal Error: Unknown DDS type: " + str(ddsType) + " texture idx: " + str(i))
		if ddsFmt != None:
			texList.append(NoeTexture(ddsName, ddsWidth, ddsHeight, ddsData, ddsFmt))
	return 1
	