import bpy
import os
hasDeleted = False

for root, dirs, files in os.walk('C:\\Users\\brand\\Desktop\\New folder\\PC_PRIM'):
	for name in files:
		if name.endswith('prim'):
			if not os.path.exists(os.path.join(root, name+'.fbx')):
				if not hasDeleted:
					os.remove(os.path.join(root, name))
					hasDeleted = True
					continue
				# delete everything
				for obj in bpy.data.objects:
					bpy.data.objects.remove(obj, do_unlink=True)
				# adjust this to match the import operator
				try:
					bpy.ops.gotg.import_model(filepath=os.path.join(root, name))
				except:
					pass
				# export as fbx
				bpy.ops.export_scene.fbx(filepath=os.path.join(root, name+'.fbx'))