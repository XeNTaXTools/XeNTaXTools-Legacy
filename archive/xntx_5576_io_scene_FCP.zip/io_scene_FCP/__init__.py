# author: Volfin
# 1.00 - Initial Release
# 1.01 - fixed Flipped faces
# 1.02 - Completely redid Skeleton creation and weight group assginment.
# 1.03 - Added in custom split normal import, and Auto-material assignment.
# 1.04 - Fixed context switching. Fixed non-zero skeleton rotation. Fixed Alpha material setting when no textures.
# 1.05 - Fixed material.bin reading, improved texture type detection logic.
# 1.06 - Fixed another material.bin bug; fixed mesh validation bug; added use_Skeleton option.
# 1.07 - validated minimum blender version 2.70

bl_info = {
    "name": "Far Cry Primal XBG Importer",
    "author": "Volfin",
    "version": (1, 0, 7),
    "blender": (2, 7, 0),
    "location": "File > Import > xbg (Far Cry Primal Model)",
    "description": "Import FCP, io: mesh",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
    "category": "Import-Export"}
    
if "bpy" in locals():
    import imp
    if "import_FCP" in locals():
        imp.reload(import_FCP)
    if "export_FCP" in locals():
        imp.reload(export_FCP)

import bpy

from bpy.props import (StringProperty,
                       BoolProperty,
                       FloatProperty,
                       EnumProperty,
                       )

from bpy_extras.io_utils import (ImportHelper,path_reference_mode)

  
class FCPImportOperator(bpy.types.Operator, ImportHelper):
    bl_idname = "import_scene.watchdogs2"
    bl_label = "Far Cry Primal Importer(.xbg)"
    
    filename_ext = ".xbg"
    skip_blank=False;

    randomize_colors = BoolProperty(\
        name="Random Material Colors",\
        description="Assigns a random color to each material",\
        default=False,\
        )

    import_vertcolors = BoolProperty(\
        name="Import Vertex Colors",\
        description="Import Vertex Colors",\
        default=False,\
        )
    
    use_Skeleton = BoolProperty(\
        name="Use Existing Skeleton",\
        description="Check to attach mesh to existing skeleton, otherwise builds new skeleton.",\
        default=False,\
        )
    mesh_scale = bpy.props.FloatProperty(
        name="Scale Factor",
        description="Mesh Import Scale Factor",
        default=1.0,
    )

    filter_glob = StringProperty(default="*.xbg") # , options={'HIDDEN'}
    filepath = bpy.props.StringProperty(subtype="FILE_PATH")        
    path_mode = path_reference_mode

    def execute(self, context):
        import os, sys
        print("Import Execute called")
        cmd_folder = os.path.dirname(os.path.abspath(__file__))
        if cmd_folder not in sys.path:
            sys.path.insert(0, cmd_folder)

        import import_FCP
        result=import_FCP.import_FCP(self.filepath, bpy.context,self.randomize_colors,self.import_vertcolors,self.skip_blank,self.use_Skeleton,self.mesh_scale)

        # force back off
        #self.skip_blank=False
        #self.use_Skeleton=False
        
        if result is not None:
            self.report({'ERROR'},result)

        return {'FINISHED'}

    def invoke(self, context, event):

        print("Import Invoke called")
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        col.label('Mesh Scale Factor')
        col.prop(self, "mesh_scale")
        row = layout.row(align=True)
        row.prop(self, "randomize_colors")
        row = layout.row(align=False)
        row.prop(self, "import_vertcolors")
        row = layout.row(align=True)
        row.prop(self, "use_Skeleton")

#
# Registration
#
def menu_func_import(self, context):
    self.layout.operator(FCPImportOperator.bl_idname, text="xbg(Far Cry Primal Model)(.xbg)",icon='PLUGIN')
   
def register():
    bpy.utils.register_module(__name__)
    bpy.types.INFO_MT_file_import.append(menu_func_import)
    
def unregister():
    bpy.utils.unregister_module(__name__)
    bpy.types.INFO_MT_file_import.remove(menu_func_import)
    
if __name__ == "__main__":
    register()