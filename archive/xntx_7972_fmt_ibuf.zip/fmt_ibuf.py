import os
from os.path import *
from inc_noesis import *
import noesis

def registerNoesisTypes():
   handle = noesis.register("Port Royale 3", ".ibuf")
   noesis.setHandlerTypeCheck(handle, noepyCheckType)
   noesis.setHandlerLoadModel(handle, noepyLoadModel)
   return 1

def noepyCheckType(data):
    if len(data) < 0x80:
        return 0
    return 1       

def HalfFloat(val):
    return noesis.getFloat16(val)

def OpenFile(texName, path): 
    try:
        fn = open(path+"\\"+texName, 'rb')
        return fn
    except:
        print("failed to open texture: %s" %texName)

def GetTextures(path):
    texList = []
    matList = []
    
    texName = ""
    texSubs = os.path.basename(path).split("_")
    for i in range(len(texSubs)):
        texName = texName+texSubs[i]+"_"
    
    texName = texName[0:-1]
    texNameOri = "0_"+texName+".dds"
    texNameNew = "0_"+texName+".png"
    
    Tfile = OpenFile(texNameOri, path)
    if Tfile != None:
        data = Tfile.read()
        tex = rapi.loadTexByHandler(data, ".dds")
        texList.append(tex)
        texList[0].name = texNameNew
        material = NoeMaterial("m_"+texName, texNameNew)
        material.setTexture(texNameNew)
        matList.append(material)
    else:
        material = NoeMaterial("m_"+texName, texNameNew)
        matList.append(material)
        
    return texList, matList

def noepyLoadModel(data, mdlList):
    bs = NoeBitStream(data)
    fileVbuf = rapi.getExtensionlessName(rapi.getInputName())+".vbuf"
    bs.seek(0xA, NOESEEK_REL)
    Icount = bs.readInt()
    bs.seek(0x16, NOESEEK_ABS)
    Itype = bs.readInt()
    bs.seek(0x20, NOESEEK_ABS)
    
    if Itype == 2:
        indices = [bs.readShort() for x in range(Icount)]
    elif Itype == 4:
        indices = [bs.readInt() for x in range(Icount)]

    if rapi.checkFileExists(fileVbuf):
        f =  open(fileVbuf,"rb")
    else:
        return 0
        
    vbuf = NoeFileStream(f)
    vbuf.seek(0x16, NOESEEK_ABS)
    sizeBlock = vbuf.readInt()
    vbuf.seek(0xA, NOESEEK_ABS)
    Vsize = vbuf.readInt()
    Vcount = int(Vsize/sizeBlock)
    
    offsetData = vbuf.fileSize - Vsize
    
    vbuf.seek(offsetData, NOESEEK_ABS)
    Positions = []
    Normals = []
    TexCoords = []
    for x in range(Vcount):
        if sizeBlock == 80:
            Positions.append(NoeVec3.fromBytes(vbuf.readBytes(12)))
            vbuf.seek(0x10, NOESEEK_REL)
            Normals.append(NoeVec3.fromBytes(vbuf.readBytes(12)))
            vbuf.seek(0x18, NOESEEK_REL)
            TexCoords.append(NoeVec3([vbuf.readFloat(), vbuf.readFloat(), 0.0]))
            vbuf.seek(0x8, NOESEEK_REL)
        elif sizeBlock == 16:
            Positions.append(NoeVec3([HalfFloat(vbuf.readUShort()),HalfFloat(vbuf.readUShort()),HalfFloat(vbuf.readUShort())]))
            #Normals.append(NoeVec3([HalfFloat(vbuf.readUShort()),HalfFloat(vbuf.readUShort()),HalfFloat(vbuf.readUShort())]))
            vbuf.seek(0x6, NOESEEK_REL)
            TexCoords.append(NoeVec3([HalfFloat(vbuf.readUShort()),HalfFloat(vbuf.readUShort()), 0.0]))
    
    basePath = noesis.getSelectedFile()
    basePathTex = os.path.dirname(basePath)
    texList, matList = GetTextures(basePathTex)
    
    mesh = NoeMesh(indices, Positions, "mesh_0", matList[0].name)
    if Normals: mesh.setNormals(Normals)
    if TexCoords: mesh.setUVs(TexCoords)
    mdl = NoeModel([mesh])
    
    mdl.setModelMaterials(NoeModelMaterials(texList, matList))
    mdlList.append(mdl)
    return 1
