from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Kaizoku Musou 3", ".g1tg")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    Magic = bs.readBytes(4).decode("ASCII")
    if Magic != 'GT1G':
        return 0
    return 1
	
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.seek(0x8, NOESEEK_ABS)
    filesize = bs.readInt()
    dataOffset = bs.readInt()
    numTexs = bs.readInt() #0x10
    print(numTexs, "numTexs")
    bs.seek(dataOffset, NOESEEK_ABS)
    for i in range(numTexs):
        texOffsets = bs.read("i" * numTexs)
        print(texOffsets, "texOffsets")
        print(hex(bs.tell()), "start1")
        for j in range(numTexs):
            texName = rapi.getExtensionlessName(rapi.getInputName()) + "_" + str(i)
            bs.seek(texOffsets[j] + dataOffset, NOESEEK_ABS)
            print(hex(bs.tell()), "we're here")
            unk = bs.readByte()
            imgFmt = bs.readUByte()             
            print(imgFmt, "imgFmt")
            texSize = bs.readByte()
            print(texSize, "texSize")
            width = texSize & 0x0F
            height = (texSize & 0xF0) // 16
            print(width, "width")
            print(height, "height")
            imgWidth = 2 ** width
            imgHeight = 2 ** height
            print(imgWidth, "imgWidth")
            print(imgHeight, "imgHeight")
            bs.seek(0x11, NOESEEK_REL)        
            print(hex(bs.tell()), "start2")
            #DXT1
            if imgFmt == 6:
                datasize = ((imgWidth * imgHeight) * 4) // 8
            #DXT5
            elif imgFmt == 8:
                datasize = ((imgWidth * imgHeight) * 8) // 8
            #ARGBA32
            elif imgFmt == 1:
                datasize = ((imgWidth * imgHeight) * 32) // 8
            print(datasize, "datasize")
            data = bs.readBytes(datasize)      
            print(hex(bs.tell()), "at end")
            #DXT1
            if imgFmt == 6:
                texFmt = noesis.NOESISTEX_DXT1
            #DXT5
            elif imgFmt == 8:
                texFmt = noesis.NOESISTEX_DXT5
            #ARGB32
            elif imgFmt == 1:
                data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "a8 r8 g8 b8")
                texFmt = noesis.NOESISTEX_RGBA32
            #unknown, not handled
            else:
                print("WARNING: Unhandled image format")
                return None
            texList.append(NoeTexture(texName, imgWidth, imgHeight, data, texFmt))
        return 1