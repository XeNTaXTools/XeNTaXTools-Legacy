from inc_noesis import *
import noesis
import rapi

def registerNoesisTypes():
	handle = noesis.register("Naughty Dog", ".pak")
	noesis.setHandlerTypeCheck(handle, upakCheckType)
	noesis.setHandlerLoadModel(handle, upakLoadModel) #see also noepyLoadModelRPG
	return 1

def upakCheckType(data):
	bs = NoeBitStream(data)
	magic = bs.readUInt()
	if magic != 0x790a0000:
		return 0
	return 1    

def readString(fstream):
	tmp = fstream.tell()
	while True:
		byte = fstream.readUByte()
		if byte == 0:
			break
	tmp2 = fstream.tell()
	fstream.seek(tmp, NOESEEK_ABS)
	string = fstream.readBytes(tmp2 - tmp).decode("ASCII").rstrip("\0")
	return(string)   

def upakLoadModel(data, mdlList):
	ctx = rapi.rpgCreateContext()
	bs = NoeBitStream(data)
	bs.setEndian(NOE_BIGENDIAN)
	rapi.rpgSetOption(noesis.RPGOPT_BIGENDIAN, 1)
	rapi.rpgSetOption(noesis.RPGOPT_TRIWINDBACKWARD, 1)

	header = bs.read(">11I")
	#print(header)

	info1 = []
	bs.seek(header[5], NOESEEK_ABS)
	for a in range(0, header[4]):
		info1.append(bs.read(">3I"))
	#print(info1)

	bs.seek(header[7], NOESEEK_ABS)
	info2 = bs.read(">3I")
	#print(info2)

	info3 = []
	bs.seek(info2[1], NOESEEK_ABS)
	for a in range(0, info2[2]):
		info3.append(bs.read(">2I"))
	#for a in range(0, info2[2]):
	#	print(("0x%0.10X" % info3[a][1]))
	texList = []
	matList = []
	for a in range(0, header[4]):
		bs.seek(info1[a][0], NOESEEK_ABS)
		info4 = bs.read(">2I4H")
		info5 = []
		for b in range(0, info4[5]):
			info5.append(bs.read(">4I"))
		for b in range(0, info4[5]):
			bs.seek(info1[a][0] + info5[b][1], NOESEEK_ABS)
			mainStr = readString(bs)
			#print(mainStr)
			bs.seek(info1[a][0] + info5[b][2], NOESEEK_ABS)
			info6 = bs.read(">8I")
			bs.seek(info1[a][0] + info6[1], NOESEEK_ABS)
			mainStr = readString(bs)
			bs.seek(info1[a][0] + info6[3], NOESEEK_ABS)
			typeStr = readString(bs)
			#print(mainStr, " - ", typeStr)
			if typeStr == "VRAM_DESC":
				bs.seek(info1[a][0] + info5[b][2] + 0x20, NOESEEK_ABS)
				texInfo = bs.read(">4I18H")
				texName = readString(bs)
				#print(texName)
				#print(texInfo)
				bs.seek(((len(data) - header[8]) + texInfo[1]), NOESEEK_ABS)
				texData = bs.readBytes(texInfo[2])
				imgWidth, imgHeight = texInfo[13], texInfo[15]
				#DXT1
				if texInfo[6] == 0x600:
					texFmt = noesis.NOESISTEX_DXT1
				#DXT3
				elif texInfo[6] == 0x700:
					texFmt = noesis.NOESISTEX_DXT3
				#DXT5
				elif texInfo[6] == 0x800:
					texFmt = noesis.NOESISTEX_DXT5
				#DXT5 packed normal map
				elif texInfo[6] == 0x0:
					texData = rapi.imageDecodeDXT(texData, imgWidth, imgHeight, noesis.FOURCC_ATI2)
					texFmt = noesis.NOESISTEX_RGBA32
				#Swizzled raw no alpha?
				elif texInfo[6] == 0x1501:
					untwid = bytearray()
					for x in range(0, imgWidth):
						for y in range(0, imgHeight):
							idx = noesis.morton2D(x, y)
							untwid += texData[idx*4:idx*4+4]
					texData = rapi.imageDecodeRaw(untwid, imgWidth, imgHeight, "r8g8b8p8")
					texFmt = noesis.NOESISTEX_RGBA32
				#Swizzled raw
				elif texInfo[6] == 0x500:
					untwid = bytearray()
					for x in range(0, imgWidth):
						for y in range(0, imgHeight):
							idx = noesis.morton2D(x, y)
							untwid += texData[idx*4:idx*4+4]
					texData = rapi.imageDecodeRaw(untwid, imgWidth, imgHeight, "r8g8b8a8")
					texFmt = noesis.NOESISTEX_RGBA32
				#unknown, not handled
				else:
					print("WARNING: Unhandled image format " + repr(texInfo[6]) + " - " + repr(texInfo[13]) + "x" + repr(texInfo[15]))
					#return None
				tex1 = NoeTexture(str(b), imgWidth, imgHeight, texData, texFmt)
				texList.append(tex1)
	mdl = NoeModel()
	mdl.setModelMaterials(NoeModelMaterials(texList, matList))
	mdlList.append(mdl)
	rapi.rpgClearBufferBinds()	
	return 1