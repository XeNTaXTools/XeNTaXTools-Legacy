Utilities for A New Beginning
=============================

Copyright (C) 2010-2012 Deniz Oezmen (http://oezmen.eu/)

All trademarks and copyrights mentioned implicitly or explicitly in this file or
the software described below are property of their respective owners.


VISExt
------

Extracts files from VIS archives (also named scene.vs* or character.vc*).

Usage:  VISExt <VISFiles> [/names:<NameFile>] [/generateNames:<NameFile>]
               [/unique]

        VISFiles                   Specifies the archive files to be processed.
                                   Wildcards are allowed.
        /names:<NameFile>          Optional, specifies a text file that contains
                                   the real names of the files within the VIS
                                   archive. This text file should usually be
                                   generated using the "generateNames" switch.
                                   When no name table is given or a file in the
                                   archive cannot be found within the name
                                   table, it will be extracted with a generic
                                   name.
        /generateNames:<NameFile>  This parameter is used to generate a table
                                   of file names found within the game's
                                   archives. It should usually be generated from
                                   the main VIS file. No files are extracted
                                   in this operation mode.
        /unique                    This switch is only effective in conjunction
                                   with the /names switch. Since files in more
                                   than one archive can have the same file name,
                                   a unique identifier will be added to the file
                                   name during extraction when specifying this
                                   switch. By default, the identifier is
                                   suppressed and all files are extracted with
                                   their exact names.


Example: First, generate the name table for all the game's archives from the
         main VIS archive:

         VISExt data.vis /generateNames:names.txt

         This should create a file "names.txt" containing the name table for all
         game archives. Next, use this name table for the extraction of each VIS
         archive:

         VISExt characters\character.vc000 /names:names.txt
         VISExt scenes\scene.vc035 /names:names.txt


VISExt has been based on the QuickBMS scripts by Luigi Auriemma
(http://aluigi.altervista.org/papers.htm#quickbms) and is thus distributed under
the terms of the GPL. See VISExt.dpr for details as well as the file COPYING
for the full license text.
