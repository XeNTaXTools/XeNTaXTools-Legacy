#include "stdafx.h"

#include "Ogre.h"
#include "OgreDefaultHardwareBufferManager.h"
#include <boost/regex.hpp> 
#include <iostream>
#include <fstream>
#include <sys/stat.h>
#include <vector>


#define PI (3.1415926535897932384626433832795)
#define DEG2RAD(a) ((a) * PI / 180.0)
#define RAD2DEG(a) ((a) * 180.0 / PI)

mathImpFn_t		*g_mfn = NULL;
noePluginFn_t	*g_nfn = NULL;

using namespace std;
using namespace Ogre;

//typedef  unsigned char    uint8;
//typedef  unsigned short   uint16;
//typedef  unsigned long    uint32;
//typedef  unsigned __int64 uint64;
//typedef  signed   char    int8;
//typedef  signed   short   int16;
//typedef  signed   long    int32;
//typedef  signed   __int64 int64;

#pragma pack(push, 1)

typedef struct Vertex_s
{
	float					PX, PY, PZ;
	float					NX, NY, NZ;
	float					TX, TY, TZ, TS;
	float					U, V;
	CArrayList<DWORD>	BoneIndex;
	CArrayList<float>	BoneWeight;
} Vertex_t;

typedef struct SubMesh_s
{
	uint8		Operation;
	char		Material[1024];
		
	uint32	IndexCount;
	uint32	*IndexData;
	uint32	Faces;

	bool		bVertexPositions;
	bool		bVertexNormals;
	bool		bVertexTangents;
	bool		bVertexUV;	
	bool		bVertexWeights;
	uint32	VertexCount;
	Vertex_t	*VertexData;
} SubMesh_t;

struct MESH_HEADER
{
	uint16	tag;
	char		begin_tag;
	char		label[20];
	char		end_tag;
};

#pragma pack(pop)

Math										*MTH = 0;
LogManager								*LGM = 0;
ResourceGroupManager					*RGM = 0;
MeshManager								*MM = 0;
LodStrategyManager					*LM = 0;
MaterialManager						*MT = 0;
SkeletonManager						*sm = 0;
MeshSerializer							*MS = 0;
SkeletonSerializer					*SS = 0;
DefaultHardwareBufferManager		*BM = 0;

//-------------------------------------------------------------------------------------------------
void	LOG(char *msg, ...)
{
	va_list		argptr;
	char			str[1024];

	va_start(argptr, msg);
	vsprintf(str, msg, argptr);
	va_end(argptr);

	LGM->logMessage(str);
}
//-------------------------------------------------------------------------------------------------
void	WARNING(char *message, ...)
{
	va_list		argptr;
	char			str[1024];

	va_start(argptr, message);
	vsprintf(str, message, argptr);
	va_end(argptr);

	LGM->logMessage(str);
	MessageBoxA(NULL, str, "Warning ...", MB_OK | MB_ICONERROR); 
}
//-------------------------------------------------------------------------------------------------
bool FileExists (LPCTSTR fname)
{
	return ::GetFileAttributes(fname) != DWORD(-1);
}
//-------------------------------------------------------------------------------------------------
void OgreStartup(void)
{
	LGM = new LogManager();
	LGM->createLog("ogre3d.log"); 
	RGM = new ResourceGroupManager();
	MTH = new Math();
	MM = new MeshManager();
	LM = new LodStrategyManager();
	MT = new MaterialManager();
	MT->initialise();
	sm = new SkeletonManager();
	MS = new MeshSerializer();
	SS = new SkeletonSerializer();
	BM = new DefaultHardwareBufferManager();
}
//-------------------------------------------------------------------------------------------------
void OgreShutdown(void)
{
	delete BM;
	delete SS;
	delete MS;
	delete sm;
	delete MT;
	delete LM;
	delete MM;
	delete MTH;
	delete RGM;
	delete LGM;
}
//-------------------------------------------------------------------------------------------------
bool ModelCheck(BYTE *fileBuffer, int bufferLen, noeRAPI_t *rapi)
{
	MESH_HEADER *header = (MESH_HEADER *)(fileBuffer);

	if(bufferLen < sizeof(MESH_HEADER)) return false;	
	if(header->tag != 0x1000) return false;
	if(header->begin_tag != '[') return false;

	return true;
}
//-------------------------------------------------------------------------------------------------
void UnloadSubMesh(SubMesh_t *data)
{	
	data->Material[0] = 0x00;
	data->bVertexPositions = data->bVertexNormals = data->bVertexTangents = data->bVertexUV = false;

	if (data->bVertexWeights)
	{
		for (int i = 0; i < data->VertexCount; i++)
		{
			data->VertexData[i].BoneIndex.Clear();
			data->VertexData[i].BoneWeight.Clear();
		}
		data->bVertexWeights = false;
	}

	data->IndexCount = 0;
	if (data->IndexData) delete(data->IndexData);	
	data->VertexCount = 0;
	if (data->VertexData) delete(data->VertexData);

	data->Faces = 0;	
}
//-------------------------------------------------------------------------------------------------
bool LoadSubMesh(Mesh *mesh, unsigned short index, SubMesh_t *data)
{
	LOG("Loading submesh with index: %d", index);

	SubMesh *sm = mesh->getSubMesh(index);
	VertexData *vd = sm->useSharedVertices ? mesh->sharedVertexData : sm->vertexData;
	bool use32BitIndexes = (!sm->indexData->indexBuffer.isNull() && sm->indexData->indexBuffer->getType() == HardwareIndexBuffer::IT_32BIT);

	strcpy_s(data->Material, 1024, sm->getMaterialName().c_str());
	data->bVertexPositions = data->bVertexNormals = data->bVertexTangents = data->bVertexUV = data->bVertexWeights = false;	
	data->VertexCount =  vd->vertexCount;
	data->VertexData = NULL;
	data->IndexCount = sm->indexData->indexCount;
	data->IndexData = NULL;
	data->Faces = 0;
	
	LOG("Material: %s", data->Material); 
	LOG("Vertex count: %d", data->VertexCount); 
	LOG("Use32BitIndexes: %d", use32BitIndexes); 
	LOG("Index count: %d", data->IndexCount);

	switch(sm->operationType)
	{
	case RenderOperation::OT_TRIANGLE_LIST:
		LOG("Operation: OT_TRIANGLE_LIST");
		data->Operation = RenderOperation::OT_TRIANGLE_LIST;
		if(sm->indexData->indexCount > 0) data->Faces = sm->indexData->indexCount / 3;
		break;
	case RenderOperation::OT_TRIANGLE_STRIP:			
		LOG("Operation: OT_TRIANGLE_STRIP");
		data->Operation = RenderOperation::OT_TRIANGLE_STRIP;
		if(sm->indexData->indexCount > 0) data->Faces = sm->indexData->indexCount - 2;
		break;
	case RenderOperation::OT_TRIANGLE_FAN:
		LOG("Operation: OT_TRIANGLE_FAN");
		data->Operation = RenderOperation::OT_TRIANGLE_FAN;
		if(sm->indexData->indexCount > 0) data->Faces = sm->indexData->indexCount - 2;
		break;
	case RenderOperation::OT_POINT_LIST:
	case RenderOperation::OT_LINE_LIST:
	case RenderOperation::OT_LINE_STRIP:
	default:
		WARNING("Unsupported operation: OT_POINT_LIST/OT_LINE_LIST/OT_LINE_STRIP");
		return(false);
		break;
	}

	LOG("Faces: %d", data->Faces);

	if (data->IndexCount > 0) 
	{
		data->IndexData = new uint32[data->IndexCount];

		size_t idx;
		unsigned int	*pInt = 0;
		unsigned short	*pShort = 0;
		HardwareIndexBufferSharedPtr ibuf = sm->indexData->indexBuffer;

		if(use32BitIndexes) pInt = static_cast<unsigned int*>(ibuf->lock(HardwareBuffer::HBL_READ_ONLY));
		else pShort = static_cast<unsigned short*>(ibuf->lock(HardwareBuffer::HBL_READ_ONLY)); 

		for (idx = 0; idx < data->IndexCount; ++idx)
		{
			if (use32BitIndexes) data->IndexData[idx] = *pInt++;
			else data->IndexData[idx] = *pShort++;			 
		}
	}

	data->VertexData = new Vertex_t[data->VertexCount];

	VertexDeclaration *decl = vd->vertexDeclaration;
	VertexBufferBinding *bind = vd->vertexBufferBinding;
	VertexBufferBinding::VertexBufferBindingMap::const_iterator b, bend;

	bend = bind->getBindings().end();	
	for(b = bind->getBindings().begin(); b != bend; ++b)
	{
		const HardwareVertexBufferSharedPtr vbuf = b->second;
		unsigned short bufferIdx = b->first;

		VertexDeclaration::VertexElementList elems = decl->findElementsBySource(bufferIdx);
		VertexDeclaration::VertexElementList::iterator i, iend;
		iend = elems.end();

		unsigned char	*pVert;
		float				*pFloat;

		pVert = static_cast<unsigned char*>(vbuf->lock(HardwareBuffer::HBL_READ_ONLY));
		unsigned short numTextureCoords = 0;
		for (i = elems.begin(); i != iend; ++i)
		{
			VertexElement &elem = *i;
			switch(elem.getSemantic())
			{
			case VES_POSITION:
				data->bVertexPositions = true;
				break;
			case VES_NORMAL:
				data->bVertexNormals = true;
				break;
			case VES_TANGENT:
				if (elem.getType() == VET_FLOAT3) data->bVertexTangents = true;
				break;
			case VES_TEXTURE_COORDINATES:
				if (elem.getType() == VET_FLOAT2) data->bVertexUV = true;
				break;
			default:				
				break;
			}
		}
		for (size_t v = 0; v < vd->vertexCount; ++v)
		{						
			for (i = elems.begin(); i != iend; ++i)
			{
				VertexElement& elem = *i;
				switch(elem.getSemantic())
				{
				case VES_POSITION:
					elem.baseVertexPointerToElement(pVert, &pFloat);
					data->VertexData[v].PX = pFloat[0];
					data->VertexData[v].PY = pFloat[1];
					data->VertexData[v].PZ = pFloat[2];
					break;
				case VES_NORMAL:
					elem.baseVertexPointerToElement(pVert, &pFloat);
					data->VertexData[v].NX = pFloat[0];
					data->VertexData[v].NY = pFloat[1];
					data->VertexData[v].NZ = pFloat[2];
					break;
				case VES_TANGENT:
					if (elem.getType() == VET_FLOAT3) 
					{
						elem.baseVertexPointerToElement(pVert, &pFloat);
						data->VertexData[v].TX = pFloat[0];
						data->VertexData[v].TY = pFloat[1];
						data->VertexData[v].TZ = pFloat[2];
						data->VertexData[v].TS = 1;
					}
					break;
				case VES_TEXTURE_COORDINATES:
					if(elem.getType() == VET_FLOAT2)
					{
						elem.baseVertexPointerToElement(pVert, &pFloat);
						data->VertexData[v].U = pFloat[0];
						data->VertexData[v].V = pFloat[1];
					}
					break;
				default:
					break;
				}				
			}
			pVert += vbuf->getVertexSize();			
		}
		vbuf->unlock();
	}

	LOG("bVertexPositions = %d bVertexNormals = %d bVertexTangents = %d bVertexUV = %d", 
		data->bVertexPositions, data->bVertexNormals, data->bVertexTangents, data->bVertexUV);

	
	if (mesh->hasSkeleton())
	{
		DWORD i; float w;
		if (sm->useSharedVertices)
		{
			Mesh::BoneAssignmentIterator mbi = const_cast<Mesh*>(mesh)->getBoneAssignmentIterator();
			while (mbi.hasMoreElements())
			{
				const VertexBoneAssignment &m_assign = mbi.getNext();	i = m_assign.boneIndex; w = m_assign.weight;
				//LOG("W: M vertex=%d index=%d weight=%f", m_assign.vertexIndex, i, w);
				data->VertexData[m_assign.vertexIndex].BoneIndex.Append(i);
				data->VertexData[m_assign.vertexIndex].BoneWeight.Append(w);
			}
		}
		else 
		{
			SubMesh::BoneAssignmentIterator smbi = const_cast<SubMesh*>(sm)->getBoneAssignmentIterator();
			while (smbi.hasMoreElements())
			{
				const VertexBoneAssignment &sm_assign = smbi.getNext();	i = sm_assign.boneIndex; w = sm_assign.weight;
				//LOG("W: SM vertex=%d index=%d weight=%f", sm_assign.vertexIndex, i, w);
				data->VertexData[sm_assign.vertexIndex].BoneIndex.Append(i);
				data->VertexData[sm_assign.vertexIndex].BoneWeight.Append(w);
			}

		}		
		data->bVertexWeights = true;
	}

	LOG("bVertexWeights = %d", data->bVertexWeights);

	return(true);
}
//-------------------------------------------------------------------------------------------------
void GetMaterialTexture(SubMesh_t *sm, noeRAPI_t *rapi)
{	
	char file[1024];
	char line[1024];

	int	exts = 5;
	char *ext[] = {".dds", ".jpg", ".png", ".tga", ".bmp"};
	for (int i = 0; i < exts; i++)
	{
		rapi->Noesis_GetExtensionlessName(file, rapi->Noesis_GetInputName());
		strcat_s(file, 1024, ext[i]);
		LOG("Check texture %s", file);
		if(FileExists(file))
		{
			rapi->Noesis_GetLocalFileName(line, file);					
			rapi->Noesis_GetExtensionlessName(sm->Material, line);
			LOG("Bind material: %s", sm->Material);
			return;
		}
	}

	// use MaterialSerializer::parseScript instead ???

	rapi->Noesis_GetDirForFilePath(file, rapi->Noesis_GetInputName());
	strcat_s(file, 1024, "\\*.material");

	// CArrayList <std::string> textures;
	std::vector <std::string> textures;
	std::string		str;

	bool				found = false, material = false, texunit = false, pushed = false;

	boost::regex	rxRegEx;
	boost::smatch	rxResults;
	std::string		rxStr;

	WIN32_FIND_DATA wfd;
	HANDLE hFind = ::FindFirstFile(file, &wfd);	
	if (hFind == INVALID_HANDLE_VALUE ) return;
	do 
	{
		rapi->Noesis_GetDirForFilePath(file, rapi->Noesis_GetInputName());
		strcat_s(file, 1024, wfd.cFileName);
		ifstream fs(file);
		if (fs.fail()) { LOG("Error open material file %s ...", file); continue; }
		LOG("Reading: %s", file);
		while (!fs.eof())
		{
			fs.getline(line, sizeof(line));			
			rxStr = line;
			rxRegEx.assign("^\\s*material\\s+(\\S+)\\s*.*", boost::regex_constants::icase);
			if (boost::regex_match(rxStr,  rxResults, rxRegEx)) 
			{
				if (material) break;
				if (rxResults[1] == (String) sm->Material) { material = true;  continue; }				
			}
			if (!material) continue;
			rxRegEx.assign("^\\s*texture_unit.*", boost::regex_constants::icase);
			if (boost::regex_match(rxStr,  rxResults, rxRegEx)) { texunit = true; found = false; pushed = false;}
			if (!texunit) continue;
			rxRegEx.assign("^\\s*\\}.*", boost::regex_constants::icase);
			if (boost::regex_match(rxStr,  rxResults, rxRegEx)) texunit = false;
			if (!texunit) continue;
			rxRegEx.assign(".*(diffuse|dif|diff|decal).*", boost::regex_constants::icase);
			if (boost::regex_match(rxStr,  rxResults, rxRegEx)) found = true;
			rxRegEx.assign("^\\s*texture\\s+(\\S+)\\s*.*", boost::regex_constants::icase);
			if (boost::regex_match(rxStr,  rxResults, rxRegEx)) 
			{
				str = ((std::string)rxResults[1]);
				textures.push_back(str);
				pushed = true;
			}			
			if (pushed && found) break;
		} 
		fs.close();
		if(material) break;
	} while (::FindNextFile(hFind, &wfd) != 0);
	FindClose(hFind);

	if(textures.size() > 0)
	{
		if (found) str = textures[textures.size()-1];
		else str = textures[0];
		rapi->Noesis_GetExtensionlessName((char *)sm->Material, (char *)str.c_str());
	}
	LOG("Bind material: %s", sm->Material);
}
//-------------------------------------------------------------------------------------------------
modelBone_t *GetModelBones(Mesh *mesh, noeRAPI_t *rapi, int &nBones)
{	
	char file[1024];
	modelBone_t *bones = NULL;

	if (!mesh->hasSkeleton()) return(NULL);
	LOG("Has skeleton: %s", (mesh->getSkeletonName()).c_str());
	rapi->Noesis_GetDirForFilePath(file, rapi->Noesis_GetInputName());
	strcat_s(file, 1024, (mesh->getSkeletonName()).c_str());
	if (!FileExists(file))
	{
		LOG("Skeleton file not found ...");
		return(NULL);
	}
	
	LOG("Loading %s", file);
	std::ifstream ifs;
	ifs.open(file, std::ios_base::in | std::ios_base::binary);
	if (ifs.bad()) 
	{
		LOG("Unable to load skeleton file ...");
		return(NULL);
	}
	SkeletonPtr skel = SkeletonManager::getSingleton().create("conversion", ResourceGroupManager::DEFAULT_RESOURCE_GROUP_NAME);
	DataStreamPtr stream(new FileStreamDataStream(file, &ifs, false));
	SS->importSkeleton(stream, skel.getPointer());
	Skeleton *sk = skel.getPointer();
	
	int numBones = nBones = sk->getNumBones();
	bones = rapi->Noesis_AllocBones(numBones);
	for (unsigned short i = 0; i < numBones; ++i)
	{
		Bone *bone = sk->getBone(i);
		bones[i].index = bone->getHandle();
		strcpy_s(bones[i].name, 31, (bone->getName()).c_str());
		bones[i].parentName[0] = 0x00;
		Bone *parent = (Bone*) bone->getParent();		
		if(parent) strcpy_s(bones[i].parentName, 31, (parent->getName()).c_str());
		else bones[i].eData.parent = NULL;

		Matrix3 rot;
		bone->getOrientation().ToRotationMatrix(rot);
		Vector3 pos = bone->getPosition();
	
		//bones[i].mat.x1[0] = rot[0][0];
		//bones[i].mat.x1[1] = rot[0][1];
		//bones[i].mat.x1[2] = rot[0][2];
		//bones[i].mat.x2[0] = rot[1][0];
		//bones[i].mat.x2[1] = rot[1][1];
		//bones[i].mat.x2[2] = rot[1][2];
		//bones[i].mat.x3[0] = rot[2][0];
		//bones[i].mat.x3[1] = rot[2][1];
		//bones[i].mat.x3[2] = rot[2][2];
		bones[i].mat = g_identityMatrix;
		bones[i].mat.o[0] = pos.x;
		bones[i].mat.o[1] = pos.y;
		bones[i].mat.o[2] = pos.z;
	}

	for (unsigned short i = 0; i < numBones; ++i)
	{		
		for (unsigned short j = 0; j < numBones; ++j)
		{
			if (strcmp(bones[i].parentName, bones[j].name) == 0)
			{
				bones[i].eData.parent = &bones[j];
				break;
			}
		}
	}
	return(bones);
}
//-------------------------------------------------------------------------------------------------
void DumpBones(modelBone_t *bones, int numBones)
{
	LOG("NUM BONES: %d", numBones);

	for (int i = 0; i < numBones; ++i)
	{
		LOG("%x BONE %d : %s parent %s %x", &bones[i], bones[i].index, bones[i].name, bones[i].parentName, bones[i].eData.parent);
		LOG("%f\t%f\t%f", bones[i].mat.x1[0], bones[i].mat.x1[1], bones[i].mat.x1[2]);
		LOG("%f\t%f\t%f", bones[i].mat.x2[0], bones[i].mat.x2[1], bones[i].mat.x2[2]);
		LOG("%f\t%f\t%f", bones[i].mat.x3[0], bones[i].mat.x3[1], bones[i].mat.x3[2]);
		LOG("%f\t%f\t%f", bones[i].mat.o[0], bones[i].mat.o[1], bones[i].mat.o[2]);
	}
}
//-------------------------------------------------------------------------------------------------
noesisModel_t *ModelLoad(BYTE *fileBuffer, int bufferLen, int &numMdl, noeRAPI_t *rapi)
{
	OgreStartup();

	std::ifstream ifs;
	ifs.open(rapi->Noesis_GetInputName(), std::ios_base::in | std::ios_base::binary);
	if (ifs.bad()) { WARNING("Error open %s ...", rapi->Noesis_GetInputName()); OgreShutdown(); return(NULL); }
	DataStreamPtr stream(new FileStreamDataStream(rapi->Noesis_GetInputName(), &ifs, false));

	MeshPtr pMesh = MeshManager::getSingleton().create("conversion", ResourceGroupManager::DEFAULT_RESOURCE_GROUP_NAME);
	Mesh *mesh = pMesh.getPointer();
	MS->importMesh(stream, mesh);		
	
	LOG("File: %s", rapi->Noesis_GetInputName());

	void *pgctx = rapi->rpgCreateContext();

	int nBones = 0;
	LOG("bones %d", nBones);
	modelBone_t *bones = GetModelBones(mesh, rapi, nBones);		
	DumpBones(bones, nBones);

	if (bones) rapi->rpgSetExData_Bones(bones, nBones);

	for (unsigned short index = 0; index < mesh->getNumSubMeshes(); index++)
	{
		SubMesh_t sm;
		if(!LoadSubMesh(mesh, index, &sm)) { OgreShutdown(); return(NULL); }
		GetMaterialTexture(&sm, rapi);

		rapi->rpgSetMaterial(sm.Material);

		switch(sm.Operation)
		{
		case RenderOperation::OT_TRIANGLE_LIST:			
			rapi->rpgBegin(RPGEO_TRIANGLE);
			break;
		case RenderOperation::OT_TRIANGLE_STRIP:			
			rapi->rpgBegin(RPGEO_TRIANGLE_STRIP);
			break;
		case RenderOperation::OT_TRIANGLE_FAN:
			rapi->rpgBegin(RPGEO_TRIANGLE_FAN);
			break;
		case RenderOperation::OT_POINT_LIST:
		case RenderOperation::OT_LINE_LIST:
		case RenderOperation::OT_LINE_STRIP:
		default:
			WARNING("Unsupported operation: OT_POINT_LIST/OT_LINE_LIST/OT_LINE_STRIP");
			OgreShutdown(); 
			return(NULL);
			break;
		}
		
		uint32 i = 9, vi = 0;
		for(i = 0; i < sm.Faces; i++)
		{
			if (sm.bVertexWeights)
			{
				rapi->rpgVertBoneIndexUI(&sm.VertexData[sm.IndexData[vi]].BoneIndex[0], sm.VertexData[sm.IndexData[vi]].BoneIndex.Num());
				rapi->rpgVertBoneWeightF(&sm.VertexData[sm.IndexData[vi]].BoneWeight[0], sm.VertexData[sm.IndexData[vi]].BoneWeight.Num());
			}
			if (sm.bVertexNormals) rapi->rpgVertNormal3f((float*) &sm.VertexData[sm.IndexData[vi]].NX);
			if (sm.bVertexTangents) rapi->rpgVertTan4f((float*) &sm.VertexData[sm.IndexData[vi]].TX);
			if (sm.bVertexUV) rapi->rpgVertUV2f((float*) &sm.VertexData[sm.IndexData[vi]].U, 0);
			if (sm.bVertexPositions) rapi->rpgVertex3f((float*) &sm.VertexData[sm.IndexData[vi]].PX);
			vi++;
			if (sm.Operation == RenderOperation::OT_TRIANGLE_LIST || i == 0)
			{
				if (sm.bVertexWeights)
				{
					rapi->rpgVertBoneIndexUI(&sm.VertexData[sm.IndexData[vi]].BoneIndex[0], sm.VertexData[sm.IndexData[vi]].BoneIndex.Num());
					rapi->rpgVertBoneWeightF(&sm.VertexData[sm.IndexData[vi]].BoneWeight[0], sm.VertexData[sm.IndexData[vi]].BoneWeight.Num());
				}
				if (sm.bVertexNormals) rapi->rpgVertNormal3f((float*) &sm.VertexData[sm.IndexData[vi]].NX);
				if (sm.bVertexTangents) rapi->rpgVertTan4f((float*) &sm.VertexData[sm.IndexData[vi]].TX);
				if (sm.bVertexUV) rapi->rpgVertUV2f((float*) &sm.VertexData[sm.IndexData[vi]].U, 0);
				if (sm.bVertexPositions) rapi->rpgVertex3f((float*) &sm.VertexData[sm.IndexData[vi]].PX);
				vi++;				
				if (sm.bVertexWeights)
				{
					rapi->rpgVertBoneIndexUI(&sm.VertexData[sm.IndexData[vi]].BoneIndex[0], sm.VertexData[sm.IndexData[vi]].BoneIndex.Num());
					rapi->rpgVertBoneWeightF(&sm.VertexData[sm.IndexData[vi]].BoneWeight[0], sm.VertexData[sm.IndexData[vi]].BoneWeight.Num());
				}
				if (sm.bVertexNormals) rapi->rpgVertNormal3f((float*) &sm.VertexData[sm.IndexData[vi]].NX);
				if (sm.bVertexTangents) rapi->rpgVertTan4f((float*) &sm.VertexData[sm.IndexData[vi]].TX);
				if (sm.bVertexUV) rapi->rpgVertUV2f((float*) &sm.VertexData[sm.IndexData[vi]].U, 0);
				if (sm.bVertexPositions) rapi->rpgVertex3f((float*) &sm.VertexData[sm.IndexData[vi]].PX);
				vi++;
			}
		}		
		UnloadSubMesh(&sm);
		rapi->rpgEnd();
	}		
	pMesh.setNull();	
	
	OgreShutdown();

	rapi->rpgOptimize();
	noesisModel_t *mdl = rapi->rpgConstructModel();
	if (mdl)
	{
		numMdl = 1; //it's important to set this on success! you can set it to > 1 if you have more than 1 contiguous model in memory
		//rapi->SetPreviewAnimSpeed(10.0f);
		//this'll rotate the model (only in preview mode) into quake-friendly coordinates
		//static float mdlAngOfs[3] = {0.0f, 0.0f, 45.0f};
		//rapi->SetPreviewAngOfs(mdlAngOfs);
	}
	rapi->rpgDestroyContext(pgctx);
	return mdl;
}

//called by Noesis to init the plugin
NPLUGIN_API bool NPAPI_Init(mathImpFn_t *mathfn, noePluginFn_t *noepfn)
{
	g_mfn = mathfn;
	g_nfn = noepfn;

	if (g_nfn->NPAPI_GetAPIVersion() < NOESIS_PLUGINAPI_VERSION)
	{ //bad version of noesis for this plugin
		return false;
	}

	int fh = g_nfn->NPAPI_Register("Ogre3d Model", ".mesh");
	if (fh < 0) return false;

	//set the data handlers for this format
	g_nfn->NPAPI_SetTypeHandler_TypeCheck(fh, ModelCheck);
	g_nfn->NPAPI_SetTypeHandler_LoadModel(fh, ModelLoad);

	return true;
}

//called by Noesis before the plugin is freed
NPLUGIN_API void NPAPI_Shutdown(void)
{
	//nothing to do in this plugin
}

NPLUGIN_API int NPAPI_GetPluginVer(void)
{
	return NOESIS_PLUGIN_VERSION;
}

NPLUGIN_API bool NPAPI_GetPluginInfo(noePluginInfo_t *infOut)
{
	strcpy_s(infOut->pluginName, 64, "ogre3d");
	strcpy_s(infOut->pluginDesc, 512, "Ogre 3D model handler.");
	return true;
}

BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
					 )
{
	return TRUE;
}
