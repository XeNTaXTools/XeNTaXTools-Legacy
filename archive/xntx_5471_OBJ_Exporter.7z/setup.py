from distutils.core import setup
import py2exe

options = {'py2exe': {"bundles_file" : 1}, },

setup(
    windows = [
        {
            "script": "YOBJ_Tool_GUI.py",                    ### Main Python script   
            #"icon_resources": [(0, "unmirror.ico")],
            "compressed": True
        }
    ],
)

setup(
    windows = [
        {
            "script": "YOBJ_Tool_GUI.py",                    ### Main Python script   
            #"icon_resources": [(0, "unmirror.ico")],
            "compressed": True
        }
    ],
)