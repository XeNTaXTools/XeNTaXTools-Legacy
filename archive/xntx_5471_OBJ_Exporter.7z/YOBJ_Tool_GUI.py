#!/usr/bin/python
from Tkinter import *
from tkFileDialog import *
from tkMessageBox import *
import ttk
import os
import sys
import shutil
from yobj import *
import scanf
class Application(object):
    def __init__(self):
        self.root = Tk()
        self.root.title('YOBJ File Tool')
        self.filename = ''
        self.basename = ''
        self.dirname  = ''
        self.file=None
        self.mainframe= ttk.Frame(self.root,padding="4 4 16 16")
        self.mainframe.grid(column=0,row=0,sticky=(N,W,E,S))
        self.mainframe.columnconfigure(0, weight=1)
        self.mainframe.rowconfigure(0, weight=1)
        if os.path.exists("yobj-editor.ico") == True:
            self.root.wm_iconbitmap(bitmap = "yobj-editor.ico")
        self.label_file           = ttk.Label(self.mainframe, text="File")
        self.label_file.grid(column=0,row=0)
        self.entry_file_var       = StringVar() 
        self.entry_file           = ttk.Entry(self.mainframe, width=16, state="readonly",textvariable=self.entry_file_var)
        self.entry_file.grid(column=1,row=0)
        self.button_open          = ttk.Button(self.mainframe, text="Open", command=self.open_file)
        self.button_open.grid(column=2,row=0)
        

        self.export_button       = ttk.Button(self.mainframe, text="Export OBJ",command=self.export_obj)
        self.export_button.grid(column=0,row=1)
        
        self.export_all_button = ttk.Button(self.mainframe, text="Export all to OBJ", command=self.export_all)
        self.export_all_button.grid(column=1,row=1)
        
        self.export_all_button2 = ttk.Button(self.mainframe, text="Export all as one OBJ", command=self.export_all2)
        self.export_all_button2.grid(column=2,row=1)
        
        self.import_button       = ttk.Button(self.mainframe, text="Import OBJ",command=self.import_obj)
        self.import_button.grid(column=0,row=2)
        self.import_all_obj_button = ttk.Button(self.mainframe, text="Import All OBJ",command=self.import_all_obj)
        self.import_all_obj_button.grid(column=1, row=2)
        
        self.menubar = Menu(self.root) 
        
        self.filemenu = Menu(self.menubar, tearoff=0)
        self.filemenu.add_command(label="Open", command=self.open_file)
        self.filemenu.add_separator()
        self.filemenu.add_command(label="Exit", command=sys.exit)        
        self.menubar.add_cascade(label="File", menu=self.filemenu)
        self.scrollbar = Scrollbar(self.root)
        self.scrollbar.grid(column=1, row=3, sticky='nsew') 
        self.listbox = Listbox(self.root,yscrollcommand = self.scrollbar.set,width=0x30,selectmode=SINGLE)
        self.scrollbar.config( command = self.listbox.yview )
        self.listbox.grid(column=0, row=3)
        
        
        if len(sys.argv) == 2:
            if os.path.exists(sys.argv[1]):
                self.open_file(sys.argv[1])
        self.root.config(menu=self.menubar)        
        self.root.resizable(width=False,height=False)
        self.root.mainloop()

    def open_file(self, filename=None):
        if filename is None:
            filename = askopenfilename(filetype=(("YOBJ Model File", "*.yobj"), ("All files", "*")),
                                       initialdir=self.dirname)
        if filename == '':
            return
        else:
            self.filename = filename
        try:
            self.file = YOBJ(self.filename)
            self.dirname = os.path.dirname(self.filename)
            self.basename = os.path.basename(self.filename)
            self.entry_file_var.set(self.basename.upper())
            self.listbox.delete(0, END)
            for x in xrange(0, self.file.n_mesh):
                self.listbox.insert(END, "Object %d" % (x))
        except Exception as exception:
            showerror(title=type(exception).__name__, message=str(exception))
        return

    def export_obj(self):
        if self.file is None:
            return
        try:
            input_name = self.listbox.get(self.listbox.curselection())
        except TclError:
            showerror(title = "Error",message="You didn't select any file")
            return
        if input_name == '':
            return
        mesh_id = scanf.sscanf(input_name, "Object %d")[0]
        output_name = asksaveasfilename(initialfile="%s_obj%d.obj" % (self.filename, mesh_id),initialdir=self.dirname)
        if output_name == '':
            return
        try:
            data = self.file.extract_obj(mesh_id, output_name)
            showinfo(title="Task completed",message="'%s' extraction completed!" % input_name)
        except Exception as exception:
            showerror(title=type(exception).__name__, message=str(exception))
        return

    def export_all(self):
        if self.file is None:
            return
        try:
            if not os.path.exists("%s\\@%s" % (self.dirname, self.basename)):
                os.mkdir("%s\\@%s" % (self.dirname, self.basename))
            for x in xrange(self.file.n_mesh):
                self.file.extract_obj(x, "%s\\@%s\\Object_%d.obj" % (self.dirname, self.basename, x))
            showinfo(title="Task completed",message="Extract all completed!")
        except Exception as exception:
            showerror(title=type(exception).__name__, message=str(exception))
        return
        
    def export_all2(self):
        if self.file is None:
            return
        output_name = asksaveasfilename(initialfile="%s.obj" % (os.path.splitext(self.basename)[0]),initialdir=self.dirname)
        if output_name == '':
            return
        try:
            self.file.extract_obj2(output_name)
            showinfo(title="Task completed",message="Extract all as one obj completed!")
        except Exception as exception:
            showerror(title=type(exception).__name__, message=str(exception))
        return
    def import_obj(self):
        if self.file is None:
            return
        try:
            input_name = self.listbox.get(self.listbox.curselection())
        except TclError:
            showerror(title = "Error",message="You didn't select any file")
            return
        try:
            inject_filename =askopenfilename(title="Select the file to inject to %s" % input_name, filetype=(("Wavefront OBJ File", "*.obj"), ("All files", "*")), initialdir=self.dirname)
            if inject_filename == '':
                return
            mesh_id = scanf.sscanf(input_name, "Object %d")[0]
            try:
                shutil.copy(self.filename, "%s.bak" % self.filename)
            except:
                if askyesno(title="Backup Failed", message="An error occurs when attempting to save the backup file\nSave anyway?") == False:
                    return      
            self.file.inject_obj(mesh_id, inject_filename)
            showinfo(title="Task completed",message="Obj File Injection Completed! Reopening the file")
            del self.file
            self.open_file(self.filename)
        except AssertionError as exception:
            showerror(title=type(exception).__name__, message=str(exception))
        return
        
    def import_all_obj(self):
        if self.file is None:
            return
        dirname = askdirectory(title="Select the directory which has all of the obj file", initialdir="%s\\@%s" % (self.dirname, self.basename))
        if dirname == '':
            return
        try:
            try:
                shutil.copy(self.filename, "%s.bak" % self.filename)
            except:
                if askyesno(title="Backup Failed", message="An error occurs when attempting to save the backup file\nSave anyway?") == False:
                    return      
            for x in xrange(0, self.file.n_mesh):
                print "Injecting mesh %d of %d" % (x, self.file.n_mesh-1)
                filepath = "%s\Object_%d.obj" % (dirname, x)
                if os.path.exists(filepath) == False:
                    answer = askyesno(title="File Not Found",message="File %s not found, do you want to continue injecting ? (No to Quit)" % filepath)
                    if answer == True:
                        continue
                    else:
                        break
                self.file.inject_obj(x, filepath)
            showinfo(title="Task completed",message="Obj Folder Injection Completed! Reopening the file")
            del self.file
            self.open_file(self.filename)        
        except Exception as exception: 
            showerror(title=type(exception).__name__, message=str(exception))
        return
            
if __name__ == "__main__":
    abs_path = os.path.abspath(sys.argv[0])
    os.chdir(os.path.dirname(abs_path))
    app = Application() 