import scanf

class OBJ(object):
    def __init__(self, filename):
        self.filename = filename
        self.file = open(filename, 'r')
        self.vertex = []
        self.normal = []
        self.face = []
        self.texture_coordinate = []
        self.unknown_list = []
        line_count = 1
        for line in self.file:
            # vertex data v x y z
            if line.startswith("#"):
                continue
            elif line.startswith("v "):
                try:
                    self.vertex.append(list(scanf.sscanf(line, "v %f %f %f\n")))
                except:
                    pass
            elif line.startswith("vn "):
                try:
                    self.normal.append(list(scanf.sscanf(line, "vn %f %f %f\n")))
                except:
                    pass
            elif line.startswith("f "):
                try:
                    self.face.append(list(scanf.sscanf(line, "f %d %d %d\n")))
                except:
                    pass
                try:
                    face_list = scanf.sscanf(line, "f %d/%d %d/%d %d/%d\n")
                    self.face.append([face_list[0], face_list[2], face_list[4]])
                except:
                    pass
                try:
                    face_list = scanf.sscanf(line, "f %d//%d %d//%d %d//%d\n")
                    self.face.append([face_list[0], face_list[2], face_list[4]])
                except:
                    pass
                try:
                    face_list = scanf.sscanf(line, "f %d/%d/%d %d/%d/%d %d/%d/%d\n")
                    self.face.append([face_list[0], face_list[3], face_list[6]])
                except:
                    pass
            elif line.startswith("vt "):
                try:
                    self.texture_coordinate.append(list(scanf.sscanf(line, "vt %f %f\n")))
                except:
                    pass
            else:
                self.unknown_list.append(line_count)
            line_count += 1 
        for x in xrange(len(self.face)):
            self.face[x][0], self.face[x][1], self.face[x][2] = self.face[x][0] - 1, self.face[x][1] - 1, self.face[x][2] - 1
        