def fill_string(string, size):
    assert len(string) <= size
    while len(string) != size:        
        string = "%s\x00" % string
    return string 

def string_shortener(string):
    new_string = ""
    for char in string:
        if char == "\x00":
            break
        new_string = "%s%s" % (new_string, char)
    return new_string
