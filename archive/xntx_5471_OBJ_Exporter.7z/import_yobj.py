#2011-11-06 Glogow Poland Mariusz Szkaradek
#Rumble Roses(PS2) yobj importer
#press alt+p and select folder with yobj files (example: '...\1200.pac')
#IMPORT:
#-geometry with uv split per material
#-bones
import struct,os
from struct import *
import math
from math import *
import sys

def create_object_name():
    global model_id
    ids = []
    #scene = bpy.data.scenes.active
    for mat in Material.Get():
        #print mat.name
        try:
            model_id = int(mat.name.split('-')[0])
            ids.append(model_id)
        except:pass
    try:
        model_id = max(ids)+1
    except:
        model_id = 0

def find_0():
    s=''
    while(True):
        litera =  struct.unpack('c',plik.read(1))[0]
        if  litera=='\x00':
            break
        else:
            s+=litera
    return s


def word(long):
   s=''
   for j in range(0,long):
       lit =  struct.unpack('c',plik.read(1))[0]
       if ord(lit)!=0:
           s+=lit
           if len(s)>100000:
               break
   return s

def b(n):
    return struct.unpack(n*'b', plik.read(n))
def B(n):
    return struct.unpack(n*'B', plik.read(n))
def h(n):
    return struct.unpack(n*'h', plik.read(n*2))
def H(n):
    return struct.unpack(n*'H', plik.read(n*2))
def i(n):
    return struct.unpack(n*'i', plik.read(n*4))
def f(n):
    return struct.unpack(n*'f', plik.read(n*4))


def vertexuv():
    for m in range(nMat):
    #for m in range(nParts):
        mesh.materials+=[Material.New()]
    mesh.vertexUV = 1
    mesh.faceUV = 1
    for m in range(len(faceslist)):
        for n in range(3):
            uv_data = uvlist[m][n]
            v_id = faceslist[m][n]
            mesh.verts[v_id].uvco = Vector(uv_data)
        f = mesh.faces[m]
        f.uv = [v.uvco for v in f.verts]
        f.mat = uvlist[m][3]
       
    mesh.update()   

def parser():
    global bones,vertexlist,faceslist,uvlist,nMat,nParts
    print word(4)
    offs = i(18);print offs
   
    bones = []

    plik.seek(offs[9]+8)
    for a in range(offs[6]):
        BoneName = word(16);print BoneName
        tx = f(1)[0]
        ty = f(1)[0]
        tz = f(1)[0]
        tw = f(1)[0]
        rx = (f(1)[0] * 180) / pi
        ry = (f(1)[0] * 180) / pi
        rz = (f(1)[0] * 180) / pi
        rw = f(1)[0]
        parent = i(1)[0]
        plik.seek(0xC,1)#seek_cur
        qx = f(1)[0]
        qy = f(1)[0]
        qz = f(1)[0]
        qw = f(1)[0]
        bones.append([BoneName,parent,[tx,ty,tz],[rx,ry,rz]])
        #tfm = (eulerangles rx ry rz) as matrix3
        #append tarr [tx,ty,tz]
        #append rarr tfm
        #append qarr [qx,qy,qz,qw]
        #append Barr BoneName
        #append Parr parent

    plik.seek(offs[8])
    print plik.tell()
    meshdata = []
    for m in range(offs[5]):
        back = plik.tell()
        data = i(13);print m,data
        pos = f(3)
        meshdata.append([data,pos])
        plik.seek(back+64)
        #break

    for m in range(offs[5]):
    #for m in range(5):
        print 'object-',m
        vertexlist = []
        faceslist = []
        uvlist = []
        data = meshdata[m][0]
        plik.seek(data[8]+40)
        back = plik.tell()
        for n in range(data[12]):
            vertexlist.append(f(3))
            i(1)[0]
        print vertexlist
 
        print plik.tell()
        print i(4)     
        for n in range(data[12]):
            f(4)

        print plik.tell()
        print i(4)     
        for n in range(data[11]):#weights
            print n,f(4)

        print plik.tell()
        plik.seek(data[5]+8)
        print plik.tell()
        face_data = []
        for n in range(data[3]):
            f(8)
            i(40)
            var = i(4)#;print var
            face_data.append(var)
            #print plik.tell()
        nMat = data[3]
        for n in range(data[3]):#nMat
            #faceslist = []
            #uvlist = []
            plik.seek(face_data[n][2]+8)           
            for k in range(face_data[n][1]):
                k,i(4)     
                #back = plik.tell()     
            plik.seek(face_data[n][3]+8)
            nParts = face_data[n][1]
            for k in range(face_data[n][1]):#nParts
                #print m,plik.tell()
                var = B(32)#;print var 
                v1 = -1
                v2 = -1
                uv1 = -1
                uv2 = -1
                direct = -1
                for l in range(var[16]):#nFaces
                    direct*=-1
                    #mesh.verts[m].uvco = Vector(uvlist[m])
                    uv3 = [f(1)[0],1-f(1)[0]]
                    l,f(1),
                    v3 = i(1)[0]
                    #print v1,v2,v3
                    f(4)
                    if v1!=-1 and v2!=-1:
                        if direct>0:
                            faceslist.append([v1,v2,v3])
                            uvlist.append([uv1,uv2,uv3,n])
                            #uvlist.append([uv1,uv2,uv3,k])
                        else:
                            faceslist.append([v1,v3,v2])
                            uvlist.append([uv1,uv3,uv2,n])
                            #uvlist.append([uv1,uv3,uv2,k])
                    v1=v2
                    uv1=uv2
                    v2=v3
                    uv2=uv3
        print plik.tell()
        yield (vertexlist, faceslist, uvlist)
        
        #drawmesh('model-'+str(m))
        #vertexuv()
        #Blender.Redraw
    print plik.tell()
       



def importer(filename):
    global plik,dirname,basename,skala,nbBones
    basename = os.path.basename(filename)
    print basename
    dirname = os.path.dirname(filename)
    plik = open(filename, 'rb')
    return
#Window.FileSelector (importer)

