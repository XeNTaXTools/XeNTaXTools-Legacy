# 06/12/2016 by eatrawmeat391
# Converted some code from import_svr_yobj_ps2.py by "Glogow Poland Mariusz Szkaradek"
# https://en.wikibooks.org/wiki/Blender_3D:_Noob_to_Pro/Materials_and_Textures
# Use ratCAVE to draw http://ratcave.readthedocs.io/en/latest/tutorial1.html
from control import *
from data_op import *
from obj import *
import os
import math

def rotate_3d_x(x, y, z, degree):
    q = degree * (math.pi / 180)
    new_y = y*math.cos(q) - z*math.sin(q)
    new_z = y*math.sin(q) + z*math.cos(q)
    new_x = x
    return new_x, new_y, new_z
    
def rotate_3d_y(x, y, z, degree):
    q = degree * (math.pi / 180)
    new_z = z*math.cos(q) - x*math.sin(q)
    new_x = z*math.sin(q) + x*math.cos(q)
    new_y = y
    return new_x, new_y, new_z
    
def rotate_3d_z(x, y, z, degree):
    q = degree * (math.pi / 180)
    new_x = x*math.cos(q) - y*math.sin(q)
    new_y = x*math.sin(q) + y*math.cos(q)
    new_z = z
    return new_x, new_y, new_z
    
class YOBJ(object):
    def __init__(self, filename):
        self.filename = filename
        self.file_obj = open(filename, 'rb+')
        self.file = hex_file(self.file_obj)
        self.size_entry = self.file.read_int(0x04, 4)
        self.n_mesh = self.file.read_int(0x18, 4)
        self.n_texture = self.file.read_int(0x20, 4)
        self.texture_start_offset = self.file.read_int(0x2C, 4) + 8
        #self.texture_end_offset = self.file.read_int(0x30, 4) + 8
        self.texture_end_offset = self.texture_start_offset + 0x10*self.n_texture
        self.texture_list = self.get_texture_list()
        self.n_bone = self.file.read_int(0x1C, 4)
        self.offset_to_mesh_description = self.file.read_int(0x24, 4)
        self.offset_to_bone             = self.file.read_int(0x28, 4) + 8
        
        #self.offset_to_indice_section   = self.file.read_int(0x54, 4)
        #self.n_bone_weight_of_mesh      = self.file.read_int(0x6C, 4)
        #self.offset_to_vertex_data      = self.file.read_int(0x60, 4) + 0x28
        #self.n_vertices_of_mesh         = self.file.read_int(0x70, 4)
        #self.offset_to_normal_data      = self.offset_to_vertex_data + self.n_vertices_of_mesh*0x10 + 0x10
        self.mesh_material_number = []
        self.offset_to_indice_section = []
        self.n_bone_weight_of_mesh = []
        self.offset_to_vertex_data = []
        self.n_vertices_of_mesh = []
        self.offset_to_normal_data = []
        self.relative_offset = []
        for x in xrange(self.n_mesh):
            self.mesh_material_number.append(self.file.read_int(self.offset_to_mesh_description+0x0C+0x40*x, 4))
            self.offset_to_indice_section.append(self.file.read_int(self.offset_to_mesh_description+0x14+0x40*x, 4))
            self.n_bone_weight_of_mesh.append(self.file.read_int(self.offset_to_mesh_description+0x2C+0x40*x, 4))
            self.offset_to_vertex_data.append(self.file.read_int(self.offset_to_mesh_description+0x20+0x40*x, 4) + 0x28)
            self.n_vertices_of_mesh.append(self.file.read_int(self.offset_to_mesh_description+0x30+0x40*x, 4))
            self.offset_to_normal_data.append(self.offset_to_vertex_data[x] + self.n_vertices_of_mesh[x]*0x10 + 0x10)
            self.relative_offset.append(self.file.read_int(self.offset_to_mesh_description+0x3C+0x40*x, 4))
        #self.part_in_mesh               = self.file.read_int(0x259C, 4)
        #self.indices_offset             = self.file.read_int(0x25A0, 4) + 4
        return

    def get_face_data(self, mesh_id):
        offset = self.offset_to_indice_section[mesh_id] + 8
        face_data = []
        for n in xrange(self.mesh_material_number[mesh_id]):
            offset += 192
            var = []
            for x in xrange(4):
                value = self.file.read_int(offset, 4)
                offset += 4
                var.append(value)
            face_data.append(var)
        return face_data
    
    def get_indice_data(self, mesh_id, return_address=False):
        #Read nMat
        nMat = self.mesh_material_number[mesh_id]
        face_data = self.get_face_data(mesh_id)
        faceslist = []
        uvlist = []    
        faces_address = []
        uv_address = []
        #temp = open("uvlist.txt", 'w')
        for n in xrange(nMat):   
            offset = face_data[n][3] + 8
            nParts = face_data[n][1]
            for k in xrange(nParts):#nParts
                #var = []
                #for x in xrange(32):
                #    value = self.file.read_int(offset, 1)
                #    offset += 1
                #    var.append(value)
                #temp.write("\n")
                nFaces = self.file.read_int(offset+16, 1)
                offset += 32
                v1 = -1
                v2 = -1
                uv1 = -1
                uv2 = -1
                direct = -1
                for l in xrange(nFaces):#nFaces
                    direct*=-1
                    #mesh.verts[m].uvco = Vector(uvlist[m])
                    
                    uv3 = [self.file.read_float(offset, 4),1-self.file.read_float(offset+4, 4)]
                        
                    v3 = self.file.read_int(offset+12, 4)
                    
                    #temp.write("%3d %3d %3d 0x%X %f %f (%f %f) %3d\n" % (n, k, l, offset,round(uv3[0], 6),round(self.file.read_float(offset+4, 4), 6),round(uv3[0], 6), round(uv3[1], 6), v3))
                    
                    #print v1,v2,v3
                    #fc3 += 1
                    if v1!=-1 and v2!=-1:
                        if direct>0: # original is > 0
                            faceslist.append([v1,v2,v3])
                            uvlist.append([uv1,uv2,uv3,n])
                            #uvlist.append([uv1,uv2,uv3,k])
                            faces_address.append([offset+12-64, offset+12-32,offset+12])
                            uv_address.append([[offset-64, offset - 60],[offset-32, offset - 28],[offset, offset+4]])
                        else:
                            faceslist.append([v1,v3,v2])
                            uvlist.append([uv1,uv3,uv2,n])
                            faces_address.append([offset+12-64, offset+12,offset+12-32])
                            uv_address.append([[offset-64, offset-60], [offset, offset+4] ,[offset-32, offset-28]])
                            #uvlist.append([uv1,uv3,uv2,k])
                    v1=v2
                    uv1=uv2
                    v2=v3
                    uv2=uv3
                    offset += 32
        #temp.close()
        if return_address == False:
            return faceslist, uvlist    
        else:
            return faceslist, uvlist, faces_address, uv_address

                              
    def vertexuv(self, faceslist, uvlist, uv_address=None):
        vt = []
        vt_address = []
        for m in range(len(faceslist)):
            for n in range(3):
                uv_data = uvlist[m][n]
                v_id = faceslist[m][n]
                for x in xrange(len(uv_data)):
                    uv_data[x] = round(uv_data[x], 6)
                if uv_address is not None:
                    addr = uv_address[m][n]
                if not (uv_data, v_id) in vt:
                    vt.append((uv_data, v_id))
                    if uv_address is not None:
                        vt_address.append(addr)
        #mat = uvlist[m][3]
        if uv_address is None:
            return vt
        else:
            return vt, vt_address
    
    def uvlist_get_item(self, uvlist, position):
        list_pos = position / 3
        uv_pos = position % 3
        return uvlist[list_pos][uv_pos]
        
    def get_vertex_data(self, mesh_id):
        vertex_list = []
        for x in xrange(self.n_vertices_of_mesh[mesh_id]):
            offset = 0x10
            vertex_x = self.file.read_float(self.offset_to_vertex_data[mesh_id] + offset*x, 4)
            vertex_y = self.file.read_float(self.offset_to_vertex_data[mesh_id] +
            offset*x + 0x04, 4)
            vertex_z = self.file.read_float(self.offset_to_vertex_data[mesh_id] + offset*x + 0x08, 4)
            #unused   = self.file.read_float(self.offset_to_vertex_data + offset*x + 0x0C, 4)
            vertex_list.append([vertex_x, vertex_y, vertex_z])
        return vertex_list

    def get_normal_data(self, mesh_id):
        normal_list = []
        for x in xrange(self.n_vertices_of_mesh[mesh_id]):
            offset = 0x10
            normal_x = self.file.read_float(self.offset_to_normal_data[mesh_id] + offset*x, 4)
            normal_y = self.file.read_float(self.offset_to_normal_data[mesh_id] + offset*x + 0x04, 4)
            normal_z = self.file.read_float(self.offset_to_normal_data[mesh_id] + offset*x + 0x08, 4)
            #unused   = self.file.read_float(self.offset_to_normal_data + offset*x + 0x0C, 4)
            normal_list.append([normal_x, normal_y, normal_z])
        return normal_list
        
    def extract_obj(self, mesh_id, filename=None):
        if filename is None:
            basename = os.path.basename(self.filename)
            name     = os.path.splitext(basename)[0]
            filename = "%s_obj%d.obj" % (name, mesh_id)
        with open(filename, 'w') as output:
            #output.write("mtllib %s.mtl\n" % os.path.splitext(self.filename)[0])        
            output.write("# Extract by OBJ Exporter by eatrawmeat391\n")
            output.write("# Visit Legend of Modding for more SVR tool\n")
            vertex_list = self.get_vertex_data(mesh_id)
            for x in vertex_list:
                coord_x, coord_y, coord_z = rotate_3d_x(x[0], x[1], x[2], 180) # rotate by 180 degree
                # swap y and z,multiple y by -1
                output.write("v %.6f %.6f %.6f\n" % (round(coord_x, 6) + 0.0,round(-coord_z, 6) + 0.0, round(coord_y, 6) + 0.0))
            normal_list = self.get_normal_data(mesh_id)
            for x in normal_list:
                coord_x, coord_y, coord_z = rotate_3d_x(x[0], x[1], x[2], 180) # rotate by 180 degree
                # swap y and z,multiple y by -1
                output.write("vn %.6f %.6f %.6f\n" % (round(coord_x, 6) + 0.0,round(-coord_z, 6) + 0.0, round(coord_y, 6) + 0.0))
            face_list, uv_list = self.get_indice_data(mesh_id)
            vt = self.vertexuv(face_list, uv_list)
            for x in vt:
                output.write("vt %.6f %.6f\n" % (round(x[0][0], 6) + 0.0,round(x[0][1], 6) + 0.0))
            
            for x in face_list:
                output.write("f %d %d %d\n" % (x[0]+1, x[1]+1, x[2]+1))            
        return
    
    def extract_obj2(self, filename=None):
        if filename is None:
            basename = os.path.basename(self.filename)
            name     = os.path.splitext(basename)[0]
            filename = "%s.obj" % name
        line_count = 0
        with open(filename, 'w') as output:
            output.write("# Extract by OBJ Exporter by eatrawmeat391\n")
            output.write("# Visit Legend of Modding for more SVR tool\n")    
            for mesh_id in xrange(0, self.n_mesh):
                vertex_list = self.get_vertex_data(mesh_id)
                for x in vertex_list:
                    coord_x, coord_y, coord_z = rotate_3d_x(x[0], x[1], x[2], 180) # rotate by 180 degree
                    # swap y and z,multiple y by -1
                    output.write("v %.6f %.6f %.6f\n" % (round(coord_x, 6) + 0.0,round(-coord_z, 6) + 0.0, round(coord_y, 6) + 0.0))
                normal_list = self.get_normal_data(mesh_id)
                for x in normal_list:
                    coord_x, coord_y, coord_z = rotate_3d_x(x[0], x[1], x[2], 180) # rotate by 180 degree
                    # swap y and z,multiple y by -1
                    output.write("vn %.6f %.6f %.6f\n" % (round(coord_x, 6) + 0.0,round(-coord_z, 6) + 0.0, round(coord_y, 6) + 0.0))
                face_list, uv_list = self.get_indice_data(mesh_id)
                vt = self.vertexuv(face_list, uv_list)
                for x in vt:
                    output.write("vt %.6f %.6f\n" % (round(x[0][0], 6) + 0.0,round(x[0][1], 6) + 0.0))
            
                for x in face_list:
                    output.write("f %d %d %d\n" % (x[0]+1+line_count, x[1]+1+line_count, x[2]+1+line_count))            
                line_count += len(vertex_list)
        return
  
    def inject_obj(self, mesh_id, filename):
        obj_file = OBJ(filename)
        vertex_list = obj_file.vertex
        normal_list = obj_file.normal
        face_list = obj_file.face
        vt_list = obj_file.texture_coordinate
        if len(vertex_list) != self.n_vertices_of_mesh[mesh_id] or len(normal_list) != self.n_vertices_of_mesh[mesh_id]:
            raise AssertionError, "This function only supports injecting obj with the same amount of vertices"
        for x in xrange(self.n_vertices_of_mesh[mesh_id]):
            # Reading vertex and normal
            vertex_x , vertex_y, vertex_z = rotate_3d_x(vertex_list[x][0], vertex_list[x][2], -vertex_list[x][1], -180)
            #normal_x , normal_y, normal_z = rotate_3d_x(normal_list[x][0], normal_list[x][2], -normal_list[x][1], -180)
            vertex_offset = self.offset_to_vertex_data[mesh_id] + 0x10*x
            #normal_offset = self.offset_to_normal_data[mesh_id] + 0x10*x
            # Convert vertex and normal to binary
            data_v_x, data_v_y, data_v_z = self.file.float_to_string(vertex_x, 4), self.file.float_to_string(vertex_y, 4), self.file.float_to_string(vertex_z, 4)
            #data_vn_x, data_vn_y, data_vn_z = self.file.float_to_string(normal_x, 4), self.file.float_to_string(normal_y, 4), self.file.float_to_string(normal_z, 4)
            # write vertex and normal
            self.file.write_string(vertex_offset, data_v_x), self.file.write_string(vertex_offset+4, data_v_y), self.file.write_string(vertex_offset+8, data_v_z)
            #self.file.write_string(normal_offset, data_vn_x), self.file.write_string(normal_offset+4, data_vn_y), self.file.write_string(normal_offset+8, data_vn_z)
        #faceslist, uvlist, faces_address ,uv_address = self.get_indice_data(mesh_id, True)
        #vt, vt_address = self.vertexuv(faceslist, uvlist, uv_address)
        #for x in xrange(len(vt_list)):
        #    address = vt_address[x]
        #    # Reading texture coordinate
        #    vt_x, vt_y = vt_list[x]
        #    vt_y = 1.0 - vt_y
                    
        #    # Convert texture coordinate to binary
        #    data_vt_x, data_vt_y = self.file.float_to_string(vt_x, 4), self.file.float_to_string(vt_y, 4)
        #    # Write them to file
        #    self.file.write_string(address[0], data_vt_x), self.file.write_string(address[1],data_vt_y)
        #    #
        #if len(face_list) != 0:
        #    for x in xrange(len(face_list)):
        #        address = faces_address[x]
                # Reading face 
        #        face1, face2, face3 = face_list[x]
                # Convert face to binary
        #        data_f1, data_f2, data_f3 = self.file.int_to_string(face1, 4),self.file.int_to_string(face2, 4),self.file.int_to_string(face3, 4)
                # Write them to file
        #        self.file.write_string(address[0], data_f1), self.file.write_string(address[1], data_f2), self.file.write_string(address[2], data_f3)
            
        self.file.update()            
        return
    def get_texture_list(self):
        texture = []
        for offset in xrange(self.texture_start_offset, self.texture_end_offset, 0x10):
            name =  string_shortener(self.file.read_string(offset, 0x10))
            texture.append(name)
        return texture
          
    def get_mesh_number_of_texture(self, mesh_id):
        assert mesh_id < self.n_mesh, 'Mesh ID is invalid,it cannot exceed the maximum number which is %d' % self.n_mesh
        offset = 0x48 + 0x40*mesh_id + 0x04
        return self.file.read_int(offset, 4)
        
    def get_texture_pointed(self, mesh_id):
        list = []
        assert mesh_id < self.n_mesh, 'Mesh ID is invalid,it cannot exceed the maximum number which is %d' % self.n_mesh
        model_offset = 0x48 + 0x40*mesh_id + 0x0C
        n_mesh_texture = self.get_mesh_number_of_texture(mesh_id)
        texture_pointer_offset = self.file.read_int(model_offset, 4) + 0x30
        for x in xrange(0, n_mesh_texture):
            list.append(self.file.read_int(texture_pointer_offset+0xD0*x, 4))
        return list
    
    def add_new_texture(self, new_texture_name, debug=False):
        assert 0 < len(new_texture_name) < 0x10, 'Texture Name has a size larger than 15 bytes or is empty'
        if debug == True:
            print "- Adding texture '%s'" % new_texture_name
            print "- At offset 0x%X, hex data is %X, increase 1 making it %X" % (0x20, self.n_texture, self.n_texture + 1)
        self.file.write_int(0x20, self.n_texture+1, 4)
        if debug == True:
            print "- At offset 0x%X, hex data is %X, increase 0x10 making it %X" % (0x04, self.size_entry, self.size_entry + 0x10)
        self.file.write_int(0x04, self.size_entry+0x10, 4)
        if debug == True:
            print "- At offset 0x%X, hex data is %X, increase 0x10 making it %X" % (0x0C, self.size_entry, self.size_entry + 0x10)
        self.file.write_int(0x0C, self.size_entry+0x10, 4)
        last_texture_address = self.texture_end_offset
        if debug == True:
            print "- Last address calculated,it is 0x%X" % last_texture_address
            print "- Inserting new texture name '%s' at 0x%X (the end)" % (new_texture_name, last_texture_address)
        new_texture_name = fill_string(new_texture_name, 0x10)
        self.file.insert_string(last_texture_address, new_texture_name)
        if debug == True:
            print "- Updating texture end address, which is now 0x%X - 0x08" % (self.texture_end_offset + 0x10)
        self.file.write_int(0x30, self.texture_end_offset+0x10-0x08, 4)
        if debug == True:
            print "- Refreshing the file"
        self.file.update()
        if debug == True:
            print "- Clomath.sing the file and reopening it"
        self.file.close()
        self.__init__(self.filename)
        return
    
    def remove_a_texture(self, texture_id, debug=False):
        texture_name = self.texture_list[texture_id]
        if debug == True:
            print "- Removing texture '%s', ID= %d" % (texture_name, texture_id)
            print "- At offset 0x%X, hex data is %X, decrease 1 making it %X" % (0x20, self.n_texture, self.n_texture - 1)
        self.file.write_int(0x20, self.n_texture-1, 4)
        if debug == True:
            print "- At offset 0x%X, hex data is %X, decrease 0x10 making it %X" % (0x04, self.size_entry, self.size_entry - 0x10)
        self.file.write_int(0x04, self.size_entry-0x10, 4)
        if debug == True:
            print "- At offset 0x%X, hex data is %X, decrease 0x10 making it %X" % (0x0C, self.size_entry, self.size_entry - 0x10)
        self.file.write_int(0x0C, self.size_entry-0x10, 4)
        texture_address = self.texture_start_offset + texture_id*0x10
        if debug == True:
            print "- Last address calculated,it is 0x%X" % texture_address
            print "- Deleting texture name '%s' at 0x%X " % (texture_name, texture_address)
        self.file.delete_string(texture_address, 0x10)
        if debug == True:
            print "- Updating texture end address, which is now 0x%X - 0x08" % (self.texture_end_offset - 0x10)
        self.file.write_int(0x30, self.texture_end_offset-0x10-0x08, 4)
        if debug == True:
            print "- Refreshing the file"
        self.file.update()
        if debug == True:
            print "- Clomath.sing the file and reopening it"
        self.file.close()
        self.__init__(self.filename)
        return
    
        
    def redirect_texture(self, mesh_id, texture_id, texture_point_id,debug=False):
        assert mesh_id < self.n_mesh, 'Mesh ID is invalid,it cannot exceed the maximum number which is %d' % self.n_mesh
        model_offset = 0x48 + 0x40*mesh_id + 0x0C
        list = self.get_texture_pointed(mesh_id)
        assert texture_id < len(list), 'Texture ID is invalid,it cannot exceed the maximum number which is %d' % len(list)
        assert texture_point_id < self.n_texture, 'Redirect ID is invalid, it cannot exceed the maximum number which is %d' % self.n_texture
        texture_pointer_offset = self.file.read_int(model_offset, 4) + 0x30 + 0xD0*texture_id
        if debug == True:
            print "- Model offset calculated, formula is 0x48 + 0x40*%d + 0x0C = 0x%X" % (mesh_id, model_offset)
            print "- Texture pointer offset read, it is 0x%X, go down 0x30+0xD0*%d bytes" % (self.file.read_int(model_offset, 4), texture_id)
            print "- We're at 0x%X, making it point to texture %d" % (texture_pointer_offset, texture_point_id)
        self.file.write_int(texture_pointer_offset, texture_point_id, 4)
        if debug == True:
            print "- Refreshing the file"
        self.file.update()
        if debug == True:
            print "- Clomath.sing the file and reopening it"
        self.file.close()
        self.__init__(self.filename)
        return
        
    def get_bone_data(self):
        offset = self.offset_to_bone
        bones = []
        for a in xrange(self.n_bone):
            BoneName = string_shortener(self.file.read_string(offset, 16))
            offset += 16
            tx = self.file.read_float(offset, 4)
            offset += 4
            ty = self.file.read_float(offset, 4)
            offset += 4
            tz = self.file.read_float(offset, 4)
            offset += 4
            tw = self.file.read_float(offset, 4)
            offset += 4
            rx = (self.file.read_float(offset, 4) * 180) / math.pi
            offset += 4
            ry = (self.file.read_float(offset, 4) * 180) / math.pi
            offset += 4
            rz = (self.file.read_float(offset, 4) * 180) / math.pi
            offset += 4
            rw = self.file.read_float(offset, 4)
            offset += 4
            parent = self.file.read_int(offset, 4)
            offset += 4
            offset += 0x0C
            qx = self.file.read_float(offset, 4)
            offset += 4
            qy = self.file.read_float(offset, 4)
            offset += 4
            qz = self.file.read_float(offset, 4)
            offset += 4
            qw = self.file.read_float(offset, 4)
            offset += 4
            bones.append([BoneName,parent,[tx,ty,tz],[rx,ry,rz]])
        return bones
    # The import yobj script below,it would yield 3 lists.
    # The above get_face_data and get_indice_data is a copy of those 2 functions
    # But it allows you to input a mesh id,unlike the 2 functions below which will yield from id 0 to end
    def get_mesh_data(self):   
        offset = self.offset_to_mesh_description    
        mesh_data = []
        for m in xrange(self.n_mesh):
            back = offset
            data = []
            for x in xrange(13):
                data.append(self.file.read_int(offset, 4))
                if x == 3:
                    print "Mesh %d vertex data[3] at offset 0x%X" % (m, offset)
                offset += 4
            pos = []
            for x in xrange(3):
                pos.append(self.file.read_float(offset, 4))
                offset += 4
            offset = back + 64
            mesh_data.append([data, pos])
        return mesh_data, data, pos
           
    def get_mesh_data1(self): 
        mesh_data, data, pos = self.get_mesh_data()
        for m in xrange(self.n_mesh):
            #print 'object-',m
            vertexlist = []
            faceslist = []
            uvlist = []
            data = mesh_data[m][0]
            offset = data[8] + 40
            
            for n in xrange(data[12]):
                vertex_x = self.file.read_float(offset, 4)
                vertex_y = self.file.read_float(offset+0x04, 4)
                vertex_z = self.file.read_float(offset+0x08, 4)
                vertexlist.append([vertex_x, vertex_y, vertex_z])
                offset += 16
            # HERE  
                        
            offset = data[5]+8 # 
            
            face_data = []
            for n in xrange(data[3]):
                offset += 192
                var = []
                for x in xrange(4):
                    value = self.file.read_int(offset, 4)
                    offset += 4
                    var.append(value)
                face_data.append(var)
        
            nMat = data[3]
            for n in xrange(data[3]): 
                offset = face_data[n][3] + 8
                nParts = face_data[n][1]
                for k in xrange(face_data[n][1]):#nParts
                    var = []
                    for x in xrange(32):
                        #print "%2d %.4X" % (x, offset)
                        value = self.file.read_int(offset, 1)
                        offset += 1
                        var.append(value)
                    v1 = -1
                    v2 = -1
                    uv1 = -1
                    uv2 = -1
                    direct = -1
                
                    for l in xrange(var[16]):#nFaces
                        direct*=-1
                        #mesh.verts[m].uvco = Vector(uvlist[m])
                        uv3 = [self.file.read_float(offset, 4),1-self.file.read_float(offset+4, 4)]
                        offset += 12
                        
                        v3 = self.file.read_int(offset, 4)
                        offset += 20
                        #print v1,v2,v3
                    
                        if v1!=-1 and v2!=-1:
                            if direct>0:
                                faceslist.append([v1,v2,v3])
                                uvlist.append([uv1,uv2,uv3,n])
                                #uvlist.append([uv1,uv2,uv3,k])
                            else:
                                faceslist.append([v1,v3,v2])
                                uvlist.append([uv1,uv3,uv2,n])
                                #uvlist.append([uv1,uv3,uv2,k])
                        v1=v2
                        uv1=uv2
                        v2=v3
                        uv2=uv3
            yield (vertexlist, faceslist, uvlist)
            
class PSP_YOBJ(YOBJ):
    def __init__(self, filename):
        self.filename = filename
        self.file_obj = open(filename, 'rb+')
        self.file = hex_file(self.file_obj)
        self.size_entry = self.file.read_int(0x04, 4)
        self.n_mesh = self.file.read_int(0x18, 4)
        self.n_texture = self.file.read_int(0x20, 4)
        self.texture_start_offset = self.file.read_int(0x2C, 4) + 8
        #self.texture_end_offset = self.file.read_int(0x30, 4) + 8
        self.texture_end_offset = self.texture_start_offset + 0x10*self.n_texture
        self.texture_list = self.get_texture_list()
        self.n_bone = self.file.read_int(0x1C, 4)
        self.offset_to_mesh_description = self.file.read_int(0x24, 4)
        self.offset_to_bone             = self.file.read_int(0x28, 4) + 8
        
        #self.offset_to_indice_section   = self.file.read_int(0x54, 4)
        #self.n_bone_weight_of_mesh      = self.file.read_int(0x6C, 4)
        #self.offset_to_vertex_data      = self.file.read_int(0x60, 4) + 0x28
        #self.n_vertices_of_mesh         = self.file.read_int(0x70, 4)
        #self.offset_to_normal_data      = self.offset_to_vertex_data + self.n_vertices_of_mesh*0x10 + 0x10
        self.mesh_material_number = []
        self.offset_to_indice_section = []
        self.n_bone_weight_of_mesh = []
        self.offset_to_vertex_data = []
        self.n_vertices_of_mesh = []
        self.offset_to_normal_data = []
        for x in xrange(self.n_mesh):
            self.mesh_material_number.append(self.file.read_int(self.offset_to_mesh_description+0x0C+0x40*x, 4))
            self.offset_to_indice_section.append(self.file.read_int(self.offset_to_mesh_description+0x14+0x40*x, 4))
            self.n_bone_weight_of_mesh.append(self.file.read_int(self.offset_to_mesh_description+0x2C+0x40*x, 4))
            self.offset_to_vertex_data.append(self.file.read_int(self.offset_to_mesh_description+0x24+0x40*x, 4)+ 0x28)
            self.n_vertices_of_mesh.append(self.file.read_int(self.offset_to_mesh_description+0x30+0x40*x, 4))
            self.offset_to_normal_data.append(self.offset_to_vertex_data[x] + self.n_vertices_of_mesh[x]*0x10 + 0x10)
        #self.part_in_mesh               = self.file.read_int(0x259C, 4)
        #self.indices_offset             = self.file.read_int(0x25A0, 4) + 4
        return

    def get_face_data(self, mesh_id):
        return super(PSP_YOBJ, self).get_face_data(mesh_id)
        
    def get_indice_data(self, mesh_id):
        return super(PSP_YOBJ, self).get_indice_data(mesh_id)
    
    def vertexuv(self, faceslist, uvlist):
        return super(PSP_YOBJ, self).vertexuv(faceslist, uvlist)
        
    def uvlist_get_item(self, uvlist, position):
        return super(PSP_YOBJ, self).uvlist_get_item(uvlist, position)
        
    def get_vertex_data(self, mesh_id):
        return super(PSP_YOBJ, self).get_vertex_data(mesh_id)
        
    def get_normal_data(self, mesh_id):
        return super(PSP_YOBJ, self).get_normal_data(mesh_id)
        
    def extract_obj(self, mesh_id, filename=None):
        return super(PSP_YOBJ, self).extract_obj(mesh_id, filename)