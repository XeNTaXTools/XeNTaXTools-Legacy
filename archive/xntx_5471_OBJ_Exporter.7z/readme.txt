Main File in the archive,you need python 2.7(+) and <= 3.0.you might need external module such as numpy:
- import_svr_yobj_ps2.py: This is a python script which is Glogow Poland Mariusz Szkaradek's original script
- YOBJ_Tool_GUI.py: This is the GUI version of my tool.You can run it by typing "python YOBJ_Tool_GUI.py",the tool incorrectly deals with uv data so I don't think the GUI will be of much use
- yobj.py: This is my python script which is run by the python interpreter.Start it by cd to the tool's directory,running python from a commandline,then type the following command:
- import-rumble-roses-ps2-2011-11-06.blend: The blend file to load within Blender
=====================================================
from yobj import *
a = YOBJ(filename) # filename is'02.yobj',create a new YOBJ object
a.n_mesh # print number of mesh
# I will get mesh 0 uv
faceslist, uvlist = a.get_indice_data(0) # 0 is mesh id
# you get the uvlist
for x in uvlist:
     print x # print each item of uvlist
exit() # stop a python session
=====================================================
# to write uvlist to file,after you get uvlist
temp = open('uvlist.txt', 'w')
for x in uvlist:
     temp.write(str(x))
temp.close()
=====================================================
Then load Blender and export obj of mesh or model-0 and you get the output obj which contains the vt section.