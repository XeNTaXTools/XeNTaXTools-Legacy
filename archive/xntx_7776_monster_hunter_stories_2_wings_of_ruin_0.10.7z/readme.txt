################################
#   INSTALL REQUIRED MODULES   #
# ONLY IF YOU WANT TO EXTRACT  #
# ARC FILES IN THE CORRECT WAY #
################################
Drive to your Blender folder and move "run-install.bat" into the folder with the same version you're using and run it.
ie: "C:\Blender\2.93"

##########################
# Install Blender plugin #
##########################
Go to Edit -> Preferences, click on "Add-ons" tab on the left. You'll find in the top menu "Install...". Drive to "seca_mhs2wor.zip" files and enabled it.

####################
# Convert textures #
####################
Copy "texconv.exe" inside "archive" folder from the game.


Enjoy!
Contact: https://discord.gg/cq87dwxsnv
         contact@secaproject.com
