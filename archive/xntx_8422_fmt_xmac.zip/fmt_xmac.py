#by Durik256
#original script for blender Szkaradek123
#https://forum.xentax.com/viewtopic.php?p=119943&sid=5d21dac0e63428558b3a3ca09eea3ecc#p119943
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Risen PC","._xmac")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)  
    noesis.logPopup()    
    return 1

def noepyCheckType(data):
    if data[:8] != b'GR01MA02':
        return 0
    return 1

def noepyLoadModel(data, mdlList):
    bs = NoeBitStream(data)
    magic = bs.readBytes(8)
    
    _xmacParser(bs)
    
    mdl = NoeModel(meshes)
    mdl.setBones(bones)
    mdl.setModelMaterials(NoeModelMaterials([], matList))
    mdlList.append(mdl)
    return 1
    
def _xmacParser(bs):
    bs.seek(146)
    
    if bs.readUByte():
        bs.setEndian(1)

    bs.seek(176)
    [bs.seek(bs.readInt(),1) for x in range(3)]
        
    #bones    
    w=bs.read('6I')
    global bones
    bones = []
    for i in range(w[4]):
        mat43=NoeQuat(bs.read('4f')).transpose().toMat43()
        bs.seek(16,1)
        mat43[3]=NoeVec3(bs.read('3f'))
        bs.seek(24,1)
        v=bs.read('4i')
        parentIndex = v[2]
        bs.seek(72,1)
        name=noeAsciiFromBytes(bs.readBytes(bs.readInt()))[-25:]
        bones.append(NoeBone(i,name,mat43,None,parentIndex))
        
    bones = rapi.multiplyBones(bones)
        
    #materials
    w=bs.read('6I')
    global matList
    matList=[]
    for m in range(w[3]):#material list
        mat=NoeMaterial('%i'%len(matList),'')
        bs.seek(92,1)
        chunk=bs.readInt()
        if chunk==4587520:
            readMaterial(bs, mat)
        
        elif chunk==21364736:    
            readMaterial(bs, mat, 1)
                    
        elif chunk==38141952:    
            readMaterial(bs, mat, 1, 1)
                    
        elif chunk==17922:    
            readMaterial(bs, mat, 1, 1)
        
        elif chunk==54919168:    
            readMaterial(bs, mat, 1, 1, 1)
        
        elif chunk==17923:    
            readMaterial(bs, mat, 1, 1, 1)
        else:
            print('WARNING:',chunk)
        matList.append(mat)
        
    #meshes
    for j in range(1):#lod list L1,L2 - delete break if want all lods
        w=bs.read('10I')
        count=w[4]
        vertPosList=[]
        vertUVList=[]
        skinIDList=[]
        for i in range(w[8]):
            section=bs.read('3I')
            print(section)
            for m in range(w[5]):
                ts=bs.tell()
                
                if section[0]==0:vertPosList.append(NoeVec3(bs.read('3f')))
                if section[0]==3:vertUVList.append(NoeVec3(bs.read('2f')+tuple([0])))
                if section[0]==5:skinIDList.append(bs.readInt())
                if section[0]==2:bs.seek(16,1)
                
                bs.seek(ts+section[1])
                
        vertIDStart=0
        meshList=[]
        subMeshInfoList=[]
        subMeshCount=w[7]
        for i in range(subMeshCount):
            mesh=Mesh()    
            v=bs.read('4I')
            mesh.matList.append(matList[v[2]])
            subMeshInfoList.append(v)
            mesh.indiceList=bs.read('%ii'%v[0])
            mesh.vertPosList=vertPosList[vertIDStart:vertIDStart+v[1]]
            mesh.vertUVList=vertUVList[vertIDStart:vertIDStart+v[1]]
            boneMap=bs.read('%ii'%v[3])
            vertIDStart+=v[1]
            meshList.append(mesh)
            
        w=bs.read('7I')
        listA=[]
        for i in range(w[5]):listA.append([bs.readFloat(),bs.read('4B')])
        listB=[]#skin list    
        ID=0
        for i in range(count):
            v=bs.read('2I')
            indiceList=[]
            weightList=[]
            for m in range(v[1]):
                indiceList.append(listA[ID][1][0])
                weightList.append(listA[ID][0])
                ID+=1
            listB.append(NoeVertWeight(indiceList, weightList))
        
        global meshes
        meshes = []
        
        vertIDStart=0
        for i in range(subMeshCount):
            mesh=meshList[i]
            for m in range(vertIDStart,vertIDStart+subMeshInfoList[i][1]):
                mesh.skinWeightList.append(listB[skinIDList[m]])
            vertIDStart+=subMeshInfoList[i][1]
            msh = NoeMesh(mesh.indiceList, mesh.vertPosList)
            msh.setWeights(mesh.skinWeightList)
            msh.setMaterial(mesh.matList[0].name)
            meshes.append(msh)
    
def readMaterial(bs, mat, d=0, n=0, s=0):
    mat.name = bs.readBytes(bs.readInt()).decode()
    if d:
        bs.seek(28,1)  
        mat.setTexture(bs.readBytes(bs.readInt()).decode().lower())
    if n:
        bs.seek(28,1)  
        mat.setNormalTexture(bs.readBytes(bs.readInt()).decode().lower())
    if s:
        bs.seek(28,1)  
        mat.setSpecularTexture(bs.readBytes(bs.readInt()).decode().lower())
        
class Mesh:
    def __init__(self):
        self.matList = []
        self.skinWeightList = []
        