from algebra import *

# -----------------------------------------------------------------------------

# Wrappers for type conversion from bytes.

def decodeINT(func) -> int:
  def wrap(*args, **kwargs): 
    return int.from_bytes(func(*args, **kwargs), byteorder='little')
  return wrap 

def decodeFLOAT(func) -> float:
  def wrap(*args, **kwargs):
    val = unpack('f', func(*args, **kwargs)) 
    return float(val[0])
  return wrap 

def decodeHALF(func):
  def wrap(*args, **kwargs):
    h = unpack('<H', func(*args, **kwargs))[0]
    return DecompressFloat16(h)
  return wrap 

#------------------------------------------------------------------------------

# Helpers to extract specific datatype from a bytestream.

def getBytes(_data, idx, bytesize):
  return _data[idx:idx + bytesize]

def getSTR(_data, idx) -> str:
  return getBytes(_data, idx, kStringBytesize).decode('ascii').replace('\x00', '')

@decodeINT
def getU8(_data, idx) -> int:
  return getBytes(_data, idx, 1)

@decodeINT
def getU16(_data, idx, off=0) -> int:
  return getBytes(_data, idx + 2*off, 2)

@decodeINT
def getU32(_data, idx, off=0) -> int:
  return getBytes(_data, idx + 4*off, 4)

@decodeHALF
def getF16(_data, idx, off=0) -> float:
  return getBytes(_data, idx + 2*off, 2)
  
@decodeFLOAT
def getF32(_data, idx, off=0) -> float:
  return getBytes(_data, idx + 4*off, 4)

def getShort3(_data, idx) -> (int, int, int):
  x = getU16(_data, idx, 0)
  y = getU16(_data, idx, 1)
  z = getU16(_data, idx, 2)
  return (x, y, z)

def getInt3(_data, idx) -> (int, int, int):
  x = getU32(_data, idx, 0)
  y = getU32(_data, idx, 1)
  z = getU32(_data, idx, 2)
  return (x, y, z)

def getHalf3(_data, idx) -> Vec3:
  x = getF16(_data, idx, 0)
  y = getF16(_data, idx, 1)
  z = getF16(_data, idx, 2)
  return Vec3(x, y, z)

def getNormU8(_data, idx) -> float:
  return getU8(_data, idx) / float(0xff)

def getVec3(_data, idx) -> Vec3:
  x = getF32(_data, idx, 0)
  y = getF32(_data, idx, 1)
  z = getF32(_data, idx, 2)
  return Vec3(x, y, z)

# -----------------------------------------------------------------------------

kFilenames = [
#  'omikron_data/OBJETS/ANNEAU.3DO',
#  'omikron_data/OBJETS/WIKI.3DO',

#  'omikron_data/MISC/MOTO.3DO',

#  'omikron_data/PERSOS/VTL_FN.3DO',
  'omikron_data/PERSOS/KAI_FN.3DO',
#  'omikron_data/PERSOS/JEN_FNM.3DO',
#  'omikron_data/PERSOS/AST_FNM.3DO',
#  'omikron_data/PERSOS/BOZ_FNM.3DO',
]

# --- Header info addresses.

kNumFacesAddr: int    = 0x0E8
kNumVerticesAddr: int = 0x0F0
kNumTexturesAddr: int = 0x0FC
kNumCamerasAddr: int  = 0x108
kNumGroupsAddr: int   = 0x10C

kNumUnknownAddresses: [int] = [
  0x100, 
  0x114, 
  0x118
]

# --- Data offsets. 

kDataStartAddr: int   = 0x174
kStringBytesize: int  = 20
kTextureInfoSize: int = 4 * kStringBytesize

kPositionOffset: int  = 0x00
kNormalOffset: int    = 0x0C

kPositionStride: int  = 32
kNormalStride: int    = 32

kIndicesStride: int   = 28

# --- Datablocks bytesize. 

kEndCameraBlockSize: int = 52
kEndGroupBlockSize: int  = 140

# -----------------------------------------------------------------------------

def check_normals(normals: [Vec3]) -> bool:
  """ 
    Return True if all normals unit length are 1..
    or mostly 1 and sometimes 0.
  """

  isNull = lambda l: isClose(l, 0.0)
  isUnit = lambda l: isClose(l, 1.0)
  
  normalLengths = [ n.length2() for n in normals ]
  areNulls      = [ isNull(l) for l in normalLengths ]
  areUniforms   = ( isNull(l) or isUnit(l) for l in normalLengths )

  if all(areNulls):
    return False

  if any(areNulls):
    print(" * Some normals are nulls.")

  return all(areUniforms)


def compute_pivot(positions: [Vec3]) -> Vec3:
  return Vec3.SumReduce(positions) / len(positions)

# -----------------------------------------------------------------------------

def extract(_filename, _data):
  vertices: [Vec3] = []
  normals: [Vec3]  = []
  textureInfos: [(str, str, str)] = []

  # ----------------------------------------------

  # - Header data -
  nfaces: int    = getU32(_data, kNumFacesAddr)
  nvertices: int = getU32(_data, kNumVerticesAddr)
  ntextures: int = getU32(_data, kNumTexturesAddr)
  ncameras: int  = getU32(_data, kNumCamerasAddr)
  ngroups: int   = getU32(_data, kNumGroupsAddr)

  nunknowns: [int] = [getU32(_data, addr) for addr in kNumUnknownAddresses]

  vertices_offset: int  = kDataStartAddr + ntextures * kTextureInfoSize
  indices_offset: int   = vertices_offset + nvertices * kPositionStride
  groupinfo_offset: int = indices_offset + nfaces * kIndicesStride

  print("\nHeader")
  print(" * nvertices : %d" % nvertices)
  print(" * nfaces : %d" % nfaces)
  print(" * ntextures : %d" % ntextures)
  print(" * ncameras : %d" % ncameras)
  print(" * ngroups : %d" % ngroups)

  for i in range(len(nunknowns)):
    print(" * unknown %d : %d" % (i, nunknowns[i]))

  # - Textures Info -
  for i in range(ntextures):
    addr: int = kDataStartAddr + i * kTextureInfoSize
    idname  = getSTR(_data, addr + kStringBytesize * 0)
    tex0    = getSTR(_data, addr + kStringBytesize * 1)
    tex1    = getSTR(_data, addr + kStringBytesize * 2)
    textureInfos.append( (idname, tex0, tex1) )
  
  print("\nTextures infos :")
  for i in range(len(textureInfos)):
    td = textureInfos[i]
    print("  %d : %s\t\t%s\t%s" % (i, td[0], td[1], td[2]))  


  # - Vertex Positions -
  position_offset: int = vertices_offset + kPositionOffset
  vertices = [getVec3(_data, position_offset + i * kPositionStride) for i in range(nvertices)]

  # print("\nVertex positions :")
  # print(" * start address : 0x%X (%d)" % (position_offset, position_offset))
  # print(" * Position 0 : %s" % vertices[0])


  # - Vertex Normals -
  normals_offset: int = vertices_offset + kNormalOffset
  normals = [getVec3(_data, normals_offset + i * kNormalStride) for i in range(nvertices)]

  # print("\nVertex normals :")
  # print(" * start address : 0x%X (%d)" % (normals_offset, normals_offset))
  # print(" * Normal 0 : %s" % normals[0])
  # for n in normals:
  #   print( "%s -> %f" % (str(n), n.length2()))


  # - Faces -
  faces = []
  for faceId in range(nfaces):
    offset = indices_offset + faceId * kIndicesStride

    indices     = getShort3(_data, offset)
    texcoords   = tuple(getNormU8(_data, offset + 6 + i) for i in range(6))
    face_normal = getVec3(_data, offset + 16)

    # ( Some face indices has an extra byte set to 0x80 or 0xff for mysterious reasons)
    masks      = tuple((i >> 8) for i in indices)
    m0, m1, m2 = tuple((m == 0x80) or (m == 0xff) for m in masks)
    flag       = int(m2) << 2 | int(m1) << 1 | int(m0)

    # clear the flags when stored.
    indices = tuple(i & 0x7fff for i in indices)

    faces.append( (indices, flag, texcoords, face_normal) )

  # print("\nFaces :")
  # print(" * start address : 0x%X (%d)" % (indices_offset, indices_offset))
  # print(" * Index 0 : %d" % getU16(_data, indices_offset))
  # print('')
  # # (Debug display)
  # flagsCount = [0] * 8
  # addr = indices_offset
  # for faceId in range(len(faces)):
  #   face = faces[faceId]

  #   indices_str = '( %3d, %3d, %3d)' % face[0]
  #   flag_str = str(face[1]) if face[1] else ''

  #   print( "(0x%05X) %3d   %s\t%s" % (addr, faceId, indices_str, flag_str) )
  #   addr += kIndicesStride
  # print('')
  # print("total faces : %d (%d)" % (totalFaces, nfaces))
  # print(flagsCount)


  # - Geometry groups -
  geometries = []
  totv, totf = 0, 0
  for i in range(ngroups):
    offset = groupinfo_offset + i * kEndGroupBlockSize

    n0 = getU8(_data, offset+0)
    n1 = getU8(_data, offset+1)
    n2 = getU16(_data, offset+2)   # is symmetric ?
    n3 = getU32(_data, offset+8)
    nn = (n0, n1, n2, n3)
    stuff0 = getU32(_data, offset+60)  # 'material' id ? num of vertices ?
    

    name            = getSTR(_data, offset+16)
    start_vertex_id = totv
    start_face_id   = totf
    num_vertices    = getU32(_data, offset+64)
    num_faces       = getU32(_data, offset+68)
    bbox            = [ getVec3(_data, offset + 76 + 12 * i) for i in range(4) ] # ?

    totv += num_vertices
    totf += num_faces

    group_verts = vertices[start_vertex_id : totv]
    group_faces = faces[start_face_id : totf]

    geometries.append( (name, group_verts, group_faces, bbox) )

    print('  * %02d | %s (%d)' % (i, name, stuff0))
    print('\t%d v  %d f' % (num_vertices, num_faces))
    print('\t%s' % str(nn))
    print('\t%s' % ', '.join(str(b) for b in bbox))

    addr = indices_offset
    for faceId in range(len(group_faces)):
      face = group_faces[faceId]

      indices_str = '( %3d, %3d, %3d)' % face[0]
      flag_str = str(face[1]) if face[1] else ''

      print( "(0x%05X) %3d   %s\t%s" % (addr, faceId, indices_str, flag_str) )
      addr += kIndicesStride
    
    print('')
  # print(totv, totf)


  # - Export to Wavefront OBJ -
  offset = 1
  objname = '%s.obj' % _filename
  with open(objname, 'wt') as fd:

    fd.write('o %s\n\n' % _filename)

    for geo in geometries:
      name  = geo[0]
      verts = geo[1]
      faces = geo[2]

      fd.write('g %s\n\n' % name)

      for v in verts:
        fd.write('v %.2f %.2f %.2f\n' % (-v.x, -v.y, v.z))
      fd.write('\n')

      for tri in faces:
        fd.write('f %d %d %d\n' % tuple(offset + i for i in tri[0]))
      fd.write('\n')

      offset += len(verts)
      fd.write('# --------------------------\n')


  # -- Check datas
  print("\nCheck _data :")
  print(" * Pivot     : %s" % compute_pivot(vertices))
  print(" * Bounds    : %s - %s" % (Vec3.MinReduce(vertices), Vec3.MaxReduce(vertices)))
  print(" * Normals are %suniforms." % ( "" if check_normals(normals) else "non "))


# -----------------------------------------------------------------------------

if __name__ == '__main__':
  import os

  for fn in kFilenames :
    with open(fn, 'rb') as fd:
      simplename = os.path.splitext(os.path.basename(fn))[0]

      print('::: %s' % fn)
      extract(simplename, fd.read())
      print("- - - - - - - - - - - - - - - - -")

# -----------------------------------------------------------------------------
