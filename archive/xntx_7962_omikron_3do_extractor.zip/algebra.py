import math
import functools

from struct import pack, unpack, calcsize
from typing import TypeVar, Generic

#------------------------------------------------------------------------------

# Loose floating pointing equality check.
isClose = lambda l, x: math.isclose(l, x, rel_tol=1e-04)

# Floating point precision to be display by strings.
kStringFloatEpsilon: int = 2

#------------------------------------------------------------------------------

TVector = TypeVar('TVector')
class Vec3(Generic[TVector]):
  x: float
  y: float
  z: float

  # -----------------------------------------

  def __init__(self, x: float, y: float, z: float) -> None:
    self.x = x
    self.y = y
    self.z = z

  @classmethod
  def create(self, x: float):
    return Vec3(x, x, x)

  @classmethod
  def zeros(self):
    return Vec3.create(0.0)

  @classmethod
  def inf(self):
    return Vec3.create(float('inf'))

  # -----------------------------------------

  @staticmethod
  def SumReduce(vbuffer: [TVector]) -> TVector:
    return functools.reduce(Vec3.__add__, vbuffer, Vec3.zeros())

  @staticmethod
  def MinReduce(vbuffer: [TVector]) -> TVector:
    return functools.reduce(min, vbuffer, Vec3.inf())

  @staticmethod
  def MaxReduce(vbuffer: [TVector]) -> TVector:
    return functools.reduce(max, vbuffer, -Vec3.inf())

  # -----------------------------------------

  def cross(self, v) -> TVector:
    return Vec3( self.x * v.y - self.y * v.x,\
                 self.y * v.z - self.z * v.y,\
                 self.z * v.x - self.x * v.z )

  def dot(self, v: TVector) -> float:
    return self.x * v.x + \
           self.y * v.y + \
           self.z * v.z

  def length2(self) -> float:
    return self.dot(self)

  def length(self) -> float:
    return math.sqrt(self.length2())

  def normalize(self) -> TVector:
    return self / self.length();

  def dump(self):
    return pack(self.mFormat, self.x, self.y, self.z)

  def _key(self):
    return (self.__class__.__name__, self.x, self.y, self.z)

  # -----------------------------------------

  def __lt__(self, v: TVector):
    return (self.x < v.x) \
        or ((isClose(self.x, v.x) and (self.y < v.y))) \
        or ((isClose(self.x, v.x) and (isClose(self.y, v.y) and (self.z < v.z))))

  def __neg__(self) -> TVector:
    return Vec3(-self.x, - self.y, - self.z)

  def __add__(self, v: TVector) -> TVector:
    return Vec3(self.x + v.x, self.y + v.y, self.z + v.z)

  def __sub__(self, v: TVector) -> TVector:
    return Vec3(self.x - v.x, self.y - v.y, self.z - v.z)

  def __mul__(self, k: float) -> TVector:
    return Vec3(self.x * k, self.y * k, self.z * k)

  def __truediv__(self, k: float) -> TVector:
    return Vec3(self.x / k, self.y / k, self.z / k)

  def __hash__(self) -> str:
    return hash(self._key())

  def __eq__(self, v) -> bool:
    if not hasattr(v, "_key"):
      return False
    return self._key() == v._key()

  def __cmp__(self, v) -> bool:
    return cmp(self.x, v.x) or\
           cmp(self.x, v.y) or\
           cmp(self.x, v.z)

  def __str__(self) -> str:
    fmt = ", ".join(["%%0.%df" % kStringFloatEpsilon] * 3)
    return "(%s)" % (fmt % (self.x, self.y, self.z)) 


#------------------------------------------------------------------------------

def DecompressFloat16(h) -> float:
  # from https://davidejones.com/blog/python-precision-floating-point/

  s = int((h >> 15) & 0x0001)    # sign
  e = int((h >> 10) & 0x001f)    # exponent
  f = int(h & 0x03ff)            # fraction

  if e == 0:
    if f == 0:
      return int(s << 31)
    else:
      while not (f & 0x00000400):
        f = f << 1
        e -= 1
      e += 1
      f &= ~0x00000400
      #print(s,e,f)
  elif e == 31:
    if f == 0:
      return int((s << 31) | 0x7f800000)
    else:
      return int((s << 31) | 0x7f800000 | (f << 13))

  e = e + (127 -15)
  f = f << 13
  
  inthalf = int((s << 31) | (e << 23) | f)

  return unpack('f', pack('I', inthalf))[0]

#------------------------------------------------------------------------------


# def short3ToUFLOAT(t):
#   s = 1.0 / (2**16)
#   x = t[0] * s
#   y = t[1] * s
#   z = t[2] * s
#   return '(%.2f, %2f, %2f)' % (x, y, z)
