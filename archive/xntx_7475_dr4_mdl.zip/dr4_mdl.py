# ================================================================================
# Dead Rising 4  .mdl script
# Noesis script by Dave, 2021
# ================================================================================


from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Dead Rising 4",".mdl")
	noesis.setHandlerTypeCheck(handle, CheckType)
	noesis.setHandlerLoadModel(handle, LoadModel)
	return 1

def CheckType(data):
	return 1


# ================================================================================
# Read the model data
# ================================================================================

def LoadModel(data, mdlList):
	bs = NoeBitStream(data)
	ctx = rapi.rpgCreateContext()

	bs.seek(0x24)
	face_size = bs.readUInt()
	face_start = bs.readUInt()
	bs.seek(face_start)
	faces = bs.readBytes(face_size)
	face_count = int(face_size/2)

	bs.seek(0x40)
	vert_size = bs.readUInt()
	vert_start = bs.readUInt()
	bs.seek(vert_start)
	vertices = bs.readBytes(vert_size)

	rapi.rpgBindPositionBuffer(vertices, noesis.RPGEODATA_FLOAT, 0x28)
	rapi.rpgBindNormalBufferOfs(vertices, noesis.RPGEODATA_SHORT, 0x28, 0x18)
	rapi.rpgBindUV1BufferOfs(vertices, noesis.RPGEODATA_SHORT, 0x28, 0x0c)
	rapi.rpgCommitTriangles(faces, noesis.RPGEODATA_USHORT, face_count, noesis.RPGEO_TRIANGLE, 1)

	mdl = rapi.rpgConstructModel()
	mdlList.append(mdl)

	return 1


