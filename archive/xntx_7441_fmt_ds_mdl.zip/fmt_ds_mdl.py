# Unknown game .mdl mesh viewer
# Noesis script by Dave, 2020

from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Unknown Game",".mdl")
	noesis.setHandlerTypeCheck(handle, bcCheckType)
	noesis.setHandlerLoadModel(handle, bcLoadModel)
	return 1

# Check file type

def bcCheckType(data):
	return 1

# Read the model data

def bcLoadModel(data, mdlList):
	bs = NoeBitStream(data)
	ctx = rapi.rpgCreateContext()

	curr_folder = rapi.getDirForFilePath(rapi.getInputName()).lower()
	curr_file = rapi.getLocalFileName(rapi.getInputName()).lower()

	total_parts = bs.readUShort()
	sub_meshes = int(total_parts / 3)

# Read names + load textures

#	bone_names = []

	name_table = (total_parts * 0x88) + 0x44

	bs.seek(name_table)
	name_count = bs.readUInt()
	names_size = bs.readUInt()

	mat_list, tex_list = LoadTextures(bs, name_table, name_count, curr_folder)


# Read mesh data

	mesh_header = name_table + names_size + 8
	table1 = mesh_header + 0x38

	bs.seek(mesh_header)
	junk = bs.readBytes(0x0a)
	mat_count = bs.readUShort()
	bone_count = bs.readUShort()
	junk = bs.readUShort()
	shp_count = bs.readUShort()
	junk = bs.readBytes(6)
	table1_count = bs.readUShort()

	lod_info = table1 + (table1_count * 0x20)					# skip unknown table, only exists in some files
	parts_info = lod_info + (3 * 0x3c)					# assume 3 LOD versions (** not always the case **)

	bs.seek(lod_info + 0x34)						# LOD info - use highest detail mesh
	mesh1_verts = bs.readUInt()
	mesh1_faces = bs.readUInt()

#	print(hex(mesh1_verts), hex(mesh1_faces))

	for a in range(sub_meshes):						# process each part of the LOD0 mesh
		bs.seek(parts_info + (a*0x24))
		vert_count = bs.readUInt()
		face_count = bs.readUInt()
		mat_num = bs.readUShort()
		junk = bs.readBytes(6)
		face_start = (bs.readUInt() * 2) + mesh1_faces
		vert_start = bs.readUInt() + mesh1_verts
		uv_start = bs.readUInt() + mesh1_verts
		junk = bs.readUInt()
		vertex_stride = bs.readUByte()
		uv_stride = bs.readUByte()

#		print(vertex_stride, uv_stride, hex(uv_start))

		rapi.rpgClearBufferBinds()
		rapi.rpgSetName("Mesh_" + str(a))
		rapi.rpgSetMaterial("Mat_" + str(mat_num))

		vertices = bytes()
		uvs = bytes()
		normals = bytes()
		weights = bytes()
		bone_idx = bytes()

		bs.seek(vert_start)

		if vertex_stride == 8:
			for v in range(vert_count):
				vx = bs.readHalfFloat()
				vy = bs.readHalfFloat()
				vz = bs.readHalfFloat()
				junk = bs.readBytes(2)
				vertices += noePack("fff", vx, vy, vz)

		if vertex_stride == 20:
			for v in range(vert_count):
				vx = bs.readFloat()
				vy = bs.readFloat()
				vz = bs.readFloat()
				w1 = bs.readUByte() / 255
				w2 = bs.readUByte() / 255
				w3 = bs.readUByte() / 255
				w4 = bs.readUByte() / 255
				bidx1 = bs.readUByte()
				bidx2 = bs.readUByte()
				bidx3 = bs.readUByte()
				bidx4 = bs.readUByte()
				vertices += noePack("fff", vx, vy, vz)
				weights += noePack("ffff", w1, w2, w3, w4)
				bone_idx += noePack("HHHH", bidx1, bidx2, bidx3, bidx4)

		if vertex_stride == 16:
			for v in range(vert_count):
				vx = bs.readHalfFloat()
				vy = bs.readHalfFloat()
				vz = bs.readHalfFloat()
				junk = bs.readBytes(2)
				w1 = bs.readUByte() / 255
				w2 = bs.readUByte() / 255
				w3 = bs.readUByte() / 255
				w4 = bs.readUByte() / 255
				bidx1 = bs.readUByte()
				bidx2 = bs.readUByte()
				bidx3 = bs.readUByte()
				bidx4 = bs.readUByte()
				vertices += noePack("fff", vx, vy, vz)
				weights += noePack("ffff", w1, w2, w3, w4)
				bone_idx += noePack("HHHH", bidx1, bidx2, bidx3, bidx4)

		bs.seek(face_start)
		faces = bs.readBytes(face_count * 2)

		bs.seek(uv_start)

		if uv_stride == 16:
			for u in range(vert_count):
				nx = bs.readHalfFloat()
				ny = bs.readHalfFloat()
				nz = bs.readHalfFloat()
				junk = bs.readBytes(6)
				uvx = bs.readHalfFloat()
				uvy = bs.readHalfFloat()
				uvs += noePack("ff", uvx, uvy)
				normals += noePack("fff", nx, ny, nz)

		if uv_stride == 24:
			for u in range(vert_count):
				nx = bs.readHalfFloat()
				ny = bs.readHalfFloat()
				nz = bs.readHalfFloat()
				junk = bs.readBytes(10)
				uvx = bs.readHalfFloat()
				uvy = bs.readHalfFloat()
				junk = bs.readBytes(4)
				uvs += noePack("ff", uvx, uvy)
				normals += noePack("fff", nx, ny, nz)


		rapi.rpgBindPositionBuffer(vertices, noesis.RPGEODATA_FLOAT, 12)
		rapi.rpgBindUV1Buffer(uvs, noesis.RPGEODATA_FLOAT, 8)
		rapi.rpgBindNormalBuffer(normals, noesis.RPGEODATA_FLOAT, 12)
		rapi.rpgCommitTriangles(faces, noesis.RPGEODATA_USHORT, face_count, noesis.RPGEO_TRIANGLE, 1)


# Draw everything

	mdl = rapi.rpgConstructModel()
	mdl.setModelMaterials(NoeModelMaterials(tex_list, mat_list))
	mdlList.append(mdl)

	return 1



# Load textures and create materials

def LoadTextures(bs, name_table, name_count, curr_folder):

	mat_list = []
	tex_list = []

	mat_count = 0

	bs.seek(name_table + 8)

	for x in range(name_count):
		name1 = bs.readString()

		split_pos = name1.rfind("/")
		name1 = name1[split_pos+1:]


		if ".mtrl" in name1:
			material = NoeMaterial("Mat_" + str(mat_count), "")
			mat_count += 1

			if rapi.checkFileExists(curr_folder + name1) == 0:
				print(name1, " material file doesn't exist")
				return mat_list, tex_list

			print("Loading material file: ", name1)

			matf = open(curr_folder + name1, "rb")
			matf2 = NoeBitStream(matf.read())
			matf.close()
			matf2.seek(0x0c)
			entry_count = matf2.readUByte() + matf2.readUByte() + matf2.readUByte()
			dds_list = []

			matf2.seek(0x10)

			for z in range(entry_count):
				dds_list.append(matf2.readUInt() & 0xFFFF)

			dds_offset = (entry_count * 4) + 0x10

			for tx in dds_list:
				matf2.seek(tx + dds_offset)
				tex_name = matf2.readString()
				split_pos = tex_name.rfind("/")
				tex_name = tex_name[split_pos+1:]

				if ".tex" in tex_name:
					if rapi.checkFileExists(curr_folder + tex_name) != 0:
#						print("Loading texture file: ", tex_name)
						tex_f = open(curr_folder + tex_name, "rb")
						texture = NoeBitStream(tex_f.read())
						tex_f.close()
						texture.seek(0x4)
						tex_type = texture.readUInt()
						width = texture.readUShort()
						height = texture.readUShort()
						texture.seek(0x20)
						tex_size = texture.readUInt() - 0x50
						texture.seek(0x50)
						raw_tex = texture.readBytes(tex_size)

						if tex_type == 0x3420:
							rgba_tex = rapi.imageDecodeDXT(raw_tex, width, height, noesis.NOESISTEX_DXT1)

						if tex_type == 0x3431:
							rgba_tex = rapi.imageDecodeDXT(raw_tex, width, height, noesis.NOESISTEX_DXT3)

						if tex_type == 0x1450:
							rgba_tex = raw_tex

						if "_n.tex" in tex_name:
							rgba_tex = rapi.imageNormalMapFromHeightMap(rgba_tex, width, height, 0.25, 1)

						tex1 = NoeTexture(tex_name, width, height, rgba_tex, noesis.NOESISTEX_RGBA32)
						tex_list.append(tex1)

						if "_d.tex" in tex_name:
							material.setTexture(tex_name)

						if "_s.tex" in tex_name:
							material.setSpecularTexture(tex_name)

						if "_n.tex" in tex_name:
							material.setNormalTexture(tex_name)

					else:
						print(tex_name, " texture file doesn't exist.")

			mat_list.append(material)

	return mat_list, tex_list

