import os
import struct
import sys


def skipPad(f, blockSize, force):
	if force or (f.tell() % blockSize != 0):
		pad = blockSize - (f.tell() % blockSize)
		f.read(pad)
		
def readString(f):
	out = ""
	while True:
		c = f.read(1)
		if len(c) == 0: break
		if c == b"\x00":
			if len(out) == 0: continue
			else: break
		out = out + c.decode("ascii")
	return out

def readPointer(f):
	return struct.unpack( "Q", f.read(8) )[0]

def readInt(f):
	return struct.unpack( "I", f.read(4) )[0]

def readShort(f):
	return struct.unpack( "H", f.read(2) )[0]

def readFloat(f):
	return struct.unpack( "f", f.read(4) )[0]

def readByte(f):
	return struct.unpack( "B", f.read(1) )[0]



class Cpeg:
    class TextureDefinition:
        def __init__(self, f):
            self.dataOffset = readPointer(f)
            self.width = readShort(f)
            self.height = readShort(f)
            self.format = readShort(f)
            if self.format not in [400, 402, 407, 411, 413]:
                print( "{0} unknown format: {1}".format(f.name, self.format) )
                raise Exception("Unsupported format.")
            f.read(8)
            self.flags = readShort(f)
            f.read(11)
            self.numMipLevels = readByte(f)
            self.dataSize = readInt(f)
            f.read(32)
            self.name = ""

    def getDdsFlags(self, tex):
        flags = 0b00000000000010100001000000000111
        if tex.format == 407:
            flags = flags | (1 << 3)        # pitch
            flags = flags & ~(1 << 19)      # linear size
        if tex.format == 413:
            flags = flags & ~(1 << 0)       # caps
            flags = flags & ~(1 << 12)      # pixel format
            flags = flags & ~(1 << 19)      # linear size
            if tex.numMipLevels == 1:
                flags = flags & ~(1 << 17)  # mipmap
        return flags

    def getCapsFlags(self, tex):
        flags = 0b00000000000000000000000000000000
        flags = flags | (1 << 12)           # texture
        if tex.numMipLevels > 1:
            flags = flags | (1 << 22)       # mipmap
        if tex.format != 413:
            flags = flags | (1 << 3)        # complex
        return flags

    def getFormatFlags(self, tex):
        flags = 0b00000000000000000000000000000000
        if tex.format != 407:
            flags = flags | (1 << 2)        # fourCC
        else:
            flags = flags | (1 << 0)        # alpha pixels
            flags = flags | (1 << 6)        # rgb
        return flags

    def writeDdsHeader(self, w, tex):
        print(tex.name)
        # 407 = ARGB8888, 411 = BC5, 413 = BC7
        fourcc = { 400: b"DXT1", 402: b"DXT5", 407 : b"\x00\x00\x00\x00", 411: b"ATI2", 413: b"DX10" }
        w.write(b"DDS ")
        w.write( struct.pack("I", 124) )
        w.write( struct.pack( "I", self.getDdsFlags(tex) ) )
        w.write( struct.pack("I", tex.height) )
        w.write( struct.pack("I", tex.width) )

        pitch = 0
        if tex.format in [407, 413]: 
            pitch = tex.width * 4
        else:
            pitch = ( (tex.width + 3) // 4 ) * ( (tex.height + 3) // 4 ) * 8
            if tex.format > 400: pitch *= 2
        w.write( struct.pack("I", pitch) )

        if tex.format == 407:
            w.write( struct.pack("I", 0) )
        else:
            w.write( struct.pack("I", 1) )
        
        w.write( struct.pack("I", tex.numMipLevels) )
        w.write(b"\x00" * 44)
        w.write( struct.pack("I", 32) )
        w.write( struct.pack( "I", self.getFormatFlags(tex) ) )
        w.write(fourcc[tex.format])

        if tex.format == 407:
            w.write( struct.pack("I", 32) )
        elif tex.format == 411:
            w.write( struct.pack("I", 1498952257) )
        else:
            w.write( struct.pack("I", 0) )
        
        if tex.format == 407:
            w.write( b"\x00\x00\xFF\x00" )
            w.write( b"\x00\xFF\x00\x00" )
            w.write( b"\xFF\x00\x00\x00" )
            w.write( b"\x00\x00\x00\xFF" )
        else:
            w.write(b"\x00" * 16)
        
        w.write( struct.pack( "I", self.getCapsFlags(tex) ) )
        w.write(b"\x00" * 16)
        if tex.format == 413:
            w.write( struct.pack("I", 98) )
            w.write( struct.pack("I", 3) )
            w.write( struct.pack("I", 0) )
            w.write( struct.pack("I", 1) )
            w.write( struct.pack("I", 0) )

    def extract(self):
        if self.fileName.endswith(".cpeg_pc"):
            filePath = os.path.join( self.dir, self.fileName.replace(".cpeg_pc", ".gpeg_pc") )
        else:
            filePath = os.path.join( self.dir, self.fileName.replace(".cvbm_pc", ".gvbm_pc") )
        if not os.path.exists(filePath):
            raise Exception(filePath.split("\\")[-1] + " not found.")
        r = open(filePath, "rb")
        for t in self.td:
            w = open(os.path.join(self.dir, t.name) + ".dds", "wb")
            r.seek(t.dataOffset)
            self.writeDdsHeader(w, t)
            w.write( r.read(t.dataSize) )
            w.close()
        r.close()

    def __init__(self, filePath):
        self.dir = os.path.dirname(filePath)
        self.fileName = filePath.split("\\")[-1]
        f = open(filePath, "rb")
        f.read(16)
        self.numTextures = readShort(f)
        f.read(2)
        self.numDefs = readShort(f)
        f.read(2)
        self.td = [ self.TextureDefinition(f) for i in range(self.numTextures) ]
        names = [ readString(f) for i in range(self.numTextures) ]
        for i in range(self.numTextures):
            self.td[i].name = names[i]
        f.close()


def batchExtract(fileDir, level=1):
    listDir = os.listdir(fileDir)
    subDirs = [ d for d in listDir if os.path.isdir( os.path.join(fileDir, d) ) ]
    cpegs = [ os.path.join(fileDir, f) for f in listDir if ( f.endswith(".cpeg_pc") or f.endswith(".cvbm_pc") ) ]
    for c in cpegs:
        cpg = Cpeg( os.path.join(fileDir, c) )
        cpg.extract()
    if level > 0:
        for d in subDirs:
            batchExtract( os.path.join(fileDir, d), level-1 )


fileDir = os.path.dirname( os.path.realpath(__file__) )

if (len(sys.argv) < 2):
    batchExtract(fileDir)
else:
    if not ( sys.argv[1].endswith(".cpeg_pc") or sys.argv[1].endswith(".cvbm_pc") ):
        raise Exception("Not a PEG file.")
    cpg = Cpeg( os.path.join(fileDir, sys.argv[1]) )
    cpg.extract()

