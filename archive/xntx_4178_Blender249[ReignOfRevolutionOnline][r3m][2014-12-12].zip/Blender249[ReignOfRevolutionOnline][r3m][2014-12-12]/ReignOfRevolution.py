import newGameLib
reload(newGameLib)
from newGameLib import *
import Blender

	
	
def r3mParser(filename,g):
	A=g.i(3)
	g.seek(565)
	B=g.i(10)	
	g.seek(1024)
	texDir=filename.split('model'+os.sep)[0]+'texture'
	texList=[]
	for m in range(A[0]):#tex count
		t=g.tell()
		texList.append(texDir+os.sep+g.find('\x00'))
		g.seek(t+256)
	C=g.i(4)
	mesh=Mesh()
	for m in range(C[1]):
		mat=Mat()
		mat.diffuse=texList[m]
		mat.info=g.i(4)
		mesh.matList.append(mat)
	
	vertPosList=[]
	vertUVList=[]
	for m in range(C[2]):vertPosList.append(g.f(3))
	for m in range(C[2]):g.f(3)
	for m in range(C[2]):vertUVList.append(g.f(2))
	for m in range(C[2]):#uv for lightmap, blender don't support 2 uvlayers
		g.f(2)
	for m in range(C[2]):g.f(3)
	for m in range(C[2]):g.f(3)	
	indiceList=g.H(C[3])
	for mat in mesh.matList:
		mesh=Mesh()
		mat.TRIANGLE=True
		mesh.vertPosList=vertPosList[mat.info[2]:mat.info[2]+mat.info[0]]
		mesh.vertUVList=vertUVList[mat.info[2]:mat.info[2]+mat.info[0]]
		mesh.indiceList=indiceList[mat.info[3]:mat.info[3]+mat.info[1]]
		mesh.matList.append(mat)
		mesh.draw()	
	
def Parser():	
	filename=input.filename
	ext=filename.split('.')[-1].lower()	
	
			
	
	if ext=='r3m':
		file=open(filename,'rb')
		g=BinaryReader(file)			
		r3mParser(filename,g)
		file.close()
 
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
	
Blender.Window.FileSelector(openFile,'import','r3m - Reign of Revolution static meshes') 