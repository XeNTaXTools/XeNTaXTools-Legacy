#  FGDK3 (PS2) 5.ovl bone dumper by Bigchillghost
from inc_noesis import *
import copy

def registerNoesisTypes():
	handle = noesis.register("FGDK3 (PS2)", ".ovl")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadModel(handle, noepyLoadModel)
	#noesis.logPopup()
	return 1

#check if it's this type based on the data
def noepyCheckType(data):
	if len(data) < 0x80:
		return 0
	return 1

#load the model
def noepyLoadModel(data, mdlList):
	bs = NoeBitStream(data)
	boneCount = 0x36
	bs.seek(0x3C106, NOESEEK_ABS)
	parentIdMap = {}
	matrixMap = {}
	maxIdx = -1
	for i in range(0, boneCount):
		boneIndex = bs.readInt()
		parentIndex = bs.readInt()
		Mat43 = bs.readBytes(0x30)
		parentIdMap[boneIndex] = parentIndex
		matrixMap[boneIndex] = Mat43
		bs.seek(4, NOESEEK_REL)
		if boneIndex > maxIdx:
			maxIdx = boneIndex
	maxIdx += 1
	strCount = 0x38
	bs.seek(0x3CEDA, NOESEEK_ABS)
	nmapData = bs.readBytes(strCount*8)
	bs.seek(0x3D3D6, NOESEEK_ABS)
	strData = bs.readBytes(0x2E8)
	ms = NoeBitStream(nmapData)
	ss = NoeBitStream(strData)
	nameAddrMap = {}
	for i in range(0, strCount):
		strAddress = ms.readInt()
		boneIndex = ms.readInt()
		nameAddrMap[boneIndex] = strAddress
	ds = NoeBitStream()
	dummyMat = NoeMat43().toBytes()
	for i in range(0, maxIdx):
		if i in parentIdMap:
			parentIndex = parentIdMap[i]
			strAddress = nameAddrMap[i]
			boneMat = matrixMap[i]
		else:
			parentIndex = -1
			if i in nameAddrMap:
				strAddress = nameAddrMap[i]
			else:
				strAddress = len(strData)
			boneMat = dummyMat
		ds.writeInt(i)
		ds.writeInt(parentIndex)
		ds.writeInt(strAddress)
		ds.writeBytes(boneMat)
	ds.writeBytes(strData)
	ds.writeInt(0)
	outName = rapi.getInputName().replace('.ovl','.dmp')
	dumpFile = open(outName, "wb")
	dumpFile.write(ds.getBuffer())
	dumpFile.close()
	return 0
