GTFS (Gran Turismo File System) - Gran Turismo Version 3
'GT3.VOL' Archive Extractor
Copyright (c) 2001 abrax

RELEASE INFO
------------
Released on http://www.sgt-dan.com
Release Date: 03 August 2001.
Independent Release by abrax.

INTRO
-----
This utility takes as input the 'gt3.vol' file from the 
game 'Gran Turismo 3' on Playstation 2.

The purpose of the program is to extract all the files
with directory structure from the various region versions
of the game. This is to allow the files to be extracted
so they can be examined and/or altered. 

TESTING
-------
This has been tested and is known to extract the files
from both the JAP(NTSC) and UK(PAL) DVD releases of GT3 for PS2.
It has not been tested with the US release, but should
work fine with it.

As far as I am aware this util extracts all the 
files and directory structure.

USAGE
-----
Place the .exe file in the same directory as the
GT3.VOL file and then run.
OR - call it with the name of the '.vol' file on
the command line if playing with multiple vol files.

..

It will create a directory called 'extracted' and
place all the files in a directory tree below there.

It will also show you the files it is writing as 
they are written. There are no options for only 
extracting a few files, it wil extract all of them.

FUTURE IMPROVEMENTS
-------------------
The next step is to create a utility that takes
that directory structure and creates a .VOL file
from it that GT3 will load and parse.
This will allow editing of files and creating of
custom GT3 disks, including CDR versions.

Document detailing the extraction steps and the 
process for rebuilding the file.

Possibly including a GUI of some sort.