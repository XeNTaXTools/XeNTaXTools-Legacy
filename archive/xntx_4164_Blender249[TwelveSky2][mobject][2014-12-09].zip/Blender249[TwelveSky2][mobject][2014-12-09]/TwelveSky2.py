import newGameLib
from newGameLib import *
import Blender

def mobjectParser(filename,g):
	g.debug=True
	itemCount=g.i(1)[0]
	new=open(filename+'.dec','wb')
	new.write(struct.pack('i',itemCount))
	#while(True):
	for m in range(itemCount):
		if g.tell()>=g.fileSize():break
		flag=g.i(1)[0]
		if flag==1:
			unk2,size=g.i(2)
			g.tell()
			if unk2==size:data=g.read(size)
			else:data=zlib.decompress(g.read(size))
			new.write(struct.pack('i',unk2))
			new.write(data)
			
			unk1,unk2,size=g.i(3)
			if unk2!=size:
				data=zlib.decompress(g.read(size))
				new.write(struct.pack('i',unk2))
				new.write(data)
				unk1,unk2=g.i(2)
	new.close()
	g.debug=False
	
	file=open(filename+'.dec','rb')
	g=BinaryReader(file)
	decParser(filename,g)
	file.close()	
	
def animation(mesh,animname,frames):
	scn = Blender.Scene.GetCurrent()
	ctx = scn.getRenderingContext()
	ctx.eFrame=frames	
	key= mesh.key	
	if not key:
		mesh.insertKey(1, 'relative')
		key= mesh.key	
	key.ipo = Blender.Ipo.New('Key',animname)
	ipo = key.ipo
	all_keys = ipo.curveConsts
	for m in range(1,frames):
		curve = ipo.getCurve(m)
		if curve == None:
			curve = ipo.addCurve(all_keys[m-1])		
		curve.append((m-1,1))
		curve.append((m-2,0))
		curve.append((m,0))
		curve.setInterpolation('Linear')
		curve.recalc()
	
	
def decParser(filename,g):
	itemCount=g.i(1)[0]
	imgID=0
	
	skeleton=Skeleton()
	modelList=[]
	texList=[]
	while(True):
		if g.tell()>=g.fileSize():break
		size=g.i(1)[0]
		pos=g.tell()
		flag,unk=g.i(2)
		if flag==542327876:
			g.seek(-8,1)
			sys=Sys(filename)
			#sys.addDir(sys.base)
			new=open(sys.dir+os.sep+sys.base+str(imgID)+'.dds','wb')
			new.write(g.read(size))
			new.close()
			texList.append(new.name)
			imgID+=1
			
		elif flag==0:
			g.i(28)
			a,b,c,d=g.i(4)
			mesh=Mesh()
			g.f(10)
			for m in range(a):
				mesh.vertPosList.append(g.f(3))
				g.seek(12,1)
				mesh.vertUVList.append(g.f(2))
			for m in range(a):
				mesh.skinIndiceList.append(g.i(4))
				mesh.skinWeightList.append(g.f(4))
			skin=Skin()
			mesh.skinList.append(skin)	
			mesh.indiceList=g.H(d*3)
			mesh.TRIANGLE=True
			mesh.imgID=imgID			
			modelList.append([mesh,'mesh'])	
			
		elif flag==1:
			g.f(28)
			a,b,c,d=g.i(4)
			skeleton.ARMATURESPACE=True
			for m in range(a):
				matrix=Matrix4x4(g.f(16))	
			meshList=[]	
			for m in range(a):#animation frame
				mesh=Mesh()
				mesh.imgID=imgID
				mesh.TRIANGLE=True
				for n in range(b):#vertex 
					mesh.vertPosList.append(g.f(3))
					g.seek(12,1)
					mesh.vertUVList.append(g.f(2))
				meshList.append(mesh)				
			indiceList=g.H(d*3)	
			for m in range(a):
				mesh=meshList[m]
				mesh.indiceList=indiceList
				mesh.TRIANGLE=True
			modelList.append([meshList,'list'])	
		g.seek(pos+size)
		
	skeleton.draw()	
	for model in modelList:
		if model[1]=='mesh':
			mat=Mat()
			mat.diffuse=texList[model[0].imgID]
			mat.ZTRANS=True
			mat.TRIANGLE=True
			model[0].matList.append(mat)
			mesh.BINDSKELETON='armature'
			mesh.draw()
		if model[1]=='list':
			blenderMesh=None	
			for i,mesh in enumerate(model[0]):
				if i==0:
					Blender.Set("curframe",i*10)
					mat=Mat()
					try:mat.diffuse=texList[mesh.imgID]
					except:pass
					mat.ZTRANS=True
					mat.TRIANGLE=True
					mesh.matList.append(mat)
					mesh.draw()
					blenderObject=mesh.object
					blenderMesh=blenderObject.getData(mesh=1)
				else:
					Blender.Set("curframe",(i-1)*10)
					for id in range(len(mesh.vertPosList)):
						blenderMesh.verts[id].co = Vector(mesh.vertPosList[id])
					blenderMesh.update()
					blenderObject.insertShapeKey()
			if blenderMesh is not None:	
				animation(blenderMesh,'anim',a)	
	
	
	
	
def Parser():	
	filename=input.filename
	print
	print filename
	print
	ext=filename.split('.')[-1].lower()	
	
	if ext=='mobject':
		file=open(filename,'rb')
		g=BinaryReader(file)
		mobjectParser(filename,g)
		file.close()
 
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
	
Blender.Window.FileSelector(openFile,'import','mobject - twelve sky 2 effect file') 