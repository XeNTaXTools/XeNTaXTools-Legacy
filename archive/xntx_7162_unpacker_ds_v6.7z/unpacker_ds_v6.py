import subprocess
import signal

import struct
import os
import shutil
import datetime
import time


##################################	INTERFACE #########################################





tool_path = 'G:\\ds3\\ds.exe' #folder with tools
bin_dir = 'G:\\ds' #"root" folder with *.bin files
work_dir = 'G:\\ds3\\ds\\models\\_ready_3' #folder with models for conversion

step_0_create_res_file = False
step_1_unpack_bin = False
step_2_unpack_core = False
step_2_5_patch_ascii_names = True

step_3_generate_chars = True #(__join_* model)
create_join_parts = False # create separate file for every model's part and skeleton (__jp_* model)


step3_without_conversion = True # not convert skeletons *.core files. 
								 # Use only existing .SMD and .ASCII files for join chars. 
								 # ONLY for second(thrid, e.t.c.) conversion
								 # You still need the skeletons created in "full" step 3.


#####################################################################################
								 
								 
								 
								 
tools_dir = os.path.dirname(tool_path)
logname = "ds_log__" + str(datetime.datetime.now())
logname = logname.replace(" ","_")
logname = logname.replace(":","_")
logname = logname.replace(".","_")
logname = logname + ".txt"
logfile = open(os.path.join(tools_dir,logname),"w")

def print_fork(in_str):
	print(in_str)
	logfile.write(in_str + "\n")
	logfile.flush()
	
	
	
	
	
	
def secure_call(work_str):
	process = subprocess.Popen(work_str, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
	#code = process.wait(1)
	
	ff = 0
	tm = 0
	timeout = 300
	step = 1
	#simple timeout
	while (tm >= 0):
	
		tm = tm + step
		print("pol: " + str(process.poll()))

		if (not (process.poll() is None)):
			if(process.poll() == 0): print_fork("SC: successful unpacked")
			else: print_fork("SC: error unpacked")
			tm = -1000
		if(tm > timeout):
			#tm = -1000
			#subprocess.call(['taskkill', '/F', '/T', '/PID', str(process.pid)])
			#print_fork("SC: timeout, aborted ")
			pass
		if(tm > 20):
			val = 128

			val = subprocess.call("Taskkill /IM dw20.exe " )

			print("	val22 " + str(val))
			if(val == 0):
				process.kill()
				print_fork("SC: ERROR dw20.exe, aborted2 ")
				#time.sleep(5)

		time.sleep(step)
	#subprocess.call("Taskkill /IM dw20.exe " )
	#subprocess.call("Taskkill /IM ds.exe /f" )
	#subprocess.call(['taskkill', '/F', '/T', '/PID', str(process.pid)])

	time.sleep(2)
	
	out, err = process.communicate()
	print_fork("SC: stdout: " + str(out))		
	print_fork("SC: stderr: " + str(err))
	
	
	
	

print_fork("create ini:")

os.chdir(tools_dir)

inipath = os.path.join(tools_dir,"decima.ini")
print_fork("path to ini: " + inipath)
inifile = open(inipath,'w')
inifile.write(bin_dir + "\n")
inifile.flush()
inifile.close()
print_fork("complete!\n\n")






if (step_0_create_res_file):
	print_fork("\n\n\nStep 0: create res file:")
	os.chdir(tools_dir)
	work_str = '\"' + tool_path + '\"'
	print_fork(work_str)
	subprocess.call(work_str)
	print_fork("res file created")
	
	
if (step_1_unpack_bin):
	print_fork("\n\n\nStep 1: unpack bin's")
	if(not os.path.exists(os.path.join(tools_dir,"_trash"))): os.makedirs(os.path.join(tools_dir,"_trash"))
	os.chdir(os.path.join(tools_dir,"_trash"))
	
	work_str = '\"' + tool_path + '\" /p \"' + os.path.join(tools_dir,"res.txt") + '\"'
	print_fork(work_str)
	subprocess.call(work_str)
	print_fork("bin files unpacked")
	print_fork("result in " + tools_dir)

if (step_2_unpack_core):
	print_fork("\n\n\nStep 2: unpack core")
	for root, dirs, files in os.walk(work_dir):
		for name in files:	
			fullname = os.path.join(root, name)
			if(name.lower() == "matrices"):
				os.remove(fullname)	
				print_fork("remove " + fullname)
		for name in files:	
			fullname = os.path.join(root, name)
			if(fullname.lower().endswith(".core")):
				work_str = '\"' + tool_path + '\" \"' +   fullname + '\"'
				print_fork(work_str)
				os.chdir(root)
				secure_call(work_str)
			
			
if(step_2_5_patch_ascii_names): #step 2.5 patch name
	print_fork("\n\n\nStep 2.5: patch ascii names ")

	for root, dirs, files in os.walk(work_dir):
		for name in files:	
			fullname = os.path.join(root, name)
			if((root.find("join_geo") == -1) and (root.find("skel_work") == -1)):
				if(name.endswith(".ascii")):
					mat_file = fullname[:-6] + "_materials.txt"

					if(os.path.exists(mat_file)):
						print_fork("	" + fullname)
						print_fork("	" + mat_file)
						
						mat_names = []
						with open(mat_file) as f:
							#print("	" + fl)
							temp_strs = f.read().splitlines()
							i = 3
							mat_name = []
							index = ""

							while i + 1 < len(temp_strs):
								index = temp_strs[i].strip()
								#print_fork("		" + "index "  + index)
								i = i + 3
								tex_set = ""
								while(i < len(temp_strs)):
									if(temp_strs[i].strip() == "-------------------------------"):
										i = i - 1
										break
									else:
										
										if((temp_strs[i].startswith("ds/models/")) and (tex_set == "")):
											tex_set = os.path.basename(temp_strs[i])
											#print_fork("		" + "tex_set " + tex_set)
											mat_names.append([index, tex_set])
										
										i = i + 1
						
						for mat_name in mat_names:
							print_fork("		" + str(mat_name))
										
						strs_geo = []
						with open(fullname) as f:
							strs_geo = f.read().splitlines()
							
						i = 0
						while i + 1 < len(strs_geo):
							if((strs_geo[i] == "material") or (strs_geo[i].startswith("material "))):
								
								
								mat_index = (strs_geo[i-3])
								
								print_fork("		" + mat_index)
								
								marker = True
								for dln in mat_names:
									if(dln[0] == mat_index):
										part_name = name[:name.find(".")] + "__" + dln[1]
										print_fork("		set part name: " + part_name)
										strs_geo[i-3] = part_name
										marker = False
										break
								if(marker):
										part_name = name[:name.find(".")] + "__" + mat_index
										
										if(not strs_geo[i-3].startswith( name[:name.find(".")] )):	
											strs_geo[i-3] = part_name
											print_fork("		set part name: " + part_name)
									
							i = i + 1
							
						with open(fullname, "w") as file:
							for  line in strs_geo:
								file.write(line + '\n')
							
						



				
				
		



			
if (step_3_generate_chars):
	print_fork("\n\n\nStep 3: generate chars ")
	for root, dirs, files in os.walk(work_dir):
		for name in files:	
			fullname = os.path.join(root, name)
			if(name.lower() == "matrices") and (fullname.find("skel_work") < 0):
				print_fork(root)
				skel_dir = os.path.join(os.path.dirname(root),"skeletons")
				if(os.path.isdir(skel_dir)):
					print_fork("	found skeleton dir: " +skel_dir)
					
					
					skelfiles = os.listdir(skel_dir) 
					
					for skfile in skelfiles:
						
						if((skfile.endswith(".core")) and (os.path.isfile(os.path.join(skel_dir,skfile)))):
							print_fork("		"+skfile)
							
							work_skel_dir = os.path.join(root,"skel_work")
							if(not (os.path.isdir(work_skel_dir))):
								os.makedirs(work_skel_dir)
							#else:
							#	shutil.rmtree(work_skel_dir)
							#	os.makedirs(work_skel_dir)
							if (not step3_without_conversion):
								if(os.path.exists(os.path.join(work_skel_dir,name))):
									os.remove(os.path.join(work_skel_dir,name))
									print_fork("			remove old matrices")
								shutil.copy(fullname, os.path.join(work_skel_dir,name))
								shutil.copy(os.path.join(skel_dir,skfile), os.path.join(work_skel_dir,skfile))
								
								
						

								work_str = '\"' + tool_path + '\" \"' +   os.path.join(work_skel_dir,skfile) + '\"'
								print_fork("			" +work_str)
								os.chdir(work_skel_dir)


								#try:
								#process = subprocess.Popen(work_str, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
								#code = process.wait(1)
								
								
								
								
								
								secure_call(work_str)

							
							
								if(os.path.exists(os.path.join(work_skel_dir,skfile))):
									os.remove(os.path.join(work_skel_dir,skfile))












							if(os.path.exists(os.path.join(work_skel_dir,skfile + ".ascii"))): 
								print_fork("					ASCII: ")
								skelsize = os.path.getsize(os.path.join(work_skel_dir,skfile + ".ascii"))
								if(skelsize>0):
									if(not os.path.exists(os.path.join(root,"join_geo"))):
										os.makedirs(os.path.join(root,"join_geo"))
									join_name = os.path.join(root,"join_geo","__join__" + skfile[:-5] + ".ascii~")
									print_fork("					" + join_name)
									if(os.path.exists(join_name)):
										os.remove(join_name)
									jfile = open(join_name, "w")
									strs_skel = ""
									with open(os.path.join(work_skel_dir,skfile + ".ascii"), 'r') as ifile:
										strs_skel = ifile.read()#.splitlines()
									jfile.write(strs_skel)
									meshfiles = os.listdir(root) 
									strs_geo = ""
									for mfile in meshfiles:
										if(mfile.endswith(".ascii")): # and (not mfile.startswith("__j")):
											print_fork("					join: " + mfile)
											with open(os.path.join(root,mfile), 'r') as ifile:
												tmp_strs = ifile.read()#.splitlines()
												num = 0
												offset = 0
												for cdi in range(0, len(tmp_strs)):
													if(tmp_strs[cdi] == "\n"):
														num = num + 1 
													if(num == 1): 
														offset = cdi
														break
												print_fork("					offset:" + str (offset))
												if(num == 1):
													strs_geo = strs_geo + tmp_strs[offset+1:]
													
												if(create_join_parts):  # create _jpfile
													jp = open(os.path.join(root,"join_geo", "__jp__" + mfile[:-len(".ascii")] + "__" +  skfile[:-5] + ".ascii"), "w")
													jp.write(strs_skel)
													jp.write(tmp_strs)
													jp.close
													
												
									num_mat = strs_geo.count("\nmaterial\n")
									print_fork("					num_mat " + str(num_mat))
									jfile.write(str(num_mat) + "\n")
									jfile.write(strs_geo)

									jfile.close()
									try:
										if(os.path.exists(join_name[:-1])): os.remove(join_name[:-1])
										os.rename(join_name, join_name[:-1])
									except Exception:
										print_fork("					cannot rename tmp file")
								else:
									print_fork("					empty skeleton")










							if(os.path.exists(os.path.join(work_skel_dir,skfile + ".smd"))):
								print_fork("					SMD: ")
								skelsize = os.path.getsize(os.path.join(work_skel_dir,skfile + ".smd"))							
								if(skelsize>0):
									if(not os.path.exists(os.path.join(root,"join_geo"))):
										os.makedirs(os.path.join(root,"join_geo"))
									join_name = os.path.join(root,"join_geo","__join__" + skfile[:-5] + ".smd~")
									print_fork("					" + join_name)
									if(os.path.exists(join_name)):
										os.remove(join_name)
									jfile = open(join_name, "w")
									strs_skel = ""
									with open(os.path.join(work_skel_dir,skfile + ".smd"), 'r') as ifile:
										strs_skel = ifile.read()#.splitlines()
									jfile.write(strs_skel)
									meshfiles = os.listdir(root) 
									strs_geo = ""

									for mfile in meshfiles:
										if(mfile.endswith(".smd")): # and (not mfile.startswith("__j")):
											print_fork("					join: " + mfile)
											with open(os.path.join(root,mfile), 'r') as ifile:
												strs_geo = ifile.read()#.splitlines()
											jfile.write(strs_geo)
											
											if(create_join_parts):
												jp = open(os.path.join(root,"join_geo", "__jp__" + mfile[:-len(".smd")] + "__" +  skfile[:-5] + ".smd"), "w")
												jp.write(strs_skel)
												jp.write(strs_geo)
												jp.close

									jfile.close()
									try:
										if(os.path.exists(join_name[:-1])): os.remove(join_name[:-1])
										os.rename(join_name, join_name[:-1])
									except Exception:
										print_fork("					cannot rename tmp file")

								else:
									print_fork("					empty skeleton")

					
					
				else:
					print_fork("	unfound skeleton dir: " +skel_dir)

	
print_fork("\n\n\nScript comlete")
logfile.close()	