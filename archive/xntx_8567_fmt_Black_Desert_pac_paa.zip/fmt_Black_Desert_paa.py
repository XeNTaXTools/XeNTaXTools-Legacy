from inc_noesis import *
import noesis
import rapi
import os
import glob


def registerNoesisTypes():
    handle = noesis.register("Black Desert Animation", ".paa")
    noesis.setHandlerTypeCheck(handle, BDCheckType)
    noesis.setHandlerLoadModel(handle, BDLoadModel)
    return 1


def BDCheckType(data):
    bs = NoeBitStream(data)
    idMagic = bs.readInt()
    if idMagic != 0x20524150:
        return 0
    return 1


def BDLoadModel(data, mdlList):
    rapi.rpgCreateContext()
    rapi.rpgSetOption(noesis.RPGOPT_SWAPHANDEDNESS, 1)
    aas = NoeBitStream(data)
    # Output
    boneList = []
    animList = []
    kfBoneList = []
    # Bone Mapping
    skelBoneHashIndexTable = {}

    # Load external PAB skeleton file
    os.chdir(rapi.getDirForFilePath(rapi.getInputName()))
    pabFileList = glob.glob("*.pab")
    if(pabFileList):
        skelFilePath = rapi.getDirForFilePath(
            rapi.getInputName())+pabFileList[0]
        bs = rapi.loadIntoByteArray(skelFilePath)
        bs = NoeBitStream(bs)
        bs.seek(0x10, NOESEEK_ABS)
        skelBoneCount = bs.readUShort()
        print("%-10s" % "boneIndex", "%-10s" % "boneParent", "%-8s" %
              "flag1", "%-8s" % "flag1_1", "%-8s" % "flag2", "boneName")
        for boneIdx in range(skelBoneCount):
            boneHash = str(bs.readUInt())
            boneName = noeStrFromBytes(
                bs.readBytes(bs.readUByte()), "euc-kr")
            skelBoneHashIndexTable[boneHash] = boneIdx
            boneParent = bs.readInt()
            boneMtx = NoeMat44.fromBytes(
                bs.readBytes(64)).toMat43().swapHandedness()
            boneMtx_Inversed = NoeMat44.fromBytes(
                bs.readBytes(64)).toMat43()
            boneMtx_Local = NoeMat44.fromBytes(bs.readBytes(64)).toMat43()
            boneMtx_LocalInversed = NoeMat44.fromBytes(
                bs.readBytes(64)).toMat43()
            boneScale = NoeVec3.fromBytes(bs.readBytes(12))
            boneQuat = NoeQuat.fromBytes(bs.readBytes(16))
            boneLocalPos = NoeVec3.fromBytes(bs.readBytes(12))
            boneList.append(
                NoeBone(boneIdx, boneName, boneMtx, None, int(boneParent)))
            # skip unknown bytes
            flag1 = flag1_1 = flag2 = 0
            flag1 = bs.readByte()
            if(flag1):
                flag1_1 = bs.readUInt()
                if(flag1_1 == 4):
                    bs.seek(16, NOESEEK_REL)
                elif(flag1_1 == 1):
                    bs.seek(20, NOESEEK_REL)
            flag2 = bs.readByte()
            if(flag2):
                bs.seek(36, NOESEEK_REL)
            print("%-10s" % boneIdx, "%-10s" % boneParent, "%-8s" %
                  flag1, "%-8s" % flag1_1, "%-8s" % flag2, boneName)
    else:
        print("Require PAB skeleton file")
        return 0
    aas.seek(16, NOESEEK_ABS)
    animBoneCount = aas.readUShort()
    animDuration = aas.readFloat()
    aas.seek(4, NOESEEK_REL)

    frameRate = 30
    for boneIdx in range(animBoneCount):
        boneHash = str(aas.readUInt())
        sclKeys = []
        rotKeys = []
        trnKeys = []
        # Scale
        sclKFrameCount = aas.readUShort()
        for sclKFrameIdx in range(sclKFrameCount):
            sclFrame = round(aas.readUShort() / (100/3), 0) / frameRate
            sclKey = NoeVec3(
                (aas.readHalfFloat(), aas.readHalfFloat(), aas.readHalfFloat()))
            sclKeys.append(NoeKeyFramedValue(sclFrame, sclKey))
        # Rotation
        rotKFrameCount = aas.readUShort()
        for rotKFrameIdx in range(rotKFrameCount):
            rotFrame = round(aas.readUShort() / (100/3), 0) / frameRate
            rotKey = NoeQuat((aas.readHalfFloat(), aas.readHalfFloat(), aas.readHalfFloat(
            ), aas.readHalfFloat())).toMat43().swapHandedness().toQuat().transpose()
            rotKeys.append(NoeKeyFramedValue(rotFrame, rotKey))
        # Translation
        trnKFrameCount = aas.readUShort()
        for trnKFrameIdx in range(trnKFrameCount):
            trnFrame = round(aas.readUShort() / (100/3), 0) / frameRate
            trnKey = NoeVec3(
                (-aas.readHalfFloat(), aas.readHalfFloat(), aas.readHalfFloat()))
            trnKeys.append(NoeKeyFramedValue(trnFrame, trnKey))

        if not(boneHash in list(skelBoneHashIndexTable.keys())):
            print("Bone %s not existed in skeleton" % boneHash)
            continue
        kfBone = NoeKeyFramedBone(skelBoneHashIndexTable[boneHash])
        kfBone.setScale(sclKeys, noesis.NOEKF_SCALE_VECTOR_3,
                        noesis.NOEKF_INTERPOLATE_LINEAR)
        kfBone.setRotation(
            rotKeys, noesis.NOEKF_ROTATION_QUATERNION_4, noesis.NOEKF_INTERPOLATE_LINEAR)
        kfBone.setTranslation(
            trnKeys, noesis.NOEKF_TRANSLATION_VECTOR_3, noesis.NOEKF_INTERPOLATE_LINEAR)
        kfBoneList.append(kfBone)
    animList.append(NoeKeyFramedAnim("anim", boneList, kfBoneList, frameRate))
    mdlList.append(NoeModel([NoeMesh([], [])], boneList, animList))
    return 1
