from inc_noesis import *
import noesis
import rapi
import os
import glob

bImportAllLODs = False


def registerNoesisTypes():
    handle = noesis.register("Black Desert Model", ".pab;.pac")
    noesis.setHandlerTypeCheck(handle, BDCheckType)
    noesis.setHandlerLoadModel(handle, BDLoadModel)
    return 1


def BDCheckType(data):
    bs = NoeBitStream(data)
    idMagic = bs.readInt()
    if idMagic != 0x20524150:
        return 0
    return 1


def BDLoadModel(data, mdlList):
    rapi.rpgCreateContext()
    rapi.rpgSetOption(noesis.RPGOPT_SWAPHANDEDNESS, 1)
    # Output
    matList = []
    boneList = []
    # Bone Mapping
    meshBoneHashList = []
    skelBoneHashIndexTable = {}
    # Load PAC
    cs = NoeBitStream(data)  # PAC bitStream
    idMagic = cs.readInt()
    pacVersion = cs.readUShort()
    print("PAC Version:", pacVersion)
    cs.seek(0x10, NOESEEK_ABS)
    if pacVersion == 515 or pacVersion == 771:
        cs.seek(0x14, NOESEEK_ABS)

    if pacVersion == 513:
        boneCount = cs.readUShort()
        for i in range(boneCount):
            boneHash = cs.readUInt()
            boneName = noeStrFromBytes(cs.readBytes(cs.readUByte()), "euc-kr")
            boneParent = cs.readInt()
            boneMtx = NoeMat44.fromBytes(
                cs.readBytes(64)).toMat43().swapHandedness()
            boneMtx_Inversed = NoeMat44.fromBytes(cs.readBytes(64)).toMat43()
            boneMtx_Local = NoeMat44.fromBytes(cs.readBytes(64)).toMat43()
            boneMtx_LocalInversed = NoeMat44.fromBytes(
                cs.readBytes(64)).toMat43()
            boneScale = NoeVec3.fromBytes(cs.readBytes(12))
            boneQuat = NoeQuat.fromBytes(cs.readBytes(16))
            bonePos = NoeVec3.fromBytes(cs.readBytes(12))
            cs.seek(2, NOESEEK_REL)
            boneList.append(NoeBone(i, boneName, boneMtx, None, boneParent))
        mdl = NoeModel()
        mdlList.append(mdl)
        mdl.setBones(boneList)
        return 1
    elif pacVersion == 259 or pacVersion == 515 or pacVersion == 771:
        meshBoneCount = cs.readUByte()
        meshBoneHashList = cs.read("I" * meshBoneCount)
        cs.read("B" * cs.readUByte())  # usedBoneList

        # Load external PAB skeleton file
        os.chdir(rapi.getDirForFilePath(rapi.getInputName()))
        pabFileList = glob.glob("*.pab")
        if(pabFileList):
            skelFilePath = rapi.getDirForFilePath(
                rapi.getInputName())+pabFileList[0]
            bs = rapi.loadIntoByteArray(skelFilePath)
            bs = NoeBitStream(bs)
            bs.seek(0x10, NOESEEK_ABS)
            skelBoneCount = bs.readUShort()

            print("%-10s" % "boneIndex", "%-10s" % "boneParent", "%-8s" %
                  "flag1", "%-8s" % "flag1_1", "%-8s" % "flag2", "boneName")
            for boneIdx in range(skelBoneCount):
                boneHash = str(bs.readUInt())
                boneName = noeStrFromBytes(
                    bs.readBytes(bs.readUByte()), "euc-kr")
                skelBoneHashIndexTable[boneHash] = boneIdx
                boneParent = bs.readInt()
                boneMtx = NoeMat44.fromBytes(
                    bs.readBytes(64)).toMat43().swapHandedness()

                boneMtx_Inversed = NoeMat44.fromBytes(
                    bs.readBytes(64)).toMat43()
                boneMtx_Local = NoeMat44.fromBytes(bs.readBytes(64)).toMat43()
                boneMtx_LocalInversed = NoeMat44.fromBytes(
                    bs.readBytes(64)).toMat43()
                boneScale = NoeVec3.fromBytes(bs.readBytes(12))
                BoneQuat = NoeQuat.fromBytes(bs.readBytes(16))
                BoneLocalPos = NoeVec3.fromBytes(bs.readBytes(12))
                boneList.append(
                    NoeBone(boneIdx, boneName, boneMtx, None, int(boneParent)))
                # skip unknown bytes
                flag1 = flag1_1 = flag2 = 0
                flag1 = bs.readByte()
                if(flag1):
                    flag1_1 = bs.readUInt()
                    if(flag1_1 == 4):
                        bs.seek(16, NOESEEK_REL)
                    elif(flag1_1 == 1):
                        bs.seek(20, NOESEEK_REL)
                flag2 = bs.readByte()
                if(flag2):
                    bs.seek(36, NOESEEK_REL)

                print("%-10s" % boneIdx, "%-10s" % boneParent, "%-8s" %
                      flag1, "%-8s" % flag1_1, "%-8s" % flag2, boneName)
            # Create BoneMap
            boneMapList = []
            for meshBoneHash in meshBoneHashList:
                if not (str(meshBoneHash) in list(skelBoneHashIndexTable.keys())):
                    print("Missing bone %s in skeleton file" %
                          str(meshBoneHash))
                    continue
                boneMapList.append(
                    skelBoneHashIndexTable[str(meshBoneHash)])
            rapi.rpgSetBoneMap(boneMapList)

        # Load Vertexs and Faces
        totalVert, totalFace, meshCount = cs.read("IIH")
        for meshIdx in range(meshCount):
            meshName = noeStrFromBytes(cs.readBytes(cs.readUByte()), "euc-kr")
            cs.seek(2, NOESEEK_REL)
            matName = "MAT_"+meshName
            material = NoeMaterial(matName, "")
            material.setTexture(meshName)
            matList.append(material)
            for lodIdx in range(3):
                rapi.rpgSetName(meshName + "_LOD_" + str(lodIdx))
                rapi.rpgSetMaterial(matName)
                vertCount = cs.readUShort()
                vertBuffer = cs.readBytes(32 * vertCount)
                faceCount = cs.readUInt()
                faceBuffer = cs.readBytes(2 * faceCount)

                rapi.rpgBindPositionBufferOfs(
                    vertBuffer, noesis.RPGEODATA_FLOAT, 32, 0)
                # rapi.rpgBindNormalBufferOfs(
                #     vertBuffer, noesis.RPGEODATA_UBYTE, 32, 12)
                rapi.rpgBindUV1BufferOfs(
                    vertBuffer, noesis.RPGEODATA_HALFFLOAT, 32, 16)
                # rapi.rpgBindColorBufferOfs(
                #     vertBuffer, noesis.RPGEODATA_UBYTE, 32, 20, 4)
                rapi.rpgBindBoneIndexBufferOfs(
                    vertBuffer, noesis.RPGEODATA_UBYTE, 32, 24, 4)
                rapi.rpgBindBoneWeightBufferOfs(
                    vertBuffer, noesis.RPGEODATA_UBYTE, 32, 28, 4)

                if not bImportAllLODs:
                    if(lodIdx == 0):
                        rapi.rpgCommitTriangles(
                            faceBuffer, noesis.RPGEODATA_USHORT, faceCount, noesis.RPGEO_TRIANGLE, 1)
                else:
                    rapi.rpgCommitTriangles(
                        faceBuffer, noesis.RPGEODATA_USHORT, faceCount, noesis.RPGEO_TRIANGLE, 1)
        mdl = rapi.rpgConstructModel()
        mdl.setModelMaterials(NoeModelMaterials([], matList))
        mdlList.append(mdl)
        mdl.setBones(boneList)
    return 1
