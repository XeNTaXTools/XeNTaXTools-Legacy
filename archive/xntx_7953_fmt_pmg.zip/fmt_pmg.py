from inc_noesis import *

def registerNoesisTypes():
   handle = noesis.register("euro track?", ".pmg")
   noesis.setHandlerTypeCheck(handle, noepyCheckType)
   noesis.setHandlerLoadModel(handle, noepyLoadModel)
   noesis.logPopup()
   return 1

def noepyCheckType(data):
    if len(data) < 0x80:
        return 0
    return 1       

def noepyLoadModel(data, mdlList):
    bs = NoeBitStream(data)
    bs.seek(0x4, NOESEEK_REL)#header
    count_submesh = bs.readInt()
    count_mat = bs.readInt()#?
    bs.seek(0x54, NOESEEK_ABS)
    submesh_offset = bs.readInt()
    string_offset = bs.readInt()
    count_char = bs.readInt()
    offset_vbuf = bs.readInt()
    size_vbuf = bs.readInt()
    offset_ibuf = bs.readInt()
    size_ibuf = bs.readInt()
    
    bs.seek(submesh_offset, NOESEEK_ABS)
    
    meshes = []
    for x in range(count_submesh):
        v, vt, vn, f = [], [], [], []
        
        count_indices = bs.readInt()
        count_vertex = bs.readInt()
        bs.seek(0x34, NOESEEK_REL)
        size_block = bs.readInt()
        print("block",size_block)
        offset_vertex = bs.readInt()#(12)
        print("v",offset_vertex)
        offset_normal = bs.readInt()#(12)
        print("vn",offset_normal)
        offset_uv = bs.readInt()#(8)
        print("uv",offset_uv)
        offset_unk = bs.readInt()#(4)
        print("unk",offset_unk)
        bs.seek(0x10, NOESEEK_REL)
        offset_indices = bs.readInt()
        
        bs.seek(offset_vertex, NOESEEK_ABS)
        
        for q in range(count_vertex):
            v.append(NoeVec3.fromBytes(bs.readBytes(12)))
            vn.append(NoeVec3.fromBytes(bs.readBytes(12)))
            bs.seek(4, NOESEEK_REL)
            if offset_uv != -1: 
                vt.append(NoeVec3([bs.readFloat(), bs.readFloat(), 0.0]))
            tx = 8 if offset_uv != -1 else 0
            bs.seek(size_block-28-tx, NOESEEK_REL)
            
        bs.seek(offset_indices, NOESEEK_ABS)
        f = [bs.readUShort() for i in range(count_indices)]
        
        bs.seek(submesh_offset + ((x+1) * 100), NOESEEK_ABS)
        mesh = NoeMesh(f, v, "mesh_" + str(x))
        mesh.setNormals(vn)
        if vt: mesh.setUVs(vt)
        meshes.append(mesh)
        
    mdlList.append(NoeModel(meshes))
    return 1