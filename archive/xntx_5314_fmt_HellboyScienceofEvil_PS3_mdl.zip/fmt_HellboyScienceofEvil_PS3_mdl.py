from inc_noesis import *
import noesis
import rapi
import os

def registerNoesisTypes():
   handle = noesis.register("Hellboy: Science of Evil (PS3)", ".mdl")
   noesis.setHandlerTypeCheck(handle, HBCheckType)
   noesis.setHandlerLoadModel(handle, HBLoadModel)
   #noesis.logPopup()
   return 1

def HBCheckType(data):
	bs = NoeBitStream(data)
	Magic = bs.readBytes(4)
	print(Magic, "magic")
	if Magic != b'MDL4': 
		return 0
	fileName = os.path.basename(rapi.getInputName())   #get file name + ext without path
	if "_CX" in fileName or "_CI" in fileName or "_CF" in fileName:
		print("Error: This type not yet supported")
		return 0
	return 1   
   
def HBLoadModel(data, mdlList):
	ctx = rapi.rpgCreateContext()
	rapi.rpgSetOption(noesis.RPGOPT_BIGENDIAN, 1)       #set big-endian byte order
	rapi.setPreviewOption("setAngOfs","0 90 90")      #set the default preview angle        
	bs = NoeBitStream(data)
	bs.seek(0x70, NOESEEK_ABS)
	print(bs.tell(), "start reading")
	infOff = bs.read(">i") #read big-endian integer
	print(infOff[0], "info offset")
	bs.seek(infOff[0], NOESEEK_ABS)
	print(bs.tell(), "start info")
	VCount = bs.read(">i")                                #vertex count
	print(VCount[0], "VCount")
	VBytes = bs.read(">i")
	print(VBytes[0], "VBytes")
	skip = bs.readBytes(40)
	FCount = bs.read(">i")                                #face indices count
	print(FCount[0], "FCount")
	skip = bs.readBytes(12)
	indLoc = bs.read(">i")
	mdgFile = rapi.getExtensionlessName(rapi.getInputName()) + ".mdg"
	print(mdgFile, "mdg file")
	bs2 = NoeBitStream(rapi.loadIntoByteArray(mdgFile))
	bs2.seek(0x10, NOESEEK_ABS)
	VBuf = bs2.readBytes(VCount[0] * VBytes[0])
	if VBytes[0] == 48:
		rapi.rpgBindPositionBufferOfs(VBuf, noesis.RPGEODATA_FLOAT, VBytes[0], 0)   #position of vertices
		#rapi.rpgBindNormalBufferOfs(VBuf, noesis.RPGEODATA_FLOAT, VBytes[0], 12)   #normals -optional
		rapi.rpgBindUV1BufferOfs(VBuf, noesis.RPGEODATA_FLOAT, VBytes[0], 20)       #UVs
	elif VBytes[0] == 56:
		rapi.rpgBindPositionBufferOfs(VBuf, noesis.RPGEODATA_FLOAT, VBytes[0], 0)   #position of vertices
		#rapi.rpgBindNormalBufferOfs(VBuf, noesis.RPGEODATA_FLOAT, VBytes[0], 12)   #normals -optional
		rapi.rpgBindUV1BufferOfs(VBuf, noesis.RPGEODATA_FLOAT, VBytes[0], 20)       #UVs
	elif VBytes[0] == 72:
		rapi.rpgBindPositionBufferOfs(VBuf, noesis.RPGEODATA_FLOAT, VBytes[0], 0)   #position of vertices
		#rapi.rpgBindNormalBufferOfs(VBuf, noesis.RPGEODATA_FLOAT, VBytes[0], 12)   #normals -optional
		rapi.rpgBindUV1BufferOfs(VBuf, noesis.RPGEODATA_FLOAT, VBytes[0], 20)       #UVs
	elif VBytes[0] == 80:
		rapi.rpgBindPositionBufferOfs(VBuf, noesis.RPGEODATA_FLOAT, VBytes[0], 0)   #position of vertices
		#rapi.rpgBindNormalBufferOfs(VBuf, noesis.RPGEODATA_FLOAT, VBytes[0], 12)   #normals -optional
		rapi.rpgBindUV1BufferOfs(VBuf, noesis.RPGEODATA_FLOAT, VBytes[0], 20)       #UVs
	bs2.seek(indLoc[0], NOESEEK_ABS)
	IBuf = bs2.readBytes(FCount[0] * 2)                       #multiply by 2 for word, 4 for dword indices, 
	rapi.rpgCommitTriangles(IBuf, noesis.RPGEODATA_SHORT, FCount[0], noesis.RPGEO_TRIANGLE, 1) #SHORT for word 
	mdl = rapi.rpgConstructModel()                                                          #INT for dword
	mdlList.append(mdl)
	rapi.rpgClearBufferBinds()
	return 1