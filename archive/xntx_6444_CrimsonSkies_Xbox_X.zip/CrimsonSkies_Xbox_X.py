#Noesis Python model import+export test module, imports/exports some data from/to a made-up format
import math

from inc_noesis import *

#registerNoesisTypes is called by Noesis to allow the script to register formats.
#Do not implement this function in script files unless you want them to be dedicated format modules!
def registerNoesisTypes():
	handle = noesis.register("Crimson Skies (Xbox)", ".x")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadModel(handle, noepyLoadModel) #see also noepyLoadModelRPG

	noesis.logPopup()
	
	return 1


#check if it's this type based on the data
def noepyCheckType(data):
	if len(data) < 8:
		return 0
	return 1

#load the model
def noepyLoadModel(data, mdlList):

	bs = NoeBitStream(data)
	
	fileDir=rapi.getDirForFilePath(rapi.getInputName());
	texDir= os.path.join(fileDir, '../TEXTURE/')
	ctx = rapi.rpgCreateContext()
		
	rapi.rpgSetOption(noesis.RPGOPT_SWAPHANDEDNESS, 1)
		
	bs.seek(32, NOESEEK_ABS)

	nameLength=bs.readInt()
	MeshName = (bs.readBytes(nameLength).decode("ASCII").rstrip("\0"))
	print("MeshName ", MeshName)

	matrix = NoeMat43( ( 
		NoeVec3( (bs.readFloat(), bs.readFloat(), bs.readFloat()) ), 
		NoeVec3( (bs.readFloat(), bs.readFloat(), bs.readFloat()) ), 
		NoeVec3( (bs.readFloat(), bs.readFloat(), bs.readFloat()) ), 
		NoeVec3( (bs.readFloat(), bs.readFloat(), bs.readFloat()) ) 
		) 
	)
	
	rapi.rpgSetTransform(matrix)  

	bs.seek(24, NOESEEK_REL)#unk

	bs.seek(4, NOESEEK_REL) # 3 ??



	meshes = []
	numMeshesInObj = bs.readInt()
	#for i in range(0, numMeshesInObj):
	#	loadMesh(bs, rapi)

	#print(numMeshesInObj, "numMeshes")

	numChildsInObj= bs.readInt()
	#print(numChildsInObj, "numChildsInObj")
	for i in range(0, numChildsInObj):
		loadObj(bs, rapi)


	mdl = rapi.rpgConstructModel()

	# print(texList)
	# print(matList)

	#mdl.setModelMaterials(NoeModelMaterials(texList, matList))
	mdlList.append(mdl)
	
	rapi.rpgClearBufferBinds()
	return 1



def loadObj(bs, rapi):
	nameLength=bs.readInt()
	MeshName = (bs.readBytes(nameLength).decode("ASCII").rstrip("\0"))
	#print("MeshName ", MeshName)

	matrix = NoeMat43( ( 
		NoeVec3( (bs.readFloat(), bs.readFloat(), bs.readFloat()) ), 
		NoeVec3( (bs.readFloat(), bs.readFloat(), bs.readFloat()) ), 
		NoeVec3( (bs.readFloat(), bs.readFloat(), bs.readFloat()) ), 
		NoeVec3( (bs.readFloat(), bs.readFloat(), bs.readFloat()) ) 
		) 
	)

	rapi.rpgSetTransform(matrix)  
	#print (matrix)

	bs.seek(24, NOESEEK_REL)#unk

	bs.seek(4, NOESEEK_REL) # 3 ??

	meshes = []
	numMeshesInObj = bs.readInt()
	#print(numMeshesInObj, "numMeshes")
	for i in range(0, numMeshesInObj):
		loadMesh(bs, rapi)

		extraSomeBlocks= bs.readShort()	
		#print (extraSomeBlocks,"extraSomeBlocks")
		bs.seek(extraSomeBlocks * 2, NOESEEK_REL) 

		whoKnows= bs.readByte()
		#print (whoKnows,"who")
		
		if whoKnows == 1:
			size=16
			numberOfUnk= bs.readInt()
		else:
			size=28
			numberOfUnk= bs.readShort()

		#print (numberOfUnk *size)

		bs.seek( numberOfUnk *size, NOESEEK_REL) 

		

	numChildsInObj= bs.readInt()

	print("Obj :" ,MeshName,"numMeshes",numMeshesInObj, "numChildsInObj",numChildsInObj)	
	#print(bs.tell() ," POS PRE CHILD")

	#print(numChildsInObj, "numChildsInObj")
	for i in range(0, numChildsInObj):
		loadObj(bs, rapi)

	return 1	
	

def loadMesh(bs, rapi):
	bs.seek(15, NOESEEK_REL)#unk

	typeText= bs.readByte()

	#exceptions
	if typeText == 17:
		typeText=3
	elif typeText == 19:
		typeText=7
	elif typeText == 23:
		typeText=15


	#print(typeText, "numofText1")
	numberOfText=math.log(typeText+1,2)
	#print(numberOfText, "numofText2")

	for i in range(0, int(numberOfText)):
		nameLength=bs.readInt()
		MaterialName = (bs.readBytes(nameLength).decode("ASCII").rstrip("\0"))
		#print(MaterialName, "MaterialName")

	numBlocks= bs.readShort()
	#print(numBlocks, "numBlocks")

	VertBuff = bs.readBytes(numBlocks * 32)
	bs.seek(16, NOESEEK_REL)#uuid¿?

	extraInfo= bs.readByte()
	#print(bs.tell() ,"pos")
	if extraInfo>0:
		bs.seek(bs.readShort() * 12 * 4, NOESEEK_REL)
	#print(bs.tell() ,"pos")	
	numTris= bs.readShort()
	#print(numTris, "numTris")
	#print(bs.tell() ,"pos")
	TrisBuff =  bs.readBytes(numTris * 2)

	rapi.rpgBindPositionBufferOfs(VertBuff, noesis.RPGEODATA_FLOAT, 32, 0)

	rapi.rpgCommitTriangles(TrisBuff, noesis.RPGEODATA_USHORT, numTris, noesis.RPGEO_TRIANGLE, 1)

	

	bs.seek(2, NOESEEK_REL) #FF
	#print(bs.tell() ,"pos")
	return 1


