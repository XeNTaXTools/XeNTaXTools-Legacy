* Pre-compiled PackagesLexer.dll from Deathmax's WFPackageParser project - https://github.com/Deathmax/WFPackageParser/
* Included getdata.ps1 Powershell script to automate the process of using PackagesLexer.dll
(!) The PackagesLexer.dll may require .NET 4.0/4.5
-------------

- Extract the compressed folder to anywhere
- Copy Packages.bin and Languages.bin to the newly extracted folder
- Run the Powershell script (getdata.ps1) or open Powershell, navigate to the extracted folder, and run the commands from getdata.ps1 one at a time.
	* You may receive quick closure of the Powershell window. This is NORMAL BEHAVIOR, but it means the script did not run. Default security settings disallow scripts.
		+ To resolve, run Powershell as Admin then execute this command: Set-ExecutionPolicy RemoteSigned
			+ When asked, enter Y to confirm the new setting. Rerun the script afterwards

		+ Documentation about the above security: http://www.adminarsenal.com/admin-arsenal-blog/powershell-how-to-write-your-first-powershell-script/


	(!) If the above is uncomfortable: open a normal Powershell window, navigate to the newly extracted folder, then run these commands one at a time:

		$absolutePath= (Get-Item -Path ".\" -Verbose).FullName
		[Reflection.Assembly]::LoadFile($absolutePath+"\PackagesLexer.dll");
		$PackagesLexer= New-Object "PackagesLexer.Packages" ($absolutePath+"\Packages.bin")
		$LanguagesLexer= New-Object "PackagesLexer.Languages" ($absolutePath+"\Languages.bin")
		$PackagesLexer > Packages.txt
		$LanguagesLexer > Languages.txt


	(!) What are those commands doing?!

		$absolutePath= (Get-Item -Path ".\" -Verbose).FullName
			* This is getting the full path name of where you are in Powershell, required for the next three lines.

		[Reflection.Assembly]::LoadFile($absolutePath+"\PackagesLexer.dll");
			* Here we manually loading PackagesLexer.dll into Powershell's Assembly "memory"

		$PackagesLexer= New-Object "PackagesLexer.Packages" ($absolutePath+"\Packages.bin")
			* Next, load the non-static function of classname: PackagesLexer function:Packages and tell it to use the string "Packages.bin"

		$LanguagesLexer= New-Object "PackagesLexer.Languages" ($absolutePath+"\Languages.bin")
			* Then, load the non-static function of classname: PackagesLexer function:Languages and tell it to use the string "Languages.bin"

		$PackagesLexer > Packages.txt
			* Execute the Packages function and store the output into Packages.txt within the same folder

		$LanguagesLexer > Languages.txt
			* Execute the Languages function and store the output into Languages.txt within the same folder
