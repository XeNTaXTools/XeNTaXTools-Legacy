$absolutePath= (Get-Item -Path ".\" -Verbose).FullName
[Reflection.Assembly]::LoadFile($absolutePath+"\PackagesLexer.dll");
$PackagesLexer= New-Object "PackagesLexer.Packages" ($absolutePath+"\Packages.bin")
$LanguagesLexer= New-Object "PackagesLexer.Languages" ($absolutePath+"\Languages.bin")
$PackagesLexer > Packages.txt
$LanguagesLexer > Languages.txt