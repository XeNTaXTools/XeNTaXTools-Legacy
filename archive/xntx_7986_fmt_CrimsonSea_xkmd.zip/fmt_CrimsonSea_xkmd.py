#  Crimson Sea/Dynasty Warriros 3 XKMD importer by Bigchillghost
from inc_noesis import *
import copy

def registerNoesisTypes():
	handle = noesis.register("Crimson Sea XKMD", ".XKMD")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadModel(handle, noepyLoadModel)
	#noesis.logPopup()
	return 1

#check if it's this type based on the data
def noepyCheckType(data):
	if len(data) < 0x80:
		return 0
	bs = NoeBitStream(data)
	if bs.readBytes(4) != b'XKMD':
		return 0
	return 1

def debugPrint(str):
	#print(str)
	pass

#load the model
def noepyLoadModel(data, mdlList):
	#noesis.logPopup()
	bs = NoeBitStream(data)
	actualSize = bs.getSize()
	bs.seek(8, NOESEEK_ABS)
	fileSize = bs.readUInt()
	headerSize = bs.readUInt()
	baseOffset = 0
	if actualSize - fileSize == 8:
		baseOffset = 4
	bs.seek(8, NOESEEK_REL)
	bs.seek(0x18, NOESEEK_REL) # BBox
	matrixCount = bs.readUInt()
	matrixAddress = bs.readUInt()
	boneCount = bs.readUInt()
	boneAddress = bs.readUInt() # stride == 40
	for i in range(0, 2):
		bs.seek(4, NOESEEK_REL)
		meshInfoTableAddress = bs.readUInt() # stride == 44
	meshCount = bs.readUInt()
	subMesh1Count = bs.readUInt()
	subMesh2Count = bs.readUInt()
	subMeshCount = subMesh1Count + subMesh2Count
	
	vertAttrFlag = [0]*meshCount
	vertStride = [0]*meshCount
	vertCount = [0]*meshCount
	vertAddress = [0]*meshCount
	indexCount = [0]*meshCount
	indexAddress = [0]*meshCount
	debugPrint('meshRec at %#x, sizeof=52'%bs.tell())
	for i in range(0, meshCount):
		vertAttrFlag[i] = bs.readUInt()
		vertStride[i] = bs.readUInt()
		vertCount[i] = bs.readUInt()
		vertAddress[i] = bs.readUInt() + baseOffset
		bs.seek(0x10, NOESEEK_REL)
		indexCount[i] = bs.readUInt()
		indexAddress[i] = bs.readUInt()
		bs.seek(0xC, NOESEEK_REL)
	recAddress = [0]*subMeshCount
	debugPrint('recAddresses at %#x, sizeof=4'%bs.tell())
	for i in range(0, subMeshCount):
		recAddress[i] = bs.readUInt()
	
	# transform matrix
	matList = []
	debugPrint('matrixAddress %x, sizeof=64'%matrixAddress)
	bs.seek(matrixAddress, NOESEEK_ABS)
	for i in range(0, matrixCount):
		boneMat = NoeMat44.fromBytes(bs.readBytes(0x40)).toMat43().inverse()
		#debugPrint(boneMat)
		matList.append(boneMat)
	primaryLinkTable = [0]*matrixCount
	for i in range(0, matrixCount):
		boneIndex = bs.readUShort()
		parentIndex = bs.readUShort()
		if parentIndex == 0xFFFF:
			primaryLinkTable[i] = boneIndex
		else:
			primaryLinkTable[i] = parentIndex
	
	# bone info
	bones = [ NoeBone(0, '', NoeMat43(), None, -1) ]*boneCount
	debugPrint('boneAddress %x, sizeof=40'%boneAddress)
	bs.seek(boneAddress, NOESEEK_ABS)
	for i in range(0, boneCount):
		boneIndex = bs.readUShort()
		parentIndex = bs.readUShort()
		boneName = "bone%d"%i
		if parentIndex == 0xFFFF: parentIndex = -1
		scale = NoeVec3.fromBytes(bs.readBytes(12))
		scal = NoeMat43()
		scal[0][0] = scale[0]
		scal[1][1] = scale[1]
		scal[2][2] = scale[2]
		rot = NoeAngles.fromBytes(bs.readBytes(12))
		tran = NoeVec3.fromBytes(bs.readBytes(12))
		boneMat = rot.toDegrees().toMat43_XYZ()
		boneMat = boneMat * scal
		boneMat[3] = tran
		bones[i] = NoeBone(i, boneName, boneMat, None, parentIndex)
	# Converting local matrix to world space
	bones = rapi.multiplyBones(bones)
	#for i in range(boneCount, matrixCount):
	#	boneName = "bone%d"%i
	#	parentIndex = primaryLinkTable[i]
	#	if parentIndex == 0xFFFF: parentIndex = -1
	#	bones.append( NoeBone(i, boneName, matList[i], None, parentIndex) )
	rawIdxChunks = []
	for i in range(0, meshCount):
		debugPrint('indexAddress[%d] %x, indexCount %x'%(i, indexAddress[i], indexCount[i]))
		bs.seek(indexAddress[i], NOESEEK_ABS)
		idxChunk = bs.readBytes(indexCount[i]*2)
		rawIdxChunks.append(idxChunk)
	rawVertChunks = []
	for i in range(0, meshCount):
		debugPrint('vertAddress[%d] %x'%(i, vertAddress[i]))
		bs.seek(vertAddress[i], NOESEEK_ABS)
		vertChunk = bs.readBytes(vertStride[i]*vertCount[i])
		rawVertChunks.append(vertChunk)
	
	submeshRec = []
	for i in range(0, subMeshCount):
		debugPrint('recAddress[%d] %x'%(i, recAddress[i]))
		bs.seek(recAddress[i], NOESEEK_ABS)
		boneID = bs.readUShort()
		blendWgtCnt = bs.readUByte()
		matrixStride = bs.readUByte()
		bs.seek(4, NOESEEK_REL)
		matIds = [0]*4
		for j in range(0, 4):
			matIds[j] = bs.readUShort()
		meshGroupID = bs.readUInt()
		subFragmentCnt = bs.readUInt()
		for k in range(0, subFragmentCnt):
			faceEncoding = bs.readUInt()
			begVertOffset = bs.readUInt()
			subMeshIndexCount = bs.readUInt()
			begIndexOffset = bs.readUInt()
			faceCount = bs.readUInt()
			submeshRec.append([meshGroupID, begVertOffset, begIndexOffset, \
			subMeshIndexCount, boneID, blendWgtCnt, matIds, faceEncoding, faceCount])
	submeshRec.sort(key=lambda x:(x[0],x[1]))
	debugPrint('sorted:')
	subMeshCount = len(submeshRec)
	for i in range(0, subMeshCount):
		debugPrint(submeshRec[i])
	
	idx = 0
	idxChunks = []
	vertChunks = []
	# meshes
	ctx = rapi.rpgCreateContext()
	for i in range(0, meshCount):
		vbs = NoeBitStream(rawVertChunks[i])
		ibs = NoeBitStream(rawIdxChunks[i])
		posList = []
		normList = []
		vertCnt = vertCount[i]
		flagList = [False]*vertCnt
		uvData = bytearray()
		blendWgtData = bytearray()
		blendIdxData = bytearray()
		bid = submeshRec[idx][4]
		blendWgtCnt = submeshRec[idx][5]
		if bid > 0:
			for j in range(0, vertCnt):
				position = NoeVec3.fromBytes(vbs.readBytes(12))
				if blendWgtCnt > 0: # should be implicit weight, just in case
					vbs.seek((blendWgtCnt-1)*4, NOESEEK_REL)
				normal = NoeVec3.fromBytes(vbs.readBytes(12))
				vbs.seek(4, NOESEEK_REL)
				uvData += NoeVec3([vbs.readFloat(), vbs.readFloat(), 0.0]).toBytes()
				posList.append(position)
				normList.append(normal)
			blendIdxData += struct.pack('<H', bid) * vertCnt
			blendWgtData += b'\x00\x00\x80\x3F' * vertCnt
			blendWgtCnt = 1
		else:
			for j in range(0, vertCnt):
				position = NoeVec3.fromBytes(vbs.readBytes(12))
				wgts = []
				implicitW = 1.0
				cnt = blendWgtCnt-1
				for k in range(0, cnt):
					weight = vbs.readFloat()
					implicitW -= weight
					wgts.append(weight)
				wgts.append(implicitW)
				normal = NoeVec3.fromBytes(vbs.readBytes(12))
				vbs.seek(4, NOESEEK_REL)
				uvData += NoeVec3([vbs.readFloat(), vbs.readFloat(), 0.0]).toBytes()
				posList.append(position)
				normList.append(normal)
				blendWgtData += struct.pack("<" + 'f'*blendWgtCnt, *wgts)
			matIds = submeshRec[idx][6]
			bIds = [0]*blendWgtCnt
			for j in range(0, blendWgtCnt):
				bIds[j] = primaryLinkTable[matIds[j]]
			blendIdxData += struct.pack("<" + 'H'*blendWgtCnt, *bIds ) * vertCnt
		
		idxList = []
		indexCnt = 0
		while idx < subMeshCount:
			if submeshRec[idx][0] != i:
				break
			begIndexOffset = submeshRec[idx][2]*2
			subMeshIndexCount = submeshRec[idx][3]
			faceEncoding = submeshRec[idx][7]
			debugPrint('[%d][%d] begIndexOffset %x, subMeshIndexCount %x'%(i, idx, begIndexOffset,subMeshIndexCount))
			ibs.seek(begIndexOffset, NOESEEK_ABS)
			idxSet = set()
			if faceEncoding == 6: # strips
				for j in range(0, subMeshIndexCount): 
					vertID = ibs.readUShort()
					idxList.append(vertID)
					idxSet.add(vertID)
				idxList.append(65535)
			elif faceEncoding == 5: # triangles
				faceCount = submeshRec[idx][8]
				for j in range(0, faceCount): 
					for k in range(0, 3): 
						vertID = ibs.readUShort()
						idxList.append(vertID)
						idxSet.add(vertID)
					idxList.append(65535)
			bid = submeshRec[idx][4]
			if bid > 0:
				lMat = bones[bid].getMatrix()
				rotMat = copy.copy(lMat)
				rotMat[3] = NoeVec3()
				for vertID in idxSet:
					if not flagList[vertID]:
						posList[vertID] = lMat * posList[vertID]
						normList[vertID] = rotMat * normList[vertID]
						flagList[vertID] = True
			idx += 1
		posData = bytearray()
		nmData = bytearray()
		for j in range(0, vertCnt):
			posData += posList[j].toBytes()
			nmData += normList[j].toBytes()
		indexCnt = len(idxList)
		idxData = struct.pack("<" + 'H'*indexCnt, *idxList)
		debugPrint('new indexCount[%d] %x'%(i, indexCnt))
		rapi.rpgSetName("mesh%d"%i)
		rapi.rpgBindPositionBuffer(posData, noesis.RPGEODATA_FLOAT, 0xC)
		rapi.rpgBindNormalBuffer(nmData, noesis.RPGEODATA_FLOAT, 0xC)
		rapi.rpgBindUV1Buffer(uvData, noesis.RPGEODATA_FLOAT, 0xC)
		rapi.rpgBindBoneIndexBuffer(blendIdxData, noesis.RPGEODATA_USHORT, 2, blendWgtCnt)
		rapi.rpgBindBoneWeightBuffer(blendWgtData, noesis.RPGEODATA_FLOAT, 4, blendWgtCnt)
		rapi.rpgCommitTriangles(idxData, noesis.RPGEODATA_USHORT, indexCnt, noesis.RPGEO_TRIANGLE_STRIP, 1)
		rapi.rpgClearBufferBinds()
	
	mdl = rapi.rpgConstructModelSlim()
	mdl.setBones(bones)
	mdlList.append(mdl)
	#rapi.setPreviewOption("setAngOfs", "0 -90 0")
	
	return 1
