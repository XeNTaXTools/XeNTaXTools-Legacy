// provided as is. Use it or ignore it. Maybe write better code than me but don't complain because: it works, bud
#include <windows.h>
#include <stdio.h>		// FILE

//#include <iostream>   // well, will blow up the exe for nothing here;-)

using namespace std;

void lin_faceind_3(FILE *stream, DWORD cnt)
{
	DWORD i ;			//

	for (i=1; i< (cnt - 3);i++) {
		 fprintf( stream, "f %ld/%ld %ld/%ld %ld/%ld\n", i,i, i+1,i+1, i+2,i+2) ;
		 i += 2 ;
	}
}

DWORD GetWebgl_ASCII(FILE *stream, BYTE wahl)
{
	FILE * stream1 ;        //
	//char  s[512] ;		// in extrahierten vertices und faces - txt files: ',' ersetzt durch blank f�r fscanf()
	//BYTE wahl= 1 ;		// 0,1,2: faces, vertices, uvs
	DWORD cnt=0 ;
	float x, y, z ;

	switch (wahl) {
		case 1: stream1 = fopen( "vertices.txt", "r" ); break ;              //
		case 2: stream1 = fopen( "uvs.txt", "r" ); break ;              //
		default: return 0 ;
	}
	if( stream1 == NULL ) {
		fprintf( stream, " The file ???.txt could not be opened!\n");
		printf(" The file ???.txt could not be opened!\n");
		return 0 ;
	}
	if (wahl==1) goto x ;
	if (wahl==2) goto y ;

x:
	while (fscanf( stream1, "%f", &x) != EOF) {
		fscanf( stream1, "%f %f", &y, &z) ;
		fprintf(stream, "v %f %f %f\n", x,y,z) ; // x*10.0 ?
		cnt++ ;
		if (cnt>3000000) break ;
	}
	fclose (stream1) ;
	return cnt ;

y:
	while (fscanf( stream1, "%f", &x) != EOF) {
		fscanf( stream1, "%f", &y) ;
		fprintf(stream, "vt %f %f\n", x,y) ;
		cnt++ ;
	}
	fclose (stream1) ;
	return cnt ;
}


int main()
{
    FILE * stream ;
    DWORD cnt, vCnt ;

    stream = fopen( "test.obj", "w" );
    if( stream == NULL ) {
        printf("'test.obj' open error!\n") ;
        return (FALSE) ;
    }
    vCnt= GetWebgl_ASCII(stream, 1) ;         // log vertices
    cnt= GetWebgl_ASCII(stream, 2) ;         // log uvs
    if ((vCnt==0)||(cnt==0)) printf("\nerror, count is zero: %ld verts, %ld uvs !\n", vCnt, cnt) ;
    if (cnt!=vCnt) printf("\nproblem: %ld verts, %ld uvs !\n", vCnt, cnt) ;
    if (vCnt>cnt) vCnt= cnt ;                   // "fix: "better than nothing
    lin_faceind_3(stream, vCnt) ;
    fclose(stream) ;
    //cout << "Hello world!" << endl;
    return 0;
}
