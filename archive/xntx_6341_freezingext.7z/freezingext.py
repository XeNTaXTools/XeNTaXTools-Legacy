from urllib.request import ProxyHandler, build_opener, install_opener, urlretrieve
import lz4
from itertools import islice
from multiprocessing.dummy import Pool as ThreadPool
import os
import struct
import json


pool = ThreadPool(100)

if not os.path.exists("freezingext"):
	os.makedirs("freezingext")
	manifestURL = 'http://download.freezingext.co.kr/FreezingCDN/Google/0.0.12/Live/assetbundles/BundleSizeInfos.json'
	urlretrieve(manifestURL, 'freezingext\\' + 'BundleSizeInfos.json')


	
def geturl(link,file):
	try:
		pass
		#print(file,link)
		#baseDir = '\\'.join((file).split('_')[0:-1]) + '\\'
		#if not os.path.exists('MillionLive\\' + baseDir):
		#	os.makedirs('MillionLive\\' + baseDir)
		urlretrieve(link, 'freezingext\\' + file)
		print('freezingext\\' + file)
	except:
		pass

with open('freezingext\\' + 'BundleSizeInfos.json', "rb" ) as f:
	fileName = []
	urlLink = []
	baseURL = 'http://download.freezingext.co.kr/FreezingCDN/Google/0.0.12/Live/assetbundles/'
	data = json.load(f)
	for i in data:
		if 'BundleName' in i:
			fileURL = baseURL + i['BundleName']
			fileName.append(i['BundleName'])
			urlLink.append(fileURL)
			#print(fileURL)

	pool.starmap(geturl, zip(urlLink,fileName) )	
	



