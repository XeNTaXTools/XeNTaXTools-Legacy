from inc_noesis import *
import os

def registerNoesisTypes():
	handle = noesis.register("G.I.Joe: Rise of Cobra (PS3)", ".tfo")
	noesis.setHandlerTypeCheck(handle, GIJCheckType)
	noesis.setHandlerLoadRGBA(handle, GIJLoadRGBA)
	#noesis.logPopup()
	return 1

#check if it's this type based on the data
def GIJCheckType(data):
	bs = NoeBitStream(data)
	Magic = bs.readBytes(8)
	print(Magic, "Magic")
	if Magic != b'\x00\x00\x00\x00\x00\x00\x00\x01':
		return 0
	return 1
	
def GIJLoadRGBA(data, texList):
	bs = NoeBitStream(data)
	bs.setEndian(NOE_BIGENDIAN)
	bs.seek(0x08, NOESEEK_ABS)
	imgWidth = bs.readUShort()            
	print(imgWidth, "imgWidth")
	imgHeight = bs.readUShort()           
	print(imgHeight, "imgHeight")
	bs.seek(0x1c, NOESEEK_ABS)
	imgFmt = bs.readInt()
	print(imgFmt, "imgFmt")
	bs.seek(0x70, NOESEEK_ABS)        
	texPath = bs.readString()
	print(texPath)
	endHeader = bs.tell()
	print(hex(endHeader), "end of header")
	datasize = len(data) - endHeader        
	bs.seek(endHeader, NOESEEK_ABS)        
	data = bs.readBytes(datasize)      
	#DXT1
	if imgFmt == 0x01:
		texFmt = noesis.NOESISTEX_DXT1
	#DXT3?
	elif imgFmt == 0x03:
		texFmt = noesis.NOESISTEX_DXT3
	#DXT5
	elif imgFmt == 0x05:
		texFmt = noesis.NOESISTEX_DXT5
	#unknown, not handled
	else:
		print("Error: Unsupported image format")
		return None
	texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
	return 1