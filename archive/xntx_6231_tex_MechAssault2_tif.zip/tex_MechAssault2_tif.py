from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("MechAssault 2", ".tif")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    bs.seek(0x4, NOESEEK_ABS)
    if noeStrFromBytes(bs.readBytes(4)) != 'MGIc': return 0
    bs.seek(0x20, NOESEEK_ABS)
    if noeStrFromBytes(bs.readBytes(4)) != 'PIC ': return 0
    return 1
    
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.seek(0x42, NOESEEK_ABS)       
    imgFmt = bs.readBits(4)
    print(imgFmt, ":imgFmt")
    bs.readBits(4)
    bs.seek(0x4d, NOESEEK_ABS)         
    imgWidth = bs.readUInt()            
    bs.seek(0x59, NOESEEK_ABS)         
    imgHeight = bs.readUInt()
    print(imgWidth, "x", imgHeight)
    bs.seek(0x71, NOESEEK_ABS)         
    datasize = bs.readUInt()
    bs.seek(0x95, NOESEEK_ABS)         
    data = bs.readBytes(datasize)      
    #RGBA8888 morton order swizzled
    if imgFmt == 0:
        untwid = bytearray()
        for x in range(imgWidth):
            for y in range(imgHeight):
                idx = noesis.morton2D(x, y)
                untwid += data[idx * 4:idx * 4 + 4]
        data = rapi.imageDecodeRaw(untwid, imgWidth, imgHeight, "b8 g8 r8 p8") #a8g8b8r8
        texFmt = noesis.NOESISTEX_RGBA32
    #DXT1
    elif imgFmt == 1:
        texFmt = noesis.NOESISTEX_DXT1
    #DXT3
    elif imgFmt == 3:
        texFmt = noesis.NOESISTEX_DXT3
    #DXT5
    elif imgFmt == 5:
        texFmt = noesis.NOESISTEX_DXT5
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1