from inc_noesis import *
import sys
import ast

def registerNoesisTypes():
    handle = noesis.register("HP MA 2D", ".dat")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)
    
    noesis.logPopup()
    return 1

def noepyCheckType(data):
    if '{' in data.decode().split('\n')[0]:
        return 1
    return 0     

def noepyLoadModel(data, mdlList):
    tx_config = os.path.join(rapi.getDirForFilePath(rapi.getOutputName()), '00000541.txt')
    tx_name = '00000539.png'
    
    dict_uv = {}
    if rapi.checkFileExists(tx_config):
        with open(tx_config, 'r') as file:
            dict_uv = parseTxConfig(file.readlines())
            
    dictionary = ast.literal_eval(data.decode())
    
    meshes = []
    for x in dictionary['skins']:
        for a in x['attachments']:
            for name in x['attachments'][a]:
                attach = x['attachments'][a][name]
                
                try: posX = attach['x']
                except: posX = None
                
                try: posY = attach['y']
                except: posY = None
                
                try: height = attach['height']
                except: height = None
                
                try: width = attach['width']
                except: width = None
                
                if posX and posY and height and width:
                    try: info = dict_uv[name]
                    except: info = None
                    
                    if info:
                        if ['rotate']: height, width = width, height
                    
                    mesh = createQuad(name, posX, posY, height, width)
                    try: mesh.setUVs(setQuadUV(dict_uv[name]['xy'], dict_uv[name]['size']))
                    except: pass
                    meshes.append(mesh)
                else:
                    try: custom_uv = [dict_uv[name]['xy'], dict_uv[name]['size']]
                    except: custom_uv = [[0,0],[0,0]]
                    mesh = createCustomMesh(name, attach, custom_uv)
                    if mesh:
                        meshes.append(mesh)
                    
    bones = []
    for x in dictionary['bones']:
        try: parent = x['parent']
        except: parent = None
        mat = NoeMat43()
        
        try: posX = x['x']
        except: posX = 0
        
        try: posY = x['y']
        except: posY = 0
        
        try: scaleX = x['scaleX']
        except: scaleX = 1
        
        try: scaleY = x['scaleY']
        except: scaleY = 1
        
        mat[3] = NoeVec3([posX, posY, 0])
        mat[0][0] = scaleX
        mat[1][1] = scaleY
        
        bones.append(NoeBone(len(bones), x['name'], mat, parent))

    for x in dictionary['slots']:
        bID = getID(bones, x['bone'])
        mID = getID(meshes, x['attachment'])
        
        if bID != -1 and mID != -1:
            boneMat = bones[bID].getMatrix()
            
            for x in range(len(meshes[mID].positions)):
                meshes[mID].positions[x] = boneMat.transformPoint(meshes[mID].positions[x])
            meshes[mID].setWeights([NoeVertWeight([bID],[1.0])]*len(meshes[mID].positions))
            
    anims = []
    for name in dictionary['animations']:
        anim = dictionary['animations'][name]
        for b in anim['bones']:
            bone = anim['bones'][b]
            print(">>>translate", bone['translate'])
            print(">>>rotate", bone['rotate'])
            print(">>>scale", bone['scale'])
    
    mdl = NoeModel(meshes)
    mdl.setBones(bones)
    mdl.setModelMaterials(NoeModelMaterials([], [NoeMaterial("default",tx_name)]))
    mdlList.append(mdl)
    return 1

def getID(arr, name):
    index = -1
    for i, item in enumerate(arr):
        if name in item.name:
            index = i
            break
    return index

def setQuadUV(xy, size):
    uv =  [
    NoeVec3([xy[0], xy[1], 0]),
    NoeVec3([xy[0], xy[1]+size[1], 0]),
    NoeVec3([xy[0]+size[0], xy[1]+size[1], 0]),
    NoeVec3([xy[0]+size[0], xy[1], 0])]
    return uv

def createQuad(name, x, y, height, width):
    tris = [2, 1, 0, 3, 2, 0]
    
    mat = NoeMat43()
    mat[3] = NoeVec3([x, y, 0])
    
    vertices = [
    mat.transformPoint(NoeVec3([-width/2, -height/2, 0])),
    mat.transformPoint(NoeVec3([-width/2, height/2, 0])),
    mat.transformPoint(NoeVec3([width/2, height/2, 0])),
    mat.transformPoint(NoeVec3([width/2, -height/2, 0]))]
    
    uv = setQuadUV([0,0],[1,-1])
    
    mesh = NoeMesh(tris, vertices, name)
    mesh.setUVs(uv)
    return mesh

def createCustomMesh(name, attach, custom_uv):
    global sizeTx

    posX, posY = custom_uv[0]
    sizeX, sizeY  = [int(custom_uv[1][0]*sizeTx[0]), int(custom_uv[1][1]*sizeTx[1])]
    
    try: uvs = attach['uvs']
    except: uvs = None
    
    try: triangles = attach['triangles']
    except: triangles = None
    
    if uvs and triangles:
        uv = []
        vertices = []
        for x in range(0,len(uvs),2):
            uv.append(NoeVec3([posX+(uvs[x]*sizeX)/sizeTx[0], posY+(uvs[x+1]*sizeY)/sizeTx[1], 0]))
            vertices.append(NoeVec3([(uvs[x]*sizeX)-(sizeX/2),-((uvs[x+1]*sizeY)-(sizeY/2)),0]))
        
        triangles = FlipFace(triangles)
        
        mesh = NoeMesh(triangles, vertices, name)
        mesh.setUVs(uv)
        return mesh

    return None

def parseTxConfig(data):
    nameTx = data[1].strip()
    global sizeTx
    sizeTx = [int(x) for x in data[2].split(':')[1].split(',')]
    dict = {}
    objects = data[6:]
    for x in range(len(objects)//7):
        name = objects[x*7].strip()
        
        rotate = True if 'true' in objects[x*7+1] else False
        posX, posY = [int(x) for x in objects[x*7+2].split(':')[1].split(',')]
        sizeX, sizeY = [int(x) for x in objects[x*7+3].split(':')[1].split(',')]
        size = [sizeX/sizeTx[0],sizeY/sizeTx[1]]
        size = size[::-1] if rotate else size
        orig = objects[x*7+4]
        offset = objects[x*7+5]
        index = objects[x*7+6]
        dict[name] = {'xy':[posX/sizeTx[0],posY/sizeTx[1]],'size': size, 'rotate':rotate}
    return dict
    
def FlipFace(indices):
    flipTriangles = []
    
    for x in range(0, len(indices), 3):
        flipTriangles += indices[x:x+3][::-1]
    
    return flipTriangles