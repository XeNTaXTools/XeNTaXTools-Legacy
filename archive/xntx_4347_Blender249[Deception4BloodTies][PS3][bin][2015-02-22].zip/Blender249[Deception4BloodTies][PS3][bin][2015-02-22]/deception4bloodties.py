import newGameLib
from newGameLib import *
import Blender	



def g1tParser(filename,g):
	#g.debug=True
	g.endian='>'
	g.word(4)
	g.word(4)
	w = g.i(4)
	g.seek(w[1])	
	for m in range(w[3]):
		t=g.tell()
		offsetList=g.i(w[2])
		for n in range(w[2]):
			#print n,offsetList[n]
			g.seek(w[1]+offsetList[n])
			v=g.H(10)
			#print n,v
			img=imageLib.Image()
			if v[0]==257:   
				img.format='tga32'
			elif v[0]==264:   
				img.format='DXT5'
			elif v[0]==774:   
				img.format='DXT1'
			elif v[0]==776:   
				img.format='DXT5'
			elif v[0]==2054:  
				img.format='DXT1'
			elif v[0]==2056:  
				img.format='DXT5'
			elif v[0]==1800:  
				img.format='DXT5'
			elif v[0]==2310:  
				img.format='DXT1'
			elif v[0]==2312:  
				img.format='DXT5'
				
			elif v[0]==1798:  
				img.format='DXT1'
			elif v[0]==1544:  
				img.format='DXT5'
			elif v[0]==1542:  
				img.format='DXT1'
			elif v[0]==1288:  
				img.format='DXT5'
			elif v[0]==1286:  
				img.format='DXT1'
				
			elif v[0]==1032:  
				img.format='DXT5'
				
			elif v[0]==2568:  
				img.format='DXT5'
			elif v[0]==2566:  
				img.format='DXT1'
				
				
				
				
			else:
				print 'WARNING: nieznany format',v[0]	
			if v[1]==26112:
				img.szer=64
				img.wys=64
			elif v[1]==34816:
				img.szer=256
				img.wys=256
				
			elif v[1]==30464:
				img.szer=128
				img.wys=128
				
			elif v[1]==43520:
				img.szer=1024
				img.wys=1024
			elif v[1]==43264:
				img.szer=1024
				img.wys=512
				
			elif v[1]==39168:
				img.szer=512
				img.wys=512
				
			elif v[1]==39169:
				img.szer=512
				img.wys=512
				
			elif v[1]==39424:
				img.szer=512
				img.wys=1024
				
			elif v[1]==39425:
				img.szer=512				
				img.wys=512
				
			elif v[1]==38912:
				img.szer=512
				img.wys=256
			elif v[1]==43776:
				img.szer=1024
				img.wys=1024
			elif v[1]==47872:
				img.szer=2048
				img.wys=2048
			elif v[1]==47616:
				img.szer=2048
				img.wys=1024
				
				
			elif v[1]==34560:
				img.szer=256
				img.wys=128
			elif v[1]==26368:
				img.szer=64
				img.wys=128
			elif v[1]==43008:
				img.szer=128
				img.wys=128
				
			elif v[1]==34304:
				img.szer=128
				img.wys=128				
			elif v[1]==29952:
				img.szer=64
				img.wys=64	
						
			elif v[1]==8704:
				img.szer=64
				img.wys=64	
						
			elif v[1]==43521:
				img.szer=1024
				img.wys=1024
						
			elif v[1]==47873:
				img.szer=2048
				img.wys=2048
						
			elif v[1]==17408:
				img.szer=2048
				img.wys=2048
						
			elif v[1]==34817:
				img.szer=256
				img.wys=256
				
			else:
				print 'WARNING: nieznane wymiary',v[1]	
			if v[3]==4608:
				g.seek(-12,1)	
				header=8
			else:
				header=20
			img.name=g.dirname+os.sep+'textures'+os.sep+str(n)+'.dds'
			if n<w[2]-1:
				img.data=g.read(offsetList[n+1]-offsetList[n])
			else:
				img.data=g.read(g.fileSize()-offsetList[n]) 
			img.draw()
			#break
			
	g.tell()


def binParser(filename,g):
	g.endian='>'
	g.word(4)
	A=g.i(9)
	fileList=[]
	for m in range(A[1]):
		B=g.i(3)
		tm=g.tell()
		g.seek(B[2])
		fileList.append(g.find('\x00'))
		g.seek(tm)	
	return fileList
	
def archiveParser(filename,g,fileList):
	g.endian='>'	
	g.word(4)
	A=g.i(7)
	for m in range(A[2]):
		B=g.q(4)
		path=g.dirname+fileList[m]
		print fileList[m]
		try:os.makedirs(os.path.dirname(path))
		except:pass
		new=open(path,'wb')
		t=g.tell()
		g.seek(B[0])
		data=g.read(B[2])
		new.write(data)
		new.close()
		g.seek(t)
	
		

def section8(g):
	count=g.i(1)[0]
	for m in range(count):
		g1m.meshInfoList.append(g.i(14))

		
def section7(g):
	count=g.i(1)[0]
	for m in range(count):
		stream=Stream()
		v=g.i(3)
		stream.elementCount=v[0]
		if v[1]==16:
			stream.strideSize=2
		elif v[1]==32:
			stream.strideSize=4
		else:
			print 'WARNING: nieznany rozmiar indice',v[1]   
		stream.offset=g.tell()  
		g.seek(stream.elementCount*stream.strideSize,1) 
		g1m.indiceStreamList.append(stream)

def section6(g):
	count=g.i(1)[0]
	for m in range(count):
		List=[]
		for n in range(g.i(1)[0]):
			g.i(1)
			#List.append(str(g.i(1)[0]))
			g.f(1)
			List.append(str(g.H(2)[1]))
		g1m.boneMapList.append(List)	
	
class Stride:
	def __init__(self):
		self.count=None 
		self.list=[]
	
class VertElement:
	def __init__(self):
		self.streamID=None
		self.offset=None
		self.unk0=None
		self.unk1=None
		self.unk2=None
		self.unk3=None

def section5(g):
	count=g.i(1)[0]
	for m in range(count):
		streamList=g.i(g.i(1)[0])		   
		stride=Stride() 
		count=g.i(1)[0]
		stride.count=count
		for n in range(count):
			element=VertElement()
			element.streamID=streamList[g.H(1)[0]]
			element.offset=g.H(1)[0]
			element.unk0=g.b(1)[0]
			element.unk1=g.b(1)[0]
			element.unk2=g.b(1)[0]
			element.unk3=g.b(1)[0]
			stride.list.append(element)
		g1m.strideList.append(stride)
			
	
	
class Stream:
	def __init__(self):
		self.unk0=None
		self.strideSize=None
		self.elementCount=None
		self.unk1=None
		self.offset=None


def section4(g):
	count=g.i(1)[0]
	for m in range(count):
		stream=Stream()
		stream.unk0=g.i(1)[0]
		stream.strideSize=g.i(1)[0]
		stream.elementCount=g.i(1)[0]
		stream.unk1=g.i(1)[0]
		stream.offset=g.tell()
		g1m.vertStreamList.append(stream)
		g.seek(stream.elementCount*stream.strideSize,1)	

def section3(g):
	#g.debug=True
	g.tell()
	for n in range(g.i(1)[0]):
		#print 
		for m in range(g.i(1)[0]):
			w=g.i(3)
			v=g.h(2)
			g.word(w[1])
			g.f(v[0])
	g.tell()	
	#print ghghgh	
	
	
def section2(g):
	count=g.i(1)[0]
	for m in range(count):
		w=g.i(4)
		mat=Mat()
		List=[]
		#print w
		for n in range(w[1]):
			List.append(g.b(12))
			#print n,List[n]
		mat.diffuse=g.dirname+os.sep+'textures'+os.sep+str(List[0][1])+'.dds'
		if w[1]==4:mat.ao='textures'+os.sep+str(List[1][1])+'.dds'
			
		#g1m.matList.append(mat)
		g1m.textureList.append(List)

	
def section1(g):
	count=g.i(1)[0]
	for m in range(count):
		g.b(4)
		g.f(7)
		g.b(4)
		g.f(7)

def G1MGParser(g):
	g.word(4)
	g.f(7)
	count=g.i(1)[0]
	for k in range(count):
		t=g.tell()
		v=g.H(2)	
		size=g.i(1)[0]
		if v[1]==1:
			section1(g)
		if v[1]==2:
			section2(g)
		if v[1]==3:
			section3(g)
		if v[1]==4:
			section4(g)
		if v[1]==5:
			section5(g)
		if v[1]==6:
			section6(g)
		if v[1]==7:
			section7(g)
		if v[1]==8:
			section8(g)
		g.seek(t+size)	
	
class G1M:
	def __init__(self):
		self.meshCount=None 	
		self.boneMapList=[]
		self.meshList=[]
		self.matList=[]
		self.strideList=[]
		self.vertStreamList=[]
		self.indiceStreamList=[]
		self.meshInfoList=[]
		self.textureList=[]
		
		

def G1MSParser(back,g):
	offset=g.i(1)[0]
	w=g.H(6)
	print offset,w,g.tell()
	#g.H(w[4])
	#g.H(2)
	#if w[0]!=0:
	g.seek(back+offset)
	#skeleton.DEL=False
	print 'boneCount:',w[2]
	if w[2]==w[3]:
		for m in range(w[2]):
			bone=Bone()
			bone.name=str(m)
			g.f(3)
			bone.parentID=g.i(1)[0]
			#print m,bone.parentID
			#print g.f(1)
			w=g.f(4)
			bone.rotMatrix=Quaternion(w[3],w[0],w[1],w[2]).toMatrix().resize4x4()
			bone.posMatrix=TranslationMatrix(Vector(g.f(4)))
			g1m.skeleton.boneList.append(bone)
		g.tell()
		
		
		
def G1M_Parser(offset,filename,g):
	global g1m	
	

	g1m=G1M()
	g1mList.append(g1m)

	g1m.skeleton=Skeleton()
	g1m.skeleton.BONESPACE=True
	g1m.skeleton.NICE=True

	A=g.i(4)		
	g.seek(offset+A[1])
	for m in range(A[3]):
		start=g.tell()
		chunk=g.word(8)
		size=g.i(1)[0]
		print chunk
		if chunk=='G1MG0044':G1MGParser(g)
		if chunk=='G1MF0023':
				w=g.i(36)
				#print w
				g1m.meshCount=w[11]
				#G1MFParser(g)
		if chunk=='G1MS0032':
		    G1MSParser(start,g)
			
		
		g.seek(start+size)
		
		
	
def g1mParser(filename,g):
	global g1mList
	
	g.endian='>'	
	g1mList=[]	
	sectionCount=g.i(1)[0]
	offsetList=g.i(sectionCount)
	for i,offset in enumerate(offsetList):
		g.seek(offset)
		if i!=0:
			chunk=g.word(4)
			g.word(4)
			if chunk=='G1M_':
				print
				print chunk
				print
				G1M_Parser(offset,filename,g)
	
	
	
	for i,g1m in enumerate(g1mList):		
		ModelID=ParseID()
		print '='*20,i
		for meshID in range(g1m.meshCount):
			mesh=Mesh()
			mesh.usedskin=[]
			mesh.name=str(ModelID)+'-mesh-'+str(meshID)
			g1m.meshList.append(mesh)
			
		for infoID in range(len(g1m.meshInfoList)):
			info=g1m.meshInfoList[infoID]
			#print infoID,info
			mesh=g1m.meshList[info[1]]
			#mesh.TRISTRIP=True
			stride=g1m.strideList[info[1]]
				
			mat=Mat()
			#mat.ZTRANS=True
			print g1m.textureList[info[6]]
			diffID=g1m.textureList[info[6]][0][1]
			mat.diffuse=g.dirname+os.sep+'textures'+os.sep+str(diffID)+'.dds'
			if len(g1m.textureList[info[6]])==4:
				diffID1=g1m.textureList[info[6]][1][1]
				mat.diffuse1=g.dirname+os.sep+'textures'+os.sep+str(diffID1)+'.dds'
				#print mat.diffuse1
				diffID2=g1m.textureList[info[6]][3][1]
				mat.diffuse2=g.dirname+os.sep+'textures'+os.sep+str(diffID2)+'.dds'
				#print mat.diffuse2
			if len(g1m.textureList[info[6]])==3:
				ID=g1m.textureList[info[6]][2][1]
				mat.normal=g.dirname+os.sep+'textures'+os.sep+str(ID)+'.dds'
				#print mat.ao
				specularID=g1m.textureList[info[6]][1][1]
				mat.specular=g.dirname+os.sep+'textures'+os.sep+str(specularID)+'.dds'
				#print mat.specular
				
			#g1m.matList[info[6]].diffuse
			#mat.ao=g1m.matList[info[6]].ao
			#mat.name=mesh.name+'-'+str(m)
			mat.IDStart=info[12]
			mat.IDCount=info[13]
			mat.TRISTRIP=True
			#mat.TRIANGLE=True
			mesh.matList.append(mat)
			
			if len(mesh.vertPosList)>0:
				for m in range(len(mesh.vertPosList)):
					#print mesh.skinIDList[m]
					mesh.skinIDList[m].extend([0])
					
			skinIndiceList=[]
			skinWeightList=[]	
			for m in range(stride.count):
				element=stride.list[m]
				if debug==True:
					print element.streamID,
					print element.offset,
					print element.unk0,
					print element.unk1,
					print element.unk2,
					print element.unk3
				if element.unk2==0:#vertPosList				 
					stream=g1m.vertStreamList[element.streamID]
					if debug==True:				
						print '----',
						print stream.elementCount,
						print stream.strideSize
					g.seek(stream.offset+info[10]*stream.strideSize)
					for n in range(info[11]):
						t=g.tell()
						g.seek(t+element.offset)
						if element.unk0==2:#3float
							mesh.vertPosList.append(g.f(3))
						if element.unk0==11:#3half
							mesh.vertPosList.append(g.half(3))
						if element.unk0==3:#3float
							mesh.vertPosList.append(g.f(3))
						g.seek(t+stream.strideSize)
						mesh.skinIDList.append([0]*(len(mesh.skinList)+1))
						
				if element.unk2==5:#vertUVList  
					if element.unk3==0:#layer 0			 
						stream=g1m.vertStreamList[element.streamID]
						if debug==True:				
							print '----',
							print stream.elementCount,
							print stream.strideSize
						g.seek(stream.offset+info[10]*stream.strideSize)
						for n in range(info[11]):
							t=g.tell()
							g.seek(t+element.offset)
							if element.unk0==1:#2float
								mesh.vertUVList.append(g.f(2))
							g.seek(t+stream.strideSize)
				if element.unk2==1:#skinWeightList 
					#print 'skinweight:',info[11]
					if element.unk3==0:#layer 0			 
						stream=g1m.vertStreamList[element.streamID]
						if debug==True:				
							print '----',
							print stream.elementCount,
							print stream.strideSize
						g.seek(stream.offset+info[10]*stream.strideSize)
						for n in range(info[11]):
							t=g.tell()
							g.seek(t+element.offset)
							if element.unk0==2:#3float
								skinWeightList.append(g.f(3))
							elif element.unk0==0:
								w=g.f(1)[0]
								skinWeightList.append([w,1.0-w])
							elif element.unk0==3:
								skinWeightList.append(g.f(3))
							elif element.unk0==1:
								skinWeightList.append(g.f(2))
							elif element.unk0==13:#3float
								W1=g.B(1)[0]/255.0
								W2=g.B(1)[0]/255.0
								W3=g.B(1)[0]/255.0
								skinWeightList.append([W1,W2,W3])
							else:
								print 'element:',element.unk0,g.tell(),g.f(4)
							g.seek(t+stream.strideSize)
				if element.unk2==2:#skinIndiceList  
					#print 'skinIndice:',info[11]
					if element.unk3==0:#layer 0			 
						stream=g1m.vertStreamList[element.streamID]
						if debug==True:				
							print '----',
							print stream.elementCount,
							print stream.strideSize
						g.seek(stream.offset+info[10]*stream.strideSize)
						for n in range(info[11]):
							t=g.tell()
							g.seek(t+element.offset)
							if element.unk0==5:#3float
								ID1=g.B(1)[0]/3
								ID2=g.B(1)[0]/3
								ID3=g.B(1)[0]/3
								skinIndiceList.append([ID1,ID2,ID3])
							else:
								print 'element:',element.unk0,g.tell(),g.i(4)
							g.seek(t+stream.strideSize) 
			
			indiceStream=g1m.indiceStreamList[info[1]]
			#print indiceStream.offset
			g.seek(indiceStream.offset+info[12]*indiceStream.strideSize)
			if info[2] not in mesh.usedskin:
				mesh.usedskin.append(info[2])
				skin=Skin()			
				skin.boneMap=g1m.boneMapList[info[2]]		
				mesh.skinList.append(skin)
			print g1m.boneMapList[info[2]]
			indiceList=[]
			for m in range(info[13]):
				if indiceStream.strideSize==2:
					id=g.H(1)[0]
					indiceList.append(id)
					mesh.skinIDList[id][mesh.usedskin.index(info[2])]=1
				if indiceStream.strideSize==4:
					pass#mesh.indiceList.append(g.i(1)[0])
			mesh.indiceList.extend(indiceList)
			if len(skinIndiceList)==len(skinWeightList):
				if len(skinIndiceList)>0 and len(skinWeightList)>0:
					mesh.skinIndiceList.extend(skinIndiceList)
					mesh.skinWeightList.extend(skinWeightList)
				else:	
					for id in range(info[11]):
						mesh.skinIndiceList.append([0])
						mesh.skinWeightList.append([1.0])
			if len(skinIndiceList)!=0 and len(skinWeightList)==0:
					mesh.skinIndiceList.extend(skinIndiceList)
					for id in range(info[11]):
						#mesh.skinIndiceList.append([0])
						mesh.skinWeightList.append([1.0])
				
			print len(mesh.vertPosList),len(mesh.skinWeightList),len(mesh.skinIndiceList)
				
			"""skin=Skin()#mesh.skinList[0]
			skin.boneMap=g1m.boneMapList[info[2]]
			skin.IDStart=info[10]
			skin.IDCount=info[11]
			if len(mesh.skinIndiceList)>0:
				mesh.skinList.append(skin) """
			
		g1m.skeleton.name=str(ModelID)+'-armature'	
		g1m.skeleton.draw()
		for mesh in g1m.meshList:
			mesh.BINDSKELETON=g1m.skeleton.name 
			#mesh.boneNameList=g1m.skeleton.boneNameList	
			#mesh.SPLIT=True
			#mesh.WARNING=True			
			mesh.draw()
			
	skeleton=Skeleton()
	boneCount=0
	for g1m in g1mList:
		if len(g1m.skeleton.boneList)>boneCount:
			skeleton=g1m.skeleton
	#skeleton.draw()		
	for g1m in g1mList:
		for mesh in g1m.meshList:
			mesh.BINDSKELETON=skeleton.name 
			#mesh.boneNameList=g1m.skeleton.boneNameList	
			#mesh.SPLIT=True
			#mesh.WARNING=True			
			#mesh.draw()
	g.tell()
	
	
def Parser():	
	global debug
	filename=input.filename
	print
	print filename
	print
	ext=filename.split('.')[-1].lower()	
	debug=0
	
	if 'lfm_order.bin' in filename.lower():
		file=open(filename,'rb')
		g=BinaryReader(file)
		fileList=binParser(filename,g)
		file.close()
		
		archivePath=os.path.dirname(filename)+os.sep+'archive00.bin'
		if os.path.exists(archivePath)==True:
			file=open(archivePath,'rb')
			g=BinaryReader(file)
			archiveParser(archivePath,g,fileList)
			file.close()
	else:
	
		modelDir=filename.lower().split('model')[0]
		g1tPath=modelDir+'texture'+os.sep+os.path.basename(filename.lower()).split('_mdl.bin')[0]+'_tex.g1t'
		print g1tPath
		if os.path.exists(g1tPath)==True:
			cmd=Cmd()
			cmd.OFFZIP=True
			cmd.input=g1tPath
			cmd.output=blendDir+os.sep+os.path.basename(filename.lower()).split('_mdl.bin')[0]
			cmd.run()
			for file in os.listdir(cmd.output):
				if file.split('.')[-1].lower()=='dat':
					g1tPath=cmd.output+os.sep+os.path.basename(filename.lower()).split('_mdl.bin')[0]+'_tex.g1t'
					try:os.rename(cmd.output+os.sep+file,g1tPath)
					except:pass
					if os.path.exists(g1tPath)==True:
						file=open(g1tPath,'rb')
						g=BinaryReader(file)
						g1tParser(g1tPath,g)
						file.close()
						
			cmd=Cmd()
			cmd.OFFZIP=True
			cmd.input=filename
			cmd.output=blendDir+os.sep+os.path.basename(filename.lower()).split('_mdl.bin')[0]
			cmd.run()
			for file in os.listdir(cmd.output):
				if file.split('.')[-1].lower()=='dat':
					g1mPath=cmd.output+os.sep+os.path.basename(filename.lower()).split('.')[0]+'.g1m'
					try:os.rename(cmd.output+os.sep+file,g1mPath)
					except:pass
					if os.path.exists(g1mPath)==True:
						file=open(g1mPath,'rb')
						g=BinaryReader(file)
						g1mParser(g1mPath,g)
						file.close()
	
		"""if ext=='bin':
			cmd=Cmd()
			cmd.OFFZIP=True
			cmd.input=filename
			cmd.output=blendDir#os.path.dirname(filename)
			cmd.run()
			for file in os.listdir(blendDir):
				if file.split('.')[-1].lower()=='dat':
					os.rename(blendDir+os.sep+file,blendDir+os.sep+os.path.basename(filename).split('.')[0]+'.g1m')
		elif ext=='g1t':
			cmd=Cmd()
			cmd.OFFZIP=True
			cmd.input=filename
			cmd.output=blendDir
			cmd.run()
			for file in os.listdir(blendDir):
				if file.split('.')[-1].lower()=='dat':
					os.rename(blendDir+os.sep+file,blendDir+os.sep+os.path.basename(filename).split('.')[0]+'.g2t')
		elif ext=='g1m':
			file=open(filename,'rb')
			g=BinaryReader(file)
			g.logOpen()
			g1mParser(filename,g)
			g.logClose()
			file.close()"""
	
	if ext=='g1t':
		file=open(filename,'rb')
		g=BinaryReader(file)
		g1tParser(filename,g)
		file.close()
			
	if ext=='g1m':
			file=open(filename,'rb')
			g=BinaryReader(file)
			g1mParser(filename,g)
			g.logClose()
			
		
		
		
		
 
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
	
Blender.Window.FileSelector(openFile,'import','Deception IV Blood Ties PS3 files: lfm_order.bin - for unpacking, *.bin, *.g1m - model') 
	