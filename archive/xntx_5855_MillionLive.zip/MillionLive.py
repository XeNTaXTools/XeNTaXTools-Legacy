from urllib.request import ProxyHandler, build_opener, install_opener, urlretrieve
import lz4
from itertools import islice
from multiprocessing.dummy import Pool as ThreadPool
import os
import struct

pool = ThreadPool(100)

if not os.path.exists("MillionLive"):
	os.makedirs("MillionLive")
	manifestURL = 'http://td-assets.bn765.com/1/production/5.6/Android/6b976a4c875a1984592a66b621872ce44c944e72.data'
	urlretrieve(manifestURL, 'MillionLive\\' + 'MillionLive.manifest')

baseURL = 'http://td-assets.bn765.com/1/production/5.6/Android/'
#proxy = urllib.request.ProxyHandler({'http': 'http://192.168.1.91:8888'})
proxy = ProxyHandler({})
opener = build_opener(proxy)
opener.addheaders = [('X-Unity-Version','5.4.5p1'),('User-Agent','Dalvik/1.6.0 (Linux; U; Android 4.4.4; GT-P5210 Build/KTU84P)')]
install_opener(opener)

def readString(myfile):
    chars = []
    while True:
        c = myfile.read(1)
        if c == b'\x93':
            return b''.join(chars).decode("ASCII")
        chars.append(c)

def geturl(link,file):
	try:
		baseDir = '\\'.join((file).split('_')[0:-1]) + '\\'
		if not os.path.exists('MillionLive\\' + baseDir):
			os.makedirs('MillionLive\\' + baseDir)
		urlretrieve(baseURL + link, 'MillionLive\\' + baseDir + (file).split('_')[-1])
		print('MillionLive\\' + baseDir + (file).split('_')[-1])
	except:
		pass

with open('MillionLive\\' + 'MillionLive.manifest', "rb" ) as f:
	fileName = []
	hashName = []
	f.read(1)
	#print(iCount)
	for i in range(0,9712):
		fileTest, fileTest2 = struct.unpack('BB',f.read(2))
		if fileTest != 0xCE:
			h3,nSize = struct.unpack('2B',  f.read(2))
			if (nSize == 0xD9):
				nSize = struct.unpack('B',  f.read(1))[0]
			#print(f.tell(),'BASE')
			nString = readString(f)
			#print(f.tell(),'BASE')
			#print(nString)
			h3,nSize = struct.unpack('BB',  f.read(2))
			#print(h3,nSize)
			hString = f.read(nSize).decode("ASCII")
			#print(hString)
			h3,nSize = struct.unpack('2B',  f.read(2))
			#print(h3,nSize)
			hName = f.read(nSize).decode("ASCII")
			#print(hName)
			#print('Hello ' + str(i))
			fileName.append(nString)
			hashName.append(hName)
	pool.starmap(geturl, zip(hashName,fileName) )






#with open('musicClean.txt', "rb" ) as f:
#	while True:
#		names = list(islice(f, 100))
#		if len(names) == 0:
#			break
#		pool.starmap(geturl, zip(names) )

		

