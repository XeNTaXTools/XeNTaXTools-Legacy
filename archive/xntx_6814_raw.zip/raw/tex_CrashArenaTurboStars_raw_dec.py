from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("CATS: Crash Arena Turbo Stars [Android]", ".raw_dec")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    return 1
    
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    imgWidth = bs.readUShort()            
    imgHeight = bs.readUShort()
    print(imgWidth, "x", imgHeight)
    imgFmt = bs.readByte()
    print(imgFmt, ":imgFmt")
    datasize = bs.readInt()        
    bs.seek(0x9, NOESEEK_ABS)         
    data = bs.readBytes(datasize)      
    if imgFmt == 0:
        data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "r8 g8 b8 a8")
        texFmt = noesis.NOESISTEX_RGBA32
    elif imgFmt == 1:
        data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "b5 g6 r5 a0")
        texFmt = noesis.NOESISTEX_RGBA32
    elif imgFmt == 2:
        data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "a4 b4 g4 r4")
        texFmt = noesis.NOESISTEX_RGBA32
    #unknown, not handled
    else:
        print("WARNING: Unhandled image format")
        return None
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1