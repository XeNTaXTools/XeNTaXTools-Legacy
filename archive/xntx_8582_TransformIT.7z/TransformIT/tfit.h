#pragma once

#include <stdint.h>
#include <array>
#include <vector>

class TFIT {
public:
  TFIT(std::array<uint8_t, 16> &previous, std::array<std::array<std::array<uint8_t, 4>, 4>, 17> &keys, std::array<std::array<std::array<std::array<uint8_t, 4>, 256>, 16>, 17> &tables);

  void Update(std::array<uint8_t, 16> &src, std::array<uint8_t, 16> &dst);

private:
  std::array<std::array<std::array<std::array<uint8_t, 4>, 256>, 16>, 17> &tables_;
  std::array<std::array<std::array<uint8_t, 4>, 4>, 17> &keys_;
  std::array<uint8_t, 16> previous_;

  void DecryptRoundA(std::array<uint8_t, 16> &data, std::array<std::array<uint8_t, 4>, 4> &key, std::array<std::array<std::array<uint8_t, 4>, 256>, 16> &table);
  void DecryptRoundB(std::array<uint8_t, 16> &data, std::array<std::array<uint8_t, 4>, 4> &key, std::array<std::array<std::array<uint8_t, 4>, 256>, 16> &table);
  void DecryptBlock(std::array<uint8_t, 16> &src, std::array<uint8_t, 16> &dst);
};
