#include <iostream>
#include <format>
#include <fstream>

#include "keys.h"
#include "tfit.h"

uint32_t read32LE(std::ifstream &s) {
  return s.get() | (s.get() << 8) | (s.get() << 16) | (s.get() << 24);
}

int main(int argc, char *argv[]) {
  if (argc != 3) {
    std::cerr << "Usage: TransformIT.exe <encrypted input> <decrypted output>" << std::endl;
    std::cerr << std::endl;
    std::cerr << "Example:" << std::endl;
    std::cerr << "  .\\TransformIT.exe \"C:\\Program Files (x86)\\DODI-Repacks\\Forza Horizon 5\\media\\Physics\\PI.xml\" \"PI.xml\"" << std::endl;
    return -1;
  }

  std::ofstream output(argv[2], std::ios_base::binary);
  // TODO: check if file already exists

  std::array<std::array<std::array<uint8_t, 4>, 4>, 17> keys{};
  std::copy_n(std::begin(fh5_file_decryption_keys) + 1, 17, std::begin(keys));

  std::array<uint8_t, 16> iv{};
  std::array<uint8_t, 16> src{};
  std::array<uint8_t, 16> dst{};
  uint32_t padding = 0;

  std::ifstream input(argv[1], std::ios_base::binary);
  input.unsetf(std::ios_base::skipws);
  input.read(reinterpret_cast<char *>(iv.data()), 16); // IV
  padding = read32LE(input);
  // read MAC to check keys are correct. ignore MAC later when reading the data. maybe use one time to check data_block size. 200 or 20000
  input.ignore(16);

  TFIT cipher(iv, keys, fh5_tables);
  while (!input.eof()) {
    for (size_t i = 0; i < 0x200 / 16; i++) {
      input.read(reinterpret_cast<char *>(src.data()), 16);
      cipher.Update(src, dst);
      //std::cout.write(reinterpret_cast<char *>(dst.data()), 16); // \r\n problem
      output.write(reinterpret_cast<char *>(dst.data()), 16);
    }

    // MAC is also encrypted and a part of encrypted flow, so don't print it
    input.read(reinterpret_cast<char *>(src.data()), 16);
    cipher.Update(src, dst);

    input.peek();
  }

  return 0;
}
