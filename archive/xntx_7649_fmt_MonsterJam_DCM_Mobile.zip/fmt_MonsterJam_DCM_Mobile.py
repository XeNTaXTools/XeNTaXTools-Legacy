from inc_noesis import *
import noesis
import rapi

def registerNoesisTypes():
	handle = noesis.register("Monster Jam",".DCM")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadModel(handle, noepyLoadModel)
	return 1
	
NOEPY_HEADER = "DC2"

def noepyCheckType(data):
   bs = NoeBitStream(data)
   if len(data) < 3:
      return 0
   if bs.readBytes(3).decode("ASCII") != NOEPY_HEADER:
      return 0
   return 1  

def noepyLoadModel(data, mdlList):
	ctx = rapi.rpgCreateContext()
	bs = NoeBitStream(data)
	bs.seek(0x1b, NOESEEK_ABS)
	Skip = bs.readUInt()
	bs.seek(Skip*8, NOESEEK_REL)
	VCount = bs.readUInt()
	bs.seek(0x5, NOESEEK_REL)
	FVFsize = bs.readUInt()
	VBuff = bs.readBytes(VCount*FVFsize)
	rapi.rpgBindPositionBufferOfs(VBuff, noesis.RPGEODATA_FLOAT, FVFsize, 0)
	rapi.rpgBindUV1BufferOfs(VBuff, noesis.RPGEODATA_FLOAT, FVFsize, 24)
	FCount = bs.readUInt()
	FBuff = bs.readBytes(FCount*4)
	rapi.rpgCommitTriangles(FBuff, noesis.RPGEODATA_UINT, FCount, noesis.RPGEO_TRIANGLE, 1)

	mdl = rapi.rpgConstructModel()
	mdlList.append(mdl)
	rapi.rpgClearBufferBinds()
	return 1