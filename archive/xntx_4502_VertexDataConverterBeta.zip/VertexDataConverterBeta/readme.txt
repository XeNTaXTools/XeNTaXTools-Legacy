This tool can convert most of the mesh groups from 360 to PC.  Some of the groups don't seem to be working correctly, and the results when converting all groups will have great comedic effects.

Note that the 360 TCM and PC tmc must be from the same DLC_### TMC file.

Inputs:
mesh_data is the user_defined info found in 3ds max -> object properties user defined
meta costume is the txt file output from the tool MetaCostume
2 file dialogs take xbox/360 version of the TMC.

Output:
A TMC file with the same name as the PC version of the TMC input file with _NEW appended at the end.  You will have to copy and rename the corresponding TMCL to view it properly in noesis.
 
Since not all groups can convert correctly, I have added a text box that lets user choose which groups to convert.  It takes a comma delimited string ie(1,3,4,5) no space in between and the tool will then only convert those groups.  If let empty, it does all groups.  Please note that the group number starts from 0 instead of 1.

There's not a lot of error handling so it might crap out unexpectedly if unhandled exceptions are found.

So far I have tested it against LEIFANG_DLC_004.TMC and it appears that groups 0 and 6 are problematic while others are fine.

