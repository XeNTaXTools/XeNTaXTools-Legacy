from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Neighbours From Hell", ".tga")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
	#noesis.logPopup()
	return 1

def noepyCheckType(data):
    return 1
	
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.seek(0xc, 0)
    imgWidth = bs.readUShort()            
    imgHeight = bs.readUShort()
    bs.readShort()    
    data = bs.readBytes(bs.getSize() - bs.tell())      
    data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "b4 g4 r4 a4")
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, noesis.NOESISTEX_RGBA32))
    return 1