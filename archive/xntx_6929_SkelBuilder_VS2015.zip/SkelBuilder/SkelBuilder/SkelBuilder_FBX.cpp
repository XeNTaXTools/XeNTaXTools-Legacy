/*===========================================================================================*\
|       Function Utilities for FBX Skeleton Builder(SkelBuilder) (C) 2019 Bigchillghost       |
\*===========================================================================================*/


/*======================================== USAGE ==========================================*\
CreateFbxFile();

LOOP:
	InitialModel();
	WriteMdl();
	AppendO2OList();
ENDLOOP;

ConnectO2O();
\*=========================================================================================*/

#ifndef _WINDOWS_
#include <Windows.h>
#endif
#ifndef _INC_STDLIB
#include <stdlib.h>
#endif
#ifndef _INC_STDIO
#include <stdio.h>
#endif
#ifndef _INC_STRING
#include <string.h>
#endif

/**************************** Global Macro Definitions *************************/

// Axes
#define		X			0
#define		Y			1
#define		Z			2

// AxisSystem
#define		MayaZUp			0
#define		MayaYUp			1
#define		Motionbuilder	2
#define		Max				3
#define		OpenGL			4
#define		DirectX			5
#define		Lightwave		6

// UnitScaleFactor
#define		millimeters		0.1
#define		centimeters		1.0
#define		decimeters		10.0
#define		meters			100.0
#define		kilometers		1000.0
#define		inches			2.54
#define		feet			30.48
#define		yards			91.44
#define		miles			160934.4

/**** On-off Controller ****/
#define enablePreRotation true

/**************************** FBX Object structures *************************/

typedef struct
{
	char ModelName[64];
	
	ULONG64 UID;
	ULONG64 parentID;
	ULONG64 NodeAttributeUID; // Used by NodeAttribute
	double SkeletonSize;
	
	double Translation[3];
	double Rotation[3];
	double Scaling[3];
} Model;

typedef struct OONode
{
	ULONG64 UID;
	ULONG64 parentID;
	struct OONode *next;
} Node;

/*************************** Global Variables **************************/
#if enablePreRotation
double PreRotation[3] = { 0.0,0.0,0.0 }; // 0.0,90.0,180.0
#endif

/*************************** data function utilities **************************/

// Initialize Model* object
void InitialModel(Model *mdl)
{
	mdl->UID = 0ULL;
	mdl->parentID = 0ULL;
	mdl->SkeletonSize = 400.0;
	for(int i = 0; i < 3; i++)
	{
		mdl->Translation[i] = 0.0;
		mdl->Rotation[i] = 0.0;
		mdl->Scaling[i] = 1.0;
	}
}

// Append IDs to node list
int AppendNodeList(Node **NodeList, ULONG64 UID, ULONG64 parentID)
{
	Node *pTail, *pNew;

	pNew = (Node *)malloc(sizeof(Node));
	if (pNew == NULL)
	{
		printf_s("memory allocation failed!\n");
		return 1;
	}

	pNew->UID = UID;
	pNew->parentID = parentID;
	pNew->next = NULL;
	if (*NodeList == NULL)
	{
		*NodeList = pNew;
	}
	else
	{
		pTail = *NodeList;
		while (pTail->next != NULL)
			pTail = pTail->next;
		pTail->next = pNew;
	}

	return 0;
}

// Destroy a Node list
void DestroyNodeList(Node **NodeList)
{
	Node *pHead;

	while (*NodeList != NULL)
	{
		pHead = *NodeList;
		*NodeList = (*NodeList)->next;
		free(pHead);
	}
}

/*************************** FBX IO Procedures **************************/

/* Create an FBX document */
void CreateFbxFile(FILE **fpFbx, char *FBXName, int CoordSystem, double SceneUnit, int ModelCount)
{
	FILE *fpFBX;
	SYSTEMTIME Time;
	int UpAxis;
	int UpAxisSign;
	int FrontAxis;
	int FrontAxisSign;
	int CoordAxis;
	int CoordAxisSign;
	int OriginalUpAxis = 0;
	int OriginalUpAxisSign = 1;
	double UnitScaleFactor = 100.0; // unit = cm
	double OriginalUnitScaleFactor = 1.0;
	char Creator[] = "SkelBuilder (C)2019 Bigchillghost";

	if (fopen_s(&fpFBX, FBXName, "w") != NULL)
	{
		printf("error! cannot create file %s\n", FBXName);
		exit(1);
	}
	
	*fpFbx = fpFBX;

	// AxisSystem Configuration
	switch (CoordSystem)
	{
	default:
	case MayaZUp:
	case Max:
		UpAxis = Z;
		FrontAxis = Y;
		CoordAxis = X;
		UpAxisSign = 1;
		FrontAxisSign = -1;
		CoordAxisSign = 1;
		break;
	case MayaYUp:
	case Motionbuilder:
	case OpenGL:
		UpAxis = Y;
		FrontAxis = Z;
		CoordAxis = X;
		UpAxisSign = 1;
		FrontAxisSign = 1;
		CoordAxisSign = 1;
		break;
	case DirectX:
	case Lightwave:
		UpAxis = Y;
		FrontAxis = Z;
		CoordAxis = X;
		UpAxisSign = 1;
		FrontAxisSign = 1;
		CoordAxisSign = -1;
		break;
	}

	// Set UnitScaleFactor
	UnitScaleFactor = SceneUnit;
	
	/* Header */
	fprintf_s(fpFBX, "; FBX 7.1.0 project file\n");
	for (BYTE cnt = 0; cnt < 52; cnt++)
		fprintf_s(fpFBX, "-");
	fprintf_s(fpFBX, "\n");

	/* Start of FBXHeaderExtension */
	fprintf_s(fpFBX, "FBXHeaderExtension:  {\n");
	fprintf_s(fpFBX, "\tFBXHeaderVersion: 1003\n");
	fprintf_s(fpFBX, "\tFBXVersion: 7100\n");
	fprintf_s(fpFBX, "\tCreationTimeStamp:  {\n");
	fprintf_s(fpFBX, "\t\tVersion: 1000\n");

	/* Start of CreationTimeStamp */
	GetLocalTime(&Time);
	fprintf_s(fpFBX, "\t\tYear: %d\n", Time.wYear);
	fprintf_s(fpFBX, "\t\tMonth: %d\n", Time.wMonth);
	fprintf_s(fpFBX, "\t\tDay: %d\n", Time.wDay);
	fprintf_s(fpFBX, "\t\tHour: %d\n", Time.wHour);
	fprintf_s(fpFBX, "\t\tMinute: %d\n", Time.wMinute);
	fprintf_s(fpFBX, "\t\tSecond: %d\n", Time.wSecond);
	fprintf_s(fpFBX, "\t\tMillisecond: %d\n", Time.wMilliseconds);
	fprintf_s(fpFBX, "\t}\n");
	/* End CreationTimeStamp */
	fprintf_s(fpFBX, "\tCreator: \"%s\"\n}\n", Creator);
	/* End FBXHeaderExtension */

	/* Start of GlobalSettings */
	fprintf_s(fpFBX, "GlobalSettings:  {\n");
	fprintf_s(fpFBX, "\tVersion: 1000\n");
	fprintf_s(fpFBX, "\tProperties70:  {\n");
	fprintf_s(fpFBX, "\t\tP: \"UpAxis\", \"int\", \"Integer\", \"\",%d\n", UpAxis);
	fprintf_s(fpFBX, "\t\tP: \"UpAxisSign\", \"int\", \"Integer\", \"\",%d\n", UpAxisSign);
	fprintf_s(fpFBX, "\t\tP: \"FrontAxis\", \"int\", \"Integer\", \"\",%d\n", FrontAxis);
	fprintf_s(fpFBX, "\t\tP: \"FrontAxisSign\", \"int\", \"Integer\", \"\",%d\n", FrontAxisSign);
	fprintf_s(fpFBX, "\t\tP: \"CoordAxis\", \"int\", \"Integer\", \"\",%d\n", CoordAxis);
	fprintf_s(fpFBX, "\t\tP: \"CoordAxisSign\", \"int\", \"Integer\", \"\",%d\n", CoordAxisSign);
	fprintf_s(fpFBX, "\t\tP: \"OriginalUpAxis\", \"int\", \"Integer\", \"\",%d\n", OriginalUpAxis);
	fprintf_s(fpFBX, "\t\tP: \"OriginalUpAxisSign\", \"int\", \"Integer\", \"\",%d\n", OriginalUpAxisSign);
	fprintf_s(fpFBX, "\t\tP: \"UnitScaleFactor\", \"double\", \"Number\", \"\",%.2f\n", UnitScaleFactor);
	fprintf_s(fpFBX, "\t\tP: \"OriginalUnitScaleFactor\", \"double\", \"Number\", \"\",%.2f\n", OriginalUnitScaleFactor);
	fprintf_s(fpFBX, "\t}\n}\n");
	/* End GlobalSettings */

	/* Start of Documents */
	fprintf_s(fpFBX, "Documents:  {\n");
	fprintf_s(fpFBX, "\tCount: 1\n");
	fprintf_s(fpFBX, "\tDocument: 1700386471, \"\", \"Scene\" {\n");
	fprintf_s(fpFBX, "\t\tProperties70:  {\n");
	fprintf_s(fpFBX, "\t\t\tP: \"SourceObject\", \"object\", \"\", \"\"\n");
	fprintf_s(fpFBX, "\t\t\tP: \"ActiveAnimStackName\", \"KString\", \"\", \"\", \"\"\n");
	fprintf_s(fpFBX, "\t\t}\n");
	fprintf_s(fpFBX, "\t\tRootNode: 0\n");
	fprintf_s(fpFBX, "\t}\n}\n\n");
	/* End Documents */

	/* Start of References */
	fprintf_s(fpFBX, "References:  {\n}\n\n");
	/* End References */

	/* ### Start of Object Definitions ### */
	fprintf_s(fpFBX, "Definitions:  {\n");
	fprintf_s(fpFBX, "\tVersion: 100\n");
	fprintf_s(fpFBX, "\tCount: %d\n", ModelCount * 2 + 1);
	fprintf_s(fpFBX, "\tObjectType: \"GlobalSettings\" {\n");
	fprintf_s(fpFBX, "\t\tCount: 1\n");
	fprintf_s(fpFBX, "\t}\n");

	fprintf_s(fpFBX, "\tObjectType: \"Model\" {\n");
	fprintf_s(fpFBX, "\t\tCount: %d\n", ModelCount);
	fprintf_s(fpFBX, "\t}\n");

	fprintf_s(fpFBX, "\tObjectType: \"NodeAttribute\" {\n");
	fprintf_s(fpFBX, "\t\tCount: %d\n", ModelCount);
	fprintf_s(fpFBX, "\t\tPropertyTemplate: \"FbxSkeleton\" {\n");
	fprintf_s(fpFBX, "\t\t\tProperties70:  {\n");
	fprintf_s(fpFBX, "\t\t\t\tP: \"Color\", \"ColorRGB\", \"Color\", \"\",0,0,0\n");
	fprintf_s(fpFBX, "\t\t\t\tP: \"Size\", \"double\", \"Number\", \"\",100\n");
	fprintf_s(fpFBX, "\t\t\t\tP: \"LimbLength\", \"double\", \"Number\", \"H\",1\n");
	fprintf_s(fpFBX, "\t\t\t}\n");
	fprintf_s(fpFBX, "\t\t}\n");
	fprintf_s(fpFBX, "\t}\n");

	fprintf_s(fpFBX, "}\n\n");
	/* End Definitions */

	/* Start of Objects properties */
	fprintf_s(fpFBX, "Objects:  {\n");
}

/* Write LimbNode & its NodeAttribute to file */
void WriteMdl(FILE *fpFBX, Model *mdl, int *MaxHandle)
{
	fprintf_s(fpFBX, "\tNodeAttribute: %lld, \"NodeAttribute::\", \"LimbNode\" {\n", mdl->NodeAttributeUID);
	fprintf_s(fpFBX, "\t\tProperties70:  {\n");
	fprintf_s(fpFBX, "\t\t\tP: \"Size\", \"double\", \"Number\", \"\",%.15g\n", mdl->SkeletonSize);
	fprintf_s(fpFBX, "\t\t}\n");
	fprintf_s(fpFBX, "\t\tTypeFlags: \"Skeleton\"\n");
	fprintf_s(fpFBX, "\t}\n");

	fprintf_s(fpFBX, "\tModel: %lld, \"Model::%s\", \"LimbNode\" {\n", mdl->UID, mdl->ModelName);
	fprintf_s(fpFBX, "\t\tVersion: 232\n");
	fprintf_s(fpFBX, "\t\tProperties70:  {\n");
#if enablePreRotation
	if (mdl->parentID == 0ull)
	{
		// PreRotation
		fprintf_s(fpFBX, "\t\t\tP: \"PreRotation\", \"Vector3D\", \"Vector\", \"\",%.15g,%.15g,%.15g\n", PreRotation[0], PreRotation[1], PreRotation[2]);
		// RotationActive
		fprintf_s(fpFBX, "\t\t\tP: \"RotationActive\", \"bool\", \"\", \"\",1\n");
	}
#endif
	fprintf_s(fpFBX, "\t\t\tP: \"InheritType\", \"enum\", \"\", \"\",1\n");
	fprintf_s(fpFBX, "\t\t\tP: \"ScalingMax\", \"Vector3D\", \"Vector\", \"\",0,0,0\n");
	fprintf_s(fpFBX, "\t\t\tP: \"DefaultAttributeIndex\", \"int\", \"Integer\", \"\",0\n");
	fprintf_s(fpFBX, "\t\t\tP: \"Lcl Translation\", \"Lcl Translation\", \"\", \"A\",%.15g,%.15g,%.15g\n", mdl->Translation[0], mdl->Translation[1], mdl->Translation[2]);
	fprintf_s(fpFBX, "\t\t\tP: \"Lcl Rotation\", \"Lcl Rotation\", \"\", \"A\",%.15g,%.15g,%.15g\n", mdl->Rotation[0], mdl->Rotation[1], mdl->Rotation[2]);
	fprintf_s(fpFBX, "\t\t\tP: \"Lcl Scaling\", \"Lcl Scaling\", \"\", \"A\",%.15g,%.15g,%.15g\n", mdl->Scaling[0], mdl->Scaling[1], mdl->Scaling[2]);
	fprintf_s(fpFBX, "\t\t\tP: \"MaxHandle\", \"int\", \"Integer\", \"UH\",%d\n", *MaxHandle);
	fprintf_s(fpFBX, "\t\t}\n");
	fprintf_s(fpFBX, "\t\tShading: T\n");
	fprintf_s(fpFBX, "\t\tCulling: \"CullingOff\"\n");
	fprintf_s(fpFBX, "\t}\n");

	(*MaxHandle)++;
}

/* Append O2O list */
void AppendO2OList(Node **NodeList, Model *mdl)
{
	AppendNodeList(NodeList, mdl->UID, mdl->parentID);
	AppendNodeList(NodeList, mdl->NodeAttributeUID, mdl->UID);
}

/* Connect object to object */
void ConnectO2O(FILE *fpFBX, Node *mdlList)
{
	Node *pNode = NULL;

	/* End Objects */
	fprintf_s(fpFBX, "}\n\n");
	/* Start of Objects connections */
	fprintf_s(fpFBX, "Connections:  {\n");

	pNode = mdlList;
	// Connect Model::LimbNode to Root/Model(parent)
	while (pNode != NULL)
	{
		fprintf_s(fpFBX, "\tC: \"OO\",%lld,%lld\n", pNode->UID, pNode->parentID);
		pNode = pNode->next;
	}
	fprintf_s(fpFBX, "}\n\n");
	/* End Connections */
}

