#include "stdafx.h"
#include <Windows.h>
#include <stdlib.h>


void Swap16(WORD *value);
void Swap32(ULONG32 *value);
void EndianBigRead(void*  _Buffer, size_t _BufferSize, size_t _ElementSize, size_t _ElementCount, FILE*  _Stream);


void Swap16(WORD *value)
{
	*value = (*value & 0x00FFU) << 8 | (*value & 0xFF00U) >> 8;
}

void Swap32(ULONG32 *value)
{
	*value = (*value & 0x000000FFU) << 24 | (*value & 0x0000FF00U) << 8 |
		(*value & 0x00FF0000U) >> 8 | (*value & 0xFF000000U) >> 24;
}

void EndianBigRead(void*  _Buffer, size_t _BufferSize, size_t _ElementSize, size_t _ElementCount, FILE*  _Stream)
{
	fread_s(_Buffer, _BufferSize, _ElementSize, _ElementCount, _Stream);
	switch (_ElementSize)
	{
	case 2:
		WORD *pWORD; 
		pWORD = (WORD *)_Buffer; 
		for (ULONG32 i = 0; i < _ElementCount; i++)
			Swap16(pWORD + i); 
		break;
	case 4:
		ULONG32 *pLONG; 
		pLONG = (ULONG32 *)_Buffer;
		for (ULONG32 i = 0; i < _ElementCount; i++)
			Swap32(pLONG + i);
	}

}
