// SkelBuilder.cpp : Defines the entry point for the console application.
// 
// FBX Skeleton Builder(SkelBuilder) Demonstration Program - (c)2019 Bigchillghost
// Demonstrations: Creating a skeleton from binary data from game files
//

#include "stdafx.h"
#include <Windows.h>
#include <string.h>
#include <stdlib.h>
#include "BigEndian.h"
#include "TransformationUtilities.c"
#include "SkelBuilder_FBX.cpp"

// Error Codes
#define  ERROR_OPEN_FILE  -1

void GetFileName(char *filename, char dst[], int Length);

/* The Fllowing Common Variables Could Be Used in Called Functions */
// int ModelCount = 0;
// int MaxHandle = 2;
// Model mdl;
// Node *mdlList = NULL;

/********************************************************************/
/**************** Format Specific Handler Prototypes ****************/
/********************************************************************/

int pigConv(char *ArcName);        // Asphalt 8: Airborne(Android)
int jmoxConv(char *ArcName);       // Asphalt 9: Legends(Android)
int afmConv(char *ArcName);        // Assalt Fire(PC)
int ve2Conv(char *ArcName);        // Ben 10 Omniverse(Xbox 360)
int skeletonConv(char *ArcName);   // Iron Man 2(PS3)
int xbgConv(char *ArcName);        // James Cameron's AVATAR THE GAME(PC)
int rnConv(char *ArcName);         // Ben 10 Omniverse 2(3DS)
int modelConv(char *ArcName);      // GuJian3(PC)
int meshConv(char *ArcName);       // Cyber Hunter(Android)

int main(int argc, char *argv[])
{
	char *EXT;

	if (argc < 2)
	{
		printf_s("\nFBX Skeleton Builder(SkelBuilder) Demonstration Program - (c)2019 Bigchillghost\n\n");
		printf_s("=================================== Usage ===================================\n");
		printf_s("Simple:\nDrag and drop files onto the tool.\n\n");
		printf_s("Command line:\nSkelBuilder <File> [File2] [File3] ...\n");
		printf_s("=============================================================================\n\n");
		system("pause");
		return 0;
	}

	for (int fileCNT = 1; fileCNT < argc; fileCNT++)
	{
		EXT = strrchr(argv[fileCNT], 0x2E) + 1;
		if (strcmp(EXT, "pig") == 0)
		{
			pigConv(argv[fileCNT]); 
		}
		else if (strcmp(EXT, "jmodel") == 0)
		{
			jmoxConv(argv[fileCNT]);
		}
		else if (strcmp(EXT, "AFM") == 0)
		{
			afmConv(argv[fileCNT]);
		}
		else if (strcmp(EXT, "ve2") == 0)
		{
			ve2Conv(argv[fileCNT]);
		}
		else if (strcmp(EXT, "SKELETON") == 0)
		{
			skeletonConv(argv[fileCNT]);
		}
		else if (strcmp(EXT, "xbg") == 0)
		{
			xbgConv(argv[fileCNT]);
		}
		else if (strcmp(EXT, "rn") == 0)
		{
			rnConv(argv[fileCNT]);
		}
		else if (strcmp(EXT, "model") == 0)
		{
			modelConv(argv[fileCNT]);
		}
		else if (strcmp(EXT, "mesh") == 0)
		{
			meshConv(argv[fileCNT]);
		}
		
	}
	return 0;
}

/**********************************************************/
/**************** Format Specific Handlers ****************/
/**********************************************************/

// Asphalt 8: Airborne(Android)
int pigConv(char *ArcName)
{
	// Common variables for skelBuilder
	FILE *fpSrc;
	FILE *fpFBX;
	int ModelCount = 0;
	int MaxHandle = 2;
	Model mdl;
	Node *mdlList = NULL;
	// Prefered variables for extraction
	double EulerRotation[3] = { 0.0 };
	float position[3];
	float rotation[4];
	float scale[3];
	char FileName[256] = { 0 }, FbxName[256] = { 0 };

	long Magic;
	short Count;
	short pID;
	WORD Length;

	GetFileName(ArcName, FileName, 256);

	if (fopen_s(&fpSrc, ArcName, "rb") != 0)
	{
		printf_s("error! cannot open file %s\n", FileName);
		exit(1);
	}

	fread_s(&Magic, 4, 4, 1, fpSrc);
	if (Magic != 0x64)		// "jmox", simple file varification
	{
		printf_s("Wrong file format!\n");
		exit(1);
	}

	printf_s("Processing %s...\t", FileName);

	strncpy_s(FbxName, 256, FileName, strlen(FileName) - 3);
	strcat_s(FbxName, 256, "FBX");

	// ### process starts ### //
	fread_s(&Count, 2, 2, 1, fpSrc);
	ModelCount = Count;

	CreateFbxFile(&fpFBX, FbxName, Max, inches, ModelCount);

	for (short i = 0; i < Count; i++)
	{
		InitialModel(&mdl);
		fseek(fpSrc, 4L, SEEK_CUR);
		fread_s(&Length, 2, 2, 1, fpSrc);
		fread_s(mdl.ModelName, 64, Length, 1, fpSrc);
		mdl.ModelName[Length] = 0;
		fseek(fpSrc, 1L, SEEK_CUR);

		fread_s(&pID, 2, 2, 1, fpSrc);
		fread_s(position, 12, 4, 3, fpSrc);
		fread_s(rotation, 16, 4, 4, fpSrc);
		fread_s(scale, 12, 4, 3, fpSrc);
		fseek(fpSrc, 6L, SEEK_CUR);

		if (pID < 0)
			mdl.parentID = 0ull;
		else
			mdl.parentID = (ULONG64)pID + 1ull;
		mdl.UID = (ULONG64)i + 1ull;
		mdl.NodeAttributeUID = mdl.UID + 100000ull;

		Quat2EulerAngles(rotation, EulerRotation);
		for (int j = 0; j < 3; j++)
		{
			mdl.Translation[j] = (double)position[j];
			mdl.Rotation[j] = (double)EulerRotation[j];
			mdl.Scaling[j] = (double)scale[j];
		}

		WriteMdl(fpFBX, &mdl, &MaxHandle);
		AppendO2OList(&mdlList, &mdl);
	}
	fclose(fpSrc);

	ConnectO2O(fpFBX, mdlList);
	DestroyNodeList(&mdlList);

	printf_s("finished!\n");

	return 0;
}

// Asphalt 9: Legends(Android)
int jmoxConv(char *ArcName)
{
	// Common variables for skelBuilder
	FILE *fpSrc;
	FILE *fpFBX;
	int ModelCount = 0;
	int MaxHandle = 2;
	Model mdl;
	Node *mdlList = NULL;
	// Prefered variables for extraction
	double EulerRotation[3] = { 0.0 };
	float position[3];
	float rotation[4];
	float scale[3];
	char FileName[256] = { 0 }, FbxName[256] = { 0 };

	long Magic;
	int Offset;
	short Count;
	short pID;
	WORD Length;

	GetFileName(ArcName, FileName, 256);

	if (fopen_s(&fpSrc, ArcName, "rb") != 0)
	{
		printf_s("error! cannot open file %s\n", FileName);
		exit(1);
	}

	fread_s(&Magic, 4, 4, 1, fpSrc);
	if (Magic != 0x6F6D6A89)		// "jmox", simple file varification
	{
		printf_s("Wrong file format!\n");
		exit(1);
	}

	printf_s("Processing %s...\t", FileName);

	fseek(fpSrc, 0x11, SEEK_SET);
	fread_s(&Offset, 4, 4, 1, fpSrc);
	fread_s(&Count, 2, 2, 1, fpSrc);

	ModelCount = Count;
	strncpy_s(FbxName, 256, FileName, strlen(FileName) - 11);
	strcat_s(FbxName, 256, "FBX");
	CreateFbxFile(&fpFBX, FbxName, Max, inches, ModelCount);

	fseek(fpSrc, Offset, SEEK_SET);
	for (short i = 0; i < Count; i++)
	{
		InitialModel(&mdl);
		fread_s(&Length, 2, 2, 1, fpSrc);
		fread_s(mdl.ModelName, 64, Length, 1, fpSrc);
		mdl.ModelName[Length] = 0;

		fread_s(&pID, 2, 2, 1, fpSrc);
		fread_s(position, 12, 4, 3, fpSrc);
		fread_s(rotation, 16, 4, 4, fpSrc);
		fread_s(scale, 12, 4, 3, fpSrc);
		fseek(fpSrc, 2L, SEEK_CUR);

		if (pID < 0)
			mdl.parentID = 0ull;
		else
			mdl.parentID = (ULONG64)pID + 1ull;
		mdl.UID = (ULONG64)i + 1ull;
		mdl.NodeAttributeUID = mdl.UID + 100000ull;

		Quat2EulerAngles(rotation, EulerRotation);
		for (int j = 0; j < 3; j++)
		{
			mdl.Translation[j] = (double)position[j];
			mdl.Rotation[j] = (double)EulerRotation[j];
			mdl.Scaling[j] = (double)scale[j];
		}

		WriteMdl(fpFBX, &mdl, &MaxHandle);
		AppendO2OList(&mdlList, &mdl);
	}
	fclose(fpSrc);

	ConnectO2O(fpFBX, mdlList);
	DestroyNodeList(&mdlList);

	printf_s("finished!\n");

	return 0;
}

// Assalt Fire(PC)
int afmConv(char *ArcName)
{
	// Common variables for skelBuilder
	FILE *fpSrc;
	FILE *fpFBX;
	int ModelCount = 0;
	int MaxHandle = 2;
	Model mdl;
	Node *mdlList = NULL;

	// Prefered variables for extraction
	double EulerRotation[3] = { 0.0 };
	float position[3];
	float rotation[4];
	char FileName[256] = { 0 }, FbxName[256] = { 0 };

	long Count;
	int aInt;
	char *NameBuf;
	char *pChar;

	GetFileName(ArcName, FileName, 256);

	if (fopen_s(&fpSrc, ArcName, "rb") != 0)
	{
		printf_s("error! cannot open file %s\n", FileName);
		exit(1);
	}

	printf_s("Processing %s...\t", FileName);

	strncpy_s(FbxName, 256, FileName, strlen(FileName) - 3);
	strcat_s(FbxName, 256, "FBX");

	// ### process starts ### //
	fseek(fpSrc, 0L, SEEK_END);
	aInt = ftell(fpSrc);
	fseek(fpSrc, 0L, SEEK_SET);
	fread_s(&Count, 4, 4, 1, fpSrc);
	fseek(fpSrc, Count * 0x34, SEEK_CUR);
	aInt -= ftell(fpSrc);
	NameBuf = (char *)malloc(aInt);
	pChar = NameBuf;
	fread_s(NameBuf, aInt, aInt, 1, fpSrc);
	fseek(fpSrc, 4L, SEEK_SET);

	ModelCount = Count;
	PreRotation[0] = 0.0;
	PreRotation[1] = -90.0;
	PreRotation[2] = 0.0;
	CreateFbxFile(&fpFBX, FbxName, Max, inches, ModelCount);

	for (int i = 0; i < Count; i++)
	{
		InitialModel(&mdl);
		fseek(fpSrc, 12L, SEEK_CUR);

		fread_s(rotation, 16, 16, 1, fpSrc);
		fread_s(position, 12, 4, 3, fpSrc);
		fseek(fpSrc, 4L, SEEK_CUR);
		fread_s(&aInt, 4, 4, 1, fpSrc);
		fseek(fpSrc, 4L, SEEK_CUR);

		strcpy_s(mdl.ModelName, 64, pChar);
		pChar += strlen(pChar) + 1;

		if (i != 0)
			mdl.parentID = (ULONG64)aInt + 1ull;
		mdl.UID = (ULONG64)i + 1ull;
		mdl.NodeAttributeUID = mdl.UID + 100000ull;

		Quat2EulerAngles(rotation, EulerRotation);
		
		mdl.Translation[0] = (double)position[2];
		mdl.Translation[1] = (double)position[1];
		mdl.Translation[2] = (double)position[0];
		mdl.Rotation[0] = EulerRotation[2];
		mdl.Rotation[1] = EulerRotation[1];
		mdl.Rotation[2] = EulerRotation[0];

		WriteMdl(fpFBX, &mdl, &MaxHandle);
		AppendO2OList(&mdlList, &mdl);
	}
	free(NameBuf);
	fclose(fpSrc);

	ConnectO2O(fpFBX, mdlList);
	DestroyNodeList(&mdlList);

	printf_s("finished!\n");
	//system("pause");
	return 0;
}

// Ben 10 Omniverse(Xbox 360)
int ve2Conv(char *ArcName)
{
	// Common variables for skelBuilder
	FILE *fpSrc;
	FILE *fpFBX;
	int ModelCount = 0;
	int MaxHandle = 2;
	Model mdl;
	Node *mdlList = NULL;

	// Prefered variables for extraction
	float Translation[3];
	double Rotation[3];
	double Scaling[3];
	float Mat3x3[9];
	char FileName[256] = { 0 }, FbxName[256] = { 0 };

	long Count;
	int parentID;


	GetFileName(ArcName, FileName, 256);

	if (fopen_s(&fpSrc, ArcName, "rb") != 0)
	{
		printf_s("error! cannot open file %s\n", FileName);
		exit(1);
	}

	printf_s("Processing %s...\t", FileName);
	//printf_s("\n");
	strncpy_s(FbxName, 256, FileName, strlen(FileName) - 3);
	strcat_s(FbxName, 256, "FBX");

	// ### process starts ### //
	EndianBigRead(&Count, 4, 4, 1, fpSrc);

	ModelCount = Count;
	CreateFbxFile(&fpFBX, FbxName, Max, inches, ModelCount);

	for (int i = 0; i < Count; i++)
	{
		InitialModel(&mdl);
		EndianBigRead(&parentID, 4, 4, 1, fpSrc);
		EndianBigRead(Translation, 12, 4, 3, fpSrc);
		EndianBigRead(Mat3x3, 36, 4, 9, fpSrc);

		fseek(fpSrc, 4L, SEEK_CUR);
		fread_s(mdl.ModelName, 64, 0x24, 1, fpSrc);
		fseek(fpSrc, 4L, SEEK_CUR);

		mdl.parentID = (ULONG64)(parentID + 1);
		mdl.UID = (ULONG64)i + 1ull;
		mdl.NodeAttributeUID = mdl.UID + 100000ull;

		TransposeMatrix33(Mat3x3);
		Matrix33ToRS(Mat3x3, Rotation, Scaling, XYZ);
		mdl.Translation[0] = (double)Translation[0];
		mdl.Translation[1] = (double)Translation[1];
		mdl.Translation[2] = (double)Translation[2];
		mdl.Rotation[0] = Rotation[0]; 
		mdl.Rotation[1] = Rotation[1];
		mdl.Rotation[2] = Rotation[2];
		mdl.Scaling[0] = Scaling[0];
		mdl.Scaling[1] = Scaling[1];
		mdl.Scaling[2] = Scaling[2];

		WriteMdl(fpFBX, &mdl, &MaxHandle);
		AppendO2OList(&mdlList, &mdl);
	}
	fclose(fpSrc);

	ConnectO2O(fpFBX, mdlList);
	DestroyNodeList(&mdlList);

	//system("pause");

	printf_s("finished!\n");
	return 0;
}

// Iron Man 2(PS3)
int skeletonConv(char *ArcName)
{
	// Common variables for skelBuilder
	FILE *fpSrc;
	FILE *fpFBX;
	int ModelCount = 0;
	int MaxHandle = 2;
	Model mdl;
	Node *mdlList = NULL;

	// Prefered variables for extraction
	double Translation[3];
	double Rotation[3];
	double Scaling[3];
	float Mat4x4[16];
	float invMat44[16];
	char FileName[256] = { 0 }, FbxName[256] = { 0 };

	long Count;
	int Offset, Size;
	int *parentIdxBuf;
	float *MatrixBuf;
	float *pMatrix;
	float *pParentMatrix;
	int parentID;
	char *NameBuf;
	char *pChar;

	GetFileName(ArcName, FileName, 256);

	printf_s("Processing %s...\t", FileName);
	if (fopen_s(&fpSrc, ArcName, "rb") != 0)
	{
		printf_s("error! cannot open file %s\n", FileName);
		exit(1);
	}

	strncpy_s(FbxName, 256, FileName, strlen(FileName) - 8);
	strcat_s(FbxName, 256, "FBX");

	// ### process starts ### //
	fseek(fpSrc, 0L, SEEK_END);
	Size = ftell(fpSrc);

	fseek(fpSrc, 0xC, SEEK_SET);
	EndianBigRead(&Offset, 4, 4, 1, fpSrc);
	EndianBigRead(&Count, 4, 4, 1, fpSrc);
	Offset += 0x10;
	Size -= Offset;
	fseek(fpSrc, Offset, SEEK_SET);

	NameBuf = (char*)malloc(Size);
	fread_s(NameBuf, Size, Size, 1, fpSrc);
	pChar = NameBuf;
	fseek(fpSrc, 0x14, SEEK_SET);

	ModelCount = Count;
	CreateFbxFile(&fpFBX, FbxName, OpenGL, inches, ModelCount);

	parentIdxBuf = (int *)malloc(Count * sizeof(int));
	MatrixBuf = (float *)malloc(Count * 0x40);
	pMatrix = MatrixBuf;
	// reading and preprocessing matries
	for (int i = 0; i < Count; i++)
	{
		fseek(fpSrc, 4L, SEEK_CUR); // skip boneID
		EndianBigRead(parentIdxBuf + i, 4, 4, 1, fpSrc);
		fseek(fpSrc, 4L, SEEK_CUR);
		EndianBigRead(Mat4x4, 64, 4, 16, fpSrc);
		inv(pMatrix, Mat4x4, ColMajor);

		// Converting left handed to right handed (OpenGL)
		pMatrix[2] = -pMatrix[2];
		pMatrix[6] = -pMatrix[6];
		pMatrix[8] = -pMatrix[8];
		pMatrix[9] = -pMatrix[9];

		pMatrix += 16;
	}
	fclose(fpSrc);

	pMatrix = MatrixBuf;
	for (int i = 0; i < Count; i++)
	{
		InitialModel(&mdl);
		strcpy_s(mdl.ModelName, 64, pChar);
		pChar += strlen(pChar) + 1;
		parentID = parentIdxBuf[i];
		if (parentID != i)
		{
			mdl.parentID = (ULONG64)parentID + 1;
			// Converting world matrix to parent space
			pParentMatrix = MatrixBuf + parentID * 16;
			inv(invMat44, pParentMatrix, ColMajor);
			mul(Mat4x4, invMat44, pMatrix, ColMajor);
		}
		else
			memcpy(Mat4x4, pMatrix, 0x40);
		pMatrix += 16;
		mdl.UID = (ULONG64)i + 1ull;
		mdl.NodeAttributeUID = mdl.UID + 100000ull;

		TransposeMatrix44(Mat4x4);
		Matrix344ToTRS(Mat4x4, Translation, Rotation, Scaling, XYZ);
		mdl.Translation[0] = Translation[0]; // 
		mdl.Translation[1] = Translation[1]; // 
		mdl.Translation[2] = Translation[2]; // 
		mdl.Rotation[0] = Rotation[0]; // 
		mdl.Rotation[1] = Rotation[1]; // 
		mdl.Rotation[2] = Rotation[2]; // 
		mdl.Scaling[0] = Scaling[0]; // 
		mdl.Scaling[1] = Scaling[1]; // 
		mdl.Scaling[2] = Scaling[2]; // 

		WriteMdl(fpFBX, &mdl, &MaxHandle);
		AppendO2OList(&mdlList, &mdl);
	}

	free(MatrixBuf);
	free(parentIdxBuf);
	free(NameBuf);

	ConnectO2O(fpFBX, mdlList);
	DestroyNodeList(&mdlList);
	
	printf_s("finished!\n");
	//system("pause");
	return 0;
}

// James Cameron's AVATAR THE GAME(PC)
int xbgConv(char *ArcName)
{
	// Common variables for skelBuilder
	FILE *fpSrc;
	FILE *fpFBX;
	int ModelCount = 0;
	int MaxHandle = 2;
	Model mdl;
	Node *mdlList = NULL;
	// Prefered variables for extraction
	double EulerRotation[3] = { 0.0 };
	float position[3];
	float rotation[4];
	float scale[3];
	char FileName[256] = { 0 }, FbxName[256] = { 0 };

	int Count;
	int pID;
	int Length;

	GetFileName(ArcName, FileName, 256);

	if (fopen_s(&fpSrc, ArcName, "rb") != 0)
	{
		printf_s("error! cannot open file %s\n", FileName);
		exit(1);
	}

	printf_s("Processing %s...\t", FileName);

	fread_s(&Count, 4, 4, 1, fpSrc);

	PreRotation[0] = -180.0;
	PreRotation[1] = -90.0;
	PreRotation[2] = 0.0;

	ModelCount = Count;
	strncpy_s(FbxName, 256, FileName, strlen(FileName) - 3);
	strcat_s(FbxName, 256, "FBX");
	CreateFbxFile(&fpFBX, FbxName, Max, inches, ModelCount);

	for (short i = 0; i < Count; i++)
	{
		InitialModel(&mdl);
		fseek(fpSrc, 0xC, SEEK_CUR);
		fread_s(&pID, 4, 4, 1, fpSrc);
		fread_s(rotation, 16, 4, 4, fpSrc);
		fread_s(position, 12, 4, 3, fpSrc);
		fread_s(scale, 12, 4, 3, fpSrc);
		fseek(fpSrc, 0xC, SEEK_CUR);
		fread_s(&Length, 4, 4, 1, fpSrc);
		fread_s(mdl.ModelName, 64, Length + 1, 1, fpSrc);

		if (pID < 0)
			mdl.parentID = 0ull;
		else
			mdl.parentID = (ULONG64)pID + 1ull;
		mdl.UID = (ULONG64)i + 1ull;
		mdl.NodeAttributeUID = mdl.UID + 100000ull;

		Quat2EulerAngles(rotation, EulerRotation);

		mdl.Translation[0] = (double)position[2];
		mdl.Translation[1] = (double)position[1];
		mdl.Translation[2] = (double)position[0];
		mdl.Rotation[0] = EulerRotation[2];
		mdl.Rotation[1] = EulerRotation[1];
		mdl.Rotation[2] = EulerRotation[0];
		mdl.Scaling[0] = (double)scale[2];
		mdl.Scaling[1] = (double)scale[1];
		mdl.Scaling[2] = (double)scale[0];

		WriteMdl(fpFBX, &mdl, &MaxHandle);
		AppendO2OList(&mdlList, &mdl);
	}
	fclose(fpSrc);

	ConnectO2O(fpFBX, mdlList);
	DestroyNodeList(&mdlList);

	printf_s("finished!\n");

	return 0;
}

// Ben 10 Omniverse 2(3DS)
int rnConv(char *ArcName)
{
	// Common variables for skelBuilder
	FILE *fpSrc;
	FILE *fpFBX;
	int ModelCount = 0;
	int MaxHandle = 2;
	Model mdl;
	Node *mdlList = NULL;

	// Prefered variables for extraction
	double Translation[3];
	double Rotation[3];
	double Scaling[3];
	float Mat4x3[12];
	char FileName[256] = { 0 }, FbxName[256] = { 0 };

	int Count;
	int Offset;
	int ID, parentID;
	char buf[4];

	GetFileName(ArcName, FileName, 256);

	if (fopen_s(&fpSrc, ArcName, "rb") != 0)
	{
		printf_s("error! cannot open file %s\n", FileName);
		exit(1);
	}

	printf_s("Processing %s...\t", FileName);
	//printf_s("\n");
	strncpy_s(FbxName, 256, FileName, strlen(FileName) - 2);
	strcat_s(FbxName, 256, "FBX");

	// ### process starts ### //
	fseek(fpSrc, 4L, SEEK_CUR);
	fread_s(&Offset, 4, 4, 1, fpSrc);
	fread_s(&Count, 4, 4, 1, fpSrc);
	fseek(fpSrc, Offset, SEEK_SET);

	ModelCount = Count;
	CreateFbxFile(&fpFBX, FbxName, OpenGL, inches, ModelCount);

	for (int i = 0; i < Count; i++)
	{
		InitialModel(&mdl);

		fseek(fpSrc, 8L, SEEK_CUR);
		fread_s(&ID, 4, 4, 1, fpSrc);
		fread_s(&parentID, 4, 4, 1, fpSrc);
		fseek(fpSrc, 0x34, SEEK_CUR);
		fread_s(Mat4x3, 48, 4, 12, fpSrc);
		fseek(fpSrc, 0x6C, SEEK_CUR);
		_itoa_s(i, buf, 4, 10);
		strcpy_s(mdl.ModelName, 64, "bone_");
		strcat_s(mdl.ModelName, 64, buf);

		mdl.parentID = (ULONG64)(parentID + 1);
		mdl.UID = (ULONG64)ID + 1ull;
		mdl.NodeAttributeUID = mdl.UID + 100000ull;

		Matrix344ToTRS(Mat4x3, Translation, Rotation, Scaling, XYZ);
		for (int j = 0; j < 3; j++)
		{
			mdl.Translation[j] = Translation[j];
			mdl.Rotation[j] = Rotation[j];
			mdl.Scaling[j] = Scaling[j];
		}

		WriteMdl(fpFBX, &mdl, &MaxHandle);
		AppendO2OList(&mdlList, &mdl);
	}
	fclose(fpSrc);
	ConnectO2O(fpFBX, mdlList);
	DestroyNodeList(&mdlList);

	//system("pause");

	printf_s("finished!\n");
	return 0;
}

// GuJian3(PC)
int modelConv(char *ArcName)
{
	// Common variables for skelBuilder
	FILE *fpSrc;
	FILE *fpFBX;
	int ModelCount = 0;
	int MaxHandle = 2;
	Model mdl;
	Node *mdlList = NULL;
	// Prefered variables for extraction
	double EulerRotation[3] = { 0.0 };
	float position[3];
	float rotation[4];
	char FileName[256] = { 0 }, FbxName[256] = { 0 };

	short Count;
	short pID;
	int Length;

	GetFileName(ArcName, FileName, 256);

	if (fopen_s(&fpSrc, ArcName, "rb") != 0)
	{
		printf_s("error! cannot open file %s\n", FileName);
		exit(1);
	}

	printf_s("Processing %s...\t", FileName);

	fread_s(&Count, 2, 2, 1, fpSrc);

	ModelCount = Count;
	strncpy_s(FbxName, 256, FileName, strlen(FileName) - 5);
	strcat_s(FbxName, 256, "FBX");
	CreateFbxFile(&fpFBX, FbxName, Max, inches, ModelCount);

	for (short i = 0; i < Count; i++)
	{
		InitialModel(&mdl);
		fread_s(&Length, 4, 4, 1, fpSrc);
		fread_s(mdl.ModelName, 64, Length, 1, fpSrc);
		mdl.ModelName[Length] = 0;

		fread_s(&pID, 2, 2, 1, fpSrc);
		fseek(fpSrc, 28L, SEEK_CUR);
		fread_s(position, 12, 4, 3, fpSrc);
		fread_s(rotation, 16, 4, 4, fpSrc);

		mdl.parentID = (ULONG64)pID + 1ull;
		mdl.UID = (ULONG64)i + 1ull;
		mdl.NodeAttributeUID = mdl.UID + 100000ull;

		Quat2EulerAngles(rotation, EulerRotation);
		for (int j = 0; j < 3; j++)
		{
			mdl.Translation[j] = (double)position[j];
			mdl.Rotation[j] = (double)EulerRotation[j];
		}

		WriteMdl(fpFBX, &mdl, &MaxHandle);
		AppendO2OList(&mdlList, &mdl);
	}
	fclose(fpSrc);

	ConnectO2O(fpFBX, mdlList);
	DestroyNodeList(&mdlList);

	printf_s("finished!\n");

	return 0;
}

// Cyber Hunter(Android)
int meshConv(char *ArcName)
{
	// Common variables for skelBuilder
	FILE *fpSrc;
	FILE *fpFBX;
	int ModelCount = 0;
	int MaxHandle = 2;
	Model mdl;
	Node *mdlList = NULL;

	// Prefered variables for extraction
	double Translation[3];
	double Rotation[3];
	double Scaling[3];
	float Mat4x4[16];
	float invMat44[16];
	char FileName[256] = { 0 }, FbxName[256] = { 0 };

	short Count;
	BYTE *pIdxBuf;
	char *nameBuf;
	char *pBoneName;
	char *MatrixBuf;
	char *pMatrix;
	char *pParentMatrix;
	float *pFloat;
	int parentID;

	GetFileName(ArcName, FileName, 256);

	if (fopen_s(&fpSrc, ArcName, "rb") != 0)
	{
		printf_s("error! cannot open file %s\n", FileName);
		return ERROR_OPEN_FILE;
	}

	printf_s("Processing %s...\t", FileName);

	strncpy_s(FbxName, 256, FileName, strlen(FileName) - 4);
	strcat_s(FbxName, 256, "FBX");

	// ### process starts ### //
	fread_s(&Count, 2, 2, 1, fpSrc);
	pIdxBuf = (BYTE *)malloc(Count);
	fread_s(pIdxBuf, Count, Count, 1, fpSrc);
	nameBuf = (char *)malloc(Count * 0x20);
	pBoneName = nameBuf;
	MatrixBuf = (char *)malloc(Count * 0x40);
	pMatrix = MatrixBuf;
	pFloat = (float *)MatrixBuf;
	fread_s(nameBuf, Count * 0x20, Count * 0x20, 1, fpSrc);
	fread_s(MatrixBuf, Count * 0x40, Count * 0x40, 1, fpSrc);
	fclose(fpSrc);

	// Convert World Matrices from DirectX to OpenGL 
	for (int i = 0; i < Count; i++)
	{
		pFloat[1] = -pFloat[1];
		pFloat[2] = -pFloat[2];
		pFloat[4] = -pFloat[4];
		pFloat[8] = -pFloat[8];
		pFloat[12] = -pFloat[12];
		pFloat += 16;
	}

	ModelCount = Count;
	CreateFbxFile(&fpFBX, FbxName, OpenGL, inches, ModelCount);

	for (int i = 0; i < Count; i++)
	{
		InitialModel(&mdl);
		
		memcpy_s(mdl.ModelName, 64, pBoneName, 32);
		pBoneName += 0x20;
		memcpy_s(Mat4x4, 0x40, pMatrix, 0x40);
		pMatrix += 0x40;

		parentID = (int)pIdxBuf[i];

		mdl.UID = (ULONG64)i + 1;
		mdl.NodeAttributeUID = (ULONG64)i + +100000ull;

		if (parentID != 0xFF)
		{
			mdl.parentID = (ULONG64)parentID + 1;
			pParentMatrix = MatrixBuf + parentID * 0x40;
			inv(invMat44, (const float *)pParentMatrix, ColMajor);
			mul(Mat4x4, invMat44, Mat4x4, ColMajor);
		}
		else
			mdl.parentID = 0ull;

		TransposeMatrix44(Mat4x4);

		Matrix344ToTRS(Mat4x4, Translation, Rotation, Scaling, XYZ);

		for (int j = 0; j < 3; j++)
		{
			mdl.Translation[j] = Translation[j];
			mdl.Rotation[j] = Rotation[j];
			mdl.Scaling[j] = Scaling[j];
		}
		
		WriteMdl(fpFBX, &mdl, &MaxHandle);
		AppendO2OList(&mdlList, &mdl);
	}
	free(pIdxBuf);
	free(nameBuf);
	free(MatrixBuf);

	ConnectO2O(fpFBX, mdlList);
	DestroyNodeList(&mdlList);

	printf_s("finished!\n");
	//system("pause");
	return 0;
}

/* Obtain Filename from Path
filename: parameter for archive name that may contain the path
dst: destination where filename will be stored
Length: size of dst
*/
void GetFileName(char *filename, char dst[], int Length)
{
	int Len, l;

	Length -= 1;
	Len = strlen(filename);
	for (short i = Len - 1; i >= 0; i--)
	{
		if (filename[i] == 92)	// backslash '\' 
		{
			Len -= i;
			if (Len > Length)
			{
				printf_s("Error! Length of string is beyond the maximum length!\n");
				return;
			}

			i += 1;
			for (l = 0; l < Len; l++)
				dst[l] = filename[i + l];
			dst[l] = 0;
			return;
		}
	}
	strcpy_s(dst, Length, filename);
}

