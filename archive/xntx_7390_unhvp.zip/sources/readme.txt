UnHVP v1.0 - HV PackFile Resource
(C) Copyright Baccello, 2004-2005. All Rights Reserved.
baccello@infinito.it

Notice:
1) All strings marked as "/* FIX */" in "unhvp.cpp" different from original source code.
2) zlib header files and static library from "zlib114dll.zip" (http://www.winimage.com/zLibDll/)
3) Executable compiled with MS VC++ 6.0 and optimized by size (see "vc60-compile.bat")

30.06.2007
-=CHE@TER=-
http://CTPAX-CHEATER.losthost.org/personal.htm
