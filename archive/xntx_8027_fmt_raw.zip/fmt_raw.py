from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("unity3d raw mesh", ".dat")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)
    noesis.logPopup()
    return 1

def noepyCheckType(data):
    if len(data) < 0x80:
        return 0
    return 1

def noepyLoadModel(data, mdlList):
    bs = NoeBitStream(data)
    fileSize = bs.getSize() - 0x80
    
    m_Name = noeAsciiFromBytes(bs.readBytes(bs.readInt()))
    print(m_Name)
    skipZero(bs)
    m_SubMeshes = bs.readInt()#Array
    
    bones = []
    meshes = []
    for x in range(m_SubMeshes):
        #SubMesh data
        firstByte  = bs.readInt()
        indexCount = bs.readInt()
        topology = bs.readInt()
        firstVertex = bs.readInt()
        skipZero(bs)
        vertexCount = bs.readInt()

        #localAABB
        m_Center = NoeVec3.fromBytes(bs.readBytes(12))
        m_Extent = NoeVec3.fromBytes(bs.readBytes(12))

        #BlendShapeData 
        vertices_size = bs.readInt()
        shapes_size = bs.readInt()
        channels_size = bs.readInt()
        fullWeights_size = bs.readInt()

        #m_BindPose 
        size = bs.readInt()
        m_BindPose = []
        for b in range(size):
            m_BindPose.append(NoeMat44.fromBytes(bs.readBytes(64)).toMat43())

        #m_BoneNameHashes
        size = bs.readInt()
        m_BoneNameHashes = [bs.readUInt() for x in range(size)]
        m_RootBoneNameHash = bs.readUInt()
        m_MeshCompression = bs.readUByte()
        m_IsReadable = bs.readUByte()#bool
        m_KeepVertices = bs.readUByte()#bool
        m_KeepIndices = bs.readUByte()#bool

        #create Bones
        for i in range(size):
            print(i, str(m_BoneNameHashes[i]),m_BindPose[i].toQuat())
            #print(i, m_BindPose[i][3])
            bones.append(NoeBone(i, str(m_BoneNameHashes[i]), m_BindPose[i]))

        #m_IndexBuffer
        skipZero(bs)
        size = bs.readInt()
        m_IndexBuffer = [bs.readUShort() for x in range(indexCount)]

        #m_Skin
        skipZero(bs)
        size = bs.readInt()
        m_Skin = []
        for s in range(size):
            bWe = [bs.readFloat() for x in range(4)]
            bID = [bs.readInt() for x in range(4)]
            m_Skin.append(NoeVertWeight(bID,bWe))

        #m_VertexData
        m_CurrentChannels = bs.readInt()
        m_VertexCount = bs.readInt()
        size = bs.readInt()
        
        m_Channels = []#0-vertex; 1-normals; 2-unk; 3-uvs; 4-unk; 5-unk; 6-unk; 7-tangens
        for c in range(size):
            m_Channels.append([bs.readUByte() for x in range(4)])
        
        size = bs.readInt()
        m_Vertices = []
        m_Normals = []
        m_Tangents = []
        m_UV = []
        
        mat_rot = NoeAngles([90,0,0]).toMat43()
        mat_rot[0][0] = -1
        #mat_rot = bones[BoneIndex(m_RootBoneNameHash, bones)].getMatrix()
        for v in range(vertexCount):
            m_Vertices.append(NoeVec3.fromBytes(bs.readBytes(12))*mat_rot)
            if m_Channels[1][3] != 0:
                m_Normals.append(NoeVec3.fromBytes(bs.readBytes(12)))
            #m_Tangents = NoeVec4.fromBytes(bs.readBytes(16))
            if m_Channels[7][3] != 0:
                bs.seek(m_Channels[7][3]*4,NOESEEK_REL)
        
        bs.seek(8,NOESEEK_REL)
        pud = 0
        for c in m_Channels:
            if c[0] == 1 and c[1] != 0:
                pud += c[3]*4
        for v in range(vertexCount):
           m_UV.append(NoeVec3([bs.readFloat(),-bs.readFloat(),0]))
           bs.seek(pud,NOESEEK_REL)
       
        mesh = NoeMesh(m_IndexBuffer, m_Vertices, "mesh_"+str(x), "mat_0")
        mesh.setNormals(m_Normals)
        #mesh.setTangents(m_Tangents)
        mesh.setUVs(m_UV)
        mesh.setWeights(m_Skin)
        meshes.append(mesh)
    
    pathDir = rapi.getDirForFilePath(rapi.getInputName())
    #=======TXT==========
    txt_path = "_".join(rapi.getInputName().split('_')[:-1])+"_m2b.txt"#H_gulong_body_m2b.txt
    bone_map = []
    with open(txt_path, "r") as txt:
        bone_map = txt.read().splitlines()
        for i,bone in enumerate(bones):
            bone.name = bone_map[i]
    #=======FBX==========
    fbx_path = os.path.join(pathDir,"Bip001.fbx")
    fbx_bones = []
    with open(fbx_path, "r") as fbx:
        lines = fbx.read().splitlines()
        fbx_bones = FBXLoad(lines)
    #=======END_FBX=======

    if fbx_bones:
        for x in range(len(m_Skin)):
            m_Skin[x].indices = [BoneIndex(bones[y].name, fbx_bones) for y in m_Skin[x].indices]
        
        #root_mat = fbx_bones[1].getMatrix()
        #root_mat[3] = NoeVec3()
        #for v in range(vertexCount):
            #m_Vertices[v] = m_Vertices[v]*root_mat

    mdl = NoeModel(meshes)
    mdl.setBones(fbx_bones if fbx_bones else bones)
    mdl.setModelMaterials(NoeModelMaterials([], [NoeMaterial("mat_0","")]))
    mdlList.append(mdl)
    return 1
    
def skipZero(bs):
    byte = 0
    while byte == 0:
        byte = bs.readByte()
    bs.seek(-1,NOESEEK_REL)
    return 1
    
#=======FBX=======
def FBXLoad(lines):
    file = lines
    bones = []
    conections = []
    
    for i in range(len(file)):
        split = file[i].split()
        if "Connections:" in split:
            conections = Connections(FindBracket(file[i:]))
        if "Pose:" in split:
            bones = Pose(FindBracket(file[i:]))
    
    #get parent
    for conect in conections:
        bones[BoneIndex(conect[0],bones)].parentIndex = BoneIndex(conect[1],bones)
    
    return bones
  
def Pose(arr):
    bones = []
    for x in range(1,len(arr)):
        split = arr[x].split()
        if "PoseNode:" in split:
            bone = PoseNode(FindBracket(arr[x:]))
            bone.index = len(bones)
            bones.append(bone)
    return bones

def PoseNode(arr):#Matrix:
    name = arr[1].split('"')[1].split('::')[1]
    mat_string = "".join(arr[2:-1])
    mat  = [float(x) for x in mat_string.split('#')[0].split(':')[1].split(',')]
    mat = NoeMat44([NoeVec4(mat[:4]),NoeVec4(mat[4:8]),NoeVec4(mat[8:12]),NoeVec4(mat[12:16])])
    bones = NoeBone(0, name, mat.toMat43())
    return bones
    
def Connections(arr):
    connect = []
    for x in range(1,len(arr)):
        split = arr[x].split('"')
        connect.append([split[3].split('::')[1], split[5].split('::')[1]])
    return connect
    
def FindBracket(arr):
    bracket = 0
    for i,line in enumerate(arr):
        if '{' in line:
            bracket += 1
        if '}' in line:
            bracket -= 1
        if bracket==0:
            return arr[:i]
            break
            
def BoneIndex(name, bones):
    for i,bone in enumerate(bones):
        if bone.name == name:
            return i
    return -1