#include <pspsdk.h>
#include <pspkernel.h>
#include <pspctrl.h>
#include <kubridge.h>
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <stdlib.h>

PSP_MODULE_INFO("PsxDecryptionTest", 0, 1, 0);
PSP_MAIN_THREAD_ATTR(PSP_THREAD_ATTR_USER);

#define printf pspDebugScreenPrintf

typedef struct __attribute__((packed))
{
	u32 offset;
	u32 length;
	u32 somechecksum[4];
	u32 dummy[2];
} IsoIndex;

void ErrorExit(int milisecs, char *fmt, ...)
{
	va_list list;
	char msg[256];	

	va_start(list, fmt);
	vsprintf(msg, fmt, list);
	va_end(list);

	printf(msg);

	sceKernelDelayThread(milisecs*1000);
	sceKernelExitGame();
}

int ReadFile(char *file, void *buf, int size)
{
	SceUID fd = sceIoOpen(file, PSP_O_RDONLY, 0777);

	if (fd < 0)
	{
		return fd;
	}

	int read = sceIoRead(fd, buf, size);
	sceIoClose(fd);

	return read;
}
int WriteFile(char *file, void *buf, int size)
{
	SceUID fd = sceIoOpen(file, PSP_O_WRONLY | PSP_O_CREAT | PSP_O_TRUNC, 0777);

	if (fd < 0)
	{
		return fd;
	}

	int written = sceIoWrite(fd, buf, size);
	sceIoClose(fd);

	return written;
}

int pspPopsDNASDecrypt(char *file, u8 *keys, int encrypt_offset, void *out, int offset, int size);

u8 header[0xb3880] __attribute__((aligned(64)));
u8 buf[1048576] __attribute__((aligned(64)));
u8 buf2[64*1024] __attribute__((aligned(64)));

u8 generic_keys[0x10] = 
{
	0x2E, 0x41, 0x17, 0xA5, 0x32, 0xE6, 0xC4, 0x73, 
	0x71, 0x7B, 0x0F, 0x7A, 0x6E, 0xC0, 0xAA, 0xA5
};

int (* Decompress)(void *dest, int dest_capacity, void *src, void *nullme);

int main() 
{
	SceCtrlData pad;
	int res;
	
	pspDebugScreenInit();
	pspDebugScreenClear();

	if (sceKernelDevkitVersion() != 0x03000310)
	{
		ErrorExit(8000, "This application is done specifcly for firmware 3.03.\n"
						"If you are in 3.03 OE and receive this message, then remember "
						"to execute this application under the 3.03 kernel.\n");
	}

	sceKernelSetCompiledSdkVersion(0x03000310);

	SceUID mod = pspSdkLoadStartModule("popsdnas.prx", PSP_MEMORY_PARTITION_KERNEL);
	if (mod < 0)
	{
		ErrorExit(8000, "Error 0x%08X loading popsdnas.prx\n", mod);
	}

	printf("Press X to decrypt game.pbp.\nPress O to decrypt document.dat\nPress start to exit.\n");

	while (1)
	{
		u8 keys[0x10];
		int signature;
		int offset, read;
		SceKernelModuleInfo info;
		SceUID fd, out;

		sceCtrlReadBufferPositive(&pad, 1);

		if (pad.Buttons & PSP_CTRL_CROSS)
		{
			u32 pbp_header[0x28/4];
						
			fd = sceIoOpen("GAME.PBP", PSP_O_RDONLY, 0777);
			if (fd < 0)
			{
				ErrorExit(8000, "Cannot open GAME.PBP\n");
			}

			if (ReadFile("KEYS.BIN", keys, 0x10) != 0x10)
			{
				ErrorExit(8000, "Error reading keys.bin file.\n");
			}

			sceIoRead(fd, pbp_header, 0x28);
			
			offset = pbp_header[9] + 0x0400;
			sceIoLseek(fd, offset, PSP_SEEK_SET);

			sceIoRead(fd, &signature, 4);
					
			if (signature != 0x44475000) /* PGD */
			{
				sceIoClose(fd);
				ErrorExit(8000, "Not encrypted file.\n");
			}	
			
			printf("Decrypting header...\n");

			if (pspPopsDNASDecrypt("GAME.PBP", keys, offset, header, 0, sizeof(header)) < 0)
			{
				sceIoClose(fd);
				ErrorExit(8000, "Error decrypting iso header.\n");
			}

			WriteFile("iso_header.bin", header, sizeof(header));

			offset = *(u32 *)(header+0xE20);
			offset += pbp_header[9];

			printf("Decrypting special data...\n");
			
			read = pspPopsDNASDecrypt("GAME.PBP", generic_keys, offset, buf, 0, sizeof(buf));
			if (read < 0)
			{
				sceIoClose(fd);
				ErrorExit(8000, "Error 0x%08X decrypting special data.\n", read);
			}

			WriteFile("special_data.bin", buf, read);

			mod = kuKernelLoadModule("flash0:/kd/pops.prx", 0, NULL);
			if (mod < 0)
			{
				sceIoClose(fd);
				ErrorExit(8000, "Error 0x%08X loading pops.prx.\n");
			}

			memset(&info, 0, sizeof(info));
			info.size = sizeof(info);

			res = sceKernelQueryModuleInfo(mod, &info);
			if (res < 0)
			{
				sceIoClose(fd);
				ErrorExit(8000, "Error 0x%08X in sceKernelQueryModuleInfo.\n", res);
			}

			//printf("text addr = 0x%08X\n", info.text_addr);
			// 3.03 specific...
			Decompress = (void *)(info.text_addr+0x12D74);
			IsoIndex *index = (IsoIndex *)(header+0x3c00);

			printf("Decompressing iso...\n");

			out = sceIoOpen("image.iso", PSP_O_WRONLY | PSP_O_CREAT | PSP_O_TRUNC, 0777);
			if (out < 0)
			{
				sceIoClose(fd);
				ErrorExit(8000, "Cannot create image.iso.\n");
			}

			while (1)
			{
				if (index->length == 0)
					break;

				sceIoLseek(fd, pbp_header[9]+0x100000+index->offset, PSP_SEEK_SET);
				sceIoRead(fd, buf, index->length);

				if (index->length == 0x9300) /* not compressed */
				{
					sceIoWrite(out, buf, 0x9300);
				}
				else
				{
					res = Decompress(buf2, 0x9300, buf, NULL);
					if (res  < 0)
					{
						ErrorExit(8000, "Error 0x%08X at some point of decompression.\n", res);
					}

					sceIoWrite(out, buf2, res);
				}

				index++;
			}
			
			sceIoClose(out);
			break;
		}

		else if (pad.Buttons & PSP_CTRL_CIRCLE)
		{
			fd = sceIoOpen("DOCUMENT.DAT", PSP_O_RDONLY, 0777);

			if (fd < 0)
			{
				ErrorExit(8000, "Cannot open DOCUMENT.DAT.\n");
			}

			sceIoRead(fd, &signature, 4);
			sceIoClose(fd);

			if (signature != 0x44475000) /* PGD */
			{
				ErrorExit(8000, "Not encrypted file.\n");
			}

			fd = sceIoOpen("DOCUMENT_DECRYPTED.DAT", PSP_O_WRONLY | PSP_O_CREAT | PSP_O_TRUNC, 0777);
			if (fd < 0)
			{
				ErrorExit(8000, "Cannot create DOCUMENT_DECRYPTED.DAT\n");
			}

			printf("Decrypting document...\n");

			offset = 0;
			while ((read = pspPopsDNASDecrypt("DOCUMENT.DAT", generic_keys, 0, buf, offset, sizeof(buf))) > 0)
			{
				sceIoWrite(fd, buf, read);
				offset += read;
			}

			sceIoClose(fd);
			break;
		}

		else if (pad.Buttons & PSP_CTRL_START)
		{
			sceKernelExitGame();
		}

		sceKernelDelayThread(10000);
	}

	printf("Done. Press X to exit\n");
	while (1)
	{
		sceCtrlReadBufferPositive(&pad, 1);
		if (pad.Buttons & PSP_CTRL_CROSS)
			break;

		sceKernelDelayThread(10000);
	}

	sceKernelExitGame();

	return 0;
	
}



