#include <pspsdk.h>
#include <pspkernel.h>
#include <systemctrl.h>
#include <string.h>

PSP_MODULE_INFO("pspPopsDNAS_Friend", 0x1007, 1, 0);
PSP_MAIN_THREAD_ATTR(0);

int pspPopsDNASDecrypt(char *file, u8 *keys, int encrypt_offset, void *out, int offset, int size)
{
	int k1 = pspSdkSetK1(0);
	int keyconfig = sctrlKernelSetInitKeyConfig(PSP_INIT_KEYCONFIG_POPS);
	int res;

	SceUID fd = sceIoOpen(file, 0x40000000 | PSP_O_RDONLY, 0);
	if (fd < 0)
	{
		Kprintf("Error 0x%08X in open dnas file.\n", fd);
		res = fd;
		goto RETURN;
	}

	res = sceIoIoctl(fd, 0x04100002, &encrypt_offset, 4, NULL, 0);
	if (res < 0)
	{
		Kprintf("Error 0x%08X setting encryption offset.\n", res);
		sceIoClose(fd);		
		goto RETURN;
	}

	res = sceIoIoctl(fd, 0x04100001, keys, 0x10, NULL, 0);
	if (res < 0)
	{
		Kprintf("Error 0x%08X setting decryption keys.\n", res);
		sceIoClose(fd);
		goto RETURN;
	}

	sceIoLseek(fd, offset, PSP_SEEK_SET);

	res = sceIoRead(fd, out, size);
	sceIoClose(fd);

RETURN:

	sctrlKernelSetInitKeyConfig(keyconfig);
	pspSdkSetK1(k1);
	return res;
}

int module_start(SceSize args, void *argp) 
{
	return 0;
}

int module_stop()
{
	return 0;
}
