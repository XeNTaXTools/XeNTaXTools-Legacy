PsxDecryption by Dark_AleX
--------------------------

This program decrypts/decompress psx games bought at the ps3store.
It can also decrypt the document.dat of those games.

Instructions:

- This program is only for 3.03 OE. It won't work on any other system
- Place the folder psxdecrypt at /PSP/GAME303 or if you have configured the GAME folder for 3.03 kernel, you
  can also place it in /PSP/GAME150.
- Place the game of the ps3store in the same directory than the application with the name "GAME.PBP".
- Place also the keys.bin and the document.dat in the same directory.
- Execute the program. Press X to decrypt iso header, game special data, and decompress the iso image.
  Press 0 to decrypt document.dat.

Note: For decompressing the iso, you need a LOT of free space in your memory stick, since the
decompressed iso will have more size than the pbp's.

If you have a fake/bad memory stick, better not to use this program.
If the dxar generation took you more than 10 minutes, better not to use this program.

In good memory sticks, the process may take between 10-20minutes to more than 1 hour, depending of the
size of the iso.

The program has only been tested with hot shots 2. Hopefull it will work with other games.