#define IDD_DIALOG                      100
#define IDC_LISTVIEW                    101
#define IDC_PICK                        102
#define IDC_RECURSIVE                   103
#define IDC_GRIPPER                     150
