# author: Volfin
# 1.00  - Initial Release
# 1.10  - Added initial support for rigged characters
#       - mapped shader type table, now detects 8/16 bit bone index values, 16/32 bit face index values, and 4/8 weight per vertex usage
#       - added skeleton building support. *.binskeleton file must be present (and if one exists it's always next to the model anyway)
#       - Fixed issue with models being flipped on X axis
#       - rewrote shader parameter parsing, should better handle unexpected parameters
#       - worked around issue where transparent/decal sections don't have a model entry, and weren't created. 
# 1.20  - Fixed an issue with missing transparent blocks (again)
#       - Fixed an issue causing empty objects to be left behind from the breakable model split operation.
# 1.30  - Added a workaround for model block count of zero. (carpets)
# 1.40  - Committed to new block parsing system.
#       - fixed flipped normals

bl_info = {
    "name": "Control Game Importer",
    "author": "Volfin",
    "version": (1, 4, 0),
    "blender": (2, 80, 0),
    "location": "File > Import > binFBX (Control Game Model)",
    "description": "Import binFBX, io: mesh",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
    "category": "Import-Export"}
    
if "bpy" in locals():
    import imp
    if "import_binFBX" in locals():
        imp.reload(import_binFBX)
    if "export_binFBX" in locals():
        imp.reload(export_binFBX)

import bpy

from bpy.props import (StringProperty,
                       BoolProperty,
                       FloatProperty,
                       EnumProperty,
                       )

from bpy_extras.io_utils import (ImportHelper,path_reference_mode)

  
class binFBXImportOperator(bpy.types.Operator, ImportHelper):
    bl_idname = "import_scene.binfbx"
    bl_label = "binFBX Importer(.binFBX)"
    
    filename_ext = ".binfbx"
    skip_blank=False;

    randomize_colors: BoolProperty(\
        name="Random Material Colors",\
        description="Assigns a random color to each material",\
        default=True,\
        )

    import_vertcolors: BoolProperty(\
        name="Import Vertex Colors",\
        description="Import Vertex Colors",\
        default=False,\
        )
    
    use_layers: BoolProperty(\
        name="Seperate Mesh Layers",\
        description="Place Meshes on seperate layers",\
        default=True,\
        )

    break_phys: BoolProperty(\
        name="Split Breakable Meshes",\
        description="Break apart 'breakable' meshes into their defined parts.",\
        default=True,\
        )
    
    mesh_scale: bpy.props.FloatProperty(
        name="Scale Factor",
        description="Mesh Import Scale Factor",
        default=1.0,
    )

    filter_glob: StringProperty(default="*.binFBX") # , options={'HIDDEN'}
    filepath: bpy.props.StringProperty(subtype="FILE_PATH")        
    path_mode: path_reference_mode

    def execute(self, context):
        import os, sys
        print("Import Execute called")
        cmd_folder = os.path.dirname(os.path.abspath(__file__))
        if cmd_folder not in sys.path:
            sys.path.insert(0, cmd_folder)

        import import_binFBX
        result=import_binFBX.import_binFBX(self.filepath, bpy.context,self.randomize_colors,self.import_vertcolors,self.skip_blank,self.use_layers,self.break_phys,self.mesh_scale)

        # force back off
        #self.skip_blank=False
        #self.use_layers=False
        
        if result is not None:
            self.report({'ERROR'},result)

        return {'FINISHED'}

    def invoke(self, context, event):

        print("Import Invoke called")
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        col.label(text='Mesh Scale Factor')
        col.prop(self, "mesh_scale")
        row = layout.row(align=True)
        row.prop(self, "randomize_colors")
        row = layout.row(align=True)
        row.prop(self, "import_vertcolors")
        row = layout.row(align=True)
        row.prop(self, "use_layers")
        row = layout.row(align=True)
        row.prop(self, "break_phys")

#
# Registration
#
def menu_func_import(self, context):
    self.layout.operator(binFBXImportOperator.bl_idname, text="binFBX(Control Game Model)(.binFBX)",icon='PLUGIN')

classes = (
binFBXImportOperator
)
   
def register():

    bpy.utils.register_class(classes)
    bpy.types.TOPBAR_MT_file_import.append(menu_func_import)
    
def unregister():

    bpy.utils.unregister_class(classes)
    bpy.types.TOPBAR_MT_file_import.remove(menu_func_import)
    
if __name__ == "__main__":
    register()