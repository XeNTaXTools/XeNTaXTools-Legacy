from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Little Big Planet [PSVita]", ".tex")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    if noeStrFromBytes(bs.readBytes(3)) != 'GTF': return 0
    return 1
    
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data, NOE_BIGENDIAN)
    bs.seek(0x03, NOESEEK_ABS)
    version = bs.readUByte()
    if version == 0x53:
        unkSize = bs.read("<I")
        bs.readBytes(unkSize[0])
    imgFmt = bs.readUByte()
    print(hex(imgFmt), ":imgFmt")
    unk = bs.readBytes(7)
    imgWidth = bs.readUShort()            
    imgHeight = bs.readUShort()
    print(imgWidth, "x", imgHeight)
    unk = bs.readBytes(14)
    numChunks = bs.readUShort()
    print(hex(numChunks), ":numChunks")
    dataStart =  bs.tell() + (numChunks * 4)
    datasize = 0
    data = bytearray()
    for i in range(numChunks):
        compSize = bs.readUShort() 
        print(hex(compSize), ":compsize")
        decompSize = bs.readUShort()
        print(hex(decompSize), ":decompsize")
        tmp = bs.tell()
        datasize += decompSize
        print(hex(datasize), ":datasize")
        if i == 0:
            bs.seek(dataStart, NOESEEK_ABS)
        if i > 0:
            bs.seek(tmp2, NOESEEK_ABS)
        imgData = bs.readBytes(compSize)
        tmp2 = bs.tell()
        print(hex(tmp2), ":tmp2")
        data += bytearray(rapi.decompInflate(imgData, decompSize))
        bs.seek(tmp, NOESEEK_ABS)
    
    if imgFmt == 0x86:
        imgFmt = b'\x85'
    elif imgFmt == 0x88:
        imgFmt = b'\x87'

    #build PSVita gxt header and append tex data
    gxtHeader = b'\x47\x58\x54\x00\x03\x00\x00\x10\x01\x00\x00\x00\x40\x00\x00\x00'
    gxtHeader += bytearray(noePack("I", datasize))     #4bytes
    gxtHeader += b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x40\x00\x00\x00'
    gxtHeader += bytearray(noePack("I", datasize))     #4bytes
    gxtHeader += b'\xFF\xFF\xFF\xFF\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    gxtHeader += imgFmt                                #1bytes
    gxtHeader += bytearray(noePack("H", imgWidth))     #2bytes
    gxtHeader += bytearray(noePack("H", imgHeight))    #2bytes
    gxtHeader += b'\x01\x00\x00\x00'              
    gxtHeader += data                                  #nbytes
       
    texList.append(rapi.loadTexByHandler(gxtHeader, ".gxt"))
    return 1