-= TF3 Tool Readme =-

This tool allows you compression and decompression of all graphics from the game, named Thunder Force III.
There are two types of graphic resources in the game:
 - LZH compressed;
 - RLE compressed.

You should to read the "TF3 Hacking Guide" by OO Styx: http://www.romhacking.net/documents/465/ to find offsets of graphics of the game.
One remark: in his guide he uses another names for LZH and RLE. Keep in mind that:
 - Iwanaga compression = LZH compression;
 - Ohtsuka compression = RLE compression;

Also this tool allows to view all planets maps, and title screen of the game. In the future, you will be able to edit it all!


-= LZH compression =-

 - Decompression
For decompression of this type of data, you must to know offset for the table with offsets for packed archives, and index of archive is needed.
For example, there are one table (LevelCprData) at offset 0x20000 (according TF3 Hacking Guide). There are 24 archives in this table (indexes from 0x0 to 0x17).

 - Compression
TF3 Tool compresses data and inserts packed archive at the same offset at the offsets table, with recalculation of compressed and decompressed size for current index.
So, you just have to select uncompressed data, ROM of the TF3, and type the same values for offset table and index, as you wrote it for decompression.


-= RLE compression =-

- Decompression
For this type of compressed data you have to input exact value for the offset. Even if there is a table with offsets.

 - Compression
TF3 Tool compresses data and inserts packed archive at the same offset as compressed data was.

-= Levels Viewer =-

How it works: TF3 Tool decompresses mappings, tiles for selected planet, assembles them into indexes, and shows a map of the level with its palettes.

-= Title screen Viewer =-

Mapping for this screen is compressed (you can use "MappingUnpacker" subroutine in "uCompression.pas" to decompress it).
This program decompresses and assembles it into indexes, and shows you a title screen.


-= OpenGL Viewer =-

TF3 Tool uses OpenGL for viewing of uncompressed data with the default palette and the default parameters.
So, if you will see some bad graphics in this window - don't worry. It's normal)

-= Bonus =-

There is an "uCompression.pas" unit in the archive with TF3 Tool. You can use it in your programs for this game.

-= P.S. =-

Maybe, in the near future, it will be TF3 Game Editor. But I don't know.

-= Authors =-
 - Coding: Dr. MefistO (meffi@lab313.ru);
 - Advices: AID_X (aid_x@lab313.ru);
 - The main TF3 analysis: OO Styx (oostyx@gmail.com).

-= [LAB 313] =-