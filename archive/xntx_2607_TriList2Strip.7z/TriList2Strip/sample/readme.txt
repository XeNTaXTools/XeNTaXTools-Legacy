"sample_trianglelist.bin" file contains the triangle list:
4 triangles (12 indices)
0 1 2
2 1 3
2 3 4
4 3 5

The output file will contain the triangle strip:
6 indicies
0 1 2 3 4 5
