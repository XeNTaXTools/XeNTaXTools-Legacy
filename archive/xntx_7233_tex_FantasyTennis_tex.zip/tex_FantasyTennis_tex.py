from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Fantasy Tennis", ".tex")
    noesis.setHandlerTypeCheck(handle, noeCheckGeneric)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1
    
def noepyCheckType(data):
    bs = NoeBitStream(data)
    if bs.readBytes(4) != b'\xbb\xbb\xac\xdf': return 0
    return 1

def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    xoredHeader = bs.readBytes(128)
    unxoredHeader = []
    for i in xoredHeader:
        unxoredHeader.append(i ^ 0xff)
    header = bytearray(unxoredHeader)
    data = bs.readBytes(bs.getSize() - bs.tell())
    DDStex = header
    DDStex += data
    tex = rapi.loadTexByHandler(DDStex, ".dds")
    tex.name = rapi.getInputName()
    texList.append(tex)
    return 1