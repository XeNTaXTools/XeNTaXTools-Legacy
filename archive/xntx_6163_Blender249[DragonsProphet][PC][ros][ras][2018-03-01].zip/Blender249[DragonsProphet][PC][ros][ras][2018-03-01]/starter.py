import newGameLib
from newGameLib import *
import Blender	

def rosParser(filename,g):

	while(True):
		if g.tell()+48>=g.fileSize():break
		g.f(12)
		A=g.i(2)
		g.word(A[1])
		g.i(2)
		g.i(4)
		g.f(3)
		g.f(4)
		g.f(3)
		B=g.i(4)
		if B[3]==0:
			flag=g.i(1)[0]
			if flag==1:
				#g.B(13)
				meshCount=g.i(1)[0]
				if meshCount!=1561189349:
					for i in safe(meshCount):
						g.f(8)
						g.B(17)
						g.f(8)
						g.B(17)
						B=g.i(2)	
						mesh=Mesh()
						for k in safe(B[1]):
							vT=[g.word(g.i(1)[0]),g.i(2)]
							#print k,vT
							if vT[1][1]==6:
								if vT[0]=="position":
									for n in safe(B[0]):						
										mesh.vertPosList.append(g.f(3))
								else:
									for n in safe(B[0]):						
										g.seek(12,1)
							if vT[1][1]==28:
								for n in safe(B[0]):
									g.seek(4,1)
							if vT[1][1]==16:
								if vT[0]=="uv":
									for n in safe(B[0]):						
										mesh.vertUVList.append(g.f(2))
								else:
									for n in safe(B[0]):						
										g.seek(8,1)
							if vT[1][1]==30:
								if vT[0]=="blend indices":
									for n in safe(B[0]):						
										mesh.skinIndiceList.append(g.B(4))
								else:
									for n in safe(B[0]):						
										g.seek(4,1)
							if vT[1][1]==2:
								if vT[0]=="blend weights":
									for n in safe(B[0]):						
										mesh.skinWeightList.append(g.f(4))
								else:
									for n in safe(B[0]):						
										g.seek(16,1)	
						g.f(8)
						g.B(17)
						B=g.i(3)
						mesh.TRIANGLE=True
						mesh.indiceList=g.H(B[2])
						g.i(2)
						g.find('\x00')
						g.i(2)
						g.i(B[1])
						
						g.f(19)
						g.i(1)
						g.f(8)
						g.B(17)
						g.f(8)
						g.B(17)
						g.f(6)
						A=g.i(2)
						for m in safe(A[0]):
							g.B(8)
						for m in safe(A[1]):
							g.f(6)
							g.i(g.i(1)[0])
						
						g.f(8)
						
						g.i(1)
						g.word(g.i(1)[0])
						count=g.i(1)[0]
						skin=Skin()
						mesh.skinList.append(skin)
						mat=Mat()
						mat.TRIANGLE=True
						mesh.matList.append(mat)
						for m in safe(count):
							type=g.word(g.i(1)[0])
							flag=g.i(1)[0]
							if flag==16:
								value=g.word(g.i(1)[0])
								if type=="tex: diffuse":
									mat.diffuse=sys.join(value+'.dds')
							if flag==2:
								g.i(1)	
							if flag==8:
								g.f(1)	
						g.i(1)				
						mesh.draw()	
						#break
					#print g.tell()	
					#break
				else:	
					g.f(7)
					g.i(1)
					g.word(g.i(1)[0])
					g.i(2)
					boneCount=g.i(1)[0]
					skeleton=Skeleton()
					#skeleton.BONESPACE=True
					skeleton.ARMATURESPACE=True
					for n in safe(boneCount):
						bone=Bone()
						skeleton.boneList.append(bone)
						bone.parentID=g.i(1)[0]
						t=g.tell()
						name=g.find('\x00')
						bone.name=str(n)
						g.seek(t+36)
						g.i(4)
						g.f(64-16)
						bone.matrix=Matrix4x4(g.f(16)).transpose().invert()
					skeleton.BINDMESH=True	
					skeleton.draw()	
					#break
		
	#g.debug=True
	#g.logWrite(g.tell())
	#g.tell()
	
def rasParser(filename,g):
	g.f(8)
	g.i(1)[0]
	g.word(g.i(1)[0])
	g.i(2)
	g.f(1)
	g.i(1)
	
	action=Action()
	action.BONESPACE=True
	action.BONESORT=True
	boneCount=g.i(1)[0]
	for m in safe(boneCount):
		bone=ActionBone()
		action.boneList.append(bone)
		#g.logWrite(m)
		g.f(8)
		g.i(1)[0]
		name=g.word(g.i(1)[0])
		bone.name=str(m)
		g.i(2)
		
		g.f(8)
		g.B(21)
		flags=g.B(32)
		g.B(17)
		B=g.i(2)
		g.f(B[1])
		if flags==(106, 109, 80, 216, 1, 74, 59, 193, 160, 88, 229, 141, 130, 185, 203, 176, 179, 130, 89, 144, 138, 73, 72, 255, 10, 77, 51, 147, 57, 74, 178, 60):
			g.f(g.i(1)[0])
		else:
			g.half(g.i(1)[0])
			
		
		g.f(8)
		g.B(21)
		flags=g.B(32)
		g.B(17)
		B=g.i(2)
		for n in range(B[1]):
			bone.rotFrameList.append(int(g.f(1)[0]*30))
		Count=g.i(1)[0]
		if flags==(106, 109, 80, 216, 1, 74, 59, 193, 160, 88, 229, 141, 130, 185, 203, 176, 179, 130, 89, 144, 138, 73, 72, 255, 10, 77, 51, 147, 57, 74, 178, 60):
			for n in range(0,Count,B[0]):
				bone.rotKeyList.append(QuatMatrix(g.f(B[0])).resize4x4().invert())
		else:
			for n in range(0,Count,B[0]):
				bone.rotKeyList.append(QuatMatrix(g.half(B[0])).resize4x4().invert())
		
		g.f(8)
		g.B(21)
		flags=g.B(32)
		g.B(17)
		B=g.i(2)
		for n in range(B[1]):
			bone.posFrameList.append(int(g.f(1)[0]*30))
		Count=g.i(1)[0]
		if flags==(106, 109, 80, 216, 1, 74, 59, 193, 160, 88, 229, 141, 130, 185, 203, 176, 179, 130, 89, 144, 138, 73, 72, 255, 10, 77, 51, 147, 57, 74, 178, 60):
			for n in range(0,Count,B[0]):
				bone.posKeyList.append(VectorMatrix(g.f(B[0])))
		else:
			for n in range(0,Count,B[0]):
				bone.posKeyList.append(VectorMatrix(g.half(B[0])))
	action.draw()
	action.setContext()	

		
		
	
	#g.debug=True
	#g.tell()	
	
def Parser(filename):
	global sys
	os.system('cls')
	sys=Sys(filename)
	if sys.ext=='ros':sys.parseFile(rosParser,'rb',log=0)
	if sys.ext=='ras':sys.parseFile(rasParser,'rb',log=0)
 
 
	
Blender.Window.FileSelector(Parser,'import','Dragons Prophet files: *.ros - model, *.ras - animation') 
	