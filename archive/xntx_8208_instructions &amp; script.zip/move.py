# Disney Move
# Noesis script by Dave, 2022


from inc_noesis import *


def registerNoesisTypes():
	handle = noesis.register("Disney Move",".move")							# made up extension
	noesis.setHandlerTypeCheck(handle, bcCheckType)
	noesis.setHandlerLoadModel(handle, bcLoadModel)
	return 1


# Check file type

def bcCheckType(data):
	return 1


# Read the model data

def bcLoadModel(data, mdlList):
	bs = NoeBitStream(data)
	ctx = rapi.rpgCreateContext()

	vert_count = 3843
	vert_start = 0x1a95

	bs.seek(vert_start)										# start of vertex data
	vertices = bs.readBytes(vert_count * 0x40)							# vertex count * stride

	rapi.rpgBindPositionBuffer(vertices, noesis.RPGEODATA_FLOAT, 0x40)
	rapi.rpgCommitTriangles(None, noesis.RPGEODATA_USHORT, vert_count, noesis.RPGEO_TRIANGLE_STRIP)	# auto-generate faces

	mdl = rapi.rpgConstructModel()
	mdlList.append(mdl)

	return 1


