valid_axes = (
    'xyz',
    'xyx',
    'xzx',
    'xzy',
    'yxy',
    'yxz',
    'yzx',
    'yzy',
    'zxy',
    'zxz',
    'zyx',
    'zyz',
)

valid_matrix_composition_modes = (
    'intrinsic',
    'extrinsic'
)

