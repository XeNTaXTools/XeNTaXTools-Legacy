import bpy
from io_scene_mdl2022.mdl_utils_2022 import main_export
from io_scene_mdl2022.mdl_utils_2022 import main_import
from io_scene_mdl2022.mdl_utils_2022 import main_import_20
from bpy_extras.io_utils import ExportHelper
from bpy.props import StringProperty, BoolProperty, EnumProperty
from bpy_extras.io_utils import ImportHelper
from bpy.types import Operator


def read_some_data_20(context, filepath):
    print( filepath )
    try:
        bpy.ops.object.mode_set(mode='OBJECT')
    except:
        pass
    main_import_20.importMDL( filepath )
    try:
        bpy.ops.object.mode_set(mode='OBJECT')
    except:
        pass
    return {'FINISHED'}

def write_some_data(context, filepath):
    print( filepath )
    bpy.ops.object.mode_set(mode='OBJECT')
    main_export.mainExportMDL( filepath )
    bpy.ops.object.mode_set(mode='OBJECT')
    return {'FINISHED'}

def read_some_data(context, filepath ):
    print( filepath )
    try:
        bpy.ops.object.mode_set(mode='OBJECT')
    except:
        pass
    main_import.importMDL( filepath )
    try:
        bpy.ops.object.mode_set(mode='OBJECT')
    except:
        pass
    return {'FINISHED'}

class ImportSomeData20(Operator, ImportHelper):
    """Import WWE 2k20 MDL object"""
    bl_idname = "import_test20.some_data"  # important since its how bpy.ops.import_test.some_data is constructed
    bl_label = "Import MDL!"

    # ImportHelper mixin class uses this
    filename_ext = ".mdl"

    filter_glob: StringProperty(
        default="*.mdl",
        options={'HIDDEN'},
        maxlen=255,  # Max internal buffer length, longer would be clamped.
    )

    def execute(self, context):
        return read_some_data_20( context, self.filepath )

class ImportSomeData(Operator, ImportHelper):
    """Import WWE 2k22 MDL object"""
    bl_idname = "import_test.some_data"  # important since its how bpy.ops.import_test.some_data is constructed
    bl_label = "Import MDL!"

    # ImportHelper mixin class uses this
    filename_ext = ".mdl"

    filter_glob: StringProperty(
        default="*.mdl",
        options={'HIDDEN'},
        maxlen=255,  # Max internal buffer length, longer would be clamped.
    )

    def execute(self, context):
        return read_some_data( context, self.filepath )
        
bl_info = {
    "name": "WWE 2K22 (.MDL) Import/Export Add-On v1.04",
    "author": "Hanleys",
    "version": (1, 0 , 4),
    "blender": (2, 93, 4),
    "description": "IO addon for importing/exporting WWE 2k22 .MDL models.",
    "category": "Object",
}

class ExportSomeData(Operator, ExportHelper):
    """Export selection as WWE 2k22 MDL object"""
    bl_idname = "export_test.some_data"  # important since its how bpy.ops.import_test.some_data is constructed
    bl_label = "Export MDL!"

    # ExportHelper mixin class uses this
    filename_ext = ".mdl"

    filter_glob: StringProperty(
        default="*.mdl",
        options={'HIDDEN'},
        maxlen=255,  # Max internal buffer length, longer would be clamped.
    )

    def execute(self, context):
        return write_some_data(context, self.filepath)


# Only needed if you want to add into a dynamic menu
def menu_func_export(self, context):
    self.layout.operator(ExportSomeData.bl_idname, text="WWE2K22 MDL (.mdl)")
    
def menu_func_import(self, context):
    self.layout.operator(ImportSomeData.bl_idname, text="WWE2K22 MDL (.mdl)")

def menu_func_import_20(self, context):
    self.layout.operator(ImportSomeData20.bl_idname, text="WWE2K20 *Legacy MDL (.mdl)")


def register():
    bpy.utils.register_class(ExportSomeData)
    bpy.types.TOPBAR_MT_file_export.append(menu_func_export)
    bpy.utils.register_class(ImportSomeData)
    bpy.types.TOPBAR_MT_file_import.append(menu_func_import)
    bpy.utils.register_class(ImportSomeData20)
    bpy.types.TOPBAR_MT_file_import.append(menu_func_import_20)

def unregister():
    bpy.utils.unregister_class(ExportSomeData)
    bpy.types.TOPBAR_MT_file_export.remove(menu_func_export)
    bpy.utils.unregister_class(ImportSomeData)
    bpy.types.TOPBAR_MT_file_import.remove(menu_func_import)
    bpy.utils.unregister_class(ImportSomeData20)
    bpy.types.TOPBAR_MT_file_import.remove(menu_func_import_20)


if __name__ == "__main__":
    register()

    # test call
    bpy.ops.export_test.some_data('INVOKE_DEFAULT')
    bpy.ops.import_test.some_data('INVOKE_DEFAULT')
    bpy.ops.import_test20.some_data('INVOKE_DEFAULT')