
from bpy import context
import bpy, bmesh
import configparser, os
import sys
from math import degrees
from math import radians
import mathutils
import math

global config
global config_path
global user_path
global conf_path
global hasConfig

config = configparser.ConfigParser()

user_path = bpy.utils.resource_path('USER')
conf_path = os.path.join(user_path, "config")
config_path = conf_path + "\mdl_skel.cache.ini" 

hasConfig = 'false'

def check_seams( model ):

    bpy.context.scene.tool_settings.use_uv_select_sync = True
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_mode(type="VERT")
    bpy.ops.mesh.select_all(action = 'SELECT')

    obj = model
    me = obj.data
    bm = bmesh.from_edit_mesh(me)

    # old seams
    old_seams = [e for e in bm.edges if e.seam]
    # unmark
    for e in old_seams:
        e.seam = False
    # mark seams from uv islands
    bpy.ops.uv.seams_from_islands()
    seams = [e for e in bm.edges if e.seam]
    # split on seams
    bmesh.ops.split_edges(bm, edges=seams)
    # re instate old seams.. could clear new seams.
    for e in old_seams:
        e.seam = True
    bmesh.update_edit_mesh(me)

    print("seams checked.")

    bpy.ops.object.mode_set(mode='OBJECT')

def init_config():
    global config
    global config_path
    global user_path
    global conf_path
    global hasConfig

    user_path = bpy.utils.resource_path('USER')
    conf_path = os.path.join(user_path, "config")
    config_path = conf_path + "\mdl_skel.cache.ini" 

    hasConfig = 'false'

    #clear old-cache
    if not os.path.exists(config_path):
        print("Config not found. Creating new...")
        write_file()
    else:
        # Read File
        hasConfig = 'true'
        config.read(config_path)
    
    print( "Config read" ) 

def write_file():
    config.write( open( config_path, 'w') )

def triangulate_object(obj):
    me = obj.data
    # Get a BMesh representation
    bm = bmesh.new()
    bm.from_mesh(me)

    bmesh.ops.triangulate(bm, faces=bm.faces[:])
    # V2.79 : bmesh.ops.triangulate(bm, faces=bm.faces[:], quad_method=0, ngon_method=0)

    # Finish up, write the bmesh back to the mesh
    bm.to_mesh(me)
    bm.free()
    
def triangulate_edit_object(obj):
    me = obj.data
    # Get a BMesh representation
    bm = bmesh.from_edit_mesh(me)

    bmesh.ops.triangulate(bm, faces=bm.faces[:])
    # V2.79 : bmesh.ops.triangulate(bm, faces=bm.faces[:], quad_method=0, ngon_method=0)

    # Show the updates in the viewport
    # and recalculate n-gon tessellation.
    bmesh.update_edit_mesh(me, True)


def getActiveModels():

    selection_names = bpy.context.selected_objects
    selection_ = []
    
    for sel in selection_names:
        if sel.type == 'MESH':
            selection_.append( sel )
            
    return selection_

def getFaceList( model ):
    isQuad = 'false'
    
    faceList = []
    
    for f in model.data.polygons:
        faceTuple = []
        for idx in f.vertices:
            faceTuple.append( model.data.vertices[idx].index + 1)
                
        if ( len( faceTuple ) != 3 ):
            isQuad = 'true'
        
        faceList.append(  faceTuple )
        
    return isQuad , faceList

##  VColor Conversion -- Code by Grix    
def to_lin(s):
    if s <= 0.0404482362771082:
        lin = s / 12.92
    else:
        lin = pow(((s + 0.055) / 1.055), 2.4)
    return lin

def parseModels( sceneModels ):
    
    meshArr = []
    vertArr = []
    faceArr = []
    normArr = []
    uvArr = []
    skin = []
    skelBones = []
    skelBones_translate = []
    skelBones_rotate = []
    skelBones_parent = []
    meshNames = []
    specialFlags = []
    vColor_sets = []
    
    for model in sceneModels:

        check_seams( model )

        print( "\nModel " + model.name )
        bpy.ops.object.mode_set(mode='OBJECT')

        modelname = model.name

        if ( "!" in  modelname ):
            specialFlags.append( "true" )
            modelname = modelname.replace("!","")
        else:
            specialFlags.append( "false" )

        if ( "." in  modelname ):
            mdlstr = modelname.split(".")
            meshArr.append( mdlstr[0] )
        else:
            meshArr.append( modelname )

        model_meshID = model.data.name
        
        if ( "." in model_meshID ):
            mdlstr = model_meshID.split(".")
            meshNames.append( mdlstr[0] )
        else:
            meshNames.append( model_meshID )
            
        ##get faces
        isQuad = 'false'
        faceInds = getFaceList( model )
        
        if ( faceInds[0] == 'true' ):
            print ("is Quad")
            triangulate_object( model )
            faceInds = getFaceList( model )
              
        faceArr.append( faceInds )
        

        ##get verts
        verts = [model.matrix_world @ vert.co for vert in model.data.vertices]
        plain_verts = [vert.to_tuple() for vert in verts]
        
        ##get norms
        nrms = []
        for vIdx in range( len( plain_verts ) ):
            normal_local = model.data.vertices[vIdx].normal.to_4d()
            normal_local.w = 0
            normal_local = (model.matrix_world @ normal_local).to_3d()
            nrms.append( normal_local.to_tuple() )
            
        vertArr.append( plain_verts )
        normArr.append( nrms )

        ##getUVs
        uv_sets = model.data.uv_layers
        uv_layers = list( range( len( uv_sets) ) )
        print( "Model has UV Layers: " , len( uv_sets ) )

        # Loops per UV Layer
        uv_layer_idx = 0
        for uv_layer in uv_sets:
            model_uvs = list( range( len( plain_verts ) ) )

            # Loops per face
            for face in model.data.polygons:
                for vert_idx, loop_idx in zip(face.vertices, face.loop_indices):
                    uv_coords = uv_layer.data[loop_idx].uv
                    model_uvs[vert_idx] = ( uv_coords.x , uv_coords.y )

            uv_layers[ uv_layer_idx ] = model_uvs
            uv_layer_idx += 1

        uvArr.append( uv_layers )

        ##getVColors
        hasColor = 'true'
        model_vcolors = []
        try:
            color_layer = model.data.vertex_colors["Col"]
            model_vcolors = list(range( len(plain_verts) ))
            i = 0
            for poly in model.data.polygons:
                for v_ix, l_ix in zip(poly.vertices, poly.loop_indices):
                    vcolors = color_layer.data[i].color
                    model_vcolors[v_ix] = ( to_lin(vcolors[0]), to_lin(vcolors[1]) , to_lin(vcolors[2]) , vcolors[3] )
                    i += 1
            print( "hasColor" )
        except:
            hasColor = 'false'
            pass
        
        vColor_sets.append( model_vcolors )

        ##skin??
        model_skin_set = []
        print( model.parent )
        
        
        if type(model.parent) != type(None):
            
            # limitBoneWeights to 4
            bpy.context.view_layer.objects.active  = model
            bpy.ops.object.vertex_group_limit_total(group_select_mode='ALL', limit=4)
           
            ##getBnes
            if ( len(skelBones) == 0 ):
                if ( model.parent ).type == 'ARMATURE':
                    skel = ( model.parent )
                    armature = skel.data
     
                    for bone in armature.bones:
                        skelBones.append( bone.name )
                        if not ( config.has_option( "general" , (bone.name+"_rotation") ) ):
                            bone_rot_ini = 0
                            bone_trn_ini = 0
                            skelBones_translate.append( bone_trn_ini )
                            skelBones_rotate.append( bone_rot_ini )
                            if not bone.parent is None:
                                skelBones_parent.append( bone.parent.name )
                            else:
                                skelBones_parent.append( 'NULL' )
                        else:   
                            bone_rot_ini = config["general"][ bone.name+"_rotation"]
                            bone_trn_ini = config["general"][ bone.name+"_translate"]
                            skelBones_translate.append( bone_trn_ini )
                            skelBones_rotate.append( bone_rot_ini )
                            if not bone.parent is None:
                                skelBones_parent.append( bone.parent.name )
                            else:
                                skelBones_parent.append( 'NULL' )
            else:
                print("bone is already cached.")
                        
                         
            ##accessVGroups
            objGroups = []
            for group in model.vertex_groups:
                objGroups.append( group.name )
            
            mesh = model.data
            skinInd = []
            skinWeights = []
             
            #collectSkinInfo
            for v in mesh.vertices:
                groupTuple = []
                indTuple = []
                
                #collectBones
                for elem in v.groups:
                    indTuple.append( objGroups[ elem.group ] )
                
                #collectWeights
                for elem in v.groups:
                    groupTuple.append( elem.weight )
                    
                skinInd.append( indTuple )
                skinWeights.append( groupTuple )
            
            model_skin_set.append( skinInd )
            model_skin_set.append( skinWeights )
            
            skin.append( model_skin_set )
                    
        else:
            print( "model has no armature" )
    
    return meshArr , vertArr , faceArr , normArr , uvArr , skelBones , skelBones_translate , skelBones_rotate , skin , skelBones_parent , meshNames, specialFlags , vColor_sets
##           0         1        2         3         4         5         6                      7                8          9               10           11             12




def formatTEXT( sceneData ): 
    
    mainText = []
    
    #addBoneNames
    for item in sceneData[5]:
        mainText.append( item )
        
    #addMeshIDs
    for item in sceneData[0]:
        mainText.append( item )
    
    #addDataTypes
    mainText.append( 'POSITION' )
    mainText.append( 'R32_G32_B32' )
    mainText.append( 'float' )
    mainText.append( 'NORMAL' )
    mainText.append( 'R8_G8_B8_A8' )
    mainText.append( 'snorm' )
    mainText.append( 'TANGENT' )
    mainText.append( 'BINORMAL' )
    mainText.append( 'R8' )
    mainText.append( 'COLOR' )
    mainText.append( 'unorm' )
    mainText.append( 'TEXCOORD' )
    mainText.append( 'R32_G32' )
    mainText.append( 'R16_G16_B16_A16' )
    mainText.append( 'BLENDINDICES' )
    mainText.append( 'uint' )
    mainText.append( 'BLENDWEIGHTS' )
    mainText.append( 'R32_G32_B32_A32' )
    mainText.append( '' )
    
    #addMeshNames
    for i in range( len( sceneData[0] ) ):
        mainText.append( sceneData[10][i] )
    
    return mainText


import io

def get_binaryTEXT( mainTEXT ):
    
    textCount = len( mainTEXT )
    in_memory_sub = io.BytesIO(b'')

    in_memory_sub.seek( 0 , 2 );in_memory_sub.write( textCount.to_bytes(4, 'little') )
    
    strOffset = 0
    for a in range( len(mainTEXT) ):
        itemString = mainTEXT[a]
        in_memory_sub.seek( 0 , 2 )
        in_memory_sub.write( strOffset.to_bytes(4, 'little') )
        strOffset += len(itemString)+1
    
    for a in range( len(mainTEXT) ):
        itemString = mainTEXT[a]
        in_memory_sub.seek( 0 , 2 );in_memory_sub.write( itemString.encode('utf-8') )
        in_memory_sub.seek( 0 , 2 );in_memory_sub.write( b'\x00' )
    
    totalSize = 8 + len( in_memory_sub.getvalue() )
    print( totalSize )
    
    while ( totalSize % 8 ):
        in_memory_sub.seek( 0 , 2 );in_memory_sub.write( b'\x00' )
        totalSize += 1
    
    in_memory = io.BytesIO(b'TEXT')
    in_memory.seek( 0 , 2 );in_memory.write( (totalSize-8).to_bytes(4, 'little') )
 
    
    return in_memory.getvalue() , in_memory_sub.getvalue()
    
def get_binaryMDLStart( ):
    
    in_memory = io.BytesIO(b'MDL!')
    in_memory.seek( 0 , 2 );in_memory.write(  int(32).to_bytes(4, 'little')  )
    in_memory.seek( 0 , 2 );in_memory.write(  b'\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF'  )
    in_memory.seek( 0 , 2 );in_memory.write(  b'\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF'  )
    in_memory.seek( 0 , 2 );in_memory.write(  b'\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF'  )


    return in_memory.getvalue()

import ast
import struct
import binascii

def float_to_hex(f):
    return struct.pack('<f', f)

def get_binaryBONE( mainText , skelBones , skelTrans , skelRot , skelPar ):
    
    in_memory = io.BytesIO(b'BONE')
    
    boneCount = len( skelBones )
    in_memory_sub = io.BytesIO(b'')
    in_memory_sub.seek( 0 , 2 );in_memory_sub.write( boneCount.to_bytes(4, 'little') )
    
    for a in range( len(skelBones) ):
        bone_name = skelBones[a]
        bone_index = mainText.index( bone_name )
        in_memory_sub.seek( 0 , 2 );in_memory_sub.write( bone_index.to_bytes(2, 'little') )
        
        bone_parent = skelPar[a]
        if ( bone_parent != 'NULL' ):
            bone_parent_index = mainText.index( bone_parent )
            in_memory_sub.seek( 0 , 2 );in_memory_sub.write( bone_parent_index.to_bytes(2, 'little') )
        else:
            bone_parent_index = 65535
            in_memory_sub.seek( 0 , 2 );in_memory_sub.write( bone_parent_index.to_bytes(2, 'little') )

        if ( skelTrans[a] == 0 ):
            print( "bone cache not found")
        if ( skelRot[a] == 0 ):
            print( "bone cache not found")

        try:
            bone_translate = ast.literal_eval( skelTrans[a] )
        except:
            print( "error: " + bone_name )
        try:    
            bone_rot = ast.literal_eval( skelRot[a] )
        except:
            print( "error: " + bone_name )
        bone_rot = [ ((i*math.pi)/180) for i in bone_rot]
        
        bone_tr_hex = [float_to_hex(i) for i in bone_translate]
        bone_ro_hex = [ float_to_hex(i) for i in bone_rot]
        
        for c in range(len(bone_tr_hex)):
            in_memory_sub.seek( 0 , 2 )
            in_memory_sub.write( bone_tr_hex[c])
        for c in range(len(bone_ro_hex)):
            in_memory_sub.seek( 0 , 2 )
            in_memory_sub.write( bone_ro_hex[c])
    
    in_memory = io.BytesIO(b'BONE')
    in_memory.seek( 0 , 2 );in_memory.write( (len(in_memory_sub.getvalue())).to_bytes(4, 'little') )       
    return in_memory.getvalue() , in_memory_sub.getvalue()
    
def get_binaryMTL( sceneData , mainText ):
    
    in_memory = io.BytesIO(b'MTL!')
    in_memory_sub = io.BytesIO(b'')
    in_memory_sub.seek( 0 , 2 );in_memory_sub.write( (len(sceneData[0])).to_bytes(4, 'little') )
    
    for i in range( len(sceneData[0]) ):
        meshId = sceneData[0][i]
        meshIndex = mainText.index( meshId )
        in_memory_sub.seek( 0 , 2 );in_memory_sub.write( meshIndex.to_bytes(4, 'little') )
    
    in_memory = io.BytesIO(b'MTL!')
    in_memory.seek( 0 , 2 );in_memory.write( (len(in_memory_sub.getvalue())).to_bytes(4, 'little') )    
    
    return in_memory.getvalue() , in_memory_sub.getvalue()


def get_binaryMBFD( sceneData , mainText , hasRig ):
    in_memory_sub = io.BytesIO(b'')
    in_memory_sub.seek( 0 , 2 );in_memory_sub.write( (len(sceneData[0])).to_bytes(4, 'little') )
    skinSetIndex = 0
    
    for i in range( len(sceneData[0]) ):
        meshString = sceneData[10][i]
        meshIndex = mainText.index( meshString )
        blockCount = 0

        if ( hasRig == 'true'):
            blockCount = 7
        else:
            blockCount = 5

        if len( sceneData[12][i] ) != 0:
            blockCount += 1

        model_uv_layers = len( sceneData[4][i] )
        blockCount += ( model_uv_layers - 1 )

        meshVerts = sceneData[ 1 ][i]
        specialFlag = sceneData[11][i]

        in_memory_sub.seek( 0 , 2 );in_memory_sub.write( meshIndex.to_bytes(4, 'little') )
        if ( specialFlag == 'true' ):
            in_memory_sub.seek( 0 , 2 );in_memory_sub.write( int(129).to_bytes(4, 'little') ) #flag 1
            in_memory_sub.seek( 0 , 2 );in_memory_sub.write( int(1).to_bytes(2, 'little') ) #flag 2
        else:
            in_memory_sub.seek( 0 , 2 );in_memory_sub.write( int(128).to_bytes(4, 'little') ) #flag 1
            in_memory_sub.seek( 0 , 2 );in_memory_sub.write( int(0).to_bytes(2, 'little') ) #flag 2
        in_memory_sub.seek( 0 , 2 );in_memory_sub.write( b'\xFF\xFF\xFF\xFF' ) #mshhash
        in_memory_sub.seek( 0 , 2 );in_memory_sub.write( b'\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF' ) #mshhash
        in_memory_sub.seek( 0 , 2 );in_memory_sub.write( b'\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF' ) #mshhash
        in_memory_sub.seek( 0 , 2 );in_memory_sub.write( b'\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF' ) #mshhash
        ####VERTICES
        
        posIndex = mainText.index( 'POSITION' )
        dxgbIndex = mainText.index( 'R32_G32_B32' )
        floatIndex = mainText.index( 'float' )
        
        in_memory_sub.seek( 0 , 2 );in_memory_sub.write( len(meshVerts).to_bytes(4, 'little') ) #meshVerts
        in_memory_sub.seek( 0 , 2 );in_memory_sub.write( int(blockCount).to_bytes(4, 'little') ) #meshBlocks --
        in_memory_sub.seek( 0 , 2 );in_memory_sub.write( b'\xA4\xCE\x1A\x5A\x67\x7D\x20\x25\x5F\x8E\xB5\x47' ) #vertHash
        in_memory_sub.seek( 0 , 2 );in_memory_sub.write( posIndex.to_bytes(2, 'little') ) #vertHash
        in_memory_sub.seek( 0 , 2 );in_memory_sub.write( dxgbIndex.to_bytes(2, 'little') ) #vertHash
        in_memory_sub.seek( 0 , 2 );in_memory_sub.write( floatIndex.to_bytes(4, 'little') ) #vertHash
        in_memory_sub.seek( 0 , 2 );in_memory_sub.write( int(0).to_bytes(2, 'little') ) #align
        
        for a in range( len(meshVerts) ):
            binFloat_x = 1.0 * meshVerts[a][0]
            binFloat_y = -1.0 * meshVerts[a][2]
            binFloat_z = 1.0 * meshVerts[a][1]
            binFloat_x = float_to_hex( binFloat_x )
            binFloat_y = float_to_hex( binFloat_y )
            binFloat_z = float_to_hex( binFloat_z )
            
            in_memory_sub.seek( 0 , 2 );in_memory_sub.write( binFloat_x ) #meshVertsx
            in_memory_sub.seek( 0 , 2 );in_memory_sub.write( binFloat_y ) #meshVertsy
            in_memory_sub.seek( 0 , 2 );in_memory_sub.write( binFloat_z ) #meshVertsz
        
        
        ####NORMALS
        
        meshNorms = sceneData[ 3 ][i]
        
        nrmIndex = mainText.index( 'NORMAL' )
        dxgbIndex = mainText.index( 'R32_G32_B32' )
        floatIndex = mainText.index( 'float' )
        
        in_memory_sub.seek( 0 , 2 );in_memory_sub.write( b'\x14\x2F\x99\x24\x67\x7D\x20\x25\x5F\x8E\xB5\x47' ) #nrmlHash
        in_memory_sub.seek( 0 , 2 );in_memory_sub.write( nrmIndex.to_bytes(2, 'little') ) 
        in_memory_sub.seek( 0 , 2 );in_memory_sub.write( dxgbIndex.to_bytes(2, 'little') ) 
        in_memory_sub.seek( 0 , 2 );in_memory_sub.write( floatIndex.to_bytes(4, 'little') ) 
        
        for a in range( len(meshNorms) ):
            binFloat_x = 1.0 * meshNorms[a][0]
            binFloat_y = 1.0 * meshNorms[a][1]
            binFloat_z = -1.0 * meshNorms[a][2] ##checkths
            binFloat_x = float_to_hex( binFloat_x )
            binFloat_y = float_to_hex( binFloat_y )
            binFloat_z = float_to_hex( binFloat_z )
                
            in_memory_sub.seek( 0 , 2 );in_memory_sub.write( binFloat_x ) #meshVertsx
            in_memory_sub.seek( 0 , 2 );in_memory_sub.write( binFloat_z ) #meshVertsy
            in_memory_sub.seek( 0 , 2 );in_memory_sub.write( binFloat_y ) #meshVertsz
            
        ####TANGENT
        
        nrmIndex = mainText.index( 'TANGENT' )
        dxgbIndex = mainText.index( 'R8_G8_B8_A8' )
        floatIndex = mainText.index( 'snorm' )
        
        in_memory_sub.seek( 0 , 2 );in_memory_sub.write( b'\xB3\x88\x28\x62\xE0\x77\x7C\x76\xAA\x58\x6A\xCC' ) #nrmlHash
        in_memory_sub.seek( 0 , 2 );in_memory_sub.write( nrmIndex.to_bytes(2, 'little') )
        in_memory_sub.seek( 0 , 2 );in_memory_sub.write( dxgbIndex.to_bytes(2, 'little') )
        in_memory_sub.seek( 0 , 2 );in_memory_sub.write( floatIndex.to_bytes(4, 'little') )
        
        for a in range( len(meshVerts) ):
            in_memory_sub.seek( 0 , 2 );in_memory_sub.write( int(255).to_bytes(4, 'little') )
        
        ####BINORMALS
        
        nrmIndex = mainText.index( 'BINORMAL' )
        dxgbIndex = mainText.index( 'R8' )
        floatIndex = mainText.index( 'snorm' )
        
        in_memory_sub.seek( 0 , 2 );in_memory_sub.write( b'\xAD\xE0\x21\x1B\xC5\x82\x47\xD3\xAA\x58\x6A\xCC' ) #nrmlHash
        in_memory_sub.seek( 0 , 2 );in_memory_sub.write( nrmIndex.to_bytes(2, 'little') )
        in_memory_sub.seek( 0 , 2 );in_memory_sub.write( dxgbIndex.to_bytes(2, 'little') )
        in_memory_sub.seek( 0 , 2 );in_memory_sub.write( floatIndex.to_bytes(4, 'little') )
        
        for a in range( len(meshVerts) ):
            in_memory_sub.seek( 0 , 2 );in_memory_sub.write( int(255).to_bytes(1, 'little') )    
        
        ##align    
        while ( len(in_memory_sub.getvalue() ) % 4 ):
            in_memory_sub.seek( 0 , 2 );in_memory_sub.write( int(0).to_bytes(1, 'little') )    
        
        ####VCOLORS
        mdl_colors = sceneData[12][i]

        if ( len (mdl_colors) ) != 0:
            nrmIndex = mainText.index( 'COLOR' )
            dxgbIndex = mainText.index( 'R8_G8_B8_A8' )
            floatIndex = mainText.index( 'unorm' )

            in_memory_sub.seek( 0 , 2 );in_memory_sub.write( b'\x6B\x63\x97\xC5\xE0\x77\x7C\x76\x42\x39\x0D\x5C' ) #nrmlHash
            in_memory_sub.seek( 0 , 2 );in_memory_sub.write( nrmIndex.to_bytes(2, 'little') )
            in_memory_sub.seek( 0 , 2 );in_memory_sub.write( dxgbIndex.to_bytes(2, 'little') )
            in_memory_sub.seek( 0 , 2 );in_memory_sub.write( floatIndex.to_bytes(4, 'little') )

            for a in range( len(meshVerts) ):
                mesh_vcol = mdl_colors[a]

                in_memory_sub.seek( 0 , 2 );in_memory_sub.write( int(mesh_vcol[0] * 255.0 ).to_bytes(1, 'little') )  
                in_memory_sub.seek( 0 , 2 );in_memory_sub.write( int(mesh_vcol[1] * 255.0 ).to_bytes(1, 'little') )  
                in_memory_sub.seek( 0 , 2 );in_memory_sub.write( int(mesh_vcol[2] * 255.0 ).to_bytes(1, 'little') ) 
                in_memory_sub.seek( 0 , 2 );in_memory_sub.write( int(mesh_vcol[3] * 255.0 ).to_bytes(1, 'little') )  

        ####TEXCOORDS
        
        for uv_layer_idx in range( model_uv_layers ):

            meshUVs = sceneData[4][i][uv_layer_idx]
            nrmIndex = mainText.index( 'TEXCOORD' )
            dxgbIndex = mainText.index( 'R32_G32' )
            floatIndex = mainText.index( 'float' )
            
            in_memory_sub.seek( 0 , 2 );in_memory_sub.write( b'\x59\xA1\x7B\x3C\x27\x02\x45\x7F\x5F\x8E\xB5\x47' ) #nrmlHash
            in_memory_sub.seek( 0 , 2 );in_memory_sub.write( nrmIndex.to_bytes(2, 'little') )
            in_memory_sub.seek( 0 , 2 );in_memory_sub.write( dxgbIndex.to_bytes(2, 'little') )
            in_memory_sub.seek( 0 , 2 );in_memory_sub.write( floatIndex.to_bytes(4, 'little') )
            
            for a in range( len(meshUVs) ):
                try:
                    binFloat_uvx = 1.0 * meshUVs[a][0]
                except:
                    pass
                    binFloat_uvx = 1.0
                try:
                    binFloat_uvy = -1.0 * (-1.0 + meshUVs[a][1])
                except:
                    pass
                    binFloat_uvy = 1.0
                binFloat_uvx = float_to_hex( binFloat_uvx )
                binFloat_uvy = float_to_hex( binFloat_uvy )
                
                in_memory_sub.seek( 0 , 2 );in_memory_sub.write( binFloat_uvx ) #meshVertsx
                in_memory_sub.seek( 0 , 2 );in_memory_sub.write( binFloat_uvy ) #meshVertsx


        ####Skin
        mdl_skin = sceneData[8]
        
        if ( len (mdl_skin) ) != 0:
            
            if not i > ( len (mdl_skin)  - 1 ):
                model_skin_set = mdl_skin[i]
                
                ####BLENDINDICES
                nrmIndex = mainText.index( 'BLENDINDICES' )
                dxgbIndex = mainText.index( 'R16_G16_B16_A16' )
                floatIndex = mainText.index( 'uint' )
                
                in_memory_sub.seek( 0 , 2 );in_memory_sub.write( b'\xB3\x6E\x8F\x6B\x4C\x21\x26\x64\x35\x89\x93\x02' ) #bonehash
                in_memory_sub.seek( 0 , 2 );in_memory_sub.write( nrmIndex.to_bytes(2, 'little') )
                in_memory_sub.seek( 0 , 2 );in_memory_sub.write( dxgbIndex.to_bytes(2, 'little') )
                in_memory_sub.seek( 0 , 2 );in_memory_sub.write( floatIndex.to_bytes(4, 'little') )
                
                for a in range( len(model_skin_set[0]) ):
               
                    for b in range( 4 ):

                        if ( b > len( model_skin_set[0][a] ) - 1 ):
                            in_memory_sub.seek( 0 , 2 );in_memory_sub.write( int(0).to_bytes(2, 'little') )
                        else:
                            boneName = model_skin_set[0][a][b]
                            boneIndex = mainText.index( boneName )
                        
                            in_memory_sub.seek( 0 , 2 );in_memory_sub.write( boneIndex.to_bytes(2, 'little') )
                        
                ###BLENDWEIGHTS
                nrmIndex = mainText.index( 'BLENDWEIGHTS' )
                dxgbIndex = mainText.index( 'R8_G8_B8_A8' )
                floatIndex = mainText.index( 'unorm' )
                
                in_memory_sub.seek( 0 , 2 );in_memory_sub.write( b'\x9B\x1A\x8F\x49\xE0\x77\x7C\x76\x42\x39\x0D\x5C' ) #bonehash
                in_memory_sub.seek( 0 , 2 );in_memory_sub.write( nrmIndex.to_bytes(2, 'little') )
                in_memory_sub.seek( 0 , 2 );in_memory_sub.write( dxgbIndex.to_bytes(2, 'little') )
                in_memory_sub.seek( 0 , 2 );in_memory_sub.write( floatIndex.to_bytes(4, 'little') )   
                
                for a in range( len(model_skin_set[1]) ):
                    for b in range( 4 ):
                        if ( b > len( model_skin_set[1][a] ) - 1 ):
                            in_memory_sub.seek( 0 , 2 );in_memory_sub.write( int(0).to_bytes(1, 'little') )
                        else:
                            boneWeight = model_skin_set[1][a][b]
                            boneWeight = boneWeight * 255
                            
                            in_memory_sub.seek( 0 , 2 );in_memory_sub.write( int(boneWeight).to_bytes(1, 'little') )
        else:
            print( "model is not skinned")              
        
        ##EmptyArr
        for a in range( len(meshVerts) ):
            in_memory_sub.seek( 0 , 2 );in_memory_sub.write( b'\x00\x00\x00\x00' ) #meshVertsx


        blankEntry = mainText.index( '' )

        in_memory_sub.seek( 0 , 2 );in_memory_sub.write( int(0).to_bytes(4, 'little') ) #AtPt data sets
        in_memory_sub.seek( 0 , 2 );in_memory_sub.write( int(blankEntry).to_bytes(4, 'little') ) #Item Dict

        if ( len (mdl_colors) ) != 0:                                                   #VColor ID
            in_memory_sub.seek( 0 , 2 );in_memory_sub.write( int(0).to_bytes(4, 'little') )

        in_memory_sub.seek( 0 , 2 );in_memory_sub.write(b'ENDM\x00\x00\x00\x00')
        
        
    in_memory = io.BytesIO(b'MBfD')
    in_memory.seek( 0 , 2 );in_memory.write( (len(in_memory_sub.getvalue())).to_bytes(4, 'little') )    
    
    return in_memory.getvalue() , in_memory_sub.getvalue()

def get_binaryLODs( sceneData , mainText , hasRig ):
    subLods = 2
    if ( hasRig == 'false'):
        subLods = 2

    in_memory_sub = io.BytesIO(b'')
    in_memory_sub.seek( 0 , 2 );in_memory_sub.write( int(subLods).to_bytes(4, 'little') )
    modelFaces = sceneData[2]
    
    for z in range( subLods ):
        for a in range( len(sceneData[0]) ):

            meshVerts = len( sceneData[ 1 ][a] )
            faceCount = len( modelFaces[a][1] )
            
            if ( a == 0 ):
                in_memory_sub.seek( 0 , 2 );in_memory_sub.write( len(sceneData[0]).to_bytes(4, 'little') )
     
            in_memory_sub.seek( 0 , 2 );in_memory_sub.write( int(a).to_bytes(2, 'little') )
            in_memory_sub.seek( 0 , 2 );in_memory_sub.write( int(faceCount*3).to_bytes(4, 'little') )

            if ( meshVerts > 65535 ):
                for b in range( len( modelFaces[a][1] ) ):
                    in_memory_sub.seek( 0 , 2 );in_memory_sub.write( (modelFaces[a][1][b][1]-1).to_bytes(4, 'little') )
                    in_memory_sub.seek( 0 , 2 );in_memory_sub.write( (modelFaces[a][1][b][0]-1). to_bytes(4, 'little') )
                    in_memory_sub.seek( 0 , 2 );in_memory_sub.write( (modelFaces[a][1][b][2]-1).to_bytes(4, 'little') )
            else:
                for b in range( len( modelFaces[a][1] ) ):
                    in_memory_sub.seek( 0 , 2 );in_memory_sub.write( (modelFaces[a][1][b][1]-1).to_bytes(2, 'little') )
                    in_memory_sub.seek( 0 , 2 );in_memory_sub.write( (modelFaces[a][1][b][0]-1). to_bytes(2, 'little') )
                    in_memory_sub.seek( 0 , 2 );in_memory_sub.write( (modelFaces[a][1][b][2]-1).to_bytes(2, 'little') )   

            ##align    
            while ( len(in_memory_sub.getvalue() ) % 4 ):
                in_memory_sub.seek( 0 , 2 );in_memory_sub.write( int(0).to_bytes(1, 'little') )    
            
            #foot
            in_memory_sub.seek( 0 , 2 );in_memory_sub.write( int(1).to_bytes(4, 'little') )
            in_memory_sub.seek( 0 , 2 );in_memory_sub.write( int(a).to_bytes(4, 'little') ) 
            in_memory_sub.seek( 0 , 2 );in_memory_sub.write( int(0).to_bytes(4, 'little') ) 
            in_memory_sub.seek( 0 , 2 );in_memory_sub.write( int(faceCount*3).to_bytes(4, 'little') )
            in_memory_sub.seek( 0 , 2 );in_memory_sub.write(b'ENDM\x00\x00\x00\x00')
        
    in_memory = io.BytesIO(b'LODs')
    in_memory.seek( 0 , 2 );in_memory.write( (len(in_memory_sub.getvalue())).to_bytes(4, 'little') )    
    
    return in_memory.getvalue() , in_memory_sub.getvalue()



def formatMDL( sceneData , outputFile ):
    
    mainText = formatTEXT( sceneData )
    
    #check if has rig
    hasRig = 'false'
    if ( len( sceneData[5] ) == 0 ):
        hasRig = 'false'
    else:
        hasRig = 'true'
    
    mdlHead = get_binaryMDLStart()
    textHead , textSub = get_binaryTEXT( mainText )
    mtlHead , mtlSub = get_binaryMTL( sceneData , mainText )
    mbfdHead , mbfdSub = get_binaryMBFD( sceneData , mainText , hasRig )
    LODsHead , LODsSub = get_binaryLODs( sceneData , mainText , hasRig )
    
    if ( hasRig == 'true' ):
        boneHead , boneSub = get_binaryBONE( mainText , sceneData[5] , sceneData[6] , sceneData[7] , sceneData[9] )
    
    with open( outputFile , 'wb' ) as f:    
        f.write( mdlHead )
        f.write( textHead )
        f.write( textSub )
        if ( hasRig == 'true' ):
            f.write( boneHead )
            f.write( boneSub )
        f.write( mtlHead )
        f.write( mtlSub )
        f.write( mbfdHead )
        f.write( mbfdSub )
        f.write( LODsHead )
        f.write( LODsSub )
        f.write( b'END!\x00\x00\x00\x00' )
        
def mainExportMDL( filepath ):

    init_config()

    sceneModels = getActiveModels()
    sceneData = []

    if ( len( sceneModels ) == 0 ):
        print( "No Objs sel" )
    else:
        sceneData = parseModels( sceneModels )
        print( "out" )

    for mesh in sceneData[0]:
        print( mesh )
    
    outFile = filepath

    print( "hello module")
     
    formatMDL( sceneData , outFile )

    return
    
    
 