from cmath import pi
import io
from pkgutil import get_loader
from io_scene_mdl2022.mdl_utils_2022 import mbfd_dxgi_bin
import math
import numpy as np
from io_scene_mdl2022.eulerangles import euler2matrix


class MBfD_model(object):
    def __init__(self, property, format, type):
        self.property = type
        self.format = format
        self.type = type

global modelCount
global MTLsList
global MBfDList
global LODsList
global modelVerts
global BONE    

modelCount = 0
MTLsList = []
MBfDList = []
LODsList = []
modelVerts = []
BONE = []

def readMain( mainMDL ):
    
    global modelCount
    global MTLsList
    global MBfDList
    global LODsList
    global modelVerts
    global BONE   

    modelCount = 0
    MTLsList = []
    MBfDList = []
    LODsList = []
    modelVerts = []
    BONE = []

    file = open( mainMDL ,"rb")
    mdlMagic = file.read(4)

    #verify file integrity
    if ( mdlMagic != b'MDL!' ):
        print( "File is not MDL.")
        file.close(); return
    else:
        print( "File is valid MDL\n\n")

    #skip internal hash
    file.seek( 32 )

    #get TEXT data
    textMagic = file.read(4)
    textSize = int.from_bytes( ( file.read(4) ) , "little" )
    textArr = io.BytesIO( file.read( textSize ) )
    mainTEXT = get_TEXT( textArr , textSize )

    # interpret data blocks
    parseModelBlocks( file , mainTEXT )
    parseModelBlocks( file , mainTEXT )
    parseModelBlocks( file , mainTEXT )
    parseModelBlocks( file , mainTEXT )
    parseModelBlocks( file , mainTEXT )

    ## MBFD at 0 is data Types
    ## MBFD at 1 is data Sets
    ## LODs at 0 is face Sets
    ## LODs at 1 is mesh IDs

    file.close()

    return MTLsList , MBfDList , LODsList , BONE , mainTEXT

def parseModelBlocks( file , textStrings ):
    global modelCount
    global BONE
    global MTLsList
    global MBfDList
    global LODsList


    #get general data
    blockMagic = file.read(4)
    blockSize = int.from_bytes( ( file.read(4) ) , "little" )
    blockArr = io.BytesIO( file.read( blockSize ) )

    if (blockMagic == b'BONE'):
        print("BONE")
        BONE = get_BONE( blockArr , blockSize , textStrings )
    if (blockMagic == b'AtPt'):
        print("AtPt")
    if (blockMagic == b'MTL!'):
        print("MTL!")
        MTLsList = get_MTL( blockArr , blockSize )
    if (blockMagic == b'MBfD'):
        print("MBfD")
        MBfDList = get_MBfD( blockArr , blockSize , textStrings )
    if (blockMagic == b'LODs'):
        print("LODs")
        LODsList = get_LODs( blockArr , blockSize , textStrings )   
    

   

def get_TEXT( textBuffer , textSize ):
    stringCount = int.from_bytes( (textBuffer.read(4) ) , "little" )
    stringOffList = []
    textStrings = []

    # collect char offset for all strings
    for x in range(stringCount):
        stringOffset = int.from_bytes( (textBuffer.read(4) ) , "little" )
        stringOffList.append( stringOffset )

    # collect actual strings
    for x in range(stringCount):
        textBuffer.seek( 4 + (4*stringCount) + stringOffList[x] , 0 )
        stringArray = b''; bitValue = b'\xFF'

        while ( bitValue != b'\x00' ):
            bitValue = textBuffer.read(1)
            stringArray += bitValue

        textStrings.append( stringArray[:-1].decode( 'utf-8' ) )

    ## ---print( textStrings )--
    print("TEXT Count is:" , str( stringCount ) )

    # return TEXTlist
    return textStrings

def get_BONE(   boneBuffer , boneSize , textStrings ):
    boneCount = int.from_bytes( (boneBuffer.read(4) ) , "little" )

    tarr = []
    rarr = []
    Barr = []
    Parr = []

    for i in range(boneCount):
        boneInd = int.from_bytes( (boneBuffer.read(2) ) , "little" )
        bonePar = int.from_bytes( (boneBuffer.read(2) ) , "little" )
        boneName= textStrings[boneInd]
        parent = bonePar

        #get point3 values
        tx = int.from_bytes( (boneBuffer.read(4) ) , "little" )
        tx = mbfd_dxgi_bin.DWORDFloat( tx )
        ty = int.from_bytes( (boneBuffer.read(4) ) , "little" )
        ty = mbfd_dxgi_bin.DWORDFloat( ty )
        tz = int.from_bytes( (boneBuffer.read(4) ) , "little" )
        tz = mbfd_dxgi_bin.DWORDFloat( tz )

        rx = int.from_bytes( (boneBuffer.read(4) ) , "little" )
        rx = (mbfd_dxgi_bin.DWORDFloat( rx ) * 180.0 ) / math.pi
        ry = int.from_bytes( (boneBuffer.read(4) ) , "little" )
        ry = (mbfd_dxgi_bin.DWORDFloat( ry ) * 180.0 ) / math.pi
        rz = int.from_bytes( (boneBuffer.read(4) ) , "little" )
        rz = (mbfd_dxgi_bin.DWORDFloat( rz ) * 180.0 ) / math.pi

        tarr.append( [tx,ty,tz] )
        rarr.append( [rx , ry , rz ] )
        Barr.append( boneName )
        Parr.append( parent )
    
    return tarr , rarr , Barr , Parr


def get_MTL(  mtlBuffer , mtlSize ):

    mtlCount = int.from_bytes( (mtlBuffer.read(4) ) , "little" )
    mtlIndices = []

    for x in range(mtlCount):
        mtlIndex = int.from_bytes( (mtlBuffer.read(4) ) , "little" )
        mtlIndices.append( mtlIndex )

    return mtlIndices
    

def get_MBfD( modelBuffer , MBfDSize , mainTEXT ):
    global modelCount
    modelCount = int.from_bytes( (modelBuffer.read(4) ) , "little" )
    modelDataSets = []
    modelDataTypes = []
    modelNames = []

    print ( "Model Count is: " + str(modelCount) )

    # iterate over every sub model
    for x in range( modelCount ):
        submodelDataSets = []
        submodelDataTypes = []

        if (x > 0):
            tempBuf = b''
            while (tempBuf != b'ENDM'):
                tempBuf = (modelBuffer.read(4))
            modelBuffer.seek( modelBuffer.tell() + 4 )
                   
        # read basic mbfd data
        modelName = mainTEXT[ int.from_bytes( (modelBuffer.read(4) ) , "little" ) ]
        modelAppearanceFlag00 =  int.from_bytes( (modelBuffer.read(4) ) , "little" )

        # skip model hash
        modelBuffer.seek( modelBuffer.tell() + 28  )

        # read general model data
        modelVertCount = int.from_bytes( (modelBuffer.read(4) ) , "little" )
        modelDataBlocks = int.from_bytes( (modelBuffer.read(4) ) , "little" )
        modelVerts.append( modelVertCount )

        ## collect subData blocks
        for i in range( modelDataBlocks ):

            subBlockData = []

            # skip block hash --these are always const
            modelBuffer.seek( modelBuffer.tell() + 12 )
            blockProperty = mainTEXT[ int.from_bytes( (modelBuffer.read(2) ) , "little" ) ]
            blockFormat = mainTEXT[ int.from_bytes( (modelBuffer.read(2) ) , "little" ) ]
            blockType = mainTEXT[ int.from_bytes( (modelBuffer.read(4) ) , "little" ) ]

            # conditionals for data types
            if ( blockFormat == "R32_G32_B32" ):
                outBuffer = io.BytesIO( modelBuffer.read( 12 * modelVertCount ) )
                subBlockData = mbfd_dxgi_bin.getData_R32_G32_B32( outBuffer , modelVertCount , blockType )

            if ( blockFormat == "R8_G8_B8_A8" ):
                outBuffer = io.BytesIO( modelBuffer.read( 4 * modelVertCount ) )
                subBlockData = mbfd_dxgi_bin.getData_R8_G8_B8_A8( outBuffer , modelVertCount , blockType )

            if ( blockFormat == "R16_G16_B16_A16" ):
                outBuffer = io.BytesIO( modelBuffer.read( 8 * modelVertCount ) )
                subBlockData = mbfd_dxgi_bin.getData_R16_G16_B16_A16( outBuffer , modelVertCount , blockType )
                
            if ( blockFormat == "R32_G32" ):
                outBuffer = io.BytesIO( modelBuffer.read( 8 * modelVertCount ) )
                subBlockData = mbfd_dxgi_bin.getData_R32_G32( outBuffer , modelVertCount , blockType )

            if ( blockFormat == "R8" ):
                outBuffer = io.BytesIO( modelBuffer.read( modelVertCount ) )
                subBlockData = mbfd_dxgi_bin.getData_R8( outBuffer , modelVertCount , blockType )
                alignPos = mbfd_dxgi_bin.checkAlignment( modelBuffer.tell() )
                modelBuffer.seek( alignPos )

            submodelDataTypes.append( blockProperty )
            submodelDataSets.append( subBlockData )
            
            # print( blockProperty + blockFormat + blockType )


        modelDataTypes.append( submodelDataTypes )
        modelDataSets.append( submodelDataSets )
        modelNames.append( modelName )

        print ( "\nSubModel: " + str(modelName) + "\n Vert Count: " + str(modelVertCount) )

    return modelDataTypes , modelDataSets , modelNames

    
def get_LODs( modelBuffer , MBfDSize , mainTEXT ):
    global modelCount
    mainLOD = []
    mainMeshID = []

    for i in range( modelCount ):
        subLODarr = []
        outOff = modelBuffer.tell()
        model_vertices = modelVerts[i]

        if (i == 0):
            subLODs = int.from_bytes( (modelBuffer.read(4) ) , "little" )
        LODCount = int.from_bytes( (modelBuffer.read(4) ) , "little" )
        LODindex = int.from_bytes( (modelBuffer.read(2) ) , "little" )
        faceCount = int.from_bytes( (modelBuffer.read(4) ) , "little" )

        if model_vertices > 65535:
            for x in range( int(faceCount/3) ):
                fx = int.from_bytes( (modelBuffer.read(4) ) , "little" )
                fy = int.from_bytes( (modelBuffer.read(4) ) , "little" )
                fz = int.from_bytes( (modelBuffer.read(4) ) , "little" )

                subLODarr.append( [fy , fx , fz] )
        else:
            for x in range( int(faceCount/3) ):
                fx = int.from_bytes( (modelBuffer.read(2) ) , "little" )
                fy = int.from_bytes( (modelBuffer.read(2) ) , "little" )
                fz = int.from_bytes( (modelBuffer.read(2) ) , "little" )

                subLODarr.append( [fy , fx , fz] )

        mainLOD.append( subLODarr )

        outOff = modelBuffer.tell()
        print( "here : " + str(outOff) +  ' ' + str(model_vertices) )
        modelBuffer.seek( outOff + 6 )
        modelIndex = int.from_bytes( (modelBuffer.read(4) ) , "little" )
        meshID = mainTEXT[ MTLsList[ modelIndex ] ]
        modelBuffer.seek( outOff + 10 )

        alignedOff = mbfd_dxgi_bin.checkAlignment( modelBuffer.tell() )
        modelBuffer.seek( alignedOff )

        tempBuf = b''
        while (tempBuf != b'ENDM'):
            tempBuf = (modelBuffer.read(4))
        
        mainMeshID.append( meshID )

    return mainLOD , mainMeshID
