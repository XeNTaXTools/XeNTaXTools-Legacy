import io
import bpy
from pkgutil import get_loader


def sceneImportMDL( sceneData ):

    ## MBFD at 0 == data Types
    ## MBFD at 1 == data Sets
    ## LODs at 0 == face Sets
    ## LODs at 1 == mesh IDs

    for x in range( len(sceneData[2][1]) ):
        LODs = sceneData[2][0][x]
        meshID = sceneData[2][1][x]
        print ("MESH ID: " + meshID)

        verts = sceneData[1][0][x].index('POSITION')
        verts = sceneData[1][1][x][verts]
        
        print("test")

        new_mesh = bpy.data.meshes.new( meshID )
        new_mesh.from_pydata(verts, [], LODs)
        new_mesh.update()
        
        new_object = bpy.data.objects.new( meshID , new_mesh )
        
        # add object to scene collection
        bpy.context.collection.objects.link(new_object)


    return 0