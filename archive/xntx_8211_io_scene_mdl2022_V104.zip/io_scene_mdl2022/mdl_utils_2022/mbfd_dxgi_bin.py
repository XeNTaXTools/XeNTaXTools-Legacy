import io
import struct


def bitFloat( value , signValue ):
    if (signValue == "snorm"):
        value = float(value / 127.0)
    elif (signValue == "unorm"):
        value = float(value / 255.0)
    return value

def shortFloat( value , signValue ):
    if (signValue == "snorm"):
        value = float(value / 32767.0)
    elif (signValue == "unorm"):
        value = float(value / 65535.0)
    return value

def DWORDFloat( value ):
    value = struct.unpack('f', struct.pack('I', value))[0]
    return value

def getData_R32_G32_B32( dataBuffer , subCount , blockType ):
    dataValues = []

    for x in range(subCount):
        RGB_Block = []

        for h in range(3):
            var_0 = int.from_bytes( (dataBuffer.read(4) ) , "little" )
            var_0 = DWORDFloat( var_0 )
            RGB_Block.append( var_0 )

        dataValues.append( RGB_Block )

    return dataValues

def getData_R32_G32( dataBuffer , subCount , blockType ):
    dataValues = []

    for x in range(subCount):
        RG_Block = []

        for h in range(2):
            var_0 = int.from_bytes( (dataBuffer.read(4) ) , "little" )
            var_0 = DWORDFloat( var_0 )
            RG_Block.append( var_0 )

        dataValues.append( RG_Block )

    return dataValues

def getData_R8_G8_B8_A8( dataBuffer , subCount , blockType ):
    dataValues = []

    for x in range(subCount):
        RGBA_Block = []

        for h in range(4):
            if blockType == "snorm":
                var_0 = int.from_bytes( ( dataBuffer.read(1) ) , "little" , signed=True )
                var_0 = float( bitFloat( var_0 , blockType ) )
            elif blockType == "unorm":
                var_0 = int.from_bytes( ( dataBuffer.read(1) ) , "little" , signed=False )
                var_0 = float( bitFloat( var_0 , blockType ) )
            elif blockType == "sint":
                var_0 = int.from_bytes( ( dataBuffer.read(1) ) , "little" , signed=True )
            elif blockType == "uint":
                var_0 = int.from_bytes( ( dataBuffer.read(1) ) , "little" , signed=False )

            RGBA_Block.append( var_0 )

        dataValues.append( RGBA_Block )

    return dataValues

def getData_R16_G16_B16_A16( dataBuffer , subCount , blockType ):
    dataValues = []

    for x in range(subCount):
        RGBA_Block = []

        for h in range(4):
            if blockType == "snorm":
                var_0 = int.from_bytes( ( dataBuffer.read(2) ) , "little" , signed=True )
                var_0 = float( shortFloat( var_0 , blockType ) )
            elif blockType == "unorm":
                var_0 = int.from_bytes( ( dataBuffer.read(2) ) , "little" , signed=False )
                var_0 = float( shortFloat( var_0 , blockType ) )
            elif blockType == "sint":
                var_0 = int.from_bytes( ( dataBuffer.read(2) ) , "little" , signed=True )
            elif blockType == "uint":
                var_0 = int.from_bytes( ( dataBuffer.read(2) ) , "little" , signed=False )

            RGBA_Block.append( var_0 )

        dataValues.append( RGBA_Block )

    return dataValues

    
def getData_R8( dataBuffer , subCount , blockType ):
    dataValues = []

    for x in range(subCount):

        if blockType == "snorm":
            var_0 = int.from_bytes( ( dataBuffer.read(1) ) , "little" , signed=True )
            var_0 = float( bitFloat( var_0 , blockType ) )
        elif blockType == "unorm":
            var_0 = int.from_bytes( ( dataBuffer.read(1) ) , "little" , signed=False )
            var_0 = float( bitFloat( var_0 , blockType ) )
        elif blockType == "sint":
            var_0 = int.from_bytes( ( dataBuffer.read(1) ) , "little" , signed=True )
        elif blockType == "uint":
            var_0 = int.from_bytes( ( dataBuffer.read(1) ) , "little" , signed=False )

        dataValues.append( var_0 )

    return dataValues

def roundUp( numToRound , multiple ):
    if (multiple == 0): return numToRound
    remainder = numToRound % multiple
    if (remainder == 0): return numToRound

    return (numToRound + multiple - remainder)


def checkAlignment(  value ):
    
    return roundUp( value , 4 )