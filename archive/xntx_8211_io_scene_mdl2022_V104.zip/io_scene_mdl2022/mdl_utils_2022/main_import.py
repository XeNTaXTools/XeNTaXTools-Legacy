# vsCode module
from io_scene_mdl2022.mdl_utils_2022 import mdl_utils , scene_mdl_blender
#blenderModule
# from io_scene_mdl2022.mdl_utils_2022 import mdl_utils , scene_mdl_blender
import bpy
import configparser, os
import sys
from math import radians
import mathutils
import bpy , bmesh
from mathutils import Vector, Quaternion
from mathutils import Euler, Matrix
import numpy as np

global config
global config_path
global user_path
global conf_path
global hasConfig

config = configparser.ConfigParser()

user_path = bpy.utils.resource_path('USER')
conf_path = os.path.join(user_path, "config")
config_path = conf_path + "\mdl_skel.cache.ini" 
hasConfig = 'false'

def write_file():
    config.write( open( config_path, 'w') )

def init_config_new():
    global config
    global config_path
    global user_path
    global conf_path
    global hasConfig
        
    config = configparser.ConfigParser()

    user_path = bpy.utils.resource_path('USER')
    conf_path = os.path.join(user_path, "config")
    config_path = conf_path + "\mdl_skel.cache.ini" 

    #clear old-cache
    if not os.path.exists(config_path):
        write_file()
        
    else:
        # Read File
        config['general'] = {}

        # remove temp files
        with open(config_path, "w") as f:
            config.write(f)

#debug-notused
def getMDLFile():
    inputMDL = ""

    return inputMDL
    

def getVertexGroups( blInds , blWeights , textStrings ):
    
    bnArrs = []
    vertArrs = []
    wtArrs = []
    
    for x in range( len( blInds ) ):
        
        for i in range( 4 ):
            boneIndexID = blInds[x][i]
            boneIndexID = textStrings[ boneIndexID ]
            vertWeight = blWeights[x][i]
            
            #add bone if not in list
            if ( boneIndexID not in bnArrs ):
                bnArrs.append( boneIndexID )
                vertArrs.append( [] )
                wtArrs.append( [] )
            
            #find index of bne
            listIndex = bnArrs.index( boneIndexID )
            
            #append vertex to list
            if ( x not in vertArrs[ listIndex ] ):
                vertArrs[ listIndex ].append( x )
                wtArrs[ listIndex ].append( vertWeight )
            
#    print ( bnArrs )
#    print ( vertArrs )
#    print ( wtArrs )
    return bnArrs , vertArrs , wtArrs

def formatMatrixArray( inputMatrix , posArr ):
    inputMatrix.invert()
    test = inputMatrix.to_4x4()
    test[3][0] = posArr[0]
    test[3][1] = posArr[1]
    test[3][2] = posArr[2]
    
    return test

def numpyToMatrix( array ):
    
    euler = Euler( ( 0 , 0 , 0 ), 'XYZ' )
    newMatrix = euler.to_matrix()
    newMatrix = newMatrix.to_4x4()
    
    newMatrix[0][0] = array[0][0]
    newMatrix[0][1] = array[0][1]
    newMatrix[0][2] = array[0][2]
    newMatrix[0][3] = array[0][3]
    
    newMatrix[1][0] = array[1][0]
    newMatrix[1][1] = array[1][1]
    newMatrix[1][2] = array[1][2]
    newMatrix[1][3] = array[1][3]
    
    newMatrix[2][0] = array[2][0]
    newMatrix[2][1] = array[2][1]
    newMatrix[2][2] = array[2][2]
    newMatrix[2][3] = array[2][3]
    
    newMatrix[3][0] = array[3][0]
    newMatrix[3][1] = array[3][1]
    newMatrix[3][2] = array[3][2]
    newMatrix[3][3] = array[3][3]

    return newMatrix

def dotMatrixArrays( inputMatrix , secMatrix ):
    a1 = [ inputMatrix[0][0] , inputMatrix[0][1] , inputMatrix[0][2] , inputMatrix[0][3] ]
    a2 = [ inputMatrix[1][0] , inputMatrix[1][1] , inputMatrix[1][2] , inputMatrix[1][3] ]
    a3 = [ inputMatrix[2][0] , inputMatrix[2][1] , inputMatrix[2][2] , inputMatrix[2][3] ]
    a4 = [ inputMatrix[3][0] , inputMatrix[3][1] , inputMatrix[3][2] , inputMatrix[3][3] ]
    
    b1 = [ secMatrix[0][0] , secMatrix[0][1] , secMatrix[0][2] , secMatrix[0][3] ]
    b2 = [ secMatrix[1][0] , secMatrix[1][1] , secMatrix[1][2] , secMatrix[1][3] ]
    b3 = [ secMatrix[2][0] , secMatrix[2][1] , secMatrix[2][2] , secMatrix[2][3] ]
    b4 = [ secMatrix[3][0] , secMatrix[3][1] , secMatrix[3][2] , secMatrix[3][3] ]
    
    a = np.array([ a1, a2, a3, a4 ])
    b = np.array([ b1, b2, b3, b4 ])
    out = a.dot(b)
    
    out = numpyToMatrix( out )
    
    return out

##  VColor Conversion -- Code by Grix    
def to_srgb(c):
    if c < 0.0031308:
        srgb = 0.0 if c < 0.0 else c * 12.92
    else:
        srgb = 1.055 * pow(c, 1.0 / 2.4) - 0.055

    return srgb;

def importMDL( filepath ):
    
    # get new config
    init_config_new()

    # get file input
    mainMDL = filepath
    print( "\nMain MDL File is: " + mainMDL )
    
    # read MDL file
    sceneData = mdl_utils.readMain( mainMDL )
    modelCount = len( sceneData[2] )

    ## check error; do something
    if ( modelCount == 0 ):
        print( "No Models Loaded" )
    else:
        print( "\n" )


    # make collection
        collName = os.path.basename(mainMDL).split(".")[0]
        mdlCollection = bpy.data.collections.new( collName )
        bpy.context.scene.collection.children.link(mdlCollection)
    
        isSkinned = 'true'
        if ( len (sceneData[3]) == 0 ):
            isSkinned = False
        else:   
            # append bone structure
            tarr = sceneData[3][0]
            rarr = sceneData[3][1]
            Barr = sceneData[3][2]
            Parr = sceneData[3][3]

            item = mdlCollection
            edBones = []
            edTransforms = []
            edItem = []
            
            armature = bpy.data.armatures.new("Skeleton")
            rig = bpy.data.objects.new("Skeleton", armature)
            mdlCollection.objects.link(rig)
            armature.display_type = "WIRE"
            
            bpy.context.view_layer.objects.active = rig
            bpy.ops.object.editmode_toggle()
            
            for a in range( len( Barr ) ):
                name = Barr[a]
                rA = rarr[a]
                tA = tarr[a]
                
                current_bone = armature.edit_bones.new( name )
                parent = Parr[a]
                
                #pos
                positionObj = tA

                #rotation
                rotationObj = Euler( ( radians(rA[0]) , radians(rA[1]) , radians(rA[2]) ), 'XYZ' )
                rotationObj = rotationObj.to_matrix()
                rotationObj = formatMatrixArray( rotationObj , positionObj )

                config["general"][name+"_translate"] = str(tA)
                config["general"][name+"_rotation"] = str(rA)
                
                if ( parent != 65535 ):
                    current_bone.parent = edBones[ parent ]
                    parentTransform = edTransforms[ parent ]
                    newTransform = dotMatrixArrays( rotationObj , parentTransform )
                    parent_tail = edItem[ parent ]
                    
                    rotationObj = newTransform
                    current_bone.tail = parent_tail

                    if ( name == 'J_Hair'):
                        print( name )
                        print ( current_bone.parent )
                        print( current_bone.tail )
                        print( current_bone.head )
                
                edTransforms.append( rotationObj )    
                edBones.append( current_bone )   
                
                ## do bones
                current_bone.head = ( rotationObj[3][0]  , rotationObj[3][1]  ,
                                    rotationObj[3][2]  ) 

                ##  add small tfm to keep zero length bones POST
                if ( current_bone.head == current_bone.tail ):
                    current_bone.tail = ( current_bone.tail[0] + .000001 ,
                    current_bone.tail[1] + .000001 , current_bone.tail[2] + .000001 )                    
                        
                edItem.append( current_bone.head )    

            
                # remove temp files
            with open(config_path, "w") as f:
                config.write(f)
                
    #        ##rotate back
            rig.rotation_euler = (radians(-90), 0, 0 )
                  

    # append indiv data to scene
    for x in range( len(sceneData[2][1]) ):
        LODs = sceneData[2][0][x]
        meshID = sceneData[2][1][x]
        mesh_name = sceneData[1][2][x]
        hasColor = 'false'

        mainText = sceneData[4]
        print ("MESH ID: " + meshID)
        modelIndex = x
        subSkinned = 'true'

        try:
            blInds = sceneData[1][0][x].index('BLENDINDICES')
        except:
            subSkinned = 'false'
            isSkinned = 'false'
            pass

        verts = sceneData[1][0][x].index('POSITION')
        verts = sceneData[1][1][x][verts]
        
        norms = sceneData[1][0][x].index('NORMAL')
        norms = sceneData[1][1][x][norms]

        if 'COLOR' in sceneData[1][0][x]:
            hasColor = 'true'
            vcolors = sceneData[1][0][x].index('COLOR')
            vcolors = sceneData[1][1][x][vcolors]
            print("mesh has color")
        
        if isSkinned == 'true':
            if ( subSkinned != 'false'):
                blInds = sceneData[1][0][x].index('BLENDINDICES')
                blInds = sceneData[1][1][x][blInds]
                
                blWeights = sceneData[1][0][x].index('BLENDWEIGHTS')
                blWeights = sceneData[1][1][x][blWeights]
            
        meshUVCount = sceneData[1][0][x].count('TEXCOORD')
        UVindices = [i for i, j in enumerate(sceneData[1][0][x]) if j == "TEXCOORD"]
        
#        bn vt wt
        if isSkinned == 'true':
            if ( subSkinned != 'false'):
                rigData = getVertexGroups( blInds , blWeights , mainText )

        for x in range( len(norms) ):
            if ( len(norms[x]) > 3 ):
                norms[x].pop()
                

        new_mesh = bpy.data.meshes.new( mesh_name )
        new_mesh.from_pydata(verts, [], LODs)
        new_mesh.normals_split_custom_set_from_vertices( norms )
        new_mesh.use_auto_smooth = True
        new_mesh.update()
        
        #mesh_object
        new_object = bpy.data.objects.new( meshID , new_mesh )
        
        if hasColor == 'true':
            new_mesh.vertex_colors.new()
            color_layer = new_mesh.vertex_colors.active
            i = 0
            for poly in new_mesh.polygons:
                for v_ix, l_ix in zip(poly.vertices, poly.loop_indices):
                    vert_color = vcolors[v_ix]
                    color_layer.data[i].color = ( to_srgb(vert_color[0]), to_srgb(vert_color[1]), to_srgb(vert_color[2]), vert_color[3])
                    i += 1
                
        if ( meshUVCount != 0 ):
            for h in range( meshUVCount ):
                meshUV = UVindices[h]
                meshUV = sceneData[1][1][modelIndex][meshUV]
                
                UVName = (meshID + "_UV" + str(h))
                
                #CreateNewUVLayer
                new_uv = new_object.data.uv_layers.new(name=UVName)
                           
                for face in new_mesh.polygons:
                    for vert_idx, loop_idx in zip(face.vertices, face.loop_indices):
                        new_uv.data[loop_idx].uv = [ meshUV[vert_idx][0] , -1.0 * (meshUV[vert_idx][1] - 1.0) ]

        if isSkinned == 'true':    
            #add rigData
            for grp in range( len(rigData[0]) ):
                
                boneName = rigData[0][grp]
                vertex_group_data = rigData[1][grp]
                weight_group_data = rigData[2][grp]
                
                vertGroup = new_object.vertex_groups.new(name=boneName)

                for x in range( len( vertex_group_data ) ):
                    var_0 = vertex_group_data[x]
                    weight = weight_group_data[x]
                    vertGroup.add(  [var_0] , weight , 'REPLACE')
                    

        if isSkinned == 'true':         
            # add object to scene collection
            new_object.parent = rig
            modifier = new_object.modifiers.new(type='ARMATURE', name="Armature")
            modifier.object = rig
        else:
            new_object.rotation_euler[0] = radians(-90)
        
        mdlCollection.objects.link(new_object)
        

    return