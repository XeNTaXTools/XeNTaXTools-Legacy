import newGameLib
from newGameLib import *
import Blender

def pfsParser(filename,g):
	sys=Sys(filename)
	sys.addDir(sys.base)
	g.seek(2861)
	while(True):
		if g.tell()>=g.fileSize():break	
		dir=g.word(256)
		print 
		print dir,g.tell()
		print
		
		nsys=Sys(sys.dir+os.sep+sys.base+os.sep+dir)
		nsys.addDir(dir)
		
		g.seek(576,1)
		
		v=g.i(3)
		
		g.seek(v[1])
		
		#for m in range(200):
		while(True):
			xxx=g.i(2)
			if xxx[1]==0:
				break
			name=g.word(256)
			w=g.i(5)
			new=open(sys.dir+os.sep+sys.base+os.sep+dir+os.sep+name,'wb')
			new.write(zlib.decompress(g.read(w[0])))
			new.close()
			print name,g.tell()
	
	
	
def gmdParser(filename,g):
	
	g.word(4)
	fileType=g.H(1)[0]
	print 'fileType:',fileType
	
	g.debug=False
	if fileType==104:
		skeleton=Skeleton()
		skeleton.BONESPACE=True
		skeleton.NICE=True
		#skeleton.IK=True
		#g.debug=True
		w=g.B(7)
		print 'boneCount:',w[0]
		for m in range(w[4]):
			bone=Bone()
			bone.parentID=g.b(1)[0]
			bone.name=g.word(g.B(1)[0])
			skeleton.boneList.append(bone)
		g.i(1)[0]	
		for m in range(w[4]):
			g.i(1)
			bone=skeleton.boneList[m]
			bone.posMatrix=VectorMatrix(g.f(3))
			bone.rotMatrix=QuatMatrix(g.f(4))
		#g.debug=False
		skeleton.draw()	
			
		matCount=g.B(1)[0]
		print 'matCount:',matCount
		meshList=[]
		for n in range(matCount):
			mat=Mat()
			file=g.word(g.B(1)[0])
			if len(file)>0:
				mat.diffuse=g.dirname+os.sep+file
			file=g.word(g.B(1)[0])
			if len(file)>0:
				mat.normal=g.dirname+os.sep+file
			print mat.diffuse
			print mat.normal
			
			
			mesh=Mesh()
			mat.TRIANGLE=True
			mesh.matList.append(mat)
			pointCount=g.i(1)[0]
			mesh.pointCount=pointCount
			print 'pointCount:',pointCount
			pointList=[]
			for m in range(pointCount):
				pointList.append(g.f(3))
			print g.B(1)
			vertCount=g.i(1)[0]
			mesh.vertCount=vertCount
			print 'vertCount:',vertCount
			pointIDList=[]	
			for m in range(vertCount):
				pointID=g.i(1)[0]
				pointIDList.append(pointID)
				mesh.vertPosList.append(pointList[pointID])
			mesh.pointIDList=pointIDList
				
			for m in range(vertCount):g.f(3)
			for m in range(vertCount):g.f(3)
			for m in range(vertCount):g.f(1)
			for m in range(vertCount):mesh.vertUVList.append(g.f(2))
			for m in range(vertCount):g.f(1)
			mesh.indiceList=g.i(g.i(1)[0])
			
			#g.debug=True
			mesh.BINDSKELETON=skeleton.name
			#mesh.draw()
			meshList.append(mesh)
		for n in range(matCount):
			mesh=meshList[n]
			indiceCountList=g.B(mesh.pointCount)	
			weightList=[]
			for m in range(mesh.pointCount):
				weightList.append(g.f(4))
			indiceList=[]
			for m in range(mesh.pointCount):	
				indiceList.append(g.B(4))
			for m in range(mesh.vertCount):
				#print weightList[pointIDList[m]],indiceCountList[m]
				mesh.skinWeightList.append(weightList[mesh.pointIDList[m]])
			for m in range(mesh.vertCount):
				indice=list(indiceList[mesh.pointIDList[m]])
				indice.reverse()
				mesh.skinIndiceList.append(indice)
			skin=Skin()
			mesh.skinList.append(skin)	
			mesh.boneNameList=skeleton.boneNameList
			mesh.draw()	
			
	
	if fileType==103:
		g.logOpen()
		skeleton=Skeleton()
		skeleton.BONESPACE=True
		skeleton.NICE=True
		#skeleton.IK=True
		w=g.B(3)
		print 'boneCount:',w[0]
		for m in range(w[0]):
			bone=Bone()
			bone.parentID=g.b(1)[0]
			bone.name=g.word(g.B(1)[0])
			skeleton.boneList.append(bone)
		#g.debug=True	
		for m in range(w[0]):
			g.i(1)
			bone=skeleton.boneList[m]
			bone.posMatrix=VectorMatrix(g.f(3))
			bone.rotMatrix=QuatMatrix(g.f(4))
		#g.debug=False
		skeleton.draw()	
			
		matCount=g.B(1)[0]
		print 'matCount:',matCount
		for n in range(matCount):
			mat=Mat()
			file=g.word(g.B(1)[0])
			if len(file)>0:
				mat.diffuse=g.dirname+os.sep+file
			file=g.word(g.B(1)[0])
			if len(file)>0:
				mat.normal=g.dirname+os.sep+file
			print mat.diffuse
			print mat.normal
			
			
			mesh=Mesh()
			mat.TRIANGLE=True
			
			
			mesh.matList.append(mat)
			mesh.TRIANGLE=True
			pointCount=g.i(1)[0]
			print 'pointCount:',pointCount
			pointList=[]
			for m in range(pointCount):pointList.append(g.f(3))
			g.B(1)
			vertCount=g.i(1)[0]
			print 'vertCount:',vertCount
			pointIDList=[]	
			for m in range(vertCount):
				pointID=g.i(1)[0]
				pointIDList.append(pointID)
				mesh.vertPosList.append(pointList[pointID])
				
			for m in range(vertCount):g.f(3)
			for m in range(vertCount):g.f(3)
			for m in range(vertCount):g.f(1)
			for m in range(vertCount):mesh.vertUVList.append(g.f(2))
			for m in range(vertCount):g.f(1)
			mesh.indiceList=g.i(g.i(1)[0])
			
			#g.debug=True
			mesh.matrix=skeleton.matrix
			mesh.BINDSKELETON=skeleton.name
			indiceCountList=g.B(pointCount)	
			weightList=[g.f(4) for m in range(pointCount)]
			indiceList=[g.B(4) for m in range(pointCount)]
			for m in range(vertCount):mesh.skinWeightList.append(weightList[pointIDList[m]])
			for m in range(vertCount):
				indice=list(indiceList[pointIDList[m]])
				indice.reverse()
				mesh.skinIndiceList.append(indice)
			skin=Skin()
			mesh.skinList.append(skin)	
			mesh.boneNameList=skeleton.boneNameList
			mesh.draw()	
		print 'endOffset:',g.tell()
		g.logClose()
	
	
def gamParser(filename,g):
	g.word(4)
	fileType=g.H(1)[0]
	print 'fileType:',fileType
	if fileType==101:
		action=Action()
		action.BONESPACE=True
		action.BONESORT=True
		#action.FRAMESORT=True
		action.skeleton='armature'
		w=g.B(3)
		boneCount=w[0]
		print 'boneCount:',boneCount
		for m in range(w[0]):
			abone=ActionBone()
			parentID=g.b(1)[0]
			abone.name=g.word(g.B(1)[0])
			action.boneList.append(abone)
		#g.debug=True
		g.i(1)
		for n in range(boneCount):
			abone=action.boneList[n]
			frameCount=g.H(1)[0]
			for m in range(frameCount):
				frameID=g.H(1)[0]
				abone.posFrameList.append(frameID)
				abone.rotFrameList.append(frameID)
				abone.posKeyList.append(VectorMatrix(g.f(3)))
				abone.rotKeyList.append(QuatMatrix(g.f(4)).resize4x4())
		action.draw()
		action.setContext()
	if fileType==100:
		action=Action()
		action.BONESPACE=True
		action.BONESORT=True
		#action.FRAMESORT=True
		action.skeleton='armature'
		w=g.B(3)
		boneCount=w[0]
		print 'boneCount:',boneCount
		for m in range(w[0]):
			abone=ActionBone()
			parentID=g.b(1)[0]
			abone.name=g.word(g.B(1)[0])
			action.boneList.append(abone)
		#g.debug=True
		#g.debug=True
		for n in range(boneCount):
			abone=action.boneList[n]
			frameCount=g.H(1)[0]
			for m in range(frameCount):
				frameID=g.H(1)[0]
				abone.posFrameList.append(frameID)
				abone.rotFrameList.append(frameID)
				abone.posKeyList.append(VectorMatrix(g.f(3)))
				abone.rotKeyList.append(QuatMatrix(g.f(4)).resize4x4())
		action.draw()
		action.setContext()
	g.tell()	
	
def Parser():	
	filename=input.filename
	print
	print filename
	print
	imageList=input.imageList
	ext=filename.split('.')[-1].lower()	
	
	if ext=='pfs':
		file=open(filename,'rb')
		g=BinaryReader(file)
		pfsParser(filename,g)
		file.close()
	
	if ext=='gmd':
		file=open(filename,'rb')
		g=BinaryReader(file)
		gmdParser(filename,g)
		file.close()
	
	if ext=='gam':
		file=open(filename,'rb')
		g=BinaryReader(file)
		gamParser(filename,g)
		file.close()
 
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
	
Blender.Window.FileSelector(openFile,'import','gmd - skinned mesh with rig, gam - animation') 	 