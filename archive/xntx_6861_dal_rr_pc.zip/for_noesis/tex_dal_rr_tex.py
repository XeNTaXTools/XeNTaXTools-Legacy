from inc_noesis import *

# debug level
# 0 - info/warn/error messages (hidden)
# 1 - 0 + pop up Noesis Debug Log
# 2 - 1 + debug messages and some variables
DEBUGLEVEL = 0
#-------------------------------------------------------------------------------
def registerNoesisTypes():
    handle = noesis.register("DaL: Rio Reincarnation PC", ".tex")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    if DEBUGLEVEL >= 1: noesis.logPopup()
    return 1
#-------------------------------------------------------------------------------
def noepyCheckType(data):
    bs = NoeBitStream(data)
    bs.setEndian(0)
    ID = bs.readUShort()
    if ID == 0x6554: # "Te"
        bs.seek(0, 0)
        if noeStrFromBytes(bs.readBytes(8)) == "Texture ": return 1
        else: return 0
    elif ID & 0x4083: return 1
    else: return 0
#-------------------------------------------------------------------------------
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.setEndian(0)
    ID = bs.readUShort()
    if ID == 0x6554: # "Te"
        bs.seek(0, 0)
        if bs.readBytes(20) == b"Texture             ":
            if DEBUGLEVEL >= 2: print("[DEBUG] Full header.")
        else: return None
        DUMMY = bs.readUInt()
    elif ID & 0x4081:
        bs.seek(0, 0)
        if DEBUGLEVEL >= 2: print("[DEBUG] Short header.")

    TMP = bs.readUInt64()
    TEXFMT = TMP & 0xFFFF
    TEXFLAGS = TMP >> 48 # 0x10 - required?
    if DEBUGLEVEL >= 2: print("[DEBUG] TEXFMT: "+hex(TEXFMT)+"; TEXFLAGS: "+hex(TEXFLAGS))
    dataSize = bs.readUInt()
    width = bs.readUShort()
    height = bs.readUShort()

    if TEXFMT & 0x4000: fmtText = "RGBA8"; texFmt = noesis.NOESISTEX_RGBA32
    elif TEXFMT & 0x80: fmtText = "L8"; texFmt = noesis.NOESISTEX_RGB24
    elif TEXFMT & 0x02: fmtText = "DXT5"; texFmt = noesis.NOESISTEX_DXT5
    elif TEXFMT & 0x01: fmtText = "DXT1"; texFmt = noesis.NOESISTEX_DXT1
    else: return None

    print("[i] Format: "+fmtText+"; WxH: "+repr(width)+"x"+repr(height)+"; data start: "+hex(bs.tell())+"; data size: "+repr(dataSize)+" B.")

    TMP = bs.readBytes(4)
    bs.seek(-4, 1)
    data = bs.readBytes(dataSize)
    if TMP == b"LZ77": print("[i] Sting/Aquaplus LZSS."); data = decompStingAquaplusLZSS(data, dataSize)

    # L8 => RGB
    if TEXFMT & 0x80:
        In = bytearray(data)
        Out = bytearray(3*len(data))
        for i in range(3): Out[i::3] = In[0::1]
        data = Out

    texList.append(NoeTexture(rapi.getInputName(), width, height, data, texFmt))
    return 1
#-------------------------------------------------------------------------------
def decompStingAquaplusLZSS(data, compSize):
    data = NoeBitStream(data)
    if noeStrFromBytes(data.readBytes(4)) != "LZ77": return None
    data.setEndian(0)
    decompSize = data.readUInt()
    print("[i] Compressed size: "+repr(compSize)+" B. Decompressed size: "+repr(decompSize)+" B. Ratio: "+repr(round(compSize/decompSize*100, 2))+"%.")
    LZSSOpCount = data.readUInt()
    LZSSDataOffset = data.readUInt()
    LZSSFlagsLength = LZSSDataOffset - 16

    flags = data.readBytes(LZSSFlagsLength)
    flags = NoeBitStream(flags)
    cmpData = data.readBytes(compSize-LZSSDataOffset)
    cmpData = NoeBitStream(cmpData)

    decompData = bytearray(decompSize)
    FlagBufferBitCount = 0
    OutPos = 0

    for i in range(LZSSOpCount):
        if FlagBufferBitCount == 0:
            FLAGS = flags.readUByte()
            FlagBufferBitCount = 8

        if FLAGS & 0x80:
            BACKSTEP = cmpData.readUByte()
            COPYAMOUNT = cmpData.readUByte() + 3
            decompData[OutPos:OutPos+COPYAMOUNT] = decompData[OutPos-BACKSTEP:OutPos-BACKSTEP+COPYAMOUNT]
            OutPos += COPYAMOUNT
        else:
            DATA = cmpData.readUByte()
            decompData[OutPos] = DATA
            OutPos += 1

        FLAGS <<= 1
        FlagBufferBitCount -= 1

    return decompData
#-------------------------------------------------------------------------------