

class TMX_HEADER
{
public:
	WORD Signature;
	WORD TexID;
	SPLIT_UINT Format;
	char TMX0[4];
	WORD Unknown1[3];
	WORD DimX;
	WORD DimY;
	BYTE Unknown2[1];
	BYTE MapMapTextureCount;
	SPLIT_UINT Unknown3;
	UINT TextureID;	
	UINT ClutID;
	char Comment[30];
	//
	BYTE IsValid();
	long FileSize();
	//
	TMX_HEADER();
};

class TMX_READER
{
public:
	//
	void Read(char *FileName);
	//
	TMX_READER();
};