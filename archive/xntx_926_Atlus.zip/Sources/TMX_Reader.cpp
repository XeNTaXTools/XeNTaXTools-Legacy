#include "StdAfx.h"

TMX_HEADER::TMX_HEADER()
{
	//sprintf(TMX0,"TMX0");
}
BYTE TMX_HEADER::IsValid()
{
	char test[5]="TMX0";
	for(int y=0;y<4;y++)
	{
		if (TMX0[y]!=test[y])
			return 0;
	}
	if (Signature==2)
		return 1;
	return 0;
}
long TMX_HEADER::FileSize()
{
	int divider=1;
	int diff=0;
	if (Format.Word[0].Byte[0]==128 && Format.Word[0].Byte[1]==16)
	{
		divider=2;
		diff=128;
		//4bpp
	}
	if (Format.Word[0].Byte[0]==64)
	{
		if (Format.Word[0].Byte[1]==4)
		{
up:
			//8bpp
			divider=1;
			diff=1088;
		}
		else if (Format.Word[0].Byte[1]==132)
		{
			goto up;
		}
	}
	if (divider==-1)
	{
		//DebugBreak();
	}	
	int pixelsize=DimX*DimY;
	int datasize=pixelsize/divider+diff;
	return datasize;
}
TMX_READER::TMX_READER()
{

}

void TMX_READER::Read(char *FileName)
{
	FILE *f=fopen(FileName,"rb");
	if (!f)
		return;
	TMX_HEADER Header;
	int total_size=GetFileSize(FileName);
	fread(&Header,sizeof(TMX_HEADER),1,f);
	if (!Header.IsValid())
		return;
	long datasize=Header.FileSize();
	if (total_size==datasize)
	{
		total_size=1;
		//wrong data ?
	}
	fclose(f);
}