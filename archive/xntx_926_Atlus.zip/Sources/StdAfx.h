

#undef UNICODE
#pragma warning(disable:4996)//PRAGMA DEPRECATED

//The MemoryLeak Detector
#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h>
//
#define WIN32_LEAN_AND_MEAN //faster builds ?

#include <stdio.h>
#include <windows.h>
#include <commctrl.h>
#include <time.h>
#ifdef WIN32_LEAN_AND_MEAN
		#include <mmsystem.h>
		#include <commdlg.h>
#endif

#include <dbghelp.h.>

//RECore
#include "..\..\..\Relative Engine 2.X\RECore\Sources\RECore.h"

//Hacking library
#include "..\..\HackLib\Hacklib.h"

#include "Atlus_DDT_IMG.h"
#include "TMX_Reader.h"
#include "PB_Reader.h"