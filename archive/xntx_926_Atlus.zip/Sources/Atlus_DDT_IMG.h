


class FOLDER_HEADER
{
public:	
	long name_offset;
	union
	{
		long next_offset;
		long FileID;
	};
	union
	{
		long subentries;
		long FileSize;
	};
	//filename
	char Name[200];
	//includes whole directory
	char FullName[200];
	FOLDER_HEADER *SubEntry;
	//
	FOLDER_HEADER();
	~FOLDER_HEADER();
};

class ATLUS_DDT_IMG
{
public:
	FOLDER_HEADER MegaHeader;
	long totalsize;
	BYTE CreateFilesAndDirectories;
	LIST<FOLDER_HEADER*> FileList;
	long show_rate;
	//
	void BeginHack(char *InDir,char *OutDir);
	void ReadFolder(FILE *f,FOLDER_HEADER *Header,char *Directory);
	void SortFileList();
	void ExtractFiles(char *InDir,char *OutDir);
	//
	ATLUS_DDT_IMG();
	~ATLUS_DDT_IMG();
};