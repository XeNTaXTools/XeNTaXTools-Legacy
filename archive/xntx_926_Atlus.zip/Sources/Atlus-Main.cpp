

#include "StdAfx.h"


/*
Author : Cippyboy

You may use it at your own discretion but do not say you made this and
give me credit if you're going to post it somewhere for download
*/

void main()
{	
	ATLUS_DDT_IMG Atlus_DDT_IMG;
	TMX_READER TmxReader;
	//
	//DDS1
	//Atlus_DDT_IMG.BeginHack("DDS1 DVD","DDS1-Root");
	//Nocturne
	//Atlus_DDT_IMG.BeginHack("Nocturne DVD","Nocturne-Root");
	//Devil Summoner
	//Atlus_DDT_IMG.BeginHack("E:","Devil Summoner-Root");


	//TmxReader.Read("hack_me.tmx");
	TmxReader.Read("DDS1-Root\\battle\\tmx\\Battle_04.tmx");	
}