#include "StdAfx.h"

FOLDER_HEADER::FOLDER_HEADER()
{
	SubEntry=NULL;
	ZeroMemory(Name,sizeof(Name));
}
FOLDER_HEADER::~FOLDER_HEADER()
{
	SafeDelete(&SubEntry);
}


ATLUS_DDT_IMG::ATLUS_DDT_IMG()
{
	totalsize=0;
	CreateFilesAndDirectories=0;
	show_rate=200;
}
ATLUS_DDT_IMG::~ATLUS_DDT_IMG()
{
}

void ATLUS_DDT_IMG::ReadFolder(FILE *f,FOLDER_HEADER *Header,char *Directory)
{	
	//
	int nrsubentries=-Header->subentries;
	Header->SubEntry=new FOLDER_HEADER[nrsubentries];
	//
	fseek(f,Header->next_offset,SEEK_SET);
	//
	for(int y=0;y<nrsubentries;y++)
	{
		fread(&Header->SubEntry[y],12,1,f);		
	}
	for(int y=0;y<nrsubentries;y++)
	{
		fseek(f,Header->SubEntry[y].name_offset,SEEK_SET);
		//Get it's Name
		char p[3]="a";
		while (p[0]!=0)
		{
			fread(p,1,1,f);
			strcat(Header->SubEntry[y].Name,p);
		}		
	}
	//
	for(int y=0;y<nrsubentries;y++)
	{		
		char NextDirectory[200]="";
		sprintf(NextDirectory,"%s\\%s",Directory,Header->SubEntry[y].Name);		
		//negative means there's another folder
		if (Header->SubEntry[y].subentries<0)
		{
			if (CreateFilesAndDirectories)
			{
				CreateDirectory(NextDirectory,0);
			}						
			//
			ReadFolder(f,&Header->SubEntry[y],NextDirectory);
		}
		//this means that it's actually a file entry in the .IMG
		else
		{
			FileList.AddConst(&Header->SubEntry[y]);
			sprintf(Header->SubEntry[y].FullName,NextDirectory);
			//
			totalsize+=Header->SubEntry[y].subentries;
			if (CreateFilesAndDirectories)
			{
				strcat(NextDirectory,".txt");
				FILE *newf=fopen(NextDirectory,"w");
				fprintf(newf,"name_offset=%d\nnext_offset=%d\nsubentries =%d\n",
							 Header->SubEntry[y].name_offset,
							 Header->SubEntry[y].next_offset,
							 Header->SubEntry[y].subentries);
				fclose(newf);
			}
		}
	}		
}
void ATLUS_DDT_IMG::SortFileList()
{	
	FOLDER_HEADER ***IDArray=new FOLDER_HEADER**[FileList.nr];
	//
	FileList.ExportPointers(IDArray);
	//
	for(int y=0;y<FileList.nr;y++)		
	{
		int min=(*FileList[y])->FileID;		
		for(int u=y+1;u<FileList.nr;u++)
		{
			if ((*FileList[u])->FileID<min)
			{
				min=(*FileList[u])->FileID;
				FOLDER_HEADER *Temp=(*FileList[y]);
				(*FileList[y])=(*FileList[u]);
				(*FileList[u])=Temp;				
			}
		}
	}
	//while(1)
	{
		int mismatch=0;
		int equal=0;
		for(int y=0;y<FileList.nr-1;y++)
		{
			if ((*FileList[y])->FileID>(*FileList[y+1])->FileID)			
			{
				mismatch++;
			}
			else if ((*FileList[y])->FileID==(*FileList[y+1])->FileID)
			{
				equal++;
			}
		}
		mismatch=mismatch;
	}
	SafeDelete(&IDArray);
}
void ATLUS_DDT_IMG::ExtractFiles(char *InDir,char *OutDir)
{
	char DDS3_IMG[200]="";
	sprintf(DDS3_IMG,"%s\\DDS3.IMG",InDir);
	//
	__int64 TotalFileSize=0;
	//GetFileLength(f,&TotalFileSize);
	TotalFileSize=GetFileSize64(DDS3_IMG);
	//
	FILE *f=fopen(DDS3_IMG,"rb");
	if (!f)
		return;
	//
	FOLDER_HEADER ***IDArray=new FOLDER_HEADER**[FileList.nr];
	FileList.ExportPointers(IDArray);
	//
	__int64 offset=0;
	printf("Extracting %d files\n",FileList.nr);
	for(int y=0;y<FileList.nr;y++)
	{
		FOLDER_HEADER *CurrentFile=(*FileList[y]);
		if (y%show_rate==0)
		{
			float completed=((float)offset/(float)TotalFileSize)*100.0f;
			printf("Finished %d files; Data Read %0.2f%%\n",y,completed);
		}
		long current_file_size=(*FileList[y])->FileSize;
		BYTE *data=new BYTE[current_file_size];
		ZeroMemory(data,current_file_size);
		//read it in one chunk
		fread(data,current_file_size,1,f);
		//
		char Directory[200]="";
		//
		GetLocalDirectoryFromFileName((*FileList[y])->FullName,Directory);			
		MakeSureDirectoryPathExists(Directory);
		//
		SaveFile2((*FileList[y])->FullName,data,current_file_size);
		SafeDelete(&data);
		
		while(1)
		{
			//now make little readings to detect the next file
			char chunk[10]="";
			fread(chunk,1,1,f);
			if (chunk[0]!=0)
			{
				//compute new file offset;
				offset=_ftelli64(f)-1;
				_fseeki64(f,offset,SEEK_SET);
				break;
			}
			if (feof(f))
				break;
		}		
	}
	fclose(f);
	SafeDelete(&IDArray);
}
void ATLUS_DDT_IMG::BeginHack(char *InDir,char *OutDir)
{	
	char DDS3_DDT[200]="";
	sprintf(DDS3_DDT,"%s\\DDS3.DDT",InDir);
	//
	long size=GetFileSize(DDS3_DDT);
	//
	FILE *f=fopen(DDS3_DDT,"rb");
	if (!f)
		return;
	//
	printf("Reading [%s] file hierarchy...\n",DDS3_DDT);	
	fread(&MegaHeader,12,1,f);
	ReadFolder(f,&MegaHeader,OutDir);
	fclose(f);
	//
	printf("Sorting %d FileIDs...\n",FileList.nr);
	//SortFileList();
	//	
	ExtractFiles(InDir,OutDir);
}