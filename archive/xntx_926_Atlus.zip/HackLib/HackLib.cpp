
#include "StdAfx.h"


bool SPLIT_WORD::operator==(WORD Other)
{
	return (Word==Other);
}
bool SPLIT_UINT::operator==(UINT Other)
{
	return (uint==Other);
}

// 2-byte number
int BigEndian2(int i)
{
    return ((i>>8)&0xff)+((i << 8)&0xff00);
}

// 4-byte number
int BigEndian4(int i)
{
    return((i&0xff)<<24)+((i&0xff00)<<8)+((i&0xff0000)>>8)+((i>>24)&0xff);
}