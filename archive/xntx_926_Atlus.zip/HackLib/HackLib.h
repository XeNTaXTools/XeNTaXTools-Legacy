
class SPLIT_WORD
{
public:
	union
	{
		BYTE Byte[2];
		char Char[2];
		WORD Word;
		signed short SignedShort;
	};
	bool operator==(WORD Other);	
};
class SPLIT_UINT
{
public:
	union
	{
		SPLIT_WORD Word[2];
		UINT uint;
		long Long;
	};
	bool operator==(UINT Other);	
};

int BigEndian2(int i);
int BigEndian4(int i);