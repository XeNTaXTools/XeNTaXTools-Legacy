# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

bl_info = {
    "name": "Export to 7.62 HC file (.act)",
    "author": "kosi maz",
    "version": (1, 0),
    "blender": (2, 69, 0),
    "location": "File > Export > 7.62 HC act file (.act)",
    "description": "Export mesh to 7.62HC file (.act)",
    "warning": "This script is still in development stage!",
    "wiki_url": "",
    "tracker_url": "",
    "category": "Import-Export"}


import bpy

from bpy.props import StringProperty, BoolProperty, EnumProperty
from bpy.types import Operator
from bpy_extras.io_utils import ExportHelper
from mathutils import *
from math import radians


# main exporting function
def act_exporter(context, filepath, set_axis, set_type):

    set_axis = set_axis
    set_type = set_type

    print("\n\n################")
    print("preparing system matrix...")
    # Creating new matrix for conversing axis
    sys_matrix = Matrix()
    if set_axis:
        sys_matrix *= Matrix.Rotation(radians(90), 4, 'X')
        sys_matrix *= Matrix.Scale(-1, 4, Vector((0, 0, 1)))

        if set_type == 'ADDON':
            sys_matrix *= Matrix.Rotation(radians(90), 4, 'Y')
            print("export as ADDON")
        else:
            print("export as WEAPON")
    print("done!\n\n")

    mesh = context.active_object.data

    # Creating duplicated vertex for each face - I get this from DirectX exporter
    print("preparing mesh data...")
    new_vertices = tuple()
    for p in mesh.polygons:
        new_vertices += tuple(mesh.vertices[i] for i in p.vertices)
    print(str(len(new_vertices)))

    new_polygons = []
    Index = 0
    for p in mesh.polygons:
        new_polygons.append(tuple(range(Index, Index + len(p.vertices))))
        Index += len(p.vertices)
    print(str(len(new_polygons)))
    print("done!\n\n")

    print("opening file...")
    file = open(filepath, 'w', encoding='utf-8')
    print("done!\n\n")

    print("start writing Header...")
    file.write("\
xof 0302txt 0032\n\
template XSkinMeshHeader {\n\
 <3cf169ce-ff7c-44ab-93c0-f78f62d172e2>\n\
 WORD nMaxSkinWeightsPerVertex;\n\
 WORD nMaxSkinWeightsPerFace;\n\
 WORD nBones;\n\
}\n\n\
template VertexDuplicationIndices {\n\
 <b8d65549-d7c9-4995-89cf-53a9a8b031e3>\n\
 DWORD nIndices;\n\
 DWORD nOriginalVertices;\n\
 array DWORD indices[nIndices];\n\
}\n\n\
template SkinWeights {\n\
 <6f0d123b-bad2-4167-a0d0-80224f25fabb>\n\
 STRING transformNodeName;\n\
 DWORD nWeights;\n\
 array DWORD vertexIndices[nWeights];\n\
 array FLOAT weights[nWeights];\n\
 Matrix4x4 matrixOffset;\n\
}\n\n\
Header {\n\
 1;\n\
 0;\n\
 1;\n\
}\n\n\
")
    print("done!\n\n")

    print("writing materials...")
    for mat in mesh.materials:
        file.write("Material {0} ".format(mat.name))
        file.write("{\n\
 0.588000, 0.588000, 0.588000, 1.000000;;\n\
 17.000000;\n\
 0.900000, 0.900000, 0.900000;;\n\
 0.000000, 0.000000, 0.000000;;\n\
")
        file.write(" TextureFilename {\n")
        file.write('  "{0}";\n'.format(mat.active_texture.image.name))
        file.write(" }\n}\n\n")
    print("done!\n\n")

    print("writing mesh...")
    file.write("Mesh {} ".format(mesh.name))
    file.write("{\n")

    print("vertices...")
    vertex_count = len(new_vertices)
    file.write(" {0};\n".format(vertex_count))
    for index, vertex in enumerate(new_vertices):
        v_co = vertex.co * sys_matrix # flipping axis here
        file.write(" {0:6f};{1:6f};{2:6f};".format(v_co[0], v_co[1], v_co[2]))
        
        if index == vertex_count - 1:
            file.write(";\n\n")
        else:
            file.write(",\n")
    print("done!")

    print("faces...")
    face_count = len(new_polygons)
    file.write("  {0};\n".format(face_count))
    for f_index, face in enumerate(new_polygons):
        file.write("  {0};".format(len(face)))
        # Changing from RightHanded system to LeftHanded
        file.write("{0},{1},{2};".format(face[0], face[2], face[1]))
        if f_index == face_count - 1:
            file.write(";\n\n")
        else:
            file.write(",\n")
    print("done!")

    print("uv coords...")
    uv_coords = mesh.uv_layers.active.data
    file.write(" MeshTextureCoords {\n")
    file.write("  {0};\n".format(len(uv_coords)))
    for index, vertex in enumerate(uv_coords):
        v_uv = vertex.uv
        file.write("  {0:6f};{1:6f};".format(v_uv[0], 1 - v_uv[1]))
        if index == len(uv_coords) - 1:
            file.write(";\n")
        else:
            file.write(",\n")
    file.write(" }\n\n")
    print("done!")

    print("material list...")
    file.write(" MeshMaterialList {\n")
    file.write("  {0};\n".format(len(mesh.materials)))
    file.write("  {0};\n".format(face_count))
    for index, face in enumerate(mesh.polygons):
        file.write("  {0}".format(face.material_index))
        if index == face_count -1:
            file.write(";\n")
        else:
            file.write(",\n")
    for mat in mesh.materials:
        file.write("  {")
        file.write("{}".format(mat.name))
        file.write("}\n")
    file.write(" }\n")
    print("done!")#

    file.write("}\n")
    print("whole mesh - done!\n\n")

    print("closing file...")
    file.close()
    print("done!\n\n")


class ExportToActFile(Operator, ExportHelper):
    """Export selected object to 7.62 HC .ACT file."""
    bl_idname = "export_test.export_to_act"
    bl_label = "Export To ACT File"

    # ExportHelper mixin class uses this
    filename_ext = ".act"

    filter_glob = StringProperty(
            default="*.act",
            options={'HIDDEN'},
            )

    # List of operator properties, the attributes will be assigned
    # to the class instance from the operator settings before calling.
    set_axis = BoolProperty(
            name="Converse Axis",
            description="Converse axis from Blender RightHanded to DirectX LeftHanded.",
            default=True,
            )

    set_type = EnumProperty(
            name="Export as:",
            description="",
            items=(('WEAPON', "Weapon", "Choose to export weapons."),
                   ('ADDON', "Attachment", "Choose to export addon attachment.")),
            default='WEAPON',
            )

    def execute(self, context):
        act_exporter(context, self.filepath, self.set_axis, self.set_type)
        return {'FINISHED'}
        
        
# Only needed if you want to add into a dynamic menu
def menu_func_export(self, context):
    self.layout.operator(ExportToActFile.bl_idname, text="7.62 HC act file (.act)")


def register():
    bpy.utils.register_module(__name__)

    bpy.types.INFO_MT_file_export.append(menu_func_export)


def unregister():
    bpy.utils.unregister_module(__name__)

    bpy.types.INFO_MT_file_export.remove(menu_func_export)

# For testing in text editor
if __name__ == "__main__":
    register()

