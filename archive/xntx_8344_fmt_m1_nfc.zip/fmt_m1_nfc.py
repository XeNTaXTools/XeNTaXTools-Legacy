#by Durik256
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Samurai Warriors 4", "._m1;.nfc")
    noesis.setHandlerTypeCheck(handle, CheckType)
    noesis.setHandlerLoadModel(handle, LoadModel)
    return 1

def CheckType(data):
    if data.find(b'cRefl') == -1:
        return 0
    return 1

def LoadModel(data, mdlList):
    bs = NoeBitStream(data)
    ctx = rapi.rpgCreateContext()
    
    m = i(bs,'20I')[-1]
    bs.seek(data.find(b'cRefl') - 28)
    bs.seek(bs.readInt()+4,1)
    
    sm = []
    for x in range(m):
        v = i(bs,'4I')
        sm.append([bs.getOffset(),v[1],v[2]])
        bs.seek(v[1]*v[2],1)
    
    bs.seek(data.find(b'\x07\x00\x01\x00',bs.getOffset())+12)
    
    for x in range(m):
        f = i(bs,'3I')
        ib = bs.readBytes(f[0]*2)
        
        cp = bs.getOffset()
        bs.seek(sm[x][0])
        vb = bs.readBytes(sm[x][1]*sm[x][2])
        bs.seek(cp)
        
        rapi.rpgSetName('mesh_%i'%x)
        rapi.rpgBindPositionBuffer(vb, noesis.RPGEODATA_FLOAT, sm[x][1])
        #rapi.rpgBindUV1BufferOfs(vb, noesis.RPGEODATA_FLOAT, sm[x][1], 40)
        rapi.rpgCommitTriangles(ib, noesis.RPGEODATA_USHORT, f[0], noesis.RPGEO_TRIANGLE_STRIP)
    
    mdl = rapi.rpgConstructModel()
    mdlList.append(mdl)
    return 1

def i(bs,s):
    return struct.unpack(s, bs.readBytes(struct.calcsize(s)))




























def LoadModel2(data, mdlList):
    bs = NoeBitStream(data)
    bs.seek(128)
    bones = []
    u = i(bs,'3I')
    id = 0
    while bs.getOffset() < bs.getSize():
        #u0 = i(bs,'4I')
        name = noeStrFromBytes(bs.readBytes(bs.readInt()))
        u0 = i(bs,'4I')
        
        time, mats = [], []
        for x in range(u0[3]):
            time = bs.readInt()
            mats.append(HalfMat44(bs).toMat43())#bs.readBytes(36)
        if not id:
            bs.seek(4,1)
        bones.append(NoeBone(id,name,mats[0]))
        id += 1
        u1 = i(bs,'4I')
        print(id, name, u0, u1)
    
    mdl = NoeModel()
    mdl.setBones(bones)
    mdlList.append(mdl)
    return 1
    
def HalfMat44(bs):
    vec4 = []
    for x in range(4):
        vec4.append(NoeVec4([bs.readHalfFloat() for x in range(4)]))
    return NoeMat44(vec4)