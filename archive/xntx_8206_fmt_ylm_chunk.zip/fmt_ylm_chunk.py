#by Durik256 for xentax
from inc_noesis import *
import math

def registerNoesisTypes():
    handle = noesis.register("Aerial Strike: The Yager Missions", ".chunk")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)
    return 1

def noepyCheckType(data):
    return 1   
	
def noepyLoadModel(data, mdlList):
    bs = NoeBitStream(data)
    ctx = rapi.rpgCreateContext()
    rapi.rpgSetMaterial('mat_0')
    
    raw_vert = []#17x17
    for y in range(17):
        raw_vert.append([VD(bs) for x in range(17)])
    
    rapi.rpgSetName('chunk_0')
    for y in range(16):
        for x in range(16):
            quad(raw_vert, 'quad_%d_%d' % (x,y), 1, x, y)
    
    tx_name = 'C:/Users/Admin/Desktop/Extract/texture/mission00_159_ground.dds'
    
    rapi.rpgOptimize()
    mdl = rapi.rpgConstructModel()
    mdl.setModelMaterials(NoeModelMaterials([], [NoeMaterial('mat_0',tx_name)]))
    mdlList.append(mdl)
    return 1
    
def quad(raw_vert, name, size, x=0, y=0):
    R, G, B, A = raw_vert[y][x].get()
    
    B = hex(B).replace("0x","")
    B, rot = int(B[-1], 16), int(B[0], 16) if len(B)>1 else 0
    
    ibuf = struct.pack('6H', *[0, 2, 1, 2, 3, 1])
    vbuf = struct.pack('12f', *[0+x, R, 0+y, size+x, raw_vert[y][x+1].R, 0+y, 0+x, raw_vert[y+1][x].R, size+y, size+x, raw_vert[y+1][x+1].R, size+y])
    
    uv1X, uv1Y = ((B*64)/1024), ((G*8)/2048)
    uv2X, uv2Y = (((B+1)*64)/1024), (((G+8)*8)/2048)
    
    if rot == 0:#default
        uvbuf = struct.pack('8f', *[uv1X, uv2Y, uv2X, uv2Y, uv1X, uv1Y, uv2X, uv1Y])
    elif rot == 2:#flip_Y
        uvbuf = struct.pack('8f', *[uv1X, uv1Y, uv2X, uv1Y, uv1X, uv2Y, uv2X, uv2Y])
    elif rot == 4:#flip_X
        uvbuf = struct.pack('8f', *[uv2X, uv2Y, uv1X, uv2Y, uv2X, uv1Y, uv1X, uv1Y])
    elif rot == 6:#rot -> 180
        uvbuf = struct.pack('8f', *[uv2X, uv1Y, uv1X, uv1Y, uv2X, uv2Y, uv1X, uv2Y])
    elif rot == 8:#rot -> 90
        uvbuf = struct.pack('8f', *[uv2X, uv2Y, uv2X, uv1Y, uv1X, uv2Y, uv1X, uv1Y])
    elif rot == 10:#rot <- 90 and flip_Y
        uvbuf = struct.pack('8f', *[uv2X, uv1Y, uv2X, uv2Y, uv1X, uv1Y, uv1X, uv2Y])
    elif rot == 12:#rot -> 90 and flip_Y
        uvbuf = struct.pack('8f', *[uv1X, uv2Y, uv1X, uv1Y, uv2X, uv2Y, uv2X, uv1Y])
    elif rot == 14:#rot <- 90
        uvbuf = struct.pack('8f', *[uv1X, uv1Y, uv1X, uv2Y, uv2X, uv1Y, uv2X, uv2Y])

    rapi.rpgBindPositionBuffer(vbuf, noesis.RPGEODATA_FLOAT, 12)
    rapi.rpgBindUV1Buffer(uvbuf, noesis.RPGEODATA_FLOAT, 8)
    rapi.rpgCommitTriangles(ibuf, noesis.RPGEODATA_USHORT, 6, noesis.RPGEO_TRIANGLE)
    return 1

class VD:
    def __init__(self, bs):
        self.R = bs.readUByte()
        self.G = bs.readUByte()
        self.B = bs.readUByte()
        self.A = bs.readUByte()
        
        self.calc()
        
    def calc(self):
        mul = 0
        if self.G % 8 != 0:
            mul = abs(self.G//8*8-self.G)
            self.G -= mul
        
        self.R = self.R/6 + ((255/6)*mul)
    
    def get(self):
        return [self.R, self.G, self.B, self.A]
    
    def __repr__(self):
        return "(VD:" + " R:" + repr(self.R) + " G:" + repr(self.G) + " B:" + repr(self.B) + " A:" + repr(self.A) + ")"