----------------------
EPIC MICKEY 1 DCT TOOL
 CREATED BY RYAN KOOP
----------------------

USAGE:
dct.py [path to JSON/DCT file]

Upon redistributing this, please include this file with the script.