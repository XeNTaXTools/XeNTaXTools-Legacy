import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;

public class WotXmlParser implements SimpleXmlParser
{
	private static class DataDescriptor
	{
		private final int address;
		private final int end;
		private final int type;

		public DataDescriptor( int end, int type, int address )
		{
			this.end = end;
			this.type = type;
			this.address = address;
		}

		public String toString()
		{
			StringBuilder sb = new StringBuilder( "[" );

			sb.append( "0x" );
			sb.append( Integer.toHexString( end ) );
			sb.append( ", " );
			sb.append( "0x" );
			sb.append( Integer.toHexString( type ) );
			sb.append( "]@0x" );
			sb.append( Integer.toHexString( address ) );
			return sb.toString();
		}
	}

	private static class ElementDescriptor
	{
		private final int nameIndex;
		private final DataDescriptor dataDescriptor;

		public ElementDescriptor( int nameIndex, DataDescriptor dataDescriptor )
		{
			this.nameIndex = nameIndex;
			this.dataDescriptor = dataDescriptor;
		}

		public String toString()
		{
			StringBuilder sb = new StringBuilder( "[" );
			sb.append( "0x" );
			sb.append( Integer.toHexString( nameIndex ) );
			sb.append( ":" );
			sb.append( dataDescriptor );
			return sb.toString();
		}
	}

	private static class CounterInputStream extends InputStream
	{
		private int counter;
		private final InputStream in;

		public CounterInputStream( InputStream in )
		{
			this.in = in;
			this.counter = -1;
		}

		@Override
		public int read() throws IOException
		{
			int result = this.in.read();
			this.counter++;
			return result;
		}

		@Override
		public synchronized void reset() throws IOException
		{
			this.counter = -1;
			this.in.reset();
		}

	}

	private static final byte[] MAGIC_NUMBER =
	{
			0x45, 0x4E, -0x5F, 0x62
	};

	private static final char[] intToBase64 =
			{
					'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L',
					'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X',
					'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j',
					'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v',
					'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7',
					'8', '9', '+', '/'
			};

	private static final int MAX_LENGTH = 256;

	private final Charset charset;

	public WotXmlParser( Charset charset )
	{
		this.charset = charset;

	}

	public WotXmlParser()
	{
		this( Charset.forName( "UTF-8" ) );
	}

	public SimpleXmlElement parse( InputStream in ) throws IOException
	{
		CounterInputStream din = new CounterInputStream( in );

		verifyMagicNumber( din );

		din.read(); // 0x00

		ArrayList<String> dictionary = readDictionary( din );

		SimpleXmlElement root = new SimpleXmlElement( "root" );

		readElement( din, root, dictionary );

		return root;
	}

	private ArrayList<String> readDictionary( InputStream din )
			throws IOException
	{
		ArrayList<String> dictionary = new ArrayList<String>();

		int counter = 0;
		String text = readStringTillZero( din );

		while (!text.isEmpty())
		{
			dictionary.add( text );
			text = readStringTillZero( din );
			counter++;
		}

		return dictionary;
	}

	private int readLittleEndianInt( InputStream din ) throws IOException
	{
		byte[] work = new byte[4];
		din.read( work, 0, 4 );
		return (work[3]) << 24 | (work[2] & 0xff) << 16 | (work[1] & 0xff) << 8
				| (work[0] & 0xff);
	}

	private int readLittleEndianShort( InputStream din ) throws IOException
	{
		byte[] work = new byte[2];
		din.read( work, 0, 2 );
		return (work[1] & 0xff) << 8 | (work[0] & 0xff);
	}

	private long readNumber( InputStream din, int lengthInBytes )
			throws IOException
	{
		byte[] bytes = new byte[lengthInBytes];
		din.read( bytes );
		long result = 0;
		for (int i = bytes.length - 1; i >= 0; i--)
		{
			result <<= 8;
			result |= bytes[i] & 0xFF;
		}
		return result;
	}

	private String readString( InputStream din, int lengthInBytes )
			throws IOException
	{
		byte[] bytes = new byte[lengthInBytes];
		din.read( bytes );
		return new String( bytes, charset );
	}

	private String readStringTillZero( InputStream din ) throws IOException
	{

		byte[] work = new byte[MAX_LENGTH];

		int i = 0;

		byte c = (byte) din.read();
		while (c != 0)
		{
			work[i++] = c;
			c = (byte) din.read();
		}
		return new String( work, 0, i, charset );

	}

	private void readElement( CounterInputStream din, SimpleXmlElement element,
			ArrayList<String> dictionary ) throws IOException
	{
		int childrenNmber = readLittleEndianShort( din );

		DataDescriptor selfDataDescriptor = readDataDescriptor( din );
		ElementDescriptor[] children =
				readElementDescriptors( din, childrenNmber );

		int offset = readData( din, dictionary, element, 0, selfDataDescriptor );
		for (ElementDescriptor elementDescriptor : children)
		{
			SimpleXmlElement child =
					new SimpleXmlElement( dictionary.get( elementDescriptor.nameIndex ) );
			element.getChildren().add( child );
			offset =
					readData( din, dictionary, child, offset,
							elementDescriptor.dataDescriptor );
		}
	}

	private ElementDescriptor[] readElementDescriptors( CounterInputStream din,
			int number ) throws IOException
	{
		ElementDescriptor[] elements = new ElementDescriptor[number];

		for (int i = 0; i < number; i++)
		{
			int nameIndex = readLittleEndianShort( din );
			DataDescriptor dataDescriptor = readDataDescriptor( din );
			elements[i] = new ElementDescriptor( nameIndex, dataDescriptor );
		}
		return elements;
	}


	private DataDescriptor readDataDescriptor( CounterInputStream din )
			throws IOException
	{
		int selfEndAndType = readLittleEndianInt( din );
		return new DataDescriptor( selfEndAndType & 0x0fffffff,
				selfEndAndType >> 28, din.counter );
	}


	private int readData( CounterInputStream din, ArrayList<String> dictionary,
			SimpleXmlElement element, int offset, DataDescriptor dataDescriptor )
			throws IOException
	{
		int lengthInBytes = dataDescriptor.end - offset;
		if (dataDescriptor.type == 0x0)
		{
			// Element
			readElement( din, element, dictionary );
		}
		else if (dataDescriptor.type == 0x1)
		{
			// String
			element.setValue( readString( din, lengthInBytes ) );
		}
		else if (dataDescriptor.type == 0x2)
		{
			// Integer number
			element
					.setValue( Long.toString( readNumber( din, lengthInBytes ) ) );
		}
		else if (dataDescriptor.type == 0x3)
		{
			// Floats
			element.setValue( readFloats( din, lengthInBytes ) );
		}
		else if (dataDescriptor.type == 0x4)
		{
			// Boolean
			element.setValue( Boolean
					.toString( readBoolean( din, lengthInBytes ) ) );

		}
		else if (dataDescriptor.type == 0x5)
		{
			// Base64
			element.setValue( readBase64( din, lengthInBytes ) );
		}
		else
		{
			throw new IllegalArgumentException( "Unknown type of \""
					+ element.getName() + ": " + dataDescriptor.toString()
					+ " " + readAndToHex( din, lengthInBytes ) );
		}

		return dataDescriptor.end;
	}

	private boolean readBoolean( CounterInputStream din, int lengthInBytes )
			throws IOException
	{
		boolean bool = lengthInBytes == 1;
		if (bool)
		{
			if (din.read() != 1)
			{
				throw new IllegalArgumentException( "Boolean error" );
			}
		}

		return bool;
	}

	private String readBase64( CounterInputStream din, int lengthInBytes )
			throws IOException
	{
		byte[] bytes = new byte[lengthInBytes];
		din.read( bytes );
		return byteArrayToBase64( bytes );
	}

	private String readFloats( InputStream din, int lengthInBytes )
			throws IOException
	{
		int n = lengthInBytes / 4;
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < n; i++)
		{
			if (i != 0)
			{
				sb.append( " " );
			}
			sb.append( Float.toString( readLittleEndianFloat( din ) ) );

		}
		return sb.toString();
	}

	private float readLittleEndianFloat( InputStream din ) throws IOException
	{
		byte[] bytes = new byte[4];
		din.read( bytes );
		int result = 0;
		for (int i = bytes.length - 1; i >= 0; i--)
		{
			result <<= 8;
			result |= bytes[i] & 0xFF;
		}
		return Float.intBitsToFloat( result );
	}

	private String readAndToHex( InputStream din, int lengthInBytes )
			throws IOException
	{
		byte[] bytes = new byte[lengthInBytes];
		din.read( bytes );
		StringBuilder sb = new StringBuilder( "[ " );
		for (byte b : bytes)
		{
			sb.append( Integer.toHexString( b & 0xff ) );
			sb.append( " " );
		}
		sb.append( "]L:" );
		sb.append( lengthInBytes );

		return sb.toString();
	}

	private void verifyMagicNumber( InputStream din ) throws IOException
	{
		byte[] number = new byte[4];
		din.read( number );
		if (!Arrays.equals( number, MAGIC_NUMBER ))
			throw new IOException( "Invalid magic number" );
	}

	private static String byteArrayToBase64( byte[] a )
	{
		int aLen = a.length;
		int numFullGroups = aLen / 3;
		int numBytesInPartialGroup = aLen - 3 * numFullGroups;
		int resultLen = 4 * ((aLen + 2) / 3);
		StringBuffer result = new StringBuffer( resultLen );

		int inCursor = 0;
		for (int i = 0; i < numFullGroups; i++)
		{
			int byte0 = a[inCursor++] & 0xff;
			int byte1 = a[inCursor++] & 0xff;
			int byte2 = a[inCursor++] & 0xff;
			result.append( intToBase64[byte0 >> 2] );
			result.append( intToBase64[(byte0 << 4) & 0x3f | (byte1 >> 4)] );
			result.append( intToBase64[(byte1 << 2) & 0x3f | (byte2 >> 6)] );
			result.append( intToBase64[byte2 & 0x3f] );
		}

		if (numBytesInPartialGroup != 0)
		{
			int byte0 = a[inCursor++] & 0xff;
			result.append( intToBase64[byte0 >> 2] );
			if (numBytesInPartialGroup == 1)
			{
				result.append( intToBase64[(byte0 << 4) & 0x3f] );
				result.append( "==" );
			}
			else
			{
				// assert numBytesInPartialGroup == 2;
				int byte1 = a[inCursor++] & 0xff;
				result.append( intToBase64[(byte0 << 4) & 0x3f | (byte1 >> 4)] );
				result.append( intToBase64[(byte1 << 2) & 0x3f] );
				result.append( '=' );
			}
		}

		return result.toString();
	}

}
