﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace rip2obj
{
    class Program
    {
        struct FACE
        {
            public int i0;
            public int i1;
            public int i2;
        }
        struct VERTEX
        {
            public float vx;
            public float vy;
            public float vz;

            public float nx;
            public float ny;
            public float nz;

            public float u;
            public float v;
        }
        static void start()
        {
            Console.WriteLine("rip2obj by aaro4130");
            Console.WriteLine("-----------------------------");
        }
        
        static void usage()
        {
            Console.WriteLine("usage : rip2obj <filename> [-silent]");
        }
        static void stop(bool silent = false)
        {
            Console.WriteLine("-----------------------------");
            Console.WriteLine("Press ENTER to close program.");
            if (!silent)
                Console.Read();
            Environment.Exit(0);
        }
        static string ReadCStr(ref System.IO.BinaryReader rdr)
        {
            byte lastRead = 255;
            string compiled = "";
            while(lastRead > 0)
            {
                lastRead = rdr.ReadByte();
                if(lastRead > 0)
                {
                    compiled += Convert.ToChar(lastRead);
                }
            }
            return compiled;
            
        }
        static void Main(string[] args)
        {
            bool silentMode = (args.Contains("-silent"));
            start();
            if (args.Length == 0)
            {
                usage();
                stop(silentMode);
            }

            //check if our argument is a file
            if (System.IO.File.Exists(args[0]))
            {
                //setup our stuff
                var sb = new System.Text.StringBuilder();
                var r = new System.IO.BinaryReader(System.IO.File.OpenRead(args[0]));
                //OFFSETS
                long vertexOffset = 0;
                long normalOffset = 0;
                long uvOffset = 0;
                //LISTS
                List<FACE> faceList = new List<FACE>();
                List<int> attribList = new List<int>();
                List<VERTEX> vertList = new List<VERTEX>();
                List<string> texFiles = new List<string>();
                using (r)
                {
                    uint signature = r.ReadUInt32();
                    uint version = r.ReadUInt32();
                    if (signature != 0xdeadc0de || version != 4){
                        Console.WriteLine("Not RIP file");
                        stop(silentMode);
                    }

                    int dwFacesCnt = r.ReadInt32();
                    int dwVertexesCnt = r.ReadInt32();
                    int vertexSize = r.ReadInt32();
                    int textureFilesCnt = r.ReadInt32();
                    int shaderFilesCnt = r.ReadInt32();
                    int vertexAttributesCnt = r.ReadInt32();

                    for(int i=0; i < vertexAttributesCnt; i++)
                    {
                        //GET SEMANTIC
                        string semantic = ReadCStr(ref r);
                        int semanticIndex = r.ReadInt32();
                        int offset = r.ReadInt32();
                        int size = r.ReadInt32();
                        int typeMapElems = r.ReadInt32();
                        for(int j=0; j < typeMapElems; j++)
                        {
                            //skip these
                            attribList.Add(r.ReadInt32());
                        }

                        //DATA STUFF
                        if(semantic == "POSITION" && vertexOffset == 0
                            )
                        { 
                            vertexOffset = offset / 4;
                        }else if(semantic == "NORMAL" && normalOffset == 0)
                        {
                            normalOffset = offset / 4;
                        }else if(semantic == "TEXCOORD" && uvOffset == 0)
                        {
                            uvOffset = offset / 4;
                        }
                    }
                    for(int i=0; i < textureFilesCnt; i++)
                    {
                        string texFile = ReadCStr(ref r);
                        texFiles.Add(texFile);
                    }

                    for (int i = 0; i < shaderFilesCnt; i++)
                    {
                        string shdFile = ReadCStr(ref r);
                    }

                    for (int i = 0; i < dwFacesCnt; i++)
                    {
                        int i0x = r.ReadInt32();
                        int i1x = r.ReadInt32();
                        int i2x = r.ReadInt32();
                        faceList.Add(new FACE { i0 = i0x, i1 = i1x, i2 = i2x });
                    }

                    for(int i=0; i < dwVertexesCnt; i++)
                    {
                        //**********************
                        float vx = 0;
                        float vy = 0;
                        float vz = 0;
                        float nx = 0;
                        float ny = 0;
                        float nz = 0;
                        float tu = 0;
                        float tv = 0;
                        for (int j = 0; j < attribList.Count; j++)
                        {
                            float z = 0;
                            int elemType = attribList[j];
                            if (elemType == 0)
                                z = r.ReadSingle();
                            if (elemType == 1)
                                z = (float)r.ReadUInt32();
                            if (elemType == 2)
                                z = (float)r.ReadInt32();
                            //*** ** **** ****
                            if (j == vertexOffset)
                                vx = z;
                            if (j == (vertexOffset + 1))
                                vy = z;
                            if (j == (vertexOffset + 2))
                                vz = z;

                            if (j == normalOffset)
                                nx = z;
                            if (j == (normalOffset + 1))
                                ny = z;
                            if (j == (normalOffset + 2))
                                nz = z;

                            if (j == uvOffset)
                                tu = z;
                            if (j == (uvOffset + 1))
                                tv = (z * -1) + 1;
                        }

                        //add to vertex list
                        vertList.Add(new VERTEX { vx = vx, vy = vy, vz = vz, nx = nx, ny = ny, nz = nz, u = tu, v = tv });
                    }

                    //STILL IN R :D
                }

                ///////////////////////////////////////
                //BUILD OBJ FILE///////////////////////
                ///////////////////////////////////////

                //FIND OUT OUR FILE NAME
                System.IO.FileInfo fi = new System.IO.FileInfo(args[0]);
                string parsedFileName = fi.Name.Substring(0, fi.Name.Length - 3) + "obj";
                string parsedFileNameMTL = fi.Name.Substring(0, fi.Name.Length - 3) + "mtl";
                string parsedFileNameRAW = fi.Name.Substring(0, fi.Name.Length - 4) ;

                sb.AppendLine("mtllib " + parsedFileNameMTL);
                foreach (VERTEX vx in vertList)
                {
                    sb.AppendLine("v " + vx.vx + " " + vx.vy + " " + vx.vz);
                    sb.AppendLine("vn " + vx.nx + " " + vx.ny + " " + vx.nz);
                    sb.AppendLine("vt " + vx.u + " " + vx.v);
                }
                sb.AppendLine();
                sb.AppendLine("usemtl ripmtl");
                sb.AppendLine("g " + parsedFileNameRAW);
                sb.AppendLine();

                foreach(FACE fc in faceList)
                {
                    int fid0 = (fc.i0 + 1);
                    string fstr0 = fid0 + "/" + fid0 + "/" + fid0;

                    int fid1 = (fc.i1 + 1);
                    string fstr1 = fid1 + "/" + fid1 + "/" + fid1;

                    int fid2 = (fc.i2 + 1);
                    string fstr2 = fid2 + "/" + fid2 + "/" + fid2;
                    sb.AppendLine("f " + fstr0 + " " + fstr1  + " " + fstr2 );
                }

                //BUILD MTL FILE
                if (texFiles.Count > 0)
                {
                    string mtlfile = "newmtl ripmtl\nmap_Kd " + texFiles[0];
                    //WRITE MTL FILE
                    System.IO.File.WriteAllText(parsedFileNameMTL, mtlfile);
                }

                //WRITE OBJ FILE
                System.IO.File.WriteAllText(parsedFileName, sb.ToString());

                //DONE!
                Console.WriteLine("Conversion complete!");
                stop(silentMode );
            }
            else
            {
                Console.WriteLine("file does not exist : " + args[0]);
                stop(silentMode);
            }
        }
    }
}
