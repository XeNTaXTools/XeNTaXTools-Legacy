import struct
import sys

if len(sys.argv) < 3:
	print("usage: python %s <filepath> <bone_data_address> [bone_map_table_address]"%sys.argv[0])
	print("     bone_data_address      -- the address of the bone data section including the anterior count")
	print("     bone_map_table_address -- the address of the bone map table including the anterior count")
	print("     both addresses are in hex form, if not specified, bone_map_table_address is assumed to be 0x3E")
	exit(0)

def readUInt32(file):
	data=file.read(4)
	return struct.unpack('<I',data)[0]

bone_data_address=int(sys.argv[2],base=16)
bone_map_table_address=0x3E
if len(sys.argv) == 4:
	bone_map_table_address=int(sys.argv[3],base=16)
with open(sys.argv[1], 'rb') as file:
	file.seek(bone_map_table_address)
	print('bone_map_table_address %x'%bone_map_table_address)
	usedBoneCnt=readUInt32(file)
	boneMap=[0]*usedBoneCnt
	print('used boneCnt %x'%usedBoneCnt)
	for i in range(usedBoneCnt):
		boneMap[i]=readUInt32(file)
	file.seek(bone_data_address)
	print('bone_data_address %x'%bone_data_address)
	boneCnt=readUInt32(file)
	print('boneCnt %x'%boneCnt)
	lookUpDict=dict()
	for i in range(boneCnt):
		boneUID=readUInt32(file)
		file.seek(0x40, 1)
		lookUpDict[boneUID]=i
	literal=''
	for i in range(usedBoneCnt):
		literal+='%d'%lookUpDict[boneMap[i]]
		if i + 1 < usedBoneCnt:
			literal+=','
	print("result:")
	print(literal)
	file.close()


	
