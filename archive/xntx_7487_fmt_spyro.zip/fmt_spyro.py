# Spyro: The Eternal Night (PS2)
# Noesis script by Dave, 2021

from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Spyro: The Eternal Night",".mdg")
	noesis.setHandlerTypeCheck(handle, bcCheckType)
	noesis.setHandlerLoadModel(handle, bcLoadModel)
	return 1

# Check file type

def bcCheckType(data):
	bs = NoeBitStream(data)

	file_id = bs.readBytes(4).decode("utf-8")

	if file_id == "MDG3":
		return 1
	else:
		return 0


# Read the model data

def bcLoadModel(data, mdlList):
	bs = NoeBitStream(data)
	ctx = rapi.rpgCreateContext()

	curr_folder = rapi.getDirForFilePath(rapi.getInputName()).lower()
	curr_file = rapi.getLocalFileName(rapi.getInputName()).lower()

	offset = 0x28
	misc1 = 0
	file_end = len(data)
	bs.seek(offset)

	while misc1 == 0:
		if offset == file_end:
			break

		block_value = bs.readUInt()

		if block_value == 0x6c028000:
			vert_count = bs.readUInt()
			junk = bs.readBytes(36)
			vertices = bs.readBytes(vert_count * 12)
			rapi.rpgBindPositionBuffer(vertices, noesis.RPGEODATA_FLOAT, 12)
			rapi.rpgCommitTriangles(None, noesis.RPGEODATA_USHORT, vert_count, noesis.RPGEO_TRIANGLE_STRIP, 1)

		offset = bs.tell()

	mdl = rapi.rpgConstructModel()
	mdlList.append(mdl)


	return 1


