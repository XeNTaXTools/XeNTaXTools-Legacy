Requirements:
*Java Runtime Environment (JRE) -> http://www.oracle.com/technetwork/java/javase/downloads/index.html
*PATH and CLASSPATH must be set -> http://docs.oracle.com/javase/tutorial/essential/environment/paths.html
*the extractor and the file you want to extract (e.g. Matrix.ftx) must be in the same directory

Usage:
double-click extract_Matrix.ftx.bat

if you want to extract other .ftx files, edit the filenames inside the .bat
please note that the extracted bitmap will be upside-down. open it with MS Paint and mirror it vertically.

