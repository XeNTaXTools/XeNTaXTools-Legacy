#include "StdAfx.h"

int CommonUnknownHeader[6]={
	0,
	-2,
	20,
	1,
	0,
	1};

PB_READER::PB_READER()
{
};
void PB_READER::Read(char *FileName,PB_FILE *PBFile)
{
	FILE *f=fopen(FileName,"rb");
	if (!f)
		return;	
	fread(&PBFile->Header,sizeof(PB_HEADER),1,f);
	//fread(&PBFile.TextureHeader[0],sizeof(TMX_HEADER),1,f);	

	//33984
	int RealDataStart = 64;
	if (memcmp(PBFile->Header.CommonUnknown, CommonUnknownHeader, sizeof(CommonUnknownHeader) ) != 0)
	{		
		CommonUnknownHeader[0]=0;
	}
	if (strcmp(PBFile->Header.Tex.TXP0,"TXP0")==0)
	{
		for(int y=0; y < PBFile->Header.Tex.NrTextures; y++)
		{
			int index = PBFile->Header.Tex.Texture[y] + 64;
			int real_size = -1;
			if (y < PBFile->Header.Tex.NrTextures-1)
			{
				real_size = PBFile->Header.Tex.Texture[y+1] - PBFile->Header.Tex.Texture[y];
			}
			else
				real_size = PBFile->Header.Tex.ContentSize - PBFile->Header.Tex.Texture[y];
			//Read only header
			fseek(f, index, SEEK_SET);
			fread(&PBFile->TextureHeader[ y ],sizeof(TMX_HEADER),1,f);

			//Read whole file
			fseek(f, index, SEEK_SET);
			char *buffer = new char[real_size];
			fread(buffer, real_size, 1, f);

			char TextureName[128]="";
			sprintf(TextureName,"%s_Tex%d.tmx", FileName, y);

			bool ExtractTextures = false;
			if (ExtractTextures)
			{
				SaveFile2(TextureName, buffer, real_size);
			}

			delete[]buffer;
		}

		RealDataStart = PBFile->Header.Tex.ContentSize + 64;
		
		fseek(f, RealDataStart, SEEK_SET);
		fread(&PBFile->ModelHeader, sizeof(PBFile->ModelHeader), 1, f);
	}
	else
	{
		PBFile->ModelHeader = PBFile->Header.Model;
	}	
	//MD00 = 8448
	//MT00 = 9024
	//END0 = 9216
	
	PBFile->Object= new PB_OBJECT[ PBFile->ModelHeader.NrObjects ];
	
	for(int y=0;y<PBFile->ModelHeader.NrObjects;y++)
	{
		fread(&PBFile->Object[y].Header, sizeof(PB_OBJECT_HEADER), 1,f);
	}

	for(int y=0; y<PBFile->ModelHeader.NrObjects; y++)
	if (PBFile->Object[y].Header.Uknown2[1] > 0 || PBFile->Object[y].Header.Uknown2[2] > 0)
	{
		int seek1 = RealDataStart + PBFile->Object[y].Header.Uknown2[1] + 32;
		int seek2 = RealDataStart + PBFile->Object[y].Header.Uknown2[2] + 32;
		int vectors = (seek2-seek1)/sizeof(Vector3);

		if (vectors == 2)
		{			
			fseek(f, seek1, SEEK_SET);
			fread(&PBFile->Object[y].BoundingBox, sizeof(Vector3), 2, f);
		}

		int NextChunk =-1;
		fseek(f, seek2, SEEK_SET);
		fread(&NextChunk, sizeof(int), 1, f);

		if (NextChunk > 0)
		{
			int NextChunkIndex= RealDataStart + NextChunk + 32;			
			int IntSet1[2];
			int IntSet2[3];
			fseek(f, NextChunkIndex, SEEK_SET);

			fread(IntSet1, sizeof(int), 2, f);

			NextChunkIndex =  RealDataStart + IntSet1[1] + 32;
			fseek(f, NextChunkIndex, SEEK_SET);
			fread(IntSet2, sizeof(int), 3, f);

			NextChunkIndex =  RealDataStart + IntSet2[2] + 32;

			fseek(f, NextChunkIndex, SEEK_SET);
			//ReadObject(&PBFile->Object[y],NextChunkIndex, f);

			for(int u=0;u<100000;u++)
			{				
				int index=ftell(f);
				if ( !ReadObject(&PBFile->Object[y],index, f) )
					break;
			}
		}		
	}
	fclose(f);

	#ifndef Release
		SaveToREM(FileName, PBFile);
	#endif
}

/*

Header Flags : 49152 -> 27905

Index Flags  : 49153 ->28162, 28168, 28174, 28176,

Vertex Flags : 49155 ->26628
			   49161 ->26633, 26648
			   49167 ->26666, 26639
			   49169 ->26642, 26644, 26648, 26650, 26653, 26656

TexcoordFlags: 49153-25624,			  
			   49170-25609,
			   49182-27663
	           49185-26648
			   49189-27668
			   49195-25626,               
			   49198-25629,
			   49201-25632
			   49209-27690
			   			   
Normal Flags : 49159-26628
			   49187-26642
			   
Color Flags  : 49163-28164			   
*/
bool PB_READER::ReadObject(PB_OBJECT *Obj,int start, FILE *f)
{
	fseek(f, start, SEEK_SET);

	INDICES_HEADER TempIndicesHeader;
	fread(&TempIndicesHeader, sizeof(INDICES_HEADER), 1, f);
	if (TempIndicesHeader.NumTriangles>0)
	{
		PB_DRAW_ELEMENT Elem;
		Elem.Header = TempIndicesHeader;
		
		fread(&Elem.IndexFlags, sizeof(ARRAY_FLAGS), 1, f);

		ReadArray(&Elem, f, INDEX_ARRAY);		

		fread(&Elem.VertexFlags,sizeof(ARRAY_FLAGS),1,f);

		ReadArray(&Elem, f, VERTEX_ARRAY);
		
		//Now we don't know for sure what's next
		ARRAY_FLAGS NextFlags;		
		for(int y=0;y<3;y++)
		{
			fread(&NextFlags, sizeof(ARRAY_FLAGS), 1, f);
			if (NextFlags.First==12 && NextFlags.Second==5120)
				goto finish;

			int index = ftell(f);
			FLOAT3_ELEMENT Vector;
			fread(&Vector.V, sizeof(Vector3), 1, f);			
			Vector.Evaluate();
			//And don't forget to rewind that vector read
			if (Vector.Normal && !Elem.Norms)
			{
				fseek(f, index, SEEK_SET);
				ReadArray(&Elem, f, NORMAL_ARRAY);
			}
			else if (Vector.TexCoord && !Elem.TexCoords)
			{
				fseek(f, index, SEEK_SET);
				ReadArray(&Elem, f, TEXCOORD0_ARRAY);
			}
			else
			{				
				while(!feof(f))
				{
					fseek(f, index, SEEK_SET);

					fread(&NextFlags, sizeof(ARRAY_FLAGS), 1, f);
					if (NextFlags.First==12 && NextFlags.Second==5120)
						goto finish;
					index++;
				}				

				//Stop reading elements because we didn't found a valid finish
				return false;
			}
		}		

finish:		
		Obj->DrawList.Add(&Elem);
		return true;
	}
	return false;
}
void PB_READER::ReadArray(PB_DRAW_ELEMENT *Elem, FILE *f, ARRAY_ID Array)
{
	/*bool ReadElements = false;
		FLOAT3_ELEMENT *Float3Elem=NULL;
		if (ReadElements)
		{
			Float3Elem = new FLOAT3_ELEMENT[ TempIndicesHeader.NumVertices ];
			for(int y=0; y<TempIndicesHeader.NumVertices ;y++)
			{
				fread(&Float3Elem[y].V, sizeof(Vector3), 1, f);
				Float3Elem[y].Evaluate();
			}
		}
	*/
	if (Array == VERTEX_ARRAY)
	{
		Elem->Verts = new Vector3[ Elem->Header.NumVertices ];
		fread(Elem->Verts, sizeof(Vector3), Elem->Header.NumVertices, f);
	}
	else if (Array == INDEX_ARRAY)
	{
		Elem->IndexArray=new TRI_INDEX[ Elem->Header.NumTriangles ];
		fread(Elem->IndexArray, sizeof(TRI_INDEX), Elem->Header.NumTriangles, f);
	}
	else if (Array == TEXCOORD0_ARRAY)
	{
		Elem->TexCoords = new Vector2[ Elem->Header.NumVertices ];
		fread(Elem->TexCoords, sizeof(Vector2), Elem->Header.NumVertices, f);
	}
	else if (Array == NORMAL_ARRAY)
	{
		Elem->Norms = new Vector3[ Elem->Header.NumVertices ];
		fread(Elem->Norms,sizeof(Vector3),Elem->Header.NumVertices,f);
	}
	else if (Array == COLOR_ARRAY)
	{
		Elem->Colors=new TRI_INDEX[ Elem->Header.NumVertices ];
		fread(Elem->Colors,sizeof(TRI_INDEX), Elem->Header.NumVertices, f);
	}
}
void PB_READER::SaveToREM(char *PBFilename,PB_FILE *PBFile)
{
	REM2 Rem;
	for(int y=0;y<PBFile->ModelHeader.NrObjects;y++)
	{
		for(int u=0;u<PBFile->Object[y].DrawList.nr;u++)
		{
			PB_DRAW_ELEMENT *Elem = PBFile->Object[y].DrawList[u];

			REM2OBJECT *RemObj = Rem.Object.AddEmpty();
			if (Elem->Verts)
			{
				RemObj->Attribute.AddConst( CreateVertexAttribute(VERTEX_ARRAY, 3, Elem->Header.NumVertices, "Vertex Array", Elem->Verts) );
			}
			if (Elem->IndexArray)
			{
				int TotalIndices = Elem->Header.NumTriangles * 3;
				UINT *Array = new UINT[ TotalIndices ];
				int count=0;
				for(int t=0;t<Elem->Header.NumTriangles;t++)
				{
					Array[count+0]=Elem->IndexArray[t].I1;
					Array[count+1]=Elem->IndexArray[t].I2;
					Array[count+2]=Elem->IndexArray[t].I3;

					count+=3;
				}
				RemObj->Attribute.AddConst( CreateVertexAttribute(INDEX_ARRAY, 1, TotalIndices, "Index Array", Array) );
			}
			//Default normals ?
			RemObj->Attribute.AddConst( CreateVertexAttribute(NORMAL_ARRAY, 3, Elem->Header.NumVertices, "Normal Array", Elem->Verts) );
			/*if (Elem->TexCoords)
			{
				Rem.Object.AddConst( CreateVertexAttribute(TEXCOORD0_ARRAY, 2, Elem->Header.NumVertices, "Texcoord Array", Elem->TexCoords) );
			}*/
		}
	}
	char FileName[256]="";
	sprintf(FileName,"%s.Rem",PBFilename);

	REM_ALLOCATORS::WriteRem(FileName, &Rem);
}
void PB_READER::ReadTest(int start, FILE *f, WORD *p)
{	
	fseek(f, start, SEEK_SET);
	fread(p, sizeof(WORD), 2, f);

	/*
	
	if (strcmp(FileName,"Valid Models\\007.PB") ==0)
	{
		//Next set ??
		//186344

		WORD Num[8];
		ReadTest( 200992 , f, &Num[0]);

		ReadTest( 201004 , f, &Num[2]);
		ReadTest( 201078 , f, &Num[4]);
		ReadTest( 201216 , f, &Num[6]);
		//offset - 200992 -> 49152 ; 27905 (6D01) or     1828831232
		//offset - 201004 -> 49153 ; 27654 or            1812381697
		//offset - 202268 -> 49154(C002); 27651(6C03) or 1812185090
		//offset - 206304 -> 49155; 27654(6C06)
		//offset - 226952 -> 49156  27657(6C09)
		//offset - 230940 -> 49157; 26624(6800)

		ReadFloats( 201024 , f);
		ReadFloats( 201104 , f);
		ReadFloats( 201252 , f);

		//ReadFloats( 201300 , f);
		//ReadFloats( 204092 - 4, f);
	}
	*/
}
void PB_READER::ReadFloats(int start, FILE *f)
{	
	//Normals start here
	int index =start;
	const int count = 1000;
	FLOAT3_ELEMENT Elements[count];	
	fseek(f, index, SEEK_SET);	
	for(int y=0;y<count;y++)
	{
		fread(&Elements[y].V, sizeof(Vector3), 1,f);
		Elements[y].Evaluate();		
	}	
	for(int y=0;y<count-1;y++)
	{
		if (y>0)
		{
			Vector3 N( Elements[y].V.z, Elements[y+1].V.x, Elements[y+1].V.y);
			float len = N.length();
			len = len;
			if (y>=7)
			{
				Vector3 N2( Elements[y].V.y, Elements[y].V.z, Elements[y+1].V.x);
				float len2 = N.length();
				len2 = len2;
			}
		}
		if (Elements[y].Normal == false)
		{
			y =y;
		}
	}	
}