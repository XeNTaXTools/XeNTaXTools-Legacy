
class FLOAT2_ELEMENT
{
public:
	float x;
	float y;

	bool IsTexCoord;

	void Evaluate()
	{
		if (x>0.0f && x<1.0f && y>0.0f && y<1.0f)
			IsTexCoord = true;
	}
	FLOAT2_ELEMENT()
	{
		IsTexCoord = false;
	};
};
class FLOAT3_ELEMENT
{
public:	
	int Normal:8;
	int Vertex:8;
	int TexCoord:8;

	Vector3 V;

	void Evaluate()
	{
		//if (x>0.0f && x<1.0f && y>0.0f && y<1.0f)
			//IsTexCoord = true;
		
		float len = V.length();		
		if (!_isnan(len) &&//it means we have have 3 "nice" floats
			_finite(len))
		{
			if (len >0.95f && len <1.05f)
			{
				Normal = (int)true;
			}
			else if (V.x > 0.0f && V.x < 1.0f &&
				     V.y > 0.0f && V.y < 1.0f)
			{
				TexCoord = (int)true;
			}
			else if (abs(V.x)<1000000 && abs(V.x)>0.00000001f &&
				abs(V.y)<1000000 && abs(V.y)>0.00000001f &&
				abs(V.z)<1000000 && abs(V.z)>0.00000001f)
			{
				Vertex = true; 
			}
		}
	}
	FLOAT3_ELEMENT()
	{
		Normal = (int)false;
		Vertex = (int)false;
		TexCoord = (int)false;
	}
};

class PB_TEXTURE_INDEX
{
public:
	WORD Index;
	WORD Flag;
};
class PB_TEXTURE_INDEX_UNION
{
public:
	union
	{
		int IntIndex;
		PB_TEXTURE_INDEX TexI;
	};
};
class PB_TEXTURE_HEADER
{
public:
	int  HeaderID;
	int  ContentSize;

	char TXP0[4];

	int  Uknown3;
	int  NrTextures;
	//PB_TEXTURE_INDEX_UNION  Texture[10];
	int  Texture[10];
	int  Uknown4;
};
class PB_MODEL_HEADER
{
public:
	int  HeaderID;
	int  ContentSize;

	char MD00[4];
	
	int Unknown2[3];
	int Zeros[2];
	int Unknown3[2];
	int Zero2;
	int Unknown8;
	//The next 2 vars are for convenience only
	int NrObjects;
	int Junk[3];
};

extern int CommonUnknownHeader[6];

class PB_HEADER
{
public:
	DDS_HEADER  HeaderID;
	int  ContentSize;
	char PIB0[4];
	int  CommonUnknown[6];
	int  RestUnknown[7];
	
	union
	{
		PB_TEXTURE_HEADER Tex;
		PB_MODEL_HEADER Model;
	};
};
class PB_OBJECT_HEADER
{
public:
	int Unknown[2];
	int ID;
	int Parent;

	Vector3 Vec1;
	float Zero;
	Vector3 Pos;
	Vector4 Rotation;

	int Uknown2[5];	
};
class TRI_INDEX
{
public:
	BYTE I1;
	BYTE I2;
	BYTE I3;
	BYTE Flag;
};
class ARRAY_FLAGS
{
public:
	WORD First;
	WORD Second;
};
class INDICES_HEADER
{
public:
	ARRAY_FLAGS Flag;
	WORD NumTriangles;
	WORD NumVertices;
	WORD Unknown;
	WORD NextChunk;	
};
class PB_DRAW_ELEMENT
{
public:
	INDICES_HEADER Header;

	ARRAY_FLAGS IndexFlags;	
	TRI_INDEX *IndexArray;

	ARRAY_FLAGS VertexFlags;
	Vector3 *Verts;
	
	ARRAY_FLAGS TexCoordFlags;
	Vector2 *TexCoords;		

	ARRAY_FLAGS ColorFlags;
	TRI_INDEX *Colors;

	ARRAY_FLAGS NormalFlags;
	Vector3 *Norms;

	PB_DRAW_ELEMENT()
	{
		NULL_THIS;
	}
};
class PB_OBJECT
{
public:
	PB_OBJECT_HEADER Header;

	Vector3 BoundingBox[2];

	LIST< PB_DRAW_ELEMENT > DrawList;
};
class PB_FILE
{
public:
	PB_HEADER Header;
	TMX_HEADER TextureHeader[10];

	PB_MODEL_HEADER ModelHeader;

	PB_OBJECT *Object;
};
class PB_READER
{
public:
	void Read(char *FileName, PB_FILE *PBFile);
	bool ReadObject(PB_OBJECT *Obj,int start, FILE *f);	
	void ReadArray(PB_DRAW_ELEMENT *Elem, FILE *f, ARRAY_ID Array);
	void SaveToREM(char *PBFilename,PB_FILE *PBFile);	

	PB_READER();
};