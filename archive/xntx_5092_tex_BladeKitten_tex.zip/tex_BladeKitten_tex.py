from inc_noesis import *
import os

def registerNoesisTypes():
    handle = noesis.register("Blade Kitten", ".tex")
    noesis.setHandlerTypeCheck(handle, BKCheckType)
    noesis.setHandlerLoadRGBA(handle, BKLoadRGBA)
    #noesis.logPopup()
    return 1

def BKCheckType(data):
    bs = NoeBitStream(data)
    bs.seek(len(data) - 0x30, NOESEEK_ABS)
    Magic = bs.readBytes(4).decode("ASCII")
    if Magic != "MTPC":
        return 0
    return 1   
	
def BKLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.seek(len(data) - 0x2C, NOESEEK_ABS)
    imgWidth = bs.readShort()
    imgHeight = bs.readShort()
    bs.seek(0x05, NOESEEK_REL)
    imgFmt = bs.readByte()              
    bs.seek(0)        
    #DXT1 diffuse ,normal and specular maps
    if imgFmt == 0x09:
        rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_DXT1)
        texFmt = noesis.NOESISTEX_DXT1
	#DXT5 diffuse maps
    elif imgFmt == 0x08:
        rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_DXT5)
        texFmt = noesis.NOESISTEX_DXT5
    #unknown, not handled
    else:
        print("WARNING: Unhandled image format")
        return None
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1