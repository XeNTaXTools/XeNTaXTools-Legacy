from urllib.request import ProxyHandler, build_opener, install_opener, urlretrieve
from itertools import islice
from multiprocessing.dummy import Pool as ThreadPool
import csv
import os
pool = ThreadPool(10)

if not os.path.exists("Imas2"):
    os.makedirs("Imas2")
#proxy = urllib.request.ProxyHandler({'http': 'http://192.168.1.91:8888'})
proxy = ProxyHandler({})
opener = build_opener(proxy)
opener.addheaders = [('X-Unity-Version','5.4.5p1'),('User-Agent','Dalvik/1.6.0 (Linux; U; Android 4.4.4; GT-P5210 Build/KTU84P)')]
install_opener(opener)


def geturl(file,link):
	try:
		#print(file)
		urlretrieve('http://storage.game.starlight-stage.jp/dl/resources/High/AssetBundles/Android/' + link, 'Imas2\\' + file)
		#urlretrieve('http://storage.game.starlight-stage.jp/dl/resources/High/AssetBundles/iOS/' + link, 'Imas2\\' + file)
		
	except:
		pass
def chunk(it, size):
    it = iter(it)
    return iter(lambda: tuple(islice(it, size)), ())


with open('manifests.csv', "rt" ) as theFile:
	reader = csv.DictReader( theFile )
	result = {}
	for row in reader:
		for column, value in row.items():
			result.setdefault(column, []).append(value)
	names = (list(chunk(result['name'], 100)))
	hashes = (list(chunk(result['hash'], 100)))
	for i in range(0,len(names)):
		pool.starmap(geturl, zip(names[i], hashes[i]))
		print(str(100*(i + 1)) + '/' + str(len(names) * 100))
