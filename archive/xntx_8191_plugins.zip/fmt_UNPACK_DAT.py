 #by Durik256 for xentax
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Tales of Vesperia", ".DAT")
    noesis.setHandlerExtractArc(handle, UnpackDAT)
    return 1
    
def UnpackDAT(fileName, fileLen, justChecking):
    data = rapi.loadIntoByteArray(fileName)
    
    if data[:4] != b'TLZC':
        return 0
    
    if justChecking: #it's valid
        return 1

    
    bs = NoeBitStream(data)
    bs.seek(4)#TLZC
    file_size, unpack_size = bs.readUInt(), bs.readUInt()
    
    data = rapi.decompInflate(data[24:], unpack_size)#decompress
    with open(rapi.getInputName().replace('.DAT', '.FPS4'), 'wb') as f: 
        f.write(data)

    print('Complete!')
    return 1