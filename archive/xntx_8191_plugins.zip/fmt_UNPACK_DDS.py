 #by Durik256 for xentax
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Tales of Vesperia", ".FPS4")
    noesis.setHandlerExtractArc(handle, UnpackDAT)
    return 1
    
def UnpackDAT(fileName, fileLen, justChecking):
    data = rapi.loadIntoByteArray(fileName)
    result = [(i-4) for i in findall(b'DDS', data)]
    
    if result[0] == -1:
        return 0
    
    if justChecking: #it's valid
        return 1

    
    bs = NoeBitStream(data)
    bs.setEndian(1)
    
    for x in result:
        bs.seek(x)
        export_data = bs.readBytes(bs.readUInt())
        name = 'tx_%d.DDS' % x
        rapi.exportArchiveFile(name, export_data)
        print("export", name)

    print("Extracting", len(result), "files.")
    return 1
    
def findall(p, s):
    i = s.find(p)
    while i != -1:
        yield i
        i = s.find(p, i+1)