import newGameLib
from newGameLib import *
import Blender	


	
def NVX2(nvx2_name,used_mat,matList,g): 
	global plik,vertexes,faceslist,uvcoord,mesh_data 
	name = nvx2_name.split(':') 
	print name
	nvx2_path = game_dir+os.sep+name[0]+os.sep+name[1]
	plik = open(nvx2_path, 'rb')
	print '==================nvx2'
	p=BinaryReader(plik)
	mesh_data = []
	print p.word(4)
	numobjects = p.i(1)[0]
	print 'numobjects =',numobjects
	numvertex = p.i(1)[0]
	print 'vertex =',numvertex
	type = p.i(1)[0]
	print 'type =',type
	numfaces = p.i(1)[0]
	print 'numfaces',numfaces
	p.H(1),p.B(6)
	mesh=Mesh()
	for m in range(numobjects):
		#mat = Material.New(str(model_id)+'-mat-'+str(mesh_id)) # 
		data = p.i(6)
		print data
		mesh_data.append(data)
	#print mesh_data
	vertexes  = []
	uvcoord  = []
	weighting = []
	for m in range(numvertex): 
		mesh.vertPosList.append(p.f(3))
		p.B(4)
		u = (p.H(1)[0]*2**-12)/2
		v = (p.H(1)[0]*2**-12)/2
		mesh.vertUVList.append([u,v])
		if type == 7:p.H(4)
		if type == 8:p.H(6)
		if type == 9:
			p.H(4)
			w = p.B(4)
			mesh.skinWeightList.append(w)
			#weights = Vector(w)/DotVecs(Vector(w),Vector(1.0, 1.0, 1.0, 1.0))
			#weighting.append([p.B(4),weights])  
			mesh.skinIndiceList.append(p.B(4))	
		if type == 10:
			p.H(6)
			w = p.B(4)
			#weights = Vector(w)/DotVecs(Vector(w),Vector(1.0, 1.0, 1.0, 1.0))
			mesh.skinWeightList.append(w)
			#weighting.append([p.B(4),weights]) 
			mesh.skinIndiceList.append(p.B(4))	
	faceslist = []
	for m in range(numfaces): 
		data = p.H(3)
		mesh.faceList.append(data)
	"""drawmesh(str(model_id)+'-model',used_mat)#-'+str(object_id))"""
	#mesh.update()
	for m in range(len(used_mat)):
		for mesh_id in range(len(used_mat[m])): 
			id = used_mat[m][mesh_id][1]   
			data  = mesh_data[id] 
			mat=Mat()
			mat.diffuse=matList[m].diffuse
			mat.IDStart=data[2]
			mat.IDCount=data[3]
			mesh.matList.append(mat)
	skin=Skin()
	mesh.skinList.append(skin)	
	mesh.draw()
	Blender.Window.RedrawAll()
	#for id in range(numobjects):
	#   mat = Material.Get(str(model_id)+'-mat-'+str(id)) # 
	#   mesh.materials+=[mat] 
				
	plik.close()
	#plik = open(filename, 'rb')



def HSMS(list,g):
	nvx2_name = g.word(g.H(1)[0])
	list['nvx2'] = nvx2_name


def DHSS(g):
	g.word(g.H(1)[0])


def IRGS(g):
	g.i(1)[0]


def RFGB(g):
	g.i(1)[0]

def IGFS(list,g):
	unk = g.i(1)[0]
	id = g.i(1)[0]
	list['IGFS'].append([unk,id])
   
	
def PJGB(g):
	g.i(2)
	
	
def DIJS(g):
	g.i(8)
	
	
def BCLS(g):
	g.f(6)

def TXTS(list,g):
	tex_type = g.word(g.H(1)[0])
	tex_name = g.word(g.H(1)[0])
	list['TXTS'].append([tex_type,tex_name])

def NSMS(g):
	global mat
	name = g.word(g.H(1)[0])#;print name

def nskinshapenode(n,g):
	list = {}
	list['TXTS']=[]
	list['IGFS']=[] 
	while(True):
		name = g.word(4)
		seek = g.H(1)[0]
		#print '-'*n,'nskinshapenode',name,seek
		back = g.tell() 
		if name == 'HSMS':HSMS(list,g)
		if name == 'TXTS':TXTS(list,g)	
		if name == 'NSMS':NSMS(g)   
		if name == 'DHSS':DHSS(g)  
		if name == 'IRGS':IRGS(g)
		if name == 'IGFS':IGFS(list,g)
		if name == 'PJGB':PJGB(g)#weights
		if name == 'DIJS':DIJS(g)#weights
		if name == 'RFGB':RFGB(g)
		if name == 'BCLS':BCLS(g)
		g.seek(back+seek)
		if name == 'les_':
			n-=4
			#print '-'*n,name
			break
	return n,list

def ntransformnode(n,list,g):
	type = ''
	while(True):
		name = g.word(4)#;print '-'*n,name
		if name == 'wen_':
			#print '-'*n,name
			type = g.word(g.H(1)[0])#;print '-'*n,type
			type_name = g.word(g.H(1)[0])#;print '-'*n,type_name
			n+=4
		else:
			seek = g.H(1)[0]#;print seek
			g.seek(seek,1)
		if name == 'les_':
			n-=4 
			#print '-'*n,name
			break
		if type == 'ntransformnode':
			list[type_name] = {}
			list[type_name]['nskinshapenode'] = []   
			list[type_name]['ncharacter3skinshapenode'] = [] 
			list = list[type_name]
			n = ntransformnode(n,list,g)
			type = ''
		if type == 'nskinshapenode':
			data = nskinshapenode(n,g)
			list['nskinshapenode'].append(data[1])
			type = ''
			n=data[0]
		if type == 'nshapenode':
			data = nskinshapenode(n,g)
			ch_list['3skin'].append(data[1]) 
			type = ''
			n=data[0] 
			#data = nskinshapenode(n)
			#character_list['nshapenode'].append(data[1])
			#type = ''
			#n=data[0]
			#n-=4 
		if type == 'ncharacter3skinshapenode':
			data = nskinshapenode(n,g)
			ch_list['3skin'].append(data[1]) 
			type = ''
			n=data[0] 
	return n
	
class Character:
	def __init__(self):
		self.type=None
	
class N2:
	def __init__(self):
		self.connection={}
		self.characterList=[]
		self.character_list = {}

def n2Parser(filename,g):
	NVX2_LIST = []
	
	n=0
	type = ''
	mat_id = 0
	object_id = 0
	#ntransformnode = {}
	connection = n2.connection
	n2.character_list['nshapenode']=[]
	static_list = []
	while(True):
		if g.tell() == g.fileSize():break
		name = g.word(4)#;print '-'*n,name
		if name == 'wen_':
			#print '-'*n,name
			type = g.word(g.H(1)[0])#;print '-'*n,type
			type_name = Blender.sys.basename(filename).split('.')[0]+'-'+g.word(g.H(1)[0])#;print '-'*n,type_name
			n2.character_list[type_name] = {}
			#character_list[type_name]['type'] = type
			n2.character_list[type_name]['3skin'] = [] 
			n2.character_list[type_name]['static'] = [] 
			global ch_list
			ch_list = n2.character_list[type_name]
			#if type
			n+=4
		else:
			seek = g.H(1)[0]#;print seek
			g.seek(seek,1)
		if name == 'les_':
			n-=4
		if type == 'ntransformnode':
			connection[type_name] = {} 
			connection[type_name]['nskinshapenode'] = []   
			list = connection[type_name]			
			n = ntransformnode(n,list,g)
			type = ''
			object_id+=1
			#n-=4
		if type == 'nskinshapenode':
			data = nskinshapenode(n,g)
			list['nskinshapenode'].append(data[1])
			type = ''
			n=data[0] 

def n2Draw(filename,g): 
	modelDir=g.dirname+os.sep+g.basename
	if os.path.exists(modelDir)==False:
		os.makedirs(modelDir)
	for key in n2.character_list:
		new=open(modelDir+os.sep+key+'.model','wb')
		new.close()
			
	for key1 in n2.connection:
		data1 = n2.connection[key1]#;print key1,data1
		data2 = data1['nskinshapenode']
		used_mat = []
		matList=[]
		for m in range(len(data2)):
			#print m
			mat = Mat()#Material.New(str(model_id)+'-mat-'+str(m))		
			matList.append(mat)	
			used_mat.append(data2[m]['IGFS'])
			for tex_type,tex_name in data2[m]['TXTS']:
				#print tex_type,tex_name 
				if tex_type == 'DiffMap0':
					name = tex_name.split(':') 
					mat.diffuse=game_dir+os.sep+name[0]+os.sep+name[1]
					#print mat.diffuse
		nvx2_list = []
		for m in range(len(data2)):
			nvx2_name = data2[m]['nvx2']
			if nvx2_name not in nvx2_list:
				nvx2_list.append(nvx2_name)
		if len(nvx2_list) == 1:
			  NVX2(nvx2_name,used_mat,matList,g)   

def modelDraw(filename,g):
		#for key in n2.character_list:
		#	print key
		model=filename.split(os.sep)[-1].split('.')[0]
		data1 = n2.character_list[model]
		data2 = data1['3skin']
		used_mat = []
		matList=[]
		for m in range(len(data2)):
			#print m
			mat = Mat()#Material.New(str(model_id)+'-mat-'+str(m))   
			matList.append(mat)
			if len(data2[m]['IGFS'])>0:  
				used_mat.append(data2[m]['IGFS'])
			else:
				  used_mat.append([[0,m]]) 
			for tex_type,tex_name in data2[m]['TXTS']:
				if tex_type == 'DiffMap0':
					name = tex_name.split(':') 
					mat.diffuse=game_dir+os.sep+name[0]+os.sep+name[1]
					#print mat.diffuse
					
		nvx2_list = []
		for m in range(len(data2)):
			nvx2_name = data2[m]['nvx2']
			if nvx2_name not in nvx2_list:
				nvx2_list.append(nvx2_name)
		if len(nvx2_list) == 1:
			  NVX2(nvx2_name,used_mat,matList,g)   

  
	
def Parser(filename):
	global game_dir	
	global n2
	n2=N2()
	#filename=input.filename
	game_dir = filename.split('gfxlib')[0]
	ext=filename.split('.')[-1].lower()	
	#print ext
	if ext=='n2':
		file=open(filename,'rb')
		g=BinaryReader(file)
		n2Parser(filename,g)
		n2Draw(filename,g)
		file.close()
	
	if ext=='model':	
		splits=filename.split(os.sep)
		n2File=filename.split(splits[-2])[0]+os.sep+splits[-2]+'.n2'
		#print n2File
		if os.path.exists(n2File)==True:
			file=open(n2File,'rb')
			g=BinaryReader(file)
			n2Parser(n2File,g)
			modelDraw(filename,g)
			file.close()
		
 
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()

	
Blender.Window.FileSelector(Parser,'import','Drakensang files: *.n2 - list of body parts, *.model - single body part') 
	