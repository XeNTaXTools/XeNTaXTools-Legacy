﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Watch_Dogs
{
    //modified DerPlaya's forgelib code for these
    class LocFile
    {
        private class CompressedStringFragment
        {
            private ushort rightIndexOrChar; // if LeftIndex == 0  => value is char, else value is index
            private ushort leftIndex;

            private string rightValue = null;
            private string leftValue = null;

            public string Value;

            public CompressedStringFragment()
            {

            }

            public CompressedStringFragment(BinaryReader r)
            {
                Read(r);
            }

            public void Read(BinaryReader r)
            {
                rightIndexOrChar = r.ReadUInt16();
                leftIndex = r.ReadUInt16();
            }

            public void Resolve(CompressedStringFragment[] list)
            {
                if (Value == null) Value = resolveString(list);
            }

            private string resolveString(CompressedStringFragment[] list)
            {
                // linked list index == 0
                if (leftIndex == 0 && rightIndexOrChar == 0) return "";

                // is character
                if (leftIndex == 0) return Encoding.Unicode.GetString(BitConverter.GetBytes(rightIndexOrChar));

                // is linked list element
                if (rightValue == null && rightIndexOrChar >= 0 && rightIndexOrChar < list.Length)
                {
                    list[rightIndexOrChar].Resolve(list);
                    rightValue = list[rightIndexOrChar].Value;
                }
                if (leftValue == null && leftIndex >= 0 && leftIndex < list.Length)
                {
                    list[leftIndex].Resolve(list);
                    leftValue = list[leftIndex].Value;
                }

                return leftValue + rightValue;
            }

            public override string ToString()
            {
                return Value;
            }
        }
        private uint maxStringFragmentIndex;
        private int stringFragmentIndexMask;
        public LocFile(BinaryReader r)
        {
            uint magic = r.ReadUInt32();
            ushort langCode = r.ReadUInt16();
            ushort count1 = r.ReadUInt16();
            uint fragsOffset = r.ReadUInt32();
            r.BaseStream.Position = fragsOffset;
            Read(r);
            StringBuilder sbFrags = new StringBuilder();
            foreach (var sf in stringFragments)
            {
                sbFrags.Append("\"");
                sbFrags.Append(sf.Value.Replace("\n", "{\\n}"));
                sbFrags.AppendLine("\"");
            }
            File.WriteAllText("STRING_FRAGMENTS.txt", sbFrags.ToString(), Encoding.UTF8);
            sbFrags.Clear();

            //try this as start position
            r.BaseStream.Position = 12 + 8 * count1;
            int consumed = 0;
            int tryConsumingThatManyBytes = 600;
            string text = decodeString(r, stringFragments, tryConsumingThatManyBytes, ref consumed);
            File.WriteAllText("TEXTS.txt", text, Encoding.UTF8);
        }
        CompressedStringFragment[] stringFragments;
        public void Read(BinaryReader r)
        {
            uint numStringFrags = r.ReadUInt32();
            maxStringFragmentIndex = Math.Min(254,numStringFrags);
            stringFragmentIndexMask = (int)numStringFrags * 255;
            stringFragments = new CompressedStringFragment[numStringFrags];
            stringFragments[0] = new CompressedStringFragment();
            for (int i = 1; i < numStringFrags; i++)
            {
                stringFragments[i] = new CompressedStringFragment(r);
            }

            // resolve list
            for (int i = 0; i < numStringFrags; i++)
            {
                stringFragments[i].Resolve(stringFragments);
            }
        
        }

        //try 1-byte indexing
        //but this does not work on main_english, since there is many fragments
        //need more complex indexing
        private string decodeString(BinaryReader r, CompressedStringFragment[] stringFragments, int endOffset, ref int numConsumedCodes)
        {

            StringBuilder sb = new StringBuilder();

            while (numConsumedCodes < endOffset)
            {

                byte b = r.ReadByte();
                ++numConsumedCodes;
                if (b < maxStringFragmentIndex)
                {
                    sb.Append(stringFragments[b + 1].ToString());
                }
                else
                {
                    sb.Append("*[");
                    sb.Append(r.BaseStream.Position);
                    sb.Append("]*");
                }
            }
            return sb.ToString();
        }
    }
}
