﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;


namespace Watch_Dogs
{
    class Program
    {
        static void Main(string[] args)
        {
            BinaryReader loc = new BinaryReader(File.OpenRead(args[0]));

            LocFile locFile = new LocFile(loc);

            loc.Close();
        }
    }
}
