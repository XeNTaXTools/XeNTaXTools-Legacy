Dark Cloud tools
=========

LightCloud and WhiteCloud are tools to unpack and repack files from Dark Cloud (TM) and Dark Cloud (TM) 2 (Dark Chronicles in Europe) games. The tools are quite simple and they doesn't offer great features. They was written only for research purpose.

WhiteCloud unpack .DAT files, that are described by an .HD2 or an .HD3 files. The HD3 files was discovered in Dark Cloud 2. The directory that will handle the exported files has the same name of .HDx file without the extension.

LightCloud repack the files unpacked with WhiteCloud (or with any other tool) using an .HDx file. The archive will be re-created using the same extracted files from WhiteCloud. This means that if you add new files into the unpacking directory, they will be not added into the new .DAT file. The old .DAT and .HDx files will be replaced with the new one.

LightCloud and WhiteCloud was written by Luciano Ciccariello (Xeeynamo) and their source code are downloadable at http://github.com/Xeeynamo/DarkCloud
