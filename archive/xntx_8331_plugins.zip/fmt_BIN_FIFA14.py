#by Durik256
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Fifa 14(Android)", ".bin")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, LoadModel)
    return 1
       
def noepyCheckType(data):
    #bs = NoeBitStream(data)
    #if bs.readUInt() > bs.getSize():
    #    return 0
    return 1

def LoadModel(data, mdlList):
    ctx = rapi.rpgCreateContext()
    curDir = rapi.getDirForFilePath(rapi.getInputName())
    #bs = NoeBitStream(data)
    #loadSkeleton
    bones = []
    try:LoadSkeleton(bones, curDir)
    except:print("ERROR load skeleton, need skin.bin in this folder!")
    
    if data[:9] == b'tehnique_':
        result = [(i+17) for i in findall(b'resourceGeometry', data)]
        bs = NoeBitStream(data)
        for i,x in enumerate(result):
            bs.seek(x)
            name = searchString(bs)
            print(name)
            LoadObject(rapi.loadIntoByteArray(curDir+name+'.bin'), bones, curDir, i)
        
        result = [(i+12) for i in findall(b'geometry\x00\x00\x00\x00', data)]
        for i,x in enumerate(result):
            bs.seek(x+12)
            attrOfs = bs.readInt()
            bs.seek(x+attrOfs)
            size = attrOfs + len(searchString(bs))
            bs.seek(x)
            LoadObject(bs.readBytes(size), None, curDir, i)
    
    elif data[:8] == b'list_bin':
        list_bin = data.split(b'\n')
        if not bones and len(list_bin[1].split(b'='))>1:
            LoadSkeleton(bones, curDir, list_bin[1].split(b'=')[1].decode().strip())
        for i,x in enumerate(list_bin[2:]):
            try:LoadObject(rapi.loadIntoByteArray(x.decode().strip()), bones, rapi.getDirForFilePath(x.decode().strip()), i)
            except:pass
    else:
        if len(data)<200:
            LoadObject(data, bones, curDir)
    
    try:mdl = rapi.rpgConstructModel()
    except:mdl = NoeModel()
    mdl.setBones(bones)
    mdl.setModelMaterials(NoeModelMaterials([], [NoeMaterial('mat','')]))
    mdlList.append(mdl)
    return 1
    
def LoadObject(data, bones, curDir, id=0):
    bs = NoeBitStream(data)
    
    primOfs = bs.readUInt()#primitive type offset
    inum = bs.readUInt()#indices number
    itype = bs.readUInt()#?UShort
    attrOfs = bs.readUInt()#attribute offset
    unk = bs.readUInt()#(4)
    vnameOfs = bs.readUInt()#vert file name offset
    vOfs = bs.readUInt()#vert offset
    bs.seek(8,1)#unk
    inameOfs = bs.readUInt()#indices file name offset
    iOfs = bs.readUInt()#indices offset
    
    bs.seek(vnameOfs)
    vFile = searchString(bs)
    bs.seek(inameOfs)
    iFile = searchString(bs)
    
    #loadSkeleton
    #bones = []
    #try:LoadSkeleton(bones)
    #except:print("ERROR load skeleton, need skin.bin in this folder!")
    
    #open indices buffer file
    data = rapi.loadIntoByteArray(curDir+iFile+'.bin')
    ibs = NoeBitStream(data)
    
    #open vert buffer file
    data = rapi.loadIntoByteArray(curDir+vFile+'.bin')
    vbs = NoeBitStream(data)
    
    #read indices buffer
    ibs.seek(iOfs)
    ibuf = ibs.readBytes(inum*2)
    
    #calculate num vert
    ibs.seek(iOfs)
    numVert = max([ibs.readUShort() for x in range(inum)]) + 1
    print('numVert',numVert, iOfs)
    
    #calculate stride
    bs.seek(attrOfs)
    attrb = searchString(bs)
    stride = sum([int(attrb[i+6:i+7]) for i in range(0, len(attrb), 7)])*4
    
    #read vert buffer
    vbs.seek(vOfs)
    vbuf = vbs.readBytes(numVert*stride)
    #create mesh
    #ctx = rapi.rpgCreateContext()
    a = parseAttrb(attrb)
    rapi.rpgSetBoneMap([x for x in range(26)]+[5])#create bonemap for fix mouth bone(26)
    rapi.rpgSetName('mesh_%i'%id)
    rapi.rpgBindPositionBuffer(vbuf, noesis.RPGEODATA_FLOAT, stride)
    if a[2]:
        rapi.rpgBindNormalBufferOfs(vbuf, noesis.RPGEODATA_FLOAT, stride, a[2])
    if a[0]:
        rapi.rpgBindUV1BufferOfs(vbuf, noesis.RPGEODATA_FLOAT, stride, a[0])
    if a[1]:
        rapi.rpgBindUV2BufferOfs(vbuf, noesis.RPGEODATA_FLOAT, stride, a[1])
    if bones and a[3] and a[4]:
        numW = int(attrb.split('BWGH0F')[1][0])
        rapi.rpgBindBoneIndexBufferOfs(vbuf, noesis.RPGEODATA_FLOAT, stride, a[3], numW)
        rapi.rpgBindBoneWeightBufferOfs(vbuf, noesis.RPGEODATA_FLOAT, stride, a[4], numW)
    rapi.rpgCommitTriangles(ibuf, noesis.RPGEODATA_USHORT, inum, noesis.RPGEO_TRIANGLE)
    rapi.rpgSetUVScaleBias(NoeVec3([1,-1,1]),None)
    #mdl = rapi.rpgConstructModel()
    #mdl.setBones(bones)
    #mdlList.append(mdl)
    return 1

def parseAttrb(attrb):
    #0-uv1;1-uv2;2-norm;3-bi;4-bw
    a = [0]*5
    ofs = 0
    for x in [attrb[i:i+7] for i in range(0, len(attrb), 7)]:
        if 'TXTC0' in x:
            a[0] = ofs
        if 'TXTC1' in x:
            a[1] = ofs
        elif 'NORM0' in x:
            a[2] = ofs
        elif 'BIDX0' in x:
            a[3] = ofs
        elif 'BWGH0' in x:
            a[4] = ofs
        ofs += int(x[6:])*4
    return a

def searchString(bs):
    bytes = []
    byte = None
    while byte != 0:
        byte = bs.readUByte()
        bytes.append(byte)
    return noeAsciiFromBytes(bytes)

def LoadSkeleton(bones, curDir, path=None):
    if path:data = rapi.loadIntoByteArray(path)
    else:data = rapi.loadIntoByteArray(curDir+'skin.bin')
    bs = NoeBitStream(data)
    parent = [bs.readShort() for x in range(26)]
    for x in range(26):
        mat = NoeMat44.fromBytes(bs.readBytes(64)).inverse().toMat43()
        bones.append(NoeBone(x, 'bone_%i'%x, mat, None, parent[x]))
    #bones.append(NoeBone(26, 'bone_26', bones[5].getMatrix(), None, 5))#mouth bone
    return 1

def findall(p, s):
    i = s.find(p)
    while i != -1:
        yield i
        i = s.find(p, i+1)