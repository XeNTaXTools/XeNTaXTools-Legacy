#by Durik256
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Fifa 14(Android)", ".fsh;.big")
    noesis.setHandlerTypeCheck(handle, CheckType)
    noesis.setHandlerLoadRGBA(handle, LoadRGBA)
    return 1

def CheckType(data):
    if data[:4] == b'SHPI': 
        return 1
    elif data[:2] == b'EB':
        return 1
    return 0
    
def LoadRGBA(data, texList):
    if data[:2] == b'EB': 
        parseBig(data, texList)
    else:
        loadFSH(data, texList)
    return 1
    
def loadFSH(data, texList):
    bs = NoeBitStream(data)
    bs.seek(4)#SHPI
    fsize = bs.readInt()
    numtx = bs.readInt()
    bs.seek(4,1)#G359
    
    for x in range(numtx):
        name = bs.readBytes(4).decode()
        curPos = bs.getOffset() + 4
        bs.seek(bs.readInt())
        type, unk = bs.readUByte(), bs.readUInt24()
        w, h = bs.readShort(), bs.readShort()
        bs.seek(8,1)
        if type == 109:
            data = rapi.imageDecodeRaw(bs.readBytes(w*h*2), w, h, 'b4g4r4a4')
        elif type == 125:
            data = rapi.imageDecodeRaw(bs.readBytes(w*h*4), w, h, 'r8g8b8a8')
        elif type == 127:#45165
            data = rapi.imageDecodeRaw(bs.readBytes(w*h*3), w, h, 'r8g8b8')
        elif type == 120:
            data = rapi.imageDecodeRaw(bs.readBytes(w*h*2), w, h, 'b5g6r5')
        elif type == 100:
            data = rapi.imageDecodePVRTC(bs.readBytes(w*h//2), w, h, 4)
        else:
            data = rapi.imageDecodeETC(bs.readBytes(w*h//2), w, h, 'sRGB')
        
        texList.append(NoeTexture(name, w, h, data, noesis.NOESISTEX_RGBA32))
        bs.seek(curPos)
    return 1
    
def parseBig(data, texList):
    bs = NoeBitStream(data)
    bs.setEndian(1)
    bs.seek(4)#EB/ver
    files = bs.readInt()
    flag = bs.readInt()
    nameofs = bs.readInt()
    namesz = bs.readInt()
    xnamesz = bs.readByte()
    xfoldersz = bs.readByte()
    folders = bs.readShort()
    bs.seek(8+16,1)
    
    info = []
    for x in range(files):
        info.append([bs.readInt() for x in range(4)])
    
    bs.seek(nameofs)
    bs.seek(xfoldersz*folders,1)
    for x in range(files):
        name = noeStrFromBytes(bs.readBytes(xnamesz).split(b'\x00')[0])
        print(name, info[x])
        curPos = bs.getOffset()
        if os.path.splitext(name)[1].lower() == '.fsh':
            bs.seek(info[x][0]*16)
            if not info[x][1]:
                data = bs.readBytes(info[x][2])
                loadFSH(data, texList)
            #else:
                #data = rapi.decompInflate(bs.readBytes(info[x][1]), info[x][2])
                #loadFSH(data, texList)
        bs.seek(curPos)
    return 1