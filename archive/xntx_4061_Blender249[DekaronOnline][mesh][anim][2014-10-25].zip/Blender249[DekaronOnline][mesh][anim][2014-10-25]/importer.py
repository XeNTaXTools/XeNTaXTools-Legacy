import newGameLib
from newGameLib import *
import Blender



def hdrParser(filename,g):
	g.logOpen()
	g.seek(404)
	for m in range(6):
		archfile=g.word(g.i(1)[0])
		for n in range(g.i(1)[0]):
			g.word(g.i(1)[0])
		w=g.i(4)
		for n in range(w[3]):
			g.i(3)
		unp=Unpacker()	
		unp.inputFile=g.dirname+os.sep+archfile
		unp.outputDir=g.dirname+os.sep+'unpacked'
		unp.count=w[2]
		for n in range(w[2]):
			unp.nameList.append(g.word(g.i(1)[0]))
			v=g.i(5)	
			unp.offsetList.append(v[0])
			unp.sizeList.append(v[2])
		#if m==6:	
		unp.unpack()	
			
	g.debug=True
	g.tell()
	g.logClose()
	
	
def meshParser(filename,g):
	w=g.i(12)
	g.seek(w[10])
	meshCount=g.i(1)[0]
	for k in range(meshCount):
		g.f(6)
		matCount=g.i(1)[0]
		mesh=Mesh()
		mesh.TRISTRIP=True
		sumID=0
		for m in range(matCount):#materials	
			v=g.i(5)	
			mesh.indiceList.extend(g.H(v[4]))
			mat=Mat()
			
			
			mat.TRISTRIP=True
			mat.IDStart=sumID
			mat.IDCount=v[4]
			mat.ZTRANS=True
			mesh.matList.append(mat)
			sumID+=v[4]
			
		vertCount=g.i(1)[0]
		skin=Skin()
		for m in range(vertCount):
			t=g.tell()
			mesh.vertPosList.append(g.f(3))
			g.seek(t+24)
			mesh.vertUVList.append(g.f(2))
			g.seek(t+40)
			mesh.skinIndiceList.append(map(int,g.f(2)))
			mesh.skinWeightList.append(g.f(2))
			g.seek(t+56)
		boneCount=g.i(1)[0]	
		for m in range(boneCount):
			mesh.boneNameList.append(g.word(g.i(1)[0]))
		texID=g.i(1)[0]		
		for mat in mesh.matList:
			if len(texList)>0:
				mat.diffuse=texDir+os.sep+texList[0][1].split('"')[1]+\
				os.sep+texList[texID+1][1].split('"')[1]
		mesh.skinList.append(skin)	
		mesh.BINDSKELETON='armature'
		mesh.draw()	
		
	
def tpackParser(input):
	lines=input.readlines()
	for line in lines:
		stripLine=line.strip()
		splitLine=stripLine.split()
		texList.append(splitLine)	

def twig(parentName,g):	
	bone=Bone()
	bone.name=g.word(g.i(1)[0])
	g.word(g.i(1)[0])
	bone.posMatrix=TranslationMatrix(Vector(g.f(3)))
	bone.parentName=parentName
	q=g.f(4)
	bone.rotMatrix=Quaternion(q[3],q[0],q[1],q[2]).toMatrix().resize4x4()
	g.f(4)
	g.f(4)
	g.f(4)
	g.f(4)
	skeleton.boneList.append(bone)
	for m in range(g.i(1)[0]):
		twig(bone.name,g)

def skelParser(g):
	global skeleton
	w=g.i(8)
	g.seek(96)
	skeleton=Skeleton()
	skeleton.BONESPACE=True
	skeleton.NICE=True
	#skeleton.IK=True
	
	bone=Bone()
	bone.name=g.word(g.i(1)[0])
	g.word(g.i(1)[0])
	bone.posMatrix=TranslationMatrix(Vector(g.f(3)))
	q=g.f(4)
	matrix=Matrix(g.f(4),g.f(4),g.f(4),g.f(4))
	bone.rotMatrix=Quaternion(q[3],q[0],q[1],q[2]).toMatrix().resize4x4()*matrix.invert()
	skeleton.boneList.append(bone)
	for m in range(g.i(1)[0]):
		twig(bone.name,g)
		
	skeleton.draw()	
	
		
def animParser(g):
	g.logOpen()
	#g.debug=True
	g.i(10)
	g.seek(104)
	boneCount=g.i(1)[0]
	action=Action()
	action.BONESPACE=True
	action.BONESORT=True
	action.name=g.basename
	for k in range(boneCount):
		bone=ActionBone()
		bone.name=g.word(g.i(1)[0])
		w=g.i(2)
		for m in range(w[1]):
			bone.posFrameList.append(int(g.f(1)[0]*60))
			bone.posKeyList.append(TranslationMatrix(Vector(g.f(3))))
		w=g.i(2)
		for m in range(w[1]):
			bone.rotFrameList.append(int(g.f(1)[0]*60))
			q=g.f(4)
			bone.rotKeyList.append(Quaternion(q[3],q[0],q[1],q[2]).toMatrix().resize4x4())
		w=g.i(2)
		for m in range(w[1]):
			g.f(1)
			matrix=Matrix(g.f(4),g.f(4),g.f(4),g.f(4))
		#print matrix,g.tell()
		action.boneList.append(bone)	
	
	
	g.tell()
	g.logClose()
	action.draw()
	action.setContext()
			
			
			
def Parser():
	filename=input.filename
	imageList=input.imageList
	print
	print filename
	print
	global texList,texDir
	ext=filename.split('.')[-1].lower()
	
	texList=[]
	texDir=None
	if ext=='hdr':
		file=open(filename,'rb')
		g=BinaryReader(file)
		hdrParser(filename,g)
		file.close()
	
	
	if ext=='mesh':
		split=filename.lower().split('mesh')
		tpackFile=split[0]+os.sep+'texturepack'+os.sep+split[1]+'tpack'
		texDir=split[0]+os.sep+'texture'
		if os.path.exists(texDir):			
			if os.path.exists(tpackFile):			
				file=open(tpackFile,'r')
				tpackParser(file)
				file.close()
			else:	
				print 'WARNING: no tpackFile',tpackFile
		else:
			print 'WARNING: no texDir',texDir
		skelFile=split[0]+os.sep+'skel'+os.sep+split[1]+'skel'	
		print skelFile		
		if os.path.exists(skelFile):
			file=open(skelFile,'rb')
			g=BinaryReader(file)
			skelParser(g)
			file.close()
		else:	
			print 'WARNING: no skelFile',skelFile
		
		
		file=open(filename,'rb')
		g=BinaryReader(file)
		meshParser(filename,g)
		file.close()
		
	if ext=='skel':
		file=open(filename,'rb')
		g=BinaryReader(file)
		skelParser(g)
		file.close()
		
	if ext=='anim':
		file=open(filename,'rb')
		g=BinaryReader(file)
		animParser(g)
		file.close()
		
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()

Blender.Window.FileSelector(openFile,'import','mesh - skinned mesh,skel - skeleton, anim - animation, hdr - archive') 	