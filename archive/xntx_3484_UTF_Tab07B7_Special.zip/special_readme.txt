This is a special build for UNION.CPK which has a sparsely populated ITOC.
