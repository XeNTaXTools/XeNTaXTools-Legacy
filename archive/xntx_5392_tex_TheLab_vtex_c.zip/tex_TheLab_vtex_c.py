from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("The Lab", ".vtex_c")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    bs.seek(0x10, NOESEEK_ABS)
    Magic = bs.readBytes(4).decode("ASCII")
    if Magic != 'REDI':
        return 0
    return 1
	
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.seek(0x20, NOESEEK_ABS)
    headOff = bs.readUInt()
    bs.seek(headOff + 0x10, NOESEEK_REL)
    print(hex(bs.tell()), "1")
    imgWidth = bs.readUShort()            
    print(imgWidth, "imgwidth")
    imgHeight = bs.readUShort()           
    print(imgHeight, "imgheight")
    skip = bs.readUShort()              
    imgFmt = bs.readUByte()
    print(imgFmt, "imgfmt")
    end = len(data)
    #DXT1
    if imgFmt == 1:
        datasize = ((imgWidth * imgHeight) * 4) // 8
        print(datasize, "DXT1 datasize")
        bs.seek(end - datasize, NOESEEK_ABS)        
        print(hex(bs.tell()), "2")
        data = bs.readBytes(datasize)      
        texFmt = noesis.NOESISTEX_DXT1
    #DXT5
    elif imgFmt == 2:
        datasize = ((imgWidth * imgHeight) * 8) // 8
        print(datasize, "DXT5 datasize")
        bs.seek(end - datasize, NOESEEK_ABS)        
        print(hex(bs.tell()), "2")
        data = bs.readBytes(datasize)      
        texFmt = noesis.NOESISTEX_DXT5
    #RGBA32
    elif imgFmt == 4:
        datasize = ((imgWidth * imgHeight) * 32) // 8
        print(datasize, "RGBA32 datasize")
        bs.seek(end - datasize, NOESEEK_ABS)        
        print(hex(bs.tell()), "2")
        data = bs.readBytes(datasize)      
        data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "r8 g8 b8 a8")
        texFmt = noesis.NOESISTEX_RGBA32
    #mostly cube maps, source says: VTEX_FORMAT_RGBA16161616F
    elif imgFmt == 10:
        #pass
        datasize = ((imgWidth * imgHeight) * 64) // 8
        print(datasize, "RGBA48 datasize")
        bs.seek(end - datasize, NOESEEK_ABS)        
        print(hex(bs.tell()), "2")
        data = bs.readBytes(datasize)      
        data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "r16 g16 b16 a16")
        texFmt = noesis.NOESISTEX_RGBA32
    else:
        print("WARNING: Unhandled image format")
        return None
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1