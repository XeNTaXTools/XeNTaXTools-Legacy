from urllib.request import ProxyHandler, build_opener, install_opener, urlretrieve
import lz4
from itertools import islice
from multiprocessing.dummy import Pool as ThreadPool
import os
import struct
import json


pool = ThreadPool(100)

if not os.path.exists("ARGirlsTrinary"):
	os.makedirs("ARGirlsTrinary")
	manifestURL = 'https://d00030400.gamecity.ne.jp/a_girl/master-android/kakutora_files_crc.json'
	urlretrieve(manifestURL, 'ARGirlsTrinary\\' + 'kakutora_files_crc.json')


	
def geturl(link,file):
	try:
		pass
		#print(file,link)
		#baseDir = '\\'.join((file).split('_')[0:-1]) + '\\'
		#if not os.path.exists('MillionLive\\' + baseDir):
		#	os.makedirs('MillionLive\\' + baseDir)
		urlretrieve(link, 'ARGirlsTrinary\\' + file)
		print('ARGirlsTrinary\\' + file)
	except:
		pass

with open('ARGirlsTrinary\\' + 'kakutora_files_crc.json', "rb" ) as f:
	fileName = []
	urlLink = []
	baseURL = 'https://d00030400.gamecity.ne.jp/a_girl/master-android/'
	data = json.load(f)
	for i in data:
		if 'assetBundle' in i:
			fn, fe = os.path.splitext(i['assetBundle'])
			fileURL = baseURL + fn + '@' + format(i['crc'], 'x').upper() + fe

			fileName.append(i['assetBundle'])
			urlLink.append(fileURL)
			#print(fileURL)

	pool.starmap(geturl, zip(urlLink,fileName) )	
	



