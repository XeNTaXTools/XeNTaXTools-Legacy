#2011-05-22 Glogow Poland Mariusz Szkaradek

import bpy,struct,os
import Blender
from Blender import *
from Blender.Mathutils import *


def vertexuv():
    mesh.vertexUV = 1
    for m in range(len(mesh.verts)):
        mesh.verts[m].uvco = Vector(uv_list[m])
    mesh.update() 
    mesh.faceUV = 1
    for fc in mesh.faces: fc.uv = [v.uvco for v in fc.verts];fc.smooth = 1;fc.mat = mat_id_list[fc.index]
    mesh.update()   


def b(n):
    return struct.unpack(n*'b', plik.read(n))
def B(n):
    return struct.unpack(n*'B', plik.read(n))
def h(n):
    return struct.unpack(n*'h', plik.read(n*2))
def H(n):
    return struct.unpack(n*'H', plik.read(n*2))
def i(n):
    return struct.unpack(n*'i', plik.read(n*4))
def f(n):
    return struct.unpack(n*'f', plik.read(n*4))

def word(long): 
   s=''
   for j in range(0,long): 
       lit =  struct.unpack('c',plik.read(1))[0]
       if ord(lit)!=0:
           s+=lit
           if len(s)>300:
               break
   return s


def drawmesh(name): 
    global obj,mesh
    mesh = bpy.data.meshes.new(name)
    mesh.verts.extend(vertices_list)
    mesh.faces.extend(faces_list,ignoreDups=True)
    for m in range(nMat):
        mesh.materials+=[Material.Get('mat-'+str(m))]
    if len(uv_list)!=0:
        vertexuv()
    scene = bpy.data.scenes.active
    obj = scene.objects.new(mesh,name)
    mesh.recalcNormals()
    mesh.update()
    Redraw()

def MOEG():
    global vertices_list,faces_list,uv_list,nMat,mat_id_list
    vertices_list = [];faces_list = [];uv_list = [];mat_id_list = []
    H(1);nMat = i(1)[0]
    #MATERIALS
    for m in range(nMat):
        Material.New('mat-'+str(m))    
        i(1)[0]
        word(4)
        seek = i(1)[0]
        back = plik.tell()
        plik.seek(back+seek)
        i(1)[0]
        word(4)
    #GEOMETRY
    ##VERTICES
    nVerts = i(1)[0]
    vert_type = H(1)[0];print vert_type
    if vert_type == 655:vert_size = 52
    if vert_type == 799:vert_size = 64
    for m in range(nVerts):
        back = plik.tell()
        vertices_list.append(f(3))
        if vert_type==799:
            f(6)
        if vert_type==655:
            f(7)
        uv_list.append([f(1)[0],1-f(1)[0]])
        plik.seek(back+vert_size)
    ##FACES 
    nFaces = i(1)[0]
    for m in range(nFaces):
        faces_list.append(i(3))
        mat_id_list.append(H(1)[0])
    #SHOW MODEL 
    drawmesh('model')


def model():    
    word(4);H(4);word(4);i(1)[0];H(1)
    while(True):
        stop = i(1)[0]
        if stop == 0:break
        name = word(4);seek = i(1)[0];back = plik.tell()
        if name == 'MOEG': MOEG()
        plik.seek(back+seek);i(1)[0];word(4)


def openfile(filename):
    global plik
    plik = open(filename,'rb')
    print '============================'
    print filename
    print '============================'
    model()

Window.FileSelector (openfile)