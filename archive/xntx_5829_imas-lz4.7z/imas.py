from urllib.request import ProxyHandler, build_opener, install_opener, urlopen
import lz4
from itertools import islice
from multiprocessing.dummy import Pool as ThreadPool
import csv
import os
import struct

pool = ThreadPool(100)

if not os.path.exists("Imas2"):
    os.makedirs("Imas2")
#proxy = urllib.request.ProxyHandler({'http': 'http://192.168.1.91:8888'})
proxy = ProxyHandler({})
opener = build_opener(proxy)
opener.addheaders = [('X-Unity-Version','5.4.5p1'),('User-Agent','Dalvik/1.6.0 (Linux; U; Android 4.4.4; GT-P5210 Build/KTU84P)')]
install_opener(opener)



def geturl(file,link):
	try:
		#print(file)
		#myFile = urlopen('http://storage.game.starlight-stage.jp/dl/resources/High/AssetBundles/Android/' + link).read()
		myFile = urlopen('http://storage.game.starlight-stage.jp/dl/resources/High/AssetBundles/iOS/' + link).read()
		#print(myFile[18:25])
		size,zsize = struct.unpack('2I', myFile[4:12])
		myArr = lz4.block.decompress(myFile[16:],size)
		with open('Imas2\\' + file, 'wb') as f:
			f.write(myArr)
		
	except:
		pass
def chunk(it, size):
    it = iter(it)
    return iter(lambda: tuple(islice(it, size)), ())


with open('manifests-ios.csv', "rt" ) as theFile:
	reader = csv.DictReader( theFile )
	result = {}
	for row in reader:
		for column, value in row.items():
			result.setdefault(column, []).append(value)
	names = (list(chunk(result['name'], 100)))
	hashes = (list(chunk(result['hash'], 100)))
	for i in range(0,len(names)):
		pool.starmap(geturl, zip(names[i], hashes[i]))
		print(str(100*(i + 1)) + '/' + str(len(names) * 100))
