from sys import *
from binascii import *
import os

##########################################################################
''' def swzdxt1  '''
##########################################################################
def swzdxt1(width,height,raw):
	fin = open(raw,'rb')
	
	fout = open(raw+'_swizzled.dds','ab')
	
	header = fin.read(128)
	fout.write(header)

	size = width * height / 4

	offset1, offset2, offset3, offset4, offset5, offset6, x = 0,0,0,0,0,0,128 
	rbuff = [0 for j in range(0x10)]
	for n in range(height/(4*4)):
		for m in range(width/0x80):
			for l in range(2):
				for k in range(4):
					for j in range(2):
						offset = offset1+offset2+offset3+offset4+offset5+offset6
						for i in range(0,0xD,4):
							fin.seek(0x10*(i+offset)+x,0)
							rbuff[i] = fin.read(0x10)
						for i in range(2,0xF,4):
							fin.seek(0x10*(i-1+offset)+x,0)
							rbuff[i] = fin.read(0x10)
						for i in range(1,0xE,4):
							fin.seek(0x10*(i-1+offset+width/8)+x,0)
							rbuff[i] = fin.read(0x10)
						for i in range(3,0x10,4):
							fin.seek(0x10*(i-2+offset+width/8)+x,0)
							rbuff[i] = fin.read(0x10)
						for i in range(0x10):
							fout.write(rbuff[i])
					
						offset1 = 2
					
					offset1 = 0
					offset2 += width/4
				
				offset2 = 0
				offset3 = width*2
				
			offset3 = 0
			offset4 = width
			
			for l in range(2):
				for k in range(4):
					for j in range(2):
						offset = offset1+offset2+offset3+offset4+offset5+offset6
						for i in range(0,0x5,4):
							fin.seek(0x10*(i+8+offset)+x,0)
							rbuff[i] = fin.read(0x10)
						for i in range(8,0xD,4):
							fin.seek(0x10*(i-8+offset)+x,0)
							rbuff[i] = fin.read(0x10)
						for i in range(2,0x7,4):
							fin.seek(0x10*(i-1+8+offset)+x,0)
							rbuff[i] = fin.read(0x10)
						for i in range(0xA,0xF,4):
							fin.seek(0x10*(i-1-8+offset)+x,0)
							rbuff[i] = fin.read(0x10)
						for i in range(1,0x6,4):
							fin.seek(0x10*(i-1+8+offset+width/8)+x,0)
							rbuff[i] = fin.read(0x10)
						for i in range(9,0xE,4):
							fin.seek(0x10*(i-1-8+offset+width/8)+x,0)
							rbuff[i] = fin.read(0x10)
						for i in range(3,0x8,4):
							fin.seek(0x10*(i-2+8+offset+width/8)+x,0)
							rbuff[i] = fin.read(0x10)
						for i in range(0xB,0x10,4):
							fin.seek(0x10*(i-2-8+offset+width/8)+x,0)
							rbuff[i] = fin.read(0x10)
						for i in range(0x10):
							fout.write(rbuff[i])
					
						offset1 = 2
					
					offset1 = 0
					offset2 += width/4
				
				offset2 = 0
				offset3 = width*2
				
			offset3 = 0
			offset4 = 0
			offset6 += 0x10
		
		offset6 = 0
		offset5 += width*4

	fin.close
	fout.close

##########################################################################
''' def unsdxt1  '''
##########################################################################
def unsdxt1(width,height,raw):
	fin = open(raw,'rb')
	
	fout = open(raw+'_uns.dds','ab')
	
	header = fin.read(128)
	fout.write(header)

	size = width * height / 4
	if width >= 0x80:
		sections = width/0x80
	else:
		sections = 1
	if width >= 0x80:
		loop1 = 2
	else:
		loop1 = 1
	offset1, offset2, offset3, offset4, offset5, x = 0,0,0,0,0,128
	
	rbuff = [0 for j in range(0x10)]
	for n in range(height/(4*4)):
		for m in range(2):
			for l in range(4):
				for k in range(2):
					for j in range(sections):
						offset =  offset1+offset2+offset3+offset4+offset5
						for i in range(0,0x5,4):
							fin.seek(0x10*(i+offset)+x,0)
							rbuff[i] = fin.read(0x10)
						for i in range(8,0xD,4):
							fin.seek(0x10*(i+offset)+x,0)
							rbuff[i] = fin.read(0x10)
						for i in range(2,0x7,4):
							fin.seek(0x10*(i+0xE+offset)+x,0)
							rbuff[i] = fin.read(0x10)
						for i in range(0xA,0xF,4):
							fin.seek(0x10*(i+0xE+offset)+x,0)
							rbuff[i] = fin.read(0x10)
						for i in range(1,0x6,4):
							fin.seek(0x10*(i+1+offset)+x,0)
							rbuff[i] = fin.read(0x10)
						for i in range(9,0xE,4):
							fin.seek(0x10*(i+1+offset)+x,0)
							rbuff[i] = fin.read(0x10)
						for i in range(3,0x8,4):
							fin.seek(0x10*(i+0xF+offset)+x,0)
							rbuff[i] = fin.read(0x10)
						for i in range(0xB,0x10,4):
							fin.seek(0x10*(i+0xF+offset)+x,0)
							rbuff[i] = fin.read(0x10)
						for i in range(0x10):
							fout.write(rbuff[i])
						
						offset1 += 0x200
					
					offset1 = 0
					offset2 = 1
				
				offset2 = 0
				offset3 += 0x20
			
			offset4 += 0x80
			
			for l in range(4):
				for k in range(2):
					for j in range(sections):
						offset =  offset1+offset2+offset3+offset4+offset5
						for i in range(0,0x5,4):
							fin.seek(0x10*(i+8+offset)+x,0)
							rbuff[i] = fin.read(0x10)
						for i in range(8,0xD,4):
							fin.seek(0x10*(i-8+offset)+x,0)
							rbuff[i] = fin.read(0x10)
						for i in range(2,0x7,4):
							fin.seek(0x10*(i+8+0xE+offset)+x,0)
							rbuff[i] = fin.read(0x10)
						for i in range(0xA,0xF,4):
							fin.seek(0x10*(i-8+0xE+offset)+x,0)
							rbuff[i] = fin.read(0x10)
						for i in range(1,0x6,4):
							fin.seek(0x10*(i+1+8+offset)+x,0)
							rbuff[i] = fin.read(0x10)
						for i in range(9,0xE,4):
							fin.seek(0x10*(i+1-8+offset)+x,0)
							rbuff[i] = fin.read(0x10)
						for i in range(3,0x8,4):
							fin.seek(0x10*(i+8+0xF+offset)+x,0)
							rbuff[i] = fin.read(0x10)
						for i in range(0xB,0x10,4):
							fin.seek(0x10*(i-8+0xF+offset)+x,0)
							rbuff[i] = fin.read(0x10)
						for i in range(0x10):
							fout.write(rbuff[i])
						
						offset1 += 0x200
					
					offset1 = 0
					offset2 = 1
				
				offset2 = 0
				offset3 += 0x20
			
			offset3 = 0
			
		
		offset4 = 0
		offset5 += width*4
	
	fin.close
	fout.close

##########################################################################
''' def unsdxt5  '''
##########################################################################
def unsdxt5(width,height,raw):
	fin = open(raw,'rb')
	
	fout = open(raw+'_uns.dds','ab')
	
	header = fin.read(128)
	fout.write(header)

	size = width * height / 4
	if width >= 0x80:
		sections = width/0x80
	else:
		sections = 1
	offset1, offset2, offset3, offset4, offset5, offset6, offset7, x = 0,0,0,0,0,0,0,128 
	rbuff = [0 for j in range(0x10)]
	for p in range(height/(8*4)):
		for o in range(2):
			for n in range(2):
				for m in range(2):
					for l in range(2):
						for k in range(sections):
							for j in range(2):
								offset =  offset1+offset2+offset3+offset4+offset5+offset6+offset7
								for i in range(0,0x7,2):
									fin.seek(0x10*(i*0x8+offset)+x,0)
									rbuff[i] = fin.read(0x10)
								for i in range(1,0x8,2):
									fin.seek(0x10*((i-1)*0x8+2+offset)+x,0)
									rbuff[i] = fin.read(0x10)
								for i in range(8,0xF,2):
									fin.seek(0x10*((i-8)*0x8+4+offset)+x,0)
									rbuff[i] = fin.read(0x10)
								for i in range(9,0x10,2):
									fin.seek(0x10*((i-9)*0x8+6+offset)+x,0)
									rbuff[i] = fin.read(0x10)
								for i in range(0x10):
									fout.write(rbuff[i])
									
								offset1 = 8
							
							offset1 = 0
							offset2 += 0x400
						
						offset2 = 0
						offset3 = 1
					
					offset3 = 0
					offset4 = 0x40
				
				offset4 = 0
				offset5 = 0x100
			
			offset5 = 0
			
			for n in range(2):
				for m in range(2):
					for l in range(2):
						for k in range(sections):
							for j in range(2):
								offset =  offset1+offset2+offset3+offset4+offset5+offset6+offset7
								for i in range(0,0x7,2):
									fin.seek(0x10*(i*0x8+0x208+offset)+x,0)
									rbuff[i] = fin.read(0x10)
								for i in range(1,0x8,2):
									fin.seek(0x10*((i-1)*0x8+2+0x208+offset)+x,0)
									rbuff[i] = fin.read(0x10)
								for i in range(8,0xF,2):
									fin.seek(0x10*((i-8)*0x8+4+0x208+offset)+x,0)
									rbuff[i] = fin.read(0x10)
								for i in range(9,0x10,2):
									fin.seek(0x10*((i-9)*0x8+6+0x208+offset)+x,0)
									rbuff[i] = fin.read(0x10)
								for i in range(0x10):
									fout.write(rbuff[i])
								
								offset1 = -0x8
							
							offset1 = 0
							offset2 += 0x400
						
						offset2 = 0
						offset3 = 1
					
					offset3 = 0
					offset4 = 0x40
				
				offset4 = 0
				offset5 = 0x100
			
			offset5 = 0
			offset6 = 0x80
		
		offset6 = 0
		offset7 += width*8
		
	
	fin.close
	fout.close

##########################################################################
''' def swzdxt5  '''
##########################################################################
def swzdxt5(width,height,raw):
	fin = open(raw,'rb')
	
	fout = open(raw+'_swizzled.dds','ab')
	
	header = fin.read(128)
	fout.write(header)

	size = width * height / 4
	if width >= 0x80:
		sections = width/0x80
	else:
		sections = 1
	offset1, offset2, offset3, offset4, offset5, offset6, offset7, x = 0,0,0,0,0,0,0,128 
	rbuff = [0 for j in range(0x10)]
	for p in range(height/(8*4)):
		for o in range(sections):
			for n in range(2):
				for m in range(2):
					for l in range(2):
						for j in range(4):
							offset =  offset1+offset2+offset3+offset4+offset5+offset6+offset7
							for i in range(0,0xD,4):
								fin.seek(0x10*(i*2+offset)+x,0)
								rbuff[i] = fin.read(0x10)
							for i in range(1,0xE,4):
								fin.seek(0x10*((i-1)*2+width/4+offset)+x,0)
								rbuff[i] = fin.read(0x10)
							for i in range(2,0xF,4):
								fin.seek(0x10*(i*2-3+offset)+x,0)
								rbuff[i] = fin.read(0x10)
							for i in range(3,0x10,4):
								fin.seek(0x10*((i-1)*2-3+width/4+offset)+x,0)
								rbuff[i] = fin.read(0x10)
							for i in range(0x10):
								fout.write(rbuff[i])
									
							offset1 += 2
							
						offset1 = 0
						offset2 = width/2
						
					offset2 = 0
					offset3 = width*4
					
				offset3 = 0
				offset4 = width
				
			offset4 = 0
			offset5 = width*2
			
			for n in range(2):
				for m in range(2):
					for l in range(2):
						for j in range(4):
							offset =  offset1+offset2+offset3+offset4+offset5+offset6+offset7
							for i in range(0,0x5,4):
								fin.seek(0x10*(i*2+0x10+offset)+x,0)
								rbuff[i] = fin.read(0x10)
							for i in range(1,0x6,4):
								fin.seek(0x10*((i-1)*2+width/4+0x10+offset)+x,0)
								rbuff[i] = fin.read(0x10)
							for i in range(2,0x7,4):
								fin.seek(0x10*(i*2-3+0x10+offset)+x,0)
								rbuff[i] = fin.read(0x10)
							for i in range(3,0x8,4):
								fin.seek(0x10*((i-1)*2-3+0x10+width/4+offset)+x,0)
								rbuff[i] = fin.read(0x10)
								
							for i in range(8,0xD,4):
								fin.seek(0x10*(i*2-0x10+offset)+x,0)
								rbuff[i] = fin.read(0x10)
							for i in range(9,0xE,4):
								fin.seek(0x10*((i-1)*2-0x10+width/4+offset)+x,0)
								rbuff[i] = fin.read(0x10)
							for i in range(0xA,0xF,4):
								fin.seek(0x10*(i*2-0x10-3+offset)+x,0)
								rbuff[i] = fin.read(0x10)
							for i in range(0xB,0x10,4):
								fin.seek(0x10*((i-1)*2-0x10-3+width/4+offset)+x,0)
								rbuff[i] = fin.read(0x10)
							for i in range(0x10):
								fout.write(rbuff[i])
							
							offset1 += 2
							
						offset1 = 0
						offset2 = width/2
						
					offset2 = 0
					offset3 = width*4
					
				offset3 = 0
				offset4 = width
				
			offset4 = 0
			offset5 = 0
			offset6 += 0x20
		
		offset6 = 0
		offset7 += width*8
	
	fin.close
	fout.close

##########################################################################
''' def swzargb  '''
##########################################################################

def swzargb(width,height,raw):
	fin = open(raw,'rb')
	
	fout = open(raw+'_swizzled.dds','ab')
	
	header = fin.read(128)
	fout.write(header)
	
	size = width * height / 4

	offset1, offset2, offset3, x = 0,0,0,128 

	rbuff = [0 for j in range(0x10)]
	for m in range(height/(0x4*0x8)):
		for l in range(width/0x20):
			for k in range(2):
				for j in range(4):
					for i in range(0,7,2):
						fin.seek(0x10*(i/2+offset1+offset2+offset3)+x,0)
						rbuff[i] = fin.read(16)
					for i in range(8,0xF,2):
						fin.seek(0x10*(i/2+offset1+offset2+offset3)+x,0)
						rbuff[i] = fin.read(16)
					
					offset1 += width/4
					
					for i in range(1,8,2):	
						fin.seek(0x10*(i/2+offset1+offset2+offset3)+x,0)
						rbuff[i] = fin.read(16)
					for i in range(9,0x10,2):	
						fin.seek(0x10*(i/2+offset1+offset2+offset3)+x,0)
						rbuff[i] = fin.read(16)
						
					offset1 += width/4
					
					for i in range(0x10):
						fout.write(rbuff[i])
					
				for j in range(4):
					for i in range(0,7,2):
						fin.seek(0x10*(i/2+offset1+offset2+offset3+4)+x,0)
						rbuff[i] = fin.read(16)
					for i in range(8,0xF,2):	
						fin.seek(0x10*(i/2+offset1+offset2+offset3-4)+x,0)
						rbuff[i] = fin.read(16)
					
					offset1 += width/4
					
					for i in range(1,8,2):	
						fin.seek(0x10*(i/2+offset1+offset2+offset3+4)+x,0)
						rbuff[i] = fin.read(16)
					for i in range(9,0x10,2):	
						fin.seek(0x10*(i/2+offset1+offset2+offset3-4)+x,0)
						rbuff[i] = fin.read(16)
					
					offset1 += width/4
					
					for i in range(0x10):
						fout.write(rbuff[i])
					
			offset1 = 0
			offset2 += 0x8
			
		offset2 = 0
		offset3 += width*0x8
	
	fin.close
	fout.close

##########################################################################
''' function unsargb  '''
##########################################################################

def unsargb(width,height,raw):

	fin = open(raw,'rb')
	
	fout = open(raw+'_uns.dds','ab')
	
	header = fin.read(128)
	fout.write(header)

	size = width * height / 4

	offset1, offset2, offset3, offset4, x = 0,0,0,0,128 
	rbuff = [0 for j in range(0x8)]
	for l in range(height/(4*0x4*0x2)):
		for j in range(2):
		
			for k in range(4):
				for j in range((width/0x4)/0x8):
					#offset1 = 0x100*j
					for i in range(8):
						fin.seek(0x10*(i*2+offset1+offset2+offset3)+x,0)
						rbuff[i] = fin.read(16)
						fout.write(rbuff[i])
					offset1 += 0x100
			
				offset1 = 0
			
				for j in range((width/0x4)/0x8):
					#offset1 = 0x100*j
					for i in range(8):
						fin.seek(0x10*(1+i*2+offset1+offset2+offset3)+x,0)
						rbuff[i] = fin.read(16)
						fout.write(rbuff[i])
					offset1 += 0x100
			
				offset1 = 0
			
				offset2 += 0x10

			for k in range(4):
				for j in range((width/0x4)/0x8):
					#offset1 = 0x100*j
					for i in range(4):
						fin.seek(0x10*(i*2+offset1+offset2+offset3+8)+x,0)
						rbuff[i] = fin.read(16)
						fout.write(rbuff[i])
					for i in range(4,8):
						fin.seek(0x10*(i*2+offset1+offset2+offset3-8)+x,0)
						rbuff[i] = fin.read(16)
						fout.write(rbuff[i])
					offset1 += 0x100
			
				offset1 = 0
			
				for j in range((width/0x4)/0x8):
					#offset1 = 0x100*j
					for i in range(4):
						fin.seek(0x10*(i*2+1+offset1+offset2+offset3+8)+x,0)
						rbuff[i] = fin.read(16)
						fout.write(rbuff[i])
					for i in range(4,8):
						fin.seek(0x10*(i*2+1+offset1+offset2+offset3-8)+x,0)
						rbuff[i] = fin.read(16)
						fout.write(rbuff[i])
				
					offset1 += 0x100
				
				offset1 = 0
			
				offset2 += 0x10
				
		offset2 = 0
		offset3 += width*0x8

	fin.close
	fout.close




##########################################################################
''' function unsdxt1_64  '''
##########################################################################

def unsdxt1_64(width,height,raw):
	print 'dxt1_wide_64'
	fin = open(raw,'rb')
	
	fout = open(raw+'_uns.dds','ab')
	
	header = fin.read(128)
	fout.write(header)

	size = width * height / 4
	if width >= 0x80:
		sections = width/0x80
	else:
		sections = 1
	if width >= 0x80:
		loop1 = 2
	else:
		loop1 = 1
	offset1, offset2, offset3, offset4, offset5, x = 0,0,0,0,0,128
	
	rbuff = [0 for j in range(0x10)]
	for n in range(height/(4*4)):
		for m in range(2):
			for l in range(4):
				for k in range(2):
					for j in range(sections):
						offset =  offset1+offset2+offset3+offset4+offset5
						for i in range(0,0x5,4):
							fin.seek(0x10*(i+offset)+x,0)
							rbuff[i] = fin.read(0x10)
						for i in range(8,0xD,4):
							fin.seek(0x10*(i+offset)+x,0)
							rbuff[i] = fin.read(0x10)
						for i in range(2,0x7,4):
							fin.seek(0x10*(i+0xE+offset)+x,0)
							rbuff[i] = fin.read(0x10)
						for i in range(0xA,0xF,4):
							fin.seek(0x10*(i+0xE+offset)+x,0)
							rbuff[i] = fin.read(0x10)
						for i in range(1,0x6,4):
							fin.seek(0x10*(i+1+offset)+x,0)
							rbuff[i] = fin.read(0x10)
						for i in range(9,0xE,4):
							fin.seek(0x10*(i+1+offset)+x,0)
							rbuff[i] = fin.read(0x10)
						for i in range(3,0x8,4):
							fin.seek(0x10*(i+0xF+offset)+x,0)
							rbuff[i] = fin.read(0x10)
						for i in range(0xB,0x10,4):
							fin.seek(0x10*(i+0xF+offset)+x,0)
							rbuff[i] = fin.read(0x10)
						for i in range(0x10):
							fout.write(rbuff[i])
						
						offset1 += 0x200
					
					offset1 = 0
					offset2 = 1
				
				offset2 = 0
				offset3 += 0x20
			
			offset4 += 0x80
			
			for l in range(4):
				for k in range(2):
					for j in range(sections):
						offset =  offset1+offset2+offset3+offset4+offset5
						
						offset1 += 0x200
					
					offset1 = 0
					offset2 = 1
				
				offset2 = 0
				offset3 += 0x20
			
			offset3 = 0
			
		
		offset4 = 0
		offset5 += width*4
	
	fin.close
	fout.close
