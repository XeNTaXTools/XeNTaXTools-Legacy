#!/usr/bin/env python
from TprClass13 import*
import wx

List =  []
ChoiceList = ['vstrd[0]', 'vstrd[1]', 'vstrd[2]', 'vstrd[3]', 'vstrd[4]', 'vstrd[F]']
ChoiceList2 = [str(i) for i in range(0x10)]
vstrd = [3 for i in range(0x10)]
g4=0

class MyApp(wx.PySimpleApp):
	def OnInit(self):
		self.Frm = wx.Frame(None, -1, "TPR Texturer", size=(950,730))

		self.StTxt = wx.StaticText(self.Frm, -1, "At First, Push \"OpenFile\"", pos=(20,20))
		self.StTxt2 = wx.StaticText(self.Frm, -1, "dds info", pos=(230,260))
		self.StTxt3 = wx.StaticText(self.Frm, -1, "obj info", pos=(350,260))
		self.StTxt4 = wx.StaticText(self.Frm, -1, "material info", pos=(470,260))
		self.StTxt5 = wx.StaticText(self.Frm, -1, "mesh info", pos=(590,260))
		self.StTxt6 = wx.StaticText(self.Frm, -1, "vbuf info", pos=(710,260))
		self.StTxt7 = wx.StaticText(self.Frm, -1, "ibuf info", pos=(830,260))
		self.StTxt8 = wx.StaticText(self.Frm, -1, "vbuf info2", pos=(710,360))
		self.StTxt9 = wx.StaticText(self.Frm, -1, "obj info2", pos=(350,360))
		self.StTxt10 = wx.StaticText(self.Frm, -1, "Real Obj", pos=(350, 670))
		self.StTxt11 = wx.StaticText(self.Frm, -1, "vbuf info2", pos=(710, 650))
		self.StTxt12 = wx.StaticText(self.Frm, -1, "obj info2", pos=(830, 650))
		self.StTxt13 = wx.StaticText(self.Frm, -1, "Select V.Stride", pos=(150,350))
		self.StTxt14 = wx.StaticText(self.Frm, -1, "VERTICES", pos=(590,400))
		
		self.LBox = wx.ListBox(self.Frm, -1, pos=(230, 10), size=(100, 250), choices=List)	#DDS
		self.LBox.Bind(wx.EVT_LISTBOX, self.LBOnSelect)
		self.LBox2 = wx.ListBox(self.Frm, -1, pos=(350, 10), size=(100, 250), choices=List)	#OBJ
		self.LBox2.Bind(wx.EVT_LISTBOX, self.LBOnSelect2)
		self.LBox3 = wx.ListBox(self.Frm, -1, pos=(470, 10), size=(100, 250), choices=List)	#MAT
		self.LBox3.Bind(wx.EVT_LISTBOX, self.LBOnSelect3)
		self.LBox4 = wx.ListBox(self.Frm, -1, pos=(590, 10), size=(100, 250), choices=List)	#MESH
		self.LBox4.Bind(wx.EVT_LISTBOX, self.LBOnSelect4)
		self.LBox6 = wx.ListBox(self.Frm, -1, pos=(710, 10), size=(100, 250), choices=List)	#VBUF
		self.LBox6.Bind(wx.EVT_LISTBOX, self.LBOnSelect6)
		self.LBox7 = wx.ListBox(self.Frm, -1, pos=(830, 10), size=(100, 250), choices=List)	#IBUF
		self.LBox7.Bind(wx.EVT_LISTBOX, self.LBOnSelect7)
		self.LBox8 = wx.ListBox(self.Frm, -1, pos=(350, 480), size=(100, 170), choices=List)	#RealOBJ
		self.LBox9 = wx.ListBox(self.Frm, -1, pos=(710, 480), size=(100, 170), choices=List)	#RealVBUF
		self.LBox10 = wx.ListBox(self.Frm, -1, pos=(830, 480), size=(100, 170), choices=List)	#RealIBUF
		self.LBox5 = wx.ListBox(self.Frm, -1, pos=(470, 480), size=(100, 70), choices=List)
		self.LBox11 = wx.ListBox(self.Frm, -1, pos=(590, 440), size=(100, 70), choices=List)
		
		self.Btn = wx.Button(self.Frm,-1,"OpenFile",pos=(20,70))
		self.Btn.Bind(wx.EVT_BUTTON, self.OnButton)
		self.Btn2 = wx.Button(self.Frm,-1,"ExportTextures",pos=(20,100))
		self.Btn2.Bind(wx.EVT_BUTTON, self.OnButton2)
		self.Btn3 = wx.Button(self.Frm,-1,"InjectTexture",pos=(20,130))
		self.Btn3.Bind(wx.EVT_BUTTON, self.OnButton3)
		self.Btn4 = wx.Button(self.Frm,-1,"InjectDXT5toDXT1",pos=(20,190))
		self.Btn4.Bind(wx.EVT_BUTTON, self.OnButton4)
		self.Btn5 = wx.Button(self.Frm,-1,"!!!TransparentTPR",pos=(20,220))
		self.Btn5.Bind(wx.EVT_BUTTON, self.OnButton5)
		self.Btn6 = wx.Button(self.Frm,-1,"ExportMqoFile",pos=(20,280))
		self.Btn6.Bind(wx.EVT_BUTTON, self.OnButton6)
		self.Btn7 = wx.Button(self.Frm,-1,"ExportIBuffVbuff",pos=(20,310))
		self.Btn7.Bind(wx.EVT_BUTTON, self.OnButton7)
		self.Btn8 = wx.Button(self.Frm,-1,"Calculate V.Stride",pos=(20,340))
		self.Btn8.Bind(wx.EVT_BUTTON, self.OnButton8)
		self.Btn9 = wx.Button(self.Frm,-1,"ExportUserData",pos=(20,160))
		self.Btn9.Bind(wx.EVT_BUTTON, self.OnButton9)
		
		"""
		self.Choice1 = wx.Choice(self.Frm, -1, pos=(20,380), choices=ChoiceList)
		self.Choice1.Bind(wx.EVT_CHOICE, self.OnChoice1)
		self.Choice2 = wx.Choice(self.Frm, -1, pos=(150,380), choices=ChoiceList2)
		self.Choice2.Bind(wx.EVT_CHOICE, self.OnChoice2)
		"""
		ChBox1 = wx.CheckBox(self.Frm, -1, "DOA4", (20, 50))
		
		#self.Tree1 = wx.TreeCtrl(self.Frm, -1, pos=(20,410), size=(300, 270))
		#IdRoot = self.Tree1.AddRoot("Company")
		
		self.Frm.Bind(wx.EVT_CHECKBOX, self.OnCheckBox1)
		self.Frm.Show(True)
		return True
	
	def CloseFrame(self, event):
		self.Frm.Close()
	
	def OnButton(self, event):
		theBtn = event.GetEventObject()
		global filein, tprdat, ddsdat, usrdat, vbfdat, ibfdat,  List
		Dlg = wx.FileDialog(self.Frm, message="Please Choose XPRFile")
		AnsBtn = Dlg.ShowModal()
		AnsFilename = Dlg.GetFilename()
		AnsFilePath = Dlg.GetPath()
		self.StTxt.SetLabel(AnsFilePath)
		filein = AnsFilename
		tprdat = TPR_data(filein)
		ddsdat = DDS_data(tprdat,filein,Flagdoa4)
		usrdat = USER_data(tprdat,filein)
		vbfdat = VBUF_data(tprdat,filein,Flagdoa4)
		ibfdat = IBUF_data(tprdat,filein,Flagdoa4)
		self.LBox.Clear()
		self.LBox2.Clear()
		self.LBox6.Clear()
		self.LBox7.Clear()
		for i in range(tprdat.numdds):
			self.LBox.Insert('%d_dds'%i,i)
		for i in range(usrdat.usr1_numobj):
			self.LBox2.Insert('%d_obj'%i,i)
		for i in range(tprdat.numvbf):
			self.LBox6.Insert('%d_vbf %X'%(i,vbfdat.info[i]),i)
		for i in range(tprdat.numibf):
			self.LBox7.Insert('%d_ibf %X'%(i,ibfdat.info[i]),i)
		
		self.LBox8.Clear()
		self.LBox9.Clear()
		self.LBox10.Clear()
		k=0
		for i in range(usrdat.usr1_numobj):
			if usrdat.usr1_vertices[i][0] != 1:
				self.LBox8.Insert('%d_obj'%i,k)
				k+=1
		k=0
		for i in range(tprdat.numvbf):
			if vbfdat.info[i] > 0x22:
				self.LBox9.Insert('%d_vbf'%i,k)
				k+=1
		self.StTxt11.SetLabel('Real V.Buff# = %X'%(k))
		k=0
		for i in range(tprdat.numibf):
			if ibfdat.info[i] > 0x10:
				self.LBox10.Insert('%d_ibf'%i,k)
				k+=1
		self.StTxt12.SetLabel('Real I.Buff# = %X'%(k))
		"""
		IdRoot = self.Tree1.AddRoot('ObjHie')
		#self.Tree1.AppendItem(IdRoot, '%d_mesh %X'%(j,usrdat.usr3_numchild[j]))
		for i in range(usrdat.usr1_numobj):
			IdRoot2 = self.Tree1.AppendItem(IdRoot, '%d_hobj(%d) child:%d'%(i,usrdat.usr3_hobjnum[i],usrdat.usr3_numchild[i]))
			for j in range(usrdat.usr3_numchild[i]):
				IdRoot3 = self.Tree1.AppendItem(IdRoot2, '%d_child'%(usrdat.usr3_child[i][j]) )
				for k in range(usrdat.usr3_numchild[j]):
					IdRoot4 = self.Tree1.AppendItem(IdRoot3, '%d_child'%(usrdat.usr3_child[j][k]) )
		"""
		Dlg.Destroy()
	
	def OnButton2(self, event):
		theBtn = event.GetEventObject()
		for i in range(tprdat.numdds):
			print '%X %X %X %X %X ' % (i, ddsdat.width[i],ddsdat.height[i],ddsdat.size[i],ddsdat.type[i])
		export_all_DDS(filein,tprdat,ddsdat)
	
	def OnButton3(self, event):
		theBtn = event.GetEventObject()
		Dlg = wx.FileDialog(self.Frm, message="Please Choose DDSFile")
		AnsBtn = Dlg.ShowModal()
		AnsFilename = Dlg.GetFilename()
		file1 = AnsFilename
		file2 = filein
		ddsdat.removeheader_and_insert(ddsdat.addr2[i],ddsdat.addr1[i],
					ddsdat.type[i],ddsdat.width[i],ddsdat.height[i],file1,file2)
		os.remove(file1+'_swizzled.dds')
		Dlg.Destroy()
	
	def OnButton4(self, event):
		theBtn = event.GetEventObject()
		Dlg = wx.FileDialog(self.Frm, message="Please Choose DDSFile")
		AnsBtn = Dlg.ShowModal()
		AnsFilename = Dlg.GetFilename()
		file1 = AnsFilename
		file2 = filein
		if ddsdat.type[i] != 0x52:
			print 'DDStype is not DXT1!'
			return
		ddsdat.removeheader_and_insert(ddsdat.addr2[i],ddsdat.addr1[i],
					0x54,ddsdat.width[i],ddsdat.height[i],file1,file2)
		os.remove(file1+'_swizzled.dds')
		dxt1to5(i,file2+'_mod')
		Dlg.Destroy()
	
	def OnButton5(self, event):
		theBtn = event.GetEventObject()
		transparentTPR(filein,tprdat,usrdat)
		print 'done'
	
	def OnButton6(self, event):
		theBtn = event.GetEventObject()
		print vstrideA
		print "please wait..."
		writeMqoFile(filein,tprdat,ddsdat,vbfdat,ibfdat,usrdat,vb,ib,vstrideA,ShortToFloat,ObjNumber,MeshNumber,MatOffset)
		print 'done'
	
	def OnButton7(self, event):
		theBtn = event.GetEventObject()
		vbfdat.write_vbuf(tprdat, filein)
		ibfdat.write_ibuf(tprdat, filein)
		print 'Ibuff and Vbuff exported to folder'
	
	def OnButton8(self, event):
		theBtn = event.GetEventObject()
		global vstrd
		vstrd = calcVStride(filein,tprdat,ddsdat,vbfdat,usrdat,vb)
		print vstrd
	
	def OnButton9(self, event):
		theBtn = event.GetEventObject()
		usrdat.writeuser(tprdat, filein)
		print 'UserData Exported!'
	
	def LBOnSelect(self, event):
		global i
		i = self.LBox.GetSelection()
		self.StTxt2.SetLabel("%X th DDS \nDDSType: %X \nWidth: %d \nHeight: %d \nSize: %X" % (\
			i,ddsdat.type[i],ddsdat.height[i]+1,(ddsdat.width[i]+1)*8,ddsdat.size[i]) )

	def LBOnSelect2(self, event):
		global j,ObjNumber
		j = self.LBox2.GetSelection()
		ObjNumber = j
		realobj = 0
		for i in range(usrdat.usr1_numobj):
			if usrdat.usr1_vertices[i][0] != 1:
				realobj += 1
		self.StTxt3.SetLabel('%X th object \nmesh# = %X\nmaterial# = %X\nRealObj# = %d\nParent :%X' % \
			(j,usrdat.usr1_objmesh[j],usrdat.usr1_nummat[j],realobj,usrdat.usr3_parent[j]) )
			
		self.LBox3.Clear()
		for i in range(usrdat.usr1_nummat[j]):
			self.LBox3.Insert('%d_material'%i,i)
		
		self.LBox4.Clear()
		for i in range(usrdat.usr1_objmesh[j]):
			self.LBox4.Insert('%d_mesh %X'%(i,usrdat.usr1_vertices[j][i]),i)
			
		if usrdat.usr1_vertices[j][0] != 1:
			self.StTxt9.SetLabel('Real Object')
		else :
			self.StTxt9.SetLabel('Dummy Object')
		
		####debug####
		print usrdat.usr3_objdict[j]
		print usrdat.usr3_parentls[usrdat.usr3_objdict[j]]
		#print usrdat.usr3_hobjnum[usrdat.usr3_hobjnum[j]]
		print usrdat.usr3_transx[usrdat.usr3_objdict[j]],usrdat.usr3_transy[usrdat.usr3_objdict[j]],usrdat.usr3_transz[usrdat.usr3_objdict[j]]

	def LBOnSelect3(self, event):
		global MatOffset
		k = self.LBox3.GetSelection()
		MatOffset = k
		texlist = usrdat.usr1_matdds[j][k]
		self.StTxt4.SetLabel('%XthObj - %XthMat\nTransparent: %X\nTexture# = %X\n VertOffset: %X\n VertRange: %X\n VertOffset2: %X\n VertRange2: %X\n Diffuse: %f\n Ambient: %f\n Specular: %f\n Power: %f' % \
			(j, k, usrdat.usr1_mattp[j][k],usrdat.usr1_matnumdds[j][k],usrdat.usr1_matvoff[j][k],usrdat.usr1_matvlen[j][k]\
				,usrdat.usr1_matvoff2[j][g4][k],usrdat.usr1_matvlen2[j][g4][k],usrdat.usr1_diffuse[j][k][0],usrdat.usr1_ambient[j][k][0],usrdat.usr1_specular[j][k][0] \
				,usrdat.usr1_power[j][k][0]) )
		self.LBox5.Clear()
		for l in range(usrdat.usr1_matnumdds[j][k]):
			self.LBox5.Insert('%d_dds'%usrdat.usr1_matdds[j][k][l],l)
	
	def LBOnSelect4(self, event):
		global vb, g4, vstrideA, MeshNumber, ib
		g4 = self.LBox4.GetSelection()
		MeshNumber = g4
		k = self.LBox4.GetSelection()
		ib = usrdat.usr1_meshibf[j][k]
		vb = usrdat.usr1_vandvstride[j][k][0][0]
		vstrideA = usrdat.usr1_vandvstride[j][k][0][1]
		self.StTxt5.SetLabel('IBUF no: %d\nVBUF no: %X\nV.Stride: %X\nVertices: %X\nIndices: %X\nattachedVertex:%d\nattchedVstride:%d\nvstridepos:%X' % \
			(usrdat.usr1_meshibf[j][k],usrdat.usr1_meshvbf[j][k],\
			usrdat.usr1_meshstride[j][k],usrdat.usr1_vertices[j][k],usrdat.usr1_indices[j][k],usrdat.usr1_vandvstride[j][k][0][0],\
			usrdat.usr1_vandvstride[j][k][0][1],usrdat.usr1_advstride[j][k][0]))
		self.StTxt14.SetLabel('Vertices: %X' %(usrdat.usr1_vertices[j][k]))
		self.StTxt14.SetForegroundColour("green")
		self.LBox11.Clear()
		'''
		if usrdat.usr1_meshstride[j][g4] == 0xB :#or 0xA:
			offsetby = usrdat.usr1_meshstride[j][g4]-3+1
		elif usrdat.usr1_meshstride[j][g4] == 0x9:
			offsetby = usrdat.usr1_meshstride[j][g4]+2+1
		else:
			offsetby = usrdat.usr1_meshstride[j][g4]+1
		vstrideA = offsetby
		"""
		if usrdat.usr1_meshstride[j][g4] == 0xC or 0x9:
			offsetby2 = 2
		else:
			offsetby2 = usrdat.usr1_meshstride[j][g4]-3
		"""
		for i in range(tprdat.numvbf):
			if usrdat.usr1_vertices[j][k] != 1 and usrdat.usr1_vertices[j][k] == vbfdat.info[i]/4/(offsetby):
				self.LBox11.Insert('%d_vbf'%i,0)
		'''
		
	def LBOnSelect6(self, event):
		global vstride #vb, vstride
		k = self.LBox6.GetSelection()
		#vb = k
		self.StTxt6.SetLabel("%X th V.buffer \nSize: %X" % (\
			k,vbfdat.info[k]) )
		if usrdat.usr1_meshstride[j][g4] == 0xB :#or 0xA:
			offsetby = usrdat.usr1_meshstride[j][g4] - 3
			vstride = usrdat.usr1_meshstride[j][g4] - 3
		elif usrdat.usr1_meshstride[j][g4] == 0x9:
			offsetby = usrdat.usr1_meshstride[j][g4] + 2
			vstride = usrdat.usr1_meshstride[j][g4] + 2
		else:
			offsetby = usrdat.usr1_meshstride[j][g4]
			vstride = usrdat.usr1_meshstride[j][g4]
		
		self.StTxt8.SetLabel("%X th Vertices =\nSize/VStrideAuto: %X\nSize/VStrideX: %X " % \
			(k,vbfdat.info[k]/4/(vstrd[0]),vbfdat.info[k]/4/(vstrideA)) )

	def LBOnSelect7(self, event):
		k = self.LBox7.GetSelection()
		self.StTxt7.SetLabel("%X th I.buffer \nSize: %X" % (\
			k,ibfdat.info[k]) )
	"""
	def OnChoice1(self, event):
		global vstrideA
		vstrideA = 15
		Number = self.Choice1.GetSelection()
		if Number == 5:
			vstrideA = 15
		elif Number == 4:
			vstrideA = 3
		else:
			vstrideA = vstrd[Number]
		print 'current vstride : vstrd[%d]=%d'%(Number,vstrideA)
		self.StTxt13.SetLabel('V.Stride : %X'%(vstrideA))
	
	def OnChoice2(self, event):
		global vstrideA
		vstrideA = self.Choice2.GetSelection()
		print 'current vstride : vstrd[%d]=%d'%(self.Choice2.GetSelection(),vstrideA)
		#self.StTxt13.SetLabel('V.Stride : %X'%(vstrideA))
	"""
	def OnCheckBox1(self, event):
		ChBox = event.GetEventObject()
		global Flagdoa4
		if event.IsChecked():
			Flagdoa4 = -0xC
			print 'on'
		else:
			Flagdoa4 = 0
			print 'off'
