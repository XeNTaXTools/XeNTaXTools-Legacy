#from TprClass import *
from TprGui3 import *

##########################################################################
''' main  '''
##########################################################################

if argv[1] == '-e' :
	filein = argv[2]
	tprdat = TPR_data(filein)
	ddsdat = DDS_data(tprdat,filein)

	for i in range(tprdat.numdds):
		print '%X %X %X %X %X ' % (i, ddsdat.width[i],ddsdat.height[i],ddsdat.size[i],ddsdat.type[i])

	export_all_DDS(filein,tprdat,ddsdat)
	
elif argv[1] == '-i':
	filein=argv[2]
	fileout=argv[3]
	tprdat = TPR_data(fileout)
	ddsdat = DDS_data(tprdat,fileout)

	
	i = int(argv[4])
	ddsdat.removeheader_and_insert(ddsdat.addr2[i],ddsdat.addr1[i],
					ddsdat.type[i],ddsdat.width[i],ddsdat.height[i],filein,fileout)
	os.remove(filein+'_swizzled.dds')

elif argv[1] == '-i5':
	filein=argv[2]
	fileout=argv[3]
	i = int(argv[4])
	tprdat = TPR_data(fileout)
	ddsdat = DDS_data(tprdat,fileout)
	ddsdat.removeheader_and_insert(ddsdat.addr2[i],ddsdat.addr1[i],
					0x54,ddsdat.width[i],ddsdat.height[i],filein,fileout)
	os.remove(filein+'_swizzled.dds')
	dxt1to5(i,fileout+'_mod')
elif argv[1] == '-b' :
	filein = argv[2]
	tprdat = TPR_data(filein)
	ddsdat = DDS_data(tprdat,filein)
	vbfdat = VBUF_data(tprdat,filein)
	ibfdat = IBUF_data(tprdat,filein)

	vbfdat.write_vbuf(tprdat, filein)
	ibfdat.write_ibuf(tprdat, filein)
	print 'a.startad = %X, vbufdat.addr1[0] = %X' % (tprdat.startad, vbfdat.addr1[0])
	
elif argv[1] == '-n' :
	filein = argv[2]
	tprdat = TPR_data(filein)
	ddsdat = DDS_data(tprdat,filein)
	vbfdat = VBUF_data(tprdat,filein)
	ibfdat = IBUF_data(tprdat,filein)
	
	print ' numdds = %d, numvbuf = %d, numibuf = %d\n mdlgeo = %d, objgeo = %d, geodecl = %d, \
mdlinfo = %d, objinfo = %d\n startad = %X' % (tprdat.numdds, tprdat.numvbf, tprdat.numibf,
	tprdat.mdlgeo, tprdat.objgeo, tprdat.geodecl, tprdat.mdlinfo, tprdat.objinfo, tprdat.startad)
	
elif argv[1] == '-u' :
	filein = argv[2]
	tprdat = TPR_data(filein)
	usrdat = USER_data(tprdat,filein)
	
	usrdat.writeuser(tprdat, filein)
	print 'done'
	
elif argv[1] == '-f':
	folder = argv[2]
	for root, dirs, files in os.walk(argv[2]):
		for f in files:
			
			print os.path.join(root, f)
			os.chdir(argv[2])
			tprdat = TPR_data(f)
			ddsdat = DDS_data(tprdat,f)
			export_all_DDS(f,tprdat,ddsdat)
			os.chdir("..")


elif argv[1] == '-o' :
	filein = argv[2]
	tprdat = TPR_data(filein)
	ddsdat = DDS_data(tprdat,filein,Flagdoa4)
	vbfdat = VBUF_data(tprdat,filein,Flagdoa4)
	ibfdat = IBUF_data(tprdat,filein,Flagdoa4)

	#vbfdat.write_vbufobj(tprdat, filein)
	ibfdat.write_ibufobj(tprdat, filein)

elif argv[1] == '-oinfo' :
	filein = argv[2]
	tprdat = TPR_data(filein)
	ddsdat = DDS_data(tprdat,filein)
	vbfdat = VBUF_data(tprdat,filein)
	ibfdat = IBUF_data(tprdat,filein)

	print '%X %X' % (vbfdat.info[0],vbfdat.size[0])

	"""
elif argv[1] == '-s' :
	raw = argv[2]
	width = int(argv[3])
	height = int(argv[4])
	fc.swzargb(width,height,raw)
	"""
elif argv[1] == '-u1' :
	filein = argv[2]
	tprdat = TPR_data(filein)
	usrdat = USER_data(tprdat,filein)
	print 'usr1size = %X, usr1numobj = %X' % (usrdat.usr1_size, usrdat.usr1_numobj)
	for i in range(usrdat.usr1_numobj):
		print '%X th object addr = %X  nummat = %X ' % (i,usrdat.usr1_objad[i],usrdat.usr1_nummat[i])
		for j in range(usrdat.usr1_nummat[i]):
			print 'matad[%X][%X] = %X mattp = %X matnumdds = %X, %X' % (i,j,usrdat.usr1_matad[i][j],usrdat.usr1_mattp[i][j],usrdat.usr1_matnumdds[i][j],usrdat.usr1_matddsad[i][j])
			for k in range(usrdat.usr1_matnumdds[i][j]):
				print '   matdds[%X][%X][%X] = %X ' % (i,j,k,usrdat.usr1_matdds[i][j][k]) 
				
				
elif argv[1] == '-u2' :
	filein = argv[2]
	tprdat = TPR_data(filein)
	usrdat = USER_data(tprdat,filein)
	totalnumber_of_mat, realmesh = 0, 0
	for i in range(usrdat.usr1_numobj):
		print '%X th object mesh# = %X  nummat = %X ' % (i,usrdat.usr1_objmesh[i],usrdat.usr1_nummat[i])
		
		for j in range(usrdat.usr1_objmesh[i]):
			print ' vbf %X ibf %X(0%d) vertex stride %X vertices %X indices %X x1 %X x2 %X' % \
				(usrdat.usr1_meshvbf[i][j],usrdat.usr1_meshibf[i][j],usrdat.usr1_meshibf[i][j],\
				usrdat.usr1_meshstride[i][j],usrdat.usr1_vertices[i][j],usrdat.usr1_indices[i][j],usrdat.usr1_x1[i][j],usrdat.usr1_x2[i][j])
			if usrdat.usr1_vertices[i][j] != 1:
				realmesh += 1
		totalnumber_of_mat += usrdat.usr1_nummat[i]
	print 'totalnumber_of_material = %d (0x%X) Realmesh = %d (0x%X)' % (totalnumber_of_mat,totalnumber_of_mat,realmesh,realmesh)
	
elif argv[1] == '-u3' :
	filein = argv[2]
	tprdat = TPR_data(filein)
	usrdat = USER_data(tprdat,filein)
	for i in range(usrdat.usr1_numobj):
		print '%X th object ad = %X  trasparent = %X obj_x %X obj_y %X' % \
			(i,usrdat.usr2_objad[i],usrdat.usr2_objtp[i],usrdat.usr2_obj_x[i],usrdat.usr2_obj_y[i])
		for j in range(usrdat.usr1_nummat[i]):
			print 'mattp[%X][%X] = %X ' % (i,j,usrdat.usr2_mattp[i][j])
			
elif argv[1] == '-utext' :
	filein = argv[2]
	tprdat = TPR_data(filein)
	usrdat = USER_data(tprdat,filein)
	fout=open(filein+'.txt','w')
	print >>fout,'usr1size = %X, usr1numobj = %X' % (usrdat.usr1_size, usrdat.usr1_numobj)
	
	for i in range(usrdat.usr1_numobj):
		print >>fout,'%X th object addr = %X  nummat = %X ' % (i,usrdat.usr1_objad[i],usrdat.usr1_nummat[i])
		for j in range(usrdat.usr1_nummat[i]):
			print >>fout, 'matad[%X][%X] = %X usr1_mattp = %X matnumdds = %X, %X' % \
							(i,j,usrdat.usr1_matad[i][j],usrdat.usr1_mattp[i][j],\
							usrdat.usr1_matnumdds[i][j],usrdat.usr1_matddsad[i][j])
			for k in range(usrdat.usr1_matnumdds[i][j]):
				print >>fout, '   matdds[%X][%X][%X] = %X ' % (i,j,k,usrdat.usr1_matdds[i][j][k]) 
	
	totalnumber_of_mat, realmesh = 0, 0
	for i in range(usrdat.usr1_numobj):
		print >>fout,'%X th object mesh# = %X  nummat = %X ' % (i,usrdat.usr1_objmesh[i],usrdat.usr1_nummat[i])
		
		for j in range(usrdat.usr1_objmesh[i]):
			print >>fout,' vbf %X ibf %X(0%d) vertex stride %X vertices %X indices %X x1 %X x2 %X' % \
					(usrdat.usr1_meshvbf[i][j],usrdat.usr1_meshibf[i][j],usrdat.usr1_meshibf[i][j],\
					usrdat.usr1_meshstride[i][j],usrdat.usr1_vertices[i][j],usrdat.usr1_indices[i][j],\
					usrdat.usr1_x1[i][j],usrdat.usr1_x2[i][j])
			if usrdat.usr1_vertices[i][j] != 1:
				realmesh += 1
		totalnumber_of_mat += usrdat.usr1_nummat[i]
	print >>fout,'totalnumber_of_material = %d (0x%X) Realmesh = %d (0x%X)' % \
						(totalnumber_of_mat,totalnumber_of_mat,realmesh,realmesh)
	
	for i in range(usrdat.usr1_numobj):
		print >>fout,'%X th object ad = %X  trasparent = %X obj_x %X obj_y %X' % \
			(i,usrdat.usr2_objad[i],usrdat.usr2_objtp[i],usrdat.usr2_obj_x[i],usrdat.usr2_obj_y[i])
		for j in range(usrdat.usr1_nummat[i]):
			print >>fout,'usr2_mattp[%X][%X] = %X ' % (i,j,usrdat.usr2_mattp[i][j])
	
	for i in range(usrdat.usr1_numobj):
		for j in range(usrdat.usr1_nummat[i]):
			for k in range(4):
				print >>fout, '  diffuse[%X][%X][%X] = %f ' % (i,j,k,usrdat.usr1_diffuse[i][j][k])
			for k in range(4):
				print >>fout, '   ambient[%X][%X][%X] = %f ' % (i,j,k,usrdat.usr1_ambient[i][j][k])
			for k in range(4):
				print >>fout, '    specular[%X][%X][%X] = %f ' % (i,j,k,usrdat.usr1_specular[i][j][k])
			for k in range(4):
				print >>fout, '     power[%X][%X][%X] = %f ' % (i,j,k,usrdat.usr1_power[i][j][k])
			
elif argv[1] == '-t' :
	filein = argv[2]
	tprdat = TPR_data(filein)
	usrdat = USER_data(tprdat,filein)
	transparentTPR(filein,tprdat,usrdat)

elif argv[1] == '-re' :
	filein = argv[2]
	tprdat = TPR_data(filein)
	usrdat = USER_data(tprdat,filein)
	i = int(argv[3],16)
	j = int(argv[4],16)
	rewriteshort(usrdat.addr1[1]+usrdat.usr1_objad[i]+usrdat.usr1_matad[i][j]+0x50+3, 1,filein)
	filein += '_'
	rewriteshort(usrdat.addr1[2]+usrdat.usr2_objad[i]+0x4C+3, 4,filein)
	for j in range(usrdat.usr1_nummat[i]):
		filein += '_'
		rewriteshort(usrdat.addr1[2]+usrdat.usr2_objad[i]+usrdat.usr2_admat[i][j]+8+3, 4,filein)

elif argv[1] == 'test' :
	filein = argv[2]
	fin = open(filein,'rb')
	lsfin = list(fin.read())
	print lsfin
	lsfin[1:2] = '\x01'
	lsfin[3:4] = '\x04'
	print lsfin
	fin.close()
	fout = open(filein+'_trans','ab')
	fout.writelines(lsfin)
	fout.close()

elif argv[1] == 'testibf' :
	filein = argv[2]
	fin = open(filein,'rb')
	lsfin = list(fin.read())
	fin.seek(0,0)
	strfin = str(hexlify(fin.read()))
	#print strfin
	a = strfin.count('ffff')
	print a
	
	fin.seek(0,0)
	ad = 0
	ls=[[] for i in range(5+1)]	#(ffff no kaisuu) + 1
	print ls
	face=0
	for i in range(0x4A/2): #filesize/2
		if readshort(ad,fin) != 65535:
			ls[face].append(readshort(ad,fin))
			ad+=2
		else :
			face+=1
			ad+=2
		
	try:
		while(ls[face][-1]==0):
			ls[face].pop()
	except IndexError:
		pass
		
	print ls
	#print ls[2]
	def ibufspliter(list):
		if len(list)==3 :
			splitedlist = [list[2::-1]] #list.reverse()
		elif len(list)==4 :
			splitedlist = [list[2::-1],list[1:4]] #[list[0:3].reverse(),list[1:4]]
		elif len(list)==5 :
			splitedlist = [list[2::-1],list[1:4],[list[4],list[3],list[2]]] #[list[0:3].reverse(),list[1:4],list[2:5].reverse()]
		elif len(list)==6 :
			splitedlist = [list[2::-1],[list[5],list[4],list[3]]] #[list[0:3].reverse(),list[3:6].reverse()]
		elif len(list)==7 :
			splitedlist = [list[2::-1],[list[6],list[5],list[4]],list[1:4]] #[list[0:3].reverse(),list[4:7].reverse(),list[1:4]]
		else :
			splitedlist =[] #[0 for i in range(len(list)-2)]#[[] for i in range(len(list)-2)]
			for i in range(len(list)-2):
				if i%2==0:
					splitedlist.append([list[i+2],list[i+1],list[i]]) #list[i:i+3] #splitedlist[i].append(list[i*2:i*2+3].reverse())
				else:
					splitedlist.append(list[i:i+3])
		
		return splitedlist
	#print len(ls[5])
	#print [ls[0][2],ls[0][1],ls[0][0]]
	#lsx = reversed(ls[0])
	#print l.append(lsx)
	#print ibufspliter(ls[5])
	fout = open('ibuffwrite.txt','w')
	#fout.write(str(ibufspliter(ls[5])[2][0])+str(ibufspliter(ls[5])[2][1])+str(ibufspliter(ls[5])[2][2]))
	#fout.write(str(ibufspliter(ls[5])[3][0])+str(ibufspliter(ls[5])[3][1])+str(ibufspliter(ls[5])[3][2]))
	
	for i in range(6):
		for j in range(len(ibufspliter(ls[i]))):
			fout.write(str(ibufspliter(ls[i])[j][0])+' '+str(ibufspliter(ls[i])[j][1])+' '+str(ibufspliter(ls[i])[j][2])+'\n')
	
	#fout = open(filein+'_trans','ab')
	#fout.writelines(lsfin)
	fout.close()

elif argv[1] == '-uvtest' :
	filein = argv[2]
	tprdat = TPR_data(filein)
	ddsdat = DDS_data(tprdat,filein,Flagdoa4)
	usrdat = USER_data(tprdat,filein)
	vbfdat = VBUF_data(tprdat,filein,Flagdoa4)
	ibfdat = IBUF_data(tprdat,filein,Flagdoa4)
	vb = int(argv[3],16)
	ib = int(argv[4],16)
	vstride = int(argv[5],16)
	getUVtest(filein,tprdat,ddsdat,vbfdat,ibfdat,usrdat,vb,ib,vstride, ShortToFloat)

elif argv[1] == '-testrb' :
	filein = argv[2]
	fin = open(filein,'rb')
	fread = fin.read()
	numobj = fread.count('\x00\xff\x00\x00\xff\xff\xff\xff')
	print numobj
	adobj=[0x320,0xc20,0xe10,0x1440]
	
	ad = [0 for i in range(3)]
	for i in range(3):
		fin.seek(objad[i],0)
		fread = fin.read(objad[i+1]-objad[i])
		ad[i]=fread.find('\x00\xff\x00\x00\xff\xff\xff\xff')
		if (ad[i])%0x10==0:
			ad[i]+=0x4*2
		elif (ad[i])%0x10==4:
			ad[i]+=0x4*3
		elif (ad[i])%0x10==8:
			ad[i]+=0x4*2+0x10
		elif (ad[i])%0x10==0xC:
			ad[i]+=0x10+4
		"""
		if (ad[i])%0x10!=0 and (ad[i])%0x8==0:
			ad[i]+=0x18
		else:
			while((ad[i])%0x10!=0):
				ad[i]+=4
		"""
		ad[i]+=adobj[i]
		#fread.seek(ad[i]+8)
		
	print ad
	
elif argv[1] == '-mqotest' :
	filein = argv[2]
	tprdat = TPR_data(filein)
	ddsdat = DDS_data(tprdat,filein,Flagdoa4)
	usrdat = USER_data(tprdat,filein)
	vbfdat = VBUF_data(tprdat,filein,Flagdoa4)
	ibfdat = IBUF_data(tprdat,filein,Flagdoa4)
	vb = int(argv[3],16)
	ib = int(argv[4],16)
	vstride = int(argv[5],16)
	writeMqoFile(filein,tprdat,ddsdat,vbfdat,ibfdat,usrdat,vb,ib,vstride,ShortToFloat)
	
elif argv[1] == '-gui':
	app = MyApp()
	app.MainLoop()

else :
	print 'wrong'



	