from sys import *
from struct import *
from binascii import *
from array import *
import func_swizzle2 as fc
import os,glob,copy,math

Flagdoa4 = 0 # 0(DOAX2) or -0xC(DOA4)
##########################################################################
''' Class TPR_data  '''
##########################################################################
class TPR_data :
	
	def __init__(self, filein ):
		f1 = open(filein,'rb')
		headtpr = f1.read(0x50000)
		self.numusr = headtpr.count('USER')
		self.numdds = headtpr.count('TX2D')
		self.numvbf = headtpr.count('VBUF')
		self.numibf = headtpr.count('IBUF')
		self.numobj = self.numusr+self.numdds+self.numvbf+self.numibf
		self.name = os.path.basename(filein)
		self.mdlgeo = headtpr.count('MdlGeo')
		self.objgeo = headtpr.count('ObjGeo')
		self.geodecl = headtpr.count('GeoDecl')
		self.mdlinfo = headtpr.count('MdlInfo')
		self.objinfo = headtpr.count('ObjInfo')
		f1.seek(0x4+0x10*self.numobj,0)
		temp1 = f1.read(4)
		temp2 = hexlify(temp1)
		self.startad = ((int(temp2,16)+0x20)/0x1000)*0x1000+0x1000
		
		f1.close()
		

##########################################################################
''' SubClass USER_data '''
##########################################################################

class USER_data(TPR_data) :
	def __init__(self, a, filein):
		self.addr1 = [0 for i in range(4)]
		self.addr2 = [0 for i in range(4)]
		self.size = [0 for i in range(4)]
		self.data = [0 for i in range(4)]
		self.name = [0 for i in range(4)]
		
		f = open(filein,'rb')
		for i in range(4):
			f.seek(0x14+0x10*i,0)
			temp41 = f.read(4)
			temp42 = hexlify(temp41)
			self.addr1[i] = int(temp42,16) + 12
			f.seek(0x14+0x4+0x10*i,0)
			temp43 = f.read(4)
			temp44 = hexlify(temp43)
			self.size[i] = int(temp44,16)
		
		self.usr1_size  = readbinary(self.addr1[1]+0x10,f)	#sizemdl
		self.usr1_numobj = readbinary(self.addr1[1]+0x14,f) #numobj
		
		self.usr1_objad = [0 for i in range(self.usr1_numobj)]		#adobj
		self.usr1_objmesh = [0 for i in range(self.usr1_numobj)]	#nummesh
		self.usr1_geodecl = [0 for i in range(self.usr1_numobj)]	#
		for i in range(self.usr1_numobj):
			self.usr1_objad[i] = readbinary(self.addr1[1]+0x30+i*4,f)	#adobj[i]
		
		self.usr1_objad.append(self.usr1_size)
		ad = [0 for i in range(self.usr1_numobj*2)]
		
		self.usr1_nummat = [0 for i in range(self.usr1_numobj)]
		for i in range(self.usr1_numobj):
			self.usr1_nummat[i] = readbinary(self.addr1[1]+self.usr1_objad[i]+0x14,f)
			self.usr1_geodecl[i] = readbinary(self.addr1[1]+self.usr1_objad[i]+0x28,f)
			self.usr1_objmesh[i] = readbinary(self.addr1[1]+self.usr1_objad[i]+self.usr1_geodecl[i]+0x14,f)
		
		
		
		self.usr1_meshad = [[0 for j in range(100)] for i in range(self.usr1_numobj)]
		self.usr1_meshstride = [[0 for j in range(100)] for i in range(self.usr1_numobj)]
		self.usr1_meshibf = [[0 for j in range(100)] for i in range(self.usr1_numobj)]
		self.usr1_meshvbf = [[0 for j in range(100)] for i in range(self.usr1_numobj)]
		self.usr1_vertices = [[0 for j in range(100)] for i in range(self.usr1_numobj)]
		self.usr1_indices = [[0 for j in range(100)] for i in range(self.usr1_numobj)]
		self.usr1_x1 = [[0 for j in range(100)] for i in range(self.usr1_numobj)]
		self.usr1_x2 = [[0 for j in range(100)] for i in range(self.usr1_numobj)]
		for i in range(self.usr1_numobj):
			for j in range(self.usr1_objmesh[i]):
				self.usr1_meshad[i][j] = readbinary(self.addr1[1]+self.usr1_objad[i]+self.usr1_geodecl[i]+0x30+4*j,f)
				self.usr1_meshstride[i][j] = readbinary(self.addr1[1]+self.usr1_objad[i]+self.usr1_geodecl[i]+self.usr1_meshad[i][j]+0x10,f)
				self.usr1_vertices[i][j] = readbinary(self.addr1[1]+self.usr1_objad[i]+self.usr1_geodecl[i]+self.usr1_meshad[i][j]+0x14,f)
				self.usr1_indices[i][j] = readbinary(self.addr1[1]+self.usr1_objad[i]+self.usr1_geodecl[i]+self.usr1_meshad[i][j]+0xC,f)
				self.usr1_meshvbf[i][j] = readbinary(self.addr1[1]+self.usr1_objad[i]+self.usr1_geodecl[i]+self.usr1_meshad[i][j]+0x4,f)
				self.usr1_meshibf[i][j] = readbinary(self.addr1[1]+self.usr1_objad[i]+self.usr1_geodecl[i]+self.usr1_meshad[i][j]+0x8,f)
				self.usr1_x1[i][j] = readbinary(self.addr1[1]+self.usr1_objad[i]+self.usr1_geodecl[i]+self.usr1_meshad[i][j]+0x18,f)
				self.usr1_x2[i][j] = readbinary(self.addr1[1]+self.usr1_objad[i]+self.usr1_geodecl[i]+self.usr1_meshad[i][j]+0x30+0x80,f)
		self.usr1_matad = [[0 for j in range(0x100)] for i in range(self.usr1_numobj)]
		for i in range(self.usr1_numobj):
			for j in range(self.usr1_nummat[i]):
				self.usr1_matad[i][j] = readbinary(self.addr1[1]+self.usr1_objad[i]+0x40+4*j,f)
				##self.usr1_matmesh[i][j] = readbinary(self.addr1[1]+self.usr1_objad[i]+0x40+4*j,f)
				
		self.usr1_mattp = [[0 for j in range(0x100)] for i in range(self.usr1_numobj)]
		self.usr1_matnumdds = [[0 for j in range(0x100)] for i in range(self.usr1_numobj)]
		self.usr1_matddsad = [[0 for j in range(0x100)] for i in range(self.usr1_numobj)]
		for i in range(self.usr1_numobj):
			for j in range(self.usr1_nummat[i]):
				self.usr1_mattp[i][j] = readbinary(self.addr1[1]+self.usr1_objad[i]+self.usr1_matad[i][j]+0x50,f)  #tp:+0x50
				self.usr1_matnumdds[i][j] = readbinary(self.addr1[1]+self.usr1_objad[i]+self.usr1_matad[i][j]+0x18,f)  #tp:+0x50
				self.usr1_matddsad[i][j] = readbinary(self.addr1[1]+self.usr1_objad[i]+self.usr1_matad[i][j]+0x18+4,f) 
				
		self.usr1_matdds = [[[0 for k in range(0x10)] for j in range(0x100)] for i in range(self.usr1_numobj)]
		for i in range(self.usr1_numobj):
			for j in range(self.usr1_nummat[i]):
				for k in range(self.usr1_matnumdds[i][j]):
					self.usr1_matdds[i][j][k] = readbinary(self.addr1[1]+self.usr1_objad[i]+self.usr1_matad[i][j]+self.usr1_matddsad[i][j]+0x8+0x40*k,f)
		
		self.usr1_diffuse = [[[0 for k in range(4)] for j in range(100)] for i in range(self.usr1_numobj)]
		self.usr1_ambient = [[[0 for k in range(4)] for j in range(100)] for i in range(self.usr1_numobj)]
		self.usr1_specular = [[[0 for k in range(4)] for j in range(100)] for i in range(self.usr1_numobj)]
		self.usr1_power = [[[0 for k in range(4)] for j in range(100)] for i in range(self.usr1_numobj)]
		self.usr1_matvoff = [[0 for j in range(100)] for i in range(self.usr1_numobj)]
		self.usr1_matvlen = [[0 for j in range(100)] for i in range(self.usr1_numobj)]
		self.usr1_matvoff2 = [[[0 for k in range(100)] for j in range(self.usr1_objmesh[i])] for i in range(self.usr1_numobj)]
		self.usr1_matvlen2 = [[[0 for k in range(100)] for j in range(self.usr1_objmesh[i])] for i in range(self.usr1_numobj)]
		
		self.usr1_advstride = [[[0 for k in range(self.usr1_vertices[i][j])] for j in range(self.usr1_objmesh[i])] for i in range(self.usr1_numobj)]
		self.usr1_vandvstride = [[[[0 for l in range(2)] for k in range(self.usr1_vertices[i][j])] for j in range(self.usr1_objmesh[i])] for i in range(self.usr1_numobj)]
		for i in range(self.usr1_numobj):
			for j in range(self.usr1_objmesh[i]):
				for k in range(self.usr1_vertices[i][j]):
					if j == 0:
						f.seek(self.addr1[1]+self.usr1_objad[i],0)
						fread = f.read(self.usr1_objad[i+1]-self.usr1_objad[i])
					else:
						f.seek(self.usr1_advstride[i][j-1][0],0)
						fread = f.read(self.usr1_objad[i+1]-self.usr1_objad[i])
					self.usr1_advst=fread.find('\x00\xff\x00\x00\xff\xff\xff\xff')
					if (self.usr1_advst)%0x10==0:
						self.usr1_advst+=0x10
					elif (self.usr1_advst)%0x10==4:
						self.usr1_advst+=0x4*3
					elif (self.usr1_advst)%0x10==8:
						self.usr1_advst+=0x4*2+0x10
					elif (self.usr1_advst)%0x10==0xC:
						self.usr1_advst+=0x10+4
					if j == 0:
						self.usr1_advstride[i][j][k] = self.usr1_advst+self.addr1[1]+self.usr1_objad[i]
					else:
						self.usr1_advstride[i][j][k] = self.usr1_advst+self.usr1_advstride[i][j-1][0]
					self.usr1_vandvstride[i][j][k][0]=readbinary(self.usr1_advstride[i][j][k],f)
					self.usr1_vandvstride[i][j][k][1]=readbinary(self.usr1_advstride[i][j][k]+4,f)/4
					
					
		for i in range(self.usr1_numobj):
			for j in range(self.usr1_nummat[i]):
				self.usr1_diffuse[i][j] = readfloat(self.addr1[1]+self.usr1_objad[i]+self.usr1_matad[i][j]+0x80,f,4)
				self.usr1_ambient[i][j] = readfloat(self.addr1[1]+self.usr1_objad[i]+self.usr1_matad[i][j]+0x90,f,4)
				self.usr1_specular[i][j] = readfloat(self.addr1[1]+self.usr1_objad[i]+self.usr1_matad[i][j]+0xA0,f,4)
				self.usr1_power[i][j] = readfloat(self.addr1[1]+self.usr1_objad[i]+self.usr1_matad[i][j]+0xB0,f,4)
				self.usr1_matvoff[i][j] = readbinary(self.addr1[1]+self.usr1_objad[i]+self.usr1_matad[i][j]+0x10,f)
				self.usr1_matvlen[i][j] = readbinary(self.addr1[1]+self.usr1_objad[i]+self.usr1_matad[i][j]+0x14,f)
				
		for i in range(self.usr1_numobj):
			for j in range(self.usr1_objmesh[i]):
				for k in range(self.usr1_nummat[i]):
					self.usr1_matvoff2[i][j][k] = self.usr1_matvoff[i][k]*self.usr1_vertices[i][j]/self.usr1_indices[i][j]
					self.usr1_matvlen2[i][j][k] = self.usr1_matvlen[i][k]*self.usr1_vertices[i][j]/self.usr1_indices[i][j]
					
		#self.usr1_objtp = [[0 for j in range(X)] for i in range(Y)]		# [Y][X]
		
		self.usr2_objad = [0 for i in range(self.usr1_numobj)]
		self.usr2_objtp = [0 for i in range(self.usr1_numobj)]
		self.usr2_objhdsize = [0 for i in range(self.usr1_numobj)]
		self.usr2_obj_x = [0 for i in range(self.usr1_numobj)]
		self.usr2_obj_y = [0 for i in range(self.usr1_numobj)]
		for i in range(self.usr1_numobj):
			self.usr2_objad[i] = readbinary(self.addr1[2]+0x30+4*i,f)
			self.usr2_objtp[i] = readbinary(self.addr1[2]+self.usr2_objad[i]+0x4C,f)
			self.usr2_objhdsize[i] = readbinary(self.addr1[2]+self.usr2_objad[i]+0x20,f)
			self.usr2_obj_x[i] = readbinary(self.addr1[2]+self.usr2_objad[i]+0x3C,f)
			self.usr2_obj_y[i] = readbinary(self.addr1[2]+self.usr2_objad[i]+0x14,f)
			
		self.usr2_mattp = [[0 for j in range(0x100)] for i in range(self.usr1_numobj)]
		self.usr2_admat = [[0 for j in range(0x100)] for i in range(self.usr1_numobj)]
		for i in range(self.usr1_numobj):
			for j in range(self.usr1_nummat[i]):
				self.usr2_admat[i][j] = readbinary(self.addr1[2]+self.usr2_objad[i]+self.usr2_objhdsize[i]+4*j,f)
				self.usr2_mattp[i][j] = readbinary(self.addr1[2]+self.usr2_objad[i]+self.usr2_admat[i][j]+8,f) 
		
		self.usr3_adhobj = [0 for i in range(self.usr1_numobj)]
		self.usr3_transx = [0 for i in range(self.usr1_numobj)]
		self.usr3_transy = [0 for i in range(self.usr1_numobj)]
		self.usr3_transz = [0 for i in range(self.usr1_numobj)]
		self.usr3_hobjnum = [0 for i in range(self.usr1_numobj)]
		self.usr3_parent = [0 for i in range(self.usr1_numobj)]
		self.usr3_numchild = [0 for i in range(self.usr1_numobj)]
		for i in range(self.usr1_numobj):
			self.usr3_adhobj[i] = readbinary(self.addr1[3]+0x30+4*i,f)
			self.usr3_transx[i] = readfloat2(self.addr1[3]+self.usr3_adhobj[i]+0x30,f)
			self.usr3_transy[i] = readfloat2(self.addr1[3]+self.usr3_adhobj[i]+0x34,f)
			self.usr3_transz[i] = readfloat2(self.addr1[3]+self.usr3_adhobj[i]+0x38,f)
			self.usr3_hobjnum[i] = readshort(self.addr1[3]+self.usr3_adhobj[i]+0x40,f)
			self.usr3_parent[i] = readshort(self.addr1[3]+self.usr3_adhobj[i]+0x42,f)
			self.usr3_numchild[i] = readshort(self.addr1[3]+self.usr3_adhobj[i]+0x44,f)
		
		ls0 = range(self.usr1_numobj)
		self.usr3_objdict = dict(zip(self.usr3_hobjnum,ls0))
		
		self.usr3_child = [[0 for j in range(self.usr3_numchild[i])] for i in range(self.usr1_numobj)]
		for i in range(self.usr1_numobj):
			for j in range(self.usr3_numchild[i]):
				self.usr3_child[i][j] =  readshort(self.addr1[3]+self.usr3_adhobj[i]+0x46+2*j,f)
		
		def getparent(k):
			ls=[]
			while(self.usr3_parent[k]!=0xFFFF):
				ls.append(self.usr3_parent[k])
				k=self.usr3_parent[k]
			return ls
		
		self.usr3_parentls = [0 for i in range(self.usr1_numobj)]
		for i in range(self.usr1_numobj):
			self.usr3_parentls[i]=getparent(i)
		
		
		f.close()
			
	

	
	def writeuser(self, a, filein) :
		f = open(filein,'rb')
		os.mkdir(filein+'_USER')
		os.chdir(filein+'_USER')
		f_name = os.path.basename(filein)
		for i in range(4):
			f.seek(self.addr1[i],0)
			self.data[i] = f.read(self.size[i])
			self.name[i] = f_name + "_%0d"%i + ".usr"
			f3 = open(self.name[i],'wb')
			f3.writelines(list(self.data[i]))
			f3.close()
			
		os.chdir("..")
		f.close()

	def transparent(self, filein, fileout):
		f = open(filein,'rb')
		f2 = open(fileout,'ab')
		buff0 = f.read(self.addr1[1]+self.usr1_objad[0]+self.usr1_matad[0][0]+0x50-1)
		buff = [[0 for j in range(0x100)] for i in range(self.usr1_numobj)]
		for i in range(self.usr1_numobj):
			for j in range(self.usr1_nummat[i]):
				buff[i][j] = f.read()
				f2.write(buff[i][j])
				f2.write(pack('B', 0x01))
				f.seek(self.addr1[1]+self.usr1_objad[i]+self.usr1_matad[i][j]+0x50,0)
		#buff2 = f.read()
		#f2.write(buff2)
		#f.close()
		#f2.close()
		
def readbinary(ad, f) :
	f.seek(ad,0)
	temp1 = f.read(4)
	temp2 = hexlify(temp1)
	return int(temp2,16)

def readshort(ad, f) :
	f.seek(ad,0)
	temp1 = f.read(2)
	temp2 = hexlify(temp1)
	return int(temp2,16)

def readfloat(ad, f, numfloat) :
	f.seek(ad,0)
	floatarray = array('f')
	floatarray.fromfile(f,numfloat)
	floatarray.byteswap()
	return floatarray

def readfloat2(ad, f) :
	f.seek(ad,0)
	floatarray = array('f')
	floatarray.fromfile(f,1)
	floatarray.byteswap()
	return floatarray[0]

def shortarr(ad, f, numshort) :
	f.seek(ad,0)
	shortarray = array('f')
	shortarray.fromfile(f,numshort)
	return shortarray

def rewriteshort(ad, x, fold) :
	fin = open(fold,'rb')
	fout = open(fold+'_','ab')
	
	off1=fin.read(ad-1)
	fout.write(off1)
	fout.write(pack('>H',x))
	fin.seek(ad+1,0)
	off2=fin.read()
	fout.write(off2)
	fin.close()
	fout.close()

			
			
##########################################################################
''' SubClass DDS_data '''
##########################################################################
class DDS_data(TPR_data) :
	
	def __init__(self ,a , filein, Flagdoa4 ):	######### a is a name of SuperClass instance
		self.type = [0 for i in range(a.numdds)] 
		self.addr1 = [0 for i in range(a.numdds)] 
		self.addr2 = [0 for i in range(a.numdds)] 
		self.size = [0 for i in range(a.numdds)] 
		self.width = [0 for i in range(a.numdds)] 
		self.height = [0 for i in range(a.numdds)] 
		self.name = [0 for i in range(a.numdds)]  
		
		f = open(filein,'rb')
		offset1 = 0
		
		for i in range(a.numdds):
			f.seek(0x54+0x10*i,0)
			temp3 = f.read(4)
			temp4 = hexlify(temp3)
			
			f.seek(int(temp4,16)+0x2C+Flagdoa4,0)								##### doax2 ####
			temp4 = f.read(4)
			temp6 = hexlify(temp4)
			
			self.type[i] = int(temp6,16)%0x1000
			
			if i != a.numdds-1 : f.seek(0x54+0x10*(i+1),0)
			if i == a.numdds-1 : f.seek(0x54+0x10*i,0)
			temp7 = f.read(4)
			temp8 = hexlify(temp7)
			
			if i != a.numdds-1 : f.seek(int(temp8,16)+0x2C+Flagdoa4, 0)			##### doax2 ####
			if i == a.numdds-1 : f.seek(int(temp8,16)+(0x2C+Flagdoa4)*2, 0)		##### doax2 ####
			temp9 = f.read(4)
			temp10 = hexlify(temp9)
			offset2 = (int(temp10,16)/0x1000)*0x1000
			
			self.addr1[i] = a.startad + offset1
			self.addr2[i] = a.startad + offset2
			self.size[i] = offset2-offset1
			
			self.name[i] = ('filein' + '_' + '%02d'%i + '.dds')
			
			if i != a.numdds-1 : f.seek(int(temp8,16)-0x4,0)
			if i == a.numdds-1 : f.seek(int(temp8,16)+0x30+Flagdoa4,0)			##### doax2 ####
			temp11 = f.read(4)
			temp12 = hexlify(temp11)
			if int(temp12,16) == 0 : 
				self.width[i] = 0x00 
				self.height[i] = 0x000 
			if int(temp12,16) != 0 : 
				self.width[i] = int(temp12,16)/0x10000
				self.height[i] = int(temp12,16)%0x1000
			
			offset1 = offset2
			
		f.close()
		
		

	##########################################################################
	#### function addheader
	##########################################################################
	def addheader(self,filein,w,h,ddssize,ddstype,ddsname):
		header=[]
		header.append(0x44445320) # 'DDS'
		header.append(0x7C000000) # 124
		#0x07100800->0x0F10000
		if ddstype==0x52 : header.append(0x0F100000) # dwFlags (combination of effective information)
		if ddstype==0x53 : header.append(0x0F100000)
		if ddstype==0x54 : header.append(0x0F100000)
		if ddstype==0x86 : header.append(0x0F100000)

		if w==0x00 : header.append(0x08000000) # 8 tate size
		if w==0x01 : header.append(0x10000000) # 16
		if w==0x03 : header.append(0x20000000) # 32
		if w==0x07 : header.append(0x40000000) # 64
		if w==0x0F : header.append(0x80000000) # 128
		if w==0x1F : header.append(0x00010000) # 256
		if w==0x3F : header.append(0x00020000) # 512
		if w==0x7F : header.append(0x00040000) # y = 1024
		if w==0xFF : header.append(0x00080000)

		if h==0x000 : header.append(0x08000000) # 8 yoko size
		if h==0x001 : header.append(0x08000000) # 8
		if h==0x003 : header.append(0x08000000) # 8
		if h==0x007 : header.append(0x08000000) # 8
		if h==0x00F : header.append(0x08000000) # 8
		if h==0x01F : header.append(0x20000000) # 32
		if h==0x03F : header.append(0x40000000) # 64
		if h==0x07F : header.append(0x80000000) # 128
		if h==0x0FF : header.append(0x00010000) # 256
		if h==0x1FF : header.append(0x00020000) # 512
		if h==0x3FF : header.append(0x00040000) # 1024
		if h==0x7FF : header.append(0x00080000) # x = 2048

		if ddstype==0x86 : 
			header.append(0x80030000) # 0x0000000->0x80030000
		else : # size of texture, or linearsize
			if ddssize==0x1000 : header.append(0x00100000)
			if ddssize==0x2000 : header.append(0x00200000)
			if ddssize==0x4000 : header.append(0x00400000)
			if ddssize==0x6000 : header.append(0x00600000)
			if ddssize==0x8000 : header.append(0x00800000)
			if ddssize==0xA000 : header.append(0x00A00000)
			if ddssize==0xB000 : header.append(0x00B00000)
			if ddssize==0xC000 : header.append(0x00C00000)
			if ddssize==0xE000 : header.append(0x00E00000)
			if ddssize==0x10000 : header.append(0x00000100)
			if ddssize==0x16000 : header.append(0x00600100)
			if ddssize==0x1A000 : header.append(0x00A00100)
			if ddssize==0x14000 : header.append(0x00400100)
			if ddssize==0x20000 : header.append(0x00000200)
			if ddssize==0x2B000 : header.append(0x00B00200)
			if ddssize==0x2C000 : header.append(0x00C00200)
			if ddssize==0x30000 : header.append(0x00000300)
			if ddssize==0x34000 : header.append(0x00400300)
			if ddssize==0x40000 : header.append(0x00000400)
			if ddssize==0x56000 : header.append(0x00600500)
			if ddssize==0x5A000 : header.append(0x00A00500)
			if ddssize==0x80000 : header.append(0x00000800)
			if ddssize==0x60000 : header.append(0x00000600)
			if ddssize==0xB0000 : header.append(0x00000B00)
			if ddssize==0x100000 : header.append(0x00001000)
			if ddssize==0x156000 : header.append(0x00601500)
			if ddssize==0x200000 : header.append(0x00002000)

		header.append(0x00000000) # z size
		header.append(0x00000000) # level of mipmap
		header.append(0x00000000) # reserved
		header.append(0x00000000) # reserved
		header.append(0x00000000) # reserved
		header.append(0x00000000) # reserved
		header.append(0x00000000) # reserved
		header.append(0x00000000) # reserved
		header.append(0x00000000) # reserved
		header.append(0x00000000) # reserved
		header.append(0x00000000) # reserved
		header.append(0x00000000) # reserved
		header.append(0x00000000) # reserved
		header.append(0x20000000) # 32
	
		if ddstype==0x52 : header.append(0x04000000) # dwPfFlags (combination of DDPF)
		if ddstype==0x53 : header.append(0x04000000)
		if ddstype==0x54 : header.append(0x04000000)
		if ddstype==0x86 : header.append(0x41000000)

		if ddstype==0x52 : header.append(0x44585431) # 'DXT1'(dwFourCC)
		if ddstype==0x53 : header.append(0x44585435) 
		if ddstype==0x54 : header.append(0x44585435) # changed!0x44585435
		if ddstype==0x86 : header.append(0x00000000)

		if ddstype==0x52 : header.append(0x00000000) # bits of a pixel(dwBitCount)
		if ddstype==0x53 : header.append(0x00000000)
		if ddstype==0x54 : header.append(0x00000000)
		if ddstype==0x86 : header.append(0x20000000)

		if ddstype==0x52 : header.append(0x00000000) # dwRBitMask
		if ddstype==0x53 : header.append(0x00000000)
		if ddstype==0x54 : header.append(0x00000000)
		if ddstype==0x86 : header.append(0x0000FF00)

		if ddstype==0x52 : header.append(0x00000000) # dwGBitMask
		if ddstype==0x53 : header.append(0x00000000)
		if ddstype==0x54 : header.append(0x00000000)
		if ddstype==0x86 : header.append(0x00FF0000)

		if ddstype==0x52 : header.append(0x00000000) # dwBBitMask
		if ddstype==0x53 : header.append(0x00000000)
		if ddstype==0x54 : header.append(0x00000000)
		if ddstype==0x86 : header.append(0xFF000000)

		if ddstype==0x52 : header.append(0x00000000) # dwRGBAlphaBitMask
		if ddstype==0x53 : header.append(0x00000000)
		if ddstype==0x54 : header.append(0x00000000)
		if ddstype==0x86 : header.append(0x000000FF)
	
		if ddstype==0x52 : header.append(0x00100000) # dwcaps (flags of mipmap etc)
		if ddstype==0x53 : header.append(0x08100000)
		if ddstype==0x54 : header.append(0x08100000) #0x00100000->0x08100000
		if ddstype==0x86 : header.append(0x08100000) #0x00100000->0x08100000

		header.append(0x00000000) # dwcaps2 (flags of cube/volume texture etc)
		header.append(0x00000000) # reserved
		header.append(0x00000000) # reserved
		header.append(0x00000000) # reserved


		f3=open(ddsname,'ab')
		for i in range(32):
			f3.write(pack('>L',header[i]))
	
		f3.close()

	def swap16bit(self,r):
		for i in range(len(r)/2):
			r[2*i:2*i+2]=(r[2*i+1],r[2*i])
		return r

	def swap32bit(self,r):
		for i in range(len(r)/4):
			r[4*i:4*i+4]=(r[4*i+3],r[4*i+2],r[4*i+1],r[4*i])
		return r

	def swap64bit(self,r):
		for i in range(len(r)/4):
			r[4*i:4*i+4]=(r[4*i+2],r[4*i+3],r[4*i],r[4*i+1])
		return r

	##########################################################################
	### function removeheader_and_insert
	##########################################################################
	def removeheader_and_insert(self,offset2,offset1,ddstype,w,h,filein,fileout):
		f5 = open(filein,'rb')
		temp14 = f5.read()
		f5.close
		if len(temp14)-0x80 != offset2-offset1 :
			raise ValueError, 'filesize different'
		
		else:
			"""
			temp14 = list(temp14)
			del temp14[0:128]
			if ddstype == 0x52 or 0x54 :  temp14 = self.swap16bit(temp14)
			if ddstype == 0x86 : temp14 = self.swap64bit(temp14)
			"""
			
			if h==0x00F : x3=16
			elif h==0x01F : x3=32
			elif h==0x03F : x3=64
			elif h==0x07F : x3=128
			elif h==0x0FF : x3=256
			elif h==0x1FF : x3=512
			elif h==0x3FF : x3=1024
			elif h==0x7FF : x3=2048
			else : x3=0
				
			if w==0x01 : y3=16
			elif w==0x03 : y3=32
			elif w==0x07 : y3=64
			elif w==0x0F : y3=128
			elif w==0x1F : y3=256
			elif w==0x3F : y3=512
			elif w==0x7F : y3=1024
			elif w==0xFF : y3=2048
			else : y3,x3=0,0
			
			
			if x3!=0 or y3!=0:
				if ddstype == 0x52 : fc.swzdxt1(x3,y3,filein)
				elif ddstype == 0x54 : fc.swzdxt5(x3,y3,filein)
				elif ddstype == 0x86 : fc.swzargb(x3,y3,filein)
				f7 = open(filein+'_swizzled.dds','rb')
				temp20 = f7.read()
				temp21 = list(temp20)
				del temp21[0:128]
				if ddstype == 0x52 or 0x54 :  temp22 = self.swap16bit(temp21)
				if ddstype == 0x86 : temp22 = self.swap64bit(temp21)
				hh22 = temp22
				f7.close
				
			else :
				print 'x < 64'
				temp14 = list(temp14)
				del temp14[0:128]
				if ddstype == 0x52 or 0x54 :  temp14 = self.swap16bit(temp14)
				if ddstype == 0x86 : temp14 = self.swap64bit(temp14)
				hh22 = temp14
				
			f5 = open(fileout,'rb')
			temp19 = f5.read(offset1)
			f5.close()
			
			f6 = open(fileout+'_M','ab')
			f6.write(temp19)
			
			print 'injecting.....'
			#temp17[offset1:offset2] = hh22
			f6.writelines(hh22)
			
			f5 = open(fileout,'rb')
			f5.seek(offset2,0)
			temp18 = f5.read()
			f5.close()
			f6.write(temp18)
			f6.close()
		print 'done!'

			
		return

##########################################################################
''' Subclass VBUF_data  '''
##########################################################################
class VBUF_data(TPR_data):
	def __init__(self,a,filein, Flagdoa4):
		self.addr1 = [0 for i in range(a.numvbf)]
		self.addr2 = [0 for i in range(a.numvbf)]
		self.numvertex = [0 for i in range(a.numvbf)]
		self.name = [0 for i in range(a.numvbf)]
		self.size = [0 for i in range(a.numvbf)]
		self.info = [0 for i in range(a.numvbf)]
		self.data = [0 for i in range(a.numvbf)]
		
		f = open(filein, 'rb')
		#offset = 0
		
		for i in range(a.numvbf):
			f.seek(((1+a.numusr+a.numdds)*0x10+0x4)+0x10*i,0)
			temp21 = f.read(4)
			temp22 = hexlify(temp21)
			f.seek(int(temp22,16)+0xC+0x18+Flagdoa4,0)				#doax2
			temp23 = f.read(4)		#vbf offset
			temp24 = hexlify(temp23)
			self.addr1[i] = ((int(temp24,16)/0x1000)*0x1000)+0x1000
			#print 'vbfad1 = %X' % vbfad1_int,
			
			f.seek(int(temp22,16)+0xC+0x18+0x4+Flagdoa4,0)			#doax2
			temp26 = f.read(4)		#unknown information about vbf
			temp27 = hexlify(temp26)
			self.info[i] = int(temp27,16)
			#print 'vbfinfo = %X' % vbfinfo_int,

		f.close()
	##########################################################################
	### function write_vbf
	##########################################################################

	def write_vbuf(self, a, filein):
		f = open(filein, 'rb')
		os.mkdir(filein+'_VBUF')
		os.chdir(filein+'_VBUF')
		f_name = os.path.basename(filein)
		
		for i in range(a.numvbf):
			f.seek(self.addr1[i] + a.startad - 0x1000,0)
			self.data[i] = f.read(self.info[i])
			
			#vbfdata_swap = swap16bit(list(vbfdata))
			self.name[i] = f_name + "_%03d"%i + ".vbf"
			f3 = open(self.name[i],'wb')
			f3.writelines(list(self.data[i]))
			f3.close()
		
		os.chdir("..")
		f.close()

	##########################################################################
	### function write_vbufobj
	##########################################################################

	def write_vbufobj(self, a, filein):
		f = open(filein, 'rb')
		os.mkdir(filein+'_OBJ')
		os.chdir(filein+'_OBJ')
		f_name = os.path.basename(filein)
		
		for i in range(a.numvbf):
			f.seek(self.addr1[i] + a.startad - 0x1000,0)
			self.name[i] = f_name + "_%03d"%i + ".x"
			f2 = open(self.name[i],'a')

			f2.write('xof 0303txt 0032\nMesh Mesh_filename\n{\n\t%d;\n' % (self.info[i]/0x24)) 
			for j in range(self.info[i]/0x24 ):  ##0x2C ##0x28 ##0x24 ##(=vertex stride *4)
				f2.write('\t')
				armax = array('f')
				armax.fromfile(f,3)
				armax.byteswap()
				for k in range(3):
					f2.write("%0.8f;" % armax[k])
				
				f.seek(4*6,1)   ##4*6? wrong -> ##4*4 ##4*5 ##4*6 ##(4,5,6 ='vertex stride'-3)
				f2.write(",\n")
			f2.write("\n")
			f2.close()
			
		
		os.chdir("..")
		f.close()

##########################################################################
''' Subclass Ibuf_data '''
##########################################################################

class IBUF_data(TPR_data):
	def __init__(self,a,filein,Flagdoa4):
		self.addr1 = [0 for i in range(a.numibf)]
		self.addr2 = [0 for i in range(a.numibf)]
		self.numvertex = [0 for i in range(a.numibf)]
		self.name = [0 for i in range(a.numibf)]
		self.size = [0 for i in range(a.numibf)]
		self.info = [0 for i in range(a.numibf)]
		self.data = [0 for i in range(a.numibf)]
		self.numsurface = [0 for i in range(a.numibf)]
		
		f = open(filein, 'rb')
		#offset = 0
		
		for i in range(a.numibf):
			f.seek(((1+a.numusr+a.numdds+a.numvbf)*0x10+0x4)+0x10*i,0)
			temp30 = f.read(4)
			temp31 = hexlify(temp30)
			f.seek(int(temp31,16)+0xC+0x18+Flagdoa4,0)
			temp32 = f.read(4)		#ibf offset
			temp33 = hexlify(temp32)
			self.addr1[i] = ((int(temp33,16)/0x1000)*0x1000)+0x1000
			#print 'ibfad1 = %X' % ibfad1_int,
			
			f.seek(int(temp31,16)+0xC+0x18+0x4+Flagdoa4,0)
			temp34 = f.read(4)		#filesize of ibuff
			temp35 = hexlify(temp34)
			self.info[i] = int(temp35,16)
			#print 'ibfinfo = %X' % ibfinfo_int,
			
			ad = self.addr1[i] + a.startad - 0x1000
			ls=[]
			for j in range(self.info[i]/2):
				if(j<10 or readshort(ad,f) != 0):
					ls.append(readshort(ad,f))
					ad+=2
			ls4=[]
			ls4=ls[0:4]
			m=0
			lsc=[]
			counter=0
	
			#fout.seek(10,1)#10
			#fout.write('\n')
			try:
				while(ls4[2] != 0 or ls4[3] != 0):
					ls4=ls[m:m+4]
					if ls4[2] != 65535:
						counter+=1
						lsc=ls4[0:4]
						lsc.reverse()
						if lsc[0]!=65535 and len(lsc)==4:
							counter+=1
							m+=2
						else:
							m+=4
					else:
						m+=3
				else:
					#print counter
					pass
			except IndexError:
				#print counter
				pass
			self.numsurface[i] = counter
		f.close()

	##########################################################################
	### function write_ibuf
	##########################################################################
	def write_ibuf(self,a,filein):
		f = open(filein, 'rb')
		os.mkdir(filein+'_IBUF')
		os.chdir(filein+'_IBUF')
		f_name = os.path.basename(filein)
		
		for i in range(a.numibf):
			f.seek(self.addr1[i] + a.startad - 0x1000,0)
			self.data[i] = f.read(self.info[i])
			
			#ibfdata_swap = swap16bit(list(ibfdata))
			self.name[i] = f_name + "_%03d"%i + ".ibf"
			f3 = open(self.name[i],'wb')
			f3.writelines(list(self.data[i]))
			f3.close()
		
		os.chdir("..")		
		f.close()

	##########################################################################
	### function write_ibuftoobj
	##########################################################################
	def write_ibufobj(self, a, filein):
		f = open(filein, 'rb')
		os.mkdir(filein+'_OBJ')
		os.chdir(filein+'_OBJ')
		f_name = os.path.basename(filein)
		
		
		
		
		for i in range(a.numibf):
			self.name[i] = f_name + "_%03d"%i + ".obj"
			f2 = open(self.name[i],'a')
			f.seek(self.addr1[i] + a.startad - 0x1000,0)
			

			temp71 = f.read(self.info[i])
			temp72 = hexlify(temp71)
			temp73 = int(temp72,16)
			temp74 = str(temp72)
			#temp74 = temp74.upper()
			numv = temp74.count('FFFF')
			als = [0 for i in range(len(temp74)/4+1)]
			bls = [[0 for i in range(3)] for j in range(len(temp74)/4+1)]
			for l in range(len(temp74)/4):
				als[l] = temp74[4*l:4*l+4]
			
			
			bls[0][0] = als[0]
			bls[0][1] = als[1]
			bls[0][2] = als[2]
			
			print bls[0][0]
			for i in range(numv*3):
				v = als.index("FFFF")
				f2.write('f ')
				bls[2*i+1][0] = copy.copy(bls[2*i][0])
				bls[2*i+1][1] = als[2]
				bls[2*i+1][2] = copy.copy(bls[2*i][1])
				bls[2*i+2] = bls[2*i+1].reverse
				
				for j in range(v):
					f2.write("%i//%i " % (int(bls[i][j]), i+1) )
					
				f2.write("\n")
				del als[0:v+1]

			f2.close()
			
		
		os.chdir("..")
		f.close()
		

###### function : export_all_DDS ######
def export_all_DDS(filein,a,b) :
	f4 = open(filein, 'rb')
	os.mkdir(filein+'_DDS')
	os.chdir(filein+'_DDS')
	th=0
	for i in range(a.numdds):
		
		f4.seek( b.addr1[i],0)
		ddsdata = f4.read(b.size[i])
		if b.type[i] == 0x52 or 0x53 or 0x54 : ddsdata_swap = b.swap16bit(list( ddsdata ))
		if b.type[i] == 0x86 : ddsdata_swap = b.swap32bit(list( ddsdata ))	

		b.addheader(filein, b.width[i], b.height[i], b.size[i], b.type[i], filein+'_%02d'%i+'.dds')
		f2 = open(filein+'_%02d'%i+'.dds','ab')
		f2.writelines(ddsdata_swap)
		f2.close()
		
	#print 'please wait...'
	for i in range(a.numdds):
		
		if b.height[i]==0x00F : x3=16
		elif b.height[i]==0x01F : x3=32
		elif b.height[i]==0x03F : x3=64
		elif b.height[i]==0x07F : x3=128
		elif b.height[i]==0x0FF : x3=256
		elif b.height[i]==0x1FF : x3=512
		elif b.height[i]==0x3FF : x3=1024
		elif b.height[i]==0x7FF : x3=2048
		else : x3=0
			
		if b.width[i]==0x01 : y3=16
		elif b.width[i]==0x03 : y3=32
		elif b.width[i]==0x07 : y3=64
		elif b.width[i]==0x0F : y3=128
		elif b.width[i]==0x1F : y3=256
		elif b.width[i]==0x3F : y3=512
		elif b.width[i]==0x7F : y3=1024
		elif b.width[i]==0xFF : y3=2048
		else : y3,x3=0,0
			
		if b.type[i] == 0x86 :
			if x3!=0 or y3!=0:
			
				fc.unsargb(x3,y3,filein+'_%02d'%i+'.dds')
				#os.remove(filein+'_%02d'%i+'.dds')
				#os.rename(filein+'_%02d'%i+'.dds'+'_uns.dds',filein+'_%02d'%i+'.dds')
			
		elif b.type[i] == 0x52 :
		
			if x3 !=0  and y3!=0:
			
				fc.unsdxt1(x3,y3,filein+'_%02d'%i+'.dds')
				#os.remove(filein+'_%02d'%i+'.dds')
				#os.rename(filein+'_%02d'%i+'.dds'+'_uns.dds',filein+'_%02d'%i+'.dds')
			#elif x3 == 64 and y3!=0:
				#fc.unsdxt1_64(x3,y3,filein+'_%02d'%i+'.dds')
				#os.remove(filein+'_%02d'%i+'.dds')
				#os.rename(filein+'_%02d'%i+'.dds'+'_uns.dds',filein+'_%02d'%i+'.dds')
			else:
				pass
		elif b.type[i] == 0x53 :
		
			if x3 !=0 and y3!=0:
			
				fc.unsdxt5(x3,y3,filein+'_%02d'%i+'.dds')
				#os.remove(filein+'_%02d'%i+'.dds')
				#os.rename(filein+'_%02d'%i+'.dds'+'_uns.dds',filein+'_%02d'%i+'.dds')
			else:
				pass
		
		elif b.type[i] == 0x54 :
		
			if x3 !=0 and y3!=0:
			
				fc.unsdxt5(x3,y3,filein+'_%02d'%i+'.dds')
				#os.remove(filein+'_%02d'%i+'.dds')
				#os.rename(filein+'_%02d'%i+'.dds'+'_uns.dds',filein+'_%02d'%i+'.dds')
			else:
				pass
			
		else: 
			pass
		print '%02d th dds exported' % th
		th += 1
	print 'done!'
	f4.close()
	os.chdir("..")

	##########################################################################
	### function dxt1_to_5
	##########################################################################
def dxt1to5(i,fileout):
	f = open(fileout,'rb')
	f.seek(0x54+0x10*i,0)
	temp7 = f.read(4)
	temp8 = hexlify(temp7)
	f.seek(0,0)
	fa = f.read(int(temp8,16)+0x2F-1)
	f.seek(0,1)
	temp12 = f.read(2)
	temp13 = hexlify(temp12)
	temp14 = int(temp13,16)+2
	f.seek(int(temp8,16)+0x2F+2,0)
	temp9 = f.read(1)
	temp10 = hexlify(temp9)
	temp11 = int(temp10,16)/2
	#temp12 = unhexlify(temp11)
	f.seek(0,1)
	fb = f.read()
	f.close()
	f2 = open(fileout,'wb')
	f2.write(fa)
	f2.seek(int(temp8,16)+0x2F-1,0)
	f2.write(pack('>H', temp14))
	f2.seek(1,1)
	f2.write(pack('B', temp11))
	f2.write(fb)
	f2.close()

	##########################################################################
	### function transparentTPR
	##########################################################################
def transparentTPR(filein,tprdat,usrdat):
	fin = open(filein,'rb')
	ad1 = [[0 for j in range(0x100)] for i in range(usrdat.usr1_numobj)]
	ad2 = [[0 for j in range(0x100)] for i in range(usrdat.usr1_numobj)]
	lstpr = list(fin.read())
	for i in range(usrdat.usr1_numobj):
		lstpr[usrdat.addr1[2]+usrdat.usr2_objad[i]+0x4C+3:usrdat.addr1[2]+usrdat.usr2_objad[i]+0x4C+3+1] = '\x04'
		for j in range(usrdat.usr1_nummat[i]):
			ad1[i][j] = usrdat.addr1[1]+usrdat.usr1_objad[i]+usrdat.usr1_matad[i][j]+0x50+3
			ad2[i][j] = usrdat.addr1[2]+usrdat.usr2_objad[i]+usrdat.usr2_admat[i][j]+8+3
			lstpr[ad1[i][j]:ad1[i][j]+1] = '\x01'
			lstpr[ad2[i][j]:ad2[i][j]+1] = '\x04'
	fin.close()
	fout = open(filein+'T','ab')
	fout.writelines(lstpr)
	fout.close()
	
	##########################################################################
	###function writeXFile
	##########################################################################
def calcVStride(filein,tprdat,ddsdat,vbfdat,usrdat,vb) :
	fin = open(filein,'rb')
	vstrd=[8,8,8,8,8,8,8,8,8,8,8,8,3,3,3,3]
	counter4=0
	fin.seek(vbfdat.addr1[vb] + tprdat.startad - 0x1000,0)
	flar = array('f')
	flar.fromfile(fin,vbfdat.info[vb]/4)
	flar.byteswap()
	try:
		for i in range(3,16):
			for j in range(i,5*i+1,i):
				if ( not((10**(-5))<abs(flar[j])<1 or flar[j]==0) or not((10**(-5))<abs(flar[j+1])<1 or flar[j+1]==0) or not((10**(-5))<abs(flar[j+2])<1 or flar[j+2]==128) ):	#or ( not(abs(flar[j+3])>10**20 or abs(flar[j+3])<10**(-20) or str(flar[j+3])=='1.#QNAN' ) ):
					break
				else :
					pass
			else:
				vstrd[counter4] = i
				print 'vstrd[%d]=%X'%(counter4,vstrd[counter4])
				counter4+=1
				#break
		print vstrd
	except IndexError :
		vstrd = [3 for i in range(len(vstrd))]
		print 'IndexError'
		print vstrd
	return vstrd

def ShortToFloat(u):
	e = (u>>10)&0b11111
	m = u&0b1111111111
	mfloat = 0
	for k in range(1,11):
		mfloat += (1.0/(2**k))*((m&(2**(10-k)))>>(10-k))
	shortfloat = (1+mfloat)*(2**(e-(2**4-1)))
	return shortfloat

	"""
	if ushort > 0:
		ufloat = ushort/32767.0 - 1.0
	else:
		ufloat = ushort/32768.0 + 1.0 
	
	#ufloat = 0.2*(ushort-8000.0)/1000.0
	#ufloat=ushort
	#return ufloat
	
	if ushort == 0:
		return 0.0
	s = ushort&0x8000
	e = ((ushort & 0x7c00) >>10)-15+127
	f=  ushort & 0x03ff
	fval= (s<<16) | ((e <<23)&0x7f800000) | (f<<13)
	return (float)(fval )
	"""
def getparent(k):
	ls=[]
	while(self.usr3_parent[k]!=0xFFFF):
		ls.append(self.usr3_parent[k])
		k=self.usr3_parent[k]
	return ls

def writeMqoFile(filein,tprdat,ddsdat,vbfdat,ibfdat,usrdat,vb,ib,vstride,ShortToFloat,ObjNumber,MeshNumber,MatOffset):
	
	hObjNumber = usrdat.usr3_objdict[ObjNumber]
	dx=usrdat.usr3_transx[hObjNumber]
	dy=usrdat.usr3_transy[hObjNumber]
	dz=usrdat.usr3_transz[hObjNumber]
	for j in range(len(usrdat.usr3_parentls[hObjNumber])):
		dx += usrdat.usr3_transx[usrdat.usr3_parentls[hObjNumber][j]]
		dy += usrdat.usr3_transy[usrdat.usr3_parentls[hObjNumber][j]]
		dz += usrdat.usr3_transz[usrdat.usr3_parentls[hObjNumber][j]]
	fin = open(filein,'rb')
	#i =  #i=0	#obj no banngou 0 kara numobj made
	fout = open(filein+'_%dv_%di.mqo'%(vb,ib),'w')
	fout.write('Metasequoia Document\nFormat Text Ver 1.0\n\nMaterial %d {\n' % (usrdat.usr1_nummat[ObjNumber]))
	for j in range(usrdat.usr1_nummat[ObjNumber]):
		fout.write('\t\"mat-'+filein+'-%d-%d-%d\" shader(3) col(1.0 1.0 1.0 1.0) dif(0.270) amb(0.740) emi(0.650) spc(0.090) power(40.00) tex('\
		 % (ObjNumber,MeshNumber,j) ) 
		fout.write('\"'+filein+'_%02d.dds_uns.dds\"'%(usrdat.usr1_matdds[ObjNumber][j][0]))
		fout.write(') aplane() bump()')
		for k in range(1,usrdat.usr1_matnumdds[ObjNumber][j]):
			fout.write('\"'+filein+'_%02d.dds_uns.dds\"'%(usrdat.usr1_matdds[ObjNumber][j][k]))
		fout.write('\n')
	fout.write('}\n')
	#j = MeshNumber #j=0 #objmesh no bangou 0 kara usr1_objmesh[i] made
	fout.write('Object "obj-'+filein+'-%d-%d" {\n\tvertex %d {\n' % (ObjNumber,MeshNumber,usrdat.usr1_vertices[ObjNumber][MeshNumber]))
	fin.seek(vbfdat.addr1[vb] + tprdat.startad - 0x1000,0)
	flar = array('f')
	flar.fromfile(fin,vbfdat.info[vb]/4)
	flar.byteswap()
	for i in range(0,vbfdat.info[vb]/4,vstride):			# '9' = vertexstride+1
		fout.write('\t\t')
		if len(flar[i:]) >= 3:
			fout.write('%0.10f '%(flar[i+0]+dx))
			fout.write('%0.10f '%(flar[i+1]+dy))
			fout.write('%0.10f '%(flar[i+2]+dz))
		fout.write('\n')
	fout.write('\t}\n')
	
	
	ad = ibfdat.addr1[ib] + tprdat.startad - 0x1000
	"""
	ls=[]
	for i in range(ibfdat.info[ib]/2):
		if(i<10 or readshort(ad,fin) != 0):
			ls.append(readshort(ad,fin))
			ad+=2
	ls4=[]
	ls4=ls[0:4]
	m=0
	lsc=[]
	counter=0
	"""
	#####kokokara ibuff kakinaoshi
	fin.seek(ad,0)
	finread1 = fin.read(ibfdat.info[ib])
	strfin = str(hexlify(finread1))
	ffffcount = strfin.count('ffff')
	lsfin = list(finread1)
	fin.seek(ad,0)
	ibuffls=[[] for i in range(ffffcount+1)]
	face = 0
	for i in range(ibfdat.info[ib]/2): #filesize/2
		if readshort(ad,fin) != 65535:
			ibuffls[face].append(readshort(ad,fin))
			ad+=2
		else :
			face+=1
			ad+=2
	try:
		while(ibuffls[face][-1]==0):
			ibuffls[face].pop()
	except IndexError:
		pass
	
	def ibufspliter(list):
		splitedlist =[] #[0 for i in range(len(list)-2)]#[[] for i in range(len(list)-2)]
		for i in range(len(list)-2):
			if i%2==0:
				splitedlist.append([list[i+2],list[i+1],list[i]]) #list[i:i+3] #splitedlist[i].append(list[i*2:i*2+3].reverse())
			else:
				splitedlist.append(list[i:i+3])
		"""
		if len(list)==3 :
			splitedlist = [list[2::-1]] #list.reverse()
		elif len(list)==4 :
			splitedlist = [list[2::-1],list[1:4]] #[list[0:3].reverse(),list[1:4]]
		elif len(list)==5 :
			splitedlist = [list[2::-1],list[1:4],[list[4],list[3],list[2]]] #[list[0:3].reverse(),list[1:4],list[2:5].reverse()]
		elif len(list)==6 :
			splitedlist = [list[2::-1],[list[5],list[4],list[3]]] #[list[0:3].reverse(),list[3:6].reverse()]
		elif len(list)==7 :
			splitedlist = [list[2::-1],[list[6],list[5],list[4]],list[1:4]] #[list[0:3].reverse(),list[4:7].reverse(),list[1:4]]
		else :
			splitedlist =[] #[0 for i in range(len(list)-2)]#[[] for i in range(len(list)-2)]
			for i in range(len(list)-2):
				if i%2==0:
					splitedlist.append([list[i+2],list[i+1],list[i]]) #list[i:i+3] #splitedlist[i].append(list[i*2:i*2+3].reverse())
				else:
					splitedlist.append(list[i:i+3])
		"""
		return splitedlist
	####kokomade Ibuff kakinaoshi
	fin.seek(vbfdat.addr1[vb] + tprdat.startad - 0x1000,0)
	shortarray = array('h')
	shortarray.fromfile(fin,2*vbfdat.info[vb]/4)
	shortarray.byteswap()
	if vstride == 5:
		numtex = 1
	else:
		numtex = vstride - 5
	numvertex = vbfdat.info[vb]/4/vstride
	uv =[[[0 for k in range(2)] for j in range(numtex)] for i in range(numvertex)]
	for i in range(numvertex):	#number of vertex
		for j in range(numtex):						#number of texture
			uv[i][j][0] = ShortToFloat(shortarray[(vstride*2)*i + 8+2*j])
			uv[i][j][1] = ShortToFloat(shortarray[(vstride*2)*i + 8+2*j + 1])
	"""
	vlen2ls=[]
	for i in range(len(usrdat.usr1_matvlen2)):
		for j in range(len(usrdat.usr1_matvlen2[i])):
			vlen2ls += usrdat.usr1_matvlen2[i][j]
	vlen2gen = (vlen2ls[i] for i in range(len(vlen2ls)))
	"""
	nextmat=0+MatOffset
	nextv=usrdat.usr1_matvlen2[ObjNumber][MeshNumber][nextmat]
	MatNumber=0
	matcounter=0
	counter=0
	fout.write('\tface %d {\n' % (ibfdat.numsurface[ib]))
	###kokokara ibuffwrite kakinaoshi
	for i in range(ffffcount+1):
		for j in range(len(ibufspliter(ibuffls[i]))):
			fout.write('\t\t3 V('+str(ibufspliter(ibuffls[i])[j][0])+' '+str(ibufspliter(ibuffls[i])[j][1])+' '+str(ibufspliter(ibuffls[i])[j][2])\
				+') M(%d) UV(%0.8f %0.8f %0.8f %0.8f %0.8f %0.8f)\n' % \
			(MatNumber,\
			#uv[ibufspliter(ibuffls[i])[j][0]][0][0],uv[ibufspliter(ibuffls[i])[j][0]][0][1],\
			# uv[ibufspliter(ibuffls[i])[j][1]][0][0],uv[ibufspliter(ibuffls[i])[j][1]][0][1],\
			 # uv[ibufspliter(ibuffls[i])[j][2]][0][0],uv[ibufspliter(ibuffls[i])[j][2]][0][1],\
			#uv[ibufspliter(ibuffls[i])[j][0]][0][0],uv[ibufspliter(ibuffls[i])[j][0]][0][1],\
			 #uv[ibufspliter(ibuffls[i])[j][1]][0][0],uv[ibufspliter(ibuffls[i])[j][1]][0][1],\
			  #uv[ibufspliter(ibuffls[i])[j][2]][0][0],uv[ibufspliter(ibuffls[i])[j][2]][0][1],\
			uv[ibufspliter(ibuffls[i])[j][0]][0][0],uv[ibufspliter(ibuffls[i])[j][0]][0][1],\
			 uv[ibufspliter(ibuffls[i])[j][1]][0][0],uv[ibufspliter(ibuffls[i])[j][1]][0][1],\
			  uv[ibufspliter(ibuffls[i])[j][2]][0][0],uv[ibufspliter(ibuffls[i])[j][2]][0][1]))
			if nextv in ibufspliter(ibuffls[i])[j]:
				nextmat+=1
				nextv+=usrdat.usr1_matvlen2[ObjNumber][MeshNumber][nextmat]
				MatNumber+=1
				#matcounter=0
			#counter+=1
	fout.write('\t}\n}')
	
	
	"""
	try:
		while(ls4[2] != 0 or ls4[3] != 0):
			ls4=ls[m:m+4]
			if ls4[2] != 65535:
				fout.write('\t\t3 V('+str(ls4[2])+' ')
				fout.write(str(ls4[1])+' ')
				fout.write(str(ls4[0])+') M(%d) UV(%0.8f %0.8f %0.8f %0.8f %0.8f %0.8f)\n' % \
					(MatNumber,\
					uv[ls4[2]][0][0],uv[ls4[2]][0][1], uv[ls4[1]][0][0],uv[ls4[1]][0][1], uv[ls4[0]][0][0],uv[ls4[0]][0][1]))
				#matcounter+=1
				if ls4[0]==nextv or ls4[1]==nextv or ls4[2]==nextv:
					nextmat+=1
					nextv+=usrdat.usr1_matvlen2[ObjNumber][MeshNumber][nextmat]
					MatNumber+=1
					#matcounter=0
				
				counter+=1
				
				lsc=ls4[0:4]
				lsc.reverse()
				if lsc[0]!=65535 and len(lsc)==4:
					fout.write('\t\t3 V('+str(lsc[2])+' ')
					fout.write(str(lsc[1])+' ')
					fout.write(str(lsc[0])+') M(%d) UV(%0.8f %0.8f %0.8f %0.8f %0.8f %0.8f)\n' % \
						(MatNumber,\
						uv[lsc[2]][0][0], uv[lsc[2]][0][1],uv[lsc[1]][0][0], uv[lsc[1]][0][1],uv[lsc[0]][0][0], uv[lsc[0]][0][1]))
					#matcounter+=1
					if lsc[0]==nextv or lsc[1]==nextv or lsc[2]==nextv:
						nextmat+=1
						nextv+=usrdat.usr1_matvlen2[ObjNumber][MeshNumber][nextmat]
						MatNumber+=1
						#matcounter=0
					counter+=1
					m+=2
				else:
					m+=4
			else:
				m+=3
		else:
			fout.write('\t}\n')
	except IndexError:
		print 'Ibuff IndexError'
		pass
	fout.write('\t}\n}')
	"""

def getUVtest(filein,tprdat,ddsdat,vbfdat,ibfdat,usrdat,vb,ib,vstride, ShortToFloat) :
	fin = open(filein,'rb')
	fin.seek(vbfdat.addr1[vb] + tprdat.startad - 0x1000,0)
	shortarray = array('h')
	shortarray.fromfile(fin,2*vbfdat.info[vb]/4)
	shortarray.byteswap()
	numtex = vstride - 5
	numvertex = vbfdat.info[vb]/4/vstride
	print 'numvertex = %d'%(numvertex)
	#uvshort = shortarray[(2*vbfdat.info[vb]/4/vstride)][numtex*2]
	uv =[[[0 for k in range(2)] for j in range(numtex)] for i in range(numvertex)]
	for i in range(numvertex):	#number of vertex
		for j in range(numtex):						#number of texture
			uv[i][j][0] = ShortToFloat(shortarray[(vstride*2)*i + 8+2*j])
			uv[i][j][1] = ShortToFloat(shortarray[(vstride*2)*i + 8+2*j + 1])
	for i in range(10):
		print uv[i][0]
	fout = open(filein+'_UVtest.txt','w')
	fout.write('\tMeshMaterialList\n\t{\n\t\t1;\n\t\t%d;\n'%(ibfdat.numsurface[ib]))
	for i in range(ibfdat.numsurface[ib]-1):
		fout.write('\t\t0,\n')
	fout.write('\t\t0;;\n\t\t{MaterialName1}\n\t}\n')
	fout.write('\tMeshTextureCoords\n\t{\n\t\t%d;\n'%(numvertex))
	for i in range(numvertex):
		fout.write('\t\t%0.10f;%0.10f;\n' % (uv[i][0][0],uv[i][0][1]))
	

def writeXFile(filein,tprdat,ddsdat,vbfdat,ibfdat,usrdat,vb,ib,vstride) :
	fin = open(filein,'rb')
	counter2=0
	fin.seek(vbfdat.addr1[vb] + tprdat.startad - 0x1000,0)
	flar = array('f')
	flar.fromfile(fin,vbfdat.info[vb]/4)
	flar.byteswap()
	####kokokra VBUFF
	fout = open(filein+'_%dv_%di.x'%(vb,ib),'w')
	fout.write('xof 0303txt 0032\nMesh Mesh_filename\n{\n')
	vbpoint = fout.tell()
	fout.seek(10,1)#40
	fout.write('\n')
	for i in range(0,vbfdat.info[vb]/4,vstride):			# '9' = vertexstride+1
		fout.write('\t')
		for j in range(3):
			try :
				fout.write('%0.10f;'%flar[i+j])
			except IndexError:
				counter2+=-1
				pass
		counter2+=1
		fout.write(',\n')
	fout.seek(-3,2)
	fout.write(';\n\n')
	fout.seek(vbpoint,0)
	
	fout.write('\t%d;'%(counter2))
	
	####kokokara IBUFF
	fout.seek(0,2)
	ibpoint = fout.tell()
	ad = ibfdat.addr1[ib] + tprdat.startad - 0x1000
	ls=[]
	for i in range(ibfdat.info[ib]/2):
		ls.append(readshort(ad,fin))
		ad+=2
	ls4=[]
	ls4=ls[0:4]
	m=0
	lsc=[]
	counter=0
	
	fout.seek(10,1)#10
	fout.write('\n')
	try:
		while(ls4[2] != 0 or ls4[3] != 0):
			ls4=ls[m:m+4]
			if ls4[2] != 65535:
				fout.write('\t3;'+str(ls4[0])+',')
				fout.write(str(ls4[1])+',')
				fout.write(str(ls4[2])+';,\n')
				counter+=1
				lsc=ls4[0:4]
				lsc.reverse()
				if lsc[0]!=65535:
					fout.write('\t3;'+str(lsc[0])+',')
					fout.write(str(lsc[1])+',')
					fout.write(str(lsc[2])+';,\n')
					counter+=1
					m+=2
				else:
					m+=4
			else:
				m+=3
		else:
			fout.seek(-3,2)
			fout.write(';')
			fout.seek(ibpoint ,0)
			fout.write('\t%d;'%(counter))
			fout.seek(0,2)
			fout.write('}')
	except IndexError:
		fout.seek(-3,2)
		fout.write(';')
		fout.seek(ibpoint ,0)
		fout.write('\t%d;'%(counter))
		fout.seek(0,2)
		fout.write('}')
	fin.close()
	fout.close()
	print 'done'


def writeObjFile(filein,tprdat,ddsdat,vbfdat,ibfdat,usrdat,vb,ib,vstride) :
	fin = open(filein,'rb')
	counter2=0
	fin.seek(vbfdat.addr1[vb] + tprdat.startad - 0x1000,0)
	flar = array('f')
	flar.fromfile(fin,vbfdat.info[vb]/4)
	flar.byteswap()
	####kokokra VBUFF
	fout = open(filein+'_%dv_%di.obj'%(vb,ib),'w')
	fout.write('mtllib mtlname1.mtl\n\n')
	vbpoint = fout.tell()
	#fout.seek(10,1)#40
	#fout.write('\n')
	for i in range(0,vbfdat.info[vb]/4,vstride):			# '9' = vertexstride+1
		fout.write('v')
		for j in range(3):
			try :
				fout.write(' %0.8f'%flar[i+j])
			except IndexError:
				counter2+=-1
				pass
		counter2+=1
		fout.write('\n')
	#fout.seek(-3,2)
	#fout.write(';\n\n')
	#fout.seek(vbpoint,0)
	
	fout.write('# %d vertices\n\n'%(counter2))
	
	####kokokara IBUFF
	fout.seek(0,2)
	ibpoint = fout.tell()
	ad = ibfdat.addr1[ib] + tprdat.startad - 0x1000
	ls=[]
	for i in range(ibfdat.info[ib]/2):
		ls.append(readshort(ad,fin))
		ad+=2
	ls4=[]
	ls4=ls[0:4]
	m=0
	lsc=[]
	counter=0
	
	#fout.seek(10,1)#10
	#fout.write('\n')
	try:
		while(ls4[2] != 0 or ls4[3] != 0):
			ls4=ls[m:m+4]
			if ls4[2] != 65535:
				fout.write('f v'+str(ls4[0]+1))
				fout.write(' v'+str(ls4[1]+1))
				fout.write(' v'+str(ls4[2]+1)+'\n')
				counter+=1
				lsc=ls4[0:4]
				lsc.reverse()
				if lsc[0]!=65535:
					fout.write('f v'+str(lsc[0]+1))
					fout.write(' v'+str(lsc[1]+1))
					fout.write(' v'+str(lsc[2]+1)+'\n')
					counter+=1
					m+=2
				else:
					m+=4
			else:
				m+=3
		else:
			fout.seek(-3,2)
			fout.write('\n')
			#fout.seek(ibpoint ,0)
			fout.write('# %d elements'%(counter))
			#fout.seek(0,2)
			#fout.write('}')
	except IndexError:
		fout.seek(-3,2)
		fout.write('\n')
		#fout.seek(ibpoint ,0)
		fout.write('# %d elements'%(counter))
		#fout.seek(0,2)
		#fout.write('}')
	fin.close()
	fout.close()
	print 'done'

