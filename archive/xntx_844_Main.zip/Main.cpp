#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

#define INSTRUCTION_SIZE 2
#define BLOCK_MIN_IT 3

struct SLD_Instruction
{
    SLD_Instruction() : Valid(true), Cushion(false), InputSize(-1), OutputSize(-1) { }
    bool Valid, Cushion;
    int InputSize, OutputSize;
    char Data[INSTRUCTION_SIZE];

    void Print()
    {
        cout << "* Cushion: " << Cushion << endl;
        cout << "* Input: " << InputSize << endl;
        cout << "* Output: " << OutputSize << endl;
    }

    string PrintBitFields()
    {
        string BitFields;
        (Data[0] & 0x01) ? BitFields += '1' : BitFields += '0';
        (Data[0] & 0x02) ? BitFields += '1' : BitFields += '0';
        (Data[0] & 0x04) ? BitFields += '1' : BitFields += '0';
        (Data[0] & 0x08) ? BitFields += '1' : BitFields += '0';
        (Data[0] & 0x10) ? BitFields += '1' : BitFields += '0';
        BitFields += ' ';
        (Data[0] & 0x20) ? BitFields += '1' : BitFields += '0';
        BitFields += ' ';
        (Data[0] & 0x40) ? BitFields += '1' : BitFields += '0';
        (Data[0] & 0x80) ? BitFields += '1' : BitFields += '0';
        (Data[1] & 0x01) ? BitFields += '1' : BitFields += '0';
        (Data[1] & 0x02) ? BitFields += '1' : BitFields += '0';
        BitFields += ' ';
        (Data[1] & 0x04) ? BitFields += '1' : BitFields += '0';
        (Data[1] & 0x08) ? BitFields += '1' : BitFields += '0';
        (Data[1] & 0x10) ? BitFields += '1' : BitFields += '0';
        (Data[1] & 0x20) ? BitFields += '1' : BitFields += '0';
        BitFields += ' ';
        (Data[1] & 0x40) ? BitFields += '1' : BitFields += '0';
        (Data[1] & 0x80) ? BitFields += '1' : BitFields += '0';
        return(BitFields);
    }

    void DebugPrint()
    {
        if(Valid)
        {
            cout << "Valid IT: " << endl;
            Print();
            cout << "* " << PrintBitFields() << endl;
        }
        else
        {
            cout << "Invalid IT: " << endl;
            cout << "Unknown Bitfields0: " << ((Data[0] & 0xE0) != 0) << endl;
            cout << "Unknown Bitfields1: " << ((Data[1] & 0xC3) != 0) << endl;
            cout << "InputSize: " << (InputSize == 0) << endl;
            cout << "OutputSize: " << (OutputSize == 0) << endl;
            cout << "OutputSize Alignment: " << (OutputSize % 2) << endl;
        }
    }

    bool Validate() // Collects & Validates
    {
        // Collect Data
        Cushion = Data[0] & 0x10; // 00010000 Cushin flag
        InputSize = Data[0] & 0x0F; // 00001111 Input Buffer size
        OutputSize = (Data[1] & 0x7C) >> 2; // 01111100 Output Buffer size
        InputSize *= 2; // Convert to pairs
        // Output size is in bytes not pairs
        // Validation Checks
        if((Data[0] & 0xE0) != 0) Valid = false;
        if((Data[1] & 0x83) != 0) Valid = false;
        if(OutputSize % 2) Valid = false; // OutputSize must be a multiple of 2
        if(InputSize == 0) Valid = false;
        if(OutputSize == 0) Valid = false;
        return(Valid);
    }
};

void Decom(const SLD_Instruction& IT, fstream& OFile);

int main()
{
    // Open Input & output file
    fstream
        IFile("yokotex1.sld", ios::binary | ios::in),
        OFile("yokotex1.tm2", ios::binary | ios::out | ios::in | ios::trunc);

    if(!IFile)
    {
        IFile.close();
        OFile.close();
        cout << "Could not open yokotex1.sld" << endl;
        return(EXIT_SUCCESS);
    }

    if(!OFile)
    {
        IFile.close();
        OFile.close();
        cout << "Could not Create yokotex1.tm2" << endl;
        return(EXIT_SUCCESS);
    }

    /*
    TODO: Proccess file by blocks instead of pairs.
    */

    // Proccess File
    int EnumBlockIT(0), NextBlockIT((EnumBlockIT * 32) + (EnumBlockIT * 2));
    int EnumIT(0), EnumData(0);
    //while(!IFile.eof())
    //while(80 > IFile.tellg()) // For Header
    while(256 > IFile.tellg())
    {
        // Read Data
        SLD_Instruction IT;
        IFile.read(IT.Data, INSTRUCTION_SIZE);
        if(NextBlockIT == (-2 + IFile.tellg())) // Block Instruction, ignore
        {
            cout << "BlockIT(DISPLAY) at: " << (-2 + IFile.tellg()) << endl;
            // Calculate Next BlockIT position
            EnumBlockIT++;
            NextBlockIT = (EnumBlockIT * 32) + (EnumBlockIT * 2);
        }
        else // InBlock Instruction
        {
            if(IT.Validate()) // It is an instruction
            {
                cout << "InBlock IT: " << (-2 + IFile.tellg()) << endl;
                IT.DebugPrint();
                Decom(IT, OFile);
                EnumIT++;
            }
            else // It is Data - Write to output file
            {
                //cout << "Data: " << (-2 + IFile.tellg()) << endl;
                OFile.write(IT.Data, INSTRUCTION_SIZE);
                EnumData++;
            }
        }
    }
    cout << "***********************************************" << endl;
    cout << "Total Instructions: " << EnumIT << endl;
    cout << "Total Block Instructions: " << EnumBlockIT << endl;
    cout << "Raw Data: " << (EnumData * 2) << endl;
    IFile.close();
    OFile.close();
    return(EXIT_SUCCESS);
}

void Decom(const SLD_Instruction& IT, fstream& OFile)
{
    // Initalise buffers to NULL
    vector <char> OBuf(IT.OutputSize, 0x00);
    vector <char> IBuf(IT.InputSize, 0x00);
    if(!IT.Cushion)
    {
        OFile.seekg(-IT.InputSize, ios::end); // Move back
        OFile.read(&IBuf[0], IT.InputSize); // Fill Input Buffer
        OFile.seekp(0, ios::end); // Fix put pointer
        OBuf.assign(IBuf.begin(), IBuf.end()); // Overwrite Output buffer
        // Big lazy buffer
        // Max output buffer size = 32(5 bits), min input buffer size = 2
        // 4 * 2 * 4 = 32..
        for(int i(0); i < 4; i++)
        {
            OBuf.insert(OBuf.end(), IBuf.begin(), IBuf.end());
            OBuf.insert(OBuf.end(), IBuf.begin(), IBuf.end());
            OBuf.insert(OBuf.end(), IBuf.begin(), IBuf.end());
            OBuf.insert(OBuf.end(), IBuf.begin(), IBuf.end());
        }
    }
    OFile.write(&OBuf[0], IT.OutputSize); // write to output file
}
