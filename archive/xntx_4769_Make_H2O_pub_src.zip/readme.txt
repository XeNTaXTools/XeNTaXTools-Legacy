
Before compiling this project with CodeBlocks 13.12 for example

try out Make_H2O.exe
in \Make_H2O\bin\Release with Mesh_1807.mdl for example. 

This will create H2O files.


mdl samples to be found here:
http://forum.xentax.com/viewtopic.php?f=16&t=11229&p=93788&hilit=sly+cooper+thieves#p93788
(Thx to o0demonboy0o)

--------------

To get hex2obj working you'll need 

1) the zipped version 0.22 and
2) hex2obj_0.24b.exe

from Xentax:
http://forum.xentax.com/viewtopic.php?f=29&t=10894

Extract the first zip to a folder of your choice.
then copy hex2obj_0.24b.exe into it.

Start hex2obj_v0.24b, load the model and choose File "SaveAs Mmesh" to create several obj files.

--------------------

When executing load_multi_obj_blender2.69.py in a blender Text Editor window with alt-p
make sure to have set "path_to_obj_dir" to YOUR mdl directory.

Just replace ('O:\\', 'Eigene Dateien\\Downloads\\Models\\MedievalMetalman\\1')

Alt-p should import the obj files in the mdl folder into blender.


Make sure that there's no obj contained in a maybe existing subfolder.