﻿# IDOLM@STER One For All PS3 pmd importer by Bigchillghost

import rapi
from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("IDOLM@STER One For All", ".pmd")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadModel(handle, noepyLoadModel)
	#noesis.logPopup()
	return 1

#check if it's this type based on the data
def noepyCheckType(data):
	if len(data) < 0x80:
		return 0
	bs = NoeBitStream(data)
	Magic = bs.readUInt()
	if Magic != 0x1444D50:		#PMD\x01
		return 0
	return 1

#load the model
def noepyLoadModel(data, mdlList):
	bs = NoeBitStream(data, NOE_BIGENDIAN)
	bs.seek(0x18, NOESEEK_ABS)
	Offset = bs.readInt()
	Size = bs.readInt()
	bs.seek(Offset, NOESEEK_ABS)
	Count = bs.readInt()
	bs.seek(Count*8+0xC+Size, NOESEEK_REL)
	bs.seek(0x10, NOESEEK_REL)
	meshCount = bs.readInt()
	bs.seek(meshCount*8+8, NOESEEK_REL)
	#noesis.logPopup()
	#print("meshCount %d"%meshCount)
	ctx = rapi.rpgCreateContext()
	rapi.rpgSetOption(noesis.RPGOPT_BIGENDIAN, 1)
	for i in range(0, meshCount):
		#print("mesh at %x"%bs.tell())
		bs.seek(0x10, NOESEEK_REL)
		meshName = noeStrFromBytes(bs.readBytes(0x20), "UTF8")
		#print("mesh %s"%meshName)
		bs.seek(0x18, NOESEEK_REL)
		Vcount = bs.readInt()
		bs.seek(4, NOESEEK_REL)
		Vsize = bs.readInt()
		sizeofV = Vsize // Vcount
		FIcount = bs.readInt()
		bs.seek(4, NOESEEK_REL)
		FIsize = bs.readInt()
		sizeofIdx = FIsize // FIcount
		bs.seek(0x58, NOESEEK_REL)
		nextMeshOffset = bs.readInt()
		bs.seek(0x84, NOESEEK_REL)
		nextMeshOffset += bs.tell()
		
		#print("vert data at %x"%bs.tell())
		Vdata = bs.readBytes(Vsize)
		#print("idx data at %x"%bs.tell())
		#print("FIsize %x"%FIsize)
		idxData = bs.readBytes(FIsize)
		#print(" ")
	
		rapi.rpgSetName(meshName)
		rapi.rpgBindPositionBuffer(Vdata, noesis.RPGEODATA_FLOAT, sizeofV)
		rapi.rpgBindNormalBufferOfs(Vdata, noesis.RPGEODATA_SHORT, sizeofV, 0x10)
		rapi.rpgBindUV1BufferOfs(Vdata, noesis.RPGEODATA_HALFFLOAT, sizeofV, 0x18)
		if sizeofIdx == 1:
			idxType = noesis.RPGEODATA_UBYTE
		elif sizeofIdx == 2:
			idxType = noesis.RPGEODATA_USHORT
		else:
			idxType = noesis.RPGEODATA_INT
		
		rapi.rpgCommitTriangles(idxData, idxType, FIcount, noesis.RPGEO_TRIANGLE_STRIP, 1)
		rapi.rpgClearBufferBinds()
		
		bs.seek(nextMeshOffset, NOESEEK_ABS)
	mdl = rapi.rpgConstructModel()
	mdlList.append(mdl)
	
	return 1

