from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Final Fantasy XV: Episode Duscae [PS4]", ".btex")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    if noeStrFromBytes(bs.readBytes(8)) != 'SEDBbtex': return 0
    bs.seek(0x200, NOESEEK_ABS)
    if noeStrFromBytes(bs.readBytes(3)) != 'GNF': return 0
    return 1

def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.seek(0x200, NOESEEK_ABS)
    gnfTex = bs.readBytes(bs.getSize() - bs.tell())      
    tex = rapi.loadTexByHandler(gnfTex, ".gnf")
    texList.append(tex)
    return 1