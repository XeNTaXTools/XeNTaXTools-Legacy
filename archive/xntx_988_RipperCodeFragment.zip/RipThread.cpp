// RipThread.cpp : implementation file
//

#include "stdafx.h"
#define NO_OPTIONFUNC
#include "FileRip4.h"
#include "RipThread.h"

// Profile the rip
//#define PROFILE_RIP

// Use the old method
#define RIP_OLD_METHOD

// The max number of rip tracks
#define MAX_RIP_TRACK 256

// The rip structure
struct SRipStruct
{
	SRipStruct* Ptr[256];
	bool End[256];
};

// Pointer to the plugins
CPlugins* g_Plugins=0;

// CurSel plugin
unsigned long g_CurSelPlugin=0xFFFFFFFF;

// CRipThread

IMPLEMENT_DYNCREATE(CRipThread, CWinThread)

CRipThread::CRipThread()
: m_RipProgress(NULL)
, m_MainDlg(NULL)
, m_Files(NULL)
, m_FoundCurrent(0)
, m_FoundTotal(0)
, m_RippedNumber(0)
, m_ArchiveType(0)
, m_BlocksSec(0)
, m_ArchiveNumberFiles(0)
, m_ArchiveUserPtr(NULL)
{
	g_Plugins=&m_Plugins;
	g_CurSelPlugin=0xFFFFFFFF;
}

CRipThread::~CRipThread()
{
	g_Plugins=0;
	g_CurSelPlugin=0xFFFFFFFF;
}

BOOL CRipThread::InitInstance()
{
	m_RipProgress->GetDlgItem(IDC_PAUSE)->EnableWindow(true);
	m_RipProgress->GetDlgItem(IDC_CANCEL)->EnableWindow(true);
	m_RipProgress->GetDlgItem(IDC_SKIP)->EnableWindow(true);

	m_RipProgress->m_Status.SetWindowText("Initializing...");

	// Load the plugins and configure them
	for(unsigned long i=0;;i++)
	{
		char Buffer[256], Buffer2[256];
		CString Filename;
		SPluginInfo* PlugInfo;
		unsigned long PluginIndex;
		_snprintf(Buffer, 256, "Plugin_%i", i);
		Filename=theApp.GetProfileString(Buffer, "Filename", "");
		if(Filename=="")
		{
			break;
		}
		PluginIndex=m_Plugins.GetNumberPlugins();
		strncpy(Buffer2, Filename, 256);
		if(!m_Plugins.AddPlugin(Buffer2, "FileRip"))
		{
			int Result=MessageBox(m_RipProgress->m_hWnd, "Error adding a plugin. Continue adding plugins?", "Prompt", MB_ICONSTOP | MB_YESNO);
			if(Result==IDNO)
			{
				break;
			}
		}
		for(unsigned long j=PluginIndex;j<m_Plugins.GetNumberPlugins();j++)
		{
			PlugInfo=m_Plugins.GetPluginInfo(j);
			if(PlugInfo==0)
			{
				continue;
			}
			PlugInfo->FilePluginIndex=i;
			PlugInfo->LocalPluginIndex=j-PluginIndex;
		}
	}
	for(unsigned long i=0;i<m_Plugins.GetNumberPlugins();i++)
	{
		SPluginInfo* PlugInfo;
		char Buffer[256];
		PlugInfo=m_Plugins.GetPluginInfo(i);
		if(PlugInfo==0)
		{
			continue;
		}
		_snprintf(Buffer, 256, "Plugin_%i\\%i", PlugInfo->FilePluginIndex, PlugInfo->LocalPluginIndex);
		PlugInfo->RipUsing=theApp.GetProfileInt(Buffer, "RipUsing", true);
	}

	// Set progress bar
	m_RipProgress->m_FileProgress.SetRange(0, 100);
	m_RipProgress->m_BlockProgress.SetRange(0, 100);
	m_RipProgress->m_MiscProgress.SetRange(0, 100);

	// Calculate the highest rip index and add one (use for the next one)
	for(unsigned long i=0;i<m_MainDlg->m_List.GetNumberItems();i++)
	{
		SRippedItem Item;
		if(m_MainDlg->m_List.GetItem(i, &Item))
		{
			if(Item.RipIndex>m_RippedNumber)
			{
				m_RippedNumber=Item.RipIndex+1;
			}
		}
	}

	// Extract files from an archive and rip them?
	bool ExtractArchive=theApp.GetProfileInt("Options", "ExtractArchive", true);
	// The block size
	unsigned long BlockSize=theApp.GetProfileInt("Options", "BlockSize", 1024);

	// A temporary buffer (1)
	char Buffer[256];
	// The total number of files to rip
	unsigned long NumberFiles=m_Files->GetNumItems();
	// The buffer for loading in a block
	unsigned char* BlockData;
	// The main window (for MessageBox)
	HWND hWnd=m_RipProgress->m_hWnd;
	// A pointer to the files to rip
	char *FilenamePtr;
	// Number of plugins it will use to rip
	unsigned long NumberPlugins=0;
	// List of plugins that it will use to rip
	unsigned long* PluginList;
	// ID lengths found (NumberPlugins of them)
	unsigned long* IDLen;
	// The handle to the file
	HANDLE hFile;
	// Plugin info
	SPluginInfo** PlugInfo;
#ifndef RIP_OLD_METHOD
	// The rip hierarchy
	SRipStruct RipStruct;
#endif

	// Allocate memory for the block
	BlockData=new unsigned char[BlockSize];
	if(BlockData==0)
	{
		MessageBox(hWnd, "Fatal memory error. (Block data)", "Fatal Error", MB_ICONERROR);
		return FALSE;
	}

	// Allocate memory for the plugin list
	for(unsigned long i=0;i<m_Plugins.GetNumberPlugins();i++)
	{
		SPluginInfo* PlugInfo;
		PlugInfo=m_Plugins.GetPluginInfo(i);
		if(PlugInfo==0)
		{
			continue;
		}
		if(PlugInfo->RipUsing && PlugInfo->Type==0 && PlugInfo->Sig.SigLength>0)
		{
			NumberPlugins++;
		}
	}
	if(NumberPlugins==0)
	{
		m_RipProgress->m_Status.SetWindowText("Done ripping.");
		delete[] BlockData;
		return FALSE;
	}
	PluginList=new unsigned long[NumberPlugins];
	if(PluginList==0)
	{
		MessageBox(hWnd, "Fatal memory error. (Plugin list)", "Fatal Error", MB_ICONERROR);
		return FALSE;
	}
	NumberPlugins=0;
	for(unsigned long i=0;i<m_Plugins.GetNumberPlugins();i++)
	{
		SPluginInfo* PlugInfo;
		PlugInfo=m_Plugins.GetPluginInfo(i);
		if(PlugInfo==0)
		{
			continue;
		}
		if(PlugInfo->RipUsing && PlugInfo->Type==0 && PlugInfo->Sig.SigLength>0)
		{
			PluginList[NumberPlugins]=i;
			NumberPlugins++;
		}
	}

	// Allocate memory for the ID lengths list
	IDLen=new unsigned long[NumberPlugins];
	if(IDLen==0)
	{
		MessageBox(hWnd, "Fatal memory error. (ID length list)", "Fatal Error", MB_ICONERROR);
		return FALSE;
	}

	// Initialize the filename list pointer
	FilenamePtr=(char*)m_Files->Lock();

	// Get plugin information
	PlugInfo=new SPluginInfo*[m_Plugins.GetNumberPlugins()];
	for(unsigned long i=0;i<m_Plugins.GetNumberPlugins();i++)
	{
		PlugInfo[i]=m_Plugins.GetPluginInfo(i);
	}

#ifndef RIP_OLD_METHOD
	// Allocate memory for the rip struct
	for(unsigned long i=0;i<m_Plugins.GetNumberPlugins();i++)
	{
		SRipStruct* RipPtr=&RipStruct;
		for(unsigned long j=0;j<PlugInfo[i]->Sig.SigLength;j++)
		{
		}
	}
#endif

#ifdef PROFILE_RIP
	// The starting time
	unsigned long StartTime=GetTickCount();
#endif

	// Go into the main loop
	for(unsigned long i=0;i<NumberFiles;i++)
	{
		char CurFilename[MAX_FILENAME];
		char BaseFilename[MAX_FILENAME];
		unsigned long FileSize;
		unsigned long NumberBlocks;

		// Initialize
		strncpy(CurFilename, FilenamePtr+(i*MAX_FILENAME), MAX_FILENAME);
		m_FoundCurrent=0;

		// Set up the progress information
		m_RipProgress->m_Filename.SetWindowText(CurFilename);
		_snprintf(Buffer, 256, "File %d / %d", i+1, NumberFiles);
		m_RipProgress->m_File.SetWindowText(Buffer);
		_snprintf(Buffer, 256, "Found: Current: %d Total: %d", m_FoundCurrent, m_FoundTotal);
		m_RipProgress->m_Found.SetWindowText(Buffer);
		Progress1(i, NumberFiles);
		m_RipProgress->m_Status.SetWindowText("Ripping...");
		Progress3();
		_snprintf(m_BlockString, 256, "Block 0 / ?");
		Progress2();
		m_RipProgress->m_Block.SetWindowText(m_BlockString);

		// Open the file
		if(ExtractArchive && LoadArchive(CurFilename))
		{
			// The file is an archive
			// Remember to change the filename text
			strncpy(BaseFilename, CurFilename, MAX_FILENAME);
		}
		else
		{
			hFile=CreateFile(CurFilename, GENERIC_READ, FILE_SHARE_READ, 0, OPEN_EXISTING, FILE_FLAG_SEQUENTIAL_SCAN, 0);
			if(hFile==INVALID_HANDLE_VALUE) 
			{
				continue;
			}
			m_ArchiveType=0xFFFFFFFF;
			m_ArchiveNumberFiles=1;
		}

		// Process the files in an archive
		for(unsigned long ii=0;ii<m_ArchiveNumberFiles;ii++)
		{
			// Clear memory
			memset(IDLen, 0, sizeof(unsigned long)*NumberPlugins);

			// Do some stuff with the archive
			if(m_ArchiveType!=0xFFFFFFFF)
			{
				_snprintf(CurFilename, MAX_FILENAME, "%s\\%u", BaseFilename, ii);
				m_RipProgress->m_Filename.SetWindowText(CurFilename);
				hFile=ExtractFromArchive(ii);
				if(hFile==0)
				{
					// Error! But just skip the file as nothing has happened...
					//MessageBox(hWnd, "File extraction error", "Error", MB_ICONERROR);
					continue;
				}
			}

			// Get size information
			FileSize=GetFileSize(hFile, 0);
			NumberBlocks=FileSize/BlockSize+1;

			// The block processing loop
			for(unsigned long j=0;j<NumberBlocks;j++)
			{
				unsigned long FileOffset;
				unsigned long Read;

				// Update progress info
				_snprintf(m_BlockString, 256, "Block %d / %d", j, NumberBlocks);
				Progress2(j, NumberBlocks);

				// Read a block
				if(!ReadFile(hFile, BlockData, BlockSize, &Read, 0))
				{
					MessageBox(hWnd, "File read error.", "Error", MB_ICONERROR);
					break;
				}

				// Search the buffer for signatures
				for(unsigned long k=0;k<BlockSize;k++)
				{
					unsigned char Temp=*(BlockData+k);
					
					// Now process one from each plugin
					for(unsigned long m=0;m<NumberPlugins;m++)
					{
#ifdef RIP_OLD_METHOD
CheckStart_0:
						if(Temp==PlugInfo[PluginList[m]]->Sig.Signature[IDLen[m]])
						{
							IDLen[m]++;

							// Check if it is done
							if(IDLen[m]==PlugInfo[PluginList[m]]->Sig.SigLength)
							{
								FileOffset=SetFilePointer(hFile, (j*BlockSize+k)-(PlugInfo[PluginList[m]]->Sig.SigLength-1)-PlugInfo[PluginList[m]]->Sig.SigOffset, 0, FILE_BEGIN);
								if(ExtractFile(hFile, FileOffset, PluginList[m], CurFilename, FileSize))
								{
									m_FoundCurrent++;
									m_FoundTotal++;
									_snprintf(Buffer, 256, "Found: Current: %d Total: %d", m_FoundCurrent, m_FoundTotal);
									m_RipProgress->m_Found.SetWindowText(Buffer);
								}
								SetFilePointer(hFile, (j+1)*BlockSize, 0, FILE_BEGIN);
								IDLen[m]=0;
							}
						}
						else
						{
							if(IDLen[m]!=0)
							{
								IDLen[m]=0;
								goto CheckStart_0;
							}
							else
							{
								IDLen[m]=0;
							}
						}
#else
#endif
					}
				}

				// Increase the blocks processed count
				m_BlocksSec++;

				// Check for a cancel or skip
				if(m_RipProgress->m_CancelClicked==true)
				{
					break;
				}
				if(m_RipProgress->m_SkipClicked==true)
				{
					break;
				}
			}

			// Put the block progress bar to the end
			Progress2(1, 1);

			// Do some other stuff with the archive
			if(m_ArchiveType!=0xFFFFFFFF)
			{
				CloseHandle(hFile);
			}

			// Chech for a cancel or skip
			if(m_RipProgress->m_CancelClicked==true)
			{
				break;
			}
			if(m_RipProgress->m_SkipClicked==true)
			{
				m_RipProgress->m_SkipClicked=false;
				break;
			}
		}

		// Close the file
		if(m_ArchiveType!=0xFFFFFFFF)
		{
			FreeArchive();
		}
		else
		{
			CloseHandle(hFile);
		}

		// Check for cancel
		if(m_RipProgress->m_CancelClicked==true)
		{
			m_RipProgress->m_CancelClicked=false;
			break;
		}
	}
#ifdef PROFILE_RIP
	char _Buffer[256];
	_snprintf(_Buffer, 256, "Rip finished in %d ms (%f sec)", GetTickCount()-StartTime, (float)(GetTickCount()-StartTime)/1000);
	MessageBox(hWnd, _Buffer, "Profiling", 0);
#endif

	// Put the file progress bar to the end
	Progress1(1, 1);

	// Free block memory
	delete[] BlockData;

	// Free the plugin list memory
	delete[] PluginList;

	// Free the ID lengths memory
	delete[] IDLen;

	// Free the Plugin info list memory
	delete[] PlugInfo;

	// Deinitialize the filename list pointer
	m_Files->Unlock();

	// Update progress bar
	m_RipProgress->m_Status.SetWindowText("Done ripping.");

	return FALSE;
}

int CRipThread::ExitInstance()
{
	return CWinThread::ExitInstance();
}

BEGIN_MESSAGE_MAP(CRipThread, CWinThread)
END_MESSAGE_MAP()


// Progress 1

void CRipThread::Progress1(unsigned long At, unsigned long Total)
{
	if(Total==0 || At==0)
	{
		m_RipProgress->m_FileProgress.SetPos(0);
	}
	else
	{
		m_RipProgress->m_FileProgress.SetPos((float)100/(float)Total*(float)At);
	}
}

// Progress 2
void CRipThread::Progress2(unsigned long At, unsigned long Total)
{
	if(Total==0 || At==0)
	{
		m_RipProgress->m_BlockProgress.SetPos(0);
		//m_RipProgress->Progress2=0;
	}
	else
	{
		m_RipProgress->m_BlockProgress.SetPos((float)100/(float)Total*(float)At);
		//m_RipProgress->Progress2=(float)100/(float)Total*(float)At;
	}
}

// Progress 3
void CRipThread::Progress3(unsigned long At, unsigned long Total)
{
	if(Total==0 || At==0)
	{
		m_RipProgress->m_MiscProgress.SetPos(0);
	}
	else
	{
		m_RipProgress->m_MiscProgress.SetPos((float)100/(float)Total*(float)At);
	}
}

// Check if it is an archive and load it
bool CRipThread::LoadArchive(char* Filename)
{
	SPluginInfo* PlugInfo;
	for(unsigned long i=0;i<m_Plugins.GetNumberPlugins();i++)
	{
		PlugInfo=m_Plugins.GetPluginInfo(i);
		if(PlugInfo==0)
		{
			continue;
		}
		if(PlugInfo->Type==1 && PlugInfo->RipUsing)
		{
			if(PlugInfo->PlugLoadArchive && PlugInfo->PlugGetNumberFiles)
			{
				SPluginParam Param;
				memset(&Param, 0, sizeof(SPluginParam));
				strncpy(Param.Filename, Filename, 260);
				if(PlugInfo->PlugLoadArchive(&Param))
				{
					m_ArchiveType=i;
					m_ArchiveUserPtr=Param.ArchivePtr;
					PlugInfo->PlugGetNumberFiles(&Param);
					m_ArchiveNumberFiles=Param.NumberFiles;
					return true;
				}
			}
		}
	}
	return false;
}

// Free the current archive
bool CRipThread::FreeArchive(void)
{
	SPluginInfo* PlugInfo;
	PlugInfo=m_Plugins.GetPluginInfo(m_ArchiveType);
	if(PlugInfo==0)
	{
		return false;
	}
	if(PlugInfo->Type==1)
	{
		if(PlugInfo->PlugFreeArchive)
		{
			SPluginParam Param;
			Param.ArchivePtr=m_ArchiveUserPtr;
			PlugInfo->PlugFreeArchive(&Param);
			m_ArchiveNumberFiles=0;
			m_ArchiveType=0xFFFFFFFF;
			m_ArchiveUserPtr=0;
		}
	}
	return true;
}

// Verify a file and add it to the list
bool CRipThread::ExtractFile(HANDLE hFile, unsigned long Offset, unsigned long Plugin, char* Filename, unsigned long FileSize)
{
	SRippedItem Item;
	SPluginParam Param;
	SPluginInfo* PlugInfo;
	memset(&Item, 0, sizeof(SRippedItem));
	memset(&Param, 0, sizeof(SPluginParam));
	Param.FileSize=FileSize;
	Param.hFile=hFile;
	Param.Offset=Offset;

	PlugInfo=m_Plugins.GetPluginInfo(Plugin);
	if(PlugInfo==0)
	{
		return false;
	}

	g_CurSelPlugin=Plugin;
	if(!PlugInfo->PlugProc)
	{
		return false;
	}
	if(PlugInfo->PlugProc(&Param))
	{
		g_CurSelPlugin=0xFFFFFFFF;
		Item.Offset=Param.Offset;
		Item.Size=Param.RipSize;
		if(strcmp(Param.Ext, "")==0)
		{
			_snprintf(Item.OutputFilename, MAX_FILENAME, "FRip%04lX", m_RippedNumber);
		}
		else
		{
			_snprintf(Item.OutputFilename, MAX_FILENAME, "FRip%04lX.%s", m_RippedNumber, Param.Ext);
		}
		Item.RipIndex=m_RippedNumber;
		m_RippedNumber++;
		strncpy(Item.SourceFilename, Filename, MAX_FILENAME);
		strncpy(Item.RipPlugin, PlugInfo->Name, 256);
		m_MainDlg->AddListItem(&Item);
		return true;
	}
	else
	{
		g_CurSelPlugin=0xFFFFFFFF;
		return false;
	}
	return false;
}

// Get an option int for a plugin
extern "C" __declspec(dllexport) bool GetIntOption(char* OptName, long* Int)
{
	char Buffer[512];
	SPluginInfo* PlugInfo;
	if(OptName==0 || Int==0 || g_Plugins==0 || g_CurSelPlugin==0xFFFFFFFF)
	{
		return false;
	}
	PlugInfo=g_Plugins->GetPluginInfo(g_CurSelPlugin);
	if(PlugInfo==0)
	{
		return false;
	}
	_snprintf(Buffer, 256, "Plugin_%i\\%i", PlugInfo->FilePluginIndex, PlugInfo->LocalPluginIndex);
	*Int=theApp.GetProfileInt(Buffer, OptName, *Int);
	return true;
}

// Get an option string for a plugin
extern "C" __declspec(dllexport) bool GetStringOption(char* OptName, char* String, unsigned long StringLength)
{
	char Buffer[512];
	SPluginInfo* PlugInfo;
	if(OptName==0 || String==0 || g_Plugins==0 || g_CurSelPlugin==0xFFFFFFFF)
	{
		return false;
	}
	PlugInfo=g_Plugins->GetPluginInfo(g_CurSelPlugin);
	if(PlugInfo==0)
	{
		return false;
	}
	_snprintf(Buffer, 256, "Plugin_%i\\%i", PlugInfo->FilePluginIndex, PlugInfo->LocalPluginIndex);
	strncpy(String, theApp.GetProfileString(Buffer, OptName, String), StringLength);
	return true;
}

// Set an option int for a plugin
extern "C" __declspec(dllexport) bool SetIntOption(char* OptName, long Int)
{
	char Buffer[512];
	SPluginInfo* PlugInfo;
	if(OptName==0 || g_Plugins==0 || g_CurSelPlugin==0xFFFFFFFF)
	{
		return false;
	}
	PlugInfo=g_Plugins->GetPluginInfo(g_CurSelPlugin);
	if(PlugInfo==0)
	{
		return false;
	}
	_snprintf(Buffer, 256, "Plugin_%i\\%i", PlugInfo->FilePluginIndex, PlugInfo->LocalPluginIndex);
	return theApp.WriteProfileInt(Buffer, OptName, Int);
}

// Set an option string for a plugin
extern "C" __declspec(dllexport) bool SetStringOption(char* OptName, char* String)
{
	char Buffer[512];
	SPluginInfo* PlugInfo;
	if(OptName==0 || g_Plugins==0 || g_CurSelPlugin==0xFFFFFFFF)
	{
		return false;
	}
	PlugInfo=g_Plugins->GetPluginInfo(g_CurSelPlugin);
	if(PlugInfo==0)
	{
		return false;
	}
	_snprintf(Buffer, 256, "Plugin_%i\\%i", PlugInfo->FilePluginIndex, PlugInfo->LocalPluginIndex);
	if(String==0)
	{
		String="";
	}
	return theApp.WriteProfileString(Buffer, OptName, String);
}

// Extract a file from the archive
HANDLE CRipThread::ExtractFromArchive(unsigned long FileNumber)
{
	HANDLE hFile;
	if(m_ArchiveType==0xFFFFFFFF)
	{
		return NULL;
	}
	SPluginInfo* PlugInfo;
	PlugInfo=m_Plugins.GetPluginInfo(m_ArchiveType);
	if(PlugInfo==0)
	{
		return NULL;
	}
	if(PlugInfo->Type==1)
	{
		if(PlugInfo->PlugSetIndex && PlugInfo->PlugReadArchive)
		{
			SPluginParam Param;
			unsigned long FileSize=0xFFFFFFFF;
			char TempPath[MAX_FILENAME];
			char Buffer[MAX_FILENAME];
			Param.ArchivePtr=m_ArchiveUserPtr;
			Param.FileIndex=FileNumber;
			if(!PlugInfo->PlugSetIndex(&Param))
			{
				return NULL;
			}
			if(PlugInfo->PlugGetFileSize)
			{
				if(PlugInfo->PlugGetFileSize(&Param))
				{
					FileSize=Param.FileSize;
				}
			}
			GetTempPath(MAX_FILENAME, TempPath);
			_snprintf(Buffer, MAX_FILENAME, "%s~ArchiveFile.tmp", TempPath);
			hFile=CreateFile(Buffer, GENERIC_WRITE, 0, 0, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
			if(hFile==INVALID_HANDLE_VALUE) 
			{
				return NULL;
			}
			unsigned long CurOffset=0;
			unsigned char DataBuffer[4096];
			m_RipProgress->m_Status.SetWindowText("Extracting from archive...");
			while(1)
			{
				unsigned long BytesWritten;
				Param.BytesRead=0;
				Param.NumBytes=4096;
				Param.DataBuffer=DataBuffer;
				if(!PlugInfo->PlugReadArchive(&Param))
				{
					break;
				}
				if(Param.BytesRead==0)
				{
					break;
				}
				CurOffset+=Param.BytesRead;
				WriteFile(hFile, DataBuffer, Param.BytesRead, &BytesWritten, 0);
				if(FileSize!=0xFFFFFFFF)
				{
					Progress3(CurOffset, FileSize);
				}
			}
			CloseHandle(hFile);
			hFile=CreateFile(Buffer, GENERIC_READ, FILE_SHARE_READ, 0, OPEN_EXISTING, FILE_FLAG_SEQUENTIAL_SCAN, 0);
			if(hFile==INVALID_HANDLE_VALUE) 
			{
				return NULL;
			}
			Progress3();
			m_RipProgress->m_Status.SetWindowText("Ripping...");
		}
	}
	return hFile;
}
