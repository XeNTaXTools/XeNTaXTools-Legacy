// Blocks.h : Declares functions for the DLL application.
//

// The number of plugins in the blocks file
#define BLOCKS_NUM_PLUG 3

// Rip a RIFF block
BASIC_API bool PlugProc_RIFF(SPluginParam* Param);

// Rip a RIFX block
BASIC_API bool PlugProc_RIFX(SPluginParam* Param);

// Rip a FORM block
BASIC_API bool PlugProc_FORM(SPluginParam* Param);