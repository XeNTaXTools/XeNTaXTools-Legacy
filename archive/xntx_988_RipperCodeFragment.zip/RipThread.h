#pragma once
#include "RipProgressDlg.h"
#include "Plugins.h"


// CRipThread

class CRipThread : public CWinThread
{
	DECLARE_DYNCREATE(CRipThread)

public:
	CRipThread();           // protected constructor used by dynamic creation
	virtual ~CRipThread();

public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();

protected:
	DECLARE_MESSAGE_MAP()
public:
	// The rip progress dialog
	CRipProgressDlg* m_RipProgress;
	// The plugins
	CPlugins m_Plugins;
	// The main dialog
	CFileRip4Dlg* m_MainDlg;
	// The list of files to rip from
	CVarArray* m_Files;
	// Progress 1
	void Progress1(unsigned long At=0, unsigned long Total=0);
	// Progress 2
	void Progress2(unsigned long At=0, unsigned long Total=0);
	// Progress 3
	void Progress3(unsigned long At=0, unsigned long Total=0);
	// How many file were found in the current file
	unsigned long m_FoundCurrent;
	// How many file were found in total
	unsigned long m_FoundTotal;
	// The next number that will be added to the filename when another file is found
	unsigned long m_RippedNumber;
	// The current archive type (if there is one)
	unsigned long m_ArchiveType;
	// Check if it is an archive and load it
	bool LoadArchive(char* Filename);
	// Free the current archive
	bool FreeArchive(void);
	// The number of blocks processed
	unsigned long m_BlocksSec;
	// The total number of files in an archive
	unsigned long m_ArchiveNumberFiles;
	// The block string
	char m_BlockString[256];
	// Verify a file and add it to the list
	bool ExtractFile(HANDLE hFile, unsigned long Offset, unsigned long Plugin, char* Filename, unsigned long FileSize);
	// Extract a file from the archive
	HANDLE ExtractFromArchive(unsigned long FileNumber);
	// Hold the user pointer for the archive
	void* m_ArchiveUserPtr;
};


