// Blocks.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include "Basic.h"

// The number of RIFF block name extentions
#define NUM_RIFF 18
// The number of RIFX block name extentions
#define NUM_RIFX 3
// The number of FORM block name extentions
#define NUM_FORM 10

// The RIFF, RIFX, and FORM block structure
struct SBlock
{
	// The signature
	char Sig[4];
	// The size
	unsigned long Size;
	// The name
	char Name[4];
};

// The names of RIFF blocks
char RIFFNames[NUM_RIFF][2][10]={{"", "rff"}, {"WAVE", "wav"}, {"ACON", "ani"}, {"AVI ", "avi"}, {"DLS ", "dls"}, \
{"RMID", "rmi"}, {"sfbk", "sbk"}, {"DSMF", "dsm"}, {"PAL ", "pal"}, {"CDDA", "cda"}, {"CSP ", "csp"}, \
{"DMSC", "spp"}, {"JAZP", "pro"}, {"DMSG", "sgp"}, {"DMBD", "bnp"}, {"DMST", "stp"}, {"DMPR", "cdp"}, \
{"IDF ", "idf"}};

// The names of RIFX blocks
char RIFXNames[NUM_RIFX][2][10]={{"", "rfx"}, {"MV93", "dxr"}, {"MC95", ""}};

// The names of FORM blocks
char FORMNames[NUM_FORM][2][10]={{"", "iff"}, {"AIFF", "aif"}, {"XMID", "xmi"}, {"AIFC", "afc"}, {"ILBM", "lbm"}, \
{"PBM ", "lbm"}, {"ANBM", "anm"}, {"ANIM", "anm"}, {"8SVX", "8sx"}, {"FMAP", "fmp"}};

// Rip a RIFF block
BASIC_API bool PlugProc_RIFF(SPluginParam* Param)
{
	SBlock Block;
	unsigned long Read;
	bool Found=false;
	ReadFile(Param->hFile, &Block, sizeof(SBlock), &Read, 0);
	if(Block.Size > Param->FileSize)
	{
		return false;
	}
	if(Block.Size+8+Param->Offset > Param->FileSize)
	{
		return false;
	}
	if(Block.Size<5)
	{
		return false;
	}
	strncpy(Param->Ext, "rff", 32);
	for(unsigned long i=0;i<NUM_RIFF;i++)
	{
		if(memcmp(Block.Name, RIFFNames[i][0], 4)==0) 
		{
			strncpy(Param->Ext, RIFFNames[i][1], 32);
			Found=true;
			break;
		}
	}
	if(!Found)
	{
		long ReportOnly=FALSE;
		if(GetIntOption("ReportOnly", &ReportOnly))
		{
			if(ReportOnly==TRUE)
			{
				return false;
			}
		}
	}
	Param->RipSize=Block.Size+8;
	return true;
}

// Rip a RIFX block
BASIC_API bool PlugProc_RIFX(SPluginParam* Param)
{
	SBlock Block;
	unsigned long Read;
	bool Found=false;
	ReadFile(Param->hFile, &Block, sizeof(SBlock), &Read, 0);
	Block.Size=FLIP4(Block.Size);
	if(Block.Size > Param->FileSize)
	{
		return false;
	}
	if(Block.Size+8+Param->Offset > Param->FileSize)
	{
		return false;
	}
	if(Block.Size<5)
	{
		return false;
	}
	strncpy(Param->Ext, "rfx", 32);
	for(unsigned long i=0;i<NUM_RIFX;i++)
	{
		if(memcmp(Block.Name, RIFXNames[i][0], 4)==0) 
		{
			strncpy(Param->Ext, RIFXNames[i][1], 32);
			Found=true;
			break;
		}
	}
	if(!Found)
	{
		long ReportOnly=FALSE;
		if(GetIntOption("ReportOnly", &ReportOnly))
		{
			if(ReportOnly==TRUE)
			{
				return false;
			}
		}
	}
	Param->RipSize=Block.Size+8;
	return true;
}

// Rip a FORM block
BASIC_API bool PlugProc_FORM(SPluginParam* Param)
{
	SBlock Block;
	unsigned long Read;
	bool Found=false;
	ReadFile(Param->hFile, &Block, sizeof(SBlock), &Read, 0);
	Block.Size=FLIP4(Block.Size);
	if(Block.Size > Param->FileSize)
	{
		return false;
	}
	if(Block.Size+8+Param->Offset > Param->FileSize)
	{
		return false;
	}
	if(Block.Size<5)
	{
		return false;
	}
	strncpy(Param->Ext, "iff", 32);
	for(unsigned long i=0;i<NUM_FORM;i++)
	{
		if(memcmp(Block.Name, FORMNames[i][0], 4)==0) 
		{
			strncpy(Param->Ext, FORMNames[i][1], 32);
			Found=true;
			break;
		}
	}
	if(!Found)
	{
		long ReportOnly=FALSE;
		if(GetIntOption("ReportOnly", &ReportOnly))
		{
			if(ReportOnly==TRUE)
			{
				return false;
			}
		}
	}
	Param->RipSize=Block.Size+8;
	return true;
}