
#include "collide.h"

//+----------------------------------------------------------------> cCollide()

cCollide::cCollide()
{
}

//+----------------------------------------------------------------> Delete()

void cCollide::Delete()
{
	if(m_pCollision)
	{
		for(unsigned int a = 0; a < m_uiCollisionNum; a++)
		{
			if(m_pCollision[a].pNormal)
				delete[] m_pCollision[a].pNormal;
			if(m_pCollision[a].pVertex)
				delete[] m_pCollision[a].pVertex);
			if(m_pCollision[a].pPart)
			{
				for(unsigned short b = 0; b < m_pCollision[a].usPartNum; b++)
				{
				}
				delete[] m_pCollision[a].pPart;
				m_pCollision[a].pPart = NULL;
			}
		}
		delete[] m_pCollision;
		m_pCollision = NULL;
	}
	if(m_pOffset)
	{
		delete[] m_pOffset;
		m_pOffset = NULL;
	}
}

//+----------------------------------------------------------------> Load()

bool cCollide::Load(FILE *pFile)
{
	// take a ref point
	unsigned int uiRef = ftell(pFile);

	// read the header
	fread(this, 48, 1, pFile);
	if(strcmp(m_pstrTag, "COLLIDE"))
	{
		printf("Invalid COLLIDE chunk at [%d] !\n", ftell(pFile));
		return false;
	}
	Moto2Intel(m_uiCollisionNum);
	Moto2Intel(m_uiTableSize);

	// read the offsets
	m_pOffset = new unsigned int[m_uiTableSize];
	fread(m_pOffset, 4, m_uiTableSize, pFile);
	for(unsigned int a = 0; a < m_uiTableSize; a++)
		Moto2Intel(m_pOffset[a]);

	// go through the collisions and read them
	unsigned int uiCollision = 0;
	m_pCollision = new cCollideBloc[m_uiCollisionNum];
	for(unsigned int a = 0; a < m_uiTableSize; a++)
	{
		if(m_pOffset[a])
		{
			fseek(pFile, uiRef + m_pOffset[a], SEEK_SET);
			if(!ReadCollision(pFile, m_pCollision[uiCollision]))
				return false;
			uiCollision++;
		}
	}

	return true;
}

//+----------------------------------------------------------------> ReadCollision()

bool cCollide::ReadCollision(FILE *pFile, cCollideBloc &p)
{
	// take a ref point
	unsigned int uiRef = ftell(pFile);

	// read the header and check for the right signature
	fread(&p, 48, 1, pFile);
	if((p.uiTag != 0x004C4C43) || (p.usVersion != 0x0101))
	{
		printf("Invalid CLL chunk at [%d] !\n", ftell(pFile));
		return false;
	}
	Moto2Intel(p.uiNormalOffset);
	Moto2Intel(p.uiVertexOffset);
	Moto2Intel(p.usPartNum);
	Moto2Intel(p.vBBoxMin);
	Moto2Intel(p.vBBoxMax);
	p.uiVertexNum = (p.uiNormalOffset - p.uiVertexOffset) / 16;
	p.uiFaceNum = 0;

	// read the parts
	p.pPart = new cCollidePart[p.usPartNum];
	fread(p.pPart, sizeof(cCollidePart), p.usPartNum, pFile);
	for(unsigned short a = 0; a < p.usPartNum; a++)
	{
		Moto2Intel(p.pPart[a].uiFaceNum);
		Moto2Intel(p.pPart[a].uiOffset);
		Moto2Intel(p.pPart[a].vBBoxMin);
		Moto2Intel(p.pPart[a].vBBoxMax);
		Moto2Intel(p.pPart[a].uiInconnu1);
		p.uiFaceNum += p.pPart[a].uiFaceNum;
	}

	// read the verts
	p.pVertex = new D3DXVECTOR4[p.uiVertexNum];
	fseek(pFile, uiRef + p.uiVertexOffset, SEEK_SET);
	fread(p.pVertex, sizeof(D3DXVECTOR4), p.uiVertexNum, pFile);
	for(unsigned int a = 0; a < p.uiVertexNum; a++)
		Moto2Intel(p.pVertex[a]);

	// read the faces normals
	p.pNormal = new D3DXVECTOR4[p.uiFaceNum];
	fseek(pFile, uiRef + p.uiNormalOffset, SEEK_SET);
	fread(p.pNormal, sizeof(D3DXVECTOR4), p.uiFaceNum, pFile);
	for(unsigned int a = 0; a < p.uiFaceNum; a++)
		Moto2Intel(p.pNormal[a]);

	// read the faces
	for(unsigned short a = 0; a < p.usPartNum; a++)
	{
		p.pPart[a].pFace = new cCollideFace[p.pPart[a].uiFaceNum];
		fseek(pFile, uiRef + p.pPart[a].uiOffset, SEEK_SET);
		fread(p.pPart[a].pFace, sizeof(cCollideFace), p.pPart[a].uiFaceNum, pFile);
		for(unsigned int b = 0; b < p.pPart[a].uiFaceNum; b++)
		{
			for(unsigned int c = 0; c < 4; c++)
				Moto2Intel(p.pPart[a].pFace[b].pIndex[c]);
		}
	}
	return true;
}

//+----------------------------------------------------------------> Export()

bool cCollide::Export(const char *strCol)
{
	FILE *pFile = fopen(strCol, "wt");
	unsigned int uiIndex = 1;

	// go through all the collisions and write them
	for(unsigned int a = 0; a < m_uiCollisionNum; a++)
	{
		// write the vertex buffer
		for(unsigned int b = 0; b < m_pCollision[a].uiVertexNum; b++)
			fprintf(pFile, "v %f %f %f\n", m_pCollision[a].pVertex[b].x, m_pCollision[a].pVertex[b].y, m_pCollision[a].pVertex[b].z);

		// write the parts
		fprintf(pFile, "g col_%d\n", a);
		for(unsigned short b = 0; b < m_pCollision[a].usPartNum; b++)
		{
			// write the faces
			for(unsigned c = 0; c < m_pCollision[a].pPart[b].uiFaceNum; c++)
			{
				unsigned int i0 = m_pCollision[a].pPart[b].pFace[c].pIndex[0] + uiIndex;
				unsigned int i1 = m_pCollision[a].pPart[b].pFace[c].pIndex[1] + uiIndex;
				unsigned int i2 = m_pCollision[a].pPart[b].pFace[c].pIndex[2] + uiIndex;
				unsigned int i3 = m_pCollision[a].pPart[b].pFace[c].pIndex[3] + uiIndex;

				fprintf(pFile, "f %d %d %d\n", i0, i1, i2);
			}
		}
		fprintf(pFile, "g\n\n");
		uiIndex += m_pCollision[a].uiVertexNum;
	}

	fclose(pFile);
	return true;
}

//+----------------------------------------------------------------> 
