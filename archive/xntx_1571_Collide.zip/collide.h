
#ifndef _COLLIDE_H
#define _COLLIDE_H

#include "main.h"

//+----------------------------------------------------------------> cCollide

struct cCollideFace
{
	WORD					pIndex[4];				// the 4th is the face id
	// ignore padding (x16) and bounding boxes (too may of them here)
	// some more ignored data here, seems to be the inverse of 'part'
};

//+----------------------------------------------------------------> cCollidePart

struct cCollidePart
{
	unsigned int			uiFaceNum;				// a face is a quad here
	unsigned int			uiInconnu1;
	unsigned int			uiInconnu2;
	unsigned int			uiOffset;
	unsigned int			uiInconnu3;
	unsigned int			uiInconnu4;
	unsigned int			uiInconnu5;
	cCollideFace			*pFace;
	D3DXVECTOR4				vBBoxMin;				// x, y, z, 1.0f
	D3DXVECTOR4				vBBoxMax;				// x, y, z, 0.0f
};

//+----------------------------------------------------------------> cCollideBloc

struct cCollideBloc
{
	unsigned int			uiTag;					// CLL
	unsigned short			usVersion;				// 0x0101
	unsigned short			usPartNum;
	unsigned int			uiVertexOffset;
	unsigned int			uiNormalOffset;			// faces normals

	D3DXVECTOR4				vBBoxMax;				// x, y, z, 1.0f
	D3DXVECTOR4				vBBoxMin;				// x, y, z, 0.0f

	unsigned int			uiVertexNum;			// calculated
	unsigned int			uiFaceNum;				// calculated
	cCollidePart			*pPart;
	D3DXVECTOR4				*pVertex;
	D3DXVECTOR4				*pNormal;				// face normals
};

//+----------------------------------------------------------------> cCollide

class cCollide
{
public:
							cCollide();

	bool					Load(FILE *pFile);
	bool					Export(const char *strCol);
	void					Delete();

private:

	bool					ReadCollision(FILE *pFile, cCollideBloc &p);

	char					m_pstrTag[8];			// COLLIDE
	unsigned int			m_uiVersion;			// 0x000100FF
	unsigned int			m_uiOffset;				// 48
	unsigned int			m_uiSize;				// bloc size in bytes
	unsigned int			m_uiTableSize;
	unsigned int			m_uiCollisionNum;
	unsigned int			m_uiInconnu[5];			// 0, 48, 0, 0

	unsigned int			*m_pOffset;
	cCollideBloc			*m_pCollision;
};

//+----------------------------------------------------------------> 
#endif