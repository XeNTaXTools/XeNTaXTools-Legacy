from inc_noesis import *
import subprocess

def registerNoesisTypes():
    handle = noesis.register("Dissidia Final Fantasy: Opera Omnia", ".g1t")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    if noeStrFromBytes(bs.readBytes(8)) != 'GT1G0600': return 0
    return 1
    
def noepyLoadRGBA(data, texList):
    rapi.processCommands("-texnorepfn")
    bs = NoeBitStream(data)
    bs.seek(0x8, NOESEEK_ABS)
    filesize = bs.readUInt()
    tableOffset = bs.readInt()
    print(hex(tableOffset), "table offset")
    numTexs = bs.readUInt() #0x10
    print(numTexs, "numTexs")
    bs.seek(tableOffset, NOESEEK_ABS)
    baseOffset = bs.tell()
    for i in range(numTexs):
        if numTexs > 1:
            texName = i + 1
            texName = rapi.getExtensionlessName(rapi.getInputName()) + "_" + str(texName)
        else:
            texName = rapi.getInputName()
        offset = bs.readUInt()
        offset += baseOffset 
        tmp = bs.tell()
        bs.seek(offset, NOESEEK_ABS)
        unk = bs.readByte()
        imgFmt = bs.readUByte()
        print(hex(imgFmt), ":format")
        width = bs.readBits(4)
        height = bs.readBits(4)
        print(hex(width), "width")
        print(hex(height), "height")
        imgWidth = 2 ** width
        imgHeight = 2 ** height
        print(imgWidth, "x", imgHeight, ":", hex(imgFmt), "imgFmt", "-", i)
        bs.seek(0x4, NOESEEK_REL)
        check = bs.readUByte()
        if check == 0x10:
            bs.seek(0xc, NOESEEK_REL)
        #ARGB16 , RGB565
        if imgFmt == 0x36 or imgFmt == 0x34:
            datasize = (imgWidth * imgHeight) * 2
        #RGBA32
        elif imgFmt == 0x0:
            datasize = (imgWidth * imgHeight) * 4
        #A8
        elif imgFmt == 0xf:
            datasize = imgWidth * imgHeight
        #ETC1
        elif imgFmt == 0x6f:
            datasize = imgWidth * imgHeight
        elif imgFmt == 0x56:
            datasize = imgWidth * imgHeight // 2
        print(hex(datasize), "datasize")
        data = bs.readBytes(datasize)      
        if imgFmt == 0x6f or imgFmt == 0x56:
            #ETC
            imgFmt = 0x6
            #build pvr header
            pvrTex = (b'\x50\x56\x52\x03\x02\x00\x00\x00')
            pvrTex += struct.pack("I", imgFmt)            
            pvrTex += (b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00')            
            pvrTex += struct.pack("I", imgWidth)
            pvrTex += struct.pack("I", imgHeight)
            pvrTex += (b'\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00')
            pvrTex += data

            dstFilePath = noesis.getScenesPath() + "sample.pvr"
            workingdir = noesis.getScenesPath()
            newfile = open(dstFilePath, 'wb')
            newfile.write(pvrTex)
            newfile.close()
            subprocess.Popen([noesis.getScenesPath() + 'PVR2PNG.bat', dstFilePath]).wait()

            data = rapi.loadIntoByteArray(dstFilePath + ".png")
            texture = rapi.loadTexByHandler(data, ".png")
            texture.name = texName
            texList.append(texture)
        else:
            #ARGB4444
            if imgFmt == 0x36:
                data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "a4 b4 g4 r4")
            #RGBA8888
            elif imgFmt == 0x0:
                data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "r8 g8 b8 a8")
            #RGB565
            elif imgFmt == 0x34:
                data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "b5 g6 r5")
            #A8
            elif imgFmt == 0xf:
                data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "a8")
            texList.append(NoeTexture(texName, imgWidth, imgHeight, data, noesis.NOESISTEX_RGBA32))
        bs.seek(tmp, NOESEEK_ABS)
    return 1