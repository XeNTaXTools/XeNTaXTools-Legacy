#pragma once

void UnpackGWDat(unsigned char *input, int insize, unsigned char *&output, int &outsize);