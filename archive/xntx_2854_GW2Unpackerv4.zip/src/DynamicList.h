#pragma once
#include <Windows.h>

template <typename ItemType> class CDynamicList
{
private:
	int Capacity;

	ItemType **Kupac;
	int KupacSize;

public:

	int ItemCount;
	ItemType **Items;

	CDynamicList()
	{
		Items=new ItemType*[10];
		memset(Items,0,sizeof(ItemType*)*10);
		Capacity=10;
		ItemCount=0;
	}

	CDynamicList(int DefCount)
	{
		Items=new ItemType*[DefCount];
		memset(Items,0,sizeof(ItemType*)*DefCount);
		Capacity=DefCount;
		ItemCount=0;
	}

	void Clear()
	{
		for (int x=0; x<ItemCount; x++)
		  if (Items[x]) 
		  {
			  delete Items[x];
			  Items[x]=NULL;
		  }
		if (Capacity) 
		{
			delete[] Items;
			Items=NULL;
		}
		ItemCount = 0;
    Capacity = 0;
	}

	virtual ~CDynamicList()
	{
		Clear();
	}

	void AddItem(ItemType *Item)
	{
		if (Capacity==ItemCount)
		{
			ItemType **Buffer=new ItemType*[(Capacity+10)*2];
			memset(Buffer,0,(Capacity+10)*2*sizeof(ItemType*));
			memcpy(Buffer,Items,Capacity*sizeof(ItemType*));
			memset(Items,0,Capacity*sizeof(ItemType*));
			delete[] Items;
			Items=Buffer;
			Capacity=(Capacity+10)*2;
		}
		Items[ItemCount]=Item;
		ItemCount++;
	}

	ItemType *operator[](const int index)
	{
		return Items[index];
	}

};