#include <stdio.h>
#include "Dynamiclist.h"
#include "Xentax.h"
#include "GWUnpacker.h"

HANDLE f;
MainHeader GWHead;
MFTHeader MFTH;

CDynamicList<MFTExpansion> MFTX;
CDynamicList<MFTEntry> MFT;

void WriteFile(char *Filename, unsigned char *data, int Size)
{
	if (!data) return;
	FILE *f=fopen(Filename,"w+b");
	if (!f) return;
	fwrite(data,1,Size,f);
	fclose(f);
}

void _nfseek(HANDLE f, __int64 offset, int origin)
{
	LARGE_INTEGER i;
	i.QuadPart=offset;
	SetFilePointerEx(f,i,NULL,FILE_BEGIN);
}

void _nfread(void *buffer, int size, int count, HANDLE f)
{
	DWORD bread;
	int errcde=ReadFile(f,buffer,size*count,&bread,NULL);
	if (!errcde)
	{
		char text[2048];
		FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM,0,GetLastError(),0,text,1024,NULL);
		printf("%s\n",text);
	}
}

int SkipCount = 0;
int BugCount = 0;
int PictureCount = 0;
int SoundCount = 0;
int ffnaCount = 0;
int unknowncount = 0;
int textcount = 0;

void DumpFile(int num, MFTEntry *m)
{
	if (m->a) printf("c ");
	else printf("u ");
	if (!m->b) 
	{
		printf("mftbase - skipping");
		SkipCount++;
		return;
	}
	printf("%2x ",m->c);

	_nfseek(f,m->Offset,0);
	unsigned char *Input=new unsigned char[m->Size];
	_nfread(Input,m->Size,1,f);
	unsigned char *Output=NULL;
	int OutSize=0;

	if (m->a) UnpackGWDat(Input,m->Size,Output,OutSize);        
	else
	{
		Output=new unsigned char[m->Size];
		memcpy(Output,Input,m->Size);
		OutSize=m->Size;
	}

	if (Output)
	{
		unsigned int i=((unsigned int*)Output)[0];
		unsigned int k=((unsigned int*)Output)[1];
		int i2=i&0xffff;
		int i3=i&0xffffff;

		char Name[256];
		sprintf(Name,"%.8d",num);
		char newname[1024];
		sprintf(newname,"GWDat/Unsorted/%s.raw\0",Name);

		CreateDirectory("GWDat",NULL);
		switch (i)
		{
		case 'XTTA':
			PictureCount++;
			CreateDirectory("GWDat/ATTX",NULL);
			printf(" Texture");
			switch(k)
			{
			case '1TXD':
				CreateDirectory("GWDat/ATTX/DXT1",NULL);
				printf(" DXT1");
				sprintf(newname,"GWDat/ATTX/DXT1/%s.atex\0",Name);
				break;
			case '3TXD':
				CreateDirectory("GWDat/ATTX/DXT3",NULL);
				printf(" DXT3");
				sprintf(newname,"GWDat/ATTX/DXT3/%s.atex\0",Name);
				break;
			case '5TXD':
				CreateDirectory("GWDat/ATTX/DXT5",NULL);
				printf(" DXT5");
				sprintf(newname,"GWDat/ATTX/DXT5/%s.atex\0",Name);
				break;
			case 'NTXD':
				CreateDirectory("GWDat/ATTX/DXTN",NULL);
				printf(" DXTN");
				sprintf(newname,"GWDat/ATTX/DXTN/%s.atex\0",Name);
				break;
			case 'ATXD':
				CreateDirectory("GWDat/ATTX/DXTA",NULL);
				printf(" DXTA");
				sprintf(newname,"GWDat/ATTX/DXTA/%s.atex\0",Name);
				break;
			case 'LTXD':
				CreateDirectory("GWDat/ATTX/DXTL",NULL);
				printf(" DXTL");
				sprintf(newname,"GWDat/ATTX/DXTL/%s.atex\0",Name);
				break;
			}
			break;
		case 'XETA':
			PictureCount++;
			CreateDirectory("GWDat/ATEX",NULL);
			printf(" Picture");
			switch(k)
			{
			case '1TXD':
				CreateDirectory("GWDat/ATEX/DXT1",NULL);
				printf(" DXT1");
				sprintf(newname,"GWDat/ATEX/DXT1/%s.atex\0",Name);
				break;
			case '2TXD':
				CreateDirectory("GWDat/ATEX/DXT2",NULL);
				printf(" DXT2");
				sprintf(newname,"GWDat/ATEX/DXT2/%s.atex\0",Name);
				break;
			case '3TXD':
				CreateDirectory("GWDat/ATEX/DXT3",NULL);
				printf(" DXT3");
				sprintf(newname,"GWDat/ATEX/DXT3/%s.atex\0",Name);
				break;
			case '4TXD':
				CreateDirectory("GWDat/ATEX/DXT4",NULL);
				printf(" DXT4");
				sprintf(newname,"GWDat/ATEX/DXT4/%s.atex\0",Name);
				break;
			case '5TXD':
				CreateDirectory("GWDat/ATEX/DXT5",NULL);
				printf(" DXT5");
				sprintf(newname,"GWDat/ATEX/DXT5/%s.atex\0",Name);
				break;
			case 'NTXD':
				CreateDirectory("GWDat/ATEX/DXTN",NULL);
				printf(" DXTN");
				sprintf(newname,"GWDat/ATEX/DXTN/%s.atex\0",Name);
				break;
			case 'ATXD':
				CreateDirectory("GWDat/ATEX/DXTA",NULL);
				printf(" DXTA");
				sprintf(newname,"GWDat/ATEX/DXTA/%s.atex\0",Name);
				break;
			case 'LTXD':
				CreateDirectory("GWDat/ATEX/DXTL",NULL);
				printf(" DXTL");
				sprintf(newname,"GWDat/ATEX/DXTL/%s.atex\0",Name);
				break;
			case 'XCD3': //GW2
				CreateDirectory("GWDat/ATEX/3DCX",NULL);
				printf(" 3DCX");
				sprintf(newname,"GWDat/ATEX/3DCX/%s.atex\0",Name);
				break;
			}
			break;
		case '===;':
		case '***;':
			textcount++;
			CreateDirectory("GWDat/TEXT",NULL);
			printf(" Text");
			sprintf(newname,"GWDat/Text/%s.txt\0",Name);
			break;
		case 'anff':
			ffnaCount++;
			CreateDirectory("GWDat/ffna",NULL);
			printf(" ffna");
			sprintf(newname,"GWDat/ffna/%s.ffna\0",Name);
			break;
		case ' SDD':
			PictureCount++;
			CreateDirectory("GWDat/DDS",NULL);
			printf(" Picture DDS");
			sprintf(newname,"GWDat/DDS/%s.dds\0",Name);
			break;
		case 'UETA': //GW2
			PictureCount++;
			CreateDirectory("GWDat/ATEU",NULL);
			printf(" ATEU");
			switch (k)
			{
			case '1TXD':
				CreateDirectory("GWDat/ATEU/DXT1",NULL);
				printf(" DXT1");
				sprintf(newname,"GWDat/ATEU/DXT1/%s.ateu\0",Name);
				break;
			case '2TXD':
				CreateDirectory("GWDat/ATEU/DXT2",NULL);
				printf(" DXT2");
				sprintf(newname,"GWDat/ATEU/DXT2/%s.ateu\0",Name);
				break;
			case '3TXD':
				CreateDirectory("GWDat/ATEU/DXT3",NULL);
				printf(" DXT3");
				sprintf(newname,"GWDat/ATEU/DXT3/%s.ateu\0",Name);
				break;
			case '5TXD':
				CreateDirectory("GWDat/ATEU/DXT5",NULL);
				printf(" DXT5");
				sprintf(newname,"GWDat/ATEU/DXT5/%s.ateu\0",Name);
				break;
			case 'LTXD':
				CreateDirectory("GWDat/ATEU/DXTL",NULL);
				printf(" DXTL");
				sprintf(newname,"GWDat/ATEU/DXTL/%s.ateu\0",Name);
				break;
			}
			break;
		case 'PETA': //GW2
			PictureCount++;
			CreateDirectory("GWDat/ATEP",NULL);
			printf(" ATEP");
			switch (k)
			{
			case '1TXD':
				CreateDirectory("GWDat/ATEP/DXT1",NULL);
				printf(" DXT1");
				sprintf(newname,"GWDat/ATEP/DXT1/%s.atep\0",Name);
				break;
			case '5TXD':
				CreateDirectory("GWDat/ATEP/DXT5",NULL);
				printf(" DXT5");
				sprintf(newname,"GWDat/ATEP/DXT5/%s.atep\0",Name);
				break;
			}
			break;
		case 'ffba': //GW2
			PictureCount++;
			CreateDirectory("GWDat/abff",NULL);
			printf(" abff");
			sprintf(newname,"GWDat/abff/%s.abff\0",Name);
			break;
		case 83536: //GW2, PF files
			CreateDirectory("GWDat/PF",NULL);
			char type[9];
			for (int z=8; z<16;z++)
				type[z-8] = Output[z];
			type[8] = '\0';
			printf(" PF %s", type);
			char dirname[18];
			sprintf(dirname, "GWDat/PF/%s\0", type);
			if (strcmp("ABNKBKCK", type) == 0 || strcmp("ASNDASND", type) == 0)
			{	//Audio files
				SoundCount++;
				CreateDirectory(dirname, NULL);
				sprintf(newname,"GWDat/PF/%s/%s.mp3\0",type, Name);
			}
			else
			{
				PictureCount++;
				CreateDirectory(dirname, NULL);
				sprintf(newname,"GWDat/PF/%s/%s.pf\0",type, Name);
			}
			break;
		case 'dnsa': //GW2
			PictureCount++;
			CreateDirectory("GWDat/asnd",NULL);
			printf(" asnd");
			sprintf(newname,"GWDat/asnd/%s.asnd\0",Name);
			break;
		case 'srts': //GW2
			textcount++;
			CreateDirectory("GWDat/strs",NULL);
			printf(" strs");
			sprintf(newname,"GWDat/strs/%s.strs\0",Name);
			break;
		default:
			CreateDirectory("GWDat/Unsorted",NULL);
			sprintf(newname,"GWDat/Unsorted/%s.raw\0",Name);
		}

		switch (i2)
		{
		case 0xFAFF:
		case 0xFBFF:
			CreateDirectory("GWDat/Sound",NULL);
			printf(" Sound");
			sprintf(newname,"GWDat/Sound/%s.mp3\0",Name);
			break;
		default:
			break;
		}

		switch (i3)
		{
		case 'PMA':
			CreateDirectory("GWDat/Amp",NULL);
			printf(" Sound Amp");
			sprintf(newname,"GWDat/Amp/%s.mp3\0",Name);
			break;
		case 0x334449:
			CreateDirectory("GWDat/Sound",NULL);
			printf(" Sound");
			sprintf(newname,"GWDat/Sound/%s.mp3\0",Name);
			break;
		default:
			break;
		}

		if (strstr(newname,"Sound")) SoundCount++;
		if (strstr(newname,"Unsort")) unknowncount++;

		WriteFile(newname,Output,OutSize);

		delete[] Output;
	}
	else
	{
		printf("BUG!");
		BugCount++;
	}

	delete[] Input;
}


void main(int argc, char **argv)
{
	printf("\nGuild Wars 2 datafile parser and decompressor tool\n\n");
	if (argc<=1)
	{
		printf("Usage:\n");
		printf("GW2Unpacker.exe [gw2.dat] (option)\n\nWARNING! There can't be any spaces in the path.\n\n");
		printf("Options: \n");
		printf("         t - Print raw MFT data to console\n");
		printf("         x start# end# - Export files from gw.dat\n");
		return;
	}

	FILE *g=fopen(argv[1],"rb");
	if (!g)
	{
		printf("Error opening \"%s\".\n",argv[1]);
		return;
	}
	fclose(g);

	f=CreateFile(argv[1],GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
	_nfread(&GWHead,sizeof(GWHead),1,f);
	printf("Header data:\n");
	printf("ID          = %7c%c%c%c\n",GWHead.ID[0],GWHead.ID[1],GWHead.ID[2],GWHead.ID[3]);
	/* //Bypass header check for newer client versions
	if (!(GWHead.ID[0]==0x97 && GWHead.ID[1]==0x41 && GWHead.ID[2]==0x4e && GWHead.ID[3]==0x1a))
	{
		printf("The input file is not a Guild Wars 2 datafile!\n");
		return;
	}
	*/
	printf("Header Size = %10d\n",GWHead.HeaderSize);
	printf("New Unknown = %7c%c%c%c\n",GWHead.Unk0[0],GWHead.Unk0[1],GWHead.Unk0[2],GWHead.Unk0[3]);
	printf("Sector Size = %10d\n",GWHead.SectorSize);
	printf("CRC1        = %10x\n",GWHead.CRC1);
	printf("MFT Offset  = %10I64d\n",GWHead.MFTOffset);
	printf("MFT Size    = %10d\n",GWHead.MFTSize);

	printf("\nReading MFT\n");
	_nfseek(f,GWHead.MFTOffset,SEEK_SET);
	_nfread(&MFTH,sizeof(MFTH),1,f);
	printf("EntryCount  = %10d\n",MFTH.EntryCount);

	for (int x=0; x<MFTH.EntryCount-1; x++)
	{
		MFTEntry *ME=new MFTEntry;
		_nfread(ME,0x18,1,f);
		MFT.AddItem(ME);
	}

	printf("\nReading MFT expansion\n");

	_nfseek(f,(int)MFT[1]->Offset,SEEK_SET);
	int mftxsize=MFT[1]->Size/sizeof(MFTExpansion);
	printf("EntryCount  = %10d\n",mftxsize);
	for (unsigned int x=0; x<MFT[1]->Size/sizeof(MFTExpansion); x++)
	{
		MFTExpansion *_MFTX=new MFTExpansion;
		_nfread(_MFTX,sizeof(MFTExpansion),1,f);
		MFTX.AddItem(_MFTX);
	}

	if (argc<3) return;

	printf("\n",argv[2][0]);

	switch (argv[2][0])
	{
	case 't':
		{
			for (int x=0; x<MFT.ItemCount; x++)
			{
				MFTEntry *ME=MFT[x];
				int off=x;
				__int64 pos=ME->Offset;
				int size=(int)ME->Size;
				int id=ME->ID;
				int unknown=ME->CRC;
				printf("#%6d ID:%7d Pos:%11I64d sect: %8d Size:%8d Flags=%2d%2d%3d\n",off+1,id,pos,(int)(pos/GWHead.SectorSize),size,ME->a,ME->b,ME->c,unknown);
			}
		}
		break;
	case 'x':
		{
			if (argc<4)
			{
				printf("You must also enter a file # range to decompress.\n");
				break;
			}
			int sid=0;
			int eid=0;
			if (argc>=4) 
			{
				if (!sscanf(argv[3],"%d",&sid))
				{
					printf("Bad number in input.\n");
					return;
				}
				eid=sid;
			}
			if (argc>=5) 
			{
				if (!sscanf(argv[4],"%d",&eid))
				{
					printf("Bad number in input.\n");
					return;
				}
			}

			for (int x=max(0,sid); x<min(MFT.ItemCount,eid+1); x++)
			{
				printf("Processing file %6d: ",x);
				DumpFile(x,MFT[x]);
				printf("\n");
			}

			printf("\nSkipped files: %d out of %d\nDecompression errors: %d\n\nImage files: %d\nSound files: %d\nffna files: %d\ntext files: %d\nUnrecognised files: %d\n\n",SkipCount,min(MFT.ItemCount,eid+1)-max(0,sid),BugCount,PictureCount,SoundCount,ffnaCount,textcount,unknowncount);

		}
		break;
	default:
		printf("Unknown command line option. \n");
		return;
	}

	CloseHandle(f);
}
