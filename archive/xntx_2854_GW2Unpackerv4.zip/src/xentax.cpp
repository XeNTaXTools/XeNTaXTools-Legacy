#include <memory.h>
#include <stdint.h>
#include "gw2Inflate.h"

void UnpackGWDat(unsigned char *input, int insize, unsigned char *&output, int &outsize)
{
	output = inflate((uint32_t*) input, insize, (uint32_t*) &outsize);
}