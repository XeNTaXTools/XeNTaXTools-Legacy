Modified Unpacker for GW2

To extract files:

GW2Unpacker.exe <dat file> x <start file index> <end file index>

Example:

GW2Unpacker.exe gw2.dat x 0 190000


It'll output to the current directory. To change the current directory, use the "cd" command.


---
Changelog
v1: Modified GWUnpacker to use decompression algorithm
v2: Categorize several GW2 file formats
v3: Bugfix for ATEP files
v4: Removed header checks so that it may work with newer GW2 dat files