"""

common data and utils

TODO some of this stuff is rather hacky and belongs elsewhere

"""

import io
import struct


PATH = 'C:/Program Files (x86)/StandingStoneGames/The Lord of the Rings Online/'


class Region:
    ERIADOR = 1
    RHOVANION = 2
    GONDOR = 3
    MORDOR = 4
    # For use with RegionDef
    Names = None, 'Eriador', 'Rhovanion', 'Gondor', 'PostPelennor'


REGION_NUMBERS = 1, 2, 3, 4


def read_vle(ins):
    result = ord(ins.read(1))
    if result & 0x80:
        b = ord(ins.read(1))
        result = ((result & 0x7f) << 8) | b
    if result == 0x4000:
        return read_uint16(ins)
    else:
        return result


def read_tsize(ins):
    """
    A large number of array types use this rather than a simple counter
    to specify their size. It's an unknown byte then a VLE count.  The
    unknown byte is roughly proportional to the array size, so perhaps
    it's a hint for a custom allocator.

    """
    ins.read(1)
    return read_vle(ins)


def read_uint32(ins):
    return struct.unpack('<L', ins.read(4))[0]


def read_int32(ins):
    return struct.unpack('<l', ins.read(4))[0]


def read_uint16(ins):
    return struct.unpack('<H', ins.read(2))[0]


def read_int16(ins):
    return struct.unpack('<h', ins.read(2))[0]


def read_uint8(ins):
    return struct.unpack('<B', ins.read(1))[0]


def read_int8(ins):
    return struct.unpack('<b', ins.read(1))[0]


def read_float(ins):
    return struct.unpack('<f', ins.read(4))[0]

        
def read_pascal_string(stream):
    length = read_vle(stream)
    return stream.read(length).decode('latin-1')


def read_prefixed_utf16(stream):
    length = read_vle(stream)
    return stream.read(length * 2).decode('utf-16')


def peek(stream, datatype):
    size = struct.calcsize(datatype)
    val, = struct.unpack('<{}'.format(datatype), stream.read(size))
    stream.seek(-size, io.SEEK_CUR)
    return val


def skip(stream, delta):
    stream.seek(delta, io.SEEK_CUR)


class Vector3D:
    def __init__(self, x, y, z):
        self.x, self.y, self.z = x, y, z
        
    def __repr__(self):
        return 'Vector3D({},{},{})'.format(self.x, self.y, self.z)


def read_vector3d(stream):
    return Vector3D(*struct.unpack('<3f', stream.read(12)))


class Quaternion:
    def __init__(self, w, x, y, z):
        self.w, self.x, self.y, self.z = w, x, y, z
        
    def __repr__(self):
        return 'Quaternion(w={},{},{},{}'.format(self.w, self.x, self.y, self.z)


def read_quaternion(stream):
    return Quaternion(*struct.unpack('<4f', stream.read(16)))


class ArbitraryBitfield:
    def __init__(self, data):
        self.data = data
        
    def flag(self, val):
        bytenum = val // 8
        bitnum = val % 8
        bitval = (self.data[bytenum] & (1 << bitnum)) >> bitnum
        return bitval == 1
        
    def value(self):
        val = 0
        for i, b in enumerate(self.data):
            for bitnum in range(8):
                bitval = b & (1 << bitnum)
                val |= bitval << (i * 8)
        return val
    

def read_bool(stream):
    val = ord(stream.read(1))
    if val == 0:
        return False
    elif val == 1:
        return True
    else:
        raise ValueError

    
def read_prefixed_array(stream, lentype, valtype):
    length, = struct.unpack('<{}'.format(lentype),
                            stream.read(struct.calcsize(lentype)))
    return struct.unpack('<{}{}'.format(length, valtype),
                         stream.read(length * struct.calcsize(valtype)))
       

def chunks(seq, size):
    i = 0
    while i < len(seq):
        yield seq[i : i + size]
        i += size

        
def hexdump(data):
    for i, chunk in enumerate(chunks(data, 16)):
        hexstr = ''.join('{:02X} '.format(c) for c in chunk)
        if len(chunk) < 16:
            hexstr += '   ' * (16 - len(chunk))
        asciistr = ''
        for c in chunk:
            if 32 <= c < 127:
                asciistr += chr(c)
            else:
                asciistr += '.'
        print('{:04X}  {} {}'.format(i * 16, hexstr, asciistr))


def hexdump_hex_only(data):
    for i, chunk in enumerate(chunks(data, 16)):
        hexstr = ''.join('{:02X} '.format(c) for c in chunk)
        if len(chunk) < 16:
            hexstr += '   ' * (16 - len(chunk))
        asciistr = ''
        for c in chunk:
            if 32 <= c < 127:
                asciistr += chr(c)
            else:
                asciistr += '.'
        print('{}'.format(hexstr))

        
def populate_object(ins, cls, fields, format):
    vals = struct.unpack(format, ins.read(struct.calcsize(format)))
    for k, v in zip(fields, vals):
        setattr(cls, k, v)
