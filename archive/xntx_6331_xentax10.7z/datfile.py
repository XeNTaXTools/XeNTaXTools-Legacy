"""

Load individual resources from .dat files and provide resource tree metadata.

TODO:
read_blocks also needs file_size as an argument, because the final (or only)
block can be larger than required, and we need to truncate.

"""

import bisect
import io
import os
import struct
import time
import zlib

import common
import dataid


class error(Exception):
    def __init__(self, msg):
        self.msg = msg


def read_blocks_old(stream, size):
    """Read old multi-block data."""
    block_size, block_offset = struct.unpack('<2L', stream.read(8))
    remainder = stream.read(size - 8)
    if block_size == block_offset == 0:
        return remainder
    stream.seek(block_offset)
    block_size2, block_offset2 = struct.unpack('<2L', stream.read(8))
    if block_size2 != 0 or block_offset2 != 0:
        raise error('ERROR old datfile version with more than 2 blocks')
    data = bytearray(stream.read(block_size))
    data.extend(remainder)
    return remainder


def read_blocks(stream, block_size):
    """Read multi-block data."""
    num_extra_blocks, legacy = struct.unpack('<2L', stream.read(8))
    if legacy != 0:
        raise error('CORRUPT OR OLD DATFILE!!!')
    first_chunk_size = block_size - 8 - num_extra_blocks * 8
    data = bytearray(stream.read(first_chunk_size))
    block_links = [struct.unpack('<2L', stream.read(8))
                   for _ in range(num_extra_blocks)]
    for size, offset in block_links:
        stream.seek(offset)
        data.extend(stream.read(size))
    return data


#-------------------------------------------------------------------------------
#
# supporting classes
#        
#-------------------------------------------------------------------------------


class Child:
    RAW_SIZE = 8

    def __init__(self, data):
        self.block_size, self.offset = struct.unpack('<2L', data)


class Key:
    RAW_SIZE = 32

    def __init__(self, data):
        self.flags, self.policy, self.did, self.offset, self.size, \
            self.timestamp, self.revision, self.block_size, pad \
            = struct.unpack('<2H7L', data)
            
    def __repr__(self):
        fmt = '{:04X} {:04X} {:08X} {:08X} {:08X} {} {:08X} {:08X}'
        return 'Key(' + fmt.format(self.flags, self.policy, self.did, \
              self.offset, self.size, time.ctime(self.timestamp), \
              self.revision, self.block_size) + ')'
              
    def compressed(self):
        return self.flags & 1


class Node:
    MAX_KEYS = 61
    RAW_SIZE = 8 + (MAX_KEYS + 1) * Child.RAW_SIZE + 4 \
               + MAX_KEYS * Key.RAW_SIZE + 8

    def __init__(self, data):
        ins = io.BytesIO(data)
        self.children = [Child(ins.read(Child.RAW_SIZE))
                         for _ in range(Node.MAX_KEYS + 1)]
        while self.children and self.children[-1].offset == 0:
            self.children.pop()
        n = struct.unpack('<L', ins.read(4))[0]
        if n > Node.MAX_KEYS:
            raise Exception('corrupt datfile node')
        self.children = self.children[:n + 1]
        self.keys = [Key(ins.read(Key.RAW_SIZE))
                         for _ in range(n)]
                         
    def __repr__(self):
        fmt = 'Node({} children, {} keys)'
        return fmt.format(len(self.children), len(self.keys))

            
#-------------------------------------------------------------------------------
#
# main DatFile class
#        
#-------------------------------------------------------------------------------


class DatFileHeader:
    FIELDS = (
        'block_size', 'file_size', 'ver1', 'ver2',
        'journal_offset', 'u1', 'u2', 'root_node_offset',
        'u3', 'engine_ver', 'datpack_ver', 'idstamp',
        'header_size', 'key_size', 'child_size', 'u7',
        'journal_size', 'block_size_2'
    )
    FORMAT = '<8L16s2L20s6L'

    def __init__(self, data):
        ins = io.BytesIO(data)
        check, = struct.unpack('<L', ins.read(4))
        if check != 0x5442:
            raise error('bad datfile header check')
        # ver1:
        # 01040000 anim
        # 02030000 cells
        # 01010000 gamelogic
        # 01030000 general
        # 01080000 highres
        # 03030000 local
        # 020a0000 maps
        # 01020000 mesh
        # 01070000 sound
        # 01090000 surface
        # observation: 1 normal extensible, 2 regional, 3 localizations
        # ver2: 0 for all but cells and maps where it's the region number,
        # and for local where it's 2 for English, 1004h for German,
        # and 1003h for French
        # u1 is either 0 or an offset
        # u2 is a small number, highest seen 47c
        # u7 looks likea  size or offset, more likely size due to
        # similarity of values
        # block_size_2 is either equal to block_size_1, or in the case
        # of cells and maps, reflects node block size rather than data
        # block sizes.
        common.populate_object(ins, self, DatFileHeader.FIELDS, DatFileHeader.FORMAT)
        # in client_general, last byte of u3 is '(', otherwise all 0
        # 3 for all but cells and maps:
        assert self.datpack_ver in (0, 3)


class DatFile:
    def __init__(self, filename):
        self._f = open(filename, 'rb')
        self._f.seek(0x140)
        raw_header = self._f.read(0x68)
        self.header = DatFileHeader(raw_header)
        if self.header.engine_ver == 111:
            self.read_blocks = read_blocks_old
        elif self.header.engine_ver == 112:
            self.read_blocks = read_blocks
        else:
            raise error('unknown DatFile engine ver')
        if os.stat(filename).st_size != self.header.file_size:
            raise error('DatFile size mismatch')
        
    def __enter__(self):
        return self
        
    def __exit__(self, etype, eval, etb):
        self._f.close()
        
    def close(self):
        self._f.close()
        
    def node(self, offset):
        """Return the node at the given offset."""
        self._f.seek(offset)
        data = self.read_blocks(self._f, Node.RAW_SIZE)
        return Node(data)
        
    def root_node(self):
        return self.node(self.header.root_node_offset)

    def key_draft(self, did):
        """Draft for a non-recursive solution. Untested."""
        node = self.node(self.header.root_node_offset)
        while True:
            for i in range(len(node.keys)):
                if did < node.keys[i].did:
                    break
            if i < len(node.keys) and did == node.keys[i].did:
                return node.keys[i]
            if not node.children:
                return None
            node = self.node(node.children[i].offset)

    def key(self, did, node_offset=None):
        """Return Key by DataID, or None if not found."""
        if node_offset is None:
            node_offset = self.header.root_node_offset
        node = self.node(node_offset)
        dids = [k.did for k in node.keys]
        index = bisect.bisect_left(dids, did)
        if index >= len(dids) or dids[index] != did:
            try:
                return self.key(did, node.children[index].offset)
            except IndexError:
                return None
        else:
            return node.keys[index]

    def exists(self, did):
        return self.key(did.raw) is not None
        
    def key_unpacked(self, did):
        """Return Key with size field replaced by uncompressed value."""
        k = self.key(did)
        if k is not None and k.compressed():
            self._f.seek(k.offset + 8)
            k.size = struct.unpack('<L', self._f.read(4))[0]
        return k
            
    def fetch_by_key(self, k):
        """Fetch a resource by key, decompressing if needed."""
        self._f.seek(k.offset)
        data = self.read_blocks(self._f, k.block_size)
        if k.compressed():
            mv = memoryview(data)
            decompressed_size = int.from_bytes(mv[:4], 'little')
            data = zlib.decompress(mv[4:],
                                   zlib.MAX_WBITS,
                                   decompressed_size)
            if len(data) != decompressed_size:
                raise error('decompressed data size mismatch')
        # TODO: this should be an error. read_blocks should handle this,
        # once it is changed to receive file_size as well as block_size.
        elif len(data) > k.size:
            data = data[:k.size]
        return data
        
    def fetch(self, did):
        """Fetch a resource by DataID or raw DataID value."""
        if isinstance(did, dataid.DataID):
            k = self.key(did.raw)
        else:
            k = self.key(did)
        if k is None:
            return None
        return self.fetch_by_key(k)
        
    def _find_file_nodes_helper(self, did, offset, nodes):
        node = self.node(offset)
        if offset != self.header.root_node_offset:
            nodes.append(offset)
        lower = 0
        upper = len(node.keys) - 1
        while lower <= upper:
            test = (lower + upper) // 2
            entry = node.keys[test]
            if entry.did < did:
                lower = test + 1
            elif entry.did > did:
                upper = test - 1
            else:
                return
        # The did is not found if it doesn't exist in a leaf:
        if node.children:
            self._find_file_nodes_helper(did,
                                         node.children[lower].offset,
                                         nodes)
        else:
            return None
        
    def find_file_nodes(self, did):
        """
        Find the nodes that lead to a file of given DataID.
        This function is needed by the TreeView Find action, which
        finds a resource by DataID then populates and expands the
        TreeView to show it.
        
        """
        nodes = []
        self._find_file_nodes_helper(did.raw,
                                     self.header.root_node_offset,
                                     nodes)
        return nodes

    def files(self, offset=None):
        """Generate all Keys in the DatFile."""
        if offset is None:
            offset = self.header.root_node_offset
        node = self.node(offset)
        if node.children:
            for child, key in zip(node.children, node.keys):
                yield from self.files(child.offset)
                yield key
            # len(node.pointers) == len(node.filerecs) + 1
            yield from self.files(node.children[-1].offset)
        else:
            for key in node.keys:
                yield key

