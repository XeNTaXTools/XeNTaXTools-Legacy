"""

blob.py

Slurps all resources in a DatFile within a range into an almighty blob.

Having all resources in a contiguous alob allows faster testing.

"""

import io
import struct

import common
from dataid import DataID
import datfile


VERSION = 2
ITERATION_RECORD_DID = 0xffff0001
FOURCC = b'BLOB'


class BlobError(Exception):
    def __init__(self, msg):
        self.msg = msg


def calculate_size(dat_filename, mindid, maxdid):
    """Calculate the size a blob will require."""
    df = datfile.DatFile(dat_filename)
    size = 0
    for file in df.files():
        if file.did < mindid:
            continue
        elif file.did > maxdid:
            break
        key_unpacked = df.key_unpacked(file.did)
        size += key_unpacked.size
    return size


def write_blob(dat_filename, mindid, maxdid, blob_filename):
    """Slurp all resources in DatFile within range into the named blob."""
    df = datfile.DatFile(dat_filename)

    iteration_rec_key = df.key(ITERATION_RECORD_DID)
    last_iteration_date = iteration_rec_key.timestamp

    # A blob containing all the 0x0c files in sequence:
    blob = bytearray()
    # DID, offset, and size of each resource destined for the blob:
    records = []

    # Slurp blob:
    for file in df.files():
        if file.did < mindid:
            continue
        elif file.did > maxdid:
            break
        records.append((file.did, len(blob), file.size))
        data = df.fetch(file.did)
        blob.extend(data)

    # Slarp blob to file:
    with open(blob_filename, 'wb') as outf:
        outf.write(FOURCC)
        outf.write(struct.pack('<L', VERSION))
        outf.write(struct.pack('<L', last_iteration_date))
        outf.write(struct.pack('<H', len(dat_filename)))
        outf.write(dat_filename.encode('ascii'))
        outf.write(struct.pack('<L', len(records)))
        packed_table = bytearray()
        for did, offset, size in records:
            chunk = struct.pack('<3L', did, offset, size)
            packed_table.extend(chunk)
        outf.write(packed_table)
        outf.write(blob)


class Blob:
    # Glarp a blob from file:
    def __init__(self, filename):
        with open(filename, 'rb') as inf:
            fourcc, version, self.last_iteration_date = struct.unpack('<4s2L', inf.read(12))
            if fourcc != FOURCC:
                raise BlobError('BLOB failed header check')
            if version != VERSION:
                raise BlobError('BLOB version mismatch: wanted {} got {}'.format(VERSION, version))
            src_filename_length, = struct.unpack('<H', inf.read(2))
            self.src_filename = inf.read(src_filename_length).decode('ascii')
            count, = struct.unpack('<L', inf.read(4))
            raw_table = inf.read(12 * count)
            self.blob = inf.read()
        ins = io.BytesIO(raw_table)
        self.table = [struct.unpack('<3L', ins.read(12))
                      for _ in range(count)]
        self.mv = memoryview(self.blob)
        self.table_map = {did: (offset, size)
                          for did, offset, size in self.table}

    def out_of_date(self):
        """Return whether the BLOB source has been updated."""
        df = datfile.DatFile(self.src_filename)
        iteration_rec = df.fetch(ITERATION_RECORD_DID)
        return iteration_rec.timestamp > self.last_iteration_date

    def files(self):
        """Generate (DID, data) pairs for each file in the blob."""
        for did, offset, size in self.table:
            yield did, self.mv[offset:offset+size]

    def fetch(self, did):
        """Fetch a file from the blob by DID."""
        offset, size = self.table_map[did]
        return self.mv[offset:offset+size]

    def offsets(self, item):
        """Return indices of all occurrences of item in blob."""
        # TODO out of date
        offsets = []
        offset = -1
        while offset < len(self.blob):
            try:
                offsets.append(self.blob.index(item, offset + 1))
            except ValueError:
                return offsets
            offset = offsets[-1] + len(item)
        return offsets

    def spanners(self, item):
        """Return DIDs of resources that contain bytes item."""
        results = set()
        for offset in self.offsets(item):  # already sorted
            for did, table_offset, size in self.table:
                if offset >= table_offset and offset + len(item) <= table_offset + size:
                    results.add(did)
                    break  # offset can't be in more than one resource!
        return [DataID(elem) for elem in sorted(results)]


if __name__ == '__main__':
    write_blob(common.PATH + 'client_general.dat', 0x02000000, 0x02ffffff, 'blobs/all_scenes.blob')
    #print('Size for all RenderMaterials:', calculate_size(common.PATH + 'client_general.dat', 0x2b000000, 0x2bffffff))

    #b = Blob('blobs/all_scriptlets.dat')
