"""

Mapping between integer keys and strings.

These mappers give useful names for all sorts of resource types and subtypes.

"""

import io
import struct

import common
from dataid import DataID
from stringinfo import StringInfo


class EnumMapper:
    def __init__(self, raw_data):
        ins = io.BytesIO(raw_data)
        did, base_did = struct.unpack('<2L', ins.read(8))
        self.did = DataID(did)
        self.base_did = DataID(base_did)
        count = common.read_tsize(ins)
        self.strings = {}
        for i in range(count):
            k, length = struct.unpack('<LB', ins.read(5))
            v = ins.read(length).decode('latin-1')
            self.strings[k] = v

        count = common.read_tsize(ins)
        self.log_strings = {}
        for i in range(count):
            k, = struct.unpack('<L', ins.read(4))
            v = StringInfo(ins)
            self.log_strings[k] = v

        if ins.tell() != len(raw_data):
            print('WARNING enum_mapper failed to hit EOF')
