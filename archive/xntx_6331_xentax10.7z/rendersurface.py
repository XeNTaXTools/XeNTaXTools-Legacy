"""

See surface.py for loading these, since it depends on Qt.

"""

import enum
import struct

from dataid import DataID


def MAKEFOURCC(a, b, c, d):
    return ord(a) | (ord(b) << 8) | (ord(c) << 16) | (ord(d) << 24)


class ImageFormat(enum.Enum):  # see d3d9types.h
    D3DFMT_R8G8B8 = 20
    D3DFMT_A8R8G8B8 = 21
    D3DFMT_A8 = 28
    FORMAT_JPEG = 500  # custom
    D3DFMT_DXT1 = MAKEFOURCC('D', 'X', 'T', '1')
    D3DFMT_DXT3 = MAKEFOURCC('D', 'X', 'T', '3')
    D3DFMT_DXT5 = MAKEFOURCC('D', 'X', 'T', '5')

    
class SurfaceHeader:
    def __init__(self, ins):
        # unk in highres.dat: 0, 1, 2, 4, 5, 6, 8, a, b, e, f
        # unk in surface aux: above but no 2 8 b
        # length is of the following image data
        did, self.unk, self.w, self.h, self.format, self.length = \
            struct.unpack('<6L', ins.read(24))
        self.did = DataID(did)


