"""

RENDER_MESH (DID 0x06nnnnnn)
These contain geometry, UVs, bones, collision data, LOD definitions,
and unknown data.
TODO

"""

import io
import struct

from common import read_uint32, read_uint16, read_uint8, read_vle
from common import read_vector3d, read_bool, read_float, peek
from dataid import DataID
from mopp import MoppData


class MeshError(Exception):
    def __init__(self, msg):
        self.msg = msg


class D3D:
    """
    See d3d9types.h, this is FVF.
    https://msdn.microsoft.com/en-us/library/windows/desktop/bb172559%28v=vs.85%29.aspx

    Note that Turbine added their own flags to FVF, see VertexType below.

    """
    D3DFVF_XYZ = 0x02
    D3DFVF_NORMAL = 0x10
    # Position of vertex in point size: in camera space units for
    # untransformed, unlit vertices; in device space units for transformed,
    # lit vertices.
    D3DFVF_PSIZE = 0x20
    # ARGB
    D3DFVF_DIFFUSE = 0x40
    # Number of texture coordinate sets present:
    D3DFVF_TEX1 = 0x100
    D3DFVF_TEX2 = 0x200
    D3DFVF_TEX3 = 0x300
    D3DFVF_TEXCOUNT_MASK = 0xf00
    D3DFVF_TEXCOUNT_SHIFT = 8


class VertexType:
    """
    See D3D above for the standard FVF flags used. Turbine have added their
    own wrinkles:

    000n0000    bone count
    10000000    tangent vector present
    20000000    binormal vector present

    TODO
    Rendering untested for VertexTypes with more than one set of texcoords.

    """

    # Confirmed from exe:
    TURBINE_TANGENT_FLAG = 0x10000000
    TURBINE_BINORMAL_FLAG = 0x20000000

    def __init__(self, flags):
        self.flags = flags

    def has_xyz(self):
        # Equality test not strictly necessary but produces a bool directly:
        return self.flags & D3D.D3DFVF_XYZ == D3D.D3DFVF_XYZ

    def has_normal(self):
        return self.flags & D3D.D3DFVF_NORMAL == D3D.D3DFVF_NORMAL

    def has_psize(self):
        return self.flags & D3D.D3DFVF_PSIZE == D3D.D3DFVF_PSIZE

    def has_diffuse(self):
        return self.flags & D3D.D3DFVF_DIFFUSE == D3D.D3DFVF_DIFFUSE

    def has_tangent(self):
        return self.flags & VertexType.TURBINE_TANGENT_FLAG

    def has_binormal(self):
        return self.flags & VertexType.TURBINE_BINORMAL_FLAG

    def tex_count(self):
        return (self.flags & D3D.D3DFVF_TEXCOUNT_MASK) >> D3D.D3DFVF_TEXCOUNT_SHIFT

    def bone_count(self):
        return (self.flags & 0x000f0000) >> 16

    def bones_offset(self):
        result = 0
        if self.flags & D3D.D3DFVF_XYZ:
            result += 3 * 4
        if self.flags & D3D.D3DFVF_NORMAL:
            result += 3 * 4
        if self.flags & D3D.D3DFVF_PSIZE:
            result += 4
        if self.flags & D3D.D3DFVF_DIFFUSE:
            result += 4
        result += self.tex_count() * 2 * 4
        if self.flags & VertexType.TURBINE_TANGENT_FLAG:
            result += 3 * 4
        if self.flags & VertexType.TURBINE_BINORMAL_FLAG:
            result += 3 * 4

        return result

    def size(self):
        """Return size of the Vertex in bytes."""
        return self.bones_offset() + self.bone_count() * 5

    @staticmethod
    def pos_offset():
        return 0

    @staticmethod
    def normal_offset():
        return 12

    def texcoord_offset(self):
        result = 0
        if self.flags & D3D.D3DFVF_XYZ:
            result += 3 * 4
        if self.flags & D3D.D3DFVF_NORMAL:
            result += 3 * 4
        if self.flags & D3D.D3DFVF_PSIZE:
            result += 4
        if self.flags & D3D.D3DFVF_DIFFUSE:
            result += 4
        return result


class BoundingBox:
    def __init__(self, ins):
        self.minx, self.miny, self.minz, self.maxx, self.maxy, \
        self.maxz = struct.unpack('<6f', ins.read(24))

    def __repr__(self):
        fmt = 'BoundingBox({:0.3f}, {:0.3f}, {:0.3f} -- {:0.3f}, {:0.3f}, {:0.3f})'
        return fmt.format(self.minx, self.miny, self.minz, self.maxx, self.maxy, self.maxz)

    def center(self):
        return (self.maxx + self.minx) / 2, (self.maxy + self.miny) / 2, \
               (self.maxz + self.minz) / 2

    def radius(self):
        cx, cy, cz = self.center()
        x, y, z = self.maxx - cx, self.maxy - cy, self.maxz - cz
        h = (x * x + y * y + z * z) ** 0.5
        return h


def is_normalized(v):
    """True if Vector3D v is normalized."""
    e = 0.0001
    return abs(v.length() - 1.0) <= e


class VertexGroup:
    """
    VertexGroup contains a list of vertices and associated data.
    The data includes a vertex type, the vertices themselves, the
    bounding box of the vertices, and a list of bone indices.

    """

    def __init__(self, ins):
        self.type = VertexType(read_uint32(ins))
        num_vertices = read_uint32(ins)
        # Read as raw data for now, rather than processing into
        # the custom Vertex type:
        self.raw_vertices = ins.read(num_vertices * self.type.size())
        self.bounding_box = BoundingBox(ins)
        # These values are a flattened version of the vertex bone
        # indices, assuming that is what the vertex values are. To set
        # up this list: make an int32 buffer, reverse iterate through
        # the vertices, for each element in position [0], copy it into
        # the buffer, continue to copy element [0] into the buffer each
        # time subsequent elements (in position[1], position[2] etc.)
        # are nonzero.
        # Note this means that this section will be empty for groups
        # with 0 bones per vertex, and equal in length to the vertex
        # list for groups with 1 bone per vertex.
        num_indices = read_uint32(ins)
        self.flattened_bone_indices = [read_uint32(ins)
                                       for _ in range(num_indices)]


class VertexRef:
    """
    Each LOD in the mesh file may contain multiple meshes.  For example, the file
    may contain 3 LODs each of which uses 4 meshes.

    mesh_index refers to a mesh within the given LOD, and vertex_index to a vertex
    in that mesh's vertex group.

    """

    def __init__(self, ins):
        self.mesh_index, self.vertex_index = struct.unpack('<BH', ins.read(3))


class Triangle:
    """
    vertex_ref is an index into the list of VertexRefs.
    node_index is an index into the list of Nodes.

    """

    def __init__(self, ins):
        self.vertex_ref_1, self.node_index_1, \
        self.vertex_ref_2, self.node_index_2, \
        self.vertex_ref_3, self.node_index_3 = \
            struct.unpack('<6h', ins.read(12))

    def __repr__(self):
        return 'Tri({},{},{},{},{},{})'.format(self.vertex_ref_1, self.node_index_1,
                                               self.vertex_ref_2, self.node_index_2, self.vertex_ref_3,
                                               self.node_index_3)


class Node:
    """
    TODO
    Not understood.  The name Node might be totally wrong.

    This is suspected to be part of a node list defining left and right
    children.

    It might also have something to do with culling information: front and
    back faces?

    vertex_ref is an index into the list of VertexRefs.
    triangle_index is an index into the list of triangles.

    triangle_index_2 can be -1: no child?
    triangle_index_1 apparently can't be -1, didn't run full test
    TODO
    run full test!

    """

    def __init__(self, ins):
        self.vertex_ref_1, self.triangle_index_1, \
        self.vertex_ref_2, self.triangle_index_2 = struct.unpack('<4h', ins.read(8))

    def __repr__(self):
        return 'Node({},{},{},{})'.format(self.vertex_ref_1, self.triangle_index_1,
                                          self.vertex_ref_2, self.triangle_index_2)


class LodData:
    """
    TODO
    The name LodData might not be the best.

    See Node (above) for more comments on the unknown purpose of some of
    this data.

    Additional comments on the VertexRefs + Triangles + Nodes data:

    In some files having this section, there are no bones associated with
    the vertices.  It doesn't make sense for a building to have a skeleton,
    so the data probably isn't that.

    MOPP data, which is used for collision detection, is present after this
    data, so probably this data isn't collision-related.

    It might make sense that this data is somehow used to specify how to
    compose models that have multiple meshes.  However, many models have
    only a single mesh but still have data in this section.

    Note again the guesses in Node docstring that this is a tree structure,
    or related to front / back culling.


    """

    def __init__(self, ins):
        # HACK: In cases where this unknown section follows another,
        # there can be an alignment problem due to an extra byte 01
        # following the preceding MOPP data. We do a crude test for
        # this here to force the file to pass testing:
        a = read_uint32(ins)
        if a not in (1, 2):
            if a in (257, 513):
                # compensate for the unknown 01 byte:
                a >>= 8
                a2 = read_uint8(ins)
                assert a2 == 0
            else:
                # 2 in 06003041; no apparent meaning, i.e. by ignoring it,
                # we can still read the remaining information.
                # TODO
                # test whether 2 occurs anywhere else
                pass

        lodcount = read_uint32(ins)
        self.lod_indices = []  # Indices of each mesh in the LOD
        for i in range(lodcount):
            # Example values for a mesh file having 13 meshes,
            # in 3 groups of 4 with a single at the end:
            # 4 0 0 0, 4 1 1 1, 4 2 2 2, 4 3 3 3
            # 4 4 4 4, 4 5 5 5, 4 6 6 6, 4 7 7 7
            # 4 8 8 8, 4 9 9 9, 4 10 10 10, 4 11, 11, 11
            # 4 12 12 12
            # Perhaps there are three values to cover MaterialInstance,
            # VertexGroup and ElementArray data.
            b0, b1, b2, b3 = struct.unpack('<B3L', ins.read(13))
            assert b1 == b2 == b3
            if b0 != 4:
                raise MeshError('unk section unexpect b marker')
            self.lod_indices.append(b1)

        if read_bool(ins):
            num_vertex_refs = read_uint32(ins)  # can be zero
            self.vertex_refs = [VertexRef(ins) for _ in range(num_vertex_refs)]
            num_triangles = read_uint32(ins)  # can be zero
            self.triangles = [Triangle(ins) for _ in range(num_triangles)]
            num_nodes = read_uint32(ins)  # can be zero
            self.nodes = [Node(ins) for _ in range(num_nodes)]
            # TODO
            # Find some examples of meshes with zero of one of the arrays,
            # but nonzero of others.  E.g. a mesh with several VertexRefs,
            # several Triangles, but no Nodes.

        if read_bool(ins):
            if read_bool(ins):
                self.mopp_data = MoppData(ins)


class RenderMesh:
    def __init__(self, source):
        if isinstance(source, bytes) or isinstance(source, bytearray):
            ins = io.BytesIO(source)
            self._load(ins)
        elif isinstance(source, io.BytesIO):
            self._load(source)
        else:
            raise TypeError('bad input to RenderMesh')

    def _load(self, ins):
        self.did = DataID(read_uint32(ins))
        # For names see MeshTypeID in ENUM_MAPPER
        self.mesh_type_id = read_uint32(ins)

        # Together, the materials, 'vertex groups' and element arrays should
        # be reorganized as MeshLODGroups.
        # LOD0 is maximum detail.
        # For exporting, use names like MeshName_LOD0 etc.
        # Correction:
        # Don't do the above. Not every mesh in a RENDER_MESH is just another
        # LOD.
        # They can be different components of the same compound model.
        # They can even be entirely unrelated to each other, like a bundle
        # of doodads from the same content update.

        # MATERIALINSTANCE DIDs.
        num_materials = read_uint32(ins)
        self.materials = [DataID(read_uint32(ins))
                          for _ in range(num_materials)]

        num_vertex_groups = read_uint32(ins)
        if num_vertex_groups != num_materials:
            raise MeshError('unequal material and vgroup counts')
        self.vertex_groups = [VertexGroup(ins)
                              for _ in range(num_vertex_groups)]

        num_element_arrays = read_uint32(ins)
        if num_element_arrays != num_vertex_groups:
            raise MeshError('unequal element array and vgroup counts')
        self.element_arrays = []
        for i in range(num_element_arrays):
            num_indices = read_uint32(ins)
            if num_indices % 3 != 0:
                raise MeshError('bad element array size')
            # Each index is into the corresponding vertex list. Number
            # should be divisible by 3, as each 3 make a tri
            indices = ins.read(num_indices * 2)
            # indices = [read_uint16(ins) for _ in range(num_indices)]
            self.element_arrays.append(indices)

        num_lods = read_uint32(ins)
        self.collision_sections = [LodData(ins) for _ in range(num_lods)]


# TESTS
if __name__ == '__main__':
    raise Exception('beware, this is a slow test')
    import common
    import datfile
    df = datfile.DatFile(common.PATH + 'client_mesh.dat')
    for f in df.files():
        if f.did < 0x06000000:
            continue
        elif f.did > 0x06ffffff:
            break
        raw_data = df.fetch(f.did)
        rm = RenderMesh(raw_data)
        # Collect examples that have multiple UVs.
        for i, vg in enumerate(rm.vertex_groups):
            tc = vg.type.tex_count()
            if tc > 1:
                print('rendermesh {:08X} mesh {} has {} UVs'.format(f.did, i, tc))
