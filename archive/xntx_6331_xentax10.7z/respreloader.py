"""

This module opens all the available dat files and allows a raw resource
to be fetched by DataID without needing to know which file it lives in.

"""

import os
import struct

import common
from datfile import DatFile


# Improvised term: DatPack
# A DatPack is a single DatFile or a collection of associated DatFiles,
# providing an interface to extensible, regional, or localized DatFiles.


class ExtentsRecord:
    DID = 0xffff0005

    def __init__(self, data):
        self.stamp = data[:16]
        self.file_num, self.file_count = struct.unpack('<2L', data[16:24])


class DatPackExtensible:
    """
    Extensible datpacks are the most common type.  They split into
    multiple files when they exceed 4GB.
    
    """
    def __init__(self, path, name):
        self.files = []
        self.filenames = []
        filename = 'client_{}.dat'.format(name)
        try:
            self.files.append(DatFile(os.path.join(path, filename)))
        except FileNotFoundError:
            print('Failed to find {}'.format(filename))
            return
        self.filenames.append(filename)
        raw_extents = self.files[0].fetch(ExtentsRecord.DID)
        if raw_extents is None:
            #print('No extents record found, looks like an early version')
            return
        extents = ExtentsRecord(raw_extents)
        for i in range(1, extents.file_count):
            filename = 'client_{}_aux_{}.datx'.format(name, i)
            self.files.append(DatFile(os.path.join(path, filename)))
            self.filenames.append(filename)

    def close(self):
        for file in self.files:
            file.close()
            
    def fetch(self, did):
        """Fetch a resource from any of the pack's extent files."""
        for file in self.files:
            result = file.fetch(did)
            if result is not None:
                return result
        return None
        

class DatPackRegional:
    """
    Regional datpacks have separate files for each game region,
    of which there are currently 4.
    
    """
    def __init__(self, path, name):
        self.files = []
        self.filenames = []
        for i in common.REGION_NUMBERS:
            filename = 'client_{}_{}.dat'.format(name, i)
            try:
                self.files.append(DatFile(os.path.join(path, filename)))
                self.filenames.append(filename)
            except FileNotFoundError:
                print('Failed to find {}'.format(filename))
            
    def close(self):
        for file in self.files:
            file.close()
            
    def fetch(self, did):
        region = did.region
        return self.files[region - 1].fetch(did)
        

class DatPackLocalized:
    """
    Localized datpacks exist in separate files for each supported language.
    
    """
    def __init__(self, path, name, language):
        self.filename = 'client_{}_{}.dat'.format(name, language)
        self.file = DatFile(os.path.join(path, self.filename))

    def close(self):
        self.file.close()
        
    def fetch(self, did):
        return self.file.fetch(did)
        
        
# This is the complete mapping as of May 2018:
_FILE_TO_RES_TYPES = {
    'anim'      : (5, ),
    'cell'      : (0x27, 0x80),
    'gamelogic' : (0x07, 0x0c, 0x34, 0x43, 0x47, 0x56, 0x70, 0x76,
                   0x78, 0x79),
    'general'   : (0x01, 0x02, 0x04, 0x08, 0x0e, 0x0f, 0x11, 0x12,
                   0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x1d,
                   0x1f, 0x20, 0x21, 0x23, 0x28, 0x2a, 0x2b, 0x2d,
                   0x30, 0x31, 0x32, 0x33, 0x35, 0x39, 0x40, 0x42,
                   0x44, 0x51, 0x66),
    'highres'   : (0x41, ),
    'local'     : (0x0a, 0x0e, 0x1d, 0x22, 0x25, 0x30, 0x40, 0x41,
                   0x42, 0x58, 0x78),
    'map'       : (0x80, ),
    'mesh'      : (0x06, ),
    'sound'     : (0x0a, ),
    'surface'   : (0x41, )
}

# Inversion of the above mapping:
_RES_TYPE_TO_FILE = {}
for k, v in _FILE_TO_RES_TYPES.items():
    for t in v:
        if t in _RES_TYPE_TO_FILE:
            _RES_TYPE_TO_FILE[t].append(k)
        else:
            _RES_TYPE_TO_FILE[t] = [k]


# All datfiles keyed by name:
_datfiles = {}
# Flat lists used by the TreeView:
sorted_datfiles = []  # tuples of (filename, datfile)


def startup(path):
    global _datfiles
    global sorted_datfiles

    for name in _FILE_TO_RES_TYPES:
        if name in ('cell', 'map'):
            _datfiles[name] = DatPackRegional(path, name)
        elif name == 'local':
            _datfiles[name] = DatPackLocalized(path, name, 'English')
        else:
            _datfiles[name] = DatPackExtensible(path, name)

    for k in _datfiles.values():
        try:
            sorted_datfiles.extend((fn, d)
                                   for (fn, d) in zip(k.filenames, k.files))
        except AttributeError:
            sorted_datfiles.append((k.filename, k.file))
    sorted_datfiles.sort()


def shutdown():
    global _datfiles
    global sorted_datfiles
    for file in _datfiles.values():
        file.close()
    _datfiles = {}
    sorted_datfiles = []


def fetch(did):
    """
    Fetch any resource by its ResID, or return None if not found.
    This is the only way the rest of the program should ask for a resource,
    all the mapping and datfile.py internals being hidden.
    
    """
    for file in _RES_TYPE_TO_FILE[did.major]:
        data = _datfiles[file].fetch(did)
        if data is not None:
            return data
    return None


def find_datfile_of_did(did):
    """Return the DatFile that contains the given DataID."""
    for f in _RES_TYPE_TO_FILE[did.major]:
        if _datfiles[f].fetch(did) is not None:
            try:
                for df in _datfiles[f].files:
                    if df.exists(did):
                        return df
            except AttributeError:
                if _datfiles[f].file.exists(did):
                    return _datfiles[f].file
            #print(_datfiles[f])
            #return _datfiles[f]
    return None


startup(common.PATH)
