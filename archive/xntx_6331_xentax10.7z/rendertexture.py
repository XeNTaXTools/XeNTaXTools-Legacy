"""

RenderTexture is basically a list of RenderSurfaces at different LOD.

"""

import io

from common import read_uint32, read_uint8
from dataid import DataID


class RenderTexture:
    def __init__(self, data):
        ins = io.BytesIO(data)
        self.did = DataID(read_uint32(ins))
        # 2 or 4 - only 8 are 4
        self.flags = read_uint8(ins)
        # Size distribution:
        # {1: 1249, 2: 8, 3: 68, 4: 474, 5: 236, 6: 1044,
        # 7: 29295, 8: 8365, 9: 7766, 10: 1444, 11: 62, 12: 3}
        numids = read_uint8(ins)
        # At last survey, 50014 total textures, 494 with c == 1
        # c: 0 or 1, d: 0, e: 0
        # Checked a few with c == 1, all seem to be imposter sheets
        self.isImposterSheet, self.d, self.e = ins.read(3)
        self.surfaces = [DataID(read_uint32(ins))
                         for _ in range(numids)]
        """
        If self.flags == 4, 
        lasts: 0x4100002c 0x4100002c
        lasts: 0x4100002e 0x4100002e
        lasts: 0x4100002c 0x4100002c
        lasts: 0x410dc851 0x410dc851
        lasts: 0x4100002e 0x4100002e
        lasts: 0x410e6bef 0x410e6bef
        lasts: 0x410e9fe6 0x410e9fe7
        lasts: 0x41116fbf 0x41116fbf
        In all other cases, they are 0 and 0f

        Checked them out. Here's what they are.
        4100002c solid black?
        4100002e solid black?
        410dc851 greyscale, ice-like?
        410e6bef greyscale, water-like?
        41116fbf solid black?
        410e9fe6 starry sky top half black bottom half
        410e9fe7 starry sky
        What's the point?
        """
        self.last1 = DataID(read_uint32(ins))
        self.last2 = DataID(read_uint32(ins))


if __name__ == '__main__':
    """
    import datfile
    df = datfile.DatFile(PATH + 'client_general.dat')
    sizes = set()
    for file in df.files():
        if file.did < 0x40000000:
            continue
        elif file.did >= 0x41000000:
            break
        raw_res = df.fetch(file.did)
        try:
            t = TextureLODGroup(raw_res)
        except:
            print(hex(file.did))
            raise
        sizes.add(len(t.texture_dids))
    """
    import blob
    b = blob.Blob('all40.dat')
    sizes = {}
    for did, data in b.files():
        pass
            


