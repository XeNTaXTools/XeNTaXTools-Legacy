import struct


class MoppData:
    """
    Havok data for collision detection.

    We have no plans to parse this for now, just read as an anonymous chunk.

    """
    def __init__(self, ins):
        self.origin = struct.unpack('<3f', ins.read(12))
        self.scale, size = struct.unpack('<fL', ins.read(8))
        self.data = ins.read(size)


"""

# Unused fragment for parsing Havok MOPP data. This is a rabbit hole, don't bother.

# This code was found 'somewhere'
# TODO
# Find where and attribute it to the correct author.

def parse_mopp(data):
    ins = io.BytesIO(data)
    _parse_mopp(data, ins)


def _parse_mopp(data, ins, start=0, depth=0, toffset=0):
    tris = []  # triangle indices
    returning = False
    while ins.tell() < len(data) and not returning:
        code = read_uint8(ins)
        msg = '{:08X} ' + ' ' * depth + '{:02X}'.format(code)
        if code == 0x09:
            # increment triangle offset
            arg = read_uint8(ins)
            toffset += arg
            msg += '{} [ tri offs += {}, offs now {} ]'.format(arg, arg, toffset)
        elif code == 0x0a:
            # increment triangle offset
            arg, = struct.unpack('>H', ins.read(2))  # TODO BIG ENDIAN TEST
            msg += '[ tri offs += {}, offs now {} ]'.format(arg, toffset)
        elif code == 0x0b:
            # unsure about first two arguments, but 3rd and 4th set tri offs
            arg1, arg2, arg3 = struct.unpack('>2BH', ins.read(4))
            toffset += arg3
            msg += '[ tri offs {} ]'.format(toffset)
        elif code in range(0x30, 0x50):
            # triangle compact
            msg += '[ tri {} ]'.format(code - 0x30 + toffset)
            tris.append(code - 0x30 + toffset)
            returning = True
        elif code == 0x50:
            # triangle byte
            arg = read_uint8(ins)
            msg += '[ tri {} ]'.format(arg + toffset)
            tris.append(arg + toffset)
            returning = True
        elif code == 0x51:
            # triangle short
            arg, = struct.unpack('>h', ins.read(2))
            msg += '[ tri {} ]'.format(arg)
            tris.append(arg)
            returning = True
        elif code == 0x53:
            # triangle short?
            arg1, arg2, arg3 = struct.unpack('>2BH', ins.read(4))
            msg += '[ tri {} ]'.format(arg3)
            tris.append(arg3)
            returning = True
        elif code == 0x05:
            # byte jump
            arg = read_uint8(ins)
            msg += '[ jump -> {} ]'.format(ins.tell() + arg)
            ins.seek(arg, io.SEEK_CUR)
        elif code == 0x06:
            # short jump
            arg, = struct.unpack('>H', ins.read(2))
            msg += '[ jump -> {} ]'.format(ins.tell() + arg)
            ins.seek(arg, io.SEEK_CUR)
        elif code in range(0x10, 0x1d):
            # compact if-then-else with two arguments
            arg1, arg2, arg3 = ins.read(3)
            if code == 0x10:
                msg += '[ branch X'
            elif code == 0x11:
                msg += '[ branch Y'
            elif code == 0x12:
                msg += '[ branch Z'
            else:
                msg += '[ branch ?'
            saved_pos = ins.tell()
            msg += '-> {} | {} ]'.format(ins.tell(), ins.tell() + arg3)
            msg += 'if:'
            more_tris1 = _parse_mopp(data, ins, 0, depth + 1, toffset)
            msg += 'else:'
            ins.seek(saved_pos + arg3, io.SEEK_CUR)
            more_tris2 = _parse_mopp(data, ins, 0, depth + 1, toffset)
            ins.seek(saved_pos)
            tris.extend([more_tris1, more_tris2])
            returning = True
        elif code in (0x20, 0x21, 0x22):
            # compact if-then-else with one argument
            arg1, arg2 = ins.read(2)
            msg += '[ branch ? -> {} | {}'.format(ins.tell(), ins.tell() + arg2)
            msg += 'if:'
            saved_pos = ins.tell()
            _parse_mopp(data, ins, 0, depth + 1, toffset)
            msg += 'else:'
            ins.seek(saved_pos + arg2)
            _parse_mopp(data, ins, 0, depth + 1, toffset)
            ins.seek(saved_pos)
            tris.extend(['tris from if', 'tris from else'])
            returning = True
        elif code in (0x23, 0x24, 0x25):
            # short if x <= a then 1; if x > b then 2
            unk, jump1, jump2 = struct.unpack('>3H', ins.read(6))
            msg += '[ branch ? -> {} | {}'.format(ins.tell() + jump1, ins.tell() + jump2)
            saved_pos = ins.tell()
            msg += 'if:'
            ins.seek(saved_pos + jump1)
            _parse_mopp(data, ins, 0, depth + 1, toffset)
            ins.seek(saved_pos + jump2)
            msg += 'else:'
            _parse_mopp(data, ins, 0, depth + 1, toffset)
            ins.seek(saved_pos)
            tris.extend(['tris from if', 'tris from else'])
            returning = True
        elif code in (0x26, 0x27, 0x28):
            args = ins.read(2)
            if code == 0x26:
                msg += '[ bound X : {}]'.format(args)
            elif code == 0x27:
                msg += '[ bound Y : {}]'.format(args)
            else:
                msg += '[ bound Z : {}]'.format(args)
        elif code in (0x01, 0x02, 0x03, 0x04):
            args = ins.read(3)
            msg += '[ bound XYZ? : {} ]'.format(args)
        else:
            msg += 'unknown mopp code {:02X} at {:08X}'.format(code, ins.tell() - 1)
            raise ValueError
        print(msg)
    return tris

"""