"""

Map names to DataIDs.  Related to EnumMapper.  0x28000000 is the master
mapper.  See enum_mapper.py

"""

import io
import struct

import common
from dataid import DataID


class DIDMapper:
    def __init__(self, raw_data):
        ins = io.BytesIO(raw_data)
        self.did, = struct.unpack('<L', ins.read(4))
        
        self.dids = {}
        self.names = {}

        while ins.tell() < len(raw_data):
            count = common.read_tsize(ins)
            for i in range(count):
                k, v = struct.unpack('<2L', ins.read(8))
                self.dids[k] = DataID(v)
            count = common.read_tsize(ins)
            for i in range(count):
                k, length = struct.unpack('<LB', ins.read(5))
                name = ins.read(length).decode('ascii')
                self.names[k] = name

        self.names_to_keys = {}
        for k, v in self.names.items():
            self.names_to_keys[v] = k


