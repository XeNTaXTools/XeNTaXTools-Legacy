import io
import struct

from common import read_uint32, read_float, read_uint8
from dataid import DataID


MAP = 0x04
RGBA = 0x10
LIGHT_VALUES = 0x40
# TODO: Many other values discovered in EnumMapper, code relying on this is brittle:
DIFFUSE_MAP = 3000
BUMP_MAP = 3011
SPECULAR_MAP_1 = 3013
SPECULAR_MAP_2 = 3018


class MaterialColor:
    # Note that this is a guess only, the data needs visualization.  It could be
    # a Waveform (see properties.py)
    def __init__(self, ins):
        self.Ka_r, self.Ka_g, self.Ka_b, \
            self.Kd_r, self.Kd_g, self.Kd_b, \
            self.Ks_r, self.Ks_g, self.Ks_b, \
            self.Ns = struct.unpack('<10f', ins.read(40))

    def __repr__(self):
        return 'MaterialColor({})'.format(vars(self))


class MaterialProperty:
    def __init__(self, ins):
        # h confirmed always in 1000, 2000, 3000, 4000
        # material_property_id is in EnumMapper:MaterialPropID
        # occurrences of mtype and h:
        # {0x10: {2000}, 0x40: {1000}, 0x04: {4000, 3000}}
        self.material_property_id, self.h, self.mtype = \
            struct.unpack('<LHL', ins.read(10))
        if self.mtype == MAP:  # note this data is 0x04 long
            val = read_uint32(ins)
            if val == 0:
                self.data = False
            elif val == 1:
                self.data = True
            else:
                self.data = DataID(val)
        elif self.mtype == RGBA:  # note this is 0x10 long
            # confirmed all values between 0.0 and 1.0
            self.data = struct.unpack('<4f', ins.read(16))
        elif self.mtype == LIGHT_VALUES:  # note this is not 0x40 long...
            # Looks like this could be WaveformValue, based on EditMaterialScript properties
            # This is 1..9 in all files except the two problem children:
            # TODO 30006274 and 30006f98, self.a is 10 there
            self.a = read_uint32(ins)
            if self.a == 1:
                self.data = read_float(ins)
            elif self.a == 10:
                self.data = MaterialColor(ins)  # TODO: values make this look like translation matrix not color
                self.extrafloat = read_float(ins)
                b = read_uint8(ins)
                assert b == 1
                pair_count = read_uint32(ins)  # occur: 7 and 10
                floaties = [read_float(ins) for _ in range(pair_count * 2)]
                """
                These occur in 30006274 and 30006f98
                all 3 occurrences:
                10.0 [0.0, 0.0, 100.0, 1.0, 100.0, 25.0, 200.0, 26.0, 200.0, 50.0,
                      720.0, 51.0, 720.0, 75.0, 500.0, 76.0, 500.0, 99.0, 0.0, 100.0]
                (second occurrence equal to the above)
                5.0  [-1.0, 100.0, -1.0, 0.0, 0.0, 20.0, -2.0, 40.0, 0.0, 60.0, -1.0, 74.055, 0.0, 86.902]

                """
                print('warning: extra data for', self.data, ':', self.extrafloat, floaties)
            else:
                self.data = MaterialColor(ins)
        else:
            print('unknown material field type', hex(self.mtype))
            raise ValueError

        # Always 0 in MaterialProperty resources, but not in MaterialProperties embedded in RenderMaterials.
        unk_count = read_uint32(ins)
        # confirmed always 0/1
        self.last_bool = read_uint8(ins)
        assert self.last_bool in (0, 1)
        self.last_bool = self.last_bool == 1

        self.unks = []
        for i in range(unk_count):
            # aval: 0..11, 32..43 - bitfield?
            # like_h: confirmed same range as h
            # unk: 0..7
            # index is into this list
            aval, like_h, index, unk = struct.unpack('<2H2L', ins.read(12))
            self.unks.append((aval, like_h, index, unk))


class MaterialModifier:
    def __init__(self, data):
        ins = io.BytesIO(data)
        self.did = DataID(read_uint32(ins))
        num_entries = read_uint32(ins)
        self.entries = [MaterialProperty(ins) for i in range(num_entries)]

        if ins.tell() != len(data):
            print('res30 missed eof in ', self.did)

    def get_diffuse_map(self, textype):
        for entry in self.entries:
            if entry.mtype == MAP and entry.material_property_id == textype:
                return entry.data
        return None
