"""

EnumMapper

This module loads EnumMapper (23nnnnnn) and DIDMapper (28nnnnnn).

TODO:

def did_of_name(name):
    return did of a resource named in these mappings

This will enable e.g.
    raw_places_table = respreloader.fetch(did_of_name('PlacesTable'))

Add an inspector for DIDMapper to the tree view.

"""

from dataid import DataID
import respreloader
from dbo.didmapper import DIDMapper
from dbo.enummapper import EnumMapper
import dbo.stringtable


def load_enum_mapper(did):
    """Use this, not the constructor, because one can link to another."""
    first = EnumMapper(respreloader.fetch(did))
    if first.base_did.raw == 0:
        return first
    second = EnumMapper(respreloader.fetch(first.base_did))
    for k, v in second.strings.items():
        first.strings[k] = v
    for k, v in second.log_strings.items():
        first.log_strings[k] = v
    return first


base_map = DIDMapper(respreloader.fetch(DataID(0x28000000)))
child_maps = {}
for name, k in base_map.names_to_keys.items():
    if k == 0:  # UNDEFINED
        continue
    raw_res = respreloader.fetch(base_map.dids[k])
    if raw_res is not None:  # some are server-side
        child_maps[name] = DIDMapper(raw_res)

enum_mapper_cache = {}  # associate name with EnumMapper


def find_did(path):
    did_mapper_name, key_string = path.split('/')
    dmapper = child_maps[did_mapper_name]
    for k, v in dmapper.names.items():
        if v == key_string:
            return dmapper.dids[k]
    return None


def fetch_by_did_and_token(did, token):
    raw_res = respreloader.fetch(did)
    if did.raw >> 24 == 0x23:
        r = EnumMapper(raw_res)
        try:
            result = r.strings[token]
        except KeyError:
            result = '(key error {:08X})'.format(token)
    elif did.raw >> 24 == 0x28:
        r = DIDMapper(raw_res)
        try:
            result = r.names[token]
        except KeyError:
            result = '(key error {:08X})'.format(token)
    else:
        raise Exception('bad did source for enum or did mapper')
    return result

 
def fetch_string(path, key):
    # e.g. result = enum_mapper.fetch_string('EMAPPER/MaterialTypeID', 0x100000ea)
    mapper_name, enum_mapper_name = path.split('/')
    try:
        emapper = enum_mapper_cache[enum_mapper_name]
    except KeyError:
        child_map = child_maps[mapper_name]
        key_to_enum_mapper = child_map.names_to_keys[enum_mapper_name]
        enum_mapper_did = child_map.dids[key_to_enum_mapper]
        emapper = load_enum_mapper(enum_mapper_did)
        enum_mapper_cache[enum_mapper_name] = emapper
    return emapper.strings[key]


def fetch_description(path, key):
    # e.g. result = enum_mapper.fetch_string('EMAPPER/MaterialTypeID', 0x100000ea)
    mapper_name, enum_mapper_name = path.split('/')
    try:
        emapper = enum_mapper_cache[enum_mapper_name]
    except KeyError:
        child_map = child_maps[mapper_name]
        key_to_enum_mapper = child_map.names_to_keys[enum_mapper_name]
        enum_mapper_did = child_map.dids[key_to_enum_mapper]
        emapper = load_enum_mapper(enum_mapper_did)
        enum_mapper_cache[enum_mapper_name] = emapper
    sinfo = emapper.log_strings[key]
    if sinfo.is_literal:
        return sinfo.val
    else:
        rawst = respreloader.fetch(sinfo.did)
        st = dbo.stringtable.StringTable(rawst)
        return st[sinfo.token]


if __name__ == '__main__':
    import common
    from dataid import DataID
    import datfile
    import respreloader
    df = datfile.DatFile(common.PATH + 'client_general.dat')
    for f in df.files():
        if f.did < 0x23000000:
            continue
        elif f.did > 0x23ffffff:
            break
        r = load_enum_mapper(DataID(f.did))
        maxk = max(k for k in r.name_map)
        if 0x10000019 <= maxk < 0x10000100:
            print(DataID(f.did), hex(maxk))

