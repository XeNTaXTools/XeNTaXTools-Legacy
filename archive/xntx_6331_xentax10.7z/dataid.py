"""

All resources in the client_* data files are identified by a 32-bit integer.
Generally, the MSB can be used to predict the data type.  More specifically,
the table _type_ranges should be used.

The type names given are DBOTypes, i.e. database objects.  These names were
found in the DBOType EnumMapper, and the mapping between DBOType keys in the
mapper and DataID ranges was found by disassembly.  The relevant code was
very quickly found by searching for the unique DataID 0x0ebada55.

Progress:
All DataID types have now been identified.

"""

_type_ranges = (
    (0x01000000, 0x01ffffff, 'CELLMESH'),
    (0x02000000, 0x02ffffff, 'SCENE'),
    (0x04000000, 0x04ffffff, 'SETUP'),
    (0x05000000, 0x05ffffff, 'DBANIMATOR'),
    (0x06000000, 0x06ffffff, 'RENDER_MESH'),
    (0x07000000, 0x07ffffff, 'SCRIPTTABLE'),
    (0x08000000, 0x08ffffff, 'CAMERASTATE'),
    (0x09000000, 0x09ffffff, 'VISIODESC'),  # beta, deprecated
    (0x0a000000, 0x0affffff, 'SOUND'),
    (0x0c000000, 0x0cffffff, 'SCRIPTLET'),
    (0x0d000000, 0x0dffffff, 'MOVIE'),
    (0x0e000002, 0x0e000002, 'SEGMENT_TABLE'),
    (0x0e000003, 0x0e000003, 'FILE2ID_TABLE'),
    (0x0e000004, 0x0e000004, 'PLACES_TABLE'),
    (0x0e000005, 0x0e000005, 'HOUSINGDB'),  # beta, deprecated
    (0x0e000006, 0x0e00ffff, 'MAPNOTE_DESC'),
    (0x0e010000, 0x0e01ffff, 'COMPRESSION_DICTIONARY'),
    (0x0e100001, 0x0e100001, 'FARVIEWENTITIES'),
    (0x0e100003, 0x0e100003, 'STRING_TOKEN_MAPPER'),
    (0x0e100009, 0x0e100009, 'FALLBACK_MAPPER_TABLE'),
    (0x0e100010, 0x0e100030, 'MONITOREDPROPERTIES'),
    (0x0e200000, 0x0e20001f, 'NAME_FILTER_TABLE'),
    (0x0e400000, 0x0e4fffff, 'QUEST_MAPNOTE_DESC'),
    (0x0ebada55, 0x0ebada55, 'TABOO_TABLE'),
    (0x0f000000, 0x0fffffff, 'REGION'),
    (0x11000000, 0x11ffffff, 'SCENE_DESC'),
    (0x12000000, 0x12ffffff, 'TERRAIN_DESC'),
    (0x14000000, 0x14ffffff, 'ENCOUNTER_DESC'),
    (0x15000000, 0x15ffffff, 'SKY_DESC'),
    (0x16000000, 0x16ffffff, 'WATER_DESC'),
    (0x17000000, 0x17ffffff, 'FOG_DESC'),
    (0x18000000, 0x18ffffff, 'PROPERTY_DESC'),
    (0x19000000, 0x19ffffff, 'TERRAIN_TYPE_TABLE'),
    (0x1a000000, 0x1affffff, 'DAY_DESC'),
    (0x1d000000, 0x1dffffff, 'KEYMAP'),
    (0x1f000000, 0x1fffffff, 'VISUAL_DESC'),
    (0x20000000, 0x20ffffff, 'APPEARANCE'),
    (0x21000000, 0x21ffffff, 'UI_SCENE'),
    (0x22000000, 0x22ffffff, 'UI_LAYOUT'),
    (0x23000000, 0x23ffffff, 'ENUM_MAPPER'),
    (0x24000000, 0x24ffffff, 'LAND_BLOCK_TERRAIN_LIST'),
    (0x25000000, 0x26ffffff, 'STRINGTABLE'),
    (0x27000000, 0x27ffffff, 'RENDER_IMPOSTER_TABLE'),
    #(0x28000000, 0x28000000, 'DID_MAPPER'),
    (0x28000000, 0x280000ff, 'DID_MAPPER'),
    (0x2a000000, 0x2affffff, 'SOUNDINFO'),
    (0x2b000000, 0x2bffffff, 'RENDERMATERIAL'),
    (0x2c000000, 0x2cffffff, 'MUSICINFO'),  # beta, deprecated
    (0x2d000000, 0x2dffffff, 'COMPUTESHADER'),  # not present in beta
    (0x30000000, 0x30ffffff, 'MATERIALMODIFIER'),
    (0x31000000, 0x31ffffff, 'MATERIALINSTANCE'),
    # easy parse: did, count, entry: index, eight floats
    # names of each are found in RenderLODClass stringtable
    (0x32000000, 0x32000000, 'RENDER_LOD_CLASSES'),
    (0x33000000, 0x33ffffff, 'IMAGE_COMPOSITOR'),
    (0x34000000, 0x34000000, 'MASTER_PROPERTY'),
    (0x35000000, 0x35000000, 'GAME_TIME'),
    (0x38000000, 0x38ffffff, 'OBSTACLEDESC'),  # beta, deprecated
    (0x39000000, 0x39ffffff, 'PSDESC'),  # particle system
    (0x40000000, 0x40ffffff, 'RENDERTEXTURE'),
    (0x41000000, 0x41ffffff, 'RENDERSURFACE'),
    (0x42000000, 0x42000fff, 'FONT'),
    (0x43001000, 0x43001000, 'SCRIPTCHANNELS'),
    (0x44000000, 0x44ffffff, 'FORKPSDESC'),  # not present in beta
    (0x46000000, 0x46ffffff, 'ENTITYGROUP'),
    (0x47000000, 0x47ffffff, 'ENTITYDESC'),
    (0x51000000, 0x51ffffff, 'ACTIONMAP'),
    (0x53000000, 0x53ffffff, 'CONTENTDB'),
    (0x56000000, 0x56ffffff, 'WLIB'),
    (0x58000000, 0x58000001, 'STRING_STATE'),
    (0x60000000, 0x60ffffff, 'CONVERSATIONTREE'),  # beta, deprecated
    (0x62000000, 0x62ffffff, 'DBCATEGORIES'),  # beta, deprecated
    (0x66000000, 0x66ffffff, 'PHYSICS_MESH'),
    (0x70000000, 0x77ffffff, 'WSTATE'),
    (0x78000000, 0x7fffffff, 'DBPROPERTIES'),
    (0x80000000, 0x800fffff, 'LANDBLOCKDATA'),
    (0x80100000, 0x801fffff, 'LANDBLOCKBLOCKMAP'),
    (0x80200000, 0x802fffff, 'LANDBLOCKINFO'),
    (0x80300000, 0x803fffff, 'PATHMAP'),  # beta, deprecated
    (0x80400000, 0x804fffff, 'LANDBLOCKPROPERTIES'),
    (0x80500000, 0x805fffff, 'DISTANT_LANDSCAPE_SECTOR'),
    (0x80600000, 0x806fffff, 'KYNLANDBLOCK'),
    (0x90000000, 0x9fffffff, 'KYNPATHDATA')
)


def range_of_name(sought_name):
    """Return the DataID range for a DBOType name."""
    for min_id, max_id, name in _type_ranges:
        if sought_name == name:
            return min_id, max_id
    raise ValueError


def name_of_did(did):
    """Render the DBOType name for a DataID."""
    for min_id, max_id, name in _type_ranges:
        if min_id <= did.raw <= max_id:
            return name
    return None


class DataID:
    def __init__(self, raw):
        self.raw = raw
        
    def __eq__(self, other):
        return self.raw == other.raw

    @property
    def major(self):
        return self.raw >> 24

    @property
    def type(self):
        """Return a DBOType string for the DataID."""
        for min_id, max_id, name in _type_ranges:
            if min_id <= self.raw <= max_id:
                return name

    @property
    def minor(self):
        return self.raw & 0xffffff

    @property
    def second(self):
        return (self.raw >> 16) & 0xff

    @property
    def third(self):
        return (self.raw >> 8) & 0xff

    @property
    def fourth(self):
        return self.raw & 0xff
        
    def valid(self):
        return self.raw != 0xffffffff
        
    def is_zero(self):
        return self.raw == 0

    @property
    def region(self):
        return self.second & 15

    def __repr__(self):
        return 'DID:{:08X}'.format(self.raw)

    def __hash__(self):
        return self.raw


def make_landblock_did(data_type, region, bx, by):
    did_base = range_of_name(data_type)[0]
    return DataID(did_base | (region << 16) | (bx << 8) | by)
