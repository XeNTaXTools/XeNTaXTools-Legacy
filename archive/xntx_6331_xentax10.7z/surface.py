import io

from PyQt5.QtGui import QImage, QPixmap

from PIL import Image, ImageQt

from dbo.rendersurface import ImageFormat, SurfaceHeader


class error(Exception):
    def __init__(self, msg):
        self.msg = msg


def convert_rgb(ins, w, h, data_size):
    data = ins.read(data_size);
    temp = QImage(data, w, h, w * 3, QImage.Format_RGB888)
    return QImage(temp.rgbSwapped())


def convert_rgba(ins, w, h, data_size):
    data = ins.read(data_size)
    temp = QImage(data, w, h, w * 4, QImage.Format_ARGB32)
    return temp


def convert_greyscale(ins, w, h, data_size):
    if data_size != w * h:
        return None
    data = ins.read(data_size)
    temp = QImage(data, w, h, w, QImage.Format_Grayscale8)
    return temp


def convert_jpeg(ins, w, h, data_size):
    data = ins.read(data_size)
    image = QImage()
    success = image.loadFromData(data, 'JPG')
    if success:
        return image
    else:
        raise error('failed to load jpeg')


def make_dds_header(data):
    """
    Construct DDS header for writing a DDS resource to disk.
    data is a raw lotro resource, already confirmed to be DDS.
    Return an empty header if the data fails header check.

    """

    header = bytearray(128)
    header[0] = 68
    header[1] = 68
    header[2] = 83
    header[3] = 32
    header[4] = 124
    header[8] = 7
    header[9] = 16
    header[12:16] = data[12:16]
    header[16:20] = data[8:12]
    header[76] = 32
    header[80] = 4
    header[84] = 68
    header[85] = 88
    header[86] = 84
    if data[19] == 49:  # DXT1
        header[87] = 49
    elif data[19] == 51:  # DXT3
        header[22] = 1
        header[76] = 32
        header[87] = 51
        header[108] = 8
        header[109] = 16
        header[110] = 64
    elif data[19] == 53:  # DXT5
        header[10] = 8
        header[22] = 1
        header[28] = 1
        header[76] = 32
        header[87] = 53
        header[88] = 32
        header[94] = 255
        header[97] = 255
        header[100] = 255
        header[107] = 255
        header[109] = 16
    else:
        raise error('failed to construct DDS header')
        
    return header


def convert_dds(ins, w, h, data_size):
    ins.seek(0)
    raw_hdr = ins.read(24)
    data = make_dds_header(raw_hdr)
    data.extend(ins.read())
    dds_ins = io.BytesIO(data)
    pilobj = Image.open(dds_ins)
    return ImageQt.ImageQt(pilobj)


FUNC_MAP = {
    ImageFormat.D3DFMT_R8G8B8.value: convert_rgb,
    ImageFormat.D3DFMT_A8R8G8B8.value: convert_rgba,
    ImageFormat.D3DFMT_A8.value: convert_greyscale,
    ImageFormat.FORMAT_JPEG.value: convert_jpeg,
    ImageFormat.D3DFMT_DXT1.value: convert_dds,
    ImageFormat.D3DFMT_DXT3.value: convert_dds,
    ImageFormat.D3DFMT_DXT5.value: convert_dds
}


def convert_image(data):
    """
    Construct a QPixmap from various image formats.  This is done using
    an intermediate QImage which is constructed by the various decoding
    functions and destroyed here.  It's more convenient for the decoders
    to construct the QImage as some handy image conversion options are
    only available through QImage's constructor.

    """
    ins = io.BytesIO(data)
    hdr = SurfaceHeader(ins)
    try:
        image = FUNC_MAP[hdr.format](ins, hdr.w, hdr.h, hdr.length)
    except KeyError:
        raise error('unknown image type: {}'.format(hdr.format))
    return QPixmap.fromImage(image)
