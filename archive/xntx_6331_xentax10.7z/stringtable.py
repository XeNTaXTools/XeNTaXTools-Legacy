"""

Note that StringTable[token] returns a list of strings, not just one.

"""

import io
import struct

import common
from dataid import DataID


class StringSubList:
    def __init__(self, ins):
        # u3 always zero?
        self.token, self.u3, num_parts = struct.unpack('<3L', ins.read(12))
        self.string_data = []
        for j in range(num_parts):
            length = common.read_vle(ins)
            strdata = ins.read(length * 2)
            self.string_data.append(strdata.decode('utf-16'))
        # seems these can be 1 or 1Bnnnnnn, full sample needed TODO
        self.string_ids = struct.unpack('<{}L'.format(num_parts),
                                        ins.read(num_parts * 4))
        if common.read_bool(ins):
            name_count = common.read_uint32(ins)
            for i in range(name_count):
                s = common.read_prefixed_utf16(ins)  # "NAME"
        

class StringTable:
    def __init__(self, data, expected_did=None):
        ins = io.BytesIO(data)
        self.did = DataID(struct.unpack('<L', ins.read(4))[0])
        if expected_did is not None:
            assert self.did == expected_did
        self.u1 = common.read_uint32(ins)  # always 1?
        num_entries = common.read_tsize(ins)
        self.entries = [StringSubList(ins) for i in range(num_entries)]

    def __getitem__(self, token):
        for entry in self.entries:
            if entry.token == token:
                return entry.string_data
        return None
