"""

RenderMaterial (2b)

Smallest: 2b0007f8, complete dump:

F8 07 00 2B     did
00 00 00 00     always 0
00 00 00 00     material property count
01 00 00 00
00 00 00 00
00 20 00 00
00 00 00 00
00 00 00 00
01 00 00 00
04 00 00 00
[DXBC chunk]    interestingly a count of 2 doesn't occur before here
[DXBC chunk]
00 00 00 00
00 00 00 00
02 01 01 08 00 01 00
01 00 00 00
66 66 66 3F
FF FF FF FF
FF FF FF FF
01 00 00 00
00 00 00 00
FF FF FF FF

2b0000ab is fairly small too, complete dump:

    reminder: type 4 -> int32, type 10 -> 4 floats, type 40 -> more complex

AB 00 00 2B     did
00 00 00 00     always 0
04 00 00 00     material property count
[MaterialProperties]
03 00 00 00
20 00 00 00
00 00 00 00
00 20 00 00 00
        00 00 00 00 00 00 00 01 00 00 00 00 00 00 00 00 00 00 00 00
        01 01 02 02 02 00 00 00 00 04 03 00 00 00
        00 00 00 00 04 03 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00
        05 06 01 04 01 02 00 01 00 00 00
        66 66 66 3F - FF FF FF FF - FF FF FF FF
        01 00 00 00 - 00 00 00 00 - FF FF FF FF
        00 00 00 00 00 00
        02 00 00 00 - 00 00 00 00 - 00 00 (?)
        01 00 00 00 03 00 00 00
0A 02 00 00     this is the length from next byte to end of first [Source]
    02 00 00 00 02 00 00 00 01 0E 01 00 00 00
    VSConstants
    40 00 00 00 04 00 00 00 01 00 00 00
    c_ModelToClipMatrix
    00 00 00 00 40 00 00 00 01 00 00 00 00
    [Source]
17 01 00 00     this is the length from next byte to end of second [Source]
    02 00 00 00 00 00 00 00 01 00 00 00
    PSConstants
    10 00 00 00 01 00 00 00 01 00 00 00
    c_MaterialDiffuseColor
    00 00 00 00 10 00 00 00 01 00 00 00 00
    [Source]
00 00 00 00 00 00 00 00 05 06 01 04 01 02 00 01 00 00 00 66 66 66 3F FF FF FF FF FF FF FF FF 01 00 00 00 00 00 00 00
FF FF FF FF 00 00 00 00 00 20 00 00 00 00 00 00 00 00 00 00 01 00 00 00 04 00 00 00
[DXBC]
[DXBC]
00 00 00 00
00 00 00 00
05 06 01 04 01 02 00
01 00 00 00
66 66 66 3F
FF FF FF FF
FF FF FF FF
01 00 00 00
00 00 00 00
FF FF FF FF


"""

from collections import namedtuple
import io
import struct

from common import read_uint32, hexdump
from dataid import DataID
from dbo.materialmodifier import MaterialProperty


CTHeader = namedtuple('CTHeader', 'size creator version constants constant_info flags target')
CTInfo = namedtuple('CTInfo', 'name register_set register_index register_count reserved type_info default_value')
CTDesc = namedtuple('CTDesc', 'name register_set register_index rows columns elements structmembers bytes')
CTType = namedtuple('CTType', 'cclass ctype rows columns elements structmembers structmemberinfo')


def read_null_term(ins):
    s = bytearray()
    while 1:
        c = ord(ins.read(1))
        if c == 0:
            break
        s.append(c)
    return s.decode('latin-1')


def parse_ctab(data):
    # For format see https://www.gamedev.net/forums/topic/648016-replacement-for-id3dxconstanttable/
    # look up D3DXCONSTANT_DESC struct
    ins = io.BytesIO(data)
    # table_size * 4 = length of most of the data - not needed in parsing
    a, b, c, table_size, e = struct.unpack('<4h4s', ins.read(12))
    assert a in (512, 768, 257)  # 0 2, 0 3, 1 1
    assert b in (-1, -2)
    assert c == -2
    assert e == b'CTAB'

    # CTHeader
    start_pos = ins.tell()
    header = CTHeader._make(struct.unpack('<7L', ins.read(28)))
    assert header.size == 28
    # m_creator = (header pos + header.Creator), yep Microsoft etc., need null-terminated string getter

    # CTInfo loaded from (header pos + header.constant_info)
    # Hang on, looks like it's an array
    # Get some namedtuples in here
    ins.seek(start_pos + header.constant_info)
    info_table = [CTInfo._make(struct.unpack('<L4H2L', ins.read(20))) for _ in range(header.constants)]

    entries = []
    for info in info_table:
        ins.seek(start_pos + info.type_info)
        typeinfo = CTType._make(struct.unpack('<6HL', ins.read(16)))
        ins.seek(start_pos + info.name)
        name = read_null_term(ins)
        desc = CTDesc._make([
            name,
            info.register_set,
            info.register_index,
            typeinfo.rows,
            typeinfo.columns,
            typeinfo.elements,
            typeinfo.structmembers,
            4 * typeinfo.elements * typeinfo.rows * typeinfo.columns
        ])
        entries.append(desc)

    return entries


def find_all(a_str, sub):
    start = 0
    while True:
        start = a_str.find(sub, start)
        if start == -1:
            return
        yield start
        start += len(sub)


class RenderMaterial:
    def __init__(self, data):
        self.data = bytes(data)
        ins = io.BytesIO(data)
        self.did = DataID(read_uint32(ins))
        assert read_uint32(ins) == 0
        count = read_uint32(ins)
        self.mat_props = [MaterialProperty(ins) for _ in range(count)]

        self.mat_props_end = ins.tell()
        self.remainder = ins.read()

        # CTAB Constants Table
        # In five files the last ctab offset is greater than the first dxbc offset:
        #     2b0000ab, ~dc, ~442, ~4b5, ~63e
        self.ctab_offsets = []
        for offset in find_all(self.data, b'CTAB'):
            # Save offset of int32 size field that precedes the CTAB chunk:
            self.ctab_offsets.append(offset - 12)
        self.ctabs = []
        for offset in self.ctab_offsets:
            ins.seek(offset)
            size, = struct.unpack('<L', ins.read(4))
            ctab = ins.read(size)
            parse_ctab(ctab)
            self.ctabs.append(ctab)

        # DXBC chunks
        # Every compiled HLSL shader starts with DXBC. The length field beforehand
        # is therefore Turbine's.
        self.dxbc_offsets = []
        for offs in find_all(self.data, b'DXBC'):
            self.dxbc_offsets.append(offs - 4)
        self.dxbcs = []
        for offset in self.dxbc_offsets:
            ins.seek(offset)
            size, = struct.unpack('<L', ins.read(4))
            self.dxbcs.append(ins.read(size))

        # Number of source offsets is often but not always equal to number of constant tables.
        # Many times the first source occurs before the last DXBC.
        # Only in 2b0000dc does the last CTAB occur after the first source.
        self.source_offsets = []
        for offs in find_all(self.data, b'#version'):
            self.source_offsets.append(offs - 4)
        self.sources = []
        for offset in self.source_offsets:
            ins.seek(offset)
            size, = struct.unpack('<L', ins.read(4))
            self.sources.append(ins.read(size).decode('latin-1'))

        # Section between mats and first ctab/dxbc/source varies in size from 28 to 666
        first_offsets = []
        if self.ctab_offsets:
            first_offsets.append(self.ctab_offsets[0])
        if self.dxbc_offsets:
            first_offsets.append(self.dxbc_offsets[0])
        if self.source_offsets:
            first_offsets.append(self.source_offsets[0])
        first_offset = min(first_offsets)
        second_section_size = first_offset - self.mat_props_end
        ins.seek(self.mat_props_end)
        second_section = ins.read(second_section_size)
        self.read_second_section(second_section)

        ctab_size = sum(len(ctab) for ctab in self.ctabs)
        dxbc_size = sum(len(dxbc) for dxbc in self.dxbcs)
        source_size = sum(len(source) for source in self.sources)
        # The sum of these three sections is around 90% of self.remainder size

        # ...

        ins.seek(-43, io.SEEK_END)
        self.read_last_section(ins)

    def read_second_section(self, data):
        ins = io.BytesIO(data)
        if len(data) > 1:
            pass
            #if self.ctabs: print('ctab count', len(self.ctabs))
            #if self.dxbcs: print('dxbc count', len(self.dxbcs))
            #if self.sources: print('source count', len(self.sources))
            #hexdump(data)

    def read_last_section(self, ins):
        a, b = struct.unpack('<2L', ins.read(8))
        assert a in (0, 1)
        assert b == 0
        unk = ins.read(7)
        t, u, v, w, x, y, z = struct.unpack('<7l', ins.read(28))
        assert t == 1
        # Floats: 0.1, 0.6, 0.8, 0.9
        assert u in (0, 1058642330, 1036831949, 0x3f4ccccd, 0x3f666666)
        assert v in (-1, 436207615, -16777216)
        assert w == -1
        assert x == 1
        assert y == 0
        assert z == -1


if __name__ == '__main__':
    import blob
    import sys
    b = blob.Blob('blobs/all_render_materials.blob')
    # smallest 2b0007f8 1151, biggest 2b000817 939769

    #r = RenderMaterial(b.fetch(0x2b000817))
    #print('Remainder size:', len(r.remainder))
    #sys.exit(0)

    total = 0
    failures = 0
    for did, raw_data in b.files():
        total += 1
        try:
            r = RenderMaterial(raw_data)
        except ValueError:
            failures += 1
    print('Total: {}, failures: {}'.format(total, failures))

