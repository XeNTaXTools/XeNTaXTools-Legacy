import io

from common import read_uint32, read_uint16
from dataid import DataID


class MaterialInstance:
    """
    A material referenced by a RenderMesh.
    These material instances link to RenderMaterials containing HLSL shaders,
    and to MaterialModifiers specifying colors, maps, transforms and so on.

    TODO
    Possibly referenced by other resources too.

    """
    def __init__(self, data):
        ins = io.BytesIO(data)
        self.did = DataID(read_uint32(ins))
        self.render_material_did = DataID(read_uint32(ins))
        # See EnumMapper:MaterialTypeID (23000088) for names of these:
        self.material_type_id = read_uint32(ins)
        count = read_uint32(ins)
        self.material_modifier_ids = [DataID(read_uint32(ins))
                                      for _ in range(count)]
        # 0 or 1 in all files except 3100000d where it's 0 1, perhaps an older material
        # file format and not consistent with today's.
        self.final = read_uint16(ins)
        if self.final not in (0, 1):
            print('final not 0 or 1 in res31', self.did, self.final)
        if ins.tell() != len(data):
            print('res31 missed eof')
