#by Durik256 for xentax
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("characterbarbie",".hnk;.dat")
    noesis.setHandlerTypeCheck(handle, CheckType)
    noesis.setHandlerLoadModel(handle, LoadModel)    
    return 1
    
def CheckType(data):
    bs = NoeBitStream(data)
    if bs.readInt() != 592:
        return 0
    if data.find('RenderModelTemplate'.encode()) != -1:
        print(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>..")
    return 1

def LoadModel(data, mdlList):
    ctx = rapi.rpgCreateContext()
    rapi.rpgSetEndian(1)
    bs = NoeBitStream(data)

    #114-end_Block;2-unk;28-unk;29-vbuf;30-ibuf;112-header;113-name;4101-anim;4123-mdl_info;4432-mat?;8529-tx
    fsize = bs.getSize()
    while bs.getOffset() < fsize:
        size, type, unk = bs.readInt(), bs.readShort(), bs.readShort()
        offset = bs.getOffset()
        if type == 8241: 
            ibuf, vcount = read_ibuf(bs, size)
            bs.seek(offset+size)
            #print("icount:", len(ibuf)//2)
        elif type == 8242: 
            type = '>>>>>>>>>>>>>>>>>>>>>...>>>>>vbuf'
            #vcount = size//22
            print("vcount:",vcount)
            vbuf = bs.readBytes(vcount*16)
            bs.seek(vcount*2)
            
            rapi.rpgSetName("Mesh_"+str(offset))
            rapi.rpgBindPositionBuffer(vbuf, noesis.RPGEODATA_FLOAT, 16)
            for _ibuf in ibuf:
                rapi.rpgCommitTriangles(_ibuf, noesis.RPGEODATA_SHORT, len(_ibuf)//2, noesis.RPGEO_TRIANGLE_STRIP)
                #rapi.rpgCommitTriangles(None, noesis.RPGEODATA_SHORT, len(vbuf)//16, noesis.RPGEO_POINTS)
            bs.seek(offset+size)
        elif type == 4144: 
            bs.seek(176,1)
            print('info_type?:', [bs.readUByte() for x in range(80)])
            bs.seek(offset+size)
        else:
            bs.seek(size,1)
        print(size, type, 'offset:', offset)
    

    try:
        mdl = rapi.rpgConstructModel()
    except:
        mdl = NoeModel()
    mdlList.append(mdl)
    #mdlList.append(NoeModel())
    return 1
        
def read_ibuf(bs, size):
    bs.setEndian(1)
    curPos = bs.getOffset()

    i_count = bs.readBytes(size)
    result = [i for i in findall(b'\x98\x00', i_count)]
    i_count = len(result)
    print("i_count:",i_count,"offset_i:",result)
    bs.seek(curPos)

    if i_count>1:
        bs.seek(2,1)
        c = bs.readUByte()
        i_size = ((curPos+result[1]-3)-curPos)//c
        i_type = 2 if i_size > 4 else 1
        if i_size == 5:
            bs.seek(5,1)
            if bs.readUByte() == bs.readUByte():
                i_type = 1
        pad = i_size - i_type 
        print("@@@@@@@@@@@@@@@@@@@@@@@@@","i_size:",i_size,"i_type:",i_type,"pad:",pad)
    else:
        i_type = 2
        bs.readUShort()#152
        bs.seek(bs.readUByte()*4,1)
        b = bs.readUShort()
        if b == 152 or b == 0:
            i_type = 1
        pad = 3 if i_type == 1 else 6
        print("@@@@@@@@@@@@@@@@@@@@@@@@@","i_type:",i_type)
    bs.seek(curPos)
    #---END_CHECK_TYPE---
    
    bs.setEndian(1)
    ibuf = []
    byte = bs.readUShort()
    max = 0
    while byte != 0:
        count = bs.readUByte()
        print(">>>byte:",byte,">>>count:",count)
        ibuf_local = b''
        for x in range(count):
            indx = bs.readUByte() if i_type == 1 else bs.readUShort()#bs.readUByte() readUShort
            if indx > max: max = indx
            #print(">>>indx:",indx)
            #bs.seek(3,1)
            ibuf_local +=(indx).to_bytes(2, 'big')
            bs.seek(pad,1)#3-6
        if len(ibuf_local)>0:
            ibuf.append(ibuf_local)
        byte = bs.readUShort()
    print(">>>max:",max+1)
    bs.setEndian(0)
    #print(ibuf)
    return ibuf, max+1
    
def findall(p, s):
    i = s.find(p)
    while i != -1:
        yield i
        i = s.find(p, i+1)
        