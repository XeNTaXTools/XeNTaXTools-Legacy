from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Bullet Girls Phantasia [PS Vita]", ".aif")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    if bs.readBytes(4) != b'\x20\x46\x49\x41': return 0
    bs.seek(0x2c)
    if bs.readBytes(4) != b'\x41\x54\x49\x56': return 0
    return 1
    
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.seek(0x4)
    aifChunkSize = bs.readUInt()
    bs.seek(0x8, 1)
    baseOffset = bs.tell()
    arfChunk = bs.readBytes(4)
    arfChunkSize = bs.readUInt()
    bs.seek(baseOffset + arfChunkSize)
    imgX = bs.readBytes(4)
    imgXSize = bs.readUInt()
    bs.seek(0x18, 1)
    imgFmt = bs.readUShort()
    print(hex(imgFmt), ":format")
    bs.seek(0x6, 1)
    imgWidth = bs.readUShort()            
    print(imgWidth, ": imgWidth")
    imgHeight = bs.readUShort()           
    print(imgHeight, ": imgHeight")
    bs.seek(0x10, 1)
    datasize = bs.readUInt()
    bs.seek(aifChunkSize)
    amf = bs.readBytes(4)
    amfSize = bs.readUInt()
    bs.seek(0x8, 1)
    baseOffset2 = bs.tell()
    head = bs.readBytes(4)
    headSize = bs.readUInt()
    bs.seek(0x30, 1)
    relDataOffset = bs.readUInt()
    bs.seek(baseOffset2 + relDataOffset)
    print(hex(bs.tell()), ":here")
    data = bs.readBytes(datasize)    
    if imgFmt == 0x10:
        data = rapi.imageFromMortonOrder(data, imgWidth >> 1, imgHeight >> 2, 4)
        data = rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_DXT1)
        texFmt = noesis.NOESISTEX_RGBA32
    elif imgFmt == 0x12:    
        data = rapi.imageFromMortonOrder(data, imgWidth >> 1, imgHeight >> 2, 8)
        data = rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_DXT3)
        texFmt = noesis.NOESISTEX_RGBA32
    elif imgFmt == 0x14:    
        data = rapi.imageFromMortonOrder(data, imgWidth >> 1, imgHeight >> 2, 8)
        data = rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_DXT5)
        texFmt = noesis.NOESISTEX_RGBA32
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1