import newGameLib
from newGameLib import *
import Blender	



def gr2Parser(filename,g):
	model=Model(filename)
	model.boneNameList=[]	
	skeleton=Skeleton()
	g.word(4)
	g.i(5)
	C=g.H(4)
	g.i(4)	
	g.f(8)
	D=g.i(10)
	B=g.H(4)
	A=g.i(8)
	if D[2]!=0:
		g.seek(D[2])	
		g.i(4)
	
	if D[4]!=0:
		g.seek(D[4])
		for m in range(C[3]):
			off1,off2=g.i(2)	
			t=g.tell()
			g.seek(off1)
			g.find('\x00')
			g.seek(off2)
			g.find('\x00')
			g.seek(t)
			g.f(16)
		
	if A[5]!=0:	
		skeleton=Skeleton()
		skeleton.ARMATURESPACE=True
		skeleton.NICE=True		
		g.seek(A[5])
		for m in safe(B[1]):
			bone=Bone()
			off=g.i(1)[0]
			posMatrix=VectorMatrix(g.f(3))
			x,y,z=g.f(3)			
			euler = Blender.Mathutils.Euler()
			RotateEuler(euler,z,'z')
			RotateEuler(euler,x,'x')
			RotateEuler(euler,y,'y')
			rotMatrix=euler.toMatrix().resize4x4()
			matrix=rotMatrix*posMatrix
			bone.matrix=matrix.invert()
			t=g.tell()
			g.seek(off)
			name=g.find('\x00')
			bone.name=name
			model.boneNameList.append(name)
			g.seek(t)
	
	if A[2]!=0:
		g.seek(A[2])
		mesh=Mesh()
		mesh.SPLIT=True
		model.meshList.append(mesh)
		for m in safe(A[0]):
			t=g.tell()
			mesh.vertPosList.append(g.f(3))
			mesh.skinWeightList.append(g.B(4))
			mesh.skinIndiceList.append(g.B(4))
			g.seek(t+B[3]-4)
			mesh.vertUVList.append(g.half(2))
			g.seek(t+B[3])
		for m in safe(A[1]/3):	
			mesh.faceList.append(g.H(3))
		mesh.TRIANGLE=True	
		skin=Skin()
		mesh.skinList.append(skin)
		mesh.boneNameList=model.boneNameList
		mesh.BINDSKELETON='armature'
		
	if A[3]!=0:		
		g.seek(A[3])
		for m in safe(B[0]):
			mat=Mat()
			mat.TRIANGLE=True
			mesh.matList.append(mat)
			a,b,c,d=g.i(4)
			g.f(8)
			for n in safe(b):
				mesh.matIDList.append(m)
		
	if D[3]!=0:
		g.seek(D[3])
		skeleton.BONESPACE=True
		for m in safe(C[2]):		
			bone=Bone()
			skeleton.boneList.append(bone)
			off,parentID=g.i(2)
			matrix1=Matrix4x4(g.f(16))
			matrix2=Matrix4x4(g.f(16))
			if m==0:
				matrix=matrix1*Matrix([1,0,0,0],[0,1,0,0],[0,0,-1,0],[0,0,0,1])
			else:	
				matrix=matrix1#*matrix2.invert()
			bone.matrix=matrix#.invert()			
			t=g.tell()
			g.seek(off)
			name=g.find('\x00')[-25:]
			bone.name=name
			bone.parentID=parentID		
			g.seek(t)
			
		
	skeleton.draw()
	model.getMat()
	model.draw()
	model.setMat()
	


def Parser(filename):	
	print '='*70
	print filename
	print '='*70
	ext=filename.split('.')[-1].lower()	
	
	if ext=='gr2':
		file=open(filename,'rb')
		g=BinaryReader(file)
		gr2Parser(filename,g)
		file.close()
 
	
Blender.Window.FileSelector(Parser,'import','select files: *.gr2') 
	