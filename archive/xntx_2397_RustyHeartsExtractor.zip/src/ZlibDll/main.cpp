#include <windows.h>
#include "zlib/zlib.h"
#include <stdio.h>

extern "C" __declspec(dllexport) int Decompress(unsigned char * compressed, unsigned int compressed_size, unsigned char * decompressed, unsigned int * decompressed_size )
{
	unsigned int est_size = *decompressed_size * 5;
	if( est_size < 4096 ) est_size = 4096;
	unsigned char * workspace = (unsigned char *)malloc( est_size );
	int result = Z_OK;
	do 
	{
		result = uncompress((Bytef*)workspace, (uLongf *)&est_size, (Bytef*)compressed, compressed_size);
		if( result == Z_OK )
		{
			if( *decompressed_size >= est_size )
			{
				*decompressed_size = est_size;
				memcpy( decompressed, workspace, est_size );
			}
			else
			{
				result = -10; // decompression size mismatch
			}
		}
		else if( result == Z_BUF_ERROR )
		{
			est_size *= 2;
			workspace = (unsigned char *)realloc(workspace, est_size);
		}
	} while( result == Z_BUF_ERROR );
	free( workspace );
	return result;
}

extern "C" __declspec(dllexport) int Compress(unsigned char * decompressed, unsigned int decompressed_size, unsigned char * compressed, unsigned int * compressed_size )
{
	unsigned int est_size = decompressed_size * 5;
	if( est_size < 4096 ) est_size = 4096;
	unsigned char * workspace = (unsigned char *)malloc( est_size );
	int result = Z_OK;
	do 
	{
		result = compress((Bytef*)workspace, (uLongf *)&est_size, (Bytef*)decompressed, decompressed_size);
		if( result == Z_OK )
		{
			*compressed_size = est_size;
			memcpy( compressed, workspace, est_size );
		}
		else if( result == Z_BUF_ERROR )
		{
			est_size *= 2;
			workspace = (unsigned char *)realloc(workspace, est_size);
		}
	} while( result == Z_BUF_ERROR );
	free( workspace );
	return result;
}
