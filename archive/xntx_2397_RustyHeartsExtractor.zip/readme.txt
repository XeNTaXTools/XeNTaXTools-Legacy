RustyHeartsExtractor
pushedx

Made for RageZone

1. Copy "bin/RustyHeartsExtractor.exe" and "bin/ZlibDll.dll" to your "RustyHearts" folder.

2. Make sure you have at least 5GB free and RH is closed and no files are locked.

3. Run "RustyHeartsExtractor.exe". Any errors will be displayed in the console

4. The process will take a long time! So please be patient. It's ~50k files and the program is single threaded.