# Star War (NGC) gcm to OBJ convertion test by Bigchillghost

import rapi
from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Star War (NGC)", ".gcm;")
	noesis.setHandlerTypeCheck(handle, checkType)
	noesis.setHandlerLoadModel(handle, convModel)
	
	#noesis.logPopup()
	return 1

#check if it's this type based on the data
def checkType(data):
	if len(data) < 0x80:
		return 0
	bs = NoeBitStream(data)
	Magic = bs.readUInt()
	if Magic != 0x52444548:
		return 0
	return 1

#convert the model to obj
def convModel(data, mdlList):
	#noesis.logPopup()
	bs = NoeBitStream(data)
	
	outName = rapi.getInputName().replace(".gcm",".obj")
	ObjFile = open(outName, "wb")
	ObjFile.write(b'# Wavefront OBJ\n\n')
	mdlAddressList = [0xB04,0x7548]
	accPosIdxBase = 1
	accNmIdxBase = 1
	accUvIdxBase = 1
	objectCnt = len(mdlAddressList)
	for i in range(0, objectCnt):
		bs.seek(mdlAddressList[i], NOESEEK_ABS)
		bs.seek(0x24, NOESEEK_REL)
		Len = bs.readUInt()
		meshName = noeStrFromBytes(bs.readBytes(Len))
		bs.seek(4, NOESEEK_REL)
		Len = bs.readUInt()
		bs.seek(Len+0x88, NOESEEK_REL)
		
		posCnt = bs.readUInt()
		posStream = NoeBitStream()
		for j in range(0, posCnt):
			x,y,z = bs.readFloat(),bs.readFloat(),bs.readFloat()
			posStream.writeString('v %f %f %f\n'%(x,y,z), 0)
		posStream.writeString('# %d vertices\n\n'%posCnt, 0)
		
		bs.seek(4, NOESEEK_REL)
		Len = bs.readUInt()
		bs.seek(Len+8, NOESEEK_REL)
		
		nmCnt = bs.readUInt()
		nmStream = NoeBitStream()
		for j in range(0, nmCnt):
			x,y,z  = bs.readFloat(),bs.readFloat(),bs.readFloat()
			nmStream.writeString('vn %f %f %f\n'%(x,y,z), 0)
		nmStream.writeString('# %d normals\n\n'%nmCnt, 0)
		
		bs.seek(8, NOESEEK_REL)
		uvCnt = bs.readUInt()
		uvStream = NoeBitStream()
		for j in range(0, uvCnt):
			u,v = bs.readFloat(),bs.readFloat()
			uvStream.writeString('vt %f %f\n'%(u,v), 0)
		uvStream.writeString('# %d texture coordinates\n\n'%uvCnt, 0)
		
		bs.seek(8, NOESEEK_REL)
		totalIndexCount = bs.readUInt()
		indexCount = totalIndexCount // 3
		posIdxList = [0]*indexCount
		nmIdxList = [0]*indexCount
		uvIdxList = [0]*indexCount
		for j in range(0, indexCount):
			posIdxList[j] = bs.readUShort()
		for j in range(0, indexCount):
			nmIdxList[j] = bs.readUShort()
		for j in range(0, indexCount):
			uvIdxList[j] = bs.readUShort()
		
		posDecList,nmDecList,uvDecList = stripDecoder(posIdxList, nmIdxList, uvIdxList, indexCount, accPosIdxBase, accNmIdxBase, accUvIdxBase)
		polyCnt = len(posDecList) // 3
		polyStream = NoeBitStream()
		polyStream.writeString('g %s\n'%meshName, 0)
		for j in range(0, polyCnt):
			polyStream.writeString('f', 0)
			for k in range(0, 3):
				vertIdx = j * 3 + k
				polyStream.writeString(' %d/%d/%d'%(posDecList[vertIdx], uvDecList[vertIdx], nmDecList[vertIdx]), 0)
			polyStream.writeString('\n', 0)
		polyStream.writeString('# %d triangles\n\n'%polyCnt, 0)
		
		ObjFile.write(posStream.getBuffer())
		ObjFile.write(nmStream.getBuffer())
		ObjFile.write(uvStream.getBuffer())
		ObjFile.write(polyStream.getBuffer())
		
		accPosIdxBase += posCnt
		accNmIdxBase += nmCnt
		accUvIdxBase += uvCnt
		
	ObjFile.close()
	
	return 0

def stripDecoder(posStripList, nmStripList, uvStripList, idxCnt, basePosIdx = 0, baseNmIdx = 0, baseUvIdx = 0):
	parity = 0
	posDecList = []
	nmDecList = []
	uvDecList = []
	idx = 0
	Cnt = idxCnt - 2
	while idx < Cnt:
		if posStripList[idx] & 0x8000 > 0:
			posStripList[idx] &= 0x7FFF
			posStripList[idx + 1] &= 0x7FFF
		if posStripList[idx] != posStripList[idx + 2] and posStripList[idx] != posStripList[idx + 1] and posStripList[idx + 1] != posStripList[idx + 2]:
			if parity % 2:
				posDecList.append(basePosIdx + posStripList[idx + 1])
				posDecList.append(basePosIdx + posStripList[idx])
				posDecList.append(basePosIdx + posStripList[idx + 2])
				nmDecList.append(baseNmIdx + nmStripList[idx + 1])
				nmDecList.append(baseNmIdx + nmStripList[idx])
				nmDecList.append(baseNmIdx + nmStripList[idx + 2])
				uvDecList.append(baseUvIdx + uvStripList[idx + 2])
				uvDecList.append(baseUvIdx + uvStripList[idx])
				uvDecList.append(baseUvIdx + uvStripList[idx + 1])
			else:
				posDecList.append(basePosIdx + posStripList[idx])
				posDecList.append(basePosIdx + posStripList[idx + 1])
				posDecList.append(basePosIdx + posStripList[idx + 2])
				nmDecList.append(baseNmIdx + nmStripList[idx])
				nmDecList.append(baseNmIdx + nmStripList[idx + 1])
				nmDecList.append(baseNmIdx + nmStripList[idx + 2])
				uvDecList.append(baseUvIdx + uvStripList[idx])
				uvDecList.append(baseUvIdx + uvStripList[idx + 1])
				uvDecList.append(baseUvIdx + uvStripList[idx + 2])
		if idx + 3 < idxCnt and posStripList[idx + 3] & 0x8000 > 0:
			idx += 3
			parity = 0
		else:
			idx += 1
			parity += 1
	return posDecList,nmDecList,uvDecList