Homefront: The Revolution game .pak extractor

Supported only v1.0.67.8905 (MD5:596649a339bdd9ff7195375e5f54819c homefront2_release.exe)

btih:ec883a23df711e2b101ef7a380d3e1d81f644260

Usage:
1. Copy dinput8.dll into Homefront_The_Revolution\Bin64\ drectory
2. Start game exe
3. See Bin64\extracted\*.
