import newGameLib
from newGameLib import *
import Blender	

emdAllFlag=1

def emmParser(filename,g):
	g.endian='>'
	g.word(4)
	A=g.i(3)
	g.seek(A[2])
	B=g.H(2)
	offsetList=g.i(B[0])
	for offset in offsetList:
		g.seek(A[2]+offset)
		g.word(32)
		g.word(32)
		C=g.H(2)
		for m in range(C[0]):
			g.word(32)
			g.H(2)
			g.f(1)
		g.tell()
	
	
	


def emdParser(filename,g):
	global matList
	matList={}

	emmPath=filename.lower().replace('.emd','.emm')
	print emmPath
	if os.path.exists(emmPath)==True:
		file=open(emmPath,'rb')
		p=BinaryReader(file)
		emmParser(emmPath,p)
		#except:pass
		file.close()

	embPath=filename.lower().replace('.emd','.emb')
	print embPath
	if os.path.exists(embPath)==True:
		file=open(embPath,'rb')
		p=BinaryReader(file)
		embParser(embPath,p)
		#except:pass
		file.close()

	#g.debug=True
	g.endian='>'
	g.tell()
	
	
	
	g.word(4)
	g.H(4)
	A=g.i(4)
	offsetList=g.i(A[1])
	for offset in offsetList:
		g.seek(offset)
		print '='*20,'model',g.tell()
		B=g.i(4)
		g.seek(offset+B[2])
		rot=Matrix3x3(g.f(9)).resize4x4()
		pos=VectorMatrix(g.f(3))
		matrix=rot*pos
		print matrix
		C=g.i(3)
		g.seek(offset+B[2]+C[0])
		print g.find('\x00')
		g.seek(offset+B[2]+C[2])
		offsetList2=g.i(C[1])
		for offset2 in offsetList2:
			mesh=Mesh()	
			g.seek(offset+B[2]+offset2)
			print 'mat',g.tell()
			rot=Matrix3x3(g.f(9)).resize4x4()
			pos=VectorMatrix(g.f(3))
			matrix=rot*pos
			print matrix
			#mesh.matrix=matrix
			D=g.i(5)+g.H(2)+g.i(2)
			print 'D:',D
			g.seek(offset+B[2]+offset2+D[4])
			name=g.find('\x00')
			print name
			mesh.name=name
			g.seek(offset+B[2]+offset2+D[7])
			print 'tex:'
			mat=Mat()
			mat.ZTRANS=True
			mat.TRIANGLE=True
			for m in range(D[5]):
				a,b=g.H(2)
				if m==0:
					mat.diffuse=g.dirname+os.sep+g.basename+'_files'+os.sep+str(a)+'.dds'
				print a,b,g.f(2)
			mesh.matList.append(mat)
			
			g.seek(offset+B[2]+offset2+D[8])
			indiceStreamCount=D[6]
			indiceStreamOffsetList=g.i(indiceStreamCount)
			for offset3 in indiceStreamOffsetList:
				g.seek(offset+B[2]+offset2+offset3)
				E=g.i(4)
				print 'E:',E
				g.seek(offset+B[2]+offset2+offset3+E[2])
				mesh.indiceList.extend(g.H(E[0]))
				
				g.seek(offset+B[2]+offset2+offset3+E[3])
				offsetList4=g.i(E[1])
				for offset4 in offsetList4:
					g.seek(offset+B[2]+offset2+offset3+offset4)
					mesh.boneNameList.append(g.find('\x00'))
				
			
			
			#print g.tell()
					
			g.seek(offset+B[2]+offset2+D[3])
			g.tell()
			g.debug=False
			for m in range(D[2]):
				t=g.tell()
				mesh.vertPosList.append(g.f(3))
				#g.short(12)
				g.seek(t+20)
				mesh.vertUVList.append(g.half(2))
				i1,i2,i3,i4=g.B(4)
				mesh.skinIndiceList.append([i4,i3,i2,i1])
				w1,w2,w3,w4=g.half(4)
				w4=1.0-(w1+w2+w3)
				mesh.skinWeightList.append([w1,w2,w3,w4])
				mesh.skinIDList.append([1])
				g.seek(t+D[1])
			skin=Skin()
			mesh.skinList.append(skin)	
			mesh.TRIANGLE=True	
			#mesh.boneNameList=skeleton.boneNameList
			mesh.BINDSKELETON=skeleton.name
			mesh.draw()	
			#g.debug=True	
			g.tell()	
	
	g.debug=True
	g.tell()	

	

def embParser(filename,g):




	g.debug=True
	g.endian='>'
	
	name=g.word(4)
	v0=g.h(4)
	v1=g.i(5)
	
	g.seek(v1[3])
	t0=g.tell()
	
	texDir=g.dirname+os.sep+g.basename.split('.')[0]+'_files'
	try:os.makedirs(texDir)
	except:pass
	
	for id0 in range(v1[0]):
		print '='*30,id0
		t1=g.tell()
		v2=g.i(2)
		t2=g.tell()
		g.seek(t1+v2[0])
		v3=g.B(8)
		v4=g.H(20)
		w,h=v4[12],v4[13]
		g.seek(t1+v2[0]+128)
		
		img=imageLib.Image()
		img.name=texDir+os.sep+str(id0)+'.dds'
		img.szer=w
		img.wys=h
		
		if v4[8]==34817:img.format='DXT5'
		
		elif v4[8]==34305:img.format='DXT1'
		else:print 'unknow format',v4[14]
		
		
		img.data=g.read(v2[1]-128)
		g.seek(t2)
		img.draw()
	

	g.tell()
	
def eskParser(filename,g):
	
	#g.debug=True
	g.endian='>'
	g.word(4)
	g.H(4)
	A=g.i(5)+g.H(2)+g.i(6)
	print A
	g.seek(A[1]+A[7])
	for m in range(A[5]):
		bone=Bone()
		B=g.h(4)
		bone.parentID=B[0]
		skeleton.boneList.append(bone)
		
	g.seek(A[1]+A[8])	
	for m in range(A[5]):
		bone=skeleton.boneList[m]
		offset=g.i(1)[0]
		t=g.tell()
		g.seek(A[1]+offset)
		bone.name=g.find('\x00')
		g.seek(t)
		
	g.seek(A[1]+A[10])	
	for m in range(A[5]):
		bone=skeleton.boneList[m]
		matrix=Matrix4x4(g.f(16))
		print matrix
		bone.matrix=matrix.invert()
		
	
	
	g.tell()	
	
def Parser():	
	global skeleton
	filename=input.filename
	print
	print filename
	print
	ext=filename.split('.')[-1].lower()		
	
	if ext=='emb':	
				
		
		
		file=open(filename,'rb')
		g=BinaryReader(file)
		embParser(filename,g)
		file.close()
	
	if ext=='esk':	
				
		
		skeleton=Skeleton()
		#skeleton.BONESPACE=True
		skeleton.ARMATURESPACE=True
		skeleton.NICE=True
		file=open(filename,'rb')
		g=BinaryReader(file)
		eskParser(filename,g)
		file.close()
		skeleton.BINDMESH=True
		skeleton.draw()
	
	if ext=='emd':
		if emdAllFlag==1:
			skeleton=Skeleton()
			#skeleton.BONESPACE=True
			skeleton.ARMATURESPACE=True
			skeleton.NICE=True
			emdID=os.path.basename(filename).split('_')[1]
			eskPath=filename.split(emdID)[0]+emdID+'.esk'
			if os.path.exists(eskPath)==True:
				file=open(eskPath,'rb')
				g=BinaryReader(file)
				eskParser(eskPath,g)
				file.close()
			skeleton.draw()
		
			emdDir=os.path.dirname(filename)
			if '_' in filename:
				if len(os.path.basename(filename).split('_'))>1:
					emdID=os.path.basename(filename).split('_')[1]
				else:
					emdID=None
				if emdID is not None:	
					for file in os.listdir(emdDir):				
						ext=file.split('.')[-1].lower()
						if ext=='emd' and 'lod' not in file.lower():	
							if '_' in file:
								if len(file.split('_'))>1:
									ID=file.split('_')[1]
									if emdID==ID:
										emdPath=emdDir+os.sep+file
							
										file=open(emdPath,'rb')
										g=BinaryReader(file)
										emdParser(emdPath,g)
										file.close()
		else:
				
			skeleton=Skeleton()
			#skeleton.BONESPACE=True
			skeleton.ARMATURESPACE=True
			skeleton.NICE=True	
			skeleton.draw()		
			file=open(filename,'rb')
			g=BinaryReader(file)
			emdParser(filename,g)
			file.close()
			
 
 
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
	
Blender.Window.FileSelector(openFile,'import','Dragon Ball Xenoverse files: *.emd - model,*.emb - textures, *.esk - skeleton') 
	