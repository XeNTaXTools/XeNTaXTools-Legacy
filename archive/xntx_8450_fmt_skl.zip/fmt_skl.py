#by Durik256
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Terminal Reality", ".SKL")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)
    
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    if data[:11].decode() != '// skeleton':
        return 0
    return 1
	
def noepyLoadModel(data, mdlList):
    data = data.decode().split('\n')

    bonecount, frameCount = [int(i) for i in data[3].split(',')]
    
    boneList = [] 
 
    for i in range(len(data)):
        if "// boneList" in data[i]:
            for j in range(1,bonecount+1):
                line = data[i+j].split(',')
                boneList.append(NoeBone(j-1,line[0].replace('"',''),NoeMat43(),None,int(line[1])))
            i += bonecount
        
        elif "// angle list:" in data[i]:
            #for j in range(1,frameCount+1):
            #    for x in range(bonecount):
            #        NoeQuat()
            i += (frameCount*bonecount)
        
        elif "// root offset list:" in data[i]:
            #for j in range(1,frameCount+1):
            #   NoeVec3()
            i += frameCount
        
        elif "// canceled movement list:" in data[i]:
            #for j in range(1,frameCount+1):
            #   NoeVec3()
            i += frameCount
            
       # elif "// ..." in data[i]:
        
        elif "// state list" in data[i]:#
            num_state = int(data[i+1])
            state_list = [data[i+x+1] for x in range(num_state)]
            i += num_state+1
            
        elif "// reference bone org list:" in data[i]:
            for j in range(1,bonecount+1):
                mat = NoeMat43()
                mat[3] = NoeVec3([float(x) for x in data[i+j].split(',')])
                boneList[j-1].setMatrix(mat)
            i += bonecount

    boneList = rapi.multiplyBones(boneList)
    mdl = NoeModel()
    mdl.setBones(boneList)
    mdlList.append(mdl)
    return 1