#by Durik256 for xentax
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Fatal Frame Unpack PS2", ".00")
    noesis.setHandlerExtractArc(handle, ExtractBIN)
    return 1
    
def ExtractBIN(fileName, fileLen, justChecking):
    if fileLen < 16:
        return 0
        
    if justChecking: #it's valid
            return 1

    data = rapi.loadIntoByteArray(fileName)[5814239:].split(b';')[0].split(b',')[:-1]
    dir = rapi.getDirForFilePath(fileName)#rapi.getInputName()

    names = []
    for x in data:
        name, id = x.split(b':')
        name = name.split(b'_')
        name = noeStrFromBytes((b'_'.join(name[:-1])+b'.'+name[-1]).replace(b'\x00', b'').replace(b'\\', b''))
        names.append(name)
        #print(int(id), name)
    
    info = []
    if rapi.checkFileExists(dir+'/IMG_HD.BIN'):
        data = rapi.loadIntoByteArray(dir+'/IMG_HD.BIN')
        bs = NoeBitStream(data)
        
        for x in range(bs.getSize()//8):
            info.append([bs.readUInt()*2048, bs.readUInt()])
    else:
        print('Not found "IMG_HD.BIN"')
        return 0
    
    if rapi.checkFileExists(dir+'/IMG_BD.BIN'):
        with open(dir+'/IMG_BD.BIN', "rb") as f:
            data = NoeFileStream(f)
        
            for i,x in enumerate(info):
                data.seek(x[0])
                export_data = data.readBytes(x[1])
                rapi.exportArchiveFile(names[i], export_data)
                print("export", names[i])

        print("Extracting", len(info), "files.")
    else:
        print('Not found "IMG_HD.BIN"')
        return 0
    
    return 1
    
'''
Table of contents: img_hd.bin
Data: img_bd.bin
Names: norg_eng.00

img_hd.bin:
Start: 0x00 (read to end)
- uint (4 bytes) x 2048: Offset in img_bd.bin
- uint (4 bytes): Data length
'''