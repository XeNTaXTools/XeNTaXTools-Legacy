
XXIExplorer v2.2 
October 2, 2006

No more guessing at the type and size of the DDS files.  Finally decoded the type, width and length of the DDS files from the texture header.  Exports files to the correct folder in the main folder of the wad files.  Exports and imports DDS files from the .k and .res files.

Keep the zlib file in the directory with XXIExplorer.  It doesn't need to be copied to the system directory.

Have fun.
