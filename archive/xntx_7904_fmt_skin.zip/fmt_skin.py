from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("put game name here",".skin")
    noesis.setHandlerTypeCheck(handle, CheckType)
    noesis.setHandlerLoadModel(handle, LoadModel)	
    return 1
    
def CheckType(data):
    bs = NoeBitStream(data)
    if len(data) < 16:
        print("Invalid file, too small")
        return 0
    return 1		
        
def LoadModel(data, mdlList):
    ctx = rapi.rpgCreateContext()

    bs = NoeBitStream(data)
    bs.seek(0x28)
    jCount = bs.readUInt() // 584
    bs.seek(bs.readUInt() + 0x20)
    
    joints = []
    
    for i in range(jCount):
        bs.seek(216, 1) #skip the first info
        bs.seek(0x30, 1) #skip the initial coords (probably local space coordinates but we have the model space ones next so we don't care)
        
        jointMatrix = NoeMat43() #if the matrix was stored per row you'd just have to do NoeMat43.fromBytes(bs.readBytes(0x30))
        #It's not the case here, so we read it column by column (so m11 then m21 then m31 etc)
        for k in range(3):
            for j in range(4):
                jointMatrix[j][k] = bs.readFloat()
        #The Y/Z axes in this game are switched compared to Noesis. So we switch both to have a good display (otherwise the skeleton would lie on the ground)
        pos = jointMatrix[3] #grab the joint's location
        jointMatrix[3] = [pos[0], pos[2], pos[1]] #switch the coordinates
        temp = bs.tell()
        jointName = bs.readString()
        bs.seek(temp + 260)
        parentRelativeIndex = bs.readInt()
        if not parentRelativeIndex:
            joints.append(NoeBone(i, jointName, jointMatrix, None, -1))
        else:
            joints.append(NoeBone(i, jointName, jointMatrix, None, i + parentRelativeIndex))
        bs.seek(8,1)
    
    try:
        mdl = rapi.rpgConstructModel()
    except:
        mdl = NoeModel()
    
    mdl.setBones(joints)
    mdlList.append(mdl)
    
    
    return 1
    
    