#WWE Raw 2 [Xbox] - ".fml" Loader
#By Gh0stblade
#v1.0
#Special thanks: Chrrox
#Options: These are bools that enable/disable certain features! They are global and affect ALL platforms!
#Var							Effect
#Misc
#Mesh Global
fDefaultMeshScale = 1.0 		#Override mesh scale (default is 1.0)
bOptimizeMesh = 0				#Enable optimization (remove duplicate vertices, optimize lists for drawing) (1 = on, 0 = off)
#bMaterialsEnabled = 1			#Materials (1 = on, 0 = off)
bRenderAsPoints = 0				#Render mesh as points without triangles drawn (1 = on, 0 = off)
#Vertex Components
bNORMsEnabled = 1				#Normals (1 = on, 0 = off)
bUVsEnabled = 1					#UVs (1 = on, 0 = off)
bDebugNormals = 0
#Gh0stBlade ONLY
debug = 1 						#Prints debug info (1 = on, 0 = off)


from inc_noesis import *
import math

def registerNoesisTypes():
	handle = noesis.register("WWE Raw 2 [Xbox]", ".fml")
	noesis.setHandlerTypeCheck(handle, fmlCheckType)
	noesis.setHandlerLoadModel(handle, fmlLoadModel)
	
	noesis.logPopup()
	return 1

def fmlCheckType(data):
	bs = NoeBitStream(data)
	fileMagic = bs.readUInt()
	if fileMagic == 0xF001FFD0:
		return 1
	else: 
		print("Fatal Error: Unknown file magic: " + str(hex(fileMagic) + " expected '0xF001FFD0'!"))
		return 0
		
class fmlFile(object): 
	def __init__(self, data):
		self.inFile = NoeBitStream(data)
		self.meshNames = []
		self.matNames = []
		self.texNames = []
		self.boneList = []
		self.numBones = -1
		
	def loadfmlFile(self):
		bs = self.inFile
		
		fileMagic = bs.readUInt()
		
		unk01 = bs.readUShort()
		unk02 = bs.readUShort()
		numTris = bs.readUShort()
		unk04 = bs.readUShort()
		numUnk00 = bs.readUShort()
		numNormals = bs.readUShort()
		
		numVertComponents = bs.readUShort()
		numBones = bs.readUShort()
		unk07 = bs.readUShort()
		numVerts = bs.readUShort()
		numNames00 = bs.readUByte()
		numNames01 = bs.readUByte()
		numNames02 = bs.readUByte()#mat
		numNames03 = bs.readUByte()
		
		unk11 = []
		for i in range(numUnk00):
			unk11.append(bs.readUInt())
		
		if debug:
			print("Normal Buffer Offset: " + str(bs.getOffset()))
			
		normList = []
		for i in range(numNormals):
			normList.append(bs.readShort())
			normList.append(bs.readShort())
			normList.append(bs.readShort())
		
		if debug:
			print("Index Buffer Offset: " + str(bs.getOffset()))
		indexBuff = bs.readBytes(numTris * 2)
		
		if debug:
			print("Vertex Buffer Offset: " + str(bs.getOffset()))
			
		vertList = []
		for i in range(numVertComponents):
			vertList.append(bs.readFloat())
			vertList.append(bs.readFloat())
			vertList.append(bs.readFloat())
		
		if debug:
			print("Vertex Buffer Remap Information Offset: " + str(bs.getOffset()))
		
		vertexBufferRemapInfo = []
		vertBufferList = []
		normBufferList = []
		uvBufferList = []
		for i in range(numVerts):
			vertexBufferRemapInfo.append(bs.read("6H"))
			vertBufferList.append(vertList[vertexBufferRemapInfo[i][0]*3])
			vertBufferList.append(vertList[vertexBufferRemapInfo[i][0]*3+1])
			vertBufferList.append(vertList[vertexBufferRemapInfo[i][0]*3+2])
			normBufferList.append(normList[vertexBufferRemapInfo[i][1]*3])
			normBufferList.append(normList[vertexBufferRemapInfo[i][1]*3+1])
			normBufferList.append(normList[vertexBufferRemapInfo[i][1]*3+2])
			uvBufferList.append(vertList[vertexBufferRemapInfo[i][2]*3])
			uvBufferList.append(vertList[vertexBufferRemapInfo[i][2]*3+1])
			uvBufferList.append(vertList[vertexBufferRemapInfo[i][2]*3+2])
			
			if debug:
				print(vertexBufferRemapInfo[i])
			
		vertBuff = struct.pack("<" + 'f'*len(vertBufferList), *vertBufferList)
		uvBuff = struct.pack("<" + 'f'*len(uvBufferList), *uvBufferList)
		normBuff = struct.pack("<" + 'h'*len(normBufferList), *normBufferList)
		
		for i in range(numNames00):
			print(self.getString())
			
		for i in range(numNames01):
			print(self.getString())
			print(self.getString())
			
		for i in range(numNames02):
			print(self.getString())
			matInfo = bs.read("12B1H")
			
			if i + 1 == numNames02:
				bs.seek(numNames02 * 18, NOESEEK_REL)
		
		#Load Bones
		self.loadBones(self.numBones)
		self.boneList = rapi.multiplyBones(self.boneList)
		
		rapi.rpgBindPositionBufferOfs(vertBuff, noesis.RPGEODATA_FLOAT, 12, 0)
		rapi.rpgBindUV1BufferOfs(uvBuff, noesis.RPGEODATA_FLOAT, 12, 0)
		
		if bNORMsEnabled:
			if bDebugNormals:
				rapi.rpgBindColorBufferOfs(normBuff, noesis.RPGEODATA_SHORT, 6, 0, 3)
			else:
				rapi.rpgBindNormalBufferOfs(normBuff, noesis.RPGEODATA_SHORT, 6, 0)
		
		if bRenderAsPoints:
			rapi.rpgCommitTriangles(None, noesis.RPGEODATA_USHORT, numVerts, noesis.RPGEO_POINTS, 1)
		else:
			rapi.rpgCommitTriangles(indexBuff, noesis.RPGEODATA_USHORT, int(numTris), noesis.RPGEO_TRIANGLE, 1)
		rapi.rpgClearBufferBinds()
		
	def getString(self):
		bs = self.inFile
		startOffset = bs.getOffset()
		string = bs.readString()
		bs.seek(startOffset + 0x10, NOESEEK_ABS)
		return string
		
	def loadBones(self, parentID):
		bs = self.inFile
		
		self.numBones += 1
		boneName = self.getString()
		boneMat = NoeMat43.fromBytes(bs.readBytes(48)).transpose()
		boneUnk00 = bs.readUByte()
		numChildren = bs.readUByte()
		boneUnk01 = bs.readUShort()
		
		self.boneList.append(NoeBone(self.numBones, boneName, boneMat, None, parentID))
		
		if debug:
			print("BN: " + str(boneName) + " BID: " + str(self.numBones) + " PID: " + str(parentID) + " NC: " + str(numChildren))
		
		lastParentID = self.numBones #Copy since self.numBones is incremented each time this method is called and thus we will not retain the parentID
		
		for i in range (numChildren):
			self.loadBones(lastParentID)
			
		return 1
		
def fmlLoadModel(data, mdlList):
	ctx = rapi.rpgCreateContext()
	mesh = fmlFile(data)
	mesh.loadfmlFile()
	try:
		mdl = rapi.rpgConstructModelSlim()
	except:
		mdl = NoeModel()
	mdl.setBones(mesh.boneList)
	mdlList.append(mdl);
	return 1