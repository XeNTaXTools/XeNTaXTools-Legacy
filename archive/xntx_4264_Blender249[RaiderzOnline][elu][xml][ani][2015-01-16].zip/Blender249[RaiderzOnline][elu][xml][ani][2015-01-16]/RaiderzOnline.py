import newGameLib
reload(newGameLib)
from newGameLib import *
import Blender
	
import math
from math import *


		
		
				
def bindPose(bindSkeleton,poseSkeleton,meshObject):
		#print 'BINDPOSE'
		mesh=meshObject.getData(mesh=1)
		poseBones=poseSkeleton.getData().bones
		bindBones=bindSkeleton.getData().bones			
		for vert in mesh.verts:
			index=vert.index
			skinList=mesh.getVertexInfluences(index)
			vco=vert.co.copy()*meshObject.matrixWorld
			vector=Vector()
			for skin in skinList:
				try:
					bone=skin[0]							
					weight=skin[1]					
					matA=bindBones[bone].matrix['ARMATURESPACE']*bindSkeleton.matrixWorld
					matB=poseBones[bone].matrix['ARMATURESPACE']*poseSkeleton.matrixWorld
					vector+=vco*matA.invert()*matB*weight
				except:pass	
			vert.co=vector
		mesh.update()
		Blender.Window.RedrawAll()
			


def eluParser(filename,g): 
	skeleton=Skeleton()
	#skeleton.NICE=True
	skeleton.ARMATURESPACE=True
	skeleton.SORT=True
	v=g.i(4)	
	meshList=[]	
	for m in range(v[3]):
		bone=Bone()
		boneName=g.word(g.i(1)[0])
		bone.name=boneName
		#print bone.name
		bone.parentID=g.i(1)[0]
		parent=g.word(g.i(1)[0])
		t=g.tell()		
		matrix=Matrix(g.f(4),g.f(4),g.f(4),g.f(4))
		bone.matrix=matrix
		skeleton.boneList.append(bone)
		g.seek(t+80)
		num=g.i(1)[0]		
		if num>0:
			mesh=Mesh()
			for n in range(num):mesh.vertPosList.append(Vector(g.f(3))*1.0)				
			uvList=[]	
			for n in range(g.i(1)[0]):
				uvList.append([g.f(1)[0],1-g.f(1)[0]])
				g.f(1)
			for n in range(g.i(1)[0]):g.f(3)
			for n in range(g.i(1)[0]):g.f(3)
			for n in range(g.i(1)[0]):g.f(4)
			var=g.i(4)
			faceCount=var[1]			
			for n in range(faceCount):
				face=[]
				uv=[]
				for k in range(g.i(1)[0]):
					fd=g.H(6)
					face.append(fd[0])
					uv.append(Vector(uvList[fd[1]]))
				mesh.matIDList.append(g.H(1)[0])
				mesh.faceList.append(face)
				mesh.faceUVList.append(uv)
			count=g.i(1)[0]	
			for n in range(count):g.seek(12,1)
			var=g.i(2)
			for n in range(var[1]):
				indiceList=[]
				weightList=[]
				for k in range(g.i(1)[0]):
					indiceList.append(g.H(2)[0])
					weightList.append(g.f(1)[0])
				mesh.skinIndiceList.append(indiceList)
				mesh.skinWeightList.append(weightList)
			skin=Skin()
			mesh.skinList.append(skin)	
			var=g.i(2)		
			for n in range(var[1]):g.H(6)
			num=g.i(1)[0]
			
			
			
			bindSkeleton=Skeleton()
			for n in range(num):
				bone=Bone()
				matrix=Matrix(g.f(4),g.f(4),g.f(4),g.f(4))
				bone.matrix=matrix#.invert()
				bindSkeleton.boneList.append(bone)
			mesh.bindSkeleton=bindSkeleton	
				
				
				
			mesh.boneMap=g.H(num)
			matCount=g.i(1)[0]
			for n in range(matCount):
				var=g.H(6)
				print var			
				matID=var[0]
				mat=Mat()
				try:
					mat.diffuse=matList[matID].diffuse
					mat.specular=matList[matID].specular
					mat.normal=matList[matID].normal
				except:pass	
				mesh.matList.append(mat)
			g.i(1)[0],g.tell()
			for n in range(faceCount):g.H(3)
			g.f(6)
			meshList.append([mesh,boneName])
		else:		
			g.seek(t+164)
	skeleton.draw()	
	for mesh,bone in meshList:
		id=ParseID()
		if len(mesh.boneMap)<=1:
			mesh.name=str(id)+'-mesh'	
			mesh.matrix=skeleton.armature.bones[bone].matrix['ARMATURESPACE']
		else:	
			mesh.name=str(id)+'-mesh'
			for ID in range(len(mesh.boneMap)):
				mesh.skinList[0].boneMap.append(skeleton.boneNameList[mesh.boneMap[ID]])
				mesh.bindSkeleton.boneList[ID].name=skeleton.boneNameList[mesh.boneMap[ID]]
			#mesh.BINDSKELETON=skeleton.name
			mesh.bindSkeleton.name=str(id)+'-skeleton'	
			mesh.bindSkeleton.NICE=True
			mesh.bindSkeleton.draw()		
		mesh.draw()

	scene = bpy.data.scenes.active
	for object in scene.objects:
		if object.type=='Mesh':
			if '-mesh' in object.name:
				try:
					bindSkeleton=Blender.Object.Get(object.name.replace('mesh','skeleton'))
					poseSkeleton=Blender.Object.Get('armature')
					meshObject=object
					bindPose(bindSkeleton,poseSkeleton,meshObject)	
				except:pass	

					
	scene = bpy.data.scenes.active
	for object in scene.objects:
			if object.type=='Mesh':
				skeleton.object.makeParentDeform([object],0,0)
			if '-skeleton' in object.name:
				scene.unlink(object)
	Blender.Window.RedrawAll	
	
			

def xmlParser(filename,file):
	xml=Xml()
	#xml.DRAWCONSOLE=True			
	xml.input=file
	xml.parse()
					
	matNodeList=xml.find(xml.root,'MATERIAL')
	for node in matNodeList:
		mat=Mat()
		#mat.ZTRANS=True
		layerList=xml.find(node,'TEXTURELAYER')		
		for layer in layerList:
			for child in layer.children:
				if child.key=='DIFFUSEMAP':
					mat.diffuse=texDir+os.sep+child.values
				if child.key=='SPECULARMAP':
					mat.specular=texDir+os.sep+child.values
				if child.key=='NORMALMAP':
					mat.normal=texDir+os.sep+child.values
		matList.append(mat)			


	
def aniParser(filename,g):
	action=Action()
	action.BONESPACE=True
	#action.ARMATURESPACE=True
	#action.UPDATE=False
	
	action.BONESORT=True
	#action.FRAMESORT=True
	w=g.i(5)
	for m in range(w[3]):
		bone=ActionBone()
		bone.name=g.word(g.i(1)[0])
		posMatrix=VectorMatrix(g.f(3))
		rotMatrix=QuatMatrix(g.f(4)).resize4x4()
		g.f(3)
		g.i(2)
		bone.posFrameList.append(0)
		bone.rotFrameList.append(0)
		bone.posKeyList.append(posMatrix)
		bone.rotKeyList.append(rotMatrix)
		#matrix=rotMatrix*posMatrix
		
		for n in range(g.i(1)[0]):	
			time=1+g.i(1)[0]/160		
			key=VectorMatrix(g.short(3))#*posMatrix
			if n==-10:
				bone.posFrameList.append(time)
				bone.posKeyList.append(key)
		g.i(2)
		for n in range(g.i(1)[0]):
			time=1+g.i(1)[0]/160
			x=degrees(g.f(1)[0])			
			y=degrees(g.f(1)[0])
			z=degrees(g.f(1)[0])
			key=Euler([x,y,z]).toMatrix().resize4x4()#*rotMatrix
			if n==-10:
				bone.rotFrameList.append(time)
				bone.rotKeyList.append(key)	
		g.i(5)
		for n in range(g.i(1)[0]):
			g.i(2)
		action.boneList.append(bone)	
	g.tell()
	#skeleton.draw()
	action.draw()
	action.setContext()
		
	
			
			
	
def Parser():	
	filename=input.filename
	ext=filename.split('.')[-1].lower()	
	global matList
	global texDir
	print
	print filename
	print
	ext=filename.split('.')[-1].lower()	
	texDir=filename.lower().split('model')[0]+'texture'+os.sep+'character'
	matList=[]
	if ext=='elu':		
		file=open(filename,'rb')		
		g=BinaryReader(file)
		eluParser(filename,g)
		file.close()
		
	if ext=='xml':
		file=open(filename,'r')
		xmlParser(filename,file)
		file.close()
		eluPath=filename.split('.xml')[0]
		if os.path.exists(eluPath)==True:	
			file=open(eluPath,'rb')		
			g=BinaryReader(file)
			#g.logOpen()
			eluParser(eluPath,g)
			#g.logClose()
			file.close()
		
	if ext=='ani':
		file=open(filename,'rb')
		g=BinaryReader(file)
		#g.logOpen()
		aniParser(filename,g)
		#g.logClose()
		file.close()	
 
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
	
	
Blender.Window.FileSelector(openFile,'import','Raiderz Online files *.xml, *.elu, *.ani')