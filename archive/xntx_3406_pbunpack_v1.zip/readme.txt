-= PB Archives (Front Mission 2) Extractor Tool v1.0 [by Lab313] =-
----------------------------------
Analysis: AID_X
Coding: Dr. MefistO
Our site: http://lab313.ru
----------------------------------
This tool decompresses RLE-packed archives with PB-tag [50 42 00 00].

USAGE: pbunpack.exe ZDATA.BIN
ZDATA.BIN: file from "Front Mission 2" game.

Source is included (Delphi + KOL).
Date: 27.03.2012