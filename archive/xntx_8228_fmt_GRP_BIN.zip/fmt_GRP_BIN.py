#by Durik256 for xentax
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Ah My Goddess (PS2)", ".BIN")
    noesis.setHandlerExtractArc(handle, ExtractBIN)
    return 1
    
def ExtractBIN(fileName, fileLen, justChecking):
    if fileLen < 16:
        return 0
        
    if justChecking: #it's valid
            return 1

    data = rapi.loadIntoByteArray(fileName)
    bs = NoeBitStream(data)
    inf_size = bs.readInt()
    
    file_inf = []
    fs = NoeBitStream(data[4:inf_size])
    while not 0:
        name = bs.readBytes(12)
        
        if name == b'\x00'*12:
            break
        
        name = noeAsciiFromBytes(name) + '.PK'
        size, offset = bs.readInt(), bs.readInt()
        file_inf.append([name, offset, size])
    
    for x in file_inf:
        bs.seek(x[1])
        export_data = bs.readBytes(x[2])
        rapi.exportArchiveFile(x[0], export_data)
        print("export", x[0])

    print("Extracting", len(file_inf), "files.")
    return 1