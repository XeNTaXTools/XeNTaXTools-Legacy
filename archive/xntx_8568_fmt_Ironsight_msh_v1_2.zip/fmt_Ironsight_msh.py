# Ironsight Model - ".msh" plugin
# By PeterZ
# Special thanks: zaramot
# v1.1 (2022.9.6) - Remove "addRootBone" feature. Use first bone instead.

from inc_noesis import *
import noesis
import rapi
import os
import glob


def registerNoesisTypes():
    handle = noesis.register("Ironsight Model", ".msh")
    noesis.setHandlerTypeCheck(handle, CheckType)
    noesis.setHandlerLoadModel(handle, LoadModel)
    noesis.logPopup()
    return 1


def CheckType(data):
    bs = NoeBitStream(data)
    idMagic = bs.readBytes(4)
    if idMagic != b'MESH':
        return 0
    return 1


def LoadModel(data, mdlList):
    bLoadedRootBone=False
    rootBoneIdx=None
    rapi.rpgCreateContext()
    # matList = []
    skelBones = []
    bs = NoeBitStream(data)
    bs.seek(0x24)

    # Bones START
    skelBoneCount = bs.readUInt()
    for skelBoneIndex in range(skelBoneCount):
        skelBoneName = 'bone'+str(skelBoneIndex)
        bs.seek(8, NOESEEK_REL)
        skelBoneParent = bs.readInt()
        if(skelBoneParent==-1):#Attach to root bone
            if not (bLoadedRootBone):
                bLoadedRootBone=True
                rootBoneIdx=skelBoneIndex
            else:skelBoneParent=rootBoneIdx

        skelBoneTrn = NoeVec3.fromBytes(bs.readBytes(12))
        skelBoneRot = NoeQuat.fromBytes(bs.readBytes(16))
        skelBoneMtx = skelBoneRot.toMat43()
        skelBoneMtx[3] = skelBoneTrn
        skelNewBone = NoeBone(skelBoneIndex, skelBoneName,
                              skelBoneMtx, None, int(skelBoneParent))
        skelBones.append(skelNewBone)
        bs.seek(16, NOESEEK_REL)
    # Bones END

    # Mesh Start
    lodCount = bs.readInt()
    for lodIdx in range(lodCount):
        bs.readFloat()  # viewDistance?
        bs.readUInt()  # meshIdx_start
        bs.readUInt()  # meshIdx_end
    meshCount = bs.readInt()

    for meshIndex in range(meshCount):
        rapi.rpgSetName("MESH_" + str(meshIndex))
        bs.readBytes(8)  # padding
        wShift = bs.readInt()
        vSecSize = bs.readInt()
        vertBuffStart = bs.tell()
        vertBuff = bs.readBytes(vSecSize)
        vertBuffEnd = bs.tell()
        if(wShift == 2):  # staticMesh
            rapi.rpgBindPositionBufferOfs(
                vertBuff, noesis.RPGEODATA_FLOAT, 28, 0)
            rapi.rpgBindUV1BufferOfs(
                vertBuff, noesis.RPGEODATA_SHORT, 28, 12)
        if(wShift == 3):  # skeletonMesh
            rapi.rpgBindPositionBufferOfs(
                vertBuff, noesis.RPGEODATA_FLOAT, 32, 0)
            rapi.rpgBindUV1BufferOfs(
                vertBuff, noesis.RPGEODATA_SHORT, 32, 12)
            rapi.rpgSetUVScaleBias(NoeVec3((32, 32, 32)), (0, 0, 0))
            bs.seek(vertBuffStart, NOESEEK_ABS)
            vwList = []
            for j in range(0, vSecSize//32):
                bs.seek(24, NOESEEK_REL)
                vwNum = 3
                bidx = []
                bwgt = []
                tmpWeight = [bs.readUByte() for i in range(3)]  # w3 w2 w1
                tmpWeight.reverse()  # w1 w2 w3
                tmpWeight.append(bs.readUByte())  # w1 w2 w3 w4
                tmpBoneIdx = [bs.readUByte()//3 for i in range(4)]
                for i in range(4):
                    if(tmpBoneIdx[i] <skelBoneCount):
                        bidx.append(tmpBoneIdx[i])
                        bwgt.append(tmpWeight[i])
                vwList.append(NoeVertWeight(bidx, bwgt))
            fw = NoeFlatWeights(vwList)
            rapi.rpgBindBoneIndexBuffer(
                fw.flatW[:fw.weightValOfs], noesis.RPGEODATA_INT, 4*fw.weightsPerVert, fw.weightsPerVert)
            rapi.rpgBindBoneWeightBuffer(
                fw.flatW[fw.weightValOfs:], noesis.RPGEODATA_FLOAT, 4*fw.weightsPerVert, fw.weightsPerVert)

            bs.seek(vertBuffEnd, NOESEEK_ABS)
        elif(wShift == 7):
            print("Not supported yet")
            return 0
        FSecSize = bs.readInt()
        faceBuff = bs.readBytes(FSecSize)
        rapi.rpgCommitTriangles(
            faceBuff, noesis.RPGEODATA_USHORT, FSecSize//2, noesis.RPGEO_TRIANGLE, 1)
        rapi.rpgClearBufferBinds()
    # Mesh End

    mdl = rapi.rpgConstructModel()
    # mdl.setModelMaterials(NoeModelMaterials([], matList))
    mdlList.append(mdl)
    mdl.setBones(skelBones)
    return 1
