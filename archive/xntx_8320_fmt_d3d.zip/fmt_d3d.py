# by Durik
from inc_noesis import *

def registerNoesisTypes():
   handle = noesis.register("Legends of Eisenwald", ".d3d")
   noesis.setHandlerTypeCheck(handle, CheckType)
   noesis.setHandlerLoadModel(handle, LoadModel)
   return 1

def CheckType(data):
    return 1       

def LoadModel(data, mdlList):
    ctx = rapi.rpgCreateContext()
    bs = NoeBitStream(data)
    bs.seek(4)
    name = noeAsciiFromBytes(bs.readBytes(bs.readInt()))
    for x in range(bs.readInt()):
        bs.seek(bs.readInt()+1,1)
        bs.seek(4,1)
    
    bs.seek(8,1)
    vnum, inum, fnum, stride, unk = [bs.readInt() for x in range(5)]
    
    ibuf = bs.readBytes(inum*2)
    vbuf = bs.readBytes(vnum*stride)
    
    rapi.rpgSetMaterial(name)
    rapi.rpgBindPositionBuffer(vbuf, noesis.RPGEODATA_FLOAT, stride)
    rapi.rpgBindUV1BufferOfs(vbuf, noesis.RPGEODATA_USHORT, stride, 24)
    rapi.rpgSetUVScaleBias(NoeVec3([16]*3), None)
    rapi.rpgCommitTriangles(ibuf, noesis.RPGEODATA_USHORT, inum, noesis.RPGEO_TRIANGLE)
    
    rapi.rpgSetOption(noesis.RPGOPT_TRIWINDBACKWARD, 1)
    mdl = rapi.rpgConstructModel()
    mdlList.append(mdl)
    rapi.setPreviewOption("setAngOfs", "0 90 90")
    return 1