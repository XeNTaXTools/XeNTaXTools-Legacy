#by Durik256
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("unk game",".csf")
    noesis.setHandlerTypeCheck(handle, bcCheckType)
    noesis.setHandlerLoadModel(handle, bcLoadModel)
    return 1

def bcCheckType(data):
    if data[:3] != b'CSF':
        return 0
    return 1

def bcLoadModel(data, mdlList):
    bs = NoeBitStream(data)
    bs.seek(8)
    
    bones = []
    for x in range(bs.readInt()):
        name = noeAsciiFromBytes(bs.readBytes(bs.readInt()))
        pos = NoeVec3.fromBytes(bs.readBytes(12))
        rot = NoeQuat.fromBytes(bs.readBytes(16)).toMat43()
        rot[3] = pos
        bs.seek(28,1)
        parent = bs.readInt()
        bs.seek(bs.readInt()*4,1)
        bones.append(NoeBone(x, name, rot, None, parent))


    bones = rapi.multiplyBones(bones)
    mdl = NoeModel()
    mdl.setBones(bones)
    mdlList.append(mdl)
    return 1
    
'''
offset[12]
name[0,int32,false]
pos[float]
quat[float]
seek[28]
parent[int32]
seek[0,int32,4]
'''