#by Durik256
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("unk game",".cmf")
    noesis.setHandlerTypeCheck(handle, bcCheckType)
    noesis.setHandlerLoadModel(handle, bcLoadModel)
    return 1

def bcCheckType(data):
    if data[:3] != b'CMF':
        return 0
    return 1

def bcLoadModel(data, mdlList):
    bs = NoeBitStream(data)
    ctx = rapi.rpgCreateContext()
    bs.seek(16)
    bones = []
    try:
        bones = loadSkel()
    except:
        print('Error load skeleton!')
    
    vnum, fnum = bs.read('2I')
    vbuf = bs.read(vnum*12)
    nbuf = bs.read(vnum*12)
    uvbuf = bs.read(vnum*8)
    iwbuf = b''
    wbuf  = b''
    for x in range(vnum):
        for x in range(4):
            iwbuf += bs.read(4)
            wbuf  += bs.read(4)
    ibuf = bs.read(fnum*6)
    
    rapi.rpgBindPositionBuffer(vbuf, noesis.RPGEODATA_FLOAT, 12)
    rapi.rpgBindUV1Buffer(uvbuf, noesis.RPGEODATA_FLOAT, 8)
    rapi.rpgBindBoneIndexBuffer(iwbuf, noesis.RPGEODATA_UINT, 16, 4)
    rapi.rpgBindBoneWeightBuffer(wbuf, noesis.RPGEODATA_FLOAT, 16, 4)
    rapi.rpgCommitTriangles(ibuf, noesis.RPGEODATA_USHORT, fnum*3, noesis.RPGEO_TRIANGLE)

    rapi.rpgSetOption(noesis.RPGOPT_TRIWINDBACKWARD, 1)
    mdl = rapi.rpgConstructModel()
    mdl.setBones(bones)
    mdlList.append(mdl)
    rapi.setPreviewOption("setAngOfs", "0 -90 0")
    return 1
    
def loadSkel():
    bs = NoeBitStream(rapi.loadIntoByteArray(rapi.getInputName().replace('.cmf','.csf')))
    bs.seek(8)
    
    bones = []
    for x in range(bs.readInt()):
        name = noeAsciiFromBytes(bs.readBytes(bs.readInt()))
        pos = NoeVec3.fromBytes(bs.readBytes(12))
        rot = NoeQuat.fromBytes(bs.readBytes(16)).toMat43()
        rot[3] = pos
        bs.seek(28,1)
        parent = bs.readInt()
        bs.seek(bs.readInt()*4,1)
        bones.append(NoeBone(x, name, rot, None, parent))


    return rapi.multiplyBones(bones)