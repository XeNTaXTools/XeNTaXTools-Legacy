from inc_noesis import *
import os

def registerNoesisTypes():
    handle = noesis.register("Supreme Snowboarding (1999)",".skl")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, LoadModel)    
    return 1
    
def noepyCheckType(data):
    bs = NoeBitStream(data)
    if noeAsciiFromBytes(bs.readBytes(5)) != 'BONE':
        return 0
    return 1  

def LoadModel(data, mdlList):
    bs = NoeBitStream(data)
    bs.seek(5)#BONE
    cBone = bs.readInt()
    unk = bs.readInt()
    print("bone_count:",cBone, "/unk:", unk)
    
    bones = []
    MotionMatrix = []
    
    for x in range(cBone):
        bs.seek(5, NOESEEK_REL)#SIGN
        name = searchString(bs)
        parentName = searchString(bs)
        cFrame = bs.readInt()
        
        print(name, "/parent:", parentName,"/frame_count:",cFrame, "/unk:",bs.readInt())
        
        for y in range(cFrame):
            mat = NoeMat43()
            bs.seek(28, NOESEEK_REL)
            '''
            read matrix 
            your code...
            time = bs.readFloat()???
            rot = NoeAngles.fromBytes(bs.readBytes(12)).transpose().toMat43()???
            pos = NoeVec3.fromBytes(bs.readBytes(12))
            '''
            MotionMatrix.append(mat)
        
        bones.append(NoeBone(x, name, MotionMatrix[-cFrame], parentName))

    anim = NoeAnim("anim", bones, cFrame, MotionMatrix, 30)

    mdl = NoeModel()
    mdl.setBones(bones)
    #mdl.setAnims([anim])
    mdlList.append(mdl)
    return 1
    
def searchString(bs):
    bytes = []
    byte = None
    while byte != 0:
        byte = bs.readUByte()
        bytes.append(byte)
    return noeAsciiFromBytes(bytes)
    
def GetParentIndex (parentName, arr):
    for i,bone in enumerate(arr):
        if bone.name == parentName:
            return i
    return -1 