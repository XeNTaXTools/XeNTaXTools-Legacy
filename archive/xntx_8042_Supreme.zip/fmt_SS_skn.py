from inc_noesis import *
import os

def registerNoesisTypes():
    handle = noesis.register("Supreme Snowboarding (1999)",".skn")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, LoadModel)    
    return 1
    
def noepyCheckType(data):
    bs = NoeBitStream(data)
    if noeAsciiFromBytes(bs.readBytes(5)) != 'SKIN':
        return 0
    return 1  

def LoadModel(data, mdlList):
    bs = NoeBitStream(data)
    bs.seek(5)#SKIN
    unk = bs.readInt()
    cBone = bs.readInt()
    print("SKIN", "ver?" ,unk, "\n/count_bone:",cBone)
    
    bones = []
    for x in range(cBone):
        id = bs.readInt()
        name = searchString(bs)
        bones.append(NoeBone(id, name, NoeMat43()))
        print(id, name)
    
    bs.seek(5, NOESEEK_REL)#SIGN
    nameModel = searchString(bs)
    count = bs.readInt()
    print("model:", "'"+nameModel+"'", "/count_data:",count)

    for x in range(count):
        #bs.seek(24, NOESEEK_REL)
        idBone = bs.readInt()
        unk_v = [bs.readFloat() for x in range(4)]
        idVert = bs.readInt()
        
        print("vertex:",idVert,"/bone:",idBone,"/unk:",unk_v)
        
    bs.seek(10, NOESEEK_REL)#SIGN SIGN
    
    mdl = NoeModel()
    mdl.setBones(bones)
    mdlList.append(mdl)
    return 1
    
def searchString(bs):
    bytes = []
    byte = None
    while byte != 0:
        byte = bs.readUByte()
        bytes.append(byte)
    return noeAsciiFromBytes(bytes)