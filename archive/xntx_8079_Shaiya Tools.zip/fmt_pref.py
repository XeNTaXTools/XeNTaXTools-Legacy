#by Durik256 15.03.2022 for xentax
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Shaiya",".pref")
    noesis.setHandlerTypeCheck(handle, CheckType)
    noesis.setHandlerLoadModel(handle, LoadModel)    
    return 1
    
def CheckType(data):
    if 'SHAIYA PREFAB' in data.decode().split('\n')[0]:
        return 1
    return 0

def LoadModel(data, mdlList):
    lines = data.decode().split('\n')[1:]
    
    if not CheckLibrary():
        print('not exists fmt_ani.py or fmt_3dc.py')
        return 0
    
    meshes, bones, anims = [], [], []
    for file in lines:
        print(file)
        if rapi.checkFileExt(file.strip(),'.3dc'):
            print(">>>",file)
            _mesh, _bones = OpenMesh(file.strip())
            if _mesh:
                meshes.append(_mesh)
            if _bones and not bones:
                bones = _bones
        elif rapi.checkFileExt(file.strip(),'.ani'):
            _anim, _bones = OpenAnims(file.strip())
            if _anim:
                anims.append(_anim)
                if bones:
                    fixParent(bones, _bones)
    
    mdl = NoeModel()
    mdl.setMeshes(meshes)
    mdl.setBones(bones)
    mdl.setAnims(anims)
    mdlList.append(mdl)
    return 1
    
def CheckLibrary():
    sciptPath = rapi.getDirForFilePath(os.path.realpath(__file__))
    sciptAnim = sciptPath + 'fmt_ani.py'
    scriptMesh = sciptPath +'fmt_3dc.py'
    
    if rapi.checkFileExists(sciptAnim) and rapi.checkFileExists(scriptMesh):
        return 1
    return 0
    
def OpenMesh(path):
    import fmt_3dc
    bs = NoeBitStream(rapi.loadIntoByteArray(path))
    mdl, bones = fmt_3dc.ParseFile(bs)
    if mdl.meshes:
        return mdl.meshes[0], bones
    return 0, 0
    
def OpenAnims(path):
    import fmt_ani
    data = rapi.loadIntoByteArray(path)
    mdlList = []
    fmt_ani.LoadModel(data, mdlList)
    if mdlList:
        return mdlList[0].anims[0], mdlList[0].bones
    return 0, 0
            
def fixParent(bones, animBones):
    for x in range(len(animBones)):
        bones[x].parentIndex = animBones[x].parentIndex