import sys
import os

droppedFiles = sys.argv[1:]
dir = os.path.dirname(droppedFiles[0])
name = os.path.splitext(droppedFiles[0])[0]+'.pref'
print("create:",dir,name)

with open(os.path.join(dir,name), 'w') as f:
    f.write('SHAIYA PREFAB\n')
    for file in droppedFiles:
        f.write(file+'\n')
        print("write: >>",file)
os.system('pause')