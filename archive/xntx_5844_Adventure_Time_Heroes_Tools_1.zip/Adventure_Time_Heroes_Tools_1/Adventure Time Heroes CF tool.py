# -*- coding: utf-8 -*-


#This tool was made by Ikskoks for Xentax community.
#Please don't copy this tool to other forums and sites.

#If you like my tool, please consider visit my fanpage https://www.facebook.com/ikskoks/ and site http://ikskoks.pl/



import argparse
import os
import sys
import time
import struct
import binascii
import re
import codecs

if len(sys.argv)<2:
        print "ikskoks's Adventure Time Heroes Font Tool"
        print "Usage: <my_tool.py> file.cf       "
        print "       <my_tool.py> --write file.cf"
        print "       <my_tool.py> --help          "
        
else:        
        parser = argparse.ArgumentParser()
        parser.add_argument('--write', help="Save to CF file", required=False, action="store_true")
        parser.add_argument("plik_CF", help="Path to CF file")
        args = parser.parse_args()
        
        (sciezka_CF, nazwa_CF) = os.path.split(args.plik_CF)
        (Krotka_nazwa_CF, extension) = os.path.splitext(nazwa_CF) 
        pelna_sciezka_do_CF = args.plik_CF    
        pelna_sciezka_nowy_TXT = sciezka_CF + "\\" + Krotka_nazwa_CF + "_temp.txt"
        pelna_sciezka_nowy_TXT2 = sciezka_CF + "\\" + Krotka_nazwa_CF + ".txt"
        pelna_sciezka_nowy_PNG = sciezka_CF + "\\" + Krotka_nazwa_CF + ".png"
        pelna_sciezka_nowy_CF = sciezka_CF + "\\" + Krotka_nazwa_CF + "_nowy.cf"
        
        #zapis
        if args.write:
                #header = '\x00\x01\x06\x11\x0D\x10'
                header = '\x00\x01\x04\x0C\x09\x0B'
                nowy_TXT2 = open(pelna_sciezka_nowy_TXT2, 'rt')
                nowy_CF = open(pelna_sciezka_nowy_CF, 'wb+')
                
                liczba_linijek  = sum(1 for line in open(pelna_sciezka_nowy_TXT2))
                i = 0
                print str(liczba_linijek) + ' znakow.'
                zbior_znakow = ''
                rozmiar_tab_znakow = 0
                tab_var = []
                tab_x = []
                tab_y = []
                tab_szer = []
                tab_wys = []
                while i < liczba_linijek:
                        linijka = nowy_TXT2.readline()
                        znak = linijka.split(', ')[0]
                        var = linijka.split(', ')[1].split('=')[1]
                        x = linijka.split(', ')[2].split('=')[1]
                        y = linijka.split(', ')[3].split('=')[1]
                        szer = linijka.split(', ')[4].split('=')[1]
                        wys = linijka.split(', ')[5].split('=')[1]
                        tab_var.append(var)
                        tab_x.append(x)
                        tab_y.append(y)
                        tab_szer.append(szer)
                        tab_wys.append(wys)
                        zbior_znakow += znak
                        rozmiar_tab_znakow += len(znak)
                        i += 1
                
                print rozmiar_tab_znakow
                nowy_CF.write(header)
                nowy_CF.write(struct.pack('>h', rozmiar_tab_znakow))
                nowy_CF.write(zbior_znakow)
                nowy_CF.write('\x00')
                
                j = 0
                for j in range( liczba_linijek):
                        nowy_CF.write(struct.pack('c', str(unichr(int(tab_var[j])))))
                        nowy_CF.write(struct.pack('>h', int(tab_x[j])))
                        nowy_CF.write(struct.pack('>h', int(tab_y[j])))
                        nowy_CF.write(struct.pack('c', str(unichr(int(tab_szer[j])))))
                        nowy_CF.write(struct.pack('c', str(unichr(int(tab_wys[j])))))
                        j += 1
                nowy_CF.write('\x00')
                
                nowy_PNG = open(pelna_sciezka_nowy_PNG, 'rb')
                dane_PNG = nowy_PNG.read()
                rozmiar_PNG = len(dane_PNG)
                nowy_CF.write(struct.pack('>h', int(rozmiar_PNG)))
                nowy_CF.write(dane_PNG)
                
                nowy_PNG.close()
                nowy_CF.close()
                nowy_TXT2.close()
                print "File write completed successfully."
        
        #wypakowanie do TXT
        else:        
                plik_CF = open(pelna_sciezka_do_CF, 'rb')
                nowy_TXT = open(pelna_sciezka_nowy_TXT, 'wb+')
                nowy_TXT2 = open(pelna_sciezka_nowy_TXT2, 'wb+')
                nowy_PNG = open(pelna_sciezka_nowy_PNG, 'wb+')
                plik_CF.read(6) #magic
                wielkosc_tablicy = struct.unpack('>i', '\x00\x00' + plik_CF.read(2))[0]
                
                licznik_znakow = 0
                i = 0
                while i < wielkosc_tablicy:
                        znak = plik_CF.read(1)
                        znak3 = struct.pack('c', znak)

                        if znak3 == '\xC3' or znak == '\xC2':
                                znak += plik_CF.read(1)
                                wielkosc_tablicy -= 1
                                nowy_TXT.write(str(znak))
                                #print znak
                        else:
                                znak2 = struct.unpack('c', znak)[0]
                                nowy_TXT.write(str(znak2))
                                #print znak2
                        
                        
                        nowy_TXT.write('\x0D\x0A')
                        
                        licznik_znakow += 1
                        i += 1
                        
                i = 0
                plik_CF.read(1)
                nowy_TXT.seek(0)
                while i < licznik_znakow:
                        bajt = struct.unpack('>i', '\x00\x00\x00' + plik_CF.read(1))[0]
                        x = struct.unpack('>h', plik_CF.read(2))[0]
                        y = struct.unpack('>h', plik_CF.read(2))[0]
                        szerokosc = struct.unpack('>i', '\x00\x00\x00' + plik_CF.read(1))[0]
                        wysokosc = struct.unpack('>i', '\x00\x00\x00' + plik_CF.read(1))[0]
                        linijka = nowy_TXT.readline().split('\x0D')[0]
                        linijka = linijka + ', var=' + str(bajt) + ', x=' + str(x) + ', y=' + str(y) + \
                        ', szerokosc=' + str(szerokosc) + ', wysokosc=' + str(wysokosc) + '\x0D\x0A'
                        nowy_TXT2.write(str(linijka))
                        i += 1
                                
                plik_CF.read(1) # '\x00'
                rozmiar_PNG = struct.unpack('>h', plik_CF.read(2))[0]
                PNG = plik_CF.read(rozmiar_PNG)
                nowy_PNG.write(PNG)
                
                
                nowy_TXT.close()
                os.remove(pelna_sciezka_nowy_TXT)
                nowy_TXT2.close()
                plik_CF.close()
                nowy_PNG.close()
                print str(licznik_znakow) + ' znakow'
                print "File read completed successully."