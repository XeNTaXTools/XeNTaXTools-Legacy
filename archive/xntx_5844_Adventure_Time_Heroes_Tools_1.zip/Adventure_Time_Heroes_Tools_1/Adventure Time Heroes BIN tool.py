# -*- coding: utf-8 -*-


#This tool was made by Ikskoks for Xentax community.
#Please don't copy this tool to other forums and sites.

#If you like my tool, please consider visit my fanpage https://www.facebook.com/ikskoks/ and site http://ikskoks.pl/


import argparse
import os
import sys
import time
import struct
import binascii
import re

if len(sys.argv)<2:
        print "ikskoks's Adventure time: Heroes of Ooo BIN tool"
        print "Usage: <my_tool.py> file.bin        "
        print "       <my_tool.py> --write file.bin"
        print "       <my_tool.py> --help          "
        
else:        
        parser = argparse.ArgumentParser()
        parser.add_argument('--write', help="Save to BIN file", required=False, action="store_true")
        parser.add_argument("plik_BIN", help="Path to BIN file")
        args = parser.parse_args()
        
        (sciezka_BIN, nazwa_BIN) = os.path.split(args.plik_BIN)
        (Krotka_nazwa_BIN, extension) = os.path.splitext(nazwa_BIN) 
        pelna_sciezka_do_BIN = args.plik_BIN    
        pelna_sciezka_listy_plikow = sciezka_BIN + "\\" + Krotka_nazwa_BIN + "\\" + Krotka_nazwa_BIN + "_lista.txt"
        pelna_sciezka_nowy_BIN = sciezka_BIN + "\\" + Krotka_nazwa_BIN.split('_skrypt')[0]  + "_nowy.bin"
        
        if args.write:
                if Krotka_nazwa_BIN == "boss0" or Krotka_nazwa_BIN == "boss1" or Krotka_nazwa_BIN == "boss2" or Krotka_nazwa_BIN == "boss3" or Krotka_nazwa_BIN == "overworld" or Krotka_nazwa_BIN == "preload" or Krotka_nazwa_BIN == "res-chars" or Krotka_nazwa_BIN == "res-common" or Krotka_nazwa_BIN == "res-finn" or Krotka_nazwa_BIN == "ui":
                        png = 1
                else:
                        png = 0
                if png == 1:                
                        #zapis dla PNG
                        lista = open(pelna_sciezka_listy_plikow, 'rt')
                        nowy_BIN = open(pelna_sciezka_nowy_BIN, 'wb+')
                        liczba_plikow  = sum(1 for line in open(pelna_sciezka_listy_plikow))
                        lista.seek(0)
                        
                        for i in range(liczba_plikow):
                                sciezka = lista.readline().split('\x0A')[0] 
                                czytany_plik = open(os.path.abspath(sciezka), 'rb')
                                rozmiar_czytanego_pliku = os.path.getsize(os.path.abspath(sciezka))
                                nowy_BIN.write(struct.Struct(">l").pack(rozmiar_czytanego_pliku))
                                nowy_BIN.write(czytany_plik.read())
                                
                        print pelna_sciezka_nowy_BIN
                        
                else:
                        #zapis dla TXT
                        nowy_BIN = open(pelna_sciezka_nowy_BIN, 'wb+')
                        nazwa_skryptu = Krotka_nazwa_BIN + ".txt"
                        sciezka_skryptu_wyjsciowego = sciezka_BIN + "\\" + nazwa_skryptu.split('.txt')[0] + '_skrypt.txt'
                        skrypt = open(sciezka_skryptu_wyjsciowego, 'rt')
                        liczba_stringow  = sum(1 for line in open(sciezka_skryptu_wyjsciowego))
                        nowy_BIN.write(struct.Struct(">l").pack(liczba_stringow))
                        
                        for i in range(liczba_stringow):
                                string = skrypt.readline().split('\x0A')[0]
                                dlugosc_stringu = struct.pack('>h', int(len(string)))
                                nowy_BIN.write(dlugosc_stringu + string)

                        print pelna_sciezka_nowy_BIN

        
        else:
                if Krotka_nazwa_BIN == "boss0" or Krotka_nazwa_BIN == "boss1" or Krotka_nazwa_BIN == "boss2" or Krotka_nazwa_BIN == "boss3" or Krotka_nazwa_BIN == "overworld" or Krotka_nazwa_BIN == "preload" or Krotka_nazwa_BIN == "res-chars" or Krotka_nazwa_BIN == "res-common" or Krotka_nazwa_BIN == "res-finn" or Krotka_nazwa_BIN == "ui":
                        png = 1
                else:
                        png = 0
                if png == 1:
                        #odczyt dla PNG
                        sciezka_kontrolna = sciezka_BIN + "\\" + Krotka_nazwa_BIN
                        if not os.path.isdir(sciezka_kontrolna):  
                                os.makedirs(sciezka_kontrolna)                          
                        plik_BIN = open(pelna_sciezka_do_BIN, 'rb')
                        lista = open(pelna_sciezka_listy_plikow, 'wt+')
                        rozmiar_archiwum = os.path.getsize(os.path.abspath(pelna_sciezka_do_BIN))
                        suma_rozmiarow = 0
                        i = "1"
                        while 1:
                                i = str(i)
                                rozmiar_PNG = struct.unpack('>i', plik_BIN.read(4))[0]
                                czytany_plik = plik_BIN.read(rozmiar_PNG)
                                nazwa_pliku = "plik_" + i.zfill(3) + ".png"
                                sciezka_pliku_wyjsciowego = sciezka_BIN + "\\" + Krotka_nazwa_BIN + "\\" + nazwa_pliku
                                i = int(i)
                                i += 1

                                with open(sciezka_pliku_wyjsciowego, 'wb+') as plik_wyjsciowy: 
                                        plik_wyjsciowy.write(czytany_plik) 
                                print sciezka_pliku_wyjsciowego
                                suma_rozmiarow += (rozmiar_PNG+4)
                                lista.write(sciezka_pliku_wyjsciowego + '\n')
                                if suma_rozmiarow >= rozmiar_archiwum:
                                        break
                                
                else:
                        #odczyt dla TXT
                        plik_BIN = open(pelna_sciezka_do_BIN, 'rb')
                        ilosc_stringow = struct.unpack('>i', plik_BIN.read(4))[0]
                        
                        nazwa_skryptu = Krotka_nazwa_BIN + "_skrypt.txt"
                        sciezka_skryptu_wyjsciowego = sciezka_BIN + "\\" + nazwa_skryptu  
                        sciezka_kontrolna = sciezka_BIN + "\\" + Krotka_nazwa_BIN
                        if not os.path.isdir(sciezka_kontrolna):  
                                os.makedirs(sciezka_kontrolna)                          
                        zapisywany_skrypt = open(sciezka_skryptu_wyjsciowego, 'wb+')
                        for i in range(ilosc_stringow):
                                dlugosc_stringu = struct.unpack('>i', '\x00\x00' + plik_BIN.read(2))[0]
                                czytany_string = plik_BIN.read(int(dlugosc_stringu))
                                zapisywany_skrypt.write(czytany_string)
                                zapisywany_skrypt.write('\n')
                        print sciezka_skryptu_wyjsciowego
                                                           