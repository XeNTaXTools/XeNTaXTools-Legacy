#by Durik256
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("S.W.A.T. Target Liberty", ".dob")
    noesis.setHandlerTypeCheck(handle, CheckType)
    noesis.setHandlerLoadModel(handle, LoadModel)
    return 1

def CheckType(data):
    if data[:4] != b'\x7B\x00\x00\x00':
        return 0
    return 1

def LoadModel(data, mdlList):
    bs = NoeBitStream(data)
    ctx = rapi.rpgCreateContext()
    
    #0-magic;1-numMt;2-objOfs;3-numObj;4..-unk
    h = bs.read('12I')
    bs.seek(h[2])
    
    for x in range(h[3]):
        bs.seek(2,1)
        name = noeAsciiFromBytes(bs.read(8))
        rapi.rpgSetName(name)
        inf = bs.read('10b')#0-idMt
        vnum = bs.readShort()
        bs.seek(26,1)
        vofs = bs.readInt()
        curPos = bs.getOffset()
        bs.seek(vofs)
        print(vnum, vofs, inf)
        
        stride = 22 if inf[1] else 14
        buf = bs.read(vnum*stride)
        rapi.rpgBindPositionBufferOfs(buf, noesis.RPGEODATA_SHORT, stride, stride-6)#16
        if stride > 14:
            rapi.rpgBindUV1BufferOfs(buf, noesis.RPGEODATA_SHORT, stride, 8)
            rapi.rpgSetUVScaleBias(NoeVec3([64]*3),None)
        
        rapi.rpgCommitTriangles(None, noesis.RPGEODATA_USHORT, vnum, noesis.RPGEO_TRIANGLE_STRIP)
        bs.seek(curPos)
    
    rapi.rpgSetOption(noesis.RPGOPT_TRIWINDBACKWARD, 1)
    mdl = rapi.rpgConstructModel()
    mdl.setModelMaterials(NoeModelMaterials([], [NoeMaterial('default','')]))
    mdlList.append(mdl)
    rapi.setPreviewOption("setAngOfs", "0 180 0")
    return 1