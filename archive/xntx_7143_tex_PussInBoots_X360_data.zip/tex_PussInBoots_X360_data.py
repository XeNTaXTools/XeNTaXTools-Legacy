from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Puss in Boots [X360]", ".data")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
	#noesis.logPopup()
	return 1

def noepyCheckType(data):
    return 1
	
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    headerFileName = rapi.getExtensionlessName(rapi.getInputName())
    print(headerFileName)
    bs2 = NoeBitStream(rapi.loadIntoByteArray(headerFileName), NOE_BIGENDIAN)
    bs2.seek(0x24, NOESEEK_ABS)
    imgWidth = bs2.readUShort()
    imgHeight = bs2.readUShort()
    print(imgWidth, "x", imgHeight)
    imgFmt = bs2.readUShort() 
    print(imgFmt, ":format")
    bs2.seek(0x4c, NOESEEK_ABS)
    datasize = bs2.readUInt()
    print(datasize, ":data size")
    data = bs.readBytes(datasize)
    if imgWidth < 128:
        imgWidth = 128
    if imgHeight < 128:      
        imgHeight = 128
    #DXT1
    if imgFmt == 0x12:
        data = rapi.swapEndianArray(data, 2)
        texFmt = noesis.NOESISTEX_DXT1
    #DXT5
    elif imgFmt == 0x16:
        data = rapi.swapEndianArray(data, 2)
        texFmt = noesis.NOESISTEX_DXT5
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1