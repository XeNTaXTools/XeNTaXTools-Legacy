===============================================================================================================================================
GFPK Unpack (A complete extractor for Dragona and Queens Blade MMO games)
Copyright (C) 2015 Lukáš Kužel (Lukas Cone)
The author is not responsible for the consequences of use of this software, no matter how awful, even if they arise from flaws in it.
The tool is released exclusively for XeNTaX or authors own websites.
================================================================================================================================================

Usage GFPKUnpack.exe [OPTIONS] filename
OPTIONS
  -dragona  Use for Dragona files
  -vm Verify Mode, doesn't write files
  -ow Overwrite file if exists
  -help Shows this Help

Main thanks goes to h4x0r from Progamercity.net forum for getting decryption keys for both games.