from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Marc Ecko's Getting Up", ".st")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
	#noesis.logPopup()
	return 1

#check if it's this type based on the data
def noepyCheckType(data):
    bs = NoeBitStream(data)
    Magic = bs.readBytes(4).decode("ASCII")
    if Magic != 'ST\x00\x00':
        return 0
    return 1
	
def noepyLoadRGBA(data, texList):
    datasize = len(data) - 0x184        
    bs = NoeBitStream(data)
    bs.seek(0x08, NOESEEK_ABS)
    imgFmt = bs.readInt()
    imgWidth = bs.readInt()            
    imgHeight = bs.readInt()           
    bs.seek(0x184, NOESEEK_ABS)        
    data = bs.readBytes(datasize)      
    #DXT1
    if imgFmt == 3:
        texFmt = noesis.NOESISTEX_DXT1
        print("using dxt1")
    #DXT5
    elif imgFmt == 4:
        texFmt = noesis.NOESISTEX_DXT5
        print("using dxt5")
    #unknown, not handled
    else:
        print("WARNING: Unhandled image format")
        return None
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1