This is a tool to extract files from abes oddysee and abes exodus writen by Paul M.
To use this tool you must put the .lvl file in the same directory as the extractor.exe and extractor.bat, then right click extractor.bat and go to edit. Finaly change "s1.lvl" to the name of the .lvl file you are trying to extract then just run the .bat file and the files will be extracted to the current directory.

Disclamier:
This software is provided "as is" and I will not be responsible for any damanges caused by direct or indirect use of this software, by using the software you are agreeing to these terms.