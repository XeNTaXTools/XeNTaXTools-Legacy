# NASCAR Revolution SE "OBJ" to OBJ Converter by Bigchillghost
from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("NASCAR Revolution SE", ".obj")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadModel(handle, noepyLoadModel)
	#noesis.logPopup()
	return 1

#check if it's this type based on the data
def noepyCheckType(data):
	if len(data) < 0x80:
		return 0
	bs = NoeBitStream(data)
	bs.seek(5, NOESEEK_REL)
	if bs.readByte() == 0:
		return 1
	return 0

#load the model
def noepyLoadModel(data, mdlList):
	#noesis.logPopup()
	bs = NoeBitStream(data)
	Vcount = bs.readUShort()
	FaceCount = bs.readUShort()
	bs.seek(4, NOESEEK_REL)
	VertOffset = bs.readInt()
	FaceOffset = bs.readInt()
	bs.seek(VertOffset, NOESEEK_ABS)
	AsciiFile = NoeBitStream()
	AsciiFile.writeString('# Wavefront OBJ\n\n', 0)
	for i in range(0, Vcount):
		x = bs.readShort() / 100.0
		y = bs.readShort() / 100.0
		z = bs.readShort() / 100.0
		AsciiFile.writeString('v %f %f %f\n'%(x,y,z), 0)
	AsciiFile.writeString('# %d vertices\n\n'%Vcount, 0)
	bs.seek(FaceOffset, NOESEEK_ABS)
	idxList = []
	for i in range(0, FaceCount):
		bs.seek(2, NOESEEK_REL)
		for j in range(0, 4):
			idxList.append(bs.readUShort())
		bs.seek(2, NOESEEK_REL)
		for j in range(0, 4):
			u = bs.readUByte() / 255.0
			v = bs.readUByte() / 255.0
			AsciiFile.writeString('vt %f %f\n'%(u,v), 0)
		bs.seek(4, NOESEEK_REL)
	AsciiFile.writeString('# %d texture coordinates\n\n'%(FaceCount*4), 0)
	
	srcName = rapi.getInputName()
	AsciiFile.writeString('g %s\n'%rapi.getExtensionlessName(rapi.getLocalFileName(srcName)), 0)
	idx = 0
	for i in range(0, FaceCount):
		AsciiFile.writeString('f ', 0)
		for j in range(0, 4):
			AsciiFile.writeString('%d/%d '%(idxList[idx]+1,idx+1), 0)
			idx += 1
		AsciiFile.writeString('\n', 0)
	AsciiFile.writeString('# %d polygons\n'%FaceCount, 0)
	outName = srcName.replace(".", "_Conv.")
	ObjFile = open(outName, "wb")
	ObjFile.write(AsciiFile.getBuffer())
	ObjFile.close()
	noesis.openFile(outName)
	return 1
