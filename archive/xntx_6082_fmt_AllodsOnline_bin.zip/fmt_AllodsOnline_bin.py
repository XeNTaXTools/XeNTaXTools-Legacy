from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Allods Online (geometry)", ".bin")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    modelfileName = rapi.getLocalFileName(rapi.getInputName())
    #print(modelfileName)
    if "(Geometry)_decomp" not in modelfileName:
        return 0
    return 1

def noepyLoadModel(data, mdlList):
    ctx = rapi.rpgCreateContext()
    rapi.setPreviewOption("setAngOfs","0 -90 0")  #set the default preview angle        
    bs = NoeBitStream(data)
    fileName = rapi.getLocalFileName(rapi.getInputName()).split(".")
    rapi.rpgSetName(str(fileName[0]))
    sectionNum0 = bs.readUInt()
    vBuffer = bs.readUInt()
    VBuf = bs.readBytes(vBuffer)
    sectionNum1 = bs.readUInt()
    fBuffer = bs.readUInt()
    FCount = fBuffer // 2 
    mylist = []
    tmp = bs.tell()
    for i in range(FCount):
        i = bs.readUShort()                
        mylist.append(i)
    VCount = max(mylist) + 1 
    VBytes = vBuffer // VCount
    bs.seek(tmp + 1, NOESEEK_ABS)
    myString = bs.readBytes(bs.getSize() - bs.tell())
    myIndex = myString.find(b'\x00\x00\x01\x00\x02\x00') 
    bs.seek(myIndex + tmp + 1, NOESEEK_ABS)
    tmp2 = bs.tell()
    LOD0_FCount = (tmp2 - tmp) // 2
    bs.seek(tmp, NOESEEK_ABS)
    IBuf = bs.readBytes(LOD0_FCount * 2) 
    rapi.rpgBindPositionBufferOfs(VBuf, noesis.RPGEODATA_FLOAT, VBytes, 0)   
    rapi.rpgBindUV1BufferOfs(VBuf, noesis.RPGEODATA_FLOAT, VBytes, 12)     
    if LOD0_FCount % 3 == 0:
        rapi.rpgCommitTriangles(IBuf, noesis.RPGEODATA_SHORT, LOD0_FCount, noesis.RPGEO_TRIANGLE, 1)
    else:
        rapi.rpgCommitTriangles(IBuf, noesis.RPGEODATA_SHORT, LOD0_FCount, noesis.RPGEO_TRIANGLE_STRIP, 1)
    mdlList.append(rapi.rpgConstructModel())
    rapi.rpgClearBufferBinds()
    return 1