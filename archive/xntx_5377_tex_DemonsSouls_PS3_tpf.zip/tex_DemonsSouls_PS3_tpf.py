﻿from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Demon's Souls (PS3)", ".tpf")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadDDS)
    #noesis.logPopup()
    return 1
		
def noepyCheckType(data):
    bs = NoeBitStream(data)
    Magic = bs.readBytes(4).decode("ASCII")
    if Magic != 'TPF\x00':
        return 0
    return 1

def noepyLoadDDS(data, texList):
    bs = NoeBitStream(data)
    magic = bs.readBytes(4).decode("ASCII")
    bs.setEndian(NOE_BIGENDIAN)
    skip = bs.readUShort()
    skip = bs.readUShort()
    numTexs = bs.readUInt()
    print(numTexs, "numTexs")
    skip = bs.readUByte()
    skip = bs.readUByte()
    skip = bs.readUByte()
    skip = bs.readUByte()
    for i in range(numTexs):
        dataOff = bs.readUInt()
        ddsSize = bs.readUInt() 
        imgFmt = bs.readUByte()
        print(imgFmt, "imgFmt")
        skip = bs.readUByte()
        skip = bs.readUShort()
        imgWidth = bs.readUShort()
        imgHeight = bs.readUShort()
        skip = bs.readUInt()
        skip = bs.readUInt()
        texNameOff = bs.readUInt()
        skip = bs.readUInt()
        tmp = bs.tell()
        bs.seek(texNameOff, NOESEEK_ABS)
        texName = bs.readString()
        bs.seek(dataOff, NOESEEK_ABS)
        data = bs.readBytes(ddsSize)	 
        #DXT1
        if imgFmt == 0 or imgFmt == 1:
            texFmt = noesis.NOESISTEX_DXT1
        #DXT3
        #if imgFmt == 1:
        #    texFmt = noesis.NOESISTEX_DXT3
        #DXT5
        if imgFmt == 5:
            texFmt = noesis.NOESISTEX_DXT5
        texList.append(NoeTexture(texName, imgWidth, imgHeight, data, texFmt))
        bs.seek(tmp, NOESEEK_ABS)
    return 1	