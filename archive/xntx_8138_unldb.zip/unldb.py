import sys
from struct import unpack
from dataclasses import dataclass


@dataclass
class Face:
    offset: int
    count: int
    val3: int
    sub_mesh: int
    normal: (float, float, float)
    vec1: (float, float, float)


@dataclass()
class Triangle2:
    normal: (float, float, float)
    vec1: (float, float, float)
    face_offset: int
    face_count: int
    val3: int
    val4: int
    val5: int
    val6: int


@dataclass()
class Unk1:
    index: int
    unk_pair: (str, str)


@dataclass()
class Unk2:
    unk_pair: (str, str)
    unk_id: int


@dataclass()
class Texture:
    texture_name: str
    texture_variants: []


@dataclass()
class TextureVariant:
    texture_file: str
    texture_path: str
    alpha_texture_path: str
    alpha: bool


class ElementReader:
    def __init__(self):
        self.f = open(sys.argv[1], "rb")

    def set_list_lambda(self, list_lambda):
        self.list_lambda = list_lambda

    def read_element(self):
        t = unpack('b', self.f.read(1))[0]
        if t == 0x0D:
            string_length = self.read_element()
            return unpack("<" + str(string_length) + "s", self.f.read(string_length))[0].decode('ascii')
        elif t == 0x0E:
            b = unpack("B", self.f.read(1))[0]
            return bool(b)
        elif t == 0x11:
            type = unpack("B", self.f.read(1))[0]
            data_size = self.read_element()
            return self.f.read(data_size)
        elif t == 0x12:
            data = unpack('BBB', self.f.read(3))
            return int.from_bytes(data, 'little')
        elif t == 0x13:
            return unpack('h', self.f.read(2))[0]
        elif t == 0x14:
            return unpack('b', self.f.read(1))[0]
        elif t == 0x16:
            return unpack('fff', self.f.read(12))
        elif t == 0x1c:
            num_elements = self.read_element()
            elements = []
            for i in range(num_elements):
                elements.append(self.list_lambda())
            return elements
        elif t == 0x1f:
            num_elements = self.read_element()
            elements = []
            for i in range(num_elements):
                elements.append(self.list_lambda())
            return elements
        elif t == 0x25:
            key = self.read_element()
            value = self.read_element()
            return (key, value)
        else:
            raise Exception("Invalid element")


def read_vec3():
    return ldb.read_element()


def read_triangle():
    t = Face(
        ldb.read_element(),
        ldb.read_element(),
        ldb.read_element(),
        ldb.read_element(),
        ldb.read_element(),
        ldb.read_element()
    )
    return t


def read_triangle2():
    t = Triangle2(
        ldb.read_element(),
        ldb.read_element(),
        ldb.read_element(),
        ldb.read_element(),
        ldb.read_element(),
        ldb.read_element(),
        ldb.read_element(),
        ldb.read_element()
    )
    return t


def read_index():
    return ldb.read_element()


def read_unk1():
    return Unk1(
        ldb.read_element(),
        ldb.read_element()
    )


def read_unk2():
    return Unk2(
        ldb.read_element(),
        ldb.read_element()
    )


ldb = ElementReader()

ldb.set_list_lambda(read_vec3)
position_list = ldb.read_element()
ldb.set_list_lambda(read_triangle)
face_list = ldb.read_element()
ldb.set_list_lambda(read_triangle2)
triangle2_list = ldb.read_element()
ldb.set_list_lambda(read_index)
index_list = ldb.read_element()

unknown = ldb.read_element()  # Always 32?
num_images = ldb.read_element()

for i in range(num_images):
    file_name = ldb.read_element()
    file_data = ldb.read_element()

    fout = open(file_name, "wb")
    fout.write(file_data)
    fout.close()
    print(file_name)

ldb.set_list_lambda(read_unk1)
unk_map1 = ldb.read_element()
print("----")
ldb.set_list_lambda(read_unk2)
unk_map2 = ldb.read_element()

num_textures = ldb.read_element()
textures = []
for i in range(num_textures):
    texture_name = ldb.read_element()
    num_variants = ldb.read_element()
    variants = []
    for j in range(num_variants):
        tex1 = ldb.read_element()
        tex2 = ldb.read_element()
        tex3 = ldb.read_element()
        has_alpha = ldb.read_element()
        b2 = ldb.read_element()
        variant = TextureVariant(tex1, tex2, tex3, has_alpha)
        variants.append(variant)

    textures.append(Texture(texture_name, variants))

count1 = ldb.read_element()
for i in range(count1):
    index = ldb.read_element()
    unk_data = ldb.read_element()

print("We are at " + hex(ldb.f.tell()))

num_points = ldb.read_element()
for i in range(num_points):
    exit1 = ldb.read_element()
    print(exit1)




print("We are at " + hex(ldb.f.tell()))

max_image = 0
for triangle2 in triangle2_list:
    max_image = max(triangle2.val5, max_image)

fobj = open(sys.argv[1] + ".obj", "w")

for position in position_list:
    fobj.write("v %f %f %f\n" % position)

for face in face_list:
    indices = range(face.offset + 1, face.offset + face.count + 1)
    fobj.write("f")
    for index in indices:
        fobj.write(" %d" % index)
    fobj.write("\n")



fobj.close()
