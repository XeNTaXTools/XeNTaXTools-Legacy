#include <iostream>
using namespace std;
#include <fstream>
//#include <cstdlib>

// Returns true if file name is found.
bool getFileName(ifstream &fin, char* name)
{
	fin.getline(name, 256, 0x00);
	if(name[0] == 0x00)
		return false;

	cout << "\tExtracting: " << name << endl;

	for(int i = 0; i < 256; i++)
		if(name[i] == '.')
		{
			name[i+1]=toupper(name[i+1]);
			name[i+2]=toupper(name[i+2]);
			name[i+3]=toupper(name[i+3]);
		}
	return true;
}

bool extractFile(ifstream &fin)
{
	// Find the file name
	char name[256];
	if(!getFileName(fin, name))
		return false;

	ofstream fout(name, ofstream::binary);

	char byte = fin.get();
	int count = 0;
	int size = 100;
	unsigned char size_byte[4];

	while(!fin.eof())
	{
		if(byte == 0x02)
		{
			count=0;

			while(!fin.eof())
			{
				if(count == 4)
				{
					count+=4;
					fout.put(size_byte[0] = byte);
					fout.put(size_byte[1] = fin.get());
					fout.put(size_byte[2] = fin.get());
					fout.put(size_byte[3] = fin.get());
					size = size_byte[3]*0x1000000 +
							size_byte[2]*0x10000 +
							size_byte[1]*0x100 +
							size_byte[0];
					cout << "\tFilesize: " << size << endl;
				}
				else
				{
					count++;
					fout.put(byte);
					if(count == size)
					{
						fout.close();
						return true;
					}
				}
				byte = fin.get();
			}
		}
		byte = fin.get();
	}

	fout.close();
	return true;
}

// Takes in a file name(s) on the command line,
int main(int argc, char* args[])
{
	int filesExtracted = 0;
	for(int i = 0; i < argc-1; i++)
	{
		cout << "Extracting files from " << args[i+1] << endl;

		ifstream fin(args[i+1], ifstream::binary);

		while(extractFile(fin))
			filesExtracted++;

		fin.close();
	}
	cout << filesExtracted << " files extracted from " << argc - 1 << " BIN files.\n";
	return 0;
}