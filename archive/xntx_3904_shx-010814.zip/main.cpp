/*
    main.cpp --
    Data extractor for Silent Hill (PlayStation)

    Legal:

    Based on the original program "SHFilesExtractor", (C) 2010 HoRRoR (www.consolegames.ru)
    This program (C) 2014 Charles MacDonald (cgfm2.emuviews.com)
    No license (copyleft), but please credit the authors in any derivative works.

    Functions:

    view <exefile>                                  View file system information (written to stdout).
    extract <exefile> <datafile> <output_dir>       Write file system contents to output directory.
    unused <exefile> <datafile> <output_file>       Write all unused data concatenated to a single file.

    For the US version of the game, exefile is "SLUS_007.07" and the datafile is "SILENT".

    Example use:

    shx view slus_007.07

    View file system, results printed to stdout.

    shx extract slus_007.07 silent gamedata

    Extract all data in the SILENT file to the 'gamedata' directory.

    shx unused slus_007.07 silent unused.bin

    Extract all unused data from the SILENT file to the file 'unused.bin'.

    Limitations:

    Cannot extract movies. These are actually stored in the HILL file.

    Movie files are listed with an extension of ".str" as a matter of
    convenience, but they have no extension defined in the file system.

    Technical information

    The game executable stores a list of file names, file sizes, and offsets
    to the file from sector 0 of the game disc.

    A correction factor is used to adjust this offset to be relative to the
    start of the SILENT data file rather than the disc.

    The file names are stored as eight 6-bit characters referenced from
    zero, concatenated together. To convert to ASCII, split each 6-bit
    value up and add 0x20.

    The directory path and file extension are stored as 4-bit codes that
    index a list stored at the end of the executable.

    The parse_file_system() function shows how data can be extracted
    depending on the new or old file system format.

    File sizes are in multiples of 0x100 bytes.
    File offsets are in multiples of 0x800 bytes.

    Since files must start on a 2K boundary and have a size that must be a
    multiple of 256 bytes, files that do not meet these criteria will
    contain garbage data either at the end of the file (to pad it to 256
    bytes) or between files (to advance to the next 2K boundary).

    The disk-image-building software KCET used during development did not
    clear out empty space between files. As a result this garbage consists
    of file data that was present at that location as the file structure
    changed. If earlier files were made smaller or larger, or added or
    removed, everything afterwards was shifted backwards or forwards in
    the disk image by a number of sectors.

    The "unused" function scans the filesystem for this unaccounted
    data at the end of files and between files and concatenates it into a
    single binary dump. While it may be possible to extract valid data
    files from this dump, the majority of it are simply fragments
    of existing files or earlier files used in development.

    Other versions of the game can be added by:

    - Describing the game in the "game_info" structure.
    - Adding a case to the 'parse_file_system' function.

*/

#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <io.h>
#include <string>
#include <vector>
#include <list>
#include <iostream>
using namespace std;

#define DEBUG   0

typedef unsigned char uint8;
typedef unsigned short int uint16;
typedef unsigned long int uint32;

/* Game vesions */
enum game_versions
{
    VER_US_FULL =   0,
    VER_JP_FULL,
    VER_EU_FULL,
    VER_US_PSMG,
    VER_US_DEMO,
    VER_JP_DEMO,
    VER_EU_DEMO,
    VER_UNKNOWN,
};

/* Game specific data */
typedef struct
{
    char *exe_name;     /* EXE filename */
    int version;        /* Game version */
    int sector_base;    /* Correction factor to convert absolute sector offsets to SILENT/WKS.XE data file offsets */
    int parts_base;     /* Offset in EXE to directory and extension parts */
    int directory_base; /* Offset in EXE to directory */
    int file_count;     /* Total files */
} game_info_rec;

/* Record to hold decoded file system data */
class file_sys_rec
{
public:
    char *name;
    uint8 dir_code;
    uint8 ext_code;
    char *path;
    int offset;
    int size;
    int raw_offset;
};

/* Raw file system parameters */
typedef struct
{
    uint32 a;
    uint32 b;
    uint32 c;
} file_rec;

/*----------------------------------------------------------------------------*/

/* Class to encapsulate file system and file system management functions */
class shfs
{
public:
    char *exe_path;
    uint8 *exe_data;
    int exe_size;
    bool verbose;
    const game_info_rec *gip;
    
    vector<string> parts_dir;
    vector<string> parts_ext;
    vector<file_sys_rec*> file_sys;

    shfs()
    {
        verbose = false;
        gip = NULL;
        exe_path = NULL;
        exe_data = NULL;
        exe_size = 0;
    }

    ~shfs()
    {
        /* Deallocate records */
        for(int i = 0; i < file_sys.size(); i++)
        {
            if(exe_data)
            {
                delete[] exe_data;
                exe_data = NULL;
            }
            
            if(file_sys[i] != NULL)
            {
                delete file_sys[i];
                file_sys[i] = NULL;
            }
        }
    }

    /* Function prototypes */
    bool load_exe(char *path);
    bool parse_file_system(void);
    void extract_path_parts(void);
    const char *get_part(vector<string> &src, int index);
    const char *get_dir(int index);
    const char *get_ext(int index);
    
};

/*----------------------------------------------------------------------------*/

/* Function prototypes */
static bool load_file(const char *path, uint8* &buffer, int &size);
static int file_size(const char *path);
static bool dir_exists(const char *path);
static bool file_exists(const char *path);

/*----------------------------------------------------------------------------*/
/* Game specific data                                                         */
/*----------------------------------------------------------------------------*/

/*
   Other versions to support:
  
   SLPM-86498, 2000/04/27, Japan (Konami The Best re-issue)
   SLPM-87029, 2001/01/24, Japan (PSone Books)
   SLES-01414-P, Europe (re-issue)
   SLUS-80707, ???, Silent Hill Trade Demo
  
   Note:

   Official U.S. PlayStation Magazine Demo Disc #15 only contains movie footage 
   of Silent Hill, there is no playable demo.
*/
static const game_info_rec game_info[] = 
{                                                                    /* Timestamp on EXE */
    {"slus_007.07", VER_US_FULL, 0x20000, 0x132CC, 0x0B850, 0x0818}, /* 01/21/1999 : US, Full Game (SLUS-00707) */
    {"slpm_861.92", VER_JP_FULL, 0x20000, 0x133B0, 0x0B91C, 0x081A}, /* 01/25/1999 : JP, Full Game (SLPM-86192) */
    {"sles_015.14", VER_EU_FULL, 0x20800, 0x13EB4, 0x0B8FC, 0x0906}, /* 06/06/1999 : EU, Full Game (SLES-01514)*/
    {"sh.exe",      VER_US_PSMG, 0x1B800, 0x0EBFC, 0x0AA90, 0x0376}, /* 10/18/1998 : Official U.S. PlayStation Magazine Demo Disc #16 (SCUS-94278) */
    {"slus_900.50", VER_US_DEMO, 0x1C000, 0x0F730, 0x0B648, 0x0351}, /* 01/15/1999 : US, Trial (Demo) Game (SLUS-90050) */
    {"slpm_803.63", VER_JP_DEMO, 0x1C800, 0x0F884, 0x0B780, 0x0351}, /* 11/05/1998 : JP, Trial (Demo) Game (SLPM-80363) */
    {"sled_017.35", VER_EU_DEMO, 0x1C000, 0x0F73C, 0x0B648, 0x0352}, /* 12/15/1998 : EU, Trial (Demo) Game (SLED-01735) */
    {NULL         , VER_UNKNOWN, 0      , 0      , 0      , 0},
};


static const char *prg_name = "shx";

/*----------------------------------------------------------------------------*/
/* Support functions                                                          */
/*----------------------------------------------------------------------------*/

/*
    HoRRoR's name decode routine.
    Used in final versions of the game.
*/
uint8* decodeNameNew(unsigned int v1, unsigned int v2, uint8 *name)
{
    v1 >>= 4;
    int i;
    for(i = 0; i < 4 && v1 != 0; i++)
    {
        name[i] = (v1 & 0x3F) + 0x20;
        v1 >>= 6;
    }
    v2 &= 0xFFFFFF;
    int l = i + 4;
    for(; i < l && v2 != 0; i++)
    {
        name[i] = (v2 & 0x3F) + 0x20;
        v2 >>= 6;
    }
    name[i] = 0;
    return name;
}


/*
    Old-format encoding used by some demo/trial versions of the game.
*/
void decodeNameOld(int b, int c, uint8 *name)
{
    int bits[64];
    memset(bits, 0, sizeof(bits));

    int index = 0;
    
    /* Make string of 48 bits out of parameters B and C */
    for(int i = 3; i < 32; i++)
    {
        int bit = (b >> i) & 1;
        bits[index++] = bit;
    }
    for(int i = 0; i < 19; i++)
    {
        int bit = (c >> i) & 1;
        bits[index++] = bit;
    }

    /* Extract eight 6-bit letters from 48-bit string */
    index = 0;
    for(int i = 0; i < 8*6; i += 6)
    {
        /* Make six-bit character offset */
        char ch = 0;
        for(int j = 0; j < 6; j++)
        {
            int bit = bits[i + j];
            ch |= bit << j;
        }

        /* Convert character from zero-based offset to ASCII */
        ch += 0x20;
        
        /* Stop parsing name at the first space found */
        if(ch == 0x20)
            break;

        name[index++] = ch;
    }

    /* Write NUL character */
    name[index] = 0;
}

/*----------------------------------------------------------------------------*/
/* File system class functions                                                */
/*----------------------------------------------------------------------------*/

const char *shfs::get_part(vector<string> &src, int index)
{
    if(index >= src.size())
        return ".str";
    index = src.size() - 1 - index;        
    return src[index].c_str();        
}

const char *shfs::get_dir(int index)
{
    return get_part(parts_dir, index);
}

const char *shfs::get_ext(int index)
{
    return get_part(parts_ext, index);
}

/*
    The EXE stores a list of 8-bit directory strings followed by a list of 8-bit file extension stirngs.
    The directory strings are preceeded and followed by a forward slash.
    The file extensions are preceeded by a period.
    Entries beyond the last file extension are filled with zero (NUL).
*/    
void shfs::extract_path_parts(void)
{
    int parts_offset = gip->parts_base;

    /* Scan lists of directory and extension parts */    
    for(int pass = 0; pass < 2; pass++)
    {
        vector<string> *parts = pass ? &parts_ext : &parts_dir;

        for(int i = 0; i < 0x10; i++)
        {
            const char delim = (pass) ? '\0' : '.';
            char path[9];

            if(parts_offset > exe_size)
                break;

            memset(path, 0, sizeof(path));
            memcpy(path, &exe_data[parts_offset], 8);

            /* Check if we have overflowed into the next parts table */
            if(path[0] == delim)
                break;

            if(!pass)
            {
                for(int i = 0; i < 8; i++)
                {
                    if(path[i] == '\\')
                        path[i] = '/';
                }                
            }

            parts->push_back(path);
            parts_offset += 8;
        }
    }
}

bool shfs::parse_file_system(void)
{
    FILE *fd;
    int base = gip->directory_base;

    int max_file_count = gip->file_count;

    for(int i = 0; i < max_file_count; i++)
    {
        int offset = base + i * 12;
        
        /* Error */
        if(offset > exe_size)
        {
            printf("Error: End of file.\n");
            return false;
        }
        
        file_rec *p = (file_rec *)&exe_data[offset];

        int dir_code;
        int ext_code;
        int file_offs;
        int file_size;
        int raw_offs;

        char path[1024];
        char name[1024];

        switch(gip->version)
        {
            /* New-type file structure */
            case VER_US_FULL:
            case VER_EU_FULL:
            case VER_JP_FULL:
            case VER_US_DEMO:
            case VER_EU_DEMO:

                dir_code = p->b & 0x0F;
                ext_code = (p->c >> 24) & 0xFF;

                raw_offs = p->a & 0x7FFFF;
                file_offs = ((p->a & 0x7FFFF) * 0x800) - gip->sector_base;
                
                file_size = (1+((p->a >> 19) & 0x1FFF)) * 0x100;
                
                decodeNameNew(p->b, p->c, (uint8 *)name);
                
                break;
        
            /* Old-type file structure */
            case VER_JP_DEMO:
            case VER_US_PSMG:

                dir_code = (p->b <<   1) & 0x0E;
                ext_code = (p->c >>  19) & 0x0F;

                raw_offs = p->a & 0x7FFFF;
                file_offs = ((p->a & 0x7FFFF) * 0x800) - gip->sector_base;       
                file_size = (((p->a & 0x7FFFFFFF) >> 19) + 1) * 0x100;

                if(p->a & 0x80000000)
                    dir_code |= 1;

                decodeNameOld(p->b, p->c, (uint8 *)name);

                break;

            default:    
                printf("Unknown encoding.\n");
                exit(1);
                break;                
        }        
        
        const char *fdir = get_part(parts_dir, dir_code);
        const char *fext = get_part(parts_ext, ext_code);

        sprintf(path, "%s%s%s", fdir, name, fext);

        file_sys_rec *q = new file_sys_rec;

        q->name = strdup(name);
        q->offset = file_offs;
        q->size = file_size;
        q->dir_code = dir_code;
        q->ext_code = ext_code;
        q->path = strdup(path);
        q->raw_offset = raw_offs;

        /* STR files seem to have invalid size fields, or the field represents other information */
        if(ext_code == 0x0F)
            q->size = 0;        
        
        file_sys.push_back(q);
    }    
    
    return true;   
}

bool shfs::load_exe(char *path)
{
    char exe_path[1024];
    strcpy(exe_path, path);

    /* Load executable */
    if(!load_file(exe_path, exe_data, exe_size))
    {
        printf("Error loading file `%s'.\n", exe_path);
        return false;
    }

    /* Print file data */
    if(verbose)
        printf("Info: Loaded file `%s' (%d bytes).\n", exe_path, exe_size);

    /* Get filename portion of path */
    char *exe_name = exe_path;
    if(strpbrk(exe_path, ":\\/") != NULL)
    {
        exe_name = strrchr(exe_path, '\\');
        if(exe_name == NULL)
            exe_name = strrchr(exe_path, '/');
        if(exe_name == NULL)
            exe_name = strrchr(exe_path, ':');
        ++exe_name;            
    }

    /* Determine game version */
    gip = NULL;
    for(int i = 0; game_info[i].exe_name != NULL; i++)
    {
        if(stricmp(exe_name, game_info[i].exe_name) == 0)
        {
            gip = &game_info[i];
            break;
        }
    }

    /* Check if it's a version we can't handle */
    if(gip == NULL)
    {
        printf("Sorry, this is an unknown version of the game.\n");
        printf("Please contact the author so that it can be supported.\n");
        return false;
    }

    /* Print game version */
    if(verbose)
        printf("Info: Game version %d.\n", gip->version);


    /* Extract path parts */
    extract_path_parts();

    /* Print parts information */
    if(verbose)
    {
        printf("Info: Directory parts: (%d found)\n", parts_dir.size());
        for(int i = 0; i < parts_dir.size(); i++)
            printf("- (%X) `%s'\n", i, get_dir(i));
        printf("\n");        

        printf("Info: Extension parts: (%d found)\n", parts_ext.size());
        for(int i = 0; i < parts_ext.size(); i++)
            printf("- (%X) `%s'\n", i, get_ext(i));
        printf("\n");        
    }

    /* Parse file system data in EXE */
    parse_file_system();

    return true;
}


/*----------------------------------------------------------------------------*/
/* Utility functions                                                          */
/*----------------------------------------------------------------------------*/

bool load_file(const char *path, uint8* &buffer, int &size)
{
    FILE *fd;

    fd = fopen(path, "rb");
    if(!fd)
        return false;

    fseek(fd, 0, SEEK_END);
    size = ftell(fd);
    fseek(fd, 0, SEEK_SET);

    if(!size)
        return false;

    buffer = new uint8 [size];
    if(!buffer)
        return false;

    fread(buffer, size, 1, fd);        
    
    fclose(fd);
    return true;
}

int file_size(const char *path)
{
    struct stat status;

    if(stat(path, &status) != 0)
        return false;

    return status.st_size;
}

bool dir_exists(const char *path)
{
    struct stat status;

    if(stat(path, &status) != 0)
        return false;

    return (status.st_mode & S_IFDIR);
}

bool file_exists(const char *path)
{
    struct stat status;

    if(stat(path, &status) != 0)
        return false;

    return (status.st_mode & S_IFREG);
}

/*----------------------------------------------------------------------------*/
/* Program commands                                                           */
/*----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Extract unused data                                                        */
/*----------------------------------------------------------------------------*/

int opt_unused(int argc, char *argv[])
{
    /* Warn user if no parameters specified */
    if(argc != 5)
    {
        printf("usage: %s unused <exe_file> <data_file> <output_file>\n", prg_name);
        printf("example: %s unused slus_007.07 silent unused.bin\n", prg_name);
        return 0;
    }

    char *exe_path = argv[2];
    char *data_path = argv[3];
    char *output_path = argv[4];
    shfs fs;

    int used_locations;
    int data_size;
    uint8 *data;

    /* Load data file */
    printf("Loading data file... ");
    if(!load_file(data_path, data, data_size))
    {
        printf("\nError opening data file `%s'.\n", data_path);
        return 0;
    }
    printf(" OK (%d bytes)\n", data_size);

    /* Load executable and parse filesystem data */
    printf("Loading executable...\n");
    if(!fs.load_exe(exe_path))
    {
        printf("An error occurred when loading the executable file.\n");
        return 0;
    }

    /* Allocate data map */
    uint8 *data_map = new uint8 [data_size];
    if(!data_map)
    {
        printf("Error allocating memory for data map.\n", data_size);
        return 0;
    }

    /* Clear data map */
    used_locations = 0;
    for(int i = 0; i < data_size; i++)
        data_map[i] = 0;

    /* Print file system information */
    for(int i = 0; i < fs.file_sys.size(); i++)
    {
        char path[1024];
        FILE *output_file;
        file_sys_rec *p = fs.file_sys[i];
        sprintf(path, "%s", p->path);

        /* If file position resides outside of the data file, warn user and skip */
        if(p->offset >= data_size)
        {
            printf("File `%s' is a movie, skipping.\n", path);
            continue;
        }
        
        /* Tell user the file is being written */
        printf("Checking file `%s'.\n", path);

        for(int offset = p->offset; offset < p->offset + p->size; offset++)
        {
            data_map[offset] = 1;
        }
    }

    /* Tally all used locations */
    used_locations = 0;
    for(int i = 0; i < data_size; i++)
    {
        if(data_map[i] == 1)
            used_locations++;
            
    }

    printf("Result: %08X of %08X bytes used, %08X unused.\n", used_locations, data_size, data_size - used_locations);

    /* If any locations are unused, write them out to disk */
    if(used_locations < data_size)
    {
        uint8 *rem_data;
        int rem_size;
        int rem_index;

        rem_size = data_size - used_locations;
        rem_data = new uint8 [rem_size];
        rem_index = 0;

        /* Concatenate unused data together */
        for(int i = 0; i < data_size; i++)
        {
            if(data_map[i] == 0)
            {
                rem_data[rem_index] = data[i];
                rem_index++;
            }
        }

        printf("Writing unused data to file `%s'.\n", output_path);
        FILE *fd = fopen(output_path, "wb");
        if(!fd)
        {
            printf("Error opening file `%s' for writing.\n", output_path);
            return 0;
        }
        
        fwrite(rem_data, rem_size, 1, fd);
        fclose(fd);

        delete[] data_map;
    }
    else
    {
        printf("No unused data found.\n");
    }

    delete[] data;
    return 1;
}


/*----------------------------------------------------------------------------*/
/* Extract files                                                              */
/*----------------------------------------------------------------------------*/

int opt_extract(int argc, char *argv[])
{
    /* Warn user if no parameters specified */
    if(argc != 5)
    {
        printf("usage: %s extract <exe_file> <data_file> <output_dir>\n", prg_name);
        printf("example: %s extract slus_007.07 silent game_data\n", prg_name);
        return 0;
    }

    char *exe_path = argv[2];
    char *data_path = argv[3];
    char *output_path = argv[4];
    shfs fs;

    int data_size;
    FILE *data_file;

    /* Check if data file exists */
    if(!file_exists(data_path))
    {
        printf("Data file `%s' does not exist.\n", data_path);
        return 0;
    }

    /* Get data file size */
    data_size = file_size(data_path);

    /* Open data file for reading */
    data_file = fopen(data_path, "rb");
    if(!data_file)
    {
        printf("Error opening data file `%s'.\n", data_path);
        return 0;
    }

    /* Load executable and parse filesystem data */
    if(!fs.load_exe(exe_path))
    {
        printf("An error occurred when loading the executable.\n");
        return 0;
    }

    printf("Checking output directories:\n");

    /* Create output directory */
    if(!dir_exists(output_path))
    {   
        printf("- Creating output directory `%s'.\n", output_path);
        if(mkdir(output_path) != 0)
        {
            printf("Error creating output directory.\n");
            return 0;
        }
    }
    else
    {
        printf("- Directory `%s' already exists.\n", output_path);
    }

    /* Change into output directory */
    char cwd[1024];
    getcwd(cwd, sizeof(cwd));
    chdir(output_path);

    /* Create subdirectories */
    for(int i = 0; i < fs.parts_dir.size(); i++)
    {   
        int j;
        char path[1024];
        char frag[1024];

        strcpy(frag, fs.get_dir(i));

        /* Sanitize fragment */
        for(j = 1; frag[j] != '/'; j++)
        {
            path[j-1] = frag[j];
        }
        path[j-1] = 0;

        if(!dir_exists(path))
        {   
            printf("- Creating subdirectory `%s'.\n", path);
            if(mkdir(path) != 0)
            {
                printf("Error creating subdirectory `%s'.\n", path);
                return 0;
            }
        }
        else
        {
            printf("- Directory `%s' already exists.\n", path);
        }
    }

    /* Change back to output directory */
    chdir(cwd);

    /* Print file system information */
    for(int i = 0; i < fs.file_sys.size(); i++)
    {
        char path[1024];
        FILE *output_file;
        file_sys_rec *p = fs.file_sys[i];
        sprintf(path, "%s%s", output_path, p->path);

        /* If file position resides outside of the data file, warn user and skip */
        if(p->offset >= data_size)
        {

            printf("File `%s' is a movie, skipping.\n", path);
            continue;
        }
    
        /* If file already exists, don't overwite it */
        if(file_exists(path))
        {
            printf("File `%s' already exists, skipping.\n", path);
            continue;
        }
        
        /* Tell user the file is being written */
        printf("Writing file `%s'. (%d bytes)\n",
            path,
            p->size
            );

        /* Open output file */
        output_file = fopen(path, "wb");
        if(!output_file)
        {   
            printf("Error opening file `%s' for writing.\n", path);
            return 0;
        }
        else
        {
            /* Seek to source position in data file */
            fseek(data_file, p->offset, SEEK_SET);
            if(ftell(data_file) != p->offset)
            {
                printf("Error seeking to data file offset %08X.\n", p->offset);
                return 0;
            }

            /* Allocate memory for file data */
            uint8 *buffer = new uint8 [p->size];
            if(!buffer)
            {
                printf("Error allocating %08X bytes for file data.\n", p->size);
                return 0;
            }
            
            /* Read file data from input and write to output */
            fread(buffer, p->size, 1, data_file);
            fwrite(buffer, p->size, 1, output_file);
            
            /* Clean up */
            delete[] buffer;
            fclose(output_file);            
        }
    }

    fclose(data_file);
    return 1;
}

/*----------------------------------------------------------------------------*/
/* View file structure                                                        */
/*----------------------------------------------------------------------------*/

int opt_view(int argc, char *argv[])
{
    char *exe_name = argv[2];
    shfs fs;

    /* Warn user if no parameters specified */
    if(argc != 3)
    {
        printf("usage: %s view <exe_file>\n", prg_name);
        printf("example: %s view slus_007.07\n", prg_name);
        return 0;
    }
    
    /* Load EXE and parse filesystem data */
    if(!fs.load_exe(exe_name))
    {
        printf("An error occurred when loading the executable.\n");
        return 0;
    }

    /* Print file system information */
    for(int i = 0; i < fs.file_sys.size(); i++)
    {
        file_sys_rec *p = fs.file_sys[i];
        printf("%03X: Sector:%05X Offs:%08X Size:%06X Path:%s\n",
            i, 
            p->raw_offset,
            p->offset,
            p->size,
            p->path
            );
    }
    
    return 1;
}

/*----------------------------------------------------------------------------*/
/* Main program                                                               */
/*----------------------------------------------------------------------------*/

typedef struct
{
    char *name;
    int (*func)(int argc, char *argv[]);
} cmd_rec;

static const cmd_rec cmds[] = 
{
    {"view",    opt_view},
    {"extract", opt_extract},
    {"unused",  opt_unused},
    {NULL,      NULL},
};

int main (int argc, char *argv[])
{
    /* Warn user if not enough arguments specified */
    if(argc < 2)
    {
        printf("Silent Hill data tool.\n");
        printf("Based on an original programn (C) 2010 HoRRoR_X (www.consolegames.ru)\n");
        printf("This program (C) 2014 Charles MacDonald (cgfm2.emuviews.com)\n");
        printf("\n");
        printf("usage: %s <command> <parameters...>\n", prg_name);
        printf("Specify a command with no parameters to get help on use.\n");
        printf("Available commands are: ");
        for(int i = 0; cmds[i].name != NULL; i++)
        {
            printf("%s ", cmds[i].name);
        }
        printf("\n");
        return 0;
    }

    /* Check for command */
    for(int i = 0; cmds[i].name != NULL; i++)
    {
        if(stricmp(argv[1], cmds[i].name) == 0)
        {
            return cmds[i].func(argc, argv);
        }
    }

    /* Unknown command */
    printf("Unknown command '%s'.\n", argv[1]);
    return 0;
}

/* End */


