import newGameLib
from newGameLib import *
import Blender	


class Node:pass
class Stream:pass	

def tree(parent,os1,os2,n,g):	
	n+=4
	sum=os1
	while(True):
		if sum==os2:
			break
		node=Node()	
		node.children=[]
		t=g.tell()
		node.offset=t
		chunk=g.i(1)[0]
		node.chunk=chunk
		parent.children.append(node)
		s1=g.i(1)[0]
		s2=g.i(1)[0]
		sum+=s2
		#print '-'*n,chunk,s1,s2,g.tell()
		if s1<s2:			
			g.seek(t+s1)
			tree(node,s1,s2,n,g)
		g.seek(t+s2)
	
	
	
def getAllImage(root,g):
	for child in root.children:
		if child.chunk==102400:
			g.seek(child.offset+12)	
			for child1 in child.children:
				if child1.chunk==102406:
					g.seek(child1.offset+12)
					name1 = g.word(g.B(1)[0])
					info=g.i(6)	
					name2 = g.word(4) 					
					for child2 in child1.children:
						if child2.chunk==102402:
							g.seek(child2.offset+12)
							new=open(g.dirname+os.sep+name1,'wb')
							new.write(g.read(g.i(1)[0]))
							new.close()
	

		
def getAllMesh(root,g):
		streamList=[]
		for child in root.children:
			if child.chunk==65601:#indices
				g.seek(child.offset+12)			
				stream=Stream()
				streamList.append(stream)
				g.i(1)[0]
				stream.name = g.word(g.B(1)[0]) 
				stream.info=g.i(5)									
				for child1 in child.children:
					if child1.chunk==65603:
						g.seek(child1.offset+12)						
						stream.itemCount=g.i(1)[0]
						stream.itemList=[]
						for m in range(stream.itemCount):
							name = g.word(g.B(1)[0]) 
							data=g.i(7)
							stream.itemList.append([name,data])	
					if child1.chunk==65602:
						stream.offset=child1.offset+12
						
			if child.chunk==65600:#vertexes
				g.seek(child.offset+12)		
				print	
				stream=Stream()
				streamList.append(stream)
				g.i(1)[0]
				stream.name = g.word(g.B(1)[0])
				stream.info=g.i(5)					
				for child1 in child.children:
					if child1.chunk==65603:
						g.seek(child1.offset+12)					
						stream.itemCount=g.i(1)[0]
						stream.itemList=[]
						for m in range(stream.itemCount):
							name = g.word(g.B(1)[0]) 
							print name
							data=g.i(7)
							stream.itemList.append([name,data])	
					if child1.chunk==65602:
						stream.offset=child1.offset+12
						
						
		for child in root.children:
			if child.chunk==151552:
				g.seek(child.offset+12)	
	
				g.i(1)[0]
				name = g.word(g.B(1)[0]) 
				name = g.word(g.B(1)[0]) 
				print name,data
				print 'body part count=',g.i(1)[0]


				
				for child1 in child.children:
					if child1.chunk==151553:
						mesh=Mesh()
						g.seek(child1.offset+12)	
						data=g.i(2)
						name = g.word(g.B(1)[0]) 
						print name,data

						
						for child2 in child1.children:
							if child2.chunk==151554:
								g.seek(child2.offset+12)
									
								g.i(1)
								materialName = g.word(g.B(1)[0]) 
								g.i(1)
								indiceStreamName = g.word(g.B(1)[0]) 
								verticeStreamName = g.word(g.B(1)[0]) 
								skinStreamName = g.word(g.B(1)[0]) 
								
								meshMat=Mat()
								mesh.matList.append(meshMat)
								for mat in matList:
									if mat.name==materialName:
										for mapType,mapName in mat.imageList:		
											if len(mapName)>0:
												if mapType=='color':meshMat.diffuse=g.dirname+os.sep+mapName
												if mapType=='aoControl':meshMat.ao=g.dirname+os.sep+mapName
												if mapType=='normal':meshMat.normal=g.dirname+os.sep+mapName
												if mapType=='specular':meshMat.specular=g.dirname+os.sep+mapName
									
								for stream in streamList:
									if stream.name==indiceStreamName:
										g.seek(stream.offset+4)
										faceCount=stream.info[4]
										for m in range(faceCount):
											mesh.faceList.append(g.H(3))
									
										
								for stream in streamList:
									if stream.name==skinStreamName:
										g.seek(stream.offset+4)
										vertCount=stream.info[2]
										for m in range(vertCount):
											t=g.tell()
											for n in range(stream.itemCount):
												type=stream.itemList[n][0]
												off=stream.itemList[n][1][2]
												stride=stream.itemList[n][1][3]
												if type=='position':
													g.seek(t+off)
													mesh.vertPosList.append(g.f(3))
													g.seek(t+stride)
												
								for stream in streamList:
									if stream.name==verticeStreamName:
										g.seek(stream.offset+4)
										vertCount=stream.info[2]
										for m in range(vertCount):
											t=g.tell()
											for n in range(stream.itemCount):
												type=stream.itemList[n][0]
												off=stream.itemList[n][1][2]
												stride=stream.itemList[n][1][3]
												if type=='tex0':
													g.seek(t+off)
													mesh.vertUVList.append(g.f(2))
													g.seek(t+stride)
											
							if child2.chunk==151555:
								g.seek(child2.offset+12)
									
								g.i(1)
								materialName = g.word(g.B(1)[0]) 
								g.i(1)
								indiceStreamName = g.word(g.B(1)[0]) 
								verticeStreamName = g.word(g.B(1)[0]) 
								skinStreamName = g.word(g.B(1)[0]) 
								
								
								
								meshMat=Mat()
								mesh.matList.append(meshMat)
								for mat in matList:
									if mat.name==materialName:
										for mapType,mapName in mat.imageList:	
											if len(mapName)>0:
												if mapType=='color':meshMat.diffuse=g.dirname+os.sep+mapName
												if mapType=='aoControl':meshMat.ao=g.dirname+os.sep+mapName
												if mapType=='normal':meshMat.normal=g.dirname+os.sep+mapName
												if mapType=='specular':meshMat.specular=g.dirname+os.sep+mapName

											
								for stream in streamList:
									if stream.name==indiceStreamName:
										g.seek(stream.offset+4)
										faceCount=stream.info[4]
										for m in range(faceCount):
											mesh.faceList.append(g.H(3))
											
								for stream in streamList:
									if stream.name==verticeStreamName:
										g.seek(stream.offset+4)
										vertCount=stream.info[2]
										for m in range(vertCount):
											t=g.tell()
											for n in range(stream.itemCount):
												type=stream.itemList[n][0]
												off=stream.itemList[n][1][2]
												stride=stream.itemList[n][1][3]
												if type=='tex0':
													g.seek(t+off)
													mesh.vertUVList.append(g.f(2))
													g.seek(t+stride)
												if type=='position':
													g.seek(t+off)
													mesh.vertPosList.append(g.f(3))
													g.seek(t+stride)
											
						mesh.draw()							
	
	
	
def getAllMaterial(root,g):
		for child in root.children:
			if child.chunk==69653:
				g.seek(child.offset+12)	
				mat=Mat()
				matList.append(mat)
				mat.imageList=[]
				mat.name = g.word(g.B(1)[0])				
				
				for child1 in child.children:
					if child1.chunk==69654:
						g.seek(child1.offset+12)
						mapType = g.word(g.B(1)[0]) 
						mapName = g.word(g.B(1)[0]) 
						mat.imageList.append([mapType,mapName])
	
	

def p3dParser(filename,g):
	global matList
	matList=[]
	#g.debug=True
	fileType=g.read(3)
	g.seek(0)
	if fileType=='\x50\x33\x44':	
		root=Node()
		n=0
		t=g.tell()
		chunk=g.i(1)[0]
		root.chunk=chunk
		root.children=[]
		root.offset=t
		s1=g.i(1)[0]		
		s2=g.i(1)[0]
		print '-'*n,s1,s2
		if s1<s2:
			g.seek(t+s1)
			tree(root,s1,s2,n,g)
		g.tell()
		getAllImage(root,g)
		getAllMaterial(root,g)
		getAllMesh(root,g)
	elif fileType=='\x52\x5A\x00':
		g.seek(16)
		data=g.read(g.fileSize()-16)
		data=zlib.decompress(data)
		new=open(filename+'.p3d','wb')
		new.write(data)
		new.close()
	
	else:
		print 'This file is not supported.'
		
	
	
def Parser(filename):	
	print '='*70
	print filename
	print '='*70
	ext=filename.split('.')[-1].lower()	
	
	if ext=='p3d':
		file=open(filename,'rb')
		g=BinaryReader(file)
		p3dParser(filename,g)
		file.close()
 
	
Blender.Window.FileSelector(Parser,'import','Prototype 2 files: *.p3d') 
	