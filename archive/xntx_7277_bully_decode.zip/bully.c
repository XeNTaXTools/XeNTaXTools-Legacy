#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#pragma warning(disable:4996)
unsigned char stringDecode[0x100];
char *stringCode = "6Ev2GlK1sWoCa5MfQ0pj43DH8Rzi9UnX";
const unsigned long magichash = 0x0ceb538d;

void initStringDecode();
void decode(char *str, char *decodestr, int *num);
void decode2(char *buffer, char *decodestr, int size);

void initStringDecode()
{
   int idx = 0;
   memset(stringDecode, 0, sizeof(stringDecode));
   do
   {
      *(stringDecode + stringCode[idx]) = idx;
      ++idx;
   } while (idx != 32);
}

void decode(char *str, char *decodestr, int *num)
{
   int s = 0;
   unsigned char v1;
   unsigned char dectable;
   int idx = 0;
   int cnt = 0;
   int l = strlen(str) - 2;
   int buf = l;
   int len = (5 * l >> 3);
   *num = len;
   memset(decodestr, 0, len);
   do
   {
      if (l <= cnt)
         buf = 0;
      else
         buf = str[cnt + 2];
      dectable = stringDecode[buf];
      //printf("%x\n", buf);
      switch (s)
      {
      case 3:
         v1 = 0;
         break;
      case 2:
         v1 = 0;
         dectable = 2 * dectable;
         break;
      case 1:
         v1 = 0;
         dectable = 4 * dectable;
         break;
      case 0:
         v1 = 0;
         dectable = 8 * dectable;
         break;
      case 7:
         v1 = 16 * dectable;
         dectable >>= 4;
         break;
      case 6:
         v1 = 32 * dectable;
         dectable >>= 3;
         break;
      case 5:
         v1 = dectable << 6;
         dectable >>= 2;
         break;
      case 4:
         v1 = dectable << 7;
         dectable >>= 1;
         break;
      default:
         v1 = 0;
         dectable = 0;
         break;
      }
      
      decodestr[idx] |= dectable;
      //printf("%x\n", dectable);
      if (l - 1 != idx)
         decodestr[idx + 1] |= v1;
      if ((unsigned int)(s + 5) <= 7)
         s += 5;
      else
      {
         idx++;
         s -= 3;
         if (idx == l)
            return;
      }
      
      cnt++;
   } while (l > cnt);

   decode2(decodestr, decodestr, *num);
}
void decode2(char *buffer,char *decodestr,int size)
{
   int i;
   char b;
   unsigned long m = magichash;
   unsigned int num = 0x12;
   for (i = 0; i < size; i++)
   {
      b = buffer[i];
      m = 0xab * (m % 0xb1) - 2 * (m / 0xb1);
      decodestr[i]=(b^num) + m;
      num += 6;
   }
}



int main(void)
{
   FILE *fp = fopen("C:\\Users\\Arek\\Desktop\\input.xml", "rb");
   FILE *fp1 = fopen("C:\\Users\\Arek\\Desktop\\output.txt", "wb");
   char *buff = (char *)malloc(0x1000000);
   char *arr = (char *)malloc(0x1000000);
   int sz;
   initStringDecode();
   memset(arr, 0, 0x1000000);
   fread(arr,0x1000000, 1, fp);
   decode(arr, buff, &sz);
   fwrite(buff, sz, 1, fp1);
   
   return 0;
   
}




