Imports System.IO
Imports ICSharpCode.SharpZipLib.Zip.Compression
Public Class TocReader
    Private ds As DataSet

    Public Sub New(ByRef toc As BinaryReader)
        ds = New DataSet("TOCFiles")
        Dim dt As DataTable = New DataTable("FileInfo")
        dt.Columns.Add(New DataColumn("fileid", GetType(System.Int32)))
        dt.Columns.Add(New DataColumn("trefilename", GetType(System.String)))
        dt.Columns.Add(New DataColumn("filepath", GetType(System.String)))
        dt.Columns.Add(New DataColumn("filename", GetType(System.String)))
        dt.Columns.Add(New DataColumn("compression", GetType(System.Int16)))
        dt.Columns.Add(New DataColumn("fileposition", GetType(System.Int32)))
        dt.Columns.Add(New DataColumn("compressedsize", GetType(System.Int32)))
        dt.Columns.Add(New DataColumn("uncompressedsize", GetType(System.Int32)))
        dt.PrimaryKey = New DataColumn() {dt.Columns("fileid")}
        ds.Tables.Add(dt)

        dt = New DataTable("TREFiles")
        dt.Columns.Add(New DataColumn("treid", GetType(System.Int16)))
        dt.Columns.Add(New DataColumn("trefilename", GetType(System.String)))
        dt.PrimaryKey = New DataColumn() {dt.Columns("treid")}
        ds.Tables.Add(dt)

        dt = New DataTable("TOCInfo")
        dt.Columns.Add(New DataColumn("numfilepaths", GetType(System.Int32)))
        dt.Columns.Add(New DataColumn("filepathoffset", GetType(System.Int32)))
        dt.Columns.Add(New DataColumn("filepathsize", GetType(System.Int32)))
        dt.Columns.Add(New DataColumn("numtrefilenames", GetType(System.Int32)))
        dt.Columns.Add(New DataColumn("trefilenamesize", GetType(System.Int32)))
        ds.Tables.Add(dt)

        toc.BaseStream.Seek(12, SeekOrigin.Begin)

        Dim dr As DataRow = ds.Tables("TOCInfo").NewRow
        dr.Item("numfilepaths") = toc.ReadInt32
        dr.Item("filepathoffset") = toc.ReadInt32
        dr.Item("filepathsize") = toc.ReadInt32
        Dim dummy As Integer = toc.ReadInt32
        dr.Item("numtrefilenames") = toc.ReadInt32
        dr.Item("trefilenamesize") = toc.ReadInt32
        ds.Tables("TOCInfo").Rows.Add(dr)

        For icount As Integer = 0 To ds.Tables("TOCInfo").Rows(0).Item("numtrefilenames") - 1
            dr = ds.Tables("TREFiles").NewRow
            dr.Item("treid") = icount
            dr.Item("trefilename") = gets(toc)
            ds.Tables("TREFiles").Rows.Add(dr)
        Next


        For icount As Integer = 0 To ds.Tables("TOCInfo").Rows(0).Item("numfilepaths") - 1
            dr = ds.Tables("FileInfo").NewRow
            dr.Item("FileID") = icount
            dr.Item("compression") = toc.ReadInt16
            dr.Item("trefilename") = ds.Tables("TREFiles").Rows.Find(toc.ReadInt16).Item("trefilename")
            dummy = toc.ReadInt32
            dummy = toc.ReadInt32
            dr.Item("fileposition") = toc.ReadInt32
            dr.Item("uncompressedsize") = toc.ReadInt32
            If dr.Item("compression") <> 0 Then
                dr.Item("compressedsize") = toc.ReadInt32
            Else
                dr.Item("compressedsize") = dr.Item("uncompressedsize")
                dummy = toc.ReadInt32
            End If
            ds.Tables("FileInfo").Rows.Add(dr)
            Application.DoEvents()
        Next

        For icount As Integer = 0 To ds.Tables("TOCInfo").Rows(0).Item("numfilepaths") - 1
            Dim pathname As String = gets(toc)
            ds.Tables("FileInfo").Rows.Find(icount).Item("filepath") = Mid(pathname, 1, InStrRev(pathname, "/") - 1)
            ds.Tables("FileInfo").Rows.Find(icount).Item("filename") = Mid(pathname, InStrRev(pathname, "/") + 1)
            Application.DoEvents()
        Next

    End Sub
    Private Function gets(ByVal fn As BinaryReader) As String
        Dim s As String
        Dim b As Byte
        b = fn.ReadByte
        Do While b <> 0
            s = s & Chr(b)
            b = fn.ReadByte
        Loop
        Return s
    End Function

    Public ReadOnly Property ItemCount() As Integer
        Get
            Return ds.Tables("FileInfo").Rows.Count
        End Get
    End Property

    Public Sub FillTreeView(ByRef tv As TreeView)
        tv.BeginUpdate()
        tv.Nodes.Clear()
        Dim n As TreeNode = New TreeNode("TOC File Root")

        'For icount As Integer = 0 To UBound(trefiles)
        'n.Nodes.Add(trefiles(icount))
        'Next
        Dim dv As DataView = New DataView(ds.Tables("FileInfo"))
        dv.Sort = "filepath"

        For icount As Integer = 0 To dv.Count - 1 'As Integer = 0 To UBound(filesummaries)
            Dim path As String = dv(icount)("filepath")
            addnodes(n, path)
            'n.Nodes.Add(filesummaries(icount).trefilename & "/" & Path)
            Application.DoEvents()
        Next
        tv.Nodes.Add(n)
        tv.EndUpdate()
    End Sub
    Public Sub FillListView(ByRef lv As ListView, ByVal path As String)
        Dim spath As String = Mid(path, 15)

        Dim dv As DataView = New DataView(ds.Tables("FileInfo"), "filepath = '" & spath & "'", "filename", DataViewRowState.CurrentRows)

        Dim itms() As ListViewItem
        ReDim itms(dv.Count - 1)
        For icount As Integer = 0 To dv.Count - 1
            itms(icount) = New ListViewItem(New String() {CType(dv(icount)("filename"), System.String), CType(dv(icount)("compression"), System.String), CType(dv(icount)("uncompressedsize"), System.String), CType(dv(icount)("fileposition"), System.String)})
            'Dim lvi As ListViewItem
            'lvi = New ListViewItem(CType(dv(icount)("filename"), System.String))
            'lvi.SubItems.Add(CType(dv(icount)("compression"), System.Int32))
            'lvi.SubItems.Add(CType(dv(icount)("uncompressedsize"), System.Int32))
            'lvi.SubItems.Add(CType(dv(icount)("fileposition"), System.Int32))
            'lv.Items.Add(lvi)
            Application.DoEvents()
        Next
        lv.Items.AddRange(itms)
    End Sub
    Private Sub addnodes(ByRef n As TreeNode, ByVal path As String)
        If InStr(path, "/") > 0 Then
            Dim nn As TreeNode = New TreeNode(Mid(path, 1, InStr(path, "/") - 1))
            Dim bfound As Boolean = False
            Dim cn As TreeNode
            For Each cn In n.Nodes
                If cn.Text = nn.Text Then
                    bfound = True
                    Exit For
                End If
            Next
            If Not bfound Then
                n.Nodes.Add(nn)
                cn = nn
            End If
            addnodes(cn, Mid(path, InStr(path, "/") + 1))
        Else
            Dim nn As TreeNode = New TreeNode(path)
            Dim bfound As Boolean = False
            For Each cn As TreeNode In n.Nodes
                If cn.Text = nn.Text Then
                    bfound = True
                    Exit For
                End If
            Next
            If Not bfound Then
                n.Nodes.Add(nn)
            End If
        End If
    End Sub
    Public Sub ExtractFiles(ByVal filepath As String, ByVal filenames() As String, ByVal destination As String)
        Dim buffer() As Byte
        For Each filename As String In filenames
            Dim dv As DataView = New DataView(ds.Tables("FileInfo"), "filepath = '" & filepath & "' AND filename = '" & filename & "'", "filename", DataViewRowState.CurrentRows)
            Dim br As BinaryReader = New BinaryReader(File.Open(dv(0)("trefilename"), FileMode.Open, FileAccess.Read))
            br.BaseStream.Seek(dv(0)("fileposition"), SeekOrigin.Begin)
            buffer = br.ReadBytes(dv(0)("compressedsize"))
            If dv(0)("compression") <> 0 Then
                DecompressData(buffer, dv(0)("uncompressedsize"))
            End If
            If Not Directory.Exists(destination & "\" & Replace(dv(0)("filepath"), "/", "\")) Then
                Directory.CreateDirectory(destination & "\" & Replace(dv(0)("filepath"), "/", "\"))
            End If
            Dim bs As BinaryWriter = New BinaryWriter(File.Open(destination & "\" & Replace(dv(0)("filepath"), "/", "\") & "\" & dv(0)("filename"), FileMode.Create))
            bs.Write(buffer)
            bs.Close()
            br.Close()
        Next
    End Sub
    Private Function DecompressData(ByRef TheData() As Byte, ByRef OrigSize As Integer) As Integer
        Dim istr As Inflater = New Inflater
        istr.SetInput(TheData)
        Dim TempData() As Byte
        ReDim TempData(OrigSize - 1)
        Try
            istr.Inflate(TempData, 0, OrigSize)
            TheData = TempData
        Catch ex As Exception
            Environment.Exit(-1)
        End Try
        Return 0
    End Function

End Class
