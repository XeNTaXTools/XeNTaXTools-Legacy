Class ListViewItemComparer
    Implements IComparer

    Private col As Integer
    Private desc As Boolean
    Public Sub New()
        col = 0
        desc = False
    End Sub

    Public Sub New(ByVal column As Integer, ByVal descending As Boolean)
        col = column
        desc = descending
    End Sub

    Public Function Compare(ByVal x As Object, ByVal y As Object) As Integer _
       Implements IComparer.Compare
        If Not desc Then
            If col > 0 Then
                Return CInt(CType(x, ListViewItem).SubItems(col).Text) - CInt(CType(y, ListViewItem).SubItems(col).Text)
            Else
                Return [String].Compare(CType(x, ListViewItem).SubItems(col).Text, CType(y, ListViewItem).SubItems(col).Text)
            End If
        Else
            If col > 0 Then
                Return CInt(CType(y, ListViewItem).SubItems(col).Text) - CInt(CType(x, ListViewItem).SubItems(col).Text)
            Else
                Return [String].Compare(CType(y, ListViewItem).SubItems(col).Text, CType(x, ListViewItem).SubItems(col).Text)
            End If
        End If
    End Function
End Class
