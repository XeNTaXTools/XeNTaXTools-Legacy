Public Class tocitem
    Public trefilename As String
    Public compression As Short
    Public fileposition As Integer
    Public uncompressedsize As Integer
    Public compressedsize As Integer
    Public filepath As String
End Class
