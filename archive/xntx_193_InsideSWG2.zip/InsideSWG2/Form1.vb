Imports System.IO
Public Class Form1
    Inherits System.Windows.Forms.Form

    Private strCurrentFile As String = Nothing
    Private tr As TocReader
    Private currentsortcolumn As Integer = 0
    Private currentsortorder As Boolean = False
#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem3 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem4 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem5 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem6 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem7 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem8 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem9 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem10 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem11 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem12 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem13 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem14 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem15 As System.Windows.Forms.MenuItem
    Friend WithEvents StatusBar1 As System.Windows.Forms.StatusBar
    Friend WithEvents ToolBar1 As System.Windows.Forms.ToolBar
    Friend WithEvents ToolBarButton1 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
    Friend WithEvents ToolBarButton2 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton3 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton4 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton5 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton6 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton7 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton8 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton9 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton10 As System.Windows.Forms.ToolBarButton
    Friend WithEvents TreeView1 As System.Windows.Forms.TreeView
    Friend WithEvents ListView1 As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader3 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader4 As System.Windows.Forms.ColumnHeader
    Friend WithEvents Splitter1 As System.Windows.Forms.Splitter
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents ContextMenu1 As System.Windows.Forms.ContextMenu
    Friend WithEvents MenuItem16 As System.Windows.Forms.MenuItem
    Friend WithEvents ContextMenu2 As System.Windows.Forms.ContextMenu
    Friend WithEvents MenuItem17 As System.Windows.Forms.MenuItem
    Friend WithEvents FolderBrowserDialog1 As System.Windows.Forms.FolderBrowserDialog
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Form1))
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.MenuItem1 = New System.Windows.Forms.MenuItem
        Me.MenuItem2 = New System.Windows.Forms.MenuItem
        Me.MenuItem3 = New System.Windows.Forms.MenuItem
        Me.MenuItem4 = New System.Windows.Forms.MenuItem
        Me.MenuItem5 = New System.Windows.Forms.MenuItem
        Me.MenuItem6 = New System.Windows.Forms.MenuItem
        Me.MenuItem7 = New System.Windows.Forms.MenuItem
        Me.MenuItem8 = New System.Windows.Forms.MenuItem
        Me.MenuItem9 = New System.Windows.Forms.MenuItem
        Me.MenuItem10 = New System.Windows.Forms.MenuItem
        Me.MenuItem11 = New System.Windows.Forms.MenuItem
        Me.MenuItem12 = New System.Windows.Forms.MenuItem
        Me.MenuItem13 = New System.Windows.Forms.MenuItem
        Me.MenuItem14 = New System.Windows.Forms.MenuItem
        Me.MenuItem15 = New System.Windows.Forms.MenuItem
        Me.StatusBar1 = New System.Windows.Forms.StatusBar
        Me.ToolBar1 = New System.Windows.Forms.ToolBar
        Me.ToolBarButton1 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton2 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton3 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton4 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton5 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton6 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton7 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton8 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton9 = New System.Windows.Forms.ToolBarButton
        Me.ToolBarButton10 = New System.Windows.Forms.ToolBarButton
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.TreeView1 = New System.Windows.Forms.TreeView
        Me.ContextMenu1 = New System.Windows.Forms.ContextMenu
        Me.MenuItem16 = New System.Windows.Forms.MenuItem
        Me.ListView1 = New System.Windows.Forms.ListView
        Me.ColumnHeader1 = New System.Windows.Forms.ColumnHeader
        Me.ColumnHeader2 = New System.Windows.Forms.ColumnHeader
        Me.ColumnHeader3 = New System.Windows.Forms.ColumnHeader
        Me.ColumnHeader4 = New System.Windows.Forms.ColumnHeader
        Me.ContextMenu2 = New System.Windows.Forms.ContextMenu
        Me.MenuItem17 = New System.Windows.Forms.MenuItem
        Me.Splitter1 = New System.Windows.Forms.Splitter
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog
        Me.FolderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog
        Me.SuspendLayout()
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1, Me.MenuItem9, Me.MenuItem12, Me.MenuItem14})
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 0
        Me.MenuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem2, Me.MenuItem3, Me.MenuItem4, Me.MenuItem5, Me.MenuItem6, Me.MenuItem7, Me.MenuItem8})
        Me.MenuItem1.Text = "&File"
        '
        'MenuItem2
        '
        Me.MenuItem2.Index = 0
        Me.MenuItem2.Shortcut = System.Windows.Forms.Shortcut.CtrlO
        Me.MenuItem2.Text = "&Open"
        '
        'MenuItem3
        '
        Me.MenuItem3.Index = 1
        Me.MenuItem3.Shortcut = System.Windows.Forms.Shortcut.CtrlS
        Me.MenuItem3.Text = "&Save"
        '
        'MenuItem4
        '
        Me.MenuItem4.Index = 2
        Me.MenuItem4.Text = "Save &As"
        '
        'MenuItem5
        '
        Me.MenuItem5.Index = 3
        Me.MenuItem5.Text = "-"
        '
        'MenuItem6
        '
        Me.MenuItem6.Index = 4
        Me.MenuItem6.Text = "&Recent File"
        '
        'MenuItem7
        '
        Me.MenuItem7.Index = 5
        Me.MenuItem7.Text = "-"
        '
        'MenuItem8
        '
        Me.MenuItem8.Index = 6
        Me.MenuItem8.Text = "E&xit"
        '
        'MenuItem9
        '
        Me.MenuItem9.Index = 1
        Me.MenuItem9.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem10, Me.MenuItem11})
        Me.MenuItem9.Text = "&View"
        '
        'MenuItem10
        '
        Me.MenuItem10.Checked = True
        Me.MenuItem10.Index = 0
        Me.MenuItem10.Text = "Toolbar"
        '
        'MenuItem11
        '
        Me.MenuItem11.Checked = True
        Me.MenuItem11.Index = 1
        Me.MenuItem11.Text = "Status Bar"
        '
        'MenuItem12
        '
        Me.MenuItem12.Index = 2
        Me.MenuItem12.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem13})
        Me.MenuItem12.Text = "&Help"
        '
        'MenuItem13
        '
        Me.MenuItem13.Index = 0
        Me.MenuItem13.Text = "&About InsideSWG2..."
        '
        'MenuItem14
        '
        Me.MenuItem14.Index = 3
        Me.MenuItem14.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem15})
        Me.MenuItem14.Text = "S&earch"
        '
        'MenuItem15
        '
        Me.MenuItem15.Index = 0
        Me.MenuItem15.Text = "Find File in Tree"
        '
        'StatusBar1
        '
        Me.StatusBar1.Location = New System.Drawing.Point(0, 371)
        Me.StatusBar1.Name = "StatusBar1"
        Me.StatusBar1.Size = New System.Drawing.Size(600, 22)
        Me.StatusBar1.TabIndex = 1
        Me.StatusBar1.Text = "Ready"
        '
        'ToolBar1
        '
        Me.ToolBar1.Appearance = System.Windows.Forms.ToolBarAppearance.Flat
        Me.ToolBar1.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.ToolBarButton1, Me.ToolBarButton2, Me.ToolBarButton3, Me.ToolBarButton4, Me.ToolBarButton5, Me.ToolBarButton6, Me.ToolBarButton7, Me.ToolBarButton8, Me.ToolBarButton9, Me.ToolBarButton10})
        Me.ToolBar1.DropDownArrows = True
        Me.ToolBar1.ImageList = Me.ImageList1
        Me.ToolBar1.Location = New System.Drawing.Point(0, 0)
        Me.ToolBar1.Name = "ToolBar1"
        Me.ToolBar1.ShowToolTips = True
        Me.ToolBar1.Size = New System.Drawing.Size(600, 28)
        Me.ToolBar1.TabIndex = 2
        '
        'ToolBarButton1
        '
        Me.ToolBarButton1.ImageIndex = 0
        Me.ToolBarButton1.ToolTipText = "Open"
        '
        'ToolBarButton2
        '
        Me.ToolBarButton2.ImageIndex = 1
        Me.ToolBarButton2.ToolTipText = "Save"
        '
        'ToolBarButton3
        '
        Me.ToolBarButton3.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'ToolBarButton4
        '
        Me.ToolBarButton4.ImageIndex = 2
        Me.ToolBarButton4.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton
        Me.ToolBarButton4.ToolTipText = "Large Icons"
        '
        'ToolBarButton5
        '
        Me.ToolBarButton5.ImageIndex = 3
        Me.ToolBarButton5.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton
        Me.ToolBarButton5.ToolTipText = "Small Icons"
        '
        'ToolBarButton6
        '
        Me.ToolBarButton6.ImageIndex = 4
        Me.ToolBarButton6.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton
        Me.ToolBarButton6.ToolTipText = "List"
        '
        'ToolBarButton7
        '
        Me.ToolBarButton7.ImageIndex = 5
        Me.ToolBarButton7.Pushed = True
        Me.ToolBarButton7.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton
        Me.ToolBarButton7.ToolTipText = "Details"
        '
        'ToolBarButton8
        '
        Me.ToolBarButton8.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'ToolBarButton9
        '
        Me.ToolBarButton9.ImageIndex = 6
        Me.ToolBarButton9.ToolTipText = "About"
        '
        'ToolBarButton10
        '
        Me.ToolBarButton10.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'ImageList1
        '
        Me.ImageList1.ImageSize = New System.Drawing.Size(16, 16)
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        '
        'TreeView1
        '
        Me.TreeView1.Dock = System.Windows.Forms.DockStyle.Left
        Me.TreeView1.ImageIndex = -1
        Me.TreeView1.Location = New System.Drawing.Point(0, 28)
        Me.TreeView1.Name = "TreeView1"
        Me.TreeView1.PathSeparator = "/"
        Me.TreeView1.SelectedImageIndex = -1
        Me.TreeView1.Size = New System.Drawing.Size(168, 343)
        Me.TreeView1.TabIndex = 3
        '
        'ContextMenu1
        '
        Me.ContextMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem16})
        '
        'MenuItem16
        '
        Me.MenuItem16.Index = 0
        Me.MenuItem16.Text = "Extract"
        '
        'ListView1
        '
        Me.ListView1.AllowColumnReorder = True
        Me.ListView1.BackColor = System.Drawing.Color.FromArgb(CType(20, Byte), CType(143, Byte), CType(200, Byte))
        Me.ListView1.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1, Me.ColumnHeader2, Me.ColumnHeader3, Me.ColumnHeader4})
        Me.ListView1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ListView1.ForeColor = System.Drawing.Color.White
        Me.ListView1.FullRowSelect = True
        Me.ListView1.LabelWrap = False
        Me.ListView1.Location = New System.Drawing.Point(176, 28)
        Me.ListView1.Name = "ListView1"
        Me.ListView1.Size = New System.Drawing.Size(424, 343)
        Me.ListView1.Sorting = System.Windows.Forms.SortOrder.Ascending
        Me.ListView1.TabIndex = 4
        Me.ListView1.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "Filename"
        Me.ColumnHeader1.Width = 400
        '
        'ColumnHeader2
        '
        Me.ColumnHeader2.Text = "Comp"
        Me.ColumnHeader2.Width = 40
        '
        'ColumnHeader3
        '
        Me.ColumnHeader3.Text = "Size"
        Me.ColumnHeader3.Width = 30
        '
        'ColumnHeader4
        '
        Me.ColumnHeader4.Text = "Offset"
        Me.ColumnHeader4.Width = 346
        '
        'ContextMenu2
        '
        Me.ContextMenu2.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem17})
        '
        'MenuItem17
        '
        Me.MenuItem17.Index = 0
        Me.MenuItem17.Text = "Extract"
        '
        'Splitter1
        '
        Me.Splitter1.Location = New System.Drawing.Point(168, 28)
        Me.Splitter1.MinExtra = 100
        Me.Splitter1.MinSize = 75
        Me.Splitter1.Name = "Splitter1"
        Me.Splitter1.Size = New System.Drawing.Size(8, 343)
        Me.Splitter1.TabIndex = 5
        Me.Splitter1.TabStop = False
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.DefaultExt = "toc"
        Me.OpenFileDialog1.DereferenceLinks = False
        Me.OpenFileDialog1.Filter = "TOC Files|*.toc"
        Me.OpenFileDialog1.Title = "Open"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(600, 393)
        Me.Controls.Add(Me.ListView1)
        Me.Controls.Add(Me.Splitter1)
        Me.Controls.Add(Me.TreeView1)
        Me.Controls.Add(Me.ToolBar1)
        Me.Controls.Add(Me.StatusBar1)
        Me.KeyPreview = True
        Me.Menu = Me.MainMenu1
        Me.Name = "Form1"
        Me.Text = "InsideSWG2"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub ToolBar1_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles ToolBar1.ButtonClick
        Select Case e.Button.ToolTipText
            Case "Large Icons"
                ToolBar1.Buttons(4).Pushed = False
                ToolBar1.Buttons(5).Pushed = False
                ToolBar1.Buttons(6).Pushed = False
                ListView1.View = View.LargeIcon
            Case "Small Icons"
                ToolBar1.Buttons(3).Pushed = False
                ToolBar1.Buttons(5).Pushed = False
                ToolBar1.Buttons(6).Pushed = False
                ListView1.View = View.SmallIcon
            Case "List"
                ToolBar1.Buttons(3).Pushed = False
                ToolBar1.Buttons(4).Pushed = False
                ToolBar1.Buttons(6).Pushed = False
                ListView1.View = View.List
            Case "Details"
                ToolBar1.Buttons(3).Pushed = False
                ToolBar1.Buttons(4).Pushed = False
                ToolBar1.Buttons(5).Pushed = False
                ListView1.View = View.Details
            Case "Open"
                MenuItem2_Click(Nothing, Nothing)
        End Select
    End Sub

    Private Sub MenuItem2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem2.Click
        Dim toc As BinaryReader
        If OpenFileDialog1.ShowDialog = DialogResult.OK Then
            toc = New BinaryReader(OpenFileDialog1.OpenFile)
            If Not toc Is Nothing Then
                strCurrentFile = OpenFileDialog1.FileName
                Cursor.Hide()
                Me.Text = "InsideSWG2 - " & Mid(OpenFileDialog1.FileName, InStrRev(OpenFileDialog1.FileName, "\") + 1)
                Me.StatusBar1.Text = "Reading TOC File..."
                Me.TreeView1.Nodes.Clear()
                Me.ListView1.Items.Clear()
                Application.DoEvents()
                tr = New TocReader(toc)
                Application.DoEvents()
                toc.Close()
                tr.FillTreeView(TreeView1)
                TreeView1.Nodes(0).Expand()
                TreeView1.ContextMenu = Me.ContextMenu1
                Me.StatusBar1.Text = "Ready"
                Cursor.Show()
                Application.DoEvents()
            End If
        End If
    End Sub

    Private Sub MenuItem8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem8.Click
        End
    End Sub

    Private Sub MenuItem10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem10.Click
        If MenuItem10.Checked = True Then
            ToolBar1.Visible = False
            MenuItem10.Checked = False
        Else
            ToolBar1.Visible = True
            MenuItem10.Checked = True
        End If
    End Sub

    Private Sub MenuItem11_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem11.Click
        If MenuItem11.Checked = True Then
            StatusBar1.Visible = False
            MenuItem11.Checked = False
        Else
            StatusBar1.Visible = True
            MenuItem11.Checked = True
        End If
    End Sub

    Private Sub TreeView1_AfterSelect(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles TreeView1.AfterSelect
        Cursor.Hide()
        StatusBar1.Text = "Reading Node..."
        ListView1.BeginUpdate()
        ListView1.Items.Clear()
        tr.FillListView(ListView1, TreeView1.SelectedNode.FullPath)
        PaintAlternatingBackColor(ListView1, System.Drawing.Color.FromArgb(&H5F8C), System.Drawing.Color.FromArgb(&H148FB2))
        ListView1.EndUpdate()
        If ListView1.Items.Count > 0 Then
            ListView1.ContextMenu = Me.ContextMenu2
        Else
            ListView1.ContextMenu = Nothing
        End If
        StatusBar1.Text = "Ready"
        Cursor.Show()
    End Sub

    Private Sub PaintAlternatingBackColor(ByVal lv As ListView, ByVal color1 As Color, ByVal color2 As Color)
        '=== Paint the rows in a ListView alternating colors

        Dim LVItem As ListViewItem

        For Each LVItem In lv.Items
            If (LVItem.Index Mod 2) = 0 Then
                LVItem.BackColor = color1
            Else
                LVItem.BackColor = color2
            End If
        Next

    End Sub
    Private Sub ListView1_ColumnClick(ByVal sender As Object, ByVal e As System.Windows.Forms.ColumnClickEventArgs) Handles ListView1.ColumnClick
        ListView1.BeginUpdate()
        If e.Column <> currentsortcolumn Then
            Me.ListView1.ListViewItemSorter = New ListViewItemComparer(e.Column, currentsortorder)
            currentsortcolumn = e.Column
        Else
            If Not currentsortorder Then
                Me.ListView1.ListViewItemSorter = New ListViewItemComparer(e.Column, True)
                currentsortorder = True
            Else
                Me.ListView1.ListViewItemSorter = New ListViewItemComparer(e.Column, False)
                currentsortorder = False
            End If
        End If
        PaintAlternatingBackColor(ListView1, System.Drawing.Color.FromArgb(&H5F8C), System.Drawing.Color.FromArgb(&H148FB2))
        ListView1.EndUpdate()
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub MenuItem17_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem17.Click
        Dim strItems() As String
        If ListView1.SelectedItems.Count > 0 Then
            ReDim strItems(ListView1.SelectedItems.Count - 1)
            For icount As Integer = 0 To ListView1.SelectedItems.Count - 1
                strItems(icount) = ListView1.SelectedItems(icount).Text
            Next
        End If
        Dim result As DialogResult = FolderBrowserDialog1.ShowDialog()
        Dim folderName As String
        If (result = DialogResult.OK) Then
            folderName = FolderBrowserDialog1.SelectedPath
        Else
            Exit Sub
        End If
        tr.ExtractFiles(Replace(TreeView1.SelectedNode.FullPath, "TOC File Root/", ""), strItems, folderName)
    End Sub
End Class
