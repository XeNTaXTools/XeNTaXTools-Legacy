import newGameLib
from newGameLib import *
import Blender

class Anim:pass
class Key:pass
class Lod:pass

def pdoParser(filename,g):
	g.i(1)
	g.word(20)
	animCount,lodCount,boneCount=g.i(3)
	g.f(1)
	g.i(3)
	g.f(4)
	
	animList=[]
	for m in range(animCount):
		anim=Anim()
		anim.name=g.word(20)
		anim.ID,anim.fps,unk,anim.offset=g.i(4)
		animList.append(anim)
	endOffset=g.tell()	
	for anim in animList:
		g.seek(anim.offset)	
		keyList=[]
		for i in range(boneCount):
			key=Key()
			key.frameCount,key.offset=g.i(2)
			keyList.append(key)
		pos=g.tell()
		for key in keyList:
				g.seek(key.offset)
				for j in range(key.frameCount):
					g.B(4)
					endOffset=g.tell()
		g.seek(pos)
	g.seek(endOffset)
	lodList=[]
	for m in range(lodCount):#lod count
		lod=Lod()
		lod.boneCount,unk,unk,lod.offset=g.i(4)	
		lodList.append(lod)
	
	for k,lod in enumerate(lodList):
		g.seek(lod.offset)
		skeleton=Skeleton()
		skeleton.name='armature-'+str(k)
		meshList=[]
		for i in range(lod.boneCount):
			bone=Bone()
			mesh=Mesh()
			g.i(3)
			bone.name=g.word(24)
			mesh.name=bone.name
			unk,unk,unk,bone.parentID=g.i(4)
			mesh.vertCount,mesh.faceCount,unk,unk=g.i(4)
			posMatrix=VectorMatrix(g.f(3))
			rotMatrix=QuatMatrix(g.f(4)).resize4x4()
			matrix=rotMatrix*posMatrix
			bone.matrix=matrix
			g.f(7)
			skeleton.boneList.append(bone)
			meshList.append(mesh)
		skeleton.BONESPACE=True
		skeleton.NICE=True
		skeleton.draw()	
		for mesh in meshList:
			for m in range(mesh.vertCount):
				mesh.vertPosList.append(g.f(3))
				g.f(4)
				mesh.vertUVList.append(g.f(2))
			for m in range(mesh.faceCount):
				g.f(5)
				mesh.indiceList.extend(g.i(3))
				g.i(1)	
			mesh.matrix=skeleton.object.getData().bones[mesh.name].matrix['ARMATURESPACE']	
			mat=Mat()
			mat.TRIANGLE=True
			mesh.matList.append(mat)
			mesh.BINDSKELETON=skeleton.name
			mesh.draw()
		
		
	
def Parser():	
	filename=input.filename
	print
	print filename
	print
	ext=filename.split('.')[-1].lower()	
	
	if ext=='pdo':
		file=open(filename,'rb')
		g=BinaryReader(file)
		pdoParser(filename,g)
		file.close()
 
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
	
Blender.Window.FileSelector(openFile,'import','pdo file') 