/*
 *  CPK infomation dump
 *  writen by tpu
 *
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <dirent.h>

typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned int u32;


typedef struct {
	u8 flag;
	u32 offset;
	u32 offset2;
	u32 value;
	u32 vlen;
}KEY_DESC;

typedef struct {
	u32 signature;
	u32 header_size;

	u32 keydesc_size;
	u32 string_offset;
	u32 end_addr;
	u32 unk0;

	u16 key_num;
	u16 val_size;
	u32 toc_fnum;
	
	KEY_DESC *key_desc;
	u8 *string_table;
	u32 vbase;
	u32 offset;
}UTF_H;


u32 _getBE32(u8 *addr)
{
	u8 a, b, c, d;

	a = addr[0];
	b = addr[1];
	c = addr[2];
	d = addr[3];

	return (a<<24) | (b<<16) | (c<<8) | (d);
}

u32 _getBE16(u8 *addr)
{
	u8 a, b;

	a = addr[0];
	b = addr[1];

	return (a<<8) | (b);
}

u32 _getU8(u8 *addr)
{
	u8 a;

	a = addr[0];

	return (a);
}


#define get_BE32(x) _getBE32((u8*)(x))
#define get_BE16(x) _getBE16((u8*)(x));
#define get_U8(x) _getU8((u8*)(x))



u8 *cpk_buf;

UTF_H ucpk;
UTF_H utoc;
UTF_H uitoc;
UTF_H uetoc;

u32 content_offset;
u32 toc_offset;
u32 itoc_offset;
u32 etoc_offset;

u32 type_len[] = {1, 1, 2, 2,
				  4, 4, 8, 8,
				  4, 8, 4, 8};

void print_keyval(UTF_H *u, KEY_DESC *k)
{
	u32 type, data, offset;

	type = k->flag&0x0f;
	offset = k->value;
	offset += u->vbase;
	switch(type){
	case 0:
	case 1:
		data = get_U8(offset);
		printf("%02x", data);
		break;
	case 2:
	case 3:
		data = get_BE16(offset);
		printf("%04x", data);
		break;
	case 4:
	case 5:
		data = get_BE32(offset);
		printf("%08x", data);
		break;
	case 6:
	case 7:
		data = get_BE32(offset+4);
		printf("%08x", data);
		break;
	case 8:
		data = get_BE32(offset);
		printf("%08x", data);
		break;
	case 9:
		data = get_BE32(offset+4);
		printf("%08x", data);
		break;
	case 10:
		data = get_BE32(offset);
		printf("%s", u->string_table+data);
		break;
	case 11:
		data = get_BE32(offset);
		printf("{%s=", u->string_table+data);
		data = get_BE32(offset+4);
		printf("%08x}", data);
		break;
	}
}


KEY_DESC *find_key(UTF_H *u, char *name)
{
	u32 i;

	for(i=0; i<u->key_num; i++){
		if(!strcmp((const char*)(u->key_desc[i].offset), (const char*)name))
			return &(u->key_desc[i]);
	}

	return NULL;
}


u32 get_keyval(UTF_H *u, char *name)
{
	KEY_DESC *k;
	u32 type, data, offset;

	k = find_key(u, name);
	if(k==NULL)
		return 0;

	data = 0;
	type = k->flag&0x0f;
	offset = k->value;
	offset += u->vbase;

	switch(type){
	case 0:
	case 1:
		data = get_U8(offset);
		break;
	case 2:
	case 3:
		data = get_BE16(offset);
		break;
	case 4:
	case 5:
		data = get_BE32(offset);
		break;
	case 6:
	case 7:
		data = get_BE32(offset+4);
		break;
	case 8:
		data = get_BE32(offset);
		break;
	case 9:
		data = get_BE32(offset+4);
		break;
	case 10:
		data = get_BE32(offset);
		data += (u32)u->string_table;
		break;
	case 11:
		data = get_BE32(offset+4);
		break;
	}

	return data;
}

int decrypt_cpk(u8 *buf, int length)
{
	u32 m, t, d;
	int i;

	m = 0x0000655f;
	t = 0x00004115;

	for(i=0; i<length; i++){
		d = buf[i];
		d = d^(m&0xff);
		buf[i] = d;
		m = m*t;
	}

	return 0;
}

void load_utf(u8 *buf, UTF_H *utf)
{
	KEY_DESC *key_desc;
	u32 kbuf, dbuf, sbuf;
	u32 i, len, flag;

	memset(utf, 0, sizeof(UTF_H));
	utf->offset        = (u32)buf;

	len = *(u32*)(buf+0x08);
	buf += 0x10;

	if(*(u32*)(buf)!=0x46545540){ // @UTF
		decrypt_cpk(buf, len);
	}



	utf->signature     = get_BE32(buf); buf+=4;
	utf->header_size   = get_BE32(buf); buf+=4;

	utf->keydesc_size  = get_BE32(buf); buf+=4;
	utf->string_offset = get_BE32(buf); buf+=4;
	utf->end_addr      = get_BE32(buf); buf+=4;
	utf->unk0          = get_BE32(buf); buf+=4;

	utf->key_num       = get_BE16(buf); buf+=2;
	utf->val_size      = get_BE16(buf); buf+=2;
	utf->toc_fnum      = get_BE32(buf); buf+=4;

	key_desc = (KEY_DESC*)malloc(utf->key_num*sizeof(KEY_DESC));
	memset(key_desc, 0, utf->key_num*sizeof(KEY_DESC));
	utf->key_desc = key_desc;

	kbuf = (int)buf;
	dbuf = kbuf+utf->keydesc_size-0x18;
	sbuf = (int)buf+utf->string_offset-0x18;
	utf->string_table  =(u8*)sbuf;

	for(i=0; i<utf->key_num; i++){
		flag = get_U8(kbuf); kbuf+=1;
		if(flag&0x10){
			key_desc[i].offset = get_BE32(kbuf); kbuf+=4;
			key_desc[i].offset += sbuf;
		}
		if(flag&0x20){
			key_desc[i].offset2 = get_BE32(kbuf); kbuf+=4;
			key_desc[i].offset2 += sbuf;
		}
		if(flag&0x40){
			len = type_len[flag&0x0f];
			key_desc[i].value = dbuf;
			key_desc[i].vlen = len;
			dbuf += len;
		}
		key_desc[i].flag = flag;
	}
}

void dump_utf(UTF_H *utf)
{
	KEY_DESC *key_desc;
	u32 j, i, flag;

	printf("\n[%s]\n", utf->string_table+7);
	//printf("key_num=%d toc_num=%d val_size=0x%x unk0=%08x\n",
	//		utf->key_num, utf->toc_fnum, utf->val_size, utf->unk0);
	printf("-------------------------\n");
	key_desc = utf->key_desc;
	for(j=0; j<utf->toc_fnum; j++){
		if(utf->toc_fnum>1)
			printf("TOC%d:\n", j);
		utf->vbase = j*utf->val_size;
		for(i=0; i<utf->key_num; i++){
			flag = key_desc[i].flag;
			printf("  %s", (char*)(key_desc[i].offset));
			if(flag&0x20)
				printf("=%s",  (char*)key_desc[i].offset2);
			if(flag&0x40){
				printf(" = ");
				print_keyval(utf, &key_desc[i]);
			}
			printf("\n");
		}
	}
	printf("\n");
}


void mkdir_p(char *dname)
{
	char name[256];
	char *p, *cp;

	strcpy(name, dname);

	cp = name;
	while(1){
		p = strchr(cp, '/');
		if(p==NULL)
			p = strchr(cp, '\\');
		if(p==NULL)
			break;

		*p = 0;
		//mkdir(name, 0777);
		mkdir(name);
		*p = '/';
		cp = p+1;
	};
}


u32 layla_decomp(u8 *src, u32 src_len, u8 *dst, u32 dst_len);

void extract_toc(UTF_H *u, char *cpk_name)
{
	KEY_DESC *k;
	u32 i, dname, fname, fsize, offset, extsize;
	u8 *buf;
	char dir_name[256], temp_name[256], *p;
	FILE *fp;

	/* make dir: xxxx_cpk */
	strcpy(dir_name, cpk_name);
	p = strrchr(dir_name, '.');
	if(p){
		*p = '_';
	}
	mkdir(dir_name);

	k = u->key_desc;
	for(i=0; i<u->toc_fnum; i++){
		u->vbase = i*u->val_size;
		dname  = get_keyval(u, "DirName");
		fname  = get_keyval(u, "FileName");
		fsize  = get_keyval(u, "FileSize");
		extsize= get_keyval(u, "ExtractSize");
		offset = get_keyval(u, "FileOffset");
		sprintf(temp_name, "%s/%s/%s", dir_name, (u8*)dname, (u8*)fname);
		mkdir_p(temp_name);
		printf("TOC[%2d]: offset=%08x size=%08x extract_size=%08x name=%s\n",
				i, offset, fsize, extsize, temp_name);

		offset += u->offset;
#if 1
		fp = fopen((const char*)temp_name, "wb");
		if(fp==NULL){
			perror("fopen");
			continue;
		}
		if(fsize==extsize){
			fwrite((const char*)offset, fsize, 1, fp);
		}else{
			buf = malloc(extsize);
			layla_decomp((u8*)offset, fsize, buf, extsize);
			fwrite((const char*)buf, extsize, 1, fp);
			free(buf);
		}
		fclose(fp);
#endif
	}
}



int main(int argc, char *argv[])
{
	FILE *cpk;
	int fsize;
	u32 cpk_id;

	cpk = fopen(argv[1], "rb");
	if(cpk==NULL){
		printf("Open %s failed!\n", argv[1]);
		return -1;
	}

	fseek(cpk, 0, SEEK_END);
	fsize = ftell(cpk);
	fseek(cpk, 0, SEEK_SET);

	cpk_buf = malloc(fsize+4096);
	fread(cpk_buf, fsize, 1, cpk);
	fclose(cpk);

	cpk_id = *(u32*)(cpk_buf);
	if(cpk_id!=0x204b5043){
		printf("File %s isn't a CPK package! %08x\n", argv[1], cpk_id);
		return -1;
	}

	load_utf(cpk_buf, &ucpk);
	dump_utf(&ucpk);

	content_offset  = get_keyval(&ucpk, "ContentOffset");
	toc_offset  = get_keyval(&ucpk, "TocOffset");
	if(toc_offset>content_offset){
		toc_offset = 0x0800;
	}
	load_utf(cpk_buf+toc_offset, &utoc);
	dump_utf(&utoc);

	extract_toc(&utoc, argv[1]);

	//itoc_offset = get_keyval(&ucpk, "ItocOffset");
	//etoc_offset = get_keyval(&ucpk, "EtocOffset");

	//load_utf(cpk_buf+itoc_offset, &uitoc);
	//load_utf(cpk_buf+etoc_offset, &uetoc);

	//dump_utf(&uitoc);
	//dump_utf(&uetoc);



	return 0;
}

