/* 
    CRI layla decompress
	writen by tpu
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned int u32;


u8 *sbuf;
u32 bitcnt;
u32 bitdat;

u32 get_bits(u32 n)
{
	u32 data, mask;

    if (bitcnt<n){
	  data = ((24-bitcnt)>>3)+1;
	  bitcnt += data*8;
      while(data) {
		bitdat = (bitdat<<8) | (*sbuf--);
		data--;
      }
    }

	data = bitdat>>(bitcnt-n);
	bitcnt -= n;
	mask = (1<<n)-1;
	data &= mask;

	return data;
}

u32 llcp_dec(u8 *src, u32 src_len, u8 *dst, u32 dst_len)
{
	u8 *dbuf, *pbuf;
	u32 plen, poffset, byte;

	sbuf = src+src_len-1;
	dbuf = dst+dst_len-1;
	bitcnt = 0;

	while(1){
		if(get_bits(1)==0){
			byte = get_bits(8);
			*dbuf-- = byte;
			if((dbuf+1)==dst)
				goto _done;
		}else{
			poffset = get_bits(13);

			plen = get_bits(2);
			if(plen==3){
				plen += get_bits(3);
				if(plen==10){
					plen += get_bits(5);
					if(plen==41){
						do{
							byte = get_bits(8);
							plen += byte;
						}while(byte==255);
					}
				}
			}

			pbuf = dbuf+poffset+3;
			plen += 3;

			while(plen) {
				byte = *pbuf--;
				*dbuf-- = byte;
				plen--;
				if((dbuf+1)==dst)
					goto _done;
			}

		}
	}

_done:
	return (u32)(dst+dst_len-dbuf-1);
}


u32 layla_decomp(u8 *src, u32 src_len, u8 *dst, u32 dst_len)
{
	u8 tbuf[256];
	u32 decomp_size;
	u32 comp_size;

	decomp_size = *(u32*)(src+8);
	comp_size = *(u32*)(src+12);

	memcpy(tbuf, (src+src_len-256), 256);

	decomp_size = llcp_dec(src+0x10, comp_size, dst+256, decomp_size);

	memcpy(dst, tbuf, 256);

	return decomp_size+256;
}


/* test */
#if 0

int main(int argc, char *argv[])
{
	FILE *ifp, *ofp;
	u8 *ibuf;
	u32 fsize;

	ifp = fopen(argv[1], "rb");
	fseek(ifp, 0, SEEK_END);
	fsize = ftell(ifp);
	fseek(ifp, 0, SEEK_SET);

	ibuf = malloc(16*1024*1024);
	fread(ibuf, fsize, 1, ifp);
	fclose(ifp);

	fsize = layla_decomp(ibuf, fsize, ibuf, 0);

	ofp = fopen(argv[2], "wb");
	fwrite(ibuf, fsize, 1, ofp);
	fclose(ofp);

	return 0;
}

#endif

