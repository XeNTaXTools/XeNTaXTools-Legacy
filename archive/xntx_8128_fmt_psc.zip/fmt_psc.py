#powered by Durik256 for xentax.com
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Bulet Girls",".psc")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)	
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    if noeAsciiFromBytes(bs.readBytes(4)) != 'PSCA':
        return 0
    return 1

def noepyLoadModel(data, mdlList):
    bs = NoeBitStream(data)
    bs.seek(16)
    #0;1;2-bone_child?;3;4;5;6;7;8-bone_rot?;9;10;11-vert_offset;12-(name);13-vert/face_count_offset?;14;
    info = [bs.readInt() for x in range(15)]
    print("info:",info)
    
    bs.seek(4)
    bcount = bs.readByte()
    print("bones:",bcount)
    
    bs.seek(info[2])
    
    i = []
    x = 0
    while x<bcount:
        byte = bs.readByte()
        if byte != -1:
            i.append(byte)
            x+=1
    
    print("i?:",i)
    chekFF(bs, bcount)
    
    bones = []
    for x in range(bcount):
        mat = NoeMat43()
        mat[3] = NoeVec3.fromBytes(bs.readBytes(12))
        bones.append(NoeBone(x,"bone_"+str(x), mat))
        
    pindex = []
    for x in range(bcount):
        pindex.append(bs.readShort())
        #bones[x].parentIndex = pindex[-1]
        bs.seek(4,1)#FFFF
    print("pindex?:",pindex)

    bs.seek(info[12])
    name = noeAsciiFromBytes(bs.readBytes(info[13]-info[12]))
    print("name:",name)
    bs.seek(info[13])
    vcount, fcount = bs.readShort(), bs.readShort()
    print("vcount:",vcount,"fcount:",fcount,)
    
    #===
    #0-unk;1-face;2-unk;3-uv?;4-unk*
    bs.seek(24,1)
    msh_info = [bs.readInt() for x in range(5)]
    print("msh_info:",msh_info)
    #===
    
    if vcount > 0:
        bs.seek(info[11]+16)
        vbuf = bs.readBytes(vcount*8)
        print("end vblock:",bs.getOffset())
        bs.seek(info[11]+msh_info[1])
        print("ibuf start:",bs.getOffset())
        ibuf = read_ibuf(bs, fcount)
        print("ibuf end:",bs.getOffset())
        #print(ibuf)
        ctx = rapi.rpgCreateContext()
        
        rapi.rpgBindPositionBufferOfs(vbuf, noesis.RPGEODATA_SHORT,8,2)
        #rapi.rpgBindUV1Buffer(uvbuf, noesis.RPGEODATA_SHORT,8)
        #======WEIGHT=========
        if msh_info[0]:
            bs.seek(info[11]+msh_info[0])
            bw_buf, bi_buf = read_weight(bs, vcount)
            rapi.rpgBindBoneIndexBuffer(bi_buf, noesis.RPGEODATA_SHORT,2,4)
            rapi.rpgBindBoneWeightBuffer(bw_buf, noesis.RPGEODATA_FLOAT,4,4)
        #======END_WEIGHT=====
        rapi.rpgSetPosScaleBias(NoeVec3([8, 8, 8]), None)
        rapi.rpgCommitTriangles(ibuf, noesis.RPGEODATA_SHORT, fcount*4, noesis.RPGEO_QUAD_ABC_ACD)#RPGEO_QUAD
        
        #rapi.rpgSkinPreconstructedVertsToBones(bones)
        mdl = rapi.rpgConstructModel()
    else:
        mdl = NoeModel()
    #+++++++
    print("start_vert:",info[11]+16,"vcount:",vcount,"start_face:",info[11]+msh_info[1],"fcount:",fcount,"start_uv:",info[11]+msh_info[3],"size_uv:",(info[11]+msh_info[4])-(info[11]+msh_info[3]))
    #+++++++
    mdl.setBones(bones)
    mdlList.append(mdl)
    rapi.setPreviewOption("setAngOfs", "0 -90 0")
    return 1
    
def chekFF(bs, bcount):
    curPos = bs.getOffset()
    bs.seek((bcount*12)+1,1)
    bs.seek(curPos + (2 if bs.readByte() != -1 else 1))#FF else FF 00
    
def read_ibuf(bs, fcount):
    ibuf = b''
    for x in range(fcount):
        ibuf += bs.readBytes(8)
        bs.seek(24,1)
    return ibuf
    
def read_weight(bs, count):
    bw_buf = b''
    bi_buf = b''
    for x in range(count):
        for y in range(4):
            bw_buf += struct.pack('f',bs.readByte()/100) 
            bi_buf += bs.readByte().to_bytes(2, 'little')
    return bw_buf, bi_buf