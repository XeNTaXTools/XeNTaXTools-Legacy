#ifndef __MILETOS_PMESH_H__
#define __MILETOS_PMESH_H__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2008
//

#include <string>

#include <elea/color.h>
#include <elea/quaternion.h>

#include <miletos/types.h>
#include <miletos/scene.h>

namespace Miletos {
#if 0
class Skeleton;

class PMesh : public Item {
public:
	static const int MESH_DEFINITION_CHANGED = 64;
	// static const int SKELETON_MODIFIED = 256;
	// static const int MAXBONESPERVERTEX = 10;
	struct PBone {
		std::string id;
		// -1 for root bone
		int parent;
		// Bone neutral orientation in parent space
		Orientation pos;
		// Transformation from mesh to neutral bone space
		Elea::Matrix4x4f mesh2bone;

		// Transformation from animated bone to object space
		Elea::Matrix4x4f anim2object;
		// Mesh animation transformation
		Elea::Matrix4x4f am2o;

		// Mesh update flag
		bool modified;

		// Animated bone orientation in parent space
		// Orientation animpos;
		// Default bounding box in object space
		Elea::Cuboid3f bbox;
		// Animated bounding box in scaled object space
		Elea::Cuboid3f animbbox;
	};
#if 0
	struct PBlend {
		int matidx;
		int nbones;
		int bones[MAXBONESPERVERTEX];
		int firstvertex;
		int numvertices;
		int firstindex;
		int numindices;
		std::vector<float> weights;
	};
#endif
	struct Frag {
		int matidx;
		int firstindex;
		int numindices;
	};
	struct Weight {
		// u16 vertex;
		u16 bone;
		f32 weight;
	};
	struct PBoneAnimation {
		int bone;
		std::vector<float> times;
		std::vector<Orientation> orientations;
	};
	struct PAnimation {
		std::string name;
		// Length in frames
		float numframes;
		// Frames per second
		float fps;
		// Has to be the same length and order as bones
		std::vector<PBoneAnimation> boneanimations;
	};
	struct PMorphKey {
		float time;
		int mbufpos;
	};
	struct PMorph {
		int firstvertex;
		int numvertices;
		std::vector<float> times;
		std::vector<int> mbufpositions;
	};
private:
	// Skeleton name
	char *skelname;

	// Object implementation
	virtual const Type *objectType (void);
	// The following two update skeleton pointer
	virtual Object *childAdded (Thera::Node *cnode, Thera::Node *rnode);
	virtual void childRemoved (Thera::Node *cnode, Thera::Node *rnode);

	// Create Sehle material
	virtual Sehle::Material *getMaterial (int matidx, Sehle::Engine *engine) = 0;

	// Helpers
	bool findKeys (float time, const float *times, u32 ntimes, int& k0, float& w0, int& k1);
	void rebuildRenderable (Sehle::StaticMesh *mesh);
	void updateRenderable (Sehle::StaticMesh *mesh);
protected:
	// Number of renderable elements
	int nvertices;
	int nindices;
	// Index buffer
	int *indices;
	// Textures
	Elea::Vector2f *tbase;
	// Morph data
	int nmorphvertices;
	Elea::Vector3f *vmorph;
	Elea::Vector3f *nmorph;
	// Base plus morphed state
	Elea::Vector3f *vbase;
	Elea::Vector3f *nbase;
	// Animated state
	Elea::Vector3f *vanim;
	Elea::Vector3f *nanim;
	Elea::Vector4f *tanim;

	std::vector<PBone> pbones;
	std::vector<PAnimation> animations;
	// std::vector<PBlend> blends;
	std::vector<PMorph> morphs;

	std::vector<int> wcounts;
	std::vector<Weight> weights;
	std::vector<Frag> frags;

	// Number of Sehle materials
	int nmaterials;

	// Skeleton tree
	Skeleton *skeleton;

	// Constructor
	PMesh (void);
	// Destructor
	~PMesh (void);

	// Object implementation
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	virtual void set (const char *attrid, const char *val);
	virtual void update (UpdateCtx *ctx, unsigned int flags);
	virtual void identityAdded (Document *pdocument, const char *pidentity, Object *pobject);
	virtual void identityRemoved (Document *pdocument, const char *pidentity);
	// Item implementation
	virtual Sehle::Renderable *show (Sehle::Graph *graph, Sehle::u32 contextmask);
	virtual Item *trace (const Elea::Line3f *wray, unsigned int mask, float *distance);

	// Helpers
	void clear ();
	// Compute default animation transformations for bones
	void initializeBoneMatrixes (void);
	// Update mesh animation transforms based on anim2object
	void updateBoneMatrixes (void);
	// Builds default bounding box for bones
	void initializeBoneBBoxes (void);
	// Update bone bounding boxes based on animation
	void updateBoneBBoxes (void);
public:
	// Type system
	static const Type *type (void);

	// Signals
	// The private definition data has changed
	// Signals::Signal2<void, PMesh *, unsigned int> sig_definition_changed;

	// Access
	const char *getName (void);
	int getNumVertices (void);
	int getNumTriangles (void);
	int getNumBones (void);
	const PBone *getBones (void) { return (!pbones.empty ()) ? &pbones[0] : NULL; }
	int getNumMaterials (void);
	Skeleton *getSkeleton (void) { return skeleton; }
	const Elea::Vector3f *getVertices (void) { return vbase; }
	const Elea::Vector3f *getNormals (void) { return nbase; }
	const Elea::Vector2f *getTexCoords (void) { return tbase; }
	const int *getWeightCounts (void) { return (!wcounts.empty ()) ? &wcounts[0] : NULL; }
	int getNumWeights (void) { return (int) weights.size (); }
	const Weight *getWeights (void) { return (!weights.empty ()) ? &weights[0] : NULL; }
	const int *getIndices (void) { return indices; }
	int getNumFrags (void) { return (int) frags.size (); }
	const Frag *getFrags (void) { return (!frags.empty ()) ? &frags[0] : NULL; }

	// Helpers
	PBone *lookupPBone (const char *sid);
	// Normally to be called from inside skeleton to notify that bone animation has changed
	void setPBoneAnimation (PBone *pbone, const Elea::Matrix4x4f& panim2object);
	// To be called from skeleton to signal that skeleton has finished update cycle
	void skeletonModified (unsigned int flags);

	// Create skeleton tree
	// Only to be called during building
	// fixme: move to more appropriate place
	Thera::Node *buildSkeleton (Thera::Document *pthedoc);
	Thera::Node *buildSkeleton (Thera::Document *pthedoc, const char *rootname);
	Thera::Node *buildSkeletalBone (Thera::Document *pthedoc, int pboneidx);
};
#endif
} // Namespace Miletos

#endif

