#define __MILETOS_XPP_CPP__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2007-2009
//

static const int debug = 0;

#ifdef WIN32
#include <io.h>
#endif
#include <stdio.h>
#include <sys/stat.h>

#include <libarikkei/token.h>
#include <libarikkei/utext.h>

#include "helpers/sjis.h"

#include "xpp.h"

#ifdef WIN32
#define read _read
#define lseek _lseek
#define close _close
#endif

namespace Miletos {

namespace Xpp {

#ifdef WIN32
inline char *strdup (const char *str) { return _strdup (str); }
#endif

static const unsigned char HakoTrialCode[] =
{
	0x11,0x73,0x10,0x21,0x5A,0xA1,0xD0,0x8B,
	0x32,0x91,0x63,0x50,0xE9,0xA8,0xF6,0xD8,
	0x40,0x72,0x80,0xF9,0xEC,0x79,0x6E,0x8D,
	0x36,0x72,0x2B,0xA1,0x76,0xB6,0x67,0x92
};

static const unsigned char AG3WelcomeCode[] =
{
	0xE5,0x77,0x64,0x05,0xD2,0x37,0x4D,0x2E,
	0xB7,0x4A,0xB7,0x2B,0x22,0x70,0xF1,0xD6,
	0xC7,0xE7,0x61,0x6D,0x10,0xED,0xF5,0xC1,
	0xD9,0x08,0x28,0xEC,0xE2,0x09,0xEA,0xD7
};

static const unsigned char SMTrialCode[] =
{
	0x7C,0xF2,0x35,0x77,0x54,0x18,0x20,0x6E,
	0x9C,0x7B,0x9E,0x85,0x1F,0xB5,0x71,0x40,
	0x25,0xAD,0x71,0x43,0x64,0x20,0x20,0x7E,
	0xCF,0xE3,0x85,0xC0,0x41,0xDE,0x23,0x12
};

static const unsigned char SMRetailCode[] =
{
	0x1E,0x5D,0x13,0xDD,0x7D,0x4C,0x4F,0xA7,
	0xDB,0xA7,0x29,0x14,0x10,0xF8,0xC0,0xBE,
	0x44,0x7F,0xD0,0x63,0x1C,0x22,0x7C,0x9F,
	0xE8,0xB9,0xF8,0xBE,0x58,0xB3,0xEF,0xF4
};

static const unsigned char AtHomeFigureCode[] =
{
	0xAB,0x2C,0xC4,0x4E,0x7B,0xDF,0xBD,0x17,
	0xDC,0x2E,0x23,0x1E,0x4B,0xE5,0x80,0x3C,
	0x93,0xB1,0x1D,0x8C,0x81,0x36,0xB3,0x88,
	0x35,0x2D,0x30,0x4B,0x10,0x66,0xC8,0xE6
};

static const unsigned char AtHomeTrialCode[] =
{
	0x67,0xF9,0x30,0x5A,0x09,0xAB,0xF5,0x60,
	0xD6,0x9F,0xFD,0x93,0xBA,0x9C,0xF5,0x60,
	0x11,0x6A,0xBA,0x79,0x4C,0x41,0x4A,0x8D,
	0xC7,0xBA,0xBB,0x9C,0x26,0x34,0x0F,0xEF
};

static const unsigned char EskMateCipher[] = {
	0xE9,0xEC,0xFC,0x9F,0x67,0x4A,0x91,0x8D,
	0x72,0x4F,0x5F,0xAE,0xBB,0xA5,0xF7,0x0A,
	0x12,0xB9,0x03,0xC5,0x4E,0x1C,0xE3,0x7A,
	0x7E,0xF4,0x05,0x48,0x51,0x18,0x16,0x99
};

static const unsigned char MIKTrialCipher[] = {
	0xD1,0xEC,0x08,0xA1,0x48,0x7F,0xD6,0x8F,
	0xAD,0x34,0xB2,0xA2,0x35,0x4D,0x55,0xD1,
	0x1F,0xC1,0xB4,0x47,0x2F,0x54,0x89,0x24,
	0x61,0xCE,0xB7,0xA5,0x22,0x80,0x05,0x29
};

static const unsigned char RGFCipher[] = {
	0x58,0x62,0x86,0xD2,0x3B,0x2F,0xC4,0x5F,
	0xEE,0x58,0x76,0x2D,0xB4,0x02,0x02,0xCD,
	0x0A,0x08,0x40,0x30,0x08,0x66,0x1D,0xE8,
	0x9B,0xA6,0x61,0xCB,0x63,0xF3,0xF3,0xB4
};

static const unsigned char SBZCipher[] = {
	0x14,0x6F,0x07,0xB8,0x9A,0x0E,0x84,0x44,
	0x59,0x25,0x8E,0x18,0xBC,0x39,0x9E,0x5C,
	0x99,0x7A,0xA0,0x92,0xD4,0xB7,0xBC,0x55,
	0x1E,0x2E,0x88,0x27,0x14,0xA1,0xE6,0x27
};

static const unsigned char CCBCipher[] = {
	0xEB,0xD6,0x6B,0x29,0x21,0x03,0xA9,0x2C,
	0x5F,0x5F,0xEF,0xBB,0xEC,0x10,0xFC,0x4C,
	0x51,0xED,0xD4,0xBE,0x99,0x4D,0x45,0x06,
	0x65,0x51,0x8E,0x25,0x33,0x5C,0x05,0x53
};

static const unsigned short AtHomeRetailCode[] =
{
	0x717e, 0x0e78, 0xafe7, 0x8fa7,
	0x9e1f, 0xc5e3, 0x0008, 0x713a
};

static const unsigned short YuushaCode[] =
{
	0xA82B, 0x1EF2, 0x1DDD, 0xC895,
	0xD47E, 0x764F, 0x416F, 0xC7BF,
};

static const unsigned short AG3RetailCode[] =
{
	0x00CA,0x006E,0x000D,0x00B3,
	0x009C,0x0036,0x001E,0x00E8,
};

static const unsigned short HakoRetailCode[] =
{
	0xCBEE,0x1675,0x3533,0x4CE6,
	0x2F68,0x936D,0xF40D,0x0539,
};

static const unsigned short DGRetailCode[] =
{
	0x2110, 0x8BD0, 0x5063, 0xD8F6,
	0x7311, 0xA15A, 0x9132, 0xA8E9
};

static const unsigned short SMSweetsRetailCode[] =
{
	0x3F86, 0xB8D5, 0x4AB4, 0x06F4,
	0x70F6, 0x078A, 0x2F26, 0x3572
};

static const Format formats[] = {
	{ UNKNOWN, "Unknown", NULL, 0x0, Format::UNKNOWN_ENCRYPTION, NULL },
	{ DIGITAL_GIRL, "Digital Girl", "DG", 0x3, Format::TWO_CIPHER, DGRetailCode },
	{ SB3, "Sexy Beach 3", "SB3", 0x0, Format::XOR_PLUS_1, NULL },
	{ AG3, "Artificial Girl 3", "AG3", 0x3, Format::TWO_CIPHER, AG3RetailCode },
	{ SCHOOLMATE, "School Mate", "SM", 0x1, Format::XOR_32, SMRetailCode },
	{ SCHOOLMATE_SWEETS, "School Mate Sweets", "SMS", 0x3, Format::TWO_CIPHER, SMSweetsRetailCode },
	{ HAKO, "Hako", "HK", 0x3, Format::TWO_CIPHER, HakoRetailCode },
	{ AT_HOME, "@Home Mate", "AHM", 0x3, Format::TWO_CIPHER, AtHomeRetailCode },
	{ YUUSHA, "Yuusha", "YKN", 0x3, Format::TWO_CIPHER, YuushaCode },
	{ RGF, "Real Girlfriend", "RGF", 0x1, Format::XOR_32, RGFCipher },
	{ SM_FIGURE, "School Mate Figure", "SMF", 0x1, Format::UNKNOWN_ENCRYPTION, NULL },
	{ SM_TRIAL, "School Mate Trial", "SMT", 0x1, Format::XOR_32, SMTrialCode },
	{ AG3_WELCOME, "Artificial Girl 3 Welcome", "AG3W", 0x1, Format::XOR_32, AG3WelcomeCode },
	{ HAKO_TRIAL, "Hako trial", "HKT", 0x1, Format::XOR_32, HakoTrialCode },
	{ ESK_MATE, "Esk Mate", "EM", 0x1, Format::XOR_32, EskMateCipher },
	{ AT_HOME_FIGURE, "@Home Figure", "AHF", 0x1, Format::XOR_32, AtHomeFigureCode },
	{ AT_HOME_TRIAL, "@Home Trial", "AHT", 0x1, Format::XOR_32, AtHomeTrialCode },
	{ MIK_TRIAL, "MIKTrial", "MKT", 0x1, Format::XOR_32, MIKTrialCipher },
	{ SBZ, "Sexy Beach Zero", "SBZ", 0x1, Format::XOR_32, SBZCipher },
	{ CCB, "CharaColle", "CCB", 0x1, Format::XOR_32, CCBCipher }
};

static const Type deforder[] = { SB3, DIGITAL_GIRL, UNKNOWN };

const Format *
getFormat (Type type)
{
	return &formats[type];
}

const Format *
testFormat (FILE *ifs, size_t fsize, const Type searchorder[])
{
	for (int i = 0; searchorder[i] != UNKNOWN; i++) {
		fseek (ifs, 0, SEEK_SET);
		if (isFormat (ifs, fsize, &formats[searchorder[i]])) return &formats[searchorder[i]];
	}
	return &formats[UNKNOWN];
}

const Format *
testFormat (FILE *ifs, size_t fsize)
{
	return testFormat (ifs, fsize, deforder);
}

static bool
isFormatSB3 (FILE *ifs, size_t fsize)
{
	unsigned char c[32];
	// Number of files
	if (fread (c, 1, 4, ifs) != 4) return false;
	int numfiles = getI32LE (c);
	if (numfiles <= 0) return false;
	size_t headersize = numfiles * 36 + 8;
	if (fread (c, 1, 4, ifs) != 4) return false;
	int totalsizefiles = getI32LE (c);
	if (totalsizefiles <= 0) return false;
	if ((headersize + totalsizefiles) != fsize) return false;
	fseek (ifs, 32 * numfiles, SEEK_CUR);
	for (int i = 0; i < numfiles; i++) {
	if (fread (c, 1, 4, ifs) != 4) return false;
		int filesize = getI32LE (c);
		if (filesize < 0) return false;
	}
	return true;
}

static int
decryptHeaderOther (unsigned char *d, const unsigned char *s, int len)
{
	unsigned char table[] = {
		0xFA, 0x49, 0x7B, 0x1C, // var48
		0xF9, 0x4D, 0x83, 0x0A,
		0x3A, 0xE3, 0x87, 0xC2, // var24
		0xBD, 0x1E, 0xA6, 0xFE
	};

	unsigned char var28;
	for (int var4 = 0; var4 < len; var4++) {
		var28 = (unsigned char) (var4 & 0x7);
		table[var28] += table[8 + var28];
		d[var4] = s[var4] ^ table[var28];
	}

	return len;
}

static bool
isFormatOther (FILE *ifs, size_t fsize, const Format *format)
{
	unsigned char c[32];
	if (fread (c, 1, 1, ifs) != 1) return false;
	unsigned char signature;
	decryptHeaderOther (&signature, c, 1);
	if (signature != format->signature) return false;
	if (fread (c, 4, 1, ifs) != 1) return false;
	unsigned char ibuf[4];
	decryptHeaderOther (ibuf, c, 4);
	int nfiles = getI32LE (ibuf);
	int headersize = 268 * nfiles + 9;
	if ((nfiles <= 0) || (headersize <= 0) || (headersize > (int) fsize)) return false;

	unsigned char *qbuf = new unsigned char[nfiles * 268];
	size_t rlen = fread (qbuf, 1, nfiles * 268, ifs);
	if ((int) rlen != (nfiles * 268)) {
		if (ferror (ifs)) fprintf (stderr, "Error\n");
		if (feof (ifs)) fprintf (stderr, "EOF\n");
		return false;
	}
	unsigned char *buf = new unsigned char[nfiles * 268];
	decryptHeaderOther (buf, qbuf, nfiles * 268);
	delete[] qbuf;
	if (fread (c, 4, 1, ifs) != 1) return false;
	decryptHeaderOther (ibuf, c, 4);
	int fileheadersize = getI32LE (ibuf);
	delete[] buf;
	if (fileheadersize != headersize) return false;

	return true;
}

bool
isFormat (FILE *ifs, size_t fsize, const Format *format)
{
	switch (format->type) {
		case UNKNOWN:
			return true;
		case SB3:
			return isFormatSB3 (ifs, fsize);
		default:
			return isFormatOther (ifs, fsize, format);
	}
}

// FileData

FileData::FileData (const char *filename, const char *fid)
: valid(0), path(filename), format(&formats[UNKNOWN])
{
#ifdef WIN32
	struct _stat st;
	if (_wstat (Arikkei::UText(filename), &st)) return;
	if (!(st.st_mode & _S_IFREG)) return;
	FILE *ifs = _wfopen (Arikkei::UText(filename), L"rb");
#else
	struct stat st;
	if (stat (filename, &st)) return;
	if (!(st.st_mode & S_IFREG)) return;
	FILE *ifs = fopen (filename, "r");
#endif
	if (!ifs) return;
	readTable (ifs, st.st_size, fid);
	fclose (ifs);
	if (!entries.empty ()) valid = 1;
}

void
FileData::readTable (FILE *ifs, size_t fsize, const char *fid)
{
	if (fid) {
		Type testtypes[] = { UNKNOWN, UNKNOWN };
		for (int i = 0; i < NUM_TYPES; i++) {
			if (formats[i].id && !strcmp (fid, formats[i].id)) {
				testtypes[0] = formats[i].type;
			}
		}
		format = testFormat (ifs, fsize, testtypes);
	} else {
		format = testFormat (ifs, fsize);
	}
	fseek (ifs, 0, SEEK_SET);

	FileEntry e;
	if (format->type == UNKNOWN) {
		return;
	} else if (format->type == SB3) {
		unsigned char c[32];
		if (fread (c, 1, 4, ifs) != 4) return;
		int nfiles = getI32LE (c);
		// size_t cpos = 0;
		// int nfiles = getI32LE (cdata + cpos);
		// cpos += 4;
		if (fread (c, 1, 4, ifs) != 4) return;
		// int totalsize = getI32LE (cdata + cpos);
		// cpos += 4;
		unsigned char *sjisbuf = (unsigned char *) malloc (nfiles * 32);
		for (int i = 0; i < nfiles; i++) {
			fread (sjisbuf + i * 32, 1, 32, ifs);
			// const unsigned char *sjisname = cdata + cpos;
			// sjisnames.push_back (sjisname);
			// cpos += 32;
		}
		int filenum = 0;
		int offset = 36 * nfiles + 8;
		for (int i = 0; i < nfiles; i++) {
			const char *utf8name = getNameStaticSB3 (sjisbuf + i * 32, 32);
			// const char *utf8name = getNameStaticSB3 (sjisnames[i], 32);
			if (!utf8name) continue;
			// Tag should be read from offset position
			// fread (c, 1, 4, ifs);
			// e.tag = getU32LE (c);
			e.name = utf8name;
			e.start = offset;
			fread (c, 1, 4, ifs);
			e.length = getU32LE (c);
			entries.push_back (e);
			map[e.name] = filenum;
			filenum += 1;
			offset += (int) e.length;
		}
		free (sjisbuf);
		return;
	} else {
		// Common format
		if (format->type == SM_FIGURE) {
			// fixme: Implement (lauris)
		} else {
			unsigned char c[32];
			// Other formats
			unsigned char buf[4];
			fread (c, 1, 1, ifs);
			decryptHeaderOther (buf, c, 1);
			fread (c, 1, 4, ifs);
			decryptHeaderOther (buf, c, 4);
			int nfiles = getI32LE (buf);
			unsigned char *ibuf = new unsigned char [268 * nfiles];
			unsigned char *hbuf = new unsigned char [268 * nfiles];
			fread (ibuf, 1, 268 * nfiles, ifs);
			decryptHeaderOther (hbuf, ibuf, 268 * nfiles);
			delete[] ibuf;

			int filenum = 0;
			for (int i = 0; i < nfiles; i++) {
				int fileoffset = i * 268;
				const unsigned char *sjisname = hbuf + fileoffset;
				char *name = (char *) sjis_to_utf8_strdup (sjisname);
				int size = getI32LE (hbuf + fileoffset + 260);
				int offset = getI32LE (hbuf + fileoffset + 264);
				if (debug > 0) fprintf (stderr, "FileData::readTable: File %d Length %d offset %d: %s\n", i, size, offset, name);
				// e.tag = getU32LE (cdata + offset);
				e.name = name;
				e.start = offset;
				e.length = size;
				entries.push_back (e);
				map[e.name] = filenum;
				filenum += 1;

				free (name);
			}
			delete[] hbuf;
		}
	}
}

int
FileData::decodeBlockTwoChipher (unsigned char *d, const unsigned char *s, int len, const u16 *cipher)
{
	u16 a[4], b[4];
	memcpy (a, cipher, 8);
	memcpy (b, cipher + 4, 8);
	int clen = len & 0xfffffffe;
	u32 codeIdx = 0;
	for (int i = 0; i < clen; i += 2) {
		a[codeIdx] = a[codeIdx] + b[codeIdx];
		d[i] = s[i] ^ (a[codeIdx] & 0xff);
		d[i + 1] = s[i + 1] ^ (a[codeIdx] >> 8);
		codeIdx = (codeIdx + 1) & 0x3;
	}
	if (len != clen) d[clen] = s[clen];
	return len;
}

int
FileData::decodeBlockXOR32 (unsigned char *d, const unsigned char *s, int len, const u8 *cipher)
{
	int clen = len & 0xfffffffc;
	for (int i = 0; i < clen; i++) {
		d[i] = s[i] ^ cipher[i &0x1f];
	}
	for (int i = clen; i < len; i++) {
		d[i] = s[i];
	}
	return len;
	// int len = size/4;
	// for (i = 0; i < len; i++) {
	// 	((unsigned int*)buf)[i] = ((unsigned int*)buf)[i] ^ code[i&7];
	// }
}

int
FileData::decodeBlockXORPlus1 (unsigned char *d, const unsigned char *s, int len)
{
	for (int i = 0; i < len; i++) {
		d[i] = ~s[i] + 1;
	}

	return len;
}

int
FileData::decodeBlock (unsigned char *d, const unsigned char *s, int len)
{
	if (format->encryption == Format::TWO_CIPHER) {
		decodeBlockTwoChipher (d, s, len, (const u16 *) format->cipher);
	} else if (format->encryption == Format::XOR_32) {
		decodeBlockXOR32 (d, s, len, (const u8 *) format->cipher);
	} else if (format->encryption == Format::XOR_PLUS_1) {
		decodeBlockXORPlus1 (d, s, len);
	} else {
		return 0;
	}

	return len;
}

const char *
FileData::getNameStatic (const unsigned char *cdata)
{
	static unsigned char d[4096];
	unsigned char s[4096];
	int namelen = Xpp::getI32LE (cdata);
	if ((namelen < 0) || (namelen > (4096 - 1))) return NULL;
	// Name in Shift-Jis
	for (int i = 0; i < namelen; i++) s[i] = ~cdata[4 + i];
	int utf8len = sjis_to_utf8 (NULL, 4096, s, namelen);
	if ((utf8len < 0) || (utf8len > (4096 - 1))) return NULL;
	utf8len = sjis_to_utf8 (d, 4096, s, namelen);
	d[utf8len] = 0;
	return (const char *) d;
}

const char *
FileData::getNameStaticSB3 (const unsigned char *cdata, int maxlen)
{
	static unsigned char d[4096];
	unsigned char s[4096];
	if (maxlen > 4095) maxlen = 4095;
	// Name in Shift-Jis
	int namelen = 0;
	while ((namelen < maxlen) && (cdata[namelen] != 0xff)) {
		s[namelen] = ~cdata[namelen] + 1;
		namelen += 1;
	}
	int utf8len = sjis_to_utf8 (NULL, 4096, s, namelen);
	if ((utf8len < 0) || (utf8len > (4096 - 1))) return NULL;
	utf8len = sjis_to_utf8 (d, 4096, s, namelen);
	d[utf8len] = 0;
	return (const char *) d;
}

const char *
FileData::getFileName (int idx)
{
	if ((idx < 0) || (idx >= (int) entries.size ())) return NULL;
	return entries[idx].name.c_str ();
}

size_t
FileData::getFileSize (int idx)
{
	if ((idx < 0) || (idx >= (int) entries.size ())) return NULL;
	return entries[idx].length;
}

unsigned char *
FileData::getFileData (int idx, size_t *size)
{
	if ((idx < 0) || (idx >= (int) entries.size ())) return NULL;
	if (!entries[idx].length) return NULL;

	FILE *ifs;
	ifs = fopen (Arikkei::UText(path.c_str ()), "rb");
	if (!ifs) return NULL;
	fseek (ifs, entries[idx].start, SEEK_SET);
	unsigned char *s = (unsigned char *) malloc (entries[idx].length);
	fread (s, 1, entries[idx].length, ifs);
	unsigned char *d = (unsigned char *) malloc (entries[idx].length);
	decodeBlock (d, s, entries[idx].length);
	free (s);
	if (size) *size = entries[idx].length;
	fclose (ifs);
	return d;
}

// FileHandler

FileHandler::FileHandler (const char *filename, const char *fid)
: HandlerFileList(filename), data(filename, fid)
{
	_valid = data.isValid ();
	int nfiles = data.getNumFiles ();
	for (int i = 0; i < nfiles; i++) {
		const char *fname = data.getFileName (i);
		Entry *e = new Entry();
		e->id = i;
		char *cname = FileSystem::canonizeName (fname, false, true);
		size_t clen = strlen (cname);
		e->name = (char *) malloc (clen + 2);
		e->name[0] = '/';
		memcpy (e->name + 1, cname, clen);
		e->name[clen + 1] = 0;
		e->dataref = 0;
		e->csize = 0;
		e->cdata = NULL;
		entries.push_back (e);
		namedict.insert (e->name, e);
	}
}

bool
FileHandler::hasDir (const char *name)
{
	if (!name) return false;
	// "" and "/" are only allowed directories
	if (!*name || !strcmp (name, "/")) return true;
	return false;
}

bool
FileHandler::loadDir (const char *name)
{
	if (!name) return false;
	// "" and "/" are only allowed directories
	if (!*name || !strcmp (name, "/")) return true;
	return false;
}

int
FileHandler::getNumFiles (void)
{
	return data.getNumFiles ();
}

const char *
FileHandler::getFileName (int idx)
{
	return data.getFileName (idx);
}

size_t
FileHandler::getFileSize (int idx)
{
	return data.getFileSize (idx);
}

int
FileHandler::getNumSubDirs (void)
{
	return 0;
}

const char *
FileHandler::getSubDirName (int idx)
{
	return NULL;
}

void
FileHandler::addFileMapping (Entry *entry)
{
	entry->cdata = (unsigned char *) data.getFileData (entry->id, &entry->csize);
	if (entry->cdata) entry->dataref = 1;
}

// URLHandler

URLHandler::URLHandler (const char *location)
: URI::URLHandler(location)
{
	// syntax: xpp:(file[;file...])/
	char *ploc = strdup (location + 5);
	ploc[strlen (ploc) - 2] = 0;
	Arikkei::TokenChar ltoken(ploc);
	Arikkei::TokenChar tokenz[16];
	int ntokenz = ltoken.tokenize (tokenz, 16, Arikkei::TokenChar(";"), false);
	for (int i = 0; i < ntokenz; i++) {
		Arikkei::TokenChar qtokenz[2];
		int nq = tokenz[i].tokenize (qtokenz, 2, Arikkei::TokenChar(","), false);
		FileHandler *handler = new FileHandler((const char *) qtokenz[0], (nq == 2) ? (const char *) qtokenz[1] : NULL);
		handlers.push_back (handler);
	}
	free (ploc);
}

URLHandler::~URLHandler (void)
{
	for (size_t i = 0; i < handlers.size (); i++) {
		handlers[i]->unRef ();
	}
}

URI::URLHandler *
URLHandler::newURLHandler (const char *url)
{
	// syntax: xpp:(file[;file...])/
	if (!url || !*url) return NULL;
	if (strncmp (url, "xpp:(", 5)) return NULL;
	if (!strstr (url, ")/")) return NULL;
	char *purl = strdup (url);
	char *pq = strstr (purl, ")/");
	*(pq + 2) = 0;
	return new URLHandler(purl);
}

const unsigned char *
URLHandler::mmapDataRelative (const char *name, size_t *size)
{
	if (!name || !*name) return NULL;
	for (size_t i = 0; i < handlers.size (); i++) {
		const unsigned char *data = handlers[i]->mmapFile (name, size);
		if (data) return data;
	}
	return NULL;
}

void
URLHandler::munmapData (const unsigned char *data)
{
	// XPP data is owned by FileHandler
}

}; // Namespace Xpp

}; // Namespace Miletos

