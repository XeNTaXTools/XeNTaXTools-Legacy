#define __MILETOS_MESH_COLLADA_CPP__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2008-2009
//

static const int debug = 1;

#include <stdlib.h>

#include <libarikkei/dict.h>

#include <elea/geometry.h>

#include <sehle/commonmaterials.h>
#include <sehle/material-multipass-dns.h>

#include "uri.h"
#include "image.h"
#include "material.h"
#include "collada/collada_node.h"
#include "collada/collada_mesh.h"
#include "collada/collada_geometry.h"
#include "collada/collada_skin.h"
#include "collada/collada_controller.h"
#include "collada/collada_instance_controller.h"
#include "collada/collada_instance_geometry.h"
#include "collada/fx/fx_primitives.h"
#include "collada/fx/collada_bind_material.h"
#include "collada/fx/collada_instance_material.h"
#include "collada/fx/collada_material.h"
#include "collada/fx/collada_instance_effect.h"
#include "collada/fx/collada_effect.h"
#include "collada/fx/collada_profile_common.h"
#include "collada/fx/collada_technique.h"
#include "collada/fx/collada_phong.h"
#include "collada/fx/collada_sampler2d.h"
#include "collada/fx/collada_surface.h"
#include "collada/fx/collada_image.h"
#include "collada/fx/collada_newparam.h"

#include "meshcollada.h"

namespace Miletos {

// ColladaData

ColladaData::ColladaData (const unsigned char *cdata, size_t csize, const char *purl, URI::URLHandler *phandler)
: DataBlock(purl, "ColladaData"), name(purl), handler(phandler), location(purl), thedoc(NULL), mildoc(NULL), croot(NULL)
{
	handler->ref ();

	thedoc = new Thera::Document("scene");
	thedoc->root->setAttribute ("xmlns", Document::getDefaultNamespace ());
	thedoc->root->setAttribute ("xmlns:collada", Collada::getDefaultNamespace ());
	Thera::Node *colladanode = Thera::loadNode (thedoc->root, cdata, csize, (const unsigned char *) name.c_str ());
	thedoc->collateTexts ();
	if (colladanode && (colladanode->type == Thera::Node::ELEMENT) && !strcmp (colladanode->name, "COLLADA")) {
		mildoc = Miletos::Document::newDocument (thedoc->root, (const char *) location.address);
		Object *cobject = mildoc->lookupObject (colladanode->getAttribute ("id"));
		if (cobject && (cobject->isType (Collada::Root::type ()))) croot = (Collada::Root *) cobject;
	}
}

ColladaData::~ColladaData (void)
{
	delete mildoc;
	delete thedoc;
	handler->unRef ();
}

ColladaData *
ColladaData::getColladaData (const char *url)
{
	ColladaData *dae = NULL;
	if (url) {
		URI::Location loc(url);
		dae = (ColladaData *) lookupDataBlock ((const char *) loc.path, "ColladaData");
		if (dae) return dae;
		URI::URLHandler *handler = URI::getHandler ((const char *) loc.path);
		if (handler) {
			size_t csize;
			const unsigned char *cdata = handler->mmapData (loc.path, &csize);
			if (cdata) {
				dae = new ColladaData (cdata, csize, (const char *) loc.path, handler);
				handler->munmapData (cdata);
			}
			handler->unRef ();
		}
	}
	return dae;
}

// SkinnedGeometryCollada

struct ColladaTextureRef {
	std::string imageid;
	NRImage *pixels;
};

struct ColladaMaterialRef {
	std::string symbol;
	std::string inputsemantic;
	std::string semantic;
	std::string base;
	// Effect id
	std::string effectid;
	// Texture
	int texidx;
};

SkinnedGeometryCollada::SkinnedGeometryCollada (void)
: bdata(NULL)
{
}

static Object *
skinnedgeometry_collada_factory (void)
{
	return new SkinnedGeometryCollada();
}

const Object::Type *
SkinnedGeometryCollada::objectType (void)
{
	return type ();
}

const Object::Type *
SkinnedGeometryCollada::type (void)
{
	static Type *mytype = NULL;
	static const Attribute attrs[] = {
		{ "source", NULL, 0 }
	};
	if (!mytype) mytype = new Type(SkinnedGeometry::type (), "SkinnedGeometryCollada", "geometryCollada", skinnedgeometry_collada_factory, sizeof (attrs) / sizeof (attrs[0]), attrs);
	return mytype;
}

void
SkinnedGeometryCollada::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	SkinnedGeometry::build (pnode, doc, ctx);

	buildAllAttributes (type (), ctx);
}

void
SkinnedGeometryCollada::release (void)
{
	for (size_t i = 0; i < textures.size (); i++) delete textures[i];
	textures.clear ();
	for (size_t i = 0; i < materials.size (); i++) delete materials[i];
	materials.clear ();

	if (bdata) {
		bdata->unRef ();
		bdata = NULL;
	}

	SkinnedGeometry::release ();
}

void
SkinnedGeometryCollada::set (const char *attrid, const char *val)
{
	if (!strcmp (attrid, "source")) {
		loadData (val);
		requestUpdate (MODIFIED | MESH_DEFINITION_MODIFIED);
	} else {
		SkinnedGeometry::set (attrid, val);
	}
}

Sehle::Material *
SkinnedGeometryCollada::getMaterial (int matidx, Sehle::Engine *engine)
{
	Sehle::Material *mat = NULL;
	if (!materials[matidx]->effectid.empty ()) {
		Object *object = bdata->mildoc->lookupObject (materials[matidx]->effectid.c_str ());
		if (object && object->isType (Collada::Effect::type ())) {
			Collada::Effect *effect = (Collada::Effect *) object;
			mat = effect->buildMaterial (engine, bdata->handler);
		}
	}
	if (!mat) {
		Sehle::WireMaterial *wmat = Sehle::WireMaterial::newWireMaterial (engine, "test");
		float r = (float) (matidx & 1);
		float g = (float) ((matidx >> 1) & 1);
		float b = (float) ((matidx >> 2) & 1);
		wmat->setColor (Elea::Color4f(r, g, b, 1));
		mat = wmat;
	}
	return mat;
}

// fixme:

TextureInfo *
SkinnedGeometryCollada::getTextureInfo (unsigned int matidx, unsigned int texidx, unsigned int getimage)
{
	if (texidx >= (u32) ntextures) return NULL;
	if (!textures[texidx]->pixels) return NULL;
	TextureInfo *tex = new TextureInfo();
	tex->urn = strdup (textures[texidx]->imageid.c_str ());
	if (getimage) {
		tex->image = textures[texidx]->pixels;
		nr_image_ref (tex->image);
	}
	return tex;
}

u32
SkinnedGeometryCollada::getMaterialInfo (MaterialInfo *mat, u32 matidx)
{
	if (matidx >= (u32) nmaterials) return false;
	if (materials[matidx]->effectid.empty ()) return false;
	Object *object = bdata->mildoc->lookupObject (materials[matidx]->effectid.c_str ());
	if (!object || !object->isType (Collada::Effect::type ())) return false;
	Collada::Effect *effect = (Collada::Effect *) object;
	if (!effect->getMaterialInfo (mat)) return false;
	mat->diffuseTexture = materials[matidx]->texidx;
	return true;
}

bool
checkNodeWithChildren (Object *object, void *data)
{
	if (!object->isType (Collada::Node::type ())) return true;
	Collada::Node *node = (Collada::Node *) object;
	for (Object *child = node->children; child; child = child->next) {
		if (child->isType (Collada::InstanceController::type ())) {
			*((Object **) data) = object;
			return false;
		}
	}
	return true;
}

void
SkinnedGeometryCollada::loadData (const char *url)
{
	clear ();
	for (size_t i = 0; i < textures.size (); i++) delete textures[i];
	textures.clear ();
	for (size_t i = 0; i < materials.size (); i++) delete materials[i];
	materials.clear ();

	if (bdata) {
		bdata->unRef ();
		bdata = NULL;
	}

	if (!url || !*url) return;

	bdata = ColladaData::getColladaData (url);

	if (!bdata || !bdata->mildoc || !bdata->croot) return;

	URI::Location loc(url);
	Object *object = NULL;
	if (loc.reference) {
		object = bdata->mildoc->lookupObject ((const char *) loc.reference);
	} else {
		// Find first Collada node with instance controller
		bdata->mildoc->ensureUpdated (10);
		bdata->mildoc->root->forall (checkNodeWithChildren, 65535, &object);
	}
	if (!object || !object->isType (Collada::Node::type ())) return;
	bdata->mildoc->ensureUpdated (10);
	Collada::Node *node = (Collada::Node *) object;
	Collada::InstanceController *icontr = NULL;
	for (Object *child = node->children; child; child = child->next) {
		if (child->isType (Collada::InstanceController::type ())) {
			icontr = (Collada::InstanceController *) child;
			break;
		}
	}
	if (!icontr) return;
	if (!icontr->controller || !icontr->controller->skin || !icontr->controller->skin->geometry || !icontr->controller->skin->geometry->mesh) return;
	if (icontr->wcounts.empty ()) return;
	if (icontr->bones.empty ()) return;
	Collada::Skin *skin = icontr->controller->skin;
	Collada::Mesh *mesh = skin->geometry->mesh;

	// Create materials
	// Zero material
	// Material *mat = new Material();
	// materials.push_back (mat);
	// TechniqueCommon material instances
	if (icontr->bindmaterial && icontr->bindmaterial->techniquecommon) {
		Collada::TechniqueCommon *ctech = icontr->bindmaterial->techniquecommon;
		for (size_t i = 0; i < ctech->materials.size (); i++) {
			addMaterial (mesh, ctech, (int) i);
		}
	}
	ntextures = (unsigned int) textures.size ();
	nmaterials = (unsigned int) materials.size ();

	// Bones
	setNumBones ((int) icontr->bones.size ());
	for (unsigned int i = 0; i < nbones; i++) {
		Elea::Matrix4x4f bone2skin;
		icontr->bones[i].invbind.invert (&bone2skin);
		Elea::Matrix4x4f bone2parent;
		if (icontr->bones[i].parent >= 0) {
			bone2parent = icontr->bones[icontr->bones[i].parent].invbind * bone2skin;
		} else {
			bone2parent = bone2skin;
		}
		setBone (i, icontr->bones[i].name.c_str (), icontr->bones[i].parent, bone2parent);
	}
	// Update bone matrixes
	initializeBoneMatrixes ();

	// Copy bone animations from node data
	for (unsigned int i = 0; i < nbones; i++) {
		Elea::Matrix4x4f anim2parent = icontr->bones[i].transform;
		setBoneAnimation ((int) i, anim2parent);
	}


	// Set up vertices
	setNumVertices ((int) mesh->vdefs.size (), true, true, true, true);
	setNumIndices ((int) mesh->indices.size ());
	setNumWeights ((int) icontr->weights.size ());
	setNumFrags ((int) mesh->fragments.size ());

	for (unsigned int i = 0; i < nvertices; i++) {
		xbase[i] = Elea::Vector2f(mesh->vdefs[i].t[0], mesh->vdefs[i].t[1]);
		vbase[i] = skin->bindshapematrix.transformPoint3 (mesh->vdefs[i].p);
		nbase[i] = skin->bindshapematrix.transformVector3 (mesh->vdefs[i].n);
		tbase[i] = Elea::Vector3fZ;
	}

	for (unsigned int i = 0; i < nvertices; i++) wcounts[i] = icontr->wcounts[i];
	for (unsigned int i = 0; i < nweights; i++) {
		weights[i].bone = icontr->weights[i].bone;
		weights[i].weight = icontr->weights[i].weight;
	}

	for (unsigned int i = 0; i < nindices; i++) {
		indices[i] = mesh->indices[i];
	}

	for (unsigned int i = 0; i < nfrags; i++) {
		frags[i].visible = 1;
		frags[i].matidx = 0;
		for (size_t j = 1; j < materials.size (); j++) {
			if (!strcmp (mesh->fragments[i].materialname.c_str (), materials[j]->symbol.c_str ())) {
				frags[i].matidx = (u32) j;
				break;
			}
		}
		frags[i].firstindex = mesh->fragments[i].firstindex;
		frags[i].numindices = mesh->fragments[i].nindices;
	}

	// Calculate bone bounding boxes
	initializeBoneBBoxes ();

	// Update bone status
	updateBoneStatus ();

	requestUpdate (MODIFIED | ANIMATION_MODIFIED);
}

void
SkinnedGeometryCollada::addMaterial (Collada::Mesh *mesh, Collada::TechniqueCommon *ctech, int ctechmatidx)
{
	Collada::InstanceMaterial *imat = ctech->materials[ctechmatidx];

	// Create new material
	ColladaMaterialRef *m = new ColladaMaterialRef();
	materials.push_back (m);
	m->texidx = -1;
	m->symbol = imat->symbol;
	m->base = (const char *) bdata->location.base;

	// <material>
	if (!imat->material) return;
	// <instance_effect>
	if (!imat->material->effect) return;
	Collada::InstanceEffect *ieffect = imat->material->effect;
	// <effect>
	if (!ieffect->effect) return;
	m->effectid = ieffect->effect->id;
	// Look fot texture
	Collada::Effect *effect = ieffect->effect;
	Collada::Image *image = effect->getDiffuseImage ();
	if (!image) return;
	for (size_t i = 0; i < textures.size (); i++) {
		if (!textures[i]->imageid.compare (image->id)) {
			m->texidx = (int) i;
			return;
		}
	}
	m->texidx = (int) textures.size ();
	ColladaTextureRef *t = new ColladaTextureRef();
	t->imageid = image->id;
	t->pixels = image->getPixels ();
	textures.push_back (t);
}

// StaticGeometryCollada

StaticGeometryCollada::StaticGeometryCollada (void)
: StaticGeometry(HAS_CHILDREN), bdata(NULL)
{
}

static Object *
staticgeometry_collada_factory (void)
{
	return new StaticGeometryCollada();
}

const Object::Type *
StaticGeometryCollada::objectType (void)
{
	return type ();
}

const Object::Type *
StaticGeometryCollada::type (void)
{
	static Type *mytype = NULL;
	static const Attribute attrs[] = {
		{ "source", NULL, 0 }
	};
	if (!mytype) mytype = new Type(StaticGeometry::type (), "StaticGeometryCollada", "staticGeometryCollada", staticgeometry_collada_factory, sizeof (attrs) / sizeof (attrs[0]), attrs);
	return mytype;
}

void
StaticGeometryCollada::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	StaticGeometry::build (pnode, doc, ctx);

	buildAllAttributes (type (), ctx);
}

void
StaticGeometryCollada::release (void)
{
	for (size_t i = 0; i < textures.size (); i++) delete textures[i];
	textures.clear ();
	for (size_t i = 0; i < materials.size (); i++) delete materials[i];
	materials.clear ();

	if (bdata) {
		bdata->unRef ();
		bdata = NULL;
	}

	StaticGeometry::release ();
}

void
StaticGeometryCollada::set (const char *attrid, const char *val)
{
	if (!strcmp (attrid, "source")) {
		loadData (val);
		requestUpdate (MODIFIED | MESH_DEFINITION_MODIFIED);
	} else {
		StaticGeometry::set (attrid, val);
	}
}

Sehle::Material *
StaticGeometryCollada::getMaterial (int matidx, Sehle::Engine *engine)
{
	Sehle::Material *mat = NULL;
	if (!materials[matidx]->effectid.empty ()) {
		Object *object = bdata->mildoc->lookupObject (materials[matidx]->effectid.c_str ());
		if (object && object->isType (Collada::Effect::type ())) {
			Collada::Effect *effect = (Collada::Effect *) object;
			mat = effect->buildMaterial (engine, bdata->handler);
		}
	}
	if (!mat) {
		Sehle::WireMaterial *wmat = Sehle::WireMaterial::newWireMaterial (engine, "test");
		float r = (float) (matidx & 1);
		float g = (float) ((matidx >> 1) & 1);
		float b = (float) ((matidx >> 2) & 1);
		wmat->setColor (Elea::Color4f(r, g, b, 1));
		mat = wmat;
	}
	return mat;
}

// fixme:

TextureInfo *
StaticGeometryCollada::getTextureInfo (unsigned int matidx, unsigned int texidx, unsigned int getimage)
{
	if (texidx >= ntextures) return NULL;
	if (!textures[texidx]->pixels) return NULL;
	TextureInfo *tex = new TextureInfo();
	tex->urn = strdup (textures[texidx]->imageid.c_str ());
	if (getimage) {
		tex->image = textures[texidx]->pixels;
		nr_image_ref (tex->image);
	}
	return tex;
}

u32
StaticGeometryCollada::getMaterialInfo (MaterialInfo *mat, u32 matidx)
{
	if (matidx >= (u32) nmaterials) return false;
	if (materials[matidx]->effectid.empty ()) return false;
	Object *object = bdata->mildoc->lookupObject (materials[matidx]->effectid.c_str ());
	if (!object || !object->isType (Collada::Effect::type ())) return false;
	Collada::Effect *effect = (Collada::Effect *) object;
	if (!effect->getMaterialInfo (mat)) return false;
	mat->diffuseTexture = materials[matidx]->texidx;
	return true;
}

bool
check_node_with_children_geom (Object *object, void *data)
{
	if (!object->isType (Collada::Node::type ())) return true;
	Collada::Node *node = (Collada::Node *) object;
	for (Object *child = node->children; child; child = child->next) {
		if (child->isType (Collada::InstanceGeometry::type ())) {
			*((Object **) data) = object;
			return false;
		}
	}
	return true;
}

void
StaticGeometryCollada::loadData (const char *url)
{
	clear ();
	for (size_t i = 0; i < textures.size (); i++) delete textures[i];
	textures.clear ();
	for (size_t i = 0; i < materials.size (); i++) delete materials[i];
	materials.clear ();

	if (bdata) {
		bdata->unRef ();
		bdata = NULL;
	}

	if (!url || !*url) return;

	bdata = ColladaData::getColladaData (url);

	if (!bdata || !bdata->mildoc || !bdata->croot) return;

	URI::Location loc(url);
	Object *object = NULL;
	if (loc.reference) {
		object = bdata->mildoc->lookupObject ((const char *) loc.reference);
	} else {
		// Find first Collada node with instance controller
		bdata->mildoc->ensureUpdated (10);
		bdata->mildoc->root->forall (check_node_with_children_geom, 65535, &object);
	}
	if (!object || !object->isType (Collada::Node::type ())) return;
	bdata->mildoc->ensureUpdated (10);
	Collada::Node *node = (Collada::Node *) object;
	Collada::InstanceGeometry *igeom = NULL;
	for (Object *child = node->children; child; child = child->next) {
		if (child->isType (Collada::InstanceGeometry::type ())) {
			igeom = (Collada::InstanceGeometry *) child;
			break;
		}
	}
	if (!igeom) return;
	if (!igeom->geometry || !igeom->geometry->mesh) return;
	Collada::Mesh *mesh = igeom->geometry->mesh;

	// Create materials
	// TechniqueCommon material instances
	if (igeom->bindmaterial && igeom->bindmaterial->techniquecommon) {
		Collada::TechniqueCommon *ctech = igeom->bindmaterial->techniquecommon;
		for (size_t i = 0; i < ctech->materials.size (); i++) {
			addMaterial (mesh, ctech, (int) i);
		}
	}
	ntextures = (unsigned int) textures.size ();
	nmaterials = (unsigned int) materials.size ();

	// Set up vertices
	setNumVertices ((int) mesh->vdefs.size (), true, true, true);
	setNumIndices ((int) mesh->indices.size ());
	setNumFrags ((int) mesh->fragments.size ());

	for (unsigned int i = 0; i < nvertices; i++) {
		xbase[i] = Elea::Vector2f(mesh->vdefs[i].t[0], mesh->vdefs[i].t[1]);
		vbase[i] = mesh->vdefs[i].p;
		nbase[i] = mesh->vdefs[i].n;
		tbase[i] = Elea::Vector3fZ;
	}

	for (unsigned int i = 0; i < nindices; i++) {
		indices[i] = mesh->indices[i];
	}

	for (unsigned int i = 0; i < nfrags; i++) {
		frags[i].visible = 1;
		frags[i].matidx = 0;
		for (size_t j = 1; j < materials.size (); j++) {
			if (!strcmp (mesh->fragments[i].materialname.c_str (), materials[j]->symbol.c_str ())) {
				frags[i].matidx = (u32) j;
				break;
			}
		}
		frags[i].firstindex = mesh->fragments[i].firstindex;
		frags[i].numindices = mesh->fragments[i].nindices;
	}

	Elea::Geometry::calculateTangents (tbase[0], sizeof (tbase[0]), vbase[0], sizeof (vbase[0]), nbase[0], sizeof (nbase[0]), xbase[0], sizeof (xbase[0]), nvertices, indices, nindices, false);

	requestUpdate (MODIFIED | MESH_DEFINITION_MODIFIED);
}

void
StaticGeometryCollada::addMaterial (Collada::Mesh *mesh, Collada::TechniqueCommon *ctech, int ctechmatidx)
{
	Collada::InstanceMaterial *imat = ctech->materials[ctechmatidx];

	// Create new material
	ColladaMaterialRef *m = new ColladaMaterialRef();
	materials.push_back (m);
	m->texidx = -1;
	m->symbol = imat->symbol;
	m->base = (const char *) bdata->location.base;

	// <material>
	if (!imat->material) return;
	// <instance_effect>
	if (!imat->material->effect) return;
	Collada::InstanceEffect *ieffect = imat->material->effect;
	// <effect>
	if (!ieffect->effect) return;
	m->effectid = ieffect->effect->id;
	// Look fot texture
	Collada::Effect *effect = ieffect->effect;
	Collada::Image *image = effect->getDiffuseImage ();
	if (!image) return;
	for (size_t i = 0; i < textures.size (); i++) {
		if (!textures[i]->imageid.compare (image->id)) {
			m->texidx = (int) i;
			return;
		}
	}
	m->texidx = (int) textures.size ();
	ColladaTextureRef *t = new ColladaTextureRef();
	t->imageid = image->id;
	t->pixels = image->getPixels ();
	textures.push_back (t);
}

} // Namespace Miletos

