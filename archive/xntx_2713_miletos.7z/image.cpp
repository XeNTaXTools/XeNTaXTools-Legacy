#define __MILETOS_IMAGE_CPP__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2007
//

#include <malloc.h>
#include <string.h>
#include <stdio.h>

// JPEG Library

extern "C" {
// fixme: Ths is needed to avoid INT32 redefinition
// #define XMD_H
#ifdef WIN32
#include <jpeglib/jconfig.h>
#include <jpeglib/jpeglib.h>
#else
#include <jconfig.h>
#include <jpeglib.h>
#endif
// #undef XMD_H
}

#include <libpng/png.h>

#include <libarikkei/arikkei-iolib.h>

#include <libnr/nr-pixblock-transform.h>

#include "uri.h"

#include "image.h"

namespace Miletos {

unsigned int
Image::load (NRPixBlock *pxb, const char *url)
{
	URI::Location loc(url, "file");
	URI::URLHandler *handler = URI::getHandler (loc.path);
	if (!handler) return false;
	size_t csize;
	// fixme: Should we use path or address here?
	// fixme: I think path, because certain handlers do not know anything about arguments
	const unsigned char *cdata = handler->mmapData (loc.path, &csize);
	unsigned int gotit = false;
	if (cdata) {
		gotit = load (pxb, cdata, csize);
		handler->munmapData (cdata);
	}
	handler->unRef ();
	return gotit;
}

unsigned int
Image::load (NRPixBlock *pxb, const unsigned char *cdata, size_t csize)
{
	if (loadBMP (pxb, cdata, csize)) return true;
	if (loadTGA (pxb, cdata, csize)) return true;
	if (loadJPEG (pxb, cdata, csize)) return true;
	if (loadPNG (pxb, cdata, csize)) return true;
	return false;
}

static unsigned int
getPow2Ceil (u32 val)
{
	unsigned int s = 1;
	while (s < val) s <<= 1;
	return s;
}

static unsigned int
getPow2Floor (u32 val)
{
	unsigned int s = 1;
	while (s < val) s <<= 1;
	return (s == val) ? s : s >> 1;
}

static unsigned int
get_size (unsigned int size, int maxsize, unsigned int forcepowerof2)
{
	if ((int) size > maxsize) size = maxsize;
	if (forcepowerof2) size = getPow2Floor (size);
	return size;
}

unsigned int
Image::load (NRPixBlock *pxb, const char *url, int maxsize, unsigned int forcepowerof2)
{
	// fixme: We do some evil stuff here
	NRPixBlock spx;
	nr_pixblock_setup (&spx, NR_PIXBLOCK_MODE_G8, 0, 0, 0, 0, false);
	if (!load (&spx, url)) return false;
	unsigned int width = get_size (spx.area.x1 - spx.area.x0, maxsize, forcepowerof2);
	unsigned int height = get_size (spx.area.y1 - spx.area.y0, maxsize, forcepowerof2);
	if ((width < 1) || (height < 1)) {
		nr_pixblock_release (&spx);
		return false;
	}
	if ((width == (spx.area.x1 - spx.area.x0)) && (height == (spx.area.y1 - spx.area.y0))) {
		// fixme: Now this is evil
		nr_pixblock_release (pxb);
		*pxb = spx;
		return true;
	}
	nr_pixblock_release (pxb);
	nr_pixblock_setup (pxb, spx.mode, 0, 0, width, height, false);
	nr_pixblock_scale (pxb, &spx);
	nr_pixblock_release (&spx);
	return true;
}

// byte-align structures
#ifdef _MSC_VER
#	pragma pack (push, packing)
#	pragma pack (1)
#	define PACK_STRUCT
#elif defined( __GNUC__ )
#	define PACK_STRUCT	__attribute__((packed))
#else
#	error compiler not supported
#endif

struct BMPHeader {
	u8	Id[2];					//	BM - Windows 3.1x, 95, NT, 98, 2000, ME, XP
							//	BA - OS/2 Bitmap Array
							//	CI - OS/2 Color Icon
							//	CP - OS/2 Color Pointer
							//	IC - OS/2 Icon
							//	PT - OS/2 Pointer
	u32	FileSize;
	u32	Reserved;
	u32	BitmapDataOffset;
	u32	BitmapHeaderSize;	// should be 28h for windows bitmaps or
							// 0Ch for OS/2 1.x or F0h for OS/2 2.x
	u32 Width;
	u32 Height;
	u16 Planes;
	u16 BPP;					// 1: Monochrome bitmap
								// 4: 16 color bitmap
								// 8: 256 color bitmap
								// 16: 16bit (high color) bitmap
								// 24: 24bit (true color) bitmap
								// 32: 32bit (true color) bitmap

	u32  Compression;			// 0: none (Also identified by BI_RGB)
								// 1: RLE 8-bit / pixel (Also identified by BI_RLE4)
								// 2: RLE 4-bit / pixel (Also identified by BI_RLE8)
								// 3: Bitfields  (Also identified by BI_BITFIELDS)

	u32  BitmapDataSize;		// Size of the bitmap data in bytes. This number must be rounded to the next 4 byte boundary.
	u32  PixelPerMeterX;
	u32  PixelPerMeterY;
	u32  Colors;
	u32  ImportantColors;
} PACK_STRUCT;

unsigned int
Image::loadBMP (NRPixBlock *pxb, const unsigned char *cdata, size_t csize)
{
	return loadBMP (pxb, cdata, csize, "BM");
}

unsigned int
Image::loadBMP (NRPixBlock *pxb, const unsigned char *cdata, size_t csize, const char id[])
{
	if (csize < sizeof (BMPHeader)) return false;
	const BMPHeader& hdr(*((BMPHeader *) cdata));
	if ((hdr.Id[0] != (u8) id[0]) || (hdr.Id[1] != (u8) id[1])) return false;
	if (hdr.Compression != 0) return false;
	if ((hdr.BPP != 24) && (hdr.BPP != 32) && (hdr.BPP != 8)) return false;
	int sbpp = hdr.BPP >> 3;
	int type = (hdr.BPP == 32) ? NR_PIXBLOCK_MODE_R8G8B8A8N : NR_PIXBLOCK_MODE_R8G8B8;
	int dbpp = (type == NR_PIXBLOCK_MODE_R8G8B8) ? 3 : 4;
	int width = hdr.Width;
	int height = hdr.Height;

	nr_pixblock_release (pxb);
	nr_pixblock_setup (pxb, type, 0, 0, width, height, false);

	u32 *palette = NULL;
	if (sbpp == 1) {
		palette = (u32 *) (cdata + sizeof (BMPHeader));
	}
	int bmprs = ((hdr.Width * sbpp) + 3) & 0xfffffffc;
	for (int y = 0; y < height; y++) {
		// u8 *d = pxb.getRow (height - 1 - y);
		u8 *d = NR_PIXBLOCK_PX (pxb) + y * pxb->rs;
		u8 *s = (u8 *) cdata + hdr.BitmapDataOffset + y * bmprs;
		for (int x = 0; x < width; x++) {
			if (sbpp == 1) {
				d[0] = (palette[s[0]] >> 16) & 255;
				d[1] = (palette[s[0]] >> 8) & 255;
				d[2] = (palette[s[0]] >> 0) & 255;
			} else {
				d[0] = s[2];
				d[1] = s[1];
				d[2] = s[0];
				if (dbpp == 4) d[3] = 255;
			}
			s += sbpp;
			d += dbpp;
		}
	}

	pxb->empty = 0;

	return true;
}

struct TGAHeader {
	u8  identsize;          // size of ID field that follows 18 byte header (0 usually)
	u8  colourmaptype;      // type of colour map 0=none, 1=has palette
    u8  imagetype;          // type of image 0=none,1=indexed,2=rgb,3=grey,+8=rle packed

	u16 colourmapstart;     // first colour map entry in palette
	u16 colourmaplength;    // number of colours in palette
	u8 colourmapbits;      // number of bits per palette entry 15,16,24,32

	u16 xstart;             // image x origin
	u16 ystart;             // image y origin
	u16 width;              // image width in pixels
	u16 height;             // image height in pixels
	u8 bits;               // image bits per pixel 8,16,24,32
	u8 descriptor;         // image descriptor bits (vh flip bits)

	// pixel data follows header
} PACK_STRUCT;

unsigned int
Image::loadTGA (NRPixBlock *pxb, const unsigned char *cdata, size_t csize)
{
	if (csize < sizeof (TGAHeader)) return false;
	const TGAHeader& hdr(*((TGAHeader *) cdata));
	if (hdr.colourmaptype != 0) return false;
	if (hdr.imagetype != 2) return false;
	if ((hdr.bits != 24) && (hdr.bits != 32)) return false;
	int bpp = hdr.bits >> 3;
	int type = (hdr.bits == 24) ? NR_PIXBLOCK_MODE_R8G8B8 : NR_PIXBLOCK_MODE_R8G8B8A8N;
	int width = hdr.width;
	int height = hdr.height;

	nr_pixblock_release (pxb);
	nr_pixblock_setup (pxb, type, 0, 0, width, height, false);

	int bmprs = hdr.width * bpp;
	bool fliph = (hdr.descriptor & 0x10) != 0;
	bool flipv = (hdr.descriptor & 0x20) != 0;
	for (int y = 0; y < height; y++) {
		u8 *d = NR_PIXBLOCK_PX (pxb) + y * pxb->rs;
		int sy = y;
		if (flipv) sy = hdr.height - 1 - sy;
		for (int x = 0; x < width; x++) {
			int sx = x;
			if (fliph) sx = hdr.width - 1 - sx;
			u8 *s = (u8 *) cdata + sizeof (TGAHeader) + hdr.identsize + sy * bmprs + sx * bpp;
			d[0] = s[2];
			d[1] = s[1];
			d[2] = s[0];
			if (bpp == 4) d[3] = s[3];
			d += bpp;
		}
	}

	pxb->empty = 0;

	return true;
}

/*	Initialize source.  This is called by jpeg_read_header() before any
data is actually read.  Unlike init_destination(), it may leave
bytes_in_buffer set to 0 (in which case a fill_input_buffer() call
will occur immediately). */

static void
init_source (j_decompress_ptr cinfo)
{
	// DO NOTHING
}

/*	This is called whenever bytes_in_buffer has reached zero and more
data is wanted.  In typical applications, it should read fresh data
into the buffer (ignoring the current state of next_input_byte and
bytes_in_buffer), reset the pointer & count to the start of the
buffer, and return TRUE indicating that the buffer has been reloaded.
It is not necessary to fill the buffer entirely, only to obtain at
least one more byte.  bytes_in_buffer MUST be set to a positive value
if TRUE is returned.  A FALSE return should only be used when I/O
suspension is desired (this mode is discussed in the next section). */

static boolean
fill_input_buffer (j_decompress_ptr cinfo)
{
	// DO NOTHING
	return 1;
}

/* Skip num_bytes worth of data.  The buffer pointer and count should
be advanced over num_bytes input bytes, refilling the buffer as
needed.  This is used to skip over a potentially large amount of
uninteresting data (such as an APPn marker).  In some applications
it may be possible to optimize away the reading of the skipped data,
but it's not clear that being smart is worth much trouble; large
skips are uncommon.  bytes_in_buffer may be zero on return.
A zero or negative skip count should be treated as a no-op. */

static void
skip_input_data (j_decompress_ptr cinfo, long count)
{
	jpeg_source_mgr * src = cinfo->src;
	if(count > 0)
	{
		src->bytes_in_buffer -= count;
		src->next_input_byte += count;
	}
}

/* This routine is called only when the decompressor has failed to find
a restart (RSTn) marker where one is expected.  Its mission is to
find a suitable point for resuming decompression.  For most
applications, we recommend that you just use the default resync
procedure, jpeg_resync_to_restart().  However, if you are able to back
up in the input data stream, or if you have a-priori knowledge about
the likely location of restart markers, you may be able to do better.
Read the read_restart_marker() and jpeg_resync_to_restart() routines
in jdmarker.c if you think you'd like to implement your own resync
procedure. */

#if 0
static void
resync_to_restart (j_decompress_ptr cinfo, long desired)
{
	// DO NOTHING
}
#endif

/* Terminate source --- called by jpeg_finish_decompress() after all
data has been read.  Often a no-op. */

static void
term_source (j_decompress_ptr cinfo)
{
	// DO NOTHING
}
	
unsigned int
Image::loadJPEG (NRPixBlock *pxb, const unsigned char *cdata, size_t csize)
{
	i32 jfif = 0;
	if (csize < (6 + sizeof (i32))) return false;
	memcpy (&jfif, cdata + 6, sizeof (jfif));
	if ((jfif != 0x4a464946) && (jfif != 0x4649464a)) return false;

	struct jpeg_decompress_struct cinfo;

	// allocate and initialize JPEG decompression object
	struct jpeg_error_mgr jerr;

	//We have to set up the error handler first, in case the initialization
	//step fails.  (Unlikely, but it could happen if you are out of memory.)
	//This routine fills in the contents of struct jerr, and returns jerr's
	//address which we place into the link field in cinfo.
	
	cinfo.err = jpeg_std_error(&jerr);
	// Now we can initialize the JPEG decompression object. 
	jpeg_create_decompress(&cinfo);

	// specify data source
	jpeg_source_mgr jsrc;

	// Set up data pointer
	jsrc.bytes_in_buffer = csize;
	jsrc.next_input_byte = (JOCTET *) cdata;
	cinfo.src = &jsrc;

	jsrc.init_source = init_source;
	jsrc.fill_input_buffer = fill_input_buffer;
	jsrc.skip_input_data = skip_input_data;
	jsrc.resync_to_restart = jpeg_resync_to_restart;
	jsrc.term_source = term_source;

	// Decodes JPG input from whatever source
	// Does everything AFTER jpeg_create_decompress
	// and BEFORE jpeg_destroy_decompress
	// Caller is responsible for arranging these + setting up cinfo

	// read file parameters with jpeg_read_header() 
	(void) jpeg_read_header (&cinfo, TRUE);

	// Start decompressor
	(void) jpeg_start_decompress(&cinfo);

	bool greyscale = (cinfo.jpeg_color_space == JCS_GRAYSCALE);

	// Get image data
	nr_pixblock_release (pxb);
	nr_pixblock_setup (pxb, (greyscale) ? NR_PIXBLOCK_MODE_G8 : NR_PIXBLOCK_MODE_R8G8B8, 0, 0, cinfo.image_width, cinfo.image_height, false);

	// Here we use the library's state variable cinfo.output_scanline as the
	// loop counter, so that we don't have to keep track ourselves.
	// Create array of row pointers for lib
	u8 **rowPtr = new u8 *[cinfo.image_height];

	for (unsigned int i = 0; i < cinfo.image_height; i++) rowPtr[i] = NR_PIXBLOCK_PX (pxb) + (cinfo.image_height - 1 - i) * pxb->rs;

	unsigned int rowsRead = 0;

	while (cinfo.output_scanline < cinfo.output_height) {
		rowsRead += jpeg_read_scanlines (&cinfo, &rowPtr[rowsRead], cinfo.output_height - rowsRead);
	}

	delete [] rowPtr;
	// Finish decompression

	(void) jpeg_finish_decompress(&cinfo);

	// Release JPEG decompression object

	// This is an important step since it will release a good deal of memory.
	jpeg_destroy_decompress(&cinfo);

	pxb->empty = 0;

	return true;
}

static void
png_cpexcept_error (png_structp png_ptr, png_const_charp msg) 
{ 
   if (png_ptr) {
		fprintf (stderr, "PNG ERROR: %s", msg);
   }
} 

struct FileData {
	const char *_cdata;
	size_t _cpos;
	size_t _csize;
	FileData (const char *cdata, size_t cpos, size_t csize) : _cdata(cdata), _cpos(cpos), _csize(csize) {}
};

static void
user_read_data_fcn (png_structp png_ptr, png_bytep data, png_size_t length)
{
	FileData *fdata = (FileData *) png_ptr->io_ptr;
	if ((fdata->_cpos + length) > fdata->_csize) {
		png_error (png_ptr, "overflow");
		return;
	}
	memcpy (data, fdata->_cdata + fdata->_cpos, length);
	fdata->_cpos += length;
} 


unsigned int
Image::loadPNG (NRPixBlock *pxb, const unsigned char *cdata, size_t csize)
{
	if (!cdata || (csize < 8)) return false;
	if (!png_check_sig ((png_bytep) cdata, 8)) return false;

	png_structp png_ptr; 
	png_infop info_ptr; 


	// Allocate the png read struct 
	png_ptr = png_create_read_struct (PNG_LIBPNG_VER_STRING, 0 , (png_error_ptr) png_cpexcept_error, (png_error_ptr) 0); 
	if (!png_ptr) {
		fprintf (stderr, "PixBlock::loadPNG: Cannot allocate PNG read struct\n");
		return false;
	}

	// Allocate the png info struct 
	info_ptr = png_create_info_struct (png_ptr);
	if (!info_ptr) {
		fprintf (stderr, "PixBlock::loadPNG: Cannot allocate PNG info struct\n");
		png_destroy_read_struct (&png_ptr, 0, 0); 
		return false;
	}

	FileData fdata ((const char *) cdata, 8, csize);
	png_set_read_fn (png_ptr, &fdata, user_read_data_fcn); 
	// Tell png that we read the signature 
	png_set_sig_bytes (png_ptr, 8);
	// Read the info section of the png file 
	png_read_info (png_ptr, info_ptr);

	// Extract info 
	png_uint_32 width, height;
	int bitdepth, colortype, interlace, compression, filter;
	png_get_IHDR (png_ptr, info_ptr, &width, &height, &bitdepth, &colortype, &interlace, &compression, &filter);

	if (bitdepth > 8) {
		fprintf (stderr, "PixBlock::loadPNG: Only 8-bit channels supported\n");
		png_destroy_read_struct (&png_ptr, &info_ptr, 0); 
		return false;
	} else if (bitdepth != 8) {
		png_set_gray_1_2_4_to_8 (png_ptr);
	}
	
	int type;
	int bpp;
	if (!(colortype & PNG_COLOR_MASK_COLOR)) {
		fprintf (stderr, "PixBlock::loadPNG: Only RGB and RGBA formats supported\n");
		png_destroy_read_struct (&png_ptr, 0, 0); 
		return false;
	}
	if (colortype & PNG_COLOR_MASK_PALETTE) {
		png_set_palette_to_rgb (png_ptr);
	}
	if (colortype & PNG_COLOR_MASK_ALPHA) {
		type = NR_PIXBLOCK_MODE_R8G8B8A8N;
		bpp = 4;
	} else {
		type = NR_PIXBLOCK_MODE_R8G8B8;
		bpp = 3;
	}
	
	if (interlace != PNG_INTERLACE_NONE) {
		fprintf (stderr, "PixBlock::loadPNG: Interlaced formats not supported\n");
		png_destroy_read_struct (&png_ptr, &info_ptr, 0); 
		return false;
	}

	// Update the changes 
	png_read_update_info (png_ptr, info_ptr); 

	png_get_IHDR (png_ptr, info_ptr, (png_uint_32*) &width, (png_uint_32*) &height, &bitdepth,&colortype, &interlace, &compression, &filter);

	// Check the number of bytes per row 
	// u32 bytes_per_row = png_get_rowbytes (png_ptr, info_ptr);

	nr_pixblock_release (pxb);
	nr_pixblock_setup (pxb, type, 0, 0, width, height, false);

	for (u32 y = 0; y < height; y++) {
		png_read_row (png_ptr, (png_bytep) (NR_PIXBLOCK_PX (pxb) + (height - 1 - y) * pxb->rs), 0);
	}

	png_destroy_read_struct (&png_ptr, &info_ptr, 0);

	pxb->empty = 0;

	return true;
}

struct PNGWriter {
	unsigned char *cdata;
	u32 csize;
	u32 cpos;
};

void
png_write_data (png_struct *png, unsigned char *bytes, size_t size)
{
	PNGWriter *pngw = (PNGWriter *) png->io_ptr;
	if (pngw->cdata && ((pngw->cpos + size) <= pngw->csize)) {
		memcpy (pngw->cdata + pngw->cpos, bytes, size);
	}
	pngw->cpos += (u32) size;
}

unsigned int
Image::writePNG (const NRPixBlock *pxb, unsigned char *cdata, u32 csize)
{
	png_struct *png;
	png_info *pnginfo;

	PNGWriter pngw;
	pngw.cdata = cdata;
	pngw.csize = csize;
	pngw.cpos = 0;

	png = png_create_write_struct (PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
	if (!png) return NULL;

	pnginfo = png_create_info_struct (png);
	if (!pnginfo) {
		png_destroy_write_struct (&png, NULL);
		return NULL;
	}

	if (setjmp (png->jmpbuf)) {
		// Error occured
		png_destroy_write_struct (&png, &pnginfo);
		if (pngw.cdata) free (pngw.cdata);
		return FALSE;
	}

	// Register write method
	png_set_write_fn (png, &pngw, png_write_data, NULL);

	int colortype = PNG_COLOR_TYPE_RGB_ALPHA;
	if (pxb->mode == NR_PIXBLOCK_MODE_R8G8B8) {
		colortype = PNG_COLOR_TYPE_RGB;
	} else if (pxb->mode == NR_PIXBLOCK_MODE_G8) {
		colortype = PNG_COLOR_TYPE_GRAY;
	}
	png_set_IHDR(png, pnginfo, pxb->area.x1 - pxb->area.x0, pxb->area.y1 - pxb->area.y0, 8, colortype, PNG_INTERLACE_NONE, PNG_COMPRESSION_TYPE_BASE, PNG_FILTER_TYPE_BASE);

	// Set channel bitdepths
	png_color_8 sig_bit;
	sig_bit.red = 8;
	sig_bit.green = 8;
	sig_bit.blue = 8;
	sig_bit.alpha = 8;
	png_set_sBIT (png, pnginfo, &sig_bit);

	png_set_sRGB(png, pnginfo, PNG_sRGB_INTENT_ABSOLUTE);
	// png_set_gAMA (png, pnginfo, 1.0);

	// Comment
	png_text text_ptr[3];
	text_ptr[0].key = (char *) "Software";
	text_ptr[0].text = (char *) "SDLMu";
	text_ptr[0].compression = PNG_TEXT_COMPRESSION_NONE;
	png_set_text (png, pnginfo, text_ptr, 1);

	// Write header
	png_write_info (png, pnginfo);

	// Write images
	int height = pxb->area.y1 - pxb->area.y0;
	for (int y = 0; y < height; y++) {
		png_write_row (png, (png_bytep) (NR_PIXBLOCK_PX (pxb) + (height - 1 - y) * pxb->rs));
	}

	// Finish
	png_write_end (png, pnginfo);

	// Cleanup
	png_destroy_write_struct (&png, &pnginfo);

	return pngw.cpos;
}

unsigned int
Image::writePNG (const NRPixBlock *pxb, const char *filename)
{
	u32 csize;
	csize = writePNG (pxb, NULL, 0);
	if (csize > 0) {
		unsigned char *cdata = (unsigned char *) malloc (csize);
		writePNG (pxb, cdata, csize);
		FILE *ofs = arikkei_fopen ((const unsigned char *) filename, (const unsigned char *) "wb");
		if (ofs) {
			fwrite (cdata, 1, csize, ofs);
			fclose (ofs);
		}
		free (cdata);
	}
	return csize;
}

} // Namespace Miletos

