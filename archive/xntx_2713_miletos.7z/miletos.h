#ifndef __MILETOS_H__
#define __MILETOS_H__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2007
//

#ifdef WITH_JAVA
#include <jni.h>
#endif

#include <elea/matrix.h>

#include <thera/thera.h>

#include <sehle/sehle.h>

#include <miletos/types.h>
#include <miletos/signal.h>

namespace Miletos {

class Document;
class Object;
class Scene;
class Light;
class ParticleEmitter;

class Document {
private:
	struct Dict;
	// New object id counter
	unsigned int _numid;
	// Object dictionary
	Dict *_dict;
	// Update requested
	bool _updatereq;
	// Modified requested
	bool _modifiedreq;
	// Size of timers array
	int sizetimers;
	// Size of lights array
	int sizelights;

	// Constructor
	Document (Scene *scene, const char *url);

public:
	// Location
	char *url;
	// Root node
	Scene *root;

	// Timers
	// fixme: Implement delay requests (Lauris)
	int numtimers;
	Object **timers;
	// Lights
	int numlights;
	Light **lights;

	// Signals
	Signals::Signal1<void, Document *> sig_destroy;
	Signals::Signal1<void, Document *> sig_modified;
	// Document, oldurl, newurl
	Signals::Signal3<void, Document *, const char *, const char *> sig_url_changed;
	// Document, parent, ref
	Signals::Signal3<void, Document *, Object *, Object *> sig_object_added;
	// Document, parent, ref, child does not exist anymore
	Signals::Signal3<void, Document *, Object *, Object *> sig_object_removed;
	// Document, parent, oldref, ref
	Signals::Signal4<void, Document *, Object *, Object *, Object *> sig_order_changed;
	Signals::Signal3<void, Document *, Object *, unsigned int> sig_object_modified;

	// Destructor
	virtual ~Document (void);

	// Static constructor
	static Document *newDocument (Thera::Node *node, const char *url);

	// Update handling
	void requestUpdate (void);
	void requestModified (void);
	void invokeUpdate (void);

	// Attach sehle engine
	void show (Sehle::Graph *graph);
	void hide (void);

	// Id management
	void defineObject (Object *object);
	Object *lookupObject (const char *id);
	void undefObject (const Object *object);
	const char *getUniqueId (Object *object);
	// Bookkeeping
	void addIdentityChangeListener (const char *pidentity, Object *pobject);
	void removeIdentityChangeListener (const char *pidentity, Object *pobject);
	void removeIdentityChangeListeners (Object *pobject);
	void identityAdded (const char *pidentity, Object *pobject);
	void identityRemoved (const char *pidentity);
	unsigned int isIdentityTracked (const char *id);

	// Access
	Thera::Document *getTheraDocument (void);
	Thera::Node *getTheraRootNode (void);
	Scene *getRootNode (void) { return root; }
	void setURL (const char *url);
	void addTimer (Object *ptimer);
	void removeTimer (Object *ptimer);
	void addLight (Light *plight);
	void removeLight (Light *plight);

	// Management
	void ensureUpdated (int maxretries);

	// Timer
	void timeStep (double time);

	// Default namespace
	static const char *getDefaultNamespace (void);

	// Create new object
	Object *newObject (Thera::Node::Type type, const char *defaultns, const char *name);

#ifdef WITH_JAVA
private:
	jobject javaobject;
	void releaseJavaDocument (JNIEnv *env);
public:
	JNIEnv *javaenv;
	jobject getJavaDocument (JNIEnv *env);
#endif
};

class Object {
public:
	// Object flags
	// Object manages children tree itself
	static const int HAS_CHILDREN = 1;
	// Update/Modified flags
	// Object internal state is modified
	static const int MODIFIED = 1;
	// Some of object children are modified
	static const int CHILD_MODIFIED = 2;
	// Object parent is modified
	static const int PARENT_MODIFIED = 4;
	// Object/Parent style is modified
	static const int STYLE_MODIFIED = 8;
	// Item transformation is modified
	static const int TRANSFORMATION_MODIFIED = 16;
	// Object animation is modified
	static const int ANIMATION_MODIFIED = 32;
	// Children were added/removed to object
	static const int TREE_MODIFIED = 64;
	// Flags that mark object as modified (1111011)
	static const int MODIFIED_STATE = 0xfffb;
	// Flags that propagate to children (0011100)
	static const int MODIFIED_CASCADE = 0x1c;

	// Attribute
	struct Attribute {
		const char *key;
		const char *defvalue;
		u32 mandatory;
	};

	// Type system
	struct Type {
	public:
		const Type *parent;
		const char *name;
		const char *tag;
		Object * (*factory) (void);
		u32 nattributes;
		const Attribute *attributes;
		// Constructor
		Type (const Type *parent, const char *name, const char *tag, Object * (*factory) (void), u32 nattributes, const Attribute *attributes);
#ifdef WITH_JAVA
	private:
		jobject javaobject;
	public:
		jobject getJavaObject (JNIEnv *env) const;
#endif
	};

	// Build context
	struct BuildCtx {
		const char *defaultns;
	};

	// Update context
	struct UpdateCtx {
		Elea::Matrix4x4f i2w;
	};
protected:
	unsigned int _flags;
	unsigned int _uflags;
	unsigned int _mflags;
private:
	// Type system
	virtual const Type *objectType (void);

	// Thera node handlers
	static unsigned int node_add_child (Thera::Node *node, Thera::Node *child, Thera::Node *ref, void *data);
	static void node_child_added (Thera::Node *node, Thera::Node *child, Thera::Node *ref, void *data);
	static unsigned int node_remove_child (Thera::Node *node, Thera::Node *child, Thera::Node *ref, void *data);
	static void node_child_removed (Thera::Node *node, Thera::Node *child, Thera::Node *ref, void *data);
	static unsigned int node_change_attr (Thera::Node *node, const char *key, const char *oldval, const char *newval, void *data);
	static void node_attr_changed (Thera::Node *node, const char *key, const char *oldval, const char *newval, void *data);
	static unsigned int node_change_content (Thera::Node *node, const char *oldcontent, const char *newcontent, void *data);
	static void node_content_changed (Thera::Node *node, const char *oldcontent, const char *newcontent, void *data);

protected:
	// Default namespace
	const char *defaultns;

	// Constructor
	Object (unsigned int flags);

	// Scene tree implementation
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx) = 0;
	virtual void release (void);
	virtual unsigned int changeAttr (const char *attrid, const char *val) { return 1; }
	virtual void set (const char *attrid, const char *val) {}
	virtual void write (const char *attrid) {}
	virtual unsigned int changeContent (const char *val) { return 0; }
	virtual void setContent (const char *val) {}
	virtual unsigned int addChild (Thera::Node *cnode, Thera::Node *rnode);
	virtual Object *childAdded (Thera::Node *cnode, Thera::Node *rnode);
	virtual unsigned int removeChild (Thera::Node *cnode, Thera::Node *rnode);
	virtual void childRemoved (Thera::Node *cnode, Thera::Node *rnode);

	// Default implementation invokes update for children
	virtual void update (UpdateCtx *ctx, unsigned int flags);
	// Default implementation invokes modified for children
	virtual void modified (unsigned int flags);
	// Run timer of this object
	virtual void timeStep (double time) {}

	// Slot for listening identity adding and deletion
	virtual void identityAdded (Document *pdocument, const char *pidentity, Object *pobject) {}
	virtual void identityRemoved (Document *pdocument, const char *pidentity) {}

	// Attachment handlers
	virtual void attachedObjectRelease (Object *attached, void *data) {}
	virtual void attachedObjectModified (Object *attached, unsigned int flags, void *data) {}

	// Update handling
	void requestUpdate (int flags);
	// Updating always requests modified too, so this is needed only if we want to use special flags
	void requestModified (int flags);
	void invokeChildrenUpdate (UpdateCtx *ctx, unsigned int flags);
	// Helper
	void setFlags (unsigned int flags) { _flags |= flags; }
	void clearFlags (unsigned int flags) { _flags &= ~flags; }
	// Build object attribute
	void buildAttribute (const char *attrid);
	// Build all attributes of type (except id for object), non-recursively
	void buildAllAttributes (const Type *type, BuildCtx *ctx);
	// fixme: Implement (Lauris)
	void buildAttributeRef (const char *attrid, BuildCtx *ctx) { buildAttribute (attrid); }
public:
	char *id;
	Thera::Node *node;
	Document *document;
	Object *next;
	Object *children;
	Object *parent;
	int attachcount;

	// Destructor
	virtual ~Object (void);

	// Signals
	Signals::Signal1<void, Object *> sig_release;
	Signals::Signal2<void, Object *, Object *> sig_child_added;
	Signals::Signal2<void, Object *, Object *> sig_remove_child;
	Signals::Signal2<void, Object *, const char *> sig_attr_changed;
	Signals::Signal1<void, Object *> sig_content_changed;
	Signals::Signal2<void, Object *, unsigned int> sig_modified;

	// Access
	bool needUpdate (void) const { return (_uflags & MODIFIED_STATE) != 0; }
	bool updateFlagIsSet (unsigned int flags) { return (_uflags & flags) != 0; }
	bool needModified (void) const { return (_mflags & MODIFIED_STATE) != 0; }
	bool modifiedFlagIsSet (unsigned int flags) { return (_uflags & flags) != 0; }
	bool modifiedIsScheduled (void) { return needUpdate () || needModified (); }

	// Management
	void invokeBuild (Thera::Node *pnode, Document *pdoc, BuildCtx *ctx);
	void invokeRelease (void);
	void invokeSet (const char *attrid, const char *val) { set (attrid, val); }
	void invokeUpdate (UpdateCtx *ctx, unsigned int flags);
	void invokeModified (unsigned int flags);
	void invokeTimeStep (double time) { timeStep (time); }

	// Bookkeeping
	void invokeIdentityAdded (Document *pdocument, const char *pidentity, Object *pobject) { identityAdded (pdocument, pidentity, pobject); }
	void invokeIdentityRemoved (Document *pdocument, const char *pidentity) { identityRemoved (pdocument, pidentity); }

	// Attachment
	void attach (Object *attachto);
	void detach (Object *attachedto);

	// Helpers
	void readAttr (const char *attrid);
	void writeAttr (const char *attrid);

	// Type system
	static const Type *type (void);
	const Type *getType (void) { return objectType (); }
	bool isType (const Type *type);

	// Helpers
	bool isParent (Object *pparent);

	// If handler return false cycle will stop
	bool forall (bool (* handler) (Object *, void *), unsigned int maxdepth, void *data);
	// If detached is false we branches with root of wrong type
	bool forallOfType (const Type *type, bool (* handler) (Object *, void *), unsigned int maxdepth, unsigned int detached, void *data);
	// Build list of all children of given type
	// Frees current list, if present, ignores excluded children
	// Returns the number of children in list
	u32 listChildrenOfType (const Type *ptype, Object ***plist, const Thera::Node *pexclude);

#ifdef WITH_JAVA
private:
	void releaseJavaObject (JNIEnv *env);
protected:
	jobject javaobject;
public:
	jobject getJavaObject (JNIEnv *env);
#endif
};

} // Namespace Miletos

#endif

