#define __MILETOS_FIGURE_CPP__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2009
//

#include <elea/line.h>

#include <sehle/renderable.h>

#include "skeleton.h"
#include "bone.h"
#include "skinnedgeometry.h"
#include "poseableitem.h"

#include "figure.h"

namespace Miletos {

Figure::Figure (void)
: Item(HAS_CHILDREN), skeleton(NULL)
{
}

static Object *
figure_factory (void)
{
	return new Figure();
}

const Object::Type *
Figure::objectType (void)
{
	return type ();
}

const Object::Type *
Figure::type (void)
{
	static Type *mytype = NULL;
	if (!mytype) mytype = new Type(Item::type (), "Figure", "figure", figure_factory, 0, NULL);
	return mytype;
}

void
Figure::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	Item::build (pnode, doc, ctx);
	updateChildData (NULL);
}

void
Figure::release (void)
{
	clearSkeletonLinks ();
	Item::release ();
}

Object *
Figure::childAdded (Thera::Node *cnode, Thera::Node *rnode)
{
	clearSkeletonLinks ();
	Object *child = Item::childAdded (cnode, rnode);
	updateChildData (NULL);
	if (renderable) {
		if (child->isType (Item::type ())) {
			Sehle::Renderable *rchild = ((Item *) child)->invokeShow (renderable->graph, 0xffffffff);
			if (rchild) ((Sehle::RenderableGroup *) renderable)->prependChild (rchild);
		} else if (child->isType (PoseableGeometry::type ())) {
			Sehle::Renderable *rchild = ((PoseableGeometry *) child)->show (renderable->graph, 0xffffffff);
			if (rchild) ((Sehle::RenderableGroup *) renderable)->prependChild (rchild);
		}
	}
	return child;
}

void
Figure::childRemoved (Thera::Node *cnode, Thera::Node *rnode)
{
	clearSkeletonLinks ();
	if (renderable) {
		for (Object *child = children; child; child = child->next) {
			if (child->node == cnode) {
				if (child->isType (Item::type ())) {
					((Item *) child)->invokeHide ((Sehle::RenderableGroup *) renderable);
				} else if (child->isType (PoseableGeometry::type ())) {
					((PoseableGeometry *) child)->hide ((Sehle::RenderableGroup *) renderable);
				}
				break;
			}
		}
	}
	updateChildData (cnode);
	Item::childRemoved (cnode, rnode);
}

void
Figure::set (const char *attrid, const char *val)
{
	Item::set (attrid, val);
}

void
Figure::write (const char *attrid)
{
	Item::write (attrid);
}

void
Figure::update (UpdateCtx *ctx, unsigned int flags)
{
	bool update_links = false;
	if (skeleton) {
		if ((flags & Skeleton::BONE_STRUCTURE_MODIFIED) || skeleton->updateFlagIsSet (Skeleton::BONE_STRUCTURE_MODIFIED)) {
			update_links = true;
			// requestUpdate (BONE_STRUCTURE_MODIFIED);
		}
	}

	// Rewrite flags
	if (flags & MODIFIED) flags |= PARENT_MODIFIED;
	flags &= MODIFIED_CASCADE;

	// Update children
	for (Object *child = children; child; child = child->next) {
		if (flags || child->updateFlagIsSet (MODIFIED_STATE)) {
			if (child->isType (Item::type ())) {
				UpdateCtx cctx;
				cctx.i2w = ctx->i2w * ((Item *) child)->getI2P ();
				child->invokeUpdate (&cctx, flags);
			} else if (false && child->isType (PoseableGeometry::type ())) {
				UpdateCtx cctx;
				cctx.i2w = ctx->i2w * ((PoseableGeometry *) child)->s2m;
				child->invokeUpdate (&cctx, flags);
			} else {
				child->invokeUpdate (ctx, flags);
			}
		}
	}

	if (update_links) {
		updateSkeletonLinks ();
	}

	bbox.setEmpty ();
	for (Object *child = children; child; child = child->next) {
		if (child->isType (Item::type ())) {
			bbox.grow (((Item *) child)->bbox);
		} else if (child->isType (PoseableGeometry::type ())) {
			bbox.grow (((PoseableGeometry *) child)->bbox);
		}
	}

	Item::update (ctx, flags);
}

Sehle::Renderable *
Figure::show (Sehle::Graph *graph, Sehle::u32 contextmask)
{
	Sehle::RenderableGroup *rgroup = new Sehle::RenderableGroup(graph, contextmask);

	for (Object *child = children; child; child = child->next) {
		if (child->isType (Item::type ())) {
			Sehle::Renderable *rchild = ((Item *) child)->invokeShow (graph, contextmask);
			if (rchild) rgroup->prependChild (rchild);
		} else if (child->isType (PoseableGeometry::type ())) {
			Sehle::Renderable *rchild = ((PoseableGeometry *) child)->show (graph, contextmask);
			if (rchild) rgroup->prependChild (rchild);
		}
	}

	return rgroup;
}

void
Figure::hide (Sehle::RenderableGroup *pgroup)
{
	for (Object *child = children; child; child = child->next) {
		if (child->isType (Item::type ())) {
			((Item *) child)->invokeHide ((Sehle::RenderableGroup *) renderable);
		} else if (child->isType (PoseableGeometry::type ())) {
			((PoseableGeometry *) child)->hide ((Sehle::RenderableGroup *) renderable);
		}
	}
}

Item *
Figure::trace (const Elea::Line3f *wray, unsigned int mask, float *distance)
{
	Item *tchild = NULL;
	float bestd = Elea::OMEGA_F;

	for (Object *child = children; child; child = child->next) {
		if (child->isType (Item::type ())) {
			float d;
			Item *tch = ((Item *) child)->invokeTrace (wray, mask, &d);
			if ((d > 0) && (d < bestd)) {
				bestd = d;
				tchild = tch;
			}
		} else if (child->isType (PoseableGeometry::type ())) {
			Elea::Line3f mray = _w2i.transform (*wray);
			float d;
			if (((PoseableGeometry *) child)->trace (&mray, mask, &d) && (d < bestd)) {
				bestd = d;
				tchild = this;
			}
		}
	}

	if (tchild) {
		*distance = bestd;
		return this;
	}

	return NULL;
}

Item *
Figure::trace (const Elea::Line3f *wray, unsigned int mask, const Elea::Matrix4x4f *e2us, float *distance, Elea::Vector3f *uscp)
{
	Item *tchild = NULL;
	float bestd = Elea::OMEGA_F;
	Elea::Vector3f bestcp(Elea::Vector3f0);

	for (Object *child = children; child; child = child->next) {
		if (child->isType (Item::type ())) {
			float d;
			Elea::Vector3f cp;
			Item *tch = ((Item *) child)->invokeTrace (wray, mask, e2us, &d, &cp);
			if ((d >= 0) && (d < bestd)) {
				bestd = d;
				bestcp = cp;
				tchild = tch;
			}
		} else if (child->isType (PoseableGeometry::type ())) {
			Elea::Line3f mray = _w2i.transform (*wray);
			Elea::Matrix4x4f me2us(*e2us * _w2i);
			me2us.setTranslation (Elea::Vector3f0);
			float d;
			Elea::Vector3f cp;
			if (((PoseableGeometry *) child)->trace (&mray, mask, &me2us, &d, &cp) && (d >= 0) && (d < bestd)) {
				bestd = d;
				bestcp = cp;
				tchild = this;
			}
		}
	}

	if (tchild) {
		if (distance) *distance = bestd;
		if (uscp) *uscp = bestcp;
		return this;
	}

	return NULL;
}

void
Figure::updateChildData (Thera::Node *removed)
{
	clearSkeletonLinks ();
	for (Object *child = children; child; child = child->next) {
		if (!child->isType (Skeleton::type ())) continue;
		if (child->node == removed) continue;
		skeleton = (Skeleton *) child;
		break;
	}
	requestUpdate (MODIFIED | Skeleton::BONE_STRUCTURE_MODIFIED);
}

void
Figure::updateSkeletonLinks (void)
{
	if (!skeleton) return;
	for (Object *child = children; child; child = child->next) {
		if (child->isType (PoseableGeometry::type ())) {
			skeleton->attachOrUpdatePoseable ((PoseableGeometry *) child);
		} else if (child->isType (PoseableItem::type ())) {
			skeleton->attachOrUpdatePoseable ((PoseableItem *) child);
		}
	}
}

void
Figure::clearSkeletonLinks (void)
{
	if (!skeleton) return;
	for (Object *child = children; child; child = child->next) {
		if (child->isType (PoseableGeometry::type ())) {
			skeleton->detachPoseable ((PoseableGeometry *) child);
		} else if (child->isType (PoseableItem::type ())) {
			skeleton->detachPoseable ((PoseableItem *) child);
		}
	}
	skeleton = NULL;
}

void
Figure::attachAnimation (Animation::SkinAnimation *animation)
{
	for (Object *child = children; child; child = child->next) {
		if (child->isType (SkinnedGeometry::type ())) {
			// ((SkinnedGeometry *) child)->attachAnimation (animation);
		} else if (child->isType (PoseableGeometry::type ())) {
			// This is false becuse we animate it via skeleton already
			// ((PoseableGeometry *) child)->attachSkeletalAnimation (animation);
		}
	}
	if (skeleton) skeleton->attachAnimation (animation);
}

void
Figure::detachAnimation (Animation::SkinAnimation *animation)
{
	for (Object *child = children; child; child = child->next) {
		if (child->isType (SkinnedGeometry::type ())) {
			// ((SkinnedGeometry *) child)->detachAnimation (animation);
		} else if (child->isType (PoseableGeometry::type ())) {
			// This is false becuse we animate it via skeleton already
			// ((PoseableGeometry *) child)->detachSkeletalAnimation (animation);
		}
	}
	if (skeleton) skeleton->attachAnimation (animation);
}

void
Figure::animate (Animation::SkinAnimation *animation, float time)
{
	skeleton->animate (animation, time);
}

} // Namespace Miletos

