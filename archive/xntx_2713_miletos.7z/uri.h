#ifndef __MILETOS_URI_H__
#define __MILETOS_URI_H__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2007-2009
//

#include <vector>
#include <string>

#include <libarikkei/dict.h>
#include <libarikkei/arikkei-url.h>

namespace Miletos {

namespace URI {

// Location

// protocol:[domain][[/]directory/][file][#reference][&arguments]

struct Location : public ArikkeiURL {
public:
	Location (const char *address);
	Location (const char *address, const char *defaultprotocol);

	~Location (void);

	char *getParent (int levels);
};

// URLHandler

class URLHandler {
private:
	int refcount;
protected:
	URLHandler (const char *url);
	virtual ~URLHandler (void);
public:
	ArikkeiURL url;

	// Full qualified resource name
	virtual const unsigned char *mmapData (const char *name, size_t *size);
	// Relative name
	virtual const unsigned char *mmapDataRelative (const char *name, size_t *size) = 0;
	virtual void munmapData (const unsigned char *data) = 0;
	// Unsigned char variants
	const unsigned char *mmapData (const unsigned char *name, size_t *size) { return mmapData ((const char *) name, size); }
	const unsigned char *mmapDataRelative (const unsigned char *name, size_t *size) { return mmapDataRelative ((const char *) name, size); }

	// Lifecycle
	void ref (void) { ++refcount; }
	void unRef (void) { if (--refcount < 1) delete this; }
};

class Resolver {
private:
	// Known handlers
	Arikkei::Dict<const char *, URLHandler * (*) (const char *)> constructors;
	std::vector<char *> schemes;
public:
	// Constructor
	Resolver (void) : constructors(17) {}
	// Destructor
	~Resolver (void);

	// Scheme should be specified without trailingg colon
	// This grabs reference to handler
	// Constructor takes full qualified URL as and argument
	void addURLHandler (const char *scheme, URLHandler * (* constructor) (const char *));
	// Get handler for given

	// Get reference to handler for resolving given URL
	URLHandler *getHandler (const char *url);
};

// Global versions

// Check whether URI contains protocol part
unsigned int isRelativeURL (const char *uri);

// Scheme should be specified without trailing colon
// This grabs reference to handler
// Constructor takes full qualified URL as and argument
void addURLHandler (const char *scheme, URLHandler * (* constructor) (const char *));

// Get reference to handler for resolving given URL
URLHandler *getHandler (const char *url);
inline URLHandler *getHandler (const unsigned char *url) { return getHandler ((const char *) url); }

} // Namespace URI

} // Namespace Miletos

#endif

