#define __MILETOS_MESHOBJ_CPP__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2008
//

static const int debug = 0;

#include <stdio.h>

#include <libarikkei/token.h>
#include <libarikkei/dict.h>

#include <elea/geometry.h>

#include <sehle/engine.h>
#include <sehle/graph.h>
#include <sehle/renderable.h>
#include <sehle/commonmaterials.h>
#include <sehle/material-multipass-dns.h>

#include "zip.h"
#include "uri.h"
#include "image.h"
#include "material.h"

#include "meshobj.h"

namespace Miletos {

Elea::Matrix4x4f OBJTransform(0, 1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1);
// Elea::Matrix4x4f OBJTransform;
float OBJScale(2.5);
// float OBJScale(1);

// OBJData

struct OBJData::BuildData {
	// Fragment is a collection of faces with single material
	struct Fragment {
		std::string usemtl;
		std::vector<int> findices;
	};
	// Group is a named subsection of mesh
	struct Group {
		std::string name;
		std::vector<int> findices;
	};
	// Smoothgroup
	struct SGroup {
		std::string name;
		int normalindex;
		std::vector<int> findices;
	};
	std::vector<Elea::Vector3f> vbuild;
	std::vector<Elea::Vector3f> nbuild;
	std::vector<Elea::Vector2f> xbuild;
	std::vector<int> vindices;
	std::vector<int> nindices;
	std::vector<int> xindices;
	std::vector<Fragment *> fragments;
	std::vector<Group *> groups;
	std::vector<SGroup *> sgroups;
	std::string usemtl;
	int cfragment;
	int cgroup;
	int csgroup;
	// The negative indec for missing normals
	// This should uniquely identify normals belonging to the same smooth group
	int lastnormalindex;
};

OBJData::OBJData (const char *purl)
: DataBlock(purl, "OBJData"), bdata(NULL), invalid(0)
{
	URI::URLHandler *handler = URI::getHandler (uri);
	if (!handler) return;
	size_t csize;
	const unsigned char *cdata = handler->mmapData (uri, &csize);
	if (!cdata) {
		handler->unRef ();
		return;
	}
	if (Zip::isGzip (cdata, csize)) {
		size_t zsize;
		unsigned char *zdata = Zip::gunzip (cdata, csize, &zsize);
		if (zdata) {
			parse (zdata, zsize);
			free (zdata);
		}
	} else {
		parse (cdata, csize);
	}
	handler->munmapData (cdata);
	handler->unRef ();
}

OBJData::OBJData (const unsigned char *cdata, size_t csize, const char *purl)
: DataBlock(purl, "OBJData"), bdata(NULL), invalid(0)
{
	if (Zip::isGzip (cdata, csize)) {
		size_t zsize;
		unsigned char *zdata = Zip::gunzip (cdata, csize, &zsize);
		if (zdata) {
			parse (zdata, zsize);
			free (zdata);
		}
	} else {
		if (cdata) parse (cdata, csize);
	}
}

OBJData::~OBJData (void)
{
	delete bdata;
}

OBJData *
OBJData::getOBJData (const char *url, unsigned int create)
{
	OBJData *obj = NULL;
	if (url) {
		obj = (OBJData *) lookupDataBlock (url, "OBJData");
		if (obj) return obj;
		URI::URLHandler *handler = URI::getHandler (url);
		if (handler) {
			size_t csize;
			const unsigned char *cdata = handler->mmapData ((const unsigned char *) url, &csize);
			if (cdata) {
				obj = new OBJData (cdata, csize, url);
				handler->munmapData (cdata);
			}
			handler->unRef ();
		}
	}
	if (!obj && create) obj = new OBJData (url);
	return obj;
}

OBJData *
OBJData::getOBJData (const unsigned char *cdata, size_t csize, const char *url)
{
	OBJData *obj = NULL;
	if (url) {
		obj = (OBJData *) lookupDataBlock (url, "OBJData");
		if (obj) return obj;
		if (cdata) {
			obj = new OBJData (cdata, csize, url);
		}
	}
	return obj;
}

void
OBJData::parse (const unsigned char *cdata, size_t csize)
{
	fprintf (stderr, "Starting parser...\n");
	startParser ();
	Arikkei::TokenChar ft((const char *) cdata, csize);
	Arikkei::TokenLineChar lt(ft);
	while (!lt.eof ()) {
		parseLine (lt.getCData (), lt.getLength ());
		lt++;
	}
	finishParser ();
	fprintf (stderr, "Finished parser...\n");
}

void
OBJData::startParser (void)
{
	if (bdata) delete bdata;
	bdata = new BuildData();
	bdata->cfragment = -1;
	bdata->cgroup = -1;
	bdata->csgroup = (int) bdata->sgroups.size ();
	BuildData::SGroup *sgroup = new BuildData::SGroup();
	sgroup->normalindex = -1;
	bdata->sgroups.push_back (sgroup);
	bdata->lastnormalindex = -1;
}

void
OBJData::parseLine (const char *cdata, size_t csize)
{
	Arikkei::TokenChar lt(cdata, csize);
	Arikkei::TokenChar st(lt.strip ());
	if (st.isEmpty () || (st[0] == '#')) return;
	Arikkei::TokenChar tokenz[32];
	int ntokenz = st.tokenize (tokenz, 32, true, true);
	if (tokenz[0] == "v") {
		// Vertex
		// vertices.push_back (Elea::Vector3f(tokenz[3].getFloat (), tokenz[1].getFloat (), tokenz[2].getFloat ()));
		Elea::Vector3f v(tokenz[1].getFloat (), tokenz[2].getFloat (), tokenz[3].getFloat ());
		if (v.length2 () > 1000000) {
			fprintf (stderr, "Very large vertex %g %g %g\n", v[0], v[1], v[2]);
		}
		bdata->vbuild.push_back (OBJTransform.transformPoint3 (OBJScale * v));
	} else if (tokenz[0] == "vt") {
		// Texcoords
		bdata->xbuild.push_back (Elea::Vector2f(tokenz[1].getFloat (), tokenz[2].getFloat ()));
	} else if (tokenz[0] == "vn") {
		// Normal
		// Elea::Vector3f n(tokenz[3].getFloat (), tokenz[1].getFloat (), tokenz[2].getFloat ());
		Elea::Vector3f n(tokenz[1].getFloat (), tokenz[2].getFloat (), tokenz[3].getFloat ());
		OBJTransform.transformVector3InPlace (n);
		bdata->nbuild.push_back (n.normalize ());
	} else if (tokenz[0] == "f") {
		// Faces
		int normalindex = (bdata->csgroup >= 0) ? bdata->sgroups[bdata->csgroup]->normalindex : --bdata->lastnormalindex;
		int ncorners = ntokenz - 1;
		for (int c1 = 1; c1 < ncorners - 1; c1++) {
			int fidx = (int) bdata->vindices.size ();
			readVertex (tokenz[1].getCData (), tokenz[1].getLength (), normalindex);
			readVertex (tokenz[1 + c1].getCData (), tokenz[1 + c1].getLength (), normalindex);
			readVertex (tokenz[1 + c1 + 1].getCData (), tokenz[1 + c1 + 1].getLength (), normalindex);
			if (bdata->cfragment < 0) {
				// Create new fragment with zero material
				bdata->cfragment = (int) bdata->fragments.size ();
				BuildData::Fragment *frag = new BuildData::Fragment();
				bdata->fragments.push_back (frag);
			}
			bdata->fragments[bdata->cfragment]->findices.push_back (fidx);
			if (bdata->cgroup >= 0) {
				bdata->groups[bdata->cgroup]->findices.push_back (fidx);
			}
			if (bdata->csgroup >= 0) {
				bdata->sgroups[bdata->csgroup]->findices.push_back (fidx);
			}
		}
	} else if (tokenz[0] == "usemtl") {
		// Start of new fragment
		// Retokenize
		ntokenz = st.tokenize (tokenz, 2, true, true);
		bdata->usemtl = (const char *) tokenz[1].strip ();
		bdata->cfragment = -1;
		for (size_t i = 0; i < bdata->fragments.size (); i++) {
			if (!bdata->fragments[i]->usemtl.compare (bdata->usemtl)) {
				bdata->cfragment = (int) i;
				break;
			}
		}
		if (bdata->cfragment < 0) {
			bdata->cfragment = (int) bdata->fragments.size ();
			BuildData::Fragment *frag = new BuildData::Fragment();
			frag->usemtl = bdata->usemtl;
			bdata->fragments.push_back (frag);
		}
	// fixme: It seems, that space is not mandatory
	} else if ((tokenz[0] == "g") || (st[0] == 'g')) {
		// Group
		if (tokenz[0] == "g") {
			// Retokenize
			ntokenz = st.tokenize (tokenz, 2, true, true);
			if (ntokenz != 2) {
				// Anonymous groups are allowed
				tokenz[1] = "default";
			}
		} else {
			tokenz[1].set (tokenz[0].getCData (), 1, tokenz[0].getLength ());
		}
		bdata->cgroup = -1;
		for (size_t i = 0; i < bdata->groups.size (); i++) {
			if (!bdata->groups[i]->name.compare ((const char *) tokenz[1].strip ())) {
				bdata->cgroup = (int) i;
				break;
			}
		}
		if (bdata->cgroup < 0) {
			bdata->cgroup = (int) bdata->groups.size ();
			BuildData::Group *group = new BuildData::Group();
			group->name = (const char *) tokenz[1].strip ();
			bdata->groups.push_back (group);
		}
	} else if (tokenz[0] == "mtllib") {
	    mtllib = tokenz[1].strdup ();
	} else if (tokenz[0] == "s") {
		bdata->csgroup = -1;
		if (tokenz[1].stricmp ("off") && tokenz[1].strcmp ("0")) {
			for (size_t i = 0; i < bdata->sgroups.size (); i++) {
				if (!bdata->sgroups[i]->name.compare ((const char *) tokenz[1].strip ())) {
					bdata->csgroup = (int) i;
					break;
				}
			}
			if (bdata->csgroup < 0) {
				bdata->csgroup = (int) bdata->sgroups.size ();
				BuildData::SGroup *sgroup = new BuildData::SGroup();
				sgroup->name = (const char *) tokenz[1].strip ();
				sgroup->normalindex = --bdata->lastnormalindex;
				bdata->sgroups.push_back (sgroup);
			}
		}
	} else {
		// Unrecognized token
		if (debug) fprintf (stderr, "GeometryOBJ::readSource: Unrecognized line: %s\n", (const char *) lt);
	}
}

static unsigned int
vec2_hash (const Elea::Vector2f *v)
{
	return arikkei_memory_hash (v, 2 * sizeof (i32));
}

static unsigned int
vec2_equal (const Elea::Vector2f *v0, const Elea::Vector2f *v1)
{
	return *v0 == *v1;
}

static unsigned int
vec3_hash (const Elea::Vector3f *v)
{
	return arikkei_memory_hash (v, sizeof (Elea::Vector3f));
}

static unsigned int
vec3_equal (const Elea::Vector3f *v0, const Elea::Vector3f *v1)
{
	return *v0 == *v1;
}

static unsigned int
int3_hash (const i32 *v)
{
	return arikkei_memory_hash (v, 3 * sizeof (i32));
}

static unsigned int
int3_equal (const i32 *v0, const i32 *v1)
{
	return arikkei_memory_equal (v0, v1, 3 * sizeof (i32));
}

static int
compare_tuples (const void *a, const void *b)
{
	const i32 *lhs = (const i32 *) a;
	const i32 *rhs = (const i32 *) b;
	for (int i = 0; i < 3; i++) {
		if (lhs[i] < rhs[i]) return -1;
		if (lhs[i] > rhs[i]) return 1;
	}
	return 0;
}

void
OBJData::finishParser (void)
{
}

int
OBJData::readVertex (const char *cdata, size_t csize, int normalindex)
{
	Arikkei::TokenChar token(cdata, csize);
	static Arikkei::TokenChar tokenz[4];
	int ntokenz = token.tokenize (tokenz, 4, Arikkei::TokenChar("/"), false);
	if (ntokenz < 1) {
		invalid = 1;
		return -1;
	}
	// Vertex
	int idx = tokenz[0].getInt ();
	if (idx < 0) {
		idx = (int) bdata->vbuild.size () + idx;
	} else {
		idx -= 1;
	}
	bdata->vindices.push_back (idx);
	idx = -1;
	if (ntokenz > 1) {
		// Texcoord
		if (!tokenz[1].isEmpty ()) {
			idx = tokenz[1].getInt ();
			if (idx < 0) {
				idx = (int) bdata->xbuild.size () + idx;
			} else {
				idx -= 1;
			}
		}
	}
	bdata->xindices.push_back (idx);
	idx = normalindex;
	if (ntokenz > 2) {
		// Normal
		if (!tokenz[2].isEmpty ()) {
			idx = tokenz[2].getInt ();
			if (idx < 0) {
				idx = (int) bdata->nbuild.size () + idx;
			} else {
				idx -= 1;
			}
		}
	}
	bdata->nindices.push_back (idx);
	return 1;
}

// OBJMesh

OBJMesh::OBJMesh (OBJData *pobjdata, unsigned int pbuild)
:objdata(pobjdata), url(NULL), mtllib(NULL)
{
	objdata->ref ();
	// We can safely copy url here as OBJMesh is immutable
	url = strdup (objdata->uri);
	if (pbuild) {
		build (true);
	}
}

OBJMesh::~OBJMesh (void)
{
	objdata->unRef ();
	if (url) free (url);
	if (mtllib) free (mtllib);
}

void
OBJMesh::weld (const char *parent, const char *child)
{
	if (!objdata->bdata) return;
	if (!fragments.empty ()) return;
	OBJData::BuildData *bdata = objdata->bdata;
	int nvertices = (int) bdata->vbuild.size ();
	int nfaces = (int) bdata->vindices.size () / 3;
	if (vindices.empty ()) {
		vindices = bdata->vindices;
		vorig2welded.resize (bdata->vbuild.size ());
		for (size_t i = 0; i < bdata->vbuild.size (); i++) vorig2welded[i] = (int) i;
	}
	OBJData::BuildData::Group *g0 = NULL;
	for (size_t i = 0; i < bdata->groups.size (); i++) {
		if (!bdata->groups[i]->name.compare (parent)) {
			g0 = bdata->groups[i];
			break;
		}
	}
	if (!g0) return;
	OBJData::BuildData::Group *g1 = NULL;
	for (size_t i = 0; i < bdata->groups.size (); i++) {
		if (!bdata->groups[i]->name.compare (child)) {
			g1 = bdata->groups[i];
			break;
		}
	}
	if (!g1) return;
	Arikkei::Dict<const Elea::Vector3f *, int> vdict((int) bdata->vbuild.size () / 3 + 1, vec3_hash, vec3_equal);
	for (size_t i = 0; i < g0->findices.size (); i++) {
		for (int j = 0; j < 3; j++) {
			int iidx = g0->findices[i] + j;
			int vidx = vindices[iidx];
			if (vidx < 0) continue;
			if (vdict.exists (&bdata->vbuild[vidx])) {
				int newidx = vdict.lookup (&bdata->vbuild[vidx]);
				vorig2welded[vidx] = newidx;
				if (newidx != vidx) {
					fprintf (stderr, ".");
				}
				vindices[iidx] = newidx;
			} else {
				vdict.insert (&bdata->vbuild[vidx], vidx);
				vorig2welded[vidx] = vidx;
			}
		}
	}
	for (size_t i = 0; i < g1->findices.size (); i++) {
		for (int j = 0; j < 3; j++) {
			int iidx = g1->findices[i] + j;
			int vidx = vindices[iidx];
			if (vidx < 0) continue;
			if (vdict.exists (&bdata->vbuild[vidx])) {
				int newidx = vdict.lookup (&bdata->vbuild[vidx]);
				if (newidx != vidx) {
					fprintf (stderr, ".");
				}
				vorig2welded[vidx] = newidx;
				vindices[iidx] = newidx;
			} else {
				vdict.insert (&bdata->vbuild[vidx], vidx);
				vorig2welded[vidx] = vidx;
			}
		}
	}
}

void
OBJMesh::build (unsigned int weld)
{
	if (!objdata->bdata) return;
	OBJData::BuildData *bdata = objdata->bdata;

	int nvertices = (int) bdata->vbuild.size ();
	int nfaces = (int) bdata->vindices.size () / 3;
	if (vindices.empty ()) {
		vindices = bdata->vindices;
		vorig2welded.resize (bdata->vbuild.size ());
		for (size_t i = 0; i < bdata->vbuild.size (); i++) vorig2welded[i] = (int) i;
	}
	if (weld) {
		// Weld vertices
		Arikkei::Dict<const Elea::Vector3f *, int> vdict((int) bdata->vbuild.size () / 3 + 1, vec3_hash, vec3_equal);
		for (size_t i = 0; i < vindices.size (); i++) {
			if (vindices[i] < 0) continue;
			if (vdict.exists (&bdata->vbuild[vindices[i]])) {
				int newidx = vdict.lookup (&bdata->vbuild[vindices[i]]);
				vorig2welded[vindices[i]] = newidx;
				vindices[i] = newidx;
			} else {
				vdict.insert (&bdata->vbuild[vindices[i]], vindices[i]);
				vorig2welded[vindices[i]] = vindices[i];
			}
		}
	}

	// Some braindead modellers repeat texture coordinates and this will proliferate collated vertices
	// So collate texture coordinates
	std::vector<int> xindices(bdata->xindices);
	Arikkei::Dict<const Elea::Vector2f *, int> xdict((int) bdata->xbuild.size () / 3 + 1, vec2_hash, vec2_equal);
	for (size_t i = 0; i < xindices.size (); i++) {
		if (xindices[i] < 0) continue;
		if (xdict.exists (&bdata->xbuild[xindices[i]])) {
			xindices[i] = xdict.lookup (&bdata->xbuild[xindices[i]]);
		} else {
			xdict.insert (&bdata->xbuild[xindices[i]], xindices[i]);
		}
	}

	// Distribute vertices/normals/texcoords to unique sets
	// Build unified index mapping for vertex/texture/normal indices
	// Create redundant vector of all vidx/nidx/tidx tuples for dictionary keys
	int ntuples = (int) vindices.size ();
	std::vector<int> allx(ntuples * 3);
	size_t tidx = 0;
	for (size_t i = 0; i < vindices.size (); i++) {
		allx[tidx + 0] = vindices[i];
		allx[tidx + 1] = (i < bdata->nindices.size ()) ? bdata->nindices[i] : -1;
		allx[tidx + 2] = (i < xindices.size ()) ? xindices[i] : -1;
		tidx += 3;
	}
	if (!allx.empty ()) qsort (&allx[0], ntuples, 3 * sizeof (int), compare_tuples);
	std::vector<Elea::Vector3f> v;
	std::vector<Elea::Vector3f> n;
	std::vector<Elea::Vector2f> t;
	vwelded2collated.resize (vindices.size (), -1);
	std::vector<int> vposwelded(bdata->vbuild.size (), 0);
	vlen.resize (bdata->vbuild.size (), 0);
	Arikkei::Dict<const i32 *, int> tupledict(ntuples / 3 + 1, int3_hash, int3_equal);
	size_t xp = 0;
	while (xp < allx.size ()) {
		int vidx = allx[xp];
		// Register this vertex
		vposwelded[vidx] = (int) v.size ();
		size_t xq = xp;
		while ((xq < allx.size ()) && (allx[xq] == vidx)) {
			int newidx = (int) v.size ();
			tupledict.insert (&allx[xq], newidx);
			vwelded2collated[vidx] = newidx;
			vlen[vidx] += 1;
			v.push_back (bdata->vbuild[vidx]);
			n.push_back ((allx[xq + 1] >= 0) ? bdata->nbuild[allx[xq + 1]] : Elea::Vector3fZ);
			t.push_back ((allx[xq + 2] >= 0) ? bdata->xbuild[allx[xq + 2]] : Elea::Vector2f0);
			// Skip identical
			size_t xr = xq + 3;
			while ((xr < allx.size ()) && (allx[xr] == vidx) && (allx[xr + 1] == allx[xq + 1]) && (allx[xr + 2] == allx[xq + 2])) {
				xr += 3;
			}
			xq = xr;
		}
		xp = xq;
	}
	vpos.resize (bdata->vbuild.size (), 0);
	for (size_t i = 0; i < bdata->vbuild.size (); i++) {
		int vidxorig = (int) i;
		int vidxwelded = vorig2welded[vidxorig];
		vpos[i] = vposwelded[vidxwelded];
	}

	// Compose new fragments
	for (size_t i = 0; i < bdata->fragments.size (); i++) {
		if (bdata->fragments[i]->findices.empty ()) continue;
		Fragment frag;
		frag.usemtl = bdata->fragments[i]->usemtl;
		frag.materialidx = -1;
		frag.firstindex = (u32) icollated.size ();
		frag.nindices = (u32) bdata->fragments[i]->findices.size () * 3;
		for (size_t j = 0; j < bdata->fragments[i]->findices.size (); j++) {
			for (int k = 0; k < 3; k++) {
				int fidx = bdata->fragments[i]->findices[j] + k;
				int x[3];
				x[0] = vindices[fidx];
				x[1] = (fidx < (int) bdata->nindices.size ()) ? bdata->nindices[fidx] : -1;
				x[2] = (fidx < (int) xindices.size ()) ? xindices[fidx] : -1;
				int idx = vindices[fidx];
				// tags[idx] |= 1;
				int newidx = tupledict.lookup (x);
				icollated.push_back (newidx);
				// tags[newidx] |= 2;
			}
		}
		fragments.push_back (frag);
	}

	// Compose real groups
	// Also generate list of original vertex indices for each group
	vgroup.resize (v.size (), -1);
	std::vector<int> tags(bdata->vbuild.size ());
	if (v.size () > tags.size ()) tags.resize (v.size ());
	for (size_t i = 0; i < bdata->groups.size (); i++) {
		if (bdata->groups[i]->findices.empty ()) continue;
		Group group;
		group.name = bdata->groups[i]->name;
		for (size_t j = 0; j < tags.size (); j++) tags[j] = 0;
		for (size_t j = 0; j < bdata->groups[i]->findices.size (); j++) {
			for (int k = 0; k < 3; k++) {
				int iidx = bdata->groups[i]->findices[j] + k;
				int vidxorig = bdata->vindices[iidx];
				int vidxwelded = vorig2welded[vidxorig];
				if (vidxwelded != vidxorig) {
					fprintf (stderr, ".");
				}
				int x[3];
				x[0] = vidxwelded;
				x[1] = (iidx < (int) bdata->nindices.size ()) ? bdata->nindices[iidx] : -1;
				x[2] = (iidx < (int) xindices.size ()) ? xindices[iidx] : -1;
				tags[vidxorig] |= 1;
				int newidx = tupledict.lookup (x);
				icollated.push_back (newidx);
				tags[newidx] |= 2;
			}
		}
		for (size_t j = 0; j < bdata->vbuild.size (); j++) if (tags[j] & 1) group.vorig.push_back ((u32) j);
		for (size_t j = 0; j < v.size (); j++) {
			if (tags[j] & 2) {
				group.vnew.push_back ((int) j);
				if (vgroup[j] < 0) vgroup[j] = (int) i;
			}
		}
		groups.push_back (group);
	}

	Elea::Geometry::calculateNormals (n[0], sizeof (Elea::Vector3f), v[0], sizeof (Elea::Vector3f), (Elea::u32) v.size (), (const Elea::u32 *) &icollated[0], (Elea::u32) icollated.size (), true);

	vcollated = v;
	xcollated = t;
	ncollated = n;

	mtllib = strdup (objdata->mtllib.c_str ());

	// Calculate the list of used materials
	for (size_t i = 0; i < fragments.size (); i++) {
		size_t j;
		for (j = 0; j < materials.size (); j++) {
			if (!fragments[i].usemtl.compare (materials[j])) {
				fragments[i].materialidx = (int) j;
				break;
			}
		}
		if (j >= materials.size ()) {
			materials.push_back (fragments[i].usemtl);
			fragments[i].materialidx = (int) j;
		}
	}
}

int
OBJMesh::lookupGroupIdx (const char *name)
{
	for (size_t i = 0; i < groups.size (); i++) {
		if (!groups[i].name.compare (name)) return (int) i;
	}
	return -1;
}

#if 0
void
OBJMesh::weld (int parentidx, int childidx)
{
	Group *g0 = &groups[parentidx];
	Group *g1 = &groups[childidx];
	Arikkei::Dict<const Elea::Vector3f *, int> vdict(10001, vec3_hash, vec3_equal);
	std::vector<char> tags(vertices.size (), 0);
	for (size_t i = 0; i < g0->vnew.size (); i++) {
		vdict.insert (&vertices[g0->vnew[i]], (int) i);
		tags[g0->vnew[i]] = 1;
	}
	std::vector<int> vorig;
	std::vector<int> vnew;
	for (size_t i = 0; i < g1->vorig.size (); i++) {
		// if ((g1->vorig[i] >= 0) && vlen[g1->vorig[i]] && !tags[vpos[g1->vorig[i]]]) {
		if ((g1->vorig[i] >= 0) && vlen[g1->vorig[i]] && !vdict.exists (&vertices[vpos[g1->vorig[i]]])) {
			vorig.push_back (g1->vorig[i]);
		} else {
			vorig.push_back (-1);
		}
	}
	for (size_t i = 0; i < g1->vnew.size (); i++) {
		if (!vdict.exists (&vertices[g1->vnew[i]])) {
			vnew.push_back (g1->vnew[i]);
		}
		// if (!tags[g1->vnew[i]]) {
		//	vnew.push_back (g1->vnew[i]);
		// }
	}
	g1->vorig = vorig;
	g1->vnew = vnew;
}
#endif

// GeometryOBJ

GeometryOBJ::GeometryOBJ (void)
: StaticGeometry(0), obj(NULL)
{
}

static Object *
geometryobj_factory (void)
{
	return new GeometryOBJ();
}

const Object::Type *
GeometryOBJ::objectType (void)
{
	return type ();
}

const Object::Type *
GeometryOBJ::type (void)
{
	static Type *mytype = NULL;
	static const Attribute attrs[] = {
		{ "source", NULL, 0 }
	};
	if (!mytype) mytype = new Type(StaticGeometry::type (), "GeometryOBJ", "geometryOBJ", geometryobj_factory, sizeof (attrs) / sizeof (attrs[0]), attrs);
	return mytype;
}

void
GeometryOBJ::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	StaticGeometry::build (pnode, doc, ctx);
	buildAllAttributes (type (), ctx);
}

void
GeometryOBJ::release (void)
{
	clear ();
	StaticGeometry::release ();
}

void
GeometryOBJ::set (const char *attrid, const char *val)
{
	if (!strcmp (attrid, "source")) {
		clear ();
		if (val) {
			OBJData *objdata = OBJData::getOBJData (val, false);
			if (objdata) {
				obj = new OBJMesh(objdata, true);
				objdata->unRef ();
				loadData ();
			}
		}
		requestUpdate (MODIFIED | MESH_DEFINITION_MODIFIED);
	} else {
		StaticGeometry::set (attrid, val);
	}
}

TextureInfo *
GeometryOBJ::getTextureInfo (unsigned int matidx, unsigned int texidx, unsigned int getimage)
{
	if (texidx >= ntextures) return NULL;
	TextureInfo *tex = new TextureInfo();
	tex->urn = strdup (textures[texidx]->id.c_str ());
	tex->path = strdup (textures[texidx]->path.c_str ());
	if (getimage) {
		tex->image = nr_image_new ();
		NRPixBlock *px = &textures[texidx]->pixels.pb;
		nr_pixblock_setup_extern (&tex->image->pixels, px->mode, px->area.x0, px->area.y0, px->area.x1, px->area.y1, NR_PIXBLOCK_PX(px), px->rs, false, false);
	}
	return tex;
}

u32
GeometryOBJ::getMaterialInfo (Miletos::MaterialInfo *mat, u32 matidx)
{
	if (matidx >= (u32) nmaterials) return false;
	if (mat) {
		mat->id = materials[matidx].usemtl.c_str ();
		mat->diffuseColor = Elea::Color4fWhite;
		mat->specularColor = Elea::Color4fBlack;
		mat->specularShininess = 1;
		mat->diffuseTexture = -1;
		mat->normalTexture = -1;
		mat->specularTexture = -1;
		if (materials[matidx].diffusetexture >= 0) {
			mat->type = Miletos::MaterialInfo::TEXTURE;
			mat->diffuseTexture = materials[matidx].diffusetexture;
		} else {
			mat->type = Miletos::MaterialInfo::COLOR;
			mat->diffuseColor = Elea::Color4fWhite;
			mat->specularColor = Elea::Color4fWhite;
			mat->specularShininess = 16;
		}
	}
	return true;
}

Sehle::Material *
GeometryOBJ::getMaterial (int matidx, Sehle::Engine *engine)
{
	if ((matidx < 0) || (matidx >= (int) materials.size ())) {
		Sehle::WireMaterial *mat = Sehle::WireMaterial::newWireMaterial (engine, "Poser:Geometry:invalidMaterial");
		if (!mat->built) mat->setColor (Elea::Color4fRed);
		return mat;
	}
	if (materials[matidx].diffusetexture >= 0) {
		Texture *tex = textures[materials[matidx].diffusetexture];
		Sehle::MaterialMultipassDNS *mat = Sehle::MaterialMultipassDNS::newMaterialMultipassDNS (engine, tex->path.c_str ());
		if (!mat->built) {
			mat->setMap (Sehle::MaterialMultipassDNS::COLOR, tex->path.c_str (), &tex->pixels.pb);
			if (materials[matidx].normaltexture >= 0) {
				tex = textures[materials[matidx].normaltexture];
				mat->setMap (Sehle::MaterialMultipassDNS::NORMAL, tex->path.c_str (), &tex->pixels.pb);
			}
			if (materials[matidx].speculartexture >= 0) {
				tex = textures[materials[matidx].speculartexture];
				mat->setMap (Sehle::MaterialMultipassDNS::SPECULAR, tex->path.c_str (), &tex->pixels.pb);
			}
		}
		return mat;
	}
	Sehle::WireMaterial *mat = Sehle::WireMaterial::newWireMaterial (engine, NULL);
	mat->setColor (Elea::Color4f((f32) ((matidx >> 2) & 1), (f32) ((matidx >> 1) & 1), (f32) (matidx & 1), 1));
	return mat;
}

void
GeometryOBJ::clear (void)
{
    for (size_t i = 0; i < textures.size (); i++) {
        delete textures[i];
    }
    textures.clear ();
    materials.clear ();
	if (obj) {
		delete obj;
		obj = NULL;
	}
	StaticGeometry::clear ();
}

void
GeometryOBJ::loadData (void)
{
	for (size_t j = 0; j < obj->materials.size (); j++) {
		Material mat;
		mat.usemtl = obj->materials[j];
		mat.diffusetexture = -1;
		materials.push_back (mat);
	}
	nmaterials = (int) materials.size ();

	vertexid = strdup (obj->url);
	indexid = strdup (obj->url);

	setNumVertices (obj->vcollated.size (), true, true, true);
	if (nvertices) {
		// t.transformPoint3 (&vbase[0], sizeof (Elea::Vector3f), &obj->vertices[0], sizeof (Elea::Vector3f), (u32) obj->vertices.size ());
		memcpy (&vbase[0], &obj->vcollated[0], obj->vcollated.size () * sizeof (Elea::Vector3f));
		memcpy (&nbase[0], &obj->ncollated[0], obj->vcollated.size () * sizeof (Elea::Vector3f));
		// fixme: Texcoords have separate indices (Lauris)
		memcpy (&xbase[0], &obj->xcollated[0], obj->vcollated.size () * sizeof (Elea::Vector2f));
	}
	int lnumindices = 0;
	int lnumfrags = 0;
	for (size_t i = 0; i < obj->fragments.size (); i++) {
		if (!obj->fragments[i].nindices) continue;
		lnumfrags += 1;
		lnumindices += obj->fragments[i].nindices;
	}
	setNumIndices (lnumindices);
	setNumFrags (lnumfrags);
	int iidx = 0;
	int fidx = 0;
	for (size_t i = 0; i < obj->fragments.size (); i++) {
		if (!obj->fragments[i].nindices) continue;
		frags[fidx].visible = 1;
		frags[fidx].matidx = obj->fragments[i].materialidx;
		frags[fidx].firstindex = iidx;
		frags[fidx].numindices = obj->fragments[i].nindices;
		for (u32 k = 0; k < obj->fragments[i].nindices; k++) {
			indices[iidx + k] = obj->icollated[obj->fragments[i].firstindex + k];
		}
		iidx += obj->fragments[i].nindices;
		fidx += 1;
	}
	Elea::Geometry::calculateTangents (tbase[0], sizeof (tbase[0]), vbase[0], sizeof (vbase[0]), nbase[0], sizeof (nbase[0]), xbase[0], sizeof (xbase[0]), nvertices, indices, nindices, false);

    if (obj->mtllib) {
        URI::URLHandler *handler = URI::getHandler (obj->url);
        if (handler) {
            size_t csize;
            const unsigned char *cdata = handler->mmapDataRelative (obj->mtllib, &csize);
            if (cdata) {
                Material *currentmtl = NULL;
                Arikkei::TokenChar ft((const char *) cdata, csize);
                Arikkei::TokenLineChar lt(ft);
                while (!lt.eof ()) {
                    Arikkei::TokenChar st(lt.strip ());
                    Arikkei::TokenChar tokenz[16];
                    int ntokenz = st.tokenize (tokenz, 16, true, true);
                    if (tokenz[0] == "newmtl") {
                        currentmtl = NULL;
                        for (size_t i = 0; i < materials.size (); i++) {
                            if (!materials[i].usemtl.compare ((const char *) tokenz[1])) {
                                currentmtl = &materials[i];
                                break;
                            }
                        }
                    } else if (tokenz[0] == "map_Kd") {
                        if (currentmtl) {
                            currentmtl->diffusemap = (const char *) tokenz[1];
                        }
                    } else if (tokenz[0] == "map_Ks") {
                        if (currentmtl) {
                            currentmtl->specularmap = (const char *) tokenz[1];
                        }
                    } else if ((tokenz[0] == "bump") && (tokenz[1] == "-bm")) {
                        if (currentmtl) {
                            currentmtl->normalmap = (const char *) tokenz[2];
                        }
                    } else if ((tokenz[0] == "bump") || (tokenz[0] == "map_bump")) {
                        if (currentmtl) {
                            currentmtl->normalmap = (const char *) tokenz[1];
                        }
                    }
                    lt++;
                }
                handler->munmapData (cdata);
            }
            // Process textures
            for (size_t i = 0; i < materials.size (); i++) {
				materials[i].diffusetexture = loadTexture (handler, materials[i].diffusemap.c_str ());
				materials[i].normaltexture = loadTexture (handler, materials[i].normalmap.c_str ());
				materials[i].speculartexture = loadTexture (handler, materials[i].specularmap.c_str ());
            }
            handler->unRef ();
        }
    }

	requestUpdate (MODIFIED | MESH_DEFINITION_MODIFIED);
}

int
GeometryOBJ::loadTexture (URI::URLHandler *handler, const char *path)
{
	if (!path || !*path) return -1;
    for (size_t j = 0; j < textures.size (); j++) {
		if (!textures[j]->id.compare (path)) return (int) j;
    }
	int texidx = -1;
	size_t csize;
    const unsigned char *cdata = NULL;
	if (FileSystem::isAbsolutePath (path)) {
		URI::Location loc(path, "file");
		cdata = handler->mmapData (loc.path, &csize);
	} else {
		cdata = handler->mmapDataRelative (path, &csize);
	}
    if (cdata) {
        Texture *tex = new Texture();
        tex->refcount = 1;
        tex->path = path;
        tex->id = path;
        if (Image::load (&tex->pixels.pb, cdata, csize)) {
            texidx = (int) textures.size ();
            textures.push_back (tex);
			ntextures += 1;
        } else {
            delete tex;
        }
        handler->munmapData (cdata);
    }
	return texidx;
}

} // Namespace Miletos

