#define __MILETOS_PRIMITIVES_CPP__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2007
//

static const int debug = 1;

#include <malloc.h>
#include <stdio.h>
#include <assert.h>

#include <elea/line.h>
#include <elea/geometry.h>

#include <sehle/engine.h>
#include <sehle/graph.h>
#include <sehle/renderable.h>
#include <sehle/commonmaterials.h>

#include "material.h"
#include "xml/base.h"

#include "primitives.h"

namespace Miletos {

Box::Box (void)
: Item(HAS_CHILDREN),
size_x_set(0), size_y_set(0), size_z_set(0),
matid(NULL), material(NULL),
size(2), size_x(2), size_y(2), size_z(2)
{
}

static Object *
box_factory (void)
{
	return new Box();
}

const Object::Type *
Box::objectType (void)
{
	return type ();
}

const Object::Type *
Box::type (void)
{
	static Type *mytype = NULL;
	static const Attribute attrs[] = {
		{ "size", "2", 0 },
		{ "sizeX", "2", 0 },
		{ "sizeY", "2", 0 },
		{ "sizeZ", "2", 0 },
		{ "material", NULL, 0 }
	};
	if (!mytype) mytype = new Type(Item::type (), "Box", "box", box_factory, sizeof (attrs) / sizeof (attrs[0]), attrs);
	return mytype;
}

void
Box::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	Item::build (pnode, doc, ctx);

	buildAllAttributes (type (), ctx);

}

void
Box::release (void)
{
	if (material) {
		material->detach (this);
		material = NULL;
	}
	if (matid) {
		document->removeIdentityChangeListener (matid, this);
		free (matid);
		matid = NULL;
	}
	Item::release ();
}

void
Box::set (const char *attrid, const char *val)
{
	if (!strcmp (attrid, "size")) {
		if (!XML::parseNumber (&size, val)) size = 2.0f;
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "sizeX")) {
		size_x_set = 1;
		if (!XML::parseNumber (&size_x, val)) {
			size_x_set = 0;
			size_x = 2.0f;
		}
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "sizeY")) {
		size_y_set = 1;
		if (!XML::parseNumber (&size_y, val)) {
			size_y_set = 0;
			size_y = 2.0f;
		}
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "sizeZ")) {
		size_z_set = 1;
		if (!XML::parseNumber (&size_z, val)) {
			size_z_set = 0;
			size_z = 2.0f;
		}
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "material")) {
		if (material) {
			material->detach (this);
			material = NULL;
		}
		if (matid) {
			document->removeIdentityChangeListener (matid, this);
			free (matid);
			matid = NULL;
		}
		if (val && (val[0] == '#') && val[1]) {
			matid = strdup (val + 1);
			document->addIdentityChangeListener (matid, this);
			Object *object = document->lookupObject (matid);
			if (object && object->isType (Material::type ())) {
				material = (Material *) object;
				material->attach (this);
			}
		}
		requestUpdate (MODIFIED);
	} else {
		Item::set (attrid, val);
	}
}

void
Box::update (UpdateCtx *ctx, unsigned int flags)
{
	Object::update (ctx, flags);

	if (flags & MODIFIED) {
		if (renderable) {
			buildMesh ((Sehle::StaticMesh *) renderable);
		}
	}

	float wx = (size_x_set) ? size_x : size;
	float wy = (size_y_set) ? size_y : size;
	float wz = (size_z_set) ? size_z : size;
	Elea::Cuboid3f q(-wx / 2, -wy / 2, -wz / 2, wx / 2, wy / 2, wz / 2);
	bbox.set (ctx->i2w.transform (q));

	Item::update (ctx, flags);
}

void
Box::identityAdded (Document *pdocument, const char *pidentity, Object *pobject)
{
	assert (!strcmp (pidentity, matid));

	if (material) {
		material->detach (this);
		material = NULL;
	}

	if (pobject->isType (Material::type ())) {
		material = (Material *) pobject;
		material->attach (this);
	}

	requestModified (MODIFIED);
}

void
Box::identityRemoved (Document *pdocument, const char *pidentity)
{
	assert (!strcmp (pidentity, matid));

	if (material) {
		material->detach (this);
		material = NULL;
	}

	requestModified (MODIFIED);
}

void
Box::attachedObjectRelease (Object *attached, void *data)
{
	assert (attached == material);

	material->detach (this);
	material = NULL;

	requestUpdate (MODIFIED);
}

void
Box::attachedObjectModified (Object *attached, unsigned int flags, void *data)
{
}

Sehle::Renderable *
Box::show (Sehle::Graph *graph, Sehle::u32 contextmask)
{
	Sehle::StaticMesh *mesh = new Sehle::StaticMesh(graph, contextmask);

	buildMesh (mesh);

	return mesh;
}

Item *
Box::trace (const Elea::Line3f *wray, unsigned int mask, float *distance)
{
	float wx = (size_x_set) ? size_x : size;
	float wy = (size_y_set) ? size_y : size;
	float wz = (size_z_set) ? size_z : size;
	Elea::Cuboid3f q(-wx / 2, -wy / 2, -wz / 2, wx / 2, wy / 2, wz / 2);
	Elea::Line3f rl = _w2i.transform (*wray);

	// i2w.transformInPlace (bbox);
	float p0, p1;
	if (q.getIntersection (rl, p0, p1) && (p0 > 0)) {
		*distance = p0;
		return this;
	}
	return NULL;
}

static void
genBox (Sehle::VertexBuffer *vb, Sehle::IndexBuffer *ib, const Elea::Vector3f corners[])
{
	vb->setUp (24, 11);
	vb->setOffset (Sehle::VertexBuffer::COORDINATES, 0);
	vb->setOffset (Sehle::VertexBuffer::NORMALS, 3);
	vb->setOffset (Sehle::VertexBuffer::TANGENTS, 6);
	vb->setOffset (Sehle::VertexBuffer::TEXCOORDS, 9);
	f32 *attributes = vb->map (Sehle::VertexBuffer::WRITE);
	ib->resize (36);
	u32 *indices = ib->map (Sehle::IndexBuffer::WRITE);
	static int ck[] = { 1, 2, 6, 5, 2, 3, 7, 6, 3, 0, 4, 7, 0, 1, 5, 4, 5, 6, 7, 4, 2, 1, 0, 3 };
	static int ik[] = { 0, 1, 3, 3, 1, 2 };
	for (int i = 0; i < 6; i++) {
		const Elea::Vector3f& p0(corners[ck[4 * i + 0]]);
		const Elea::Vector3f& p1(corners[ck[4 * i + 1]]);
		const Elea::Vector3f& p2(corners[ck[4 * i + 2]]);
		// const Elea::Vector3f& p3(corners[ck[4 * i + 3]]);
		Elea::Vector3f normal = Elea::Vector3f(p0, p1) * Elea::Vector3f(p0, p2);
		normal.normalizeSelf ();
		for (int j = 0; j < 4; j++) {
			vb->setValues (4 * i + j, vb->offset[Sehle::VertexBuffer::COORDINATES], corners[ck[4 * i + j]], 3);
			vb->setValues (4 * i + j, vb->offset[Sehle::VertexBuffer::NORMALS], normal, 3);
			vb->setValue (4 * i + j, vb->offset[Sehle::VertexBuffer::TEXCOORDS], (Sehle::f32) (((j + 1) & 3) >> 1));
			vb->setValue (4 * i + j, vb->offset[Sehle::VertexBuffer::TEXCOORDS] + 1, (Sehle::f32) (j >> 1));
		}
		for (int j = 0; j < 6; j++) {
			indices[6 * i + j] = 4 * i + ik[j];
		}
	}
	Elea::Geometry::calculateTangents (attributes + vb->offset[Sehle::VertexBuffer::TANGENTS], 11 * sizeof (f32),
		attributes + vb->offset[Sehle::VertexBuffer::COORDINATES], 11 * sizeof (f32),
		attributes + vb->offset[Sehle::VertexBuffer::NORMALS], 11 * sizeof (f32),
		attributes + vb->offset[Sehle::VertexBuffer::TEXCOORDS], 11 * sizeof (f32), 24,
		indices, 36, false);
	vb->unMap ();
	ib->unMap ();
}

static void
genBox (Sehle::VertexBuffer *vb, Sehle::IndexBuffer *ib, const Elea::Vector3f& p0, const Elea::Vector3f& p1)
{
	Elea::Vector3f corners[8];
	for (int i = 0; i < 8; i++) {
		int x = ((i + 1) >> 1) & 1;
		int y = (i >> 1) & 1;
		int z = (i >> 2) & 1;
		corners[i][Elea::X] = (1 - x) * p0[Elea::X] + x * p1[Elea::X];
		corners[i][Elea::Y] = (1 - y) * p0[Elea::Y] + y * p1[Elea::Y];
		corners[i][Elea::Z] = (1 - z) * p0[Elea::Z] + z * p1[Elea::Z];
	}
	genBox (vb, ib, corners);
}

void
Box::buildMesh (Sehle::StaticMesh *mesh)
{
	if (!mesh->vbuffer) mesh->vbuffer = mesh->graph->engine->getVertexBuffer (NULL);
	if (!mesh->ibuffer) mesh->ibuffer = mesh->graph->engine->getIndexBuffer (NULL);
	float wx = (size_x_set) ? size_x : size;
	float wy = (size_y_set) ? size_y : size;
	float wz = (size_z_set) ? size_z : size;
	genBox (mesh->vbuffer, mesh->ibuffer, Elea::Vector3f(-wx / 2, -wy / 2, -wz / 2), Elea::Vector3f(wx / 2, wy / 2, wz / 2));
	mesh->resizeMaterials (1);
	// mesh->setMaterial (0, WireMaterial::newWireMaterial (engine, NULL));
	if (material) {
		mesh->setMaterial (0, material->getSehleMaterial (mesh->graph->engine));
	} else {
		mesh->setMaterial (0, Sehle::ColorMaterial::newColorMaterial (mesh->graph->engine, NULL));
	}
	mesh->resizeFragments (1);
	mesh->frags[0].first = 0;
	mesh->frags[0].nindices = 36;
	mesh->frags[0].matidx = 0;
}

void
Box::generateMesh (f32 *v, int vstridebytes, f32 *n, int nstridebytes, f32 *t, int tstridebytes, u32 *indices, float sizex, float sizey, float sizez, int *nvertices, int *nindices)
{
	Elea::Vector3f p0(-sizex / 2, -sizey / 2, -sizez / 2);
	Elea::Vector3f p1(sizex / 2, sizey / 2, sizez / 2);
	generateMesh (v, vstridebytes, n, nstridebytes, t, tstridebytes, indices, p0, p1, nvertices, nindices);
}

void
Box::generateMesh (f32 *v, int vstridebytes, f32 *n, int nstridebytes, f32 *t, int tstridebytes, u32 *indices, const float *p0, const float *p1, int *nvertices, int *nindices)
{
	if (nvertices) {
		*nvertices = 6 * 4;
	}
	if (nindices) {
		*nindices = 6 * 6;
	}
	Elea::Vector3f c[8];
	for (int i = 0; i < 8; i++) {
		int x = ((i + 1) >> 1) & 1;
		int y = (i >> 1) & 1;
		int z = (i >> 2) & 1;
		c[i][Elea::X] = x * p0[0] + (1 - x) * p1[0];
		c[i][Elea::Y] = y * p0[1] + (1 - y) * p1[1];
		c[i][Elea::Z] = z * p0[2] + (1 - z) * p1[2];
	}
	static int ci[] = { 0, 1, 2, 3, 1, 5, 6, 2, 2, 6, 7, 3, 3, 7, 4, 0, 0, 4, 5, 1, 5, 4, 7, 6 };
	for (int i = 0; i < 6; i++) {
		const Elea::Vector3f& p0(c[ci[4 * i + 0]]);
		const Elea::Vector3f& p1(c[ci[4 * i + 1]]);
		const Elea::Vector3f& p2(c[ci[4 * i + 2]]);
		// const Elea::Vector3f& p3(c[ci[4 * i + 3]]);
		Elea::Vector3f normal = Elea::Vector3f(p0, p1) * Elea::Vector3f(p0, p2);
		normal.normalizeSelf ();
		if (v) {
			for (int j = 0; j < 4; j++) memcpy ((char *) v + (4 * i + j) * vstridebytes, c[ci[4 * i + j]], 3 * sizeof (f32));
		}
		if (n) {
			for (int j = 0; j < 4; j++) memcpy ((char *) n + (4 * i + j) * nstridebytes, normal, 3 * sizeof (f32));
		}
		if (t) {
			for (int j = 0; j < 4; j++) {
				Elea::Vector2f texcoord((Elea::f32) (((j + 1) & 3) >> 1), (Elea::f32) (j >> 1));
				memcpy ((char *) n + (4 * i + j) * tstridebytes, texcoord, 2 * sizeof (f32));
			}
		}
		if (indices) {
			indices[6 * i + 0] = 4 * i + 0;
			indices[6 * i + 1] = 4 * i + 1;
			indices[6 * i + 2] = 4 * i + 2;
			indices[6 * i + 3] = 4 * i + 0;
			indices[6 * i + 4] = 4 * i + 2;
			indices[6 * i + 5] = 4 * i + 3;
		}
	}
}

} // Namespace Miletos
