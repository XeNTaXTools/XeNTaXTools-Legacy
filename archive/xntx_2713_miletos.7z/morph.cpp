#define __MILETOS_MORPH_CPP__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2009
//

#include <malloc.h>
#include <stdlib.h>

#include "xml/base.h"

#include "morph.h"

namespace Miletos {

// MorphTarget

MorphTarget::MorphTarget (u32 flags)
: Object(flags), sid(NULL), vdata(NULL), ndata(NULL), tdata(NULL), indices(NULL), numindices(0), maxindex(0)
{
}

MorphTarget::~MorphTarget (void)
{
	clear ();
}

const Object::Type *
MorphTarget::objectType (void)
{
	return type ();
}

const Object::Type *
MorphTarget::type (void)
{
	static Type *mytype = NULL;
	static const Attribute attrs[] = {
		{ "sid", NULL, 0 }
	};
	if (!mytype) mytype = new Type(Object::type (), "MorphTarget", NULL, NULL, sizeof (attrs) / sizeof (attrs[0]), attrs);
	return mytype;
}

void
MorphTarget::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	Object::build (pnode, doc, ctx);

	buildAllAttributes (type (), ctx);

}

void
MorphTarget::set (const char *attrid, const char *val)
{
	if (!strcmp (attrid, "sid")) {
		if (sid) free (sid);
		sid = (val) ? strdup (val) : NULL;
		requestUpdate (MODIFIED);
	}
}

void
MorphTarget::clear (void)
{
	vdata = NULL;
	ndata = NULL;
	tdata = NULL;
	indices = NULL;
	numindices = 0;
	maxindex = 0;

	if (sid) free (sid);
	sid = NULL;
}

// Morph

Morph::Morph (void)
: Object(HAS_CHILDREN), sid(NULL), enabled(1), tgt0(-1), tgt1(-1), s(0)
{
}

Morph::~Morph (void)
{
	if (sid) free (sid);
}

static Object *
morph_factory (void)
{
	return new Morph();
}

const Object::Type *
Morph::objectType (void)
{
	return type ();
}

const Object::Type *
Morph::type (void)
{
	static Type *mytype = NULL;
	static const Attribute attrs[] = {
		{ "sid", NULL, 0 },
		{ "disabled", "false", 0 },
		{ "target0", "-1", 0 },
		{ "target0", "-1", 0 },
		{ "s", "0", 0 }
	};
	if (!mytype) mytype = new Type(Object::type (), "Morph", "morph", morph_factory, sizeof (attrs) / sizeof (attrs[0]), attrs);
	return mytype;
}

void
Morph::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	Object::build (pnode, doc, ctx);

	buildAllAttributes (type (), ctx);


	updateChildData (NULL);
}

void
Morph::release (void)
{
	targets.clear ();

	Object::release ();
}

Object *
Morph::childAdded (Thera::Node *cnode, Thera::Node *rnode)
{
	Object *cobj = Object::childAdded (cnode, rnode);

	updateChildData (NULL);

	return cobj;
}

void
Morph::childRemoved (Thera::Node *cnode, Thera::Node *rnode)
{
	updateChildData (cnode);

	Object::childRemoved (cnode, rnode);
}

void
Morph::set (const char *attrid, const char *val)
{
	if (!strcmp (attrid, "sid")) {
		if (sid) free (sid);
		sid = (val) ? strdup (val) : NULL;
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "disabled")) {
		enabled = 1;
		bool bval;
		if (XML::parseBoolean (&bval, val)) enabled = !bval;
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "target0")) {
		tgt0 = (val) ? atoi (val) : -1;
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "target1")) {
		tgt1 = (val) ? atoi (val) : -1;
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "s")) {
		if (!XML::parseNumber (&s, val)) s = 0;
		requestUpdate (MODIFIED);
	}
}

void
Morph::update (UpdateCtx *ctx, unsigned int flags)
{
	Object::update (ctx, flags);
}

void
Morph::updateChildData (Thera::Node *removed)
{
	targets.clear ();
	for (Object *child = children; child; child = child->next) {
		if (child->node == removed) continue;
		if (child->isType (MorphTarget::type ())) {
			targets.push_back ((MorphTarget *) child);
		}
	}
}

} // Namespace Miletos


