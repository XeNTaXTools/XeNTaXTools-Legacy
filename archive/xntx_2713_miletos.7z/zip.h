#ifndef __MILETOS_ZIP_H__
#define __MILETOS_ZIP_H__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2007-2009
//

#include <string>
#include <vector>
#include <map>

#include <miletos/types.h>
#include <miletos/filesystem.h>
#include <miletos/uri.h>

namespace Miletos {

namespace Zip {

unsigned int isGzip (const unsigned char *cdata, size_t csize);
unsigned char *gunzip (const unsigned char *cdata, size_t csize, size_t *zsize);

// fixme: Handle encodings (Lauris)

class FileData {
private:
	// Parent data container
	const unsigned char *cdata;
	size_t csize;
	bool privmap;

	struct FileEntry {
	public:
		// Name
		std::string canonicalname;
		size_t offset;
		u32 compressedsize;
		u32 uncompressedsize;
		int compressionmethod;
		// Mapping
		unsigned char *cdata;
		size_t csize;
		int cref;
	};

	// Helpers
	void loadEntries (bool ignorecase);
public:
	// Files
	std::vector<FileEntry> files;

	// Constructor
	FileData (const char *pzipfilename, bool ignorecase);
	FileData (const unsigned char *zdata, size_t zsize, bool ignorecase);
	// Destructor
	~FileData ();

	// Helpers
	bool isValid (void) const { return cdata != NULL; }
	bool getFileEntry (FileEntry& entry);
};

class FileHandler : public FileSystem::HandlerFileList {
private:
	FileData data;

	// Whether to ignore filename case if lookig files
	bool ignorecase;
	// Whether current directory data is loaded
	bool dirloaded;

	// Current directory contents
	std::vector<std::string> _lfiles;
	std::vector<size_t> _lsizes;
	std::vector<std::string> _lsubdirs;


	// Handler implementation
	// Test whether current handler has dir (relative to root)
	virtual bool hasDir (const char *name);
	// Test whether current handler has file (relative to root)
	// virtual bool hasFile (const char *name);

	// Set current reading directory to given value (or unset if there is no such dir)
	virtual bool loadDir (const char *name);
	// Return the number of files in reading dir
	virtual int getNumFiles (void);
	// Return the name of file in reading dir
	virtual const char *getFileName (int idx);
	// Return the size of file in reading dir
	virtual size_t getFileSize (int idx);
	// Return the number of subdirectories in reading dir
	virtual int getNumSubDirs (void);
	// Return the name of subdirectory in reading dir
	virtual const char *getSubDirName (int idx);
	// Get file image
	virtual unsigned const char *mmapFile (const char *name, size_t *size);
	// Release file image
	virtual void munmapFile (const unsigned char *cdata);

	// HandlerFileList implementation
	virtual void addFileMapping (Entry *entry);
public:
	// Constructor
	FileHandler (const char *zipfilename);
};

class URLHandler : public URI::URLHandler {
private:
	std::vector<FileSystem::Handler *> handlers;

	URLHandler (const char *location);
	virtual ~URLHandler (void);

	// URLHandler implementation
	virtual const unsigned char *mmapDataRelative (const char *name, size_t *size);
	virtual void munmapData (const unsigned char *data);
public:
	// Static constructor
	static URI::URLHandler *newURLHandler (const char *url);
};

}; // Namespace Zip

}; // Namespace Miletos

#endif
