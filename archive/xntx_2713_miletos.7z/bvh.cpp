#define __MILETOS_BVH_CPP__

//
// Miletos
//
// Copyright (C) Lauris Kaplinski 2010
//

#include <stdio.h>

#include <libarikkei/token.h>

#include <elea/quaternion.h>

#include "zip.h"
#include "uri.h"

#include "bvh.h"

namespace Miletos {

static Arikkei::Dict<const char *, BVHData *> objdict(31);

BVHData::BVHData (const char *purl)
: refcount(1), url(strdup (purl)), nframes(0)
{
	if (url) objdict.insert (url, this);
	URI::URLHandler *handler = URI::getHandler (url);
	if (!handler) return;
	size_t csize;
	const unsigned char *cdata = handler->mmapData (url, &csize);
	if (!cdata) {
		handler->unRef ();
		return;
	}
	if (Zip::isGzip (cdata, csize)) {
		size_t zsize;
		unsigned char *zdata = Zip::gunzip (cdata, csize, &zsize);
		if (zdata) {
			parse (zdata, zsize);
			free (zdata);
		}
	} else {
		parse (cdata, csize);
	}
	handler->munmapData (cdata);
	handler->unRef ();
}

BVHData::BVHData (const unsigned char *cdata, size_t csize, const char *purl)
: refcount(1), url(strdup (purl))
{
	if (url) objdict.insert (url, this);
	if (Zip::isGzip (cdata, csize)) {
		size_t zsize;
		unsigned char *zdata = Zip::gunzip (cdata, csize, &zsize);
		if (zdata) {
			parse (zdata, zsize);
			free (zdata);
		}
	} else {
		if (cdata) parse (cdata, csize);
	}
}

BVHData::~BVHData (void)
{
	if (url) {
		objdict.remove (url);
		free (url);
	}
}

static Arikkei::TokenChar tokenz[4];
static int ntokenz;

static const float BVHScale = 1.0f / 70;
// static const Elea::Matrix4x4f BVHTransform(0, 1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1);
static const Elea::Matrix4x4f BVHTransform(0, 0, 1, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1);
// static const Elea::Matrix4x4f BVHTransform(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);

unsigned int
BVHData::parse (const unsigned char *cdata, size_t csize)
{
	Arikkei::CharToken itokens("{\t}\tEnd Site\tFrame Time:");
	ntokenz = itokens.tokenize (tokenz, 4, false, false, false);
	// bdatav.clear ();
	Arikkei::TokenChar ft((const char *) cdata, csize);
	size_t cpos = 0;

	// Skeleton
	Arikkei::CharToken t = ft.nextToken (cpos, tokenz, ntokenz);
	if (t != "HIERARCHY") return false;
	t = ft.nextToken (cpos, tokenz, ntokenz);
	if (t != "ROOT") return false;
	t = ft.nextToken (cpos, tokenz, ntokenz);
	// if (t != "Hips") return false;
	if (!parseBone (-1, (const char *) t, cdata, csize, cpos)) {
		bones.clear ();
		return false;
	}

	// Animations
	t = ft.nextToken (cpos, tokenz, ntokenz);
	if (t != "MOTION") return false;
	t = ft.nextToken (cpos, tokenz, ntokenz);
	if (t != "Frames:") return false;
	t = ft.nextToken (cpos, tokenz, ntokenz);
	nframes = t.getInt ();
	t = ft.nextToken (cpos, tokenz, ntokenz);
	if (t != "Frame Time:") return false;
	t = ft.nextToken (cpos, tokenz, ntokenz);
	// float ftime = t.getFloat ();

	// int ncodes = 0;
	// for (size_t j = 0; j < bones.size (); j++) ncodes += bones[j].ncodes;
	// Arikkei::TokenChar *ctokenz = new Arikkei::TokenChar[ncodes];

	for (unsigned int i = 0; i < nframes; i++) {
		// fprintf (stderr, "frame %d (%d)\n", i, nframes);
		for (size_t j = 0; j < bones.size (); j++) {
			// fprintf (stderr, "bone %d (%d)\n", (int) j, (int) bones.size ());
			Bone *bone = &bones[j];
			// AnimationKey key;
			// key._time = 1000 * i * ftime;
			Orientation lab2p;
			lab2p.p = bone->offset;
			Elea::Matrix4x4f m;
			for (int k = 0; k < bone->ncodes; k++) {
				// fprintf (stderr, "Bone %d code %d\n", (int) j, k);
				t = ft.nextToken (cpos, tokenz, ntokenz);
				float val = t.getFloat ();
				switch (bone->codes[k]) {
				case XPOSITION:
					lab2p.p[Elea::X] = val * BVHScale;
					break;
				case YPOSITION:
					lab2p.p[Elea::Y] = val * BVHScale;
					break;
				case ZPOSITION:
					lab2p.p[Elea::Z] = val * BVHScale;
					break;
				case XROTATION:
					// ab2p.q =  ab2p.q * Elea::Quaternionf(Elea::Vector3fX, val * Elea::M_PI_F / 180);
					m.rotateObjectSelf (Elea::Vector3fY, val * Elea::M_PI_F / 180);
					break;
				case YROTATION:
					// ab2p.q = ab2p.q * Elea::Quaternionf(Elea::Vector3fY, val * Elea::M_PI_F / 180);
					m.rotateObjectSelf (Elea::Vector3fZ, val * Elea::M_PI_F / 180);
					break;
				case ZROTATION:
					// ab2p.q = ab2p.q * Elea::Quaternionf(Elea::Vector3fZ, val * Elea::M_PI_F / 180);
					m.rotateObjectSelf (Elea::Vector3fX, val * Elea::M_PI_F / 180);
					break;
				default:
					fprintf (stderr, "Bone %d: invalid key %d\n", (int) j, bone->codes[k]);
					return false;
					break;
				}
			}
			// m = BVHTransform * m;
			BVHTransform.transformVector3InPlace (lab2p.p);
			lab2p.q = m.getRotationQuaternion ();
			// bone->ab2p.push_back (ab2p);
			ab2p.push_back (lab2p);
		}
	}
	// delete[] ctokenz;

	while (cpos < ft.getLength ()) {
		Arikkei::TokenChar token = ft.nextToken (cpos, tokenz, ntokenz);
		fprintf (stderr, "Token: \"%s\"\n", (const char *) token);
	}

	return true;
}

unsigned int
BVHData::parseBone (int parent, const char *name, const unsigned char *cdata, size_t csize, size_t& cpos)
{
	Arikkei::TokenChar ft((const char *) cdata, csize);
	Arikkei::TokenChar t = ft.nextToken (cpos, tokenz, ntokenz);
	// {
	if (t != "{") return false;
	int bidx = (int) bones.size ();
	Bone bone;
	bone.name = name;
	bone.idx = bidx;
	bone.pidx = parent;
	bone.offset = Elea::Vector3f0;
	bone.endsite = Elea::Vector3f0;
	bones.push_back (bone);
	bones[bidx].ncodes = 0;
	// OFFSET X Y Z
	t = ft.nextToken (cpos, tokenz, ntokenz);
	if (t != "OFFSET") {
		fprintf (stderr, "Invalid token (should be OFFSET): %s\n", (const char *) t);
		return false;
	}
	Arikkei::CharToken tx = ft.nextToken (cpos, tokenz, ntokenz);
	Arikkei::CharToken ty = ft.nextToken (cpos, tokenz, ntokenz);
	Arikkei::CharToken tz = ft.nextToken (cpos, tokenz, ntokenz);
	bones[bidx].offset = Elea::Vector3f (tx.getFloat () * BVHScale, ty.getFloat () * BVHScale, tz.getFloat () * BVHScale);
	BVHTransform.transformVector3InPlace (bones[bidx].offset);
	t = ft.nextToken (cpos, tokenz, ntokenz);
	while (t != "}") {
		if (t == "CHANNELS") {
			// Parse channels
			t = ft.nextToken (cpos, tokenz, ntokenz);
			int nchannels = t.getInt ();
			if (nchannels > 6) {
				fprintf (stderr, "Invalid number of channels: %d\n", nchannels);
				return false;
			}
			for (int i = 0; i < nchannels; i++) {
				t = ft.nextToken (cpos, tokenz, ntokenz);
				if (t == "Xposition") {
					bones[bidx].codes[bones[bidx].ncodes++] = XPOSITION;
				} else if (t == "Yposition") {
					bones[bidx].codes[bones[bidx].ncodes++] = YPOSITION;
				} else if (t == "Zposition") {
					bones[bidx].codes[bones[bidx].ncodes++] = ZPOSITION;
				} else if (t == "Xrotation") {
					bones[bidx].codes[bones[bidx].ncodes++] = XROTATION;
				} else if (t == "Yrotation") {
					bones[bidx].codes[bones[bidx].ncodes++] = YROTATION;
				} else if (t == "Zrotation") {
					bones[bidx].codes[bones[bidx].ncodes++] = ZROTATION;
				} else {
					fprintf (stderr, "Invalid channel: %s\n", (const char *) t);
					return false;
				}
			}
		} else if (t == "JOINT") {
			t = ft.nextToken (cpos, tokenz, ntokenz);
			if (!parseBone (bidx, (const char *) t, cdata, csize, cpos)) {
				fprintf (stderr, "Cannot parse bone\n");
				return false;
			}
		} else if (t == "End Site") {
			t = ft.nextToken (cpos, tokenz, ntokenz);
			if (t != "{") return false;
			// OFFSET X Y Z
			t = ft.nextToken (cpos, tokenz, ntokenz);
			if (t != "OFFSET") {
				fprintf (stderr, "Invalid token (should be OFFSET): %s\n", (const char *) t);
				return false;
			}
			Arikkei::CharToken tx = ft.nextToken (cpos, tokenz, ntokenz);
			Arikkei::CharToken ty = ft.nextToken (cpos, tokenz, ntokenz);
			Arikkei::CharToken tz = ft.nextToken (cpos, tokenz, ntokenz);
			bones[bidx].endsite = Elea::Vector3f (tx.getFloat () * BVHScale, ty.getFloat () * BVHScale, tz.getFloat () * BVHScale);
			BVHTransform.transformVector3InPlace (bones[bidx].endsite);
			t = ft.nextToken (cpos, tokenz, ntokenz);
			if (t != "}") return false;
		} else {
			fprintf (stderr, "Invalid token: %s\n", (const char *) t);
			return false;
		}
		t = ft.nextToken (cpos, tokenz, ntokenz);
	}
	if (bones[bidx].ncodes > 6) {
		fprintf (stderr, "Parsing %s resulted in invalid number of codes: %d\n", name, bones[bidx].ncodes);
		return false;
	}
	return true;
}

BVHData *
BVHData::getBVHData (const char *url)
{
	if (url) {
		BVHData *objdata = objdict.lookup (url);
		if (objdata) {
			objdata->ref ();
			return objdata;
		}
	}
	return new BVHData(url);
}

BVHData *
BVHData::getBVHData (const unsigned char *cdata, size_t csize, const char *url)
{
	if (url) {
		BVHData *objdata = objdict.lookup (url);
		if (objdata) {
			objdata->ref ();
			return objdata;
		}
	}
	return new BVHData(cdata, csize, url);
}

// BoneAnimationBVH

BoneAnimationBVH::BoneAnimationBVH (void)
: BoneAnimation(0), source(NULL), bdata(NULL), bidx(-1)
{
	fps = 30;
}

BoneAnimationBVH::~BoneAnimationBVH (void)
{
	if (bdata) bdata->unRef ();
	if (source) free (source);
}

static Object *
boneanimationbvh_factory (void)
{
	return new BoneAnimationBVH();
}

const Object::Type *
BoneAnimationBVH::objectType (void)
{
	return type ();
}

const Object::Type *
BoneAnimationBVH::type (void)
{
	static Type *mytype = NULL;
	static const Attribute attrs[] = {
		{ "source", NULL, 0 },
		{ "bone", "-1", 0 }
	};
	if (!mytype) mytype = new Type(BoneAnimation::type (), "BoneAnimationBVH", "boneAnimationBVH", boneanimationbvh_factory, sizeof (attrs) / sizeof (attrs[0]), attrs);
	return mytype;
}

void
BoneAnimationBVH::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	BoneAnimation::build (pnode, doc, ctx);

	buildAllAttributes (type (), ctx);

}

void
BoneAnimationBVH::release (void)
{
	BoneAnimation::release ();
}

void
BoneAnimationBVH::set (const char *attrid, const char *val)
{
	if (!strcmp (attrid, "source")) {
		if (source) free (source);
		source = (val) ? strdup (val) : NULL;
		if (bdata) {
			bdata->unRef ();
			bdata = NULL;
			minframetime = 0;
			maxframetime = 0;
		}
		if (source) {
			bdata = BVHData::getBVHData (source);
			if (bdata && bdata->nframes) {
				maxframetime = (float) bdata->nframes - 1;
			}
		}
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "bone")) {
		bidx = (val) ? atoi (val) : -1;
		requestUpdate (MODIFIED);
	} else {
		BoneAnimation::set (attrid, val);
	}
}

Elea::Vector3f
BoneAnimationBVH::getPosition (unsigned int frameidx)
{
	if (!bdata || (frameidx >= bdata->nframes)) return Elea::Vector3f0;
	return bdata->ab2p[frameidx * bdata->bones.size () + bidx].p;
}

Elea::Quaternionf
BoneAnimationBVH::getQuaternion (unsigned int frameidx)
{
	if (!bdata || (frameidx >= bdata->nframes)) return Elea::Quaternionf0;
	return bdata->ab2p[frameidx * bdata->bones.size () + bidx].q;
}

} // Namespace Miletos

