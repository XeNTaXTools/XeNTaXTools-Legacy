#ifndef __MILETOS_ANIMATION_GRAPH_H__
#define __MILETOS_ANIMATION_GRAPH_H__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2009
//

#include <miletos/types.h>
#include <miletos/animation.h>

namespace Miletos {

class Figure;
class MorphTarget;

namespace Animation {

class Graph;

// Pose

class Pose : public Object {
private:
	char *sourceid;

	// Object implementation
	virtual const Type *objectType (void);

protected:
	// Object implementation
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	virtual void set (const char *attrid, const char *val);
	virtual void identityAdded (Document *pdocument, const char *pidentity, Object *pobject);
	virtual void identityRemoved (Document *pdocument, const char *pidentity);
	virtual void attachedObjectRelease (Object *attached, void *data);
	virtual void attachedObjectModified (Object *attached, unsigned int flags, void *data);
public:
	char *sid;
	Source *source;
	float frametime;

	Pose (void);

	// Type system
	static const Type *type (void);
};

class Transition : public Source {
private:
	char *keyposesids[2];

	// Object implementation
	virtual const Type *objectType (void);

	void clear (unsigned int poses, unsigned int startsid, unsigned int endsid);
protected:
	// Object implementation
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	virtual void set (const char *attrid, const char *val);
	virtual void attachedObjectRelease (Object *attached, void *data);
	virtual void attachedObjectModified (Object *attached, unsigned int flags, void *data);
public:
	// Endpoint poses
	Pose *keyposes[2];
	// Transition time
	float duration;

	Transition (void);

	// Type system
	static const Type *type (void);

	// Attach transition to graph - i.e. resolve keyframes and attach to poses (NULL detaches)
	void attachToGraph (Graph *graph);
};

class Graph : public Object {
private:
	// Object implementation
	virtual const Type *objectType (void);

	// Helper
	void updateChildData (Thera::Node *removed);
protected:
	// Object implementation
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	virtual Object *childAdded (Thera::Node *cnode, Thera::Node *rnode);
	virtual void childRemoved (Thera::Node *cnode, Thera::Node *rnode);
	virtual void update (UpdateCtx *ctx, unsigned int flags);

public:
	u32 nposes;
	Pose **poses;
	u32 nsources;
	Source **sources;

	Graph (void);

	// Type system
	static const Type *type (void);

	// Lookup child by SID
	Pose *lookupPose (const char *sid);
};

//
// Controller applies graph animation data to Figure
//

class Controller : public Object {
private:
	char *targetid;
	char *graphid;
	char *animationsid;

	// Object implementation
	virtual const Type *objectType (void);
protected:
	// Object implementation
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	virtual void set (const char *attrid, const char *val);
	virtual void update (UpdateCtx *ctx, unsigned int flags);
	virtual void identityAdded (Document *pdocument, const char *pidentity, Object *pobject);
	virtual void identityRemoved (Document *pdocument, const char *pidentity);
	virtual void attachedObjectRelease (Object *attached, void *data);
	virtual void attachedObjectModified (Object *attached, unsigned int flags, void *data);

public:
	Figure *target;
	Graph *graph;
	u32 transition;
	f32 transitiontime;

	Controller (void);

	// Type system
	static const Type *type (void);

	void setTransitionTime (float time);
};

} // Namespace Animation

} // Namespace Miletos

#endif

