#define __MILETOS_MESHMD3_CPP__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2007
//

#include "meshmd3.h"

#if 0
namespace Miletos {

void
MeshMD3::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	// Superclass implementation
	SMesh::build (pnode, doc, ctx);

	// Read attributes
	buildAttribute ("source");
}

void
MeshMD3::release (void)
{
	// Superclass implementation
	SMesh::release ();
}

void
MeshMD3::set (const char *attrid, const char *val)
{
	if (!strcmp (attrid, "source")) {
		// Read mesh source
		requestUpdate (MODIFIED);
	} else {
		// Superclass implementation
		SMesh::set (attrid, val);
	}
}

void
MeshMD3::update (UpdateCtx *ctx, unsigned int flags)
{
	// fixme: Calculate BBox
	// Superclass implementation
	SMesh::update (ctx, flags);
}


void
MeshMD3::buildMesh (Sehle::StaticMesh *mesh)
{
	// Build Sehle mesh object
}

const Object::Type *
MeshMD3::objectType (void)
{
	return type ();
}

const Object::Type *
MeshMD3::type (void)
{
	static Type *mytype = NULL;
	if (!mytype) mytype = new Type("MeshMD3", SMesh::type (), 0, NULL);
	return mytype;
}

} // Namespace Miletos
#endif
