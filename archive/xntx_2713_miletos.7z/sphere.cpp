#define __MILETOS_SPHERE_CPP__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2007
//

static const int debug = 0;

#include <stdlib.h>
#include <stdio.h>

#include <elea/types.h>

#include <sehle/engine.h>
#include <sehle/graph.h>
#include <sehle/renderable.h>
#include <sehle/commonmaterials.h>
#include <sehle/material-multipass-dns.h>

#include "xml/base.h"
#include "primitives.h"
#include "image.h"

#include "sphere.h"

namespace Miletos {

static Object *
sphere_factory (void)
{
	return new Sphere();
}

const Object::Type *
Sphere::objectType (void)
{
	return type ();
}

const Object::Type *
Sphere::type (void)
{
	static Type *mytype = NULL;
	static const Attribute attrs[] = {
		{ "radius", "1", 0 },
		{ "subdivs", "2", 0 }
	};
	if (!mytype) mytype = new Type(Item::type (), "Sphere", "sphere", sphere_factory, sizeof (attrs) / sizeof (attrs[0]), attrs);
	return mytype;
}

void
Sphere::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	Item::build (pnode, doc, ctx);

	buildAllAttributes (type (), ctx);

}

void
Sphere::release (void)
{
	// Superclass implementation
	Item::release ();
}

void
Sphere::set (const char *attrid, const char *val)
{
	if (!strcmp (attrid, "radius")) {
		if (!XML::parseNumber (&radius, val)) {
			radius = 1;
		}
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "subdivs")) {
		if (!XML::parseInteger (&level, val)) {
			level = 2;
		}
		requestUpdate (MODIFIED);
	} else {
		// Superclass implementation
		Item::set (attrid, val);
	}
}

void
Sphere::update (UpdateCtx *ctx, unsigned int flags)
{
	bbox.setEmpty ();

	generateSphere ();
	if (renderable) {
		generateRenderable ((Sehle::StaticMesh *) renderable);
	}

	Elea::Matrix4x4f i2ws(ctx->i2w.scaleObject (radius, radius, radius));
	bbox.grow (vertices[0], (Elea::u32) vertices.size (), sizeof (vertices[0]), &i2ws);

	// Superclass implementation
	Item::update (ctx, flags);
}

Sehle::Renderable *
Sphere::show (Sehle::Graph *graph, Sehle::u32 contextmask)
{
	Sehle::StaticMesh *mesh = new Sehle::StaticMesh(graph, contextmask);

	generateRenderable (mesh);

	return mesh;
}

Item *
Sphere::trace (const Elea::Line3f *wray, unsigned int mask, float *distance)
{
	// fixme:
	float p0, p1;
	if (bbox.getIntersection (*wray, p0, p1)) {
		if (distance) *distance = p0;
		return this;
	}
	return NULL;
}

float
Sphere::longitude (const Elea::Vector3f& v)
{
	if ((v[Elea::Z] == 1) || (v[Elea::Z] == -1)) return 0.5f;
	float s = sqrt (1 - v[Elea::Z] * v[Elea::Z]);
	float latitude = atan2 (v[Elea::Y] / s, v[Elea::X] / s) / Elea::M_2PI_F;
	if (latitude < 0) latitude = latitude + 1.0f;
	return latitude;
}

float
Sphere::latitude (const Elea::Vector3f& v)
{
	return 0.5f + atan2 (v[Elea::Z], sqrt (1 - v[Elea::Z] * v[Elea::Z])) / Elea::M_PI_F;
}

struct Sphere::CBuf {
	f32 *vertices;
	int vstridebytes;
	f32 *normals;
	int nstridebytes;
	f32 *texcoords;
	int tstridebytes;
	// Access
	Elea::Vector3f& vertex (int idx) { return *((Elea::Vector3f *)((char *) vertices + idx * vstridebytes)); }
	Elea::Vector3f& normal (int idx) { return *((Elea::Vector3f *)((char *) normals + idx * nstridebytes)); }
	Elea::Vector2f& texCoord (int idx) { return *((Elea::Vector2f *)((char *) texcoords + idx * tstridebytes)); }
};

void
Sphere::addVertex (const Elea::Vector3f& vertex, CBuf *cbuf, u32 *vpos, bool end)
{
	if (vpos) {
		if (cbuf) {
			Elea::Vector3f vn(vertex.normalize ());
			float s = longitude (vn);
			float t = latitude (vn);
			if (end && (s < 0.25f)) s += 1.0;
			if (cbuf->vertices) cbuf->vertex (*vpos) = vertex;
			if (cbuf->normals) cbuf->normal (*vpos) = vn;
			if (cbuf->texcoords) cbuf->texCoord (*vpos) = Elea::Vector2f(s, t);
			// vb[*vpos] = vn;
			// nb[*vpos] = vn;
			// tb[*vpos] = Elea::Vector2f(s, t);
		}
		*vpos += 1;
	}
}

struct Sphere::Side
{
	int v0;
	int v1;
	int vmid;
	int side0;
	int side1;
	int opposite;
	Side (void) : v0(0), v1(0), vmid(-1), side0(-1), side1(-1), opposite(-1) {}
};

void
Sphere::subdivideSide (Side& side, Side *sb, u32 *spos, CBuf *cbuf, u32 *vpos, float radius)
{
	assert (side.vmid < 0);
	if ((side.opposite >= 0) && (sb[side.opposite].vmid >= 0)) {
		if ((sb[side.opposite].v0 != side.v1) || (sb[side.opposite].v1 != side.v0)) {
			fprintf (stderr, "sides messed up!\n");
		}
		// Opposite side has already subdivided vertices
		side.vmid = sb[side.opposite].vmid;
	} else {
		// Create new vertex
		Elea::Vector3f v(Elea::Vector3fZ);
		if (cbuf->vertices) {
			v = cbuf->vertex (side.v0) + cbuf->vertex (side.v1);
			v = radius * v.normalize ();
		}
		bool end = false;
		if (cbuf->texcoords) {
			end = (cbuf->texCoord (side.v0)[0] > 0.5f) || (cbuf->texCoord (side.v1)[0] > 0.5f);
		}
		side.vmid = *vpos;
		addVertex (v, cbuf, vpos, end);
	}
	side.side0 = *spos;
	sb[*spos].v0 = side.v0;
	sb[*spos].v1 = side.vmid;
	if ((side.opposite >= 0) && (sb[side.opposite].side1 >= 0)) {
		// Opposite is already divided
		sb[*spos].opposite = sb[side.opposite].side1;
		sb[sb[side.opposite].side1].opposite = *spos;
	}
	*spos += 1;
	side.side1 = *spos;
	sb[*spos].v0 = side.vmid;
	sb[*spos].v1 = side.v1;
	if ((side.opposite >= 0) && (sb[side.opposite].side0 >= 0)) {
		// Opposite is already divided
		sb[*spos].opposite = sb[side.opposite].side0;
		sb[sb[side.opposite].side0].opposite = *spos;
	}
	*spos += 1;
}

void
Sphere::subdivide (Side *sb, u32 *spos, CBuf *cbuf, u32 *vpos, u32 *ib, u32 *ipos, u32 s0, u32 s1, u32 s2, float radius, int level)
{
	if (level > 0) {
		// Subdivide triangle
		// Subdivide sides
		subdivideSide (sb[s0], sb, spos, cbuf, vpos, radius);
		subdivideSide (sb[s1], sb, spos, cbuf, vpos, radius);
		subdivideSide (sb[s2], sb, spos, cbuf, vpos, radius);
		// Add inner sides
		u32 s02 = *spos;
		sb[*spos].v0 = sb[s0].vmid;
		sb[*spos].v1 = sb[s2].vmid;
		*spos += 1;
		u32 s10 = *spos;
		sb[*spos].v0 = sb[s1].vmid;
		sb[*spos].v1 = sb[s0].vmid;
		*spos += 1;
		u32 s21 = *spos;
		sb[*spos].v0 = sb[s2].vmid;
		sb[*spos].v1 = sb[s1].vmid;
		*spos += 1;
		subdivide (sb, spos, cbuf, vpos, ib, ipos, sb[s0].side0, s02, sb[s2].side1, radius, level - 1);
		subdivide (sb, spos, cbuf, vpos, ib, ipos, sb[s1].side0, s10, sb[s0].side1, radius, level - 1);
		subdivide (sb, spos, cbuf, vpos, ib, ipos, sb[s2].side0, s21, sb[s1].side1, radius, level - 1);
		u32 s20 = *spos;
		sb[*spos].v0 = sb[s2].vmid;
		sb[*spos].v1 = sb[s0].vmid;
		*spos += 1;
		u32 s01 = *spos;
		sb[*spos].v0 = sb[s0].vmid;
		sb[*spos].v1 = sb[s1].vmid;
		*spos += 1;
		u32 s12 = *spos;
		sb[*spos].v0 = sb[s1].vmid;
		sb[*spos].v1 = sb[s2].vmid;
		*spos += 1;
		// Opposites
		sb[s02].opposite = s20;
		sb[s20].opposite = s02;
		sb[s10].opposite = s01;
		sb[s01].opposite = s10;
		sb[s21].opposite = s12;
		sb[s12].opposite = s21;
		subdivide (sb, spos, cbuf, vpos, ib, ipos, s01, s12, s20, radius, level - 1);
		return;
	}
	// No more subdivisions - add indices of this triangle
	// fixme: think why this was originally needed (Lauris)
	// if ((s0 > 0.5) || (s1 > 0.5) || (s2 > 0.5)) {
	// 	// Handle special case
	// 	if (s0 < 0.5) s0 += 1;
	// 	if (s1 < 0.5) s1 += 1;
	// 	if (s2 < 0.5) s2 += 1;
	// }
	if (ipos) {
		if (ib) {
			ib[*ipos] = sb[s0].v0;
			ib[*ipos + 1] = sb[s1].v0;
			ib[*ipos + 2] = sb[s2].v0;
		}
		*ipos += 3;
	}
}

void
Sphere::generateMesh (f32 *v, int vstridebytes, f32 *n, int nstridebytes, f32 *t, int tstridebytes, u32 *indices, float radius, int level, int dir, int& nvertices, int& nindices)
{
	// Subdiv 0
	// nvertices = 7;
	int nfaces = 8;
	int nsides = 24;
	// fixme: calculate proper number of new vertices
	for (int i = 0; i < level; i++) {
		// Each subdivision creates 12 sides and max 3 vertices per side
		// nvertices += 3 * nfaces;
		nsides += 12 * nfaces;
		nfaces *= 4;
	}
	// nindices = 3 * nfaces;

	std::vector<Side> sides;
	sides.resize (nsides);

	static const float vdata[] = { 1, 0, 0, 0, 1, 0, -1, 0, 0, 0, -1, 0, 1, 0, 0, 0, 0, 1, 0, 0, -1 };
	static const float tdata[] = { 0, 0.5f, 0.25f, 0.5f, 0.5f, 0.5f, 0.75f, 0.5f, 1.0f, 0.5f, 0.5f, 1, 0.5f, 0 };
	static const int idata[] = { 0, 1, 5, 1, 2, 5, 2, 3, 5, 3, 4, 5, 4, 3, 6, 3, 2, 6, 2, 1, 6, 1, 0, 6 };
	// static const int sdata[] = { 0 };

	u32 vpos = 0;
	u32 spos = 0;
	u32 ipos = 0;
	// Set initial vertices
	for (int i = 0; i < 7; i++) {
		Elea::Vector3f vi(&vdata[3 * i]);
		vi.normalizeSelf ();
		if (v) *((Elea::Vector3f *)((char *) v + vpos * vstridebytes)) = radius * vi;
		if (n) *((Elea::Vector3f *)((char *) n + vpos * nstridebytes)) = vi;
		Elea::Vector2f ti(&tdata[2 * i]);
		if (t) *((Elea::Vector2f *)((char *) t + vpos * tstridebytes)) = ti;
		vpos += 1;
	}
	// Set initial sides
	for (int i = 0; i < 8; i++) {
		sides[spos].v0 = idata[3 * i + 0];
		sides[spos].v1 = idata[3 * i + 1];
		spos += 1;
		sides[spos].v0 = idata[3 * i + 1];
		sides[spos].v1 = idata[3 * i + 2];
		spos += 1;
		sides[spos].v0 = idata[3 * i + 2];
		sides[spos].v1 = idata[3 * i + 0];
		spos += 1;
	}
	// Opposites
	for (int i = 0; i < 24; i++) {
		for (int j = i + 1; j < 24; j++) {
			if ((sides[i].v0 == sides[j].v1) && (sides[i].v1 == sides[j].v0)) {
				sides[i].opposite = (int) j;
				sides[j].opposite = (int) i;
				break;
			}
		}
	}
	// Subdivide sides
	CBuf cbuf;
	cbuf.vertices = v;
	cbuf.vstridebytes = vstridebytes;
	cbuf.normals = n;
	cbuf.nstridebytes = nstridebytes;
	cbuf.texcoords = t;
	cbuf.tstridebytes = tstridebytes;
	for (int i = 0; i < 8; i++) {
		subdivide (&sides[0], &spos, &cbuf, &vpos, &indices[0], &ipos, 3 * i, 3 * i + 1, 3 * i + 2, radius, level);
	}
	if (dir < 0) {
		if (indices) {
			for (u32 i = 0; i < ipos; i += 3) {
				u32 t = indices[i + 1];
				indices[i + 1] = indices[i + 2];
				indices[i + 2] = t;
			}
		}
		if (n) {
			for (u32 i = 0; i < vpos; i++) {
				Elea::Vector3f *nv = (Elea::Vector3f *) ((char *) n + i * nstridebytes);
				*nv = -*nv;
			}
		}
	}
	nvertices = vpos;
	nindices = ipos;
}

void
Sphere::generateSphere (void)
{
	int nvertices = 7;
	int nfaces = 8;
	int nsides = 24;
	// fixme: calculate proper number of new vertices
	for (int i = 0; i < level; i++) {
		// Each subdivision creates 12 sides and max 3 vertices per side
		nvertices += 3 * nfaces;
		nsides += 12 * nfaces;
		nfaces *= 4;
	}
	int nindices = 3 * nfaces;

	vertices.resize (nvertices);
	normals.resize (nvertices);
	texcoords.resize (nvertices);
	indices.resize (nindices);

	generateMesh (vertices[0], (int) sizeof (vertices[0]), normals[0], (int) sizeof (normals[0]), texcoords[0], (int) sizeof (texcoords[0]), &indices[0], 1, level, 1, nvertices, nindices);
	vertices.resize (nvertices);

	// Calculate tangents
	std::vector<Elea::Vector3f> t;
	t.resize (nvertices);
	for (size_t i = 0; i < vertices.size (); i++) t[i] = Elea::Vector3f0;
	for (size_t i = 0; i < indices.size (); i += 3) {
		for (int k = 0; k < 3; k++) {
			int idx0 = indices[i + (k + 0) % 3];
			int idx1 = indices[i + (k + 1) % 3];
			int idx2 = indices[i + (k + 2) % 3];
			Elea::Vector3f v0(vertices[idx1] - vertices[idx0]);
			Elea::Vector3f v1(vertices[idx2] - vertices[idx0]);
			Elea::Vector3f vq(v0 + v1);
			Elea::Vector2f t0(texcoords[idx1] - texcoords[idx0]);
			Elea::Vector2f t1(texcoords[idx2] - texcoords[idx0]);
			// if (fabs (t0[1]) > 0.01 && fabs (t1[1]) > 0.01) continue;
			// Ts * t0.x + Tt * t0.y = v0
			// Ts * t1.x + Tt * t1.y = v1
			// D = t0.x * t1.y - t1.x * t0.y
			// Ds = v0 * t1.y - v1 * t0.y
			// Dt = t0.x * v1 - t1.x * v0
			float D = t0[Elea::X] * t1[Elea::Y] - t1[Elea::X] * t0[Elea::Y];
			Elea::Vector3f Ds = v0 * t1[Elea::Y] - v1 * t0[Elea::Y];
			Elea::Vector3f Dt = t0[Elea::X] * v1 - t1[Elea::X] * v0;
			Elea::Vector3f Ts = Ds / D;
			Elea::Vector3f Tt = Dt / D;
			if (false && fabs (Ts[2]) > 0.01) {
				// For some reason texture s is not parallel to xy plane
				fprintf (stderr, "v0: %.2f %.2f %.2f\n", v0[0], v0[1], v0[2]);
				fprintf (stderr, "t0: %.3f %.3f\n", t0[0], t0[1]);
				fprintf (stderr, "v1: %.2f %.2f %.2f\n", v1[0], v1[1], v1[2]);
				fprintf (stderr, "t1: %.3f %.3f\n", t1[0], t1[1]);
				fprintf (stderr, "Ts: %.2f %.2f %.2f\n", Ts[0], Ts[1], Ts[2]);
				fprintf (stderr, "Tt: %.2f %.2f %.2f\n", Tt[0], Tt[1], Tt[2]);
			}
			Elea::Vector3f cv0 = Ts * t0[Elea::X] + Tt * t0[Elea::Y];
			Elea::Vector3f cv1 = Ts * t1[Elea::X] + Tt * t1[Elea::Y];
			Ts.normalizeSelf ();
			Tt.normalizeSelf ();
			Elea::Vector3f q0(v0 - cv0);
			Elea::Vector3f q1(v1 - cv1);
			if ((q0.length2 () > 0.001) || (q1.length2 () > 0.001)) {
				fprintf (stderr, "-");
			}
			Elea::Vector3f normal = normals[idx0].normalize ();
			Elea::Vector3f tangent = Ts.normalize ();
			// Elea::Vector3f binormal = Ty.normalize ();
			Elea::Vector3f binormal = normal * tangent;
			float weight = sin (Elea::Vector3f::angle (v0, vq));
			Elea::Vector3f lt(tangent * weight);
			if (Elea::Vector3f::scalarProduct (t[idx0], lt) < 0) {
				// fprintf (stderr, "=");
			}
			if (t[idx0].length2 () > -0.01) t[idx0] += lt;
			if (idx0 == 271) {
				fprintf (stderr, "v0: %.2f %.2f %.2f\n", v0[0], v0[1], v0[2]);
				fprintf (stderr, "t0: %.3f %.3f\n", t0[0], t0[1]);
				fprintf (stderr, "v1: %.2f %.2f %.2f\n", v1[0], v1[1], v1[2]);
				fprintf (stderr, "t1: %.3f %.3f\n", t1[0], t1[1]);
				fprintf (stderr, "Ts: %.2f %.2f %.2f\n", Ts[0], Ts[1], Ts[2]);
				fprintf (stderr, "Tt: %.2f %.2f %.2f\n", Tt[0], Tt[1], Tt[2]);
				fprintf (stderr, "D %.g\n", D);
			}
		}
	}
	for (size_t i = 0; i < vertices.size (); i++) {
		Elea::Vector3f normal = normals[i].normalize ();
		Elea::Vector3f tangent = t[i].normalize ();
		Elea::Vector3f binormal = normal * tangent;
		binormal.normalizeSelf ();
		// tangent = binormal * normal;
		Elea::Matrix4x4f tspace;
		for (int j = 0; j < 3; j++) {
			tspace[0 + j] = tangent[j];
			tspace[4 + j] = binormal[j];
			tspace[8 + j] = normal[j];
		}
		Elea::Quaternionf q = tspace.getRotationQuaternion ();
		q.normalizeSelf ();
		Elea::Matrix4x4f r;
		r.setRotation (q);
		float dd = q[0] * q[0] + q[1] * q[1] + q[2] * q[2];
		if (dd > 1) dd = 1;
		q[3] = sqrt (1 - dd);
		float x =      2 * (q[0] * q[2] + q[1] * q[3]);
		float y =      2 * (q[1] * q[2] - q[0] * q[3]);
		float z = 1 - 2 * (q[0] * q[0] + q[1] * q[1]);
		Elea::Vector3f d(normal - Elea::Vector3f(x, y, z));
		// Elea::Vector3f d(normal - r.getColVector3 (2));
		if (d.length2 () > 0.001) {
			fprintf (stderr, ".");
		}
		// normals[i].set (q[0], q[1], q[2]);
	}
}

void
Sphere::generateRenderable (Sehle::StaticMesh *smesh)
{
	if (!smesh->vbuffer) {
		smesh->vbuffer = smesh->graph->engine->getVertexBuffer (NULL);
	}
	if (!smesh->ibuffer) {
		smesh->ibuffer = smesh->graph->engine->getIndexBuffer (NULL);
	}
	smesh->vbuffer->setUp ((Sehle::u32) vertices.size (), 8);
	smesh->vbuffer->setOffset (Sehle::VertexBuffer::COORDINATES, 0);
	smesh->vbuffer->setOffset (Sehle::VertexBuffer::NORMALS, 3);
	smesh->vbuffer->setOffset (Sehle::VertexBuffer::TEXCOORDS, 6);
	smesh->ibuffer->resize ((Sehle::u32) indices.size ());

	smesh->vbuffer->map (Sehle::VertexBuffer::WRITE);
	smesh->ibuffer->map (Sehle::IndexBuffer::WRITE);

	for (size_t i = 0; i < vertices.size (); i++) {
		smesh->vbuffer->setValues ((Sehle::i32) i, smesh->vbuffer->offset[Sehle::VertexBuffer::COORDINATES], radius * vertices[i], 3);
		smesh->vbuffer->setValues ((Sehle::i32) i, smesh->vbuffer->offset[Sehle::VertexBuffer::NORMALS], normals[i], 3);
		smesh->vbuffer->setValues ((Sehle::i32) i, smesh->vbuffer->offset[Sehle::VertexBuffer::TEXCOORDS], texcoords[i], 2);
	}
	for (size_t i = 0; i < indices.size (); i++) {
		smesh->ibuffer->indices[i] = indices[i];
	}
	smesh->resizeMaterials (1);
	if (true) {
		Sehle::ColorMaterial *mat = Sehle::ColorMaterial::newColorMaterial (smesh->graph->engine, NULL);
		mat->setColor (Elea::Color4f(1.0f, 0.5f, 0.5f, 0.5f));
		// smesh->setMaterial (0, WireMaterial::newWireMaterial (smesh->graph->engine, NULL));
		// smesh->setMaterial (0, ColorMaterial::newColorMaterial (smesh->graph->engine, NULL));
		smesh->setMaterial (0, mat);
	} else {
		Sehle::MaterialMultipassDNS *matdns = Sehle::MaterialMultipassDNS::newMaterialMultipassDNS (smesh->graph->engine, NULL);
		NRPixBlock px;
		nr_pixblock_setup_fast (&px, NR_PIXBLOCK_MODE_G8, 0, 0, 0, 0, 0);
		if (Image::load (&px, "earthmap1k.jpg")) {
			matdns->setMap (Sehle::MaterialMultipassDNS::COLOR, "earthmap1k.jpg", &px);
		}
		if (Image::load (&px, "earthspec1k.jpg")) {
			matdns->setMap (Sehle::MaterialMultipassDNS::SPECULAR, "earthspec1k.jpg", &px);
		}
		nr_pixblock_release (&px);
		smesh->setMaterial (0, matdns);
	}
	smesh->vbuffer->unMap ();
	smesh->ibuffer->unMap ();

	smesh->resizeFragments (1);
	smesh->frags[0].matidx = 0;
	smesh->frags[0].first = 0;
	smesh->frags[0].nindices = (Sehle::u32) indices.size ();
}

} // Namespace Miletos
