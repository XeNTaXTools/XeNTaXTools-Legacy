#define __MILETOS_INTERFACE_CPP__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2007
//

#include "interface.h"

namespace Miletos {

EventHandler::EventHandler (void)
: next(NULL), x(0), y(0), buttonstate(0), modifierstate(0)
{
}

EventHandler::~EventHandler (void)
{
	sig_destroy.invoke (this);
}

bool
EventHandler::sendMouseMove (double px, double py)
{
	x = px;
	y = py;
	bool result = mouseMove (x, y);
	if (buttonstate != 0) sig_dragged.invoke (this, buttonstate);
	return result;
}

bool
EventHandler::sendMouseButtonDown (int button, double px, double py)
{
	x = px;
	y = py;
	bool result = mouseButtonDown (button, px, py);
	sig_grabbed.invoke (this, button);
	return result;
}

bool
EventHandler::sendMouseButtonUp (int button, double px, double py)
{
	x = px;
	y = py;
	bool result = mouseButtonUp (button, px, py);
	sig_released.invoke (this, button);
	return result;
}

bool
EventHandler::sendMouseScroll (double xdir, double ydir, double px, double py)
{
	x = px;
	y = py;
	bool result = mouseScroll (xdir, ydir, px, py);
	sig_scroll.invoke (this, (float) xdir, (float) ydir);
	return result;
}

bool
EventHandler::sendKeyPress (int key)
{
	bool result = keyPress (key);
	if (key < NUM_MODIFIERS) {
		modifierstate |= (1 << key);
	}
	sig_key_pressed.invoke (this, key);
	return result;
}

bool
EventHandler::sendKeyRelease (int key)
{
	bool result = keyRelease (key);
	if (key < NUM_MODIFIERS) {
		modifierstate &= ~(1 << key);
	}
	sig_key_released.invoke (this, key);
	return result;
}

void
EventHandler::invokeResize (double width, double height)
{
	resize (width, height);
}

void
EventHandler::invokeTimeStep (double time)
{
	timeStep (time);
}

// EventStack

EventStack::EventStack (void)
: handler(NULL), grabbed(NULL)
{
}

EventStack::~EventStack (void)
{
	while (handler) {
		EventHandler *current = handler;
		handler = handler->next;
		delete current;
	}
}

void
EventStack::pushHandler (EventHandler *phandler)
{
	phandler->next = handler;
	handler = phandler;
}

void
EventStack::popHandler (void)
{
	if (handler) {
		if (grabbed == handler) grabbed = NULL;
		EventHandler *prev = handler;
		handler = handler->next;
		delete prev;
	}
}

bool
EventStack::sendMouseMove (double x, double y)
{
	if (grabbed) {
		return grabbed->sendMouseMove (x, y);
	}
	for (EventHandler *h = handler; h != NULL; h = h->next) {
		if (h->sendMouseMove (x, y)) return true;
	}
	return false;
}

bool
EventStack::sendMouseButtonDown (int button, double x, double y)
{
	// Update button state for the whole stack
	for (EventHandler *h = handler; h != NULL; h = h->next) {
		h->setButtonState (button);
	}
	if (grabbed) {
		return grabbed->sendMouseButtonDown (button, x, y);
	}
	for (EventHandler *h = handler; h != NULL; h = h->next) {
		if (h->sendMouseButtonDown (button, x, y)) {
			grabbed = h;
			return true;
		}
	}
	return false;
}

bool
EventStack::sendMouseButtonUp (int button, double x, double y)
{
	// Update button state for the whole stack
	for (EventHandler *h = handler; h != NULL; h = h->next) {
		h->clearButtonState (button);
	}
	if (grabbed) {
		if (grabbed->sendMouseButtonUp (button, x, y) && (grabbed->buttonstate == 0)) {
			grabbed = NULL;
			return true;
		}
		return false;
	}
	// Button up should not happen without grab
	return false;
}

bool
EventStack::sendMouseScroll (double xdir, double ydir, double x, double y)
{
	if (grabbed) {
		return grabbed->sendMouseScroll (xdir, ydir, x, y);
	}
	for (EventHandler *h = handler; h != NULL; h = h->next) {
		if (h->sendMouseScroll (xdir, ydir, x, y)) return true;
	}
	return false;
}

bool
EventStack::sendKeyPress (int key)
{
	if (key < EventHandler::NUM_MODIFIERS) {
		// Update modifier state for the whole stack
		for (EventHandler *h = handler; h != NULL; h = h->next) {
			h->setModifierState (key);
		}
	}
	if (grabbed) {
		return grabbed->sendKeyPress (key);
	}
	for (EventHandler *h = handler; h != NULL; h = h->next) {
		if (h->sendKeyPress (key)) return true;
	}
	return false;
}

bool
EventStack::sendKeyRelease (int key)
{
	if (key < EventHandler::NUM_MODIFIERS) {
		// Update modifier state for the whole stack
		for (EventHandler *h = handler; h != NULL; h = h->next) {
			h->clearModifierState (key);
		}
	}
	if (grabbed) {
		return grabbed->sendKeyRelease (key);
	}
	for (EventHandler *h = handler; h != NULL; h = h->next) {
		if (h->sendKeyRelease (key)) return true;
	}
	return false;
}

void
EventStack::invokeResize (double width, double height)
{
	for (EventHandler *h = handler; h != NULL; h = h->next) {
		h->invokeResize (width, height);
	}
}

void
EventStack::invokeTimeStep (double time)
{
	for (EventHandler *h = handler; h != NULL; h = h->next) {
		h->invokeTimeStep (time);
	}
}

// TrackBallHandler

void
TrackBall::setMode (Mode pmode)
{
	if (pmode == _mode) return;
	_mode = pmode;
}

void
TrackBall::setDimensions (float width, float height)
{
	_cx = width / 2;
	_cy = height / 2;
	// fixme: Think about radiuses for different modes
	_radius = _rscale * (width >= height) ? width : height;
}

void
TrackBall::grab (float x, float y)
{
	_grabnx = (x - _cx) / _radius;
	_grabny = (y - _cy) / _radius;
	if (_mode == TRACKBALL) {
		_grabisv = getUnitSphereIntersection (_grabnx, _grabny);
	}
	axis = Elea::Vector3fZ;
	angle = 0;
}


void
TrackBall::drag (float x, float y)
{
	float nx = (x - _cx) / _radius;
	float ny = (y - _cy) / _radius;
	if (_mode == TRACKBALL) {
		Elea::Vector3f isv = getUnitSphereIntersection (nx, ny);
		axis = _grabisv * isv;
		angle = 0;
		if (axis.length2 ()) {
			axis.normalizeSelf ();
			angle = Elea::Vector3f::angle (_grabisv, isv);
		} else {
			isv = getUnitSphereIntersection ((_grabnx + nx) / 2, (_grabny + ny) / 2);
			axis = _grabisv * isv;
			if (axis.length2 ()) {
				axis.normalizeSelf ();
				angle = Elea::M_PI_F;
			} else {
				axis = Elea::Vector3fZ;
				angle = 0;
			}
		}
	} else if (_mode == FREEROTATE) {
		Elea::Vector3f v0(_grabnx, _grabny, -1);
		Elea::Vector3f v1(nx, ny, -1);
		axis = v1 * v0;
		if (axis.length2 ()) {
			angle = (float) hypot (nx - _grabnx, ny - _grabny) * Elea::M_PI2_F / _rscale;
		} else {
			angle = 0;
		}
	} else if (_mode == ZROTATE) {
	}
}

Elea::Vector3f
TrackBall::getUnitSphereIntersection (float x, float y)
{
	float z2 = 1 - x * x - y * y;
	float z = (z2 > 0) ? sqrtf (z2) : 0;
	// fixme: depending on solution used one may have to normalize x & y (Lauris)
	Elea::Vector3f isv(x, y, z);
	return isv.normalize ();
}

} // Namespace Miletos

