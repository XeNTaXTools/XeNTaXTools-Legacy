#ifndef __MILETOS_MESH_COLLADA_H__
#define __MILETOS_MESH_COLLADA_H__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2008-2009
//

#include <miletos/uri.h>
#include <miletos/helpers/datablock.h>
#include <miletos/skinnedgeometry.h>
#include <miletos/collada/collada.h>

namespace Miletos {

struct ColladaTextureRef;
struct ColladaMaterialRef;

class ColladaData : public DataBlock {
private:
	std::string name;

	ColladaData (const unsigned char *cdata, size_t csize, const char *url, URI::URLHandler *handler);
	virtual ~ColladaData (void);
public:
	// Handler for resolving relative references
	URI::URLHandler *handler;
	// Location data
	URI::Location location;

	// Thera tree
	Thera::Document *thedoc;
	// Semantic tree
	Document *mildoc;
	// Collada root
	Collada::Root *croot;

	// Static constructor
	static ColladaData *getColladaData (const char *url);
};

class SkinnedGeometryCollada : public SkinnedGeometry {
private:
	ColladaData *bdata;

	// Private material definitions
	std::vector<ColladaTextureRef *> textures;
	std::vector<ColladaMaterialRef *> materials;

	// Object implementation
	virtual const Type *objectType (void);
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	virtual void set (const char *attrid, const char *val);

	// Geometry implementation
	virtual TextureInfo *getTextureInfo (unsigned int matidx, unsigned int texidx, unsigned int getimage);
	virtual u32 getMaterialInfo (MaterialInfo *mat, u32 matidx);
	// PoseableGeometry implementation
	virtual Sehle::Material *getMaterial (int matidx, Sehle::Engine *engine);

	void loadData (const char *url);
	void addMaterial (Collada::Mesh *mesh, Collada::TechniqueCommon *ctech, int ctechmatidx);
protected:
public:
	// Constructor
	SkinnedGeometryCollada (void);

	// Type system
	static const Type *type (void);
};

class StaticGeometryCollada : public StaticGeometry {
private:
	ColladaData *bdata;

	// Private material definitions
	std::vector<ColladaTextureRef *> textures;
	std::vector<ColladaMaterialRef *> materials;

	// Object implementation
	virtual const Type *objectType (void);
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	virtual void set (const char *attrid, const char *val);
	// Geometry implementation
	virtual TextureInfo *getTextureInfo (unsigned int matidx, unsigned int texidx, unsigned int getimage);
	virtual u32 getMaterialInfo (MaterialInfo *mat, u32 matidx);
	// StaticGeometry implementation
	virtual Sehle::Material *getMaterial (int matidx, Sehle::Engine *engine);

	// Helpers
	void loadData (const char *url);
	void addMaterial (Collada::Mesh *mesh, Collada::TechniqueCommon *ctech, int ctechmatidx);
public:
	StaticGeometryCollada (void);

	// Type system
	static const Type *type (void);
};

} // Namespace Miletos

#endif

