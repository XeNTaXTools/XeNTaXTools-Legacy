#define __MILETOS_ANIMATIONDATA_CPP__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2011
//

#include <malloc.h>

#include "xml/base.h"

#include "animationdata.h"

namespace Miletos {

namespace Animation {

BoneKeys::BoneKeys (void)
: BoneAnimation(0), sid(NULL), p0(Elea::Vector3f0), ntimes(0), times(NULL), npositions(0), positions(NULL), nrotations(0), rotations(NULL)
{
	fps = 30;
}

BoneKeys::~BoneKeys (void)
{
}

static Object *
bonekeys_factory (void)
{
	return new BoneKeys();
}

const Object::Type *
BoneKeys::objectType (void)
{
	return type ();
}

const Object::Type *
BoneKeys::type (void)
{
	static Type *mytype = NULL;
	static const Attribute attrs[] = {
		{ "sid", NULL, 0 },
		{ "p0", NULL, 0 },
		{ "times", NULL, 0 },
		{ "positions", NULL, 0 },
		{ "rotations", NULL, 0 }
	};
	if (!mytype) mytype = new Type(BoneAnimation::type (), "BoneKeys", "animation:boneKeys", bonekeys_factory, sizeof (attrs) / sizeof (attrs[0]), attrs);
	return mytype;
}

void
BoneKeys::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	BoneAnimation::build (pnode, doc, ctx);

	buildAllAttributes (type (), ctx);

}

void
BoneKeys::release (void)
{
	if (sid) free (sid);
	if (times) {
		ntimes = 0;
		free (times);
		times = NULL;
	}
	if (positions) {
		npositions = 0;
		free (positions);
		positions = NULL;
	}
	if (rotations) {
		nrotations = 0;
		free (rotations);
		rotations = NULL;
	}
	BoneAnimation::release ();
}

void
BoneKeys::set (const char *attrid, const char *val)
{
	if (!strcmp (attrid, "sid")) {
		if (sid) free (sid);
		sid = (val) ? strdup (val) : NULL;
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "p0")) {
		Elea::Matrix4x4f m;
		if (!XML::parseNumbers (p0, 3, val)) {
			p0 = Elea::Vector3f0;
		}
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "times")) {
		if (times) {
			ntimes = 0;
			free (times);
			times = NULL;
			minframetime = 0;
			maxframetime = 0;
		}
		if (XML::parseNumbers (NULL, &ntimes, val) && ntimes) {
			times = (float *) malloc (ntimes * sizeof (float));
			XML::parseNumbers (times, &ntimes, val);
			minframetime = times[0];
			maxframetime = times[ntimes - 1];
		}
		nframes = ntimes;
		frametimes = times;
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "positions")) {
		if (positions) {
			npositions = 0;
			free (positions);
			positions = NULL;
		}
		unsigned int nvalues;
		if (XML::parseNumbers (NULL, &nvalues, val)) {
			npositions = nvalues / 3;
			if (npositions) {
				positions = (float *) malloc (npositions * 3 * sizeof (float));
				XML::parseNumbers (positions, npositions * 3, val);
			}
		}
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "rotations")) {
		if (rotations) {
			nrotations = 0;
			free (rotations);
			rotations = NULL;
		}
		unsigned int nvalues;
		if (XML::parseNumbers (NULL, &nvalues, val)) {
			nrotations = nvalues / 3;
			if (nrotations) {
				rotations = (float *) malloc (nrotations * 3 * sizeof (float));
				XML::parseNumbers (rotations, nrotations * 3, val);
			}
		}
		requestUpdate (MODIFIED);
	} else {
		BoneAnimation::set (attrid, val);
	}
}

Elea::Vector3f
BoneKeys::getPosition (unsigned int frameidx)
{
	return (frameidx < npositions) ? p0 + Elea::Vector3f(&positions[3 * frameidx]) : p0;
}

Elea::Quaternionf
BoneKeys::getQuaternion (unsigned int frameidx)
{
	return (frameidx < nrotations) ? Elea::Quaternionf(rotations[3 * frameidx], rotations[3 * frameidx + 1], rotations[3 * frameidx + 2]) : Elea::Quaternionf0;
}

} // Namespace Animation

} // Namespace Miletos


