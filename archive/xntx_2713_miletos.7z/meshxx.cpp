#define __MILETOS_MESH_XX_CPP__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2008
//

static const int debug = 1;
static const int debug_frame = 0;
static const int debug_mesh = 1;
static const int debug_material = 1;
static const int debug_texture = 1;

#include <stdlib.h>
#include <stdio.h>

#include <libarikkei/dict.h>

#include <sehle/GLee.h>

#include <sehle/engine.h>
#include <sehle/graph.h>
#include <sehle/rendercontext.h>
#include <sehle/commonmaterials.h>
#include <sehle/material-multipass-dns.h>

#include "filesystem.h"
#include "image.h"
#include "xpp.h"
#include "material.h"
#include "xml/base.h"
#include "helpers/sjis.h"
#include "shaders-dict.h"

#include "meshxx.h"

// static const float DefaultScale = 0.0702f;
static const float DefaultScale = 0.0766584f;

namespace Miletos {

// XXData

static void printHexBytes16 (const unsigned char *cdata, size_t cpos, size_t length);

static const float *shuffle3 (const float *v);
static const float *shuffle16 (const float *m);

// XXData

class XXData : public DataBlock {
private:
	URI::URLHandler *handler;
	size_t csize;
	const unsigned char *cdata;

	XXData (const unsigned char *xdata, size_t xsize, const char *url, URI::URLHandler *handler);
	virtual ~XXData (void);

	void setup (void);
public:
	struct JointMask {
		// fixme: Do it better way (Lauris)
		// Max 256 joints
		u32 m[8];
		JointMask (void) { for (int i = 0; i < 8; i++) m[i] = 0; }
		bool test (int joint) const { int p = joint / 32; int q = 1 << (joint % 32); return (m[p] & q) != 0; }
		void clear (void) { for (int i = 0; i < 8; i++) m[i] = 0; }
		void set (int joint) { int p = joint / 32; int q = 1 << (joint % 32); m[p] |= q; }
		friend JointMask operator| (const JointMask& a, const JointMask& b) { JointMask d; for (int i = 0; i < 8; i++) d.m[i] = a.m[i] | b.m[i]; return d; }
		friend JointMask operator& (const JointMask& a, const JointMask& b) { JointMask d; for (int i = 0; i < 8; i++) d.m[i] = a.m[i] & b.m[i]; return d; }
		friend bool operator|| (const JointMask& a, const JointMask& b) { for (int i = 0; i < 8; i++) if (a.m[i] || b.m[i]) return true; return false; }
		friend bool operator&& (const JointMask& a, const JointMask& b) { for (int i = 0; i < 8; i++) if (a.m[i] && b.m[i]) return true; return false; }
		friend bool operator== (const JointMask& a, const JointMask& b) { for (int i = 0; i < 8; i++) if (a.m[i] != b.m[i]) return false; return true; }
		int getNumJoints (void) const { int n = 0; for (int i = 0; i < 8; i++) for (u32 q = 0x80000000; q != 0; q = q >> 1) if (m[i] & q) n += 1; return n; }
	};

	struct Triangle {
		int vertex[3];
		int njoints;
		JointMask joints;
		static int compare (const void *a, const void *b) { return ((const Triangle *) b)->njoints - ((const Triangle *) a)->njoints; }
	};

	// For mesh types < 4
	struct Vertex_1 {
		u32 index;
		f32 coord[3];
		f32 weights[3];
		u8 bones[4];
		f32 normal[3];
		f32 texcoord[2];
	};

	// For mesh type 4
	struct Vertex_2 {
		u16 index;
		f32 coord[3];
		f32 weights[3];
		u8 bones[4];
		f32 normal[3];
		f32 texcoord[2];
		u32 unknown[5];
	};

	// Local container
	struct Vertex {
		Elea::Vector3f coords;
		Elea::Vector3f normals;
		Elea::Vector2f texcoords;
		f32 weights[3];
		u8 bones[4];
	};

	struct Mesh {
		u8 matflags;
		int matidx;
		u32 nindices;
		const u16 *indices;
		u32 nvertices;
		const Vertex_1 *vertexdata_1;
		const Vertex_2 *vertexdata_2;
		Vertex *vertices;
		// 2 * nvertices floats present if type > 0
		const float *type1data;
		// 2 * nvertices floats present if type == 2
		const float *type2data;
		// Parent frame for this mesh
		int frameidx;
		// First vertex of this mesh
		int firstvertex;

		Mesh ();
		~Mesh ();
	};

	struct Bone {
		// Bone is synonymous to frame
		const unsigned char *xxname;
		// Sequential numbers
		// fixme: Should really test whether this is always the case
		int index;
		// This is precalculated o2b matrix
		const f32 *matrix;
		// Frame index in our mesh
		int frameidx;
	};

	struct Frame {
		int parent;
		const unsigned char *xxname;
		// std::string name;
		std::vector<Frame *> children;
		const f32 *matrix;
		Elea::Cuboid3f meshlistbbox;
		std::vector<Mesh *> meshes;
		u32 nvertdup;
		Vertex *vertdup;
		std::vector<Bone *> bones;
		// Test
		Elea::Matrix4x4f f2p;
		Elea::Matrix4x4f f2o;
		Elea::Matrix4x4f o2f;

		Frame ();
		~Frame ();
	};

	struct Material {
		const unsigned char *xxname;
		const float (*color)[4];
		float shininess;
		const unsigned char *texname[4];
		int texidx[4];
		// Material falgs as used by mesh
		u16 flags;
	};

	struct Texture {
		const unsigned char *xxname;
		int width;
		int height;
		const int *format;
		int dsize;
		const unsigned char *ddata;
	};

	// Root frame
	Frame *rootframe;
	// Frames
	std::vector<Frame *> frames;
	// Meshes
	std::vector<Mesh *> meshes;
	// Materials
	std::vector<Material *> materials;
	// Textures
	std::vector<Texture *> textures;

	// Static constructor
	static XXData *getXXData (const char *url);

	// Helpers
	Frame *parseFrame (const unsigned char *cdata, size_t csize, size_t& cpos, int frametype, int parent);
	unsigned int parseMesh (Mesh *mesh, const unsigned char *cdata, size_t csize, size_t& cpos, int frametype, int meshtype, int frame);
	Bone *parseBone (const unsigned char *cdata, size_t csize, size_t& cpos);
	Material *parseMaterial (const unsigned char *cdata, size_t csize, size_t& cpos);
	Texture *parseTexture (const unsigned char *cdata, size_t csize, size_t& cpos);
	u32 parseVertex (Vertex *vertex, const unsigned char *cdata, int frametype);

	static int parseName (const unsigned char *cdata, size_t csize, size_t& cpos);
	static char *getName (const unsigned char *cdata);
	static const char *getNameStatic (const unsigned char *cdata);
	static bool nameIsEqual (const unsigned char *a, const unsigned char *b);
};

XXData::XXData (const unsigned char *xdata, size_t xsize, const char *purl, URI::URLHandler *phandler)
: DataBlock (purl, "XXData"), handler(phandler), cdata(xdata), csize(xsize)
{
	handler->ref ();
	setup ();
}

XXData::~XXData (void)
{
	handler->munmapData (cdata);
	handler->unRef ();
}

void
XXData::setup (void)
{
	size_t cpos = 0;

	// fixme: We need a way to query file type (Lauris)
	int formattype;
	if (true) {
		// SB3 and similar types
		formattype = cdata[cpos];
		cpos += 26;
	} else {
		formattype = 0;
		cpos += 21;
	}

	// Root frame
	rootframe = parseFrame (cdata, csize, cpos, formattype, -1);
	if (!rootframe) return;

	// Unknown i32;
	// int unknown = Xpp::getI32LE (cdata + cpos);
	cpos += 4;

	int nmaterials = Xpp::getI32LE (cdata + cpos);
	cpos += 4;

	for (int i = 0; i < nmaterials; i++) {
		Material *material = parseMaterial (cdata, csize, cpos);
		materials.push_back (material);
		// if (!strcmp (getNameStatic (material->xxname), "m_sbb_hama")) {
		//	fprintf (stderr, "hama\n");
		// }
	}

	int ntextures = Xpp::getI32LE (cdata + cpos);
	cpos += 4;

	for (int i = 0; i < ntextures; i++) {
		Texture *texture = parseTexture (cdata, csize, cpos);
		textures.push_back (texture);
	}

	// Set up mesh firstvertex
	int nvertices = 0;
	for (size_t i = 0; i < meshes.size (); i++) {
		meshes[i]->firstvertex = nvertices;
		nvertices += meshes[i]->nvertices;
	}

	// Resolve textures
	for (size_t i = 0; i < materials.size (); i++) {
		Material *material = materials[i];
		for (int j = 0; j < 4; j++) {
			size_t k;
			for (k = 0; k < textures.size (); k++) {
				if (material->texname[j] && nameIsEqual (material->texname[j], textures[k]->xxname)) break;
			}
			if (k < textures.size ()) {
				material->texidx[j] = (int) k;
			} else {
				material->texidx[j] = -1;
			}
		}
	}

	for (size_t i = 0; i < meshes.size (); i++) {
		Material *material = materials[meshes[i]->matidx];
		if (material->flags >= 256) {
			material->flags = meshes[i]->matflags;
		} else if (material->flags != meshes[i]->matflags) {
			fprintf (stderr, "XXData::XXData: Inconsistnecy in material flags (%x %x)\n", material->flags, meshes[i]->matflags);
		}
		fprintf (stderr, "Mesh %s (%0x) ", getNameStatic(frames[meshes[i]->frameidx]->xxname), meshes[i]->matflags);
		fprintf (stderr, "Material %s (%0x)\n", getNameStatic(material->xxname), material->flags);
	}

	// Compare bone and frame matrixes
	for (size_t i = 0; i < frames.size (); i++) {
		frames[i]->f2p.set (shuffle16 (frames[i]->matrix));
		if (frames[i]->parent >= 0) {
			frames[i]->f2o = frames[frames[i]->parent]->f2o * frames[i]->f2p;
		} else {
			frames[i]->f2o = frames[i]->f2p;
		}
		frames[i]->f2o.invert (&frames[i]->o2f);
	}
	for (size_t i = 0; i < frames.size (); i++) {
		if (debug > 1) fprintf (stderr, "Frame %d %s\n", (int) i, getNameStatic (frames[i]->xxname));
		for (size_t j = 0; j < frames[i]->bones.size (); j++) {
			if (debug > 0) fprintf (stderr, "Bone %d %s\n", frames[i]->bones[j]->index, getNameStatic (frames[i]->bones[j]->xxname));
			Elea::Matrix4x4f o2b(shuffle16 (frames[i]->bones[j]->matrix));
			size_t k;
			for (k = 0; k < frames.size (); k++) {
				if (nameIsEqual (frames[i]->bones[j]->xxname, frames[k]->xxname)) {
					// Found it
					frames[i]->bones[j]->frameidx = (int) k;
					Elea::Vector3f v0[4];
					for (int l = 0; l < 4; l++) {
						v0[l].set (frames[k]->o2f.getColVector3 (l));
					}
					Elea::Vector3f v1[4];
					for (int l = 0; l < 4; l++) {
						v1[l].set (o2b.getColVector3 (l));
					}
					bool differ = false;
					for (int l = 0; l < 4; l++) {
						Elea::Vector3f d(v1[l] - v0[l]);
						if (d.length () > 0.01) {
							differ = true;
							break;
						}
					}
					if (differ) {
						fprintf (stderr, "Frame %s", getNameStatic (frames[k]->xxname));
						fprintf (stderr, " and bone %s matrixes differ\n", getNameStatic (frames[i]->bones[j]->xxname));
						for (int l = 0; l < 16; l++) fprintf (stderr, "%.2f ", frames[k]->o2f[l]);
						fprintf (stderr, "\n");
						for (int l = 0; l < 16; l++) fprintf (stderr, "%.2f ", o2b[l]);
						fprintf (stderr, "\n");
					}
					break;
				}
			}
			if (k >= frames.size ()) {
				frames[i]->bones[j]->frameidx = -1;
				fprintf (stderr, "Did not find frame for bone %s\n", getNameStatic (frames[i]->bones[j]->xxname));
			}
		}
	}

	fprintf (stderr, "\n");
}

XXData *
XXData::getXXData (const char *purl)
{
	XXData *xx = NULL;
	if (purl) {
		xx = (XXData *) lookupDataBlock (purl, "XXData");
		if (xx) return xx;
		URI::URLHandler *handler = URI::getHandler (purl);
		if (handler) {
			size_t csize;
			const unsigned char *cdata = handler->mmapData ((const unsigned char *) purl, &csize);
			if (cdata) {
				xx = new XXData (cdata, csize, purl, handler);
			}
			handler->unRef ();
		}
	}
	return xx;
}

int
XXData::parseName (const unsigned char *cdata, size_t csize, size_t& cpos)
{
	unsigned char s[4096];
	int namelen = Xpp::getI32LE (cdata + cpos);
	if ((namelen < 0) || (namelen > 4096)) return -1;
	// Name in Shift-Jis
	for (int i = 0; i < namelen; i++) s[i] = ~cdata[cpos + 4 + i];
	int utf8len = sjis_to_utf8 (NULL, 0, s, namelen);
	if (utf8len < 0) return -1;
	cpos += 4;
	cpos += namelen;

	return utf8len;
}

XXData::Frame::Frame ()
{
	nvertdup = 0;
	vertdup = NULL;
}

XXData::Frame::~Frame ()
{
	if (vertdup) free (vertdup);
}

XXData::Frame *
XXData::parseFrame (const unsigned char *cdata, size_t csize, size_t& cpos, int frametype, int parent)
{
	int myidx = (int) frames.size ();

	// Frame name
	// XXname
	const unsigned char *xxname = cdata + cpos;
	if (parseName (cdata, csize, cpos) < 0) {
		fprintf (stderr, "XXData::parseFrame: invalid name\n");
		return NULL;
	}
	if (debug) fprintf (stderr, "XXData::parseFrame: Frame %s (%d)\n", getNameStatic (xxname), myidx);
	// At least 4 + 64 + 16 + 4 + 24 + 16 bytes are required for frame data
	if ((cpos + 128) >= csize) {
		fprintf (stderr, "XXData::parseFrame: Frame section too short (%d bytes)\n", (int) (csize - cpos));
		return NULL;
	}

	// Num children
	// u32
	u32 numchildren = Xpp::getU32LE (cdata + cpos);
	if (numchildren > 4096) {
		fprintf (stderr, "XXData::parseFrame: Invalid number of children: %d (%x)\n", (int) numchildren, numchildren);
		return NULL;
	}
	cpos += 4;

	// Matrix
	// f32[16]
	const f32 *matrix = (const f32 *) (cdata + cpos);
	float d = Elea::Matrix4x4f(matrix).determinant ();
	if ((fabs (matrix[3]) > 0.0001) || (fabs (matrix[7]) > 0.0001) || (fabs (matrix[11]) > 0.0001) || (fabs (matrix[15] - 1.0f) > 0.0001)) {
		fprintf (stderr, "XXData::parseFrame: Invalid frame matrix (determinant %.2f\n", d);
		return NULL;
	}
	cpos += 64;

	// Unknown
	// 16 bytes
	if (debug_frame > 0) {
		fprintf (stderr, "XXData::parseFrame: UnknownA[16]\n");
		printHexBytes16 (cdata, cpos, 16);
	}
	cpos += 16;

	// Num meshes
	// u32
	u32 nummeshes = Xpp::getU32LE (cdata + cpos);
	if (nummeshes > 4096) {
		fprintf (stderr, "XXData::parseFrame: Invalid number of meshes: %d (%x)\n", (int) nummeshes, nummeshes);
		return NULL;
	}
	cpos += 4;

	// Create frame
	Frame *frame = new Frame();
	frames.push_back (frame);
	frame->parent = parent;
	frame->xxname = xxname;
	frame->matrix = matrix;
	if (debug_frame > 1) fprintf (stderr, "XXData::parseFrame: Translation %.2f %.2f %.2f\n", frame->matrix[12], frame->matrix[13], frame->matrix[14]);
	if (debug_frame > 1) fprintf (stderr, "XXData::parseFrame: Num meshes %d\n", nummeshes);

	// Bounding box
	// f32[6]
	memcpy (frame->meshlistbbox, cdata + cpos, 6 * sizeof (float));
	cpos += 24;

	// Unknown
	// 16 bytes
	if (debug_frame > 0) {
		fprintf (stderr, "XXData::parseFrame: UnknownB[16]\n");
		printHexBytes16 (cdata, cpos, 16);
	}
	cpos += 16;

	if (nummeshes > 0) {
		// At least 1 + 2 + 8 + 4 bytes are required for frame data
		if ((cpos + 15) >= csize) {
			fprintf (stderr, "XXData::parseFrame: Mesh section too short (%d bytes)\n", (int) (csize - cpos));
			delete frame;
			return NULL;
		}

		// Mesh type
		// u8
		char meshtype = (char) cdata[cpos];
		if ((debug_frame > 1) && (meshtype == 2)) {
			fprintf (stderr, "mesh type 2\n");
		}
		cpos += 1;

		for (u32 i = 0; i < nummeshes; i++) {
			Mesh *mesh = new Mesh();
			if (parseMesh (mesh, cdata, csize, cpos, frametype, meshtype, myidx)) {
				frame->meshes.push_back (mesh);
				meshes.push_back (mesh);
			} else {
				delete mesh;
				fprintf (stderr, "XXData::parseFrame: Could not parse child mesh\n");
				delete frame;
				return NULL;
			}
		}

		// Number of private vertices
		// u16
		frame->nvertdup = Xpp::getU16LE (cdata + cpos);
		cpos += sizeof (u16);

		if (debug_frame > 1) {
			int nmeshverts = 0;
			int nmeshindices = 0;
			for (size_t i = 0; i < frame->meshes.size (); i++) {
				fprintf (stderr, "Mesh %d nvers %d nindices %d\n", (int) i, frame->meshes[i]->nvertices, frame->meshes[i]->nindices);
				nmeshverts += frame->meshes[i]->nvertices;
				nmeshindices += frame->meshes[i]->nindices;
			}
			fprintf (stderr, "Num meshes %d Total vertices %d indices %d Num vertdup %d\n", nummeshes, nmeshverts, nmeshindices, frame->nvertdup);
		}

		// Unknown
		// 8 bytes
		if (debug_frame > 0) {
			fprintf (stderr, "XXData::parseFrame: UnknownC[8]\n");
			printHexBytes16 (cdata, cpos, 8);
		}
		cpos += 8;

		// Private vertices
		// Vertex[numvertices]
		if ((cpos + frame->nvertdup * sizeof (Vertex)) >= csize) {
			fprintf (stderr, "XXData::parseFrame: Mesh section too short for vertices (%d bytes)\n", (int) (csize - cpos));
			delete frame;
			return NULL;
		}
		frame->vertdup = (Vertex *) malloc (frame->nvertdup * sizeof (Vertex));
		for (u32 i = 0; i < frame->nvertdup; i++) {
			cpos += parseVertex (&frame->vertdup[i], cdata + cpos, frametype);
		}

		// Test
		if (debug_frame > 2) {
			for (u32 i = 0; i < frame->nvertdup; i++) {
				Elea::Vector3f v0(frame->vertdup[i].coords);
				bool found = false;
				fprintf (stderr, "%d ", i);
				for (size_t j = 0; j < frame->meshes.size (); j++) {
					for (u32 k = 0; k < frame->meshes[j]->nvertices; k++) {
						Elea::Vector3f v1(frame->meshes[j]->vertices[k].coords);
						Elea::Vector3f v(v1 - v0);
						if (v.length () < 0.0001) {
							fprintf (stderr, "%d/%d ", (int) j, k);
							found = true;
						}
					}
				}
				if (!found) {
					fprintf (stderr, "NOT FOUND\n");
				}
				fprintf (stderr, "\n");
			}
		}

		// Test 2
		if (debug_frame > 2) {
			for (size_t j = 0; j < frame->meshes.size (); j++) {
				for (u32 k = 0; k < frame->meshes[j]->nvertices; k++) {
					bool found = false;
					Elea::Vector3f v1(frame->meshes[j]->vertices[k].coords);
					for (u32 i = 0; i < frame->nvertdup; i++) {
						Elea::Vector3f v0(frame->vertdup[i].coords);
						Elea::Vector3f v(v1 - v0);
						if (v.length () < 0.0001) {
							// fprintf (stderr, "%d/%d ", j, k);
							found = true;
						}
					}
					if (!found) {
						fprintf (stderr, "%d/%d ", (int) j, k);
					}
				}
			}
			fprintf (stderr, "\n");
		}

		// Number of bones
		// u32
		u32 nbones = Xpp::getU32LE (cdata + cpos);
		if (nbones > 4096) {
			fprintf (stderr, "XXData::parseFrame: Invalid number of bones: %d (%x)\n", (int) nbones, nbones);
			delete frame;
			return NULL;
		}
		cpos += 4;

		// Bones
		for (u32 j = 0; j < nbones; j++) {
			Bone *bone = parseBone (cdata, csize, cpos);
			if (!bone) {
				fprintf (stderr, "XXData::parseFrame: Could not parse child bone\n");
				delete frame;
				return NULL;
			}
			frame->bones.push_back (bone);
		}
	} else {
		frame->nvertdup = 0;
		frame->vertdup = NULL;
	}

	// Children
	for (u32 i = 0; i < numchildren; i++) {
		Frame *child = parseFrame (cdata, csize, cpos, frametype, myidx);
		if (!child) {
			fprintf (stderr, "XXData::parseFrame: Could not parse child frame\n");
			delete frame;
			return NULL;
		}
		frame->children.push_back (child);
	}

	return frame;
}

XXData::Mesh::Mesh ()
{
	nvertices = 0;
	vertices = NULL;
}

XXData::Mesh::~Mesh ()
{
	if (vertices) free (vertices);
}

unsigned int
XXData::parseMesh (Mesh *mesh, const unsigned char *cdata, size_t csize, size_t& cpos, int frametype, int meshtype, int frameidx)
{
	memset (mesh, 0, sizeof (mesh));

	mesh->frameidx = frameidx;

	// Flags
	// 16 bytes
	mesh->matflags = cdata[cpos];
	// Seems to be:
	// 00 64 00 00 00 00 00 00 00 00 00 00 00 00 00 00 - normal
	// 04 64 00 00 00 00 00 00 00 00 00 00 00 00 00 00 - hilight
	// 06 64 00 00 00 00 00 00 00 00 00 00 00 00 00 00 - hilight (on top of transparent object?)
	// 08 64 00 00 00 00 00 00 00 00 00 00 00 00 00 00 - shadows
	// 0a 64 00 00 00 00 00 00 00 00 00 00 00 00 00 00 - shadows
	// 0c 64 00 00 00 00 00 00 00 00 00 00 00 00 00 00 - shadows, positive, with transparency
	//                                                 - the same code is used for some hair meshes
	if (debug_mesh > 0) {
		fprintf (stderr, "XXData::parseMesh: UnknownA[16] (Material flags)\n");
		printHexBytes16 (cdata, cpos, 16);
	}
	cpos += 16;

	// Material index (u32)
	mesh->matidx = Xpp::getI32LE (cdata + cpos);
	if ((mesh->matidx < 0) || (mesh->matidx > 4096)) {
		fprintf (stderr, "Invalid material index %d (%x)\n", mesh->matidx, mesh->matidx);
		return 0;
	}
	cpos += 4;

	// Number of indices (u32)
	mesh->nindices = Xpp::getU32LE (cdata + cpos);
	cpos += 4;
	if (mesh->nindices > 10000000) {
		fprintf (stderr, "Invalid number of indices %d (%x)\n", (int) mesh->nindices, mesh->nindices);
		return 0;
	}
	// Indices
	// u16[numindices]
	mesh->indices = (const u16 *) (cdata + cpos);
	cpos += mesh->nindices * sizeof (u16);

	// Number of vertices (u32)
	mesh->nvertices = Xpp::getU32LE (cdata + cpos);
	if (mesh->nvertices > 10000000) {
		fprintf (stderr, "Invalid number of vertices %d (%x)\n", (int) mesh->nvertices, mesh->nvertices);
		return 0;
	}
	cpos += 4;
	if (debug_mesh > 1) {
		fprintf (stderr, "Nvertices %d nindices %d\n", mesh->nvertices, mesh->nindices);
	}
	// Vertices
	if (frametype < 4) {
		mesh->vertexdata_1 = (const Vertex_1 *) (cdata + cpos);
	} else {
		mesh->vertexdata_2 = (const Vertex_2 *) (cdata + cpos);
	}
	mesh->vertices = (Vertex *) malloc (mesh->nvertices * sizeof (Vertex));
	for (u32 i = 0; i < mesh->nvertices; i++) {
		cpos += parseVertex (&mesh->vertices[i], cdata + cpos, frametype);
	}

	if (meshtype != 0) {
		// Unknown (mesh type != 0)
		// Extra 2 floats per vertex
		// Mizu, f32[2 * nvertices]
		mesh->type1data = (const float *) (cdata + cpos);
		if (debug_mesh > 1) {
			fprintf (stderr, "XXData::parseMesh: UnknownB[2 * %d]\n", mesh->nvertices);
			printHexBytes16 (cdata, cpos, 100);
		}
		cpos += mesh->nvertices * 8;
	}

	if (meshtype == 2) {
		// Unknown (mesh type == 2)
		// File SchoolMate_Map_Pack.pp, object m55_01_.xx, mesh g_P_OnsenYuiIwaba
		// Mesh type 2 seem to have another 2 floats per vertex
		// f32[2 * nvertices]
		mesh->type2data = (const float *) (cdata + cpos);
		if (debug_mesh > 1) {
			fprintf (stderr, "XXData::parseMesh: UnknownC[2 * %d]\n", mesh->nvertices);
			printHexBytes16 (cdata, cpos, 100);
		}
		cpos += mesh->nvertices * 8;
	}

	if (frametype >= 2) {
		// Unknown (frame type >= 2)
		// 100 bytes
		if (debug_mesh > 1) {
			fprintf (stderr, "XXData::parseMesh: UnknownD[100]\n");
			printHexBytes16 (cdata, cpos, 100);
		}
		cpos += 100;
	}

	if (frametype >= 3) {
		// Unknwon - MIKDemo, RealGirlfriend
		// 64 bytes
		if (debug_mesh > 1) fprintf (stderr, "XXData::parseMesh: mesh type %d\n", frametype);
		if (debug_mesh > 1) {
			fprintf (stderr, "XXData::parseMesh: UnknownE[64]\n");
			printHexBytes16 (cdata, cpos, 64);
		}
		cpos += 64;
	}

	if (frametype >= 5) {
		// Unknown - Real Girlfriend
		// 20 bytes
		if (debug_mesh > 1) fprintf (stderr, "XXData::parseMesh: mesh type %d\n", frametype);
		if (debug_mesh > 1) {
			fprintf (stderr, "XXData::parseMesh: UnknownF[20]\n");
			printHexBytes16 (cdata, cpos, 20);
		}
		cpos += 20;
	}

	return 1;
}

XXData::Bone *
XXData::parseBone (const unsigned char *cdata, size_t csize, size_t& cpos)
{
	// Bone name
	const unsigned char *xxname = cdata + cpos;
	if (parseName (cdata, csize, cpos) < 0) {
		fprintf (stderr, "XXData::parseBone: invalid name\n");
		return NULL;
	}
	if (debug > 1) fprintf (stderr, "XXData::parseBone: Bone %s\n", getNameStatic (xxname));

	Bone *bone = new Bone();
	bone->xxname = xxname;

	// BoneInfo [2] index
	bone->index = Xpp::getI32LE (cdata + cpos);
	cpos += 4;
	// BoneInfo [3] float[4][4] matrix
	// memcpy (bone->matrix, cdata + cpos, sizeof (Elea::Matrix4x4f));
	bone->matrix = (const f32 *) (cdata + cpos);
	cpos += sizeof (Elea::Matrix4x4f);
	if (debug > 1) fprintf (stderr, "XXData::parseBone: Translation %.2f %.2f %.2f\n", bone->matrix[12], bone->matrix[13], bone->matrix[14]);

	return bone;
}

XXData::Material *
XXData::parseMaterial (const unsigned char *cdata, size_t csize, size_t& cpos)
{
	// Material name
	const unsigned char *xxname = cdata + cpos;
	if (parseName (cdata, csize, cpos) < 0) {
		fprintf (stderr, "XXData::parseMaterial: invalid name\n");
		return NULL;
	}
	if (debug > 0) fprintf (stderr, "XXData::parseMaterial: Material %s\n", getNameStatic (xxname));

	Material *material = new Material();
	material->xxname = xxname;
	material->flags = 65535;

	// fixme: These values are negative (Lauris)
	material->color = (const float (*)[4]) (cdata + cpos);
	cpos += 64;
	material->shininess = Xpp::getF32LE (cdata + cpos);
	cpos += 4;
	if (debug_material > 0) {
		for (int i = 0; i < 4; i++) {
			fprintf (stderr, "Color %d: %.2f %.2f %.2f %.2f\n", i, material->color[i][0], material->color[i][1], material->color[i][2], material->color[i][3]);
		}
		fprintf (stderr, "Shininess %.2f\n", material->shininess);
	}

	for (int i = 0; i < 4; i++) {
		material->texname[i] = cdata + cpos;
		if (getNameStatic (cdata + cpos) && !strcmp (getNameStatic (cdata + cpos), "mj03_023.bmp")) {
			static int q = 0;
			q += 1;
		}
		if (parseName (cdata, csize, cpos) < 0) {
			fprintf (stderr, "XXData::parseMaterial: invalid texture name %d\n", i);
			return NULL;
		}
		// Unknown
		i32 val[4];
		memcpy (val, cdata + cpos, sizeof (val));
		// printHexBytes16 (cdata, cpos, 16);
		cpos += 16;
		if (debug_material > 0) {
			fprintf (stderr, "XXData::parseMaterial: Texture %d (%x %x %x %x): %s\n", i, val[0], val[1], val[2], val[3], getNameStatic (material->texname[i]));
		}
	}

	// Unknown
	// printHexBytes16 (cdata, cpos, 88);
	cpos += 88;

	return material;
}

XXData::Texture *
XXData::parseTexture (const unsigned char *cdata, size_t csize, size_t& cpos)
{
	// Texture name
	const unsigned char *xxname = cdata + cpos;
	if (parseName (cdata, csize, cpos) < 0) {
		fprintf (stderr, "XXData::parseTexture: invalid name\n");
		return NULL;
	}
	if (debug > 0) fprintf (stderr, "XXData::parseTexture: Texture %s\n", getNameStatic (xxname));

	Texture *texture = new Texture();
	texture->xxname = xxname;

	// Unknown
	// int u0 = Xpp::getI32LE (cdata + cpos);
	cpos += 4;
	// Width
	texture->width = Xpp::getI32LE (cdata + cpos);
	cpos += 4;
	// Height
	texture->height = Xpp::getI32LE (cdata + cpos);
	cpos += 4;
	// Unknown
	// BMP: 1 1 20|41 3 0
	// TGA: 1 1 21 3 2
	int u1[5];
	memcpy (u1, cdata + cpos, 20);
	texture->format = (const int *) (cdata + cpos);
	cpos += 20;
	// Checksum
	// u8 checksum = *(cdata + cpos);
	cpos += 1;
	// Image data size
	texture->dsize = Xpp::getI32LE (cdata + cpos);
	cpos += 4;
	// Image data
	texture->ddata = cdata + cpos;
	cpos += texture->dsize;

	if (debug_texture > 0) {
		fprintf (stderr, "Format: %x %x %x %x %x\n", texture->format[0], texture->format[1], texture->format[2], texture->format[3], texture->format[4]);
	}

	if (false) {
		FILE *ofs = fopen (getNameStatic (texture->xxname), "wb+");
		if (texture->format[4] == 0) {
			fputs ("BM", ofs);
			fwrite (texture->ddata + 2, 1, texture->dsize - 2, ofs);
		} else {
			fwrite (texture->ddata, 1, texture->dsize, ofs);
		}
		fclose (ofs);
	}

	return texture;
}

const char *
XXData::getNameStatic (const unsigned char *cdata)
{
	static unsigned char d[4096];
	unsigned char s[4096];
	int namelen = Xpp::getI32LE (cdata);
	if ((namelen < 0) || (namelen > (4096 - 1))) return NULL;
	// Name in Shift-Jis
	for (int i = 0; i < namelen; i++) s[i] = ~cdata[4 + i];
	int utf8len = sjis_to_utf8 (NULL, 4096, s, namelen);
	if ((utf8len < 0) || (utf8len > (4096 - 1))) return NULL;
	utf8len = sjis_to_utf8 (d, 4096, s, namelen);
	d[utf8len] = 0;
	return (const char *) d;
}

u32
XXData::parseVertex (Vertex *vertex, const unsigned char *cdata, int frametype)
{
	u32 cpos = 0;
	if (frametype >= 4) {
		// vertex->index = Xpp::getU16LE (cdata + cpos);
		cpos += 2;
	} else {
		// vertex->index = Xpp::getU32LE (cdata + cpos);
		cpos += 4;
	}
	for (int i = 0; i < 3; i++) {
		vertex->coords[i] = Xpp::getF32LE (cdata + cpos);
		cpos += 4;
	}
	for (int i = 0; i < 3; i++) {
		vertex->weights[i] = Xpp::getF32LE (cdata + cpos);
		cpos += 4;
	}
	for (int i = 0; i < 4; i++) {
		vertex->bones[i] = *(cdata + cpos);
		cpos += 1;
	}
	for (int i = 0; i < 3; i++) {
		vertex->normals[i] = Xpp::getF32LE (cdata + cpos);
		cpos += 4;
	}
	for (int i = 0; i < 2; i++) {
		vertex->texcoords[i] = Xpp::getF32LE (cdata + cpos);
		cpos += 4;
	}
	if (frametype >= 4) {
		cpos += 20;
	}
	return cpos;
}

char *
XXData::getName (const unsigned char *cdata)
{
	const char *utf8 = getNameStatic (cdata);
	if (!utf8) return NULL;
	return strdup (utf8);
}

bool
XXData::nameIsEqual (const unsigned char *a, const unsigned char *b)
{
	int alen = Xpp::getI32LE (a);
	int blen = Xpp::getI32LE (b);
	if (alen != blen) return false;
	for (int i = 0; i < alen; i++) if (a[4 + i] != b[4 + i]) return false;
	return true;
}

// XAData

XAData::XAData (const unsigned char *xdata, size_t xsize, const char *purl, URI::URLHandler *phandler)
: DataBlock (purl, "XAData"), handler(phandler), cdata(xdata), csize(xsize)
{
	handler->ref ();

	Format fmt = getFormat (cdata, csize);
	if (fmt == UNKNOWN) return;

#if 0
	if (duplicate) {
		privdata = true;
		cdata = (unsigned char *) malloc (csize);
		memcpy ((void *) cdata, xdata, csize);
	}
#endif

	size_t cpos = 0;
	u8 type = *(cdata + cpos);

	if (fmt == SB3) {
		// xaHeader [0] type
		// i32 headertype = Miletos::Xpp::getI32LE (cdata + cpos);
		cpos += 4;
		// xaHeader [1] unknown
		// u8 unknown = *(cdata + cpos);
		cpos += 1;
	}

	// Materials
	u8 exists1 = *(cdata + cpos);
	cpos += 1;
	if (exists1 == 0x1) {
		i32 nmat = Miletos::Xpp::getI32LE (cdata + cpos);
		cpos += 4;
		for (i32 i = 0; i < nmat; i++) {
			const char *name = XXData::getNameStatic (cdata + cpos);
			if (debug) fprintf (stderr, "XAData::XAData: Material %d: %s\n", i, name);
			XXData::parseName (cdata, csize, cpos);

			i32 nconfigs = Miletos::Xpp::getI32LE (cdata + cpos);
			cpos += 4;
			for (i32 j = 0; j < nconfigs; j++) {
				// section1MaterialConfig [0] diffuse rgba
				cpos += 16;
				// section1MaterialConfig [1] ambient rgba
				cpos += 16;
				// section1MaterialConfig [2] specular rgba
				cpos += 16;
				// section1MaterialConfig [3] emissive rgba
				cpos += 16;
				// section1MaterialConfig [4] specular power
				cpos += 4;
				// section1MaterialConfig [5] unknown
				cpos += 4;
			}
		}
	}

	// Section 2
	u8 exists2 = *(cdata + cpos);
	cpos += 1;
	if (exists2 == 0x1) {
		i32 nchildren = Miletos::Xpp::getI32LE (cdata + cpos);
		cpos += 4;
		for (i32 i = 0; i < nchildren; i++) {
			// section2Item [0] unknown
			cpos += 4;
			// section2Item [1] name length
			// section2Item [2] name
			char *name = XXData::getName (cdata + cpos);
			XXData::parseName (cdata, csize, cpos);
			if (debug) fprintf (stderr, "Child %d: %s\n", i, name);

			// section2Item [3] unknown
			cpos += 4;
			// section2Item [4] unknown
			cpos += 4;
			// section2Item [5] count
			i32 nchildren2a = Xpp::getI32LE (cdata + cpos);
			cpos += 4;
			// section2Item [6] unknown
			cpos += 4;

			for (int j = 0; j < nchildren2a; j++) {
				// section2ItemBlock [0] unknown
				cpos += 1;
				// section2ItemBlock [1] unknown
				cpos += 4;
			}
			// section2ItemLastByte [0] unknown
			cpos += 1;
		}
	}

	// Morph targets
	u8 hassection3 = *(cdata + cpos);
	cpos += 1;
	if (hassection3 == 0x1) {
		// Index data
		i32 nindexdata = Miletos::Xpp::getI32LE (cdata + cpos);
		cpos += 4;
		for (i32 i = 0; i < nindexdata; i++) {
			IndexBlock ib;
			// u8 - The index of submesh in frame
			ib.framemeshidx = *(cdata + cpos);
			if (debug) fprintf (stderr, "Submesh index in frame: %d\n", *(cdata + cpos));
			cpos += 1;
			// Number of indices
			ib.numindices = Miletos::Xpp::getU32LE (cdata + cpos);
			cpos += 4;
			// Coordinate indices
			ib.vindices = (const u16 *) (cdata + cpos);
			cpos += ib.numindices * 2;
			// Normal indices
			ib.nindices = (const u16 *) (cdata + cpos);
			cpos += ib.numindices * 2;
			// Name
			ib.name = XXData::getNameStatic (cdata + cpos);
			if (debug) fprintf (stderr, "Index block %d: %s (%d)\n", i, ib.name.c_str (), ib.numindices);
			XXData::parseName (cdata, csize, cpos);
			indexblocks.push_back (ib);
		}
		// Vertex data
		i32 nvertexdata = Miletos::Xpp::getI32LE (cdata + cpos);
		cpos += 4;
		for (i32 i = 0; i < nvertexdata; i++) {
			VertexBlock vb;
			vb.numvertices = Miletos::Xpp::getU32LE (cdata + cpos);
			cpos += 4;
			// Vertices
			vb.vertices = (const f32 *) (cdata + cpos);
			cpos += vb.numvertices * 12;
			// Normals
			vb.normals = (const f32 *) (cdata + cpos);
			cpos += vb.numvertices * 12;
			// Name
			vb.name = XXData::getNameStatic (cdata + cpos);
			if (debug) fprintf (stderr, "Vertex block %d: %s (%d)\n", i, vb.name.c_str (), vb.numvertices);
			XXData::parseName (cdata, csize, cpos);
			vertexblocks.push_back (vb);
		}
		// Morphs
		i32 nmorphs = Miletos::Xpp::getI32LE (cdata + cpos);
		cpos += 4;
		for (i32 i = 0; i < nmorphs; i++) {
			Morph m;
			// The name of frame
			m.name = XXData::getNameStatic (cdata + cpos);
			if (debug) fprintf (stderr, "Morph %d: %s\n", i, m.name.c_str ());
			XXData::parseName (cdata, csize, cpos);

			// Name of index block
			const char *ibname = XXData::getNameStatic (cdata + cpos);
			if (debug) fprintf (stderr, "Morph indices: %s\n", ibname);
			XXData::parseName (cdata, csize, cpos);
			m.ibidx = -1;
			for (size_t k = 0; k < indexblocks.size (); k++) {
				if (!indexblocks[k].name.compare (ibname)) {
					m.ibidx = (int) k;
					if (debug) fprintf (stderr, "Found: %s (%d)\n", indexblocks[k].name.c_str (), indexblocks[k].numindices);
					break;
				}
			}

			i32 ntargets = Miletos::Xpp::getI32LE (cdata + cpos);
			cpos += 4;
			for (int j = 0; j < ntargets; j++) {
				// Section3PartCItemAnimation [0] unknown
				// Structure: 00 X 00 00 00 00
				// X seems to be frame number as it increases sequentially
				if (debug) printHexBytes16 (cdata, cpos, 6);
				cpos += 6;
				// Name of vertex block
				const char *vbname = XXData::getNameStatic (cdata + cpos);
				if (debug) fprintf (stderr, "Vertex block %d: %s\n", j, vbname);
				XXData::parseName (cdata, csize, cpos);
				int vbidx = -1;
				for (size_t k = 0; k < vertexblocks.size (); k++) {
					if (!vertexblocks[k].name.compare (vbname)) {
						vbidx = (int) k;
						break;
					}
				}
				if (vbidx >= 0) {
					m.vbidx.push_back (vbidx);
					if (debug) fprintf (stderr, "Found: %s (%d)\n", vertexblocks[vbidx].name.c_str (), vertexblocks[vbidx].numvertices);
				}
			}
			// Section3PartCItemUnknown [0] unknown count
			// Variants:
			// 03 00 00 00
			// 05 00 00 00
			if (debug) printHexBytes16 (cdata, cpos, 4);
			cpos += 4;

			morphs.push_back (m);
		}
	}

	if (fmt == SB3) {
		if (type == 0x02) {
			// u8 exists = *(cdata + cpos);
			// fixme: Has to be 0 for known formats
			cpos += 1;
		} else if (type == 0x03) {
			// Section 4
			u8 exists4 = *(cdata + cpos);
			cpos += 1;
			if (exists4 == 0x1) {
				i32 count1 = Miletos::Xpp::getI32LE (cdata + cpos);
				cpos += 4;
				for (int i = 0; i < count1; i++) {
					i32 count2 = Miletos::Xpp::getI32LE (cdata + cpos);
					cpos += 4;
					for (int j = 0; j < count2; j++) {
						// section4ItemBlock [0] unknown1
						cpos += 104;
						// section4ItemBlock [1] unknown2
						cpos += 4;
						// section4ItemBlock [2] unknown3
						cpos += 64;
					}
				}
			}
		}
	}

	u8 exists5 = *(cdata + cpos);
	cpos += 1;
	if (exists5 == 0x1) {
		int loopcount;
		if ((fmt == SB3) && (type == 0x03)) {
			loopcount = 1024;
		} else {
			loopcount = 512;
		}
		for (int i = 0; i < loopcount; i++) {
			Sequence seq;

			// shift-jis name (64 bytes)
			unsigned char s[64];
			for (int j = 0; j < 64; j++) s[j] = ~cdata[cpos + j];
			s[63] = 0;
			size_t namelen = strlen ((char *) s);
			static unsigned char d[4096];
			int utf8len = sjis_to_utf8 (NULL, 4096, s, namelen);
			if ((utf8len < 0) || (utf8len > (4096 - 1))) {
				d[0] = 0;
			} else {
				utf8len = sjis_to_utf8 (d, 4096, s, namelen);
				d[utf8len] = 0;
			}
			seq.id = (char *) d;
			cpos += 64;

			if ((debug > 1) && (i < 32)) {
				fprintf (stderr, "Sequence %d: %s\n", i, d);
				printHexBytes16 (cdata, cpos + 64, 108 - 64);
				fprintf (stderr, "%.3f ", *((float *) (cdata + cpos + 64)));
				fprintf (stderr, "%.3f ", *((float *) (cdata + cpos + 64 + 8)));
				fprintf (stderr, "%.3f ", *((float *) (cdata + cpos + 64 + 12)));
				fprintf (stderr, "%d ", *((i32 *) (cdata + cpos + 64 + 16 + 3)));
				fprintf (stderr, "\n");
			}

			// sequence [0] speed (f32)
			seq.speed = *((f32 *) (cdata + cpos));
			cpos += 4;

			// sequence [4] unknown (4 bytes)
			cpos += 4;

			// sequence [8] startTime (f32)
			seq.startframe = *((f32 *) (cdata + cpos));
			cpos += 4;

			// sequence [12] endTime (f32)
			seq.endframe = *((f32 *) (cdata + cpos));
			cpos += 4;

			// sequence [16] unknown
			cpos += 1;
			// sequence [17] unknown
			cpos += 1;
			// sequence [18] unknown
			cpos += 1;

			// sequence [19] nextIdx (i32)
			seq.nextidx = Xpp::getI32LE (cdata + cpos);
			cpos += 4;

			// sequence [23] unknown
			cpos += 1;
			// sequence [24] unknown
			cpos += 4;
			// sequence [28] unknown
			cpos += 16;

			if (seq.endframe > seq.startframe) sequences.push_back (seq);
		}
		i32 nanims = Xpp::getI32LE (cdata + cpos);
		cpos += 4;
		for (int i = 0; i < nanims; i++) {
			Animation anim;

			// animation [0] name length
			// animation [4] name
			const char *name = XXData::getNameStatic (cdata + cpos);
			XXData::parseName (cdata, csize, cpos);
			anim.boneid = name;

			// animation [2] number of animation frames
			int nanimframes = Xpp::getI32LE (cdata + cpos);
			anim.numframes = nanimframes;
			cpos += 4;

			if (debug > 0) fprintf (stderr, "Animation %d: %s (%d frames)\n", i, name, nanimframes);

			if (debug > 1) printHexBytes16 (cdata, cpos, 4 + 52);
			// animation [3] unknown (usually 0)
			cpos += 4;

			// Frame positions
			anim.frames = (f32 *) (cdata + cpos);
			for (int j = 0; j < nanimframes; j++) {
				if ((debug > 1) && (j < 8)) {
					for (int k = 0; k < 12; k++) {
						fprintf (stderr, "%.2f ", *((float *) (cdata + cpos + 4 * k)));
					}
					fprintf (stderr, "\n");
				}

				// animation [4] keyframe data
				// 0 QUATERNION(YZXW) 0 0 POSITION(YZX) 1 1
				cpos += 52;
			}
			animations.push_back (anim);
		}
	}
	if (cpos != csize) {
		if (debug) fprintf (stderr, "csize %d cpos %d", (int) csize, (int) cpos);
	}
}

XAData::~XAData (void)
{
	handler->munmapData (cdata);
	handler->unRef ();
}

XAData::Format
XAData::getFormat (const unsigned char *cdata, size_t csize)
{
	if (csize < 6) return UNKNOWN;

	switch (cdata[0]) {
	case 0x00:
		return OTHER;
	case 0x01:
		if (cdata[1] == 0x00) return SB3;
		if (cdata[1] == 0x01) {
			if (XXData::getName (cdata + 5)) return OTHER;
			return SB3;
		}
		return OTHER;
	case 0x02:
	case 0x03:
		return SB3;
	default:
		break;
	}
	return UNKNOWN;
}

XAData *
XAData::getXAData (const char *purl)
{
	XAData *xa = NULL;
	if (purl) {
		xa = (XAData *) lookupDataBlock (purl, "XAData");
		if (xa) return xa;
		URI::URLHandler *handler = URI::getHandler (purl);
		if (handler) {
			size_t csize;
			const unsigned char *cdata = handler->mmapData ((const unsigned char *) purl, &csize);
			if (cdata) {
				xa = new XAData (cdata, csize, purl, handler);
			}
			handler->unRef ();
		}
	}
	return xa;
}

void
XAData::buildMorphs (Thera::Node *parentnode, const char *xxuri, const char *geometry)
{
	for (size_t i = 0; i < morphs.size (); i++) {
		Thera::Node *morphnode = new Thera::Node(parentnode->document, "morph");
		morphnode->setAttribute ("sid", morphs[i].name.c_str ());
		for (size_t j = 0; j < morphs[i].vbidx.size (); j++) {
			Thera::Node *targetnode = new Thera::Node(parentnode->document, "morphTargetXA");
			targetnode->setAttribute ("sid", vertexblocks[morphs[i].vbidx[j]].name.c_str ());
			targetnode->setAttribute ("geometry", geometry);
			targetnode->setAttributeInt ("morph", i);
			targetnode->setAttributeInt ("target", j);
			targetnode->setAttribute ("source", uri);
			targetnode->setAttribute ("geometrysource", xxuri);
			morphnode->appendChild (targetnode);
		}
		parentnode->appendChild (morphnode);
	}
}

// LightmapMaterialXX

class LightmapMaterialXX : public Sehle::Material {
public:
	enum BlendType { ADD, SUBTRACT };
	enum Programs { AMBIENT, NUM_PROGRAMS };
	enum AmbientUniforms { AMBIENT_LIGHTMAP_SAMPLER, AMBIENT_AMBIENT_LIGHT, AMBIENT_BLEND_FACTOR, NUM_AMBIENT_UNIFORMS };
	enum AmbientAttributes { AMBIENT_LIGHTMAP_COORDS, NUM_AMBIENT_ATTRIBUTES };
private:
	Sehle::Program *programs[NUM_PROGRAMS];
	Sehle::Texture *lmap;
	int lchannel;
	// Rendering state
	int loc_texcoord;

	u32 blendtype;

	// Material implementation
	virtual void bindClass (Sehle::RenderContext *ctx, Sehle::u32 renderflags);
	virtual void bindInstance (Sehle::RenderContext *ctx, Sehle::u32 renderflags, bool isfirstofclass);
	virtual void reset (Sehle::RenderContext *ctx);
	virtual void render (Sehle::RenderContext *ctx, Sehle::VertexBuffer *vb, Sehle::VertexBuffer *tb, const Sehle::u32 *indices, Sehle::u32 nindices, Sehle::u32 renderflags);
	virtual u32 defaultRenderStage (void);

	// Constructor
	LightmapMaterialXX (Sehle::Engine *engine, const char *id);
	// Destructor
	~LightmapMaterialXX (void);
public:
	// Static constructor
	static LightmapMaterialXX *newLightmapMaterialXX (Sehle::Engine *engine, const char *id);

	// Access
	void setLightMap (const char *id, const NR::PixBlock *ppxb);
	void setBlendType (u32 pblendtype);
};

// GeometryXX

static const float *
shuffle16 (const float *m)
{
	static float s[16];
	// X -> Y, Y -> Z, Z -> -X
	s[0] = m[10];
	s[1] = m[8];
	s[2] = m[9];
	s[3] = m[3];
	s[4] = m[2];
	s[5] = m[0];
	s[6] = m[1];
	s[7] = m[7];
	s[8] = m[6];
	s[9] = m[4];
	s[10] = m[5];
	s[11] = m[11];
	s[12] = m[14];
	s[13] = m[12];
	s[14] = m[13];
	s[15] = m[15];
	return s;
}

static const float *
shuffle3 (const float *v)
{
	static float s[3];
	// X -> Y, Y -> Z, Z -> X
	s[0] = v[2];
	s[1] = v[0];
	s[2] = v[1];
	return s;
}

struct GeometryXX::Texture {
	NR::PixBlock pxb;
	// fixme:
	std::string name;
};

GeometryXX::~GeometryXX (void)
{
	delete[] textures;
	if (bdata) bdata->unRef ();
}

static Object *
geometryxx_factory (void)
{
	return new GeometryXX();
}

const Object::Type *
GeometryXX::objectType (void)
{
	return type ();
}

const Object::Type *
GeometryXX::type (void)
{
	static Type *mytype = NULL;
	static const Attribute attrs[] = {
		{ "source", NULL, 0 }
	};
	if (!mytype) mytype = new Type(SkinnedGeometry::type (), "GeometryXX", "geometryXX", geometryxx_factory, sizeof (attrs) / sizeof (attrs[0]), attrs);
	return mytype;
}

void
GeometryXX::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	SkinnedGeometry::build (pnode, doc, ctx);

	buildAllAttributes (type (), ctx);

}

void
GeometryXX::release (void)
{
	SkinnedGeometry::release ();
}

void
GeometryXX::set (const char *attrid, const char *val)
{
	if (!strcmp (attrid, "source")) {
		clear ();
		if (bdata) bdata->unRef ();
		bdata = NULL;
		URI::URLHandler *handler = URI::getHandler (val);
		if (handler) {
			loadData (handler, val);
			handler->unRef ();
		}
		requestUpdate (MODIFIED | MESH_DEFINITION_MODIFIED);
	} else {
		SkinnedGeometry::set (attrid, val);
	}
}

void
GeometryXX::update (UpdateCtx *ctx, unsigned int flags)
{
	SkinnedGeometry::update (ctx, flags);
}

Sehle::Material *
GeometryXX::getMaterial (int matidx, Sehle::Engine *engine)
{
	if (materials[matidx].texture < 0) {
		Sehle::ColorMaterial *cmat = Sehle::ColorMaterial::newColorMaterial (engine, materials[matidx].id.c_str ());
		cmat->setColor (materials[matidx].color);
		return cmat;
	}
	NR::PixBlock *pxb = &textures[materials[matidx].texture].pxb;
	if (false) {
		float r = (float) (matidx & 1);
		float g = (float) ((matidx >> 1) & 1);
		float b = (float) ((matidx >> 2) & 1);
		Sehle::WireMaterial *wmat = Sehle::WireMaterial::newWireMaterial (engine, NULL);
		wmat->setColor (Elea::Color4f(r, g, b, 1));
		return wmat;
	} else if (pxb->isEmpty ()) {
		Sehle::ColorMaterial *cmat = Sehle::ColorMaterial::newColorMaterial (engine, materials[matidx].id.c_str ());
		cmat->setColor (materials[matidx].color);
		return cmat;
	} else {
		if (materials[matidx].type == Material::NORMAL) {
			Sehle::MaterialMultipassDNS *m = Sehle::MaterialMultipassDNS::newMaterialMultipassDNS (engine, materials[matidx].id.c_str ());
			m->setMap (Sehle::MaterialMultipassDNS::COLOR, NULL, &pxb->pb);
			// if (materials[matidx].color[Elea::A] < 0.95f) m->setOpacity (materials[matidx].color[Elea::A]);
			return m;
		} else if (materials[matidx].type == Material::SHADOW) {
			LightmapMaterialXX *m = LightmapMaterialXX::newLightmapMaterialXX (engine, materials[matidx].id.c_str ());
			m->setLightMap (NULL, pxb);
			m->setBlendType (LightmapMaterialXX::SUBTRACT);
			return m;
		} else {
			LightmapMaterialXX *m = LightmapMaterialXX::newLightmapMaterialXX (engine, materials[matidx].id.c_str ());
			m->setLightMap (NULL, pxb);
			m->setBlendType (LightmapMaterialXX::ADD);
			return m;
		}
	}
}

TextureInfo *
GeometryXX::getTextureInfo (unsigned int matidx, unsigned int texidx, unsigned int getimage)
{
	if (texidx >= ntextures) return NULL;
	TextureInfo *tex = new TextureInfo();
	tex->urn = strdup (textures[texidx].name.c_str ());
	if (getimage) {
		tex->image = nr_image_new ();
		NRPixBlock *px = &textures[texidx].pxb.pb;
		nr_pixblock_setup_extern (&tex->image->pixels, px->mode, px->area.x0, px->area.y0, px->area.x1, px->area.y1, NR_PIXBLOCK_PX(px), px->rs, false, false);
	}
	return tex;
}

u32
GeometryXX::getMaterialInfo (MaterialInfo *mat, u32 matidx)
{
	if (matidx >= (u32) nmaterials) return false;
	if (mat) {
		mat->id = materials[matidx].id.c_str ();
		mat->diffuseColor = materials[matidx].color;
		mat->specularColor = Elea::Color4fBlack;
		mat->specularShininess = 1;
		if (materials[matidx].type == Material::NORMAL) {
			mat->type = (materials[matidx].texture >= 0) ? MaterialInfo::TEXTURE : MaterialInfo::COLOR;
			mat->diffuseTexture = materials[matidx].texture;
			mat->normalTexture = -1;
			mat->specularTexture = -1;
			mat->lightmapTexture = -1;
			mat->lightmapCoefficent = 1;
		} else {
			mat->type = MaterialInfo::LIGHTMAP;
			mat->diffuseTexture = materials[matidx].texture;
			mat->normalTexture = -1;
			mat->specularTexture = -1;
			mat->lightmapTexture = -1;
			mat->lightmapCoefficent = (materials[matidx].type == Material::HILIGHT) ? 1.0f : -1.0f;
		}
	}
	return true;
}

void
GeometryXX::loadData (URI::URLHandler *handler, const char *url)
{
	float scale = DefaultScale;

	clear ();
	delete[] textures;
	ntextures = 0;
	textures = NULL;
	materials.clear ();

	// size_t csize;
	// const unsigned char *cdata = handler->mmapData (url, &csize);
	// if (!cdata) return;

	XXData *newxxdata = XXData::getXXData (url);
	if (bdata) bdata->unRef ();
	bdata = newxxdata;
	if (!bdata || bdata->meshes.empty () || bdata->frames.empty () || bdata->materials.empty ()) {
		if (bdata) bdata->unRef ();
		bdata = NULL;
		// handler->munmapData (cdata);
		return;
	}

	// Textures
	ntextures = (int) bdata->textures.size ();
	textures = new Texture[ntextures];
	for (unsigned int i = 0; i < ntextures; i++) {
		XXData::Texture *tex = bdata->textures[i];
		char c[32];
		sprintf (c, "texture_%d", i);
		textures[i].name = c;
		// BMP: 1 1 20 3 0
		// TGA: 1 1 21 3 2
		if (tex->format[4] == 0) {
			// BMP
			// .pp file have \0\0 at the place of bitmap signature
			Image::loadBMP (&textures[i].pxb.pb, tex->ddata, tex->dsize, "\0\0");
		} else {
			// TGA
			Image::load (&textures[i].pxb.pb, tex->ddata, tex->dsize);
		}
		if (textures[i].pxb.isEmpty ()) {
			fprintf (stderr, "Could not load texture %s\n", XXData::getNameStatic (tex->xxname));
		}
	}
	// Materials
	// fixme:
	nmaterials = (int) bdata->materials.size ();
	for (unsigned int i = 0; i < nmaterials; i++) {
		Material mat;
		mat.id = XXData::getNameStatic (bdata->materials[i]->xxname);
		mat.color.set (bdata->materials[i]->color[0]);
		// For some reason XX files have negative color values
		for (int j = 0; j < 4; j++) mat.color[j] = -mat.color[j];
		mat.texture = bdata->materials[i]->texidx[0];
		// fixme: Analyze all these variants (Lauris)
		if (bdata->materials[i]->flags == 0x4) {
			mat.type = Material::HILIGHT;
		} else if (bdata->materials[i]->flags == 0x6) {
			mat.type = Material::HILIGHT;
		} else if (bdata->materials[i]->flags == 0x8) {
			mat.type = Material::SHADOW;
		} else if (bdata->materials[i]->flags == 0x48) {
			mat.type = Material::SHADOW;
		} else if (bdata->materials[i]->flags == 0xa) {
			mat.type = Material::SHADOW;
		} else if (bdata->materials[i]->flags == 0xc) {
			// fixme: This is used for some hair meshes so we have to keep normal rendering (Lauris)
			mat.type = Material::NORMAL;
		} else {
			mat.type = Material::NORMAL;
		}
		// fixme:
		materials.push_back (mat);
	}

	// Bones
	setNumBones ((int) bdata->frames.size ());
	for (size_t i = 0; i < bdata->frames.size (); i++) {
		Elea::Matrix4x4f ft(shuffle16 (bdata->frames[i]->matrix));
		Elea::Matrix3x4f ft3(ft);
		ft3.setTranslation (scale * ft.getTranslation ());
		setBone ((int) i, XXData::getNameStatic (bdata->frames[i]->xxname), bdata->frames[i]->parent, ft3);
	}
	// Update bone matrixes
	initializeBoneMatrixes ();

#if 1
	// Determine buffer sizes
	int nvertices = 0;
	int nindices = 0;
	int nweights = 0;
	for (size_t i = 0; i < bdata->meshes.size (); i++) {
		XXData::Mesh *mesh = bdata->meshes[i];
		nvertices += mesh->nvertices;
		nindices += mesh->nindices;
		for (u32 j = 0; j < mesh->nvertices; j++) {
			float sumweights = 0;
			for (int k = 0; k < 4; k++) {
				float weight = (k < 3) ? mesh->vertices[j].weights[k] : 1 - sumweights;
				if (fabs (weight) > 0.001) {
					nweights += 1;
				}
				sumweights += weight;
			}
		}
	}

	// Initialize buffers
	setNumVertices (nvertices, true, true, true, true);
	setNumIndices (nindices);
	setNumWeights (nweights);
	setNumFrags ((int) bdata->meshes.size ());

	int vidx = 0;
	int iidx = 0;
	int widx = 0;
	for (size_t i = 0; i < bdata->meshes.size (); i++) {
		XXData::Mesh *mesh = bdata->meshes[i];
		XXData::Frame *frame = bdata->frames[mesh->frameidx];

		frags[i].visible = 1;
		frags[i].matidx = bdata->meshes[i]->matidx;
		frags[i].firstindex = iidx;
		// fixme:
		assert ((bdata->meshes[i]->nindices % 3) == 0);
		frags[i].numindices = bdata->meshes[i]->nindices;

		assert (bdata->meshes[i]->firstvertex == vidx);
		// bdata->meshes[i]->firstvertex = vidx;

		for (u32 j = 0; j < mesh->nvertices; j++) {
			vbase[vidx + j] = scale * frame->f2o.transformPoint3 (shuffle3 (mesh->vertices[j].coords));
			nbase[vidx + j] = frame->f2o.transformVector3 (shuffle3 (mesh->vertices[j].normals));
			// fixme:
			tbase[vidx + j] = Elea::Vector3fZ;
			xbase[vidx + j][0] = mesh->vertices[j].texcoords[0];
			xbase[vidx + j][1] = 1 - mesh->vertices[j].texcoords[1];

			int numweights = 0;
			float sumweights = 0;
			for (int k = 0; k < 4; k++) {
				int meshbone = mesh->vertices[j].bones[k];
				// fixme: Supplemental meshes (like head) do not define bones themselves
				int bone = (meshbone < (int) frame->bones.size ()) ? frame->bones[meshbone]->frameidx : mesh->frameidx;
				if ((bone < 0) || (bone >= (int) nbones)) {
					fprintf (stderr, "?!\n");
					bone = 0;
				}
				float weight = (k < 3) ? mesh->vertices[j].weights[k] : 1 - sumweights;
				if (fabs (weight) > 0.001) {
					weights[widx].bone = bone;
					weights[widx].weight = weight;
					widx += 1;
					numweights += 1;
				}
				sumweights += weight;
			}
			wcounts[vidx + j] = numweights;
		}

		for (u32 j = 0; j < bdata->meshes[i]->nindices; j += 3) {
			indices[iidx + j + 0] = vidx + mesh->indices[j + 0];
			indices[iidx + j + 1] = vidx + mesh->indices[j + 1];
			indices[iidx + j + 2] = vidx + mesh->indices[j + 2];
		}

		vidx += mesh->nvertices;
		iidx += mesh->nindices;
	}
#endif

	// fixme:
	// memcpy (vanim, vbase, nvertices * sizeof (Elea::Vector3f));
	// memcpy (nanim, nbase, nvertices * sizeof (Elea::Vector3f));

	// Invalidate source
	// delete bdata;
	// bdata = NULL;
	// handler->munmapData (cdata);

	// Calculate bone bounding boxes
	initializeBoneBBoxes ();

	// Update bone status
	updateBoneStatus ();

	// calculateNormals (true);

	requestUpdate (MODIFIED | MESH_DEFINITION_MODIFIED | ANIMATION_MODIFIED);
}

const char *
GeometryXX::getMaterialName (int midx)
{
	return materials[midx].id.c_str ();
}

const char *
GeometryXX::getTextureName (int midx)
{
	return textures[materials[midx].texture].name.c_str ();
}

bool
GeometryXX::isColorMaterial (int midx)
{
	return textures[materials[midx].texture].pxb.isEmpty ();
}

bool
GeometryXX::isTexturedMaterial (int midx)
{
	return !textures[materials[midx].texture].pxb.isEmpty ();
}

bool
GeometryXX::getTextureImage (NR::PixBlock& px, int midx)
{
	px.set (textures[materials[midx].texture].pxb);
	return true;
}

Elea::Color4f
GeometryXX::getMaterialDiffuse (int midx)
{
	return materials[midx].color;
}

// MorphtargetXA

MorphTargetXA::MorphTargetXA (void)
: MorphTarget(0), xadata(NULL), morphidx(-1), targetidx(-1), pvertices(NULL), pnormals(NULL), pindices(NULL)
{
}

MorphTargetXA::~MorphTargetXA (void)
{
}

static Object *
morphtargetxa_factory (void)
{
	return new MorphTargetXA();
}

const Object::Type *
MorphTargetXA::objectType (void)
{
	return type ();
}

const Object::Type *
MorphTargetXA::type (void)
{
	static Type *mytype = NULL;
	static const Attribute attrs[] = {
		{ "source", NULL, 0 },
		{ "morph", "-1", 0 },
		{ "target", "-1", 0 }
	};
	if (!mytype) mytype = new Type(MorphTarget::type (), "MorphTargetXA", "morphTargetXA", morphtargetxa_factory, sizeof (attrs) / sizeof (attrs[0]), attrs);
	return mytype;
}

void
MorphTargetXA::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	MorphTarget::build (pnode, doc, ctx);

	buildAllAttributes (type (), ctx);

}

void
MorphTargetXA::release (void)
{
	if (xadata) {
		xadata->unRef ();
		xadata = NULL;
	}

	if (pvertices) {
		free (pvertices);
		pvertices = NULL;
	}

	if (pnormals) {
		free (pnormals);
		pnormals = NULL;
	}

	if (pindices) {
		free (pindices);
		pindices = NULL;
	}

	MorphTarget::release ();
}

void
MorphTargetXA::set (const char *attrid, const char *val)
{
	if (!strcmp (attrid, "source")) {
		if (xadata) {
			xadata->unRef ();
			xadata = NULL;
		}

		if (val) {
			xadata = XAData::getXAData (val);
		}
		updateData ();
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "morph")) {
		morphidx = (val) ? atoi (val) : -1;
		updateData ();
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "target")) {
		targetidx = (val) ? atoi (val) : -1;
		updateData ();
		requestUpdate (MODIFIED);
	} else {
		MorphTarget::set (attrid, val);
	}
}

void
MorphTargetXA::updateData (void)
{
	vdata = NULL;
	ndata = NULL;
	if (pvertices) {
		free (pvertices);
		pvertices = NULL;
	}
	if (pnormals) {
		free (pnormals);
		pnormals = NULL;
	}
	if (pindices) {
		free (pindices);
		pindices = NULL;
	}
	indices = NULL;
	numindices = 0;
	maxindex = 0;

	if (!xadata || (morphidx < 0) || (targetidx < 0)) return;
	if (morphidx >= (int) xadata->morphs.size ()) return;
	if (targetidx >= (int) xadata->morphs[morphidx].vbidx.size ()) return;

	int vbidx = xadata->morphs[morphidx].vbidx[targetidx];
	int ibidx = xadata->morphs[morphidx].ibidx;

	// Test
	const char *gs = node->getAttribute ("geometrysource");
	if (!gs) return;
	XXData *xxdata = XXData::getXXData (gs);
	if (!xxdata) return;
	XXData::Frame *frame = NULL;
	XXData::Mesh *mesh = NULL;
	for (size_t i = 0; i < xxdata->meshes.size (); i++) {
		int frameidx = xxdata->meshes[i]->frameidx;
		frame = xxdata->frames[frameidx];
		if (!strcmp (XXData::getNameStatic (frame->xxname), xadata->morphs[morphidx].name.c_str ())) {
			mesh = frame->meshes[xadata->indexblocks[ibidx].framemeshidx];
			break;
		}
	}
	if (!mesh) return;

	float scale = DefaultScale;
	numindices = xadata->indexblocks[xadata->morphs[morphidx].ibidx].numindices;
	pvertices = (Elea::Vector3f *) malloc (numindices * sizeof (Elea::Vector3f));
	pnormals = (Elea::Vector3f *) malloc (numindices * sizeof (Elea::Vector3f));
	for (u32 i = 0; i < numindices; i++) {
		int vidx = xadata->indexblocks[xadata->morphs[morphidx].ibidx].vindices[i];;
		pvertices[i] = scale * frame->f2o.transformPoint3 (shuffle3 (xadata->vertexblocks[vbidx].vertices + vidx * 3));
		pnormals[i] = frame->f2o.transformVector3 (shuffle3 (xadata->vertexblocks[vbidx].normals + vidx * 3));
	}
	vdata = pvertices;
	ndata = pnormals;
	// vdata = xadata->vertexblocks[xadata->morphs[morphidx].vbidx[targetidx]].vertices;
	// ndata = xadata->vertexblocks[xadata->morphs[morphidx].vbidx[targetidx]].normals;

	// numindices = xadata->indexblocks[xadata->morphs[morphidx].ibidx].numindices;
	pindices = (u32 *) malloc (numindices * sizeof (u32));
	maxindex = 0;
	for (u32 i = 0; i < numindices; i++) {
		int vidx = mesh->firstvertex + xadata->indexblocks[ibidx].vindices[i];
		// int vidx = mesh->firstvertex + mesh->indices[xadata->indexblocks[xadata->morphs[morphidx].ibidx].vindices[i]];
		// fixme: Test whether vertex and normal indices are identical (Lauris)
		pindices[i] = vidx;
		if (pindices[i] > maxindex) maxindex = pindices[i];
	}
	indices = pindices;
}

// BoneAnimationXA

BoneAnimationXA::BoneAnimationXA (void)
: BoneAnimation(0), source(NULL), meshsource(NULL), animidx(-1), seqidx(-1), bdata(NULL), mdata(NULL), pframetimes(NULL), porientations(NULL)
{
	fps = 30;
}

BoneAnimationXA::~BoneAnimationXA (void)
{
	if (bdata) bdata->unRef ();
	if (mdata) mdata->unRef ();
	if (source) free (source);
	if (meshsource) free (meshsource);
}

static Object *
boneanimationxa_factory (void)
{
	return new BoneAnimationXA();
}

const Object::Type *
BoneAnimationXA::objectType (void)
{
	return type ();
}

const Object::Type *
BoneAnimationXA::type (void)
{
	static Type *mytype = NULL;
	static const Attribute attrs[] = {
		{ "animation", "-1", 0 },
		{ "sequence", "-1", 0 },
		{ "source", NULL, 0 },
		{ "meshSource", NULL, 0 }
	};
	if (!mytype) mytype = new Type(BoneAnimation::type (), "BoneAnimationXA", "boneAnimationXA", boneanimationxa_factory, sizeof (attrs) / sizeof (attrs[0]), attrs);
	return mytype;
}

void
BoneAnimationXA::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	BoneAnimation::build (pnode, doc, ctx);

	buildAllAttributes (type (), ctx);

}

void
BoneAnimationXA::release (void)
{
	if (porientations) {
		free (porientations);
		porientations = NULL;
	}

	if (pframetimes) {
		free (pframetimes);
		pframetimes = NULL;
	}

	BoneAnimation::release ();
}

void
BoneAnimationXA::set (const char *attrid, const char *val)
{
	if (!strcmp (attrid, "source")) {
		if (source) free (source);
		source = (val) ? strdup (val) : NULL;
		if (bdata) {
			bdata->unRef ();
			bdata = NULL;
		}
		if (source) {
			bdata = XAData::getXAData (source);
		}
		updateData ();
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "meshSource")) {
		if (meshsource) free (meshsource);
		meshsource = (val) ? strdup (val) : NULL;
		if (mdata) {
			mdata->unRef ();
			mdata = NULL;
		}
		if (meshsource) {
			mdata = XXData::getXXData (meshsource);
		}
		updateData ();
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "animation")) {
		animidx = (val) ? atoi (val) : -1;
		updateData ();
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "sequence")) {
		seqidx = (val) ? atoi (val) : -1;
		updateData ();
		requestUpdate (MODIFIED);
	} else {
		BoneAnimation::set (attrid, val);
	}
}

Elea::Vector3f
BoneAnimationXA::getPosition (unsigned int frameidx)
{
	return (frameidx < nframes) ? porientations[frameidx].p : Elea::Vector3f0;
}

Elea::Quaternionf
BoneAnimationXA::getQuaternion (unsigned int frameidx)
{
	return (frameidx < nframes) ? porientations[frameidx].q : Elea::Quaternionf0;
}

void
BoneAnimationXA::updateData (void)
{
	float scale = DefaultScale;

	frametimes = NULL;
	if (pframetimes) {
		free (pframetimes);
		pframetimes = NULL;
	}
	if (porientations) {
		free (porientations);
		porientations = NULL;
	}
	nframes = 0;
	maxframetime = 0;

	if (!bdata || !mdata) return;
	if (animidx < 0) return;
	if (animidx >= (int) bdata->animations.size ()) return;
	if (seqidx > (int) bdata->sequences.size ()) return;

	int frame0 = 0;
	int frame1 = (int) bdata->animations[animidx].numframes;
	fps = 30;
	if (seqidx >= 0) {
		frame0 = (int) (bdata->sequences[seqidx].startframe + 0.5f);
		frame1 = (int) (bdata->sequences[seqidx].endframe + 0.5f);
		if (frame0 >= frame1) return;
		fps = 30 * bdata->sequences[seqidx].speed;
	}
	nframes = frame1 - frame0;
	if (nframes < 1) return;
	// bonesid = strdup (bdata->animations[animidx].boneid.c_str ());

	pframetimes = (float *) malloc (nframes * sizeof (float));
	porientations = (Orientation *) malloc (nframes * sizeof (Orientation));
	for (u32 i = 0; i < nframes; i++) {
		pframetimes[i] = (f32) i;
		const float *f = &bdata->animations[animidx].frames[(frame0 + i) * 13];
		const float *fq = f + 1;
		const float *fp = f + 7;
		const float *qa = shuffle3(fq);
		porientations[i].q = Elea::Quaternionf(qa[0], qa[1], qa[2], fq[3]);
		porientations[i].p = scale * Elea::Vector3f(shuffle3(fp));
	}
	frametimes = pframetimes;
	maxframetime = frametimes[0];
	maxframetime = frametimes[nframes - 1];
}

// LightmapMaterialXX

LightmapMaterialXX::LightmapMaterialXX (Sehle::Engine *engine, const char *id)
: Sehle::Material (engine, id, engine->getClassId (Sehle::Engine::MATERIAL, "Miletos::LightmapMaterialXX")),
lmap(NULL), lchannel(-1), loc_texcoord(-1), blendtype(SUBTRACT)
{
	// Get programs
	programs[AMBIENT] = engine->getProgram("Miletos::LightmapMaterialXX::AmbientProgram");
	// Build ambient program
	if (!programs[AMBIENT]->built) {
		static const char *vnames[] = { "Miletos::LightmapMaterialXX::Vertex" };
		static const char *vfiles[] = { "xx-lightmap-vertex.txt" };
		static const char *fnames[] = { "Miletos::LightmapMaterialXX::Fragment" };
		static const char *ffiles[] = { "xx-lightmap-fragment.txt" };
		static const char *unames[] = { "lmapSampler", "ambientLight", "blendFactor" };
		static const char *anames[] = { "lmapCoords" };
		programs[AMBIENT]->build (0, NULL, NULL, 0, NULL, NULL, sizeof (unames) / sizeof (unames[0]), unames, sizeof (anames) / sizeof (anames[0]), anames);
		Sehle::Shader *shader = engine->getShader (vnames[0]);
		if (!shader->built) {
			size_t csize;
			const unsigned char *cdata = getMap_Miletos (vfiles[0], &csize);
			shader->build (Sehle::Shader::VERTEX, (const char *) cdata, csize);
		}
		programs[AMBIENT]->addVertexShaderGrabRef (shader);
		shader = engine->getShader (fnames[0]);
		if (!shader->built) {
			size_t csize;
			const unsigned char *cdata = getMap_Miletos (ffiles[0], &csize);
			shader->build (Sehle::Shader::FRAGMENT, (const char *) cdata, csize);
		}
		programs[AMBIENT]->addFragmentShaderGrabRef (shader);
	}
}

LightmapMaterialXX::~LightmapMaterialXX (void)
{
	if (lmap) lmap->unRef ();
	programs[AMBIENT]->unRef ();
}

void
LightmapMaterialXX::bindClass (Sehle::RenderContext *ctx, Sehle::u32 renderflags)
{
	if (renderflags & Sehle::RenderContext::AMBIENT) {
		glUseProgram (programs[AMBIENT]->getHandle ());
	}
}

void
LightmapMaterialXX::bindInstance (Sehle::RenderContext *ctx, Sehle::u32 renderflags, bool isfirstofclass)
{
	if (renderflags & Sehle::RenderContext::AMBIENT) {
		if (lmap) {
			if (isfirstofclass) {
				lchannel = ctx->allocateTexture (false);
			} else {
				LightmapMaterialXX *prev = (LightmapMaterialXX *) ctx->material;
				if (prev->lchannel >= 0) {
					// Channel is already reserved
					lchannel = prev->lchannel;
				} else {
					// Allocate new texture channel
					lchannel = ctx->allocateTexture (0);
				}
			}
			if (lchannel >= 0) lmap->bind (lchannel);
		} else {
			if (!isfirstofclass) {
				LightmapMaterialXX *prev = (LightmapMaterialXX *) ctx->material;
				if (prev->lchannel >= 0) {
					// Release channel
					ctx->releaseTexture (prev->lchannel);
				}
			}
		}
		programs[AMBIENT]->setUniform1i (AMBIENT_LIGHTMAP_SAMPLER, (lchannel >= 0) ? lchannel : 0);
		programs[AMBIENT]->setUniform3fv (AMBIENT_AMBIENT_LIGHT, 1, ctx->globalAmbient);
		programs[AMBIENT]->setUniform1f (AMBIENT_BLEND_FACTOR, (blendtype == ADD) ? 0.25f : -0.25f);
	}
}

void
LightmapMaterialXX::reset (Sehle::RenderContext *ctx)
{
	glUseProgram (0);
	if (lchannel >= 0) {
		glActiveTexture (GL_TEXTURE0 + lchannel);
		glDisable (GL_TEXTURE_2D);
		glActiveTexture (GL_TEXTURE0);
		ctx->releaseTexture (lchannel);
		lchannel = -1;
	}
}

void
LightmapMaterialXX::render (Sehle::RenderContext *ctx, Sehle::VertexBuffer *vb, Sehle::VertexBuffer *tb, const Sehle::u32 *indices, Sehle::u32 nindices, Sehle::u32 renderflags)
{
	if (!(renderflags & Sehle::RenderContext::AMBIENT)) return;
	if (lchannel < 0) return;

	if (!nindices) return;
	// const f32 *attribs = vb->getValuesR ();
	// if (!attribs) return;
	// const f32 *texattribs = tb->getValuesR ();
	// if (!texattribs) return;
	int loc_lightmapcoords = programs[AMBIENT]->getAttribLocation (AMBIENT_LIGHTMAP_COORDS);
	if (loc_lightmapcoords < 0) return;
	const f32 *attribs = (const f32 *) tb->bind ();
	glEnableVertexAttribArray (loc_lightmapcoords);
	glVertexAttribPointer (loc_lightmapcoords, 2, GL_FLOAT, true, tb->stride * sizeof (Sehle::f32), attribs + tb->offset[Sehle::VertexBuffer::TEXCOORDS]);
	if (vb != tb) {
		tb->release ();
		attribs = (const f32 *) vb->bind ();
	}
	glEnableClientState (GL_VERTEX_ARRAY);
	glVertexPointer (3, GL_FLOAT, vb->stride * sizeof (Sehle::f32), attribs + vb->offset[Sehle::VertexBuffer::COORDINATES]);
	glDrawElements (GL_TRIANGLES, nindices, GL_UNSIGNED_INT, indices);
	glDisableClientState (GL_VERTEX_ARRAY);
	glDisableVertexAttribArray (loc_lightmapcoords);
	vb->release ();
}

u32
LightmapMaterialXX::defaultRenderStage (void)
{
	return Sehle::Graph::LIGHTMAP;
}

LightmapMaterialXX *
LightmapMaterialXX::newLightmapMaterialXX (Sehle::Engine *engine, const char *id)
{
	if (id) {
		LightmapMaterialXX *res = (LightmapMaterialXX *) engine->lookupResource (Sehle::Engine::MATERIAL, id);
		if (res && (res->resclass == engine->getClassId (Sehle::Engine::MATERIAL, "Miletos::LightmapMaterialXX"))) {
			res->ref ();
			return res;
		}
	}
	LightmapMaterialXX *res = new LightmapMaterialXX(engine, id);
	return res;
}

void
LightmapMaterialXX::setLightMap (const char *id, const NR::PixBlock *ppxb)
{
	Sehle::Texture *tx = NULL;
	if (ppxb) {
		tx = engine->getTexture (id);
		if (tx) {
			NR::PixBlock pxb;
			tx->map (&pxb.pb, ppxb->getMode (), ppxb->getWidth (), ppxb->getHeight ());
			pxb.blit (*ppxb, 255);
			tx->unMap (Sehle::Texture::UINT8, 1);
		}
	}
	if (lmap) {
		lmap->unRef ();
	}
	lmap = tx;
}

void
LightmapMaterialXX::setBlendType (u32 pblendtype)
{
	blendtype = pblendtype;
}

static void
printHexBytes16 (const unsigned char *cdata, size_t cpos, size_t length)
{
	for (size_t pos = 0; pos < length; pos += 16) {
		int rowlen = (int) (length - pos);
		if (rowlen > 16) rowlen = 16;
		// Print address
		fprintf (stderr, "0x%09x  ", (int) (cpos + pos));
		// Print hexvals
		for (int i = 0; i < 16; i++) {
			unsigned char v = cdata[cpos + pos + i];
			if (i == 8) fprintf (stderr, " ");
			if (i < rowlen) {
				fprintf (stderr, "%02x ", v);
			} else {
				fprintf (stderr, "   ");
			}
		}
		// Print bytes
		fprintf (stderr, " ");
		for (int i = 0; i < 16; i++) {
			unsigned char v = cdata[cpos + pos + i];
			if (i >= rowlen) v = ' ';
			if ((v < 32) || ((v >= 128) && (v < 160))) v = '.';
			fprintf (stderr, "%c", v);
		}
		fprintf (stderr, "\n");
	}
}

} // Namespace Miletos
