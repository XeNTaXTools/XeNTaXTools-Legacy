#ifndef __MILETOS_GEOMETRY_H__
#define __MILETOS_GEOMETRY_H__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2010
//

#include <miletos/types.h>
#include <miletos/scene.h>

namespace Miletos {

struct TextureInfo;
struct MaterialInfo;
class Material;

// Base class for all renderable geometries

class Geometry : public Object {
public:
	// Geometry is modified so sehle object has to be rebuilt
	static const int MESH_DEFINITION_MODIFIED = 128;
	// Sehle materials have to be reattached
	static const int MATERIAL_DEFINITION_MODIFIED = 256;
private:
	unsigned int nhiddenfrags;
	unsigned int *hiddenfrags;

	// Object implementation
	virtual const Type *objectType (void);

protected:
	char *vertexid;
	char *indexid;

	// Object implementation
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	virtual void set (const char *attrid, const char *val);
	virtual void write (const char *attrid);
	virtual void update (UpdateCtx *ctx, unsigned int flags);
	virtual void identityAdded (Document *pdocument, const char *pidentity, Object *pobject);
	virtual void identityRemoved (Document *pdocument, const char *pidentity);
	virtual void attachedObjectRelease (Object *attached, void *data);
	virtual void attachedObjectModified (Object *attached, unsigned int flags, void *data);

	Geometry (unsigned int flags);
	virtual ~Geometry (void);

	void clear (void);
	void clearOverrides (void);
	void setNumFrags (unsigned int pnumfrags);
public:
	// Material overrides
	u32 noverrides;
	char **overrideids;
	Material **overrides;
	// Mesh to Skin transformations
	Elea::Matrix3x4f s2m;
	Elea::Matrix3x4f m2s;
	// Scaling factor
	float scale;

	// Bounding box in world coordinate system
	Elea::Cuboid3f bbox;

	// Number of distinct textures
	unsigned int ntextures;
	// Number of materials
	unsigned int nmaterials;

	// Fragment data
	struct Frag {
		u32 visible : 1;
		u32 matidx;
		u32 firstindex;
		u32 numindices;
	};
	unsigned int nfrags;
	Frag *frags;

	// Visibility
	virtual Sehle::Renderable *show (Sehle::Graph *graph, Sehle::u32 contextmask) = 0;
	virtual void hide (Sehle::RenderableGroup *pgroup) = 0;
	virtual bool trace (const Elea::Line3f *mray, unsigned int mask, float *distance) = 0;
	virtual bool trace (const Elea::Line3f *mray, unsigned int mask, const Elea::Matrix4x4f *me2us, float *distance, Elea::Vector3f *uscp) { return false; }

	// Type system
	static const Type *type (void);

	// Set fragment visibility
	void setFragVisibility (u32 fragidx, unsigned int visible);

	// Exporter support
	virtual TextureInfo *getTextureInfo (unsigned int matidx, unsigned int texidx, unsigned int getimage) = 0;
	virtual u32 getMaterialInfo (MaterialInfo *mat, u32 matidx) = 0;
	virtual unsigned int getVertices (const Elea::Vector3f **vertices, const Elea::Vector3f **normals, const Elea::Vector3f **tangents, const Elea::Vector2f **texcoords) = 0;
	virtual unsigned int getIndices (const u32 **indices) = 0;
};

// Static objects

class StaticGeometry : public Geometry {
private:
	// Private renderable
	Sehle::StaticMesh *renderable;

	// Object implementation
	virtual const Type *objectType (void);

	// Create Sehle material
	virtual Sehle::Material *getMaterial (int matidx, Sehle::Engine *engine) = 0;

	// Helpers
	void rebuildRenderable (Sehle::StaticMesh *mesh);
	void updateRenderable (Sehle::StaticMesh *mesh);
protected:
	StaticGeometry (unsigned int flags);
	virtual ~StaticGeometry (void);

	// Object implementation
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	virtual void update (UpdateCtx *ctx, unsigned int flags);
	// Geometry implementation
	virtual Sehle::Renderable *show (Sehle::Graph *graph, Sehle::u32 contextmask);
	void hide (Sehle::RenderableGroup *pgroup);
	virtual bool trace (const Elea::Line3f *mray, unsigned int mask, float *distance);
	virtual unsigned int getVertices (const Elea::Vector3f **vertices, const Elea::Vector3f **normals, const Elea::Vector3f **tangents, const Elea::Vector2f **texcoords);
	virtual unsigned int getIndices (const u32 **indices);

	// Helpers
	void clear ();
	// Vertex resizing
	void setNumVertices (int pnumvertices, bool texcoords, bool normals, bool tangents);
	void setNumIndices (unsigned int pnumindices);
public:
	// Number of renderable elements
	unsigned int nvertices;
	unsigned int nindices;
	// Vertex data
	Elea::Vector3f *vbase;
	Elea::Vector3f *nbase;
	Elea::Vector3f *tbase;
	Elea::Vector2f *xbase;
	// Index data
	u32 *indices;

	// Type system
	static const Type *type (void);
};

} // Namespace Miletos

#endif

