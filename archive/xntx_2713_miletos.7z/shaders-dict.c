#define __SHADERS_DICT_C__

#include <stdlib.h>
#include <string.h>

#include <zlib.h>

#include "shaders-code.c"

struct StringData {
    const char *cdata;
    size_t csize;
};

static struct StringData strings[] = {
    { lightmap_ambient_fragment_txt_0_data, sizeof (lightmap_ambient_fragment_txt_0_data) - 1 },
    { lightmap_hilight_fragment_txt_0_data, sizeof (lightmap_hilight_fragment_txt_0_data) - 1 },
    { lightmap_vertex_txt_0_data, sizeof (lightmap_vertex_txt_0_data) - 1 },
    { lightmap_gbuf_vertex_txt_0_data, sizeof (lightmap_gbuf_vertex_txt_0_data) - 1 },
    { lightmap_gbuf_fragment_txt_0_data, sizeof (lightmap_gbuf_fragment_txt_0_data) - 1 },
    { xx_lightmap_vertex_txt_0_data, sizeof (xx_lightmap_vertex_txt_0_data) - 1 },
    { xx_lightmap_fragment_txt_0_data, sizeof (xx_lightmap_fragment_txt_0_data) - 1 },
};

struct MapData {
    const char *mapname;
    int firststring;
    int numstrings;
    size_t zsize;
    size_t size;
    char *data;
};

static struct MapData maps[] = {
    { "lightmap-ambient-fragment.txt", 0, 1, 329, 704, 0 },
    { "lightmap-hilight-fragment.txt", 1, 1, 1057, 2935, 0 },
    { "lightmap-vertex.txt", 2, 1, 412, 816, 0 },
    { "lightmap-gbuf-vertex.txt", 3, 1, 223, 393, 0 },
    { "lightmap-gbuf-fragment.txt", 4, 1, 437, 1020, 0 },
    { "xx-lightmap-vertex.txt", 5, 1, 116, 141, 0 },
    { "xx-lightmap-fragment.txt", 6, 1, 202, 361, 0 },
};

const unsigned char *
getMap_Miletos (const char *name, size_t *csize)
{
    int i;
    for (i = 0; i < 7; i++) {
        if (!strcmp (maps[i].mapname, name)) {;
            if (!maps[i].data) {;
                if (maps[i].zsize != 0) {
                    unsigned char *zdata;
                    size_t pos;
                    int j, zresult;
                    unsigned long dlen = maps[i].size;
                    zdata = (unsigned char *) malloc (maps[i].zsize);
                    pos = 0;
                    for (j = 0; j < maps[i].numstrings; j++) {
                        memcpy (zdata + pos, strings[maps[i].firststring + j].cdata, strings[maps[i].firststring + j].csize);
                        pos += strings[maps[i].firststring + j].csize;
                    }
                    maps[i].data = (char *) malloc (maps[i].size);
                    zresult = uncompress ((unsigned char *) maps[i].data, &dlen, zdata, maps[i].zsize);
                    free (zdata);
                } else {
                    size_t pos;
                    int j;
                    maps[i].data = (char *) malloc (maps[i].size);
                    pos = 0;
                    for (j = 0; j < maps[i].numstrings; j++) {
                        memcpy (maps[i].data + pos, strings[maps[i].firststring + j].cdata, strings[maps[i].firststring + j].csize);
                        pos += strings[maps[i].firststring + j].csize;
                    }
                }
            }
            if (csize) *csize = maps[i].size;
            return (const unsigned char *) maps[i].data;
        }
    }
    return NULL;
}
