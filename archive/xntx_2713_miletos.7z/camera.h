#ifndef __MILETOS_CAMERA_H__
#define __MILETOS_CAMERA_H__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2010
//

#include <miletos/scene.h>

namespace Miletos {

class Camera : public Item {
public:
	enum ProjectionMode { PERSPECTIVE, ISOMETRIC };
private:
	// Object implementation
	virtual const Type *objectType (void);
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	// The following two update child pointers and emit signals
	virtual void set (const char *attrid, const char *val);
	virtual void write (const char *attrid);
	// Item implementation
	virtual Sehle::Renderable *show (Sehle::Graph *graph, Sehle::u32 contextmask);
	virtual Item *trace (const Elea::Line3f *wray, unsigned int mask, float *distance);
public:
	// View matrix
	Elea::Matrix4x4f v2w;
	// Distance to rotation centre
	float distance;
	// Focal distance
	float focus;
	// Mode
	unsigned int mode;

	Camera (void);

	// Type system
	static const Type *type (void);

	void setPosition (const Elea::Matrix4x4f *v2w, float distance, float focus, int mode);
};

} // Namespace Miletos

#endif

