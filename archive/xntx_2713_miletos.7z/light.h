#ifndef __MILETOS_LIGHT_H__
#define __MILETOS_LIGHT_H__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2009-2011
//

#include <elea/color.h>

#include <miletos/scene.h>

namespace Miletos {

class Light : public Item {
private:
	// Object implementation
	virtual const Type *objectType (void);
protected:
	// Sehle light block
	Sehle::Light *sehlelights;

	Light (void);
	virtual ~Light (void);

	// Object implementation
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	virtual void set (const char *attrid, const char *val);
	virtual void write (const char *attrid);
	virtual void update (UpdateCtx *ctx, unsigned int flags);
	// Update sehle light definition
	virtual void updateSehleLights (void);
public:
	unsigned int has_shadow : 1;
	unsigned int has_density : 1;
	// Colors
	Elea::Color4f ambient;
	Elea::Color4f diffuse;
	Elea::Color4f direct;
	// Inside out light volume
	Elea::Vector3f *vertices;
	u32 nindices;
	u32 *indices;

	// Type system
	static const Type *type (void);

	// Access
	void setAmbient (const Elea::Color4f& color);
	void setDiffuse (const Elea::Color4f& color);
	void setDirect (const Elea::Color4f& color);
};

class DirectionalLight : public Light {
public:
private:
	float radius;

	// Object implementation
	virtual const Type *objectType (void);
	virtual void update (UpdateCtx *ctx, unsigned int flags);
	// Item implementation
	virtual Sehle::Renderable *show (Sehle::Graph *graph, Sehle::u32 contextmask);
	virtual void hide (Sehle::RenderableGroup *pgroup);
	virtual Item *trace (const Elea::Line3f *wray, unsigned int mask, float *distance);
	// Light implementation
	virtual void updateSehleLights (void);
public:
	DirectionalLight (void);
	virtual ~DirectionalLight (void);

	// Type system
	static const Type *type (void);
};

class PointLight : public Light {
public:
private:
	float radius;

	// Object implementation
	virtual const Type *objectType (void);
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void set (const char *attrid, const char *val);
	virtual void write (const char *attrid);
	virtual void update (UpdateCtx *ctx, unsigned int flags);
	// Item implementation
	virtual Sehle::Renderable *show (Sehle::Graph *graph, Sehle::u32 contextmask);
	virtual void hide (Sehle::RenderableGroup *pgroup);
	virtual Item *trace (const Elea::Line3f *wray, unsigned int mask, float *distance);
	// Light implementation
	virtual void updateSehleLights (void);

	// Helper
	void updateVolume (void);
public:
	float cutoffDistance;
	float constantAttenuation;
	float linearAttenuation;
	float quadraticAttenuation;

	PointLight (void);
	virtual ~PointLight (void);

	// Type system
	static const Type *type (void);
};

class SpotLight : public Light {
public:
private:
	float radius;

	Elea::Matrix4x4f shadowprojection;

	// Object implementation
	virtual const Type *objectType (void);
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void set (const char *attrid, const char *val);
	virtual void write (const char *attrid);
	virtual void update (UpdateCtx *ctx, unsigned int flags);
	// Item implementation
	virtual Sehle::Renderable *show (Sehle::Graph *graph, Sehle::u32 contextmask);
	virtual void hide (Sehle::RenderableGroup *pgroup);
	virtual Item *trace (const Elea::Line3f *wray, unsigned int mask, float *distance);
	// Light implementation
	virtual void updateSehleLights (void);

	// Helper
	void updateVolume (void);
public:
	float cutoffDistance;
	float decayExponent;
	float cutoffAngle;
	float constantAttenuation;
	float linearAttenuation;
	float quadraticAttenuation;

	SpotLight (void);
	virtual ~SpotLight (void);

	// Type system
	static const Type *type (void);

	// Access
	Elea::Matrix4x4f getShadowProjection (void);
	void setShadowProjection (const Elea::Matrix4x4f& pprojection);
};

class AreaLight : public Light {
public:
private:
	Elea::Matrix4x4f shadowprojection;

	// Object implementation
	virtual const Type *objectType (void);
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void set (const char *attrid, const char *val);
	virtual void update (UpdateCtx *ctx, unsigned int flags);
	// Item implementation
	virtual Sehle::Renderable *show (Sehle::Graph *graph, Sehle::u32 contextmask);
	virtual void hide (Sehle::RenderableGroup *pgroup);
	virtual Item *trace (const Elea::Line3f *wray, unsigned int mask, float *distance);
	// Light implementation
	virtual void updateSehleLights (void);

	// Helper
	void updateVolume (void);
public:
	float cutoffDistance;
	float decayExponent;
	float cutoffAngle;
	float constantAttenuation;
	float linearAttenuation;
	float quadraticAttenuation;

	float size[2];
	int samples[2];

	AreaLight (void);
	virtual ~AreaLight (void);

	// Type system
	static const Type *type (void);
};

class DayLight : public Light {
public:
private:
	Elea::Matrix4x4f shadowprojection;
	float azimuth;
	float altitude;
	float airmass;

	// Object implementation
	virtual const Type *objectType (void);
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void set (const char *attrid, const char *val);
	virtual void update (UpdateCtx *ctx, unsigned int flags);
	// Item implementation
	virtual Sehle::Renderable *show (Sehle::Graph *graph, Sehle::u32 contextmask);
	virtual void hide (Sehle::RenderableGroup *pgroup);
	virtual Item *trace (const Elea::Line3f *wray, unsigned int mask, float *distance);
	// Light implementation
	virtual void updateSehleLights (void);

	// Helper
	void updateVolume (void);
public:
	// Latitude in degrees
	float latitude;
	// Time of astronomical year in full days
	float timeOfYear;
	// Time of astronomical day in seconds
	float timeOfDay;
	// The azimuth of x axis (eastward from north)
	float xAzimuth;
	int nsamples;

	DayLight (void);
	virtual ~DayLight (void);

	// Type system
	static const Type *type (void);
};

} // Namespace Miletos

#endif

