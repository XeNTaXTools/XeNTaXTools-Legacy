#define __MILETOS_MESH_CPP__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2008
//

#if 0
static const int debug = 1;

#include <sehle/renderable.h>

#include "xml/base.h"

#include "mesh.h"

namespace Miletos {

// SMesh

Sehle::Renderable *
SMesh::show (Sehle::Graph *graph, Sehle::u32 contextmask)
{
	Sehle::StaticMesh *mesh = new Sehle::StaticMesh(graph, contextmask);

	buildMesh (mesh);

	return mesh;
}

const Object::Type *
SMesh::objectType (void)
{
	return type ();
}

const Object::Type *
SMesh::type (void)
{
	static Type *mytype = NULL;
	if (!mytype) mytype = new Type("SMesh", Item::type (), 0, NULL);
	return mytype;
}

} // Namespace Miletos

#endif
