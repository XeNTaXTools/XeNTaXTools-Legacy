#ifndef __MILETOS_SIGNAL_H__
#define __MILETOS_SIGNAL_H__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2007
//

#include <vector>

#include <assert.h>

namespace Miletos {

namespace Signals {

// Base class of all slots

class Slot {
protected:
	typedef Slot *(*SBDuplicateFunction) (const Slot&);
private:
	// Duplicator
	SBDuplicateFunction _duplicate;
	// Blocked
	Slot& operator= (const Slot& base) { assert(0); }
	// Default copy constructor should work
protected:
	// Data member
	void *_data;
	// Constructor
	Slot (SBDuplicateFunction duplicate, void *data) : _duplicate(duplicate), _data(data) {}
public:
	// Duplication
	Slot *duplicate (void) const {
		return _duplicate (*this);
	}
	// Access
	void *getData (void) const { return _data; }
};

// Base slot class, capable of invoking static functions

template<typename RET>
class Slot0 : public Slot
{
protected:
	typedef RET (*SB0InvokeFunction) (Slot0 *, void *);
private:
	SB0InvokeFunction _invoke;
public:
	// Constructors
	Slot0 (SBDuplicateFunction duplicate, SB0InvokeFunction invoke, void *data) : Slot(duplicate, data), _invoke(invoke) {}
	// Invocation
	RET operator() (void) {
		return _invoke (this, _data);
	}
};

template<typename RET, typename ARG1>
class Slot1 : public Slot
{
protected:
	typedef RET (*SB1InvokeFunction) (Slot1 *, ARG1, void *);
private:
	SB1InvokeFunction _invoke;
public:
	// Constructors
	Slot1 (SBDuplicateFunction duplicate, SB1InvokeFunction invoke, void *data) : Slot(duplicate, data), _invoke(invoke) {}
	// Invocation
	RET operator() (ARG1 arg1) {
		return _invoke (this, arg1, _data);
	}
};

template<typename RET, typename ARG1, typename ARG2>
class Slot2 : public Slot
{
protected:
	typedef RET (*SB2InvokeFunction) (Slot2 *, ARG1, ARG2, void *);
private:
	SB2InvokeFunction _invoke;
public:
	// Constructors
	Slot2 (SBDuplicateFunction duplicate, SB2InvokeFunction invoke, void *data) : Slot(duplicate, data), _invoke(invoke) {}
	// Invocation
	RET operator() (ARG1 arg1, ARG2 arg2) {
		return _invoke (this, arg1, arg2, _data);
	}
};

template<typename RET, typename ARG1, typename ARG2, typename ARG3>
class Slot3 : public Slot
{
protected:
	typedef RET (*SB3InvokeFunction) (Slot3 *, ARG1, ARG2, ARG3, void *);
private:
	SB3InvokeFunction _invoke;
public:
	// Constructors
	Slot3 (SBDuplicateFunction duplicate, SB3InvokeFunction invoke, void *data) : Slot(duplicate, data), _invoke(invoke) {}
	// Invocation
	RET operator() (ARG1 arg1, ARG2 arg2, ARG3 arg3) {
		return _invoke (this, arg1, arg2, arg3, _data);
	}
};

template<typename RET, typename ARG1, typename ARG2, typename ARG3, typename ARG4>
class Slot4 : public Slot
{
protected:
	typedef RET (*SB4InvokeFunction) (Slot4 *, ARG1, ARG2, ARG3, ARG4, void *);
private:
	SB4InvokeFunction _invoke;
public:
	// Constructors
	Slot4 (SBDuplicateFunction duplicate, SB4InvokeFunction invoke, void *data) : Slot(duplicate, data), _invoke(invoke) {}
	// Invocation
	RET operator() (ARG1 arg1, ARG2 arg2, ARG3 arg3, ARG4 arg4) {
		return _invoke (this, arg1, arg2, arg3, arg4, _data);
	}
};

// Base class for signals

class Signal {
private:
	// Blocked
	Signal(const Signal& signal) { assert (0); }
	Signal& operator= (const Signal& signal) { assert (0); return *this; }
protected:
	std::vector<Slot *> _slots;
	// Constructor
	Signal (void) {}
	// Destructor
	~Signal (void) {
		for (size_t i = 0; i < _slots.size (); i++) {
			// fixme: I am alost sure that plain delete is enough for slots, but should check (Lauris)
			delete _slots[i];
		}
	}
	// Connection
	int connect (const Slot& slot) {
		for (size_t i = 0; i < _slots.size (); i++) {
			if (!_slots[i]) {
				_slots[i] = slot.duplicate ();
				return (int) i;
			}
		}
	 	size_t pos = _slots.size ();
	 	_slots.push_back (slot.duplicate ());
		return (int) pos;
	}
public:
	// Disconnection
	void disconnect (int idx) {
		delete _slots[idx];
		_slots[idx] = NULL;
	}
	void disconnect (void *data) {
		size_t i = 0;
		while (i < _slots.size ()) {
			if (_slots[i] && (_slots[i]->getData () == data)) {
				delete _slots[i];
				_slots[i] = NULL;
			} else {
				i += 1;
			}
		}
	}

};

template<typename RET>
class Signal0 : public Signal {
public:
	// Constructor
	Signal0 (void) : Signal() {}
	// Connection
	int connect (const Slot0<RET>& slot) {
		return Signal::connect (slot);
	}
	// Callback
	// fixme: Return type collection
	RET invoke (RET rval) {
		for (size_t i = 0; i < _slots.size (); i++) {
			if (_slots[i]) rval = (*((Slot0<RET> *) _slots[i])) ();
		}
		return rval;
	}
};

template<>
class Signal0<void> : public Signal {
public:
	// Constructor
	Signal0 (void) : Signal() {}
	// Connection
	int connect (const Slot0<void>& slot) {
		return Signal::connect (slot);
	}
	// Callback
	void invoke (void) {
		for (size_t i = 0; i < _slots.size (); i++) {
			if (_slots[i]) (*((Slot0<void> *) _slots[i])) ();
		}
	}
};

template<typename RET, typename ARG1>
class Signal1 : public Signal {
public:
	// Constructor
	Signal1 (void) : Signal() {}
	// Connection
	int connect (const Slot1<RET, ARG1>& slot) {
		return Signal::connect (slot);
	}
	// Callback
	// fixme: Return type collection
	RET invoke (ARG1 arg1, RET rval) {
		for (size_t i = 0; i < _slots.size (); i++) {
			if (_slots[i]) rval = (*((Slot1<RET, ARG1> *) _slots[i])) (arg1);
		}
		return rval;
	}
};

template<typename ARG1>
class Signal1<void, ARG1> : public Signal {
public:
	// Constructor
	Signal1 (void) : Signal() {}
	// Connection
	int connect (const Slot1<void, ARG1>& slot) {
		return Signal::connect (slot);
	}
	// Callback
	void invoke (ARG1 arg1) {
		for (size_t i = 0; i < _slots.size (); i++) {
			if (_slots[i]) (*((Slot1<void, ARG1> *) _slots[i])) (arg1);
		}
	}
};

template<typename RET, typename ARG1, typename ARG2>
class Signal2 : public Signal {
public:
	// Constructor
	Signal2 (void) : Signal() {}
	// Connection
	int connect (const Slot2<RET, ARG1, ARG2>& slot) {
		return Signal::connect (slot);
	}
	// Callback
	// fixme: Return type collection
	RET invoke (ARG1 arg1, ARG2 arg2, RET rval) {
		for (size_t i = 0; i < _slots.size (); i++) {
			if (_slots[i]) rval = (*((Slot2<RET, ARG1, ARG2> *) _slots[i])) (arg1, arg2);
		}
		return rval;
	}
};

template<typename ARG1, typename ARG2>
class Signal2<void, ARG1, ARG2> : public Signal {
public:
	// Constructor
	Signal2 (void) : Signal() {}
	// Connection
	int connect (const Slot2<void, ARG1, ARG2>& slot) {
		return Signal::connect (slot);
	}
	// Callback
	void invoke (ARG1 arg1, ARG2 arg2) {
		for (size_t i = 0; i < _slots.size (); i++) {
			if (_slots[i]) (*((Slot2<void, ARG1, ARG2> *) _slots[i])) (arg1, arg2);
		}
	}
};

template<typename RET, typename ARG1, typename ARG2, typename ARG3>
class Signal3 : public Signal {
public:
	// Constructor
	Signal3 (void) : Signal() {}
	// Connection
	int connect (const Slot3<RET, ARG1, ARG2, ARG3>& slot) {
		return Signal::connect (slot);
	}
	// Callback
	// fixme: Return type collection
	RET invoke (ARG1 arg1, ARG2 arg2, ARG3 arg3, RET rval) {
		for (size_t i = 0; i < _slots.size (); i++) {
			if (_slots[i]) rval = (*((Slot3<RET, ARG1, ARG2, ARG3> *) _slots[i])) (arg1, arg2, arg3);
		}
		return rval;
	}
};

template<typename ARG1, typename ARG2, typename ARG3>
class Signal3<void, ARG1, ARG2, ARG3> : public Signal {
public:
	// Constructor
	Signal3 (void) : Signal() {}
	// Connection
	int connect (const Slot3<void, ARG1, ARG2, ARG3>& slot) {
		return Signal::connect (slot);
	}
	// Callback
	void invoke (ARG1 arg1, ARG2 arg2, ARG3 arg3) {
		for (size_t i = 0; i < _slots.size (); i++) {
			if (_slots[i]) (*((Slot3<void, ARG1, ARG2, ARG3> *) _slots[i])) (arg1, arg2, arg3);
		}
	}
};

template<typename RET, typename ARG1, typename ARG2, typename ARG3, typename ARG4>
class Signal4 : public Signal {
public:
	// Constructor
	Signal4 (void) : Signal() {}
	// Connection
	int connect (const Slot4<RET, ARG1, ARG2, ARG3, ARG4>& slot) {
		return Signal::connect (slot);
	}
	// Callback
	// fixme: Return type collection
	RET invoke (ARG1 arg1, ARG2 arg2, ARG3 arg3, ARG4 arg4, RET rval) {
		for (size_t i = 0; i < _slots.size (); i++) {
			if (_slots[i]) rval = (*((Slot4<RET, ARG1, ARG2, ARG3, ARG4> *) _slots[i])) (arg1, arg2, arg3, arg4);
		}
		return rval;
	}
};

template<typename ARG1, typename ARG2, typename ARG3, typename ARG4>
class Signal4<void, ARG1, ARG2, ARG3, ARG4> : public Signal {
public:
	// Constructor
	Signal4 (void) : Signal() {}
	// Connection
	int connect (const Slot4<void, ARG1, ARG2, ARG3, ARG4>& slot) {
		return Signal::connect (slot);
	}
	// Callback
	void invoke (ARG1 arg1, ARG2 arg2, ARG3 arg3, ARG4 arg4) {
		for (size_t i = 0; i < _slots.size (); i++) {
			if (_slots[i]) (*((Slot4<void, ARG1, ARG2, ARG3, ARG4> *) _slots[i])) (arg1, arg2, arg3, arg4);
		}
	}
};


} // Namespace Signals

} // Namespace Miletos

#endif

