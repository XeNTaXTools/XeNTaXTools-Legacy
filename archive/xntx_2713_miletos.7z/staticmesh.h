#ifndef __MILETOS_SMESH_H__
#define __MILETOS_SMESH_H__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2010
//

#include <miletos/scene.h>
#include <miletos/geometry.h>

namespace Miletos {

class SMesh : public Item {
private:
	// Object implementation
	virtual const Type *objectType (void);
	virtual Object *childAdded (Thera::Node *cnode, Thera::Node *rnode);
	virtual void childRemoved (Thera::Node *cnode, Thera::Node *rnode);
protected:
	Geometry *geometry;

	// Object implementation
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	virtual void update (UpdateCtx *ctx, unsigned int flags);
	// Item implementation
	virtual Sehle::Renderable *show (Sehle::Graph *graph, Sehle::u32 contextmask);
	virtual void hide (Sehle::RenderableGroup *pgroup);
	virtual Item *trace (const Elea::Line3f *wray, unsigned int mask, float *distance);
public:
	SMesh (void);
	virtual ~SMesh (void);

	// Type system
	static const Type *type (void);
};

} // Namespace Miletos

#endif

