#define __MILETOS_URI_CPP__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2007-2009
//

#include <stdlib.h>

#include <libarikkei/dict.h>

#include "zip.h"
#include "xfpk.h"
#include "xpp.h"

#include "uri.h"

#ifdef WIN32
#define strdup _strdup
#endif

namespace Miletos {

namespace URI {

// Location

Location::Location (const char *address)
{
	arikkei_url_setup (this, (const unsigned char *) address, NULL);
}

Location::Location (const char *address, const char *defaultprotocol)
{
	arikkei_url_setup (this, (const unsigned char *) address, (const unsigned char *) defaultprotocol);
}

Location::~Location (void)
{
	arikkei_url_release (this);
}

char *
Location::getParent (int levels)
{
	if (!base) return NULL;
	const unsigned char *p = (const unsigned char *) strrchr ((const char *) base, '/');
	if (!p) return NULL;
	for (int i = 0; i < levels; i++) {
		if (p == base) return NULL;
		p -= 1;
		while ((p > base) && (*p != '/')) p--;
		if (*p != '/') return NULL;
	}
	size_t len = p - base + 1;
	char *parent = (char *) malloc (len + 1);
	memcpy (parent, base, len);
	parent[len] = 0;
	return parent;
}

// URLHandler

URLHandler::URLHandler (const char *purl)
: refcount(1)
{
	arikkei_url_setup (&url, (const unsigned char *) purl, NULL);
}

URLHandler::~URLHandler (void)
{
	arikkei_url_release (&url);
}

const unsigned char *
URLHandler::mmapData (const char *name, size_t *size)
{
	if (!name || !*name) return NULL;
	if (strncmp (name, (const char *) url.path, strlen ((const char *) url.path))) return NULL;
	return mmapDataRelative (name + strlen ((const char *) url.path), size);
}

// Resolver

Resolver::~Resolver (void)
{
	// Free schemes
	for (size_t i = 0; i < schemes.size (); i++) {
		free (schemes[i]);
	}
}

// This grabs reference to handler

void
Resolver::addURLHandler (const char *scheme, URLHandler * (* constructor) (const char *))
{
	if (!scheme || !*scheme || !constructor) return;
	char *pscheme = strdup (scheme);
	schemes.push_back (pscheme);
	constructors.insert (pscheme, constructor);
}

URLHandler *
Resolver::getHandler (const char *url)
{
	if (!url || !*url) return NULL;
	char *purl = strdup (url);
	char *cpos = strchr (purl, ':');
	if (!cpos) {
		// No scheme specified
		free (purl);
		return NULL;
	}
	*cpos = 0;
	URLHandler * (* constructor) (const char *) = constructors.lookup (purl);
	if (!constructor) {
		// No handler for such scheme
		free (purl);
		return NULL;
	}
	free (purl);
	return constructor (url);
}

// FileHandler

class FileHandler : public URLHandler {
private:
	// URLHandler implementation
	virtual const unsigned char *mmapData (const char *name, size_t *size);
	virtual void munmapData (const unsigned char *data);
public:
};

// Global data

static Resolver *globalresolver = NULL;

// Scheme should be specified without trailing colon

static void
init_global_resolver (void)
{
	globalresolver = new Resolver();
	globalresolver->addURLHandler ("file", FileSystem::URLHandler::newURLHandler);
	globalresolver->addURLHandler ("xfpk", Xfpk::URLHandler::newURLHandler);
	globalresolver->addURLHandler ("xpp", Xpp::URLHandler::newURLHandler);
	globalresolver->addURLHandler ("zip", Zip::URLHandler::newURLHandler);
}

unsigned int
isRelativeURL (const char *uri)
{
	return !uri || !strchr (uri, ':');
}

void
addURLHandler (const char *scheme, URLHandler * (* constructor) (const char *))
{
	if (!globalresolver) init_global_resolver ();
	globalresolver->addURLHandler (scheme, constructor);
}

URLHandler *
getHandler (const char *url)
{
	if (!url || !*url) return NULL;
	if (!globalresolver) init_global_resolver ();
	return globalresolver->getHandler (url);
}

} // Namespace URI

} // Namespace Miletos

