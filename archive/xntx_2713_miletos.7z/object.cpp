#define __MILETOS_CPP__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2007
//

#ifndef _CRT_SECURE_NO_DEPRECATE
#define _CRT_SECURE_NO_DEPRECATE 1
#endif

static const int debug = 0;

#include <malloc.h>
#include <string.h>
#include <stdio.h>
#include <assert.h>

#include "miletos.h"
#include "connect.h"

#ifdef WIN32
#define strdup _strdup
#endif

namespace Miletos {

// Type

Object::Type::Type (const Type *pparent, const char *pname, const char *ptag, Object * (*pfactory) (), u32 pnattributes, const Attribute *pattributes)
: parent(pparent), name(pname), tag(ptag), factory(pfactory), nattributes(pnattributes), attributes(pattributes)
{
#ifdef WITH_JAVA
	javaobject = NULL;
#endif
}

// Object

unsigned int
Object::node_add_child (Thera::Node *node, Thera::Node *child, Thera::Node *ref, void *data)
{
	Object *object = (Object *) data;
	assert (node == object->node);
	return object->addChild (child, ref);
}

void
Object::node_child_added (Thera::Node *node, Thera::Node *child, Thera::Node *ref, void *data)
{
	Object *object = (Object *) data;
	assert (node == object->node);
	object->childAdded (child, ref);
}

unsigned int
Object::node_remove_child (Thera::Node *node, Thera::Node *child, Thera::Node *ref, void *data)
{
	Object *object = (Object *) data;
	assert (node == object->node);
	return object->removeChild (child, ref);
}

void
Object::node_child_removed (Thera::Node *node, Thera::Node *child, Thera::Node *ref, void *data)
{
	Object *object = (Object *) data;
	assert (node == object->node);
	object->childRemoved (child, ref);
}

unsigned int
Object::node_change_attr (Thera::Node *node, const char *key, const char *oldval, const char *newval, void *data)
{
	Object *object = (Object *) data;
	assert (node == object->node);
	if (!strcmp (key, "id")) {
		if (!newval || object->document->lookupObject (newval)) return false;
	} else if (!strcmp (key, "xmlns")) {
		// fixme: handle namespace change
		return false;
	}
	return object->changeAttr (key, newval);
}

void
Object::node_attr_changed (Thera::Node *node, const char *key, const char *oldval, const char *newval, void *data)
{
	Object *object = (Object *) data;
	assert (node == object->node);
	if (!strcmp (key, "id")) {
		Document *document = object->document;
		// Release old id
		// Signal everyone about identity deletion
		document->identityRemoved (object->id);
		// Clear id
		document->undefObject (object);
		free (object->id);
		// Set new id
		object->id = strdup (newval);
		document->defineObject (object);
		document->identityAdded (object->id, object);
		object->requestModified (MODIFIED);
	} else if (!strcmp (key, "xmlns")) {
		// fixme: handle namespace change
	}
	object->set (key, newval);
	object->sig_attr_changed.invoke (object, key);
}

unsigned int
Object::node_change_content (Thera::Node *node, const char *oldcontent, const char *newcontent, void *data)
{
	Object *object = (Object *) data;
	assert (node == object->node);
	return object->changeContent (newcontent);
}

void
Object::node_content_changed (Thera::Node *node, const char *oldcontent, const char *newcontent, void *data)
{
	Object *object = (Object *) data;
	assert (node == object->node);
	object->setContent (newcontent);
	object->sig_content_changed.invoke (object);
}

Object::Object (unsigned int flags)
: _flags(flags), _uflags(0), _mflags(0), defaultns(NULL), id(NULL), node(NULL), document(NULL), next(NULL), children(NULL), parent(NULL), attachcount(0)
{
#ifdef WITH_JAVA
	javaobject = NULL;
#endif
}

Object::~Object (void)
{
	assert (!parent);
	assert (!children);
	assert (!next);
	assert (!document);
	assert (!node);
	assert (!id);
}

const Object::Type *
Object::objectType (void)
{
	return type ();
}

const Object::Type *
Object::type (void)
{
	static Type *mytype = NULL;
	static const Attribute attrs[] = {
		{ "id", NULL, 0 }
	};
	if (!mytype) mytype = new Type(NULL, "Object", NULL, NULL, sizeof (attrs) / sizeof (attrs[0]), attrs);
	return mytype;
}

void
Object::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	if (!(_flags & HAS_CHILDREN)) return;

	// Build children
	Object *prevchild = NULL;
	for (Thera::Node *cnode = pnode->children; cnode; cnode = cnode->next) {
		const char *childns = cnode->getAttribute ("xmlns");
		Object *child = document->newObject (cnode->type, (childns) ? childns : ctx->defaultns, cnode->name);
		BuildCtx cctx;
		cctx.defaultns = (childns) ? childns : ctx->defaultns;
		child->invokeBuild (cnode, doc, &cctx);
		if (prevchild) {
			prevchild->next = child;
		} else {
			children = child;
		}
		child->parent = this;
		prevchild = child;
	}

	// Request update
	requestUpdate (MODIFIED | TREE_MODIFIED);
}

void
Object::release (void)
{
	if (!(_flags & HAS_CHILDREN)) return;
	// Release children
	while (children) {
		Object *child = children;
		children = child->next;
		child->parent = NULL;
		child->next = NULL;
		child->invokeRelease ();
		delete child;
	}
}

unsigned int
Object::addChild (Thera::Node *cnode, Thera::Node *rnode)
{
	return (_flags & HAS_CHILDREN) != 0;
}

Object *
Object::childAdded (Thera::Node *cnode, Thera::Node *rnode)
{
	assert ((_flags & HAS_CHILDREN) != 0);
	// Build child
	const char *childns = cnode->getAttribute ("xmlns");
	Object *child = document->newObject (cnode->type, (childns) ? childns : defaultns, cnode->name);
	BuildCtx ctx;
	ctx.defaultns = (childns) ? childns : defaultns;
	child->invokeBuild (cnode, document, &ctx);
	Object *rchild = NULL;
	if (rnode) {
		rchild = children;
		while (rchild && (rchild->node != rnode)) rchild = rchild->next;
		assert (rchild);
		child->next = rchild->next;
		rchild->next = child;
	} else {
		child->next = children;
		children = child;
	}
	child->parent = this;

	// Request update
	requestUpdate (MODIFIED | TREE_MODIFIED);

	// Emit signals
	sig_child_added.invoke (this, child);
	document->sig_object_added.invoke (document, this, rchild);

	return child;
}

unsigned int
Object::removeChild (Thera::Node *cnode, Thera::Node *rnode)
{
	return (_flags & HAS_CHILDREN) != 0;
}

void
Object::childRemoved (Thera::Node *cnode, Thera::Node *rnode)
{
	assert ((_flags & HAS_CHILDREN) != 0);
	// Find ref and child
	Object *rchild = NULL;
	if (rnode) {
		rchild = children;
		while (rchild && (rchild->node != rnode)) rchild = rchild->next;
		assert (rchild != NULL);
	}
	Object *child = children;
	while (child && (child->node != cnode)) child = child->next;
	assert (child != NULL);

	// Emit signal
	sig_remove_child.invoke (this, child);

	// Release child
	if (rchild) {
		rchild->next = child->next;
	} else {
		children = child->next;
	}
	child->parent = NULL;
	child->next = NULL;
	child->invokeRelease ();
	delete child;

	// Emit document signal
	document->sig_object_removed.invoke (document, this, rchild);

	// Request update
	requestUpdate (MODIFIED | TREE_MODIFIED);
}

void
Object::invokeBuild (Thera::Node *pnode, Document *pdoc, BuildCtx *ctx)
{
	static struct Thera::EventVector objev = {
		// void (* destroy) (Node *node, void *data);
		NULL,
		// unsigned int (* add_child) (Node *node, Node *child, Node *ref, void *data);
		Object::node_add_child,
		// void (* child_added) (Node *node, Node *child, Node *ref, void *data);
		Object::node_child_added,
		// unsigned int (* remove_child) (Node *node, Node *child, Node *ref, void *data);
		Object::node_remove_child,
		// void (* child_removed) (Node *node, Node *child, Node *ref, void *data);
		Object::node_child_removed,
		// unsigned int (* change_attr) (Node *node, const char *key, const char *oldval, const char *newval, void *data);
		Object::node_change_attr,
		// void (* attr_changed) (Node *node, const char *key, const char *oldval, const char *newval, void *data);
		Object::node_attr_changed,
		// unsigned int (* change_content) (Node *node, const char *oldcontent, const char *newcontent, void *data);
		NULL,
		// void (* content_changed) (Node *node, const char *oldcontent, const char *newcontent, void *data);
		Object::node_content_changed,
		// unsigned int (* change_order) (Node *node, Node *child, Node *oldref, Node *newref, void *data);
		// void (* order_changed) (Node *node, Node *child, Node *oldref, Node *newref, void *data);
		NULL, NULL,
		// Upstream handlers
		NULL, NULL, NULL, NULL, NULL
	};

	assert (!node);
	assert (pnode);
	assert (!document);
	assert (pdoc);
	// Attaching should be performed after build
	assert (!parent);
	assert (!next);
	assert (!children);

	// Set members
	node = pnode;
	document = pdoc;
	defaultns = ctx->defaultns;

	// Set or update Id
	const char *pid = node->getAttribute ("id");
	if (!pid || document->lookupObject (pid)) {
		pid = document->getUniqueId (this);
		if (!node->setAttribute ("id", pid)) {
			assert (0);
		}
		pid = node->getAttribute ("id");
		assert (pid);
	}
	id = strdup (pid);
	document->defineObject (this);

	// Build actual object in current namespace
	build (pnode, pdoc, ctx);

	// Attach to node
	node->addListener (&objev, this);
	// Request update
	requestUpdate (MODIFIED);
	// Signal everyone about new identity
	document->identityAdded (id, this);
}

void
Object::invokeRelease (void)
{
	assert (document);
	assert (node);
	// Subclass implementation
	release ();
	// Detaching should be completed now
	assert (!next);
	assert (!parent);
	assert (!children);

#ifdef WITH_JAVA
	if (javaobject) {
		assert (document->javaenv);
		releaseJavaObject (document->javaenv);
		javaobject = NULL;
	}
#endif

	// Signal everyone about identity deletion
	document->identityRemoved (id);
	// Emit signal
	sig_release.invoke (this);
	if (attachcount > 0) {
		fprintf (stderr, "Synchronization problem: Object %s attachcount %d\n", id, attachcount);
	}
	// Detach from node
	node->removeListener (this);
	// Clear id
	document->undefObject (this);
	free (id);
	id = NULL;
	// Clear members
	document = NULL;
	node = NULL;
}

void
Object::requestUpdate (int flags)
{
	assert (document);
	assert (!(flags & PARENT_MODIFIED));
	assert (flags & MODIFIED_STATE);
	// The following happens, if objects signal others in ::modified cascade
	// assert (!(flags & CHILD_MODIFIED) || !(flags & ~CHILD_MODIFIED));
	if (debug) fprintf (stderr, "Object::requestUpdate: %s %d/%d\n", id, flags, _uflags);
	// Check if we have to propagate upstreams
	bool propagate = !(_uflags & MODIFIED_STATE);
	// Set our flags
	_uflags |= flags;
	// Propagate
	if (propagate) {
		if (parent) {
			parent->requestUpdate (CHILD_MODIFIED);
		} else {
			document->requestUpdate ();
		}
	}
}

void
Object::requestModified (int flags)
{
	assert (document);
	assert (!(flags & PARENT_MODIFIED));
	assert (flags & MODIFIED_STATE);
	assert (!(flags & CHILD_MODIFIED) || !(flags & ~CHILD_MODIFIED));
	// Check if we have to propagate upstreams
	bool propagate = !(_mflags & MODIFIED_STATE);
	// Set our flags
	_mflags |= flags;
	// Propagate
	if (propagate) {
		if (parent) {
			parent->requestModified (CHILD_MODIFIED);
		} else {
			document->requestModified ();
		}
	}
}

void
Object::invokeUpdate (UpdateCtx *ctx, unsigned int flags)
{
	if (debug) fprintf (stderr, "Object::invokeUpdate: %s %d/%d\n", id, flags, _uflags);
	// Collate flags
	flags |= _uflags;
	// Set modified flags
	_mflags |= _uflags;
	// Clear flags to allow rescheduling update
	_uflags = 0;

	// fixme: Style stuff (Lauris)

	update (ctx, flags);
}

void
Object::invokeModified (unsigned int flags)
{
	// Collate flags
	flags |= _mflags;
	// Clear flags to allow rescheduling update
	_mflags = 0;
	// Invoke virtual method
	modified (flags);
	// Emit signals
	sig_modified.invoke (this, flags);
	document->sig_object_modified.invoke (document, this, flags);
}

void
Object::update (UpdateCtx *ctx, unsigned int flags)
{
	invokeChildrenUpdate (ctx, flags);
}

void
Object::modified (unsigned int flags)
{
	if (flags & MODIFIED) flags |= PARENT_MODIFIED;
	flags &= MODIFIED_CASCADE;

	for (Object *child = children; child; child = child->next) {
		if (flags | (child->_mflags & MODIFIED_STATE)) {
			child->invokeModified (flags);
		}
	}
}

void
Object::invokeChildrenUpdate (UpdateCtx *ctx, unsigned int flags)
{
	if (flags & MODIFIED) flags |= PARENT_MODIFIED;
	flags &= MODIFIED_CASCADE;

	for (Object *child = children; child; child = child->next) {
		if (flags | (child->_uflags & MODIFIED_STATE)) {
			child->invokeUpdate (ctx, flags);
		}
	}
}

void
Object::buildAttribute (const char *attrid)
{
	const char *val = node->getAttribute (attrid);
	set (attrid, val);
}

void
Object::buildAllAttributes (const Type *type, BuildCtx *ctx)
{
	if (type == Object::type ()) return;
	for (u32 i = 0; i < type->nattributes; i++) {
		const char *val = node->getAttribute (type->attributes[i].key);
		if (!val) val = type->attributes[i].defvalue;
		set (type->attributes[i].key, val);
	}
}

void
Object::readAttr (const char *attrid)
{
	if (node && attrid) set (attrid, node->getAttribute (attrid));
}

void
Object::writeAttr (const char *attrid)
{
	if (node && attrid) write (attrid);
}

void
Object::attach (Object *attachto)
{
	attachcount += 1;
	sig_release.connect (Signals::MEMBER_SLOT(*attachto, &Object::attachedObjectRelease, (void *) attachto));
	sig_modified.connect (Signals::MEMBER_SLOT(*attachto, &Object::attachedObjectModified, (void *) attachto));
}

void
Object::detach (Object *attachedto)
{
	sig_modified.disconnect (attachedto);
	sig_release.disconnect (attachedto);
	attachcount -= 1;
}

bool
Object::isType (const Object::Type *type)
{
	const Type *mytype = getType ();
	while (mytype) {
		if (type == mytype) return true;
		mytype = mytype->parent;
	}
	return false;
}

bool
Object::isParent (Object *pparent)
{
	for (Object *p = parent; p; p = p->parent) {
		if (p == pparent) return true;
	}
	return false;
}

bool
Object::forall (bool (* handler) (Object *, void *), unsigned int maxdepth, void *data)
{
	if (!handler) return false;
	if (!handler (this, data)) return false;
	if (maxdepth > 0) {
		for (Object *child = children; child; child = child->next) {
			if (!child->forall (handler, maxdepth - 1, data)) return false;
		}
	}
	return true;
}

bool
Object::forallOfType (const Type *type, bool (* handler) (Object *, void *), unsigned int maxdepth, unsigned int detached, void *data)
{
	if (!handler) return false;
	if (isType (type)) {
		if (!handler (this, data)) return false;
	} else {
		if (!detached) return false;
	}
	if (maxdepth > 0) {
		for (Object *child = children; child; child = child->next) {
			if (!child->forallOfType (type, handler, maxdepth - 1, detached, data)) return false;
		}
	}
	return true;
}

u32
Object::listChildrenOfType (const Type *ptype, Object ***plist, const Thera::Node *pexclude)
{
	if (plist && *plist) {
		free (*plist);
		*plist = NULL;
	}
	std::vector<Object *> llist;
	for (Object *child = children; child; child = child->next) {
		if (child->node == pexclude) continue;
		if (child->isType (ptype)) {
			llist.push_back (child);
		}
	}
	if (plist && !llist.empty ()) {
		*plist = (Object **) malloc (llist.size () * sizeof (Object *));
		memcpy (*plist, &llist[0], llist.size () * sizeof (Object *));
	}
	return (u32) llist.size ();
}

} // Namespace Miletos
