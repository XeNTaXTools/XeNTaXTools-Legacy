#define __MILETOS_LIGHT_CPP__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2007
//

#include <malloc.h>

#include <elea/line.h>

#include <sehle/engine.h>
#include <sehle/graph.h>
#include <sehle/light.h>
#include <sehle/renderable.h>
#include <sehle/commonmaterials.h>

#include "xml/base.h"
#include "sphere.h"
#include "primitives.h"

#include "light.h"

namespace Miletos {

// Light

Light::Light (void)
: Item(0), sehlelights(NULL), has_shadow(1), has_density(1), ambient(Elea::Color4fBlack), diffuse(Elea::Color4fWhite), direct(Elea::Color4fWhite), vertices(NULL), nindices(0), indices(NULL)
{
}

Light::~Light (void)
{
	if (vertices) free (vertices);
	if (indices) free (indices);
}

const Object::Type *
Light::objectType (void)
{
	return type ();
}

const Object::Type *
Light::type (void)
{
	static Type *mytype = NULL;
	static const Attribute attrs[] = {
		{ "ambient", "black", 0 },
		{ "diffuse", "white", 0 },
		{ "direct", "white", 0 }
	};
	if (!mytype) mytype = new Type(Item::type (), "Light", NULL, NULL, sizeof (attrs) / sizeof (attrs[0]), attrs);
	return mytype;
}

void
Light::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	Item::build (pnode, doc, ctx);

	document->addLight (this);

	buildAttribute ("ambient");
	buildAttribute ("diffuse");
	buildAttribute ("direct");
}

void
Light::release (void)
{
	document->removeLight (this);

	Item::release ();
}

void
Light::set (const char *attrid, const char *val)
{
	if (!strcmp (attrid, "ambient")) {
		if (!XML::parseColor (&ambient, val)) {
			ambient = Elea::Color4fBlack;
		}
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "diffuse")) {
		if (!XML::parseColor (&diffuse, val)) {
			diffuse = Elea::Color4fWhite;
		}
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "direct")) {
		if (!XML::parseColor (&direct, val)) {
			direct = Elea::Color4fWhite;
		}
		requestUpdate (MODIFIED);
	} else {
		Item::set (attrid, val);
	}
}

void
Light::write (const char *attrid)
{
	char c[256];
	if (!strcmp (attrid, "ambient")) {
		XML::writeColor (c, 64, ambient, false);
		node->setAttribute (attrid, c);
	} else if (!strcmp (attrid, "diffuse")) {
		XML::writeColor (c, 64, diffuse, false);
		node->setAttribute (attrid, c);
	} else if (!strcmp (attrid, "direct")) {
		XML::writeColor (c, 64, direct, false);
		node->setAttribute (attrid, c);
	} else {
		Item::write (attrid);
	}
}

void
Light::update (UpdateCtx *ctx, unsigned int flags)
{
	Item::update (ctx, flags);

	if (sehlelights || graph) updateSehleLights ();
}

void
Light::updateSehleLights (void)
{
	sehlelights->highlightmask = OPAQUE | TRANSPARENT;
	sehlelights->shadowmask = SHADOW | DENSITY;
	sehlelights->l2w = _i2w;
	sehlelights->ambient = ambient;
	sehlelights->diffuse = diffuse;
	sehlelights->direct = direct;
}

void
Light::setAmbient (const Elea::Color4f& color)
{
	ambient = color;

	requestUpdate (MODIFIED);
}

void
Light::setDiffuse (const Elea::Color4f& color)
{
	diffuse = color;

	requestUpdate (MODIFIED);
}

void
Light::setDirect (const Elea::Color4f& color)
{
	direct = color;

	requestUpdate (MODIFIED);
}

// DirectionalLight

DirectionalLight::DirectionalLight (void)
: radius(0.1f)
{
}

DirectionalLight::~DirectionalLight (void)
{
}

static Object *
directionallight_factory (void)
{
	return new DirectionalLight();
}

const Object::Type *
DirectionalLight::objectType (void)
{
	return type ();
}

const Object::Type *
DirectionalLight::type (void)
{
	static Type *mytype = NULL;
	if (!mytype) mytype = new Type(Light::type (), "DirectionalLight", "directionalLight", directionallight_factory, 0, NULL);
	return mytype;
}

void
DirectionalLight::update (UpdateCtx *ctx, unsigned int flags)
{
	Elea::Cuboid3f q(-radius, -radius, -radius, radius, radius, radius);
	bbox.set (ctx->i2w.transform (q));

	Light::update (ctx, flags);
}

Sehle::Renderable *
DirectionalLight::show (Sehle::Graph *pgraph, Sehle::u32 contextmask)
{
	// Create Sehle light block
	sehlelights = graph->newDirectionalLight (0);
	updateSehleLights ();

	// Create mesh
	Sehle::StaticMesh *mesh = new Sehle::StaticMesh(graph, contextmask);

	int nvertices;
	int nindices;
	Sphere::generateMesh (NULL, 0, NULL, 0, NULL, 0, NULL, radius, 3, 1, nvertices, nindices);
	if (!mesh->vbuffer) mesh->vbuffer = mesh->graph->engine->getVertexBuffer (NULL);
	mesh->vbuffer->setUp (nvertices, 8);
	mesh->vbuffer->setOffset (Sehle::VertexBuffer::COORDINATES, 0);
	mesh->vbuffer->setOffset (Sehle::VertexBuffer::NORMALS, 3);
	mesh->vbuffer->setOffset (Sehle::VertexBuffer::TEXCOORDS, 6);
	Sehle::f32 *attributes = mesh->vbuffer->map (Sehle::VertexBuffer::WRITE);
	if (!mesh->ibuffer) mesh->ibuffer = mesh->graph->engine->getIndexBuffer (NULL);
	mesh->ibuffer->resize (nindices);
	Sehle::u32 *indices = mesh->ibuffer->map (Sehle::IndexBuffer::WRITE);
	Sphere::generateMesh (attributes, mesh->vbuffer->stride * sizeof (Sehle::f32),
		attributes + 3, mesh->vbuffer->stride * sizeof (Sehle::f32),
		attributes + 6, mesh->vbuffer->stride * sizeof (Sehle::f32),
		indices, radius, 3, 1, nvertices, nindices);
	mesh->vbuffer->unMap ();
	mesh->ibuffer->unMap ();

	mesh->resizeMaterials (1);
	// mesh->setMaterial (0, WireMaterial::newWireMaterial (engine, NULL));
	mesh->setMaterial (0, Sehle::ColorMaterial::newColorMaterial (mesh->graph->engine, NULL));
	mesh->resizeFragments (1);
	mesh->frags[0].first = 0;
	mesh->frags[0].nindices = nindices;
	mesh->frags[0].matidx = 0;

	return mesh;
}

void
DirectionalLight::hide (Sehle::RenderableGroup *pgroup)
{
	graph->deleteDirectionalLight ((Sehle::DirectionalLight *) sehlelights);
	sehlelights = NULL;

	Item::hide (pgroup);
}

Item *
DirectionalLight::trace (const Elea::Line3f *wray, unsigned int mask, float *distance)
{
	Elea::Cuboid3f bbox(-radius, -radius, -radius, radius, radius, radius);
	Elea::Line3f rl = _w2i.transform (*wray);

	// i2w.transformInPlace (bbox);
	float p0, p1;
	if (bbox.getIntersection (rl, p0, p1) && (p0 > 0)) {
		*distance = p0;
		return this;
	}

	return NULL;
}

void
DirectionalLight::updateSehleLights (void)
{
	Light::updateSehleLights ();
}

// PointLight

PointLight::PointLight (void)
: radius(0.1f),
cutoffDistance(10), constantAttenuation(1), linearAttenuation(0), quadraticAttenuation(0)
{
	static u32 ival[] = { 0, 1, 2, 0, 2, 3, 1, 0, 4, 1, 4, 5, 2, 1, 5, 2, 5, 6, 3, 2, 6, 3, 6, 7, 0, 3, 7, 0, 7, 4, 5, 4, 7, 5, 7, 6 };
	nindices = 12 * 3;
	if (!indices) indices = (u32 *) malloc (nindices * sizeof (u32));
	memcpy (indices, ival, nindices * sizeof (u32));
}

PointLight::~PointLight (void)
{
}

static Object *
pointlight_factory (void)
{
	return new PointLight();
}

const Object::Type *
PointLight::objectType (void)
{
	return type ();
}

const Object::Type *
PointLight::type (void)
{
	static Type *mytype = NULL;
	static const Attribute attrs[] = {
		{ "constantAttenuation", "1", 0 },
		{ "linearAttenuation", "0", 0 },
		{ "quadraticAttenuation", "0", 0 }
	};
	if (!mytype) mytype = new Type(Light::type (), "PointLight", "pointLight", pointlight_factory, sizeof (attrs) / sizeof (attrs[0]), attrs);
	return mytype;
}

void
PointLight::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	Light::build (pnode, doc, ctx);

	buildAllAttributes (type (), ctx);

}

void
PointLight::set (const char *attrid, const char *val)
{
	if (!strcmp (attrid, "constantAttenuation")) {
		if (!XML::parseNumber (&constantAttenuation, val)) constantAttenuation = 1;
		if (constantAttenuation < 0.001f) constantAttenuation = 0.001f;
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "linearAttenuation")) {
		if (!XML::parseNumber (&linearAttenuation, val)) linearAttenuation = 0;
		if (linearAttenuation < 0) linearAttenuation = 0;
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "quadraticAttenuation")) {
		if (!XML::parseNumber (&quadraticAttenuation, val)) quadraticAttenuation = 0;
		if (quadraticAttenuation < 0) quadraticAttenuation = 0;
		requestUpdate (MODIFIED);
	} else {
		Light::set (attrid, val);
	}
}

void
PointLight::write (const char *attrid)
{
	char c[256];
	if (!strcmp (attrid, "constantAttenuation")) {
		XML::writeNumber (c, 256, constantAttenuation);
		node->setAttribute (attrid, c);
	} else if (!strcmp (attrid, "linearAttenuation")) {
		XML::writeNumber (c, 256, linearAttenuation);
		node->setAttribute (attrid, c);
	} else if (!strcmp (attrid, "quadraticAttenuation")) {
		XML::writeNumber (c, 256, quadraticAttenuation);
		node->setAttribute (attrid, c);
	} else {
		Light::write (attrid);
	}
}

void
PointLight::update (UpdateCtx *ctx, unsigned int flags)
{
	Elea::Cuboid3f q(-radius, -radius, -radius, radius, radius, radius);
	bbox.set (ctx->i2w.transform (q));

	updateVolume ();

	Light::update (ctx, flags);
}

Sehle::Renderable *
PointLight::show (Sehle::Graph *pgraph, Sehle::u32 contextmask)
{
	// Create Sehle light block
	sehlelights = graph->newPointLights (1, 0);
	updateSehleLights ();

	// Create mesh
	Sehle::StaticMesh *mesh = new Sehle::StaticMesh(graph, contextmask);

	int nvertices;
	int nindices;
	Sphere::generateMesh (NULL, 0, NULL, 0, NULL, 0, NULL, radius, 3, 1, nvertices, nindices);
	if (!mesh->vbuffer) mesh->vbuffer = mesh->graph->engine->getVertexBuffer (NULL);
	mesh->vbuffer->setUp (nvertices, 8);
	mesh->vbuffer->setOffset (Sehle::VertexBuffer::COORDINATES, 0);
	mesh->vbuffer->setOffset (Sehle::VertexBuffer::NORMALS, 3);
	mesh->vbuffer->setOffset (Sehle::VertexBuffer::TEXCOORDS, 6);
	Sehle::f32 *attributes = mesh->vbuffer->map (Sehle::VertexBuffer::WRITE);
	if (!mesh->ibuffer) mesh->ibuffer = mesh->graph->engine->getIndexBuffer (NULL);
	mesh->ibuffer->resize (nindices);
	Sehle::u32 *indices = mesh->ibuffer->map (Sehle::IndexBuffer::WRITE);
	Sphere::generateMesh (attributes, mesh->vbuffer->stride * sizeof (Sehle::f32),
		attributes + 3, mesh->vbuffer->stride * sizeof (Sehle::f32),
		attributes + 6, mesh->vbuffer->stride * sizeof (Sehle::f32),
		indices, radius, 3, 1, nvertices, nindices);
	mesh->ibuffer->unMap ();
	mesh->vbuffer->unMap ();
	mesh->resizeMaterials (1);
	// mesh->setMaterial (0, WireMaterial::newWireMaterial (engine, NULL));
	mesh->setMaterial (0, Sehle::ColorMaterial::newColorMaterial (mesh->graph->engine, NULL));
	mesh->resizeFragments (1);
	mesh->frags[0].first = 0;
	mesh->frags[0].nindices = nindices;
	mesh->frags[0].matidx = 0;

	return mesh;
}

void
PointLight::hide (Sehle::RenderableGroup *pgroup)
{
	graph->deletePointLights ((Sehle::PointLight *) sehlelights);
	sehlelights = NULL;

	Item::hide (pgroup);
}

Item *
PointLight::trace (const Elea::Line3f *wray, unsigned int mask, float *distance)
{
	Elea::Cuboid3f bbox(-radius, -radius, -radius, radius, radius, radius);
	Elea::Line3f rl = _w2i.transform (*wray);

	// i2w.transformInPlace (bbox);
	float p0, p1;
	if (bbox.getIntersection (rl, p0, p1) && (p0 > 0)) {
		*distance = p0;
		return this;
	}

	return NULL;
}

void
PointLight::updateSehleLights (void)
{
	Sehle::PointLight *point = (Sehle::PointLight *) sehlelights;
	point->vertices = vertices;
	point->nindices = nindices;
	point->indices = indices;
	point->constantAttenuation = constantAttenuation;
	point->linearAttenuation = linearAttenuation;
	point->quadraticAttenuation = quadraticAttenuation;

	Light::updateSehleLights ();
}

void
PointLight::updateVolume (void)
{
	float maxdist = cutoffDistance;
	// maxdist = 20;
	if ((quadraticAttenuation >= 0) && ((linearAttenuation > 0) || (quadraticAttenuation > 0))) {
		// Find distance where I1 == 0.001
		// constAtt + linAtt * d + quadAtt * d * d = 1000
		double a = quadraticAttenuation;
		double b = linearAttenuation;
		double c = constantAttenuation - 1000;
		double q = b * b - 4 * a * c;
		if (q >= 0) {
			double distance = (-b + sqrt (q)) / (2 * a);
			if (distance < maxdist) maxdist = (float) distance;
		}
	}
	float l = maxdist;

	if (!vertices) vertices = (Elea::Vector3f *) malloc (8 * sizeof (Elea::Vector3f));
	vertices[0].set (-l, -l, -l);
	vertices[1].set (l, -l, -l);
	vertices[2].set (l, l, -l);
	vertices[3].set (-l, l, -l);
	vertices[4].set (-l, -l, l);
	vertices[5].set (l, -l, l);
	vertices[6].set (l, l, l);
	vertices[7].set (-l, l, l);
}

// SpotLight

SpotLight::SpotLight (void)
: radius(0.1f), shadowprojection(Elea::Matrix4x4f::frustum (0.1f, 1, 0.1f, 1000)),
cutoffDistance(1000), decayExponent(1), cutoffAngle(0.5f), constantAttenuation(1), linearAttenuation(0), quadraticAttenuation(0)
{
}

SpotLight::~SpotLight (void)
{
}

static Object *
spotlight_factory (void)
{
	return new SpotLight();
}

const Object::Type *
SpotLight::objectType (void)
{
	return type ();
}

const Object::Type *
SpotLight::type (void)
{
	static Type *mytype = NULL;
	static const Attribute attrs[] = {
		// fixme: Use correct matrix value
		{ "shadowProjection", NULL, 0 },
		{ "decay", "1", 0 },
		{ "cutoff", "0.5", 0 },
		{ "constantAttenuation", "1", 0 },
		{ "linearAttenuation", "0", 0 },
		{ "quadraticAttenuation", "0", 0 }
	};
	if (!mytype) mytype = new Type(Light::type (), "SpotLight", "spotLight", spotlight_factory, sizeof (attrs) / sizeof (attrs[0]), attrs);
	return mytype;
}

void
SpotLight::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	Light::build (pnode, doc, ctx);

	buildAllAttributes (type (), ctx);

}

void
SpotLight::set (const char *attrid, const char *val)
{
	if (!strcmp (attrid, "shadowProjection")) {
		if (!XML::parseTransform (shadowprojection, val)) {
			shadowprojection = Elea::Matrix4x4f::frustum (0.1f, 1, 0.1f, 1000);
		}
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "decay")) {
		if (!XML::parseNumber (&decayExponent, val)) decayExponent = 1;
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "cutoff")) {
		if (!XML::parseNumber (&cutoffAngle, val)) cutoffAngle = 0.5f;
		if (cutoffAngle > 1) cutoffAngle = 1;
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "constantAttenuation")) {
		if (!XML::parseNumber (&constantAttenuation, val)) constantAttenuation = 1;
		if (constantAttenuation < 0.001f) constantAttenuation = 0.001f;
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "linearAttenuation")) {
		if (!XML::parseNumber (&linearAttenuation, val)) linearAttenuation = 0;
		if (linearAttenuation < 0) linearAttenuation = 0;
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "quadraticAttenuation")) {
		if (!XML::parseNumber (&quadraticAttenuation, val)) quadraticAttenuation = 0;
		if (quadraticAttenuation < 0) quadraticAttenuation = 0;
		requestUpdate (MODIFIED);
	} else {
		Light::set (attrid, val);
	}
}

void
SpotLight::write (const char *attrid)
{
	char c[256];
	if (!strcmp (attrid, "shadowProjection")) {
		XML::writeMatrix (c, 256, shadowprojection, true);
		node->setAttribute (attrid, c);
	} else {
		Light::write (attrid);
	}
}

void
SpotLight::update (UpdateCtx *ctx, unsigned int flags)
{
	Elea::Cuboid3f q(-radius, -radius, -radius, radius, radius, radius);
	bbox.set (ctx->i2w.transform (q));

	updateVolume ();

	Light::update (ctx, flags);
}

Sehle::Renderable *
SpotLight::show (Sehle::Graph *pgraph, Sehle::u32 contextmask)
{
	// Create Sehle light block
	sehlelights = graph->newSpotLights (1, 0);
	updateSehleLights ();

	// Create mesh
	Sehle::StaticMesh *mesh = new Sehle::StaticMesh(graph, contextmask);

	int nvertices;
	int nindices;
	Sphere::generateMesh (NULL, 0, NULL, 0, NULL, 0, NULL, radius, 3, 1, nvertices, nindices);
	if (!mesh->vbuffer) mesh->vbuffer = mesh->graph->engine->getVertexBuffer (NULL);
	mesh->vbuffer->setUp (nvertices, 8);
	mesh->vbuffer->setOffset (Sehle::VertexBuffer::COORDINATES, 0);
	mesh->vbuffer->setOffset (Sehle::VertexBuffer::NORMALS, 3);
	mesh->vbuffer->setOffset (Sehle::VertexBuffer::TEXCOORDS, 6);
	mesh->vbuffer->map (Sehle::VertexBuffer::WRITE);
	if (!mesh->ibuffer) mesh->ibuffer = mesh->graph->engine->getIndexBuffer (NULL);
	mesh->ibuffer->resize (nindices);
	mesh->ibuffer->map (Sehle::IndexBuffer::WRITE);
	Sphere::generateMesh (mesh->vbuffer->getValuesW (), mesh->vbuffer->stride * sizeof (Sehle::f32),
		mesh->vbuffer->getValuesW () + 3, mesh->vbuffer->stride * sizeof (Sehle::f32),
		mesh->vbuffer->getValuesW () + 6, mesh->vbuffer->stride * sizeof (Sehle::f32),
		&mesh->ibuffer->indices[0], radius, 3, 1, nvertices, nindices);
	mesh->vbuffer->unMap ();
	mesh->ibuffer->unMap ();

	mesh->resizeMaterials (1);
	// mesh->setMaterial (0, WireMaterial::newWireMaterial (engine, NULL));
	mesh->setMaterial (0, Sehle::ColorMaterial::newColorMaterial (mesh->graph->engine, NULL));
	mesh->resizeFragments (1);
	mesh->frags[0].first = 0;
	mesh->frags[0].nindices = nindices;
	mesh->frags[0].matidx = 0;

	return mesh;
}

void
SpotLight::hide (Sehle::RenderableGroup *pgroup)
{
	graph->deleteSpotLights ((Sehle::SpotLight *) sehlelights);
	sehlelights = NULL;

	Item::hide (pgroup);
}

Item *
SpotLight::trace (const Elea::Line3f *wray, unsigned int mask, float *distance)
{
	Elea::Cuboid3f bbox(-radius, -radius, -radius, radius, radius, radius);
	Elea::Line3f rl = _w2i.transform (*wray);

	// i2w.transformInPlace (bbox);
	float p0, p1;
	if (bbox.getIntersection (rl, p0, p1) && (p0 > 0)) {
		*distance = p0;
		return this;
	}

	return NULL;
}

void
SpotLight::updateSehleLights (void)
{
	Sehle::SpotLight *spot = (Sehle::SpotLight *) sehlelights;
	spot->vertices = vertices;
	spot->nindices = nindices;
	spot->indices = indices;
	spot->decayExponent = decayExponent;
	spot->cutoffAngle = cutoffAngle;
	spot->constantAttenuation = constantAttenuation;
	spot->linearAttenuation = linearAttenuation;
	spot->quadraticAttenuation = quadraticAttenuation;
	spot->hasshadow = 1;
	spot->hasdensity = 1;
	spot->shadowProjection = shadowprojection;

	Light::updateSehleLights ();
}

Elea::Matrix4x4f
SpotLight::getShadowProjection (void)
{
	return shadowprojection;
}

void
SpotLight::setShadowProjection (const Elea::Matrix4x4f& pprojection)
{
	shadowprojection = pprojection;
}

void
SpotLight::updateVolume (void)
{
	if (!vertices || !indices) {
		unsigned int nv, ni;
		Sehle::SpotLight::buildVolume (NULL, 0, &nv, NULL, &ni, 0.01f, 6, decayExponent, cutoffAngle, constantAttenuation, linearAttenuation, quadraticAttenuation, cutoffDistance, NULL);
		if (!vertices) vertices = (Elea::Vector3f *) malloc (nv * sizeof (Elea::Vector3f));
		if (!indices) indices = (u32 *) malloc (ni * sizeof (u32));
		nindices = ni;
	}
	Sehle::SpotLight::buildVolume (vertices[0], sizeof (Elea::Vector3f), NULL, indices, NULL, 0.01f, 6, decayExponent, cutoffAngle, constantAttenuation, linearAttenuation, quadraticAttenuation, cutoffDistance, &shadowprojection);
}

// AreaLight

AreaLight::AreaLight (void)
: shadowprojection(Elea::Matrix4x4f::frustum (0.1f, 1, 0.1f, 1000)),
cutoffDistance(1000), decayExponent(1), cutoffAngle(0.5f), constantAttenuation(1), linearAttenuation(0), quadraticAttenuation(0)
{
	size[0] = 1;
	size[1] = 1;
	samples[0] = 2;
	samples[1] = 2;
}

AreaLight::~AreaLight (void)
{
}

static Object *
arealight_factory (void)
{
	return new AreaLight();
}

const Object::Type *
AreaLight::objectType (void)
{
	return type ();
}

const Object::Type *
AreaLight::type (void)
{
	static Type *mytype = NULL;
	static const Attribute attrs[] = {
		// fixme: Use correct matrix value
		{ "shadowProjection", NULL, 0 },
		{ "decay", "1", 0 },
		{ "cutoff", "0.5", 0 },
		{ "constantAttenuation", "1", 0 },
		{ "linearAttenuation", "0", 0 },
		{ "quadraticAttenuation", "0", 0 },
		{ "sizeX", "1", 0 },
		{ "sizeY", "1", 0 },
		{ "samplesX", "2", 0 },
		{ "samplesY", "2", 0 }
	};
	if (!mytype) mytype = new Type(Light::type (), "AreaLight", "areaLight", arealight_factory, sizeof (attrs) / sizeof (attrs[0]), attrs);
	return mytype;
}

void
AreaLight::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	Light::build (pnode, doc, ctx);

	buildAllAttributes (type (), ctx);

}

void
AreaLight::set (const char *attrid, const char *val)
{
	if (!strcmp (attrid, "decay")) {
		if (!XML::parseNumber (&decayExponent, val)) decayExponent = 1;
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "cutoff")) {
		if (!XML::parseNumber (&cutoffAngle, val)) cutoffAngle = 0.5f;
		if (cutoffAngle > 1) cutoffAngle = 1;
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "constantAttenuation")) {
		if (!XML::parseNumber (&constantAttenuation, val)) constantAttenuation = 1;
		if (constantAttenuation < 0.001f) constantAttenuation = 0.001f;
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "linearAttenuation")) {
		if (!XML::parseNumber (&linearAttenuation, val)) linearAttenuation = 0;
		if (linearAttenuation < 0) linearAttenuation = 0;
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "quadraticAttenuation")) {
		if (!XML::parseNumber (&quadraticAttenuation, val)) quadraticAttenuation = 0;
		if (quadraticAttenuation < 0) quadraticAttenuation = 0;
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "sizeX")) {
		if (!XML::parseNumber (&size[Elea::X], val)) size[Elea::X] = 1;
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "sizeY")) {
		if (!XML::parseNumber (&size[Elea::Y], val)) size[Elea::Y] = 1;
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "samplesX")) {
		if (!XML::parseInteger (&samples[Elea::X], val)) samples[Elea::X] = 2;
		if (samples[Elea::X] < 1) samples[Elea::X] = 1;
		if (samples[Elea::X] > 10) samples[Elea::X] = 10;
		if (sehlelights) {
			graph->deleteSpotLights ((Sehle::SpotLight *) sehlelights);
			sehlelights = NULL;
		}
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "samplesY")) {
		if (!XML::parseInteger (&samples[Elea::Y], val)) samples[Elea::Y] = 2;
		if (samples[Elea::Y] < 1) samples[Elea::Y] = 1;
		if (samples[Elea::Y] > 10) samples[Elea::Y] = 10;
		if (sehlelights) {
			graph->deleteSpotLights ((Sehle::SpotLight *) sehlelights);
			sehlelights = NULL;
		}
		requestUpdate (MODIFIED);
	} else {
		Light::set (attrid, val);
	}
}

void
AreaLight::update (UpdateCtx *ctx, unsigned int flags)
{
	Elea::Cuboid3f q(-size[Elea::X] / 2, -size[Elea::Y] / 2, 0, size[Elea::X] / 2, size[Elea::Y] / 2, 0.1f);
	bbox.set (ctx->i2w.transform (q));

	updateVolume ();

	Light::update (ctx, flags);
}

Sehle::Renderable *
AreaLight::show (Sehle::Graph *pgraph, Sehle::u32 contextmask)
{
	updateSehleLights ();

	// Create mesh
	Sehle::StaticMesh *mesh = new Sehle::StaticMesh(graph, contextmask);

	Elea::Vector3f p0(-size[0] / 2, -size[1] / 2, 0);
	Elea::Vector3f p1(size[0] / 2, size[1] / 2, 0.1f);
	int nvertices;
	int nindices;
	Box::generateMesh (NULL, 0, NULL, 0, NULL, 0, NULL, p0, p1, &nvertices, &nindices);
	if (!mesh->vbuffer) mesh->vbuffer = mesh->graph->engine->getVertexBuffer (NULL);
	mesh->vbuffer->setUp (nvertices, 8);
	mesh->vbuffer->setOffset (Sehle::VertexBuffer::COORDINATES, 0);
	mesh->vbuffer->setOffset (Sehle::VertexBuffer::NORMALS, 3);
	mesh->vbuffer->setOffset (Sehle::VertexBuffer::TEXCOORDS, 6);
	if (!mesh->ibuffer) mesh->ibuffer = mesh->graph->engine->getIndexBuffer (NULL);
	mesh->ibuffer->resize (nindices);
	mesh->vbuffer->map (Sehle::VertexBuffer::WRITE);
	mesh->ibuffer->map (Sehle::IndexBuffer::WRITE);
	Box::generateMesh (mesh->vbuffer->getValuesW (), mesh->vbuffer->stride * sizeof (Sehle::f32),
		mesh->vbuffer->getValuesW () + 3, mesh->vbuffer->stride * sizeof (Sehle::f32),
		mesh->vbuffer->getValuesW () + 6, mesh->vbuffer->stride * sizeof (Sehle::f32),
		&mesh->ibuffer->indices[0], p0, p1, &nvertices, &nindices);
	mesh->vbuffer->unMap ();
	mesh->ibuffer->unMap ();
	mesh->resizeMaterials (1);
	// mesh->setMaterial (0, WireMaterial::newWireMaterial (engine, NULL));
	mesh->setMaterial (0, Sehle::ColorMaterial::newColorMaterial (mesh->graph->engine, NULL));
	mesh->resizeFragments (1);
	mesh->frags[0].first = 0;
	mesh->frags[0].nindices = nindices;
	mesh->frags[0].matidx = 0;

	return mesh;
}

void
AreaLight::hide (Sehle::RenderableGroup *pgroup)
{
	graph->deleteSpotLights ((Sehle::SpotLight *) sehlelights);
	sehlelights = NULL;

	Item::hide (pgroup);
}

Item *
AreaLight::trace (const Elea::Line3f *wray, unsigned int mask, float *distance)
{
	Elea::Cuboid3f q(-size[Elea::X] / 2, -size[Elea::Y] / 2, 0, size[Elea::X] / 2, size[Elea::Y] / 2, 0.1f);
	Elea::Line3f rl = _w2i.transform (*wray);

	// i2w.transformInPlace (bbox);
	float p0, p1;
	if (q.getIntersection (rl, p0, p1) && (p0 > 0)) {
		*distance = p0;
		return this;
	}

	return NULL;
}

void
AreaLight::updateSehleLights (void)
{
	int nsublights = samples[Elea::X] * samples[Elea::Y];
	if (!sehlelights) {
		sehlelights = graph->newSpotLights (nsublights + 1, 0);
	}
	// Opaque lights
	for (int y = 0; y < samples[Elea::Y]; y++) {
		for (int x = 0; x < samples[Elea::X]; x++) {
			Sehle::SpotLight *spot = (Sehle::SpotLight *) sehlelights + y * samples[Elea::X] + x;
			spot->vertices = vertices;
			spot->nindices = nindices;
			spot->indices = indices;
			spot->l2w.translateObjectSelf (Elea::Vector3f((x + 1) * size[Elea::X] / (samples[Elea::X] + 1) - size[Elea::X] / 2, (y + 1) * size[Elea::Y] / (samples[Elea::Y] + 1) - size[Elea::Y] / 2, -0.05f));
			// spot->l2w.translateObjectSelf (Elea::Vector3f(x, y, 0));
			spot->decayExponent = decayExponent;
			spot->cutoffAngle = cutoffAngle;
			spot->constantAttenuation = constantAttenuation;
			spot->linearAttenuation = linearAttenuation;
			spot->quadraticAttenuation = quadraticAttenuation;
			// We have to set parameters here because Light only sets single sehlelight
			spot->hasshadow = 1;
			spot->hasdensity = 1;
			spot->highlightmask = OPAQUE;
			spot->shadowmask = SHADOW | DENSITY;
			spot->shadowProjection = shadowprojection;
			spot->l2w = _i2w;
			spot->ambient = ambient;
			spot->diffuse = diffuse;
			spot->direct = direct;
			for (int i = 0; i < 3; i++) {
				spot->ambient[i] /= nsublights;
				spot->diffuse[i] /= nsublights;
				spot->direct[i] /= nsublights;
			}
		}
	}
	// Transparent light
	Sehle::SpotLight *spot = (Sehle::SpotLight *) sehlelights + nsublights;
	spot->vertices = vertices;
	spot->nindices = nindices;
	spot->indices = indices;
	spot->decayExponent = decayExponent;
	spot->cutoffAngle = cutoffAngle;
	spot->constantAttenuation = constantAttenuation;
	spot->linearAttenuation = linearAttenuation;
	spot->quadraticAttenuation = quadraticAttenuation;
	spot->hasshadow = 1;
	spot->hasdensity = 1;
	spot->highlightmask = TRANSPARENT;
	spot->shadowmask = SHADOW | DENSITY;
	spot->shadowProjection = shadowprojection;
	spot->l2w = _i2w;
	// We have to set colors here because Light only sets single sehlelight
	spot->ambient = ambient;
	spot->diffuse = diffuse;
	spot->direct = direct;
}

void
AreaLight::updateVolume (void)
{
	// I0 = cosAngle ** spotExponent
	float maxangle = cutoffAngle;
	if (decayExponent > 1) {
		// Find cosAngle where I0 == 0.001
		double cosAngle = exp (log (0.001) / decayExponent);
		if (cosAngle > -1) {
			double angle = acos (cosAngle);
			if (angle < maxangle) maxangle = (float) angle;
		}
	}
	// I1 = 1 / (constAtt + linAtt * d + quadAtt * d * d)
	float maxdist = cutoffDistance;
	// maxdist = 20;
	if ((quadraticAttenuation >= 0) && ((linearAttenuation > 0) || (quadraticAttenuation > 0))) {
		// Find distance where I1 == 0.001
		// constAtt + linAtt * d + quadAtt * d * d = 1000
		double a = quadraticAttenuation;
		double b = linearAttenuation;
		double c = constantAttenuation - 1000;
		double q = b * b - 4 * a * c;
		if (q >= 0) {
			double distance = (-b + sqrt (q)) / (2 * a);
			if (distance < maxdist) maxdist = (float) distance;
		}
	}
	float l0 = -maxdist;
	float l1 = -maxdist * cos (maxangle);
	float h = maxdist * sin (maxangle) / cos (Elea::M_2PI_F / 12);

	if (!vertices) vertices = (Elea::Vector3f *) malloc (14 * sizeof (Elea::Vector3f));
	nindices = 24 * 3;
	if (!indices) indices = (u32 *) malloc (nindices * sizeof (u32));
	vertices[0].set (0, 0, l0);
	for (int i = 0; i < 6; i++) {
		float x = h * sin (i * Elea::M_2PI_F / 6);
		float y = h * cos (i * Elea::M_2PI_F / 6);
		vertices[1 + i].set (x, y, l0);
		vertices[1 + 6 + i].set (x, y, l1);
	}
	vertices[13].set (0, 0, 0);
	for (int i = 0; i < 6; i++) {
		indices[3 * i + 0] = 0;
		indices[3 * i + 1] = 1 + (i + 1) % 6;
		indices[3 * i + 2] = 1 + i;

		indices[18 + 3 * i + 0] = 1 + 0 + i;
		indices[18 + 3 * i + 1] = 1 + 0 + (i + 1) % 6;
		indices[18 + 3 * i + 2] = 1 + 6 + i;

		indices[36 + 3 * i + 0] = 1 + 0 + (i + 1) % 6;
		indices[36 + 3 * i + 1] = 1 + 6 + (i + 1) % 6;
		indices[36 + 3 * i + 2] = 1 + 6 + i;

		indices[54 + 3 * i + 0] = 13;
		indices[54 + 3 * i + 1] = 1 + 6 + i;
		indices[54 + 3 * i + 2] = 1 + 6 + (i + 1) % 6;
	}

	// fixme: Think how to handle shadowprojection (Lauris)
	shadowprojection = Elea::Matrix4x4f::frustum (0.1f * 2 * tan (maxangle), 1, 0.1f, maxdist);
}

// dayLight

DayLight::DayLight (void)
: shadowprojection(Elea::Matrix4x4f::frustum (0.1f, 1, 0.1f, 1000)),
azimuth(0), altitude(0.5f), airmass(1), latitude(58), timeOfYear(162), timeOfDay(43200), xAzimuth(0), nsamples(1)
{
}

DayLight::~DayLight (void)
{
}

static Object *
daylight_factory (void)
{
	return new DayLight();
}

const Object::Type *
DayLight::objectType (void)
{
	return type ();
}

const Object::Type *
DayLight::type (void)
{
	static Type *mytype = NULL;
	static const Attribute attrs[] = {
		{ "latitude", "58", 0 },
		{ "timeOfYear", "162", 0 },
		{ "timeOfDay", "43200", 0 },
		{ "xAzimuth", "0", 0 },
		{ "samples", "1", 0 }
	};
	if (!mytype) mytype = new Type(Light::type (), "DayLight", "dayLight", daylight_factory, sizeof (attrs) / sizeof (attrs[0]), attrs);
	return mytype;
}

void
DayLight::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	Light::build (pnode, doc, ctx);

	buildAllAttributes (type (), ctx);

}

void
DayLight::set (const char *attrid, const char *val)
{
	if (!strcmp (attrid, "latitude")) {
		if (!XML::parseNumber (&latitude, val)) latitude = 58;
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "timeOfYear")) {
		if (!XML::parseNumber (&timeOfYear, val)) timeOfYear = 162;
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "timeOfDay")) {
		if (!XML::parseNumber (&timeOfDay, val)) timeOfDay = 1;
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "xAzimuth")) {
		if (!XML::parseNumber (&xAzimuth, val)) xAzimuth = 1;
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "samples")) {
		if (!XML::parseInteger (&nsamples, val)) nsamples = 1;
		if (nsamples < 1) nsamples = 1;
		if (nsamples > 10) nsamples = 10;
		if (sehlelights) {
			graph->deleteSpotLights ((Sehle::SpotLight *) sehlelights);
			sehlelights = NULL;
		}
		requestUpdate (MODIFIED);
	} else {
		Light::set (attrid, val);
	}
}

void
DayLight::update (UpdateCtx *ctx, unsigned int flags)
{
	Elea::Cuboid3f q(-0.5f, -0.5f, -0.5f, 0.5f, 0.5f, 0.5f);
	bbox.set (ctx->i2w.transform (q));

	// Calculate the coordinates of Sun
	// http://www.astro.uio.no/~bgranslo/aares/calculate.html
	// Number of days since 01/01/2000
	// d0 = 367Y - INT{(7/4)[Y+INT((M+9)/12)]} + INT(275M/9) + D -730531.5  [1]
	float d0 = timeOfYear;
	// Number of Julian centuries since 01/01/2000
	float T0 = d0 / 36525;
	// Sidereal time at Greenwich at 00/00 midnight
	float S0_hours = 6.6974f + 2400.0513f * T0;
	S0_hours = fmod (S0_hours, 24);
	// Sidereal time at Greenwich at given universal time
	float SG_hours = S0_hours + (366.2422f / 365.2422f) * (timeOfDay / 3600);
	SG_hours = fmod (SG_hours, 24);
	// Sidereal time at longitude
	float S_hours = SG_hours + 0;
	float S = S_hours * 360 / 24;
	// Number of days since 01/01/2000
	float d = d0 + timeOfDay / 86400;
	// Number of centuries from 01/01/2000
	float T = d / 36525;
	// Sun longitude in degrees
	float L0 = 280.466f + 36000.770f * T;
	L0 = fmod (L0, 360);
	// Sun anomaly in degrees
	float M0 = 357.529f + 35999.050f * T;
	// Sun center
	float C = (1.915f - 0.005f * T) * sin (M0 * Elea::M_PI_F / 180) + 0.020f * sin (2 * M0 * Elea::M_PI_F / 180);
	// True ecliptical longitude of Sun
	float LS =  L0 + C;
	LS = fmod (LS, 360);
	// The obliquity of ecliptic
	float K = 23.439f - 0.013f * T;
	// The Sun right ascension
	float tanRS = tan (LS * Elea::M_PI_F / 180) * cos (K * Elea::M_PI_F / 180);
	float RS = atan (tanRS) * 180 / Elea::M_PI_F;
	if ((LS > 90) && (LS < 270)) RS += 180;
	// Declination
	float sinDS = sin (RS * Elea::M_PI_F / 180) * sin (K * Elea::M_PI_F / 180);
	float DS = asin (sinDS) * 180 / Elea::M_PI_F;
	// Hour angle
	float H = S - RS;
	fprintf (stderr, "S %g   RS %g    H %g\n", S, RS, H);
	// True altitude
	float sinh = sin (latitude) * sin (DS * Elea::M_PI_F / 180) + cos (latitude) * cos (DS * Elea::M_PI_F / 180) * cos (H * Elea::M_PI_F / 180);
	float h = asin (sinh);
	// Azimuth (eastward from north)
	float y = -sin (H * Elea::M_PI_F / 180);
	float x = tan (DS * Elea::M_PI_F / 180) * cos (latitude) - sin (latitude) * cos (H * Elea::M_PI_F / 180);
	float A = -atan2 (y, x);
	// Air mass
	float X = (sinh > 0) ? 1 / (sinh + 0.025f * exp (-11 * sinh)) : 40;

	azimuth = A;
	altitude = h;
	airmass = X;

	updateVolume ();

	Light::update (ctx, flags);
}

Sehle::Renderable *
DayLight::show (Sehle::Graph *pgraph, Sehle::u32 contextmask)
{
	updateSehleLights ();

	// Create mesh
	Sehle::StaticMesh *mesh = new Sehle::StaticMesh(graph, contextmask);

	static const float radius = 0.1f;

	int nvertices;
	int nindices;
	Sphere::generateMesh (NULL, 0, NULL, 0, NULL, 0, NULL, radius, 3, 1, nvertices, nindices);
	if (!mesh->vbuffer) mesh->vbuffer = mesh->graph->engine->getVertexBuffer (NULL);
	mesh->vbuffer->setUp (nvertices, 8);
	mesh->vbuffer->setOffset (Sehle::VertexBuffer::COORDINATES, 0);
	mesh->vbuffer->setOffset (Sehle::VertexBuffer::NORMALS, 3);
	mesh->vbuffer->setOffset (Sehle::VertexBuffer::TEXCOORDS, 6);
	Sehle::f32 *attributes = mesh->vbuffer->map (Sehle::VertexBuffer::WRITE);
	if (!mesh->ibuffer) mesh->ibuffer = mesh->graph->engine->getIndexBuffer (NULL);
	mesh->ibuffer->resize (nindices);
	Sehle::u32 *indices = mesh->ibuffer->map (Sehle::IndexBuffer::WRITE);
	Sphere::generateMesh (attributes, mesh->vbuffer->stride * sizeof (Sehle::f32),
		attributes + 3, mesh->vbuffer->stride * sizeof (Sehle::f32),
		attributes + 6, mesh->vbuffer->stride * sizeof (Sehle::f32),
		indices, radius, 3, -1, nvertices, nindices);
	mesh->vbuffer->unMap ();
	mesh->ibuffer->unMap ();

	mesh->resizeMaterials (1);
	// mesh->setMaterial (0, WireMaterial::newWireMaterial (engine, NULL));
	mesh->setMaterial (0, Sehle::ColorMaterial::newColorMaterial (mesh->graph->engine, NULL));
	mesh->resizeFragments (1);
	mesh->frags[0].first = 0;
	mesh->frags[0].nindices = nindices;
	mesh->frags[0].matidx = 0;

	return mesh;
}

void
DayLight::hide (Sehle::RenderableGroup *pgroup)
{
	graph->deleteSpotLights ((Sehle::SpotLight *) sehlelights);
	sehlelights = NULL;

	Item::hide (pgroup);
}

Item *
DayLight::trace (const Elea::Line3f *wray, unsigned int mask, float *distance)
{
	Elea::Cuboid3f q(-0.5f, -0.5f, -0.5f, 0.5f, 0.5f, 0.5f);
	Elea::Line3f rl = _w2i.transform (*wray);

	// i2w.transformInPlace (bbox);
	float p0, p1;
	if (q.getIntersection (rl, p0, p1) && (p0 > 0)) {
		*distance = p0;
		return this;
	}

	return NULL;
}

void
DayLight::updateSehleLights (void)
{
	float z = sin(altitude);
	float xy = cos(altitude);
	float x = xy * cos (azimuth - xAzimuth);
	float y = xy * sin (azimuth - xAzimuth);
	Elea::Vector3f p(100 * x, 100 * y, 100 * z);
	Elea::Matrix4x4f l2w = Elea::Matrix4x4f::lookAt (p, Elea::Vector3f0, Elea::Vector3fZ);

	int nsublights = nsamples * nsamples;
	if (!sehlelights) {
		// Create Sehle light block
		sehlelights = graph->newSpotLights (nsublights, 0);
	}

	float q = airmass - 1;
	if (q < 0) q = 0;
	float r = exp (-0.0625f * q);
	float g = exp (-0.125f * q);
	float b = exp (-0.25f * q);
	Elea::Color4f sunlight(r, g, b, 1);
	Elea::Color4f l(0.5f + r / 2, 0.35f + g / 2, 0.2f + b / 2, 1);

	static const float size = 1;
	for (int y = 0; y < nsamples; y++) {
		for (int x = 0; x < nsamples; x++) {
			Sehle::SpotLight *spot = (Sehle::SpotLight *) sehlelights + y * nsamples + x;
			spot->hasshadow = 1;
			spot->hasdensity = 1;
			spot->highlightmask = OPAQUE | TRANSPARENT;
			spot->shadowmask = SHADOW | DENSITY;
			spot->shadowProjection = shadowprojection;
			// We have to set colors here because Light only sets single sehlelight
			spot->ambient = l / (float) nsublights;
			spot->diffuse = sunlight / (float) nsublights;
			spot->direct = direct / (float) nsublights;
			spot->l2w = l2w;
			spot->l2w.translateObjectSelf (Elea::Vector3f((x + 1) * size / (nsamples + 1) - size / 2, (y + 1) * size / (nsamples + 1) - size / 2, 0));
			spot->vertices = vertices;
			spot->nindices = nindices;
			spot->indices = indices;
			spot->decayExponent = 1;
			spot->cutoffAngle = 0.5f;
			spot->constantAttenuation = 1;
			spot->linearAttenuation = 0;
			spot->quadraticAttenuation = 0;
		}
	}
}

void
DayLight::updateVolume (void)
{
	static const float cutoffAngle = 0.5f;
	static const float cutoffDistance = 1000;
	// I0 = cosAngle ** spotExponent
	float maxangle = cutoffAngle;
	// I1 = 1 / (constAtt + linAtt * d + quadAtt * d * d)
	float maxdist = cutoffDistance;
	float l0 = -maxdist;
	float l1 = -maxdist * cos (maxangle);
	float h = maxdist * sin (maxangle) / cos (Elea::M_2PI_F / 12);

	if (!vertices) vertices = (Elea::Vector3f *) malloc (14 * sizeof (Elea::Vector3f));
	nindices = 24 * 3;
	if (!indices) indices = (u32 *) malloc (nindices * sizeof (u32));
	vertices[0].set (0, 0, l0);
	for (int i = 0; i < 6; i++) {
		float x = h * sin (i * Elea::M_2PI_F / 6);
		float y = h * cos (i * Elea::M_2PI_F / 6);
		vertices[1 + i].set (x, y, l0);
		vertices[1 + 6 + i].set (x, y, l1);
	}
	vertices[13].set (0, 0, 0);
	for (int i = 0; i < 6; i++) {
		indices[3 * i + 0] = 0;
		indices[3 * i + 1] = 1 + (i + 1) % 6;
		indices[3 * i + 2] = 1 + i;

		indices[18 + 3 * i + 0] = 1 + 0 + i;
		indices[18 + 3 * i + 1] = 1 + 0 + (i + 1) % 6;
		indices[18 + 3 * i + 2] = 1 + 6 + i;

		indices[36 + 3 * i + 0] = 1 + 0 + (i + 1) % 6;
		indices[36 + 3 * i + 1] = 1 + 6 + (i + 1) % 6;
		indices[36 + 3 * i + 2] = 1 + 6 + i;

		indices[54 + 3 * i + 0] = 13;
		indices[54 + 3 * i + 1] = 1 + 6 + i;
		indices[54 + 3 * i + 2] = 1 + 6 + (i + 1) % 6;
	}

	// fixme: Think how to handle shadowprojection (Lauris)
	shadowprojection = Elea::Matrix4x4f::frustum (0.1f * 2 * tan (maxangle), 1, 0.1f, maxdist);
}

} // Namespace Miletos
