#define __MILETOS_ANIMATION_GRAPH_CPP__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2009
//

#include <malloc.h>

#include "xml/base.h"
#include "figure.h"
#include "animation.h"
#include "walkcycle.h"

#include "animationgraph.h"

namespace Miletos {

namespace Animation {

// Pose

Pose::Pose (void)
: Object(0), sourceid(NULL), sid(NULL), source(NULL), frametime(0)
{
}

static Object *
pose_factory (void)
{
	return new Pose();
}

const Object::Type *
Pose::objectType (void)
{
	return type ();
}

const Object::Type *
Pose::type (void)
{
	static Type *mytype = NULL;
	static const Attribute attrs[] = {
		{ "sid", NULL, 0 },
		{ "source", NULL, 0 },
		{ "frameTime", "0", 0 }
	};
	if (!mytype) mytype = new Type(Object::type (), "Animation:Pose", "animation:pose", pose_factory, sizeof (attrs) / sizeof (attrs[0]), attrs);
	return mytype;
}

void
Pose::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	Object::build (pnode, doc, ctx);

	buildAllAttributes (type (), ctx);
}

void
Pose::release (void)
{
	if (source) {
		source->detach (this);
		source = NULL;
	}
	if (sourceid) {
		document->removeIdentityChangeListener (sourceid, this);
		free (sourceid);
		sourceid = NULL;
	}
	if (sid) {
		free (sid);
		sid = NULL;
	}
	Object::release ();
}

void
Pose::set (const char *attrid, const char *val)
{
	if (!strcmp (attrid, "sid")) {
		if (sid) free (sid);
		sid = (val) ? strdup (val) : NULL;
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "source")) {
		if (source) {
			source->detach (this);
			source = NULL;
		}
		if (sourceid) {
			document->removeIdentityChangeListener (sourceid, this);
			free (sourceid);
			sourceid = NULL;
		}
		if (val && (val[0] == '#') && val[1]) {
			sourceid = strdup (val + 1);
			document->addIdentityChangeListener (sourceid, this);
			Object *object = document->lookupObject (sourceid);
			if (object && object->isType (Source::type ())) {
				source = (Source *) object;
				source->attach (this);
			}
		}
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "frameTime")) {
		if (!XML::parseNumber (&frametime, val)) frametime = 0;
		requestUpdate (MODIFIED);
	}
}

void
Pose::identityAdded (Document *pdocument, const char *identity, Object *object)
{
	assert (!strcmp (identity, sourceid));
	if (source) {
		source->detach (this);
		source = NULL;
	}
	if (object->isType (Source::type ())) {
		source = (Source *) object;
		source->attach (this);
	}
	requestModified (MODIFIED);
}

void
Pose::identityRemoved (Document *pdocument, const char *identity)
{
	assert (!strcmp (identity, sourceid));
	if (source) {
		source->detach (this);
		source = NULL;
	}
	requestModified (MODIFIED);
}

void
Pose::attachedObjectRelease (Object *attached, void *data)
{
	assert (attached == source);
	source->detach (this);
	source = NULL;
	requestUpdate (MODIFIED);
}

void
Pose::attachedObjectModified (Object *attached, unsigned int flags, void *data)
{
	assert (attached == source);
	requestUpdate (MODIFIED);
}

// Transition

Transition::Transition (void)
: Source(0), duration(0)
{
	memset (keyposesids, 0, sizeof (keyposesids));
	memset (keyposes, 0, sizeof (keyposes));
}

static Object *
transition_factory (void)
{
	return new Transition();
}

const Object::Type *
Transition::objectType (void)
{
	return type ();
}

const Object::Type *
Transition::type (void)
{
	static Type *mytype = NULL;
	static const Attribute attrs[] = {
		{ "startPose", NULL, 0 },
		{ "endPose", NULL, 0 },
		{ "duration", 0, 0}
	};
	if (!mytype) mytype = new Type(Source::type (), "Animation:Transition", "animation:transition", transition_factory, sizeof (attrs) / sizeof (attrs[0]), attrs);
	return mytype;
}

void
Transition::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	Source::build (pnode, doc, ctx);

	buildAllAttributes (type (), ctx);
}

void
Transition::release (void)
{
	clear (true, true, true);
	Source::release ();
}

void
Transition::set (const char *attrid, const char *val)
{
	if (!strcmp (attrid, "startPose")) {
		clear (true, true, false);
		if (val) keyposesids[0] = strdup (val);
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "endPose")) {
		clear (true, false, true);
		if (val) keyposesids[1] = strdup (val);
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "duration")) {
		if (!XML::parseNumber (&duration, val)) duration = 0;
		requestUpdate (MODIFIED);
	} else {
		Source::set (attrid, val);
	}
}

void
Transition::attachedObjectRelease (Object *attached, void *data)
{
	for (int i = 0; i < 5; i++) {
		if (keyposes[i] == attached) {
			clear (true, false, false);
			break;
		}
	}
}

void
Transition::attachedObjectModified (Object *attached, unsigned int flags, void *data)
{
	requestUpdate (MODIFIED);
}

void
Transition::attachToGraph (Graph *graph)
{
	clear (true, false, false);
	if (!graph) return;
	if (!keyposesids[0] || !keyposesids[1]) return;
	Pose *start = graph->lookupPose (keyposesids[0]);
	Pose *end = graph->lookupPose (keyposesids[1]);
	if (!start | !end) return;
	if (!start->source || (start->source != end->source)) return;
	if (start->frametime > end->frametime) return;
	keyposes[0] = start;
	keyposes[0]->attach (this);
	keyposes[1] = end;
	keyposes[1]->attach (this);
}

void
Transition::clear (unsigned int poses, unsigned int startsid, unsigned int endsid)
{
	if (poses) {
		for (int i = 0; i < 2; i++) {
			if (keyposes[i]) {
				keyposes[i]->detach (this);
				keyposes[i] = NULL;
			}
		}
	}
	if (startsid && keyposesids[0]) {
		free (keyposesids[0]);
		keyposesids[0] = NULL;
	}
	if (endsid && keyposesids[1]) {
		free (keyposesids[1]);
		keyposesids[1] = NULL;
	}
	requestUpdate (MODIFIED);
}


// Graph

Graph::Graph (void)
: Object(HAS_CHILDREN), nposes(0), poses(NULL), nsources(0), sources(NULL)
{
}

static Object *
graph_factory (void)
{
	return new Graph();
}

const Object::Type *
Graph::objectType (void)
{
	return type ();
}

const Object::Type *
Graph::type (void)
{
	static Type *mytype = NULL;
	if (!mytype) mytype = new Type(Object::type (), "Animation:Graph", "animation:graph", graph_factory, 0, NULL);
	return mytype;
}

void
Graph::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	Object::build (pnode, doc, ctx);

	buildAllAttributes (type (), ctx);

	updateChildData (NULL);
}

void
Graph::release (void)
{
	if (poses) {
		nposes = 0;
		free (poses);
		poses = NULL;
	}
	if (sources) {
		nsources = 0;
		free (sources);
		sources = NULL;
	}

	Object::release ();
}

Object *
Graph::childAdded (Thera::Node *cnode, Thera::Node *rnode)
{
	Object *cobj = Object::childAdded (cnode, rnode);

	updateChildData (NULL);

	return cobj;
}

void
Graph::childRemoved (Thera::Node *cnode, Thera::Node *rnode)
{
	updateChildData (cnode);

	Object::childRemoved (cnode, rnode);
}

void
Graph::update (UpdateCtx *ctx, unsigned int flags)
{
	// Have to track child modification flags
	// fixme: Is it good idea to attach before main update has ran on children?
	for (u32 i = 0; i < nsources; i++) {
		if ((flags & MODIFIED) || sources[i]->modifiedFlagIsSet (MODIFIED)) {
			if (sources[i]->isType (Transition::type ())) {
				((Transition *) sources[i])->attachToGraph (this);
			} else if (sources[i]->isType (WalkCycle::type ())) {
				((WalkCycle *) sources[i])->attachToGraph (this);
			}
		}
	}

	Object::update (ctx, flags);
}

void
Graph::updateChildData (Thera::Node *removed)
{
	nposes = listChildrenOfType (Pose::type (), (Object ***) &poses, removed);
	nsources = listChildrenOfType (Source::type (), (Object ***) &sources, removed);
}

Pose *
Graph::lookupPose (const char *sid)
{
	if (!sid || !*sid) return NULL;
	for (u32 i = 0; i < nposes; i++) {
		if (poses[i]->sid && !strcmp (sid, poses[i]->sid)) return poses[i];
	}
	return NULL;
}

// Controller

Controller::Controller (void)
: Object(0), targetid(NULL), graphid(NULL), animationsid(NULL), target(NULL), graph(NULL), transition(0), transitiontime(0)
{
}

static Object *
controller_factory (void)
{
	return new Controller();
}

const Object::Type *
Controller::objectType (void)
{
	return type ();
}

const Object::Type *
Controller::type (void)
{
	static Type *mytype = NULL;
	static const Attribute attrs[] = {
		{ "target", NULL, 0 },
		{ "graph", NULL, 0 },
		{ "animation", NULL, 0 },
	};
	if (!mytype) mytype = new Type(Object::type (), "Animation:Controller", "animation:controller", controller_factory, sizeof (attrs) / sizeof (attrs[0]), attrs);
	return mytype;
}

void
Controller::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	Object::build (pnode, doc, ctx);

	buildAllAttributes (type (), ctx);

}

void
Controller::release (void)
{
	if (target) {
		target->detach (this);
		target = NULL;
	}
	if (targetid) {
		document->removeIdentityChangeListener (targetid, this);
		free (targetid);
		targetid = NULL;
	}
	if (graph) {
		graph->detach (this);
		graph = NULL;
	}
	if (graphid) {
		document->removeIdentityChangeListener (graphid, this);
		free (graphid);
		graphid = NULL;
	}
	if (animationsid) {
		free (animationsid);
		animationsid = NULL;
	}

	Object::release ();
}

void
Controller::set (const char *attrid, const char *val)
{
	if (!strcmp (attrid, "target")) {
		if (target) {
			target->detach (this);
			target = NULL;
		}
		if (targetid) {
			document->removeIdentityChangeListener (targetid, this);
			free (targetid);
			targetid = NULL;
		}
		if (val && (val[0] == '#') && val[1]) {
			targetid = strdup (val + 1);
			document->addIdentityChangeListener (targetid, this);
			Object *object = document->lookupObject (targetid);
			if (object && object->isType (Figure::type ())) {
				target = (Figure *) object;
				target->attach (this);
			}
		}
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "graph")) {
		if (graph) {
			graph->detach (this);
			graph = NULL;
		}
		if (graphid) {
			document->removeIdentityChangeListener (graphid, this);
			free (graphid);
			graphid = NULL;
		}
		if (val && (val[0] == '#') && val[1]) {
			graphid = strdup (val + 1);
			document->addIdentityChangeListener (graphid, this);
			Object *object = document->lookupObject (graphid);
			if (object && object->isType (Graph::type ())) {
				graph = (Graph *) object;
				graph->attach (this);
			}
		}
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "animation")) {
		if (animationsid) free (animationsid);
		animationsid = (val) ? strdup (val) : NULL;
		requestUpdate (MODIFIED);
	}
}

void
Controller::update (UpdateCtx *ctx, unsigned int flags)
{
	Object::update (ctx, flags);

	// fixme:
	// Think out, how exactly the attaching should be, especially as we need multiple skinanimations
	if (!target) return;
	if (!graph) return;
	if (transition >= graph->nsources) return;
	if (graph->sources[transition]->isType (Transition::type ())) {
		Transition *t = (Transition *) graph->sources[transition];
		if (t->keyposes[0]) {
			if (t->keyposes[0]->source->isType (SkinAnimation::type ())) {
				target->attachAnimation ((SkinAnimation *) t->keyposes[0]->source);
			}
		}
	} else if (graph->sources[transition]->isType (WalkCycle::type ())) {
		WalkCycle *t = (WalkCycle *) graph->sources[transition];
		if (t->keyposes[0]) {
			if (t->keyposes[0]->source->isType (SkinAnimation::type ())) {
				target->attachAnimation ((SkinAnimation *) t->keyposes[0]->source);
			}
		}
	}
}

void
Controller::identityAdded (Document *pdocument, const char *pidentity, Object *pobject)
{
	if (targetid && !strcmp (pidentity, targetid)) {
		if (target) {
			target->detach (this);
			target = NULL;
		}
		if (pobject->isType (Figure::type ())) {
			target = (Figure *) pobject;
			target->attach (this);
		}
	} else if (graphid && !strcmp (pidentity, graphid)) {
		if (graph) {
			graph->detach (this);
			graph = NULL;
		}
		if (pobject->isType (Graph::type ())) {
			graph = (Graph *) pobject;
			graph->attach (this);
		}
	}
	requestModified (MODIFIED);
}

void
Controller::identityRemoved (Document *pdocument, const char *pidentity)
{
	if (targetid && !strcmp (pidentity, targetid)) {
		if (target) {
			target->detach (this);
			target = NULL;
		}
	} else if (graphid && !strcmp (pidentity, graphid)) {
		if (graph) {
			graph->detach (this);
			graph = NULL;
		}
	}
	requestModified (MODIFIED);
}

void
Controller::attachedObjectRelease (Object *attached, void *data)
{
	if (attached == target) {
		target->detach (this);
		target = NULL;
	} else if (attached == graph) {
		graph->detach (this);
		graph = NULL;
	}
	requestUpdate (MODIFIED);
}

void
Controller::attachedObjectModified (Object *attached, unsigned int flags, void *data)
{
	// fixme: I am not exactly sure, if tree modification always sets MODIFIED as well
	// But we want to ignore CHILD and PARENT modified signals to cut potential loops if we are in same hirarchy
	if (flags & MODIFIED) requestUpdate (MODIFIED);
}

void
Controller::setTransitionTime (float time)
{
	transitiontime = time;
	if (!target) return;
	if (!graph) return;
	if (transition >= graph->nsources) return;
	if (graph->sources[transition]->isType (Transition::type ())) {
		Transition *t = (Transition *) graph->sources[transition];
		if (!t->keyposes[0]) return;
		// fixme: This is simply test
		// time = time * t->duration;
		if (t->keyposes[0]->source->isType (SkinAnimation::type ())) {
			target->animate ((SkinAnimation *) t->keyposes[0]->source, t->keyposes[0]->frametime + (t->keyposes[1]->frametime - t->keyposes[0]->frametime) * time);
		}
	} else if (graph->sources[transition]->isType (WalkCycle::type ())) {
		WalkCycle *w = (WalkCycle *) graph->sources[transition];
		if (!w->keyposes[0]) return;
		// fixme: This is simply test
		// time = time * t->duration;
		time = (float) fmod (4 * time, 4);
		int i0 = (int) floor (time);
		int i1 = i0 + 1;
		float s = time - i0;
		if (w->keyposes[0]->source->isType (SkinAnimation::type ())) {
			target->animate ((SkinAnimation *) w->keyposes[0]->source, w->keyposes[i0]->frametime + (w->keyposes[i1]->frametime - w->keyposes[i0]->frametime) * s);
		}
	}
}

} // Namespace Animation

} // Namespace Miletos

