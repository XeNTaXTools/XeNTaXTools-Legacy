#ifndef __MILETOS_IKCHAIN_H__
#define __MILETOS_IKCHAIN_H__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2010
//

#include <miletos/types.h>
#include <miletos/miletos.h>

namespace Miletos {

class Bone;
class Figure;
class Skeleton;

//
// IK chain controller for skeletal meshes
//
// Properties:
// first - first bone to be adjusted
// last - last bone to be adjusted
// end - the bone associated with endpoint (usually the next to last)
// endPosition - the endpoint position on end bone (usually 0)
// targetPosition - the position of target point
//

class IKChain : public Object {
public:
	struct BoneSlot {
		Bone *bone;
		// Rotation space
		Elea::Matrix4x4f r2b;
		// Angles
		float angles[3];
	};
private:
	// Object implementation
	virtual const Type *objectType (void);
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	// The following two update child pointers and emit signals
	virtual void set (const char *attrid, const char *val);
	virtual void write (const char *attrid);
	virtual void update (UpdateCtx *ctx, unsigned int flags);

public:
	// Chain structure is modified
	static const int CHAIN_STRUCTURE_MODIFIED = 64;
	// Local ID
	char *sid;
	// Bones
	char *first;
	char *last;
	char *end;
	Elea::Vector3f endPosition;
	Elea::Vector3f targetPosition;
	unsigned int enabled : 1;

	std::vector<BoneSlot> bones;
	Bone *endbone;

	IKChain (void);
	virtual ~IKChain (void);

	// Type system
	static const Type *type (void);

	// Populate bone list
	void attach (Skeleton *skeleton);

	// Access
	void setTargetPosition (const Elea::Vector3f *pos);
};

} // Namespace Miletos

#endif

