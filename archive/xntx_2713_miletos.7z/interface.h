#ifndef __MILETOS_INTERFACE_H__
#define __MILETOS_INTERFACE_H__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2007
//

#include <elea/vector.h>

#include <miletos/signal.h>

namespace Miletos {

class EventHandler {
public:
	enum Modifiers { NONE, LSHIFT, RSHIFT, LCONTROL, RCONTROL, LALT, RALT, NUM_MODIFIERS };
	enum SpecialKeys { ESC = NUM_MODIFIERS, LEFT, RIGHT, UP, DOWN, PAGE_UP, PAGE_DOWN, HOME, END, SPACE, DEL, NUM_SPECIAL_KEYS };
private:
	// Interface
	virtual bool mouseMove (double x, double y) { return false; }
	virtual bool mouseButtonDown (int button, double x, double y) { return false; }
	virtual bool mouseButtonUp (int button, double x, double y) { return false; }
	virtual bool mouseScroll (double xdir, double ydir, double x, double y) { return false; }
	virtual bool keyPress (int key) { return false; }
	virtual bool keyRelease (int key) { return false; }
	virtual void resize (double width, double height) {}
	virtual void timeStep (double time) {}
protected:
public:
	// Next handler in queue
	EventHandler *next;
	// State data
	double x, y;
	int buttonstate;
	int modifierstate;
	// Constructor
	EventHandler (void);
	// Destructor
	virtual ~EventHandler (void);
	// Signals
	Signals::Signal1<void, EventHandler *> sig_destroy;
	Signals::Signal2<void, EventHandler *, int> sig_grabbed;
	Signals::Signal2<void, EventHandler *, int> sig_dragged;
	Signals::Signal2<void, EventHandler *, int> sig_released;
	Signals::Signal2<void, EventHandler *, int> sig_key_pressed;
	Signals::Signal2<void, EventHandler *, int> sig_key_released;
	Signals::Signal3<void, EventHandler *, float, float> sig_scroll;
	// Access
	bool mouseButtonIsDown (int button) { return (buttonstate & (1 << (button - 1))) != 0; }
	bool modifierIsPressed (int key) { return (modifierstate & (1 << key)) != 0; }
	void setButtonState (int button) { buttonstate |= (1 << (button - 1)); }
	void clearButtonState (int button) { buttonstate &= ~(1 << (button - 1)); }
	void setModifierState (int key) { modifierstate |= (1 << key); }
	void clearModifierState (int key) { modifierstate &= ~(1 << key); }
	// Send events
	bool sendMouseMove (double x, double y);
	bool sendMouseButtonDown (int button, double x, double y);
	bool sendMouseButtonUp (int button, double x, double y);
	bool sendMouseScroll (double xdir, double ydir, double x, double y);
	bool sendKeyPress (int key);
	bool sendKeyRelease (int key);
	void invokeResize (double width, double height);
	void invokeTimeStep (double time);
};

class EventStack {
private:
	EventHandler *handler;
	EventHandler *grabbed;
public:
	// Constructor
	EventStack (void);
	// Destructor
	~EventStack (void);
	// Access
	void pushHandler (EventHandler *phandler);
	void popHandler (void);
	bool sendMouseMove (double x, double y);
	bool sendMouseButtonDown (int button, double x, double y);
	bool sendMouseButtonUp (int button, double x, double y);
	bool sendMouseScroll (double xdir, double ydir, double x, double y);
	bool sendKeyPress (int key);
	bool sendKeyRelease (int key);
	void invokeResize (double width, double height);
	void invokeTimeStep (double time);
	// Helpers
	int getButtonMask (int button) { return 1 << (button - 1); }
};

class TrackBall {
public:
	enum Mode { TRACKBALL, FREEROTATE, ZROTATE, NUM_MODES };
private:
	Mode _mode;
	// The scale of sphere in trackball mode relative to viewport size
	float _rscale;
	// Center position in viewport coordinates
	float _cx, _cy;
	// Actual trackball radius in viewport coordinates
	float _radius;
	// Grab state
	float _grabnx, _grabny;
	Elea::Vector3f _grabisv;
	// Helpers
	Elea::Vector3f getUnitSphereIntersection (float x, float y);
public:
	// State
	Elea::Vector3f axis;
	float angle;
	// Constructor
	TrackBall (Mode pmode) : _mode(pmode), _rscale(1), _cx(0), _cy(0), _radius(1), axis(Elea::Vector3fZ), angle(0) {}
	TrackBall (Mode pmode, float pscale) : _mode(pmode), _rscale(pscale), _cx(0), _cy(0), _radius(1), axis(Elea::Vector3fZ), angle(0) {}
	// Access
	void setMode (Mode pmode);
	void setDimensions (float width, float height);
	void grab (float x, float y);
	void drag (float x, float y);
};

} // Namespace Miletos

#endif
