#ifndef __MILETOS_BVH_H__
#define __MILETOS_BVH_H__

//
// Miletos
//
// Copyright (C) Lauris Kaplinski 2010
//

#include <string>
#include <vector>

#include <miletos/animation.h>

namespace Miletos {

class BVHData {
public:
	enum AnimCodes { XPOSITION, YPOSITION, ZPOSITION, XROTATION, YROTATION, ZROTATION };
private:
	u32 refcount;

	BVHData (const char *url);
	BVHData (const unsigned char *cdata, size_t csize, const char *url);
	~BVHData (void);

	unsigned int parse (const unsigned char *cdata, size_t csize);
	unsigned int parseBone (int parent, const char *name, const unsigned char *cdata, size_t csize, size_t& cpos);
public:
	char *url;

	unsigned int nframes;

	struct Bone {
		std::string name;
		int idx;
		int pidx;
		Elea::Vector3f offset;
		Elea::Vector3f endsite;
		// Channels
		int ncodes;
		AnimCodes codes[6];
	};
	std::vector<Bone> bones;
	std::vector<Orientation> ab2p;

	// Static constructor
	static BVHData *getBVHData (const char *url);
	static BVHData *getBVHData (const unsigned char *cdata, size_t csize, const char *url);

	// Lifecycle
	void ref (void) { refcount += 1; }
	void unRef (void) { refcount -= 1; if (!refcount) delete this; }
};

class BoneAnimationBVH : public Animation::BoneAnimation {
private:
	char *source;

	BVHData *bdata;
	int bidx;

	// Object implementation
	virtual const Type *objectType (void);
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	virtual void set (const char *attrid, const char *val);

	// BoneAnimation implementation
	virtual Elea::Vector3f getPosition (unsigned int frameidx);
	virtual Elea::Quaternionf getQuaternion (unsigned int frameidx);
public:
	BoneAnimationBVH (void);
	virtual ~BoneAnimationBVH (void);

	// Type system
	static const Type *type (void);
};

} // Namespace Miletos

#endif
