#ifndef __MILETOS_MESH_OBJM_H__
#define __MILETOS_MESH_OBJM_H__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2008
//

#include <miletos/types.h>
#include <miletos/uri.h>
#include <miletos/pmesh.h>
#include <miletos/skinnedgeometry.h>
#include <miletos/morph.h>
#include <miletos/animation.h>

namespace Miletos {

struct OBJMData;

class GeometryOBJM : public SkinnedGeometry {
private:
	OBJMData *bdata;
	float scale;

	struct PTexture;
	std::vector<PTexture *> textures;
	struct PMaterial;
	std::vector<PMaterial *> materials;

	// Object implementation
	virtual const Type *objectType (void);
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	virtual void set (const char *attrid, const char *val);
	virtual void update (UpdateCtx *ctx, unsigned int flags);

	// SkinnedGeometry implementation
	virtual Sehle::Material *getMaterial (int matidx, Sehle::Engine *engine);
	virtual TextureInfo *getTextureInfo (unsigned int matidx, unsigned int texidx, unsigned int getimage);
	virtual u32 getMaterialInfo (MaterialInfo *mat, u32 matidx);

	void loadData (void);
protected:
public:
	int nmorphvertices;
	Elea::Vector3f *vmorph;
	Elea::Vector3f *nmorph;

	struct PMorph {
		u32 firstdstvertex;
		u32 firstsrcvertex;
		u32 nvertices;
		u32 ntargets;
	};
	int npmorphs;
	PMorph *pmorphs;

	// Synchronous signal
	Miletos::Signals::Signal1<void, GeometryOBJM *> sig_definition_changed;

	GeometryOBJM (void);
	~GeometryOBJM (void);

	// Type system
	static const Type *type (void);

#if 0
	// Access for exporter
	const char *getMaterialName (int midx);
	const char *getTextureName (int midx);
	bool isColorMaterial (int midx);
	bool isTexturedMaterial (int midx);
	bool getTextureImage (NR::PixBlock& px, int midx);
	Elea::Color4f getMaterialDiffuse (int midx);
#endif

	// Create Morph tree
	void buildMorphs (Thera::Node *parentnode, const char *geometry);
	// Create BoneAnimations
	void buildAnimations (Thera::Node *parentnode, const char *geometry);
};

class MorphTargetOBJM : public MorphTarget {
private:
	char *source;
	int morphidx;
	int targetidx;
	OBJMData *bdata;

	Elea::Vector3f *pvdata;
	Elea::Vector3f *pndata;
	u32 *pindices;

	// Object implementation
	virtual const Type *objectType (void);
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	virtual void set (const char *attrid, const char *val);

	// Helpers
	void updateData (void);
protected:
public:
	MorphTargetOBJM (void);
	virtual ~MorphTargetOBJM (void);

	// Type system
	static const Type *type (void);
};

class BoneAnimationOBJM : public Animation::BoneAnimation {
private:
	char *source;
	int animidx;
	int frameidx;

	OBJMData *bdata;

	f32 *pframetimes;
	Orientation *porientations;

	// Object implementation
	virtual const Type *objectType (void);
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	virtual void set (const char *attrid, const char *val);

	// BoneAnimation implementation
	virtual Elea::Vector3f getPosition (unsigned int frameidx);
	virtual Elea::Quaternionf getQuaternion (unsigned int frameidx);

	// Helpers
	void updateData ();
protected:
public:
	BoneAnimationOBJM (void);
	virtual ~BoneAnimationOBJM (void);

	// Type system
	static const Type *type (void);
};

class KeyFrameAnimationOBJM : public Animation::KeyFrameAnimation {
private:
	char *source;
	int morphidx;

	OBJMData *bdata;

	u32 *pindices;
	f32 *pframetimes;
	Elea::Vector3f *pvdata;
	Elea::Vector3f *pndata;

	// Object implementation
	virtual const Type *objectType (void);
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	virtual void set (const char *attrid, const char *val);

	// Helpers
	void updateData ();
protected:
public:
	// Constructor
	KeyFrameAnimationOBJM (void);
	// Destructor
	~KeyFrameAnimationOBJM (void);

	// Type system
	static const Type *type (void);
};

} // Namespace Miletos

#endif

