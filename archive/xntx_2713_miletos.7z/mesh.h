#ifndef __MILETOS_MESH_H__
#define __MILETOS_MESH_H__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2008
//

#if 0
#include <elea/quaternion.h>

#include <miletos/scene.h>

namespace Miletos {

class SMesh : public Item {
private:
	// Object implementation
	virtual const Type *objectType (void);
	// Item implementation
	virtual Sehle::Renderable *show (Sehle::Graph *graph, Sehle::u32 contextmask);
	virtual Item *trace (const Elea::Line3f *ray, unsigned int mask, float *distance) { return NULL; }
	// Interface
	virtual void buildMesh (Sehle::StaticMesh *mesh) = 0;
protected:
	// Constructor
	SMesh(void) : Item(0) {}
public:
	// Type system
	static const Type *type (void);
};

} // Namespace Miletos
#endif

#endif

