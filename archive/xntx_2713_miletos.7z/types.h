#ifndef __MILETOS_TYPES_H__
#define __MILETOS_TYPES_H__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2008
//

#include <elea/vector.h>
#include <elea/quaternion.h>

namespace Miletos {

// Basic types

typedef char i8;
typedef unsigned char u8;
typedef short i16;
typedef unsigned short u16;
typedef int i32;
typedef unsigned int u32;
typedef float f32;
typedef double f64;

// Orientation
struct Orientation {
	bool set;
	Elea::Vector3f p;
	Elea::Quaternionf q;
	// Constructor
	Orientation (void) : set(false), p(Elea::Vector3f0), q(Elea::Quaternionf0) {}
};

} // Namespace Miletos

#endif

