#ifndef __MILETOS_POSEABLEITEM_H__
#define __MILETOS_POSEABLEITEM_H__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2009
//

#include <miletos/types.h>
#include <miletos/scene.h>

namespace Miletos {

class Bone;

//
// PoseableItem
//
// This is item container that tracks bone movements and transforms all children accordingly
// Extra transform rootbone->skeleton is appended to item transformation before updating children
// By changing item transform, all children can be transformed in world space
// By changing child transform children can be transformed in local space
//
// Parameters:
// anchor - sid of anchor bone of skeleton
//
// MESH_DEFINITION_CHANGED signals that anchor bone sid is modified
//

class PoseableItem : public Item {
private:
	// SID of skeletal bone we are attached to
	char *anchor;

	// Root bone -> Skeleton transformation
	// This is appended to our item transform
	Elea::Matrix4x4f c2o;

	// Object implementation
	virtual const Type *objectType (void);
	virtual Object *childAdded (Thera::Node *cnode, Thera::Node *rnode);
	virtual void childRemoved (Thera::Node *cnode, Thera::Node *rnode);

protected:
	// Object implementation
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	virtual void set (const char *attrid, const char *val);
	virtual void write (const char *attrid);
	virtual void update (UpdateCtx *ctx, unsigned int flags);

	// Item implementation
	virtual Sehle::Renderable *show (Sehle::Graph *graph, Sehle::u32 contextmask);
	virtual void hide (Sehle::RenderableGroup *pgroup);
	virtual Item *trace (const Elea::Line3f *wray, unsigned int mask, float *distance);
	virtual void getC2P (Elea::Matrix4x4f *c2p, Miletos::Item *child);
public:
	// Anchor bone is changed
	static const int MESH_DEFINITION_MODIFIED = 64;

	// Constructor
	PoseableItem (void);
	// Destructor
	~PoseableItem (void);

	// Type system
	static const Type *type (void);

	//
	// Poseable interface
	//
	// Index of parent bone in skeleton bone list
	int skeletonanchoridx;
	// This updates skeleton<->poseable attachment indices
	void updateSkeletonIndices (Skeleton *skeleton);
	void clearSkeletonIndices (void);

	// Set the transformation of anchor bone
	// Matrix has to be normalized
	void setC2O (const Elea::Matrix4x4f& pc2o);
};

} // Namespace Miletos

#endif

