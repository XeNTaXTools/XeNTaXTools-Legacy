#define __MILETOS_SKELETON_CPP__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2008
//

#include <stdlib.h>
#include <stdio.h>

#include "xml/base.h"
#include "ikchain.h"
#include "bone.h"
#include "skinnedgeometry.h"
#include "poseableitem.h"
#include "animation.h"
#include "connect.h"

#include "skeleton.h"

namespace Miletos {

Miletos::Skeleton::Skeleton (void) :
Object(HAS_CHILDREN), nchains(0), chains(NULL)
{
}

Skeleton::~Skeleton (void)
{
	assert (bones.empty ());
}

static Object *
skeleton_factory (void)
{
	return new Skeleton();
}

const Object::Type *
Skeleton::objectType (void)
{
	return type ();
}

const Object::Type *
Skeleton::type (void)
{
	static Type *mytype = NULL;
	if (!mytype) mytype = new Type(Object::type (), "Skeleton", "skeleton", skeleton_factory, 0, NULL);
	return mytype;
}

void
Skeleton::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	Object::build (pnode, doc, ctx);
	updateChildData (NULL);
	requestUpdate (MODIFIED | BONE_STRUCTURE_MODIFIED);
}

void
Skeleton::release (void)
{
	clearBoneLinks ();
	if (chains) {
		nchains = 0;
		free (chains);
		chains = NULL;
	}
	Object::release ();
}

Object *
Skeleton::childAdded (Thera::Node *cnode, Thera::Node *rnode)
{
	clearBoneLinks ();
	Object *child = Object::childAdded (cnode, rnode);
	updateChildData (NULL);
	requestUpdate (MODIFIED | BONE_STRUCTURE_MODIFIED);
	return child;
}

void
Skeleton::childRemoved (Thera::Node *cnode, Thera::Node *rnode)
{
	clearBoneLinks ();
	updateChildData (cnode);
	Object::childRemoved (cnode, rnode);
	requestUpdate (MODIFIED | BONE_STRUCTURE_MODIFIED);
}

void
Skeleton::set (const char *attrid, const char *val)
{
}

void
Skeleton::update (UpdateCtx *ctx, unsigned int flags)
{
	if (flags & BONE_STRUCTURE_MODIFIED) {
		// Create bone list
		assert (bones.empty ());
		for (Object *child = children; child; child = child->next) {
			if (child->isType (Bone::type ())) {
				((Bone *) child)->attachToSkeleton (this);
			}
		}
		// Update lists
		for (u32 i = 0; i < nchains; i++) {
			chains[i]->attach (this);
		}
		// Update poseables
		for (size_t i = 0; i < poseables.size (); i++) {
			poseables[i]->attachSkeleton (this);
		}
		for (size_t i = 0; i < poseableitems.size (); i++) {
			poseableitems[i]->updateSkeletonIndices (this);
		}
	} else {
		// Update modified lists
		for (u32 i = 0; i < nchains; i++) {
			if (chains[i]->updateFlagIsSet (IKChain::CHAIN_STRUCTURE_MODIFIED)) {
				chains[i]->attach (this);
			}
		}
	}
	Object::update (ctx, flags);
}

void
Skeleton::updateChildData (Thera::Node *removed)
{
	nchains = listChildrenOfType (IKChain::type (), (Object ***) &chains, removed);
}

int
Skeleton::lookupBone (const char *sid)
{
	if (!sid) return -1;
	for (size_t i = 0; i < bones.size (); i++) {
		if (bones[i]->sid && !strcmp (sid, bones[i]->sid)) return (int) i;
	}
	return -1;
}

int
Skeleton::lookupIKChain (const char *sid)
{
	if (!sid) return -1;
	for (u32 i = 0; i < nchains; i++) {
		if (chains[i]->sid && !strcmp (sid, chains[i]->sid)) return (int) i;
	}
	return -1;
}

int
Skeleton::getBoneIndex (Bone *bone)
{
	if (!bone) return -1;
	for (size_t i = 0; i < bones.size (); i++) {
		if (bones[i] == bone) return (int) i;
	}
	return -1;
}

int
Skeleton::getBoneParentIndex (Bone *bone)
{
	if (!bone || !bone->parent->isType (Bone::type ())) return -1;
	for (size_t i = 0; i < bones.size (); i++) {
		if (bones[i] == bone->parent) return (int) i;
	}
	return -1;
}

void
Skeleton::clearBoneLinks (void)
{
	for (u32 i = 0; i < nchains; i++) {
		chains[i]->attach (NULL);
	}
	for (Object *child = children; child; child = child->next) {
		if (child->isType (Bone::type ())) {
			((Bone *) child)->detachFromSkeleton (this);
		}
	}
	bones.clear ();
	for (size_t i = 0; i < poseables.size (); i++) {
		poseables[i]->detachSkeleton (this);
		poseables[i]->detach (this);
	}
	poseables.clear ();
	for (size_t i = 0; i < poseableitems.size (); i++) {
		poseableitems[i]->clearSkeletonIndices ();
		poseableitems[i]->detach (this);
	}
	poseableitems.clear ();
}

void
Skeleton::boneTreeModified (void)
{
	clearBoneLinks ();
	requestUpdate (MODIFIED | BONE_STRUCTURE_MODIFIED);
}

int
Skeleton::registerBone (Bone *pbone)
{
	bones.push_back (pbone);
	return (int) bones.size () - 1;
}

void
Skeleton::updateBoneAnimation (Bone *pbone, int pboneidx)
{
	if (pboneidx < 0) return;

	for (size_t i = 0; i < poseables.size (); i++) {
		if (poseables[i]->skeleton2local[pboneidx] >= 0) {
			poseables[i]->setBoneAnimation (poseables[i]->skeleton2local[pboneidx], bones[pboneidx]->ab2p);
		}
		if (pboneidx == poseables[i]->skeletonanchoridx) {
			poseables[i]->setA2M (bones[pboneidx]->getAB2O ());
		}
	}
	for (size_t i = 0; i < poseableitems.size (); i++) {
		if (pboneidx == poseableitems[i]->skeletonanchoridx) {
			poseableitems[i]->setC2O (bones[pboneidx]->getAB2O ());
		}
	}
}

void
Skeleton::attachedObjectRelease (Object *attached, void *data)
{
	for (size_t i = 0; i < poseables.size (); i++) {
		if (poseables[i] == (PoseableGeometry *) attached) {
			poseables[i]->detachSkeleton (this);
			poseables[i]->detach (this);
			poseables.erase (poseables.begin () + i);
			break;
		}
	}
	for (size_t i = 0; i < poseableitems.size (); i++) {
		if (poseableitems[i] == (PoseableItem *) attached) {
			poseableitems[i]->clearSkeletonIndices ();
			poseableitems.erase (poseableitems.begin () + i);
			break;
		}
	}
}

void
Skeleton::attachedObjectModified (Object *attached, unsigned int flags, void *data)
{
	if (flags & PoseableGeometry::MESH_DEFINITION_MODIFIED) {
		if (attached->isType (PoseableGeometry::type ())) {
			((PoseableGeometry *) attached)->attachSkeleton (this);
		} else if (attached->isType (PoseableItem::type ())) {
			((PoseableItem *) attached)->updateSkeletonIndices (this);
		}
	}
}

void
Skeleton::attachOrUpdatePoseable (PoseableGeometry *geometry)
{
	for (size_t i = 0; i < poseables.size (); i++) {
		if (poseables[i] == geometry) {
			geometry->attachSkeleton (this);
			return;
		}
	}
	poseables.push_back (geometry);
	geometry->attach (this);
	geometry->attachSkeleton (this);
}

void
Skeleton::attachOrUpdatePoseable (PoseableItem *item)
{
	for (size_t i = 0; i < poseableitems.size (); i++) {
		if (poseableitems[i] == item) {
			item->updateSkeletonIndices (this);
			return;
		}
	}
	poseableitems.push_back (item);
	item->attach (this);
	item->updateSkeletonIndices (this);
}

void
Skeleton::detachPoseable (PoseableGeometry *geometry)
{
	for (size_t i = 0; i < poseables.size (); i++) {
		if (poseables[i] == geometry) {
			geometry->detachSkeleton (this);
			geometry->detach (this);
			poseables.erase (poseables.begin () + i);
			break;
		}
	}
}

void
Skeleton::detachPoseable (PoseableItem *item)
{
	for (size_t i = 0; i < poseableitems.size (); i++) {
		if (poseableitems[i] == item) {
			item->clearSkeletonIndices ();
			item->detach (this);
			poseableitems.erase (poseableitems.begin () + i);
			break;
		}
	}
}

void
Skeleton::attachAnimation (Animation::SkinAnimation *animation)
{
	if (!animation) {
		skeleton2local.clear ();
		return;
	}
	skeleton2local.resize (animation->nboneanimations);
	for (u32 i = 0; i < animation->nboneanimations; i++) {
		int bidx = lookupBone (animation->boneanimations[i]->bonesid);
		skeleton2local[i] = bidx;
	}
}

void
Skeleton::detachAnimation (Animation::SkinAnimation *animation)
{
	skeleton2local.clear ();
}

void
Skeleton::animate (Animation::SkinAnimation *animation, float time)
{
	if (!animation) return;
	if ((u32) skeleton2local.size () < animation->nboneanimations) return;
	for (u32 j = 0; j < animation->nboneanimations; j++) {
		int bidx = skeleton2local[j];
		if ((bidx < 0) || (bidx >= (int) bones.size ())) continue;
		float frametime = time * (animation->boneanimations[j]->fps / animation->fps);
		Elea::Matrix3x4f ab2p = animation->boneanimations[j]->getAB2P (frametime, Animation::Source::CLAMP);
		bones[bidx]->setAB2P (ab2p);
	}
}

} // Namespace Miletos
