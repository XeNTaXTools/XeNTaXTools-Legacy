#define __MILETOS_FILESYSTEM_CPP__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2007-2008
//

static const int debug = 1;

#ifdef WIN32
#include <io.h>
#else
#include <stdio.h>
#include <sys/types.h>
#include <dirent.h>
#endif

#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <ctype.h>

#include <string>
#include <vector>

#include <libarikkei/utext.h>
#include <libarikkei/arikkei-iolib.h>

#include "zip.h"

#include "filesystem.h"

#ifdef WIN32
#define strdup _strdup
#endif

namespace Miletos {

namespace FileSystem {

char *
canonizeName (const char *name, bool isdirectory, bool makelowercase)
{
	if (!name) return NULL;
	return canonizeName (name, strlen (name), isdirectory, makelowercase);
}

char *
canonizeName (const char *name, size_t len, bool isdirectory, bool makelowercase)
{
	if (!name) return NULL;
	char *cname = (char *) malloc (len + 2);
	int cpos = 0;
	for (size_t i = 0; i < len; i++) {
		if (name[i] == '\\') {
			cname[cpos++] = '/';
		} else {
			cname[cpos++] = tolower (name[i]);
		}
	}
	if (isdirectory && (name[len - 1] != '/')) cname[cpos++] = '/';
	cname[cpos++] = 0;
	return cname;
}

unsigned int
isAbsolutePath (const char *path)
{
	if (!path || !*path) return false;
	if (*path == '/') return true;
#ifdef WIN32
	if (*path && (path[1] == ':')) return true;
#endif
	return false;
}

// Handler

Handler::Handler (const char *name)
: _refcount(1), _name((name) ? strdup (name) : NULL), _valid(false)
{
}

Handler::~Handler (void)
{
	if (_name) free (_name);
}

// HandlerFileList

HandlerFileList::HandlerFileList (const char *name)
: Handler(name), ignorecase(false), currentdir("/"), namedict(97), datadict(97)
{
}

HandlerFileList::~HandlerFileList (void)
{
	for (size_t i = 0; i < entries.size (); i++) {
		if (entries[i]->dataref > 0) free (entries[i]->cdata);
		free (entries[i]->name);
		delete entries[i];
	}
}

HandlerFileList::Entry *
HandlerFileList::getEntry (const char *name)
{
	if (!name || !*name) return false;
	char *cname = getAbsoluteCanonicalName (name, false, ignorecase);
	Entry *entry = namedict.lookup (cname);
	free (cname);
	return entry;
}

bool
HandlerFileList::hasFile (const char *name)
{
	Entry *entry = getEntry (name);
	return entry != NULL;
}

unsigned const char *
HandlerFileList::mmapFile (const char *name, size_t *size)
{
	Entry *entry = getEntry (name);
	if (!entry) return NULL;
	if (entry->cdata) {
		if (entry->dataref) entry->dataref += 1;
	} else {
		addFileMapping (entry);
		if (!entry->cdata) {
			datadict.insert ((const char *) entry->cdata, entry);
		}
	}
	if (!entry->cdata) return NULL;
	if (size) *size = entry->csize;
	return entry->cdata;
}

void
HandlerFileList::munmapFile (const unsigned char *data)
{
	if (!data) return;
	Entry *entry = datadict.lookup ((const char *) data);
	if (!entry) return;
	if (!entry->dataref) return;
	entry->dataref -= 1;
	if (!entry->dataref) {
		entry->csize = NULL;
		entry->cdata = NULL;
		datadict.insert ((const char *) data, NULL);
	}
}

char *
HandlerFileList::getAbsoluteCanonicalName (const char *name, bool isdirectory, bool makelowercase)
{
	char *cname = canonizeName (name, isdirectory, makelowercase);
	if (!strcmp (cname, "./")) {
		free (cname);
		return strdup (currentdir.c_str ());
	} else if (!strcmp (cname, "../")) {
		free (cname);
		char *cdir = strdup (currentdir.c_str ());
		if (!strcmp (cdir, "/")) return cdir;
		int clen = (int) currentdir.size ();
		int cpos = clen - 2;
		while ((cpos >= 0) && (cdir[cpos] != '/')) cpos -= 1;
		if (cpos < 0) return cdir;
		cdir[cpos + 1] = 0;
		return cdir;
	} else if (*cname != '/') {
		// Relative name
		size_t cdirlen = currentdir.size ();
		size_t cnamelen = strlen (cname);
		char *nname = (char *) malloc (cdirlen + cnamelen + 1);
		memcpy (nname, currentdir.c_str (), cdirlen);
		memcpy (nname + cdirlen, cname, cnamelen);
		nname[cdirlen + cnamelen] = 0;
		free (cname);
		return nname;
	}
	// Absolute name
	return cname;
}

// Handler using underlying OS filesystem

class OSHandler : public Handler {
private:
	struct MMapData {
		const unsigned char *_cdata;
		size_t _csize;
	};
	struct FileData {
		std::string _name;
		size_t _size;
	};
	struct DirData {
		bool valid;
		// Absolute OS path (do not end with '/')
		std::string ospath;
		// Relative path (do not end with '/')
		std::string relpath;
		std::vector<std::string> subdirs;
		std::vector<FileData> files;
	};
	std::string _rootpath;
	std::vector<MMapData> _mmaps;
	DirData _currentdir;
	std::string currentdirname;
	// Handler implementation
	virtual bool hasDir (const char *name);
	virtual bool hasFile (const char *name);
	virtual bool loadDir (const char *name);
	virtual const char *getDirName (void);
	virtual int getNumFiles (void);
	virtual const char *getFileName (int idx);
	virtual size_t getFileSize (int idx);
	virtual int getNumSubDirs (void);
	virtual const char *getSubDirName (int idx);
	virtual const unsigned char *mmapFile (const char *name, size_t *size);
	virtual void munmapFile (const unsigned char *data);
	// Helpers
	std::string buildOSPath (const char *name);
	bool hasOSDir (const char *absname);
	bool hasOSFile (const char *absname);
	void readDir (const char *dirname);
public:
	// Constructor
	OSHandler (const char *name, const char *rootpath);
	// Destructor
	~OSHandler (void);
};

OSHandler::OSHandler (const char *name, const char *rootpath)
: Handler (name), _rootpath(rootpath)
{
	_currentdir.valid = false;
#ifdef WIN32
	// Handle absolute path different way
	if (_rootpath == "/") _rootpath = "";
#endif
	readDir (NULL);
	_valid = _currentdir.valid;
}

OSHandler::~OSHandler (void)
{
	for (size_t i = 0; i < _mmaps.size (); i++) {
		arikkei_munmap (_mmaps[i]._cdata, _mmaps[i]._csize);
	}
}

std::string
OSHandler::buildOSPath (const char *relname)
{
	if (!relname || !*relname) {
		if (!_currentdir.valid) {
			return _rootpath;
		} else {
			return _currentdir.ospath;
		}
	}
	bool absolute = *relname == '/';
#ifdef WIN32
	absolute = absolute || strchr (relname, ':');
#endif
	if (absolute) {
		// Absolute path
#ifdef WIN32
		if (!strcmp (relname, "/")) {
			return _rootpath;
		}
		if (_rootpath == "") {
			return std::string(relname);
		} else {
			return _rootpath + relname;
		}
#else
		return _rootpath + relname;
#endif
	} else {
		// Relative path
#ifdef WIN32
		if (_currentdir.valid) {
			if (_currentdir.ospath == "") {
				return relname;
			} else {
				return _currentdir.ospath + "/" + relname;
			}
		} else {
			if (_rootpath == "") {
				return std::string(relname);
			} else {
				return _rootpath + "/" + relname;
			}
		}
#else
		if (_currentdir.valid) {
			return _currentdir.ospath + "/" + relname;
		} else {
			return _rootpath + "/" + relname;
		}
#endif
	}
}

bool
OSHandler::hasOSDir (const char *abspath)
{
#ifdef WIN32
	struct _stat st;
	if (_wstat (Arikkei::UText(abspath), &st)) return false;
	if (st.st_mode & _S_IFDIR) return true;
	return false;
#else
	struct stat st;
	if (stat (abspath, &st)) return false;
	if (S_ISDIR (st.st_mode)) return true;
	return false;
#endif
}

bool
OSHandler::hasOSFile (const char *abspath)
{
#ifdef WIN32
	struct _stat st;
	if (_wstat (Arikkei::UText(abspath), &st)) return false;
	if (st.st_mode & _S_IFDIR) return false;
	return true;
#else
	struct stat st;
	if (stat (abspath, &st)) return false;
	if (S_ISREG (st.st_mode)) return true;
	return false;
#endif
}

void
OSHandler::readDir (const char *relpath)
{
	if (!relpath) relpath = "";
	std::string abspath = buildOSPath (relpath);
	if (!hasOSDir (abspath.c_str ())) {
		_currentdir.valid = false;
		return;
	}
	_currentdir.valid = true;
	_currentdir.ospath = abspath;
	_currentdir.relpath = relpath;
	_currentdir.subdirs.clear ();
	_currentdir.files.clear ();

	currentdirname = _currentdir.relpath + "/";

#ifdef WIN32
	std::string search = abspath + "/*";
	_wfinddata_t finddata;
	intptr_t handle;
	handle = _wfindfirst (Arikkei::UText(search.c_str ()), &finddata);
	if (handle != (intptr_t) -1) {
		do {
			if (finddata.attrib & _A_SUBDIR) {
				_currentdir.subdirs.push_back ((const char *) Arikkei::UText(finddata.name));
			} else {
				FileData fd;
				fd._name = (const char *) Arikkei::UText(finddata.name);
				fd._size = finddata.size;
				_currentdir.files.push_back (fd);
			}
		} while (_wfindnext (handle, &finddata) == 0);
		_findclose (handle);
	}
#else
	std::string base = abspath + "/";
	size_t plen = base.length ();
	DIR *dir = opendir (abspath.c_str ());
	struct dirent *dentry = readdir (dir);
	while (dentry) {
		size_t elen = strlen (dentry->d_name);
		char *path = (char *) malloc (plen + elen + 1);
		memcpy (path, base.c_str (), plen);
		memcpy (path + plen, dentry->d_name, elen);
		path[plen + elen] = 0;
		struct stat st;
		if (!stat (path, &st)) {
			if (st.st_mode & S_IFDIR) {
				_currentdir.subdirs.push_back (dentry->d_name);
			} else if (st.st_mode & S_IFREG) {
				FileData fd;
				fd._name = dentry->d_name;
				// fixme: We stat zero-sized files continuously
				fd._size = 0;
				_currentdir.files.push_back (fd);
			}
		}
		free (path);
		// if (dentry->d_type == DT_DIR) {
		//	_currentdir.subdirs.push_back (dentry->d_name);
		// } else if (dentry->d_type == DT_REG) {
		//	FileData fd;
		//	fd._name = dentry->d_name;
		//	// fixme: We stat zero-sized files continuously
		//	fd._size = 0;
		// 	_currentdir.files.push_back (fd);
		// }
		dentry = readdir (dir);
	}
	closedir (dir);
#endif
}

bool
OSHandler::hasDir (const char *name)
{
	std::string abspath = buildOSPath (name);
	return hasOSDir (abspath.c_str ());
}

bool
OSHandler::hasFile (const char *name)
{
	std::string abspath = buildOSPath (name);
	return hasOSFile (abspath.c_str ());
}

const char *
OSHandler::getDirName (void)
{
	if (!_currentdir.valid) return NULL;
	return currentdirname.c_str ();
}

bool
OSHandler::loadDir (const char *name)
{
	readDir (name);
	return _currentdir.valid;
}

int
OSHandler::getNumFiles (void)
{
	if (!_currentdir.valid) return 0;
	return (int) _currentdir.files.size ();
}

const char *
OSHandler::getFileName (int idx)
{
	return _currentdir.files[idx]._name.c_str ();
}

size_t
OSHandler::getFileSize (int idx)
{
#ifndef WIN32
	if (_currentdir.files[idx]._size == 0) {
		std::string abspath = buildOSPath (_currentdir.files[idx]._name.c_str ());
		struct stat st;
		if (stat (abspath.c_str (), &st)) return 0;
		if (!S_ISREG (st.st_mode)) return 0;
		_currentdir.files[idx]._size = st.st_size;
	}
#endif
	return _currentdir.files[idx]._size;

}

int
OSHandler::getNumSubDirs (void)
{
	if (!_currentdir.valid) return 0;
	return (int) _currentdir.subdirs.size ();
}

const char *
OSHandler::getSubDirName (int idx)
{
	return _currentdir.subdirs[idx].c_str ();
}

const unsigned char *
OSHandler::mmapFile (const char *name, size_t *size)
{
	if (!hasFile (name)) return NULL;
	std::string abspath = buildOSPath (name);
	MMapData mmd;
	mmd._cdata = arikkei_mmap ((const unsigned char *) abspath.c_str (), &mmd._csize, NULL);
	if (mmd._cdata) {
		_mmaps.push_back (mmd);
		*size = mmd._csize;
		return mmd._cdata;
	}
	return NULL;
}

void
OSHandler::munmapFile (const unsigned char *data)
{
	for (size_t i = 0; i < _mmaps.size (); i++) {
		if (_mmaps[i]._cdata == data) {
			arikkei_munmap (_mmaps[i]._cdata, _mmaps[i]._csize);
			_mmaps.erase (_mmaps.begin () + i);
			break;
		}
	}
}

// URLHandler

URLHandler::URLHandler (const char *location)
: URI::URLHandler(location)
{
	// syntax: file:path/
	char *ploc = strdup (location + 5);
	handler = newDirectoryHandler (ploc);
	free (ploc);
}

URLHandler::~URLHandler (void)
{
	handler->unRef ();
}

URI::URLHandler *
URLHandler::newURLHandler (const char *url)
{
	// syntax: file:path/
	if (!url || !*url) return NULL;
	if (strncmp (url, "file:", 5)) return NULL;
	char *purl = strdup (url);
	char *pq = strrchr (purl, '/');
	if (pq) {
		*(pq + 1) = 0;
	} else {
		*(purl + 5) = 0;
	}
	return new URLHandler(purl);
}

const unsigned char *
URLHandler::mmapDataRelative (const char *name, size_t *size)
{
	if (!name || !*name) return NULL;
	const unsigned char *data = handler->mmapFile (name, size);
	return data;
}

void
URLHandler::munmapData (const unsigned char *data)
{
	// XPP data is owned by FileHandler
}

// Filesystem

struct FileMapping {
	Handler *_handler;
	const unsigned char *_cdata;
	size_t _csize;
};

std::vector<Handler *> _handlers;
std::vector<FileMapping> _mappings;

static void
ensureInitialized (void)
{
	static bool initialized = false;
	if (!initialized) {
#ifdef WIN32
		wchar_t cpath[_MAX_PATH];
		_wgetcwd (cpath, _MAX_PATH);
		char *ucpath = (char *) arikkei_ucs2_utf8_strdup (cpath);
		char *cpos = strchr (ucpath, ':');
		if (!cpos) {
			cpos = ucpath;
		} else {
			cpos += 1;
		}
		Handler *handler = new OSHandler(NULL, "/");
		handler->loadDir (cpos);
		free (ucpath);
		_handlers.push_back (handler);
#else
		char *cwd = getcwd (NULL, 0);
		Handler *handler = new OSHandler(NULL, "/");
		handler->loadDir (cwd);
		free (cwd);
		_handlers.push_back (handler);
#endif
		initialized = true;
	}
}

void
addHandler (const char *id, Handler *handler)
{
	_handlers.push_back (handler);
}

void
addDirectoryHandler (const char *id, const char *basedir)
{
	ensureInitialized ();
	OSHandler *oh = new OSHandler(id, basedir);
	if (oh->isValid ()) {
		_handlers.push_back (oh);
	} else {
		fprintf (stderr, "OSHandler %s not valid - NOT ADDED\n", basedir);
		delete oh;
	}
}

void
AddZipHandler (const char *id, const char *zipfilename)
{
	ensureInitialized ();
	Zip::FileHandler *zh = new Zip::FileHandler(zipfilename);
	if (zh->isValid ()) {
		_handlers.push_back (zh);
	} else {
		fprintf (stderr, "ZipHandler %s not valid - NOT ADDED\n", zipfilename);
		delete zh;
	}
}

void
removeHandler (const char *id)
{
	ensureInitialized ();
	for (size_t i = 0; i < _handlers.size (); i++) {
		const char *name = _handlers[i]->getName ();
		if (name && !strcmp (name, id)) {
			_handlers[i]->unRef ();
			_handlers.erase (_handlers.begin () + i);
			return;
		}
	}
}

unsigned const char *
mmapFile (const char *name, size_t *size)
{
	if (!name || !*name) return NULL;
	ensureInitialized ();
	for (int i = (int) _handlers.size () - 1; i >= 0 ; i--) {
		size_t csize;
		const unsigned char *cdata = _handlers[i]->mmapFile (name, &csize);
		if (cdata) {
			FileMapping fm;
			_handlers[i]->ref ();
			fm._handler = _handlers[i];
			fm._cdata = cdata;
			fm._csize = csize;
			_mappings.push_back (fm);
			*size = csize;
			return cdata;
		}
	}
	return NULL;
}

void
munmapFile (const unsigned char *data)
{
	if (!data) return;
	ensureInitialized ();
	for (size_t i = 0; i < _mappings.size (); i++) {
		if (_mappings[i]._cdata == data) {
			_mappings[i]._handler->munmapFile (_mappings[i]._cdata);
			_mappings[i]._handler->unRef ();
			_mappings.erase (_mappings.begin () + i);
			break;
		}
	}
}

bool
hasFile (const char *name)
{
	if (!name || !*name) return false;
	ensureInitialized ();
	for (int i = (int) _handlers.size () - 1; i >= 0 ; i--) {
		if (_handlers[i]->hasFile (name)) return true;
	}
	return false;
}

Handler *
newDirectoryHandler (const char *dirname)
{
	OSHandler *oh = new OSHandler(NULL, dirname);

	return oh;
}

} // Namespace FileSystem

} // Namespace Miletos

