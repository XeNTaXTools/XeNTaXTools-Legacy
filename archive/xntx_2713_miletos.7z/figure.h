#ifndef __MILETOS_FIGURE_H__
#define __MILETOS_FIGURE_H__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2009
//

#include <miletos/types.h>
#include <miletos/scene.h>

namespace Miletos {

class PoseableGeometry;
class Skeleton;
class Bone;

namespace Animation {
	class SkinAnimation;
}

class Figure : public Item {
private:
	// Object implementation
	virtual const Type *objectType (void);
	virtual Object *childAdded (Thera::Node *cnode, Thera::Node *rnode);
	virtual void childRemoved (Thera::Node *cnode, Thera::Node *rnode);

	// Helpers
	// Reparses children (currently only updates skeleton)
	void updateChildData (Thera::Node *removed);
	// Detaches all poseablegeometries from skeleton
	void clearSkeletonLinks (void);
	// Attaches all poseablegeometries to skeleton
	void updateSkeletonLinks (void);
protected:
	// Object implementation
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	virtual void set (const char *attrid, const char *val);
	virtual void write (const char *attrid);
	virtual void update (UpdateCtx *ctx, unsigned int flags);
	// Item implementation
	virtual Sehle::Renderable *show (Sehle::Graph *graph, Sehle::u32 contextmask);
	virtual void hide (Sehle::RenderableGroup *pgroup);
	virtual Item *trace (const Elea::Line3f *wray, unsigned int mask, float *distance);
	virtual Item *trace (const Elea::Line3f *wray, unsigned int mask, const Elea::Matrix4x4f *e2us, float *distance, Elea::Vector3f *uscp);
public:
	Skeleton *skeleton;

	Figure (void);

	// Type system
	static const Type *type (void);

	//
	// Animatable interface
	//
	// These simply attach skinanimation to all animatable children (skeleton, poseablegeometries...)
	void attachAnimation (Animation::SkinAnimation *animation);
	void detachAnimation (Animation::SkinAnimation *animation);
	// fixme: This is still wrong as we can interpolate between different skinanimation objects
	void animate (Animation::SkinAnimation *animation, float time);
};

} // Namespace Miletos

#endif

