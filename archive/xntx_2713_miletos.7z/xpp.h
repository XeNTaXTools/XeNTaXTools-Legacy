#ifndef __MILETOS_XPP_H__
#define __MILETOS_XPP_H__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2007-2009
//

#include <stdio.h>

#include <string>
#include <vector>
#include <map>

#include <miletos/types.h>
#include <miletos/filesystem.h>
#include <miletos/uri.h>

namespace Miletos {

namespace Xpp {

// Known file formats
enum Type { UNKNOWN,
	DIGITAL_GIRL,
	SB3,
	AG3,
	SCHOOLMATE,
	SCHOOLMATE_SWEETS,
	HAKO,
	AT_HOME,
	YUUSHA,
	RGF,
	SM_FIGURE, SM_TRIAL, AG3_WELCOME, HAKO_TRIAL, ESK_MATE, AT_HOME_FIGURE, AT_HOME_TRIAL,
	MIK_TRIAL,
	SBZ,
	CCB,
	NUM_TYPES };

struct Format {
	enum Encryption { UNKNOWN_ENCRYPTION, XOR_32, XOR_PLUS_1, TWO_CIPHER };

	Type type;
	const char *description;
	const char *id;
	unsigned char signature;
	Encryption encryption;
	const void *cipher;
};

const Format *getFormat (Type type);

const Format *testFormat (FILE *ifs, size_t fsize, const Type searchorder[]);
const Format *testFormat (FILE *ifs, size_t fsize);

bool isFormat (FILE *ifs, size_t fsize, const Format *format);

// Helpers
inline i16 getI16LE (const unsigned char *c) { return (i16) c[0] | ((u16) c[1] << 8); }
inline u16 getU16LE (const unsigned char *c) { return (u16) c[0] | ((u16) c[1] << 8); }
inline i32 getI32LE (const unsigned char *c) { return (i32) c[0] | ((u32) c[1] << 8) | ((u32) c[2] << 16) | ((u32) c[3] << 24); }
inline u32 getU32LE (const unsigned char *c) { return (u32) c[0] | ((u32) c[1] << 8) | ((u32) c[2] << 16) | ((u32) c[3] << 24); }
inline f32 getF32LE (const unsigned char *c) { return *((const float *) c); }

class FileData {
private:
	unsigned int valid;
	std::string path;

	const Format *format;

	struct FileEntry {
		// u32 tag;
		std::string name;
		size_t start;
		size_t length;
	};
	std::vector<FileEntry> entries;
	std::map<std::string, int> map;

	// Helpers
	void readTable (FILE *ifs, size_t fsize, const char *fid);
	int decodeBlock (unsigned char *d, const unsigned char *s, int len);
	// Static helpers
	// static int decryptHeaderOther (unsigned char *d, const unsigned char *s, int len);
	static int decodeBlockTwoChipher (unsigned char *d, const unsigned char *s, int len, const u16 *cipher);
	static int decodeBlockXOR32 (unsigned char *d, const unsigned char *s, int len, const u8 *cipher);
	static int decodeBlockXORPlus1 (unsigned char *d, const unsigned char *s, int len);
	static const char *getNameStatic (const unsigned char *cdata);
	static const char *getNameStaticSB3 (const unsigned char *cdata, int maxlen);
public:
	// Constructor
	FileData (const char *path, const char *formatid);

	// Access
	bool isValid (void) const { return valid != 0; }
	int getNumFiles (void) { return (int) entries.size (); }
	const char *getFileName (int idx);
	size_t getFileSize (int idx);
	unsigned char *getFileData (int idx, size_t *size);
	int lookupFileIdx (const char *name) { if (map.find (name) == map.end ()) return -1; return map[std::string(name)]; }
};

class FileHandler : public FileSystem::HandlerFileList {
private:
	FileData data;

	// Handler implementation
	// Test whether current handler has dir (relative to root)
	virtual bool hasDir (const char *name);

	// Set current reading directory to given value (or unset if there is no such dir)
	virtual bool loadDir (const char *name);
	// Return the number of files in reading dir
	virtual int getNumFiles (void);
	// Return the name of file in reading dir
	virtual const char *getFileName (int idx);
	// Return the size of file in reading dir
	virtual size_t getFileSize (int idx);
	// Return the number of subdirectories in reading dir
	virtual int getNumSubDirs (void);
	// Return the name of subdirectory in reading dir
	virtual const char *getSubDirName (int idx);

	// HandlerFileList implementation
	virtual void addFileMapping (Entry *entry);
public:
	// Constructor
	FileHandler (const char *filename, const char *fid);
};

class URLHandler : public URI::URLHandler {
private:
	std::vector<FileSystem::Handler *> handlers;

	URLHandler (const char *location);
	virtual ~URLHandler (void);

	// URLHandler implementation
	virtual const unsigned char *mmapDataRelative (const char *name, size_t *size);
	virtual void munmapData (const unsigned char *data);
public:
	// Static constructor
	static URI::URLHandler *newURLHandler (const char *url);
};

}; // Namespace Xpp

}; // Namespace Miletos

#endif
