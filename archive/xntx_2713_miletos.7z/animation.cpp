#define __MILETOS_ANIMATION_CPP__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2009
//

static const int debug = 0;

#include <malloc.h>
#include <stdlib.h>
#include <stdio.h>

#include "xml/base.h"

#include "figure.h"
#include "skinnedgeometry.h"
#include "skeleton.h"
#include "bone.h"

#include "animation.h"

namespace Miletos {

namespace Animation {

Source::Source (u32 flags)
: Object(flags), sid(NULL), fps(1), minframetime(0), maxframetime(0)
{
}

Source::~Source (void)
{
	if (sid) free (sid);
}

const Object::Type *
Source::objectType (void)
{
	return type ();
}

const Object::Type *
Source::type (void)
{
	static Type *mytype = NULL;
	static const Attribute attrs[] = {
		{ "sid", NULL, 0 }
	};
	if (!mytype) mytype = new Type(Object::type (), "Animation:Source", NULL, NULL, sizeof (attrs) / sizeof (attrs[0]), attrs);
	return mytype;
}

void
Source::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	Object::build (pnode, doc, ctx);

	buildAllAttributes (type (), ctx);

}

void
Source::set (const char *attrid, const char *val)
{
	if (!strcmp (attrid, "sid")) {
		if (sid) free (sid);
		sid = (val) ? strdup (val) : NULL;
		requestUpdate (MODIFIED);
	}
}

void
Source::write (const char *attrid)
{
	if (!strcmp (attrid, "sid")) {
		node->setAttribute (attrid, sid);
	} else {
		Object::write (attrid);
	}
}

float
Source::normalize (float frametime, float minframetime, float maxframetime, unsigned int repeattype)
{
	float interval = maxframetime - minframetime;
	if (interval <= 0) return minframetime;
	frametime -= minframetime;
	if (repeattype == CLAMP) {
		if (frametime < 0) frametime = 0;
		if (frametime > interval) frametime = interval;
	} else if (repeattype == REPEAT) {
		frametime = fmod (frametime, interval);
		if (frametime < 0) frametime += interval;
	} else {
		if (frametime < 0) frametime = -frametime;
		frametime = fmod (frametime, interval);
	}
	frametime += minframetime;
	return frametime;
}

BoneAnimation::BoneAnimation (u32 flags)
: Source(flags), enabled(1), bonesid(NULL), nframes(0), frametimes(NULL)
{
}

BoneAnimation::~BoneAnimation (void)
{
	clear ();
}

const Object::Type *
BoneAnimation::objectType (void)
{
	return type ();
}

const Object::Type *
BoneAnimation::type (void)
{
	static Type *mytype = NULL;
	static const Attribute attrs[] = {
		{ "bone", NULL, 0 },
		{ "disabled", "false", 0 }
	};
	if (!mytype) mytype = new Type(Source::type (), "Animation:BoneAnimation", NULL, NULL, sizeof (attrs) / sizeof (attrs[0]), attrs);
	return mytype;
}

void
BoneAnimation::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	Source::build (pnode, doc, ctx);

	buildAllAttributes (type (), ctx);

}

void
BoneAnimation::set (const char *attrid, const char *val)
{
	if (!strcmp (attrid, "bone")) {
		if (bonesid) free (bonesid);
		bonesid = (val) ? strdup (val) : NULL;
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "disabled")) {
		enabled = 1;
		bool bval;
		if (XML::parseBoolean (&bval, val)) enabled = !bval;
		requestUpdate (MODIFIED);
	} else {
		Source::set (attrid, val);
	}
}

void
BoneAnimation::clear (void)
{
	if (bonesid) free (bonesid);
	bonesid = NULL;
}

static bool
findKeys (float time, const float *times, u32 ntimes, u32& k0, u32& k1, float& w0)
{
	if (ntimes < 1) return false;
	k0 = 0;
	k1 = 0;
	if (time <= times[0]) {
		k0 = k1 = 0;
	} else if (time >= times[ntimes - 1]) {
		k0 = k1 = (int) ntimes - 1;
	} else {
		for (u32 j = 1; j < ntimes; j++) {
			if (times[j] > time) {
				k0 = (int) j - 1;
				k1 = (int) j;
				break;
			}
		}
	}
	if (k1 > k0) {
		// Interpolate
		float dt = times[k1] - times[k0];
		w0 = (times[k1] - time) / dt;
	} else {
		w0 = 1;
	}
	return true;
}

bool
BoneAnimation::interpolate (f32 frametime, u32& f0, u32& f1, f32& s, u32 repeattype)
{
	if (nframes == 0) {
		return false;
	} else if (nframes == 1) {
		f0 = 0;
		f1 = 0;
		s = 1;
		return true;
	}

	frametime = normalize (frametime, minframetime, maxframetime, repeattype);

	findKeys (frametime, frametimes, nframes, f0, f1, s);
	s = 1 - s;

	return true;
}

Elea::Matrix3x4f
BoneAnimation::getAB2P (float frametime, unsigned int type)
{
	unsigned int f0, f1;
	float s;
	if (!interpolate (frametime, f0, f1, s, type)) return Elea::Matrix3x4fIdentity;
	Elea::Quaternionf q0 = getQuaternion (f0);
	Elea::Quaternionf q1 = getQuaternion (f1);
	Elea::Quaternionf q = Elea::Quaternionf::slerp (q0, q1, s);
	Elea::Vector3f p0 = getPosition (f0);
	Elea::Vector3f p1 = getPosition (f1);
	Elea::Vector3f p = (1 - s) * p0 + s * p1;
	return Elea::Matrix3x4f(q, p);
}

// KeyFrameAnimation

KeyFrameAnimation::KeyFrameAnimation (u32 flags)
: Source(flags), enabled(1), geometrysid(NULL), indices(NULL), numindices(0), minindex(0), maxindex(0),
nframes(0), frametimes(NULL), vdata(NULL), ndata(NULL), tdata(NULL)
{
}

KeyFrameAnimation::~KeyFrameAnimation (void)
{
	clear ();
}

const Object::Type *
KeyFrameAnimation::objectType (void)
{
	return type ();
}

const Object::Type *
KeyFrameAnimation::type (void)
{
	static Type *mytype = NULL;
	static const Attribute attrs[] = {
		{ "geometry", NULL, 0 },
		{ "disabled", "false", 0 }
	};
	if (!mytype) mytype = new Type(Source::type (), "Animation:KeyFrameAnimation", NULL, NULL, sizeof (attrs) / sizeof (attrs[0]), attrs);
	return mytype;
}

void
KeyFrameAnimation::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	Source::build (pnode, doc, ctx);

	buildAllAttributes (type (), ctx);

}

void
KeyFrameAnimation::set (const char *attrid, const char *val)
{
	if (!strcmp (attrid, "geometry")) {
		if (geometrysid) free (geometrysid);
		geometrysid = (val) ? strdup (val) : NULL;
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "disabled")) {
		enabled = 1;
		bool bval;
		if (XML::parseBoolean (&bval, val)) enabled = !bval;
		requestUpdate (MODIFIED);
	} else {
		Source::set (attrid, val);
	}
}

void
KeyFrameAnimation::clear (void)
{
	if (geometrysid) free (geometrysid);
	geometrysid = NULL;
}

bool
KeyFrameAnimation::interpolate (f32 frametime, u32& f0, u32& f1, f32& s, u32 repeattype)
{
	if (nframes == 0) {
		return false;
	} else if (nframes == 1) {
		f0 = 0;
		f1 = 0;
		s = 1;
		return true;
	}

	// Find normalized frametime
	if (repeattype == CLAMP) {
		if (frametime < 0) frametime = 0;
		if (frametime > maxframetime) frametime = maxframetime;
	} else if (repeattype == REPEAT) {
		frametime = fmod (frametime, maxframetime);
		if (frametime < 0) frametime += maxframetime;
	} else {
		if (frametime < 0) frametime = -frametime;
		frametime = fmod (frametime, maxframetime);
	}

	findKeys (frametime, frametimes, nframes, f0, f1, s);
	s = 1 - s;

	return true;
}

// Animation

SkinAnimation::SkinAnimation (void)
: Source(HAS_CHILDREN),
enabled(1),
nboneanimations(0), boneanimations(NULL), nkeyframeanimations(0), keyframeanimations(NULL), nsequences(0), sequences(NULL),
currentframetime(0), currentseq(-1),
nkeyframes(0), keyframes(NULL), identities(NULL)
{
}

SkinAnimation::~SkinAnimation (void)
{
	if (keyframes) free (keyframes);
	if (identities) free (identities);
}

static Object *
skinanimation_factory (void)
{
	return new SkinAnimation();
}

const Object::Type *
SkinAnimation::objectType (void)
{
	return type ();
}

const Object::Type *
SkinAnimation::type (void)
{
	static Type *mytype = NULL;
	static const Attribute attrs[] = {
		{ "disabled", "false", 0 },
		{ "fps", "30", 0 },
		{ "currentFrameTime", "0", 0 },
		{ "currentSequence", "-1", 0 },
		{ "identities", NULL, 0 }
	};
	if (!mytype) mytype = new Type(Source::type (), "Animation:SkinAnimation", "animation:skinAnimation", skinanimation_factory, sizeof (attrs) / sizeof (attrs[0]), attrs);
	return mytype;
}

void
SkinAnimation::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	Source::build (pnode, doc, ctx);

	// We have to do this before arguments so keyframes are set up when parsing identities
	updateChildData (NULL);

	buildAllAttributes (type (), ctx);

}

void
SkinAnimation::release (void)
{
	if (boneanimations) {
		nboneanimations = 0;
		free (boneanimations);
		boneanimations = NULL;
	}
	if (keyframeanimations) {
		nkeyframeanimations = 0;
		free (keyframeanimations);
		keyframeanimations = NULL;
	}
	if (sequences) {
		nsequences = 0;
		free (sequences);
		sequences = NULL;
	}

	Source::release ();
}

Object *
SkinAnimation::childAdded (Thera::Node *cnode, Thera::Node *rnode)
{
	Object *cobj = Source::childAdded (cnode, rnode);

	updateChildData (NULL);

	return cobj;
}

void
SkinAnimation::childRemoved (Thera::Node *cnode, Thera::Node *rnode)
{
	updateChildData (cnode);

	Source::childRemoved (cnode, rnode);
}

void
SkinAnimation::set (const char *attrid, const char *val)
{
	if (!strcmp (attrid, "disabled")) {
		enabled = 1;
		bool bval;
		if (XML::parseBoolean (&bval, val)) enabled = !bval;
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "fps")) {
		if (!XML::parseNumber (&fps, val)) fps = 30;
		calculateLimits ();
		calculateKeyFrames ();
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "currentFrameTime")) {
		if (!XML::parseNumber (&currentframetime, val)) currentframetime = 0;
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "currentSequence")) {
		currentseq = (val) ? atoi (val) : -1;
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "identities")) {
		if (identities) free (identities);
		identities = NULL;
		if (!nkeyframes) return;
		int nvalues;
		if (XML::parseIntegers (NULL, &nvalues, val)) {
			u32 bwidth = (nkeyframes + 31) / 32;
			identities = (u32 *) malloc (nkeyframes * bwidth * sizeof (u32));
			memset (identities, 0, nkeyframes * bwidth * sizeof (u32));
			i32 *values = new i32[nvalues];
			XML::parseIntegers (values, &nvalues, val);
			for (int i = 0; i < nvalues - 1; i += 2) {
				setIdentity (values[i], values[i + 1]);
				setIdentity (values[i + 1], values[i]);
			}
			delete[] values;
			for (u32 i = 0; i < nkeyframes; i++) setIdentity (i, i);
		}
		requestUpdate (MODIFIED);
	} else {
		Source::set (attrid, val);
	}
}

void
SkinAnimation::write (const char *attrid)
{
	if (!strcmp (attrid, "identities")) {
		char *c = NULL;
		if (identities) {
			std::vector<int> values;
			for (u32 i = 0; i < nkeyframes; i++) {
				for (u32 j = i + 1; j < nkeyframes; j++) {
					if (areIdentical (i, j)) {
						values.push_back (i);
						values.push_back (j);
					}
				}
			}
			if (!values.empty ()) {
				int len = (int) values.size () * 32;
				c = new char[len];
				XML::writeIntegers (c, len, &values[0], (int) values.size ());
			}
		}
		node->setAttribute (attrid, c);
		if (c) delete[] c;
	} else {
		Source::write (attrid);
	}
}

void
SkinAnimation::update (UpdateCtx *ctx, unsigned int flags)
{
	Source::update (ctx, flags);
}

void
SkinAnimation::updateChildData (Thera::Node *removed)
{
	nboneanimations = listChildrenOfType (BoneAnimation::type (), (Object ***) &boneanimations, removed);
	nkeyframeanimations = listChildrenOfType (KeyFrameAnimation::type (), (Object ***) &keyframeanimations, removed);
	nsequences = listChildrenOfType (Sequence::type (), (Object ***) &sequences, removed);

	calculateLimits ();
	calculateKeyFrames ();
}

void
SkinAnimation::setCurentFrameTime (float time)
{
	currentframetime = time;
	if (currentframetime < minframetime) currentframetime = minframetime;
	if (currentframetime > maxframetime) currentframetime = maxframetime;
	requestUpdate (MODIFIED);
}

void
SkinAnimation::calculateLimits (void)
{
	minframetime = Elea::OMEGA_F;
	maxframetime = -Elea::OMEGA_F;
	for (u32 i = 0; i < nboneanimations; i++) {
		float lmintime = boneanimations[i]->minframetime * (fps / boneanimations[i]->fps);
		float lmaxtime = boneanimations[i]->maxframetime * (fps / boneanimations[i]->fps);
		if (lmintime < minframetime) minframetime = lmintime;
		if (lmaxtime > maxframetime) maxframetime = lmaxtime;
	}
	for (u32 i = 0; i < nkeyframeanimations; i++) {
		float lmintime = keyframeanimations[i]->minframetime * (fps / keyframeanimations[i]->fps);
		float lmaxtime = keyframeanimations[i]->maxframetime * (fps / keyframeanimations[i]->fps);
		if (lmintime < minframetime) minframetime = lmintime;
		if (lmaxtime > maxframetime) maxframetime = lmaxtime;
	}
	if (minframetime > maxframetime) {
		minframetime = 0;
		maxframetime = 0;
	}
	if (currentframetime < minframetime) currentframetime = minframetime;
	if (currentframetime > maxframetime) currentframetime = maxframetime;
}

void
SkinAnimation::calculateKeyFrames (void)
{
	std::vector<u32> bi(nboneanimations);
	for (u32 i = 0; i < nboneanimations; i++) bi[i] = 0;
	std::vector<u32> ki(nkeyframeanimations);
	for (u32 i = 0; i < nkeyframeanimations; i++) ki[i] = 0;
	std::vector<float> kftimes;
	float ltime = minframetime;
	kftimes.push_back (ltime);
	while (ltime < maxframetime) {
		float ntime = maxframetime;
		for (u32 i = 0; i < nboneanimations; i++) {
			float ftime = ntime;
			while (bi[i] < boneanimations[i]->nframes) {
				ftime = boneanimations[i]->frametimes[bi[i]] * (fps / boneanimations[i]->fps);
				if (ftime > ltime) break;
				bi[i] += 1;
			}
			if (bi[i] < boneanimations[i]->nframes) {
				if (ftime < ntime) ntime = ftime;
			}
		}
		for (u32 i = 0; i < nkeyframeanimations; i++) {
			float ftime = ntime;
			while (ki[i] < keyframeanimations[i]->nframes) {
				ftime = keyframeanimations[i]->frametimes[ki[i]] * (fps / keyframeanimations[i]->fps);
				if (ftime > ltime) break;
				ki[i] += 1;
			}
			if (ki[i] < keyframeanimations[i]->nframes) {
				if (ftime < ntime) ntime = ftime;
			}
		}
		ltime = ntime;
		kftimes.push_back (ltime);
	}
	nkeyframes = (u32) kftimes.size ();
	keyframes = (float *) realloc (keyframes, kftimes.size () * sizeof (float));
	memcpy (keyframes, &kftimes[0], nkeyframes * sizeof (float));
}

void
SkinAnimation::calculateBonePositions (Elea::Matrix4x4f b2s[], Elea::Vector3f endpos[], float time, const int anim2skel[], u32 nbones, const int parents[], const Orientation orientations[], const float lengths[])
{
	// Initialize orientations
	std::vector<Orientation> b2p(nbones);
	for (u32 i = 0; i < nbones; i++) b2p[i] = orientations[i];
	// Iterate over all bone animations and update relevant orientations
	for (u32 i = 0; i < nboneanimations; i++) {
		int idx = anim2skel[i];
		if ((idx < 0) || (idx >= (int) nbones)) continue;
		u32 f0, f1;
		float s;
		if (boneanimations[i]->interpolate (time * boneanimations[i]->fps, f0, f1, s, BoneAnimation::CLAMP)) {
			Elea::Quaternionf q = Elea::Quaternionf::slerp (boneanimations[i]->getQuaternion (f0), boneanimations[i]->getQuaternion (f1), s);
			Elea::Vector3f p = (1 - s) * boneanimations[i]->getPosition (f0) + s * boneanimations[i]->getPosition (f1);
			b2p[idx].q = q;
			b2p[idx].p = p;
		}
	}
	// Calculate bone matrixes
	for (u32 i = 0; i < nbones; i++) {
		Elea::Matrix4x4f m(b2p[i].q, b2p[i].p);
		if (parents[i] >= 0) {
			b2s[i] = b2s[parents[i]] * m;
		} else {
			b2s[i] = m;
		}
	}
	// Calculate endpoint positions
	for (u32 i = 0; i < nbones; i++) {
		endpos[i] = b2s[i].transformPoint3 (Elea::Vector3f(0, 0, lengths[i]));
	}
}

void
SkinAnimation::calculateIdentities (const int anim2skel[], u32 nbones, const int parents[], const Orientation orientations[], const float lengths[], float maxdelta)
{
	if (identities) free (identities);
	identities = NULL;
	if (!nbones) return;
	if (!nkeyframes) return;
	float maxdelta2 = maxdelta * maxdelta;
	u32 bwidth = (nkeyframes + 31) / 32;
	identities = (u32 *) malloc (nkeyframes * bwidth * sizeof (u32));
	memset (identities, 0, nkeyframes * bwidth * sizeof (u32));
	for (u32 i = 0; i < (nkeyframes - 1); i++) {
		if (debug) fprintf (stderr, "Keyframe %d (%.2f): ", i, keyframes[i]);

		int nident = 0;
		std::vector<Elea::Matrix4x4f> b2s0(nbones);
		std::vector<Elea::Vector3f> endpos0(nbones);
		calculateBonePositions (&b2s0[0], &endpos0[0], keyframes[i] / fps, anim2skel, nbones, parents, orientations, lengths);
		std::vector<Elea::Matrix4x4f> b2s1(nbones);
		std::vector<Elea::Vector3f> endpos1(nbones);
		for (u32 j = i + 1; j < nkeyframes; j++) {
			calculateBonePositions (&b2s1[0], &endpos1[0], keyframes[j] / fps, anim2skel, nbones, parents, orientations, lengths);
			u32 k;
			for (k = 0; k < nbones; k++) {
				Elea::Vector3f d(b2s0[k].getTranslation () - b2s1[k].getTranslation ());
				// if (d.length2 () > maxdelta2) break;
				d = Elea::Vector3f(endpos0[k] - endpos1[k]);
				if (d.length2 () > maxdelta2) break;
			}
			if (k >= nbones) {
				setIdentity (i, j);
				setIdentity (j, i);
				nident += 1;
				if (debug) fprintf (stderr, "%.3f ", keyframes[j]);
			}
		}
		setIdentity (i, i);
		if (debug) fprintf (stderr, "- %d identical frames\n", nident);
	}
}

void
SkinAnimation::setIdentity (int keyframe0, int keyframe1)
{
	if (!identities) return;
	if (!nkeyframes) return;
	u32 bwidth = (nkeyframes + 31) / 32;
	identities[keyframe0 * bwidth + keyframe1 / 32] = identities[keyframe0 * bwidth + keyframe1 / 32] | (1 << (keyframe1 % 32));
}

unsigned int
SkinAnimation::areIdentical (int frame0, int frame1)
{
	if (!nkeyframes || !identities) return 0;
	u32 bwidth = (nkeyframes + 31) / 32;
	return (identities[frame0 * bwidth + frame1 / 32] & (1 << (frame1 % 32))) != 0;
}

void
SkinAnimation::calculateIdentities (Skeleton *skeleton, float pmaxdelta)
{
	if (!nboneanimations) return;
	// Generate anim2skel mapping
	std::vector<int> anim2skel(nboneanimations);
	for (u32 i = 0; i < nboneanimations; i++) {
		anim2skel[i] = skeleton->lookupBone (boneanimations[i]->bonesid);
	}
	std::vector<int> parents(skeleton->bones.size (), -1);
	for (size_t i = 0; i < skeleton->bones.size (); i++) {
		for (size_t j = i + 1; j < skeleton->bones.size (); j++) {
			if (skeleton->bones[j]->parent == (Object *) skeleton->bones[i]) parents[j] = i;
		}
	}
	std::vector<Orientation> orientations(skeleton->bones.size ());
	std::vector<float> lengths(skeleton->bones.size ());
	for (size_t i = 0; i < skeleton->bones.size (); i++) {
		Elea::Matrix4x4f b2p = skeleton->bones[i]->b2p;
		orientations[i].q = b2p.getRotationQuaternion ();
		orientations[i].p = b2p.getTranslation ();
		// fixme:
		lengths[i] = 0.1f;
	}
	// fixme:
	calculateIdentities (&anim2skel[0], skeleton->bones.size (), &parents[0], &orientations[0], &lengths[0], 0.001f);
}

// Sequence

Sequence::Sequence (void)
: Source(0), targetid(NULL), sourceid(NULL), repeattype(CLAMP), speed(1), target(NULL), source(NULL)
{
}

static Object *
sequence_factory (void)
{
	return new Sequence();
}

const Object::Type *
Sequence::objectType (void)
{
	return type ();
}

const Object::Type *
Sequence::type (void)
{
	static Type *mytype = NULL;
	static const Attribute attrs[] = {
		{ "target", NULL, 0 },
		{ "source", NULL, 0 },
		{ "repeat", "repeat", 0 },
		{ "fps", "30", 0 },
		{ "startFrameTime", "0", 0 },
		{ "endFrameTime", "0", 0 },
		{ "speed", "1", 0 }
	};
	if (!mytype) mytype = new Type(Source::type (), "Animation:Sequence", "animation:sequence", sequence_factory, sizeof (attrs) / sizeof (attrs[0]), attrs);
	return mytype;
}

void
Sequence::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	Source::build (pnode, doc, ctx);
	buildAllAttributes (type (), ctx);
}

void
Sequence::release (void)
{
	if (target) {
		target->detach (this);
		target = NULL;
	}
	if (targetid) {
		document->removeIdentityChangeListener (targetid, this);
		free (targetid);
		targetid = NULL;
	}
	if (source) {
		source->detach (this);
		source = NULL;
	}
	if (sourceid) {
		document->removeIdentityChangeListener (sourceid, this);
		free (sourceid);
		sourceid = NULL;
	}
	Source::release ();
}


void
Sequence::set (const char *attrid, const char *val)
{
	if (!strcmp (attrid, "target")) {
		if (target) {
			target->detach (this);
			target = NULL;
		}
		if (targetid) {
			document->removeIdentityChangeListener (targetid, this);
			free (targetid);
			targetid = NULL;
		}
		if (val && (val[0] == '#') && val[1]) {
			targetid = strdup (val + 1);
			document->addIdentityChangeListener (targetid, this);
			Object *object = document->lookupObject (targetid);
			if (object && object->isType (Figure::type ())) {
				target = (Figure *) object;
				target->attach (this);
			}
		}
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "source")) {
		if (source) {
			source->detach (this);
			source = NULL;
		}
		if (sourceid) {
			document->removeIdentityChangeListener (sourceid, this);
			free (sourceid);
			sourceid = NULL;
		}
		if (val && (val[0] == '#') && val[1]) {
			sourceid = strdup (val + 1);
			document->addIdentityChangeListener (sourceid, this);
			Object *object = document->lookupObject (sourceid);
			if (object && object->isType (Source::type ())) {
				source = (Source *) object;
				source->attach (this);
			}
		}
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "repeat")) {
		repeattype = CLAMP;
		if (val) {
			if (!strcmp (val, "clamp")) {
				repeattype = CLAMP;
			} else if (!strcmp (val, "mirror")) {
				repeattype = MIRROR;
			}
		}
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "fps")) {
		if (!XML::parseNumber (&fps, val)) fps = 30;
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "startFrameTime")) {
		if (!XML::parseNumber (&minframetime, val)) minframetime = 0;
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "endFrameTime")) {
		if (!XML::parseNumber (&maxframetime, val)) maxframetime = 0;
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "speed")) {
		if (!XML::parseNumber (&speed, val)) speed = 1;
		requestUpdate (MODIFIED);
	} else {
		Source::set (attrid, val);
	}
}

void
Sequence::update (UpdateCtx *ctx, unsigned int flags)
{
	Source::update (ctx, flags);
	if (source && source->isType (SkinAnimation::type ()) && target) {
		// fixme: We should detach it as well
		target->attachAnimation ((SkinAnimation *) source);
	}
}

void
Sequence::identityAdded (Document *pdocument, const char *pidentity, Object *pobject)
{
	if (targetid && !strcmp (pidentity, targetid)) {
		if (target) {
			target->detach (this);
			target = NULL;
		}
		if (pobject->isType (Figure::type ())) {
			target = (Figure *) pobject;
			target->attach (this);
		}
	} else if (sourceid && !strcmp (pidentity, sourceid)) {
		if (source) {
			source->detach (this);
			source = NULL;
		}
		if (pobject->isType (Source::type ())) {
			source = (Source *) pobject;
			source->attach (this);
		}
	}
	requestModified (MODIFIED);
}

void
Sequence::identityRemoved (Document *pdocument, const char *pidentity)
{
	if (targetid && !strcmp (pidentity, targetid)) {
		if (target) {
			target->detach (this);
			target = NULL;
		}
	} else if (sourceid && !strcmp (pidentity, sourceid)) {
		if (source) {
			source->detach (this);
			source = NULL;
		}
	}
	requestModified (MODIFIED);
}

void
Sequence::attachedObjectRelease (Object *attached, void *data)
{
	if (attached == target) {
		target->detach (this);
		target = NULL;
	} else if (attached == source) {
		source->detach (this);
		source = NULL;
	}
	requestUpdate (MODIFIED);
}

void
Sequence::attachedObjectModified (Object *attached, unsigned int flags, void *data)
{
	if ((attached == source) && (flags & MODIFIED)) requestUpdate (MODIFIED);
}

void
Sequence::applyAnimation (float frametime)
{
	if (!target || !source) return;
	if (source->isType (SkinAnimation::type ())) {
		target->animate ((SkinAnimation *) source, minframetime + frametime);
	}
}

} // Namespace Animation

} // Namespace Miletos
