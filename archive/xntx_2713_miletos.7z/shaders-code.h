#ifndef __SHADERS_CODE_H__
#define __SHADERS_CODE_H__

#ifdef __cplusplus
extern "C" {
#endif

extern const char lightmap_ambient_fragment_txt_0_data[];
extern size_t lightmap_ambient_fragment_txt_0_size;
extern size_t lightmap_ambient_fragment_txt_size;

extern const char lightmap_hilight_fragment_txt_0_data[];
extern size_t lightmap_hilight_fragment_txt_0_size;
extern size_t lightmap_hilight_fragment_txt_size;

extern const char lightmap_vertex_txt_0_data[];
extern size_t lightmap_vertex_txt_0_size;
extern size_t lightmap_vertex_txt_size;

extern const char lightmap_gbuf_vertex_txt_0_data[];
extern size_t lightmap_gbuf_vertex_txt_0_size;
extern size_t lightmap_gbuf_vertex_txt_size;

extern const char lightmap_gbuf_fragment_txt_0_data[];
extern size_t lightmap_gbuf_fragment_txt_0_size;
extern size_t lightmap_gbuf_fragment_txt_size;

extern const char xx_lightmap_vertex_txt_0_data[];
extern size_t xx_lightmap_vertex_txt_0_size;
extern size_t xx_lightmap_vertex_txt_size;

extern const char xx_lightmap_fragment_txt_0_data[];
extern size_t xx_lightmap_fragment_txt_0_size;
extern size_t xx_lightmap_fragment_txt_size;

#ifdef __cplusplus
}; /* "C" */
#endif

#endif
