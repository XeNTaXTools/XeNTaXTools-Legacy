#ifndef __MILETOS_MATERIAL_H__
#define __MILETOS_MATERIAL_H__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2009
//

#include <libnr/nr-image.h>

#include <miletos/types.h>
#include <miletos/miletos.h>

namespace Miletos {

// Texture info
struct TextureInfo {
	// Identifying location or id
	char *urn;
	// Path to unmodified disk image if applicable
	char *path;
	// Image container
	NRImage *image;

	TextureInfo (void);
	~TextureInfo (void);
};

// Material info
struct MaterialInfo {
	enum Type { COLOR, TEXTURE, LIGHTMAP, SPECIAL };
	enum Channels { DIFFUSE, SPECULAR, NORMAL };
	Type type;
	const char *id;
	// Color info
	Elea::Color4f diffuseColor;
	Elea::Color4f specularColor;
	f32 specularShininess;
	// Texture info
	int diffuseTexture;
	int normalTexture;
	int specularTexture;
	// Lightmap info
	int lightmapTexture;
	f32 lightmapCoefficent;
};

// Material

class Material : public Object {
private:
	// Object implementation
	virtual const Type *objectType (void);
protected:
	// Constructor
	Material (u32 flags) : Object(flags) {}
public:
	// Type system
	static const Type *type (void);

	// Get sehle material reference
	virtual Sehle::Material *getSehleMaterial (Sehle::Engine *engine) = 0;
	// Exporter support
	virtual TextureInfo *getTextureInfo (unsigned int texidx, unsigned int getimage) = 0;
	virtual u32 getMaterialInfo (MaterialInfo *mat) = 0;
};

// MaterialNoise

class MaterialNoise : public Material {
private:
	unsigned int resolution_s_set : 1;
	unsigned int resolution_t_set : 1;

	// Reference to Sehle::Material
	// fixme: This crashes if engine will be destroyed before document
	Sehle::Material *smat;

	// Object implementation
	virtual const Type *objectType (void);
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	virtual void set (const char *attrid, const char *val);
	virtual void update (UpdateCtx *ctx, unsigned int flags);

	// Material implementation
	virtual Sehle::Material *getSehleMaterial (Sehle::Engine *engine);
	virtual TextureInfo *getTextureInfo (unsigned int texidx, unsigned int getimage);
	virtual u32 getMaterialInfo (MaterialInfo *mat);

	// Helpers
	void updateSehleMaterial (void);
public:
	u32 resolution;
	u32 resolution_s;
	u32 resolution_t;

	// Constructor
	MaterialNoise (void);

	// Type system
	static const Type *type (void);
};

// MaterialNoise

class MaterialDNS : public Material {
public:
	// Sehle material has to be reattached
	static const int MAP_MODIFIED = 128;
	enum { DIFFUSE, TRANSPARENCY, SPECULAR, NORMAL, NUM_MAPS };
private:
	enum { WIRE, SOLID };

	// Reference to Sehle::Material
	// fixme: This crashes if engine will be destroyed before document
	Sehle::Material *smat;
	// Image data
	char *urls[NUM_MAPS];
	NRImage *images[NUM_MAPS];
	int filltype;

	// Object implementation
	virtual const Type *objectType (void);
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	virtual void set (const char *attrid, const char *val);
	virtual void update (UpdateCtx *ctx, unsigned int flags);

	// Material implementation
	virtual Sehle::Material *getSehleMaterial (Sehle::Engine *engine);
	virtual TextureInfo *getTextureInfo (unsigned int texidx, unsigned int getimage);
	virtual u32 getMaterialInfo (MaterialInfo *mat);

	// Helpers
	void setImage (unsigned int map, const char *url);
	void loadImage (unsigned int map);
	NRImage *getDiffuseImage (bool scaled);
	void updateSehleMaterial (unsigned int maps);
public:
	Elea::Color4f diffuseColor;
	Elea::Color4f specularColor;
	float shininess;
	unsigned int mapsize;

	MaterialDNS (void);

	// Type system
	static const Type *type (void);
};

} // Namespace Miletos

#endif

