#ifndef __MILETOS_MESH_XX_H__
#define __MILETOS_MESH_XX_H__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2009
//

#include <miletos/helpers/datablock.h>
#include <miletos/uri.h>
#include <miletos/pmesh.h>
#include <miletos/skinnedgeometry.h>
#include <miletos/morph.h>
#include <miletos/animation.h>

namespace Miletos {

class XXData;

class XAData : public DataBlock {
private:
	enum Format { UNKNOWN, SB3, OTHER };
	URI::URLHandler *handler;
	const unsigned char *cdata;
	size_t csize;

	XAData (const unsigned char *xdata, size_t xsize, const char *url, URI::URLHandler *handler);
	virtual ~XAData (void);

	// Helper
	Format getFormat (const unsigned char *xdata, size_t xsize);
public:
	// Morph targets
	struct IndexBlock {
		std::string name;
		u32 framemeshidx;
		u32 numindices;
		const u16 *vindices;
		const u16 *nindices;
	};
	std::vector<IndexBlock> indexblocks;
	struct VertexBlock {
		std::string name;
		u32 numvertices;
		const f32 *vertices;
		const f32 *normals;
	};
	std::vector<VertexBlock> vertexblocks;
	struct Morph {
		std::string name;
		int ibidx;
		std::vector<int> vbidx;
	};
	std::vector<Morph> morphs;

	// Animations
	struct Animation {
		std::string boneid;
		u32 numframes;
		const f32 *frames;
	};
	std::vector<Animation> animations;
	struct Sequence {
		std::string id;
		f32 speed;
		f32 startframe;
		f32 endframe;
		i32 nextidx;
	};
	std::vector<Sequence> sequences;

	// Static constructor
	static XAData *getXAData (const char *url);

	// Create Morph tree
	void buildMorphs (Thera::Node *parentnode, const char *xxuri, const char *geometry);
};

class GeometryXX : public SkinnedGeometry {
private:
	XXData *bdata;

	// Textures
	struct Texture;
	Texture *textures;

	// Private material definitions
	struct Material {
		enum Type { NORMAL, SHADOW, HILIGHT, NUM_TYPES };
		std::string id;
		Elea::Color4f color;
		int texture;
		u32 type;
	};
	std::vector<Material> materials;

	// Object implementation
	virtual const Type *objectType (void);
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	virtual void set (const char *attrid, const char *val);
	virtual void update (UpdateCtx *ctx, unsigned int flags);

	// SkinnedGeometry implementation
	virtual Sehle::Material *getMaterial (int matidx, Sehle::Engine *engine);
	virtual TextureInfo *getTextureInfo (unsigned int matidx, unsigned int texidx, unsigned int getimage);
	virtual u32 getMaterialInfo (MaterialInfo *mat, u32 matidx);

	void loadData (URI::URLHandler *handler, const char *url);
protected:
public:
	// Constructor
	GeometryXX (void) : bdata(NULL), textures(NULL) {}
	// Destructor
	~GeometryXX (void);

	// Type system
	static const Type *type (void);

	// Access for exporter
	const char *getMaterialName (int midx);
	const char *getTextureName (int midx);
	bool isColorMaterial (int midx);
	bool isTexturedMaterial (int midx);
	bool getTextureImage (NR::PixBlock& px, int midx);
	Elea::Color4f getMaterialDiffuse (int midx);
};

class MorphTargetXA : public MorphTarget {
private:
	XAData *xadata;
	int morphidx;
	int targetidx;
	Elea::Vector3f *pvertices;
	Elea::Vector3f *pnormals;
	u32 *pindices;

	// Object implementation
	virtual const Type *objectType (void);
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	virtual void set (const char *attrid, const char *val);

	// Helpers
	void updateData (void);
protected:
public:
	// Constructor
	MorphTargetXA (void);
	// Destructor
	~MorphTargetXA (void);

	// Type system
	static const Type *type (void);
};

class BoneAnimationXA : public Animation::BoneAnimation {
private:
	char *source;
	char *meshsource;
	int animidx;
	int seqidx;

	XAData *bdata;
	XXData *mdata;

	f32 *pframetimes;
	Orientation *porientations;

	// Object implementation
	virtual const Type *objectType (void);
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	virtual void set (const char *attrid, const char *val);

	// BoneAnimation implementation
	virtual Elea::Vector3f getPosition (unsigned int frameidx);
	virtual Elea::Quaternionf getQuaternion (unsigned int frameidx);

	// Helpers
	void updateData ();
protected:
public:
	// Constructor
	BoneAnimationXA (void);
	// Destructor
	~BoneAnimationXA (void);

	// Type system
	static const Type *type (void);
};

} // Namespace Miletos

#endif

