#define __MILETOS_MATERIAL_CPP__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2009
//

static const int debug = 0;

#include <malloc.h>

#include <libnr/nr-blit.h>
#include <libnr/nr-pixblock-compose.h>
#include <libnr/nr-pixblock-transform.h>

#include <sehle/rendercontext.h>
#include <sehle/material-multipass-dns.h>

#include "image.h"
#include "uri.h"
#include "xml/base.h"

#include "material.h"

namespace Miletos {

TextureInfo::TextureInfo (void)
: urn(NULL), path(NULL), image(NULL)
{
}

TextureInfo::~TextureInfo (void)
{
	if (urn) free (urn);
	if (path) free (path);
	if (image) nr_image_unref (image);
}

// Material

const Object::Type *
Material::objectType (void)
{
	return type ();
}

const Object::Type *
Material::type (void)
{
	static Type *mytype = NULL;
	if (!mytype) mytype = new Type(Object::type (), "Material", NULL, NULL, 0, NULL);
	return mytype;
}

// MaterialNoise

MaterialNoise::MaterialNoise (void)
: Material(0),
resolution_s_set(0), resolution_t_set(0),
smat(NULL),
resolution(256), resolution_s(256), resolution_t(256)
{
}

static Object *
materialnoise_factory (void)
{
	return new MaterialNoise();
}

const Object::Type *
MaterialNoise::objectType (void)
{
	return type ();
}

const Object::Type *
MaterialNoise::type (void)
{
	static Type *mytype = NULL;
	static const Attribute attrs[] = {
		{ "resolution", "256", 0 },
		{ "resolutionS", "256", 0 },
		{ "resolutionT", "256", 0 },
		{ "frequency", "1", 0 },
		{ "frequencyS", "1", 0 },
		{ "frequencyT", "1", 0 },
		{ "octaves", "4", 0 },
		{ "octavesS", "4", 0 },
		{ "octavesT", "4", 0 },
		{ "persistence", "2", 0 },
		{ "persistenceS", "2", 0 },
		{ "persistenceT", "2", 0 },
		{ "s0", "0", 0 },
		{ "t0", "0", 0 },
		{ "seed", "0", 0 },
		{ "color0", "black", 0 },
		{ "color1", "white", 0 }
	};
	if (!mytype) mytype = new Type(Material::type (), "MaterialNoise", "materialNoise", materialnoise_factory, sizeof (attrs) / sizeof (attrs[0]), attrs);
	return mytype;
}

void
MaterialNoise::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	Material::build (pnode, doc, ctx);

	buildAllAttributes (type (), ctx);

}

void
MaterialNoise::release (void)
{
	if (smat) {
		smat->unRef ();
		smat = NULL;
	}
}

void
MaterialNoise::set (const char *attrid, const char *val)
{
	if (!strcmp (attrid, "resolution")) {
		if (!XML::parseInteger ((int *) &resolution, val)) resolution = 256;
	} else if (!strcmp (attrid, "resolutionS")) {
		resolution_s_set = 0;
		resolution_s = 256;
		if (XML::parseInteger ((int *) &resolution_s, val)) resolution_s_set = 1;
	} else if (!strcmp (attrid, "resolutionT")) {
		resolution_t_set = 0;
		resolution_t = 256;
		if (XML::parseInteger ((int *) &resolution_t, val)) resolution_t_set = 1;
	}
	requestUpdate (MODIFIED);
}

void
MaterialNoise::update (UpdateCtx *ctx, unsigned int flags)
{
	Material::update (ctx, flags);

	if (flags & MODIFIED) {
		if (smat) updateSehleMaterial ();
	}
}

Sehle::Material *
MaterialNoise::getSehleMaterial (Sehle::Engine *engine)
{
	if (!smat) {
		smat = Sehle::MaterialMultipassDNS::newMaterialMultipassDNS (engine, NULL);
		updateSehleMaterial ();
	}
	smat->ref ();
	return smat;
}

TextureInfo *
MaterialNoise::getTextureInfo (unsigned int texidx, unsigned int getimage)
{
	return NULL;
}

u32
MaterialNoise::getMaterialInfo (MaterialInfo *mat)
{
	return false;
}

void
MaterialNoise::updateSehleMaterial (void)
{
	Sehle::MaterialMultipassDNS *dns = (Sehle::MaterialMultipassDNS *) smat;

	u32 width = (resolution_s_set) ? resolution_s : resolution;
	u32 height = (resolution_t_set) ? resolution_t : resolution;
	if (width < 1) width = 1;
	if (width > 4096) width = 4096;
	if (height < 1) height = 1;
	if (height > 4096) height = 4096;
	NR::PixBlock px(NR::PixBlock::R8G8B8A8N, 0, 0, width, height, true, false);
	for (int y = 0; y < px.getHeight (); y++) {
		unsigned char *d = px.getRow (y);
		for (int x = 0; x < px.getHeight (); x++) {
			d[0] = (x << 4) & 255;
			d[1] = (y << 4)  & 255;
			d[2] = x & 255;
			d[3] = (x * y) & 255;
			d += 4;
		}
	}
	px.markDirty ();
	dns->setMap (Sehle::MaterialMultipassDNS::COLOR, NULL, &px.pb);
}

// MaterialDNS

MaterialDNS::MaterialDNS (void)
: Material(0), smat(NULL), filltype(SOLID), diffuseColor(Elea::Color4fWhite), specularColor(Elea::Color4fTransparent), shininess(32), mapsize(1024)
{
	for (int i = 0; i < NUM_MAPS; i++) {
		urls[i] = NULL;
		images[i] = NULL;
	}
}

static Object *
materialdns_factory (void)
{
	return new MaterialDNS();
}

const Object::Type *
MaterialDNS::objectType (void)
{
	return type ();
}

const Object::Type *
MaterialDNS::type (void)
{
	static Type *mytype = NULL;
	static const Attribute attrs[] = {
		{ "diffuse", NULL, 0 },
		{ "transparency", NULL, 0 },
		{ "specular", NULL, 0 },
		{ "normal", NULL, 0 },
		{ "diffuseColor", NULL, 0 },
		{ "specularColor", NULL, 0 },
		{ "shininess", NULL, 0 },
		{ "mapsize", "1024", 0 },
		{ "type", "solid", 0 }
	};
	if (!mytype) mytype = new Type(Material::type (), "MaterialDNS", "materialDNS", materialdns_factory, sizeof (attrs) / sizeof (attrs[0]), attrs);
	return mytype;
}

void
MaterialDNS::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	Material::build (pnode, doc, ctx);

	buildAllAttributes (type (), ctx);

}

void
MaterialDNS::release (void)
{
	for (int i = 0; i < NUM_MAPS; i++) {
		if (urls[i]) {
			free (urls[i]);
			urls[i] = NULL;
		}
		if (images[i]) {
			nr_image_unref (images[i]);
			images[i] = NULL;
		}
	}
	if (smat) {
		smat->unRef ();
		smat = NULL;
	}
}

void
MaterialDNS::setImage (unsigned int map, const char *url)
{
	if (urls[map]) {
		free (urls[map]);
		urls[map] = NULL;
	}
	if (images[map]) {
		nr_image_unref (images[map]);
		images[map] = NULL;
	}
	if (!url || !*url) return;
	urls[map] = strdup (url);
}

void
MaterialDNS::loadImage (unsigned int map)
{
	if (images[map]) return;
	if (!urls[map] || !*urls[map]) return;
	URI::Location loc(urls[map]);
	URI::URLHandler *handler = URI::getHandler (loc.path);
	if (handler) {
		size_t csize;
		const unsigned char *cdata = handler->mmapData (loc.path, &csize);
		if (cdata) {
			images[map] = nr_image_new ();
			if (!Image::load (&images[map]->pixels, cdata, csize)) {
				nr_image_unref (images[map]);
				images[map] = NULL;
			}
			handler->munmapData (cdata);
		}
		handler->unRef ();
	}
}

void
MaterialDNS::set (const char *attrid, const char *val)
{
	if (!strcmp (attrid, "diffuse")) {
		setImage (DIFFUSE, val);
		requestUpdate (MODIFIED | MAP_MODIFIED);
	} else if (!strcmp (attrid, "transparency")) {
		setImage (TRANSPARENCY, val);
		requestUpdate (MODIFIED | MAP_MODIFIED);
	} else if (!strcmp (attrid, "specular")) {
		setImage (SPECULAR, val);
		requestUpdate (MODIFIED | MAP_MODIFIED);
	} else if (!strcmp (attrid, "normal")) {
		setImage (NORMAL, val);
		requestUpdate (MODIFIED | MAP_MODIFIED);
	} else if (!strcmp (attrid, "diffuseColor")) {
		if (!XML::parseColor (&diffuseColor, val)) diffuseColor = Elea::Color4fWhite;
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "specularColor")) {
		if (!XML::parseColor (&specularColor, val)) specularColor = Elea::Color4fTransparent;
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "shininess")) {
		if (!XML::parseNumber (&shininess, val)) shininess = 32;
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "mapsize")) {
		if (!XML::parseInteger ((int *) &mapsize, val)) mapsize = 1024;
		if (mapsize < 16) mapsize = 16;
		requestUpdate (MODIFIED | MAP_MODIFIED);
	} else if (!strcmp (attrid, "type")) {
		if (val && !strcmp (val, "wire")) {
			filltype = WIRE;
		} else {
			filltype = SOLID;
		}
		requestUpdate (MODIFIED);
	}
}

void
MaterialDNS::update (UpdateCtx *ctx, unsigned int flags)
{
	Material::update (ctx, flags);

	if (smat && (flags & MODIFIED)) {
		updateSehleMaterial (flags & MAP_MODIFIED);
	}
}

Sehle::Material *
MaterialDNS::getSehleMaterial (Sehle::Engine *engine)
{
	if (!smat) {
		smat = Sehle::MaterialMultipassDNS::newMaterialMultipassDNS (engine, NULL);
		updateSehleMaterial (true);
	}
	smat->ref ();
	return smat;
}

TextureInfo *
MaterialDNS::getTextureInfo (unsigned int texidx, unsigned int getimage)
{
	if (!urls[DIFFUSE]) return false;
	TextureInfo *tex = new TextureInfo();
	if (!urls[TRANSPARENCY]) {
		tex->urn = strdup (urls[DIFFUSE]);
		URI::Location loc(urls[DIFFUSE], "file");
		if (loc.protocol && !strcmp ((const char *) loc.protocol, "file")) {
			tex->path = strdup ((const char *) loc.path + 5);
		}
	} else {
		size_t dlen = strlen (urls[DIFFUSE]);
		size_t tlen = strlen (urls[TRANSPARENCY]);
		tex->urn = (char *) malloc (10 + dlen + 1 + tlen + 1);
		memcpy (tex->urn, "composite:", 10);
		memcpy (tex->urn + 10, urls[DIFFUSE], dlen);
		tex->urn[10 + dlen] = '+';
		memcpy (tex->urn + 10 + dlen + 1, urls[TRANSPARENCY], tlen);
		tex->urn[10 + dlen + 1 + tlen] = 0;
	}
	if (getimage) {
		tex->image = getDiffuseImage (false);
	}
	return tex;
}

u32
MaterialDNS::getMaterialInfo (MaterialInfo *mat)
{
	mat->id = id;
	mat->diffuseColor = diffuseColor;
	mat->specularColor = specularColor;
	mat->specularShininess = shininess;
	if (images[DIFFUSE] && !images[DIFFUSE]->pixels.empty) {
		mat->type = MaterialInfo::TEXTURE;
		mat->diffuseTexture = 0;
	} else {
		mat->type = MaterialInfo::COLOR;
		mat->diffuseTexture = -1;
	}
	mat->normalTexture = -1;
	mat->specularTexture = -1;
	mat->lightmapTexture = -1;
	mat->lightmapCoefficent = 1;
	return true;
}

NRImage *
MaterialDNS::getDiffuseImage (bool scaled)
{
	if (!images[DIFFUSE] || images[DIFFUSE]->pixels.empty) return NULL;

	if (images[TRANSPARENCY] && !images[TRANSPARENCY]->pixels.empty) {
		// We have to composite image with transparency
		NRImage *dimage = images[DIFFUSE];
		nr_image_ref (dimage);
		NRImage *timage = images[TRANSPARENCY];
		nr_image_ref (timage);
		unsigned int dw = dimage->pixels.area.x1 - dimage->pixels.area.x0;
		unsigned int tw = timage->pixels.area.x1 - timage->pixels.area.x0;
		unsigned int dh = dimage->pixels.area.y1 - dimage->pixels.area.y0;
		unsigned int th = timage->pixels.area.y1 - timage->pixels.area.y0;
		if (scaled) {
			// Ensure map size
			if ((dw > mapsize) || (dh > mapsize)) {
				if (dw > mapsize) dw = mapsize;
				if (dh > mapsize) dh = mapsize;
				NRImage *tmp = nr_image_new ();
				nr_pixblock_release (&tmp->pixels);
				nr_pixblock_setup (&tmp->pixels, dimage->pixels.mode, 0, 0, dw, dh, false);
				nr_pixblock_scale (&tmp->pixels, &dimage->pixels);
				nr_image_unref (dimage);
				dimage = tmp;
			}
			if ((tw != dw) || (th != dh)) {
				tw = dw;
				th = dh;
				NRImage *tmp = nr_image_new ();
				nr_pixblock_release (&tmp->pixels);
				nr_pixblock_setup (&tmp->pixels, timage->pixels.mode, 0, 0, tw, th, false);
				nr_pixblock_scale (&tmp->pixels, &timage->pixels);
				nr_image_unref (timage);
				timage = tmp;
			}
		}
		// Ensure diffuse is in RGBA mode
		if (dimage->pixels.mode == NR_PIXBLOCK_MODE_G8) {
			NRImage *tmp = nr_image_new ();
			nr_pixblock_release (&tmp->pixels);
			nr_pixblock_setup (&tmp->pixels, NR_PIXBLOCK_MODE_R8G8B8A8N, 0, 0, dw, dh, false);
			unsigned int dbpp = NR_PIXBLOCK_BPP (&tmp->pixels);
			unsigned int sbpp = NR_PIXBLOCK_BPP (&dimage->pixels);
			for (unsigned int y = 0; y < dh; y++) {
				unsigned char *d = NR_PIXBLOCK_PX (&tmp->pixels) + y * tmp->pixels.rs;
				const unsigned char *s = NR_PIXBLOCK_PX (&dimage->pixels) + y * dimage->pixels.rs;
				for (unsigned int x = 0; x < dw; x++) {
					d[0] = s[0];
					d[1] = s[0];
					d[2] = s[0];
					d[3] = 255;
					d += dbpp;
					s += sbpp;
				}
			}
			tmp->pixels.empty = 0;
			nr_image_unref (dimage);
			dimage = tmp;
		} else if (dimage->pixels.mode == NR_PIXBLOCK_MODE_R8G8B8) {
			NRImage *tmp = nr_image_new ();
			nr_pixblock_release (&tmp->pixels);
			nr_pixblock_setup (&tmp->pixels, NR_PIXBLOCK_MODE_R8G8B8A8N, 0, 0, dw, dh, false);
			unsigned int dbpp = NR_PIXBLOCK_BPP (&tmp->pixels);
			unsigned int sbpp = NR_PIXBLOCK_BPP (&dimage->pixels);
			for (unsigned int y = 0; y < dh; y++) {
				unsigned char *d = NR_PIXBLOCK_PX (&tmp->pixels) + y * tmp->pixels.rs;
				const unsigned char *s = NR_PIXBLOCK_PX (&dimage->pixels) + y * dimage->pixels.rs;
				for (unsigned int x = 0; x < dw; x++) {
					d[0] = s[0];
					d[1] = s[1];
					d[2] = s[2];
					d[3] = 255;
					d += dbpp;
					s += sbpp;
				}
			}
			tmp->pixels.empty = 0;
			nr_image_unref (dimage);
			dimage = tmp;
		}
		// Ensure mask in in G8 mode
		if (timage->pixels.mode == NR_PIXBLOCK_MODE_R8G8B8) {
			NRImage *tmp = nr_image_new ();
			nr_pixblock_release (&tmp->pixels);
			nr_pixblock_setup (&tmp->pixels, NR_PIXBLOCK_MODE_G8, 0, 0, dw, dh, false);
			unsigned int dbpp = NR_PIXBLOCK_BPP (&tmp->pixels);
			unsigned int sbpp = NR_PIXBLOCK_BPP (&timage->pixels);
			for (unsigned int y = 0; y < dh; y++) {
				unsigned char *d = NR_PIXBLOCK_PX (&tmp->pixels) + y * tmp->pixels.rs;
				const unsigned char *s = NR_PIXBLOCK_PX (&timage->pixels) + y * timage->pixels.rs;
				for (unsigned int x = 0; x < dw; x++) {
					d[0] = s[0];
					d += dbpp;
					s += sbpp;
				}
			}
			tmp->pixels.empty = 0;
			nr_image_unref (timage);
			timage = tmp;
		}
		// No rescaling
		NRImage *img = nr_image_new ();
		nr_pixblock_release (&img->pixels);
		nr_pixblock_setup (&img->pixels, NR_PIXBLOCK_MODE_R8G8B8A8N, 0, 0, dw, dh, false);
		nr_blit_pixblock_pixblock_mask (&img->pixels, &dimage->pixels, &timage->pixels);
		img->pixels.empty = 0;
		nr_image_unref (dimage);
		nr_image_unref (timage);
		return img;
	} else {
		nr_image_ref (images[DIFFUSE]);
		return images[DIFFUSE];
	}
}

void
MaterialDNS::updateSehleMaterial (unsigned int maps)
{
	Sehle::MaterialMultipassDNS *dns = (Sehle::MaterialMultipassDNS *) smat;
	if (maps) {
		for (unsigned int i = 0; i < NUM_MAPS; i++) loadImage (i);
		if (images[DIFFUSE] && !images[DIFFUSE]->pixels.empty) {
			NRImage *img = getDiffuseImage (true);
			if (img) {
				dns->setMap (Sehle::MaterialMultipassDNS::COLOR, (!images[TRANSPARENCY]) ? urls[DIFFUSE] : NULL, &img->pixels);
				nr_image_unref (img);
			}
		} else {
			dns->setMap (Sehle::MaterialMultipassDNS::COLOR, NULL, NULL);
		}
		if (images[SPECULAR] && !images[SPECULAR]->pixels.empty) {
			dns->setMap (Sehle::MaterialMultipassDNS::SPECULAR, urls[SPECULAR], &images[SPECULAR]->pixels);
		} else {
			dns->setMap (Sehle::MaterialMultipassDNS::SPECULAR, NULL, NULL);
		}
		if (images[NORMAL] && !images[NORMAL]->pixels.empty) {
			dns->setMap (Sehle::MaterialMultipassDNS::NORMAL, urls[NORMAL], &images[NORMAL]->pixels);
		} else {
			dns->setMap (Sehle::MaterialMultipassDNS::NORMAL, NULL, NULL);
		}
	}
	dns->setDiffuse (&diffuseColor);
	dns->setSpecular (&specularColor);
	dns->setShininess (shininess);
	if (filltype == SOLID) {
		dns->setStateFlags (Sehle::RenderContext::FILL);
	} else {
		dns->clearStateFlags (Sehle::RenderContext::FILL);
	}
}

} // Namespace Miletos
