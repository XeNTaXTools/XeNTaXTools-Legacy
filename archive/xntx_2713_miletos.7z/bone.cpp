#define __MILETOS_BONE_CPP__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2008
//

static const int debug = 1;

#include <stdio.h>
#include <malloc.h>

#include "xml/base.h"
#include "figure.h"
#include "skeleton.h"
#include "connect.h"

#include "bone.h"

#ifdef WIN32
#define strcasecmp strcmpi
#endif

namespace Miletos {

// Bone

static const int order_xyz[] = { 0, 1, 2 };
static const int order_xzy[] = { 0, 2, 1 };
static const int order_yxz[] = { 1, 0, 2 };
static const int order_yzx[] = { 1, 2, 0 };
static const int order_zxy[] = { 2, 0, 1 };
static const int order_zyx[] = { 2, 1, 0 };

static const Bone::Tension defaulttension = { 1, { -Elea::M_2PI_F, Elea::M_2PI_F }, { 1.0f, 1.0f }};

Bone::Bone (void)
: Object(HAS_CHILDREN),
sid(NULL), mirror(NULL),
b2p_set(0), ab2p_set(0),
axisorder(order_xyz),
bbox(Elea::Cuboid3fEmpty), animbbox(Elea::Cuboid3fEmpty), vLength(1), visible(1),
nchildbones(0), childbones(NULL),
skeleton(NULL), index(-1)
{
	for (int i = 0; i < 3; i++) tension[i] = defaulttension;
}

Bone::~Bone (void)
{
	if (sid) free (sid);
	if (mirror) free (mirror);
}

static Object *
bone_factory (void)
{
	return new Bone();
}

const Object::Type *
Bone::objectType (void)
{
	return type ();
}

const Object::Type *
Bone::type (void)
{
	static Type *mytype = NULL;
	static const Attribute attrs[] = {
		{ "sid", NULL, 0 },
		{ "orientation", "identity", 0 },
		{ "animatedOrientation", "identity", 0 },
		{ "vOrientation", "identity", 0 },
		{ "vLength", "1", 0 },
		{ "mirror", NULL, 0 },
		{ "axisOrder", NULL, 0 },
		{ "tensionX", NULL, 0 },
		{ "tensionY", NULL, 0 },
		{ "tensionZ", NULL, 0 },
		{ "visible", "true", 0 }
	};
	if (!mytype) mytype = new Type(Object::type (), "Bone", "bone", bone_factory, sizeof (attrs) / sizeof (attrs[0]), attrs);
	return mytype;
}

void
Bone::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	Object::build (pnode, doc, ctx);

	updateChildData (NULL);

	buildAllAttributes (type (), ctx);
}

void
Bone::release (void)
{
	if (skeleton) detachFromSkeleton (skeleton);

	if (childbones) {
		free (childbones);
		childbones = NULL;
		nchildbones = 0;
	}

	Object::release ();
}

Object *
Bone::childAdded (Thera::Node *cnode, Thera::Node *rnode)
{
	Object *cobj = Object::childAdded (cnode, rnode);

	updateChildData (NULL);

	return cobj;
}

void
Bone::childRemoved (Thera::Node *cnode, Thera::Node *rnode)
{
	updateChildData (cnode);

	Object::childRemoved (cnode, rnode);
}

void
Bone::set (const char *attrid, const char *val)
{
	if (!strcmp (attrid, "sid")) {
		if (sid) free (sid);
		sid = (val) ? strdup (val) : NULL;
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "orientation")) {
		Orientation pos;
		if (XML::parseOrientation (pos.p, pos.q, val)) {
			b2p.setRotation (pos.q);
			b2p.setTranslation (pos.p);
			b2p_set = 1;
		} else {
			b2p_set = 0;
			b2p = Elea::Matrix3x4fIdentity;
		}
		if (!ab2p_set) {
			ab2p = b2p;
		}
		requestUpdate (ANIMATION_MODIFIED);
	} else if (!strcmp (attrid, "animatedOrientation")) {
		Orientation animpos;
		if (XML::parseOrientation (animpos.p, animpos.q, val)) {
			ab2p.setRotation (animpos.q);
			ab2p.setTranslation (animpos.p);
			ab2p_set = 1;
		} else {
			ab2p_set = 0;
			ab2p = Elea::Matrix3x4fIdentity;
		}
		requestUpdate (MODIFIED | ANIMATION_MODIFIED);
	} else if (!strcmp (attrid, "vOrientation")) {
		if (XML::parseOrientation (vOrientation.p, vOrientation.q, val)) {
			vOrientation.set = true;
		} else {
			vOrientation.set = false;
			vOrientation.p = Elea::Vector3f0;
			vOrientation.q = Elea::Quaternionf0;
		}
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "vLength")) {
		if (!XML::parseNumber (&vLength, val)) vLength = 0.1f;
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "mirror")) {
		if (mirror) free (mirror);
		mirror = (val) ? strdup (val) : NULL;
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "axisOrder")) {
		if (!val) {
			axisorder = order_xyz;
		} else if (!strcasecmp (val, "xzy")) {
			axisorder = order_xzy;
		} else if (!strcasecmp (val, "yxz")) {
			axisorder = order_yxz;
		} else if (!strcasecmp (val, "yzx")) {
			axisorder = order_yzx;
		} else if (!strcasecmp (val, "zxy")) {
			axisorder = order_zxy;
		} else if (!strcasecmp (val, "zyx")) {
			axisorder = order_zyx;
		} else {
			axisorder = order_xyz;
		}
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "tensionX")) {
		setTension (&tension[0], val);
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "tensionY")) {
		setTension (&tension[1], val);
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "tensionZ")) {
		setTension (&tension[2], val);
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "visible")) {
		if (!XML::parseBoolean (&visible, val)) visible = true;
		requestUpdate (MODIFIED);
	}
	// Object does not implement set
}

void
Bone::setTension (Tension *tension, const char *val)
{
	float v[5];
	if (XML::parseNumbers (v, 5, val)) {
		tension->enabled = (v[0] != 0);
		tension->threshold[0] = v[1];
		tension->rigidity[0] = v[2];
		tension->threshold[1] = v[3];
		tension->rigidity[1] = v[4];
		if (tension->threshold[0] >= 0) tension->enabled = false;
		if (tension->threshold[1] <= 0) tension->enabled = false;
		for (int i = 0; i < 2; i++) {
			if (tension->rigidity[i] < 0) tension->enabled = false;
		}
	} else {
		*tension = defaulttension;
	}
}

void
Bone::write (const char *attrid)
{
	// Object does not implement set
	if (!strcmp (attrid, "animatedOrientation")) {
		Elea::Matrix4x4f ab2p4(ab2p);
		Orientation animpos;
		animpos.q = ab2p4.getRotationQuaternion ();
		animpos.p = ab2p4.getTranslation ();
		if ((animpos.p == Elea::Vector3f0) && (animpos.q == Elea::Quaternionf0)) {
			node->setAttribute (attrid, "null");
		} else {
			char c[256];
			XML::writeOrientation (c, 256, animpos.q, animpos.p, true);
			node->setAttribute (attrid, c);
		}
	} else if (!strcmp (attrid, "visible")) {
		node->setAttribute (attrid, (visible) ? "1" : "0");
	} else if (!strcmp (attrid, "tensionX")) {
		char c[256];
		int len = XML::writeInteger (c, 256, tension[0].enabled);
		c[len++] = ' ';
		len += XML::writeNumber (c + len, 256 - len, tension[0].threshold[0]);
		c[len++] = ' ';
		len += XML::writeNumber (c + len, 256 - len, tension[0].rigidity[0]);
		c[len++] = ' ';
		len += XML::writeNumber (c + len, 256 - len, tension[0].threshold[1]);
		c[len++] = ' ';
		len += XML::writeNumber (c + len, 256 - len, tension[0].rigidity[1]);
		node->setAttribute (attrid, c);
	} else if (!strcmp (attrid, "tensionY")) {
		char c[256];
		int len = XML::writeInteger (c, 256, tension[1].enabled);
		c[len++] = ' ';
		len += XML::writeNumber (c + len, 256 - len, tension[1].threshold[0]);
		c[len++] = ' ';
		len += XML::writeNumber (c + len, 256 - len, tension[1].rigidity[0]);
		c[len++] = ' ';
		len += XML::writeNumber (c + len, 256 - len, tension[1].threshold[1]);
		c[len++] = ' ';
		len += XML::writeNumber (c + len, 256 - len, tension[1].rigidity[1]);
		node->setAttribute (attrid, c);
	} else if (!strcmp (attrid, "tensionZ")) {
		char c[256];
		int len = XML::writeInteger (c, 256, tension[2].enabled);
		c[len++] = ' ';
		len += XML::writeNumber (c + len, 256 - len, tension[2].threshold[0]);
		c[len++] = ' ';
		len += XML::writeNumber (c + len, 256 - len, tension[2].rigidity[0]);
		c[len++] = ' ';
		len += XML::writeNumber (c + len, 256 - len, tension[2].threshold[1]);
		c[len++] = ' ';
		len += XML::writeNumber (c + len, 256 - len, tension[2].rigidity[1]);
		node->setAttribute (attrid, c);
	} else if (debug) {
		fprintf (stderr, "Unhandled item::write %s\n", attrid);
	}
}

void
Bone::update (UpdateCtx *ctx, unsigned int flags)
{
	if (flags & ANIMATION_MODIFIED) {
		if (parent && parent->isType (Bone::type ())) {
			Bone *pbone = (Bone *) parent;
			UpdatePositionMatrixes (pbone->o2b);
			UpdateAnimationMatrixes (pbone->ab2o);
		} else {
			UpdatePositionMatrixes (Elea::Matrix3x4fIdentity);
			UpdateAnimationMatrixes (Elea::Matrix3x4fIdentity);
		}
	}

	Object::update (ctx, flags);
}

void
Bone::updateChildData (Thera::Node *removed)
{
	nchildbones = listChildrenOfType (Bone::type (), (Object ***) &childbones, removed);
	if (skeleton) {
		skeleton->boneTreeModified ();
	}
}

void
Bone::setAB2P (const Elea::Matrix3x4f& pab2p)
{
	ab2p = pab2p;
	// fixme: We have to update PMesh animations immediately or otherwise or the delay will be 2 cycles
	// fixme: Think (Lauris)
	if (skeleton) skeleton->updateBoneAnimation (this, index);
	// if (mesh) mesh->updateBoneAnimation (this, skelidx);
	requestUpdate (MODIFIED | ANIMATION_MODIFIED);
}

Elea::Matrix3x4f
Bone::getAB2O (void)
{
	// fixme:
	return ab2o;
}

void
Bone::setAB2O (const Elea::Matrix3x4f& pab2o)
{
	Elea::Matrix3x4f p2o;
	if (parent && parent->isType (Bone::type ())) {
		Elea::Matrix3x4f p2o = ((Bone *) parent)->getAB2O ();
	}
	Elea::Matrix3x4f o2p;
	p2o.invertNormalized (&o2p);
	setAB2P (o2p * pab2o);
}

Elea::Matrix3x4f
Bone::getAB2W (const Elea::Matrix3x4f& o2w)
{
	return o2w * ab2o;
}

void
Bone::setAB2W (const Elea::Matrix3x4f& pab2w, const Elea::Matrix3x4f& o2w)
{
	Elea::Matrix3x4f p2o;
	if (parent && parent->isType (Bone::type ())) {
		p2o = ((Bone *) parent)->getAB2O ();
	}
	Elea::Matrix3x4f p2w = o2w * p2o;
	Elea::Matrix3x4f w2p;
	p2w.invertNormalized (&w2p);
	setAB2P (w2p * pab2w);
}

void
Bone::UpdatePositionMatrixes (const Elea::Matrix3x4f& o2p)
{
	Elea::Matrix3x4f p2b;
	b2p.invertNormalized (&p2b);
	// Elea::Matrix4x4f b2o(p2o * b2p);
	// b2o.invert (&object2bone);
	o2b = p2b * o2p;
	for (int i = 0; i < nchildbones; i++) {
		childbones[i]->UpdatePositionMatrixes (o2b);
	}
}

void
Bone::UpdateAnimationMatrixes (const Elea::Matrix3x4f& ap2o)
{
	ab2o = ap2o * ab2p;
	if (skeleton) skeleton->updateBoneAnimation (this, index);
	for (int i = 0; i < nchildbones; i++) {
		childbones[i]->UpdateAnimationMatrixes (ab2o);
	}
}

void
Bone::attachToSkeleton (Skeleton *pskeleton)
{
	assert (!skeleton);
	assert (index < 0);
	assert (isParent (pskeleton));
	assert (pskeleton->isType (Skeleton::type ()));

	skeleton = pskeleton;
	index = skeleton->registerBone (this);

	for (int i = 0; i < nchildbones; i++) {
		childbones[i]->attachToSkeleton (skeleton);
	}
}

void
Bone::detachFromSkeleton (Skeleton *pskeleton)
{
	assert (!skeleton || (skeleton == pskeleton));

	if (!skeleton) return;

	skeleton = NULL;
	index = -1;

	for (int i = 0; i < nchildbones; i++) {
		if (childbones[i]->skeleton) childbones[i]->detachFromSkeleton (pskeleton);
	}
}

float
Bone::calculateTension (const Tension *tension, float angle)
{
	// Tension = rigidity * pow (angle / treshold, 1.25) + pow (angle / treshold, 16)
	if (angle > 0) {
		float t = angle / tension->threshold[1];
		return tension->rigidity[1] * pow (t, 1.25f) + pow (t, 16);
	} else if (angle < 0) {
		float t = angle / tension->threshold[0];
		return tension->rigidity[0] * pow (t, 1.25f) + pow (t, 16);
	}
	return 0;
}

float
Bone::calculateDTension (const Tension *tension, float angle)
{
	// Tension = rigidity * pow (angle / treshold, 1.25) + pow (angle / treshold, 16)
	// DTension =  rigidity * 1.25 * pow (angle / treshold, 0.25) + 16 * pow (angle / treshold, 15)
	if (angle > 0) {
		float t = angle / tension->threshold[1];
		return tension->rigidity[1] * 1.25f * pow (t, 0.25f) + 16 * pow (t, 15);
	} else if (angle < 0) {
		float t = angle / tension->threshold[0];
		return tension->rigidity[0] * 1.25f * pow (t, 0.25f) + 16 * pow (t, 15);
	}
	return 0;
}

} // Namespace Miletos
