#define __MILETOS_SCENE_CPP__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2007
//

static const int debug = 1;

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

#include <elea/line.h>

#include <sehle/graph.h>
#include <sehle/renderable.h>

#include "xml/base.h"
#include "camera.h"

#include "scene.h"

namespace Miletos {

// Unknown

const Object::Type *
Unknown::objectType (void)
{
	return type ();
}

const Object::Type *
Unknown::type (void)
{
	static Type *mytype = NULL;
	if (!mytype) mytype = new Type(Object::type (), "Unknown", NULL, NULL, 0, NULL);
	return mytype;
}

void
Unknown::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	if (debug) fprintf (stderr, "Built unknown object %s:%s (%s)\n", ctx->defaultns, pnode->name, pnode->getAttribute ("id"));
}

void
Unknown::release (void)
{
	if (debug) fprintf (stderr, "Released unknown object %s (%s)\n", node->name, node->getAttribute ("id"));
}

void
Unknown::set (const char *attrid, const char *val)
{
	if (debug) fprintf (stderr, "Set unknown object %s (%s) : %s = %s\n", node->name, node->getAttribute ("id"), attrid, val);
}

unsigned int
Unknown::addChild (Thera::Node *cnode, Thera::Node *rnode)
{
	if (debug) fprintf (stderr, "Trying to add child to unknown object %s (%s) : %s\n", node->name, node->getAttribute ("id"), cnode->name);
	return 0;
}

// Text

const Object::Type *
Text::objectType (void)
{
	return type ();
}

const Object::Type *
Text::type (void)
{
	static Type *mytype = NULL;
	if (!mytype) mytype = new Type(Object::type (), "Text", NULL, NULL, 0, NULL);
	return mytype;
}

void
Text::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	if (debug) fprintf (stderr, "Built text object %s:%s (%s)\n", ctx->defaultns, pnode->name, pnode->getAttribute ("id"));
}

void
Text::release (void)
{
	if (debug) fprintf (stderr, "Released text object %s (%s)\n", node->name, node->getAttribute ("id"));
}

// Defs

const Object::Type *
Defs::objectType (void)
{
	return type ();
}

const Object::Type *
Defs::type (void)
{
	static Type *mytype = NULL;
	if (!mytype) mytype = new Type(Object::type (), "Defs", "defs", NULL, 0, NULL);
	return mytype;
}

// Item

const Object::Type *
Item::objectType (void)
{
	return type ();
}

const Object::Type *
Item::type (void)
{
	static Type *mytype = NULL;
	static const Attribute attrs[] = {
		{ "transform", NULL, 0 },
		{ "visibility", NULL, 0 },
		{ "traceMask", NULL, 0 }
	};
	if (!mytype) mytype = new Type(Object::type (), "Item", NULL, NULL, sizeof (attrs) / sizeof (attrs[0]), attrs);
	return mytype;
}

void
Item::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	Object::build (pnode, doc, ctx);

	buildAllAttributes (type (), ctx);

}

void
Item::release (void)
{
	// Items should be hidden before releasing
	assert (!renderable);
	Object::release ();
}

void
Item::set (const char *attrid, const char *val)
{
	// Object does not implement set
	if (!strcmp (attrid, "transform")) {
		_i2p = Elea::Matrix4x4fIdentity;
		XML::parseTransform (_i2p, val);
		requestUpdate (TRANSFORMATION_MODIFIED);
	} else if (!strcmp (attrid, "visibility")) {
		i32 vis;
		if (XML::parseInteger (&vis, val)) {
			visibility = vis;
		} else {
			visibility = 0xffffffff;
		}
		if (renderable) renderable->setContextMask (visibility);
	} else if (!strcmp (attrid, "traceMask")) {
		tracemask = (val) ? atoi(val) : 0xffffffff;
	} else if (debug) {
		fprintf (stderr, "Unhandled item::set %s = %s", attrid, val);
	}
}

void
Item::write (const char *attrid)
{
	// Object does not implement set
	if (!strcmp (attrid, "transform")) {
		if (_i2p == Elea::Matrix4x4fIdentity) {
			node->setAttribute (attrid, "null");
		} else {
			char c[256];
			XML::writeMatrix (c, 256, _i2p, false);
			node->setAttribute (attrid, c);
		}
	} else if (!strcmp (attrid, "visibility")) {
		node->setAttributeUint (attrid, visibility);
	} else if (!strcmp (attrid, "traceMask")) {
		node->setAttributeUint (attrid, tracemask);
	} else if (debug) {
		fprintf (stderr, "Unhandled item::write %s\n", attrid);
	}
}

void
Item::update (UpdateCtx *ctx, unsigned int flags)
{
	// We do not call Object::update because subclasses may want to fine-tune tree updating

	_i2w = ctx->i2w;
	_i2w.invert (&_w2i);

	if (renderable) {
		Elea::Matrix3x4f m3(_i2w);
		renderable->setTransform (&m3);
		renderable->setBBox (&bbox);
	}
}

Sehle::Renderable *
Item::invokeShow (Sehle::Graph *pgraph, Sehle::u32 contextmask)
{
	assert (!renderable);
	// fixme: Think about visibility (Lauris)
	graph = pgraph;
	renderable = show (graph, contextmask & visibility);
	if (renderable) {
		Elea::Matrix3x4f m3(_i2w);
		renderable->setTransform (&m3);
		renderable->setBBox (&bbox);
	}
	return renderable;
}

void
Item::invokeHide (Sehle::RenderableGroup *pgroup)
{
	assert (renderable);
	hide (pgroup);
	if (pgroup) pgroup->removeChild (renderable);
	delete renderable;
	renderable = NULL;
	graph = NULL;
}

Item *
Item::invokeTrace (const Elea::Line3f *wray, unsigned int mask, float *distance)
{
	if (!(mask & tracemask)) return NULL;
	float p0, p1;
	if (!bbox.getIntersection (*wray, p0, p1)) return NULL;
	return trace (wray, mask, distance);
}

Item *
Item::invokeTrace (const Elea::Line3f *wray, unsigned int mask, const Elea::Matrix4x4f *e2us, float *distance, Elea::Vector3f *uscp)
{
	if (!(mask & tracemask)) return NULL;
	Elea::Cuboid3f c(e2us->transform (bbox));
	for (int i = 0; i < 3; i++) {
		c[i] -= 1;
		c[3 + i] += 1;
	}
	Elea::Line3f r(e2us->transform (*wray));
	float p0, p1;
	if (!c.getIntersection (r, p0, p1)) return NULL;
	return trace (wray, mask, e2us, distance, uscp);
}

void
Item::setI2P (const Elea::Matrix4x4f *pi2p)
{
	if (!pi2p) {
		_i2p = Elea::Matrix4x4fIdentity;
	} else {
		_i2p = *pi2p;
	}
	requestUpdate (TRANSFORMATION_MODIFIED);
}

Elea::Matrix4x4f
Item::getI2W (void) const
{
	Elea::Matrix4x4f i2w = _i2p;
	Object *c = (Object *) this;
	Object *p = parent;
	while (p->isType (Item::type ())) {
		Elea::Matrix4x4f c2gp;
		((Miletos::Item *) p)->getC2P (&c2gp, (Item *) c);
		i2w = c2gp * i2w;
		c = p;
		p = p->parent;
	}
	return i2w;
}

void
Item::setI2W (const Elea::Matrix4x4f *ni2w)
{
	Elea::Matrix4x4f i2w = getI2W ();
	Elea::Matrix4x4f w2i = i2w.invert ();
	// fixme:
	// fprintf (stderr, "Item::setI2W: transforms may be not correct if update is not processed\n");
	Elea::Matrix4x4f nw2p(_i2p * w2i);
	Elea::Matrix4x4f ni2p(nw2p * (*ni2w));
	setI2P (&ni2p);
}

void
Item::getC2P (Elea::Matrix4x4f *c2p, Miletos::Item *child)
{
	*c2p = _i2p;
}

// Group

static Object *
group_factory (void)
{
	return new Group();
}

const Object::Type *
Group::objectType (void)
{
	return type ();
}

const Object::Type *
Group::type (void)
{
	static Type *mytype = NULL;
	if (!mytype) mytype = new Type(Item::type (), "Group", "group", group_factory, 0, NULL);
	return mytype;
}

void
Group::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	// Superclass implementation
	Item::build (pnode, doc, ctx);
}

void
Group::release (void)
{
	// Superclass implementation
	Item::release ();
}

void
Group::set (const char *attrid, const char *val)
{
	// Superclass implementation
	Item::set (attrid, val);
}

void
Group::update (UpdateCtx *ctx, unsigned int flags)
{
	// Rewrite flags
	if (flags & MODIFIED) flags |= PARENT_MODIFIED;
	flags &= MODIFIED_CASCADE;
	// Update children
	for (Object *child = children; child; child = child->next) {
		if (flags || child->updateFlagIsSet (MODIFIED_STATE)) {
			if (child->isType (Item::type ())) {
				Item *ichild = (Item *) child;
				UpdateCtx cctx;
				cctx.i2w = ctx->i2w * ichild->getI2P ();
				child->invokeUpdate (&cctx, flags);
			} else {
				child->invokeUpdate (ctx, flags);
			}
		}
	}
	// Set bbox
	bbox.setEmpty ();
	for (Object *child = children; child; child = child->next) {
		if (child->isType (Item::type ())) {
			Item *ichild = (Item *) child;
			bbox.grow (ichild->bbox);
		}
	}
	// Superclass implementation
	// Currently this simply set renderable bbox
	Item::update (ctx, flags);
}

void
Group::modified (unsigned int flags)
{
	// Superclass implementation
	Item::modified (flags);
}

Object *
Group::childAdded (Thera::Node *cnode, Thera::Node *rnode)
{
	Object *child = Item::childAdded (cnode, rnode);
	if (renderable && child->isType (Item::type ())) {
		Item *ichild = (Item *) child;
		Sehle::Renderable *rchild = ichild->invokeShow (renderable->graph, 0xffffffff);
		// fixme: Should append (Lauris)
		Sehle::RenderableGroup *rgroup = (Sehle::RenderableGroup *) renderable;
		if (rchild) rgroup->prependChild (rchild);
	}
	return child;
}

unsigned int
Group::removeChild (Thera::Node *cnode, Thera::Node *rnode)
{
	if (renderable) {
		for (Object *child = children; child; child = child->next) {
			if (child->node == cnode) {
				if (child->isType (Item::type ())) {
					((Item *) child)->invokeHide ((Sehle::RenderableGroup *) renderable);
				}
				break;
			}
		}
	}
	return Item::removeChild (cnode, rnode);
}

Sehle::Renderable *
Group::show (Sehle::Graph *graph, Sehle::u32 contextmask)
{
	Sehle::RenderableGroup *rgroup = new Sehle::RenderableGroup(graph, contextmask);
	for (Object *child = children; child; child = child->next) {
		if (child->isType (Item::type ())) {
			Item *ichild = (Item *) child;
			Sehle::Renderable *rchild = ichild->invokeShow (graph, contextmask);
			// fixme: Should append (Lauris)
			if (rchild) rgroup->prependChild (rchild);
		}
	}
	return rgroup;
}

void
Group::hide (Sehle::RenderableGroup *pgroup)
{
	for (Object *child = children; child; child = child->next) {
		if (child->isType (Item::type ())) {
			Item *ichild = (Item *) child;
			ichild->invokeHide ((Sehle::RenderableGroup *) renderable);
		}
	}
}

Item *
Group::trace (const Elea::Line3f *ray, unsigned int mask, float *distance)
{
	Item *tchild = NULL;
	float bestd = Elea::OMEGA_F;
	for (Object *child = children; child; child = child->next) {
		if (child->isType (Item::type ())) {
			Item *ichild = (Item *) child;
			float d;
			Item *tch = ichild->invokeTrace (ray, mask, &d);
			if ((d > 0) && (d < bestd)) {
				bestd = d;
				tchild = tch;
			}
		}
	}
	if (tchild) *distance = bestd;
	return tchild;
}

// Scene

static Object *
scene_factory (void)
{
	return new Scene();
}

const Object::Type *
Scene::objectType (void)
{
	return type ();
}

const Object::Type *
Scene::type (void)
{
	static Type *mytype = NULL;
	static const Attribute attrs[] = {
		{ "ambientLight", "white", 0 }
	};
	if (!mytype) mytype = new Type(Object::type (), "Scene", "scene", scene_factory, sizeof (attrs) / sizeof (attrs[0]), attrs);
	return mytype;
}

void
Scene::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	Object::build (pnode, doc, ctx);
	buildAllAttributes (type (), ctx);
	updateChildData (NULL);
}

void
Scene::release (void)
{
	if (cameras) {
		ncameras = 0;
		free (cameras);
		cameras = NULL;
	}
	Object::release ();
}

Object *
Scene::childAdded (Thera::Node *cnode, Thera::Node *rnode)
{
	Object *child = Object::childAdded (cnode, rnode);
	updateChildData (NULL);
	if (rgroup && child->isType (Item::type ())) {
		Item *ichild = (Item *) child;
		Sehle::Renderable *rchild = ichild->invokeShow (rgroup->graph, 0xffffffff);
		// fixme: Should append (Lauris)
		if (rchild) rgroup->prependChild (rchild);
	}
	return child;
}

unsigned int
Scene::removeChild (Thera::Node *cnode, Thera::Node *rnode)
{
	updateChildData (cnode);
	if (rgroup) {
		for (Object *child = children; child; child = child->next) {
			if (child->node == cnode) {
				if (child->isType (Item::type ())) {
					((Item *) child)->invokeHide (rgroup);
				}
				break;
			}
		}
	}
	return Object::removeChild (cnode, rnode);
}

void
Scene::set (const char *attrid, const char *val)
{
	if (!strcmp (attrid, "ambientLight")) {
		if (!XML::parseColor (&ambient, val)) {
			ambient = Elea::Color4fWhite;
		}
		requestUpdate (MODIFIED);
	} else {
		if (debug) fprintf (stderr, "Unhandled scene::set %s = %s", attrid, val);
	}
}

void
Scene::write (const char *attrid)
{
	char c[256];
	if (!strcmp (attrid, "ambientLight")) {
		XML::writeColor (c, 64, ambient, false);
		node->setAttribute (attrid, c);
	}
}

void
Scene::update (UpdateCtx *ctx, unsigned int flags)
{
	// Rewrite flags
	if (flags & MODIFIED) flags |= PARENT_MODIFIED;
	flags &= MODIFIED_CASCADE;
	// Update children
	for (Object *child = children; child; child = child->next) {
		if (flags || child->updateFlagIsSet (MODIFIED_STATE)) {
			if (child->isType (Item::type ())) {
				Item *ichild = (Item *) child;
				UpdateCtx cctx;
				cctx.i2w = ctx->i2w * ichild->getI2P ();
				child->invokeUpdate (&cctx, flags);
			} else {
				child->invokeUpdate (ctx, flags);
			}
		}
	}
	// Set bbox
	Elea::Cuboid3f bbox(Elea::Cuboid3fEmpty);
	for (Object *child = children; child; child = child->next) {
		if (child->isType (Item::type ())) {
			Item *ichild = (Item *) child;
			bbox.grow (ichild->bbox);
		}
	}
	// Set renderable bbox
	if (rgroup) rgroup->setBBox (&bbox);
}

void
Scene::modified (unsigned int flags)
{
	Object::modified (flags);
}

void
Scene::show (Sehle::Graph *graph)
{
	rgroup = new Sehle::RenderableGroup(graph, 0xffffffff);
	graph->addRenderable (rgroup);
	for (Object *child = children; child; child = child->next) {
		if (child->isType (Item::type ())) {
			Item *ichild = (Item *) child;
			Sehle::Renderable *rchild = ichild->invokeShow (graph, 0xffffffff);
			// fixme: Should append (Lauris)
			if (rchild) rgroup->prependChild (rchild);
		}
	}

	// _rgroup->invokeBBox (true);
}

void
Scene::hide (void)
{
	for (Object *child = children; child; child = child->next) {
		if (child->isType (Item::type ())) {
			Item *ichild = (Item *) child;
			ichild->invokeHide (rgroup);
		}
	}
	// fixme: Destroy renferable
	rgroup = NULL;
}

Item *
Scene::trace (const Elea::Line3f *wray, unsigned int mask, float *distance)
{
	Item *tchild = NULL;
	float bestd = Elea::OMEGA_F;
	for (Object *child = children; child; child = child->next) {
		if (child->isType (Item::type ())) {
			Item *ichild = (Item *) child;
			float d;
			Item *tch = ichild->invokeTrace (wray, mask, &d);
			if (tch && (d > 0) && (d < bestd)) {
				bestd = d;
				tchild = tch;
			}
		}
	}
	if (tchild) *distance = bestd;
	return tchild;
}

Item *
Scene::trace (const Elea::Line3f *wray, unsigned int mask, const Elea::Matrix4x4f *e2us, float *distance, Elea::Vector3f *uscp)
{
	Item *tchild = NULL;
	float bestd = Elea::OMEGA_F;
	Elea::Vector3f bestcp(Elea::Vector3f0);
	for (Object *child = children; child; child = child->next) {
		if (child->isType (Item::type ())) {
			Item *ichild = (Item *) child;
			float d;
			Elea::Vector3f cp;
			Item *tch = ichild->invokeTrace (wray, mask, e2us, &d, &cp);
			if (tch && (d > 0) && (d < bestd)) {
				bestd = d;
				bestcp = cp;
				tchild = tch;
			}
		}
	}
	if (tchild) {
		if (distance) *distance = bestd;
		if (uscp) *uscp = bestcp;
	}
	return tchild;
}

void
Scene::updateChildData (Thera::Node *removed)
{
	ncameras = listChildrenOfType (Camera::type (), (Object ***) &cameras, removed);
}

void
Scene::setAmbient (const Elea::Color4f& color)
{
	ambient = color;

	requestModified (MODIFIED);
}

} // Namespace Miletos
