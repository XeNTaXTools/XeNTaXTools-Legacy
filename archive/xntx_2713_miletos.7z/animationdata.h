#ifndef __MILETOS_ANIMATIONDATA_H__
#define __MILETOS_ANIMATIONDATA_H__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2011
//

#include <miletos/animation.h>

namespace Miletos {

namespace Animation {

class BoneKeys : public Animation::BoneAnimation {
private:
	Elea::Vector3f p0;
	unsigned int ntimes;
	float *times;
	unsigned int npositions;
	float *positions;
	unsigned int nrotations;
	float *rotations;

	// Object implementation
	virtual const Type *objectType (void);
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	virtual void set (const char *attrid, const char *val);

	// BoneAnimation implementation
	virtual Elea::Vector3f getPosition (unsigned int frameidx);
	virtual Elea::Quaternionf getQuaternion (unsigned int frameidx);
public:
	char *sid;

	BoneKeys (void);
	virtual ~BoneKeys (void);

	// Type system
	static const Type *type (void);
};

} // Namespace Animation

} // Namespace Miletos

#endif

