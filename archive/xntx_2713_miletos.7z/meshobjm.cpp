#define __MILETOS_MESH_OBJM_CPP__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2008
//

static const int debug = 0;

#include <stdlib.h>
#include <stdio.h>

#include <libarikkei/arikkei-strlib.h>

#include <sehle/commonmaterials.h>
#include <sehle/material-multipass-dns.h>

#include "connect.h"
#include "filesystem.h"
#include "material.h"
#include "image.h"
#include "xfpk.h"
#include "xml/base.h"

#include "meshobjm.h"

namespace Miletos {

#define TAG(c) ((u32) (c[0]|(c[1]<<8)|(c[2]<<16)|c[3]<<24))

// Object tags
#define	TAG_OBJN TAG("OBJN")
#define	TAG_OBJM TAG("OBJM")
#define	TAG_OBJI TAG("OBJI")

// Component tags
#define	TAG_BLND TAG("BLND")
#define	TAG_MATE TAG("MATE")
#define	TAG_TEXT TAG("TEXT")
#define	TAG_LIGH TAG("LIGH")
#define	TAG_MESH TAG("MESH")
#define	TAG_FRAM TAG("FRAM")
#define	TAG_ANIM TAG("ANIM")
#define	TAG_MORP TAG("MORP")
#define	TAG_FOG	 TAG("FOG ")
#define	TAG_ENVL TAG("ENVL")
#define	TAG_CNST TAG("CNST")

static const float DefaultScale = 0.0702f;

struct OBJMData {
private:
	u32 refcount;

	// Memory buffer
	bool privmap;
	size_t usize;
	unsigned char *udata;

	// Constructor
	OBJMData (const char *pname, const unsigned char *pdata, size_t psize, bool pprivmap);
	// Destructor
	~OBJMData (void);

public:
	std::string name;

	struct OBJM_VERTEX;
	struct OBJM_MATE;
	struct OBJM_TEXT;
	struct OBJM_LIGH;
	struct OBJM_MESH_HEADER;
	struct OBJM_MESH_DATA;
	struct OBJM_FRAM;
	struct OBJM_BLND_HEADER;
	struct OBJM_BLND_DATA;
	struct OBJM_ANIM_HEADER;
	struct OBJM_ANIM_DATA;
	struct OBJM_ANIM_KEY;
	struct OBJM_MORP_HEADER;
	struct OBJM_MORP_DATA;
	struct OBJM_MORP_KEY;
	struct OBJM_CNST_HEADER;
	struct OBJM_CNST_DATA;

	struct Material {
		const OBJM_MATE *_data;
		int _materialidx;
		Material (const unsigned char *cdata) : _data((const OBJM_MATE *) cdata), _materialidx(-1) {}
	};
	std::vector<Material> materials;

	struct ObjmTextureData {
		const OBJM_TEXT *_data;
		std::string _name;
		u32 _id;
		std::string _filename;
		int _materialidx;
		bool isshadow;
	};
	std::vector<ObjmTextureData> _objmtextures;

	// fixme: It is quite possible that there can be > 1 meshes under single header (Lauris)
	struct Mesh {
		const OBJM_MESH_HEADER *_header;
		const OBJM_MESH_DATA *_data;
		const OBJM_VERTEX *_vdata;
		const u16 *_idata;
		std::vector<u32> _children;
		int _frameidx;
		int _morph;
		// The Cnst objects that refer to this mesh
		// Additional frames that morph this object

		std::vector<int> cnsts;
		std::vector<int> cnstframes;

		// The start of mesh vertices in global vertexbuffer
		int firstvertex;

		Mesh (const OBJM_MESH_HEADER *hdata, const OBJM_MESH_DATA *cdata, const OBJM_VERTEX *vdata, const u16 *idata) : _header(hdata), _data(cdata), _vdata(vdata), _idata(idata), _frameidx(-1), _morph(-1), firstvertex(-1) {}
	};
	std::vector<Mesh> meshes;

	struct Blend {
		const OBJM_BLND_HEADER *_header;
		const OBJM_BLND_DATA *_data;
		const OBJM_VERTEX *_vdata0;
		const OBJM_VERTEX *_vdata1;
		const u16 *_idata;
		Blend (const OBJM_BLND_HEADER *hdata, const OBJM_BLND_DATA *cdata, const OBJM_VERTEX *v0data, const OBJM_VERTEX *v1data, const u16 *idata) : _header(hdata), _data(cdata), _vdata0(v0data), _vdata1(v1data), _idata(idata) {}
	};
	std::vector<Blend> blends;

	struct ObjmFrame {
		const OBJM_FRAM *_data;
		i32 _parent;
		i32 _mesh;
		i32 _blend;
		i32 _child;

		// Frame to skin (object) transformation
		Elea::Matrix4x4f f2s;

		ObjmFrame (const unsigned char *cdata) : _data((const OBJM_FRAM *) cdata), _parent(-1), _mesh(-1), _blend(-1), _child(-1) {}
	};
	std::vector<ObjmFrame> _objmframes;

	struct FrameAnimation {
		const OBJM_ANIM_DATA *data;
		const OBJM_ANIM_KEY *keys;
		FrameAnimation (const OBJM_ANIM_DATA *pdata, const OBJM_ANIM_KEY *pkeys) : data(pdata), keys(pkeys) {}
	};

	struct Animation {
		const OBJM_ANIM_HEADER *header;
		std::vector<FrameAnimation> frameanims;
		Animation (const OBJM_ANIM_HEADER *pheader) : header(pheader) {}
	};
	std::vector<Animation> animations;

	struct MorphKey {
		const OBJM_MORP_KEY *_kdata;
		const OBJM_VERTEX *_vdata;
		const char *_cdata;
		// float _time;
		MorphKey (const OBJM_MORP_KEY *kdata, const OBJM_VERTEX *vdata, const char *cdata) : _kdata(kdata), _vdata(vdata), _cdata(cdata) {}
	};
	struct Morph {
		const OBJM_MORP_HEADER *_header;
		const OBJM_MORP_DATA *_data;
		int _mesh;
		std::vector<MorphKey> _keys;
		Morph (const OBJM_MORP_HEADER *header, const OBJM_MORP_DATA *data) : _header(header), _data(data), _mesh(-1) {}
	};
	std::vector<Morph> morphs;

	struct ObjmCnst {
		const OBJM_CNST_HEADER *_header;
		const OBJM_CNST_DATA *_data;
		const u16 *vidxB;
		const u16 *vidxA;
		const float *weightsA;
		const float *_val0;
		const float *_val1;
		const float *_val2;
		const OBJM_VERTEX *_vertices;
		i32 _meshA;
		i32 _frameA;
		i32 _meshB;
		i32 _frameB;
		u32 _npoints;
		// std::vector<u16> _indicesA;
		// std::vector<u16> _indicesB;
	};
	std::vector<ObjmCnst> _objmcnsts;

	// Data
	int nmeshvertices;
	int nmeshindices;

	// Lifecycle
	void ref (void) { refcount += 1; }
	void unRef (void) { refcount -= 1; if (!refcount) delete this; }

	// Static constructor
	static OBJMData *getOBJMData (const char *uri);

	// Access
	const char *getURI (void) { return name.c_str (); }

	// Helpers
	bool parse (const unsigned char *cdata, size_t csize);
	bool parse_OBJX (const unsigned char *cdata, size_t csize, size_t& cpos);
	bool parse_MESH_OBJM (const unsigned char *cdata, size_t csize, size_t& cpos, std::vector<u32>& treevec);
	int lookupMaterial (u32 objmidx);
	int lookupTexture (u32 objmidx);
	int lookupMesh (u32 objmidx);
	int lookupBlend (u32 objmidx);
	int lookupFrame (u32 objmidx);
	int getMaterialIdx (u32 tex, u32 mat);
	static void printHexBytes16 (const unsigned char *cdata, size_t cpos, size_t length);
};

struct ILLUSION_OBJM_HEADER {
	u32 dwMagic;
	u32 dwReserved[2];
};

struct ILLUSION_OBJM_TAG {
	u32 dwType;
	u32 dwSize;
};

struct OBJMData::OBJM_VERTEX {
	float x, y, z;
	float weight;
	float nx, ny, nz;
	float tu, tv;
	u32 dwUserData[6];
};

struct OBJMData::OBJM_MATE {
	char cName[60];
	u32 dwUnknown;
	u32 dwID;
	float fDiffuse[4];
	float fAmbient[4];
	float fSpecular[4];
	float fEmissive[4];
	float fPower[2];
};

struct OBJMData::OBJM_TEXT {
	char cName[60];
	u32 dwUnknown;
	u32 dwID;
	char cFileName[64];
	u32 dwReserved[17];
	u32 dwSize;
};

struct OBJMData::OBJM_LIGH {
	char cName[64];
	u32 dwID;
	u32 dwType;
	float fDiffuse[4];
	float fSpecular[4];
	float fAmbient[4];
	float fPosition[3];
	float fDirection[3];
	float fRange;
	float fFalloff;
	float fAttenuation[3];
	float fTheta;
	float fPhi;
};

struct OBJMData::OBJM_MESH_HEADER {
	char cName[64];
	u32 dwID;
	u32 dwCount;
};

struct OBJMData::OBJM_MESH_DATA {
	u32 dwUnknown1;
	u32 dwMateID;
	u32 dwTextID;
	u32 dwUnknown2;
	u32 dwFlags[12];
	u32 dwVertexCount;
	u32 dwIndexCount;
	u32 dwUnknown3;
	u32 dwLevel;
	u32 dwReserved[63];
};

struct OBJMData::OBJM_BLND_HEADER {
	char cName[64];
	u32 dwID;
	u32 dwCount;
};

struct OBJMData::OBJM_BLND_DATA {
	u32 dwUnknown1;
	u32 idMATE;
	u32 dwUnknown2;
	u32 idTEXT;
	u32 dwUnknown3[13];
	u32 dwVertexCount;
	u32 dwIndexCount;
	u32 dwUnknown4[64];
};

struct OBJMData::OBJM_FRAM {
	char cName[64];
	u32 dwID;
	f32 fMatrix[4][4];
	u32 dwReserved1[9];
	u32 dwUnknown;
	u32 dwParentID;
	u32 dwMeshID;
	u32 dwLighID;
	u32 dwBlndID;
	u32 dwChildID;
	u32 dwReserved2[51];
};

struct OBJMData::OBJM_ANIM_HEADER {
	u32 dwReserved[16];
	u32 dwID;
	u32 dwFramCount;
};

struct OBJMData::OBJM_ANIM_DATA {
	u32 dwFramID;
	u32 dwReserved[4];
	u32 dwCount;
};

struct OBJMData::OBJM_ANIM_KEY {
	float fTime;
	i32 dwTranslationChanged;
	float fTranslation[3];
	i32 dwRotationChanged;
	float fRotation[3];
	i32 dwScaleChanged;
	float fScale[3];
	float fMatrix[4][4];
	float fRotation4[4];
	i32 dwReserved[20];
	long nStart;
	long nEnd;
};

struct OBJMData::OBJM_MORP_HEADER {
	u32 dwReserved[16];
	u32 dwID;
	u32 dwMeshCount;
};

struct OBJMData::OBJM_MORP_DATA {
	u32 dwMeshID;
	u32 dwReserved[4];
	u32 dwCount;
};

struct OBJMData::OBJM_MORP_KEY {
	float fTime;
	u32 dwReserved;
	u32 dwVertexCount;
};

struct OBJMData::OBJM_CNST_HEADER {
	u32 unKnown0;
	u32 zero0[16];
	u32 nData;
};

struct OBJMData::OBJM_CNST_DATA {
	u32 zero1[17];
	u32 frame1Idx;
	u32 mesh1Idx;
	u32 frame2Idx;
	u32 mesh2Idx;
	u32 nPoints;
	u32 nVertices;
	u32 zero[4];
};

static const float *
shuffle16 (const float *m)
{
	static float s[16];
	// X -> Y, Y -> Z, Z -> -X
	s[0] = m[10];
	s[1] = -m[8];
	s[2] = -m[9];
	s[3] = m[3];
	s[4] = -m[2];
	s[5] = m[0];
	s[6] = m[1];
	s[7] = m[7];
	s[8] = -m[6];
	s[9] = m[4];
	s[10] = m[5];
	s[11] = m[11];
	s[12] = -m[14];
	s[13] = m[12];
	s[14] = m[13];
	s[15] = m[15];
	return s;
}

static const float *
shuffle3 (const float *v)
{
	static float s[3];
	// X -> Y, Y -> Z, Z -> -X
	s[0] = -v[2];
	s[1] = v[0];
	s[2] = v[1];
	return s;
}

// OBJMData

static Arikkei::Dict<const char *, OBJMData *> objmdict(31);

OBJMData::OBJMData (const char *pname, const unsigned char *pdata, size_t psize, bool pprivmap)
: refcount(1), privmap(true), usize(0), udata(NULL), name(pname), nmeshvertices(0), nmeshindices(0)
{
	objmdict.insert (name.c_str (), this);

	if (TAG (pdata) == TAG_OBJN) {
		udata = Xfpk::FileData::unpack_a67f54cb (pdata + 12, psize - 12, usize);
	} else if (pprivmap && psize) {
		usize = psize;
		udata = (unsigned char *) malloc (usize);
		memcpy (udata, pdata, usize);
	} else {
		privmap = false;
	}
	if (udata) {
		parse (udata, usize);
	}
}

OBJMData::~OBJMData (void)
{
	objmdict.remove (name.c_str ());

	if (privmap && udata) free (udata);
}

OBJMData *
OBJMData::getOBJMData (const char *uri)
{
	OBJMData *objmdata = objmdict.lookup (uri);
	if (objmdata) {
		objmdata->ref ();
	} else {
		URI::Location loc(uri);
		URI::URLHandler *handler = URI::getHandler (loc.path);
		if (handler) {
			size_t csize;
			const unsigned char *cdata = handler->mmapData (loc.path, &csize);
			if (cdata) {
				objmdata = new OBJMData((const char *) loc.path, cdata, csize, true);
				handler->munmapData (cdata);
			}
			handler->unRef ();
		}
	}
	return objmdata;
}

bool
OBJMData::parse (const unsigned char *cdata, size_t csize)
{
	size_t cpos = 0;
	bool result = parse_OBJX (cdata, csize, cpos);

	// Add some bookkeeping data
	// Frame parent, mesh, blend, child, skin transformation
	for (size_t i = 0; i < _objmframes.size (); i++) {
		ObjmFrame& of(_objmframes[i]);
		of._parent = lookupFrame (of._data->dwParentID);
		of._mesh = lookupMesh (of._data->dwMeshID);
		if (of._mesh >= 0) meshes[of._mesh]._frameidx = (int) i;
		of._blend = lookupBlend (of._data->dwBlndID);
		of._child = lookupFrame (of._data->dwChildID);

		Elea::Matrix4x4f f2p(shuffle16 (&of._data->fMatrix[0][0]));
		if (of._parent >= 0) {
			of.f2s = _objmframes[of._parent].f2s * f2p;
		} else {
			of.f2s = f2p;
		}
	}

	// Assign frame indices to unassigned children meshes
	// We expect here that child is aways after parent in list
	for (size_t i = 0; i < meshes.size (); i++) {
		Mesh& om(meshes[i]);
		if (om._frameidx >= 0) {
			for (size_t j = 0; j < om._children.size (); j++) {
				int cpos = om._children[j];
				Mesh& child(meshes[cpos]);
				if (child._frameidx < 0) child._frameidx = om._frameidx;
			}
		}
		if (om._data) {
			om.firstvertex = nmeshvertices;
			nmeshvertices += om._data->dwVertexCount;
			nmeshindices += om._data->dwIndexCount;
		}
	}
	// Assign morph indices to morphed meshes
	for (size_t i = 0; i < morphs.size (); i++) {
		int meshidx = lookupMesh (morphs[i]._data->dwMeshID);
		if ((meshidx >= 0) && (morphs[i]._keys.size () > 0)) {
			if (!meshes[meshidx]._data) {
				fprintf (stderr, "Bad, morphed mesh %s does not have data (morph %d)\n", meshes[meshidx]._header->cName, (int) i);
				continue;
			}
			morphs[i]._mesh = meshidx;
			meshes[meshidx]._morph = (int) i;
		}
	}
	// Assign bone and mesh indices to Cnst blocks
	// Update the number of Cnst refs to meshes
	for (size_t i = 0; i < _objmcnsts.size (); i++) {
		ObjmCnst& cnst(_objmcnsts[i]);
		cnst._meshA = lookupMesh (cnst._data->mesh1Idx);
		cnst._frameA = lookupFrame (cnst._data->frame1Idx);
		cnst._meshB = lookupMesh (cnst._data->mesh2Idx);
		cnst._frameB = lookupFrame (cnst._data->frame2Idx);
		cnst._npoints = cnst._data->nPoints;
		meshes[cnst._meshA].cnsts.push_back ((int) i);
		meshes[cnst._meshA].cnstframes.push_back (cnst._frameB);
		meshes[cnst._meshB].cnsts.push_back ((int) i);
		meshes[cnst._meshB].cnstframes.push_back (cnst._frameA);
	}

	// Set shadow flags
	for (size_t i = 0; i < meshes.size (); i++) {
		if (!meshes[i]._data) continue;
		int tidx = -1;
		for (size_t j = 0; j < _objmtextures.size (); j++) {
			if (_objmtextures[j]._id == meshes[i]._data->dwTextID) {
				tidx = j;
				break;
			}
		}
		if (tidx < 0) continue;
		// 0x00000001 seems to be set for lightmap meshes
		if (meshes[i]._data->dwLevel == 1) _objmtextures[tidx].isshadow = true;
	}
#if 0
	// Test
	for (size_t k = 0; k < _objmframes.size (); k++) {
		if (_objmframes[k]._mesh < 0) continue;
		int i = _objmframes[k]._mesh;
		if (meshes[i]._data) {
			int tidx = -1;
			for (size_t j = 0; j < _objmtextures.size (); j++) {
				if (_objmtextures[j]._id == meshes[i]._data->dwTextID) {
					tidx = j;
					break;
				}
			}
			if (tidx < 0) continue;
			int midx = -1;
			for (size_t j = 0; j < materials.size (); j++) {
				if (materials[j]._data->dwID == meshes[i]._data->dwMateID) {
					midx = j;
					break;
				}
			}
			if (midx < 0) continue;
			const char *texname = _objmtextures[tidx]._name.c_str ();
			if (strcmp (texname, "p0500_00_08.bmp") && strcmp (texname, "p0500_00_01.bmp")) continue;
			fprintf (stderr, "%s %s %s\n", meshes[i]._header->cName, materials[midx]._data->cName, _objmtextures[tidx]._name.c_str ());
			fprintf (stderr, "%08x\n", _objmframes[k]._data->dwUnknown);
			for (int j = 0; j < 9; j++) {
				fprintf (stderr, "%08x ", _objmframes[k]._data->dwReserved1[j]);
			}
			fprintf (stderr, "\n");
			fprintf (stderr, "%08x\n", materials[midx]._data->dwUnknown);
			fprintf (stderr, "%08x %08x\n", _objmtextures[tidx]._data->dwUnknown, _objmtextures[tidx]._data->dwSize);
			for (int j = 0; j < 17; j++) {
				fprintf (stderr, "%08x ", _objmtextures[tidx]._data->dwReserved[j]);
			}
			fprintf (stderr, "\n");
			// u32 dwUnknown1;
			// u32 dwMateID;
			// u32 dwTextID;
			// u32 dwUnknown2;
			// u32 dwFlags[12];
			// u32 dwVertexCount;
			// u32 dwIndexCount;
			// u32 dwUnknown3;
			// u32 dwLevel;
			// u32 dwReserved[63];
			fprintf (stderr, "%08x %08x %08x ", meshes[i]._data->dwUnknown1, meshes[i]._data->dwUnknown2, meshes[i]._data->dwUnknown3);
			fprintf (stderr, "%08x\n", meshes[i]._data->dwLevel);
			for (int j = 0; j < 12; j++) {
				fprintf (stderr, "%08x ", meshes[i]._data->dwFlags[j]);
			}
			fprintf (stderr, "\n");
		}
	}
#endif

	return result;
}

static bool
get_block (void *block, size_t bsize, const unsigned char *cdata, size_t csize, size_t& cpos)
{
	if ((cpos + bsize) > csize) return false;
	memcpy (block, cdata + cpos, bsize);
	cpos += bsize;
	return true;
}

static const char *
tag_name (i32 tag)
{
	static char c[5];
	memcpy (c, &tag, 4);
	c[5] = 0;
	return c;
}

bool
OBJMData::parse_OBJX (const unsigned char *cdata, size_t csize, size_t& cpos)
{
	ILLUSION_OBJM_HEADER header;
	if (!get_block (&header, sizeof (header), cdata, csize, cpos)) return false;
	if (debug) fprintf (stderr, "Block: %s\n", tag_name (header.dwMagic));
	if ((header.dwMagic == TAG_OBJN) || (header.dwMagic == TAG_OBJM)) {
		while (cpos < csize) {
			ILLUSION_OBJM_TAG tag;
			if (!get_block (&tag, sizeof (tag), cdata, csize, cpos)) return false;
			if (debug) fprintf (stderr, "Tag: %s %d\n", tag_name (tag.dwType), tag.dwSize);
			size_t endpos = cpos + tag.dwSize;
			if (tag.dwType == TAG_MATE) {
				// Material
				while ((cpos + sizeof (OBJM_MATE)) <= endpos) {
					const unsigned char *mdata = cdata + cpos;
					OBJM_MATE obj;
					if (!get_block (&obj, sizeof (obj), cdata, endpos, cpos)) return false;
					if (debug) {
						fprintf (stderr, "Mat name: %s Id %d (%x)\n", obj.cName, obj.dwID, obj.dwID);
						printHexBytes16 ((const unsigned char *) &obj.dwID, 0, 4);
						printHexBytes16 ((const unsigned char *) &obj.dwUnknown, 0, 4);
					}
					materials.push_back (Material (mdata));
				}
			} else if (tag.dwType == TAG_TEXT) {
				while ((cpos + sizeof (OBJM_TEXT)) <= endpos) {
					OBJM_TEXT obj;
					if (!get_block (&obj, sizeof (obj), cdata, endpos, cpos)) return false;
					if (debug) {
						fprintf (stderr, "Txt name: %s Id %d (%x)\n", obj.cName, obj.dwID, obj.dwID);
						printHexBytes16 ((const unsigned char *) &obj.dwID, 0, 4);
						printHexBytes16 ((const unsigned char *) &obj.dwUnknown, 0, 4);
						printHexBytes16 ((const unsigned char *) &obj.dwReserved, 0, 4 * 17);
					}
					_objmtextures.push_back (ObjmTextureData ());
					ObjmTextureData& ot(_objmtextures.back ());
					ot._data = &obj;
					ot._name = obj.cName;
					ot._id = obj.dwID;
					ot._filename = obj.cFileName;
					ot._materialidx = -1;
					ot.isshadow = false;
				}
			} else if (tag.dwType == TAG_LIGH) {
				while ((cpos + sizeof (OBJM_LIGH)) <= endpos) {
					OBJM_LIGH obj;
					if (!get_block (&obj, sizeof (obj), cdata, endpos, cpos)) return false;
					if (debug) fprintf (stderr, "Light name: %s Id %d (%x)\n", obj.cName, obj.dwID, obj.dwID);
				}
			} else if (tag.dwType == TAG_MESH) {
				// if (!parse_MESH_OBJM (cdata, endpos, cpos, _objmmeshroots)) return false;
				std::vector<u32> rootmeshes;
				if (!parse_MESH_OBJM (cdata, endpos, cpos, rootmeshes)) return false;
			} else if (tag.dwType == TAG_BLND) {
				while ((cpos + sizeof (OBJM_BLND_HEADER)) <= endpos) {
					const unsigned char *hdata = cdata + cpos;
					OBJM_BLND_HEADER hdr;
					if (!get_block (&hdr, sizeof (hdr), cdata, endpos, cpos)) return false;
					if (debug) fprintf (stderr, "Blend %s Id %d (%x) Count %d\n", hdr.cName, hdr.dwID, hdr.dwID, hdr.dwCount);
					for (u32 i = 0; i < hdr.dwCount; i++) {
						const unsigned char *bdata = cdata + cpos;
						OBJM_BLND_DATA info;
						if (!get_block (&info, sizeof (info), cdata, endpos, cpos)) return false;
						if (debug) fprintf (stderr, "BlendInfo idMATE %d idTEXT %d nVertices %d nIndices %d\n", info.idMATE, info.idTEXT, info.dwVertexCount, info.dwIndexCount);
						const OBJM_VERTEX *v0data = (const OBJM_VERTEX *) (cdata + cpos);
						cpos += info.dwVertexCount * sizeof (OBJM_VERTEX);
						const OBJM_VERTEX *v1data = (const OBJM_VERTEX *) (cdata + cpos);
						cpos += info.dwVertexCount * sizeof (OBJM_VERTEX);
						const u16 *idata = (const u16 *) (cdata + cpos);
						cpos += info.dwIndexCount * sizeof (u16);
						blends.push_back (Blend((const OBJM_BLND_HEADER *) hdata, (const OBJM_BLND_DATA *) bdata, v0data, v1data, idata));
					}
				}
			} else if (tag.dwType == TAG_FRAM) {
				while ((cpos + sizeof (OBJM_FRAM)) <= endpos) {
					const unsigned char *fdata = cdata + cpos;
					OBJM_FRAM obj;
					if (!get_block (&obj, sizeof (obj), cdata, endpos, cpos)) return false;
					if (debug) fprintf (stderr, "Frame name: %s Id %d (%x) Parent %d Mesh %d Blend %d Child %d\n", obj.cName, obj.dwID, obj.dwID, obj.dwParentID, obj.dwMeshID, obj.dwBlndID, obj.dwChildID);
					_objmframes.push_back (ObjmFrame(fdata));
				}
			} else if (tag.dwType == TAG_ANIM) {
				const unsigned char *adata = cdata + cpos;
				OBJM_ANIM_HEADER anim;
				if (!get_block (&anim, sizeof (anim), cdata, endpos, cpos)) return false;
				if (debug) fprintf (stderr, "Anim Id %d (%x) NFrames %d (%x)\n", anim.dwID, anim.dwID, anim.dwFramCount, anim.dwFramCount);
				animations.push_back (Animation((const OBJM_ANIM_HEADER *) adata));
				Animation& objmanim(animations.back ());
				for (u32 i = 0; i < anim.dwFramCount; i++) {
					const unsigned char *fadata = cdata + cpos;
					OBJM_ANIM_DATA info;
					if (!get_block (&info, sizeof (info), cdata, endpos, cpos)) return false;
					if (debug) fprintf (stderr, "Frame Id %d (%x) NKeys %d (%x)\n", info.dwFramID, info.dwFramID, info.dwCount, info.dwCount);
					const unsigned char *kdata = cdata + cpos;
					cpos += info.dwCount * sizeof (OBJM_ANIM_KEY);
					objmanim.frameanims.push_back (FrameAnimation((const OBJM_ANIM_DATA *) fadata, (const OBJM_ANIM_KEY *) kdata));
				}
			} else if (tag.dwType == TAG_MORP) {
				const unsigned char *hdata = cdata + cpos;
				OBJM_MORP_HEADER obj;
				if (!get_block (&obj, sizeof (obj), cdata, endpos, cpos)) return false;
				if (debug) fprintf (stderr, "Morph Id %d (%x) MeshCount %d\n", obj.dwID, obj.dwID, obj.dwMeshCount);
				for (u32 i = 0; i < obj.dwMeshCount; i++) {
					const unsigned char *mdata = cdata + cpos;
					OBJM_MORP_DATA dobj;
					if (!get_block (&dobj, sizeof (dobj), cdata, endpos, cpos)) return false;
					if (debug) fprintf (stderr, "Morphed Mesh %d (%x) Count %d\n", dobj.dwMeshID, dobj.dwMeshID, dobj.dwCount);
					morphs.push_back (Morph((const OBJM_MORP_HEADER *) hdata, (const OBJM_MORP_DATA *) mdata));
					Morph& morph(morphs.back ());
					for (u32 j = 0; j < dobj.dwCount; j++) {
						const unsigned char *kdata = cdata + cpos;
						OBJM_MORP_KEY kobj;
						if (!get_block (&kobj, sizeof (kobj), cdata, endpos, cpos)) return false;
						const unsigned char *vdata = cdata + cpos;
						cpos += kobj.dwVertexCount * sizeof (OBJM_VERTEX);
						if (debug) fprintf (stderr, "MorphData Numvertices %d name %s\n", kobj.dwVertexCount, cdata + cpos);
						morph._keys.push_back (MorphKey((const OBJM_MORP_KEY *) kdata, (const OBJM_VERTEX *) vdata, (const char *) (cdata + cpos)));
						cpos += 64;
					}
				}
			} else if (tag.dwType == TAG_FOG) {
				char c[32];
				if (!get_block (c, sizeof (c), cdata, endpos, cpos)) return false;
			} else if (tag.dwType == TAG_ENVL) {
				if (debug) fprintf (stderr, "ENVL\n");
			} else if (tag.dwType == TAG_CNST) {
				const unsigned char *hdata = cdata + cpos;
				OBJM_CNST_HEADER obj;
				if (!get_block (&obj, sizeof (obj), cdata, endpos, cpos)) return false;
				if (debug) fprintf (stderr, "Cnst v0 %d (%x) v1 %d (%x)\n", obj.unKnown0, obj.unKnown0, obj.nData, obj.nData);
				for (u32 k = 0; k < obj.nData; k++) {
					const unsigned char *ddata = cdata + cpos;
					OBJM_CNST_DATA dobj;
					if (!get_block (&dobj, sizeof (dobj), cdata, endpos, cpos)) return false;
					if (debug) fprintf (stderr, "Cnst Data points %d vertices %d\n", dobj.nPoints, dobj.nVertices);
					_objmcnsts.push_back (ObjmCnst ());
					ObjmCnst& cnst(_objmcnsts.back ());
					cnst._header = (const OBJM_CNST_HEADER *) hdata;
					cnst._data = (const OBJM_CNST_DATA *) ddata;

					Mesh& mesh1(meshes[lookupMesh (dobj.mesh1Idx)]);
					ObjmFrame& frame1(_objmframes[lookupFrame (dobj.frame1Idx)]);
					Mesh& mesh2(meshes[lookupMesh (dobj.mesh2Idx)]);
					ObjmFrame& frame2(_objmframes[lookupFrame (dobj.frame2Idx)]);
					if (debug) fprintf (stderr, "1 Mesh %s (%d)   frame %s\n", mesh1._header->cName, mesh1._data->dwVertexCount, frame1._data->cName);
					if (debug) fprintf (stderr, "2 Mesh %s (%d)   frame %s\n", mesh2._header->cName, mesh2._data->dwVertexCount, frame2._data->cName);

					cnst.vidxB = (const u16 *) (cdata + cpos);
					for (u32 i = 0; i < dobj.nPoints; i++) {
						u16 val;
						if (!get_block (&val, sizeof (val), cdata, endpos, cpos)) return false;
						if (debug) fprintf (stderr, "%d ", val);
					}
					if (debug) fprintf (stderr, "\n");
					cnst.vidxA = (const u16 *) (cdata + cpos);
					for (u32 i = 0; i < dobj.nPoints; i++) {
						u16 val;
						if (!get_block (&val, sizeof (val), cdata, endpos, cpos)) return false;
						if (debug) fprintf (stderr, "%d ", val);
					}
					if (debug) fprintf (stderr, "\n");
					cnst.weightsA = (const float *) (cdata + cpos);
					for (u32 i = 0; i < dobj.nPoints; i++) {
						float val;
						if (!get_block (&val, sizeof (val), cdata, endpos, cpos)) return false;
						if (debug) fprintf (stderr, "%.4f ", val);
					}
					if (debug) fprintf (stderr, "\n");
					cnst._val0 = (const float *) (cdata + cpos);
					for (u32 i = 0; i < 3 * dobj.nPoints; i++) {
						float val;
						if (!get_block (&val, sizeof (val), cdata, endpos, cpos)) return false;
						if (debug) fprintf (stderr, "%.4f ", val);
					}
					if (debug) fprintf (stderr, "\n");
					cnst._val1 = (const float *) (cdata + cpos);
					for (u32 i = 0; i < 3 * dobj.nPoints; i++) {
						float val;
						if (!get_block (&val, sizeof (val), cdata, endpos, cpos)) return false;
						if (debug) fprintf (stderr, "%.4f ", val);
					}
					if (debug) fprintf (stderr, "\n");
					cnst._val2 = (const float *) (cdata + cpos);
					for (u32 i = 0; i < dobj.nPoints; i++) {
						float val;
						if (!get_block (&val, sizeof (val), cdata, endpos, cpos)) return false;
						if (debug) fprintf (stderr, "%.4f ", val);
					}
					if (debug) fprintf (stderr, "\n");
					cnst._vertices = (const OBJM_VERTEX *) (cdata + cpos);
					for (u32 i = 0; i < dobj.nVertices; i++) {
						OBJM_VERTEX val;
						if (!get_block (&val, sizeof (val), cdata, endpos, cpos)) return false;
						if (debug > 1) fprintf (stderr, "Vertex %.1f %.1f %.1f\n", val.x, val.y, val.z);
					}
					if (debug) fprintf (stderr, "\n");
				}
			} else if (!tag.dwType) {
				break;
			}
			if (cpos != endpos) {
				fprintf (stderr, "Block end inconsistency: by content %d by tag %d\n", (int) cpos, (int) endpos);
				size_t nrows = (endpos + 15 - cpos) / 16;
				if (nrows > 32) nrows = 32;
				for (size_t row = 0; row < nrows; row++) {
					// print_row (stderr, cdata, cpos + 16 * row);
				}
			}
			cpos = endpos;
		}
	}
	return true;
}

bool
OBJMData::parse_MESH_OBJM (const unsigned char *cdata, size_t csize, size_t& cpos, std::vector<u32>& treevec)
{
	while ((cpos + sizeof (OBJM_MESH_HEADER)) <= csize) {
		const unsigned char *hdata = cdata + cpos;
		OBJM_MESH_HEADER obj;
		if (!get_block (&obj, sizeof (obj), cdata, csize, cpos)) return false;
		if (debug) fprintf (stderr, "Mesh name: %s Id %d (%x) Count %d (%x)\n", obj.cName, obj.dwID, obj.dwID, obj.dwCount, obj.dwCount);
		// fixme: Possibly multiple submeshes
		if (obj.dwCount > 1) {
			// Has submeshes
			size_t mypos = meshes.size ();
			treevec.push_back ((int) mypos);
			meshes.push_back (Mesh((const OBJM_MESH_HEADER *) hdata, NULL, NULL, NULL));
			std::vector<u32> mytreevec;
			for (u32 i = 0; i < obj.dwCount; i++) {
				if (!parse_MESH_OBJM (cdata, csize, cpos, mytreevec)) return false;
			}
			meshes[mypos]._children = mytreevec;
		} else {
			const unsigned char *ddata = cdata + cpos;
			OBJM_MESH_DATA info;
			if (!get_block (&info, sizeof (info), cdata, csize, cpos)) return false;
			if (debug) fprintf (stderr, "nVertices %d nIndices %d\n", info.dwVertexCount, info.dwIndexCount);
			const OBJM_VERTEX *vdata = (const OBJM_VERTEX *) (cdata + cpos);
			cpos += info.dwVertexCount * sizeof (OBJM_VERTEX);
			const u16 *idata = (const u16 *) (cdata + cpos);
			cpos += info.dwIndexCount * sizeof (u16);
			meshes.push_back (Mesh((const OBJM_MESH_HEADER *) hdata, (const OBJM_MESH_DATA *) ddata, vdata, idata));

			size_t mypos = meshes.size () - 1;
			treevec.push_back ((int) mypos);
		}
	}
	return true;
}

int
OBJMData::lookupMaterial (u32 objmidx)
{
	for (size_t i = 0; i < materials.size (); i++) {
		if (materials[i]._data->dwID == objmidx) return (int) i;
	}
	return -1;
}

int
OBJMData::lookupTexture (u32 objmidx)
{
	for (size_t i = 0; i < _objmtextures.size (); i++) {
		if (_objmtextures[i]._id == objmidx) return (int) i;
	}
	return -1;
}

int
OBJMData::lookupMesh (u32 objmidx)
{
	for (size_t i = 0; i < meshes.size (); i++) {
		if (meshes[i]._header->dwID == objmidx) return (int) i;
	}
	return -1;
}

int
OBJMData::lookupBlend (u32 objmidx)
{
	for (size_t i = 0; i < blends.size (); i++) {
		if (blends[i]._header->dwID == objmidx) return (int) i;
	}
	return -1;
}

int
OBJMData::lookupFrame (u32 objmidx)
{
	for (size_t i = 0; i < _objmframes.size (); i++) {
		if (_objmframes[i]._data->dwID == objmidx) return (int) i;
	}
	return -1;
}

int
OBJMData::getMaterialIdx (u32 tex, u32 mat)
{
	int matid = lookupTexture (tex);
	if (matid >= 0) {
		return _objmtextures[matid]._materialidx;
	} else {
		matid = lookupMaterial (mat);
		if (matid >= 0) return materials[matid]._materialidx;
	}
	return 0;
}

void
OBJMData::printHexBytes16 (const unsigned char *cdata, size_t cpos, size_t length)
{
	for (size_t pos = 0; pos < length; pos += 16) {
		int rowlen = (int) (length - pos);
		if (rowlen > 16) rowlen = 16;
		// Print address
		fprintf (stderr, "0x%09x  ", (int) (cpos + pos));
		// Print hexvals
		for (int i = 0; i < 16; i++) {
			if (i == 8) fprintf (stderr, " ");
			if (i < rowlen) {
				unsigned char v = cdata[cpos + pos + i];
				fprintf (stderr, "%02x ", v);
			} else {
				fprintf (stderr, "   ");
			}
		}
		// Print bytes
		fprintf (stderr, " ");
		for (int i = 0; i < 16; i++) {
			unsigned char v = ' ';
			if (i < rowlen) {
				v = cdata[cpos + pos + i];
			}
			if ((v < 32) || ((v >= 128) && (v < 160))) v = '.';
			fprintf (stderr, "%c", v);
		}
		fprintf (stderr, "\n");
	}
}

// GeometryOBJM

struct VertexData {
	int frame0;
	float weight0;
	int frame1;
	float weight1;
};

struct GeometryOBJM::PTexture {
	const char *id;
	NR::PixBlock pxb;
};

struct GeometryOBJM::PMaterial {
	const char *id;
	Elea::Color4f diffuse;
	int texid;
	bool lightmap;
};

GeometryOBJM::GeometryOBJM (void)
: bdata(NULL), scale(DefaultScale),
nmorphvertices(0), vmorph(NULL), nmorph(NULL), npmorphs(0), pmorphs(NULL)
{
}

GeometryOBJM::~GeometryOBJM (void)
{
	for (size_t i = 0; i < materials.size (); i++) delete materials[i];
	if (bdata) bdata->unRef ();
}

static Object *
geometryobjm_factory (void)
{
	return new GeometryOBJM();
}

const Object::Type *
GeometryOBJM::objectType (void)
{
	return type ();
}

const Object::Type *
GeometryOBJM::type (void)
{
	static Type *mytype = NULL;
	static const Attribute attrs[] = {
		{ "source", NULL, 0 },
		{ "scale", NULL, 0 }
	};
	if (!mytype) mytype = new Type(SkinnedGeometry::type (), "GeometryOBJM", "geometryOBJM", geometryobjm_factory, sizeof (attrs) / sizeof (attrs[0]), attrs);
	return mytype;
}

void
GeometryOBJM::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	SkinnedGeometry::build (pnode, doc, ctx);

	buildAllAttributes (type (), ctx);

}

void
GeometryOBJM::release (void)
{
	nmorphvertices = 0;
	if (vmorph) free (vmorph);
	vmorph = NULL;
	if (nmorph) free (nmorph);
	nmorph = NULL;

	npmorphs = 0;
	if (pmorphs) free (pmorphs);
	pmorphs = NULL;

	// Clear private textures and materials
	for (size_t i = 0; i < textures.size (); i++) delete textures[i];
	textures.clear ();
	ntextures = 0;
	for (size_t i = 0; i < materials.size (); i++) delete materials[i];
	materials.clear ();
	nmaterials = 0;

	SkinnedGeometry::release ();
}

void
GeometryOBJM::set (const char *attrid, const char *val)
{
	if (!strcmp (attrid, "source")) {
		clear ();
		if (bdata) {
			bdata->unRef ();
			bdata = NULL;
		}
		if (val) bdata = OBJMData::getOBJMData (val);
		loadData ();
		requestUpdate (MODIFIED | MESH_DEFINITION_MODIFIED);
	} else if (!strcmp (attrid, "scale")) {
		if (!XML::parseNumber (&scale, val)) scale = 1;
		scale *= DefaultScale;
		loadData ();
		requestUpdate (MODIFIED | MESH_DEFINITION_MODIFIED);
	} else {
		SkinnedGeometry::set (attrid, val);
	}
}

void
GeometryOBJM::update (UpdateCtx *ctx, unsigned int flags)
{
	SkinnedGeometry::update (ctx, flags);
}

Sehle::Material *
GeometryOBJM::getMaterial (int matidx, Sehle::Engine *engine)
{
	PMaterial *pm = materials[matidx];
	if (false) {
		return Sehle::WireMaterial::newWireMaterial (engine, "test");
	} else if (pm->texid < 0) {
		Sehle::ColorMaterial *m = Sehle::ColorMaterial::newColorMaterial (engine, pm->id);
		m->setColor (pm->diffuse);
		return m;
	} else {
		PTexture *tex = textures[pm->texid];
		// fixme: We should implement unique descriptor system in material parser (based on file name, object and material names) (Lauris)
		Sehle::MaterialMultipassDNS *m = Sehle::MaterialMultipassDNS::newMaterialMultipassDNS (engine, pm->id);
		// We expect that material names are unique
		if (m->built) return m;
		if (pm->lightmap) {
			NR::PixBlock pxs(NR::PixBlock::R8G8B8A8N, tex->pxb.getX0 (), tex->pxb.getY0 (), tex->pxb.getWidth (), tex->pxb.getHeight (), true, false);
			for (int y = 0; y < tex->pxb.getHeight (); y++) {
				const unsigned char *s = tex->pxb.getRow (y);
				unsigned char *d = pxs.getRow (y);
				for (int x = 0; x < tex->pxb.getWidth (); x++) {
					d[0] = 255 - s[0];
					d[1] = 255 - s[1];
					d[2] = 255 - s[2];
					d[3] = s[0];
					s += tex->pxb.getBPP ();
					d += 4;
				}
			}
			pxs.markDirty ();
			m->setMap (Sehle::MaterialMultipassDNS::COLOR, tex->id, &pxs.pb);
		} else {
			m->setMap (Sehle::MaterialMultipassDNS::COLOR, tex->id, &tex->pxb.pb);
		}
		// test
		// m->clearStateFlags (Sehle::RenderContext::FILL);
		// m->setShininess (32);
		// m->setOpacity (0.5f);
		return m;
	}
}

TextureInfo *
GeometryOBJM::getTextureInfo (unsigned int matidx, unsigned int texidx, unsigned int getimage)
{
	if (texidx >= ntextures) return NULL;
	TextureInfo *tex = new TextureInfo();
	tex->urn = strdup (textures[texidx]->id);
	if (getimage) {
		tex->image = nr_image_new ();
		NRPixBlock *px = &textures[texidx]->pxb.pb;
		nr_pixblock_setup_extern (&tex->image->pixels, px->mode, px->area.x0, px->area.y0, px->area.x1, px->area.y1, NR_PIXBLOCK_PX(px), px->rs, false, false);
	}
	return tex;
}

u32
GeometryOBJM::getMaterialInfo (MaterialInfo *mat, u32 matidx)
{
	if (matidx >= (u32) nmaterials) return false;
	if (mat) {
		mat->type = (materials[matidx]->texid >= 0) ? MaterialInfo::TEXTURE : MaterialInfo::COLOR;
		mat->id = materials[matidx]->id;
		mat->diffuseColor = materials[matidx]->diffuse;
		mat->specularColor = Elea::Color4fBlack;
		mat->specularShininess = 1;
		mat->diffuseTexture = materials[matidx]->texid;
		mat->normalTexture = -1;
		mat->specularTexture = -1;
	}
	return true;
}

void
GeometryOBJM::loadData ()
{
	clear ();
	// Clear private textures and materials
	for (size_t i = 0; i < textures.size (); i++) delete textures[i];
	textures.clear ();
	ntextures = 0;
	for (size_t i = 0; i < materials.size (); i++) delete materials[i];
	materials.clear ();
	nmaterials = 0;
	// Clear morphs
	nmorphvertices = 0;
	if (vmorph) free (vmorph);
	vmorph = NULL;
	if (nmorph) free (nmorph);
	nmorph = NULL;
	npmorphs = 0;
	if (pmorphs) free (pmorphs);
	pmorphs = NULL;

	if (!bdata) return;

	// Build textures
	URI::Location loc(bdata->name.c_str ());
	URI::URLHandler *handler = URI::getHandler (loc.base);
	for (size_t i = 0; i < bdata->_objmtextures.size (); i++) {
		OBJMData::ObjmTextureData& ot(bdata->_objmtextures[i]);
		PTexture *tex = new PTexture();
		size_t isize;
		const unsigned char *idata = handler->mmapDataRelative (ot._filename.c_str (), &isize);
		if (idata && Image::load (&tex->pxb.pb, idata, isize)) {
			tex->id = ot._filename.c_str ();
			// tex->id = ot._data->cFileName;
			textures.push_back (tex);
		} else {
			delete tex;
		}
	}
	ntextures = (int) textures.size ();

	// Build materials
	PMaterial *mat = new PMaterial();
	mat->id = "SkinnedGeometryOBJM:undefinedMaterial";
	mat->diffuse = Elea::Color4fRed;
	mat->texid = -1;
	mat->lightmap = 0;
	materials.push_back (mat);
	// Color materials
	for (size_t i = 0; i < bdata->materials.size (); i++) {
		OBJMData::Material& om(bdata->materials[i]);
		mat = new PMaterial();
		mat->id = om._data->cName;
		mat->diffuse.set (om._data->fDiffuse);
		mat->texid = -1;
		mat->lightmap = 0;
		om._materialidx = (int) materials.size ();
		materials.push_back (mat);
	}
	// Textured materials
	for (size_t i = 0; i < bdata->_objmtextures.size (); i++) {
		OBJMData::ObjmTextureData& ot(bdata->_objmtextures[i]);
		mat = new PMaterial();
		mat->id = ot._filename.c_str ();
		mat->diffuse = Elea::Color4fBlue;
		mat->texid = -1;
		for (size_t j = 0; j < textures.size (); j++) {
			if (!strcmp (mat->id, textures[j]->id)) {
				mat->texid = (int) j;
				break;
			}
		}
		mat->lightmap = ot.isshadow;
		ot._materialidx = (int) materials.size ();
		materials.push_back (mat);
	}
	nmaterials = (int) materials.size ();

	handler->unRef ();

	// Meshes & Blends
	// Calculate buffer size
	int nvertices = bdata->nmeshvertices;
	int nindices = bdata->nmeshindices;
	int nfrags = 0;
#if 0
	for (size_t i = 0; i < bdata->meshes.size (); i++) {
		OBJMData::Mesh& om(bdata->meshes[i]);
		if (om._data) {
			nvertices += (u32) om._data->dwVertexCount;
			nindices += (u32) om._data->dwIndexCount;
		}
	}
#endif
	for (size_t i = 0; i < bdata->blends.size (); i++) {
		OBJMData::Blend& ob(bdata->blends[i]);
		if (ob._data) {
			nvertices += (u32) ob._data->dwVertexCount;
			nindices += (u32) ob._data->dwIndexCount;
		}
	}
	for (size_t i = 0; i < bdata->meshes.size (); i++) {
		OBJMData::Mesh& om(bdata->meshes[i]);
		if ((om._frameidx < 0) || (!om._data)) continue;
		nfrags += 1;
	}
	for (size_t i = 0; i < bdata->_objmframes.size (); i++) {
		OBJMData::ObjmFrame& of(bdata->_objmframes[i]);
		if (of._blend < 0) continue;
		nfrags += 1;
	}
	// Initialize buffers
	setNumVertices (nvertices, true, true, true, true);
	setNumIndices (nindices);
	setNumFrags (nfrags);

	// Frame cleanup is done in OBJMData constructor
	// Morph cleanup is done in OBJMData constructor

	// Skeleton
	setNumBones ((int) bdata->_objmframes.size ());
	for (size_t i = 0; i < bdata->_objmframes.size (); i++) {
		OBJMData::ObjmFrame& of(bdata->_objmframes[i]);
		Elea::Matrix4x4f ft(shuffle16 (&of._data->fMatrix[0][0]));
		Elea::Matrix3x4f ft3(ft);
		ft3.setTranslation (scale * ft.getTranslation ());
		setBone ((int) i, of._data->cName, of._parent, ft3);
	}
	// Update bone matrixes
	initializeBoneMatrixes ();

	int vidx = 0;
	int iidx = 0;
	int fidx = 0;
	std::vector<VertexData> vdata;
	vdata.resize (nvertices);
	for (size_t i = 0; i < bdata->meshes.size (); i++) {
		OBJMData::Mesh& om(bdata->meshes[i]);
		if ((om._frameidx < 0) || (!om._data)) continue;
		frags[fidx].visible = 1;
		frags[fidx].matidx = bdata->getMaterialIdx (om._data->dwTextID, om._data->dwMateID);
		frags[fidx].firstindex = iidx;
		frags[fidx].numindices = (int) om._data->dwIndexCount;
		// om.firstvertex = vidx;
		Elea::Matrix4x4f tobase = bones[om._frameidx].ab2s;
		// Mesh vertices
		for (u32 j = 0; j < om._data->dwVertexCount; j++) {
			vbase[om.firstvertex + j] = tobase.transformPoint3 (scale * Elea::Vector3f(shuffle3 (&om._vdata[j].x)));
			nbase[om.firstvertex + j] = tobase.transformVector3 (Elea::Vector3f (shuffle3 (&om._vdata[j].nx)));
			xbase[om.firstvertex + j].set (om._vdata[j].tu, 1 - om._vdata[j].tv);
			vdata[om.firstvertex + j].frame0 = om._frameidx;
			vdata[om.firstvertex + j].weight0 = 1;
			vdata[om.firstvertex + j].frame1 = -1;
			vdata[om.firstvertex + j].weight1 = 0;
		}
		// Resolve cnsts
		for (size_t j = 0; j < om.cnsts.size (); j++) {
			OBJMData::ObjmCnst& cnst(bdata->_objmcnsts[om.cnsts[j]]);
			OBJMData::Mesh& meshA(bdata->meshes[cnst._meshA]);
			OBJMData::Mesh& meshB(bdata->meshes[cnst._meshB]);
			Bone& boneA(bones[cnst._frameA]);
			Bone& boneB(bones[cnst._frameB]);
			for (u32 k = 0; k < cnst._data->nPoints; k++) {
				int idxA = cnst.vidxA[k];
				int idxB = cnst.vidxB[k];
				const OBJMData::OBJM_VERTEX& vA(meshA._vdata[idxA]);
				const OBJMData::OBJM_VERTEX& vB(meshB._vdata[idxB]);
				Elea::Vector3f pA = boneA.ab2s.transformPoint3 (scale * Elea::Vector3f(shuffle3 (&vA.x)));
				Elea::Vector3f pB = boneB.ab2s.transformPoint3 (scale * Elea::Vector3f(shuffle3 (&vB.x)));
				Elea::Vector3f nA = boneA.ab2s.transformVector3 (Elea::Vector3f(shuffle3 (&vA.nx)));
				Elea::Vector3f nB = boneB.ab2s.transformVector3 (Elea::Vector3f(shuffle3 (&vB.nx)));
				Elea::Vector3f p = 0.5f * (pA + pB);
				Elea::Vector3f n = 0.5f * (nA + nB);
				if (cnst._meshA == (i32) i) {
					vbase[om.firstvertex + idxA] = p;
					nbase[om.firstvertex + idxA] = n;
					// This vertex is only influenced by current mesh
					vdata[om.firstvertex + idxA].weight0 = cnst.weightsA[k];
					vdata[om.firstvertex + idxA].frame1 = meshB._frameidx;
					vdata[om.firstvertex + idxA].weight1 = 1 - cnst.weightsA[k];
				} else {
					vbase[om.firstvertex + idxB] = p;
					nbase[om.firstvertex + idxB] = n;
					// This vertex is influenced by other mesh
					vdata[om.firstvertex + idxB].weight0 = 1 - cnst.weightsA[k];
					vdata[om.firstvertex + idxB].frame1 = meshA._frameidx;
					vdata[om.firstvertex + idxB].weight1 = cnst.weightsA[k];
				}
			}
		}
		// Mesh indices
		for (u32 j = 0; j < om._data->dwIndexCount; j += 3) {
			indices[iidx + j] = vidx + om._idata[j];
			indices[iidx + j + 1] = vidx + om._idata[j + 2];
			indices[iidx + j + 2] = vidx + om._idata[j + 1];
		}
		vidx += (int) om._data->dwVertexCount;
		iidx += (int) om._data->dwIndexCount;
		fidx += 1;
	}

	for (size_t i = 0; i < bdata->_objmframes.size (); i++) {
		OBJMData::ObjmFrame& of(bdata->_objmframes[i]);
		if (of._blend < 0) continue;
		OBJMData::Blend& ob(bdata->blends[of._blend]);
		frags[fidx].visible = 1;
		frags[fidx].matidx = bdata->getMaterialIdx (ob._data->idTEXT, ob._data->idMATE);
		frags[fidx].firstindex = iidx;
		frags[fidx].numindices = (int) ob._data->dwIndexCount;
		int firstvertex = vidx;
		Elea::Matrix4x4f tobase0 = bones[i].ab2s;
		Elea::Matrix4x4f tobase1 = bones[of._child].ab2s;
		for (u32 j = 0; j < ob._data->dwVertexCount; j++) {
			Elea::Vector3f p0(tobase0.transformPoint3 (scale * Elea::Vector3f(shuffle3 (&ob._vdata1[j].x))));
			// Check
			Elea::Vector3f p1(tobase1.transformPoint3 (scale * Elea::Vector3f(shuffle3 (&ob._vdata0[j].x))));
			Elea::Vector3f v(p1 - p0);
			if (v.length2 () > 0.01) {
				fprintf (stderr, "Oops, transformed blendpoints are not the same\n");
			}
			Elea::Vector3f n0(tobase0.transformVector3 (shuffle3 (&ob._vdata1[j].nx)));
			// Check
			Elea::Vector3f n1(tobase1.transformVector3 (shuffle3 (&ob._vdata0[j].nx)));
			v = (n1 - n0);
			if (v.length2 () > 0.01) {
				fprintf (stderr, "Oops, transformed blendnormals are not the same\n");
			}
			Elea::Vector2f t(ob._vdata0[j].tu, 1 - ob._vdata0[j].tv);

			vbase[firstvertex + j] = p0;
			nbase[firstvertex + j] = n0;
			xbase[firstvertex + j] = t;
			vdata[firstvertex + j].frame0 = (int) i;
			vdata[firstvertex + j].weight0 = ob._vdata0[j].weight;
			vdata[firstvertex + j].frame1 = of._child;
			vdata[firstvertex + j].weight1 = 1 - ob._vdata0[j].weight;
		}

		// Fill index buffer
		for (size_t j = 0; j < ob._data->dwIndexCount; j += 3) {
			indices[iidx + j] = vidx + ob._idata[j];
			indices[iidx + j + 1] = vidx + ob._idata[j + 2];
			indices[iidx + j + 2] = vidx + ob._idata[j + 1];
		}
		vidx += (int) ob._data->dwVertexCount;
		iidx += (int) ob._data->dwIndexCount;
		fidx += 1;
	}

	int nweights = 0;
	for (int i = 0; i < nvertices; i++) {
		if (vdata[i].weight0 > 0) {
			nweights += 1;
		}
		if (vdata[i].weight1 > 0) {
			nweights += 1;
		}
	}
	setNumWeights (nweights);
	int widx = 0;

	for (int i = 0; i < nvertices; i++) {
		wcounts[i] = 0;
		if (vdata[i].weight0 > 0) {
			weights[widx].bone = vdata[i].frame0;
			weights[widx].weight = vdata[i].weight0;
			widx += 1;
			wcounts[i] += 1;
		}
		if (vdata[i].weight1 > 0) {
			weights[widx].bone = vdata[i].frame1;
			weights[widx].weight = vdata[i].weight1;
			widx += 1;
			wcounts[i] += 1;
		}
	}

	// Morph data
	// Calculate the size of morph buffer
	nmorphvertices = 0;
	npmorphs = 0;
	for (size_t i = 0; i < bdata->morphs.size (); i++) {
		OBJMData::Morph& morph(bdata->morphs[i]);
		if (morph._mesh >= 0) {
			OBJMData::Mesh& mesh(bdata->meshes[morph._mesh]);
			for (size_t j = 0; j < morph._keys.size (); j++) {
				OBJMData::MorphKey& key(morph._keys[j]);
				if (key._kdata->dwVertexCount != mesh._data->dwVertexCount) {
					// fixme: Ignore this morph (Lauris)
					fprintf (stderr, "Bad, morphed mesh %s vertexcount differs from morph %d (%d != %d)\n", mesh._header->cName, (int) i, mesh._data->dwVertexCount, key._kdata->dwVertexCount);
				}
				nmorphvertices += key._kdata->dwVertexCount;
			}
			npmorphs += 1;
		}
	}
	vmorph = (Elea::Vector3f *) malloc (nmorphvertices * sizeof (Elea::Vector3f));
	nmorph = (Elea::Vector3f *) malloc (nmorphvertices * sizeof (Elea::Vector3f));
	pmorphs = (PMorph *) malloc (npmorphs * sizeof (PMorph));
	// Fill morph buffer and build PMesh morphs
	int mvidx = 0;
	int midx = 0;
	for (size_t i = 0; i < bdata->morphs.size (); i++) {
		OBJMData::Morph& omorph(bdata->morphs[i]);
		if (omorph._mesh >= 0) {
			OBJMData::Mesh& om(bdata->meshes[omorph._mesh]);

			pmorphs[midx].firstdstvertex = om.firstvertex;
			pmorphs[midx].firstsrcvertex = mvidx;
			pmorphs[midx].nvertices = om._data->dwVertexCount;
			pmorphs[midx].ntargets = (u32) omorph._keys.size ();

			Bone& bone(bones[om._frameidx]);
			Elea::Matrix3x4f& toskin = bone.ab2s;

			for (size_t j = 0; j < omorph._keys.size (); j++) {
				OBJMData::MorphKey& ok(omorph._keys[j]);
				// morph.times[j] = ok._kdata->fTime;
				for (u32 k = 0; k < ok._kdata->dwVertexCount; k++) {
					vmorph[mvidx + k] = toskin.transformPoint3 (scale * Elea::Vector3f(shuffle3 (&ok._vdata[k].x)));
					nmorph[mvidx + k] = toskin.transformVector3 (scale * Elea::Vector3f(shuffle3 (&ok._vdata[k].nx)));
				}
				mvidx += ok._kdata->dwVertexCount;
			}

			midx += 1;
		}
	}

	// Invalidate source
	// fixme: We need bdata for building animations etc. (Lauris)
	// bdata->unRef ();
	// bdata = NULL;

	// Calculate bone bounding boxes
	initializeBoneBBoxes ();

	// Update bone status
	updateBoneStatus ();

	// Emit signal
	sig_definition_changed.invoke (this);

	requestUpdate (MODIFIED | ANIMATION_MODIFIED);
}

void
GeometryOBJM::buildMorphs (Thera::Node *parentnode, const char *geometry)
{
	if (!bdata) return;
	for (size_t i = 0; i < bdata->morphs.size (); i++) {
		char c[256];
		Thera::Node *morphnode = new Thera::Node(parentnode->document, "morph");
		sprintf (c, "morph-%d", bdata->morphs[i]._header->dwID);
		morphnode->setAttribute ("sid", c);
		for (u32 j = 0; j < bdata->morphs[i]._keys.size (); j++) {
			Thera::Node *targetnode = new Thera::Node(parentnode->document, "morphTargetOBJM");
			targetnode->setAttribute ("geometry", geometry);
			targetnode->setAttributeInt ("morph", (int) i);
			targetnode->setAttributeInt ("target", (int) j);
			targetnode->setAttribute ("source", bdata->getURI ());
			morphnode->appendChild (targetnode);
		}
		parentnode->appendChild (morphnode);
	}
}

void
GeometryOBJM::buildAnimations (Thera::Node *parentnode, const char *geometry)
{
	if (!bdata) return;
	for (size_t i = 0; i < bdata->animations.size (); i++) {
		char c[256];
		Thera::Node *animnode = new Thera::Node (parentnode->document, "animation:skinAnimation");
		sprintf (c, "animation-%d", bdata->animations[i].header->dwID);
		animnode->setAttribute ("sid", c);
		// fixme: Is there always only one animation?
		for (size_t j = 0; j < bdata->morphs.size (); j++) {
			Thera::Node *bnode = new Thera::Node(parentnode->document, "keyFrameAnimationOBJM");
			bnode->setAttribute ("geometry", geometry);
			bnode->setAttributeInt ("morph", (int) j);
			bnode->setAttribute ("source", bdata->getURI ());
			animnode->appendChild (bnode);
		}
		for (size_t j = 0; j < bdata->animations[i].frameanims.size (); j++) {
			Thera::Node *bnode = new Thera::Node(parentnode->document, "boneAnimationOBJM");
			OBJMData::FrameAnimation *fanim = &bdata->animations[i].frameanims[j];
			int frameidx = bdata->lookupFrame (fanim->data->dwFramID);
			bnode->setAttribute ("bone", bdata->_objmframes[frameidx]._data->cName);
			bnode->setAttributeInt ("animation", (int) i);
			bnode->setAttributeInt ("frameAnimation", (int) j);
			bnode->setAttribute ("source", bdata->getURI ());
			animnode->appendChild (bnode);
		}

		parentnode->appendChild (animnode);
	}
}

// MorphtargetOBJM

MorphTargetOBJM::MorphTargetOBJM (void)
: MorphTarget(0), source(NULL), morphidx(-1), targetidx(-1), bdata(NULL), pvdata(NULL), pndata(NULL), pindices(NULL)
{
}

MorphTargetOBJM::~MorphTargetOBJM (void)
{
	if (bdata) bdata->unRef ();
	if (source) free (source);
}

static Object *
morphtargetobjm_factory (void)
{
	return new MorphTargetOBJM();
}

const Object::Type *
MorphTargetOBJM::objectType (void)
{
	return type ();
}

const Object::Type *
MorphTargetOBJM::type (void)
{
	static Type *mytype = NULL;
	static const Attribute attrs[] = {
		{ "source", NULL, 0 },
		{ "morph", "-1", 0 },
		{ "target", "-1", 0 }
	};
	if (!mytype) mytype = new Type(MorphTarget::type (), "MorphTargetOBJM", "morphTargetOBJM", morphtargetobjm_factory, sizeof (attrs) / sizeof (attrs[0]), attrs);
	return mytype;
}

void
MorphTargetOBJM::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	MorphTarget::build (pnode, doc, ctx);

	buildAllAttributes (type (), ctx);

}

void
MorphTargetOBJM::release (void)
{
	if (pvdata) {
		free (pvdata);
		pvdata = NULL;
	}
	if (pndata) {
		free (pndata);
		pndata = NULL;
	}
	if (pindices) {
		free (pindices);
		pindices = NULL;
	}

	MorphTarget::release ();
}

void
MorphTargetOBJM::set (const char *attrid, const char *val)
{
	if (!strcmp (attrid, "source")) {
		if (source) free (source);
		source = (val) ? strdup (val) : NULL;
		if (bdata) {
			bdata->unRef ();
			bdata = NULL;
		}
		if (source) {
			bdata = OBJMData::getOBJMData (source);
		}
		updateData ();
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "morph")) {
		morphidx = (val) ? atoi (val) : -1;
		updateData ();
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "target")) {
		targetidx = (val) ? atoi (val) : -1;
		updateData ();
		requestUpdate (MODIFIED);
	} else {
		// MorphTarget does not implement ::set
		// MorphTarget::set (attrid, val);
	}
}

void
MorphTargetOBJM::updateData (void)
{
	float scale = DefaultScale;

	vdata = NULL;
	ndata = NULL;
	indices = NULL;
	if (pvdata) {
		free (pvdata);
		pvdata = NULL;
	}
	if (pndata) {
		free (pndata);
		pndata = NULL;
	}
	if (pindices) {
		free (pindices);
		pindices = NULL;
	}
	numindices = 0;
	maxindex = 0;

	if (!bdata) return;
	if ((morphidx < 0) || (targetidx < 0)) return;
	if (morphidx >= (int) bdata->morphs.size ()) return;
	if (targetidx >= (int) bdata->morphs[morphidx]._keys.size ()) return;

	OBJMData::Morph *morph = &bdata->morphs[morphidx];
	if (morph->_mesh < 0) return;
	OBJMData::Mesh *mesh = &bdata->meshes[morph->_mesh];
	OBJMData::ObjmFrame *frame = &bdata->_objmframes[mesh->_frameidx];

	int nvertices = morph->_keys[targetidx]._kdata->dwVertexCount;
	// int nvertices = mesh->_data->dwVertexCount;
	numindices = morph->_keys[targetidx]._kdata->dwVertexCount;
	pvdata = (Elea::Vector3f *) malloc (nvertices * sizeof (Elea::Vector3f));
	pndata = (Elea::Vector3f *) malloc (nvertices * sizeof (Elea::Vector3f));
	pindices = (u32 *) malloc (numindices * sizeof (u32));

	for (int i = 0; i < nvertices; i++) {
		Elea::Matrix4x4f m2s = frame->f2s;
		// m2s.setTranslation (scale * m2s.getTranslation ());
		pvdata[i] = scale * m2s.transformPoint3 (Elea::Vector3f(shuffle3 (&morph->_keys[targetidx]._vdata[i].x)));
		pndata[i] = m2s.transformVector3 (Elea::Vector3f(shuffle3 (&morph->_keys[targetidx]._vdata[i].nx)));
		pindices[i] = mesh->firstvertex + i;
	}

	vdata = pvdata;
	ndata = pndata;
	indices = pindices;
	maxindex = mesh->firstvertex + nvertices - 1;
}

// BoneAnimationOBJM

BoneAnimationOBJM::BoneAnimationOBJM (void)
: BoneAnimation(0), source(NULL), animidx(-1), frameidx(-1), bdata(NULL), pframetimes(NULL), porientations(NULL)
{
	fps = 30;
}

BoneAnimationOBJM::~BoneAnimationOBJM (void)
{
	if (bdata) bdata->unRef ();
	if (source) free (source);
}

static Object *
boneanimationobjm_factory (void)
{
	return new BoneAnimationOBJM();
}

const Object::Type *
BoneAnimationOBJM::objectType (void)
{
	return type ();
}

const Object::Type *
BoneAnimationOBJM::type (void)
{
	static Type *mytype = NULL;
	static const Attribute attrs[] = {
		{ "source", NULL, 0 },
		{ "animation", "-1", 0 },
		{ "frameAnimation", "-1", 0 }
	};
	if (!mytype) mytype = new Type(BoneAnimation::type (), "BoneAnimationOBJM", "boneAnimationOBJM", boneanimationobjm_factory, sizeof (attrs) / sizeof (attrs[0]), attrs);
	return mytype;
}

void
BoneAnimationOBJM::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	BoneAnimation::build (pnode, doc, ctx);

	buildAllAttributes (type (), ctx);

}

void
BoneAnimationOBJM::release (void)
{
	if (porientations) {
		free (porientations);
		porientations = NULL;
	}

	if (pframetimes) {
		free (pframetimes);
		pframetimes = NULL;
	}

	BoneAnimation::release ();
}

void
BoneAnimationOBJM::set (const char *attrid, const char *val)
{
	if (!strcmp (attrid, "source")) {
		if (source) free (source);
		source = (val) ? strdup (val) : NULL;
		if (bdata) {
			bdata->unRef ();
			bdata = NULL;
		}
		if (source) {
			bdata = OBJMData::getOBJMData (source);
		}
		updateData ();
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "animation")) {
		animidx = (val) ? atoi (val) : -1;
		updateData ();
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "frameAnimation")) {
		frameidx = (val) ? atoi (val) : -1;
		updateData ();
		requestUpdate (MODIFIED);
	} else {
		BoneAnimation::set (attrid, val);
	}
}

Elea::Vector3f
BoneAnimationOBJM::getPosition (unsigned int frameidx)
{
	return (frameidx < nframes) ? porientations[frameidx].p : Elea::Vector3f0;
}

Elea::Quaternionf
BoneAnimationOBJM::getQuaternion (unsigned int frameidx)
{
	return (frameidx < nframes) ? porientations[frameidx].q : Elea::Quaternionf0;
}

void
BoneAnimationOBJM::updateData (void)
{
	float scale = DefaultScale;

	frametimes = NULL;
	if (pframetimes) {
		free (pframetimes);
		pframetimes = NULL;
	}
	if (porientations) {
		free (porientations);
		porientations = NULL;
	}
	nframes = 0;
	maxframetime = 0;

	if (!bdata) return;
	if ((animidx < 0) || (frameidx < 0)) return;
	if (animidx >= (int) bdata->animations.size ()) return;
	if (frameidx >= (int) bdata->animations[animidx].frameanims.size ()) return;

	OBJMData::FrameAnimation *fanim = &bdata->animations[animidx].frameanims[frameidx];
	int frameidx = bdata->lookupFrame (fanim->data->dwFramID);
	if (frameidx < 0) return;
	nframes = fanim->data->dwCount;
	if (nframes < 1) return;
	// bonesid = strdup (bdata->_objmframes[frameidx]._data->cName);

	pframetimes = (float *) malloc (nframes * sizeof (float));
	porientations = (Orientation *) malloc (nframes * sizeof (Orientation));
	for (u32 i = 0; i < nframes; i++) {
		const OBJMData::OBJM_ANIM_KEY *key = &fanim->keys[i];
		pframetimes[i] = key->fTime;
		Elea::Matrix4x4f t(shuffle16 (&key->fMatrix[0][0]));
		porientations[i].q = t.getRotationQuaternion ();
		porientations[i].p = scale * t.getTranslation ();
	}
	frametimes = pframetimes;
	maxframetime = frametimes[0];
	maxframetime = frametimes[nframes - 1];
}

// KeyFrameAnimationOBJM

KeyFrameAnimationOBJM::KeyFrameAnimationOBJM (void)
: KeyFrameAnimation(0), source(NULL), morphidx(-1), bdata(NULL), pindices(NULL), pframetimes(NULL), pvdata(NULL), pndata(NULL)
{
	fps = 30;
}

KeyFrameAnimationOBJM::~KeyFrameAnimationOBJM (void)
{
	if (bdata) bdata->unRef ();
	if (source) free (source);
}

static Object *
keyframeanimationobjm_factory (void)
{
	return new KeyFrameAnimationOBJM();
}

const Object::Type *
KeyFrameAnimationOBJM::objectType (void)
{
	return type ();
}

const Object::Type *
KeyFrameAnimationOBJM::type (void)
{
	static Type *mytype = NULL;
	static const Attribute attrs[] = {
		{ "source", NULL, 0 },
		{ "morph", "-1", 0 }
	};
	if (!mytype) mytype = new Type(KeyFrameAnimation::type (), "KeyFrameAnimationOBJM", "keyFrameAnimationOBJM", keyframeanimationobjm_factory, sizeof (attrs) / sizeof (attrs[0]), attrs);
	return mytype;
}

void
KeyFrameAnimationOBJM::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	KeyFrameAnimation::build (pnode, doc, ctx);

	buildAllAttributes (type (), ctx);

}

void
KeyFrameAnimationOBJM::release (void)
{
	if (pindices) {
		free (pindices);
		pindices = NULL;
	}
	if (pframetimes) {
		free (pframetimes);
		pframetimes = NULL;
	}
	if (pvdata) {
		free (pvdata);
		pvdata = NULL;
	}
	if (pndata) {
		free (pndata);
		pndata = NULL;
	}

	KeyFrameAnimation::release ();
}

void
KeyFrameAnimationOBJM::set (const char *attrid, const char *val)
{
	if (!strcmp (attrid, "source")) {
		if (source) free (source);
		source = (val) ? strdup (val) : NULL;
		if (bdata) {
			bdata->unRef ();
			bdata = NULL;
		}
		if (source) {
			bdata = OBJMData::getOBJMData (source);
		}
		updateData ();
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "morph")) {
		morphidx = (val) ? atoi (val) : -1;
		updateData ();
		requestUpdate (MODIFIED);
	} else {
		KeyFrameAnimation::set (attrid, val);
	}
}

void
KeyFrameAnimationOBJM::updateData (void)
{
	float scale = DefaultScale;

	indices = NULL;
	frametimes = NULL;
	vdata = NULL;
	ndata = NULL;
	if (pindices) {
		free (pindices);
		pindices = NULL;
	}
	if (pframetimes) {
		free (pframetimes);
		pframetimes = NULL;
	}
	if (pvdata) {
		free (pvdata);
		pvdata = NULL;
	}
	if (pndata) {
		free (pndata);
		pndata = NULL;
	}
	numindices = 0;
	minindex = 0;
	maxindex = 0;
	nframes = 0;
	maxframetime = 0;

	if (!bdata) return;
	if (morphidx < 0) return;
	if (morphidx >= (int) bdata->morphs.size ()) return;

	OBJMData::Morph *morph = &bdata->morphs[morphidx];
	if (morph->_mesh < 0) return;
	if (morph->_keys.empty ()) return;
	OBJMData::Mesh *mesh = &bdata->meshes[morph->_mesh];
	OBJMData::ObjmFrame *frame = &bdata->_objmframes[mesh->_frameidx];

	numindices = morph->_keys[0]._kdata->dwVertexCount;
	if (numindices < 1) return;
	nframes = morph->_data->dwCount;
	if (nframes < 1) return;

	int nvertices = morph->_keys[0]._kdata->dwVertexCount;

	pindices = (u32 *) malloc (numindices * sizeof (u32));
	pframetimes = (float *) malloc (nframes * sizeof (float));
	pvdata = (Elea::Vector3f *) malloc (nframes * nvertices * sizeof (Elea::Vector3f));
	pndata = (Elea::Vector3f *) malloc (nframes * nvertices * sizeof (Elea::Vector3f));

	for (int i = 0; i < nvertices; i++) {
		pindices[i] = mesh->firstvertex + i;
	}

	Elea::Matrix4x4f m2s = frame->f2s;
	for (u32 i = 0; i < nframes; i++) {
		pframetimes[i] = morph->_keys[i]._kdata->fTime;
		for (int j = 0; j < nvertices; j++) {
			pvdata[i * nvertices + j] = scale * m2s.transformPoint3 (Elea::Vector3f(shuffle3 (&morph->_keys[i]._vdata[j].x)));
			pndata[i * nvertices + j] = m2s.transformVector3 (Elea::Vector3f(shuffle3 (&morph->_keys[i]._vdata[j].nx)));
		}
	}
	indices = pindices;
	maxindex = mesh->firstvertex;
	maxindex = mesh->firstvertex + nvertices - 1;
	frametimes = pframetimes;
	vdata = pvdata;
	ndata = pndata;
	maxframetime = frametimes[0];
	maxframetime = frametimes[nframes - 1];
}

} // Namespace Miletos

