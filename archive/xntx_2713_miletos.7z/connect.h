#ifndef __MILETOS_CONNECT_H__
#define __MILETOS_CONNECT_H__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2007
//

#include "signal.h"

namespace Miletos {

namespace Signals {

//
// Here are templates that are only needed for connecting to signals
// to reduce the clutter (and parsing time) in library headers
//

// Slot0

// Extended slot, capable of calling static functions

template<typename RET>
class Slot0S : public Slot0<RET>
{
private:
	// Callback
	RET (*_method) (void);
	// Duplication
	static Slot *duplicate (const Slot& base) {
		return new Slot0S(*((const Slot0S *) &base));
	}
	// Invocation
	static RET invoke (Slot0<RET> *base, void *data) {
		Slot0S *slot = (Slot0S *) base;
		return slot->_method ();
	}
	// Default copy constructor should work
public:
	// Constructor
	Slot0S (RET (*method) (void)) : Slot0<RET>(duplicate, invoke, 0), _method(method) {}
	Slot0S (RET (*method) (void), const void *data) : Slot0<RET>(duplicate, invoke, (void *) data), _method(method) {}
};

template<typename RET, typename DATA>
class Slot0SD : public Slot0<RET>
{
private:
	// Callback
	RET (*_method) (DATA *);
	// Duplication
	static Slot *duplicate (const Slot& base) {
		return new Slot0SD(*((const Slot0SD *) &base));
	}
	// Invocation
	static RET invoke (Slot0<RET> *base, void *data) {
		Slot0SD *slot = (Slot0SD *) base;
		return slot->_method ((DATA *) data);
	}
public:
	// Constructor
	Slot0SD (RET (*method) (DATA *), DATA *data) : Slot0<RET>(duplicate, invoke, (void *) data), _method(method) {}
};

// Extended slot, capable of calling object members

template<typename OBJ, typename RET>
class Slot0O : public Slot0<RET>
{
private:
	// Callback
	RET (OBJ::*_method) (void);
	OBJ *_object;
	// Duplication
	static Slot *duplicate (const Slot& base) {
		return new Slot0O(*((const Slot0O *) &base));
	}
	// Invocation
	static RET invoke (Slot0<RET> *base, void *data) {
		Slot0O *slot = (Slot0O *) base;
		return (slot->_object->*slot->_method) ();
	}
public:
	// Constructor
	Slot0O (OBJ& object, RET (OBJ::*method) (void)) : Slot0<RET>(duplicate, invoke, 0), _method(method), _object(&object) {}
	Slot0O (OBJ& object, RET (OBJ::*method) (void), const void *data) : Slot0<RET>(duplicate, invoke, (void *) data), _method(method), _object(&object) {}
};

template<typename OBJ, typename RET, typename DATA>
class Slot0OD : public Slot0<RET>
{
private:
	// Callback
	RET (OBJ::*_method) (DATA *);
	OBJ *_object;
	// Duplication
	static Slot *duplicate (const Slot& base) {
		return new Slot0OD(*((const Slot0OD *) &base));
	}
	// Invocation
	static RET invoke (Slot0<RET> *base, void *data) {
		Slot0OD *slot = (Slot0OD *) base;
		return (slot->_object->*slot->_method) ((DATA *) data);
	}
public:
	// Constructor
	Slot0OD (OBJ& object, RET (OBJ::*method) (DATA *), DATA *data) : Slot0<RET>(duplicate, invoke, (void *) data), _method(method), _object(&object) {}
};

// Static callback
template <class RET>
inline Slot0S<RET> STATIC_SLOT (RET (*method) (void)) { return Slot0S<RET>(method); }
// Static callback + data
template <class RET>
inline Slot0S<RET> STATIC_SLOT (RET (*method) (void), const void *data) { return Slot0S<RET>(method, data); }
// Static callback_data + data
template <class RET, class DATA>
inline Slot0SD<RET, DATA> STATIC_SLOT (RET (*method) (DATA *), DATA *data) { return Slot0SD<RET, DATA>(method, data); }
// Member callback
template <class RET, class OBJ, class OBJ2>
inline Slot0O<OBJ, RET> MEMBER_SLOT (OBJ& object, RET (OBJ2::*method) (void)) { return Slot0O<OBJ, RET>(object, method); }
// Member callback + data
template <class RET, class OBJ, class OBJ2>
inline Slot0O<OBJ, RET> MEMBER_SLOT (OBJ& object, RET (OBJ2::*method) (void), const void *data) { return Slot0O<OBJ, RET>(object, method, data); }
// Member callback_data + data
template <class RET, class DATA, class OBJ, class OBJ2>
inline Slot0OD<OBJ, RET, DATA> MEMBER_SLOT (OBJ& object, RET (OBJ2::*method) (DATA *), DATA *data) { return Slot0OD<OBJ, RET, DATA>(object, method, data); }

// Slot1

// Extended slot, capable of calling static functions

template<typename RET, typename ARG1>
class Slot1S : public Slot1<RET,ARG1>
{
private:
	// Callback
	RET (*_method) (ARG1);
	// Duplication
	static Slot *duplicate (const Slot& base) {
		return new Slot1S(*((const Slot1S *) &base));
	}
	// Invocation
	static RET invoke (Slot1<RET,ARG1> *base, ARG1 arg1, void *data) {
		Slot1S *slot = (Slot1S *) base;
		return slot->_method (arg1);
	}
	// Default copy constructor should work
public:
	// Constructor
	Slot1S (RET (*method) (ARG1)) : Slot1<RET,ARG1>(duplicate, invoke, 0), _method(method) {}
	Slot1S (RET (*method) (ARG1), const void *data) : Slot1<RET,ARG1>(duplicate, invoke, (void *) data), _method(method) {}
};

template<typename RET, typename ARG1, typename DATA>
class Slot1SD : public Slot1<RET, ARG1>
{
private:
	// Callback
	RET (*_method) (ARG1, DATA *);
	// Duplication
	static Slot *duplicate (const Slot& base) {
		return new Slot1SD(*((const Slot1SD *) &base));
	}
	// Invocation
	static RET invoke (Slot1<RET, ARG1> *base, ARG1 arg1, void *data) {
		Slot1SD *slot = (Slot1SD *) base;
		return slot->_method (arg1, (DATA *) data);
	}
public:
	// Constructor
	Slot1SD (RET (*method) (ARG1, DATA *), DATA *data) : Slot1<RET, ARG1>(duplicate, invoke, (void *) data), _method(method) {}
};

// Extended slot, capable of calling object members

template<typename OBJ, typename RET, typename ARG1>
class Slot1O : public Slot1<RET, ARG1>
{
private:
	// Callback
	RET (OBJ::*_method) (ARG1);
	OBJ *_object;
	// Duplication
	static Slot *duplicate (const Slot& base) {
		return new Slot1O(*((const Slot1O *) &base));
	}
	// Invocation
	static RET invoke (Slot1<RET, ARG1> *base, ARG1 arg1, void *data) {
		Slot1O *slot = (Slot1O *) base;
		return (slot->_object->*slot->_method) (arg1);
	}
public:
	// Constructor
	Slot1O (OBJ& object, RET (OBJ::*method) (ARG1)) : Slot1<RET, ARG1>(duplicate, invoke, 0), _method(method), _object(&object) {}
	Slot1O (OBJ& object, RET (OBJ::*method) (ARG1), const void *data) : Slot1<RET, ARG1>(duplicate, invoke, (void *) data), _method(method), _object(&object) {}
};

template<typename OBJ, typename RET, typename ARG1, typename DATA>
class Slot1OD : public Slot1<RET, ARG1>
{
private:
	// Callback
	RET (OBJ::*_method) (ARG1, DATA *);
	OBJ *_object;
	// Duplication
	static Slot *duplicate (const Slot& base) {
		return new Slot1OD(*((const Slot1OD *) &base));
	}
	// Invocation
	static RET invoke (Slot1<RET, ARG1> *base, ARG1 arg1, void *data) {
		Slot1OD *slot = (Slot1OD *) base;
		return (slot->_object->*slot->_method) (arg1, (DATA *) data);
	}
public:
	// Constructor
	Slot1OD (OBJ& object, RET (OBJ::*method) (ARG1, DATA *), DATA *data) : Slot1<RET, ARG1>(duplicate, invoke, (void *) data), _method(method), _object(&object) {}
};

// Static callback
template <class RET, class ARG1>
inline Slot1S<RET, ARG1> STATIC_SLOT (RET (*method) (ARG1)) { return Slot1S<RET, ARG1>(method); }
// Static callback + data
template <class RET, class ARG1>
inline Slot1S<RET, ARG1> STATIC_SLOT (RET (*method) (ARG1), const void *data) { return Slot1S<RET, ARG1>(method, data); }
// Static callback_data + data
template <class RET, class ARG1, class DATA>
inline Slot1SD<RET, ARG1, DATA> STATIC_SLOT (RET (*method) (ARG1, DATA *), DATA *data) { return Slot1SD<RET, ARG1, DATA>(method, data); }
// Member callback
template <class RET, class ARG1, class OBJ, class OBJ2>
inline Slot1O<OBJ, RET, ARG1> MEMBER_SLOT (OBJ& object, RET (OBJ2::*method) (ARG1)) { return Slot1O<OBJ, RET, ARG1>(object, method); }
// Member callback + data
template <class RET, class ARG1, class OBJ, class OBJ2>
inline Slot1O<OBJ, RET, ARG1> MEMBER_SLOT (OBJ& object, RET (OBJ2::*method) (ARG1), const void *data) { return Slot1O<OBJ, RET, ARG1>(object, method, data); }
// Member callback_data + data
template <class RET, class ARG1, class DATA, class OBJ, class OBJ2>
inline Slot1OD<OBJ, RET, ARG1, DATA> MEMBER_SLOT (OBJ& object, RET (OBJ2::*method) (ARG1, DATA *), DATA *data) { return Slot1OD<OBJ, RET, ARG1, DATA>(object, method, data); }

// Slot2

// Extended slot, capable of calling static functions

template<typename RET, typename ARG1, typename ARG2>
class Slot2S : public Slot2<RET,ARG1,ARG2>
{
private:
	// Callback
	RET (*_method) (ARG1, ARG2);
	// Duplication
	static Slot *duplicate (const Slot& base) {
		return new Slot2S(*((const Slot2S *) &base));
	}
	// Invocation
	static RET invoke (Slot2<RET,ARG1,ARG2> *base, ARG1 arg1, ARG2 arg2, void *data) {
		Slot2S *slot = (Slot2S *) base;
		return slot->_method (arg1, arg2);
	}
	// Default copy constructor should work
public:
	// Constructor
	Slot2S (RET (*method) (ARG1, ARG2)) : Slot2<RET,ARG1,ARG2>(duplicate, invoke, 0), _method(method) {}
	Slot2S (RET (*method) (ARG1, ARG2), const void *data) : Slot2<RET,ARG1,ARG2>(duplicate, invoke, (void *) data), _method(method) {}
};

template<typename RET, typename ARG1, typename ARG2, typename DATA>
class Slot2SD : public Slot2<RET, ARG1, ARG2>
{
private:
	// Callback
	RET (*_method) (ARG1, ARG2, DATA *);
	// Duplication
	static Slot *duplicate (const Slot& base) {
		return new Slot2SD(*((const Slot2SD *) &base));
	}
	// Invocation
	static RET invoke (Slot2<RET,ARG1,ARG2> *base, ARG1 arg1, ARG2 arg2, void *data) {
		Slot2SD *slot = (Slot2SD *) base;
		return slot->_method (arg1, arg2, (DATA *) data);
	}
public:
	// Constructor
	Slot2SD (RET (*method) (ARG1, ARG2, DATA *), DATA *data) : Slot2<RET,ARG1,ARG2>(duplicate, invoke, (void *) data), _method(method) {}
};

// Extended slot, capable of calling object members

template<typename OBJ, typename RET, typename ARG1, typename ARG2>
class Slot2O : public Slot2<RET, ARG1, ARG2>
{
private:
	// Callback
	RET (OBJ::*_method) (ARG1, ARG2);
	OBJ *_object;
	// Duplication
	static Slot *duplicate (const Slot& base) {
		return new Slot2O(*((const Slot2O *) &base));
	}
	// Invocation
	static RET invoke (Slot2<RET, ARG1, ARG2> *base, ARG1 arg1, ARG2 arg2, void *data) {
		Slot2O *slot = (Slot2O *) base;
		return (slot->_object->*slot->_method) (arg1, arg2);
	}
public:
	// Constructor
	Slot2O (OBJ& object, RET (OBJ::*method) (ARG1, ARG2)) : Slot2<RET, ARG1, ARG2>(duplicate, invoke, 0), _method(method), _object(&object) {}
	Slot2O (OBJ& object, RET (OBJ::*method) (ARG1, ARG2), const void *data) : Slot2<RET, ARG1, ARG2>(duplicate, invoke, (void *) data), _method(method), _object(&object) {}
};

template<typename OBJ, typename RET, typename ARG1, typename ARG2, typename DATA>
class Slot2OD : public Slot2<RET, ARG1, ARG2>
{
private:
	// Callback
	RET (OBJ::*_method) (ARG1, ARG2, DATA *);
	OBJ *_object;
	// Duplication
	static Slot *duplicate (const Slot& base) {
		return new Slot2OD(*((const Slot2OD *) &base));
	}
	// Invocation
	static RET invoke (Slot2<RET, ARG1, ARG2> *base, ARG1 arg1, ARG2 arg2, void *data) {
		Slot2OD *slot = (Slot2OD *) base;
		return (slot->_object->*slot->_method) (arg1, arg2, (DATA *) data);
	}
public:
	// Constructor
	Slot2OD (OBJ& object, RET (OBJ::*method) (ARG1, ARG2, DATA *), DATA *data) : Slot2<RET, ARG1, ARG2>(duplicate, invoke, (void *) data), _method(method), _object(&object) {}
};
// Static callback
template <class RET, class ARG1, class ARG2>
inline Slot2S<RET, ARG1, ARG2> STATIC_SLOT (RET (*method) (ARG1, ARG2)) { return Slot2S<RET, ARG1, ARG2>(method); }
// Static callback + data
template <class RET, class ARG1, class ARG2>
inline Slot2S<RET, ARG1, ARG2> STATIC_SLOT (RET (*method) (ARG1, ARG2), const void *data) { return Slot2S<RET, ARG1, ARG2>(method, data); }
// Static callback_data + data
template <class RET, class ARG1, class ARG2, class DATA>
inline Slot2SD<RET, ARG1, ARG2, DATA> STATIC_SLOT (RET (*method) (ARG1, ARG2, DATA *), DATA *data) { return Slot2SD<RET, ARG1, ARG2, DATA>(method, data); }
// Member callback
template <class RET, class ARG1, class ARG2, class OBJ, class OBJ2>
inline Slot2O<OBJ, RET, ARG1, ARG2> MEMBER_SLOT (OBJ& object, RET (OBJ2::*method) (ARG1, ARG2)) { return Slot2O<OBJ, RET, ARG1, ARG2>(object, method); }
// Member callback + data
template <class RET, class ARG1, class ARG2, class OBJ, class OBJ2>
inline Slot2O<OBJ, RET, ARG1, ARG2> MEMBER_SLOT (OBJ& object, RET (OBJ2::*method) (ARG1, ARG2), const void *data) { return Slot2O<OBJ, RET, ARG1, ARG2>(object, method, data); }
// Member callback_data + data
template <class RET, class ARG1, class ARG2, class DATA, class OBJ, class OBJ2>
inline Slot2OD<OBJ, RET, ARG1, ARG2, DATA> MEMBER_SLOT (OBJ& object, RET (OBJ2::*method) (ARG1, ARG2, DATA *), DATA *data) { return Slot2OD<OBJ, RET, ARG1, ARG2, DATA>(object, method, data); }

// Slot3

// Extended slot, capable of calling static functions

template<typename RET, typename ARG1, typename ARG2, typename ARG3>
class Slot3S : public Slot3<RET,ARG1,ARG2,ARG3>
{
private:
	// Callback
	RET (*_method) (ARG1, ARG2, ARG3);
	// Duplication
	static Slot *duplicate (const Slot& base) {
		return new Slot3S(*((const Slot3S *) &base));
	}
	// Invocation
	static RET invoke (Slot3<RET,ARG1,ARG2,ARG3> *base, ARG1 arg1, ARG2 arg2, ARG3 arg3, void *data) {
		Slot3S *slot = (Slot3S *) base;
		return slot->_method (arg1, arg2, arg3);
	}
	// Default copy constructor should work
public:
	// Constructor
	Slot3S (RET (*method) (ARG1, ARG2, ARG3)) : Slot3<RET,ARG1,ARG2,ARG3>(duplicate, invoke, 0), _method(method) {}
	Slot3S (RET (*method) (ARG1, ARG2, ARG3), const void *data) : Slot3<RET,ARG1,ARG2,ARG3>(duplicate, invoke, (void *) data), _method(method) {}
};

template<typename RET, typename ARG1, typename ARG2, typename ARG3, typename DATA>
class Slot3SD : public Slot3<RET, ARG1, ARG2, ARG3>
{
private:
	// Callback
	RET (*_method) (ARG1, ARG2, ARG3, DATA *);
	// Duplication
	static Slot *duplicate (const Slot& base) {
		return new Slot3SD(*((const Slot3SD *) &base));
	}
	// Invocation
	static RET invoke (Slot3<RET,ARG1,ARG2,ARG3> *base, ARG1 arg1, ARG2 arg2, ARG3 arg3, void *data) {
		Slot3SD *slot = (Slot3SD *) base;
		return slot->_method (arg1, arg2, arg3, (DATA *) data);
	}
public:
	// Constructor
	Slot3SD (RET (*method) (ARG1, ARG2, ARG3, DATA *), DATA *data) : Slot3<RET,ARG1,ARG2,ARG3>(duplicate, invoke, (void *) data), _method(method) {}
};

// Extended slot, capable of calling object members

template<typename OBJ, typename RET, typename ARG1, typename ARG2, typename ARG3>
class Slot3O : public Slot3<RET, ARG1, ARG2, ARG3>
{
private:
	// Callback
	RET (OBJ::*_method) (ARG1, ARG2, ARG3);
	OBJ *_object;
	// Duplication
	static Slot *duplicate (const Slot& base) {
		return new Slot3O(*((const Slot3O *) &base));
	}
	// Invocation
	static RET invoke (Slot3<RET, ARG1, ARG2, ARG3> *base, ARG1 arg1, ARG2 arg2, ARG3 arg3, void *data) {
		Slot3O *slot = (Slot3O *) base;
		return (slot->_object->*slot->_method) (arg1, arg2, arg3);
	}
public:
	// Constructor
	Slot3O (OBJ& object, RET (OBJ::*method) (ARG1, ARG2, ARG3)) : Slot3<RET, ARG1, ARG2, ARG3>(duplicate, invoke, 0), _method(method), _object(&object) {}
	Slot3O (OBJ& object, RET (OBJ::*method) (ARG1, ARG2, ARG3), const void *data) : Slot3<RET, ARG1, ARG2, ARG3>(duplicate, invoke, (void *) data), _method(method), _object(&object) {}
};

template<typename OBJ, typename RET, typename ARG1, typename ARG2, typename ARG3, typename DATA>
class Slot3OD : public Slot3<RET, ARG1, ARG2, ARG3>
{
private:
	// Callback
	RET (OBJ::*_method) (ARG1, ARG2, ARG3, DATA *);
	OBJ *_object;
	// Duplication
	static Slot *duplicate (const Slot& base) {
		return new Slot3OD(*((const Slot3OD *) &base));
	}
	// Invocation
	static RET invoke (Slot3<RET,ARG1,ARG2,ARG3> *base, ARG1 arg1, ARG2 arg2, ARG3 arg3, void *data) {
		Slot3OD *slot = (Slot3OD *) base;
		return (slot->_object->*slot->_method) (arg1, arg2, arg3, (DATA *) data);
	}
public:
	// Constructor
	Slot3OD (OBJ& object, RET (OBJ::*method) (ARG1, ARG2, ARG3, DATA *), DATA *data) : Slot3<RET,ARG1,ARG2,ARG3>(duplicate, invoke, (void *) data), _method(method), _object(&object) {}
};
// Static callback
template <class RET, class ARG1, class ARG2, class ARG3>
inline Slot3S<RET, ARG1, ARG2, ARG3> STATIC_SLOT (RET (*method) (ARG1, ARG2, ARG3)) { return Slot3S<RET, ARG1, ARG2, ARG3>(method); }
// Static callback + data
template <class RET, class ARG1, class ARG2, class ARG3>
inline Slot3S<RET, ARG1, ARG2, ARG3> STATIC_SLOT (RET (*method) (ARG1, ARG2, ARG3), const void *data) { return Slot3S<RET, ARG1, ARG2, ARG3>(method, data); }
// Static callback_data + data
template <class RET, class ARG1, class ARG2, class ARG3, class DATA>
inline Slot3SD<RET, ARG1, ARG2, ARG3, DATA> STATIC_SLOT (RET (*method) (ARG1, ARG2, ARG3, DATA *), DATA *data) { return Slot3SD<RET, ARG1, ARG2, ARG3, DATA>(method, data); }
// Member callback
template <class RET, class ARG1, class ARG2, class ARG3, class OBJ, class OBJ2>
inline Slot3O<OBJ, RET, ARG1, ARG2, ARG3> MEMBER_SLOT (OBJ& object, RET (OBJ2::*method) (ARG1, ARG2, ARG3)) { return Slot3O<OBJ, RET, ARG1, ARG2, ARG3>(object, method); }
// Member callback + data
template <class RET, class ARG1, class ARG2, class ARG3, class OBJ, class OBJ2>
inline Slot3O<OBJ, RET, ARG1, ARG2, ARG3> MEMBER_SLOT (OBJ& object, RET (OBJ2::*method) (ARG1, ARG2, ARG3), const void *data) { return Slot3O<OBJ, RET, ARG1, ARG2, ARG3>(object, method, data); }
// Member callback_data + data
template <class RET, class ARG1, class ARG2, class ARG3, class DATA, class OBJ, class OBJ2>
inline Slot3OD<OBJ, RET, ARG1, ARG2, ARG3, DATA> MEMBER_SLOT (OBJ& object, RET (OBJ2::*method) (ARG1, ARG2, ARG3, DATA *), DATA *data) { return Slot3OD<OBJ, RET, ARG1, ARG2, ARG3, DATA>(object, method, data); }

// Slot4

// Extended slot, capable of calling static functions

template<typename RET, typename ARG1, typename ARG2, typename ARG3, typename ARG4>
class Slot4S : public Slot4<RET,ARG1,ARG2,ARG3,ARG4>
{
private:
	// Callback
	RET (*_method) (ARG1, ARG2, ARG3, ARG4);
	// Duplication
	static Slot *duplicate (const Slot& base) {
		return new Slot4S(*((const Slot4S *) &base));
	}
	// Invocation
	static RET invoke (Slot4<RET,ARG1,ARG2,ARG3,ARG4> *base, ARG1 arg1, ARG2 arg2, ARG3 arg3, ARG4 arg4, void *data) {
		Slot4S *slot = (Slot4S *) base;
		return slot->_method (arg1, arg2, arg3, arg4);
	}
	// Default copy constructor should work
public:
	// Constructor
	Slot4S (RET (*method) (ARG1, ARG2, ARG3, ARG4)) : Slot4<RET,ARG1,ARG2,ARG3,ARG4>(duplicate, invoke, 0), _method(method) {}
	Slot4S (RET (*method) (ARG1, ARG2, ARG3, ARG4), const void *data) : Slot4<RET,ARG1,ARG2,ARG3,ARG4>(duplicate, invoke, (void *) data), _method(method) {}
};

template<typename RET, typename ARG1, typename ARG2, typename ARG3, typename ARG4, typename DATA>
class Slot4SD : public Slot4<RET, ARG1, ARG2, ARG3, ARG4>
{
private:
	// Callback
	RET (*_method) (ARG1, ARG2, ARG3, ARG4, DATA *);
	// Duplication
	static Slot *duplicate (const Slot& base) {
		return new Slot4SD(*((const Slot4SD *) &base));
	}
	// Invocation
	static RET invoke (Slot4<RET,ARG1,ARG2,ARG3,ARG4> *base, ARG1 arg1, ARG2 arg2, ARG3 arg3, ARG4 arg4, void *data) {
		Slot4SD *slot = (Slot4SD *) base;
		return slot->_method (arg1, arg2, arg3, arg4, (DATA *) data);
	}
public:
	// Constructor
	Slot4SD (RET (*method) (ARG1, ARG2, ARG3, ARG4, DATA *), DATA *data) : Slot4<RET,ARG1,ARG2,ARG3,ARG4>(duplicate, invoke, (void *) data), _method(method) {}
};

// Extended slot, capable of calling object members

template<typename OBJ, typename RET, typename ARG1, typename ARG2, typename ARG3, typename ARG4>
class Slot4O : public Slot4<RET, ARG1, ARG2, ARG3, ARG4>
{
private:
	// Callback
	RET (OBJ::*_method) (ARG1, ARG2, ARG3, ARG4);
	OBJ *_object;
	// Duplication
	static Slot *duplicate (const Slot& base) {
		return new Slot4O(*((const Slot4O *) &base));
	}
	// Invocation
	static RET invoke (Slot4<RET,ARG1,ARG2,ARG3,ARG4> *base, ARG1 arg1, ARG2 arg2, ARG3 arg3, ARG4 arg4, void *data) {
		Slot4O *slot = (Slot4O *) base;
		return (slot->_object->*slot->_method) (arg1, arg2, arg3, arg4);
	}
public:
	// Constructor
	Slot4O (OBJ& object, RET (OBJ::*method) (ARG1, ARG2, ARG3, ARG4)) : Slot4<RET,ARG1,ARG2,ARG3,ARG4>(duplicate, invoke, 0), _method(method), _object(&object) {}
	Slot4O (OBJ& object, RET (OBJ::*method) (ARG1, ARG2, ARG3, ARG4), const void *data) : Slot4<RET,ARG1,ARG2,ARG3,ARG4>(duplicate, invoke, (void *) data), _method(method), _object(&object) {}
};

template<typename OBJ, typename RET, typename ARG1, typename ARG2, typename ARG3, typename ARG4, typename DATA>
class Slot4OD : public Slot4<RET, ARG1, ARG2, ARG3, ARG4>
{
private:
	// Callback
	RET (OBJ::*_method) (ARG1, ARG2, ARG3, ARG4, DATA *);
	OBJ *_object;
	// Duplication
	static Slot *duplicate (const Slot& base) {
		return new Slot4OD(*((const Slot4OD *) &base));
	}
	// Invocation
	static RET invoke (Slot4<RET,ARG1,ARG2,ARG3,ARG4> *base, ARG1 arg1, ARG2 arg2, ARG3 arg3, ARG4 arg4, void *data) {
		Slot4OD *slot = (Slot4OD *) base;
		return (slot->_object->*slot->_method) (arg1, arg2, arg3, arg4, (DATA *) data);
	}
public:
	// Constructor
	Slot4OD (OBJ& object, RET (OBJ::*method) (ARG1, ARG2, ARG3, ARG4, DATA *), DATA *data) : Slot4<RET,ARG1,ARG2,ARG3,ARG4>(duplicate, invoke, (void *) data), _method(method), _object(&object) {}
};
// Static callback
template <class RET, class ARG1, class ARG2, class ARG3, class ARG4>
inline Slot4S<RET, ARG1, ARG2, ARG3, ARG4> STATIC_SLOT (RET (*method) (ARG1, ARG2, ARG3, ARG4)) { return Slot4S<RET, ARG1, ARG2, ARG3, ARG4>(method); }
// Static callback + data
template <class RET, class ARG1, class ARG2, class ARG3, class ARG4>
inline Slot4S<RET, ARG1, ARG2, ARG3, ARG4> STATIC_SLOT (RET (*method) (ARG1, ARG2, ARG3, ARG4), const void *data) { return Slot4S<RET, ARG1, ARG2, ARG3, ARG4>(method, data); }
// Static callback_data + data
template <class RET, class ARG1, class ARG2, class ARG3, class ARG4, class DATA>
inline Slot4SD<RET, ARG1, ARG2, ARG3, ARG4, DATA> STATIC_SLOT (RET (*method) (ARG1, ARG2, ARG3, ARG4, DATA *), DATA *data) { return Slot4SD<RET, ARG1, ARG2, ARG3, ARG4, DATA>(method, data); }
// Member callback
template <class RET, class ARG1, class ARG2, class ARG3, class ARG4, class OBJ, class OBJ2>
inline Slot4O<OBJ, RET, ARG1, ARG2, ARG3, ARG4> MEMBER_SLOT (OBJ& object, RET (OBJ2::*method) (ARG1, ARG2, ARG3, ARG4)) { return Slot4O<OBJ, RET, ARG1, ARG2, ARG3, ARG4>(object, method); }
// Member callback + data
template <class RET, class ARG1, class ARG2, class ARG3, class ARG4, class OBJ, class OBJ2>
inline Slot4O<OBJ, RET, ARG1, ARG2, ARG3, ARG4> MEMBER_SLOT (OBJ& object, RET (OBJ2::*method) (ARG1, ARG2, ARG3, ARG4), const void *data) { return Slot4O<OBJ, RET, ARG1, ARG2, ARG3, ARG4>(object, method, data); }
// Member callback_data + data
template <class RET, class ARG1, class ARG2, class ARG3, class ARG4, class DATA, class OBJ, class OBJ2>
inline Slot4OD<OBJ, RET, ARG1, ARG2, ARG3, ARG4, DATA> MEMBER_SLOT (OBJ& object, RET (OBJ2::*method) (ARG1, ARG2, ARG3, ARG4, DATA *), DATA *data) { return Slot4OD<OBJ, RET, ARG1, ARG2, ARG3, ARG4, DATA>(object, method, data); }

} // Namespace Signals

} // Namespace Miletos

#endif
