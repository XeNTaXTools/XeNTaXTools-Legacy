#define __MILETOS_BLOCK_WORLD_CPP__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2007
//

static const int debug = 1;

#include <malloc.h>
#include <stdlib.h>

#include <elea/cuboid.h>
#include <elea/line.h>
#include <elea/color.h>

#include <sehle/engine.h>
#include <sehle/graph.h>
#include <sehle/renderable.h>
#include <sehle/commonmaterials.h>

#include "uri.h"
#include "material.h"

#include "blockworld.h"

namespace Miletos {

// BlockWorld

BlockWorld::BlockWorld (void)
: Item(0), xsize(10), ysize(10), zsize(10), sidelenght(1), blocks(NULL)
{
	for (int i = 0; i < NUM_MATERIALS; i++) {
		materialids[i] = NULL;
		materials[i] = NULL;
	}
}

BlockWorld::~BlockWorld (void)
{
	if (blocks) free (blocks);
}

static Object *
blockworld_factory (void)
{
	return new BlockWorld();
}

const Object::Type *
BlockWorld::objectType (void)
{
	return type ();
}

const Object::Type *
BlockWorld::type (void)
{
	static Type *mytype = NULL;
	static const Attribute attrs[] = {
		{ "source", NULL, 0 },
		{ "topMaterial", NULL, 0 },
		{ "sideMaterial", NULL, 0 }
	};
	if (!mytype) mytype = new Type(Item::type (), "BlockWorld", "blockWorld", blockworld_factory, sizeof (attrs) / sizeof (attrs[0]), attrs);
	return mytype;
}

void
BlockWorld::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	Item::build (pnode, doc, ctx);

	buildAllAttributes (type (), ctx);

}

void
BlockWorld::release (void)
{
	clear ();

	for (int i = 0; i < NUM_MATERIALS; i++) {
		if (materialids[i]) {
			free (materialids[i]);
			materialids[i] = NULL;
		}
		if (materials[i]) {
			materials[i]->detach (this);
			materials[i] = NULL;
		}
	}

	Item::release ();
}

void
BlockWorld::set (const char *attrid, const char *val)
{
	if (!strcmp (attrid, "source")) {
		readMap (val);
		requestUpdate (MODIFIED | MESH_DEFINITION_MODIFIED);
	} else if (!strcmp (attrid, "topMaterial")) {
		if (materials[TOP]) {
			materials[TOP]->detach (this);
			materials[TOP] = NULL;
		}
		if (materialids[TOP]) {
			free (materialids[TOP]);
			materialids[TOP] = NULL;
		}
		if (val && (val[0] == '#') && val[1]) {
			materialids[TOP] = strdup (val + 1);
			document->addIdentityChangeListener (materialids[TOP], this);
			Object *object = document->lookupObject (materialids[TOP]);
			if (object && object->isType (Material::type ())) {
				materials[TOP] = (Material *) object;
				materials[TOP]->attach (this);
			}
		}
		requestUpdate (MODIFIED | MESH_DEFINITION_MODIFIED);
	} else if (!strcmp (attrid, "sideMaterial")) {
		if (materials[SIDE]) {
			materials[SIDE]->detach (this);
			materials[SIDE] = NULL;
		}
		if (materialids[SIDE]) {
			free (materialids[SIDE]);
			materialids[SIDE] = NULL;
		}
		if (val && (val[0] == '#') && val[1]) {
			materialids[SIDE] = strdup (val + 1);
			document->addIdentityChangeListener (materialids[SIDE], this);
			Object *object = document->lookupObject (materialids[SIDE]);
			if (object && object->isType (Material::type ())) {
				materials[SIDE] = (Material *) object;
				materials[SIDE]->attach (this);
			}
		}
		requestUpdate (MODIFIED | MESH_DEFINITION_MODIFIED);
	} else {
		Item::set (attrid, val);
	}
}

void
BlockWorld::identityAdded (Document *pdocument, const char *pidentity, Object *pobject)
{
	assert (!strcmp (pidentity, materialids[TOP]) || !strcmp (pidentity, materialids[SIDE]));

	if (!strcmp (pidentity, materialids[TOP])) {
		if (materials[TOP]) {
			materials[TOP]->detach (this);
			materials[TOP] = NULL;
		}
		if (pobject->isType (Material::type ())) {
			materials[TOP] = (Material *) pobject;
			materials[TOP]->attach (this);
		}
	} else {
		if (materials[SIDE]) {
			materials[SIDE]->detach (this);
			materials[SIDE] = NULL;
		}
		if (pobject->isType (Material::type ())) {
			materials[SIDE] = (Material *) pobject;
			materials[SIDE]->attach (this);
		}
	}

	requestModified (MODIFIED);
}

void
BlockWorld::identityRemoved (Document *pdocument, const char *pidentity)
{
	assert (!strcmp (pidentity, materialids[TOP]) || !strcmp (pidentity, materialids[SIDE]));

	if (!strcmp (pidentity, materialids[TOP])) {
		if (materials[TOP]) {
			materials[TOP]->detach (this);
			materials[TOP] = NULL;
		}
	} else {
		if (materials[SIDE]) {
			materials[SIDE]->detach (this);
			materials[SIDE] = NULL;
		}
	}

	requestModified (MODIFIED);
}

void
BlockWorld::attachedObjectRelease (Object *attached, void *data)
{
	assert ((attached == materials[TOP]) || (attached == materials[SIDE]));

	if ((attached == materials[TOP])) {
		materials[TOP]->detach (this);
		materials[TOP] = NULL;
	} else {
		materials[SIDE]->detach (this);
		materials[SIDE] = NULL;
	}

	requestUpdate (MODIFIED);
}

void
BlockWorld::attachedObjectModified (Object *attached, unsigned int flags, void *data)
{
}

void
BlockWorld::update (UpdateCtx *ctx, unsigned int flags)
{
	bbox = ctx->i2w.transform (Elea::Cuboid3f(0, 0, 0, xsize * sidelenght, ysize * sidelenght, zsize * sidelenght));

	if (flags & MESH_DEFINITION_MODIFIED) {
		if (renderable) buildMesh ((Sehle::StaticMesh *) renderable);
	}

	Item::update (ctx, flags);
}

Sehle::Renderable *
BlockWorld::show (Sehle::Graph *graph, Sehle::u32 contextmask)
{
	Sehle::StaticMesh *mesh = new Sehle::StaticMesh(graph, contextmask);

	buildMesh (mesh);

	return mesh;
}

static bool
trace_div (int x0, int x1, int y0, int y1, int z0, int z1, int xsize, int ysize, int zsize, const int *blocks, float sidelen, const Elea::Line3f& ray, float& distance)
{
	Elea::Cuboid3f c(sidelen * x0, sidelen * y0, sidelen * z0, sidelen * x1, sidelen * y1, sidelen * z1);
	float p0, p1;
	if (!c.getIntersection (ray, p0, p1)) return false;
	if (((x1 - x0) == 1) && ((y1 - y0) == 1) && ((z1 - z0) == 1)) {
		if (!blocks[z0 * xsize * ysize + y0 * xsize + x0]) return false;
		if (p0 < 0) return false;
		if (p0 < distance) distance = p0;
		return true;
	}
	int xmid = (x1 + x0) / 2;
	int ymid = (y1 + y0) / 2;
	int zmid = (z1 + z0) / 2;
	bool intersect = false;
	if (xmid > x0) {
		if (ymid > y0) {
			if (zmid > z0) intersect |= trace_div (x0, xmid, y0, ymid, z0, zmid, xsize, ysize, zsize, blocks, sidelen, ray, distance);
			if (z1 > zmid) intersect |= trace_div (x0, xmid, y0, ymid, zmid, z1, xsize, ysize, zsize, blocks, sidelen, ray, distance);
		}
		if (y1 > ymid) {
			if (zmid > z0) intersect |= trace_div (x0, xmid, ymid, y1, z0, zmid, xsize, ysize, zsize, blocks, sidelen, ray, distance);
			if (z1 > zmid) intersect |= trace_div (x0, xmid, ymid, y1, zmid, z1, xsize, ysize, zsize, blocks, sidelen, ray, distance);
		}
	}
	if (x1 > xmid) {
		if (ymid > y0) {
			if (zmid > z0) intersect |= trace_div (xmid, x1, y0, ymid, z0, zmid, xsize, ysize, zsize, blocks, sidelen, ray, distance);
			if (z1 > zmid) intersect |= trace_div (xmid, x1, y0, ymid, zmid, z1, xsize, ysize, zsize, blocks, sidelen, ray, distance);
		}
		if (y1 > ymid) {
			if (zmid > z0) intersect |= trace_div (xmid, x1, ymid, y1, z0, zmid, xsize, ysize, zsize, blocks, sidelen, ray, distance);
			if (z1 > zmid) intersect |= trace_div (xmid, x1, ymid, y1, zmid, z1, xsize, ysize, zsize, blocks, sidelen, ray, distance);
		}
	}
	return intersect;
}

Item *
BlockWorld::trace (const Elea::Line3f *wray, unsigned int mask, float *distance)
{
	if (!blocks) return NULL;
	Elea::Line3f lray = _w2i.transform (*wray);
	float ldistance = Elea::OMEGA_F;
	if (!trace_div (0, xsize, 0, ysize, 0, zsize, xsize, ysize, zsize, blocks, sidelenght, lray, ldistance)) return NULL;
	if (*distance) *distance = ldistance;
	return this;
}

void
BlockWorld::clear ()
{
}

void
BlockWorld::readMap (const char *uri)
{
	URI::Location loc(uri, "file");
	URI::URLHandler *handler = URI::getHandler (loc.path);
	if (handler) {
		size_t csize;
		const unsigned char *cdata = handler->mmapData (loc.path, &csize);
		if (cdata) {
			if (blocks) free (blocks);
			blocks = NULL;
			size_t cpos = 64;
			xsize = cdata[cpos] | cdata[cpos + 1] << 8 | cdata[cpos + 2] << 16 | cdata[cpos + 3] << 24;
			cpos += 4;
			ysize = cdata[cpos] | cdata[cpos + 1] << 8 | cdata[cpos + 2] << 16 | cdata[cpos + 3] << 24;
			cpos += 4;
			zsize = 9;
			blocks = (int *) malloc (xsize * ysize * zsize * sizeof (int));
			memset (blocks, 0, xsize * ysize * zsize * sizeof (int));
			for (int y = 0; y < ysize; y++) {
				for (int x = 0; x < xsize; x++) {
					blocks[0 * (ysize * xsize) + y * xsize + x] = 1;
					for (int z = 0; z < 8; z++) {
						unsigned char v = cdata[cpos + y * xsize * 8 + x * 8 + z];
						if (v > 0) blocks[(z + 1) * (ysize * xsize) + y * xsize + x] = 1;
					}
				}
			}
			handler->munmapData (cdata);
		}
		handler->unRef ();
	}
}

void
BlockWorld::buildWorld (void)
{
	if (blocks) free (blocks);
	blocks = (int *) malloc (xsize * ysize * zsize * sizeof (int));

	// fixme: Move to parameters (Lauris)
	unsigned int seed = 0;
	srand (seed);
	for (int y = 0; y < ysize; y++) {
		for (int x = 0; x < xsize; x++) {
			// double val = PerlinNoise2D ((double) x / _width, (double) y / height, 2, 2.0, 8);
			// val = val * _maxheight;
			// if (val < 0) val = 0;
			for (int z = 0; z < zsize; z++) {
				int val = rand () % 5;
				blocks[z * (ysize * xsize) + y * xsize + x] = (val == 1);
			}
		}
	}
}

static int
get_block (int x, int y, int z, int xsize, int ysize, int zsize, const int *blocks)
{
	if (!blocks) return 0;
	if ((x < 0) || (x >= xsize)) return 0;
	if ((y < 0) || (y >= ysize)) return 0;
	if ((z < 0) || (z >= zsize)) return 0;
	return blocks[z * (ysize * xsize) + y * xsize + x];
}

static void
build_side (const Elea::Vector3f& p, const Elea::Vector3f& dx, const Elea::Vector3f& dy, Sehle::VertexBuffer *vb, u32 *vidx, Sehle::IndexBuffer *ib, u32 *iidx)
{
	static const f32 cv[] = {0, 0, 1, 0, 1, 1, 0, 1 };
	Elea::Vector3f normal = dx * dy;
	normal.normalizeSelf ();
	Elea::Vector3f tangent = dx.normalize ();
	if (vidx && vb) {
		for (int i = 0; i < 4; i++) {
			Elea::Vector3f vertex(p + cv[2 * i] * dx + cv[2 * i + 1] * dy);
			vb->setValues (*vidx + i, vb->offset[Sehle::VertexBuffer::COORDINATES], vertex, 3);
			vb->setValues (*vidx + i, vb->offset[Sehle::VertexBuffer::NORMALS], normal, 3);
			vb->setValues (*vidx + i, vb->offset[Sehle::VertexBuffer::TANGENTS], tangent, 3);
			vb->setValues (*vidx + i, vb->offset[Sehle::VertexBuffer::TEXCOORDS], Elea::Vector2f(cv[2 * i], cv[2 * i + 1]), 2);
		}
	}
	static const int cc[] = { 0, 1, 2, 0, 2, 3 };
	if (iidx && ib && vidx) {
		for (int i = 0; i < 6; i++) {
			ib->indices[*iidx + i] = *vidx + cc[i];
		}
	}
	if (vidx) *vidx += 4;
	if (iidx) *iidx += 6;
}

static void
build_sides (int xsize, int ysize, int zsize, const int *blocks, float sidelen, Sehle::VertexBuffer *vb, u32 *vidx, Sehle::IndexBuffer *ib, u32 *iidx)
{
	for (int z = 0; z < zsize; z++) {
		for (int y = 0; y < ysize; y++) {
			for (int x = 0; x < xsize; x++) {
				if (!get_block (x, y, z, xsize, ysize, zsize, blocks)) continue;
				for (int i = 0; i < 4; i++) {
					static const int cq[] = { 0, -1, 1, 0, 0, 1, -1, 0 };
					if (get_block (x + cq[2 * i], y + cq[2 * i + 1], z, xsize, ysize, zsize, blocks)) continue;
					static const float cp[] = { 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0 };
					static const float cd[] = { 1, 0, 0, 0, 1, 0, -1, 0, 0, 0, -1, 0 };
					Elea::Vector3f p(sidelen * x, sidelen * y, sidelen * z);
					build_side (p + sidelen * Elea::Vector3f(&cp[3 * i]), sidelen * Elea::Vector3f(&cd[3 * i]), sidelen * Elea::Vector3fZ, vb, vidx, ib, iidx); 
				}
			}
		}
	}
}

static void
build_tops (int xsize, int ysize, int zsize, const int *blocks, float sidelen, Sehle::VertexBuffer *vb, u32 *vidx, Sehle::IndexBuffer *ib, u32 *iidx)
{
	for (int z = 0; z < zsize; z++) {
		for (int y = 0; y < ysize; y++) {
			for (int x = 0; x < xsize; x++) {
				if (!get_block (x, y, z, xsize, ysize, zsize, blocks)) continue;
				if (get_block (x, y, z + 1, xsize, ysize, zsize, blocks)) continue;
				Elea::Vector3f p(sidelen * x, sidelen * y, sidelen * (z + 1));
				build_side (p, sidelen * Elea::Vector3fX, sidelen * Elea::Vector3fY, vb, vidx, ib, iidx); 
			}
		}
	}
}

static void
build_bottoms (int xsize, int ysize, int zsize, const int *blocks, float sidelen, Sehle::VertexBuffer *vb, u32 *vidx, Sehle::IndexBuffer *ib, u32 *iidx)
{
	for (int z = 0; z < zsize; z++) {
		for (int y = 0; y < ysize; y++) {
			for (int x = 0; x < xsize; x++) {
				if (!get_block (x, y, z, xsize, ysize, zsize, blocks)) continue;
				if (get_block (x, y, z - 1, xsize, ysize, zsize, blocks)) continue;
				Elea::Vector3f p(sidelen * (x + 1), sidelen * y, sidelen * z);
				build_side (p, -sidelen * Elea::Vector3fX, sidelen * Elea::Vector3fY, vb, vidx, ib, iidx); 
			}
		}
	}
}

void
BlockWorld::buildMesh (Sehle::StaticMesh *mesh)
{
	u32 vidx = 0;
	u32 iidx = 0;
	build_sides (xsize, ysize, zsize, blocks, sidelenght, NULL, &vidx, NULL, &iidx);
	build_tops (xsize, ysize, zsize, blocks, sidelenght, NULL, &vidx, NULL, &iidx);
	build_bottoms (xsize, ysize, zsize, blocks, sidelenght, NULL, &vidx, NULL, &iidx);
	if (!mesh->vbuffer) mesh->vbuffer = mesh->graph->engine->getVertexBuffer (NULL);
	mesh->vbuffer->setUp (vidx, 11);
	mesh->vbuffer->setOffset (Sehle::VertexBuffer::COORDINATES, 0);
	mesh->vbuffer->setOffset (Sehle::VertexBuffer::NORMALS, 3);
	mesh->vbuffer->setOffset (Sehle::VertexBuffer::TANGENTS, 6);
	mesh->vbuffer->setOffset (Sehle::VertexBuffer::TEXCOORDS, 9);
	if (!mesh->ibuffer) mesh->ibuffer = mesh->graph->engine->getIndexBuffer (NULL);
	mesh->ibuffer->resize (iidx);

	mesh->resizeMaterials (2);
	if (materials[SIDE]) {
		mesh->setMaterial (0, materials[SIDE]->getSehleMaterial (mesh->graph->engine));
	} else {
		Sehle::ColorMaterial *cmat = Sehle::ColorMaterial::newColorMaterial (mesh->graph->engine, "blockWorld::Side");
		cmat->setColor (Elea::Color4f(0xbfbfbfff));
		mesh->setMaterial (0, cmat);
	}
	if (materials[TOP]) {
		mesh->setMaterial (1, materials[TOP]->getSehleMaterial (mesh->graph->engine));
	} else {
		Sehle::ColorMaterial *cmat = Sehle::ColorMaterial::newColorMaterial (mesh->graph->engine, "blockWorld::Top");
		cmat->setColor (Elea::Color4f(0xff7f7fff));
		mesh->setMaterial (1, cmat);
	}

	mesh->vbuffer->map (Sehle::VertexBuffer::WRITE);
	mesh->ibuffer->map (Sehle::IndexBuffer::WRITE);

	vidx = 0;
	iidx = 0;
	mesh->resizeFragments (2);
	mesh->frags[0].matidx = 0;
	mesh->frags[0].first = 0;
	build_sides (xsize, ysize, zsize, blocks, sidelenght, mesh->vbuffer, &vidx, mesh->ibuffer, &iidx);
	build_bottoms (xsize, ysize, zsize, blocks, sidelenght, mesh->vbuffer, &vidx, mesh->ibuffer, &iidx);
	mesh->frags[0].nindices = iidx;

	mesh->frags[1].matidx = 1;
	mesh->frags[1].first = iidx;
	build_tops (xsize, ysize, zsize, blocks, sidelenght, mesh->vbuffer, &vidx, mesh->ibuffer, &iidx);
	mesh->frags[1].nindices = iidx - mesh->frags[1].first;

	mesh->vbuffer->unMap ();
	mesh->ibuffer->unMap ();
}

} // Namespace Miletos
