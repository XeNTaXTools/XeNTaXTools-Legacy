#ifndef __MILETOS_ANIMATION_H__
#define __MILETOS_ANIMATION_H__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2009
//

#include <vector>

#include <miletos/miletos.h>

namespace Miletos {

class Figure;
class SkinnedGeometry;
class Skeleton;

namespace Animation {

class Sequence;

//
// Abstract base class for animation sources
//
// All animation times are specified in frametimes
// time = frametime * fps
// This is good to avoid rounding errors, as frametimes should usually be integers
//

class Source : public Object {
public:
	enum RepeatType { CLAMP, REPEAT, MIRROR, NUM_REPEAT_TYPES };
private:
	// Object implementation
	virtual const Type *objectType (void);

protected:
	// Object implementation
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void set (const char *attrid, const char *val);
	virtual void write (const char *attrid);

public:
	char *sid;

	float fps;
	float minframetime;
	float maxframetime;

	Source (u32 flags);
	virtual ~Source (void);

	// Type system
	static const Type *type (void);

	// Find normalized frametime
	static float normalize (float frametime, float minframetime, float maxframetime, unsigned int repeattype);
};

//
// Boneanimation
//
// Defines set of bone local transformations in time
// Bone is referenced by SID that has to be resolved during binding
//

class BoneAnimation : public Source {
private:
	// const Orientation *orientations;

	// Object implementation
	virtual const Type *objectType (void);

protected:
	// Object implementation
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void set (const char *attrid, const char *val);

	// Release and clear all dependent data
	void clear (void);

public:
	unsigned int enabled : 1;

	// SID of modified bone
	char *bonesid;

	unsigned int nframes;
	const float *frametimes;

	BoneAnimation (u32 flags);
	virtual ~BoneAnimation (void);

	// Type system
	static const Type *type (void);

	// Find interpolation for given frame
	bool interpolate (f32 frametime, u32& f0, u32& f1, f32& s, u32 repeattype);
	// Get animated position
	virtual Elea::Vector3f getPosition (unsigned int frameidx) = 0;
	virtual Elea::Quaternionf getQuaternion (unsigned int frameidx) = 0;
	// Get interpolated position
	Elea::Matrix3x4f getAB2P (float frametime, unsigned int type);
};

class KeyFrameAnimation : public Source {
private:
	// Object implementation
	virtual const Type *objectType (void);

protected:
	// Object implementation
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void set (const char *attrid, const char *val);

	// Release and clear all dependent data
	void clear (void);

public:
	unsigned int enabled : 1;

	char *geometrysid;

	const u32 *indices;
	u32 numindices;
	u32 minindex;
	u32 maxindex;

	u32 nframes;

	const f32 *frametimes;
	const Elea::Vector3f *vdata;
	const Elea::Vector3f *ndata;
	const Elea::Vector3f *tdata;

	// Constructor
	KeyFrameAnimation (u32 flags);
	// Destructor
	virtual ~KeyFrameAnimation (void);

	// Type system
	static const Type *type (void);

	// Find interpolation for given frame
	bool interpolate (f32 frametime, u32& f0, u32& f1, f32& s, u32 repeattype);
};

//
// SkinAnimation
//
// Skinanimation is single linear-time animation sequence
// It is collection of both bone and skin animations in common time interval
// Keyframes is the union of all bone and skin animation keyframes
// It can contain subsequences that define certain time interval
//

class SkinAnimation : public Source {
private:
	// Object implementation
	virtual const Type *objectType (void);

	// Helpers
	void updateChildData (Thera::Node *removed);
	//
	// Calculate postions of bones at specific animation time
	//
	// input:
	// anim2skel is the maping from animation bone indices to skeleton bone indices
	// parents is an array of bone parent indices in skeleton
	// orientations ais an array of unanimated bone orientations in skeleton
	// lengths is an array of bone lengths for endpoint calculation
	// output:
	// b2s is an array of bone->skeleton matrixes at given time
	// endpos is an array of bone endpoint positions at given time
	// 
	void calculateBonePositions (Elea::Matrix4x4f b2s[], Elea::Vector3f endpos[], float time, const int anim2skel[], u32 nbones, const int parents[], const Orientation orientations[], const float lengths[]);
	void calculateIdentities (const int anim2skel[], u32 nbones, const int parents[], const Orientation orientations[], const float lengths[], float maxdelta);
	void setIdentity (int keyframe0, int keyframe1);
protected:
	// Object implementation
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	virtual Object *childAdded (Thera::Node *cnode, Thera::Node *rnode);
	virtual void childRemoved (Thera::Node *cnode, Thera::Node *rnode);
	virtual void set (const char *attrid, const char *val);
	virtual void write (const char *attrid);
	virtual void update (UpdateCtx *ctx, unsigned int flags);

public:
	unsigned int enabled : 1;

	u32 nboneanimations;
	BoneAnimation **boneanimations;
	u32 nkeyframeanimations;
	KeyFrameAnimation **keyframeanimations;
	u32 nsequences;
	Sequence **sequences;

	float currentframetime;

	int currentseq;

	// List of keyframes
	u32 nkeyframes;
	float *keyframes;

	// Identities between keyframes
	u32 *identities;

	SkinAnimation (void);
	virtual ~SkinAnimation (void);

	// Type system
	static const Type *type (void);

	// Access
	void setCurentFrameTime (float ptime);

	// Helpers
	// Recalculate limits
	void calculateLimits (void);
	// Recalculate keyframe list
	void calculateKeyFrames (void);
	void calculateIdentities (Skeleton *skeleton, float pmaxdelta);
	// Return true if keyframes are identical
	unsigned int areIdentical (int frame0, int frame1);
};

//
// AnimationSequence
//
// This is clipped interval from some other animation
// It can be applied to animatable objects
//

class Sequence : public Source {
private:
	char *targetid;
	char *sourceid;
	// Object implementation
	virtual const Type *objectType (void);

protected:
	// Object implementation
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	virtual void set (const char *attrid, const char *val);
	virtual void update (UpdateCtx *ctx, unsigned int flags);
	virtual void identityAdded (Document *pdocument, const char *pidentity, Object *pobject);
	virtual void identityRemoved (Document *pdocument, const char *pidentity);
	virtual void attachedObjectRelease (Object *attached, void *data);
	virtual void attachedObjectModified (Object *attached, unsigned int flags, void *data);

public:
	RepeatType repeattype;
	float speed;
	Figure *target;
	Source *source;


	Sequence (void);

	// Type system
	static const Type *type (void);
	// Helper
	void applyAnimation (float frametime);
};

} // Namespace Animation

} // Namespace Miletos

#endif

