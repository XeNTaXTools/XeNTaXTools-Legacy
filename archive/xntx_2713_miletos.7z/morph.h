#ifndef __MILETOS_MORPH_H__
#define __MILETOS_MORPH_H__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2009
//

#include <vector>

#include <miletos/types.h>
#include <miletos/scene.h>

namespace Miletos {

class MorphTarget : public Object {
private:
	// Object implementation
	virtual const Type *objectType (void);

protected:
	// Object implementation
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void set (const char *attrid, const char *val);

	// Release and clear all dependent data
	void clear (void);

public:
	char *sid;

	const Elea::Vector3f *vdata;
	const Elea::Vector3f *ndata;
	const Elea::Vector3f *tdata;
	const u32 *indices;
	u32 numindices;
	u32 maxindex;

	// Constructor
	MorphTarget (u32 flags);
	// Destructor
	virtual ~MorphTarget (void);

	// Type system
	static const Type *type (void);
};

class Morph : public Object {
private:
	// Object implementation
	virtual const Type *objectType (void);

	// Helper
	void updateChildData (Thera::Node *removed);
protected:
	// Object implementation
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	virtual Object *childAdded (Thera::Node *cnode, Thera::Node *rnode);
	virtual void childRemoved (Thera::Node *cnode, Thera::Node *rnode);
	virtual void set (const char *attrid, const char *val);
	virtual void update (UpdateCtx *ctx, unsigned int flags);

public:
	char *sid;

	unsigned int enabled : 1;

	std::vector<MorphTarget *> targets;

	int tgt0;
	int tgt1;
	float s;

	// Constructor
	Morph (void);
	// Destructor
	virtual ~Morph (void);

	// Type system
	static const Type *type (void);

	// Access
	MorphTarget *getTarget0 (void) { return ((tgt0 >= 0) && (tgt0 < (int) targets.size ())) ? targets[tgt0] : NULL; }
	MorphTarget *getTarget1 (void) { return ((tgt1 >= 0) && (tgt1 < (int) targets.size ())) ? targets[tgt1] : NULL; }
};

} // Namespace Miletos

#endif

