#ifndef __MILETOS_BONE_H__
#define __MILETOS_BONE_H__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2008
//

#include <elea/quaternion.h>

#include <miletos/pmesh.h>

namespace Miletos {

class Skeleton;
class Figure;

//
// Bone controller for skeletal meshes
//
// Attributes:
// sid - The SID of bone (for animators etc.) - should be unique in skeleton hierarchy
// orientation - The default transformation from controller coordinate system to parent
// animatedOrientation - The current orientation of controller coordinate system
// vOrientation - The transformation from bone visualization to orientation (bone is rendered along Z axis)
// vLength - The length (local Z coordinate of end) of rendered bone (default 10 cm)
// mirror - The SID of mirrored bone if present (L <-> R)
// visible - Whether bone is visible in skeleton mode (default true)
//
// Bone can be attached to skeleton via skeletalbone interface
// If so, they register themselves in skeleton and obtain unique and sequential index
// Index will be used to signal skeleton about animation changes
// Skeleton will also be notified, if any child is added or removed or bone released
//

class Bone : public Object {
public:
	// Default is { true -PI/2 PI/2 1 1 }
	struct Tension {
		unsigned int enabled;
		float threshold[2];
		float rigidity[2];
	};
private:
	// Object implementation
	virtual const Type *objectType (void);
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	// The following two update child pointers and emit signals
	virtual Object *childAdded (Thera::Node *cnode, Thera::Node *rnode);
	virtual void childRemoved (Thera::Node *cnode, Thera::Node *rnode);
	virtual void set (const char *attrid, const char *val);
	virtual void write (const char *attrid);
	virtual void update (UpdateCtx *ctx, unsigned int flags);

	// Helper
	void updateChildData (Thera::Node *removed);
	static void setTension (Tension *tension, const char *val);
public:
	char *sid;
	char *mirror;

	// Flags
	unsigned int b2p_set : 1;
	unsigned int ab2p_set : 1;

	// Bone orientation in parent space
	Elea::Matrix3x4f b2p;
	// Animated bone orientation in parent space
	Elea::Matrix3x4f ab2p;
	// Transformation from object to default bone space
	Elea::Matrix3x4f o2b;
	// Transformation from animated bone to object space
	Elea::Matrix3x4f ab2o;
	// Default bounding box in object space
	Elea::Cuboid3f bbox;
	// Animated bounding box in object space
	Elea::Cuboid3f animbbox;

	const int *axisorder;
	Tension tension[3];

	// Visual data
	// Orientation relative to bone local coordinate system
	Orientation vOrientation;
	float vLength;
	bool visible;

	// Child bones
	int nchildbones;
	Bone **childbones;

	Bone (void);
	virtual ~Bone (void);

	// Type system
	static const Type *type (void);

	// Helpers
	void setAB2P (const Elea::Matrix3x4f& ab2p);
	Elea::Matrix3x4f getAB2O (void);
	void setAB2O (const Elea::Matrix3x4f& ab2o);
	Elea::Matrix3x4f getAB2W (const Elea::Matrix3x4f& o2w);
	void setAB2W (const Elea::Matrix3x4f& ab2w, const Elea::Matrix3x4f& o2w);

	//
	// Skeletalbone interface
	//
	Skeleton *skeleton;
	int index;
	// Will be called recursively if skeleton want to do (re)indexing
	void attachToSkeleton (Skeleton *skeleton);
	// Clears skeleton link and index recursively
	void detachFromSkeleton (Skeleton *skeleton);
	// To be called during skeleton update
	// Update o2b
	void UpdatePositionMatrixes (const Elea::Matrix3x4f& o2p);
	// Update ab2o
	void UpdateAnimationMatrixes (const Elea::Matrix3x4f& ap2o);

	// Helpers
	static float calculateTension (const Tension *tension, float angle);
	static float calculateDTension (const Tension *tension, float angle);
};

} // Namespace Miletos

#endif

