#ifndef __MILETOS_SCENE_H__
#define __MILETOS_SCENE_H__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2007
//

#include <sehle/sehle.h>

#include <miletos/types.h>
#include <miletos/miletos.h>

#ifdef WIN32
#undef OPAQUE
#undef TRANSPARENT
#endif

namespace Miletos {

class Camera;

class Unknown : public Object {
private:
	// Object implementation
	virtual const Type *objectType (void);
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	virtual void set (const char *attrid, const char *val);
	virtual unsigned int addChild (Thera::Node *cnode, Thera::Node *rnode);
public:
	// Constructor
	Unknown (void) : Object(0) {}
	// Type system
	static const Type *type (void);
};

class Text : public Object {
private:
	// Object implementation
	virtual const Type *objectType (void);
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	virtual unsigned int changeAttr (const char *attrid, const char *val) { return 0; }
	virtual void set (const char *attrid, const char *val) {}
	virtual unsigned int changeContent (const char *val) { return 1; }
public:
	// Constructor
	Text (void) : Object(0) {}
	// Type system
	static const Type *type (void);
};

class Defs : public Object {
private:
	// Object implementation
	virtual const Type *objectType (void);
public:
	Defs (void) : Object(HAS_CHILDREN) {}

	// Type system
	static const Type *type (void);
};

// Visibility masks
//
// 1 - opaque geometry
// 2 - transparent geometry
// 4 - shadow maps
// 8 - density maps
//

class Item : public Object {
public:
	// Sehle context flags
	static const unsigned int OPAQUE = 1;
	static const unsigned int TRANSPARENT = 2;
	static const unsigned int SHADOW = 4;
	static const unsigned int DENSITY = 8;
private:
	// Object implementation
	virtual const Type *objectType (void);
	// Rendering system
	virtual Sehle::Renderable *show (Sehle::Graph *graph, Sehle::u32 contextmask) = 0;
	virtual Item *trace (const Elea::Line3f *wray, unsigned int mask, float *distance) = 0;
protected:
	Elea::Matrix4x4f _i2p;
	Elea::Matrix4x4f _i2w;
	Elea::Matrix4x4f _w2i;
	Sehle::Graph *graph;
	Sehle::Renderable *renderable;
	// Object implementation
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	virtual void set (const char *attrid, const char *val);
	virtual void write (const char *attrid);
	virtual void update (UpdateCtx *ctx, unsigned int flags);
	// Release references to sehle engine
	virtual void hide (Sehle::RenderableGroup *pgroup) {}
	// Sphere tracing
	virtual Item *trace (const Elea::Line3f *wray, unsigned int mask, const Elea::Matrix4x4f *e2us, float *distance, Elea::Vector3f *uscp) { return NULL; }
	// Constructor
	Item (unsigned int flags) : Object(flags), graph(NULL), renderable(NULL), visibility(0xffffffff), tracemask(0xffffffff), bbox(Elea::Cuboid3fEmpty)  {}
public:
	u32 visibility;
	u32 tracemask;
	Elea::Cuboid3f bbox;
	// Access
	const Elea::Cuboid3f& getBBox (void) { return bbox; }
	const Elea::Matrix4x4f& getI2P (void) const { return _i2p; }
	void setI2P (const Elea::Matrix4x4f *pi2p);
	Elea::Matrix4x4f getI2W (void) const;
	void setI2W (const Elea::Matrix4x4f *pi2w);
	const Elea::Matrix4x4f& getW2I (void) const { return _w2i; }
	// Get child to parent transform for given child
	virtual void getC2P (Elea::Matrix4x4f *c2p, Miletos::Item *child);
	// Render system management
	Sehle::Renderable *invokeShow (Sehle::Graph *graph, Sehle::u32 contextmask);
	void invokeHide (Sehle::RenderableGroup *pgroup);
	// Trace returns if there will be hit along ray between 0-infinity
	Item *invokeTrace (const Elea::Line3f *wray, unsigned int mask, float *distance);
	// e2us - transformation from world-space ellipsoid to unit sphere (no translation)
	// uscp - collision point in unit sphere coordinates
	Item *invokeTrace (const Elea::Line3f *wray, unsigned int mask, const Elea::Matrix4x4f *e2us, float *distance, Elea::Vector3f *uscp);
	// Type system
	static const Type *type (void);
};

class Group : public Item {
private:
protected:
	// Object implementation
	virtual const Type *objectType (void);
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	virtual void set (const char *attrid, const char *val);
	virtual void update (UpdateCtx *ctx, unsigned int flags);
	virtual void modified (unsigned int flags);
	virtual Object *childAdded (Thera::Node *cnode, Thera::Node *rnode);
	virtual unsigned int removeChild (Thera::Node *cnode, Thera::Node *rnode);
	// Item implementation
	virtual Sehle::Renderable *show (Sehle::Graph *graph, Sehle::u32 contextmask);
	virtual void hide (Sehle::RenderableGroup *pgroup);
	virtual Item *trace (const Elea::Line3f *ray, unsigned int mask, float *distance);
public:
	// Constructor
	Group (void) : Item(HAS_CHILDREN) {}
	// Type system
	static const Type *type (void);
};

class Scene : public Object {
private:
	Sehle::RenderableGroup *rgroup;

	void updateChildData (Thera::Node *removed);
protected:
	// Object implementation
	virtual const Type *objectType (void);
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	virtual void set (const char *attrid, const char *val);
	virtual void write (const char *attrid);
	virtual Object *childAdded (Thera::Node *cnode, Thera::Node *rnode);
	virtual unsigned int removeChild (Thera::Node *cnode, Thera::Node *rnode);
	virtual void update (UpdateCtx *ctx, unsigned int flags);
	virtual void modified (unsigned int flags);
public:
	Elea::Color4f ambient;
	u32 ncameras;
	Camera **cameras;

	// Constructor
	Scene (void) : Object(HAS_CHILDREN), rgroup(NULL), ambient(Elea::Color4fWhite), ncameras(0), cameras(NULL) {}
	// Type system
	static const Type *type (void);

	// Access
	void show (Sehle::Graph *graph);
	void hide (void);
	Item *trace (const Elea::Line3f *ray, unsigned int mask, float *distance);
	Item *trace (const Elea::Line3f *wray, unsigned int mask, const Elea::Matrix4x4f *e2us, float *distance, Elea::Vector3f *uscp);

	void setAmbient (const Elea::Color4f& color);
};

} // Namespace Miletos

#endif

