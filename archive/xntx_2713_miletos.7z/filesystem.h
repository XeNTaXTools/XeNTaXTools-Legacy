#ifndef __MILETOS_FILESYSTEM_H__
#define __MILETOS_FILESYSTEM_H__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2007-2008
//

#include <string>
#include <vector>

#include <libarikkei/dict.h>

#include <miletos/uri.h>

namespace Miletos {

namespace FileSystem {

class Handler;

// All pathnames use '/' as separators
// Directories have '/' as last symbol
char *canonizeName (const char *path, bool isdirectory, bool makelowercase);
char *canonizeName (const char *path, size_t length, bool isdirectory, bool makelowercase);
unsigned int isAbsolutePath (const char *path);

// Handler

class Handler {
private:
	unsigned int _refcount;
	char *_name;
protected:
	bool _valid;
	// Constructor
	Handler (const char *name);
public:
	// Destructor
	virtual ~Handler (void);

	// Refrence counting
	void ref (void) { _refcount++; }
	void unRef (void) { _refcount--; if (!_refcount) delete this; }

	// Get the name of current handler
	const char *getName (void) const { return _name; }
	// Check integrity
	bool isValid (void) const { return _valid; }

	// Absolute paths are relative to root, relative paths to current directory
	// Test whether current handler has dir
	virtual bool hasDir (const char *name) = 0;
	// Test whether current handler has file
	virtual bool hasFile (const char *name) = 0;

	// Set current reading directory to given value (or unset if there is no such dir)
	virtual bool loadDir (const char *name) = 0;
	// Get current reading directory name (normalized)
	virtual const char *getDirName (void) = 0;
	// Return the number of files in reading dir
	virtual int getNumFiles (void) = 0;
	// Return the name of file in reading dir
	virtual const char *getFileName (int idx) = 0;
	// Return the size of file in reading dir
	virtual size_t getFileSize (int idx) = 0;
	// Return the number of subdirectories in reading dir
	virtual int getNumSubDirs (void) = 0;
	// Return the name of subdirectory in reading dir
	// Subdir name ends with '/'
	virtual const char *getSubDirName (int idx) = 0;
	// Get file image
	virtual unsigned const char *mmapFile (const char *name, size_t *size) = 0;
	// Release file image
	virtual void munmapFile (const unsigned char *data) = 0;
};

// HandlerFileList

class HandlerFileList : public Handler {
private:
protected:
	bool ignorecase;
	// Absolute canonical name of currentdir (i.e. starts and ends with '/')
	std::string currentdir;

	// If dataref is still 0 after successful mapping then data is not reference managed
	// Name should be canonical absolute name (i.e.) start with '/'
	struct Entry {
		int id;
		char *name;
		int dataref;
		size_t csize;
		unsigned char *cdata;
	};

	std::vector<Entry *> entries;
	Arikkei::Dict<const char *, Entry *> namedict;
	Arikkei::Dict<const char *, Entry *> datadict;

	// Constructor
	HandlerFileList (const char *name);

	// Add file mapping
	virtual void addFileMapping (Entry *entry) {};

	// Helpers
	Entry *getEntry (const char *name);
public:
	// Destructor
	virtual ~HandlerFileList (void);

	// Handler implementation
	// Get current reading directory name (normalized)
	virtual const char *getDirName (void) { return currentdir.c_str (); }
	// Test whether current handler has file
	virtual bool hasFile (const char *name);
	// Get file image
	virtual unsigned const char *mmapFile (const char *name, size_t *size);
	// Release file image
	virtual void munmapFile (const unsigned char *data);

	// Get absolute name from canonized name (i.e. currentdir is prepended if not starting with '/')
	char *getAbsoluteCanonicalName (const char *name, bool isdirectory, bool makelowercase);
};

// Resolve file:... URI-s

class URLHandler : public URI::URLHandler {
private:
	Handler * handler;

	URLHandler (const char *location);
	virtual ~URLHandler (void);

	// URLHandler implementation
	virtual const unsigned char *mmapDataRelative (const char *name, size_t *size);
	virtual void munmapData (const unsigned char *data);
public:
	// Static constructor
	static URI::URLHandler *newURLHandler (const char *url);
};

unsigned const char *mmapFile (const char *name, size_t *size);
void munmapFile (const unsigned char *data);

// This grabs reference to handler
void addHandler (const char *id, Handler *handler);
void removeHandler (const char *id);

void addDirectoryHandler (const char *id, const char *basedir);
void AddZipHandler (const char *id, const char *zipfilename);

bool hasFile (const char *name);

Handler *newDirectoryHandler (const char *dirname);

} // Namespace FileSystem

} // Namespace Miletos

#endif

