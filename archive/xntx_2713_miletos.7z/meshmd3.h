#ifndef __MILETOS_MESHMD3_H__
#define __MILETOS_MESHMD3_H__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2007
//

#if 0
#include <miletos/mesh.h>

namespace Miletos {

class MeshMD3 : public SMesh {
private:
	// Object implementation
	virtual const Type *objectType (void);
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	virtual void set (const char *attrid, const char *val);
	virtual void update (UpdateCtx *ctx, unsigned int flags);
	// Item implementation
	// SMesh implementation
	virtual void buildMesh (Sehle::StaticMesh *mesh);
public:
	// Type system
	static const Type *type (void);
};

} // Namespace Miletos

#endif

#endif

