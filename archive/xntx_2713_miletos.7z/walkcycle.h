#ifndef __MILETOS_WALKCYCLE_H__
#define __MILETOS_WALKCYCLE_H__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2010
//

#include <miletos/animation.h>

namespace Miletos {

class Figure;

namespace Animation {

class Pose;
class Graph;

//
// Walkcycle
//
// This is specail transition that is composed of 5 sequential poses
//

class WalkCycle : public Source {
public:
	enum { LEFT_FORWARD, LEFT_FRONT, RIGHT_FORWARD, RIGHT_FRONT };
private:
	// Object implementation
	virtual const Type *objectType (void);

	void clear (unsigned int poses, unsigned int ids);
protected:
	// Object implementation
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	virtual void set (const char *attrid, const char *val);
	virtual void write (const char *attrid);
	virtual void attachedObjectRelease (Object *attached, void *data);
	virtual void attachedObjectModified (Object *attached, unsigned int flags, void *data);

public:
	WalkCycle (void);

	char *keyposesids[5];
	// Attached graph
	Graph *graph;
	// Keyframes
	Pose *keyposes[5];
	// The phase of first keyframe (0-3)
	int phase;
	// The changes of position during phases
	Elea::Vector3f movements[4];

	// Type system
	static const Type *type (void);

	// Attach transition to graph - i.e. resolve keyframes and attach to poses (NULL detaches)
	void attachToGraph (Graph *graph);
	// Update keypose sids
	void setKeyposeSid (int idx, const char *sid);
};

//
// Biped manages character animation
//

class Biped : public Object {
private:
	char *targetid;
	char *graphid;
	char *animationsid;

	// Object implementation
	virtual const Type *objectType (void);
protected:
	// Object implementation
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	virtual void set (const char *attrid, const char *val);
	virtual void update (UpdateCtx *ctx, unsigned int flags);
	virtual void identityAdded (Document *pdocument, const char *pidentity, Object *pobject);
	virtual void identityRemoved (Document *pdocument, const char *pidentity);
	virtual void attachedObjectRelease (Object *attached, void *data);
	virtual void attachedObjectModified (Object *attached, unsigned int flags, void *data);

public:
	Figure *target;
	Graph *graph;

	float delta;
	Elea::Vector3f speed;

	Biped (void);

	// Type system
	static const Type *type (void);

	float getS (float dT);
};

} // Namespace Animation

} // Namespace Miletos

#endif

