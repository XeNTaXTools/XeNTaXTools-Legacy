#define __MILETOS_SKINNEDGEOMETRY_CPP__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2009
//

static const int debug = 0;

#include <malloc.h>

#include <elea/line.h>
#include <elea/quaternion.h>

#include <sehle/engine.h>
#include <sehle/graph.h>
#include <sehle/renderable.h>

#include "morph.h"
#include "animation.h"
#include "figure.h"
#include "skeleton.h"
#include "bone.h"
#include "material.h"
#include "xml/base.h"

#include "skinnedgeometry.h"

namespace Miletos {

PoseableGeometry::PoseableGeometry (void)
: Geometry(HAS_CHILDREN),
parentsid(NULL), anchorid(NULL),
nbones(0), bones(NULL), anchor(-1),
nvertices(0),  xbase(NULL), vanim(NULL), nanim(NULL), tanim(NULL),
nindices(0), indices(NULL),
skeleton(NULL), skeletonanchoridx(-1)
{
}

PoseableGeometry::~PoseableGeometry (void)
{
	if (parentsid) free (parentsid);
	if (anchorid) free (anchorid);
}

const Object::Type *
PoseableGeometry::objectType (void)
{
	return type ();
}

const Object::Type *
PoseableGeometry::type (void)
{
	static Type *mytype = NULL;
	static const Attribute attrs[] = {
		{ "ownerBone", NULL, 0 },
		{ "anchorBone", NULL, 0 },
		{ "localTransform", NULL, 0 }
	};
	if (!mytype) mytype = new Type(Geometry::type (), "PoseableGeometry", NULL, NULL, sizeof (attrs) / sizeof (attrs[0]), attrs);
	return mytype;
}

void
PoseableGeometry::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	Geometry::build (pnode, doc, ctx);
	buildAllAttributes (type (), ctx);
}

void
PoseableGeometry::release (void)
{
	if (skeleton) {
		skeleton->detach (this);
		skeleton = NULL;
	}
	clear ();
	Geometry::release ();
}

void
PoseableGeometry::set (const char *attrid, const char *val)
{
	if (!strcmp (attrid, "ownerBone")) {
		if (parentsid) free (parentsid);
		parentsid = (val) ? strdup (val) : NULL;
		requestUpdate (MODIFIED | MESH_DEFINITION_MODIFIED);
	} else if (!strcmp (attrid, "anchorBone")) {
		if (anchorid) free (anchorid);
		anchorid = (val) ? strdup (val) : NULL;
		updateBoneStatus ();
		requestUpdate (MODIFIED | MESH_DEFINITION_MODIFIED);
	} else if (!strcmp (attrid, "localTransform")) {
		Elea::Matrix4x4f s2p4;
		if (XML::parseTransform (s2p4, val)) {
			s2p.set (s2p4);
		} else {
			s2p = Elea::Matrix3x4fIdentity;
		}
		requestUpdate (MODIFIED | MESH_DEFINITION_MODIFIED);
	} else {
		Geometry::set (attrid, val);
	}
}

void
PoseableGeometry::write (const char *attrid)
{
	if (!strcmp (attrid, "ownerBone")) {
		node->setAttribute (attrid, parentsid);
	} else {
		Geometry::write (attrid);
	}
}

void
PoseableGeometry::update (UpdateCtx *ctx, unsigned int flags)
{
	bbox.setEmpty ();

	Geometry::update (ctx, flags);

	if (flags & ANIMATION_MODIFIED) {
		updateBoneMatrixes ();
		updateBoneBBoxes ();
	}
}

void
PoseableGeometry::attachedObjectRelease (Object *attached, void *data)
{
	if (attached == skeleton) {
		fprintf (stderr, "PoseableGeometry::attachedObjectRelease: Skeleton should detach itself before sending release signal\n");
		skeleton = NULL;
	}
}

void
PoseableGeometry::attachedObjectModified (Object *attached, unsigned int flags, void *data)
{
	if (attached == skeleton) {
		if (flags & (MODIFIED | ANIMATION_MODIFIED)) {
			requestUpdate (flags & MODIFIED_STATE);
		}
	}
}

unsigned int
PoseableGeometry::getVertices (const Elea::Vector3f **vertices, const Elea::Vector3f **normals, const Elea::Vector3f **tangents, const Elea::Vector2f **texcoords)
{
	if (vertices) *vertices = vanim;
	if (normals) *normals = nanim;
	if (tangents) *tangents = tanim;
	if (texcoords) *texcoords = xbase;
	return nvertices;
}

unsigned int
PoseableGeometry::getIndices (const u32 **pindices)
{
	if (pindices) *pindices = indices;
	return nindices;
}

void
PoseableGeometry::clear (void)
{
	// Clear bones
	for (unsigned int i = 0; i < nbones; i++) {
		if (bones[i].id) free (bones[i].id);
	}
	nbones = NULL;
	if (bones) free (bones);
	bones = NULL;

	nvertices = 0;
	if (xbase) free (xbase);
	xbase = NULL;
	if (vanim) free (vanim);
	vanim = NULL;
	if (nanim) free (nanim);
	nanim = NULL;
	if (tanim) free (tanim);
	tanim = NULL;

	nindices = 0;
	if (indices) free (indices);
	indices = NULL;

	nfrags = 0;
	if (frags) free (frags);
	frags = NULL;

	Geometry::clear ();
}

void
PoseableGeometry::updateBoneStatus (void)
{
	anchor = -1;
	if (anchorid) {
		for (unsigned int i = 0; i < nbones; i++) {
			if (bones[i].id && !strcmp (bones[i].id, anchorid)) {
				anchor = i;
				break;
			}
		}
	}
	if (anchor < 0) {
		for (unsigned int i = 0; i < nbones; i++) bones[i].locked = 0;
	} else {
		for (unsigned int i = 0; i < nbones; i++) bones[i].locked = 1;
		for (unsigned int i = 0; i < nbones; i++) {
			if ((bones[i].pidx == anchor) || ((bones[i].pidx >= 0) && !bones[bones[i].pidx].locked)) bones[i].locked = 0;
		}
	}
}

void
PoseableGeometry::updateBoneMatrixes (void)
{
	for (unsigned int i = 0; i < nbones; i++) {
		bones[i].ab2s = (bones[i].pidx >= 0) ? bones[bones[i].pidx].ab2s * bones[i].ab2p : bones[i].ab2p;
		bones[i].as2m = s2m * bones[i].ab2s * bones[i].s2b;
	}
}

void
PoseableGeometry::updateBoneBBoxes (void)
{
	for (unsigned int i = 0; i < nbones; i++) {
		bones[i].abbox = bones[i].as2m.transform (bones[i].bbox);
	}
}

void
PoseableGeometry::setNumBones (unsigned int pnumbones)
{
	if (pnumbones == nbones) return;
	if (pnumbones < nbones) {
		for (unsigned int i = pnumbones; i < nbones; i++) {
			if (bones[i].id) free (bones[i].id);
		}
	}
	bones = (Bone *) realloc (bones, pnumbones * sizeof (Bone));
	if (pnumbones > nbones) {
		for (unsigned int i = nbones; i < pnumbones; i++) {
			bones[i].id = NULL;
		}
	}
	nbones = pnumbones;
}

void
PoseableGeometry::setBone (int bidx, const char *id, int pidx, const Elea::Matrix3x4f& b2p)
{
	if (bones[bidx].id) free (bones[bidx].id);
	bones[bidx].id = (id) ? strdup (id) : NULL;
	bones[bidx].pidx = pidx;
	bones[bidx].locked = 0;
	bones[bidx].b2p = b2p;
}

void
PoseableGeometry::setNumVertices (unsigned int pnumvertices, bool texcoords, bool normals, bool tangents)
{
	nvertices = pnumvertices;
	if (texcoords) {
		xbase = (Elea::Vector2f *) realloc (xbase, nvertices * sizeof (Elea::Vector2f));
	} else {
		if (xbase) free (xbase);
		xbase = NULL;
	}
	vanim = (Elea::Vector3f *) realloc (vanim, nvertices * sizeof (Elea::Vector3f));
	if (normals) {
		nanim = (Elea::Vector3f *) realloc (nanim, nvertices * sizeof (Elea::Vector3f));
	} else {
		if (nanim) free (nanim);
		nanim = NULL;
	}
	if (tangents) {
		tanim = (Elea::Vector3f *) realloc (tanim, nvertices * sizeof (Elea::Vector3f));
	} else {
		if (tanim) free (tanim);
		tanim = NULL;
	}
}

void
PoseableGeometry::setNumIndices (unsigned int pnumindices)
{
	if (pnumindices == nindices) return;
	nindices = pnumindices;
	indices = (unsigned int *) realloc (indices, nindices * sizeof (unsigned int));
}

void
PoseableGeometry::initializeBoneMatrixes (void)
{
	for (unsigned int i = 0; i < nbones; i++) {
		Elea::Matrix3x4f p2b;
		bones[i].b2p.invertNormalized (&p2b);
		bones[i].s2b = (bones[i].pidx >= 0) ? p2b * bones[bones[i].pidx].s2b : p2b;
		bones[i].ab2p = bones[i].b2p;
		bones[i].s2b.invertNormalized (&bones[i].ab2s);
		bones[i].as2m = s2m;
	}
}

int
PoseableGeometry::lookupBone (const char *sid)
{
	if (!sid || !*sid) return -1;
	for (unsigned int i = 0; i < nbones; i++) {
		if (bones[i].id && !strcmp (bones[i].id, sid)) return i;
	}
	return -1;
}

void
PoseableGeometry::setBoneAnimation (int bidx, const Elea::Matrix3x4f& ab2p)
{
	bones[bidx].ab2p = ab2p;
	requestUpdate (ANIMATION_MODIFIED);
}

void
PoseableGeometry::setA2M (const Elea::Matrix3x4f& a2m)
{
	if (anchor >= 0) {
		s2m = a2m * s2p * bones[anchor].s2b;
	} else {
		s2m = a2m * s2p;
	}
	s2m.invertNormalized (&m2s);

	requestUpdate (ANIMATION_MODIFIED);
}

void
PoseableGeometry::buildSkeleton (Thera::Node *skelnode, int algorithm)
{
	for (unsigned int i = 0; i < nbones; i++) {
		if (bones[i].pidx < 0) {
			Thera::Node *node = buildSkeletalBone (skelnode->getDocument (), i, &Elea::Quaternionf0, 0, algorithm);
			skelnode->appendChild (node);
		}
	}
}

Thera::Node *
PoseableGeometry::buildBoneTree (Thera::Document *pdocument, int rootidx, int algorithm)
{
	return buildSkeletalBone (pdocument, rootidx, &Elea::Quaternionf0, 0, algorithm);
}

Thera::Node *
PoseableGeometry::buildSkeletalBone (Thera::Document *thedoc, int bidx, const Elea::Quaternionf *parentdir, float parentlen, int algorithm)
{
	Bone *bone = &bones[bidx];

	Thera::Node *node = new Thera::Node (Thera::Node::ELEMENT, thedoc, "bone");
	node->setAttribute ("id", bone->id);
	node->setAttribute ("sid", bone->id);

	char c[256];
	Elea::Matrix4x4f b2p4(bone->b2p);
	Orientation pos;
	pos.q = b2p4.getRotationQuaternion ();
	pos.p = b2p4.getTranslation ();
	int p = XML::writeOrientation (c, 256, pos.q, pos.p, true);
	node->setAttribute ("orientation", c);
	Elea::Matrix4x4f ab2p4(bone->ab2p);
	pos.q = ab2p4.getRotationQuaternion ();
	pos.p = ab2p4.getTranslation ();
	p = XML::writeOrientation (c, 256, pos.q, pos.p, false);
	node->setAttribute ("animatedOrientation", c);

	// Heuristics to find the best visual geometry
	Orientation vOrientation;
	float vLength = 0.1f;
	// Start and endpoint
	Elea::Vector3f p0(0, 0, 0);
	vOrientation.p = p0;
	Elea::Vector3f p1(p0);
	int nchildren = 0;
	for (unsigned int j = 0; j < nbones; j++) {
		if (bones[j].pidx == bidx) {
			p1 += bones[j].b2p.getTranslation ();
			nchildren += 1;
			if (algorithm == 1) break;
		}
	}
	Elea::Vector3f d(p1 - p0);
	if (d.length2 () > 0) {
		d /= (float) nchildren;
		// Main direction vector
		vLength = d.length ();
		if (vLength > 0) {
			Elea::Vector3f dn(d.normalize ());
			float dnx = Elea::Vector3f::scalarProduct (dn, Elea::Vector3fX);
			float dny = Elea::Vector3f::scalarProduct (dn, Elea::Vector3fY);
			float dnz = Elea::Vector3f::scalarProduct (dn, Elea::Vector3fZ);
			Elea::Vector3f tz(d.normalize ());
			Elea::Vector3f ty;
			if ((fabs (dnx) >= fabs (dny)) && (fabs (dnx) >= fabs (dnz))) {
				// X is main dimension
				if (dnx > 0) {
					ty = Elea::Vector3fZ;
				} else {
					ty = -Elea::Vector3fZ;
				}
			} else if ((fabs (dny) >= fabs (dnx)) && (fabs (dny) >= fabs (dnz))) {
				// Y is main dimension
				if (dny > 0) {
					ty = Elea::Vector3fX;
				} else {
					ty = -Elea::Vector3fX;
				}
			} else {
				// Z is main dimension
				if (dnz > 0) {
					ty = Elea::Vector3fY;
				} else {
					ty = -Elea::Vector3fY;
				}
			}
			Elea::Vector3f tx(ty * tz);
			// Renormalize ty
			ty = tz * tx;
			// Now construct bone shape matrix
			// fixme: Maybe switch coordinates so x is main dimension (Lauris)
			Elea::Matrix4x4f t;
			for (int i = 0; i < 3; i++) {
				t[0 + i] = tx[i];
				t[4 + i] = ty[i];
				t[8 + i] = tz[i];
			}
			vOrientation.q = t.getRotationQuaternion ();
		}
	} else if (bone->pidx >= 0) {
		vOrientation.q = *parentdir;
		vLength = parentlen;
	} else {
		vOrientation.q = Elea::Quaternionf0;
	}
	p = XML::writeOrientation (c, 256, vOrientation.q, vOrientation.p, false);
	node->setAttribute ("vOrientation", c);
	p = XML::writeNumber (c, 256, vLength);
	node->setAttribute ("vLength", c);

	// Add children
	for (unsigned int i = 0; i < nbones; i++) {
		if (bones[i].pidx == bidx) {
			Thera::Node *child = buildSkeletalBone (thedoc, i, &vOrientation.q, vLength, algorithm);
			node->appendChild (child);
		}
	}

	return node;
}

void
PoseableGeometry::attachSkeleton (Skeleton *pskeleton)
{
	if (skeleton != pskeleton) {
		if (skeleton) skeleton->detach (this);
		skeleton = pskeleton;
		skeleton->attach (this);
	}
	skeleton2local.resize (skeleton->bones.size ());
	skeletonanchoridx = -1;
	if (parentsid) {
		skeletonanchoridx = skeleton->lookupBone (parentsid);
		if (skeletonanchoridx >= 0) {
			setA2M (skeleton->bones[skeletonanchoridx]->getAB2O ());
		}
	}
	for (size_t i = 0; i < skeleton->bones.size (); i++) {
		int bidx = lookupBone (skeleton->bones[i]->sid);
		if (bidx >= 0) {
			if (bones[bidx].locked) {
				bidx = -1;
			}
			// fixme: If parent and child have identical bone names everything will be messed up (Lauris)
		}
		skeleton2local[i] = bidx;
		if (skeleton2local[i] >= 0) {
			setBoneAnimation (skeleton2local[i], skeleton->bones[i]->ab2p);
		}
	}
}

void
PoseableGeometry::detachSkeleton (Skeleton *pskeleton)
{
	skeleton2local.clear ();
	skeletonanchoridx = -1;
	skeleton->detach (this);
	skeleton = NULL;
}

void
PoseableGeometry::applyBoneAnimation (int bidx, Animation::BoneAnimation *ba, float frametime)
{
	Elea::Matrix3x4f ab2p = ba->getAB2P (frametime, Animation::Source::CLAMP);
	setBoneAnimation (bidx, ab2p);
}

void
PoseableGeometry::applySkinAnimation (Animation::SkinAnimation *animation, float frametime)
{
	float time = frametime / animation->fps;
	// fixme: Keyframeanimations
	for (u32 j = 0; j < animation->nboneanimations; j++) {
		int bidx = lookupBone (animation->boneanimations[j]->bonesid);
		if (bidx < 0) continue;
		applyBoneAnimation (bidx, animation->boneanimations[j], time * animation->boneanimations[j]->fps);
	}
	requestUpdate (MODIFIED | ANIMATION_MODIFIED);
}

// Skinnedgeometry

SkinnedGeometry::SkinnedGeometry (void)
: renderable(NULL),
vbase(NULL), nbase(NULL), tbase(NULL),
wcounts(NULL), nweights(0), weights(NULL),
nmorphs(0), morphs(NULL), nanimations(0), animations(NULL)
{
}

SkinnedGeometry::~SkinnedGeometry (void)
{
	// Parent has to hide us before deleting
	assert (!renderable);
	clear ();
}

const Object::Type *
SkinnedGeometry::objectType (void)
{
	return type ();
}

const Object::Type *
SkinnedGeometry::type (void)
{
	static Type *mytype = NULL;
	if (!mytype) mytype = new Type(PoseableGeometry::type (), "SkinnedGeometry", NULL, NULL, 0, NULL);
	return mytype;
}

void
SkinnedGeometry::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	PoseableGeometry::build (pnode, doc, ctx);
	buildAllAttributes (type (), ctx);
	updateChildData (NULL);
}

void
SkinnedGeometry::release (void)
{
	nmorphs = 0;
	if (morphs) free (morphs);
	morphs = NULL;
	nanimations = 0;
	if (animations) free (animations);
	animations = NULL;
	clear ();
	PoseableGeometry::release ();
}

Object *
SkinnedGeometry::childAdded (Thera::Node *cnode, Thera::Node *rnode)
{
	Object *cobj = PoseableGeometry::childAdded (cnode, rnode);
	updateChildData (NULL);
	return cobj;
}

void
SkinnedGeometry::childRemoved (Thera::Node *cnode, Thera::Node *rnode)
{
	updateChildData (cnode);
	PoseableGeometry::childRemoved (cnode, rnode);
}

void
SkinnedGeometry::update (UpdateCtx *ctx, unsigned int flags)
{
	// fixme: Because we use morph flags, we have to process these before we invoke superclass update
	// fixme: One idea is to use modified flag instead of update
	// Update morphs
	for (unsigned int i = 0; i < nmorphs; i++) {
		if (morphs[i]->enabled && morphs[i]->updateFlagIsSet (MODIFIED | CHILD_MODIFIED)) {
			float s = morphs[i]->s;
			applyMorph (morphs[i], s);
		}
	}
	// Update animations
	for (unsigned int i = 0; i < nanimations; i++) {
		if (animations[i]->enabled && animations[i]->updateFlagIsSet (MODIFIED | CHILD_MODIFIED)) {
			for (u32 j = 0; j < animations[i]->nkeyframeanimations; j++) {
				Animation::KeyFrameAnimation *kfa = animations[i]->keyframeanimations[j];
				if (!kfa->enabled) continue;
				u32 f0, f1;
				f32 s;
				float frametime = animations[i]->currentframetime * (kfa->fps / animations[i]->fps);
				if (kfa->interpolate (frametime, f0, f1, s, Animation::Source::CLAMP)) {
					applyAnimation (kfa, f0, f1, s);
				}
			}
			for (unsigned int j = 0; j < animations[i]->nboneanimations; j++) {
				if (!animations[i]->boneanimations[j]->enabled) continue;
				// fixme:
				int bidx = lookupBone (animations[i]->boneanimations[j]->bonesid);
				if ((bidx < 0) || (bidx >= (int) nbones)) continue;
				float frametime = animations[i]->currentframetime * (animations[i]->boneanimations[j]->fps / animations[i]->fps);
				applyBoneAnimation (bidx, animations[i]->boneanimations[j], frametime);
			}
			// fixme: How to handle this? (Lauris)
			flags |= ANIMATION_MODIFIED;
		}
	}

	PoseableGeometry::update (ctx, flags);

	if (flags & (MESH_DEFINITION_MODIFIED | ANIMATION_MODIFIED)) {
		// Update weights
		memset (vanim, 0, nvertices * sizeof (Elea::Vector3f));
		if (nanim) memset (nanim, 0, nvertices * sizeof (Elea::Vector3f));
		if (tanim) memset (tanim, 0, nvertices * sizeof (Elea::Vector3f));
		int wpos = 0;
		for (unsigned int vidx = 0; vidx < nvertices; vidx++) {
			for (unsigned int widx = 0; widx < wcounts[vidx]; widx++) {
				vanim[vidx] += weights[wpos].weight * bones[weights[wpos].bone].as2m.transformPoint3 (vbase[vidx]);
				if (nanim) nanim[vidx] += weights[wpos].weight * bones[weights[wpos].bone].as2m.transformVector3 (nbase[vidx]);
				if (tanim) tanim[vidx] += weights[wpos].weight * bones[weights[wpos].bone].as2m.transformVector3 (tbase[vidx]);
				wpos += 1;
			}
		}
	}

	if (nvertices) {
		Elea::Matrix4x4f s2w = ctx->i2w * Elea::Matrix4x4f::scaling (scale, scale, scale);
		bbox.grow (vanim[0], nvertices, sizeof (vanim[0]), &s2w);
	}

	if (renderable) {
		if (flags & MESH_DEFINITION_MODIFIED) {
			rebuildRenderable (renderable);
		} else if (flags & (MODIFIED | ANIMATION_MODIFIED)) {
			updateRenderable (renderable);
			if (flags & MATERIAL_DEFINITION_MODIFIED) {
				Sehle::StaticMesh *mesh = (Sehle::StaticMesh *) renderable;
				for (unsigned int i = 0; i < nmaterials; i++) {
					if ((i < noverrides) && (overrides[i])) {
						mesh->setMaterial (i, overrides[i]->getSehleMaterial (mesh->graph->engine));
					} else {
						mesh->setMaterial (i, getMaterial (i, mesh->graph->engine));
					}
				}
			}
		}
		Elea::Matrix3x4f m3(ctx->i2w);
		renderable->setTransform (&m3);
		renderable->setBBox (&bbox);
	}
}

void
SkinnedGeometry::clear (void)
{
	// Clear vertices
	if (vbase) free (vbase);
	vbase = NULL;
	if (nbase) free (nbase);
	nbase = NULL;
	if (tbase) free (tbase);
	tbase = NULL;

	// Clear weights
	if (wcounts) free (wcounts);
	wcounts = NULL;
	nweights = 0;
	if (weights) free (weights);
	weights = NULL;

	PoseableGeometry::clear ();
}

void
SkinnedGeometry::initializeBoneBBoxes (void)
{
	// valgrind_check ();

	for (unsigned int i = 0; i < nbones; i++) {
		bones[i].bbox.setEmpty ();
	}
	int wpos = 0;
	for (unsigned int vidx = 0; vidx < nvertices; vidx++) {
		for (unsigned int widx = 0; widx < wcounts[vidx]; widx++) {
			bones[weights[wpos].bone].bbox.grow (vbase[vidx]);
			wpos += 1;
		}
	}
	for (unsigned int i = 0; i < nbones; i++) {
		bones[i].abbox = bones[i].as2m.transform (bones[i].bbox);
	}
}

void
SkinnedGeometry::setNumVertices (int pnumvertices, bool texcoords, bool normals, bool tangents, bool weightcounts)
{
	PoseableGeometry::setNumVertices (pnumvertices, texcoords, normals, tangents);
	vbase = (Elea::Vector3f *) realloc (vbase, nvertices * sizeof (Elea::Vector3f));
	if (normals) {
		nbase = (Elea::Vector3f *) realloc (nbase, nvertices * sizeof (Elea::Vector3f));
	} else {
		if (nbase) free (nbase);
		nbase = NULL;
	}
	if (tangents) {
		tbase = (Elea::Vector3f *) realloc (tbase, nvertices * sizeof (Elea::Vector3f));
	} else {
		if (tbase) free (tbase);
		tbase = NULL;
	}
	if (weightcounts) {
		wcounts = (unsigned int *) realloc (wcounts, nvertices * sizeof (unsigned int));
	} else {
		if (wcounts) free (wcounts);
		wcounts = NULL;
	}
}

void
SkinnedGeometry::setNumWeights (int pnumweights)
{
	if (pnumweights == nweights) return;
	nweights = pnumweights;
	weights = (Weight *) realloc (weights, nweights * sizeof (Weight));
}

void
SkinnedGeometry::calculateNormals (bool normalize)
{
	if (!nbase) return;
	memset (nbase, 0, nvertices * sizeof (nbase[0]));
	for (unsigned int i = 0; i < nfrags; i++) {
		for (unsigned int j = 0; j < frags[i].numindices; j += 3) {
			for (int k = 0; k < 3; k++) {
				unsigned int idx0 = indices[frags[i].firstindex + j + (k + 0) % 3];
				unsigned int idx1 = indices[frags[i].firstindex + j + (k + 1) % 3];
				unsigned int idx2 = indices[frags[i].firstindex + j + (k + 2) % 3];
				Elea::Vector3f v0(vbase[idx1] - vbase[idx0]);
				Elea::Vector3f v1(vbase[idx2] - vbase[idx0]);
				Elea::Vector3f vq(v0 + v1);
				v0.normalizeSelf ();
				vq.normalizeSelf ();
				nbase[idx0] += v0 * vq;
			}
		}
	}
	if (normalize) {
		for (unsigned int i = 0; i < nvertices; i++) nbase[i].normalizeSelf ();
	}
}

void
SkinnedGeometry::rebuildRenderable (Sehle::StaticMesh *mesh)
{
	if (!nvertices || !nindices || !nfrags) {
		mesh->resizeMaterials (0);
		mesh->resizeFragments (0);
		if (mesh->vbuffer) mesh->vbuffer->unRef ();
		mesh->vbuffer = NULL;
		if (mesh->ibuffer) mesh->ibuffer->unRef ();
		mesh->ibuffer = NULL;
		return;
	}

	if (debug) fprintf (stderr, "Rebuilding renderable... ");

	Sehle::VertexBuffer *newvbuf = mesh->graph->engine->getVertexBuffer (vertexid);
	if (mesh->vbuffer) mesh->vbuffer->unRef ();
	mesh->vbuffer = newvbuf;
	u32 vstride = 3;
	u32 noffset = 0;
	u32 toffset = 0;
	u32 xoffset = 0;
	if (nbase) {
		noffset = vstride;
		vstride += 3;
	}
	if (tbase) {
		toffset = vstride;
		vstride += 3;
	}
	if (xbase) {
		xoffset = vstride;
		vstride += 2;
	}
	mesh->vbuffer->setUp ((Sehle::u32) nvertices, vstride);
	mesh->vbuffer->setOffset (Sehle::VertexBuffer::COORDINATES, 0);
	mesh->vbuffer->setOffset (Sehle::VertexBuffer::NORMALS, noffset);
	mesh->vbuffer->setOffset (Sehle::VertexBuffer::TANGENTS, toffset);
	mesh->vbuffer->setOffset (Sehle::VertexBuffer::TEXCOORDS, xoffset);
	mesh->vbuffer->map (Sehle::VertexBuffer::WRITE);
	if (xbase) {
		mesh->vbuffer->setValues (0, nvertices, mesh->vbuffer->offset[Sehle::VertexBuffer::TEXCOORDS], xbase[0], 2, sizeof (xbase[0]));
	}
	mesh->vbuffer->unMap ();

	Sehle::IndexBuffer *newibuf = mesh->graph->engine->getIndexBuffer (indexid);
	if (mesh->ibuffer) mesh->ibuffer->unRef ();
	mesh->ibuffer = newibuf;
	mesh->ibuffer->resize ((Sehle::u32) nindices);
	mesh->ibuffer->map (Sehle::IndexBuffer::WRITE);
	memcpy (mesh->ibuffer->indices, indices, nindices * sizeof (indices[0]));
	mesh->ibuffer->unMap ();

	mesh->resizeMaterials (nmaterials);
	for (unsigned int i = 0; i < nmaterials; i++) {
		if ((i < noverrides) && (overrides[i])) {
			mesh->setMaterial (i, overrides[i]->getSehleMaterial (mesh->graph->engine));
		} else {
			mesh->setMaterial (i, getMaterial (i, mesh->graph->engine));
		}
	}

	int nvisiblefrags = 0;
	for (unsigned int i = 0; i < nfrags; i++) {
		if (frags[i].visible) nvisiblefrags += 1;
	}
	mesh->resizeFragments (nvisiblefrags);
	int fidx = 0;
	for (unsigned int i = 0; i < nfrags; i++) {
		if (!frags[i].visible) continue;
		mesh->frags[fidx].matidx = frags[i].matidx;
		mesh->frags[fidx].first = frags[i].firstindex;
		mesh->frags[fidx].nindices = frags[i].numindices;
		fidx += 1;
	}

	if (debug) fprintf (stderr, "finished\n");

	updateRenderable (mesh);
}

void
SkinnedGeometry::updateRenderable (Sehle::StaticMesh *mesh)
{
	if (!nvertices || !nindices || !nfrags) return;

	if (debug) fprintf (stderr, "Updating renderable... ");

	mesh->vbuffer->map (Sehle::VertexBuffer::WRITE);
	if (scale == 1) {
		mesh->vbuffer->setValues (0, nvertices, mesh->vbuffer->offset[Sehle::VertexBuffer::COORDINATES], vanim[0], 3, sizeof (Elea::Vector3f));
	} else {
		for (unsigned int i = 0; i < nvertices; i++) {
			mesh->vbuffer->setValues (i, mesh->vbuffer->offset[Sehle::VertexBuffer::COORDINATES], scale * vanim[i], 3);
		}
	}
	if (nbase) mesh->vbuffer->setValues (0, nvertices, mesh->vbuffer->offset[Sehle::VertexBuffer::NORMALS], nanim[0], 3, sizeof (nanim[0]));
	if (tbase) mesh->vbuffer->setValues (0, nvertices, mesh->vbuffer->offset[Sehle::VertexBuffer::TANGENTS], tanim[0], 3, sizeof (tanim[0]));
	mesh->vbuffer->unMap ();

	mesh->setBBox (&bbox);

	if (debug) fprintf (stderr, "finished\n");
}

Sehle::Renderable *
SkinnedGeometry::show (Sehle::Graph *graph, Sehle::u32 contextmask)
{
	assert (!renderable);
	renderable = new Sehle::StaticMesh(graph, contextmask);
	rebuildRenderable (renderable);
	return renderable;
}

void
SkinnedGeometry::hide (Sehle::RenderableGroup *pgroup)
{
	assert (renderable);
	pgroup->removeChild (renderable);
	delete renderable;
	renderable = NULL;
}

bool
SkinnedGeometry::trace (const Elea::Line3f *mray, unsigned int mask, float *distance)
{
	float mindist = Elea::OMEGA_F;
	for (unsigned int i = 0; i < nfrags; i++) {
		Elea::f32 t;
		if (mray->getTriangleMeshIntersection (vanim[0], sizeof (vanim[0]), (const Elea::u32 *) &indices[frags[i].firstindex], frags[i].numindices, sizeof (indices[0]), &t, NULL)) {
			if (t < mindist) mindist = t;
		}
	}
	if (mindist < Elea::OMEGA_F) {
		if (distance) *distance = mindist;
		return true;
	}

	return false;
}

bool
SkinnedGeometry::trace (const Elea::Line3f *mray, unsigned int mask, const Elea::Matrix4x4f *me2us, float *distance, Elea::Vector3f *uscp)
{
	float bestdist = Elea::OMEGA_F;
	Elea::Vector3f bestcp(Elea::Vector3f0);
	for (unsigned int i = 0; i < nfrags; i++) {
		Elea::f32 t;
		Elea::Vector3f cp;
		if (mray->getTriangleMeshIntersection (vanim[0], sizeof (vanim[0]), (const Elea::u32 *) &indices[frags[i].firstindex], frags[i].numindices, sizeof (indices[0]), me2us, &t, &cp, NULL)) {
			if (t < bestdist) {
				bestdist = t;
				bestcp = cp;
			}
		}
	}
	if (bestdist < Elea::OMEGA_F) {
		if (distance) *distance = bestdist;
		if (uscp) *uscp = bestcp;
		return true;
	}

	return false;
}

void
SkinnedGeometry::applyMorph (Morph *morph, f32 s)
{
	MorphTarget *target0 = morph->getTarget0 ();
	MorphTarget *target1 = morph->getTarget1 ();
	if (!target0 || !target1) return;
	if ((target0->maxindex != target1->maxindex) || ((int) target0->maxindex >= nvertices)) return;
	float t = 1 - s;
	if (vbase && target0->vdata && target1->vdata && target0->indices) {
		for (u32 j = 0; j < target0->numindices; j++) {
			vbase[target0->indices[j]] = t * target0->vdata[j] + s * target1->vdata[j];
		}
	}
	if (nbase && target0->ndata && target1->ndata && target0->indices) {
		for (u32 j = 0; j < target0->numindices; j++) {
			nbase[target0->indices[j]] = t * target0->ndata[j] + s * target1->ndata[j];
		}
	}
	if (tbase && target0->tdata && target1->tdata && target0->indices) {
		for (u32 j = 0; j < target0->numindices; j++) {
			tbase[target0->indices[j]] = t * target0->tdata[j] + s * target1->tdata[j];
		}
	}
}

void
SkinnedGeometry::applyAnimation (Animation::KeyFrameAnimation *kfa, u32 f0, u32 f1, f32 s)
{
	if (vbase && kfa->vdata) {
		for (u32 k = 0; k < kfa->numindices; k++) {
			vbase[kfa->indices[k]] = (1 - s) * kfa->vdata[f0 * kfa->numindices + k] + s * kfa->vdata[f1 * kfa->numindices + k];
		}
	}
	if (nbase && kfa->ndata) {
		for (u32 k = 0; k < kfa->numindices; k++) {
			nbase[kfa->indices[k]] = (1 - s) * kfa->ndata[f0 * kfa->numindices + k] + s * kfa->ndata[f1 * kfa->numindices + k];
		}
	}
	if (tbase && kfa->tdata) {
		for (u32 k = 0; k < kfa->numindices; k++) {
			tbase[kfa->indices[k]] = (1 - s) * kfa->tdata[f0 * kfa->numindices + k] + s * kfa->tdata[f1 * kfa->numindices + k];
		}
	}
}

void
SkinnedGeometry::updateChildData (Thera::Node *removed)
{
	nmorphs = listChildrenOfType (Morph::type (), (Object ***) &morphs, removed);
	nanimations = listChildrenOfType (Animation::SkinAnimation::type (), (Object ***) &animations, removed);
}

} // Namespace Miletos

