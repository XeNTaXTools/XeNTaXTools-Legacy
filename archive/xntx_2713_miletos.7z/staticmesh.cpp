#define __MILETOS_SMESH_CPP__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2010
//

#include <elea/line.h>

#include <sehle/renderable.h>

#include "staticmesh.h"

namespace Miletos {

SMesh::SMesh (void)
: Item(HAS_CHILDREN), geometry(NULL)
{
}

SMesh::~SMesh (void)
{
}

static Object *
mesh_factory (void)
{
	return new SMesh();
}

const Object::Type *
SMesh::objectType (void)
{
	return type ();
}

const Object::Type *
SMesh::type (void)
{
	static Type *mytype = NULL;
	if (!mytype) mytype = new Type(Item::type (), "StaticMesh", "staticMesh", mesh_factory, 0, NULL);
	return mytype;
}

void
SMesh::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	Item::build (pnode, doc, ctx);

	buildAllAttributes (type (), ctx);

	for (Object *child = children; child; child = child->next) {
		if (child->isType (Geometry::type ())) {
			geometry = (Geometry *) child;
			break;
		}
	}
}

void
SMesh::release (void)
{
	geometry = NULL;
	Item::release ();
}

Object *
SMesh::childAdded (Thera::Node *cnode, Thera::Node *rnode)
{
	Object *child = Item::childAdded (cnode, rnode);
	Geometry *newgeometry = NULL;
	for (Object *c = children; c; c = c->next) {
		if (c->isType (Geometry::type ())) {
			newgeometry = (Geometry *) c;
			break;
		}
	}
	if (newgeometry != geometry) {
		if (geometry) {
			if (renderable) {
				geometry->hide ((Sehle::RenderableGroup *) renderable);
			}
			geometry = NULL;
		}
		geometry = newgeometry;
		if (renderable) {
			Sehle::Renderable *rchild = geometry->show (renderable->graph, 0xffffffff);
			if (rchild) ((Sehle::RenderableGroup *) renderable)->prependChild (rchild);
		}
	}
	return child;
}

void
SMesh::childRemoved (Thera::Node *cnode, Thera::Node *rnode)
{
	Geometry *newgeometry = NULL;
	for (Object *child = children; child; child = child->next) {
		if (child->isType (Geometry::type ()) && (child->node != rnode)) {
			newgeometry = (Geometry *) child;
			break;
		}
	}
	if (newgeometry != geometry) {
		if (geometry) {
			if (renderable) {
				geometry->hide ((Sehle::RenderableGroup *) renderable);
			}
			geometry = NULL;
		}
		geometry = newgeometry;
		if (renderable) {
			Sehle::Renderable *rchild = geometry->show (renderable->graph, 0xffffffff);
			if (rchild) ((Sehle::RenderableGroup *) renderable)->prependChild (rchild);
		}
	}
	Item::childRemoved (cnode, rnode);
}

void
SMesh::update (UpdateCtx *ctx, unsigned int flags)
{
	bbox.setEmpty ();
	// Update children
	for (Object *child = children; child; child = child->next) {
		if (flags || child->updateFlagIsSet (MODIFIED_STATE)) {
			child->invokeUpdate (ctx, flags);
		}
	}
	if (geometry) {
		bbox.grow (geometry->bbox);
	}
	Item::update (ctx, flags);
}

Sehle::Renderable *
SMesh::show (Sehle::Graph *graph, Sehle::u32 contextmask)
{
	Sehle::RenderableGroup *rgroup = new Sehle::RenderableGroup(graph, contextmask);
	if (geometry) {
		Sehle::Renderable *rchild = geometry->show (graph, contextmask);
		if (rchild) rgroup->prependChild (rchild);
	}
	return rgroup;
}

void
SMesh::hide (Sehle::RenderableGroup *pgroup)
{
	if (geometry) {
		geometry->hide ((Sehle::RenderableGroup *) renderable);
	}
}

Item *
SMesh::trace (const Elea::Line3f *wray, unsigned int mask, float *distance)
{
	if (geometry) {
		Elea::Line3f mray = _w2i.transform (*wray);
		if (geometry->trace (&mray, mask, distance)) {
			return this;
		}
	}

	return NULL;
}

} // Namespace Miletos
