#ifndef __MILETOS_MESH3DS_H__
#define __MILETOS_MESH3DS_H__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2011
//

#include <string>
#include <vector>

#include <miletos/helpers/datablock.h>
#include <miletos/geometry.h>

namespace Miletos {

class SD3Data : public DataBlock {
public:
	struct MGroup {
		std::string matname;
		std::vector<u16> faces;
	};

	struct Mesh {
		std::vector<Elea::Vector3f> vdata;
		std::vector<Elea::Vector2f> tdata;
		std::vector<u16> fdata;
		std::vector<MGroup> mgroups;
	};

	struct Object {
		std::string name;
		Mesh mesh;
	};

	struct Material {
		std::string name;
		Elea::Color4f ambient;
		Elea::Color4f diffuse;
		Elea::Color4f specular;
		float shininess;
		std::string filename;
		std::string opacitymap;
	};

	struct MData {
		std::vector<Material> materials;
		std::vector<Object> objects;
	};
private:
	SD3Data (const unsigned char *cdata, size_t csize, const char *url);
	virtual ~SD3Data (void);

	unsigned int parse (const unsigned char *cdata, size_t csize);
	unsigned int parseMAIN (const unsigned char *cdata, size_t csize);
	unsigned int parseMDATA (const unsigned char *cdata, size_t csize, MData& mdata);
	unsigned int parseOBJECT (const unsigned char *cdata, size_t csize, Object& obj);
	unsigned int parseMESH (const unsigned char *cdata, size_t csize, Mesh& mesh);
	unsigned int parseVERTICES (const unsigned char *cdata, size_t csize, Mesh& mesh);
	unsigned int parseFACES (const unsigned char *cdata, size_t csize, Mesh& mesh);
	unsigned int parseMGROUP (const unsigned char *cdata, size_t csize, MGroup& mgroup);
	unsigned int parseUV (const unsigned char *cdata, size_t csize, Mesh& mesh);
	unsigned int parseMATRIX (const unsigned char *cdata, size_t csize, Mesh& mesh);
	unsigned int parseMATERIAL (const unsigned char *cdata, size_t csize, Material &mat);
	unsigned int parseMAP (const unsigned char *cdata, size_t csize, std::string& filename);
	unsigned int parseCOLOR (const unsigned char *cdata, size_t csize, Elea::Color4f& color);
	unsigned int parsePERCENTAGE (const unsigned char *cdata, size_t csize, float& value);
public:
	MData mdata;

	static SD3Data *getSD3Data (const char *url);
	static SD3Data *getSD3Data (const unsigned char *cdata, size_t csize, const char *url);
};

class Geometry3DS : public StaticGeometry {
private:
    SD3Data *obj;

	struct Texture {
		std::string url;
		NRImage *pixels;
	};
	std::vector<Texture *> textures;

	// Object implementation
	virtual const Type *objectType (void);
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	virtual void set (const char *attrid, const char *val);
	// Geometry implementation
	virtual TextureInfo *getTextureInfo (unsigned int matidx, unsigned int texidx, unsigned int getimage);
	virtual u32 getMaterialInfo (MaterialInfo *mat, u32 matidx);
	// StaticGeometry implementation
	virtual Sehle::Material *getMaterial (int matidx, Sehle::Engine *engine);

	// Helpers
	void clear (void);
	void loadData (void);
public:
	Geometry3DS (void);

	// Type system
	static const Type *type (void);
};

} // Namespace Miletos

#endif
