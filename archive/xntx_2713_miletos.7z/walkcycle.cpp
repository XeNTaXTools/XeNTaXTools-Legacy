#define __MILETOS_WALKCYCLE_CPP__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2010
//

#include <stdio.h>

#include <libarikkei/token.h>

#include <elea/line.h>

#include "xml/base.h"
#include "animationgraph.h"
#include "figure.h"

#include "walkcycle.h"

namespace Miletos {

namespace Animation {

WalkCycle::WalkCycle (void)
: Source(0), graph(NULL), phase(0)
{
	memset (keyposesids, 0, sizeof (keyposesids));
	memset (keyposes, 0, sizeof (keyposes));
	memset (movements, 0, sizeof (movements));
}

static Object *
walkcycle_factory (void)
{
	return new WalkCycle();
}

const Object::Type *
WalkCycle::objectType (void)
{
	return type ();
}

const Object::Type *
WalkCycle::type (void)
{
	static Type *mytype = NULL;
	static const Attribute attrs[] = {
		{ "keyPoses", NULL, 0 },
		{ "phase", "0", 0 },
		{ "movements", NULL, 0 }
	};
	if (!mytype) mytype = new Type(Source::type (), "WalkCycle", "animation:walkCycle", walkcycle_factory, sizeof (attrs) / sizeof (attrs[0]), attrs);
	return mytype;
}

void
WalkCycle::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	Source::build (pnode, doc, ctx);

	buildAllAttributes (type (), ctx);
}

void
WalkCycle::release (void)
{
	clear (true, true);
	Source::release ();
}

void
WalkCycle::set (const char *attrid, const char *val)
{
	if (!strcmp (attrid, "keyPoses")) {
		clear (true, true);
		if (val) {
			Arikkei::TokenChar vtoken(val);
			Arikkei::TokenChar stoken(vtoken.strip ());
			Arikkei::TokenChar tokenz[6];
			int ntokenz = stoken.tokenize (tokenz, 6, true, true);
			if (ntokenz == 5) {
				for (int i = 0; i < 5; i++) {
					keyposesids[i] = tokenz[i].strdup ();
				}
			}
		}
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "phase")) {
		if (!XML::parseInteger (&phase, val)) phase = 0;
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "movements")) {
		float values[12];
		if (XML::parseNumbers (values, 12, val)) {
			for (int i = 0; i < 4; i++) {
				for (int j = 0; j < 3; j++) {
					movements[i][j] = values[3 * i + j];
				}
			}
		} else {
			memset (movements, 0, sizeof (movements));
		}
		requestUpdate (MODIFIED);
	} else {
		Source::set (attrid, val);
	}
}

void
WalkCycle::write (const char *attrid)
{
	if (!strcmp (attrid, "keyPoses")) {
		size_t len = 5;
		for (int i = 0; i < 5; i++) {
			if (!keyposesids[i]) return;
			len += strlen (keyposesids[i]);
		}
		char *c = (char *) malloc (len);
		int pos = 0;
		for (int i = 0; i < 5; i++) {
			if (i > 0) c[pos++] = ' ';
			strcpy (c + pos, keyposesids[i]);
			pos += strlen (keyposesids[i]);
		}
		node->setAttribute (attrid, c);
		free (c);
	} else if (!strcmp (attrid, "phase")) {
		node->setAttributeUint (attrid, phase);
	} else if (!strcmp (attrid, "movements")) {
		static const unsigned int len = 12 * 16 + 1;
		unsigned char c[len];
		unsigned int p = 0;
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 3; j++) {
				p += arikkei_dtoa_simple (c + p, len - p, movements[i][j], 6, 4, 0);
				c[p++] = ' ';
			}
		}
		c[p - 1] = 0;
		node->setAttribute (attrid, (const char *) c);
	} else {
		Source::write (attrid);
	}
}

void
WalkCycle::attachedObjectRelease (Object *attached, void *data)
{
	if (attached == graph) {
		clear (true, false);
		return;
	}
	for (int i = 0; i < 5; i++) {
		if (attached == keyposes[i]) {
			clear (true, false);
			return;
		}
	}
}

void
WalkCycle::attachedObjectModified (Object *attached, unsigned int flags, void *data)
{
	if (!isParent (attached)) requestUpdate (MODIFIED);
}

void
WalkCycle::attachToGraph (Graph *pgraph)
{
	clear (true, false);
	if (!pgraph) return;
	graph = pgraph;
	graph->attach (this);
	Pose *poses[5];
	for (int i = 0; i < 5; i++) {
		if (!keyposesids[i]) return;
		poses[i] = pgraph->lookupPose (keyposesids[i]);
		if (!poses[i]) return;
		if (!poses[i]->source) return;
		if (i > 0) {
			if (poses[i]->source != poses[0]->source) return;
			if (poses[i]->frametime < poses[i-1]->frametime) return;
		}
	}
	for (int i = 0; i < 5; i++) {
		keyposes[i] = poses[i];
		keyposes[i]->attach (this);
	}
}

void
WalkCycle::setKeyposeSid (int idx, const char *sid)
{
	if ((idx < 0) || (idx > 5)) return;
	clear (true, false);
	if (keyposesids[idx]) free (keyposesids[idx]);
	keyposesids[idx] = (sid) ? strdup (sid) : NULL;
}

void
WalkCycle::clear (unsigned int poses, unsigned int ids)
{
	if (graph) {
		graph->detach (this);
		graph = NULL;
	}
	if (poses) {
		for (int i = 0; i < 5; i++) {
			if (keyposes[i]) {
				keyposes[i]->detach (this);
				keyposes[i] = NULL;
			}
		}
	}
	if (ids) {
		for (int i = 0; i < 5; i++) {
			if (keyposesids[i]) {
				free (keyposesids[i]);
				keyposesids[i] = NULL;
			}
		}
	}
	requestUpdate (MODIFIED);
}

// Biped

Biped::Biped (void)
: Object(0), targetid(NULL), graphid(NULL), animationsid(NULL), target(NULL), graph(NULL), delta(0.0078125f), speed(Elea::Vector3f0)
{
}

static Object *
controller_factory (void)
{
	return new Biped();
}

const Object::Type *
Biped::objectType (void)
{
	return type ();
}

const Object::Type *
Biped::type (void)
{
	static Type *mytype = NULL;
	static const Attribute attrs[] = {
		{ "target", NULL, 0 },
		{ "graph", NULL, 0 },
		{ "animation", NULL, 0 },
		{ "delta", "0.0078125", 0 },
	};
	if (!mytype) mytype = new Type(Object::type (), "Animation:Biped", "animation:biped", controller_factory, sizeof (attrs) / sizeof (attrs[0]), attrs);
	return mytype;
}

void
Biped::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	Object::build (pnode, doc, ctx);

	buildAllAttributes (type (), ctx);

}

void
Biped::release (void)
{
	if (target) {
		target->detach (this);
		target = NULL;
	}
	if (targetid) {
		document->removeIdentityChangeListener (targetid, this);
		free (targetid);
		targetid = NULL;
	}
	if (graph) {
		graph->detach (this);
		graph = NULL;
	}
	if (graphid) {
		document->removeIdentityChangeListener (graphid, this);
		free (graphid);
		graphid = NULL;
	}
	if (animationsid) {
		free (animationsid);
		animationsid = NULL;
	}

	Object::release ();
}

void
Biped::set (const char *attrid, const char *val)
{
	if (!strcmp (attrid, "target")) {
		if (target) {
			target->detach (this);
			target = NULL;
		}
		if (targetid) {
			document->removeIdentityChangeListener (targetid, this);
			free (targetid);
			targetid = NULL;
		}
		if (val && (val[0] == '#') && val[1]) {
			targetid = strdup (val + 1);
			document->addIdentityChangeListener (targetid, this);
			Object *object = document->lookupObject (targetid);
			if (object && object->isType (Figure::type ())) {
				target = (Figure *) object;
				target->attach (this);
			}
		}
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "graph")) {
		if (graph) {
			graph->detach (this);
			graph = NULL;
		}
		if (graphid) {
			document->removeIdentityChangeListener (graphid, this);
			free (graphid);
			graphid = NULL;
		}
		if (val && (val[0] == '#') && val[1]) {
			graphid = strdup (val + 1);
			document->addIdentityChangeListener (graphid, this);
			Object *object = document->lookupObject (graphid);
			if (object && object->isType (Graph::type ())) {
				graph = (Graph *) object;
				graph->attach (this);
			}
		}
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "animation")) {
		if (animationsid) free (animationsid);
		animationsid = (val) ? strdup (val) : NULL;
		requestUpdate (MODIFIED);
	} else if (!strcmp (attrid, "delta")) {
		if (!XML::parseNumber (&delta, val)) delta = 0.0078125f;
		requestUpdate (MODIFIED);
	}
}

void
Biped::update (UpdateCtx *ctx, unsigned int flags)
{
	Object::update (ctx, flags);

	// fixme:
	// Think out, how exactly the attaching should be, especially as we need multiple skinanimations
}

void
Biped::identityAdded (Document *pdocument, const char *pidentity, Object *pobject)
{
	if (targetid && !strcmp (pidentity, targetid)) {
		if (target) {
			target->detach (this);
			target = NULL;
		}
		if (pobject->isType (Figure::type ())) {
			target = (Figure *) pobject;
			target->attach (this);
		}
	} else if (graphid && !strcmp (pidentity, graphid)) {
		if (graph) {
			graph->detach (this);
			graph = NULL;
		}
		if (pobject->isType (Graph::type ())) {
			graph = (Graph *) pobject;
			graph->attach (this);
		}
	}
	requestModified (MODIFIED);
}

void
Biped::identityRemoved (Document *pdocument, const char *pidentity)
{
	if (targetid && !strcmp (pidentity, targetid)) {
		if (target) {
			target->detach (this);
			target = NULL;
		}
	} else if (graphid && !strcmp (pidentity, graphid)) {
		if (graph) {
			graph->detach (this);
			graph = NULL;
		}
	}
	requestModified (MODIFIED);
}

void
Biped::attachedObjectRelease (Object *attached, void *data)
{
	if (attached == target) {
		target->detach (this);
		target = NULL;
	} else if (attached == graph) {
		graph->detach (this);
		graph = NULL;
	}
	requestUpdate (MODIFIED);
}

void
Biped::attachedObjectModified (Object *attached, unsigned int flags, void *data)
{
	// fixme: I am not exactly sure, if tree modification always sets MODIFIED as well
	// But we want to ignore CHILD and PARENT modified signals to cut potential loops if we are in same hirarchy
	if (flags & MODIFIED) requestUpdate (MODIFIED);
}

float
Biped::getS (float dT)
{
	if (!target) return 0;
	Item *item = (Item *) target;
	Elea::Vector3f dS = dT * speed;
	Elea::Line3f path(item->getI2W().getTranslation (), dS);
	float s;
	if (!document->root->trace (&path, 0x1, &s)) {
		// Did not hit
		return dS.length ();
	}
	// Did hit
	if (s > 0) {
		if (s > 1) {
			s = 1;
		} else {
			fprintf (stderr, "lala\n");
		}
		return s * dS.length ();
	}
	return 0;
}

} // Namespace Animation

} // Namespace Miletos
