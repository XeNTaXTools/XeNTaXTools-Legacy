#define __MILETOS_MESH_MD5_CPP__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2008-2009
//

static const int debug = 1;

#include <stdio.h>

#include <libarikkei/token.h>

#include <elea/geometry.h>

#include <sehle/commonmaterials.h>
#include <sehle/material-multipass-dns.h>

#include "uri.h"
#include "image.h"
#include "material.h"

#include "meshmd5.h"

namespace Miletos {

static const float DefaultScale = 0.01933f;

struct MD5Data
{
	struct Joint {
		std::string name;
		int parent;
		Orientation orientation;
		Elea::Matrix4x4f j2o;
	};
	std::vector<Joint> joints;

	struct JointMask {
		// fixme: Do it better way (Lauris)
		// Max 256 joints
		u32 m[8];
		JointMask (void) { for (int i = 0; i < 8; i++) m[i] = 0; }
		bool test (int joint) const { int p = joint / 32; int q = 1 << (joint % 32); return (m[p] & q) != 0; }
		void set (int joint) { int p = joint / 32; int q = 1 << (joint % 32); m[p] |= q; }
		friend JointMask operator| (const JointMask& a, const JointMask& b) { JointMask d; for (int i = 0; i < 8; i++) d.m[i] = a.m[i] | b.m[i]; return d; }
		friend JointMask operator& (const JointMask& a, const JointMask& b) { JointMask d; for (int i = 0; i < 8; i++) d.m[i] = a.m[i] & b.m[i]; return d; }
		friend bool operator|| (const JointMask& a, const JointMask& b) { for (int i = 0; i < 8; i++) if (a.m[i] || b.m[i]) return true; return false; }
		friend bool operator&& (const JointMask& a, const JointMask& b) { for (int i = 0; i < 8; i++) if (a.m[i] && b.m[i]) return true; return false; }
		friend bool operator== (const JointMask& a, const JointMask& b) { for (int i = 0; i < 8; i++) if (a.m[i] != b.m[i]) return false; return true; }
		int getNumJoints (void) const { int n = 0; for (int i = 0; i < 8; i++) for (u32 q = 0x80000000; q != 0; q = q >> 1) if (m[i] & q) n += 1; return n; }
	};

	struct Vertex {
		Elea::Vector2f texcoords;
		int firstweight;
		int numweights;
	};

	struct Triangle {
		int c[3];
		int njoints;
		JointMask joints;
	};

	struct Weight {
		int joint;
		float weight;
		Elea::Vector3f pos;
	};

	struct Mesh {
		std::string shader;
		std::vector<Vertex> vertices;
		std::vector<Triangle> triangles;
		std::vector<Weight> weights;
	};
	std::vector<Mesh> meshes;

	// Constructor
	MD5Data (const unsigned char *cdata, size_t csize, float scale);

	// Parsers
	void parseJoints (Arikkei::TokenLineChar& lt, float scale);
	void parseMesh (Arikkei::TokenLineChar& lt, float scale);
};

MD5Data::MD5Data (const unsigned char *cdata, size_t csize, float scale)
{
	Arikkei::TokenChar ft((const char *) cdata, csize);
	Arikkei::TokenLineChar lt(ft);
	while (!lt.eof ()) {
		Arikkei::TokenChar st(lt.strip ());
		if (st == "joints {") {
			parseJoints (lt, scale);
		} else if (st == "mesh {") {
			parseMesh (lt, scale);
		} else if (!st.isEmpty ()) {
			Arikkei::TokenChar tokenz[2];
			st.tokenize (tokenz, 2, true, true);
			if (tokenz[0] == "MD5Version ") {
			} else if (tokenz[0] == "numJoints") {
			} else if (tokenz[0] == "numMeshes ") {
			} else {
				fprintf (stderr, "MD5Data::MD5Data: Invalid line %s\n", (const char *) st);
			}
		}
		lt++;
	}
}

void
MD5Data::parseJoints (Arikkei::TokenLineChar& lt, float scale)
{
	Arikkei::TokenChar tokenz[16];
	lt++;
	Arikkei::TokenChar st(lt.strip ());
	while (!lt.eof () && (st != "}")) {
		// Parse name
		int ntokenz = st.tokenize (tokenz, 3, Arikkei::TokenChar("\""), true);
		if (ntokenz == 3) {
			Joint j;
			j.name = (const char *) tokenz[1];
			if ((debug > 0) && strchr (j.name.c_str (), '#')) {
 				fprintf (stderr, ".");
			}
			st = tokenz[2].strip ();
			int ntokenz = st.tokenize (tokenz, 16, Arikkei::TokenChar(" \t()"), true);
			if (ntokenz >= 7) {
				j.parent = tokenz[0];
				float x = tokenz[1];
				float y = tokenz[2];
				float z = tokenz[3];
				j.orientation.p.set (scale * -y, scale * x, scale * z);
				x = tokenz[4];
				y = tokenz[5];
				z = tokenz[6];
				float w = 1 - x * x - y * y - z * z;
				if (w < 0) w = 0;
				w = sqrt (w);
				j.orientation.q.set (y, -x, -z, w);
				j.j2o.setTranslation (j.orientation.p);
				j.j2o.setRotation (j.orientation.q);
				joints.push_back (j);
			}
		}
		lt++;
		st = lt.strip ();
	}
}
void
MD5Data::parseMesh (Arikkei::TokenLineChar& lt, float scale)
{
	meshes.push_back(Mesh());
	Mesh& mesh(meshes.back ());
	Arikkei::TokenChar tokenz[16];
	lt++;
	Arikkei::TokenChar st(lt.strip ());
	while (!lt.eof () && (st != "}")) {
		int ntokenz = st.tokenize (tokenz, 2, Arikkei::TokenChar(" \t"), true);
		if (ntokenz >= 2) {
			if (tokenz[0] == "shader") {
				mesh.shader = (const char *) tokenz[1].strip("\"");
			} else if (tokenz[0] == "vert") {
				Arikkei::TokenChar dt(tokenz[1]);
				ntokenz = dt.tokenize (tokenz, 16, Arikkei::TokenChar(" \t()"), true);
				Vertex v;
				v.texcoords.set (tokenz[1], tokenz[2]);
				v.firstweight = tokenz[3];
				v.numweights = tokenz[4];
				mesh.vertices.push_back (v);
			} else if (tokenz[0] == "tri") {
				Arikkei::TokenChar dt(tokenz[1]);
				ntokenz = dt.tokenize (tokenz, 16, Arikkei::TokenChar(" \t()"), true);
				Triangle t;
				t.c[0] = tokenz[1];
				t.c[1] = tokenz[3];
				t.c[2] = tokenz[2];
				mesh.triangles.push_back (t);
			} else if (tokenz[0] == "weight") {
				Arikkei::TokenChar dt(tokenz[1]);
				ntokenz = dt.tokenize (tokenz, 16, Arikkei::TokenChar(" \t()"), true);
				Weight w;
				w.joint = tokenz[1];
				w.weight = tokenz[2];
				float x = tokenz[3];
				float y = tokenz[4];
				float z = tokenz[5];
				w.pos.set (scale * -y, scale * x, scale * z);
				mesh.weights.push_back (w);
			} else {
				fprintf (stderr, "MD5Data::parseMesh: Invalid line %s\n", (const char *) st);
			}
		} else if (ntokenz > 0) {
			fprintf (stderr, "MD5Data::parseMesh: Invalid line %s\n", (const char *) st);
		}
		lt++;
		st = lt.strip ();
	}
	// Built joint masks for triangles
	for (size_t i = 0; i < mesh.triangles.size (); i++) {
		mesh.triangles[i].njoints = 0;
		for (int j = 0; j < 3; j++) {
			int v = mesh.triangles[i].c[j];
			for (int k = 0; k < mesh.vertices[v].numweights; k++) {
				int jidx = mesh.weights[mesh.vertices[v].firstweight + k].joint;
				if (!mesh.triangles[i].joints.test (jidx)) mesh.triangles[i].njoints += 1;
				mesh.triangles[i].joints.set (jidx);
			}
		}
	}
}

// GeometryMD5

struct GeometryMD5::Shader {
	std::string name;
	NR::PixBlock diffuse;
	NR::PixBlock normal;
	NR::PixBlock specular;
};

GeometryMD5::~GeometryMD5 (void)
{
	for (size_t i = 0; i < shaders.size (); i++) delete shaders[i];
	delete bdata;
}

static Object *
geometrymd5_factory (void)
{
	return new GeometryMD5();
}

const Object::Type *
GeometryMD5::objectType (void)
{
	return type ();
}

const Object::Type *
GeometryMD5::type (void)
{
	static Type *mytype = NULL;
	static const Attribute attrs[] = {
		{ "source", NULL, 0 }
	};
	if (!mytype) mytype = new Type(SkinnedGeometry::type (), "GeometryMD5", "geometryMD5", geometrymd5_factory, sizeof (attrs) / sizeof (attrs[0]), attrs);
	return mytype;
}

void
GeometryMD5::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	SkinnedGeometry::build (pnode, doc, ctx);

	buildAllAttributes (type (), ctx);

}

void
GeometryMD5::release (void)
{
	SkinnedGeometry::release ();
}

void
GeometryMD5::set (const char *attrid, const char *val)
{
	if (!strcmp (attrid, "source")) {
		clear ();
		delete bdata;
		bdata = NULL;
		URI::URLHandler *handler = URI::getHandler (val);
		if (handler) {
			loadData (handler, val);
			handler->unRef ();
		}
		requestUpdate (MODIFIED | MESH_DEFINITION_MODIFIED);
	} else {
		SkinnedGeometry::set (attrid, val);
	}
}

void
GeometryMD5::update (UpdateCtx *ctx, unsigned int flags)
{
	SkinnedGeometry::update (ctx, flags);
}

Sehle::Material *
GeometryMD5::getMaterial (int matidx, Sehle::Engine *engine)
{
	Sehle::MaterialMultipassDNS *mdns = NULL;
	// Try to load diffuse map
	if (!shaders[matidx]->diffuse.isEmpty ()) {
		mdns = Sehle::MaterialMultipassDNS::newMaterialMultipassDNS (engine, shaders[matidx]->name.c_str ());
		mdns->setMap (Sehle::MaterialMultipassDNS::COLOR, NULL, &shaders[matidx]->diffuse.pb);
		if (!shaders[matidx]->normal.isEmpty ()) mdns->setMap (Sehle::MaterialMultipassDNS::NORMAL, NULL, &shaders[matidx]->normal.pb);
		if (!shaders[matidx]->specular.isEmpty ()) mdns->setMap (Sehle::MaterialMultipassDNS::SPECULAR, NULL, &shaders[matidx]->specular.pb);
		return mdns;
	}
	Sehle::WireMaterial *wmat = Sehle::WireMaterial::newWireMaterial (engine, "test");
	wmat->setColor (Elea::Color4fTransparent);
	wmat->setDrawTriangles ();
	return wmat;
}

// fixme: Set textures up properly (Lauris)

TextureInfo *
GeometryMD5::getTextureInfo (unsigned int matidx, unsigned int texidx, unsigned int getimage)
{
	if (texidx >= ntextures) return NULL;
	TextureInfo *tex = new TextureInfo();
	tex->urn = strdup (shaders[texidx]->name.c_str ());
	if (getimage) {
		tex->image = nr_image_new ();
		NRPixBlock *px = &shaders[texidx]->diffuse.pb;
		nr_pixblock_setup_extern (&tex->image->pixels, px->mode, px->area.x0, px->area.y0, px->area.x1, px->area.y1, NR_PIXBLOCK_PX(px), px->rs, false, false);
	}
	return tex;
}

u32
GeometryMD5::getMaterialInfo (MaterialInfo *mat, u32 matidx)
{
	if (matidx >= (u32) nmaterials) return false;
	if (mat) {
		mat->type = MaterialInfo::TEXTURE;
		mat->id = shaders[matidx]->name.c_str ();
		mat->diffuseColor = Elea::Color4fGreen;
		mat->specularColor = Elea::Color4fBlack;
		mat->specularShininess = 1;
		mat->diffuseTexture = matidx;
		mat->normalTexture = -1;
		mat->specularTexture = -1;
	}
	return true;
}

static bool
load_image (NR::PixBlock& pxb, URI::URLHandler *handler, const char *imgname)
{
	size_t isize;
	const unsigned char *idata = handler->mmapDataRelative (imgname, &isize);
	if (debug) fprintf (stderr, "meshmd5.cpp:load_image: %s %s\n", (idata) ? "successfully mapped" : "cannot map", imgname);
	if (!idata) return false;
	bool retval = Image::load (&pxb.pb, idata, isize) != 0;
	handler->munmapData (idata);
	return retval;
}

void
GeometryMD5::loadData (URI::URLHandler *handler, const char *url)
{
	float scale = DefaultScale;

	clear ();
	for (size_t i = 0; i < shaders.size (); i++) delete shaders[i];
	shaders.clear ();

	size_t csize;
	const unsigned char *cdata = handler->mmapData (url, &csize);
	if (!cdata) return;

	if (bdata) delete bdata;
	bdata = new MD5Data (cdata, csize, scale);

	// Number of materials
	ntextures = (int) bdata->meshes.size ();
	nmaterials = (int) bdata->meshes.size ();
	for (size_t i = 0; i < bdata->meshes.size (); i++) {
		Shader *shader = new Shader();
		shader->name = bdata->meshes[i].shader;
		std::string mfname = shader->name;
		load_image (shader->diffuse, handler, mfname.c_str ());
		if (shader->diffuse.isEmpty ()) {
			mfname = shader->name;
			mfname += ".png";
			load_image (shader->diffuse, handler, mfname.c_str ());
		}
		if (shader->diffuse.isEmpty ()) {
			mfname = shader->name;
			mfname += ".tga";
			load_image (shader->diffuse, handler, mfname.c_str ());
		}
		if (shader->diffuse.isEmpty ()) {
			mfname = shader->name;
			mfname += "_d.tga";
			load_image (shader->diffuse, handler, mfname.c_str ());
		}
		if (shader->diffuse.isEmpty ()) {
			mfname = shader->name;
			mfname += "_c.tga";
			load_image (shader->diffuse, handler, mfname.c_str ());
		}
		if (!shader->diffuse.isEmpty ()) {
			// Try normal
			mfname = shader->name;
			mfname += "_local.tga";
			load_image (shader->normal, handler, mfname.c_str ());
			// Try specular
			mfname = shader->name;
			mfname += "_spec.tga";
			load_image (shader->specular, handler, mfname.c_str ());
			if (shader->specular.isEmpty ()) {
				mfname = shader->name;
				mfname += "_s.tga";
				load_image (shader->specular, handler, mfname.c_str ());
			}
		}
		shaders.push_back (shader);
	}

	// PBones
	setNumBones ((int) bdata->joints.size ());
	for (size_t i = 0; i < bdata->joints.size (); i++) {
		Elea::Matrix4x4f o2p;
		if (bdata->joints[i].parent >= 0) {
			bdata->joints[bdata->joints[i].parent].j2o.invertNormalized (&o2p);
		}
		Elea::Matrix4x4f j2p = o2p *  bdata->joints[i].j2o;
		setBone ((int) i, bdata->joints[i].name.c_str (), bdata->joints[i].parent, j2p);
	}
	// Update bone matrixes
	initializeBoneMatrixes ();

	// Calculate the number of primitives
	int nvertices = 0;
	int nindices = 0;
	int nweights = 0;
	int nweights2 = 0;
	for (size_t i = 0; i < bdata->meshes.size (); i++) {
		nvertices += (int) bdata->meshes[i].vertices.size ();
		nindices += 3 * (int) bdata->meshes[i].triangles.size ();
		nweights += (int) bdata->meshes[i].weights.size ();
		for (size_t j = 0; j < bdata->meshes[i].vertices.size (); j++) {
			nweights2 += bdata->meshes[i].vertices[j].numweights;
		}
	}
	// Initialize buffers
	setNumVertices (nvertices, true, true, true, true);
	setNumIndices (nindices);
	setNumWeights (nweights2);
	setNumFrags ((int) bdata->meshes.size ());

	int vidx = 0;
	int widx = 0;
	int iidx = 0;

	for (size_t i = 0; i < bdata->meshes.size (); i++) {
		frags[i].visible = 1;
		frags[i].matidx = (int) i;
		frags[i].firstindex = iidx;
		for (size_t j = 0; j < bdata->meshes[i].triangles.size (); j++) {
			for (int k = 0; k < 3; k++) {
				indices[iidx] = vidx + bdata->meshes[i].triangles[j].c[k];
				iidx += 1;
			}
		}
		frags[i].numindices = iidx - frags[i].firstindex;
		for (size_t j = 0; j < bdata->meshes[i].vertices.size (); j++) {
			wcounts[vidx] = bdata->meshes[i].vertices[j].numweights;
			Elea::Vector3f p = Elea::Vector3f0;
			for (int k = 0; k < bdata->meshes[i].vertices[j].numweights; k++) {
				weights[widx].bone = bdata->meshes[i].weights[bdata->meshes[i].vertices[j].firstweight + k].joint;
				weights[widx].weight = bdata->meshes[i].weights[bdata->meshes[i].vertices[j].firstweight + k].weight;
				Elea::Vector3f q = bdata->meshes[i].weights[bdata->meshes[i].vertices[j].firstweight + k].pos;
				p += weights[widx].weight * bdata->joints[weights[widx].bone].j2o.transformPoint3 (q);
				widx += 1;
			}
			vbase[vidx] = p;
			xbase[vidx][0] = bdata->meshes[i].vertices[j].texcoords[0];
			xbase[vidx][1] = 1 - bdata->meshes[i].vertices[j].texcoords[1];
			vidx += 1;
		}
	}

#if 0
	// Calculate normals
	for (int i = 0; i < nvertices; i++) nbase[i] = Elea::Vector3f0;
	for (size_t i = 0; i < frags.size (); i++) {
		for (int j = 0; j < frags[i].numindices; j += 3) {
			for (int k = 0; k < 3; k++) {
				int idx0 = indices[frags[i].firstindex + j + (k + 0) % 3];
				int idx1 = indices[frags[i].firstindex + j + (k + 1) % 3];
				int idx2 = indices[frags[i].firstindex + j + (k + 2) % 3];
				Elea::Vector3f v0(vbase[idx1] - vbase[idx0]);
				Elea::Vector3f v1(vbase[idx2] - vbase[idx0]);
				Elea::Vector3f vq(v0 + v1);
				v0.normalizeSelf ();
				vq.normalizeSelf ();
				nbase[idx0] += v0 * vq;
			}
		}
	}
	// Calculate tangents
	std::vector<Elea::Vector3f> t;
	t.resize (nvertices);
	for (int i = 0; i < nvertices; i++) t[i] = Elea::Vector3f0;
	for (size_t i = 0; i < frags.size (); i++) {
		for (int j = 0; j < frags[i].numindices; j += 3) {
			for (int k = 0; k < 3; k++) {
				int idx0 = indices[frags[i].firstindex + j + (k + 0) % 3];
				int idx1 = indices[frags[i].firstindex + j + (k + 1) % 3];
				int idx2 = indices[frags[i].firstindex + j + (k + 2) % 3];
				Elea::Vector3f v0(vbase[idx1] - vbase[idx0]);
				Elea::Vector3f v1(vbase[idx2] - vbase[idx0]);
				Elea::Vector3f vq(v0 + v1);
				// v0.normalizeSelf ();
				// vq.normalizeSelf ();
				Elea::Vector2f t0(tbase[idx1] - tbase[idx0]);
				Elea::Vector2f t1(tbase[idx2] - tbase[idx0]);
				// if (fabs (t0[1]) > 0.01 && fabs (t1[1]) > 0.01) continue;
				// Ts * t0.x + Tt * t0.y = v0
				// Ts * t1.x + Tt * t1.y = v1
				// D = t0.x * t1.y - t1.x * t0.y
				// Ds = v0 * t1.y - v1 * t0.y
				// Dt = t0.x * v1 - t1.x * v0
				float D = t0[Elea::X] * t1[Elea::Y] - t1[Elea::X] * t0[Elea::Y];
				Elea::Vector3f Ds = v0 * t1[Elea::Y] - v1 * t0[Elea::Y];
				Elea::Vector3f Dt = t0[Elea::X] * v1 - t1[Elea::X] * v0;
				Elea::Vector3f Ts = Ds / D;
				Elea::Vector3f Tt = Dt / D;
				Elea::Vector3f cv0 = Ts * t0[Elea::X] + Tt * t0[Elea::Y];
				Elea::Vector3f cv1 = Ts * t1[Elea::X] + Tt * t1[Elea::Y];
				Elea::Vector3f q0(v0 - cv0);
				Elea::Vector3f q1(v1 - cv1);
				if ((q0.length2 () > 0.001) || (q1.length2 () > 0.001)) {
					fprintf (stderr, "-");
				}
				Elea::Vector3f normal = nbase[idx0].normalize ();
				Elea::Vector3f tangent = Ts.normalize ();
				Elea::Vector3f bitangent = normal * tangent;
				float weight = sin (Elea::Vector3f::angle (v0, vq));
				Elea::Vector3f lt(tangent * weight);
				if (Elea::Vector3f::scalarProduct (t[idx0], lt) < 0) {
					fprintf (stderr, "=");
				}
				t[idx0] += lt;
			}
		}
	}
	for (int i = 0; i < nvertices; i++) {
		Elea::Vector3f normal = nbase[i].normalize ();
		Elea::Vector3f tangent = t[i];
		Elea::Vector3f bitangent = normal * tangent;
		bitangent.normalizeSelf ();
		tangent = bitangent * normal;
		// binormal.normalizeSelf ();
		// tangent = binormal * normal;
		Elea::Matrix4x4f tspace;
		for (int j = 0; j < 3; j++) {
			tspace[0 + j] = tangent[j];
			tspace[4 + j] = bitangent[j];
			tspace[8 + j] = normal[j];
		}
		Elea::Quaternionf q = tspace.getRotationQuaternion ();
		q.normalizeSelf ();
		Elea::Matrix4x4f r;
		r.setRotation (q);
		float dd = q[0] * q[0] + q[1] * q[1] + q[2] * q[2];
		if (dd > 1) dd = 1;
		q[3] = sqrt (1 - dd);
		float x =      2 * (q[0] * q[2] + q[1] * q[3]);
		float y =      2 * (q[1] * q[2] - q[0] * q[3]);
		float z = 1 - 2 * (q[0] * q[0] + q[1] * q[1]);
		Elea::Vector3f d(normal - Elea::Vector3f(x, y, z));
		// Elea::Vector3f d(normal - r.getColVector3 (2));
		if (d.length2 () > 0.001) {
			fprintf (stderr, ".");
		}
		// nbase[i].set (q[0], q[1], q[2]);
	}
#endif

	// Invalidate source
	delete bdata;
	bdata = NULL;
	handler->munmapData (cdata);

	// Calculate normals
	calculateNormals (true);
	Elea::Geometry::calculateTangents (tbase[0], sizeof (tbase[0]), vbase[0], sizeof (vbase[0]), nbase[0], sizeof (nbase[0]), xbase[0], sizeof (xbase[0]), nvertices, indices, nindices, false);

	// Calculate bone bounding boxes
	initializeBoneBBoxes ();

	// Update bone status
	updateBoneStatus ();

	requestUpdate (MODIFIED | ANIMATION_MODIFIED);
}

} // Namespace Miletos

