#ifndef __MILETOS_IMAGE_H__
#define __MILETOS_IMAGE_H__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2007-2008
//

#include <miletos/types.h>

#include <libnr/nr-pixblock.h>

namespace Miletos {

namespace Image {

//
// Load images in OpenGL layout - i.e. 0,0 of actual image is lower left
//
// Pixblock has to be set up and will be replaced if load successfully
//

unsigned int load (NRPixBlock *pxb, const unsigned char *cdata, size_t csize);
unsigned int load (NRPixBlock *pxb, const char *url);

// maxsize -1 keeps the original size
unsigned int load (NRPixBlock *pxb, const char *url, int maxsize, unsigned int forcepowerof2);

unsigned int loadBMP (NRPixBlock *pxb, const unsigned char *cdata, size_t csize);
unsigned int loadBMP (NRPixBlock *pxb, const unsigned char *cdata, size_t csize, const char id[]);
unsigned int loadTGA (NRPixBlock *pxb, const unsigned char *cdata, size_t csize);
unsigned int loadJPEG (NRPixBlock *pxb, const unsigned char *cdata, size_t csize);
unsigned int loadPNG (NRPixBlock *pxb, const unsigned char *cdata, size_t csize);

unsigned int writePNG (const NRPixBlock *pxb, unsigned char *cdata, u32 csize);
unsigned int writePNG (const NRPixBlock *pxb, const char *filename);

} // Namespace Image

} // Namespace Miletos

#endif

