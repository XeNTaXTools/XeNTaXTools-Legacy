#define __MILETOS_MESHBSP_CPP__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2007
//

static const int debug = 1;

static const float DefaultScale = 0.01933f;

#ifdef WIN32
#define _CRT_SECURE_NO_DEPRECATE 1
#endif

#include <stdio.h>

#include <sehle/GLee.h>
#include <sehle/renderable.h>

#include <string>

#include <elea/plane.h>
#include <elea/color.h>

#include <sehle/engine.h>
#include <sehle/graph.h>
#include <sehle/material.h>
#include <sehle/rendercontext.h>

#include "helpers/datablock.h"
#include "uri.h"
#include "image.h"
#include "primitives.h"
#include "shaders-dict.h"

#include "meshbsp.h"

namespace Miletos {

// BSPData

class BSPData : public DataBlock {
private:
	// Mapped file
	size_t csize;
	const unsigned char *cdata;

	BSPData (URI::URLHandler *handler, const char *url);
	virtual ~BSPData (void);

	// Helpers
	void parse (void);
	void clear (void);
public:
	URI::URLHandler *handler;

	// BSP Data containers
	enum eLumps {
		kEntities = 0,     // Stores player/object positions, etc...
		kTextures,         // Stores texture information
		kPlanes,           // Stores the splitting planes
		kNodes,            // Stores the BSP nodes
		kLeafs,            // Stores the leafs of the nodes
		kLeafFaces,        // Stores the leaf's indices into the faces
		kLeafBrushes,      // Stores the leaf's indices into the brushes
		kModels,           // Stores the info of world models
		kBrushes,          // Stores the brushes info (for collision)
		kBrushSides,       // Stores the brush surfaces info
		kVertices,         // Stores the level vertices
		kMeshVerts,        // Stores the model vertices offsets
		kShaders,          // Stores the shader files (blending, anims..)
		kFaces,            // Stores the faces for the level
		kLightmaps,        // Stores the lightmaps for the level
		kLightVolumes,     // Stores extra world lighting information
		kVisData,          // Stores PVS and cluster info (visibility)
		NUM_LUMPS          // A constant to store the number of lumps
	};

	struct Lump {
		i32 offset;
		i32 length;
	};
	const Lump *lumps;

	struct tBSPHeader
	{
		i32 strID;     // This should always be 'IBSP'
		i32 version;       // This should be 0x2e for Quake 3 files
	}; 
	const tBSPHeader *header;

	struct tBSPTexture {
		i8 strName[64];   // The name of the texture w/o the extension 
		u32 flags;          // The surface flags (unknown) 
		u32 contents;       // The content flags (unknown)
	};
	int ntextures;
	const tBSPTexture *textures;

	struct tBSPPlane {
		f32 vNormal[3];     // Plane normal. 
		f32 d;              // The plane distance from origin 
	};
	int nplanes;
	const tBSPPlane *planes;

	struct tBSPNode {
		i32 plane;      // The index into the planes array 
		i32 front;      // The child index for the front node 
		i32 back;       // The child index for the back node 
		i32 mins[3];    // The bounding box min position. 
		i32 maxs[3];    // The bounding box max position. 
	};
	int nnodes;
	const tBSPNode *nodes;

	struct tBSPLeaf {
		i32 cluster;           // The visibility cluster 
		i32 area;              // The area portal 
		i32 mins[3];           // The bounding box min position 
		i32 maxs[3];           // The bounding box max position 
		i32 leafface;          // The first index into the face array 
		i32 numOfLeafFaces;    // The number of faces for this leaf 
		i32 leafBrush;         // The first index for into the brushes 
		i32 numOfLeafBrushes;  // The number of brushes for this leaf 
	};
	int nleaves;
	const tBSPLeaf *leaves;

	int nleaffaces;
	const i32 *leaffaces;

	int nleafbrushes;
	const i32 *leafbrushes;

	struct tBSPModel {
		f32 min[3];           // The min position for the bounding box
		f32 max[3];           // The max position for the bounding box. 
		i32 faceIndex;          // The first face index in the model 
		i32 numOfFaces;         // The number of faces in the model 
		i32 brushIndex;         // The first brush index in the model 
		i32 numOfBrushes;       // The number brushes for the model
	}; 

	struct tBSPBrush {
		i32 brushSide;           // The starting brush side for the brush 
		i32 numOfBrushSides;     // Number of brush sides for the brush
		i32 textureID;           // The texture index for the brush
	}; 
	int nbrushes;
	const tBSPBrush *brushes;

	struct tBSPBrushSide {
		i32 plane;              // The plane index
		i32 textureID;          // The texture index
	};
	int nbrushsides;
	const tBSPBrushSide *brushsides;

	struct tBSPVertex {
		f32 vPosition[3];      // (x, y, z) position. 
		f32 vTextureCoord[2];  // (u, v) texture coordinate
		f32 vLightmapCoord[2]; // (u, v) lightmap coordinate
		f32 vNormal[3];        // (x, y, z) normal vector
		u8 color[4];           // RGBA color for the vertex 
	};
	int nvertices;
	const tBSPVertex *vertices;

	int nmeshverts;
	const i32 *meshverts;

	struct tBSPShader {
		i8 strName[64];     // The name of the shader file 
		i32 brushIndex;       // The brush index for this shader 
		i32 unknown;          // This is 99% of the time 5
	}; 

	struct tBSPFace {
		i32 texture;          // The index into the texture array 
		i32 effect;           // The index for the effects (or -1 = n/a) 
		i32 type;             // 1=polygon, 2=patch, 3=mesh, 4=billboard 
		i32 firstvertex;      // The index into this face's first vertex 
		i32 numOfVerts;       // The number of vertices for this face 
		i32 firstmeshvert;    // The index into the first meshvertex 
		i32 nmeshverts;       // The number of mesh vertices 
		i32 lightmap;         // The texture index for the lightmap 
		i32 lMapCorner[2];    // The face's lightmap corner in the image 
		i32 lMapSize[2];      // The size of the lightmap section 
		f32 lMapPos[3];       // The 3D origin of lightmap. 
		f32 lMapBitsets[2][3]; // The 3D space for s and t unit vectors. 
		f32 vNormal[3];       // The face normal. 
		i32 size[2];          // The bezier patch dimensions. 
	};
	int nfaces;
	const tBSPFace *faces;

	struct tBSPLightmap {
		u8 imageBits[128][128][3];   // The RGB data in a 128x128 image
	};
	int nlightmaps;
	const tBSPLightmap *lightmaps;

	struct tBSPVisData {
		i32 numOfClusters;   // The number of clusters
		i32 bytesPerCluster; // Bytes (8 bits) in the cluster's bitset
		u8 *pBitsets;      // Array of bytes holding the cluster vis.
	};
	const tBSPVisData *visdata;
	const u8 *visbits;

	struct tBSPLights {
		u8 ambient[3];     // This is the ambient color in RGB
		u8 directional[3]; // This is the directional color in RGB
		u8 direction[2];   // The direction of the light: [phi,theta] 
	}; 

	static BSPData *getBSPData (const char *url);
};

BSPData::BSPData (URI::URLHandler *phandler, const char *purl)
: DataBlock (purl, "BSPData"), csize (0), cdata(NULL), handler (phandler)
{
	clear ();
	if (handler) {
		handler->ref ();
		cdata = handler->mmapData ((const unsigned char *) purl, &csize);
		if (cdata) {
			parse ();
		}
	}
}

BSPData::~BSPData (void)
{
	if (handler) {
		if (cdata) {
			handler->munmapData (cdata);
			cdata = NULL;
			csize = 0;
		}
		handler->unRef ();
	}
}

BSPData *
BSPData::getBSPData (const char *purl)
{
	BSPData *bsp = NULL;
	if (purl) {
		bsp = (BSPData *) lookupDataBlock (purl, "BSPData");
		if (bsp) return bsp;
		URI::URLHandler *handler = URI::getHandler (purl);
		if (handler) {
			bsp = new BSPData (handler, purl);
			handler->unRef ();
		}
	}
	return bsp;
}

void
BSPData::clear (void)
{
	visbits = NULL;
	visdata = NULL;
	nlightmaps = 0;
	lightmaps = NULL;
	nfaces = 0;
	faces = NULL;
	nmeshverts = 0;
	meshverts = NULL;
	nvertices = 0;
	vertices = NULL;
	nbrushsides = 0;
	brushsides = NULL;
	nbrushes = 0;
	brushes = NULL;
	nleafbrushes = 0;
	leafbrushes = NULL;
	nleaffaces = 0;
	leaffaces = NULL;
	nleaves = 0;
	leaves = NULL;
	nnodes = 0;
	nodes = NULL;
	nplanes = 0;
	planes = NULL;
	ntextures = 0;
	textures = NULL;
	header = NULL;
	lumps = NULL;
}

void
BSPData::parse (void)
{
	const unsigned char *mdata = cdata;
	size_t msize = csize;

	size_t mpos = 0;

	// Header
	header = (tBSPHeader *) (mdata + mpos);
	mpos += sizeof (tBSPHeader);
	if ((header->strID != 0x50534249) || (header->version != 0x2e)) {
		clear ();
		return;
	}

	// Map lumps
	lumps = (const Lump *) (mdata + mpos);

	// Map everything
	// Entities
	// Textures
	ntextures = lumps[kTextures].length / sizeof (tBSPTexture);
	textures = (tBSPTexture *) (mdata + lumps[kTextures].offset);
	// Planes
	nplanes = lumps[kPlanes].length / sizeof (tBSPPlane);
	planes = (const tBSPPlane *) (mdata + lumps[kPlanes].offset);
	// Nodes
	nnodes = lumps[kNodes].length / sizeof (tBSPNode);
	nodes = (const tBSPNode *) (mdata + lumps[kNodes].offset);
	// Leaves
	nleaves = lumps[kLeafs].length / sizeof (tBSPLeaf);
	leaves = (const tBSPLeaf *) (mdata + lumps[kLeafs].offset);
	// Leaffaces
	nleaffaces = lumps[kLeafFaces].length / sizeof (Elea::i32);
	leaffaces = (const i32 *) (mdata + lumps[kLeafFaces].offset);
	// Leafbrushes
	nleafbrushes = lumps[kLeafBrushes].length / sizeof (Elea::i32);
	leafbrushes = (const i32 *) (mdata + lumps[kLeafBrushes].offset);
	// Models
	// Brushes
	nbrushes = lumps[kBrushes].length / sizeof (tBSPBrush);
	brushes = (const tBSPBrush *) (mdata + lumps[kBrushes].offset);
	// Brushsides
	nbrushsides = lumps[kBrushSides].length / sizeof (tBSPBrushSide);
	brushsides = (const tBSPBrushSide *) (mdata + lumps[kBrushSides].offset);
	// Vertices
	nvertices = lumps[kVertices].length / sizeof (tBSPVertex);
	vertices = (const tBSPVertex *) (mdata + lumps[kVertices].offset);
	// Meshverts
	nmeshverts = lumps[kMeshVerts].length / sizeof (Elea::i32);
	meshverts = (const i32 *) (mdata + lumps[kMeshVerts].offset);
	// Shaders
	// Faces
	nfaces = lumps[kFaces].length /sizeof (tBSPFace);
	faces = (const tBSPFace *) (mdata + lumps[kFaces].offset);
	// LightMaps
	nlightmaps = lumps[kLightmaps].length / sizeof (tBSPLightmap);
	lightmaps = (const tBSPLightmap *) (mdata + lumps[kLightmaps].offset);
	// LigthVolumes
	// Visibility
	visdata = (const tBSPVisData *) (mdata + lumps[kVisData].offset);
	visbits = visdata->pBitsets;

	if (debug) {
		fprintf (stderr, "Num Vertices: %d\n", nvertices);
		fprintf (stderr, "Num Faces: %d\n", nfaces);
		fprintf (stderr, "Num Nodes: %d\n", nnodes);
		fprintf (stderr, "Num Leaves: %d\n", nleaves);
	}
}

// BSPMesh

class BSPMaterial : public Sehle::Material {
public:
	enum Programs { AMBIENT, HILIGHT, GBUF, NUM_PROGRAMS };
	enum AmbientUniforms { AMBIENT_HAS_COLOR, AMBIENT_HAS_LIGHTMAP, AMBIENT_COLOR_SAMPLER, AMBIENT_LIGHTMAP_SAMPLER, AMBIENT_OPACITY, NUM_AMBIENT_UNIFORMS };
	enum AmbientAttributes { AMBIENT_LIGHTMAP_COORDS, NUM_AMBIENT_ATTRIBUTES };
	enum HilightUniforms { HILIGHT_HAS_SHADOW, HILIGHT_HAS_COLOR, HILIGHT_ACCUMULATION_SAMPLER, HILIGHT_SHADOW_SAMPLER, HILIGHT_DENSITY_SAMPLER, HILIGHT_COLOR_SAMPLER, HILIGHT_OPACITY, HILIGHT_FLATTEN, NUM_HILIGHT_UNIFORMS };
	enum GBufUniforms { GBUF_HAS_COLOR, GBUF_HAS_LIGHTMAP, GBUF_COLOR_SAMPLER, GBUF_LIGHTMAP_SAMPLER, NUM_GBUF_UNIFORMS };
	enum GBufAttributes { GBUF_LIGHTMAP_COORDS, NUM_GBUF_ATTRIBUTES };
private:
	Sehle::Program *programs[NUM_PROGRAMS];
	Sehle::Texture *_dmap;
	int _dchannel;
	Sehle::Texture *_lmap;
	int _lchannel;
	// Rendering state
	int _loc_texcoord;
	// Material implementation
	virtual void bindClass (Sehle::RenderContext *ctx, Sehle::u32 flags);
	virtual void bindInstance (Sehle::RenderContext *ctx, Sehle::u32 flags, bool isfirstofclass);
	virtual void reset (Sehle::RenderContext *ctx);
	virtual void render (Sehle::RenderContext *ctx, Sehle::VertexBuffer *vb, Sehle::VertexBuffer *tb, const Sehle::u32 *indices, Sehle::u32 nindices, Sehle::u32 flags);
	virtual u32 defaultRenderStage (void) { return Sehle::Graph::SOLID; }
	// Constructor
	BSPMaterial (Sehle::Engine *engine, const char *id);
	// Destructor
	~BSPMaterial (void);
public:
	// Access
	void setDiffuseMap (const char *id, const NR::PixBlock *dpxb);
	void setLightMap (const char *id, const NR::PixBlock *dpxb);
	// Static constructor
	static BSPMaterial *newBSPMaterial (Sehle::Engine *engine, const char *id);
};

class StaticMeshBSP : public Sehle::StaticMesh {
private:
	// Renderable implementation
	virtual void display (Sehle::RenderContext *ctx);
public:
	struct Node {
		// Boundign box
		Elea::Cuboid3f bbox;
		// Division plane
		Elea::Plane3f plane;
		// Nodes
		int frontnode;
		int backnode;
	};
	std::vector<Node> nodes;
	struct Leaf {
		// Boundign box
		Elea::Cuboid3f bbox;
		// Mask of clusters visible from here
		const Sehle::u8 *visibility;
		// List of fragments
		int firstfrag;
		int nfrags;
	};
	std::vector<Leaf> leaves;
	// Constructor
	StaticMeshBSP (Sehle::Graph *graph, Sehle::u32 contextMask) : StaticMesh(graph, contextMask) {}
	// Destructor
	virtual ~StaticMeshBSP (void) {}
};

void
StaticMeshBSP::display (Sehle::RenderContext *ctx)
{
	// fixme: Test visibility
	for (size_t i = 0; i < leaves.size (); i++) {
		if (leaves[i].bbox.testPosition (ctx->viewSpace) != Elea::ALL_OUT) {
			for (int j = 0; j < leaves[i].nfrags; j++) {
				int fidx = leaves[i].firstfrag + j;
				Sehle::Material *mat = materials[frags[fidx].matidx];
				if (mat != NULL) {
					ctx->scheduleRender (vbuffer, vbuffer, ibuffer, frags[fidx].first, frags[fidx].nindices, mat, &transform, (mat->isTransparent ()) ? Sehle::Graph::TRANSPARENT : Sehle::Graph::SOLID);
				} else {
					static int shown = 0;
					if (shown < 10) {
						fprintf (stderr, "StaticMesh::display - No material %d (frag %d)\n", frags[fidx].matidx, (int) i);
						shown += 1;
					}
				}
			}
		}
	}
}

// MeshBSP

MeshBSP::MeshBSP (void)
: Item(0), bdata(NULL), _npixblocks(0), _pixblocks(NULL)
{
}

static Object *
meshbsp_factory (void)
{
	return new MeshBSP();
}

const Object::Type *
MeshBSP::objectType (void)
{
	return type ();
}

const Object::Type *
MeshBSP::type (void)
{
	static Type *mytype = NULL;
	static const Attribute attrs[] = {
		{ "source", NULL, 0 }
	};
	if (!mytype) mytype = new Type(Item::type (), "MeshBSP", "meshBSP", meshbsp_factory, sizeof (attrs) / sizeof (attrs[0]), attrs);
	return mytype;
}

void
MeshBSP::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	Item::build (pnode, doc, ctx);

	buildAllAttributes (type (), ctx);

}

void
MeshBSP::release (void)
{
	resetInternalData ();
	clear ();
	Item::release ();
}

void
MeshBSP::set (const char *attrid, const char *val)
{
	if (!strcmp (attrid, "source")) {
		resetInternalData ();
		clear ();
		if (val) {
			bdata = BSPData::getBSPData (val);
			if (bdata) loadData ();
		}
		requestUpdate (MODIFIED | Geometry::MESH_DEFINITION_MODIFIED);
	} else {
		Item::set (attrid, val);
	}
}

void
MeshBSP::update (UpdateCtx *ctx, unsigned int flags)
{
	// Update bbox
	bbox.setEmpty ();
	if (!vertices.empty ()) {
		bbox.grow (vertices[0].p, (Elea::u32) vertices.size (), sizeof (Vertex), &ctx->i2w);
	}
	if (flags & Geometry::MESH_DEFINITION_MODIFIED) {
		if (renderable) {
			buildMesh ((Sehle::StaticMesh *) renderable);
		}
	}
	// Update leaf bboxes
	// fixme: implement?
	// Update renderable if needed
	if (renderable) {
		StaticMeshBSP *meshbsp = (StaticMeshBSP *) renderable;
		for (size_t i = 0; i < leaves.size (); i++) {
			meshbsp->leaves[i].bbox = ctx->i2w.transform (leaves[i].bbox);
		}
	}
	// Superclass implementation
	Item::update (ctx, flags);
}

Sehle::Renderable *
MeshBSP::show (Sehle::Graph *graph, Sehle::u32 contextmask)
{
	StaticMeshBSP *mesh = new StaticMeshBSP(graph, contextmask);

	buildMesh (mesh);

	return mesh;
}

Item *
MeshBSP::trace (const Elea::Line3f *wray, unsigned int mask, float *distance)
{
	float p0, p1;
	if (bbox.getIntersection (*wray, p0, p1)) {
		if (distance) *distance = p0;
		return this;
	}
	return NULL;
}

void
MeshBSP::clear (void)
{
	if (bdata) {
		bdata->unRef ();
		bdata = NULL;
	}
}

void
MeshBSP::resetInternalData (void)
{
	delete[] _pixblocks;
	_npixblocks = 0;
	vertices.clear ();
	indices.clear ();
	faces.clear ();
	leaves.clear ();
	materials.clear ();
}

int
MeshBSP::findLeaf (int nidx, const Elea::Vector3f *p)
{
	float scale = DefaultScale;

	const BSPData::tBSPNode *node = &bdata->nodes[nidx];
	Elea::Plane3f plane(bdata->planes[node->plane].vNormal, scale * bdata->planes[node->plane].d);
	if (plane.getPosition (*p) >= 0) {
		// In front of plane
		nidx = node->front;
	} else {
		// Back of plane
		nidx = node->back;
	}
	if (nidx < 0) return -(nidx + 1);
	return findLeaf (nidx, p);
}

bool
MeshBSP::isVisible (int from, int what)
{
	if (from < 0) return false;
	if (what < 0) return false;
	i32 fromcluster = bdata->leaves[from].cluster;
	i32 whatcluster = bdata->leaves[what].cluster;
	if (fromcluster < 0) return false;
	if (whatcluster < 0) return false;
	unsigned char vbyte = bdata->visbits[(fromcluster * bdata->visdata->bytesPerCluster) + (whatcluster / 8)];
	return (vbyte & (1 << (whatcluster & 7))) != 0;
}

void
MeshBSP::buildMesh (Sehle::StaticMesh *mesh)
{
	if (!bdata || vertices.empty () || indices.empty ()) {
		mesh->resizeMaterials (0);
		mesh->resizeFragments (0);
		return;
	}

	// Build Sehle mesh object
	// Determine the required number of sehle vertices
	static const int nxsubdivs = 3;
	static const int nysubdivs = 3;
	int npatchvertices = 0;
	for (int i = 0; i < bdata->nfaces; i++) {
		if (bdata->faces[i].type == 2) {
			// Patch mesh
			int nxpatches = (bdata->faces[i].size[0] - 1) / 2;
			int nypatches = (bdata->faces[i].size[1] - 1) / 2;
			npatchvertices += nxpatches * (nxsubdivs - 1) * nypatches * (nysubdivs - 1);
		}
	}
	// Set up vertices
	mesh->vbuffer = mesh->graph->engine->getVertexBuffer (id);
	static const u32 stride = 3 + 3 + 2 + 2 + 4;
	mesh->vbuffer->setUp ((Sehle::u32) vertices.size (), stride);
	mesh->vbuffer->setOffset (Sehle::VertexBuffer::COORDINATES, 0);
	mesh->vbuffer->setOffset (Sehle::VertexBuffer::NORMALS, 3);
	mesh->vbuffer->setOffset (Sehle::VertexBuffer::TEXCOORDS, 6);
	mesh->vbuffer->setOffset (Sehle::VertexBuffer::COLORS, 10);
	mesh->vbuffer->map (Sehle::VertexBuffer::WRITE);
	mesh->vbuffer->setValues (0, (Sehle::u32) vertices.size (), 0, vertices[0].p, 3, 14 * sizeof (Sehle::f32));
	mesh->vbuffer->setValues (0, (Sehle::u32) vertices.size (), 3, vertices[0].n, 3, 14 * sizeof (Sehle::f32));
	mesh->vbuffer->setValues (0, (Sehle::u32) vertices.size (), 6, vertices[0].td, 2, 14 * sizeof (Sehle::f32));
	mesh->vbuffer->setValues (0, (Sehle::u32) vertices.size (), 8, vertices[0].tl, 2, 14 * sizeof (Sehle::f32));
	mesh->vbuffer->setValues (0, (Sehle::u32) vertices.size (), 10, vertices[0].c, 4, 14 * sizeof (Sehle::f32));
	mesh->vbuffer->unMap ();

	// Set up indices
	mesh->ibuffer = mesh->graph->engine->getIndexBuffer (id);
	// Calculate required size
	size_t nindices = 0;
	for (size_t i = 0; i < leaves.size (); i++) {
		for (size_t j = 0; j < leaves[i].lists.size (); j++) {
			for (size_t k = 0; k < leaves[i].lists[j].faces.size (); k++) nindices += faces[leaves[i].lists[j].faces[k]].nindices;
		}
	}
	mesh->ibuffer->resize ((Sehle::u32) nindices);

	// Set up textures
	mesh->resizeMaterials ((Sehle::u32) materials.size ());
	for (size_t i = 0; i < materials.size (); i++) {
		BSPMaterial *bspmat = BSPMaterial::newBSPMaterial (mesh->graph->engine, NULL);
		int difid = materials[i].textureidx - 1;
		if ((difid >= 0) && !_pixblocks[difid].isEmpty ()) {
			// bspmat->setDiffuseMap (materials[i].id.c_str (), &_pixblocks[difid]);
			bspmat->setDiffuseMap (NULL, &_pixblocks[difid]);
		}
		int lmapid = materials[i].lmapidx - 1;
		if (lmapid >= 0) {
			const BSPData::tBSPLightmap *lm = &bdata->lightmaps[lmapid];
			char c[256];
			sprintf (c, "_lmap_%d", lmapid);
			std::string lmstrid(id);
			lmstrid += c;
			NR::PixBlock lmpix(NR::PixBlock::R8G8B8, 0, 0, 128, 128, (unsigned char *) lm->imageBits, 3 * 128, false, false);
			// bspmat->setLightMap (lmstrid.c_str (), &lmpix);
			bspmat->setLightMap (NULL, &lmpix);
		}
		mesh->setMaterial ((Sehle::i32) i, bspmat);
	}

	// Set up fragments
	size_t nfrags = 0;
	for (size_t i = 0; i < leaves.size (); i++) nfrags += leaves[i].lists.size ();
	mesh->resizeFragments ((Sehle::u32) nfrags);
	// Set up leaves
	StaticMeshBSP *meshbsp = (StaticMeshBSP *) mesh;
	meshbsp->leaves.resize (leaves.size ());
	int fragn = 0;
	int indexn = 0;
	mesh->ibuffer->map (Sehle::IndexBuffer::WRITE);
	for (size_t i = 0; i < leaves.size (); i++) {
		// fixme: This has to be transformed
		meshbsp->leaves[i].bbox = leaves[i].bbox;
		meshbsp->leaves[i].visibility = bdata->visbits + i * bdata->visdata->bytesPerCluster;
		meshbsp->leaves[i].firstfrag = fragn;
		for (size_t j = 0; j < leaves[i].lists.size (); j++) {
			mesh->frags[fragn].matidx = leaves[i].lists[j].matidx;
			mesh->frags[fragn].first = indexn;
			for (size_t k = 0; k < leaves[i].lists[j].faces.size (); k++) {
				Face& face(faces[leaves[i].lists[j].faces[k]]);
				if (face.nindices > 0) {
					for (int l = 0; l < face.nindices; l += 3) {
						mesh->ibuffer->indices[indexn + l + 0] = face.vertexbase + indices[face.firstindex + l + 0];
						mesh->ibuffer->indices[indexn + l + 1] = face.vertexbase + indices[face.firstindex + l + 2];
						mesh->ibuffer->indices[indexn + l + 2] = face.vertexbase + indices[face.firstindex + l + 1];
					}
					indexn += face.nindices;
				}
			}
			mesh->frags[fragn].nindices = indexn - mesh->frags[fragn].first;
			fragn += 1;
		}
		meshbsp->leaves[i].nfrags = fragn - meshbsp->leaves[i].firstfrag;
	}
	mesh->ibuffer->unMap ();
}

bool
MeshBSP::loadData (void)
{
	float scale = DefaultScale;

	resetInternalData ();

	// NULL Source is valid
	if (!bdata || !bdata->nvertices) return true;

	// Initialize vertices
	vertices.resize (bdata->nvertices);
	for (int i = 0; i < bdata->nvertices; i++) {
		// Write down static vertices
		vertices[i].p.set (scale * Elea::Vector3f(bdata->vertices[i].vPosition));
		vertices[i].n.set (bdata->vertices[i].vNormal);
		vertices[i].td.set (bdata->vertices[i].vTextureCoord[0], 1 - bdata->vertices[i].vTextureCoord[1]);
		vertices[i].tl.set (bdata->vertices[i].vLightmapCoord);
		vertices[i].c.set (bdata->vertices[i].color[0] / 255.0f, bdata->vertices[i].color[1] / 255.0f, bdata->vertices[i].color[2] / 255.0f, bdata->vertices[i].color[3] / 255.0f);
	}

	// Create material buffer
	int ntexids = bdata->ntextures + 1;
	int nlmapids = bdata->nlightmaps + 1;
	int nvisualids = ntexids * nlmapids;
	std::vector<int> vis2mat;
	vis2mat.resize (nvisualids);
	for (int i = 0; i < nvisualids; i++) vis2mat[i] = -1;

	// Create index buffer
	indices.resize (bdata->nmeshverts);
	for (int i = 0; i < bdata->nmeshverts; i++) {
		// Write static indices
		indices[i] = bdata->meshverts[i];
	}

	// Initalize faces
	faces.resize (bdata->nfaces);
	for (int i = 0; i < bdata->nfaces; i++) {
		faces[i].matidx = 0;
		faces[i].vertexbase = 0;
		faces[i].firstindex = 0;
		faces[i].nindices = 0;
	}
	for (int i = 0; i < bdata->nfaces; i++) {
		const BSPData::tBSPFace &face(bdata->faces[i]);
		if ((face.type == 1) || (face.type == 3) || (face.type == 2)) {
			// Valid geometric face
			int texid = face.texture + 1;
			if (texid < 0) texid = 0;
			if (texid > bdata->ntextures) texid = bdata->ntextures;
			int lmapid = face.lightmap + 1;
			if (lmapid < 0) lmapid = 0;
			if (lmapid > bdata->nlightmaps) lmapid = bdata->nlightmaps;
			int visualid = texid * nlmapids + lmapid;
			if (vis2mat[visualid] < 0) {
				// Have to initialize this material
				vis2mat[visualid] = (int) materials.size ();
				Material m;
				char c[256];
				sprintf (c, "_%d_%d", texid, lmapid);
				m.id = std::string (id) + c;
				m.textureidx = texid;
				m.lmapidx = lmapid;
				materials.push_back (m);
			}
			faces[i].matidx = vis2mat[visualid];
			if (face.type == 2) {
				// Patch
			} else {
				// Geometry
				faces[i].vertexbase = face.firstvertex;
				faces[i].firstindex = face.firstmeshvert;
				if (faces[i].firstindex >= bdata->nmeshverts) {
					fprintf (stderr, "jama\n");
				}
				faces[i].nindices = face.nmeshverts;
			}
		}
	}

	// Initialize leaves
	leaves.resize (bdata->nleaves);
	// Iterate over leaves
	std::vector<FaceList> lists;
	lists.resize (nvisualids);
	for (int i = 0; i < nvisualids; i++) lists[i].matidx = i;
	int nrenderedindices = 0;
	for (int i = 0; i < bdata->nleaves; i++) {
		const BSPData::tBSPLeaf &bspleaf(bdata->leaves[i]);
		leaves[i].bbox.setEmpty ();
		leaves[i].bbox.grow (scale * Elea::Vector3f((float) bspleaf.mins[0], (float) bspleaf.mins[1], (float) bspleaf.mins[2]));
		leaves[i].bbox.grow (scale * Elea::Vector3f((float) bspleaf.maxs[0], (float) bspleaf.maxs[1], (float) bspleaf.maxs[2]));
		for (int j = 0; j < nvisualids; j++) lists[j].faces.clear ();
		for (int j = 0; j < bspleaf.numOfLeafFaces; j++) {
			int faceidx = bdata->leaffaces[bspleaf.leafface + j];
			Face &face(faces[faceidx]);
			if (face.nindices > 0) {
				// Geometry face
				lists[face.matidx].matidx = face.matidx;
				lists[face.matidx].faces.push_back (faceidx);
				nrenderedindices += face.nindices;
			}
		}
		for (int j = 0; j < nvisualids; j++) {
			if (!lists[j].faces.empty ()) {
				leaves[i].lists.push_back (lists[j]);
			}
		}
	}

	// Load images
	_pixblocks = new NR::PixBlock[bdata->ntextures];
	for (int i = 0; i < bdata->ntextures; i++) {
		std::string bspname(bdata->textures[i].strName);
		std::string imgname(bspname + ".tga");
		size_t isize;
		const unsigned char *idata = bdata->handler->mmapDataRelative (imgname.c_str (), &isize);
		if (!idata) {
			imgname = bspname + ".jpg";
			idata = bdata->handler->mmapDataRelative (imgname.c_str (), &isize);
		}
		if (!idata) {
			imgname = bspname + ".png";
			idata = bdata->handler->mmapDataRelative (imgname.c_str (), &isize);
		}
		unsigned int loaded = false;
		if (idata) {
			loaded = Image::load (&_pixblocks[i].pb, idata, isize);
		}
		if (loaded) {
			if (debug) fprintf (stderr, "Successfully loaded texture image: %s\n", bspname.c_str ());
		} else {
			if (debug) fprintf (stderr, "Cannot load texture image: %s\n", bspname.c_str ());
		}
	}
	return true;
}

// BSPMaterial

// static Sehle::u32 bspmid = 0;

static const char bspvshader[] =
"attribute vec4 texcoord;\n"
"varying vec4 tci;\n"
"void main () {\n"
"    gl_FrontColor = gl_Color;\n"
"    tci = texcoord;\n"
"    gl_Position = ftransform ();\n"
"}\n";
static const size_t bspvshaderlen = sizeof (bspvshader);

static const char bspfshader[] =
" uniform sampler2D dmap, lmap;\n"
" uniform int hasdmap, haslmap;\n"
"varying vec4 tci;\n"
"void main () {\n"
"    vec4 color = gl_Color;\n"
"    if (hasdmap != 0) color = texture2D (dmap, tci.st);\n"
"    if (haslmap != 0) color = 2.0 * color * texture2D (lmap, tci.pq);\n"
"    color.a = 1.0;\n"
"    gl_FragColor = color;\n"
"}\n";
static const size_t bspfshaderlen = sizeof (bspfshader);

BSPMaterial::BSPMaterial (Sehle::Engine *engine, const char *id)
: Sehle::Material (engine, id, engine->getClassId (Sehle::Engine::MATERIAL, "Miletos::MaterialBSP")),
_dmap(NULL), _dchannel(-1), _lmap(NULL), _lchannel(-1),
_loc_texcoord(-1)
{
	// Get programs
	programs[AMBIENT] = engine->getProgram("Miletos::BSPMaterial::AmbientProgram");
	programs[HILIGHT] = engine->getProgram("Miletos::BSPMaterial::HilightProgram");
	programs[GBUF] = engine->getProgram("Miletos::BSPMaterial::GBufProgram");
	// Build ambient program
	if (!programs[AMBIENT]->built) {
		static const char *vnames[] = { "Miletos::BSPMaterial::Vertex" };
		static const char *vfiles[] = { "lightmap-vertex.txt" };
		static const char *fnames[] = { "Miletos::BSPMaterial::Ambient::Fragment" };
		static const char *ffiles[] = { "lightmap-ambient-fragment.txt" };
		static const char *unames[] = { "hasColor", "hasLmap", "colorSampler", "lmapSampler", "opacity" };
		static const char *anames[] = { "lmapCoords" };
		programs[AMBIENT]->build (0, NULL, NULL, 0, NULL, NULL, sizeof (unames) / sizeof (unames[0]), unames, sizeof (anames) / sizeof (anames[0]), anames);
		Sehle::Shader *shader = engine->getShader (vnames[0]);
		if (!shader->built) {
			size_t csize;
			const unsigned char *cdata = getMap_Miletos (vfiles[0], &csize);
			shader->build (Sehle::Shader::VERTEX, (const char *) cdata, csize);
		}
		programs[AMBIENT]->addVertexShaderGrabRef (shader);
		shader = engine->getShader (fnames[0]);
		if (!shader->built) {
			size_t csize;
			const unsigned char *cdata = getMap_Miletos (ffiles[0], &csize);
			shader->build (Sehle::Shader::FRAGMENT, (const char *) cdata, csize);
		}
		programs[AMBIENT]->addFragmentShaderGrabRef (shader);
	}
	// Build hilight program
	if (!programs[HILIGHT]->built) {
		// static const char *hilightvnames[] = { "Miletos::BSPMaterial::Hilight::Vertex" };
		// static const char *hilightvfiles[] = { "../miletos/lightmap-vertex.txt" };
		static const char *hilightfnames[] = { "Sehle::hilightColor", "Sehle::exposure" };
		static const char *hilightffiles[] = { "hilightColor.txt", "exposure.txt" };
		static const char *hilightunames[] = { "hasShadow", "hasColor", "accumulateSampler", "shadowSampler", "densitySampler", "colorSampler", "flatten", "opacity" };
		programs[HILIGHT]->build (0, NULL, NULL, sizeof (hilightfnames) / sizeof (hilightfnames[0]), hilightfnames, hilightffiles,
			sizeof (hilightunames) / sizeof (hilightunames[0]), hilightunames, 0, NULL);
		Sehle::Shader *shader = engine->getShader ("Miletos::BSPMaterial::Vertex");
		if (!shader->built) {
			size_t csize;
			const unsigned char *cdata = getMap_Miletos ("lightmap-vertex.txt", &csize);
			shader->build (Sehle::Shader::VERTEX, (const char *) cdata, csize);
		}
		programs[HILIGHT]->addVertexShaderGrabRef (shader);
		shader = engine->getShader ("Miletos::BSPMaterial::Hilight::Fragment");
		if (!shader->built) {
			size_t csize;
			const unsigned char *cdata = getMap_Miletos ("lightmap-hilight-fragment.txt", &csize);
			shader->build (Sehle::Shader::FRAGMENT, (const char *) cdata, csize);
		}
		programs[HILIGHT]->addFragmentShaderGrabRef (shader);
	}
	// Build gbuffer program
	if (!programs[GBUF]->built) {
		static const char *vnames[] = { "Miletos::BSPMaterial::GBuf::Vertex" };
		static const char *vfiles[] = { "lightmap-gbuf-vertex.txt" };
		static const char *fnames[] = { "Miletos::BSPMaterial::GBuf::Fragment" };
		static const char *ffiles[] = { "lightmap-gbuf-fragment.txt" };
		static const char *unames[] = { "hasColor", "hasLmap", "colorSampler", "lmapSampler" };
		static const char *anames[] = { "lmapCoords" };
		programs[GBUF]->build (0, NULL, NULL, 0, NULL, NULL, sizeof (unames) / sizeof (unames[0]), unames, sizeof (anames) / sizeof (anames[0]), anames);
		Sehle::Shader *shader = engine->getShader (vnames[0]);
		if (!shader->built) {
			size_t csize;
			const unsigned char *cdata = getMap_Miletos (vfiles[0], &csize);
			shader->build (Sehle::Shader::VERTEX, (const char *) cdata, csize);
		}
		programs[GBUF]->addVertexShaderGrabRef (shader);
		shader = engine->getShader (fnames[0]);
		if (!shader->built) {
			size_t csize;
			const unsigned char *cdata = getMap_Miletos (ffiles[0], &csize);
			shader->build (Sehle::Shader::FRAGMENT, (const char *) cdata, csize);
		}
		programs[GBUF]->addFragmentShaderGrabRef (shader);
	}
}

BSPMaterial::~BSPMaterial (void)
{
	if (_dmap) _dmap->unRef ();
	if (_lmap) _lmap->unRef ();
	programs[AMBIENT]->unRef ();
	programs[HILIGHT]->unRef ();
	programs[GBUF]->unRef ();
}

void
BSPMaterial::bindClass (Sehle::RenderContext *ctx, Sehle::u32 flags)
{
	if (flags & Sehle::RenderContext::HILIGHT) {
		glUseProgram (programs[HILIGHT]->getHandle ());
	} else if (flags & Sehle::RenderContext::GBUFFER){
		glUseProgram (programs[GBUF]->getHandle ());
	} else {
		glUseProgram (programs[AMBIENT]->getHandle ());
	}
}

void
BSPMaterial::bindInstance (Sehle::RenderContext *ctx, Sehle::u32 flags, bool isfirstofclass)
{
	if (flags & Sehle::RenderContext::HILIGHT) {
		if (_dmap) {
			if (isfirstofclass) {
				_dchannel = ctx->allocateTexture (false);
			} else {
				BSPMaterial *prev = (BSPMaterial *) ctx->material;
				if (prev->_dchannel >= 0) {
					// Channel is already reserved
					_dchannel = prev->_dchannel;
				} else {
					// Allocate new texture channel
					_dchannel = ctx->allocateTexture (0);
				}
			}
			if (_dchannel >= 0) _dmap->bind (_dchannel);
		} else {
			if (!isfirstofclass) {
				BSPMaterial *prev = (BSPMaterial *) ctx->material;
				if (prev->_dchannel >= 0) {
					// Release channel
					ctx->releaseTexture (prev->_dchannel);
				}
			}
		}
		if (ctx->accumulatedcolorchannel >= 0) {
			programs[HILIGHT]->setUniform1i (HILIGHT_ACCUMULATION_SAMPLER, ctx->accumulatedcolorchannel);
		}
		programs[HILIGHT]->setUniform1i (HILIGHT_HAS_SHADOW, (ctx->shadowdepthchannel[0] >= 0) ? 1 : 0);
		if (ctx->shadowdepthchannel[0] >= 0) {
			programs[HILIGHT]->setUniform1i (HILIGHT_SHADOW_SAMPLER, ctx->shadowdepthchannel[0]);
		}
		if (ctx->shadowdensitychannel >= 0) {
			programs[HILIGHT]->setUniform1i (HILIGHT_DENSITY_SAMPLER, ctx->shadowdensitychannel);
		}
		programs[HILIGHT]->setUniform1i (HILIGHT_HAS_COLOR, (_dmap && (_dchannel >= 0)) ? 1 : 0);
		programs[HILIGHT]->setUniform1i (HILIGHT_COLOR_SAMPLER, (_dchannel >= 0) ? _dchannel : 0);
		programs[HILIGHT]->setUniform1f (HILIGHT_OPACITY, 1.0f);
		programs[HILIGHT]->setUniform1i (HILIGHT_FLATTEN, (flags & Sehle::RenderContext::RGBI) ? 0 : 1);
	} else if (flags & Sehle::RenderContext::GBUFFER) {
		if (_dmap) {
			if (isfirstofclass) {
				_dchannel = ctx->allocateTexture (false);
			} else {
				BSPMaterial *prev = (BSPMaterial *) ctx->material;
				if (prev->_dchannel >= 0) {
					// Channel is already reserved
					_dchannel = prev->_dchannel;
				} else {
					// Allocate new texture channel
					_dchannel = ctx->allocateTexture (0);
				}
			}
			if (_dchannel >= 0) _dmap->bind (_dchannel);
		} else {
			if (!isfirstofclass) {
				BSPMaterial *prev = (BSPMaterial *) ctx->material;
				if (prev->_dchannel >= 0) {
					// Release channel
					ctx->releaseTexture (prev->_dchannel);
				}
			}
		}
		if (_lmap) {
			if (isfirstofclass) {
				_lchannel = ctx->allocateTexture (false);
			} else {
				BSPMaterial *prev = (BSPMaterial *) ctx->material;
				if (prev->_lchannel >= 0) {
					// Channel is already reserved
					_lchannel = prev->_lchannel;
				} else {
					// Allocate new texture channel
					_lchannel = ctx->allocateTexture (0);
				}
			}
			if (_lchannel >= 0) _lmap->bind (_lchannel);
		} else {
			if (!isfirstofclass) {
				BSPMaterial *prev = (BSPMaterial *) ctx->material;
				if (prev->_lchannel >= 0) {
					// Release channel
					ctx->releaseTexture (prev->_lchannel);
				}
			}
		}
		programs[GBUF]->setUniform1i (GBUF_HAS_COLOR, (_dmap && (_dchannel >= 0)) ? 1 : 0);
		programs[GBUF]->setUniform1i (GBUF_COLOR_SAMPLER, (_dchannel >= 0) ? _dchannel : 0);
		programs[GBUF]->setUniform1i (GBUF_HAS_LIGHTMAP, (_lmap && (_lchannel >= 0)) ? 1 : 0);
		programs[GBUF]->setUniform1i (GBUF_LIGHTMAP_SAMPLER, (_lchannel >= 0) ? _lchannel : 0);
	} else {
		if (_dmap) {
			if (isfirstofclass) {
				_dchannel = ctx->allocateTexture (false);
			} else {
				BSPMaterial *prev = (BSPMaterial *) ctx->material;
				if (prev->_dchannel >= 0) {
					// Channel is already reserved
					_dchannel = prev->_dchannel;
				} else {
					// Allocate new texture channel
					_dchannel = ctx->allocateTexture (0);
				}
			}
			if (_dchannel >= 0) _dmap->bind (_dchannel);
		} else {
			if (!isfirstofclass) {
				BSPMaterial *prev = (BSPMaterial *) ctx->material;
				if (prev->_dchannel >= 0) {
					// Release channel
					ctx->releaseTexture (prev->_dchannel);
				}
			}
		}
		if (_lmap) {
			if (isfirstofclass) {
				_lchannel = ctx->allocateTexture (false);
			} else {
				BSPMaterial *prev = (BSPMaterial *) ctx->material;
				if (prev->_lchannel >= 0) {
					// Channel is already reserved
					_lchannel = prev->_lchannel;
				} else {
					// Allocate new texture channel
					_lchannel = ctx->allocateTexture (0);
				}
			}
			if (_lchannel >= 0) _lmap->bind (_lchannel);
		} else {
			if (!isfirstofclass) {
				BSPMaterial *prev = (BSPMaterial *) ctx->material;
				if (prev->_lchannel >= 0) {
					// Release channel
					ctx->releaseTexture (prev->_lchannel);
				}
			}
		}
		programs[AMBIENT]->setUniform1i (AMBIENT_HAS_COLOR, (_dmap && (_dchannel >= 0)) ? 1 : 0);
		programs[AMBIENT]->setUniform1i (AMBIENT_COLOR_SAMPLER, (_dchannel >= 0) ? _dchannel : 0);
		programs[AMBIENT]->setUniform1i (AMBIENT_HAS_LIGHTMAP, (_lmap && (_lchannel >= 0)) ? 1 : 0);
		programs[AMBIENT]->setUniform1i (AMBIENT_LIGHTMAP_SAMPLER, (_lchannel >= 0) ? _lchannel : 0);
		programs[AMBIENT]->setUniform1f (AMBIENT_OPACITY, 1.0f);
	}
}

void
BSPMaterial::reset (Sehle::RenderContext *ctx)
{
	glUseProgram (0);
	if (_lchannel >= 0) {
		glActiveTexture (GL_TEXTURE0 + _lchannel);
		glDisable (GL_TEXTURE_2D);
		glActiveTexture (GL_TEXTURE0);
		ctx->releaseTexture (_lchannel);
		_lchannel = -1;
	}
	if (_dchannel >= 0) {
		glActiveTexture (GL_TEXTURE0 + _dchannel);
		glDisable (GL_TEXTURE_2D);
		glActiveTexture (GL_TEXTURE0);
		ctx->releaseTexture (_dchannel);
		_dchannel = -1;
	}
}

void
BSPMaterial::render (Sehle::RenderContext *ctx, Sehle::VertexBuffer *vb, Sehle::VertexBuffer *tb, const Sehle::u32 *indices, Sehle::u32 nindices, Sehle::u32 flags)
{
	if (!nindices) return;
	// const f32 *attribs = vb->getValuesR ();
	// if (!attribs) return;
	// const f32 *texattribs = tb->getValuesR ();
	// if (!texattribs) return;
	const f32 *attribs = (const f32 *) tb->bind ();
	glEnableClientState (GL_TEXTURE_COORD_ARRAY);
	glTexCoordPointer (2, GL_FLOAT, tb->stride * sizeof (f32), attribs + tb->offset[Sehle::VertexBuffer::TEXCOORDS]);
	int loc_lightmapcoords = -1;
	if ((flags & Sehle::RenderContext::AMBIENT) && (_lchannel >= 0)) {
		loc_lightmapcoords = programs[AMBIENT]->getAttribLocation (AMBIENT_LIGHTMAP_COORDS);
	} else if ((flags & Sehle::RenderContext::GBUFFER) && (_lchannel >= 0)) {
		loc_lightmapcoords = programs[GBUF]->getAttribLocation (AMBIENT_LIGHTMAP_COORDS);
	}
	if (loc_lightmapcoords >= 0) {
		glEnableVertexAttribArray (loc_lightmapcoords);
		glVertexAttribPointer (loc_lightmapcoords, 2, GL_FLOAT, true, tb->stride * sizeof (Sehle::f32), attribs + tb->offset[Sehle::VertexBuffer::TEXCOORDS] + 2);
	}
	if (vb != tb) {
		tb->release ();
		attribs = (const f32 *) vb->bind ();
	}
	glEnableClientState (GL_COLOR_ARRAY);
	glColorPointer (4, GL_FLOAT, vb->stride * sizeof (f32), attribs + vb->offset[Sehle::VertexBuffer::COLORS]);
	glEnableClientState (GL_NORMAL_ARRAY);
	glNormalPointer (GL_FLOAT, vb->stride * sizeof (f32), attribs + vb->offset[Sehle::VertexBuffer::NORMALS]);
	glEnableClientState (GL_VERTEX_ARRAY);
	glVertexPointer (3, GL_FLOAT, vb->stride * sizeof (f32), attribs + vb->offset[Sehle::VertexBuffer::COORDINATES]);
	glDrawElements (GL_TRIANGLES, nindices, GL_UNSIGNED_INT, indices);
	glDisableClientState (GL_VERTEX_ARRAY);
	glDisableClientState (GL_NORMAL_ARRAY);
	glDisableClientState (GL_COLOR_ARRAY);
	if (loc_lightmapcoords >= 0) {
		glDisableVertexAttribArray (loc_lightmapcoords);
	}
	glDisableClientState (GL_TEXTURE_COORD_ARRAY);
	vb->release ();
}

BSPMaterial *
BSPMaterial::newBSPMaterial (Sehle::Engine *engine, const char *id)
{
	if (id) {
		BSPMaterial *res = (BSPMaterial *) engine->lookupResource (Sehle::Engine::MATERIAL, id);
		if (res && (res->resclass == engine->getClassId (Sehle::Engine::MATERIAL, "Miletos::MaterialBSP"))) {
			res->ref ();
			return res;
		}
	}
	BSPMaterial *res = new BSPMaterial(engine, id);
	return res;
}

void
BSPMaterial::setDiffuseMap (const char *id, const NR::PixBlock *dpxb)
{
	Sehle::Texture *tx = NULL;
	if (dpxb) {
		tx = engine->getTexture (id);
		if (tx) {
			NR::PixBlock pxb;
			tx->map (&pxb.pb, dpxb->getMode (), dpxb->getWidth (), dpxb->getHeight ());
			pxb.blit (*dpxb, 255);
			tx->unMap (Sehle::Texture::UINT8, 1);
		}
	}
	if (_dmap) {
		_dmap->unRef ();
	}
	_dmap = tx;
}

void
BSPMaterial::setLightMap (const char *id, const NR::PixBlock *dpxb)
{
	Sehle::Texture *tx = NULL;
	if (dpxb) {
		tx = engine->getTexture (id);
		if (tx) {
			NR::PixBlock pxb;
			tx->map (&pxb.pb, dpxb->getMode (), dpxb->getWidth (), dpxb->getHeight ());
			pxb.blit (*dpxb, 255);
			tx->unMap (Sehle::Texture::UINT8, 1);
		}
	}
	if (_lmap) {
		_lmap->unRef ();
	}
	_lmap = tx;
}

} // Namespace Miletos
