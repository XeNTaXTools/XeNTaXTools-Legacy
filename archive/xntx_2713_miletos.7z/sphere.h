#ifndef __MILETOS_SPHERE_H__
#define __MILETOS_SPHERE_H__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2008
//

#include <miletos/types.h>
#include <miletos/scene.h>

namespace Miletos {

class Sphere : public Item {
private:
	struct CBuf;
	struct Side;

	std::vector<Elea::Vector3f> vertices;
	std::vector<Elea::Vector3f> normals;
	std::vector<Elea::Vector2f> texcoords;
	std::vector<u32> indices;

	// Object implementation
	virtual const Type *objectType (void);
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	virtual void set (const char *attrid, const char *val);
	virtual void update (UpdateCtx *ctx, unsigned int flags);
	// Item implementation
	virtual Sehle::Renderable *show (Sehle::Graph *graph, Sehle::u32 contextmask);
	virtual Item *trace (const Elea::Line3f *ray, unsigned int mask, float *distance);

	// Helpers
	void generateSphere (void);
	void generateRenderable (Sehle::StaticMesh *mesh);
	// Static helpers
	static float longitude (const Elea::Vector3f& v);
	static float latitude (const Elea::Vector3f& v);
	static void addVertex (const Elea::Vector3f& vertex, CBuf *cbuf, u32 *vpos, bool end);
	static void subdivideSide (Side& side, Side *sb, u32 *spos, CBuf *cbuf, u32 *vpos, float radius);
	static void subdivide (Side *sb, u32 *spos, CBuf *cbuf, u32 *vpos, u32 *ib, u32 *ipos, u32 s0, u32 s1, u32 s2, float radius, int level);
public:
	float radius;
	int level;

	// Constructor
	Sphere (void) : Item(0), radius(1), level(2) {}
	// Type system
	static const Type *type (void);

	// Static helper
	static void generateMesh (f32 *v, int vstridebytes, f32 *n, int nstridebytes, f32 *t, int tstridebytes, u32 *indices, float radius, int level, int dir, int& nvertices, int& nindices);
};

} // Namespace Miletos

#endif

