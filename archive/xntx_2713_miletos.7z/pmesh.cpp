#define __MILETOS_PMESH_CPP__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2008
//

static const int debug = 1;

#include <stdlib.h>
#include <stdio.h>

#include <elea/line.h>

#include <sehle/engine.h>
#include <sehle/graph.h>
#include <sehle/renderable.h>
#include <sehle/commonmaterials.h>

#include "types.h"
#include "primitives.h"
#include "xml/base.h"
#include "skeleton.h"
#include "bone.h"
#include "connect.h"

#include "pmesh.h"

#ifdef WIN32
#define strdup _strdup
#endif

namespace Miletos {
#if 0
// PMesh

PMesh::PMesh(void)
: Item(HAS_CHILDREN),
skelname(NULL),
nvertices(0), nindices(0), indices(0), tbase(NULL),
nmorphvertices(0), vmorph(NULL), nmorph(NULL),
vbase(NULL), nbase(NULL), vanim(NULL), nanim(NULL), tanim(NULL),
nmaterials(0),
skeleton(NULL)
{
}

PMesh::~PMesh (void)
{
	assert (!skelname);
	assert (!skeleton);

	clear ();
}

const Object::Type *
PMesh::objectType (void)
{
	return type ();
}

const Object::Type *
PMesh::type (void)
{
	static Type *mytype = NULL;
	static const Attribute attrs[] = {
		{ "skeleton", NULL }
	};
	if (!mytype) mytype = new Type("PMesh", Item::type (), sizeof (attrs) / sizeof (attrs[0]), attrs);
	return mytype;
}

void
PMesh::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	// Superclass
	Item::build (pnode, doc, ctx);

	// Read attributes
	buildAttribute ("skeleton");
}

void
PMesh::release (void)
{
	// Detach skeleton listener
	if (skelname) {
		document->removeIdentityChangeListener (skelname, this);
		free (skelname);
		skelname = NULL;
	}
	// Detach skeleton pointer
	if (skeleton) {
		// Detach existing skeleton
		skeleton->removeMesh (this);
		skeleton = NULL;
	}

	// Superclass
	Item::release ();
}

void
PMesh::set (const char *attrid, const char *val)
{
	if (!strcmp (attrid, "skeleton")) {
		// Detach skeleton listener
		if (skelname) {
			document->removeIdentityChangeListener (skelname, this);
			free (skelname);
			skelname = NULL;
		}
		// Detach skeleton pointer
		if (skeleton) {
			skeleton->removeMesh (this);
			skeleton = NULL;
		}
		if (val && (*val == '#')) {
			skelname = strdup (val + 1);
		}
		// Attach new listener
		if (skelname) {
			document->addIdentityChangeListener (skelname, this);
			Object *object = document->lookupObject (skelname);
			if (object && object->isType (Skeleton::type ())) {
				skeleton = (Skeleton *) object;
				// fixme: In normal situations our private bone array is not yet initialized (Lauris)
				skeleton->addMesh (this);
			}
		}
		requestUpdate (MODIFIED);
	} else {
		// Superclass implementation
		Item::set (attrid, val);
	}
}

Object *
PMesh::childAdded (Thera::Node *cnode, Thera::Node *rnode)
{
	// Superclass
	Object *cobj = Item::childAdded (cnode, rnode);

	return cobj;
}

void
PMesh::childRemoved (Thera::Node *cnode, Thera::Node *rnode)
{
	// Superclass
	Item::childRemoved (cnode, rnode);
}

void
PMesh::update (UpdateCtx *ctx, unsigned int flags)
{
	// Update children
	invokeChildrenUpdate (ctx, flags);

	// If skeleton has modified pending do not update
	if (skeleton && skeleton->modifiedIsScheduled ()) return;

	bbox.setEmpty ();

	// Update bone animation matrixes
	if (flags & ANIMATION_MODIFIED) {
		updateBoneMatrixes ();
		updateBoneBBoxes ();
	}
	// Update morphs
	for (size_t i = 0; i < morphs.size (); i++) {
		PMorph& morph(morphs[i]);
		int k0, k1;
		float kw0;
		if (!morph.times.empty () && findKeys (0, &morph.times[0], (u32) morph.times.size (), k0, kw0, k1)) {
			for (int j = 0; j < morph.numvertices; j++) {
				vbase[morph.firstvertex + j] = kw0 * vmorph[morph.mbufpositions[k0] + j] + (1 - kw0) * vmorph[morph.mbufpositions[k1] + j];
				// fixme: normalize here or somewhere else (Lauris)
				nbase[morph.firstvertex + j] = kw0 * nmorph[morph.mbufpositions[k0] + j] + (1 - kw0) * nmorph[morph.mbufpositions[k1] + j];
			}
		}
	}
	// Update weights
	// fixme: We should only update vertices that are actually changed (Lauris)
	memset (vanim, 0, nvertices * sizeof (Elea::Vector3f));
	memset (nanim, 0, nvertices * sizeof (Elea::Vector3f));
	int wpos = 0;
	for (int vidx = 0; vidx < nvertices; vidx++) {
		for (int widx = 0; widx < wcounts[vidx]; widx++) {
			vanim[vidx] += weights[wpos].weight * pbones[weights[wpos].bone].am2o.transformPoint3 (vbase[vidx]);
			nanim[vidx] += weights[wpos].weight * pbones[weights[wpos].bone].am2o.transformVector3 (nbase[vidx]);
			wpos += 1;
		}
	};
#if 0
	for (size_t i = 0; i < weights.size (); i++) {
		vanim[weights[i].vertex] += weights[i].weight * pbones[weights[i].bone].am2o.transformPoint3 (vbase[weights[i].vertex]);
		nanim[weights[i].vertex] += weights[i].weight * pbones[weights[i].bone].am2o.transformVector3 (nbase[weights[i].vertex]);
	}
#endif
#if 0
	// Update animated scaled vertex buffer
	for (size_t i = 0; i < blends.size (); i++) {
		PBlend& blend(blends[i]);
		if (!blend.numvertices) {
			// Index-only blend
			continue;
		}
		if (blend.nbones == 0) {
			// If blend has no bones we expect animation buffer to be set up during mesh construction
		} else if (blend.nbones == 1) {
			PBone& bone(pbones[blend.bones[0]]);
			Elea::Matrix4x4f mv(bone.am2o);
			mv.transformPoint3 (vanim + blend.firstvertex, sizeof (vanim[0]), vbase + blend.firstvertex, sizeof (vbase[0]), blend.numvertices);
			Elea::Matrix4x4f mn(bone.am2o);
			// fixme: Think about the whole tangent space stuff (Lauris)
			mv.transformVector3 (nanim + blend.firstvertex, sizeof (nanim[0]), nbase + blend.firstvertex, sizeof (nbase[0]), blend.numvertices);
		} else if (blend.nbones > 1) {
			Elea::Matrix4x4f mv[MAXBONESPERVERTEX];
			Elea::Matrix4x4f mn[MAXBONESPERVERTEX];
			for (int j = 0; j < blend.nbones; j++) {
				PBone& bone(pbones[blend.bones[j]]);
				mv[j] = bone.am2o;
				mn[j] = bone.am2o;
			}
			Elea::Matrix4x4f::transformPoint3 (vanim + blend.firstvertex, sizeof (vanim[0]), vbase + blend.firstvertex, sizeof (vbase[0]), blend.numvertices, mv, blend.nbones, &blend.weights[0]);
			Elea::Matrix4x4f::transformVector3 (nanim + blend.firstvertex, sizeof (nanim[0]), nbase + blend.firstvertex, sizeof (nbase[0]), blend.numvertices, mn, blend.nbones, &blend.weights[0]);
		}
	}
#endif
	if (nvertices) {
		bbox.grow (vanim[0], nvertices, sizeof (vanim[0]), &ctx->i2w);
	}

	if (renderable) {
		if (flags & MESH_DEFINITION_CHANGED) {
			rebuildRenderable ((Sehle::StaticMesh *) renderable);
		} else {
			updateRenderable ((Sehle::StaticMesh *) renderable);
		}
	}

	// Superclass implementation
	Item::update (ctx, flags);
	// Emit signal
	// fixme: check for actual changes
	requestModified (MODIFIED);
}

void
PMesh::identityAdded (Document *pdocument, const char *pidentity, Object *pobject)
{
	assert (skelname && !strcmp (skelname, pidentity));
	if (skeleton) {
		fprintf (stderr, "PMesh::identityAdded: Object %s added but we already have skeleton %s\n", pidentity, skeleton->id);
		skeleton->removeMesh (this);
		skeleton = NULL;
	}
	if (pobject->isType (Skeleton::type ())) {
		skeleton = (Skeleton *) pobject;
		// fixme: In normal situations our private bone array is not yet initialized (Lauris)
		skeleton->addMesh (this);
	}
	requestModified (MODIFIED);
}

void
PMesh::identityRemoved (Document *pdocument, const char *pidentity)
{
	assert (skelname && !strcmp (skelname, pidentity));
	if (skeleton) {
		skeleton->removeMesh (this);
		skeleton = NULL;
	}
	requestModified (MODIFIED);
}

Sehle::Renderable *
PMesh::show (Sehle::Graph *graph, Sehle::u32 contextmask)
{
	Sehle::StaticMesh *mesh = new Sehle::StaticMesh(graph, contextmask);

	rebuildRenderable (mesh);

	return mesh;
}

Item *
PMesh::trace (const Elea::Line3f *wray, unsigned int mask, float *distance)
{
	// Ray in object space
	Elea::Line3f lr = _w2i.transform (*wray);
	lr.d.normalizeSelf ();
	// Object center
	Elea::Vector3f c = (bbox.getMax () + bbox.getMin ()) / 2;
	float cdistance = Elea::Vector3f::scalarProduct (c - lr.p, lr.d);
	lr.p += cdistance * lr.d;

	float mindist = Elea::OMEGA_F;
	for (size_t i = 0; i < frags.size (); i++) {
		Frag& frag(frags[i]);
		Elea::f32 t;
		if (lr.getTriangleMeshIntersection (vanim[0], sizeof (vanim[0]), (const Elea::u32 *) &indices[frag.firstindex], frag.numindices, sizeof (indices[0]), &t, NULL)) {
			if (t < mindist) {
				mindist = t;
			}
		}
	}
#if 0
	for (size_t i = 0; i < blends.size (); i++) {
		PBlend& blend(blends[i]);
		Elea::f32 t;
		if (lr.getTriangleMeshIntersection (vanim[0], sizeof (vanim[0]), (const Elea::u32 *) &indices[blend.firstindex], blend.numindices, sizeof (indices[0]), &t, NULL)) {
			if (t < mindist) {
				mindist = t;
			}
		}
	}
#endif
	if (mindist < Elea::OMEGA_F) {
		*distance = mindist;
		return this;
	}

	return NULL;
}

void
PMesh::clear ()
{
	if (vbase) {
		free (vbase);
		vbase = NULL;
	}
	if (nbase) {
		free (nbase);
		nbase = NULL;
	}
	if (tbase) {
		free (tbase);
		tbase = NULL;
	}
	if (indices) {
		free (indices);
		indices = NULL;
	}
	if (vmorph) {
		free (vmorph);
		vmorph = NULL;
	}
	if (nmorph) {
		free (nmorph);
		nmorph = NULL;
	}
	if (vanim) {
		free (vanim);
		vanim = NULL;
	}
	if (nanim) {
		free (nanim);
		nanim = NULL;
	}
	if (tanim) {
		free (tanim);
		tanim = NULL;
	}
	nvertices = 0;
	nindices = 0;
	nmorphvertices = 0;

	pbones.clear ();
	animations.clear ();
	// blends.clear ();
	morphs.clear ();

	wcounts.clear ();
	weights.clear ();
	frags.clear ();
}

void
PMesh::initializeBoneMatrixes (void)
{
	for (size_t i = 0; i < pbones.size (); i++) {
		PBone& bone(pbones[i]);
		Elea::Matrix4x4f anim2parent;
		anim2parent.setTranslation (bone.pos.p);
		anim2parent.setRotation (bone.pos.q);
		bone.anim2object = (bone.parent >= 0) ? pbones[bone.parent].anim2object * anim2parent : anim2parent;
		bone.mesh2bone = bone.anim2object.invertNormalized ();
		bone.am2o = bone.anim2object * bone.mesh2bone;
	}
}

void
PMesh::updateBoneMatrixes (void)
{
	for (size_t i = 0; i < pbones.size (); i++) {
		PBone& bone(pbones[i]);
		bone.am2o = bone.anim2object * bone.mesh2bone;
	}
}

void
PMesh::initializeBoneBBoxes (void)
{
	for (size_t i = 0; i < pbones.size (); i++) {
		pbones[i].bbox.setEmpty ();
	}
	// int wpos = 0;
	for (int vidx = 0; vidx < nvertices; vidx++) {
		for (int widx = 0; widx < wcounts[vidx]; widx++) {
			PBone& bone(pbones[weights[widx].bone]);
			bone.bbox.grow (vbase[vidx]);
			widx += 1;
		}
	};

#if 0
	for (size_t i = 0; i < blends.size (); i++) {
		PBlend& blend(blends[i]);
		for (int j = 0; j < blend.nbones; j++) {
			PBone& bone(pbones[blend.bones[j]]);
			for (int k = 0; k < blend.numvertices; k++) {
				if ((blend.nbones == 1) || (blend.weights[blend.nbones * k + j] > 0)) {
					bone.bbox.grow (Elea::Vector3f(vbase[blend.firstvertex + k]));
				}
			}
		}
	}
#endif
	for (size_t i = 0; i < pbones.size (); i++) {
		pbones[i].animbbox = pbones[i].bbox;
	}
}

void
PMesh::updateBoneBBoxes (void)
{
	for (size_t i = 0; i < pbones.size (); i++) {
		pbones[i].animbbox = pbones[i].am2o.transform (pbones[i].bbox);
	}
}

bool
PMesh::findKeys (float time, const float *times, u32 ntimes, int& k0, float& w0, int& k1)
{
	if (ntimes < 1) return false;
	k0 = 0;
	k1 = 0;
	if (time <= times[0]) {
		k0 = k1 = 0;
	} else if (time >= times[ntimes - 1]) {
		k0 = k1 = (int) ntimes - 1;
	} else {
		for (u32 j = 1; j < ntimes; j++) {
			if (times[j] > time) {
				k0 = (int) j - 1;
				k1 = (int) j;
				break;
			}
		}
	}
	if (k1 > k0) {
		// Interpolate
		float dt = times[k1] - times[k0];
		w0 = (times[k1] - time) / dt;
	} else {
		w0 = 1;
	}
	return true;
}

void
PMesh::rebuildRenderable (Sehle::StaticMesh *mesh)
{
	if (nvertices && nindices) {
		// fixme: There can be multiple objects witht he same id in different documents (Lauris)
		if (!mesh->vbuffer) mesh->vbuffer = mesh->graph->engine->getVertexBuffer (NULL);
		mesh->vbuffer->setUp ((Sehle::u32) nvertices, 12, 0, 3, 10);
		mesh->vbuffer->setValues (0, nvertices, mesh->vbuffer->toffset, tbase[0], 2, sizeof (tbase[0]));
		if (!mesh->ibuffer) mesh->ibuffer = mesh->graph->engine->getIndexBuffer (NULL);
		mesh->ibuffer->resize ((Sehle::u32) nindices);
		memcpy (mesh->ibuffer->indices, indices, nindices * sizeof (indices[0]));
		mesh->resizeMaterials (nmaterials);
		for (int i = 0; i < nmaterials; i++) {
			mesh->setMaterial (i, getMaterial (i, mesh->graph->engine));
		}
		mesh->resizeFragments (frags.size ());
		for (size_t i = 0; i < frags.size (); i++) {
			mesh->frags[i].matidx = frags[i].matidx;
			mesh->frags[i].first = frags[i].firstindex;
			mesh->frags[i].nindices = frags[i].numindices;
			// if (i < 65) mesh->frags[i].nindices = 0;
		}
#if 0
		mesh->resizeFragments (blends.size ());
		for (size_t i = 0; i < blends.size (); i++) {
			mesh->frags[i].matidx = blends[i].matidx;
			mesh->frags[i].first = blends[i].firstindex;
			mesh->frags[i].nindices = blends[i].numindices;
			// if (i < 65) mesh->frags[i].nindices = 0;
		}
#endif
		updateRenderable (mesh);
	} else {
		mesh->resizeMaterials (0);
		mesh->resizeFragments (0);
		if (mesh->vbuffer) mesh->vbuffer->unRef ();
		mesh->vbuffer = NULL;
		if (mesh->ibuffer) mesh->ibuffer->unRef ();
		mesh->ibuffer = NULL;
	}
}

void
PMesh::updateRenderable (Sehle::StaticMesh *mesh)
{
	if (!vanim || !nanim) {
		mesh->resizeFragments (0);
		return;
	}
	mesh->vbuffer->setValues (0, nvertices, mesh->vbuffer->voffset, vanim[0], 3, sizeof (vanim[0]));
	mesh->vbuffer->setValues (0, nvertices, mesh->vbuffer->noffset, nanim[0], 3, sizeof (nanim[0]));
	// fixme: think (Lauris)
	// Calculate tangents
	if (!tanim) tanim = (Elea::Vector4f *) malloc (nvertices * sizeof (Elea::Vector4f));
	for (int i = 0; i < nvertices; i++) tanim[i] = Elea::Vector4f(0, 0, 0, 0);
#if 0
	for (size_t i = 0; i < frags.size (); i++) {
		for (int j = 0; j < frags[i].numindices; j += 3) {
			for (int k = 0; k < 3; k++) {
				int idx0 = indices[frags[i].firstindex + j + (k + 0) % 3];
				if (idx0 < 0 || idx0 > nvertices) {
					fprintf (stderr, "jama\n");
				}
				int idx1 = indices[frags[i].firstindex + j + (k + 1) % 3];
				if (idx0 < 0 || idx1 > nvertices) {
					fprintf (stderr, "jama\n");
				}
				int idx2 = indices[frags[i].firstindex + j + (k + 2) % 3];
				if (idx0 < 0 || idx2 > nvertices) {
					fprintf (stderr, "jama\n");
				}
				Elea::Vector3f v0(vanim[idx1] - vanim[idx0]);
				Elea::Vector3f v1(vanim[idx2] - vanim[idx0]);
				Elea::Vector3f vq(v0 + v1);
				Elea::Vector2f t0(tbase[idx1] - tbase[idx0]);
				Elea::Vector2f t1(tbase[idx2] - tbase[idx0]);
				// Ts * t0.x + Tt * t0.y = v0
				// Ts * t1.x + Tt * t1.y = v1
				// D = t0.x * t1.y - t1.x * t0.y
				// Ds = v0 * t1.y - v1 * t0.y
				// Dt = t0.x * v1 - t1.x * v0
				float D = t0[Elea::X] * t1[Elea::Y] - t1[Elea::X] * t0[Elea::Y];
				Elea::Vector3f Ds = v0 * t1[Elea::Y] - v1 * t0[Elea::Y];
				Elea::Vector3f Dt = t0[Elea::X] * v1 - t1[Elea::X] * v0;
				Elea::Vector3f Ts = Ds / D;
				Elea::Vector3f Tt = Dt / D;
				Ts.normalizeSelf ();
				Tt.normalizeSelf ();
				Elea::Vector3f normal = nanim[idx0].normalize ();
				Elea::Vector3f tangent = Ts.normalize ();
				Elea::Vector3f bitangent = normal * tangent;
				tangent = bitangent * normal;
				float weight = sin (Elea::Vector3f::angle (v0, vq));
				Elea::Vector3f lt(tangent * weight);
				tanim[idx0][Elea::X] += lt[Elea::X];
				tanim[idx0][Elea::Y] += lt[Elea::Y];
				tanim[idx0][Elea::Z] += lt[Elea::Z];
				// fixme: calculate bitangent
			}
		}
	}
	for (int i = 0; i < nvertices; i++) {
		Elea::Vector3f t(&tanim[i][0]);
		t.normalizeSelf ();
		tanim[i].set (t[Elea::X], t[Elea::Y], t[Elea::Z], tanim[i][Elea::W]);
	}
#endif
	mesh->vbuffer->setValues (0, nvertices, mesh->vbuffer->noffset + 3, tanim[0], 4, sizeof (tanim[0]));
}

PMesh::PBone *
PMesh::lookupPBone (const char *sid)
{
	if (!sid || !*sid) return NULL;
	for (size_t i = 0; i < pbones.size (); i++) {
		if (!pbones[i].id.compare (sid)) return &pbones[i];
	}
	return NULL;
}

void
PMesh::setPBoneAnimation (PBone *pbone, const Elea::Matrix4x4f& panim2object)
{
	pbone->anim2object = panim2object;
	requestUpdate (ANIMATION_MODIFIED);
}

void
PMesh::skeletonModified (unsigned int flags)
{
	if (flags & MODIFIED_STATE) requestUpdate (ANIMATION_MODIFIED);
}

Thera::Node *
PMesh::buildSkeletalBone (Thera::Document *pthedoc, int pboneidx)
{
	PBone *pbone = &pbones[pboneidx];

	Thera::Node *node = new Thera::Node (Thera::Node::ELEMENT, pthedoc, "bone");
	node->setAttribute ("id", pbone->id.c_str ());
	node->setAttribute ("name", pbone->id.c_str ());

	char c[256];
	int p = XML::writeOrientation (c, 256, pbone->pos.q, pbone->pos.p, true);
	node->setAttribute ("orientation", c);
	p = XML::writeOrientation (c, 256, pbone->pos.q, pbone->pos.p, false);
	node->setAttribute ("animatedOrientation", c);

	// Heuristics to find the best visual geometry
	Orientation vOrientation;
	// Start and endpoint
	Elea::Vector3f p0(0, 0, 0);
	vOrientation.p = p0;
	Elea::Vector3f p1(p0);
	int nchildren = 0;
	for (size_t j = 0; j < pbones.size (); j++) {
		if (pbones[j].parent == pboneidx) {
			p1 += pbones[j].pos.p;
			nchildren += 1;
		}
	}
	if (nchildren > 0) {
		p1 /= (float) nchildren;
	} else {
		p1 = p0 + Elea::Vector3fZ / 10;
	}
	// Main direction vector
	Elea::Vector3f d(p1 - p0);
	float vLength = d.length ();
	if (vLength > 0) {
		Elea::Vector3f dn(d.normalize ());
		float dnx = Elea::Vector3f::scalarProduct (dn, Elea::Vector3fX);
		float dny = Elea::Vector3f::scalarProduct (dn, Elea::Vector3fY);
		float dnz = Elea::Vector3f::scalarProduct (dn, Elea::Vector3fZ);
		Elea::Vector3f tz(d.normalize ());
		Elea::Vector3f ty;
		if ((fabs (dnx) >= fabs (dny)) && (fabs (dnx) >= fabs (dnz))) {
			// X is main dimension
			if (dnx > 0) {
				ty = Elea::Vector3fZ;
			} else {
				ty = -Elea::Vector3fZ;
			}
		} else if ((fabs (dny) >= fabs (dnx)) && (fabs (dny) >= fabs (dnz))) {
			// Y is main dimension
			if (dny > 0) {
				ty = Elea::Vector3fX;
			} else {
				ty = -Elea::Vector3fX;
			}
		} else {
			// Z is main dimension
			if (dnz > 0) {
				ty = Elea::Vector3fY;
			} else {
				ty = -Elea::Vector3fY;
			}
		}
		Elea::Vector3f tx(ty * tz);
		// Renormalize ty
		ty = tz * tx;
		// Now construct bone shape matrix
		// fixme: Maybe switch coordinates so x is main dimension (Lauris)
		Elea::Matrix4x4f t;
		for (int i = 0; i < 3; i++) {
			t[0 + i] = tx[i];
			t[4 + i] = ty[i];
			t[8 + i] = tz[i];
		}
		vOrientation.q = t.getRotationQuaternion ();
	}
	p = XML::writeOrientation (c, 256, vOrientation.q, vOrientation.p, false);
	node->setAttribute ("vOrientation", c);
	p = XML::writeNumber (c, 256, vLength);
	node->setAttribute ("vLength", c);

	// Add children
	for (size_t i = 0; i < pbones.size (); i++) {
		if (pbones[i].parent == pboneidx) {
			Thera::Node *child = buildSkeletalBone (pthedoc, (int) i);
			node->appendChild (child);
		}
	}

	return node;
}

Thera::Node *
PMesh::buildSkeleton (Thera::Document *pthedoc)
{
	Thera::Node *skelnode = new Thera::Node (Thera::Node::ELEMENT, pthedoc, "skeleton");

	for (size_t i = 0; i < pbones.size (); i++) {
		if (pbones[i].parent < 0) {
			Thera::Node *node = buildSkeletalBone (pthedoc, (int) i);
			skelnode->appendChild (node);
		}
	}

	return skelnode;
}

Thera::Node *
PMesh::buildSkeleton (Thera::Document *pthedoc, const char *rootname)
{
	for (size_t i = 0; i < pbones.size (); i++) {
		if (!pbones[i].id.compare (rootname)) {
			Thera::Node *node = buildSkeletalBone (pthedoc, (int) i);
			Thera::Node *skelnode = new Thera::Node (Thera::Node::ELEMENT, pthedoc, "skeleton");
			skelnode->appendChild (node);
			return skelnode;
		}
	}

	return NULL;
}

const char *
PMesh::getName (void)
{
	return id;
}

int
PMesh::getNumVertices (void)
{
	return nvertices;
}

int
PMesh::getNumTriangles (void)
{
	return nindices;
}

int
PMesh::getNumBones (void)
{
	return (int) pbones.size ();
}

int
PMesh::getNumMaterials (void)
{
	return nmaterials;
}
#endif
} // Namespace Miletos
