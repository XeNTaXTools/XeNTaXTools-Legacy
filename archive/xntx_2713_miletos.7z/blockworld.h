#ifndef __MILETOS_BLOCK_WORLD_H__
#define __MILETOS_BLOCK_WORLD_H__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2007
//

#include <miletos/scene.h>

namespace Miletos {

class Material;

class BlockWorld : public Item {
private:
	enum Materials { TOP, SIDE, NUM_MATERIALS };

	char *materialids[NUM_MATERIALS];
	Material *materials[NUM_MATERIALS];

	int xsize, ysize, zsize;
	float sidelenght;

	int *blocks;

	// Object implementation
	virtual const Type *objectType (void);
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	virtual void set (const char *attrid, const char *val);
	virtual void update (UpdateCtx *ctx, unsigned int flags);
	virtual void identityAdded (Document *pdocument, const char *pidentity, Object *pobject);
	virtual void identityRemoved (Document *pdocument, const char *pidentity);
	virtual void attachedObjectRelease (Object *attached, void *data);
	virtual void attachedObjectModified (Object *attached, unsigned int flags, void *data);
	// Item implementation
	virtual Sehle::Renderable *show (Sehle::Graph *graph, Sehle::u32 contextmask);
	virtual Item *trace (const Elea::Line3f *wray, unsigned int mask, float *distance);

	// Helpers
	void clear (void);
	void readMap (const char *uri);
	void buildWorld (void);
	void buildMesh (Sehle::StaticMesh *mesh);
public:
	// Vertices, indices, materials, morphs or skeleton changed
	static const int MESH_DEFINITION_MODIFIED = 64;

	// Constructor
	BlockWorld (void);
	// Destructor
	virtual ~BlockWorld (void);

	// Type system
	static const Type *type (void);
};

} // Namespace Miletos

#endif

