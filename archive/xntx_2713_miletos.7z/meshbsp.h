#ifndef __MILETOS_MESHBSP_H__
#define __MILETOS_MESHBSP_H__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2007
//

#include <vector>

#include <miletos/uri.h>
#include <miletos/scene.h>
#include <miletos/geometry.h>

namespace Miletos {

class BSPData;

class MeshBSP : public Item {
private:
	// Data container
	BSPData *bdata;

	struct Vertex {
		Elea::Vector3f p;
		Elea::Vector3f n;
		Elea::Vector2f td;
		Elea::Vector2f tl;
		Elea::Color4f c;
	};
	// Local list of vertices (original and generated)
	std::vector<Vertex> vertices;
	// Local list of indices (original and generated)
	std::vector<int> indices;

	struct Face {
		int matidx;
		int vertexbase;
		int firstindex;
		int nindices;
	};
	// Local 8cleaned and generated) list of faces
	std::vector<Face> faces;

	struct FaceList {
		int matidx;
		std::vector<int> faces;
	};

	struct Leaf {
		Elea::Cuboid3f bbox;
		std::vector<FaceList> lists;
	};
	// Local version of leaves
	std::vector<Leaf> leaves;

	struct Material {
		std::string id;
		int textureidx;
		int lmapidx;
	};
	std::vector<Material> materials;

	// Array of texture images
	int _npixblocks;
	NR::PixBlock *_pixblocks;

	// Object implementation
	virtual const Type *objectType (void);
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	virtual void set (const char *attrid, const char *val);
	virtual void update (UpdateCtx *ctx, unsigned int flags);
	// Item implementation
	virtual Sehle::Renderable *show (Sehle::Graph *graph, Sehle::u32 contextmask);
	virtual Item *trace (const Elea::Line3f *wray, unsigned int mask, float *distance);

	// Helpers
	void clear (void);
	void resetInternalData (void);
	bool loadData (void);
	void buildMesh (Sehle::StaticMesh *mesh);
	int findLeaf (int nodeidx, const Elea::Vector3f *p);
	bool isVisible (int from, int what);
public:

	MeshBSP (void);

	// Type system
	static const Type *type (void);
};

} // Namespace Miletos

#endif

