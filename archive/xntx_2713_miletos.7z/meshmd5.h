#ifndef __MILETOS_MESH_MD5_H__
#define __MILETOS_MESH_MD5_H__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2008-2009
//

#include <miletos/types.h>
#include <miletos/pmesh.h>
#include <miletos/skinnedgeometry.h>

namespace Miletos {

struct MD5Data;

class GeometryMD5 : public SkinnedGeometry {
private:
	MD5Data *bdata;

	struct Shader;
	std::vector<Shader *> shaders;

	// Object implementation
	virtual const Type *objectType (void);
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	virtual void set (const char *attrid, const char *val);
	virtual void update (UpdateCtx *ctx, unsigned int flags);

	// SkinnedGeometry implementation
	virtual Sehle::Material *getMaterial (int matidx, Sehle::Engine *engine);
	virtual TextureInfo *getTextureInfo (unsigned int matidx, unsigned int texidx, unsigned int getimage);
	virtual u32 getMaterialInfo (MaterialInfo *mat, u32 matidx);

	void loadData (URI::URLHandler *handler, const char *url);
protected:
public:
	// Constructor
	GeometryMD5 (void) : bdata(NULL) {}
	// Destructor
	~GeometryMD5 (void);

	// Type system
	static const Type *type (void);
};

} // Namespace Miletos

#endif

