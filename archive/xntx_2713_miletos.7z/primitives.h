#ifndef __MILETOS_PRIMITIVES_H__
#define __MILETOS_PRIMITIVES_H__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2007
//

#include <elea/color.h>

#include <miletos/scene.h>

namespace Miletos {

class Material;

class Box : public Item {
private:
	unsigned int size_x_set : 1;
	unsigned int size_y_set : 1;
	unsigned int size_z_set : 1;
	// Material link
	char *matid;
	Material *material;

	// Object implementation
	virtual const Type *objectType (void);
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	virtual void set (const char *attrid, const char *val);
	virtual void update (UpdateCtx *ctx, unsigned int flags);
	virtual void identityAdded (Document *pdocument, const char *pidentity, Object *pobject);
	virtual void identityRemoved (Document *pdocument, const char *pidentity);
	virtual void attachedObjectRelease (Object *attached, void *data);
	virtual void attachedObjectModified (Object *attached, unsigned int flags, void *data);

	// Item implementation
	virtual Sehle::Renderable *show (Sehle::Graph *graph, Sehle::u32 contextmask);
	virtual Item *trace (const Elea::Line3f *ray, unsigned int mask, float *distance);
	// Helpers
	void buildMesh (Sehle::StaticMesh *mesh);
public:
	float size;
	float size_x;
	float size_y;
	float size_z;

	// Constructor
	Box (void);

	// Type system
	static const Type *type (void);

	// Static helper
	static void generateMesh (f32 *v, int vstridebytes, f32 *n, int nstridebytes, f32 *t, int tstridebytes, u32 *indices, float sizex, float sizey, float sizez, int *nvertices, int *nindices);
	static void generateMesh (f32 *v, int vstridebytes, f32 *n, int nstridebytes, f32 *t, int tstridebytes, u32 *indices, const float *p0, const float *p1, int *nvertices, int *nindices);
};

} // Namespace Miletos

#endif

