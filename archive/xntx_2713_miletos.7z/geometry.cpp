#define __MILETOS_SMESH_CPP__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2010
//

static const int debug = 0;

#include <malloc.h>

#include <libarikkei/token.h>

#include <elea/line.h>

#include <sehle/engine.h>
#include <sehle/graph.h>
#include <sehle/renderable.h>

#include "xml/base.h"
#include "material.h"

#include "geometry.h"

namespace Miletos {

// Geometry

Geometry::Geometry (unsigned int flags)
: Object(flags),
nhiddenfrags(0), hiddenfrags(NULL),
vertexid(NULL), indexid(NULL),
noverrides(0), overrideids(NULL), overrides(NULL),
scale(1),
bbox(Elea::Cuboid3fEmpty), ntextures(0), nmaterials(0), nfrags(0), frags(NULL)
{
}

Geometry::~Geometry (void)
{
	if (hiddenfrags) free (hiddenfrags);
}

const Object::Type *
Geometry::objectType (void)
{
	return type ();
}

const Object::Type *
Geometry::type (void)
{
	static Type *mytype = NULL;
	static const Attribute attrs[] = {
		{ "materials", NULL, 0 },
		{ "hiddenFragments", NULL, 0 },
		{ "scale", NULL, 0 }
	};
	if (!mytype) mytype = new Type(Object::type (), "Geometry", NULL, NULL, sizeof (attrs) / sizeof (attrs[0]), attrs);
	return mytype;
}

void
Geometry::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	Object::build (pnode, doc, ctx);
	buildAllAttributes (type (), ctx);
}

void
Geometry::release (void)
{
	clear ();
	clearOverrides ();
	Object::release ();
}

void
Geometry::set (const char *attrid, const char *val)
{
	if (!strcmp (attrid, "materials")) {
		clearOverrides ();
		if (val) {
			Arikkei::TokenChar t(val);
			Arikkei::TokenChar tokenz[1024];
			int ntokenz = t.tokenize (tokenz, 1024, true, true);
			if (ntokenz > 0) {
				noverrides = ntokenz;
				overrideids = (char **) malloc (noverrides * sizeof (char *));
				memset (overrideids, 0, noverrides * sizeof (char *));
				overrides = (Material **) malloc (noverrides * sizeof (Material *));
				memset (overrides, 0, noverrides * sizeof (Material *));
				for (u32 i = 0; i < noverrides; i++) {
					if (tokenz[i][0] == '#') {
						Arikkei::TokenChar id(tokenz[i], 1, tokenz[i].getLength ());
						overrideids[i] = id.strdup ();
						document->addIdentityChangeListener (overrideids[i], this);
						Object *object = document->lookupObject (overrideids[i]);
						if (object && object->isType (Material::type ())) {
							overrides[i] = (Material *) object;
							overrides[i]->attach (this);
						}
					}
				}
			}
		}
		requestUpdate (MODIFIED | MATERIAL_DEFINITION_MODIFIED);
	} else if (!strcmp (attrid, "hiddenFragments")) {
		if (hiddenfrags) {
			nhiddenfrags = 0;
			free (hiddenfrags);
			hiddenfrags = NULL;
		}
		int nvalues;
		if (XML::parseIntegers (NULL, &nvalues, val)) {
			nhiddenfrags = (u32) nvalues;
			hiddenfrags = (u32 *) malloc (nhiddenfrags * sizeof (u32));
			XML::parseIntegers ((i32 *) hiddenfrags, &nvalues, val);
		}
		requestUpdate (MODIFIED | MESH_DEFINITION_MODIFIED);
	} else if (!strcmp (attrid, "scale")) {
		if (!XML::parseNumber (&scale, val)) scale = 1;
		requestUpdate (MODIFIED);
	}
}

void
Geometry::write (const char *attrid)
{
	if (!strcmp (attrid, "hiddenFragments")) {
		if (!nhiddenfrags) {
			node->setAttribute (attrid, NULL);
		} else {
			char *c = new char[nhiddenfrags * 32 + 1];
			XML::writeIntegers (c, nhiddenfrags * 32 + 1, (i32 *) hiddenfrags, nhiddenfrags);
			node->setAttribute (attrid, c);
			delete c;
		}
	}
}

void
Geometry::update (UpdateCtx *ctx, unsigned int flags)
{
	Object::update (ctx, flags);

	if (flags & MESH_DEFINITION_MODIFIED) {
		for (unsigned int i = 0; i < nfrags; i++) frags[i].visible = 1;
		for (unsigned int i = 0; i < nhiddenfrags; i++) {
			if (hiddenfrags[i] < nfrags) frags[hiddenfrags[i]].visible = 0;
		}
	}
}

void
Geometry::identityAdded (Document *pdocument, const char *pidentity, Object *pobject)
{
	for (u32 i = 0; i < noverrides; i++) {
		if (overrideids[i] && !strcmp (pidentity, overrideids[i])) {
			if (overrides[i]) {
				overrides[i]->detach (this);
				overrides[i] = NULL;
			}

			if (pobject->isType (Material::type ())) {
				overrides[i] = (Material *) pobject;
				overrides[i]->attach (this);
			}
		}
	}
	requestUpdate (MODIFIED | MATERIAL_DEFINITION_MODIFIED);
}

void
Geometry::identityRemoved (Document *pdocument, const char *pidentity)
{
	for (u32 i = 0; i < noverrides; i++) {
		if (overrideids[i] && !strcmp (pidentity, overrideids[i])) {
			if (overrides[i]) {
				overrides[i]->detach (this);
				overrides[i] = NULL;
			}
		}
	}
	requestUpdate (MODIFIED | MATERIAL_DEFINITION_MODIFIED);
}

void
Geometry::attachedObjectRelease (Object *attached, void *data)
{
	for (u32 i = 0; i < noverrides; i++) {
		if (overrides[i] == attached) {
			overrides[i]->detach (this);
			overrides[i] = NULL;
		}
	}
	requestUpdate (MODIFIED | MATERIAL_DEFINITION_MODIFIED);
}

void
Geometry::attachedObjectModified (Object *attached, unsigned int flags, void *data)
{
	if (flags & MODIFIED) requestUpdate (MODIFIED | MATERIAL_DEFINITION_MODIFIED);
}

void
Geometry::clear (void)
{
	ntextures = 0;
	nmaterials = 0;
	if (vertexid) {
		free (vertexid);
		vertexid = NULL;
	}
	if (indexid) {
		free (indexid);
		indexid = NULL;
	}
}

void
Geometry::clearOverrides (void)
{
	for (u32 i = 0; i < noverrides; i++) {
		if (overrides[i]) overrides[i]->detach (this);
		if (overrideids[i]) {
			document->removeIdentityChangeListener (overrideids[i], this);
			free (overrideids[i]);
		}
	}
	noverrides = 0;
	if (overrideids) {
		free (overrideids);
		overrideids = NULL;
	}
	if (overrides) {
		free (overrides);
		overrides = NULL;
	}
}

void
Geometry::setNumFrags (unsigned int pnumfrags)
{
	if (pnumfrags == nfrags) return;
	nfrags = pnumfrags;
	frags = (Frag *) realloc (frags, nfrags * sizeof (Frag));
}

void
Geometry::setFragVisibility (u32 pfragidx, unsigned int pvisible)
{
	if (pfragidx >= (u32) nfrags) return;
	if (frags[pfragidx].visible == (pvisible != 0)) return;
	frags[pfragidx].visible = (pvisible != 0);

	int nvalues = 0;
	for (unsigned int i = 0; i < nfrags; i++) if (!frags[i].visible) nvalues += 1;
	if (!nvalues) {
		nhiddenfrags = 0;
		if (hiddenfrags) free (hiddenfrags);
		hiddenfrags = NULL;
	} else {
		nhiddenfrags = (u32) nvalues;
		hiddenfrags = (u32 *) realloc (hiddenfrags, nhiddenfrags * sizeof (u32));
		int vidx = 0;
		for (unsigned int i = 0; i < nfrags; i++) if (!frags[i].visible) hiddenfrags[vidx++] = i;
	}
	requestUpdate (MESH_DEFINITION_MODIFIED);
}

// StaticGeometry

//
// fixme: I do not like this, but we want to add materials to geometries
//

StaticGeometry::StaticGeometry (unsigned int flags)
: Geometry(flags | HAS_CHILDREN), renderable(NULL),
nvertices(0), nindices(0), vbase(NULL), nbase (NULL), tbase(NULL), xbase(NULL), indices(NULL)
{
}

StaticGeometry::~StaticGeometry (void)
{
}

const Object::Type *
StaticGeometry::objectType (void)
{
	return type ();
}

const Object::Type *
StaticGeometry::type (void)
{
	static Type *mytype = NULL;
	if (!mytype) mytype = new Type(Geometry::type (), "StaticGeometry", NULL, NULL, 0, NULL);
	return mytype;
}

void
StaticGeometry::build (Thera::Node *pnode, Document *doc, BuildCtx *ctx)
{
	Geometry::build (pnode, doc, ctx);

	buildAllAttributes (type (), ctx);

}

void
StaticGeometry::release (void)
{
	clear ();
	Geometry::release ();
}

void
StaticGeometry::update (UpdateCtx *ctx, unsigned int flags)
{
	bbox.setEmpty ();

	Geometry::update (ctx, flags);

	if (nvertices) {
		Elea::Matrix4x4f m = ctx->i2w.scaleObject (scale, scale, scale);
		bbox.grow (vbase[0], nvertices, sizeof (vbase[0]), &m);
	}

	if (renderable) {
		if (flags & MESH_DEFINITION_MODIFIED) {
			rebuildRenderable ((Sehle::StaticMesh *) renderable);
		} else if (flags & MODIFIED) {
			updateRenderable ((Sehle::StaticMesh *) renderable);
			if (flags & MATERIAL_DEFINITION_MODIFIED) {
				Sehle::StaticMesh *mesh = (Sehle::StaticMesh *) renderable;
				for (unsigned int i = 0; i < nmaterials; i++) {
					if ((i < noverrides) && (overrides[i])) {
						mesh->setMaterial (i, overrides[i]->getSehleMaterial (mesh->graph->engine));
					} else {
						mesh->setMaterial (i, getMaterial (i, mesh->graph->engine));
					}
				}
			}
		}
		Elea::Matrix3x4f m3(ctx->i2w);
		renderable->setTransform (&m3);
		renderable->setBBox (&bbox);
	}
}

Sehle::Renderable *
StaticGeometry::show (Sehle::Graph *graph, Sehle::u32 contextmask)
{
	renderable = new Sehle::StaticMesh(graph, contextmask);
	rebuildRenderable ((Sehle::StaticMesh *) renderable);
	return renderable;
}

void
StaticGeometry::hide (Sehle::RenderableGroup *pgroup)
{
	assert (renderable);
	pgroup->removeChild (renderable);
	delete renderable;
	renderable = NULL;
}

bool
StaticGeometry::trace (const Elea::Line3f *mray, unsigned int mask, float *distance)
{
	float mindist = Elea::OMEGA_F;
	for (unsigned int i = 0; i < nfrags; i++) {
		if (!frags[i].numindices) continue;
		Elea::Matrix4x4f m = Elea::Matrix4x4f::scaling (1 / scale, 1 / scale, 1 / scale);
		Elea::Line3f sray = m.transform (*mray);
		Elea::f32 t;
		if (sray.getTriangleMeshIntersection (vbase[0], sizeof (Elea::Vector3f), (const Elea::u32 *) &indices[frags[i].firstindex], frags[i].numindices, sizeof (indices[0]), &t, NULL)) {
			if (t < mindist) mindist = t;
		}
	}
	if (mindist < Elea::OMEGA_F) {
		if (distance) *distance = mindist;
		return true;
	}

	return false;
}

unsigned int
StaticGeometry::getVertices (const Elea::Vector3f **vertices, const Elea::Vector3f **normals, const Elea::Vector3f **tangents, const Elea::Vector2f **texcoords)
{
	if (vertices) *vertices = vbase;
	if (normals) *normals = nbase;
	if (tangents) *tangents = tbase;
	if (texcoords) *texcoords = xbase;
	return nvertices;
}

unsigned int
StaticGeometry::getIndices (const u32 **pindices)
{
	if (pindices) *pindices = indices;
	return nindices;
}

void
StaticGeometry::rebuildRenderable (Sehle::StaticMesh *mesh)
{
	if (!nvertices || !nindices || !nfrags) {
		mesh->resizeMaterials (0);
		mesh->resizeFragments (0);
		if (mesh->vbuffer) mesh->vbuffer->unRef ();
		mesh->vbuffer = NULL;
		if (mesh->ibuffer) mesh->ibuffer->unRef ();
		mesh->ibuffer = NULL;
		return;
	}

	Sehle::VertexBuffer *newvbuf = mesh->graph->engine->getVertexBuffer (vertexid);
	if (mesh->vbuffer) mesh->vbuffer->unRef ();
	mesh->vbuffer = newvbuf;
	u32 vstride = 3;
	u32 noffset = 0;
	u32 toffset = 0;
	u32 xoffset = 0;
	if (nbase) {
		noffset = vstride;
		vstride += 3;
	}
	if (tbase) {
		toffset = vstride;
		vstride += 3;
	}
	if (xbase) {
		xoffset = vstride;
		vstride += 2;
	}
	mesh->vbuffer->setUp ((Sehle::u32) nvertices, vstride);
	mesh->vbuffer->setOffset (Sehle::VertexBuffer::COORDINATES, 0);
	mesh->vbuffer->setOffset (Sehle::VertexBuffer::NORMALS, noffset);
	mesh->vbuffer->setOffset (Sehle::VertexBuffer::TANGENTS, toffset);
	mesh->vbuffer->setOffset (Sehle::VertexBuffer::TEXCOORDS, xoffset);
	mesh->vbuffer->map (Sehle::VertexBuffer::WRITE);
	if (xbase) {
		mesh->vbuffer->setValues (0, nvertices, mesh->vbuffer->offset[Sehle::VertexBuffer::TEXCOORDS], xbase[0], 2, sizeof (Elea::Vector2f));
	}
	mesh->vbuffer->unMap ();

	Sehle::IndexBuffer *newibuf = mesh->graph->engine->getIndexBuffer (indexid);
	if (mesh->ibuffer) mesh->ibuffer->unRef ();
	mesh->ibuffer = newibuf;
	mesh->ibuffer->resize ((Sehle::u32) nindices);
	mesh->ibuffer->map (Sehle::IndexBuffer::WRITE);
	memcpy (mesh->ibuffer->indices, indices, nindices * sizeof (indices[0]));
	mesh->ibuffer->unMap ();

	mesh->resizeMaterials (nmaterials);
	for (unsigned int i = 0; i < nmaterials; i++) {
		if ((i < noverrides) && (overrides[i])) {
			mesh->setMaterial (i, overrides[i]->getSehleMaterial (mesh->graph->engine));
		} else {
			mesh->setMaterial (i, getMaterial (i, mesh->graph->engine));
		}
	}

	int nvisiblefrags = 0;
	for (unsigned int i = 0; i < nfrags; i++) {
		if (frags[i].visible) nvisiblefrags += 1;
	}
	mesh->resizeFragments (nvisiblefrags);
	int fidx = 0;
	for (unsigned int i = 0; i < nfrags; i++) {
		if (!frags[i].visible) continue;
		mesh->frags[fidx].matidx = frags[i].matidx;
		mesh->frags[fidx].first = frags[i].firstindex;
		mesh->frags[fidx].nindices = frags[i].numindices;
		fidx += 1;
	}

	updateRenderable (mesh);
}

void
StaticGeometry::updateRenderable (Sehle::StaticMesh *mesh)
{
	if (!nvertices || !nindices || !nfrags) return;

	mesh->vbuffer->map (Sehle::VertexBuffer::WRITE);
	if (scale == 1) {
		mesh->vbuffer->setValues (0, nvertices, mesh->vbuffer->offset[Sehle::VertexBuffer::COORDINATES], vbase[0], 3, sizeof (Elea::Vector3f));
	} else {
		for (unsigned int i = 0; i < nvertices; i++) {
			mesh->vbuffer->setValues (i, mesh->vbuffer->offset[Sehle::VertexBuffer::COORDINATES], scale * vbase[i], 3);
		}
	}
	if (nbase) mesh->vbuffer->setValues (0, nvertices, mesh->vbuffer->offset[Sehle::VertexBuffer::NORMALS], nbase[0], 3, sizeof (Elea::Vector3f));
	if (tbase) mesh->vbuffer->setValues (0, nvertices, mesh->vbuffer->offset[Sehle::VertexBuffer::TANGENTS], tbase[0], 3, sizeof (Elea::Vector3f));
	mesh->vbuffer->unMap ();

	mesh->setBBox (&bbox);
}

void
StaticGeometry::clear (void)
{
	nvertices = 0;
	if (vbase) free (vbase);
	vbase = NULL;
	if (nbase) free (nbase);
	nbase = NULL;
	if (tbase) free (tbase);
	tbase = NULL;
	if (xbase) free (xbase);
	xbase = NULL;

	nindices = 0;
	if (indices) free (indices);
	indices = NULL;

	nfrags = 0;
	if (frags) free (frags);
	frags = NULL;

	nmaterials = 0;

	if (vertexid) {
		free (vertexid);
		vertexid = NULL;
	}
	if (indexid) {
		free (indexid);
		indexid = NULL;
	}
}

void
StaticGeometry::setNumVertices (int pnumvertices, bool texcoords, bool normals, bool tangents)
{
	nvertices = pnumvertices;
	if (texcoords) {
		xbase = (Elea::Vector2f *) realloc (xbase, nvertices * sizeof (Elea::Vector2f));
	} else {
		if (xbase) free (xbase);
		xbase = NULL;
	}
	vbase = (Elea::Vector3f *) realloc (vbase, nvertices * sizeof (Elea::Vector3f));
	if (normals) {
		nbase = (Elea::Vector3f *) realloc (nbase, nvertices * sizeof (Elea::Vector3f));
	} else {
		if (nbase) free (nbase);
		nbase = NULL;
	}
	if (tangents) {
		tbase = (Elea::Vector3f *) realloc (tbase, nvertices * sizeof (Elea::Vector3f));
	} else {
		if (tbase) free (tbase);
		tbase = NULL;
	}
}

void
StaticGeometry::setNumIndices (unsigned int pnumindices)
{
	if (pnumindices == nindices) return;
	nindices = pnumindices;
	indices = (u32 *) realloc (indices, nindices * sizeof (u32));
}

} // Namespace Miletos
