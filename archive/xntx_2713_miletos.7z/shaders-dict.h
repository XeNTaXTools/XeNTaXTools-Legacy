#ifndef __MILETOS_SHADERS_DICT_H__
#define __MILETOS_SHADERS_DICT_H__

#ifdef __cplusplus
extern "C" {
#endif

const unsigned char *getMap_Miletos (const char *name, size_t *csize);

#ifdef __cplusplus
}; /* "C" */
#endif

#endif
