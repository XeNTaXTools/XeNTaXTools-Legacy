#ifndef __MILETOS_MESHOBJ_H__
#define __MILETOS_MESHOBJ_H__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2008
//

#include <string>
#include <vector>

#include <miletos/uri.h>
#include <miletos/geometry.h>
#include <miletos/helpers/datablock.h>

namespace Miletos {

#ifndef __MILETOS_MESHOBJ_CPP__
extern Elea::Matrix4x4f OBJTransform;
extern float OBJScale;
#endif

class OBJData : public DataBlock {
public:
	// Parser temporaries
	struct BuildData;
	BuildData *bdata;
	unsigned int invalid;
private:
	OBJData (const char *url);
	OBJData (const unsigned char *cdata, size_t csize, const char *url);
	virtual ~OBJData (void);

	// Helper
	void parse (const unsigned char *cdata, size_t csize);
	int readVertex (const char *cdata, size_t csize, int normalindex);
public:
	std::string mtllib;

	// Static constructor
	static OBJData *getOBJData (const char *url, unsigned int create);
	static OBJData *getOBJData (const unsigned char *cdata, size_t csize, const char *url);

	// Parsing
	void startParser (void);
	void parseLine (const char *cdata, size_t csize);
	void finishParser (void);
};

// This is processed OBJ mesh with normals calculated ant vertices welded

class OBJMesh {
private:
	OBJData *objdata;

	// Welded vindices
	std::vector<int> vindices;
	// Map from original vertex index to welded vertex index
	std::vector<int> vorig2welded;
	// Map from welded vertex index to collated vertex index
	std::vector<int> vwelded2collated;
public:
	char *url;
    char *mtllib;

	struct Fragment {
		// Name of material from usemtl tag
		std::string usemtl;
		int materialidx;
		// Pointers to main index array
		u32 firstindex;
		u32 nindices;
	};

	struct Group {
		std::string name;
		// Original vertex indices of this group
		std::vector<int> vorig;
		// Collated vertex indices of this group
		std::vector<int> vnew;
	};

	std::vector<Elea::Vector3f> vcollated;
	std::vector<Elea::Vector2f> xcollated;
	std::vector<Elea::Vector3f> ncollated;
	std::vector<int> icollated;
	// Mappings from original vertex indices to collated indices
	std::vector<int> vpos;
	std::vector<int> vlen;
	// Preferred group for each new vertex
	std::vector<int> vgroup;

	std::vector<Fragment> fragments;
	std::vector<Group> groups;

	std::vector<std::string> materials;

	OBJMesh (OBJData *objdata, unsigned int build);
	~OBJMesh (void);

	// Helpers
	int lookupGroupIdx (const char *name);
	// Weld vertices between specific groups
	// This has to be done bofore building
	void weld (const char *parent, const char *child);
	// Build all required data
	// If requested autoweld all coincident vertices
	void build (unsigned int weld);
};

class GeometryOBJ : public StaticGeometry {
private:
    OBJMesh *obj;

	struct Texture {
		unsigned int refcount;
		std::string path;
		std::string id;
		NR::PixBlock pixels;
	};
	std::vector<Texture *> textures;
	struct Material {
		// OBJ usemtl tag
		std::string usemtl;
		int diffusetexture;
		int normaltexture;
		int speculartexture;
		std::string diffusemap;
		std::string normalmap;
		std::string specularmap;
	};
	std::vector<Material> materials;

	// Object implementation
	virtual const Type *objectType (void);
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	virtual void set (const char *attrid, const char *val);
	// Geometry implementation
	virtual TextureInfo *getTextureInfo (unsigned int matidx, unsigned int texidx, unsigned int getimage);
	virtual u32 getMaterialInfo (MaterialInfo *mat, u32 matidx);
	// StaticGeometry implementation
	virtual Sehle::Material *getMaterial (int matidx, Sehle::Engine *engine);

	// Helpers
	void clear (void);
	void loadData (void);
	int loadTexture (URI::URLHandler *handler, const char *path);
	bool readVertex (const char *cdata, size_t csize);
public:
	GeometryOBJ (void);

	// Type system
	static const Type *type (void);
};

#if 0
class MeshOBJ : public SMesh {
private:
	GeometryOBJ *_geometry;
	// Object implementation
	virtual const Type *objectType (void);
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	virtual void set (const char *attrid, const char *val);
	virtual void update (UpdateCtx *ctx, unsigned int flags);
	// Item implementation
	// SMesh implementation
	virtual void buildMesh (Sehle::StaticMesh *mesh);
	// Slots
	void geometryModified (Object *object, unsigned int flags);
	void geometryReleased (Object *object);
public:
	// Constructor
	MeshOBJ (void);
	// Type system
	static const Type *type (void);
};
#endif

} // Namespace Miletos

#endif

