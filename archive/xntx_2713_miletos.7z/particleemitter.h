#ifndef __MILETOS_PARTICLE_EMITTER_H__
#define __MILETOS_PARTICLE_EMITTER_H__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2009
//

#include <elea/color.h>

#include <miletos/scene.h>

namespace Miletos {

// ParticleEmitter

class ParticleEmitter : public Item {
private:
	float radius;

	// Object implementation
	virtual const Type *objectType (void);
protected:
	// Sehle light block
	u32 numlights;
	Sehle::PointLight *lights;
	// Inside out light volume
	Elea::Vector3f *vertices;
	u32 nindices;
	u32 *indices;
	// Light parameters
	float cutoffDistance;
	float constantAttenuation;
	float linearAttenuation;
	float quadraticAttenuation;

	// Particles
	u32 maxparticles;
	u32 numparticles;
	Elea::Vector3f *coords;
	Elea::Vector3f *velocities;
	float *ages;
	Elea::Color4f *colors;
	double lasttime;
	double lastcreation;

	// Object implementation
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	virtual void set (const char *attrid, const char *val);
	virtual void write (const char *attrid);
	virtual void update (UpdateCtx *ctx, unsigned int flags);
	virtual void timeStep (double time);
	// Item implementation
	virtual Sehle::Renderable *show (Sehle::Graph *graph, Sehle::u32 contextmask);
	virtual void hide (Sehle::RenderableGroup *pgroup);
	virtual Item *trace (const Elea::Line3f *wray, unsigned int mask, float *distance);

	// Update sehle light definition
	void updateLights (void);
	void updateVolume (void);
public:

	// Constructor
	ParticleEmitter (void);
	// Destructor
	virtual ~ParticleEmitter (void);

	virtual void start (double time);
	virtual void stop (double time);

	// Type system
	static const Type *type (void);
};

} // Namespace Miletos

#endif

