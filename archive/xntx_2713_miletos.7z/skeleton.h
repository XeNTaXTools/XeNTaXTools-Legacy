#ifndef __MILETOS_SKELETON_H__
#define __MILETOS_SKELETON_H__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2009
//

#include <vector>

#include <miletos/miletos.h>

namespace Miletos {

class PoseableGeometry;
class PoseableItem;
class IKChain;
class Bone;

namespace Animation {
	class SkinAnimation;
}

//
// Skeleton
//
// A managed collection of bone hierarchies
// All bones are kept in array and assigned sequential index via skeletalbone interface
// If bone signals about tree change, the whole array is dropped, all poseables
// are signalled to clear indices and update is scheduled with flag BONE_STRUCTURE_MODIFIED flag
// If this flag is set, bone array and poseable indices will be rebuilt as the first step of update cycle
//
// Implements both poseable and skeleton interfaces
//

class Skeleton : public Object {
private:
	// Object implementation
	virtual const Type *objectType (void);
	virtual Object *childAdded (Thera::Node *cnode, Thera::Node *rnode);
	virtual void childRemoved (Thera::Node *cnode, Thera::Node *rnode);

	// Helpers
	void updateChildData (Thera::Node *removed);
protected:
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	virtual void set (const char *attrid, const char *val);
	virtual void update (UpdateCtx *ctx, unsigned int flags);
	virtual void attachedObjectRelease (Object *attached, void *data);
	virtual void attachedObjectModified (Object *attached, unsigned int flags, void *data);

	// Helpers
	// Clear bone array and poseable indices
	void clearBoneLinks (void);
public:
	// Bones have been added, removed or renamed
	static const int BONE_STRUCTURE_MODIFIED = 128;
	// Full bone list
	std::vector<Bone *> bones;
	// List of IKChains
	u32 nchains;
	IKChain **chains;

	Skeleton (void);
	virtual ~Skeleton (void);

	// Type system
	static const Type *type (void);

	// Handling of bone structure
	// Request releasing of bone list and recalculation in next update cycle
	void boneTreeModified (void);
	// Register bone to poseable and get index
	int registerBone (Bone *bone);
	// Bone informs poseable to update animation data
	void updateBoneAnimation (Bone *bone, int boneidx);

	// External access
	int getNumBones (void) { return (int) bones.size (); }
	int lookupBone (const char *sid);
	int lookupIKChain (const char *sid);
	int getBoneIndex (Bone *bone);
	int getBoneParentIndex (Bone *bone);

	//
	// Skeleton interface
	//
	std::vector<PoseableGeometry *> poseables;
	std::vector<PoseableItem *> poseableitems;
	void attachOrUpdatePoseable (PoseableGeometry *geometry);
	void attachOrUpdatePoseable (PoseableItem *item);
	void detachPoseable (PoseableGeometry *geometry);
	void detachPoseable (PoseableItem *item);

	//
	// Poseable interface
	//
	// These are local indices for all parent skeleton bones (-1 if not in local list)
	std::vector<int> skeleton2local;
	// This updates skeleton<->poseable attachment indices
	void attachAnimation (Animation::SkinAnimation *animation);
	void detachAnimation (Animation::SkinAnimation *animation);
	void animate (Animation::SkinAnimation *animation, float time);
};

} // Namespace Miletos

#endif
