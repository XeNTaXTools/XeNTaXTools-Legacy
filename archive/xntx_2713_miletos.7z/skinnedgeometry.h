#ifndef __MILETOS_SKINNEDGEOMETRY_H__
#define __MILETOS_SKINNEDGEOMETRY_H__

//
// Libmiletos
//
// Copyright (C) Lauris Kaplinski 2011
//

#include <miletos/geometry.h>

namespace Miletos {

class Figure;
class Skeleton;
class Morph;

namespace Animation {
	class SkinAnimation;
	class KeyFrameAnimation;
	class BoneAnimation;
}

class PoseableGeometry : public Geometry {
private:
	// Object implementation
	virtual const Type *objectType (void);

	// Update animated transforms (based on ab2p)
	void updateBoneMatrixes (void);
	// Update animated bounding boxes
	void updateBoneBBoxes (void);

	// Create bone node
	Thera::Node *buildSkeletalBone (Thera::Document *pthedoc, int pboneidx, const Elea::Quaternionf *parentdir, float parentlen, int algorithm);
protected:
	// Object implementation
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	virtual void set (const char *attrid, const char *val);
	virtual void write (const char *attrid);
	virtual void update (UpdateCtx *ctx, unsigned int flags);
	virtual void attachedObjectRelease (Object *attached, void *data);
	virtual void attachedObjectModified (Object *attached, unsigned int flags, void *data);
	// Geometry implementation
	virtual unsigned int getVertices (const Elea::Vector3f **vertices, const Elea::Vector3f **normals, const Elea::Vector3f **tangents, const Elea::Vector2f **texcoords);
	virtual unsigned int getIndices (const u32 **indices);

	// Release and clear all dependent data
	void clear (void);

	// Bone array construction
	void setNumBones (unsigned int pnumbones);
	void setBone (int bidx, const char *id, int pidx, const Elea::Matrix3x4f& b2p);
	// Compute default transformations (neutral + animated)
	void initializeBoneMatrixes (void);
	// Update bone lock status
	void updateBoneStatus (void);

	// Vertex resizing
	void setNumVertices (unsigned int pnumvertices, bool texcoords, bool normals, bool tangents);
	void setNumIndices (unsigned int pnumindices);

	// Create Sehle material
	virtual Sehle::Material *getMaterial (int matidx, Sehle::Engine *engine) = 0;
public:
	// Parent bone sid
	// Parent bone is skeletal bone the whole posebale geometry is attached to
	char *parentsid;
	// Local bone that is attached to parent bone
	// Parent transformations are NOT applied to anchor but the whole geometry instead
	char *anchorid;
	// Local transform added to parent
	// s2m = p2m * s2p
	Elea::Matrix3x4f s2p;

	// Local bone structure
	struct Bone {
		// Neutral position
		// Neutral orientation in parent space
		Elea::Matrix3x4f b2p;
		// Skin to neutral bone space
		Elea::Matrix3x4f s2b;
		// Default bounding box in skin space
		Elea::Cuboid3f bbox;

		// Animated position
		// Animated orientation in parent space
		Elea::Matrix3x4f ab2p;
		// Animated bone to skin space
		Elea::Matrix3x4f ab2s;
		// Animated skin to mesh
		Elea::Matrix3x4f as2m;
		// Animated bounding box in mesh space
		Elea::Cuboid3f abbox;

		char *id;
		// -1 for root bone
		i16 pidx;
		// Lock flag
		i16 locked;
	};
	unsigned int nbones;
	Bone *bones;
	int anchor;

	// Vertex data
	unsigned int nvertices;
	// Texture coordinates
	Elea::Vector2f *xbase;
	// Animated state
	Elea::Vector3f *vanim;
	Elea::Vector3f *nanim;
	Elea::Vector3f *tanim;

	// Index data
	unsigned int nindices;
	// Index buffer
	u32 *indices;

	PoseableGeometry (void);
	virtual ~PoseableGeometry (void);

	// Type system
	static const Type *type (void);

	// Request recalculation of absolute bone positions
	virtual void setBoneAnimation (int bidx, const Elea::Matrix3x4f& ab2p);

	// Build tree of skeletal nodes
	// Algorithm 0 - bone end is the average of all children origins
	// Algorithm 1 - bone end is the origin of first child
	void buildSkeleton (Thera::Node *skelnode, int algorithm);
	Thera::Node *buildBoneTree (Thera::Document *pdocument, int rootidx, int algorithm);

	//
	// Poseable interface
	//
	// We keep attachment link to skeleton
	Skeleton *skeleton;
	// These are local indices for all skeleton bones (-1 if not in local list)
	std::vector<int> skeleton2local;
	// Index of parent bone in skeleton bone list
	int skeletonanchoridx;
	// This either builds or updates skeleton<->poseable attachment indices
	void attachSkeleton (Skeleton *skeleton);
	void detachSkeleton (Skeleton *skeleton);

	// Find local bone index by SID
	int lookupBone (const char *sid);
	// Set the transformation of anchor bone
	// Matrix has to be normalized
	void setA2M (const Elea::Matrix3x4f& a2m);

	//
	// Animatable interface
	//
	void applyBoneAnimation (int bidx, Animation::BoneAnimation *ba, float frametime);
	void applySkinAnimation (Animation::SkinAnimation *animation, float frametime);
};

class SkinnedGeometry : public PoseableGeometry {
private:
	// Private renderable
	Sehle::StaticMesh *renderable;

	// Object implementation
	virtual const Type *objectType (void);

	// Geometry implementation
	Sehle::Renderable *show (Sehle::Graph *graph, Sehle::u32 contextmask);
	void hide (Sehle::RenderableGroup *pgroup);
	virtual bool trace (const Elea::Line3f *mray, unsigned int mask, float *distance);
	virtual bool trace (const Elea::Line3f *mray, unsigned int mask, const Elea::Matrix4x4f *me2us, float *distance, Elea::Vector3f *uscp);

	// Renderable management
	void rebuildRenderable (Sehle::StaticMesh *mesh);
	void updateRenderable (Sehle::StaticMesh *mesh);

	// Helper
	void updateChildData (Thera::Node *removed);
protected:
	// Object implementation
	virtual void build (Thera::Node *pnode, Document *doc, BuildCtx *ctx);
	virtual void release (void);
	virtual Object *childAdded (Thera::Node *cnode, Thera::Node *rnode);
	virtual void childRemoved (Thera::Node *cnode, Thera::Node *rnode);
	virtual void update (UpdateCtx *ctx, unsigned int flags);

	// Release and clear all dependent data
	void clear (void);

	// Builds bounding boxes for bones (neutral + animated)
	void initializeBoneBBoxes (void);

	// Vertex resizing
	void setNumVertices (int pnumvertices, bool texcoords, bool normals, bool tangents, bool weightcounts);
	void setNumWeights (int pnumweights);
public:
	// Base plus morphed state
	Elea::Vector3f *vbase;
	Elea::Vector3f *nbase;
	Elea::Vector3f *tbase;

	// Weight data
	unsigned int *wcounts;
	struct Weight {
		unsigned int bone;
		float weight;
	};
	unsigned int nweights;
	Weight *weights;

	// Morph data
	unsigned int nmorphs;
	Morph **morphs;
	unsigned int nanimations;
	Animation::SkinAnimation **animations;

	// Constructor
	SkinnedGeometry (void);
	// Destructor
	virtual ~SkinnedGeometry (void);

	// Type system
	static const Type *type (void);

	// fixme: This should be handled by properties (Lauris)
	void calculateNormals (bool normalize);

	//
	// Animatable interface
	//
	void applyMorph (Morph *morph, f32 s);
	void applyAnimation (Animation::KeyFrameAnimation *kfa, u32 f0, u32 f1, f32 s);
};

} // Namespace Miletos

#endif

