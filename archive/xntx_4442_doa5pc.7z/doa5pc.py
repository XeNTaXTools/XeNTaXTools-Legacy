#Script Version 1.0 Beta
#Dead or Alive 5 LR PC

from inc_noesis import *
import time
import noesis
import array
import struct

#rapi methods should only be used during handler callbacks
import rapi

# parsenormals = 0    #little bit slower but better looking
texonly = 0         #load only the textures
warn    = 0         #print logs

#registerNoesisTypes is called by Noesis to allow the script to register formats.
#Do not implement this function in script files unless you want them to be dedicated format modules!
def registerNoesisTypes():
    handle = noesis.register("Dead Or Alive 5 LR PC", ".tmc")
    noesis.setHandlerTypeCheck(handle, tmcCheckType)
    noesis.setHandlerLoadModel(handle, tmcLoadModel)
    if warn:
        noesis.logPopup()
    return 1

#check if it's this type based on the data

def tmcCheckType(data):
    bs = NoeBitStream(data)
    if bs.readBytes(3) != b"TMC":
        return 0
    return 1

class tmchead():
    BlockName = ''
    Count1 = Count2 = Offset1 = Offset2 = Offset3 = base = 0
    offsets = []
    def __init__(self, base, bytestream):
        bytestream.seek(base)
        self.BlockName = bytestream.readBytes(8).decode("ASCII").rstrip("\0")
        self.Count1, self.Count2, self.Offset1, self.Offset2, self.Offset3 = bytestream.read("<12x2L4x3L")
        self.base = base
        bytestream.seek(base+self.Offset1)
        self.offsets = [bytestream.readUInt() for i in range(self.Count1)]

# def tosigned(unsigned, signflag):
    # return unsigned - (0 if unsigned < signflag else signflag*2)

# def Dec4NToFloat4(I):
    # x = tosigned(I       & 0x3FF, 0x200) / 511
    # y = tosigned(I >> 10 & 0x3FF, 0x200) / 511
    # z = tosigned(I >> 20 & 0x3FF, 0x200) / 511
    # w = tosigned(I >> 30        ,   2  ) /  1
    # return(x,y,z,w)

# def HenD3NToFloat3(I):
    # x = tosigned(I       & 0x7FF, 0x400) / 1023
    # y = tosigned(I >> 11 & 0x7FF, 0x400) / 1023
    # z = tosigned(I >> 22        , 0x200) / 511
    # return (x,y,z)

#load the model
def tmcLoadModel(data, mdlList):
    starttime = time.time()
    ctx = rapi.rpgCreateContext()
    bs = NoeBitStream(data)
    bs.setEndian(NOE_LITTLEENDIAN)
    #rapi.rpgSetOption(noesis.RPGOPT_BIGENDIAN, 1)

    #prepare the l file
    lname = rapi.getInputName()
    lname = lname[:-3] + {'TMC':'TMCL', 'GMD':'TTGL'}[lname[-3:].upper()]
    if not rapi.checkFileExists(lname):
        print("file not found:", lname)
        return 0
    tmclData = NoeBitStream(rapi.loadIntoByteArray(lname))
    tmclData.setEndian(NOE_LITTLEENDIAN)

    tmch     = tmchead(0, bs)#0MdlGeo,1TTX,2VtxLay,3IdxLay,4MtrCol,5MdlInfo, ! 6HieLay,7LHeader,8NodeLay,9GlblMtx,10BnOfsMtx, !! 11cpf,12MCAPACK,13RENPACK
    mdlgeoh, ttdm, vtxlayh, idxlayh, mtrcolh, mdlinfoh, hielayh, lheaderh, nodelayh, glbmtxh  = [tmchead(tmch.offsets[i], bs) for i in range(10)]           

    if warn:print('l ok')
    
    
    texList = []
    texNameList = []
   #load textures
    bs.seek(ttdm.base + ttdm.Offset3 + 0x14)
    txoffc, txszc, txoffo, txszo = bs.read("<2L4x2L")
    if txoffc:
        bs.seek(ttdm.base + ttdm.Offset3 + txoffo)
        txoffs = [bs.readUInt() for i in range(txoffc)]
        bs.seek(ttdm.base + ttdm.Offset3 + txszo)
        txszs = [bs.readUInt() for i in range(txszc)]
        for i in range(txoffc):
            texName = str(i) + '.dds'
            tmclData.seek(0x80 + txoffs[i])
            data = tmclData.readBytes(txszs[i])
            Height = int.from_bytes(data[12:16], byteorder='little')
            Width = int.from_bytes(data[16:20], byteorder='little')
            if data[87] == 49: texFmt = noesis.NOESISTEX_DXT1
            elif data[87] == 51: texFmt = noesis.NOESISTEX_DXT3
            elif data[87] == 53: texFmt = noesis.NOESISTEX_DXT5
            data = data[128:]
            texList.append(NoeTexture(texName, Width, Height, data, texFmt))
            texNameList.append(texName)

    if warn:print('tx ok')

    if texonly:
        mdl = NoeModel([])
        mdl.setModelMaterials(NoeModelMaterials(texList, []))
        mdlList.append(mdl)
        rapi.rpgClearBufferBinds()
        return 1

   #parse matrices
    #parse GlblMtx
    GlblMtxs = []
    for offs in glbmtxh.offsets:
        bs.seek(glbmtxh.base + offs)
        gmatrix = NoeMat44.fromBytes(bs.readBytes(0x40)) #rapi.swapEndianArray(bs.readBytes(0x40), 4))#Matrix([fread("4f") for i in range(4)]).transposed()
        GlblMtxs.append(gmatrix)
    #parse NodeLay
    mtx44 = NoeMat44()
    NodeLays_meshnodes = {}
    for offidx ,offs in enumerate(nodelayh.offsets):
        nodeobjh = tmchead(nodelayh.base + offs, bs)
        bs.seek(nodeobjh.base + 0x40)
        nodename = bs.readString()
        for mtxoffs in nodeobjh.offsets:
            bs.seek(nodeobjh.base + mtxoffs)
            objectindex = bs.readUInt()
            objmatrix = (None if GlblMtxs[offidx] == mtx44 else GlblMtxs[offidx])
            NodeLays_meshnodes[objectindex] = (nodename, GlblMtxs[offidx].toMat43())

    #parse mesh data
    matList = []
    #mdlinfo
    mdlinfos = {}
    for objidx, objoffs in enumerate(mdlinfoh.offsets):#get the transparency from those
        if objoffs == 0: continue
        objh  = tmchead(mdlinfoh.base + objoffs, bs)
        objinfos = {}
        for matoffset in objh.offsets:#parse mats
            if matoffset == 0: continue
            bs.seek(objh.base + matoffset)
            matindex, unkflags0, Unk0, fUnk0, v0_1, v00_1, v000_1 = bs.read("<3Lf3L")
            objinfos[matindex] = [unkflags0, Unk0, fUnk0, v0_1, v00_1, v000_1]
        mdlinfos[objidx] = objinfos
    #mdlgeo
    for objidx, objoffs in enumerate(mdlgeoh.offsets):
        if objoffs == 0: continue #fix to support mods
        objh  = tmchead(mdlgeoh.base + objoffs, bs)
        declh = tmchead(mdlgeoh.base + objoffs + objh.Offset3, bs)
        fixmatrix = None
        if objidx in NodeLays_meshnodes:
            objname, fixmatrix = NodeLays_meshnodes[objidx]
        else:
            bs.seek(objh.base + 0x50)
            objname = bs.readString()
        if warn:print(objname)
        if 'sweat' in objname or "zdmodel" in objname or "OPTblur" in objname or "_after_" in objname:
            continue
        decls = []
        for decloffset in declh.offsets:#parse decls
            bs.seek(declh.base + decloffset + 0xC)
            IDXBUFindex, IDXcount, VERTcount, unk0, unk1, VTXBUFindex, vsize, vdatalayerscount =  bs.read("<5L16xL2L4x")#this reach the 0x40 offset
            
            #vdatalayers = [(bs.readUInt(), bs.readUInt(), bs.readUInt()) for i in range(vdatalayerscount)]#vdatalayers[2]#(0,1,10000,20000,30000,50000,50100,50200,60000,a0000)
            vdatalayers = [(bs.readUInt(), bs.readUInt()) for i in range(vdatalayerscount)]#vdatalayers[2, 30002, 1000D, 20005, 60003, 5000B, 105000B]            
            decls.append([IDXBUFindex,vsize,vdatalayers, IDXcount, VERTcount, unk0, unk1, VTXBUFindex]) #vdatalayeroffset, vd3dtype, vusage+vusagelayer

        declmats = [[] for i in range(len(decls))]
        for matoffset in objh.offsets:#parse mats
            if matoffset == 0: continue #fix to support mods
            bs.seek(objh.base + matoffset)
            matindex, mtrcolindex, matTexCount, declfvfindex, transparentmat,v0_ff,transparentmasc,Pad2,fUnk0,fUnk1,Pad3,Pad4, v0_1,v3_4_5,v1_2, twosided, mIDXstart, mIDXcount, mVERTstart, mVERTcount = bs.read("<2L4xL40xL4xL3L2f2L4L4L")
            texbase = objh.base + matoffset + 0xD0 #textures info in mat



            txrs = []
            for texinfo in range(matTexCount):#parse material textueres
                bs.seek(texbase + texinfo * 0x70)
                texSlot, texmaptype, texId = (bs.readUInt(), bs.readUInt(), bs.readUInt())
                txrs.append((texSlot, texmaptype, texId))

            declmats[declfvfindex].append((matindex, mtrcolindex, transparentmat, v0_ff,transparentmasc,Pad2,fUnk0,fUnk1,Pad3,Pad4, v0_1,v3_4_5,v1_2, twosided, mIDXstart,mIDXcount, mVERTstart, mVERTcount,  txrs))

        #parse tmcl raw data
        rapi.rpgSetTransform(fixmatrix)
        for enumdecl, (IDXBUFindex,vsize,vdatalayers, IDXcount, VERTcount, unk0, unk1, VTXBUFindex) in enumerate(decls): #??unk1 is tritype??

            # fvfdata = {fvf[2]:(fvf[0],fvf[1]) for fvf in vdatalayers}
            # tmclData.seek(lheaderh.offsets[1] + vtxlayh.offsets[VTXBUFindex])#seek for fvf buffer
            # BUFdata = tmclData.readBytes(vsize * VERTcount)
            fvfdata = {fvf[1]:(fvf[0]//0x10000) for fvf in vdatalayers}
            bs.seek(vtxlayh.base + vtxlayh.offsets[VTXBUFindex])
            BUFdata = bs.readBytes(vsize * VERTcount)
            
            # if 0 in fvfdata:        rapi.rpgBindPositionBufferOfs(BUFdata, noesis.RPGEODATA_FLOAT, vsize, fvfdata[0][0])
            if 2 in fvfdata:        rapi.rpgBindPositionBufferOfs(BUFdata, noesis.RPGEODATA_FLOAT, vsize, fvfdata[2])
            else:                   rapi.rpgBindPositionBuffer(      none, noesis.RPGEODATA_FLOAT)
            # if 0x50000 in fvfdata:  rapi.rpgBindUV1BufferOfs(BUFdata, noesis.RPGEODATA_HALFFLOAT, vsize, fvfdata[0x50000][0])
            if 0x5000B in fvfdata:  rapi.rpgBindUV1BufferOfs(BUFdata, noesis.RPGEODATA_HALFFLOAT, vsize, fvfdata[0x5000B])
            else:                   rapi.rpgBindUV1Buffer(None, noesis.RPGEODATA_HALFFLOAT, vsize)

            #if 0x30000 in fvfdata and fvfdata[0x30000][1] in (0x1a23a6, 0x2a23b9):#float3/4
            if 0x30002 in fvfdata:
##                print('float normals')
                #rapi.rpgBindNormalBufferOfs(BUFdata, noesis.RPGEODATA_FLOAT, vsize, fvfdata[0x30000][0])
                rapi.rpgBindNormalBufferOfs(BUFdata, noesis.RPGEODATA_FLOAT, vsize, fvfdata[0x30002])
            # elif parsenormals and 0x30000 in fvfdata and fvfdata[0x30000][1] == 0x2a2190:#hend3n
# ##                print('hend3n normals')
# ##                normals = struct.unpack(">" + ("%dx"%(fvfdata[0x30000][0]) + "L" + "%dx"%(vsize - fvfdata[0x30000][0] - 4))*VERTcount, BUFdata)
                # normals = [n for ni in range(VERTcount) for n in HenD3NToFloat3(noeUnpackFrom("<L", BUFdata, ni*vsize+fvfdata[0x30000][0])[0])]
                # normalsdata = struct.pack('<%df'%(VERTcount*3), *normals)
                # rapi.rpgBindNormalBuffer(normalsdata, noesis.RPGEODATA_FLOAT, 12)
# ##                print(normals)
            else:
##                print('generated normals')
                rapi.rpgBindNormalBuffer(None, noesis.RPGEODATA_HALFFLOAT, vsize)

            for matindex, mtrcolindex, transparentmat, v0_ff,transparentmasc,Pad2,fUnk0,fUnk1,Pad3,Pad4, v0_1,v3_4_5,v1_2, twosided, mIDXstart,mIDXcount, mVERTstart, mVERTcount, txrs in declmats[enumdecl]:

                unkflags0, Unk0, fUnk0, v0_1i, v00_1, v000_1 = mdlinfos[objidx][matindex]

                meshname = objname + ("_%x"%matindex if matindex else "")# + ('#' if transparentmasc else '') + ('+' if transparentmat else '')
                matname = objname + "_mat%x"%matindex
                rapi.rpgSetName(meshname)
                material = NoeMaterial(matname, "")
                if twosided:
                    material.setFlags(noesis.NMATFLAG_TWOSIDED, 0)
                for texindex, (texSlot, texmaptype, texId) in enumerate(txrs):
##                    if texmaptype == 3:
##                        material.setTexture(texNameList[texId])
##                        material.setEnvTexture(texNameList[texId])
##                    if texmaptype == 2:
##                        material.setSpecularTexture(texNameList[texId])
                    if texSlot == 0:
                        material.setTexture(texNameList[texId])
                        if not (transparentmat or transparentmasc):
                            material.setDiffuseColor(NoeVec4([1.0, 1.0, 1.0, 0.0]))
                            material.setDefaultBlend(0)
                    elif texSlot == 1:
                        if texmaptype == 0:
                            pass
##                            material.setDefaultBlend(0)
##                        else:
##                            material.setSpecularTexture(texNameList[texId])
                    elif texSlot == 2:
                        if texmaptype == 1:
                            material.setNormalTexture(texNameList[texId])
                    elif texSlot == 3:
                        material.setNormalTexture("")

                matList.append(material)
                #read mat indices
                # tmclData.seek(lheaderh.offsets[2] + idxlayh.offsets[IDXBUFindex] + mIDXstart*2)
                bs.seek(idxlayh.base + idxlayh.offsets[IDXBUFindex] + mIDXstart*2)
##                print(mIDXstart,mIDXcount, tmclData.tell())
                # idata = tmclData.readBytes(mIDXcount*2)
                idata = bs.readBytes(mIDXcount*2)
                rapi.rpgSetMaterial(matname)
                rapi.rpgCommitTriangles(idata, noesis.RPGEODATA_USHORT, mIDXcount, noesis.RPGEO_TRIANGLE_STRIP, 1)

    mdl = rapi.rpgConstructModel()
    mdl.setModelMaterials(NoeModelMaterials(texList, matList))
    mdlList.append(mdl)
    rapi.rpgClearBufferBinds()

    return 1