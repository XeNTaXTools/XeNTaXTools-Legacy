import newGameLib
from newGameLib import *
import Blender	
import math
from math import *

def mdlParser(filename,file):
	#g.debug=True
	lines=file.readlines()
	id=0
	#for id in range len(lines):
	skeleton=Skeleton()
	skeleton.BONESPACE=True
	skeleton.NICE=True
	#skeleton.BONESORT=True
	meshList=[]
	while(True):
	
		if id==len(lines):break
		else:
			line=lines[id]
			
			if 'node ' in line and 'endnode' not in line and ' dummy ' in line:
				#print line
				bone=Bone()
				bone.name=line.strip().split()[2]
				skeleton.boneList.append(bone)
				matrix=Matrix()
				
			if 'node ' in line and 'endnode' not in line and ' trimesh ' in line:
				#print line
				bone=Bone()
				bone.name=line.strip().split()[2]
				skeleton.boneList.append(bone)
				mesh=Mesh()
				mesh.render=0
				#print 'mesh'
				mesh.boneName=bone.name
				meshList.append(mesh)
				matrix=Matrix()
				
			if 'node ' in line and 'endnode' not in line and ' skin ' in line:
				#print line
				bone=Bone()
				bone.name=line.strip().split()[2]
				skeleton.boneList.append(bone)
				mesh=Mesh()
				mesh.render=0
				#print 'mesh'
				mesh.boneName=bone.name
				meshList.append(mesh)
				matrix=Matrix()
				
			if 'node ' in line and 'endnode' not in line and ' danglymesh ' in line:
				#print line
				bone=Bone()
				bone.name=line.strip().split()[2]
				skeleton.boneList.append(bone)
				mesh=Mesh()
				mesh.render=0
				#print 'mesh'
				mesh.boneName=bone.name
				meshList.append(mesh)
				matrix=Matrix()
				
			if 'bitmap ' in line:
				mat=Mat()
				mat.TRIANGLE=True
				mat.diffuse=os.path.dirname(filename)+os.sep+line.strip().split()[1]+'.tga'
				print mat.diffuse
				mesh.matList.append(mat)
				
			if 'parent ' in line:
				bone.parentName=line.strip().split()[1]
				if bone.parentName=='NULL':
					bone.parentName=None
					
			if 'render ' in line:
				mesh.render=int(line.strip().split()[1])
				
			if 'position ' in line:
				#bone.matrix=Matrix()
				matrix=VectorMatrix(map(float,line.strip().split()[1:4]))
				#bone.matrix*=posMatrix#.invert()
				
			if 'orientation ' in line:
				#matrix=Matrix()
				nwangle=map(float,line.strip().split()[1:5])
				#print nwangle       
				phi2 = 0.5 * nwangle[3]			
				tmp = math.sin(phi2)
				qx = nwangle[0]*tmp
				qy = nwangle[1]*tmp
				qz = nwangle[2]*tmp
				qw = math.cos(phi2)
				rotMatrix=QuatMatrix([qx,qy,qz,qw]).resize4x4()#.invert()
				matrix=rotMatrix*matrix
					
					
			if 'endnode' in line:
				#print
				#print matrix
				bone.matrix=matrix
				
			if ' verts ' in line:
				vertCount=int(line.split()[1])
				for m in range(vertCount):
					id+=1
					line=lines[id]
					mesh.vertPosList.append(map(float,line.strip().split()))
			if 'faces ' in line:
				faceCount=int(line.split()[1])
				for m in range(faceCount):
					id+=1
					line=lines[id]
					mesh.faceList.append(map(int,line.strip().split()[:3]))
				#print matrix	
				#mesh.matrix=matrix	
				#mesh.draw()
				#mesh.object.setMatrix(matrix)				
			if ' tverts ' in line:
				vertCount=int(line.split()[1])
				for m in range(vertCount):
					id+=1
					line=lines[id]
					u,v=map(float,line.strip().split()[:2])
					mesh.vertUVList.append([u,1-v])	
					
			if ' weights ' in line:
				vertCount=int(line.split()[1])
				skin=Skin()
				mesh.skinList.append(skin)
				for m in range(vertCount):
					id+=1
					lineSplit=lines[id].strip().split()
					#print lineSplit
					count=len(lineSplit)/2
					groupList=[]
					weightList=[]
					for n in range(count):
						groupList.append(lineSplit[n*2])
						weightList.append(float(lineSplit[n*2+1]))
					mesh.skinGroupList.append(groupList)
					mesh.skinWeightList.append(weightList)		
					
			if 'endmodelgeom '	in line:
				break
				
			id+=1	
	#g.tell()
	skeleton.name='skeleton-'+str(ParseID())
	skeleton.draw()
	for mesh in meshList:
		if len(mesh.vertUVList)>0:
			#print len(mesh.vertPosList),len(mesh.vertUVList),mesh.boneName
			print len(mesh.vertPosList),len(mesh.vertUVList),mesh.boneName,mesh.name
			if mesh.render==1:
				mesh.BINDSKELETON=skeleton.name
				#print len(mesh.skinList)
				if len(mesh.skinList)==0:
					skin=Skin()
					mesh.skinList.append(skin)
					for m in range(len(mesh.vertPosList)):
						mesh.skinGroupList.append([mesh.boneName])
						mesh.skinWeightList.append([1.0])
				mesh.draw()
				#print len(mesh.vertPosList),len(mesh.vertUVList),mesh.boneName,mesh.name
				Blender.Window.RedrawAll()
				mesh.object.setMatrix(skeleton.object.getData().bones[mesh.boneName].matrix['ARMATURESPACE'])
	#try:	
	selObjectList=Blender.Object.GetSelected()
	if len(selObjectList)>0:
		selObject=selObjectList[0]
		if selObject.type=='Armature':			
			
			skeleton.object.setMatrix(selObject.getData().bones['necklwr_g'].matrix['ARMATURESPACE'])	
			Blender.Window.RedrawAll()
			#except:
		#pass
	
	
	id=0
	animFlag=0
	while(True):
	
		if id==len(lines):break
		else:
			line=lines[id]
			#print line
			if 'newanim ' in line:
				#print line
				animFlag=1
				animDir=os.path.dirname(filename)+os.sep+os.path.basename(filename)+'_animfiles'
				if os.path.exists(animDir)==False:
					os.makedirs(animDir)
				new=open(animDir+os.sep+line.strip().split()[1]+'.anim','wb')
				g=BinaryReader(new)
				
			if 	'node ' in line and 'endnode' not in line and animFlag==1: 
				#bone=AnimBone()
				name=line.strip().split()[2]
				rotList=[]
				posList=[]
				
			if 'orientationkey' in line and animFlag==1:
				while(True):
					id+=1
					line=lines[id]
					#print line
					if "endlist" in line:break
					else:
						rotList.append(map(float,line.strip().split()))
						
				
			if 'positionkey' in line and animFlag==1:
				while(True):
					id+=1
					line=lines[id]
					if "endlist" in line:break
					else:
						posList.append(map(float,line.strip().split()))
					
			if 'endnode' in line and animFlag==1:
				#print id,line
				new.write(name+'\x00')
				g.i([len(rotList)])
				for m in range(len(rotList)):
					g.f(rotList[m])
				g.i([len(posList)])
				for m in range(len(posList)):
					g.f(posList[m])

			if 'doneanim' in line and animFlag==1:
				animFlag=0
				#new.close()
				
			id+=1
			
def animParser(filename,g):
	selObject=Blender.Object.GetSelected()
	if len(selObject)>0:
		name=selObject[0].name
		action=Action()
		action.BONESPACE=True
		action.BONESORT=True
		action.skeleton=name
		while(True):
			if g.tell()>=g.fileSize():break
			bone=ActionBone()
			action.boneList.append(bone)
			bone.name=g.find('\x00')
			rotCount=g.i(1)[0]
			for m in range(rotCount):
				bone.rotFrameList.append(int(g.f(1)[0]*30))				
				nwangle=g.f(4)    
				phi2 = 0.5 * nwangle[3]			
				tmp = math.sin(phi2)
				qx = nwangle[0]*tmp
				qy = nwangle[1]*tmp
				qz = nwangle[2]*tmp
				qw = math.cos(phi2)
				#print qx,qy,qz,qw
				rotMatrix=QuatMatrix([qx,qy,qz,qw]).resize4x4()
				bone.rotKeyList.append(rotMatrix)
			posCount=g.i(1)[0]
			for m in range(posCount):
				bone.posFrameList.append(int(g.f(1)[0]*30))
				posMatrix=VectorMatrix(g.f(3))
				bone.posKeyList.append(posMatrix)
		action.draw()
		action.setContext()	
				
			
	
	
def Parser(filename):	
	print '='*70
	print filename
	print '='*70
	ext=filename.split('.')[-1].lower()	
	
	if ext=='mdl':
		file=open(filename,'r')
		#g=BinaryReader(file)
		#g.logOpen()
		#g=file.readlines
		mdlParser(filename,file)
		#g.logClose()
		file.close()	
	
	if ext=='anim':
		file=open(filename,'rb')
		g=BinaryReader(file)
		g.logOpen()
		#g=file.readlines
		animParser(filename,g)
		g.logClose()
		file.close()
 
	
Blender.Window.FileSelector(Parser,'import','... files: *.... - model') 
	