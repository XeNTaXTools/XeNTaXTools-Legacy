# Giana Sisters: Twisted Dreams
# NX mesh viewer
# Noesis script by Dave, 2020

from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Giana Sisters: Twisted Dreams",".nx")
	noesis.setHandlerTypeCheck(handle, bcCheckType)
	noesis.setHandlerLoadModel(handle, bcLoadModel)
	return 1

# Check file type

def bcCheckType(data):
	return 1

# Read the model data

def bcLoadModel(data, mdlList):
	bs = NoeBitStream(data)
	ctx = rapi.rpgCreateContext()

	misc = DrawMesh(bs, 0)						# enter mesh number here (0+)

	if misc == 1:
		mdl = rapi.rpgConstructModel()
		mdlList.append(mdl)

	return 1


# Draw Mesh

def DrawMesh(bs, num):
	bs.seek(0x18)
	data_start = bs.readUInt() + 0x10

	bs.seek(0x34)
	mesh_max = bs.readUInt()

	if num >= mesh_max:
		print("Mesh number greater than maximum mesh count")
		return 0

	bs.seek(0x3c)
	mesh_table = bs.readUInt() + 0x34

	bs.seek(mesh_table + (num * 0x34))
	mesh_id = bs.readUInt()
	vert_offset = bs.readUInt() + data_start
	junk = bs.readUInt()
	face_offset = bs.readUInt() + data_start
	vert_count = bs.readUInt()
	face_count = bs.readUInt()
	t1_offset = bs.readUInt()

	bs.seek(t1_offset + 0x4c)
	stride = bs.readUInt()

#	print(hex(mesh_id), hex(vert_offset), hex(face_offset), stride, vert_count, face_count)

	bs.seek(vert_offset)
	vertices = bytes()
	uvs = bytes()
	normals = bytes()

	if stride == 32:
		for a in range(vert_count):
			vx = bs.readHalfFloat()
			vz = bs.readHalfFloat()
			vy = bs.readHalfFloat()
			junk = bs.readShort()
			nx = bs.readHalfFloat()
			ny = bs.readHalfFloat()
			nz = bs.readHalfFloat()
			junk = bs.readShort()
			uvx = bs.readHalfFloat()
			uvy = bs.readHalfFloat()
			junk = bs.readBytes(12)
			vertices += noePack("fff", vx, vy, vz)
			normals += noePack("fff", nx, ny, nz)
			uvs += noePack("ff", uvx, uvy)

	elif stride == 16:
		for a in range(vert_count):
			vx = bs.readHalfFloat()
			vz = bs.readHalfFloat()
			vy = bs.readHalfFloat()
			junk = bs.readShort()
			nx = bs.readHalfFloat()
			ny = bs.readHalfFloat()
			nz = bs.readHalfFloat()
			junk = bs.readShort()
			vertices += noePack("fff", vx, vy, vz)
			normals += noePack("fff", nx, ny, nz)

	elif stride == 36:
		for a in range(vert_count):
			vx = bs.readHalfFloat()
			vz = bs.readHalfFloat()
			vy = bs.readHalfFloat()
			junk = bs.readBytes(6)
			nx = bs.readHalfFloat()
			ny = bs.readHalfFloat()
			nz = bs.readHalfFloat()
			junk = bs.readBytes(2)
			uvx = bs.readHalfFloat()
			uvy = bs.readHalfFloat()
			junk = bs.readBytes(12)
			vertices += noePack("fff", vx, vy, vz)
			normals += noePack("fff", nx, ny, nz)
			uvs += noePack("ff", uvx, uvy)

	elif stride == 28:
		for a in range(vert_count):
			vx = bs.readHalfFloat()
			vz = bs.readHalfFloat()
			vy = bs.readHalfFloat()
			junk = bs.readBytes(22)

			vertices += noePack("fff", vx, vy, vz)

	else:
		print("Unknown stride size")
		return 0

	rapi.rpgBindPositionBuffer(vertices, noesis.RPGEODATA_FLOAT, 12)
	rapi.rpgBindUV1Buffer(uvs, noesis.RPGEODATA_FLOAT, 8) if uvs else None
	rapi.rpgBindNormalBuffer(normals, noesis.RPGEODATA_FLOAT, 12) if normals else None


	if face_count != 0:
		bs.seek(face_offset)
		faces = bs.readBytes(face_count * 2)

	rapi.rpgSetName("Mesh_" + str(hex(mesh_id)))

# Draw points only if face count is 0

	if face_count != 0:
		rapi.rpgCommitTriangles(faces, noesis.RPGEODATA_USHORT, face_count, noesis.RPGEO_TRIANGLE, 1)
	else:
		rapi.rpgCommitTriangles(None, noesis.RPGEODATA_USHORT, int(vert_count / 3), noesis.RPGEO_POINTS, 1)	

	return 1

