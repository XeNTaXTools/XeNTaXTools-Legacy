import System;
import System.IO;	//Filesystem
import System.Drawing;	//Bitmap
/* ----- Helper Functions ----- */

var Reform32={
	tbl32bc:[0, 1, 4, 5, 16, 17, 20, 21, 2, 3, 6, 7, 18, 19, 22, 23, 8, 9, 12, 13, 24, 25, 28, 29, 10, 11, 14, 15, 26, 27, 30, 31],
	tbl32pao:[0, 1, 4, 5, 8, 9, 12, 13, 2, 3, 6, 7, 10, 11, 14, 15],
	Decode32:function(bin:byte[], bw:int, bh:int){
Console.WriteLine('Decode32-BEGIN');
		var buf:byte[] = new byte[bin.Length],
			i:int=0,j:int,k:int,m:int,n:int,p:int,
			c1:int,c2:int,c3:int,c4:int,c5:int,ind:int,indO:int;
		for(i=0;i<(32*bh);i+=32){
			for(j=0;j<(64*bw);j+=64){
				c1 = 8192 * ((j / 64) + (bw * (i / 32)));
				for(k=0;k<32;k+=8){
					for(m=0;m<64;m+=8){
						c2 = 256 * Reform32.tbl32bc[(m / 8) + ((k / 8) * 8)];
						for(n=0;n<4;n++){
							c3 = 64 * n;
							for(p=0;p<16;p++){
								c4 = (j + m) + (p % 8);
								c5 = int(((i + k) + (2 * n)) + (p / 8));
								ind = 4 * (c4 + ((64 * bw) * c5));
								indO = (((4 * Reform32.tbl32pao[p]) + c3) + c2) + c1;
								buf[ind] = bin[indO];
								buf[ind + 1] = bin[indO + 1];
								buf[ind + 2] = bin[indO + 2];
								buf[ind + 3] = bin[indO + 3];
							}
						}
					}
				}
			}
		}
Console.WriteLine('Decode32-END');
		return buf;
	},
	Encode32:function(bin:byte[], bw:int, bh:int){
Console.WriteLine('Encode32-BEGIN');
		var buf:byte[] = new byte[bin.Length],
			i:int=0,j:int,k:int,m:int,n:int,p:int,
			c1:int,c2:int,c3:int,c4:int,c5:int,ind:int,indO:int;
		for(i=0;i<(32*bh);i+=32){
			for(j=0;j<(64*bw);j+=64){
				c1 = 8192 * ((j / 64) + (bw * (i / 32)));
				for(k=0;k<32;k+=8){
					for(m=0;m<64;m+=8){
						c2 = int(256 * Reform32.tbl32bc[(m / 8) + ((k / 8) * 8)]);
						for(n=0;n<4;n++){
							c3 = 64 * n;
							for(p=0;p<16;p++){
								c4 = (j + m) + (p % 8);
								c5 = int(((i + k) + (2 * n)) + (p / 8));
								ind = 4 * (c4 + ((64 * bw) * c5));
								indO = (((4 * Reform32.tbl32pao[p]) + c3) + c2) + c1;
								buf[indO] = bin[ind];
								buf[indO + 1] = bin[ind + 1];
								buf[indO + 2] = bin[ind + 2];
								buf[indO + 3] = bin[ind + 3];
							}
						}
					}
				}
			}
		}
Console.WriteLine('Encode32-END');
		return buf;
	}
};
var Reform4={
	tbl4bc:[0, 2, 8, 10, 1, 3, 9, 11, 4, 6, 12, 14, 5, 7, 13, 15, 16, 18, 24, 26, 17, 19, 25, 27, 20, 22, 28, 30, 21, 23, 29, 31],
	tbl4col0:[0, 0x20, 0x80, 160, 0x100, 0x120, 0x180, 0x1a0, 8, 40, 0x88, 0xa8, 0x108, 0x128, 0x188, 0x1a8, 0x10, 0x30, 0x90, 0xb0, 0x110, 0x130, 400, 0x1b0, 0x18, 0x38, 0x98, 0xb8, 280, 0x138, 0x198, 440, 0x40, 0x60, 0xc0, 0xe0, 320, 0x160, 0x1c0, 480, 0x48, 0x68, 200, 0xe8, 0x148, 360, 0x1c8, 0x1e8, 80, 0x70, 0xd0, 240, 0x150, 0x170, 0x1d0, 0x1f0, 0x58, 120, 0xd8, 0xf8, 0x158, 0x178, 0x1d8, 0x1f8, 260, 0x124, 0x184, 420, 4, 0x24, 0x84, 0xa4, 0x10c, 300, 0x18c, 0x1ac, 12, 0x2c, 140, 0xac, 0x114, 0x134, 0x194, 0x1b4, 20, 0x34, 0x94, 180, 0x11c, 0x13c, 0x19c, 0x1bc, 0x1c, 60, 0x9c, 0xbc, 0x144, 0x164, 0x1c4, 0x1e4, 0x44, 100, 0xc4, 0xe4, 0x14c, 0x16c, 460, 0x1ec, 0x4c, 0x6c, 0xcc, 0xec, 340, 0x174, 0x1d4, 500, 0x54, 0x74, 0xd4, 0xf4, 0x15c, 380, 0x1dc, 0x1fc, 0x5c, 0x7c, 220, 0xfc],
	tbl4col1:[0x100, 0x120, 0x180, 0x1a0, 0, 0x20, 0x80, 160, 0x108, 0x128, 0x188, 0x1a8, 8, 40, 0x88, 0xa8, 0x110, 0x130, 400, 0x1b0, 0x10, 0x30, 0x90, 0xb0, 280, 0x138, 0x198, 440, 0x18, 0x38, 0x98, 0xb8, 320, 0x160, 0x1c0, 480, 0x40, 0x60, 0xc0, 0xe0, 0x148, 360, 0x1c8, 0x1e8, 0x48, 0x68, 200, 0xe8, 0x150, 0x170, 0x1d0, 0x1f0, 80, 0x70, 0xd0, 240, 0x158, 0x178, 0x1d8, 0x1f8, 0x58, 120, 0xd8, 0xf8, 4, 0x24, 0x84, 0xa4, 260, 0x124, 0x184, 420, 12, 0x2c, 140, 0xac, 0x10c, 300, 0x18c, 0x1ac, 20, 0x34, 0x94, 180, 0x114, 0x134, 0x194, 0x1b4, 0x1c, 60, 0x9c, 0xbc, 0x11c, 0x13c, 0x19c, 0x1bc, 0x44, 100, 0xc4, 0xe4, 0x144, 0x164, 0x1c4, 0x1e4, 0x4c, 0x6c, 0xcc, 0xec, 0x14c, 0x16c, 460, 0x1ec, 0x54, 0x74, 0xd4, 0xf4, 340, 0x174, 0x1d4, 500, 0x5c, 0x7c, 220, 0xfc, 0x15c, 380, 0x1dc, 0x1fc],
	Decode4:function(bin:byte[], bw:int, bh:int){
Console.WriteLine('Decode4-BEGIN');
		var buf:byte[] = new byte[bin.Length],
			i:int,j:int,k:int,m:int,n:int,p:int,c1:int,c2:int,c3:int,b2:int[],
			c4:int,c5:int,c6:byte,c7:int,c8:int,c9:int,ca:byte;
		for(i=0;i<(128*bh);i+=128){
			for(j=0;j<(128*bw);j+=128){
				c1 = 8192 * ((j / 128) + (bw * (i / 128)));
				for(k=0;k<128;k+=16){
					for(m=0;m<128;m+=32){
						c2 = 256 * Reform4.tbl4bc[(m / 32) + (4 * (k / 16))];
						for(n=0;n<4;n++){
							c3 = 64 * n;
							b2 = ((n & 1) === 0) ? Reform4.tbl4col0 : Reform4.tbl4col1;
							for(p=0;p<128;p++){

								c4 = int(b2[p] / 8);
								c5 = b2[p] % 8;
								c6 = (bin[((c1 + c2) + c3) + c4] >> c5) & 15;
								c7 = (j + m) + (p % 32);
								c8 = int(((i + k) + (4 * n)) + (p / 32));
								c9 = c7 + ((128 * bw) * c8);
								ca = byte(buf[int(c9 / 2)]);
								if((c9 & 1) === 0){
									ca = ca & 15;
									ca = ca | ((c6 << 4)&0xFF);
								}else{
									ca = ca & 240;
									ca = ca | c6;
								}
								buf[int(c9 / 2)] = ca;

							}
						}
					}
				}
			}
		}
Console.WriteLine('Decode4-END');
		return buf;
	},
	Encode4:function(bin:byte[], bw:int, bh:int){
Console.WriteLine('Encode4-BEGIN');
		var buf:byte[] = new byte[bin.Length],
			i:int,j:int,k:int,m:int,n:int,p:int,c1:int,c2:int,c3:int,b2:int[],
			c4:int,c5:int,c6:byte,c7:int,c8:int,c9:int,ca:byte,ind:int;
		for(i=0;i<(128*bh);i+=128){
			for(j=0;j<(128*bw);j+=128){
				c1 = 8192 * ((j / 128) + (bw * (i / 128)));
				for(k=0;k<128;k+=16){
					for(m=0;m<128;m+=32){
						c2 = 256 * Reform4.tbl4bc[(m / 32) + (4 * (k / 16))];
						for(n=0;n<4;n++){
							c3 = 64 * n;
							b2 = ((n & 1) === 0) ? Reform4.tbl4col0 : Reform4.tbl4col1;
							for(p=0;p<128;p++){
								c4 = (j + m) + (p % 0x20);
								c5 = int(((i + k) + (4 * n)) + (p / 0x20));
								c7 = c4 + ((0x80 * bw) * c5);
								c6 = bin[int(c7 / 2)];
								if ((c7 & 1) !== 0){
									c6 = (c6 & 15);
								}else{
									c6 = (c6 >> 4);
								}
								c8 = int(b2[p] / 8);
								c9 = b2[p] % 8;
								ind = ((c1 + c2) + c3) + c8;
								ca = buf[ind];
								switch(c9){
									case 0:
										ca = (ca & 240);
										ca = (ca | c6);
										break;
									case 4:
										ca = (ca & 15);
										ca = (ca | ((byte)(c6 << 4)));
										break;
								}
								buf[ind] = ca;
							}
						}
					}
				}
			}
		}
Console.WriteLine('Encode4-END');
		return buf;
	}
};


Console.WriteLine("Start");
function main(){
	var inp=Environment.GetCommandLineArgs(),l=0,i=null;
	if(inp.length>1){
		inp=inp[1];
		do{
			Console.WriteLine('Write file for Final mix [j] or US [u]?');
			i=Console.ReadLine().Trim().toLowerCase();
		}while(i!=='j'&&i!=='u');
		l=i==='j'?1892:1472;
		var bm:Bitmap = new Bitmap(inp),bin:byte[]=new byte[(512*512)+l],
			j,n,o,h=512;
		if(bm.Width!==512){
			Console.WriteLine("WIDTH MUST BE 512!");
			return;
		}else if(bm.Height!==1024){
			Console.WriteLine("HEIGHT MUST BE 1024!");
			return;
		}
		for(i=0;i<h;i++){
			for(j=0;j<512;j++){
				n = (Math.ceil(bm.GetPixel(j,i).G/16)*16)|0;
				o = (Math.ceil(bm.GetPixel(j,i+h).G/16)*16)|0;
				bin[j + (512 * i)] = (o&0xC0) | ((n&0xC0) >> 2) | ((o&0x30) >> 2) | ((n&0x30) >> 4);
			}
		}
		//bin matches here [1]
		//File.WriteAllBytes('outE',bin);
		h=1024/128;
		bin = Reform32.Decode32(Reform4.Encode4(bin,4,h), 4, h);
		Console.Write("Import file for widths? (If no, 0 is used for all characters): ");
		
		if(File.Exists(j=inp.replace(/\.bmp$/,'.dat'))){i=j;Console.WriteLine(''+j);}else{i=Console.ReadLine();}
		if(File.Exists(i)){
			i=File.ReadAllBytes(i);
			if(i.length!==l){
				Console.WriteLine('File has length '+i.length+', but this file needs '+l+'!\Using 0s!');
			}else{
				for(j=0;j<l;j++){
					bin[j+262144]=i[j];
				}
				Console.WriteLine("Copied!");
			}
		}else{Console.WriteLine("Using 0s!");}
		
		File.WriteAllBytes('NEW-kanji.knj',bin);
	}else{Console.Write('Drag-and-Drop a BMP onto this program to convert it!\n');}
}main();

Console.WriteLine("End\nPress enter to exit...");Console.Read();