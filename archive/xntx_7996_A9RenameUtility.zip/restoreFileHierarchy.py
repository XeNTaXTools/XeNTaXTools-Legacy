import os,sys

argc = len(sys.argv)
if argc > 1 and sys.argv[1] == '-h':
	print('Usage: python %s [map_file] [input_dir] [output_dir]'%sys.argv[0])
	exit(0)
mapFile='manifest.map'
inDir = '.'
outDir = '.'
if argc > 1:
	mapFile = sys.argv[1]
if argc > 2:
	inDir = sys.argv[2]
if argc > 3:
	outDir = sys.argv[3]
inDir += '/'
if not os.path.exists(mapFile):
	print('file %s not found!'%mapFile)
	exit(1)
fp=open(mapFile, "r")
print('renaming files...')
renamed = 0
total = 0
for line in fp.readlines():
	pairs = line.strip().split(':')
	oldName = inDir + pairs[0]
	newName = outDir + pairs[1]
	total += 1
	if os.path.exists(oldName):
		os.renames(oldName, newName)
		renamed += 1
print('done.')
print('statistics: renamed %d files among %d in list.'%(renamed, total))