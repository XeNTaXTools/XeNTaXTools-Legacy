﻿#AC: Origins .DAT [PC] - ".DAT" Loader
#v1.0 by zaramot

from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("AC: Origins 2D Texture [PC]", ".dat")
	noesis.setHandlerTypeCheck(handle, datCheckType)
	noesis.setHandlerLoadRGBA(handle, datLoadDDS)
	noesis.logPopup()
	return 1
		
def datCheckType(data):
	bs = NoeBitStream(data)
	fileMagic = bs.readUInt()
	if fileMagic == 0xa2b7e917:
		return 1
	else: 
		print("Fatal Error: Unknown file magic: " + str(hex(fileMagic) + " expected 0xa2b7e917!"))
		return 0

def datLoadDDS(data, texList):
	bs = NoeBitStream(data)
	
	numTextures  = 1
	fileMagic = bs.readUInt()
	fileUnk00  = bs.readUShort()
	fileUnk01  = bs.readUShort()
	ddsNameSize = bs.readUInt()
	#print (ddsNameSize)
	
	for i in range (1):
		ddsName = bs.readString()
		bs.seek((0x47), NOESEEK_REL)
		MipType =  bs.readUInt()
		#MipType
		if MipType == 0:
		    bs.seek((0x2F), NOESEEK_REL)
		    ddsWidth =  bs.readUInt()
		    ddsHeight =  bs.readUInt()
		#MipType
		elif MipType != 0:
		    bs.seek((0x11), NOESEEK_REL)
		    MipType2 =  bs.readUInt()
		    #MipType2
		    if MipType2 == 0:
		        bs.seek((0x1A), NOESEEK_REL)
		        ddsWidth =  bs.readUInt()//2
		        ddsHeight =  bs.readUInt()//2
		    #MipType2
		    elif MipType2 != 0:
		        bs.seek((0x1A), NOESEEK_REL)
		        ddsWidth =  bs.readUInt()//4
		        ddsHeight =  bs.readUInt()//4
		bs.seek((0xC), NOESEEK_REL)
		dxtType = bs.readUInt()
		bs.seek((0x1D), NOESEEK_REL)
		ddsSize = bs.readUInt()
		print (MipType)
		print (ddsName)
		print (ddsSize)
		print (dxtType)
		ddsData = bs.readBytes(ddsSize)	  
		#DXT1
		if dxtType == 2:
		    ddsFmt = noesis.NOESISTEX_DXT1
		#DXT1
		elif dxtType == 3:
		    ddsFmt = noesis.NOESISTEX_DXT1
		#DXT5
		elif dxtType == 5:
		    ddsFmt = noesis.NOESISTEX_DXT5
		#ATI1
		elif dxtType == "ATI1":
		    ddsData = rapi.imageDecodeDXT(ddsData, ddsWidth, ddsHeight, noesis.FOURCC_ATI1)
		    ddsFmt = noesis.NOESISTEX_RGBA32	
		#ATI2
		elif dxtType == "ATI2":
		    ddsData = rapi.imageDecodeDXT(ddsData, ddsWidth, ddsHeight, noesis.FOURCC_ATI2)
		    ddsFmt = noesis.NOESISTEX_RGBA32	
		#BC7
		elif dxtType == 9:
		    ddsData = rapi.imageDecodeDXT(ddsData, ddsWidth, ddsHeight, noesis.FOURCC_BC7)
		    ddsFmt = noesis.NOESISTEX_RGBA32
		#print (ddsType)   
		#print (dxtType)      
		texList.append(NoeTexture(ddsName, ddsWidth, ddsHeight, ddsData, ddsFmt))
	return 1
	