#ifndef __XENTAX_AMC_H
#define __XENTAX_AMC_H

struct AMCVERTEX {
};

struct ADVANCEDMODELCONTAINER {
};


bool GeometryToLWO(const char* path, const char* name, const ADVANCEDMODELCONTAINER& data);

#endif
