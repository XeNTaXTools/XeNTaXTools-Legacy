#ifndef __XENTAX_DDS_H
#define __XENTAX_DDS_H

typedef struct {
  DWORD dwSize;
  DWORD dwFlags;
  DWORD dwFourCC;
  DWORD dwRGBBitCount;
  DWORD dwRBitMask;
  DWORD dwGBitMask;
  DWORD dwBBitMask;
  DWORD dwABitMask;
} DDS_PIXELFORMAT, DDSPF;

typedef struct {
  DWORD dwSize;
  DWORD dwFlags;
  DWORD dwHeight;
  DWORD dwWidth;
  DWORD dwPitchOrLinearSize;
  DWORD dwDepth;
  DWORD dwMipMapCount;
  DWORD dwReserved01;
  DWORD dwReserved02;
  DWORD dwReserved03;
  DWORD dwReserved04;
  DWORD dwReserved05;
  DWORD dwReserved06;
  DWORD dwReserved07;
  DWORD dwReserved08;
  DWORD dwReserved09;
  DWORD dwReserved10;
  DWORD dwReserved11;
  DDSPF ddspf;
  DWORD dwCaps1;
  DWORD dwCaps2;
  DWORD dwCaps3;
  DWORD dwCaps4;
  DWORD dwReserved12;
} DDS_HEADER;

BOOL CreateUncompressedDDSHeader(DWORD dx, DWORD dy, DWORD mipmaps, DWORD maskR, DWORD maskG, DWORD maskB, DWORD maskA, BOOL cubemap, DDS_HEADER* header);
BOOL CreateDXT1Header(DWORD dx, DWORD dy, DWORD mipmaps, BOOL cubemap, DDS_HEADER* header);
BOOL CreateDXT2Header(DWORD dx, DWORD dy, DWORD mipmaps, BOOL cubemap, DDS_HEADER* header);
BOOL CreateDXT3Header(DWORD dx, DWORD dy, DWORD mipmaps, BOOL cubemap, DDS_HEADER* header);
BOOL CreateDXT4Header(DWORD dx, DWORD dy, DWORD mipmaps, BOOL cubemap, DDS_HEADER* header);
BOOL CreateDXT5Header(DWORD dx, DWORD dy, DWORD mipmaps, BOOL cubemap, DDS_HEADER* header);

DWORD UncompressedDDSFileSize(DWORD dx, DWORD dy, DWORD mipmaps, DWORD maskR, DWORD maskG, DWORD maskB, DWORD maskA);
DWORD DXT1Filesize(DWORD dx, DWORD dy, DWORD mipmaps);
DWORD DXT2Filesize(DWORD dx, DWORD dy, DWORD mipmaps);
DWORD DXT3Filesize(DWORD dx, DWORD dy, DWORD mipmaps);
DWORD DXT4Filesize(DWORD dx, DWORD dy, DWORD mipmaps);
DWORD DXT5Filesize(DWORD dx, DWORD dy, DWORD mipmaps);

BOOL SaveDDSFile(const char* filename, const DDS_HEADER& ddsh, boost::shared_array<char> data, uint32 size);

#endif
