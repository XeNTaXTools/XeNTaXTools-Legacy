#ifndef __XENTAX_SMC_H
#define __XENTAX_SMC_H

#include "x_skel.h"

//
// VERTEX DATA
//

#define VERTEX_POSITION 0x01
#define VERTEX_NORMAL   0x02
#define VERTEX_UV       0x04
#define VERTEX_WEIGHTS  0x08
#define VERTEX_BONEIDX  0x10
#define VERTEX_WMAPIDX  0x20
#define VERTEX_SKELETON 0x40

#define INVALID_VERTEX_BONE_INDEX 0xFFFF
#define INVALID_VERTEX_WMAP_INDEX 0xFFFF
#define INVALID_VERTEX_SKEL_INDEX 0xFFFF

struct SMC_VERTEX {
 real32 vx, vy, vz;
 real32 nx, ny, nz;
 real32 tu, tv;
 uint16 wv[8];
 union { uint16 bi[8]; uint16 mi[8]; };
 uint16 si[8];
};

struct SMC_VERTEX_BUFFER {
 unsigned char flags;
 std::string name;
 uint32 elem;
 boost::shared_array<SMC_VERTEX> data;
};

//
// RENDER DATA
//

#define FACE_FORMAT_UINT_08   0x1
#define FACE_FORMAT_UINT_16   0x2
#define FACE_FORMAT_UINT_32   0x4

#define FACE_TYPE_TRIANGLES   0x1
#define FACE_TYPE_TRISTRIP    0x2
#define FACE_TYPE_TRISTRIPCUT 0x4

struct SMC_INDEX_BUFFER {
 unsigned char format;
 unsigned char type;
 std::string name;
 uint32 elem;
 boost::shared_array<char> data;
 uint32 tris;
 uint16 material;
};

//
// MATERIAL DATA
//

#define INVALID_MATERIAL 0xFFFF
#define INVALID_TEXTURE_INDEX 0xFFFF

struct SMC_MATERIAL {
 std::string id; // identifier
 uint08 twoside; // double-sided
 uint16 basemap; // reference to texture id
 uint16 specmap; // reference to texture id
 uint16 tranmap; // reference to texture id
 uint16 bumpmap; // reference to texture id
 uint16 normmap; // reference to texture id
 uint16 resmap1; // reserved1
 uint16 resmap2; // reserved2
 uint16 resmap3; // reserved3
 uint16 resmap4; // reserved4
};

struct SMC_TEXTURE {
 std::string id;
 std::string filename;
};

//
// SKELETON DATA
//

typedef SKELETON SMC_SKELETON;

//
// MODEL DATA
//

struct SIMPLEMODELCONTAINER {
 SMC_VERTEX_BUFFER vbuffer;
 std::deque<SMC_INDEX_BUFFER> ibuffer;
 std::deque<SMC_TEXTURE> textures;
 std::deque<SMC_MATERIAL> materials;
 std::deque<SMC_SKELETON> skeletons;
};

bool SaveLWO(const char* path, const char* name, const SIMPLEMODELCONTAINER& data);

#endif
