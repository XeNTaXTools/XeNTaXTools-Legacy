#ifndef __XENTAX_AFS_H
#define __XENTAX_AFS_H

bool ExtractAFS(const char* filename);

#endif
