#include "xentax.h"
#include "template.h"

#define X_SYSTEM PS3
#define X_GAME   ONE_PIECE

namespace X_SYSTEM { namespace X_GAME {

class extractor {
 private :
  std::string pathname;
 private :
 public :
  bool extract(void);
 public :
  extractor(const char* pn) : pathname(pn) {}
 ~extractor() {}
};

};};

namespace X_SYSTEM { namespace X_GAME {

bool extractor::extract(void)
{
 return true;
}

};};

namespace X_SYSTEM { namespace X_GAME {

bool extract(void)
{
 char pathname[MAX_PATH];
 GetModulePathname(pathname, MAX_PATH);
 return extract(pathname);
}

bool extract(const char* pathname)
{
 return extractor(pathname).extract();
}

};};