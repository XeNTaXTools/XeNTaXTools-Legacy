#ifndef __XENTAX_KARY_H
#define __XENTAX_KARY_H

struct KAryTreeData {
 size_t type;
 KAryTreeData(size_t id = 0) : type(id) {}
 virtual ~KAryTreeData() { std::cout << "Deleting KAryTreeData..." << std::endl; }
};

struct KAryTreeNode {
 typedef KAryTreeData* data_t;
 data_t data;
 std::deque<size_t> children;
};

class KAryTree {
 private :
  std::deque<KAryTreeNode> list;
 public :
  KAryTree()
  {
  }
 ~KAryTree()
  {
   for(size_t i = 0; i < list.size(); i++) {
       delete list[i].data;
       list[i].data = nullptr;
      }
  }
 public :
  bool insert(KAryTreeData* item, uint32 parent)
  {
   // this is not root
   if(parent != 0xFFFFFFFF) {
     }
   // this is root
   else if(list.size())
      return false;

   // insert into list
   KAryTreeNode node;
   node.data = item;
   list.push_back(node);

   return true;
  }
 private :
  KAryTree(const KAryTree&);
  void operator =(const KAryTree&);
};

#endif
