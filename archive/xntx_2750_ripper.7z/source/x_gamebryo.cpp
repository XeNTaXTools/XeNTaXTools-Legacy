#include "xentax.h"

namespace Gamebryo {

class extractor {
 private :
  std::string pathname;
 private :
 public :
  bool extract(void);
  void clear(void);
 public :
  extractor(const char* path);
 ~extractor();
};

extractor::extractor(const char* path) : pathname(path)
{
}

extractor::~extractor()
{
}

bool extractor::extract(void)
{
 // clear previous
 clear();

 return true;
}

void extractor::clear(void)
{
}

};

namespace Gamebryo {

bool extract(void)
{
 char pathname[MAX_PATH];
 GetModulePathname(pathname, MAX_PATH);
 return extract(pathname);
}

bool extract(const char* pathname)
{
 return extractor(pathname).extract();
}

};