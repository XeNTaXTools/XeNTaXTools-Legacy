#ifndef __XENTAX_MAX_H
#define __XENTAX_MAX_H

//bool GeometryToMAX(const char* path, const char* name, const SIMPLEMODELCONTAINER& data);
//bool GeometryToDAE(const char* path, const char* name, const SIMPLEMODELCONTAINER& data);

#endif
