#ifndef __XENTAX_MATH_H
#define __XENTAX_MATH_H

template<class T>
void matrix4x4_transpose(T* m)
{
 T temp;
 temp = m[ 1]; m[ 1] = m[ 4]; m[ 4] = temp;
 temp = m[ 2]; m[ 2] = m[ 8]; m[ 8] = temp;
 temp = m[ 3]; m[ 3] = m[12]; m[12] = temp;
 temp = m[ 6]; m[ 6] = m[ 9]; m[ 9] = temp;
 temp = m[ 7]; m[ 7] = m[13]; m[13] = temp;
 temp = m[11]; m[11] = m[14]; m[14] = temp;
}

#endif
