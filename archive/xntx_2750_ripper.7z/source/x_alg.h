#ifndef __XENTAX_ALG_H
#define __XENTAX_ALG_H

template<class T>
bool minimum(const T* data, size_t elem, T& item)
{
 if(!data) return false;
 if(!elem) return false;
 item = data[0];
 for(size_t i = 1; i < elem; i++) if(data[i] < item) item = data[i];
 return true;
}

template<class T>
bool maximum(const T* data, size_t elem, T& item)
{
 if(!data) return false;
 if(!elem) return false;
 item = data[0];
 for(size_t i = 1; i < elem; i++) if(item < data[i]) item = data[i];
 return true;
}

#endif
