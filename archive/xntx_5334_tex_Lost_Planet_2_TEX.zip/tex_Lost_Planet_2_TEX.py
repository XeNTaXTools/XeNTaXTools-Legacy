#Lost Planet 2 [PC] .TEX [PC] - ".TEX" Loader
#By Zaramot
#modified and rearranged further by Acewell :)
#v1.02

from inc_noesis import *
import subprocess

def registerNoesisTypes():
	handle = noesis.register("Lost Planet 2 [PC]", ".tex")
	noesis.setHandlerTypeCheck(handle, texCheckType)
	noesis.setHandlerLoadRGBA(handle, texLoadDDS)
	#noesis.logPopup()
	return 1
		
def texCheckType(data):
	bs = NoeBitStream(data)
	fileMagic = bs.readUInt()
	if fileMagic != 0x584554:
		return 0
	return 1

def texLoadDDS(data, texList):
    bs = NoeBitStream(data)
    dataSize = len(data) - 0x30
    bs.seek(0xA, NOESEEK_ABS) 
    imgHeight = (bs.readUShort()) // 2
    bs.seek(0xC, NOESEEK_ABS)
    TWidth = bs.readUShort()
    if TWidth == 0x72:
        imgWidth = 2048
    elif TWidth == 10240:
        imgWidth = 2048
    elif TWidth == 9216:
	    imgWidth = 1024
    elif TWidth == 8704:
	    imgWidth = 512
    elif TWidth == 8448:
	    imgWidth = 256		
    elif TWidth == 8320:
	    imgWidth = 128
    elif TWidth == 8256:
	    imgWidth = 64
    elif TWidth == 8200:
	    imgWidth = 8
    bs.seek(0x10, NOESEEK_ABS) #DXT1 / DXT5
    imgFmt = bs.readUInt()
    bs.seek(0x14, NOESEEK_ABS)
    dataOff = (bs.readUInt())
    bs.seek(dataOff, NOESEEK_ABS) #data start			
    data = bs.readBytes(dataSize)
    #DXT1
    if imgFmt == 0x13 or imgFmt == 0x19:
        texFmt = noesis.NOESISTEX_DXT1
    #DXT5
    elif imgFmt == 0x17 or imgFmt == 0x1f:
        texFmt = noesis.NOESISTEX_DXT5
    else:
        print("WARNING: Unhandled image format")		
    tex = (NoeTexture(rapi.getInputName(), imgHeight, imgWidth, data, texFmt))
    texList.append(tex)
    return 1	