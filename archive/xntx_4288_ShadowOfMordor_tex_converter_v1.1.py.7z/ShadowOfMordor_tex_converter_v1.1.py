
import struct
import os

array_tex=[]

#manual_mode = True
#manual_format="DXT5"
#path_Directory = "D:\\Program Files\\Middle-earth. Shadow of Mordor\\Arch05\\!!Unpack\\models\\weapons\\player_weapons\\player_sword01\\"
path_Directory = raw_input("Path to the directory? (finish on the \"\\\") ")


for root, dirs, files in os.walk(path_Directory):
    for name in files:
        fullname = os.path.join(root, name)

        if fullname.endswith('tex') or fullname.endswith('tex0'):

           #-- try:
                print ("fullname:  "+fullname)
                x = fullname

                print ("\nFILE:   " + x)

                path_tex = x



                file_tex = open(path_tex, 'rb')


                file_tex.seek(0,os.SEEK_END)
                file_tex_size=file_tex.tell()

                print  ("file_tex_size: " + hex(file_tex_size))


                file_tex.seek(0x10,os.SEEK_SET)
                file_path_lenght = struct.unpack('<H', file_tex.read(2))[0]
                file_path = file_tex.readline(file_path_lenght)
                print  ("file_path: " + str(file_path))
                file_tex.seek(0xF,os.SEEK_CUR)
                height = struct.unpack('<i', file_tex.read(4))[0]
                width = struct.unpack('<i', file_tex.read(4))[0]

                print  ("width: " + str(width))
                print  ("height: " + str(height))

                file_tex.seek(0x40,os.SEEK_CUR)
                format =  file_tex.read(4)
                print("format: " + format)

                Data_lenght = 0
                if (format == "DXT5"): Data_lenght = width * height
                if (format == "DXT1"): Data_lenght = width * height / 2
                file_tex.seek(0x28,os.SEEK_CUR)


 




            #DDS Generated
                path_DDS =  x + ".dds"
                file_DDS = open(path_DDS, 'wb')


                # magic number
                ID_format = 0x20534444 #('DDS ') - 4 byte
                # DDS header
                dwSize = 0x7C           # 0x04
                dwFlags = 0x00081007    # 0x08
                dwHeight = height    # 0x0C
                dwWidth = width     # 0x10
                dwPitchOrLinearSize = Data_lenght # 0x14
                dwDepth = 0             # 0x18
                dwMipMapCount = 0       # 0x1c
                dwReserved1 = 11        # 0x20-0x4C

                ddspf_dwSize = 0x20     # 0x4C
                ddspf_dwFlags =  0x04   # 0x50

                ddspf_dwFourCC=format

                #ddspf_dwFourCC = 0x00   # 0x58
                ddspf_dwRGBBitCount = 0x00 #0x5C
                ddspf_dwRBitMask = 0x00 #0x60
                ddspf_dwGBitMask = 0x00 #0x64
                ddspf_dwBBitMask = 0x00 #0x68
                ddspf_dwABitMask = 0x00 #0x6c


                dwCaps =  0x1000
                dwCaps2 = 0x00
                dwCaps3 = 0x00
                dwCaps4 = 0x00
                dwReserved2 = 0x00

                #print (tex_hight)
                #print (tex_width)

                file_DDS.write( struct.pack( 'I', ID_format ) )
                file_DDS.write( struct.pack( 'I', dwSize ) )
                file_DDS.write( struct.pack( 'I', dwFlags ) )
                file_DDS.write( struct.pack( 'I', dwHeight ) )
                file_DDS.write( struct.pack( 'I', dwWidth ) )
                file_DDS.write( struct.pack( 'I', dwPitchOrLinearSize ) )
                file_DDS.write( struct.pack( 'I', dwDepth ) )
                file_DDS.write( struct.pack( 'I', dwMipMapCount ) )

                for i in range(dwReserved1):
                    file_DDS.write( struct.pack( 'I', 0 ) )


                file_DDS.write( struct.pack( 'I', ddspf_dwSize ) )
                file_DDS.write( struct.pack( 'I', ddspf_dwFlags ) )
                file_DDS.write(ddspf_dwFourCC)
                #file_DDS.write( struct.pack( 'I', ddspf_dwFourCC ) )
                file_DDS.write( struct.pack( 'I', ddspf_dwRGBBitCount ) )
                file_DDS.write( struct.pack( 'I', ddspf_dwRBitMask ) )
                file_DDS.write( struct.pack( 'I', ddspf_dwGBitMask ) )
                file_DDS.write( struct.pack( 'I', ddspf_dwBBitMask ) )
                file_DDS.write( struct.pack( 'I', ddspf_dwABitMask ) )

                file_DDS.write( struct.pack( 'I', dwCaps ) )
                file_DDS.write( struct.pack( 'I', dwCaps2 ) )
                file_DDS.write( struct.pack( 'I', dwCaps3 ) )
                file_DDS.write( struct.pack( 'I', dwCaps4 ) )
                file_DDS.write( struct.pack( 'I', dwReserved2 ) )

                #file_tex.seek(Data_offset,os.SEEK_SET)
                byte_data=file_tex.read(Data_lenght)
                file_DDS.write(byte_data)

                #for i in range(file_tg4d_size):
                #    byte_data=file_tg4h.read(4))[0]
                #    file_DDS.write( struct.pack( 'I', 0 ) )


                file_DDS.close()
                file_tex.close()

           # --except Exception:
           # --    print ("ERRORR:: fullname:  "+fullname)
print ("end of dds creating")