#by Durik256 02.03.2022 for xentax
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("chuanshuo OL",".mesh")
    noesis.setHandlerTypeCheck(handle, CheckType)
    noesis.setHandlerLoadModel(handle, LoadModel)    
    return 1
    
def CheckType(data):
    bs = NoeBitStream(data)
    if noeAsciiFromBytes(bs.readBytes(8)) != 'MESH2.00':
        return 0
    return 1

def LoadModel(data, mdlList):
    ctx = rapi.rpgCreateContext()
    bs = NoeBitStream(data)
    bs.seek(12)
    
    vCount = bs.readUInt()
    
    vbuffer = bs.readBytes(vCount*12)
    nbuffer = bs.readBytes(vCount*12)

    bs.seek(vCount*4, NOESEEK_REL)

    unkCount = bs.readUInt()
    bs.seek(unkCount*16, NOESEEK_REL)
       
    bs.readUInt()
    fCount = bs.readUInt()
    print("fCount:", fCount)
    
    faces = b''
    bs.seek(36, NOESEEK_REL)
    for x in range(fCount):
        faces += bs.readBytes(12)
        bs.seek(24, NOESEEK_REL)
    
    rapi.rpgBindPositionBuffer(vbuffer, noesis.RPGEODATA_FLOAT,12)
    rapi.rpgCommitTriangles(faces, noesis.RPGEODATA_UINT, fCount*3, noesis.RPGEO_TRIANGLE)

    mdl = rapi.rpgConstructModel()
    mdlList.append(mdl) 
    return 1