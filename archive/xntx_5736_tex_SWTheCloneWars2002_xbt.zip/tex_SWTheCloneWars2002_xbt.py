from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Star Wars: The Clone Wars 2002", ".xbt")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    return 1
    
def noepyLoadRGBA(data, texList):
    datasize = len(data) - 0x20        
    bs = NoeBitStream(data)
    imgWidth = bs.readInt()            
    imgHeight = bs.readInt()
    print(imgWidth, "x", imgHeight)
    bs.seek(0x0C, NOESEEK_ABS)         
    imgFmt = bs.readByte()
    print(imgFmt, ":imgFmt")
    bs.seek(0x20, NOESEEK_ABS)         
    data = bs.readBytes(datasize)      
    #DXT1
    if imgFmt == 12:
        texFmt = noesis.NOESISTEX_DXT1
    #DXT3
    elif imgFmt == 14:
        texFmt = noesis.NOESISTEX_DXT3
    #morton order swizzled raw alpha 
    elif imgFmt == 4:
        untwid = bytearray()
        for x in range(imgWidth):
            for y in range(imgHeight):
                idx = noesis.morton2D(x, y)
                untwid += data[idx * 2:idx * 2 + 4]
        data = rapi.imageDecodeRaw(untwid, imgWidth, imgHeight, "g8 b8 r8 p8")
        texFmt = noesis.NOESISTEX_RGBA32
    #morton order swizzled raw alpha 
    elif imgFmt == 5:
        untwid = bytearray()
        for x in range(imgWidth):
            for y in range(imgHeight):
                idx = noesis.morton2D(x, y)
                untwid += data[idx * 2:idx * 2 + 4]
        data = rapi.imageDecodeRaw(untwid, imgWidth, imgHeight, "p8 g8 b8 r8")
        texFmt = noesis.NOESISTEX_RGBA32
    #unknown, not handled
    else:
        print("WARNING: Unhandled image format")
        return None
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1