import newGameLib
from newGameLib import *
import Blender
import math
from math import *


unpackDir="E:\\Games\\Castlevania Lords of Shadow - Mirror of Fate HD"
		


blendDir=os.path.dirname(Blender.Get('filename'))
toolDir=blendDir+os.sep+'newgameLib'+os.sep+'tools'
		

def bcmdlParser(filename,g):	
	skeleton=Skeleton()
	skeleton.BONESPACE=True
	skeleton.NICE=True	
	meshList=[]
	matList=[]
	texList={}
	faceList={}
	
	g.endian='<'
	g.word(4)
	g.i(1)[0]
	
	offsetListLevel0=[]
	while(True):
		offset=g.i(1)[0]
		if offset!=0:
			offsetListLevel0.append(offset)
		else:
			break
		
	id=0
	for offset in offsetListLevel0:	
		g.seek(offset)
		offsetListLevel1=[]
		while(True):
			w=g.i(2)
			offsetListLevel1.append(w)
			if w[1]==0:	break
		if id==0:
			for offset in offsetListLevel1:
				g.seek(offset[0])
				g.i(4)
		if id==1:
			for offset in offsetListLevel1:
				g.seek(offset[0])
				g.i(4)
		if id==2:
			offsetListLevel2=[]
			for offset in offsetListLevel1:
				g.seek(offset[0])
				offset2=g.i(4)+g.H(2)+g.i(3)
				g.seek(offset2[8])
				if offset2[1]==0:
					mesh=Mesh()
					for m in range(offset2[7]):
						mesh.vertPosList.append(g.f(3))
						mesh.skinIndiceList.append([0,0,0,0])
						mesh.skinWeightList.append([0,0,0,0])
						mesh.skinIDList.append(None)
					meshList.append(mesh)
				if offset2[1]==2:
					for m in range(offset2[7]):
						mesh.vertUVList.append(g.f(2))
				if offset2[1]==6:
					for m in range(offset2[7]):
						for n in range(offset2[5]):
							mesh.skinIndiceList[m][n]=int(g.f(1)[0])
				if offset2[1]==7:
					for m in range(offset2[7]):
						for n in range(offset2[5]):
							mesh.skinWeightList[m][n]=g.f(1)[0]
						
						
				
		if id==3:
			offsetListLevel2=[]
			for offset in offsetListLevel1:
				g.seek(offset[0])
				w=g.i(6)
				offsetListLevel2.append(w)
			for offset in offsetListLevel2:
				g.seek(offset[5])
				faceList[str(offset[0])]=[]
				for m in range(offset[1]/3):
					faceList[str(offset[0])].append(g.H(3))
				
				
		if id==4:
			for i,offset in enumerate(offsetListLevel1):
				mesh=meshList[i]
				mesh.matHash=offset[0]
				g.seek(offset[0])
				Matrix(g.f(4),g.f(4),g.f(4),g.f(4))
				TranslationMatrix(Vector(g.f(3)))
				w=g.i(4)
				t=g.tell()				
				#w3
				g.seek(w[3])
				u=g.i(1)[0]	
				g.seek(u)
				for m in range(w[2]):
					mat=Mat()
					mat.TRIANGLE=True
					u=g.i(4)
					faces=faceList[str(u[0])]
					mesh.faceList.extend(faces)
					for n in range(len(faces)):
						mesh.matIDList.append(m)
					for n in range(len(faces)):
						for k in range(3):						
							vertID=faces[n][k]
							mesh.skinIDList[vertID]=m
					mesh.matList.append(mat)
					tu=g.tell()
					g.seek(u[3])
					skin=Skin()
					skin.boneMap=g.i(u[2])
					mesh.skinList.append(skin)
					g.seek(tu)
					
				g.seek(t)
				posmatrix=TranslationMatrix(Vector(g.f(3)))
				mesh.matrix=posmatrix
				
		if id==5:
			List=[]
			for offset in offsetListLevel1:
				g.seek(offset[0])
				w=g.i(5)
				List.append([w,offset])
			for list in List:
				diffuse=None
				g.seek(list[0][0])
				g.find('\x00')
				g.seek(list[0][1])
				g.find('\x00')
				diff=g.find('\x00')+'.bctex'
				search=Searcher()
				search.dir=unpackDir
				search.what=diff
				if os.path.exists(search.dir)==True:
					search.run()
					if len(search.list)>0:
						command=toolDir+os.sep+"bctex2dds.exe "+'"'+search.list[0]+'"'
						os.system(command)
						diffuse=search.list[0].replace('.bctex','.dds')
				
				texList[list[1][0]]=diffuse
				g.seek(63,1)
				g.find('\x00')
				
				
		if id==6:
			for offset in offsetListLevel1:
				g.seek(offset[0])
				w=g.i(5)
				mat=Mat()
				mat.hash=w[0]
				mat.diffuse=texList[w[1]]
				matList.append(mat)
		if id==8:
		
			for offset in offsetListLevel1:
				g.seek(offset[0])
				#g.tell()
				bone=Bone()
				posMatrix=VectorMatrix(g.f(3))
				rx=degrees(g.f(1)[0])
				ry=degrees(g.f(1)[0])
				rz=degrees(g.f(1)[0])
				rotMatrix=Euler(rx,ry,rz).toMatrix().resize4x4()
				matrix=rotMatrix*posMatrix
				bone.matrix=matrix#.invert()
				g.f(19)
				skeleton.boneList.append(bone)
				
					
		if id==9:
			for offset in offsetListLevel1:
				g.seek(offset[0])
				offsetListLevel2=[]
				while(True):
					w=g.i(2)
					#print id,w
					offsetListLevel2.append(w)
					if w[1]==0:	break
				for i,offset2 in enumerate(offsetListLevel2):
					g.seek(offset2[0])
					bone=skeleton.boneList[i]
					a,b,c,d,e=g.i(5)
					
					g.seek(b)
					bone.name=g.find('\x00')[-25:]
					if c!=0:
						g.seek(c)
						bone.parentName=g.find('\x00')[-25:]
				break		
			
		
			
			
		id+=1
		
	skeleton.draw()
	for i,mesh in enumerate(meshList):
		mesh.boneNameList=skeleton.boneNameList
		mesh.BINDSKELETON=skeleton.name
		for mat in matList:
			if mat.hash==mesh.matHash:
				for emat in mesh.matList:
					emat.diffuse=mat.diffuse
		mesh.draw()

	
def Parser():	
	filename=input.filename
	ext=filename.split('.')[-1].lower()	
	
	if ext=='bcmdl':
		file=open(filename,'rb')
		g=BinaryReader(file)
		bcmdlParser(filename,g)
		file.close()
 
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
	
Blender.Window.FileSelector(openFile,'import','*.bcmdl')