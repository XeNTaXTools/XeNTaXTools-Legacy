from inc_noesis import *

# debug level
# 0 - info/warn/error messages (hidden)
# 1 - 0 + pop up Noesis Debug Log
# 2 - 1 + some debug variables
DEBUGLEVEL = 1
#-------------------------------------------------------------------------------
def registerNoesisTypes():
    handle = noesis.register("Spirit Hunter DAT", ".dat")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)

    handle2 = noesis.register("Spirit Hunter EXG", ".exg")
    noesis.setHandlerTypeCheck(handle2, noepyCheckType)

    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    noesis.setHandlerLoadRGBA(handle2, noepyLoadRGBA)
    if DEBUGLEVEL >= 1: noesis.logPopup()
    return 1
#-------------------------------------------------------------------------------
def noepyCheckType(data):
    global HeaderOffset, fileSize
    MAGIC = b"EXGr"

    # open file
    with open(rapi.getInputName(), 'rb') as f:
        s = f.read()
        f.seek(0, 2)
        fileSize = f.tell()
        f.close()

    # find all instances of MAGIC first and save their offsets
    HeaderOffset = []
    StartPoint = 0
    while s.find(MAGIC, StartPoint) != -1:
        HeaderOffset.append(s.find(MAGIC, StartPoint))
        StartPoint = HeaderOffset[len(HeaderOffset)-1]+1

    if len(HeaderOffset) > 0: return 1
    else: print("[x] No EXGr headers found."); return 0
#-------------------------------------------------------------------------------
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.setEndian(0)

    print("[i] EXGr Headers: "+repr(len(HeaderOffset))+".")
    if DEBUGLEVEL >= 2: print("[DEBUG] Header offsets: "+repr(HeaderOffset))

    for i in range(len(HeaderOffset)):
        bs.seek(HeaderOffset[i], 0)
        bs.readBytes(8)

        # subheader seeker
        SubHeaderOffset = [bs.tell()]
        dataSize = 0
        while (SubHeaderOffset[len(SubHeaderOffset)-1] + dataSize + 0x20) < fileSize:
            dataSize = bs.readUInt()
            if ((SubHeaderOffset[len(SubHeaderOffset)-1] + dataSize + 0x20) < fileSize):
                SubHeaderOffset.append(SubHeaderOffset[len(SubHeaderOffset)-1] + dataSize + 0x20)
            bs.seek(SubHeaderOffset[len(SubHeaderOffset)-1])

        if DEBUGLEVEL >= 2: print("[DEBUG] Subheader offsets: "+repr(SubHeaderOffset))

        for j in range(len(SubHeaderOffset)):
            bs.seek(SubHeaderOffset[j], 0)
            if bs.readBytes(4) not in (b"<?xm", b"EXGr"):
                bs.seek(-4, 1)
                dataSize = bs.readUInt() # +0x8
                DUMMY = bs.readUInt() # +0xC, 4x width? stride?
                DUMMY = bs.readUShort() # +0x10, invalid width
                DUMMY = bs.readUShort() # +0x12, invalid height
                DUMMY = bs.readUInt() # +0x14
                width = bs.readUShort() # +0x18
                height = bs.readUShort() # +0x1A
                TEXFMT = bs.readUShort() # +0x1C
                DUMMY = bs.readUShort() # +0x1E
                DUMMY = bs.readUInt() # +0x20
                DUMMY = bs.readUInt() # +0x24

                if TEXFMT == 0: fmtText = "BGRA8"; IsBC = False; texFmt = "b8g8r8a8"
                elif TEXFMT == 9: fmtText = "BC7"; IsBC = True; texFmt = noesis.FOURCC_BC7
                else: fmtText = "unknown"

                dataStart = bs.tell() # +0x28
                data = bs.readBytes(dataSize)

                print("[i] Texture #"+repr(i+1)+"-"+repr(j+1)+": format: "+fmtText+"; WxH: "+repr(width)+"x"+repr(height)+"; data start: "+hex(dataStart)+"; data size: "+repr(dataSize)+" B.")
                if fmtText == "unknown": return 0

                if IsBC: data = rapi.imageDecodeDXT(data, width, height, texFmt); texFmt = noesis.NOESISTEX_RGBA32
                else: data = rapi.imageDecodeRaw(data, width, height, texFmt); texFmt = noesis.NOESISTEX_RGBA32

                texList.append(NoeTexture(rapi.getExtensionlessName(rapi.getInputName())+"_"+repr(i+1)+"_"+repr(j+1), width, height, data, texFmt))

    return 1
#-------------------------------------------------------------------------------