from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("MadWorld",".datM")
	noesis.setHandlerTypeCheck(handle, CheckType)
	noesis.setHandlerLoadModel(handle, LoadModel)
	
	return 1
	
def CheckType(data):
	bs = NoeBitStream(data)
	if len(data) < 16:
		print("Invalid file, too small")
		return 0
	return 1

def LoadModel(data, mdlList):
	
	ctx = rapi.rpgCreateContext()
	bs = NoeBitStream(data)
	bs.setEndian(NOE_BIGENDIAN)
	
	bs.readBytes(0x20)
	bs.seek(bs.readUInt()) #go to the JK section
	JKOffset = bs.tell()
	bs.readShort() #magic
	vertexFlag = bs.readUByte()
	bs.readUByte() #padding
	vertexCount = bs.readUInt()
	vertexPosOffset = bs.readUInt()
	
	bs.readUInt() #???
	bs.readUInt() #???	
	bs.readUInt() #???
	bs.readUInt() #???	
	bs.readUInt() #???
	bs.readUInt() #???	
	bs.readUInt() #???
	bs.readUInt() #???
	
	jointCount = bs.readUInt()
	jointParentingOffset = bs.readUInt() #joint IDs seem to be after that section, fixed length ? Don't really care since in order
	
	bs.readUInt() #???
	
	jointPosOffset = bs.readUInt()
	
	bs.readUInt() #???
	bs.readUInt() #???	
	bs.readUInt() #???
	
	subMeshesOffset = bs.readUInt()
	
	#position		
	posBuffer = bytes()
	bs.seek(vertexPosOffset + JKOffset)
	for i in range(vertexCount):
		for j in range(3):
			posBuffer += noePack('f', bs.readShort()/8192) if vertexFlag == 0x12 else noePack('f', bs.readFloat())
		bs.readShort() if vertexFlag == 0x12 else bs.readFloat()
		
	#bones
	jointParenting = []
	jointPos = []
	jointList = []
	
	bs.seek(jointParentingOffset + JKOffset)	
	for i in range(jointCount):
		jointParenting.append(bs.readByte())
	bs.seek(jointPosOffset + JKOffset)
	for i in range(jointCount):
		jointPos.append(NoeVec3([bs.readFloat(),bs.readFloat(),bs.readFloat()]))	
	for i in range(jointCount):
		jointMatrixTransform = NoeQuat().toMat43()
		jointMatrixTransform[3] = jointPos[i]
		joint = NoeBone(i, 'bone_' + str(i), jointMatrixTransform, None, jointParenting[i])
		jointList.append(joint)
		
	#faces 
	bs.seek(subMeshesOffset + JKOffset)
	offsetToNextSubmesh = 1
	subMeshesIndices = []
	subMeshesNames = []
	subMeshesFaceCount = []
	while offsetToNextSubmesh:
		checkPoint1 = bs.tell()
		offsetToNextSubmesh = bs.readUInt()
		bs.readBytes(0x1C) #???
		checkPoint2 = bs.tell()
		subMeshesNames.append(bs.readString())
		flag = 0
		while flag != 0x90:
			flag = bs.readUByte()
		indexCount = bs.readUShort()
		subMeshesFaceCount.append(indexCount//3)
		faceBuffer = bs.readBytes(0x6*indexCount)
		faceBuffer = noesis.swapEndianArray(faceBuffer,0x2)
		subMeshesIndices.append(noesis.deinterleaveBytes(faceBuffer,0x0,0x2,0x6))
		bs.seek(checkPoint1 + offsetToNextSubmesh)	
	
	for j, name in enumerate(subMeshesNames):
			rapi.rpgSetName(name)
			rapi.rpgBindPositionBuffer(posBuffer, noesis.RPGEODATA_FLOAT,0xC)
			rapi.rpgCommitTriangles(subMeshesIndices[j], noesis.RPGEODATA_USHORT, subMeshesFaceCount[j]*3, noesis.RPGEO_TRIANGLE)
	try:
		mdl = rapi.rpgConstructModel()
	except:
		mdl = NoeModel()
	mdl.setBones(jointList)
	mdlList.append(mdl)
	
	return 1
	
	