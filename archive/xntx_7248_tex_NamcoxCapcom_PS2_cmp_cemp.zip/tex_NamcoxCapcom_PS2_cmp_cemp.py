from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Namco x Capcom [PS2]", ".cmp;.cemp")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    magic = bs.readBytes(4)
    if magic != b'\x43\x4d\x50\x44': #CMPD
        if magic != b'\x50\x32\x49\x47': #P2IG
            return 0
    return 1

def noepyLoadRGBA(data, texList):
    rapi.processCommands("-texnorepfn")
    bs = NoeBitStream(data)
    magic = bs.readBytes(4)
    if magic == b'\x50\x32\x49\x47': #P2IG
        bs.seek(0x1c, 1)
        width = bs.readUShort()
        height = bs.readUShort()
        imgFmt = bs.readUShort()
        imgWidth = 2 ** width
        imgHeight = 2 ** height
        #print(imgWidth, "x", imgHeight, "-", hex(imgFmt))
        bs.seek(0x1a, 1)
        headerSize = bs.readUInt()
        paletteSize = bs.readUInt()
        dataStart = bs.readUInt()
        datasize = bs.readUInt()
        bs.seek(0x30, 1)
        palette = bs.readBytes(paletteSize)
        bs.seek(dataStart)
        data = bs.readBytes(datasize)
        if imgFmt == 0x13:
            data = rapi.imageDecodeRawPal(data, palette, imgWidth, imgHeight, 8, "r8 g8 b8 a8", noesis.DECODEFLAG_PS2SHIFT)
        elif imgFmt == 0x14:
            data = rapi.imageDecodeRawPal(data, palette, imgWidth, imgHeight, 4, "r8 g8 b8 a8")        
        texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, noesis.NOESISTEX_RGBA32))
        return 1
    elif magic == b'\x43\x4d\x50\x44': #CMPD
        bs.seek(0)
        look4 = bs.readBytes(bs.getSize())
        CMTX = look4.find(b'\x43\x4d\x54\x58')
        if CMTX == -1: 
            return 0
        else:
            bs.seek(CMTX + 4)
        CMTXChunkSize = bs.readUInt()
        bs.seek(0x8, 1)
        tmp = bs.tell()
        bs.seek(0x8, 1)
        numFiles = bs.readUInt()
        print(numFiles, ":files")
        infoTableSize = bs.readUInt()
        texNames = []
        offset = []
        #print(hex(bs.tell()), ":here")
        for i in range(numFiles):
            try:
                texName = noeStrFromBytes(bs.readBytes(0x10))
            except:
                bs.seek(-0x10, 1)
                omit = [0x82, 0x83, 0x86, 0x8c]
                name = bs.readBytes(0x10)
                newName = bytearray()
                for j in name:
                    if j in omit:
                        j = 0x78
                    newName.append(j)
                texName = noeStrFromBytes(newName)
                print(texName)
            texNames.append(texName)
            bs.seek(0x10, 1)
            offset.append(bs.readUInt() + tmp)
            size = bs.readUInt()
            bs.seek(0x8, 1)
        for i in range(numFiles):
            bs.seek(offset[i])
            P2IG = noeStrFromBytes(bs.readBytes(0x4))
            bs.seek(0x1c, 1)
            width = bs.readUShort()
            height = bs.readUShort()
            imgFmt = bs.readUShort()
            imgWidth = 2 ** width
            imgHeight = 2 ** height
            #print(i +1, ":", imgWidth, "x", imgHeight, "-", hex(imgFmt))
            bs.seek(0x1a, 1)
            headerSize = bs.readUInt()
            paletteSize = bs.readUInt()
            dataStart = bs.readUInt() + offset[i]
            datasize = bs.readUInt()
            bs.seek(0x30, 1)
            palette = bs.readBytes(paletteSize)
            bs.seek(dataStart)
            data = bs.readBytes(datasize)
            if imgFmt == 0x13:
                data = rapi.imageDecodeRawPal(data, palette, imgWidth, imgHeight, 8, "r8 g8 b8 a8", noesis.DECODEFLAG_PS2SHIFT)
            elif imgFmt == 0x14:
                data = rapi.imageDecodeRawPal(data, palette, imgWidth, imgHeight, 4, "r8 g8 b8 a8")        
            texList.append(NoeTexture(texNames[i], imgWidth, imgHeight, data, noesis.NOESISTEX_RGBA32))
        return 1