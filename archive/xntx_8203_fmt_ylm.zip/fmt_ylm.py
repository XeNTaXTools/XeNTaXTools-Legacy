#by Durik256 for xentax
from inc_noesis import *
import math

def registerNoesisTypes():
    handle = noesis.register("Aerial Strike: The Yager Missions", ".ylm")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)
    return 1

def noepyCheckType(data):
    if data[:3] != b'YLM':
        return 0
    return 1   
	
def noepyLoadModel(data, mdlList):
    bs = NoeBitStream(data)

    bs.seek(4)#YML
    texFmt = noesis.NOESISTEX_RGBA32
    
    file_size, unk, num_file = bs.readInt(), bs.readInt(), bs.readInt()

    bs.seek(4, 1)#MAP
    
    (size, unk, unk, x_terrain, y_terrain, x_chunk, y_chunk, unk, height) = [bs.readInt() for x in range(9)]

    #bs.seek((x_terrain*y_terrain)*4, 1)
    texList, meshes = [], []

    data = bs.readBytes(x_terrain * y_terrain * 4)
    texList.append(NoeTexture('_small', x_terrain, y_terrain, data, texFmt))
    
    start_chunk = bs.getOffset() + (x_terrain*y_terrain)*4 + 4
    
    for y in range(y_terrain):
        for x in range(x_terrain):

            offset, curPos = bs.readInt(), bs.getOffset()
            if offset != -1:
                bs.seek(offset + start_chunk)

                meshes.append(plane(bs, 'quad_%d_%d' % (x,y), 17, height, x_terrain, y_terrain, x, -y))
                bs.seek(curPos)
    
    
    #num_chunk = bs.readInt()
    '''
    bs.seek(4, 1)#NRML
    n_size, n_num = bs.readInt(), bs.readInt()
    for x in range(n_num):
        nbuf = bs.readBytes(n_num*12)
        
    bs.seek(4, 1)#TEX
    tx_size, tx_num = bs.readInt(), bs.readInt()
    for x in range(tx_num):
        tx_name = bs.readBytes(to the first zero)
    '''
    
    mdl = NoeModel(meshes)
    #----find texture----
    tx_dir = os.path.abspath(os.path.join(rapi.getDirForFilePath(rapi.getInputName()), '../texture/'))
    tx_name = rapi.getLocalFileName(rapi.getInputName()).split('.')[0]+'_shadow'
    
    for file in os.listdir(tx_dir):
        if tx_name in file:
            tx_name = os.path.join(tx_dir,file)
            break
    #--------------------
    mdl.setModelMaterials(NoeModelMaterials(texList, [NoeMaterial('mat_0',tx_name)]))
    mdlList.append(mdl)
    return 1
    
def plane(bs, name, size, height, terX, terY, offsetX=0, offsetY=0):
    vert = []
    uv = []
    for x in range(size):
        for j in range(size):
            Y = bs.readUByte()#R - chanel
            bs.seek(3,1)#GBA - chanel
            
            vert.append(NoeVec3([j+((size-1)*offsetX), Y/height, -x+((size-1)*offsetY)]))
            uvX, uvY = ((j/(size-1))/terY)+((1/terX)*offsetX), ((-x/(size-1))/terY)+((1/terX)*offsetY)
            uv.append(NoeVec3([uvX, -uvY, 0]))

    face = []
    for x in range(size-1):
        for j in range(size-1):
            face += [x*size+j, x*size+(j+1) , (x+1)*size+j, x*size+(j+1), (x+1)*size+(j+1) , (x+1)*size+j]

    mesh = NoeMesh(face, vert, name)
    mesh.setUVs(uv)
    mesh.setMaterial('mat_0')
    return mesh