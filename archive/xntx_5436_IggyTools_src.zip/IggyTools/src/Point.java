
public class Point {

	public static final int MOVE_TO = 1;
	public static final int STRAIGHT = 2;
	public static final int CURVED = 3;
	
	private int type;
	private float x, y, cx, cy;
	
	public Point(int type, float x, float y, float cx, float cy) {
		this.type = type;
		this.x = x;
		this.y = y;
		this.cx = cx;
		this.cy = cy;
	}

	public int getType() {
		return type;
	}

	public float getX() {
		return x;
	}

	public float getY() {
		return y;
	}

	public float getCx() {
		return cx;
	}

	public float getCy() {
		return cy;
	}
}
