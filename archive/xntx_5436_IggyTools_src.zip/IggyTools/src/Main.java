import java.io.File;
import java.io.IOException;
import java.util.List;

public class Main {

	private static List<Font> fonts = null;
	private static FontWindow fontWindow;

	public static void main(String[] args) {
		fontWindow = new FontWindow();
		
		/*
		// Load file on start-up
		String filename = "C:/Users/Z/Desktop/iggy/lib_loc_english_font.iggy";
		loadFile(new File(filename));
		*/
	}

	public static void loadFile(File file) {
		try {
			fonts = IggyReader.readFile(file);
			fontWindow.setFont(fonts);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
