import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class IggyReader {

	private static final boolean DEBUG_OUTPUT = false;
	private static LittleEndianInputStream stream;

	public static List<Font> readFile(File file) throws IOException {
		return readFile(file.getAbsolutePath());
	}

	public static List<Font> readFile(String filename) throws IOException {
		
		stream = new LittleEndianInputStream(filename);
		
		stream.skip(0x2C);
		int headerLength = stream.readInt();
		stream.skip(headerLength + 0xC0);
		
		List<Font> fonts = new ArrayList<Font>(6);
		
		int[] offset = new int[6];
		
		for (int i = 0; i < offset.length; i++) {
			int pos = stream.getPosition();
			offset[i] = pos + stream.readInt();
			stream.skip(4);
		}
		
		for (int i = 0; i < offset.length; i++) {
			Font font = readFont(offset[i]);
			fonts.add(font);
		}
		
		stream.close();
		
		return fonts;
	}

	public static Font readFont(int offset) throws IOException {
		
		stream.seek(offset);
		stream.skip(0x20);
		
		int numCharacters = stream.readShort();
		stream.skip(0x16);
		
		int keyCodeTableOffset = stream.getPosition() + stream.readInt();
		stream.skip(4);
		
		int charWidthTableOffset = stream.getPosition() + stream.readInt();
		stream.skip(0x11C);
		
		String fontName = "";
		
		char nextChar;
		while (true) {
			nextChar = (char) stream.readByte();
			stream.readByte(); // skip 0
			if (nextChar == 0) {
				break;
			}
			fontName += nextChar;
		}
		// skip padding after string
		int toSkip = (8 - (fontName.length() * 2 + 2) % 8) % 8;
		stream.skip(toSkip);
		
		List<Character> charList = new ArrayList<Character>(numCharacters);
		
		for (int i = 0; i < numCharacters; i++) {
			stream.readInt();
			stream.readInt();
			boolean hasPoints = (stream.readShort() == 1) ? true : false;
			stream.readShort();
			stream.readInt();
			stream.readShort(); // 0x50
			stream.readShort(); // 0x13
			stream.readInt();
			int charOffset = stream.getPosition() + stream.readInt();
			stream.readInt();
			
			charList.add(new Character(hasPoints, charOffset));
		}
		
		BufferedWriter writer = null;
		
		if (DEBUG_OUTPUT) {
			File file = new File(fontName + ".txt");
			FileWriter fw = new FileWriter(file);
			writer = new BufferedWriter(fw);
		}
		
		for (int index = 0; index < charList.size(); index++) {
			Character c = charList.get(index);
			
			if (!c.hasPoints()) {
				continue;
			}
			stream.seek(c.getOffset());
			
			float a1 = stream.readFloat();
			float a2 = stream.readFloat();
			float a3 = stream.readFloat();
			float a4 = stream.readFloat();
			stream.skip(8);
			
			if (DEBUG_OUTPUT) {
				writer.write("# INDEX: " + index + "\r\n");
				writer.write(a1 + "\t");
				writer.write(a2 + "\t");
				writer.write(a3 + "\t");
				writer.write(a4 + "\r\n");
			}
			
			int numChunks = stream.readInt();
			stream.skip(36);
			
			List<Point> pointList = new ArrayList<Point>(numChunks);
			
			for (int i = 0; i < numChunks; i++) {
				
				float f1 = stream.readFloat();
				float f2 = stream.readFloat();
				float f3 = stream.readFloat();
				float f4 = stream.readFloat();
				
				int s1 = stream.readByte() & 0xFF;
				
				stream.readByte();
				
				stream.readShort();
				stream.readShort();
				stream.readShort();
				
				if (DEBUG_OUTPUT) {
					writer.write(s1 + "\t" + f1 + "\t" + f2 + "\t" + f3 + "\t" + f4 + "\r\n");
				}
				
				pointList.add(new Point(s1, f1, f2, f3, f4));
			}
			c.addPoints(pointList);
			
			if (DEBUG_OUTPUT) {
				writer.write("\r\n");
			}
		}
		
		stream.seek(keyCodeTableOffset);
		
		for (Character c : charList) {
			int keyCode = stream.readShort() & 0xFFFF;
			c.setKeyCode(keyCode);
		}
		
		stream.seek(charWidthTableOffset);
		
		for (Character c : charList) {
			float width = stream.readFloat();
			c.setWidth(width);
		}
		
		if (DEBUG_OUTPUT) {
			writer.close();
		}
		
		return new Font(fontName, charList);
	}
}
