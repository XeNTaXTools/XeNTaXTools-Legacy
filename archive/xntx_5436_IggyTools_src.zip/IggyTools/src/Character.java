import java.util.List;

public class Character {

	private boolean hasPoints;
	private int offset;
	private List<Point> points;
	private int keyCode;
	private float width;

	public Character(boolean hasPoints, int offset) {
		this.hasPoints = hasPoints;
		this.offset = offset;
	}

	public List<Point> getPoints() {
		return points;
	}

	public int getKeyCode() {
		return keyCode;
	}

	public void setKeyCode(int keyCode) {
		this.keyCode = keyCode;
	}

	public float getWidth() {
		return width;
	}

	public void setWidth(float width) {
		this.width = width;
	}

	public boolean hasPoints() {
		return hasPoints;
	}

	public int getOffset() {
		return offset;
	}

	public void addPoints(List<Point> points) {
		this.points = points;
	}
}
