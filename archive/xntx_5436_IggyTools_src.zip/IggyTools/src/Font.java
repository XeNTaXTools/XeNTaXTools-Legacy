import java.util.List;

public class Font {
	
	private List<Character> charList;
	private String fontName;

	public Font(String fontName, List<Character> charList) {
		this.fontName = fontName;
		this.charList = charList;
	}

	public String getFontName() {
		return fontName;
	}

	public List<Character> getCharList() {
		return charList;
	}
}
