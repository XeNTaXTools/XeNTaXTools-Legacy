import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.awt.dnd.DnDConstants;
import java.awt.dnd.DropTarget;
import java.awt.dnd.DropTargetDragEvent;
import java.awt.dnd.DropTargetDropEvent;
import java.awt.dnd.DropTargetEvent;
import java.awt.dnd.DropTargetListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.geom.CubicCurve2D;
import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.swing.JFrame;

public class FontWindow extends JFrame implements KeyListener, DropTargetListener {
	
	private static final long serialVersionUID = 1L;
	
	private static final int offsetX = 200;
	private static final int offsetY = 600;
	private static final int scaleFactor = 500;
	
	private int fontIndex = 0;
	private int charIndex = 1;
	private boolean drawExtra = false;
	
	private Font font;
	private List<Font> fonts;
	private List<Character> charList;

	public FontWindow() {
		super("Font Viewer");
		
		new DropTarget(this, DnDConstants.ACTION_COPY_OR_MOVE, this, true);
        
		setSize(800, 800);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		addKeyListener(this);
        setFocusable(true);
        setFocusTraversalKeysEnabled(false);
        setVisible(true); 
	}

	public void setFont(List<Font> fonts) {
		this.fonts = fonts;
		fontIndex = 0;
		charIndex = 1;
		repaint();
	}

	public void paint(Graphics g) {
		super.paint(g);
		drawCharacter(g);
	}

	void drawCharacter(Graphics g) {
		if (fonts == null) {
			g.drawString("Drag & drop an *.iggy file onto the application.", 20, 50);
			return;
		}
		
		Graphics2D g2d = (Graphics2D) g;
		
		g2d.clearRect(0, 0, 900, 900);
		
		font = fonts.get(fontIndex);
		charList = font.getCharList();
		charIndex %= charList.size();
		Character c = charList.get(charIndex);
		
		g.drawString("Font : " + font.getFontName() + " (Index: " + (fontIndex + 1) + ")", 20, 50);
		g.drawString("Char: " + c.getKeyCode() + " (Index: " + (charIndex + 1) + " / " + charList.size() + ")", 20, 70);
		
		g.drawString("keyboard commands:", 20, 700);
		g.drawString("right:", 20, 720);  g.drawString("next character", 60, 720);
		g.drawString("left:", 20, 740);   g.drawString("previous character", 60, 740);
		g.drawString("down:", 20, 760);   g.drawString("next font", 60, 760);
		g.drawString("up:", 20, 780);     g.drawString("show/hide points and width", 60, 780);
		
		if (drawExtra) {
			g.setColor(Color.BLUE);
			g.drawLine(offsetX, offsetY, (int) (c.getWidth() * scaleFactor) + offsetX, offsetY);
		}
		
		if (!c.hasPoints()) {
			return;
		}
		
		Point lastPoint = null;
		
		for (Point p : c.getPoints()) {
			
			int type = p.getType();
			
			if (type == Point.MOVE_TO) {
				// do nothing
			} else {
				g.setColor(Color.BLACK);
				
				int x1 = (int) (p.getX() * scaleFactor) + offsetX;
				int y1 = (int) (p.getY() * scaleFactor) + offsetY;
				int cx1 = (int) (p.getCx() * scaleFactor) + offsetX;
				int cy1 = (int) (p.getCy() * scaleFactor) + offsetY;
				
				int x2 = (int) (lastPoint.getX() * scaleFactor) + offsetX;
				int y2 = (int) (lastPoint.getY() * scaleFactor) + offsetY;
				//int cx2 = (int) (lastPoint.getCx() * scaleFactor) + offsetX;
				//int cy2 = (int) (lastPoint.getCy() * scaleFactor) + offsetY;
				
				if (type == Point.STRAIGHT) {
					g2d.drawLine(x1, y1, x2, y2);
				} else {
					CubicCurve2D curve = new CubicCurve2D.Float();
					curve.setCurve(x1, y1, cx1, cy1, cx1, cy1, x2, y2);
					g2d.draw(curve);
				}
				
				if (drawExtra) {
					if (type == Point.CURVED) {
						g.setColor(Color.BLUE);
						g2d.drawLine(cx1-3, cy1, cx1+3, cy1); 
						g2d.drawLine(cx1, cy1-3, cx1, cy1+3);
					}
					
					g.setColor(Color.RED);
					g2d.drawLine(x1-3, y1, x1+3, y1); 
					g2d.drawLine(x1, y1-3, x1, y1+3);
				}
			}
			
			lastPoint = p;
		}
	}

	@Override
	public void keyPressed(KeyEvent e) {
		if (fonts == null) {
			return;
		}
		
		switch (e.getKeyCode()) {
        case KeyEvent.VK_UP:
        	drawExtra = !drawExtra;
            break;
        case KeyEvent.VK_DOWN:
            fontIndex++;
            fontIndex %= fonts.size();
            break;
        case KeyEvent.VK_RIGHT:
            charIndex++;
            charIndex %= charList.size();
            break;
        case KeyEvent.VK_LEFT:
        	if (charIndex != 0) {
                charIndex--;
        	} else {
        		charIndex = charList.size() - 1;
        	}
            break;
		}
		repaint();
	}

	@Override
	public void drop(DropTargetDropEvent dtde) {
		Transferable t = dtde.getTransferable();
        if (t.isDataFlavorSupported(DataFlavor.javaFileListFlavor)) {
            try {
            	dtde.acceptDrop(DnDConstants.ACTION_COPY_OR_MOVE);
                Object td = t.getTransferData(DataFlavor.javaFileListFlavor);
                if (td instanceof List) {
                    for (Object value : ((List<?>) td)) {
                        if (value instanceof File) {
                            File file = (File) value;
                            String name = file.getName().toLowerCase();
                            if (!name.endsWith(".iggy")) {
                                break;
                            }
                            Main.loadFile(file);
                        }
                    }
                }
            } catch (UnsupportedFlavorException | IOException ex) {
                ex.printStackTrace();
            }
        }
	}

	@Override
	public void keyReleased(KeyEvent e) {}

	@Override
	public void keyTyped(KeyEvent e) {}

	@Override
	public void dragEnter(DropTargetDragEvent paramDropTargetDragEvent) {}

	@Override
	public void dragOver(DropTargetDragEvent paramDropTargetDragEvent) {}

	@Override
	public void dropActionChanged(DropTargetDragEvent paramDropTargetDragEvent) {}

	@Override
	public void dragExit(DropTargetEvent paramDropTargetEvent) {}
}