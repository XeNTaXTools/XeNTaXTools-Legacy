from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Blue Estate Font", ".Texture2D")
	noesis.setHandlerTypeCheck(handle, noeCheckGeneric)
	noesis.setHandlerLoadRGBA(handle, SWEp3RotSLoadRGBA)
	#noesis.logPopup()
	return 1

	
def SWEp3RotSLoadRGBA(data, texList):
	datasize = len(data) - 0x131        
	bs = NoeBitStream(data)
	bs.seek(0x1c, NOESEEK_ABS)
	imgWidth = bs.readInt()            
	bs.seek(0x70, NOESEEK_ABS)
	imgHeight = bs.readInt()           
	bs.seek(0x131, NOESEEK_ABS)        
	data = bs.readBytes(datasize)      
	texFmt = noesis.NOESISTEX_DXT5
	texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
	return 1