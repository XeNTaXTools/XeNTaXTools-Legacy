from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Slave Zero", ".tex")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    return 1
    
def noepyLoadRGBA(data, texList):
    rapi.processCommands("-texnorepfn")
    bs = NoeBitStream(data)
    imgWidth = bs.readUInt()            
    imgHeight = bs.readUInt()
    numTex = bs.readUInt()
    imgFmt = bs.readUByte()
    print(hex(imgFmt))
    flag1 = bs.readByte() #?
    flag2 = bs.readByte() #?
    flag3 = bs.readByte() #?
    datasize = ((bs.getSize() - 0x10) // numTex)
    for i in range(numTex):
        data = bs.readBytes(datasize)
        if numTex > 1:
            texName = i + 1
            texName = rapi.getExtensionlessName(rapi.getInputName()) + "_" + str(texName)
        else:
            texName = rapi.getInputName()
        if imgFmt == 0x80 or imgFmt == 0x81 or imgFmt == 0x88 or imgFmt == 0x89 or imgFmt == 0xa0:
            data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "b5 g5 r5 a1")
        elif imgFmt == 0x8:
            data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "a8")
        elif imgFmt == 0x44 or imgFmt == 0x4:
            data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "b8 g8 r8 a8")
        data = rapi.imageFlipRGBA32(data, imgWidth, imgHeight, 0, 1)
        texList.append(NoeTexture(texName, imgWidth, imgHeight, data, noesis.NOESISTEX_RGBA32))
    return 1