Credits:
Ekey
Cra0kalo

Information:
should work for all archives in watch_dogs forum reference
http://forum.xentax.com/viewtopic.php?f=10&t=11534