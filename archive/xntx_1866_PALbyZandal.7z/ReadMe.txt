################################################################################
################################################################################
################################################################################
##########"""""""' ##################################   #################"""####
#########   ~,,   ,################################# , ,################'  #####
#########  ####  ####################################  ################,  ,#####
#########,###" ,########"""'"#######"#############""#  #####"""" #######  ######
############' ########' ,,  ######"  ###"  #####"     #####  ,   #######  ######
##########" )#########  #'  #####",  ##",  #####  #,  ####  /#   ######  #######
#########  ##########  #"   |###### # '#|  ####  ###  #### ,#    ######  #######
#####    .#######"'## #"'#   ##'/##  ,##   #"#'  #"  ####  # ,#  "#""#  �#######
#####,     "####  ##  " ##,  " /##  ,###     #   ",  #### #' ##   , ##   "",####
########,      ,####   ####   #### ,####  ,###.  ##  ###|  ,###\  /###   #######
####################,,#########################,###( ####,######################
#################################################### "##########################
####################################################\,"#########################
###################################################### ",#######################
################################################################################

You can use this tool in your kit but 
 
 P L E A S E

put this Readme.txt file together...



StuntMan PAL v1.0b (c) Zandal 13/09/2002 

Now you can also Rebuild.....
IMPORTANT.... Re-EXTRACT the IMG file with this new version....
In the LNN files and in the extract files there are 5-6 file missing...
I have some problems extracting them... but dont Worry are only EXTRAS movies....
The tool relink them to this:
00341#00001#02710#000011282B#00046B78CB#0000000000#MOVIES\TRAILERS\MONAC_TR.XAV

So if MONAC_TR.XAV exist again in your plan.... when you select extra movies... you see this.... otherwise crash it....

I'm here to explain you how this fucking Decrypt works.... ehehehe....



StuntMan PAL Internal Version (c) Zandal 13/09/2002 INTERNAL VERSION

How to fill the field:
Original Folder: put the folder where the original file is....


DONT TOUCH ANYTHING ELSE


Now Press EXTRACT or REBUILD....

HOW TO DOWNSIZE STUNTMAN PAL BIG FILE....
You can follow 2 way to do that:

1) Replace files that you dont want with dummy files....
2) Relink files...

HOW TO RELINK FILES....
After the Extraction phase you must have somewhere this file:
TABLE.LNN file...
This is the layout:

IMPORTANT DONT CHANGE THE LAYOUT!!!!

Row  #Link #Other usefull data for the tool.....dont touch!
00001#00001#00002#0000000000#0001584C13#0000000000#System\DeusExConAudioAIBarks.u      
00002#00002#0002D#0001584C13#0002DFEF42#0000000000#System\DeusExConAudioHK_Shared.u    
00003#00003#0005B#0004383B55#000077BAD1#0000000000#System\DeusExConAudioMission00.u    
00004#00004#00089#0004AFF626#00011F4ED8#0000000000#System\DeusExConAudioMission01.u    
00005#00005#000B7#0005CF44FE#00019EEED4#0000000000#System\DeusExConAudioMission02.u    
00006#00006#000E5#00076E33D2#0001D5AFA0#0000000000#System\DeusExConAudioMission03.u
.....

If you want to relink the file with ROW 00004 and 00005 and 00006 with file in ROW 00003....
you must do that:

Row  #Link #Other usefull data for the tool.....dont touch!
00001#00001#00002#0000000000#0001584C13#0000000000#System\DeusExConAudioAIBarks.u      
00002#00002#0002D#0001584C13#0002DFEF42#0000000000#System\DeusExConAudioHK_Shared.u    
00003#00003#0005B#0004383B55#000077BAD1#0000000000#System\DeusExConAudioMission00.u    
00004#00003#00089#0004AFF626#00011F4ED8#0000000000#System\DeusExConAudioMission01.u    
00005#00003#000B7#0005CF44FE#00019EEED4#0000000000#System\DeusExConAudioMission02.u    
00006#00003#000E5#00076E33D2#0001D5AFA0#0000000000#System\DeusExConAudioMission03.u
.....

As you can see the LINK column has been changed....


ABOUT EXTRACT AND REBUILD....
If you have some probs with the tool try to UNCHECK the API FUNCTION CHECK.... and do the operation again....



