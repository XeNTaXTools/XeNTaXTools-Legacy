from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Skel",".skel")
    noesis.setHandlerTypeCheck(handle, CheckType)
    noesis.setHandlerLoadModel(handle, LoadModel)	
    return 1
    
def CheckType(data):
    bs = NoeBitStream(data)
    return 1

def LoadModel(data, mdlList):
    
    ctx = rapi.rpgCreateContext()
    bs = NoeBitStream(data)
    bs.setEndian(NOE_LITTLEENDIAN)
    
    unk = bs.readUInt() #version ?
    jointCount = bs.readUInt()
    
    jointList = []
    
    for i in range(jointCount):
        nameLength = bs.readUInt()
        jointName = bs.readBytes(nameLength).decode("ASCII")
        parent = bs.readInt()
        position = NoeVec3([bs.readHalfFloat() for _ in range(3)])
        jointMat = NoeQuat([bs.readHalfFloat() for _ in range(4)]).toMat43()
        jointMat[3] = position
        jointList.append(NoeBone(i, jointName, jointMat, None, parent))
    
    try:
        mdl = rapi.rpgConstructModel()
    except:
        mdl = NoeModel()
    mdl.setBones(jointList)
    mdlList.append(mdl)
    
    return 1
    
    