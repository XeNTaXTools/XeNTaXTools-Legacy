import Blender
from Blender import *
import bpy


selObjs=Blender.Object.GetSelected()

if len(selObjs)>0:
	morphObj=selObjs[0]
	mouthObj=None
	eyeObj=None
	scene = bpy.data.scenes.active
	for object in scene.objects:
		if 'head_mouth' in object.name:
			mouthObj=object
		if 'head_eye' in object.name:
			eyeObj=object
	if 'mouth' in morphObj.name:
		if mouthObj is not None:
			meshMouth=mouthObj.getData(mesh=1)
			morphMouth=morphObj.getData(mesh=1)
			if len(meshMouth.verts)==len(morphMouth.verts):
				for m in range(len(meshMouth.verts)):
					meshMouth.verts[m].co=morphMouth.verts[m].co
			meshMouth.update()
	if 'eye' in morphObj.name:
		if eyeObj is not None:
			meshEye=eyeObj.getData(mesh=1)
			morphEye=morphObj.getData(mesh=1)
			if len(meshEye.verts)==len(morphEye.verts):
				for m in range(len(meshEye.verts)):
					meshEye.verts[m].co=morphEye.verts[m].co
			meshEye.update()
Blender.Window.RedrawAll()					
								