import newGameLib
reload(newGameLib)
from newGameLib import *
import Blender

	
	
def TRNS(g):
	flag=g.word(1)
	data=Matrix4x4(g.f(16))
	flag=g.word(1)
	return data
	
def VRSN(g):
	g.seek(13,1)
	
def VRTX(g):
	flag=g.word(1)			
	vertCount=g.i(1)[0]
	vertPosList=[]
	skinIndiceList=[]
	skinWeightList=[]
	for m in range(vertCount):
		vertPosList.append(g.f(3))
		skinIndiceList.append([])
		skinWeightList.append([])
		g.seek(4,1)
	flag=g.word(1)
	return vertPosList,skinIndiceList,skinWeightList
	
	
def NRML(g):
	flag=g.word(1)			
	vertCount=g.i(1)[0]
	for m in range(vertCount):
		g.seek(12,1)
	flag=g.word(1)
	
def TXUV(g):
	data=[]
	flag=g.word(1)			
	vertCount=g.i(1)[0]
	for m in range(vertCount):
		data.append(g.f(2))
	flag=g.word(1)
	return data
	
def FACE(g):
	data=[]
	flag=g.word(1)			
	faceCount=g.i(1)[0]
	for m in range(faceCount):
		data.append(g.H(3))
	flag=g.word(1)
	return data
	
def TSPC(g):
	flag=g.word(1)			
	vertCount=g.i(1)[0]
	for m in range(vertCount):
		g.seek(24,1)
	flag=g.word(1)
	
def MLST(g):
	data=[]
	flag=g.word(1)
	matCount=g.i(1)[0];	
	data.append(matCount)	
	for m in range(matCount):
		data.append(g.i(2))	
	data.append(g.find('\x0d\x0a\x7d'))
	return data
	
		
def BONE(g,n):
	data=[]
	n+=4
	g.word(1)
	name=g.find('\x00')	
	data.append(name)
	count=g.i(1)[0]
	data.append(count)
	data.append(g.i(count))
	data.append(g.f(count))
	bindMatrix=Matrix4x4(g.f(16))
	data.append(bindMatrix)
	g.word(1)
	return data
	
def ANIM(parent,g,n):
	action=Action()
	action.BONESPACE=True
	#action.ARMATURESPACE=True
	action.FRAMESORT=True
	action.skeleton='armature'
	g.find('\x00')
	g.word(1)
	fps,frameCount,boneCount=g.i(3)
	#INDX
	g.word(4)	
	g.word(1)
	for m in range(boneCount):
		bone=ActionBone()
		g.i(1)
		bone.name=g.word(g.i(1)[0])
		matrix=Matrix4x4(g.f(16))
		matrix=Matrix4x4(g.f(16))	
		action.boneList.append(bone)
	g.word(1)
	#AKEY
	g.word(4)	
	g.word(1)
	for m in range(frameCount):
		for n in range(boneCount):
			bone=action.boneList[n]
			bone.matrixFrameList.append(m)
			bone.matrixKeyList.append(Matrix4x4(g.f(16)))
	g.word(1)
	action.draw()
	action.setContext()
		
	
chunkList=['VRSN','FRME','TRNS','CLSN','MESH','VRTX','NRML','TXUV','FACE','TSPC','MLST','SKIN','BONE','ANIM']	
	
	
	
def chunkParser(parent,g,n):
	n+=4
	while(True):
		if g.tell()+4>g.fileSize():break
		pos=g.tell()
		chunk=g.word(4)
		if chunk in chunkList:
			print '-'*n,chunk,g.tell()
			node=Node()
			parent.children.append(node)
			node.chunk=chunk
			node.offset=pos
			if chunk=='VRSN':#node.data=g.find('\x7d\x0d\x0a')
				if ext=='mdl':
					#g.B(11)
					node.data=g.find('\x7d\x0d\x0a')
				if ext=='anm':g.B(3)
			if chunk=='FRME':node.data=g.find('\x00').strip()
			if chunk=='TRNS':node.data=TRNS(g)
			if chunk=='CLSN':node.data=g.find('\x0a\x7d\x0d\x0a')	
			if chunk=='MESH':node.data=g.find('\x00').strip()	
			if chunk=='ANIM':node.data=ANIM(node,g,n)	
			#if chunk=='INDX':node.data=INDX(node,g,n)
			if chunk=='VRTX':node.data=VRTX(g)
			if chunk=='NRML':NRML(g)
			if chunk=='TXUV':node.data=TXUV(g)
			if chunk=='FACE':node.data=FACE(g)
			if chunk=='TSPC':TSPC(g)
			if chunk=='MLST':node.data=MLST(g)
			if chunk=='SKIN':pass
			if chunk=='BONE':node.data=BONE(g,n)
			
		else:
			g.seek(-4,1)
			flag=g.word(1)
			if flag=='{':chunkParser(node,g,n)
			elif flag=='\x0d':print 'end line'
			elif flag=='\x0a':print 'next line'
			elif flag=='}':break
			else:	 
				print 'WARNING:',chunk,g.tell()
				break
	
class Node:
	def __init__(self):
		self.chunk=None
		self.offset=None
		self.data=None
		self.children=[]
	
def tree(list,node,chunk):
	for child in node.children:
		if child.chunk==chunk:
			list.append(child)
		tree(list,child,chunk)
		
def get(node,chunk):
	list=[]
	tree(list,node,chunk)	
	return list
	

def frmeParser(parentBone,parentNode):
	for child in parentNode.children:
		if child.chunk=='TRNS':	
			parentBone.matrix=child.data#.invert()
		if child.chunk=='FRME':
			bone=Bone()
			bone.name=child.data
			bone.parentName=parentBone.name
			skeleton.boneList.append(bone)
			frmeParser(bone,child)	
		
	
	
def mdlParser(filename,g):
	global skeleton
	g.endian='>'	
	g.word(3)
	
	root=Node()
	root.chunk=='ROOT'
	chunkParser(root,g,0)
	print 'tell:',g.tell()
	
	skeleton=Skeleton()
	skeleton.BONESPACE=True
	#skeleton.ARMATURESPACE=True
	skeleton.NICE=True
	for child in root.children:
		print child.chunk
		if child.chunk=='FRME':
			bone=Bone()
			bone.name=child.data
			skeleton.boneList.append(bone)
			frmeParser(bone,child)
	skeleton.draw()		
			
			
			
	
	for child in root.children:
		#print child.chunk
		#if child.chunk=='CLSN':
		#	print child.data
		if child.chunk=='MESH':
			mesh=Mesh()
			mesh.name=child.data
			print 'mesh:',mesh.name
			mesh.vertPosList=get(child,'VRTX')[0].data[0]
			if len(get(child,'TXUV'))>0:
				mesh.vertUVList=get(child,'TXUV')[0].data
			mesh.skinIndiceList=get(child,'VRTX')[0].data[1]
			mesh.skinWeightList=get(child,'VRTX')[0].data[2]
			if len(get(child,'FACE'))>0:
				mesh.faceList=get(child,'FACE')[0].data
			
			if len(get(child,'SKIN'))>0:
				skin=get(child,'SKIN')[0]
				boneList=get(skin,'BONE')
				for i,bone in enumerate(boneList):
					mesh.boneNameList.append(bone.data[0])
					for m in range(bone.data[1]):
						vertID=bone.data[2][m]
						weight=bone.data[3][m]
						mesh.skinIndiceList[vertID].append(i)
						mesh.skinWeightList[vertID].append(weight)
				skin=Skin()
				mesh.skinList.append(skin)
			
			mesh.matrix=skeleton.object.getData().bones[mesh.name].matrix['ARMATURESPACE']
			mesh.BINDSKELETON='armature'
			
			if len(get(child,'MLST'))>0:
				mlst=get(child,'MLST')[0].data
				#print mlst[-1]
				diffList=[]	
				textLines=mlst[-1].split('\x0d')
				for line in textLines:
					line=line.strip()
					if 'MTRL ' in line:
						matName=line.split('MTRL')[1].split('{')[0].strip()
						print 'mat:',matName
						diff=None
						for file in os.listdir(g.dirname):
							#if mesh.name+'.'+matName in file and '00_01' in file:
							if matName in file and '00_01' in file:
								matPath=g.dirname+os.sep+file
								matFile=open(matPath,'rb')
								p=BinaryReader(matFile)
								p.seek(32)
								imageName=p.find('\x00')
								matFile.close()
								
								
								imagePath=gameDir+os.sep+imageName+'.gtf'
								#print imagePath
								if os.path.exists(imagePath)==True:
									imageFile=open(imagePath,'rb')
									p=BinaryReader(imageFile)
									p.endian='>'
									A=p.H(64)
									#print A
									img=imageLib.Image()
									img.szer=A[16]
									img.wys=A[17]
									#if A[2]==5:img.format='DXT5'
									#if A[2]==20:img.format='DXT5'
									#if A[2]==10:img.format='DXT5'
									img.format='DXT5'
									img.data=p.read(p.fileSize()-128)
									img.name=gameDir+os.sep+imageName
									img.draw()
									diff=img.name
									imageFile.close()
						diffList.append(diff)	
						#print 'diff:',diff
						
								
								
					
			
			
				for m in range(mlst[0]):
					a,b=mlst[1+m]
					mat=Mat()
					mat.diffuse=diffList[m]
					print a,b
					for n in range(a,b+1):
						mesh.matIDList.append(m)
					mesh.matList.append(mat)
			
			
			mesh.draw()
		
		
	
	
		
	g.tell()
	
	
	
	
	
	
	
def anmParser(filename,g):
	global skeleton
	#g.logOpen()
	g.endian='>'	
	g.word(3)
	
	root=Node()
	root.chunk=='ROOT'
	chunkParser(root,g,0)
	print 'tell:',g.tell()
	
			
	
def Parser():	
	global ext,gameDir
	filename=input.filename
	print
	print filename
	print
	ext=filename.split('.')[-1].lower()	
	gameDir=filename.split('media'+os.sep)[0]
	if os.path.exists(gameDir)==False:
		gameDir=os.path.dirname(filename)
	
	if ext=='mdl':
		file=open(filename,'rb')
		g=BinaryReader(file)
		mdlParser(filename,g)
		file.close()
	
	if ext=='anm':
		file=open(filename,'rb')
		g=BinaryReader(file)
		anmParser(filename,g)
		file.close()
 
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
	
Blender.Window.FileSelector(openFile,'import','mdl - skinned mesh+skeleton, anm - animation')