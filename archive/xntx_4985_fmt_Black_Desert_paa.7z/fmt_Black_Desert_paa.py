from inc_noesis import *
import noesis
import rapi
from Utils.SkyUtils import *
import os
import glob


def registerNoesisTypes():
	handle = noesis.register("Black Desert anim", ".paa")
	noesis.setHandlerTypeCheck(handle, BDCheckType)
	noesis.setHandlerLoadModel(handle, BDLoadModel) #see also noepyLoadModelRPG
	#noesis.logPopup()
	return 1

def BDCheckType(data):
	bs = NoeBitStream(data)
	idMagic = bs.readInt()
	return 1

find = lambda searchList, elem: [[i for i, x in enumerate(searchList) if x == e] for e in elem]

def UnpackValue(value):
	if value < 0:
		return(value * 3.27680)
	elif value > 0:    
		return(value * 3.327670)
	else:
    # If we get this far then the value has to be 0
		return 0.0

def BDLoadModel(data, mdlList):
	ctx = rapi.rpgCreateContext()
	bs = NoeBitStream(data)
	rapi.setPreviewOption('setAngOfs',"0 90 90")

	boneNames = []
	boneTable = {}
	
	boneMtxList = []
	BonePosList = []
	boneParentList = []
	BoneQuatList = []
	
	BoneLocalPosList = []
	BoneLocalRotList = []
		
	meshes = []
	animBones = []
	anims = []

	test = rapi.getDirForFilePath(rapi.getInputName())
	os.chdir(test)
	test = glob.glob("*.pab")
	try:
		skelfile = rapi.getDirForFilePath(rapi.getInputName()) + test[0]
		
	except:
		skelfile = ""
	
	if (rapi.checkFileExists(skelfile)):
		ss = rapi.loadIntoByteArray(skelfile)
		ss = NoeBitStream(ss)
		ss.seek(0x10, NOESEEK_ABS)
		boneCount1 = ss.readUShort()
		print(boneCount1)
		for i in range(0, boneCount1):
			boneHash = ss.readUInt()
			boneNameSize = ss.readUByte()
			boneName = ss.readBytes(boneNameSize).decode("ASCII").rstrip("\0")
			boneTable[str(boneHash)] = boneName
			boneNames.append(boneName)
			boneParent = ss.readInt()
			boneMtx             = NoeMat44.fromBytes(ss.readBytes(64)).toMat43()
			boneMtxInverse      = NoeMat44.fromBytes(ss.readBytes(64)).toMat43().inverse()
			boneMtxLocal        = NoeMat44.fromBytes(ss.readBytes(64)).toMat43()
			boneMtxLocalInverse = NoeMat44.fromBytes(ss.readBytes(64)).toMat43().inverse()
			boneScale           = NoeVec3.fromBytes(ss.readBytes(12))
			BoneQuat            = NoeQuat.fromBytes(ss.readBytes(16))
			BonePos             = NoeVec3.fromBytes(ss.readBytes(12))
			
			boneMtxList.append(boneMtxLocal)
			BonePosList.append(BonePos)
			boneParentList.append(boneParent)
			BoneQuatList.append(BoneQuat)
			
			BoneLocalPosList.append(boneMtxLocal.toAngles().toVec3())
			BoneLocalRotList.append(boneMtxLocal.toQuat())
			
			ss.seek(0x2, NOESEEK_REL)
			newBone = NoeBone(i, boneName, boneMtx, None, boneParent)
			animBones.append(newBone)
	
	# Zagruzka animacii	
	bs.readBytes(4)
	bs.seek(16, NOESEEK_ABS)
	boneCount = bs.readUShort()
	animationDuration = bs.readFloat()
	NumFrames = int(animationDuration * 30.0)
	bs.readBytes(4)
	
	boneList = []
	kfBones = []
	timeList=[]
	
	for m in range(0, boneCount1):
		boneHash1 = bs.readUInt()
		
		name = boneNames[m]
		Parent = boneParentList[m]

		RotKeys = []; TrnKeys = []
				
		scaleKeyframeCount = bs.readUShort()
		for n in range(0, scaleKeyframeCount):#scale key
			scalekeyframe = bs.readUShort()//33 
			bs.readHalfFloat(); bs.readHalfFloat(); bs.readHalfFloat()

		rotationKeyframeCount = bs.readUShort()
		for n in range(0, rotationKeyframeCount):#rotation key
			rotationkeyframe = bs.readUShort()//33
			BoneQuat = NoeQuat( (bs.readHalfFloat(), bs.readHalfFloat(), bs.readHalfFloat(), bs.readHalfFloat()) )
			if Parent is not -1:
				RotKeys.append(NoeKeyFramedValue(rotationkeyframe, BoneQuat * BoneLocalRotList[Parent]))
			else:
				RotKeys.append(NoeKeyFramedValue(rotationkeyframe, BoneQuat))
			
		positionKeyframeCount = bs.readUShort()
		for n in range(0, positionKeyframeCount):#transaltion key
			positionkeyframe = bs.readUShort()//33
			BonePosition = NoeVec3( (bs.readHalfFloat(), bs.readHalfFloat(), bs.readHalfFloat()) )
			if Parent is not -1:
				TrnKeys.append(NoeKeyFramedValue(positionkeyframe, BonePosition + BonePosList[Parent]))
			else:
				TrnKeys.append(NoeKeyFramedValue(positionkeyframe, BonePosition + BonePosList[m]))

		kfBone = NoeKeyFramedBone(m)
		kfBone.setRotation(RotKeys, noesis.NOEKF_ROTATION_QUATERNION_4, noesis.NOEKF_INTERPOLATE_LINEAR)
		kfBone.setTranslation(TrnKeys, noesis.NOEKF_TRANSLATION_VECTOR_3, noesis.NOEKF_INTERPOLATE_LINEAR)
		kfBones.append(kfBone)
	anims.append(NoeKeyFramedAnim("BlackDesert anim", animBones, kfBones, 1))	
	

	
	
	idxList = []
	posList = []
	mesh = NoeMesh(idxList, posList)
	meshes.append(mesh)
	mdl = NoeModel(meshes, animBones, anims)
	mdlList.append(mdl)			#important, don't forget to put your loaded model in the mdlList
	
	return 1