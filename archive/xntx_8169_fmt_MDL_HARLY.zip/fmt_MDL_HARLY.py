# by Durik for xentax.com 
from inc_noesis import *

def registerNoesisTypes():
   handle = noesis.register("Harley Davidson", ".MDL")
   noesis.setHandlerTypeCheck(handle, CheckType)
   noesis.setHandlerLoadModel(handle, LoadModel)
   return 1

def CheckType(data):
    f = data.find(b'POLYVERTEX')
    if f == -1:
        return 0
    return 1       

def LoadModel(data, mdlList):
    bs = NoeBitStream(data)
    
    ioff = data.find(b'POLYVERTEX') + 10
    voff = data.find(b'VERTEXLOC') + 9
    print(ioff, voff)
    
    bs.seek(ioff)
    itype, isize, inum = [bs.readInt() for x in range(3)]
    print(itype, isize, inum)
    ibuf = bs.readBytes(isize)
    
    bs.seek(voff)
    vtype, vsize, vnum = [bs.readInt() for x in range(3)]
    print(vtype, vsize, vnum)
    vbuf = bs.readBytes(vsize)

    ctx = rapi.rpgCreateContext()
                
    rapi.rpgBindPositionBuffer(vbuf, noesis.RPGEODATA_FLOAT, vtype)
    rapi.rpgCommitTriangles(ibuf, noesis.RPGEODATA_INT, inum*3, noesis.RPGEO_TRIANGLE)
            
    mdl = rapi.rpgConstructModel()
    
    mdlList.append(mdl)
    return 1