float __fastcall Aska::AafKeyframeData_Quaternion_Linear_U48EX::GetValue(Aska::AafKeyframeData_Quaternion_Linear_U48EX *this, float *a2)
{  #input  Gun_skill_20f_unpack. 0x42D0 TO 0x4B90
   #sample :58 1a 33 94 24 5c// 58 1a 33 94 24 5c//fc 1e 51 9c 31 dc //da 25 1a e3 4a dc
   #hypothesis:v3= 24 5c #worong:be lenth not enough to >>31 ,fix v3 = 24 5c ,58 1a 33 94 24 5c        ,or just 48bit =24 5c ,58 1a 33 94
   #           v4= (0x12866)| 2 * (0x5c2494331a58 & 0xFFFF)= (0x12866)| 2 * (0x1a58) = 0x12866 | 0x34b0 = 0x13cf6
   #                v5 = 1- (0.61907)^2=0.61674
   #                v6 = float(0x250cc696 & 0x3FFF)=float(0x696)=1686.0 ???
   #                v7 = cos(0x1c24* 0.00009588)=cos(0.690719)=0.77078 ,v8=0.63709
   #                v9 = cosf(1686.0 * 0.00009588) = 0.986962 ,v10_result=0.16095
   #                     v11 = -v8*v9 = -0.62878 ,v12=-v8*v10=-0.10253   ,v13=-0.77078
   #                     if v3 & 0x10000000!=0,so v12=         0.10253
   #                     v14 =sqrtf( 1-0.61674*0.61674) = 0.78716
   #                     v15 =v11*v14= -0.49495, v17=v12*v14=0.0807,v16=v13*v14=-0.60672
   #                         v5^2 + v15^2 + v17^2 +v16^2 = 0.9999653 = w^2 +x^2+y^2+z^2
  float *v2; // r8
  unsigned int v3; // r6
  int v4; // r0
  float v5; // s16
  float v6; // s0
  float v7; // r9
  float v8; // r5
  float v9; // r4
  float result; // r0
  float v11; // s20
  float v12; // s26
  float v13; // s18
  float v14; // s0
  float v15; // s22
  float v16; // s18
  float v17; // s20
  float v18; // s0
  float v19; // s2

  v2 = a2;
  ##define DWORD unsigned long
  ##                            4 bytes
  #because input a 6 byte=48bit,so default use 64bit Uint?  #fix 32bit
  #v7 = *(_DWORD *)(v7 + 8);  Means : v7 = *(v7 + 8)
  #huibian### MOV v7, DWORD PTR [v7 + 0x8]
  #       ###       double word pointer,            memory address 0x???([v7+8*sizeof(DWORD)]) ,where value asign to v7
  #       ###                                                            ##HERE IS C++,NOT C!!!! NOT array[index]
  v3 = *((_DWORD *)this + 1);  #v3= pointer( lenth_of_int32or64 * input + 1 )
  #2^31 = 0xFFFF FFFF
  v4 = (v3 >> 31) | 2 * (*(_DWORD *)this & 0xFFFF); # =(v3 /2^31 ) BITor  [(kInt) and 11111...) <<1]    #final save v3 [64~32] [BITor kInt's 0 <<1]
  #                                        ,0xFFFF,lower 15bit <<1, <<1 left a empty postion for join in    
  #v3's  48Bit[32bit]               48Bit[33~48bit]  in fact =v3's 48Bit[-15~0bit]  =v4 's 48Bit[1~15bit]
  v5 = 1.0 - (float)((float)((float)(unsigned int)v4 / 131070.0) * (float)((float)(unsigned int)v4 / 131070.0)); #float 0x40FFFFE0,int0x1fffe,16Bit,2byte , =1-Y^2  
  #v5 should be a sin or a cos
  #v5 = cos(angle/2)? from "angleToQuaternion" ,as Quaternion_w
  # --http://www.euclideanspace.com/maths/geometry/rotations/conversions/angleToQuaternion/index.htm
  
  #cos(2angle) = 1-2 * (sin(angle))^2 
  #what the ?
  if ( v5 >= 0.0 )  #IF Y<=1:
  {
    if ( v5 > 1.0 ) 
      v5 = 1.0;#never
  }
  else
  {
    v5 = 0.0;
  }
  #v5 in [0,1]
  v6 = (float)((v3 >> 14) & 0x3FFF); # = moveout[1~14]  and 0011 11..  #set [17~18] to zero ,== [48 47...33,00 ,31 30.. 16 15th]
  #3FFF = 0011 1111 1111 =lower  10bit
  #14 +10=24bit = 3byte
  v7 = cosf((float)(v3 & 0x3FFF) * 0.00009588); #0x38C9132F  ,1/16384= 0.00006103, 9588/6103=1.57
  v8 = sinf((float)(v3 & 0x3FFF) * 0.00009588); #                                      #0x3FFF =16383,16386*0.00009588=1.57 , =3.1415926/2 = 90 angle , Unsign 90?
  v9 = cosf(v6 * 0.00009588);  #v9 = cos( (float)((v3 >> 14) & 0x3FFF)* 0.00009588 )
  result = sinf(v6 * 0.00009588);
  v11 = -(float)(v8 * v9);   # =- sin(a) *cos(b)  #axis_x
  v12 = -(float)(v8 * result); # =- sin(a) *sin(b)  #axis_y
  v13 = -v7; #=-cos(a)  #axis_z
  if ( !(v3 & 0x20000000) )#0010 00...   if v3[14] !=1
    v13 = v7; #*-1
  if ( !(v3 & 0x40000000) )#0100 00...   if v3[15] !=1
    v11 = v8 * v9; #*-1
  v14 = sqrtf(1.0 - (float)(v5 * v5));
  if ( !(v3 & 0x10000000) )#             if v3[16] !=1
    v12 = v8 * result;#*-1
  #the "Rectangular Coordinate"axis is normalised so: axis_x^2 + : axis_y^2 + : axis_z^2 = 1
  #IF in Polar Coordinate (3D_version) (r,a,b),
  #    x=rsin(a)cons(b)
  #    y=rsin(a)sin(b)
  #    z=cos(b)
  #    default radiu=1, r = 1.

  #v3 structure 48Bit[1~24bit] Polar Coordinate message : 48Bit[14~24bit] angle a,48Bit[1~10bit] angle b, ,48Bit[30bit] angle b's +or-, 48Bit[29bit]and[31bit] angle a's in where [0,90] [90,180],[180,270],[270,360]

  #             [32~48]:48Bit[-15~0bit]<<1 | 48Bit[32bit] sin(angle/2)
  
  v15 = v11 * v14; # sin * cos
  v16 = v13 * v14; # cos
  v17 = v14 * v12; # sin * sin
  #qx = ax * sin(angle/2)
  #qz = az * sin(angle/2)
  #qy = ay * sin(angle/2)
  v18 = (float)(v5 * v5) + (float)((float)((float)(v15 * v15) + (float)(v16 * v16)) + (float)(v17 * v17));
  #because norlised , w^2 +x^2+y^2+z^2 = 1
  if ( v18 > 0.000001 )
  {
    v19 = sqrtf(v18);
    v5 = v5 / v19;
    v17 = v17 / v19;
    v16 = v16 / v19;
    v15 = v15 / v19;
  }
  *v2 = v15;   #x
  v2[1] = v16; #z
  v2[2] = v17; #y
  v2[3] = v5; #w
  return result;
}
