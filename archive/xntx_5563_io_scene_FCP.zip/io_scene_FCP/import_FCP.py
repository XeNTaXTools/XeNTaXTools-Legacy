# author: Volfin

import bpy
import os
import sys
import mathutils
import math
import platform
import imp
import csv
import struct
from bpy_extras.io_utils import unpack_list
from struct import *
from mathutils import Vector, Matrix, Quaternion, Euler
import time
import random
import numpy as np

matList = []  # materials List
boneMapList = []
boneClearNAMES = []
LODList = [];
filehandle = 0
majorRevision = 0
minorRevision = 0

def to_blender_matrix(bl_mat):
    mat = mathutils.Matrix()
    for i, col in enumerate(bl_mat):
        for k, val in enumerate(col):
            mat[k][i] = val
    return mat

def import_mesh(context,randomize_colors,import_vertcolors,use_Skeleton,mesh_scale,Block_Count):
    
    global file_path,model_name,majorRevision,minorRevision,filehandle
    SWAP_YZ_MATRIX = mathutils.Matrix.Rotation(math.radians(180.0), 4, 'Z')
    
    # lets just do this to be sure    
    if bpy.ops.object.mode_set.poll():
        bpy.ops.object.mode_set(mode='OBJECT')
    #else:
    #    print("mode_set() context is incorrect, current mode is", bpy.context.mode)

    def processVertexData(vertexCount):
        print ("Vertex MajorRev:"+str(majorRevision))
        print("UVOffset:"+str(uvOffset)+" uvMult:"+str(uvMultiplier))
        for pk in range(vertexCount):
            flg = VB['flag']
            #print("Flag:"+str(flg))
            if flg | 1 == flg:
                #print ('in 1')
                vx = Bf(1)[0]
                vy = Bf(1)[0]
                vz = Bf(1)[0]
                pt = (vx, vy, vz)
                vertexArray.append(pt)
            if flg | 2 == flg:
                #print ('in 2')
                vx = Bh(1)[0] * vertexMultiplier
                vy = Bh(1)[0] * vertexMultiplier
                vz = Bh(1)[0] * vertexMultiplier
                vw = Bh(1)[0]
                pt = (vx, vy, vz)
                vertexArray.append(pt)
            if flg | 32 == flg:
                print ('in 32')
                vx = rdf(struct.unpack("2B", filehandle.read(2)),16,'LIttle')
                vy = rdf(struct.unpack("2B", filehandle.read(2)),16,'LIttle')
                vz = rdf(struct.unpack("2B", filehandle.read(2)),16,'liTTLe')
                pt = (vx, vy, vz)
                vertexArray.append(pt)
            if flg | 8 == flg:
                #print ('in 8')
                u1 = (Bh(1)[0] * uvMultiplier) + uvOffset
                v1 = (Bh(1)[0] * (uvMultiplier * -1)) + uvOffset
                UV1.extend([(u1, v1)])
            if flg | 2048 == flg:
                #print ('in 2048')
                u2 = Bh(1)[0] * uvMultiplier + uvOffset
                v2 = Bh(1)[0] * (uvMultiplier * -1) + uvOffset
                UV2.extend([(u2, v2)])
            if flg | 4096 == flg:
                #print ('in 4096')
                u3 = Bh(1)[0] * uvMultiplier + uvOffset
                v3 = Bh(1)[0] * (uvMultiplier * -1) + uvOffset
                UV3.extend([(u3, v3)])
            if flg | 8192 == flg:
                #print ('in 8192')
                u4 = Bh(1)[0] * uvMultiplier + uvOffset
                v4 = Bh(1)[0] * (uvMultiplier * -1) + uvOffset
                UV4.extend([(u4, v4)])
        
            if flg | 16 == flg:
                #print ('in 16')
                w1 = BB(1)[0] /255.0
                w2 = BB(1)[0] /255.0
                w3 = BB(1)[0] /255.0
                w4 = BB(1)[0] /255.0
                
                bi1 = BB(1)[0]
                bi2 = BB(1)[0]
                bi3 = BB(1)[0]
                bi4 = BB(1)[0]
                
                if w4 != 0:
                    #print("did 4")
                    bt = (bi1, bi2, bi3, bi4)
                    wt = (w1,w2,w3,w4)
                    vbBIDS.append(bt)
                    vbWeights.append(wt)
                
                elif w3 != 0:
                    #print("did 3")
                    bt = (bi1, bi2, bi3)
                    wt = (w1,w2,w3)
                    vbBIDS.append(bt)
                    vbWeights.append(wt)
                elif w2 != 0:
                    #print("did 2")
                    bt = (bi1, bi2)
                    wt = (w1,w2)
                    vbBIDS.append(bt)
                    vbWeights.append(wt)
                    
                else:
                    #print("did 1")
                    bt = (bi1,)
                    wt = (w1,)
                    vbBIDS.append(bt)
                    vbWeights.append(wt)
            else:
                #print('in else')
                bt = (0,)
                wt = (1.0,)
                vbBIDS.append(bt)
                vbWeights.append(wt)
        
            if flg | 128 == flg:
                #print ('in 128')
                nx = (BB(1)[0] / 255.0)*2 -1 
                ny = (BB(1)[0] / 255.0)*2 -1
                nz = (BB(1)[0] / 255.0)*2 -1
                nw = (BB(1)[0] / 255.0)*2 -1
                nt = (nx, ny, nz)
                normalArray.extend([nt])
        
            if flg | 64 == flg:
                #print ('in 64')
                cr = BB(1)[0]
                cg = BB(1)[0]
                cb = BB(1)[0]
                ca = BB(1)[0]
                #rgba = (cr,cg,cb,ca)
                colorr.extend([(cr/255.0,cg/255.0,cb/255.0)])                  
             
            if flg | 256 == flg:
                #print ('in 256')
                filehandle.seek(4,1)
            if flg | 512 == flg:
                #print ('in 512')
                filehandle.seek(4,1)
            if flg | 32768 == flg:
                #print ('in 32768')
                filehandle.seek(4,1)

    # establish variables
    me = None
    me_obj = None 
    armature_ob = None
    
    buffData = {}
    unkMatrices = []
    trans = []
    unkCrap = {}
    materials = []
    boneNAMES = []
    SKID = {}
    clusters = {}
    matFaces = []
    something = []
    
    
    new = True

    for i in range(0,Block_Count):
        
        #Block 1
        sectionStart = filehandle.tell()
        print("Chunkstart:"+str(sectionStart))
        chunkName = file_str(4)
        chunkNum = BI(1)[0]
        chunkSize = BI(1)[0]
        nextChunk = BI(1)[0]
        subChunks = BI(1)[0]
        print("Chunk:"+chunkName)

        if chunkName == 'LTMR': #RMTL
            numMats = BI(1)[0]
            print("nummats:"+str(numMats)+" MajorRev:"+str(majorRevision))
            if majorRevision >= 52 or majorRevision == 42:
                null = BI(1)[0]
            for j in range(numMats):
                strLen = BI(1)[0]
                matPath = file_str(strLen)
                print("matPath:"+str(matPath))
                if majorRevision == 42:
                    matName = matPath.split('\\')[-1].encode('ascii','ignore').split('.')[0]
                    matList.append((matName,matPath))
                filehandle.seek(1,1) # SEEK_CUR
                if majorRevision >= 52:
                    strLen = BI(1)[0]
                    matName = file_str(strLen)
                    print("matName:"+matName)
                    matList.append((matName,matPath))
                    filehandle.seek(1,1) # SEEK_CUR
        elif chunkName == 'LEKS': #SKEL
            skelBool = BI(1)[0]

        elif chunkName == 'ITOM': #MOTI  *new* for Primal
            motiBool = BI(1)[0]
        
        elif chunkName == 'EDON': #NODE
            
            Bone_parents = []
            MF_List = []
            Bone_Table=[]
            Pose_Table=[]            

            nodeCount = BI(1)[0]

            for y in range(0,nodeCount):

                nameHash = BI(1)[0]
                nextSiblingIdx = BI(1)[0]
                firstChildIdx = BI(1)[0]
                Bone_parents.append(Bi(1)[0]) # signed so root = -1

                if majorRevision == 46:
                    mf = Bf(12)
                else:
                    mf = Bf(10)

                #kludge fix: set root translation to 0,0,0 for compatibility.
                if y == 0:
                    mf[4] = 0.0
                    mf[5] = 0.0
                    mf[6] = 0.0
                    
                MF_List.append(mf)

                O2BMIndex = Bi(1)[0]
                unk1 = Bf(1)[0]
                unk2 = BI(1)[0]
                nameLen = BI(1)[0]
                boneName = file_str(nameLen)

                if boneName[0].isalpha() == False:
                    boneName = 'bone_' + boneName
                boneNAMES.append(boneName)
                if O2BMIndex != -1:  # guess what, if this is -1, this bone isn't used, so don't use it!
                    boneClearNAMES.append(boneName)
                
                filehandle.seek(1,1) #SEEK_CUR
                if majorRevision == 46:
                    filehandle.seek(4,1) #SEEK_CUR
                    
            #print("Parents:"+str(Bone_parents))
            #print("Names:"+str(boneClearNAMES))
            for y in range(0,nodeCount):
                parent_name = None
                parent_id=Bone_parents[y]
                if parent_id != -1:
                    parent_name = boneNAMES[parent_id]

                loc_n_rot = MF_List[y]
                Bone_Table.extend([(boneNAMES[y],parent_name,(loc_n_rot[4],loc_n_rot[5]*-1,loc_n_rot[6]*-1))]) # Flip on Y Axis
                Pose_Table.extend([(boneNAMES[y],(loc_n_rot[4],loc_n_rot[5]*-1,loc_n_rot[6]*-1),(loc_n_rot[0],loc_n_rot[1],loc_n_rot[2],loc_n_rot[3]))])

            # build the skeleton
            result = [obj for obj in bpy.context.scene.objects if obj.type == "ARMATURE" and obj.name == "Skeleton"]

            if use_Skeleton and len(result)!=0:
                armature_ob = result[0]
            else:
                armature_ob = createRig('Skeleton', Vector((0,0,0)), Bone_Table)
                poseRig(armature_ob, Pose_Table,False,mesh_scale)
                

        elif chunkName == 'MB02': #O2BM
            numEntries = BI(1)[0]
            for m in range(numEntries):
                mr = Bf(16) #fh.read("16f")
                unkMatrices.append(mr)
        
        elif chunkName == 'DIKS': #SKID
            matCount = BI(1)[0]
            SKID['MaterialCount'] = matCount
            for lj in range(matCount):
                SKID[lj] = {}
                s1 = BI(1)[0]
                s2 = BH(1)[0]
                s3 = BH(1)[0]
                if majorRevision >= 52:
                    null = BI(1)[0]
                SKID[lj]['Data'] = (s1,s2,s3)
        
        elif chunkName == 'DNKS': #SKND
            for p in range(subChunks):
                subchunkName = file_str(4)
                unk = BI(1)[0]
                size = BI(1)[0]
                dataSize = BI(1)[0]
                unk2 = BI(1)[0]                

                for kl in range(SKID['MaterialCount']):
                    #print("writing cluster set "+str(kl))
                    clusters[kl] = {}
                    mCount = BI(1)[0]
                    #print ("SKND mCount:"+str(mCount))
                    for ch in range(mCount):
                        firstPart = BH(7)
                        secondPart = Bh(48)
                        if majorRevision >= 46:
                            godOnlyKnows = BH(32)
                        clusters[kl]['count'] = mCount
                        clusters[kl][ch] = {'first':firstPart,'second':secondPart}
               
            meshcount = BI(1)[0]
            print ("SKND meshcount:"+str(meshcount))
            for z in range(meshcount):
                drawDistance = Bf(1)[0]
                if majorRevision == 46:
                    cr = Bf(21)
                    flags = BI(1)[0]
                    mrNull = BI(1)[0]
                    hashBrowns = BI(1)[0]
                    filehandle.seek(1,1) # SEEK_CUR
                    unkCrap[z] = {hashBrowns:cr}
                if majorRevision >=52 or majorRevision == 42:
                    cr = Bf(10)
                    flags = BI(1)[0]
                    mrNull = BI(1)[0]
                    stLen = BI(1)[0]
                    name = file_str(stLen)
                    print("SKND name:"+name)
                    filehandle.seek(1,1) # SEEK_CUR
                    unkCrap[z] = {name:cr}
        
        elif chunkName == 'SDOL': #LODS
            There = filehandle.tell()
            filehandle.seek(sectionStart + chunkSize + 20,0) # SEEK_SET
            bFloats1 = Bf(3)
            bFloats2 = Bf(3)
            print("bFloats1:"+str(bFloats1))

            if majorRevision >= 55:
                filehandle.seek(109,1) # SEEK_CUR
            else:
                filehandle.seek(84,1) # SEEK_CUR
            vertexOffset = Bf(1)[0]
            vertexMultiplier = Bf(1)[0]
            
            filehandle.seek(22,1) # SEEK_CUR
            uvOffset = Bf(1)[0]
            uvMultiplier = Bf(1)[0]

            print("UVOffset:"+str(uvOffset)+" uvMult:"+str(uvMultiplier))
            if uvOffset == 0.523193359375:
                uvOffset = 0.5
                print("using fixed UV offset")
                
            filehandle.seek(There,0) # SEEK_SET
            LODcount = BI(1)[0]
            #for fg in range(LODcount):
            drawDistance = Bf(1)[0]
            buffCount = BI(1)[0]
            for r in range(buffCount):
                flag = BI(1)[0]
                stride = BI(1)[0]
                vCount = BI(1)[0]
                offset = BI(1)[0]
                buffData[r] = {'flag':flag, 'stride':stride, 'vCount':vCount, 'offset':offset}
            
            
            numEntries = BI(1)[0]
            subMeshData = {}
            for sk in range(numEntries):
                bufferIndex = BI(1)[0]
                skeletonIndex = BI(1)[0]
                materialIndex = BI(1)[0]
                faceIndex = BI(1)[0]
                lastVertex = BI(1)[0]
                vbOffset = BI(1)[0]
                #if majorRevision >=52 or majorRevision == 42:
                #    theresThatDamnedNullAgain = BI(1)[0]
                matFaces.append(faceIndex)
                
                subMeshData[sk] = {'Buffer Index':bufferIndex, 'Skeleton Index':skeletonIndex, \
                                'Material Index':materialIndex, 'Face Index':faceIndex, \
                                'Last Vertex':lastVertex, 'vbOffset':vbOffset}
            
            faceIDS = [0]
            for g in range(len(subMeshData)):
                if g > 0 and subMeshData[g]['Buffer Index'] != subMeshData[g-1]['Buffer Index']:
                    faceIDS.append(subMeshData[g]['Face Index'])
            
            
            buffSZ = BI(1)[0]
            
            alignPosition(16)
            
            VBoffset = filehandle.tell()
            filehandle.seek(buffSZ,1) # SEEK_CUR
            numIdx = BI(1)[0]
            print("numIdx:"+str(numIdx))
            idxBytes = numIdx * 2
            
            alignPosition(16)
            
            idxOffset = filehandle.tell()
            fi = np.fromfile(filehandle, dtype = 'b', count = idxBytes)
            filehandle.seek(VBoffset,0) # SEEK_SET
            
            matFaces.append(numIdx)
            faceIDS.append(numIdx)
            matRanges = []
            for p in range(len(subMeshData)):
                matRanges.append((matFaces[p],matFaces[p+1]))
            
            lb = len(buffData)
            if lb > 1:
                for sm in range(len(subMeshData)):
                    mName = model_name + '__' + 'SubMesh_' + str(sm)
                    vertJointWeightData = []
                    vbBIDS = []
                    vbWeights = []
                    vertexArray = []
                    normalArray = []
                    colorr = []
                    
                    UV1=[]
                    UV2=[]
                    UV3=[]
                    UV4=[]

                    face_idx = []
                    
                    firstVertex = 0
                    vertexCount = subMeshData[sm]['Last Vertex'] + 1
                    if sm > 0 and subMeshData[sm-1]['Buffer Index'] == subMeshData[sm]['Buffer Index']:
                        firstVertex = subMeshData[sm-1]['Last Vertex'] + 1
                        vertexCount -= firstVertex
                    
                    subOffset = VBoffset + subMeshData[sm]['vbOffset']
                    filehandle.seek(subOffset,0)                 

                    #############################################
                    VB = buffData[subMeshData[sm]['Buffer Index']]
                    processVertexData(vertexCount)
                    #############################################
                    print("LB > 1")
                    print("vertex array length:"+str(len(vertexArray)))
                    print("normal array length:"+str(len(normalArray)))
                    print("weights array length:"+str(len(vbWeights)))
                    print("index array length:"+str(len(vbBIDS)))
                    print("UV1 array length:"+str(len(UV1)))
                    print("UV2 array length:"+str(len(UV2)))
                    print("UV3 array length:"+str(len(UV3)))
                    print("UV4 array length:"+str(len(UV4)))
                    print("Colors array length:"+str(len(colorr)))

    
                    faceCount = numIdx//3 - subMeshData[sm]['Face Index']//3
                    
                    if subMeshData.get(sm+1, 'You\'re an idiot') != 'You\'re an idiot':
                        print("doing strange thing")
                        faceCount = subMeshData[sm+1]['Face Index']//3 - subMeshData[sm]['Face Index']//3
                    
                    idSubOFF = idxOffset + subMeshData[sm]['Face Index']*2
                    filehandle.seek(idSubOFF,0)
                    
                    faces = []
                    for i in range(numIdx):
                        data = BH(3)
                        fc = (data[2],data[1],data[0]) # flip winding
                        faces.append(fc)
                        face_idx.extend([0]) #initialize for fill-in later

                    # unselect all   
                    for item in bpy.context.selectable_objects:   
                        item.select = False

                    print("starting multi-object")
                    me = bpy.data.meshes.new(model_name)
                    me_obj = bpy.data.objects.new(model_name, me)
                    print("me:"+str(me)+" me_obj:"+str(me_obj))
                    me_obj.select = True # makes selected
                    context.scene.objects.link(me_obj)
                    context.scene.objects.active = me_obj # makes active
                    me.from_pydata(vertexArray,[],faces)
                    #me.vertices.foreach_set("normal",normalArray) # add normals
                    #me.polygons.foreach_set("use_smooth", [True] * len(me.polygons))
                    # set to smooth shaded	
                    bpy.ops.object.shade_smooth()

                    ###############################################
                    # Do UVs
                    ###############################################
                    if len(UV1) != 0:
                        me.uv_textures.new(name='UV_0')
                        uv_data = me.uv_layers[0].data
                        for i in range(len(uv_data)):
                            uv_data[i].uv = UV1[me.loops[i].vertex_index]
                    if len(UV2) != 0:
                        me.uv_textures.new(name='UV_1')
                        uv_data = me.uv_layers[1].data
                        for i in range(len(uv_data)):
                            uv_data[i].uv = UV2[me.loops[i].vertex_index]
                    if len(UV3) != 0:
                        me.uv_textures.new(name='UV_2')
                        uv_data = me.uv_layers[2].data
                        for i in range(len(uv_data)):
                            uv_data[i].uv = UV3[me.loops[i].vertex_index]
                    if len(UV4) != 0:
                        me.uv_textures.new(name='UV_3')
                        uv_data = me.uv_layers[3].data
                        for i in range(len(uv_data)):
                            uv_data[i].uv = UV4[me.loops[i].vertex_index]

                    ###############################################
                    # Do Vertex Color
                    ###############################################

                    if len(colorr) != 0 and import_vertcolors:
                        me.vertex_colors.new(name='Color_Data')
                        color_data = me.vertex_colors[0].data
                        for i in range(len(color_data)):
                            color_data[i].color = colorr[me.loops[i].vertex_index]
                        
                    
                    ###############################################
                    # Finalize
                    ###############################################

                    # finalize mesh
                    me.update(calc_edges=True)

                    #scale
                    scale_matrix = mathutils.Matrix.Scale(1.0*mesh_scale, 4)
     
            
            else:
                #meshName = boneNAMES[0]
                vertJointWeightData = []
                vbBIDS = []
                vbWeights = []
                vertexArray = []
                normalArray = []
                
                UV1=[]
                UV2=[]
                UV3=[]
                UV4=[]
                
                pConnects = []
                pCounts = []
                colorr = []

                face_idx = []
                
                vs = buffData[0]['stride']
                 
                #############################################
                vertexCount = buffData[0]['vCount']
                VB = buffData[subMeshData[0]['Buffer Index']]
                processVertexData(vertexCount)
                #############################################
                print("LB = 1")
                print("vertex array length:"+str(len(vertexArray)))
                print("normal array length:"+str(len(normalArray)))
                print("weights array length:"+str(len(vbWeights)))
                print("index array length:"+str(len(vbBIDS)))
                print("UV1 array length:"+str(len(UV1)))
                print("UV2 array length:"+str(len(UV2)))
                print("UV3 array length:"+str(len(UV3)))
                print("UV4 array length:"+str(len(UV4)))
                print("Colors array length:"+str(len(colorr)))

    
                fn = 0
                faces = []
                for j in range(numIdx//3):
                    data = struct.unpack_from("<3H", fi[fn:fn+6])
                    fc = (data[2],data[1],data[0])  # flip winding
                    faces.append(fc)
                    fn += 6
                    face_idx.extend([0]) #initialize for fill-in later
       
                # unselect all   
                for item in bpy.context.selectable_objects:   
                    item.select = False

                print("starting object")
                me = bpy.data.meshes.new(model_name)
                me_obj = bpy.data.objects.new(model_name, me)
                print("me:"+str(me)+" me_obj:"+str(me_obj))
                me_obj.select = True # makes selected
                context.scene.objects.link(me_obj)
                context.scene.objects.active = me_obj # makes active
                me.from_pydata(vertexArray,[],faces)

                ###############################################
                # Do Normals
                ###############################################
                me.create_normals_split()
                me.use_auto_smooth = True
                me.show_edge_sharp = True
                #me.validate(clean_customdata = False) #seems to break some meshes.
                me.normals_split_custom_set_from_vertices(normalArray)
                me.free_normals_split()
                me.update()
                #me.vertices.foreach_set("normal",normalArray) # add normals
                #me.polygons.foreach_set("use_smooth", [True] * len(me.polygons))
                # set to smooth shaded	
                #bpy.ops.object.shade_smooth()

                ##############################################
                # MATS
                ##############################################
                vertIDStart = 0

                #tempfile = open("C:\\Users\\Owner\\Desktop\\debug.txt", "wt")
                for m in range(0,len(subMeshData)):
                    info = subMeshData[m]
                    #tempfile.write("subMeshData[m]:"+str(info)+"\r\n")
                    subMesh = clusters[ info['Skeleton Index']] [info['Material Index'] ]
                    #tempfile.write("info['Skeleton Index']:"+str(info['Skeleton Index'])+"info['Material Index']:"+str(info['Material Index'])+"\r\n")
                    matx = matList[subMesh['first'][0]][0]
                    if matx[0].isalpha() == False:
                        matx = 'mat_' + matx
                    start = matRanges[m][0] //3
                    stop = matRanges[m][1] //3

                    mat_group = bpy.data.materials.new(matx)
                    bpy.ops.object.material_slot_add()
                    mat_group.diffuse_intensity = 1.0

                    if randomize_colors:
                        mat_group.diffuse_color = randomColor()

                    #mat.specular_color = material.specular()
                    #mat.mirror_color = material.emissive()
                    #mat.alpha = material.transparency_factor()
                    #mat.specular_intensity = material.shininess()

                    # Attempt to auto convert/assign textures
                    matFile=matList[subMesh['first'][0]][1]
                    matPath=file_path.split('graphics')[0]+matFile

                    if os.path.exists(matPath):
                        fileheld = filehandle # store model file handle
                        filehandle=open(matPath,'rb')
                        print("processing:"+matPath)
                        filehandle.seek(46,0) #SEEK_SET
                        file_str(BB(1)[0])
                        BI(1) # skip
                        file_str(BB(1)[0])

                        spec_found = False
                        norm_found = False
                        diff_found = False
                        pathFrag = ""
                        map_index=0
                        for n in range(9): #there can be a ridiculous number of textures. we go far enough for most applications.
                            filehandle.seek(10,1) #SEEK_CUR
                            print("odd_at:"+str(filehandle.tell()))
                            odd_name=BB(1)[0]
                            if odd_name == 4:
                                BI(2)
                            else:
                                file_str(odd_name)
                                BI(7)

                            odd_name2=BB(1)[0]                           
                            if odd_name2 == 4:
                                BI(1)
                                pathFrag=""
                            else:
                                pathFrag=file_str(odd_name2)
                                
                            if pathFrag == "":
                                continue
                            
                            xbtPath=file_path.split('graphics')[0]+pathFrag
                            #print("XBT:"+xbtPath)
                            if os.path.exists(xbtPath)==True:
                                ddsPath=xbtPath.replace('.xbt','.dds')
                                #print("DDS:"+ddsPath)
                                # only convert if not already there
                                if os.path.exists(ddsPath)==False:
                                    xbtParser(xbtPath)

                                root, ext = os.path.splitext(ddsPath)
                                tex_name=root.split("\\")[-1]                                

                                if ddsPath.find("_s.") != -1 and spec_found == False: #specular
                                    tex = mat_group.texture_slots.create(map_index)
                                    tex.texture = bpy.data.textures.new(tex_name, type='IMAGE')
                                    tex.texture_coords = 'UV'
                                    tex.use = True
                                    tex.use_map_color_diffuse = False
                                    tex.use_map_specular = True
                                    tex.texture.image = bpy.data.images.load(ddsPath)
                                    spec_found = True
                                    map_index = map_index + 1
                                elif ddsPath.find("_n.") != -1 and norm_found == False: # Normals
                                    tex = mat_group.texture_slots.create(map_index)
                                    tex.texture = bpy.data.textures.new(tex_name, type='IMAGE')
                                    tex.texture_coords = 'UV'
                                    tex.use = True
                                    tex.use_map_color_diffuse = False
                                    tex.use_map_normal = True
                                    tex.normal_map_space = 'TANGENT'
                                    tex.texture.image = bpy.data.images.load(ddsPath)
                                    tex.texture.use_normal_map = True #yes the names are odd but right
                                    norm_found = True
                                    map_index = map_index + 1
                                elif ddsPath.find("_d.") != -1 and diff_found == False: # diffuse
                                    tex = mat_group.texture_slots.create(map_index)
                                    tex.texture = bpy.data.textures.new(tex_name, type='IMAGE')
                                    tex.texture_coords = 'UV'
                                    tex.use = True
                                    tex.use_map_color_diffuse = True
                                    tex.use_map_alpha = True
                                    diff_found = True
                                    map_index = map_index + 1
                                    
                                    # set transparency options
                                    mat_group.use_transparency = True
                                    mat_group.transparency_method ='MASK'
                                    mat_group.alpha = 0.0
                                    
                                    tex.texture.image = bpy.data.images.load(ddsPath)

                        filehandle.close()
                        filehandle = fileheld # back to model file

                    #tempfile.write("setting materials slot "+str(m)+" to "+str(mat_group)+"\r\n")
                    #tempfile.write("START:"+str(start)+" END:"+str(stop)+"\r\n")
                    me_obj.material_slots[m].material = mat_group

                    for j in range(start,stop): # Start number, count
                        #print("assigning material ",x," to index ",j)
                        face_idx[j]=m

                    if len(vbWeights) > 0:

                        ##############################################
                        # create bone group
                        ##############################################
                        #tempfile.write("Submesh:"+str(subMesh['second'])+"\r\n")
                        #tempfile.write("VertIDStart:"+str(vertIDStart)+" - subMesh[first][5]:"+str(subMesh['first'][5])+"\r\n")
                        for n in range(vertIDStart,vertIDStart+subMesh['first'][5]):
                            for g in range(len(vbBIDS[n])):

                                #tempfile.write("Vertex:"+str(n)+" w_index:"+str(g)+" vbBIDS:"+str(vbBIDS[n][g])+" bID:"+str(subMesh['second'][vbBIDS[n][g]])+" name:"+str(boneNAMES[subMesh['second'][vbBIDS[n][g]]])+"\r\n")                                
                                bID = subMesh['second'][vbBIDS[n][g]]
                                
                                bone_name = boneNAMES[bID] # was bID
                                weight = vbWeights[n][g]
                                #tempfile.write(" -"+str(bone_name)+", W:"+str(weight)+", cnt:"+str(g)+"\r\n")
                                # use existing group or new
                                group = None
                                if bone_name in me_obj.vertex_groups.keys():
                                    group = me_obj.vertex_groups[bone_name]
                                if group == None:
                                    group = me_obj.vertex_groups.new(bone_name)


                                if weight == 0: # no weight = no influence, so not acutally used
                                    continue;
                                group.add([n], weight, 'ADD')
                                
                        vertIDStart += subMesh['first'][5]
                                
                ######################################################
                #tempfile.close() # debug
                me.polygons.foreach_set("material_index",face_idx) # should set multiple mat indexes.

                ###############################################
                # Do UVs
                ###############################################
                if len(UV1) != 0:
                    me.uv_textures.new(name='UV_0')
                    uv_data = me.uv_layers[0].data
                    for i in range(len(uv_data)):
                        uv_data[i].uv = UV1[me.loops[i].vertex_index]
                if len(UV2) != 0:
                    me.uv_textures.new(name='UV_1')
                    uv_data = me.uv_layers[1].data
                    for i in range(len(uv_data)):
                        uv_data[i].uv = UV2[me.loops[i].vertex_index]
                if len(UV3) != 0:
                    me.uv_textures.new(name='UV_2')
                    uv_data = me.uv_layers[2].data
                    for i in range(len(uv_data)):
                        uv_data[i].uv = UV3[me.loops[i].vertex_index]
                if len(UV4) != 0:
                    me.uv_textures.new(name='UV_3')
                    uv_data = me.uv_layers[3].data
                    for i in range(len(uv_data)):
                        uv_data[i].uv = UV4[me.loops[i].vertex_index]

                ###############################################
                # Do Vertex Color
                ###############################################

                if len(colorr) != 0 and import_vertcolors:
                    me.vertex_colors.new(name='Color_Data')
                    color_data = me.vertex_colors[0].data
                    for i in range(len(color_data)):
                        color_data[i].color = colorr[me.loops[i].vertex_index]
                
                


                ###############################################
                # Finalize
                ###############################################

                # finalize mesh
                print("finalize me:"+str(me)+" - "+str(me_obj))
                me.update(calc_edges=True)

                #scale
                scale_matrix = mathutils.Matrix.Scale(1.0*mesh_scale, 4)

                me_obj.matrix_basis = SWAP_YZ_MATRIX * scale_matrix#* global_trans

                # apply transforms (rotation)
                bpy.ops.object.transform_apply(location=False,rotation=True,scale=True)

                # finalize mesh
                me.update(calc_edges=True)

                #add armature modifier
                mod = me_obj.modifiers.new('RigModifier', 'ARMATURE')
                mod.object = armature_ob
                mod.use_bone_envelopes = False
                mod.use_vertex_groups = True

                # sort by skeletal links
                bpy.ops.object.vertex_group_sort(sort_type='BONE_HIERARCHY')

                        
                
            ##############################################################
            filehandle.seek(sectionStart + chunkSize,0)
    
        
        elif chunkName == 'XOBB': #BBOX
            bb = Bf(6)
        
        else:
            filehandle.seek(chunkSize - 20, 1) # SEEK_CUR

            
    print("Finished Model")

    return 0 # all fine

def createRig(name, origin, boneTable):

    # Create armature and object
    bpy.ops.object.add(
        type='ARMATURE', 
        enter_editmode=True,
        location=origin)
    ob = bpy.context.object
    ob.show_x_ray = True
    ob.data.draw_type = 'STICK'
    ob.name = name
    amt = ob.data
    amt.name = name+'Amt'
    amt.show_axes = False
 
    # Create bones
    bpy.ops.object.mode_set(mode='EDIT')
    for (bname, pname, vector) in boneTable:    
        bone = amt.edit_bones.new(bname)
        if pname:
            parent = amt.edit_bones[pname]
            bone.parent = parent
            bone.head = parent.tail
            bone.use_connect = False
            if vector[0]+vector[1]+vector[2] < 0.0001:
                vector = (0,0.0001,0) # try to prevent zero length bones
            (trans, rot, scale) = parent.matrix.decompose()
        else:
            print("Making bone:"+str(bname))
            bone.head = (0,0,0)
            if vector[0]+vector[1]+vector[2] < 0.0001:
                vector = (0,0.0001,0) # try to prevent zero length bones
            rot = Matrix.Translation((0,0,0))	# identity matrix
        bone.tail = rot * Vector(vector) + bone.head
    bpy.ops.object.mode_set(mode='OBJECT')
    return ob

def poseRig(rig, poseTable,use_layers,mesh_scale):


    ROT_Y_MATRIX = mathutils.Matrix.Rotation(math.radians(180.0), 4, 'Y')
    bpy.context.scene.objects.active = rig
    bpy.ops.object.mode_set(mode='POSE')
    ROT_FIX = Matrix.Identity(4)
 
    for (bname, loc,angle) in poseTable:
        
        pbone = rig.pose.bones[bname]

        pbone.matrix_basis.identity()
        # Set rotation mode to Euler XYZ, easier to understand
        # than default quaternions
        pbone.rotation_mode = 'XYZ'
        # Documentation bug: Euler.rotate(angle,axis):
        # axis in ['x','y','z'] and not ['X','Y','Z']
        #print("quat:",angle)
        quat = Quaternion((angle[3]*-1.0,angle[0]*-1.0,angle[1],angle[2])) # flip on axis, Negate axis, negate 'w'
        euler=quat.to_euler('XYZ')
        #pbone.rotation_euler.rotate_axis('X', euler[0])
        #pbone.rotation_euler.rotate_axis('Y', euler[2])
        #pbone.rotation_euler.rotate_axis('Z', euler[1])

        #########################
        pos = Vector([float(loc[0]), float(loc[1]), float(loc[2])])
        rot = Euler([float(euler[0]), float(euler[1]), float(euler[2])])
        
        kf = Matrix.Identity(4)
        kf = Matrix.Translation(pos) * rot.to_matrix().to_4x4()

        if pbone.parent:
            pbone.matrix = pbone.parent.matrix * kf
        else:
            pbone.matrix = kf
            ROT_FIX = rot.to_matrix().to_4x4()
            ROT_FIX.invert()
        
    bpy.ops.pose.armature_apply()

    #sphere
    bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=3,size=1)
    bone_vis = bpy.context.active_object
    bone_vis.data.name = bone_vis.name = "Farcry_bone_vis"
    bone_vis.use_fake_user = True
    bpy.context.scene.objects.unlink(bone_vis) # don't want the user deleting this

    #cube
    bpy.ops.mesh.primitive_cube_add(radius=0.3)
    bone_vis2 = bpy.context.active_object
    bone_vis2.data.name = bone_vis.name = "Farcry_bone_vis2"
    bone_vis2.use_fake_user = True
    bpy.context.scene.objects.unlink(bone_vis2) # don't want the user deleting this
    
    bpy.context.scene.objects.active = rig
    ###########################

    # Calculate armature dimensions...Blender should be doing this!
    maxs = [0,0,0]
    mins = [0,0,0]
    for bone in rig.data.bones:
        for i in range(3):
            maxs[i] = max(maxs[i],bone.head_local[i])
            mins[i] = min(mins[i],bone.head_local[i])

    dimensions = []

    for i in range(3):
        dimensions.append(maxs[i] - mins[i])
        
    length = max(0.001, (dimensions[0] + dimensions[1] + dimensions[2]) / 600) # very small indeed, but a custom bone is used for display

    # Apply spheres
    bpy.ops.object.mode_set(mode='EDIT')
    for (bname, loc,angle) in poseTable:
        bone=rig.data.edit_bones[bname]
        bone.tail = bone.head + (bone.tail - bone.head).normalized() * length # Resize loose bone tails based on armature size
        if bone.name in boneClearNAMES:
            rig.pose.bones[bone.name].custom_shape = bone_vis # apply bone sphere
        else:
            rig.pose.bones[bone.name].custom_shape = bone_vis2 # apply bone square
        

    #pbone.rotation_quaternion = quat
    bpy.ops.object.mode_set(mode='OBJECT')

    #scale
    scale_matrix = mathutils.Matrix.Scale(1.0*mesh_scale, 4)

    global_trans = mathutils.Matrix.Translation((poseTable[0][1][0]*100.0,poseTable[0][1][1]*100.0,poseTable[0][1][2]*100.0))
    matrix_basis = ROT_Y_MATRIX *ROT_FIX * scale_matrix * global_trans
    rig.data.transform(matrix_basis)

    # apply transforms (rotation)
    bpy.ops.object.transform_apply(location=True,rotation=True,scale=True)
    print('ping')

##################################################################

def xbtParser(filename):
    global filehandle;
    holdfile = filehandle #save
    filehandle=open(filename,'rb')	
    BH(4)
    w=BI(1)[0]
    filehandle.seek(w)

    # get size
    back=filehandle.tell()
    filehandle.seek(0,2) #SEEK_END
    size=filehandle.tell()
    filehandle.seek(back,0) #SEEK_SET
    
    new=open(filename.replace('.xbt','.dds'),'wb')	
    new.write(filehandle.read(size-filehandle.tell()))
    new.close()
    filehandle.close()
    filehandle=holdfile # restore

##################################################################

def alignPosition(alignment):
	alignment = alignment - 1
	filehandle.seek(((filehandle.tell() + alignment) & ~alignment), 0) # SEEK_SET

def randomColor():
    randomR = random.random()
    randomG = random.random()
    randomB = random.random()
    return (randomR, randomG, randomB)

def HalfToFloat(h):
    s = int((h >> 15) & 0x00000001)    # sign
    e = int((h >> 10) & 0x0000001f)    # exponent
    f = int(h & 0x000003ff)            # fraction

    if e == 0:
       if f == 0:
          return int(s << 31)
       else:
          while not (f & 0x00000400):
             f <<= 1
             e -= 1
          e += 1
          f &= ~0x00000400
          #print (s,e,f)
    elif e == 31:
       if f == 0:
          return int((s << 31) | 0x7f800000)
       else:
          return int((s << 31) | 0x7f800000 | (f << 13))

    e = e + (127 -15)
    f = f << 13

    return int((s << 31) | (e << 23) | f)


def file_str(long): 
   s=''
   for j in range(0,long): 
       lit =  unpack('c',filehandle.read(1))[0]
       #print("ord of "+str(lit)+" is "+str(ord(lit)))
       if ord(lit)!= 0:
           s+=lit.decode("utf-8",'ignore')
       else:
           pass; # keep reading # of values specified even if 0
   return s

def readcstr():
    buf = ''
    while True:
        b = unpack('c',filehandle.read(1))[0]
        #print("ord of "+str(b)+" is "+str(ord(b)))
        if b is None or ord(b) == 0:
            return buf
        else:
            buf+=b.decode("utf-8")

def BB(n): # Unsigned Char Default is < (little Endian)  > = Big-Endian
    array = [] 
    for id in range(n): 
        array.append(unpack('B', filehandle.read(1))[0])
    return array
def Bb(n): # Signed Char
    array = [] 
    for id in range(n): 
        array.append(unpack('b', filehandle.read(1))[0])
    return array
def BH(n): # Unsigned Short
    array = [] 
    for id in range(n): 
        array.append(unpack('H', filehandle.read(2))[0])
    return array
def Bh(n): # Signed Short
    array = [] 
    for id in range(n): 
        array.append(unpack('h', filehandle.read(2))[0])
    return array
def Bf(n): # Float
	array = [] 
	for id in range(n):
		nz=filehandle.read(4)
		#print("NZ:"+str(nz))
		array.append(unpack('f',nz )[0])
	return array
def BF(n): # HALF FLoat
    array = [] 
    for id in range(n):
        nz=filehandle.read(2)
        #print("NZ:"+str(nz))
        v = struct.unpack('H', nz)
        x = HalfToFloat(v[0])
        # hack to coerce int to float
        str = struct.pack('I',x)
        f=struct.unpack('f', str)
        array.append(f[0])
    return array
def Bi(n): # Signed Long Int
    array = [] 
    for id in range(n): 
        array.append(unpack('i', filehandle.read(4))[0])
    return array
def BI(n): # Unsigned Long Int
    array = [] 
    for id in range(n): 
        array.append(unpack('I', filehandle.read(4))[0])
    return array
def Bd(n): # Double
    array = [] 
    for id in range(n): 
        array.append(unpack('d', filehandle.read(8))[0])
    return array

def views():
    """ Returns the set of 3D views.
    """
    rtn = []
    for a in bpy.data.screens["Default"].areas:
        if a.type == 'VIEW_3D':
            rtn.append(a)
    return rtn

def import_FCP(file, context, randomize_colors,import_vertcolors,skip_blank,use_Skeleton,mesh_scale):

    global file_path,filehandle,model_name,matList,boneMapList,LODList,majorRevision,minorRevision
    report = None

    time1 = time.time()
    print("start")

    matList = [];  # materials List
    boneMapList = [];
    LODList = [];

    workingpath=os.path.dirname(os.path.realpath(__file__))

    #adjust clipping mode
    view=views()
    print(view[0].spaces[0].type)  # should be VIEW_3D
    view[0].spaces[0].clip_end=10000

    # split off model name
    file_path=file # for use later
    root, ext = os.path.splitext(file)
    model_name=root.split("\\")[-1]
    print(model_name)

    ##################################
    try:
        filehandle = open(file, "rb")
    except:
        report="Error loading '"+model_name+".xbg'\n"
        return report

    #get key data about the mesh
    Magic = file_str(4)
    majorRevision = BH(1)[0]
    minorRevision = BH(1)[0]

    if Magic != 'HSEM': # should be reversed MESH header.
        report=model_name+".xbg doesn't seem to be a model file."
        return report

    if majorRevision != 0x3A or minorRevision != 0x06:
        report=model_name+".xbg is wrong version (Watchdogs 1?)."
        return report

    # unselect all   
    for item in bpy.context.selectable_objects:   
        item.select = False  

    #read in junk
    BI(5)
    unk_Count = BI(1)[0]
    print("Count:"+str(unk_Count))

    # at model start
    ####################################

    # do mesh and materials
    result=import_mesh(context,randomize_colors,import_vertcolors,use_Skeleton,mesh_scale,unk_Count)

    if result is None:
        report = "Mesh Output Failed."
    elif result == 1:
        report = "Vertice counts didn't match, aborting!"


    # should be at end of models, process last
    filehandle.close()

    print("time is ", time.time() - time1)
    return report
