from inc_noesis import *

import noesis
import rapi

def registerNoesisTypes():
	handle = noesis.register("The iDOLM@STER One For All Model", ".pmd")
	noesis.setHandlerTypeCheck(handle, pmdCheckType)
	noesis.setHandlerLoadModel(handle, pmdLoadModel)
    
	handle = noesis.register("The iDOLM@STER One For All Texture Archive", ".pta")
	noesis.setHandlerTypeCheck(handle, ptaCheckType)
	noesis.setHandlerLoadRGBA(handle, ptaLoadRGBA)
    
	handle = noesis.register("Graphics Texture Format", ".gtf")
	noesis.setHandlerTypeCheck(handle, gtfCheckType)
	noesis.setHandlerLoadRGBA(handle, gtfLoadRGBA)

	noesis.logPopup()
	return 1

NOEPY_HEADER = "PMD"

def ptaCheckType(data):
	bs = NoeBitStream(data)
	return 1

def gtfCheckType(data):
	bs = NoeBitStream(data)
	return 1

def pmdCheckType(data):

	bs = NoeBitStream(data)
	if len(data) < 3:
		return 0
	if bs.readBytes(3).decode("ASCII") != NOEPY_HEADER:
		return 0
	return 1

def gtfLoadRGBA(data, texList):

	bs = NoeBitStream(data, NOE_BIGENDIAN)

	TexName = rapi.getExtensionlessName(rapi.getLocalFileName(rapi.getLastCheckedName()))
	print(TexName+".gtf")

	GTFVer = bs.readInt()
	TexSize = bs.readInt()
	TexCNT = bs.readInt()
	bs.seek(0x04, NOESEEK_REL)
	TexSizeHeader = bs.readInt()
	TexSizeNoPadding = bs.readInt()

	print(TexSize)

	GTFunk1 = int.from_bytes(bs.readBytes(1), "big")
	GTFunk2 = int.from_bytes(bs.readBytes(1), "big")
	GTFunk3 = int.from_bytes(bs.readBytes(1), "big")
	GTFunk4 = int.from_bytes(bs.readBytes(1), "big")

	bs.seek(0x04, NOESEEK_REL)

	imgWidth = bs.readShort()
	imgHeight = bs.readShort()
	imgDepth = bs.readShort()
	print(imgWidth, "x", imgHeight)
	print(imgDepth)

	print(GTFunk1)
	print(GTFunk2)
	print(GTFunk3)
	print(GTFunk4)

	bs.seek(0x5A, NOESEEK_REL)

	data = bs.readBytes(TexSize)
	if GTFunk1 == 133:
		data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "a8r8g8b8")
		data = rapi.imageFromMortonOrder(data, imgWidth, imgHeight, 4)
		texFMT = noesis.NOESISTEX_RGBA32
	elif GTFunk1 == 134:
		texFMT = noesis.NOESISTEX_DXT1
	elif GTFunk1 == 135:
		texFMT = noesis.NOESISTEX_DXT3
	elif GTFunk1 == 136:
		texFMT = noesis.NOESISTEX_DXT5
	texList.append(NoeTexture(TexName, imgWidth, imgHeight, data, texFMT))
	return 1

def ptaLoadRGBA(data, texList):

	bs = NoeBitStream(data, NOE_BIGENDIAN)
    
	TextureOffsets = []
	TextureNames = []
	Files = []
    
	Header = bs.readBytes(3).decode("ASCII")
	print(Header)
	bs.seek(0x5, NOESEEK_REL)
	FileCount=bs.readInt()
	print(FileCount)
	bs.seek(0x4, NOESEEK_REL)
	for i in range(0, FileCount):
		TextureOffsets.append (bs.readInt())
	if(FileCount % 4 != 0):
		bs.seek((4 - FileCount % 4)*4, NOESEEK_REL)

	for i in range(0, FileCount):
		TextureNames.append(bs.readBytes(128).decode("UTF-8").rstrip("\0"))

	print(TextureOffsets)
	print(TextureNames)

	bs = NoeBitStream(data)
	bs.setEndian(NOE_BIGENDIAN)
	bs.seek(TextureOffsets[0], NOESEEK_ABS)

	for i in range(0, FileCount):
		bs.seek(TextureOffsets[i], NOESEEK_ABS)
		GTFVer = bs.readInt()
		TexSize = bs.readInt()
		TexCNT = bs.readInt()
		bs.seek(0x04, NOESEEK_REL)
		TexSizeHeader = bs.readInt()
		TexSizeNoPadding = bs.readInt()

		print(TexSize)

		GTFunk1 = int.from_bytes(bs.readBytes(1), "big")
		GTFunk2 = int.from_bytes(bs.readBytes(1), "big")
		GTFunk3 = int.from_bytes(bs.readBytes(1), "big")
		GTFunk4 = int.from_bytes(bs.readBytes(1), "big")

		bs.seek(0x04, NOESEEK_REL)

		imgWidth = bs.readShort()
		imgHeight = bs.readShort()
		imgDepth = bs.readShort()
		print(imgWidth, "x", imgHeight)
		print(imgDepth)

		print(GTFunk1)
		print(GTFunk2)
		print(GTFunk3)
		print(GTFunk4)

		bs.seek(0x5A, NOESEEK_REL)

		data = bs.readBytes(TexSize)
		if GTFunk1 == 133:
			data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "a8r8g8b8")
			data = rapi.imageFromMortonOrder(data, imgWidth, imgHeight, 4)
			texFMT = noesis.NOESISTEX_RGBA32
		elif GTFunk1 == 134:
			texFMT = noesis.NOESISTEX_DXT1
		elif GTFunk1 == 135:
			texFMT = noesis.NOESISTEX_DXT3
		elif GTFunk1 == 136:
			texFMT = noesis.NOESISTEX_DXT5
		texList.append(NoeTexture(TextureNames[i], imgWidth, imgHeight, data, texFMT))

	return 1

def pmdLoadModel(data, mdlList):

	global boneList, texList, texNameList
	boneList = []
	texList = []
	texNameList = []

	baseName = rapi.getExtensionlessName(rapi.getLocalFileName(rapi.getLastCheckedName()))
	texName = baseName
	if baseName.endswith("glamour"):
		texName = baseName[:-8]
	elif baseName.endswith("slender"):
		texName = baseName[:-8]

	bs = NoeBitStream(data, NOE_BIGENDIAN)
	bs.seek(0x10, NOESEEK_ABS) #PTR - Bone block
	BoneBlock=bs.readBytes(3).decode("UTF-8")
	print(BoneBlock)
	bs.seek(0x05, NOESEEK_REL)
	BoneCountOffset=bs.readInt()
	print(BoneCountOffset)
	BoneBlockSize = bs.readInt()
	print(BoneBlockSize)
	bs.seek(BoneCountOffset, NOESEEK_ABS)
	BoneCount=bs.readInt()
	print(BoneCount)
	bs.seek(8*BoneCount+12, NOESEEK_REL)
	BoneNames = []
	for i in range(0, BoneCount):
		BoneID = bs.readInt()
		bs.seek(8, NOESEEK_REL)
		BoneNames.append(bs.readBytes(32).decode("UTF-8").rstrip("\0"))
		if(BoneNames[i] == ""):
			BoneNames[i] = "ROOT"
		BoneParent = bs.readInt()
		bs.seek(0x9C, NOESEEK_REL)
		Mat44 = NoeMat44.fromBytes( bs.readBytes(0x40), NOE_BIGENDIAN )
		bs.seek(0x10, NOESEEK_REL)
		MATRIX = Mat44.toMat43().inverse()
		boneList.append( NoeBone(BoneID, BoneNames[i], MATRIX, None, BoneParent) )
	print(BoneNames)
	MeshBlock=bs.readBytes(3).decode("UTF-8")
	print(MeshBlock)
	bs.seek(0xD, NOESEEK_REL)
	MeshCount=bs.readInt()
	print(MeshCount)
	bs.seek(MeshCount*8+8, NOESEEK_REL)
	ctx = rapi.rpgCreateContext()
	rapi.rpgSetOption(noesis.RPGOPT_BIGENDIAN, 1)
	MeshNames = []
	MaterialInfo = []
	for i in range(0, MeshCount):
		bs.seek(0x10, NOESEEK_REL)
		MeshNames.append (noeStrFromBytes(bs.readBytes(0x20), "UTF8"))

		bs.seek(0x18, NOESEEK_REL)
		VertCount = bs.readInt()

		bs.seek(4, NOESEEK_REL)
		VertSize = bs.readInt()
		FaceSize = VertSize // VertCount
		print(FaceSize)
		FaceIndexCount = bs.readInt()

		bs.seek(4, NOESEEK_REL)
		FaceIndexSize = bs.readInt()
		IndexSize = FaceIndexSize // FaceIndexCount

		bs.seek(0x58, NOESEEK_REL)
		MeshOffset = bs.readInt()

		bs.seek(0x84, NOESEEK_REL)
		MeshOffset += bs.tell()

		VData = bs.readBytes(VertSize)
		IndexData = bs.readBytes(FaceIndexSize)

		rapi.rpgSetName(MeshNames[i])
		rapi.rpgBindPositionBuffer(VData, noesis.RPGEODATA_FLOAT, FaceSize)
		rapi.rpgBindNormalBufferOfs(VData, noesis.RPGEODATA_SHORT, FaceSize, 16)
		rapi.rpgBindUV1BufferOfs(VData, noesis.RPGEODATA_HALFFLOAT, FaceSize, 24)
		#rapi.rpgBindBoneIndexBufferOfs(VData, noesis.RPGEODATA_UBYTE, FaceSize, 30, 4)
		#rapi.rpgBindBoneWeightBufferOfs(VData, noesis.RPGEODATA_UBYTE, FaceSize, 18, 4)
		if IndexSize == 1:
			idxType = noesis.RPGEODATA_UBYTE
		elif IndexSize == 2:
			idxType = noesis.RPGEODATA_USHORT
		else:
			idxType = noesis.RPGEODATA_INT

		rapi.rpgCommitTriangles(IndexData, idxType, FaceIndexCount, noesis.RPGEO_TRIANGLE_STRIP, 1)
		rapi.rpgClearBufferBinds()
		
		bs.seek(MeshOffset, NOESEEK_ABS)

	print(MeshNames)

	bs.seek(0x04, NOESEEK_REL)
	MaterialBlock=noeStrFromBytes(bs.readBytes(3), "UTF8")
	print(MaterialBlock)
	bs.seek(0x09, NOESEEK_REL)
	MaterialOffset=bs.readInt()
	print(MaterialOffset)
	MaterialCount=bs.readInt()
	print(MaterialCount)
	bs.seek(0xF, NOESEEK_REL)
	bs.seek(MaterialCount*8+10, NOESEEK_REL)

	bs.seek(MaterialOffset-13, NOESEEK_REL)
	TextureBlock=noeStrFromBytes(bs.readBytes(3), "UTF8")
	print(TextureBlock)
	bs.seek(0xD, NOESEEK_REL)
	TextureCount=bs.readInt()
	print(TextureCount)
	bs.seek(0xF, NOESEEK_REL)
	bs.seek(TextureCount*8+41, NOESEEK_REL)
	TextureNames = []
	for i in range(0, TextureCount):
		TextureNames.append (noeStrFromBytes(bs.readBytes(40), "UTF8") + ".gtf")
		bs.seek(0x148, NOESEEK_REL)
	print(TextureNames)

	if( rapi.checkFileExists( rapi.getDirForFilePath( rapi.getLastCheckedName() ) + texName + ".pta" ) ):
		data = rapi.loadIntoByteArray( rapi.getDirForFilePath( rapi.getLastCheckedName() ) + texName + ".pta" )
		ptaLoadRGBA(data, texList)

	mdl = rapi.rpgConstructModel()
	mdl.setBones(boneList)
	mdlList.append(mdl)
	return 1