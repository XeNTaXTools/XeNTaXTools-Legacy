# Euro Truck Simulator
# Noesis script by Dave, 2022


from inc_noesis import *


def registerNoesisTypes():
	handle = noesis.register("Euro Truck Simulator",".pmg")
	noesis.setHandlerTypeCheck(handle, bcCheckType)
	noesis.setHandlerLoadModel(handle, bcLoadModel)
	return 1


# Check file type

def bcCheckType(data):
	bs = NoeBitStream(data)
	file_id = bs.readUInt()

	if file_id != 0x506d6715:
		print("Invalid file")
		return 0
	else:
		return 1

	return 1


# Read the model data

def bcLoadModel(data, mdlList):
	bs = NoeBitStream(data)
	ctx = rapi.rpgCreateContext()

	curr_folder = rapi.getDirForFilePath(rapi.getInputName()).lower()
	curr_file = rapi.getLocalFileName(rapi.getInputName()).lower()

	bs.seek(0x54)
	mesh_info = bs.readUInt()
	name_off = bs.readUInt()
	mesh_count = (name_off - mesh_info) // 0x64
	name_size = bs.readUInt()
	vert_start = bs.readUInt()							# not needed for script
	vert_size = bs.readUInt()							# "" ""
	face_start = bs.readUInt()							# "" ""
	face_size = bs.readUInt()							# "" ""

	for a in range(mesh_count):
		bs.seek(mesh_info + (a * 0x64))
		face_count = bs.readUInt()
		vert_count = bs.readUInt()
		bs.readUInt()
		misc1 = bs.readUInt()						# different mesh type ?
		misc2 = bs.readUInt()
		bs.seek(0x28, 1)
		stride = bs.readUInt()
		vert_start = bs.readUInt()
		norm_off = bs.readInt()
		uv_off = bs.readInt()
		bs.seek(0x14, 1)
		face_start = bs.readUInt()

		bs.seek(vert_start)
		vertices = bs.readBytes(vert_count * stride)
		bs.seek(face_start)
		faces = bs.readBytes(face_count * 2)

		rapi.rpgSetName("Mesh_" + str(a))
		rapi.rpgBindPositionBufferOfs(vertices, noesis.RPGEODATA_FLOAT, stride, 0)

		if norm_off != -1:
			rapi.rpgBindNormalBufferOfs(vertices, noesis.RPGEODATA_FLOAT, stride, norm_off - vert_start)

		if uv_off != -1:
			rapi.rpgBindUV1BufferOfs(vertices, noesis.RPGEODATA_FLOAT, stride, uv_off - vert_start)

		rapi.rpgCommitTriangles(faces, noesis.RPGEODATA_USHORT, face_count, noesis.RPGEO_TRIANGLE)

		rapi.rpgClearBufferBinds()

	try:
		mdl = rapi.rpgConstructModel()
	except:
		mdl = NoeModel()

	mdlList.append(mdl)

	return 1





