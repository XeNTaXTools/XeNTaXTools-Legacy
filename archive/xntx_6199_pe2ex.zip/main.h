#include <stdlib.h>
#include <stdio.h>
#include <cstring>
#include <vector>

#include "pe2lzss.h"

/*
Parasite eve 2 CDF parser
Refer to a PE2ISO::extract() for a data blocks descriptions
*/

struct BLOCKHDR
{
    unsigned short block_type;
	unsigned short sector_size;
	unsigned int   sectors_num;
	unsigned int   unknown1; //most of the cases == 0x00000000. Rarely equals to address (ff04h/0104h blocks) or to other unknown value (ff00h/0100h blocks)
	unsigned int   unknown2; //maybe just 4 dummy zeroes to make header 16 byte long
	
	unsigned long  offset;
};

class PE2ISO
{
public:
    
	PE2ISO(char *path)
	{
	    this->ifname = path;
		_splitpath(this->ifname, this->drive, this->directory, this->fname, this->fext);
		char mdir[256];
		strcpy(mdir, "md ");
		strcat(mdir, fname);
		
		system(mdir);
		
		this->error = 0;
	    
	    this->iso = fopen(path, "rb");
		
		if( this->iso == NULL )
		{
		    this->error = 1;
			return;
		}
		
		fseek(this->iso, 0, SEEK_END);
		this->iso_size = ftell(this->iso);
		rewind(this->iso);
		
		this->parse();
		this->extract();
	}
	
	~PE2ISO()
	{
	    if( this->iso != NULL ) fclose(iso);
	}
	
	void debug()
	{
	    FILE *fo;
		fo = fopen("debug.txt", "wb");
		
		unsigned long scntr = 0;
		
		fprintf(fo, "Number of blocks: %u\n\n", this->blocks.size());
		
		for(unsigned int i = 0; i < this->blocks.size(); i++)
		{
		    fprintf(fo, "Block %u - offset: 0x%08x, type: 0x%04x, size: %u\n", i+1, this->blocks[i].offset, this->blocks[i].block_type, this->blocks[i].sectors_num * 0x800);
			scntr += this->blocks[i].sectors_num * 0x800;
		}
		
		fprintf(fo, "/nTotal size: %u\n", scntr);
		
		fclose(fo);
	}
	
	unsigned int get_error() 
	{
	    return this->error;
	}
	
private:
    std::vector<BLOCKHDR> blocks;
    unsigned int error;
    unsigned long iso_size;
    FILE *iso;
	
	char* ifname;
	
	char drive[3];
	char directory[256];
	char fname[256];
	char fext[256];
	
	
	
	void parse()
	{
	    //Search blocks
        BLOCKHDR buff;
		float progress = 0.0;
		while(fread(&buff, 16, 1, this->iso) == 1)
		{	
			switch(buff.block_type)
			{
			    case 0x0100:
				case 0xff00:
				case 0x0101:
				case 0xff01:
				case 0x0102:
				case 0xff02:
				case 0x0103:
				case 0xff03:
				case 0xff04:
				case 0x0104:
				case 0x0105:
				case 0xff05:
				case 0x0106:
				case 0xff06:
				case 0x0107:
				case 0xff07:
				{
				    if( (buff.sector_size == 0x0800 || buff.sector_size == 0x0600 || buff.sector_size == 0x0500) && buff.sectors_num > 0 && buff.unknown2 == 0 )
					{
						buff.offset = ftell(this->iso) - 16;
						this->blocks.push_back(buff);
					}
					break;
				}
				default:
				    //fseek(this->iso, -15, SEEK_CUR);
					break;
			}
			
		}
		printf("\n");
	}
	
	void extract()
	{
        //Extract finded blocks
		for(unsigned int i = 0; i < this->blocks.size(); i++)
		{
		    char ext[256];
			char ofname[256];
		    unsigned char *input_buffer;
			unsigned int ibsize = 0;
		    unsigned int image_counter = 0;
		    unsigned int header_size = 16; //offset from the block beginning to the actual data
		    unsigned int buffer;
			bool image = false;
			
		    switch(this->blocks[i].block_type)
			{
			     //Image data block
                 case 0x0101:
				 case 0xff01:
				 {
		             image = true;
					 strcpy(ext, ".pe2img");
					 fseek(this->iso, this->blocks[i].offset + 20, SEEK_SET);
					 fread(&header_size, sizeof(unsigned int), 1, this->iso); //images has long headers with sub header length, coordinates and dummy zeroes
					 header_size += 16; //previous line rewrote main header length, so we'll just add it again
					 fseek(this->iso, this->blocks[i].offset + 16, SEEK_SET);
					 
				     while(true)
					 {
					     fread(&buffer, sizeof(unsigned int), 1, this->iso);
						 if((buffer & 0x0000ffff) != 0x0000ffff) 
						 {
						     image_counter++;
						     fread(&buffer, sizeof(unsigned int), 1, this->iso);
						 }
						 else break;
						 
						 if(image_counter > 10)
						 {
						     printf("Image counter > 10!\n");
							 break;
						 }
					 }
					 printf("Image data block %u...\n", i+1);
					 break;
				}
                //CLUT (Color palette) data block
				case 0x0102:
				case 0xff02:
				    image = false;
					strcpy(ext, ".pe2clut");
					header_size += 16;
					printf("CLUT container block %u...\n", i+1);
					break;
                //Compressed binary data (models, enemy programs, e.t.c)
				case 0x0100:
				case 0xff00:
				    image = false;
					strcpy(ext, ".pe2pkg");
					printf("Package block %u...\n", i+1);
				    break;
				case 0x0103:
				case 0xff03:
				{
				    strcpy(ext, ".03");
					printf("Unknown ff03/0103 block %u...\n", i+1);
					char fnumber[256];
			        itoa(i + 1, fnumber, 10);
			        strcpy(ofname, ".\\");
			        strcat(ofname, this->fname);
			        strcat(ofname, "\\");
			        strcat(ofname, fnumber);
			        strcat(ofname, ext);
					
					fseek(this->iso, this->blocks[i].offset, SEEK_SET);
					unsigned char output[blocks[i].sectors_num * 0x0800];
					fread(output, blocks[i].sectors_num * 0x0800, 1, this->iso);
					
					FILE* fo;
					fo = fopen(ofname, "wb");
					if(fo == NULL)
			        {
			            printf("Error opening output file %s!\n", ofname);
				        return;
			        }
					fwrite(output, blocks[i].sectors_num * 0x0800, 1, fo);
					fclose(fo);
					continue;
					break;
				}
                //Character dialogue blocks
                //May rarely contain compressed data
				case 0xff04:
				case 0x0104:
			    {
				    strcpy(ext, ".04");
					printf("Unknown ff04/0104 block %u...\n", i+1);
					char fnumber[256];
			        itoa(i + 1, fnumber, 10);
			        strcpy(ofname, ".\\");
			        strcat(ofname, this->fname);
			        strcat(ofname, "\\");
			        strcat(ofname, fnumber);
			        strcat(ofname, ext);
					
					fseek(this->iso, this->blocks[i].offset, SEEK_SET);
					unsigned char output[blocks[i].sectors_num * 0x0800];
					fread(output, blocks[i].sectors_num * 0x0800, 1, this->iso);
					
					FILE* fo;
					fo = fopen(ofname, "wb");
					if(fo == NULL)
			        {
			            printf("Error opening output file %s!\n", ofname);
				        return;
			        }
					fwrite(output, blocks[i].sectors_num * 0x0800, 1, fo);
					fclose(fo);
					continue;
					break;
				}
                //MDEC images (backgrounds, loading screens)
				case 0x0105:
				case 0xff05:
				{
				    strcpy(ext, ".bs");
					printf("MDEC .BS image %u...\n", i+1);
					char fnumber[256];
			        itoa(i + 1, fnumber, 10);
			        strcpy(ofname, ".\\");
			        strcat(ofname, this->fname);
			        strcat(ofname, "\\");
			        strcat(ofname, fnumber);
			        strcat(ofname, ext);
					
					fseek(this->iso, this->blocks[i].offset + 16, SEEK_SET);
					unsigned char output[blocks[i].sectors_num * 0x0800 - 16];
					fread(output, blocks[i].sectors_num * 0x0800 - 16, 1, this->iso);
					
					FILE* fo;
					fo = fopen(ofname, "wb");
					if(fo == NULL)
			        {
			            printf("Error opening output file %s!\n", ofname);
				        return;
			        }
					fwrite(output, blocks[i].sectors_num * 0x0800 - 16, 1, fo);
					fclose(fo);
					continue;
					break;
				}
                //Sound programs (music)
				case 0x0106:
				case 0xff06:
				{
				    strcpy(ext, ".spk");
					printf("SPK/MPK block %u...\n", i+1);
					char fnumber[256];
			        itoa(i + 1, fnumber, 10);
			        strcpy(ofname, ".\\");
			        strcat(ofname, this->fname);
			        strcat(ofname, "\\");
			        strcat(ofname, fnumber);
			        strcat(ofname, ext);
					
					fseek(this->iso, this->blocks[i].offset, SEEK_SET);
					unsigned char output[blocks[i].sectors_num * 0x0800];
					fread(output, blocks[i].sectors_num * 0x0800, 1, this->iso);
					
					FILE* fo;
					fo = fopen(ofname, "wb");
					if(fo == NULL)
			        {
			            printf("Error opening output file %s!\n", ofname);
				        return;
			        }
					fwrite(output, blocks[i].sectors_num * 0x0800, 1, fo);
					fclose(fo);
					continue;
					break;
				}
                //Text data (items descriptions)
				case 0x0107:
				case 0xff07:
				{
				    strcpy(ext, ".txt");
					printf("Text block %u...\n", i+1);
					char fnumber[256];
			        itoa(i + 1, fnumber, 10);
			        strcpy(ofname, ".\\");
			        strcat(ofname, this->fname);
			        strcat(ofname, "\\");
			        strcat(ofname, fnumber);
			        strcat(ofname, ext);
					
					fseek(this->iso, this->blocks[i].offset, SEEK_SET);
					unsigned char output[blocks[i].sectors_num * 0x0800];
					fread(output, blocks[i].sectors_num * 0x0800, 1, this->iso);
					
					FILE* fo;
					fo = fopen(ofname, "wb");
					if(fo == NULL)
			        {
			            printf("Error opening output file %s!\n", ofname);
				        return;
			        }
					fwrite(output, blocks[i].sectors_num * 0x0800, 1, fo);
					fclose(fo);
					continue;
					break;
				}
				default: continue;
			}
			
			char fnumber[256];
			itoa(i + 1, fnumber, 10);
			strcpy(ofname, ".\\");
			strcat(ofname, this->fname);
			strcat(ofname, "\\");
			strcat(ofname, fnumber);
			strcat(ofname, ext);
			
			fseek(this->iso, this->blocks[i].offset + header_size, SEEK_SET);
			
					 
			ibsize = this->blocks[i].sectors_num * 0x0800 - header_size;
			input_buffer = new unsigned char[ibsize];
			fread(input_buffer, ibsize, 1, this->iso);
			pe2lzss::init(input_buffer, ibsize, image);
			pe2lzss::unpack();
			FILE *fo;
			fo = fopen(ofname, "wb");
			if(fo == NULL)
			{
			    printf("Error opening output file %s!\n", ofname);
				return;
			}
			
			printf("Preparing outbuff...\n");
			unsigned char outbuff[pe2lzss::outbuff.size()];
			/*for(int i = 0; i < pe2lzss::outbuff.size(); i++)
			{
			    outbuff[i] = pe2lzss::outbuff[i];
			}*/
			std::copy(pe2lzss::outbuff.begin(), pe2lzss::outbuff.end(), outbuff);
			
			fwrite(outbuff, pe2lzss::outbuff.size(), 1, fo);
			fclose(fo);
		}
	}
};