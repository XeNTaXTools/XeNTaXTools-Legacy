/*****************************************************/
/*           Parasite eve 2 CDF extractor            */
/*            By md_hyena, Moscow, 2015              */
/*****************************************************/

#include "main.h"

int main(int argc, char **argv)
{
    
	
	if(argc < 2)
    {
        printf("Usage: PE2Ex.exe \"Path-To-PE2-ISO\"\n");
        return -1;
    }

	PE2ISO *iso = new PE2ISO(argv[1]);
	if(iso->get_error() != 0)
	{
	    printf("Error opening file %s!\n", argv[1]);
		return -1;
	}
	
	iso->debug();
	delete iso;
	
	return 0;
}