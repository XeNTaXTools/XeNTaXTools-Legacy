/*****************************************************/
/*                 PE2lzss decoder                   */
/*            By md_hyena, Moscow, 2015              */
/* Based on lzss encoder-decoder By Haruhiko Okumura */
/*****************************************************/

#include <vector>

#define BS 256   //Dictionary size, bytes
#define OS 8     //Offset length, bits
#define SS 4     //String length, bits
#define RS SS+OS //Reference size
#define LS 8     //Literal size
#define COR 1    //Dictionary index correction, algorithm should start unpacking to dict[1], not dict[1]!


namespace pe2lzss{

int bit_buffer       = 0; 
int bit_mask         = 128;

unsigned long insize = 0;

unsigned char dict[BS];
unsigned char *inbuff;
//unsigned char *outbuff;
std::vector<unsigned char> outbuff;


unsigned long obcar = 0;  //Output buffer carriage
unsigned long ibcar = 0;  //Input buffer carriage
unsigned int dictcar = 0; //Dictionary carriage

unsigned long image_counter = 1;
unsigned long image_size = 0;

int buf, mask = 0;
bool image = false;

int init(unsigned char *input, unsigned long inlen, bool isimage)
{
    std::vector<unsigned char> empty;
    outbuff.swap(empty);
    obcar = 0;
    ibcar = 0;
    inbuff = input;
    insize = inlen;
    image = isimage;
}

int getbit(int n) //get n bits from input buffer
{
    int i, x;
    
    x = 0;
    for (i = 0; i < n; i++) {
        if (mask == 0) {
            
            buf = *(inbuff + ibcar);
            ibcar++;
            mask = 128;
        }
        x <<= 1;
        if (buf & mask) x++;
        mask >>= 1;
    }
    return x;
}

void writetodict(unsigned char byte) //write byte to dictionary and advance carriage position
{
    dict[dictcar] = byte;
    dictcar++;
    dictcar &= 0x000000ff; //to exclude dictionary overflowing
    return;
    
}

unsigned char readfromdict(unsigned char pos) //read byte from dictionary at position pos
{
    unsigned char byte = dict[pos];
    return byte;
}

/*void writetooutbuff(unsigned char byte)
{
    
    if(outbuff == NULL){
        outbuff = new unsigned char[obcar+1];
    }
    
    else{
        unsigned char tempbuff[obcar];
        for(int i = 0; i < obcar; i++) tempbuff[i] = outbuff[i];
        delete[] outbuff;
        outbuff = NULL;
        outbuff = new unsigned char[obcar+1];
        for(int i = 0; i < obcar; i++) outbuff[i] = tempbuff[i];
    }
    outbuff[obcar] = byte;
    obcar++;
}*/

void writetooutbuff(unsigned char byte) //write byte to output buffer
{
    image_size++;
    outbuff.push_back(byte);
    return;
}

int EOS() //Check if end of packed data stream is met
{
    if(inbuff + insize - 1 == inbuff + ibcar)
    {
        return 1;
    }
    else return 0;
}

int skipzeroes() //Skip alignment zeroes
{
    if(EOS()) return 1;
    
    if(inbuff[ibcar] == 0x00)
    {
        ibcar++;
        skipzeroes();
    }
    
    return 0;
}


void unpack()
{
    for(int i = 0; i < BS; i++) dict[i] = 0;
    dictcar = 0;
    
    buf = 0;
    mask = 0;
    while(true)
    {
        if(getbit(1))
        {
            unsigned char literal = getbit(LS);
            writetodict(literal);
            writetooutbuff(literal);
        }
        else
        {
            unsigned char offset = getbit(OS);
            if(offset == 0) break;
            unsigned char length = getbit(SS);

            if(offset != 0) offset -= COR;
            else offset = 255;

            for(int i = 0; i < length + 2; i++)
            {      
                unsigned char literal = readfromdict(offset);
                writetodict(literal);
                writetooutbuff(literal);
                if(offset != 255) offset++;
                    else offset = 0;
            }
        }
    }
    
    if(!skipzeroes() && !EOS()) //Try to remove redutant bytes if image size is exceeded
    {
        image_size--;
        if(image_size == 32768)
        {
            image_size = 0;
        }
        
        if(image_size != 0) outbuff.resize(outbuff.size() - 1);
        
        unpack();
    }
    return;
}

}