from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("iOS Activity app", ".bdg")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    return 1   

def noepyLoadModel(data, mdlList):
    ctx = rapi.rpgCreateContext()
    bs = NoeBitStream(data)
    VCount = bs.readUInt()
    FCount = bs.readUInt() * 3
    numMatGroups = bs.readUInt()
    texIndex = []
    numFaces = []
    for i in range(numMatGroups):
        texNum = bs.readUInt()
        texIndex.append(texNum)
    for i in range(numMatGroups):
        numFace = bs.readUInt() * 3
        numFaces.append(numFace)
    VBuf = bs.readBytes(VCount * 32)
    for i in range(numMatGroups):
        rapi.rpgSetName(str(texIndex[i]))
        IBuf = bs.readBytes(numFaces[i] * 4)
        rapi.rpgBindPositionBufferOfs(VBuf, noesis.RPGEODATA_FLOAT, 32, 0)
        rapi.rpgBindNormalBufferOfs(VBuf, noesis.RPGEODATA_FLOAT, 32, 12)
        rapi.rpgBindUV1BufferOfs(VBuf, noesis.RPGEODATA_FLOAT, 32, 24)
        rapi.rpgCommitTriangles(IBuf, noesis.RPGEODATA_INT, numFaces[i], noesis.RPGEO_TRIANGLE, 1)
    mdlList.append(rapi.rpgConstructModel())
    rapi.rpgClearBufferBinds()
    return 1