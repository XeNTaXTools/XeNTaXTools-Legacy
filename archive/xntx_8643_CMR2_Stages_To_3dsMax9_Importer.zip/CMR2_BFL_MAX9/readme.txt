instalation:
-copy "zlib1.dll" in 3dsmax9 root folder, "C:\Program Files\Autodesk\3ds Max 9\"
-copy "max9cmr2bfl.dli"in 3dsmax9 plugins folder, "C:\Program Files\Autodesk\3ds Max 9\plugins"

usage:
start max, Menu->File->Import, choose *bfl in extension filter list and select any of the bfl files from 
"Colin McRae Rally 2\Game\Tracks", except the texture pack files as described below:

track geometry bfls:
	each country has several tracks each with 2 different lods, ie.:
		fin01hi.bfl
		fin01lo.bfl


texture pack bfls:	
	in each country folder you wil see 2 texture pack files, 
	also in bfl format but with name sightly different:
		finhit.bfl
		finlot.bfl
	notice they have a "t" at the end of the name and they don't contain any number
	!!! do not select any of those texture pack files in max.


however the plugin will do all the dirty work for you, it will decompress, extract and save the textures
in your "Scenes" directory in max, 
	(default path "c:\Documents and Settings\Administrator.DECK2\My Documents\3dsmax\scenes"), 
also the textures will be loaded as max materials and assigned to objects so in the end you should
see the materials as they are in game - more or less :)

notes:	- the whole thing should take 10 - 30 seconds on an average PC;
	- no other tools are required for decompression or extraction;
	- this plugin it will work only with 3dstudiomax version 9;
	- the plugin was not extensively tested so bugs may show off in a form or another;
	- no network activity involved;
	- feel free do to whatever you want with this plugin;

(c)black f.

