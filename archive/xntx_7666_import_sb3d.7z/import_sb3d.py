import bpy
import struct
import bmesh
import zstandard as zstd
import numpy as np


from mathutils import *
from math import *
from io import BytesIO


bl_info = {
	"name": "Import NFS No Limit Models format (.sb3d)",
	"description": "Test",
	"author": "GreenTrafficLight",
	"version": (1, 0),
	"blender": (2, 80, 0),
	"location": "File > Import > NFS No Limit Importer (.sb3d)",
	"warning": "",
	"wiki_url": "",
	"tracker_url": "",
	"support": "COMMUNITY",
	"category": "Import-Export"}

class BinaryReader:
    def __init__(self, data, endian="<"):
        self.data = data
        self.endian = endian

        self.seek(0)

    def seek(self, offset, option=0):
        if option == 1:
            self.data.seek(offset, 1)
        elif option == 2:
            self.data.seek(offset, 2)
        else:
            self.data.seek(offset, 0)

    def tell(self):
        return self.data.tell()

    def read(self, size):
        return self.data.read(size)

    def readInt(self):
        return struct.unpack(self.endian + "i", self.read(4))[0]

    def readShort(self):
        return struct.unpack(self.endian + "h", self.read(2))[0]

    def readUShort(self):
        return struct.unpack(self.endian + "H", self.read(2))[0]
    
    def readChar(self):
        return struct.unpack(self.endian + "c", self.read(1))[0]

    def readByte(self):
        return struct.unpack(self.endian + "b", self.read(1))[0]
    
    def readUByte(self):
        return struct.unpack(self.endian + "B", self.read(1))[0]
    
    def readBytes(self, size):
        ret = bytearray()
        for i in range(size):
            ret.append(struct.unpack(self.endian + "B", self.read(1))[0])
        return bytes(ret)

    def readFloat(self):
        return struct.unpack(self.endian + "f", self.read(4))[0]

    def bytesToString(self, byteArray, encoding="utf-8"):
        return byteArray.decode(encoding)
    
    
class Matrix4x4:
    def __init__(self, matrix = ((0.0, 0.0, 0.0, 0.0),
                                 (0.0, 0.0, 0.0, 0.0), 
                                 (0.0, 0.0, 0.0, 0.0), 
                                 (0.0, 0.0, 0.0, 0.0))):
        self.matrix = matrix
        
    def fromBytes(data):
        row1 = struct.unpack("ffff", data[0:16])
        row2 = struct.unpack("ffff", data[16:32])
        row3 = struct.unpack("ffff", data[32:48])
        row4 = struct.unpack("ffff", data[48:64])
        return (row1, row2, row3, row4)
    
class Vector4:
    def __init__(self, vector4 = (0.0, 0.0, 0.0, 0.0)):
        self.vector4 = vector4
        
    def fromBytes(data):
        x,y,z,w = struct.unpack("ffff", data)
        return x,y,z,w


class Vector3:
    def __init__(self, vector3 = (0.0, 0.0, 0.0)):
        self.vector3 = vector3
        
    def fromBytes(data):
        x,y,z = struct.unpack("fff", data)
        return x,y,z

class SB3D_MATERIAL:
    def __init__(self):
        self.name = ""
    
class SB3D_NODE:
    def __init__(self):
        self.name = ""
        self.min = 0
        self.max = 0
        
        self.parentIndex = 0
        self.childIndex = 0
        
class SB3D_SHAPE:
    def __init__(self):
        self.name = ""
        self.meshName = ""
        
        self.boneIndex = 0
        
        self.subMeshCount = 0
        self.vertexBufferIndex = 0
        self.faceBuffersIndex = []
        
        self.stride = 0
        self.vertexNumber = 0
        self.facesCount = []
        
        self.BBoxMin = None
        self.BBoxMax = None

class sb3dModel:
    def __init__(self, bs, file):
        self.bs = bs
        self.file = file
        
        self.separate = self.file.separate
        
        self.buildMesh()
    
    def buildMesh(self):
        print("----------------------------")
        
        # TO DO :
        # Add hierarchy
        # Add materials
        # Add locators
        # Add support for different vertex format
        
        clearScene()
        
        for shape in self.file.meshList:
            
            mesh = bpy.data.meshes.new(shape.meshName)
            obj = bpy.data.objects.new(shape.meshName, mesh)
            obj.rotation_euler = ( radians(90), 0, 0 )
            
            if bpy.app.version >= (2, 80, 0):
                bpy.context.scene.collection.objects.link(obj)
            else:
                bpy.context.scene.objects.link(obj)            
            
            minx = shape.BBoxMin[0]
            miny = shape.BBoxMin[1]
            minz = shape.BBoxMin[2]
            
            maxx = shape.BBoxMax[0]
            maxy = shape.BBoxMax[1]
            maxz = shape.BBoxMax[2]
                         
            sx = maxx - minx
            sy = maxy - miny
            sz = maxz - minz

            vertices = []
            normals = []
            Normals = []
            texCoords = []
                        
            if self.separate == True: #TEST
                vertexBuffer = BinaryReader(BytesIO(self.file.vertexBuffers[shape.vertexBufferIndex]))
            else:
                vertexBuffer = BinaryReader(BytesIO(self.file.buffers[shape.vertexBufferIndex]))
            
            for i in range(shape.vertexNumber):
                x = (vertexBuffer.readUShort() / 65535) * sx + minx
                y = (vertexBuffer.readUShort() / 65535) * sy + miny
                z = (vertexBuffer.readUShort() / 65535) * sz + minz
                vertices.append([x,y,z])
                
                vertexBuffer.seek(2, 1)
                    
                n1 = (vertexBuffer.readByte() * 2) / 255
                n2 = (vertexBuffer.readByte() * 2) / 255
                n3 = (vertexBuffer.readByte() * 2) / 255
                normals.append(Vector((n1,n2,n3)).normalized())
                
                vertexBuffer.seek(1, 1)
                
                if shape.stride > 12:
                    u = vertexBuffer.readUShort() / 65535
                    v = vertexBuffer.readUShort() / 65535
                    texCoords.append([u,v])
                
                    vertexBuffer.seek(shape.stride - 16, 1)
                else:
                    vertexBuffer.seek(shape.stride - 12, 1)
                                        
                                                
            # Set Faces
            indices = []
            if self.separate == True: #TEST
                faceBuffer = BinaryReader(BytesIO(self.file.faceBuffers[shape.faceBuffersIndex[0]]))
            else:
                faceBuffer = BinaryReader(BytesIO(self.file.buffers[shape.faceBuffersIndex[0]]))
            
            for i in range(shape.facesCount[0] // 3):
                indices.append([faceBuffer.readUShort(), faceBuffer.readUShort(),faceBuffer.readUShort()])
                                    
            

            if shape.stride == 24:
                print(shape.meshName + " : " + str(shape.vertexBufferIndex))

            
            
            # Construct mesh                                                    
            mesh.from_pydata(vertices, [], indices)
                                                   
            # Set normals
            mesh.use_auto_smooth = True
            mesh.normals_split_custom_set_from_vertices(normals)

            
            # Set uv
            #uv = mesh.uv_layers.new()
            #for i in range(0, len(indices)):
                #for v in range(0, 3):
                    #mesh.uv_layers[uv.name].data[(i * 3) + v].uv = (texCoords[indices[i][v]][0], 1 - texCoords[indices[i][v]][1])
            
            
                     
            # Set matrix transformation   
            matrix = self.file.matrixList[shape.boneIndex]
            matrix.transpose()
            
            mesh.transform(matrix)
            
                                                
            # Set Hierarchy
            #node = self.file.nodeList[shape.boneIndex]
            
            #if shape.stride == 24:
                #print(shape.meshName + " : " + str(shape.vertexBufferIndex))
            
            
            #mesh.validate(clean_customdata=False)
            #mesh.update()
                     

            
            
            

            
            #t = Vector((node.min[0], -node.min[2], node.min[1]))
            # https://blender.stackexchange.com/questions/134879/how-to-create-an-empty-per-object-in-selection
            
            # Create the empty using the operator
            #bpy.ops.object.empty_add(type='CUBE', location= t)
            # Get the newly created empty
            #empty = bpy.context.view_layer.objects.active
            # Set the size
            #empty.empty_display_size = 0.1
            
            #empty.name = node.name
            
            #obj.parent = empty
            
        #for node in self.file.nodeList:
            #t = Vector((node.min[0], -node.min[2], node.min[1]))
            
            #bpy.ops.object.empty_add(type="CUBE", location = t)
            
            # Create the empty using the operator
            #bpy.ops.object.empty_add(type='CUBE', location= t)
            # Get the newly created empty
            #empty = bpy.context.view_layer.objects.active
            # Set the size
            #empty.empty_display_size = 0.1
            
            #empty.name = node.name
            


class sb3dFile:
    def __init__(self, bs):
        self.bs = bs
        self.subInformations = []
        
        self.matrixList = []
        self.inverseMatrixList = []
        
        self.materialList = []
        self.shapeList = []
        self.meshList = []
        
        self.buffers = []
        self.faceBuffers = []
        self.vertexBuffers = []
        
        self.parentIndexList = []
        self.childIndexList = []
        self.nodeList = []
        
        self.separate = True # TEST

        self.load()

    def load(self):
        sbinData = SBIN(self.bs)
        struData = STRU(self.bs)
        fielData = FIEL(self.bs)
        enumData = ENUM(self.bs)
        ohdrData = OHDR(self.bs)
        dataData = DATA(self.bs)
        chdrData = CHDR(self.bs)
        cdatData = CDAT(self.bs)
        bulkData = BULK(self.bs)
        bargData = BARG(self.bs, bulkData)
        
        self.buffers = bargData.buffers
        self.materialList = bargData.materialList
        
        self.readInformations(bargData.information)
        
        firstFaceBufferIndex = self.meshList[0].faceBuffersIndex[0]
        
        vertexBuffersCount = self.meshList[len(self.meshList) - 1].vertexBufferIndex
        faceBuffersCount = self.meshList[len(self.meshList) - 1].faceBuffersIndex[len(self.meshList[len(self.meshList) - 1].faceBuffersIndex) - 1]
                
        if firstFaceBufferIndex == 0:
            
            for i in range(faceBuffersCount + 1):
                self.faceBuffers.append(bargData.buffers[i])
                
            for i in range(faceBuffersCount + 1, (faceBuffersCount + 1) + (vertexBuffersCount + 1)):
                self.vertexBuffers.append(bargData.buffers[i])
        else:
            self.separate = False
            
            for i in range(firstFaceBufferIndex, faceBuffersCount + 1):
                self.faceBuffers.append(bargData.buffers[i])
                
            for i in range(vertexBuffersCount + 1):
                self.vertexBuffers.append(bargData.buffers[i])
        
        
        #print(self.bs.tell())
        
    def readInformations(self, information):
        informationData = BytesIO(information)
        binaryInformation = BinaryReader(informationData)
        
        sizeHeaderInformation = binaryInformation.readInt() # size of header information
        binaryInformation.readInt() # size of informations
        binaryInformation.seek(8,1) # zeros (?)
        Vector4.fromBytes(binaryInformation.readBytes(16))
        Vector4.fromBytes(binaryInformation.readBytes(16))
        
        for i in range(8):
            self.subInformations.append((binaryInformation.readInt(), binaryInformation.readInt() + binaryInformation.tell() - 4))
        
        binaryInformation.seek(sizeHeaderInformation - binaryInformation.tell(), 1)
        
        # Matrix information
        binaryInformation.seek(self.subInformations[0][1], 0)
        self.readMatrix(binaryInformation)
        
        binaryInformation.seek(self.subInformations[1][1], 0)
        self.readInverseMatrix(binaryInformation)
        
        # Hierarchy information
        binaryInformation.seek(self.subInformations[2][1], 0)
        self.readParentIndex(binaryInformation)
        
        binaryInformation.seek(self.subInformations[3][1], 0)
        self.readChildIndex(binaryInformation)
        
        binaryInformation.seek(self.subInformations[4][1], 0)
        self.readHierarchy(binaryInformation)
        
        # Unknown
        binaryInformation.seek(self.subInformations[5][1], 0)
        
        # Mesh information
        binaryInformation.seek(self.subInformations[6][1], 0)
        self.readMeshInformation(binaryInformation)
        
        binaryInformation.seek(self.subInformations[7][1], 0)
        self.readMeshTransformation(binaryInformation)
        
        
    def readMatrix(self, information):
        for i in range(self.subInformations[0][0]):
            matrixData = Matrix4x4.fromBytes(information.readBytes(64))
            matrix = Matrix()
            matrix[0] = matrixData[0]
            matrix[1] = matrixData[1]
            matrix[2] = matrixData[2]
            matrix[3] = matrixData[3]
            self.matrixList.append(matrix)
            
    def readInverseMatrix(self, information):
        for i in range(self.subInformations[1][0]):
            inverseMatrixData = Matrix4x4.fromBytes(information.readBytes(64))
            inverseMatrix = Matrix()
            inverseMatrix[0] = inverseMatrixData[0]
            inverseMatrix[1] = inverseMatrixData[1]
            inverseMatrix[2] = inverseMatrixData[2]
            inverseMatrix[3] = inverseMatrixData[3]
            self.inverseMatrixList.append(inverseMatrix)
        
    def readParentIndex(self, information):
        for i in range(self.subInformations[2][0]):
            self.parentIndexList.append(information.readInt())
            
    def readChildIndex(self, information):
        for i in range(self.subInformations[3][0]):
            self.childIndexList.append(information.readInt())
            
    def readHierarchy(self, information):
        offsetList = []
        for i in range(self.subInformations[4][0]):
            offsetList.append(information.tell() + information.readInt())
            
        for i in range(self.subInformations[4][0]):
            node = SB3D_NODE()
            
            information.seek(offsetList[i], 0)
            
            node.min = Vector4.fromBytes(information.readBytes(16))
            node.max = Vector4.fromBytes(information.readBytes(16))
            Vector4.fromBytes(information.readBytes(16))
            
            sizeInformation = information.readInt()
            information.readInt()
            information.readInt()
            information.readInt()
            information.readInt()
            
            if i == len(offsetList) - 1:
                node.name = information.bytesToString(information.readBytes(self.subInformations[5][1] - offsetList[i] - 48 - sizeInformation)).replace("\0", "")
            else:
                node.name = information.bytesToString(information.readBytes(offsetList[i + 1] - offsetList[i] - 48 - sizeInformation)).replace("\0", "")
            
            node.parentIndex = self.parentIndexList[i]
            node.childIndex = self.childIndexList[i]
            
            self.nodeList.append(node)
            
        
    def readMeshInformation(self, information):
        offsetList = []
        for i in range(self.subInformations[6][0]):
            offsetList.append(information.tell() + information.readInt())
        
        for i in range(self.subInformations[6][0]):
            information.seek(offsetList[i], 0)
            
            mesh = SB3D_SHAPE()
            
            #print(information.tell())
            size = information.readInt()
            information.readInt() # zeros ?
            mesh.boneIndex = information.readInt() # hierarchy Index
            information.readInt() # zeros ?
            information.readInt() # ???
            information.readInt() # ???
            information.readInt() # ???
            information.readInt() # size ?
            information.readInt() # ???
            information.readInt() # zeros ?
            mesh.meshName = information.bytesToString(information.readBytes(size - 40)).replace("\0", "")
            
            mesh.BBoxMin = Vector4.fromBytes(information.readBytes(16))
            mesh.BBoxMax = Vector4.fromBytes(information.readBytes(16))
            mesh.submeshCount = information.readInt() # size of mesh informaton ?
            size = information.readInt() # # size of mesh informaton ?
            information.readInt() # size ?
            information.readInt() # ???
            mesh.vertexBufferIndex = information.readInt() # ???
            information.readInt() # zeros ?
            information.readInt() # zeros ?
            information.readInt() # zeros ?
            
            information.bytesToString(information.readBytes(size - 28)).replace("\0", "")
            size = information.readInt() - 4 # flag or size ?
            information.seek(size, 1)
            
            for j in range(mesh.submeshCount):
                savePos = information.tell()
                faceInformationOffset = information.readInt()
                
                information.seek(faceInformationOffset - 4, 1)
                
                mesh.facesCount.append(information.readInt()) # face count
                information.readInt() # ???
                mesh.faceBuffersIndex.append(information.readInt()) # face Buffer Index ?
                
                information.seek(savePos, 0)
                information.seek(32, 1)
                
            information.readInt() # ??
            
            self.meshList.append(mesh)
        
        
            
    def readMeshTransformation(self, information):
            offsetList = []
            for i in range(self.subInformations[7][0]):
                offsetList.append(information.tell() + information.readInt())
            
            for i in range(self.subInformations[7][0]):
                information.seek(offsetList[i], 0)
                
                self.meshList[i].vertexNumber = information.readInt() # vertex Number
                information.readInt() # ???
                self.meshList[i].stride = information.readInt() # stride 
                information.readInt() # zeros ?
                
                information.readInt() # ???
                information.readInt() # ???
                count = information.readByte() # count of ? (28 bytes each)
                matrixCount = information.readByte() # matrix count (32 bytes each)
                
                for j in range(count):
                    information.readBytes(28)
                    
                # Read matrices
                for j in range(count):
                    information.readBytes(32)

class SBIN:
    def __init__(self, bs):
        self.bs = bs

        self.header = bs.bytesToString(bs.readBytes(4))
        self.size = bs.readInt()

class STRU:
    def __init__(self, bs):
        self.bs = bs

        self.header = bs.bytesToString(bs.readBytes(4))
        self.size = bs.readInt()
        self.CRC = bs.readInt()

        self.bs.seek(8, 1)

class FIEL:
    def __init__(self, bs):
        self.bs = bs

        self.header = bs.bytesToString(bs.readBytes(4))
        self.size = bs.readInt()
        self.CRC = bs.readInt()

        self.bs.seek(self.size, 1)

class ENUM:
    def __init__(self, bs):
        self.bs = bs

        self.header = bs.bytesToString(bs.readBytes(4))
        self.size = bs.readInt()
        self.CRC = bs.readInt()

        self.bs.seek(self.size, 1)

class OHDR:
    def __init__(self, bs):
        self.bs = bs

        self.header = bs.bytesToString(bs.readBytes(4))
        self.size = bs.readInt()
        self.CRC = bs.readInt()

        self.bs.seek(self.size, 1)

class DATA:
    def __init__(self, bs):
        self.bs = bs

        self.header = bs.bytesToString(bs.readBytes(4))
        self.size = bs.readInt()
        self.CRC = bs.readInt()

        self.bs.seek(self.size, 1)

class CHDR:
    def __init__(self, bs):
        self.bs = bs

        self.offsetList = []
        self.stringSize = []

        self.header = bs.bytesToString(bs.readBytes(4))
        self.size = bs.readInt()
        self.CRC = bs.readInt()

        for i in range(self.size // 8):
            self.offsetList.append(self.bs.readInt())
            self.stringSize.append(self.bs.readInt())

class CDAT:
    def __init__(self, bs):
        self.bs = bs

        self.stringSize = []

        self.header = bs.bytesToString(bs.readBytes(4))
        self.size = bs.readInt()
        self.CRC = bs.readInt()
        self.bs.seek(self.size, 1)

        while self.bs.readByte() == 0:
            pass
        self.bs.seek(-1, 1)

class BULK:
    def __init__(self, bs):
        self.bs = bs

        self.offsetList = []
        self.zSizeList = []

        self.header = bs.bytesToString(bs.readBytes(4))
        self.size = bs.readInt()
        self.CRC = bs.readInt()

        for i in range(self.size // 8):
            self.offsetList.append(self.bs.readInt())
            self.zSizeList.append(self.bs.readInt())

class BARG:
    def __init__(self, bs, bulkData):
        self.bs = bs
        self.bulkData = bulkData
        self.information = None
        
        self.buffers = []
        self.materialList = []
        self.shapeList = []
        
        self.dctx = zstd.ZstdDecompressor()
        
        self.header = self.bs.bytesToString(bs.readBytes(4))
        if self.header == "ALGN":
            ALGNsize = bs.readInt()
            ALGNCRC = bs.readInt()
            self.bs.readBytes(ALGNsize)
            self.header = self.bs.bytesToString(bs.readBytes(4))
            
        self.size = bs.readInt()
        self.CRC = bs.readInt()
        
        savePos = self.bs.tell()

        for i in range(self.bulkData.size // 8):
            self.bs.seek(savePos + self.bulkData.offsetList[i], 0)
            
            flag = bs.readInt()
            if flag == 0:
                self.bs.readInt() # 0xFFFF(?)
                self.bs.seek(8, 1) # zeros (?)
                state = self.bs.readInt()
                if state == 2:
                    self.bs.readInt() # 0x1 ?
                    self.bs.readInt()
                    self.bs.readInt()
                    material = SB3D_MATERIAL()
                    material.name = self.bs.bytesToString(bs.readBytes(self.bulkData.offsetList[i+1] - self.bulkData.offsetList[i] - 32)).replace("\0", "")
                    self.materialList.append(material)
                elif state == 3:
                    self.bs.readInt() # 0x1 ?
                    self.bs.readInt() # 0x1 ?
                    sizeUnknownInfo = self.bs.readInt()
                    self.bs.readInt()
                    self.bs.readInt()
                    self.bs.readInt()                                    
                    self.bs.readInt()
                    shape = SB3D_SHAPE()
                    shape.name = self.bs.bytesToString(bs.readBytes(sizeUnknownInfo - 20)).replace("\0", "")
                    self.shapeList.append(shape)
                    self.bs.readInt()     
                    self.bs.readInt()
                              
            elif flag == 2:
                self.readCompressedData(i)
            

    def readCompressedData(self, index):
        compressedSize = self.bs.readInt()
        if compressedSize == 1:
            print("TEST")
        self.bs.seek(8, 1)
        compressedData = self.bs.readBytes(self.bulkData.zSizeList[index] - 16)
        
        if index == (self.bulkData.size // 8) - 1:
            self.information = self.dctx.decompress(compressedData)
        else:
            buffer = self.dctx.decompress(compressedData)
            self.buffers.append(buffer)

def readSB3D(context, filepath, use_some_setting):
    f = open(filepath, 'rb')
    br = BinaryReader(f)

    file = sb3dFile(br)
    sb3dModel(br, file)

    f.close()

    return {'FINISHED'}


# ImportHelper is a helper class, defines filename and
# invoke() function which calls the file selector.
from bpy_extras.io_utils import ImportHelper
from bpy.props import StringProperty, BoolProperty, EnumProperty
from bpy.types import Operator

def clearScene():
    for object in bpy.context.scene.objects:
        bpy.data.objects.remove(object, do_unlink=True)


class ImportSB3D(Operator, ImportHelper):
    """This appears in the tooltip of the operator and in the generated docs"""
    bl_idname = "import_sb3d.data"  # important since its how bpy.ops.import_test.some_data is constructed
    bl_label = "Import sb3d model"

    # ImportHelper mixin class uses this
    filename_ext = ".sb3d"

    filter_glob: StringProperty(
        default="*.sb3d",
        options={'HIDDEN'},
        maxlen=255,  # Max internal buffer length, longer would be clamped.
    )

    # List of operator properties, the attributes will be assigned
    # to the class instance from the operator settings before calling.
    use_setting: BoolProperty(
        name="Example Boolean",
        description="Example Tooltip",
        default=True,
    )

    type: EnumProperty(
        name="Example Enum",
        description="Choose between two items",
        items=(
            ('OPT_A', "First Option", "Description one"),
        ),
        default='OPT_A',
    )

    def execute(self, context):
        return readSB3D(context, self.filepath, self.use_setting)


# Only needed if you want to add into a dynamic menu
def menu_func_import(self, context):
    self.layout.operator(ImportSB3D.bl_idname, text="NFS No limits (.sb3d)")


def register():
    bpy.utils.register_class(ImportSB3D)
    bpy.types.TOPBAR_MT_file_import.append(menu_func_import)


def unregister():
    bpy.utils.unregister_class(ImportSB3D)
    bpy.types.TOPBAR_MT_file_import.remove(menu_func_import)


if __name__ == "__main__":
    register()

    # test call
    bpy.ops.import_sb3d.data('INVOKE_DEFAULT')