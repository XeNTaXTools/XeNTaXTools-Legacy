
well, to be honest, I never wanted to code an obj-to-whatever format converter
because other than for simple whatever format-to-obj converters
you need a full format description.

Now I finally did this tiny (read: ugly) obj-to-vkm converter and it was no fun:D

Also I could not test it because I don't have the FungWan game.


The converter needs a vkm file as a base and a test.obj file as a single mesh model.
Works for static meshes only such as swords.

The test.obj is required to use render-to-vertex this means 
the face indices for v,vn and vt need to be identical:

f 1/1/1 2/2/2 3/3/3 
f 4/4/4 5/5/5 6/6/6 

vkm "base files" with more than one submesh are not supported
(or are supposed to provide ugly results, could not check this)


example of use
--------------

start Make_vkm.exe, open Sword006.vkm

important: there's a test.obj required to be present in the same directory

There's no message for success, but the output file should be _Sword006.vkm.
It's identical to the original vkm (with some minor differences).

This is because the test.obj was derived from that vkm.
So this was a proof that the converter is working.

Then I added 3 vertices (plus vn, vt) and some face indices to check the
new vertex count, FI count and base block size and found no caveats.

################################################################################
Be informed that you can't use obj outputs from my FWanExtract.exe as a test.obj.

You have to use FWanExtract<2>.exe, then concatenate v.txt, vn.txt and vt.txt
to a new file and rename it to test.obj.

To my knowledge blender wavefront obj export DOES NOT create render-to-vertex obj files.

You can use the max script (xzzy_obj_tool_vntf.ms, tested with Gmax only!) to create such.

Have fun!

shak-otay, 7th of May, 2017


to do list:

update of bounding box values

-------------------------------------------------------
You might update the
bounding box values (6 floats at 0x005C in the vkm)
manually in a hexeditor with some knowledge

texture names are NOT touched so far

You might rename Sword006.dds to Sword007.dds for example
Use a hexeditor in OVERWRITE mode!

-----------------------------------------------------
Insert mode will spoil the vkm - YOU HAVE BEEN WARNED
-----------------------------------------------------

