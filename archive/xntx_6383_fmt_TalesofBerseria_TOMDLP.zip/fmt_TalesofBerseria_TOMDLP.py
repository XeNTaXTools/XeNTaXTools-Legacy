#Noesis Python model import+export test module, imports/exports some data from/to a made-up format

from inc_noesis import *

#registerNoesisTypes is called by Noesis to allow the script to register formats.
#Do not implement this function in script files unless you want them to be dedicated format modules!
def registerNoesisTypes():
    handle = noesis.register("Tales of Berseria Model Header", ".TOMDLB_D")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModelRPG) #see also noepyLoadModelRPG

    #noesis.logPopup()
    #print("The log can be useful for catching debug prints from preview loads.\nBut don't leave it on when you release your script, or it will probably annoy people.")
    return 1

NOEPY_HEADER = int(1178882116)
NOEPY_VERSION = int(0)

#check if it's this type based on the data
def noepyCheckType(data):
    if len(data) < 8:
        return 0
    bs = NoeBitStream(data)

    if bs.readInt() != NOEPY_HEADER:
        return 0
    if bs.readInt() != NOEPY_VERSION:
        return 0

    return 1

class MeshAttrib():
    def __init__(self):
        self.Name = str("")
        self.VertCount = int()
        self.FaceCount = int()
        self.VertOff = int()
        self.FaceOff = int()
        self.UNK = bytes()
        self.POSList = []
        self.NORList = []
        self.IDList = []
        self.WEIList = []
        self.UV1 = []
        self.UV2 = []

def TableGetCount64(bs, C):
    A = []
    N = []
    for i in range(0, C):
        A.append(bs.tell() + bs.readUInt64())
        N.append(bs.readUInt64())
    return A, N

def TableGet64(bs, C):
    A = []
    for i in range(0, C):
        A.append(bs.tell() + bs.readUInt64())
    return A


def BoneGet(BDCount, BData, bs, AddSkel, BoneIDS, BoneList):
        BoneIDS = BoneIDS
        BoneParents = []
        NameOffs = []
        BoneNames = []
        Matrix1 = []
        Matrix2 = []
        BoneList = BoneList
        #print("BoneLOCS:", BData)
        #print("BoneCounts:", BDCount)
        bs.seek(BData[0])
        for B in range(0, BDCount[0]):
            BoneIDS.append(bs.readUInt())
        bs.seek(BData[1])
        if AddSkel:
            #print("ADDING TO SKELETON")
            print(BoneIDS)
        for B in range(0, BDCount[1]):
            X = bs.readUInt()
            #print(X)
            if X == (4294967295):
                BoneParents.append(int(-1))
            else:
                BoneParents.append(BoneIDS.index(X))
        bs.seek(BData[3])
        for B in range(0, BDCount[3]):
            NameOffs.append(bs.tell() + bs.readUInt64())
        for S in range(0, len(NameOffs)):
            bs.seek(NameOffs[S])
            BoneNames.append(bs.readString())
        bs.seek(BData[5])
        for B in range(0, BDCount[5]):
            Matrix1.append(NoeMat44.fromBytes(bs.readBytes(64)))
        bs.seek(BData[6])
        for B in range(0, BDCount[6]):
            Matrix2.append(NoeMat44.fromBytes(bs.readBytes(64)))
        bs.seek(BData[7])
        if AddSkel:
            ID = len(BoneList)
        else:
            ID = int(0)
        for BC in range(0, len(Matrix1)):
            boneMat = Matrix1[BC]
            boneMat = boneMat.toMat43()
            BoneList.append(NoeBone(ID, BoneNames[BC], boneMat, None, BoneParents[BC]))
            ID += int(1)
        return BoneList, BoneIDS


def LoadSourceSkel(ss):
    ss.seek(8)
    NameLOC = ss.tell() + ss.readUInt64()
    NameCount = ss.readUInt64()
    ss.seek(32)
    BlockLOC = TableGet64(ss, 12)
    ss.seek(BlockLOC[0] + 16)
    IDCount = ss.readUShort()
    ParentCount = ss.readUShort()
    MatCount = ss.readUShort()
    Blank = ss.readUShort()
    BLoc, BLocCount = TableGetCount64(ss, 9)
    SIds = []
    BoneList = []
    BoneList, BoneIDS = BoneGet(BLocCount, BLoc, ss, 0, SIds, BoneList)
    return BoneList, BoneIDS

def noepyLoadModelRPG(data, mdlList):
    bs = NoeBitStream(data)
    ctx = rapi.rpgCreateContext()
    #rapi.rpgSetOption(noesis.RPGOPT_TRIWINDBACKWARD, 1)

    bs.seek(16)
    stringCount = bs.readUInt64()
    sbFile = rapi.loadPairedFile("Tales of Berseria Model Data", ".TOMDLP_P")
    SSk = rapi.loadPairedFile("Tales of Berseria Source Skeleton", ".TOMDLB_D")
    ss = NoeBitStream(SSk)
    sb = NoeBitStream(sbFile)
    MDLBCheck = int(1296321602)
    MDLB = bs.readUInt()
    if MDLBCheck != MDLB:
        print("PANIC", bs.tell(), MDLB)
    Vers = bs.readUInt()
    ChunkOffs = []
    for C in range(0, 12):
        ChunkOffs.append(bs.tell() + bs.readUInt64())
    Strings = []
    StringOff = []
    for S in range(0, stringCount):
        StringOff.append(bs.tell() + bs.readUInt64())
    for S in range(0, stringCount):
        bs.seek(StringOff[S], NOESEEK_ABS)
        Strings.append(bs.readString())
        print(Strings[S])

    bs.seek(ChunkOffs[0])
    UNK1 = bs.readUInt64()
    UNK2 = bs.readUInt()
    UNK3 = bs.readUShort()
    UNK4 = bs.readUShort()
    BoneC1 = bs.readUShort()
    BoneC2 = bs.readUShort()
    BoneC3 = bs.readUShort()
    BoneC4 = bs.readUShort()

    BData = []
    BDCount = []
    for BD in range(0, 9):
        BData.append(bs.tell() + bs.readUInt64())
        BDCount.append(bs.readUInt64())
    #print(BData, BDCount)

    BoneList, BoneIDS = LoadSourceSkel(ss)
    #print("Loaded Source Skeleton", len(BoneList))

    BoneList, BoneIDS = BoneGet(BDCount, BData, bs, 1, BoneIDS, BoneList)
    #print("Finalized Skeleton", len(BoneList))

    #print(len(BoneList), BoneList)
    #print("BoneIDS", len(BoneIDS), BoneIDS)
    bs.seek(ChunkOffs[6])

    Morph = 0
    UNK1 = bs.readUInt()
    if UNK1 == int(42):
        Morph = 1
        Static = 0
    UNK2 = bs.readUInt()
    UNK3 = bs.readUInt64()
    SData = []
    SCount = []
    for S in range(0, 4):
        SData.append(bs.tell() + bs.readUInt64())
        SCount.append(bs.readUInt64())

    bs.seek(SData[0])
    MChunkUNK = []
    MChunkAtt = []
    MBoneMap = []
    MCounts = []
    bs.seek(SData[0])
    for Q in range(0, SCount[0]):
        MChunkUNK.append(bs.readBytes(16))
    bs.seek(SData[2])
    for Q in range(0, SCount[2]):
        MBoneMap.append(BoneIDS.index(bs.readUInt()))
    bs.seek(SData[1])
    for Q in range(0, SCount[1]):
        MCUNK1 = bs.readUInt()
        MCUNK2 = bs.readShort()
        MCUNK3 = bs.readShort()
        MCUNK4 = bs.readShort()
        MCUNK5 = bs.readShort()
        MCUNK6 = bs.readUInt()
        Attrib = MeshAttrib()

        NameOff = bs.tell() + bs.readUInt64()
        DataOff = bs.tell() + bs.readUInt64()
        DataUNK = bs.readUInt64()
        ret = bs.tell()

        bs.seek(NameOff)
        MeshName = bs.readString()
        Attrib.Name = MeshName

        bs.seek(DataOff)
        VertCount = bs.readShort()
        FaceCount = bs.readShort()
        VertOff = bs.readUInt()
        FaceOff = bs.readUInt()
        ExtraSeek = int((FaceOff - VertOff) / VertCount)
        ExtraSeekUV = ExtraSeek - 20
        if Morph == 0:
            Weight1Count = bs.readUInt()
            Weight2Count = bs.readUInt()
            Weight3Count = bs.readUInt()
            Weight4Count = bs.readUInt()
            Static = 0
            if Weight1Count == int(0) and Weight2Count == int(0) and Weight3Count == int(0) and Weight4Count == int(0):
                Static = 1
                print("STATICMESH", Weight1Count, Weight2Count, Weight3Count, Weight4Count)
                ExtraSeekUV = ExtraSeek - 44
            else:
                Static = 0
        else:
            MorphCount = bs.readUInt()
            MorphSize = []
            for M in range(0, MorphCount):
                MorphSize.append(bs.readUInt())


        print(Q, "MESHNAME", Attrib.Name, VertCount, FaceCount)
        sb.seek(VertOff, NOESEEK_ABS)
        for V in range(0, VertCount):
            Test = int(0)
            F = float(1.0)
            if Static:
                print(V)
                POSX = sb.readFloat()
                POSY = sb.readFloat()
                POSZ = sb.readFloat()
                NORMX = sb.readFloat()
                NORMY = sb.readFloat()
                NORMZ = sb.readFloat()
                sb.seek(4, NOESEEK_REL)
                U = sb.readFloat()
                V = sb.readFloat()
                U2 = sb.readFloat()
                V2 = sb.readFloat()
                sb.seek(ExtraSeekUV, NOESEEK_REL)
                Attrib.POSList.append(POSX)
                Attrib.POSList.append(POSY)
                Attrib.POSList.append(POSZ)
                Attrib.NORList.append(NORMX)
                Attrib.NORList.append(NORMY)
                Attrib.NORList.append(NORMZ)
                Attrib.UV1.append(U)
                Attrib.UV1.append(V)
                Attrib.UV2.append(U2)
                Attrib.UV2.append(V2)
            else:
                POSX = bs.readFloat()
                POSY = bs.readFloat()
                POSZ = bs.readFloat()
                NORMX = bs.readFloat()
                NORMY = bs.readFloat()
                NORMZ = bs.readFloat()
                if Morph == 0:
                    ID1 = bs.readUByte()
                    ID2 = bs.readUByte()
                    ID3 = bs.readUByte()
                    ID4 = bs.readUByte()
                    Attrib.IDList.append(MBoneMap[ID1])
                    Attrib.IDList.append(MBoneMap[ID2])
                    Attrib.IDList.append(MBoneMap[ID3])
                    Attrib.IDList.append(MBoneMap[ID4])
                sb.seek(4, NOESEEK_REL)
                U = sb.readFloat()
                V = sb.readFloat()
                U2 = sb.readFloat()
                V2 = sb.readFloat()
                sb.seek(ExtraSeekUV, NOESEEK_REL)
                Attrib.POSList.append(POSX)
                Attrib.POSList.append(POSY)
                Attrib.POSList.append(POSZ)
                Attrib.NORList.append(NORMX)
                Attrib.NORList.append(NORMY)
                Attrib.NORList.append(NORMZ)
                
                Attrib.UV1.append(U)
                Attrib.UV1.append(V)
                Attrib.UV2.append(U2)
                Attrib.UV2.append(V2)
                if Morph == 0:
                    if Weight1Count > int(0):
                        Attrib.WEIList.append(float(1))
                        Attrib.WEIList.append(float(0))
                        Attrib.WEIList.append(float(0))
                        Attrib.WEIList.append(float(0))
                        Weight1Count -= int(1)
                    elif Weight2Count > int(0):
                        WE = bs.readFloat()
                        Attrib.WEIList.append(WE)
                        Attrib.WEIList.append((float(1) - WE))
                        Attrib.WEIList.append(float(0))
                        Attrib.WEIList.append(float(0))
                        Weight2Count -= int(1)
                    elif Weight3Count > int(0):
                        WE = bs.readFloat()
                        WE2 = bs.readFloat()
                        To = WE + WE2
                        Attrib.WEIList.append(WE)
                        Attrib.WEIList.append(WE2)
                        Attrib.WEIList.append(float(1)- To)
                        Attrib.WEIList.append(float(0))
                        Weight3Count -= int(1)
                    elif Weight4Count > int(0):
                        WE = bs.readFloat()
                        WE2 = bs.readFloat()
                        WE3 = bs.readFloat()
                        To = WE + WE2 + WE3
                        Attrib.WEIList.append(WE)
                        Attrib.WEIList.append(WE2)
                        Attrib.WEIList.append(WE3)
                        Attrib.WEIList.append(float(1)- To)
                        Weight4Count -= int(1)


        bs.seek(ret)
        Attrib.VertCount = VertCount
        Attrib.FaceCount = FaceCount
        Attrib.VertOff = VertOff
        Attrib.FaceOff = FaceOff
        MChunkAtt.append(Attrib)

    bs.seek(SData[2])

    bs.seek(SData[3])
    for Q in range(0, SCount[3]):
        MeshCount = bs.readUInt()
        UseBoneCount = bs.readUInt()

    


    for i in range(0, MeshCount):
        A = MChunkAtt[i]

        rapi.rpgSetName(A.Name + "_" + str(i))
        sb.seek(A.VertOff)
        POS = struct.pack('f'*len(A.POSList), *A.POSList)
        NORM = struct.pack('f'*len(A.NORList), *A.NORList)
        uv1 = struct.pack('f'*len(A.UV1), *A.UV1)
        uv2 = struct.pack('f'*len(A.UV2), *A.UV2)
        if len(A.WEIList) != int(0):
            WL = struct.pack('f'*len(A.WEIList), *A.WEIList)
            IDS = struct.pack('B'*len(A.IDList), *A.IDList)
            rapi.rpgBindBoneIndexBuffer(IDS, noesis.RPGEODATA_UBYTE, 4, 4)
            rapi.rpgBindBoneWeightBuffer(WL, noesis.RPGEODATA_FLOAT, 16, 4)


        sb.seek(A.FaceOff)
        Faces = sb.readBytes(2 * A.FaceCount)


        rapi.rpgBindPositionBuffer(POS, noesis.RPGEODATA_FLOAT, 12)
        rapi.rpgBindNormalBuffer(NORM, noesis.RPGEODATA_FLOAT, 12)
        rapi.rpgBindUV1Buffer(uv1, noesis.RPGEODATA_FLOAT, 8)
        rapi.rpgBindUV2Buffer(uv2, noesis.RPGEODATA_FLOAT, 8)


        rapi.rpgCommitTriangles(Faces, noesis.RPGEODATA_USHORT, A.FaceCount, noesis.RPGEO_TRIANGLE_STRIP, 1)
        rapi.rpgClearBufferBinds() #reset in case a subsequent mesh doesn't have the same components
        #print("Done", i)
    print(len(BoneList))    
    if MeshCount == int(0):
        mdl = NoeModel()
    else:
        mdl = rapi.rpgConstructModel()
    
    mdl.setBones(BoneList)
    mdlList.append(mdl)			#important, don't forget to put your loaded model in the mdlList
    return 1
