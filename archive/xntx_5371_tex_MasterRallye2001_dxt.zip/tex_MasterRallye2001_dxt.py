from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Master Rallye 2001", ".dxt")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    Magic = bs.readBytes(4)
    if Magic != b'\xED\xFE\x00\x00':
        return 0
    return 1
    
def noepyLoadRGBA(data, texList):
    datasize = len(data) - 0x14        
    bs = NoeBitStream(data)
    skip = bs.readInt()       
    imgFmt = bs.readInt()       
    skip = bs.readInt()       
    imgWidth = bs.readInt()            
    imgHeight = bs.readInt()           
    bs.seek(0x14, NOESEEK_ABS)         
    data = bs.readBytes(datasize)      
    #RGBA32
    if imgFmt == 1:
        data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "b8 g8 r8 a8")
        texFmt = noesis.NOESISTEX_RGBA32
    #unknown, not handled
    else:
        print("WARNING: Unhandled image format")
        return None
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1