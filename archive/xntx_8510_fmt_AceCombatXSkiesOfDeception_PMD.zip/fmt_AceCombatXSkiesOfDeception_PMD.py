#  Ace Combat X: Skies of Deception PMD importer by Bigchillghost
from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Ace Combat X: Skies of Deception", ".PMD")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadModel(handle, noepyLoadModel)
	#noesis.logPopup()
	return 1

#check if it's this type based on the data
def noepyCheckType(data):
	if len(data) < 0x80:
		return 0
	bs = NoeBitStream(data)
	if bs.readUInt() != 0x2E444D50: # 'PMD.'
		return 0
	return 1

#load the model
def noepyLoadModel(data, mdlList):
	bs = NoeBitStream(data)
	bs.seek(0x2C, NOESEEK_ABS)
	meshOffset = bs.readUInt()
	bs.seek(meshOffset, NOESEEK_ABS)
	ctx = rapi.rpgCreateContext()
	idx = 0
	while True:
		signature = bs.readUInt()
		headerSize = bs.readUInt()
		if signature != 0x3A3 or headerSize == 0:
			break
		dataSize = bs.readUInt()
		bs.seek(2, NOESEEK_REL)
		groupCnt = bs.readUShort()
		bs.seek(0x10, NOESEEK_REL)
		idxList = []
		accIdx = 0
		for i in range(0, groupCnt):
			stripVertCnt = bs.readUShort()
			stripCnt = bs.readUShort()
			for j in range(0, stripCnt):
				for k in range(0, stripVertCnt):
					idxList.append(accIdx)
					accIdx += 1
				idxList.append(0xFFFF)
		indexCnt = len(idxList)
		vStride = 0x1C
		vertData = bs.readBytes(dataSize-headerSize)
		idxData = struct.pack("<" + 'H'*indexCnt, *idxList)
		meshName = 'mesh%03d'%idx
		idx += 1
		rapi.rpgSetName(meshName)
		rapi.rpgBindPositionBufferOfs(vertData, noesis.RPGEODATA_FLOAT, vStride, 0x10)
		rapi.rpgBindNormalBufferOfs(vertData, noesis.RPGEODATA_BYTE, vStride, 0xC)
		rapi.rpgBindUV1BufferOfs(vertData, noesis.RPGEODATA_FLOAT, vStride, 4)
		rapi.rpgCommitTriangles(idxData, noesis.RPGEODATA_USHORT, indexCnt, noesis.RPGEO_TRIANGLE_STRIP, 1)
		rapi.rpgClearBufferBinds()
	rapi.rpgSetTriWinding(1)
	mdl = rapi.rpgConstructModelSlim()
	mdlList.append(mdl)
	
	return 1
