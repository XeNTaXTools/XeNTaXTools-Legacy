#Noesis python importer
from inc_noesis import *
import noesis

#rapi methods should only be used during handler callbacks
import rapi
#registerNoesisTypes is called by Noesis to allow the script to register formats.
#Do not implement this function in script files unless you want them to be dedicated format modules!
 
def registerNoesisTypes():
	handle = noesis.register("NHL Legacy (X360) model test", ".rx2t") #female_0_4.rx2t
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadModel(handle, noepyLoadModel)
	
	noesis.logPopup()
	#print("The log can be useful for catching debug prints from preview loads.\nBut don't leave it on when you release your script, or it will probably annoy people.")
	return 1
#check if it's this type based on the data
def noepyCheckType(data):
    bs = NoeBitStream(data)
    Magic = bs.readBytes(7)
    if Magic != b'\x89\x52\x57\x34\x78\x62\x32':
        return 0
    return 1
 
#load the model

def noepyLoadModel(data, mdlList):
  
   ctx = rapi.rpgCreateContext()
   bs = NoeBitStream(data, NOE_BIGENDIAN)
		  				
 #Construct Models		  			   

   for i in range(0, 1):
   		VBsize = 24
   		VOffset = 0x1000
   		FOffset = 0xAA20
   		VertBufferSize = 39456
   		FaceBufferSize = 16192
   		FCount = 8094
   		#ANIMATION SKIN OFFSET = 0x200
   		
   		bs.seek(VOffset, NOESEEK_ABS)
   		VertBuff = bs.readBytes(VertBufferSize)
   		
   		rapi.rpgSetName("mesh_" + str(i))
   		rapi.rpgSetOption(noesis.RPGOPT_BIGENDIAN, 1)
   		
   		rapi.rpgBindPositionBufferOfs(VertBuff, noesis.RPGEODATA_HALFFLOAT, VBsize, 0)   	
   			
   		rapi.rpgBindUV1BufferOfs(VertBuff, noesis.RPGEODATA_HALFFLOAT, VBsize, 8)

   		rapi.rpgBindBoneIndexBufferOfs(VertBuff, noesis.RPGEODATA_UBYTE, VBsize, 16, 4) #UBYTE4
   		
   		rapi.rpgBindBoneWeightBufferOfs(VertBuff, noesis.RPGEODATA_UBYTE, VBsize, 20, 4) #UBYTE4N
   			   			  				
   		bs.seek(FOffset, NOESEEK_ABS)
   		FaceBuff = bs.readBytes(FaceBufferSize)

   		rapi.rpgCommitTriangles(FaceBuff, noesis.RPGEODATA_USHORT, FCount, noesis.RPGEO_TRIANGLE, 1)

   mdl = rapi.rpgConstructModel()
   mdlList.append(mdl)
   rapi.rpgClearBufferBinds()
   rapi.rpgReset() 
   return 1
   