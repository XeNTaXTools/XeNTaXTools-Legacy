﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using Gibbed.IO;

namespace tool
{
    class TImport
    {
        int index;

        Int32 packageName, packageNameOrd, className, classNameOrd;
        Int32 outerObj;
        public Int32 objName, objNameOrd;


        public TImport(int index)
        {
            this.index = index;
        }

        public void Read(Stream reader)
        {
            packageName = reader.ReadValueS32(UpkTool.endian);
            packageNameOrd = reader.ReadValueS32(UpkTool.endian);
            className = reader.ReadValueS32(UpkTool.endian);
            classNameOrd = reader.ReadValueS32(UpkTool.endian);
            outerObj = reader.ReadValueS32(UpkTool.endian);
            objName = reader.ReadValueS32(UpkTool.endian);
            objNameOrd = reader.ReadValueS32(UpkTool.endian);
        }

        public void Write(Stream writer)
        {
            writer.WriteValueS32(packageName, UpkTool.endian);
            writer.WriteValueS32(packageNameOrd, UpkTool.endian);
            writer.WriteValueS32(className, UpkTool.endian);
            writer.WriteValueS32(classNameOrd, UpkTool.endian);
            writer.WriteValueS32(outerObj, UpkTool.endian);
            writer.WriteValueS32(objName, UpkTool.endian);
            writer.WriteValueS32(objNameOrd, UpkTool.endian);
        }
    }
}
