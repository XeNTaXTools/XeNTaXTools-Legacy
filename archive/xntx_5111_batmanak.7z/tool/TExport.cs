﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using Gibbed.IO;

namespace tool
{
	class TExport
	{
        int index;

        public Int32 classObj, superObj, outerObj;
        public Int32 objName, objNameOrder;
        Int32 objArchetype;
        UInt64 objFlags;
        Int32 objFlagsExt;
        public Int32 size, offset;
        UInt32 exportFlags;
        Byte[] GUID;
        Int32 packageFlags, packageFlagsExt;

        public TExport(int index)
        {
            this.index = index;
        }

        public void Read(Stream reader)
        {
            classObj = reader.ReadValueS32(UpkTool.endian);
            superObj = reader.ReadValueS32(UpkTool.endian);
            outerObj = reader.ReadValueS32(UpkTool.endian);
            objName = reader.ReadValueS32(UpkTool.endian);
            objNameOrder = reader.ReadValueS32(UpkTool.endian);
            objArchetype = reader.ReadValueS32(UpkTool.endian);
            objFlags = reader.ReadValueU64(UpkTool.endian);
            objFlagsExt = reader.ReadValueS32(UpkTool.endian);
            size = reader.ReadValueS32(UpkTool.endian);
            if(size > 0)
                offset = reader.ReadValueS32(UpkTool.endian);
            exportFlags = reader.ReadValueU32(UpkTool.endian);
            GUID = reader.ReadBytes(16);
            packageFlags = reader.ReadValueS32(UpkTool.endian);
            packageFlagsExt = reader.ReadValueS32(UpkTool.endian);
        }

        public void Write(Stream writer)
        {
            writer.WriteValueS32(classObj, UpkTool.endian);
            writer.WriteValueS32(superObj, UpkTool.endian);
            writer.WriteValueS32(outerObj, UpkTool.endian);
            writer.WriteValueS32(objName, UpkTool.endian);
            writer.WriteValueS32(objNameOrder, UpkTool.endian);
            writer.WriteValueS32(objArchetype, UpkTool.endian);
            writer.WriteValueU64(objFlags, UpkTool.endian);
            writer.WriteValueS32(objFlagsExt, UpkTool.endian);
            writer.WriteValueS32(size, UpkTool.endian);
            if (size > 0)
                writer.WriteValueS32(offset, UpkTool.endian);
            writer.WriteValueU32(exportFlags, UpkTool.endian);
            writer.WriteBytes(GUID);
            writer.WriteValueS32(packageFlags, UpkTool.endian);
            writer.WriteValueS32(packageFlagsExt, UpkTool.endian);
        }



	}
}
