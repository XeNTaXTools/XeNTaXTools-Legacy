﻿
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Gibbed.IO;

namespace tool
{
    internal class UpkTool
    {

        public static readonly int GAME_VER = -2132606113;
        public static readonly Endian endian = Endian.Little;
        public static readonly string EXTENSION = ".upk";

        public static void Main(string[] args)
        {

            Console.WriteLine("-----------------------------------------");
            Console.WriteLine("  UPKTool  - Text Modify Tool - Batman Arkham Knight (PC) ");
            Console.WriteLine("  celikeins - v1.0 - 2015.06.25");
            Console.WriteLine("-----------------------------------------");
            if (args.Length > 0)
            {
                foreach (string fileName in args)
                {
                    FileInfo fileInfo = new FileInfo(fileName);
                    if (fileInfo.Extension.ToLower() == EXTENSION)
                        UpkTool.export(fileInfo);
                    else if (fileInfo.Extension.ToLower() == ".txt")
                    {
                        if (fileInfo.Length > 0L)
                            UpkTool.import(fileInfo);
                        else
                            Console.WriteLine("The file {0} has zero bytes!", fileInfo.Name);
                    }
                    else
                        Console.WriteLine("The file {0} is not supported!", fileInfo.Name);
                }
            }
            else
                Console.WriteLine("USAGE: Drag and drop TXT or UPK file(s) on the executable");
            Console.Write("DONE!");

        }

        private static void import(FileInfo fileInfo)
        {
                string upkFile = Path.ChangeExtension(fileInfo.FullName, EXTENSION);
                if (File.Exists(upkFile))
                {
                    Stream upkWriter = File.Open(upkFile + ".clxi", FileMode.Create);
                    Stream upkReader = File.OpenRead(upkFile);

                    long upkFileSize = upkReader.Length;

                    UpkPackage upkPackage = new UpkPackage(upkReader, upkWriter);
                    upkPackage.Read();

                    string[] textLines = File.ReadAllLines(fileInfo.FullName, Encoding.Unicode);

                    int readTextLine = 0;
                    AkDialogueEvent rDialogueEvent = new AkDialogueEvent(upkReader, upkWriter, upkPackage.nameTable, textLines);
                    Console.WriteLine("Importing texts...");
                    for (int i = 0; i < upkPackage.exportCount; ++i)
                    {
                        long offset = upkPackage.exportTable[i].offset;
                        long size = upkPackage.exportTable[i].size;
                        upkWriter.Seek(offset, SeekOrigin.Begin);
                        upkReader.Seek(offset, SeekOrigin.Begin);

                        upkWriter.WriteBytes(upkReader.ReadBytes(upkPackage.exportTable[i].size));

                        if (upkPackage.ReadObjectIndex(upkPackage.exportTable[i].classObj) == AkDialogueEvent.KEY)
                        {
                            long endPosition = offset + size;
                            upkWriter.Seek(upkFileSize, SeekOrigin.Begin);
                            upkReader.Seek(offset, SeekOrigin.Begin);

                            rDialogueEvent.search(endPosition, ref readTextLine, false);

                            upkPackage.exportTable[i].offset = (int)upkFileSize;
                            upkPackage.exportTable[i].size = (int)(upkWriter.Position - upkFileSize);
                            upkFileSize = upkWriter.Position;
                        }

                        

                    }

                    upkPackage.Write();

                    upkReader.Close();
                    upkWriter.Close();
                }
                else 
                {
                    Console.WriteLine("File {0} was not found!", Path.GetFileName(upkFile));
                }
        }

        private static void export(FileInfo fileInfo)
        {
            Stream upkReader = File.OpenRead(fileInfo.FullName);
            UpkPackage upkPackage = new UpkPackage(upkReader);      
            upkPackage.Read();

            bool found = false;
            for (int i = 0; i < upkPackage.importCount; ++i)
            {
                if (upkPackage.nameTable[upkPackage.importTable[i].objName].Name == AkDialogueEvent.KEY) 
                {
                    found = true;
                    break;
                }
            }

            if (!found) 
            {
                Console.WriteLine("File {0} does not import {1}!", fileInfo.Name, AkDialogueEvent.KEY);
                upkReader.Close();
                return;
            }

            StringBuilder stringBuilder = new StringBuilder();
            AkDialogueEvent akDialogueEvent = new AkDialogueEvent(upkReader, upkPackage.nameTable, stringBuilder);
            Console.WriteLine("Extracting texts...");
            for (int i = 0; i < upkPackage.exportCount; ++i) 
            {
                if (upkPackage.ReadObjectIndex(upkPackage.exportTable[i].classObj) == AkDialogueEvent.KEY) 
                {
                    upkReader.Seek(upkPackage.exportTable[i].offset, SeekOrigin.Begin);
                    long endPosition = upkPackage.exportTable[i].offset + upkPackage.exportTable[i].size;
                    //upkReader.Seek(4, SeekOrigin.Current);
                    akDialogueEvent.search(endPosition, false);
                }
            }
            upkReader.Close();
            Console.WriteLine();
            if (stringBuilder.Length != 0)
            {
                File.WriteAllText(fileInfo.DirectoryName + "\\" + Path.GetFileNameWithoutExtension(fileInfo.Name) + ".txt", stringBuilder.ToString(), Encoding.Unicode);
                Console.WriteLine("Text File {0} successfully extracted!", fileInfo.Name);
            }
            else
            {
                Console.WriteLine("File {0} does not have any text!", fileInfo.Name);
            }

        }
    }

}
