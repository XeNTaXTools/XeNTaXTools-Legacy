﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using Gibbed.IO;

namespace tool
{
	class TString
	{

        private bool toUnicode;

        int length;
        string str;

        public TString()
        {
            this.toUnicode = true;
        }

        public TString(bool toUnicode)
        {
            this.toUnicode = toUnicode;
        }
        
        public void Read(Stream reader) 
        {
            length = reader.ReadValueS32(UpkTool.endian);
            if (length > 0) 
            {
                str = reader.ReadString(length, true, Encoding.Default);
            }
            else if(length < 0)
            {
                length *= -2;
                str = reader.ReadString(length, true, Encoding.Unicode);
            }else{
                str = "";
            }
        }

        public void Write(Stream writer)
        {
            if(length == 0)
            {
                writer.WriteValueS32(0, UpkTool.endian);
            }
            else if(toUnicode)
            {
                byte[] bytes= Encoding.Unicode.GetBytes(str + '\0');
                writer.WriteValueS32(bytes.Length / -2, UpkTool.endian);
                writer.WriteBytes(bytes);
            }
            else
            {
                byte[] bytes= Encoding.Default.GetBytes(str + '\0');
                writer.WriteValueS32(bytes.Length, UpkTool.endian);
                writer.WriteBytes(bytes);
            }
        }

        public void WriteField(Stream writer)
        {
            if (str.Length == 0)
            {
                writer.WriteValueS32(4, UpkTool.endian);
                writer.WriteValueS32(0, UpkTool.endian);
                writer.WriteValueS32(0, UpkTool.endian); 
            }
            else if (toUnicode)
            {
                byte[] bytes = Encoding.Unicode.GetBytes(str + '\0');
                writer.WriteValueS32(bytes.Length + 4, UpkTool.endian);
                writer.WriteValueS32(0, UpkTool.endian);
                writer.WriteValueS32(bytes.Length / -2, UpkTool.endian);
                writer.WriteBytes(bytes);   
            }
            else
            {
                byte[] bytes = Encoding.Default.GetBytes(str + '\0');
                writer.WriteValueS32(bytes.Length + 4, UpkTool.endian);
                writer.WriteValueS32(0, UpkTool.endian);
                writer.WriteValueS32(bytes.Length, UpkTool.endian);
                writer.WriteBytes(bytes);
            }
        }

        public string Str
        {
            get
            {
                return str;
            }
            set 
            {
                str = value;
            }
        }

        public bool ToUnicode 
        {
            set 
            {
                this.toUnicode = value;
            }
        }
	}
}
