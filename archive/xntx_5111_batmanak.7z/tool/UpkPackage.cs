﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using Gibbed.IO;

namespace tool
{
	class UpkPackage
	{
        private static readonly UInt32 UPK_PACKAGE_SIGN = 2653586369;

        UInt32 packageSign;
        Int32 gameVer;
        Int32 packageHeaderSize;
        TString none;
        UInt32 packageFlags;
        public Int32 nameCount, nameOffset;
        public Int32 exportCount, exportOffset;
        public Int32 importCount, importOffset;
        Int32 dependOffset1, dependOffset2;
        Byte[] chunk; //size 12
        Byte[] GUID; //size 16
        Int32 generationCount;
        Byte[] generationData; // 12 * generationCount
        Int32 engineVer, cookerVer;
        Int32 compressed, chunkSize;
        Byte[] unknown1; //nameOffset-current
        public TName[] nameTable;
        public TImport[] importTable;
        public TExport[] exportTable;
        Byte[] unknown2;//packageHeaderSize(exportTable[0].offset)-current

        public Stream reader;
        public Stream writer;


        public UpkPackage(Stream reader)
        {
            none = new TString(false);
            this.reader = reader;
        }

        public UpkPackage(Stream reader, Stream writer)
        {
            none = new TString(false);
            this.reader = reader;
            this.writer = writer;
        }

        public void Read()
        {
            reader.Seek(0, SeekOrigin.Begin);
            packageSign = reader.ReadValueU32(UpkTool.endian);
            if (packageSign != UPK_PACKAGE_SIGN)
                throw new Exception("Not valid UPK Package file!");
            gameVer = reader.ReadValueS32(UpkTool.endian);
            if (gameVer != UpkTool.GAME_VER)
                throw new NotSupportedException("This game is not supported!");
            packageHeaderSize = reader.ReadValueS32(UpkTool.endian);
            none.Read(reader);
            packageFlags = reader.ReadValueU32(UpkTool.endian);
            nameCount = reader.ReadValueS32(UpkTool.endian);
            nameOffset = reader.ReadValueS32(UpkTool.endian);
            exportCount = reader.ReadValueS32(UpkTool.endian);
            exportOffset = reader.ReadValueS32(UpkTool.endian);
            importCount = reader.ReadValueS32(UpkTool.endian);
            importOffset = reader.ReadValueS32(UpkTool.endian);
            dependOffset1 = reader.ReadValueS32(UpkTool.endian);
            dependOffset2 = reader.ReadValueS32(UpkTool.endian);
            chunk = reader.ReadBytes(12);
            GUID = reader.ReadBytes(16);
            generationCount = reader.ReadValueS32(UpkTool.endian);
            generationData = reader.ReadBytes(12 * generationCount);
            engineVer = reader.ReadValueS32(UpkTool.endian);
            cookerVer = reader.ReadValueS32(UpkTool.endian);
            compressed = reader.ReadValueS32(UpkTool.endian);
            chunkSize = reader.ReadValueS32(UpkTool.endian);
            if (compressed != 0)
                throw new Exception("Compressed UPK Files are not supported!");
            unknown1 = reader.ReadBytes(nameOffset - (int)reader.Position);
            nameTable = new TName[nameCount];
            for (int i = 0; i < nameCount; ++i)
            {
                TName name = new TName(i);
                name.Read(reader);
                nameTable[i] = name;
            }
            importTable = new TImport[importCount];
            for (int i = 0; i < importCount; ++i)
            {
                TImport import = new TImport(i);
                import.Read(reader);
                importTable[i] = import;
            }
            exportTable = new TExport[exportCount];
            for (int i = 0; i < exportCount; ++i)
            {
                TExport export = new TExport(i);
                export.Read(reader);
                exportTable[i] = export;
            }
            unknown2 = reader.ReadBytes(packageHeaderSize - (int)reader.Position);
        }

        public void Write()
        {
            if (writer == null)
                return;
            writer.Seek(0, SeekOrigin.Begin);
            writer.WriteValueU32(packageSign, UpkTool.endian);
            writer.WriteValueS32(gameVer, UpkTool.endian);
            writer.WriteValueS32(packageHeaderSize, UpkTool.endian);
            none.Write(writer);
            writer.WriteValueU32(packageFlags, UpkTool.endian);
            writer.WriteValueS32(nameCount, UpkTool.endian);
            writer.WriteValueS32(nameOffset, UpkTool.endian);
            writer.WriteValueS32(exportCount, UpkTool.endian);
            writer.WriteValueS32(exportOffset, UpkTool.endian);
            writer.WriteValueS32(importCount, UpkTool.endian);
            writer.WriteValueS32(importOffset, UpkTool.endian);
            writer.WriteValueS32(dependOffset1, UpkTool.endian);
            writer.WriteValueS32(dependOffset2, UpkTool.endian);
            writer.WriteBytes(chunk);
            writer.WriteBytes(GUID);
            writer.WriteValueS32(generationCount, UpkTool.endian);
            writer.WriteBytes(generationData);
            writer.WriteValueS32(engineVer, UpkTool.endian);
            writer.WriteValueS32(cookerVer, UpkTool.endian);
            writer.WriteValueS32(compressed, UpkTool.endian);
            writer.WriteValueS32(chunkSize, UpkTool.endian);
            writer.WriteBytes(unknown1);
            for (int i = 0; i < nameCount; ++i)
            {
                nameTable[i].Write(writer);
            }
            for (int i = 0; i < importCount; ++i)
            {
                importTable[i].Write(writer);
            }
            for (int i = 0; i < exportCount; ++i)
            {
                exportTable[i].Write(writer);
            }
            writer.WriteBytes(unknown2);
        }


        public string ReadObjectIndex(int index) 
        {
            if(index < 0)
                return nameTable[importTable[-index-1].objName].Name;
            else if(index > 0)
                return nameTable[exportTable[index - 1].objName].Name;
            else
                return "null";
        }

	}
}
