﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Gibbed.IO;

namespace tool
{
	class RDialogueEvent
	{
        
        public static readonly string KEY = "RDialogueEvent";
        private static readonly Dictionary<short, string> typeDict = new Dictionary<short, string>()
                                                        {
                                                            {1,"NameProperty"},
                                                            {2,"IntProperty"},
                                                            {3,"BoolProperty"},
                                                            {4,"FloatProperty"},
                                                            {9,"ArrayProperty"},
                                                            {13,"StrProperty"},
                                                            {16,"IntProperty"}
                                                        };

        StringBuilder allTexts;
        string[] allTextLines;
        Stream reader;
        Stream writer;
        TName[] nameTable;

        public RDialogueEvent(Stream reader, TName[] nameTable, StringBuilder outputStream)
        {
            this.reader = reader;
            this.nameTable = nameTable;
            this.allTexts = outputStream;
        }

        public RDialogueEvent(Stream reader, Stream writer, TName[] nameTable, string[] texts)
        {
            this.reader = reader;
            this.writer = writer;
            this.nameTable = nameTable;
            this.allTextLines = texts;
        }

        public void search(long endPos, bool inArray)
        {
            while (reader.Position < endPos)
            {
                short fieldName = reader.ReadValueS16(UpkTool.endian);
                if (fieldName != 0)
                {
                    short fieldCode = reader.ReadValueS16(UpkTool.endian);
                    string type;
                    if (typeDict.TryGetValue(fieldName, out type))
                    {
                        switch (type)
                        {
                            case "IntProperty":
                            case "FloatProperty":
                                reader.Seek(4, SeekOrigin.Current);
                                continue;
                            case "BoolProperty":
                                reader.Seek(17, SeekOrigin.Current);
                                continue;
                            case "NameProperty":
                                reader.Seek(24, SeekOrigin.Current);
                                continue;
                            case "StrProperty":
                                TString str = new TString();
                                str.Read(reader);
                                if (fieldCode == 0 && inArray)
                                {
                                    if (str.Str.Length > 0)
                                    {
                                        allTexts.AppendLine(str.Str.Replace("\n", "{\\n}"));
                                    }
                                }
                                continue;
                            case "ArrayProperty":
                                int arrayType = reader.ReadValueS32(UpkTool.endian);
                                reader.Seek(4, SeekOrigin.Current);
                                int arraySize = reader.ReadValueS32(UpkTool.endian);
                                reader.Seek(4, SeekOrigin.Current);
                                long endArrayPos = arraySize + reader.Position;
                                int arrCount = reader.ReadValueS32(UpkTool.endian);
                                if (arrCount > 0)
                                {
                                    switch (nameTable[arrayType].Name)
                                    {
                                        case "Subtitles":
                                        case "LocalizedSubtitles":
                                            bool isSubtitles = nameTable[arrayType].Name == "Subtitles";
                                            for (int index = 0; index < arrCount; ++index)
                                                search(endArrayPos, isSubtitles);
                                            break;
                                        default:
                                            reader.Seek(endArrayPos, SeekOrigin.Begin);
                                            break;
                                    }
                                }
                                continue;
                            default:
                                throw new Exception("Unexpected field in RDialogueEvent class!!");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Error: Unknown Type {0}", fieldName);
                    }

                }
            }
        }

        public void search(long endPos,ref int lineNumber, bool inArray) 
        {
            while (reader.Position < endPos)
            {
                short fieldName = reader.ReadValueS16(UpkTool.endian);
                writer.WriteValueS16(fieldName, UpkTool.endian);
                if (fieldName != 0)
                {
                    short fieldCode = reader.ReadValueS16(UpkTool.endian);
                    writer.WriteValueS16(fieldCode, UpkTool.endian);
                    string type;
                    if (typeDict.TryGetValue(fieldName, out type))
                    {
                        switch (type)
                        {
                            case "IntProperty":
                            case "FloatProperty":
                                writer.WriteBytes(reader.ReadBytes(4));
                                continue;
                            case "BoolProperty":
                                writer.WriteBytes(reader.ReadBytes(17));
                                continue;
                            case "NameProperty":
                                writer.WriteBytes(reader.ReadBytes(24));
                                continue;
                            case "StrProperty":
                                TString str = new TString(false);
                                str.Read(reader);
                                if (fieldCode == 0 && inArray)
                                {
                                    if (str.Str.Length > 0)
                                    {
                                        str.ToUnicode = true;
                                        str.Str = allTextLines[lineNumber++].Replace("{\\n}", "\n");
                                    }
                                }
                                str.Write(writer);
                                continue;
                            case "ArrayProperty":
                                int arrayType = reader.ReadValueS32(UpkTool.endian);
                                writer.WriteValueS32(arrayType, UpkTool.endian);
                                writer.WriteBytes(reader.ReadBytes(4));
                                int arraySize = reader.ReadValueS32(UpkTool.endian), 
                                    arraySizeNum = reader.ReadValueS32(UpkTool.endian);

                                long sizePosition = writer.Position;
                                writer.WriteValueS32(arraySize, UpkTool.endian);
                                writer.WriteValueS32(arraySizeNum, UpkTool.endian);

                                long endArrayPos = arraySize + reader.Position;
                                int arrCount = reader.ReadValueS32(UpkTool.endian);
                                writer.WriteValueS32(arrCount, UpkTool.endian);
                                switch (nameTable[arrayType].Name)
                                {
                                    case "Subtitles":
                                    case "LocalizedSubtitles":
                                        bool isSubtitles = nameTable[arrayType].Name == "Subtitles";
                                        for (int index = 0; index < arrCount; ++index)
                                            search(endArrayPos, ref lineNumber, isSubtitles);
                                        long finishPosition = writer.Position;
                                        writer.Seek(sizePosition, SeekOrigin.Begin);
                                        writer.WriteValueS32((int)(finishPosition - sizePosition - 8),UpkTool.endian);
                                        writer.Seek(finishPosition, SeekOrigin.Begin);
                                        break;
                                    default:
                                        writer.WriteBytes(reader.ReadBytes(arraySize - 4));
                                        break;
                                }
                                continue;
                            default:
                                throw new Exception("Unexpected field in RDialogueEvent class!!");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Error: Unknown Type {0}", fieldName);
                    }

                }


            }
        
        }

	}
}
