﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using Gibbed.IO;

namespace tool
{
	class TName
	{
        int index;

        TString name;
        UInt64 flags;

        public TName(int index)
        {
            this.index = index;
            name = new TString(false);
        }

        public void Read(Stream reader)
        {   
            name.Read(reader);
            flags = reader.ReadValueU64(UpkTool.endian);
        }

        public void Write(Stream writer)
        {
            name.Write(writer);
            writer.WriteValueU64(flags, UpkTool.endian);
        }

        public string Name 
        {
            get 
            {
                return name.Str;
            }
        }

	}
}
