﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyProduct("UPKTool")]
[assembly: AssemblyDescription("Edit Texts in UPK Packages of Batman Arkham Knight(PC)")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("celikeins")]
[assembly: AssemblyTitle("UPKTool")]
[assembly: AssemblyCopyright("Copyright celikeins 2015")]
[assembly: AssemblyTrademark("celikeins")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("1.0.0.0")]
