import newGameLib
reload(newGameLib)
from newGameLib import *
import Blender
	

	

def imaterialParser(filename):
	
	texDir=os.path.dirname(filename)
	matFile=open(filename,'r')
	for line in matFile.readlines():
		stripLine=line.strip()
		if 'material' in stripLine:# and flag==False:
			splitLine=stripLine.split()
			if splitLine[0]=='material':
					mat=Mat()
					mat.name=splitLine[1]
					matList.append(mat)
		if 'texture_unit' in stripLine:					
			splitLine=stripLine.split()
			texType=None
			if len(splitLine)>1:
				texType=splitLine[1]
		if 'texture ' in stripLine:					
			splitLine=stripLine.split()
			if mat is not None:
				if texType=='diffuseTex':
					mat.diffuse=texDir+os.sep+splitLine[1]
				if texType=='normalSpecularMap':
					mat.normal=texDir+os.sep+splitLine[1]
				if texType=='normalSpecularMap':
					mat.specular=texDir+os.sep+splitLine[1]
				if texType==None:
					mat.diffuse=texDir+os.sep+splitLine[1]
		
		
def xa100(g,t):
	startSection=g.tell()-2
	
	size=g.i(1)[0]
	g.H(1)[0],
	g.find('\x0a')
	
	endSection=g.tell()
	usedSizeSection=endSection-startSection
	
	g.seek(t+size)
	txt.write(' '*4+'rest='+str(size-usedSizeSection)+'\n')
		
	
		

class Declaration:
	def __init__(self):
		self.streamID=None
		self.format=None
		self.type=None
		self.offset=None
		
		
class Submesh:
	def __init__(self):
		self.infoList=[]
		self.streamList=[]	
		self.indiceList=[]
		self.material=None	
		self.vertCount=None	
		self.skin=[]
		
class Stream:
	def __init__(self):
		self.ID=None
		self.stride=None
		self.offset=None		
		

def meshParser(filename,g):
	
	submeshList=[]
	indiceList=[]
	
	
	g.B(2)
	g.find('\x0a')
	
	mesh=Mesh()
	while(True):
		if g.tell()>=g.fileSize():
			print 'DONE.ALL PARSED'
			break
		pos=g.tell()
		chunk=g.H(1)[0]
		#print '-'*20,hex(chunk),g.tell()
		if chunk==0x4000:
			#submesh=Submesh()
			#submeshList.append(submesh)
			print '-'*20,hex(chunk),g.tell()
			size=g.i(1)[0]
			matName=g.find('\x0a')
			mat=Mat()
			mat.name=matName
			for item in matList:
				if item.name==matName:
					mat.diffuse=item.diffuse
					mat.normal=item.normal
					mat.specular=item.specular
			#print len(matList)
			#mat=matList[len(mesh.matList)]
			g.B(1)
			indiceCount=g.i(1)[0]
			g.B(1)
			mat.TRIANGLE=True
			mat.ZTRANS=True
			mat.IDStart=len(mesh.indiceList)
			mat.IDCount=indiceCount	
			mesh.indiceList.extend(g.i(indiceCount))	
			#submesh.material=mat
			mesh.matList.append(mat)
			print 'indice count:',indiceCount	
		elif chunk==0x2000:
			print '-'*20,hex(chunk),g.tell()
			g.B(6)		
		elif chunk==0x3000:
			submesh=Submesh()
			submeshList.append(submesh)
			print '-'*20,hex(chunk),g.tell()
			size=g.i(1)[0]
			Count=g.B(1)[0]
			print 'Count:',Count
		elif chunk==0x3100:
			print '-'*20,hex(chunk),g.tell()
			size=g.i(1)[0]
			g.i(2)
			g.f(24)
			g.H(36)
			#g.seek(pos+size)
		elif chunk==0x5f47:
			print '-'*20,hex(chunk),g.tell()
			print g.find('\x0a')
		elif chunk==0x5f43:
			print '-'*20,hex(chunk),g.tell()
			skeletonName=g.find('\x0a')
			skeletonPath=g.dirname+os.sep+skeletonName
			if os.path.exists(skeletonPath)==True:
				print skeletonPath
			print skeletonPath	
		elif chunk==0x5000:	
			print '-'*20,hex(chunk),g.tell()		
			size=g.i(1)[0]
			vertCount=g.i(1)[0]	
			submesh.vertCount=vertCount
			print 'vertCount:',vertCount
		elif chunk==0x5100:	
			print '-'*20,hex(chunk),g.tell()
			size=g.i(1)[0]	
			#print 'size:',	size
		elif chunk==0x5110:	
			print '-'*20,hex(chunk),g.tell()	
			info=Declaration()
			size=g.i(1)[0]
			info.streamID=g.H(1)[0]
			info.format=g.H(1)[0]
			info.type=g.H(1)[0]
			info.offset=g.H(1)[0]
			unk=g.H(1)[0]
			submesh.infoList.append(info)
			print 'submesh add info:',info.streamID,info.format,info.type,info.offset
		elif chunk==0x5200:
			print '-'*20,hex(chunk),g.tell()
			stream=Stream()
			submesh.streamList.append(stream)		
			size=g.i(1)[0]
			stream.ID=g.H(1)[0]
			stream.stride=g.H(1)[0]
			stream.offset=g.tell()
			print 'stream:',stream.ID,stream.stride,stream.offset
		elif chunk==0x5210:
			print '-'*20,hex(chunk),g.tell()
			size=g.i(1)[0]
			stream.offset=g.tell()
			g.seek(pos+size)
		elif chunk==0x4010:
			print '-'*20,hex(chunk),g.tell()
			size=g.i(1)[0]
			#print g.i(7)
			#print g.find('\x0a')
			#print g.find('\x0a')
			#g.B(5)
			g.seek(pos+size)
		elif chunk==0x4003:	
			g.i(6)
			img=g.find('\x0a')
			imgPath=g.dirname+os.sep+img
			if os.path.exists(imgPath)==True:
				mat=Mat()
				mat.TRIANGLE=True
				mat.ZTRANS=True
				mat.diffuse=imgPath
				submesh.material=mat
			
			print g.find('\x0a')
			g.B(5)
		elif chunk==0x4100:			
			size=g.i(1)[0]
			ID=g.H(1)[0]
			unk=g.H(2)
			weight=g.f(1)[0]
			g.seek(pos+size)			
		elif chunk==0x6000:
			print '-'*20,hex(chunk),g.tell()
			size=g.i(1)[0]
			name=g.find('\x0a')
			g.seek(pos+size)		
		elif chunk==0x7000:	
			#print '-'*20,hex(chunk),g.tell()		
			size=g.i(1)[0]
			ID=g.H(1)[0]
			unk=g.H(2)
			weight=g.f(1)[0]
			submesh.skin.append([ID,unk[1],weight])
			g.seek(pos+size)	
		elif chunk==0x9000:	
			print '-'*20,hex(chunk),g.tell()	
			size=g.i(1)[0]
			unk=g.f(7)
			g.seek(pos+size)			
		elif chunk==0xa000:		
			print '-'*20,hex(chunk),g.tell()
			size=g.i(1)[0]
			g.seek(pos+size)
		elif chunk==0xa100:xa100(g,t)
		else:
			print 'WARNING: unknow',hex(chunk),'offset=',g.tell()
				
			break
	
	g.tell()
	for submesh in submeshList:
		for info in submesh.infoList:
			streamID=info.streamID
			stream=submesh.streamList[streamID]
			g.seek(stream.offset)
			for m in range(submesh.vertCount):
				t=g.tell()
				if info.type==1:
					g.seek(t+info.offset)
					if info.format==2:
						mesh.vertPosList.append(g.f(3))
				if info.type==7:
					g.seek(t+info.offset)
					if info.format==1:
						mesh.vertUVList.append(g.f(2))
				g.seek(t+stream.stride)
		skin=Skin()	
		for n in range(submesh.vertCount):
			mesh.skinIndiceList.append([])
			mesh.skinWeightList.append([])
		for n in range(len(submesh.skin)):
			mesh.skinIndiceList[submesh.skin[n][0]].append(submesh.skin[n][1])	
			mesh.skinWeightList[submesh.skin[n][0]].append(submesh.skin[n][2])	
		mesh.skinList.append(skin)	
	mesh.BINDSKELETON='armature'
	mesh.draw()			
		
	
	
		
def skeletonParser(filename,g):

	g.B(2)
	g.find('\x0a')
	
	
	sys=Sys(filename)
	sys.addDir(sys.base+'_animfiles')
	boneList=[]
	animFlag=True
	while(True):
		pos=g.tell()
		chunk = g.H(1)[0]
		#print '-'*20,hex(chunk),g.tell()
		if chunk==0x2000:
			bone=Bone()
			size  = g.i(1)[0]
			name = g.find('\x0a')
			bone.ID=g.H(1)[0]
			bone.posmatrix=VectorMatrix(g.f(3))
			bone.rotmatrix=QuatMatrix(g.f(4)).resize4x4()
			bone.matrix=bone.rotmatrix*bone.posmatrix
			"""posMatrix=VectorMatrix(g.f(3))
			rotMatrix=QuatMatrix(g.f(4)).resize4x4()
			matrix=rotMatrix*posMatrix
			bone.matrix=matrix"""
			if size==48:print g.f(3)
			boneList.append(bone)
		elif chunk==0x3000:
			size=g.i(1)[0]
			var=g.H(2)
			#print var
			#skeleton.boneList[var[0]].name=str(var[0])
			boneList[var[0]].parentID=var[1]
		elif chunk==0x4000:
			animFlag=True
			size=g.i(1)[0] 
			animName=g.find('\x0a')
			lenght=g.f(1)[0]
			print animName,lenght
			animPath=g.dirname+os.sep+sys.base+'_animfiles'+os.sep+animName+'.anim'
			animFile=open(animPath,'wb')
			p=BinaryReader(animFile)
			p.i([len(boneList)])#p is in write mode, so function p.i writes list of values as integers
			"""for i,bone in enumerate(boneList):
				if bone.parentID is None:bone.parentID=-1
				p.i([bone.parentID])
				p.f(bone.matrix[0])
				p.f(bone.matrix[1])
				p.f(bone.matrix[2])
				p.f(bone.matrix[3])"""
			for i,bone in enumerate(boneList):
				if bone.parentID is None:bone.parentID=-1
				p.i([bone.parentID])
				p.f(bone.rotmatrix[0])#p is in write mode, so function p.f writes list of values as floats
				p.f(bone.rotmatrix[1])
				p.f(bone.rotmatrix[2])
				p.f(bone.rotmatrix[3])
				p.f(bone.posmatrix[0])
				p.f(bone.posmatrix[1])
				p.f(bone.posmatrix[2])
				p.f(bone.posmatrix[3])
		elif chunk==0x4100:	
			p.i([chunk])
			a,b,c=g.H(3)
			p.i([c])				
		elif chunk==0x4110:	
			size=g.i(1)[0]
			p.i([chunk])
			if size==38:animFile.write(g.read(32))
			elif size==50:
				animFile.write(g.read(32))
				g.f(3)
			else:
				print 'WARNING:unknow size:',size
				break
			g.seek(pos+size)
		elif chunk==0x5000:
			g.debug=True
			size=g.i(1)[0]
			name = g.find('\x0a')
			g.f(1)
			g.seek(pos+size)
		else:
			print 'unknow chunk',hex(chunk),g.tell()
			break
		if g.tell()==g.fileSize():
			break
	if animFlag==True:	
		skeleton=Skeleton()
		skeleton.SORT=True
		#skeleton.BONESPACE=True
		skeleton.ARMATURESPACE=True
		skeleton.BINDMESH=True
		skeleton.NICE=True
		skeleton.boneList=boneList
		skeleton.draw()
				
	
def animParser(filename,g):
	
	
	skeleton=Skeleton()
	skeleton.BONESPACE=True
	skeleton.BINDMESH=True
	skeleton.NICE=True
	boneCount=g.i(1)[0]
	for m in range(boneCount):
		bone=Bone()
		bone.parentID=g.i(1)[0]
		rotMatrix=Matrix4x4(g.f(16))
		posMatrix=Matrix4x4(g.f(16))
		bone.posMatrix=posMatrix
		bone.rotMatrix=rotMatrix
		skeleton.boneList.append(bone)
	#skeleton.draw()
	
	action=Action()
	action.skeleton='armature'
	action.BONESORT=True
	action.BONESPACE=True
	while(True):
		chunk = g.i(1)[0]	
		#print '-'*20,hex(chunk)	
		if chunk==0x4100:
			abone=ActionBone()
			id=g.i(1)[0]
			abone.name=str(id)
			action.boneList.append(abone)
			rotMatrix=skeleton.boneList[id].rotMatrix
			posMatrix=skeleton.boneList[id].posMatrix
		elif chunk==0x4110:	
			time=g.f(1)[0]*30
			abone.posFrameList.append(time)
			abone.rotFrameList.append(time)
			matrix=QuatMatrix(g.f(4)).resize4x4()*rotMatrix
			abone.rotKeyList.append(matrix)
			matrix=VectorMatrix(g.f(3))*posMatrix
			abone.posKeyList.append(matrix)
		if g.tell()==g.fileSize():
			break		
	action.draw()
	action.setContext()
	
		
def Parser():
	global matList
	filename=input.filename
	print
	print filename
	print
	ext=filename.split('.')[-1].lower()
	
	
	matList=[]
	
	
	if ext=='mesh':
		filedir=os.path.dirname(filename)
		for file in os.listdir(filedir):
			fileext=file.split('.')[-1]
			if fileext=='imaterial':
				imaterialPath=filedir+os.sep+file
				imaterialParser(imaterialPath)		
		
		
		file=open(filename,'rb')
		g=BinaryReader(file)
		meshParser(filename,g)
		file.close()
	
		
	if ext=='skeleton':
		file=open(filename,'rb')
		g=BinaryReader(file)
		skeletonParser(filename,g)
		file.close()
		
	if ext=='anim':
		file=open(filename,'rb')
		g=BinaryReader(file)
		animParser(filename,g)
		file.close()
		
	
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
	
Blender.Window.FileSelector(openFile,'import','Shadow Heretic .mesh, .skeleton, .anim') 