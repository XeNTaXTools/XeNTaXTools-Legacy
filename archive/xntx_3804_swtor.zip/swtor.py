#Noesis Python model import+export test module, imports/exports some data from/to a made-up format

from inc_noesis import *

import noesis
#rapi methods should only be used during handler callbacks
import rapi
import math
import sys
from bs4 import BeautifulSoup

#registerNoesisTypes is called by Noesis to allow the script to register formats.
#Do not implement this function in script files unless you want them to be dedicated format modules!
def registerNoesisTypes():
	handle = noesis.register("Star Wars: The Old Republic", ".gr2")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadModel(handle, noepyLoadModel) #see also noepyLoadModelRPG
	#noesis.setHandlerWriteModel(handle, noepyWriteModel)
	#noesis.setHandlerWriteAnim(handle, noepyWriteAnim)
	#noesis.logPopup()
	print("The log can be useful for catching debug prints from preview loads.\nBut don't leave it on when you release your script, or it will probably annoy people.")
	return 1

NOEPY_HEADER="GAWB"

#check if it's this type based on the data
def noepyCheckType(data):
	bs = NoeBitStream(data)
	if len(data) < 4:
		return 0
	if bs.readBytes(4).decode("ASCII").rstrip("\0") != NOEPY_HEADER:
		return 0
	return 1	   


#load the model
def noepyLoadModel(data, mdlList):
	ctx = rapi.rpgCreateContext()
	
	filelist=[]
	filecount=0
	matFilelist=[]
	matFilecount=0
	dirPath = rapi.getDirForFilePath(rapi.getInputName())
	resourcePath = ""
	pluginPath = noesis.getPluginsPath()
	configName = "python\\swtor-config.xml"
	if (rapi.checkFileExists(pluginPath + configName)):
		print("found the config file!")
		f = open(pluginPath + configName, 'r')
		config = BeautifulSoup(f)
		f.close()
		resourcePath = config.configuration.resourcepath.string
	workingfile=rapi.getInputName().split('\\')[-1]
	toLoadList = dirPath + workingfile + '.txt'
	if (rapi.checkFileExists(toLoadList)):
		f = open(toLoadList, 'r') #list of gr2 files to load
		for line in f:
			filelist.append(line.strip())
			print(line.strip())
			filecount += 1;
		print(filecount)
		if filecount > 0:
			for model in filelist:
				print(model)
			print('File Count: ' + str(filecount))
		else:
			print("Empty model_list.txt")
		f.close()

	matList=[] #Noesis built-in must have material list
	texList=[] #Noesis built-in must have texture list
	bones=[]
	anims=[]

	while (filecount >= 0 ): #change this when adding support for list of submodels to be loaded
		rapi.setPreviewOption("noTextureLoad","1")
		rapi.setPreviewOption("setAngOfs","0 0 90") #sets the default preview angle
		print("filecount=" +str(filecount))
		currentPath = dirPath
		if (rapi.checkFileExists(dirPath + workingfile) == False):
			if (rapi.checkFileExists(resourcePath + workingfile)):
				currentPath = resourcePath
			else:
				filecount -= 1
				if (filecount >= 0):
					workingfile=filelist[filecount]
				else:
					break
				continue

		meshHeader=[] #mesh header data
		meshName=[] #mesh names
		matName=[] #materialname used by meshes
		attachments=[]
		offsetMeshPiecesMesh=[]
		offsetMeshPiecesTexture=[]
		print(workingfile)
		fileHandle = open(currentPath + workingfile,"rb")
		fileReader = fileHandle.read()
		bs = NoeBitStream(fileReader)
		bs.seek(0x10,NOESEEK_ABS) #seek 0x10h/24
		num50Offsets=bs.read("i")
		gr2Type=bs.read("i")
		numMeshes=bs.read("h") #number of meshes
		numTextures=bs.read("h") #number of textures
		numBones=bs.read("h")
		numAttachs=bs.read("h")
		print( str(numAttachs))
		bs.seek(0x50,NOESEEK_ABS) #seek 0x50h/80
		offset50offset=bs.read("i")
		offsetMeshHeader=bs.read("i")
		offsetMaterialNameOffsets=bs.read("i")
		offsetBoneStructure=bs.read("i")
		offsetAttachments=bs.read("i")
		print (str(offsetAttachments))
		print("numMeshes: " + str(numMeshes[0]) + ", numTextures: " + str(numTextures[0]) + ", offset50offset: " + str(offset50offset[0]) + ", offsetMeshHeader: " + str(offsetMeshHeader[0]) + ", offsetMaterialNameOffsets=" + str(offsetMaterialNameOffsets[0]))
		
		if(offsetMeshHeader[0] != 0x70): #0x70
			print("Non-standard Mesh header: " + str(offsetMeshHeader))
		else:
			bs.seek(0x70,NOESEEK_ABS) #seek to Mesh Header
		
			#for loop to get meshHeader data
			for i in range(0,numMeshes[0]): 
				offsetMeshName=bs.read("i") 
				unkFloat=bs.read("f") #nem kell offsetMeshName olvassa
				numPieces=bs.read("h")
				numUsedBones=bs.read("h")
				unKnown=bs.read("h") #nem kell numBones olvassa
				numVertexBytes=bs.read("h")
				numVertices=bs.read("i")
				numFaces=bs.read("i")
				offsetMeshVertices=bs.read("i")
				offsetMeshPieces=bs.read("i")
				offsetFaces=bs.read("i") 
				offsetBones=bs.read("i") #nem kell offsetFaces olvassa
				print("offsetMeshName: " + str(offsetMeshName[0]) + ", numPieces: " + str(numPieces[0])+ ", numVertexBytes: " + str(numVertexBytes[0])+ ", numVertices: " + str(numVertices[0]) + ", numFaces: " + str(numFaces[0]))
				print("offsetMeshVertices: " + str(offsetMeshVertices[0]) + ", offsetMeshPieces: " + str(offsetMeshPieces[0]) + ", offsetFaces: " + str(offsetFaces[0]))
				meshHeader.append([offsetMeshName[0],numPieces[0],numVertexBytes[0],numVertices[0],numFaces[0],offsetMeshVertices[0],offsetMeshPieces[0],offsetFaces[0],offsetBones[0]])
										#0				#1				#2				#3				#4			#5						#6				#7				#8
			#-------------------------------------------------------------
		
			#for loop to get meshName data
			for i in range(0,numMeshes[0]):
				bs.seek((meshHeader[i][0]),NOESEEK_ABS)
				nameLength=0
				boolP=True
				while (boolP==True):
					wak=bs.read("b")
					if (wak[0]!=0):
						nameLength=nameLength+1
					else:
						boolP=False
				bs.seek((meshHeader[i][0]),NOESEEK_ABS)
				meshName.append(bs.readBytes(nameLength).decode("ASCII"))
			#-------------------------------------------------------------
		
			#for loop to get meshPieces data
			for i in range(0,numMeshes[0]): # meshszamszor vegrehajt pl 3 mesh
				bs.seek((meshHeader[i][6]),NOESEEK_ABS)
				for j in range(0,(meshHeader[i][1])): #hasznalt textura szamszor vegrehajt pl 4 texture
					materialFacesIndex=bs.read("i")
					materialNumFaces=bs.read("i") #szorozni harommal a vertex szamhoz
					textureID=bs.read("i")
					if (textureID[0]== -1):
						textureID = (0,)
					numIdx=materialNumFaces*3
					bs.seek(0x24,NOESEEK_REL)
					offsetMeshPiecesMesh.append([materialFacesIndex[0],materialNumFaces[0],textureID[0],numIdx[0]])
															#0				#1					#2			#3
					print("materialFacesIndex: " + str(materialFacesIndex[0])+ ", materialNumFaces: " + str(materialNumFaces[0])+ ", textureId: " + str(textureID[0])+ ", numIdx: " + str(numIdx[0]))
				offsetMeshPiecesTexture.append(offsetMeshPiecesMesh)
				offsetMeshPiecesMesh=[]
			#-------------------------------------------------------------
					
			#for loop to get Attached Objects data
			attachmentsOffsetList=[]
			bs.seek(offsetAttachments[0],NOESEEK_ABS) #seek to offsetAttachments
			for i in range(0,numAttachs[0]): #fill attachmentsOffsetList
				offsetAttachmentName=bs.read("i")
				offsetBoneName=bs.read("i")
				matrix=NoeMat44.fromBytes(bs.readBytes(64))
				attachmentsOffsetList.append([offsetAttachmentName[0],offsetBoneName[0],matrix])
				#print (matrix)

			for i in range(0,numAttachs[0]):
				bs.seek((attachmentsOffsetList[i][0]),NOESEEK_ABS)
				nameLength=0
				boolP=True
				while (boolP==True):
					wak=bs.read("b")
					if (wak[0]!=0):
						nameLength=nameLength+1
					else:
						boolP=False
				bs.seek(attachmentsOffsetList[i][0],NOESEEK_ABS)
				attachmentName=bs.readBytes(nameLength).decode("ASCII").rstrip("\0").rstrip("\\")

				bs.seek((attachmentsOffsetList[i][1]),NOESEEK_ABS)
				nameLength=0
				boolP=True
				while (boolP==True):
					wak=bs.read("b")
					if (wak[0]!=0):
						nameLength=nameLength+1
					else:
						boolP=False
				bs.seek(attachmentsOffsetList[i][1],NOESEEK_ABS)
				boneName=bs.readBytes(nameLength).decode("ASCII").rstrip("\0").rstrip("\\")

				attachments.append([attachmentName,boneName,attachmentsOffsetList[i][2]])

			for i in range(0,numAttachs[0]):
				print ("attachments: " + str(attachments[i]))
		
			#-------------------------------------------------------------
		
			#for loop to get materialName data
			matNameOffsetList=[]
			bs.seek(offsetMaterialNameOffsets[0],NOESEEK_ABS) #seek to 0x50 offsetMaterialNameOffset
			for i in range(0,numTextures[0]): #fill matNameOffsetList
				matNameOffsetList.append(bs.read("i"))

			if (offsetMaterialNameOffsets[0] == 0):
				print (str(meshHeader[0][0]))
				matNameOffsetList.append((meshHeader[0][0],))
				numTextures = (1,)
						
			for i in range(0,numTextures[0]):
				bs.seek((matNameOffsetList[i][0]),NOESEEK_ABS)
				nameLength=0
				boolP=True
				while (boolP==True):
					wak=bs.read("b")
					if (wak[0]!=0):
						nameLength=nameLength+1
					else:
						boolP=False
				bs.seek(matNameOffsetList[i][0],NOESEEK_ABS)
				matName.append(bs.readBytes(nameLength).decode("ASCII").rstrip("\0").rstrip("\\"))

			#-------------------------------------------------------------
		
			#material loading
			for i in range(0,numTextures[0]):
				print ("Material Name:" + matName[i])
				material=NoeMaterial(matName[i],"")

				materialFileName = matName[i]
				shaderLocation = resourcePath + "\\resources\\art\\shaders\\materials\\"
				if ("efault" in matName[i]): #uh oh this is a file with no regular materials defined. Checking for common material names based on model name.
					materialFileName = workingfile.split(".")[0]
					if (rapi.checkFileExists(shaderLocation + materialFileName + "_v01" + ".mat")):
						materialFileName = materialFileName + "_v01"
					elif (rapi.checkFileExists(shaderLocation + materialFileName + "_v02" + ".mat")):
						materialFileName = materialFileName + "_v02"
					elif (rapi.checkFileExists(shaderLocation + materialFileName + "_v03" + ".mat")):
						materialFileName = materialFileName + "_v03"
				materialFile = shaderLocation + materialFileName + ".mat"
				print(materialFile)
				
				inputs = {'DiffuseMap': 'default', 'GlossMap': 'default', 'UvScaling': '1,1', 'UsesReflection': 'False', 'ReflectionSpecInfluence': '0', 'ReflectionIntensity': '0', 'UsesEmissive': 'False', 'ReflectionContrast': '0', 'ReflectionBlurIntensity': '0', 'RotationMap1': 'default'} #setting up defaults
				alphaTestValue = 0.5
				alphaTestMode = "None"
				isTwoSided = False
				if (rapi.checkFileExists(materialFile)):
					f = open(materialFile, 'r') #material file
					xml = BeautifulSoup(f)
					#print(str(xml.material.input.semantic))
					f.close()

					rawInputs = xml.find_all("input")
					#print(str(rawInputs))
					for input in rawInputs:
						inputs[input.semantic.string] = input.value.string
					print(inputs)

					alphaTestValue = float(xml.alphatestvalue.string)
					print("AlphaTestValue: " + str(alphaTestValue))
					alphaTestMode = xml.alphamode.string
					print("AlphaTestMode: " + alphaTestMode)
					isTwoSided = bool(xml.istwosided.string)
					print("IsTwoSided: " + alphaTestMode)

				diffuseFile = resourcePath + "\\resources\\" + inputs["DiffuseMap"] + ".dds"
				rotationFile = resourcePath + "\\resources\\" + inputs["RotationMap1"] + ".dds"
				glossFile = resourcePath + "\\resources\\" + inputs["GlossMap"] + ".dds"

				UsesEmissive = bool(inputs["UsesEmissive"])
				print("UsesEmissive: " + str(UsesEmissive))
				useReflections = bool(inputs["UsesReflection"])
				print("UsesReflection: " + str(useReflections))
				reflectionIntensity = float(inputs["ReflectionIntensity"])
				print("reflectionIntensity: " + str(reflectionIntensity))
				reflectionBlurIntensity = float(inputs["ReflectionBlurIntensity"])
				print("reflectionBlurIntensity: " + str(reflectionBlurIntensity))

				print("d " + diffuseFile)
				print("n " + rotationFile)
				print("s " + glossFile)
				print("a " + str(alphaTestValue))

				#print ("texPath: " + texPath)
				if (matName[i] == "util_collision_hidden"): #Disable the material for the collision geometry meshes
					material.setSkipRender(1)

				if (rapi.checkFileExists(diffuseFile)):
					rgbaMap1 = noesis.loadImageRGBA(diffuseFile)
					rgbaMap1Data = rgbaMap1.pixelData
					height = rgbaMap1.height
					width = rgbaMap1.width
					
					if (alphaTestMode == "Add"):
						diffuseData = rgbaMap1Data
					else:
						diffuseData = rapi.imageDecodeRaw(rapi.imageEncodeRaw(rgbaMap1Data, width, height, "r8g8b8a0"), width, height, "r8g8b8a0") #have to remove the alpha channel

					if ("irror" in matName[i]):
						#diffuseData = rapi.imageFlipRGBA32(diffuseData, width, height, 1, 0)
						material.setSkipRender(1) #skipping "mirrored" materials for now as they don't load properly
					#experimental section to apply pallete files to a texture
					#if (rapi.checkFileExists(dirPath + matName[i] + ".mat")):
						#code to pull pallete dds name from .mat file
						#palleteRGBA = noesis.loadImageRGBA(dirPath + matName[i]+".dds") #get pallet dds here into a Noetexture
						#
						#rapi.imageDecodeRawPal(dataToApplyPalleteTo, palleteRGBA, pixWidth, pixHeight, 8, "r8g8b8a8")

					diffuseMap1 = NoeTexture(matName[i] + "_diffuse", width, height, diffuseData)
					texList.append(diffuseMap1)
					material.setTexture(matName[i] + "_diffuse")
					material.setDiffuseColor([1,1,1,0])
					material.setAmbientColor([.5,.5,.5,0])

					if (alphaTestMode == "Add"):
						material.setBlendMode("GL_ONE", "GL_ONE")
					
					#if (rapi.checkFileExists(resourcePath + "\\resources\\art\\environmentmaps\\coruscant_main\\area.dds")):
						#enviromentMap = noesis.loadImageRGBA(resourcePath + "\\resources\\art\\environmentmaps\\coruscant_main\\area.dds")
						#cubeMap = NoeTexture("envMap", enviromentMap.width, enviromentMap.height, enviromentMap.pixelData * 6)
						#cubeMap.setFlags(noesis.NTEXFLAG_CUBEMAP)
						#texList.append(cubeMap)
						#material.setEnvTexture("envMap")

					if (rapi.checkFileExists(rotationFile)):
						rotationMap1 = noesis.loadImageRGBA(rotationFile)
						rotationMap1Data = rotationMap1.pixelData
						rotHeight = rotationMap1.height
						rotWidth = rotationMap1.width

						opacityData = bytearray([])
						if (alphaTestMode == "Test" and rotWidth == width and rotHeight == height):
							for k in range(0, rotWidth*rotHeight):
								opacityData.append(rgbaMap1Data[k*4 + 0])
								opacityData.append(rgbaMap1Data[k*4 + 1])
								opacityData.append(rgbaMap1Data[k*4 + 2])
								opacityData.append(255 - rotationMap1Data[k*4 + 0])
							opacityMap = NoeTexture(matName[i] +"_opacity", rotWidth, rotHeight, opacityData)
							texList.append(opacityMap)
							material.setTexture(matName[i] +"_opacity")
						else:
							opacityData = rapi.imageDecodeRaw(rapi.imageEncodeRaw(rotationMap1Data, rotWidth, rotHeight, "g0b0a0r8"), rotWidth, rotHeight, "a8")
							opacityMap = NoeTexture(matName[i] +"_opacity", rotWidth, rotHeight, opacityData)
							texList.append(opacityMap)
							material.setOpacityTexture(matName[i] +"_opacity")
							material.setAlphaTest(alphaTestValue)
							if (alphaTestMode == "MultipassFull"):
								material.setBlendMode("GL_SRC_ALPHA", "GL_SRC_COLOR")
							elif(alphaTestMode == "Full"):
								material.setBlendMode("GL_SRC_ALPHA", "GL_SRC_ALPHA")
			
						bumpData = rapi.imageDecodeRaw(rapi.imageEncodeRaw(rotationMap1Data, rotWidth, rotHeight, "r0g8b0a8"), rotWidth, rotHeight, "r8g8b0a0")
						normalData = rapi.imageNormalMapFromHeightMap(bumpData, rotWidth, rotHeight, 1, 2) #this turns our bump map into a normal map
						bumpMap1 = NoeTexture(matName[i] +"_bump", rotWidth, rotHeight, normalData)
						texList.append(bumpMap1)
						material.setNormalTexture(matName[i] +"_bump")

						if(UsesEmissive): #rotWidth == width and rotHeight == height):
							emissiveMaterial=NoeMaterial(matName[i] + "_emissive","")

							#emissiveMask = bytearray([])
							#multiplier = int(4 * math.floor((width/rotWidth)*(height/rotHeight)))
							#print( str(width) + "x" + str(height) + " " + str(rotWidth) + "x" + str(rotHeight))
							#for j in range(0, rotWidth*rotHeight):
								#if (rotationMap1Data[j*4 + 2] != 0): #check blue channel of the rotationMap which is the alpha channel of the glowMap, and...
								#	emissiveMask.append(255) #rgbaMap1Data[j*4 + 0]) #copy only the non-masked pixels from the diffuseMap
								#	emissiveMask.append(255) #rgbaMap1Data[j*4 + 1])
								#	emissiveMask.append(255) #rgbaMap1Data[j*4 + 2])
								#else:
								#	emissiveMask.append(0)
								#	emissiveMask.append(0)
								#	emissiveMask.append(0)
								#emissiveMask.append(rotationMap1Data[j*4 + 2])
								#emissiveMask.append(rotationMap1Data[j*4 + 2])
								#emissiveMask.append(rotationMap1Data[j*4 + 2])
								#emissiveMask.append(rotationMap1Data[j*4 + 2]) #set the alpha channel value from the rotationMap
							emissiveMask = rapi.imageDecodeRaw(rapi.imageEncodeRaw(rotationMap1Data, rotWidth, rotHeight, "b8b8b8b8"), width, height, "r8g8b8a8")

							emissiveMaskMap1 = NoeTexture(matName[i] +"_emissive1", rotWidth, rotHeight, emissiveMask)
							emissiveMaterial.setAlphaTest(alphaTestValue)
							emissiveMaterial.setOpacityTexture(matName[i] +"_opacity")
							emissiveMaterial.setTexture(matName[i] +"_emissive1")
							texList.append(emissiveMaskMap1)
							emissiveMaterial.setBlendMode("GL_DST_COLOR","GL_ONE")
							material.setNextPass(emissiveMaterial)
					else:
						print ("Couldn't find the normal map: " + rotationFile)
					flags = 0
					if (rapi.checkFileExists(glossFile) and useReflections):
						glossMap1 = noesis.loadImageRGBA(glossFile)
						gloHeight = glossMap1.height
						gloWidth = glossMap1.width
						glossMapData = glossMap1.pixelData
						specularMap1 = NoeTexture(matName[i] +"_gloss", gloWidth, gloHeight, glossMapData, noesis.NOESISTEX_RGBA32) #blurMap)
						texList.append(specularMap1)
						#material.setSpecularTexture(matName[i] +"_gloss") #disabled because it doesn't work right
						#material.setSpecularColor([reflectionIntensity,reflectionIntensity,reflectionIntensity,32]) 
						#flags += noesis.NMATFLAG_KAJIYAKAY #this flag is needed so that that the alpha channel of the specular map is used as the luminosity value
					if (isTwoSided):
						flags += noesis.NMATFLAG_TWOSIDED 
					material.setFlags(flags) 
				else:
					material.setTexture("default_d.dds")

				print (texList)
				matList.append(material)
			#-------------------------------------------------------------
			#if (filecount == 0):
				#rapi.rpgSetPosScaleBias(NoeVec3((1,1,1)), NoeVec3((0,0,0))) #testing positioning of loaded models
			#else:
				#rapi.rpgSetPosScaleBias(NoeVec3((1,1,1)), NoeVec3((0,0,0)))
			#the draw
			for i in range(0,numMeshes[0]):
				bs.seek(meshHeader[i][5],NOESEEK_ABS) #set pointer to vertex offset
				if meshHeader[i][2]==12:
					VertBuff = bs.readBytes((meshHeader[i][3]) * 0xC)
					#rapi.rpgBindPositionBufferOfs(VertBuff, noesis.RPGEODATA_FLOAT, 12, 0) #this appears to be the collision model - disabled so it's invisible
					continue
				elif meshHeader[i][2]==24:
					VertBuff = bs.readBytes((meshHeader[i][3]) * 0x18)
					rapi.rpgBindPositionBufferOfs(VertBuff, noesis.RPGEODATA_FLOAT, 24, 0)
					rapi.rpgBindNormalBufferOfs(VertBuff,noesis.RPGEODATA_UBYTE, 24, 12)
					rapi.rpgBindTangentBufferOfs(VertBuff,noesis.RPGEODATA_UBYTE, 24,16)
					rapi.rpgBindUV1BufferOfs(VertBuff,noesis.RPGEODATA_HALFFLOAT,24,20)
					rapi.rpgBindUV2BufferOfs(VertBuff,noesis.RPGEODATA_HALFFLOAT,24,20)
				elif meshHeader[i][2]==32:
					VertBuff = bs.readBytes((meshHeader[i][3]) * 0x20)
					rapi.rpgBindPositionBufferOfs(VertBuff, noesis.RPGEODATA_FLOAT, 32, 0)
					rapi.rpgBindNormalBufferOfs(VertBuff,noesis.RPGEODATA_UBYTE, 32, 12)
					rapi.rpgBindTangentBufferOfs(VertBuff,noesis.RPGEODATA_UBYTE, 32,16)
					rapi.rpgBindUV1BufferOfs(VertBuff,noesis.RPGEODATA_HALFFLOAT,32,28) #this value can either be 20 or 28. The vast majority of models use 28, but we need to find the flag that sets this.
				rapi.rpgCommitTriangles(None, noesis.RPGEODATA_USHORT, meshHeader[i][3], noesis.RPGEO_POINTS, 1)
				bs.seek(meshHeader[i][7],NOESEEK_ABS)
				#print("debug1: " + str(meshHeader[i][7]))
				for j in range(0,meshHeader[i][1]):
					#print ("debug: " + str(i) + ", " + str(j))
					FaceBuff=bs.readBytes((offsetMeshPiecesTexture[i][j][1]*3)*2)
					rapi.rpgSetMaterial(matName[offsetMeshPiecesTexture[i][j][2]])
					#rapi.rpgSetLightmap(matName[(offsetMeshPiecesTexture[i][j][2] - 1 )] + "_e")
					rapi.rpgSetName(meshName[i])
					rapi.rpgCommitTriangles(FaceBuff, noesis.RPGEODATA_USHORT, offsetMeshPiecesTexture[i][j][1]*3, noesis.RPGEO_TRIANGLE, 1)
				rapi.rpgClearBufferBinds()
		fileHandle.close()
		filecount -= 1
		if (filecount >= 0):
			workingfile=filelist[filecount]
		
	mdl=rapi.rpgConstructModel()
	mdl.setModelMaterials(NoeModelMaterials(texList,matList))
	mdlList.append(mdl)
	rapi.rpgClearBufferBinds()
	return 1