import newGameLib
reload(newGameLib)
from newGameLib import *
import Blender

			
def section_1860(g):
	g.B(4)
	num = g.i(8)
	for m in range(num[4]):
		t=g.tell()		
		mesh.vertPosList.append(g.f(3))
		g.seek(t+24,0)
	for m in range(num[6]):
		t=g.tell()
		mesh.faceList.append(g.i(3))
		matID,unk=g.i(2)
		mesh.matIDList.append(matID)
		g.seek(t+20,0) 
	if num[3]!=0: 
		uvcoord=[]
		for m in range(num[5]):
			uvcoord.append(Vector(g.f(2)))
		for m in range(num[6]):
			id1,id2,id3=g.i(3)
			mesh.faceUVList.append([uvcoord[id1],uvcoord[id2],uvcoord[id3]])
		skin=Skin()
		for m in range(num[4]):
			count = g.i(1)[0]
			list1,list2=[],[]
			for n in range(count):
				list1.append(g.i(1)[0])
				g.f(3)
				list2.append(g.f(1)[0])
			mesh.skinIndiceList.append(list1)
			mesh.skinWeightList.append(list2)
		mesh.skinList.append(skin)	
	
	
def section_0(g):
	g.find('\x00')


def section_1863(g):
	g.i(4)
	t=g.tell()
	name=g.find('\x00')
	g.seek(t+132,0)
	type=g.B(4)
	if type==(255,255,255,0):
		mat=Mat()
		mat.ZTRANS=True
		g.seek(t+404,0)
		name=g.find('\x00')
		mat.diffuse=g.dirname+os.sep+os.path.basename(name)
		if os.path.exists(mat.diffuse)==False:
			mat.diffuse=g.dirname.split('object')[0]+os.sep+name		
		g.seek(t+876,0)
		g.seek(t+1348,0)
		g.find('\x00')
		g.seek(t+1820,0)
		name=g.find('\x00')
		mat.specular=g.dirname+os.sep+os.path.basename(name)
		if os.path.exists(mat.specular)==False:
			mat.specular=g.dirname.split('object')[0]+os.sep+name
		mesh.matList.append(mat)	

	
def section_656(g):
	g.B(4)
	num = g.i(4)
	for m in range(num[3]):
		t=g.tell()
		v=g.i(3)
		g.seek(t+152,0)	
		bone_parent_list.append(v[1])

		
def section_1861(g):	
	num = g.i(1)[0]
	for m in range(num):
		name=g.find('\x00')
		bone_name_list.append(name)

		
def section_1(g): 
	num = g.i(2)
	for m in range(num[1]):
		rotmatrix=Matrix(g.f(3),g.f(3),g.f(3)).resize4x4()
		posmatrix=TranslationMatrix(Vector(g.f(3)))
		bone_matrices_list.append([rotmatrix,posmatrix])
	
	
def cgfParser(filename,g):
	global mesh,skeleton
	global bone_matrices_list
	global bone_parent_list
	global bone_name_list
	
	global mesh
	
	skeleton=Skeleton()
	skeleton.name='armature'
	skeleton.ARMATURESPACE=True
	bone_matrices_list=[]
	bone_parent_list=[]
	bone_name_list=[]
	
	mesh=Mesh() 
	mesh.BINDSKELETON=skeleton.name

	g.word(10)
	g.H(1)
	mat_id=0
	bone_id=0
	off=g.i(2)
	g.seek(off[1],0)
	nSec = g.i(1)[0]
	off_list=[]
	for m in range(nSec):
		off_list.append([g.B(4),g.i(3)])
	for m in range(nSec):
		chunk=off_list[m][0]
		type=off_list[m][1][0]  
		off=off_list[m][1][1]
		g.seek(off,0)
		if type==0:
			section_0(g) 
		if chunk==(0,0,204,204) and type==1860: 
			section_1860(g)
		if chunk==(3,0,204,204) and type==656:
			section_656(g)
		if chunk==(5,0,204,204) and type==1861:
			section_1861(g)  
		if chunk==(18,0,204,204) and type==1:
			section_1(g)
		if chunk==(12,0,204,204) and type==1863:
			section_1863(g)
		if chunk==(13,0,204,204) and type==2089:	  
			anim_section_2089(bone_id)
			bone_id+=1
		
	for m in range(len(bone_name_list)):
		bone=Bone()
		bone.name=bone_name_list[m]
		bone.parentID=bone_parent_list[m]
		bone.rotMatrix=bone_matrices_list[m][0]
		bone.posMatrix=bone_matrices_list[m][1]
		skeleton.boneList.append(bone)
	skeleton.draw()	
	mesh.boneNameList=skeleton.boneNameList
	mesh.draw()	
	
						
		

		
				
def section_2089(g):
	num=g.i(2)
	abone=ActionBone()
	framecountlist.append(num[0])
	for m in range(num[0]):
		t=g.tell()
		time = int(g.i(1)[0]/160)
		pos=g.f(3)
		rot=g.f(4)
		rot=Quaternion(rot[3],rot[0],rot[1],rot[2]).toMatrix().invert()
		matrix = Matrix()		   
		matrix[0][:3] = rot[0]
		matrix[1][:3] = rot[1]
		matrix[2][:3] = rot[2]
		matrix[3][:3] = pos
		abone.posFrameList.append(time)
		abone.rotFrameList.append(time)
		abone.posKeyList.append(TranslationMatrix(Vector(pos)))
		abone.rotKeyList.append(rot.resize4x4())
		#abone.matrixframelist.append(time) 
		#abone.matrixkeylist.append(matrix)
		g.seek(t+32)
	action.boneList.append(abone)
		
def caf_parser(filename,g):
	global bone_name_list
	global action
	global framecountlist
	framecountlist=[]
			
	action=Action()
	action.skeleton='armature'
	action.BONESPACE=True
	action.BONESORT=True
	
	bone_name_list=[]

	g.word(10)
	g.H(1)
	off=g.i(2)
	g.seek(off[1],0)
	nSec = g.i(1)[0]
	off_list=[]
	for m in range(nSec):
		off_list.append([g.B(4),g.i(3)])
	for m in range(nSec):
		chunk=off_list[m][0]
		type=off_list[m][1][0]  
		off=off_list[m][1][1]
		g.seek(off)
		if chunk==(5,0,204,204) and type==1861:section_1861(g) 
		if chunk==(13,0,204,204) and type==2089:section_2089(g)
	for m in range(len(action.boneList)):
		abone=action.boneList[m]
		abone.name=bone_name_list[m]
	action.framecount=max(framecountlist)
	action.draw()	
	action.setContext()				
						
				
		
			
def Parser():
	filename=input.filename
	ext=filename.split('.')[-1].lower()
	
	if ext=='cgf':
		file=open(filename,'rb')
		g=BinaryReader(file)
		cgfParser(filename,g)
		file.close()
		
	if ext=='caf':
		file=open(filename,'rb')
		g=BinaryReader(file)
		caf_parser(filename,g)
		file.close()
 
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
	
Blender.Window.FileSelector(openFile,'import','cgf - skeleton mesh,caf - animation file') 