#!/usr/bin/env ruby

def make_code_map(infile, className)
  key = []
  value = []
  ifp = open(infile)
  ifp.read.each do |line|
    if line =~ /^(\d+),(.*)/
      key << $1
      value << $2
    end
  end
  ifp.close

  ofp = open("#{className}.java", "w")
  ofp.printf "public class #{className} {\n"
  ofp.printf "\tpublic static final String[][] array = {\n"
  key.length.times do |i|
    ofp.printf "\t\t{\"#{key[i]}\", \"#{value[i]}\"},\n"
  end
  ofp.printf "\t};\n"
  ofp.printf "}\n"
end

make_code_map('../../codes/@items.csv', 'ItemList')
make_code_map('../../codes/@characters.csv', 'CharaList')
