import java.util.ArrayList;

public class Category {
    String mName;
    ArrayList<Obj3D> mObjArray;

    Category(String name) {
	mName = name;
	mObjArray = new ArrayList<Obj3D>();
    }

    Obj3D getObject(int index) {
	return mObjArray.get(index);
    }

    String getName() {
	return mName;
    }

    @Override
    public String toString() {
	return getName();
    }

    void add(Obj3D object) {
	mObjArray.add(object);
    }
}
