package vra;

public class VraException extends Exception {
    public VraException(String msg) {
	super(msg);
    }

    public VraException(String msg, Throwable th) {
	super(msg, th);
    }
}
