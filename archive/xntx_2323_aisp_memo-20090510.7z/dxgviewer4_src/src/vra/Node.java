package vra;

import java.util.*;

/**
 * vra�ե�������ΥΡ��ɤ�ɽ�魯���饹��
 *
 * vra�ե������XML�˻������ع�¤�Υǡ������ݻ����롣
 * �Ρ��ɤϳ��ؾ��˹�������Ƥ��ꡢ�ޤ��ơ��ΥΡ��ɤ�°������ġ�
 * <p>���ع�¤����:<pre>
 * vra
 *   +-geometry
 *   | +-mesh
 *   |   +-lod0
 *   +-material_set
 *   | +-material
 *   |   +-texture
 *   |   +-diffuse
 *   |   +-param_block
 *   +-attribute
 *   +-dynamics_set
 *     +-collision
 *     +-dynamics
 *       +-joint
 *       +-connect
 * </pre>
 */
public class Node {
    private String mName;
    private Node mParent;
    private ArrayList<Node> mChildren;
    private ArrayList<Attr> mAttrs;

    public Node(String name, Node parent) {
	mName = name;
	mParent = parent;
	mChildren = new ArrayList<Node>();
	mAttrs = new ArrayList<Attr>();
    }

    public String getName() {
	return mName;
    }

    public Node getParent() {
	return mParent;
    }

    public List<Node> getChildren() {
	return mChildren;
    }

    public Node findChild(String name) {
	for(Node child: mChildren)
	    if(child.getName().equals(name))
		return child;
	return null;
    }

    public List<Attr> getAttributes() {
	return mAttrs;
    }

    public Attr getAttribute(String name) {
	for(Attr attr: mAttrs)
	    if(attr.getName().equals(name))
		return attr;
	return null;
    }

    protected void addAttr(Attr attr) {
	mAttrs.add(attr);
    }

    public void print() {
	print(0);
    }

    public void print(int depth) {
	int i;
	for(i = 0; i < depth; i++)
	    System.out.print("  ");
	System.out.printf("{%s}\n", mName);
	for(Attr attr: mAttrs) {
	    for(i = 0; i < depth + 1; i++)
		System.out.print("  ");
	    System.out.printf("%s (%s):", attr.getName(), attr.getType());
	    for(Object o: attr.getValues())
		System.out.printf(" %s", o.toString());
	    System.out.println();
	}
	    
	for(Node child: mChildren)
	    child.print(depth + 1);
    }
}
