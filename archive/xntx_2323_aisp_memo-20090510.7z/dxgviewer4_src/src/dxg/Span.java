package dxg;

import java.util.ArrayList;

public class Span {
    String desc;
    int start, len, elem_nr, elem_size;

    public Span(String desc, int start, int len, int elem_nr, int elem_size) {
	this.desc = desc;
	this.start = start;
	this.len = len;
	this.elem_nr = elem_nr;
	this.elem_size = elem_size;
    }

    public void setLength(int len) {
	this.len = this.elem_size = len;
    }

    private static void printHeader() {
	System.out.println(
	    //23456 123456 123456 123456 123456 123456 123456 
	    "  ����   ��λ �ΰ�Ĺ   ����   ��λ   �Ŀ� ������ �֥��å�̾\n");
    }

    public void show() {
	System.out.printf("%6d %6d %6d %5xh %5xh %6d %6d %s\n",
			  start, start + len, len,
			  start, start + len, elem_nr, elem_size, desc);
    }

    public static void list(ArrayList<Span> spans) {
	printHeader();
	for(Span span: spans)
	    span.show();
    }
}
