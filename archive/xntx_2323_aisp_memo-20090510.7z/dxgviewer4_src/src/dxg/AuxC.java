package dxg;

import java.util.*;
import java.nio.*;

public class AuxC {
    int nr_aux_elems;
    float[] dataz;

    AuxC(ByteBuffer bf, String type, FileHeader fhdr, ArrayList<Span> ranges) {
    }

    void show(int what) {
    }
}
