package dxg;

import java.util.*;
import java.nio.*;

public class AuxD {
    int nr_aux_elems;
    String[] names; // ¸�ߤ��ʤ����Ȥ⤢��
    BoneLink[] boneLinks;
    float[] dataz;

    AuxD(ByteBuffer bf, String type, FileHeader fhdr, ArrayList<Span> ranges) {
    }

    void show(int what) {
    }
}
