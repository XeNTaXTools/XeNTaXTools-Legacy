#by Durik256
from inc_noesis import *
import os
from ctypes import *
import noewin

def registerNoesisTypes():
    handle = noesis.registerTool("&TestTx", TestTxMethod)
    handle = noesis.register("TestTx", ".TestTx")
    noesis.setHandlerTypeCheck(handle, CheckType)
    noesis.setHandlerLoadRGBA(handle, LoadRGBA)
    return 1

FilePath = ""
fileSize, coef = 0xFFFF, 1

def CheckType(data):
    if data[:4] != b'TEST':
        return 0
    return 1
    
def LoadRGBA(data, texList):
    name = rapi.getInputName()
    
    arg  = data.decode().split(';')
    ofs  = toInt(arg[1], 'offset')
    w    = toInt(arg[2], 'width')
    h    = toInt(arg[3], 'height')
    fmt  = arg[4]
    bits = parseFormat(fmt)
        
    if w <= 0: w =1
    if h <= 0: h =1
        
    print('offset:',ofs,'\nsize: %ix%i'%(w,h),'\nformat:',fmt,'\nbits per pixel:',bits)
        
    bs = NoeBitStream(rapi.loadIntoByteArray(FilePath))
    if ofs > bs.getSize():
        ofs = bs.getSize() -1
    bs.seek(ofs)
    size, eof, add = int(-1 * (w*h*bits/8) // 1 * -1), bs.getSize() - ofs, 0
    if eof < size:
        add = size - eof
        size = eof
        
    print('size file:',bs.getSize(),'\nsize on prewiev:',size+add)
        
    data = bs.readBytes(size) + b'\xFF'*add
    data = rapi.imageDecodeRaw(data, w, h, fmt)
    
    #if fw or fh:
    #    data = rapi.imageFlipRGBA32(data, w, h, fh, fw)
    
    texList.append(NoeTexture(name, w, h, data, noesis.NOESISTEX_RGBA32))
    return 1
    
def parseFormat(fmt):
    try:
        x = ''.join(c if c.isdigit() else ' ' for c in fmt)
        return sum([int(i) for i in x.split()])
    except:
        print('Error parse format', fmt)
        return 0
    
def toInt(s, n='value'):
    try:
        s = ''.join(c if c.isdigit() else '' for c in s)
        return int(s)
    except:
        print('Error convert', n)
        return 0
 
#---------------------------------------------------
def dialogOpenFile(wind, id, wParam, lParam):
    FileName = noesis.userPrompt(noesis.NOEUSERVAL_FILEPATH, "Open File", "Select any File", noesis.getSelectedFile())
    global FilePath, fileSize, coef
    
    if FileName:
        FilePath = str(FileName)
        noewin.user32.SetWindowTextW(wind.userControls[11].hWnd, os.path.basename(FileName))
        
        fileSize = os.stat(FilePath).st_size
        coef = fileSize/0xFFFF
        #wind.userControls[16].setScrollMinMax(0, 65535)
        wind.userControls[16].setScrollValue(0)
        OpenTemp(wind, id, wParam, lParam)
        
def OpenTemp(wind, controlId, wParam, lParam):
    template = 'TEST;'
    
    for x in range(1,4):#textbox
        template += str(wind.userControls[x].getText().strip()) + ';'
        
    x = wind.userControls[0]
    l = noewin.user32.GetWindowTextLengthW(x.hWnd) + 1
    textBuffer = noewin.create_unicode_buffer(l)
    noewin.user32.GetWindowTextW(x.hWnd, textBuffer, l)
    template += textBuffer.value.strip() + ';'
    
    if os.path.exists(FilePath):
        with open('test.TestTx', 'w') as w:
            w.write(template)
        noesis.openAndRemoveTempFile('test.TestTx')
    else:
        print('Error file exists!', FilePath)
    print(template)
    
def TestTxMethod(toolIndex):
    noesis.logPopup()
    
    wind = noewin.NoeUserWindow("TEST", "TestTxClass", 427, 206, noewin.defaultWindowProc)

    rect = noewin.getNoesisWindowRect()
    if rect:
        wind.x = rect[0] + 64
        wind.y = rect[1] + 64
    if not wind.createWindow():
        print("Failed to create window.")
        return 0

    wind.setFont("Arial", 14)
    ctrl = wind.userControls
    
    wind.createComboBox(90, 10, 320, 24, comboMethod, style = noewin.CBS_DROPDOWN)#0-ImageType
    wind.createEditBox(305, 44, 90, 24, text = '0', commandMethod = editMethod, isMultiLine = False)#1-Offset
    wind.createEditBox(305, 74, 90, 24, text = '512', commandMethod = editMethod, isMultiLine = False)#2-Width
    wind.createEditBox(305, 104, 90, 24, text = '512', commandMethod = editMethod, isMultiLine = False)#3-Height
    
    #UpDownNumeric ▲▼▾▴
    wind.createButton('▴', 395, 44, 15, 12, ChangeValue)#4 - Offset
    wind.createButton('▾', 395, 56, 15, 12, ChangeValue)#5 - Offset
    wind.createButton('▴', 395, 74, 15, 12, ChangeValue)#6 - Width
    wind.createButton('▾', 395, 86, 15, 12, ChangeValue)#7 - Width
    wind.createButton('▴', 395, 104, 15, 12, ChangeValue)#8 - Height
    wind.createButton('▾', 395, 116, 15, 12, ChangeValue)#9 - Height

    wind.createButton("Open File", 10, 138, 80, 24, dialogOpenFile)#10
    
    #static
    wind.createStatic(""           , 100, 141, 307, 24)#11
    wind.createStatic("Image Type:", 10 , 14 , 100, 24)#12
    wind.createStatic("offset:"    , 10 , 49 , 100, 24)#13
    wind.createStatic("Width:"     , 10 , 79 , 100, 24)#14
    wind.createStatic("Height:"    , 10 , 109, 100, 24)#15
    
    #add items in combobox
    formats = ['r16g16b16a16', 'r16g16b16',
               'r8g8b8a8'    , 'r8g8b8'   ,
               'r5g6b5'      , 'r5g5b5a1' ,
               'r4g4b4a4'    , 'r3g3b2'   ,
               'r2g2b2a2'    ]
    
    for x in formats:
        wind.userControls[0].addString(x)
    wind.userControls[0].selectString('r8g8b8a8')
    
    #slider
    wind.createScrollBar(90, 42, 205, 24, scrl0)#16
    wind.userControls[-1].setScrollMinMax(0, 0xFFFF)
    wind.userControls[-1].setScrollValue(512)
    
    wind.createScrollBar(90, 72, 205, 24, scrl1)#17
    wind.userControls[-1].setScrollMinMax(1, 2048)
    wind.userControls[-1].setScrollValue(512)
    
    wind.createScrollBar(90, 102, 205, 24, scrl2)#18
    wind.userControls[-1].setScrollMinMax(1, 2048)
    wind.userControls[-1].setScrollValue(512)
    return 0

def editMethod(wind, id, wParam, lParam):
    notificationId = (wParam >> 16)
    if notificationId == noewin.EN_CHANGE:
        editBox = wind.getControlById(id)
        print("Edit update:", editBox.getText())
        OpenTemp(wind, id, wParam, lParam)
    return False	

def comboMethod(wind, id, wParam, lParam):
    notificationId = (wParam >> 16)
    if notificationId == noewin.CBN_SELCHANGE:
        comboBox = wind.getControlById(id)
        comboIndex = comboBox.getSelectionIndex()
        noewin.user32.SetWindowTextW(wind.userControls[0].hWnd, comboBox.getStringForIndex(comboIndex))
        OpenTemp(wind, id, wParam, lParam)
    return False

def scrl0(wind, id, wParam, lParam, scrollType):
    if wParam != lParam:
        noewin.user32.SetWindowTextW(wind.userControls[1].hWnd, str(int(-1 * (lParam*coef) // 1 * -1)))
    if scrollType == noewin.SB_ENDSCROLL:
        OpenTemp(wind, id, wParam, lParam)
        
def scrl1(wind, id, wParam, lParam, scrollType):
    if wParam != lParam:
        noewin.user32.SetWindowTextW(wind.userControls[2].hWnd, str(lParam))
    if scrollType == noewin.SB_ENDSCROLL:
        OpenTemp(wind, id, wParam, lParam)
        
def scrl2(wind, id, wParam, lParam, scrollType):
    if wParam != lParam:
        noewin.user32.SetWindowTextW(wind.userControls[3].hWnd, str(lParam))
    if scrollType == noewin.SB_ENDSCROLL:
        OpenTemp(wind, id, wParam, lParam)

#UpDownNumerick change value
def calc(id, ids, i, wind):
    s = ''.join(c for c in '0'+wind.userControls[id].getText() if c.isdigit())
    s = int(s) + (i)
    if s < 0: s = 0
    wind.userControls[id].setText(str(s))
    if ids == 17 or ids == 18:
        if s > 2049: s = 2048
    else:
        if s > 0xFFFF: s = 0xFFFF
        
    wind.userControls[ids].setScrollValue(s)
   
def ChangeValue(wind, id, wParam, lParam):
    btn = wind.getControlById(id)
    if btn == wind.userControls[4]:#4 - Offset
        calc(1, 16, 1, wind)
    elif btn == wind.userControls[5]:#5 - Offset
        calc(1, 16, -1, wind)
    elif btn == wind.userControls[6]:#6 - Width
        calc(2, 17, 1, wind)
    elif btn == wind.userControls[7]:#7 - Width
        calc(2, 17, -1, wind)
    elif btn == wind.userControls[8]:#8 - Height
        calc(3, 18, 1, wind)
    elif btn == wind.userControls[9]:#9 - Height
        calc(3, 18, -1, wind)
    #OpenTemp(wind, id, wParam, lParam)