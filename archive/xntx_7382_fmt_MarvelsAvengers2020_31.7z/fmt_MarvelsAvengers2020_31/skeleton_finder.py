import os
import struct
from shutil import copyfile
uiNumBones =  0
search_dir = "D:\\marvel\\drm_unp"
print("search_dir:	" + search_dir)

for root, dirs, files in os.walk(search_dir):
	if(root.upper().endswith("\\DTPDATA")):
		for name in files:
		
			#print(os.path.join(root, name))
			if(name.upper().endswith(".DTP")):
				#print(os.path.join(root, name))
				isSkeleton = False
				
				
				
				f = open(os.path.join(root, name), 'rb')
				f.seek(0,2)
				f_size = f.tell()
				f.seek(0,0)
				if(f_size>=0x0100):				
					data = f.read(4)
					T = struct.unpack("<I", data)[0]
					#print("T: " + str(hex(T[0])))
					if(T == 0x0D):
						
						f.seek(0x18, 0)
						data = f.read(4)
						UnkBluckSize = struct.unpack("<I", data)[0]
						
						
						for ii in range(13):
							uiUnkVal1_1 = f.read(4)
							uiUnkVal1_2 = f.read(4)
						for ii in range(UnkBluckSize):
							uiUnkVal1_1 = f.read(4)
							uiUnkVal1_2 = f.read(4)
							
						data = f.read(4)	
						test_val = struct.unpack("<I", data)[0]
						while(test_val > 0):
							data = f.read(4)	
							test_val = struct.unpack("<I", data)[0]
						f.seek(0xAC, 1)
						data = f.read(4)
						uiNumBones = struct.unpack("<I", data)[0]
						if(uiNumBones > 0):
							if(uiNumBones <= 0x10000):
								isSkeleton = True
								
				f.close()
				
				
				
				if(isSkeleton):
					print("	" + os.path.join(root, name))
					print("		uiNumBones: " + str(uiNumBones))
					copy_to = root#root[:-len("\\DTPDATA")] + "\\RenderMesh"
					if(os.path.exists(copy_to) ):
						#print("	" + copy_to)
						copyname_base = os.path.join(copy_to, "skeleton")
						copyname = copyname_base + "_1"
						i = 2
						while(os.path.exists(copyname + ".maskl")):
							copyname = copyname_base + "_" + str(i)
							i = i + 1
						copyname = copyname + ".maskl"
						print("		copy_to " + copyname)
						copyfile(os.path.join(root, name), copyname)
						