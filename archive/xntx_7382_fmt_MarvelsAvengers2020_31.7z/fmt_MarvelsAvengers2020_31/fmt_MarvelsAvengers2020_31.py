#Marvel's Avengers [PC] - ".mamesh" / ".mapcd" /".maskl" Loader
#v0.11 BETA
#By Erik945
#Special thanks:  
#	Dazzy  -   for researching the skeleton structure
#
#
#Based on Gh0stblade's Tomb Raider script



#Options: These are bools that enable/disable certain features! They are global and affect ALL platforms!
#Var							Effect
#Misc
#Mesh Global
fDefaultMeshScale = 1.0 		#Override mesh scale (default is 1.0)
bOptimizeMesh = 0				#Enable optimization (remove duplicate vertices, optimize lists for drawing) (1 = on, 0 = off)
#bMaterialsEnabled = 1			#Materials (1 = on, 0 = off)
bRenderAsPoints = 0				#Render mesh as points without triangles drawn (1 = on, 0 = off)
#Vertex Components
bNORMsEnabled = 1				#Normals (1 = on, 0 = off)
bTANGsEnabled = 0				#Tangents (1 = on, 0 = off)
bUVsEnabled = 1					#UVs (1 = on, 0 = off)
bCOLsEnabled = 0				#Vertex colours (1 = on, 0 = off)
bSkinningEnabled = 1			#Enable skin weights (1 = on, 0 = off)
bDebugNormals = 0				#Debug normals as RGBA
bDebugTangents = 0				#Debug tangents as RGBA

CreateMeshWOUV = True
LoadOnlyLod1 = True
from inc_noesis import *
import math
import traceback

def registerNoesisTypes():
	handle = noesis.register("Marvel's Avengers 3D Mesh [PC]", ".mamesh")
	noesis.setHandlerTypeCheck(handle, meshCheckType)
	noesis.setHandlerLoadModel(handle, meshLoadModel)
	
	handle = noesis.register("Marvel's Avengers 3D Skeleton [PC]", ".maskl")
	noesis.setHandlerTypeCheck(handle, sklCheckType)
	noesis.setHandlerLoadModel(handle, sklLoadModel)
	
	handle = noesis.register("Marvel's Avengers 2D Texture [PC]", ".mapcd")
	noesis.setHandlerTypeCheck(handle, pcdCheckType)
	noesis.setHandlerLoadRGBA(handle, pcdLoadDDS2)
	
	#handle = noesis.register("Marvel's Avengers Material [PC]", ".material")
	#noesis.setHandlerTypeCheck(handle, matCheckType)
	#noesis.setHandlerLoadRGBA(handle, pcdLoadmat)
	
	noesis.logPopup()
	return 1

def sklCheckType(data):
	bs = NoeBitStream(data)
	uiMagic = bs.readUInt()
	
	if uiMagic == 0x0d:
		return 1
	else: 
		print("Fatal Error: Unknown file magic: " + str(hex(uiMagic) + " expected 'mesh'!"))
		return 0


def meshCheckType(data):
	bs = NoeBitStream(data)
	uiMagic = bs.readUInt()
	
	if uiMagic == 0x6873654e:
		return 1
	else: 
		print("Fatal Error: Unknown file magic: " + str(hex(uiMagic) + " expected 'mesh'!"))
		return 0

def pcdCheckType(data):
	bs = NoeBitStream(data)
	uiMagic = bs.readUInt()
	if   ((uiMagic & 0x0000ffff) == 0x0000c1cd):
		return 1
	else: 
		print("Fatal Error: Unknown file magic: " + str(hex(uiMagic) + " expected PCD!"))
		return 0

def matCheckType(data):
	bs = NoeBitStream(data)
	return 1


def pcdCheckType2(data):
	bs = NoeBitStream(data)
	uiMagic = bs.readUInt()
	if uiMagic == 0x207c1cd:
		return 1
	else: 
		print("Fatal Error: Unknown file magic: " + str(hex(uiMagic) + " expected PCD!"))
		return 0
	




def pcdLoadmat(data, texList):

	print("\n\n#############################################\n\n")
	texList2 = []
	bs = NoeBitStream(data)
	fsize = bs.getSize()
	print("fsize: " + str(hex(fsize) ))
	tex_index = 0

	#while(tex_index < 1):
		
	print("texture " + str(tex_index) + "		offset " +  str(hex(bs.tell())))
		
	uiDataSize1 = bs.readUInt()
	print("	uiDataSize1: " + str(hex(uiDataSize1) ))
	uiDataSize2 = bs.readUInt()
	print("	uiDataSize2: " + str(hex(uiDataSize2) ))
	uiDataSize3 = bs.readUInt()
	print("	uiDataSize3: " + str(hex(uiDataSize3) ))	
	uiDataSize4 = bs.readUInt()
	print("	uiDataSize4: " + str(hex(uiDataSize4) ))
	bs.seek(0x0c, NOESEEK_REL)	
	print("	offset1 " + str(tex_index) + "		offset " +  str(hex(bs.tell())))

	for i in range(uiDataSize1):
		str_ = "	" + str(i) + "	"
		for i in range(8):
			idata = bs.readUByte()
			if idata < 16 :	str_ =str_+ "0" + str(hex(idata))[2:] + "  "
			else: str_ = str_+  str(hex(idata))[2:]+ "  "
		print(str_)
	print("	offset2 " +   str(hex(bs.tell())))

	for i in range(uiDataSize3):
		str_ = "	" + str(i) + "	"

		for i in range(8):
			
			idata = bs.readUByte()
			if idata < 16 :	str_ =str_+ "0" + str(hex(idata))[2:] + "  "
			else: str_ = str_+  str(hex(idata))[2:]+ "  "
		
		bs.seek(-8, NOESEEK_REL)
		val1 = bs.readUInt()
		val2 = bs.readUInt()
		
		print (str_ + "		" + str(val1) + "		" + str(val2))
	print("	offset3 " +   str(hex(bs.tell())))
	offtest1 = bs.tell()
	if (offtest1 % 0x10 != 0):
		offtest1 = (offtest1 // 0x10) * 0x10 + 0x10
	bs.seek(offtest1, NOESEEK_ABS)
	print("	offset3s " +   str(hex(bs.tell())))
	toffset2 = bs.tell() + 0xE8
	
	str_ = "	" 
	for j in range(16):
		idata = bs.readUByte()
		if idata < 16 :	str_ =str_+ "0" + str(hex(idata))[2:] + "  "
		else: str_ = str_+  str(hex(idata))[2:]+ "  "
		
	print(str_)	
	str_ = "	" 
	for j in range(16):
		idata = bs.readUByte()
		if idata < 16 :	str_ =str_+ "0" + str(hex(idata))[2:] + "  "
		else: str_ = str_+  str(hex(idata))[2:]+ "  "
		
	print(str_)	
	str_ = "	" 
	for j in range(18):
		idata = bs.readUByte()
		if idata < 16 :	str_ =str_+ "0" + str(hex(idata))[2:] + "  "
		else: str_ = str_+  str(hex(idata))[2:]+ "  "
		
	print(str_)	


	for kkd in range(5):
		str_ = "	" 

		for j in range(12):
			idata = bs.readUByte()
			if idata < 16 :	str_ =str_+ "0" + str(hex(idata))[2:] + "  "
			else: str_ = str_+  str(hex(idata))[2:]+ "  "
			
		print(str_)	
		
	for kkd in range(8):
		str_ = "	" 

		for j in range(16):
			idata = bs.readUByte()
			if idata < 16 :	str_ =str_+ "0" + str(hex(idata))[2:] + "  "
			else: str_ = str_+  str(hex(idata))[2:]+ "  "
			
		print(str_)			
	
	bs.seek(toffset2, NOESEEK_ABS)
	
	print("\n")
	print("\n")
	for i in range(20):
		offst1_ = bs.tell()
		str_ = "	" + str(i) + "	offset:  " + str(hex(offst1_)) + "	"
		for j in range(16):
			idata = bs.readUByte()
			if idata < 16 :	str_ =str_+ "0" + str(hex(idata))[2:] + "  "
			else: str_ = str_+  str(hex(idata))[2:]+ "  "
			
		print(str_)	
		bs.seek(offst1_ + 8, NOESEEK_ABS)
		num1 = bs.readUByte()
		print( "		num: " +str(num1) )
		bs.seek(offst1_ + 16, NOESEEK_ABS)
		
		for l in range (num1):
			str_ = "		" + str(l) + "	offset:  " + str(hex(offst1_)) + "	"

			for k in range(28):
				idata = bs.readUByte()
				if idata < 16 :	str_ =str_+ "0" + str(hex(idata))[2:] + "  "
				else: str_ = str_+  str(hex(idata))[2:]+ "  "
	
			'''
			while True:
				cc1 = bs.readUByte()
				cc2 = bs.readUByte()
				cc3 = bs.readUByte()
				cc4 = bs.readUByte()
				if(cc1 * cc2 * cc3 * cc4 != 0): 
					break
					
				else:
					idata = cc1
					if idata < 16 :	str_ =str_+ "0" + str(hex(idata))[2:] + "  "
					else: str_ = str_+  str(hex(idata))[2:]+ "  "
					idata = cc2
					if idata < 16 :	str_ =str_+ "0" + str(hex(idata))[2:] + "  "
					else: str_ = str_+  str(hex(idata))[2:]+ "  "
					idata = cc3
					if idata < 16 :	str_ =str_+ "0" + str(hex(idata))[2:] + "  "
					else: str_ = str_+  str(hex(idata))[2:]+ "  "
					idata = cc4
					if idata < 16 :	str_ =str_+ "0" + str(hex(idata))[2:] + "  "
					else: str_ = str_+  str(hex(idata))[2:]+ "  "	
			bs.seek(-4, NOESEEK_REL)'''
			print(str_ )
		offtest1 = bs.tell()
		if (offtest1 % 0x8 != 0):
			offtest1 = (offtest1 // 0x8) * 0x8 + 0x8
		bs.seek(offtest1, NOESEEK_ABS)
		
		cc1 = bs.readUByte()
		cc2 = bs.readUByte()
		cc3 = bs.readUByte()
		cc4 = bs.readUByte()
		if(cc1 * cc2 * cc3 * cc4 == 0): 
			break
		else:
			bs.seek(-4, NOESEEK_REL)
			
		print("\n")
		
		
		
	offtest1 = bs.tell()
	if (offtest1 % 0x10 != 0):
		offtest1 = (offtest1 // 0x10) * 0x10 + 0x10
	bs.seek(offtest1, NOESEEK_ABS)
	
	print("	offset5 " +   str(hex(bs.tell())))




def pcdLoadDDS2(data, texList):
	try:
		print("\n\n#############################################\n\n")
		texList2 = []
		bs = NoeBitStream(data)
		fsize = bs.getSize()
		print("fsize: " + str(hex(fsize) ))
		tex_index = 0

		#while(tex_index < 1):
		while(bs.tell() + 0x28 < fsize):
			
			print("texture " + str(tex_index) + "		offset " +  str(hex(bs.tell())))
			
			uiMagic = bs.readUInt()
			print("	uiMagic: " + str(hex(uiMagic) ))
			
			uiPcdType = bs.readUInt()
			print("	uiPcdType: " + str(hex(uiPcdType) ))
			
			uiPcdLength = bs.readUInt()
			print("	uiPcdLength: " + str(hex(uiPcdLength) ))
			
			uiPcdUnk01 = bs.readUInt()
			print("	uiPcdUnk01: " + str(hex(uiPcdUnk01) ))
			
			uiPcdUnk02 = bs.readUInt()
			print("	uiPcdUnk02: " + str(hex(uiPcdUnk02) ))
			
			uiPcdUnk03 = bs.readUInt()
			print("	uiPcdUnk03: " + str(hex(uiPcdUnk03) ))		
			
			uiPcdWidth = bs.readUShort()
			print("	uiPcdWidth: " + str(hex(uiPcdWidth) ) + "  /  " + str((uiPcdWidth) ))
			uiPcdHeight = bs.readUShort()
			print("	uiPcdHeight: " + str(hex(uiPcdHeight) ) + "  /  " + str((uiPcdHeight) ))		
			
			uiPcdUnk04 = bs.readUInt()
			print("	uiPcdUnk04: " + str(hex(uiPcdUnk04) ))
			
			uiPcdUnk05 = bs.readUInt()
			print("	uiPcdUnk05: " + str(hex(uiPcdUnk05) ))
			
			uiPcdUnk06 = bs.readUInt()
			print("	uiPcdUnk06: " + str(hex(uiPcdUnk06) ))
			print("	Tex Header End: " + str(hex(bs.tell())))

			test_offset = bs.tell()
			add_val = 0
			bs.seek(uiPcdLength , NOESEEK_REL)
			
			while(True):
				if(bs.tell() + 1 >= fsize):
					break
				test_val = bs.readUInt()
				if   ((test_val & 0x0000ffff) == 0x0000c1cd):
					break
			
				add_val = add_val + 4
				
			print("	add_val " + str(hex(add_val)))
			bs.seek(test_offset + add_val, NOESEEK_ABS)
			
			bPcdData = None
			gPcdFmt = None
			print("	Tex Data Start: " + str(hex(bs.tell())))
			bPcdData = bs.readBytes(uiPcdLength)
			tex_start_offset = 0
			tex_end_offset  = uiPcdLength
			
			add_val1 = 0
			if(uiPcdLength != uiPcdUnk01):
				add_val1 = 1
			
			if uiPcdType == 0xffff:
				print("skip")
			
			elif uiPcdType == 0x23:#typeCORRECT
				if(add_val1 != 0): tex_start_offset = uiPcdLength - (uiPcdWidth * uiPcdHeight) * 4 
				print("	data buff from	" + str(hex(tex_start_offset)) + "	to "  + str(hex(tex_end_offset)))
				gPcdFmt = noesis.NOESISTEX_RGBA32
				bPcdData = rapi.imageDecodeRaw(bPcdData[tex_start_offset:tex_end_offset], uiPcdWidth, uiPcdHeight, "r16g16")			
				
			elif uiPcdType == 0x31:#typeCORRECT
				if(add_val1 != 0): tex_start_offset = uiPcdLength - (uiPcdWidth * uiPcdHeight) * 2
				print("	data buff from	" + str(hex(tex_start_offset)) + "	to "  + str(hex(tex_end_offset)))
				gPcdFmt = noesis.NOESISTEX_RGBA32
				bPcdData = rapi.imageDecodeRaw(bPcdData[tex_start_offset:tex_end_offset], uiPcdWidth, uiPcdHeight, "r8g8b0")
				
			elif uiPcdType == 0x38:#UNCORRECT, DONT WORK found only one
				if(add_val1 != 0): tex_start_offset = uiPcdLength - (uiPcdWidth * uiPcdHeight) // 1
				print("	data buff from	" + str(hex(tex_start_offset)) + "	to "  + str(hex(tex_end_offset)))
				gPcdFmt = noesis.NOESISTEX_RGBA32
				bPcdData = rapi.imageDecodeDXT(bPcdData[tex_start_offset:tex_end_offset], uiPcdWidth, uiPcdHeight, noesis.FOURCC_BC6S) 
				
			elif uiPcdType == 0x3d:#typeCORRECT
				if(add_val1 != 0): tex_start_offset = uiPcdLength - (uiPcdWidth * uiPcdHeight) // 1
				print("	data buff from	" + str(hex(tex_start_offset)) + "	to "  + str(hex(tex_end_offset)))
				gPcdFmt = noesis.NOESISTEX_RGBA32
				bPcdData = rapi.imageDecodeRaw(bPcdData[tex_start_offset:tex_end_offset], uiPcdWidth, uiPcdHeight, "a8")
				
			elif uiPcdType == 0x44:#typeCORRECT
				if(add_val1 != 0): tex_start_offset = uiPcdLength - (uiPcdWidth * uiPcdHeight) // 2
				print("	data buff from	" + str(hex(tex_start_offset)) + "	to "  + str(hex(tex_end_offset)))
				gPcdFmt = noesis.NOESISTEX_RGBA32
				bPcdData = rapi.imageDecodeDXT(bPcdData[tex_start_offset:tex_end_offset], uiPcdWidth, uiPcdHeight, noesis.FOURCC_BC1) 
				
			elif uiPcdType == 0x45:#typeCORRECT
				if(add_val1 != 0): tex_start_offset = uiPcdLength - (uiPcdWidth * uiPcdHeight) // 2
				print("	data buff from	" + str(hex(tex_start_offset)) + "	to "  + str(hex(tex_end_offset)))
				gPcdFmt = noesis.NOESISTEX_RGBA32
				bPcdData = rapi.imageDecodeDXT(bPcdData[tex_start_offset:tex_end_offset], uiPcdWidth, uiPcdHeight, noesis.FOURCC_DXT1) 
				
			elif uiPcdType == 0x4a:#typeCORRECT
				if(add_val1 != 0): tex_start_offset = uiPcdLength - (uiPcdWidth * uiPcdHeight) // 1
				print("	data buff from	" + str(hex(tex_start_offset)) + "	to "  + str(hex(tex_end_offset)))
				gPcdFmt = noesis.NOESISTEX_RGBA32
				bPcdData = rapi.imageDecodeDXT(bPcdData[tex_start_offset:tex_end_offset], uiPcdWidth, uiPcdHeight, noesis.FOURCC_BC3)
				
			elif uiPcdType == 0x4b:#typeCORRECT
				if(add_val1 != 0): tex_start_offset = uiPcdLength - (uiPcdWidth * uiPcdHeight) // 1
				print("	data buff from	" + str(hex(tex_start_offset)) + "	to "  + str(hex(tex_end_offset)))
				gPcdFmt = noesis.NOESISTEX_RGBA32
				bPcdData = rapi.imageDecodeDXT(bPcdData[tex_start_offset:tex_end_offset], uiPcdWidth, uiPcdHeight, noesis.FOURCC_DXT5)  
				
			elif uiPcdType == 0x4d:#typeCORRECT
				if(add_val1 != 0): tex_start_offset = uiPcdLength - (uiPcdWidth * uiPcdHeight) // 2
				print("	data buff from	" + str(hex(tex_start_offset)) + "	to "  + str(hex(tex_end_offset)))
				gPcdFmt = noesis.NOESISTEX_RGBA32
				bPcdData = rapi.imageDecodeDXT(bPcdData[tex_start_offset:tex_end_offset], uiPcdWidth, uiPcdHeight, noesis.FOURCC_BC4) 
				
			elif   uiPcdType == 0x50:#typeCORRECT
				if(add_val1 != 0): tex_start_offset = uiPcdLength - int((uiPcdWidth * uiPcdHeight) * 1)  
				print("	data buff from	" + str(hex(tex_start_offset)) + "	to "  + str(hex(tex_end_offset)))
				gPcdFmt = noesis.NOESISTEX_RGBA32
				bPcdData = rapi.imageDecodeDXT(bPcdData[tex_start_offset:tex_end_offset], uiPcdWidth, uiPcdHeight, noesis.FOURCC_BC5) #555555555555555555
				
			elif   uiPcdType == 0x54:#typeCORRECT
				if(add_val1 != 0): tex_start_offset = uiPcdLength - (uiPcdWidth * uiPcdHeight) * 4
				print("	data buff from	" + str(hex(tex_start_offset)) + "	to "  + str(hex(tex_end_offset)))
				bPcdData = bPcdData[tex_start_offset:tex_end_offset]
				gPcdFmt = noesis.NOESISTEX_RGBA32
				
			elif   uiPcdType == 0x57:#typeCORRECT
				if(add_val1 != 0): tex_start_offset = uiPcdLength - (uiPcdWidth * uiPcdHeight) * 4
				print("	data buff from	" + str(hex(tex_start_offset)) + "	to "  + str(hex(tex_end_offset)))
				bPcdData = bPcdData[tex_start_offset:tex_end_offset]
				gPcdFmt = noesis.NOESISTEX_RGBA32
				
			elif   uiPcdType == 0x5b:#typeCORRECT
				if(add_val1 != 0): tex_start_offset = uiPcdLength - (uiPcdWidth * uiPcdHeight) // 1
				print("	data buff from	" + str(hex(tex_start_offset)) + "	to "  + str(hex(tex_end_offset)))
				gPcdFmt = noesis.NOESISTEX_RGBA32
				bPcdData = rapi.imageDecodeDXT(bPcdData[tex_start_offset:tex_end_offset], uiPcdWidth, uiPcdHeight, noesis.FOURCC_BC6H)
				
			elif   uiPcdType == 0x5e:#typeCORRECT
				if(add_val1 != 0): tex_start_offset = uiPcdLength - (uiPcdWidth * uiPcdHeight) // 1
				print("	data buff from	" + str(hex(tex_start_offset)) + "	to "  + str(hex(tex_end_offset)))
				gPcdFmt = noesis.NOESISTEX_RGBA32
				bPcdData = rapi.imageDecodeDXT(bPcdData[tex_start_offset:tex_end_offset], uiPcdWidth, uiPcdHeight, noesis.FOURCC_BC7)	
				
			elif   uiPcdType == 0x5f:#typeCORRECT	
				if(add_val1 != 0): tex_start_offset = uiPcdLength - (uiPcdWidth * uiPcdHeight) // 1
				print("	data buff from	" + str(hex(tex_start_offset)) + "	to "  + str(hex(tex_end_offset)))
				gPcdFmt = noesis.NOESISTEX_RGBA32
				bPcdData = rapi.imageDecodeDXT(bPcdData[tex_start_offset:tex_end_offset], uiPcdWidth, uiPcdHeight, noesis.FOURCC_BC7) 
			'''	PYNOECONSTN(FOURCC_DXT1),
				PYNOECONSTN(FOURCC_DXT3),
				PYNOECONSTN(FOURCC_DXT5),
				PYNOECONSTN(FOURCC_DXT1NORMAL),
				PYNOECONSTN(FOURCC_ATI1),
				PYNOECONSTN(FOURCC_ATI2),
				PYNOECONSTN(FOURCC_DX10),
				PYNOECONSTN(FOURCC_BC1),
				PYNOECONSTN(FOURCC_BC2),
				PYNOECONSTN(FOURCC_BC3),
				PYNOECONSTN(FOURCC_BC4),
				PYNOECONSTN(FOURCC_BC5),
				PYNOECONSTN(FOURCC_BC6H),
				PYNOECONSTN(FOURCC_BC6S),
				PYNOECONSTN(FOURCC_BC7),
				
				
				
				
				
				PYNOECONSTN(NOESISTEX_UNKNOWN),
				PYNOECONSTN(NOESISTEX_RGBA32),
				PYNOECONSTN(NOESISTEX_RGB24),
				PYNOECONSTN(NOESISTEX_DXT1),
				PYNOECONSTN(NOESISTEX_DXT3),
				PYNOECONSTN(NOESISTEX_DXT5),'''

			if gPcdFmt != None:
				#ddsData = rapi.imageFlipRGBA32(bPcdData, uiPcdWidth, uiPcdHeight, 0, 1)
				texList2.append(NoeTexture("	Texture_" + str(tex_index), int(uiPcdWidth), int(uiPcdHeight), bPcdData, gPcdFmt))
			print("	Tex Data END: " + str(hex(bs.tell())))
			tex_index = tex_index + 1

		texList2 = texList2[::-1] 
		
		for tex in texList2:
			texList.append(tex)
	except Exception:
		traceback.print_exc()
	return 1





class LodInfo():
	def __init__(self):
		self.num = -1
		self.vertex_start = 0
		self.vertex_count = 0
		self.vertex_offset = 0
		self.face_start = 0
		self.face_count = 0
		self.face_offset = 0
		self.faceArray = []
		self.faceArrayB = []
		self.LodId = 0




class meshFile(object): 
	def __init__(self, data):
		self.inFile = NoeBitStream(data)
		self.meshGroupIdx = 0
		self.boneList = []
		self.matList = []
		self.texList = []
		self.matNames = []
		self.offsetMeshStart = 0
		self.lastModelIndex = 0
		self.Error_SKIN_glob = False
	def loadMeshFile(self, mdlList):
		ctx = rapi.rpgCreateContext()
		bs = self.inFile
		meshes = []
		meshesRapi = []
		vertArrayB = 0
		min_bones = 1000000
		max_bones  = 0
		ind_table = []
		
		#bs.seek(self.offsetMeshStart, NOESEEK_ABS)
		
		uiMagic = bs.readUInt()     # 
		print("\n\n\n\n#############################################\n#############################################\n#############################################\n\n")
		print("uiMagic: " + str(hex(uiMagic) ))
		
		uiUnk00 = bs.readUInt()     # XZ maybe version???
		print("uiUnk00: " + str(hex(uiUnk00) ))
		
		
		
		
		#bs.seek(0x1030 , NOESEEK_ABS)

		
		
		bs.seek(0x60 , NOESEEK_ABS)		
		
		usBlockRecords4 = bs.readUShort()
		print("usBlockRecords4: 	" + str(hex(usBlockRecords4) ) + "	//	" + str((usBlockRecords4) ))		
		
		usBlockRecords3 = bs.readUShort()
		print("usBlockRecords3: 	" + str(hex(usBlockRecords3) ) + "	//	" + str((usBlockRecords3) ))		
		
		usBonesCount = bs.readUShort()
		print("usBonesCount: 	" + str(hex(usBonesCount) ) + "	//	" + str((usBonesCount) ))		
		
		usBlockRecords = bs.readUShort()
		print("usBlockRecords: 	" + str(hex(usBlockRecords) ) + "	//	" + str((usBlockRecords) ))

		usUnk68 = bs.readUShort()
		print("usUnk68: 	" + str(hex(usUnk68) ) + "	//	" + str((usUnk68) ))


		bs.seek(0xf8 , NOESEEK_ABS)
		uiOffsetBR4 = bs.readUInt()
		print("uiOffsetBR4: 	" + str(hex(uiOffsetBR4) ) + "	//	" + str((uiOffsetBR4) ))
		
		bs.seek(0x118 , NOESEEK_ABS)
		uiFaceGlobOffset = bs.readUInt()
		print("uiFaceGlobOffset: 	" + str(hex(uiFaceGlobOffset) ) + "	//	" + str((uiFaceGlobOffset) ))		
		
		
		
		

		
		
		
		
		
		uiMeshFileSize = bs.readUInt()
		print("uiMeshFileSize: " + str(hex(uiMeshFileSize) ))

		uiUnk01 = bs.readUInt()
		print("uiUnk01: " + str(hex(uiUnk01) ))
		
		bs.seek(0xE8, NOESEEK_REL)#AABB MIN/MAX?
		
		uiOffsetMeshGroupInfo = bs.readUInt()
		uiUnk02 = bs.readUInt()
		
		uiOffsetMeshInfo = bs.readUInt()
		uiUnk03 = bs.readUInt()
		
		uiOffsetBoneMap = bs.readUInt()
		uiUnk04 = bs.readUInt()
		
		uiUnk05 = bs.readUInt()
		uiUnk06 = bs.readUInt()
		
		uiOffsetFaceData = bs.readUInt()
		uiUnk07 = bs.readUInt()
		
		usNumMeshGroups = bs.readUShort()
		usNumMesh = bs.readUShort()
		usNumBones = bs.readUShort()
		
		usNumMesh = 7
	



		bs.seek(0x130 , NOESEEK_ABS)
		print("BlockRecords Start: " + str(hex(bs.tell())))		
		for i in range(usBlockRecords):
				strm = ""
				for j in range (0x48):
					cbyte = str(hex(bs.readUByte()))[2:]
					if len(cbyte) == 1:
						cbyte = "0" + cbyte
					strm = strm + "  " + cbyte
				print(strm)
		print("BlockRecords End: " + str(hex(bs.tell())))	
		
		
		
		
		
		
		BlockRecords2Array = []
		
		print("BlockRecords2 Start: " + str(hex(bs.tell())))		
		for i in range(usBonesCount):
				uiTemp1 = bs.readUInt()
				BlockRecords2Array.append(uiTemp1)
				#print("uiTemp1: 	" + str(hex(uiTemp1) ) + "	//	" + str((uiTemp1) ))
				
		print("BlockRecords2 End: " + str(hex(bs.tell())))		
		
		
		
		

		
		CurFaceOffset = uiFaceGlobOffset
		print("BlockRecords3 Start: " + str(hex(bs.tell())))
		print("")		
		
		
		
		
		
		
		
		cf = bs.tell()
		
		
		
		
		
		
		
		
		
		
#class LodInfo():
#	def __init__(self):
#		vertex_start = 0
#		vertex_count = 0
#		vertex_offset = 0
#		face_start = 0
#		face_count = 0
#		face_offset = 0		
		
		LODS = []
		bs.seek(uiOffsetBR4 , NOESEEK_ABS)
		print("BlockRecords4 Start: " + str(hex(bs.tell())))		
		for i in range(usBlockRecords4): 
			cur_offset = bs.tell()
			
			
			strm = ""
			for j in range (0x70):
				cbyte = str(hex(bs.readUByte()))[2:]
				if len(cbyte) == 1:
					cbyte = "0" + cbyte
				strm = strm + "  " + cbyte
			print(strm)
			
			
			bs.seek(cur_offset + 12 , NOESEEK_ABS)
			uiFACE_START = bs.readUInt()
			print("		REC_LOD    uiFACE_START: 	" + str(hex(uiFACE_START) ) + "	//	" + str((uiFACE_START) ))
			uiFACE_COUNT = bs.readUInt()
			print("		REC_LOD    uiFACE_COUNT: 	" + str(hex(uiFACE_COUNT) ) + "	//	" + str((uiFACE_COUNT) ))
			uiVERTEX_COUNT = bs.readUInt()
			print("		REC_LOD    uiVERTEX_COUNT: 	" + str(hex(uiVERTEX_COUNT) ) + "	//	" + str((uiVERTEX_COUNT) ))	
			
			bs.seek(cur_offset + 4 * 0x0a , NOESEEK_ABS)
			uiLOD_ID = bs.readUInt()
			print("		REC_LOD    uiLOD_ID: 	" + str(hex(uiLOD_ID) ) + "	//	" + str((uiLOD_ID) ))	

			new_lod = LodInfo()
			new_lod.face_start = uiFACE_START
			new_lod.face_count = uiFACE_COUNT
			new_lod.vertex_count = uiVERTEX_COUNT
			new_lod.num = i
			new_lod.LodId = uiLOD_ID
			LODS.append(new_lod)
			bs.seek(cur_offset + 0x70, NOESEEK_ABS)		
			#print(strm)
			
			
			

			
			
			
		print("BlockRecords4 Start: 	" + str(hex(bs.tell())))
		
		
		
		
		
		
		
		
		
		
		
		# VERY DIRTY!!! Calculate size of number vertex for face and

		bs.seek(cf, NOESEEK_ABS)	
		uByteOfFaces = 4 
		GlobalNumberOfFaces = 0
		for i in range(usBlockRecords3):  
			uiArr1 = []
			for j in range(30):
				uiArr1.append(bs.readUInt())
			
			uVertexOfFace = uiArr1[8] // 0x10000
			GlobalNumberOfFaces = GlobalNumberOfFaces + (uiArr1[6] * uVertexOfFace)
		print("GlobalNumberOfFaces  " + str(GlobalNumberOfFaces))
		GlobalFaceSize = uiOffsetBR4 - uiFaceGlobOffset
		print("GlobalFaceSize  " + str(GlobalFaceSize))
		fs = GlobalFaceSize / GlobalNumberOfFaces 
		print("uByteOfFaces  " + str(fs))	
		if(fs < 3): uByteOfFaces = 2
		
		print("indices_table_offset " +str(hex(bs.tell())))
		indices_table_offset = bs.tell()
		for  ppp in range(usBonesCount):
			ind_table.append(bs.readUInt())
		
		
		
		
		
		bs.seek(cf, NOESEEK_ABS)		
		rapi.rpgSetStripEnder(0x1000000)		
				
				
				
				
				
		strm = ""		
		for j in range (0x78 // 4):
			cbyte = str(hex( j ))[2:]
			if len(cbyte) == 1:
				cbyte = "0" + cbyte
			strm = strm + "  " + cbyte	
			strm = strm + "  " + cbyte
			strm = strm + "  " + cbyte
			strm = strm + "  " + cbyte					
		print(strm)		                                                                                                                                                         
		print("                                                 | uiVertexCount |               |uiFaceLocOffset|  uiFaceCount  |               | uVertexOfFace|                |BoneTableOffset|               |uiVertexOffset1|                                                                                                               |uiVertexOffset2|                         ")
		for i in range(usBlockRecords3): 
				cur_offset = bs.tell()
				print(str(i))
				strm = ""
				for j in range (0x78):
					cbyte = str(hex(bs.readUByte()))[2:]
					if len(cbyte) == 1:
						cbyte = "0" + cbyte
					strm = strm + "  " + cbyte
				print(strm)
				bs.seek(cur_offset, NOESEEK_ABS)
				
				
				uiArr1 = []
				for j in range(30):
					uiArr1.append(bs.readUInt())
				
				uiVertexCount = uiArr1[3]
				print("REC_BASE    uiVertexCount: 	" + str(hex(uiVertexCount) ) + "	//	" + str((uiVertexCount) ))
				
				
				uiVertexOffset1 = uiArr1[12]				
				print("REC_BASE    uiVertexOffset1: 	" + str(hex(uiVertexOffset1) ) + "	//	" + str((uiVertexOffset1) ))
				print("REC_BASE    uiVertexOffset1C: 	" + str(hex(uiVertexOffset1 + cur_offset) ) + "	//	" + str((uiVertexOffset1 + cur_offset) ))
				uiVertexOffset2 = uiArr1[20]
				print("REC_BASE    uiVertexOffset2: 	" + str(hex(uiVertexOffset2) ) + "	//	" + str((uiVertexOffset2) ))
				print("REC_BASE    uiVertexOffset2C: 	" + str(hex(uiVertexOffset2 + cur_offset) ) + "	//	" + str((uiVertexOffset2 + cur_offset  ) ))

				
				uiFaceCount = uiArr1[6]
				print("REC_BASE    uiFaceCount: 	" + str(hex(uiFaceCount) ) + "	//	" + str((uiFaceCount) ))				
				uiFaceLocOffset = uiArr1[5]
				print("REC_BASE    uiFaceLocOffset: 	" + str(hex(uiFaceLocOffset) ) + "	//	" + str((uiFaceLocOffset) ))				
				uiBonesTableOffsetLocal = uiArr1[10]
				print("REC_BASE    uiBonesTableOffsetLocal: 	" + str(hex(uiBonesTableOffsetLocal) ) + "	//	" + str((uiBonesTableOffsetLocal) ))
				
				iDelta = uiVertexOffset1 - uiVertexOffset2
				print("REC_BASE    iDelta: 		" + str(hex(iDelta) ) + "	//	" + str((iDelta) ))
				iDeltaVal = uiArr1[7]
				print("REC_BASE    iDeltaVal: 	" + str(hex(iDeltaVal) ) + "	//	" + str((iDeltaVal) ))
				
				
				
				uVertexOfFace = uiArr1[8] // 0x10000
				print("REC_BASE    uVertexOfFace: 	" + str(hex(uVertexOfFace) ) + "	//	" + str((uVertexOfFace) ))
				uBoneTableSize = uiArr1[8] & 0x0000ffff
				print("REC_BASE    uBoneTableSize " + str(hex(uBoneTableSize)))
				

				
				bStandartFaceEncoding = True
				if(uiArr1[29] > 0 ): bSpecificEncoding = False
				
				uiFaceOffset = CurFaceOffset
				print("REC_BASE    uiFaceOffset: 	" + str(hex(uiFaceOffset) ) + "	//	" + str((uiFaceOffset) ))

				CurFaceOffset = CurFaceOffset + uiFaceCount * 12
				
				
				

				

					
				bs.seek(uiVertexOffset2 + 0x08, NOESEEK_ABS)
				usNumberRecords = bs.readUShort() # ???????
				print("REC_BASE    usNumberRecords: 	" + str(hex(usNumberRecords) ) + "	//	" + str((usNumberRecords) ))
				
				usVertexSizeT = bs.readUShort()
				print("REC_BASE    usVertexSizeT: 	" + str(hex(usVertexSizeT) ) + "	//	" + str((usVertexSizeT) ))
				#uByteOfFaces = 0x2
				
				print("REC_CALC    uByteOfFaces: 	" + str(hex(uByteOfFaces) ) + "	//	" + str((uByteOfFaces) ))


				
				uintUnk = bs.readUInt()
				
				position_offset = -1
				uv1_offset = -1
				uv2_offset = -1
				uv3_offset = -1
				uv4_offset = -1
				SkinWeights_offset = -1
				SkinIndices_offset = -1
				SkinWeights_size = 0
				SkinIndices_size = 0			
				if(True):
					
					vertex_format = []
					for ww in range(usNumberRecords):
						VertexEncoding = bs.read("1I1H2B")
						vertex_format.append(VertexEncoding)
						#uint   Type of data
						#short  Offset
						#byte	xxx
						#byte	xxx
					for ww in range(usNumberRecords):
						segment_size = 0;
						if((ww + 1) < len(vertex_format)):
							segment_size = vertex_format[ww+1 ][1] - vertex_format[ww][1]
						else:
							segment_size = usVertexSizeT - vertex_format[ww][1]
							
							
						str_ = str(hex(vertex_format[ww][0]) )
						if(vertex_format[ww][0] == 0xD2F7D823): 	
							str_ = str_ + "	Position	"
							position_offset = vertex_format[ww][1]
						if(vertex_format[ww][0] == 0x36F5E414): str_ = str_ + "	Normal	"
						if(vertex_format[ww][0] == 0x3E7F6149): str_ = str_ + "	TessellationNormal	"
						if(vertex_format[ww][0] == 0xF1ED11C3): str_ = str_ + "	Tangent	"
						if(vertex_format[ww][0] == 0x64A86F01): str_ = str_ + "	Binormal	"
						if(vertex_format[ww][0] == 0x9B1D4EA): str_ = str_ + "	PackedNTB	"		
						if(vertex_format[ww][0] == 0x48E691C0): 
							str_ = str_ + "	SkinWeights	"	
							SkinWeights_offset = vertex_format[ww][1]
							SkinWeights_size = segment_size
						if(vertex_format[ww][0] == 0x5156D8D3): 
							str_ = str_ + "	SkinIndices	"
							SkinIndices_offset = vertex_format[ww][1]
							SkinIndices_size = segment_size
						if(vertex_format[ww][0] == 0x7E7DD623): str_ = str_ + "	Color1	"		
						if(vertex_format[ww][0] == 0x733EF0FA): str_ = str_ + "	Color2	"
						
						if(vertex_format[ww][0] == 0x8317902A): 
							str_ = str_ + "	Texcoord1	"
							uv1_offset = vertex_format[ww][1]
						if(vertex_format[ww][0] == 0x8E54B6F3): 
							str_ = str_ + "	Texcoord2	"
							uv2_offset = vertex_format[ww][1]
						if(vertex_format[ww][0] == 0x8A95AB44): 
							str_ = str_ + "	Texcoord3	"
							uv3_offset = vertex_format[ww][1]
						if(vertex_format[ww][0] == 0x94D2FB41): 
							str_ = str_ + "	Texcoord4	"
							uv4_offset = vertex_format[ww][1]
						
						
							
						if(vertex_format[ww][0] == 0xE7623ECF): str_ = str_ + "	InstanceID	"						
						str_ = str_ + str(hex(vertex_format[ww][1]) ) + "	" + str(hex(vertex_format[ww][2]) ) + "	" + str(hex(vertex_format[ww][3])) + "		size " + str(hex(segment_size)) 
						print("VERT_RECORD        " + str_)
					
					vertex_block_offset = bs.tell()
					print("VERT_DATA  vertex_block_offset:	" + str(hex(vertex_block_offset) ))
					vertArray = []
					
					UvArray1 = []
					UvArray2 = []
					UvArray3 = []
					UvArray4 = []
					
					vertArrayB = []
					UvArrayB1 = []
					UvArrayB2 = []
					UvArrayB3 = []
					UvArrayB4 = []
					SkinWeights_array = []
					SkinIndices_array = []
					SkinIndices_array_real = []
					Error_SKIN = False
					
					bs.seek(vertex_block_offset + position_offset, NOESEEK_ABS)
					for vv in range(uiVertexCount):
					
						#x = bs.readFloat()						
						#z = -1.0 * bs.readFloat()
						#y =   bs.readFloat()
						#vertArray.append(NoeVec3((x, y, z)))
						
						
						x =   bs.readFloat()						
						y =   bs.readFloat()
						z =   bs.readFloat()
						vertArray.append(NoeVec3((x, y, z)))
						
						vertArrayB.append(x)
						vertArrayB.append(y)
						vertArrayB.append(z)
						#bs.seek(-0xC, NOESEEK_REL)
						#for vvv in range(12):
						#	vertArrayB2.append( bs.readUByte())
						bs.seek(usVertexSizeT - 0xC, NOESEEK_REL)
						#print(str(x)+ "	"+ str(y) +"	"+ str(z))
						
					UvArray1 = vertArray[:]
					UvArray2 = vertArray[:]
					UvArray3 = vertArray[:]
					UvArray4 = vertArray[:]
					
					
					if(uv1_offset >= 0):
						bs.seek(vertex_block_offset + uv1_offset, NOESEEK_ABS)
						for vv in range(uiVertexCount):
							x = bs.readShort() / 2048
							y = bs.readShort() / 2048
							UvArray1[vv] = NoeVec3((x, y, 0))								
							bs.seek(usVertexSizeT - 0x4, NOESEEK_REL)
							UvArrayB1.append(x)
							UvArrayB1.append(y)
							UvArrayB1.append(0)
							
					if(uv2_offset >= 0):
						bs.seek(vertex_block_offset + uv2_offset, NOESEEK_ABS)
						for vv in range(uiVertexCount):
							x = bs.readShort() / 2048
							y = bs.readShort() / 2048
							UvArray2[vv] = NoeVec3((x, y, 0))								
							bs.seek(usVertexSizeT - 0x4, NOESEEK_REL)
							UvArrayB2.append(x)
							UvArrayB2.append(y)
							UvArrayB2.append(0)

					if(uv3_offset >= 0):
						bs.seek(vertex_block_offset + uv3_offset, NOESEEK_ABS)
						for vv in range(uiVertexCount):
							x = bs.readShort() / 2048
							y = bs.readShort() / 2048
							UvArray3[vv] = NoeVec3((x, y, 0))								
							bs.seek(usVertexSizeT - 0x4, NOESEEK_REL)
							UvArrayB3.append(x)
							UvArrayB3.append(y)
							UvArrayB3.append(0)

					if(uv4_offset >= 0):
						bs.seek(vertex_block_offset + uv4_offset, NOESEEK_ABS)
						for vv in range(uiVertexCount):
							x = bs.readShort() / 2048
							y = bs.readShort() / 2048
							UvArray4[vv] = NoeVec3((x, y, 0))								
							bs.seek(usVertexSizeT - 0x4, NOESEEK_REL)
							UvArrayB4.append(x)
							UvArrayB4.append(y)
							UvArrayB4.append(0)							
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
					if(  (SkinIndices_offset >= 0)  and  (SkinWeights_offset >= 0)):
					
						
						bs.seek(uiBonesTableOffsetLocal, NOESEEK_ABS)
						print("SKIN_DATA    Bones Table Offset START: " + str(hex(bs.tell())))	
						bone_table_local = []
						for  qqq in range(uBoneTableSize):
							bone_table_local.append(bs.readUInt())
						print("SKIN_DATA    Bones Table Offset END:   " + str(hex(bs.tell())))	

						#SkinIndices_size: 0x8
						#SkinWeights_size: 0x4						
						uiBoneIndicisLenght = 0
						if(SkinWeights_size != 0):
							print("SKIN_DATA    SkinIndices_size: " + str(hex(SkinIndices_size)))
							print("SKIN_DATA    SkinWeights_size: " + str(hex(SkinWeights_size)))
							uiBoneIndicisLenght =  SkinIndices_size // SkinWeights_size
							print("SKIN_DATA    uiBoneIndicisLenght: " + str(hex(uiBoneIndicisLenght)))
							print("SKIN_DATA    number of bone_per_vertex1 " + str((SkinIndices_size // uiBoneIndicisLenght)))
							print("SKIN_DATA    number of bone_per_vertex2 " + str((SkinWeights_size )))  # more correct
						else:
							uiBoneIndicisLenght == 0
							print("SKIN_DATA    uiBoneIndicisLenght: " + str(hex(uiBoneIndicisLenght)))
							print("SKIN_DATA    number of bone_per_vertex1 UNCORRECT" )
							print("SKIN_DATA    number of bone_per_vertex2 UNCORRECT" )  # more correct
						
						
						
						bs.seek(vertex_block_offset + SkinIndices_offset, NOESEEK_ABS)
						min_bones = 1000000
						max_bones  = 0		
						for vv in range(uiVertexCount):
							str_1 = str(vv) + "	"
							for qds in range (SkinIndices_size // uiBoneIndicisLenght):
								v1 = 0
								if(uiBoneIndicisLenght == 1): v1 =  int(bs.readUByte())  
								if(uiBoneIndicisLenght == 2): v1 =  int(bs.readUShort())
								if(uiBoneIndicisLenght == 4): v1 =  int(bs.readUInt())									
								str_1 = str_1 + "	" + str((v1)) 
								SkinIndices_array.append(v1)
								if(v1 < min_bones): min_bones = v1
								if(v1 > max_bones): max_bones = v1
							bs.seek(usVertexSizeT - SkinIndices_size, NOESEEK_REL)
						print("SKIN_DATA    min_bones      " + str(hex(min_bones)))
						print("SKIN_DATA    max_bones      " + str(hex(max_bones )))
						
						
							 
						
						for vv in range(len(SkinIndices_array)):
							#if( SkinIndices_array[vv] < uBoneTableSize):
								SkinIndices_array_real.append(bone_table_local[SkinIndices_array[vv]])
							#else:
							#	#print("ES: " + str((hex(SkinIndices_array[vv]))))
							#	SkinIndices_array_real.append(bone_table_local[0])
							#	Error_SKIN = True
							#	self.Error_SKIN_glob = True

						
								


						#if((SkinWeights_offset >= 0)):		
						bs.seek(vertex_block_offset + SkinWeights_offset, NOESEEK_ABS)
						for vv in range(uiVertexCount):
							summ = 0
							for qds in range (SkinWeights_size ):
								v1 = float(bs.readUByte()) / 255.0
								SkinWeights_array.append(v1)
								summ = summ + v1
							#print("summ  " + str(summ))
							bs.seek(usVertexSizeT - SkinWeights_size, NOESEEK_REL)
					















					print("LODS_DATA")
					my_lods = []
					for lod in LODS:
						if(lod.face_start >= uiFaceLocOffset):
							if(lod.face_start < uiFaceLocOffset + uiFaceCount * uVertexOfFace):
								print("LODS_DATA    num: " + str(lod.num) + "	start " + str(hex(lod.face_start)))
								my_lods.append(lod)


					print("FACE_DATA    Go to faces: " + str(hex(uiFaceGlobOffset + uiFaceLocOffset * uByteOfFaces)))
					for lod in my_lods:	
						
						bs.seek(uiFaceGlobOffset + lod.face_start * uByteOfFaces, NOESEEK_ABS)
						print("FACE_DATA    Faces start: " + str(hex(bs.tell())))	
						
						vert_max = 0
						vert_min = 1000000000
						faceArray = []
						faceArrayB = []
						for ee in range (0,lod.face_count ):	
						
							if(uByteOfFaces == 4):
								if(uVertexOfFace == 3):
									v1 = bs.readUInt() 
									v2 = bs.readUInt() 
									v3 = bs.readUInt() 					
									#bs.seek( -0x8, NOESEEK_REL)						
									if((v1 < uiVertexCount ) and (v2 < uiVertexCount ) and (v3 < uiVertexCount )):
										faceArray.extend([v1, v2, v3])
										faceArrayB.append(int(v1))
										faceArrayB.append(int(v2))
										faceArrayB.append(int(v3))
								elif(uVertexOfFace == 4):
									v1 = bs.readUInt() 
									v2 = bs.readUInt() 
									v3 = bs.readUInt() 					
									#bs.seek( -0x8, NOESEEK_REL)						
									if((v1 < uiVertexCount ) and (v2 < uiVertexCount ) and (v3 < uiVertexCount )):
										faceArray.extend([v1, v2, v3])
										faceArrayB.append(int(v1))
										faceArrayB.append(int(v2))
										faceArrayB.append(int(v3))
									#v4 = bs.readUInt() 
									#v5 = bs.readUInt() 
									v6 = bs.readUInt() 
									if((v1 < uiVertexCount ) and (v2 < uiVertexCount ) and (v3 < uiVertexCount )):
										faceArray.extend([v1, v3, v6])
										faceArrayB.append(int(v1))
										faceArrayB.append(int(v3))
										faceArrayB.append(int(v6))
								else:
									v1 = bs.readUInt() 
									v2 = bs.readUInt() 
									v3 = bs.readUInt() 					
									#bs.seek( -0x8, NOESEEK_REL)						
									if((v1 < uiVertexCount ) and (v2 < uiVertexCount ) and (v3 < uiVertexCount )):
										faceArray.extend([v1, v2, v3])
										faceArrayB.append(int(v1))
										faceArrayB.append(int(v2))
										faceArrayB.append(int(v3))									

							if(uByteOfFaces == 2):
								if(uVertexOfFace == 3):
									v1 = bs.readUShort() 
									v2 = bs.readUShort() 
									v3 = bs.readUShort() 										
									if((v1 < uiVertexCount ) and (v2 < uiVertexCount ) and (v3 < uiVertexCount )):
										faceArray.extend([v1, v2, v3])
										faceArrayB.append(int(v1))
										faceArrayB.append(int(v2))
										faceArrayB.append(int(v3))										
								elif(uVertexOfFace == 4):
									v1 = bs.readUShort() 
									v2 = bs.readUShort() 
									v3 = bs.readUShort() 					
									if((v1 < uiVertexCount ) and (v2 < uiVertexCount ) and (v3 < uiVertexCount )):
										faceArray.extend([v1, v2, v3])
										faceArrayB.append(int(v1))
										faceArrayB.append(int(v2))
										faceArrayB.append(int(v3))									
									v6 = bs.readUShort() 
									if((v1 < uiVertexCount ) and (v2 < uiVertexCount ) and (v3 < uiVertexCount )):
										faceArray.extend([v1, v3, v6])
										faceArrayB.append(int(v1))
										faceArrayB.append(int(v3))
										faceArrayB.append(int(v6))									
								else:
									v1 = bs.readUShort() 
									v2 = bs.readUShort() 
									v3 = bs.readUShort() 					
									if((v1 < uiVertexCount ) and (v2 < uiVertexCount ) and (v3 < uiVertexCount )):
										faceArray.extend([v1, v2, v3])
										faceArrayB.append(int(v1))
										faceArrayB.append(int(v2))
										faceArrayB.append(int(v3))									

								
							if(v1 < vert_min): vert_min = v1
							if(v2 < vert_min): vert_min = v2
							if(v3 < vert_min): vert_min = v3
							
							if(v1 > vert_max): vert_max = v1
							if(v2 > vert_max): vert_max = v2
							if(v3 > vert_max): vert_max = v3
						lod.faceArray = faceArray[:]
						lod.faceArrayB = faceArrayB[:]
						print("FACE_DATA    Faces END:  " + str(hex(bs.tell())))	
						
#								new_lod = LodInfo()
#			new_lod.face_start = uiFACE_START
#			new_lod.face_count = uiFACE_COUNT
#			new_lod.vertex_count = uiVERTEX_COUNT
#			LODS.append(new_lod)
#			bs.seek(cur_offset + 0x70, NOESEEK_ABS)	
			

					
					
					

					print("FACE_DATA    vert_min  " + str(vert_min))
					print("FACE_DATA    vert_max  " + str(vert_max))
					

					
					
					
					
					
					
					for lod in my_lods:
						if((uv1_offset >= 0) or (uv2_offset >= 0) or (uv3_offset >= 0) or (uv4_offset >= 0)) or (CreateMeshWOUV): #vert_max < 0xffff):
						
						
							

							if((lod.LodId == 1) or (lod.LodId == 0) or(LoadOnlyLod1 == False)):
								print("CREATE_MESH    START")
								
								rapi.rpgSetName("mesh_" + str(i) + "__LOD" + str(lod.LodId) + "__group_" + str(lod.num) + "_f" + str(lod.face_count))
								#print(lod.faceArrayB)
								
								bVertBuf = struct.pack("<" + 'f'*len(vertArrayB), *vertArrayB)
								bFaceBuf = struct.pack("<" + 'I'*len(lod.faceArrayB), *lod.faceArrayB)
								
								
								print("CREATE_MESH    Create Vertices")
								rapi.rpgBindPositionBuffer(bVertBuf, noesis.RPGEODATA_FLOAT, 12)
								#rapi.rpgCommitTriangles(None, noesis.RPGEODATA_USHORT, uiVertexCount, noesis.RPGEO_POINTS, 0x1) # 
								if(uv1_offset >= 0):
									print("CREATE_MESH    Create UV1")
									bUVBuf = struct.pack("<" + 'f'*len(UvArrayB1), *UvArrayB1)
									rapi.rpgBindUV1Buffer(bUVBuf, noesis.RPGEODATA_FLOAT, 12)
								if(uv2_offset >= 0):
									print("CREATE_MESH    Create UV2")
									bUVBuf = struct.pack("<" + 'f'*len(UvArrayB2), *UvArrayB2)
									rapi.rpgBindUV2Buffer(bUVBuf, noesis.RPGEODATA_FLOAT, 12)
								if(uv3_offset >= 0):
									print("CREATE_MESH    Create UV3")
									bUVBuf = struct.pack("<" + 'f'*len(UvArrayB3), *UvArrayB3)
									rapi.rpgBindUV3Buffer(bUVBuf, noesis.RPGEODATA_FLOAT, 12)
								if(uv4_offset >= 0):
									print("CREATE_MESH    Create UV4")
									bUVBuf = struct.pack("<" + 'f'*len(UvArrayB4), *UvArrayB4)
									rapi.rpgBindUV4Buffer(bUVBuf, noesis.RPGEODATA_FLOAT, 12)
								
								
								rapi.rpgSetStripEnder(0x0fffffff)
								
								if((SkinWeights_offset >= 0) and (SkinIndices_offset >= 0)):
									print("CREATE_MESH    Create Skin")
									if (False): #Error_SKIN:
										print("\nCREATE_MESH  	ERROR_SKIN bone indicies\n")
									#print("number of bone_per_vertex1 " + str((SkinIndices_size // 2)))
									#print("number of bone_per_vertex2 " + str((SkinWeights_size )))								
									#rapi.rpgBindBoneWeightBufferOfs(weightBuff, noesis.RPGEODATA_FLOAT, 0x10, 0x0, 0x4)
									#rapi.rpgBindBoneIndexBufferOfs(vertexBuffers[entryData[iMeshBiIndex][3]], noesis.RPGEODATA_BYTE, vertexStrideInfo[entryData[iMeshBiIndex][3]], entryData[iMeshBiIndex][1], 0x4)										
									#rapi.rpgBindBoneIndexBufferOfs(weightIdx, noesis.RPGEODATA_UBYTE, 4, 0, 4)
									#rapi.rpgBindBoneWeightBufferOfs(self.vertBuff, noesis.RPGEODATA_FLOAT, self.vertLength, self.boneWeightOffset, 4)								
									#SkinIndices_arrayBuf= struct.pack("<" + 'H'*len(SkinIndices_array), *SkinIndices_array)							
									#rapi.rpgBindBoneIndexBufferOfs(SkinIndices_arrayBuf, noesis.RPGEODATA_USHORT, SkinIndices_size, 0, (SkinIndices_size//2))
									else:
										SkinIndices_arrayBuf= struct.pack("<" + 'I'*len(SkinIndices_array_real), *SkinIndices_array_real)						
										SkinWeights_arrayBuf= struct.pack("<" + 'f'*len(SkinWeights_array), *SkinWeights_array)
										print("CREATE_MESH    len SkinIndices_arrayBuf " + str((len(SkinIndices_arrayBuf))))
										print("CREATE_MESH    len SkinWeights_arrayBuf " + str((len(SkinWeights_arrayBuf))))
										rapi.rpgBindBoneIndexBufferOfs(SkinIndices_arrayBuf, noesis.RPGEODATA_UINT, SkinWeights_size * 4, 0, SkinWeights_size)		
										rapi.rpgBindBoneWeightBufferOfs(SkinWeights_arrayBuf, noesis.RPGEODATA_FLOAT, SkinWeights_size * 4, 0, SkinWeights_size)
								
								print("CREATE_MESH    Create Faces")
								
								
								
								
								rapi.rpgCommitTriangles(bFaceBuf, noesis.RPGEODATA_INT, len(lod.faceArrayB) , noesis.RPGEO_TRIANGLE, 1)


								rapi.rpgClearBufferBinds()





						else:
							print("CREATE_MESH  		MESH W/O UV CHANNELS, SKIPPED")
							
							
						

					




					

					faceArray = []
					vertArray = []
						
					



					
				
				
				
				
				

				bs.seek(cur_offset + 0x78 , NOESEEK_ABS)
				#print("")
				print("")
		print("BlockRecords3 End: " + str(hex(bs.tell())))






	
		print("File END:			" + str(hex(bs.getSize())))	




		#mdl = rapi.rpgConstructModel()
		#mdl = rapi.rpgConstructModelSlim()
		#mdlList.append(mdl)
		
	

				
	def buildSkeleton2(self, skelFileName):
			
		if (rapi.checkFileExists(skelFileName)):
			print("\n\nSKELETON FILE DETECTED")
			print("Building Skeleton....")
			
			sd = rapi.loadIntoByteArray(skelFileName)
			
			sd = NoeBitStream(sd)
			sd.seek(0x00, NOESEEK_ABS)
			uiMagic = sd.readUInt()     # 
			print("uiMagic  (need 0x0D):  " + str(hex(uiMagic) ))
			
			
			sd.seek(0x18, NOESEEK_ABS)
			UnkBluckSize = sd.readUInt()
			print("UnkBluckSize: " + str(hex(UnkBluckSize) ))
			print("UNK1")
			for i in range(13):
				uiUnkVal1_1 = sd.readUInt()
				uiUnkVal1_2 = sd.readUInt()
				#print(str(i) + "	||	" + str(hex( uiUnkVal1_1  ) )   + "		" +     str(hex( uiUnkVal1_2  ) )         )
			print("UNK2")
			
			for i in range(UnkBluckSize):
				uiUnkVal1_1 = sd.readUInt()
				uiUnkVal1_2 = sd.readUInt()
				#print(str(i) + "	||	" + str(hex( uiUnkVal1_1  ) )   + "		" +     str(hex( uiUnkVal1_2  ) )         )
			
			print("UnkBluck END: " +   str(hex(sd.tell()))   )
			
			# DIRTY HOOK
			test_val = sd.readUInt()
			while(test_val > 0):
				test_val = sd.readUInt()
			print("Bones Block Start: " +   str(hex(sd.tell()))   )
			sd.seek(0xAC, NOESEEK_REL)
			
			#sd.seek(0x12C + 0x1c - 8 + numData * 8, NOESEEK_ABS)
			print("NumBonesOffset: " + str(hex(sd.tell()) ))
			uiNumBones = sd.readUInt()
			print ("num bones: " + str(uiNumBones))
			
			if uiNumBones > 0:
				for i in range(uiNumBones):
					sd.seek(0x1C, NOESEEK_REL)
					mat = NoeMat44.fromBytes(sd.readBytes(64)).toMat43()
					iBonePID = sd.readInt()
					self.boneList.append(NoeBone(i, "bone%03i"%i, mat, None, iBonePID))
			print("BUILD SKELETON END!")
		
		
def meshLoadModel(data, mdlList):
	ctx = rapi.rpgCreateContext()
	mesh = meshFile(data)
	mesh.loadMeshFile(mdlList)
	

	skelFileName = rapi.getDirForFilePath(rapi.getInputName()) + "skeleton.maskl"
	
	mesh.buildSkeleton2(skelFileName)

	try:
		mdl = rapi.rpgConstructModelSlim()
	except:
		mdl = NoeModel()
	mdl.setBones(mesh.boneList)
	'''
	
	mdl.setModelMaterials(NoeModelMaterials(mesh.texList, mesh.matList))
	
	'''
	mdlList.append(mdl);
	return 1
	
	
	
	
def sklLoadModel(data, mdlList):
	ctx = rapi.rpgCreateContext()
	mesh = meshFile(data)
	
	
	mesh.buildSkeleton2(rapi.getInputName())

	try:
		mdl = rapi.rpgConstructModelSlim()
	except:
		mdl = NoeModel()
	mdl.setBones(mesh.boneList)
	'''
	
	mdl.setModelMaterials(NoeModelMaterials(mesh.texList, mesh.matList))
	
	'''
	mdlList.append(mdl);
	if(mesh.Error_SKIN_glob):
		print(print("\n	ERROR_SKIN bone indicies\n"))
	return 1	