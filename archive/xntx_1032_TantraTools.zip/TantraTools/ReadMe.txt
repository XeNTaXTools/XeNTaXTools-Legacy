
EXE List

TantraParam2Csv.exe : TantraParam.tpa(server and client) -> CsvFile -> TantraParam.tpa(server and client)
ClientRes2Csv.exe : ClientRes.txl -> CsvFile -> ClientRes.txl
fxPC2Csv.exe : fxPC.txl -> CsvFile -> fxPC.txl
hpk2Files.exe : hpkFile -> CsvFile and Files -> hpkFile
HTMessage2Csv.exe : HTMessage.txl -> CsvFile

I write the explanation in Japanese.
Because I can't speak English very much. 

GoodLuck.
