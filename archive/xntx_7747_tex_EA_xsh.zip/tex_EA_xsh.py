# EA XSH (XBOX) xsh images Loader by Bigchillghost
from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("EA XSH (XBOX)", ".xsh")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
	#noesis.logPopup()
	return 1

#check if it's this type based on the data
def noepyCheckType(data):
	bs = NoeBitStream(data)
	Magic = bs.readUInt()
	if Magic != 0x58504853:
		return 0
	return 1
	
def noepyLoadRGBA(data, texList):
	bs = NoeBitStream(data)
	bs.seek(0x70, NOESEEK_ABS)
	pixelTotalSize = bs.readUInt()
	fmtFlag = pixelTotalSize & 0xFF
	pixelTotalSize >>= 8
	imgWidth = bs.readUShort()
	imgHeight = bs.readUShort()
	bs.seek(0x80, NOESEEK_ABS)
	pixelSize = imgWidth*imgHeight*4
	pixelData = bs.readBytes(pixelSize)
	pixelData = rapi.imageToMortonOrder(pixelData, imgWidth, imgHeight, 4, 1)
	pixelData = rapi.imageDecodeRaw(pixelData, imgWidth, imgHeight, "b8 g8 r8 a8")
	texFmt = noesis.NOESISTEX_RGBA32
	texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, pixelData, texFmt))
	return 1
