import newGameLib
reload(newGameLib)
from newGameLib import *
import Blender	

		

def gmdParser(filename,g):
	g.endian='>'
	g.seek(18)
	g.word(30)
	A=g.i(28)
	g.f(12)
	g.i(6)
	
	
	boneNameList=[]
	g.seek(A[20])
	for m in range(A[21]):
		g.H(1)[0]
		boneNameList.append(g.word(30))
	
	g.seek(A[0])
	skeleton=Skeleton()
	skeleton.ARMATURESPACE=True
	skeleton.name='poseskeleton'
	skeleton.NICE=True
	for m in range(A[1]):
		bone=Bone()		
		t=g.tell()
		B=g.i(8)
		bone.B=B
		bone.children=[B[1]]
		posMatrix=VectorMatrix(g.f(3))
		g.f(1)
		rotMatrix=QuatMatrix(g.f(4)).resize4x4()
		parentMatrix=rotMatrix*posMatrix
		g.f(4)
		posMatrix=VectorMatrix(g.f(3))
		g.f(1)
		rotMatrix=QuatMatrix(g.f(4)).resize4x4()
		matrix=rotMatrix*posMatrix
		bone.matrix=matrix
		C=g.i(5)
		bone.name=boneNameList[B[6]]
		g.seek(t+128)
		skeleton.boneList.append(bone)
		
	for i,bone in enumerate(skeleton.boneList):
		#g.logWrite(str(bone.B)+'    '+bone.name)
		for boneID in bone.children:
			if boneID!=-1:
				child=skeleton.boneList[boneID]
				child.parentID=i
				last=i
			#else:
			#	bone.parentID=last
	skeleton.draw()
	
	g.seek(A[16])
	texList = []
	for m in range(A[17]):
		id = g.H(1)[0]
		name = g.word(30)
		texList.append(name)
		
	matList=[]	
	g.seek(A[6])
	for m in range(A[7]):
		matInfo = g.h(32)
		matInfo2 = g.f(16)
		mat=Mat()
		if matInfo[17] != -1:
			name=texList[matInfo[17]] + ".dds"
			mat.diffuse=g.dirname+os.sep+name
		matList.append(mat)

	meshList=[]
	for m in range(A[13]):
		mesh=Mesh()
		mesh.localMatList={}
		mesh.localBoneMap={}
		#mesh.SPLIT=True
		mesh.TRIANGLE=True
		meshList.append(mesh)
		
		
	g.seek(A[26])
	boneMap=g.B(A[27])
		
		
	indiceList = []
	g.seek(A[4])
	for m in range(A[5]):
		B = g.i(16)
		mesh=meshList[B[2]]
		t=g.tell()
		g.seek(A[22]+B[5]*2)			
		list=g.H(B[4])
			
		mat=Mat()
		mat.diffuse=matList[B[1]].diffuse
		mat.TRIANGLE=True
		mat.IDStart=len(mesh.indiceList)
		mat.IDCount=len(list)
		mesh.indiceList.extend(list)
		mesh.matList.append(mat)			

		skin=Skin()
		skin.boneMap=boneMap[B[11]:B[11]+B[10]+1][1:]
		mesh.skinList.append(skin)
		
		if max(list)<0:
			print A[22]+B[5]*2,B[2],max(list)
		g.seek(t)
		
	
	g.seek(A[12])
	for m in range(A[13]):
		B=g.i(2)
		C=g.b(8)
		D=g.i(4)
		mesh=meshList[B[0]]
		t=g.tell()
		g.seek(A[14]+D[0])
		for n in range(B[1]):
			tn=g.tell()
			mesh.vertPosList.append(g.f(3))
			mesh.skinWeightList.append(g.B(4))
			mesh.skinIndiceList.append(g.B(4))
			mesh.skinIDList.append([0]*len(mesh.matList))
			if C[3]==4:
				g.seek(tn+D[2]-4)
				mesh.vertUVList.append(g.half(2))
			if C[3]==68:
				g.seek(tn+D[2]-8)
				mesh.vertUVList.append(g.half(2))
			g.seek(tn+D[2])
		g.seek(t)
		for i,mat in enumerate(mesh.matList):
			for n in range(mat.IDStart,mat.IDStart+mat.IDCount):
				id=mesh.indiceList[n]
				mesh.skinIDList[id][i]=1
		
		
	for mesh in meshList:
		mesh.SPLIT=True
		mesh.BINDSKELETON=skeleton.name	
		mesh.boneNameList=skeleton.boneNameList
		mesh.draw()
		
	g.seek(A[10])
	skeleton=Skeleton()
	skeleton.ARMATURESPACE=True
	skeleton.name='bindskeleton'
	skeleton.NICE=True
	for m in range(A[11]):
		bone=Bone()
		bone.matrix=Matrix4x4(g.f(16)).invert()
		skeleton.boneList.append(bone)
	skeleton.draw()	
	

def Parser():	
	filename=input.filename
	print
	print filename
	print
	
	ext=filename.split('.')[-1].lower()	
	
	
	if ext=='gmd':
		file=open(filename,'rb')
		g=BinaryReader(file)
		gmdParser(filename,g)
		file.close()
 
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
	 
Blender.Window.FileSelector(openFile,'import','Yakuza 4 PS3 files: *.gmd ') 