#by Durik256 for xentax
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("miami vice(PSP)", ".unk")
    noesis.setHandlerTypeCheck(handle, CheckType)
    noesis.setHandlerLoadModel(handle, LoadModel)
    return 1

def CheckType(data):
    return 1
    
def LoadModel(data, mdlList):
    bs = NoeBitStream(data)
    ctx = rapi.rpgCreateContext()
    
    try:
        bs.seek(4)
        unk = bs.readInt()
            
        vnum, inum = bs.readInt(), bs.readInt()
        
        if unk < 10: unk = unk*16
        else: unk = 4
        bs.seek(unk, 1)
        
        vbuf = bs.readBytes(vnum*32)
        ibuf = bs.readBytes(inum*2)
        
        rapi.rpgBindPositionBufferOfs(vbuf, noesis.RPGEODATA_FLOAT, 32, 20)
        rapi.rpgBindUV1Buffer(vbuf, noesis.RPGEODATA_FLOAT, 32)
        rapi.rpgCommitTriangles(ibuf, noesis.RPGEODATA_USHORT, inum, noesis.RPGEO_TRIANGLE_STRIP)
        
        mdl = rapi.rpgConstructModel()
        rapi.setPreviewOption("setAngOfs", "0 90 -90")
    except:
        mdl = NoeModel()
        print("Error model, dont have mesh?")
    
    mdlList.append(mdl)
    return 1