from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Marvel Avengers Academy [iOS/Android]", ".ccz")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1
   
def noepyCheckType(data):
    bs = NoeBitStream(data)
    if bs.readBytes(4) != b'\x43\x43\x5A\x21': return 0
    return 1
    
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data, NOE_BIGENDIAN)
    bs.seek(0x0C, NOESEEK_ABS)         
    decompSize = bs.readUInt()
    compSize = bs.getSize() - bs.tell()
    data = bs.readBytes(compSize)
    data2 = rapi.decompInflate(data, decompSize)
    
    fileName = rapi.getLocalFileName(rapi.getInputName()).lower()    
    if ".astc.ccz" in fileName:
        texList.append(rapi.loadTexByHandler(data2, ".astc"))    
    elif ".pvr.ccz" in fileName:
        texList.append(rapi.loadTexByHandler(data2, ".pvr"))
    return 1
    
    
    




        
