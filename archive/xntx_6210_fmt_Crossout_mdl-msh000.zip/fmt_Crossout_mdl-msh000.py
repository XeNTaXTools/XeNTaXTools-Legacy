from inc_noesis import *
import noesis
import rapi

def registerNoesisTypes():
    handle = noesis.register("Crossout", ".mdl-msh000;.mdl-msh001;.mdl-msh002;.mdl-msh003;.mdl-msh004;.mdl-msh005;.mdl-msh006;.mdl-msh007;.mdl-msh008;.mdl-msh009")
    noesis.setHandlerTypeCheck(handle, noeCheckGeneric)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)
    #noesis.logPopup()
    return 1

def noepyLoadModel(data, mdlList):
    ctx = rapi.rpgCreateContext()
    rapi.rpgSetOption(noesis.RPGOPT_TRIWINDBACKWARD, 1)  #flip normals
    rapi.setPreviewOption("setAngOfs","0 290 130")       #sets the default preview angle        
    bs = NoeBitStream(data)
    version = bs.readInt()
    print(version, ":version")
    if version == 0:
        bs.seek(0x08, NOESEEK_ABS)
        VBytes = bs.readInt()                                
        print(VBytes, ":vbytes")
        VCount = bs.readInt()                                
        FCount = bs.readInt()                                
        bs.seek(0x44, NOESEEK_ABS)
        VBuf = bs.readBytes(VCount * VBytes)
        rapi.rpgBindPositionBufferOfs(VBuf, noesis.RPGEODATA_FLOAT, VBytes, 0)
        rapi.rpgBindUV1BufferOfs(VBuf, noesis.RPGEODATA_FLOAT, VBytes, 20)
        IBuf = bs.readBytes(FCount * 2)                           
        rapi.rpgCommitTriangles(IBuf, noesis.RPGEODATA_SHORT, FCount, noesis.RPGEO_TRIANGLE, 1)
        mdl = rapi.rpgConstructModel()                                                         
        mdlList.append(mdl)
        rapi.rpgClearBufferBinds()
        return 1
    elif version == 3:
        bs.seek(0x3f, NOESEEK_ABS)
        VBytes = bs.readByte()
        print(VBytes, ":vbytes")
        skip = bs.readInt() 
        VCount = bs.readInt()
        FCount = bs.readInt()                                
        bs.seek(0xb0, NOESEEK_ABS)
        VBuf = bs.readBytes(VCount * VBytes)
        rapi.rpgBindPositionBufferOfs(VBuf, noesis.RPGEODATA_FLOAT, VBytes, 0)
        rapi.rpgBindUV1BufferOfs(VBuf, noesis.RPGEODATA_FLOAT, VBytes, 28)
        IBuf = bs.readBytes(FCount * 2)                           
        rapi.rpgCommitTriangles(IBuf, noesis.RPGEODATA_SHORT, FCount, noesis.RPGEO_TRIANGLE, 1) 
        mdl = rapi.rpgConstructModel()                                                          
        mdlList.append(mdl)
        rapi.rpgClearBufferBinds()
        return 1
    elif version == 18:
        bs.seek(0xc, NOESEEK_ABS)
        VBytes = bs.readUInt()
        print(VBytes, ":vbytes")
        VCount = bs.readInt()
        FCount = bs.readInt()                                
        bs.seek(0x34, NOESEEK_ABS)
        VBuf = bs.readBytes(VCount * VBytes)
        rapi.rpgBindPositionBufferOfs(VBuf, noesis.RPGEODATA_FLOAT, VBytes, 0)
        rapi.rpgBindUV1BufferOfs(VBuf, noesis.RPGEODATA_FLOAT, VBytes, 32)
        IBuf = bs.readBytes(FCount * 2)                           
        rapi.rpgCommitTriangles(IBuf, noesis.RPGEODATA_SHORT, FCount, noesis.RPGEO_TRIANGLE, 1) 
        mdl = rapi.rpgConstructModel()                                                          
        mdlList.append(mdl)
        rapi.rpgClearBufferBinds()
        return 1
   