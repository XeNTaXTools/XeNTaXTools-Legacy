#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <string.h>
#include <tchar.h>
#include "minilzo.h"

int main(int argc, char *argv[]){
FILE *fl, *fout;
lzo_uint packed, unpacked, flsize, nm;
lzo_byte *p, *u;
char *s;
  printf("Beyond Good & Evil .BIN unpacker v1.1\n(c) -=CHE@TER=- 2008\n\n");
  if(argc != 2){
    printf("Usage: bin2unp filename.bin\n");
    return(1);
  }
  fl = fopen(argv[1], "rb");
  if(fl == NULL){
    printf("Can\'t open input file.\n");
    return(2);
  }
  s = (char *)malloc(strlen(argv[1])+1);
  strcpy(s, argv[1]);
  fread(&flsize, 1, 4, fl);
  flsize = flsize + 4;
  printf("File size: %d\n", flsize);
  nm = 0;
  while(!feof(fl)){
    fread(&unpacked, 1, 4, fl);
    fread(&packed, 1, 4, fl);
    if(unpacked == 0){ break; }
    p = malloc(packed);
    u = malloc(unpacked);
    fread(&p[0], 1, packed, fl);
    printf("Packed: %d\nUnpacked: %d\n", packed, unpacked);
    lzo1x_decompress_safe(&p[0], packed, &u[0], &unpacked, NULL);
    sprintf(&s[strlen(s)-3], "%.3d", nm);
    printf("%s", s);
    fout = fopen(s, "wb");
    fwrite(&u[0], 1, unpacked, fout);
    fclose(fout);
    printf(" [ok]\n");
    free(u);
    free(p);
    nm++;
  }
  free(s);
  fclose(fl);
  printf("Total file(s): %d\n", nm);
  return(0);
}
