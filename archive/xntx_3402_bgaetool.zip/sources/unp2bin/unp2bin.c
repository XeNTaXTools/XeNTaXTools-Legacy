#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <math.h>
#include <string.h>
#include <tchar.h>
#include "minilzo.h"

int main(int argc, char *argv[]){
FILE *fl, *fout;
lzo_uint packed, unpacked, flsize, calcsize, nm;
lzo_byte *p, *u;
char *bf, *s;
  printf("Beyond Good & Evil .BIN packer v1.1\n(c) -=CHE@TER=- 2008\n\n");
  if(argc != 2){
    printf("Usage: unp2bin filename.###\n");
    return(1);
  }
  s = (char *)malloc(strlen(argv[1])+1);
  strcpy(s, argv[1]);
  sprintf(&s[strlen(s)-3], "%s", "bin");
  flsize = 4;
  fout = fopen(s, "wb+");
  fwrite(&flsize, 1, 4, fout);
  nm = 0;
  do{
    sprintf(&s[strlen(s)-3], "%.3d", nm);
    fl = fopen(s, "rb");
    if(fl == NULL){
      break;
    }
    fseek(fl, 0, SEEK_END);
    unpacked = ftell(fl);
    fseek(fl, 0, SEEK_SET);
    packed = unpacked;
    p = malloc(unpacked);
    u = malloc(unpacked);
    fread(&u[0], 1, unpacked, fl);
    bf = (char *)malloc(unpacked);
    lzo1x_1_compress(&u[0], unpacked, &p[0], &packed, bf);
    free(bf);
    printf("File: %s\nPacked: %d\nUnpacked: %d\n", s, packed, unpacked);
    fwrite(&unpacked, 1, 4, fout);
    fwrite(&packed, 1, 4, fout);
    fwrite(&p[0], 1, packed, fout);
    free(u);
    free(p);
    fclose(fl);
    flsize = flsize + (packed+8);
    nm++;
  }while(nm != 0);
  calcsize = (ceil(flsize/2048.0)*2048) - flsize;
  bf = (char *)malloc(calcsize);
  memset(bf, 0, calcsize);
  fwrite(&bf[0], 1, calcsize, fout);
  free(bf);
  flsize = flsize-4+calcsize;
  fseek(fout, 0, SEEK_SET);
  fwrite(&flsize, 1, 4, fout);
  fclose(fout);
  free(s);
  printf("Total file(s): %d\n", nm);
  return(0);
}
