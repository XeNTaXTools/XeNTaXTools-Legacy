import newGameLib
from newGameLib import *
import Blender	

BINDPOSEFLAG=1


def n2pkParser(filename,g):
	g.word(g.i(1)[0]*2)
	g.B(2)
	t=g.tell()
	off=g.i(1)[0]
	g.B(4)
	g.seek(t+off)
	g.i(2)
	for m in range(g.i(1)[0]):		
		g.B(4)
		name=g.word(g.i(1)[0]*2)
		new=open(g.dirname+os.sep+name,'wb')
		g.B(2)
		v=g.i(4)
		t=g.tell()
		g.seek(44+v[0])
		data=g.read(v[2])
		new.write(data)
		new.close()
		ext=name.split('.')[-1].lower()
		g.seek(t)
		
	
def parseVertex(g):	
	t=g.tell()
	list0.append(g.f(3))
	if vertex_type==12:
		a=g.B(4)
		b=g.B(4)
		list3.append([a[1],a[2],a[0],a[3]])
		list4.append([b[1],b[0],b[2],b[3]])
		g.seek(t+24)
		list2.append(g.half(2))
		g.seek(t+36)
	elif vertex_type==11:
		a=g.B(4)
		b=g.B(4)
		list3.append([a[1],a[2],a[0],a[3]])
		list4.append([b[1],b[0],b[2],b[3]])
		g.seek(t+24)
		list2.append(g.half(2))
		g.seek(t+28)
	elif vertex_type==10:
		a=g.B(4)
		b=g.B(4)
		waga=a[0]+a[1]+a[2]+a[3]
		if waga!=255:print 'WARNING:waga'
		list3.append([a[1],a[2],a[0],a[3]])
		list4.append([b[1],b[0],b[2],b[3]])
		g.seek(t+24)
		list2.append(g.half(2))
		g.seek(t+36)
	elif vertex_type==8:
		a=g.B(4)
		b=g.B(4)
		list3.append([a[1],a[2],a[0],a[3]])
		list4.append([b[1],b[0],b[2],b[3]])
		g.seek(t+24)
		list2.append(g.half(2))
		g.seek(t+36)
	elif vertex_type==4:g.seek(t+16),list2.append(g.half(2)),g.seek(t+28)
	elif vertex_type==16:g.seek(t+16),list2.append(g.half(2)),g.seek(t+36) 
	elif vertex_type==6:g.seek(t+16),list2.append(g.half(2)),g.seek(t+32)
	elif vertex_type==14:g.seek(t+16),list2.append(g.half(2)),g.seek(t+32)
	elif vertex_type==7:g.seek(t+16),list2.append(g.half(2)),g.seek(t+28)
	elif vertex_type==3:g.seek(t+16),list2.append(g.half(2)),g.seek(t+20)
	elif vertex_type==13:g.seek(t+16),list2.append(g.half(2)),g.seek(t+24)
	else:
		pass
		print 'WARNING:',vertex_type
	
	
def lodParser(g):
	global list0,list1,list2,list3,list4
	v=g.i(2)
	submeshCount=g.i(1)[0];
	submeshList=[]
	print ' '*12,'submesh count:',submeshCount
	print ' '*12,'total vert count:',v[0]
	print ' '*12,'total face count:',v[0]
	for m in range(submeshCount):
		print ' '*16,'submeshID:',m
		v1=g.i(1)[0]
		v0=g.i(4)
		print ' '*16,v1,v0
		submeshList.append(v0)
	g.tell()	
	g.debug=False
	list0,list1,list2,list3,list4=[],[],[],[],[]
	for m in range(v[0]):parseVertex(g)
	for m in range(v[1]):
		if v[0]>58180:list1.append(g.i(3))
		else:list1.append(g.H(3))
	print ' '*12,'parseVertex:',g.tell()
	print ' '*12,'total pos count:',len(list0)
	print ' '*12,'total face count:',len(list1)
	print ' '*12,'total uv count:',len(list2)
	print ' '*12,'total skin weight count:',len(list3)
	print ' '*12,'total skin indice count:',len(list4)
	mesh=Mesh()
	mesh.SPLIT=False
	for k in range(submeshCount):
		mat=Mat()
		for m in range(submeshList[k][2],submeshList[k][2]+submeshList[k][3]):
			mesh.vertPosList.append(list0[m])
			if len(list2)>0:mesh.vertUVList.append(list2[m])
			if len(list3)>0 and len(list4)>0:	
				mesh.skinIDList.append(k)
				mesh.skinWeightList.append(list3[m])
				mesh.skinIndiceList.append(list4[m])	
		for m in range(submeshList[k][0],submeshList[k][0]+submeshList[k][1]):
			mesh.faceList.append(list1[m])
			mesh.matIDList.append(k)
		mesh.matList.append(mat)
	g.i(1)	
	return mesh
	
			
			
	
			
	
def skinParser(lodList,g):
	print ' '*8,'SKINPARSER:',g.tell()
	lod=lodList[0]
	u=g.i(2)
	print ' '*12,'bone map count:',u[0]
	print ' '*12,'material count:',u[1]
	for i in range(u[1]):
		value=g.H(3)
		count=g.i(1)[0]
		for j in range(count):
			matID=g.i(1)[0]
			print ' '*16,'matID:',matID,value
			for mat in matList:
				if mat.name==str(matID):
					lod.matList[i].diffuse=mat.diffuse
					lod.matList[i].normal=mat.normal
					lod.matList[i].specular=mat.specular
	boneCount=u[0]
	if version==794:list=[1,1,1,1,1,0,0,0]
	elif version==774:list=[0,1,1,1,0,0,1,0]
	elif version==910:list=[1,1,1,1,1,0,0,1]
	elif version==905:list=[1,1,1,1,1,0,0,1]
	elif version==904:list=[1,1,1,1,1,0,0,1]
	elif version==898:list=[1,1,1,1,1,0,0,1]
	elif version==892:list=[1,1,1,1,1,0,0,1]
	elif version==891:list=[1,1,1,1,1,0,0,1]
	elif version==888:list=[1,1,1,1,1,0,0,1]
	elif version==886:list=[1,1,1,1,1,0,0,1]
	elif version==884:list=[1,1,1,1,1,0,0,1]
	elif version==865:list=[1,1,1,1,1,0,0,1]
	elif version==837:list=[1,1,1,1,1,0,0,0]
	elif version==883:list=[1,1,1,1,1,0,0,1]
	elif version==821:list=[1,1,1,1,1,0,0,0]
	elif version==823:list=[1,1,1,1,1,0,0,0]
	elif version==830:list=[1,1,1,1,1,0,0,0]
	elif version==831:list=[1,1,1,1,1,0,0,0]
	elif version==828:list=[1,1,1,1,1,0,0,0]
	elif version==811:list=[1,1,1,1,1,0,0,0]
	elif version==807:list=[1,1,1,1,1,0,0,0]	
	elif version==775:list=[0,1,1,0,0,0,1,0]	
	elif version==710:list=[0,1,1,0,0,1,0,0]
	elif version==739:list=[0,1,1,0,0,1,0,0]
	elif version==717:list=[0,1,1,0,0,1,0,0]
	elif version==713:list=[0,1,1,0,0,1,0,0]
	elif version==704:list=[0,1,1,0,0,1,0,0]
	elif version==706:list=[0,1,1,0,0,1,0,0]
	elif version==714:list=[0,1,1,0,0,1,0,0]
	elif version==700:list=[0,1,1,0,0,1,0,0]
	elif version==697:list=[0,1,1,0,0,1,0,0]
	elif version==698:list=[0,1,1,0,0,1,0,0]
	elif version==701:list=[0,1,1,0,0,1,0,0]
	elif version==712:list=[0,1,1,0,0,1,0,0]
	elif version==666:list=[0,1,1,0,0,1,0,0]
	else:print 'WARNING:skin section 174',version
	if list[0]==1:g.i(g.i(1)[0])
	
	skeletonA=Skeleton()
	#skeletonA.NICE=True
	skeletonA.ARMATURESPACE=True
	skeletonA.FRAMESORT=True
	
	if list[7]==1:
		g.B(g.i(1)[0])
		g.i(g.i(1)[0])
		
	
	if list[1]==1:
		size=g.i(1)[0]
		t=g.tell()
		if size!=0:
			for m in range(boneCount):
				bone=Bone()
				rot=Matrix3x3(g.f(9)).resize4x4()
				pos=VectorMatrix(g.f(3))
				matrix=rot*pos
				matrixList.append(matrix)
				bone.matrix=matrix.invert()
				lod.bindPoseMatrixList.append(bone.matrix)
				#lod.boneNameList.append()
				skeletonA.boneList.append(bone)
		g.seek(t+size)
	if list[2]==1:
		g.i(1)[0]
		count=g.H(1)[0]
		for i in range(count):
			skin=Skin()	
			listA=g.H(64)
			print listA
			skin.list=[]
			for j in range(listA[0]):
				boneID=listA[j+1]
				skin.list.append(boneID)
			lod.skinList.append(skin)	
			
	if list[3]==1:
		for i in range(count):g.seek(252,1)	
	if list[4]==1:g.B(20),g.f(15),g.B(12)
	if list[5]==1:
		g.i(1)[0]
		g.word(g.i(1)[0]*2)
		g.B(2)
		g.word(g.i(1)[0]*2)
		g.B(2)
		count=g.i(1)[0]
		for i in range(count):
			g.seek(48,1)
		g.f(14)
		g.B(11)
		
	if list[6]==1:g.B(20),g.f(15),g.B(11)	
	skeletonList.append(skeletonA)
	
	
	



def bindPose(bindSkeleton,poseSkeleton,meshObject):
		#print 'BINDPOSE'
		mesh=meshObject.getData(mesh=1)
		poseBones=poseSkeleton.getData().bones
		bindBones=bindSkeleton.getData().bones			
		for vert in mesh.verts:
			index=vert.index
			skinList=mesh.getVertexInfluences(index)
			vco=vert.co.copy()*meshObject.matrixWorld
			vector=Vector()
			#waga=0
			for skin in skinList:
				#try:
					bone=skin[0]							
					weight=skin[1]	
					#waga+=weight	
					matA=bindBones[bone].matrix['ARMATURESPACE']*bindSkeleton.matrixWorld
					matB=poseBones[bone].matrix['ARMATURESPACE']*poseSkeleton.matrixWorld
					vector+=vco*matA.invert()*matB*weight
				#except:pass	
			vert.co=vector
			#print waga,
		mesh.update()
		Blender.Window.RedrawAll()
			
			
#ID=3
#bindSkeleton=Blender.Object.Get('armature-'+str(ID))
#poseSkeleton=Blender.Object.Get('bindPose-mesh-'+str(ID))
#meshObject=Blender.Object.Get('mesh-'+str(ID))

#bindPose(bindSkeleton,poseSkeleton,meshObject)			
	

def vhmParser(filename,g):
	global version
	global matList
	global matrixList
	global boneMapIDList	
	global vertex_type
	global skeletonList
	
	matrixList=[]
	boneMapIDList=[]
	matList=[]	
	highDir=g.dirname+os.sep+'high'	
	
	
	g.find('\x00')
	version,unk=g.i(2)	
	print 'version:',version
			
	
	if version in [666,697,698,704,706,700,701,710,712,713,714,717,739,774,775,794,807,811,821,823,828,830,831,837,865,883,884,886,888,891,892,898,904,905,910]:
	
		
		g.B(1),g.word(g.i(1)[0]*2),g.B(6)
		material_count=g.i(1)[0]
		print 'MATERIAL'
		print 'material count:',material_count	
		for k in range(material_count):	#materials
			mat_id=g.i(1)[0]
			mat=Mat()
			mat.name=str(mat_id)
			matList.append(mat) 
			count=g.i(1)[0]
			print '  material ID:',k
			print '    texture count:',count
			for m in range(count):
				name=g.word(g.i(1)[0]*2)	
				print '        texture ID:',m,name	
				g.B(2),g.f(2)
				if len(name)>0:
					name=name.lower().split('.')[0]+'.dds'
					imgPath=g.dirname+os.sep+name	
					if os.path.exists(imgPath)==False:			
						imgPath=highDir+os.sep+name
					if os.path.exists(imgPath)==False:
						n2pkPath=highDir+os.sep+'files.n2pk'
						if os.path.exists(n2pkPath)==True:
							print 'nconvert'
							file=open(n2pkPath,'rb')
							p=BinaryReader(file)
							n2pkParser(n2pkPath,p)
							file.close()
					if os.path.exists(imgPath)==True:
						if os.path.exists(imgPath.replace('.dds','.png'))==False:
							cmd=Cmd()
							cmd.input=imgPath
							cmd.PNG=True
							#cmd.run()
						#imgPath=imgPath.replace('.dds','.png')	
						if m==0:mat.diffuse=imgPath
						if m==1:mat.normal=imgPath
						if m==2:mat.specular=imgPath
				
			g.B(3)
			A=g.i(2)
			g.f(4)
			chunk=g.i(1)[0]
			g.word(g.i(1)[0]*2)
			if version==837:g.B(18)
			elif version==666:g.B(14)
			elif version==794:g.B(18)
			elif version==807:g.B(18)
			elif version==828:g.B(18)
			elif version==823:g.B(18)
			elif version==774:g.B(14)
			elif version==775:g.B(14)
			elif version==811:g.B(18)
			elif version==698:g.B(14)
			elif version==830:g.B(18)
			elif version==831:g.B(18)
			elif version==710:g.B(14)
			elif version==712:g.B(14)
			elif version==821:g.B(18)
			elif version==739:g.B(14)
			elif version==717:g.B(14)
			elif version==713:g.B(14)
			elif version==704:g.B(14)
			elif version==706:g.B(14)
			elif version==714:g.B(14)
			elif version==700:g.B(14)
			elif version==697:g.B(14)
			elif version==701:g.B(14)
			elif version==888:g.B(20)
			elif version==898:g.B(20)
			elif version==910:g.B(20)
			elif version==883:g.B(18)
			elif version==904:g.B(20)
			elif version==905:g.B(20)
			elif version==865:g.B(18)
			elif version==892:g.B(20)
			elif version==891:g.B(20)
			elif version==886:g.B(20)
			elif version==884:g.B(18)
			else:
				print 'WARNING:',version,g.tell()
				print g.B(30)
		print 'MESHES'		
		meshList=[]	
		skeletonList=[]
		meshCount=g.i(1)[0]
		print 'mesh count:',meshCount
		for s in range(meshCount):#meshes
			print '    meshID:',s
			g.word(g.i(1)[0]*2)
			g.H(1)	
			vertex_type=g.i(1)[0]
			print '        vertex_type:',vertex_type
			matrix=Matrix(g.f(4),g.f(4),g.f(4),g.f(4))
			print '        ',matrix[0]
			print '        ',matrix[1]
			print '        ',matrix[2]
			print '        ',matrix[3]
			g.B(1)
			lodCount=g.i(1)[0]
			lodList=[]
			print ' '*8,'lod count:',lodCount
			for i in range(lodCount):
				print
				print ' '*12,'lodID:',i
				lod=lodParser(g)
				lodList.append(lod)
				
			skinParser(lodList,g)	
			meshList.append(lodList)
		
		skeleton=Skeleton()
		skeleton.name='pose'
		skeleton.ARMATURESPACE=True
		skeleton.NICE=True
		animationFlag=g.B(1)[0]
		print 'ANIMATION'
		if animationFlag==1:
			sum=0
			animCount=g.i(1)[0]
			actionList=[]
			#print 'DEBUG'
			#g.debug=True
			#if version in [898]:g.i(1)
			print ' '*4,'animation count:',animCount
			for m in range(animCount):
				#print
				action=Action()
				if version in [774,794,807,811,821,823,828,830,831,837,910]:
					v=g.i(3)
					action.frameCount=v[2]
					sum+=v[2]
					g.B(16)
					g.i(g.i(1)[0])
					g.B(4)
					action.name=g.word(g.i(1)[0]*2)
					g.B(6)
				elif version in [666]:
					v=g.i(3)
					action.frameCount=v[2]
					sum+=v[2]
					g.B(26)
					#g.i(g.i(1)[0])
					#g.B(4)
					action.name=g.word(g.i(1)[0]*2)
					g.B(11)
				elif version in [883,865,884,886,888,891,892,898,904,905]:
					v=g.i(3)
					#print v
					action.frameCount=v[2]
					sum+=v[2]
					g.B(16)
					g.i(g.i(1)[0])
					g.B(4)
					action.name=g.word(g.i(1)[0]*2)
					#print action.name
					g.B(6)
				else:
					#print 'WARNING at skeleton:',version,g.tell()
					v=g.i(3)
					#print v
					action.frameCount=v[2]
					sum+=v[2]
					g.i(g.i(1)[0])
					g.i(1)
					count=g.i(1)[0]
					#print count
					g.i(count*3)
					count=g.i(1)[0]
					g.H(count)
					g.B(10)
					action.name=g.word(g.i(1)[0]*2)
					g.B(12)	
				print ' '*8,'animation name:',action.name	
				actionList.append(action)
			#g.debug=False	
			#print 'tell:',g.tell()	
			boneCount,animStreamSize=g.i(2)
			start=g.tell()				
			g.seek(start+animStreamSize)
			g.f(boneCount)   
			for m in range(g.i(1)[0]/24):
				g.seek(24,1)
		#BONES
				
		def twig(parentMatrix,parentName):
			name=g.word(g.i(1)[0]*2)[-25:]
			#print name,g.tell()
			g.B(2)
			matrix=Matrix4x4(g.f(16))*parentMatrix
			g.i(1),g.word(g.i(1)[0]*2),g.B(6)
			bone=Bone()
			bone.name=name
			bone.matrix=matrix
			bone.parentName=parentName
			skeleton.boneList.append(bone)
			for m in range(g.i(1)[0]):
				twig(matrix,name)	
			
			
		name=g.word(g.i(1)[0]*2)[-25:]
		bone=Bone()
		bone.name=name
		g.B(2)
		matrix=Matrix4x4(g.f(16))
		rotMatrix=matrix.rotationPart().invert().resize4x4()
		matrix=rotMatrix
		bone.matrix=matrix
		g.i(1),g.word(g.i(1)[0]*2),g.B(6)
		skeleton.boneList.append(bone)
		for m in range(g.i(1)[0]):
			twig(matrix,name)
			
		skeleton.draw()
		
		"""if animationFlag==1:
			g.seek(start)
			
			for m in range(animCount):
				action=actionList[m]
				action.ARMATURESPACE=True
				action.BONESORT=True
				action.skeleton='pose'
				#action.BONESPACE=True
				for k in range(action.frameCount):
					for n in range(boneCount):
						if k==0:
							bone=ActionBone()
							bone.name=skeleton.boneNameList[n]
							action.boneList.append(bone)	
						else:
							bone=action.boneList[n]
						g.logWrite(bone.name)	
						rot=Matrix3x3(g.f(9)).resize4x4()
						pos=VectorMatrix(g.f(3))
						matrix=rot*pos
						bone.matrixFrameList.append(k)
						bone.matrixKeyList.append(matrix)
						#bone.rotFrameList.append(k)
						#bone.rotKeyList.append(rot)
						#bone.posFrameList.append(k)
						#bone.posKeyList.append(pos)
				action.draw()
				action.setContext()	
				break"""	
		"""action=actionList[0]	
			for bone in action.boneList:
				g.logWrite(bone.name)				
				for i in range(action.frameCount):
					g.logWrite(str(i))
					g.logWrite(str(bone.matrixKeyList[i]))"""
			

			
		poseSkeleton=None
		g.logClose()
		for i,lodList in enumerate(meshList):
			print 'meshID:',i
			meshSkeleton=skeletonList[i]
			meshSkeleton.name='armature-'+str(i)
			for j,bone in enumerate(meshSkeleton.boneList):
				bone.name=skeleton.boneList[j].name
				bone.parentName=skeleton.boneList[j].parentName
				#bone.matrix*=skeleton.boneList[j].matrix
			meshSkeleton.draw()
			for lod in lodList:
				#lod.BINDSKELETON='pose'
				#lod.BINDSKELETON=meshSkeleton.name#
				#lod.BINDPOSESKELETON=meshSkeleton.name#
				if len(lod.skinIndiceList)>0 and len(lod.skinWeightList)>0:
					lod.boneNameList=meshSkeleton.boneNameList
					#lod.BINDPOSE=True
					for skin in lod.skinList:
						for m in range(len(skin.list)):
							#skin.boneMap.append(skeleton.boneNameList[skin.list[m]])
							skin.boneMap.append(skin.list[m])
				lod.draw()
				if BINDPOSEFLAG==True:	
					if len(lod.skinIndiceList)>0 and len(lod.skinWeightList)>0:
						bindSkeleton=Blender.Object.Get(meshSkeleton.name)
						poseSkeleton=Blender.Object.Get('pose')
						meshObject=Blender.Object.Get(lod.object.name)

						bindPose(bindSkeleton,poseSkeleton,meshObject)			
		
				
				
				
				break#we need only first lod from each mesh
		
		if BINDPOSEFLAG==True:	
			scene = bpy.data.scenes.active
			for object in scene.objects:
				if object.type=='Armature':
					if 'armature-' in object.name:		
						scene.unlink(object)
			scene.update()
			scene = bpy.data.scenes.active	
			try:poseSkeleton=Blender.Object.Get('pose')	
			except:pass
			if poseSkeleton is not None:
				for object in scene.objects:
					if object.type=='Mesh':
						poseSkeleton.makeParentDeform([object],0,0)
		print 'DONE'
	else:
		print 'WARNING: NIEZGODNA WERSJA',version
		print 'KONIEC'
		
def Parser():	
	filename=input.filename
	print
	print filename
	print
	
	imageList=input.imageList
	ext=filename.split('.')[-1].lower()	
	
	if ext=='n2pk':
		file=open(filename,'rb')
		g=BinaryReader(file)
		n2pkParser(filename,g)
		file.close()	
	
	if ext=='vhm':
		file=open(filename,'rb')
		g=BinaryReader(file)
		vhmParser(filename,g)
		file.close()	
	
	if ext=='vht':
		file=open(filename,'rb')
		g=BinaryReader(file)
		vhtParser(filename,g)
		file.close()
 
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
	 
Blender.Window.FileSelector(openFile,'import','Van Helsing and Deathtrap files: n2pk - container file, vhm - skinned meshes') 