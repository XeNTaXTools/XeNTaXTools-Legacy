import newGameLib
from newGameLib import *
import Blender	


def NDEB(model,g):
	skeleton=Skeleton()
	skeleton.BONESPACE=True
	#skeleton.NICE=True
	model.skeleton=skeleton
	for m in range(model.boneCount):		
		A=g.i(4)
		bone=Bone()
		bone.name=model.idList[A[0]]
		bone.parentID=A[1]
		skeleton.boneList.append(bone)
		bone.matrix=Matrix4x4(g.f(16))#.invert()	
def INVB(model,g):
	A=g.i(8)
	t=g.tell()	
	model.boneMap=g.i(A[1])
	g.seek(t+A[3])
	for m in range(A[1]):
		bone=Bone()
		bone.name=str(model.boneMap[m])
		model.bindSkeleton.boneList.append(bone)
		bone.matrix=Matrix4x4(g.f(16)).invert()
def GEOP(mesh,g):
	g.tell()
	A=g.i(12)
	start=g.tell()
	mat=Mat()
	mat.TRIANGLE=True
	mesh.matList.append(mat)
	for m in range(A[4]):
		t=g.tell()
		if mesh.vertexInfo.posOff is not None:
			g.seek(t+mesh.vertexInfo.posOff)
			if mesh.vertexInfo.posType=='float':
				mesh.vertPosList.append(g.f(3))
		if mesh.vertexInfo.uvOff is not None:
			g.seek(t+mesh.vertexInfo.uvOff)
			if mesh.vertexInfo.uvType=='half':
				mesh.vertUVList.append(g.half(2))
				
		if mesh.vertexInfo.skinIndiceOff is not None:
			g.seek(t+mesh.vertexInfo.skinIndiceOff)
			if mesh.vertexInfo.skinIndiceType=='byteAsInt':
				mesh.skinIndiceList.append(g.B(4))
				
		if mesh.vertexInfo.skinWeightOff is not None:
			g.seek(t+mesh.vertexInfo.skinWeightOff)
			if mesh.vertexInfo.skinWeightType=='byteAsFloat':
				mesh.skinWeightList.append(g.B(4))
		g.seek(t+mesh.vertexInfo.stride)
	
	g.seek(start+A[6])
	g.logWrite(['indice:',A])
	#mat.IDStart=len(mesh.indiceList)
	#mat.IDCount=A[8]
	#mesh.TRISTRIP=True	
	mesh.indiceList=g.H(A[8])
	
class VertexInfo:
	pass	
	
def SGEO(vertexInfo,g):
	B=g.i(4)
	BB=g.f(7)
	A=g.i(5)
	vertexInfo.posOff=None
	vertexInfo.posType=None
	vertexInfo.uvOff=None
	vertexInfo.uvType=None
	vertexInfo.skinIndiceOff=None
	vertexInfo.skinIndiceType=None
	vertexInfo.skinWeightOff=None
	vertexInfo.skinWeightType=None
	vertexInfo.hash=B[1]
	
	for m in range(A[1]):
		B=g.i(8)		
		if B[0]==0:
			vertexInfo.posOff=B[4]
			if B[2]==2:	
				vertexInfo.posType='float'
		if B[0]==5 and B[1]==0:
			vertexInfo.uvOff=B[4]
			if B[2]==2:	
				vertexInfo.uvType='float'
			if B[2]==4:	
				vertexInfo.uvType='half'
				
		if B[0]==2 and B[1]==0:
			vertexInfo.skinIndiceOff=B[4]
			if B[2]==11:	
				vertexInfo.skinIndiceType='byteAsInt'
				
		if B[0]==1 and B[1]==0:
			vertexInfo.skinWeightOff=B[4]
			if B[2]==10:	
				vertexInfo.skinWeightType='byteAsFloat'
				
	vertexInfo.stride=A[4]
def MTLB(model,g):
	print model.matCount
	for m in range(model.matCount):
		A=g.i(12)
		print A
		always=0
		for n in range(A[3]):
			g.logWrite(n)
			B=g.i(2)
			value=[0]*20
			if B[1]==14:value=g.i(2)
			elif B[1]==1:value=g.i(2)
			elif B[1]==4:value=g.i(6)
			elif B[1]==3:value=g.i(6)
			elif B[1]==2:value=g.i(2)
			elif B[1]==19:value=g.i(6)
			elif B[1]==21:value=g.i(6)
			#elif B[1]==14:g.i(2)
			else:
				print 'UWAGA:',B
				break
			if B[1]==19 and always==0:
				diffTexID=value[0]
				model.matList.append(diffTexID)
				always=1
def MTLB1(model,g):g.i(700)
def IMGB(model,g):
	for m in range(model.texCount):
		A=g.i(2)
		model.texList.append(model.idList[A[1]])
def HDET(model,g):
	A=g.i(16)
	model.boneCount=A[3]
	model.texCount=A[0]
	model.matCount=A[1]
def MTDT(model,g):
	t=g.tell()
	A=g.i(4)
	offList=g.i(A[0])
	for off in offList:
		g.seek(t+off)
		A=g.i(12)
def STHB(model,g):
	A=g.i(4)
	t=g.tell()
	offList=[]
	for m in range(A[0]):offList.append(g.i(2))
	g.seek(t+A[1])	
	t=g.tell()
	model.idList={}
	for [id,off] in offList:
		g.seek(t+off)
		name=g.find('\x00')
		model.idList[id]=name
		


class Node:
	def __init__(self):
		self.chunk=None
		self.offset=None
		self.children=[]
		
	
	
def tree(HEADSIZE,DATASIZE,g,n,parent):
	sum=HEADSIZE
	n+=4
	while(True):
		node=Node()
		parent.children.append(node)
		start=g.tell()
		node.offset=start
		print start
		chunk=g.word(8)
		node.chunk=chunk
		dataSize,headSize=g.i(2)
		node.headSize=headSize
		node.dataSize=dataSize
		sum+=16+dataSize
		g.seek(start+headSize)
		if headSize>16:tree(headSize-16,dataSize,g,n,node)
		g.seek(start+16+dataSize)
		if sum==DATASIZE:break
		
	
def gtfParser(texPath):
	
	texFile=open(texPath,'rb')
	p=BinaryReader(texFile)
	p.endian='>'
	obrazek=Obrazek()
	obrazek.name=texPath.replace('.gtf','.dds')
	A=p.i(6)
	B=p.H(36*2)
	obrazek.szer=B[4]
	obrazek.wys=B[5]
	if B[0]==34827:
		obrazek.format='DXT5'
	elif B[0]==34826:
		obrazek.format='DXT5'
	else:	
		obrazek.format='DXT1'
	p.seek(A[4])
	obrazek.data=p.read(A[5])
	obrazek.save()
	texFile.close()	
	return obrazek.name

def mdlParser(filename,g):
	global meshList
	meshList=[]
	endian=g.word(8)
	if endian=='ENDILTLE':		
		g.endian='<'
	else:		
		g.endian='>'
	g.seek(0)	
	size=g.fileSize()
	n=-4
	root=Node()
	tree(0,size,g,n,root)	
	
	
	model=Model(filename)
	model.matList=[]
	model.texList=[]
	model.groupList=[]
	model.groupList=[]
	bindSkeleton=Skeleton()
	bindSkeleton.name='bindarmature'
	bindSkeleton.ARMATURESPACE=True
	#bindSkeleton.NICE=True
	model.bindSkeleton=bindSkeleton
	model.boneMap=[]
	
#def pp():
	for node in root.children:
		g.seek(node.offset+16)
		g.logWrite(node.chunk)
		if node.chunk=='MDL GEOB':
			A=g.i(4)
			groupCount=A[1]
			for node in node.children:
				g.seek(node.offset+16)
				if node.chunk=='MDL GEO ':
					A=g.i(4)
					group=[]
					model.groupList.append(group)
					for node in node.children:
						g.seek(node.offset+16)
						if node.chunk=='MDL SGEO':
							meshList=[]#Mesh()
							#group.append(mesh)
							group.append(meshList)
							vertexInfo=VertexInfo()
							SGEO(vertexInfo,g)
							for node in node.children:
								g.seek(node.offset+16)								
								if node.chunk=='MDL GEOP':
									mesh=Mesh()
									meshList.append(mesh)
									mesh.vertexInfo=vertexInfo
									GEOP(mesh,g)
					
		if node.chunk=='MDL HDET':HDET(model,g)
		if node.chunk=='MDL STHB':STHB(model,g)
		if node.chunk=='MDL MTDT':MTDT(model,g)
		if node.chunk=='MDL IMGB':IMGB(model,g)
		if node.chunk=='MDL INVB':INVB(model,g)
		if node.chunk=='MDL NDEB':NDEB(model,g)
		if node.chunk=='MDL MTLB':MTLB(model,g)
		if node.chunk=='MDL MMVB':
			A=g.i(4)
			for node in node.children:
				g.seek(node.offset+16)
				if node.chunk=='MDL MMV ':
					A=g.i(8)+g.H(2)
		if node.chunk=='MDL IGOB':
			skeleton=model.skeleton
			skeleton.draw()
			bindSkeleton=model.bindSkeleton
			for m,bone in enumerate(bindSkeleton.boneList):
				bone.name=skeleton.boneNameList[model.boneMap[m]]
			bindSkeleton.draw()
			for m in range(groupCount):			
				A=g.i(4)
				group=model.groupList[A[1]]
				for n in range(A[2]):
					meshList=group[n]
					for mesh in  meshList:
						mesh.BINDSKELETON=skeleton.name
						mesh.boneNameList=skeleton.boneNameList
						skin=Skin()
						skin.boneMap=model.boneMap
						mesh.skinList.append(skin)
						#mat=Mat()
						matID=g.i(1)[0]
						if len(mesh.matList)>1:
							mesh.SPLIT=True
						for mat in mesh.matList:
						#mesh.matList.append(mat)
							if matID<len(model.matList):
								texID=model.matList[matID]
								print texID,len(model.texList)
								texPath=model.texList[texID]
								texPath=g.dirname+os.sep+texPath
								print texPath
								if os.path.exists(texPath)==True:	
									if g.endian=='<':
										mat.diffuse=texPath
									else:						
										mat.diffuse=gtfParser(texPath)	
								else:
									texPath=g.dirname+os.sep+os.path.basename(texPath)
									if os.path.exists(texPath)==True:	
										if g.endian=='<':
											mat.diffuse=texPath
										else:						
											mat.diffuse=gtfParser(texPath)	
							else:
								print 'check mat and tex section'
							
						if len(mesh.skinIndiceList)==0:	
							matrix=skeleton.object.getData().bones[skeleton.boneList[A[0]].name].matrix['ARMATURESPACE']
							skin.boneMap=[A[0]]
							for m in range(len(mesh.vertPosList)):
								mesh.skinIndiceList.append([0])
								mesh.skinWeightList.append([1.0])
							mesh.draw()
							mesh.object.setMatrix(matrix)
						else:	
							mesh.draw()
							bindPose(bindSkeleton.object,skeleton.object,mesh.object)
	
	
	
def anmParser(filename,g):
	global meshList
	meshList=[]
	endian=g.word(8)
	if endian=='ENDILTLE':		
		g.endian='<'
	else:		
		g.endian='>'
	g.seek(0)	
		
	size=g.fileSize()
	n=-4
	root=Node()
	tree(0,size,g,n,root)	
	
	
	model=Model(filename)
	model.matList=[]
	model.texList=[]
	model.groupList=[]
	
	
	action=Action()
	action.BONESORT=True
	action.BONESPACE=True
	action.name=g.basename
	boneList={}
	for node in root.children:
		g.seek(node.offset+16)
		if node.chunk=='ANM ANMB':
			A=g.i(4)
			groupCount=A[1]
			for node in node.children:
				g.seek(node.offset+16)
				if node.chunk=='ANM ANM ':
					A=g.i(8)
					name=model.idList[A[1]]
					if name not in boneList:						
						bone=ActionBone()
						bone.name=name
						boneList[name]=bone
						action.boneList.append(bone)
					else:
						bone=boneList[name]
					if A[3]==2:
						for m in range(A[7]):
							time=g.f(1)[0]*33
							bone.rotFrameList.append(time)
							bone.rotKeyList.append(QuatMatrix(g.f(4)).resize4x4())
					if A[3]==3:
						for m in range(A[7]):
							time=g.f(1)[0]*33
							pos=g.f(4)
							bone.posFrameList.append(time)
							bone.posKeyList.append(VectorMatrix(pos))
					
		if node.chunk=='ANM HDET':HDET(model,g)
		if node.chunk=='ANM STHB':STHB(model,g)
		if node.chunk=='ANM MTDT':MTDT(model,g)
		if node.chunk=='ANM IMGB':IMGB(model,g)
		if node.chunk=='ANM INVB':INVB(model,g)
		if node.chunk=='ANM NDEB':NDEB(model,g)
		if node.chunk=='ANM MTLB':MTLB(model,g)
		
	action.draw()
	action.setContext()	
	
def Parser(filename):
	ext=filename.split('.')[-1].lower()	
	
	if ext=='mdl':
		file=open(filename,'rb')
		g=BinaryReader(file)
		g.logOpen()
		mdlParser(filename,g)
		g.logClose()
		file.close()	
	
	if ext=='anm':
		file=open(filename,'rb')
		g=BinaryReader(file)
		anmParser(filename,g)
		file.close()
 
 
	
Blender.Window.FileSelector(Parser,'import','SELECT: *.mdl, *.anm') 
	