import newGameLib
from newGameLib import *
import Blender
import math 
from math import *



	
	
def quatDecompress(s0,s1,s2):  
	tmp0= s0>>15 
	tmp1= (s1*2+tmp0) & 0x7FFF
	s0= s0 & 0x7FFF ;
	tmp2= s2*4 ;
	tmp2= (s2*4+ (s1>>14)) & 0x7FFF ;
	s1= tmp1 ;
	AxisFlag= s2>>13 ;
	s2= tmp2 ;
	f0 = 1.41421*(s0-0x3FFF)/0x7FFF ;
	f1 = 1.41421*(s1-0x3FFF)/0x7FFF ;
	f2 = 1.41421*(s2-0x3FFF)/0x7FFF ;  
	f3 = sqrt(1.0-(f0*f0+f1*f1+f2*f2))
	if AxisFlag==3:x= f2;y= f1;z= f0;w= f3
	if AxisFlag==2:x= f2;y= f1;z= f3;w= f0
	if AxisFlag==1:x= f2;y= f3;z= f1;w= f0
	if AxisFlag==0:x= f3;y= f2;z= f1;w= f0
	return x,y,z,w  

	

def sknParser(filename,g):
	dirname=Blender.sys.dirname(filename)
	mesh=Mesh() 
	mesh.BINDSKELETON=skeleton.name
	HEADER = g.H(4)
	print 'HEADER:',HEADER
	if HEADER[2]==2:
		for m in range(g.i(1)[0]):
			g.word(64),g.i(4)
		data = g.i(2)
		mesh.indiceList=g.H(data[0])
		skin=Skin()
		for m in range(data[1]):	
			back = g.tell()
			mesh.vertPosList.append(g.f(3))	 
			mesh.skinIndiceList.append(g.B(4))
			mesh.skinWeightList.append(g.f(4))
			g.seek(back+44,0)
			mesh.vertUVList.append(g.f(2))
			g.seek(back+52,0) 
		if skeleton is not None:
			list=[]
			for m in range(len(boneMap)):
				list.append(skeleton.boneNameList[boneMap[m]])	
			skin.boneMap=list
		mesh.skinList.append(skin)	
		
		#facesgroups (or materials)
		mat=Mat()
		mat.TRIANGLE=True
		listdir=os.listdir(dirname)
		image_name=Blender.sys.basename(filename).lower().replace('.skn','.dds')
		image_path=filename.lower().replace('.skn','.dds')
		for file in listdir:
			if image_name == file.lower():
				mat.diffuse=image_path
			
		image_name=Blender.sys.basename(filename).lower().replace('.skn','_tx_cm.dds')
		image_path=filename.lower().replace('.skn','_tx_cm.dds')
		for file in listdir:
			if image_name == file.lower():
				mat.diffuse=image_path	
			
		image_name=Blender.sys.basename(filename).lower().replace('.skn','_base_tx_cm.dds')
		image_path=filename.lower().replace('.skn','_base_tx_cm.dds')
		for file in listdir:
			if image_name == file.lower():
				mat.diffuse=image_path		
		mesh.matList.append(mat)
		
		#draw mesh			
		mesh.draw()	
		
		g.logClose()
	if HEADER[2]==4:
	
		for m in range(g.i(1)[0]):
			g.word(64),g.i(4)
		a,b,c,d,e = g.i(5)
		g.f(10)
		mesh.indiceList=g.H(b)
		for m in range(c):	
			back = g.tell()
			mesh.vertPosList.append(g.f(3))	 
			mesh.skinIndiceList.append(g.B(4))
			mesh.skinWeightList.append(g.f(4))
			g.seek(back+44,0)
			mesh.vertUVList.append(g.f(2))
			g.seek(back+52,0) 
		mesh.boneNameList=skeleton.boneNameList	 
		if skeleton is not None:
			list=[]
			for m in range(len(boneMap)):
				list.append(skeleton.boneNameList[boneMap[m]])	
			mesh.boneNameList=list
		skin=Skin()	
		mesh.skinList.append(skin)	
		
		#facesgroups (or materials)
		mat=Mat()
		mat.TRIANGLE=True
		listdir=os.listdir(dirname)
		image_name=Blender.sys.basename(filename).lower().replace('.skn','.dds')
		image_path=filename.lower().replace('.skn','.dds')
		for file in listdir:
			if image_name == file.lower():
				mat.diffuse=image_path
			
		image_name=Blender.sys.basename(filename).lower().replace('.skn','_tx_cm.dds')
		image_path=filename.lower().replace('.skn','_tx_cm.dds')
		for file in listdir:
			if image_name == file.lower():
				mat.diffuse=image_path	
			
		image_name=Blender.sys.basename(filename).lower().replace('.skn','_base_tx_cm.dds')
		image_path=filename.lower().replace('.skn','_base_tx_cm.dds')
		for file in listdir:
			if image_name == file.lower():
				mat.diffuse=image_path		
		mesh.matList.append(mat)
		mesh.draw()
	
	
	
def anm_parser(filename,g):
	chunk=g.word(8)
	if chunk=='r3d2anmd':
		action=Action()
		action.BONESORT=True
		#action.FRAMESORT=True
		#action.ARMATURESPACE=True
		action.BONESPACE=True
		action.skeleton='armature'
		a=g.i(17)
		version=a[0]
		print 'animation version:',version
		if version==4:
			boneList={}
			new=open('boneList.txt','r')
			lines=new.readlines()
			if len(lines)!=0:
				for line in lines:
					hash,name=line.strip().split(':')
					boneList[hash]=name
				new.close()
			
				g.seek(a[11]+12)
				count=(a[12]-a[11])/12
				posMatrixList=[]
				for n in range(count):#pos matrix
					posMatrixList.append(VectorMatrix(g.f(3)))
					
				g.seek(a[12]+12)
				count=(a[13]-a[12])/16
				rotMatrixList=[]
				for n in range(count):#rot matrix
					rotMatrixList.append(QuatMatrix(g.f(4)).resize4x4())
					
					
				g.seek(a[13]+12)
				List={}
				for m in range(a[6]):#frame
					for n in range(a[5]):
						hash=g.i(1)[0]
						ID=g.H(4)
						if hash not in List:
							bone=ActionBone()
							#bone.name=str(hash)
							bone.name=boneList[str(hash)]
							List[hash]=bone
							action.boneList.append(bone)
						else:
							bone=List[hash]
						bone.matrixFrameList.append(m)
						posMatrix=posMatrixList[ID[0]]
						rotMatrix=rotMatrixList[ID[2]]
						bone.matrixKeyList.append(rotMatrix*posMatrix)
				action.draw()
				action.setContext()

						
				g.debug=True
				g.tell()
			else:
				print 'WARNING:version skn with version anm Not supported'
		elif version==5:
			print a
			boneList={}
			new=open('boneList.txt','r')
			lines=new.readlines()
			if len(lines)!=0:
				for line in lines:
					hash,name=line.strip().split(':')
					boneList[hash]=name
				new.close()
				
				g.seek(a[8]+12)
				hashList=g.i(a[5])
				
				g.seek(a[11]+12)
				count=(a[12]-a[11])/12
				posMatrixList=[]
				for n in range(count):#pos matrix
					posMatrixList.append(VectorMatrix(g.f(3)))
				
				g.seek(a[12]+12)
				count=(a[8]-a[12])/6
				rotMatrixList=[]
				for n in range(count):#rot matrix				
					x,y,z=g.h(3)
					x,y,z,w=quatDecompress(x,y,z)
					rotMatrixList.append(QuatMatrix([x,y,z,w]).resize4x4())
					
				g.seek(a[13]+12)
				List1=[]
				List2=[]
				List3=[]
				List={}
				for m in range(a[6]):#frame
					g.logWrite('frame'+str(m))
					for n in range(a[5]):
						#g.logWrite(m)
						ID=g.H(3)
						List1.append(ID[0])
						List2.append(ID[1])
						List3.append(ID[2])
						hash=hashList[n]
						if hash not in List:
							bone=ActionBone()
							#bone.name=str(hash)
							bone.name=boneList[str(hash)]
							List[hash]=bone
							action.boneList.append(bone)
						else:
							bone=List[hash]
						bone.matrixFrameList.append(m)
						posMatrix=posMatrixList[ID[0]]
						rotMatrix=rotMatrixList[ID[2]]
						bone.matrixKeyList.append(rotMatrix*posMatrix)
				print max(List1),max(List2),max(List3)		
				action.draw()
				action.setContext()
				g.debug=True
				g.tell()
		elif version==3:
			g.seek(8)
			action=Action()
			action.name=Blender.sys.basename(filename).split('.')[0]
			action.skeleton='armature'
			action.BONESPACE=True
			action.BONESORT=True
			data = g.i(5)
			print data
			action.framecount=data[3]
			for m in range(data[2]):
				actionbone=ActionBone()
				name = g.word(32)
				actionbone.name=name
				g.i(1)[0]
				for n in range(data[3]):
					actionbone.rotFrameList.append(n)
					rot=g.f(4)
					pos=g.f(3)
					rot=Quaternion(rot[3],rot[0],rot[1],rot[2]).toMatrix().resize4x4()	
					pos=TranslationMatrix(Vector(pos))	
					actionbone.rotKeyList.append(rot)
					actionbone.posFrameList.append(n)			
					actionbone.posKeyList.append(pos)
				action.boneList.append(actionbone)
			action.draw()	
			action.setContext()
		else:	
			print 'WARNING:unknow version:',version

	elif chunk=='r3d2canm':
		g.i(2)
		g.word(4)
		print 'WARNING:unknow version:',chunk
		
	else:	
		action=Action()
		action.name=Blender.sys.basename(filename).split('.')[0]
		action.skeleton='armature'
		action.BONESPACE=True
		action.BONESORT=True
		data = g.i(5)
		print data
		action.framecount=data[3]
		for m in range(data[2]):
			actionbone=ActionBone()
			name = g.word(32)
			actionbone.name=name
			g.i(1)[0]
			for n in range(data[3]):
				actionbone.rotFrameList.append(n)
				rot=g.f(4)
				pos=g.f(3)
				rot=Quaternion(rot[3],rot[0],rot[1],rot[2]).toMatrix().resize4x4()	
				pos=TranslationMatrix(Vector(pos))	
				actionbone.rotKeyList.append(rot)
				actionbone.posFrameList.append(n)			
				actionbone.posKeyList.append(pos)
			action.boneList.append(actionbone)
		action.draw()	
		action.setContext()
	
def rafParser(filename,g):
	g.logOpen()
	a=g.i(6)
	A=[]
	for i in range(a[5]):
		A.append(g.i(4))
	a=g.i(2)
	nameList=[]
	start=g.tell()
	
	datFile=open(filename+'.dat','rb')
	
	B=[]
	for i in range(a[1]):
		B.append([g.i(1)[0],g.i(1)[0]])
	g.debug=True
	for i in range(a[1]):
		ID=A[i][3]
		g.seek(B[ID][0]+start-8)
		filePath=gameDir+os.sep+g.word(B[ID][1])
		sys=Sys(filePath)
		if os.path.exists(sys.dir)==False:
			os.makedirs(sys.dir)
		new=open(filePath,'wb')
		datFile.seek(A[i][1])
		data=zlib.decompress(datFile.read(A[i][2]))
		new.write(data)
		new.close()	
	datFile.close()	
	g.tell()
	g.logClose()	
	
def skl_parser(filename,g):
	g.logOpen()
	skeleton=Skeleton()
	chunk=g.word(8)
	boneMap=[]
	
	new=open('boneList.txt','w')
	
	if chunk=='r3d2sklt':
		print chunk
		skeleton.name='armature'
		skeleton.ARMATURESPACE=True	
		data = g.i(3)
		for m in range(data[2]):
			bone=Bone()
			bone.name=g.word(32)
			bone.parentID=g.i(1)[0]
			g.f(1)[0]
			row1=g.f(4)
			row2=g.f(4)
			row3=g.f(4)
			bone.rotMatrix=Matrix(row1[:3],row2[:3],row3[:3]).resize4x4().invert()
			bone.posMatrix=TranslationMatrix(Vector(row1[3],row2[3],row3[3]))
			skeleton.boneList.append(bone)
		boneMap = g.i(g.i(1)[0])
		skeleton.draw()	 
	else:
		skeleton.name='armature'
		#skeleton.ARMATURESPACE=True	
		skeleton.BONESPACE=True	
		skeleton.NICE=True
		g.seek(0)
		a=g.H(8)
		print a
		b=g.i(13)
		print b
		g.seek(b[2])
		
		hashList={}
		for m in range(a[7]):
			c=g.H(2)+g.i(1)
			print c
			hashList[c[0]]=c[2]
		g.seek(b[3])
		boneMap=g.H(b[0])
		g.seek(b[6])
		
		boneNameList=[]
		for m in range(a[7]):
			boneNameList.append(g.find('\x00'))
			g.seekpad(4)
		g.seek(b[1])	
		#g.debug=True
		for m in range(a[7]):
			bone=Bone()
			t=g.tell()
			c=g.h(8)
			bone.ID=c[1]
			bone.parentID=c[2]
			bone.name=boneNameList[m]
			new.write(str(hashList[m])+':'+boneNameList[m]+'\n')
			#bone.name=str(hashList[m])
			bone.posMatrix=VectorMatrix(g.f(3))
			sc=g.f(3)
			bone.rotMatrix=QuatMatrix(g.f(4)).resize4x4()
			
			pos=g.f(3)
			sc=g.f(3)
			rot=g.f(4)
			
			
			
			g.i(1)
			g.seek(t+100)
			skeleton.boneList.append(bone)
		skeleton.draw()	 
		
	g.logClose()
	g.tell()
	new.close()
	return skeleton,boneMap	
		
def datParser(filename,g):
	g.logOpen()
	g.debug=True
	g.i(1)[0]
	g.word(g.H(1)[0])
	a,b=g.i(2)
	for m in range(b):#bone
		frameCount=g.i(1)[0]
		g.word(g.H(1)[0])
		g.f(1)
		for n in range(frameCount):#frame
			g.f(10)
		#break
	g.tell()	
	g.logClose()
		
			
def Parser():
	global gameDir
	filename=input.filename
	print
	print filename
	print
	ext=filename.split('.')[-1].lower()
	
	gameDir='e:\\LeagueOfLegends'
	
	global skeleton,boneMap
	skeleton=None
	boneMap=None
	
	if ext=='skn':
		new=open('model.txt','w')
		new.write(filename+'\n')
		new.close()
		
		file=open(filename.replace('.skn','.skl'),'rb')
		g=BinaryReader(file)
		skeleton,boneMap=skl_parser(filename,g)
		file.close()
		
		file=open(filename,'rb')
		g=BinaryReader(file)
		sknParser(filename,g)
		file.close()
	
	if ext=='skl':
		
		file=open(filename,'rb')
		g=BinaryReader(file)
		skl_parser(filename,g)
		file.close()
	
	if ext=='anm':
		
		file=open(filename,'rb')
		g=BinaryReader(file)
		anm_parser(filename,g)
		file.close()
		if 'animations' in filename.lower():
			sknDir=filename.lower().split('animations')[0]
		
	
	if ext=='raf':
		
		file=open(filename,'rb')
		g=BinaryReader(file)
		rafParser(filename,g)
		file.close()
		
	if ext=='dat':
		
		file=open(filename,'rb')
		g=BinaryReader(file)
		datParser(filename,g)
		file.close()
	

def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()

Blender.Window.FileSelector(openFile,'import','skn - skinned mesh, anm - animation') 