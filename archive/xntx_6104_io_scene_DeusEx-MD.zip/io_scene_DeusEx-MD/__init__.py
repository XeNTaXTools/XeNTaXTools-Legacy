# author: Volfin, Aspadm
# 1.00 - Initial Release
# 1.01 - Improved UV detection
# 1.02 - added support for moar model formats.
# 1.03 - fixed a regression
# 1.04 - Added some missing UV formats
# 1.05 - Added in proper UV scaling; cleaned up code
# 1.06 - Fixed UV block skip table calculation
# 1.07 - Added new Model format
# 1.08 - Validated to blender version 2.70; added check for Object mode
# 1.09 - Added support for alternate unpacker format
# 1.10 - Added UV decode fix for some types of mesh discovered by Aspadm.

bl_info = {
    "name": "DeusEx:Mankind Divided Dat Importer",
    "author": "Volfin",
    "version": (1, 1, 0),
    "blender": (2, 7, 0),
    "location": "File > Import > Dat (DeusEx:MD Model)",
    "description": "Import DeusExMD, io: mesh",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
    "category": "Import-Export"}
    
if "bpy" in locals():
    import imp
    if "import_DeusExMD" in locals():
        imp.reload(import_DeusExMD)
    if "export_DeusExMD" in locals():
        imp.reload(export_DeusExMD)

import bpy

from bpy.props import (StringProperty,
                       BoolProperty,
                       FloatProperty,
                       EnumProperty,
                       )

from bpy_extras.io_utils import (ImportHelper,path_reference_mode)

  
class DeusExMDImportOperator(bpy.types.Operator, ImportHelper):
    bl_idname = "import_scene.deusexmd"
    bl_label = "DeusEx:MD Importer(.Dat/.Bin)"
    
    filename_ext = ".dat"
    skip_blank=False;

    randomize_colors = BoolProperty(\
        name="Random Material Colors",\
        description="Assigns a random color to each material",\
        default=True,\
        )

    import_vertcolors = BoolProperty(\
        name="Import Vertex Colors",\
        description="Import Vertex Colors",\
        default=False,\
        )
    
    use_layers = BoolProperty(\
        name="Seperate Mesh Layers",\
        description="Place Meshes on seperate layers",\
        default=True,\
        )
    mesh_scale = bpy.props.FloatProperty(
        name="Scale Factor",
        description="Mesh Import Scale Factor",
        default=1.0,
    )

    filter_glob = StringProperty(default="*.dat;*.bin") # , options={'HIDDEN'}
    filepath = bpy.props.StringProperty(subtype="FILE_PATH")        
    path_mode = path_reference_mode

    def execute(self, context):
        import os, sys
        print("Import Execute called")
        cmd_folder = os.path.dirname(os.path.abspath(__file__))
        if cmd_folder not in sys.path:
            sys.path.insert(0, cmd_folder)

        import import_DeusExMD
        result=import_DeusExMD.import_DeusExMD(self.filepath, bpy.context,self.randomize_colors,self.import_vertcolors,self.skip_blank,self.use_layers,self.mesh_scale)

        # force back off
        #self.skip_blank=False
        #self.use_layers=False
        
        if result is not None:
            self.report({'ERROR'},result)

        return {'FINISHED'}

    def invoke(self, context, event):

        print("Import Invoke called")
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        col.label('Mesh Scale Factor')
        col.prop(self, "mesh_scale")
        row = layout.row(align=True)
        row.prop(self, "randomize_colors")
        row = layout.row(align=True)
        row.prop(self, "import_vertcolors")
        row = layout.row(align=True)
        row.prop(self, "use_layers")

#
# Registration
#
def menu_func_import(self, context):
    self.layout.operator(DeusExMDImportOperator.bl_idname, text="dat(DeusEx:MD Model)(.dat/.bin)",icon='PLUGIN')
   
def register():
    bpy.utils.register_module(__name__)
    bpy.types.INFO_MT_file_import.append(menu_func_import)
    
def unregister():
    bpy.utils.unregister_module(__name__)
    bpy.types.INFO_MT_file_import.remove(menu_func_import)
    
if __name__ == "__main__":
    register()