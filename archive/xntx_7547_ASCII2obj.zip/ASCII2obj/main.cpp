// provided as is. Use it or ignore it. Maybe write better code than me but don't complain because: it works, bud
#include <windows.h>
#include <stdio.h>		// FILE

//#include <iostream>   // well, will blow up the exe for nothing here;-)

using namespace std;

void lin_faceind_3(FILE *stream, DWORD cnt)
{
	DWORD i, sm=0 ;			//

	for (i=1; i< (cnt - 3);i++) {
            //if (i==1000) fprintf( stream, "--- %d\n", i%1000) ;
        if ( (i % 2000) ==0) {
            fprintf( stream, "g sm_%lu\n", sm) ; sm++ ;
        }
		fprintf( stream, "f %ld/%ld %ld/%ld %ld/%ld\n", i,i, i+1,i+1, i+2,i+2) ;
		i += 2 ;
	}
}

DWORD GetWebgl_ASCII(FILE *stream, BYTE wahl)		// yeah, the name is bogus
{
	FILE * stream1 ;        //
	//char  s[512] ;		// in extrahierten vertices und faces - txt files: ',' ersetzt durch blank f�r fscanf()
	//BYTE wahl= 1 ;		// 0,1,2: faces, vertices, uvs
	DWORD cnt=0 ;
	int a,b,c,d,e,f,g,h,i, x, y, z ;
	int j,k,l,m,n,o,p ;

	switch (wahl) {
		case 1: stream1 = fopen( "vertices.txt", "r" ); break ;              //
		case 2: stream1 = fopen( "faces.txt", "r" ); break ;              //
		default: return 0 ;
	}
	if( stream1 == NULL ) {
		fprintf( stream, " The file ???.txt could not be opened!\n");
		printf(" The file ???.txt could not be opened!\n");
		return 0 ;
	}
	if (wahl==1) goto x ;
	if (wahl==2) goto y ;

x:
	/*while (fscanf( stream1, "%d, %d, ", &a, &b) != EOF) {
		fscanf( stream1, "%d, %d, %d, ", &x, &y, &z) ;
		fscanf( stream1, "%d, %d, %d, ", &c, &d, &e) ;
		fscanf( stream1, "%d, %d, %d, %d", &f, &g, &h, &i) ;
		fprintf(stream, "v %d %d %d\n", x,y*10,z*2) ; // z is die Tiefe
		cnt++ ;
		if (cnt>100000) break ;
	}   */
    while (fscanf( stream1, "%d, %d, ", &x, &y) != EOF) {
		fscanf( stream1, "%d, %d, %d, ", &z, &a, &b) ;
		fscanf( stream1, "%d, %d, %d, ", &c, &d, &e) ;
		fscanf( stream1, "%d, %d, %d, %d", &f, &g, &h, &i) ;
		//fprintf(stream, "v %d %d %d\n", x,y*10,z*2) ; // z is die Tiefe
		fprintf(stream, "v %d %d %d\n", x,y,z) ; // z is die Tiefe
		cnt++ ;
		if (cnt>100000) break ;
	}
	fclose (stream1) ;
	return cnt ;

y:
	while (fscanf( stream1, "%d, ", &x) != EOF) {
		fscanf( stream1, "%d, %d, ", &y, &z) ;
		fscanf( stream1, "%d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d", &a, &b, &c, &d, &e, &f, &g, &h, &i, &j, &k, &l, &m, &n, &o, &p) ;
		fprintf(stream, "f %d %d %d\n", x,y,z) ;
		cnt++ ;
	}
	fclose (stream1) ;
	return cnt ;
}


int main()
{
    FILE * stream ;
    DWORD cnt, vCnt ;

    stream = fopen( "test.obj", "w" );
    if( stream == NULL ) {
        printf("'test.obj' open error!\n") ;
        return (FALSE) ;
    }
    //vCnt= GetWebgl_ASCII(stream, 1) ;         // log vertices
    cnt= GetWebgl_ASCII(stream, 2) ;            // log face indices
    /*if ((vCnt==0)||(cnt==0)) printf("\nerror, count is zero: %ld verts, %ld uvs !\n", vCnt, cnt) ;
    //if (cnt!=vCnt) printf("\nproblem: %ld verts, %ld uvs !\n", vCnt, cnt) ;
    //if (vCnt>cnt) vCnt= cnt ;                   // "fix: "better than nothing
        */
    //lin_faceind_3(stream, vCnt) ;
    fclose(stream) ;
    //cout << "Hello world!" << endl;
    return 0;
}
