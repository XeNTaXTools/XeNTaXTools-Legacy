<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmEdit
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblPayLoad = New System.Windows.Forms.Label
        Me.txtPayLoad = New System.Windows.Forms.TextBox
        Me.btnSave = New System.Windows.Forms.Button
        Me.btnCancel = New System.Windows.Forms.Button
        Me.txtFuel = New System.Windows.Forms.TextBox
        Me.lblFuel = New System.Windows.Forms.Label
        Me.txtAcc = New System.Windows.Forms.TextBox
        Me.lblAcc = New System.Windows.Forms.Label
        Me.txtTurning = New System.Windows.Forms.TextBox
        Me.lblTurning = New System.Windows.Forms.Label
        Me.txtTopSpeed = New System.Windows.Forms.TextBox
        Me.lblTopSpeed = New System.Windows.Forms.Label
        Me.txtArmor = New System.Windows.Forms.TextBox
        Me.lblArmor = New System.Windows.Forms.Label
        Me.txtGun1 = New System.Windows.Forms.TextBox
        Me.lblGun1 = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'lblPayLoad
        '
        Me.lblPayLoad.AutoSize = True
        Me.lblPayLoad.Location = New System.Drawing.Point(13, 15)
        Me.lblPayLoad.Name = "lblPayLoad"
        Me.lblPayLoad.Size = New System.Drawing.Size(49, 13)
        Me.lblPayLoad.TabIndex = 0
        Me.lblPayLoad.Text = "PayLoad"
        '
        'txtPayLoad
        '
        Me.txtPayLoad.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtPayLoad.Location = New System.Drawing.Point(97, 12)
        Me.txtPayLoad.Name = "txtPayLoad"
        Me.txtPayLoad.Size = New System.Drawing.Size(111, 20)
        Me.txtPayLoad.TabIndex = 1
        '
        'btnSave
        '
        Me.btnSave.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSave.Location = New System.Drawing.Point(133, 199)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(75, 23)
        Me.btnSave.TabIndex = 2
        Me.btnSave.Text = "&Save"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnCancel.Location = New System.Drawing.Point(16, 199)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(75, 23)
        Me.btnCancel.TabIndex = 3
        Me.btnCancel.Text = "&Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'txtFuel
        '
        Me.txtFuel.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtFuel.Location = New System.Drawing.Point(97, 38)
        Me.txtFuel.Name = "txtFuel"
        Me.txtFuel.Size = New System.Drawing.Size(111, 20)
        Me.txtFuel.TabIndex = 5
        '
        'lblFuel
        '
        Me.lblFuel.AutoSize = True
        Me.lblFuel.Location = New System.Drawing.Point(13, 41)
        Me.lblFuel.Name = "lblFuel"
        Me.lblFuel.Size = New System.Drawing.Size(27, 13)
        Me.lblFuel.TabIndex = 4
        Me.lblFuel.Text = "Fuel"
        '
        'txtAcc
        '
        Me.txtAcc.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtAcc.Location = New System.Drawing.Point(97, 64)
        Me.txtAcc.Name = "txtAcc"
        Me.txtAcc.Size = New System.Drawing.Size(111, 20)
        Me.txtAcc.TabIndex = 7
        '
        'lblAcc
        '
        Me.lblAcc.AutoSize = True
        Me.lblAcc.Location = New System.Drawing.Point(13, 67)
        Me.lblAcc.Name = "lblAcc"
        Me.lblAcc.Size = New System.Drawing.Size(26, 13)
        Me.lblAcc.TabIndex = 6
        Me.lblAcc.Text = "Acc"
        '
        'txtTurning
        '
        Me.txtTurning.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtTurning.Location = New System.Drawing.Point(97, 90)
        Me.txtTurning.Name = "txtTurning"
        Me.txtTurning.Size = New System.Drawing.Size(111, 20)
        Me.txtTurning.TabIndex = 9
        '
        'lblTurning
        '
        Me.lblTurning.AutoSize = True
        Me.lblTurning.Location = New System.Drawing.Point(13, 93)
        Me.lblTurning.Name = "lblTurning"
        Me.lblTurning.Size = New System.Drawing.Size(43, 13)
        Me.lblTurning.TabIndex = 8
        Me.lblTurning.Text = "Turning"
        '
        'txtTopSpeed
        '
        Me.txtTopSpeed.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtTopSpeed.Location = New System.Drawing.Point(97, 116)
        Me.txtTopSpeed.Name = "txtTopSpeed"
        Me.txtTopSpeed.Size = New System.Drawing.Size(111, 20)
        Me.txtTopSpeed.TabIndex = 11
        '
        'lblTopSpeed
        '
        Me.lblTopSpeed.AutoSize = True
        Me.lblTopSpeed.Location = New System.Drawing.Point(13, 119)
        Me.lblTopSpeed.Name = "lblTopSpeed"
        Me.lblTopSpeed.Size = New System.Drawing.Size(60, 13)
        Me.lblTopSpeed.TabIndex = 10
        Me.lblTopSpeed.Text = "Top Speed"
        '
        'txtArmor
        '
        Me.txtArmor.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtArmor.Location = New System.Drawing.Point(97, 142)
        Me.txtArmor.Name = "txtArmor"
        Me.txtArmor.Size = New System.Drawing.Size(111, 20)
        Me.txtArmor.TabIndex = 13
        '
        'lblArmor
        '
        Me.lblArmor.AutoSize = True
        Me.lblArmor.Location = New System.Drawing.Point(13, 145)
        Me.lblArmor.Name = "lblArmor"
        Me.lblArmor.Size = New System.Drawing.Size(34, 13)
        Me.lblArmor.TabIndex = 12
        Me.lblArmor.Text = "Armor"
        '
        'txtGun1
        '
        Me.txtGun1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtGun1.Location = New System.Drawing.Point(97, 168)
        Me.txtGun1.Name = "txtGun1"
        Me.txtGun1.Size = New System.Drawing.Size(111, 20)
        Me.txtGun1.TabIndex = 15
        '
        'lblGun1
        '
        Me.lblGun1.AutoSize = True
        Me.lblGun1.Location = New System.Drawing.Point(13, 171)
        Me.lblGun1.Name = "lblGun1"
        Me.lblGun1.Size = New System.Drawing.Size(36, 13)
        Me.lblGun1.TabIndex = 14
        Me.lblGun1.Text = "Gun 1"
        '
        'frmEdit
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(220, 234)
        Me.Controls.Add(Me.txtGun1)
        Me.Controls.Add(Me.lblGun1)
        Me.Controls.Add(Me.txtArmor)
        Me.Controls.Add(Me.lblArmor)
        Me.Controls.Add(Me.txtTopSpeed)
        Me.Controls.Add(Me.lblTopSpeed)
        Me.Controls.Add(Me.txtTurning)
        Me.Controls.Add(Me.lblTurning)
        Me.Controls.Add(Me.txtAcc)
        Me.Controls.Add(Me.lblAcc)
        Me.Controls.Add(Me.txtFuel)
        Me.Controls.Add(Me.lblFuel)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.txtPayLoad)
        Me.Controls.Add(Me.lblPayLoad)
        Me.MinimumSize = New System.Drawing.Size(228, 268)
        Me.Name = "frmEdit"
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.Text = "Edit Zone66 Ship"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblPayLoad As System.Windows.Forms.Label
    Friend WithEvents txtPayLoad As System.Windows.Forms.TextBox
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents txtFuel As System.Windows.Forms.TextBox
    Friend WithEvents lblFuel As System.Windows.Forms.Label
    Friend WithEvents txtAcc As System.Windows.Forms.TextBox
    Friend WithEvents lblAcc As System.Windows.Forms.Label
    Friend WithEvents txtTurning As System.Windows.Forms.TextBox
    Friend WithEvents lblTurning As System.Windows.Forms.Label
    Friend WithEvents txtTopSpeed As System.Windows.Forms.TextBox
    Friend WithEvents lblTopSpeed As System.Windows.Forms.Label
    Friend WithEvents txtArmor As System.Windows.Forms.TextBox
    Friend WithEvents lblArmor As System.Windows.Forms.Label
    Friend WithEvents txtGun1 As System.Windows.Forms.TextBox
    Private WithEvents lblGun1 As System.Windows.Forms.Label
End Class
