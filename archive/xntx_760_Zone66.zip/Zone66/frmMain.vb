Public Class frmMain
#Region " Private Constants "
    Private Const StructSize As Integer = 43
#End Region
#Region " Functions "
    Private Function Example() As Zone66Ship
        Dim Result As New Zone66Ship
        Dim SourceFile As String = BrowseForFile("C:\", "zone66 files (*.z66)|*.z66")
        If Not String.IsNullOrEmpty(SourceFile) Then
            Dim MyShip As Zone66Ship = GetZone66Ship(SourceFile, 0)
        Else
            MsgBox("No source file was selected")
        End If
        Return Result
    End Function
    Private Function GetZone66Ship(ByVal FileName As String, ByVal StartPosition As Int64) As Zone66Ship
        Dim Result As New Zone66Ship
        If System.IO.File.Exists(FileName) Then
            ' The "Using" constructor ensures us that
            ' if something goes wrong, everything will be handled as it should
            ' (Handles get closed, memory is released, this is because of the IDisposable interface).
            Using BR As New IO.BinaryReader(New IO.FileStream(FileName, IO.FileMode.Open))
                If StartPosition < BR.BaseStream.Length Then
                    If BR.BaseStream.Length >= StructSize + BR.BaseStream.Position Then
                        ' Jump to the position in memory
                        BR.BaseStream.Seek(StartPosition, IO.SeekOrigin.Begin)
                        Result.Padding = BR.ReadBytes(36)
                        Result.PayLoad = BR.ReadByte
                        Result.Fuel = BR.ReadByte
                        Result.Acc = BR.ReadByte
                        Result.Turning = BR.ReadByte
                        Result.TopSpeed = BR.ReadByte
                        Result.Armor = BR.ReadByte
                        Result.Gun1 = BR.ReadByte
                    Else
                        MsgBox("Not enough bytes left to read")
                    End If
                Else
                    MsgBox(String.Format("The position {0} lies beyond the length of file File '{1}' (MAX = {2})!", StartPosition, FileName, BR.BaseStream.Length))
                End If
            End Using
        Else
            MsgBox(String.Format("File '{0}' does not exist!", FileName))
        End If
        Return Result
    End Function
#End Region
#Region " Helper Functions "
    Private Function BrowseForFile(ByVal InitialDir As String, ByVal Filter As String) As String
        ' Initialize Result to avoid warnings since we will return
        ' this variable, even if a user doesn't select a file
        Dim Result As String = String.Empty
        ' Create a new OpenFileDialog
        Dim ofd As New OpenFileDialog()
        ' Set the specified Start directory
        ofd.InitialDirectory = InitialDir
        ' Set the file filter
        ofd.Filter = Filter
        ' Make sure that if this function get's called again,
        ' the previous selected folder will be the next base dir
        ofd.RestoreDirectory = True
        ' Calling ShowDialog() returns a Dialog result.
        ' We should only take action if the user pressed OK to select
        ' the file. There is no need to do a check afterwards if 
        ' the file exists (as you would do when normaly accepting
        ' file input, since this OFD does these checks for us).
        If ofd.ShowDialog = Windows.Forms.DialogResult.OK Then
            Result = ofd.FileName
        End If
        ' Return the result variable, which could be empty, or hold the filename
        Return Result
    End Function
    Private Function BrowseForFileSteam(ByVal InitialDir As String, ByVal Filter As String) As System.IO.Stream
        ' Initialize Result to avoid warnings since we will return
        ' this variable, even if a user doesn't select a file
        Dim Result As System.IO.Stream = Nothing
        ' Create a new OpenFileDialog
        Dim ofd As New OpenFileDialog()
        ' Set the specified Start directory
        ofd.InitialDirectory = InitialDir
        ' Set the file filter
        ofd.Filter = Filter
        ' Make sure that if this function get's called again,
        ' the previous selected folder will be the next base dir
        ofd.RestoreDirectory = True
        ' Calling ShowDialog() returns a Dialog result.
        ' We should only take action if the user pressed OK to select
        ' the file. There is no need to do a check afterwards if 
        ' the file exists (as you would do when normaly accepting
        ' file input, since this OFD does these checks for us).
        If ofd.ShowDialog = Windows.Forms.DialogResult.OK Then
            Result = ofd.OpenFile
        End If
        ' Return the result variable, which could be empty, or hold the filename
        Return Result
    End Function
#End Region
End Class
Public Structure Zone66Ship
    Dim Padding() As Byte ' 36 bytes
    Dim PayLoad As Byte
    Dim Fuel As Byte
    Dim Acc As Byte
    Dim Turning As Byte
    Dim TopSpeed As Byte
    Dim Armor As Byte
    Dim Gun1 As Byte ' Total should be 43 bytes.
End Structure