Public Class frmEdit
    ' this is just a simple example, you'd want
    ' to validate input better, but that takes
    ' to much time for this simple example
#Region " Public Properties "
    Public Property PayLoad() As Byte
        Get
            Return GetByteFromString(txtPayLoad.Text)
        End Get
        Set(ByVal value As Byte)
            txtPayLoad.Text = value.ToString
        End Set
    End Property
    Public Property Fuel() As Byte
        Get
            Return GetByteFromString(txtFuel.Text)
        End Get
        Set(ByVal value As Byte)
            txtFuel.Text = value.ToString
        End Set
    End Property
    Public Property Acc() As Byte
        Get
            Return GetByteFromString(txtAcc.Text)
        End Get
        Set(ByVal value As Byte)
            txtAcc.Text = value.ToString
        End Set
    End Property
    Public Property Turning() As Byte
        Get
            Return GetByteFromString(txtTurning.Text)
        End Get
        Set(ByVal value As Byte)
            txtTurning.Text = value.ToString
        End Set
    End Property
    Public Property TopSpeed() As Byte
        Get
            Return GetByteFromString(txtTopSpeed.Text)
        End Get
        Set(ByVal value As Byte)
            txtTopSpeed.Text = value.ToString
        End Set
    End Property
    Public Property Armor() As Byte
        Get
            Return GetByteFromString(txtArmor.Text)
        End Get
        Set(ByVal value As Byte)
            txtArmor.Text = value.ToString
        End Set
    End Property
    Public Property Gun1() As Byte
        Get
            Return GetByteFromString(txtGun1.Text)
        End Get
        Set(ByVal value As Byte)
            txtGun1.Text = value.ToString
        End Set
    End Property
    ' This smart property ensures you maximum flexibility
    ' with geting and setting the values various ways
    Public Property Zone66Ship() As Zone66Ship
        Get
            Dim Result As New Zone66Ship
            Result.PayLoad = PayLoad
            Result.Fuel = Fuel
            Result.Acc = Acc
            Result.Turning = Turning
            Result.Armor = Armor
            Result.Gun1 = Gun1
            Return Result
        End Get
        Set(ByVal value As Zone66Ship)
            PayLoad = value.PayLoad
            Fuel = value.Fuel
            Acc = value.Acc
            Turning = value.Turning
            Armor = value.Armor
            Gun1 = value.Gun1
        End Set
    End Property
#End Region
#Region " Help Functions "
    Private Function GetByteFromString(ByVal Value As String) As Byte
        Dim Result As Byte
        ' If TryParse fails, Result becomes 0
        If Not Byte.TryParse(txtPayLoad.Text, Result) Then
            Debug.WriteLine(String.Format("'{0}' is not a valid byte", txtPayLoad))
        End If
        Return Result
    End Function
#End Region
#Region " Event Handlers "
    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        ' Setting the DialogResult property automaticly closes the form
        Me.DialogResult = Windows.Forms.DialogResult.Cancel
    End Sub
    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        ' Setting the DialogResult property automaticly closes the form
        Me.DialogResult = Windows.Forms.DialogResult.OK
    End Sub
#End Region
End Class