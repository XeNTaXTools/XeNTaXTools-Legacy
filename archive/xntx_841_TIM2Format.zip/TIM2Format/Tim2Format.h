///============================================================================
/// \file		Tim2Format.h
/// \brief		Header file for Tim2 Format Photoshop plugin
/// \date		07-16-2005
/// \author		Silverado
///============================================================================

#ifndef _TIM2FORMAT_H
#define _TIM2FORMAT_H

class CTim2FormatApp : public CWinApp
{
public:
	typedef void (CTim2FormatApp::*SELECTORCALLBACK)(FormatRecord *formatParamsBlock,
									long *data,
									short *result);
	struct SELECTORTOFUNCMAP
	{
		short selector;
		SELECTORCALLBACK cb;
	};

// method overrides
	virtual BOOL InitInstance();

// public exposed methods
	CTim2FormatApp();

	// handles selector function from paint program
	void HandleSelector(const short selector, 
						FormatRecord *formatParamsBlock,
						long *data,
						short *result);

	/// display about box
	/// \param formatParamsBlock -
	/// \param data - data specific to selector
	/// \param result - short pointer to return result into
	void About(FormatRecord *formatParamsBlock,
		long *data,
		short *result);

	/// display about box
	/// \param formatParamsBlock -
	/// \param data - data specific to selector
	/// \param result - short pointer to return result into
	void ReadPrepare(FormatRecord *formatParamsBlock,
		long *data,
		short *result);
	/// display about box
	/// \param formatParamsBlock -
	/// \param data - data specific to selector
	/// \param result - short pointer to return result into
	void ReadStart(FormatRecord *formatParamsBlock,
		long *data,
		short *result);

	/// display about box
	/// \param formatParamsBlock -
	/// \param data - data specific to selector
	/// \param result - short pointer to return result into
	void ReadContinue(FormatRecord *formatParamsBlock,
		long *data,
		short *result);

	/// display about box
	/// \param formatParamsBlock -
	/// \param data - data specific to selector
	/// \param result - short pointer to return result into
	void ReadFinish(FormatRecord *formatParamsBlock,
		long *data,
		short *result);

	/// display about box
	/// \param formatParamsBlock -
	/// \param data - data specific to selector
	/// \param result - short pointer to return result into
	void OptionsPrepare(FormatRecord *formatParamsBlock,
		long *data,
		short *result);

	/// display about box
	/// \param formatParamsBlock -
	/// \param data - data specific to selector
	/// \param result - short pointer to return result into
	void OptionsStart(FormatRecord *formatParamsBlock,
		long *data,
		short *result);

	/// display about box
	/// \param formatParamsBlock -
	/// \param data - data specific to selector
	/// \param result - short pointer to return result into
	void OptionsContinue(FormatRecord *formatParamsBlock,
		long *data,
		short *result);

	/// display about box
	/// \param formatParamsBlock -
	/// \param data - data specific to selector
	/// \param result - short pointer to return result into
	void OptionsFinish(FormatRecord *formatParamsBlock,
		long *data,
		short *result);

	/// display about box
	/// \param formatParamsBlock -
	/// \param data - data specific to selector
	/// \param result - short pointer to return result into
	void EstimatePrepare(FormatRecord *formatParamsBlock,
		long *data,
		short *result);

	/// display about box
	/// \param formatParamsBlock -
	/// \param data - data specific to selector
	/// \param result - short pointer to return result into
	void EstimateStart(FormatRecord *formatParamsBlock,
		long *data,
		short *result);

	/// display about box
	/// \param formatParamsBlock -
	/// \param data - data specific to selector
	/// \param result - short pointer to return result into
	void EstimateContinue(FormatRecord *formatParamsBlock,
		long *data,
		short *result);

	/// display about box
	/// \param formatParamsBlock -
	/// \param data - data specific to selector
	/// \param result - short pointer to return result into
	void EstimateFinish(FormatRecord *formatParamsBlock,
		long *data,
		short *result);

	/// display about box
	/// \param formatParamsBlock -
	/// \param data - data specific to selector
	/// \param result - short pointer to return result into
	void WritePrepare(FormatRecord *formatParamsBlock,
		long *data,
		short *result);

	/// display about box
	/// \param formatParamsBlock -
	/// \param data - data specific to selector
	/// \param result - short pointer to return result into
	void WriteStart(FormatRecord *formatParamsBlock,
		long *data,
		short *result);

	/// display about box
	/// \param formatParamsBlock -
	/// \param data - data specific to selector
	/// \param result - short pointer to return result into
	void WriteContinue(FormatRecord *formatParamsBlock,
		long *data,
		short *result);

	/// display about box
	/// \param formatParamsBlock -
	/// \param data - data specific to selector
	/// \param result - short pointer to return result into
	void WriteFinish(FormatRecord *formatParamsBlock,
		long *data,
		short *result);

	/// display about box
	/// \param formatParamsBlock -
	/// \param data - data specific to selector
	/// \param result - short pointer to return result into
	void FilterFile(FormatRecord *formatParamsBlock,
		long *data,
		short *result);


// private methods
private:
	void UnlockHandle(HandleProcs *procs, Handle h);
	BOOL ProcsAvailable(HandleProcs *procs, BOOL *outNewerVersion);
	void UnInterleaveData(DWORD row, DWORD plane, DWORD bytesPerColor);
	void InterleaveData(DWORD row, DWORD plane, DWORD bytesPerColor, BYTE *srcData);

// private attributes
private:
	DECLARE_MESSAGE_MAP()
	static const SELECTORTOFUNCMAP m_SelectorToRoutine[];
	void *m_CurTimFile;
	BYTE *m_RowData;
	TIM2_PICTUREHEADER *m_ImageHeader;
	TIM2_PICTUREHEADER m_LocalImageHeader;
	BYTE m_PaletteData[256*4];
};

#endif		//#ifndef _TIM2FORMAT_H
