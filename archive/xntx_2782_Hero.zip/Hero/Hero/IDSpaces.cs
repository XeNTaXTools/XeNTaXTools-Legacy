﻿namespace Hero
{
    using System;

    public enum IDSpaces
    {
        ClientTemporaryNode,
        ServerTemporaryNode,
        ServerPersistantNode,
        ServerSystemNode
    }
}

