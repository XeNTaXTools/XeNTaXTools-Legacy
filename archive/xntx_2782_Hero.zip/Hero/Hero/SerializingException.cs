﻿namespace Hero
{
    using System;

    public class SerializingException : Exception
    {
        public SerializingException(string message) : base(message)
        {
        }
    }
}

