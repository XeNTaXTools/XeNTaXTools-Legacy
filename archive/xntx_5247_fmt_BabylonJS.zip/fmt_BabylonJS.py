from inc_noesis import *
import noesis
import rapi
import os

def registerNoesisTypes():
   handle = noesis.register("BabylonJS", ".babylonbinarymeshdata")
   noesis.setHandlerTypeCheck(handle, noeCheckGeneric)
   noesis.setHandlerLoadModel(handle, noepyLoadModel)
   #noesis.logPopup()
   return 1

def noepyLoadModel(data, mdlList):
	ctx = rapi.rpgCreateContext()
	rapi.setPreviewOption("setAngOfs","0 290 140")       #sets the default preview angle        
	rapi.rpgSetOption(noesis.RPGOPT_TRIWINDBACKWARD, 1)  #flip the normals
	bs = NoeBitStream(data)
	fileName = os.path.basename(rapi.getInputName())     #get file name + ext without path
	if "48_R" in fileName:
		bs.seek(0x0, NOESEEK_ABS)
		VBuf = bs.readBytes(8275 * 12)
		rapi.rpgBindPositionBufferOfs(VBuf, noesis.RPGEODATA_FLOAT, 12, 0)   #start position of vertices
		NBuf = bs.readBytes(8275 * 12)
		rapi.rpgBindNormalBufferOfs(NBuf, noesis.RPGEODATA_FLOAT, 12, 0)     #start normals
		UVBuf = bs.readBytes(8275 * 8)
		rapi.rpgBindUV1BufferOfs(UVBuf, noesis.RPGEODATA_FLOAT, 8, 0)        #start UVs
		IBuf = bs.readBytes(47808 * 4)                                      #multiply by 4 for dword indices
		rapi.rpgCommitTriangles(IBuf, noesis.RPGEODATA_INT, 47808, noesis.RPGEO_TRIANGLE, 1) #INT for dword, SHORT for word indices
		mdl = rapi.rpgConstructModel()
		mdlList.append(mdl)
		rapi.rpgClearBufferBinds()
		return 1
	bs.seek(len(data) - 0x0C, NOESEEK_ABS)
	VCount = bs.readInt()                                #vertex count
	bs.seek(0x04, NOESEEK_REL)
	FCount = bs.readInt()                                #face indices count
	bs.seek(0x0, NOESEEK_ABS)
	VBuf = bs.readBytes(VCount * 12)
	rapi.rpgBindPositionBufferOfs(VBuf, noesis.RPGEODATA_FLOAT, 12, 0)   #start position of vertices
	NBuf = bs.readBytes(VCount * 12)
	rapi.rpgBindNormalBufferOfs(NBuf, noesis.RPGEODATA_FLOAT, 12, 0)     #start normals
	UVBuf = bs.readBytes(VCount * 8)
	rapi.rpgBindUV1BufferOfs(UVBuf, noesis.RPGEODATA_FLOAT, 8, 0)        #start UVs
	IBuf = bs.readBytes(FCount * 4)                                      #multiply by 4 for dword indices
	rapi.rpgCommitTriangles(IBuf, noesis.RPGEODATA_INT, FCount, noesis.RPGEO_TRIANGLE, 1) #INT for dword, SHORT for word indices
	mdl = rapi.rpgConstructModel()
	mdlList.append(mdl)
	rapi.rpgClearBufferBinds()
	return 1