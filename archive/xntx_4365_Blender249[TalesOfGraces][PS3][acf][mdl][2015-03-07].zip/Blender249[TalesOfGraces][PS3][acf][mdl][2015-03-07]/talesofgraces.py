import newGameLib
from newGameLib import *
import Blender

def acfParser(filename,g):
	g.endian='>'
	string=g.word(4)	
	v=g.i(7)		
	g.seek(v[1])	
	unp=Unpacker()
	unp.inputFile=filename
	unp.outputDir=g.dirname+os.sep+g.basename
	for m in range(v[0]):
		t=g.tell()
		v1=g.i(3)
		string=g.word(32)
		if v1[1]!=0:
			unp.nameList.append(string)
			unp.offsetList.append(v1[0])
			unp.sizeList.append(v1[1])
		g.seek(t+48)
	unp.unpack()	
		
def getInfoimageListInfo(g):
	off=g.tell()
	v=g.i(5)
	imageListInfo=[]
	for m in range(v[3]):
		t=g.tell()
		v1=g.i(7)
		g.seek(t+v1[5]+20)
		name=g.find('\x00')
		imageListInfo.append([v1,name,off+v[1]+v1[6]])
		g.seek(t+28)
	for ID in range(v[3]):
		img=Image()
		img.name=g.dirname+os.sep+'textures'+os.sep+imageListInfo[ID][1]+'.dds'
		img.szer=imageListInfo[ID][0][1]
		img.wys=imageListInfo[ID][0][2]
		if imageListInfo[ID][0][4]==-2012960028:img.format='DXT5'
		elif imageListInfo[ID][0][4]==-2046645532:img.format='DXT1'
		else:print 'WARNING:unknow image format',hex(imageListInfo[ID][0][4])
		g.seek(imageListInfo[ID][2]+16)
		if ID==v[3]-1:img.data=g.read(g.fileSize()-g.tell())
		else:img.data=g.read(imageListInfo[ID+1][0][6]-imageListInfo[ID][0][6])
		img.draw()
		
		
def getMat(g):
	off=g.tell()
	v=g.i(5)
	List=[]
	for m in range(v[3]):
		mat=Mat()		
		t=g.tell()
		v1=g.i(10)
		if v1[0]==2:g.i(2)
		if v1[0]==3:g.i(4)
		matList[str(v1[1])]=mat
		List.append(matList[str(v1[1])])	
	g.i(1)			
	for m in range(v[3]):
		t=g.tell()
		v1=g.i(6)
		g.seek(t+v1[0])
		name=g.find('\x00')
		mat.name=name
		if v1[2]==0:
			g.seek(t+v1[3]+12)
			name=g.find('\x00')
		else:
			g.seek(t+v1[2]+8)
			name=g.find('\x00')
			g.seek(t+v1[5]+20)
			name=g.find('\x00')
		mat.diffuse=g.dirname+os.sep+'textures'+os.sep+name+'.dds'
		g.seek(t+24)
		List[m].diffuse=g.dirname+os.sep+'textures'+os.sep+name+'.dds'
			

		
def getInfoMat(g):
	v=g.i(8)

def getMesh(offList,g):	
	off=g.tell()
	v=g.i(9)
	list0=[]
	for m in range(v[3]):
		v1=g.f(4)
		v2=g.i(4)
		list0.append(v2)
	for m in range(v[3]):
		v1=g.f(4)	
	for m in range(v[3]):
		v0=g.B(4)
		v1=g.i(7)
		v2=g.i(7)
		matID=v1[3]		
		type=v2[1]		
		start=g.tell()		
		g.seek(start+v2[5]-8)
		name=g.find('\x00')			
		faceslist_list=[]
		g.seek(start+v1[5]-36)
		v5=g.i(1)[0]	
		list5=[]
		for n in range(v5):
			data=g.H(2)
			list5.append(data)
		IDStart=0
		IDCount=0
		meshList=[]
		for n in range(v5):
			mesh=Mesh()	
			mesh.matID=matID
			mat=Mat()
			mat.ZTRANS=True
			mat.TRISTRIP=True
			mesh.indiceList=g.H(list5[n][1])
			mesh.matList.append(mat)
			mesh.boneHash=v1[2]	
			meshList.append(mesh)
		g.seek(off+offList[1]+v1[4])
		vertUVList=[]	
		for n in range(v2[2]):
			g.i(1)
			vn=g.f(2)
			vertUVList.append(vn)
		g.seek(start+v1[6]-32)	
		if v0[2]==7:
			uvIDStart=0
			uvIDCount=0	
			for k in range(v5):	
				mesh=meshList[k]
				for n in range(list5[k][0]):
					t=g.tell()
					vn=g.f(3)
					mesh.vertPosList.append(vn)
					if type==241:g.seek(t+28)	
					elif type==753:g.seek(t+12)
					elif type==754:g.seek(t+12)
					else:print 'unknow stride for ',type					
				for n in range(list5[k][0]):
					vn=g.f(3)				
				v6=g.i(1)[0]
				uvIDCount=list5[k][0]
				mesh.vertUVList=vertUVList[uvIDStart:uvIDStart+uvIDCount]
				uvIDStart+=uvIDCount					
		elif v0[2]==1:
			list1=list0[m]
			uvIDStart=0
			uvIDCount=0	
			for k in range(v5):	
				mesh=meshList[k]
				skin=Skin()
				mesh.skinList.append(skin)	
				vertexlist=[]
				for n in range(list1[0]):
					t=g.tell()
					v3=g.f(3)
					vertexlist.append(v3)
					g.seek(t+24)
					v4=g.B(4)
					mesh.skinIndiceList.append([v4[0]])
					mesh.skinWeightList.append([1.0])	
					g.seek(t+28)						
				for n in range(list1[1]):
					t=g.tell()
					v3=g.f(3)
					g.seek(t+24)
					v4=g.B(4)
					v5=g.f(1)[0]
					mesh.skinIndiceList.append(v4[:2])
					mesh.skinWeightList.append([v5,1.0-v5])	
					vertexlist.append(v3)
					g.seek(t+32)
						
				for n in range(list1[2]):
					t=g.tell()
					v3=g.f(3)
					vertexlist.append(v3)
					g.seek(t+24)
					v4=g.B(4)
					v5=g.f(1)[0]
					v6=g.f(1)[0]
					mesh.skinIndiceList.append(v4[:3])
					mesh.skinWeightList.append([v5,v6,1.0-v5-v6])	
					g.seek(t+36)
						
				for n in range(list1[3]):
					t=g.tell()
					v3=g.f(3)
					vertexlist.append(v3)
					g.seek(t+24)
					v4=g.B(4)
					v5=g.f(1)[0]
					v6=g.f(1)[0]
					v7=g.f(1)[0]
					mesh.skinIndiceList.append(v4)
					mesh.skinWeightList.append([v5,v6,v7,1.0-v5-v6-v7])	
					g.seek(t+40)
						
				list1=g.i(4)
				uvIDCount=list5[k][0]
				mesh.vertUVList=vertUVList[uvIDStart:uvIDStart+uvIDCount]	
				mesh.vertPosList=vertexlist
				uvIDStart+=uvIDCount
				
		
		
		g.seek(start)
		modelList.append(meshList)
	boneMapList=g.i(v[4])
	return boneMapList
		
		
def getBones(filename,g):
	A=g.i(5)+g.H(2)+g.i(1)
	boneHashList=g.i(A[3])
	for m in range(A[3]):
		bone=Bone()
		B=g.i(8)
		#print B	
		if B[1]!=-1:
			bone.parentID=boneHashList.index(B[1])
		t=g.tell()
		g.seek(t+B[6]-8)
		bone.name=g.find('\x00')
		g.seek(t)
		skeleton.boneList.append(bone)
	for m in range(A[4]):
		g.f(4)
		g.f(4)
		g.f(4)
		g.f(4)
	for m in range(A[6]):
		g.i(3)	
		g.f(6)	
	for m in range(A[3]):
		g.f(3)
		rotMatrix=QuatMatrix(g.f(4)).resize4x4()
		posMatrix=VectorMatrix(g.f(3))
		skeleton.boneList[m].matrix=rotMatrix*posMatrix
		g.f(2)
	skeleton.draw()
	return boneHashList
	

def fps4Parser(filename,g):
	global modelList
	global matList
	global skeleton
	
	skeleton=Skeleton()
	skeleton.ARMATURESPACE=True
	skeleton.SORT=True
	matList={}
	modelList=[]
	boneMapList=[]
	boneHashList=[]
	
	offset=g.tell()-4
	v=g.i(6)
	if v[0]==10:
		g.seek(offset+v[1])
		
		for m in range(v[0]):
			vm=g.i(3)	
			tm=g.tell()
			g.seek(offset+vm[0])
			if m==0:boneHashList=getBones(filename,g)
			if m==1:boneMapList=getMesh(vm,g)
			if m==4:getInfoMat(g)	
			if m==5:getMat(g)
			if m==6:pass
			if m==7:getInfoimageListInfo(g)
			if m==8:pass
			g.seek(tm)
			
		boneNameList=[]
		for hash in boneMapList:
			if hash in boneHashList:
				id=boneHashList.index(hash)
				boneNameList.append(skeleton.boneNameList[id])
			else:
				boneNameList.append(str(hash))
			
			
		for model in modelList:		
			for mesh in model:
				if len(mesh.skinList)==0:
					if mesh.boneHash in boneHashList:
						for m in range(len(mesh.vertPosList)):
							mesh.skinIndiceList.append([boneMapList.index(mesh.boneHash)])
							mesh.skinWeightList.append([1.0])
						skin=Skin()
						mesh.skinList.append(skin)	
					else:print 'WARNING:unknow bone hash'	
				mesh.matList[0].diffuse=matList[str(mesh.matID)].diffuse
				if len(boneNameList)>0:
					mesh.boneNameList=boneNameList
				mesh.BINDSKELETON=skeleton.name
				mesh.draw()
		
	
def mdlParser(filename,g):
	g.endian='>'
	name=g.word(4)
	if name=='FPS4':
		fps4Parser(filename,g)
	
def Parser():	
	filename=input.filename
	print '='*70
	print filename
	print '='*70
	ext=filename.split('.')[-1].lower()
	
	
	if ext=='acf':		
		file=open(filename,'rb')
		g=BinaryReader(file)		
		acfParser(filename,g)
		file.close()
	
	if ext=='mdl':
		file=open(filename,'rb')
		g=BinaryReader(file)
		mdlParser(filename,g)
		file.close()
 
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
	
Blender.Window.FileSelector(openFile,'import','Tales of Graces PS3 files: *.acf - archive, *.mdl - model') 
	