import newGameLib
from newGameLib import *
import Blender	
class Model():
	pass

def binParser(filename,g):
	g.logOpen()
	
	txt=open('log.txt','w')
	
	#g.debug=True
	A=g.i(11)
	g.seek(A[3])
	modelOffsetList=g.i(A[1])
	g.seek(A[4])
	g.i(A[1])
	g.i(10)
	g.i(10)
	print
	
	modelList=[]
	id=0
	for m in range(A[1]):
		print '='*30 
		meshList=[]
		model=Model()
		modelList.append(model)
		g.seek(modelOffsetList[m])
		txt.write('model-'+str(m)+':off:'+str(g.tell())+'\n')
		tt=g.tell()
		X=g.H(4)
		txt.write(' '*4+str(tt)+':'+str(X)+'\n')
		tt=g.tell()
		X=g.f(4)
		txt.write(' '*4+str(tt)+':'+str(X)+'\n')
		tt=g.tell()
		B=g.i(15)
		#txt.write(' '*4+str(B)+'\n')
		txt.write(' '*4+str(tt)+':'+str(B)+'\n')
		#mesh=Mesh()
		#meshList.append(mesh)
		t=g.tell()
		print t
		for n in range(B[0]):
			mesh=Mesh()
			skin=Skin()
			mesh.skinList.append(skin)
			txt.write('='*50+str(id)+'\n')
			id+=1
			meshList.append(mesh)
			tt=g.tell()
			X=g.f(4)	
			txt.write(' '*8+str(tt)+':'+str(X)+'\n')
			tt=g.tell()
			A=g.i(5)
			txt.write(' '*8+str(tt)+':'+str(A)+'\n')
			mesh.start=modelOffsetList[m]+A[1]
			mesh.vertCount=A[4]
			tt=g.tell()
			mesh.offsetList=g.i(13)
			txt.write(' '*8+str(tt)+':'+str(mesh.offsetList)+'\n')
			#g.seek(60,1)
			tt=g.tell()
			X=g.i(15)
			txt.write(' '*8+str(tt)+':'+str(A)+'\n')
			X=g.word(68)
			txt.write(' '*8+str(tt)+':'+str(X)+'\n')
			t=g.tell()
			
			g.seek(mesh.start)
			#txt.write(' '*12+str(g.tell())+'\n')
			tt=g.tell()
			floats=g.f(5)
			txt.write(' '*12+str(tt)+':'+str(floats)+'\n')
			#g.seek(modelOffsetList[m]+A[3])			
			#B=g.f(5)
			tt=g.tell()
			C=g.i(18)
			#txt.write(' '*12+str(B)+'\n')
			txt.write(' '*12+str(tt)+':'+str(C)+'\n')
			for k in range(13):
				if mesh.offsetList[k]!=0:	
					g.seek(modelOffsetList[m]+mesh.offsetList[k])
					#print k,g.tell()
					txt.write(str(k)+'\n')
					if k==0:		
						for a in range(mesh.vertCount):
							pos=g.f(3)
							txt.write(' '*16+str(g.tell()-12)+' '+str(a)+' pos:'+str(pos)+'\n')
							mesh.vertPosList.append(pos)
					if k==1:
						for a in range(mesh.vertCount):g.seek(12,1)
					if k==2:
						for a in range(mesh.vertCount):
							g.seek(16,1)
					if k==4:
						for a in range(mesh.vertCount):
							uv=g.f(2)
							txt.write(' '*16+str(g.tell()-12)+' '+str(a)+' uv:'+str(uv)+'\n')
							mesh.vertUVList.append(uv)
					if k==10:
						for a in range(mesh.vertCount):
							#g.seek(16,1)
							X=g.f(4)
							txt.write(' '*16+str(a)+':'+str(g.tell()-16)+' '+str(X)+'\n')
							mesh.skinWeightList.append(X)
					if k==11:
						for a in range(mesh.vertCount):
							#g.seek(16,1)
							X=g.f(4)
							X=map(int,X)#.replace(255,-1)
							txt.write(' '*16+str(a)+':'+str(g.tell()-16)+' '+str(X)+'\n')
							#print X
							mesh.skinIndiceList.append([X[0]/3,X[1]/3,X[2]/3,X[3]/3])
							
							
							
			txt.write(' '*4+'end vert data:'+str(g.tell())+'\n')
			#g.seek(modelOffsetList[m]+C[4])
			#tt=g.tell()
			#X=g.H(C[0])
			#txt.write(str(tt)+':'+str(X)+'\n')
			g.seek(modelOffsetList[m]+C[4])
			tt=g.tell()
			X=g.H(C[3])
			txt.write(str(tt)+':'+str(X)+'\n')
			#skin.boneMap=X
			print id-1,C[3],X
			
			g.seek(modelOffsetList[m]+C[9])
			mesh.indiceList=g.H(C[8])
			txt.write(str(g.tell())+'\n')
			mesh.TRISTRIP=True
			mesh.draw()
			
			g.seek(t)
			
			
			
		
	txt.close()		
		
	g.debug=True	
	
	
	g.tell()
	g.logClose()
	
def Parser(filename):	
	#filename=input.filename
	print
	print filename
	print
	ext=filename.split('.')[-1].lower()	
	
	if ext=='bin':
		file=open(filename,'rb')
		g=BinaryReader(file)
		binParser(filename,g)
		file.close()
 
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
	
 
	
Blender.Window.FileSelector(Parser,'import','Dreamy Theater PS3 files: *.bin') 
	