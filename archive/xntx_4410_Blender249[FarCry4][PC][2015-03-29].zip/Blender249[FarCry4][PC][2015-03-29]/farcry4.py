import newGameLib
reload(newGameLib)
from newGameLib import *
import Blender	


GETALLFILES=1 
#0 - import single file like *.mesh, *.xbt, *.bin
#1 - parse all files from folder with selected file to get some sorted new files like *.mesh, *.mat, *.dds
	
class VertStream:
	def __init__(self):
		self.offset=None
		self.vertPosList=[]

def xbgParser(filename,g):
	g.word(4)
	g.i(7)
	name=None
	while(True):
		t=g.tell()
		if t>=g.fileSize():break
		chunk=g.word(4)#LTMR
		if chunk=='LTMR':
			A=g.i(6)
			for m in range(A[4]):
				g.word(g.i(1)[0])
				g.B(1)
				g.word(g.i(1)[0])
				g.B(1)
		elif chunk=='LEKS':	
			g.i(5)

		elif chunk=='EDON':	
			B=g.i(5)
			for m in range(B[4]):
				g.B(16)
				g.f(12)
				g.i(1)
				name=g.word(g.i(1)[0])
				g.B(1)
				break
			break	
		
		elif chunk=='MB2O':	
			C=g.i(5)
			for m in range(C[4]):
				g.f(16)
		
		elif chunk=='DIKS':	
			D=g.i(5)
			for m in range(D[4]):
				g.H(6)
		
		elif chunk=='DNKS':	
			E=g.i(4)
	
		elif chunk=='SULC':	
			F=g.i(5)
			g.seek(t+F[1])
			count=g.i(1)[0]
			for m in range(count):
				g.seek(52,1)
				g.word(g.i(1)[0])
				g.B(1)
		
		elif chunk=='ITOM':	
			G=g.i(5)
	
		
		elif chunk=='SDOL':	
			for k in range(2):
		
				meshList=[]
				matList=[]
				
				g.debug=True
				H=g.i(5)
				a,b=g.i(2)
				#print
				for m in range(b):
					mesh=Mesh()				
					mesh.info=g.i(4)
					meshList.append(mesh)
				c=g.i(1)[0]			
				for n in range(c):
					mat=Mat()
					mat.info=g.i(7)
					matList.append(mat)
				vertStreamSize=g.i(1)[0]
				g.seekpad(16)
				g.debug=False
				Start=g.tell()
				for mesh in meshList:
					g.seek(Start+mesh.info[3])
					for m in range(mesh.info[2]):
						t=g.tell()
						mesh.vertPosList.append(g.short(3))
						g.seek(t+mesh.info[1])
				g.seek(Start+vertStreamSize)
				
				indiceCount=g.i(1)[0]
				#print indiceCount
				g.seekpad(16)
				Start=g.tell()	
				for n in range(c):
					MAT=matList[n]
					print MAT.info
					mesh=meshList[MAT.info[0]]
					g.seek(Start+MAT.info[3]*2)
					if n<c-1:
						list=g.H(matList[n+1].info[3]-matList[n].info[3])
						mat=Mat()
						mat.TRIANGLE=True
						mat.IDStart=len(mesh.indiceList)
						mat.IDCount=len(list)
						mesh.indiceList.extend(list)
						mesh.matList.append(mat)
					else:	
						list=g.H(indiceCount-matList[n].info[3])
						mat=Mat()
						mat.TRIANGLE=True
						mat.IDStart=len(mesh.indiceList)
						mat.IDCount=len(list)
						mesh.indiceList.extend(list)
						mesh.matList.append(mat)
					#print len(list),min(list),max(list)	
					#mesh.TRIANGLE=True	
				for mesh in meshList:	
					mesh.SPLIT=True
					mesh.draw()	
				g.debug=True	
			
			#g.seek(t+H[1])
			break
		
		elif chunk=='XOBB':	
			g.i(4)
			g.f(6)
		elif chunk=='HPSB':
			g.i(4)
			g.f(4)
		elif chunk=='FIKS':	
			g.i(4)
			g.B(33)
		elif chunk=='PMCP':
			g.i(6)
		elif chunk=='PMCU':	
			g.B(25)
		elif chunk=='ATEM':
			g.B(8)
		else:
			break
	
	
	
	g.tell()
	return name


def fileParser(filename,g):
	g.debug=True
	g.tell()
	

class SubMesh:pass	

class Lod:pass

class Sknd:pass
	
def meshParser(filename,g):
	g.word(4)
	g.i(7)
	name=None
	
	matList=[]
	meshList=[]
	lodList=[]
	skndList=[]
	
	uvScale=1.0
	uvTrans=0.0
	
	posScale=1.0
	posTrans=0.0
	
	skeleton=Skeleton()
	skeleton.NICE=True
	skeleton.BONESPACE=True
	
	while(True):
		t=g.tell()
		if t>=g.fileSize():break
		chunk=g.word(4)#LTMR
		A=g.i(4)
		#print '='*30,
		#print chunk,A
		if chunk=='LTMR':
			a,b=g.i(2)
			for m in range(a):
				mat=Mat()
				mat.binFile=g.word(g.i(1)[0])
				g.B(1)
				mat.name=g.word(g.i(1)[0])
				print m,'material:',mat.name
				g.B(1)
				matList.append(mat)
				
			for mat in matList:
				matPath=g.dirname+os.sep+mat.name+'.mat'
				flag=os.path.exists(matPath)
				if flag==True:
					matFile=open(matPath,'r')
					lines=matFile.readlines()
					for line in lines:
						if '_d.xbt' in line.lower():
							xbtPath=g.dirname+os.sep+line.strip()
							ddsPath=xbtPath.replace('.xbt','.dds')
							if os.path.exists(xbtPath)==True and os.path.exists(xbtPath)==False:
								xbtfile=open(xbtPath,'rb')
								p=BinaryReader(xbtfile)
								xbtParser(xbtPath,p)
								xbtfile.close()
							mat.diffuse=ddsPath	
							print mat.diffuse
						
							mat.diffuse=g.dirname+os.sep+line.strip().replace('.xbt','_mip0.dds')	
							if os.path.exists(mat.diffuse)==False:
								print '='*20,'no exists:'
								print line.strip().replace('.xbt','_mip0.dds')
								if os.path.exists(g.dirname+os.sep+line.strip().replace('.xbt','_mip0.xbt'))==True:										
									filePath=g.dirname+os.sep+line.strip()
									xbtfile=open(filePath,'rb')
									p=BinaryReader(xbtfile)
									xbtParser(filePath,p)
									xbtfile.close()
									
								else:	
								
									mat.diffuse=g.dirname+os.sep+line.strip().replace('.xbt','.dds')
										
									if os.path.exists(mat.diffuse)==False:	
										if os.path.exists(g.dirname+os.sep+line.strip())==True:										
											filePath=g.dirname+os.sep+line.strip()
											xbtfile=open(filePath,'rb')
											p=BinaryReader(xbtfile)
											xbtParser(filePath,p)
											xbtfile.close()
									
					matFile.close()
						
				
				
		elif chunk=='LEKS':	
			g.i(1)

			
			
			
		elif chunk=='EDON':	
			a=g.i(1)[0]
			for m in range(a):
				bone=Bone()
				g.b(4)
				w = g.i(3)
				bone.rotMatrix=QuatMatrix(g.f(4)).resize4x4()
				bone.posMatrix=VectorMatrix(g.f(3))
				g.f(3)
				g.i(1)[0]
				g.f(1)[0]
				g.i(1)[0]
				bone.name = g.word(g.i(1)[0])[-25:]
				bone.parentID = w[2]
				g.b(1)
				skeleton.boneList.append(bone)
		
		elif chunk=='MB2O':	
			a=g.i(1)[0]
			for m in range(a):
				g.f(16)
		
		elif chunk=='DIKS':	
			a=g.i(1)[0]
			for m in range(a):
				mesh=Mesh()#it is not mesh only info
				B=g.h(6)
				mesh.ID=B[2]
				mesh.boneID=B[3]
				#print m,B
				meshList.append(mesh)
		
		elif chunk=='DNKS':	
			startSULC=g.tell()			
			g.word(4)
			B=g.i(4)
			start=g.tell()
			g.seek(startSULC+B[1])
			count=g.i(1)[0]
			for m in range(count):
				mesh=meshList[m]
				mesh.distance=g.f(1)[0]
				mesh.floatList=g.f(10)
				#print mesh.floatList
				mesh.lodID=g.i(1)[0]
				mesh.unk=g.i(1)[0]
				#print mesh.unk
				mesh.name=g.word(g.i(1)[0])
				#print m,mesh.name
				g.B(1)
			end=g.tell()			
			g.seek(start)
			
			for m in range(count):
				mesh=meshList[m]
				mesh.matCount=g.i(1)[0]
				for n in range(mesh.matCount):
					mat=Mat()
					mat.info=g.H(7)
					#print mat.info
					mat.diffuse=matList[mat.info[0]].diffuse
					mat.boneMap=g.H(48)
					g.i(8)
					g.i(8)
					mesh.matList.append(mat)					
			g.seek(end)		
					
		
		elif chunk=='ITOM':	
			g.i(1)	
		
		elif chunk=='SDOL':			
			lodCount=g.i(1)[0]
			for k in range(lodCount):			
				lod=Lod()
				lodList.append(lod)
				lod.subMeshList=[]
				lod.vertStreamList=[]
				lod.meshListPerStream=[]				
				a,b=g.i(2)
				for m in range(b):
					mesh=Mesh()
					stream=VertStream()				
					stream.info=g.i(4)
					print 'stream:',m,stream.info
					lod.vertStreamList.append(stream)
					lod.meshListPerStream.append(mesh)
				lod.subMeshCount=g.i(1)[0]			
				for n in range(lod.subMeshCount):
					subMesh=Mat()
					subMesh.info=g.i(7)
					lod.subMeshList.append(subMesh)
					#print n,subMesh.info
				lod.vertStreamListSize=g.i(1)[0]
				g.seekpad(16)
				lod.vertStart=g.tell()
				g.seek(lod.vertStart+lod.vertStreamListSize)				
				lod.indiceCount=g.i(1)[0]
				g.seekpad(16)
				lod.indiceStart=g.tell()
				break
			
		
		elif chunk=='XOBB':	
			g.f(6)
		elif chunk=='HPSB':
			g.f(4)
		elif chunk=='FIKS':	
			g.B(33)
		elif chunk=='PMCP':
			posTrans,posScale,unk=g.f(3)
			#print posTrans,posScale
		elif chunk=='PMCU':
			uvTrans,uvScale=g.f(2)	
			break
		elif chunk=='DOL':
			g.i(4)
		elif chunk=='ATEM':
			g.B(8)
			break
		g.seek(t+A[1])
	
	
	
	g.tell()
	skeleton.draw()
	
	for lod in lodList:	
		for n in range(lod.subMeshCount):
			subMesh=lod.subMeshList[n]
			#print subMesh.info
			stream=lod.vertStreamList[subMesh.info[0]]
			#print stream.info
			MESH=lod.meshListPerStream[subMesh.info[0]]				
			g.seek(lod.indiceStart+subMesh.info[3]*2)
			mesh=meshList[subMesh.info[1]]
			mat=mesh.matList[subMesh.info[2]]
			
			MAT=Mat()
			MAT.name=mat.name
			MAT.boneID=mesh.boneID
			MAT.diffuse=mat.diffuse
			MAT.ID=subMesh.info[2]
			MESH.matList.append(MAT)
			list=g.H(mat.info[3])
			
			#print min(list),max(list)
			MAT.TRIANGLE=True
			MAT.IDStart=len(MESH.indiceList)
			MAT.IDCount=len(list)
			MESH.indiceList.extend(list)
			#g.seek(lod.vertStart+stream.info[3]+subMesh.info[5])
			g.seek(lod.vertStart+subMesh.info[5])
			
			skin=Skin()
			if MAT.boneID==-1 and stream.info[0]!=3018:
				skin.boneMap=mat.boneMap
			elif MAT.boneID==-1 and stream.info[0]==3018:
				skin.boneMap=[0]
			else:
				skin.boneMap=[MAT.boneID]
			MESH.skinList.append(skin)
			
			for m in range(len(MESH.vertPosList)):
				MESH.skinIDList[m].append(0)
			
			for m in range(mat.info[5]):
				tm=g.tell()
				MESH.skinIDList.append([0]*len(MESH.skinList))
				x = posTrans+g.h(1)[0]*posScale
				y = posTrans+g.h(1)[0]*posScale
				z = posTrans+g.h(1)[0]*posScale
				MESH.vertPosList.append([x,y,z])
				if stream.info[0]==3034:
					g.seek(tm+8)
					u = uvTrans+g.h(1)[0]*uvScale
					v = uvTrans+g.h(1)[0]*uvScale
					#print u,v
					MESH.vertUVList.append([u,v])
					g.seek(4,1)	
					MESH.skinWeightList.append(g.B(4)) 
					MESH.skinIndiceList.append(g.B(4))
				if stream.info[0]==3018:
					g.seek(tm+8)
					u = uvTrans+g.h(1)[0]*uvScale
					v = uvTrans+g.h(1)[0]*uvScale
					MESH.vertUVList.append([u,v])
					MESH.skinWeightList.append([1.0]) 					
					MESH.skinIndiceList.append([0])
				g.seek(tm+mat.info[4])
				
			for id in list:
				MESH.skinIDList[id][len(MESH.skinList)-1]=1
				
			
		for j,MESH in enumerate(lod.meshListPerStream):
			MESH.SPLIT=True
			MESH.BINDSKELETON=skeleton.name
			MESH.boneNameList=skeleton.boneNameList
			
			for mat in MESH.matList:
				if mat.boneID!=-1:
					boneName=skeleton.boneNameList[mat.boneID]
					matrix=skeleton.object.getData().bones[boneName].matrix['ARMATURESPACE']
					#print boneName
					#print matrix
					mat.matrix=matrix
			MESH.draw()	
			#print 'mesh:',j,'splitted by mat'
			#for i,mat in enumerate(MESH.matList):				
			#	print 'submesh',i,' matID:',mat.ID
			#print
			
	
	
	

	
def xbtParser(filename,g):
	g.word(4)
	A=g.i(4)
	g.seekpad(16)
	name=g.find('\x00')
	g.seek(A[1]+88)
	chunk=g.read(4)
	g.seek(A[1])
	if len(name)==0:
		if chunk=='\x41\x32\x44\x35':
			new=open(filename.replace('.xbt','_norm.dds'),'wb')
		else:	
			new=open(filename.replace('.xbt','.dds'),'wb')
		new.write(g.read(g.fileSize()-A[1]))
		new.close()
	else:	
		filePath=g.dirname+os.sep+name
		try:os.makedirs(os.path.dirname(filePath))
		except:pass
		new=open(filePath.replace('.xbt','.dds'),'wb')
		new.write(g.read(g.fileSize()-A[1]))
		new.close()
	#print os.path.basename(new.name)	
	
	
def split(key,g,new):
	g.seek(0)
	start=0
	data=g.read(g.fileSize()-g.tell())
	fileSize=len(data)
	fileList=[]
	while(True):
		offset=data.find(key)
		if offset>0:
			file=File()
			#print start+offset,len(data)
			data=data[offset+len(key):]
			start+=offset+len(key)
			offset=start-len(key)	
			fileList.append(offset)		
		else:
			break
	for i,offset in enumerate(fileList):
		#print i,offset
		g.seek(offset)
		new.write(g.find('\x00')+'\n')
	
	
def binParser(filename,g):
	#g.debug=True
	g.word(4)
	g.seek(24)
	A=g.i(g.i(1)[0])
	g.seek(11,1)
	matName=g.find('\x00')
	g.seek(5,1)
	matType=g.find('\x00')
	new=open(g.dirname+os.sep+matName+'.mat','w')
	new.write('material type:'+matType+'\n')
	split('graphics',g,new)
	new.close()
	
	
	g.tell()	
	
def Parser(filename):	
	print '='*70
	print filename
	print '='*70
	ext=filename.split('.')[-1].lower()	
	
		
	if GETALLFILES==1:
		dirname=os.path.dirname(filename)
		fileCount=len(os.listdir(dirname))
		for i,file in enumerate(os.listdir(dirname)):
			print i+1,'/',fileCount,file
			if '.xbg' in file.lower():
				filePath=dirname+os.sep+file
				g=open(filePath,'rb')
				g=BinaryReader(g)
				meshName=xbgParser(filePath,g)
				g.close()
				if meshName is not None:
					g=open(filePath,'rb')
					new=open(dirname+os.sep+meshName+'.mesh','wb')
					new.write(g.read())
					new.close()
					g.close()
			elif '.bin' in file.lower():
				filePath=dirname+os.sep+file
				file=open(filePath,'rb')
				g=BinaryReader(file)
				binParser(filePath,g)
				file.close()
			elif '.xbt' in file.lower():
				filePath=dirname+os.sep+file
				file=open(filePath,'rb')
				g=BinaryReader(file)
				xbtParser(filePath,g)
				file.close()
				
	else:		
	
		if ext=='mesh':
			file=open(filename,'rb')
			g=BinaryReader(file)
			meshParser(filename,g)
			file.close()
			
		if ext=='xbg':
			file=open(filename,'rb')
			g=BinaryReader(file)
			meshParser(filename,g)
			file.close()
			
		if ext=='bin':
			file=open(filename,'rb')
			g=BinaryReader(file)
			binParser(filename,g)
			file.close()	
		
		
		
 
	
Blender.Window.FileSelector(Parser,'import','Far Cry 4 files: *.xbg, *.mesh, *.bin, *.xbt') 
	