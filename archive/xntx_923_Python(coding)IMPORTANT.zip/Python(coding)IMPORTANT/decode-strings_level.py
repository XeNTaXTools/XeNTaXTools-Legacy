#!/usr/bin/env python
# vi: set softtabstop=4 shiftwidth=4 tabstop=4 expandtab:
#
# Decoder for strings_level.xls.uni.cooked.
# Copyright (C) 2007  Kral
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# Kral <kral@variadic.org>
#

from struct import *
from optparse import OptionParser
from xml.dom.DOMImplementation import implementation
from xml.dom.ext import Print
from xml.dom.ext.reader import Sax2
from xml.dom import Node
import xml.utils
import os
import string
import sys
import binascii

def main():

    # Parse commandline options
    parser = OptionParser("usage: %prog [options] fileIN")
    (options, arguments) = parser.parse_args()
    if len(arguments) != 1:
        parser.error("Must specify an input file")

    inputData = file(arguments[0], "rb").read()

    # Check it's a tsfh file (first 4 bytes).
    if inputData[0:4] != "tsfh":
        raise Exception("Invalid file, missing tsfh header")

    # Start the document.
    doctype = implementation.createDocumentType(None, None, None)
    document = implementation.createDocument("http://hellgate.variadic.org/strings_level.xls.uni.cooked", "document", doctype)

    # Decode the header.
    headerElement = document.createElement("header")
    document.documentElement.appendChild(headerElement)
    unknown = binascii.b2a_hex(inputData[4:8])
    hexElement = document.createElement("hex")
    hexElement.appendChild(document.createTextNode(unknown))
    headerElement.appendChild(hexElement)
    recordCount = unpack("<L", inputData[8:12])[0]

    recordOffset = 12

    recordIndex = 0
    while(recordIndex < recordCount):

        element = document.createElement("element")
        document.documentElement.appendChild(element)

        element.setAttribute("index", str(recordIndex))
        element.setAttribute("offset", str(recordOffset))

        id = unpack("<L", inputData[recordOffset:recordOffset + 4])[0]
        element.setAttribute("id", str(id))
        recordOffset += 4

        # Unknown data (0x06ab)
        unknown = binascii.b2a_hex(inputData[recordOffset:recordOffset + 4])
        hexElement = document.createElement("hex")
        hexElement.appendChild(document.createTextNode(unknown))
        element.appendChild(hexElement)
        recordOffset += 4

        # Get the level text.
        levelTextLength = unpack("<L", inputData[recordOffset:recordOffset + 4])[0]
        recordOffset += 4
        levelTextString = inputData[recordOffset:recordOffset + levelTextLength]
        recordOffset += levelTextLength + 1
        stringElement = document.createElement("level")
        stringElement.appendChild(document.createTextNode(levelTextString))
        element.appendChild(stringElement)

        # Unknown data (null?).
        unknown = binascii.b2a_hex(inputData[recordOffset:recordOffset + 4])
        hexElement = document.createElement("hex")
        hexElement.appendChild(document.createTextNode(unknown))
        element.appendChild(hexElement)
        recordOffset += 4

        # Get the unicode text.
        levelUnicodeTextLength = unpack("<L", inputData[recordOffset:recordOffset + 4])[0]
        recordOffset += 4
        levelUnicodeTextString = unicode(inputData[recordOffset:recordOffset + levelUnicodeTextLength - 2], "utf-16")
        recordOffset += levelUnicodeTextLength
        stringElement = document.createElement("display")
        stringElement.appendChild(document.createTextNode(levelUnicodeTextString))
        element.appendChild(stringElement)

        # Unknown data.
        unknown = binascii.b2a_hex(inputData[recordOffset:recordOffset + 4])
        hexElement = document.createElement("hex")
        hexElement.appendChild(document.createTextNode(unknown))
        element.appendChild(hexElement)
        recordOffset += 4

        # NOTE: I'm guessing this is 2 * length of the "English" 
        # unicode, and ignoring the trailing null.
        levelUnicodeTextLanguageLength = unpack("<L", inputData[recordOffset:recordOffset + 4])[0]
        recordOffset += 4
        levelUnicodeTextLanguageString = unicode(inputData[recordOffset:recordOffset + levelUnicodeTextLanguageLength * 2], "utf-16")
        recordOffset += levelUnicodeTextLanguageLength * 2 + 2
        stringElement = document.createElement("language")
        stringElement.appendChild(document.createTextNode(levelUnicodeTextLanguageString))
        element.appendChild(stringElement)

        recordIndex += 1

    xml.dom.ext.PrettyPrint(document)

def getString(offset, data):
    result = ""
    index = 0
    while 1:
        byte = data[(offset + index):(offset + index) + 1]
        if(ord(byte) == 0x00): break
        result += byte
        index += 1
    return result

if __name__ == "__main__":
    main()
