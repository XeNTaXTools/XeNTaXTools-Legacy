#!/usr/bin/env python
# vi: set softtabstop=4 shiftwidth=4 tabstop=4 expandtab:
#
# Decoder for levels.txt.cooked
# Copyright (C) 2007  Kral
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# Kral <kral@variadic.org>
#

from struct import *
from optparse import OptionParser
from xml.dom.DOMImplementation import implementation
from xml.dom.ext import Print
from xml.dom.ext.reader import Sax2
from xml.dom import Node
import xml.utils
import os
import string
import sys
import binascii

def main():

    # Parse commandline options
    parser = OptionParser("usage: %prog [options] fileIN")
    (options, arguments) = parser.parse_args()
    if len(arguments) != 1:
        parser.error("Must specify an input file")

    inputData = file(arguments[0], "rb").read()

    # Check it's a cxeh file (first 4 bytes).
    if inputData[0:4] != "cxeh":
        raise Exception("Invalid file, missing cxeh header")

    # Start the document.
    doctype = implementation.createDocumentType(None, None, None)
    document = implementation.createDocument("http://hellgate.variadic.org/levels.txt.cooked", "document", doctype)

    # Decode the header.
    headerElement = document.createElement("header")
    document.documentElement.appendChild(headerElement)
    unknown = binascii.b2a_hex(inputData[4:40])
    hexElement = document.createElement("hex")
    hexElement.appendChild(document.createTextNode(unknown))
    headerElement.appendChild(hexElement)
    recordCount = unpack("<L", inputData[40:40 + 4])[0]
    recordOffset = 44

    recordIndex = 0
    while(recordIndex < recordCount):

        element = document.createElement("element")
        document.documentElement.appendChild(element)

        element.setAttribute("index", str(recordIndex))
        element.setAttribute("offset", str(recordOffset))

        # Unknown data.
        unknown = binascii.b2a_hex(inputData[recordOffset:recordOffset + 16])
        hexElement = document.createElement("hex")
        hexElement.appendChild(document.createTextNode(unknown))
        element.appendChild(hexElement)
        recordOffset += 16

        # Get the level text (null terminated fixed-length buffer).
        levelText = getString(recordOffset, inputData)
        stringElement = document.createElement("level")
        stringElement.appendChild(document.createTextNode(levelText))
        element.appendChild(stringElement)
        recordOffset += 64

        # Unknown data.
        unknown = binascii.b2a_hex(inputData[recordOffset:recordOffset + 80])
        hexElement = document.createElement("hex")
        hexElement.appendChild(document.createTextNode(unknown))
        element.appendChild(hexElement)
        recordOffset += 80

        # The id of the strings_level localization.
        localizationId = unpack("<L", inputData[recordOffset:recordOffset + 4])[0]
        stringElement = document.createElement("localizationId")
        stringElement.appendChild(document.createTextNode(str(localizationId)))
        element.appendChild(stringElement)
        recordOffset += 4

        # Unknown data.
        unknown = binascii.b2a_hex(inputData[recordOffset:recordOffset + 260])
        hexElement = document.createElement("hex")
        hexElement.appendChild(document.createTextNode(unknown))
        element.appendChild(hexElement)
        recordOffset += 284

        # Some map stuff.
        mapText = getString(recordOffset, inputData)
        stringElement = document.createElement("mapShape")
        stringElement.appendChild(document.createTextNode(mapText))
        element.appendChild(stringElement)
        recordOffset += 256

        # Some other map stuff.
        mapText = getString(recordOffset, inputData)
        stringElement = document.createElement("mapShapeAlternate")
        stringElement.appendChild(document.createTextNode(mapText))
        element.appendChild(stringElement)
        recordOffset += 256

        # Unknown data.
        unknown = binascii.b2a_hex(inputData[recordOffset:recordOffset + 104])
        hexElement = document.createElement("hex")
        hexElement.appendChild(document.createTextNode(unknown))
        element.appendChild(hexElement)
        recordOffset += 104

        recordIndex += 1

    xml.dom.ext.PrettyPrint(document)

def getString(offset, data):
    result = ""
    index = 0
    while 1:
        byte = data[(offset + index):(offset + index) + 1]
        if(ord(byte) == 0x00): break
        result += byte
        index += 1
    return result

if __name__ == "__main__":
    main()
