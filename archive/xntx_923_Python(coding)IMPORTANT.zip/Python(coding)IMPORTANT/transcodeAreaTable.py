#!/usr/bin/env python
# vi: set softtabstop=4 shiftwidth=4 tabstop=4 expandtab:
#
# Transcoder for AreaTable.dbc.
# Copyright (C) 2005  Rosten
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# Rosten <rosten@variadic.org>
#

from struct import *
from optparse import OptionParser
from xml.dom.DOMImplementation import implementation
from xml.dom.ext import Print
from xml.dom.ext.reader import Sax2
from xml.dom import Node
import xml.utils
import os
import string
import sys
import binascii

def main():

    # Parse commandline options
    parser = OptionParser("usage: %prog [options] fileIN fileOUT")
    parser.add_option("-d", "--decode", dest="decode", help="Decode the dbc to xml", action="store_true")
    parser.add_option("-e", "--encode", dest="encode", help="Encode the xml to dbc", action="store_true")
    (options, arguments) = parser.parse_args()
    if options.encode and options.decode:
        parser.error("Only one of encode or decode may be specified")
    if not options.encode and not options.decode:
        parser.error("Must specify one of encode or decode")
    if len(arguments) != 2:
        parser.error("Must specify an input file and an output file")

    if(options.decode):
        inputData = file(arguments[0], "rb").read()
        outputFile = file(arguments[1], "w")

        # Start the document.
        doctype = implementation.createDocumentType(None, None, None)
        document = implementation.createDocument("http://wow.variadic.org", "genericDbc", doctype)

        # Check it's a dbc file (first 4 bytes).
        if inputData[0:4] != "WDBC":
            raise Exception("Invalid dbc file, missing WDBC header")

        # Get count of records in the file (from the 16 byte header).
        recordCount = unpack("<L", inputData[4:8])[0]

        # Get record size.
        recordSize = unpack("<L", inputData[12:16])[0]

        # Get address of the string table.  It's after all the header (4 + 16)
        # and the records.
        stringTableOffset = (4 + 16) + recordCount * recordSize
        stringTableSize = unpack("<L", inputData[16:20])[0]

        # Add the file-specific parts of the header to the file (One is the
        # record size, but what's the other?)
        unknown = binascii.b2a_hex(inputData[8:16])
        headerElement = document.createElement("header")
        document.documentElement.appendChild(headerElement)
        hexElement = document.createElement("hex")
        hexElement.appendChild(document.createTextNode(unknown))
        headerElement.appendChild(hexElement)

        # Loop decoding records.
        recordIndex = 0
        while(recordIndex < recordCount):
            recordOffset = (4 + 16) + recordIndex * recordSize

            element = document.createElement("element")
            document.documentElement.appendChild(element)

            # Id.
            id = unpack("<L", inputData[recordOffset + 0:recordOffset + 0 + 4])[0]
            element.setAttribute("id", str(id))

            # Unknown data.
            unknownData = inputData[recordOffset + 4:recordOffset + 4 + 4]
            unknown = binascii.b2a_hex(unknownData)
            hexElement = document.createElement("hex")
            hexElement.appendChild(document.createTextNode(unknown))
            element.appendChild(hexElement)

            # Parent zone id.
            id = unpack("<L", inputData[recordOffset + 8:recordOffset + 8 + 4])[0]
            parentZoneIdElement = document.createElement("parentZoneId")
            parentZoneIdElement.appendChild(document.createTextNode(str(id)))
            element.appendChild(parentZoneIdElement)

            # Unknown data.
            unknownData = inputData[recordOffset + 12:recordOffset + 44]
            unknown = binascii.b2a_hex(unknownData)
            hexElement = document.createElement("hex")
            hexElement.appendChild(document.createTextNode(unknown))
            element.appendChild(hexElement)

            # Zone/Subzone name.
            stringEntryOffset = unpack("<L", inputData[recordOffset + 44:recordOffset + 44 + 4])[0]
            stringEntry = getString(stringTableOffset + stringEntryOffset, inputData)
            stringElement = document.createElement("name")
            if(stringEntryOffset != 0): stringElement.appendChild(document.createTextNode(stringEntry))
            element.appendChild(stringElement)

            # Unknown data.
            unknownData = inputData[recordOffset + 48:recordOffset + 48 + 36]
            unknown = binascii.b2a_hex(unknownData)
            hexElement = document.createElement("hex")
            hexElement.appendChild(document.createTextNode(unknown))
            element.appendChild(hexElement)

            recordIndex += 1

        # Loop adding stringtable entries.
        stringTableIndex = 1
        while(stringTableIndex < stringTableSize):
            stringEntry = getString(stringTableOffset + stringTableIndex, inputData)

            stringElement = document.createElement("string")
            stringElement.appendChild(document.createTextNode(stringEntry))
            document.documentElement.appendChild(stringElement)

            stringTableIndex += len(stringEntry) + 1

        # End the document.
        xml.dom.ext.PrettyPrint(document, outputFile)

    else:
        stringTable = None
        inputFile = file(arguments[0], "r")
        outputFile = file(arguments[1], "wb")
        document = Sax2.Reader().fromStream(inputFile)

        records = str()
        header = str()
        stringTable = str()
        elementCount = 0

        # First byte of the string table will be a null.
        stringTable += chr(0)

        # Iterate over the nodes writing the records.
        for node in document.documentElement.childNodes:
            if(node.nodeType != Node.ELEMENT_NODE): continue

            # Is it a header?
            if(node.nodeName == "header"):

                # Add any child hex nodes to the header data.
                for child in node.childNodes:
                    if(child.nodeType != Node.ELEMENT_NODE): continue
                    if(child.nodeName == "hex"):
                        header += binascii.a2b_hex(child.firstChild.nodeValue)

            # Is it a string?
            elif(node.nodeName == "string"):
                name = node.firstChild.nodeValue
                stringTable += name
                stringTable += chr(0)

            # Is it an element?
            elif(node.nodeName == "element"):
                elementCount += 1
                record = str()

                for child in node.childNodes:
                    if(child.nodeType != Node.ELEMENT_NODE): continue

                    # Write any hex.
                    if(child.nodeName == "hex"):
                        record += binascii.a2b_hex(child.firstChild.nodeValue)

                    else:
                        print("Unhandled node: " + child.nodeName)


                records += record

        # Write the header ("WDBC", records, (file-specific header), string
        # table size)
        outputFile.write("WDBC")
        outputFile.write(pack("<L", elementCount))
        outputFile.write(header)
        outputFile.write(pack("<L", len(stringTable)))

        # Write the records.
        outputFile.write(records)

        # Write the string table.
        outputFile.write(stringTable)

        outputFile.close()

def analyzeUnknown(unknownData, inputData, stringTableOffset, stringTableSize, document, element):

    # Make guesses at stringtable entries.
    unknownIndex = 0
    while(unknownIndex < len(unknownData)):
        index = unpack("<L", unknownData[unknownIndex:unknownIndex + 4])[0]

        if(index < stringTableSize):
            guessedString = getString(stringTableOffset + index, inputData)
            if(len(guessedString) > 0):
                comment = "%d: '%s'" % (unknownIndex, guessedString)
                commentElement = document.createComment(" %d: '%s' " % (unknownIndex, getString(stringTableOffset + index, inputData)))
                element.appendChild(commentElement)

        unknownIndex += 4

def getString(offset, data):
    result = ""
    index = 0
    while 1:
        byte = data[(offset + index):(offset + index) + 1]
        if(ord(byte) == 0x00): break
        result += byte
        index += 1
    return result

if __name__ == "__main__":
    main()
