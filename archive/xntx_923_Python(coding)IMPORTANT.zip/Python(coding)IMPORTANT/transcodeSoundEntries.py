#!/usr/bin/env python
# vi: set softtabstop=4 shiftwidth=4 tabstop=4 expandtab:
#
# Transcoder for SoundEntries.dbc.
# Copyright (C) 2005  Rosten
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# Rosten <rosten@variadic.org>
#

from struct import *
from optparse import OptionParser
from xml.dom.DOMImplementation import implementation
from xml.dom.ext import Print
from xml.dom.ext.reader import Sax2
from xml.dom import Node
import xml.utils
import os
import string
import sys
import binascii

def main():

    # Parse commandline options
    parser = OptionParser("usage: %prog [options] fileIN fileOUT")
    parser.add_option("-d", "--decode", dest="decode", help="Decode the dbc to xml", action="store_true")
    parser.add_option("-e", "--encode", dest="encode", help="Encode the xml to dbc", action="store_true")
    (options, arguments) = parser.parse_args()
    if options.encode and options.decode:
        parser.error("Only one of encode or decode may be specified")
    if not options.encode and not options.decode:
        parser.error("Must specify one of encode or decode");
    if len(arguments) != 2:
        parser.error("Must specify an input file and an output file");

    if(options.decode):
        inputData = file(arguments[0], "rb").read();
        outputFile = file(arguments[1], "w");

        # Start the document.
        doctype = implementation.createDocumentType(None, None, None)
        document = implementation.createDocument("http://wow.variadic.org", "soundEntries", doctype)

        # Check it's a dbc file (first 4 bytes).
        if inputData[0:4] != "WDBC":
            raise Exception("Invalid dbc file, missing WDBC header")

        # Get count of records in the file (from the 16 byte header).
        recordCount = unpack("<L", inputData[4:8])[0];

        # Get address of the string table.  It's after all the header (4 + 16)
        # and the 116 byte records.
        stringTableOffset = (4 + 16) + recordCount * 116

        # Add the unknown parts of the header to the file (One is the record
        # size, but what's the other?)
        unknown = binascii.b2a_hex(inputData[8:16])
        headerElement = document.createElement("header")
        document.documentElement.appendChild(headerElement);
        hexElement = document.createElement("hex")
        hexElement.appendChild(document.createTextNode(unknown))
        headerElement.appendChild(hexElement);

        # Loop decoding records.
        recordIndex = 0
        while(recordIndex < recordCount):
            recordOffset = (4 + 16) + recordIndex * 116;

            soundElement = document.createElement("sound")
            document.documentElement.appendChild(soundElement)

            # Sound id.
            soundId = unpack("<L", inputData[recordOffset + 0:recordOffset + 0 + 4])[0]
            soundElement.setAttribute("id", str(soundId))

            # Unknown 4 @ +4
            unknown = binascii.b2a_hex(inputData[recordOffset + 4:recordOffset + 4 + 4])
            hexElement = document.createElement("hex")
            hexElement.appendChild(document.createTextNode(unknown))
            soundElement.appendChild(hexElement)

            # name
            stringEntryOffset = unpack("<L", inputData[recordOffset + 8:recordOffset + 8 + 4])[0]
            stringEntry = getString(stringTableOffset + stringEntryOffset, inputData)
            stringElement = document.createElement("name")
            if(stringEntryOffset != 0): stringElement.appendChild(document.createTextNode(stringEntry))
            soundElement.appendChild(stringElement)

            # There are 10 alternate files.
            for i in range(1, 10 + 1):
                stringEntryOffset = unpack("<L", inputData[recordOffset + 12 + ((i - 1) * 4):recordOffset + 12 + ((i - 1) * 4) + 4])[0]
                stringEntry = getString(stringTableOffset + stringEntryOffset, inputData)
                stringElement = document.createElement("file" + str(i))
                if(stringEntryOffset != 0): stringElement.appendChild(document.createTextNode(stringEntry))
                soundElement.appendChild(stringElement)

            # Unknown 40 @ +52
            unknown = binascii.b2a_hex(inputData[recordOffset + 52:recordOffset + 52 + 40])
            hexElement = document.createElement("hex")
            hexElement.appendChild(document.createTextNode(unknown))
            soundElement.appendChild(hexElement)

            # path
            stringEntryOffset = unpack("<L", inputData[recordOffset + 92:recordOffset + 92 + 4])[0]
            stringEntry = getString(stringTableOffset + stringEntryOffset, inputData)
            stringElement = document.createElement("path")
            if(stringEntryOffset != 0): stringElement.appendChild(document.createTextNode(stringEntry))
            soundElement.appendChild(stringElement)

            # Unknown 4 @ +96
            unknown = binascii.b2a_hex(inputData[recordOffset + 96:recordOffset + 96 + 4])
            hexElement = document.createElement("hex")
            hexElement.appendChild(document.createTextNode(unknown))
            soundElement.appendChild(hexElement)

            # Flags
            flags = binascii.b2a_hex(inputData[recordOffset + 100:recordOffset + 100 + 4])
            hexElement = document.createElement("flags")
            hexElement.appendChild(document.createTextNode(flags))
            soundElement.appendChild(hexElement)

            # Unknown 104 @ +12
            unknown = binascii.b2a_hex(inputData[recordOffset + 104:recordOffset + 104 + 12])
            hexElement = document.createElement("hex")
            hexElement.appendChild(document.createTextNode(unknown))
            soundElement.appendChild(hexElement)

            # XXX Note, looping sounds have a '2' in the hex where others have 0.

            recordIndex += 1

        # End the document.
        xml.dom.ext.PrettyPrint(document, outputFile)

    else:
        stringTable = None
        inputFile = file(arguments[0], "r")
        outputFile = file(arguments[1], "wb")
        document = Sax2.Reader().fromStream(inputFile)

        records = str()
        header = str()
        stringTable = str()
        soundCount = 0

        # First byte of the string table will be a null.
        stringTable += chr(0)

        # Iterate over the nodes writing the records.
        for node in document.documentElement.childNodes:
            if(node.nodeType != Node.ELEMENT_NODE): continue

            # Is it a header?
            if(node.nodeName == "header"):

                # Add any child hex nodes to the header data.
                for child in node.childNodes:
                    if(child.nodeType != Node.ELEMENT_NODE): continue;
                    if(child.nodeName == "hex"):
                        header += binascii.a2b_hex(child.firstChild.nodeValue)

            # Is it a sound?
            if(node.nodeName == "sound"):
                soundCount += 1
                record = str()

                # Write its id.
                record += pack("<L", int(node.getAttribute("id")))

                for child in node.childNodes:
                    if(child.nodeType != Node.ELEMENT_NODE): continue;

                    # Write any hex or flags.
                    if(child.nodeName == "hex" or child.nodeName == "flags"):
                        record += binascii.a2b_hex(child.firstChild.nodeValue)

                    # Is it a string table type?
                    if(child.nodeName == "name" or child.nodeName == "path" or child.nodeName == "file1" or child.nodeName == "file2" or child.nodeName == "file3" or child.nodeName == "file4" or child.nodeName == "file5" or child.nodeName == "file6" or child.nodeName == "file7" or child.nodeName == "file8" or child.nodeName == "file9" or child.nodeName == "file10"):
                        index = len(stringTable)
                        if(child.firstChild != None):
                            name = child.firstChild.nodeValue;
                            record += pack("<L", index)
                            stringTable += name
                            stringTable += chr(0)
                        else:
                            record += pack("<L", 0)

                records += record

        # Write the header ("WDBC", sound count, (unknown header), string
        # table size)
        outputFile.write("WDBC")
        outputFile.write(pack("<L", soundCount))
        outputFile.write(header)
        outputFile.write(pack("<L", len(stringTable)))

        # Write the records.
        outputFile.write(records)

        # Write the string table.
        outputFile.write(stringTable)

        outputFile.close()

def getString(offset, data):
    result = ""
    index = 0
    while 1:
        byte = data[(offset + index):(offset + index) + 1]
        if(ord(byte) == 0x00): break
        result += byte
        index += 1
    return result

if __name__ == "__main__":
    main()
