#!/usr/bin/env python
# vi: set softtabstop=4 shiftwidth=4 tabstop=4 expandtab:
#
# Transcoder for CreatureSoundData.dbc.
# Copyright (C) 2005  Rosten
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# Rosten <rosten@variadic.org>
#

from struct import *
from optparse import OptionParser
from xml.dom.DOMImplementation import implementation
from xml.dom.ext import Print
from xml.dom.ext.reader import Sax2
from xml.dom import Node
import xml.utils
import os
import string
import sys
import binascii

def main():

    # Parse commandline options
    parser = OptionParser("usage: %prog [options] fileIN fileOUT")
    parser.add_option("-d", "--decode", dest="decode", help="Decode the dbc to xml", action="store_true")
    parser.add_option("-e", "--encode", dest="encode", help="Encode the xml to dbc", action="store_true")
    (options, arguments) = parser.parse_args()
    if options.encode and options.decode:
        parser.error("Only one of encode or decode may be specified")
    if not options.encode and not options.decode:
        parser.error("Must specify one of encode or decode");
    if len(arguments) != 2:
        parser.error("Must specify an input file and an output file");

    if(options.decode):
        inputData = file(arguments[0], "rb").read();
        outputFile = file(arguments[1], "w");

        # Start the document.
        doctype = implementation.createDocumentType(None, None, None)
        document = implementation.createDocument("http://wow.variadic.org", "creatureSoundData", doctype)

        # Check it's a dbc file (first 4 bytes).
        if inputData[0:4] != "WDBC":
            raise Exception("Invalid dbc file, missing WDBC header")

        # Get count of records in the file (from the 16 byte header).
        recordCount = unpack("<L", inputData[4:8])[0];

        # Get address of the string table.  It's after all the header (4 + 16)
        # and the 108 byte records.
        stringTableOffset = (4 + 16) + recordCount * 108

        # Add the unknown parts of the header to the file (One is the record
        # size, but what's the other?)
        unknown = binascii.b2a_hex(inputData[8:16])
        headerElement = document.createElement("header")
        document.documentElement.appendChild(headerElement);
        hexElement = document.createElement("hex")
        hexElement.appendChild(document.createTextNode(unknown))
        headerElement.appendChild(hexElement);

        # Loop decoding records.
        recordIndex = 0
        while(recordIndex < recordCount):
            recordOffset = (4 + 16) + recordIndex * 108;

            creatureSoundElement = document.createElement("creatureSound")
            document.documentElement.appendChild(creatureSoundElement)

            # Creature id.
            creatureSoundId = unpack("<L", inputData[recordOffset + 0:recordOffset + 0 + 4])[0]
            creatureSoundElement.setAttribute("id", str(creatureSoundId))

            # Attack.
            id = unpack("<L", inputData[recordOffset + 4:recordOffset + 4 + 4])[0]
            idElement = document.createElement("attack")
            idElement.appendChild(document.createTextNode(str(id)))
            creatureSoundElement.appendChild(idElement)

            # Unknown 4 @ +8 (some sort of index, but not to a sound)
            unknown = binascii.b2a_hex(inputData[recordOffset + 8:recordOffset + 8 + 4])
            hexElement = document.createElement("hex")
            hexElement.appendChild(document.createTextNode(unknown))
            creatureSoundElement.appendChild(hexElement)

            # Wound.
            id = unpack("<L", inputData[recordOffset + 12:recordOffset + 12 + 4])[0]
            idElement = document.createElement("wound")
            idElement.appendChild(document.createTextNode(str(id)))
            creatureSoundElement.appendChild(idElement)

            # Crit.
            id = unpack("<L", inputData[recordOffset + 16:recordOffset + 16 + 4])[0]
            idElement = document.createElement("crit")
            idElement.appendChild(document.createTextNode(str(id)))
            creatureSoundElement.appendChild(idElement)

            # Unknown 4 @ +20
            unknown = binascii.b2a_hex(inputData[recordOffset + 20:recordOffset + 20 + 4])
            hexElement = document.createElement("hex")
            hexElement.appendChild(document.createTextNode(unknown))
            creatureSoundElement.appendChild(hexElement)

            # Death.
            id = unpack("<L", inputData[recordOffset + 24:recordOffset + 24 + 4])[0]
            idElement = document.createElement("death")
            idElement.appendChild(document.createTextNode(str(id)))
            creatureSoundElement.appendChild(idElement)

            # Unknown 4 @ +28 (non-sound index?)
            unknown = binascii.b2a_hex(inputData[recordOffset + 28:recordOffset + 28 + 4])
            hexElement = document.createElement("hex")
            hexElement.appendChild(document.createTextNode(unknown))
            creatureSoundElement.appendChild(hexElement)

            # Fidget5.
            id = unpack("<L", inputData[recordOffset + 32:recordOffset + 32 + 4])[0]
            idElement = document.createElement("fidget5")
            idElement.appendChild(document.createTextNode(str(id)))
            creatureSoundElement.appendChild(idElement)

            # Footstep.
            id = unpack("<L", inputData[recordOffset + 36:recordOffset + 36 + 4])[0]
            idElement = document.createElement("footstep")
            idElement.appendChild(document.createTextNode(str(id)))
            creatureSoundElement.appendChild(idElement)

            # Aggro.
            id = unpack("<L", inputData[recordOffset + 40:recordOffset + 40 + 4])[0]
            idElement = document.createElement("aggro")
            idElement.appendChild(document.createTextNode(str(id)))
            creatureSoundElement.appendChild(idElement)

            # Flap.
            id = unpack("<L", inputData[recordOffset + 44:recordOffset + 44 + 4])[0]
            idElement = document.createElement("flap")
            idElement.appendChild(document.createTextNode(str(id)))
            creatureSoundElement.appendChild(idElement)

            # Unknown 4 @ +48
            unknown = binascii.b2a_hex(inputData[recordOffset + 48:recordOffset + 48 + 4])
            hexElement = document.createElement("hex")
            hexElement.appendChild(document.createTextNode(unknown))
            creatureSoundElement.appendChild(hexElement)

            # "Pre aggro" XXX ?
            id = unpack("<L", inputData[recordOffset + 52:recordOffset + 52 + 4])[0]
            idElement = document.createElement("preAggro")
            idElement.appendChild(document.createTextNode(str(id)))
            creatureSoundElement.appendChild(idElement)

            # Fidget1
            id = unpack("<L", inputData[recordOffset + 56:recordOffset + 56 + 4])[0]
            idElement = document.createElement("fidget1")
            idElement.appendChild(document.createTextNode(str(id)))
            creatureSoundElement.appendChild(idElement)

            # Fidget2
            id = unpack("<L", inputData[recordOffset + 60:recordOffset + 60 + 4])[0]
            idElement = document.createElement("fidget2")
            idElement.appendChild(document.createTextNode(str(id)))
            creatureSoundElement.appendChild(idElement)

            # Fidget3
            id = unpack("<L", inputData[recordOffset + 64:recordOffset + 64 + 4])[0]
            idElement = document.createElement("fidget3")
            idElement.appendChild(document.createTextNode(str(id)))
            creatureSoundElement.appendChild(idElement)

            # Fidget4
            id = unpack("<L", inputData[recordOffset + 68:recordOffset + 68 + 4])[0]
            idElement = document.createElement("fidget4")
            idElement.appendChild(document.createTextNode(str(id)))
            creatureSoundElement.appendChild(idElement)

            # specialAttack1.
            id = unpack("<L", inputData[recordOffset + 72:recordOffset + 72 + 4])[0]
            idElement = document.createElement("specialAttack1")
            idElement.appendChild(document.createTextNode(str(id)))
            creatureSoundElement.appendChild(idElement)

            # specialAttack2.
            id = unpack("<L", inputData[recordOffset + 76:recordOffset + 76 + 4])[0]
            idElement = document.createElement("specialAttack2")
            idElement.appendChild(document.createTextNode(str(id)))
            creatureSoundElement.appendChild(idElement)

            # specialAttack3.
            id = unpack("<L", inputData[recordOffset + 80:recordOffset + 80 + 4])[0]
            idElement = document.createElement("specialAttack3")
            idElement.appendChild(document.createTextNode(str(id)))
            creatureSoundElement.appendChild(idElement)

            # specialAttack4.
            id = unpack("<L", inputData[recordOffset + 84:recordOffset + 84 + 4])[0]
            idElement = document.createElement("specialAttack4")
            idElement.appendChild(document.createTextNode(str(id)))
            creatureSoundElement.appendChild(idElement)

            # Unknown 4 @ +88
            unknown = binascii.b2a_hex(inputData[recordOffset + 88:recordOffset + 88 + 4])
            hexElement = document.createElement("hex")
            hexElement.appendChild(document.createTextNode(unknown))
            creatureSoundElement.appendChild(hexElement)

            # Loop.
            id = unpack("<L", inputData[recordOffset + 92:recordOffset + 92 + 4])[0]
            idElement = document.createElement("loop")
            idElement.appendChild(document.createTextNode(str(id)))
            creatureSoundElement.appendChild(idElement)

            # Unknown 8 @ +96
            unknown = binascii.b2a_hex(inputData[recordOffset + 96:recordOffset + 96 + 8])
            hexElement = document.createElement("hex")
            hexElement.appendChild(document.createTextNode(unknown))
            creatureSoundElement.appendChild(hexElement)

            # Land.
            id = unpack("<L", inputData[recordOffset + 104:recordOffset + 104 + 4])[0]
            idElement = document.createElement("land")
            idElement.appendChild(document.createTextNode(str(id)))
            creatureSoundElement.appendChild(idElement)

            recordIndex += 1

        # End the document.
        xml.dom.ext.PrettyPrint(document, outputFile)

    else:
        stringTable = None
        inputFile = file(arguments[0], "r")
        outputFile = file(arguments[1], "wb")
        document = Sax2.Reader().fromStream(inputFile)

        records = str()
        header = str()
        stringTable = str()
        creatureSoundCount = 0

        # First byte of the string table will be a null.
        stringTable += chr(0)

        # Iterate over the nodes writing the records.
        for node in document.documentElement.childNodes:
            if(node.nodeType != Node.ELEMENT_NODE): continue

            # Is it a header?
            if(node.nodeName == "header"):

                # Add any child hex nodes to the header data.
                for child in node.childNodes:
                    if(child.nodeType != Node.ELEMENT_NODE): continue;
                    if(child.nodeName == "hex"):
                        header += binascii.a2b_hex(child.firstChild.nodeValue)

            # Is it a creatureSound?
            if(node.nodeName == "creatureSound"):
                creatureSoundCount += 1
                record = str()

                # Write its id.
                record += pack("<L", int(node.getAttribute("id")))

                for child in node.childNodes:
                    if(child.nodeType != Node.ELEMENT_NODE): continue;

                    # Write any hex.
                    if(child.nodeName == "hex"):
                        record += binascii.a2b_hex(child.firstChild.nodeValue)

                    # Write sound ids.
                    elif(child.nodeName == "land" or child.nodeName == "loop" or child.nodeName == "aggro" or child.nodeName == "preAggro" or child.nodeName == "death" or child.nodeName == "crit" or child.nodeName == "wound" or child.nodeName == "attack" or child.nodeName == "fidget1" or child.nodeName == "fidget2" or child.nodeName == "fidget3" or child.nodeName == "fidget4" or child.nodeName == "fidget5" or child.nodeName == "footstep" or child.nodeName == "specialAttack1" or child.nodeName == "specialAttack2" or child.nodeName == "specialAttack3" or child.nodeName == "specialAttack4" or child.nodeName == "flap"):
                        record += pack("<L", int(child.firstChild.nodeValue))

                    else:
                        print("Unhandled node: " + child.nodeName)

                records += record

        # Write the header ("WDBC", records, (unknown header), string
        # table size)
        outputFile.write("WDBC")
        outputFile.write(pack("<L", creatureSoundCount))
        outputFile.write(header)
        outputFile.write(pack("<L", len(stringTable)))

        # Write the records.
        outputFile.write(records)

        # Write the string table.
        outputFile.write(stringTable)

        outputFile.close()

def getString(offset, data):
    result = ""
    index = 0
    while 1:
        byte = data[(offset + index):(offset + index) + 1]
        if(ord(byte) == 0x00): break
        result += byte
        index += 1
    return result

if __name__ == "__main__":
    main()
