#!/usr/bin/env python
# vi: set softtabstop=4 shiftwidth=4 tabstop=4 expandtab:
#
# Transcoder for CreatureDisplayInfo.dbc.
# Copyright (C) 2005  Rosten
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# Rosten <rosten@variadic.org>
#

from struct import *
from optparse import OptionParser
from xml.dom.DOMImplementation import implementation
from xml.dom.ext import Print
from xml.dom.ext.reader import Sax2
from xml.dom import Node
import xml.utils
import os
import string
import sys
import binascii

def main():

    # Parse commandline options
    parser = OptionParser("usage: %prog [options] fileIN fileOUT")
    parser.add_option("-d", "--decode", dest="decode", help="Decode the dbc to xml", action="store_true")
    parser.add_option("-e", "--encode", dest="encode", help="Encode the xml to dbc", action="store_true")
    (options, arguments) = parser.parse_args()
    if options.encode and options.decode:
        parser.error("Only one of encode or decode may be specified")
    if not options.encode and not options.decode:
        parser.error("Must specify one of encode or decode");
    if len(arguments) != 2:
        parser.error("Must specify an input file and an output file");

    if(options.decode):
        inputData = file(arguments[0], "rb").read();
        outputFile = file(arguments[1], "w");

        # Start the document.
        doctype = implementation.createDocumentType(None, None, None)
        document = implementation.createDocument("http://wow.variadic.org", "creatureModelData", doctype)

        # Check it's a dbc file (first 4 bytes).
        if inputData[0:4] != "WDBC":
            raise Exception("Invalid dbc file, missing WDBC header")

        # Get count of records in the file (from the 16 byte header).
        recordCount = unpack("<L", inputData[4:8])[0];

        # Get address of the string table.  It's after all the header (4 + 16)
        # and the 48 byte records.
        stringTableOffset = (4 + 16) + recordCount * 48

        # Add the unknown parts of the header to the file.
        unknown = binascii.b2a_hex(inputData[8:16])
        headerElement = document.createElement("header")
        document.documentElement.appendChild(headerElement);
        hexElement = document.createElement("hex")
        hexElement.appendChild(document.createTextNode(unknown))
        headerElement.appendChild(hexElement);

        # Loop decoding records.
        recordIndex = 0
        while(recordIndex < recordCount):
            recordOffset = (4 + 16) + recordIndex * 48;

            creatureDisplayElement = document.createElement("creatureDisplay")
            document.documentElement.appendChild(creatureDisplayElement)

            # Creature id.
            creatureId = unpack("<L", inputData[recordOffset + 0:recordOffset + 0 + 4])[0]
            creatureDisplayElement.setAttribute("id", str(creatureId))

            # Model id.
            id = unpack("<L", inputData[recordOffset + 4:recordOffset + 4 + 4])[0]
            idElement = document.createElement("modelId")
            idElement.appendChild(document.createTextNode(str(id)))
            creatureDisplayElement.appendChild(idElement)

            # Unknown 16 @ +8
            unknown = binascii.b2a_hex(inputData[recordOffset + 8:recordOffset + 8 + 16])
            hexElement = document.createElement("hex")
            hexElement.appendChild(document.createTextNode(unknown))
            creatureDisplayElement.appendChild(hexElement)

            # skin1
            creatureSkinOffset = unpack("<L", inputData[recordOffset + 24:recordOffset + 24 + 4])[0]
            creatureSkin = getString(stringTableOffset + creatureSkinOffset, inputData)
            skin1Element = document.createElement("skin1")
            skin1Element.appendChild(document.createTextNode(creatureSkin))
            creatureDisplayElement.appendChild(skin1Element)

            # skin2
            creatureSkinOffset = unpack("<L", inputData[recordOffset + 28:recordOffset + 28 + 4])[0]
            creatureSkin = getString(stringTableOffset + creatureSkinOffset, inputData)
            skin2Element = document.createElement("skin2")
            skin2Element.appendChild(document.createTextNode(creatureSkin))
            creatureDisplayElement.appendChild(skin2Element)

            # skin3
            creatureSkinOffset = unpack("<L", inputData[recordOffset + 32:recordOffset + 32 + 4])[0]
            creatureSkin = getString(stringTableOffset + creatureSkinOffset, inputData)
            skin3Element = document.createElement("skin3")
            skin3Element.appendChild(document.createTextNode(creatureSkin))
            creatureDisplayElement.appendChild(skin3Element)

            # Unknown 12 @ +36
            unknown = binascii.b2a_hex(inputData[recordOffset + 36:recordOffset + 36 + 12])
            hexElement = document.createElement("hex")
            hexElement.appendChild(document.createTextNode(unknown))
            creatureDisplayElement.appendChild(hexElement)

            recordIndex += 1

        # End the document.
        xml.dom.ext.PrettyPrint(document, outputFile)

    else:
        stringTable = None
        inputFile = file(arguments[0], "r")
        outputFile = file(arguments[1], "wb")
        document = Sax2.Reader().fromStream(inputFile)

        records = str()
        header = str()
        stringTable = str()
        creatureDisplayCount = 0

        # First byte of the string table will be a null.
        stringTable += chr(0)

        # Iterate over the nodes writing the records.
        for node in document.documentElement.childNodes:
            if(node.nodeType != Node.ELEMENT_NODE): continue

            # Is it a header?
            if(node.nodeName == "header"):

                # Add any child hex nodes to the header data.
                for child in node.childNodes:
                    if(child.nodeType != Node.ELEMENT_NODE): continue;
                    if(child.nodeName == "hex"):
                        header += binascii.a2b_hex(child.firstChild.nodeValue)

            # Is it a creatureDisplay?
            if(node.nodeName == "creatureDisplay"):
                creatureDisplayCount += 1
                record = str()

                # Write its id.
                record += pack("<L", int(node.getAttribute("id")))

                for child in node.childNodes:
                    if(child.nodeType != Node.ELEMENT_NODE): continue;

                    # Write any hex.
                    if(child.nodeName == "hex"):
                        record += binascii.a2b_hex(child.firstChild.nodeValue)

                    # Write any skins.
                    elif(child.nodeName == "skin1" or child.nodeName == "skin2" or child.nodeName == "skin3"):
                        index = len(stringTable)
                        name = child.firstChild.nodeValue;
                        record += pack("<L", index)
                        stringTable += name
                        stringTable += chr(0)

                    # Write ids.
                    elif(child.nodeName == "modelId"):
                        record += pack("<L", int(child.firstChild.nodeValue))

                    else:
                        print("Unhandled node: " + child.nodeName)

                records += record

        # Write the header ("WDBC", model count, (unknown header), string table
        # size)
        outputFile.write("WDBC")
        outputFile.write(pack("<L", creatureDisplayCount))
        outputFile.write(header)
        outputFile.write(pack("<L", len(stringTable)))

        # Write the records.
        outputFile.write(records)

        # Write the string table.
        outputFile.write(stringTable)

        outputFile.close()

def getString(offset, data):
    result = ""
    index = 0
    while 1:
        byte = data[(offset + index):(offset + index) + 1]
        if(ord(byte) == 0x00): break
        result += byte
        index += 1
    return result

if __name__ == "__main__":
    main()
