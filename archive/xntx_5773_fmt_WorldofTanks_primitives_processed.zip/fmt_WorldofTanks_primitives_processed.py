from inc_noesis import *
import noesis
import rapi

def registerNoesisTypes():
    handle = noesis.register("World of Tanks", ".primitives_processed")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    Magic = bs.readBytes(8)
    print(Magic)
    if Magic != b'\x65\x4E\xA1\x42\x6C\x69\x73\x74': 
        return 0
    return 1   

def noepyLoadModel(data, mdlList):
    ctx = rapi.rpgCreateContext()
    #rapi.setPreviewOption("setAngOfs","0 -60 90")        #set the default preview angle        
    bs = NoeBitStream(data)
    bs.seek(0x44, NOESEEK_ABS)
    meshName = rapi.getLocalFileName(rapi.getInputName()).strip(".primitives_processed")
    rapi.rpgSetName(meshName)
    print(meshName, ":mesh name")
    #rapi.rpgSetMaterial("Panzer58_guns_AM.dds")
    FCount = bs.readUInt()                                #face indices count
    print(FCount, ":face count")
    unk =  bs.readUInt()
    IBuf = bs.readBytes(FCount * 2)                       #multiply by 2 for word, 4 for dword indices 
    print(hex(bs.tell()), ":here")
    bs.seek(0xc, NOESEEK_REL)
    VCount = bs.readUInt()
    print(VCount, ":vertex count")
    check = bs.readShort()
    if check == 0:
        bs.seek(0x88, NOESEEK_REL)
    else:
        bs.seek(0x86, NOESEEK_REL)
    TMP = bs.tell()
    VBytes = 32 #32 or 40                                          #FVF/vertex stride
    print(hex(bs.tell()), ":here2")
    VBuf = bs.readBytes(VCount * VBytes)
    print(hex(bs.tell()), ":here3")
    check2 = bs.readByte()
    print(check2, ":check2")
    if check2 != 0x42:
        bs.seek(TMP, NOESEEK_ABS)
        VBytes = 40
        VBuf = bs.readBytes(VCount * VBytes)
        rapi.rpgSetOption(noesis.RPGOPT_TRIWINDBACKWARD, 1)  #uncomment to flip normals  
        rapi.rpgBindPositionBufferOfs(VBuf, noesis.RPGEODATA_FLOAT, VBytes, 0)   #position of vertices
        #rapi.rpgBindNormalBufferOfs(VBuf, noesis.RPGEODATA_FLOAT, VBytes, 12)   #normals -optional
        rapi.rpgBindUV1BufferOfs(VBuf, noesis.RPGEODATA_FLOAT, VBytes, 16)   #UV1
    else:
        rapi.rpgBindPositionBufferOfs(VBuf, noesis.RPGEODATA_FLOAT, VBytes, 0)   #position of vertices
        #rapi.rpgBindNormalBufferOfs(VBuf, noesis.RPGEODATA_FLOAT, VBytes, 12)   #normals -optional
        rapi.rpgBindUV1BufferOfs(VBuf, noesis.RPGEODATA_FLOAT, VBytes, 16)   #UV1
    print(VBytes, ":vbytes")
    checkTri = int(FCount % 3)                            #check if FCount is evenly divisible by 3,    
    if checkTri == 0:
        rapi.rpgCommitTriangles(IBuf, noesis.RPGEODATA_SHORT, FCount, noesis.RPGEO_TRIANGLE, 1)
    else:
        rapi.rpgCommitTriangles(IBuf, noesis.RPGEODATA_SHORT, FCount, noesis.RPGEO_TRIANGLE_STRIP, 1)
    mdl = rapi.rpgConstructModel()                                                          
    mdlList.append(mdl)
    rapi.rpgClearBufferBinds()
    return 1