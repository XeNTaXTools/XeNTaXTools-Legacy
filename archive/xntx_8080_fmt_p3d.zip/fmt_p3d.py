#by Durik 256 for xentax
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Ragnarok Web", ".p3d")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)
    
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    return 1

def noepyLoadModel(data, mdlList):
    data = rapi.decompInflate(data, int(len(data)*6))
    bs = NoeBitStream(data)
    
    inum = data.find(b'icount')+7
    bs.seek(inum)
    inum = ReadAmf3UInt(bs)
    
    vnum = data.find(b'numVertices')+12
    bs.seek(vnum)
    vnum = ReadAmf3UInt(bs)
    
    i_off = data.find(b'index\x0C')+6
    v_off = data.find(b'Position/')
    
    bs.seek(i_off)
    ReadAmf3UInt(bs)
    print('ibuf_offset:',bs.getOffset())
    ibuf = bs.readBytes(inum*2)
    
    bs.seek(v_off)
    stride, info, slen = calcStride(bs)
    
    bs.seek(v_off+slen)
    ReadAmf3UInt(bs)
    print('vbuf_offset:',bs.getOffset())
    vbuf = bs.readBytes(vnum*stride)
    
    print('stride:',stride, 'info:', info,'inum:',inum ,'i_off:',i_off,'vnum:',vnum,'v_off:',v_off)
    ctx = rapi.rpgCreateContext()
    rapi.rpgBindPositionBuffer(vbuf, noesis.RPGEODATA_FLOAT, stride)
    
    off = 12
    if info[1]:
        rapi.rpgBindNormalBufferOfs(vbuf, noesis.RPGEODATA_FLOAT, stride, off)
        off += 12
    if info[2]:
        rapi.rpgBindUV1BufferOfs(vbuf, noesis.RPGEODATA_FLOAT, stride, off)
        off += 8
    if info[3]:
        rapi.rpgBindUV2BufferOfs(vbuf, noesis.RPGEODATA_FLOAT, stride, off)
        off += 8
    if info[4]:
        rapi.rpgBindBoneIndexBufferOfs(vbuf, noesis.RPGEODATA_FLOAT, stride, off, 4)
        off += 16
    if info[5]:
        rapi.rpgBindBoneWeightBufferOfs(vbuf, noesis.RPGEODATA_FLOAT, stride, off, 4)
        off += 16
    
    rapi.rpgCommitTriangles(ibuf, noesis.RPGEODATA_SHORT, inum, noesis.RPGEO_TRIANGLE)
    mdl = rapi.rpgConstructModel()
    mdlList.append(mdl)
    rapi.setPreviewOption("setAngOfs", "0 -90 0")
    return 1

def calcStride(bs):
    vstr = searchString(bs)
    label = ['Position','Normal','Texcoord1', 'Texcoord2', 'BoneIndex','BoneWeight']
    info, size = [0,0,0,0,0,0], [12,12,8,8,16,16]
    stride = 0
    for i,x in enumerate(label):
        if x in vstr:
            info[i] = 1
            stride += size[i]
    return stride, info, len(vstr)+1

def ReadAmf3UInt(bs):
    valueA = bs.readUByte()
    if valueA <= 0x7F:
        return valueA

    valueB = bs.readUByte()
    if valueB <= 0x7F:
        return (valueA & 0x7F) << 7 | valueB

    valueC = bs.readUByte()
    if valueC <= 0x7F:
        return (valueA & 0x7F) << 14 | (valueB & 0x7F) << 7 | valueC

    valueD = bs.readUByte()
    ret = (valueA & 0x7F) << 22 | (valueB & 0x7F) << 15 | (valueC & 0x7F) << 8 | valueD
    if (ret & 268435456) == 268435456:
        ret = ret | -536870912;
    return ret
    
def searchString(bs):
    bytes = []
    byte = None
    while byte != 12:
        byte = bs.readUByte()
        bytes.append(byte)
    return noeAsciiFromBytes(bytes)