from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("F.E.A.R. Online", ".tex")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    if noeStrFromBytes(bs.readBytes(4)) != 'TEXR': return 0
    bs.seek(0xc)
    if noeStrFromBytes(bs.readBytes(3)) != 'DDS': return 0
    return 1
    
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.seek(0xc)
    ddsTex = bs.readBytes(bs.getSize() - bs.tell())
    tex = rapi.loadTexByHandler(ddsTex, ".dds")
    tex.name = rapi.getInputName()
    texList.append(tex)
    return 1