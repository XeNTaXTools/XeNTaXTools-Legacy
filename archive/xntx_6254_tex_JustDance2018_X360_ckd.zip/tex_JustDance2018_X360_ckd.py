from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Just Dance 2018 [X360]", ".ckd")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    if bs.readBytes(8) != b'\x00\x00\x00\x09\x54\x45\x58\x00': return 0
    return 1

def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data, NOE_BIGENDIAN)
    bs.seek(0x4f, NOESEEK_ABS)
    imgFmt = bs.readUByte()
    height = bs.readUShort()
    width = bs.readUShort()
    imgHeight = (height + 1) * 8
    imgWidth = (width + 1) & 0x1FFF
    print(imgWidth, "x", imgHeight, "-", hex(imgFmt))
    bs.seek(0xc, NOESEEK_REL)
    data = bs.readBytes(len(data) - bs.tell())
    #DXT1
    if imgFmt == 0x52:
        data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 8)
        texFmt = noesis.NOESISTEX_DXT1
    #DXT5
    elif imgFmt == 0x54:
        data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 16)
        texFmt = noesis.NOESISTEX_DXT5
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1