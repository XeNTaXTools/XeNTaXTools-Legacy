This tool will only work with release PC version of TT. If you need to extract
music/sfx from previous PoP games, use apropriate versions of my old tools.

How to use:
Extract whole package to the game's Sound folder and run
tt_extract_and_convert_music.bat
file. This will extract most of the ingame music (and some other junk too).
About 1.5Gb of free disk space required.

The credits song stored in the video\credits.bik file, use RADTools to get it.
Don't ask me for any assitance with that.


WARNING
This version may be somewhat unstable. Take care.

changes history:
21-dec 0.7b : implemented another tracks searching strategy (see /?)
17-dec 0.6b : initial poptt support

Enjoy,
-VAG