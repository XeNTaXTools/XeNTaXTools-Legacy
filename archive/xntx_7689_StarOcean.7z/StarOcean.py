from urllib.request import ProxyHandler, build_opener, install_opener, urlopen
from itertools import islice
from multiprocessing.dummy import Pool as ThreadPool
import os
import io
import gzip
import struct
import json
pool = ThreadPool(40)

if not os.path.exists("StarOcean"):
    os.makedirs("StarOcean")
#proxy = urllib.request.ProxyHandler({'http': 'http://192.168.1.91:8888'})
proxy = ProxyHandler({})
opener = build_opener(proxy)
opener.addheaders = [('X-QOOKIA-DEVICE-TYPE','web'),('User-Agent','Dalvik/2.1.0 (Linux; U; Android 7.1.2; huawei Build/PPR1.190810.011)')]
install_opener(opener)

#myFile = urlopen('http://production-cache.so-ana.com/download/1471/Android/manifest/etc2/hi/version_latest_Bulk.bin').read()
myFile = urlopen('http://production-cache.so-ana.com/download/1471/Android/manifest/etc2/hi/version_latest_Individual.bin').read()
#myFile = urlopen('http://production-cache.so-ana.com/download/1471/Android/manifest/etc2/hi/version_latest_ep1.bin').read()
#myFile = urlopen('http://production-cache.so-ana.com/download/1471/Android/manifest/etc2/hi/version_latest_ep2.bin').read()
#myFile = urlopen('http://production-cache.so-ana.com/download/1471/Android/manifest/etc2/hi/version_latest_ep3.bin').read()


def geturl(name):
	try:
		pass
		#print(name[1])
		fname = 'StarOcean\\' + name[1]

		if os.path.exists(fname):
			pass
		else:
			#print(fname)
			print('Downlaoding',name[0])
			myFile = urlopen(name[0]).read()
			#print(myFile)
			if len(myFile) > 0:

				tmp = ''
				if '/' in name[1]:
					tmp = name[1].rsplit('/',1)[0]
					#print(tmp)
					if os.path.exists('StarOcean\\' + tmp):
						pass
					else:
						os.makedirs('StarOcean\\' + tmp)
				#print(fname)
				with open(fname, 'wb') as f:
					f.write(myFile)
		
	except:
		pass




baseURL = 'http://production-cache.so-ana.com/download/1471/Android/'
names = []

lines = myFile[72:-1].split(b'\x90')
for line in lines:
	#print(line)
	bs = io.BytesIO(line)
	hashNameSize = struct.unpack('B', bs.read(1))[0] - 0xA0
	if hashNameSize == 1:
		bs.read(1)
		hashNameSize = struct.unpack('B', bs.read(1))[0] - 0xA0
		if hashNameSize == 58:
			bs.read(1)
			hashNameSize = struct.unpack('B', bs.read(1))[0]
	elif hashNameSize == 58:
		bs.read(1)
		hashNameSize = struct.unpack('B', bs.read(1))[0]
	#print(hashNameSize)
	hashName = bs.read(hashNameSize).decode("ASCII",errors='ignore')
	if '.bin' in hashName:
		print(hashName)
		bs.read(1)
		tmp = struct.unpack('B', bs.read(1))[0]
		while tmp != 0x86:
			tmp = struct.unpack('B', bs.read(1))[0]
		end = bs.tell() - 1
		#print("END",end)
		bs.seek(bs.tell() - 3,0)
		tmp = struct.unpack('B', bs.read(1))[0]
		while tmp != 0:
			tmp = struct.unpack('B', bs.read(1))[0]
			if tmp > 0xA0:
				#print(tmp - 0xA0,bs.tell())
				tmp = end - (bs.tell() + (tmp - 0xA0))
			else:
				#print(tmp,bs.tell())
				tmp = end - (bs.tell() + (tmp))
			start = bs.tell()
			bs.seek(bs.tell() - 2,0)
		fileName = line[start:end].decode("ASCII",errors='ignore')
		print(fileName)
		names.append([baseURL + hashName,fileName])


pool.map(geturl, names )


