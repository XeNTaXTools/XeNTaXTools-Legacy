# author: Volfin
# 1.00 - Initial Release
# 1.01 - Added Materials, and alternate UV support
# 1.02 - Fixed Flipped UV Maps
# 1.03 - Added mesh format 2048
# 1.04 - validated to Blender version 2.70; added check for Object mode
# 1.05 - added support for Alpha version models

bl_info = {
    "name": "Hitman2016 Dat Importer",
    "author": "Volfin",
    "version": (1, 0, 5),
    "blender": (2, 7, 0),
    "location": "File > Import > Dat (Hitman 2016 Model)",
    "description": "Import HitmanDat, io: mesh",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
    "category": "Import-Export"}
    
if "bpy" in locals():
    import imp
    if "import_HitmanDat" in locals():
        imp.reload(import_HitmanDat)
    if "export_HitmanDat" in locals():
        imp.reload(export_HitmanDat)

import bpy

from bpy.props import (StringProperty,
                       BoolProperty,
                       FloatProperty,
                       EnumProperty,
                       )

from bpy_extras.io_utils import (ImportHelper,path_reference_mode)

  
class HitmanDatImportOperator(bpy.types.Operator, ImportHelper):
    bl_idname = "import_scene.hitmandat"
    bl_label = "Hitman 2016 Importer(.Dat)"
    
    filename_ext = ".dat"
    skip_blank=False;

    randomize_colors = BoolProperty(\
        name="Random Material Colors",\
        description="Assigns a random color to each material",\
        default=True,\
        )

    import_vertcolors = BoolProperty(\
        name="Import Vertex Colors",\
        description="Import Vertex Colors",\
        default=False,\
        )
    
    use_layers = BoolProperty(\
        name="Seperate Mesh Layers",\
        description="Place Meshes on seperate layers",\
        default=True,\
        )
    mesh_scale = bpy.props.FloatProperty(
        name="Scale Factor",
        description="Mesh Import Scale Factor",
        default=1.0,
    )

    filter_glob = StringProperty(default="*.dat;*.prim;*.pc_prim") # , options={'HIDDEN'}
    filepath = bpy.props.StringProperty(subtype="FILE_PATH")        
    path_mode = path_reference_mode

    def execute(self, context):
        import os, sys
        print("Import Execute called")
        cmd_folder = os.path.dirname(os.path.abspath(__file__))
        if cmd_folder not in sys.path:
            sys.path.insert(0, cmd_folder)

        import import_HitmanDat
        result=import_HitmanDat.import_HitmanDat(self.filepath, bpy.context,self.randomize_colors,self.import_vertcolors,self.skip_blank,self.use_layers,self.mesh_scale)

        # force back off
        #self.skip_blank=False
        #self.use_layers=False
        
        if result is not None:
            self.report({'ERROR'},result)

        return {'FINISHED'}

    def invoke(self, context, event):

        print("Import Invoke called")
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        col.label('Mesh Scale Factor')
        col.prop(self, "mesh_scale")
        row = layout.row(align=True)
        row.prop(self, "randomize_colors")
        row = layout.row(align=True)
        row.prop(self, "import_vertcolors")
        row = layout.row(align=True)
        row.prop(self, "use_layers")

#
# Registration
#
def menu_func_import(self, context):
    self.layout.operator(HitmanDatImportOperator.bl_idname, text="dat(Hitman 2016 Model)(.dat)",icon='PLUGIN')
   
def register():
    bpy.utils.register_module(__name__)
    bpy.types.INFO_MT_file_import.append(menu_func_import)
    
def unregister():
    bpy.utils.unregister_module(__name__)
    bpy.types.INFO_MT_file_import.remove(menu_func_import)
    
if __name__ == "__main__":
    register()