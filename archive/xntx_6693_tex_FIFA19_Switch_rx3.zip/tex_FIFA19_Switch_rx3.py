from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("FIFA 2019", ".rx3")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    if noeStrFromBytes(bs.readBytes(4)) != 'RX3l': return 0
    return 1

def noepyLoadRGBA(data, texList):
    rapi.processCommands("-texnorepfn")
    bs = NoeBitStream(data)
    bs.seek(0x4)
    version = bs.readUInt() #??
    rx3Size = bs.readUInt()
    entries = bs.readUInt()
    tmp = bs.tell()
    myString = bs.readBytes(0x200)
    myIndex = myString.find(b'\xB2\x9E\x9B\x4C')
    bs.seek(myIndex + tmp + 4)
    #print(hex(bs.tell()), ":here")
    strTableOff = bs.readUInt() + 0x10
    bs.seek(tmp)
    for i in range(entries):
        type = bs.readBytes(4)
        offset = bs.readUInt()
        size = bs.readUInt()
        zero = bs.readInt()
        tmp2 = bs.tell()
        if type == b'\xda\x60\x0b\x7a':
            bs.seek(strTableOff)
            type2 = bs.readBytes(4)
            strideSZ = bs.readUInt()
            texName = bs.readString()
            print(texName)
            strTableOff = bs.tell()
            bs.seek(offset)
            size = bs.readUInt()
            bs.readByte()
            imgFmt = bs.readUByte()
            bs.readByte()
            bs.readByte()
            imgWidth = bs.readUShort()
            imgHeight = bs.readUShort()
            bs.readUShort()
            mips = bs.readUShort()
            bs.seek(0x10, 1)            
            data = bs.readBytes(size - 0x20)
            #DXT1
            if imgFmt == 0x0:
                texFmt = noesis.NOESISTEX_DXT1
            #DXT5
            elif imgFmt == 0x2:
                texFmt = noesis.NOESISTEX_DXT5
            #ATI2
            elif imgFmt == 0x7:
                data = rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_ATI2) #DX10
                texFmt = noesis.NOESISTEX_RGBA32
            texList.append(NoeTexture(texName, imgWidth, imgHeight, data, texFmt))
        bs.seek(tmp2)
    return 1