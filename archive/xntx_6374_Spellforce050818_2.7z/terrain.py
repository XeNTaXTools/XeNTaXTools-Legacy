"""

Simple terrain visualization.

"""

import struct

from PyQt5.QtCore import Qt
from PyQt5.QtGui import QLinearGradient, QVector3D
from PyQt5.QtWidgets import QApplication, QVBoxLayout, QWidget
from PyQt5.QtDataVisualization import Q3DSurface, Q3DTheme, QSurface3DSeries
from PyQt5.QtDataVisualization import QSurfaceDataItem, QSurfaceDataProxy


class TerrainView(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)

        self.proxy = QSurfaceDataProxy()
        self.series = None
        #self.proxy.resetArray(heightmap2)
        #self.series = QSurface3DSeries(self.proxy)
        #self.series.setDrawMode(QSurface3DSeries.DrawSurface)

        self.g = Q3DSurface()
        #self.g.addSeries(self.series)
        self.g.axisX().setRange(0, 512)
        self.g.axisZ().setRange(0, 512)
        self.g.axisY().setRange(0, 15000)

        #self.g.seriesList()[0].setColorStyle(Q3DTheme.ColorStyleRangeGradient)
        self.gr = QLinearGradient()
        self.gr.setColorAt(0.0, Qt.darkBlue)
        self.gr.setColorAt(0.5, Qt.darkGray)
        self.gr.setColorAt(0.8, Qt.gray)
        self.gr.setColorAt(1.0, Qt.lightGray)
        #self.g.seriesList()[0].setBaseGradient(self.gr)

        container = QWidget.createWindowContainer(self.g)

        vbox = QVBoxLayout()
        vbox.addWidget(container)
        self.setMinimumSize(800, 600)
        self.setLayout(vbox)

    def set_data(self, data):
        self.proxy.resetArray(data)
        self.series = QSurface3DSeries(self.proxy)
        self.series.setDrawMode(QSurface3DSeries.DrawSurface)
        self.g.addSeries(self.series)
        self.g.seriesList()[0].setColorStyle(Q3DTheme.ColorStyleRangeGradient)
        self.g.seriesList()[0].setBaseGradient(self.gr)

    def set_texture(self, texture):
        self.series.setTexture(texture)

    def set_from_heightmap_arrays(self, raw_heightmaps):
        if self.series is not None:
            self.g.removeSeries(self.series)
        heightmap = []
        dimension = len(raw_heightmaps)
        self.g.axisX().setRange(0, dimension)
        self.g.axisZ().setRange(0, dimension)
        for row in raw_heightmaps:
            values = list(struct.unpack('<{}H'.format(dimension), row.data))
            heightmap.append(values)

        for z in range(dimension):
            for x in range(dimension):
                y = heightmap[z][x]
                heightmap[z][x] = QSurfaceDataItem(QVector3D(x, y, z))
        self.proxy.resetArray(heightmap)
        self.series = QSurface3DSeries(self.proxy)
        self.series.setDrawMode(QSurface3DSeries.DrawSurface)
        self.g.addSeries(self.series)
        #self.g.seriesList()[0].setColorStyle(Q3DTheme.ColorStyleRangeGradient)
        #self.g.seriesList()[0].setBaseGradient(self.gr)


def test():
    import json

    with open('heightmap.txt') as inf:
        heightmap = json.load(inf)
    heightmap2 = []
    for z in range(512):
        row = []
        for x in range(512):
            y = heightmap[512 * z + x]
            item = QSurfaceDataItem(QVector3D(x, y, z))
            row.append(item)
        heightmap2.append(row)

    app = QApplication(sys.argv)
    t = TerrainView()
    t.set_data(heightmap2)
    t.show()
    return app.exec_()


if __name__ == '__main__':
    import sys
    sys.exit(test())
