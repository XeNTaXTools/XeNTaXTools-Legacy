"""

Container File Format

This format is used by GameData.cff, .map files, and save games.

TODO

tool that repackages a file with replacement resources

"""

import io
import struct
import zlib


class RawResource:
    def __init__(self, ins):
        # type - see dbtypes
        # index - allows for arrays, only used by DBType.HEIGHT_MAP
        # compressed - we save this because a tool is planned to allow
        #     insertion of replacement resources into .map files,
        #     so we have to know whether to compress
        # version - allows for different schema of the same type
        self.type, self.index, self.compressed, size, self.version = \
            struct.unpack('<3hLh', ins.read(12))
        if self.compressed:
            uncompressed_size, = struct.unpack('<L', ins.read(4))
            compressed_data = ins.read(size)
            self.data = zlib.decompress(compressed_data)
            assert len(self.data) == uncompressed_size
        else:
            self.data = ins.read(size)


class ContainerFile:
    MAGIC = 0xdd72dd12

    def __init__(self, filename):
        with open(filename, 'rb') as inf:
            raw_data = inf.read()
        ins = io.BytesIO(raw_data)
        magic, = struct.unpack('<L', ins.read(4))
        assert magic == ContainerFile.MAGIC
        # For map: 3 1 various 0, for game data: 2 2 1 0
        # self.c is not unique, Howling Mounds and Whisper are both 79
        self.a, self.b, self.c, self.d = struct.unpack('<4L', ins.read(16))

        self.resources = {}
        while ins.tell() < len(raw_data):
            resource = RawResource(ins)
            try:
                self.resources[resource.type].append(resource)
            except KeyError:
                self.resources[resource.type] = [resource]
