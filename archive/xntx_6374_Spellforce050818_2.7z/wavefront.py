"""

Export a model to Wavefront OBJ and MTL files.

"""


def export_model(msbfile, textures, outfilename):
    with open(outfilename, 'w') as outf:
        # TODO: extract filename without extension
        outf.write('mtllib MODELNAME.MTL\n')
        outf.write('usemtl MODELNAME\n')
        for v in msbfile.meshes[0].verts:
            outf.write('v {} {} {}\n'.format(v.pos.x(), v.pos.y(), v.pos.z()))
        for v in msbfile.meshes[0].verts:
            outf.write('vt {} {}\n'.format(v.texcoord.x(), v.texcoord.y()))
        # TODO: is the winding order correct?
        for tri in msbfile.meshes[0].tris:
            outf.write('f {} {} {}\n'.format(tri.c + 1, tri.b + 1, tri.a + 1))
        # TODO: write material file



