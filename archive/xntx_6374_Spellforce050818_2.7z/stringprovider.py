from collections import namedtuple
import io
import struct

import utils


_fields = 'string_id language is_dialogue script_name_offset string_offset'
_StringInfo = namedtuple('_StringInfo', _fields)


RAW_SCRIPT_NAME_LENGTH = 50
RAW_STRING_LENGTH = 512


class StringProvider:
    def __init__(self, raw_data):
        self.raw_data = raw_data
        self.language = 1  # English
        ins = io.BytesIO(self.raw_data)
        self.entries = {}
        while ins.tell() < len(self.raw_data):
            string_id, language, is_dialog = struct.unpack('<H2B', ins.read(4))
            script_name_ofs = ins.tell()
            ins.seek(RAW_SCRIPT_NAME_LENGTH, io.SEEK_CUR)
            string_ofs = ins.tell()
            ins.seek(RAW_STRING_LENGTH, io.SEEK_CUR)
            if language == self.language:
                vals = (
                    string_id, language, is_dialog,
                    script_name_ofs, string_ofs
                )
                self.entries[string_id] = _StringInfo._make(vals)

    def script_name(self, string_id):
        try:
            entry = self.entries[string_id]
        except KeyError:
            return '(string id not found)'
        ofs = entry.script_name_offset
        raw_string = self.raw_data[ofs:ofs+RAW_SCRIPT_NAME_LENGTH]
        return utils.read_cstr(raw_string)

    def string(self, string_id):
        try:
            entry = self.entries[string_id]
        except KeyError:
            return '(string id not found)'
        ofs = entry.string_offset
        raw_string = self.raw_data[ofs:ofs+RAW_STRING_LENGTH]
        return utils.read_cstr(raw_string)
