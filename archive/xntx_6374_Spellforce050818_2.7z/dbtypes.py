"""

This module supports loading what we're calling DBTypes (Database Types),
found in ContainerFiles.  This means GameData.cff and all the .map files.
The module is used by GameDataView's data model.

It was discovered that much of the work on GameData.cff overlapped with work
by Hokan Ashir and others at https://github.com/Hokan-Ashir/SFGameDataEditor
Where there was large overlap, names here were replaced with the names used
in that project.

"""

import io
import struct


# Words are better than numbers.  We prefix MAP_ for stuff like MAP_BUILDING
# to avoid clashes with the GameData.cff BUILDINGS resource.
class DBType:
    TEXTURE_MAP = 2
    TYPE3 = 3
    TEXTURE_SET = 4
    HEIGHT_MAP = 6
    MAP_BUILDING = 11
    MAP_NPC = 12
    MAP_ADORNMENT = 29
    MAP_MONUMENT = 30
    TYPE31 = 31
    TYPE32 = 32
    MAP_PORTAL = 35
    MAP_WATER = 40
    VISIBILITY_FLAG = 42
    MAP_WEATHER = 44
    TYPE46 = 46
    TYPE53 = 53
    MAP_BINDPOINT = 55
    BLOCK_FLAG = 56
    COOP_SPAWN_SETTINGS = 59
    TYPE60 = 60
    BUILDINGS_ARMY_REQUIREMENTS = 2001
    SPELL_PARAMETERS = 2002
    ITEM_PRICE_PARAMETERS = 2003
    ARMOR_PARAMETERS = 2004
    CREATURE_PARAMETERS = 2005
    CREATURE_SKILLS = 2006
    ITEM_UI_ELEMENTS = 2012
    ITEM_SCROLLS = 2013
    ITEM_SPELL_EFFECTS = 2014
    WEAPON_PARAMETERS = 2015
    STRING_TABLE = 2016
    ITEM_REQUIREMENTS = 2017
    ITEM_EFFECTS = 2018
    RACES = 2022
    TYPE2023 = 2023
    CREATURE_COMMON_PARAMETERS = 2024
    CREATURE_EQUIPMENT = 2025
    CREATURE_SPELLS = 2026
    CREATURE_RESOURCES = 2028
    BUILDINGS = 2029
    BUILDING_OUTLINES = 2030
    BUILDINGS_REQUIREMENTS = 2031
    TYPE2032 = 2032
    BUTTONS = 2036
    SKILL_TREES = 2039
    CREATURE_CORPSE_LOOT = 2040
    MERCHANT_INVENTORY = 2041
    MERCHANT_INVENTORY_ITEMS = 2042
    RESOURCE_NAME = 2044
    TYPE2047 = 2047
    PLAYER_LEVEL_STATS = 2048
    TYPE2049 = 2049
    ADORNMENTS = 2050
    NPC_NAMES = 2051
    CAMPAIGNS = 2052
    PORTALS = 2053
    SPELL_UI_MAP = 2054
    TYPE2055 = 2055
    TYPE2056 = 2056
    ADORNMENT_OUTLINES = 2057
    TYPE2058 = 2058
    TOOLTIPS = 2059
    QUESTS = 2061
    SKILL_PARAMETERS = 2062
    WEAPON_TYPES = 2063
    WEAPON_MATERIALS = 2064
    CHEST_CORPSE_LOOT = 2065
    HERO_SPELLS = 2067
    SET_BONUSES = 2072
    TYPE8000 = 8000


# Comments on 'version' refer to resource version in the ContainerFile.
# When the value is a tuple, it's the only version.  When it's a dictionary,
# there are multiple versions of the type.
# Value fields are:
#     resource name
#     resource member names
#     struct module unpack string
#     (optional) extra info to help unpacking
DBTYPES = {
    DBType.TEXTURE_MAP: (  # version is always 6
        'TextureMap',
        None,
        None
    ),
    # zeroing this out makes patrolling NPCs run like mad things on their
    # paths, also hero runs at huge speeds
    DBType.TYPE3: (  # version is always 3
        'unknown3',
        'a b c d e f g h i',
        '<bbhhHbbhH'
    ),
    DBType.TEXTURE_SET: (  # version is always 4
        'TextureSet',
        None,
        None
    ),
    DBType.HEIGHT_MAP: (
        'HeightMap',
        None,
        None
    ),
    DBType.MAP_BUILDING: {
        2: ('building', 'x y angle u buildingId1 level', '<4H2B'),
        3: ('building', 'x y angle u buildingId1 level u2', '<4H3B')
    },
    DBType.MAP_NPC: {
        4: ('npc', 'x y c npcId scriptId f g', '<6HB'),
        5: ('npc', 'x y c npcId scriptId f g h', '<6H2B')
    },
    DBType.MAP_ADORNMENT: {
        4: ('adorns', 'x y adornId angle scriptId u0', '<6H'),
        5: ('adorns', 'x y adornId angle scriptId u0 u1', '<7H'),
        6: ('adorns', 'x y adornId angle scriptId u0 u1 u2', '<8H')
    },
    DBType.MAP_MONUMENT: (  # version is always 1
        'monument',
        'x y adornId angle g',
        '<4HB'
    ),
    # 31: size always 1048576, highly sparse
    # nonzero count in Greyfell is 4285 max elem 53
    # Liannon: 3701 max 52
    # Eloni: 10010 max 53
    # Southern Windwalls: 14767 max 52
    # texture overlays?
    DBType.TYPE31: (  # version is always 2
        'unknown31',
        None,
        None
    ),
    DBType.TYPE32: (  # version is always 1
        'unknown32',
        None,
        None
    ),
    DBType.MAP_PORTAL: (  # version is always 1
        'portal',
        'x y angle portalId',
        '<4H'
    ),
    DBType.MAP_WATER: (  # version is always 1
        'water',
        ## type: water=0, swamp=1, lava=2, ice=3
        'x y depth type',
        '<3HB',
        'int8count'
    ),
    DBType.VISIBILITY_FLAG: (  # version is always 1
        # There is a visibility flag and a block flag that can be placed
        # in the editor. 42 and 56 undoubtedly.  Which is which?
        'visFlag',
        'x y',
        '<2H'
    ),
    # 44 Weather todo  version is always 1
    # 46 unknown46 todo  version is always 1
    # 53: major part is of length 128 * 128 * 3
    # header conissts of x y stringId tuples, but format
    # not figured out yet; stringIds are race names...
    # 53
    DBType.MAP_BINDPOINT: (  # version is always 1
        'bindpoints',
        'x y nameId',
        '<2HL',
        'int32count'
    ),
    DBType.BLOCK_FLAG: (  # version is always 1
        'blockFlag',
        'x y',
        '<2H'
    ),
    # 59 CoopSpawnSettings todo
    # 60 unknown60 todo

    DBType.BUILDINGS_ARMY_REQUIREMENTS: (
        'BuildingsArmyRequirements',
        'unitId numberOfRequirements buildingId',
        '<HBH'
    ),
    DBType.SPELL_PARAMETERS: (
        'SpellParameters',
        '''spellNumber spellNameId requirementClass1 requirementSubclass1 '''
        '''requirementLevel1 requirementClass2 requirementSubclass2 '''
        '''requirementLevel2 requirementClass3 requirementSubclass3 '''
        '''requirementLevel3 unk1 unk2 unk3 manaUsage castTime cooldown '''
        '''minRange maxRange castType param0 param1 param2 param3 param4 '''
        '''param5 param6 param7 param8 param9 param10''',
        '<2H12BH2L3H11L'
    ),
    DBType.ITEM_PRICE_PARAMETERS: (
        'ItemPriceParameters',
        '''itemId typeId nameId unitStatsId armyStatsId buildingId unknown '''
        '''copperSellingPrice copperBuyingPrice itemSetId''',
        '<6HB2LB'
    ),
    DBType.ARMOR_PARAMETERS: (
        'ArmorParameters',
        '''itemId strength stamina agility dexterity health charisma '''
        '''intelligence wisdom mana armor fireResistance iceResistance '''
        '''blackResistance mindResistance runSpeed fightSpeed castSpeed''',
        '<H17h'
    ),
    DBType.CREATURE_PARAMETERS: (
        'CreatureParameters',
        '''statsId level raceId agility charisma dexterity intelligence '''
        '''stamina strength wisdom unknown1 fireResistance iceResistance '''
        '''blackResistance mindResistance walkSpeed fightSpeed castSpeed '''
        '''size unknown2 spawnTime genderAndVulnerability headId '''
        '''equipmentSlotId''',
        '<2HB17HLBHB'
    ),
    DBType.CREATURE_SKILLS: (
        'CreatureSkills',
        'creatureStatsId skillSchoolClass skillSchoolSubClass skillLevel',
        '<H3B'
    ),
    DBType.ITEM_UI_ELEMENTS: (
        'itemUiElements',
        'itemId a name a',
        '<HB64sH'
    ),
    DBType.ITEM_SCROLLS: (
        'itemScrolls',
        'itemId1 itemId2',
        '<2H'
    ),
    DBType.ITEM_SPELL_EFFECTS: (
        'ItemSpellEffects',
        'itemId itemEffectNumber effectNumber',
        '<HBH'
    ),
    DBType.WEAPON_PARAMETERS: (
        'WeaponParameters',
        'itemId minDamage maxDamage minRange maxRange speed type material',
        '<8H'
    ),
    DBType.STRING_TABLE: (
        'StringTable',
        None,
        None
    ),
    DBType.ITEM_REQUIREMENTS: (
        'ItemRequirements',
        '''itemId requirementNumber schoolRequirementClass '''
        '''subSchoolRequirementClass level''',
        '<H4B'
    ),
    DBType.ITEM_EFFECTS: (
        'ItemEffects',
        'itemId effectNumber',
        '<2H'
    ),
    DBType.RACES: (
        'races',
        'index a b c d e f nameId u1 u12 u2 u21 u3 u31 u4 u41 u5',
        '<7B10H'
    ),
    DBType.TYPE2023: (
        'unknown23',
        'a b c',  # 1..32, 1..32, 0 | 100 | -100
        '3b'
    ),
    DBType.CREATURE_COMMON_PARAMETERS: (
        'CreatureCommonParameters',
        '''creatureId nameId statsId experience unknown1 hpFactor unknown2 '''
        '''unknown3 armor unitNameId unknown4''',
        '<3HLH2LBH40sB'
    ),
    DBType.CREATURE_EQUIPMENT: (
        'CreatureEquipment',
        'creatureId equipmentSlot itemId',
        '<HBH'
    ),
    DBType.CREATURE_SPELLS: (
        'CreatureSpells',
        'creatureId skillNumber spellNumber',
        '<HBH'
    ),
    DBType.CREATURE_RESOURCES: (
        'CreatureResources',
        'creatureId resourceId resourceAmount',
        '<H2B'
    ),
    DBType.BUILDINGS: (
        # anchor point is a guess based on editor docs 6.1
        'Buildings',
        '''buildingId raceId enterSlot slotsAmount hpAmount nameId '''
        '''anchorX anchorY unknown3 workerJobTime unknown4 '''
        '''rotation unknown5 unknown6''',
        '<H3B2H2hB4HB'
    ),
    DBType.BUILDING_OUTLINES: (
        'BuildingOutlines',
        'buildingId index b coords',
        '(special)'
    ),
    DBType.BUILDINGS_REQUIREMENTS: (
        'BuildingRequirements',
        'buildingId resourceId resourceAmount',
        '<HBH'
    ),
    DBType.TYPE2032: (
        'unknown32',
        'a b',  # 1..120, 778 | 1802
        '<2H'
    ),
    DBType.BUTTONS: (
        'buttons',
        '''index c nameId anIndex wood stone iron lenya aria moonsilver '''
        '''food name last1 last2''',
        '<11H64s2H'
    ),
    DBType.SKILL_TREES: (
        'skillTrees',
        'skillType skillSubtype nameId',
        '<2BH'
    ),
    DBType.CREATURE_CORPSE_LOOT: (
        'CreatureCorpseLoot',
        '''creatureId slotNumber itemId1 chanceToGetItem1 itemId2 '''
        '''chanceToGetItem2 itemId3''',
        '<HBHBHBH'
    ),
    DBType.MERCHANT_INVENTORY: (
        'MerchantInventory',
        'inventoryId merchantId',
        '<2H'
    ),
    DBType.MERCHANT_INVENTORY_ITEMS: (
        'MerchantInventoryItems',
        'inventoryId itemId itemType',
        '<3H'
    ),
    DBType.RESOURCE_NAME: (
        'resourceName',
        'resourceType nameId',
        '<BH'
    ),
    DBType.TYPE2047: (
        'unknown47',
        'inventoryId b c',
        '<HBH'
    ),
    DBType.PLAYER_LEVEL_STATS: (
        'PlayerLevelStats',
        '''level hpFactor mpFactor experience maxAttributesPoints '''
        '''maxSkillLevel weaponFactor armorFactor''',
        '<B2HL2B2H'
    ),
    DBType.TYPE2049: (
        'unknown49',
        'a',
        '<h'
    ),
    DBType.ADORNMENTS: (
        'adorns',
        'adornId nameId groupId h name b c d',
        '<3HB41s3H'
    ),
    DBType.NPC_NAMES: (
        'npcNames',
        'a b nameId',
        '<3H'
    ),
    DBType.CAMPAIGNS: (
        'campaigns',
        'index c d name coda',
        '<2HB64sH'
    ),
    DBType.PORTALS: (
        'portals',
        'portalId u0 destX destY u4 nameId',
        '<HL2hBH'
    ),
    DBType.SPELL_UI_MAP: (
        'spellUIMap',
        'index nameId a b c d e name last',
        '<2H5B64sH'
    ),
    DBType.TYPE2055: (
        'unknown55',
        'a b',
        '<HB'
    ),
    # 2056: 01 00 01 01 01 00 01 00 01 02 02 00 - too small to understand
    DBType.ADORNMENT_OUTLINES: (
        'adornOutlines',
        'adornId index b coords',
        '(special)'
    ),
    DBType.TYPE2058: (
        'unknown58',
        'a b',
        '<2H'
    ),
    DBType.TOOLTIPS: (
        'tooltips',
        'index nameId stringId',
        '<3H'
    ),
    DBType.QUESTS: (
        'quests',
        'questId prevQuestId mainStory nameId descrId k m',
        '<2LB4H'
    ),
    DBType.SKILL_PARAMETERS: (
        'SkillParameters',
        '''skillTypeId level strengthRequired staminaRequired '''
        '''agilityRequired dexterityRequired charismaRequired '''
        '''intelligenceRequired wisdomRequired''',
        '9B'
    ),
    DBType.WEAPON_TYPES: (
        'weaponTypes',
        'typeId nameId c',
        '<2HB'
    ),
    DBType.WEAPON_MATERIALS: (
        'weaponMaterials',
        'materialId nameId',
        '<2H'
    ),
    DBType.CHEST_CORPSE_LOOT: (
        'ChestCorpseLoot',
        '''chestCorpseId slotNumber itemId1 chanceToGetItem1 itemId2 '''
        '''chanceToGetItem2 itemId3''',
        '<HBHBHBH'
    ),
    DBType.HERO_SPELLS: (
        'HeroSpells',
        'statsId skillNumber spellNumber',
        '<HBH'
    ),
    DBType.SET_BONUSES: (
        'setBonuses',
        'index nameId u',
        '<BHB'
    )
    # 8000
    # Versions TODO not including lan, lanfreegame folders, check those
    # 1: always [0]
    # 2: always [0, 0]
    # 3: always [0, 0, 100, 0]
}


def get_typeinfo(resource):
    """Return the DBTYPES value for a resource, accounting for versions."""
    typeinfo = DBTYPES[resource.type]
    if isinstance(typeinfo, dict):
        # Multiple versions of the resource exist:
        typeinfo = typeinfo[resource.version]
    return typeinfo


def load_outlines(data):
    """Special loader for outline resources with variable-length fields."""
    # It's extremely ugly how this is being done, save the data permanently.
    ins = io.BytesIO(data)
    outlines = []
    while ins.tell() < len(data):
        eid, a, b, length = struct.unpack('<H3B', ins.read(5))
        coords = [struct.unpack('<2h', ins.read(4)) for _ in range(length)]
        outlines.append((eid, a, b, coords))
    return outlines


def field_names(resource):
    """Return a list of names for each column/member of a resource type."""
    typeinfo = get_typeinfo(resource)
    names = typeinfo[1]
    return names.split(' ')


def field_name(resource, index):
    """Return the name of a resource type column/member by index."""
    names = field_names(resource)
    return names[index]


def row_count(resource):
    """Return the number of rows in a resource, accounting for versions."""
    if resource.type in (DBType.BUILDING_OUTLINES, DBType.ADORNMENT_OUTLINES):
        outlines = load_outlines(resource.data)
        return len(outlines)
    # general case
    typeinfo = get_typeinfo(resource)
    return len(resource.data) // struct.calcsize(typeinfo[2])


def read_row(resource, row):
    """Return a list of values for each column/member of a row by index."""
    # Special cases:
    if resource.type in (DBType.BUILDING_OUTLINES, DBType.ADORNMENT_OUTLINES):
        outlines = load_outlines(resource.data)
        return outlines[row]
    # General cases:
    typeinfo = get_typeinfo(resource)
    size = struct.calcsize(typeinfo[2])
    offset = row * size
    if len(typeinfo) == 4:  # special marker
        if typeinfo[3] == 'int8count':
            offset += 1
        elif typeinfo[3] == 'int32count':
            offset += 4
    chunk = resource.data[offset:offset+size]
    fmt = typeinfo[2]
    return struct.unpack(fmt, chunk)
