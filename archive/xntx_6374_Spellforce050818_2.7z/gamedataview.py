from PyQt5.QtCore import Qt, QAbstractTableModel, QVariant, pyqtSignal
from PyQt5.QtWidgets import QHBoxLayout, QWidget
from PyQt5.QtWidgets import QListWidget, QListWidgetItem, QTableView

from cff import ContainerFile
import dbtypes
from stringprovider import StringProvider
import utils


class GameData:
    def __init__(self, filename):
        file = ContainerFile(filename)
        # TODO: ugly, but for the moment just take them:
        self.resources = file.resources
        # TODO: hack: this is due to piggybacking this class in mapviewer
        if 'GameData.cff' in filename:
            raw_data = self.resource(dbtypes.DBType.STRING_TABLE).data
            self.string_provider = StringProvider(raw_data)

    def set_string_provider(self, string_provider):
        self.string_provider = string_provider

    def resource(self, key):
        # Bypass the index part of a resource, since it only applies
        # to the heightmaps.
        return self.resources[key][0]


class TableModel(QAbstractTableModel):
    def __init__(self, parent, game_data):
        super().__init__(parent)
        self.game_data = game_data
        self.dbtype = None
        self.renderers = (
            ("field_name == 'nameId'", self.render_string_id),
            ("field_name == 'stringId'", self.render_string_id),
            ("field_name == 'descrId'", self.render_string_id),
            ("self.dbtype == 2024 and field_name == 'name'", self.decode_string),
            ("self.dbtype == 2024 and field_name == 'unknown2'", self.hexify_int),
            ("self.dbtype == 2024 and field_name == 'unitNameId'", self.decode_string),
            ("self.dbtype == 2036 and field_name == 'name'", self.decode_string),
            ("self.dbtype == 2050 and field_name == 'name'", self.decode_string),
            ("self.dbtype == 2052 and field_name == 'name'", self.decode_string),
            ("self.dbtype == 2054 and field_name == 'name'", self.decode_string),
        )

    def rowCount(self, parent=None, *args, **kwargs):
        if self.dbtype is None:
            return 0
        resource = self.game_data.resource(self.dbtype)
        return dbtypes.row_count(resource)

    def columnCount(self, parent=None, *args, **kwargs):
        if self.dbtype is None:
            return 0
        resource = self.game_data.resource(self.dbtype)
        return len(dbtypes.field_names(resource))

    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid() or role != Qt.DisplayRole:
            return QVariant()
        if self.dbtype is None:
            return QVariant()
        # Upack data fields for the type:
        resource = self.game_data.resource(self.dbtype)
        values = dbtypes.read_row(resource, index.row())
        # Prepare specialized rendering of the data:
        # (field_name is used by the renderers)
        field_name = dbtypes.field_name(resource, index.column())
        value = values[index.column()]
        for pred, func in self.renderers:
            if eval(pred):
                return func(value)
        # Support lists for things like coordinate arrays:
        if isinstance(value, list):
            return str(value)
        # No specialized rendering, return the raw value:
        return value

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        if role != Qt.DisplayRole or orientation != Qt.Horizontal:
            return QVariant()
        if self.dbtype is None:
            return QVariant()
        resource = self.game_data.resource(self.dbtype)
        return dbtypes.field_name(resource, section)

    def set_type(self, dbtype):
        self.dbtype = dbtype

    def force_update(self):
        self.beginResetModel()
        self.endResetModel()

    # Helper functions for rendering special data fields:
    def render_string_id(self, value):
        return self.game_data.string_provider.string(value)

    def decode_string(self, value):
        return utils.read_cstr(value)

    def hexify_int(self, value):
        return hex(value)

    def get_coord_list(self):
        if self.dbtype is None:
            return []
        resource = self.game_data.resource(self.dbtype)
        names = dbtypes.field_names(resource)
        if 'x' in names and 'y' in names:
            coords = []
            xc = names.index('x')
            yc = names.index('y')
            for row in range(self.rowCount()):
                x = self.data(self.createIndex(row, xc))
                y = self.data(self.createIndex(row, yc))
                coords.append((x, y))
            return coords
        else:
            return []


class GameDataView(QWidget):
    coords_available = pyqtSignal(list)

    def __init__(self, parent, game_data):
        super().__init__(parent)
        self.game_data = game_data

        self.list_widget = QListWidget(self)
        self.table_view = QTableView(self)
        if self.game_data is not None:
            self.table_model = TableModel(self, self.game_data)
            self.populate_list()
            self.table_view.setModel(self.table_model)

        self.list_widget.itemClicked.connect(self.pick_type)

        self.list_widget.setFixedWidth(200)
        hbox = QHBoxLayout()
        hbox.addWidget(self.list_widget)
        hbox.addWidget(self.table_view)
        self.setLayout(hbox)

    def set_data(self, data):
        self.game_data = data
        self.table_model = TableModel(self, self.game_data)
        self.populate_list()
        self.table_view.setModel(self.table_model)

    def populate_list(self):
        self.list_widget.clear()
        for dbtype in self.game_data.resources:
            resource = self.game_data.resource(dbtype)
            try:
                typeinfo = dbtypes.get_typeinfo(resource)
            except KeyError:
                name = '(no schema)'
                item = QListWidgetItem('{}: {}'.format(dbtype, name))
                # Setting only this flag will prevent selection:
                item.setFlags(Qt.ItemIsEnabled)
                self.list_widget.addItem(item)
                continue
            # Handle resources like TextureMap that make no sense to put
            # in a table preview:
            if typeinfo[1] is None:
                item = QListWidgetItem('{}: ({})'.format(dbtype, typeinfo[0]))
                item.setFlags(Qt.ItemIsEnabled)
            else:
                item = QListWidgetItem('{}: {}'.format(dbtype, typeinfo[0]))
                item.setData(Qt.UserRole, dbtype)
            self.list_widget.addItem(item)

    def pick_type(self, item):
        dbtype = item.data(Qt.UserRole)
        self.table_model.set_type(dbtype)
        self.table_model.force_update()
        self.table_view.scrollToTop()
        self.coords_available.emit(self.table_model.get_coord_list())

        #self.table_view.setWordWrap(True)
        #self.table_view.setTextElideMode(Qt.ElideMiddle)
        #self.table_view.resizeRowsToContents()
