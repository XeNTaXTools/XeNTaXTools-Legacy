"""

Preview widgets for resource types found in the PakFiles.

More complex preview widgets get their own modules - at present, sound
and model.

"""

from PyQt5.QtCore import QSize
from PyQt5.QtGui import QFont, QFontMetrics
from PyQt5.QtWidgets import QFileDialog, QLabel, QPlainTextEdit, QPushButton
from PyQt5.QtWidgets import QGroupBox, QHBoxLayout, QScrollBar, QStackedWidget
from PyQt5.QtWidgets import QLineEdit, QVBoxLayout, QWidget

import common
import luadec
from meshpreview import MeshPreview
from soundpreview import SoundPreview


class ImagePreview(QGroupBox):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setTitle('Image Preview')
        self.label = QLabel(self)
        self.max_size = QSize(512, 512)
        self.label.setFixedSize(self.max_size)
        vbox = QVBoxLayout()
        vbox.addWidget(self.label)
        self.setLayout(vbox)

    def set_pixmap(self, pixmap, name):
        too_wide = pixmap.width() > self.max_size.width()
        too_high = pixmap.height() > self.max_size.height()
        if too_wide or too_high:
            self.label.setPixmap(pixmap.scaled(self.max_size))
        else:
            self.label.setPixmap(pixmap)
        w, h = pixmap.width(), pixmap.height()
        self.setTitle('Image Preview: {} ({}x{})'.format(name, w, h))


class TextPreview(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.export_button = QPushButton('Export', self)
        self.line_edit = QLineEdit(self)
        self.line_edit.setFixedWidth(200)
        self.find_button = QPushButton('Find', self)
        self.find_button.setEnabled(False)
        self.export_button.setEnabled(False)
        self.text_edit = QPlainTextEdit(self)
        f = QFont()
        f.setFamily('Courier')
        f.setStyleHint(QFont.Monospace)
        f.setFixedPitch(True)
        f.setPointSize(10)
        self.text_edit.setFont(f)
        tabstop = 4
        metrics = QFontMetrics(f)
        self.text_edit.setTabStopWidth(tabstop * metrics.width(' '))
        self.text_edit.setReadOnly(True)

        self.export_button.clicked.connect(self.handle_export)
        self.line_edit.textChanged.connect(self.handle_find_entry)
        self.line_edit.returnPressed.connect(self.handle_find)
        self.find_button.clicked.connect(self.handle_find)

        hbox = QHBoxLayout()
        hbox.addWidget(self.export_button)
        hbox.addWidget(self.line_edit)
        hbox.addWidget(self.find_button)
        hbox.addStretch(1)
        vbox = QVBoxLayout()
        vbox.addLayout(hbox)
        vbox.addWidget(self.text_edit)
        self.setLayout(vbox)

    def set_text(self, text):
        self.text_edit.clear()
        self.text_edit.appendPlainText(text)
        self.export_button.setEnabled(True)

    def scroll_to_top(self):
        scrollbar = self.text_edit.verticalScrollBar()
        scrollbar.triggerAction(QScrollBar.SliderToMinimum)

    def handle_export(self):
        name, mask = QFileDialog.getSaveFileName(self, 'Save as...',
                                                 common.EXPORT_PATH,
                                                 '*.txt')
        if name:
            with open(name, 'w') as outf:
                outf.write(self.text_edit.toPlainText())

    def handle_find_entry(self, text):
        new_state = self.export_button.isEnabled() and text != ''
        self.find_button.setEnabled(new_state)

    def handle_find(self):
        self.text_edit.find(self.line_edit.text())


class HexPreview(TextPreview):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedWidth(640)

    def set_data(self, data):
        self.text_edit.clear()
        text = ''
        hexout = ''
        asciiout = ''
        spacer = ''
        fmt = '{:08X}  {}{} {}\n'
        for i, ch in enumerate(data):
            hexout += '{:02X} '.format(ch)
            if ch < 32 or ch > 126:
                asciiout += '.'
            else:
                asciiout += chr(ch)
            if i % 16 == 15:
                text += fmt.format(i - 15, hexout, spacer, asciiout)
                hexout = ''
                asciiout = ''
        if asciiout:
            spacer = ' ' * 3 * (16 - len(asciiout))
            text += fmt.format(i - len(asciiout) + 1, hexout, spacer, asciiout)
        self.text_edit.appendPlainText(text)


class LuaPreview(TextPreview):
    def __init__(self, parent=None):
        super().__init__(parent)

    def set_data(self, data):
        self.text_edit.clear()
        text = luadec.disassemble(data)
        self.text_edit.appendPlainText(text)


class StackedWidget(QStackedWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.text_preview = TextPreview(self)
        self.hex_preview = HexPreview(self)
        self.image_preview = ImagePreview(self)
        self.mesh_preview = MeshPreview(self)
        self.sound_preview = SoundPreview(self)
        self.lua_preview = LuaPreview(self)
        self.addWidget(self.text_preview)
        self.addWidget(self.hex_preview)
        self.addWidget(self.image_preview)
        self.addWidget(self.mesh_preview)
        self.addWidget(self.sound_preview)
        self.addWidget(self.lua_preview)

    def preview_text(self, data):
        self.text_preview.set_text(data.decode('latin-1'))
        self.setCurrentWidget(self.text_preview)
        self.text_preview.scroll_to_top()

    def preview_data(self, data):
        self.hex_preview.set_data(data)
        self.setCurrentWidget(self.hex_preview)
        self.hex_preview.scroll_to_top()

    def preview_pixmap(self, pixmap, name):
        self.image_preview.set_pixmap(pixmap, name)
        self.setCurrentWidget(self.image_preview)

    def preview_mesh(self, name, data, pakfiles):
        self.mesh_preview.load_model(name, data, pakfiles)
        self.setCurrentWidget(self.mesh_preview)

    def preview_sound(self, data):
        self.sound_preview.set_source(data)
        self.setCurrentWidget(self.sound_preview)

    def preview_lua(self, data):
        self.lua_preview.set_data(data)
        self.setCurrentWidget(self.lua_preview)
        self.lua_preview.scroll_to_top()
