"""

.DES file parser.  This format is also used for .MSH.

Values can be fetched from the tree by chaining section calls:

# Using d = DesFile(raw_data):
name = d.section('Material').section('M1').section('Diffuse_Map').value('Name')

but it's tidier to specify a path:

name = d.value('Material/M1/Diffuse_Map/Name')

"""

import collections
import re

from PyQt5.QtGui import QVector2D, QVector3D, QVector4D


#_section_name_pattern = r'\[([A-Za-z_][\w]*)]'
# It turns out we can have section names like [0]
_section_name_pattern = r'\[([\w]*)]'
_section_name_program = re.compile(_section_name_pattern)
_valid_name_pattern = r'[A-Za-z_][\w]*'
_valid_name_pattern_program = re.compile(_valid_name_pattern)


class DESParseError(Exception):
    def __init__(self, msg):
        self.msg = msg


def preprocess_line(line):
    # Strip comment:
    try:
        index = line.index('//')
        line = line[:index]
    except ValueError:
        pass
    return line.strip()


def is_valid_name(name):
    return _valid_name_pattern_program.fullmatch(name) is not None


class Item:
    def __init__(self, line):
        try:
            sep = line.index('=')
        except ValueError:
            raise DESParseError('bad item line {}'.format(line))
        self.key = line[:sep].strip()
        if not is_valid_name(self.key):
            raise DESParseError('bad key {}'.format(self.key))
        self.value = line[sep + 1:].strip()


def read_section_name(line):
    result = _section_name_program.findall(line)
    if len(result) != 1:
        raise DESParseError('section name result {}'.format(result))
    return result[0]


def read_section_content(lines):
    line = lines.popleft()
    if line != '{':
        raise DESParseError('missing section {')
    items = []
    while 1:
        line = lines.popleft()
        if line == '}':
            break
        elif line[0] == '[':
            sub_name = read_section_name(line)
            sub_content = read_section_content(lines)
            items.append(Section(sub_name, sub_content))
        else:
            try:
                items.append(Item(line))
            except DESParseError:
                if 'Diffuse' in line:
                    # Malformed data in the original game in the alpha
                    # section in landscape_island_textures.msh
                    pass
                else:
                    raise
    return items


def format_value(value, valuetype):
    if valuetype is None:
        return value
    elif valuetype == 'vector':
        parts = value.split(',')
        if len(parts) < 2 or len(parts) > 4:
            raise DESParseError('bad vector value {}'.format(value))
        parts = [float(part.strip()) for part in parts]
        if len(parts) == 2:
            return QVector2D(parts[0], parts[1])
        elif len(parts) == 3:
            return QVector3D(parts[0], parts[1], parts[2])
        else:
            return QVector4D(parts[0], parts[1], parts[2], parts[3])
    else:
        raise DESParseError('unhandled value type: {}'.format(valuetype))


class Section:
    def __init__(self, name, content):
        self.name, self.content = name, content

    @classmethod
    def from_lines(cls, lines):
        line = lines.popleft()
        name = read_section_name(line)
        content = read_section_content(lines)
        return cls(name, content)

    def section(self, name):
        for elem in self.content:
            try:
                if elem.name == name:
                    return elem
            except AttributeError:
                pass  # it's an Item
        return None

    def value(self, name, valuetype=None):
        for elem in self.content:
            try:
                if elem.key == name:
                    return format_value(elem.value, valuetype)
            except AttributeError:
                pass  # it's a Section
        return None


class DESFile:
    def __init__(self, data):
        lines = collections.deque()
        for raw_line in data.decode('latin-1').split('\n'):
            line = preprocess_line(raw_line)
            if line:
                lines.append(line)
        self.sections = []
        while lines:
            self.sections.append(Section.from_lines(lines))

    def section(self, name):
        for section in self.sections:
            if section.name == name:
                return section
        return None

    def value(self, path):
        parts = path.split('/')
        section = self.section(parts[0])
        for part in parts[1:-1]:
            section = section.section(part)
        result = section.value(parts[-1])
        return result


def dump_section(section, depth=0):
    spacer = '    ' * depth
    print(spacer, 'Section:', section.name)
    for item in section.content:
        if isinstance(item, Section):
            dump_section(item, depth+1)
        else:
            print(spacer, item.key, '=', item.value)


def test():
    with open('landscape_island_textures.msh', 'rb') as inf:
        raw_data = inf.read()
    d = DESFile(raw_data)
    print(d.value('Material/M1/Map_Diffuse/Name'))


if __name__ == '__main__':
    test()
