"""

Bone reference files, using .DES format.

The I = values in this have a maximum equal to the maximum value of the
uint32 in the vertex fields of MeshBuffers.

"""

