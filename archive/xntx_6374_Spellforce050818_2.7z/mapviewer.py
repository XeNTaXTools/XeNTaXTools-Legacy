"""

2D and 3D visualization of a map.

Note from the editor: maximum heightmap value is 100m

More work needed:

a translate function for game to scene (y = dimension - y - 1)

texture mapping isn't quite correct yet

zoom should ignore the item highlights, so that they're clickable
individually

"""

import logging

from PyQt5.QtCore import Qt, QPoint, pyqtSignal
from PyQt5.QtGui import QImage, QPainter, QPixmap, qRgba
from PyQt5.QtWidgets import QFileDialog, QStatusBar, QStyle, QToolBar
from PyQt5.QtWidgets import QGraphicsView, QGraphicsScene, QGraphicsPixmapItem
from PyQt5.QtWidgets import QHBoxLayout, QStackedWidget, QVBoxLayout, QWidget
from PyQt5.QtWidgets import QPushButton

import common
from dbtypes import DBType
from gamedataview import GameData, GameDataView
import msb
from terrain import TerrainView
import utils

logger = logging.getLogger(__name__)


class TextureSet:
    """
    There are 118 base textures, from which 31 can be specified for a single
    map.  0 is the world/base ocean texture, so indices are 1..31.

    The textures seem to be listed in sf9/mesh/landscae_island_textures.msh,
    but there aren't actually enough there, only 100.

    Documentation for the editor mentions a blocking flag settable on each
    texture.

    From documentation for auto-texture scripts: TextureID above 1..31 stands
    for 'mix texture', which is 2-3 textures mixed into one.  It's not clear
    how 8 bits can specify 3 textures from a set of 31, especially if one bit
    is given over to specifying blocking.  Interesting.

    Greyfell set0:

    57, 115, 108, 93, 101, 5, 110, 102, 54, 31, 32, 12, 69, 18, 83, 33, 17,
    87, 75, 16, 24, 59, 111, 72, 6, 22, 9, 77, 29, 74, 56

    >> 3:

    [1, 3, 3, 2, 3, 0, 3, 3, 1, 0, 1, 0, 2, 0, 2, 1, 0, 2, 2, 0, 0, 1, 3, 2,
    0, 0, 0, 2, 0, 2, 1]

    However - look at this: this is sorted(set(Greyfell terrain map)):

    0, 1, 2, 10, 11, 12, 13, 14, 15, 18, 19, 20, 24, 26, 32, 33,
    224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235,
    236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247,
    248, 249, 250, 251, 252, 253, 254

    (224 == 0b11100000)

    So this could be where the blocking flag, for example, is specified,
    rather than in TextureSet.

    """
    def __init__(self, data):
        self.world = data[0]
        self.set0 = [n for n in data[1:32]]
        self.set1 = [n for n in data[32:]]
        assert all(self.set1[i] == self.set0[i] + 119
                   or self.set0[i] == self.set1[i] == 0
                   for i in range(len(self.set0)))


def load_landscape_textures(pakfiles):
    raw_data = pakfiles[8].read_by_name('mesh\\landscape_island_textures.msb')
    mesh_buffer = msb.MeshBuffer(raw_data)
    pixmaps = []
    for mesh in mesh_buffer.meshes:
        name = mesh.diffuse_material.name + '_l2.tga'
        name = 'texture\\terrain\\' + name
        data = pakfiles[0].read_by_name(name)
        pm = utils.raw_tga_to_pixmap(data)
        pixmaps.append(pm)
        if len(pixmaps) == 120:
            break
    return pixmaps


def make_textured(dimension, texture_map, texture_set, pakfiles):
    textures = load_landscape_textures(pakfiles)
    image = QImage(dimension * 4, dimension * 4, QImage.Format_ARGB32)
    image.fill(Qt.black)
    painter = QPainter(image)
    for y in range(dimension):
        for x in range(dimension):
            index = texture_map[dimension * y + x] & 31
            if index == 0:
                continue  # skip world/base
            try:
                index2 = texture_set.set0[index]
            except IndexError:
                # TODO 31 in Stoneblade Mountain, that shouldn't
                # be out of range, so this is a promising bug for
                # understanding TextureSet
                fmt = 'bad textureset index {}, substituting base'
                logger.info(fmt.format(index))
                index2 = 1
            pm = textures[index2]
            painter.drawPixmap(x * 4, (dimension - y - 1) * 4, pm)
    painter.end()
    return image


class GraphicsScene(QGraphicsScene):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setBackgroundBrush(Qt.black)
        self.landscape = None
        self.background_item = None
        self.textured = None
        self.coords = []

    def make_landscape(self, texture_map, texture_set, pakfiles):
        self.clear_coords()
        self.clear()

        if self.landscape is not None:
            self.removeItem(self.landscape)
        dimension = int.from_bytes(texture_map[0:2], 'little')
        image = QImage(dimension, dimension, QImage.Format_ARGB32)
        for y in range(dimension):
            for x in range(dimension):
                val = texture_map[3 + y * dimension + x]
                val2 = val & 0x2f
                val3 = val2 * 2
                image.setPixel(x, dimension - y - 1, qRgba(val3, val3, val3, 255))
        self.background_item = QGraphicsPixmapItem(QPixmap.fromImage(image))
        self.addItem(self.background_item)
        self.setSceneRect(0, 0, dimension - 1, dimension - 1)

        self.textured = make_textured(dimension, texture_map, texture_set, pakfiles)

    def clear_coords(self):
        for coord in self.coords:
            self.removeItem(coord)
        self.coords = []

    def add_coord(self, x, y):
        image = QImage(5, 5, QImage.Format_ARGB32)
        image.fill(Qt.yellow)
        item = QGraphicsPixmapItem(QPixmap.fromImage(image))
        maxh = self.background_item.pixmap().height() - 1
        item.setOffset(x - 2, maxh - (y - 2))
        item.setZValue(100)
        self.coords.append(item)
        self.addItem(item)


class GraphicsView(QGraphicsView):
    mouse_moved = pyqtSignal(QPoint)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMouseTracking(True)

    def mouseMoveEvent(self, event):
        scene_pos = self.mapToScene(event.pos()).toPoint()
        self.mouse_moved.emit(scene_pos)

    def wheelEvent(self, event):
        d = event.angleDelta()
        if d.y() > 0:
            self.scale(1.1, 1.1)
        elif d.y() < 0:
            self.scale(0.9, 0.9)


class MapViewer(QWidget):
    def __init__(self, parent, pakfiles, game_data):
        super().__init__(parent)

        self.pakfiles = pakfiles
        self.game_data = game_data
        self.map_file = None

        self.toolbar = QToolBar(self)
        self.view = GraphicsView(self)
        self.terrain_view = TerrainView(self)
        self.scene = GraphicsScene(self)
        self.view.setScene(self.scene)
        self.status_bar = QStatusBar(self)
        self.tables = GameDataView(self, None)
        open_icon = self.style().standardIcon(QStyle.SP_DialogOpenButton)
        self.toolbar.addAction(open_icon, 'Open map', self.open_map)
        self.button2d3d = QPushButton('3D', self)
        self.button2d3d.setEnabled(False)
        self.toolbar.addWidget(self.button2d3d)
        self.stacked_widget = QStackedWidget(self)

        self.view.mouse_moved.connect(self.handle_view_mouse_moved)
        self.tables.coords_available.connect(self.create_item_overlay)
        self.button2d3d.clicked.connect(self.handle_button2d3d)

        vbox = QVBoxLayout()
        vbox.addWidget(self.toolbar)
        self.stacked_widget.addWidget(self.view)
        self.stacked_widget.addWidget(self.terrain_view)
        vbox.addWidget(self.stacked_widget)
        vbox.addWidget(self.status_bar)
        hbox = QHBoxLayout()
        hbox.addLayout(vbox)
        hbox.addWidget(self.tables)
        self.setLayout(hbox)

    def handle_button2d3d(self):
        if self.button2d3d.text() == '3D':
            self.button2d3d.setText('2D')
            self.stacked_widget.setCurrentWidget(self.terrain_view)
        else:
            self.button2d3d.setText('3D')
            self.stacked_widget.setCurrentWidget(self.view)

    def create_item_overlay(self, coords):
        if coords:
            self.scene.clear_coords()
            for x, y in coords:
                self.scene.add_coord(x, y)

    def open_map(self):
        name, filter = QFileDialog.getOpenFileName(self, 'Open map file',
                                                   common.GAME_PATH + 'map/',
                                                   'Map files (*.map)')
        if not name:
            return
        self.map_file = GameData(name)
        self.map_file.set_string_provider(self.game_data.string_provider)
        self.tables.set_data(self.map_file)
        texture_map = self.map_file.resource(DBType.TEXTURE_MAP).data
        texture_set = TextureSet(self.map_file.resource(DBType.TEXTURE_SET).data)
        self.scene.make_landscape(texture_map, texture_set, self.pakfiles)
        self.button2d3d.setEnabled(True)
        height_map = self.map_file.resources[DBType.HEIGHT_MAP]
        self.terrain_view.set_from_heightmap_arrays(height_map)
        self.terrain_view.set_texture(self.scene.textured)

    def handle_view_mouse_moved(self, pos):
        self.status_bar.showMessage('X: {}, Y: {}'.format(pos.x(), pos.y()))
