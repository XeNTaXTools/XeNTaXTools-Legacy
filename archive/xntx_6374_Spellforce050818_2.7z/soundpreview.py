"""

Bare bones sound player.

To do:
crash on changing source - what the hell is wrong with QMediaPlayer?
it seems even the Qt guys themselves advise not to use it under Windows...

"""

import logging

from PyQt5.QtCore import Qt, QBuffer, QByteArray, QTime
from PyQt5.QtMultimedia import QAudio, QMediaContent, QMediaPlayer
from PyQt5.QtWidgets import QLabel, QPushButton, QSlider, QStyle
from PyQt5.QtWidgets import QGroupBox, QHBoxLayout, QVBoxLayout
from PyQt5.QtWidgets import QMessageBox


logger = logging.getLogger(__name__)

DEFAULT_VOLUME = 60


def milliseconds_to_time_text(ms):
    """Convert milliseconds duration to minutes:seconds text."""
    t0 = QTime(0, 0, 0, 0)
    t = t0.addMSecs(ms)
    return '{}:{:02}'.format(t.minute(), t.second())


def error_dialog(parent, text):
    """Display a blocking error dialog."""
    mb = QMessageBox(parent)
    mb.setWindowTitle('Error')
    mb.setText(text)
    mb.exec()


ERROR_MAP = {
    QMediaPlayer.ResourceError:
        "Media resource couldn't be resolved.",
    QMediaPlayer.FormatError:
        "Media resource format not fully supported.  Playback may still be possible.",
    QMediaPlayer.NetworkError:
        "A network error occurred.",
    QMediaPlayer.AccessDeniedError:
        "There are not the appropriate permissions to play the media resource.",
    QMediaPlayer.ServiceMissingError:
        "A valid playback service was not found."
}


class SoundPreview(QGroupBox):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setTitle('Sound Player')

        # Create members:
        self.media_player = QMediaPlayer(self, QMediaPlayer.StreamPlayback)
        self.media_player.setVolume(DEFAULT_VOLUME)
        self.media_player.setAudioRole(QAudio.MusicRole)
        self.source = None
        self.ba = None
        self.buf = QBuffer(self)
        icon = self.style().standardIcon
        self.play_icon = icon(QStyle.SP_MediaPlay)
        self.pause_icon = icon(QStyle.SP_MediaPause)
        self.stop_icon = icon(QStyle.SP_MediaStop)
        self.volume_icon = icon(QStyle.SP_MediaVolume)
        self.muted_icon = icon(QStyle.SP_MediaVolumeMuted)
        self.play_button = QPushButton(self)
        self.play_button.setIcon(self.play_icon)
        self.play_button.setEnabled(False)
        self.stop_button = QPushButton(self)
        self.stop_button.setIcon(self.stop_icon)
        self.stop_button.setEnabled(False)
        self.mute_button = QPushButton(self)
        self.mute_button.setIcon(self.volume_icon)
        self.position_label = QLabel('-:--', self)
        self.position_slider = QSlider(self)
        self.position_slider.setOrientation(Qt.Horizontal)
        self.volume_slider = QSlider(self)
        self.volume_slider.setOrientation(Qt.Horizontal)
        self.volume_slider.setRange(0, 100)
        self.volume_slider.setValue(DEFAULT_VOLUME)

        # Connections:
        self.do_connections()

        # Layout:
        self.setFixedSize(300, 100)
        position_hbox = QHBoxLayout()
        position_hbox.addWidget(self.position_label)
        position_hbox.addWidget(self.position_slider)
        lower_hbox = QHBoxLayout()
        lower_hbox.addWidget(self.play_button)
        lower_hbox.addWidget(self.stop_button)
        lower_hbox.addWidget(self.mute_button)
        lower_hbox.addWidget(self.volume_slider)
        vbox = QVBoxLayout()
        vbox.addLayout(position_hbox)
        vbox.addLayout(lower_hbox)
        self.setLayout(vbox)

    def do_connections(self):
        self.media_player.mediaStatusChanged.connect(self.handle_status_changed)
        self.media_player.error.connect(self.handle_error)
        self.media_player.stateChanged.connect(self.handle_state_changed)
        self.media_player.durationChanged.connect(self.set_new_duration)
        self.media_player.positionChanged.connect(self.set_new_position)
        self.play_button.clicked.connect(self.handle_play_button)
        self.stop_button.clicked.connect(self.handle_stop_button)
        self.mute_button.clicked.connect(self.handle_mute_button)
        self.volume_slider.sliderMoved.connect(self.handle_volume_change)

    def disconnect_all(self):
        self.media_player.mediaStatusChanged.disconnect()
        self.media_player.error.disconnect()
        self.media_player.stateChanged.disconnect()
        self.media_player.durationChanged.disconnect()
        self.media_player.positionChanged.disconnect()

    def _set_source(self, data):
        """Set a new media source.  Assumes it is safe to do so."""
        logger.info('setting new source')
        self.buf.close()
        logger.info('buffer closing...')
        while self.buf.isOpen():
            pass
        logger.info('buffer closed')
        self.ba = QByteArray()
        self.source = data
        self.ba = QByteArray(self.source)
        logger.info('setting new buffer')
        self.buf.setBuffer(self.ba)
        if not self.buf.open(QBuffer.ReadOnly):
            logger.error('Failed to open QBuffer on QByteArray')
            return
        logger.info('setting new media')
        logger.info('mediastatus: {}'.format(self.media_player.mediaStatus()))
        logger.info('state: {}'.format(self.media_player.state()))
        logger.info('attempting final halt:')
        self.media_player.setMedia(QMediaContent())
        logger.info('and attempting new set')
        self.media_player.setMedia(QMediaContent(), self.buf)
        logger.info('new media set')

    def set_source(self, data):
        """Set a new media source, handling unloading of previous sources."""
        import time
        if self.source is None:
            # First source.  Proceed.
            logger.info('first source')
            self._set_source(data)
        else:
            logger.info('state is {}; stopping'.format(self.media_player.state()))
            self.disconnect_all()
            self.media_player.stop()
            while self.media_player.state() != QMediaPlayer.StoppedState:
                time.sleep(0.1)
            self._set_source(data)
            self.do_connections()

    def handle_error(self, error):
        error_dialog(self, ERROR_MAP[error])

    def handle_status_changed(self, status):
        if status == QMediaPlayer.UnknownMediaStatus:
            error_dialog(self, 'Unknown media status.')
        elif status == QMediaPlayer.NoMedia:
            pass
        elif status == QMediaPlayer.LoadingMedia:
            self.setTitle('Sound Player - loading...')
            self.play_button.setEnabled(False)
            self.stop_button.setEnabled(False)
        elif status == QMediaPlayer.LoadedMedia:
            self.setTitle('Sound Player')
            self.play_button.setEnabled(True)
            self.stop_button.setEnabled(False)
        elif status == QMediaPlayer.StalledMedia:
            self.setTitle('Sound Player (stalled)')
        elif status == QMediaPlayer.BufferingMedia:
            self.setTitle('Sound Player (buffering...)')
        elif status == QMediaPlayer.BufferedMedia:
            self.setTitle('Sound Player')
        elif status == QMediaPlayer.EndOfMedia:
            pass
        elif status == QMediaPlayer.InvalidMedia:
            error_dialog(self, 'Invalid media.  Playback cannot proceed.')

    def handle_state_changed(self, state):
        if state == QMediaPlayer.StoppedState:
            self.play_button.setIcon(self.play_icon)
            self.stop_button.setEnabled(False)
        elif state == QMediaPlayer.PlayingState:
            self.play_button.setIcon(self.pause_icon)
            self.stop_button.setEnabled(True)
        elif state == QMediaPlayer.PausedState:
            self.play_button.setIcon(self.play_icon)
            self.stop_button.setEnabled(True)

    def handle_play_button(self):
        if self.media_player.state() == QMediaPlayer.PlayingState:
            self.media_player.pause()
        else:
            self.media_player.play()

    def handle_stop_button(self):
        self.media_player.stop()

    def handle_mute_button(self):
        is_muted = self.media_player.isMuted()
        if is_muted:
            self.mute_button.setIcon(self.muted_icon)
        else:
            self.mute_button.setIcon(self.volume_icon)
        self.media_player.setMuted(not is_muted)

    def handle_volume_change(self, val):
        self.media_player.setVolume(val)

    def set_new_duration(self, val):
        text = milliseconds_to_time_text(val)
        self.position_label.setText('0:00 / {}'.format(text))

    def set_new_position(self, val):
        dur = self.media_player.duration()
        if dur == 0:
            perc = 0
        else:
            perc = int(100 * val / dur)
        self.position_slider.setValue(perc)
        pos_text = milliseconds_to_time_text(val)
        total_text = milliseconds_to_time_text(dur)
        self.position_label.setText('{} / {}'.format(pos_text, total_text))
