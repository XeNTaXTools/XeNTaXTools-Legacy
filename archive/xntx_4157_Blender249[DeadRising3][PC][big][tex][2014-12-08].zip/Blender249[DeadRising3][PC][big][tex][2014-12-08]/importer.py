import newGameLib
reload(newGameLib)
from newGameLib import *
import Blender



modelUserIDList=[]	
#modelUserIDList=[0,1,2,4,3]
boneMapFlag=True
boneOffset=3	
	

class SubMesh:
	def __init__(self):
		self.name=None
		self.vertCount=None
		self.IDStart=0
		self.IDCount=0
		self.stride=None	
		self.matHash=None
		self.boneMapOffset=None
class Stream:
	def __init__(self):
		self.IDStart=0
		self.IDCount=0			
		self.stride=None
		self.vertPosList=[]
		self.vertUVList=[]
		self.skinWeightList=[]
		self.skinIndiceList=[]
		
class VertDesc:	
	def __init__(self):
		self.name=None			
		self.itemCount=None
		self.itemList=[]
		
class MatDesc:
	def __init__(self):		
		self.itemCount=None
		self.submeshId=None
		self.texCount=None
		self.texTableOffset=None
		self.texList=[]
		

		
def bigParser(offset,n,filename,g):
	g.logOpen()
	header = g.i(6)
	g.seek(offset+header[5],0)
	names = []
	for m in range(header[3]):names.append(g.find('\x00'))			
	g.seek(offset + header[4],0)
	
	subMeshList=[]
	streamList=[]
	vertDescList=[]
	matDescList=[]
	
		
	skeleton=Skeleton()
	skeleton.BONESPACE=True	
	#skeleton.ARMATURESPACE=True
	skeleton.NICE=True
	
	for m in range(header[3]):
		seek = g.i(1)[0]
		back = g.tell()
		g.seek(offset+seek)
		name = g.find('\x00')
		g.seek(back)
		blockID=g.i(1)[0]
		blockHeader = g.i(5)
		back = g.tell()
		g.seek(offset+blockHeader[2])
			
		if 'MatArray'	in name:
			count=blockHeader[0]/80
			for i in range(count):
				matDesc=MatDesc()
				u=g.i(20)
				matDesc.submeshId=u[0]-1
				matDesc.texCount=u[3]
				matDesc.texTableOffset=u[4]
				matDescList.append(matDesc)
				
		if 'MatTextureInfoArray'	in name:
			count=blockHeader[0]/16
			startOff=g.tell()
			for matDesc in matDescList:
				g.seek(startOff+matDesc.texTableOffset)
				for i in range(matDesc.texCount):
					matDesc.texList.append(g.i(4))
		
		if '_ANIMLIB_SKELETON_'	in name:
			count=blockHeader[0]/4
			w=g.i(2)
			for i in range(w[1]):
				bone=Bone()
				bone.hash=g.i(1)
				bone.type=g.H(1)[0]
				bone.nameTableOffset=g.H(1)[0]
				bone.rotMatrix=QuatMatrix(g.f(4)).resize4x4()
				bone.posMatrix=VectorMatrix(g.f(3))
				skeleton.boneList.append(bone)
			g.B(8)
			for i in range(w[1]):
				parentID=g.B(1)[0]
				if parentID!=255:
					skeleton.boneList[i].parentID=parentID
				else:	
					skeleton.boneList[i].parentID=-1
			startTable=g.tell()
			if boneMapFlag==True:
				for i in range(w[1]):
					g.seek(startTable+skeleton.boneList[i].nameTableOffset)
					if i==0:
						skeleton.boneList[i].name='ROOT'
					else:	
						skeleton.boneList[i].name=g.find('\x00')
				
				
		
		if ' VDHeader' in name:
			g.i(4)
			
		if 'SceneDescription'	in name:
			count=blockHeader[0]/36
			for i in range(count):g.word(36)
				
		if ' D3DVertexDesc 0'	in name:#first skin layer 
			count=blockHeader[0]/28
			vertDesc=VertDesc()
			vertDesc.itemCount=count
			vertDesc.name=name.split()[0]+'-'+str(0)
			for i in range(count):
				vertDesc.itemList.append(g.i(7))
			vertDescList.append(vertDesc)	
			
		if ' MaskRenderStrip'	in name:
			matCount=blockHeader[0]/36
			maskList=[]
			for i in range(matCount):
				maskList.append(g.i(9))
			
			
		if ' CommandBuffer'	in name:
			for i in range(len(maskList)):
				mask=maskList[i]
				subMeshName=name.split()[0]+'-'+str(i)
				submesh=SubMesh()
				submesh.name=subMeshName
				submesh.ID=len(subMeshList)
				g.i(1)
				countA=(mask[-1]-15)/4
				for i in range(countA):g.i(4)
				u0=g.i(4)+g.B(4)
				u1=g.i(5)
				u2=g.i(5)
				#print i,u1
				#print len(subMeshList),u0,u2[1],u1[2],u2[3]
				submesh.vertCount=u2[1]
				submesh.IDStart=u1[2]
				submesh.IDCount=u2[3]
				submesh.stride=u0[6]
				submesh.matHash=u0[2]
				submesh.boneMapOffset=mask[5]
				subMeshList.append(submesh)
				

		if 'SharedZPassCommandBuffer'	in name:
			count=blockHeader[0]/4
			list=str(g.i(count)).split('776')
			#for item in list:g.logWrite(item)
		if 'SharedZPassFirstCommandBuffer'	in name:
			count=blockHeader[0]/4
			list=str(g.i(count)).split('776')
			#for item in list:g.logWrite(item)
			
		if 'SharedOpaqueCommandBuffer'	in name:
			count=blockHeader[0]/4
			list=str(g.i(count)).split('776')
			#for item in list:g.logWrite(item)
			
		if 'SharedTransparentCommandBuffer'	in name:
			count=blockHeader[0]/4
			list=str(g.i(count)).split('776')
			#for item in list:g.logWrite(item)
			
		if ' desc2'	in name:
			count=blockHeader[0]/4
			g.i(8)
			g.f(7)
			g.i(count-8-7)
				
		if 'Combined_VBHeader'	in name:
			count=blockHeader[0]/24
			for i in range(count):
				g.i(6)
				
		if 'Combined_IBHeader'	in name:
			count=blockHeader[0]/1
			g.B(count)
			
			
			
		if 'TotalVBSize'	in name:
			count=blockHeader[0]/4
			g.i(count)
			
		if 'TotalIBSize'	in name:
			count=blockHeader[0]/4
			g.i(count)

		if 'MatParameterArray'	in name:
			count=blockHeader[0]/(20*61)
			for i in range(count):
				g.f(5*61)

		if 'MatSamplerInfoArray'	in name:
			count=blockHeader[0]/40
			for i in range(count):
				g.i(10)


		if 'TextureNames'	in name:
			count=blockHeader[0]/4
			texCount=g.H(1)[0]
			offsetList=g.H(texCount)
			start=g.tell()
			for i in range(texCount):
				g.seek(start+offsetList[i])
				g.find('\x00')
		
		if 'Indices' in name:
			indiceCount = blockHeader[0]/2
			indiceStreamList=g.H(indiceCount)
		if 'Vertices' in name:
			stream=Stream()
			#print name
			if '32' in name:stride=32
			if '36' in name:stride=36
			if '40' in name:stride=40
			if '44' in name:stride=44
			if '48' in name:stride=48
			if '52' in name:stride=52
			stream.stride=stride
			stream.offset=g.tell()
			streamList.append(stream)	
		g.seek(back) 
	
	g.tell()
	g.logClose()
	
	skeleton.draw()
	
	
	def goNext(ID,pnext):	
		for i,submesh in enumerate(subMeshList):
			s=indiceStreamList[submesh.IDStart:submesh.IDStart+submesh.IDCount]
			minID,maxID=min(s),max(s)
			if minID==pnext:
				if i not in usedIDList:
					usedIDList.append(i)
					#print i,minID,maxID,submesh.stride
					ID.append(i)
					next=maxID+1
					goNext(ID,next)	
					break	
					
			
	def sort():
		for i,submesh in enumerate(subMeshList):
			s=indiceStreamList[submesh.IDStart:submesh.IDStart+submesh.IDCount]
			minID,maxID=min(s),max(s)
			if minID==0:
				#print i,minID,maxID,submesh.stride
				usedIDList.append(i)
				ID=[]
				ID.append(i)
				next=maxID+1
				goNext(ID,next)	
				IDList.append(ID)
		
	IDList=[]
	usedIDList=[]
	
	listA=sort()
	
	meshList=[]
	
	newIDList=[]
	if len(modelUserIDList)>0:
		for id in modelUserIDList:
			newIDList.append(IDList[id])		
	else:
		newIDList=IDList
	for list in newIDList:
		#list=IDList[1]
		mesh=Mesh()
		mesh.TRIANGLE=True
		meshList.append(mesh)
		mesh.name=str(len(meshList)-1)+'-model'
		#print '=='*30
		matIDStart=0
		for id in list:
			submesh=subMeshList[id]
			#g.logWrite(submesh.name)
			#print id,submesh.name
			for stream in streamList:
				if stream.stride==submesh.stride:
					stream.IDCount=submesh.vertCount
					#print stream.stride,submesh.vertCount
					for vertDesc in vertDescList:
						if vertDesc.name==submesh.name:
							for item in vertDesc.itemList:
								if item[0]==0:vertPosStrideOffset=item[4]
								if item[0]==1:skinWeightStrideOffset=item[4]
								if item[0]==2:skinIndiceStrideOffset=item[4]
								if item[0]==5:
									if item[1]==0:#uv layer
										vertUVType=item[2]
										vertUVStrideOffset=item[4]
							break	
					for i in range(submesh.vertCount):
						g.seek(stream.offset+(stream.IDStart+i)*stream.stride+vertPosStrideOffset)
						mesh.vertPosList.append(g.f(3))
						g.seek(stream.offset+(stream.IDStart+i)*stream.stride+vertUVStrideOffset)
						if vertUVType==16:mesh.vertUVList.append(g.f(2))
						if vertUVType==37:mesh.vertUVList.append(g.short(2,'h',15))
						g.seek(stream.offset+(stream.IDStart+i)*stream.stride+skinWeightStrideOffset)
						mesh.skinWeightList.append(g.B(4))
						g.seek(stream.offset+(stream.IDStart+i)*stream.stride+skinIndiceStrideOffset)
						#mesh.skinIndiceList.append(g.B(4))
						
						id0=submesh.boneMapOffset+g.B(1)[0]#/3
						id1=submesh.boneMapOffset+g.B(1)[0]#/3
						id2=submesh.boneMapOffset+g.B(1)[0]#/3
						id3=submesh.boneMapOffset+g.B(1)[0]#/3
						
						mesh.skinIndiceList.append([id0,id1,id2,id3])
						
						
						
						
						#mesh.skinIDList.append(id)
						
						
					
					#mesh.vertPosList.extend(stream.vertPosList[stream.IDStart:stream.IDStart+stream.IDCount])
					#mesh.vertUVList.extend(stream.vertUVList[stream.IDStart:stream.IDStart+stream.IDCount])
					
					stream.IDStart+=stream.IDCount					
			mesh.indiceList.extend(indiceStreamList[submesh.IDStart:submesh.IDStart+submesh.IDCount])
			mat=Mat()
			for matDesc in matDescList:
				if matDesc.submeshId==id:
					matDesc=matDescList[id]
					#print matDesc.texList
					for texDesc in matDesc.texList:
						#print texDesc
						if texDesc[3]==0:
							if texDesc[2] in imageHashList:
								img=imageHashList[texDesc[2]]
								#print img
								if '_om' in img:
									if os.path.exists(g.dirname+os.sep+g.basename.split('.')[0]+os.sep+img+'.dds'):
										mat.alpha=g.dirname+os.sep+g.basename.split('.')[0]+os.sep+img+'.dds'
									img=img.replace('_om','_cm')
								mat.diffuse=g.dirname+os.sep+g.basename.split('.')[0]+os.sep+img+'.dds'
							else:
								'missing:',texDesc[2]
						if texDesc[3]==1:
							if texDesc[2] in imageHashList:
								img=imageHashList[texDesc[2]]
								if '_cm' in img:
									img=img.replace('_cm','_sm')
									mat.specular=g.dirname+os.sep+g.basename.split('.')[0]+os.sep+img+'.dds'
								mat.specular=g.dirname+os.sep+g.basename.split('.')[0]+os.sep+img+'.dds'
			mat.name=submesh.name
			mat.TRIANGLE=True
			mat.IDStart=matIDStart
			mat.IDCount=submesh.IDCount
			matIDStart+=submesh.IDCount
			mesh.matList.append(mat)
		skin=Skin()
		mesh.boneNameList=skeleton.boneNameList
		mesh.skinList.append(skin)	
		mesh.SPLIT=True	
		mesh.BINDSKELETON=skeleton.name
		try:mesh.draw()
		except:
			print 'WARNING mesh:',mesh.name
		#break
	print 'model count:',len(IDList)	
	
			
	
	"""for submesh in subMeshList:
		print submesh.ID,submesh.name,submesh.matHash,
		s=indiceStreamList[submesh.IDStart:submesh.IDStart+submesh.IDCount]
		minID,maxID=min(s),max(s)
		print	minID,maxID"""
	
	
def texParser(filename,g):
	g.logOpen()
	header = g.i(6)
	g.seek(header[5],0)
	names = []
	for m in range(header[3]):names.append(g.find('\x00'))			
	g.seek(header[4],0)
	
	
	for m in range(header[3]):
		seek = g.i(1)[0]
		back = g.tell()
		g.seek(seek)
		name = g.find('\x00')
		g.seek(back)
		blockID=g.i(1)[0]
		blockHeader = g.i(5)
		back = g.tell()
		g.seek(blockHeader[2])
		start=g.tell()
		header=g.i(8)
		for i in range(8):
			size,unk0,unk1,unk2=g.i(4)
			#print size,unk0,unk1,unk2
			img=imageLib.Image()
			imageHashList[blockID]=name
			#print blockID,name
			img.name=g.dirname+os.sep+g.basename.split(os.sep)[0]+os.sep+name+'.dds'
			if size==65536:img.format='DXT1';img.wys=128;img.szer=128;g.seek(start+header[-1]);img.data=g.read(size);img.draw()
			elif size==32768:img.format='DXT1';img.wys=256;img.szer=256;g.seek(start+header[-1]);img.data=g.read(size);img.draw()
			elif size==131072:img.format='DXT1';img.wys=512;img.szer=512;g.seek(start+header[-1]);img.data=g.read(size);img.draw()
			elif size==262144:img.format='DXT1';img.wys=512;img.szer=1024;g.seek(start+header[-1]);img.data=g.read(size);img.draw()
			elif size==1048576:img.format='DXT1';img.wys=1024;img.szer=2048;g.seek(start+header[-1]);img.data=g.read(size);img.draw()
			elif size==524288:img.format='DXT1';img.wys=1024;img.szer=1024;g.seek(start+header[-1]);img.data=g.read(size);img.draw()
			elif size==2097152:img.format='DXT1';img.wys=2048;img.szer=2048;g.seek(start+header[-1]);img.data=g.read(size);img.draw()
			elif size==4194304:img.format='DXT1';img.wys=2048;img.szer=2048;g.seek(start+header[-1]);img.data=g.read(size);img.draw()
			else:
				'unknow image size:',size
				
			break	
		g.seek(back) 
	
		
	
def Parser():	
	global imageHashList
	filename=input.filename
	print
	print filename
	print
	
	imageList=input.imageList
	ext=filename.split('.')[-1].lower()	
	
	imageHashList={}
	
	if ext=='big':
		texPath=filename.replace('.big','.tex')
		if os.path.exists(texPath):
			file=open(texPath,'rb')
			g=BinaryReader(file)
			texParser(texPath,g)
			file.close()
		
		file=open(filename,'rb')
		g=BinaryReader(file)
		bigParser(0,0,filename,g)
		file.close()
	
	if ext=='tex':
		file=open(filename,'rb')
		g=BinaryReader(file)
		texParser(filename,g)
		file.close()
	
 
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
	
Blender.Window.FileSelector(openFile,'import','big - skeleton mesh,tex - texture container') 