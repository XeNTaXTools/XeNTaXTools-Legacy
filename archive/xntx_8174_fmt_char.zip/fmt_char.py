#by Durik256 for xentax
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("miami vice(PSP)", ".char")
    noesis.setHandlerTypeCheck(handle, CheckType)
    noesis.setHandlerLoadModel(handle, LoadModel)
    return 1

def CheckType(data):
    return 1
    
def LoadModel(data, mdlList):
    bs = NoeBitStream(data)
    ctx = rapi.rpgCreateContext()
    
    name = searchString(bs)
    skipZero(bs)
    vert_count = bs.readInt()
    
    submesh = []
    for x in range(bs.readInt()):
        unk = [bs.readInt() for x in range(4)]
        submesh.append(unk[1])
        
    for vcount in submesh:
        vbuf = bs.readBytes(vcount*20)
        ibuf = autoTriangles(vcount)
            
        rapi.rpgBindPositionBufferOfs(vbuf, noesis.RPGEODATA_SHORT, 20, 14)
        rapi.rpgBindUV1BufferOfs(vbuf, noesis.RPGEODATA_SHORT, 20, 4)
        rapi.rpgBindNormalBufferOfs(vbuf, noesis.RPGEODATA_SHORT, 20, 8)
        rapi.rpgCommitTriangles(ibuf, noesis.RPGEODATA_USHORT, len(ibuf)//2, noesis.RPGEO_TRIANGLE_STRIP)
        
    mdl = rapi.rpgConstructModel()
    rapi.setPreviewOption("setAngOfs", "0 90 -90")
    mdlList.append(mdl)
    return 1
    
def autoTriangles(vcount):
    ibuf = b''
    for x in range(vcount):
        ibuf +=(x).to_bytes(2, 'little')
    return ibuf
    
def searchString(bs):
    bytes = []
    byte = None
    while byte != 0:
        byte = bs.readUByte()
        bytes.append(byte)
    return noeAsciiFromBytes(bytes)
    
def skipZero(bs):
    byte = 0
    while byte == 0:
        byte = bs.readUByte()
    bs.seek(-1,1)