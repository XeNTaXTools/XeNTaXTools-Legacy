using ArchiveX;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ARchive_neXt
{
    class acu
    {
        #region Methods
        #region expandDatafile Method v1.11.16.0
        /// <summary>
        /// Expand Assassin's Creed Unity datafiles.
        /// </summary>
        /// <param name="archivePath">Path to the forge file</param>
        /// <param name="tNode">TreeNode to populate</param>
        internal static void expandDatafile(String archivePath, TreeNode tNode)
        {
            #region Variables
            Archive_XLZO myLzo = new Archive_XLZO();
            Int32 notComp;
            Int64 offset;
            String fileName = "", strID = "", tempFile = "";
            String[] splitTag = { "," }, tagSplit;
            #endregion

            tagSplit = tNode.Tag.ToString().Split(splitTag, StringSplitOptions.None);
            offset = Convert.ToInt64(tagSplit[0]);

            #region Set up
            FileStream fstForgeReader = new FileStream(archivePath, FileMode.Open, FileAccess.Read, FileShare.Read);
            BinaryReader bnrForgeReader = new BinaryReader(fstForgeReader);
            #endregion

            #region Start De-compressing
            try
            {
                notComp = 1;
                bnrForgeReader.BaseStream.Position = offset;
                strID = String.Format("{0:X8}", bnrForgeReader.ReadInt64()).PadLeft(16, '0');

                if ((strID == "41544144454C4946") || (strID == "0000000000000004"))
                {
                }
                else
                {
                    bnrForgeReader.BaseStream.Position -= 8;
                }

                strID = String.Format("{0:X8}", bnrForgeReader.ReadInt64()).PadLeft(16, '0');

                while ((strID == "1004FA9957FBAA33") && (bnrForgeReader.BaseStream.Position < (Convert.ToInt64(tagSplit[0]) + Convert.ToInt64(tagSplit[2]))))
                {
                    #region Variables
                    Byte compAlgo;
                    Int16 blockCount, minSize, maxSize;
                    UInt16[] dCompSize, uCompSize;
                    #endregion

                    notComp = 0;
                    compAlgo = bnrForgeReader.ReadByte();
                    bnrForgeReader.BaseStream.Position += 2;
                    minSize = bnrForgeReader.ReadInt16();
                    maxSize = bnrForgeReader.ReadInt16();
                    blockCount = bnrForgeReader.ReadInt16();
                    bnrForgeReader.BaseStream.Position += 2;

                    dCompSize = new UInt16[blockCount];
                    uCompSize = new UInt16[blockCount];

                    for (int i = 0; i < blockCount; i++)
                    {
                        uCompSize[i] = bnrForgeReader.ReadUInt16();
                        dCompSize[i] = bnrForgeReader.ReadUInt16();
                    }

                    if (fileName == "")
                    {
                        fileName = tNode.Text;
                    }

                    foreach (Char isDisallowed in System.IO.Path.GetInvalidFileNameChars())
                    {
                        fileName = fileName.Replace(isDisallowed.ToString(), "");
                    }

                    tempFile = arxForm.tempDir + "\\" + tNode.Parent.Text + "\\" + fileName + ".acu";

                    if (!Directory.Exists(arxForm.tempDir + "\\" + tNode.Parent.Text))
                    {
                        Directory.CreateDirectory((arxForm.tempDir + "\\" + tNode.Parent.Text));
                    }

                    #region Set up
                    FileStream fstWriter = new FileStream(tempFile, FileMode.Append, FileAccess.Write, FileShare.None);
                    BinaryWriter bnrWriter = new BinaryWriter(fstWriter);
                    #endregion

                    #region Write de-compressed info
                    for (int i = 0; i < blockCount; i++)
                    {
                        #region Variables
                        Byte[] compSource, decompDest;
                        Int32 checksum;
                        #endregion

                        compSource = new Byte[dCompSize[i]];
                        decompDest = new Byte[uCompSize[i]];

                        checksum = bnrForgeReader.ReadInt32();
                        compSource = bnrForgeReader.ReadBytes(dCompSize[i]);

                        if (dCompSize[i] != uCompSize[i])
                        {
                            decompDest = myLzo.Decompress(compAlgo, compSource, uCompSize[i]);
                        }
                        else
                        {
                            decompDest = compSource;
                        }

                        bnrWriter.Write(decompDest);
                    }
                    #endregion

                    strID = String.Format("{0:X8}", bnrForgeReader.ReadInt64()).PadLeft(16, '0');

                    #region Clean up
                    bnrWriter.Flush();
                    bnrWriter.Close();
                    fstWriter.Close();
                    #endregion
                }

                if (notComp == 1)
                {
                    #region Variables
                    Byte[] readBytes;
                    #endregion

                    tempFile = arxForm.tempDir + "\\" + tNode.Parent.Text + "\\" + fileName + ".acu";

                    #region Set up
                    FileStream fstWriter = new FileStream(tempFile, FileMode.Create, FileAccess.Write, FileShare.None);
                    BinaryWriter bnrWriter = new BinaryWriter(fstWriter);
                    #endregion

                    readBytes = new Byte[Convert.ToInt32(tagSplit[2])];

                    #region Write Issues
                    bnrForgeReader.BaseStream.Position += 30;
                    readBytes = bnrForgeReader.ReadBytes(Convert.ToInt32(tagSplit[2]));
                    bnrWriter.Write(readBytes);
                    #endregion

                    #region Clean up
                    bnrWriter.Flush();
                    bnrWriter.Close();
                    fstWriter.Close();
                    #endregion

                    notComp = 0;
                }

                tNode.Tag = 0;
                tNode.Name = "acu";
                tNode.Nodes.RemoveAt(0);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error expanding DATAFILE\n\n" + ex.Message + "\n\n" + ex.StackTrace, "DATAFILE Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            #endregion

            #region Clean up
            bnrForgeReader.Close();
            fstForgeReader.Close();
            #endregion
        }
        #endregion
        #endregion
    }
}
