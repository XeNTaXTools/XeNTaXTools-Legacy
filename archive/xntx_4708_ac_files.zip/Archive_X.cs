﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace ArchiveX
{
    public class Archive_XLZO
    {
        [DllImport("lzo.dll")]
        private static extern int lzo1c_decompress(
            Byte[] src,
            UInt16 src_len,
            Byte[] dst,
            ref UInt16 dst_len,
            Byte[] wrkmem);

        [DllImport("lzo.dll")]
        private static extern int lzo1x_decompress(
            Byte[] src,
            UInt16 src_len,
            Byte[] dst,
            ref UInt16 dst_len,
            Byte[] wrkmem);

        [DllImport("lzo.dll")]
        private static extern int lzo2a_decompress(
            Byte[] src,
            UInt16 src_len,
            Byte[] dst,
            ref UInt16 dst_len,
            Byte[] wrkmem);

        private Byte[] workMem = new Byte[16384L * 4];

        public Byte[] Decompress(Int16 compAlgo, Byte[] src, UInt16 dstLen)
        {
            Byte[] dst = new Byte[dstLen];
            UInt16 outLen = dstLen;

            switch (compAlgo)
            {
                case 1:

                    lzo1x_decompress(src, Convert.ToUInt16(src.Length), dst, ref outLen, workMem);

                    break;

                case 2:

                    lzo2a_decompress(src, Convert.ToUInt16(src.Length), dst, ref outLen, workMem);

                    break;

                case 5:

                    lzo1c_decompress(src, Convert.ToUInt16(src.Length), dst, ref outLen, workMem);

                    break;
            }

            return dst;
        }
    }

    public sealed class Archive_XLZF
    {
        /// <summary>
        /// Hashtable, that can be allocated only once
        /// </summary>
        private readonly long[] HashTable = new long[HSIZE];
        private const uint HLOG = 14;
        private const uint HSIZE = (1 << 14);
        private const uint MAX_LIT = (1 << 5);
        private const uint MAX_OFF = (1 << 13);
        private const uint MAX_REF = ((1 << 8) + (1 << 3));

        /// <summary>
        /// Decompresses the data using LibLZF algorithm
        /// </summary>
        /// <param name="input">Reference to the data to decompress</param>
        /// <param name="inputLength">Lenght of the data to decompress</param>
        /// <param name="output">Reference to a buffer which will contain the decompressed data</param>
        /// <param name="outputLength">The size of the decompressed archive in the output buffer</param>
        /// <returns>Returns decompressed size</returns>
        public int Decompress(byte[] input, int inputLength, byte[] output, int outputLength)
        {
            uint iidx = 0;
            uint oidx = 0;

            do
            {
                uint ctrl = input[iidx++];

                if (ctrl < (1 << 5)) /* literal run */
                {
                    ctrl++;

                    if (oidx + ctrl > outputLength)
                    {
                        //SET_ERRNO (E2BIG);
                        return 0;
                    }

                    do
                    {
                        output[oidx++] = input[iidx++];
                    }
                    while ((--ctrl) != 0);
                }
                else /* back reference */
                {
                    uint len = ctrl >> 5;
                    int reference = (int)(oidx - ((ctrl & 0x1f) << 8) - 1);

                    if (len == 7)
                    {
                        len += input[iidx++];
                    }

                    reference -= input[iidx++];

                    if (oidx + len + 2 > outputLength)
                    {
                        //SET_ERRNO (E2BIG);
                        return 0;
                    }

                    if (reference < 0)
                    {
                        //SET_ERRNO (EINVAL);
                        return 0;
                    }

                    output[oidx++] = output[reference++];
                    output[oidx++] = output[reference++];

                    do
                    {
                        output[oidx++] = output[reference++];
                    }
                    while ((--len) != 0);
                }
            }
            while (iidx < inputLength);

            return (int)oidx;
        }
    }
}
