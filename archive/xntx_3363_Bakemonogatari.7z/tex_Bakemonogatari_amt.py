from inc_noesis import *
import noesis
import rapi

texList = []

def registerNoesisTypes():
	handle = noesis.register("AMT Textures", ".amt")
	noesis.setHandlerTypeCheck(handle, AMTCheckType)
	noesis.setHandlerLoadRGBA(handle, AMTLoadRGBA)
	#noesis.logPopup()
	return 1

def AMTCheckType(data):
	bs = NoeBitStream(data)
	magic = bs.readBytes(4).decode("ASCII")
	if magic != '#AMT':
		return 0
	return 1

def AMTLoadRGBA(data, texList):
	bs = NoeBitStream(data)
	header = bs.read("6I")
	bs.seek(header[5], NOESEEK_ABS)
	texOffset = bs.read(str(header[4]) + "I")
	#print(texOffset)
	for a in range(0, header[4]):
		bs.seek(texOffset[a], NOESEEK_ABS)
		texName = bs.readInt()
		texInfo = bs.read("8B")
		texInfo2 = bs.read("4H")
		texInfo3 = bs.read("7I")
		#print(texName, texInfo, texInfo2, texInfo3)
		bs.seek(texInfo3[0], NOESEEK_ABS)
		texData = bs.readBytes(texInfo3[1])
		bs.seek(texInfo3[4], NOESEEK_ABS)
		palData = bs.readBytes(texInfo3[5])
		if texInfo[4] == 5:
			pix = rapi.imageUntwiddlePSP(texData, texInfo2[2], texInfo2[3], 8)
			pix = rapi.imageDecodeRawPal(pix, palData, texInfo2[2], texInfo2[3], 8, "r8g8b8a0p8")
			texList.append(NoeTexture(str(texName), texInfo2[2], texInfo2[3], pix, noesis.NOESISTEX_RGBA32))
		elif texInfo[4] == 4:
			pix = rapi.imageUntwiddlePSP(texData, texInfo2[2], texInfo2[3], 4)
			pix = rapi.imageDecodeRawPal(pix, palData, texInfo2[2], texInfo2[3], 4, "r8g8b8a8")
			texList.append(NoeTexture(str(texName), texInfo2[2], texInfo2[3], pix, noesis.NOESISTEX_RGBA32))
		elif texInfo[4] == 3:
			pix = rapi.imageUntwiddlePSP(texData, texInfo2[2], texInfo2[3], 32)
			texList.append(NoeTexture(str(texName), texInfo2[2], texInfo2[3], pix, noesis.NOESISTEX_RGBA32))

	return 1