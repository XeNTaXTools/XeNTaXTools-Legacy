
Before compiling this project with CodeBlocks 13.12 for example

try out Make_obj.exe in \Make_obj\bin\Release 
- Kamen Rider with with MDL__B00007_7.prefab
(from the lower right drop down box chose KR_CW)

This will create Makeobj_log.obj


Kamen Rider CW *.prefab sample to be found here:
http://forum.xentax.com/viewtopic.php?f=16&t=17900&p=139138#p139138
(Thx to dswd2015)
Kamen Rider

----------------------------------------------------

or try out Make_obj.exe in \Make_obj\bin\Release 
Star Wars with Han_stormtrooper.rax
(from the lower right drop down box chose SW_BF3)

This will create Makeobj_log.obj


rax sample to be found here:
http://forum.xentax.com/viewtopic.php?f=16&t=13867&p=126467&hilit=stormtrooper#p126467
(Thx to AceWell)

----------------

or try out Make_obj.exe in \Make_obj\bin\Release 

- Scion of Fate with 101.YOM, enter 156A in lower left editbox

- Super Hero Generation with an mbg file

- Skyforge with a Base.Skin-Geometry.bin

This will create Makeobj_log.obj


Scion of Fate
-------------
101.YOM only, try others on your own risk
May require adding of unrecognized FI blocks in source file.
### Otherwise QNANs are very likely to happen! ###

For 101_type2.YOM enter 21F8 in editbox.

Your required to delete everything from submesh 366 
(line # 366. lastFI 47612, vCnt 504)
'til the end of Make_log.obj else blender import will fail!

Kao
--------
snowman outout.bin only

Skyforge
--------
important: the /3 doesn't apply for all ..-Geometry.bin files!

vStride = (BYTE) (vCnt / vCntSum / 3) ;

There was some confusion with Make_obj.exe files, where using "Skyforge"
required a vhm file. Just ignore, or use the exe(s) from this zip!

-----------

btw: mouse scroll wheel doesn't work for the lower right listbox
     use arrow up/down keys to find all handled 3D formats, just in case

have fun,
shak-otay

provided as is - the author can't be made responsible for any problems 
that might arise using the code and/or the exe files
