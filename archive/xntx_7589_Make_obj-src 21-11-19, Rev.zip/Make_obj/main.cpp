/*
#################################################################
# DISCLAIMER This is an excerpt from my Make_H2O project. (RIP)
#
# It is provided as is. It's self-written, except the __inline,
# the bubblesort-function, HFloat() and the MinGW_gcc_dll.
#
# So this is MY code, but you can do with it whatever you want.
#
# If you don't like my coding style then don't use it or write
# your own code.
# I'm writing code to solve problems not to be sophisticated.
# So the more complaints the more of my ugly code will be hidden
# in the DLL_MakeH2O.dll.
#
# Use it on your own risk. I won't overtake any responsibilities.
#################################################################
*/   // 28.5.2020, 12:13

#include <windows.h>

#include <stdio.h>		// FILE
#include <math.h>		//
#include "Main.h"

static char g_szClassName[] = "MyWindowClass";
static HINSTANCE g_hInst = NULL;

#define IDC_MAIN_TEXT   1001
#define bool BOOL
#define false FALSE
#define true TRUE
#define ID_LIST     1
#define ID_EDIT     2
#define ID_BUTTON1  3
#define ID_COMBO1   4

//typedef unsigned long   DWORD; // no effect
// replaced %x by %lu

#define FILENAME  TEXT("Makeobj_log.obj")

#define chDIMOF(Array) (sizeof(Array) / sizeof(Array[0]))
__inline void chMB(PCSTR s) {
   char szTMP[128];
   GetModuleFileNameA(NULL, szTMP, chDIMOF(szTMP));
   MessageBoxA(GetActiveWindow(), s, szTMP, MB_OK);
}

BYTE model = 7 ;    // 1: SW_BF3
                    // 2: Kamen Rider CW
                    // 3: Skyforge
                    // 4: SuperHeroGen, SHGen
                    // 5: Kao
                    // 6: Scion
                    // 7: GodSu

char szErrMess[1024]= "error in H20 no: " ;    // about 20 MB static file buffer for model files
char szFileNameG[MAX_PATH];
BYTE SM_cntArr[10] ;
BYTE FImode=0 ;           // 0: log, 1: get max FI no only
DWORD dwFileSize, dwStart, lastJ ;
FILE *stream ;          // for logfile (unused so far)
LPVOID lpFBuf ;         // pointer to file buffer
bool bFstRun= true ;    // KinectSW
bool bDbg= true ;       // debug on

bool bIsDW ;	       // for log_FIs()
bool bBigE= false ;

DWORD gvCnt_arr[1999] ;         // nur f�r "Trails in the Sky" ?
DWORD vSumGlob= 250000;

void bubblesort(int* &array, int* &array2, int length)   // array-Werte als call-by-value, oder doch by ref? (mit &)
 {
    int i, j;
    for (i = 0; i < length - 1; ++i)

        for (j = 0; j < length - i - 1; ++j) {
            if (array[j] > array[j + 1]) {
                int tmp = array[j]; array[j] = array[j + 1]; array[j + 1] = tmp;
                tmp = array2[j]; array2[j] = array2[j + 1]; array2[j + 1] = tmp;
            }
        }
 }

void Show_nFloats(FILE *stream, char* &pFBuf, DWORD &j, BYTE cnt, bool bBigE)
{
    char tmp[4] ;
    BYTE i, l ;
    float *pFloat ;
	float fData = 0.0f;

	pFloat= &fData ;

    if (bBigE)
        for (i=0;i<cnt;i++) {
            for (l=0;l<4;l++) tmp[3-l]= *(pFBuf+l) ;
            pFloat = (float*) tmp ;
			fprintf( stream, "%f ", *pFloat) ; pFBuf += 4 ; j += 4 ;
		}
	else
        for (i=0;i<cnt;i++) {
			pFloat = (float*) pFBuf ;
			fprintf( stream, "%f ", *pFloat) ; pFBuf += 4 ; j += 4 ;
		}
    fprintf( stream, "\n") ;
}

void ShowDWord(FILE *stream, char* &pFBuf, DWORD &j)
{
	BYTE i ;
	int nValue[4] ;

	for (i=0;i<4;i++) {									// 1x DW
		nValue[i] = (*pFBuf & 255) ; pFBuf++ ; j++ ;
		if (nValue[i]<16) fprintf( stream, "0") ;
		fprintf( stream, "%X ", nValue[i]) ;
	}
}

char * ShowString(FILE *stream, char* &pFBuf, DWORD &j, DWORD &dwStart)
{
	char szName[256] ;
	BYTE * pByte ;
	BYTE i ;
	DWORD dwCnt1 ;

	pByte = (BYTE*) &dwCnt1 ;							// DW-cnter Stringl�nge
	for (i=0;i<4;i++) {									//
		*pByte = *pFBuf &255 ; pByte++; pFBuf++; j++ ;
	}
	if (dwCnt1>255) { dwCnt1 = 0 ; fprintf( stream, "(strLen) ABBRUCH bei %7lx\n\n", j+dwStart); }
	dwStart+= dwCnt1 + 4 ;
	for (i=0;i<dwCnt1;i++) {							// String f�llen
		szName[i]= *pFBuf ; pFBuf++; j++ ;
	}
	szName[i]= '\0' ;									// Bone name
	return szName ;             // return local address, nicht gut?
	//fprintf( stream, "%s ", szName) ;
}

char * ShowFName(FILE *stream, char* &pFBuf, DWORD &j, BYTE cnt, DWORD &dwStart)
{
	char szName[256] ;
	//BYTE * pByte ;
	BYTE i ;

	if (cnt>255) { cnt = 0 ; fprintf( stream, "(strLen) ABBRUCH bei %7lx\n\n", j+dwStart); }
	dwStart+= cnt ;
	for (i=0;i<cnt;i++) {							// String f�llen
		szName[i]= *pFBuf ; pFBuf++; j++ ;
	}
	szName[i]= '\0' ;									// Bone name
	return szName ;             // return local address, nicht gut?
	//fprintf( stream, "%s ", szName) ;
}

WORD GetFaceIndexWord(char* &pFBuf, DWORD &j, DWORD &minFaceInd, DWORD &maxFaceInd, DWORD lastFaceInd, bool bBigE)		//
{																// lastFaceInd: start face index f�r n�chstes Submesh
	//char * pTmp ;
	BYTE i ;
	int nValue[3] ;
	WORD wFaceInd ;

	//pTmp= pFBuf ;
	for (i=0;i<2;i++) {
		nValue[i] = (*pFBuf & 255) ; pFBuf++ ; j++ ;			// 2 Byte-Index
	}
	if (bBigE)
        wFaceInd = (WORD) (nValue[1]+nValue[0]*256) + lastFaceInd ;
    else wFaceInd = (WORD) (nValue[0]+nValue[1]*256) + lastFaceInd ;
	// genome face-no +1 f�r Wandlung to Wavefront-obj
	wFaceInd++ ;
	if (wFaceInd<minFaceInd) minFaceInd = wFaceInd ;
	if (wFaceInd>maxFaceInd) maxFaceInd = wFaceInd ;
	return wFaceInd ;
}

DWORD GetFaceIndex(char* &pFBuf, DWORD &j, DWORD &minFaceInd, DWORD &maxFaceInd, DWORD lastFaceInd, bool bDW)		//
{																// lastFaceInd: start face index f�r n�chstes Submesh
	//char * pTmp ;
	BYTE i ;
	int nValue[3] ;
	DWORD dwFaceInd ;

	//pTmp= pFBuf ;   // helper var for GDB
	for (i=0;i<2;i++) { // supa, wie soll'n das 'n DWORD Wert werden?
		nValue[i] = (*pFBuf & 255) ; pFBuf++ ; j++ ;			// 2 Byte-Index
	}
	dwFaceInd = (WORD) (nValue[0]+nValue[1]*256) + lastFaceInd ;				//
	if (bDW) { nValue[2] = (*pFBuf & 255) ; pFBuf+=2 ; j+=2 ;
        dwFaceInd += (DWORD) nValue[2]*65536 ;
	}
	// genome face-no +1 f�r Wandlung to Wavefront-obj
	dwFaceInd++ ;
	if (dwFaceInd<minFaceInd) minFaceInd = dwFaceInd ;
	if (dwFaceInd>maxFaceInd) maxFaceInd = dwFaceInd ;
	return dwFaceInd ;
}

DWORD GetFaceIndexBigE(char* &pFBuf, DWORD &j, DWORD &minFaceInd, DWORD &maxFaceInd, DWORD lastFaceInd, bool bDW)		//
{																// lastFaceInd: start face index f�r n�chstes Submesh
	//char * pTmp ;
	BYTE i ;
	int nValue[3] ;
	DWORD dwFaceInd ;

	//pTmp= pFBuf ;                                              // helper var for GDB
	for (i=0;i<2;i++) {             //
		nValue[i] = (*pFBuf & 255) ; pFBuf++ ; j++ ;			// 2 Byte-Index
	}
        //fprintf( stream, "(%d) ", (WORD) (nValue[0]*256) ) ;        // this works
	dwFaceInd =  (WORD) (nValue[0]*256)+ nValue[1] + lastFaceInd ;// big endian
	// genome face-no +1 f�r Wandlung to Wavefront-obj
	dwFaceInd++ ;
	if (dwFaceInd<minFaceInd) minFaceInd = dwFaceInd ;
	if (dwFaceInd>maxFaceInd) maxFaceInd = dwFaceInd ;
	return dwFaceInd ;
}

bool show_table(DWORD dwStart)			// crappy code, I know, but: works
{					//
	char * pFBuf ;			//
	BYTE i ;
	int cnt=0, l, nValue[8] ;			//
	DWORD j ;		//

	pFBuf = (char *) lpFBuf ;           // start of file buffer
	pFBuf += dwStart ; j= 0 ; l= 0 ;
    fprintf( stream, "%s\n\n0x%lx:\n", szFileNameG, dwStart) ;
	for (l=0;l<100;l++) {				// 100 entries a 8 DWORDs
		for (cnt=0;cnt<8;cnt++) {
			for (i=0;i<4;i++) {									// 1x DWord
				nValue[i] = (*pFBuf & 255) ; pFBuf++ ; j++ ;
			}
			if (nValue[2]!=0) fprintf( stream, "    x") ;
			else fprintf( stream, "%5d", nValue[0] + nValue[1]*256) ;       // little endian
			fprintf( stream, " ") ;
		}
		fprintf( stream, "\n") ;
	}
	fprintf( stream, "0x%lx\n", dwStart+j) ;
	return true ;
}

void log_WordsBE(DWORD dwStart)			//
{					//
	char * pFBuf ;			//
	BYTE i ;
	int cnt=0, nValue[2] ;			//
	WORD w ;
	DWORD j ;		//

	pFBuf = (char *) lpFBuf ;           // start of file buffer
	pFBuf += dwStart ; j= 0 ;
    for (cnt=0;cnt<46;cnt++) {
        for (i=0;i<2;i++) {									// 1x DWord
			nValue[i] = (*pFBuf & 255) ; pFBuf++ ; j++ ;
		}
		w= nValue[0]*256 + nValue[1] ;       // big endian
		if (w!=0) fprintf( stream, "%5d ", w) ; else fprintf( stream, "0 ") ;
    }
    fprintf( stream, "\n") ;
}

bool log_MBG(void)			// crappy code, I know, but: works
{					//
	char * pFBuf ;			//
	BYTE fCnt=0 ;
	int cnt=1, FIcnt, i, l=0 ;			// , nValue[8]
	WORD FI ;
	DWORD j, dwStart= 0x395, lastFaceInd=0, minFaceInd= 0xFFFF, maxFaceInd=0 ;		//
	bool bStop= false ;

	pFBuf = (char *) lpFBuf ;           // start of file buffer
	dwStart= 0x138D ;
	pFBuf += dwStart ; j= 0 ;
    fprintf( stream, "# %s\n\n0x%lx:\n", szFileNameG, dwStart) ;
	//for (l=0;l<6731;l++) {				// a 76 bytes (12, 2x8, 3x12 +4x5)  sind aber nicht immer 76 pro l
	while ((l<15000)&&!bStop) {
        if (*pFBuf==1) {
            pFBuf += 4 ; j += 4 ;       // skip 01 000000
            switch (cnt) {
                case 1: fprintf( stream, "v ") ; break ;
                case 2: fprintf( stream, "vt ") ; break ;
                default: fprintf( stream, "# ") ;
            }
            if (cnt<6) cnt++ ; else cnt= 1 ;
            if (*pFBuf==8) {
                pFBuf++ ; j ++ ; Show_nFloats(stream, pFBuf, j, 2, true) ;
            }
            else if (*pFBuf==12) {
                pFBuf++ ; j ++ ; Show_nFloats(stream, pFBuf, j, 3, true) ;
            }
            else {          // == 4?
                pFBuf++ ; j ++ ; ShowDWord(stream, pFBuf, j) ;
            }
            if (cnt==6) fprintf( stream, "# %d 0x%lx\n", l, dwStart+j) ;
        }
        else if (*pFBuf==3) {  // idx
            pFBuf += 3 ; j += 3 ; // size des idx blocks folgt (als Word gelesen statt DWord)
            FIcnt= GetFaceIndexWord(pFBuf, j, minFaceInd, maxFaceInd, lastFaceInd, true) ; FIcnt-- ;
            fprintf( stream, "\n") ;
            for (i=0;i<FIcnt/2;i++) {       // weil, FIcnt ist die size
                FI= GetFaceIndexWord(pFBuf, j, minFaceInd, maxFaceInd, lastFaceInd, false) ; // littleE
                if (fCnt==0) fprintf( stream, "f ") ;
                fprintf( stream, "%d ", FI) ; fCnt++ ;
                if (fCnt==3) { fCnt=0 ; fprintf( stream, "\n") ; }
            }
            fprintf( stream, "\n") ; bStop= true ;
        }
        else if (*pFBuf==7) {
            ShowDWord(stream, pFBuf, j) ;
        }
        l++ ;
	}
	fprintf( stream, "# 0x%lx\n", dwStart+j) ;
	return true ;
}

void SM_of_unkn_loop(HWND hwnd, char szPathname[], DWORD dwStart)      // scanning the submeshes params in the MLX table
{
   //char * pFBuf ;
   //BYTE * pByte, cnt, i ;

   //DWORD deltaFI, deltaV, dwFaceIndCnt, dwFICntLast=0, dwVertsCnt, dwVCntLast=0, addrFI=0x124D0, addrV=0x1BC20, j ;

   chMB("WIP, not included, sry!\nMaybe released when working better/for more than one model.") ;
}

DWORD dataAlignment(DWORD j){
    int cnt ;

    cnt = j/16 ; cnt++ ;
    if ((j%16)!=0) { j = cnt*16 ; }
    return j ;
}
DWORD dataAlignment_4(DWORD j){
    int cnt ;

    cnt = j/4 ; cnt++ ;
    if ((j%4)!=0) { j = cnt*4 ; }
    return j ;
}

void GetDW(char * &pFBuf, DWORD &j, DWORD &dw, bool bBigE) {
    BYTE * pByte, i ;
    WORD wLo, wHi ;
    DWORD dwTmp ;

    pByte = (BYTE*) &dw ;    			        // get vertex count
    for (i=0;i<4;i++) {									//
        *pByte = *pFBuf &255 ; pByte++; pFBuf++; j++ ;
    }
    if (bBigE) {
        dwTmp = dw / 65536 ;        // low word
        wLo= dwTmp % 256 ; wHi= dwTmp / 256 ;           // little to big endian correction
        dwTmp= wLo * 256 + wHi ;
        dw %= 65536 ;               // hi word
        wLo= dw % 256 ; wHi= dw / 256 ;
        dw= (wLo * 256 + wHi)*65536 + dwTmp ;
    }
}
void GetWord(char * &pFBuf, DWORD &j, WORD &w, bool bBigE) {
    BYTE * pByte, i ;
    WORD wLo, wHi ;

    pByte = (BYTE*) &w ;
    for (i=0;i<2;i++) {
        *pByte = *pFBuf &255 ; pByte++; pFBuf++; j++ ;
    }
    if (bBigE) {
        wLo= w % 256 ; wHi= w / 256 ;           // little to big endian correction
        w= wLo * 256 + wHi ;
    }
}

// *** for MLX only!***
BYTE GetFirstSubMesh_vertexStart(char * pFBuf, DWORD &addrFI, DWORD dwFIrel, BYTE KFMG_cnt) {
   char * pTmp ;
   BYTE cnt= 1, retcnt ;
   DWORD dwFIprev[256], dwFaceIndCnt, dwFICntLast=0, dwVertsCnt, dwVCntLast=0 ;
   DWORD addrFIbac, deltaFI, deltaV, j=0 ;	// addrFIprev,
   bool bStop= false ;

    pTmp= pFBuf ; addrFIbac= addrFI ;
        //fprintf( stream, "  addr FI, FIrel vCnt\n") ;
    // first calculation while loop results in false addrFI! because of possible negative counts
    do {
        dwFIprev[cnt-1]= dwFIrel ;
        GetDW(pFBuf, j, dwFIrel, false) ;                   // only required for last FI addr
        GetDW(pFBuf, j, dwVertsCnt, false) ;
        bStop= (dwVertsCnt==0)||(dwVertsCnt>65535) ;
        deltaV= dwVertsCnt - dwVCntLast ; dwVertsCnt= deltaV ;
        GetDW(pFBuf, j, dwFaceIndCnt, false) ;              // absoulte FI count
        deltaFI= dwFaceIndCnt - dwFICntLast ; dwFaceIndCnt= deltaFI ;
        pFBuf += 5*4 ; j += 5*4 ;                           // next table SM entry for MLX tables only!
            //fprintf( stream, "%d 0x%lx %d (%d), v%d\n", cnt-1, addrFI, dwFIprev[cnt-1], deltaFI, deltaV) ; // deltaV evtl. negativ!
        //addrFIprev= addrFI ;
        addrFI += deltaFI*2 ;
        dwVCntLast += deltaV ; dwFICntLast += deltaFI ;
        if (cnt<254) cnt++ ; else chMB("more than 256 submeshes per KFMG can't be handled") ;
   } while (!bStop && (j<dwFileSize)) ;
   if (bStop) fprintf( stream, " breaking count in table= %ld\n\n", dwVertsCnt) ;
   else fprintf( stream, " EOF met on table scan\n\n") ;
   if (cnt!=SM_cntArr[KFMG_cnt]) {
       fprintf( stream, "\n SM_counts: %d!=%d \n", SM_cntArr[KFMG_cnt], cnt) ;
       cnt= SM_cntArr[KFMG_cnt] ;
   }
   retcnt= cnt ;

   pFBuf= pTmp +4 ;     // weil FIrel jetzt nicht gelesen
   dwFIrel=0; dwFICntLast=0; dwVCntLast=0 ;
   addrFI= addrFIbac ; j= 0 ;
   for (cnt=0;cnt<retcnt;cnt++) {             // -1 to avoid last fxxxing value/line
       GetDW(pFBuf, j, dwVertsCnt, false) ;
       deltaV= dwVertsCnt - dwVCntLast ; dwVertsCnt= deltaV ;
       GetDW(pFBuf, j, dwFaceIndCnt, false) ;              // absoulte FI count
       deltaFI= dwFaceIndCnt - dwFICntLast ;               // kann negativ sein!
       deltaFI= dwFIprev[cnt] ;                             // <- daher
       dwFaceIndCnt= deltaFI ;
       pFBuf += 6*4 ; j += 6*4 ;                           // next table SM entry for MLX tables only!
       //addrFIprev= addrFI ;
       addrFI += deltaFI*2 ; //fprintf( stream, " %d (%d->) addr FI= 0x%lx\n", cnt, deltaFI, addrFI) ;
       dwVCntLast += deltaV ; dwFICntLast += deltaFI ;
   }
   fprintf( stream, "last addr FI= 0x%lx\n", addrFI) ;
   return retcnt ;
}
BYTE GetFirstSubMesh_vertexStart_(char * pFBuf, DWORD &addrFI) {
   BYTE cnt= 1 ;
   DWORD dwFIrel=0, dwFIprev, dwFaceIndCnt, dwFICntLast=0, dwVertsCnt, dwVCntLast=0 ;
   DWORD addrFIprev, deltaFI, deltaV, j=0 ;
   bool bStop= false ;

        //fprintf( stream, "  addr FI\n") ;
    do {
        dwFIprev= dwFIrel ;
        GetDW(pFBuf, j, dwFIrel, false) ;                   // only required for last FI addr
        GetDW(pFBuf, j, dwVertsCnt, false) ;
        bStop= (dwVertsCnt==0)||(dwVertsCnt>65535) ;
        deltaV= dwVertsCnt - dwVCntLast ; dwVertsCnt= deltaV ;
        GetDW(pFBuf, j, dwFaceIndCnt, false) ;              // absoulte FI count
        deltaFI= dwFaceIndCnt - dwFICntLast ; dwFaceIndCnt= deltaFI ;
        pFBuf += 5*4 ; j += 5*4 ;                           // next table SM entry for MLX tables only!
            fprintf( stream, "%d 0x%lx %ld (%ld), v%ld\n", cnt-1, addrFI, dwFIprev, deltaFI, deltaV) ; // deltaV evtl. negativ!
        addrFIprev= addrFI ;
        addrFI += deltaFI*2 ;
        dwVCntLast += deltaV ; dwFICntLast += deltaFI ;
        cnt++ ;
   } while (!bStop && (j<dwFileSize)) ;
   addrFI = addrFIprev + dwFIprev*2 ; fprintf( stream, "last addr FI= 0x%lx, cnt %ld\n", addrFI, dwFIprev) ;
   if (bStop) fprintf( stream, " breaking count in table= %ld\n\n", dwVertsCnt) ;
   else fprintf( stream, " EOF met on table scan\n\n") ;
   return cnt ;
}
//SetWindowText (hwndEdit, "F200");

void logUVs(DWORD addrUV, DWORD Vcnt, BYTE vStride)
{
    char *pFBuf ;
    BYTE i ;
    DWORD k ;
    float *pFloat ;
	float fData = 0.0f;

    pFloat= &fData ;
    pFBuf = (char *) lpFBuf ;
    pFBuf += addrUV ;
	for (k=0;k < Vcnt;k++) {
        fprintf( stream, "vt ") ;
        for (i=0;i<2;i++) {
            pFloat = (float*) pFBuf ; fprintf( stream, "%f ", *pFloat) ; pFBuf += 4 ;
        }
        fprintf( stream, "\n") ;
		pFBuf += vStride-8 ;
	}
}
void log_UVsBE(DWORD addrUV, DWORD Vcnt, BYTE vStride)
{
    char *pFBuf, pTmp[4] ;
    BYTE i, l ;
    DWORD k ;
    float *pFloatBE ;
	float fData = 0.0f;

    pFloatBE= &fData ;
    pFBuf = (char *) lpFBuf ;
    pFBuf += addrUV ;
	for (k=0;k < Vcnt;k++) {
        fprintf( stream, "vt ") ;
        for (i=0;i<2;i++) {
            for (l=0;l<4;l++) pTmp[3-l]= *(pFBuf+l) ;
            pFloatBE= (float*) pTmp ; fprintf( stream, "%f ", *pFloatBE) ; pFBuf += 4 ;
        }
        fprintf( stream, "\n") ;
		pFBuf += vStride-8 ;
	}
}
void log_short_UVs(DWORD addrUV, DWORD Vcnt, BYTE vStride)
{
    char *pFBuf ;
    BYTE i, l ;
    int nValue[2] ;
    DWORD k ;
    float lPosXYZ ;

    pFBuf = (char *) lpFBuf ;
    pFBuf += addrUV ;
	for (k=0;k < Vcnt;k++) {
        fprintf( stream, "vt ") ;
		for (l=0;l<2;l++) {
			for (i=0;i<2;i++) {									// 1x Word
				nValue[i] = (*pFBuf & 255) ; pFBuf++ ;
			}
            if (!bBigE) lPosXYZ= nValue[0] + nValue[1]*256 ;
            else lPosXYZ= nValue[0]*256 + nValue[1] ;           // big endian for BF3
            if (lPosXYZ>32767) lPosXYZ -= 65536;
			//fprintf( stream, "%f ", lPosXYZ/32768.0) ;
			fprintf( stream, "%f ", lPosXYZ/4096.0) ;        // was /256.0
		}
		fprintf( stream, "\n") ;
		pFBuf += vStride-4 ;
	}
}

void Vertex12(FILE *stream, DWORD dwStart, DWORD dwVertsCnt, BYTE vStride, bool bBigE)	//
{
	char *pFBuf, pTmp[4] ;
	int i, l ;			//, nValue[12]
	DWORD j, k ;
    float *pFloat, *pFloatBE ;
	float fData = 0.0f ;    // , XYZPos

	pFBuf = (char *) lpFBuf ;
	pFBuf += dwStart ;	j= dwStart ;

	pFloatBE= &fData ; pFloat= &fData ;
    if (bBigE)
    for (k=0;k < dwVertsCnt;k++) {
		fprintf( stream, "v ") ;
        for (i=0;i<3;i++) {
            for (l=0;l<4;l++) pTmp[3-l]= *(pFBuf+l) ;
            pFloatBE= (float*) pTmp ;
			fprintf( stream, "%f ", *pFloatBE) ; pFBuf += 4 ; j += 4 ;
		}
		fprintf( stream, "\n") ;
		pFBuf += vStride-12 ; j += vStride-12 ;
	}
	else for (k=0;k < dwVertsCnt;k++) {
		fprintf( stream, "v ") ;
        for (i=0;i<3;i++) {
			pFloat = (float*) pFBuf ;
			fprintf( stream, "%f ", *pFloat) ; pFBuf += 4 ; j += 4 ;
		}
		fprintf( stream, "\n") ;
		pFBuf += vStride-12 ; j += vStride-12 ;     // this line was missing in releases prior to 7-3-2018
	}
}

float HFloat(char* &pFBuf, DWORD &j, bool bBigE)        // auch BigEndian
{
	BYTE i, nValue[4] ;
	DWORD h, h2 ;
	//float lPosXYZ ;
    float *pFloat ;
	float fData = 0.0f;

		for (i=0;i<2;i++) {
			nValue[i] = (*pFBuf & 255) ; pFBuf++ ; j++ ;
		}
		if (bBigE) h = nValue[0]*256 + nValue[1] ;
		else h = nValue[1]*256 + nValue[0] ;
		h2 = ((h&0x8000)<<16) | (((h&0x7c00)+0x1C000)<<13) | ((h&0x03FF)<<13) ;
		h = h2 / 65536 ; nValue[3]= h / 256 ; nValue[2]= h % 256 ;
		h = h2 % 65536 ; nValue[1]= h / 256 ; nValue[0]= h % 256 ;
		pFloat = (float*) nValue ;
		return *pFloat ;	// check whether value is correct!
}

void logUVsHF(DWORD addrUV, DWORD Vcnt, BYTE vStride)
{
    char *pFBuf ;
    BYTE i ;
    DWORD j, k ;
    //float *pFloat ;
	//float fData = 0.0f;

    //pFloat= &fData ;
    pFBuf = (char *) lpFBuf ;
    pFBuf += addrUV ; j= dwStart ;
	for (k=0;k < Vcnt;k++) {
        fprintf( stream, "vt ") ;
        for (i=0;i<2;i++) {
            fprintf( stream, "%f ", HFloat(pFBuf, j, bBigE)) ;
        }
        fprintf( stream, "\n") ;
		pFBuf += vStride-4 ; j += vStride-4 ;
	}
}
void Vertex6_HF(FILE *stream, DWORD dwStart, DWORD dwVertsCnt, BYTE stride)	// , DOUBLE xMax,DOUBLE yMax,DOUBLE zMax, DOUBLE xThres,DOUBLE yThres,DOUBLE zThres
{
	char *pFBuf ;
	int i ;			//, nValue[12]
	DWORD j, k ;
	bool bBigE= false ;      //

	pFBuf = (char *) lpFBuf ;
	pFBuf += dwStart ; j= dwStart ;

    for (k=0;k < dwVertsCnt;k++) {
		fprintf( stream, "v ") ;
        for (i=0;i<3;i++) {
            fprintf( stream, "%f ", HFloat(pFBuf, j, bBigE)) ; //
		}
		fprintf( stream, "\n") ;
		pFBuf += stride-6 ; j += stride-6 ;
	}
}
void log_Verts(DWORD addrV, DWORD Vcnt, BYTE vStride)   // floats
{
    char *pFBuf ;
    BYTE i ;
    DWORD k ;
    float *pFloat ;
	float fData = 0.0f;

    pFloat= &fData ;
    pFBuf = (char *) lpFBuf ;
    pFBuf += addrV ;
	for (k=0;k < Vcnt;k++) {
        fprintf( stream, "v ") ;
        for (i=0;i<3;i++) {
            pFloat = (float*) pFBuf ; fprintf( stream, "%f ", *pFloat) ; pFBuf += 4 ; // +5 f�r el Mat
        }
        fprintf( stream, "\n") ;
		pFBuf += vStride-12 ;   // -15 f�r el Mat
	}
}

void log_short_Verts(DWORD addrV, DWORD Vcnt, BYTE vStride) // warum hier stride not in code?
{
    char *pFBuf ;
    BYTE i, l ;
    int nValue[2] ;
    DWORD k ;
    float lPosXYZ ;

    pFBuf = (char *) lpFBuf ;
    pFBuf += addrV ;
	for (k=0;k < Vcnt;k++) {
        fprintf( stream, "v ") ;
		for (l=0;l<3;l++) {
			for (i=0;i<2;i++) {									// 1x Word
				nValue[i] = (*pFBuf & 255) ; pFBuf++ ;
			}
            if (!bBigE) lPosXYZ= nValue[0] + nValue[1]*256 ;
            else lPosXYZ= nValue[0]*256 + nValue[1] ;            // big endian
            if (lPosXYZ>32767) lPosXYZ -= 65536;
			fprintf( stream, "%f ", lPosXYZ/256.0) ;        // 32768.0?
		}
		fprintf( stream, "\n") ;
		pFBuf += vStride-6 ;
	}
}

void log_FIs_Kao(FILE *stream, DWORD dwStart, DWORD &minFaceInd, DWORD &maxFaceInd, DWORD &lastFaceInd, DWORD FIcnt_arr[], int cnt) // cnt= SMcnt
{
    char *pFBuf, szNo[5] ;
    BYTE fCnt= 0 ;
    DWORD FI[4], k ;     //
    DWORD j, prevFI ;

	pFBuf = (char *) lpFBuf ;
	pFBuf += dwStart ;	j= dwStart ; prevFI= lastFaceInd ;

        _itoa(cnt, szNo, 10) ; fprintf( stream, "g SM_%s\n", szNo) ;      // separating the submeshes (building groups)
            //fprintf( stream, "# FIcnt: %d\n", FIcnt_arr[i]) ;
        for (k=0;k<FIcnt_arr[cnt];k++) {       //
            //               adding lastFaceInd inside fct. for absolute FIs
            FI[fCnt]= GetFaceIndex(pFBuf, j, minFaceInd, maxFaceInd, lastFaceInd, false) ;	// j for count only!
            pFBuf += 2 ; j += 2 ;               // skip unkn
            fCnt++ ;
            if (fCnt==4) {
                fprintf( stream, "f %lu/%lu %lu/%lu %lu/%lu\n", FI[0],FI[0],FI[1],FI[1],FI[2],FI[2]) ;
                fCnt=0 ;
            }
        }
        if (maxFaceInd<lastFaceInd) {
            fprintf( stream, "# error! maxFI %lu < lastFI %lu\n\n", maxFaceInd, lastFaceInd) ;
        }           //
        else lastFaceInd = maxFaceInd ;         // needed to "convert" relative to absolute face indices
        gvCnt_arr[cnt] = lastFaceInd - prevFI ;  // wieso nicht +1?
            //fprintf( stream, "# %d. maxFI %d,  lastFI %d\n\n", cnt, maxFaceInd, lastFaceInd) ;
            // sind identischhier
            fprintf( stream, "# %d. lastFI %ld, vCnt %ld\n\n", cnt, lastFaceInd, gvCnt_arr[cnt]) ;
        //fprintf( stream, "# next FI block: %lx\n", j) ;
}
void log_FIs(FILE *stream, DWORD dwStart, DWORD &minFaceInd, DWORD &maxFaceInd, DWORD &lastFaceInd, DWORD FIcnt_arr[], int cnt, bool bSkip) // cnt= SMcnt
{
    char *pFBuf, szNo[5] ;
    BYTE fCnt= 0 ;
    DWORD FI[3], k ;     // WORD reichte f�r TrailsInTheSky
    DWORD j, prevFI ;

	pFBuf = (char *) lpFBuf ;
	pFBuf += dwStart ;	j= dwStart ; prevFI= lastFaceInd ;

        _itoa(cnt, szNo, 10) ;
		if (!bSkip) fprintf( stream, "g SM_%s\n", szNo) ;      // separating the submeshes (building groups)
            //fprintf( stream, "# FIcnt: %d\n", FIcnt_arr[i]) ;
        for (k=0;k<FIcnt_arr[cnt];k++) {       //
            //               adding lastFaceInd inside fct. for absolute FIs
            if (bIsDW)
                FI[fCnt]= GetFaceIndex(pFBuf, j, minFaceInd, maxFaceInd, lastFaceInd, true) ;
            else
                FI[fCnt]= GetFaceIndex(pFBuf, j, minFaceInd, maxFaceInd, lastFaceInd, false) ;	// j for count only!
            fCnt++ ;
            if (fCnt==3) {
                fCnt=0 ;
                if (FImode==0)
                    fprintf( stream, "f %ld/%ld %ld/%ld %ld/%ld\n", FI[0],FI[0],FI[1],FI[1],FI[2],FI[2]) ;
            }
        }
        if (maxFaceInd<lastFaceInd) {
            fprintf( stream, "# error! maxFI %ld < lastFI %ld\n\n", maxFaceInd, lastFaceInd) ;
        }           //
        else lastFaceInd = maxFaceInd ;         // needed to "convert" relative to absolute face indices
        gvCnt_arr[cnt] = lastFaceInd - prevFI ;  // wieso nicht +1?
            //fprintf( stream, "# %d. maxFI %d,  lastFI %d\n\n", cnt, maxFaceInd, lastFaceInd) ;
            // sind identischhier
            fprintf( stream, "# %d. lastFI %ld, vCnt %ld\n\n", cnt, lastFaceInd, gvCnt_arr[cnt]) ;
        //fprintf( stream, "# next FI block: %lx\n", j) ;
}
void log_FIsBigE(FILE *stream, DWORD dwStart, DWORD &minFaceInd, DWORD &maxFaceInd, DWORD &lastFaceInd, DWORD FIcnt_arr[], int cnt) // cnt= SMcnt
{
    char *pFBuf, szNo[5] ;
    BYTE fCnt= 0 ;
    DWORD FI[3], k ;     // WORD reichte f�r TrailsInTheSky
    DWORD j, prevFI ;
    bool bBad= false ;

	pFBuf = (char *) lpFBuf ;
	pFBuf += dwStart ;	j= dwStart ; prevFI= lastFaceInd ;

        _itoa(cnt, szNo, 10) ; fprintf( stream, "g SM_%s\n", szNo) ;      // separating the submeshes (building groups)
            //fprintf( stream, "# FIcnt: %d\n", FIcnt_arr[i]) ;
        for (k=0;k<FIcnt_arr[cnt];k++) {       //
            //               adding lastFaceInd inside fct. for absolute FIs
            if (bIsDW)
                FI[fCnt]= (WORD) GetFaceIndexBigE(pFBuf, j, minFaceInd, maxFaceInd, lastFaceInd, true) ;
            else
                FI[fCnt]= (WORD) GetFaceIndexBigE(pFBuf, j, minFaceInd, maxFaceInd, lastFaceInd, false) ;	// j for count only!
            if (FI[fCnt]>250000) { FI[fCnt]= lastFaceInd ; fprintf( stream, "# error FI!\n") ; }
            if (FI[fCnt]>vSumGlob) bBad= true ;     // SHeroGen
            fCnt++ ;
            if (fCnt==3) {
                fCnt=0 ;
                if (bBad) fprintf( stream, "# ") ;
                fprintf( stream, "f %ld/%ld %ld/%ld %ld/%ld\n", FI[0],FI[0],FI[1],FI[1],FI[2],FI[2]) ;
                bBad= false ;
            }
        }
        if (maxFaceInd<lastFaceInd) {
            fprintf( stream, "# error! maxFI %ld < lastFI %ld\n\n", maxFaceInd, lastFaceInd) ;
        }           //
        else lastFaceInd = maxFaceInd ;         // needed to "convert" relative to absolute face indices
        gvCnt_arr[cnt] = lastFaceInd - prevFI ;  // wieso nicht +1?
            //fprintf( stream, "# %d. maxFI %d,  lastFI %d\n\n", cnt, maxFaceInd, lastFaceInd) ;
            // sind identischhier
            fprintf( stream, "# %d. lastFI %ld, vCnt %ld\n\n", cnt, lastFaceInd, gvCnt_arr[cnt]) ;
        //fprintf( stream, "# next FI block: %lx\n", j) ;
}
bool check4addFIGroup(char * &pFBuf, DWORD &j, DWORD &FIcnt, DWORD border)
{
    //int nValue[8] ;
    DWORD dumCnt, flag ;

    GetDW(pFBuf, j, flag, false) ;
    if (flag!=1) return false ;
    GetDW(pFBuf, j, flag, false) ;
    if (flag!=1) return false ;
    else {
            //fprintf(stream, "JuppH\n") ;
        pFBuf += 8 ; j += 8 ; // nextFIgroup = j;
        GetDW(pFBuf, j, dumCnt, false) ;
        pFBuf += 4 ; j += 4 ;                   // skip 00000000 zwischen evtl. counts
        GetDW(pFBuf, j, flag, false) ;
        if (flag==dumCnt) return false ;        // 2 counter f�r irgendwas, aber keine FIs hier
        pFBuf -= 8 ; j -= 8 ;           // wieda zur�ck, wenn's kein dumCnt war
        GetDW(pFBuf, j, dumCnt, false) ;      // vCnt als dummyCnt
            //fprintf(stream, "dumCnt: %d at %lx\n", dumCnt, j-4) ; return false ;
        if (dumCnt>1024) return false ;
        pFBuf += dumCnt*2 ; j += dumCnt*2 ;
        GetDW(pFBuf, j, FIcnt, false) ;
        GetDW(pFBuf, j, dumCnt, false) ;
        if (FIcnt!=dumCnt) return false ;        // FICnt
        // zu kompliziert
/*        pFBuf -= 4 ; j -= 4 ;           // wieda zur�ck, wenn's kein dumCnt war
        nValue[0]= 1; nValue[1]= 0; nValue[2]= 0; nValue[3]= 0;    // assumed signature of FIs end
        nValue[4]= 1; nValue[5]= 0; nValue[6]= 0; nValue[7]= 0;
        offs2 = FindBytes(lpFBuf, j, dwFileSize-j, nValue, 8) ;
        if (offs2==0) {chMB("error: no 01000000 after addFIgroup"); return false ;}
        FIcnt= offs2/2 ;
        if (j+FIcnt*2>border) return false ;    // wohl doch keine FIs hier     */
            //fprintf(stream, "%d FIs at %lx\n", FIcnt, j) ;
    }
    return true ;
}

void SM_of_DFF_loop(HWND hwnd, char szPathname[], DWORD dwStart)      // scanning the submeshes params for Captn America
{                                                                         // only model tested
   char * pFBuf ;            // , szNo[4], *pTmp
   BYTE cnt ;
   //int nValue[16] ;
   //WORD wFaceIndCnt, wVertsCnt, wOffs2VBlock ;         //
   //DWORD addrFI=0, addrUV, addrV, jOld, lastJ, offs2 ;  //
   DWORD j=0 ;
   float *pFloat ;
   float fData = 0.0f;
   bool bStop= false ;

   pFBuf = (char *) lpFBuf ; //pTmp= pFBuf ;
   dwStart = 0x23BA5 ;                                        // unneeded here
   dwStart = 0x2425D ;
   dwStart = 0x25000 ;
   pFBuf += dwStart ;
   SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " creating obj:") ;
   cnt= 0 ; lastJ= 0 ;
   do {
        if ((cnt%3)==0) fprintf( stream, "\n0x%lx v ",  dwStart+j) ;
        pFloat = (float*) pFBuf ; cnt++ ;
		fprintf( stream, "%f ", *pFloat) ; pFBuf += 4 ; j += 4 ;
		if (*(pFBuf+2)==0) {fprintf( stream, " %lx+4 ", dwStart+j) ; pFBuf += 4 ; j += 4 ; }
		if ((*(pFBuf+4)==0)&&(*(pFBuf+5)!=0)) {fprintf( stream, " %lx+6 ", dwStart+j) ; pFBuf += 6 ; j += 6 ; }
		if ((*(pFBuf+3)==0)&&(*(pFBuf+5)==0)) {fprintf( stream, " %lx+8 ", dwStart+j) ; pFBuf += 8 ; j += 8 ; }
		else if ((*(pFBuf+3)==0)) {fprintf( stream, " %lx+5 ", dwStart+j) ; pFBuf += 5 ; j += 5 ; }
   } while (!bStop&&(j<dwStart+0x520)) ; // dwFileSize

}

void SM_of_KR_CW_loop(HWND hwnd, char szPathname[], DWORD dwStart)      //
{                                                                         // Kamen Rider City Wars
   char * pFBuf ;            // , *pTmp, szNo[4]
   BYTE cnt= 0 ;
   int nValue[16] ;
   //WORD wFaceIndCnt, wVertsCnt, wOffs2VBlock ;         //
   DWORD FIaddr_arr[999], FIcnt, FIcnt_arr[999], uvCnt, vCnt ;  // Vaddr_arr[999], vCnt_arr[999]
   DWORD minFaceInd = 16777215, maxFaceInd = 0, lastFaceInd=0 ;
   DWORD addrFI=0, addrUV, addrV, offs2 ;  //
   DWORD j=0 ;
   bool bUV ;

   pFBuf = (char *) lpFBuf ; //pTmp= pFBuf ;
   //if ((*pFBuf!=0xww)&&(*(pFBuf+3)!=0xyy)) {
   //     chMB("This doesn't seem to be a Kamen Rider CW prefab file!") ; return ;
   //}
   dwStart = 0 ; pFBuf += dwStart ;            //Triangles 54 72 69 61 Positions  50 6F 73 69
   SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " creating obj:") ;
   cnt= 0 ; lastJ= 0 ;
   nValue[0]= 0x54; nValue[1]= 0x72; nValue[2]= 0x69; nValue[3]= 0x61;          // Tria

        offs2 = FindBytes(lpFBuf, j, dwFileSize-j, nValue, 4) ;       // j is offset here
        if (offs2!=0) {
            pFBuf += offs2 ; j += offs2 ; fprintf( stream, "#") ;
            if (*(pFBuf+8)!= 0x73) {
                chMB("String 'Triangles' not found! - EXIT") ; return ;
            }
            addrFI = j ;
            fprintf( stream, " Triangles string at %lx\n", j) ;
        }
        else {
            chMB("String 'Triangles' not found! - EXIT") ; return ;
        }

   nValue[0]= 0; nValue[1]= 0; nValue[2]= 1; nValue[3]= 0; nValue[4]= 2; nValue[5]= 0;          // 0000 0100 0200

        offs2 = FindBytes(lpFBuf, addrFI, dwFileSize-j, nValue, 6) ;       // j is offset here
        if (offs2!=0) {
            pFBuf += offs2 ; j += offs2 ; fprintf( stream, "#") ;
            addrFI = j ;
            fprintf( stream, " 0000 0100 0200 at %lx\n", j) ;
        }
        else {
            chMB("0000 0100 0200 not found! - EXIT") ; return ;
        }
        FIaddr_arr[cnt]= j ; pFBuf -= 4 ; j -= 4 ;
        GetDW(pFBuf, j, FIcnt, false) ; FIcnt_arr[cnt]= FIcnt /2 ;
        fprintf( stream, "# FIs: %ld\n", FIcnt_arr[cnt]) ;
        log_FIs(stream, FIaddr_arr[cnt], minFaceInd, maxFaceInd, lastFaceInd, FIcnt_arr, cnt, false) ;

   cnt= 0 ;
   nValue[0]= 7; nValue[1]= 0; nValue[2]= 0; nValue[3]= 0; nValue[4]= 3;    // Normals, BiNormals, Positions
   do {
        offs2 = FindBytes(lpFBuf, j, dwFileSize-j, nValue, 5) ;       // j is offset here
        if (offs2!=0) {
            pFBuf += offs2 ; j += offs2 ; fprintf( stream, "#") ;
            if (*(pFBuf+8)==1) {
                //fprintf( stream, "sig 07000000 at %lx\n", j) ;
                offs2= 0 ; addrV= j + 17 ;
                fprintf( stream, " verts at %lx\n", addrV) ;
                cnt++ ;
                //if (cnt==3) {             // we search behind FIS, so Normals/BiNorm sig is skipped
                //    offs2= 0 ; addrV= j + 17 ;
                //    fprintf( stream, "verts at %lx\n", addrV) ;
                //}
            }
        }
        pFBuf += 8 ; j += 8 ;
   } while ((offs2!=0)&&(j<dwFileSize)) ;
        //if (cnt!= 3) chMB("not all sigs for Norm/BiNorm/Pos found!\nModel will be faulty.") ;
   if (cnt!= 1) { chMB("Pos sig not found, no verts in model!\nExit.") ; return ; }
   pFBuf += 5 ; j += 5 ;            // advance to verts blocksize, DWord
   GetDW(pFBuf, j, vCnt, false) ; vCnt = vCnt/12 ;
   fprintf( stream, "# verts count: %ld\n", vCnt) ;
   log_Verts(addrV, vCnt, 12) ;

   pFBuf = (char *) lpFBuf ; j= 0 ;
   nValue[0]= 7; nValue[1]= 0; nValue[2]= 0; nValue[3]= 0; nValue[4]= 2;    // UVx
        offs2 = FindBytes(lpFBuf, j, dwFileSize-j, nValue, 5) ;       // j is offset here
        if (offs2!=0) {
            pFBuf += offs2 ; j += offs2 ; fprintf( stream, "#") ;
            if (*(pFBuf+8)==1) {
                bUV= true ;
                //fprintf( stream, "sig 07000000 at %lx\n", j) ;
                offs2= 0 ; addrUV= j + 17 ;
                fprintf( stream, "verts at %lx\n", addrV) ;
            }
            else bUV= false ;
        }
    if (!bUV) chMB("UVs not found!") ;
    else {
           pFBuf += 13 ; j += 13 ;            // advance to UVs blocksize, DWord
           GetDW(pFBuf, j, uvCnt, false) ; uvCnt = uvCnt/8 ;
           if (uvCnt!=vCnt) chMB("uv cnt doesn't match vCnt!") ;
           logUVs(addrUV, vCnt, 8) ;
    }
}

void SM_of_Skyforge_loop(HWND hwnd, char szPathname[], DWORD dwStart)
{
   char * pFBuf, *pTmp ;            // , szNo[4]
   BYTE vStride= 24 ;     			// stride autoset now
   int cnt= 0, i, ii, SMcnt, nValue[16] ;
   //WORD wFaceIndCnt, wVertsCnt, wOffs2VBlock ;         //
   DWORD FIaddr_arr[999], FIcnt=0, FIcnt_arr[999], vCnt, vCnt_arr[999], vCntSum=0 ;	// uvCnt,
   DWORD minFaceInd = 16777215, maxFaceInd = 0, lastFaceInd=0, startFI ;
   DWORD addrV, offs2 ;  //
   DWORD j=0 ;
   //bool bStop= false, bUV ;

   //chMB("vStride is 24 atm") ;
   pFBuf = (char *) lpFBuf ; pTmp= pFBuf ;
   dwStart = 0 ; pFBuf += dwStart ;            //Triangles 54 72 69 61 Positions  50 6F 73 69
   SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " creating obj:") ;
   cnt = 0 ;
   nValue[0]= 0; nValue[1]= 0; nValue[2]= 1; nValue[3]= 0; nValue[4]= 2; //nValue[5]= 0;    // 0000 0100 02
   do {
        offs2 = FindBytes(lpFBuf, j, dwFileSize-j, nValue, 5) ;       // j is offset here
        if (offs2!=0) {
            pFBuf += offs2 ; j += offs2 ; fprintf( stream, "#") ;
            FIaddr_arr[cnt]= j ; if (cnt<511) cnt++ ; else chMB("Too many submeshes!") ;
            fprintf( stream, "%lx\n", j) ;
            pFBuf += 6 ; j += 6 ;
        }
   } while ((offs2!=0)&&(j<dwFileSize)) ;
   FIaddr_arr[cnt] = dwFileSize ;               // but not sure if every Geometry.bin file has FIs 'til their ending!
   SMcnt = cnt ; fprintf( stream, "#") ;
   for (i=0;i<SMcnt;i++) {
       FIcnt_arr[i] = (FIaddr_arr[i+1]-FIaddr_arr[i]) / 2 ;
            fprintf( stream, "%lu, ", FIcnt_arr[i]) ;
       FIcnt += FIcnt_arr[i] ;
   }
   pFBuf= pTmp ; pFBuf += 4 ;
   GetDW(pFBuf, j, vCnt, false) ;       // vCnt is size of the vertex block here; pFBuf increased

   fprintf( stream, "\n# vCnt?: %ld, FIs %ld\n", vCnt/vStride/3, FIcnt) ;

   addrV = 8 ; startFI = 0; i= 0 ;
    // erster Durchlauf zur Bestimg des ersten vertex
   	//fflush(stream) ;
   for (ii=0;ii<SMcnt*3;ii++) {
        i = ii / 3 ;
        if ((ii % 3)==0) {
            fprintf( stream, "# FIaddr: %lx, %lu\n", FIaddr_arr[i], FIcnt_arr[i]) ;
            log_FIs(stream, FIaddr_arr[i], minFaceInd, maxFaceInd, lastFaceInd, FIcnt_arr, i, false) ;
            vCnt_arr[i] = lastFaceInd - startFI ; startFI = lastFaceInd ;
        }
   }
   for (i=0;i<SMcnt;i++) vCntSum += vCnt_arr[i] ;
   vStride = (BYTE) (vCnt / vCntSum / 3) ;
   for (ii=0;ii<SMcnt*3;ii++) {
        i = ii / 3 ;
        if ((ii % 3)==0) {
            fprintf( stream, "# vAddr: %lx, %lu\n", addrV, vCnt_arr[i]) ;
            log_short_Verts(addrV, vCnt_arr[i], vStride) ;          // vertex stride: 24
            log_short_UVs(addrV+8, vCnt_arr[i], vStride) ;
        }
        addrV += vCnt_arr[i]*vStride ;
        fprintf( stream, "# [%d] v end: %lx, vStride: %d\n", ii, addrV, vStride) ;
   }

}

void SM_of_Skyforge_loop_vhm(HWND hwnd, char szPathname[], DWORD dwStart)
{
   char * pFBuf, *pTmp ;            // , szNo[4]
   //BYTE vStride= 24 ;     			// stride autoset now
   int cnt= 0, i, nValue[16] ;  // SMcnt,
   //WORD wFaceIndCnt, wVertsCnt, wOffs2VBlock ;         //
   DWORD FIcnt=0, n, n1, vCnt ;
   //DWORD FIaddr_arr[999], FIcnt_arr[999], vCnt_arr[999], vCntSum=0 ;	// uvCnt,
   //DWORD minFaceInd = 16777215, maxFaceInd = 0, lastFaceInd=0, startFI ;
   DWORD addrV, offs2 ;  //
   DWORD j=0, jTmp ;
   //bool bStop= false, bUV ;

   //chMB("vStride is 24 atm") ;
   pFBuf = (char *) lpFBuf ; pTmp= pFBuf ;
   dwStart = 0 ; pFBuf += dwStart ;            //
   if (*pFBuf!=0x43) chMB("This doesn't seem to be a vhm file!") ;
   SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " creating obj:") ;
   cnt = 0 ;
   nValue[0]= 1; nValue[1]= 0; nValue[2]= 0; nValue[3]= 0;     // 01000000
   do {
        offs2 = FindBytes(lpFBuf, j, dwFileSize-j, nValue, 4) ;       // j is offset here
        if (offs2!=0) {
            pFBuf += offs2 ; j += offs2 ;
            pTmp= pFBuf -32 ; jTmp= j - 32 ;
            GetDW(pTmp, jTmp, vCnt, false) ;
            GetDW(pTmp, jTmp, FIcnt, false) ; FIcnt *= 3 ;
                //fprintf( stream, "#%lx\n", j) ;
            i=0 ; n1=1 ;
            if (j==0x2996)          // 2a6e, 30dc6
                i = 2*i-i ;
            pFBuf += 20 ; j += 20 ;
                do {
                    n= n1 ; i++ ;
                    GetDW(pFBuf, j, n1, false) ;    // j + 4!
                    pFBuf += 16 ; j += 16 ;
                        //fprintf( stream, "# %d", n1) ;
                } while (n1==n+1) ;
                addrV = j -20 ;         // weil 20 zu weit gelooped
            //if (cnt<511) cnt++ ; else chMB("Too many submeshes!") ;
            if (i>1) {
                cnt++ ;
                fprintf( stream, "# %d. %lx %ld, FIcnt: %ld (%lx or %lx)\n", cnt, addrV, vCnt, FIcnt, addrV+vCnt*32, addrV+vCnt*36) ;
            }
            else { pFBuf -= 36 ; j -= 36 ; }
        }
        //fprintf( stream, "\n") ;
   } while ((offs2!=0)&&(j<dwFileSize)) ;
   fprintf( stream, "# %d", cnt) ;

}

DWORD check_count(DWORD dwStart)
{
   char * pFBuf ;
   int nValue[6] ;
   DWORD cnt, offs2 ;

   pFBuf = (char *) lpFBuf ;

   fprintf( stream, "# 0x%lx ", dwStart) ;

   nValue[0]= 1; nValue[1]= 0; nValue[2]= 0; nValue[3]= 0; nValue[4]= 4;        // "01 00000004" before DW cnt

        offs2 = FindBytes(lpFBuf, dwStart, dwFileSize-dwStart, nValue, 5) ;     // dwStart is offset here
        if (offs2!=0) {
            dwStart += offs2 +5 ; pFBuf += dwStart ;
            GetDW(pFBuf, dwStart, cnt, true) ; fprintf( stream, "# {%x} ", *pFBuf&255) ;
            if ((*pFBuf!=3)&&(*pFBuf!=1)) return 0 ;    // 3 bei verts, 1 bei FIs
            else return cnt ;
        }
        else return 0 ;
}

void SM_of_SHeroGen_loop(HWND hwnd, char szPathname[], DWORD dwStart)
{
   char * pFBuf, *pTmp, *pTmp1 ;            // , szNo[4]
   int cnt= 0, cntUV01=0, cntUV01_max, i, ii, SMcnt, nValue[16] ;

   //WORD wFaceIndCnt, wVertsCnt, wOffs2VBlock ;         //
   DWORD UV01cnt_arr[999], UV01addr_arr[999], Vaddr_arr[999], vCnt, vCnt_arr[999], vCnt_addr[999] ;
   DWORD FIaddr_arr[999], FIcnt=0, FIcnt_arr[999], FIcnt_addr[999], minFaceInd = 16777215, maxFaceInd = 0, lastFaceInd=0 ;     // , startFI
   DWORD addrV, jOld, offs2, vSum=0 ;  //
   DWORD j=0, chkCnt ;
   //float *pFloat ;
   //float fData = 0.0f;      // 55 76 73 Uvs
   bool bFound= false ;

   pFBuf = (char *) lpFBuf ; pTmp= pFBuf ;
   dwStart = 0 ; pFBuf += dwStart ;            //
   SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " creating obj:") ;
   cnt = 0 ;
   nValue[0]= 0x2D; nValue[1]= 0x6D; nValue[2]= 0x65; nValue[3]= 0x73; nValue[4]= 0x68; nValue[5]= 0;    // -mesh: 2D 6D 65 73 68
   do {
        offs2 = FindBytes(lpFBuf, j, dwFileSize-j, nValue, 6) ;       // j is offset here
        if (offs2!=0) {
            pFBuf += offs2 ; j += offs2 ;
            Vaddr_arr[cnt]= j ; if (cnt<511) cnt++ ; else chMB("Too many submeshes!") ;
            fprintf( stream, "# %lx\n", j) ;
            pFBuf += 6 ; j += 6 ;
        }
   } while ((offs2!=0)&&(j<dwFileSize)) ;
   SMcnt = cnt ;
   // UV01 blocks, vertices!?
   pFBuf= pTmp ; cntUV01 = 0 ; j = 0 ;
   nValue[0]= 0x75; nValue[1]= 0x76; nValue[2]= 0x30; nValue[3]= 0x31; nValue[4]= 0;    // uv01 00
   do {
        offs2 = FindBytes(lpFBuf, j, dwFileSize-j, nValue, 5) ;       // j is offset here
        if (offs2!=0) {
            pFBuf += offs2 ; j += offs2 ; pTmp1= pFBuf ; i= 0 ;
            while ((!bFound)&&(i<256)) {        // just a random range, > 80 bytes, though
                while ((*pTmp1!=0x0C)&&(i<256)) { pTmp1++ ; i++ ; }
                if (i<256) bFound = ((*(pTmp1-4)==1)&&(*(pTmp1+94)==0x0C)) ; // Problem: 0C found, but i= 75 for example
                pTmp1++ ; i++ ;
            }
            if (bFound) {            // sig 01 0000000C ?
                bFound = false ;
                UV01addr_arr[cntUV01]= j + i ;      // start vertex block
                UV01cnt_arr[cntUV01] = check_count(UV01addr_arr[cntUV01]) ;
                fprintf( stream, "# UV01 0x%lx (%ld)\n", UV01addr_arr[cntUV01], UV01cnt_arr[cntUV01]) ;
                if (cntUV01<511) cntUV01++ ; else chMB("Too many UV01 submeshes!") ;
            }
            pFBuf += 5 ; j += 5 ;
        }
   } while ((offs2!=0)&&(j<dwFileSize)) ;
   pFBuf= pTmp ; cnt = 0 ; j = 0 ; fprintf( stream, "# FIs at:\n") ;
   nValue[0]= 0; nValue[1]= 0; nValue[2]= 0; nValue[3]= 1; nValue[4]= 0; nValue[5]= 2;    // 0000 0001 0002, big endian
   do {
        offs2 = FindBytes(lpFBuf, j, dwFileSize-j, nValue, 6) ;       // j is offset here
        if (offs2!=0) {
            pFBuf += offs2 ; j += offs2 ;
            FIaddr_arr[cnt]= j ; if (cnt<511) cnt++ ; else chMB("Too many FI blocks!") ;
                fprintf( stream, "# 0x%lx\n", j) ;
            pFBuf += 6 ; j += 6 ;
        }
   } while ((offs2!=0)&&(j<dwFileSize)) ;
   if (SMcnt+cntUV01 != cnt) {
        chMB("SM count and FIs block count are different!\nSome SM may be missing.\n\nTrying auto correction!") ;
        fprintf( stream, "# SM count and FIs block count are different!\nSome SM may be missing. %d != %d\n", SMcnt+cntUV01, cnt) ;
   }

   for (i=0;i<SMcnt;i++) {              // backward search for counts
        pFBuf= pTmp ; pFBuf += Vaddr_arr[i] ; addrV = Vaddr_arr[i] ;
        bFound = false ;
        do {
            while (*pFBuf!=4) {
                pFBuf-- ; addrV-- ;
            }
            bFound = ((*(pFBuf-4)==1)&&(*(pFBuf-9)==4)&&(*(pFBuf-13)==1)) ;
            pFBuf-- ; addrV-- ;
        } while (!bFound) ;
        pFBuf -= 16 ; addrV -= 16 ; vCnt_addr[i]= addrV ;
        GetDW(pFBuf, addrV, vCnt, true) ;                       // get vertex count
        vCnt_arr[i]= vCnt ;
		pFBuf += 5 ; addrV += 5 ; FIcnt_addr[i]= addrV ;
        GetDW(pFBuf, addrV, FIcnt, true) ;                      // get FIcnt
        FIcnt_arr[i] = FIcnt ;
        fprintf( stream, "#%d vCnt: %ld (at 0x%lx), FIcnt: %ld (at 0x%lx)\n", i, vCnt, vCnt_addr[i], FIcnt, addrV-4) ;  //
   }
   fprintf( stream, "\n# start of vertices\n") ;
   for (i=0;i<SMcnt;i++) {
        nValue[0]= 1; nValue[1]= 0; nValue[2]= 0; nValue[3]= 0; nValue[4]= 0x0C;     // 01 000000 0C
        j = Vaddr_arr[i] ; jOld = j ;

            offs2 = FindBytes(lpFBuf, j, dwFileSize-j, nValue, 5) ;       // j is offset here
            if (offs2!=0) {
                j += offs2 + 5 ; Vaddr_arr[i]= j ;
                fprintf( stream, "#%d %lx\n", i, j) ;
            }
        if ((offs2==0)||(j> jOld+0x50)) {
            SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " error with vAddr, mesh is faulty!") ;
            fprintf( stream, "# error with vAddr, mesh is faulty! %lx\n", j) ;
        }
   }
   for (i=0;i<SMcnt;i++) {                                                 // correction of counters
        chkCnt= check_count(Vaddr_arr[i]) ;
        if ((chkCnt!=0)&&(chkCnt!=vCnt_arr[i])) {
            offs2= Vaddr_arr[i]+chkCnt*94 ; pFBuf= pTmp ; pFBuf += offs2 -5 ;  // Ende vertex buffer
            fprintf( stream, "# correction: vCnt[%d] %ld -> %ld\n", i, vCnt_arr[i], chkCnt) ;
            if ((*pFBuf!=1)&&(*(pFBuf+4)!=4)) fprintf( stream, "Error with 1/4 sig at end of vertex block!") ;
            vCnt_arr[i]= chkCnt ;
        }
        chkCnt= check_count(FIaddr_arr[i]) ; fprintf( stream, "%ld\n", chkCnt) ;
        if ((chkCnt!=0)&&(chkCnt!=FIcnt_arr[i])) {
                //fprintf( stream, "# [%d] 0x%lx ", i, FIaddr_arr[i]) ;
            offs2= FIaddr_arr[i]+chkCnt*2 ; pFBuf= pTmp ; pFBuf += offs2 ;  // Ende FI buffer
            fprintf( stream, "# correction: FIcnt[%d] %ld -> %ld [%lx - %lx]", i, FIcnt_arr[i], chkCnt, FIaddr_arr[i], offs2) ;
            if ((*pFBuf!=1)&&(*(pFBuf+4)!=4)) fprintf( stream, "Error with 1/4 sig at FIs' end!") ;
            fprintf( stream, "\n") ;
            FIcnt_arr[i]= chkCnt ;
        }
        fprintf( stream, "\n") ;
   }
   for (i=SMcnt;i<SMcnt+cntUV01;i++) {  // handling last FI blocks
       chkCnt= check_count(FIaddr_arr[i]) ; fprintf( stream, "%ld\n", chkCnt) ;
       if ((chkCnt!=0)&&(chkCnt!=FIcnt_arr[i])) {
            offs2= FIaddr_arr[i]+chkCnt*2 ; pFBuf= pTmp ; pFBuf += offs2 ;  // Ende FI buffer
            fprintf( stream, "# correction: FIcnt[%d] %ld -> %ld [%lx - %lx]", i, FIcnt_arr[i], chkCnt, FIaddr_arr[i], offs2) ;
            if ((*pFBuf!=1)&&(*(pFBuf+4)!=4)) fprintf( stream, "Error with 1/4 sig at FIs' end!") ;
            fprintf( stream, "\n") ;
            FIcnt_arr[i]= chkCnt ;
        }
        fprintf( stream, "\n") ;
   }

   for (i=0;i<SMcnt;i++) vSum += vCnt_arr[i] ;
   for (i=0;i<cntUV01;i++) vSum += UV01cnt_arr[i] ;
   vSumGlob= vSum ;         // for log_FIsBigE()
   cntUV01_max= cntUV01 ; UV01addr_arr[cntUV01]= 0xFFFFFFF  ; cntUV01 = 0 ;  // important; SMcnt += cntUV01 ; nope, too umst�ndlich
   //startFI = 0;
   //for ( i = 5 ; i-- > 0 ; ) fprintf( stream, "%d ", i) ;     // 4..0
   ii= 0 ;
   for (i=0;i<SMcnt;i++) {
                //fprintf( stream, "# nerv %d vAddr: %lx - %lx\n", i, Vaddr_arr[i], UV01addr_arr[cntUV01]) ;
        if (Vaddr_arr[i]<UV01addr_arr[cntUV01]) {
            fprintf( stream, "# %d vAddr: %lx, %ld\n", i, Vaddr_arr[i], vCnt_arr[i]) ;
            Vertex12(stream, Vaddr_arr[i], vCnt_arr[i], 94, true) ;          // vertex stride: 94
            log_UVsBE(Vaddr_arr[i]+17, vCnt_arr[i], 94) ;
            fprintf( stream, "# FIs %d (%d) FIaddr: %lx - %ld\n", ii, i, FIaddr_arr[ii], FIcnt_arr[ii]) ;
            log_FIsBigE(stream, FIaddr_arr[ii], minFaceInd, maxFaceInd, lastFaceInd, FIcnt_arr, ii) ;
        }
        else {
            fprintf( stream, "# UV01Addr: %lx, %ld\n", UV01addr_arr[cntUV01], UV01cnt_arr[cntUV01]) ;
            Vertex12(stream, UV01addr_arr[cntUV01], UV01cnt_arr[cntUV01], 94, true) ;          // vertex stride: 94
            log_UVsBE(UV01addr_arr[cntUV01]+17, UV01cnt_arr[cntUV01], 94) ;
            fprintf( stream, "# uv01 FIs %d (%d) FIaddr: %lx - %ld\n", ii, i, FIaddr_arr[ii], FIcnt_arr[ii]) ;
            log_FIsBigE(stream, FIaddr_arr[ii], minFaceInd, maxFaceInd, lastFaceInd, FIcnt_arr, ii) ;
            if (cntUV01<cntUV01_max) cntUV01++ ;
            i-- ; // tricky!
        }
            //addrV += vCnt_arr[i]*94 ;
        ii++ ;
            //vCnt_arr[i] = lastFaceInd - startFI ;
        //startFI = lastFaceInd ;
   }
   fprintf( stream, "# v end: %lx, vsum: %ld\n", addrV, vSum) ;
}

void SM_of_Kao_loop(HWND hwnd, char szPathname[], DWORD dwStart)
{
   char * pFBuf ;            // , szNo[4]
   //BYTE cnt= 0, i, SMcnt ;
   //int nValue[16] ;
   //WORD wFaceIndCnt, wVertsCnt, wOffs2VBlock ;         //
   //DWORD FIcnt=0, uvAddr_arr[999], uvCnt, vCnt ;
   DWORD FIaddr_arr[999], FIcnt_arr[999], Vaddr_arr[999], vCnt_arr[999] ;
   DWORD minFaceInd = 16777215, maxFaceInd = 0, lastFaceInd=0 ; // , startFI
   //DWORD addrFI=0, addrUV, addrV, jOld, lastJ, offs2 ;  //
   //DWORD j=0 ;
   //float *pFloat ;
   //float fData = 0.0f;      // 55 76 73 Uvs
   //bool bStop= false, bFound= false ;

   pFBuf = (char *) lpFBuf ;
   dwStart = 0 ; pFBuf += dwStart ;
   if ((*pFBuf!=0x54)&&(*(pFBuf+3)!=0x64)) {
        chMB("This doesn't seem to be a Kao T83d file!") ; return ;          //
   }
   SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " creating obj (snowman ONLY!):") ;

   fprintf( stream, "\n# start of vertices\n") ;

   //startFI = 0;
   Vaddr_arr[0]= 0x1970 ; vCnt_arr[0]= 234 ;        //
   FIaddr_arr[0]= 0xD0 ; FIcnt_arr[0]= 1576 ;       //
//   for (i=0;i<SMcnt;i++) {
        fprintf( stream, "# vAddr: %lx, %ld\n", Vaddr_arr[0], vCnt_arr[0]) ;
        Vertex12(stream, Vaddr_arr[0], vCnt_arr[0], 16, false) ;          // vertex stride: 94
        //log_UVsBE(Vaddr_arr[i]+17, vCnt_arr[i], 94) ;
        log_FIs_Kao(stream, FIaddr_arr[0], minFaceInd, maxFaceInd, lastFaceInd, FIcnt_arr, 0) ;
        //vCnt_arr[i] = lastFaceInd - startFI ;
        //startFI = lastFaceInd ;
//   }
   //fprintf( stream, "# v end: %lx\n", addrV) ;
}

void SM_of_Scion_loop(HWND hwnd, char szPathname[], DWORD dwStart)
{
   char * pFBuf, *pTmp ;            // , szNo[4]
   char * pStart ;
   BYTE nerv ;
   int cnt= 0, FFcnt= 0, i, SMcnt ;
   int ch ='\\' ;
   int nValue[16] ;
   //WORD wFaceIndCnt, wVertsCnt, wOffs2VBlock ;         //
   DWORD FIaddr_arr[999], FIcnt=0, FIcnt_arr[999], Vaddr_arr[999], vCnt, vCnt_arr[999] ;
   DWORD minFaceInd = 16777215, maxFaceInd = 0, lastFaceInd=0 ;             // , startFI
   DWORD addrFI=0, addrV, dum=0, offs2, precalc= 0, vCnt_sum=0, vCnt_tmp ;  //
   DWORD j=0 ;
   //float *pFloat ;
   //float fData = 0.0f;      // 55 76 73 Uvs
   bool bIsFF ;

   pFBuf = (char *) lpFBuf ; pTmp= pFBuf ;

   SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " creating obj from 101.YOM:") ;
   SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " change vStart (156a) for other YOMs!") ;
   SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " ") ;
   SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " may need corrections in source:") ;
   SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " adding unrecognized FI blocks") ;

   pStart = strrchr(szFileNameG, ch) ;  		// '\' suchen, ext abtrennen; pour le .obj file
    //if (pStart!= NULL) *pStart= 0 ;
   strcpy(szFileNameG, pStart+1) ;              // Filename without path

   cnt = 0 ;
   nValue[0]= 0; nValue[1]= 0; nValue[2]= 1; nValue[3]= 0; nValue[4]= 2; //nValue[5]= 0;    // 0000 0100 02
   do {
        offs2 = FindBytes(lpFBuf, j, dwFileSize-j, nValue, 5) ;       // j is offset here
        if (offs2!=0) {
            pFBuf += offs2 ; j += offs2 ;
            FIaddr_arr[cnt]= j ;
            if (cnt==65) {      // correction:
                if (strcmp("101.YOM", szFileNameG)==0)  {
                    cnt++ ;     //  >>> adding unrecognized FI block
                    FIaddr_arr[cnt]= 0x546FE ;
                }
            }
            if (cnt==348) {      // correction:
                if (strcmp("101_type2.YOM", szFileNameG)==0)    //
                    if (FIaddr_arr[cnt]==0x24ac44) FIaddr_arr[cnt]= 0x24AB54 ;  // change address
            }
                //fprintf( stream, "#%lx\n", j) ;
            if (cnt<997) cnt++ ; else chMB("Too many submeshes!") ;
            pFBuf += 6 ; j += 6 ;
        }
   } while ((offs2!=0)&&(j<dwFileSize)) ;
   SMcnt = cnt ; fprintf( stream, "\n# %d SMs\n", cnt) ;
   for (i=0;i<SMcnt;i++) {                      // reading the face index counts, DWs
       pFBuf = pTmp ; addrFI = FIaddr_arr[i] - 4  ;
       pFBuf += addrFI ;
       GetDW(pFBuf, addrFI, FIcnt, false) ;     // ret addrFI += 4
       if (FIcnt==0) {                          // corrections
           addrFI -= 6 ; FIaddr_arr[i] -= 2 ;
           pFBuf = pTmp ; pFBuf += addrFI ;
           GetDW(pFBuf, addrFI, FIcnt, false) ;
       }
       else if (FIcnt==65536) {
           addrFI -= 12 ; FIaddr_arr[i] -= 8 ;
           pFBuf = pTmp ; pFBuf += addrFI ;
           GetDW(pFBuf, addrFI, FIcnt, false) ;
       }
       if (FIcnt>150000) {
            chMB("FI count too big. Mesh cut!") ;
            SMcnt= i ;
       }
       else FIcnt_arr[i] = FIcnt ;
       fprintf( stream, "# %d. %lx %ld\n", i, addrFI, FIcnt) ;
   }

   pFBuf= pTmp ; cnt = 0 ; j = 0 ; fprintf( stream, "# offset search:\n") ;
   nValue[0]= 0; nValue[1]= 0; nValue[2]= 0; nValue[3]= 0xff; // 00 00 00 FF
   do {
        offs2 = FindBytes(lpFBuf, j, dwFileSize-j, nValue, 4) ;       // j is offset here
        if (offs2!=0) {
            pFBuf += offs2 ; j += offs2 ; FFcnt= 0 ;
            //GetDW(pFBuf, dum, precalc, false) ;     // precalc gets count (DW before FF block)
            if   (j>0x2615B0)    //   (j>0x25e040)             // 2608d0
                j = j+j-j ;
            do {
                nerv = (*(pFBuf+3))&255 ;
                bIsFF= (nerv==0xFF) ; //fprintf( stream, "%lx ", nerv) ;
                if (bIsFF) {
                    if ((*(pFBuf)==0)&&(*(pFBuf+1)==0)) {       // &&(*(pFBuf+2)==0), 00 (00) xx FF ist auch ein Block
                        FFcnt++ ; pFBuf += 4 ; j += 4 ;
                    }
                    else bIsFF= false ;
                }
            }
            while (bIsFF==true) ;
            if (FFcnt>1) {
                fprintf( stream, "# %d. 0x%lx %d ", cnt, j-4*FFcnt, FFcnt) ;
                cnt++ ;
                GetDW(pFBuf, dum, precalc, false) ;
                if ((*(pFBuf+4)==0)&&(*(pFBuf+5)==0)&&(*(pFBuf+6)==0)&&(*(pFBuf+7)==0)) {
                    fprintf( stream, " -> %ld", precalc) ;
                }
                pFBuf -= 4 ;
                fprintf( stream, "\n") ;
            }
                    //offAddr_arr[cnt]= j -2 -FFcnt ;
                    //Vertex12(stream, offAddr_arr[cnt]-52, 1, 12, false) ;
                    //if (cnt<2997) cnt++ ; else chMB("Too many FF blocks!") ;

                //fprintf( stream, "#      %lx (%d) %d\n", j-2-FFcnt, precalc, FFcnt+1) ;

                //fprintf( stream, "\n") ;
            pFBuf += 3 ; j += 3 ;
        }
   } while ((offs2!=0)&&(j<dwFileSize)) ;
   //fprintf( stream, "\n# start of vertices\n") ;

   //startFI = 0;
   Vaddr_arr[0]= dwStart ; //vCnt_arr[0]= 192 ;

   for (i=0;i<SMcnt;i++) {
        log_FIs(stream, FIaddr_arr[i], minFaceInd, maxFaceInd, lastFaceInd, FIcnt_arr, i, false) ;
        //startFI = lastFaceInd ;
        vCnt_arr[i] = gvCnt_arr[i] ;
        // check vertex count (DW)
        addrV = Vaddr_arr[i] - 12 ;        // pointing to vCount DW of CURRENT SM
        pFBuf = pTmp + addrV ;
        GetDW(pFBuf, addrV, vCnt, false) ;  // returns pFBuf += 4!
        vCnt_tmp = vCnt ;
        if (vCnt_arr[i]!=vCnt) {
            pFBuf -= 16 ; addrV -= 16 ;
            GetDW(pFBuf, addrV, vCnt, false) ;
        }
        if (vCnt==0) vCnt = vCnt_tmp ;
        if (vCnt_arr[i]!=vCnt) {
            fprintf( stream, "# error vertex counts (calc versa file): %lu != %lu\n", vCnt_arr[i], vCnt) ;
            //if (vCnt<128000) vCnt_arr[i] = vCnt ;
        }
        vCnt_sum += vCnt_arr[i] ;
        fprintf( stream, "# (%lx) vAddr: %lx, %lu\n", precalc, Vaddr_arr[i], vCnt_arr[i]) ;
        Vertex12(stream, Vaddr_arr[i], vCnt_arr[i], 32, false) ;          // vertex stride: 32
        logUVs(Vaddr_arr[i]+24, vCnt_arr[i], 32) ;
        // calculate vertex address of next SM
        Vaddr_arr[i+1] = FIaddr_arr[i] + FIcnt_arr[i]*2 + 36 ; precalc= Vaddr_arr[i+1] ;
        pFBuf = pTmp + Vaddr_arr[i+1] ;
        if ((*(pFBuf-1)!=0)&&(*(pFBuf-2)!=0)) {
            pFBuf -= 22 ;
            if ((*pFBuf==0)&&(*(pFBuf+1)==0))
            if ((*(pFBuf-1)==1)||(*(pFBuf-1)==0)) Vaddr_arr[i+1] -= 12 ;   // start correction
        }
   }
   fprintf( stream, "# vertex sum: %ld\n", vCnt_sum) ;
}

void SM_of_GodSummoner_loop(HWND hwnd, char szPathname[], DWORD dwStart)
{
   char * pFBuf ;            // ,szNo[4], *pTmp
   char * pStart ;
   BYTE o_type=99 ;                   // 0: .sm, 1: .skin
   int cnt= 0, i, SMcnt ;             // FFcnt= 0,
   int ch ='\\' ;
   int nValue[16] ;
   //WORD wFaceIndCnt, wVertsCnt, wOffs2VBlock ;         //
   DWORD FIaddr_arr[199], FIcnt=0, FIcnt_arr[199], vCnt_arr[199] ;  // , Vaddr_arr[199], vCnt
   DWORD minFaceInd = 16777215, maxFaceInd = 0, lastFaceInd=0 ;             // , startFI
   DWORD addrV, offs2, vCnt_max=0 ;  //addrFI=0, dum=0, precalc= 0, vCnt_tmp
   DWORD j=0 ;
   //float *pFloat ;
   //float fData = 0.0f;      // 55 76 73 Uvs
   //bool bIsFF ;

   pFBuf = (char *) lpFBuf ; //pTmp= pFBuf ;

   if (*pFBuf==0x32) {
       if (*(pFBuf+2)==0x53) o_type=0 ;
       else if (*(pFBuf+3)==0x53) o_type=1 ;
       else { chMB("This doesn't seem to be a God Summoner sm or skin file!") ; return ; }
   }
   else { chMB("This doesn't seem to be a God Summoner sm or skin file!") ; return ; }
   SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " creating obj from *.sm/skin:") ;
   //SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " change vStart (30) for other sm s!") ;
   SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " ") ;
   //SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " may need corrections in source:") ;
   //SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " adding unrecognized FI blocks") ;

   pStart = strrchr(szFileNameG, ch) ;  		// '\' suchen, ext abtrennen; pour le .obj file
    //if (pStart!= NULL) *pStart= 0 ;
   strcpy(szFileNameG, pStart+1) ;              // Filename without path

   pFBuf += 8 ; j += 8 ;                        // get the SIG/whatever
   cnt = 0 ;
   nValue[0]= *pFBuf&255; nValue[1]= *(pFBuf+1)&255; nValue[2]= *(pFBuf+2)&255; nValue[3]= *(pFBuf+3)&255;
   pFBuf += 4 ; j += 4 ;        // skip the 4 bytes
   do {
        offs2 = FindBytes(lpFBuf, j, dwFileSize-j, nValue, 4) ;       // j is offset here
        if (offs2!=0) {
            pFBuf += offs2 +30 ; j += offs2 + 30 ;
            GetDW(pFBuf, j, FIcnt, false) ; FIcnt *= 3 ;              // each face has 3 FIs
            FIcnt_arr[cnt]= FIcnt ;
            FIaddr_arr[cnt]= j ;        fprintf( stream, "\n# 0x%lx %lu\n", j, FIcnt) ;   // face indices count
            if (cnt<197) cnt++ ; else chMB("Too many submeshes!") ;
            pFBuf += 6 ; j += 6 ;   // skip a face at least
        }
   } while ((offs2!=0)&&(j<dwFileSize)) ;
   SMcnt = cnt ; fprintf( stream, "\n# %d SMs\n", cnt) ;
   FImode= 1 ;              // get vertex count
   for (i=0;i<SMcnt;i++) {
        minFaceInd = 16777215; maxFaceInd = 0; lastFaceInd=0 ;
        log_FIs(stream, FIaddr_arr[i], minFaceInd, maxFaceInd, lastFaceInd, FIcnt_arr, i, true) ;
        vCnt_arr[i]= gvCnt_arr[i] ;
        if (vCnt_arr[i] > vCnt_max) vCnt_max= vCnt_arr[i] ;
   }
   FImode= 0 ;      // restore standard
   addrV= 0x30 ;
   if (o_type==0) {
        log_short_Verts(addrV, vCnt_max, 20) ; log_short_UVs(addrV+16, vCnt_max, 20) ;
   }
   if (o_type==1) {
        log_short_Verts(addrV, vCnt_max, 24) ; log_short_UVs(addrV+12, vCnt_max, 24) ;
   }
   for (i=0;i<SMcnt;i++) {
        minFaceInd = 16777215; maxFaceInd = 0; lastFaceInd=0 ;
        log_FIs(stream, FIaddr_arr[i], minFaceInd, maxFaceInd, lastFaceInd, FIcnt_arr, i, false) ;
        //startFI = lastFaceInd ;
   }
   fprintf( stream, "# overall vertex cnt: %ld\n", vCnt_max) ;
}

void SM_of_SW_BF3_loop(HWND hwnd, char szPathname[], DWORD dwStart)      // scanning the submeshes
{                                                                         // only one model tested
   char * pFBuf, *pTmp, szNo[4] ;
   BYTE fCnt=0, FVFsize= 24 ;        // 24 for Han; others: 20
   int cnt, i, SMcnt ;
   int k, nValue[16] ;
   WORD FI[3], grp_arr[512], grpCnt=0 ;				// cmpCnt=0,
   DWORD FIcnt, FIcnt_arr[999], indexF, vCnt, vCnt_arr[999] ;         //
   DWORD addrUV, addrV, j=0, offs2 ;  // , lastJ, addrUVtmp
   DWORD minFaceInd = 16777215, maxFaceInd = 0, lastFaceInd=0 ;
   //float *pFloat ;
   //float fData = 0.0f;
   //bool bStop= false ;

   pFBuf = (char *) lpFBuf ; pTmp= pFBuf ;
   //dwStart = 0x23BA5 ;                                        // unneeded here
   pFBuf += dwStart ;
   bBigE= true ;                                                // for log_short_Verts() and log_short_UVs()
   SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " creating obj:") ;
/*   nValue[0]= 0x4B; nValue[1]= 0x5F; nValue[2]= 0x53; nValue[3]= 0x54; //  PAC K_ST N
   do {
        offs2 = FindBytes(lpFBuf, j, dwFileSize-j, nValue, 4) ;       // j is offset here
        if (offs2!=0) {
            pFBuf += offs2 - 51 ; j += offs2 - 51 ;
            GetDW(pFBuf, j, addrV, true) ; pFBuf += 16 ; j += 16 ;
            GetDW(pFBuf, j, addrUV, true) ; // j not used here
            fprintf( stream, "# v/uvaddr: 0x%lx, 0x%lx\n", addrV, addrUV) ;
            //if (cnt<999) cnt++ ; else chMB("Too many submeshes!") ;
            pFBuf += 28 ; j += 28 ;
        }
   } while ((offs2!=0)&&(j<dwFileSize)) ;   // keine neuen Adressen
   // 14th find: # v/uvaddr: 0xb2b40, 0xe3690
   */
   nValue[0]= 0x46; nValue[1]= 0x41; nValue[2]= 0x43; nValue[3]= 0x45; nValue[4]= 0;    // 'FACE '
   do {
        offs2 = FindBytes(lpFBuf, j, dwFileSize-j, nValue, 5) ;       // j is offset here
        if (offs2!=0) {
            pFBuf += offs2 ; j += offs2 ; fprintf( stream, "#") ;
            while (*pFBuf== 'F') {
                pFBuf += 16 ; j += 16 ;
                GetDW(pFBuf, j, indexF, true) ; fprintf( stream, " %lu", indexF/4) ;
                grp_arr[grpCnt]= indexF/4 ; if (grpCnt<511) grpCnt++ ; else chMB("Too many groups!") ;
                pFBuf += 4 ; j += 4 ;
            }
            fprintf( stream, "\n# ----------\n") ;
            pFBuf += 6 ; j += 6 ;
        }
   } while ((offs2!=0)&&(j<dwFileSize)) ;

   cnt= 0 ; pFBuf= pTmp; j= 0 ;		//  lastJ= 0 ;
   // get counts of submeshes
   nValue[0]= 0x45; nValue[1]= 0x5F; nValue[2]= 0x4F; nValue[3]= 0x50; // there's counts behind FAC E_OP A
   do {
        offs2 = FindBytes(lpFBuf, j, dwFileSize-j, nValue, 4) ;       // j is offset here
        if (offs2!=0) {
            pFBuf += offs2 - 47 ; j += offs2 - 47 ;
            GetDW(pFBuf, j, vCnt, true) ; GetDW(pFBuf, j, FIcnt, true) ; // j not used here
            vCnt_arr[cnt]= vCnt ; FIcnt_arr[cnt]= FIcnt ; fprintf( stream, "# %lu %lu\n", vCnt, FIcnt) ;
            if (cnt<999) cnt++ ; else chMB("Too many submeshes!") ;
            pFBuf += 40 ; j += 40 ;
        }
   } while ((offs2!=0)&&(j<dwFileSize)) ;
   if (bDbg) fprintf( stream, "# submesh count: %d \n", cnt) ;
    // get counts of last submesh                   // not needed any more because FACE_OPA gets all
/*   offs2 = FindBytes(lpFBuf, j, dwFileSize-j, nValue, 3) ;       // j is offset here
    if (offs2!=0) {
        pFBuf += offs2 + 4 ; j += offs2 + 4 ;
        GetDW(pFBuf, j, vCnt, true) ; GetDW(pFBuf, j, FIcnt, true) ; // j not used here
        vCnt_arr[cnt]= vCnt ; FIcnt_arr[cnt]= FIcnt ; fprintf( stream, "# %d %d\n", vCnt, FIcnt) ;
        pFBuf += 8 ; j += 8 ; cnt++ ;
    } else chMB("Error, last submesh not found!") ; */
    // where's the startaddresses for vertices and uvs?
   nValue[0]= 0x46; nValue[1]= 0x41; nValue[2]= 0x43; nValue[3]= 0x45; nValue[4]= 0;    // 'FACE '
   offs2 = FindBytes(lpFBuf, j, dwFileSize-j, nValue, 5) ;       // j is offset here
    if (offs2!=0) {
        pFBuf += offs2 ; j += offs2 ;                   //
        pFBuf += 8 ; j += 8 ;
    } else chMB("Error, 'FACE ' after last counts not found!") ;    // evtl. erste von 2 'FACE '
   nValue[0]= 0x50; nValue[1]= 0x4F; nValue[2]= 0x53; nValue[3]= 0;     // 'POS '
   offs2 = FindBytes(lpFBuf, j, dwFileSize-j, nValue, 4) ;       // j is offset here
    if (offs2!=0) {
        pFBuf += offs2 -32 ; j += offs2 - 32 ;                   //
        GetDW(pFBuf, j, addrV, true) ; pFBuf += 16 ; j += 16 ;
        GetDW(pFBuf, j, addrUV, true) ; fprintf( stream, "# %lx %lx\n", addrV, addrUV) ;
        pFBuf += 72 ; j += 72 ;
    } else chMB("Error, 'POS ' after 'FACE' not found!") ;
    if (j!=addrV) {
        chMB("address calculation went wrong! break...") ;
        if (bDbg) fprintf( stream, "# addr v, uv: 0x%lx, 0x%lx, curr. addr: 0x%lx\n", addrV, addrUV, j) ;
        //return ;
    }
    SMcnt= cnt ;        // addrV= 0x3600 ;                                                    // set manually; j= 0x3568
    for (i=0;i < SMcnt;i++) {
        fprintf( stream, "# vAddr, cnt: %lx, %ld\n", addrV, vCnt_arr[i]) ;
            //if (addrV==0xb2b28) addrV= 0xb2b40 ;                                            // manual correction
        /*Vertex12( stream, addrV, vCnt_arr[i], FVFsize, true) ;
        addrV += FVFsize*vCnt_arr[i] ;
        if (i==0) {
            addrUVtmp= addrV +16 ; fprintf( stream, "# uvAddr: %lx\n", addrV+16) ;       // +16 set manually
            log_short_UVs(addrUVtmp, vCnt_arr[i], 20) ; addrUVtmp += 4*vCnt_arr[i] ;     // 20 set manually
            addrV += FVFsize*vCnt_arr[i] ;
        }   */
        log_short_Verts(addrV, vCnt_arr[i], FVFsize) ; addrV += FVFsize*vCnt_arr[i] ;
    }
    if (addrV!=addrUV) chMB("UV address calculation went wrong! break...") ; //return ;}
    // go for uvs, blocksize is 4
    //addrUV= 0xE3690 ;
    for (i=0;i < SMcnt;i++) {                                               // i=1, if option if (i==0) is choosen in upper loop
        fprintf( stream, "# uvAddr: %lx\n", addrUV) ;
        log_short_UVs(addrUV, vCnt_arr[i], 4) ; addrUV += 4*vCnt_arr[i] ;
        //log_UVsBE(addrUV, vCnt_arr[i], 16) ; addrUV += 16*vCnt_arr[i] ;     // 16 set manually
    }
    pFBuf= pTmp + addrUV + 40 ; j= addrUV + 40 ; fprintf( stream, "# start of FIs: %lx\n", j) ;
    // go for face indices
    //0x10A640
    for (i=0;i < SMcnt;i++) {
        _itoa(i, szNo, 10) ; fprintf( stream, "g SM_%s\n", szNo) ;      // separating the submeshes (building groups)
            //fprintf( stream, "# FIcnt: %d\n", FIcnt_arr[i]) ;
        for (k=0;k<FIcnt_arr[i];k++) {       //
            if (j==0x11aeac) {
                //pFBuf += 24 ; j += 24 ;
            }
            //               adding lastFaceInd inside fct. gor absolute FIs
            FI[fCnt]= (WORD) GetFaceIndexBigE(pFBuf, j, minFaceInd, maxFaceInd, lastFaceInd, false) ;	// j for count only!
            fCnt++ ;
            if (fCnt==3) {
                fCnt=0 ;
                /*        //fprintf( stream, "s %d. %d %d\n", i, (k+cmpCnt)/3, grp_arr[l]) ;
                    fprintf( stream, "  %d. %d %d\n", i, FI[0], grp_arr[l]) ;
                if (FI[0]>=grp_arr[l]) {          // (k+cmpCnt)/3>)
                    _itoa(l, szNo1, 10) ; fprintf( stream, "g SM_%s_%s\n", szNo, szNo1) ;
                    l++ ;
                }   */
                fprintf( stream, "f %d/%d %d/%d %d/%d\n", FI[0],FI[0],FI[1],FI[1],FI[2],FI[2]) ;
            }
        }
        if (maxFaceInd<lastFaceInd) {
            fprintf( stream, "# error! maxFI %lu < lastFI %lu\n\n", maxFaceInd, lastFaceInd) ;
        }
        else lastFaceInd = maxFaceInd ;         // needed to "convert" relative to absolute face indices
            fprintf( stream, "# %d. maxFI %lu,  lastFI %lu\n\n", i, maxFaceInd, lastFaceInd) ;
        fprintf( stream, "# next FI block: %lx\n", j) ;
            //cmpCnt += FIcnt_arr[i] ;
    }
}

BOOL CheckValue(HWND hwnd)          // returns dwStart (value from editbox)
{
   BOOL bSuccess = FALSE;
   BOOL bErr = false ;      //
   char szText[2][8] ;      //
   char *stopStr ;          //
   signed long slTmp ;
   DWORD dwTextLength;

    GetDlgItemText(hwnd, ID_EDIT, (LPTSTR) szText[0], 8 ) ;
    dwTextLength = strlen(szText[0]) ;
    bErr = (dwTextLength==0) ;
    if (bErr)  {
        chMB("Lower left editbox must contain a value!\n") ; return false ;
    }

    slTmp= strtol(szText[0], &stopStr, 16) ;
    if (slTmp>=0) bSuccess = TRUE;
    else {
        chMB("error!\n enter a positive address") ;
        return false ;
    }
    dwStart = (DWORD) slTmp ;
    if (dwStart<=dwFileSize) bSuccess = TRUE;
    else {
        chMB("error!\n address greater than filesize") ;
        return false ;
    }
   return bSuccess;
}

BOOL DoFileOpenSave(HWND hwnd, BOOL bSave)
{
static char szFilter[] =  "model (*.*)\0*.*\0"
                          "All Files (*.*)\0*.*\0\0" ;

   OPENFILENAME ofn;
   char buffer[10], szFileName[MAX_PATH];

   ZeroMemory(&ofn, sizeof(ofn));
   szFileName[0] = 0;

   ofn.lStructSize = sizeof(ofn);
   ofn.hwndOwner = hwnd;
   ofn.lpstrFile = szFileName;
   ofn.nMaxFile = MAX_PATH;

   ofn.lpstrFilter       = szFilter;
   ofn.lpstrCustomFilter = NULL ;
   ofn.nMaxCustFilter    = 0 ;
   ofn.nFilterIndex      = 1L ;
   ofn.lpstrFile[0] = 0;
   ofn.lpstrTitle = TEXT("*.* open") ;
   ofn.Flags = OFN_EXPLORER | OFN_FILEMUSTEXIST;
   GetOpenFileName(&ofn);
   if (strlen((char *) ofn.lpstrFile)!= 0) {
        dwFileSize = _ReadFile(szFileName, lpFBuf, FALSE, stream) ;      // load the model to static buffer
        if (dwFileSize==0) {
            chMB("error: model file size==0!") ; return FALSE ;
        }
        strcpy(szFileNameG, szFileName) ;
            //strcpy (szErrMess, "error in H20 no: ") ;
        SendDlgItemMessage(hwnd, ID_LIST, LB_RESETCONTENT, 0, 0L);
		bIsDW= false ;          // default
        switch (model) {        // set model in line 28 or make it available via a combo box
            case 1: break ;
            case 2: SetWindowText (GetDlgItem(hwnd, ID_EDIT), "0"); break ;
            case 3: SetWindowText (GetDlgItem(hwnd, ID_EDIT), "30"); break ;
            case 4: SetWindowText (GetDlgItem(hwnd, ID_EDIT), "B5B"); break ;   //
            case 5:
            case 6: break ;   // SetWindowText (GetDlgItem(hwnd, ID_EDIT), "156A");
            case 7: case 8:                                                     //
            case 9: SetWindowText (GetDlgItem(hwnd, ID_EDIT), "0"); break ;
            case 10: if (!CheckValue(hwnd)) {
                        ltoa(dwFileSize,buffer,16);
                        SetWindowText (GetDlgItem(hwnd, ID_EDIT), buffer); }
                        else bFstRun= false ;
                     break ;
            case 11: SetWindowText (GetDlgItem(hwnd, ID_EDIT), "0"); break ;  // get startaddress from Edit1 ?
        }
        //if (CheckValue(hwnd)) {       // check the edit box contents (not required for model 2 so far)
        switch (model) {        // set model in line 28 or make it available via a combo box
            case 1: //SM_of_MLX_loop(hwnd, szFileName) ;
                    SM_of_SW_BF3_loop(hwnd, szFileName, 0) ;
                    EnableWindow(GetDlgItem(hwnd, ID_BUTTON1), TRUE) ;
                    //SetWindowText (GetDlgItem(hwnd, ID_EDIT), "F200");  // 0x10A10: table start in "DL020A_SD002J.MLX"
                    break ;// dwStart from Editbox
            case 2:  SM_of_KR_CW_loop(hwnd, szFileName, 0) ; break ;
            case 3:  SM_of_Skyforge_loop(hwnd, szFileName, 0) ; break ;
            case 4:  SM_of_SHeroGen_loop(hwnd, szFileName, 0) ; break ;
            case 5:  SM_of_Kao_loop(hwnd, szFileName, 0) ; break ;
            case 6:  if (CheckValue(hwnd))
                        SM_of_Scion_loop(hwnd, szFileName, dwStart) ;
                     break ;
            case 7:  SM_of_GodSummoner_loop(hwnd, szFileName, dwStart) ; break ;
            case 8:  break ;  //
            case 9:  break ;  //
            case 10: break ;
            case 11: break ;
        }
        //}
    }
    return (TRUE) ;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam)
{
   static HWND  hwndButt1, hwndEdit ;
   static HWND  hwndCombo1, hwndList ;	// from environ.c
   static RECT  rect ;
   static int   cxChar, cyChar ;
   HDC          hdc ;
   PAINTSTRUCT  ps ;

   switch(Message)
   {
      case WM_CREATE:
           cxChar = LOWORD (GetDialogBaseUnits ()) ;
           cyChar = HIWORD (GetDialogBaseUnits ()) ;

           stream = fopen( FILENAME, "w" );
                if( stream == NULL ) {
                    chMB("<Makeobj_log.obj> creation error!") ;
                    DestroyWindow(hwnd);    // we really shouldn't "meet" the fclose()
                    break ;                 // from WM_CLOSE
                }


         CreateWindow("EDIT", "",
            WS_CHILD | WS_VISIBLE | WS_HSCROLL | WS_VSCROLL | ES_MULTILINE |
               ES_WANTRETURN,
            CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
            hwnd, (HMENU)IDC_MAIN_TEXT, g_hInst, NULL);

         SendDlgItemMessage(hwnd, IDC_MAIN_TEXT, WM_SETFONT,
            (WPARAM)GetStockObject(DEFAULT_GUI_FONT), MAKELPARAM(TRUE, 0)); // GDI32.lib
            hwndList = CreateWindow (TEXT ("listbox"), NULL,
                              WS_CHILD | WS_VISIBLE | LBS_NOTIFY | WS_VSCROLL | WS_BORDER,
                              cxChar, cyChar ,
                              cxChar * 34 + GetSystemMetrics (SM_CXVSCROLL),
                              cyChar * 8,
                              hwnd, (HMENU) ID_LIST,
                              (HINSTANCE) GetWindowLong (hwnd, GWL_HINSTANCE),
                              NULL) ;
			SendDlgItemMessage(hwnd, ID_LIST, LB_RESETCONTENT, 0, 0L); //
   		    SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM) ">>> create obj files <<<") ;
			SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM) " editbox: hex start addr of ...") ;
			SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM) " ") ;
			SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM) " (log file MakeObj_log.obj in project dir)") ;
			SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM) "-------------------------------------------------------") ;

            hwndEdit = CreateWindow (TEXT ("edit"), NULL,
                            WS_CHILD | WS_VISIBLE | WS_BORDER,
                            cxChar+10, cyChar + 134+16 ,
                            10 * cxChar, cyChar,
                            hwnd, (HMENU) ID_EDIT,
                            (HINSTANCE) GetWindowLong (hwnd, GWL_HINSTANCE),
                        NULL) ;

			hwndButt1 = CreateWindow ( TEXT("button"),
                            TEXT ("log table"),         //
                            WS_CHILD | WS_VISIBLE | WS_DISABLED | BS_PUSHBUTTON,
                            cxChar+114, cyChar + 144,        // normal font: 130
                            10 * cxChar, 3 * cyChar / 2,
                            hwnd, (HMENU) ID_BUTTON1,
                        ((LPCREATESTRUCT) lParam)->hInstance, NULL) ;
            hwndCombo1 = CreateWindow (TEXT ("combobox"), NULL,          // model Auswahl combo
                              WS_CHILD | WS_VISIBLE | WS_BORDER | CBS_DROPDOWN,
                              cxChar+220, cyChar + 131+16,       // 170
                              9 * cxChar, 8*cyChar, //
                              hwnd, (HMENU) ID_COMBO1,
                              (HINSTANCE) GetWindowLong (hwnd, GWL_HINSTANCE),
                           NULL) ;
            SendMessage(hwndCombo1, CB_ADDSTRING, 0, (LPARAM) "SW_BF3") ;
            SendMessage(hwndCombo1, CB_ADDSTRING, 0, (LPARAM) "KR_CW") ;
            SendMessage(hwndCombo1, CB_ADDSTRING, 0, (LPARAM) "Skyfo") ;
            SendMessage(hwndCombo1, CB_ADDSTRING, 0, (LPARAM) "SHGen") ;
            SendMessage(hwndCombo1, CB_ADDSTRING, 0, (LPARAM) "Kao") ;
            SendMessage(hwndCombo1, CB_ADDSTRING, 0, (LPARAM) "Scion") ;
            SendMessage(hwndCombo1, CB_ADDSTRING, 0, (LPARAM) "GodSu") ;
            //SendMessage(hwndCombo1, CB_ADDSTRING, 0, (LPARAM) "") ;

            SendDlgItemMessage(hwnd, ID_COMBO1, CB_SETCURSEL, model-1, 0L);

        //SomeFunction("blubb") ;
      break;
      case WM_SIZE:
         //if(wParam != SIZE_MINIMIZED)
           // MoveWindow(GetDlgItem(hwnd, IDC_MAIN_TEXT), 0, 0, LOWORD(lParam),
             //  HIWORD(lParam), TRUE);
      break;
      case WM_PAINT : //return 0 ;
          InvalidateRect (hwnd, &rect, TRUE) ;

          hdc = BeginPaint (hwnd, &ps) ;
          SelectObject (hdc, GetStockObject (SYSTEM_FIXED_FONT)) ;
          SetBkMode (hdc, TRANSPARENT) ;

          //TextOut (hdc, 24 * cxChar, cyChar, szTop, lstrlen (szTop)) ;
          //TextOut (hdc, 24 * cxChar, cyChar, szUnd, lstrlen (szUnd)) ;

          EndPaint (hwnd, &ps) ;
          return 0 ;
      case WM_SETFOCUS:
         SetFocus(GetDlgItem(hwnd, IDC_MAIN_TEXT));
      break;
      case WM_COMMAND:
         switch(LOWORD(wParam))
         {
            case ID_BUTTON1:                    // show_table

                if (CheckValue(hwnd)) {         // editbox -> dwStart
                   SendDlgItemMessage(hwnd, ID_LIST, LB_RESETCONTENT, 0, 0L);
                   SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM) " (You might log here instead") ;
                   SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM) "  to MakeObj_log.obj)") ;
                   if (model==1) show_table(dwStart)  ; // log table to MakeH2O_log.txt
                   else {
                        SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM) " ") ;
                        SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM) " implemented for ... only") ;
                   }
                }
                break ;
            case ID_COMBO1:                             // model/format selection
                //_itoa(wParam/65536, szErrMess, 10) ; fprintf( stream, "%s\n", szErrMess) ;
                //if (wParam/65536==1) chMB("leckmichdochaa") ;
                 if (HIWORD(wParam)==CBN_SELCHANGE) {
                    model = (BYTE) LOWORD( SendDlgItemMessage(hwnd, ID_COMBO1, CB_GETCURSEL, 0, 0L) ) + 1 ;
                        //if (model==x) SetWindowText (GetDlgItem(hwnd, ID_EDIT), "ABCD");    // ABCD, kann vor File load �berschrieben werden
                 }
            break ;

            case CM_FILE_OPEN:
               DoFileOpenSave(hwnd, FALSE);
            break;
            case CM_FILE_SAVEAS:
               //DoFileOpenSaveAs(hwnd, TRUE);
            break;
            //case CM_FORMAT:
               //CheckFormat() ;
            //   chMB("not in use") ;
            break;
            case CM_FILE_EXIT:
               PostMessage(hwnd, WM_CLOSE, 0, 0);
            break;
            case CM_ABOUT:
               //MessageBox (NULL, "Make_H2O\n  by shak-otay 10/15\n \n     Verwendung auf\n      eigene Gefahr!\n (Use it on your own risk!)" , "About...", 0);
			   MessageBox (NULL, "         Make_obj\n    by shak-otay 09/19\n             ver 0.1\n \n     Verwendung auf\n      eigene Gefahr!\n (Use it on your own risk!)", "About...", 0);
            break ;
         }
      break;
      case WM_CLOSE:
         fclose( stream );        // uncomment when log file used
         DestroyWindow(hwnd);
      break;
      case WM_DESTROY:
         PostQuitMessage(0);
      break;
      default:
         return DefWindowProc(hwnd, Message, wParam, lParam);
   }
   return 0;
}


int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
   LPSTR lpCmdLine, int nCmdShow)
{
   WNDCLASSEX WndClass;
   HWND hwnd;
   MSG Msg;

   g_hInst = hInstance;

   WndClass.cbSize        = sizeof(WNDCLASSEX);
   WndClass.style         = 0;
   WndClass.lpfnWndProc   = WndProc;
   WndClass.cbClsExtra    = 0;
   WndClass.cbWndExtra    = 0;
   WndClass.hInstance     = g_hInst;
   WndClass.hIcon         = LoadIcon (hInstance, MAKEINTRESOURCE (5000)) ;//LoadIcon(NULL, IDI_APPLICATION);
   WndClass.hCursor       = LoadCursor(NULL, IDC_ARROW);
   WndClass.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
   WndClass.lpszMenuName  = "MAINMENU";
   WndClass.lpszClassName = g_szClassName;
   WndClass.hIconSm       = LoadIcon (hInstance, MAKEINTRESOURCE (5000)) ;//LoadIcon(NULL, IDI_APPLICATION);

   if(!RegisterClassEx(&WndClass))
   {
      MessageBox(0, "Window Registration Failed!", "Error!",
         MB_ICONEXCLAMATION | MB_OK | MB_SYSTEMMODAL);
      return 0;
   }

   hwnd = CreateWindowEx(
      WS_EX_CLIENTEDGE,
      g_szClassName,
      " Make_obj",
      WS_OVERLAPPEDWINDOW,
      CW_USEDEFAULT, CW_USEDEFAULT, 330, 256,
      NULL, NULL, g_hInst, NULL);

   if(hwnd == NULL)
   {
      MessageBox(0, "Window Creation Failed!", "Error!",
         MB_ICONEXCLAMATION | MB_OK | MB_SYSTEMMODAL);
      return 0;
   }

   ShowWindow(hwnd, nCmdShow);
   UpdateWindow(hwnd);

   while(GetMessage(&Msg, NULL, 0, 0))
   {
      TranslateMessage(&Msg);
      DispatchMessage(&Msg);
   }
   return Msg.wParam;
}


