===========================================================================================

Advanced Mesh Reaper by Bigchillghost
Host: https://forum.xentax.com/viewtopic.php?f=33&t=20995

===========================================================================================


////////////////////////////////////////////////////////////////////////////////////////////

1) Introduction
2) System Requirement
3) Main Features
4) User Interface
5) Notes

////////////////////////////////////////////////////////////////////////////////////////////

======================
1) Introduction
======================

Advanced Mesh Reaper, or AMR for short, is a tool I created when playing around with MFC.
It's aimed to be a quick approach to obtain a couple of meshes with all basic attributes
including positions, normal vectors, texture coordinates, and if necessary, to transform 
them to the target coordinate system without the assistance of extra programing or other 
3D applications.

Though it can be used for format researching purpose, it's not served to be a beginner's tool.
So there're not any step-by-step tutorials on specific formats.

////////////////////////////////////////////////////////////////////////////////////////////

======================
2) System Requirement
======================

Windows XP, Windows 7, Windows 8 or Windows 10 with Visual C++ 2015 redistributable or
newer versions installed.

////////////////////////////////////////////////////////////////////////////////////////////

======================
3) Main Features
======================

1. The Multi Sources mode allows you to specify individual data files as inputs. This can be very
convenient when you have raw data dumped from discrete compressed blocks.
2. Independent routines of handling different mesh elements, which ensures a simple, clean and 
user friendly interface.
3. Complete modules for managing the parameter list to make your work easier and faster.
4. Ability to handle cases where extra data is inserted in polygon indices. This is useful for
files containing combined UV or normal indices.
5. Support of parsing position bounding box to restore the mesh to its in-game scaling.
6. Multiple UV channels support. By exporting to FBX format, the tool allows to export each mesh 
with up to 4 individual UV channels.
7. Flip UV option. It allows to vertically flip the UV so as to map with the textures.
8. Supports for normal vectors of various encodings
9. Transformation options of the model including axis inversion and mesh rotations.
10. Assignment of material groups to polygons.
11. Implicit triangle/triangle strip indices generation.
12. Visulizes meshes, UVs and vertex normals vectors.

////////////////////////////////////////////////////////////////////////////////////////////

======================
4) User Interface
======================

Refer to the AMR Specification.

////////////////////////////////////////////////////////////////////////////////////////////

======================
5) Notes
======================

AMR is using an external mesh viewer called ViewScene to preview the model with different attributes.
It's based on the ViewScene sample program of Autodesk FBX SDK, version 2019.2. I made some modifications
myself to meet with different demands of this project. The main modifications include:
- Added codes for displaying vertex normal vectors;
- Added codes for displaying as point cloud;
- Added codes for displaying shaded wireframe;
- Changed some of the keyboard accelerators, and added a few more to interact with the scene more easily;

Still, the modified ViewScene executable along with its required libaries technically are not a part
of AMR. So they do not come with this release. You should obtain these components from the release page
and place them into the location of the AMR executable.
