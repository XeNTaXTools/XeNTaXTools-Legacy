Double Fine tool

** About this tool
This tool is for games released by Double Fine. This includes unpack/repack tool for archive
files (~h and ~p) and text unpack/repack tool for stringtable files in archives.
The games supported by this tools are:

Costume Quest
Stacking
Iron Brigade

*) This version is not compatible with previous version. Please unpack again if you use this
   new version.

** System requirement
.NET Framework 4.0 or higher version

** How to use DoubleFileTool
 This is unpack/repack tool for ~h and ~p files.

1)Unpack
 DoubleFineTool -u [~h file name for unpack] [folder path for unpacked files]

2)Pack
 DoubleFineTool -p [folder path of unpacked files] [file name for repack (without file extension)]

** How to use TextTool
 This tool is for StringTable files which are unpacked by DoubleFineTool to convert csv.

1)Unpack
 TextTool -g? -u [file name of StringTable] [Csv file]

2)Pack
 TextTool -g? -p [Csv file] [file name of StringTable]

-g option is for game type. This is a necessary option. Current supported games and game
type id are:

1:Stacking
2:Costume Quest
3:Iron Brigade, The Cave

** Change log
2012/01/25 Checked to be compatible with game files of The Cave.
2012/08/23 ver 1.1 Supported Iron Brigade and Texture resources are converted to DDS
2012/05/07 ver 1.0 Initial release
