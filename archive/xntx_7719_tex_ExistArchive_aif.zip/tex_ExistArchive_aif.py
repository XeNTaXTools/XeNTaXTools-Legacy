# Exist Archive (Vita) aif images test Loader by Bigchillghost
from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Exist Archive(Vita)", ".aif")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
	#noesis.logPopup()
	return 1

#check if it's this type based on the data
def noepyCheckType(data):
	bs = NoeBitStream(data)
	Magic = bs.readUInt()
	if Magic != 0x41494620:
		return 0
	return 1
	
def noepyLoadRGBA(data, texList):
	bs = NoeBitStream(data)
	bs.seek(0x1E0, NOESEEK_ABS)
	imgWidth = 128
	imgHeight = 128
	pixelSize = 0x10000
	pixelData = bs.readBytes(pixelSize)
	pixelData = rapi.imageToMortonOrder(pixelData, imgWidth, imgHeight, 4, 1)
	rotData = bytearray(pixelSize)
	idx0 = 0
	idx1 = 0
	for i in range(0, imgWidth):
		for j in range(0, imgHeight):
			idx0 = j * imgWidth * 4 + i*4
			for k in range(0, 4):
				rotData[idx0] = pixelData[idx1]
				idx0 += 1
				idx1 += 1
	pixelData = rapi.imageDecodeRaw(rotData, imgWidth, imgHeight, "b8 g8 r8 a8")
	texFmt = noesis.NOESISTEX_RGBA32
	texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, pixelData, texFmt))
	return 1
