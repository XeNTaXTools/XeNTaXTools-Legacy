from inc_noesis import *
import noesis
import rapi

def registerNoesisTypes():
	handle = noesis.register("Tree of Savior WEB",".3d")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadModel(handle, noepyLoadModel)
	return 1
	
def noepyCheckType(data):
    bs = NoeBitStream(data)
    return 1  

def noepyLoadModel(data, mdlList):
	ctx = rapi.rpgCreateContext()
	bs = NoeBitStream(data)

	bs.seek(0x4, NOESEEK_ABS)
	VCnt = bs.readUShort()
	FCnt = bs.readUShort()
	FVFsize = int(12)
	VBSize = bs.readBytes(VCnt * FVFsize)

	Jump = VCnt * 0x18
	UVoffset = Jump + 8 
	bs.seek(UVoffset, NOESEEK_ABS)
	UVBSize = VCnt * 8
	UVBuff = bs.readBytes(UVBSize)
	rapi.rpgBindUV1BufferOfs(UVBuff, noesis.RPGEODATA_FLOAT, 8, 0)
	rapi.rpgBindPositionBufferOfs(VBSize, noesis.RPGEODATA_FLOAT, FVFsize, 0)

	addr=bs.tell()
	fileBuff = bs.data[addr:bs.dataSize]
	addr1= fileBuff.find(b'\x00\x00\x02\x00')
	addr += addr1
	bs.seek(addr)
	offset= bs.tell()
	FBuff = bs.readBytes(FCnt*6)
	rapi.rpgCommitTriangles(FBuff, noesis.RPGEODATA_USHORT, FCnt*3, noesis.RPGEO_TRIANGLE, 1)
	
	mdl = rapi.rpgConstructModel()
	mdlList.append(mdl)
	rapi.rpgClearBufferBinds()
	return 1