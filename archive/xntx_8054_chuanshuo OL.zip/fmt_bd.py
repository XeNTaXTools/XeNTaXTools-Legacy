#by Durik256 02.03.2022 for xentax
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("chuanshuo OL",".bp")
    noesis.setHandlerTypeCheck(handle, CheckType)
    noesis.setHandlerLoadModel(handle, LoadModel)    
    return 1
    
def CheckType(data):
    bs = NoeBitStream(data)
    if noeAsciiFromBytes(bs.readBytes(8)) != 'BIND1.00':
        return 0
    return 1

def LoadModel(data, mdlList):    
    bs = NoeBitStream(data)
    bs.seek(8)
    
    bCount = bs.readUInt()
    
    bones = []
    for x in range(bCount):
        mat = NoeMat44.fromBytes(bs.readBytes(64)).toMat43()
        name = noeAsciiFromBytes(bs.readBytes(bs.readUInt()))
        bones.append(NoeBone(x, name, mat))

    mdl = NoeModel()
    mdl.setBones(bones)
    mdlList.append(mdl) 
    return 1