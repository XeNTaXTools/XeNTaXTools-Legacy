#by Durik256 02.03.2022 for xentax
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("chuanshuo OL",".mesh")
    noesis.setHandlerTypeCheck(handle, CheckType)
    noesis.setHandlerLoadModel(handle, LoadModel)    
    return 1
    
def CheckType(data):
    bs = NoeBitStream(data)
    if noeAsciiFromBytes(bs.readBytes(8)) != 'MESH2.00':
        return 0
    return 1

def LoadModel(data, mdlList):
    ctx = rapi.rpgCreateContext()
    bs = NoeBitStream(data)
    bs.seek(12)
    
    vCount = bs.readUInt()
    
    vbuffer = bs.readBytes(vCount*12)
    nbuffer = bs.readBytes(vCount*12)
    
    bs.seek(vCount*4, NOESEEK_REL)
    
    unkCount = bs.readUInt()
    bs.seek(unkCount*16, NOESEEK_REL)
       
    bs.readUInt()
    fCount = bs.readUInt()
    
    rapi.rpgBindPositionBuffer(vbuffer, noesis.RPGEODATA_FLOAT,12)
    rapi.rpgCommitTriangles(None, noesis.RPGEODATA_USHORT, len(vbuffer)//12, noesis.RPGEO_POINTS, 1)

    mdl = rapi.rpgConstructModel()
    mdlList.append(mdl) 
    return 1