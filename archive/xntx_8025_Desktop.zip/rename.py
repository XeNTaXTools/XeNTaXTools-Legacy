import sys
import os

droppedFile = sys.argv[1]
print("open",droppedFile)
dir = os.path.dirname(droppedFile)
print("dir",dir)

with open(droppedFile, 'r') as file:
    lines = file.read().splitlines()
    
    files = sorted(os.listdir(dir), key=len)
    if len(files) >= len(lines):
        for i,line in enumerate(lines):
            newName = str(i)+os.path.splitext(lines[i].split('|')[0])[1]
            print(files[i],">>",newName)
            os.rename(os.path.join(dir,files[i]),os.path.join(dir,newName))
            
print("rename",len(files),"files!")
os.system('pause')