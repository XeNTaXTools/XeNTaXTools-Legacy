from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("long 3d", ".axp")
    noesis.setHandlerExtractArc(handle, axpExtractArc)
    return 1

def axpExtractArc(fileName, fileLen, justChecking):
    if fileLen < 16:
        return 0
        
    if justChecking: #it's valid
            return 1

    f = open(fileName, "rb")
    fs = NoeFileStream(f)
    
    idstring = noeAsciiFromBytes(fs.readBytes(4))
    if idstring != "AXPK":
        return 0
    
    VER1 = fs.readShort()
    VER2 = fs.readShort()
    ZERO = fs.readInt()
    ZERO = fs.readInt()
    INFO_OFF = fs.readInt()
    FILES = fs.readInt()
    DUMMY = fs.readInt()
    DATA_OFF = fs.readInt()
    DATA_SIZE = fs.readInt()
    
    fs.seek(INFO_OFF, NOESEEK_ABS)
    allOffset = []

    for i in range(FILES):
        OFFSET = fs.readInt()
        SIZE = fs.readInt()
        FLAGS = fs.readInt()# ever 0x80000000!

        if FLAGS != 0:
            allOffset.append([OFFSET,SIZE])

    fs.seek(allOffset[-1][0], NOESEEK_ABS)
        
    for x in range(len(allOffset)):
        name_file = str(x)+".dat"
        fs.seek(allOffset[x][0], NOESEEK_ABS)
        export_data = fs.readBytes(allOffset[x][1])
        rapi.exportArchiveFile(name_file, export_data)
        print("export", name_file)

    print("Extracting", len(allOffset), "files.")
    return 1