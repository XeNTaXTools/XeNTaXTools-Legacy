from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Kamen Rider City Wars [Android]", ".texture")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    if bs.readBytes(4) != b'\x5E\x08\xB4\x5E': return 0
    return 1
    
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.seek(0x31, NOESEEK_ABS)         
    imgFmt = bs.readUByte()
    bs.seek(0x8b, NOESEEK_ABS)         
    imgWidth = bs.readUInt()            
    imgHeight = bs.readUInt()
    print(imgWidth, "x", imgHeight, ":", imgFmt)
    bs.seek(0x9c, NOESEEK_ABS)
    datasize = bs.readUInt()
    data = bs.readBytes(datasize)      
    #RGB565
    if imgFmt == 3:
        data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "b5 g6 r5")
    #RGBA4444
    elif imgFmt == 4:
        data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "a4 b4 g4 r4") 
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, noesis.NOESISTEX_RGBA32))
    return 1