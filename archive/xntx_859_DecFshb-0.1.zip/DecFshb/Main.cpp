// Main.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Adpcm.h"
#include "WaveWriter.h"

static int DecodeFSHB(std::istream& Input, std::ostream& Output, \
					  unsigned char& Channels, unsigned long& SampleRate, \
					  unsigned long& NumberSamples)
{
	char Signature[4];
	unsigned long NumberChannels;
	unsigned long Something;
	unsigned long Offset;
	unsigned long BlockSize;

	Input.read(Signature, 4);
	if(memcmp(Signature, "FSHB", 4)!=0)
	{
		std::cout << "Bad signature" << std::endl;
		return 4;
	}
	Input.read((char*)&NumberChannels, 4);
	Input.read((char*)&Something, 4);
	Input.read((char*)&Offset, 4);
	Input.read((char*)&BlockSize, 4);
	Input.read((char*)&SampleRate, 4);
	Input.seekg(Offset);

	// Print some information
	std::cout << "Channels: " << NumberChannels << std::endl;
	std::cout << "Offset: " << Offset << std::endl;
	std::cout << "Block Size: " << BlockSize << std::endl;
	std::cout << "Sample Rate: " << SampleRate << std::endl;

	// Allocate some data
	const unsigned long SamplesInBlock=BlockSize*2;
	unsigned char* Data=new unsigned char[BlockSize];
	short* Samples=new short[NumberChannels*SamplesInBlock];
	SAdpcmMonoParam* Params=new SAdpcmMonoParam[NumberChannels];
	Channels=(unsigned char)NumberChannels;

	// Initialize the parameters
	for(unsigned long i=0;i<NumberChannels;i++)
	{
		Params[i].InputBuffer=Data;
		Params[i].InputLength=BlockSize;
		Params[i].OutputBuffer=Samples+i*SamplesInBlock;
		Params[i].FirstSample=0;
		Params[i].FirstIndex=20;
	}

	// Start decoding
	while(!Input.eof())
	{
		for(unsigned long i=0;i<NumberChannels;i++)
		{
			// Read it
			Input.read((char*)Data, BlockSize);
			if(Input.fail())
			{
				break;
			}

			// Decode it
			DecompressMonoAdpcm(&Params[i]);
		}

		// Write it
		for(unsigned long i=0;i<SamplesInBlock;i++)
		{
			for(unsigned long j=0;j<NumberChannels;j++)
			{
				Output.write((char*)(Samples+j*SamplesInBlock+i), 2);
			}
		}
		NumberSamples+=SamplesInBlock*NumberChannels;
	}

	// Clean up
	delete[] Data;
	delete[] Samples;
	delete[] Params;
	return 0;
}

int _tmain(int argc, _TCHAR* argv[])
{
	// Check the number of arguments
	if(argc!=3)
	{
		std::cout << "Usage: DecFshb InputFile.fsb OutputFile.wav" << std::endl;
		return 1;
	}

	// Open the input file
	std::ifstream Input;
	Input.open(argv[1], std::ios_base::in | std::ios_base::binary);
	if(!Input.is_open())
	{
		std::cout << "Cannot open input file '" << argv[1] << "'" << std::endl;
		return 2;
	}

	// Open the output file
	std::ofstream Output;
	Output.open(argv[2], std::ios_base::out | std::ios_base::binary);
	if(!Output.is_open())
	{
		std::cout << "Cannot open output file '" << argv[2] << "'" << std::endl;
		Input.close();
		return 3;
	}

	// Write a wave header and decode
	int Result;
	unsigned char Channels=0;
	unsigned long SampleRate=0;
	unsigned long NumberSamples=0;
	PrepareWaveHeader(Output);
	Result=DecodeFSHB(Input, Output, Channels, SampleRate, NumberSamples);
	Output.seekp(0);
	WriteWaveHeader(Output, SampleRate, 16, Channels, NumberSamples);

	// Close the files
	Input.close();
	Output.close();
	return Result;
}

