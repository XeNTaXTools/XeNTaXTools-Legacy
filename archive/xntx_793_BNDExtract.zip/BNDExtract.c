#include <stdio.h>
#include <stdlib.h>

struct bnd_header
{
       int magic;
       int version;
       int numentries;
} __attribute__((packed));

struct bnd_entry
{
       int filesize;
       int offset;
       char identifier[32];
} __attribute__((packed));

int main(int argc, char *argv[])
{
    FILE *bnd, *out;
    struct bnd_header hdr;
    int i;
    char outname[600];
    char *buffer;
    
    if (argc != 2)
    {
       printf("Invalid arguments!\n");
       getch();
       exit(-1);
    }
    
    // Open
    bnd = fopen(argv[1], "rb");
    if (bnd == NULL)
    {
       printf("Can't open the BNKD file!\n");
       getch();
       exit(-1);
    }
    
    // Read header
    fread(&hdr, sizeof(struct bnd_header), 1, bnd);
    
    // Check header
    if (hdr.magic != 0x444B4E42)
    {
       printf("Not a valid BNKD file!\n");
       getch();
       exit(-1);
    }
    
    if (hdr.version != 2)
       printf("WARNING: Unsupported version (maybe will crash)");
    
    // Read entries
    struct bnd_entry entries[hdr.numentries];
    fread(&entries, sizeof(struct bnd_entry) * hdr.numentries, 1, bnd);
    
    // Extract files
    for (i = 0; i < hdr.numentries; i++)
    {
        sprintf(outname, "%s-%i.unk", argv[1], i);
        printf("Extracting file %i as %s (O: %i, FS: %i)\n", i, outname, entries[i].offset, entries[i].filesize);
        
        // Open outfile
        out = fopen(outname, "wb");
        if (out == NULL)
        {
           printf("Can't open the output file!\n");
           getch();
           exit(-1);
        }
        
        // Copy to memory
        fseek(bnd, entries[i].offset, SEEK_SET);
        
        buffer = malloc(entries[i].filesize);
        if (buffer == NULL)
        {
           printf("Can't get enough memory to copy the file!\n");
           getch();
           exit(-1);
        }
        
        fread(buffer, entries[i].filesize, 1, bnd);
        
        // Write
        fwrite(buffer, entries[i].filesize, 1, out);
        
        // Clean
        free(buffer);
        fclose(out);
    }
    
    fclose(bnd);
    
    printf("\nEverything done OK!\n");
    getch();
    return 0;
}
