from inc_noesis import *
import noesis
import rapi

def registerNoesisTypes():
   handle = noesis.register("Elite Force", ".msd")    #change this extension
   noesis.setHandlerTypeCheck(handle, EFCheckType)
   noesis.setHandlerLoadModel(handle, EFLoadModel)
   #noesis.logPopup()
   return 1

def EFCheckType(data):
	bs = NoeBitStream(data)
	Magic = bs.readBytes(4)
	print(Magic, "magic")
	if Magic != b'MSD0': 
		return 0
	return 1   

def EFLoadModel(data, mdlList):
	ctx = rapi.rpgCreateContext()
	#rapi.setPreviewOption("setAngOfs","0 -60 90")         #set the default preview angle        
	bs = NoeBitStream(data)
	x = bs.readBytes(1500)
	y = x.rfind(b"\x64\x64\x73")
	print("we found 'dds' at", hex(y))
	bs.seek(y + 3, NOESEEK_ABS)
	zee = bs.readBytes(48)
	if b"\x44\x44\x53" in zee:
		y = x.rfind(b"\x44\x44\x53")
		print("we found 'DDS' at", hex(y))
	if y == -1:
		y = x.rfind(b"\x44\x44\x53")
		print("we found 'DDS' at", hex(y))
	bs.seek(y + 3, NOESEEK_ABS)
	print("You are now at", hex(bs.tell()))
	FCount = bs.readUInt()                                 #face indices count
	print(FCount, "face count")
	IBuf = bs.readBytes(FCount * 2)                       #multiply by 2 for word, 4 for dword indices 
	flag = bs.readInt()
	if flag == 1:
		skip = bs.readBytes(4)
	elif flag == 2:
		skip = bs.readBytes(8)
	elif flag == 3:
		skip = bs.readBytes(12)
	elif flag == 4:
		skip = bs.readBytes(16)
	VCount = bs.readUInt()                                     # vertex count
	print(VCount, "vertex count")
	VBuf = bs.readBytes(VCount * 12)
	rapi.rpgBindPositionBufferOfs(VBuf, noesis.RPGEODATA_FLOAT, 12, 0)   #position of vertices
	print(hex(bs.tell()), "we are at UV count")
	UVCount = bs.readUInt()
	print(UVCount, "UV count")
	UVBuf = bs.readBytes(UVCount * 8)
	rapi.rpgBindUV1BufferOfs(UVBuf, noesis.RPGEODATA_FLOAT, 8, 0)   #UVs
	rapi.rpgCommitTriangles(IBuf, noesis.RPGEODATA_SHORT, FCount, noesis.RPGEO_TRIANGLE, 1) #SHORT for word , INT for dword
	mdl = rapi.rpgConstructModel()                                                          
	mdlList.append(mdl)
	rapi.rpgClearBufferBinds()
	return 1