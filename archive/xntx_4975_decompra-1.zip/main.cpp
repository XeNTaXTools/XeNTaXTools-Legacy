/*
  a simple test program for the decompression class
  usage: decompRA infile outfile
*/

#include <cstdlib>
#include <iostream>
#include "decompressRA.h"

int main(int argc, char *argv[])
{

    printf("DecompRA (c) 2006 Benjamin Haisch\n\n");

    if (argc < 3) {
        printf("usage: decompRA infile outfile\n");
        return EXIT_FAILURE;
    }

    FILE *i = fopen(argv[1], "rb");
    
    if (!i) {
        printf("Couldn't open the input file!\n");
        return EXIT_FAILURE;
    }
    
    uint32 insize, outsize;
    byte *inbuffer, *outbuffer = NULL;
    fseek(i, 0, SEEK_END);
    insize = ftell(i);
    fseek(i, 0, SEEK_SET);
    inbuffer = new byte[insize];
    fread(inbuffer, insize, 1, i);
    fclose(i);

    DecompressRA decompressRA;
    if (decompressRA.isRA(inbuffer, insize)) {
        outsize = decompressRA.decompress(inbuffer, &outbuffer);
        printf("Decompressed, outsize = %d bytes\n", outsize);
        FILE *o = fopen(argv[2], "wb");
        fwrite(outbuffer, outsize, 1, o);
        fclose(o);
        delete[] outbuffer;
    } else {
        printf("This is not an RA compressed file!\n");
    }
    
    delete[] inbuffer;

    return EXIT_SUCCESS;
}
