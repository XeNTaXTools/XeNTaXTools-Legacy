/*
  RA decompression class version 1.0
  (c) 2006 Benjamin Haisch
  email: john_doe@techie.com
  You may use this code freely as long as you give me credit for it :)
*/

#ifndef DECOMPRESSRA_H
#define DECOMPRESSRA_H

#include <iostream>

#define byte unsigned char
#define uint16 unsigned short
#define uint32 unsigned long

class DecompressRA {
    private:
        int bitsLeft;
        byte bitBuffer;
        byte *inb, *outb, *inbuffer, *outbuffer;
        byte countTable1[512], countTable2[512];
        byte lengthTable1[512], lengthTable2[512];
        byte offsetTable1[32], offsetTable2[32];
        int getBit();
        int loadBits(int count);
        void loadTable(byte *table1, byte *table2);
        int loadValue(byte *table1, byte *table2);
        int loadCount();
        int loadLength();
        int loadOffset();
        void decompressData();
    public:
        DecompressRA() {};
        ~DecompressRA() {};
        bool isRA(byte *inbuffer, uint32 insize);
        uint32 decompress(byte *inbuffer, byte **outbuffer);
};

#endif
