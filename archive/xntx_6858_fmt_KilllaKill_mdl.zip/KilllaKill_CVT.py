import os
import sys
import struct

def readUInt(f):
    return struct.unpack("I", f.read(4))[0]

def readUShort(f):
    return struct.unpack("H", f.read(2))[0]

def main():
    dir_path = os.path.dirname(os.path.realpath(__file__))
    fileName = sys.argv[1]
    fileNameNoPath = fileName.split("\\")
    fileNameNoPath = fileNameNoPath[len(fileNameNoPath) - 1]
    fileNamePure = fileNameNoPath.split(".")[0]
    f = open(fileName, 'rb')
    f.seek(0, 2)
    Size = f.tell()
    f.seek(0)
    UNK = readUShort(f)
    Width = readUShort(f)
    Height = readUShort(f)
    Type = readUShort(f)
    f.seek(80)
    Data = f.read(Size - 80)
    UNKHeader = bytearray.fromhex('444453207C00000007100000')
    UNKHeader2 = bytearray.fromhex('0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000200000004100000000000000200000000000FF0000FF0000FF000000000000FF0210000000000000000000000000000000000000')
    w = open(fileNamePure+".dds", 'wb')
    if Type == int(256):
        w.write(bytes(UNKHeader))
        w.write(struct.pack('I', Width))
        w.write(struct.pack('I', Height))
        w.write(UNKHeader2)
        w.write(Data)
    w.write(Data)
    w.close()

main()
