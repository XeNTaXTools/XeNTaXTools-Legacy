from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Castlevania: Curse of Darkness [PS2]", ".bin")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    return 1

def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.seek(0x14)
    imgWidth = bs.readUShort()
    imgHeight = bs.readUShort()
    bs.seek(0x80)
    palette = bs.readBytes(0x400)
    data = bs.readBytes(bs.getSize() - bs.tell())
    data = rapi.imageUntwiddlePS2(data, imgWidth, imgHeight, 8)
    data = rapi.imageDecodeRawPal(data, palette, imgWidth, imgHeight, 8, "r8 g8 b8 p8")
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, noesis.NOESISTEX_RGBA32))
    return 1