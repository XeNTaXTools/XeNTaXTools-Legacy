import newGameLib
reload(newGameLib)
from newGameLib import *
import Blender
import math
from math import *	

def jmdlParser(filename,g):
	g.endian='>'
	g.word(4)
	A=g.H(4)+g.i(9)	
		
	g.seek(A[6])#textures
	start=g.tell()
	a,b=g.H(2)
	offList=g.i(a)
	texList=[]
	for off in offList:	
		g.seek(start+off)
		g.B(25)
		texCount=g.B(1)[0]
		List=g.H(texCount)
		if len(List)==1:texList.append(0)
		else:texList.append(List[1])	
	
	g.seek(A[5])#materials
	start=g.tell()
	a,b=g.H(2)
	offList=g.i(a)	
	matList=[]
	for off in offList:	
		g.seek(start+off)
		g.i(3)	
		g.f(6)	
		count=g.H(1)[0]
		g.H(1)
		for m in range(count):
			mat=Mat()
			a,b,c,d=g.H(4)	
			mat.IDStart=b
			mat.IDCount=c
			id=g.H(1)[0]
			mat.ID=texList[id]
			mat.meshID=g.B(1)[0]
			g.B(1)
			mat.boneMap=g.H(16)	
			g.f(6)	
			matList.append(mat)
		g.f(1)	
	
	g.seek(A[8])#meshes		
	start=g.tell()
	count=g.i(1)[0]
	B=g.i(3)
	meshList=[]
	g.seek(start+B[0])
	for m in range(count):
		mesh=Mesh()
		mesh.info=g.i(5)+g.H(2)
		meshList.append(mesh)
	for m in range(count):
		mesh=meshList[m]
		mesh.vertPosOff=None
		mesh.vertUVOff=None
		mesh.skinIndiceOff=None
		mesh.skinWeightOff=None
		mesh.stride=None
		off=0
		for n in range(mesh.info[2]):
			info=g.i(1)+g.B(4)
			if info[1]==1:mesh.vertPosOff=info[0]#off
			if info[1]==8:mesh.vertUVOff=info[0]#off
			if info[1]==6:mesh.skinIndiceOff=info[0]#off
			if info[1]==5:mesh.skinWeightOff=info[0]#off			
			if info[3]==2:off+=8
			if info[3]==3:off+=12
			if info[3]==4:off+=16
		mesh.stride=info[4]
	for m in range(count):
		mesh=meshList[m]
		g.seek(start+mesh.info[0])
		vertCount=mesh.info[1]/mesh.stride
		for n in range(vertCount):
			t=g.tell()
			g.seek(t+mesh.vertPosOff)
			mesh.vertPosList.append(g.f(3))
			if mesh.vertUVOff is not None:
				g.seek(t+mesh.vertUVOff)
				mesh.vertUVList.append(g.f(2))
			if mesh.skinIndiceOff is not None:
				g.seek(t+mesh.skinIndiceOff)
				mesh.skinIndiceList.append(g.B(4))
			if mesh.skinWeightOff is not None:
				g.seek(t+mesh.skinWeightOff)
				mesh.skinWeightList.append(g.f(4))
			g.seek(t+mesh.stride)
			mesh.skinIDList.append([])
	g.seek(start+B[2])
	start=g.tell()		
	indiceStreamInfoList=[]
	for m in range(B[1]):
		t=g.tell()
		C=g.i(4)
		indiceStreamInfoList.append([t,C])
	
	
	sys=Sys(filename)	
	for mat in matList:
		mesh=meshList[mat.meshID]
		for m in range(len(mesh.vertPosList)):
			mesh.skinIDList[m].append(0)
		MAT=Mat()
		MAT.diffuse=sys.dir+os.sep+sys.base+'_files'+os.sep+str(mat.ID)+'.dds'
		MAT.TRIANGLE=True
		MAT.IDStart=len(mesh.indiceList)
		MAT.IDCount=mat.IDCount
		MAT.matrix=Euler(0,0,-90).toMatrix().resize4x4()
		g.seek(indiceStreamInfoList[mesh.info[4]][0]+indiceStreamInfoList[mesh.info[4]][1][0])
		indiceList=g.H(indiceStreamInfoList[mesh.info[4]][1][2])
		list=indiceList[mat.IDStart:mat.IDStart+mat.IDCount]
		if mesh.skinIndiceOff is not None and mesh.skinWeightList is not None:		
			skin=Skin()
			for map in mat.boneMap:
				skin.boneMap.append(map-1)
			for indice in list:
				mesh.skinIDList[indice][len(mesh.skinList)]=1
			mesh.skinList.append(skin)	
		else:
			for m in range(len(mesh.vertPosList)):
				mesh.skinIndiceList.append([0])
				mesh.skinWeightList.append([1.0])	
			skin=Skin()
			for map in mat.boneMap:
				skin.boneMap.append(map-1)
			for indice in list:
				mesh.skinIDList[indice][len(mesh.skinList)]=1
			mesh.skinList.append(skin)	
		mesh.indiceList.extend(list)		
		mesh.matList.append(MAT)
			
	g.seek(A[4])#bones
	start=g.tell()
	a=g.H(1)[0]
	skeleton=Skeleton()
	skeleton.BONESPACE=True
	skeleton.NICE=True
	for m in range(a):
		g.H(1)[0]
		bone=Bone()
		bone.name=str(m)
		bone.hash=g.i(1)[0]
		g.f(1)
		posMatrix=VectorMatrix(g.f(3))#.invert()
		x,y,z=g.f(3)
		x=degrees(x)
		y=degrees(y)
		z=degrees(z)
		rotMatrix=Euler(x,y,z).toMatrix().resize4x4()#*Euler(0,0,90).toMatrix().resize4x4()
		bone.matrix=rotMatrix*posMatrix
		skala=g.f(3)		
		bone.parentID= g.H(1)[0]-1
		skeleton.boneList.append(bone)
	skeleton.draw()	
	for mesh in meshList:
		mesh.SPLIT=True
		if len(mesh.skinList)>0:mesh.BINDSKELETON=skeleton.name
		mesh.draw()
	
	
def unpParser(filename,g):
	#g.debug=True
	g.endian='>'
	chunk=g.read(4)
	if chunk=='\x6a\x41\x52\x43':
		A=g.i(3)
		for m in range(A[2]):
			B=g.i(5)
			t=g.tell()
			g.seek(B[2])
			path=g.dirname+os.sep+g.find('\x00')
			try:os.makedirs(os.path.dirname(path))
			except:pass
			new=open(path,'wb')
			g.seek(B[0])
			new.write(g.read(B[1]))
			new.close()
			g.seek(t)
	g.tell()	

def getTextures(filename,g):
	start=g.tell()
	offsetList=[]
	data=g.read(g.fileSize())
	while(True):
		offset=data.find('\x6a\x49\x4d\x47')
		start+=offset
		if offset!=-1:
			offsetList.append(start)
			data=data[offset+4:]
			start+=4
		else:
			break
	sys=Sys(filename)
	sys.addDir(sys.base+'_files')	
	for i,offset in enumerate(offsetList):
		path=sys.dir+os.sep+sys.base+'_files'+os.sep+str(i)+'.dds'
		g.seek(offset)
		g.word(4)
		A=g.B(4)+g.H(2)+g.B(1)
		print A
		img=imageLib.Image()
		img.name=path
		if A[4]==4:img.szer=1024
		if A[4]==2:img.szer=512
		if A[4]==1:img.szer=256
		if A[4]==32768:img.szer=128
		if A[4]==16384:img.szer=64	
		
		if A[5]==4:img.wys=1024 
		if A[5]==1:img.wys=256 
		if A[5]==4096:img.wys=8 
		if A[5]==32768:img.wys=128
		if A[5]==16384:img.wys=64
		
		if A[6]==11:img.format='DXT5'
		if A[6]==8:img.format='DXT1'
		if A[6]==1:img.format='DXT3'
		if i<len(offsetList)-1:
			g.seek(offset+256)
			size=offsetList[i+1]-offset
			img.data=g.read(size)
			img.draw()		
		else:
			g.seek(offset+256)
			size=g.fileSize()-offset
			img.data=g.read(size)
			img.draw()		
	g.seek(0)	
	

def Parser():	
	filename=input.filename
	print
	print filename
	print
	
	ext=filename.split('.')[-1].lower()	
	
	
	if ext=='jmdl':
		file=open(filename,'rb')
		g=BinaryReader(file)
		getTextures(filename,g)
		jmdlParser(filename,g)
		file.close()
	else:
		for file in os.listdir(os.path.dirname(filename)):
			nfilename=os.path.dirname(filename)+os.sep+file
			print file
			if os.path.isfile(nfilename)==True:
				file=open(nfilename,'rb')
				g=BinaryReader(file)
				unpParser(nfilename,g)
				file.close()
		
		
 
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
	 
Blender.Window.FileSelector(openFile,'import','One Piece Unlimited World Red files: *.None - archives, jmdl - model') 