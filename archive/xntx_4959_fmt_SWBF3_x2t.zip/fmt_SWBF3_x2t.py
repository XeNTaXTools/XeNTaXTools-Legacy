from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Star Wars Battlefront III x2t", ".x2t")
	noesis.setHandlerTypeCheck(handle, SWBF3CheckType)
	noesis.setHandlerLoadRGBA(handle, SWBF3LoadRGBA)
	#noesis.logPopup()
	return 1

def SWBF3CheckType(data):
	return 1   

	
def SWBF3LoadRGBA(data, texList):
	bs = NoeBitStream(data)
	imgFmt = 1                      #set the image format 1 2 3 4 5 6
	imgWidth = 1024                 #set the image width
	imgHeight = 1024                #set the image height
	#DXT1
	if imgFmt == 1:
		data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 8)
		texFmt = noesis.NOESISTEX_DXT1
	#DXT5
	elif imgFmt == 2:
		data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 16)
		texFmt = noesis.NOESISTEX_DXT5
	#DXT5 packed normal map
	elif imgFmt == 3:
		data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 16)
		data = rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_ATI2)
		texFmt = noesis.NOESISTEX_RGBA32
	#DXT5 packed normal map2
	elif imgFmt == 4:
		data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 16)
		data = rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_ATI1)
		texFmt = noesis.NOESISTEX_RGBA32
	#DXT1 packed normal map
	elif imgFmt == 5:
		data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 8)
		data = rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_DXT1NORMAL)
		texFmt = noesis.NOESISTEX_RGBA32
	#raw
	elif imgFmt == 6:
		data = rapi.imageUntile360Raw(rapi.swapEndianArray(data, 4), imgWidth, imgHeight, 4)
		texFmt = noesis.NOESISTEX_RGBA32
	#unknown, not handled
	else:
		print("WARNING: Unhandled image format")
		return None
	texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
	return 1