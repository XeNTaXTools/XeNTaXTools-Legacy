#by Durik256
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("S.W.A.T. Target Liberty", ".wob")
    noesis.setHandlerTypeCheck(handle, CheckType)
    noesis.setHandlerLoadModel(handle, LoadModel)
    return 1

def CheckType(data):
    if data[:4] != b'\xBC\x00\x00\x00':
        return 0
    return 1

def LoadModel(data, mdlList):
    bs = NoeBitStream(data)
    ctx = rapi.rpgCreateContext()
    bs.seek(20)
    
    vnum = bs.readInt()
    inum = bs.readInt()
    
    vofs = bs.readInt() + 4
    iofs = bs.readInt() + 4
    uofs = bs.readInt() + 4
    
    bs.seek(vofs)
    vbuf = bs.readBytes(vnum*44)
    rapi.rpgBindPositionBuffer(vbuf, noesis.RPGEODATA_FLOAT, 44)
    rapi.rpgBindUV1BufferOfs(vbuf, noesis.RPGEODATA_FLOAT, 44, 28)
        
    bs.seek(iofs)
    ibuf = bs.readBytes(inum*2)
    rapi.rpgCommitTriangles(ibuf, noesis.RPGEODATA_USHORT, inum, noesis.RPGEO_TRIANGLE)


    mdl = rapi.rpgConstructModel()
    mdl.setModelMaterials(NoeModelMaterials([], [NoeMaterial('default','')]))
    mdlList.append(mdl)
    rapi.setPreviewOption("setAngOfs", "0 180 0")
    return 1