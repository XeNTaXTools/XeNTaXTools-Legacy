from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("S.W.A.T. Target Liberty", ".tex")
    noesis.setHandlerTypeCheck(handle, CheckType)
    noesis.setHandlerLoadRGBA(handle, LoadRGBA)
    return 1

def CheckType(data):
    return 1
    
def LoadRGBA(data, texList):
    bs = NoeBitStream(data)
    w, h, psize = bs.read('3H')
    t0, t1 = bs.read('2B')
    unk, pofs = bs.read('2I')
    dsize = w*h
    
    bs.seek(pofs)
    
    if t0 == 128:
        pix = bs.read(dsize*2)#psize
        pix = rapi.imageDecodeRaw(pix, w, h, 'r4g4b4a4')
    else:
        psize = bs.getSize() - dsize - pofs

        pal = bs.read(psize)
        pix = bs.read(dsize)
        
        fmt = 'r5g5b5a1'
        if t1 == 128:
            fmt = 'r8g8b8a8'
        
        pix = rapi.imageUntwiddlePSP(pix, w, h, 8)
        pix = rapi.imageDecodeRawPal(pix, pal, w, h, 8, fmt, 0)

    texList.append(NoeTexture(rapi.getInputName(), w, h, pix, noesis.NOESISTEX_RGBA32))
    return 1