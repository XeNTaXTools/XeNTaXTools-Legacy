#by Durik256
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("S.W.A.T. Target Liberty", ".lmp")
    noesis.setHandlerExtractArc(handle, ExtractBIN)
    return 1
    
def ExtractBIN(fileName, fileLen, justChecking):

    if justChecking: #it's valid
            return 1

    data = rapi.loadIntoByteArray(fileName)
    bs = NoeBitStream(data)
    
    count = bs.readInt()
    
    if not count:
        return 0
    
    for x in range(count):
        name_ofs, data_ofs, size = bs.read('3I')
        curPos = bs.tell()
        
        bs.seek(name_ofs)
        name = bs.readString()
        
        bs.seek(data_ofs)
        data = bs.read(size)
        
        rapi.exportArchiveFile(name, data)
        print("export", name)
        
        bs.seek(curPos)

    print("Extracting", count, "files.")
    return 1