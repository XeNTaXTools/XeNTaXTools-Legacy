#2010-12-17 Glogow Poland Mariusz Szkaradek 
#version 2 
#draw geometry and uv-mapping
#for repair face direction please: 
#     *in Object Mode  select object
#     *in Edit Mode    left ctrl + n  => recalculate normals outside


import Blender
from Blender import *
from Blender import Armature as A
from Blender.Mathutils import *
import struct,os,bpy


def word(long): 
   s=''
   for j in range(0,long):  
       s+=struct.unpack('c',plik.read(1))[0]
   return s

def b(n):
    return struct.unpack(n*'b', plik.read(n))
def B(n):
    return struct.unpack(n*'B', plik.read(n))
def h(n):
    return struct.unpack(n*'h', plik.read(n*2))
def H(n):
    return struct.unpack(n*'H', plik.read(n*2))
def i(n):
    return struct.unpack(n*'i', plik.read(n*4))
def f(n):
    return struct.unpack(n*'f', plik.read(n*4))




def drawmesh(num): 
    global mesh
    mesh = bpy.data.meshes.new('mesh'+str(num))
    mesh.verts.extend(vertexy)
    mesh.faces.extend(faceslist,ignoreDups=True)
    try:
    #if len(uvcoord)>0:
        vertexuv()
    except:
        pass
    scene = bpy.data.scenes.active
    obj = scene.objects.new(mesh,'obiekt'+str(num))
    Redraw()


def type5():
    global faceslist
    numfaces =  i(1)[0]
    print'numfaces',numfaces
    v1=-1
    v2=-1
    v3=-1
    for v in range(numfaces):
        v3=v2 
        v2=v1         
        v1=struct.unpack('h', plik.read(2))[0]
        if v1!=-1 and v2!=-1 and v3!=-1:
            faceslist.append([v1,v2,v3])

def type3():
    numfaces =  i(1)[0]
    print'numfaces',numfaces
    for v in range(numfaces/3):
        faceslist.append(H(3))



def readtype37():
    global type37
    type37=[] 
    num = i(1)[0]
    print 'num',num
    for v in range(num):
        type37.append(f(3))

def readvertexes():
    global vertexy
    vertexy=[] 
    numvertex = i(1)[0]
    print 'numvertex',numvertex
    for v in range(numvertex):
        vertexy.append(f(3))

def readnormals():
    global normals
    normals = []
    numnormals = i(1)[0]
    print 'numnormals',numnormals
    for v in range(numnormals):
        normals.append(f(3))

def readtangent():
    global normals
    normals = []
    numnormals = i(1)[0]
    print 'numnormals',numnormals
    for v in range(numnormals):
        normals.append(f(3))
    
def readbinormals():
    global normals
    normals = []
    numnormals = i(1)[0]
    print 'numnormals',numnormals
    for v in range(numnormals):
        normals.append(f(3))
    
def readdiffuse():
    global uvcoord
    uvcoord = [] 
    numvertex = i(1)[0]
    print 'numvertex',numvertex
    for m in range(numvertex):
        uvco = f(2)
        u = uvco[0]
        v = uvco[1]
        #print u,v
        uvcoord.append( (u,1-v) )

def facesuv():
    for faceID in range(0,len(mesh.faces)):
            face = mesh.faces[faceID]
            index1 = faceslist[faceID][0]
            index2 = faceslist[faceID][1]
            index3 = faceslist[faceID][2]
            uv1 = Vector(uvcoord[index1])
            uv2 = Vector(uvcoord[index2])
            uv3 = Vector(uvcoord[index3])
            face.uv = [uv1, uv2, uv3]
            face.smooth=True 

def vertexuv():
    mesh.vertexUV = 1
    for m in range(len(mesh.verts)):
        mesh.verts[m].uvco = uvcoord[m]  
    mesh.update() 
    mesh.faceUV = 1
    for fc in mesh.faces: fc.uv = [v.uvco for v in fc.verts]
    mesh.update()
      
             
def boneweights0(gr):
    num = i(1)[0]
    print 'num=',num
    if gr == 32:
        for v in range(num):
            f(1)
    if gr == 33:
        for v in range(num):
            f(2)
    if gr == 34:
        for v in range(num):
            f(3)
    if gr == 35:
        for v in range(num):
            f(4)
            
def boneindices0(gr):
    num = i(1)[0]
    print 'num=',num
    if gr == 32:
        for v in range(num):
            B(4)
    if gr == 33:
        for v in range(num):
            B(8)
    if gr == 34:
        for v in range(num):
            B(12)
    if gr == 35:
        for v in range(num):
            B(16)


def obiekt(id_obiekt):
    global faceslist
    faceslist = []
    print i(1)
    data = B(4)
    print data
    if data[0]==49:
        print i(1)
        print word(i(1)[0])
        print B(5)
        print i(1)[0],'---------------VERTEXES'
        num = i(1)[0]
        print 'num=',num
        for m in range(num):
            data = B(4)
            print data
            print i(1)[0]
            name = word(i(1)[0])
            print name
            print i(1),B(4),i(1)
            if name == 'a2v.objCoord':
                readvertexes()
            if name == 'a2v.objNormal':
                readnormals()
            if name == 'a2v.objTangent':
                readtangent()
            if name == 'a2v.objBinormal':
                readbinormals()
            if name == 'a2v.diffuse':
                readdiffuse()
            if name == 'a2v.boneWeights0':
                boneweights0(data[0])
            if name == 'a2v.boneIndices0':
                boneindices0(data[0])
            print i(1)
        print i(1)[0],'------------------FACES'
        num = i(1)[0]
        for m in range(num):
            print B(4),i(1)[0]
            data = i(2)
            print data
            if data[0] == 5: 
                 type5()
            if data[0] == 3: 
                 type3()
            print i(1)
        drawmesh(id_obiekt)
    elif data[0]==56:
        print i(1)
        print word(i(1)[0])
        print B(5)
        print i(1)[0]
        num = i(1)[0]
        print 'num=',num
        print B(17)
        num = i(1)[0] 
        #BONES
        print 'num=',num,'-------------------BONES'
        for  m in range(num):
            data1 = B(8)
            print word(i(1)[0])
            print i(1)[0],word(i(1)[0])
            if data1[0]==3:
                print B(20)
            if data1[0]==1:
                print B(64)
        print i(1)
        num = i(1)[0]
        print 'num=',num
        for m in range(num):
            data = B(4)
            print data
            print i(1)[0],'---------------VERTEXES'
            name = word(i(1)[0])
            print name
            print i(1),B(4),i(1)          
            if name == 'a2v.worldCoord':
                readvertexes()
            if name == 'a2v.worldNormal':
                readnormals()
            if name == 'a2v.worldTangent':
                readtangent()
            if name == 'a2v.worldBinormal':
                readbinormals()
            if name == 'a2v.diffuse':
                readdiffuse()
            if name == 'a2v.boneWeights0':
                boneweights0(data[0])
            if name == 'a2v.boneIndices0':
                boneindices0(data[0])
            if name == 'a2v.worldCoordDiff0':
                readtype37()
            if name == 'a2v.worldCoordDiff1':
                readtype37()
            if name == 'a2v.worldCoordDiff2':
                readtype37()
            if name == 'a2v.worldCoordDiff3':
                readtype37()
            if name == 'a2v.worldCoordDiff4':
                readtype37()
            if name == 'a2v.worldCoordDiff5':
                readtype37()
            if name == 'a2v.worldCoordDiff6':
                readtype37()
            if name == 'a2v.worldCoordDiff7':
                readtype37()
            if name == 'a2v.worldCoordDiff8':
                readtype37()
            if name == 'a2v.worldCoordDiff9':
                readtype37()
            if name == 'a2v.worldCoordDiff10':
                readtype37()
            if name == 'a2v.worldCoordDiff11':
                readtype37()
            if name == 'a2v.worldCoordDiff12':
                readtype37()
            if name == 'a2v.worldCoordDiff13':
                readtype37()
            if name == 'a2v.worldCoordDiff14':
                readtype37()
            if name == 'a2v.worldCoordDiff15':
                readtype37()
            if name == 'a2v.worldCoordDiff16':
                readtype37()
            if name == 'a2v.worldCoordDiff17':
                readtype37()
            if name == 'a2v.worldCoordDiff18':
                readtype37()
            if name == 'a2v.worldNormalDiff0':
                readtype37()
            if name == 'a2v.worldNormalDiff1':
                readtype37()
            if name == 'a2v.worldNormalDiff2':
                readtype37()
            if name == 'a2v.worldNormalDiff3':
                readtype37()
            if name == 'a2v.worldNormalDiff4':
                readtype37()
            if name == 'a2v.worldNormalDiff5':
                readtype37()
            if name == 'a2v.worldNormalDiff6':
                readtype37()
            if name == 'a2v.worldNormalDiff7':
                readtype37()
            if name == 'a2v.worldNormalDiff8':
                readtype37()
            if name == 'a2v.worldNormalDiff9':
                readtype37()
            if name == 'a2v.worldNormalDiff10':
                readtype37()
            if name == 'a2v.worldNormalDiff11':
                readtype37()
            if name == 'a2v.worldNormalDiff12':
                readtype37()
            if name == 'a2v.worldNormalDiff13':
                readtype37()
            if name == 'a2v.worldNormalDiff14':
                readtype37()
            if name == 'a2v.worldNormalDiff15':
                readtype37()
            if name == 'a2v.worldNormalDiff16':
                readtype37()
            if name == 'a2v.worldNormalDiff17':
                readtype37()
            if name == 'a2v.worldNormalDiff18':
                readtype37()
            print i(1)

        print i(1)[0],'------------------FACES'
        num = i(1)[0]
        for m in range(num):
            print B(4),i(1)[0]
            data = i(2)
            print data
            if data[0] == 5: 
                 type5()
            if data[0] == 3: 
                 type3()
            print i(1)
        drawmesh(id_obiekt)




def nividia_dusk(filename):
    global plik
    plik = open(filename,'rb')
    plik.seek(176285)    
    for id_obiekt in range(171):#171
        print '==============obiect',id_obiekt   
        obiekt(id_obiekt)

Window.FileSelector (nividia_dusk, 'import nmb','*.nmb')
    