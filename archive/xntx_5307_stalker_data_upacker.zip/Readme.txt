S.T.A.L.K.E.R. Database Extractor  uploaded by TonyMontana5000
---------------------------------

This tool is very simple:
1)Start the Tool
2)Choose the *.db file in the S.T.A.L.K.E.R. directory.
3)Choose a place where the files schould be extracted.


TonyMontana5000
-TonyMontana5000@gmx.at