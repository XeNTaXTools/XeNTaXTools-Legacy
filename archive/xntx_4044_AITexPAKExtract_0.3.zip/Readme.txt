Authors: Cra0kalo
Game: Alien Isolation
Purpose: Unpack paks
Version: 0.3
---------------------------------------------------------------------------
Usage Example:

Inorder to unpack texture packages you will need to have the accompanying header bin file next to the package.
Below is an example usage case:


File to unpack-> LEVEL_TEXTURES.ALL.PAK

Copy
*LEVEL_TEXTURES.ALL.PAK
*LEVEL_TEXTURE_HEADERS.ALL.BIN

to a new directory

rename (LEVEL_TEXTURE_HEADERS.ALL.BIN) to (LEVEL_TEXTURES_HEADERS.ALL.BIN)
NOTE THE "TEXTURE" -> "TEXTURES" you add the 'S'



Now run like so
*************************************************************
AITexExtract -p LEVEL_TEXTURES.ALL.PAK _extracted
*************************************************************

where "LEVEL_TEXTURES.ALL.PAK" is the package you wish to extract and "_extracted" is the output folder


Lastly this is only for people who know what they are doing! If you're incompetent don't mess with this and annoy me about errors!

