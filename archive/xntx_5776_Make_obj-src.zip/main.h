#define CM_FORMAT       9073
#define CM_FILE_SAVEAS	9072
#define CM_FILE_EXIT	9071
#define CM_FILE_OPEN	9070
#define CM_ABOUT        9069
#ifndef __MAIN_H__
#define __MAIN_H__

#include <windows.h>

/*  To use this exported function of dll, include this header
 *  in your project.
 */

#ifdef BUILD_DLL
    #define DLL_EXPORT __declspec(dllexport)
#else
    #define DLL_EXPORT __declspec(dllimport)
#endif


#ifdef __cplusplus
extern "C"
{
#endif

void DLL_EXPORT SomeFunction(const LPCSTR sometext);

#ifdef __cplusplus
}
#endif

#ifdef __cplusplus
extern "C"
{
#endif

DWORD DLL_EXPORT FindBytes(LPVOID lpFBuf, DWORD dwStart, DWORD dwSize, int nValue[], int Anzahl) ;

#ifdef __cplusplus
}
#endif

#ifdef __cplusplus
extern "C"
{
#endif

DWORD DLL_EXPORT _ReadFile(char szFileName[], LPVOID &lpFBuf, bool bWildCard, FILE *stream);

#ifdef __cplusplus
}
#endif

#ifdef __cplusplus
extern "C"
{
#endif

void DLL_EXPORT Float2_I3E750(float fZahl, int nValue[]) ;

#ifdef __cplusplus
}
#endif


#endif // __MAIN_H__
