from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Skyforge (materialLayer.bin)", ".bin")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
	#noesis.logPopup()
	return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    Magic = bs.readInt()
    if Magic != 0:
        return 0
    return 1
	
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    while bs.getOffset() < bs.getSize():
        texName = bs.readInt()
        origFileName = rapi.getLocalFileName(rapi.getInputName()).strip(".bin")
        datasize = bs.readInt()
        print(hex(datasize), ":datasize")
        data = bs.readBytes(datasize)
        #DXT5
        if datasize == 0x10:
            imgWidth = 4
            imgHeight = 4
        elif datasize == 0x40:
            imgWidth = 8
            imgHeight = 8
        elif datasize == 0x100:
            imgWidth = 16
            imgHeight = 16
        elif datasize == 0x400:
            imgWidth = 32
            imgHeight = 32
        elif datasize == 0x1000:
            imgWidth = 64
            imgHeight = 64
        elif datasize == 0x4000:
            imgWidth = 128
            imgHeight = 128
        elif datasize == 0x10000:
            imgWidth = 256
            imgHeight = 256
        elif datasize == 0x40000:
            imgWidth = 512
            imgHeight = 512
        elif datasize == 0x100000:
            imgWidth = 1024
            imgHeight = 1024
        print(imgWidth, "x", imgHeight)
        texName = origFileName + "_" + str(imgWidth) + "x" + str(imgHeight) + "_" + str(texName) 
        print(texName, ":texName")
        texFmt = noesis.NOESISTEX_DXT5
        #if datasize > 0x10000:            # display only images greater than 256x256
        #    texList.append(NoeTexture(texName, imgWidth, imgHeight, data, texFmt))
        texList.append(NoeTexture(texName, imgWidth, imgHeight, data, texFmt)) #display all images in file
    return 1