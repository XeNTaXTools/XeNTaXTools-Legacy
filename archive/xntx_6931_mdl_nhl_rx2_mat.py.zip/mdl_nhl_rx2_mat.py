#Noesis python importer - EA NHL games stadium container .rx2 files - version 1.0
from inc_noesis import *
import noesis
#rapi methods should only be used during handler callbacks
import rapi
#registerNoesisTypes is called by Noesis to allow the script to register formats.
#Do not implement this function in script files unless you want them to be dedicated format modules!
def registerNoesisTypes():
	handle = noesis.register("NHL Legacy (X360)", ".rx2")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadModel(handle, noepyLoadModel)
	noesis.logPopup()
	#print("The log can be useful for catching debug prints from preview loads.\nBut don't leave it on when you release your script, or it will probably annoy people.")
	return 1
#check if it's this type based on the data
def noepyCheckType(data):
    bs = NoeBitStream(data)
    Magic = bs.readBytes(7)
    if Magic != b'\x89\x52\x57\x34\x78\x62\x32':
        return 0
    return 1  

#load the model
def noepyLoadModel(data, mdlList):
   VInfo = []
   VOff = []
   VBufferSize = []
   FInfo = []   
   FOff = []
   FBufferSize = []
   MatInfo = []
   MatIndexInfo = []
   MatIndexTable = []
   TexIndexInfo = []
   TexIndex = []
   UVIndexInfo = []
   UVpos = []   
   MatNames = []
   NameInfo = []
   TexList = []
   MatList = []
   MaterialInfo = []
   MeshNames = []
   
   ctx = rapi.rpgCreateContext()
   bs = NoeBitStream(data, NOE_BIGENDIAN)
   bs.seek(0x20, NOESEEK_ABS)
   fileCount = bs.read(">i")
   bs.seek(12, NOESEEK_REL)
   fileTable = bs.read(">i")
   bs.seek(16, NOESEEK_REL)
   hdrSize = bs.read(">i")  
   bs.seek(fileTable[0], NOESEEK_ABS)
   meshCount = 0
   texCount = 0
   materialCount = 0
   ebCount = 0
   
   for i in range(0, fileCount[0]):
	    fileInfo = bs.read(">iiiii")
	    fileType = bs.readBytes(4)
	   			    
	    if fileType == b'\x00\x02\x00\x05':
	   		bs.seek(-48, NOESEEK_REL)
	   		info = bs.read(">iiiiiiiiiiii")
	   		VOff.append([info[0]])
	   		VBufferSize.append([info[2]])
	   		VInfo.append([info[6]])
	   				 			   		
	    elif fileType == b'\x00\x02\x00\x07':
	   		bs.seek(-48, NOESEEK_REL)
	   		info = bs.read(">iiiiiiiiiiii")
	   		FOff.append([info[0]])
	   		FBufferSize.append([info[2]])
	   		FInfo.append([info[6]])	   		

	    elif fileType == b'\x00\x02\x00\x09':
	   		meshCount +=1 

	    elif fileType == b'\x00\x02\x00\x04':
	   		UVIndexInfo.append([fileInfo[0]])
	   		
	    elif fileType == b'\x00\xEB\x00\x03':
	   		MatIndexInfo.append([fileInfo[0]])
	   		ebCount +=1
	   		
	    elif fileType == b'\x00\xEC\x00\x10':
	   		NameInfo.append([fileInfo[0]])
	    
	    elif fileType == b'\x00\xEF\x00\x01':
	   		TexIndexInfo.append([fileInfo[0]])

	    elif fileType == b'\x00\xEF\x00\x05':
	   		MatInfo.append([fileInfo[0]])
	   		materialCount +=1				 			   		
   
#Read material names
   bs.seek(NameInfo[0][0], NOESEEK_ABS)
   nameCount = bs.read(">HH")
   bs.seek(4, NOESEEK_REL)
   for i in range(0, nameCount[1]):
   		nameOff = bs.read(">i")
   		nameType = bs.readBytes(4)
   		nameIndex = bs.read(">i")
   		pos = bs.tell()
   		if nameType == b'\x00\xEF\x00\x05':
   			bs.seek(nameOff[0], NOESEEK_ABS)
   			MatNames.append(bs.readString())
   			bs.seek(pos, NOESEEK_ABS)	
   			
#Read material indices for meshes
   for i in range(0, ebCount):
   		bs.seek(MatIndexInfo[i][0] + 0x10, NOESEEK_ABS)
   		contents = bs.read(">i")
   		tablesize = bs.read(">i")
   		bs.seek(tablesize[0] + 12, NOESEEK_REL)
   		for j in range(0, contents[0]):
   				materialIndex = bs.read(">i")
   				MatIndexTable.append(materialIndex[0])
   				bs.seek(40, NOESEEK_REL)

#Read texture indices for materials
   for i in range(0, materialCount):
   		bs.seek(TexIndexInfo[i][0] + 256, NOESEEK_ABS)
   		index = bs.read(">i")
   		textindex = index[0] // 2
   		TexIndex.append(str(textindex)+".tga")
   		
   for i in range(0, materialCount):
   		material = NoeMaterial(MatNames[i], TexIndex[i])
   		MatList.append(material) 

   for i in range(0, meshCount):
   		bs.seek(UVIndexInfo[i][0] + 16, NOESEEK_ABS)
   		for j in range(0, 4):
   			position = bs.read(">i")
   			type = bs.readBytes(8)
   			if type == b'\x00\x2C\x23\xA5\x00\x05\x00\x06':
   				UVpos.append(position[0]) 
   		
 #Construct Models		  			   
   for i in range(0, meshCount):
   		print(UVpos[i])
   		bs.seek(VInfo[i][0] + 32, NOESEEK_ABS) #Seek to vertices info
   		VData = bs.read(">HHi") 
   		VBsize = VData[0]
   		VCount = VData[2]
   		bs.seek(FInfo[i][0] + 32, NOESEEK_ABS) #Seek to faces info  
   		FCount = bs.read(">HH")   
   		bs.seek(VOff[i][0] + hdrSize[0], NOESEEK_ABS) #Seek to Vertices Start
   		VertBuff = bs.readBytes(VBufferSize[i][0])
   		rapi.rpgSetOption(noesis.RPGOPT_BIGENDIAN, 1)
   		rapi.rpgBindPositionBufferOfs(VertBuff, noesis.RPGEODATA_FLOAT, VBsize, 0)
   		rapi.rpgBindUV1BufferOfs(VertBuff, noesis.RPGEODATA_FLOAT, VBsize, UVpos[i])
   		bs.seek(FOff[i][0] + hdrSize[0], NOESEEK_ABS) #Seek to Faces Start
   		FaceBuff = bs.readBytes(FBufferSize[i][0])
   		rapi.rpgSetMaterial(MatNames[((MatIndexTable[i] - 1) // 3) - 28])
   		rapi.rpgCommitTriangles(FaceBuff, noesis.RPGEODATA_USHORT, FCount[1], noesis.RPGEO_TRIANGLE, 1)
   		mdl = rapi.rpgConstructModel()
   		mdl.setModelMaterials(NoeModelMaterials(TexList, MatList))
   		mdlList.append(mdl)         #important, don't forget to put your loaded model in the mdlList
   		rapi.rpgClearBufferBinds()
   		rapi.rpgReset()   
   
   return 1