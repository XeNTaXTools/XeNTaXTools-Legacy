#Lost Planet 2 [PC] .TEX [PC] - ".TEX" Loader
#By Zaramot
#modified and rearranged further by Acewell :)
#modified even further by PedatorCZ :3
#v1.03 <-- Yes I did dare to change version (PedatorCZ)

from inc_noesis import *
import subprocess

def registerNoesisTypes():
	handle = noesis.register("Lost Planet 2 [PC]", ".tex")
	noesis.setHandlerTypeCheck(handle, texCheckType)
	noesis.setHandlerLoadRGBA(handle, texLoadDDS)
	#noesis.logPopup()
	return 1
		
def texCheckType(data):
	bs = NoeBitStream(data)
	fileMagic = bs.readUInt()
	if fileMagic != 0x584554:
		return 0
	return 1

def texLoadDDS(data, texList):
	bs = NoeBitStream(data)
	bs.seek(4, NOESEEK_ABS)
	flags0 = bs.readUInt()
	flags1 = bs.readUInt()
	flags2 = bs.readUInt()
	imgFmt = bs.readUInt()
	
	useDX10 = (flags0>>8) & 0xff; 
	usemips = flags1 & 0x4; 
	mipCount = (flags1>>4) & 0xf; 
	imgHeight = (flags1>>17) & 0x1fff;
	imgWidth = flags2 & 0xfff;
	
	dataOff = 20
	if not usemips:
		dataOff = (bs.readUInt())
		
	dataSize = len(data) - dataOff
	
	bs.seek(dataOff, NOESEEK_ABS) #data start
	data = bs.readBytes(dataSize)
    #DXT1
	if imgFmt == 0x13 or imgFmt == 0x1e:
		texFmt = noesis.NOESISTEX_DXT1
	#ATI1/DXT1
	elif imgFmt == 0x19:
		if useDX10:
			data = rapi.imageDecodeDXT(data, imgHeight, imgWidth, noesis.FOURCC_ATI1)
			texFmt = noesis.NOESISTEX_RGBA32
		else:
			texFmt = noesis.NOESISTEX_DXT1
    #DXT5
	elif imgFmt == 0x17 or imgFmt == 0x1f or imgFmt == 0x20:
		texFmt = noesis.NOESISTEX_DXT5
	#DXT2
	elif imgFmt == 0x15:
		data = rapi.imageDecodeDXT(data, imgHeight, imgWidth, noesis.FOURCC_BC2)
		texFmt = noesis.NOESISTEX_RGBA32
	#RGBA8888
	elif imgFmt == 0x27:
		texFmt = noesis.NOESISTEX_RGBA32
	else:
		print("WARNING: Unhandled image format")
	tex = (NoeTexture(rapi.getInputName(), imgHeight, imgWidth, data, texFmt))
	texList.append(tex)
	return 1