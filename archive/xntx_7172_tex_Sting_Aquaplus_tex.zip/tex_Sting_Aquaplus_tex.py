from inc_noesis import *

# debug level
# 0 - info/warn/error messages (hidden)
# 1 - 0 + pop up Noesis Debug Log
# 2 - 1 + debug messages and some variables
DEBUGLEVEL = 0
#-------------------------------------------------------------------------------
def registerNoesisTypes():
    handle = noesis.register("Sting/Aquaplus TEX", ".tex")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    if DEBUGLEVEL >= 1: noesis.logPopup()
    return 1
#-------------------------------------------------------------------------------
def noepyCheckType(data):
    bs = NoeBitStream(data)
    bs.setEndian(0)
    ID = bs.readUShort()
    bs.seek(0, 0)

    if bs.readBytes(4) == b"ZLIB":
        size = bs.readUInt()
        zsize = bs.readUInt()
        cmpData = bs.readBytes(zsize)
        decompData = rapi.decompInflate(cmpData, size)
        bs = NoeBitStream(decompData)
        ID = bs.readUShort()

    bs.seek(0, 0)
    if bs.readBytes(8) == b"Texture ": return 1
    elif ID & 0x778B: return 1
    else: return 0
#-------------------------------------------------------------------------------
def noepyLoadRGBA(data, texList):
    # script parameters presets
    # Endian - 0 for little, 1 for BIG
    # HdrLn - length of "Texture " magic bytes, including spaces
    # ChSwap - BGRA8 instead of RGBA8
    # Is64bit - applies to newer PC releases
    ScriptParams = (
    #	 Endian	HdrLn	ChSwap	Is64bit
        (1,	8,	True,	False),	#0 (PS3) Date A Live; White Album
        (0,	8,	False,	False),	#1 (PSV) Date A Live; Hyperdevotion Noire; Utawarerumono
        (0,	20,	False,	False),	#2 (PSV) Dungeon Travelers 2-2
        (0,	8,	True,	False),	#3 (PC) Hyperdevotion Noire
        (0,	12,	False,	True),	#4 (PC) Utawarerumono
        (0,	20,	True,	True)	#5 (PC) Date A Live: Rio Reincarnation
#        (,	,	,	),	#x Add preset here
#        (,	,	,	)	#x Add preset here
    #	 Endian	HdrLn	ChSwap	Is64bit
    )
    GamePreset = 3 # select the game from the list above, numbers start from 0

    global Endian
    if GamePreset in range(len(ScriptParams)): Endian, HeaderLength, ChannelSwap, Is64bit = ScriptParams[GamePreset]
    else: Endian, ChannelSwap, HeaderLength, Is64bit = (0, 8, True, False) # defaults to Hyperdevotion Noire PC
#    Endian, ChannelSwap, HeaderLength, Is64bit = (0, 8, True, False) # manual override here
#---------------------------------------
    bs = NoeBitStream(data)
    bs.setEndian(0)
    ID = bs.readUShort()
    bs.seek(0, 0)

    if bs.readBytes(4) == b"ZLIB":
        print("[i] ZLIB compressed.")
        size = bs.readUInt()
        zsize = bs.readUInt()
        print("[i] Compressed size: "+repr(zsize)+" B. Decompressed size: "+repr(size)+" B. Ratio: "+repr(round(zsize/size*100, 2))+"%.")
        cmpData = bs.readBytes(zsize)
        decompData = rapi.decompInflate(cmpData, size)
        bs = NoeBitStream(decompData)
        ID = bs.readUShort()

    bs.seek(0, 0)
    if bs.readBytes(HeaderLength) == (b"Texture " + (HeaderLength - 8) * b" "):
        if DEBUGLEVEL >= 2: print("[DEBUG] Full header. Length: "+repr(HeaderLength)+".")
        DUMMY = bs.readUInt() # section size, consider as fileSize
    elif ID & 0x778B:
        if DEBUGLEVEL >= 2: print("[DEBUG] Short header.")
        bs.seek(0, 0)
    else: print("[x] Unexpected magic bytes!"); return 0
#---------------------------------------
    bs.setEndian(Endian)

    if Is64bit: TMP = bs.readUInt64(); TEXFMT = TMP & 0xFFFF; TEXFLAGS = TMP >> 48
    else: TMP = bs.readUInt(); TEXFMT = TMP & 0xFFFF; TEXFLAGS = TMP >> 16
    if DEBUGLEVEL >= 2: print("[DEBUG] TEXFMT: "+hex(TEXFMT)+"; TEXFLAGS: "+hex(TEXFLAGS))
    dataSize = bs.readUInt() # payload (+palette if applicable) size

    if Is64bit: width = bs.readUShort(); height = bs.readUShort()
    else:
        width = bs.readUInt(); height = bs.readUInt()
        if bs.readUInt() != width: bs.seek(-4, 1)
        if bs.readUInt() != height: bs.seek(-4, 1)

    if TEXFMT & 0x4008:
        if ChannelSwap: fmtText = "BGRA8"; texFmt = "b8g8r8a8"
        else: fmtText = "RGBA8"; texFmt = "r8g8b8a8"
    elif TEXFMT & 0x2002: fmtText = "DXT5"; texFmt = noesis.NOESISTEX_DXT5; BytesPerBlock = 8
    elif TEXFMT & 0x1001: fmtText = "DXT1"; texFmt = noesis.NOESISTEX_DXT1; BytesPerBlock = 4
    elif TEXFMT & 0x400: fmtText = "LA88"; texFmt = "g8a8"
    elif TEXFMT & 0x200: fmtText = "RGBA8 (palletized)"; texFmt = "r8g8b8a8"
    elif TEXFMT & 0x100: fmtText = "L4"; texFmt = "g4"
    elif TEXFMT & 0x80: fmtText = "L8"; texFmt = "g8"
    else: print("[x] Unknown TEXFMT! ("+hex(TEXFMT)+")"); return None

    print("[i] Format: "+fmtText+"; WxH: "+repr(width)+"x"+repr(height)+"; data start: "+hex(bs.tell())+"; data size: "+repr(dataSize)+" B.")
#---------------------------------------
    if TEXFLAGS & 1:
        print("[i] PNG image.")
        data = bs.readBytes(dataSize)
        data = rapi.loadTexByHandler(data, ".png")
        data.name = "test.png"
        data = rapi.imageGetTexRGBA(data)
        texFmt = noesis.NOESISTEX_RGBA32
    else:
        TMP = bs.readBytes(4)
        bs.seek(-4, 1)
        data = bs.readBytes(dataSize)
        if TEXFLAGS & 4 or TEXFMT & 8 or TMP == b"LZ77": print("[i] Sting/Aquaplus LZSS."); data = decompStingAquaplusLZSS(data, dataSize)

        if TEXFMT & 0x200: data = rapi.imageDecodeRawPal(data[:-0x400], data[-0x400:], width, height, 8, texFmt); texFmt = noesis.NOESISTEX_RGBA32
        elif TEXFMT & 0x3000: data = rapi.imageFromMortonOrder(data, width>>1, height>>2, BytesPerBlock) # PSVita specific swizzling, thanks Acewell
        elif TEXFMT & 0x4588: data = rapi.imageDecodeRaw(data, width, height, texFmt); texFmt = noesis.NOESISTEX_RGBA32

    texList.append(NoeTexture(rapi.getInputName(), width, height, data, texFmt))

    return 1
#-------------------------------------------------------------------------------
def decompStingAquaplusLZSS(data, zsize):
    data = NoeBitStream(data)
    if noeStrFromBytes(data.readBytes(4)) != "LZ77": return None
    data.setEndian(Endian)
    size = data.readUInt()
    print("[i] Compressed size: "+repr(zsize)+" B. Decompressed size: "+repr(size)+" B. Ratio: "+repr(round(zsize/size*100, 2))+"%.")
    LZSSOpCount = data.readUInt()
    LZSSDataOffset = data.readUInt()
    LZSSFlagsLength = LZSSDataOffset - 16

    flags = NoeBitStream(data.readBytes(LZSSFlagsLength))
    src = NoeBitStream(data.readBytes(zsize-LZSSDataOffset))
    dst = bytearray(size)
    FlagBufferBitCount = 0
    dstPos = 0

    for i in range(LZSSOpCount):
        if FlagBufferBitCount == 0:
            FLAGS = flags.readUByte()
            FlagBufferBitCount = 8

        if FLAGS & 0x80:
            b = src.readUByte()
            c = src.readUByte() + 3
            dst[dstPos:dstPos+c] = dst[dstPos-b:dstPos-b+c]
            dstPos += c
        else:
            dst[dstPos] = src.readUByte()
            dstPos += 1

        FLAGS <<= 1
        FlagBufferBitCount -= 1

    return dst
#-------------------------------------------------------------------------------