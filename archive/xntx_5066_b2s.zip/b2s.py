#sample class
from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Beyond 2 Souls", ".bin1")
	noesis.setHandlerTypeCheck(handle, binModCheckType)
	noesis.setHandlerLoadModel(handle, binModLoadModel)
	#noesis.logPopup()

	return 1


def binModCheckType(data):
	td = NoeBitStream(data)
	return 1

class binFile: 
         
	def __init__(self, bs):
		self.bs = bs
		rapi.rpgSetOption(noesis.RPGOPT_BIGENDIAN, 1)
		self.texList  = []
		self.matList  = [] 
		self.boneList = []
		self.boneMap  = []
		self.offsetList = []
		self.meshOffsets = []

	#1CB145 prim edge
	#0x2D2263 - 0x0D0 - 0xC - Eyes
	#0x2D3B63 - 0x0EE - 0xC - Shoes
	#0x2D5DB3 - 0x072 - 0xC - part of shoe?
	#0x2E6073 - 0x06C - 0xC - eye lash
	#0x2E7233 - 0x2E0 - 0xC - arm
	#0x2EF5A3 - 0x2D8 - 0xC - arm cloth
	#0x2F7973 - 0x2D0 - 0xC - other game
	#0x2FF6D3 - 0x0FD - 0xC - fingers
	#0x302953 - 0x2D0 - 0xC - half of face - 0x3022B3 - 06 A0 - 0F 60
	#0x30A743 - 0x168 - 0xC - more of face
	def loadAll(self, bs):
		indexCount = 0xEEB
		indexSize = 0x6A0
		bs.seek(0x3022B3, NOESEEK_ABS)
		edgeData = bs.readBytes(indexSize)
		edgeDecomp = rapi.decompressEdgeIndices(edgeData, indexCount)
		for i in range(0, indexCount):
			t = edgeDecomp[i*2]
			edgeDecomp[i*2] = edgeDecomp[i*2 + 1]
			edgeDecomp[i*2 + 1] = t

		bs.seek(0x302953, NOESEEK_ABS)
		vertCount = 0x2D0
		vSize = 0xC
		vertBuff = bs.readBytes(vSize * vertCount)
		rapi.rpgBindPositionBufferOfs(vertBuff, noesis.RPGEODATA_FLOAT, vSize, 0)
		#rapi.rpgCommitTriangles(None, noesis.RPGEODATA_USHORT, vertCount, noesis.RPGEO_POINTS, 1)
		rapi.rpgCommitTriangles(edgeDecomp, noesis.RPGEODATA_USHORT, indexCount, noesis.RPGEO_TRIANGLE, 1)

def binModLoadModel(data, mdlList):
	ctx = rapi.rpgCreateContext()
	bin = binFile(NoeBitStream(data, NOE_BIGENDIAN))
	bin.loadAll(bin.bs)
	try:
		mdl = rapi.rpgConstructModel()
	except:
		mdl = NoeModel()
	mdl.setModelMaterials(NoeModelMaterials(bin.texList, bin.matList))
	mdlList.append(mdl); mdl.setBones(bin.boneList)	
	return 1