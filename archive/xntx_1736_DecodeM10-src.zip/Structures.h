#pragma once

#pragma pack(push, 4)

struct S_inner_file_data // size: 3396
{
    void* CompressedData;
    uint32_t Bits;
    uint32_t BitCount;
    uint32_t FirstBit;
    uint32_t Second4Bits;
    float FloatTable[64];
    uint32_t Table1[12];
    uint32_t Table2[12];
    uint32_t BigTable[324];
    float SampleBuffer[432];
};

#pragma pack(pop)
