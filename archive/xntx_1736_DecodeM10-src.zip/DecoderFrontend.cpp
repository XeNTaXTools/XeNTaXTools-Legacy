#include "stdafx.h"
#include "DecoderFrontend.h"
#include "Structures.h"


extern "C" void mtInitializeDecoder(S_inner_file_data* Inner, const void* InputBuffer);
extern "C" void mtDecodeBlock(S_inner_file_data* Inner);

mtDecoder::mtDecoder() :
        m_InputBuffer(NULL),
        m_Input(NULL),
        m_SampleBufferOffset(0),
        m_SamplesDecodedSoFar(0),
        m_TotalSampleCount(0)
{
    return;
}

mtDecoder::~mtDecoder()
{
    Clear();
    return;
}

void mtDecoder::Initialize(std::istream& Input)
{
    // Calculate the file size
    std::streamsize FileSize;
    Clear();

    Input.seekg(0, std::ios_base::end);
    FileSize = Input.tellg();
    Input.seekg(0);

    if (FileSize < 1)
    {
        std::cerr << "Empty file." << std::endl;
        return;
    }

    // Read the PT header
    if (!ParsePTHeader(Input))
    {
        return;
    }

    // Load the file in
    std::streamsize DataSize;
    DataSize = FileSize - Input.tellg();
    m_InputBuffer = new uint8_t[DataSize];
    Input.read((char*)m_InputBuffer, DataSize);

    std::cout << "Total sample count: " << m_TotalSampleCount << std::endl;

    // Initialize the decoder
    m_Input = new S_inner_file_data;
    try
    {
        mtInitializeDecoder(m_Input, m_InputBuffer);
        /*std::ofstream Output;
        Output.open("log", std::ios_base::out | std::ios_base::binary);
        Output.write((char*)m_Input, sizeof(S_inner_file_data));*/
    }
    catch (...)
    {
        std::cerr << "The decoder could not be initialized (bug in program)." << std::endl;
    }
    m_SampleBufferOffset = 432;
    m_SamplesDecodedSoFar = 0;
    return;
}

union mtFloatInt
{
    float Float;
    uint32_t Int;
};

unsigned long mtDecoder::Decode(short* OutputBuffer, unsigned long SampleCount)
{
    if (!m_TotalSampleCount)
    {
        return 0;
    }

    for (unsigned long i = 0; i < SampleCount; i++)
    {
        mtFloatInt Sample;
        Sample.Int = 0x4B400000;

        if (m_SampleBufferOffset >= 432)
        {
            try
            {
                mtDecodeBlock(m_Input);
            }
            catch (...)
            {
                std::cerr << "The decoder encountered a problem (bug in program)." << std::endl;
                return i;
            }
            m_SampleBufferOffset = 0;
        }

        Sample.Float += m_Input->SampleBuffer[m_SampleBufferOffset];
        m_SampleBufferOffset++;
        m_SamplesDecodedSoFar++;

        unsigned long Clipped;
        Clipped = Sample.Int & 0x1FFFF;
        if (Clipped > 0x7FFF && Clipped < 0x18000)
        {
            if (Clipped >= 0x10000)
            {
                Clipped = 0x8000;
            }
            else
            {
                Clipped = 0x7FFF;
            }
        }

        OutputBuffer[i] = (short)Clipped;

        if (m_SamplesDecodedSoFar >= m_TotalSampleCount)
        {
            return i + 1;
        }
    }
    return SampleCount;
}

void mtDecoder::Clear()
{
    delete[] m_InputBuffer;
    m_InputBuffer = NULL;
    delete m_Input;
    m_Input = NULL;
    return;
}

static unsigned long ReadBytes(std::istream& Input, uint8_t count)
{
    uint8_t i;
    uint8_t byte;
    unsigned long result;

    result = 0L;
    for (i = 0; i < count; i++)
    {
        Input.read((char*)&byte, 1);
        result <<= 8;
        result |= byte;
    }
    return result;
}

bool mtDecoder::ParsePTHeader(std::istream& Input)
{
    // Signature
    char Sig[2];
    Input.read(Sig, 2);
    if (memcmp(Sig, "PT", 2) != 0)
    {
        std::cerr << "Missing PT signature." << std::endl;
        return false;
    }

    Input.seekg(2, std::ios_base::cur);

    // Data offset
    uint32_t DataOffset;
    Input.read((char*)&DataOffset, 4);

    // Read in the header (code borrowed from Valery V. Anisimovsky (samael@avn.mccme.ru) )
    unsigned int CompressionType;
    uint8_t byte;
    bool bInHeader;
    bool bInSubHeader;

    bInHeader = true;
    while (bInHeader)
    {
        Input.read((char*)&byte, 1);
        switch (byte) // parse header code
        {
        case 0xFF: // end of header
            bInHeader = false;
        case 0xFE: // skip
        case 0xFC: // skip
            break;
        case 0xFD: // subheader starts...
            bInSubHeader = true;
            while (bInSubHeader)
            {
                Input.read((char*)&byte, 1);
                switch (byte) // parse subheader code
                {
                case 0x83:
                    Input.read((char*)&byte, 1);
                    CompressionType = ReadBytes(Input, byte);
                    break;
                case 0x85:
                    Input.read((char*)&byte, 1);
                    m_TotalSampleCount = ReadBytes(Input, byte);
                    break;
                case 0xFF:
                    break;
                case 0x8A: // end of subheader
                    bInSubHeader = false;
                default: // ???
                    Input.read((char*)&byte, 1);
                    Input.seekg(byte, std::ios_base::cur);
                }
            }
            break;
        default:
            Input.read((char*)&byte, 1);
            if (byte == 0xFF)
                Input.seekg(4, std::ios_base::cur);
            Input.seekg(byte, std::ios_base::cur);
        }
    }

    // Print some things out
    std::cout << "Compression: " << CompressionType << std::endl;

    // Seek to the data offset
    Input.seekg(DataOffset);
    return true;
}
