﻿using System;
using System.Text;
using System.IO;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace ptr2sound
{
	/// <summary>
	/// Good/Cool/Bad/Awful converter
	/// </summary>
	public partial class Good : Form
	{
		public Good()
		{
			InitializeComponent();
			this.FormBorderStyle = FormBorderStyle.FixedSingle;
		}
		
		const int st1c = 34755584;
		const int st1g = 34755584;
		const int st1ba = 67608576;
		
		const int st2c = 43478016;
		const int st2g = 42121216;
		const int st2ba = 79986688;
		
		const int st3c = 45651968;
		const int st3g = 47423488;
		const int st3ba = 90845184;
		
		const int st4c = 43966464;
		const int st4g = 43966464;
		const int st4ba = 86884352;
		
		const int st5c = 37473280;
		const int st5g = 36595712;
		const int st5ba = 71266304;
		
		const int st6c = 43062272;
		const int st6g = 45321216;
		const int st6ba = 90497024;
		
		const int st7c = 43732992;
		const int st7g = 39853056;
		const int st7ba = 77686784;
		
		const int st8c = 68538368;
		const int st8g = 46662656;
		const int st8ba = 86691840;
		
		int stageSize;
		bool cancelProcess;
		string outputDir;
				
		string WP2Data;
		string inputData;
		string badInputData;
		string awfulInputData;
		
		string WP2outputDir;
		string badOutputDir;
		string awfulOutputDir;
		
		void wavDump(byte[] deinterData1, string outDir)
		{
			FileStream wavfile = new FileStream(outDir, FileMode.Create);
			BinaryWriter wav = new BinaryWriter(wavfile);
			wav.Write(Encoding.ASCII.GetBytes("RIFF")); //chunkid
			wav.Write(36 + deinterData1.Length); //length of all data after this
			wav.Write(Encoding.ASCII.GetBytes("WAVE")); //format
			wav.Write(Encoding.ASCII.GetBytes("fmt ")); //subchunk1id
			wav.Write(16); //subchunk1 size
			wav.Write((ushort)1); //audioformat (pcm = 1)
			wav.Write((ushort)2); //channels
			wav.Write(48000); //samplerate
			wav.Write(192000); //byterate, which is (samplerate * bitspersample * channels) / 8
			wav.Write((ushort)4); //blockalign (channels * bitspersample/8)
			wav.Write((ushort)16); //bitspersample
			wav.Write(Encoding.ASCII.GetBytes("data")); //subchunk2 id
			wav.Write(deinterData1.Length); //subchunk2 size
			wav.Write(deinterData1); //the data
			wavfile.Flush();
			wav.Close();
			
		}
		
		byte[] sizeFix(byte[] input, bool bad)
		{
			//make sure data is right size
			if (input.Length != stageSize)
			{
				int diff = Math.Abs(input.Length - stageSize);
				if (diff > (stageSize / 4))
				{
					string warning = "";
					
					if (input.Length > stageSize)
					{
						if (RankCombo.Text == "Bad+Awful")
						{
							if (bad){ warning = "Your Bad input wav is way too big! If you continue, the whole song will not play in the result!";}
							else { warning = "Your Awful input wav is way too big! If you continue, the whole song will not play in the result!";}
						}
						
						else { warning = "Your input wav is way too big! If you continue, the whole song will not play in the result!"; }
						
					}
					if (input.Length < stageSize)
					{
						if (RankCombo.Text == "Bad+Awful")
						{
							if (bad){ warning = "Your Bad input wav is way too small! If you continue, there will be noticable silence in the result";}
							else { warning = "Your Awful input wav is way too small! If you continue, there will be noticable silence in the result";}
						}
						else{ warning = "Your input wav is way too small! If you continue, there will be noticable silence in the result";}

					}
					
					var result = MessageBox.Show(warning, "Warning", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
					if (result == DialogResult.Cancel) 
					{
						cancelProcess = true;
						return null;
					}
				}
				
				byte[] deInterDataFixed = new byte[stageSize];
				if (input.Length > stageSize) { Buffer.BlockCopy(input,0,deInterDataFixed,0,stageSize);}
				else { Buffer.BlockCopy(input,0,deInterDataFixed,0,input.Length); }
				
				return deInterDataFixed;
				
			}
			return input;
		}
		
		void wavExtract()
		{
			//byte[] dataLength = new byte[4];
			//Buffer.BlockCopy(inputData, 36, dataLength, 0, 4);
			if (RankCombo.Text == "Good" || RankCombo.Text  == "Cool")
			{
				byte[] gcinputData = File.ReadAllBytes(inputData);
				byte[] wavSubChunk2Size = new byte[4];
				Buffer.BlockCopy(gcinputData, 40, wavSubChunk2Size, 0, 4);
				int dataLength = BitConverter.ToInt32(wavSubChunk2Size, 0);
				byte[] deinterData = new byte[dataLength];
				//only take raw data out of wav (get rid of metadata)
				Buffer.BlockCopy(gcinputData, 44, deinterData, 0, dataLength);
				
				byte[] gcDeInterData = sizeFix(deinterData, false);
				if (cancelProcess){ return;}
				
				interleave(gcDeInterData,null,true);

			}
			else
			{
				byte[] badData = File.ReadAllBytes(badInputData);
				byte[] awfulData = File.ReadAllBytes(awfulInputData);
				
				byte[] wavSubChunk2Size = new byte[4];
				Buffer.BlockCopy(badData, 40, wavSubChunk2Size, 0, 4);
				int dataLength = BitConverter.ToInt32(wavSubChunk2Size, 0);
				byte[] deinterData = new byte[dataLength];
				//only take raw data out of wav (get rid of metadata)
				Buffer.BlockCopy(badData, 44, deinterData, 0, dataLength);
				
				byte[] badInterData = sizeFix(deinterData, true);
				if (cancelProcess){ return;}
				
				
				Buffer.BlockCopy(awfulData, 40, wavSubChunk2Size, 0, 4);
				dataLength = BitConverter.ToInt32(wavSubChunk2Size, 0);
				deinterData = new byte[dataLength];
				//only take raw data out of wav (get rid of metadata)
				Buffer.BlockCopy(awfulData, 44, deinterData, 0, dataLength);
				
				byte[] awfulInterData = sizeFix(deinterData, false);
				if (cancelProcess){ return;}
				
				interleave(badInterData,awfulInterData,false);
			}
			
		}
		
		void deinterleave()
		{	
			byte[] interData = File.ReadAllBytes(WP2Data);
				
			if (RankCombo.Text == "Good" || RankCombo.Text  == "Cool")
			{
				//int blocks = inputData.Length / 400;
				byte[] deinterData = new byte[interData.Length];
				for (int i = 0; i < interData.Length; i+= 1024)
				{
					for (int i2 = 0; i2 < 512; i2+= 2)
					{
						Buffer.BlockCopy(interData, i + i2, deinterData, i + i2 + i2, 2);
						Buffer.BlockCopy(interData, i + i2 + 512, deinterData, i + i2 + i2 + 2, 2);
					}
				}
				wavDump(deinterData, outputDir);
				//File.WriteAllBytes(outputDir, audioData1);
			}
			else //if bad/awful
			{
				//int blocks = inputData.Length / 400;
				byte[] badDeinterData = new byte[interData.Length / 2];
				byte[] awfulDeinterData = new byte[interData.Length / 2];
				for (int i = 0; i < interData.Length; i+= 2048)
				{
					for (int i2 = 0; i2 < 512; i2+= 2)
					{
						Buffer.BlockCopy(interData, i + i2, badDeinterData, i/2 + i2 + i2, 2);
						Buffer.BlockCopy(interData, i + i2 + 512, badDeinterData, i/2 + i2 + i2 + 2, 2);
						Buffer.BlockCopy(interData, i + i2 + 1024, awfulDeinterData, i/2 + i2 + i2, 2);
						Buffer.BlockCopy(interData, i + i2 + 1536, awfulDeinterData, i/2 + i2 + i2 + 2, 2);
					}
				}
				//File.WriteAllBytes(outputDir, audioData1);
				wavDump(badDeinterData, badOutputDir);
				wavDump(awfulDeinterData, awfulOutputDir);
			}
			
		}
		
		void interleave(byte[] deinterData1, byte[] deinterData2, bool good)
		{	
			if (good) //if good/cool
			{
				
				byte[] interData1 = new byte[deinterData1.Length];
				for (int i = 0; i < deinterData1.Length; i+= 1024) //1024 = 0x400
				{
					for (int i2 = 0; i2 < 512; i2+= 2) //since working with int offsets for byte arrays, no need to convert 0x2 to dec
					{
						Buffer.BlockCopy(deinterData1, i + i2 + i2, interData1, i + i2, 2); //put first channel bytes into first 0x200 chunk
						Buffer.BlockCopy(deinterData1, i + i2 + i2 + 2, interData1, i + i2 + 512, 2); //put second channel bytes into second 0x200 chunk
					}
				}
				File.WriteAllBytes(outputDir, interData1);
			}
			
			else //if bad/awful
			{
				byte[] interData1 = new byte[deinterData1.Length * 2];
				for (int i = 0; i < interData1.Length; i+= 2048)
				{
					for (int i2 = 0; i2 < 512; i2+= 2)
					{
						Buffer.BlockCopy(deinterData1, i/2 + i2 + i2, interData1, i + i2, 2);
						Buffer.BlockCopy(deinterData1, i/2 + i2 + i2 + 2, interData1, i + i2 + 512, 2);
						Buffer.BlockCopy(deinterData2, i/2 + i2 + i2, interData1, i + i2 + 1024, 2);
						Buffer.BlockCopy(deinterData2, i/2 + i2 + i2 + 2, interData1, i + i2 + 1536, 2);
					}
				}
				File.WriteAllBytes(WP2outputDir, interData1);
			}
			

		}

		void ProcessButtonClick(object sender, EventArgs e)
		{
			checkStageSize();
			if (OutputButton.Text == "Select Output (WAV)")
			{
				deinterleave();
			}
			else if (OutputButton.Text == "Select Output (WP2)")
			{
				wavExtract();
			}
			else if (OutputButton2.Text == "Select Awful Output")
			{
				deinterleave();
			}
			else
			{
				wavExtract();
			}
			if (cancelProcess) { return;};
			MessageBox.Show("Conversion Done");
		}
		
		void InputButtonClick(object sender, EventArgs e)
		{
			OpenFileDialog openFileDialog1 = new OpenFileDialog();
			openFileDialog1.Filter = "WP2 or WAV|*.WP2;*.wav";
		    openFileDialog1.Title = "Select a PaRappa 2 WP2 or WAV file";  
		 
		    if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)  
		    {  	
		    	if (Path.GetExtension(openFileDialog1.FileName).ToUpper() == ".WP2")
		    	{
		    		textBox1.Text = Path.GetFileName(openFileDialog1.FileName);
		    		
		    		if (RankCombo.Text == "Good" || RankCombo.Text == "Cool")
		    		{
		    			OutputButton.Text = "Select Output (WAV)";
		    			OutputButton.Enabled = true;
		    			OutputButton2.Enabled = false;
		    			OutputButton3.Enabled = false;
		    			OutputButton2.Hide();
		    			OutputButton3.Hide();
		    			textBox1.Show();
		    			textBox3.Hide();
		    			textBox4.Hide();
		    			
		    			textBox1.Text = Path.GetFileName(openFileDialog1.FileName);
		    			ProcessButton.Size = new Size(373, 118);
		    			ProcessButton.Location = new Point(13, 132);
			    		
			    		textBox2.Text = "";
			    		textBox3.Text = "";
			    		textBox4.Text = "";
			    		
			    		
			    		
		    		}
		    		
		    		else if (RankCombo.Text == "Bad+Awful")
		    		{
		    			OutputButton.Text = "Select Bad Output";
		    			OutputButton2.Text = "Select Awful Output";
		    			OutputButton.Enabled = true;
		    			OutputButton2.Enabled = true;
		    			OutputButton3.Enabled = false;
		    			OutputButton2.Show();
		    			OutputButton3.Hide();
		    			textBox1.Show();
		    			textBox3.Show();
		    			textBox4.Hide();
		    			
		    			textBox1.Text = Path.GetFileName(openFileDialog1.FileName);
		    			ProcessButton.Size = new Size(373, 87);
		    			ProcessButton.Location = new Point(13, 163);
		    			
		    			
		    			textBox2.Text = "";
			    		textBox3.Text = "";
			    		textBox4.Text = "";
		    			
		    		}
		    		
		    		WP2Data = openFileDialog1.FileName;
		    	}
		    	
		    	else
		    	{
		    		if (RankCombo.Text == "Good" || RankCombo.Text == "Cool")
			    	{
			    		OutputButton.Text = "Select Output (WP2)";
			    		OutputButton2.Show();
			    		OutputButton.Enabled = true;
			    		OutputButton2.Enabled = false;
			    		OutputButton3.Enabled = false;
			    		OutputButton2.Hide();
			    		OutputButton3.Hide();
			    		textBox1.Show();
			    		textBox3.Hide();
			    		textBox4.Hide();
			    			
			    		ProcessButton.Size = new Size(373, 118);
			    		ProcessButton.Location = new Point(13, 132);
			    		
				    	textBox1.Text = Path.GetFileName(openFileDialog1.FileName);
				    	textBox2.Text = "";
				    	textBox3.Text = "";
				    	textBox4.Text = "";
				    	
				    	inputData = openFileDialog1.FileName;
				    }
		    		
			    	else if (RankCombo.Text == "Bad+Awful")
			    	{
			    		OutputButton.Text = "Open Bad WAV";
			    		OutputButton2.Text = "Open Awful WAV";
			    		OutputButton3.Text = "Select Output (WP2)";
			    		
			    		OutputButton.Enabled = true;
			    		OutputButton2.Enabled = true;
			    		OutputButton3.Enabled = true;
			    		OutputButton2.Show();
			    		OutputButton3.Show();
			    		textBox1.Hide();
			    		textBox2.Show();
			    		textBox3.Show();
			    		textBox4.Show();
			    		
			    		textBox2.Text = Path.GetFileName(openFileDialog1.FileName);
				    	textBox3.Text = "";
				    	textBox4.Text = "";

			    		ProcessButton.Size = new Size(373, 58);
			    		ProcessButton.Location = new Point(13, 194);
			    		
			    		badInputData = openFileDialog1.FileName;
			    	}
		    	}
		    	
		    }
		    
		}
		
		void OutputButtonClick(object sender, EventArgs e)
		{
			
			if (OutputButton.Text == "Select Bad Output")
			{ 
				SaveFileDialog saveFileDialog1 = new SaveFileDialog();
				saveFileDialog1.Filter = "WAV|*.wav";
				saveFileDialog1.Title = "Save Bad As";
				if (saveFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
				{
					badOutputDir = saveFileDialog1.FileName;
					textBox2.Text = Path.GetFileName(saveFileDialog1.FileName);
					ProcessButton.Enabled |= textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "";
				}
			}
			
			else if (OutputButton.Text == "Open Bad WAV")
			{
				OpenFileDialog openFileDialog2 = new OpenFileDialog();
				openFileDialog2.Filter = "WAV|*.wav";
				openFileDialog2.Title = "Select Bad WAV File";
				if (openFileDialog2.ShowDialog() == System.Windows.Forms.DialogResult.OK)  
		    	{
					badInputData = openFileDialog2.FileName;
					textBox2.Text = Path.GetFileName(openFileDialog2.FileName);
					ProcessButton.Enabled |= textBox1.Text != "" && textBox2.Text != "" && textBox4.Text != "";
				}
			}
			else
			{
				SaveFileDialog saveFileDialog1 = new SaveFileDialog();
				saveFileDialog1.Filter = "WP2|*.WP2";
				if (OutputButton.Text == "Select Output (WAV)")
				{
					saveFileDialog1.Filter = "WAV|*.wav";
				}
				saveFileDialog1.Title = "Save As";
				
				if (saveFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
				{
					outputDir = saveFileDialog1.FileName;
					ProcessButton.Enabled = true;
					textBox2.Text = Path.GetFileName(saveFileDialog1.FileName);
				}
			}

		}
		
		void OutputButton2Click(object sender, EventArgs e)
		{
			if (OutputButton2.Text == "Select Awful Output")
			{ 
				SaveFileDialog saveFileDialog1 = new SaveFileDialog();
				saveFileDialog1.Filter = "WAV|*.wav";
				saveFileDialog1.Title = "Save Awful As";
				if (saveFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
				{
					awfulOutputDir = saveFileDialog1.FileName;
					textBox3.Text = Path.GetFileName(saveFileDialog1.FileName);
					ProcessButton.Enabled |= textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "";
				}
			}
			else
			{
				OpenFileDialog openFileDialog1 = new OpenFileDialog();
				openFileDialog1.Filter = "WAV|*.wav";
				openFileDialog1.Title = "Select Awful WAV File";
				if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)  
		    	{
					awfulInputData = openFileDialog1.FileName;
					textBox3.Text = Path.GetFileName(openFileDialog1.FileName);
					ProcessButton.Enabled |= textBox2.Text != "" && textBox3.Text != "" && textBox4.Text != "";
				}
			}
		}
		
		void OutputButton3Click(object sender, EventArgs e)
		{
			SaveFileDialog saveFileDialog1 = new SaveFileDialog();
			saveFileDialog1.Filter = "WP2|*.WP2";
			saveFileDialog1.Title = "Save WP2 As";
			if (saveFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
			{
				WP2outputDir = saveFileDialog1.FileName;
				textBox4.Text = Path.GetFileName(saveFileDialog1.FileName);
				ProcessButton.Enabled |= textBox2.Text != "" && textBox3.Text != "" && textBox4.Text != "";
			}
		}
		
		
		void StageComboSelectedIndexChanged(object sender, EventArgs e)
		{
			OutputButton.Enabled = false;
			OutputButton2.Enabled = false;
			OutputButton3.Enabled = false;
			OutputButton2.Hide();
			OutputButton3.Hide();
			textBox1.Show();
			textBox2.Show();
			textBox3.Hide();
			textBox4.Hide();
			    		
			textBox1.Text = "";
			textBox2.Text = "";
			textBox3.Text = "";
			textBox4.Text = "";
			
			ProcessButton.Size = new Size(373, 118);
		    ProcessButton.Location = new Point(13, 132);
			
			RankCombo.Enabled = true;
		}
		void checkStageSize()
		{
			if (StageCombo.Text == "Stage 1" && RankCombo.Text == "Cool") { stageSize = st1c; }
			if (StageCombo.Text == "Stage 2" && RankCombo.Text == "Cool") { stageSize = st2c; }
			if (StageCombo.Text == "Stage 3" && RankCombo.Text == "Cool") { stageSize = st3c; }
			if (StageCombo.Text == "Stage 4" && RankCombo.Text == "Cool") { stageSize = st4c; }
			if (StageCombo.Text == "Stage 5" && RankCombo.Text == "Cool") { stageSize = st5c; }
			if (StageCombo.Text == "Stage 6" && RankCombo.Text == "Cool") { stageSize = st6c; }
			if (StageCombo.Text == "Stage 7" && RankCombo.Text == "Cool") { stageSize = st7c; }
			if (StageCombo.Text == "Stage 8" && RankCombo.Text == "Cool") { stageSize = st8c; }
			
			if (StageCombo.Text == "Stage 1" && RankCombo.Text == "Good") { stageSize = st1g; }
			if (StageCombo.Text == "Stage 2" && RankCombo.Text == "Good") { stageSize = st2g; }
			if (StageCombo.Text == "Stage 3" && RankCombo.Text == "Good") { stageSize = st3g; }
			if (StageCombo.Text == "Stage 4" && RankCombo.Text == "Good") { stageSize = st4g; }
			if (StageCombo.Text == "Stage 5" && RankCombo.Text == "Good") { stageSize = st5g; }
			if (StageCombo.Text == "Stage 6" && RankCombo.Text == "Good") { stageSize = st6g; }
			if (StageCombo.Text == "Stage 7" && RankCombo.Text == "Good") { stageSize = st7g; }
			if (StageCombo.Text == "Stage 8" && RankCombo.Text == "Good") { stageSize = st8g; }
			
			if (StageCombo.Text == "Stage 1" && RankCombo.Text == "Bad+Awful") { stageSize = st1ba; }
			if (StageCombo.Text == "Stage 2" && RankCombo.Text == "Bad+Awful") { stageSize = st2ba; }
			if (StageCombo.Text == "Stage 3" && RankCombo.Text == "Bad+Awful") { stageSize = st3ba; }
			if (StageCombo.Text == "Stage 4" && RankCombo.Text == "Bad+Awful") { stageSize = st4ba; }
			if (StageCombo.Text == "Stage 5" && RankCombo.Text == "Bad+Awful") { stageSize = st5ba; }
			if (StageCombo.Text == "Stage 6" && RankCombo.Text == "Bad+Awful") { stageSize = st6ba; }
			if (StageCombo.Text == "Stage 7" && RankCombo.Text == "Bad+Awful") { stageSize = st7ba; }
			if (StageCombo.Text == "Stage 8" && RankCombo.Text == "Bad+Awful") { stageSize = st8ba; }
			
			if (RankCombo.Text == "Bad+Awful")
			{
				stageSize /= 2;
			}
		}
		void RankComboSelectedIndexChanged(object sender, EventArgs e)
		{
			InputButton.Enabled = true;
			OutputButton.Enabled = false;
			OutputButton2.Enabled = false;
			OutputButton3.Enabled = false;
			OutputButton2.Hide();
			OutputButton3.Hide();
			textBox1.Show();
			textBox2.Show();
			textBox3.Hide();
			textBox4.Hide();
			    		
			textBox1.Text = "";
			textBox2.Text = "";
			textBox3.Text = "";
			textBox4.Text = "";
			
			ProcessButton.Size = new Size(373, 118);
		    ProcessButton.Location = new Point(13, 132);
	
		}


		
	}
}
