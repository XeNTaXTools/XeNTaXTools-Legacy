pips======================
	ptr2sound
1.3 BETA==================
This program is for PaRappa The Rapper 2 Audio Format conversions.
Currently supports: Singleplayer Good/Cool/Bad/Awful Instrumental files (.WP2)
They're located in the SND folder of the PaRappa 2 ISO. 
Their filenames are formatted as such:
ST0[X]GM0[Y].INT
-[X] is the number indicating what stage the file is for.
-[Y] is the letter indicating what rank the file is. G = Good, C = Cool, and N = Bad and Awful (They're both contained in one file).

If you're having issues importing, make sure your input wav(s) are uncompressed 16 bit PCM.
Also make sure they're the same length, or around the same length as the stage song you're trying to replace. 

I plan to add support for more PaRappa 2 audio formats (e.g lyrics - .bd/hd)

For updates to ptr2sound, bug reports, help with modding other aspects of PaRappa 2, or even just general PaRappa discussion, check the discord:
https://discord.gg/htrcMPP - PaRappa The Rapper 2 Modding Community Discord Server

https://ptrguide.github.io/ - Modding guides for PaRappa games.