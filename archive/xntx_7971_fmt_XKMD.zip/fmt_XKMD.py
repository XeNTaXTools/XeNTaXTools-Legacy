from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Crimson Sea", ".XKMD")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)
    noesis.logPopup()
    return 1
       
def noepyCheckType(data):
    if len(data) < 0x80:
        return 0
    bs = NoeBitStream(data)
    Tag = noeAsciiFromBytes(bs.readBytes(4))
    if Tag != 'XKMD':
        return 0
    return 1

def noepyLoadModel(data, mdlList):
    bs = NoeBitStream(data)
    bs.seek(48, NOESEEK_ABS)
    
    boneC = bs.readInt()
    skelOff = bs.readInt()
    hierC = bs.readInt()
    hierOff = bs.readInt()
    bs.seek(12, NOESEEK_REL)
    triDescOff = bs.readInt()
    meshC = bs.readInt()
    triP1C = bs.readInt()
    triP2C = bs.readInt()
    
    triP1C += triP2C
    
    mdStart = bs.getOffset()
    hasSkel = True if boneC > 0 else False
    
    #Skeleton
    if hasSkel:
        bones = []
        parIds = []
        hierIds = []
        bMats = []
        locIds = []
        transMats = []

        bs.seek(skelOff + 64 * boneC, NOESEEK_ABS)
        for i in range(boneC):
            bs.readShort()
            parIds.append(bs.readShort())
        
        for i in range(hierC):
            bs.seek(hierOff + 40 * i)
            bId = bs.readShort()
            parId = bs.readShort()
            parIds[bId] = parId
            hierIds.append(bId)
            
        bs.seek(skelOff, NOESEEK_ABS)
        for i in range(boneC):
            bMat = NoeMat44.fromBytes(bs.readBytes(64))
            bMat = bMat.inverse()
            bMats.append(bMat)
            
        bs.seek(hierOff, NOESEEK_ABS)
        for i in range(hierC):
            bId = bs.readShort()
            locIds.append(bId)
            parId = bs.readShort()
            
            sca = NoeVec3.fromBytes(bs.readBytes(12))
            
            rot = NoeAngles.fromBytes(bs.readBytes(12))#.toDegrees()

            pos = NoeVec3.fromBytes(bs.readBytes(12))
            
            mat = rot.toMat43()
            mat[3] = pos
            
            for x in range(3):
                mat[x][x] = sca[x]

            bMats[bId] = mat
            parIds[bId] = parId
            
        for i in range(hierC):
            bone = NoeBone(i, "Bone" + str(i), NoeMat43())
            bones.append(bone)
            
        for i in range(hierC):
            bone = bones[i]
            
            targId = locIds[i]
            parId = parIds[targId]
            
            if parId > -1:
                bone.parentIndex = parId
                
        #transMats.append(bone.getAbsoluteTransform())
        
        for i in range(hierC):
            bone = bones[i]
            targId = locIds[i]
            bMat = bMats[targId]
            bone.setMatrix(bMat)
            
#================???====================================
        #for bone in bones:
            #pIndex = bone.parentIndex
            #if pIndex != -1:
                #bone.setMatrix((bones[pIndex].getMatrix() * bone.getMatrix()))
#================???====================================

    xMeshes = {}
    strOp = [1, -1, 0]
    
    prevC = 0
    indCounts = []
    
    for m in range(meshC):
        bs.seek(mdStart + 52 * m, NOESEEK_ABS)
        bs.readInt()
        
        vbStr = bs.readInt()
        vertC = bs.readInt()
        vertOff = bs.readInt()
        bs.seek(16, NOESEEK_REL)
        indC = bs.readInt()
        indOff = bs.readInt()
        
        meshX = MeshX()
        vertData = VertData()
        wCount = (vbStr - 36) / 4
        vertData.wCount = wCount
        
        alLVerts = []
        allNorms = []
        
        newVerts = []
        
        xMeshes[m] = meshX
        vbS = vertOff
        for i in range(vertC):
            bs.seek(vbS + vbStr * i + 0, NOESEEK_ABS)
            vertData.vertices.append(NoeVec3.fromBytes(bs.readBytes(12)))
            
            wSum = 0
            
            for w in range(int(wCount)):
                wei = bs.readFloat()
                wSum += wei
                vertData.weights.append(wei)
                
            vertData.wSums.append(wSum)
            vertData.weights.append(1.0 - wSum)
            
            for w in range(int(4 - wCount - 1)):
                vertData.weights.append(0)
                    
            vertData.normals.append(NoeVec3.fromBytes(bs.readBytes(12)))
        
        allInds = []
        bs.seek(indOff, NOESEEK_ABS)
        
        for i in range(indC):
            allInds.append(bs.readUShort())

        exInds = []
        indCur = 0
        
        bs.seek(triDescOff, NOESEEK_ABS)

        vertData.bIds = [0]*len(vertData.weights)
        startStr = 1
        for t in range(triP1C):
            b0Id = bs.readUShort()
            weiC = bs.readUByte() / 2 + 1;
            bs.seek(3, NOESEEK_REL)
            b1Id = bs.readUShort()

            strBIds = []
            for b in range(4):
                strBIds.append(bs.readUShort())

            meshId = bs.readInt()
            entC = bs.readInt()
            for e in range(entC):
                triType = bs.readInt()
                startVertex = bs.readInt()
                triIndC = bs.readInt()
                triIndOrg = bs.readInt()
                triIndOff = triIndOrg - prevC
                triCount = bs.readInt()
                
                if meshId == m and triIndOff >= 0:
                    if triType == 5:
                        startStr += 1
                        for i in range(triIndC):
                            ind = allInds[triIndOff + i]
                            meshX.indices.append(ind)
                            
                            if not ind in exInds:
                                exInds.append(ind)
                                vertData.vertices[ind] = vertData.vertices[ind]*bones[b0Id].getMatrix()
                                vertData.normals[ind] = vertData.normals[ind]*bones[b0Id].getMatrix()
                                
                                wInd = ind * 4;
                                if weiC == 1:
                                    vertData.weights[wInd] = 1
                                    vertData.bIds[wInd] = b0Id
                                    
                                    for w in range(1,4):
                                        vertData.bIds[wInd + w] = 0
                                        vertData.weights[wInd + w] = 0
                                else:
                                    wS = 0
                                    for w in range(int(weiC)):
                                        vertData.bIds[wInd + w] = parIds[strBIds[w]]
                                        wS += vertData.weights[wInd + w]
                                    ex = 0
                                    if wS < 1 and weiC < 4:
                                        vertData.bIds[int(wInd + weiC)] = b0Id
                                        vertData.weights[int(wInd + weiC)] = 1.0 - wS
                                        ex = 1
                                        
                                    for w in range(int(weiC + ex), 4):
                                        vertData.bIds[wInd + w] = 0
                                        vertData.weights[wInd + w] = 0
                    elif triType == 6:
                        strInd = startStr
                        for i in range(triIndC - 2):
                            for s in range(3):
                                ind = allInds[triIndOff + i + s + strOp[s] * (strInd % 2)]
                                
                                meshX.indices.append(ind)
                                if not ind in exInds:
                                    exInds.append(ind)
                                    vertData.vertices[ind] = vertData.vertices[ind]*bones[b0Id].getMatrix()
                                    vertData.normals[ind] = vertData.normals[ind]*bones[b0Id].getMatrix()
                                    
                                    wInd = ind * 4
                                    if weiC == 1:
                                        vertData.weights[wInd] = 1
                                        vertData.bIds[wInd] = b0Id
                                        
                                        for w in range(1, 4):
                                            vertData.bIds[wInd + w] = 0
                                            vertData.weights[wInd + w] = 0
                                    else:
                                        wS = 0
                                        for w in range(int(weiC)):
                                             vertData.bIds[wInd + w] = parIds[strBIds[w]]
                                             wS += vertData.weights[wInd + w]
                                             
                                        ex = 0
                                        if wS < 1 and weiC < 4:
                                            vertData.bIds[int(wInd + weiC)] = b0Id
                                            vertData.weights[int(wInd + weiC)] = 1.0 - wS
                                            ex = 1
                                        
                                        for w in range(int(weiC + ex),4):
                                            vertData.bIds[wInd + w] = 0
                                            vertData.weights[wInd + w] = 0
                            strInd+=1
                    else:
                        print(bs.getOffset());

        for i in range(len(vertData.vertices)):
            vert = vertData.vertices[i]
            norm = vertData.normals[i]
            
            meshX.vertices.append(vert)
            meshX.normals.append(norm)
        
        meshX.bIds = copy.copy(vertData.bIds)
        meshX.weights = copy.copy(vertData.weights)

    meshes = []
    for i in range(meshC):
        meshX = xMeshes[i]
        mesh = NoeMesh(meshX.indices, meshX.vertices ,"mesh_"+str(i))
        mesh.setNormals(meshX.normals)

        if hasSkel:
            mesh.setWeights(meshX.createWeights())
        meshes.append(mesh)
    
    mdl = NoeModel(meshes)
    mdl.setBones(bones)
    mdlList.append(mdl)
    return 1

class MeshX:
    def __init__(self):
        self.indices = []
        self.vertices = []
        self.normals = []
        self.bIds = []
        self.weights = []
        
    def createWeights(self):
        setWeights = []
        w = self.weights
        bi = self.bIds
        
        for x in range(0,len(w),4):
            setWeights.append(NoeVertWeight([bi[x],bi[x+1],bi[x+2],bi[x+3]], [w[x],w[x+1],w[x+2],w[x+3]]))
        
        return setWeights
   
class VertData:
    def __init__(self):
        self.vertices = []
        self.normals = []

        self.weights = []
        self.bIds = []

        self.wCount = 0
        self.wSums = []

        self.strInd = 1;
