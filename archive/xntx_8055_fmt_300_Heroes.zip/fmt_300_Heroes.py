from inc_noesis import *

def registerNoesisTypes():
   handle = noesis.register("300 Heroes", ".dat")
   noesis.setHandlerTypeCheck(handle, CheckType)
   noesis.setHandlerLoadModel(handle, LoadModel)
   return 1

def CheckType(data):
    if len(data) < 0x80:
        return 0
    return 1       

def LoadModel(data, mdlList):
    ctx = rapi.rpgCreateContext()
    bs = NoeBitStream(data)
    # submesh [[0,1,2,3], ... , ...]
    # 0-indices_offset; 1-num_indices; 2-vert_offset; 3-num_vert;
    # 000032b1.dat >> [[36866, 624, 33104, 114], [202550, 22284, 40850, 4900]]
    # 00002674.dat >> [[39291, 996, 31008, 251], [0x3b4b1, 25965, 0xb8cb, 5926]]
    offset = [[36866, 624, 33104, 114], [202550, 22284, 40850, 4900]]
    
    for i,x in enumerate(offset):
        iOffset, iCount, vOffset, vCount = x
        
        bs.seek(iOffset)
        faces = bs.readBytes(iCount*2)
        
        bs.seek(vOffset)
        vbuffer = bs.readBytes(vCount*12)
        nbuffer = bs.readBytes(vCount*12)
        uvbuffer = bs.readBytes(vCount*8)
        
        rapi.rpgBindPositionBuffer(vbuffer, noesis.RPGEODATA_FLOAT, 12)
        rapi.rpgBindNormalBuffer(nbuffer, noesis.RPGEODATA_FLOAT, 12)
        rapi.rpgBindUV1Buffer(uvbuffer, noesis.RPGEODATA_FLOAT, 8)
        rapi.rpgCommitTriangles(faces, noesis.RPGEODATA_USHORT, iCount, noesis.RPGEO_TRIANGLE)

    mdl = rapi.rpgConstructModel()
    mdl.setModelMaterials(NoeModelMaterials([], [NoeMaterial("default","")]))
    mdlList.append(mdl)
    rapi.setPreviewOption("setAngOfs", "0 -90 0")
    return 1
