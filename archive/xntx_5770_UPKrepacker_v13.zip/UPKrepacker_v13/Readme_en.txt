UPK Unpack/Repack ver1.3

(c) 0dd14Lab 2012 
https://sites.google.com/site/0dd14lab2/
*For a future maintenance,Uploading this program without permission to other sites is forbidden. 

[[ What this?	]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]

This program is performs unpack/re-pack the package file (UPK) of unreal engine3 (UE3).
You can replace the unpacked file and can re-pack to UPK.
(In re-pack processing, it does not support to an addition and deletion of a file.) 

* This program does not run on the UPK file of all UE3-games, since the format of a UPK file changes a little with games.


[[ Usage	]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]

I recommend you to perform it, after copying a upk file to a folder other than an game folder. 
Please run a program from a command line. 

- UPK unpacking:

>UPKunpack [TargetUPK] [DestFolder]

[TargetUPK] is unpacked to [DestFolder].
If [DestFolder] is omitted,The folder of a UPK file name is created by the same folder as a TargetUPK,
and the file of contents is unpacked there. 

* [.UPKpkginfo] file is also created as an information file for repacks.Since this file is needed at repacking,please do not delete it. 

- UPK repacking

>UPKrepack [TargetFolder] [DestFileName]

File in [TargetFolder] is repacked to [DestUPKFile]. 
If [DestFileName] is omitted,The file in [TargetFolder] is repacked to [TargetFolder].upk. 


[[ Notes	]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]

- Although the UPK file may be compressed, it is NOT re-compressed by repacking. 
UE3 also recognizes correctly UPK which has not been compressed. 

- In the case of the form which the contents name in UPK cannot output to a file, at unpacking,
output file name is changed to .[Num]\[Num].[extension] (Num is an  Export number).
The file of such a name also recognizes repack processing. 

- I checked by some of UPK files of these games. 
	Mirrors Edge		(UPK ver 0x218)
	Batman - Arkham Asylum	(UPK ver 0x240)
	Borderlands		(UPK ver 0x248)
	TERA			(UPK ver 0x262)
	Alice Madness Returns	(UPK ver 0x2b2)
	Batman - Arkham City	(UPK ver 0x325)
	Barderlands2		(UPK ver 0x340)

[[ changelog	]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
Ver1.3 28.10.2012  :Added support to Boraderlands2's UPK. Support to Full-Compressed UPK.
Ver1.22 06.09.2012 :Fix bug
Ver1.2 19.06.2012  :Fix bug(failed in change of ExportTable at repacking)
Ver1.1 18.06.2012  :Added support to TERA .upk/.gpk files. 
Ver1.0 06.06.2012





