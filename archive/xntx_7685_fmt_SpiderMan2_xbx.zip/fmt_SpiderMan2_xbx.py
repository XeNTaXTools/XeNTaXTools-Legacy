# Spider-Man 2 (Xbox) model importer by Bigchillghost

from inc_noesis import *
import struct

def registerNoesisTypes():
	handle = noesis.register("Spider-Man 2 Xbox", ".xbx")
	noesis.setHandlerTypeCheck(handle, checkType)
	noesis.setHandlerLoadModel(handle, modelLoadModel)
	
	#noesis.logPopup()
	return 1

#check if it's this type based on the data
def checkType(data):
	if len(data) < 0x80:
		return 0
	bs = NoeBitStream(data)
	Magic = bs.readUInt()
	if Magic != 0x4D584258:
		return 0
	bs.seek(8, NOESEEK_ABS)
	entryCnt = bs.readUInt()
	entryOffset = bs.readUInt()
	bs.seek(entryOffset, NOESEEK_ABS)
	for i in range(0, entryCnt):
		bs.seek(3, NOESEEK_REL)
		assetType = bs.readUByte()
		bs.seek(8, NOESEEK_REL)
		if assetType == 2:
			return 1
	return 0

#load the model
def modelLoadModel(data, mdlList):
	bs = NoeBitStream(data)
	bs.seek(8, NOESEEK_ABS)
	entryCnt = bs.readUInt()
	entryOffset = bs.readUInt()
	bs.seek(entryOffset, NOESEEK_ABS)
	entryList = []
	for i in range(0, entryCnt):
		Size = bs.readUInt24()
		assetType = bs.readUByte()
		subEntryOffset = bs.readUInt()
		strOffset = bs.readUInt()
		entryList.append([Size, assetType, subEntryOffset])
	
	ctx = rapi.rpgCreateContext()
	for i in range(0, entryCnt):
		if entryList[i][1] != 2:
			continue
		bs.seek(entryList[i][2], NOESEEK_ABS)
		meshGroupNameOffset = bs.readUInt()
		bs.seek(4, NOESEEK_REL)
		subMeshCnt = bs.readUInt()
		subMeshEntryOffset = bs.readUInt()
		boneCnt = bs.readUInt()
		boneMatOffset = bs.readUInt()
		unkCnt = bs.readUInt()
		unkOffset = bs.readUInt()
			
		bs.seek(subMeshEntryOffset, NOESEEK_ABS)
		subMeshEntryInfoOffset = [0]*subMeshCnt
		for j in range(0, subMeshCnt):
			bs.seek(4, NOESEEK_REL)
			subMeshEntryInfoOffset[j] = bs.readUInt()
		subMeshEntryInfo = []
		for j in range(0, subMeshCnt):
			bs.seek(8, NOESEEK_REL)
			mappingBoneIndexCount = bs.readUInt()
			mappingBoneIndexOffset = bs.readUInt()
			bs.seek(0x18, NOESEEK_REL)
			encodeFmt = bs.readUInt()
			vertexIndexCount = bs.readUInt()
			vertexIndexOffset = bs.readUInt()
			bs.seek(4, NOESEEK_REL)
			indexRelativeOffset = bs.readUInt()
			blockSize = bs.readUInt()
			vertexCount = bs.readUInt()
			vertexOffset = bs.readUInt()
			vertexDataSize = bs.readUInt()
			bs.seek(4, NOESEEK_REL)
			vertexDataStride = bs.readUInt()
			bs.seek(0xC, NOESEEK_REL)
			subMeshEntryInfo.append([vertexIndexCount, vertexIndexOffset, 
			indexRelativeOffset, encodeFmt, vertexCount,
			vertexOffset, vertexDataSize, vertexDataStride])
		bs.seek(meshGroupNameOffset+4, NOESEEK_ABS)
		meshGroupName = bs.readString()
		for j in range(0, subMeshCnt):
			vertexIndexCount = subMeshEntryInfo[j][0]
			vertexIndexOffset = subMeshEntryInfo[j][1]
			indexEncoding = subMeshEntryInfo[j][3]
			if vertexIndexCount == 0:
				print("indexEncoding %d"%indexEncoding)
				vertexIndexCount = subMeshEntryInfo[j][4]
				indexList = [0]*vertexIndexCount
				quadNum = vertexIndexCount // 4
				accIdx = 0
				for k in range(0, quadNum):
					indexList[accIdx] = accIdx
					indexList[accIdx + 1] = accIdx + 1
					indexList[accIdx + 2] = accIdx + 3
					indexList[accIdx + 3] = accIdx + 2
					accIdx += 4
				vertexIndexData = struct.pack("<" + 'H'*vertexIndexCount, *indexList)
			elif vertexIndexOffset == 0:
				vertexIndexOffset = subMeshEntryInfo[j][2] + 8
				bs.seek(vertexIndexOffset, NOESEEK_ABS)
				vertexIndexData = bytearray()
				while True:
					Sig = bs.readUShort()
					if Sig == 0x17FC:
						break
					dataSize = bs.readUShort() & 0x3FFF
					vertexIndexData += bs.readBytes(dataSize)
			else:
				bs.seek(vertexIndexOffset, NOESEEK_ABS)
				dataSize = vertexIndexCount * 2
				vertexIndexData = bs.readBytes(dataSize)
			bs.seek(subMeshEntryInfo[j][5], NOESEEK_ABS)
			vertexData = bs.readBytes(subMeshEntryInfo[j][6])
			vertexStride = subMeshEntryInfo[j][7]
			encoding = noesis.RPGEO_TRIANGLE_STRIP
			if indexEncoding == 5:
				encoding = noesis.RPGEO_TRIANGLE
			elif indexEncoding == 6:
				encoding = noesis.RPGEO_TRIANGLE_STRIP
			elif indexEncoding == 8:
				encoding = noesis.RPGEO_QUAD
			else:
				raise Exception("Unknown index encoding:%d"%indexEncoding)
			uvPos = 0x10
			if vertexStride < 0x1C:
				uvPos = 0xC
			rapi.rpgSetName(meshGroupName+'_%d'%j)
			rapi.rpgBindPositionBuffer(vertexData, noesis.RPGEODATA_FLOAT, vertexStride)
			rapi.rpgBindUV1BufferOfs(vertexData, noesis.RPGEODATA_FLOAT, vertexStride, uvPos)
			rapi.rpgCommitTriangles(vertexIndexData, noesis.RPGEODATA_USHORT, vertexIndexCount, encoding, 1)
			rapi.rpgSmoothNormals()
			rapi.rpgClearBufferBinds()
	if rapi.rpgGetVertexCount() == 0:
		return 0
	mdl = rapi.rpgConstructModelSlim()
	mdlList.append(mdl)
	
	return 1