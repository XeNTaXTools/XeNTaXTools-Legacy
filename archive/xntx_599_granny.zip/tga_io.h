#ifndef TGA_IO

#define TGA_IO

int tga_save(const char *fname,const unsigned char *image,int wid,int hit); // JWR  save 24 bit RGB
int tga_save_alpha(const char *fname,const unsigned char *image,int wid,int hit); // JWR  save 32 bit ARGB
int tga_save_gray(const char *fname,const unsigned char *image,int wid,int hit); // JWR  save 8 bit Grayscale


#endif
