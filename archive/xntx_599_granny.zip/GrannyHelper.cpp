#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#include "GrannyHelper.h"
#include "granny.h"

#if !NOGRANNY

static granny_data_type_definition GlobalGrannyVertexType[] =
{
  {GrannyReal32Member, GrannyVertexPositionName, 0, 3},
  {GrannyReal32Member, GrannyVertexNormalName, 0, 3},
  {GrannyReal32Member, GrannyVertexTangentName, 0, 3},
  {GrannyReal32Member, GrannyVertexBinormalName, 0, 3},
  {GrannyReal32Member, GrannyVertexTextureCoordinatesName "0", 0, 2},
  {GrannyReal32Member, GrannyVertexTextureCoordinatesName "1", 0, 2},
  {GrannyUInt32Member, GrannyVertexDiffuseColorName "0", 0, 1},
  {GrannyEndMember},
};

static granny_data_type_definition GlobalGrannyVertexWithBonesType[] =
{
  {GrannyReal32Member, GrannyVertexPositionName, 0, 3},
  {GrannyNormalUInt8Member,  GrannyVertexBoneWeightsName, 0, BONES_PER_VERT},
  {GrannyUInt8Member,  GrannyVertexBoneIndicesName, 0, BONES_PER_VERT},
  {GrannyReal32Member, GrannyVertexNormalName, 0, 3},
  {GrannyReal32Member, GrannyVertexTangentName, 0, 3},
  {GrannyReal32Member, GrannyVertexBinormalName, 0, 3},
  {GrannyReal32Member, GrannyVertexTextureCoordinatesName "0", 0, 2},
  {GrannyReal32Member, GrannyVertexTextureCoordinatesName "1", 0, 2},
  {GrannyUInt32Member,  GrannyVertexDiffuseColorName "0", 0, 1},
  {GrannyEndMember},
};


void * getGrannyVertices(const granny_mesh *GrannyMesh,GrannyVertexType &type,unsigned int &VertexCount)
{
  void * ret = 0;

  type = GV_LAST;

  VertexCount = GrannyMesh->PrimaryVertexData->VertexCount;

  bool HasTangents = false;
  bool HasBinormals = false;
  bool HasSecondUVSet = false;
  bool HasVertexColor = false;
  bool Deformable = !GrannyMeshIsRigid(GrannyMesh);

  granny_data_type_definition* NoBonesDef = 0;
  granny_data_type_definition* WithBonesDef = 0;

  // Determine if exported mesh has tangent vectors
  granny_variant Match;
  GrannyFindMatchingMember(GrannyGetMeshVertexType(GrannyMesh),GrannyGetMeshVertices(GrannyMesh),GrannyVertexTangentName,&Match);
  if(Match.Object) 
  {
    HasTangents = true;
  }
  // Determine if exported mesh has binormal vectors
  granny_variant MatchB;
  GrannyFindMatchingMember(GrannyGetMeshVertexType(GrannyMesh),GrannyGetMeshVertices(GrannyMesh),GrannyVertexBinormalName,&MatchB);
  if(MatchB.Object) 
  {
    HasBinormals = true;
  }

  // Determine if this mesh has 1 or two sets of UVs
  granny_variant MatchC;
  GrannyFindMatchingMember(GrannyGetMeshVertexType(GrannyMesh),GrannyGetMeshVertices(GrannyMesh),GrannyVertexTextureCoordinatesName "1",&MatchC);
  if(MatchC.Object) 
  {
    HasSecondUVSet = true;
  } 
  else 
  {
    HasSecondUVSet = false;
  }

  // Determine if mesh has color components
  granny_variant MatchVC;
  GrannyFindMatchingMember(GrannyGetMeshVertexType(GrannyMesh),GrannyGetMeshVertices(GrannyMesh),GrannyVertexDiffuseColorName "0",&MatchVC);
  HasVertexColor = (MatchVC.Object!=0);

  granny_data_type_definition *CurrentType=0;
  void *TargetBuffer = 0;
  if ( Deformable)
  {
    CurrentType = GlobalGrannyVertexWithBonesType;
    TargetBuffer = new GrannyVertexDeformable[VertexCount];
    type = GV_DEFORMABLE;
  }
  else
  {
    CurrentType = GlobalGrannyVertexType;
    TargetBuffer = new GrannyVertexRigid[VertexCount];
    type = GV_RIGID;
  }


	GrannyCopyMeshVertices(GrannyMesh, CurrentType, TargetBuffer);


  if ( type == GV_DEFORMABLE)
  {
    GrannyVertexDeformable *verts = (GrannyVertexDeformable *) TargetBuffer;
    printf("debug me");
  }
  else
  {
    GrannyVertexRigid *verts = (GrannyVertexRigid *) TargetBuffer;
    printf("debug me");
  }


  return ret;
}

#endif
