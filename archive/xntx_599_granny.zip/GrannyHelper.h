#ifndef GRANNY_HELPER_H

#define GRANNY_HELPER_H

#define BONES_PER_VERT 4

enum GrannyVertexType
{
  GV_RIGID,
  GV_DEFORMABLE,
  GV_LAST
};

class GrannyVertexRigid
{
public:
  GrannyVertexRigid(void)
  {
    mPosition[0] = mPosition[1] = mPosition[2] = 0;
    mNormal[0] = mNormal[1] = mNormal[2] = 0;
    mTangent[0] = mTangent[1] = mTangent[2] = 0;
    mBinormal[0] = mBinormal[1] = mBinormal[2] = 0;
    mUV1[0] = mUV1[1] = 0;
    mUV2[0] = mUV2[1] = 0;
    mColor = 0xFFFFFFFF;
  }
  float        mPosition[3];
  float        mNormal[3];
  float        mTangent[3];
  float        mBinormal[3];
  float        mUV1[2];
  float        mUV2[2];
  unsigned int mColor;
};

class GrannyVertexDeformable
{
public:
  GrannyVertexDeformable(void)
  {
    mPosition[0] = mPosition[1] = mPosition[2] = 0;
    mBoneWeights[0] = 1; mBoneWeights[1] = 0; mBoneWeights[2] = 0; mBoneWeights[3] = 0;
    mBoneIndices[0] = mBoneIndices[1] = mBoneIndices[2] = mBoneIndices[3] = 0;
    mNormal[0] = mNormal[1] = mNormal[2] = 0;
    mTangent[0] = mTangent[1] = mTangent[2] = 0;
    mBinormal[0] = mBinormal[1] = mBinormal[2] = 0;
    mUV1[0] = mUV1[1] = 0;
    mUV2[0] = mUV2[1] = 0;
    mColor = 0xFFFFFFFF;
  }
  float        mPosition[3];
  char         mBoneWeights[BONES_PER_VERT];
  char         mBoneIndices[BONES_PER_VERT];
  float        mNormal[3];
  float        mTangent[3];
  float        mBinormal[3];
  float        mUV1[2];
  float        mUV2[2];
  unsigned int mColor;
};

struct granny_mesh;

void * getGrannyVertices(const granny_mesh *mesh,GrannyVertexType &type,unsigned int &vcount);


#endif
