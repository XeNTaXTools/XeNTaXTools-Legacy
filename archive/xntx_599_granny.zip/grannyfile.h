#if !defined(BASIC_PROCESSED_FILE_FORMAT_H)
/* ========================================================================
   $RCSfile: basic_processed_file_format.h,v $
   $Date: 2007/02/01 $
   $Revision: #2 $
   $Creator: Casey Muratori $
   (C) Copyright 1999-2002 by RAD Game Tools, All Rights Reserved.
   ======================================================================== */

/* This file defines a simplified version of what a typical 3D app
   might use as its file format.  Typically, 3D files can be very
   ugly, since they contain a variety of different types of
   information with complex interrelations between them.  However,
   Granny can help make this easier for applications, since its
   automated file packing and compression routines are exposed to the
   app for use with its own files, even if their contents are
   completely unrelated to those found in a typical Granny file.

   As you can see, each C data type in this file is accompanied by
   a simple Granny data type descriptor.  So long as you take the
   time to provide such a type descriptor for each type you wish
   to save, Granny can take care of everything else for you.  See
   basic_file_processing.cpp for more information, as it uses
   this file format to automatically write out its data. */

#include "granny.h"

#if !NOGRANNY


granny_data_type_definition GlobalGrannyVertexType[] =
{
  {GrannyReal32Member, GrannyVertexPositionName, 0, 3},
  {GrannyReal32Member, GrannyVertexNormalName, 0, 3},
  {GrannyReal32Member, GrannyVertexTangentName, 0, 3},
  {GrannyReal32Member, GrannyVertexBinormalName, 0, 3},
  {GrannyReal32Member, GrannyVertexTextureCoordinatesName "0", 0, 2},
  //{GrannyReal32Member, GrannyVertexDiffuseColorName "0", 0, 1},
  //{GrannyReal32Member, "Padding", 0, 1},
  {GrannyUInt32Member, GrannyVertexDiffuseColorName "0", 0, 1},

  {GrannyEndMember},
};

granny_data_type_definition GlobalGrannyVertexType2[] =
{
  {GrannyReal32Member, GrannyVertexPositionName, 0, 3},
  {GrannyReal32Member, GrannyVertexNormalName, 0, 3},
  {GrannyReal32Member, GrannyVertexTangentName, 0, 3},
  {GrannyReal32Member, GrannyVertexBinormalName, 0, 3},
  {GrannyReal32Member, GrannyVertexTextureCoordinatesName "1", 0, 2},  // use second set of VUs as main UVs (first set is only for tangent space cal in exporter)

  {GrannyEndMember},
};

#define BONES_PER_VERT 4

granny_data_type_definition GlobalGrannyVertexWithBonesType[] =
{
  {GrannyReal32Member, GrannyVertexPositionName, 0, 3},
  {GrannyNormalUInt8Member,  GrannyVertexBoneWeightsName, 0, BONES_PER_VERT},
  {GrannyUInt8Member,  GrannyVertexBoneIndicesName, 0, BONES_PER_VERT},
  {GrannyReal32Member, GrannyVertexNormalName, 0, 3},
  {GrannyReal32Member, GrannyVertexTangentName, 0, 3},
  {GrannyReal32Member, GrannyVertexBinormalName, 0, 3},
  {GrannyReal32Member, GrannyVertexTextureCoordinatesName "0", 0, 2},
  {GrannyUInt32Member,  GrannyVertexDiffuseColorName "0", 0, 1},

  {GrannyEndMember},
};

granny_data_type_definition GlobalGrannyVertexWithBonesType2[] =
{
  {GrannyReal32Member, GrannyVertexPositionName, 0, 3},
  {GrannyNormalUInt8Member,  GrannyVertexBoneWeightsName, 0, BONES_PER_VERT},
  {GrannyUInt8Member,  GrannyVertexBoneIndicesName, 0, BONES_PER_VERT},
  {GrannyReal32Member, GrannyVertexNormalName, 0, 3},
  {GrannyReal32Member, GrannyVertexTangentName, 0, 3},
  {GrannyReal32Member, GrannyVertexBinormalName, 0, 3},
  {GrannyReal32Member, GrannyVertexTextureCoordinatesName "1", 0, 2},   // use second set of VUs as main UVs (first set is only for tangent space cal in exporter)

  {GrannyEndMember},
};


struct triangle_group
{
    // This is a grouping structure used by the mesh structures to
    // bundle triangles into groups that share the same texture.
    // (normally, it would be by material instead of by texture,
    // but for simplicity's sake, this sample ignores the concept
    // of a material and just uses textures directly).

    // The texture for this group of triangles is stored as an
    // index into the TextureNames array in the mesh structure
    // that contains the group.
    int TextureIndex;

    // The triangles are stored as groups of 3 indices, with an IndexCount
    // that is 3 times the triangle count, and an array of int's that are
    // the indices.
    int IndexCount;
    int *Indices;
};
granny_data_type_definition TriangleGroupType[] =
{
    {GrannyInt32Member, "TextureIndex"},
    {GrannyReferenceToArrayMember, "Indices", GrannyInt32Type},
    {GrannyEndMember},
};

struct rigid_vertex
{
    // This is a simple rigid vertex format for tutorial purposes.
    // Granny can handle arbitrary vertex formats, so you're certainly
    // not limited to vertices with this little information.

    float Position[3];   // The location of the vertex
    float Normal[3];     // The normal for the vertex
    float TexCoord0[2];   // The UV coordinate for the vertex
    float TexCoord1[2];
};
granny_data_type_definition RigidVertexType[] =
{
    {GrannyReal32Member, GrannyVertexPositionName, 0, 3},
    {GrannyReal32Member, GrannyVertexNormalName, 0, 3},
    {GrannyReal32Member, GrannyVertexTextureCoordinatesName "0", 0, 2},
    {GrannyReal32Member, GrannyVertexTextureCoordinatesName "1", 0, 2},
    {GrannyEndMember},
};

struct rigid_mesh
{
    // This is the name of the mesh, as named by the artist in the art tool
    char *Name;

    // This is the name of the bone that controls this mesh - since it
    // is a non-deforming mesh, there is only one bone
    char *BoneName;

    // This is the array of textures used by the triangle groups,
    // stored by name
    int TextureCount;
    char **TextureNames;

    // This is the array of triangle groups that make up the mesh
    int TriangleGroupCount;
    triangle_group *TriangleGroups;

    // This is the array of vertices into which the triangle groups index
    int VertexCount;
    rigid_vertex *Vertices;
};
granny_data_type_definition RigidMeshType[] =
{
    {GrannyStringMember, "Name"},
    {GrannyStringMember, "BoneName"},
    {GrannyReferenceToArrayMember, "TextureNames", GrannyStringType},
    {GrannyReferenceToArrayMember, "TriangleGroups", TriangleGroupType},
    {GrannyReferenceToArrayMember, "Vertices", RigidVertexType},
    {GrannyEndMember},
};

int const MaxWeightCount = 4;
struct deformable_vertex
{
    // This is a simple deformable vertex format for tutorial purposes.
    // Granny can handle arbitrary vertex formats, so you're certainly
    // not limited to vertices with this little information.

    float Position[3];   // The location of the vertex
    float Normal[3];     // The normal for the vertex
    float TexCoord0[2];   // The UV coordinate for the vertex
    float TexCoord1[2];   // The UV coordinate for the vertex

    int unsigned Bones[MaxWeightCount];  // The bone indices for this vertex
    float Weights[MaxWeightCount];       // The weights for the bones
};
granny_data_type_definition DeformableVertexType[] =
{
    {GrannyReal32Member, GrannyVertexPositionName, 0, 3},
    {GrannyReal32Member, GrannyVertexNormalName, 0, 3},
    {GrannyReal32Member, GrannyVertexTextureCoordinatesName "0", 0, 2},
    {GrannyReal32Member, GrannyVertexTextureCoordinatesName "1", 0, 2},
    {GrannyInt32Member, GrannyVertexBoneIndicesName, 0, MaxWeightCount},
    {GrannyReal32Member, GrannyVertexBoneWeightsName, 0, MaxWeightCount},
    {GrannyEndMember},
};

struct deformable_mesh
{
    // This is the name of the mesh, as named by the artist in the art tool
    char *Name;

    // These are the bones that control the deformation of this mesh,
    // stored by name
    int BoneCount;
    char **BoneNames;

    int *BoneIndices; // remap bone indices to this skeleton map

    // This is the array of textures used by the triangle groups,
    // stored by name
    int TextureCount;
    char **TextureNames;

    // This is the array of triangle groups that make up the mesh
    int TriangleGroupCount;
    triangle_group *TriangleGroups;
    
    // This is the array of vertices into which the triangle groups index
    int VertexCount;
    deformable_vertex *Vertices;
};
granny_data_type_definition DeformableMeshType[] =
{
    {GrannyStringMember, "Name"},
    {GrannyReferenceToArrayMember, "BoneNames", GrannyStringType},
    {GrannyReferenceToArrayMember, "TextureNames", GrannyStringType},
    {GrannyReferenceToArrayMember, "TriangleGroups", TriangleGroupType},
    {GrannyReferenceToArrayMember, "Vertices", DeformableVertexType},
    {GrannyEndMember},
};

struct bone
{
    // This is the name of the bone, as named by the artist in the art tool
    char *Name;

    // This is the index of the parent of this bone, or -1 if it is the root
    int ParentIndex;

    // This is the resting transform of this bone
    granny_transform Transform;
};
granny_data_type_definition BoneType[] =
{
    {GrannyStringMember, "Name"},
    {GrannyInt32Member, "ParentIndex"},
    {GrannyTransformMember, "Transform"},
    {GrannyEndMember},
};

struct model
{
    // This is the name of the model, which is generally synthesized by
    // Granny since most art tools do not allow artists to name models,
    // just meshes and bones.  So Granny's exporters usually choose the
    // name of the root bone as the name of the model, for lack of a better
    // option.
    char *Name;

    // This is the array of rigid meshes in the model
    int RigidMeshCount;
    rigid_mesh *RigidMeshes;

    // This is the array of deformable meshes in the model
    int DeformableMeshCount;
    deformable_mesh *DeformableMeshes;

    // This is the skeleton of the model, stored as an array of bones
    // which index into the array to indicate their parents.
    int BoneCount;
    bone *Bones;

    granny_transform  InitialPlacement;

};
granny_data_type_definition ModelType[] =
{
    {GrannyStringMember, "Name"},
    {GrannyReferenceToArrayMember, "RigidMeshes", RigidMeshType},
    {GrannyReferenceToArrayMember, "DeformableMeshes", DeformableMeshType},
    {GrannyReferenceToArrayMember, "Bones", BoneType},
    {GrannyEndMember},
};

struct texture
{
    // This is the file name of the texture
    char *Name;

    // These are the dimensions of the texture
    int Width, Height;

    // This is an array of raw pixel data for the texture, stored as
    // packed RGBA 8888 dwords
    int Size;
    unsigned char *Pixels;
};
granny_data_type_definition TextureType[] =
{
    {GrannyStringMember, "Name"},
    {GrannyInt32Member, "Width"},
    {GrannyInt32Member, "Height"},
    {GrannyReferenceToArrayMember, "Pixels", GrannyUInt8Type},
    {GrannyEndMember},
};

struct file
{
    // This is the array of textures contained in the file
    int TextureCount;
    texture *Textures;

    // This is the array of models contained in the file
    int ModelCount;
    model *Models;

    // This is the array of animations contained in the file
    int AnimationCount;
    granny_animation **Animations;
};
granny_data_type_definition FileType[] =
{
    {GrannyReferenceToArrayMember, "Textures", TextureType},
    {GrannyReferenceToArrayMember, "Models", ModelType},
    {GrannyArrayOfReferencesMember, "Animations", GrannyAnimationType},
    {GrannyEndMember},
};

// This is a randomly chosen magic value that labels this file format.
// It can be any number, so long as the high bit is not set, since
// Granny reserves all values with the high bit set for labeling its
// own file formats, so picking a value with the high bit set might
// cause type conflicts with Granny's standard file format.
granny_uint32 const BasicProcessFileTag = 0x3666460d;

// BasicProcessFileTag is used to mark the file as our own file
// format, as opposed to a standard Granny file or otherwise.  In
// general, any time this format is changed (fields added, moved,
// etc.), its value should be changed to indicate that the format has
// changed.  This is so that Granny will know, at load time, if it is
// loading a file that is in a revision of the format that is
// different from the current one, and (if you've elected to save
// formatting information in your files) it will perform automatic
// backwards and/or forwards compatibility conversions as best it can.

#endif

#define BASIC_PROCESSED_FILE_FORMAT_H
#endif
