#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "granny.h"
#include "grannymesh.h"
#include "log.h"
#include "GrannyHelper.h"

/*!  
** 
** Copyright (c) 2007 by John W. Ratcliff mailto:jratcliff@infiniplex.net
**
** Portions of this source has been released with the PhysXViewer application, as well as 
** Rocket, CreateDynamics, ODF, and as a number of sample code snippets.
**
** If you find this code useful or you are feeling particularily generous I would
** ask that you please go to http://www.amillionpixels.us and make a donation
** to Troy DeMolay.
**
** DeMolay is a youth group for young men between the ages of 12 and 21.  
** It teaches strong moral principles, as well as leadership skills and 
** public speaking.  The donations page uses the 'pay for pixels' paradigm
** where, in this case, a pixel is only a single penny.  Donations can be
** made for as small as $4 or as high as a $100 block.  Each person who donates
** will get a link to their own site as well as acknowledgement on the
** donations blog located here http://www.amillionpixels.blogspot.com/
**
** If you wish to contact me you can use the following methods:
**
** Skype Phone: 636-486-4040 (let it ring a long time while it goes through switches)
** Skype ID: jratcliff63367
** Yahoo: jratcliff63367
** AOL: jratcliff1961
** email: jratcliff@infiniplex.net
** Personal website: http://jratcliffscarab.blogspot.com
** Coding Website:   http://codesuppository.blogspot.com
** FundRaising Blog: http://amillionpixels.blogspot.com
** Fundraising site: http://www.amillionpixels.us
** New Temple Site:  http://newtemple.blogspot.com
**
**
** The MIT license:
**
** Permission is hereby granted, free of charge, to any person obtaining a copy 
** of this software and associated documentation files (the "Software"), to deal 
** in the Software without restriction, including without limitation the rights 
** to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
** copies of the Software, and to permit persons to whom the Software is furnished 
** to do so, subject to the following conditions:
**
** The above copyright notice and this permission notice shall be included in all 
** copies or substantial portions of the Software.

** THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
** IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
** FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
** AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
** WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN 
** CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

*/



#if NOGRANNY


int GrannyMeshImporter::LoadMesh(const char *fname,GeometryInterface *callback) { return 0; };
void GrannyMeshImporter::SetProperty(const char *key,const char *value) { };

#else

#pragma comment(lib, "granny2.lib" )

#include "tga_io.h"

#include "quat.h"

#include "stringdict.h"
#include "log.h"
#include "inparser.h"
#include "sutil.h"
#include "animation.h"

#define ARENA_PUSH(Arena, type) (type *)GrannyMemoryArenaPush(Arena, sizeof(type))
#define ARENA_PUSH_SIZE(Arena, Size) GrannyMemoryArenaPush(Arena, Size)
#define ARENA_PUSH_ARRAY(Arena, Count, type) (type *)GrannyMemoryArenaPush(Arena, Count * sizeof(type))

// This include defines the output file format
#include "grannymesh.h"
#include "grannyfile.h"

#include "geometry.h"
#include "skeleton.h"

#define DO_CALLBACK 1

static float gMeterScale = 1.0f;
static bool  gDeformOk=false;

static float gameScale=10;

static GeometryInterface *callback = 0;

char mFileName[512];

#define FLIP_INDEX 0

#if 0
float RightVector[3] = {-1, 0, 0};
float UpVector[3]    = {0, 1, 0};
float BackVector[3]  = {0, 0, 1};
#else
float RightVector[3] = {1, 0, 0};
float UpVector[3]    = {0, 1, 0};
float BackVector[3]  = {0, 0, 1};
#endif

#if FLIP_INDEX
void FlipIndex(unsigned int count,unsigned short *indices)
{
	unsigned int tcount = count/3;
	for (unsigned int i=0; i<tcount; i++)
	{
		unsigned short i1 = indices[0];
		unsigned short i2 = indices[1];
		unsigned short i3 = indices[2];
		indices[2] = i1;
		indices[1] = i2;
		indices[0] = i3;
		indices+=3;
	}
}
#endif


// Forward declarations
bool ProcessFile(granny_file *SourceFile, char const *DestFileName);

void ProcessModel(granny_file_info *SourceFile, granny_model *SourceModel,
                  granny_memory_arena *Arena, model &DestModel);

void ProcessMesh(granny_file_info *SourceFile, granny_mesh *SourceMesh,
                 granny_memory_arena *Arena, model &DestModel,int *bone_mapping);

void ProcessTexture(granny_file_info *SourceFile,
                    granny_texture *SourceTexture,
                    granny_memory_arena *Arena, texture &DestTexture);

char *GetBestTextureNameForMaterial(granny_file_info *SourceFile,
                                    granny_material *Material);

void PrintGrannyError(granny_log_message_type Type,
                      granny_log_message_origin Origin,
                      char const *Error, void *UserData);


void  TransformFile(granny_file_info *TheFileInfo)
{

	//LogMessage(HB_T("Transforming: %s (%f units/meter)"),Spec::wideString(FileInfo->FromFileName).c_str(),FileInfo->ArtToolInfo->UnitsPerMeter);

  granny_art_tool_info *ArtToolInfo = TheFileInfo->ArtToolInfo;
  if ( ArtToolInfo )
  {
    granny_triple Origin = {0, 0, 0};
    granny_triple RightVector = {1, 0, 0};
    granny_triple UpVector = {0, 1, 0};
    granny_triple BackVector = {0, 0, 1};
    granny_real32 UnitsPerMeter = 0.1f;

    // Tell Granny to construct the transform from the file's coordinate
    // system to our coordinate system
    granny_triple Affine3;
    granny_matrix_3x3 Linear3x3;
    granny_matrix_3x3 InverseLinear3x3;
    GrannyComputeBasisConversion (
      TheFileInfo, UnitsPerMeter, 
      Origin, RightVector, UpVector, BackVector,
      Affine3, (granny_real32*)Linear3x3, (granny_real32*)InverseLinear3x3);

    // Tell Granny to transform the file into our coordinate system
    GrannyTransformFile ( TheFileInfo, Affine3, (granny_real32*)Linear3x3, (granny_real32*)InverseLinear3x3,
      1e-5f, 1e-5f,
      GrannyRenormalizeNormals | GrannyReorderTriangleIndices );
  }


}

const char * ExtractBaseName(const char *tname)
{
  static char name[512];
  if ( tname )
    strcpy(name,tname);
  else
	strcpy(name,"null");

  char *slash = name;
  char *dot   = 0;
  char *foo = name;
  while ( *foo )
  {
    if ( *foo == '\\' ) slash = foo+1;
    if ( *foo == '/' ) slash = foo+1;
    if ( *foo == '.' ) dot = foo;
    foo++;
  }


//  if ( dot ) *dot = 0;

  return slash;
}

static bool IsIgnore(const char *tname)
{
	return false;
}

void Process(file *DestFile)
{

  if ( DestFile->AnimationCount )
  {
    
    assert( DestFile->AnimationCount == 1 );

    for (int i=0; i<DestFile->AnimationCount; i++)
    {
      granny_animation *animation = DestFile->Animations[i];

      const char *name = animation->Name;
      float duration   = animation->Duration;

      int tcount = animation->TrackGroupCount;

      if ( tcount )
      {
        tcount = 1; // we only support one track

        for (int i=0; i<tcount; i++)
        {
          granny_track_group *track = animation->TrackGroups[i];

          int bcount = track->TransformTrackCount;

          const float FREQ = 1.0f / 60.0f; // sample it at 60hz

          // ok.. have everything I need to construct the animation!
          int framecount;

          if ( 1 )
          {
            int frame = 0;
            for (float t=0; t<duration; t+=FREQ)
            {
              frame++;
            }
            framecount = frame;
          }

          const char *bname = ExtractBaseName( name );

          Animation *a = new Animation(mFileName, bcount, framecount, duration, FREQ );

          for (int j=0; j<bcount; j++)
          {
            granny_transform_track &gt = track->TransformTracks[j];

            granny_track_sampler *sampler = GrannyGetTrackSamplerFor(&gt);

            granny_sample_context Context;

            Context.LocalClock = 0;
            Context.LocalDuration = duration;
            Context.UnderflowLoop = true;
            Context.OverflowLoop = true;

            granny_bound_transform_track binding;
            binding.Sampler        = sampler;
            binding.SourceTrack    = &gt;
            binding.SourceTrackIndex = j;
            binding.QuaternionMode = GrannyBlendQuaternionDirectly;

            const char *bname = gt.Name;

            a->SetTrackName(j, bname );

            int frame = 0;


            for (float t=0; t<duration; t+=FREQ, frame++ )
            {
              Context.LocalClock = t;
              Vector3d<float> pos(0,0,0);
              Quat            q;
              GrannySampleTrackPOLocal(&Context, &gt, &binding, pos.Ptr(), q.Ptr() );

              if ( frame >= 0 && frame < framecount )
              {
                a->SetTrackPose( j, frame, pos.Ptr(), q.Ptr() );
              }

            }

            assert( frame == framecount );


          }
#if DO_CALLBACK
          callback->NodeAnimation( a );
#endif
          delete a;

        }
      }
    }
  }

#if 0
  //...need to export the textures!
  if ( DestFile->TextureCount )
  {
    for (int i=0; i<DestFile->TextureCount; i++)
    {

      texture &t = DestFile->Textures[i];

      const char *name = ExtractBaseName( t.Name );

			if ( stristr(name,".tga") != 0 )
			{
				const char *fname = name;
				FILE *fph = fopen(fname,"rb");
				if ( fph )
				{
					fclose(fph);
				}
				else
				{
					if (t.Width && t.Height )
					{
						unsigned char *pixels = new unsigned char[t.Width*t.Height*4];
						const unsigned char *source = (const unsigned char *) t.Pixels;
						unsigned char *dest = pixels;
						int count = t.Width*t.Height;
						for (int j=0; j<count; j++)
						{
							unsigned char r = source[0];
							unsigned char g = source[1];
							unsigned char b = source[2];
							unsigned char a = source[3];

							dest[0] = a;
							dest[1] = r;
							dest[2] = g;
							dest[3] = b;

							dest+=4;
							source+=4;
						}

						tga_save_alpha(fname, (const unsigned char *)pixels, t.Width, t.Height );

						delete pixels;
					}
				}
			}
    }
  }
  //
#endif

  for (int i=0; i<DestFile->ModelCount; i++)
  {

    model &model = DestFile->Models[i];

    if ( model.BoneCount < 0 || model.BoneCount >= 512 )
    {
      gLog->Display("Model has completly bogus bone count of %d!!\r\n", model.BoneCount );
    }

    if ( model.BoneCount > 0 && model.BoneCount < 512  )
    {

      Skeleton *skeleton = new Skeleton(model.Name);

      Bone *bones = new Bone[ model.BoneCount];


      for (int i=0; i<model.BoneCount; i++)
      {
        const char *name = model.Bones[i].Name;
        int parent       = model.Bones[i].ParentIndex;

        granny_transform t = model.Bones[i].Transform;

#if 1
        if ( i == 0 )
        {
          granny_transform i = model.InitialPlacement;

          granny_transform result;
          GrannyMultiply(&result, &i, &t );

          t = result;

        }
#endif

//        struct granny_transform
//{
//    granny_uint32 Flags;
//    granny_triple Position;
//    granny_quad Orientation;
//    granny_triple ScaleShear[3];
//};

        float position[3];
        position[0] = t.Position[0];
        position[1] = t.Position[1];
        position[2] = t.Position[2];

        float rot[4];

        rot[0] = t.Orientation[0];
        rot[1] = t.Orientation[1];
        rot[2] = t.Orientation[2];
        rot[3] = t.Orientation[3];


        float scalex[3];
        scalex[0] = t.ScaleShear[0][0];
        scalex[1] = t.ScaleShear[0][1];
        scalex[2] = t.ScaleShear[0][2];

        float scaley[3];
        scaley[0] = t.ScaleShear[1][0];
        scaley[1] = t.ScaleShear[1][1];
        scaley[2] = t.ScaleShear[1][2];

        float scalez[3];
        scalez[0] = t.ScaleShear[2][0];
        scalez[1] = t.ScaleShear[2][1];
        scalez[2] = t.ScaleShear[2][2];


        bones[i].Set( name, parent, position, rot );


      }

      skeleton->SetBones( model.BoneCount, bones );
#if DO_CALLBACK
      callback->NodeSkeleton(skeleton);
#endif

      delete bones;
    }

    if ( model.RigidMeshCount )
    {
      for (int j=0; j<model.RigidMeshCount; j++)
      {
        rigid_mesh &mesh = model.RigidMeshes[j];


        bool deform = false;
        int boneindex = 0;

        if ( model.BoneCount > 1 && gDeformOk )
        {
          deform = true;
          for (int i=0; i<model.BoneCount; i++)
          {
            if ( stricmp(mesh.BoneName,model.Bones[i].Name) == 0 )
            {
              boneindex = i;
              break;
            }
          }

        }

        if ( deform )
        {
          GeometryDeformVertex *verts = new GeometryDeformVertex[mesh.VertexCount];
          GeometryDeformVertex *dest = verts;
          rigid_vertex   *source = mesh.Vertices;

          for (int i=0; i<mesh.VertexCount; i++)
          {
            dest->mPos[0] = source->Position[0]*gameScale;
            dest->mPos[1] = source->Position[1]*gameScale;
            dest->mPos[2] = source->Position[2]*gameScale;

            dest->mNormal[0] = source->Normal[0]*gameScale;
            dest->mNormal[1] = source->Normal[1]*gameScale;
            dest->mNormal[2] = source->Normal[2]*gameScale;

            dest->mTexel1[0] = source->TexCoord0[0];
            dest->mTexel1[1] = source->TexCoord0[1];

            dest->mTexel2[0] = source->TexCoord1[0];
            dest->mTexel2[1] = source->TexCoord1[1];

            dest->mWeight[0] = 1;
            dest->mWeight[1] = 0;
            dest->mWeight[2] = 0;
            dest->mWeight[3] = 0;
            dest->mBone[0]   = boneindex;
            dest->mBone[1]   = 0;
            dest->mBone[2]   = 0;
            dest->mBone[3]   = 0;

            dest++;
            source++;
          }
          for (int k=0; k<mesh.TriangleGroupCount; k++)
          {
            triangle_group &group = mesh.TriangleGroups[k];
            const char *texture = 0;
			if ( mesh.TextureCount )
			{
				int tindex = group.TextureIndex;
				texture = mesh.TextureNames[tindex];
			}
            const char *base = "null";

            if ( mesh.TextureCount )
              base = ExtractBaseName(texture);

            char scratch[512];
            sprintf(scratch,"%s", base );
            bool ignore = IsIgnore(scratch);
            if ( !ignore )
            {
#if DO_CALLBACK
              callback->NodeMaterial(scratch,texture);
#endif
            }
            unsigned short *idx = new unsigned short[ group.IndexCount ];
            for (int l=0; l<group.IndexCount; l++)
            {
              idx[l] = group.Indices[l];
            }
#if DO_CALLBACK
            if ( !ignore )
            {
            	#if FLIP_INDEX
            	FlipIndex(group.IndexCount,idx);
            	#endif
              callback->NodeTriangleList( mesh.VertexCount, verts, group.IndexCount, idx );
            }
#endif
            delete idx;
          }
          delete verts;
        }
        else
        {
          GeometryVertex *verts = new GeometryVertex[mesh.VertexCount];
          GeometryVertex *dest = verts;
          rigid_vertex   *source = mesh.Vertices;

          for (int i=0; i<mesh.VertexCount; i++)
          {
            dest->mPos[0] = source->Position[0]*gameScale;
            dest->mPos[1] = source->Position[1]*gameScale;
            dest->mPos[2] = source->Position[2]*gameScale;

            dest->mNormal[0] = source->Normal[0];
            dest->mNormal[1] = source->Normal[1];
            dest->mNormal[2] = source->Normal[2];

            dest->mTexel1[0] = source->TexCoord0[0];
            dest->mTexel1[1] = source->TexCoord0[1];

            dest->mTexel2[0] = source->TexCoord1[0];
            dest->mTexel2[1] = source->TexCoord1[1];

            dest++;
            source++;
          }
          for (int k=0; k<mesh.TriangleGroupCount; k++)
          {
            triangle_group &group = mesh.TriangleGroups[k];
			const char *texture = 0;
			if ( mesh.TextureCount ) 
			{
				int tindex = group.TextureIndex;
        texture = mesh.TextureNames[tindex];
			}
            const char *base = "null";
            if ( texture )
            {
              base = ExtractBaseName(texture);
            }

            char scratch[512];
            sprintf(scratch,"%s", base );
#if DO_CALLBACK
            bool ignore = IsIgnore(scratch);
            if ( !ignore )
            {
              callback->NodeMaterial(scratch,texture);
            }
#endif
            unsigned short *idx = new unsigned short[ group.IndexCount ];
            for (int l=0; l<group.IndexCount; l++)
            {
              idx[l] = group.Indices[l];
            }
#if DO_CALLBACK
            if ( !ignore )
            {
            	#if FLIP_INDEX
            	FlipIndex(group.IndexCount,idx);
            	#endif
              callback->NodeTriangleList( mesh.VertexCount, verts, group.IndexCount, idx );
            }
#endif
            delete idx;
          }
          delete verts;
        }

      }
    }

    if ( model.DeformableMeshCount )
    {
      for (int j=0; j<model.DeformableMeshCount; j++)
      {
        deformable_mesh &mesh = model.DeformableMeshes[j];

        GeometryDeformVertex *verts = new GeometryDeformVertex[mesh.VertexCount];

        if ( 1 )
        {
          GeometryDeformVertex *dest = verts;
          deformable_vertex   *source = mesh.Vertices;

          MyMatrix m;
          m.Rotate(0,3.141592654f/2.0f,0);
          m.SetTranslation(0.075f,0,0);

          m.Identity();

          int *bmap = mesh.BoneIndices;

          for (int i=0; i<mesh.VertexCount; i++)
          {

            Vector3d<float> p( source->Position );
            Vector3d<float> n( source->Normal );

            Vector3d<float> tp,tn;
            m.Transform(p,tp);
            m.TransformRotateOnly(n,tn);

            dest->mPos[0] = tp.x*gameScale;
            dest->mPos[1] = tp.y*gameScale;
            dest->mPos[2] = tp.z*gameScale;

            dest->mNormal[0] = tn.x;
            dest->mNormal[1] = tn.y;
            dest->mNormal[2] = tn.z;

            dest->mTexel1[0] = source->TexCoord0[0];
            dest->mTexel1[1] = source->TexCoord0[1];

            dest->mTexel2[0] = source->TexCoord1[0];
            dest->mTexel2[1] = source->TexCoord1[1];

            dest->mWeight[0] = source->Weights[0];
            dest->mWeight[1] = source->Weights[1];
            dest->mWeight[2] = source->Weights[2];
            dest->mWeight[3] = source->Weights[3];

            dest->mBone[0] = bmap[source->Bones[0]];
            dest->mBone[1] = bmap[source->Bones[1]];
            dest->mBone[2] = bmap[source->Bones[2]];
            dest->mBone[3] = bmap[source->Bones[3]];

            dest++;
            source++;
          }
        }



        for (int k=0; k<mesh.TriangleGroupCount; k++)
        {
          triangle_group &group = mesh.TriangleGroups[k];
          const char *texture = mesh.TextureNames[k];
          const char *base = ExtractBaseName(texture);
          char scratch[512];
          sprintf(scratch,"%s", base );
#if DO_CALLBACK
          bool ignore = IsIgnore(scratch);

          if ( !ignore )
            callback->NodeMaterial(scratch,texture);
#endif
          unsigned short *idx = new unsigned short[ group.IndexCount ];
          for (int l=0; l<group.IndexCount; l++)
          {
            idx[l] = group.Indices[l];
          }
#if DO_CALLBACK
          if ( !ignore )
          {
          	#if FLIP_INDEX
          	FlipIndex(group.IndexCount,idx);
          	#endif
            callback->NodeTriangleList( mesh.VertexCount, verts, group.IndexCount, idx );
          }
#endif
          delete idx;
        }

        delete verts;
      }
    }
  }
  
}

void GrannyMeshImporter::SetProperty(const char *key,const char *value)
{
}

const char * NextSlash(const char *scan)
{
	const char *slash = strstr(scan,"\\");
  if ( !slash )
	{
		slash = strstr(scan,"/");
	}
	return slash;
}

// Definitions
int GrannyMeshImporter::LoadMesh(const char *fname,GeometryInterface *iface)
{
  int Result = -1;

  callback = iface;

  strcpy(mFileName, fname );

#if DO_CALLBACK

	const char *begin = fname;
	const char *scan = NextSlash(begin);
	while ( scan )
	{
		begin = scan+1;
    scan = NextSlash(begin);
	}
	
  callback->NodeMesh( begin, 0 );

#endif

  if(!GrannyVersionsMatch)
  {
    printf("Warning: the Granny DLL currently loaded "
           "doesn't match the .h file used during compilation\n");
  }

  granny_log_callback Callback;
  Callback.Function = PrintGrannyError;
  Callback.UserData = 0;
  GrannySetLogCallback(&Callback);

  const char *SourceFileName = fname;
  const char *DestFileName   = "mesh.out";

  // Have Granny read in the source file

  const char *remapfname = SourceFileName;

  granny_file *SourceFile = GrannyReadEntireFile(remapfname);


  if(SourceFile)
  {
    // Process the file contents and write out the result
    if(ProcessFile(SourceFile, DestFileName))
    {
      Result = 0;
    }
    else
    {
      printf("Unable to write %s.\n", DestFileName);
    }
  }
  else
  {
    printf("Unable to read %s.\n", SourceFileName);
  }

  // Free the memory used to hold the source file
  GrannyFreeFile(SourceFile);

  return Result;
}

bool ProcessFile(granny_file *SourceFile, char const *DestFileName)
{
  bool Result = false;

  granny_memory_arena *Arena = GrannyNewMemoryArena();
  assert(Arena);
  granny_file_info *SourceFileInfo = GrannyGetFileInfo(SourceFile);
  if(SourceFileInfo)
  {
    TransformFile(SourceFileInfo);
    file *DestFile = ARENA_PUSH(Arena, file);
    int ModelCount = SourceFileInfo->ModelCount;
    DestFile->ModelCount = ModelCount;
    DestFile->Models = ARENA_PUSH_ARRAY(Arena, ModelCount, model);
    {for(int ModelIndex = 0; ModelIndex < ModelCount; ++ModelIndex)
    {
      ProcessModel(SourceFileInfo, SourceFileInfo->Models[ModelIndex],Arena, DestFile->Models[ModelIndex]);
    }}

    int TextureCount = SourceFileInfo->TextureCount;
    DestFile->TextureCount = TextureCount;
    DestFile->Textures = ARENA_PUSH_ARRAY(Arena, TextureCount, texture);

    {for(int TextureIndex = 0; TextureIndex < TextureCount; ++TextureIndex)
    {
      ProcessTexture(SourceFileInfo,SourceFileInfo->Textures[TextureIndex],Arena, DestFile->Textures[TextureIndex]);
    }}

    int AnimationCount = SourceFileInfo->AnimationCount;
    DestFile->AnimationCount = AnimationCount;
    DestFile->Animations = ARENA_PUSH_ARRAY(Arena, AnimationCount, granny_animation *);

    {for(int AnimationIndex = 0; AnimationIndex < AnimationCount; ++AnimationIndex)
    {
      DestFile->Animations[AnimationIndex] = SourceFileInfo->Animations[AnimationIndex];
    }}

    Process(DestFile);

		Result = true;

  }
  else
  {
    printf("Unable to parse input file.\n");
  }

  GrannyFreeMemoryArena(Arena);

  return(Result);
}

void ProcessModel(granny_file_info *SourceFile, granny_model *SourceModel, granny_memory_arena *Arena, model &DestModel)
{

  if ( stristr(SourceModel->Name,"occluder") )
  {
    printf("Skipping occluder\r\n");
    return;
  }

  if ( stristr(SourceModel->Name,"lod") )
  {
    printf("Skipping lod_\r\n");
    return;
  }


  granny_model_instance *ginstance = GrannyInstantiateModel(SourceModel);
  granny_skeleton *Skeleton        = GrannyGetSourceSkeleton(ginstance);


  DestModel.InitialPlacement = SourceModel->InitialPlacement;

  DestModel.Name = SourceModel->Name;

  int MeshCount = SourceModel->MeshBindingCount;

  DestModel.RigidMeshCount = 0;
  DestModel.RigidMeshes = ARENA_PUSH_ARRAY(Arena, MeshCount, rigid_mesh);

  DestModel.DeformableMeshCount = 0;
  DestModel.DeformableMeshes = ARENA_PUSH_ARRAY(Arena, MeshCount, deformable_mesh);

  {for(int MeshIndex = 0; MeshIndex < MeshCount; ++MeshIndex)
  {
    granny_mesh *SourceMesh = SourceModel->MeshBindings[MeshIndex].Mesh;
    granny_mesh_binding *mbinding = GrannyNewMeshBinding(SourceMesh, Skeleton, Skeleton);
    int *ToBoneIndices = GrannyGetMeshBindingToBoneIndices(mbinding);
    ProcessMesh(SourceFile, SourceMesh, Arena, DestModel, ToBoneIndices);
  }}

  if(SourceModel->Skeleton)
  {
    int BoneCount = SourceModel->Skeleton->BoneCount;
    DestModel.BoneCount = BoneCount;
    DestModel.Bones = ARENA_PUSH_ARRAY(Arena, BoneCount, bone);
    {for(int BoneIndex = 0; BoneIndex < BoneCount; ++BoneIndex)
    {
      granny_bone &SourceBone = SourceModel->Skeleton->Bones[BoneIndex];
      bone &DestBone = DestModel.Bones[BoneIndex];
      DestBone.Name = SourceBone.Name;
      DestBone.ParentIndex = SourceBone.ParentIndex;
      DestBone.Transform = SourceBone.LocalTransform;
    }}
  }
  else
  {
    printf("ERROR: Skeletons must be included in the export for "
           "this preprocessor.  Please re-export your file with "
           "the skeleton included.\n");
  }
}

void ProcessMesh(granny_file_info *SourceFile, granny_mesh *SourceMesh,granny_memory_arena *Arena, model &DestModel,int *bone_mapping)
{
  int TextureCount = SourceMesh->MaterialBindingCount;
  char **TextureNames = ARENA_PUSH_ARRAY(Arena, TextureCount, char *);
  {for(int MaterialBindingIndex = 0; MaterialBindingIndex < TextureCount; ++MaterialBindingIndex)
  {
    TextureNames[MaterialBindingIndex] = GetBestTextureNameForMaterial(SourceFile,SourceMesh->MaterialBindings[MaterialBindingIndex].Material);
  }}

	if ( SourceMesh->PrimaryTopology )
	{
		int GroupCount = SourceMesh->PrimaryTopology->GroupCount;
		triangle_group *TriangleGroups = ARENA_PUSH_ARRAY(Arena, GroupCount, triangle_group);
		{for(int GroupIndex = 0; GroupIndex < GroupCount;	++GroupIndex)
		{
			granny_tri_material_group &SourceGroup = SourceMesh->PrimaryTopology->Groups[GroupIndex];
			triangle_group &DestGroup = TriangleGroups[GroupIndex];

			DestGroup.TextureIndex = SourceGroup.MaterialIndex;
			if(SourceMesh->PrimaryTopology->IndexCount)
			{
				DestGroup.IndexCount = 3*SourceGroup.TriCount;
				DestGroup.Indices = &SourceMesh->PrimaryTopology->Indices[3*SourceGroup.TriFirst];
			}
			else if ( SourceMesh->PrimaryTopology->Index16Count )
			{
				// TODO: This happens when you have only 16-bit indices
				// or no indices at all
        DestGroup.IndexCount = 3*SourceGroup.TriCount;
        DestGroup.Indices = new int[DestGroup.IndexCount];
        const unsigned short *source = &SourceMesh->PrimaryTopology->Indices16[3*SourceGroup.TriFirst];
        int *dest = DestGroup.Indices;
        for (int i=0; i<DestGroup.IndexCount; i++)
        {
          *dest++ = (unsigned int)*source++;
        }
			}
      else
      {
        assert(0); // no indices found!
      }
		}}

#if 0
    unsigned int VertexCount;
    GrannyVertexType type;
    void *mem = getGrannyVertices(SourceMesh,type,VertexCount);
#endif
    int BoneBindingCount = SourceMesh->BoneBindingCount;
    if(BoneBindingCount > 1)
    {
      deformable_mesh &DestMesh = DestModel.DeformableMeshes[DestModel.DeformableMeshCount++];
      DestMesh.Name = SourceMesh->Name;
      DestMesh.TextureCount = TextureCount;
      DestMesh.TextureNames = TextureNames;
      DestMesh.TriangleGroupCount = GroupCount;
      DestMesh.TriangleGroups = TriangleGroups;
      int BoneCount = SourceMesh->BoneBindingCount;
      DestMesh.BoneCount = BoneCount;
      DestMesh.BoneNames = ARENA_PUSH_ARRAY(Arena, BoneCount, char *);
      {for(int BoneBindingIndex = 0; BoneBindingIndex < BoneCount; ++BoneBindingIndex)
      {
        DestMesh.BoneNames[BoneBindingIndex] = SourceMesh->BoneBindings[BoneBindingIndex].BoneName;
      }}

      DestMesh.BoneIndices = bone_mapping;
      DestMesh.VertexCount = SourceMesh->PrimaryVertexData->VertexCount;
      DestMesh.Vertices = ARENA_PUSH_ARRAY(Arena, DestMesh.VertexCount,deformable_vertex);

      GrannyCopyMeshVertices(SourceMesh, DeformableVertexType,DestMesh.Vertices);
    }
    else
    {
      rigid_mesh &DestMesh = DestModel.RigidMeshes[DestModel.RigidMeshCount++];
      DestMesh.Name = SourceMesh->Name;
      DestMesh.TextureCount = TextureCount;
      DestMesh.TextureNames = TextureNames;
      DestMesh.TriangleGroupCount = GroupCount;
      DestMesh.TriangleGroups = TriangleGroups;
      assert(BoneBindingCount == 1);
      DestMesh.BoneName = SourceMesh->BoneBindings[0].BoneName;
      DestMesh.VertexCount = SourceMesh->PrimaryVertexData->VertexCount;
      DestMesh.Vertices = ARENA_PUSH_ARRAY(Arena, DestMesh.VertexCount,rigid_vertex);
      GrannyCopyMeshVertices(SourceMesh, RigidVertexType,DestMesh.Vertices);



    }
  }
}

void ProcessTexture(granny_file_info *SourceFile, granny_texture *SourceTexture,granny_memory_arena *Arena, texture &DestTexture)
{
  DestTexture.Name = SourceTexture->FromFileName;
  if(SourceTexture->ImageCount)
  {
    int DestStride = (SourceTexture->Width * GrannyRGBA8888PixelFormat->BytesPerPixel);
    DestTexture.Width = SourceTexture->Width;
    DestTexture.Height = SourceTexture->Height;
    DestTexture.Size = DestStride * DestTexture.Height;
    DestTexture.Pixels = ARENA_PUSH_ARRAY(Arena, DestTexture.Size,unsigned char);
    GrannyCopyTextureImage(SourceTexture, 0, 0,GrannyRGBA8888PixelFormat,SourceTexture->Width,SourceTexture->Height,DestStride, DestTexture.Pixels);
  }
  else
  {
    DestTexture.Width = 0;
    DestTexture.Height = 0;
    DestTexture.Size = 0;
    DestTexture.Pixels = 0;
  }
}

char * GetBestTextureNameForMaterial(granny_file_info *SourceFile,granny_material *Material)
{
  char *TextureName = 0;


  char scratch[512];
  scratch[0] = 0;

  if(Material)
  {
    if(Material->Texture)
    {
      TextureName = Material->Texture->FromFileName;
    }
    else
    {

      {for(int MapIndex = 0; (MapIndex < Material->MapCount); ++MapIndex)
      {
        char *tname = GetBestTextureNameForMaterial(SourceFile, Material->Maps[MapIndex].Material);
				if ( tname )
				{
					const char *bname = ExtractBaseName(tname);

					if ( strlen(scratch) )
					{
						strcat(scratch,"+");
						strcat(scratch,bname);
					}
					else
					{
						strcpy(scratch,bname);
					}
				}
      }}
			StringRef ref = SGET(scratch);
			TextureName = (char *)ref.Get();
    }
  }

  return(TextureName);
}

void PrintGrannyError(granny_log_message_type Type,granny_log_message_origin Origin,char const *Error, void *UserData)
{
  printf("GRANNY: \"%s\"\n", Error);
}

#endif
