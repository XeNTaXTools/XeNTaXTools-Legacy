import newGameLib
reload(newGameLib)
from newGameLib import *
import Blender	

		
def eta(value,pad):
	intv=value/int(pad)
	floatv=value/float(pad)
	neta=floatv-intv
	if 	neta>0:return (1+intv)*pad
	else: return intv*pad

def hxtParser(filename,g):
	g.logOpen()
	g.endian='>'
	g.word(7)
	g.i(34)
	g.seek(140)
	imageCount=g.i(1)[0]
	g.i(5)
	folder=g.word(g.i(1)[0])	
	g.seek(108,1)
	for m in range(imageCount):
		texName=g.word(g.i(1)[0])
		A=g.i(11)
		size=g.i(1)[0]
		g.seek(size,1)
		g.i(3)
		for m in range(3):
			B=g.i(6)
		g.seek(84,1)
		
	#g.debug=True
	#.ddm section
	g.word(4)
	g.seek(164,1)
	
	A=g.i(3)
	t=g.tell()
	boneNameList=g.B(A[2])
	parentList=g.B(A[2])
	A1Flag=True
	if A[1]==19:
		#skeleton=Skeleton()
		#skeleton.BONESPACE=True
		#skeleton.NICE=True
		#skeleton.SORT=True
		g.seek(t+eta(A[2]*2,8))
		for n in range(A[2]):
			#bone=Bone()
			#bone.name=str(boneNameList[n])
			posMatrix=VectorMatrix(g.f(3))
			#bone.matrix=posMatrix
			g.f(1)
			#skeleton.boneList.append(bone)
		for n in range(A[2]):g.i(1)	
		B=g.i(1)
		for n in range(B[0]):
			#bone=skeleton.boneList[n]
			posMatrix=VectorMatrix(g.f(3))
			g.f(1)
			rotMatrix=QuatMatrix(g.f(4)).resize4x4()#.invert()
			#matrix=rotMatrix*posMatrix
			#bone.matrix=matrix
			#if parentList[n]!=255:
			#	bone.parentName=str(parentList[n])
			#else:
			#	bone.parentName=None
			posMatrix=VectorMatrix(g.f(3))
			g.f(1)
		B=g.i(3)
		for n in range(B[1]):
			size=g.i(1)[0]
			t=g.tell()
			g.seek(t+size)
		g.logWrite('mesh offset:'+str(g.tell()))	
		#skeleton.draw()	
	elif A[1]==23:
		g.seek(t+eta(A[2]*2,8))	
		for n in range(A[2]):g.f(4)	
		for n in range(A[2]):g.f(4)
		for n in range(A[2]):g.i(1)	
		B=g.i(1)
		for n in range(B[0]):g.f(12)
		B=g.i(3)
		for n in range(B[1]):
			size=g.i(1)[0]
			t=g.tell()
			g.seek(t+size)
		g.logWrite('mesh offset:'+str(g.tell()))	
	elif A[1]==27:
		g.seek(t+eta(A[2]*2,8))
		for n in range(A[2]):g.f(4)	
		for n in range(A[2]):g.f(4)
		for n in range(A[2]):g.i(1)	
		B=g.i(1)
		for n in range(B[0]):g.f(12)
		B=g.i(3)
		for n in range(B[1]):
			size=g.i(1)[0]
			t=g.tell()
			g.seek(t+size)
		g.logWrite('mesh offset:'+str(g.tell()))		
	elif A[1]==31:
		g.seek(t+eta(A[2]*2,8))
		for n in range(A[2]):g.f(4)	
		for n in range(A[2]):g.f(4)	
		for n in range(A[2]):g.f(4)
		for n in range(A[2]):g.i(1)	
		B=g.i(1)
		for n in range(B[0]):g.f(12)
		B=g.i(3)
		for n in range(B[1]):
			size=g.i(1)[0]
			t=g.tell()
			g.seek(t+size)
		g.logWrite('mesh offset:'+str(g.tell()))
	else:
		A1Flag=False
		print 'WARNING:not supported:',A
		
	if 	A1Flag==True:
		
		#g.debug=True
		#g.seek(35657)
		matList=[]
		count=g.i(1)[0]
		for m in range(count):
			mat=Mat()
			matList.append(mat)
			name=g.word(g.i(1)[0])
			mat.name=name
			print m,'material:',name
			for n in range(4):
				name=g.word(g.i(1)[0])
				print ' '*4,'image:',name
				g.i(8)
				if n==0:
					search=Searcher()
					search.what=name+'0.dds'
					search.dir=g.dirname
					search.run()
					if len(search.list)>0:
						mat.diffuse=search.list[0]							
			g.seek(168,1)
		modelCount=g.i(1)[0]	
		for m in range(modelCount):	
			skeleton=Skeleton()
			skeleton.name='model-'+str(m)
			skeleton.draw()
			A=g.i(5)
			print A
			#g.debug=False	
			#if m==1:break
			#mesh=Mesh()
			#mesh.TRISTRIP=True
			vertPosList=[]
			vertUVList=[]
			skinIndiceList=[]
			skinWeightList=[]
			indiceList=g.H(A[4])
			if A[1]==8:
				for n in range(A[2]):
					t=g.tell()
					vertPosList.append(g.f(3))
					g.seek(t+32)
					vertUVList.append(g.half(2))
					g.seek(t+36)
					skinIndiceList.append(g.B(4))
					skinWeightList.append(g.B(4))
					g.seek(t+44)
			if A[1]==3:
				for n in range(A[2]):
					t=g.tell()
					vertPosList.append(g.f(3))
					g.seek(t+32)
					vertUVList.append(g.half(2))
					g.seek(t+36)
					skinIndiceList.append(g.B(4))
					skinWeightList.append(g.B(4))
					g.seek(t+48)
			#g.debug=True	
			g.i(A[3])
			
			for n in range(A[0]):
				mesh=Mesh()	
				mat=Mat()	
				mat.ZTRANS=True	
				C=g.i(14)
				print n,'mesh:',C
				mat.diffuse=matList[C[4]].diffuse
				mesh.indiceList=indiceList[C[12]:C[12]+C[13]]
				mesh.vertPosList=vertPosList[C[2]:C[2]+C[3]]
				mesh.vertUVList=vertUVList[C[2]:C[2]+C[3]]
				localskinIndiceList=skinIndiceList[C[2]:C[2]+C[3]]
				localskinWeightList=skinWeightList[C[2]:C[2]+C[3]]
				localbonemap=[]
				for i,list in enumerate(localskinIndiceList):
					for j,item in enumerate(list):
						if localskinWeightList[i][j]!=0:
							if item not in localbonemap:
								localbonemap.append(item)
				#localbonemap.sort()				
				skin=Skin()
				#for i in range(C[3]):mesh.skinIDList.append([1])
				count=g.i(1)[0]
				boneMap=g.i(count)
				#skin.boneMap=boneMap
				#print 	localbonemap	,boneMap
				for i in range(C[3]):
					skinindiceList=[]
					skinweightList=[]
					#print localskinIndiceList[i]
					for j in range(4):
						id=localskinIndiceList[i][j]
						if localskinWeightList[i][j]!=0:
							skinindiceList.append(boneMap[		localbonemap.index(id)	])
							#skinindiceList.append(	localbonemap.index(id)	)
							skinweightList.append(localskinWeightList[i][j])
					#mesh.skinIndiceList.append(skinindiceList)
					#mesh.skinWeightList.append(skinweightList)
				#mesh.skinList.append(skin)
				g.i(11)
				mat.TRISTRIP=True
				mesh.matList.append(mat)
				mesh.BINDSKELETON=skeleton.name
				mesh.draw()
		
	g.debug=True
	g.tell()
	g.logClose()
	
def Parser():	
	filename=input.filename
	print
	print filename
	print
	ext=filename.split('.')[-1].lower()	
	
	if ext=='hxt':
		file=open(filename,'rb')
		g=BinaryReader(file)
		hxtParser(filename,g)
		file.close()
 
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
	
Blender.Window.FileSelector(openFile,'import','Knights Contract PS3 files: *hxt - model') 
	