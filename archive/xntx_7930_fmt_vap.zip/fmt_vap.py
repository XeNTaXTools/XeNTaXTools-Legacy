from inc_noesis import *
import os
from ctypes import *
import noewin

def registerNoesisTypes():
    handle = noesis.registerTool("&bbr2 to ktx2", ToolMethod)
    return 1
    
listBox = None
editBox = None
filelist = []
bytes1 = [
    0xAB, 0x4B, 0x54, 0x58, 0x20, 0x32, 0x30, 0xBB, 0x0D, 0x0A, 0x1A, 0x0A, 
    0x94, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00]
bytes2 = [
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00,
	0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x68, 0x00, 0x00, 0x00,
	0x2C, 0x00, 0x00, 0x00, 0x94, 0x00, 0x00, 0x00, 0x38, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0xD0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x02, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x2C, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x02, 0x00, 0x28, 0x00, 0xA1, 0x01, 0x02, 0x00, 0x03, 0x03, 0x00, 0x00,
	0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x3F, 0x02,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xFF, 0xFF, 0xFF, 0xFF,
	0x33, 0x00, 0x00, 0x00, 0x4B, 0x54, 0x58, 0x77, 0x72, 0x69, 0x74, 0x65,
	0x72, 0x00, 0x55, 0x6E, 0x69, 0x64, 0x65, 0x6E, 0x74, 0x69, 0x66, 0x69,
	0x65, 0x64, 0x20, 0x61, 0x70, 0x70, 0x20, 0x2F, 0x20, 0x6C, 0x69, 0x62,
	0x6B, 0x74, 0x78, 0x20, 0x76, 0x34, 0x2E, 0x30, 0x2E, 0x30, 0x2D, 0x62,
	0x65, 0x74, 0x61, 0x38, 0x7E, 0x32, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    
    
def AllConvertMethod(noeWnd, controlId, wParam, lParam):
    button = noeWnd.getControlById(controlId)
    global filelist
    for file in filelist:
        toKTX2(file)
    listBox.resetContent()
    filelist = []
    return True
    
def OneConvertMethod(noeWnd, controlId, wParam, lParam):
    button = noeWnd.getControlById(controlId)
    listIndex = listBox.getSelectionIndex()
    file = filelist[listIndex]
    toKTX2(file)
    listBox.removeString(listBox.getStringForIndex(listIndex))
    filelist.remove(filelist[listIndex])
    return True

def scan(path, file):
    global filelist
    filelist = []
    listBox.resetContent()
    
    if file:
        filelist.append(path)
        listBox.addString(path)
    else:
        for root, dirs, files in os.walk(path):
            for file in files:
                ext = os.path.splitext(file)[1]
                if ext == ".vap" or ext == ".dat":
                    filelist.append(os.path.join(root,file))
                    listBox.addString(filelist[-1].replace(path,''))

    if filelist:
        listBox.selectString(listBox.getStringForIndex(0))
    return 1
    
def EditMethod(noeWnd, controlId, wParam, lParam):
    if (wParam >> 16) == noewin.EN_CHANGE:
        path = editBox.getText()
        if os.path.isfile(path):
            scan(path, True)
        elif os.path.exists(path):
            scan(path, False)
        else: 
            listBox.resetContent()
    return 1
    
def ToolMethod(toolIndex):
    noeWnd = noewin.NoeUserWindow("rbb2 to ktx2", "convert", 500, 300)

    noeWindowRect = noewin.getNoesisWindowRect()
    if noeWindowRect:
        windowMargin = 64
        noeWnd.x = noeWindowRect[0] + windowMargin
        noeWnd.y = noeWindowRect[1] + windowMargin
    if not noeWnd.createWindow():
        print("Failed to create window.")
        return 0

    noeWnd.setFont("Arial", 14)
    
    buttonAllConvert = noeWnd.createButton("All convert", 10, 225, 96, 32, AllConvertMethod)
    buttonAll = noeWnd.getControlByIndex(buttonAllConvert)
    
    buttonOneConvert = noeWnd.createButton("selected convert", 116, 225, 126, 32, OneConvertMethod)
    buttonOne = noeWnd.getControlByIndex(buttonOneConvert)
    
    global editBox
    editIndex = noeWnd.createEditBox(10, 10, 480, 27, "path...", EditMethod, True)
    editBox = noeWnd.getControlByIndex(editIndex)
    
    global listBox 
    listIndex = noeWnd.createListBox(10, 42, 480, 200, None, noewin.LBS_NOTIFY)
    listBox = noeWnd.getControlByIndex(listIndex)
    
    return 0

def toKTX2(path):
    f = open(path, "rb+")
    f.seek(0x19)
    wth_hgt = f.read(8)
    f.seek(0x25)
    size = struct.unpack('I', f.read(4))[0]
    data = f.read(size) 
    f.seek(0x0)
    f.flush()
    f.truncate()
    f.write(bytes(bytes1))
    f.write(wth_hgt)
    f.write(bytes(bytes2))
    f.write(data)
    f.close()
    os.rename(path, os.path.splitext(path)[0] + ".ktx2")
    print("converted:",path)
    
    return 1