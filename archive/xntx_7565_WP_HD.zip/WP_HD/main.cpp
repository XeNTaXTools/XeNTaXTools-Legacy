/*
#################################################################
# DISCLAIMER This is an excerpt from my Make_H2O project. (RIP)
#
# It is provided as is. It's self-written, except the __inline,
# the bubblesort-function and the MinGW_gcc_dll.
#
# So this is MY code, but you can do with it whatever you want.
#
# If you don't like my coding style then don't use it or write
# your own code.
# I'm writing code to solve problems not to be sophisticated.
# (To avoid complaints some of my ugly code was hidden in the
#  DLL_MakeH2O.dll.)
#
# Use it on your own risk. I won't overtake any responsibilities.
#################################################################
*/
#include <windows.h>

#include <stdio.h>		// FILE
#include <math.h>		//
#include "Main.h"

static char g_szClassName[] = "MyWindowClass";
static HINSTANCE g_hInst = NULL;

#define IDC_MAIN_TEXT   1001
#define bool BOOL
#define false FALSE
#define true TRUE
#define ID_LIST     1
#define ID_EDIT     2
#define ID_BUTTON1  3
#define ID_COMBO1   4

//typedef unsigned long   DWORD; // no effect
// replaced %d by %d, %x by %lx

#define FILENAME  TEXT("MakeH2O_log.txt")

#define chDIMOF(Array) (sizeof(Array) / sizeof(Array[0]))
__inline void chMB(PCSTR s) {
   char szTMP[128];
   GetModuleFileNameA(NULL, szTMP, chDIMOF(szTMP));
   MessageBoxA(GetActiveWindow(), s, szTMP, MB_OK);
}

BYTE model = 8 ;    // 1: MLX, 2: Capt'n America, 3: Sly Cooper TiT  4: Ride 5: Atlantica onl, 6: winning 11 7: Eagle Debris
                    // 8: Wipeout, 9: Fahrenheit
                    //

char szErrMess[1024]= "error in H20 no: " ;    // about 20 MB static file buffer for model files
char szFileNameG[MAX_PATH], szWorkDir[MAX_PATH];
BYTE SM_cntArr[10] ;
DWORD dwFileSize, dwStart, lastJ ;
FILE *stream ;          // for logfile (unused so far)
LPVOID lpFBuf ;         // pointer to file buffer
//bool bFstRun= true ;    // KinectSW

void bubblesort(int* &array, int* &array2, int length)   // array-Werte als call-by-value, oder doch by ref? (mit &)
 {
    int i, j;
    for (i = 0; i < length - 1; ++i)

        for (j = 0; j < length - i - 1; ++j) {
            if (array[j] > array[j + 1]) {
                int tmp = array[j]; array[j] = array[j + 1]; array[j + 1] = tmp;
                tmp = array2[j]; array2[j] = array2[j + 1]; array2[j + 1] = tmp;
            }
        }
 }

void Show_nFloats(FILE *stream, char* &pFBuf, DWORD &j, BYTE cnt, bool bBigE)
{
    char tmp[4] ;
    BYTE i, l ;
    float *pFloat ;
	float fData = 0.0f;

	pFloat= &fData ;

    if (bBigE)
        for (i=0;i<cnt;i++) {
            for (l=0;l<4;l++) tmp[3-l]= *(pFBuf+l) ;
            pFloat = (float*) tmp ;
			fprintf( stream, "%f ", *pFloat) ; pFBuf += 4 ; j+= 4 ;
		}
	else
        for (i=0;i<cnt;i++) {
			pFloat = (float*) pFBuf ;
			fprintf( stream, "%f ", *pFloat) ; pFBuf += 4 ; j+= 4 ;
		}
    fprintf( stream, "\n") ;
}

void ShowDWord(FILE *stream, char* &pFBuf, DWORD &j)
{
	BYTE i ;
	int nValue[4] ;

	for (i=0;i<4;i++) {									// 1x DW
		nValue[i] = (*pFBuf & 255) ; pFBuf++ ; j++ ;
		if (nValue[i]<16) fprintf( stream, "0") ;
		fprintf( stream, "%X ", nValue[i]) ;
	}
}

char * ShowString(FILE *stream, char* &pFBuf, DWORD &j, DWORD &dwStart)
{
	char szName[256] ;
	BYTE * pByte ;
	BYTE i ;
	DWORD dwCnt1 ;

	pByte = (BYTE*) &dwCnt1 ;							// DW-cnter Stringl�nge
	for (i=0;i<4;i++) {									//
		*pByte = *pFBuf &255 ; pByte++; pFBuf++; j++ ;
	}
	if (dwCnt1>255) { dwCnt1 = 0 ; fprintf( stream, "(strLen) ABBRUCH bei %7lx\n\n", j+dwStart); }
	dwStart+= dwCnt1 + 4 ;
	for (i=0;i<dwCnt1;i++) {							// String f�llen
		szName[i]= *pFBuf ; pFBuf++; j++ ;
	}
	szName[i]= '\0' ;									// Bone name
	return szName ;             // return local address, nicht gut?
	//fprintf( stream, "%s ", szName) ;
}

char * ShowFName(FILE *stream, char* &pFBuf, DWORD &j, BYTE cnt, DWORD &dwStart)
{
	char szName[256] ;
	//BYTE * pByte ;
	BYTE i ;

	if (cnt>255) { cnt = 0 ; fprintf( stream, "(strLen) ABBRUCH bei %7lx\n\n", j+dwStart); }
	dwStart+= cnt ;
	for (i=0;i<cnt;i++) {							// String f�llen
		szName[i]= *pFBuf ; pFBuf++; j++ ;
	}
	szName[i]= '\0' ;									// Bone name
	return szName ;             // return local address, nicht gut?
	//fprintf( stream, "%s ", szName) ;
}

WORD GetFaceIndexWord(char* &pFBuf, DWORD &j, DWORD &minFaceInd, DWORD &maxFaceInd, DWORD lastFaceInd, bool bBigE)		//
{																// lastFaceInd: start face index f�r n�chstes Submesh
	//char * pTmp ;
	BYTE i ;
	int nValue[3] ;
	WORD wFaceInd ;

	//pTmp= pFBuf ;
	for (i=0;i<2;i++) {
		nValue[i] = (*pFBuf & 255) ; pFBuf++ ; j++ ;			// 2 Byte-Index
	}
	if (bBigE)
        wFaceInd = (WORD) (nValue[1]+nValue[0]*256) + lastFaceInd ;
    else wFaceInd = (WORD) (nValue[0]+nValue[1]*256) + lastFaceInd ;
	// genome face-no +1 f�r Wandlung to Wavefront-obj
	wFaceInd++ ;
	if (wFaceInd<minFaceInd) minFaceInd = wFaceInd ;
	if (wFaceInd>maxFaceInd) maxFaceInd = wFaceInd ;
	return wFaceInd ;
}

DWORD GetFaceIndex(char* &pFBuf, DWORD &j, DWORD &minFaceInd, DWORD &maxFaceInd, DWORD lastFaceInd, bool bDW)		//
{																// lastFaceInd: start face index f�r n�chstes Submesh
	//char * pTmp ;
	BYTE i ;
	int nValue[3] ;
	DWORD dwFaceInd ;

	//pTmp= pFBuf ;
	for (i=0;i<2;i++) { // supa, wie soll'n das 'n DWORD Wert werden?
		nValue[i] = (*pFBuf & 255) ; pFBuf++ ; j++ ;			// 2 Byte-Index
	}
	dwFaceInd = (WORD) (nValue[0]+nValue[1]*256) + lastFaceInd ;				//
	if (bDW) { nValue[2] = (*pFBuf & 255) ; pFBuf+=2 ; j+=2 ;
        dwFaceInd += (DWORD) nValue[2]*65536 ;
	}
	// genome face-no +1 f�r Wandlung to Wavefront-obj
	dwFaceInd++ ;
	if (dwFaceInd<minFaceInd) minFaceInd = dwFaceInd ;
	if (dwFaceInd>maxFaceInd) maxFaceInd = dwFaceInd ;
	return dwFaceInd ;
}

bool create_H2O(char szPathname[], WORD no, char lines[][20], DWORD addrFI, DWORD dwFaceIndCnt, DWORD addrUV, BYTE sizeUVB, DWORD addrV, DWORD dwVertsCnt, BYTE mode)
{                                                                                   // modi: 0= seq. mode, 1=VBlock, 2= mixed mode
	FILE * stream ;  // local
	char szH2O[256], szNo[5], szTmp[12] ;

    // upset about the use of "unsafe" strcpy/strcat? -> noone hinders u to rewrite this
    // but the code until "return" doesn't require a change for other models!
    _itoa(no, szNo, 10) ;           // number of next H2O file to be created
    strcpy(szH2O, szPathname) ; strcat(szH2O,"_") ; strcat(szH2O,szNo) ; strcat(szH2O,".h2o") ;
    stream = fopen( szH2O, "w" );
    if( stream == NULL ) {
        printf("%s open error!\n", szH2O) ;
        return (FALSE) ;
    }
    strcpy(lines[0], "0x") ; _itoa(addrFI, szTmp, 16) ; strcat(lines[0], szTmp) ; strcat(lines[0], " ") ;
    _itoa(dwFaceIndCnt, szTmp, 10) ; strcat(lines[0], szTmp) ;
    if (szTmp[0]=='-') {
        //strcat(lines[0], "err") ;
        strcat(szErrMess, szNo) ; strcat(szErrMess, ", ") ;
    }
    fprintf(stream, "%s\n", lines[0]) ;
    fprintf(stream, "%s\n%s\n", lines[1], lines[2]) ;
    strcpy(lines[3], "0x") ; _itoa(addrV, szTmp, 16) ; strcat(lines[3], szTmp) ; strcat(lines[3], " ") ;
    _itoa(dwVertsCnt, szTmp, 10) ; strcat(lines[3], szTmp) ;
    if (szTmp[0]=='-') {
        strcat(szErrMess, szNo) ; strcat(szErrMess, ", ") ;
    }
    fprintf(stream, "%s\n%s\n", lines[3], lines[4]) ;
    if (mode==2) {    // 'mixed mode' has a separate UV block
        strcpy(lines[5], "0x") ; _itoa(addrUV, szTmp, 16) ; strcat(lines[5], szTmp) ; strcat(lines[5], " ") ;
        _itoa(sizeUVB, szTmp, 10) ; strcat(lines[5], szTmp) ;
        if (szTmp[0]=='-') {                                    // check for error (MLX table problem)
            strcat(szErrMess, szNo) ; strcat(szErrMess, ", ") ;
            // bSuccess= false ?
        }
    }
    fprintf(stream, "%s\n", lines[5]) ;
	fclose (stream) ;
	return true ;
}

bool show_table(DWORD dwStart)			// crappy code, I know, but: works
{					//
	char * pFBuf ;			//
	BYTE i ;
	int cnt=0, l, nValue[8] ;			//
	DWORD j ;		//

	pFBuf = (char *) lpFBuf ;           // start of file buffer
	pFBuf += dwStart ; j= 0 ; l= 0 ;
    fprintf( stream, "%s\n\n0x%lx:\n", szFileNameG, dwStart) ;
	for (l=0;l<100;l++) {				// 100 entries a 8 DWORDs
		for (cnt=0;cnt<8;cnt++) {
			for (i=0;i<4;i++) {									// 1x DWord
				nValue[i] = (*pFBuf & 255) ; pFBuf++ ; j++ ;
			}
			if (nValue[2]!=0) fprintf( stream, "    x") ;
			else fprintf( stream, "%5d", nValue[0] + nValue[1]*256) ;       // little endian
			fprintf( stream, " ") ;
		}
		fprintf( stream, "\n") ;
	}
	fprintf( stream, "0x%lx\n", dwStart+j) ;
	return true ;
}

void log_WordsBE(DWORD dwStart)			//
{					//
	char * pFBuf ;			//
	BYTE i ;
	int cnt=0, nValue[2] ;			//
	WORD w ;
	DWORD j ;		//

	pFBuf = (char *) lpFBuf ;           // start of file buffer
	pFBuf += dwStart ; j= 0 ;
    for (cnt=0;cnt<46;cnt++) {
        for (i=0;i<2;i++) {									// 1x DWord
			nValue[i] = (*pFBuf & 255) ; pFBuf++ ; j++ ;
		}
		w= nValue[0]*256 + nValue[1] ;       // big endian
		if (w!=0) fprintf( stream, "%5d ", w) ; else fprintf( stream, "0 ") ;
    }
    fprintf( stream, "\n") ;
}

bool log_MBG(void)			// crappy code, I know, but: works
{					//
	char * pFBuf ;			//
	BYTE fCnt=0 ;
	int cnt=1, FIcnt, i, l=0 ;			// , nValue[8]
	WORD FI ;
	DWORD j, dwStart= 0x395, lastFaceInd=0, minFaceInd= 0xFFFF, maxFaceInd=0 ;		//
	bool bStop= false ;

	pFBuf = (char *) lpFBuf ;           // start of file buffer
	dwStart= 0x138D ;
	pFBuf += dwStart ; j= 0 ;
    fprintf( stream, "# %s\n\n0x%lx:\n", szFileNameG, dwStart) ;
	//for (l=0;l<6731;l++) {				// a 76 bytes (12, 2x8, 3x12 +4x5)  sind aber nicht immer 76 pro l
	while ((l<15000)&&!bStop) {
        if (*pFBuf==1) {
            pFBuf += 4 ; j += 4 ;       // skip 01 000000
            switch (cnt) {
                case 1: fprintf( stream, "v ") ; break ;
                case 2: fprintf( stream, "vt ") ; break ;
                default: fprintf( stream, "# ") ;
            }
            if (cnt<6) cnt++ ; else cnt= 1 ;
            if (*pFBuf==8) {
                pFBuf++ ; j ++ ; Show_nFloats(stream, pFBuf, j, 2, true) ;
            }
            else if (*pFBuf==12) {
                pFBuf++ ; j ++ ; Show_nFloats(stream, pFBuf, j, 3, true) ;
            }
            else {          // == 4?
                pFBuf++ ; j ++ ; ShowDWord(stream, pFBuf, j) ;
            }
            if (cnt==6) fprintf( stream, "# %d 0x%lx\n", l, dwStart+j) ;
        }
        else if (*pFBuf==3) {  // idx
            pFBuf += 3 ; j += 3 ; // size des idx blocks folgt (als Word gelesen statt DWord)
            FIcnt= GetFaceIndexWord(pFBuf, j, minFaceInd, maxFaceInd, lastFaceInd, true) ; FIcnt-- ;
            fprintf( stream, "\n") ;
            for (i=0;i<FIcnt/2;i++) {       // weil, FIcnt ist die size
                FI= GetFaceIndexWord(pFBuf, j, minFaceInd, maxFaceInd, lastFaceInd, false) ; // littleE
                if (fCnt==0) fprintf( stream, "f ") ;
                fprintf( stream, "%d ", FI) ; fCnt++ ;
                if (fCnt==3) { fCnt=0 ; fprintf( stream, "\n") ; }
            }
            fprintf( stream, "\n") ; bStop= true ;
        }
        else if (*pFBuf==7) {
            ShowDWord(stream, pFBuf, j) ;
        }
        l++ ;
	}
	fprintf( stream, "# 0x%lx\n", dwStart+j) ;
	return true ;
}

void SM_of_unkn_loop(HWND hwnd, char szPathname[], DWORD dwStart)      // scanning the submeshes params in the MLX table
{
   //char * pFBuf ;
   //BYTE * pByte, cnt, i ;

   //DWORD deltaFI, deltaV, dwFaceIndCnt, dwFICntLast=0, dwVertsCnt, dwVCntLast=0, addrFI=0x124D0, addrV=0x1BC20, j ;

   chMB("WIP, not included, sry!\nMaybe released when working better/for more than one model.") ;
}

DWORD dataAlignment(DWORD j){
    int cnt ;

    cnt = j/16 ; cnt++ ;
    if ((j%16)!=0) { j = cnt*16 ; }
    return j ;
}
DWORD dataAlignment_4(DWORD j){
    int cnt ;

    cnt = j/4 ; cnt++ ;
    if ((j%4)!=0) { j = cnt*4 ; }
    return j ;
}

void GetDW(char * &pFBuf, DWORD &j, DWORD &dw, bool bBigE) {
    BYTE * pByte, i ;
    WORD wLo, wHi ;
    DWORD dwTmp ;

    pByte = (BYTE*) &dw ;    			        // get vertex count
    for (i=0;i<4;i++) {									//
        *pByte = *pFBuf &255 ; pByte++; pFBuf++; j++ ;
    }
    if (bBigE) {
        dwTmp = dw / 65536 ;        // low word
        wLo= dwTmp % 256 ; wHi= dwTmp / 256 ;           // little to big endian correction
        dwTmp= wLo * 256 + wHi ;
        dw %= 65536 ;               // hi word
        wLo= dw % 256 ; wHi= dw / 256 ;
        dw= (wLo * 256 + wHi)*65536 + dwTmp ;
    }
}
void GetWord(char * &pFBuf, DWORD &j, WORD &w, bool bBigE) {
    BYTE * pByte, i ;
    WORD wLo, wHi ;

    pByte = (BYTE*) &w ;
    for (i=0;i<2;i++) {
        *pByte = *pFBuf &255 ; pByte++; pFBuf++; j++ ;
    }
    if (bBigE) {
        wLo= w % 256 ; wHi= w / 256 ;           // little to big endian correction
        w= wLo * 256 + wHi ;
    }
}

void SM_of_CA_mesh_loop_bak(HWND hwnd, char szPathname[], DWORD dwStart)      // scanning the submeshes params for Captn America
{                                                                         // only model tested
   char * pFBuf, *pTmp, szNo[4] ;
   BYTE cnt ;
   int delta, nValue[16] ;
   WORD wFaceIndCnt, wVertsCnt, wOffs2VBlock ;         //
   DWORD addrFI=0, addrUV, addrV, j, jOld, lastJ, offs2 ;  //
   char lines[6][20]= {"","Vb1","12 99","","120300",""} ;
   bool bStop= false ;

   pFBuf = (char *) lpFBuf ; pTmp= pFBuf ;
   //dwStart = 0 ;                                        // unneeded here
   //pFBuf += dwStart ;
   SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " creating H2O files:") ;
   cnt= 0 ; lastJ= 0 ;
   do {
        pFBuf= pTmp ; j= lastJ ;                                // restore from previous run, ahja,init j=0 not required
        nValue[0]= 0; nValue[1]= 6; nValue[2]= 0; nValue[3]= 0xFF;		// assumed signature of submesh header
        nValue[4]= 0x12; nValue[5]= 0;
        offs2 = FindBytes(lpFBuf, j, dwFileSize-j, nValue, 6) ;
        if (offs2!=0) {
            pFBuf += offs2 ; j += offs2 ;
            pFBuf += 6 ; j += 6 ;                               // skip signature bytes
            GetWord(pFBuf, j, wVertsCnt, true) ;   			            // get vertex count
            GetWord(pFBuf, j, wFaceIndCnt, true) ;
            pFBuf += 8 ; j += 8 ;                               // skip FFFFFFFF and 4 bytes
            GetWord(pFBuf, j, wOffs2VBlock, true) ;
            pTmp= pFBuf ; lastJ= j ;                            // backup current file buffer pos
            delta= j - addrFI ;                                 // addrFI from previous run
            if (delta<=0) {                                     // avoid finding the same addrFI again
                pFBuf -= delta ; j -= delta ;
                pFBuf++ ; j++ ;
            }
                    //pFBuf += 14*16 + 4 ; j += 14*16 + 4;            // simply skip bytes before face indices block; nope
            nValue[0]= 0; nValue[1]= 0; nValue[2]= 0; nValue[3]= 1;	  // first face
            nValue[4]= 0; nValue[5]= 2;
            offs2 = FindBytes(lpFBuf, j, dwFileSize-j, nValue, 6) ;
            if (offs2!=0) {
                pFBuf += offs2 ; j += offs2 ;
                addrFI= j ;                                         //
                pFBuf += wFaceIndCnt * 2 ; j += wFaceIndCnt * 2 ;   // skip face indices
                jOld= j ; j = dataAlignment(j) ;                   // data alignment
                pFBuf += (j-jOld) ;                                 // don't forget to update the pointer
                // now we are at start of vertex block (are we?)
                addrV = j ;
                pFBuf += wVertsCnt * 12 ; j += wVertsCnt * 12 ;
                fprintf(stream, "SM %d, UV block: 0x%lx\n", cnt, j) ;
                jOld= j ; j = dataAlignment(j) ;                   // data alignment
                pFBuf += (j-jOld) ;                                 // don't forget to update the pointer
                // point to fst uv set
                addrUV = j + 24 ;     //
                _itoa(cnt, szNo, 10) ;
                if (create_H2O(szPathname, cnt, lines, addrFI, wFaceIndCnt, addrUV, 40, addrV, wVertsCnt, 2) )
                    SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) szNo) ;
                else SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " failed") ;
                //  code might come in handy when search for 0000 0001 0002 results in problems
/*                pFBuf += wVertsCnt * 40 ; j += wVertsCnt * 40 ;     // skip uvs (and other) block
                jOld= j ; j = dataAlignment(j) ;                   // data alignment
                pFBuf += (j-jOld) ;
                pFBuf += wVertsCnt * 8 ; j += wVertsCnt * 8 ;      // skip unknown block
                jOld= j ; j = dataAlignment(j) ;                   // data alignment
                pFBuf += (j-jOld) ;                                 // don't forget to update the pointer   */
                    //offs += 96 ;                          // skip unknown bytes
            }
        }
        else bStop= true ;
        cnt++ ;                                                 // next submesh
   } while (!bStop&&(j<dwFileSize)) ;

   if (strlen(szErrMess)>17) MessageBox(NULL, szErrMess, "error", MB_ICONINFORMATION);
}

void SM_of_CA_mesh_loop(HWND hwnd, char szPathname[], DWORD dwStart)      //
{                                                                         // MG_heroa00_0 contains counts for MG_heroa00_0_gpu
   char * pFBuf, *pTmp, szNo[5] ;
   //BYTE cnt ;
   int cnt, nValue[16] ;
   DWORD addrFI=0, addrUV= 0, addrV, j=0, lastJ, offs2, FIcnt, vCnt ;  //
   char lines[6][20]= {"","Vb1","40 32","","020300",""} ;
   bool bDoubleSig= false, bStop= false ;

   pFBuf = (char *) lpFBuf ; pTmp= pFBuf ;
   //dwStart = 0 ;                                        // unneeded here
   //pFBuf += dwStart ;
   SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " creating H2O files:") ;
   cnt= 0 ; lastJ= 0 ;
   fprintf( stream, "cnt (addr of values) addrFI FIcnt, addrV vCnt\n\n") ;
   do {
        nValue[0]= 0xFF; nValue[1]= 0xFF; nValue[2]= 0x7F; nValue[3]= 0x7F;		// assumed signature of submesh header
        nValue[4]= 0xFF; nValue[5]= 0xFF; nValue[6]= 0x7F; nValue[7]= 0x7F;
        offs2 = FindBytes(lpFBuf, j, dwFileSize-j, nValue, 4) ;
        if (offs2!=0) {
            pFBuf += offs2 ; j += offs2 ; lastJ= j ; bDoubleSig= false ;
            if ((*(pFBuf+6)!=0x7F)||(*(pFBuf+7)!=0x7F)) {pFBuf -= 4 ; j -= 4 ;}   // "compensate" missing first FFFF7F7F
            else bDoubleSig= true ;
            //if (cnt==10)
            //    j= j*2-j ;
            pFBuf += 44 ; j += 44 ;     //lastJ= j ;                        // skip signature bytes and more
            GetDW(pFBuf, j, addrFI, false) ;  pFBuf += 4 ; j += 4 ;
            GetDW(pFBuf, j, addrV, false) ;  pFBuf += 4 ; j += 4 ;
            GetDW(pFBuf, j, vCnt, false) ;
            GetDW(pFBuf, j, FIcnt, false) ;
                //if (!bDoubleSig) {
                //    fprintf( stream, "> ") ;
                //    strcpy(lines[2], "6 99") ; strcpy(lines[4], "020400") ;
                //}
                fprintf( stream, "%d. (%lx) %lx %lu, %lx %lu\n", cnt, lastJ, addrFI, FIcnt, addrV, vCnt) ;
                fflush(stream) ;        // for debug only!
            // >>> !bDoubleSig for FVF6 finds (1 sig only)
            if (bDoubleSig) {          // skip FVF 6 (or FVF40 with !)
                _itoa(cnt, szNo, 10) ;
                if (create_H2O(szPathname, cnt, lines, addrFI, FIcnt, addrUV, 255, addrV, vCnt, 2) ) // mode: 2 is mixed, uv addr=0 here
                    SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) szNo) ;
                else SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " failed") ;
            }
        }
        else bStop= true ;
        if (bDoubleSig) {
            if (cnt<998) cnt++ ; else bStop= true ;                                                // next submesh
        }
   } while (!bStop&&(j<dwFileSize)) ;

   if (strlen(szErrMess)>17) MessageBox(NULL, szErrMess, "error", MB_ICONINFORMATION);
}

void SM_of_SlyC_mdl_loop(HWND hwnd, char szPathname[], DWORD dwStart)      // scanning the submeshes params for Mesh_1807
{
   char * pFBuf, szNo[4] ;
   BYTE * pByte, cnt, i ;
   int cnt1, nValue[16] ;        //
   WORD  wFaceIndCnt, wVertsCnt ;
   DWORD addrFI, addrUV, addrV, dwSM_HeaderSize, j, offs2, oldJ ;  //
   bool bStop= false ;

    // ###  line to be changed for other models than MLX! ###
    //char lines[5][20]= {"","Vb1","76 40","021000","0x0 255"} ;                      // [5][16] sollte reichen?
    //char lines[6][20]= {"","Vb1","12 99","","120300",""} ;          // Capt'n A.
    char lines[6][20]= {"","Vb1","26 10","","120201",""} ;            // Sly Cooper TiT

    //0x124D0 1469          this is the ref H2O file for the first submesh of "DL020A_SD002J.MLX"
    //Vb1 -> lines[1]       which you'll get after having found out the format and saving the H2O in hex2obj
    //76 40 -> [2]
    //0x1BC20 701           this line's contents varies (same with first line)
    //021000 -> [4]
    //0x0 255- > [5]

   pFBuf = (char *) lpFBuf ; j= 0 ;
   if ((*pFBuf!=0x4D)&&(*(pFBuf+3)!=0x48)) {
    chMB("This doesn't seem to be a SlyCooper mesh file!") ; return ;
   }
   SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " creating H2O files:") ;
   pFBuf += dwStart ; j += dwStart ;                            // dwStart: start of first submesh at 0x30, from editbox
   addrUV = 0 ;     // zero for VB mode (hex2obj)
   cnt= 0 ;
   do {
        pFBuf += 4 ; j += 4 ;                                   // point to header size
        pByte = (BYTE*) &dwSM_HeaderSize ;						//
        for (i=0;i<4;i++) {									//
            *pByte = *pFBuf &255 ; pByte++; pFBuf++; j++ ;
        }
        if (dwSM_HeaderSize==144) {chMB("headersize= 144: not supported so far.\nbreak...") ; return ;}
        pFBuf++; j++ ;                                          // skip 04
        pByte = (BYTE*) &wVertsCnt ;						    // get vertex count
        for (i=0;i<2;i++) {									//
            *pByte = *pFBuf &255 ; pByte++; pFBuf++; j++ ;
        }
        pByte = (BYTE*) &wFaceIndCnt ;						//
        for (i=0;i<2;i++) {									//
            *pByte = *pFBuf &255 ; pByte++; pFBuf++; j++ ;
        }
        // with cnt==0, first submesh, we are at file offset 0x3D now. We have to skip 123 bytes to vertex start: 0xB8
        //pFBuf += 123 ; j += 123 ;                               // that's the headersize -1
        pFBuf += dwSM_HeaderSize - 1 ; j += (dwSM_HeaderSize -1) ;
        addrV = j ;                                             // parameter (start of vertices) for create_H2O()
        offs2 = wVertsCnt*26 ;                                  // use vertex stride to calculate size of vertex data block
        pFBuf += offs2 ; j += offs2 ; oldJ = j ;                //
        cnt1 = j/4 ; cnt1++ ;
        if ((j%4)!=0) j = cnt1*4 ;                              // 4 byte alignment
        pFBuf += (j-oldJ) ;                                     // yeah, don't forget to update the pointer
            //fprintf( stream, "debug: pos of MDIX=%lx?\n", j) ;
        pFBuf += 8 ; j += 8 ;                                   // skip 8 bytes ("MIDX" and DWORD)
        addrFI = j ;
        offs2 = wFaceIndCnt*2 ;                                 // size of face indices block with word indices
        pFBuf += offs2 ; j += offs2 ;                           //
        // we could do a simple byte alignment here, then skip another 8 bytes
        // but I would like to introduce a search feature; we search for "MHDR"
        // j is the current position in the model file
        _itoa(cnt, szNo, 10) ;
        nValue[0]= 0x4D; nValue[1]= 0x48; nValue[2]= 0x44; nValue[3]= 0x52;		// "MHDR": signature start of submesh block
        offs2 = FindBytes(lpFBuf, j, dwFileSize-j, nValue, 4) ;
        if (offs2!=0) {
            pFBuf += offs2 ; j += offs2 ;
                //fprintf( stream, "       pos of MHDR=%lx?\n", j) ;
            if (create_H2O(szPathname, cnt, lines, addrFI, wFaceIndCnt, addrUV, 255, addrV, wVertsCnt, 2))
                SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) szNo) ;
            else SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " failed") ;
        }
        else {                      // sadly we don't have control, when there's no "MHDR" in the file
            if (create_H2O(szPathname, cnt, lines, addrFI, wFaceIndCnt, addrUV, 255, addrV, wVertsCnt, 2) )
                SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) szNo) ;
            else SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " failed") ;  // plus H2O no!
            bStop= true ;
        }
        cnt++ ;                                                 // next submesh
   } while (!bStop&&(j<dwFileSize)) ;                //
   if (strlen(szErrMess)>17) MessageBox(NULL, szErrMess, "error", MB_ICONINFORMATION);
}
// *** for MLX only!***
BYTE GetFirstSubMesh_vertexStart(char * pFBuf, DWORD &addrFI, DWORD dwFIrel, BYTE KFMG_cnt) {
   char * pTmp ;
   BYTE cnt= 1, retcnt ;
   DWORD dwFIprev[256], dwFaceIndCnt, dwFICntLast=0, dwVertsCnt, dwVCntLast=0 ;
   DWORD addrFIbac, deltaFI, deltaV, j=0 ;	//
   bool bStop= false ;

    pTmp= pFBuf ; addrFIbac= addrFI ;
        //fprintf( stream, "  addr FI, FIrel vCnt\n") ;
    // first calculation while loop results in false addrFI! because of possible negative counts
    do {
        dwFIprev[cnt-1]= dwFIrel ;
        GetDW(pFBuf, j, dwFIrel, false) ;                   // only required for last FI addr
        GetDW(pFBuf, j, dwVertsCnt, false) ;
        bStop= (dwVertsCnt==0)||(dwVertsCnt>65535) ;
        deltaV= dwVertsCnt - dwVCntLast ; dwVertsCnt= deltaV ;
        GetDW(pFBuf, j, dwFaceIndCnt, false) ;              // absoulte FI count
        deltaFI= dwFaceIndCnt - dwFICntLast ; dwFaceIndCnt= deltaFI ;
        pFBuf += 5*4 ; j += 5*4 ;                           // next table SM entry for MLX tables only!
            fprintf( stream, "%d 0x%lx %lu (%lu), v%lu\n", cnt-1, addrFI, dwFIprev[cnt-1], deltaFI, deltaV) ; // deltaV evtl. negativ!
            //addrFIprev= addrFI ;
        addrFI += deltaFI*2 ;
        dwVCntLast += deltaV ; dwFICntLast += deltaFI ;
        if (cnt<254) cnt++ ; else chMB("more than 256 submeshes per KFMG can't be handled") ;
   } while (!bStop && (j<dwFileSize)) ;
   if (bStop) fprintf( stream, " breaking count in table= %lu\n\n", dwVertsCnt) ;
   else fprintf( stream, " EOF met on table scan\n\n") ;
   if (cnt!=SM_cntArr[KFMG_cnt]) {
       fprintf( stream, "\n SM_counts: %d!=%d \n", SM_cntArr[KFMG_cnt], cnt) ;
       cnt= SM_cntArr[KFMG_cnt] ;
   }
   retcnt= cnt ;

   pFBuf= pTmp +4 ;     // weil FIrel jetzt nicht gelesen
   dwFIrel=0; dwFICntLast=0; dwVCntLast=0 ;
   addrFI= addrFIbac ; j= 0 ;
   for (cnt=0;cnt<retcnt;cnt++) {             // -1 to avoid last fxxxing value/line
       GetDW(pFBuf, j, dwVertsCnt, false) ;
       deltaV= dwVertsCnt - dwVCntLast ; dwVertsCnt= deltaV ;
       GetDW(pFBuf, j, dwFaceIndCnt, false) ;              // absoulte FI count
       deltaFI= dwFaceIndCnt - dwFICntLast ;               // kann negativ sein!
       deltaFI= dwFIprev[cnt] ;                             // <- daher
       dwFaceIndCnt= deltaFI ;
       pFBuf += 6*4 ; j += 6*4 ;                           // next table SM entry for MLX tables only!
       //addrFIprev= addrFI ;
       addrFI += deltaFI*2 ; //fprintf( stream, " %d (%d->) addr FI= 0x%lx\n", cnt, deltaFI, addrFI) ;
       dwVCntLast += deltaV ; dwFICntLast += deltaFI ;
   }
   fprintf( stream, "last addr FI= 0x%lx\n", addrFI) ;
   return retcnt ;
}
BYTE GetFirstSubMesh_vertexStart_(char * pFBuf, DWORD &addrFI) {
   BYTE cnt= 1 ;
   DWORD dwFIrel=0, dwFIprev, dwFaceIndCnt, dwFICntLast=0, dwVertsCnt, dwVCntLast=0 ;
   DWORD addrFIprev, deltaFI, deltaV, j=0 ;
   bool bStop= false ;

        //fprintf( stream, "  addr FI\n") ;
    do {
        dwFIprev= dwFIrel ;
        GetDW(pFBuf, j, dwFIrel, false) ;                   // only required for last FI addr
        GetDW(pFBuf, j, dwVertsCnt, false) ;
        bStop= (dwVertsCnt==0)||(dwVertsCnt>65535) ;
        deltaV= dwVertsCnt - dwVCntLast ; dwVertsCnt= deltaV ;
        GetDW(pFBuf, j, dwFaceIndCnt, false) ;              // absoulte FI count
        deltaFI= dwFaceIndCnt - dwFICntLast ; dwFaceIndCnt= deltaFI ;
        pFBuf += 5*4 ; j += 5*4 ;                           // next table SM entry for MLX tables only!
            fprintf( stream, "%d 0x%lx %lu (%lu), v%lu\n", cnt-1, addrFI, dwFIprev, deltaFI, deltaV) ; // deltaV evtl. negativ!
        addrFIprev= addrFI ;
        addrFI += deltaFI*2 ;
        dwVCntLast += deltaV ; dwFICntLast += deltaFI ;
        cnt++ ;
   } while (!bStop && (j<dwFileSize)) ;
   addrFI = addrFIprev + dwFIprev*2 ; fprintf( stream, "last addr FI= 0x%lx, cnt %lu\n", addrFI, dwFIprev) ;
   if (bStop) fprintf( stream, " breaking count in table= %lu\n\n", dwVertsCnt) ;
   else fprintf( stream, " EOF met on table scan\n\n") ;
   return cnt ;
}
//SetWindowText (hwndEdit, "F200");
void SM_of_MLX_loop(HWND hwnd, char szPathname[])      // scanning the submeshes params in the MLX table
{
   char * pFBuf, * pTmp, * pTmp2, szNo[9] ;
   BYTE cnt=0, i, KFMG_cnt=0, SM_cnt, nTmp ;  //KFMG_cnt=0 h�h?
   int nValue[14] ;
   bool bLog= true ;
   //signed long deltaFI, deltaV ;      // bad idea
   WORD  wFIcnt, wVertsCnt ;
   DWORD dum, dwFaceIndCnt, dwFICntLast=0, dwVertsCnt, dwVCntLast=0 ;
   DWORD dwFIrel, addrFI[20], addrFIbac[KFMG_cnt], addrV[20], deltaFI, deltaV, j=0, offs=0, offs2 ;
   DWORD dwStart=0, addrTable[20+1] ;   // search addr Table start
   //char lines[6][20]= {"","Vb1","76 40","","021000","0x0 255"} ;                // 124D0            1BC20
   char lines[6][20]= {"","Vb1","64 40","","021000","0x0 255"} ;                // Weapons Axe
   char szTmpName[MAX_PATH];

   pFBuf = (char *) lpFBuf ; pTmp= pFBuf ; addrTable[0]= 0 ;
   if (bLog) chMB("Log on") ;
   if ((*pFBuf!=0x49)&&(*(pFBuf+3)!=0x41)) {                        // "IZCA" ?
    chMB("This doesn't seem to be an MLX file!") ; //return ;
   }
   do {
       nValue[0]= 0x4B; nValue[1]= 0x46; nValue[2]= 0x4D; nValue[3]= 0x53;		// "KFMS": signature for SM counts
       offs2 = FindBytes(lpFBuf, offs, dwFileSize, nValue, 4) ;
       if (offs2!=0) {
           pFBuf += offs2 + 60 ; offs += offs2 + 60 ;                           // just a wild guess
           GetDW(pFBuf, offs, dum, false) ; SM_cntArr[cnt]= dum ; //fprintf( stream, " dum: %d at %lx\n\n", dum, offs) ;
           if (cnt<19) cnt++ ; else chMB("more than 20 KFMSs can't be stored!") ;
       }
   } while ((offs2!=0)) ;
   pFBuf= pTmp ;
   //dwStart= 0xC5150 ;     // DL0108, 2nd table
   do {
       addrFIbac[KFMG_cnt]= 0 ;
       nValue[0]= 0x4B; nValue[1]= 0x46; nValue[2]= 0x4D; nValue[3]= 0x47;		// "KFMG": signature start of ? to get FIaddr
       offs2 = FindBytes(lpFBuf, dwStart, dwFileSize, nValue, 4) ;
       if (offs2!=0) {
           dwStart += offs2 + 64 ;                                              // just a wild guess
           addrFI[KFMG_cnt]= dwStart ; addrFIbac[KFMG_cnt]= dwStart ;
               if (bLog) fprintf( stream, "first addrFI[%d] at 0x%lx\n", KFMG_cnt, addrFI[KFMG_cnt]) ;
           if (KFMG_cnt<19) KFMG_cnt++ ; else chMB("more than 20 KFMGs can't be stored!") ;
       }
   } while ((offs2!=0)) ;

   if (cnt!=KFMG_cnt) chMB("error: counts KFMS!=KFMG") ;
   //dwStart= 0xC37E4 ;   // wieder zur�ck f�r table-Suche
   //pFBuf += dwStart ; j= dwStart ;    besser nicht
 //for (KFMG_cnt=0;KFMG_cnt<KFMG_max;KFMG_cnt++) {
        pFBuf = (char *) lpFBuf ;            KFMG_cnt=0 ;
        pFBuf += addrTable[KFMG_cnt] ; j= addrTable[KFMG_cnt] ;
        if (bLog) fprintf( stream, "addrTable at 0x%lx\n", addrTable[KFMG_cnt]) ;
/*
   nValue[0]= 5; nValue[1]= 6; 		        // signature 03050601 oder 04050600 040201
   do {
        offs2 = FindBytes(lpFBuf, j, dwFileSize, nValue, 2) ;
        if (offs2!=0) {
            pFBuf += offs2  ; j += offs2 ;
            if ( ((*(pFBuf-1)==3)||(*(pFBuf-1)==4) ) && ( (*(pFBuf+2)==1)||(*(pFBuf+2)==0)) ) {
                pTmp= pFBuf + 15*16 ;
                    if (bLog) fprintf( stream, "sig xx 05 06.. at 0x%lx\n", j) ;
                bStop = !((*pTmp==5)&&(*(pTmp+1)==6) ) ;
                if (bStop) bStop = !((*pTmp==2)&&(*(pTmp+1)==1) ) ;
                if (bStop) {
                    pFBuf += 15*16 ; j += 15*16 ; //fprintf( stream, "  hit\n") ;
                }
            }
            pFBuf++  ; j++ ;
        }
   } while (!bStop&&(offs2!=0)) ;                   //
   if (!bStop) {
       chMB("start of mesh infotable not found!\n break...") ; return ;
   }    */
   cnt= 0 ;     strcpy(szTmpName, szPathname) ;
      // 00000000 00000000 01000100 0100 3F3F3F3F 0000000000000000000000000000, 14x 0
   do {
       i= 0 ;
       nValue[0]= 0; nValue[1]= 0; nValue[2]= 0; nValue[3]= 0;		// signature of magic table
       nValue[4]= 0; nValue[5]= 0; nValue[6]= 0; nValue[7]= 0;
       nValue[8]= 1; nValue[9]= 0; nValue[10]= 1; nValue[11]= 0; nValue[12]= 1; nValue[13]= 0;
       offs2 = FindBytes(lpFBuf, j, dwFileSize, nValue, 14) ;
       if (offs2!=0) {
           pFBuf += offs2 + 18 ; j += offs2 + 18 ;                           //
           while ((*pFBuf==0)&&(i<14)) {
                pFBuf++ ; i++ ; j++ ;
           }
           if (i>13) {
               addrTable[cnt+1]= j  ;
               pFBuf -= 18 ; j -= 18 ;
               GetWord(pFBuf, j, wVertsCnt, false) ; GetWord(pFBuf, j, wFIcnt, false) ;
               addrV[cnt]= addrFI[cnt] + wFIcnt*2 ;
               addrV[cnt]= dataAlignment(addrV[cnt]) ; pTmp2 = pFBuf ; pFBuf = pTmp ;
               pFBuf += addrV[cnt] -3 ;
               if ((*pFBuf>3)||(*(pFBuf+2)>3)) SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " vStart might be wrong!") ;
               pFBuf = pTmp2 ;
               if (!create_H2O(szTmpName, cnt, lines, addrFI[cnt], wFIcnt, 0, 255, addrV[cnt], wVertsCnt, 1) )    // 0, 255 not used in mode 1
                   SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " failed") ;
               if (cnt<19) cnt++ ;
           }
       }
   } while ((offs2!=0)) ;
   pFBuf= pTmp ; fflush(stream) ;
return ;
   addrTable[KFMG_cnt+1]= j ; if (bLog) fprintf( stream, "addrTable[%d] at 0x%lx\n", KFMG_cnt+1, j-6) ;
   SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " table:") ;
   _itoa(j-6, szNo,16) ;                                    // start of mesh info table
   //SetWindowText (GetDlgItem(hwnd, ID_EDIT), szNo);
   SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) szNo) ;         // table
   SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " creating H2O files:") ;
   //pFBuf = (char *) lpFBuf ; j= 0 ;
   pFBuf += 2 ; j += 2 ;                            // skip from 10A16
   GetDW(pFBuf, j, dwFIrel, false) ;
   pFBuf += 7*4 ; j += 7*4 ;                        // point to first submeshes rel. FI count
       if (bLog) fprintf( stream, "rel. FIcnt fst SM at 0x%lx\n", j) ;
   pTmp = pFBuf + 4 ;                          // pTmp + 4: skip FI count
   SM_cnt = GetFirstSubMesh_vertexStart(pFBuf, addrFI[KFMG_cnt], dwFIrel, KFMG_cnt) ;     // dwFIrel: see GetDW() above
   addrFI[KFMG_cnt] = dataAlignment(addrFI[KFMG_cnt]) ;                         // data alignment, 16 bytes, or 8 only?
   addrV[KFMG_cnt] = addrFI[KFMG_cnt] ;                                         // last FI addr -> start of vertices, fst submesh
        //addrV= 0x17110 ;    // DL0124 manually
            //addrV[0]= 0x16E80 ;    // DL0108 manually statt 2E8C0
            //addrV[1]= 0xC9F80 ;    // DL0108, 2nd manually, 0xE55F0 statt 0xE55E0? beide Mist
   addrFI[KFMG_cnt]= addrFIbac[KFMG_cnt] ;
   pFBuf = pTmp ;                                           // restore for 2nd pass
   dwFICntLast= 0; dwVCntLast= 0 ;
   strcpy(szTmpName, szPathname) ;
   if (KFMG_cnt>0) {
       nTmp= KFMG_cnt ; nTmp += 0x40 ;  // "1" -> "A" wg. Sortierung der H2O files; andernfalls kommt nach _1 nicht _2, sondern _1_0
       strcat(szTmpName, "_") ; szNo[0]= nTmp ; szNo[1]= 0;//_itoa(nTmp, szNo, 16) ;
       strcat(szTmpName, szNo) ;
   }
   for (cnt=0;cnt<SM_cnt;cnt++) {                         // 29: count of submeshes
        GetDW(pFBuf, j, dwVertsCnt, false) ; if (dwVertsCnt>65535) dwVertsCnt= 99999 ;
        deltaV= dwVertsCnt - dwVCntLast ; dwVertsCnt= deltaV ;
        GetDW(pFBuf, j, dwFaceIndCnt, false) ; if (dwFaceIndCnt>65535) dwFaceIndCnt= 99999 ;
        deltaFI= dwFaceIndCnt - dwFICntLast ; dwFaceIndCnt= deltaFI ;
        pFBuf += 6*4 ; j += 6*4 ;                           // next table SM entry for MLX tables only!
        _itoa(cnt, szNo, 10) ;
        SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) szNo) ;
            //if (bLog) fprintf( stream, "%d addrFI: 0x%lx, addrV: 0x%lx\n", cnt, addrFI, addrV) ;
            if (bLog) fprintf( stream, "%d_%d addrFI: 0x%lx, addrV: 0x%lx\n", KFMG_cnt, cnt, addrFI[KFMG_cnt], addrV[KFMG_cnt]) ;
        if (addrFI[KFMG_cnt]>dwFileSize) addrFI[KFMG_cnt]= 0 ; if (addrV[KFMG_cnt]>dwFileSize) addrV[KFMG_cnt]= 0 ;
        if (!create_H2O(szTmpName, cnt, lines, addrFI[KFMG_cnt], dwFaceIndCnt, 0, 255, addrV[KFMG_cnt], dwVertsCnt, 1) )    // 0, 255 not used in mode 1
            SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " failed") ;
        addrFI[KFMG_cnt] += deltaFI*2 ; addrV[KFMG_cnt] += deltaV*76 ;         // for <WORD> face indices and vStride of 76
        dwVCntLast += deltaV ; dwFICntLast += deltaFI ;
   }

   //}   // end for KFMG_cnt
   if (strlen(szErrMess)>17) MessageBox(NULL, szErrMess, "error", MB_ICONINFORMATION);
}

void SM_of_winning_11_2010_loop(HWND hwnd, char szPathname[], DWORD dwStart)      // logging plants vs zombies 2 obb - filenames
{                                                                         //
   char * pFBuf, * szNPtr, szName[256] ;    // , szNo[4]            1C00 0240: ATLASIMAGE_ATLAS_WORLDMAP_BEACH_768_00
   BYTE * pByte, cnt, vCnt ;
   int nValue[16] ;
   DWORD j=0, offs2 ;  //
   bool bStop= false ;

   pFBuf = (char *) lpFBuf ; //pTmp= pFBuf ;
   //dwStart = 0 ;                                        // unneeded here
   pFBuf += dwStart ;
   //if ((*pFBuf!=0x1E)) {                             // comment out for "Gambryo File Format" -> tristripped?
   //     chMB("This doesn't seem to be a winning 11 stadium file!") ; //return ;
   //}
   SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " logging filenames:") ;
   cnt= 0 ;
   do {
        nValue[0]= 0x90; if ((*pFBuf &255)==0x90) {pFBuf-- ; j-- ; }
        offs2 = FindBytes(lpFBuf, j, dwFileSize-j, nValue, 1) ;
        if (offs2!=0) {
            pFBuf += offs2 + 1 ; j += offs2 + 1 ;
            pByte = (BYTE*) &vCnt ;          			        // get strlen
            *pByte = *pFBuf &255 ; pFBuf++ ; j++ ;
            szNPtr = ShowFName(stream, pFBuf, j, vCnt, dwStart) ; strcpy(szName, szNPtr) ;   // dwStart um strlen erh�ht zur�ck
            fprintf( stream, "%s\n", szName) ;
        }
        else bStop= true ;
        cnt++ ;                                                 // next filename
   } while (!bStop&&(j<dwFileSize)) ;
   fprintf(stream, "\n files: %d (last %lx)\n", cnt, j) ;
   //if (strlen(szErrMess)>17) MessageBox(NULL, szErrMess, "error", MB_ICONINFORMATION);
}

void SM_of_Fahrenheit_loop(HWND hwnd, char szPathname[], DWORD dwStart)      // trying to create point clouds
{                                                                         //
   char * pFBuf, szNo[4], * pTmp ;
   BYTE cnt, cntMax ;
   int nValue[16] ;
   DWORD FIcnt, dwFaceIndCnt[100], vCnt, dwVertsCnt[100] ;         // des sind face counts, keine FI counts
   DWORD addrFI, addrUV, addrV, j=0, offs2 ;  //
   DWORD addr[100] ;        // 34 finds in vulture.dat
   char lines[6][20]= {"","Vb1","16 99","","021000",""} ; // little Endian; immer 32?
   bool bStop= false ;

   pFBuf = (char *) lpFBuf ; pTmp= pFBuf ;
   //dwStart = 0 ;                                        // unneeded here
   //pFBuf += dwStart ;
   if ((*pFBuf&255)!=0x44) {                             // comment out for "Gambryo File Format" -> tristripped?
        chMB("This doesn't seem to be a 'Fahrenheit' file!") ; return ;
   }
   SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " creating H2O files:") ;
   cnt= 0 ;
   do {    //
        nValue[0]= 0x70; nValue[1]= 1; nValue[2]= 0x95; nValue[3]= 0;    // assumed signature of magic table
        offs2 = FindBytes(lpFBuf, j, dwFileSize-j, nValue, 4) ;
        if (offs2!=0) {
            pFBuf += offs2 ; j += offs2 ;
            addr[cnt]= j +32 ;  // vertex count und face index count
            fprintf(stream, "70019500...: %lx\n", j) ;
            //pByte = (BYTE*) &vCnt ;          			        // get vertex count
            //*pByte = *(pFBuf-1) &255 ;
            //wVertsCnt= (WORD) vCnt ;
            pFBuf += 4 ; j += 4 ;                               // skip signature bytes
        }
        else bStop= true ;
        cnt++ ;                                                 // next submesh
   } while (!bStop&&(j<dwFileSize)) ;
   fprintf(stream, "\n assumed magic tables: %d\n", cnt-1) ;    // stimmt -1 ?

   cntMax= cnt-1 ; addrUV= 0 ; cnt= 0 ;
   //do {
        do {
            pFBuf= pTmp ; pFBuf += addr[cnt] ; j = addr[cnt] ;  // vor auf DW vCnt
            GetDW(pFBuf, j, vCnt, false) ;  dwVertsCnt[cnt]= vCnt ;
            addrV= addr[cnt] + 17*16;           // insgesamt 0x130 bytes header
            GetDW(pFBuf, j, FIcnt, false) ; dwFaceIndCnt[cnt]= FIcnt ;
            addrFI = addrV + 40* vCnt ;
            pFBuf= pTmp ; pFBuf += addrFI ;
            while (*pFBuf==0x2D) { pFBuf++ ; addrFI++;}     // risky!!
            if ((*pFBuf!=0)||(*(pFBuf+2)!=1)) {
                pFBuf += 8* vCnt ; addrFI += 8* vCnt ;
                if ((*pFBuf!=0)||(*(pFBuf+2)!=1)) {pFBuf += 16 ; addrFI += 16 ;}
                if ((*pFBuf!=0)||(*(pFBuf+2)!=1)) {pFBuf += 16 ; addrFI += 16 ;}
            }
            fprintf(stream, "FI: %lu, v: %lu\n", FIcnt, dwVertsCnt[cnt]) ;

            fprintf(stream, "g SM_%d\n#  at 0x%lx (FIs at 0x%lx)\n", cnt, addrV, addrFI) ;
            _itoa(cnt, szNo, 10) ;
            if (create_H2O(szPathname, cnt, lines, addrFI, dwFaceIndCnt[cnt], addrUV, 255, addrV, dwVertsCnt[cnt], 2) )
                SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) szNo) ;
            else SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " failed") ;
            cnt++ ;
        } while (cnt<cntMax) ;
            //cnt= cntMax ;               // force break
   //} while (startCnt<cntMax) ;
        //fprintf(stream, "\n vertex blocks: %d, vMax: %d\n", cnt, vMax) ;
   if (strlen(szErrMess)>17) MessageBox(NULL, szErrMess, "error", MB_ICONINFORMATION);
}

void SM_of_Wipeout_loop(HWND hwnd, char szPathname[], DWORD dwStart)      //
{                                                                         //
   const BYTE d=1 ;                 // 0: agsys_2028  1: sol_track
   const WORD SMCNT=3500;
   char * pFBuf, szNo[4], *pTmp, *pTmp2 ;
   BYTE FVFtype[SMCNT], lastFVF ;    //
   int cnt, cnt1, cntMax, objCnt, objCntMax, nValue[16] ;
   WORD FIcnt, wFaceIndCnt[SMCNT], vCnt, wVertsCnt[SMCNT] ;         //
   DWORD addrFI, addrFI_[SMCNT], addrUV, addrV, j=0, offs2 ;  //
   DWORD addr[SMCNT], objAddr[SMCNT] ;                          // addr[]: vertex startaddr
   char lines[6][20]= {"","Vb1","28 99","","020100",""} ; //
   bool bStop ;
   //FILE *stream1 ;

   pFBuf = (char *) lpFBuf ; pTmp= pFBuf ;
   //dwStart = 0 ;                                        // unneeded here
   //pFBuf += dwStart ;
   //SetCurrentDirectory(szAppDir) ;

   if ((*(pFBuf+2)!=0x5C)) {                             //
        chMB("This doesn't seem to be a 'Wipeout' model file!") ; return ;
   }
   if (d==0) SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " agsys_2048 version") ;
   else SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " sol_track version") ;
   SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " creating H2O files:") ;
   objCnt= 0 ; bStop= false ; cnt=0 ;
   SetCurrentDirectory(szWorkDir) ;

   do {    //                                                         00000000 FFFFFFFF 00000000
        nValue[0]= 0; nValue[1]= 0; nValue[2]= 0; nValue[3]= 0;    // assumed signature of an object
        nValue[4]= 0xFF; nValue[5]= 0xFF; nValue[6]= 0xFF; nValue[7]= 0xFF;
        nValue[8]= 0; nValue[9]= 0; nValue[10]= 0; nValue[11]= 0;
        offs2 = FindBytes(lpFBuf, j, dwFileSize-j, nValue, 12) ;
            //if ((offs2!=0)&&(*(pFBuf+offs2-2)==0)&&(*(pFBuf+offs2-3)==0)&&(*(pFBuf+offs2-4)==0)) {
        if (offs2!=0) {
            pFBuf += offs2+12+8 ; j += offs2+12+8 ; //
            GetWord(pFBuf, j, FIcnt, false) ; wFaceIndCnt[cnt]= FIcnt ;
            pFBuf += 2 ; j += 2 ;   //
            GetWord(pFBuf, j, vCnt, false) ; wVertsCnt[cnt]= vCnt ;
            objAddr[objCnt]= j-4 ; //fprintf(stream, "%d. %lx %2x%2x %2x%2x %2x%2x\n", objCnt, j-4, *(pFBuf)&255, *(pFBuf+1)&255, *(pFBuf+8)&255, *(pFBuf+9), *(pFBuf+12)&255, *(pFBuf+13)) ;
            fprintf(stream, "%d. %lx %d %d\n", objCnt, j-4, FIcnt, vCnt) ;
            cnt++ ;
                //logFloats(objAddr[objCnt]-0x5C, 4, true) ; logFloats(objAddr[objCnt]-0x4C, 4, true) ;
        }       // check for position offsets, oder wie?
        else bStop= true ;
        if (objCnt<SMCNT) objCnt++ ;                       // next object
   } while (!bStop&&(j<dwFileSize)) ;
   objCntMax= objCnt-1 ; objCnt=0 ;
        cntMax= objCntMax ;          // comment out! ########################
   pFBuf= pTmp ; j= 0 ;
   cnt= 0 ; bStop= false ;
   fflush(stream) ;                 // for debug on crash - wichtig bei crash f�r Nachvollzug
    //return ;
   fprintf(stream, "\n%d submeshes\n FIs at, v at (vCnt)\n", cntMax) ;
   do {
        nValue[0]= 0; nValue[1]= 0; nValue[2]= 1; nValue[3]= 0;    // first 3 face indices
        nValue[4]= 2; nValue[5]= 0; //nValue[6]= 0xFF; nValue[7]= 0xFF;
        offs2 = FindBytes(lpFBuf, j, dwFileSize-j, nValue, 6) ;
        if (offs2!=0) {
            addrFI_[cnt] = j + offs2 ;
            pFBuf += offs2+18 ; j += offs2+18 ;         // skip 3 faces (minimum submesh?)
            //fprintf(stream, "%d 0x%x, 0x%x\n", cnt, addrFI) ;
        }
        cnt++ ;
   } while (cnt<cntMax) ;
   pTmp2= pTmp ; j= 0 ; addrFI_[cntMax]= dwFileSize ;   // fail safe
   cnt= 0 ; bStop= false ;  //fflush(stream) ; return ;
   do {
            pFBuf= pTmp2 ;
            addrV= addrFI_[cnt] + wFaceIndCnt[cnt+d] * 2 ;
            pFBuf += addrV ; j = addrV ;         //

            if (*pFBuf==0) addrV += 2 ;

            addrFI= addrFI_[cnt] ;
                //wFaceIndCnt[cnt]= (addrV-addrFI)/2 ;
                //if (bMerk) wFaceIndCnt[cnt]-- ;
            addr[cnt]= addrV ; addrFI_[cnt]= addrFI ;
            vCnt= wVertsCnt[cnt+d] ;
            //fprintf(stream, "%d 0x%x (%d) %d\n", cnt, addrFI, vCnt, lastFIcnt) ;
            FVFtype[cnt]= (BYTE) ((addrFI_[cnt+1]-addrV)/vCnt) ;
            if (FVFtype[cnt]==17) FVFtype[cnt]= 18 ;
            fprintf(stream, "%d 0x%lx 0x%lx %d %d [%d]\n", cnt, addrFI, addrV, wFaceIndCnt[cnt+d], vCnt, FVFtype[cnt]) ;
        if (d==0)
            switch (FVFtype[cnt]) {
                case 28: strcpy(lines[2], "28 24") ; lastFVF= 28 ; break ;
                case 24: strcpy(lines[2], "24 16") ; lastFVF= 24 ; break ;
                case 20: strcpy(lines[2], "20 16") ; lastFVF= 20 ; break ;
                case 18: strcpy(lines[2], "18 99") ; lastFVF= 18 ; break ;
                case 10: strcpy(lines[2], "10 99") ; lastFVF= 10 ; break ;
                case 40: strcpy(lines[2], "40 16") ; lastFVF= 40 ; break ;
                case 0: break ;                         // use values of previous submesh
                default: fprintf(stream, "> CHECK H2O%d: unknown FVFtype %d\n", cnt, FVFtype[cnt]) ;
            }
        else
            switch (FVFtype[cnt]) {
                case 28: strcpy(lines[2], "28 20") ; lastFVF= 28 ; break ;
                case 24: strcpy(lines[2], "24 16") ; lastFVF= 24 ; break ;
                case 20: strcpy(lines[2], "20 16") ; lastFVF= 20 ; break ;
                case 18: strcpy(lines[2], "18 99") ; lastFVF= 18 ; break ;
                case 10: strcpy(lines[2], "10 99") ; lastFVF= 10 ; break ;
                case 40: strcpy(lines[2], "40 16") ; lastFVF= 40 ; break ;
                case 0: break ;                         // use values of previous submesh
                default: fprintf(stream, "> CHECK H2O%d: unknown FVFtype %d\n", cnt, FVFtype[cnt]) ;
            }

            _itoa(cnt, szNo, 10) ; //fprintf(stream, "%x %x\n", objAddr[objCnt], addr[cnt]);
            //if (addr[cnt]>objAddr[objCnt]) { if (objCnt<objCntMax) objCnt++ ; SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) "------") ;}

            //if (wVertsCnt[cnt+d]>250) cnt1= 3000+cnt;
            //else
                cnt1= cnt ;
            if (create_H2O(szPathname, cnt1, lines, addrFI_[cnt], wFaceIndCnt[cnt+d], addrUV, 255, addr[cnt], wVertsCnt[cnt+d], 2) )
                SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) szNo) ;
            else SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " failed") ;

        cnt++ ; fflush(stream) ;
   } while (cnt<cntMax) ;
   fprintf(stream, "\n%d submeshes\n", cntMax) ;
        //fprintf(stream, "\n vertex blocks: %d, vMax: %d\n", cnt, vMax) ;
    if (strlen(szErrMess)>17) MessageBox(NULL, szErrMess, "error", MB_ICONINFORMATION);
}

bool check4addFIGroup(char * &pFBuf, DWORD &j, DWORD &FIcnt, DWORD border)
{
    //int nValue[8] ;
    DWORD dumCnt, flag ;

    GetDW(pFBuf, j, flag, false) ;
    if (flag!=1) return false ;
    GetDW(pFBuf, j, flag, false) ;
    if (flag!=1) return false ;
    else {
            //fprintf(stream, "JuppH\n") ;
        pFBuf += 8 ; j += 8 ; // nextFIgroup = j;
        GetDW(pFBuf, j, dumCnt, false) ;
        pFBuf += 4 ; j += 4 ;                   // skip 00000000 zwischen evtl. counts
        GetDW(pFBuf, j, flag, false) ;
        if (flag==dumCnt) return false ;        // 2 counter f�r irgendwas, aber keine FIs hier
        pFBuf -= 8 ; j -= 8 ;           // wieda zur�ck, wenn's kein dumCnt war
        GetDW(pFBuf, j, dumCnt, false) ;      // vCnt als dummyCnt
            //fprintf(stream, "dumCnt: %d at %lx\n", dumCnt, j-4) ; return false ;
        if (dumCnt>1024) return false ;
        pFBuf += dumCnt*2 ; j += dumCnt*2 ;
        GetDW(pFBuf, j, FIcnt, false) ;
        GetDW(pFBuf, j, dumCnt, false) ;
        if (FIcnt!=dumCnt) return false ;        // FICnt
        // zu kompliziert
/*        pFBuf -= 4 ; j -= 4 ;           // wieda zur�ck, wenn's kein dumCnt war
        nValue[0]= 1; nValue[1]= 0; nValue[2]= 0; nValue[3]= 0;    // assumed signature of FIs end
        nValue[4]= 1; nValue[5]= 0; nValue[6]= 0; nValue[7]= 0;
        offs2 = FindBytes(lpFBuf, j, dwFileSize-j, nValue, 8) ;
        if (offs2==0) {chMB("error: no 01000000 after addFIgroup"); return false ;}
        FIcnt= offs2/2 ;
        if (j+FIcnt*2>border) return false ;    // wohl doch keine FIs hier     */
            //fprintf(stream, "%d FIs at %lx\n", FIcnt, j) ;
    }
    return true ;
}

void SM_of_B2S_loop(HWND hwnd, char szPathname[], DWORD dwStart)      //
{                                                                         //
   //const BYTE SMCNT= 255 ;
   char * pFBuf ;         // szNo[4],
   int cnt=0, nValue[16] ;
   DWORD j=0, offs2 ;  //
   //bool bStop= false ;

   pFBuf = (char *) lpFBuf ;

   SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " Ready. View MakeH2O_log.txt") ;
   SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " ") ;
   SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " ( )") ;
   SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " Copy indexOffs and dataTableOffs") ;
   SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " array values to B2S py script") ;

    // Beyound 2 Souls
   nValue[0]= 0xE; nValue[1]= 0; nValue[2]= 0; nValue[3]= 0x14;    //0E 00 00 14 06 01 04 04, 75x, +20 ==0?
   nValue[4]= 6; nValue[5]= 1; nValue[6]= 4; nValue[7]= 4;
   do {
        offs2 = FindBytes(lpFBuf, j, dwFileSize-j, nValue, 8) ;
        if (offs2!=0)
            if ( *(pFBuf+offs2+20+j)!=0) {
                //merde= *(pFBuf+offs2+20+j) ;
                cnt++; fprintf( stream, "0x%lx, ", offs2+j+16+3) ;
                if (cnt%10==0) fprintf( stream, "\n") ;
            }
        j += offs2 + 8 ;
   } while (offs2!=0) ;

   // additional finds
   fprintf( stream, "\n%d finds\n000000 0C 06 01\n", cnt) ;
   j= 0 ; offs2= 0 ; cnt= 0 ;
   nValue[0]= 0; nValue[1]= 0; nValue[2]= 0; nValue[3]= 0xC;    //  00 00 00 0C 06 01 02 04, 75x, +20 == 6?
   nValue[4]= 6; nValue[5]= 1; nValue[6]= 2; nValue[7]= 4;
   do {
        offs2 = FindBytes(lpFBuf, j, dwFileSize-j, nValue, 8) ;
        if (offs2!=0)
            if ( ( *(pFBuf+offs2+20+j)!=6)&&( *(pFBuf+offs2+31+j)!=0)) {
                cnt++; fprintf( stream, "0x%lx, ", offs2+j+16+3) ;
            }
        j += offs2 + 8 ;
   } while (offs2!=0) ;

   fprintf( stream, "\n%d finds\ndataTableOffs\n", cnt) ;
   j= 0 ; offs2= 0 ; cnt= 0 ;
   nValue[0]= 0; nValue[1]= 0xFF; nValue[2]= 0xFF; nValue[3]= 0xFF;    // (85 3F) 00 FF FF FF
   do {
        offs2 = FindBytes(lpFBuf, j, dwFileSize-j, nValue, 4) ;
        if (offs2!=0)
            //if ( (*(pFBuf+offs2-2+j)&255)==0x85) {
            if ( ( (*(pFBuf+offs2+10+j)&255)==0xFF)&&( (*(pFBuf+offs2+4+j)&255)!=0xFF)) {
                cnt++; fprintf( stream, "0x%lx, ", offs2-2+j +6) ;  // 68x, offs2-2+j +6
                if (cnt%10==0) fprintf( stream, "\n") ;
                //log_WordsBE(offs2+j+16) ;        // Start hinter indSize
            }
        j += offs2 + 4 ;
   } while (offs2!=0) ;
   fprintf( stream, "\n%d finds\n", cnt) ;
   //return ;
}

BOOL CheckValue(HWND hwnd)          // returns dwStart (value from editbox)
{
   BOOL bSuccess = FALSE;
   BOOL bErr = false ;      //
   char szText[2][8] ;      //
   char *stopStr ;          //
   signed long slTmp ;
   DWORD dwTextLength;

    GetDlgItemText(hwnd, ID_EDIT, (LPTSTR) szText[0], 8 ) ;
    dwTextLength = strlen(szText[0]) ;
    bErr = (dwTextLength==0) ;
    if (bErr)  {
        chMB("Lower left editbox must contain a value!\n(ignore this message for first run of KinectSW)") ; return false ;
    }

    slTmp= strtol(szText[0], &stopStr, 16) ;
    if (slTmp>=0) bSuccess = TRUE;
    else {
        chMB("error!\n enter a positive address") ;
        return false ;
    }
    dwStart = (DWORD) slTmp ;
    if (dwStart<=dwFileSize) bSuccess = TRUE;
    else {
        chMB("error!\n address greater than filesize") ;
        return false ;
    }
   return bSuccess;
}

BOOL DoFileOpenSave(HWND hwnd, BOOL bSave)
{
static char szFilter[] =  "model (*.*)\0*.*\0"
                          "All Files (*.*)\0*.*\0\0" ;

   OPENFILENAME ofn;
   char szFileName[MAX_PATH];

   ZeroMemory(&ofn, sizeof(ofn));
   szFileName[0] = 0;

   ofn.lStructSize = sizeof(ofn);
   ofn.hwndOwner = hwnd;
   ofn.lpstrFile = szFileName;
   ofn.nMaxFile = MAX_PATH;

   ofn.lpstrFilter       = szFilter;
   ofn.lpstrCustomFilter = NULL ;
   ofn.nMaxCustFilter    = 0 ;
   ofn.nFilterIndex      = 1L ;
   ofn.lpstrFile[0] = 0;
   ofn.lpstrTitle = TEXT("*.* open") ;
   ofn.Flags = OFN_EXPLORER | OFN_FILEMUSTEXIST;
   GetOpenFileName(&ofn);
   if (strlen((char *) ofn.lpstrFile)!= 0) {
        GetCurrentDirectory(256, (LPTSTR) szWorkDir);
        dwFileSize = _ReadFile(szFileName, lpFBuf, FALSE, stream) ;      // load the model to static buffer
        if (dwFileSize==0) {
            chMB("error: model file size==0!") ; return FALSE ;
        }
        strcpy(szFileNameG, szFileName) ;
        strcpy (szErrMess, "error in H20 no: ") ;
        SendDlgItemMessage(hwnd, ID_LIST, LB_RESETCONTENT, 0, 0L);
        switch (model) {        // set model in line 28 or make it available via a combo box
            case 1: break ;
            case 2: SetWindowText (GetDlgItem(hwnd, ID_EDIT), "0"); break ;
            case 3: SetWindowText (GetDlgItem(hwnd, ID_EDIT), "30"); break ;
            case 4: SetWindowText (GetDlgItem(hwnd, ID_EDIT), "B5B"); break ;   // 0xB5B: 24 string blocks; 0x217F, unregelm��ige blocks
            case 5: case 6:                                                     // Atlantica, Winning
            case 7: case 8:                                                     // org winning: 0; pvz2: erster FName string at 1C08D75C
            case 9: SetWindowText (GetDlgItem(hwnd, ID_EDIT), "0"); break ;
            case 10: break ;
        }
        //if (CheckValue(hwnd)) {       // check the edit box contents (not required for model 2 so far)
        switch (model) {        // set model in line 28 or make it available via a combo box
            case 1: SM_of_MLX_loop(hwnd, szFileName) ;
                    EnableWindow(GetDlgItem(hwnd, ID_BUTTON1), TRUE) ;
                    //SetWindowText (GetDlgItem(hwnd, ID_EDIT), "F200");  // 0x10A10: table start in "DL020A_SD002J.MLX"
                    break ;// dwStart from Editbox
            case 2: SM_of_CA_mesh_loop(hwnd, szFileName, dwStart) ; break ;
            case 3: SM_of_SlyC_mdl_loop(hwnd, szFileName, dwStart) ; break ;
            case 4: SM_of_unkn_loop(hwnd, szFileName, dwStart) ; break ;
                //case 4: if (CheckValue(hwnd)) SM_of_Ride_loop(hwnd, szFileName, dwStart) ; break ;
            case 5: SM_of_unkn_loop(hwnd, szFileName, dwStart) ; break ;
                //case 5: SM_of_Atlantica_onl_loop(hwnd, szFileName, dwStart) ; break ;
            case 6: SM_of_winning_11_2010_loop(hwnd, szFileName, dwStart) ; break ;
            case 7: SM_of_unkn_loop(hwnd, szFileName, dwStart) ; break ;
                //case 7: SM_of_Eagle_vulture_loop(hwnd, szFileName, dwStart) ; break ;
            case 8: SM_of_Wipeout_loop(hwnd, szFileName, dwStart) ; break ;
                //case 8: if (CheckValue(hwnd)) SM_of_B2S_loop(hwnd, szFileName, dwStart) ; break ;  //
            case 9: SM_of_Fahrenheit_loop(hwnd, szFileName, dwStart) ; break ; //

        }
        //}
    }
    return (TRUE) ;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam)
{
   static HWND  hwndButt1, hwndEdit ;          //
   static HWND  hwndCombo1, hwndList ;	// from environ.c
   static RECT  rect ;
   static int   cxChar, cyChar ;
   HDC          hdc ;
   PAINTSTRUCT  ps ;

   switch(Message)
   {
      case WM_CREATE:
           cxChar = LOWORD (GetDialogBaseUnits ()) ;
           cyChar = HIWORD (GetDialogBaseUnits ()) ;
           stream = fopen( FILENAME, "w" );
            if( stream == NULL ) {
                chMB("<MakeH2O_log.txt> creation error!") ;
                DestroyWindow(hwnd);    // we really shouldn't "meet" the fclose()
                break ;                 // from WM_CLOSE
            }
         CreateWindow("EDIT", "",
            WS_CHILD | WS_VISIBLE | WS_HSCROLL | WS_VSCROLL | ES_MULTILINE |
               ES_WANTRETURN,
            CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
            hwnd, (HMENU)IDC_MAIN_TEXT, g_hInst, NULL);

         SendDlgItemMessage(hwnd, IDC_MAIN_TEXT, WM_SETFONT,
            (WPARAM)GetStockObject(DEFAULT_GUI_FONT), MAKELPARAM(TRUE, 0)); // GDI32.lib
            hwndList = CreateWindow (TEXT ("listbox"), NULL,
                              WS_CHILD | WS_VISIBLE | LBS_NOTIFY | WS_VSCROLL | WS_BORDER,
                              cxChar, cyChar ,
                              cxChar * 34 + GetSystemMetrics (SM_CXVSCROLL),
                              cyChar * 8,
                              hwnd, (HMENU) ID_LIST,
                              (HINSTANCE) GetWindowLong (hwnd, GWL_HINSTANCE),
                              NULL) ;
			SendDlgItemMessage(hwnd, ID_LIST, LB_RESETCONTENT, 0, 0L); //
   		    SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM) ">>> create H2O files <<<") ;
			SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM) " editbox: hex start addr of SM header") ;
			SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM) " for slyCooper or vertexstart for KinectSW") ;
			SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM) " ") ;
			SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM) " (log file MakeH2O_log.txt in project dir)") ;
			SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM) "-------------------------------------------------------") ;
			if (model==1)
                SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM) "to do: fix 'error in H2O'") ;

            hwndEdit = CreateWindow (TEXT ("edit"), NULL,
                            WS_CHILD | WS_VISIBLE | WS_BORDER,
                            cxChar+10, cyChar + 134+16 ,
                            10 * cxChar, cyChar,
                            hwnd, (HMENU) ID_EDIT,
                            (HINSTANCE) GetWindowLong (hwnd, GWL_HINSTANCE),
                        NULL) ;

			hwndButt1 = CreateWindow ( TEXT("button"),
                            TEXT ("log table"),         //
                            WS_CHILD | WS_VISIBLE | WS_DISABLED | BS_PUSHBUTTON,
                            cxChar+114, cyChar + 144,        // normal font: 130
                            10 * cxChar, 3 * cyChar / 2,
                            hwnd, (HMENU) ID_BUTTON1,
                        ((LPCREATESTRUCT) lParam)->hInstance, NULL) ;
            hwndCombo1 = CreateWindow (TEXT ("combobox"), NULL,          // model Auswahl combo
                              WS_CHILD | WS_VISIBLE | WS_BORDER | CBS_DROPDOWN,
                              cxChar+220, cyChar + 131+16,       // 170
                              9 * cxChar, 8*cyChar, //
                              hwnd, (HMENU) ID_COMBO1,
                              (HINSTANCE) GetWindowLong (hwnd, GWL_HINSTANCE),
                           NULL) ;
            SendMessage(hwndCombo1, CB_ADDSTRING, 0, (LPARAM) "MLX") ;
            SendMessage(hwndCombo1, CB_ADDSTRING, 0, (LPARAM) "CaptnA") ;
            SendMessage(hwndCombo1, CB_ADDSTRING, 0, (LPARAM) "SlyCoop") ;
            SendMessage(hwndCombo1, CB_ADDSTRING, 0, (LPARAM) "-Ride") ;
            SendMessage(hwndCombo1, CB_ADDSTRING, 0, (LPARAM) "-AtlOnl") ;
            SendMessage(hwndCombo1, CB_ADDSTRING, 0, (LPARAM) "winn11") ;
            SendMessage(hwndCombo1, CB_ADDSTRING, 0, (LPARAM) "-EagleDeb") ;
            SendMessage(hwndCombo1, CB_ADDSTRING, 0, (LPARAM) "Wipeout") ;
                //SendMessage(hwndCombo1, CB_ADDSTRING, 0, (LPARAM) "Format") ;
            SendMessage(hwndCombo1, CB_ADDSTRING, 0, (LPARAM) "Fahrenh") ;
            SendDlgItemMessage(hwnd, ID_COMBO1, CB_SETCURSEL, model-1, 0L);

        //SomeFunction("blubb") ;
      break;
      case WM_SIZE:
         //if(wParam != SIZE_MINIMIZED)
           // MoveWindow(GetDlgItem(hwnd, IDC_MAIN_TEXT), 0, 0, LOWORD(lParam),
             //  HIWORD(lParam), TRUE);
      break;
      case WM_PAINT : //return 0 ;
          InvalidateRect (hwnd, &rect, TRUE) ;

          hdc = BeginPaint (hwnd, &ps) ;
          SelectObject (hdc, GetStockObject (SYSTEM_FIXED_FONT)) ;
          SetBkMode (hdc, TRANSPARENT) ;

          //TextOut (hdc, 24 * cxChar, cyChar, szTop, lstrlen (szTop)) ;
          //TextOut (hdc, 24 * cxChar, cyChar, szUnd, lstrlen (szUnd)) ;

          EndPaint (hwnd, &ps) ;
          return 0 ;
      case WM_SETFOCUS:
         SetFocus(GetDlgItem(hwnd, IDC_MAIN_TEXT));
      break;
      case WM_COMMAND:
         switch(LOWORD(wParam))
         {
            case ID_BUTTON1:                    // show_table

                if (CheckValue(hwnd)) {         // editbox -> dwStart
                   SendDlgItemMessage(hwnd, ID_LIST, LB_RESETCONTENT, 0, 0L);
                   SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM) " (You might log here instead") ;
                   SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM) "  to MakeH2O_log.txt)") ;
                   if (model==1) show_table(dwStart)  ; // log table to MakeH2O_log.txt
                   else {
                        SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM) " ") ;
                        SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM) " implemented for MLX only") ;
                   }
                }
                break ;
            case ID_COMBO1:                             // model/format selection
                //_itoa(wParam/65536, szErrMess, 10) ; fprintf( stream, "%s\n", szErrMess) ;
                //if (wParam/65536==1) chMB("leckmichdochaa") ;
                 if (HIWORD(wParam)==CBN_SELCHANGE) {
                    model = (BYTE) LOWORD( SendDlgItemMessage(hwnd, ID_COMBO1, CB_GETCURSEL, 0, 0L) ) + 1 ;
                        //if (model==x) SetWindowText (GetDlgItem(hwnd, ID_EDIT), "ABCD");    // ABCD, kann vor File load �berschrieben werden
                 }
            break ;

            case CM_FILE_OPEN:
               DoFileOpenSave(hwnd, FALSE);
            break;
            case CM_FILE_SAVEAS:
               //DoFileOpenSaveAs(hwnd, TRUE);
            break;
            //case CM_FORMAT:
               //CheckFormat() ;
            //   chMB("not in use") ;
            break;
            case CM_FILE_EXIT:
               PostMessage(hwnd, WM_CLOSE, 0, 0);
            break;
            case CM_ABOUT:
               //MessageBox (NULL, "Make_H2O\n  by shak-otay 10/15\n \n     Verwendung auf\n      eigene Gefahr!\n (Use it on your own risk!)" , "About...", 0);
			   MessageBox (NULL, "         Make_H2O\n    by shak-otay 03/21\n              ver 1.0e\n \n     Verwendung auf\n      eigene Gefahr!\n (Use it on your own risk!)", "About...", 0);
            break ;
         }
      break;
      case WM_CLOSE:
         fclose( stream );        // uncomment when log file used
         DestroyWindow(hwnd);
      break;
      case WM_DESTROY:
         PostQuitMessage(0);
      break;
      default:
         return DefWindowProc(hwnd, Message, wParam, lParam);
   }
   return 0;
}


int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
   LPSTR lpCmdLine, int nCmdShow)
{
   WNDCLASSEX WndClass;
   HWND hwnd;
   MSG Msg;

   g_hInst = hInstance;

   WndClass.cbSize        = sizeof(WNDCLASSEX);
   WndClass.style         = 0;
   WndClass.lpfnWndProc   = WndProc;
   WndClass.cbClsExtra    = 0;
   WndClass.cbWndExtra    = 0;
   WndClass.hInstance     = g_hInst;
   WndClass.hIcon         = LoadIcon (hInstance, MAKEINTRESOURCE (5000)) ;//LoadIcon(NULL, IDI_APPLICATION);
   WndClass.hCursor       = LoadCursor(NULL, IDC_ARROW);
   WndClass.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
   WndClass.lpszMenuName  = "MAINMENU";
   WndClass.lpszClassName = g_szClassName;
   WndClass.hIconSm       = LoadIcon (hInstance, MAKEINTRESOURCE (5000)) ;//LoadIcon(NULL, IDI_APPLICATION);

   if(!RegisterClassEx(&WndClass))
   {
      MessageBox(0, "Window Registration Failed!", "Error!",
         MB_ICONEXCLAMATION | MB_OK | MB_SYSTEMMODAL);
      return 0;
   }

   hwnd = CreateWindowEx(
      WS_EX_CLIENTEDGE,
      g_szClassName,
      " Make_H2O",
      WS_OVERLAPPEDWINDOW,
      CW_USEDEFAULT, CW_USEDEFAULT, 330, 256,
      NULL, NULL, g_hInst, NULL);

   if(hwnd == NULL)
   {
      MessageBox(0, "Window Creation Failed!", "Error!",
         MB_ICONEXCLAMATION | MB_OK | MB_SYSTEMMODAL);
      return 0;
   }

   ShowWindow(hwnd, nCmdShow);
   UpdateWindow(hwnd);

   while(GetMessage(&Msg, NULL, 0, 0))
   {
      TranslateMessage(&Msg);
      DispatchMessage(&Msg);
   }
   return Msg.wParam;
}


