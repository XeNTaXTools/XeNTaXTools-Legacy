
	
class Node:
	def __init__(self):
		self.name=None
		self.children=[]
		self.offset=None
		self.start=None
		self.end=None
		self.header=''
		self.data=''
	
class Yson:
	def __init__(self):
		self.input=None
		self.filename=None
		self.root=Node()
		self.log=False
	def parse(self):
		global offset,string,txt
		if self.filename is not None:
			file=open(self.filename,'rb')
			self.input=file.read().replace('\x20','').replace('\x0A','')		
		
			line=self.input
			if self.log==True:txt=open(self.filename+'.ys','w')
			
			if line is not None and len(line)>0:
				offset=0
				n=0
				string=[]
				if self.input[offset]=='{':
					if self.log==True:
						txt.write('\n')
						txt.write(' '*n+'header:'+str(None))
						txt.write(' { '+str(offset))
						txt.write(' '*(n+4))
				if self.input[offset]=='[':
					if self.log==True:
						txt.write('\n')
						txt.write(' '*n+'header:'+str(None))
						txt.write(' [ '+str(offset))
						txt.write(' '*(n+4))
				self.tree(self.root,n)
				if self.log==True:
					txt.write(' '*n)
				print round(100*offset/float(len(self.input)),3),'procent'
				
			file.close()	
			
		if self.log==True:txt.close()

	def getTree(self,parent,list,key):
		for child in parent.children:
			if key in child.header:
				list.append(child)
			self.getTree(child,list,key)	
		
	def values(self,data,type):
		list={}
		A=data.split(',')
		if type==':':
			for a in A:
				if ':' in a:
					B=a.split(':')
					list[B[0]]=B[1]
		if type=='f':
			list=map(float,A)
		if type=='i':
			list=map(int,A)
		if type=='s':
			list=A
		return list			
		
	def get(self,node,key):		
		list=[]
		self.getTree(node,list,key)
		return list	
		
	#def getTree(self,node,key)	
		
			
	def tree(self,parentNode,n):
		global offset,string
		n+=4
		offset+=1
		while(True):	
			if  offset>=len(self.input):break
			value=self.input[offset]
			if value=='}':
				if self.log==True:
					txt.write('\n')
					if len(string)>0:
						txt.write(' '*n+'data:'+self.input[string[0]:offset])	
					else:	
						txt.write(' '*n+'data:None')				
					txt.write('\n'+' '*n+' } '+str(offset))
				if len(string)>0:	
					parentNode.data=self.input[string[0]:offset]
				string=[]
				offset+=1			
				break
			
			elif value=='{':
				if self.log==True:
					txt.write('\n')
					if len(string)>0:
						txt.write(' '*n+'header:'+self.input[string[0]:offset])	
					else:	
						txt.write(' '*n+'header:None')				
					txt.write(' { '+str(offset))
					txt.write(' '*(n+4))
				#print round(100*offset/float(len(self.input)),3),'procent'
				node=Node()
				parentNode.children.append(node)
				node.offset=offset
				if len(string)>0:
					node.header=self.input[string[0]:offset]
				string=[]
				self.tree(node,n)
				if self.log==True:
					txt.write(' '*n)
				
			elif value==']':
				if len(string)>0:
					parentNode.data=self.input[string[0]:offset]
				
				if self.log==True:
					txt.write('\n')
					if len(string)>0:
						txt.write(' '*n+'data:'+self.input[string[0]:offset]+'\n')	
					else:	
						txt.write(' '*n+'data:None')							
					txt.write(' '*n+' ] '+str(offset))
					
				offset+=1
				string=[]
				break
			
			elif value=='[':
				if self.log==True:
					txt.write('\n')
					if len(string)>0:
						txt.write(' '*n+'header:'+self.input[string[0]:offset])
					else:	
						txt.write(' '*n+'header:None')
					txt.write(' [ '+str(offset))
					txt.write(' '*(n+4))
				#print round(100*offset/float(len(self.input)),3),'procent'
				node=Node()
				parentNode.children.append(node)
				node.offset=offset
				node.name=string
				if len(string)>0:
					node.header=self.input[string[0]:offset]
				else:
					node.header=''
				string=[]
				self.tree(node,n)
				if self.log==True:
					txt.write(' '*n)
			else:			
				#string+=value
				if len(string)==0:
					string.append(offset)
				offset+=1
					