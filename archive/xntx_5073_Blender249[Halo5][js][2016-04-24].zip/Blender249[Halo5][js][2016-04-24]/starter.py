import newGameLib
from newGameLib import *
import Blender	


def treeNode(list,node):
	for child in node.children:
		if 'vertices' in child.header:
			list.append(node)
			break
		else:
			treeNode(list,child)

def findMeshNode(node):
	list=[]
	treeNode(list,node)
	return list


def jsonParser(filename):
	global yson
	yson=Yson()
	yson.log=True
	yson.filename=filename	
	yson.parse()
	
	meshList=[]
	meshesList=findMeshNode(yson.root)
	for i,child in enumerate(meshesList):
		print '='*10,i
		mesh=Mesh()
		#mesh.TRIANGLE=True
		mesh.uvList=[]
		meshList.append(mesh)
		
		materials=yson.get(child,'materials')
		if len(materials)==1:
			values=yson.values(materials[0].data,'s')
			print values
					
		vertices=yson.get(child,'vertices')
		if len(vertices)==1:
			values=yson.values(vertices[0].data,'f')
			print 'vertCount:',len(values)/3
			for m in range(0, len(values), 3):
				mesh.vertPosList.append(values[m:m+3] )
				
				
		uvs=yson.get(child,'uvs')
		if len(uvs)==1:
			if len(uvs[0].children)>0:
				if len(uvs[0].children[0].data)>0:
					values=yson.values(uvs[0].children[0].data,'f')
					
					print 'uvsCount:',len(values)/2
					for m in range(0, len(values), 2):
						mesh.uvList.append(values[m:m+2] )
					
		faces=yson.get(child,'faces')
		if len(faces)==1:
			values=yson.values(faces[0].data,'i')
			for m in range(0, len(values), 11):
				if values[m]==42:
					mesh.faceList.append(values[m+1:m+4] )
					if len(mesh.uvList)>0:
						uv1=Vector(mesh.uvList[values[m+5]])
						uv2=Vector(mesh.uvList[values[m+6]])
						uv3=Vector(mesh.uvList[values[m+7]])
						mesh.faceUVList.append([uv1,uv2,uv3])
			
			m=0	
			while(True):
				if m==len(values):break
				if values[m]==42:
					mesh.faceList.append(values[m+1:m+4] )
					if len(mesh.uvList)>0:
						uv1=Vector(mesh.uvList[values[m+5]])
						uv2=Vector(mesh.uvList[values[m+6]])
						uv3=Vector(mesh.uvList[values[m+7]])
						mesh.faceUVList.append([uv1,uv2,uv3])
					
					m+=11
				elif values[m]==40:
					mesh.faceList.append(values[m+1:m+4] )
					if len(mesh.uvList)>0:
						uv1=Vector(mesh.uvList[values[m+4]])
						uv2=Vector(mesh.uvList[values[m+5]])
						uv3=Vector(mesh.uvList[values[m+6]])
						mesh.faceUVList.append([uv1,uv2,uv3])
					
					m+=10
				else:
					print 'Unknow face type:',values[m]
					break
					
		skinWeights=yson.get(child,'skinWeights')
		if len(skinWeights)==1:
			values=yson.values(skinWeights[0].data,'f')
			print 'skinWeightsCount:',len(values)/2
			if len(values)==1:
				for m in range(len(mesh.vertPosList)):
					mesh.skinWeightList.append(values)
			else:		
				for m in range(0, len(values), 2):
					mesh.skinWeightList.append(values[m:m+2] )
					
		skinIndices=yson.get(child,'skinIndices')
		if len(skinIndices)==1:
			values=yson.values(skinIndices[0].data,'i')
			print 'skinIndicesCount:',len(values)/2
			if len(values)==1:
				for m in range(len(mesh.vertPosList)):
					mesh.skinIndiceList.append(values)
			else:		
				for m in range(0, len(values), 2):
					mesh.skinIndiceList.append(values[m:m+2] )
				
		
		if len(skinIndices)==1 and len(skinWeights)==1:
			skin=Skin()
			mesh.skinList.append(skin)	
					
						
	skeleton=Skeleton()
	skeleton.draw()	
	for mesh in meshList:
		mesh.BINDSKELETON=skeleton.name
		mesh.draw()			
	
def Parser(filename):
	ext=filename.split('.')[-1].lower()
	if ext in ['json','js']:
		jsonParser(filename)
 
	
Blender.Window.FileSelector(Parser,'import','Halo 5 files: *.js - model') 
	