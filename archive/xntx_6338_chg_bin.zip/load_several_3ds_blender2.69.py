import os
import bpy

# http://blender.stackexchange.com/questions/5064/batch-import-wavefront-obj
# put the location to the folder where the objs are located here in this fashion
# this line will only work on windows ie C:\objects
models_path = os.path.join('S:\\', 'REO\\r0150100')

models = ["1.3ds", "2.3ds", "3.3ds", "4.3ds", "5.3ds", "6.3ds", "7.3ds", "8.3ds", "9.3ds", "10.3ds", "11.3ds", "12.3ds", "13.3ds", "14.3ds", "15.3ds", "16.3ds", "17.3ds", "18.3ds", "19.3ds", "20.3ds", "21.3ds", "22.3ds", "23.3ds", "24.3ds", "25.3ds", "26.3ds", "27.3ds", "28.3ds", "29.3ds", "30.3ds", "31.3ds", "32.3ds", "33.3ds", "34.3ds", "35.3ds", "36.3ds", "37.3ds", "38.3ds", "39.3ds", "40.3ds", "41.3ds", "42.3ds", "43.3ds", "44.3ds", "45.3ds", "46.3ds", "47.3ds", "48.3ds", "49.3ds", "50.3ds", "51.3ds", "52.3ds", "53.3ds", "54.3ds", "55.3ds", "56.3ds", "57.3ds", "58.3ds", "59.3ds", "60.3ds", "61.3ds", "62.3ds", "63.3ds", "64.3ds", "65.3ds", "66.3ds", "67.3ds", "68.3ds", "69.3ds", "70.3ds", "71.3ds", "72.3ds", "73.3ds", "74.3ds", "75.3ds", "76.3ds", "77.3ds", "78.3ds", "79.3ds", "80.3ds", "81.3ds", "82.3ds", "83.3ds", "84.3ds", "85.3ds", "86.3ds", "87.3ds", "88.3ds", "89.3ds", "90.3ds", "91.3ds", "92.3ds", "93.3ds", "94.3ds", "95.3ds", "96.3ds", "97.3ds", "98.3ds", "99.3ds", "100.3ds", "101.3ds", "102.3ds", "103.3ds", "104.3ds", "105.3ds", "106.3ds", "107.3ds", "108.3ds", "109.3ds", "110.3ds", "111.3ds", "112.3ds", "113.3ds", "114.3ds", "115.3ds", "116.3ds"]


# loop through the strings in models list and add the files to the scene
for model_path in models:
    path = os.path.join(models_path, model_path)
    bpy.ops.import_scene.autodesk_3ds(filepath = path)