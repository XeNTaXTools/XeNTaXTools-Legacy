# based on Two Worlds II - model importer (.chv) by Szkaradek123
# http://forum.xentax.com/viewtopic.php?f=16&t=5535&hilit=Two+Worlds

from inc_noesis import *
import noesis
import rapi

from datetime import datetime
import string
import os

# debug level 1/2/3 and etc
DEBUG = 0
# game name
GAMEID = 'Two Worlds 2'
# first bytes for each extensions, if eq b'' open without check
IDBYTES = {'vdf': b'\x9f\x99\x66\xf6', 'chv': b'\x9f\x99\x66\xf6'}


def registerNoesisTypes():
    handle = noesis.register(GAMEID, ';'.join('.' + e for e in IDBYTES.keys()))
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)
    if DEBUG:
        noesis.logPopup()
        print("\n", datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
        print("----------------------------------------------------------------------------------------")
    return 1


def noepyCheckType(data):
    extension = rapi.getLocalFileName(rapi.getInputName()).split('.')[-1]
    if len(data) < 4 or not extension in IDBYTES:
        return 0
    size = len(IDBYTES[extension])
    if size != 0 and NoeBitStream(data).readBytes(size) != IDBYTES[extension]:
        return 0
    return 1


def noepyLoadModel(data, mdlList):
    if DEBUG:
        print("\n", datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
        print(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")

    global nodeList, texList, matList
    nodeList = []
    texList = []
    matList = []

    ctx = rapi.rpgCreateContext()
    # rapi.rpgSetOption(noesis.RPGOPT_TRIWINDBACKWARD, 1)

    f = open(rapi.getInputName(), 'rb')
    g = BinaryReader(f)
    if DEBUG > 1:
        g.logOpen()

    g.i(1)[0]
    flag = g.B(1)[0]
    back = g.tell()
    n = 0
    # print('flag:', flag)
    if flag == 2:
        section_size = g.i(1)[0]
        node = Node()
        nodeList.append(node)
        node.type = g.i(1)[0]
        # print ('node.type', node.type)
        if node.type == -1:
            twSectionParser(g, back + section_size, node, n)

    if g.ext == 'vdf':
        twReadVDF(g)
    if g.ext == 'chv':
        twReadCHV(g)

    if DEBUG > 1:
        g.logClose()
    f.close()

    try:
        mdl = rapi.rpgConstructModel()
    except:
        mdl = NoeModel([], [], [])

    mdl.setModelMaterials(NoeModelMaterials(texList, matList))
    mdlList.append(mdl)
    rapi.rpgClearBufferBinds()
    # rapi.setPreviewOption("setAngOfs", "90 270 90")
    return 1


def twReadCHV(g):
    for node in nodeList:
        if int(node.type or 0) >= 0:
            lodLevel = None
            meshName = None
            vertCount, vertOffset, vertFormat = None, None, None
            faceCount, faceOffset = None, None
            boneCount, boneMapOffset, boneBindMatrixOffset = None, None, None
            texturePath = None

            # matList=[]
            for child in node.children:
                for key in child.data.keys():
                    # print(key, child.data[key])
                    if key == 'Name': meshName = child.data[key]
                    if key == 'NumVertexes': vertCount = child.data[key]
                    if key == 'Vertexes': vertOffset = child.data[key]
                    if key == 'VertexFormat': vertFormat = child.data[key]
                    if key == 'NumFaces': indiceCount = child.data[key]
                    if key == 'Faces': faceOffset = child.data[key]
                    if key == 'LODLevel': lodLevel = child.data[key]
                    if key == 'NumBones': boneCount = child.data[key]
                    if key == 'BoneIDS': boneMapOffset = child.data[key]
                    if key == 'BindMatrix': boneBindMatrixOffset = child.data[key]
                #print child.type
                if child.type == -253:
                    texDir = rapi.getInputName().lower().split('models')[0] + 'textures\\'
                    if not os.path.isdir(texDir): texDir = rapi.getDirForFilePath(rapi.getInputName()).lower()
                    # mat=Mat()
                    for child253 in child.children:
                        for key in child253.data.keys():
                            print(key, child253.data[key])
                            if key == 'TexS0': texturePath = texDir + child253.data[key]
                            #if key=='TexS1':mat.normal=texDir+os.sep+child253.data[key]
                            #if key=='TexS2':mat.specular=texDir+os.sep+child253.data[key]
                    #matList.append(mat)
            if lodLevel is not None:
                if lodLevel == 0:
                    # skeleton = Skeleton()
                    # skeleton.name = meshName
                    # mesh = Mesh()
                    # mesh.UVFLIP = True
                    # skin = Skin()
                    # mesh.skinList.append(skin)
                    if vertCount is not None and vertOffset is not None and vertFormat is not None:
                        g.seek(vertOffset)
                        if vertFormat == 1:
                            size = 52
                        else:
                            size = 44
                        b = bytearray(g.read(vertCount * size))
                        rapi.rpgBindPositionBufferOfs(b, noesis.RPGEODATA_FLOAT, size, 0)
                        for i in range(vertCount):  # flip UV
                            base = (i * size) + 40
                            v = struct.unpack('<f', b[base:base + 4])[0]
                            b[base:base + 4] = struct.pack('<f', 1-v)
                        rapi.rpgBindUV1BufferOfs(b, noesis.RPGEODATA_FLOAT, size, 36)
                        #for i in range(vertCount):
                        #    t = g.tell()
                        #    mesh.vertPosList.append(g.f(3))
                        #    mesh.skinWeightList.append(g.f(3))
                        #    mesh.skinIndiceList.append(g.B(3))
                        #    g.seek(t + 36)
                        #    mesh.vertUVList.append(g.f(2))
                        #    if vertFormat == 1:
                        #        g.seek(t + 52)
                    if indiceCount is not None and faceOffset is not None:
                        g.seek(faceOffset)
                        faceCount = int(indiceCount / 3)
                        b = g.read(faceCount * 6)
                        if texturePath is not None:
                            rapi.rpgSetMaterial(rapi.getLocalFileName(texturePath).split('.')[0])
                        rapi.rpgCommitTriangles(b, noesis.RPGEODATA_USHORT, indiceCount, noesis.RPGEO_TRIANGLE, 1)
                        #faceCount = indiceCount / 3
                        #for i in range(faceCount):
                        #    mesh.faceList.append(g.H(3))
                    if texturePath is not None:
                        materialName = rapi.getLocalFileName(texturePath).split('.')[0]
                        rapi.rpgSetMaterial(materialName)
                        material = NoeMaterial(materialName, texturePath)
                        material.setTexture(texturePath)
                        matList.append(material)


def twReadVDF(g):
    for node in nodeList:
        if int(node.type or 0) >= 0:
            lodLevel = None
            meshName = None
            vertCount, vertOffset, vertFormat = None, None, None
            faceCount, faceOffset = None, None
            boneCount, boneMapOffset, boneBindMatrixOffset = None, None, None
            texturePath = None

            for child in node.children:
                for key in child.data.keys():
                    # print (key, child.data[key])
                    if key == 'Name': meshName = child.data[key]
                    if key == 'NumVertexes': vertCount = child.data[key]
                    if key == 'Vertexes': vertOffset = child.data[key]
                    if key == 'VertexFormat': vertFormat = child.data[key]
                    if key == 'NumFaces': indiceCount = child.data[key]
                    if key == 'Faces': faceOffset = child.data[key]
                    if key == 'LODLevel': lodLevel = child.data[key]
                    if key == 'NumBones': boneCount = child.data[key]
                    if key == 'BoneIDS': boneMapOffset = child.data[key]
                    if key == 'BindMatrix': boneBindMatrixOffset = child.data[key]
                # print(child.type)
                if child.type == -253:
                    texDir = rapi.getInputName().lower().split('models')[0] + 'textures\\'
                    if not os.path.isdir(texDir): texDir = rapi.getDirForFilePath(rapi.getInputName()).lower()
                    # mat = Mat()
                    for child253 in child.children:
                        for key in child253.data.keys():
                            print(key, child253.data[key])  # TODO: FIX
                            if key == 'TexS0': texturePath = texDir + child253.data[key]
                            # if key == 'TexS1': mat.normal = texDir + os.sep + child253.data[key]
                            # if key == 'TexS2': mat.specular = texDir + os.sep + child253.data[key]
                    # matList.append(mat)
            if lodLevel is not None:
                if lodLevel == 0:
                    # skeleton = Skeleton()
                    # skeleton.name = meshName
                    # mesh = Mesh()
                    # mesh.UVFLIP = True
                    if vertCount is not None and vertOffset is not None and vertFormat is not None:
                        g.seek(vertOffset)
                        if vertFormat == 1:
                            size = 36
                        else:
                            size = 28
                        b = bytearray(g.read(vertCount * size))
                        rapi.rpgBindPositionBufferOfs(b, noesis.RPGEODATA_FLOAT, size, 0)
                        for i in range(vertCount):  # flip UV
                            base = (i * size) + 24
                            v = struct.unpack('<f', b[base:base + 4])[0]
                            b[base:base + 4] = struct.pack('<f', v * -1)
                        rapi.rpgBindUV1BufferOfs(b, noesis.RPGEODATA_FLOAT, size, 20)
                        #rapi.rpgBindNormalBufferOfs(b, noesis.RPGEODATA_FLOAT, 88, 12)
                        #rapi.rpgCommitTriangles(None, noesis.RPGEODATA_USHORT, vertCount, noesis.RPGEO_POINTS, 1)
                        #for i in range(vertCount):
                        #    t = g.tell()
                        #    print(g.f(3))  # mesh.vertPosList.append(g.f(3))
                        #    g.seek(t+20)
                        #    g.f(2)  # mesh.vertUVList.append(g.f(2))
                        #    if vertFormat == 1:
                        #        g.seek(t+36)
                    if indiceCount is not None and faceOffset is not None:
                        g.seek(faceOffset)
                        faceCount = int(indiceCount / 3)
                        b = g.read(faceCount * 6)
                        if texturePath is not None:
                            rapi.rpgSetMaterial(rapi.getLocalFileName(texturePath).split('.')[0])
                        rapi.rpgCommitTriangles(b, noesis.RPGEODATA_USHORT, indiceCount, noesis.RPGEO_TRIANGLE, 1)
                        # for i in range(faceCount):
                        #    print(g.tell() - faceOffset)
                        #    print(g.H(3))  # mesh.faceList.append(g.H(3))
                    if texturePath is not None:
                        materialName = rapi.getLocalFileName(texturePath).split('.')[0]
                        rapi.rpgSetMaterial(materialName)
                        material = NoeMaterial(materialName, texturePath)
                        material.setTexture(texturePath)
                        matList.append(material)
                        #mesh.matList = matList
                        #mesh.BINDSKELETON = skeleton.name
                        #mesh.draw()


def twSectionParser(g, size, parent, n):
    section_size = size
    n += 4
    while (True):
        node = Node()
        nodeList.append(node)
        flag = g.B(1)[0]
        # print('-' * n, 'flag:', flag)
        back = g.tell()
        offset = g.i(1)[0]
        if flag == 1:
            chunk = g.B(1)[0]
            name = g.word(g.i(1)[0])
            # print('-' * n, chunk, name, g.tell())
            if chunk == 18: node.data[name] = g.i(1)[0]
            if chunk == 21: node.data[name] = g.f(16)  # Matrix4x4(g.f(16))
            if chunk == 23: node.data[name] = g.tell()
            if chunk == 22: node.data[name] = g.bytesToStr(g.find(b'\x01'))
        if flag == 2:
            node.type = g.i(1)[0]
            # print('-' * n, 'node.type:', node.type)
            if node.type >= 0: print('-submesh')
            if node.type == -255: print('-bone')
            if node.type == -253: print('-material')
            twSectionParser(g, back + offset, node, n)
        g.seek(back + offset, 0)
        parent.children.append(node)
        if back + offset == section_size:
            break


class Node:
    def __init__(self):
        self.type = None
        self.children = []
        self.data = {}
        self.name = None


class BinaryReader:
    # general BinaryReader

    def __init__(self, inputFile):
        self.inputFile = inputFile
        self.endian = '<'
        self.debug = False
        self.stream = {}
        self.logfile = None
        self.log = False
        # Blender.sys.dirname(self.inputFile.name)
        self.dirname = rapi.getDirForFilePath(self.inputFile.name)
        # Blender.sys.basename(self.inputFile.name).split('.')[0]
        self.basename = rapi.getLocalFileName(self.inputFile.name).split('.')[0]
        # Blender.sys.basename(self.inputFile.name).split('.')[-1]
        self.ext = rapi.getLocalFileName(self.inputFile.name).split('.')[-1]
        self.xorKey = None
        self.xorOffset = 0
        self.xorData = ''

    def bytesToStr(self, data, printable=True, encoding="ASCII"):
        # data.decode("ASCII", 'ignore')
        # tst = ''.join(chr(c) for c in tst if 32 <= c <= 127)
        # tst = ''.join(c for c in tst if ord(c)>=32)
        # spurious = set(chr(c) for c in range(32)) - set('\r\n\t')
        # clean = ''.join(c for c in line if c not in spurious)
        s = str(data, encoding, "ignore").rstrip("\0")
        if printable:
            return ''.join(c for c in s if c in string.printable)
        return s

    def XOR(self, data):
        self.xorData = ''
        for m in range(len(data)):
            ch = ord(chr(data[m] ^ self.xorKey[self.xorOffset]))
            self.xorData += struct.pack('B', ch)
            if self.xorOffset == len(self.xorKey) - 1:
                self.xorOffset = 0
            else:
                self.xorOffset += 1

    def logOpen(self):
        self.log = True
        self.logfile = open(self.inputFile.name + '.log', 'w')

    def logClose(self):
        self.log = False
        if self.logfile is not None:
            self.logfile.close()

    def logWrite(self, data):
        if self.logfile is not None:
            self.logfile.write(str(data) + '\n')
        else:
            print('WARNING: no log')

    def dirname(self):
        return self.dirname  # Blender.sys.dirname(self.inputFile.name)

    def basename(self):
        return self.basename  # Blender.sys.basename(self.inputFile.name).split('.')[0]

    def ext(self):
        return self.ext  # Blender.sys.basename(self.inputFile.name).split('.')[-1]

    def q(self, n):
        offset = self.inputFile.tell()
        data = struct.unpack(self.endian + n * 'q', self.inputFile.read(n * 8))
        if self.debug == True:
            print(data)
        if self.log == True:
            if self.logfile is not None:
                self.logfile.write('offset ' + str(offset) + '	' + str(data) + '\n')
        return data

    def i(self, n):
        if self.inputFile.mode == 'rb':
            offset = self.inputFile.tell()
            if self.xorKey is None:
                data = struct.unpack(self.endian + n * 'i', self.inputFile.read(n * 4))
            else:
                data = struct.unpack(self.endian + n * 4 * 'B', self.inputFile.read(n * 4))
                self.XOR(data)
                data = struct.unpack(self.endian + n * 'i', self.xorData)

            if self.debug == True:
                print(data)
            if self.log == True:
                if self.logfile is not None:
                    self.logfile.write('offset ' + str(offset) + '	' + str(data) + '\n')
            return data
        if self.inputFile.mode == 'wb':
            for m in range(len(n)):
                data = struct.pack(self.endian + 'i', n[m])
                self.inputFile.write(data)

    def I(self, n):
        offset = self.inputFile.tell()
        if self.xorKey is None:
            data = struct.unpack(self.endian + n * 'I', self.inputFile.read(n * 4))
        else:
            data = struct.unpack(self.endian + n * 4 * 'B', self.inputFile.read(n * 4))
            self.XOR(data)
            data = struct.unpack(self.endian + n * 'I', self.xorData)
        if self.debug == True:
            print(data)
        if self.log == True:
            if self.logfile is not None:
                self.logfile.write('offset ' + str(offset) + '	' + str(data) + '\n')
        return data

    def B(self, n):
        if self.inputFile.mode == 'rb':
            offset = self.inputFile.tell()
            if self.xorKey is None:
                data = struct.unpack(self.endian + n * 'B', self.inputFile.read(n))
            else:
                data = struct.unpack(self.endian + n * 'B', self.inputFile.read(n))
                self.XOR(data)
                data = struct.unpack(self.endian + n * 'B', self.xorData)
            if self.debug == True:
                print(data)
            if self.log == True:
                if self.logfile is not None:
                    self.logfile.write('offset ' + str(offset) + '	' + str(data) + '\n')
            return data
        if self.inputFile.mode == 'wb':
            for m in range(len(n)):
                data = struct.pack(self.endian + 'B', n[m])
                self.inputFile.write(data)

    def b(self, n):
        if self.inputFile.mode == 'rb':
            offset = self.inputFile.tell()
            if self.xorKey is None:
                data = struct.unpack(self.endian + n * 'b', self.inputFile.read(n))
            else:
                data = struct.unpack(self.endian + n * 'b', self.inputFile.read(n))
                self.XOR(data)
                data = struct.unpack(self.endian + n * 'b', self.xorData)
            if self.debug == True:
                print(data)
            if self.log == True:
                if self.logfile is not None:
                    self.logfile.write('offset ' + str(offset) + '	' + str(data) + '\n')
            return data
        if self.inputFile.mode == 'wb':
            for m in range(len(n)):
                data = struct.pack(self.endian + 'b', n[m])
                self.inputFile.write(data)

    def h(self, n):
        if self.inputFile.mode == 'rb':
            offset = self.inputFile.tell()
            if self.xorKey is None:
                data = struct.unpack(self.endian + n * 'h', self.inputFile.read(n * 2))
            else:
                data = struct.unpack(self.endian + n * 2 * 'B', self.inputFile.read(n * 2))
                self.XOR(data)
                data = struct.unpack(self.endian + n * 'h', self.xorData)
            if self.debug == True:
                print(data)
            if self.log == True:
                if self.logfile is not None:
                    self.logfile.write('offset ' + str(offset) + '	' + str(data) + '\n')
            return data
        if self.inputFile.mode == 'wb':
            for m in range(len(n)):
                data = struct.pack(self.endian + 'h', n[m])
                self.inputFile.write(data)

    def H(self, n):
        if self.inputFile.mode == 'rb':
            offset = self.inputFile.tell()
            if self.xorKey is None:
                data = struct.unpack(self.endian + n * 'H', self.inputFile.read(n * 2))
            else:
                data = struct.unpack(self.endian + n * 2 * 'B', self.inputFile.read(n * 2))
                self.XOR(data)
                data = struct.unpack(self.endian + n * 'H', self.xorData)
            if self.debug == True:
                print(data)
            if self.log == True:
                if self.logfile is not None:
                    self.logfile.write('offset ' + str(offset) + '	' + str(data) + '\n')
            return data
        if self.inputFile.mode == 'wb':
            for m in range(len(n)):
                data = struct.pack(self.endian + 'H', n[m])
                self.inputFile.write(data)

    def f(self, n):
        if self.inputFile.mode == 'rb':
            offset = self.inputFile.tell()
            if self.xorKey is None:
                data = struct.unpack(self.endian + n * 'f', self.inputFile.read(n * 4))
            else:
                data = struct.unpack(self.endian + n * 4 * 'B', self.inputFile.read(n * 4))
                self.XOR(data)
                data = struct.unpack(self.endian + n * 'f', self.xorData)
            if self.debug == True:
                print(data)
            if self.log == True:
                if self.logfile is not None:
                    self.logfile.write('offset ' + str(offset) + '	' + str(data) + '\n')
            return data
        if self.inputFile.mode == 'wb':
            for m in range(len(n)):
                data = struct.pack(self.endian + 'f', n[m])
                self.inputFile.write(data)

    def half(self, n, h='h'):
        array = []
        offset = self.inputFile.tell()
        for id in range(n):
            # array.append(converthalf2float(struct.unpack(self.endian+'H',self.inputFile.read(2))[0]))
            array.append(converthalf2float(struct.unpack(self.endian + h, self.inputFile.read(2))[0]))
        if self.debug == True:
            print(array)
        if self.log == True:
            if self.logfile is not None:
                self.logfile.write('offset ' + str(offset) + '	' + str(array) + '\n')
        return array

    def short(self, n, h='h', exp=12):
        array = []
        offset = self.inputFile.tell()
        for id in range(n):
            array.append(struct.unpack(self.endian + h, self.inputFile.read(2))[0] * 2 ** -exp)
        # array.append(self.H(1)[0]*2**-exp)
        if self.debug == True:
            print(array)
        if self.log == True:
            if self.logfile is not None:
                self.logfile.write('offset ' + str(offset) + '	' + str(array) + '\n')
        return array

    def i12(self, n):
        array = []
        offset = self.inputFile.tell()
        for id in range(n):
            if self.endian == '>':
                var = '\x00' + self.inputFile.read(3)
            if self.endian == '<':
                var = self.inputFile.read(3) + '\x00'
            array.append(struct.unpack(self.endian + 'i', var)[0])
        if self.debug == True:
            print(array)
        if self.log == True:
            if self.logfile is not None:
                self.logfile.write('offset ' + str(offset) + '	' + str(array) + '\n')
        return array

    def find(self, var, size=1000):
        # var type is bytes, bytearray or memoryview
        start = self.inputFile.tell()
        s = bytes()
        while (True):
            data = self.inputFile.read(size)
            off = data.find(var)  # off = data.find(var.encode('ASCII'))  # TODO: FIX
            if off >= 0:
                s += data[:off]
                self.inputFile.seek(start + off + len(var))
                break
            else:
                s += data
                start += size

        # s = s.decode('ASCII', 'ignore').rstrip("\x00\x01\x02")

        if self.debug == True:
            print(s)
        if self.log == True:
            if self.logfile is not None:
                self.logfile.write('offset ' + str(start) + '	' + ascii(s) + '\n')

        # print(">>>>" + repr(s))
        # print(">>>>" + s)
        return s

    def findAll(self, var, size=100):
        list = []
        start = self.inputFile.tell()
        while (True):
            data = self.inputFile.read(size)
            off = data.find(var.encode('latin1'))  # TODO: FIX
            # print off,self.inputFile.tell()
            if off >= 0:
                list.append(start + off)
                self.inputFile.seek(start + off + len(var))
                if self.debug == True:
                    print(start + off)
            else:
                start += size
                self.inputFile.seek(start)
            if self.inputFile.tell() > self.fileSize():
                break
        return list

    def findchar(self, var):
        offset = self.inputFile.find(var.encode('latin1'))  # TODO: FIX
        if self.debug == True:
            print(var, 'znaleziono', offset)
        if self.log == True:
            if self.logfile is not None:
                self.logfile.write(var + ' znaleziono ' + str(offset) + '\n')
        return offset

    def fileSize(self):
        back = self.inputFile.tell()
        self.inputFile.seek(0, 2)
        tell = self.inputFile.tell()
        self.inputFile.seek(back)
        return tell

    def seek(self, off, a=0):
        self.inputFile.seek(off, a)

    def seekpad(self, pad, type=0):
        ''' 16-byte chunk alignment'''
        size = self.inputFile.tell()
        seek = (pad - (size % pad)) % pad
        if type == 1:
            if seek == 0:
                seek += pad
        self.inputFile.seek(seek, 1)

    def read(self, count):
        back = self.inputFile.tell()
        if self.xorKey is None:
            return self.inputFile.read(count)
        else:
            data = struct.unpack(self.endian + n * 'B', self.inputFile.read(n))
            self.XOR(data)
            return self.xorData

    def tell(self):
        val = self.inputFile.tell()
        if self.debug == True:
            print('current offset is', val)
        return val

    def word(self, long):
        if long < 10000:
            if self.inputFile.mode == 'rb':
                offset = self.inputFile.tell()
                s = ''
                for j in range(0, long):
                    if self.xorKey is None:
                        lit = struct.unpack('c', self.inputFile.read(1))[0]
                        # data=struct.unpack(self.endian+n*'i',self.inputFile.read(n*4))
                    else:
                        data = struct.unpack(self.endian + 'B', self.inputFile.read(1))
                        self.XOR(data)
                        lit = struct.unpack(self.endian + 'c', self.xorData)[0]
                        # lit =  struct.unpack('c',self.inputFile.read(1))[0]
                    if ord(lit) != 0:
                        s += lit.decode()  # noeStrFromBytes(lit)  # TODO: FIX
                if self.debug == True:
                    print(s)
                if self.log == True:
                    if self.logfile is not None:
                        self.logfile.write('offset ' + str(offset) + '	' + s + '\n')
                return s
            if self.inputFile.mode == 'wb':
                # data=self.inputFile.read(long)
                self.inputFile.write(long)
                # return 0
        else:
            if self.debug == True:
                print('WARNING:too long')
                # return 1

    def Stream(self, stream_name, element_count, element_size):
        self.inputFile.seek(element_count * element_size, 1)
        self.stream[stream_name]['offset'] = offset
        self.stream[stream_name]['element_count'] = element_count
        self.stream[stream_name]['element_size'] = element_size

        # def getFrom(self,stream_name,)