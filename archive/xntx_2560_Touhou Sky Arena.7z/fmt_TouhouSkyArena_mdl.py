from inc_noesis import *
import noesis
import rapi

from Sanae3D.Sanae import SanaeObject
import os

def registerNoesisTypes():
    handle = noesis.register("Touhou Sky Arena", ".mdl")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel) #see also noepyLoadModelRPG
    noesis.logPopup()
    return 1

#check if it's this type based on the data
def noepyCheckType(data):
    
    if len(data) < 23:
        return 0
    bs = NoeBitStream(data)
    header = noeStrFromBytes(bs.readBytes(23))
    if header != "MBS MODEL VER 0.01 FILE":
        return 0
    return 1

#load the model
def noepyLoadModel(data, mdlList):
    ctx = rapi.rpgCreateContext()
    parser = TouhouSkyArena_MDL(data)
    parser.parse_file()
    mdl = rapi.rpgConstructModel()
    mdl.setModelMaterials(NoeModelMaterials(parser.texList, parser.matList))
    mdlList.append(mdl)
    return 1

class TouhouSkyArena_MDL(SanaeObject):
    
    def __init__(self, data):    
        super(TouhouSkyArena_MDL, self).__init__(data)
        self.faceMats = []
      
    def read_name(self):

        return self.inFile.readString()
    
    def parse_material(self, numMat):
        
        for i in range(numMat):
            matSize = self.inFile.readUInt()
            matName = self.read_name()
            self.inFile.read('16f')
            self.inFile.read('5L')
            charLen = self.inFile.readUInt()
            texName = os.path.basename(self.read_string(charLen))
            self.inFile.read('3L')
            
            material = NoeMaterial(matName, "")
            material.setTexture(texName)
            self.matList.append(material)
    
    def parse_vertices(self, numVerts):
        
        verts = self.inFile.readBytes(numVerts * 48)
        rapi.rpgBindPositionBufferOfs(verts, noesis.RPGEODATA_FLOAT, 48, 0)
        rapi.rpgBindNormalBufferOfs(verts, noesis.RPGEODATA_FLOAT, 48, 12)
        rapi.rpgBindUV1BufferOfs(verts, noesis.RPGEODATA_FLOAT, 48, 24)
            
    def parse_faces(self, numIdx):
        
        self.idxList = self.inFile.readBytes(numIdx * 4)
        
    def parse_face_material(self):
        
        numMat = self.inFile.readUInt()
        for i in range(numMat):
            start, count = self.inFile.read('2L')
            self.faceMats.append([start, count])
            
    def assign_face_material(self, numMat, numIdx):
        '''Have to split the idxList into separate parts, where each index
        is an integer'''
        
        for i in range(numMat):
            start = self.faceMats[i][0]
            count = self.faceMats[i][1]
            end = start*4 + count*4
            idxList = self.idxList[start*4:end]
            material = self.matList[i]
            matName = material.name
            rapi.rpgSetMaterial(matName)
            rapi.rpgCommitTriangles(idxList, noesis.RPGEODATA_UINT, count, noesis.RPGEO_TRIANGLE, 1)

    def parse_file(self):
        '''Main parser method. Can be replaced'''
        
        idstring = self.read_string(23)
        null, meshSize = self.inFile.read('2L')
        meshName = self.read_name()        
        rapi.rpgSetName(meshName)
        unk2, unk3, numVerts, unk4 = self.inFile.read('4L')
        self.parse_vertices(numVerts)
        null, unk5, faceSectSize, numIdx = self.inFile.read('4L')
        self.parse_faces(numIdx)
        self.parse_face_material()
        
        #material section
        null, unk6 = self.inFile.read('2L')
        matSectSize, numMat, numMat2 = self.inFile.read('3L')
        self.parse_material(numMat)
        self.assign_face_material(numMat, numIdx)