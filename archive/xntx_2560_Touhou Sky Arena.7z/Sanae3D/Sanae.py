from inc_noesis import *
import noesis
import rapi

class SanaeObject(object):
    '''A generic class that provides some common methods'''
    
    def __init__(self, data):
        
        self.inFile = NoeBitStream(data)
        self.meshList = []
        self.uvList = []
        self.normList = []
        self.vertList = []
        self.idxList = []
        self.animList = ""
        self.texList = []
        self.matList = []
        
    def create_mesh(self, meshName):
      
        mesh = NoeMesh(self.idxList, self.vertList, meshName, self.animList)
        mesh.normals.extend(self.normList)
        mesh.uvs.extend(self.uvList)
        self.meshList.append(mesh)
        
    def read_string(self, n):
    
        return noeStrFromBytes(self.inFile.readBytes(n))