from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("25 To Life", ".DBL")
    noesis.setHandlerTypeCheck(handle, CheckType)
    noesis.setHandlerLoadModel(handle, LoadModel)
    noesis.logPopup()
    return 1

def CheckType(data):
    bs = NoeBitStream(data)
    if bs.readInt() != 48: return 0
    return 1
    
def LoadModel(data, mdlList):
    bs = NoeBitStream(data)
    
    bs.seek(24)
    count_file = bs.readShort()
    bs.seek(6, NOESEEK_REL)
    
    for file in range(count_file):
        type = bs.readInt()
        #materials
        if type == 917764:
            readMaterials(bs)
        #texture
        elif type == 917634:
            readTextures(bs)
        #object
        elif type == 917607:
            readObject(bs)
        #mesh
        elif type == 917539 or type == 917538:
            readMesh(bs, mdlList)
    
    print("END>>>>>>>", bs.getOffset())
    if not mdlList:
        mdl = NoeModel()
        mdlList.append(mdl)
    return 1
    """
    print(bs.getOffset())
    bs.seek(57216)
    for x in range(26):
        bs.seek(176,NOESEEK_REL)
        print(noeAsciiFromBytes(bs.readBytes(64)))
        
    print(bs.getOffset())

 
    for x in range(1):
        data = bs.readBytes(imgWidth*imgHeight*4) 
        data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "r8 g8 b8 a8")
        texFmt = noesis.NOESISTEX_RGBA32
        texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    """
def readMaterials(bs):
    size = bs.readInt()
    unk = bs.readShort()
    bs.seek(54, NOESEEK_REL)#1000 and zero bytes
    endBlock = bs.getOffset() + size
    count = bs.readUShort()
    unk0 = bs.readUShort()
    size = bs.readInt()
    print("<<<MATERIAL>>> size:",size,"unk:",unk,"conut:",count)
    print("unk0:",unk0)
    bs.seek(size-8, NOESEEK_REL)
    for x in range(count):
        index = bs.readInt()
        name = searchString(bs)
        skipByte(bs, 238)
        print(index, name, bs.getOffset())
    bs.seek(endBlock)
    return 1

def readTextures(bs):
    size = bs.readInt()
    unk = bs.readShort()
    bs.seek(54, NOESEEK_REL)#1000 and zero bytes
    endBlock = bs.getOffset() + size
    countTx = bs.readInt()
    bs.seek(20, NOESEEK_REL)
    print("<<<TEXTURE>>> size:",size,"unk:",unk,"conut:",countTx)
    path = searchString(bs)
    print("path:",path)
    tx_info = []
    for x in range(countTx):
        #image info 40 bytes:
        #0-type(9, 28); ...; 6-ossfet; ...; 8-with; 9-height; ...; 14-palette; ...
        info = [bs.readUShort() for x in range(20)]
        #image
        name = searchString(bs)
        tx_info.append([name,info])

    for x in tx_info:
        type = x[1][0]
        if type == 9:
            pixel_byte = 1
            palete_byte = 8
        elif type == 28:
            pixel_byte = 4
            palete_byte = 0
        elif type == 8:
            pixel_byte = 1
            palete_byte = 2
        
        #bs.seek(x[1][16]*x[1][17]*palete_byte, NOESEEK_REL)#paletteData
        #bs.seek(x[1][8]*x[1][9]*pixel_byte, NOESEEK_REL)#pixelData
        
        print(x[0], x[1], bs.getOffset())
    bs.seek(endBlock)
    return 1

def readObject(bs):
    size = bs.readInt()
    unk = bs.readShort()
    print("<<<OBJECT>>> size:",size,"unk:",unk)
    bs.seek(54, NOESEEK_REL)#1000 and zero bytes
    startBlock = bs.getOffset()
    endBlock = startBlock + size

    countM, unk0 = bs.readShort(), bs.readShort()
    offset = [bs.readInt() for x in range(countM)]
    print("offset:",offset)
    startData = offset[0]
    bs.seek(startBlock+startData)
    print("Count object:",countM, unk0)
    for y in range(countM):
        bs.seek(4, NOESEEK_REL)
        count = bs.readInt()
        print("-Count subObject:",count)
        for x in range(count):
            #0-mat;
            info = [bs.readUShort() for x in range(6)]
            name = noeAsciiFromBytes(bs.readBytes(32))#searchString(bs)
            print("subObject:",name, info, bs.getOffset())
    bs.seek(endBlock)
    return 1

def readMesh(bs, mdlList):
    size = bs.readInt()
    unk = bs.readShort()
    print("<<<MESH>>> size:",size,"unk:",unk)
    bs.seek(54, NOESEEK_REL)#1000 and zero bytes
    startBlock = bs.getOffset()
    endBlock = startBlock + size
    
    countM, unk0 = bs.readShort(), bs.readShort()
    offset = [bs.readInt() for x in range(countM)]
    print("cont mesh:",countM,"offset:",offset)
    #startData = offset[0]
    #bs.seek(startBlock+startData)
    """
    size = bs.readInt()
    unk = bs.readShort()
    bs.seek(54, NOESEEK_REL)#1000 and zero bytes
    endBlock = bs.getOffset() + size
    print("<<<MESH>>> size:",size,"unk:",unk)
    unk0 = [bs.readUShort() for x in range(8)]
    print(unk0)
    """
    ctx = rapi.rpgCreateContext()
    for mesh_off in offset:
        
        off = startBlock+mesh_off
        bs.seek(off+120)
        #print(startBlock+mesh_off)
        
        start_file = bs.readUInt()+off
        bs.seek(startBlock+mesh_off+144)
        size_file = bs.readUInt()
        num_mesh = bs.readUInt()
        offset_mesh = [bs.readUInt() for x in range(num_mesh)]
        print("num_mesh>>>",num_mesh,"offset_mesh>>>",offset_mesh)
        bs.seek(start_file)
        
        for offset in offset_mesh:
            bs.seek(off+offset)
            head = bs.readUInt()#head mesh (EF BE AD DE)
            if head != 3735928559:
                bs.seek(off+offset+152)#152
                head = bs.readUInt()
            start_file = bs.getOffset() - 4
            #0-(1);1-(68);2-numSubMesh;3-unk;4-zero;5-zero;6-numUnk;7-unkOffset;8-unk;9-unk;10-zero;11-zero; 
            #12-numUnk;13-unkOffset;14-numUnk;15-unkOffset;16-offsetIndise;17-numIndices;18-unk;
            info = [bs.readUInt() for x in range(19)]
            print("head>>>(",head,") info>>>",info,"offset>>>",bs.getOffset())
        
            iCount = info[-2]
            start_faces = bs.getOffset()
            bs.seek(start_faces+iCount * 2)
            
            #faces = bs.readBytes(iCount * 2)
            print("face info>>>",iCount)
            
            #>>>>>>>>>>>>>>>>>>>>
            curPos = bs.getOffset()
            bs.seek(start_file+info[-4])
            dict_submesh = {}
            for t in range(info[-5]):
                #0-zero;1-id;2-IDsubmesh;3-zero;4-zero;5-startIndc;6-startVert;7-numVert;8-numIndices;9-end(5);
                submesh_info = [bs.readInt() for x in range(10)]
                print("submesh_info>>>",submesh_info)
                if submesh_info[2] in dict_submesh:
                    dict_submesh[submesh_info[2]].append(submesh_info[5:-1])
                else:
                    dict_submesh[submesh_info[2]]=[submesh_info[5:-1]]
            print(dict_submesh)
            bs.seek(curPos)
            #>>>>>>>>>>>>>>>>>>>>
            
            vert_info = []
            for i in range(info[-17]):
                #vert_offset, vCount, stride, size
                vert_info.append([bs.readInt() for x in range(4)])
            
            for q,v in enumerate(vert_info):
                vOffset, vCount, stride, size = v[0], v[1], v[2], v[3]
                    
                print("vert info>>> vOffset:",vOffset,"vCount:",vCount,"stride:",stride,"size:",size, "offset:",bs.getOffset())
                start_vertices = bs.getOffset()
                #bs.seek(start_vertices+size)
                data = bs.readBytes(size)
                         
                uvOffset = stride-8 if stride > 20 else 0

                cp = bs.getOffset()
                #data = b''
                faces = b''
                iCount = 0
                for value in dict_submesh[q]:
                    print("value", value)#0-startIndc;1-startVert;2-numVert;3-numIndices
                    bs.seek(start_faces+value[0]*2)
                    iCount += value[3]+2
                    faces += bs.readBytes((value[3]+2) * 2)
                    #bs.seek(start_vertices+value[1]*stride)
                    #data += bs.readBytes(value[2]*stride)

                bs.seek(cp)
                
                rapi.rpgSetName("Mesh_"+str(vOffset+q))
                rapi.rpgBindPositionBufferOfs(data, noesis.RPGEODATA_FLOAT, stride, 0)

                #if normOffset:
                    #rapi.rpgBindNormalBufferOfs(data, noesis.RPGEODATA_FLOAT, stride, normOffset)
                if uvOffset:
                    rapi.rpgBindUV1BufferOfs(data, noesis.RPGEODATA_FLOAT, stride, uvOffset)
                rapi.rpgCommitTriangles(faces, noesis.RPGEODATA_USHORT, iCount, noesis.RPGEO_TRIANGLE_STRIP)
                rapi.rpgClearBufferBinds()
    rapi.rpgOptimize()
    mdl = rapi.rpgConstructModel()
    mdlList.append(mdl)
    bs.seek(endBlock)
    return 1

def searchString(bs):
    bytes = []
    byte = None
    while byte != 0:
        byte = bs.readUByte()
        bytes.append(byte)
    return noeAsciiFromBytes(bytes)
    
def skipByte(bs, b):
    for x in range(99):
        if bs.readUByte() != b: 
            bs.seek(-1, NOESEEK_REL)
            return 1