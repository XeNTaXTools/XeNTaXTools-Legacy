# Legacy Of Discord
# Noesis script by DKDave, 2021
# Last updated: 4 January 2022


from inc_noesis import *


def registerNoesisTypes():
	handle = noesis.register("Legacy Of Discord",".skn")
	noesis.setHandlerTypeCheck(handle, bcCheckType)
	noesis.setHandlerLoadModel(handle, bcLoadModel)
	return 1


# Check file type

def bcCheckType(data):
	bs = NoeBitStream(data)
	file_id1 = bs.readUInt()

	if file_id1 == 0x525350:
		return 1
	else:
		return 0


def bcLoadModel(data, mdlList):
	bs = NoeBitStream(data)
	ctx = rapi.rpgCreateContext()

	bones = ReadBones(bs)

	file_end = len(data)

	chunk_start = 0x8
	flag = True

	while flag:
		bs.seek(chunk_start)
		chunk_name = bs.readUInt()
		chunk_size = bs.readUInt()

		if chunk_name == 0x0048534d:					# only process MSH segments
			DrawMesh(bs, chunk_start)

		chunk_start += chunk_size + 8

		if chunk_start == file_end:
			flag = False


	try:
		mdl = rapi.rpgConstructModel()
	except:
		mdl = NoeModel()

	mdl.setBones(bones)
	mdlList.append(mdl)

	return 1


def DrawMesh(bs, offset):
	bs.seek(offset + 0x0c)
	text_len = bs.readUInt()
	model_name = bs.readBytes(text_len * 2).decode("utf-16")

	bs.readUShort()
	vert_type = bs.readUByte()
	bs.readBytes(11)
	vert_count = bs.readUInt()
	tri_count = bs.readUInt()
	vert_start = bs.tell() + 0x20

	vertices = bytearray(vert_count * 12)
	normals = bytearray(vert_count * 12)
	uvs = bytearray(vert_count * 8)
	bone_idx = bytearray(vert_count * 16)
	bone_wgt = bytearray(vert_count * 16)

	bs.seek(vert_start)

	for v in range(vert_count):

		if vert_type == 0x11:
			vx, vz, vy, nx, ny, nz, uvx, uvy = bs.read("<8f")

		elif vert_type == 0x13:
			vx, vz, vy, nx, ny, nz, unk1, uvx, uvy = bs.read("<9f")

		elif vert_type == 0x17:
			vx, vz, vy, nx, ny, nz, unk1, unk2, uvx, uvy = bs.read("<10f")

		else:
			print("Unknown vertex type: ", hex(vert_type))
			return 0

		count1 = bs.readUInt()

		for b in range(count1):
			temp_idx = bs.readUInt()
			temp_weight = bs.readFloat()
			struct.pack_into("<I", bone_idx, (v * 16) + (b * 4), temp_idx)
			struct.pack_into("<f", bone_wgt, (v * 16) + (b * 4), temp_weight)

		struct.pack_into("<fff", vertices, v * 12, vx, vz, vy)
		struct.pack_into("<fff", normals, v * 12, nx, ny, nz)
		struct.pack_into("<ff", uvs, v * 8, uvx, uvy)

	rapi.rpgBindPositionBuffer(vertices, noesis.RPGEODATA_FLOAT, 12)
	rapi.rpgBindNormalBuffer(normals, noesis.RPGEODATA_FLOAT, 12)
	rapi.rpgBindUV1Buffer(uvs, noesis.RPGEODATA_FLOAT, 8)
	rapi.rpgBindBoneIndexBuffer(bone_idx, noesis.RPGEODATA_UINT, 16, 4)
	rapi.rpgBindBoneWeightBuffer(bone_wgt, noesis.RPGEODATA_FLOAT, 16, 4)

	faces = bs.readBytes(tri_count * 6)
	text_len = bs.readUInt()

	rapi.rpgSetName(model_name)
	rapi.rpgCommitTriangles(faces, noesis.RPGEODATA_USHORT, tri_count * 3, noesis.RPGEO_TRIANGLE)

	return 1


# Load skeleton data file if it exists in the same folder

def ReadBones(bs):
	curr_folder = rapi.getDirForFilePath(rapi.getInputName()).lower()
	curr_file = rapi.getLocalFileName(rapi.getInputName()).lower()
	skel_name = curr_file.replace(".skn", "_skeleton.skl")
	skel_exists = rapi.checkFileExists(curr_folder + skel_name)

	bones = []

	if skel_exists:
		sk = NoeBitStream(rapi.loadIntoByteArray(curr_folder + skel_name))

		sk.seek(0x14)
		bone_count = sk.readUInt()
		sk.readUInt()

		for b in range(bone_count):
			name_len = sk.readUInt()
			bone_name = sk.readBytes(name_len * 2).decode("utf-16")
			sk.readUShort()
			parent_id = sk.readInt()

			pos = sk.read("3f")
			rot = NoeQuat.fromBytes(sk.readBytes(0x10))
			sk.seek(0x1c, 1)
			matrix = rot.toMat43()
			matrix[3] = pos
			bones.append(NoeBone(b, bone_name, matrix, None, parent_id))

		bones = rapi.multiplyBones(bones)

	else:
		print("No skeleton file found for this mesh.")

	return bones



