Here are three bms script files I have made for UFC2009 for Xbox 360 and the files I know they will work on.

UFC2009_PAC.bms - PAC Files and Uncompressed TEX Files

UFC2009_TEX.bms - Compressed TEX Files (If a TEX file has an error extracting, the TEX file is Uncompressed, so use UFC2009_PAC.bms instead)

When using the UFC2009_TEX.bms script, you must extract into the same folder that the TEX file is located, at least for now.

UFC2009_YMX.bms - YMX Files (Extracted as a *.yobj file, do not know the format yet)