import newGameLib
from newGameLib import *
import Blender	

def faceuv(mesh,UVList,UVIDList,faceList,matIDList):
	for m in range(0,len(matIDList)): 
		face=None
		if len(faceList[m])==3:
			if 	faceList[m][0]==faceList[m][1] or\
				faceList[m][0]==faceList[m][2] or\
				faceList[m][1]==faceList[m][2]:
				print faceList[m]
			else:	
				if UVIDList[m] is not None:
					uv0 = Vector(UVList[UVIDList[m][0]])
					uv1 = Vector(UVList[UVIDList[m][1]])
					uv2 = Vector(UVList[UVIDList[m][2]])
					mesh.faceUVList.append([uv0, uv1, uv2])
				else:
					mesh.faceUVList.append(None)	
				face=faceList[m]
				mesh.faceList.append(face)
				
		if len(faceList[m])==4:
			if 	faceList[m][0]==faceList[m][1] or\
				faceList[m][0]==faceList[m][2] or\
				faceList[m][0]==faceList[m][3] or\
				faceList[m][1]==faceList[m][2] or\
				faceList[m][1]==faceList[m][3] or\
				faceList[m][2]==faceList[m][3]:
				print faceList[m]
			else:	
				if UVIDList[m] is not None:
					uv0 = Vector(UVList[UVIDList[m][0]])
					uv1 = Vector(UVList[UVIDList[m][1]])
					uv2 = Vector(UVList[UVIDList[m][2]])
					uv3 = Vector(UVList[UVIDList[m][3]])
					mesh.faceUVList.append([uv0, uv1, uv2,uv3])
				else:
					mesh.faceUVList.append(None)	
				face=faceList[m]
				mesh.faceList.append(face)
				
		if face is not None:
			mesh.matIDList.append(matIDList[m])	
		"""if UVIDList[m]==None:
			mesh.faceUVList.append(None)
			print UVIDList[m]
		else:	
			if len(UVIDList[m])==3:
				if 	faceList[m][0]==faceList[m][1] or\
					faceList[m][0]==faceList[m][2] or\
					faceList[m][1]==faceList[m][2]:
					print faceList[m]
				if 	UVIDList[m][0]==UVIDList[m][1] or\
					UVIDList[m][0]==UVIDList[m][2] or\
					UVIDList[m][1]==UVIDList[m][2]:
					mesh.faceUVList.append(None) 
					
				else:
					uv0 = Vector(UVList[UVIDList[m][0]])
					uv1 = Vector(UVList[UVIDList[m][1]])
					uv2 = Vector(UVList[UVIDList[m][2]])
					mesh.faceUVList.append([uv0, uv1, uv2])
			if len(UVIDList[m])==4:
				if 	UVIDList[m][0]==UVIDList[m][1] or\
					UVIDList[m][0]==UVIDList[m][2] or\
					UVIDList[m][0]==UVIDList[m][3] or\
					UVIDList[m][1]==UVIDList[m][2] or\
					UVIDList[m][1]==UVIDList[m][3] or\
					UVIDList[m][2]==UVIDList[m][3]:
					mesh.faceUVList.append(None) 
				else:
					uv0 = Vector(UVList[UVIDList[m][0]])
					uv1 = Vector(UVList[UVIDList[m][1]])
					uv2 = Vector(UVList[UVIDList[m][2]])
					uv3 = Vector(UVList[UVIDList[m][3]])
					mesh.faceUVList.append([uv0, uv1, uv2,uv3])
		mesh.matIDList.append(matIDList[m])"""


def binParser(filename,g):
	#g.logOpen()
	name=g.word(12);print name
	
	skeleton=Skeleton()
	skeleton.draw()
	mesh=Mesh()
	mesh.BINDSKELETON=skeleton.name
	if name=='Three.js 003':
		UVList=[]
		UVIDList=[]	
		v0=g.i(13);print 'v0=',v0
		vertPosList=[]
		faceList=[]
		vertUVList=[]
		matIDList=[]
		mesh.WARNING=True
		for m in range(v0[2]):
			mesh.vertPosList.append(g.f(3))
		print 'vertex count=',v0[2]
		print 'uv count=',v0[4]
		print 'triangles count=',v0[8]
		print 'quad count=',v0[12]  
		if v0[3]!=0:
				
			if v0[4]!=0:
				print 'type 1'
				g.B(v0[3]*3)
				g.seekpad(4)
				for m in range(v0[4]):UVList.append([g.f(1)[0],1-g.f(1)[0]])
				for m in range(v0[6]):faceList.append(g.i(3))
				for m in range(v0[6]):UVIDList.append(None)
				for m in range(v0[6]):g.i(3)
				#for m in range(v0[6]):UVIDList.append(g.i(3))
				for m in range(v0[6]):matIDList.append(g.H(1)[0])
				g.seekpad(4)
					
				for m in range(v0[8]):faceList.append(g.i(3))
				for m in range(v0[8]):g.i(3)
				for m in range(v0[8]):UVIDList.append(g.i(3))
				for m in range(v0[8]):matIDList.append(g.H(1)[0])
				g.seekpad(4)
				for m in range(v0[10]):faceList.append(g.i(4))
				for m in range(v0[10]):g.i(4)
				for m in range(v0[10]):UVIDList.append(None)
				for m in range(v0[10]):matIDList.append(g.H(1)[0])
				g.seekpad(4)
				for m in range(v0[12]):faceList.append(g.i(4))
				for m in range(v0[12]):g.i(4)
				for m in range(v0[12]):UVIDList.append(g.i(4))
				for m in range(v0[12]):matIDList.append(g.H(1)[0])
				g.seekpad(4)
				print g.tell()
				if len(UVIDList)>0:faceuv(mesh,UVList,UVIDList,faceList,matIDList)
				
			if v0[4]==0 and v0[5]==0:
				print 'type 2'	  
				for m in range(v0[3]):B(3)
				g.seekpad(4)
				for m in range(v0[6]):faceslist.append(g.i(3))  
				for m in range(v0[6]):g.i(3)
				#quads				  
				for m in range(v0[12]):faceList.append(g.i(4))
				if len(UVIDList)>0:faceuv(mesh,UVList,UVIDList,faceList,matIDList)
				else:mesh.faceList=faceList
			
		if v0[3]==0 and v0[4]==0 and v0[5]!=0:
			print 'type 3'  
			for m in range(v0[5]):mesh.faceList.append(g.i(3))
			for m in range(v0[5]):matIDList.append(g.H(1)[0])
			g.seekpad(4)					
			for m in range(v0[9]):mesh.faceList.append(g.i(4))
			for m in range(v0[9]):matIDList.append(g.H(1)[0])
			g.seekpad(4)
			
		if v0[3]==0 and v0[4]==0 and v0[5]==0:
			print 'type 4'  
			for m in range(v0[9]):mesh.faceList.append(g.i(4))
			
			
		if v0[3]==0 and v0[4]!=0 and v0[5]==0:
			print 'type 5'
			for m in range(v0[4]):UVList.append([g.f(1)[0],1-g.f(1)[0]])
			for m in range(v0[7]):faceList.append(g.i(3))
			for m in range(v0[7]):UVIDList.append(g.i(3))
			for m in range(v0[7]):matIDList.append(g.H(1)[0])
			g.seekpad(4)
			for m in range(v0[9]):faceList.append(g.i(4))
			for m in range(v0[9]):UVIDList.append(None)
			for m in range(v0[9]):matIDList.append(g.H(1)[0])
			g.seekpad(4)				
			for m in range(v0[11]):faceList.append(g.i(4))
			for m in range(v0[11]):UVIDList.append(g.i(4))
			for m in range(v0[11]):matIDList.append(g.H(1)[0])
			g.seekpad(4)
			if len(UVIDList)>0:
				faceuv(mesh,UVList,UVIDList,faceList,matIDList)
			
			
		if v0[3]==0 and v0[4]!=0 and v0[5]!=0:
			print 'type 6'
			for m in range(v0[4]):UVList.append([g.f(1)[0],1-g.f(1)[0]])
				
			for m in range(v0[5]):faceList.append(g.i(3))
			for m in range(v0[5]):UVIDList.append(None)
			for m in range(v0[5]):matIDList.append(g.H(1)[0])
			g.seekpad(4)
			for m in range(v0[7]):faceList.append(g.i(3))
			for m in range(v0[7]):UVIDList.append(g.i(3))
			for m in range(v0[7]):matIDList.append(g.H(1)[0])
			g.seekpad(4)	
			for m in range(v0[9]):faceList.append(g.i(4))
			for m in range(v0[9]):UVIDList.append(None)
			for m in range(v0[9]):matIDList.append(g.H(1)[0])
			g.seekpad(4)				
			for m in range(v0[11]):faceList.append(g.i(4))
			for m in range(v0[11]):UVIDList.append(g.i(4))
			for m in range(v0[11]):matIDList.append(g.H(1)[0])
			if len(UVIDList)>0:
				faceuv(mesh,UVList,UVIDList,faceList,matIDList)
	return mesh 
	#g.logClose()  
	print g.tell()	



	
def dataFromLine(line,type):
	data=None
	lineStrip=line.strip()
	lineClear=lineStrip.replace(',',' ')
	lineSplit=lineClear.split()
	if type=='int':
		Len=len(lineSplit)
		if Len==1:
			data=map(int,lineSplit)[0]
		if Len>1:   
			data=map(int,lineSplit)
	if type=='ch':
		Len=len(lineSplit)
		if Len==1:
			data=lineSplit[0]
		if Len>1:   
			data=lineSplit
	return data 
		

def yamlParser(filename,g): 
	global model
	model=Model(filename)
	#model.filename=filename
	yaml=Yaml()
	yaml.input=g
	yaml.keyList=[['[',']'],['{','}'],['<','>']]
	rootNode=yaml.rootNode()
	
	
	#images
	imageList={}
	for child in rootNode.children:
		for child in child.children:
			dataList=child.dataL.split('\x0a')
			dataName=dataList[-1].split('"')[1]
			if dataName=='textures':
				for child in child.children:
					data=child.dataU
					
					#print child.values(data)
					
					
					dataList=child.dataU.split('\x0a')
					imageFile=None
					imageID=None
					for data in dataList:
						if ':'in data:
							dataName=data.split('"')[1]
							if dataName=='url':
								imageFile=data.split('"')[3]
								sys=Sys(imageFile)
								imagePath=g.dirname+os.sep+sys.base+'.'+sys.ext
							if dataName=='id':
								imageID=data.split(':')[1].split(',')[0].strip()
					#print imageFile
					#print 'imageID:',imageID
					imageList[imageID]=imagePath	
									
		
	#textures
	textureList={}
	for child in rootNode.children:
		for child in child.children:
			dataList=child.dataL.split('\x0a')
			dataName=dataList[-1].split('"')[1]
			if dataName=='texture_assignments':
				for child in child.children:
					data=child.dataU
					dataList=child.dataU.split('\x0a')
					textureType=None
					textureID=None
					imageID=None
					for data in dataList:
						if ':'in data:
							dataName=data.split('"')[1]
							if dataName=='texture_type':
								textureType=data.split('"')[3]
							if dataName=='texture_id':
								imageID=data.split(':')[1].split(',')[0].strip()
							if dataName=='id':
								textureID=data.split(':')[1].split(',')[0].strip()
					textureList[textureID]=[imageList[imageID],textureType]
												
								
	
	
	#materials  
	materialList={}
	matList=[]												  
					
					
	for child in rootNode.children:
		for child in child.children:
			dataList=child.dataL.split('\x0a')
			dataName=dataList[-1].split('"')[1]
			if dataName=='materials':
				for child in child.children:
					#data
					data=child.dataU
					dataList=child.dataU.split('\x0a')
					material=None   
					materialID=None			 
					for data in dataList:
						#print data
						if ':'in data:
							dataName=data.split('"')[1]
							if dataName=='id':
								materialID=data.split(':')[1].split(',')[0]
								#print 'matID:',materialID		  
					#children   
					#print 'mat'
					#mat=Mat()
					matList.append(None)	
					#newMatList.append(mat)
					materialList[materialID]=Mat()
					#materialList[materialID]['index']=index
					#materialList[materialID]['textures']=[]
					material=materialList[materialID]
					#material.ZTRANS=True
					for child in child.children:
						dataList=child.dataL.split('\x0a')
						dataName=dataList[-1].split('"')[1]
						#print dataName
						if dataName=='texture_assignment_ids':
							data=child.dataU
							dataList=data.split('\x0a')
							for data in dataList:
								ID=dataFromLine(data,'ch')
								#print int(data.replace(',',''))
								if ID is not None:
									texture=textureList[ID]
									#material['textures'].append(textureList[ID])
									if texture[1]=='diff':
										material.diffuse=texture[0]
									if texture[1]=='spec':
										material.specular=texture[0]
									if texture[1]=='norm':
										material.normal=texture[0]
	for child in rootNode.children:
		for child in child.children:
			dataList=child.dataL.split('\x0a')
			dataName=dataList[-1].split('"')[1]
			if dataName=='material_assignments':
				for child in child.children:
					data=child.dataU
					dataList=child.dataU.split('\x0a')
					index=None
					materialID=None 
					mat=Mat()
					#mat.ZTRANS=True
					for data in dataList:
						if ':'in data:
							dataName=data.split('"')[1]
							if dataName=='index':
								index=data.split(':')[1].split(',')[0]
							if dataName=='material_id':
								materialID=data.split(':')[1].split(',')[0]
					material=materialList[materialID]
					matList[int(index)]=material
								
															
								
	#model						  
	for child in rootNode.children:
		for child in child.children:
			dataList=child.dataL.split('\x0a')
			dataName=dataList[-1].split('"')[1]
			if dataName=='viewer_model':
				data=child.dataU
				dataList=child.dataU.split('\x0a')
				mesh=None
				for data in dataList:
					if ':'in data:
						dataName=data.split('"')[1]
						if dataName=='base_url':
							modelFile=data.split('"')[3]
							sys=Sys(modelFile)
							modelPath=g.dirname+os.sep+sys.base+'.p3d.r48.bin'
							print modelPath
							file=open(modelPath,'rb')
							g=BinaryReader(file)
							mesh=binParser(modelPath,g)
							model.meshList.append(mesh)
							mesh.matList=matList
							#if len(matList)>=16:
							mesh.SPLIT=True
							#mesh.draw()
							file.close()
				for child in child.children:
					dataList=child.dataL.split('\x0a')
					dataName=dataList[-1].split('"')[1]
					#print dataName
					if dataName=='material_assignment_ids':
						data=child.dataU
						dataList=data.split('\x0a')
						for data in dataList:
							print dataFromLine(data,'int')
							#print int(data.replace(',',''))
					
	model.getMat()
	#setBox([1,1,0,-1,-1,2],model.meshList)
	model.draw()		
	model.setMat()			
								
			
	
			
	
def Parser(filename):
	#filename=input.filename
	print
	print filename
	print
	ext=filename.split('.')[-1].lower()
	
	
	if ext=='bin':
		file=open(filename,'rb')
		g=BinaryReader(file)
		binParser(filename,g)
		file.close()
		
	if ext=='htm':
		file=open(filename.split('.htm')[0],'rb')
		g=BinaryReader(file)
		yamlParser(filename,g)
		file.close()
		
	if ext=='txt':
		file=open(filename.split('.htm')[0],'rb')
		g=BinaryReader(file)
		yamlParser(filename,g)
		file.close()
		
	
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
 
	
Blender.Window.FileSelector(Parser,'import','P3D.IN files: *.htm') 
	