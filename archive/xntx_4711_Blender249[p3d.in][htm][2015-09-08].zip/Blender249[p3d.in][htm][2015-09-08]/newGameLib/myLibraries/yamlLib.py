
class Node():
	def __init__(self):
		self.name=None
		self.offset=None
		self.children=[]
		self.dataL=''
		self.dataU=''
	def values(self,data):
		lines=data.split('\x0a')
		list={}
		for line in lines:
			lineStrip=line.strip().replace(',',' ')
			
			if len(lineStrip)>0:
				if ':' in lineStrip:
					lineSplit=line.split(':')
					if '"' in lineSplit[0]:
						key=lineSplit[0].split('"')[1]
						print 'key',key
					if '"' in lineSplit[1]:
						data=lineSplit[1].split('"')[1]
						print 'data',data
						
						
			
		
	

	
class Yaml():
	def __init__(self):
		self.input=None	
		self.keyList=[]
		self.fileKeyList=[]
		self.keyID=0
		self.txt=None
		self.LOG=False
	def logOpen(self):
		self.txt=open(self.input.inputFile.name+'.log','w')
	def logClose(self):
		self.txt.close()
	
	def tree(self,parentNode,n):
		n+=4
		while(True):
			key=self.fileKeyList[self.keyID]
			print '-'*n,key
			if self.LOG==True:
				self.txt.write(' '*n+str(key)+'\n')
			self.keyID+=1
			if key[2]=='o':
				node=Node()	
				node.offset=key[0]			
				parentNode.children.append(node)
				if self.keyID-2<0:
					self.input.seek(0)
					data=self.input.read(self.fileKeyList[self.keyID-1][0]-1)
				else:
					self.input.seek(self.fileKeyList[self.keyID-2][0]+1)
					data=self.input.read(self.fileKeyList[self.keyID-1][0]-self.fileKeyList[self.keyID-2][0]-1)
				#data=data.split('\x0a')	
				
				parentNode.dataU+=data
				node.dataL=data	
				
				
				self.tree(node,n)
			if key[2]=='c':
				self.input.seek(self.fileKeyList[self.keyID-2][0]+1)
				data=self.input.read(self.fileKeyList[self.keyID-1][0]-self.fileKeyList[self.keyID-2][0]-1)	
				#data=data.split('\x0a')	
				parentNode.dataU+=data
				break
			if self.keyID>=len(self.fileKeyList):break
			
	def rootNode(self):
		if self.LOG==True:self.logOpen()
		rootNode=None
		if self.input is not None:
			for charID in range(self.input.fileSize()):
				char=self.input.read(1)
				for keyID in range(len(self.keyList)):
					keyOpen=self.keyList[keyID][0]
					keyClose=self.keyList[keyID][1]
					if keyOpen==char:
						if self.LOG==True:self.txt.write(str(charID)+':'+keyOpen+'\n')
						self.fileKeyList.append([charID,keyOpen,'o'])
					if keyClose==char:
						#print charID,keyClose
						if self.LOG==True:self.txt.write(str(charID)+':'+keyClose+'\n')
						self.fileKeyList.append([charID,keyClose,'c'])
			rootNode=Node()
			if len(self.fileKeyList)>0:
				n=0
				self.tree(rootNode,n)
					
					
				
		else:
			return None	
		if self.LOG==True:self.logClose()
		return rootNode
	