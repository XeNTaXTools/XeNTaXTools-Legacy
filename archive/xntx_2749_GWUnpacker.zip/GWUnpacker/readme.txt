Hi.

This stuff will enable you to lurk around a bit in your guild wars datafile.
It's two command line programs so if you don't know how to use one wait around
until someone builds a gui around this.

The decompressor basically dumps files from your gw.dat, and the converter
can create png files from atex files.

Source code included, altho I didn't feel like cleaning up the atex converter
and that one misses some stuff which I won't release to the public. (Some
generic codebase stuff like file finding ect)

The decompressor looks into each file, tries to determine what it is and sorts
the results in a few directories. Gw.dat doesn't contain any filenames so don't
ask for them :)

The image converter can accept wildcards in the commandline so you won't have to
convert each image one by one.

Have fun!

BoyC

ah, and you can reach me on the xentax.com forums under the name BoyC