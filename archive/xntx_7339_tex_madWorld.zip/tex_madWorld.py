from inc_noesis import *
import noesis
import rapi
import os
import lib_zq_nintendo_tex as nintex


class TextureInfo:
	def __init__(self):
		self.width = -1
		self.height = -1
		self.format = -1
		self.offset = -1

def registerNoesisTypes():
	handle = noesis.register("madworld textures", ".datMT")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
	return 1

def noepyCheckType(data):
	bs = NoeBitStream(data, NOE_BIGENDIAN)
	return 1

def noepyLoadRGBA(data, texList):
	bs = NoeBitStream(data, NOE_BIGENDIAN)
	bs.seek(0x24)
	print(bs.tell())
	bs.seek(bs.readUInt())
	
	checkPoint = bs.tell()
	bs.readUInt()
	texCount = bs.readUInt()
	texInfoOffset = bs.readUInt()
	texHeaderOffsets = []
	texInfos = []
	
	bs.seek(texInfoOffset + checkPoint)
	for j in range(texCount):
		texHeaderOffsets.append(bs.readUInt())
		bs.readUInt()
	
	for j in range(texCount):
		bs.seek(texHeaderOffsets[j] + checkPoint)
		texInfo = TextureInfo()
		texInfo.width, texInfo.height, texInfo.format, texInfo.offset = bs.readUShort(), bs.readUShort(), bs.readUInt(), bs.readUInt()
		texInfos.append(texInfo)
	
	for i, info in enumerate(texInfos):
		bs.seek(info.offset + checkPoint)
		tex = nintex.readTexture(bs, info.width, info.height, info.format)
		tex.name = str(i)
		texList.append(tex)
	return len(texList)
