HPK Extractor v 0.1b
Created by Crypton
-------------------------

Notes:

Archive structure is pretty complex,its not encrypted but its using a few tricks how to fool hackers :)

Most of files are compressed with ZLIB(like Textures and XML) but every file may be splitted into 32KB chunks (offsets are in ZLIB Header),few files have "ZLIB" tag,
but they are not compressed, usually because of small input buffer (for example chunk with 24 bytes is not compressed,but directly saved into file).
You can also find a relative or absolute offsets of files or directories,which are also incorrect.

Game using also in few files a LZSS compression which is not supported in this Extractor ( I cannot find a correct library which will decompress LZSS files(I know structure of "LZSS" filles)).
Game with work with compressed and decompressed files too,but if you will using decompressed files then you may notice a slight decrease of game performance.

Game will work with extracted archives, only one thing is need to be done to work:
Move all HPK archives from subfolders into main folder (where is exe located) then extract all archives,delete all hpk archives and folders Local and Packs.

Thats all.

-------------------------
Usage:

HPKExtractor.exe [options] -hpk "YourFile.hpk"
Options are: "-zlib" - This will decompress all ZLIB files.

