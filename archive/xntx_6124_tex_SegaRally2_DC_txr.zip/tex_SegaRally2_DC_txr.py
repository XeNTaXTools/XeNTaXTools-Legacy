from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Sega Rally 2 [Dreamcast]", ".txr")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    if noeStrFromBytes(bs.readBytes(4)) != "RTEX": return 0
    return 1
    
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.seek(0x14, NOESEEK_ABS)
    imgWidth = bs.readUInt()            
    print(imgWidth, ": imgWidth")
    datasize = bs.readUInt()
    imgHeight = (datasize // imgWidth) // 2           
    print(imgHeight, ": imgHeight")
    bs.seek(0x1000, NOESEEK_ABS)
    data = bs.readBytes(datasize)      
    #R5G6B5
    data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "r5 g6 b5 a0")
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, noesis.NOESISTEX_RGBA32))
    return 1