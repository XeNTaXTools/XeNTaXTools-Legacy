/*
  stdafx.h
  Precompiled header
*/

#pragma once

// Defines for the includes
#define WIN32_LEAN_AND_MEAN
#define VC_EXTRALEAN
#define STRICT

// The includes
#include <windows.h>
#include <objidl.h>
#include <shlobj.h>
#include <assert.h>
#include <direct.h>
#include <io.h>
#include <string>
#include <vector>
#include <fstream>
#include "unzip.h"
#include "jni.h"
