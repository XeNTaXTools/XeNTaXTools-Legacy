/*
  RPMCommon.h
  Common structures and defines for Rahly's Plugin Manager; mirrors Common.pas
*/

#pragma once

// Typedefs
typedef long longbool;

// Interface version
#define InterfaceVersionMajor 1
#define InterfaceVersionMinor 0

// Support flags
enum
{
	SUPPORTFLAG_CREATE             = 0x0000000000000001,
	SUPPORTFLAG_IMPORT             = 0x0000000000000002,
	SUPPORTFLAG_EXPORT             = 0x0000000000000004,
	SUPPORTFLAG_DELETE             = 0x0000000000000008,
	SUPPORTFLAG_REPLACE            = 0x0000000000000010,
	SUPPORTFLAG_BYINDEX            = 0x0000000000000020,
	SUPPORTFLAG_BYNAME             = 0x0000000000000040,
	SUPPORTFLAG_HANDLEISTREAM      = 0x0000000000000080,
	SUPPORTFLAG_HANDLEFILE         = 0x0000000000000100,
	SUPPORTFLAG_TESTARCHIVE        = 0x0000000000000200,
	SUPPORTFLAG_EXPORTNAMEWILD     = 0x0000000000000400,
	SUPPORTFLAG_IMPORTNAMEWILD     = 0x0000000000000800
};

typedef unsigned long long mpSupportFlags;

// Option types
enum mpOptionType
{
	OPTIONTYPE_CREATE              = 0x00000001,
	OPTIONTYPE_EXPORT              = 0x00000002,
	OPTIONTYPE_IMPORT              = 0x00000003,
	OPTIONTYPE_FILEINFO            = 0x00000004,
	OPTIONTYPE_INVALIDFILENAMECHAR = 0x00000005
};

// Open flags
enum
{
	OPENFLAG_CREATENEW             = 0x00000001,
	OPENFLAG_OPENALWAYS            = 0x00000002,
	OPENFLAG_FOREXPORT             = 0x00000004,
	OPENFLAG_FORIMPORT             = 0x00000008
};

typedef unsigned long mpOpenFlags;

// Find handle
typedef void* mpFindHandle;

// Archive handle
typedef void* mpArchiveHandle;

// Error messages
// TODO: When compiling for 64-bit make sure this is an unsigned long long
enum mpErrorCode
{
	pERROR_OK                      = 0x00000000,
	pERROR_INVALID_PARM_1          = 0x00000001,
	pERROR_INVALID_PARM_2          = 0x00000002,
	pERROR_INVALID_PARM_3          = 0x00000003,
	pERROR_INVALID_PARM_4          = 0x00000004,
	pERROR_INVALID_PARM_5          = 0x00000005,
	pERROR_INVALID_PARM_6          = 0x00000006,
	pERROR_INVALID_PARM_7          = 0x00000007,
	pERROR_INVALID_PARM_8          = 0x00000008,
	pERROR_INVALID_PARM_9          = 0x00000009,
	pERROR_FILE_NOT_EXISTS         = 0x0000000A,
	pERROR_FILE_CANT_OPEN          = 0x0000000B,
	pERROR_INVALID_FORMAT          = 0x0000000C,
	pERROR_STREAM_READ             = 0x0000000D,
	pERROR_INVALID_HANDLE          = 0x0000000E,
	pERROR_INVALID_INDEX           = 0x0000000F,
	pERROR_CREATE_ERROR            = 0x00000010,
	pERROR_ARCHIVE_READ_ERROR      = 0x00000011,
	pERROR_NO_MATCHES              = 0x00000012,
	pERROR_ARCHIVE_CLOSED          = 0x00000013,
	pERROR_INVALID_OPTION          = 0x00000014,
	pERROR_WILDCARDS_NOT_ALLOWED   = 0x00000015,
	pERROR_INVALID_ARCHIVE         = 0x00000016,
	pERROR_FILE_EXISTS             = 0x00000017,
	pERROR_UNSUPPORTED             = 0x00000018,
	pERROR_SPECIFICPLUGIN          = 0x80000000,
};

// Plugin Manager Structures
#pragma pack(push, 1)

struct mpPluginInfo
{
	unsigned long Size;
	char* Name;
	char* Author;
	char* Website;
	char* Email;
	long Major;
	long Minor;
};

struct mpArchiveInfo
{
	unsigned long Size;
	char* FileMask;
	char* GameName;
	mpSupportFlags Flags;
};

#pragma pack(pop)

// A forward-declaration of this is required
struct IStream;

// Declarations for Plugin Functions
mpErrorCode _stdcall mpGetLastError();
void _stdcall mpSetLastError(mpErrorCode ErrorCode);
char* _stdcall mpGetErrorText(mpErrorCode ErrorCode);
longbool _stdcall mpGetInterfaceVersion(long& Major, long& Minor);
longbool _stdcall mpGetPluginInfo(mpPluginInfo& Info);
unsigned long _stdcall mpGetFormatCount();
longbool _stdcall mpGetFormatInfo(unsigned long FormatIndex, mpArchiveInfo& FormatInfo);
char* _stdcall mpGetOptions(unsigned long FormatIndex, mpOptionType OptionType);
longbool _stdcall mpSetOption(unsigned long FormatIndex, mpOptionType OptionType, char* Name, char* Value);
longbool _stdcall mpIsFileAnArchive(unsigned long FormatIndex, char* Filename);
longbool _stdcall mpIsStreamAnArchive(unsigned long FormatIndex, IStream* Stream);
longbool _stdcall mpOpenArchive(mpArchiveHandle& ArchiveHandle, unsigned long FormatIndex, char* ArchiveName, mpOpenFlags Flags);
longbool _stdcall mpOpenArchiveBindStream(mpArchiveHandle& ArchiveHandle, unsigned long FormatIndex, IStream& Stream, mpOpenFlags Flags);
longbool _stdcall mpCloseArchive(mpArchiveHandle ArchiveHandle);
unsigned long _stdcall mpIndexCount(mpArchiveHandle ArchiveHandle);
char* _stdcall mpIndexedInfo(mpArchiveHandle ArchiveHandle, unsigned long Index, char* Item);
mpFindHandle _stdcall mpFindFirstFile(mpArchiveHandle ArchiveHandle, char* FileMask);
char* _stdcall mpFindInfo(mpFindHandle FindHandle, char* Field);
longbool _stdcall mpFindNextFile(mpFindHandle FindHandle);
longbool _stdcall mpFindClose(mpFindHandle FindHandle);
longbool _stdcall mpExportFileByNameToFile(mpArchiveHandle ArchiveHandle, char* ArchiveFile, char* ExternalFile);
longbool _stdcall mpExportFileByIndexToFile(mpArchiveHandle ArchiveHandle, unsigned long FileIndex, char* ExternalFile);
longbool _stdcall mpExportFileByNameToStream(mpArchiveHandle ArchiveHandle, char* ArchiveFile, IStream& Stream);
longbool _stdcall mpExportFileByIndexToStream(mpArchiveHandle ArchiveHandle, unsigned long FileIndex, IStream& Stream);
longbool _stdcall mpImportFileFromFile(mpArchiveHandle ArchiveHandle, char* ArchiveFile, char* ExternalFile);
longbool _stdcall mpImportFileFromStream(mpArchiveHandle ArchiveHandle, char* ArchiveFile, IStream& Stream);
longbool _stdcall mpRemoveFileByName(mpArchiveHandle ArchiveHandle, char* Filename);
longbool _stdcall mpRemoveFileByIndex(mpArchiveHandle ArchiveHandle, unsigned long FileIndex);
