/*
  Archive.h
  A Game Extractor archive
*/

#pragma once

// Required headers
#include <map>
#include "Resource.h"

// Make sure we have the right JNI header
#ifndef JNI_VERSION_1_6
#error "Java/JNI 1.6 or higher is required!"
#endif

// A Game Extractor archive
class geArchive
{
public:
	// Constructors
	geArchive(JNIEnv* Env);
	geArchive(JNIEnv* Env, jobjectArray Resources);
	virtual ~geArchive();

	// General Methods
	virtual bool IsOkay() const;

	// Management
	virtual unsigned long GetResourceCount() const;
	virtual geResource GetResource(unsigned long Index) const;
	virtual geResource GetResource(const std::string& Name) const;
	//virtual void SetResource(unsigned long Index, const geResource& NewResource);

protected:
	// Typedefs
	typedef std::map<std::string, unsigned long> geNameIndexMap;

	// Helper Methods
	virtual bool CreateNameIndexMap();

	// Internal Variables
	JNIEnv* m_Env;
	jobjectArray m_Resources;
	geNameIndexMap m_NameIndexMap;
};
