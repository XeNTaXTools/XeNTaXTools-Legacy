/*
  Cache.cpp
  Cache for the plugin information
*/

#include "stdafx.h"
#include "Cache.h"

#define CACHE_SIGNATURE "GEPlugins Cache 1.0"

void WriteULong(std::ostream& Output, unsigned long Number)
{
	Output.write((char*)&Number, sizeof(unsigned long));
	return;
}

void WriteString(std::ostream& Output, const std::string& String)
{
	WriteULong(Output, (unsigned long)String.length());
	Output << String;
	return;
}

geCache::geCache()
{
	return;
}

geCache::geCache(const std::string& Filename)
{
	Load(Filename);
	return;
}

geCache::~geCache()
{
	return;
}

bool geCache::Load(const std::string& Filename)
{
	// TODO: Function Load
	return false;
}

bool geCache::Save(const std::string& Filename) const
{
	// Open the file
	std::ofstream Output;
	Output.open(Filename.c_str(), std::ios_base::out | std::ios_base::binary | std::ios_base::trunc);
	if(!Output.is_open())
	{
		return false;
	}

	// Write the signature
	Output.write(CACHE_SIGNATURE, sizeof(CACHE_SIGNATURE));

	// TODO: Function Save
	WriteULong(Output, GetCount());

	for(unsigned long i=0;i<GetCount();i++)
	{
		WriteString(Output, Get(i).Class);
		WriteString(Output, Get(i).GameName);
		WriteULong(Output, (unsigned long)Get(i).Extentions.size());
		for(std::vector<std::string>::const_iterator Iter=Get(i).Extentions.begin();Iter!=Get(i).Extentions.end();++Iter)
		{
			WriteString(Output, *Iter);
		}
	}
	return false;
}

unsigned long geCache::Add(const gePluginInfo& Info)
{
	m_Plugins.push_back(Info);
	m_Plugins.back().ExtentionList=GenerateExtentionList(m_Plugins.back().Extentions);
	m_Plugins.back().MexComDisplayString=m_Plugins.back().GameName+" [GE] ";
	return (unsigned long)m_Plugins.size()-1;
}

const geCache::gePluginInfo& geCache::Get(unsigned long Index) const
{
	assert(Index<GetCount());
	return m_Plugins[Index];
}

void geCache::Remove(unsigned long Index)
{
	assert(Index<GetCount());
	std::vector<gePluginInfo>::iterator Iter=m_Plugins.begin()+Index;
	m_Plugins.erase(Iter);
	return;
}

void geCache::Clear()
{
	m_Plugins.clear();
	return;
}

unsigned long geCache::GetCount() const
{
	return (unsigned long)m_Plugins.size();
}

std::string geCache::GenerateExtentionList(const std::vector<std::string>& Extentions) const
{
	std::string String;
	bool First=true;
	for(std::vector<std::string>::const_iterator Iter=Extentions.begin();Iter!=Extentions.end();++Iter)
	{
		if(!First)
		{
			String.append("; ");
		}
		else
		{
			First=false;
		}
		String.append("*.");
		String.append(*Iter);
	}
	return String;
}
