/*
  Initialization.h
  Performs the initialization for GEPlugins
*/

#pragma once

// Required headers
#include "RPMCommon.h"
#include "Cache.h"

// Make sure we have the right JNI header
#ifndef JNI_VERSION_1_6
#error "Java/JNI 1.6 or higher is required!"
#endif

// Internal Structures
struct geEnvironment
{
	geEnvironment() :
		LastError(pERROR_OK),
		Initialized(false),
		FlushCache(true),
		Cache(NULL),
		JvmBinaryHandle(NULL),
		Jvm(NULL),
		Env(NULL)
	{
	}

	// The last error code
	mpErrorCode LastError;

	// Initialization state
	bool Initialized;
	std::string JreBinary;
	std::string GEJarFilename;
	std::string GEPluginPath;
	std::string CacheFilename;
	bool FlushCache;
	geCache* Cache;

	// Java VM
	HMODULE JvmBinaryHandle;
	JavaVM* Jvm;
    JNIEnv* Env;
};

// Declarations for Helper Functions
bool InitializeEnvironment();
std::string FindJavaVM();
void UninitializeEnvironment();
bool InitializeJavaVM();
void RetrievePluginInfo(std::string PluginName, geCache& Cache);
bool IsFile(const std::string& Filename);
bool IsDirectory(const std::string& Path);
bool FindPlugins(const std::string& Path, std::vector<std::string>& ClassNames);
char* HeapString(const std::string& String);

// The environment
extern geEnvironment g_Env;
