/*
  Archive.h
  A Game Extractor archive resource
*/

#pragma once

// Required headers
#include "Resource.h"

// Make sure we have the right JNI header
#ifndef JNI_VERSION_1_6
#error "Java/JNI 1.6 or higher is required!"
#endif

// A Game Extractor archive resource
class geResource
{
public:
	// Constructors
	geResource(JNIEnv* Env);
	geResource(JNIEnv* Env, jobject Resource);
	virtual ~geResource();

	// General Methods
	virtual bool IsOkay() const;

	// Resource Methods
	virtual bool Extract(const std::string& OutputFilename) const;
	virtual unsigned long long GetOffset() const;
	virtual unsigned long long GetLength() const;
	virtual unsigned long long GetDecompressedLength() const;
	virtual std::string GetName() const;

protected:
	// Helper Methods
	virtual void GetResourceClass();

	// Internal Variables
	JNIEnv* m_Env;
	jobject m_Resource;
	jclass m_ResourceClass;
};
