/*
  GEPlugins.cpp
  Plugin for using Game Extractor Plugins with MexCom
*/

#include "stdafx.h"
#include "GEPlugins.h"
#include "Initialization.h"
#include "Cache.h"
#include "RPMCommon.h"
#include "Plugin.h"
#include "Archive.h"
#include "Resource.h"

// Make sure we have the right JNI header
#ifndef JNI_VERSION_1_6
#error "Java/JNI 1.6 or higher is required!"
#endif

// Debugging Macro
//#define IdentifyFunction() MessageBox(0, __FUNCTION__, "Identify Function", 0)

// Globals
//geEnvironment g_Env;

// Initialization
BOOL APIENTRY DllMain(HANDLE hModule, unsigned long ReasonForCall, void* lpReserved)
{
	switch(ReasonForCall)
	{
		case DLL_PROCESS_ATTACH:
			// It's not safe to do any major initialization in this function
			//MessageBox(NULL, "Attach", "GEPlugins", 0);
		break;
		case DLL_THREAD_ATTACH:
		break;
		case DLL_THREAD_DETACH:
		break;
		case DLL_PROCESS_DETACH:
			UninitializeEnvironment();
			//MessageBox(NULL, "Detach", "GEPlugins", 0);
		break;
	}
    return TRUE;
}

// Plugin Functions

mpErrorCode _stdcall mpGetLastError()
{
	return g_Env.LastError;
}

void _stdcall mpSetLastError(mpErrorCode ErrorCode)
{
	g_Env.LastError=ErrorCode;
	return;
}

char* _stdcall mpGetErrorText(mpErrorCode ErrorCode)
{
	// Get the error string if it's one of our errors
	/*switch(ErrorCode)
	{
	}*/
	return NULL;
}

longbool _stdcall mpGetInterfaceVersion(long& Major, long& Minor)
{
	// Make sure we're initialized
	if(!InitializeEnvironment())
	{
		return false;
	}

	// Set the version number
	Major=InterfaceVersionMajor;
	Minor=InterfaceVersionMinor;
	return true;
}

longbool _stdcall mpGetPluginInfo(mpPluginInfo& Info)
{
	// Make sure we're initialized
	if(!InitializeEnvironment())
	{
		return false;
	}

	// Make sure that this structure is the right size
	if(Info.Size!=sizeof(mpPluginInfo))
	{
		mpSetLastError(pERROR_INVALID_PARM_1);
		return false;
	}

	// Clear the data and reset it
	memset(&Info, 0, sizeof(mpPluginInfo));
	Info.Size=sizeof(mpPluginInfo);

	// Set the plugin information
	Info.Name="Game Extractor Plugin Loader";
	Info.Author="Zench";
	Info.Website="";
	Info.Email="";
	Info.Major=1;
	Info.Minor=0;
	return true;
}

unsigned long _stdcall mpGetFormatCount()
{
	// Make sure we're initialized
	if(!InitializeEnvironment())
	{
		return 0;
	}
	return g_Env.Cache->GetCount();
}

longbool _stdcall mpGetFormatInfo(unsigned long FormatIndex, mpArchiveInfo& FormatInfo)
{
	// Make sure we're initialized
	if(!InitializeEnvironment())
	{
		return false;
	}

	// Make sure the index is valid
	if(FormatIndex>=mpGetFormatCount())
	{
		mpSetLastError(pERROR_INVALID_INDEX);
		return false;
	}

	// Clear the data and reset it
	memset(&FormatInfo, 0, sizeof(mpArchiveInfo));
	FormatInfo.Size=sizeof(mpArchiveInfo);

	// Get the format info
	const geCache::gePluginInfo& Info=g_Env.Cache->Get(FormatIndex);
	FormatInfo.GameName=(char*)Info.MexComDisplayString.c_str();
	FormatInfo.FileMask=(char*)Info.ExtentionList.c_str();
	FormatInfo.Flags=SUPPORTFLAG_EXPORT | SUPPORTFLAG_BYNAME | SUPPORTFLAG_HANDLEFILE | \
		SUPPORTFLAG_TESTARCHIVE;
	return true;
}

char* _stdcall mpGetOptions(unsigned long FormatIndex, mpOptionType OptionType)
{
	// Make sure we're initialized
	if(!InitializeEnvironment())
	{
		return false;
	}

	// Make sure the index is valid
	if(FormatIndex>=mpGetFormatCount())
	{
		mpSetLastError(pERROR_INVALID_INDEX);
		return false;
	}

	// Get the options
	switch(OptionType)
	{
		case OPTIONTYPE_FILEINFO:
		return HeapString("FILENAME=STRING;FILESIZE=INT64;COMPRESSED=INT64;OFFSET=INT64");
	}
	return NULL;
}

longbool _stdcall mpSetOption(unsigned long FormatIndex, mpOptionType OptionType, char* Name, char* Value)
{
	__asm int 3;
	// TODO: Implement later
	mpSetLastError(pERROR_UNSUPPORTED);
	return false;
}

longbool _stdcall mpIsFileAnArchive(unsigned long FormatIndex, char* Filename)
{
	// Make sure we're initialized
	if(!InitializeEnvironment())
	{
		return false;
	}

	// Make sure the index is valid
	if(FormatIndex>=mpGetFormatCount())
	{
		mpSetLastError(pERROR_INVALID_INDEX);
		return false;
	}

	// Create a new plugin
	gePlugin Plugin(g_Env.Env, g_Env.Cache->Get(FormatIndex).Class);

	// Get the match rating
	int MatchRating;
	MatchRating=Plugin.GetMatchRating(std::string(Filename));
	if(MatchRating<26)
	{
		return false;
	}
	return true;
}

longbool _stdcall mpIsStreamAnArchive(unsigned long FormatIndex, IStream& Stream)
{
	__asm int 3;
	mpSetLastError(pERROR_UNSUPPORTED);
	return false;
}

longbool _stdcall mpOpenArchive(mpArchiveHandle& ArchiveHandle, unsigned long FormatIndex, char* ArchiveName, mpOpenFlags Flags)
{
	// Make sure we're initialized
	if(!InitializeEnvironment())
	{
		return false;
	}

	// Make sure the index is valid
	if(FormatIndex>=mpGetFormatCount())
	{
		mpSetLastError(pERROR_INVALID_INDEX);
		return false;
	}

	// Clear some values
	ArchiveHandle=NULL;

	// Check the flags
	if(Flags & OPENFLAG_CREATENEW)
	{
		// TODO: Creating a new archive is not supported
		return false;
	}
	if(Flags & OPENFLAG_FORIMPORT)
	{
		// TODO: Editing an existing archive is not supported
		return false;
	}

	// Load the archive
	if((Flags & OPENFLAG_OPENALWAYS) || (Flags & OPENFLAG_FOREXPORT))
	{
		// Create a new plugin
		gePlugin Plugin(g_Env.Env, g_Env.Cache->Get(FormatIndex).Class);

		// Read the archive
		geArchive* Archive;
		Archive=Plugin.Read(std::string(ArchiveName));
		if(!Archive)
		{
			MessageBox(0, "The archive could not be loaded.", "Error", MB_ICONSTOP);
			mpSetLastError(pERROR_ARCHIVE_READ_ERROR);
			return false;
		}

		// Set this as the archive
		ArchiveHandle=Archive;
	}
	return true;
}

longbool _stdcall mpOpenArchiveBindStream(mpArchiveHandle& ArchiveHandle, unsigned long FormatIndex, IStream* Stream, mpOpenFlags Flags)
{
	__asm int 3;
	mpSetLastError(pERROR_UNSUPPORTED);
	return false;
}

longbool _stdcall mpCloseArchive(mpArchiveHandle ArchiveHandle)
{
	// Make sure the archive handle is valid
	if(!ArchiveHandle)
	{
		mpSetLastError(pERROR_INVALID_HANDLE);
		return false;
	}

	// Cast the archive handle
	geArchive* Archive=(geArchive*)ArchiveHandle;
	if(!Archive)
	{
		mpSetLastError(pERROR_INVALID_HANDLE);
		return false;
	}

	// And delete it
	delete Archive;
	Archive=NULL;
	ArchiveHandle=NULL;
	return true;
}

unsigned long _stdcall mpIndexCount(mpArchiveHandle ArchiveHandle)
{
	// Make sure the archive handle is valid
	if(!ArchiveHandle)
	{
		mpSetLastError(pERROR_INVALID_HANDLE);
		return false;
	}

	// Cast the archive handle
	geArchive* Archive=(geArchive*)ArchiveHandle;
	if(!Archive)
	{
		return true;
	}

	// Return the number of resources
	return Archive->GetResourceCount();
}

char* _stdcall mpIndexedInfo(mpArchiveHandle ArchiveHandle, unsigned long Index, char* Item)
{
	// Make sure the archive handle is valid
	if(!ArchiveHandle)
	{
		mpSetLastError(pERROR_INVALID_HANDLE);
		return NULL;
	}

	// Cast the archive handle
	geArchive* Archive=(geArchive*)ArchiveHandle;
	if(!Archive)
	{
		mpSetLastError(pERROR_INVALID_HANDLE);
		return NULL;
	}

	// Make sure the index is in range
	if(Index>=Archive->GetResourceCount())
	{
		mpSetLastError(pERROR_INVALID_INDEX);
		return NULL;
	}

	// Switch based on what MexCom is requesting
	if(stricmp(Item, "Filename")==0)
	{
		return HeapString(Archive->GetResource(Index).GetName());
	}
	else if(stricmp(Item, "FileSize")==0)
	{
		// Get the file size and turn it into a string
		unsigned long long FileSize;
		char Buffer[64];
		FileSize=Archive->GetResource(Index).GetDecompressedLength();
		_snprintf(Buffer, sizeof(Buffer), "%I64u", FileSize);
		return HeapString(Buffer);
	}
	else if(stricmp(Item, "Compressed")==0)
	{
		// Get the file size and turn it into a string
		unsigned long long Compressed;
		char Buffer[64];
		Compressed=Archive->GetResource(Index).GetLength();
		_snprintf(Buffer, sizeof(Buffer), "%I64u", Compressed);
		return HeapString(Buffer);
	}
	else if(stricmp(Item, "Offset")==0)
	{
		// Get the file size and turn it into a string
		unsigned long long Offset;
		char Buffer[64];
		Offset=Archive->GetResource(Index).GetOffset();
		_snprintf(Buffer, sizeof(Buffer), "%I64u", Offset);
		return HeapString(Buffer);
	}
	return NULL;
}

// HACK: To combat a bug in MexCom where it passes the wrong value
mpFindData* g_FindData=NULL;

mpFindHandle _stdcall mpFindFirstFile(mpArchiveHandle ArchiveHandle, char* FileMask)
{
	// Make sure the archive handle is valid
	if(!ArchiveHandle)
	{
		mpSetLastError(pERROR_INVALID_HANDLE);
		return NULL;
	}

	// Cast the archive handle
	geArchive* Archive=(geArchive*)ArchiveHandle;
	if(!Archive)
	{
		mpSetLastError(pERROR_INVALID_HANDLE);
		return NULL;
	}

	// Make sure this is one that we can handle
	if(std::string(FileMask)!="*")
	{
		mpSetLastError(pERROR_NO_MATCHES);
		return NULL;
	}

	// Create the find data
	mpFindData* FindData;
	FindData=new mpFindData;
	FindData->Archive=Archive;
	FindData->FileMask=FileMask;
	FindData->CurrentPosition=0;

	// HACK: To combat a bug in MexCom where it passes the wrong value
	g_FindData=FindData;

	// TODO: Find the first one?
	return FindData;
}

char* _stdcall mpFindInfo(mpFindHandle FindHandle, char* Field)
{
	// Make sure the find handle is valid
	if(!FindHandle)
	{
		mpSetLastError(pERROR_INVALID_HANDLE);
		return false;
	}

	// HACK: To combat a bug in MexCom where it passes the wrong value
	FindHandle=g_FindData;

	// Cast the find handle
	mpFindData* FindData=(mpFindData*)FindHandle;
	if(!FindData)
	{
		mpSetLastError(pERROR_INVALID_HANDLE);
		return false;
	}

	// Use the index
	return mpIndexedInfo(FindData->Archive, FindData->CurrentPosition, Field);
}

longbool _stdcall mpFindNextFile(mpFindHandle FindHandle)
{
	// Make sure the find handle is valid
	if(!FindHandle)
	{
		mpSetLastError(pERROR_INVALID_HANDLE);
		return false;
	}

	// Cast the find handle
	mpFindData* FindData=(mpFindData*)FindHandle;
	if(!FindData)
	{
		mpSetLastError(pERROR_INVALID_HANDLE);
		return false;
	}

	// Find the next file
	unsigned long Total=FindData->Archive->GetResourceCount();
	bool Found=false;
	for(unsigned long i=FindData->CurrentPosition+1;i<Total;i++)
	{
		// TODO: Check to see if this is the one
		FindData->CurrentPosition=i;
		Found=true;
		break;
	}

	// Check if none were found
	if(!Found)
	{
		mpSetLastError(pERROR_NO_MATCHES);
		return false;
	}
	return true;
}

longbool _stdcall mpFindClose(mpFindHandle FindHandle)
{
	// Make sure the find handle is valid
	if(!FindHandle)
	{
		mpSetLastError(pERROR_INVALID_HANDLE);
		return false;
	}

	// Cast the find handle
	mpFindData* FindData=(mpFindData*)FindHandle;
	if(!FindData)
	{
		mpSetLastError(pERROR_INVALID_HANDLE);
		return false;
	}

	// Delete the find handle;
	delete FindData;
	FindData=NULL;
	FindHandle=NULL;

	// HACK: To combat a bug in MexCom where it passes the wrong value
	g_FindData=NULL;
	return true;
}

longbool _stdcall mpExportFileByNameToFile(mpArchiveHandle ArchiveHandle, char* ArchiveFile, char* ExternalFile)
{
	// Make sure the archive handle is valid
	if(!ArchiveHandle)
	{
		mpSetLastError(pERROR_INVALID_HANDLE);
		return false;
	}

	// Cast the archive handle
	geArchive* Archive=(geArchive*)ArchiveHandle;
	if(!Archive)
	{
		mpSetLastError(pERROR_INVALID_HANDLE);
		return false;
	}

	// Now export the file
	if(!Archive->GetResource(ArchiveFile).Extract(ExternalFile))
	{
		mpSetLastError(pERROR_ARCHIVE_READ_ERROR);
		return false;
	}
	return true;
}

longbool _stdcall mpExportFileByIndexToFile(mpArchiveHandle ArchiveHandle, unsigned long FileIndex, char* ExternalFile)
{
	// Make sure the archive handle is valid
	if(!ArchiveHandle)
	{
		mpSetLastError(pERROR_INVALID_HANDLE);
		return false;
	}

	// Cast the archive handle
	geArchive* Archive=(geArchive*)ArchiveHandle;
	if(!Archive)
	{
		mpSetLastError(pERROR_INVALID_HANDLE);
		return false;
	}

	// Make sure the index is in range
	if(FileIndex>=Archive->GetResourceCount())
	{
		mpSetLastError(pERROR_INVALID_INDEX);
		return false;
	}

	// Now export the file
	if(!Archive->GetResource(FileIndex).Extract(ExternalFile))
	{
		mpSetLastError(pERROR_ARCHIVE_READ_ERROR);
		return false;
	}
	return true;
}

longbool _stdcall mpExportFileByNameToStream(mpArchiveHandle ArchiveHandle, char* ArchiveFile, IStream& Stream)
{
	__asm int 3;
	mpSetLastError(pERROR_UNSUPPORTED);
	return false;
}

longbool _stdcall mpExportFileByIndexToStream(mpArchiveHandle ArchiveHandle, unsigned long FileIndex, IStream& Stream)
{
	__asm int 3;
	mpSetLastError(pERROR_UNSUPPORTED);
	return false;
}

longbool _stdcall mpImportFileFromFile(mpArchiveHandle ArchiveHandle, char* ArchiveFile, char* ExternalFile)
{
	__asm int 3;
	mpSetLastError(pERROR_UNSUPPORTED);
	return false;
}

longbool _stdcall mpImportFileFromStream(mpArchiveHandle ArchiveHandle, char* ArchiveFile, IStream& Stream)
{
	__asm int 3;
	mpSetLastError(pERROR_UNSUPPORTED);
	return false;
}

longbool _stdcall mpRemoveFileByName(mpArchiveHandle ArchiveHandle, char* Filename)
{
	__asm int 3;
	mpSetLastError(pERROR_UNSUPPORTED);
	return false;
}

longbool _stdcall mpRemoveFileByIndex(mpArchiveHandle ArchiveHandle, unsigned long FileIndex)
{
	__asm int 3;
	mpSetLastError(pERROR_UNSUPPORTED);
	return false;
}

