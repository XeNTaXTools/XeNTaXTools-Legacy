/*
  Cache.h
  Cache for the plugin information
*/

#pragma once

// The cache
class geCache
{
public:
	struct gePluginInfo
	{
		// General Information
		std::string Class;
		std::string GameName;
		std::vector<std::string> Extentions;

		// Automatically Generated
		std::string MexComDisplayString;
		std::string ExtentionList;
	};

public:
	geCache();
	geCache(const std::string& Filename);
	virtual ~geCache();
	virtual bool Load(const std::string& Filename);
	virtual bool Save(const std::string& Filename) const;
	virtual unsigned long Add(const gePluginInfo& Info);
	virtual const gePluginInfo& Get(unsigned long Index) const;
	virtual void Remove(unsigned long Index);
	virtual void Clear();
	virtual unsigned long GetCount() const;

protected:
	virtual std::string GenerateExtentionList(const std::vector<std::string>& Extentions) const;

private:
	std::vector<gePluginInfo> m_Plugins;
};
