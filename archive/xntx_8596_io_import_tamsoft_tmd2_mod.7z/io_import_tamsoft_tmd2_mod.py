bl_info = {
	"name": "Import Tamsoft TMD2 model (.tmd2)",
	"description": "Import Tamsoft TMD2 model data.",
	"author": "(^_^)",
	"version": (0, 0, 4),
	"blender": (2, 93, 0),
	"location": "File > Import > Tamsoft TMD2 model (.tmd2)",
	"warning": "Under construction.",
	"wiki_url" : "",
	"tracker_url" : "",
	"category": "Import-Export",
}

"""
This script imports Tamsoft TMD2 model (.tmd2)
"""



import bpy
import bmesh
from bpy.props import ( StringProperty, BoolProperty )
import os
import struct
import mathutils
import math

prop = {}

g_have_weight   = 0
g_have_tangent  = 0
g_have_binormal = 0
g_have_amb_ocl  = 0
g_have_color    = 1
g_have_uv       = 1
g_num_vertices  = 0

g_parts           = []
g_commands        = []
g_materials       = []
g_material_params = []
g_sub_meshes      = []
g_faces           = []
g_texture_info    = dict()
g_textures        = []
g_bone_transforms = []
g_bone_names      = []
g_bone_pos        = []
g_bone_parent_ids = []
g_vertices        = []
g_vert_bones      = []
g_vert_weights    = []
g_normals         = []
g_tangents        = []
g_binormals       = []
g_vertex_amb_ocl  = []
g_vertex_colors   = []
g_vertex_colors2  = []
g_uv              = []
g_uv2             = []
g_uv3             = []
g_bounding_boxes  = []



def read_uint8(fin):
	return struct.unpack("<B", fin.read(1))[0]



def read_uint16(fin):
	return struct.unpack("<H", fin.read(2))[0]



def read_uint32(fin):
	return struct.unpack("<L", fin.read(4))[0]



def read_float(fin):
	return struct.unpack("<f", fin.read(4))[0]



def init_variables():
	global g_have_weight
	global g_have_tangent
	global g_have_binormal
	global g_have_amb_ocl
	global g_have_color
	global g_have_uv
	global g_num_vertices

	global g_parts
	global g_commands
	global g_materials
	global g_material_params
	global g_sub_meshes
	global g_faces
	global g_texture_info
	global g_textures
	global g_bone_transforms
	global g_bone_names
	global g_bone_pos
	global g_bone_parent_ids
	global g_vertices
	global g_vert_bones
	global g_vert_weights
	global g_normals
	global g_tangents
	global g_binormals
	global g_vertex_amb_ocl
	global g_vertex_colors
	global g_vertex_colors2
	global g_uv
	global g_uv2
	global g_uv3
	global g_bounding_boxes

	g_have_weight   = 0
	g_have_tangent  = 0
	g_have_binormal = 0
	g_have_amb_ocl  = 0
	g_have_color    = 1
	g_have_uv       = 1
	g_num_vertices  = 0

	g_parts           = []
	g_commands        = []
	g_materials       = []
	g_material_params = []
	g_sub_meshes      = []
	g_faces           = []
	g_texture_info.clear()
	g_textures        = []
	g_bone_transforms = []
	g_bone_names      = []
	g_bone_pos        = []
	g_bone_parent_ids = []
	g_vertices        = []
	g_vert_bones      = []
	g_vert_weights    = []
	g_normals         = []
	g_tangents        = []
	g_binormals       = []
	g_vertex_amb_ocl  = []
	g_vertex_colors   = []
	g_vertex_colors2  = []
	g_uv              = []
	g_uv2             = []
	g_uv3             = []
	g_bounding_boxes  = []



def read_parts(fin, offset, count):
	global g_parts

	print("----------------------------------------")
	print("parts : offset={0:08X} count={1}".format(offset, count))

	fin.seek(offset, os.SEEK_SET)
	for i in range(count):
		bound_min_x          = read_float(fin)
		bound_min_y          = read_float(fin)
		bound_min_z          = read_float(fin)
		bound_max_x          = read_float(fin)
		bound_max_y          = read_float(fin)
		bound_max_z          = read_float(fin)
		num_commands         = read_uint16(fin)
		unknown_1A           = read_uint16(fin)
		start_index_commands = read_uint16(fin)
		unknown_1E           = read_uint16(fin)
		unknown_20           = read_uint32(fin)
		unknown_24           = read_uint32(fin)
		unknown_28           = read_uint32(fin)

		g_parts.append([bound_min_x, bound_min_y, bound_min_z, bound_max_x, bound_max_y, bound_max_z, start_index_commands, num_commands])

		print("[{0}]".format(i))
		print("\tbound min = ({0:f} {1:f} {2:f})".format(bound_min_x, bound_min_y, bound_min_z))
		print("\tbound max = ({0:f} {1:f} {2:f})".format(bound_max_x, bound_max_y, bound_max_z))
		print("\tcommands  = {0} {1}".format(start_index_commands, num_commands))

	return 0



def read_commands(fin, offset, count):
	global g_commands

	print("----------------------------------------")
	print("commands : offset={0:08X} count={1}".format(offset, count))

	fin.seek(offset, os.SEEK_SET)
	for i in range(count):
		index   = read_uint8(fin)
		command = read_uint8(fin)

		g_commands.append([command, index])

		print("[{0}] {1:02X} {2:02X}".format(i, index, command))

	return 0



def read_materials(fin, offset, count):
	global g_materials

	print("----------------------------------------")
	print("materials : offset={0:08X} count={1}".format(offset, count))

	fin.seek(offset, os.SEEK_SET)
	for i in range(count):
		material_hash               = read_uint32(fin)
		material_sig                = read_uint32(fin)
		start_index_textures        = read_uint16(fin)
		num_textures                = read_uint16(fin)
		start_index_material_params = read_uint16(fin)
		num_material_params         = read_uint16(fin)
		unknown_10                  = read_uint32(fin)

		g_materials.append([material_hash, material_sig, start_index_textures, num_textures, start_index_material_params, num_material_params])

		print("[{0}]".format(i))
		print("\tmaterial hash   = {0:08X}".format(material_hash))
		print("\tmaterial sig    = {0:08X}".format(material_sig))
		print("\ttextures        = {0} {1}".format(start_index_textures, num_textures))
		print("\tmaterial params = {0} {1}".format(start_index_material_params, num_material_params))

	return 0



def read_material_params(fin, offset, count):
	global g_material_params

	print("----------------------------------------")
	print("material params : offset={0:08X} count={1}".format(offset, count))

	fin.seek(offset, os.SEEK_SET)
	for i in range(count):
		unknown_00    = read_uint32(fin)
		unknown_param = read_float(fin)

		g_material_params.append([unknown_00, unknown_param])

		print("[{0}]".format(i))
		print("\tunknown 00    = {0}".format(unknown_00))
		print("\tunknown param = {0:f}".format(unknown_param))

	return 0



def read_sub_meshes(fin, offset, count):
	global g_sub_meshes

	print("----------------------------------------")
	print("sub meshes : offset={0:08X} count={1}".format(offset, count))

	fin.seek(offset, os.SEEK_SET)
	for i in range(count):
		num_faces         = read_uint32(fin)
		start_index_faces = read_uint32(fin)

		g_sub_meshes.append([start_index_faces, num_faces])

		print("[{0}]".format(i))
		print("\tfaces = {0} {1}".format(start_index_faces, num_faces))

	return 0



def read_faces(fin, offset, count):
	global g_faces

	print("----------------------------------------")
	print("faces : offset={0:08X} count={1}".format(offset, count))

	fin.seek(offset, os.SEEK_SET)
	for i in range(count):
		if g_num_vertices <= 0x10000:
			vert_id0 = read_uint16(fin)
			vert_id1 = read_uint16(fin)
			vert_id2 = read_uint16(fin)
		else:
			vert_id0 = read_uint32(fin)
			vert_id1 = read_uint32(fin)
			vert_id2 = read_uint32(fin)

		g_faces.append([vert_id0, vert_id1, vert_id2])

	return 0



def read_texture_info(fin, offset, count):
	global g_texture_info

	print("----------------------------------------")
	print("texture info : offset={0:08X} count={1}".format(offset, count))

	fin.seek(offset, os.SEEK_SET)
	for i in range(count):
		texture_hash  = read_uint32(fin)
		texture_index = read_uint16(fin)
		width         = read_uint16(fin)
		height        = read_uint16(fin)
		unknown_0A    = read_uint8(fin)
		unknown_0B    = read_uint8(fin)

		g_texture_info[texture_hash] = [texture_hash, texture_index, width, height]

		print("[{0}]".format(i))
		print("\ttexture hash  = {0:08X}".format(texture_hash))
		print("\ttexture index = {0}".format(texture_index))
		print("\tsize          = {0} x {1}".format(width, height))

	return 0



def read_textures(fin, offset, count):
	global g_textures

	print("----------------------------------------")
	print("textures : offset={0:08X} count={1}".format(offset, count))

	fin.seek(offset, os.SEEK_SET)
	for i in range(count):
		texture_hash  = read_uint32(fin)
		texture_index = read_uint16(fin)
		unknown_06    = read_uint16(fin)
		unknown_08    = read_uint16(fin)
		unknown_0A    = read_uint8(fin)
		texture_type  = read_uint8(fin)

		g_textures.append([texture_hash, texture_index, texture_type])

		print("[{0}]".format(i))
		print("\ttexture hash  = {0:08X}".format(texture_hash))
		print("\ttexture index = {0}".format(texture_index))
		print("\ttexture type  = {0}".format(texture_type))

	return 0



def read_bone_transforms(fin, offset, count):
	global g_bone_transforms

	print("----------------------------------------")
	print("bone transforms : offset={0:08X} count={1}".format(offset, count))

	fin.seek(offset, os.SEEK_SET)
	for i in range(count):
		tfm = mathutils.Matrix()
		for r in range(4):
			for c in range(4):
				tfm[r][c] = read_float(fin)
		tfm.invert()

		g_bone_transforms.append(tfm)

		#print("[{0}]".format(i))
		#print("\t{0:f} {1:f} {2:f} {3:f}".format(tfm[0][0], tfm[0][1], tfm[0][2], tfm[0][3]))
		#print("\t{0:f} {1:f} {2:f} {3:f}".format(tfm[1][0], tfm[1][1], tfm[1][2], tfm[1][3]))
		#print("\t{0:f} {1:f} {2:f} {3:f}".format(tfm[2][0], tfm[2][1], tfm[2][2], tfm[2][3]))
		#print("\t{0:f} {1:f} {2:f} {3:f}".format(tfm[3][0], tfm[3][1], tfm[3][2], tfm[3][3]))

	return 0



def read_bones(fin, offset, count):
	global prop

	global g_bone_names
	global g_bone_pos
	global g_bone_parent_ids

	print("----------------------------------------")
	print("bones : offset={0:08X} count={1}".format(offset, count))

	fin.seek(offset, os.SEEK_SET)
	for i in range(count):
		bone_hash  = read_uint32(fin)
		x          = read_float(fin)
		y          = read_float(fin)
		z          = read_float(fin)
		parent_id  = read_uint32(fin)
		unknown_14 = read_uint32(fin)

		if prop["use_hash_values_as_bone_names"]:
			name = "bone_{0:08X}".format(bone_hash)
		else:
			name = "bone_{0:03d}".format(i)
		g_bone_names.append(name)
		g_bone_pos.append([x, y, z])
		g_bone_parent_ids.append(parent_id)

		#print("[{0}]".format(i))
		#print("\tbone hash = {0:08X}".format(bone_hash))
		#print("\tpos       = {0:f} {1:f} {2:f}".format(x, y, z))
		#print("\tparent id = {0}".format(parent_id))

	return 0



def read_vertices(fin, offset, count):
	global g_have_weight
	global g_have_tangent
	global g_have_binormal
	global g_have_amb_ocl
	global g_have_color
	global g_have_uv

	global g_vertices
	global g_vert_bones
	global g_vert_weights
	global g_normals
	global g_tangents
	global g_binormals
	global g_vertex_amb_ocl
	global g_vertex_colors
	global g_vertex_colors2
	global g_uv
	global g_uv2
	global g_uv3

	print("----------------------------------------")
	print("vertices : offset={0:08X} count={1}".format(offset, count))

	fin.seek(offset, os.SEEK_SET)
	for i in range(count):
		weights = []
		bones = []

		vx = read_float(fin)
		vy = read_float(fin)
		vz = read_float(fin)

		if g_have_weight != 0:
			for j in range(4):
				weights.append(read_uint8(fin))
			for j in range(4):
				bones.append(read_uint8(fin))
			if g_have_weight == 8:
				for j in range(4):
					weights.append(read_uint8(fin))
				for j in range(4):
					bones.append(read_uint8(fin))

		nx = read_uint8(fin)
		ny = read_uint8(fin)
		nz = read_uint8(fin)
		nw = read_uint8(fin)

		if g_have_tangent != 0:
			tx = read_uint8(fin)
			ty = read_uint8(fin)
			tz = read_uint8(fin)
			tw = read_uint8(fin)

		if g_have_binormal != 0:
			bx = read_uint8(fin)
			by = read_uint8(fin)
			bz = read_uint8(fin)
			bw = read_uint8(fin)

		if g_have_amb_ocl != 0:
			ocl_red   = read_uint8(fin)
			ocl_green = read_uint8(fin)
			ocl_blue  = read_uint8(fin)
			ocl_alpha = read_uint8(fin)

		red   = read_uint8(fin)
		green = read_uint8(fin)
		blue  = read_uint8(fin)
		alpha = read_uint8(fin)

		if g_have_color == 2:
			red2   = read_uint8(fin)
			green2 = read_uint8(fin)
			blue2  = read_uint8(fin)
			alpha2 = read_uint8(fin)

		tu = read_float(fin)
		tv = read_float(fin)
		if 2 <= g_have_uv:
			tu2 = read_float(fin)
			tv2 = read_float(fin)
			if 3 <= g_have_uv:
				tu3 = read_float(fin)
				tv3 = read_float(fin)

		g_vertices.append([vx, vy, vz])

		if g_have_weight != 0:
			g_vert_bones.append(bones)
			g_vert_weights.append(weights)

		g_normals.append([nx, ny, nz, nw])

		if g_have_tangent != 0:
			g_tangents.append([tx, ty, tz, tw])

		if g_have_binormal != 0:
			g_binormals.append([bx, by, bz, bw])

		if g_have_amb_ocl != 0:
			g_vertex_amb_ocl.append([ocl_red, ocl_green, ocl_blue, ocl_alpha])

		g_vertex_colors.append([red, green, blue, alpha])
		if g_have_color == 2:
			g_vertex_colors2.append([red2, green2, blue2, alpha2])

		g_uv.append([tu, tv])
		if 2 <= g_have_uv:
			g_uv2.append([tu2, tv2])
			if 3 <= g_have_uv:
				g_uv3.append([tu3, tv3])

	return 0



def read_bounding_boxes(fin, offset, count):
	global g_bounding_boxes

	print("----------------------------------------")
	print("bounding boxes : offset={0:08X} count={1}".format(offset, count))

	fin.seek(offset, os.SEEK_SET)
	for i in range(count):
		pos = []
		for j in range(8):
			x = read_float(fin)
			y = read_float(fin)
			z = read_float(fin)
			pos.append([x, y, z])

		g_bounding_boxes.append(pos)

		print("[{0}]".format(i))
		for j in range(8):
			print("\t({0:f} {1:f} {2:f})".format(pos[j][0], pos[j][1], pos[j][2]))

	return 0



def read_tmd2_data(fin):
	global g_have_weight
	global g_have_tangent
	global g_have_binormal
	global g_have_amb_ocl
	global g_have_color
	global g_have_uv
	global g_num_vertices

	data = fin.read(4)
	if data == b"0dmt":
		print("unsupported version!")
		return -1
	if data != b"tmd0":
		print("FILE is not TMD2")
		return -1

	unknown_04             = read_uint16(fin)
	vertex_format          = read_uint16(fin)
	unknown_08             = read_uint16(fin)
	unknown_0A             = read_uint16(fin)
	unknown_0C             = read_uint16(fin)
	unknown_0E             = read_uint16(fin)
	bound_min_x            = read_float(fin)
	bound_min_y            = read_float(fin)
	bound_min_z            = read_float(fin)
	bound_max_x            = read_float(fin)
	bound_max_y            = read_float(fin)
	bound_max_z            = read_float(fin)
	offset_parts           = read_uint32(fin)
	unknown_2C             = read_uint32(fin)
	offset_unknown_data1   = read_uint32(fin)
	offset_commands        = read_uint32(fin)
	offset_materials       = read_uint32(fin)
	offset_material_params = read_uint32(fin)
	offset_string_data     = read_uint32(fin)
	offset_unknown_data3   = read_uint32(fin)
	offset_sub_meshes      = read_uint32(fin)
	offset_faces           = read_uint32(fin)
	offset_texture_info    = read_uint32(fin)
	unknown_54             = read_uint32(fin)
	offset_textures        = read_uint32(fin)
	offset_vertices        = read_uint32(fin)
	offset_bounding_boxes  = read_uint32(fin)
	unknown_64             = read_uint32(fin)
	num_parts              = read_uint32(fin)
	unknown_6C             = read_uint32(fin)
	num_unknown_data1      = read_uint32(fin)
	num_commands           = read_uint32(fin)
	num_materials          = read_uint32(fin)
	num_material_params    = read_uint32(fin)
	size_string_data       = read_uint32(fin)
	num_unknown_data3      = read_uint32(fin)
	num_sub_meshes         = read_uint32(fin)
	num_faces              = read_uint32(fin)
	num_texture_info       = read_uint32(fin)
	unknown_94             = read_uint32(fin)
	num_textures           = read_uint32(fin)
	g_num_vertices         = read_uint32(fin)

	vertex_unit_size = 12 + 4 + 4 + 8		# co + normal + color + uv
	g_have_color = 1
	g_have_uv = 1
	if (vertex_format & 0x0001) == 0:
		g_have_amb_ocl = 1
		vertex_unit_size += 4
	if (vertex_format & 0x0008) != 0:
		g_have_tangent  = 1
		g_have_binormal = 1
		vertex_unit_size += 8
	if (vertex_format & 0x0020) != 0:
		g_have_uv += 1
		vertex_unit_size += 8
	if (vertex_format & 0x0040) != 0:
		g_have_uv += 1
		vertex_unit_size += 8
	if (vertex_format & 0x0100) != 0:
		g_have_color += 1
		vertex_unit_size += 4
	if (vertex_format & 0xA400) == 0xA400:
		g_have_weight = 8
		vertex_unit_size += 16
	elif (vertex_format & 0xA400) == 0x2400:
		g_have_weight = 4
		vertex_unit_size += 8

	if g_have_weight != 0:
		offset2_sub_meshes     = read_uint32(fin)
		unknown_A4             = read_uint32(fin)
		offset_bone_transforms = read_uint32(fin)
		offset_bones           = read_uint32(fin)
		unknown_B0             = read_uint32(fin)
		unknown_B4             = read_uint32(fin)
		num_bone_transforms    = read_uint32(fin)
		num_bones              = read_uint32(fin)
		offset_unknown_data4   = read_uint32(fin)
		offset_unknown_data5   = read_uint32(fin)
		unknown_C8             = read_uint32(fin)
		unknown_CC             = read_uint32(fin)

	print("unknown 04       = {0:04X}".format(unknown_04))
	print("vertex format    = {0:04X}".format(vertex_format))
	print("unknown 08       = {0:04X}".format(unknown_08))
	print("unknown 0A       = {0:04X}".format(unknown_0A))
	print("unknown 0C       = {0:04X}".format(unknown_0C))
	print("unknown 0E       = {0:04X}".format(unknown_0E))
	print("bound min        = ({0:f} {1:f} {2:f})".format(bound_min_x, bound_min_y, bound_min_z))
	print("bound max        = ({0:f} {1:f} {2:f})".format(bound_max_x, bound_max_y, bound_max_z))
	print("parts            = {0:08X} {1}".format(offset_parts, num_parts))
	print("unknown data 1   = {0:08X} {1}".format(offset_unknown_data1, num_unknown_data1))
	print("commands         = {0:08X} {1}".format(offset_commands, num_commands))
	print("materials        = {0:08X} {1}".format(offset_materials, num_materials))
	print("material params  = {0:08X} {1}".format(offset_material_params, num_material_params))
	print("string data      = {0:08X} {1:08X}".format(offset_string_data, size_string_data))
	print("unknown data 3   = {0:08X} {1}".format(offset_unknown_data3, num_unknown_data3))
	print("sub meshes       = {0:08X} {1}".format(offset_sub_meshes, num_sub_meshes))
	print("faces            = {0:08X} {1}".format(offset_faces, num_faces))
	print("texture info     = {0:08X} {1}".format(offset_texture_info, num_texture_info))
	print("textures         = {0:08X} {1}".format(offset_textures, num_textures))
	print("vertices         = {0:08X} {1}".format(offset_vertices, g_num_vertices))
	print("bounding boxes   = {0:08X}".format(offset_bounding_boxes))
	if g_have_weight != 0:
		print("bone transforms  = {0:08X} {1}".format(offset_bone_transforms, num_bone_transforms))
		print("bones            = {0:08X} {1}".format(offset_bones, num_bones))
		print("unknown data 4   = {0:08X}".format(offset_unknown_data4))
		print("unknown data 5   = {0:08X}".format(offset_unknown_data5))

	print("vertex unit size = 0x{0:X}".format(vertex_unit_size))
	if g_have_weight != 0:
		print("have weights     = {0}".format(g_have_weight))
	if g_have_tangent != 0:
		print("have tangent")
	if g_have_binormal != 0:
		print("have binormal")
	if g_have_amb_ocl != 0:
		print("have ambient occlusion")
	print("have color       = {0}".format(g_have_color))
	print("have uv          = {0}".format(g_have_uv))

	if read_parts(fin, offset_parts, num_parts) < 0:
		print("ERROR: read parts")
		return -1

	if read_commands(fin, offset_commands, num_commands) < 0:
		print("ERROR: read commands")
		return -1

	if read_materials(fin, offset_materials, num_materials) < 0:
		print("ERROR: read materials")
		return -1

	if read_material_params(fin, offset_material_params, num_material_params) < 0:
		print("ERROR: read material params")
		return -1

	if read_sub_meshes(fin, offset_sub_meshes, num_sub_meshes) < 0:
		print("ERROR: read sub meshes")
		return -1

	if read_faces(fin, offset_faces, num_faces) < 0:
		print("ERROR: read faces")
		return -1

	if read_texture_info(fin, offset_texture_info, num_texture_info) < 0:
		print("ERROR: read texture info")
		return -1

	if read_textures(fin, offset_textures, num_textures) < 0:
		print("ERROR: read textures")
		return -1

	if read_vertices(fin, offset_vertices, g_num_vertices) < 0:
		print("ERROR: read vertices")
		return -1

	if g_have_weight != 0:
		if read_bone_transforms(fin, offset_bone_transforms, num_bone_transforms) < 0:
			print("ERROR: read bone transforms")
			return -1

		if read_bones(fin, offset_bones, num_bones) < 0:
			print("ERROR: read bone transforms")
			return -1

	if offset_bounding_boxes != 0:
		if read_bounding_boxes(fin, offset_bounding_boxes, num_parts + 1) < 0:
			print("ERROR: read bounding boxes")
			return -1

	print("read tmd2 file ... OK", flush=True)

	return 0



def create_bones(armature):
	global g_bone_names
	global g_bone_transforms
	global g_bone_pos
	global g_bone_parent_ids

	bpy.ops.object.mode_set(mode='EDIT', toggle=False)

	num_bones = len(g_bone_names)
	for i, name in enumerate(g_bone_names):
		pos       = g_bone_pos[i]
		parent_id = g_bone_parent_ids[i]
		tfm       = g_bone_transforms[i]
		tfm[3][0] = pos[0]
		tfm[3][1] = pos[1]
		tfm[3][2] = pos[2]

		eb = armature.edit_bones.new(name)
		if parent_id < num_bones:
			tfm = g_bone_transforms[parent_id] @ tfm							# 親のトランスフォームを適用
			g_bone_transforms[i] = tfm
			g_bone_pos[i][0] = tfm[3][0]
			g_bone_pos[i][1] = tfm[3][1]
			g_bone_pos[i][2] = tfm[3][2]
			pos = g_bone_pos[i]
			# 身体の各所に小さな制御用のポイントが配置された形
			eb.head = [ pos[0], pos[1]        , pos[2] ]
			eb.tail = [ pos[0], pos[1] + 0.001, pos[2] ]
			eb.transform(mathutils.Matrix.Identity(4).Rotation(math.radians(90), 4, 'X') @ tfm)		# X軸で90度回転
			eb.parent = armature.edit_bones[g_bone_names[parent_id]]
			eb.use_connect = False
		else:
			# 身体の各所に小さな制御用のポイントが配置された形
			eb.head = [ pos[0], pos[1]        , pos[2] ]
			eb.tail = [ pos[0], pos[1] + 0.001, pos[2] ]
			eb.transform(mathutils.Matrix.Identity(4).Rotation(math.radians(90), 4, 'X') @ tfm)		# X軸で90度回転
			eb.use_connect = False

		print("[{0}]->[{1}] {2}".format(parent_id, i, name))
		print("\t[ {0:f} {1:f} {2:f} ]".format(eb.head[0], eb.head[1], eb.head[2]))
		print("\t[ {0:f} {1:f} {2:f} ]".format(eb.tail[0], eb.tail[1], eb.tail[2]))

	bpy.ops.object.mode_set(mode='OBJECT')
	bpy.context.active_object.select_set(False)



def create_materials(display_name, tex_files):
	global g_texture_info
	global g_textures
	global g_materials

	materials = []
	loaded_images = {}

	# マテリアル作成
	for i, material in enumerate(g_materials):
		name = display_name + '.' + str(i)
		start_index_textures = material[2]
		num_textures         = material[3]

		mat = bpy.data.materials.new(name)
		mat.use_nodes = True
		bsdf = mat.node_tree.nodes['Principled BSDF']
		mat.use_backface_culling = True
		mat.blend_method = 'BLEND'
		mat.shadow_method = 'HASHED'
		mat.alpha_threshold = 0.5
		mat.show_transparent_back = False

		materials.append(mat)

		for j in range(start_index_textures, start_index_textures + num_textures):
			texture       = g_textures[j]
			texture_type  = texture[2]
			texture_info  = g_texture_info[texture[0]]
			texture_index = texture_info[1]

			# diffuseとnormalのみ作成
			img = None
			if texture_type in [0, 4]:
				if texture_index in loaded_images:
					img = loaded_images[texture_index]
				else:
					suffix_png = ".{0}.png".format(texture_index)
					suffix_dds = ".{0}.dds".format(texture_index)
					for filename in tex_files:
						for suffix in [suffix_png, suffix_dds]:
							image_file = filename + suffix
							if os.path.exists(image_file):
								print("texture type={0} file={1}".format(texture_type, image_file))
								try:
									img = bpy.data.images.load(image_file)
									loaded_images[texture_index] = img
								except:
									raise NameError("Cannot load image {0}".format(image_file))

				if img is not None:
					img_node = mat.node_tree.nodes.new(type='ShaderNodeTexImage')
					img_node.image = img
					if texture_type == 0:
						img_node.location = ( -500, 300 )
						mat.node_tree.links.new(bsdf.inputs['Base Color'], img_node.outputs['Color'])
					elif texture_type == 4:
						img_node.location = ( -500, -250 )
						img_node.image.colorspace_settings.name = 'Non-Color'
						normal_node = mat.node_tree.nodes.new(type='ShaderNodeNormalMap')
						normal_node.location = ( -200, -200 )
						normal_node.space = 'TANGENT'
						normal_node.uv_map = 'UVMap'
						normal_node.inputs['Strength'].default_value = 2.0
						mat.node_tree.links.new(normal_node.inputs['Color'], img_node.outputs['Color'])
						mat.node_tree.links.new(bsdf.inputs['Normal'], normal_node.outputs['Normal'])

	return materials



def create_sub_mesh(display_name, sub_mesh_index, material):
	global prop

	global g_have_weight
	global g_have_tangent
	global g_have_binormal
	global g_have_color
	global g_have_uv

	global g_sub_meshes
	global g_faces

	global g_bone_names

	global g_vertices
	global g_vert_bones
	global g_vert_weights
	global g_normals
	global g_tangents
	global g_binormals
	global g_vertex_amb_ocl
	global g_vertex_colors
	global g_vertex_colors2
	global g_uv
	global g_uv2
	global g_uv3

	bound_min = [  math.inf,  math.inf,  math.inf ]
	bound_max = [ -math.inf, -math.inf, -math.inf ]

	obj_name = display_name + ':' + str(sub_mesh_index)
	mesh = bpy.data.meshes.new(obj_name)
	obj = bpy.data.objects.new(mesh.name, mesh)
	obj.data.materials.append(material)

	bm = bmesh.new()

	# サブメッシュ毎に使用している頂点だけ登録すると頂点IDがデータと違ってしまうので
	# 頂点IDを変換するための配列を作成する
	old_vert_ids = []							# 新頂点ID→オリジナル頂点ID
	new_vert_ids = [-1] * len(g_vertices)		# オリジナル頂点ID→新頂点ID(-1は未使用頂点)
	next_id = 0

	bone_used = [False] * len(g_bone_names)

	sub_mesh = g_sub_meshes[sub_mesh_index]
	start_index_faces = sub_mesh[0]
	num_faces         = sub_mesh[1]
	for i in range(start_index_faces, start_index_faces + num_faces):
		vert_ids = g_faces[i]
		new_ids  = [ -1, -1, -1 ]
		for j in range(3):
			new_ids[j] = new_vert_ids[vert_ids[j]]
			# 頂点追加
			if new_ids[j] < 0:
				old_vert_ids.append(vert_ids[j])
				new_ids[j] = next_id
				new_vert_ids[vert_ids[j]] = next_id
				next_id += 1
				co = g_vertices[vert_ids[j]]
				bm.verts.new([co[0], -co[2], co[1]])	# X軸で90度回転
				bm.verts.ensure_lookup_table()			# verts[インデックス]を使用できるようにする

				for k in range(3):
					if co[k] < bound_min[k]:
						bound_min[k] = co[k]
					if bound_max[k] < co[k]:
						bound_max[k] = co[k]

			if g_have_weight != 0:
				b = g_vert_bones[vert_ids[j]]
				w = g_vert_weights[vert_ids[j]]
				for k in range(g_have_weight):
					if w[k] != 0:
						bone_used[b[k]] = True

		# 面追加
		try:
			bm.faces.new([bm.verts[new_ids[0]], bm.verts[new_ids[1]], bm.verts[new_ids[2]]])
		except ValueError as e:
			print("ERROR: {0}".format(e.args))
			print("ERROR: face {0} [ {1} {2} {3} ]".format(i, vert_ids[0], vert_ids[1], vert_ids[2]))
			continue

	bm.to_mesh(mesh)
	bm.free()
	print("added vertices and faces")

	# 頂点グループ
	if g_have_weight != 0:
		# 頂点グループ作成
		for i, used in enumerate(bone_used):
			if used:
				obj.vertex_groups.new(name=g_bone_names[i])

		# 頂点グループに頂点を追加
		for i, vi in enumerate(old_vert_ids):
			b = g_vert_bones[vi]
			w = g_vert_weights[vi]
			for j in range(g_have_weight):
				if w[j] != 0:
					bone_name = g_bone_names[b[j]]
					obj.vertex_groups[bone_name].add([i], w[j] / 255.0, 'ADD')
		print("added vertex groups")

	# 法線
	for poly in mesh.polygons:
		poly.use_smooth = True

	no = []
	for loop in mesh.loops:
		n = g_normals[old_vert_ids[loop.vertex_index]]
		nx = n[0] / 127.5 - 1.0
		ny = n[1] / 127.5 - 1.0
		nz = n[2] / 127.5 - 1.0
		vec = mathutils.Vector((nx, ny, nz))
		vec.normalize()
		nx = vec[0]
		ny = vec[1]
		nz = vec[2]
		no.append([nx, -nz, ny])					# X軸で90度回転
	mesh.normals_split_custom_set(no)
	mesh.use_auto_smooth = True
	print("added normals")

	# 頂点カラー
	color_layer = mesh.vertex_colors.new(name='color')
	for poly in mesh.polygons:
		for loop_index in range(poly.loop_start, poly.loop_start + poly.loop_total):
			vi = old_vert_ids[mesh.loops[loop_index].vertex_index]
			c = g_vertex_colors[vi]
			r = c[0] / 255.0
			g = c[1] / 255.0
			b = c[2] / 255.0
			a = c[3] / 255.0
			color_layer.data[loop_index].color = [r, g, b, a]
	print("added vertex colors")

	if g_have_color == 2:
		color2_layer = mesh.vertex_colors.new(name='color2')
		for poly in mesh.polygons:
			for loop_index in range(poly.loop_start, poly.loop_start + poly.loop_total):
				vi = old_vert_ids[mesh.loops[loop_index].vertex_index]
				c = g_vertex_colors2[vi]
				r = c[0] / 255.0
				g = c[1] / 255.0
				b = c[2] / 255.0
				a = c[3] / 255.0
				color2_layer.data[loop_index].color = [ r, g, b, a ]
		print("added vertex colors2)")

	if g_have_amb_ocl != 0:
		amb_ocl_layer = mesh.vertex_colors.new(name='amb_ocl')
		for poly in mesh.polygons:
			for loop_index in range(poly.loop_start, poly.loop_start + poly.loop_total):
				vi = old_vert_ids[mesh.loops[loop_index].vertex_index]
				c = g_vertex_amb_ocl[vi]
				r = c[0] / 255.0
				g = c[1] / 255.0
				b = c[2] / 255.0
				a = c[3] / 255.0
				amb_ocl_layer.data[loop_index].color = [ r, g, b, a ]
		print("added vertex ambient occlusion)")

	# 法線のX,Y,Z要素をR,G,B値とした頂点カラーを追加する
	if prop["set_normals_to_vertex_colors"]:
		normal_layer = mesh.vertex_colors.new(name='normals')
		for poly in mesh.polygons:
			for loop_index in range(poly.loop_start, poly.loop_start + poly.loop_total):
				vi = old_vert_ids[mesh.loops[loop_index].vertex_index]
				no = g_normals[vi]
				if prop["rotate_colors"]:
					r =       no[0] / 255.0
					g = 1.0 - no[2] / 255.0
					b =       no[1] / 255.0
				else:
					r = no[0] / 255.0
					g = no[1] / 255.0
					b = no[2] / 255.0
				normal_layer.data[loop_index].color = [ r, g, b, 1.0 ]
		print("added vertex colors(normals)")

		# 従法線のX,Y,Z要素をR,G,B値とした頂点カラーを追加する
		if g_have_binormal != 0:
			binormal_layer = mesh.vertex_colors.new(name='binormals')
			for poly in mesh.polygons:
				for loop_index in range(poly.loop_start, poly.loop_start + poly.loop_total):
					vi = old_vert_ids[mesh.loops[loop_index].vertex_index]
					bi = g_binormals[vi]
					if prop["rotate_colors"]:
						r =       bi[0] / 255.0
						g = 1.0 - bi[2] / 255.0
						b =       bi[1] / 255.0
					else:
						r = bi[0] / 255.0
						g = bi[1] / 255.0
						b = bi[2] / 255.0
					binormal_layer.data[loop_index].color = [ r, g, b, 1.0 ]
			print("added vertex colors(binormals)")

		# 接線のX,Y,Z要素をR,G,B値とした頂点カラーを追加する
		if g_have_tangent != 0:
			tangent_layer = mesh.vertex_colors.new(name='tangents')
			for poly in mesh.polygons:
				for loop_index in range(poly.loop_start, poly.loop_start + poly.loop_total):
					vi = old_vert_ids[mesh.loops[loop_index].vertex_index]
					ta = g_tangents[vi]
					if prop["rotate_colors"]:
						r =       ta[0] / 255.0
						g = 1.0 - ta[2] / 255.0
						b =       ta[1] / 255.0
					else:
						r = ta[0] / 255.0
						g = ta[1] / 255.0
						b = ta[2] / 255.0
					tangent_layer.data[loop_index].color = [ r, g, b, 1.0 ]
			print("added vertex colors(tangents)")

	uv_layer = mesh.uv_layers.new(name='UVMap')
	for poly in mesh.polygons:
		for loop_index in range(poly.loop_start, poly.loop_start + poly.loop_total):
			vi = old_vert_ids[mesh.loops[loop_index].vertex_index]
			u =       g_uv[vi][0]
			v = 1.0 - g_uv[vi][1]				# 上下反転
			uv_layer.data[loop_index].uv = [u, v]
	print("added uv map")

	if 2 <= g_have_uv:
		uv2_layer = mesh.uv_layers.new(name='UVMap2')
		for poly in mesh.polygons:
			for loop_index in range(poly.loop_start, poly.loop_start + poly.loop_total):
				vi = old_vert_ids[mesh.loops[loop_index].vertex_index]
				u =       g_uv2[vi][0]
				v = 1.0 - g_uv2[vi][1]				# 上下反転
				uv2_layer.data[loop_index].uv = [u, v]
		print("added uv map 2")

		if 3 <= g_have_uv:
			uv3_layer = mesh.uv_layers.new(name='UVMap3')
			for poly in mesh.polygons:
				for loop_index in range(poly.loop_start, poly.loop_start + poly.loop_total):
					vi = old_vert_ids[mesh.loops[loop_index].vertex_index]
					u =       g_uv3[vi][0]
					v = 1.0 - g_uv3[vi][1]				# 上下反転
					uv3_layer.data[loop_index].uv = [u, v]
			print("added uv map 3")

	return [obj, bound_min, bound_max]



def import_tmd2_main(filepath):
	global prop

	global g_have_weight

	global g_parts
	global g_commands

	init_variables()

	display_name = bpy.path.display_name_from_filepath(filepath)
	name_work = os.path.basename(filepath).split(".")
	print("name work={0}".format(name_work))
	dir = os.path.dirname(filepath)
	tex_basename = name_work[0]
	tex_files = []
	tex_files.append(os.path.join(dir, '..', 'tex', tex_basename))
	tex_files.append(os.path.join(dir, '..', 'tex', tex_basename, tex_basename))
	tex_files.append(os.path.join(dir, tex_basename))
	tex_files.append(os.path.join(dir, tex_basename, tex_basename))


	fin = open(filepath, "rb")
	result = read_tmd2_data(fin)
	fin.close()
	if result < 0:
		return None

	# 既存オブジェクトの選択を全て解除
	scene = bpy.context.scene
	for obj in scene.collection.objects:
		obj.select_set(False)

	if bpy.ops.object.mode_set.poll():
		bpy.ops.object.mode_set(mode='OBJECT')

	# ボーン
	armature = bpy.data.armatures.new(display_name)
	armature.display_type = 'STICK'
	a_obj = bpy.data.objects.new(armature.name, armature)
	a_obj.location = bpy.context.scene.cursor.location
	scene.collection.objects.link(a_obj)
	bpy.context.view_layer.objects.active = a_obj

	if g_have_weight != 0:
		create_bones(armature)
		print("added bones")

	# マテリアル
	materials = create_materials(display_name, tex_files)
	print("created materials")

	bound_min      = [  math.inf,  math.inf,  math.inf ]
	bound_max      = [ -math.inf, -math.inf, -math.inf ]
	bound_min_part = [  math.inf,  math.inf,  math.inf ]
	bound_max_part = [ -math.inf, -math.inf, -math.inf ]

	sub_mesh_index = 0
	material_index = 0

	for part in g_parts:
		print("part={0}".format(part))
		start_index_commands = part[6]
		num_commands         = part[7]

		for command, index in g_commands[start_index_commands : start_index_commands + num_commands]:
			print("command={0:02X}, index={1}".format(command, index))

			if command == 0x10:
				print("min ({0:f} {1:f} {2:f})".format(bound_min_part[0], bound_min_part[1], bound_min_part[2]))
				print("max ({0:f} {1:f} {2:f})".format(bound_max_part[0], bound_max_part[1], bound_max_part[2]))
				bound_min_part = [  math.inf,  math.inf,  math.inf ]
				bound_max_part = [ -math.inf, -math.inf, -math.inf ]

			if command == 0x60 or command == 0x50:
				material_index = index
				print("material index={0}".format(material_index))

			if (command & 0xF0) == 0x30:
				sub_mesh_index = index + 0x100 * (command & 0x0F)
				print("sub mesh index={0}".format(sub_mesh_index))

				new_obj, bmin, bmax = create_sub_mesh(display_name, sub_mesh_index, materials[material_index])
				new_obj.parent = a_obj
				new_obj.parent_type = 'ARMATURE'
				scene.collection.objects.link(new_obj)

				for i in range(3):
					if bmin[i] < bound_min_part[i]:
						bound_min_part[i] = bmin[i]
					if bound_max_part[i] < bmax[i]:
						bound_max_part[i] = bmax[i]
				for i in range(3):
					if bound_min_part[i] < bound_min[i]:
						bound_min[i] = bound_min_part[i]
					if bound_max[i] < bound_max_part[i]:
						bound_max[i] = bound_max_part[i]

	print("min ({0:f} {1:f} {2:f})".format(bound_min[0], bound_min[1], bound_min[2]))
	print("max ({0:f} {1:f} {2:f})".format(bound_max[0], bound_max[1], bound_max[2]))

	# テクスチャ表示モード
	for area in bpy.context.workspace.screens[0].areas:
		for space in area.spaces:
			if space.type == 'VIEW_3D':
				space.shading.type = 'SOLID'
				space.shading.color_type = 'TEXTURE'

	print("import Tamsoft TMD2 ... completed", flush=True)



class IMPORT_OT_tamsoft_tmd2_neptunia(bpy.types.Operator):
	"""Load Tamsoft TMD2 Model"""
	bl_idname = "import_model.tamsoft_tmd2_neptunia"
	bl_description = 'Import Tamsoft TMD2 model (.tmd2)'
	bl_label = "Import TMD2 model"
	bl_options = {'UNDO'}

	filepath : StringProperty(subtype='FILE_PATH')
	filter_glob : StringProperty(default="*.tmd2", options={'HIDDEN'})

	use_hash_values_as_bone_names : BoolProperty(
		name = "Use Hash Values as Bone Names",
		description = "Use hash values as bone names",
		default = False
	)

	set_normals_to_vertex_colors : BoolProperty(
		name = "Set Normals to Vertex Colors",
		description = "Set the normal X, Y, Z elements to the vertex color R, G, B elements",
		default = False
	)

	rotate_colors : BoolProperty(
		name = "Rotate Colors",
		description = "First rotate the normal 90 degrees around the X axis,\nthen set the X, Y, Z components to the R, G, B components.",
		default = False
	)

	def draw(self, context):
		layout = self.layout
		layout.prop(self, "use_hash_values_as_bone_names")
		layout.prop(self, "set_normals_to_vertex_colors")
		layout.prop(self, "rotate_colors")

	def execute(self, context):
		global prop

		prop = {}
		prop["use_hash_values_as_bone_names"] = self.use_hash_values_as_bone_names
		prop["set_normals_to_vertex_colors"] = self.set_normals_to_vertex_colors
		prop["rotate_colors"] = self.rotate_colors

		import_tmd2_main(self.filepath)
		return {'FINISHED'}

	def invoke(self, context, event):
		wm = context.window_manager
		wm.fileselect_add(self)
		return {'RUNNING_MODAL'}


def menu_func(self, context):
	self.layout.operator(IMPORT_OT_tamsoft_tmd2_neptunia.bl_idname, text="Tamsoft TMD2 model (.tmd2)")


def register():
	bpy.utils.register_class(IMPORT_OT_tamsoft_tmd2_neptunia)
	bpy.types.TOPBAR_MT_file_import.append(menu_func)


def unregister():
	bpy.utils.unregister_class(IMPORT_OT_tamsoft_tmd2_neptunia)
	bpy.types.TOPBAR_MT_file_import.remove(menu_func)


if __name__ == "__main__":
	unregister()
	register()

