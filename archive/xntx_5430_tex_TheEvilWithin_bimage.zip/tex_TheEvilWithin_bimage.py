from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("The Evil Within", ".bimage")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
	#noesis.logPopup()
	return 1

#check if it's this type based on the data
def noepyCheckType(data):
    bs = NoeBitStream(data)
    bs.seek(0x4, NOESEEK_ABS)
    Magic = bs.readBytes(4).decode("ASCII")
    if Magic != '\x09MIB':
        return 0
    return 1
	
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.setEndian(NOE_BIGENDIAN)
    bs.seek(0x10, NOESEEK_ABS)
    imgWidth = bs.readInt()            
    imgHeight = bs.readInt()           
    bs.seek(0x24, NOESEEK_ABS)
    imgFmt = bs.readByte()
    bs.seek(0x3e, NOESEEK_ABS)
    datasize = bs.readInt()
    data = bs.readBytes(datasize)      
    #DXT1
    if imgFmt == 0xa:
        texFmt = noesis.NOESISTEX_DXT1
    #DXT5
    elif imgFmt == 0xb:
        texFmt = noesis.NOESISTEX_DXT5
    #rgba2222?
    elif imgFmt == 0x08:
        data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "r2 g2 b2 a2")
        texFmt = noesis.NOESISTEX_RGBA32
    #unknown, not handled
    else:
        print("WARNING: Unhandled image format")
        return None
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1