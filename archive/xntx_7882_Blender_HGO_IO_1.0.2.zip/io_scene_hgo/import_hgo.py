# Bitmap decoders for image types 0x80 and 0x81 lifted from TWOCLevelView
# Hardcoded paths for import are at the bottom

from sys import argv
from struct import pack, unpack
from os.path import split, splitext, join, isdir, isfile, basename
from collections import namedtuple
from io import BytesIO as bio
from os import walk
from math import tan, atan
# .hgo
#	c_type as little endian
#	c_size as big endian
# .hgo.blk
#	c_type as big endian
#	c_size as little endian
Indent = namedtuple('Indent', 'signature end')
Image32 = namedtuple('Image32', 'width height data')
Matrix4x4 = namedtuple('Matrix4x4',
	'm11			m12			m13			m14		'
	'm21			m22			m23			m24		'
	'm31			m32			m33			m34		'
	'm41			m42			m43			m44		'
)

try:
	import bpy, bmesh
	from mathutils import Vector
	blender = True
except ModuleNotFoundError: blender = False

CHUNK_TYPES = {
	b'HGOF' : 'Root',
	b'NTBL' : 'NameTable',
	b'TST0' : 'TextureSet',
	b'TSH0' : 'TextureSet Counter', # 1 int: amount of TXM0
	b'TXM0' : 'TextureSet Material',
	b'MS00' : 'MaterialSet',
	b'TAS0' : 'TexAnimSet',
	b'HGO0' : 'HGobjSet',
}
globals().update( {'C_' + k.decode('ascii'): k for k in CHUNK_TYPES} )

T_TEXANIM_VALUE		= 'texanim value'
T_TEXANIM_STRUCTS	= 'texanim structs'
T_TEXANIM_SHORTS	= 'texanim shorts'
T_BONES				= 'bones'
T_BONE_NTBL			= 'nametable offset'
T_BONE_SOURCE		= 'bone source'
T_BONE_VALUE		= 'value'
T_BONE_ROTATION		= 'rotation'
T_BONE_POSITION		= 'position'
T_BONE_UNKNOWNM		= 'unknownm'
T_BONE_UNKNOWN3		= 'unknown3'
T_C2				= 'count2 data'
T_C3				= 'count3 data'
T_LAYERS			= 'layers'
T_LAYER_SOURCE		= 'collection source'
T_LAYER_NTBL		= 'nametable offset'
T_LAYER_MESH_PB		= 'primary bone mesh sources'
T_LAYER_MESH_P		= 'primary mesh source'
T_LAYER_MESH_SB		= 'secondary bone mesh sources'
T_LAYER_MESH_S		= 'secondary mesh source'
T_POI				= 'poi'
T_POI_VALUE			= 'value'
T_POI_DATA			= 'data'
T_POI_NAME			= 'name'
T_POI_NTBL			= 'nametable offset'
T_C6				= 'count6 data'
T_BITMAPS			= 'bitmaps'
T_MATERIALS			= 'materials'
T_NTBL				= 'name table'
T_ENDFLOAT00		= 'end float 00'
T_ENDFLOAT04		= 'end float 04'
T_ENDFLOAT08		= 'end float 08'
T_ENDFLOAT0C		= 'end float 0c'
T_ENDFLOAT10		= 'end float 10'
T_ENDFLOAT14		= 'end float 14'
T_ENDFLOAT18		= 'end float 18'
T_ENDFLOAT1C		= 'end float 1c'
T_ENDFLOAT20		= 'end float 20'
T_ENDFLOAT24		= 'end float 24'
T_ENDFLOAT28		= 'end float 28'

def truncate_cstr(s: bytes) -> bytes:
	index = s.find(0)
	if index == -1: return s
	return s[:index]
def fetch_cstr(f: 'filelike') -> bytearray:
	build = bytearray()
	while 1:
		strbyte = f.read(1)
		if strbyte == b'\0' or not strbyte: break
		build += strbyte
	return build
def DXTBlend(v1, v2): return (v1 * 3 + v2 * 5) >> 3
def Convert3To8(v): return (v << 5) | (v << 2) | (v >> 1)
def Convert4To8(v): return (v << 4) | v
def Convert5To8(v): return (v << 3) | (v >> 2)
def Convert6To8(v): return (v << 2) | (v >> 4)
#Regular DXT1 model
#	Store/B.E.:	33221100 77665544 bbaa9988 ffeeddcc
#	L.E.:		ffeeddcc bbaa9988 77665544 33221100
#	
#	Tile layout: linear tile layout, left to right, top to bottom
#	0.1.2.3. Tile 2.. Tile 3.. Tile 4.. Tile 5.. Tile 6.. Tile 7.. Tile 8..
#	4.5.6.7. ........ ........ ........ ........ ........ ........ ........
#	8.9.a.b. ........ ........ ........ ........ ........ ........ ........
#	c.d.e.f. ........ ........ ........ ........ ........ ........ ........
#	
#	Tile 9.. Tile 10. Tile 11. Tile 12. Tile 13. Tile 14. Tile 15. Tile 16.
#	........ ........ ........ ........ ........ ........ ........ ........
#	........ ........ ........ ........ ........ ........ ........ ........
#	........ ........ ........ ........ ........ ........ ........ ........
#	
#	Tile 17. Tile 18. Tile 19. Tile 20. Tile 21. Tile 22. Tile 23. Tile 24.
#	........ ........ ........ ........ ........ ........ ........ ........
#	........ ........ ........ ........ ........ ........ ........ ........
#	........ ........ ........ ........ ........ ........ ........ ........
#	
#	Tile 25. Tile 26. Tile 27. Tile 28. Tile 29. Tile 30. Tile 31. Tile 32.
#	........ ........ ........ ........ ........ ........ ........ ........
#	........ ........ ........ ........ ........ ........ ........ ........
#	........ ........ ........ ........ ........ ........ ........ ........
#TWoC DXT1 model
#	Store/B.E.:	00112233 44556677 8899aabb ccddeeff
#	L.E.:		ccddeeff 8899aabb 44556677 00112233
#
#	Tile layout: Z-shape-ordered tile clusters of 4, left to right, top to bottom
#	0.1.2.3. Tile 2.. Tile 5.. Tile 6.. Tile 9.. Tile 10. Tile 13. Tile 14.
#	4.5.6.7. ........ ........ ........ ........ ........ ........ ........
#	8.9.a.b. ........ ........ ........ ........ ........ ........ ........
#	c.d.e.f. ........ ........ ........ ........ ........ ........ ........
#	                                                               
#	Tile 3.. Tile 4.. Tile 7.. Tile 8.. Tile 11. Tile 12. Tile 15. Tile 16.
#    ........ ........ ........ ........ ........ ........ ........ ........
#    ........ ........ ........ ........ ........ ........ ........ ........
#    ........ ........ ........ ........ ........ ........ ........ ........
#	
#	Tile 17. Tile 18. Tile 21. Tile 22. Tile 25. Tile 26. Tile 29. Tile 30.
#	........ ........ ........ ........ ........ ........ ........ ........
#	........ ........ ........ ........ ........ ........ ........ ........
#	........ ........ ........ ........ ........ ........ ........ ........
#	                                                               
#	Tile 19. Tile 20. Tile 23. Tile 24. Tile 27. Tile 28. Tile 31. Tile 32.
#    ........ ........ ........ ........ ........ ........ ........ ........
#    ........ ........ ........ ........ ........ ........ ........ ........
#    ........ ........ ........ ........ ........ ........ ........ ........
def dxt1twoc_to_rgba(dxt1data, width, height) -> Image32:
	assert not width % 8 and not height % 8, f'Image dimensions (received: {width}x{height}) must be divisible by 8.'
	newdata = bio(b'\0'*(4*width*height))
	def DecodeDXTBlock(xoffset, yoffset):
		c1, c2, pixels = unpack('>2HL', dxt1data.read(8))
		blue1	= Convert5To8( c1        & 0b11111 )
		green1	= Convert6To8((c1 >> 5)  & 0b111111)
		red1	= Convert5To8((c1 >> 11) & 0b11111 )
		blue2	= Convert5To8( c2        & 0b11111 )
		green2	= Convert6To8((c2 >> 5)  & 0b111111)
		red2	= Convert5To8((c2 >> 11) & 0b11111 )
		palette = (
			bytes((red1, green1, blue1, 0xFF)),
			bytes((red2, green2, blue2, 0xFF)),
			*(
				(
					bytes((DXTBlend(red2, red1), DXTBlend(green2, green1), DXTBlend(blue2, blue1), 0xFF)),
					bytes((DXTBlend(red1, red2), DXTBlend(green1, green2), DXTBlend(blue1, blue2), 0xFF)),
				) if c1 > c2 else (
					bytes(((red1 + red2)//2, (green1 + green2)//2, (blue1 + blue2)//2, 0xFF)),
					bytes(((red1 + red2)//2, (green1 + green2)//2, (blue1 + blue2)//2, 0)),
				)
			)
		)
		pixels = (
			(pixels >> 30)       ,
			(pixels >> 28) & 0b11,
			(pixels >> 26) & 0b11,
			(pixels >> 24) & 0b11,
			(pixels >> 22) & 0b11,
			(pixels >> 20) & 0b11,
			(pixels >> 18) & 0b11,
			(pixels >> 16) & 0b11,
			(pixels >> 14) & 0b11,
			(pixels >> 12) & 0b11,
			(pixels >> 10) & 0b11,
			(pixels >> 8 ) & 0b11,
			(pixels >> 6 ) & 0b11,
			(pixels >> 4 ) & 0b11,
			(pixels >> 2 ) & 0b11,
			(pixels      ) & 0b11,
		)
		pixel = 0
		for y in range(4):
			for x in range(4):
				newdata.seek(
					+ 4*width*(y + yoffset)
					+ 4*(x + xoffset) )
				newdata.write(palette[pixels[pixel]])
				pixel += 1
	for y in range(0, height, 8):
		for x in range(0, width, 8):# Z-Z-Z shape tile order
			DecodeDXTBlock(x    , y    )
			DecodeDXTBlock(x + 4, y    )
			DecodeDXTBlock(x    , y + 4)
			DecodeDXTBlock(x + 4, y + 4)
	return Image32(width, height, newdata.getvalue())

def rgb5a3twoc_to_rgba(rgb5a3data, width, height):
	outbuffer = bio(b'\0'*(4*width*height))
	for ymacro in range(0, height, 4):
		for xmacro in range(0, width, 4):
			for ymicro in range(4):
				for xmicro in range(4):
					short, = unpack('>H', rgb5a3data.read(2))
					outbuffer.seek(
						+ 4*width*(ymacro + ymicro)
						+ 4*(xmacro + xmicro) )
					outbuffer.write(bytes(
						(	Convert5To8((short>>10)&0b11111),
							Convert5To8((short>>5 )&0b11111),
							Convert5To8((short    )&0b11111),0xFF) if short & 0x8000 else
						(	Convert4To8((short>>8 )&0b1111),
							Convert4To8((short>>4 )&0b1111),
							Convert4To8((short    )&0b1111),
							Convert3To8((short>>12)       ),)
					))
	return Image32(width, height, outbuffer.getvalue())

def chunk64twoc_to_rgba(chunk64data, width, height):
	outbuffer = bio(b'\0'*(4*width*height))
	for ymacro in range(0, height, 4):
		for xmacro in range(0, width, 4):
			division1, division2, = unpack('>16H', chunk64data.read(0x20)), unpack('>16H', chunk64data.read(0x20))
			for ymicro in range(4):
				for xmicro in range(4):
					outbuffer.seek(
						+ 4*width*(ymacro + ymicro)
						+ 4*(xmacro + xmicro) )
					n = (division1[2*ymicro + xmicro] << 16) | division2[2*ymicro + xmicro] | 0xFF
					outbuffer.write( pack('>L', n) )
	return Image32(width, height, outbuffer.getvalue())

def parse_hgo(infilepath, ntbl_preserve = False, debug_scanmode = False):
	debug_set = set()
	def blender_new_rgba(name, image: Image32, **kwargs):
		bimg = bpy.data.images.new(name, image.width, image.height, **kwargs)
		fdata = [ image.data[scanline:scanline + 4*image.width] for scanline in reversed(range(0, len(image.data), 4*image.width)) ]
		bimg.pixels = [b/255 for line in fdata for b in line]
		return bimg
	def cprint(*words, indents = 0, base = None):
		if not debug_scanmode: print((f'          ' if base == None else f'0x{base:08X}') + ' '*indents, *words)
	def ReadNuIFFGeom(indent, route):
		models, = unpack('>L', f.read(4)) # always 1
		cprint(f'models:{models}', indents = indent, base = f.tell() - 4)
		for model_i in range(models):
			if blender:
				bm = bmesh.new()
				voffsets = []
				vnormals = []
				vuvs = []
				vcolours = []
				colourlayer = bm.loops.layers.color.verify()
				uvlayer = bm.loops.layers.uv.verify()
				
				### since blender can only build shape keys (blendshapes in HGO) after a mesh object is created
				### to add them to the object, a blendshapeinfos dictionary is built from encountered blendshapes
				### blendshapes are defined with:
				### * int array of blendshape_id (the blendshape order for these arrays)
				### * bool array of defined blendshape_id
				### * vector array of verts
				### the blendshapeinfos structure is as follows:
				#blendshapeinfos = {
				#	blendshape_id_1: {
				#		this_voffset_1: [Vectors]
				#		this_voffset_2: [Vectors]
				#	},
				#	blendshape_id_2: {
				#		this_voffset_1: [Vectors]
				#		this_voffset_2: [Vectors]
				#	}
				#}
				blendshapeinfos = {}
				### the skininfos structure is as follows:
				#skininfos = {
				#	this_voffset: (
				#		(influence1, influence2, influence3, bone1, bone2, bone3, null),
				#		(influence1, influence2, influence3, bone1, bone2, bone3, null),
				#	)
				#}
				skininfos = {}
		
			meshtype, = unpack('>L', f.read(4)) # only 0 is used
			cprint(f'meshtype:{meshtype}', indents = indent + 1, base = f.tell() - 4)
			if meshtype == 0:
				mesh_i0, mesh_i4, mesh_i8, = unpack('>3L', f.read(0xC)) # 0,0,0 in all models
				cprint(f'Mesh group header: 0x{mesh_i0:08X} 0x{mesh_i4:08X} 0x{mesh_i8:08X}', indents = indent + 2, base = f.tell() - 0xC)
				meshes, = unpack('>L', f.read(4)) # the model is split into meshes according to material
				cprint(f'meshes:{meshes}', indents = indent + 2, base = f.tell() - 4)
				for meshes_i in range(meshes):
					cprint(f'Mesh {meshes_i}', indents = indent + 3, base = f.tell())
					material_id, = unpack('>L', f.read(4))
					cprint(f'material_id:{material_id}', indents = indent + 4, base = f.tell() - 4)
					#ReadNuIFFGeomVtx:
					verts, = unpack('>L', f.read(4))
					cprint(f'verts:{verts}', indents = indent + 4, base = f.tell() - 4)
					if blender:
						this_voffset = len(bm.verts)
						voffsets.append(this_voffset)
						
						for vert_i in range(verts):
							(	pos_x, pos_y, pos_z,
								norm_x, norm_y, norm_z,
								vertexcolour_argb, uv_x, uv_y,) = unpack('>6fL2f', f.read(0x24))
							vert = bm.verts.new( (pos_x, pos_z, pos_y,) )
							vuvs.append( (uv_x, -uv_y) )
							vnormals.append( (norm_x, norm_y, norm_z) )
							vcolours.append(tuple((
								((vertexcolour_argb      ) & 0xFF) / 255, # r
								((vertexcolour_argb >> 8 ) & 0xFF) / 255, # g
								((vertexcolour_argb >> 16) & 0xFF) / 255, # b
								((vertexcolour_argb >> 24)       ) / 255, # a
							)))
						bm.verts.ensure_lookup_table()
					else:
						for vert_i in range(verts):
							(	pos_x, pos_y, pos_z,
								norm_x, norm_y, norm_z,
								vertexcolour_argb, uv_x, uv_y,) = unpack('>6fL2f', f.read(0x24))
					#ReadNuIFFGeomCntrl:
					GeomCntrl, = unpack('>L', f.read(4)) # only 0 is used
					cprint(f'GeomCntrl:{GeomCntrl}', indents = indent + 4, base = f.tell() - 4)
					#ReadNuIFFGeomPrim:
					primitives, = unpack('>L', f.read(4))
					cprint(f'primitives:{primitives}', indents = indent + 4, base = f.tell() - 4)
					for primitive_i in range(primitives):
						primtype, = unpack('>L', f.read(4))
						cprint(f'primtype:{primtype}', indents = indent + 5, base = f.tell() - 4)
						vert_indices, = unpack('>L', f.read(4))
						cprint(f'vert_indices:{vert_indices}', indents = indent + 5, base = f.tell() - 4)
						
						if primtype == 5:
							if blender:
								for face_i in range(vert_indices // 3):
									face = bm.faces.new( bm.verts[this_voffset + vert] for vert in unpack('>3H', f.read(2*3)) )
									face.material_index = material_id
							else: f.seek(vert_indices*2, 1)
						elif primtype == 6: # strips, used in B/BdyParts/BdyParts.hgo
							if blender and False: # this is wrong
								v1, v2, v3 = unpack('>3H', f.read(2*3))
								for face in range(vert_indices - 3):
									try:bm.faces.new( (bm.verts[this_voffset + v1], bm.verts[this_voffset + v2], bm.verts[this_voffset + v3]) )
									except:pass
									v1, v2, v3 = v2, v3, unpack('>H', f.read(2))[0]
							else: f.seek(vert_indices*2, 1)
						else: raise AssertionError(f'Mesh type ({primtype}) wasn\'t 5 nor 6.')
					#ReadNuIFFGeomSkin:
					GeomSkin_present, = unpack('>L', f.read(4))
					cprint(f'GeomSkin_present:{GeomSkin_present}', indents = indent + 4, base = f.tell() - 4)
					if GeomSkin_present:
						GeomSkin_type, = f.read(1) # only 1
						cprint(f'GeomSkin_type:{GeomSkin_type}', indents = indent + 5, base = f.tell() - 1)
						if GeomSkin_type == 0: ### this path is unused; no models use it
							GeomSkin_3, GeomSkin_4, GeomSkin_5, = unpack('>3L', f.read(4*3))
							f.seek(4*GeomSkin_5, 1)
							f.seek(4*GeomSkin_4*GeomSkin_5, 1)
						else:
							if blender:
								skininfos[this_voffset] = tuple(unpack('>3f4B', f.read(16)) for _ in range(verts))
							else: f.seek( verts*16, 1 )
					#ReadNuIFFBlendShape:
					BlendShapes, = unpack('>L', f.read(4))
					cprint(f'BlendShapes:{BlendShapes}', indents = indent + 4, base = f.tell() - 4)
					if BlendShapes:
						BlendShapes_indices = unpack(f'>{BlendShapes}L', f.read(4*BlendShapes))
						cprint(f'BlendShapes_indices: {BlendShapes_indices}', indents = indent + 5, base = f.tell() - 4)
						BlendShape_vbuffer_size, = unpack('>L', f.read(4)) # equal to 12*sum(BlendShapes_bools)*verts
						cprint(f'BlendShape_vbuffer_size:0x{BlendShape_vbuffer_size:X}', indents = indent + 5, base = f.tell() - 4)
						BlendShape_vbuffer = bio(f.read(BlendShape_vbuffer_size))
						BlendShapes_bools = f.read(BlendShapes)
						cprint(f'BlendShapes_bools:{tuple(BlendShapes_bools)}', indents = indent + 5, base = f.tell() - 4)
						if blender:
							for ispresent, index in zip(BlendShapes_bools, BlendShapes_indices):
								if not ispresent: continue
								if index not in blendshapeinfos: blendshapeinfos[index] = {}
								blendshapeinfos[index][this_voffset] = tuple(unpack(f'>3f', BlendShape_vbuffer.read(12)) for _ in range(verts))
							 
			elif meshtype == 1: # not used by any model
				var3, = unpack('>L', f.read(4))
				cprint(f'var3:{var3}', indents = indent + 2, base = f.tell() - 4)
				for var3_i in range(var3):
					var3_1, = unpack('>L', f.read(4))
					cprint(f'var3_1:{var3_1}', indents = indent + 3, base = f.tell() - 4)
					#ReadNuIFFFaceOnGeom:
					FaceOnGeom_1, FaceOnGeom_2, FaceOnGeom_3 = unpack('>2Lf', f.read(4*3))
					f.read( 0x18*FaceOnGeom_1 )
			if blender:
				bm.faces.ensure_lookup_table()
				for vert_i, uv in enumerate(vuvs):
					for loop in bm.verts[vert_i].link_loops:
						loop[uvlayer].uv = uv
						#loop[colourlayer] = vcolours[vert_i]
				m = bpy.data.meshes.new(f'HGO Mesh {model_i} {route}')
				bm.to_mesh(m)
				
				### this doesn't do anything... wtf??
				#m.normals_split_custom_set_from_vertices(vnormals)
				#m.use_auto_smooth = True
				#m.update()
				
				o = bpy.data.objects.new(f'HGO Object {model_i} {route}', m)
				for material in materials: o.data.materials.append(material)
				layer.objects.link(o)
				o.parent = arma
				
				o.shape_key_add(name = 'BlendShape Base')
				for blendshape_id, dict_voffsets in ((k, blendshapeinfos[k]) for k in sorted(blendshapeinfos)):
					blendshape = o.shape_key_add(name = f'BlendShape {blendshape_id}')
					for voffset, vectors in dict_voffsets.items():
						for vector_i, v in enumerate(vectors):
							blendshape.data[voffset + vector_i].co += Vector((v[0], v[2], v[1]))
				
				armamodifier = o.modifiers.new('HGO Armature Modifier', 'ARMATURE')
				armamodifier.object = arma
				vgroups = [o.vertex_groups.new(name = bone.name) for bone in arma.data.bones]
				for voffset, skininfos in skininfos.items():
					for vert_i, skininfo in enumerate(skininfos):
						weight1, weight2, weight3, boneid1, boneid2, boneid3, null = skininfo
						if boneid1:
							vgroups[boneid1].add((voffset + vert_i,), weight1, 'REPLACE')
							if boneid2:
								vgroups[boneid2].add((voffset + vert_i,), weight2, 'REPLACE')
								if boneid3:
									vgroups[boneid3].add((voffset + vert_i,), weight3, 'REPLACE')
				arma.show_in_front = True
				return o
	with open(infilepath, 'rb') as f:
		indents = []
		if blender:
			hgoname = splitext(basename(infilepath))[0]
			### make a new scene to load the model(s) into
			scene = bpy.context.window.scene = bpy.data.scenes.new(hgoname)
			coll = bpy.context.collection
			### make a text file to store all the unused or problematic information in
			text = bpy.data.texts.new(scene.name)
			text.write('{\n')
		while 1:
			c_base = f.tell()
			c_header = f.read(8)
			if len(c_header) != 8:
				if c_header: cprint('EOF reached. There was trailing data.', indents = 0)
				else: cprint('EOF reached.', indents = 0)
				break
				
			c_type, c_size = unpack('>4sl', c_header)
			c_type = c_type[::-1]
			if c_size < 1:
				if c_size < 0: c_size = -c_size
				#elif not c_size:
				#	raise ValueError(f'Fatal error: Null-size chunk found at 0x{c_base:08X}')
			
			printed = False
			if c_type == C_NTBL:
				ntbl_len, = unpack('>L', f.read(4)) # does not include padding
				printed = cprint(f'{repr(c_type)[2:-1]} ({CHUNK_TYPES.get(c_type)}) Len:0x{c_size:X} DataLen:0x{ntbl_len:X}', indents = len(indents), base = c_base)
				ntbl_buffer = bio(f.read(ntbl_len))
				name_i = 0
				while 1:
					name = fetch_cstr(ntbl_buffer).decode('ascii')
					if not name: break
					cprint(f'{name_i}:', name, indents = len(indents) + 1)
					name_i += 1
				f.seek(c_base + c_size)
			elif c_type in (C_TST0, C_HGOF): pass # contains more chunks
			elif c_type == C_TXM0:
				txm_datatype, txm_width, txm_height, txm_datalen = unpack('>4L', f.read(4*4))
				printed = cprint(f'{repr(c_type)[2:-1]} ({CHUNK_TYPES.get(c_type)}) Len:0x{c_size:X} Type:0x{txm_datatype:X} Width:{txm_width}x{txm_height} DataLen:0x{txm_datalen:X}', indents = len(indents), base = c_base)
				if blender:
				
					if txm_datatype == 0x80: imgtexture = dxt1twoc_to_rgba(f, txm_width, txm_height)
					elif txm_datatype == 0x81: imgtexture = rgb5a3twoc_to_rgba(f, txm_width, txm_height)
					elif txm_datatype == 0x82: imgtexture = chunk64twoc_to_rgba(f, txm_width, txm_height) # only used by E/Vortex/Vortex.hgo
					else: raise AssertionError('Invalid texture type.')
					image = blender_new_rgba(f'HGO Image', imgtexture)
					images[image_assignid] = image
					image_assignid += 1
				f.seek(c_base + c_size)
			elif c_type == C_MS00:
				mat_amount, = unpack('>L', f.read(4))
				printed = cprint(f'{repr(c_type)[2:-1]} ({CHUNK_TYPES.get(c_type)}) Len:0x{c_size:X} Amount:{mat_amount}', indents = len(indents), base = c_base)
				materials = []
				materialdefs = []
				for mat_i in range(mat_amount):
					(	ms00_v0,	ms00_v1,	ms00_v2,	ms00_v3,
						ms00_v4,	diffuse_r,	diffuse_g,	diffuse_b,
						ms00_v8,	ms00_v9,	ms00_v10,	ms00_v11,
						ms00_v12,	ms00_v13,	texture_id,	ms00_v15,
						ms00_v16,	ms00_v17,	ms00_v18,	ms00_v19, ms00_v20,
					) = unpack('>5L5f2L2fl6L', f.read(0x54))
					cprint(f'Material {mat_i} texture_id:{texture_id}', indents = len(indents) + 1)
					
					if blender:
						m = bpy.data.materials.new(f'HGO Material {mat_i}')
						m.diffuse_color = (diffuse_r, diffuse_g, diffuse_b, 1.0)
						if texture_id >= 0 and images[texture_id]:
							m.use_nodes = True
							m.blend_method = 'HASHED' # this isn't the prettiest transparency effect, but it doesn't have background textures popping through
							targetnode = m.node_tree.nodes.get('Principled BSDF')
							assert targetnode, 'Failed to locate target node.'
							n = m.node_tree.nodes.new('ShaderNodeTexImage')
							n.image = images[texture_id]
							m.node_tree.links.new( n.outputs['Color'], targetnode.inputs['Base Color'] )
							m.node_tree.links.new( n.outputs['Alpha'], targetnode.inputs['Alpha'] )
						materials.append(m)
						materialdefs.append(( m.name,
							ms00_v0,	ms00_v1,	ms00_v2,	ms00_v3,
							ms00_v4,	diffuse_r,	diffuse_g,	diffuse_b,
							ms00_v8,	ms00_v9,	ms00_v10,	ms00_v11,
							ms00_v12,	ms00_v13,	texture_id,	ms00_v15,
							ms00_v16,	ms00_v17,	ms00_v18,	ms00_v19, ms00_v20,
						))
				f.seek(c_base + c_size)
			elif c_type == C_TAS0:
				printed = cprint(f'{repr(c_type)[2:-1]} ({CHUNK_TYPES.get(c_type)}) Len:0x{c_size:X}', indents = len(indents), base = c_base)
				tas0_count, texanim_value = unpack('>2L', f.read(8))
				cprint(f'tas0_count:{tas0_count} texanim_value:{texanim_value}', indents = len(indents) + 1)
				texanim_structs = []
				for tas0_i in range(tas0_count):
					texanim_struct = f.read(0x20)
					texanim_structs.append(texanim_struct)
					(	tas0_v0,	tas0_v1,	tas0_v2,	tas0_v3,
						tas0_v4,	tas0_v5,	tas0_v6,	tas0_v7,
					) = unpack('>8L', texanim_struct)
					cprint(f'tas0_v4:{tas0_v4}', indents = len(indents) + 2)
				tas0_shorts_count, = unpack('>L', f.read(4))
				cprint(f'tas0_shorts_count:{tas0_shorts_count}', indents = len(indents) + 1, base = f.tell() - 4)
				tas0_shorts = unpack(f'>{tas0_shorts_count}H', f.read(2*tas0_shorts_count))
				for tas0_short in tas0_shorts:
					cprint(f'short:{tas0_short}', indents = len(indents) + 2)
				f.seek(c_base + c_size)
				
				if blender:
					text.write(f'{repr(T_TEXANIM_VALUE)}: {texanim_value},\n')
					text.write(f'{repr(T_TEXANIM_STRUCTS)}: (\n')
					for struct in texanim_structs:
						text.write(f'  {repr(struct.hex())},\n')
					text.write('),\n')
					text.write(f'{repr(T_TEXANIM_SHORTS)}: {tas0_shorts},\n')
			elif c_type == C_TSH0:
				tsh0_num, = unpack('>L', f.read(4))
				images = [None]*tsh0_num
				image_assignid = 0
				printed = cprint(f'{repr(c_type)[2:-1]} ({CHUNK_TYPES.get(c_type)}) Len:0x{c_size:X} Amount:{tsh0_num}', indents = len(indents), base = c_base)
				f.seek(c_base + c_size)
			elif c_type == C_HGO0:
				printed = cprint(f'{repr(c_type)[2:-1]} ({CHUNK_TYPES.get(c_type)}) Len:0x{c_size:X}', indents = len(indents), base = c_base)
				bones, = f.read(1)
				cprint(f'bones:{bones}', indents = len(indents) + 1, base = f.tell() - 1)
				if bones:
					if blender:
						skel = bpy.data.armatures.new('HGO Skeleton')
						arma = bpy.data.objects.new('HGO Armature', skel)
						coll.objects.link(arma)
						bpy.context.view_layer.objects.active = arma
						bpy.ops.object.mode_set(mode = 'EDIT')
						
						text.write(f'{repr(T_BONES)}: [\n')
					
					bone_parentlist = []
					for bone_i in range(bones):
						cprint(f'Bone {bone_i}', indents = len(indents) + 2, base = f.tell())
						bone_v0,=f.read(1)
						cprint(f'bone_v0: {bone_v0}', indents = len(indents) + 3)
						# these identity matrices ideally only have XYZ fields filled (B/Cortex/Cortex.hgo), but may other fields may be contaminated by unknown means
						mrot = Matrix4x4(*unpack('>16f', f.read(0x40)))
						mpos = Matrix4x4(*unpack('>16f', f.read(0x40)))
						munk = Matrix4x4(*unpack('>16f', f.read(0x40))) # is usually a blank identity matrix
						bdiv4_v00, bdiv4_v04, bdiv4_v08, = unpack('>L2f', f.read(0xC)) # a minority of models have non-null values here - bdiv4_v00 is either 0, 0x80<<24, or 0x26<<24
						cprint(f'bdiv4: {bdiv4_v00}, {bdiv4_v04}, {bdiv4_v08}', indents = len(indents) + 3)
						
						
						bone_parent,=unpack('>b', f.read(1))
						cprint(f'bone_parent: {bone_parent}', indents = len(indents) + 3)
						
						bone_parentlist.append(bone_parent)
						name_offset,=unpack('>L', f.read(4))
						cprint(f'name_offset: 0x{name_offset:X}', indents = len(indents) + 3)
						ntbl_buffer.seek(name_offset - 1)
						bone_name = fetch_cstr(ntbl_buffer).decode('ascii')
						cprint(f'Name      : {bone_name}', indents = len(indents) + 3)
						
						if blender:
							bone = skel.edit_bones.new(bone_name)
							bone.head = ( # this approach only works for matrices where all other fields are default
								-mpos.m41,
								-mpos.m43,
								-mpos.m42,
							)
							bone.tail = ( # todo: make a math expression that incorporates the length into the position (to facilitate accurate export)
								tan(mrot.m41) - mpos.m41,
								tan(mrot.m43) - mpos.m43,
								tan(mrot.m42) - mpos.m42,
							)
							bone.length = 0.03
							#bone.tail = (
							#	bone.head[0],
							#	bone.head[1],
							#	bone.head[2] + 0.03,
							#)
								
							text.write('  {\n')
							text.write(f'    {repr(T_BONE_SOURCE)}: {repr(bone.name)},\n')
							if ntbl_preserve:
								text.write(f'    {repr(T_BONE_NTBL)}: {name_offset},\n')
							text.write(f'    {repr(T_BONE_VALUE)}: {bone_v0},\n')
							text.write(f'    {repr(T_BONE_ROTATION)}: {tuple(mrot)},\n')
							text.write(f'    {repr(T_BONE_POSITION)}: {tuple(mpos)},\n')
							text.write(f'    {repr(T_BONE_UNKNOWNM)}: {tuple(munk)},\n')
							text.write(f'    {repr(T_BONE_UNKNOWN3)}: ({hex(bdiv4_v00)}, {bdiv4_v04}, {bdiv4_v08}),\n')
							text.write('  },\n')
					if blender:
						for bone_id, bone_parent in enumerate(bone_parentlist):
							if bone_parent < 0: continue # root bone is set to -1
							skel.edit_bones[bone_id].parent = skel.edit_bones[bone_parent]
						bpy.ops.object.mode_set(mode = 'OBJECT')
						text.write('],\n')
					
					countbyte2, = f.read(1) # set to 1, 2, or 4 in a minority of models: 
					cprint(f'countbyte2:{countbyte2}', indents = len(indents) + 1, base = f.tell() - 1)
					countbyte2_data = f.read(countbyte2)
					if blender and countbyte2_data: text.write(f'{repr(T_C2)}: {repr(countbyte2_data.hex())},\n')
					
					countbyte3, = f.read(1)
					cprint(f'countbyte3:{countbyte3}', indents = len(indents) + 1, base = f.tell() - 1)
					countbyte3_data = f.read(countbyte3)
					if blender and countbyte3_data: text.write(f'{repr(T_C3)}: {repr(countbyte3_data.hex())},\n')
					
					layers, = f.read(1)
					cprint(f'layers:{layers}', indents = len(indents) + 1, base = f.tell() - 1)
					
					if blender: text.write(f'{repr(T_LAYERS)}: [\n')
					for layers_i in range(layers):
						layer_nameoffset, = unpack('>L', f.read(4))
						ntbl_buffer.seek(layer_nameoffset - 1)
						layer_name = fetch_cstr(ntbl_buffer).decode('ascii')
						cprint(f'layer_nameoffset: 0x{layer_nameoffset:X} ({layer_name})', indents = len(indents) + 2, base = f.tell() - 4)
						
						if blender:
							text.write('  {\n')
							text.write(f'    {repr(T_LAYER_SOURCE)}: {repr(layer_name)},\n')
							if ntbl_preserve: # otherwise, the exporter can use bone.name
								text.write(f'    {repr(T_LAYER_NTBL)}: {layer_nameoffset},\n')
							layer = bpy.data.collections.new( layer_name )
							coll.children.link(layer)
							
						
						primary_bone_meshes_present, = f.read(1) # this is present in around half of models
						cprint(f'primary_bone_meshes_present:{primary_bone_meshes_present}', indents = len(indents) + 2, base = f.tell() - 1)
						if primary_bone_meshes_present:
							if blender: text.write(f'    {repr(T_LAYER_MESH_PB)}: [\n')
							for bone_i in range(bones):
								primary_bone_mesh_present, = f.read(1)
								cprint(f'primary_bone_mesh_present:{primary_bone_mesh_present}', indents = len(indents) + 3, base = f.tell() - 1)
								if primary_bone_mesh_present:
									meshreturn = ReadNuIFFGeom(len(indents) + 4, f'PrimaryBone_{bone_i}')
									if blender: text.write(f'      {repr(meshreturn.name)},\n')
							if blender: text.write('    ],\n')
								
						primary_mesh_present, = f.read(1)  # this is present in most models
						cprint(f'primary_mesh_present:{primary_mesh_present}', indents = len(indents) + 2, base = f.tell() - 1)
						if primary_mesh_present:
							meshreturn = ReadNuIFFGeom(len(indents) + 3, 'Primary')
							if blender: text.write(f'    {repr(T_LAYER_MESH_P)}: {repr(meshreturn.name)},\n')
						
						secondary_bone_meshes_present, = f.read(1) # only used by "C\Splash\Splash.hgo"
						cprint(f'secondary_bone_meshes_present:{secondary_bone_meshes_present}', indents = len(indents) + 2, base = f.tell() - 1)
						if secondary_bone_meshes_present:
							for bone_i in range(bones):
								if blender: text.write(f'    {repr(T_LAYER_MESH_SB)}: [\n')
								secondary_bone_mesh_present, = f.read(1)
								cprint(f'secondary_bone_mesh_present:{secondary_bone_mesh_present}', indents = len(indents) + 3, base = f.tell() - 1)
								if secondary_bone_mesh_present:
									meshreturn = ReadNuIFFGeom(len(indents) + 4, f'SecondaryBone_{bone_i}')
									if blender: text.write(f'    {repr(meshreturn.name)},\n')
								if blender: text.write('    ],\n')
									
						secondary_mesh_present, = f.read(1) # used by a few models, such as "\A\AkuAku\AkuAku.hgo"
						cprint(f'secondary_mesh_present:{secondary_mesh_present}', indents = len(indents) + 2, base = f.tell() - 1)
						if secondary_mesh_present:
							meshreturn = ReadNuIFFGeom(len(indents) + 3, 'Secondary')
							if blender: text.write(f'    {repr(T_LAYER_MESH_S)}: {repr(meshreturn.name)},\n')
							
						if blender: text.write('  },\n')
					if blender: text.write('],\n')
					
					points, = f.read(1) # set in around a third of models
					cprint(f'points:{points}', indents = len(indents) + 1, base = f.tell() - 1)
					point_data = []
					for point_i in range(points): # strings label these as "poi" - "point of interest"? attachment points?
						point_boneid, = f.read(1)
						point_matrix = f.read(0x40)
						point_nameoffset, = unpack('>L', f.read(4))
						ntbl_buffer.seek(point_nameoffset - 1)
						point_name = fetch_cstr(ntbl_buffer).decode('ascii')
						point_data.append((point_boneid, point_matrix.hex(), point_nameoffset))
						cprint(f'Boneid:{point_boneid} Nameoffset:0x{point_nameoffset:X} ({point_name})', indents = len(indents) + 2, base = f.tell() - 1 - 0x40 - 4)
					if blender and point_data:
						text.write(f'{repr(T_POI)}: [\n')
						for p_value, p_data, p_ntbl in point_data:
							text.write('  {\n')
							text.write(f'    {repr(T_POI_VALUE)}: {p_value},\n')
							if ntbl_preserve:
								text.write(f'    {repr(T_POI_NTBL)}: {p_ntbl},\n')
							else:
								ntbl_buffer.seek(p_ntbl - 1); p_name = fetch_cstr(ntbl_buffer).decode('ascii')
								text.write(f'    {repr(T_POI_NAME)}: {repr(p_name)},\n')
							text.write(f'    {repr(T_POI_DATA)}: {repr(p_data)},\n')
							text.write('  },\n')
						text.write('],\n')
						
					countbyte6, = f.read(1) # set to 20 in only 2 models: \A\Crash\Crash.hgo & newCrash.hgo
					cprint(f'countbyte6:{countbyte6}', indents = len(indents) + 1, base = f.tell() - 1)
					count6data = []
					for countbyte6_i in range(countbyte6):
						countbyte6_1, = f.read(1)
						countbyte6_1_data = f.read( countbyte6_1*0x30 )
						countbyte6_2, = f.read(1)
						countbyte6_2_data = f.read( countbyte6_2*0x40 )
						countbyte6_3, = f.read(1)
						cprint(f'countbyte6_1:{countbyte6_1} countbyte6_2:{countbyte6_2} countbyte6_3:{countbyte6_3}', indents = len(indents) + 2)
						countbyte6_3_data = []
						for countbyte6_3_i in range(countbyte6_3):
							c63_1, = unpack('>L', f.read(4))
							c63_1_data = f.read( c63_1*16 )
							c63_2, = unpack('>L', f.read(4))
							c63_2_data = f.read( c63_2*16 )
							
							cprint(f'c63_1:{c63_1} c63_2:{c63_2}', indents = len(indents) + 3)
							countbyte6_3_data.append( (c63_1_data.hex(), c63_2_data.hex()) )
						countbyte6_last, = f.read(1)
						count6data.append((countbyte6_1_data.hex(), countbyte6_2_data.hex(), countbyte6_3_data, countbyte6_last))
					if blender and count6data:
						text.write(f'{repr(T_C6)}: [\n')
						for count6 in count6data:
							text.write(f'  {count6},\n')
						text.write('],\n')
						
				(	float00, float04, float08, float0C,
					float10, float14, float18, float1C,
					float20, float24, float28,) = unpack('>11f', f.read(4*11))
				cprint(f'Ending floats:', indents = len(indents) + 1, base = f.tell() - 4*11)
				cprint(f'{float00:.03f} {float04:.03f} {float08:.03f} {float0C:.03f}', indents = len(indents) + 2)
				cprint(f'{float10:.03f} {float14:.03f} {float18:.03f} {float1C:.03f}', indents = len(indents) + 2)
				cprint(f'{float20:.03f} {float24:.03f} {float28:.03f}', indents = len(indents) + 2)
					
				if blender:
					text.write(f'{repr(T_ENDFLOAT00)}: {float00},\n')
					text.write(f'{repr(T_ENDFLOAT04)}: {float04},\n')
					text.write(f'{repr(T_ENDFLOAT08)}: {float08},\n')
					text.write(f'{repr(T_ENDFLOAT0C)}: {float0C},\n')
					text.write(f'{repr(T_ENDFLOAT10)}: {float10},\n')
					text.write(f'{repr(T_ENDFLOAT14)}: {float14},\n')
					text.write(f'{repr(T_ENDFLOAT18)}: {float18},\n')
					text.write(f'{repr(T_ENDFLOAT1C)}: {float1C},\n')
					text.write(f'{repr(T_ENDFLOAT20)}: {float20},\n')
					text.write(f'{repr(T_ENDFLOAT24)}: {float24},\n')
					text.write(f'{repr(T_ENDFLOAT28)}: {float28},\n')
					
					text.write(f'{repr(T_BITMAPS)}: [\n')
					for image in images:
						text.write(f'  {repr(image.name)},\n')
					text.write('],\n')
					
					text.write(f'{repr(T_MATERIALS)}: [\n')
					for materialdef in materialdefs:
						text.write(f'  {materialdef},\n')
					text.write('],\n')
					
					if ntbl_preserve:
						text.write(f'{repr(T_NTBL)}: [\n') # format it nicely, rather than 1 big bytes block
						ntbl_buffer.seek(0)
						buildstr = bytearray()
						lastbyte = b'\0'
						while 1:
							readbyte = ntbl_buffer.read(1)
							if readbyte == b'\0' == lastbyte: # failsafe for something that is not expected to happen
								text.write(f'  {readbyte + ntbl_buffer.read()},\n')
								break
							elif readbyte == b'\0':
								text.write(f'  {bytes(buildstr) + readbyte},\n')
								buildstr = bytearray()
							elif not readbyte:
								if buildstr: text.write(f'  {bytes(buildstr)},\n') # not expected to happen either
								break
							else: buildstr += readbyte
							lastbyte = readbyte
						text.write('],\n')
					
					text.write('}')
					
				f.seek(c_base + c_size)
			else:
				f.seek(c_base + c_size) # skip
			if printed == False:
				printed = cprint(f'{repr(c_type)[2:-1]} ({CHUNK_TYPES.get(c_type)}) Len:0x{c_size:X}', indents = len(indents), base = c_base)
			
			terminate = False
			indents.append( Indent(c_type, c_base + c_size) )
			currentpos = f.tell()
			for indent_i in reversed(range(len(indents))):
				if currentpos >= indents[indent_i].end:
					if currentpos > indents[indent_i].end:
						cprint(f'Error: span ending at 0x{indents[indent_i].end:X} overshot. ####################################################################################', indents = 0)
					if not indent_i:
						cprint('Broke out of root span.')
						terminate = True
					del indents[indent_i]
				else: break
			if terminate: break
	if debug_scanmode: print(' Debug set:', debug_set)

if __name__ == '__main__':
	sample = ( argv[1] if len(argv) > 1 else # parse given file, else use a default
		r'C:\Users\nesfi\OneDrive\Documents\ROM\GC\Crash Bandicoot - The Wrath of Cortex (USA).nkit.iso_GCBE7D0000\chars\B\Cortex\Cortex.hgo'
	)
	
	if isdir(sample) and not isfile(sample): # batch parse models if given a dir
		for dir, dirs, files in walk(sample):
			for file in files:
				if file.lower().endswith('.hgo'):
					print(f'Opening file: {join(dir, file).removeprefix(argv[1]):30}' , end = '')
					parse_hgo(join(dir, file), debug_scanmode = True)
	else:
		extless, ext = splitext(sample)
		
		if ext.lower() == '.hgo':
			print('Opening file:', sample)
			parse_hgo(sample)
		else:
			print('Invalid input file extension.')
