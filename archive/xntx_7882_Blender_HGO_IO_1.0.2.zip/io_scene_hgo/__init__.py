bl_info = {
	'name'			: 'Crash Bandicoot: The Wrath of Cortex HGO Tools',
	'author'		: 'Inuk#9439, in collaboration with CTWOC Modding Discord',
	'version'		: (1, 0, 2),
	'blender'		: (2, 93, 1),
	'location'		: 'File > Import/Export',
	'description'	: 'Import or export a Wrath of Cortex GameCube HGO file.',
	'category'		: 'Import-Export',
}
import os
import bpy
import importlib
from bpy.props import (
	CollectionProperty,
	StringProperty	,
	BoolProperty	,
	EnumProperty	,
	FloatProperty	,
)
from bpy_extras.io_utils import (
	ImportHelper			  ,
	ExportHelper			  ,
)

from.import import_hgo, export_hgo

class ImportHGO(bpy.types.Operator, ImportHelper):
	bl_idname  = 'import_mesh.hgo'
	bl_label   = 'Import HGO'
	bl_options = {'UNDO'}
	filename_ext = '.hgo'
	files: CollectionProperty(
		name	    = 'File path',
		description = 'File path used for finding the HGO file.',
		type	    = bpy.types.OperatorFileListElement
	)
	ntbl_preserve: BoolProperty(
		name        = 'Preserve nametable',
		description = 'Include values in the import text to fully recreate the nametable. The nametable may include strings that aren\'t otherwise used by the importer. This did not have any effect on the game in my testing.'
	)
	directory: StringProperty()
	filter_glob: StringProperty(default = '*.hgo', options = {'HIDDEN'})
	def execute(self, context):
		paths = [os.path.join(self.directory, name.name) for name in self.files]
		if not paths: paths.append(self.filepath)
		importlib.reload(import_hgo)
		for path in paths: import_hgo.parse_hgo(path, ntbl_preserve = self.ntbl_preserve)
		return {'FINISHED'}
class ExportHGO(bpy.types.Operator, ExportHelper):
	bl_idname  = 'export_mesh.hgo'
	bl_label   = 'Export HGO'
	filename_ext = '.hgo'
	files: CollectionProperty(
		name	    = 'File Path',
		description = 'File path used for finding the HGO file.',
		type	    = bpy.types.OperatorFileListElement
	)
	exportblk: BoolProperty(
		name        = 'Generate .hgo.blk',
		description = 'Generate a .hgo.blk file, which contains an index of the hgo\'s chunks.',
		default     = True,
	)
	directory: StringProperty()
	def execute(self, context):
		importlib.reload(export_hgo)
		export_hgo.blender_export(self.filepath, exportblk = self.exportblk)
		return {'FINISHED'}
def menu_func_import(self, context):
	self.layout.operator(ImportHGO.bl_idname, text='HGO (.hgo)')
def menu_func_export(self, context):
	self.layout.operator(ExportHGO.bl_idname, text='HGO (.hgo)')
def register():
	bpy.utils.register_class(ImportHGO)
	bpy.utils.register_class(ExportHGO)
	bpy.types.TOPBAR_MT_file_import.append(menu_func_import)
	bpy.types.TOPBAR_MT_file_export.append(menu_func_export)
def unregister():
	bpy.utils.unregister_class(ImportHGO)
	bpy.utils.unregister_class(ExportHGO)
	bpy.types.TOPBAR_MT_file_import.remove(menu_func_import)
	bpy.types.TOPBAR_MT_file_export.remove(menu_func_export)
if __name__ == '__main__': register()