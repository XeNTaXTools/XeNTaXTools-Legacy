from os.path import join, split, splitext
from collections import namedtuple
from struct import pack
from io import BytesIO as bio
from ast import literal_eval
from math import atan
import bpy

Storechunk = namedtuple('Storechunk', 'type address')

CHUNK_TYPES = {
	b'HGOF' : 'Root',
	b'NTBL' : 'NameTable',
	b'TST0' : 'TextureSet',
	b'TSH0' : 'TextureSet Counter', # 1 int: amount of TXM0
	b'TXM0' : 'TextureSet Material',
	b'MS00' : 'MaterialSet',
	b'TAS0' : 'TexAnimSet',
	b'HGO0' : 'HGobjSet',
}
globals().update( {'C_' + k.decode('ascii'): k for k in CHUNK_TYPES} )

T_TEXANIM_VALUE		= 'texanim value'
T_TEXANIM_STRUCTS	= 'texanim structs'
T_TEXANIM_SHORTS	= 'texanim shorts'
T_BONES				= 'bones'
T_BONE_NTBL			= 'nametable offset'
T_BONE_SOURCE		= 'bone source'
T_BONE_VALUE		= 'value'
T_BONE_ROTATION		= 'rotation'
T_BONE_POSITION		= 'position'
T_BONE_UNKNOWNM		= 'unknownm'
T_BONE_UNKNOWN3		= 'unknown3'
T_C2				= 'count2 data'
T_C3				= 'count3 data'
T_LAYERS			= 'layers'
T_LAYER_SOURCE		= 'collection source'
T_LAYER_NTBL		= 'nametable offset'
T_LAYER_MESH_PB		= 'primary bone mesh sources'
T_LAYER_MESH_P		= 'primary mesh source'
T_LAYER_MESH_SB		= 'secondary bone mesh sources'
T_LAYER_MESH_S		= 'secondary mesh source'
T_POI				= 'poi'
T_POI_VALUE			= 'value'
T_POI_DATA			= 'data'
T_POI_NAME			= 'name'
T_POI_NTBL			= 'nametable offset'
T_C6				= 'count6 data'
T_BITMAPS			= 'bitmaps'
T_MATERIALS			= 'materials'
T_NTBL				= 'name table'
T_ENDFLOAT00		= 'end float 00'
T_ENDFLOAT04		= 'end float 04'
T_ENDFLOAT08		= 'end float 08'
T_ENDFLOAT0C		= 'end float 0c'
T_ENDFLOAT10		= 'end float 10'
T_ENDFLOAT14		= 'end float 14'
T_ENDFLOAT18		= 'end float 18'
T_ENDFLOAT1C		= 'end float 1c'
T_ENDFLOAT20		= 'end float 20'
T_ENDFLOAT24		= 'end float 24'
T_ENDFLOAT28		= 'end float 28'

def frgba_to_5a3twoc(fpixels, width, height, outbuffer):
	### make a new fpixels buffer that accounts for blender's reversed scanline order
	cascading = []
	for scanline in range(height):
		offset = 4*width*(height - scanline - 1)
		cascading.extend( fpixels[offset:offset + 4*width] )
	### write the rgb5a3 data
	for ymacro in range(0, height, 4):
		for xmacro in range(0, width, 4):
			for ymicro in range(4):
				for xmicro in range(4):
					offset = 4*width*(ymacro + ymicro) + 4*(xmacro + xmicro)
					r, g, b, a = cascading[offset:offset + 4]
					aprocessed = int(a*7.0)
					outbuffer.write(pack('>H',(
							  int(r*31.0) << 10
							| int(g*31.0) << 5
							| int(b*31.0)
							| 0x8000
						) if aprocessed == 7 else (
							  int(r*15.0) << 8
							| int(g*15.0) << 4
							| int(b*15.0)
							| aprocessed << 12
					)))
				
def blender_export(infilepath, exportblk = True):
	def packmeshobject(o):
		# todo: handle Ngons with more than 3 verts
		# https://blenderartists.org/t/triangulate-mesh-before-export/533998/2
			
		facesbymaterial = tuple(
			tuple(face_i for face_i, face in enumerate(o.data.polygons)
				if face.material_index == materialslot_i)
			for materialslot_i, materialslot in enumerate(o.material_slots))
			
		f.write( pack('>L', 1) ) # models
		f.write( pack('>L', 0) ) # meshtype
		f.write( pack('>3L', 0, 0, 0) )
		f.write( pack('>L', sum(map(bool, facesbymaterial))) ) # meshes; number of materials in actual use
		
		for materialslot_i, faceids in enumerate(facesbymaterial):
			if not faceids: continue
			f.write( pack('>L', materialslot_i) )
			
			###vertex
			#Vertex structure:
			# f x, z, y
			# f normx, normz, normy
			# u32 colour_argb
			# f uvx, uvy
			#uvy needs to be inverted for blender
			vertids = tuple(set(vert for face_i in faceids for vert in o.data.polygons[face_i].vertices))
			f.write( pack('>L', len(vertids)) )
			for vertid in vertids:
				# overengineered solution for UVs; retrieve all loops of a vertex and average their uvs:
				uvxlist = []
				uvylist = []
				for user in (poly for poly in o.data.polygons if vertid in poly.vertices):
					for uservert, userloop in zip(user.vertices, user.loop_indices):
						if vertid == uservert:
							uvx, uvy = o.data.uv_layers.active.data[userloop].uv
							uvxlist.append(uvx)
							uvylist.append(uvy)
				f.write( pack('>6fL2f',
					*o.data.vertices[vertid].co.xzy,
					*o.data.vertices[vertid].normal.xzy,
					0xFF000000, sum(uvxlist) / len(uvxlist), -(sum(uvylist) / len(uvylist))
				))
				
			f.write( pack('>L', 0) ) # GeomCntrl, always 0
			
			###primitives
			#Primitives structure:
			# u32	n_primitives (this is only ever 1)
			# array[n_primitives] primitives
			#
			#Primitive structure:
			# u32	type (5 for simple tris, 6 for strips)
			#if type==5:
			# u32	n_indices (if type==5, polygons==indices/3
			# array[n_indices] indices
			#else: tristrip format not investigated
			f.write( pack('>L', 1) ) # primitives
			f.write( pack('>L', 5) ) # primtype
			f.write( pack('>L', 3*len(faceids)) ) # vert_indices
			for face_i in faceids:
				f.write( pack('>3H', *(vertids.index(v_i) for v_i in o.data.polygons[face_i].vertices)) )
			
			###geomskin
			#Geomskin structure:
			# bool32	is_included (yeah, a 32-bit bool)
			#if is_included:
			# u8	type (0 or 1)
			# array[verts]	geomskins
			#
			#Type 1 geomskins:
			# float weight1
			# float weight2
			# float weight3
			# u8	boneid1
			# u8	boneid2
			# u8	boneid3
			# u8	null
			#
			#the obvious implication from this struct is that only 3 weights are allowed per vertex,
			#and the type 0 structure seems to exist to circumvent that limitation,
			#but no model uses it and so it hasn't been investigated
			f.write( pack('>L', True) ) # GeomSkin present
			f.write( pack('>B', 1) ) # type
			for vertid in vertids:
				# get the 3 most significantly weighing groups (as a failsafe), then pad out the resulting list
				groups = (*sorted(o.data.vertices[vertid].groups, key = lambda g: g.weight)[:3], None, None, None)[:3]
				f.write(pack('>3f4B',
					*(group.weight if group is not None else 0 for group in groups),
					*(group.group  if group is not None else 0 for group in groups),
					0
				))
				
			###blendshapes
			#Blendshape structure:
			# u32	shapes
			#if shapes:
			# array(u32)[shapes] shapeids
			# u32	len_shapebuffer
			# array(vector) shapebuffer
			# array(bool8)[shapes] include
			#
			#shapebuffer structure: float x, float z, float y
			#
			#shapeids & include explanation
			# include is an array of bools that determines which shapeids are represented in the buffer.
			# if 1, there is an array(vector)[verts] in the buffer. if 0, don't include anything;
			# the next 1 will have its data in the buffer placed adjacent
			# (this is done to reduce filesize, shapebuffer is pretty massive still).
			# shapeids determines the order. it's always a counter from 0 and up, so it really is redundant.
			#
			#shapebuffer explanation:
			# this is an array of array of vertex vectors. see the above explanation.
			# the size of the buffer can be calculated as 12*sum(include)*shapes == len_shapebuffer
			bshapes = o.data.shape_keys.key_blocks[1:] # split off blender's base key
			lenbshapes = len(bshapes)
			bshapes_include = [False]*lenbshapes
			for bs_i, bs in enumerate(bshapes):
				for vertid in vertids:
					if bs.data[vertid].co != o.data.vertices[vertid].co:
						bshapes_include[bs_i] = True
						break
			
			f.write( pack('>L', lenbshapes) )
			if lenbshapes:
				f.write(pack(f'>{lenbshapes}L', *range(lenbshapes) ))
				f.write(pack(f'>L', 12*sum(bshapes_include)*len(vertids) ))
				for bs_i, bs in enumerate(bshapes):
					if not bshapes_include[bs_i]: continue
					for vertid in vertids:
						f.write(pack(f'>3f', *(bs.data[vertid].co.xzy - o.data.vertices[vertid].co.xzy) ))
				f.write(pack(f'>{lenbshapes}B', *bshapes_include ))
	print('blender_export: Exported', infilepath)
	storechunks = []
	
	scene = bpy.context.scene
	coll = scene.collection
	origdata = literal_eval( bpy.data.texts[scene.name].as_string() )
	
	ntbl_preserve = T_NTBL in origdata
	if ntbl_preserve: ntbl_buffer = bio( b''.join(origdata[T_NTBL]) )
		
	with open(infilepath, 'wb') as f:
	
		storechunks.append(Storechunk(C_HGOF, 0))
		f.write( C_HGOF[::-1] + b'\0'*4 )
		
		### NAMETABLE
		ntbl_base = f.tell()
		storechunks.append(Storechunk(C_NTBL, ntbl_base))
		f.write( C_NTBL[::-1] + b'\0'*8 )
		nameoffsets_bones = []
		nameoffsets_layers= []
		nameoffsets_poi   = []
		ntbl_data_offset = f.tell() - 1 # original hgos have an off by one error too
		for bone in origdata.get(T_BONES, ()):
			if ntbl_preserve: nameoffsets_bones.append(bone[T_BONE_NTBL])
			else:
				nameoffsets_bones.append(f.tell() - ntbl_data_offset)
				f.write( bone[T_BONE_SOURCE].encode('ascii') + b'\0' )
		for layer in origdata.get(T_LAYERS, ()):
			if ntbl_preserve: nameoffsets_layers.append(layer[T_LAYER_NTBL])
			else:
				nameoffsets_layers.append(f.tell() - ntbl_data_offset)
				f.write( layer[T_LAYER_SOURCE].encode('ascii') + b'\0' )
		for poi in origdata.get(T_POI, ()):
			if ntbl_preserve: nameoffsets_poi.append(poi[T_POI_NTBL])
			else:
				nameoffsets_poi.append(f.tell() - ntbl_data_offset)
				f.write( poi[T_POI_NAME].encode('ascii') + b'\0' )
			
		ntbl_data_end = f.tell() # and then write padding, chunk length, string buffer length:
		if ntbl_data_end % 4: f.write(b'\0' * (4 - (ntbl_data_end % 4))) # padding
		ntbl_end = f.tell()
		f.seek(ntbl_base + 4); f.write( pack('>2L', ntbl_end - ntbl_base, ntbl_data_end - ntbl_base - 0xC) )
		f.seek(ntbl_end)
		
		### BITMAPS
		tst0_base = f.tell()
		storechunks.append(Storechunk(C_TST0, tst0_base))
		f.write( C_TST0[::-1] + b'\0'*4 )
		
		storechunks.append(Storechunk(C_TSH0, tst0_base + 8))
		f.write( pack('>4s2L', C_TSH0[::-1], 0xC, len(origdata[T_BITMAPS])) )
		
		for bitmapname in origdata[T_BITMAPS]:
			image = bpy.data.images[bitmapname]
			width, height = image.size
			
			storechunks.append(Storechunk(C_TXM0, f.tell()))
			f.write( pack('>4s5L', C_TXM0[::-1], 2*width*height + 4*6,
				0x81,
				width,
				height,
				2*width*height) )
			frgba_to_5a3twoc(image.pixels, width, height, f)
		tst0_end = f.tell()
		f.seek(tst0_base + 4); f.write( pack('>L', tst0_end - tst0_base) )
		f.seek(tst0_end)
			
		### MATERIALS
		materials = origdata[T_MATERIALS]
		storechunks.append(Storechunk(C_MS00, f.tell()))
		f.write( pack('>4s2L', C_MS00[::-1], 0xC + 0x54*len(materials), len(materials)) )
		for ( materialname,
				ms00_v0,	ms00_v1,	ms00_v2,	ms00_v3,
				ms00_v4,	diffuse_r,	diffuse_g,	diffuse_b,
				ms00_v8,	ms00_v9,	ms00_v10,	ms00_v11,
				ms00_v12,	ms00_v13,	texture_id,	ms00_v15,
				ms00_v16,	ms00_v17,	ms00_v18,	ms00_v19, ms00_v20,
		) in materials:
			f.write(pack('>5L5f2L2fl6L',
				ms00_v0,	ms00_v1,	ms00_v2,	ms00_v3,
				ms00_v4,	*bpy.data.materials[materialname].diffuse_color[:3],
				ms00_v8,	ms00_v9,	ms00_v10,	ms00_v11,
				ms00_v12,	ms00_v13,	texture_id,	ms00_v15,
				ms00_v16,	ms00_v17,	ms00_v18,	ms00_v19, ms00_v20,
			))
			
		### TEXANIMS
		storechunks.append(Storechunk(C_TAS0, f.tell()))
		f.write( pack('>4s3L', C_TAS0[::-1], 0x14 + 0x20*len(origdata[T_TEXANIM_STRUCTS]) + 2*len(origdata[T_TEXANIM_SHORTS]),
			len(origdata[T_TEXANIM_STRUCTS]),
			origdata[T_TEXANIM_VALUE] ) )
		for struct in origdata[T_TEXANIM_STRUCTS]: f.write( bytes.fromhex(struct) )
		f.write( pack('>L', len(origdata[T_TEXANIM_SHORTS])) )
		for short in origdata[T_TEXANIM_SHORTS]: f.write( pack('>H', short) )
		
		### HGO
		hgo0_base = f.tell()
		storechunks.append(Storechunk(C_HGO0, hgo0_base))
		f.write( pack('>4sL', C_HGO0[::-1], 0) )
		
		for arma in coll.objects:
			if arma.type == 'ARMATURE': break
		else: raise AssertionError('There are no armatures in the scene collection.')
		
		savedbones = origdata[T_BONES]
		f.write( pack('>B', len(arma.data.bones)) )
		if len(arma.data.bones):
			#for bone_i, bone in enumerate(arma.data.bones):
			for bone_i, savedbone in enumerate(savedbones):
				bone     = arma.data.bones[savedbone[T_BONE_SOURCE]]
				val0     = savedbone.get(T_BONE_VALUE, 1)
				rotation = savedbone.get(T_BONE_ROTATION, (
					1, 0, 0, 0,
					0, 1, 0, 0,
					0, 0, 1, 0,
					*-bone.head.xzy, 1,
				))
				location = savedbone.get(T_BONE_POSITION, (
					1, 0, 0, 0,
					0, 1, 0, 0,
					0, 0, 1, 0,
					*(atan(t + h) for h, t in zip(bone.head.xzy, bone.tail.xzy)), 1, # undo expression from import
				))
				munknown = savedbone.get(T_BONE_UNKNOWNM, (
					1, 0, 0, 0,
					0, 1, 0, 0,
					0, 0, 1, 0,
					0, 0, 0, 1,
				))
				unknown3 = savedbone.get(T_BONE_UNKNOWN3, (0, 0, 0))
				
				f.write(pack('>B'  , val0    ))
				f.write(pack('>16f', *rotation))
				f.write(pack('>16f', *location))
				f.write(pack('>16f', *munknown))
				f.write(pack('>L2f', *unknown3))
				f.write(pack('>b'  , arma.data.bones.find(bone.parent.name) if bone.parent is not None else -1))
				f.write(pack('>L'  , nameoffsets_bones[bone_i]))
				
			countbyte2_data = bytes.fromhex(origdata.get(T_C2, ''))
			f.write(pack('>B', len(countbyte2_data)))
			f.write(countbyte2_data)
				
			countbyte3_data = bytes.fromhex(origdata.get(T_C3, ''))
			f.write(pack('>B', len(countbyte3_data)))
			f.write(countbyte3_data)
				
			layers = origdata.get(T_LAYERS, ())
			f.write(pack('>B', len(layers)))
			for layer_i, layer in enumerate(layers):
				f.write(pack('>L', nameoffsets_layers[layer_i])) # name offset
				
				layercol = coll.children[layer[T_LAYER_SOURCE]]
				primarybonemeshes = layer.get(T_LAYER_MESH_PB, ())
				f.write( pack('>B', bool(primarybonemeshes)) )
				for moname in primarybonemeshes:
					packmeshobject(layercol.objects[moname])
				
				primary = layer.get(T_LAYER_MESH_P)
				f.write( pack('>B', primary is not None) )
				if primary is not None: packmeshobject(layercol.objects[primary])
				
				secondarybonemeshes = layer.get(T_LAYER_MESH_SB, ())
				f.write( pack('>B', bool(secondarybonemeshes)) )
				for moname in secondarybonemeshes:
					packmeshobject(layercol.objects[moname])
				
				secondary = layer.get(T_LAYER_MESH_S)
				f.write( pack('>B', secondary is not None) )
				if secondary is not None: packmeshobject(layercol.objects[secondary])
				
			
			pois = origdata.get(T_POI, ())
			f.write(pack('>B', len(pois)))
			for poi_i, poi in enumerate(pois):
				p_value = poi[T_POI_VALUE]
				p_data = bytes.fromhex(poi[T_POI_DATA])
				p_nameoffset = nameoffsets_poi[poi_i]
				f.write(pack('>B64sL', p_value, p_data, p_nameoffset))
			
			countbyte6_data = origdata.get(T_C6, ())
			f.write(pack('>B', len(countbyte6_data)))
			for c61, c62, c63, c6last in countbyte6_data:
				c61_b, c62_b = bytes.fromhex(c61), bytes.fromhex(c62)
				f.write(pack('>B', len(c61_b) // 0x30))
				f.write(c61_b)
				f.write(pack('>B', len(c62_b) // 0x40))
				f.write(c62_b)
				f.write(pack('>B', len(c63)))
				for c631, c632 in c63:
					c631_b, c632_b = bytes.fromhex(c631), bytes.fromhex(c632)
					f.write(pack('>L', len(c631_b) // 16))
					f.write(c631_b)
					f.write(pack('>L', len(c632_b) // 16))
					f.write(c632_b)
				f.write(pack('>B', c6last))
		f.write(pack('>11f',
			origdata.get(T_ENDFLOAT00, 0),
			origdata.get(T_ENDFLOAT04, 0),
			origdata.get(T_ENDFLOAT08, 0),
			origdata.get(T_ENDFLOAT0C, 0),
			origdata.get(T_ENDFLOAT10, 0),
			origdata.get(T_ENDFLOAT14, 0),
			origdata.get(T_ENDFLOAT18, 0),
			origdata.get(T_ENDFLOAT1C, 0),
			origdata.get(T_ENDFLOAT20, 0),
			origdata.get(T_ENDFLOAT24, 0),
			origdata.get(T_ENDFLOAT28, 0),
		))
		hgo0_end = f.tell()
		f.seek(hgo0_base + 4); f.write( pack('>L', hgo0_end - hgo0_base + (-hgo0_end % 4)) ) # (-hgo0_end % 4) = calculate padding.
		
		# pad hgof size regardless of filesize
		f.seek(4); f.write( pack('>L', hgo0_end + (-hgo0_end % 4)) )
		
	if exportblk:
		with open(infilepath + '.blk', 'wb') as f:  # this is little endian, unlike HGO
			for storechunk in storechunks:
				f.write( pack('<4sL', storechunk.type, storechunk.address + 4) )
				