/*
	ACS Resouce Extractor
	Written by WRS (forum.xentax.com)
	
	Extracts BMP and WAV data from the Agent Character Storage format used by Microsoft Agents
	
	Bitmap decoding function from the DoubleAgent project (Cinnamon Software, Inc.)
	
	History
		v0.1		Initial version
*/

#include <windows.h>
#include <WinDef.h>
#include <stdio.h>

/**** START DOUBLEAGENT ****/

typedef const BYTE * LPCBYTE;
typedef const WORD * LPCWORD;
typedef const DWORD * LPCDWORD;
typedef const GUID * LPCGUID;

ULONG DecodeData (LPCVOID pSrcData, ULONG pSrcSize, LPVOID pTrgData, ULONG pTrgSize)
{
	LPCBYTE	lSrcPtr = (LPCBYTE)pSrcData;
	LPCBYTE	lSrcEnd = lSrcPtr + pSrcSize;
	LPBYTE	lTrgPtr = (LPBYTE)pTrgData;
	LPBYTE	lTrgEnd = lTrgPtr + pTrgSize;
	DWORD	lSrcQuad;
	BYTE	lTrgByte;
	DWORD	lBitCount = 0;
	DWORD	lSrcOffset;
	DWORD	lRunLgth;
	DWORD	lRunCount;

	if	(
			(pSrcSize <= 7)
		||	(*lSrcPtr != 0)
		)
	{
		return 0;
	}

	for	(lBitCount = 1; (*(lSrcEnd-lBitCount) == 0xFF); lBitCount++)
	{
		if	(lBitCount > 6)
		{
			break;
		}
	}
	if	(lBitCount < 6)
	{
		return 0;
	}

	lBitCount = 0;
	lSrcPtr += 5;

	while	(
				(lSrcPtr < lSrcEnd)
			&&	(lTrgPtr < lTrgEnd)
			)
	{
		lSrcQuad = *(LPCDWORD)(lSrcPtr - sizeof(DWORD));

		if	(lSrcQuad & (1 << LOWORD(lBitCount)))
		{
			lSrcOffset = 1;

			if	(lSrcQuad & (1 << LOWORD(lBitCount+1)))
			{
				if	(lSrcQuad & (1 << LOWORD(lBitCount+2)))
				{
					if	(lSrcQuad & (1 << LOWORD(lBitCount+3)))
					{
						lSrcQuad >>= LOWORD(lBitCount+4);
						lSrcQuad &= 0x000FFFFF;
						if	(lSrcQuad == 0x000FFFFF)
						{
							break;
						}
						lSrcQuad += 4673;
						lBitCount += 24;

						lSrcOffset = 2;
					}
					else
					{
						lSrcQuad >>= LOWORD(lBitCount+4);
						lSrcQuad &= 0x00000FFF;
						lSrcQuad += 577;
						lBitCount += 16;
					}
				}
				else
				{
					lSrcQuad >>= LOWORD(lBitCount+3);
					lSrcQuad &= 0x000001FF;
					lSrcQuad += 65;
					lBitCount += 12;
				}
			}
			else
			{
				lSrcQuad >>= LOWORD(lBitCount+2);
				lSrcQuad &= 0x0000003F;
				lSrcQuad += 1;
				lBitCount += 8;
			}

			lSrcPtr += (lBitCount/8);
			lBitCount &= 7;
			lRunLgth = *(LPCDWORD)(lSrcPtr - sizeof(DWORD));
			lRunCount = 0;
			while	(lRunLgth & (1 << LOWORD(lBitCount+lRunCount)))
			{
				lRunCount++;
				if	(lRunCount > 11)
				{
					break;
				}
			}

			lRunLgth >>= LOWORD(lBitCount+lRunCount+1);
			lRunLgth &= (1 << lRunCount) - 1;
			lRunLgth += 1 << lRunCount;
			lRunLgth += lSrcOffset;
			lBitCount += lRunCount*2+1;

			if	(lTrgPtr + lRunLgth > lTrgEnd)
			{
				break;
			}
			if	(lTrgPtr - lSrcQuad < pTrgData)
			{
				break;
			}
			while	((long)lRunLgth > 0)
			{
				lTrgByte = *(lTrgPtr - lSrcQuad);
				*(lTrgPtr++) = lTrgByte;
				lRunLgth--;
			}
		}
		else
		{
			lSrcQuad >>= LOWORD(lBitCount+1);
			lBitCount += 9;

			lTrgByte = LOBYTE(lSrcQuad);
			*(lTrgPtr++) = lTrgByte;
		}

		lSrcPtr += lBitCount/8;
		lBitCount &= 7;
	}
	
	return (ULONG)(lTrgPtr - (LPBYTE)pTrgData);
}


int DecodeImage (LPCVOID pSrcBits, ULONG pSrcCount, LPBYTE pTrgBits, ULONG pTrgCount)
{
	// modified
	
	return (DecodeData (pSrcBits, pSrcCount, pTrgBits, pTrgCount) == pTrgCount);
}

/**** END DOUBLEAGENT ****/

// my own research from here (except the voice style branch) :

struct ACS_HEADER // 36-bytes
{
	DWORD magic;
	DWORD pDesc;	DWORD descSize;
	DWORD pAni;		DWORD aniSize;
	DWORD pBmp;		DWORD bmpSize; // >= 4
	DWORD pWav;		DWORD wavSize; // >= 4
};

struct ACS_RESOURCE // 12-bytes
{
	DWORD offset;
	DWORD size;
	DWORD unknown;
};

#pragma pack(push)
#pragma pack(1)
	struct ACS_BMP_HEADER // 10-bytes
	{
		unsigned char un;
		WORD cx; // width
		WORD cy; // height
		unsigned char isCmp;
		DWORD size;	
	};
#pragma pack(pop)

char palette[ 1024 ]; // 256 colors

void readPallete( struct ACS_HEADER *head, char *acsBuf )
{
	char *pAcs;
	DWORD styleflags, fntname, hastable;

	// Seek to description
	pAcs = acsBuf + head->pDesc;
	
	pAcs += 12; // size of language section header
	pAcs += 16; // guid
	pAcs += 5; // width, height, transparency
	
	// read style in (voice, balloon and other optional ones)
	styleflags = *(DWORD *)pAcs; pAcs += sizeof( DWORD );
	
	pAcs += 4; // unknown value 00000002
	
	#define AXS_VOICE_NONE 		    0x00000010
	#define AXS_VOICE_TTS 		    0x00000020
	
	#define AXS_BALLOON_NONE 	    0x00000100
	#define AXS_BALLOON_ROUNDRECT	0x00000200
	
	// if voice
	if( (styleflags & AXS_VOICE_TTS) != 0 )
	{
		pAcs += 16 + 16 + 4 + 2;
		
		if(*pAcs++)
		{
			pAcs += 2;
			
			// NOTE: NOT FONT NAME
			
			fntname = *(DWORD *)pAcs; pAcs += sizeof( DWORD );
			
			if( fntname > 0)
			{
				pAcs += (fntname * 2);
				pAcs += 2; // null-terminated unicode
			}
			
			pAcs += 2 + 2;
			
			// NOTE: NOT FONT NAME
			
			fntname = *(DWORD *)pAcs; pAcs += sizeof( DWORD );
			
			if( fntname > 0)
			{
				pAcs += (fntname * 2);
				pAcs += 2; // null-terminated unicode
			}
		}
	}
	
	// if balloon
	if( (styleflags & AXS_BALLOON_ROUNDRECT) != 0 )
	{
		pAcs += 1 + 1 + 4 + 4 + 4; // balloon info
		
		// read font name
		fntname = *(DWORD *)pAcs; pAcs += sizeof( DWORD );
		
		if( fntname > 0)
		{
			pAcs += (fntname * 2);
			pAcs += 2; // null-terminated unicode
		}
		
		pAcs += 4 + 2 + 2 + 2;
	}
	
	#undef AXS_BALLOON_ROUNDRECT
	#undef AXS_BALLOON_NONE
	
	#undef AXS_VOICE_TTS
	#undef AXS_VOICE_NONE
	
	hastable = *(DWORD *)pAcs; pAcs += sizeof( DWORD );
	
	if( hastable == 256 )
	{
		memcpy( palette, pAcs, 256 * 4 );
		pAcs += (256 * 4);
		
		printf("Got bitmap palette\n\n");
	}
	else
	{
		printf("Warning: Unknown color table format (%i bytes)\n", hastable );
		memset( palette, 0, 1024 );
	}
	
	// then icon stuff
}

FILE *bakeBitmapHeader( struct ACS_BMP_HEADER *bmpres, DWORD nBitmap )
{
	FILE *fTmp;
	BITMAPFILEHEADER bmfh;
	BITMAPINFOHEADER bmih;
	char fName[8*2 +5];
	
	sprintf( fName, "%08X.bmp\0", nBitmap );
	
	if( fTmp = fopen( fName, "wb" ) )
	{
		// make headers
		bmfh.bfType			= 0x4D42; // "BM"
		bmfh.bfOffBits		= sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER) + 1024;
//		bmfh.bfSize			= bmfh.bfOffBits + (bmpres->cx * bmpres->cy * 4);
		bmfh.bfReserved1	= 0;
		bmfh.bfReserved2	= 0;
		
		bmih.biSize			= sizeof(BITMAPINFOHEADER);
		bmih.biWidth		= bmpres->cx;
		bmih.biHeight		= bmpres->cy;
		bmih.biPlanes		= 1;
		bmih.biBitCount		= 8;
		bmih.biCompression	= 0;
		
		// Should handle uncompressed images too:
		bmih.biSizeImage	= ( ( bmpres->isCmp == 1)  ? (bmpres->cx * bmpres->cy * 4) : bmpres->size );
		// Then updated the total filesize
		bmfh.bfSize			= bmfh.bfOffBits + bmih.biSizeImage;
		
		bmih.biXPelsPerMeter= 0;
		bmih.biYPelsPerMeter= 0;
		bmih.biClrUsed		= 0;
		bmih.biClrImportant	= 0;
		
		// write headers
		fwrite( &bmfh, 1, sizeof(BITMAPFILEHEADER), fTmp );
		fwrite( &bmih, 1, sizeof(BITMAPINFOHEADER), fTmp );
		
		// write pallete
		fwrite( palette, 1, 1024, fTmp );		
	}
	
	return fTmp;
}

void saveBitmap( struct ACS_RESOURCE *reshead, char *acsBuf, DWORD nBitmap )
{
	char *pAcs;
	struct ACS_BMP_HEADER bmpres;
	DWORD mBitsSize;
	char *mBits;
	FILE *fTmp;
	
	// Seek to bitmap resource
	pAcs = acsBuf + reshead->offset;

	// Read bitmap resource header
	bmpres = *(struct ACS_BMP_HEADER *)pAcs; pAcs += sizeof( struct ACS_BMP_HEADER ); 
	
	// Check compression flag
	if( bmpres.isCmp == 1 )
	{
		mBitsSize = (((bmpres.cx + 3) / 4) * 4) * bmpres.cy;

		if( mBits = (char *)malloc( mBitsSize) )
		{
			if( DecodeImage (pAcs, bmpres.size, mBits, mBitsSize) )
			{
				if( fTmp = bakeBitmapHeader( &bmpres, nBitmap ) )
				{
					fwrite( mBits, 1, mBitsSize, fTmp );
					fclose( fTmp );
					
					printf("Saved %08x.bmp (compressed, %ix%i)\n", nBitmap, bmpres.cx, bmpres.cy);
				}				
			}
			
			free( mBits );
		}
	}
	else
	{
		// uncompressed
		
		if( fTmp = bakeBitmapHeader( &bmpres, nBitmap ) )
		{
			fwrite( pAcs, 1, bmpres.size, fTmp );
			fclose( fTmp );
			
			printf("Saved %08x.bmp (%ix%i)\n", nBitmap, bmpres.cx, bmpres.cy);
		}	
	}
}

void readBitmaps( struct ACS_HEADER *head, char *acsBuf )
{
	char *pAcs;
	DWORD bmps, i;
	struct ACS_RESOURCE reshead;
	
	// Seek to bitmap headers
	pAcs = acsBuf + head->pBmp;
	
	// Read bitmap header info:
	
	bmps = *(DWORD *)pAcs; pAcs += sizeof( DWORD );
	
	if( bmps > 0 )
	{
		printf("Found %i image header(s)\n", bmps);
		
		for( i = 0; i < bmps; i++ )
		{
			// Read bitmap header
			reshead = *(struct ACS_RESOURCE *)pAcs; pAcs += sizeof( struct ACS_RESOURCE );
			
			// Process bitmap data
			saveBitmap( &reshead, acsBuf, i );
		}
	}
	else
	{
		printf("No bitmap data to extact\n");
	}
}

void saveWav( struct ACS_RESOURCE *wavhead, char *acsBuf, DWORD nWav )
{
	char *pAcs;
	FILE *fTmp;
	char fName[8*2 +5];
	
	sprintf( fName, "%08X.wav\0", nWav );
	
	if( fTmp = fopen( fName, "wb" ) )
	{
		// Seek to sfx resource
		pAcs = acsBuf + wavhead->offset;

		fwrite( pAcs, 1, wavhead->size, fTmp );
		fclose( fTmp );
		
		printf("Saved %08x.wav\n", nWav);
	}
}

void readWavs( struct ACS_HEADER *head, char *acsBuf )
{
	char *pAcs;
	DWORD wavs, i;
	struct ACS_RESOURCE reshead;
	
	// Seek to wav headers
	pAcs = acsBuf + head->pWav;
	
	// Read wav header info:
	
	wavs = *(DWORD *)pAcs; pAcs += sizeof( DWORD );
	
	if( wavs > 0 )
	{
		printf("Found %i sfx header(s)\n", wavs);
		
		for( i = 0; i < wavs; i++ )
		{
			// Read wav header
			reshead = *(struct ACS_RESOURCE *)pAcs; pAcs += sizeof( struct ACS_RESOURCE );
			
			// Process bitmap data
			saveWav( &reshead, acsBuf, i );
		}
	}
	else
	{
		printf("No sfx data to extact\n");
	}
}

void parseAcs( char *acsBuf )
{
	struct ACS_HEADER head;
	
	// Read ACS header
	head = *(struct ACS_HEADER *)acsBuf;
	
	if( head.magic == 0xABCDABC3 )
	{
	
		// Buffers the color table
		readPallete( &head, acsBuf );

		// Parses all the bitmaps
		readBitmaps( &head, acsBuf );
		
		// Parses all the sfx
		readWavs( &head, acsBuf );
		
	}
	else
	{
		printf("Unknown ACS version\n");
	}
}


char *BufferFile( const char *fn )
{
	long size;
	FILE *fTmp;
	char *buf;

	if( !( fTmp = fopen( fn, "rb" ) ) )
	{
		printf( "Could not open file: %s\n", fn );
		return NULL;
	}
	else
	{
		fseek( fTmp, 0, SEEK_END );
		size = ftell( fTmp );
		fseek( fTmp, 0, SEEK_SET );
		
		if( buf = (char *)malloc( size ) )
		{
			fread( buf, 1, size, fTmp );
			fclose( fTmp );
			
			return buf;
		}
		
		fclose( fTmp );
		
		printf( "Could not buffer file: %s (%i bytes)\n", fn, size );
		return NULL;
	}
}

int main(int argc, char **argv)
{
	char *buf;
	
	printf("ACS Resouce Extractor\n");
	printf("Written by WRS (forum.xentax.com)\n\n");
	
	printf("Using bitamp decoding from DoubleAgent (Cinnamon Software Inc.)\n\n");
	
	if( argc == 2 )
	{
		// try buffering file
		if( buf = BufferFile( argv[1] ) )
		{
			// try parsing file
			parseAcs( buf );
			free( buf );
		}
		else
		{
			printf("Unable to parse ACS data\n");
		}
	}
	else
	{
		printf("Usage:\n\t%s <acs file>\n\n", argv[0]);
	}
	
	return 0;
}
