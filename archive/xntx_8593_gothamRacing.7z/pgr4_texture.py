from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Xbox swizzled texture", ".pgrt")
	noesis.setHandlerTypeCheck(handle, noeCheckGeneric)
	noesis.setHandlerLoadRGBA(handle, MUA2LoadRGBA)
	#noesis.logPopup()
	return 1

def MUA2LoadRGBA(data, texList):
    bs = NoeBitStream(data)
    imgWidth = bs.readInt()
    imgHeight = bs.readInt()
    imgformat = bs.readInt()
    datasize = len(data) - 12
    #bs.seek(0x1000, NOESEEK_ABS)
    data = bs.readBytes(datasize)
    if imgformat == 4:
        texFmt = noesis.NOESISTEX_DXT1
        data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 8)
    elif imgformat == 7:
        texFmt = noesis.NOESISTEX_DXT5
        data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 16)
    elif imgformat == 10:
        data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 16)
        data = rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_ATI2)
        texFmt = noesis.NOESISTEX_RGBA32
    else:
        texFmt = noesis.NOESISTEX_DXT5
        data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 16)

    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1
