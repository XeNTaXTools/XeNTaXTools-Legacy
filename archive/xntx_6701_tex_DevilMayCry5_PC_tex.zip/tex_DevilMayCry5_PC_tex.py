﻿from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Devil may cry 5 [PC]", ".tex",)
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1
        
def noepyCheckType(data):
    bs = NoeBitStream(data)
    if bs.readUInt() != 0x584554: return 0
    return 1

def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.seek(0x8)
    imgWidth = bs.readUShort()
    imgHeight = bs.readUShort()
    print(imgWidth, "X", imgHeight)
    bs.seek(0x2, 1)
    mips = bs.readByte() #??
    bs.readByte()
    imgFmt = bs.readUInt()
    print(hex(imgFmt), ":format")
    bs.seek(0xC, 1)
    dataOff = bs.readUInt()
    bs.seek(0x8, 1)
    datasize = bs.readUInt()
    bs.seek(dataOff)
    print(hex(datasize), ":size")
    data = bs.readBytes(datasize)     
    #DXT1
    if imgFmt == 0x47 or imgFmt == 0x48:
        texFmt = noesis.NOESISTEX_DXT1
	#ATI1
    elif imgFmt == 0x50:
	    data = rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_ATI1)
	    texFmt = noesis.NOESISTEX_RGBA32
    #BC7
    elif imgFmt == 0x62 or imgFmt == 0x63:
        data = rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_BC7)
        texFmt = noesis.NOESISTEX_RGBA32
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1
    