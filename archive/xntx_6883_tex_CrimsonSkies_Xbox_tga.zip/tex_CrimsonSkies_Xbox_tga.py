from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Crimson Skies (Xbox)", ".tga")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
	#noesis.logPopup()
	return 1

def noepyCheckType(data):
    return 1
	
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    imgWidth = bs.readUShort()            
    imgHeight = bs.readUShort()           
    numMips = bs.readUByte()
    unk = bs.readByte()
    unk = bs.readByte()
    imgFmt = bs.readUInt()
    print(imgWidth, "x", imgHeight, "-", imgFmt, ":format")
    datasize = bs.readUInt()            
    data = bs.readBytes(datasize)      
    #DXT1
    if imgFmt == 1:
        texFmt = noesis.NOESISTEX_DXT1
    #DXT5
    elif imgFmt == 5:
        texFmt = noesis.NOESISTEX_DXT5
    #RGB565 ?
    elif imgFmt == 14:
        untwid = bytearray()
        for x in range(imgWidth):
            for y in range(imgHeight):
                idx = noesis.morton2D(x, y)
                untwid += data[idx * 2:idx * 2 + 4]
        data = rapi.imageDecodeRaw(untwid, imgWidth, imgHeight, "g16 b0 r16 a0")
        texFmt = noesis.NOESISTEX_RGBA32
    #unknown, not handled
    else:
        print("WARNING: Unhandled image format " + repr(imgFmt) + " - " + repr(imgWidth) + "x" + repr(imgHeight) + " - " + repr(len(data)))
        return None
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1