
#include "arc.h"

//---------------------------------------------------------> main()

bool main()
{
	//+------------------------------------------------------------------------------> Re5Patch

	printf("\n| Surveyor's Resident Evil 5 filename patcher\n");
	printf("| Septembre 2009\n\n");

	char strDir[512] = {0};
	GetCurrentDirectory(unsigned int(strlen(strDir) - 1), strDir);
	PatchAllArcFilenames(strDir);

	//+------------------------------------------------------------------------------> Re5UnPatch

	//printf("\n| Surveyor's Resident Evil 5 filename patcher\n");
	//printf("| Septembre 2009\n\n");

	//char strDir[512] = {0};
	//GetCurrentDirectory(unsigned int(strlen(strDir) - 1), strDir);
	//UnPatchAllArcFilenames(strDir);

	return true;
}
