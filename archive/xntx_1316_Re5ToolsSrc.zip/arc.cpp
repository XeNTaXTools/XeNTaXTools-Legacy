
#include "arc.h"

//+-----------------------------------------------------------> PatchArcFilnames()
// will patch the filenames inside the arc so that they'll no longer
// be loaded by the game exe, instead the extracted files will be 
// used. the way it's done is simple: replace the 1st filename character
// by # and mark the filename as patched in the 61st char, the 62nd char
// will hold the altered 1st char for further restitution purposes

bool PatchArcFilenames(const char *strArc)
{
	// open the file
	FILE *pFile = fopen(strArc, "rb+wb");
	if(!pFile)
	{
		printf("Can't open ARC file [%s] !\n", strArc);
		return false;
	}

	// read the header
	cArcHeader hdr;
	fread(&hdr, sizeof(cArcHeader), 1, pFile);
	if(hdr.uiTag != 0x00435241)
	{
		fclose(pFile);
		return true;
	}
	printf("%s\n", strArc);

	// read the file info
	cArcFileInfo *pInfo = new cArcFileInfo[hdr.usFileNum];
	fread(pInfo, sizeof(cArcFileInfo), hdr.usFileNum, pFile);

	// go through all the files
	for(unsigned short a = 0; a < hdr.usFileNum; a++)
	{
		if(!pInfo[a].strName[61])
		{
			// get the extension
			char strExt[8] = {0};
			switch(pInfo[a].uiExtension)
			{
			case ARCEXT_SHADER:
			//case ARCEXT_TEXTURE:
			case ARCEXT_MOTION:
			case ARCEXT_MODEL:
			case ARCEXT_VIBRATION:
			case ARCEXT_MESSAGE:
			case ARCEXT_LSP:
			case ARCEXT_SDL:
			case ARCEXT_IDM:
			case ARCEXT_STP:
			case ARCEXT_MTG:
			case ARCEXT_LCM:
			case ARCEXT_JEX:
			case ARCEXT_CHN:
			case ARCEXT_AHC:
			case ARCEXT_HIT:
			//case ARCEXT_RTEXTURE:
			//case ARCEXT_EFFECT_EAN:
			//case ARCEXT_EFFECT_EFL:
			//case ARCEXT_EFFECT_EFS:
			//case ARCEXT_EFFECT_RTT:
			//case ARCEXT_EFFECT_AEF:
			//case ARCEXT_EFFECT_ADH:
			//case ARCEXT_EFFECT_CEF:
			case ARCEXT_SOUND_SPC:
			case ARCEXT_SOUND_SRD:
			case ARCEXT_SOUND_SRQ:
			case ARCEXT_SOUND_STQ:
			case ARCEXT_SOUND_REVWIN:
			case ARCEXT_SOUND_EQU:
			case ARCEXT_SOUND_SCS:
			case ARCEXT_SOUND_SDS:
			case ARCEXT_SOUND_MSE:
			case ARCEXT_SOUND_ASE:
			case ARCEXT_SOUND_SNGW:
			case ARCEXT_SBC:

			//case ARCEXT_CCL:
			//case ARCEXT_HAVOK:
			//case ARCEXT_FSM:
			//case ARCEXT_NAV:
			//case ARCEXT_WAY:
			//case ARCEXT_OBJ:
			//case ARCEXT_SHP:
			//case ARCEXT_SHW:
			//case ARCEXT_CDG:
			//case ARCEXT_UNK08:
			//case ARCEXT_UNK09:
			//case ARCEXT_UNK12:
			//case ARCEXT_UNK14:
			//case ARCEXT_UNK15:
			//case ARCEXT_UNK17:
			//case ARCEXT_UNK18:
			//case ARCEXT_UNK19:
			//case ARCEXT_UNK20:
			//case ARCEXT_UNK21:
			//case ARCEXT_UNK24:
			//case ARCEXT_UNK26:
			//case ARCEXT_UNK29:
			//case ARCEXT_UNK30:
			//case ARCEXT_UNK34:
			//case ARCEXT_UNK35:
			//case ARCEXT_UNK36:
			//case ARCEXT_SOUND_SND12:
			//case ARCEXT_SOUND_SND13:
				{
					// save the 1st char in the 62nd position
					pInfo[a].strName[62] = pInfo[a].strName[0];

					// alter the 1st char
					pInfo[a].strName[0] = '#';

					// mark the filename as modified
					pInfo[a].strName[61] = 1;
				}
				break;
			}
		}
	}

	// write back the modified header data
	fseek(pFile, 8, SEEK_SET);
	fwrite(pInfo, sizeof(cArcFileInfo), hdr.usFileNum, pFile);
	fclose(pFile);

	delete[] pInfo;
	pInfo = NULL;
	return true;
}

//+-----------------------------------------------------------> PatchAllArcFilenames()

void PatchAllArcFilenames(char *rep)
{
    WIN32_FIND_DATA FindFileData;
    char path[MAX_PATH];
    strcpy(path,rep);
	//printf("%s\n", rep);
    strcat(path,"\\*.*");
    HANDLE hFind = FindFirstFile(path, &FindFileData);
    if (hFind==INVALID_HANDLE_VALUE)
        return;
	// if we found a directory then process this directory right away
    if(strcmp(FindFileData.cFileName,".")!=0 && strcmp(FindFileData.cFileName,"..")!=0)
    {
        strcpy(path, rep);
        strcat(path, "\\");
        strcat(path, FindFileData.cFileName);
        PatchAllArcFilenames(path);
    }
	// find all the files in this directory
    DWORD a = 0;
    while(a != ERROR_NO_MORE_FILES)
    {
        if(!FindNextFile(hFind, &FindFileData))
            a = GetLastError();
        else
        {
            if(strcmp(FindFileData.cFileName,".")!=0 && strcmp(FindFileData.cFileName,"..")!=0)
            {
                strcpy(path,rep);
                strcat(path,"\\");
                strcat(path,FindFileData.cFileName);
                if (FindFileData.dwFileAttributes == FILE_ATTRIBUTE_DIRECTORY)
                    PatchAllArcFilenames(path);
                else
                {
					char strData[512] = {0};
					sprintf(strData, "%s\\%s", rep, FindFileData.cFileName);
					PatchArcFilenames(strData);
                }
            }
        }
    }
    FindClose(hFind);
}

//+-----------------------------------------------------------> UnPatchAllArcFilenames()

bool UnPatchArcFilenames(const char *strArc)
{
	// open the file
	FILE *pFile = fopen(strArc, "rb+wb");
	if(!pFile)
	{
		printf("Can't open ARC file [%s] !\n", strArc);
		return false;
	}

	// read the header
	cArcHeader hdr;
	fread(&hdr, sizeof(cArcHeader), 1, pFile);
	if(hdr.uiTag != 0x00435241)
	{
		fclose(pFile);
		return true;
	}
	printf("%s\n", strArc);

	// read the file info
	cArcFileInfo *pInfo = new cArcFileInfo[hdr.usFileNum];
	fread(pInfo, sizeof(cArcFileInfo), hdr.usFileNum, pFile);

	// go through all the files
	for(unsigned short a = 0; a < hdr.usFileNum; a++)
	{
		if(pInfo[a].strName[61])
		{
			pInfo[a].strName[0] = pInfo[a].strName[62];
			pInfo[a].strName[62] = 0;
			pInfo[a].strName[61] = 0;
		}
	}

	// write back the modified header data
	fseek(pFile, 8, SEEK_SET);
	fwrite(pInfo, sizeof(cArcFileInfo), hdr.usFileNum, pFile);
	fclose(pFile);

	delete[] pInfo;
	pInfo = NULL;
	return true;
}

//+-----------------------------------------------------------> UnPatchAllArcFilenames()

void UnPatchAllArcFilenames(char *rep)
{
    WIN32_FIND_DATA FindFileData;
    char path[MAX_PATH];
    strcpy(path,rep);
	//printf("%s\n", rep);
    strcat(path,"\\*.*");
    HANDLE hFind = FindFirstFile(path, &FindFileData);
    if (hFind==INVALID_HANDLE_VALUE)
        return;
	// if we found a directory then process this directory right away
    if(strcmp(FindFileData.cFileName,".")!=0 && strcmp(FindFileData.cFileName,"..")!=0)
    {
        strcpy(path, rep);
        strcat(path, "\\");
        strcat(path, FindFileData.cFileName);
        UnPatchAllArcFilenames(path);
    }
	// find all the files in this directory
    DWORD a = 0;
    while(a != ERROR_NO_MORE_FILES)
    {
        if(!FindNextFile(hFind, &FindFileData))
            a = GetLastError();
        else
        {
            if(strcmp(FindFileData.cFileName,".")!=0 && strcmp(FindFileData.cFileName,"..")!=0)
            {
                strcpy(path,rep);
                strcat(path,"\\");
                strcat(path,FindFileData.cFileName);
                if (FindFileData.dwFileAttributes == FILE_ATTRIBUTE_DIRECTORY)
                    UnPatchAllArcFilenames(path);
                else
                {
					char strData[512] = {0};
					sprintf(strData, "%s\\%s", rep, FindFileData.cFileName);
					UnPatchArcFilenames(strData);
                }
            }
        }
    }
    FindClose(hFind);
}
