
#ifndef _MAIN_H
#define _MAIN_H

#include <stdio.h>
#include <windows.h>
#include "zlib/unzip.h"

#pragma comment(lib, "zlib/zlibstat.lib")

#endif