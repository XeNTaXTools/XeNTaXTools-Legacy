
#include "main.h"

//+-----------------------------------------------------------> cArcHeader

struct cArcHeader
{
	unsigned int				uiTag;
	unsigned short				usVersion;
	unsigned short				usFileNum;
};

//+-----------------------------------------------------------> cArcFile

struct cArcFileInfo
{
	char						strName[64];
	unsigned int				uiExtension;
	unsigned int				uiSize1;
	unsigned int				uiSize2;
	unsigned int				uiOffset;
};

//+-----------------------------------------------------------> Filetypes

#define ARCEXT_SHADER			0x50F9DB3E		// bfx
#define ARCEXT_TEXTURE			0x241F5DEB		// tex
#define ARCEXT_MOTION			0x76820D81		// lmt
#define ARCEXT_MODEL			0x58A15856		// mod
#define ARCEXT_VIBRATION		0x358012E8		// vib
#define ARCEXT_MESSAGE			0x10C460E6		// msg
#define ARCEXT_LSP				0x60DD1B16		// lsp
#define ARCEXT_SDL				0x4C0DB839		// sdl
#define ARCEXT_STP				0x671F21DA		// stp
#define ARCEXT_IDM				0x2447D742		// idm
#define ARCEXT_MTG				0x4E2FEF36		// mtg
#define ARCEXT_LCM				0x39C52040		// lcm
#define ARCEXT_JEX				0x2282360D		// jex
#define ARCEXT_CHN				0x3E363245		// chn
#define ARCEXT_AHC				0x5802B3FF		// ahc
#define ARCEXT_HIT				0x0253f147		// hit
#define ARCEXT_RTEXTURE			0x7808EA10		// rtex, not used, all textures empty
#define ARCEXT_CUBEMAP			0x4D894D5D		// for all the stages, header: XFS, loads without

#define ARCEXT_EFFECT_EAN		0x4E397417		// ean
#define ARCEXT_EFFECT_EFL		0x6D5AE854		// efl
#define ARCEXT_EFFECT_EFS		0x02833703		// efs
#define ARCEXT_EFFECT_RTT		0x276DE8B7		// rtt
#define ARCEXT_EFFECT_AEF		0x557ECC08		// for all the stages, header: XFS, loads without
#define ARCEXT_EFFECT_ADH		0x1EFB1B67		// adh
#define ARCEXT_EFFECT_CEF		0x758B2EB7		// cef

#define ARCEXT_SOUND_SPC		0x7E33A16C		// spc
#define ARCEXT_SOUND_SRD		0x2D12E086		// srd
#define ARCEXT_SOUND_SRQ		0x1BCC4966		// srq
#define ARCEXT_SOUND_STQ		0x167DBBFF		// stq
#define ARCEXT_SOUND_REVWIN		0x232E228C		// rev_win
#define ARCEXT_SOUND_EQU		0x2B40AE8F		// equ
#define ARCEXT_SOUND_SCS		0x0ECD7DF4		// scs
#define ARCEXT_SOUND_SDS		0x0315E81F		// sds
#define ARCEXT_SOUND_MSE		0x4CA26828		// mse
#define ARCEXT_SOUND_ASE		0x07437CCE		// ase
#define ARCEXT_SOUND_SNGW		0x7D1530C2		// sngw, ogg

// the fellowing are untested files but extensions are given according to their header
// missing extensions: at3, xma, bgm, pth, ptl, lom, los, way, nav, 

#define ARCEXT_UNK08			0x30ED4060		// XFS
#define ARCEXT_UNK09			0x430B4FF4		// XFS
#define ARCEXT_UNK12			0x5898749C		// XFS
#define ARCEXT_UNK14			0x38F66FC3		// XFS
#define ARCEXT_UNK15			0x039D71F2		// XFS
#define ARCEXT_UNK17			0x176C3F95		// XFS
#define ARCEXT_UNK18			0x2C4666D1		// XFS
#define ARCEXT_UNK19			0x266E8A91		// XFS
#define ARCEXT_UNK20			0x15302EF4		// XFS
#define ARCEXT_UNK21			0x19A59A91		// XFS
#define ARCEXT_UNK24			0x1ED12F1B		// XFS
#define ARCEXT_UNK26			0x65B275E5		// XFS
#define ARCEXT_UNK29			0x754B82B4		// XFS
#define ARCEXT_UNK30			0x017A550D		// XFS
#define ARCEXT_UNK34			0x1BA81D3C		// XFS
#define ARCEXT_UNK35			0x4F16B7AB		// XFS
#define ARCEXT_UNK36			0x585831AA		// XFS

#define ARCEXT_CCL				0x0026E7FF		// CCL
#define ARCEXT_HAVOK			0x36E29465		// havok HVK
#define ARCEXT_FSM				0x66B45610		// FSM
#define ARCEXT_SBC				0x51FC779F		// SBC
#define ARCEXT_NAV				0x4EF19843		// NAV
#define ARCEXT_WAY				0x5F36B659		// WAY
#define ARCEXT_OBJ				0x0DADAB62		// OBJ
#define ARCEXT_SHP				0x5204D557		// SHP
#define ARCEXT_SHW				0x60524FBB		// SHW
#define ARCEXT_CDG				0x2DC54131		// CDF, present only for pl02 model

#define ARCEXT_SOUND_SND12		0x46810940		// header: XFS
#define ARCEXT_SOUND_SND13		0x538120DE		// header: XFS

//+-----------------------------------------------------------> 

bool PatchArcFilenames(const char *strArc);
void PatchAllArcFilenames(char *rep);
bool UnPatchArcFilenames(const char *strArc);
void UnPatchAllArcFilenames(char *rep);

//+-----------------------------------------------------------> 