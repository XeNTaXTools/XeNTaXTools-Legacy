// Version5.h : Convert UbiSoft format version 3 and 5 audio
//

// Convert UbiSoft version 3 or 5 audio
bool ConvertVersion5(std::istream& Input, std::ostream& Output, size_t Size, unsigned char Channels);
