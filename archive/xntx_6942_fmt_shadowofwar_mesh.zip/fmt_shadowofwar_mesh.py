# Middle-earth: Shadow of War Script plugin for Noesisquestionablecompatibility
# 
# Author: zaramot
# URL: https://forum.xentax.com/viewtopic.php?t=17200
# Date: Oct 28, 2017
# 
# 
# Recoded from maxscript to python
# Transcoder: mariokart64n
# URL: https://www.deviantart.com/mariokart64n
# Date: October 13 2019
# 
# Known Issues:
# - Original script read files improperly, compatibility questionable
# - Bone Import and texture corrdinate data not ported from original authors script
#
# Changelog:
#	2019/10/13:
#		Initial mock up of python script from maxscript -mariokart64n
#

from inc_noesis import *

showPrints = False

class Mesh_Info_Struct:
	VertexCount = 0
	VertexStart = 0
	FaceCount = 0
	FaceStart = 0
	VertexId = 0
	UsedBones = 0
	UsedBonesStart = 0
	VertexEnd = 0

class weight_data:
	boneids = []
	weights = []

def registerNoesisTypes():
	if showPrints == True: 
		noesis.logPopup()
		for i in range(0, 30): print("\n")
	#print("The log can be useful for catching debug prints from preview loads.\nBut don't leave it on when you release your script, or it will probably annoy people.")
	
	handle = noesis.register("Shadow of War (PC)", ".mesh")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadModel(handle, noepyLoadModel) #see also noepyLoadModelRPG
	#noesis.setHandlerWriteModel(handle, noepyWriteModel)
	#noesis.setHandlerWriteAnim(handle, noepyWriteAnim)
	
	return 1

NOEPY_HEADER = 0x48534D4D

def noepyCheckType(data):
	if len(data) < 8:
		return 0
	bs = NoeBitStream(data)
	
	if bs.readUInt() != NOEPY_HEADER:
		return 0
	
	return 1

def noepyLoadModel(data, mdlList):
	bs = NoeBitStream(data)
	if bs.readUInt() != NOEPY_HEADER:
		return 0
	
	bs.seek(0x08, NOESEEK_ABS)
	FirstOff = bs.readUInt()
	DataStride = bs.readUInt()
	
	bs.seek(FirstOff + 24, NOESEEK_ABS)
	MeshCount = bs.readUInt()
	SkipSecCount = bs.readUInt()
	
	if showPrints == True : print("Check Pos @ 0x", hex(bs.tell()))
	
	BoneMapCount = bs.readUInt()
	MeshCountTrue = bs.readUInt()
	
	bs.seek(44, NOESEEK_REL)
	BoneCount = bs.readUInt()
	BoneSecSize = bs.readUInt()
	
	if showPrints == True : print("!!! @ 0x", hex(bs.tell()))
	
	bs.seek(MeshCount * 4, NOESEEK_REL)
	
	if showPrints == True : print("!!! @ 0x", hex(bs.tell()))
	
	bs.seek(SkipSecCount * 16, NOESEEK_REL)
	
	if showPrints == True : print("!!! @ 0x", hex(bs.tell()))
	
	VertSecSizeArray = []
	FaceSecSizeArray = []
	MapCountArray = []
	SubMeshCountArray = []
	
	for i in range(0, BoneMapCount):
		getPos = bs.tell() + 48
		VertSecSize = bs.readUInt()
		FaceSecSize = bs.readUInt()
		MapCount = bs.readUInt()
		SubMeshCount = bs.readUInt()
		bs.seek(getPos, NOESEEK_ABS)
		VertSecSizeArray.append(VertSecSize)
		FaceSecSizeArray.append(FaceSecSize)
		MapCountArray.append(MapCount)
		SubMeshCountArray.append(SubMeshCount)
	
	if showPrints == True : print("!!! @ 0x", hex(bs.tell()))
	
	meshes = []
	matList = []
	Mesh_Info = []
	Pos = bs.tell()
	for i in range(0, BoneMapCount):
		for ii in range(0, SubMeshCountArray[i]):
			getPos = bs.tell() + 40
			UnkOff01 = bs.readUInt()
			VertexStart = bs.readUInt()
			VertexCount = bs.readUInt()
			FaceStart = bs.readUInt()
			FaceCount = bs.readUInt()
			UsedBonesStart = bs.readUInt()
			UsedBones = bs.readUInt()
			bs.seek(8, NOESEEK_REL)
			VertexId = bs.readUInt()
			
			bs.seek(int(getPos), NOESEEK_ABS)
			mi = Mesh_Info_Struct()
			mi.VertexCount = VertexCount
			mi.VertexStart = VertexStart
			mi.FaceCount = FaceCount
			mi.FaceStart = FaceStart
			mi.VertexId = VertexId
			mi.UsedBones = UsedBones
			mi.UsedBonesStart = UsedBonesStart
			mi.VertexEnd = UnkOff01
			Mesh_Info.append(mi)
		
	
	bs.seek(Pos, NOESEEK_ABS)
	
	
	if showPrints == True : print("----- This is Mesh Info Section -----  @ 0x", hex(bs.tell()))
	
	bs.seek(int((FirstOff+DataStride) + 24), NOESEEK_ABS)
	
	VertexStartArray = []
	
	for i in range(0, BoneMapCount):
		bs.seek(VertSecSizeArray[i], NOESEEK_REL)
	
	
	FacePosition = bs.tell()
	
	FacePosArray = []
	for i in range(0, MeshCountTrue):
		FacePosStart = bs.tell()
		for x in range(0, int(Mesh_Info[i].FaceCount/3)):
			getPos = bs.tell() + 6
			bs.seek(getPos, NOESEEK_ABS)
			
		FacePosArray.append(FacePosStart)
		
		
	
	if showPrints == True : print(FacePosArray)
	
	BoneIDPosArray = []
	
	for i in range(0, MeshCountTrue):
		BoneIDPos = bs.tell()
		bs.seek(Mesh_Info[i].UsedBones, NOESEEK_REL)
		BoneIDPosArray.append(BoneIDPos)
		
	
	bs.seek(int(((FirstOff + DataStride) + 24)), NOESEEK_ABS)
	
	VertexStartArray = []
	
	for i in range(0, MeshCountTrue):
		
		VertexSize = 0
		
		VertexStartPos = bs.tell()
		
		bs.seek(0x6, NOESEEK_REL)
		CheckVert = bs.readUShort()
		if CheckVert == 15360:
			bs.seek(0x1E, NOESEEK_REL)
		
		CheckVert2 = bs.readUShort()
		if CheckVert2 == 15360: VertexSize = 16
		if CheckVert2 != 15360: VertexSize = 24
		
		bs.seek(VertexStartPos, NOESEEK_ABS)
		
		if showPrints == True : print("Vertex Start @ 0x", hex(bs.tell()))
		
		if VertexSize == 16:
			bs.seek(Mesh_Info[i].VertexCount * 16, NOESEEK_REL)
		
		if VertexSize == 24:
			bs.seek(Mesh_Info[i].VertexCount * 24, NOESEEK_REL)
		
		PosVStart = int(bs.tell())
		
		if showPrints == True : print("------------------------ 0x", hex(bs.tell()))
		
		if (i + 1) != MeshCountTrue:
			if VertexSize == 16:
				bs.seek(Mesh_Info[i].VertexCount * 44, NOESEEK_REL)
				Pos0 = bs.tell()
				bs.seek(0x6, NOESEEK_REL)
				CheckVert = bs.readUShort()
				if CheckVert == 15360:
					bs.seek(0x1E, NOESEEK_REL)
				
				CheckVert2 = bs.readUShort()
				if CheckVert2 == 15360:
					bs.seek(Pos0, NOESEEK_ABS)
				
				if CheckVert2 != 15360:
					bs.seek(PosVStart, NOESEEK_ABS)
					bs.seek(Mesh_Info[i].VertexCount * 48, NOESEEK_REL)
					Pos1 = bs.tell()
					bs.seek(0x06, NOESEEK_REL)
					CheckVert = bs.readUShort()
					if CheckVert==15360:
						bs.seek(0x1E, NOESEEK_REL)
					
					CheckVert2 = bs.readUShort()
					if CheckVert2 == 15360:
						bs.seek(Pos1, NOESEEK_ABS)
					
					if CheckVert2 != 15360:
						bs.seek(PosVStart, NOESEEK_ABS)
						bs.seek(Mesh_Info[i].VertexCount * 52, NOESEEK_REL)
						Pos2 = bs.tell()
						bs.seek(0x6, NOESEEK_REL)
						CheckVert = bs.readUShort()
						if CheckVert == 15360:
							bs.seek(0x1E, NOESEEK_REL)
						
						CheckVert2 = bs.readUShort()
						if CheckVert2 == 15360:
							bs.seek(Pos2, NOESEEK_ABS)
						
						if CheckVert2 != 15360:
							bs.seek(PosVStart, NOESEEK_ABS)
							bs.seek(Mesh_Info[i].VertexCount * 56, NOESEEK_REL)
							Pos3 = bs.tell()
							bs.seek(0x6, NOESEEK_REL)
							CheckVert = bs.readUShort()
							if CheckVert == 15360:
								bs.seek(0x1E, NOESEEK_REL)
							
							CheckVert2 = bs.readUShort()
							if CheckVert2 == 15360:
								bs.seek(Pos3, NOESEEK_ABS)
							
						
					
				
			elif VertexSize == 24:
				bs.seek(int(Mesh_Info[i].VertexCount * 44), NOESEEK_REL)
				Pos0 = bs.tell()
				bs.seek(0xC, NOESEEK_REL)
				CheckVert = bs.readFloat()
				if CheckVert == 1.0:
					bs.seek(0x14, NOESEEK_REL)
				
				CheckVert2 = bs.readFloat()
				
				if CheckVert2 == 1.0:
					bs.seek(Pos0, NOESEEK_ABS)
				else:
					bs.seek(PosVStart, NOESEEK_ABS)
					bs.seek(Mesh_Info[i].VertexCount * 48, NOESEEK_REL)
					Pos1 = bs.tell()
					bs.seek(0xC, NOESEEK_REL)
					CheckVert = bs.readFloat()
					if CheckVert == 1.0:
						bs.seek(0x14, NOESEEK_REL)
					
					CheckVert2 = bs.readFloat()
					if CheckVert2 == 1.0:
						bs.seek(Pos1, NOESEEK_ABS)
					else:
						bs.seek(PosVStart, NOESEEK_ABS)
						bs.seek(Mesh_Info[i].VertexCount * 52, NOESEEK_REL)
						Pos2 = bs.tell()
						bs.seek(0xC, NOESEEK_REL)
						CheckVert = bs.readFloat()
						if CheckVert == 1.0:
							bs.seek(0x14, NOESEEK_REL)
						
						CheckVert2 = bs.readFloat()
						if CheckVert2 == bs.readFloat():
							bs.seek(Pos2, NOESEEK_ABS)
						else:
							bs.seek(PosVStart, NOESEEK_ABS)
							bs.seek(Mesh_Info[i].VertexCount * 56, NOESEEK_REL)
							Pos3 = bs.tell()
							bs.seek(0xC, NOESEEK_REL)
							CheckVert = bs.readFloat()
							if CheckVert == 1.0:
								bs.seek(0x14, NOESEEK_REL)
							
							CheckVert2 = bs.readFloat()
							if CheckVert2 == 1.0:
								bs.seek(Pos3, NOESEEK_ABS)
							
						
					
				
			
		
		PosVEnd = bs.tell()
		
		if (i + 1) != MeshCountTrue:
			UvSize = int((PosVEnd - PosVStart) / Mesh_Info[i].VertexCount)
		else:
			UvSize = int((FacePosition - PosVStart) / Mesh_Info[i].VertexCount)
		
		if showPrints == True : print("----- Mesh Number ----- ", int(i + 1))
		
		if showPrints == True : print("----- This is UV's Size ----- ", UvSize)
		
		if showPrints == True : print("------------------------ 0x", hex(bs.tell()))
		
		bs.seek(PosVStart, NOESEEK_ABS)
		
		bs.seek(int(Mesh_Info[i].VertexCount * UvSize), NOESEEK_REL)
		
		VertexStartArray.append(VertexStartPos)
		
	
	if showPrints == True : print("Vertex Pos Section End @ 0x", hex(bs.tell()))
	
	if showPrints == True : print("--------------------------")
	
	if showPrints == True : print(VertexStartArray)
	
	bs.seek((((FirstOff+DataStride)+20)-BoneSecSize), NOESEEK_ABS)
	
	if showPrints == True : print("Bones Section Start @ 0x", hex(bs.tell()))
	
	tarr = []
	rarr = []
	parr = []
	
	for i in range(0, BoneCount):
		BoneHash = bs.readUInt()
		BoneParent = bs.readUShort()
		BoneChild = bs.readUShort()
		a11 = bs.readFloat()
		a12 = bs.readFloat()
		a13 = bs.readFloat()
		a14 = bs.readFloat()
		a21 = bs.readFloat()
		a22 = bs.readFloat()
		a23 = bs.readFloat()
		a24 = bs.readFloat()
		
		tarr.append(NoeVec3([-a11, a12, a13]))
		rarr.append(NoeVec4([a21, a22, a23, a24]))
		parr.append(BoneParent)
		
	
	if showPrints == True : print("Bones Section End @ 0x", hex(bs.tell()))
	
	for i in range(0, MeshCountTrue):
		vertArray = []
		faceArray = []
		UV_array = []
		UV_array2 = []
		Weight_array = []
		BoneIDArray = []
		
		#BoneIdStart = BoneIDPosArray[i]
		
		#bs.seek(BoneIdStart, NOESEEK_ABS)
		
		#for x in range(0, Mesh_Info[i].UsedBones):
		#	BoneIDArray.append(bs.readUInt())
		
		VertexSize = 0
		
		VertexStart = VertexStartArray[i]
		
		bs.seek(VertexStart, NOESEEK_ABS)
		
		bs.seek(0x6, NOESEEK_REL)
		
		CheckVert = bs.readUShort()
		
		if CheckVert== 15360:
			bs.seek(0x1E, NOESEEK_REL)
		CheckVert2 = bs.readUShort()
		if CheckVert2 == 15360: VertexSize = 16
		if CheckVert2 != 15360: VertexSize = 24
		
		if showPrints == True : print("---Vertex Size---: ", VertexSize)
		
		bs.seek(VertexStart, NOESEEK_ABS)
		
		if showPrints == True : print("Vertex Start @ 0x", hex(bs.tell()))
		
		if VertexSize == 16:
			for x in range(0, Mesh_Info[i].VertexCount):
				getPos = bs.tell() + 16
				vx = bs.readHalfFloat()
				vy = bs.readHalfFloat()
				vz = bs.readHalfFloat()
				
				Null = bs.readUShort()
				
				weight3 = bs.readUByte()
				weight2 = bs.readUByte()
				weight1 = bs.readUByte()
				weight4 = bs.readUByte()
				
				bone1 = bs.readUByte()
				bone2 = bs.readUByte()
				bone3 = bs.readUByte()
				bone4 = bs.readUByte()
				
				w = weight_data()
				maxweight = 0
				
				if weight1 != 0:
					maxweight = maxweight + weight1
				if weight2 != 0:
					maxweight = maxweight + weight2
				if weight3 != 0:
					maxweight = maxweight + weight3
				if weight4 != 0:
					maxweight = maxweight + weight4
				
				if maxweight != 0:
					if weight1 != 0:
						w.boneids.append(bone1)
						w.weights.append(weight1 / 255.0)
					
					if weight2 != 0:
						w.boneids.append(bone2)
						w.weights.append(weight2 / 255.0)
					
					if weight3 != 0:
						w.boneids.append(bone3)
						w.weights.append(weight3 / 255.0)
					
					if weight4 != 0:
						w.boneids.append(bone4)
						w.weights.append(weight4 / 255.0)
					
				Weight_array.append(w)
				bs.seek(getPos, NOESEEK_ABS)
				vertArray.append(NoeVec3([-vx,vy,vz]))
		else:
			for x in range(0, Mesh_Info[i].VertexCount):
				getPos = bs.tell() + 24
				vx = bs.readFloat()
				vy = bs.readFloat()
				vz = bs.readFloat()
				
				Null= bs.readUInt()
				
				weight3 = bs.readUByte()
				weight2 = bs.readUByte()
				weight1 = bs.readUByte()
				weight4 = bs.readUByte()
				
				bone1 = bs.readByte()
				bone2 = bs.readByte()
				bone3 = bs.readByte()
				bone4 = bs.readByte()
				
				w = weight_data()
				maxweight = 0
				
				if weight1 != 0:
					maxweight = maxweight + weight1
				if weight2 != 0:
					maxweight = maxweight + weight2
				if weight3 != 0:
					maxweight = maxweight + weight3
				if weight4 != 0:
					maxweight = maxweight + weight4
				
				if maxweight != 0:
					if weight1 != 0:
						w.boneids.append(bone1)
						w.weights.append(weight1 / 255.0)
					
					if weight2 != 0:
						w.boneids.append(bone2)
						w.weights.append(weight2 / 255.0)
					
					if weight3 != 0:
						w.boneids.append(bone3)
						w.weights.append(weight3 / 255.0)
					
					if weight4 != 0:
						w.boneids.append(bone4)
						w.weights.append(weight4 / 255.0)
					
				Weight_array.append(w)
				bs.seek(getPos, NOESEEK_ABS)
				vertArray.append(NoeVec3([-vx,vy,vz]))
			
		
		
		PosVStart = bs.tell()
		
		
		if (i + 1) != MeshCountTrue:
			if VertexSize == 16:
				bs.seek(Mesh_Info[i].VertexCount * 44, NOESEEK_REL)
				Pos0 = bs.tell()
				bs.seek(0x6, NOESEEK_REL)
				CheckVert = bs.readUShort()
				if CheckVert == 15360:
					bs.seek(0x1E, NOESEEK_REL)
				CheckVert2 = bs.readUShort()
				if CheckVert2 == 15360:
					bs.seek(Pos0, NOESEEK_ABS)
				if CheckVert2 != 15360:
					bs.seek(PosVStart, NOESEEK_ABS)
					bs.seek(Mesh_Info[i].VertexCount * 48, NOESEEK_REL)
					Pos1 = bs.tell()
					bs.seek(0x6, NOESEEK_REL)
					CheckVert = bs.readUShort()
					if CheckVert == 15360:
						bs.seek(0x1E, NOESEEK_REL)
					CheckVert2 = bs.readUShort()
					if CheckVert2 == 15360:
						bs.seek(Pos1, NOESEEK_ABS)
					if CheckVert2 != 15360:
						bs.seek(PosVStart, NOESEEK_ABS)
						bs.seek(Mesh_Info[i].VertexCount * 52, NOESEEK_REL)
						Pos2 = bs.tell()
						bs.seek(0x6, NOESEEK_REL)
						CheckVert = bs.readUShort()
						if CheckVert == 15360:
							bs.seek(0x1E, NOESEEK_REL)
						CheckVert2 = bs.readUShort()
						if CheckVert2 == 15360:
							bs.seek(Pos2, NOESEEK_ABS)
						if CheckVert2 != 15360:
							bs.seek(PosVStart, NOESEEK_ABS)
							bs.seek(Mesh_Info[i].VertexCount * 56, NOESEEK_REL)
							Pos3 = bs.tell()
							bs.seek(0x6, NOESEEK_REL)
							CheckVert = bs.readUShort()
							if CheckVert == 15360:
								bs.seek(0x1E, NOESEEK_REL)
							CheckVert2 = bs.readUShort()
							if CheckVert2 == 15360:
								bs.seek(Pos3, NOESEEK_ABS)
							
						
					
				
			elif VertexSize == 24:
				bs.seek(Mesh_Info[i].VertexCount * 44, NOESEEK_REL)
				Pos0 = bs.tell()
				bs.seek(0xC, NOESEEK_REL)
				CheckVert = bs.readFloat()
				if CheckVert == 1.0:
					bs.seek(0x14, NOESEEK_REL)
				CheckVert2 = bs.readFloat()
				if CheckVert2 == 1.0:
					bs.seek(Pos0, NOESEEK_ABS)
				if CheckVert2 != 1.0:
					bs.seek(PosVStart, NOESEEK_ABS)
					bs.seek(Mesh_Info[i].VertexCount * 48, NOESEEK_REL)
					Pos1 = bs.tell()
					bs.seek(0xC, NOESEEK_REL)
					CheckVert = bs.readFloat()
					if CheckVert == 1.0:
						bs.seek(0x14, NOESEEK_REL)
					CheckVert2 = bs.readFloat()
					if CheckVert2 == 1.0:
						bs.seek(Pos1, NOESEEK_ABS)
					if CheckVert2 != 1.0:
						bs.seek(PosVStart, NOESEEK_ABS)
						bs.seek(Mesh_Info[i].VertexCount * 52, NOESEEK_REL)
						Pos2 = bs.tell()
						bs.seek(0xC, NOESEEK_REL)
						CheckVert = bs.readFloat()
						if CheckVert == 1.0:
							bs.seek(0x14, NOESEEK_REL)
						CheckVert2 = bs.readFloat()
						if CheckVert2 == bs.readFloat():
							bs.seek(Pos2, NOESEEK_ABS)
						if CheckVert2 != 1.0:
							bs.seek(PosVStart, NOESEEK_ABS)
							bs.seek(Mesh_Info[i].VertexCount * 56, NOESEEK_REL)
							Pos3 = bs.tell()
							bs.seek(0xC, NOESEEK_REL)
							CheckVert = bs.readFloat()
							if CheckVert == 1.0:
								bs.seek(0x14, NOESEEK_REL)
							CheckVert2 = bs.readFloat()
							if CheckVert2 == 1.0:
								bs.seek(Pos3, NOESEEK_ABS)
							
						
					
				
			
		
		PosVEnd = bs.tell()
		
		if (i + 1) != MeshCountTrue:
			UvSize = int((PosVEnd - PosVStart) / Mesh_Info[i].VertexCount)
		else:
			UvSize = int((FacePosition - PosVStart) / Mesh_Info[i].VertexCount)
		
		bs.seek(PosVStart, NOESEEK_ABS)
		
		if showPrints == True : print("Vertex Position End @ 0x", hex(bs.tell()))
		
		if showPrints == True : print ("----- This is UV's Size ----- ", UvSize)
		
		if UvSize == 44:
			for x in range(0, Mesh_Info[i].VertexCount):
				getPos = int(bs.tell() + UvSize)
				
				tu = (bs.readUShort()) / 32767.0
				tv = (1.0 - (bs.readUShort())) / 32767.0
				
				bs.seek(getPos, NOESEEK_ABS)
				UV_array.append(NoeVec3([tu,tv,0]))
			
		
		#----------------------------------------------------------------
		
		if VertexSize != 24:
			if UvSize == 48:
				if Mesh_Info[i].VertexId == 0:
					for x in range(0, Mesh_Info[i].VertexCount):
						getPos = int(bs.tell() + UvSize)
						
						tu = (bs.readUShort()) / 32767.0
						tv = (1.0 - (bs.readUShort())) / 32767.0
						
						bs.seek(getPos, NOESEEK_ABS)
						UV_array.append(NoeVec3([tu,tv,0]))
						
					bs.seek(PosVStart, NOESEEK_ABS)
					
					for x in range(0, Mesh_Info[i].VertexCount):
						getPos = int(bs.tell() + UvSize)
						
						tu = bs.readFloat()
						tv= 1.0 - (bs.readFloat())
						
						bs.seek(getPos, NOESEEK_ABS)
						UV_array2.append(NoeVec3([tu,tv,0]))
						
					
				
			
		
		if VertexSize != 24:
			if UvSize == 48:
				if Mesh_Info[i].VertexId == 1:
					for x in range(0, Mesh_Info[i].VertexCount):
						getPos = int(bs.tell() + UvSize)
						
						tu = (bs.readUShort()) / 32767.0
						tv = (1.0 - (bs.readUShort())) / 32767.0
						
						bs.seek(getPos, NOESEEK_ABS)
						UV_array.append(NoeVec3([tu,tv,0]))
					
				
			
		
		if VertexSize == 24:
			if UvSize == 48:
				if Mesh_Info[i].VertexId == 0:
					for x in range(0, Mesh_Info[i].VertexCount):
						getPos = int(bs.tell() + UvSize)
						
						tu = (bs.readUShort()) / 32767.0
						tv = (1.0 - (bs.readUShort())) / 32767.0
						
						bs.seek(getPos, NOESEEK_ABS)
						UV_array.append(NoeVec3([tu,tv,0]))
						
					
					bs.seek(PosVStart, NOESEEK_ABS)
					for x in range(0, Mesh_Info[i].VertexCount):
						getPos = int(bs.tell() + UvSize)
						
						tu = bs.readFloat()
						tv= 1.0 - (bs.readFloat())
						
						bs.seek(getPos, NOESEEK_ABS)
						UV_array2.append(NoeVec3([tu,tv,0]))
						
					
				
			
		
		if VertexSize == 24:
			if UvSize == 48:
				if Mesh_Info[i].VertexId == 1:
					for x in range(0, Mesh_Info[i].VertexCount):
						getPos = int(bs.tell() + UvSize)
						
						tu = (bs.readUShort()) / 32767.0
						tv = (1.0 - (bs.readUShort())) / 32767.0
						
						bs.seek(getPos, NOESEEK_ABS)
						UV_array.append(NoeVec3([tu,tv,0]))
						
					
				
			
		
		if VertexSize != 24:
			if UvSize == 48: #Not confirmed
				if Mesh_Info[i].VertexId == 2:
					for x in range(0, Mesh_Info[i].VertexCount):
						getPos = int(bs.tell() + UvSize)
						
						tu = (bs.readUShort()) / 32767.0
						tv = (1.0 - (bs.readUShort())) / 32767.0
						
						bs.seek(getPos, NOESEEK_ABS)
						UV_array.append(NoeVec3([tu,tv,0]))
					
				
			
		
		if VertexSize == 24:
			if UvSize == 48: #Not confirmed
				if Mesh_Info[i].VertexId == 2:
					for x in range(0, Mesh_Info[i].VertexCount):
						getPos = int(bs.tell() + UvSize)
						
						tu = bs.readFloat()
						tv= 1.0 - (bs.readFloat())
						
						bs.seek(getPos, NOESEEK_ABS)
						UV_array.append(NoeVec3([tu,tv,0]))
						

		if UvSize == 48:
			if Mesh_Info[i].VertexId == 3:
				for x in range(0, Mesh_Info[i].VertexCount):
					getPos = int(bs.tell() + UvSize)
					
					tu = bs.readFloat()
					tv= 1.0 - (bs.readFloat())
					
					bs.seek(getPos, NOESEEK_ABS)
					UV_array.append(NoeVec3([tu,tv,0]))
				
			
		
		if UvSize == 48:
			if Mesh_Info[i].VertexId == 4:
				for x in range(0, Mesh_Info[i].VertexCount):
					getPos = int(bs.tell() + UvSize)
					
					tu = bs.readFloat()
					tv= 1.0 - (bs.readFloat())
					
					bs.seek(getPos, NOESEEK_ABS)
					UV_array.append(NoeVec3([tu,tv,0]))
				
			
		
		if UvSize == 52:
			for x in range(0, Mesh_Info[i].VertexCount):
				getPos = int(bs.tell() + UvSize)
				
				tu = bs.readFloat()
				tv= 1.0 - (bs.readFloat())
				
				bs.seek(getPos, NOESEEK_ABS)
				UV_array.append(NoeVec3([tu,tv,0]))
			
		
		if UvSize == 56:
			for x in range(0, Mesh_Info[i].VertexCount):
				getPos = int(bs.tell() + UvSize)
				
				tu = bs.readFloat()
				tv= 1.0 - (bs.readFloat())
				
				bs.seek(getPos, NOESEEK_ABS)
				UV_array.append(NoeVec3([tu,tv,0]))
		
		if showPrints == True : print("Vertex End @ 0x", hex(bs.tell()))
		
		bs.seek(FacePosArray[i], NOESEEK_ABS)
		
		if showPrints == True : print("Face Start @ 0x", hex(bs.tell()))
		
		for x in range(0, int(Mesh_Info[i].FaceCount / 3)):
			fa = bs.readShort()
			fb = bs.readShort()
			fc = bs.readShort()
			faceArray.append(fc)
			faceArray.append(fb)
			faceArray.append(fa)
		
		if showPrints == True : print("Face End @ 0x", hex(bs.tell()))
		
		material = NoeMaterial("Material " + str(i), "")
		if i > 0: material.setSkipRender(True)
		matList.append(material)
		mesh = NoeMesh(faceArray, vertArray, "Mesh " + str(i), "Material " + str(i))
		meshes.append(mesh)
		
	
	mdl = NoeModel(meshes, [], [])
	mdl.setModelMaterials(NoeModelMaterials([], matList))
	mdlList.append(mdl)
	
	
	if showPrints == True : print(Mesh_Info)
	return 1
