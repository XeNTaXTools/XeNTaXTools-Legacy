#Noesis Python model import test module, imports some data from a WoW model format

from inc_noesis import *

import noesis
import rapi
def registerNoesisTypes():
   handle = noesis.register("Blizzard character models", ".m2")
   noesis.setHandlerTypeCheck(handle, noepyCheckType)
   noesis.setHandlerLoadModel(handle, noepyLoadModel) #see also noepyLoadModelRPG
   #noesis.setHandlerWriteModel(handle, noepyWriteModel)
   #noesis.setHandlerWriteAnim(handle, noepyWriteAnim)
   #noesis.logPopup()#comment this when done writing the code
   return 1

#check if it's this type based on the data
def noepyCheckType(data):
   bs = NoeBitStream(data)
   if len(data) < 16:
      return 0
   global old
   global new
   magic = bs.readBytes(4).decode("ASCII")
   if magic == "MD20": #if pre-legion
      old = 0
      new = 0x0
   elif magic == "MD21": #if legion or newer
      old = 0
      new = 0x8
   else:#if different
      print ("Unexpected block name.")
      return 0
   if bs.readInt() < 264:#if pre-wotlk
      old = 1
   return 1       

#load the model
def noepyLoadModel(data, mdlList):
   ctx = rapi.rpgCreateContext()
   bs = NoeBitStream(data)
   bs.seek(0x4 + new, NOESEEK_ABS)#seek to file version
   version = bs.readInt()
   if version < 264:#if pre-wotlk
      hseek = 0x3C
   else:
      hseek = 0x34
   bs.seek(0x8 + new, NOESEEK_ABS)#seek to name header
   MNamel = bs.readInt()
   MName = bs.readInt()
   bs.seek(MName + new, NOESEEK_ABS)
   MName = bs.readBytes(MNamel - 1).decode("ASCII")
   if old == 0:
      skinFileName = rapi.getDirForFilePath(rapi.getInputName()) + MName + "00.skin"
      skin = rapi.loadIntoByteArray(skinFileName)
      skin = NoeBitStream(skin)
      skin.seek(0xC, NOESEEK_ABS)
      FCount = skin.readInt()
      FOffs = skin.readInt()
      skin.seek(FOffs, NOESEEK_ABS)
      FaceBuff = skin.readBytes(FCount * 2)
   else:
      bs.seek(0x50, NOESEEK_ABS)
      FOffs = bs.readInt()
      bs.seek(FOffs + 0x8, NOESEEK_ABS)
      FCount = bs.readInt()
      FOffs = bs.readInt()
      bs.seek(FOffs, NOESEEK_ABS)
      FaceBuff = bs.readBytes(FCount * 2)
   bs.seek(hseek + new, NOESEEK_ABS)#seek to bones and vert header
   BCount = bs.readInt()
   BOffs = bs.readInt()
   VCount = bs.readInt()
   VOffs = bs.readInt()
   bs.seek(VOffs + new, NOESEEK_ABS)
   boneBuf = []
   texBuf = []
   VertBuff = bytes()
   BoneBuff = bytes()
   NormBuff = bytes()
   TexBuff = bytes()
   for i in range(0, VCount):
      Xpos = bs.readBytes(4)#vert pos x
      Ypos = bs.readBytes(4)#vert pos y
      Zpos = bs.readBytes(4)#vert pos z
      bw1 = bs.readByte()#bone weight 1
      bw2 = bs.readByte()#bone weight 2
      bw3 = bs.readByte()#bone weight 3
      bw4 = bs.readByte()#bone weight 4
      bi1 = bs.readByte()#bone index 1
      bi2 = bs.readByte()#bone index 2
      bi3 = bs.readByte()#bone index 3
      bi4 = bs.readByte()#bone index 4
      Xnormal = bs.readBytes(4)#normal x
      Ynormal = bs.readBytes(4)#normal y
      Znormal = bs.readBytes(4)#normal z
      Utex = bs.readFloat()#texture u
      Vtex = bs.readFloat()#texture v(mirrored)
      Vtex = (Vtex * (-1)) + 1
      bs.readInt()#packing
      bs.readInt()#zeros for packing to end the block and give it size of 0x30
      VertBuff += Ypos + Zpos + Xpos
      #boneBuf.append([bw1, bw2, bw3, bw4], [bi1, bi2, bi3, bi4])#this part isn't working
      NormBuff += Ynormal + Znormal + Xnormal
      texBuf.append([Utex, Vtex])
   for i in range(0, VCount):
      read = texBuf[i]
      for j in range(2):
         TexBuff += noePack('f', read[j])
   #seek to bones
   #buffer bones
   rapi.rpgBindPositionBufferOfs(VertBuff, noesis.RPGEODATA_FLOAT, 12, 0)
   rapi.rpgBindNormalBufferOfs(NormBuff, noesis.RPGEODATA_FLOAT, 12, 0)
   rapi.rpgBindUV1BufferOfs(TexBuff, noesis.RPGEODATA_FLOAT, 8, 0)
   #rapi.rpgSetBoneMap(bonePallet[(fvfInfo2[i][2])])
   #rapi.rpgBindBoneIndexBufferOfs(VertBuff, noesis.RPGEODATA_USHORT, vsize, fvfTmp[j][1], 4)
   #rapi.rpgBindBoneWeightBufferOfs(VertBuff, noesis.RPGEODATA_HALFFLOAT, vsize, fvfTmp[j][1], 4)
   rapi.rpgCommitTriangles(FaceBuff, noesis.RPGEODATA_USHORT, FCount, noesis.RPGEO_TRIANGLE, 1)
   mdl = rapi.rpgConstructModel()
   #bones = rapi.multiplyBones(bones)
   #mdl.setBones(bones)
   mdlList.append(mdl)
   rapi.rpgClearBufferBinds()
   return 1
