
The source code for pmd2obj is so ugly that I decided not to release it.

(In case someone urgently is demanding for it I could pm it.)

tested with chr_body_rank_104_a_slender.pmd only
------------------------------------------------

(SM 4.obj is broken, main body has some extra vertices
because of my poor tristrips algo, whatever)

have fun, anyways
shak-otay

provided as is - the author can't be made responsible for any problems 
that might arise using the code and/or the exe

------------------------------------




"importing to blender"
----------------------

import single obj with wavefront importer
or use .py script for several obj files:

When executing load_multi_obj_blender2.69.py in a blender Text Editor window 
make sure to have set "path_to_obj_dir" to YOUR .pmd (with obj created) directory.

(obj files in a maybe contained subdirectory are being loaded, too)
