import bpy
import os
import struct


def read_some_data(context, filepath, use_some_setting):
    print("running read_some_data...")
    global bufdata
    
    with open(filepath,'rb') as bufdata:
    
    # would normally load the data here
#    print(data)
        ReadFile(bufdata,filepath)
        return {'FINISHED'}


# ImportHelper is a helper class, defines filename and
# invoke() function which calls the file selector.
from bpy_extras.io_utils import ImportHelper
from bpy.props import StringProperty, BoolProperty, EnumProperty
from bpy.types import Operator


class ImportSomeData(Operator, ImportHelper):
    """This appears in the tooltip of the operator and in the generated docs"""
    bl_idname = "import_test.some_data"  # important since its how bpy.ops.import_test.some_data is constructed
    bl_label = "Import NGB AFS"

    # ImportHelper mixin class uses this
    filename_ext = ".afs"

    filter_glob: StringProperty(
        default="*.afs",
        options={'HIDDEN'},
        maxlen=255,  # Max internal buffer length, longer would be clamped.
    )

    # List of operator properties, the attributes will be assigned
    # to the class instance from the operator settings before calling.
    use_setting: BoolProperty(
        name="unused Boolean",
        description="unused Tooltip",
        default=True,
    )

    type: EnumProperty(
        name="unused Enum",
        description="Choose between two useless items",
        items=(
            ('blah', "blahblah", "blahblahblah"),
            ('blah', "blahblah", "blahblahblah"),
        ),
        default='blah',
    )

    def execute(self, context):
        return read_some_data(context, self.filepath, self.use_setting)


# Only needed if you want to add into a dynamic menu
def menu_func_import(self, context):
    self.layout.operator(ImportSomeData.bl_idname, text="Text Import Operator")


def register():
    bpy.utils.register_class(ImportSomeData)
    bpy.types.TOPBAR_MT_file_import.append(menu_func_import)


def unregister():
    bpy.utils.unregister_class(ImportSomeData)
    bpy.types.TOPBAR_MT_file_import.remove(menu_func_import)

class AFS():  
    def __init__(self,filename):
        self.name = filename
        self.splitname = os.path.splitext(filename)[0]
        

    def ADDKMD(self):
        try:
            if self.kmd[self.kmdidx] in self.kmd:
                self.kmdidx += 1
                # print('new kmd added, idx',self.kmdidx)      
        except AttributeError:
            self.kmd = []
            self.kmdidx = 0
            # print('kmd created, idx',self.kmdidx)

        kmd = KMD(self.kmdidx)
        self.kmd.append(kmd)
        return kmd
        

class KMD():
    def __init__(self,kmdid):
        self.id = kmdid

    def ADDobj(self):
        try:
            if self.obj[self.objidx] in self.obj:
                self.objidx += 1
                # print('new obj added, idx',self.objidx)
        except AttributeError:
            self.obj = []
            self.objidx = 0
            # print('obj created, idx',self.objidx)

        obj = OBJ(self.objidx)
        self.obj.append(obj)
        return obj
    
    def ADDtex(self):
        try:
            if self.tex[self.texidx] in self.tex:
                self.texidx += 1
                # print('new texture added, idx',self.texidx)
        except AttributeError:
            self.tex = []
            self.texidx = 0
            # print('texture created, idx',self.texidx)
        
        tex = TEX(self.texidx)
        self.tex.append(tex)
        return tex
    
    def ADDhie(self):
        try:
            if self.hie[self.hieidx] in self.hie:
                self.hieidx += 1

        except AttributeError:
            self.hie = []
            self.hieidx = 0

        hie = HIE(self.hieidx)
        self.hie.append(hie)
        return hie

    def ADDpivot(self):
        try:
            if self.pivot[self.pivotidx] in self.pivot:
                self.pivotidx += 1
        
        except AttributeError:
            self.pivot = []
            self.pivotidx = 0

        pivot = PIVOT(self.pivotidx)
        self.pivot.append(pivot)
        return pivot

class PIVOT():
    def __init__(self,pivotid):
        self.id = pivotid

class HIE():
    def __init__(self,hieid):
        self.id = hieid

class OBJ():
    # unknown: 0, 3, 5
    objtypedict = {1:'fixed',2:'lowpoly',4:'joint',6:'eff',0:'0???',3:'3???',5:'5???'}

    def __init__(self,objid):
        self.id = objid

    def ADDmesh(self):
        try:
            if self.mesh[self.meshidx] in self.mesh:
                self.meshidx += 1
                # print('new mesh added, idx',self.meshidx)
        except AttributeError:
            self.mesh = []
            self.meshidx = 0
            # print('mesh created, idx',self.meshidx)

        mesh = MESH(self.meshidx)
        self.mesh.append(mesh)
        return mesh

    def ADDmat(self):
        try:
            if self.mat[self.matidx] in self.mat:
                self.matidx += 1
                # print('new material added, idx', self.matidx)
        except AttributeError:
            self.mat = []
            self.matidx = 0
            # print('material created, idx',self.matidx)

        mat = MAT(self.matidx)
        self.mat.append(mat)
        return mat

    

    def ADDInfo(self,objtype,loc,idxtype):
        self.type = objtype
        self.locx, self.locy, self.locz = loc
        self.idxtype = idxtype


class MAT():
    # unknown: 4 animated? (doku,drag), 16 masa flame?
    # by bit : 1 1st, 2 2nd, 4 3rd......0x10, 5th
    mattypedict = {2:'dds1(solid)',8:'dds5(transparent)',4:'4???',1:'1???',16:'16???'}

    def __init__(self,matid):
        self.id = matid

    def ADDInfo(self,mattype):
        self.type = mattype


    def ADDInfo2(self,meshid,secidxflag,idxstart,idxsize):
        self.meshid = meshid
        self.secidxflag = secidxflag
        self.idxstart = idxstart
        self.idxsize = idxsize


class MESH():
    # 142: 0001 0100 0010
    # 112: 0001 0001 0010
    # 116: 0001 0001 0110
    # 042: 0000 0100 0010
    # 118: 0001 0001 1000
    # 152: 0001 0101 0010
    
    # bit from right to left: 1,2 coor 3f 0xc,3 weight 0x4,4? 0x14,5 normal 3f 0xc,6,7 color 0x4,8,9 uv 2f 0x8
    fvftypedict = {0x112:'112',0x142:'142',0x42:'42',0x116:'116',0x118:'118',0x12:'12',0x152:'152',0x52:'52'}
    def __init__(self,meshid):
        self.id = meshid

    def ADDInfo(self,fvftype,fvfsize,vtxcount,priidxflag,idxcount):
        self.fvftype = fvftype
        self.fvfsize = fvfsize
        self.vtxcount = vtxcount
        self.priidxflag = priidxflag
        self.idxcount = idxcount

        self.fvfflag2 = fvftype >> 1 & 0x1
        self.fvfflag3 = fvftype >> 2 & 0x1
        self.fvfflag4 = fvftype >> 3 & 0x1
        self.fvfflag5 = fvftype >> 4 & 0x1
        self.fvfflag7 = fvftype >> 6 & 0x1
        self.fvfflag9 = fvftype >> 8 & 0x1
        

    def ADDoff(self,offvtxbuf):
        self.offvtxbuf = offvtxbuf


class TEX():
    bytestringp1 = b'\x44\x44\x53\x20\x7C\x00\x00\x00\x07\x10\x00\x00'
    bytestringp2 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x20\x00\x00\x00'
    # 0x6: ARGBs 0x27: not even displayed in GreedXplorer 0x28: G8B8s in GreedXplorer
    # by bit? 
    bytestringp3dict = {
        0xc:b'\x04\x00\x00\x00\x44\x58\x54\x31\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x10\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00',
        0xf:b'\x04\x00\x00\x00\x44\x58\x54\x35\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x10\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00',
        0x6:b'\x41\x00\x00\x00\x00\x00\x00\x00\x20\x00\x00\x00\x00\x00\xFF\x00\x00\xFF\x00\x00\xFF\x00\x00\x00\x00\x00\x00\xFF\x00\x10\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00',
        0x27:'0x27???',
        0x28:'G8B8s'}
    hwdict = {0:'0',2:0x4,3:0x8,4:0x10,5:0x20,6:0x40,7:0x80,8:0x100,9:0x200,10:0x400}
    t1dict = {0x1:'1???',0x2:'2???',0x3:'3???',0x4:'4???',0x5:'5???',0x6:'6???',0x7:"7???",0x8:'8???',0x9:'9???',0xa:'10???',0xb:'11???'}
    sizedict = {0xc:0x8,0xf:0x10,0x6:0x40}
    def __init__(self,texid):
        self.id = texid

    def ADDInfo(self,textype,t1,height,width,off_texbuf,off_1stbuf):
        self.type = textype
        self.t1 = t1
        self.height = height
        self.width = width
        self.offtexbuf = off_texbuf
        try:
            self.bytestringp3dict[self.type]
        except KeyError:
            print('-----------------------------tex',hex(self.type))
        


def ReadString(dat):
    return str(dat,encoding='utf-8').strip(b'\x00'.decode())


def TellPointer():
    print(hex(bufdata.tell()))


def ReadAFS(filename):
    global afs
    #header
    filenum = struct.unpack('<I',bufdata.read(4))[0]
    # print('file number: ',filenum)
    afs = AFS(filename)
    
    list_afsfile = []
    for i in range(filenum):
        off_file,size_file = struct.unpack('<2I',bufdata.read(8))
        list_afsfile.append(off_file)
    # print(list_afsfile)
    for offfile in list_afsfile:
        bufdata.seek(offfile)
        header = bufdata.read(4)
        if header == b'KMD\x00':
            ReadKMD(offfile)


def ReadKMD(off_kmd):
    global kmd
    hieflag = 0
    kmd = afs.ADDKMD()

    bufdata.seek(off_kmd)
    chunkid = ReadString(bufdata.read(8))
    blank,size = struct.unpack('<2I',bufdata.read(8))
    unkline1 = struct.unpack('16B',bufdata.read(0x10))
    #line2: 0?, 42 or 41, obj count, 3?, 4?, 5?
    unkline2 = struct.unpack('16B',bufdata.read(0x10))
    #line3: light trace?, 1?, 2?, 3? ,4?,5?, bone count,7?
    unkline3 = struct.unpack('16B',bufdata.read(0x10))
    #line4: 0?,1?,2?,3?,4?,5?,6?,7?,hie count?,
    unkline4 = struct.unpack('16B',bufdata.read(0x10))
    unkline5_1 = struct.unpack('8B',bufdata.read(8))
    name_model = ReadString(bufdata.read(8))
    unkline6 = struct.unpack('<4f',bufdata.read(0x10))
    unkline7 = struct.unpack('<4f',bufdata.read(0x10))
    off_objinfo, off_xpr, off_hie, off_hitmdl, off_texanm, off_morph,\
    off_acssri, off_miscdata, off_objhit, off_effscr = struct.unpack('<10I',bufdata.read(0x28))

    print(name_model)
    kmd.name = name_model

    if off_objinfo != 0:
        ReadOBJINFO(off_objinfo+off_kmd)

    if off_xpr !=0:
        ReadXPR(off_xpr+off_kmd)

    if off_hie !=0:
        hieflag = 1
        ReadHIE(off_hie+off_kmd)

    if off_hitmdl != 0:
        pass
        ReadHITMDL(off_hitmdl+off_kmd)

    if off_texanm != 0:
        pass
        ReadTEXANM(off_texanm+off_kmd)

    if off_morph != 0:
        pass
        ReadMORPH(off_morph+off_kmd)

    if off_acssri != 0:
        pass
        ReadACSSRI(off_acssri+off_kmd)

    if off_miscdata !=0:
        pass
        ReadMISCdata(off_miscdata+off_kmd)

    if off_objhit != 0:
        pass
        ReadOBJHIT(off_objhit+off_kmd)

    if off_effscr !=0:
        pass
        ReadEFFSCR(off_effscr+off_kmd)
        
    if blenderflag == 1:
        Blenderimport(hieflag)


def ReadOBJINFO(off0):
    bufdata.seek(off0)
    # print('OBJINFO at',hex(off0))
    chunkid = ReadString(bufdata.read(8))
    blank,size = struct.unpack('<2I',bufdata.read(8))
    countobj, asscountobj, unk1,unk2 = struct.unpack('<4I',bufdata.read(0x10))
    
    kmd.countobj = countobj
    list_off_oi = struct.unpack('<'+str(countobj)+'I',bufdata.read(countobj*4))

    for off_oi in list_off_oi:
        ReadOI(off_oi+off0)


def ReadOI(off0):
    obj = kmd.ADDobj()

    bufdata.seek(off0)
    id = bufdata.read(8)
    #meshcount = material count?
    matcount,objtype = struct.unpack('<2I',bufdata.read(8))
    #unk1: 0?,1?,2?,all0 after 3
    unk1 = struct.unpack('8B',bufdata.read(8))
    #flt1: 1.0, 0
    flt1 = struct.unpack('<2f',bufdata.read(8))
    #0x20
    #unk2: 0?,0,0,0
    unk2 = struct.unpack('4B',bufdata.read(4))
    #unk3: float32
    unk3 = struct.unpack('4B',bufdata.read(4))
    unk4 = struct.unpack('4B',bufdata.read(4))
    unk5 = struct.unpack('4B',bufdata.read(4))
    #0x30 location
    locx, locy, locz,flt2 = struct.unpack('<4f',bufdata.read(0x10))
    #0x40 rotation
    rotx, roty, rotz,flt3 = struct.unpack('<4f',bufdata.read(0x10))
    #0x50 scale
    sclx, scly, sclz,flt4 = struct.unpack('<4f',bufdata.read(0x10))

    unkflt1 = struct.unpack('<4f',bufdata.read(0x10))
    unkflt2 = struct.unpack('<4f',bufdata.read(0x10))
    unkflt3 = struct.unpack('<4f',bufdata.read(0x10))

    obj.matcount = matcount
    obj.ADDInfo(objtype,[locx,locz*-1,locy],unk1[1])

    for i in range(matcount):
        mat = obj.ADDmat()

        unkm1 = struct.unpack('16B',bufdata.read(0x10))
        unkm2 = struct.unpack('<4f',bufdata.read(0x10))
  
        mat.ADDInfo(unkm1[1])

    # read complete
    

def ReadXPR(off0):
    

    bufdata.seek(off0)
    chunkid = ReadString(bufdata.read(4))
    #unk1: command?
    size, off_1stbuf, unk1 = struct.unpack('<3I',bufdata.read(0xc))
    #0x10
    off_meshinfo, unk2, counttex, countvtxbuf = struct.unpack('<4I',bufdata.read(0x10))
    countpriidx, countsecidx, off_2ndbuf, size_2ndbuf = struct.unpack('<4I',bufdata.read(0x10))
    # pointer = bufdata.tell()

    if xprsplitflag == 1:
        pointer = bufdata.tell()
        xprsplit(off0,size)
        bufdata.seek(pointer)

    countobj = kmd.countobj
    for i in range(countobj):
        obj = kmd.obj[i]

        cmd = bufdata.read(4)
        size = struct.unpack('<I',bufdata.read(4))[0]
        countmesh, countmat = struct.unpack('<2I',bufdata.read(8))

        obj.countmesh = countmesh
        

        # mesh info
        for j in range(countmesh):
            mesh = obj.ADDmesh()
            
            # unkflag: morph?
            fvftype, morphflag, empty1, countvtx = struct.unpack('<4I',bufdata.read(0x10))
            # unkflag2 : always 1, priidxflag: 0 or 2
            fvfsize, unkflag2, priidxflag, countidx = struct.unpack('<4I',bufdata.read(0x10))

            mesh.ADDInfo(fvftype,fvfsize,countvtx,priidxflag,countidx)
 
        # material info
        for j in range(countmat):
            mat = obj.mat[j]

            # unkflag5: always 0, unkflag4: 0,1,2,3
            matid, meshid, counttexeach, unkflag5 = struct.unpack('<4I',bufdata.read(0x10))
            # unkflag6: always 1
            secidxflag, idxstart, idxsize, unkflag6 = struct.unpack('<4I',bufdata.read(0x10))
        
            unki3 = struct.unpack('<16I',bufdata.read(0x40))

            priidxflag1 = obj.mesh[meshid].priidxflag

            mat.ADDInfo2(meshid,secidxflag,idxstart,idxsize)

            if unki3[0] != 0:
                color = struct.unpack('<16f',bufdata.read(0x40))
                unki4 = struct.unpack('16B',bufdata.read(0x10))


            # texture info
            mat.texidlist = []
            for k in range(counttexeach):
                # print(bufdata.read(4))
                nametex = ReadString(bufdata.read(4))
                texid,unkt1,unkt2 = struct.unpack('<3I',bufdata.read(0xc))
                bufdata.read(0x30)
                mat.texidlist.append(texid)


    # read texture buffer offset
    for i in range(counttex):
        tex = kmd.ADDtex()

        raw = bufdata.read(4)
        # unktex: empty, unkb: always 0x29, unktex2: empty
        off_texbuf,unktex,unkb,typetex,hwidthtex,unktex2 = struct.unpack('<2I2BHI',bufdata.read(0x10))
        # if raw != b'\x01\x00\x04\x00':
            # print(raw,hex(bufdata.tell()),'--------------------------------')
        t1 = hwidthtex & 0xF
        height = hwidthtex >> 4 & 0xF
        width = hwidthtex >> 8 & 0xF

        tex.ADDInfo(typetex,t1,height,width,off_texbuf,off_1stbuf)

        # print(hex(t1),hex(height),hex(width),hex(hwidthtex))
        # if t1 != 1:

            # print('texture no.',i,unktex,unkb,hex(typetex),hex(hwidthtex),unktex2)
    
    # read vtx and idx buffer offset
    for i in range(countobj):
        obj = kmd.obj[i]
        cntmesh = obj.countmesh
        # print('object number',i,'mesh count',cntmesh,'object index type',obj.idxtype)

        # vtx buffer offset
        for i in range(cntmesh):
            rawvtx = bufdata.read(4)
            off_vtxbuf, empty2 = struct.unpack('<2I',bufdata.read(8))
            
            mesh = obj.mesh[i]
            mesh.ADDoff(off_vtxbuf)
            # if mesh.fvftype == 0x118:
            if 0:
                print('obj',obj.id,'------------------vtx',rawvtx,hex(bufdata.tell()-off0),'buffer start',hex(off_vtxbuf+off_1stbuf),'vtx count',mesh.vtxcount,'fvf type',hex(mesh.fvftype),'size',mesh.fvfsize)

            # priidx buffer offset
            if mesh.priidxflag == 0:
                rawidx = bufdata.read(4)
                off_priidxbuf,empty3 = struct.unpack('<2I',bufdata.read(8))
                mesh.offidxbuf = off_priidxbuf
                # print('pri idx',rawidx,'start at',hex(off_priidxbuf+off_1stbuf+off0),'index count',mesh.idxcount)

        # secidx buffer offset
        for i in range(obj.matcount):
            mat = obj.mat[i]
            if mat.secidxflag == 0:
                rawsecidx = bufdata.read(4)
                off_secidxbuf,empty4 = struct.unpack('<2I',bufdata.read(8))
                unksecidx = struct.unpack('<3I',bufdata.read(0xc))

                mat.offidxbuf = off_secidxbuf
                # print('secondary index',rawsecidx,'start at',hex(off_secidxbuf+off_1stbuf),'mesh id',mat.meshid,'idx count',obj.mesh[mat.meshid].idxcount,'start',mat.idxstart//2,'size',mat.idxsize//2)
            else:
                mat.offidxbuf = obj.mesh[mat.meshid].offidxbuf
                pass
                # print('primary index',hex(mat.offidxbuf+off_1stbuf),'mesh id',mat.meshid,'idx count',obj.mesh[mat.meshid].idxcount,'start',mat.idxstart,'size',mat.idxsize)
    
    
    # vertex and index buffer read
    if 1:
        for i in range(countobj):
            obj = kmd.obj[i]
            meshcount = obj.countmesh
            matcount = obj.matcount
            # vertex buffer
            if 1:
                for j in range(meshcount):
                    mesh = obj.mesh[j]
                    vtxcount = mesh.vtxcount
                    fvfsize = mesh.fvfsize
                    bufdata.seek(mesh.offvtxbuf+off_1stbuf+off0)
                    # print('vtx count',vtxcount)
                    # TellPointer()
                    mesh.vtxcoorlist = []
                    mesh.vtxweightlist = []
                    mesh.vtxunklist = []
                    mesh.vtxnormlist = []
                    mesh.vtxcolorlist = []
                    mesh.vtxuvlist = []
                    for k in range(vtxcount):
                        # mesh.ADDVTX()
                        # vtx = mesh.vtx[k]
                        if mesh.fvfflag2 == 1:
                            coorx,coory,coorz = struct.unpack('<3f',bufdata.read(0xc))
                            mesh.vtxcoorlist.append((coorx,coorz*-1,coory))
                        if mesh.fvfflag3 == 1:
                            weight = struct.unpack('<f',bufdata.read(0x4))[0]
                            mesh.vtxweightlist.append(weight)
                        if mesh.fvfflag4 == 1:
                            coorx,coory,coorz,weight1,weight2 = struct.unpack('<5f',bufdata.read(0x14))
                            mesh.vtxcoorlist.append((coorx,coorz*-1,coory))
                            mesh.vtxweightlist.append([weight1,weight2])
                        if mesh.fvfflag5 == 1:
                            normx,normy,normz = struct.unpack('<3f',bufdata.read(0xc))
                            mesh.vtxnormlist.append((normx,normz*-1,normy))
                        if mesh.fvfflag7 == 1:
                            diffr,diffg,diffb,diffa = struct.unpack('4B',bufdata.read(0x4))
                            mesh.vtxcolorlist.append([diffr,diffg,diffb,diffa])
                        if mesh.fvfflag9 == 1:
                            texu,texv = struct.unpack('<2f',bufdata.read(0x8))
                            if texv > 0:
                                texv = 1-texv
                            mesh.vtxuvlist.append([texu,abs(texv)])
            
            if 1:
                for j in range(matcount):
                    mat = obj.mat[j]
                    secidxflag = mat.secidxflag
                    meshid = mat.meshid
                    idxstart = mat.idxstart
                    idxsize = mat.idxsize
                    offidxbuf = mat.offidxbuf

                    bufdata.seek(idxstart+offidxbuf+off_1stbuf+off0)
                    # primary index
                    if secidxflag != 0:
                        pass
                        # TellPointer()
                        mat.idx = struct.unpack('<'+str(idxsize//2)+'H',bufdata.read(idxsize))
                        # TellPointer()

                    # secondary index
                    else:
                        mat.idx = []
                        secraw = bufdata.read(8)
                        # if secraw != b'\xfc\x17\x04\x00\x06\x00\x00\x00':
                            # print(secraw)
                        secflag,sizesecidx = struct.unpack('<2H',bufdata.read(4))
                        while secflag == 0x1800:
                            sizesecidx -= 0x4000
                            # print('next buffer size',hex(sizesecidx))
                            mat.idx.extend(struct.unpack('<'+str(sizesecidx//2)+'H',bufdata.read(sizesecidx)))
                            secflag,sizesecidx = struct.unpack('<2H',bufdata.read(4))
                        else:
                            if secflag == 0x1808:
                                # print('last buffer size',hex(sizesecidx))
                                idxlast = struct.unpack('<'+str(sizesecidx//2)+'H',bufdata.read(sizesecidx))
                                mat.idx.extend([idxlast[0]])
    
    #texture buffer read and extract
    if 1:    
        texdir = fpath + 'xpr/' + afs.splitname + '/' + kmd.name + '/'
        if not os.path.exists(texdir):
            os.makedirs(texdir)
            print('texdir created')

        for i in range(counttex):
            tex = kmd.tex[i]
            if tex.type not in [0x27,0x28,0x6]:
                texid = tex.id
                texname = afs.splitname + '-' + kmd.name + '-' + str(texid)
                if not os.path.exists(texdir+texname+'.dds'):
                    texh = tex.hwdict[tex.height]
                    texw = tex.hwdict[tex.width]
                    texbit = tex.sizedict[tex.type]
                    texsize = texh*texw*texbit//0x10
                    # print('tex',texid,'size',hex(texsize),hex(tex.offtexbuf+off_1stbuf))

                    bytestringhw = struct.pack('<2I',texw,texh)
                    bufdata.seek(tex.offtexbuf + off_1stbuf + off0)
                    bytestringtex = bufdata.read(texsize)
                    texf = open(texdir+texname+'.dds','wb')
                    texf.write(tex.bytestringp1+bytestringhw+tex.bytestringp2+tex.bytestringp3dict[tex.type]+bytestringtex)
                    texf.close()
                                
    # end of XPR section


def ReadHIE(off0):
    bufdata.seek(off0)
    chunkid = bufdata.read(8)
    empty1,size = struct.unpack('<2I',bufdata.read(8))
    if empty1 != 0:
        print('---------------------------',empty1)

    #unkhie2: 0x30 or 0x50, unkhie3: always 0x20 (header size?)
    countobj,counthie,hietype,unkhie3 = struct.unpack('<4I',bufdata.read(0x10))
    #unkhie4: pivot bone flag?
    pivotflag = struct.unpack('<I',bufdata.read(0x4))[0]
    countpivot,pivotcnt = struct.unpack('<2H',bufdata.read(4))
    pivotlist = struct.unpack('<'+str(countpivot)+'H',bufdata.read(countpivot*0x2))

    kmd.countpivot = countpivot
    kmd.pivotlist = pivotlist
    kmd.hielist =[]

    if hietype == 0x30:
        bufdata.seek(off0+0x30)
    elif hietype == 0x50:
        bufdata.seek(off0+0xb0)
    else:
        print('----------------------unknown hie type')
    offhielist = struct.unpack('<'+str(counthie)+'I',bufdata.read(counthie*0x4))

    for i in range(counthie):
        kmd.ADDhie()
        hie = kmd.hie[i]
        
        if offhielist[i] != 0:
            
            
            
            offhie = offhielist[i]
            bufdata.seek(offhie+off0)
            objid,parentobjid,countcntobj,remaincnt = struct.unpack('<4H',bufdata.read(0x8))
            # print('bone',i,'count connect obj',countcntobj)
            # TellPointer()
            cntobjlist = struct.unpack('<'+str(countcntobj)+'H',bufdata.read(countcntobj*0x2))
            bonetype = kmd.obj[i].type
            # if ((bonetype != 1) and (len(cntobjlist) != 0)):
                # print('bone',objid,'objtype',bonetype,'parent bone',parentobjid,'connected with',cntobjlist)

            hie.boneid = objid
            hie.parentboneid = parentobjid
            hie.countcntobj = countcntobj
            hie.cntobjlist = cntobjlist
            
            kmd.hielist.append(objid)

    # hie completed


def ReadHITMDL(off0):
    pass

def ReadTEXANM(off0):
    pass

def ReadMORPH(off0):
    pass

def ReadACSSRI(off0):
    pass

def ReadMISCdata(off0):
    pass

def ReadOBJHIT(off0):
    pass

def ReadEFFSCR(off0):
    pass


def Blenderimport(hieflag):
    global bpy
    import bpy
    import bmesh
    import mathutils
    
    global afsname
    global kmdname
    global colkmd
    
    afsname = afs.splitname
    col = bpy.data.collections
#    print('-----afs',afsname)
    if afsname not in col:
        colafs = bpy.data.collections.new(afsname)
        bpy.context.scene.collection.children.link(colafs)
    else:
        colafs = col[afsname]
    kmdname = kmd.name
#    print('+++++kmd',kmdname) 
    colkmd = bpy.data.collections.new(kmdname)
    colafs.children.link(colkmd)

    for obj in kmd.obj:
#        print('obj type',obj.type)       
        if dictobjflag[obj.type] == 1:
#            print(obj.type)
            
            for h in range(obj.countmesh):
                mesh = obj.mesh[h]
                me = bpy.data.meshes.new(afsname+'-'+kmdname+'-'+str(obj.id)+'-'+str(mesh.id))
                ob = bpy.data.objects.new(afsname+'-'+kmdname+'-'+str(obj.id)+'-'+str(mesh.id),me)
                colkmd.objects.link(ob)
            
                bm = bmesh.new()
                uv_layer = bm.loops.layers.uv.new()
                
                
                
#                vtxcount = mesh.vtxcount
                for g in range(len(mesh.vtxcoorlist)):
                    vert = bm.verts.new(mesh.vtxcoorlist[g])
                    if mesh.fvfflag5 == 1:
                        vert.normal = mathutils.Vector(mesh.vtxnormlist[g])
                bm.verts.ensure_lookup_table()
                if mesh.fvfflag7 == 1:
                    color_layer = bm.loops.layers.color.new()
                    
                    
                for mat in obj.mat:
                    if mat.meshid == mesh.id:
                        if len(mat.texidlist) != 0:
                            matid = mat.texidlist[0]
                            print('texture llist',mat.texidlist)
                            if matid != 0xffffffff:
                                    matname = afsname+'-'+kmdname+'-'+str(matid)+'-'+str(mat.type)
                                    material = bpy.data.materials
                                    if matname in material:
                                        mtl = bpy.data.materials[matname]
                                    else:
                                        mtl = bpy.data.materials.new(matname)
                                    me.materials.append(mtl)
                                    mtl.use_nodes = True
                                    nodes = mtl.node_tree.nodes
                                    nodeTex = nodes.new(type='ShaderNodeTexImage')
                                    nodeTex.location = (-300,300)
                                    links = mtl.node_tree.links
                                    bsdf = nodes['Principled BSDF']
                                    links.new(nodeTex.outputs['Color'], bsdf.inputs['Base Color'])
                                    links.new(nodeTex.outputs['Alpha'], bsdf.inputs['Alpha'])
                                    if mat.type == 8:
                                        mtl.blend_method = 'BLEND'
                                        mtl.use_backface_culling = True
                                    if kmd.tex[matid].type not in[0x27,0x28,0x6]:
                                        texpath = fpath + 'xpr/'+afsname+'/'+kmdname+'/'
                                        texname = afsname+'-'+kmdname+'-'+str(matid)+'.dds'
                                        images = bpy.data.images
                                        print('obj',obj.id,'checking img',texname)
                                        if texname not in images:
                                            img = bpy.data.images.load(texpath+texname)
                                        if texname != nodeTex.image:
                                            nodeTex.image = images[texname]
                            
                        
                        cw = False
#                        print(obj.mesh[mat.meshid].vtxuvlist[0:10])
                        for i in range(len(mat.idx)):
                            
#                        for i in range(10):
                            
#                            print(cw)
                            try:
                                if not cw:
                                    face = bm.faces.new((bm.verts[mat.idx[i]],bm.verts[mat.idx[i+1]],bm.verts[mat.idx[i+2]]))
#                                    cw = not cw
                                    face.loops[0][uv_layer].uv = obj.mesh[mat.meshid].vtxuvlist[mat.idx[i]]
                                    face.loops[1][uv_layer].uv = obj.mesh[mat.meshid].vtxuvlist[mat.idx[i+1]]
                                    face.loops[2][uv_layer].uv = obj.mesh[mat.meshid].vtxuvlist[mat.idx[i+2]]
                                    if mesh.fvfflag7 == 1:
                                        color1 = mesh.vtxcolorlist[mat.idx[i]]
                                        color2 = mesh.vtxcolorlist[mat.idx[i+1]]
                                        color3 = mesh.vtxcolorlist[mat.idx[i+2]]
                                        face.loops[0][color_layer]=[color1[0]/255,color1[1]/255,color1[2]/255,color1[3]/255]
                                        face.loops[1][color_layer]=[color2[0]/255,color2[1]/255,color2[2]/255,color2[3]/255]
                                        face.loops[2][color_layer]=[color3[0]/255,color3[1]/255,color3[2]/255,color3[3]/255]
                                else:
                                    face = bm.faces.new((bm.verts[mat.idx[i]],bm.verts[mat.idx[i+2]],bm.verts[mat.idx[i+1]]))
#                                    cw = not cw
                                    face.loops[0][uv_layer].uv = obj.mesh[mat.meshid].vtxuvlist[mat.idx[i]]
                                    face.loops[1][uv_layer].uv = obj.mesh[mat.meshid].vtxuvlist[mat.idx[i+2]]
                                    face.loops[2][uv_layer].uv = obj.mesh[mat.meshid].vtxuvlist[mat.idx[i+1]]
                                    if mesh.fvfflag7 == 1:
                                        color1 = mesh.vtxcolorlist[mat.idx[i]]
                                        color2 = mesh.vtxcolorlist[mat.idx[i+2]]
                                        color3 = mesh.vtxcolorlist[mat.idx[i+1]]
                                        face.loops[0][color_layer]=[color1[0]/255,color1[1]/255,color1[2]/255,color1[3]/255]
                                        face.loops[1][color_layer]=[color2[0]/255,color2[1]/255,color2[2]/255,color2[3]/255]
                                        face.loops[2][color_layer]=[color3[0]/255,color3[1]/255,color3[2]/255,color3[3]/255]
#                                print(i,i+1,i+2)
                                
                            except IndexError:
                                cw = not cw
                                continue
                            except ValueError:
                                cw = not cw
                                continue
                            cw = not cw
                            face.material_index = mat.id
                            
#                                print('vertex color ',mesh.vtxcolorlist[mat.idx[i+2]][3]/0xff)
#                                face.loops[0][color_layer] = [1.0,0,1,1.0]
#                                face.loops[1][color_layer] = [1.0,1,0,1.0]
#                                face.loops[2][color_layer] = [0,1,1,1.0]
#                                face.loops[0][color_layer] = [mesh.vtxcolorlist[mat.idx[i]][0]/0xff,mesh.vtxcolorlist[mat.idx[i]][1]/0xff,mesh.vtxcolorlist[mat.idx[i]][2]/0xff,mesh.vtxcolorlist[mat.idx[i]][3]/0xff]
#                                face.loops[1][color_layer] = [mesh.vtxcolorlist[mat.idx[i+1]][0]/0xff,mesh.vtxcolorlist[mat.idx[i+1]][1]/0xff,mesh.vtxcolorlist[mat.idx[i+1][2]/0xff,mesh.vtxcolorlist[mat.idx[i+1]][3]/0xff]
#                                face.loops[2][color_layer] = [mesh.vtxcolorlist[mat.idx[i+2]][0]/0xff,mesh.vtxcolorlist[mat.idx[i+2]][1]/0xff,mesh.vtxcolorlist[mat.idx[i+2][2]/0xff,mesh.vtxcolorlist[mat.idx[i+2]][3]/0xff]
                            if mesh.fvfflag5 == 1:
                                face.smooth = True
#                            bm.faces.smooth = True
                            
                            
                            
#                            print(i,i+1,i+2)
#                            print(mesh.vtxuvlist[i],mesh.vtxuvlist[i+1],mesh.vtxuvlist[i+2])
                            
                                
                bm.to_mesh(me)
                bm.free
#                for faces in me.polygons:
#                    faces.use_smooth = True
#                me.use_auto_smooth = True
                
                
    ####### pivot set
    if hieflag == 1:
        for pivotid in kmd.pivotlist:
            pivotobjstr = afsname+'-'+kmdname+'-'+str(pivotid)+'-'
    #        print('pivot str',pivotobjstr)
            # get pivot object and set coor
            for object in colkmd.objects:
                if pivotobjstr in object.name:
    #                print('pivot name',object.name) 
                    
                    object.location.x += kmd.obj[pivotid].locx
                    object.location.y += kmd.obj[pivotid].locy
                    object.location.z += kmd.obj[pivotid].locz
                    # set bone objects
                    addweight(pivotid,object)
                    addarmature(pivotid,pivotflag=1)
                    nextobj = object
                    buildhie(pivotid,nextobj)
                    bpy.ops.object.mode_set(mode='OBJECT') 
                    
def addarmature(objid,pivotflag):
    if kmd.obj[objid].type in[1]:
        global arm
        bonename = afsname+'-'+kmdname+'-'+str(objid)
        if pivotflag == 1:
            name = afsname+'-'+kmdname+'-'+'armature'+'-'+str(objid)
            
            arm = bpy.data.armatures.new(name)
            obarm = bpy.data.objects.new(name,arm)
            colkmd.objects.link(obarm)
            bpy.context.view_layer.objects.active = obarm
            bpy.ops.object.mode_set(mode='EDIT')
            bone = arm.edit_bones.new(bonename)
        else:
            parentboneid = kmd.hie[objid].parentboneid
            parentbonename = afsname+'-'+kmdname+'-'+str(parentboneid)
            bone = arm.edit_bones.new(bonename)
            parentbone = arm.edit_bones[parentbonename]
#            print(bone,arm.edit_bones[parentbonename])
            bone.parent = parentbone
        bone.head = bpy.data.objects[bonename+'-0'].location
        bone.tail = bone.head
        bone.tail.z = bone.head.z + 0.1
            
            

def addweight(objid,object):
    for hie in kmd.hie:
        try:
            hie.boneid
        except AttributeError:
            continue
        # the current mechod of reading hie has a problem: the first int(in HIE reading 
        # function) is the actual
        # offset count, including those empty off after all valid. the second number is
        # valid count. unless read all offsets, created all empty hie or set a empty flag,
        # the child obj id give to the next recurse will always have a problem fiding the 
        # correct hie. or like the current, searching in all hie until find the matched one.
        # need to rewrite HIEread in the future
        if hie.boneid == objid:
            print('obj add weight, id',hex(objid))
            obj = kmd.obj[objid]
            if obj.type == 1:
                weight = 1
                groupname = afsname+'-'+kmdname+'-'+str(objid)
                object.vertex_groups.new(name=groupname)
                objname = object.name
#                print(objname)
                mesh = bpy.data.meshes[objname]
                for i in range(len(mesh.vertices)):
                    object.vertex_groups[groupname].add([i],weight,'REPLACE')
            elif obj.type == 4:
                # this section is messy, need to be clarify in the future, mainly the name
                # for a joint, the fixed mesh it sticked to is the "bone", it's parent is the
                # real "parent bone"
                pareid = kmd.hie[objid].parentboneid
                
                preid = kmd.hie[pareid].parentboneid
                groupname = afsname+'-'+kmdname+'-'+str(pareid)
                reversename = afsname+'-'+kmdname+'-'+str(preid)
                object.vertex_groups.new(name=groupname)
                object.vertex_groups.new(name=reversename)
                objname = object.name
                print(objname)
                meshid = int(objname[-1])
                print('meshid',meshid)
                mesh = bpy.data.meshes[objname]
                print('meshname',mesh.name,'verticies',len(mesh.vertices))
                for i in range(len(mesh.vertices)):
                    if obj.mesh[meshid].fvfflag4 == 1:
                        weight1 = obj.mesh[meshid].vtxweightlist[i][0]
                        weight2 = obj.mesh[meshid].vtxweightlist[i][1]
                        object.vertex_groups[groupname].add([i],weight2,'REPLACE')
                        object.vertex_groups[reversename].add([i],weight1,'REPLACE')
                    else:
                        weight = obj.mesh[meshid].vtxweightlist[i]
            #            print(weight)
                        object.vertex_groups[groupname].add([i],1-weight,'REPLACE')
                        object.vertex_groups[reversename].add([i],weight,'REPLACE')
        
        

def buildhie(parentid,parentobj):
    for hie in kmd.hie:

        try:
            hie.boneid
        except AttributeError:
            continue
        if parentid == hie.boneid:  
#            print(hex(parentid),hie.cntobjlist) 
            for childid in hie.cntobjlist:
                
#                print('parent bone',hex(parentid),parentobj.name,'child bone',hex(childid))
                childstr = afsname+'-'+kmdname+'-'+str(childid)+'-'
                for object in colkmd.objects:
                    if childstr in object.name:
#                        print('childobj',object.name,'type',kmd.obj[childid].type,'parentobj',parentobj.name)
        #                print('---parent coor',parentobj.location.x,parentobj.location.y,parentobj.location.z)
        #                print(kmd.obj[childid].locx,kmd.obj[childid].locy,kmd.obj[childid].locz)
                        object.location.x += parentobj.location.x 
                        object.location.y += parentobj.location.y 
                        object.location.z += parentobj.location.z 
                        
                        if kmd.obj[childid].type != 4:
                            object.location.x += kmd.obj[childid].locx
                            object.location.y += kmd.obj[childid].locy
                            object.location.z += kmd.obj[childid].locz
        #                else:
        #                    object.location.x -= kmd.obj[childid].locx
        #                    object.location.y -= kmd.obj[childid].locy
        #                    object.location.z -= kmd.obj[childid].locz
        #                print('---child coor',object.location.x,object.location.y,object.location.z)
                        addweight(childid,object)
                        
                        nextobj = object
                        
                        # next bone object # NOTE: multiple mesh will cause the next hie add coordinate
                        # multiple times too. to aviod this, either put all meshes in one object or
                        # do something that only read the next hie for the first mesh. if seperate object
                        # into each material, change the condition too
                        if childstr + '0' in object.name:
                            addarmature(childid,pivotflag=0)
                            buildhie(childid,nextobj) 
        
                        
                    
#######################################            

# xprsplit
def xprsplit(off0,size):
    pass
    filename = afs.splitname
    xprname = kmd.name

    
    dir = fpath + 'xpr/' + filename + '/'
    file = dir + xprname + '.xpr'

    bufdata.seek(off0)
    fstream = bufdata.read(size)

    if os.path.exists(dir):
        print('dir existed')
    else:
        os.makedirs(dir)
        print('dir created')

    if os.path.exists(file):
        print(file,'existed')
    else:
        f = open(file,'wb')
        f.write(fstream)
        f.close
        print('file written')
        





def ReadFile(bufdata,filepath):

    

    global fpath
    global xprsplitflag
    global blenderflag
    global dictobjflag
    
    fpath,file = os.path.split(filepath)
    
    print('splited path',fpath)

                         #   ↓↓↓↓
    dictobjflag = {             
                        0:        0,    # weapons or items without animation, displayed as a solid object
                        1:        1,    ### fixed with animation, the armature is based on this type
                        2:        0,    #low poly mesh, not displayed in game, can not been displayed correctly without type 1
                        3:        0,    # objects without texture, the first layer are all 'tex,0xffffffff', either with normal or vertex color
                        4:        1,    ### joint with animation, together with type 1
                        5:        1,    ### (guess) mesh without animation and weight: eyes, accessories, mid poly corpse?
                        6:        0,    # attack effect, both ryu's weapon and enemies' attack. controled by effscr section(guess). many unused effects
                    }           
                #      ↑↑↑↑  #   ↑↑↑↑       edit these 0 and 1 to choose what type of 
                # do not     #          object you want to import. 0 means not import
                # change     # 
                # these      #

    blenderflag = 1
    xprsplitflag = 0
    
    chunkid = bufdata.read(4)
    if chunkid == b'AFS\x00':
        pass
        ReadAFS(file)



if __name__ == "__main__":
    register()

    # test call
    bpy.ops.import_test.some_data('INVOKE_DEFAULT')
