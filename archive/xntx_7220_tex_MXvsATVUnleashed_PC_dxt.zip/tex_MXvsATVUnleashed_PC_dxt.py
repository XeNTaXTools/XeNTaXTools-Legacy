from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("MX vs ATV Unleashed [PC]", ".dxt")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
	#noesis.logPopup()
	return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    if bs.readUInt() != 2: return 0
    return 1
	
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.readUInt()
    imgFmt = bs.readInt()
    print(hex(imgFmt))
    if imgFmt == 0x37:
        numColors = bs.readUInt()
        palette = bs.readBytes(numColors * 4)
        numMips = bs.readUInt()
        print(numMips, ":mipmaps")
        maxWidth = bs.readUInt()
        maxHeight = bs.readUInt()
        print(maxWidth, "x", maxHeight)        
        for i in range(numMips):
            imgWidth = bs.readUInt()
            imgHeight = bs.readUInt()
            datasize = bs.readUInt()
            data = bs.readBytes(datasize)
            data = rapi.imageDecodeRawPal(data, palette, imgWidth, imgHeight, 8, "b8 g8 r8 a8")
            untwid = bytearray()
            for x in range(imgWidth):
                for y in range(imgHeight):
                    idx = noesis.morton2D(x, y)
                    untwid += data[idx * 4:idx * 4 + 4]
            if imgWidth == maxWidth: #display top level mip only
                texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, untwid, noesis.NOESISTEX_RGBA32))
    else:
        unk = bs.readUInt()
        numMips = bs.readUInt()
        print(numMips, ":mipmaps")
        maxWidth = bs.readUInt()
        maxHeight = bs.readUInt()
        print(maxWidth, "x", maxHeight)        
        for i in range(numMips):
            imgWidth = bs.readUInt()
            imgHeight = bs.readUInt()
            datasize = bs.readUInt()
            data = bs.readBytes(datasize)
            if imgFmt == 0x26:
                texFmt = noesis.NOESISTEX_DXT1
            elif imgFmt == 0x36:
                texFmt = noesis.NOESISTEX_DXT5
            if imgWidth == maxWidth: #display top level mip only
                texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1