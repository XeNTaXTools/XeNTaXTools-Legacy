# Assassin's Creed: Origins model plugin for Noesis
# Version 1.0
# by theawesomecoder61 (pineapples721)
#
# Version 1.0 (3/27/2019):
# - initial version

from inc_noesis import *
import math
import os
import struct

MDL_MAGIC = 1096652136
MSH_DATA = 105229237

class submeshObj(object):
	def __init__(self):
		self.vertices = []
		self.indices = []
		self.normals = []
		self.uvs = []
		self.boneIndices = []
		self.boneIndices2 = []
		self.boneWeights = []
		self.boneWeights2 = []
		self.numVertices = 0
		self.numIndices = 0
		self.vertexOffset = 0
		self.faceOffset = 0

def registerNoesisTypes():
	handle = noesis.register("Assassin's Creed: Origins model", ".acor")
	noesis.setHandlerTypeCheck(handle, mdlValidate)
	noesis.setHandlerLoadModel(handle, mdlLoadModel)

	noesis.logPopup()
	return 1

def mdlValidate(data):
	bs = NoeBitStream(data)
	if bs.readInt() != MDL_MAGIC:
		print("Not a model file")
		return 0
	return 1

def mdlLoadModel(data, mdlList):
	bs = NoeBitStream(data)
	submeshes = []
	meshes = []
	vertex_pos = 0
	face_pos = 0

	# header
	bs.seek(8, NOESEEK_REL)
	filename_size = bs.readInt()
	bs.seek(filename_size + 10, NOESEEK_REL)

	# mesh
	bs.seek(11, NOESEEK_REL)
	a_count = bs.readInt()
	bs.seek(4, NOESEEK_REL)

	# bones
	if a_count > 0:
		bone_count = bs.readInt()
		print(bs.tell())
		if bone_count > 0:
			bs.seek(bone_count * 81, NOESEEK_REL)

	# precursor to compiled mesh
	bs.seek(41 + 17, NOESEEK_REL)

	# the mesh data block may appear after the compiled mesh block (ex. SHP_ORM_EXT_Hull_100M_01_LOD0)
	if bs.readInt() == MSH_DATA:
		vertextable_size = 20

		# mesh data
		bs.seek(6, NOESEEK_REL)
		mesh_count = bs.readInt()
		for i in range(0, mesh_count):
			msh = submeshObj()
			bs.seek(20, NOESEEK_REL)
			msh.numVertices = bs.readInt()
			bs.seek(4, NOESEEK_REL)
			msh.numFaces = bs.readInt()
			bs.seek(4, NOESEEK_REL) # texture index
			submeshes.append(msh)

		print(bs.tell())

		# vertices
		vertexdata_size = bs.readInt()
		vertex_pos = bs.tell()
		bs.seek(vertexdata_size, NOESEEK_REL)

		bs.seek(8, NOESEEK_REL)

		# faces
		facesdata_size = bs.readInt()
		face_pos = bs.tell()
		bs.seek(facesdata_size, NOESEEK_REL)

		# submeshes
		mesh_count_2 = bs.readInt()
		print("Submeshes @ " + str(bs.tell()))
		for i in range(0, mesh_count_2):
			bs.seek(24, NOESEEK_REL)
			#submeshes[i].faceOffset = bs.readInt()
			#submeshes[i].vertexOffset = bs.readInt()
	else:
		# compiled mesh
		bs.seek(5, NOESEEK_REL)
		vertextable_size = bs.readInt()
		num1 = bs.readInt()
		num2 = bs.readInt()
		unknown2count = bs.readInt()
		bs.seek(25, NOESEEK_REL)

		# fix vertex table size
		if vertextable_size != 8 and vertextable_size != 16:
			vertextable_size = vertextable_size # nothing useful
		else:
			vertextable_size = num1

		# submeshes
		mesh_count = bs.readInt()
		for i in range(0, mesh_count):
			msh = submeshObj()
			bs.seek(16, NOESEEK_REL)
			msh.faceOffset = bs.readInt()
			msh.vertexOffset = bs.readInt()
			submeshes.append(msh)

		# unknown0
		if num2 != 0:
			u0_size = bs.readInt()
			bs.seek(u0_size, NOESEEK_REL)
		else:
			bs.seek(0, NOESEEK_REL) # useless

		# vertices
		vertexdata_size = bs.readInt()
		vertex_pos = bs.tell()
		bs.seek(vertexdata_size, NOESEEK_REL)

		# vertex weights
		if num2 == 0:
			bs.seek(8, NOESEEK_REL)
		else:
			vertexweightsdata_size = bs.readInt()
			bs.seek(vertexweightsdata_size, NOESEEK_REL)

		# faces
		facesdata_size = bs.readInt()
		face_pos = bs.tell()
		bs.seek(facesdata_size, NOESEEK_REL)

		# unknown2
		u2_size = bs.readInt()
		bs.seek(u2_size, NOESEEK_REL)

		# unknown3
		u3_size = bs.readInt()
		bs.seek(u3_size, NOESEEK_REL)

		# unknown4
		u4_size = bs.readInt()
		bs.seek(u4_size, NOESEEK_REL)

		bs.seek(8, NOESEEK_REL)

		# mesh data
		bs.seek(10, NOESEEK_REL)
		mesh_count_2 = bs.readInt()
		for i in range(0, mesh_count_2):
			bs.seek(20, NOESEEK_REL)
			submeshes[i].numVertices = bs.readInt()
			bs.seek(4, NOESEEK_REL)
			submeshes[i].numFaces = bs.readInt()
			bs.seek(4, NOESEEK_REL) # texture index

	print("Vertex table size: " + str(vertextable_size))
	print("Vertex pos: " + str(vertex_pos))
	print("Face pos: " + str(face_pos))

	# create model and add to mdlList
	meshes = createMeshes(bs, submeshes, mesh_count, vertextable_size, vertex_pos, face_pos)
	mdl = NoeModel(meshes)
	mdlList.append(mdl)
	return 1

def createMeshes(bs, submeshes, mesh_count, vertextable_size, vertex_pos, face_pos):
	meshes = []
	vCt = 0
	fCt = 0

	# create meshes
	for i in range(0, mesh_count):
		print("Face offset: " + str(submeshes[i].faceOffset))
		print("Vertex offset: " + str(submeshes[i].vertexOffset))
		print("Faces: " + str(submeshes[i].numFaces))
		print("Vertices: " + str(submeshes[i].numVertices))

		# vertices
		#bs.seek(vertex_pos + (vCt * vertextable_size), NOESEEK_ABS)
		bs.seek(vertex_pos + (submeshes[i].vertexOffset * vertextable_size), NOESEEK_ABS)
		for j in range(0, submeshes[i].numVertices):
			x = bs.readShort()
			y = bs.readShort()
			z = bs.readShort()

			if vertextable_size == 12:
				bs.seek(2, NOESEEK_REL)
				u = bs.readShort()
				v = bs.readShort()
				submeshes[i].uvs.append(NoeVec3((u, v, 0)))
			elif vertextable_size == 16:
				scale = bs.readShort()
				if scale != 0:
					x /= scale
					y /= scale
					z /= scale
				bs.seek(4, NOESEEK_REL)
				u = bs.readShort()
				v = bs.readShort()
				submeshes[i].uvs.append(NoeVec3((u, v, 0)))
			elif vertextable_size == 20:
				scale = bs.readShort()
				if scale != 0:
					x /= scale
					y /= scale
					z /= scale
				nx = bs.readShort()
				ny = bs.readShort()
				nz = bs.readShort()
				submeshes[i].normals.append(NoeVec3((nx, ny, nz)))
				bs.seek(2, NOESEEK_REL)
				u = bs.readShort()
				v = bs.readShort()
				submeshes[i].uvs.append(NoeVec3((u, v, 0)))
			elif vertextable_size == 24:
				scale = bs.readShort()
				if scale != 0:
					x /= scale
					y /= scale
					z /= scale
				nx = bs.readShort()
				ny = bs.readShort()
				nz = bs.readShort()
				submeshes[i].normals.append(NoeVec3((nx, ny, nz)))
				bs.seek(2, NOESEEK_REL)
				u = bs.readShort()
				v = bs.readShort()
				submeshes[i].uvs.append(NoeVec3((u, v, 0)))
				bs.seek(6, NOESEEK_REL)
			elif vertextable_size == 28:
				scale = bs.readShort()
				if scale != 0:
					x /= scale
					y /= scale
					z /= scale
				nx = bs.readShort()
				ny = bs.readShort()
				nz = bs.readShort()
				submeshes[i].normals.append(NoeVec3((nx, ny, nz)))
				bs.seek(6, NOESEEK_REL)
				u = bs.readShort()
				v = bs.readShort()
				submeshes[i].uvs.append(NoeVec3((u, v, 0)))
				bs.seek(4, NOESEEK_REL)
			elif vertextable_size == 32:
				scale = bs.readShort()
				if scale != 0:
					x /= scale
					y /= scale
					z /= scale
				nx = bs.readShort()
				ny = bs.readShort()
				nz = bs.readShort()
				submeshes[i].normals.append(NoeVec3((nx, ny, nz)))
				bs.seek(6, NOESEEK_REL)
				u = bs.readShort()
				v = bs.readShort()
				submeshes[i].uvs.append(NoeVec3((u, v, 0)))
				submeshes[i].boneIndices.append(NoeVec4(bs.readByte(), bs.readByte(), bs.readByte(), bs.readByte()))
				submeshes[i].boneWeights.append(NoeVec4(bs.readByte(), bs.readByte(), bs.readByte(), bs.readByte()))
			elif vertextable_size == 36:
				scale = bs.readShort()
				if scale != 0:
					x /= scale
					y /= scale
					z /= scale
				nx = bs.readShort()
				ny = bs.readShort()
				nz = bs.readShort()
				submeshes[i].normals.append(NoeVec3((nx, ny, nz)))
				bs.seek(6, NOESEEK_REL)
				u = bs.readShort()
				v = bs.readShort()
				submeshes[i].uvs.append(NoeVec3((u, v, 0)))
				bs.seek(4, NOESEEK_REL)
				submeshes[i].boneIndices.append(NoeVec4(bs.readByte(), bs.readByte(), bs.readByte(), bs.readByte()))
				submeshes[i].boneWeights.append(NoeVec4(bs.readByte(), bs.readByte(), bs.readByte(), bs.readByte()))
			elif vertextable_size == 40:
				scale = bs.readShort()
				if scale != 0:
					x /= scale
					y /= scale
					z /= scale
				nx = bs.readShort()
				ny = bs.readShort()
				nz = bs.readShort()
				submeshes[i].normals.append(NoeVec3((nx, ny, nz)))
				bs.seek(6, NOESEEK_REL)
				u = bs.readShort()
				v = bs.readShort()
				submeshes[i].uvs.append(NoeVec3((u, v, 0)))
				bs.seek(4, NOESEEK_REL)
				submeshes[i].boneIndices.append(NoeVec4(bs.readByte(), bs.readByte(), bs.readByte(), bs.readByte()))
				submeshes[i].boneIndices2.append(NoeVec4(bs.readByte(), bs.readByte(), bs.readByte(), bs.readByte()))
				submeshes[i].boneWeights.append(NoeVec4(bs.readByte(), bs.readByte(), bs.readByte(), bs.readByte()))
				submeshes[i].boneWeights2.append(NoeVec4(bs.readByte(), bs.readByte(), bs.readByte(), bs.readByte()))
			elif vertextable_size == 44:
				scale = bs.readShort()
				if scale != 0:
					x /= scale
					y /= scale
					z /= scale
				nx = bs.readShort()
				ny = bs.readShort()
				nz = bs.readShort()
				submeshes[i].normals.append(NoeVec3((nx, ny, nz)))
				bs.seek(6, NOESEEK_REL)
				u = bs.readShort()
				v = bs.readShort()
				submeshes[i].uvs.append(NoeVec3((u, v, 0)))
				submeshes[i].boneIndices.append(NoeVec4(bs.readByte(), bs.readByte(), bs.readByte(), bs.readByte()))
				submeshes[i].boneIndices2.append(NoeVec4(bs.readByte(), bs.readByte(), bs.readByte(), bs.readByte()))
				submeshes[i].boneWeights.append(NoeVec4(bs.readByte(), bs.readByte(), bs.readByte(), bs.readByte()))
				submeshes[i].boneWeights2.append(NoeVec4(bs.readByte(), bs.readByte(), bs.readByte(), bs.readByte()))
				bs.seek(4, NOESEEK_REL)
			elif vertextable_size == 48:
				scale = bs.readShort()
				if scale != 0:
					x /= scale
					y /= scale
					z /= scale
				nx = bs.readShort()
				ny = bs.readShort()
				nz = bs.readShort()
				submeshes[i].normals.append(NoeVec3((nx, ny, nz)))
				bs.seek(6, NOESEEK_REL)
				u = bs.readShort()
				v = bs.readShort()
				submeshes[i].uvs.append(NoeVec3((u, v, 0)))
				submeshes[i].boneIndices.append(NoeVec4(bs.readByte(), bs.readByte(), bs.readByte(), bs.readByte()))
				submeshes[i].boneIndices2.append(NoeVec4(bs.readByte(), bs.readByte(), bs.readByte(), bs.readByte()))
				submeshes[i].boneWeights.append(NoeVec4(bs.readByte(), bs.readByte(), bs.readByte(), bs.readByte()))
				submeshes[i].boneWeights2.append(NoeVec4(bs.readByte(), bs.readByte(), bs.readByte(), bs.readByte()))
				bs.seek(4, NOESEEK_REL)
			else:
				bs.seek(vertextable_size - 6, NOESEEK_REL)

			submeshes[i].vertices.append(NoeVec3((y, z, x)))

		# faces
		#bs.seek(face_pos + (fCt * 6), NOESEEK_ABS)
		bs.seek(face_pos + (submeshes[i].faceOffset * 2), NOESEEK_ABS)
		for j in range(0, submeshes[i].numFaces):
			x = bs.readUShort()
			y = bs.readUShort()
			z = bs.readUShort()
			submeshes[i].indices.extend([x, y, z])

		mesh = NoeMesh(submeshes[i].indices, submeshes[i].vertices)
		mesh.name = "mesh" + str(i)

		vCt += submeshes[i].numVertices
		fCt += submeshes[i].numFaces

		# add normals and UVs
		for j in range(0, submeshes[i].numVertices):
			#mesh.normals.append(submeshes[i].normals[i].normalize())
			mesh.uvs.append(submeshes[i].uvs[i])

		meshes.append(mesh)

	return meshes

def generateNormals(submesh):
	normals = []
	for i in range(0, submesh.numIndices, 3):
		v1 = submesh.vertices[i]
		v2 = submesh.vertices[i + 1]
		v3 = submesh.vertices[i + 2]

		vv1 = v2 - v1
		vv2 = v3 - v1
		normals.append(vv2.cross(vv1))
		normals.append(vv2.cross(vv1))
		normals.append(vv2.cross(vv1))
	return normals
