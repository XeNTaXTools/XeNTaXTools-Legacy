# DragonQuestLoc

DragonQuestLoc is a GUI tool written in C# to translate MES files from Dragon Quest Monsters: Joker 3 for the Nintendo 3DS.

It is written and maintained by x1nixmzeng. The source code is on [GitHub][0].


For general game format discussions visit [XeNTaX][1].


## Screenshot

![screenshot of tool](http://i.imgur.com/mz53Uc0.png)


## Licence

This code has been placed in the public domain

[0]:https://github.com/x1nixmzeng/DragonQuestLoc
[1]:http://forum.xentax.com/viewforum.php?f=10
