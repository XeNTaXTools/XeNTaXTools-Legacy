from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Jetpack Joyride", ".tex")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    Magic = bs.readBytes(4)
    if Magic != b'\x54\x45\x58\x01':
        return 0
    return 1

def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.seek(0x8, NOESEEK_ABS) 
    imgFmt = bs.readByte()
    bs.seek(0x13, NOESEEK_REL) 
    imgWidth = bs.readInt()            
    imgHeight = bs.readInt()           
    bs.seek(0xc, NOESEEK_REL) 
    datasize = bs.readInt()
    data = bs.readBytes(datasize)
    #raw
    if imgFmt == 4:
        data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "a4 b4 g4 r4") 
        texFmt = noesis.NOESISTEX_RGBA32
    elif imgFmt == 8:
        data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "r8 g8 b8 a8")
        texFmt = noesis.NOESISTEX_RGBA32
    #unknown, not handled
    else:
        print("WARNING: Unhandled image format")
        return None
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1