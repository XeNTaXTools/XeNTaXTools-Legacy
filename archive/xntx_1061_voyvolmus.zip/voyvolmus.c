/*
    Copyright 2009 Luigi Auriemma

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA

    http://www.gnu.org/licenses/gpl-2.0.txt
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <ctype.h>
#include <sys/stat.h>
#include "mywav.h"

#ifdef WIN32
    #include <direct.h>
    #define PATHSLASH   '\\'
    #define MAKEDIR(x)  mkdir(x)   
#else
    #include <unistd.h>
    #define PATHSLASH   '/'
    #define MAKEDIR(x)  mkdir(name, 0755)
#endif

typedef uint8_t     u8;
typedef uint16_t    u16;
typedef uint32_t    u32;



#define VER     "0.1a"



int check_overwrite(u8 *fname);
FILE *newfile(int fnum, int size);
int fgetxx(FILE *fd, int bits);
void read_err(void);
void std_err(void);



typedef struct {
    int     one;    // ???
    int     offset;
    int     size;
} voyvol_t;



int main(int argc, char *argv[]) {
    voyvol_t    *voyvol;
    FILE    *fd     = NULL,
            *fdo    = NULL;
    int     len,
            i,
            files,
            type,
            rem,
            fsize,
            buffsz  = 0;
    u8      *buff   = NULL,
            *fin,
            *fdir;

    setbuf(stdout, NULL);

    fputs("\n"
        "Voyeur II VOL audio extractor "VER"\n"
        "by Luigi Auriemma\n"
        "e-mail: aluigi@autistici.org\n"
        "web:    aluigi.org\n"
        "\n", stdout);

    if(argc < 3) {
        printf("\n"
            "Usage: %s <file.VOL> <output_folder>\n"
            "\n", argv[0]);
        exit(1);
    }
    fin  = argv[1];
    fdir = argv[2];

    printf("- open %s\n", fin);
    fd = fopen(fin, "rb");
    if(!fd) std_err();

    printf("- change folder %s\n", fdir);
    if(chdir(fdir) < 0) std_err();
    
    type =  fgetxx(fd, 32);
    if(type != 0x000c4449) printf("- the file has a wrong signature (%08x)\n", type);
            fgetxx(fd, 16);
    files = fgetxx(fd, 32);
            fgetxx(fd, 32); // total file size

    files--;
    voyvol = calloc(files, sizeof(voyvol_t));
    if(!voyvol) std_err();
    fread(voyvol, 1, files * sizeof(voyvol_t), fd);

    for(i = 0; i < files; i++) {
        printf("  %-4d %08x %08x %08x\n", i, voyvol[i].one, voyvol[i].offset, voyvol[i].size);

        if(fseek(fd, voyvol[i].offset, SEEK_SET)) std_err();

        if(fseek(fd, 42, SEEK_CUR)) std_err();  // ???
        fsize = fgetxx(fd, 32);
        if(fseek(fd, 16, SEEK_CUR)) std_err();  // ???

        fdo = newfile(i, fsize);
        rem = voyvol[i].size - 62;

        for(;;) {
            type = fgetxx(fd, 32);
            len  = fgetxx(fd, 32);
            rem -= 4 + 4;
            if((len <= 0) || (rem <= 0)) break; // each file has ever a len=0 at the end
            rem -= len;

            if(type == 1) {     // audio
                if(len > buffsz) {
                    buffsz = len;
                    buff = realloc(buff, buffsz);
                    if(!buff) std_err();
                }
                len = fread(buff, 1, len, fd);
                if(fdo) fwrite(buff, 1, len, fdo);
            } else {            // video? skip
                if(fseek(fd, len, SEEK_CUR)) std_err();
            }
        }
        if(fdo) fclose(fdo);
    }

    if(buff) free(buff);
    if(fdo) fclose(fdo);
    fclose(fd);
    printf("- done\n");
    return(0);
}



int check_overwrite(u8 *fname) {
    FILE    *fd;
    u8      ans[16];

    fd = fopen(fname, "rb");
    if(!fd) return(0);
    fclose(fd);
    printf("  the file already exists, do you want to overwrite it (y/N)? ");
    fgets(ans, sizeof(ans), stdin);
    if(tolower(ans[0]) != 'y') return(-1);
    return(0);
}



FILE *newfile(int fnum, int size) {
    mywav_fmtchunk  fmt;
    FILE    *fdo;
    u8      tmp[32];

    sprintf(tmp, "%08x.wav", fnum);
    if(check_overwrite(tmp) < 0) return(NULL);
    fdo = fopen(tmp, "wb");
    if(!fdo) std_err();

    fmt.wFormatTag       = 0x0001;
    fmt.wChannels        = 1;
    fmt.dwSamplesPerSec  = 11025;
    fmt.wBitsPerSample   = 8;
    fmt.wBlockAlign      = (fmt.wBitsPerSample / 8) * fmt.wChannels;
    fmt.dwAvgBytesPerSec = fmt.dwSamplesPerSec * fmt.wBlockAlign;
    mywav_writehead(fdo, &fmt, size, NULL, 0);

    return(fdo);
}



int fgetxx(FILE *fd, int bits) {
    u32     num;
    int     i,
            bytes;
    u8      tmp[4];

    bytes = bits >> 3;
    if(fread(tmp, 1, bytes, fd) != bytes) read_err();

    for(num = i = 0; i < bytes; i++) {
        num |= (tmp[i] << (i << 3));
    }
    return(num);
}



void read_err(void) {
    printf("\nError: the input file is corrupted or incomplete\n");
    exit(1);
}



void std_err(void) {
    perror("\nError");
    exit(1);
}


