
Version for "char" meshes, hordesuperbattledroid.msh, obicloak.msh, yoda.msh

Before creating obj files with hex2obj, File/SaveAs Mmesh:
for yoda's left foot you need a manual correction:

0x6FF6 806
Vb1
36 16
0x140 747
021000
0x0 255

(then delete superfluous faces in your 3D sw)

Rename all *.objx to *.obj. Should be save...

----------------------------------------------------------- 

>>> exe only. Needs

DLL_MakeH2O.dll
and
libgcc_s_dw2-1.dll (for W7 and higher)

There's MakeObj/MakeH2O zips where the dlls are contained.

---------------------------------

For static meshes (m03_droidcontrolship.msh for example) use version from here:

Re: Extracting .msh files Star Wars: Ep III - RotS (2005) [XBOX]
https://forum.xentax.com/viewtopic.php?f=16&t=22057&p=162462#p162462

Some submeshes need manual correction (switch from 'Strip' to 'noStr')

have fun
shak-otay, April 2020
