# -*- coding: utf-8 -*-
import os 
import shutil 

# script copy files from fdir, with correct filenames

fdir = "E:\\DXMD_DLC_UNPACK" # base unpack folder with nameMap file
fsrc = "E:\\md_files_DLC2\\" # folder with correct filenames 

def GetListForBackup(PathForBackup):
    ListForBackup = []
    for file in os.listdir(PathForBackup):
        path = os.path.join(PathForBackup, file)
        if not os.path.isdir(path):
            ListForBackup.append(path)
        else:
            ListForBackup += GetListForBackup(path)
    return ListForBackup


flist = []
fnames={}



f = open(fdir + '\\NameMap.txt')
line = f.readline()
while line:
 #print (line),
 hash_str = line[21:37]
 name_start = line.find(":/")
 name_end = line.find("]")
 name_str = line[name_start + 2 : name_end]
 name_str = name_str.replace("?", "_")
 #print("   |" + hash_str + "|  |" + name_str + "|")
 flist.append([(hash_str + ".bin") , name_str])
 #fnames[hash_str + ".bin"] = name_str
 line = f.readline()
 #print("next")
f.close()


filesList = GetListForBackup(fdir)

for files_ in filesList:
	fnames[os.path.basename(files_)] = files_



for fstr in flist:
	try:
		print("file: " + fstr[1])
		name = fnames.get(fstr[0], "")
		if (name != ""):
			print(name)
			
			new_file = fsrc +  fstr[1]
			new_file = new_file.replace("/","\\")
					
			if not os.path.exists(os.path.dirname(new_file)):
				os.makedirs(os.path.dirname(new_file))
							
			while os.path.exists(new_file + ".bin"):
				new_file = new_file + ".cpy"
				
			new_file = new_file	+ ".bin"

			
			shutil.copyfile(name,  new_file)
		else:
			print("UNKNOWN")
	except:
		print("#########################")
		print("ERROR::  HASH: "  + fstr[0])	
		print("ERROR::  NAME: "  + fstr[1])	
		print("#########################")
		print("")
		print("")
		print("")

	
	
 