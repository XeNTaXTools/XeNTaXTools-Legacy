import os
import bpy

fdir = "E:\\md_files_DLC\\objects\\"


def reset_blend():
    #bpy.ops.wm.read_factory_settings()
    for scene in bpy.data.scenes:
        for obj in scene.objects:
            scene.objects.unlink(obj)
    # only worry about data in the startup scene
    for bpy_data_iter in (
            bpy.data.objects,
            bpy.data.meshes,
            bpy.data.lamps,
            bpy.data.cameras,
            ):
        for id_data in bpy_data_iter:
            bpy_data_iter.remove(id_data)



def GetListForBackup(PathForBackup):
 ListForBackup = []
 for file in os.listdir(PathForBackup):
  path = os.path.join(PathForBackup, file)
  if not os.path.isdir(path):
   namefile = os.path.basename(file)
   name_lenght = namefile.find(".")
   if not (name_lenght == -1):
    formatfile = namefile[name_lenght:]
    if not (formatfile.find("prim") == -1):
     #print (path	)		
     ListForBackup.append(path)
  else:
   ListForBackup += GetListForBackup(path)
 return ListForBackup

filesList = GetListForBackup(fdir)

for file in filesList:
 print("------------------------------------")
 print(file)
 try:
  reset_blend()
  bpy.ops.import_scene.deusexmd(filepath=file)
  bpy.ops.export_scene.fbx(filepath=(file + ".fbx"))

 except:
  print ("ERROR")
