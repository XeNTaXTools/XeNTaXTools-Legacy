#include <stdio.h>
#include <stdlib.h>
#include <memory.h>

#include "msvc/stdint.h"

#include "minilzo.h"

#define BLOCKSIZE 512000


static struct header
{
    uint32 filesize;
    uint32 unpacked_block;
    uint32 packed_block;
} header;


// Work-memory needed for compression. Allocate memory in units
// of `lzo_align_t' (instead of `char') to make sure it is properly aligned.
#define HEAP_ALLOC(var,size) \
    lzo_align_t __LZO_MMODEL var [ ((size) + (sizeof(lzo_align_t) - 1)) / sizeof(lzo_align_t) ]

static HEAP_ALLOC(wrkmem,LZO1X_1_MEM_COMPRESS);


void showUsage(char *argv0)
{
    printf("    Usage: %s [-option] <infile> <outfile>\n\n",argv0);

    printf(" Examples: %s -c ff801b17.dec ff801b17.bin\n",argv0);
    printf("           %s -d ff801b17.bin ff801b17.dec\n\n",argv0);

    printf(" Switches:\n");
    printf("    -c           compress\n");
    printf("    -d           decompress\n");
}


int main(int argc, char *argv[])
{
    lzo_uint out_len;
    FILE *fin, *fout;
    uint32 i, r, blocks, last;
    uint8 *in, *out, mode=0;

    printf("JADE Game Engine .bin file pack-tool v1.0 by xor37h/hitmen\n");
    printf("using LZO real-time data compression library (v%s, %s).\n\n", lzo_version_string(), lzo_version_date());

    if(argc < 4)
    {
        showUsage(argv[0]);
        return 1;
    }

    if(argv[1][0] == '-')
    {
        switch(argv[1][1])
        {
            case 'c':
            case 'C':
                mode = 1;
                break;
            case 'd':
            case 'D':
                mode = 2;
                break;
            default:
                showUsage(argv[0]);
                return 2;
        }
    }

    if (lzo_init() != LZO_E_OK)
    {
        printf("internal error - lzo_init() failed !!!\n");
        return 3;
    }

    fin = fopen(argv[2], "rb");
    if (!fin) 
    {
        printf("error, could not open the file %s\n", argv[2]);
        return 4;
    }

    fout = fopen(argv[3],"wb");
    if (!fout)
    {
        printf("error, could write to the file %s\n", argv[3]);
        return 5;
    }

    switch(mode)
    {
        case 1:
            fseek(fin, 0, SEEK_END);
            header.filesize = ftell(fin);
            fseek(fin, 0, SEEK_SET);

            in = malloc(BLOCKSIZE*2);
            out = malloc(BLOCKSIZE*2);

            blocks = header.filesize / BLOCKSIZE;
            last = header.filesize - (blocks * BLOCKSIZE);

            for(i=0; i<blocks; i++)
            {
                header.unpacked_block = BLOCKSIZE;

                lzo_memset(in,0,BLOCKSIZE*2);
                lzo_memset(out,0,BLOCKSIZE*2);

                fread(in,1,BLOCKSIZE,fin);

                r = lzo1x_1_compress(in,BLOCKSIZE,out,&out_len,wrkmem);
                if (r != LZO_E_OK)
                {
                    printf("error, during packing...\n");
                    return 6;
                }

                if (out_len >= BLOCKSIZE)
                {
                    memcpy(out,in,BLOCKSIZE);
                    out_len = BLOCKSIZE;
                }
                
                header.packed_block = out_len;

                fwrite(&header,1,sizeof(header),fout);

                fwrite(out,1,out_len,fout);

                memset(&header,0,sizeof(header));
            }

            if(last)
            {
                header.unpacked_block = last;

                lzo_memset(in,0,BLOCKSIZE*2);
                lzo_memset(out,0,BLOCKSIZE*2);

                fread(in,1,last,fin);

                r = lzo1x_1_compress(in,last,out,&out_len,wrkmem);
                if (r != LZO_E_OK)
                {
                    printf("error, during packing...\n");
                    return 6;
                }

                if (out_len >= last)
                {
                    memcpy(out,in,last);
                    out_len = last;
                }

                header.packed_block = out_len;

                fwrite(&header,1,sizeof(header),fout);

                fwrite(out,1,out_len,fout);
            }

            // pad to blocksize 2048
            header.filesize = ftell(fout);
            i = 2048 - (header.filesize % 2048);
            memset(out,0,i);
            fwrite(out,1,i,fout);

            // update header.filesize in the start
            header.filesize += i-4;
            fseek(fout, 0, SEEK_SET);
            fwrite(&header.filesize,1,4,fout);

            free(in); 
            free(out);

            break;
        
        case 2:

            fread(&header, 1, sizeof(header), fin);

            while(header.unpacked_block)
            {
                in = malloc(header.packed_block);
                out = malloc(header.unpacked_block);

                lzo_memset(in,0,header.packed_block);
                lzo_memset(out,0,header.unpacked_block);

                fread(in, 1, header.packed_block, fin);

                // if packed_block == unpacked_block then its not compressed!
                if(header.packed_block == header.unpacked_block)
                {
                    memcpy(out, in, header.unpacked_block);
                }
                else
                {
                    r = lzo1x_decompress(in,header.packed_block,out,&out_len,NULL);
                    if((r != LZO_E_OK) || (out_len != header.unpacked_block))
                    {
                        printf("error, during unpack...\n");
                        return 7;
                    }
                }

                fwrite(out, 1, header.unpacked_block, fout);
    
                free(in); 
                free(out);

                fread(&header, 1, sizeof(header), fin);
            }

            break;

	default:
		printf("wtf?!\n");
		return -1;
            break;
    }

    printf("all done, enjoy...\n");

    fclose(fin);
    fclose(fout); 

    return 0;
}
