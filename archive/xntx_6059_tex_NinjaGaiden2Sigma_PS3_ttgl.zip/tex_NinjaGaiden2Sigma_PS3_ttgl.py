from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Ninja Gaiden 2 Sigma textures [PS3]", ".gmd")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    Magic = bs.readBytes(4)
    if Magic != b'TMC\x00':
        return 0
    return 1
    
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data, NOE_BIGENDIAN)
    myString = bs.readBytes(len(data)) 
    myIndex = myString.find(b"\x54\x54\x47\x00")
    bs.seek(myIndex + 0x10, NOESEEK_ABS)
    TTG_SZ = bs.readUInt()
    total_files = bs.readUInt()
    #print(total_files, ":total_files")
    total_files2 = bs.readUInt() #??
    zero = bs.readInt()
    TTG_header_SZ = bs.readUInt()
    unk = bs.readInt()
    unk2 = bs.readInt()
    zero2 = bs.readInt()
    files_in_ttgl = bs.readUInt() #num files stored in ttgl file
    bs.seek(0xc, NOESEEK_REL)
    section_SZ = total_files * 4
    check = section_SZ % 16
    if check != 0:
        section_SZ = (section_SZ - check) + 16  
    #print(hex(section_SZ), ":section size")
    fName = rapi.getExtensionlessName(rapi.getInputName()) + ".ttgl"
    print(fName, ":fname")
    try:
        bs2 = NoeBitStream(rapi.loadIntoByteArray(fName))
    except:
        noesis.logPopup()
        print("\n", "Missing *.ttgl file!", "\n")
    start = bs.tell()
    tmp2 = 0
    tmp3 = 0
    for i in range(total_files):
        offset = bs.readUInt()         #section 1
        #print(hex(offset), ":offset")
        tmp = bs.tell()
        if i == 0:
            bs.seek(start + section_SZ, NOESEEK_ABS)
        else:
            bs.seek(tmp2, NOESEEK_ABS)
        datasize = bs.readUInt()       #section 2
        #print(datasize, ":datasize")
        tmp2 = bs.tell()
        if i == 0:
            bs.seek(start + (section_SZ * 2), NOESEEK_ABS)
        else:
            bs.seek(tmp3, NOESEEK_ABS)
        imgFmt = bs.readUByte()         #section 3
        #print(hex(imgFmt), ":imgFmt")
        unk = bs.readByte()
        unk = bs.readByte()
        unk = bs.readByte()
        unk = bs.readInt()
        #print(hex(bs.tell()), "here3")
        imgWidth = bs.readUShort()
        imgHeight = bs.readUShort()
        #print(imgWidth, "x", imgHeight)
        mips = bs.readUShort() #??
        file_flag = bs.readUShort()
        #print(file_flag, ":file_flag")
        bs.seek(0x8, NOESEEK_REL)
        texName = bs.readBytes(8).decode("ASCII").rstrip("\x00")
        texName = texName + "_" + str(i)
        tmp3 = bs.tell()
        #print(texName, ":file name")
        if file_flag == 0:
            bs2.seek(offset + 0x80, NOESEEK_ABS)
            data = bs2.readBytes(datasize)  
            #print("reading from ttgl")
        else:
            bs.seek(myIndex + offset, NOESEEK_ABS)
            data = bs.readBytes(datasize)      
            #print("reading from gmd")
        #DXT1
        if imgFmt == 0x86:
            texFmt = noesis.NOESISTEX_DXT1
        #DXT3
        elif imgFmt == 0x87:
            texFmt = noesis.NOESISTEX_DXT3
        #DXT5
        elif imgFmt == 0x88:
            texFmt = noesis.NOESISTEX_DXT5
        #ARGB32 swizzled
        elif imgFmt == 0x85:
            untwid = bytearray()
            for x in range(0, imgWidth):
                for y in range(0, imgHeight):
                    idx = noesis.morton2D(x, y)
                    untwid += data[idx*4:idx*4+4]
            data = rapi.imageDecodeRaw(untwid, imgWidth, imgHeight, "a8 r8 g8 b8")
            texFmt = noesis.NOESISTEX_RGBA32        
        bs.seek(tmp, NOESEEK_ABS)
        texList.append(NoeTexture(texName, imgWidth, imgHeight, data, texFmt))
    return 1