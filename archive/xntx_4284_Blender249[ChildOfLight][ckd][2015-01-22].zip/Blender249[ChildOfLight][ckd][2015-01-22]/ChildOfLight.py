import newGameLib
reload(newGameLib)
from newGameLib import *
import Blender
	
import math
from math import *

def ckdParser(filename,g):
	#g.debug=True
	g.endian='>'
	A=g.i(2)
	print A
	
	if A[0]==8:
		B=g.i(6)
		g.i(B[5])
		g.i(23)
		g.B(1)
		g.H(52)
		g.H(94)
		g.H(94)
		g.seek(13745)
		g.f(21)
		for m in range(20):
			g.B(6)
	
	if A[0]==12:
		g.seek(52)
		new=open(filename+'.dds','wb')
		new.write(g.read(g.fileSize()-g.tell()))
		new.close()
	
	if A[0]==4:
		skeleton=Skeleton()
		skeleton.BONESPACE=True
		skeleton.NICE=True
		boneCount=g.i(1)[0]
		for m in range(boneCount):
			bone=Bone()
			name=str(g.i(1)[0])
			bone.parentID=g.i(1)[0]
			bone.matrix=Matrix4x4(g.f(16))
			skeleton.boneList.append(bone)
		skeleton.BINDMESH=True	
		skeleton.draw()	
		
	
	
	if A[0]==7:
		print A
		mesh=Mesh()
		matCount=g.i(1)[0]
		for n in range(matCount):
			mat=Mat()
			mat.TRIANGLE=True
			B=g.i(2)	
			for m in range(B[1]):
				mesh.faceList.append(g.i(3))
				mesh.matIDList.append(n)
				mesh.skinIndiceList.append([])
				mesh.skinWeightList.append([])
			mesh.matList.append(mat)	
		vertCount=g.i(1)[0]
		for m in range(vertCount):
			t=g.tell()
			mesh.vertPosList.append(g.f(3))
			g.seek(t+32)
			mesh.vertUVList.append(g.f(2))
			g.seek(t+40)
		boneCount=g.i(1)[0]
		for n in range(boneCount):
			boneID,boneName=g.i(2)
			g.f(4)
			g.f(4)
			g.f(4)
			g.f(4)
			count=g.i(1)[0]
			for m in range(count):
				vertID=g.i(1)[0]
				weight=g.f(1)[0]
				mesh.skinIndiceList[vertID].append(boneID)
				mesh.skinWeightList[vertID].append(weight)
		skin=Skin()
		mesh.skinList.append(skin)
		mesh.BINDSKELETON='armature'	
		mesh.draw()	
		g.debug=True
		
	g.tell()

	
def Parser():	
	global texDir,matList
	filename=input.filename
	print
	print filename
	print 
	ext=filename.split('.')[-1].lower()	
	
	
		
	if ext=='ckd':
		file=open(filename,'rb')
		g=BinaryReader(file)
		ckdParser(filename,g)
		file.close()
 
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
	
Blender.Window.FileSelector(openFile,'import','Child of Light *.ckd')