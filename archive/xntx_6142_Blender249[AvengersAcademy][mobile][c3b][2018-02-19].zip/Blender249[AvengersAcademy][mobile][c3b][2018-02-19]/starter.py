import newGameLib
from newGameLib import *
import Blender	

def c3bParser(filename,g):


	def getChildren(parent,n):
		n+=4
		bone=Bone()
		bone.parentName=parent.name
		skeleton.boneList.append(bone)
		bone.name=g.word(g.i(1)[0])	
		a=g.B(1)
		bone.matrix=Matrix4x4(g.f(16))	
		b=g.i(1)[0]
		for m in safe(g.i(1)[0]):
			getChildren(bone,n)

	a=g.B(6)
	sectionCount=g.i(1)[0]
	boneNamesList=[]
	skeletonList=[]
	meshList=[]
	nodeList=[]
	for i in safe(sectionCount):
		sectionName=g.word(g.i(1)[0])
		unk,offset=g.i(2)
		back=g.tell()
		g.seek(offset)
		if unk==2:
			nodeCount=g.i(1)[0]
			for m in safe(nodeCount):
				a=g.word(g.i(1)[0])
				b=g.B(1)[0]
				if b==0:
					c=g.f(16)
					d=g.i(1)[0]
					name1=g.word(g.i(1)[0])
					name2=g.word(g.i(1)[0])
					boneCount=g.i(1)[0]
					bindskeleton=Skeleton()
					bindskeleton.NICE=True
					boneNames=[]
					for m in safe(boneCount):
						bone=Bone()
						bindskeleton.boneList.append(bone)
						name=g.word(g.i(1)[0])
						bone.name=name
						bone.matrix=Matrix4x4(g.f(16)).invert()
						boneNames.append(name)
					#bindskeleton.draw()	
					boneNamesList.append(boneNames)	
					nodeList.append([c,d,name1,name2,boneNames])
					e=g.i(2)
					f1=g.i(e[0])
					f2=g.i(e[1])
				if b==1:	
					c=g.f(16)
					d=g.i(1)[0]
					global skeleton 
					skeleton=Skeleton()
					skeletonList.append(skeleton)
					skeleton.NICE=True
					bone=Bone()
					skeleton.boneList.append(bone)
					bone.name=a
					bone.matrix=Matrix4x4(c)
					print 'use for scaling:'
					print bone.matrix
					for n in safe(g.i(1)[0]):
						getChildren(bone,4)
					skeleton.draw()	
		
		if unk==16:
			matCount=g.i(1)[0]	
			for m in safe(matCount):
				name0=g.word(g.i(1)[0])
				b=g.f(14)
				c=g.i(1)[0]
				for n in safe(c):
					name1=g.word(g.i(1)[0])
					name2=g.word(g.i(1)[0])
					d=g.f(4)
					name3=g.word(g.i(1)[0])
					name4=g.word(g.i(1)[0])
					name5=g.word(g.i(1)[0])	
		
		if unk==34:
			meshCount=g.i(1)[0]
			for k in safe(meshCount):
				stride=0
				B=[]
				vertexItemCount=g.i(1)[0]
				for m in safe(vertexItemCount):
					a=g.i(1)[0]
					b=g.word(g.i(1)[0])
					c=g.word(g.i(1)[0])
					B.append([c,stride])
					if b=='GL_FLOAT':
						stride+=a*4
					else:
						print 'unknow:',b
						break
				count=g.i(1)[0]	
				back1=g.tell()	
				vertCount=count*4/stride
				mesh=Mesh()
				meshList.append(mesh)
				mesh.SPLIT=True
				for b in B:
					g.seek(back1)
					if b[0]=='VERTEX_ATTRIB_POSITION':
						for m in safe(vertCount):
							t=g.tell()
							g.seek(t+b[1])
							mesh.vertPosList.append(g.f(3))
							g.seek(t+stride)
					if b[0]=='VERTEX_ATTRIB_TEX_COORD':
						for m in safe(vertCount):
							t=g.tell()
							g.seek(t+b[1])
							mesh.vertUVList.append(g.f(2))
							g.seek(t+stride)	
					if b[0]=='VERTEX_ATTRIB_BLEND_WEIGHT':
						for m in safe(vertCount):
							t=g.tell()
							g.seek(t+b[1])
							mesh.skinWeightList.append(g.f(4))
							g.seek(t+stride)	
					if b[0]=='VERTEX_ATTRIB_BLEND_INDEX':
						for m in safe(vertCount):
							t=g.tell()
							g.seek(t+b[1])
							C=g.f(4)
							mesh.skinIndiceList.append([int(C[0]),int(C[1]),int(C[2]),int(C[3])])
							g.seek(t+stride)
				g.seek(back1+count*4)
				subMeshCount=g.i(1)[0]
				for m in safe(vertCount):
					mesh.skinIDList.append([0]*subMeshCount)
				for m in safe(subMeshCount):
					skin=Skin()
					mesh.skinList.append(skin)
					mat=Mat()
					mat.TRIANGLE=True
					mesh.matList.append(mat)
					name=g.word(g.i(1)[0])
					mat.name=name	
					indiceCount=g.i(1)[0]	
					back1=g.tell()
					mat.IDStart=len(mesh.indiceList)
					mat.IDCount=indiceCount
					indiceList=g.H(indiceCount)
					mesh.indiceList.extend(indiceList)
					g.seek(back1+indiceCount*2)
					for indice in indiceList:
						mesh.skinIDList[indice][m]=1
					g.f(6)
		g.seek(back)
	
	meshList=meshList	
	for node in nodeList:
		for mesh in meshList:
			for i,mat in enumerate(mesh.matList):
				if node[2]==mat.name:
					mesh.boneNameList.extend(node[4])
					for boneName in node[4]:
						mesh.skinList[i].boneMap.append(mesh.boneNameList.index(boneName))
		
	for mesh in meshList:					
			mesh.draw()
	
		
	
def Parser(filename):
	print '='*70
	print filename
	print '='*70
	ext=filename.split('.')[-1].lower()	
	
	if ext=='c3b':
		if 'skin' in filename.lower():
			file=open(filename,'rb')
			g=BinaryReader(file)
			c3bParser(filename,g)
			file.close()
 
	
Blender.Window.FileSelector(Parser,'import','Avengers Academy files: *.c3b - model') 
	