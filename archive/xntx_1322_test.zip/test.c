#include <stdio.h>
#include <stdlib.h>

int Uncompress__No_Really(unsigned char *output, unsigned char *input)
{
  unsigned char *out;
  unsigned char *in;
  unsigned int v0;
  char v1;
  char v2;
  unsigned int i;
  int v3;
  int v4;
  int v5;
  unsigned char *v6;
  unsigned int k;
  unsigned char *v7;
  unsigned int v8;
  int v9;
  signed int v10;
  int v11;
  int v12;
  char v13;
  unsigned char *v14;
  unsigned char *v15;
  char v16;
  int j;
  char v17;
  int tmp;

  in = input;
  out = output;
  do
  {
LABEL_1:
    v8 = *in;
    v9 = *in++ & 7;
    v0 = v8 >> 3;
    j = v9 + 1;
    if ( (signed int)v0 < 30 )
      goto LABEL_2;
    if ( v0 == 30 )
    {
      v0 = *in++ + 30;
LABEL_2:
      if ( !v0 )
        continue;
      goto LABEL_3;
    }
    v0 += *in + (*(in + 1) << 8) + 255;
    in += 2;
    if ( v0 != 65821 )
      goto LABEL_2;
    --j;
LABEL_3:
    v1 = *in;
    tmp = *(in + 1);
    v17 = *(in + 2);
    v2 = *(in + 3);
    if ( (signed int)v0 >= 4 )
    {
      i = v0 >> 2;
      v0 += -4 * (v0 >> 2);
      do
      {
        *out = v1;
        *(out + 1) = tmp;
        in += 4;
        *(out + 2) = v17;
        *(out + 3) = v2;
        v1 = *in;
        tmp = *(in + 1);
        out += 4;
        --i;
        v17 = *(in + 2);
        v2 = *(in + 3);
      }
      while ( i );
    }
    if ( (signed int)v0 > 0 )
    {
      in += v0;
      *out++ = v1;
      if ( (signed int)v0 > 1 )
      {
        *out++ = tmp;
        if ( (signed int)v0 > 2 )
          *out++ = v17;
      }
    }
  }
  while ( !j );
  while ( 1 )
  {
    v10 = *in;
    --j;
    v4 = v10 & 7;
    ++in;
    v3 = v10 >> 3;
    if ( v4 )
      goto LABEL_4;
    v5 = *in++;
    if ( !v5 )
      return out - output;
    v4 = v5 + 7;
LABEL_4:
    if ( v3 >= 30 )
    {
      if ( v3 == 30 )
      {
        v3 = *in + 30;
      }
      else
      {
        v11 = *in + v3;
        v12 = *(in++ + 1);
        v3 = v11 + (v12 << 8) + 255;
      }
      ++in;
    }
    v6 = out - v3 - 1;
    if ( v4 >= 4 )
    {
      k = (unsigned int)v4 >> 2;
      v4 += -4 * ((unsigned int)v4 >> 2);
      do
      {
        *out = *v6;
        v13 = *(v6 + 1);
        v14 = out + 1;
        v15 = v6 + 1;
        *v14 = v13;
        v16 = *(v15 + 1);
        ++v14;
        ++v15;
        *v14++ = v16;
        *v14 = *(v15 + 1);
        out = v14 + 1;
        v6 = v15 + 2;
        --k;
      }
      while ( k );
    }
    if ( v4 > 0 )
    {
      *out++ = *v6;
      v7 = v6 + 1;
      if ( v4 > 1 )
      {
        *out++ = *v7;
        if ( v4 > 2 )
          *out++ = *(v7 + 1);
      }
    }
    if ( !j )
      goto LABEL_1;
  }
}



int main(int argc, char *argv[]) {
    FILE    *fd;
    int     len;
    unsigned char   *input,
                    *output,
                    *fin,
                    *fout;

    if(argc < 3) {
        printf("\nUsage: %s <input> <output>\n", argv[0]);
        exit(1);
    }
    fin = argv[1];
    fout = argv[2];

    fd = fopen(fin, "rb");
    if(!fd) exit(1);
    fseek(fd, 0, SEEK_END);
    len = ftell(fd);
    fseek(fd, 0, SEEK_SET);

    input = malloc(len);
    output = malloc(len * 10);  // 10 enough?

    fread(input, 1, len, fd);
    fclose(fd);

    printf("- unpacking %d bytes\n", len);
    len = Uncompress__No_Really(output, input);

    fd = fopen(fout, "wb");
    if(!fd) exit(1);
    fwrite(output, 1, len, fd);
    fclose(fd);

    printf("- unpacked %d bytes\n", len);
    return(0);
}

