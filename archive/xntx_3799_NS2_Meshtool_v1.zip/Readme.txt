===========================================
===========================================
NATURAL SELECTION 2 MESHTOOL
===========================================
===========================================

===========================
Library/Author Information:
===========================

Title:
Natural Selection 2 Meshtool

Base Release Date:
20/05/2014

Author:
Cra0kalo/Chrrox

Build:
1.0 Public Release

Email:
me@cra0kalo.com (Cihan/Cra0kalo)

Website:
http://dev.cra0kalo.com


===========================
Usage:
===========================

Usage: meshtool -f={format} -m path/to/model/file.model path/to/outputfolder
Options: --v (Verbose Mode)
Export Formats: f=obj f=smd

Example: meshtool --v -f=obj -m O:/RamBox/modelsrc/alien/crag.model O:/RamBox/modelsrc/alien/output
Example's output crag.obj will be created in path  {O:/RamBox/modelsrc/alien/output/}

