import newGameLib
from newGameLib import *

#dragon age 2
DRAGONAGE=0

class Node:
	def __init__(self):
		self.offset=None
		self.childList=[]
		self.chunk=None
		self.type=None
		self.index=None
		self.label=None
		self.value=None
	
	
class Section:
	def __init__(self):
		self.name=None
		self.itemCount=None
		self.offset=None
		self.size=None
		self.itemList=[]
		self.childrenList=[]
	
def getSection(sectionName):
	value=None
	for section in sectionList:
		if section.name==sectionName:
			value=section
			break
	return value		
	
	
		
def parser(parentNode,seek,chunk,n,g):
	n+=4	
	section=getSection(chunk)	
	parentNode.chunk=chunk
	for item in section.itemList:		
		node=Node()
		node.index=item[0]
		node.type=item[1]
		node.off=item[2]
		node.seek=seek
		node.offset=offset		
		parentNode.childList.append(node)
		
		node.chunk=chunk
		node.value=getValue(node,g)
		#print node.index,node.type,node.chunk
		if node.type==-1610547201:
			node.chunk='twig'
			g.seek(seek+offset+node.off)
			g.seek(offset+g.i(1)[0])
			nChildren=g.i(1)[0]
			for m in range(nChildren):
				childType=g.i(1)[0]
				childOff=g.i(1)[0]
				childNode=Node()
				childNode.type=childType
				node.childList.append(childNode)
				t=g.tell()
				#print childType
				if DRAGONAGE==0:
					if childType==1073741859:#dragon age
						childNode.chunk='node'
						parser(childNode,childOff,'node',n,g)
					
					if childType==1073741832:#dragon age
						childNode.chunk='trsl'
						parser(childNode,childOff,'trsl',n,g)
						
					if childType==1073741831:#dragon age
						childNode.chunk='rota'
						parser(childNode,childOff,'rota',n,g)
					
					if childType==1073741860:#mshh
						childNode.chunk='mshh'
						parser(childNode,childOff,'mshh',n,g)
						
				else:		
					
					if childType==1073741825:#dragon age 2
						childNode.chunk='node'
						parser(childNode,childOff,'node',n,g)
						
					if childType==1073741828:#dragon age 2
						childNode.chunk='trsl'
						parser(childNode,childOff,'trsl',n,g)
						
					if childType==1073741829:#dragon age 2
						childNode.chunk='rota'
						parser(childNode,childOff,'rota',n,g)
						
					if childType==1073741831:#dragon age 2
						childNode.chunk='mshh'
						parser(childNode,childOff,'mshh',n,g)
				
					
				g.seek(t)		
		if node.type==-536870908:#chn 
			g.seek(seek+offset+node.off)
			g.seek(offset+g.i(1)[0])
			nChildren=g.i(1)[0]
			for k in range(nChildren):
				childOff=g.i(1)[0]
				childNode=Node()
				node.childList.append(childNode)
				t=g.tell()
				parser(childNode,childOff,'chnk',n,g)
				g.seek(t)
				
		if node.type==-536870909:#chn 
			g.seek(seek+offset+node.off)
			g.seek(offset+g.i(1)[0])
			nChildren=g.i(1)[0]
			for k in range(nChildren):
				childOff=g.i(1)[0]
				childNode=Node()
				node.childList.append(childNode)
				t=g.tell()
				parser(childNode,childOff,'chnk',n,g)
				g.seek(t)
				
				
		if node.type == -1073741823:
			g.seek(seek+offset+node.off)
			g.seek(offset+g.i(1)[0])
			nChildren=g.i(1)[0]
			for k in range(nChildren):
				childNode=Node()
				node.childList.append(childNode)
				decl(childNode,'decl',n,g)
				
		if node.type == -2147483644:
			g.seek(seek+offset+node.off)
			g.seek(offset+g.i(1)[0])
			nChildren=g.i(1)[0]
			for k in range(nChildren):
				childNode=Node()
				node.childList.append(childNode)
				childNode.chunk='bone id'
				childNode.value=g.i(1)[0]
		
		
		
def decl(parentNode,chunk,n,g):
	n+=4	
	section=getSection(chunk)
	t=g.tell()	
	for item in section.itemList:		
		node=Node()
		node.index=item[0]
		node.type=item[1]
		node.off=item[2]
		parentNode.childList.append(node)
		node.seek=t
		node.offset=0
		node.value=getValue(node,g)
			
def getTwig(parent,n):
	n+=4
	for child in parent.childList:
		#print ' '*n,child.index,child.chunk,child.type
		#if child.chunk=='twig':
		txt.write(' '*n+str(child.index)+' '+str(child.chunk)+' '+str(child.type))
		txt.write(' value:'+str(child.value)+'\n')
		getTwig(child,n)
	
def getIndexTwig(node,index,list):	
	for child in node.childList:
		if child.index==index:
			list.append(child)
		getIndexTwig(child,index,list)	
	
def getIndex(node,index):
	list=[]
	getIndexTwig(node,index,list)
	return list
	
def getValue(node,g):
	#back=g.tell()
	value=None
	if node.type==14:
		g.seek(node.seek+node.offset+node.off)
		g.seek(node.offset+g.i(1)[0])
		value=g.word(g.i(1)[0]*2)
	elif node.type==4:
		g.seek(node.seek+node.offset+node.off)
		value=g.i(1)[0]
	elif node.type==5:
		g.seek(node.seek+node.offset+node.off)
		value=g.i(1)[0]
	elif node.type==12:
		g.seek(node.seek+node.offset+node.off)
		if node.chunk=='trsl':
			value=g.f(4)
	elif node.type==13:
		g.seek(node.seek+node.offset+node.off)
		if node.chunk=='rota':
			value=g.f(4)
	return value	


def getNodeTwig(meshList,node,parent):


	for child in node.childList:
		#print ' '*4,child.index,child.chunk
		if child.index==6000:
			if parent is not None:
				parent.name=child.value
				
		if child.index==6254:
			if parent is not None:
				parent.index=child.value
		
		if child.index==6999:			
			for m in range(len(child.childList)):
				child1=child.childList[m]
				#print child1.chunk
				if child1.chunk=='node':
					bone=Bone()
					if parent is not None:
						bone.parentName=parent.name
					skeleton.boneList.append(bone)
					getNodeTwig(meshList,child1,bone)
					
				if child1.chunk=='trsl':
					index6047List=getIndex(child1,6047)
					if len(index6047List)==1:
						#print index6047List[0].value
						parent.posMatrix=VectorMatrix(index6047List[0].value)
						#print parent.posMatrix

						
				if child1.chunk=='rota':
					index6048List=getIndex(child1,6048)
					if len(index6048List)==1:
						parent.rotMatrix=QuatMatrix(index6048List[0].value).resize4x4()
						#print parent.rotMatrix
						
				if child1.chunk=='mshh':
					meshName=None
					for child2 in child1.childList:
						if child2.index==6006:
							meshName=child2.value
					index6255List=getIndex(child1,6255)
					if len(index6255List)==1:
						if meshName is not None:
							for mesh in meshList:
								if mesh.name==meshName:
									for child2 in index6255List[0].childList:
										boneIndex=child2.value
										for i,bone in enumerate(skeleton.boneList):
											if bone.index==boneIndex:
												mesh.skinList[0].boneMap.append(i)
					
	
	
def mmhParser(filename,g):
	global offset,txt,sectionList,skeleton#,meshList
	
	skeleton=Skeleton()
	skeleton.BONESPACE=True
	skeleton.NICE=True
	
	name=g.word(20)
	sectionCount=g.i(1)[0]
	offset=g.i(1)[0]	
	nodeList=[]
	sectionList=[]
	txt=open('tree.txt','w')
	
	
	for m in range(sectionCount):
		section=Section()
		sectionList.append(section)
		section.name=g.word(4)
		section.itemCount=g.i(1)[0]
		section.offset=g.i(1)[0]
		section.size=g.i(1)[0]
		
	for section in sectionList:
		g.seek(section.offset)
		#print section.name
		for m in range(section.itemCount):
			A=g.i(3)
			section.itemList.append(A)
	
			
	n=0	 
	seek=0
	root=Node()
	root.chunk='mdlh'
	parser(root,seek,'mdlh',n,g)
	n=0	
	getTwig(root,n)
	txt.close()
	
	meshList=[]
	
	mshFile=None
	for child in root.childList:
		if child.index==6005:
			mshFile=child.value
	
	if mshFile is not None:	
		mshPath=filename.lower().split('art')[0]+os.sep+mshFile
		if os.path.exists(mshPath)==False:
			mshPath=os.path.dirname(filename)+os.sep+os.path.basename(mshFile)
			
	
		if os.path.exists(mshPath)==True:
			file=open(mshPath,'rb')
			p=BinaryReader(file)
			meshList=mshParser(mshPath,p)
			file.close()
			
	
	
	getNodeTwig(meshList,root,None)
	
	
	
	skeleton.draw()
	
	for mesh in meshList:
		mesh.boneNameList=skeleton.boneNameList
		mesh.BINDSKELETON=skeleton.name
		mesh.draw()
	
	
	mmhPath=None
	for child in root.childList:
		if child.index==6000:
			mmhPath=child.value
	return mmhPath
			
			
def mshParser(filename,g):
	global offset,txt,sectionList
	name=g.word(20)
	sectionCount=g.i(1)[0]
	offset=g.i(1)[0]	
	nodeList=[]
	sectionList=[]
	txt=open('tree.txt','w')
	
	
	for m in range(sectionCount):
		section=Section()
		sectionList.append(section)
		section.name=g.word(4)
		section.itemCount=g.i(1)[0]
		section.offset=g.i(1)[0]
		section.size=g.i(1)[0]
		
	for section in sectionList:
		g.seek(section.offset)
		print section.name
		for m in range(section.itemCount):
			A=g.i(3)
			section.itemList.append(A)
	
			
	n=0	 
	seek=0
	root=Node()
	root.chunk='mesh'
	parser(root,seek,'mesh',n,g)
	n=0	
	getTwig(root,n)
	txt.close()
	
	vertexStreamOffset=None
	indexStreamOffset=None
	vertexCount=None
	vertexStride=None
	indexCount=None
	indexStart=None
	
	
	index8022List=getIndex(root,8022)
	if len(index8022List)==1:
		index8022=index8022List[0]
		g.seek(index8022.seek+index8022.offset+index8022.off)
		g.seek(index8022.offset+g.i(1)[0])
		vertexStreamOffset=g.tell()
		
	index8023List=getIndex(root,8023)
	if len(index8023List)==1:
		index8023=index8023List[0]
		g.seek(index8023.seek+index8023.offset+index8023.off)
		g.seek(index8023.offset+g.i(1)[0])
		indexStreamOffset=g.tell()
		
				
				
		
		
		
	meshList=[]	
	
	index8021List=getIndex(root,8021)
	for index8021 in index8021List:
		for child in index8021.childList:
		
		
		
			vertOff=None
			vertDataType=None
			uvOff=None
			uvDataType=None
			skinIndiceOff=None
			skinIndiceDataType=None
			skinWeightOff=None
			skinWeightDataType=None
				
				
			index8025List=getIndex(child,8025)	
			if len(index8025List)==1:
				index8025=index8025List[0]
				for childA in index8025.childList:
					usage=None
					dataType=None
					offset=None
				
					index8029List=getIndex(childA,8029)
					if len(index8029List)==1:
						index8029=index8029List[0]
						usage=index8029.value
						
					index8028List=getIndex(childA,8028)
					if len(index8028List)==1:
						index8028=index8028List[0]
						dataType=index8028.value
						
					index8027List=getIndex(childA,8027)
					if len(index8027List)==1:
						index8027=index8027List[0]
						offset=index8027.value
						
					if usage==0 and dataType==2 and offset is not None:
						vertOff=offset
						vertDataType=dataType
						
					if usage==0 and dataType==16 and offset is not None:
						vertOff=offset
						vertDataType=dataType
						
					if usage==5 and dataType==15 and offset is not None:
						uvOff=offset
						print '='*10,uvOff
						uvDataType=dataType
						
					if usage==5 and dataType==16 and offset is not None:
						uvOff=offset
						print '='*10,uvOff
						uvDataType=dataType
						
					if usage==2 and dataType==5 and offset is not None:
						skinIndiceOff=offset
						print '='*10,skinIndiceOff
						skinIndiceDataType=dataType
						
					if usage==1 and dataType==8 and offset is not None:
						skinWeightOff=offset
						print '='*10,skinWeightOff
						skinWeightDataType=dataType
						
				
					
		
		
		
			mesh=Mesh()
			meshList.append(mesh)
			print 'mesh'
			index2List=getIndex(child,2)
			for index2 in index2List:
				name=index2.value
				mesh.name=name
				print mesh.name
				
			index8000List=getIndex(child,8000)
			for index8000 in index8000List:
				vertexStride=index8000.value
				print vertexStride
				
			index8001List=getIndex(child,8001)
			for index8001 in index8001List:
				vertexCount=index8001.value
				print vertexCount
				
			index8002List=getIndex(child,8002)
			for index8002 in index8002List:
				indexCount=index8002.value
				print indexCount
				
			index8009List=getIndex(child,8009)
			for index8009 in index8009List:
				indexStart=index8009.value
				print indexStart
				
			index8006List=getIndex(child,8006)
			for index8006 in index8006List:
				vertexOffset=index8006.value
				print vertexOffset
				if vertexStreamOffset is not None:
					g.seek(vertexStreamOffset+vertexOffset+4)
					print 'vertexstream:',g.tell()
					#g.debug=True
					if vertexCount is not None and vertexStride is not None:
						for m in range(vertexCount):
							t=g.tell()
							
							if vertOff is not None and vertDataType==2:
								g.seek(t+vertOff)
								mesh.vertPosList.append(g.f(3))
								#print g.B(20)
								
							if vertOff is not None and vertDataType==16:
								g.seek(t+vertOff)
								mesh.vertPosList.append(g.half(3))
								
							if uvOff is not None and uvDataType==15:
								g.seek(t+uvOff)
								mesh.vertUVList.append(g.half(2))
								
							if uvOff is not None and uvDataType==16:
								g.seek(t+uvOff)
								mesh.vertUVList.append(g.half(2))
								
							if skinIndiceOff is not None and skinIndiceDataType==5:
								g.seek(t+skinIndiceOff)
								mesh.skinIndiceList.append(g.B(4))
								
							if skinWeightOff is not None and skinWeightDataType==8:
								g.seek(t+skinWeightOff)
								mesh.skinWeightList.append(g.B(4))
								
							g.seek(t+vertexStride)
							
			g.seek(indexStreamOffset+indexStart*2+4)
			mesh.indiceList=g.H(indexCount)	
			mesh.TRIANGLE=True	
			skin=Skin()
			mesh.skinList.append(skin)	
			#mesh.draw()			
					
		
		
	mshPath=None
	for child in root.childList:
		if child.index==2:
			mshPath=child.value
	return meshList
			
			
	
		
def Parser(filename):
	print
	print filename
	print
	#global g
	ext=filename.split('.')[-1].lower()
	if ext=='mmh':
		file=open(filename,'rb')
		g=BinaryReader(file)
		mmhParser(filename,g)
		file.close()
	elif ext=='msh':
		file=open(filename,'rb')
		g=BinaryReader(file)
		meshList=mshParser(filename,g)		
		file.close()
		for mesh in meshList:
			mesh.draw()
	Redraw()
	
	

def Parser1(filename):
	print
	print filename
	print
	global g
	ext=filename.split('.')[-1].lower()
	
	for file in os.listdir(os.path.dirname(filename)):
		filePath=os.path.dirname(filename)+os.sep+file
		ext=filePath.split('.')[-1].lower()
		print filePath
		
		if ext=='mmh':
			file=open(filePath,'rb')
			g=BinaryReader(file)
			path=mmhParser()			 
			file.close()
			if path is not None:
				path=os.path.dirname(filename)+os.sep+path
				if os.path.exists(os.path.dirname(path))==False:
					os.makedirs(os.path.dirname(path))
				os.rename(filePath,path)
				
		if ext=='msh':
			file=open(filePath,'rb')
			g=BinaryReader(file)
			path=mshParser()			 
			file.close()
			if path is not None:
				path=os.path.dirname(filename)+os.sep+path
				if os.path.exists(os.path.dirname(path))==False:
					os.makedirs(os.path.dirname(path))
				try:os.rename(filePath,path)
				except:pass
	Redraw()	


	
Blender.Window.FileSelector(Parser,'import','Dragon Age files: *.msh - mesh, *.mmh - skeleton') 
	