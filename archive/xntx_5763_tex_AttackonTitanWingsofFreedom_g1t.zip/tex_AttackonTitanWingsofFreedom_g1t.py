from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Attack on Titan Wings of Freedom", ".g1t")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    Magic = bs.readBytes(4).decode("ASCII")
    if Magic != 'GT1G':
        return 0
    return 1
	
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.seek(0x8, NOESEEK_ABS)
    filesize = bs.readInt()
    tableOffset = bs.readInt()
    print(hex(tableOffset), "table offset")
    numTexs = bs.readInt() #0x10
    print(numTexs, "numTexs")
    bs.seek(tableOffset, NOESEEK_ABS)
    for i in range(numTexs):
        texOffset = bs.readInt()
        TMP = bs.tell()
        print(hex(texOffset + tableOffset), "start")
        bs.seek(texOffset + tableOffset, NOESEEK_ABS)
        texName = rapi.getExtensionlessName(rapi.getInputName()) + "_" + str(i)
        print(hex(bs.tell()), "we're here")
        unk = bs.readByte()
        imgFmt = bs.readUByte()             
        texSize = bs.readUByte()
        print(hex(texSize), "texSize")
        width = texSize & 0x0F
        height = (texSize & 0xF0) // 16
        #print(hex(width), "width")
        #print(hex(height), "height")
        imgWidth = 2 ** width
        imgHeight = 2 ** height
        print(imgWidth, "x", imgHeight, ":", hex(imgFmt), "imgFmt")
        if imgWidth <= 4 or imgHeight <= 4:
            bs.seek(0x5, NOESEEK_REL)
        else:
            bs.seek(0x11, NOESEEK_REL)
        print(hex(bs.tell()), "start2")
        #DXT1
        if imgFmt == 0x59: #6:
            datasize = ((imgWidth * imgHeight) * 4) // 8
        #DXT5
        elif imgFmt == 0x5b: #8:
            datasize = ((imgWidth * imgHeight) * 8) // 8
        #ATI1
        elif imgFmt == 0x5c:
            datasize = ((imgWidth * imgHeight) * 16) // 8
        #ATI2?
        elif imgFmt == 0x5f:
            datasize = ((imgWidth * imgHeight) * 8) // 8
        #ARGB32
        elif imgFmt == 1:
            datasize = ((imgWidth * imgHeight) * 32) // 8
        print(hex(datasize), "datasize")
        data = bs.readBytes(datasize)      
        print(hex(bs.tell()), "at end")
        #DXT1
        if imgFmt == 0x59: #6:
            texFmt = noesis.NOESISTEX_DXT1
        #DXT5
        elif imgFmt == 0x5b: #8:
            texFmt = noesis.NOESISTEX_DXT5
        #ATI1
        elif imgFmt == 0x5c:
            data = rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_ATI1) #ATI1 ATI2 DX10
            texFmt = noesis.NOESISTEX_RGBA32
        #ATI2?
        elif imgFmt == 0x5f:
            data = rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_ATI2) #ATI1 ATI2 DX10
            texFmt = noesis.NOESISTEX_RGBA32
        #ARGB32
        elif imgFmt == 1:
            data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "a8 r8 g8 b8")
            texFmt = noesis.NOESISTEX_RGBA32
        if imgWidth > 4 and imgHeight > 4:
            texList.append(NoeTexture(texName, imgWidth, imgHeight, data, texFmt))
        bs.seek(TMP, NOESEEK_ABS)
    return 1