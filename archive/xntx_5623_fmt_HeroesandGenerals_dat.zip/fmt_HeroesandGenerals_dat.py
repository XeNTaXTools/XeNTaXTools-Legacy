from inc_noesis import *
import noesis
import rapi
import os

def registerNoesisTypes():
    handle = noesis.register("Heroes and Generals", ".dat")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    return 1   

def noepyLoadModel(data, mdlList):
    ctx = rapi.rpgCreateContext()
    bs = NoeBitStream(data)
    bs.seek(len(data) - 0x80, NOESEEK_ABS)
    TMP = bs.tell()
    print(hex(bs.tell()), "here1")
    string = bs.readBytes(0x80) #set range of bytes to search
    index = string.find(b"\x02\x00") #search for 0x02 0x00
    print(hex(bs.tell()), index, "index")
    bs.seek(TMP + index - 2, NOESEEK_ABS)        
    print(hex(bs.tell()), "here3")
    checkVBytes = bs.readInt()
    print(hex(checkVBytes), hex(bs.tell()), "here4")
    if checkVBytes == 0x20018:
        VBytes = 24
    elif checkVBytes == 0x20014:
        VBytes = 20
    elif checkVBytes == 0x20028:
        VBytes = 40
    bs.seek(0x16, NOESEEK_ABS)
    print(hex(bs.tell()), "here5")
    print(VBytes, "vbytes")
    check = 0
    end = len(data)
    meshName = 0
    while check != end:
        meshName += 1
        rapi.rpgSetName(str(meshName))
        VCount = bs.readInt() // VBytes
        print(hex(VCount), hex(bs.tell()), "vcount")
        FCount = bs.readInt() // 2
        print(hex(FCount), hex(bs.tell()), "fcount")
        VBuf = bs.readBytes(VCount * VBytes)
        IBuf = bs.readBytes(FCount * 2) 
        if VBytes == 20:
            rapi.rpgBindPositionBufferOfs(VBuf, noesis.RPGEODATA_HALFFLOAT, VBytes, 0)   #position of vertices
            rapi.rpgBindUV1BufferOfs(VBuf, noesis.RPGEODATA_HALFFLOAT, VBytes, 16)   #UVs    
        else:
            rapi.rpgBindPositionBufferOfs(VBuf, noesis.RPGEODATA_FLOAT, VBytes, 0)   #position of vertices
            rapi.rpgBindUV1BufferOfs(VBuf, noesis.RPGEODATA_HALFFLOAT, VBytes, 20)   #UVs    
        rapi.rpgCommitTriangles(IBuf, noesis.RPGEODATA_USHORT, FCount, noesis.RPGEO_TRIANGLE, 1) #SHORT for word indices
        TMP2 = bs.tell()
        bs.seek(0x3a, NOESEEK_REL)
        checkint = bs.readInt()
        if checkint == 0:
            bs.seek(TMP2, NOESEEK_ABS)
            skip = bs.readBytes(0x3e)
        check = bs.tell()
        if check + 200 > end:
            check = end
    mdl = rapi.rpgConstructModel()                                                          
    mdlList.append(mdl)
    rapi.rpgClearBufferBinds()
    return 1