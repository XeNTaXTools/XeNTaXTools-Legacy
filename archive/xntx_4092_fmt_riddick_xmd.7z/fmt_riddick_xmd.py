from inc_noesis import *

import noesis
#rapi methods should only be used during handler callbacks
import rapi
import struct

#registerNoesisTypes is called by Noesis to allow the script to register formats.
#Do not implement this function in script files unless you want them to be dedicated format modules!
def registerNoesisTypes():
	handle = noesis.register("Riddick", ".xmd")
	noesis.setHandlerTypeCheck(handle, xmdCheckType)
	noesis.setHandlerLoadModel(handle, xmdLoadModel) #see also noepyLoadModelRPG
	noesis.logPopup()
	return 1

#check if it's this type based on the data

def xmdCheckType(data):
	bs = NoeBitStream(data)
	idMagic = bs.readString()
	if idMagic != "MOS DATAFILE2.0":
		return 0
	return 1       

#load the model
def xmdLoadModel(data, mdlList):
	ctx = rapi.rpgCreateContext()
	bs = NoeBitStream(data)
	rapi.rpgSetOption(noesis.RPGOPT_TRIWINDBACKWARD, 1)
	rapi.setPreviewOption("setAngOfs", "0 180 0")
	SURFACES = []
	BOUNDPOS = []
	bs.seek(0x20, NOESEEK_ABS)
	tblEnd = bs.readInt()
	bs.seek(0x30, NOESEEK_ABS)
	while bs.tell() < tblEnd:
		sectionName = bs.readBytes(24).decode("ASCII").rstrip("\0")
		unk01 = bs.readInt()
		unk02 = bs.readInt()
		sectionOffset = bs.readInt()
		sectionSize = bs.readInt()
		sectionCount = bs.readInt()
		unk06 = bs.readInt()
		if sectionName == "SURFACES":
			SURFACES.append([sectionOffset,sectionSize,sectionCount])
		elif sectionName == "BOUND":
			BOUNDPOS.append(bs.tell() - 0x30)
	BOUNDPOS.append(bs.tell())
	for i in range(0, (len(BOUNDPOS) - 1)):
		BOUND = []
		CLUSTERS = []
		VERTEXFRAMES = []
		TVERTEXFRAMES = []
		TRIANGLES = []
		MODELINFO = []

		bs.seek(BOUNDPOS[i], NOESEEK_ABS)
		while bs.tell() < BOUNDPOS[(i + 1)]:
			sectionName = bs.readBytes(24).decode("ASCII").rstrip("\0")
			unk01 = bs.readInt()
			unk02 = bs.readInt()
			sectionOffset = bs.readInt()
			sectionSize = bs.readInt()
			sectionCount = bs.readInt()
			MeshCount = bs.readInt()
			if sectionName == "BOUND":
				BOUND.append([sectionOffset,sectionSize,sectionCount])
			elif sectionName == "CLUSTERS":
				CLUSTERS.append([sectionOffset,sectionSize,sectionCount,MeshCount])
			elif sectionName == "VERTEXFRAMES":
				VERTEXFRAMES.append([sectionOffset,sectionSize,sectionCount])
			elif sectionName == "TVERTEXFRAMES":
				TVERTEXFRAMES.append([sectionOffset,sectionSize,sectionCount])
			elif sectionName == "TRIANGLES":
				TRIANGLES.append([sectionOffset,sectionSize,sectionCount]) 			
		bs.seek(BOUND[0][0], NOESEEK_ABS)
		globalBB = bs.read("f"*7)
		scaleX = globalBB[3] - globalBB[0]
		scaleY = globalBB[4] - globalBB[1]
		scaleZ = globalBB[5] - globalBB[2]
		rapi.rpgSetPosScaleBias(NoeVec3 ((scaleX, scaleY, scaleZ)), NoeVec3 ((1.0, 1.0, 1.0)))
		bs.seek(CLUSTERS[0][0], NOESEEK_ABS)
		myPos = -1
		for a in range(0, CLUSTERS[0][2]):
			matID = bs.readInt()
			faceStart = bs.readInt()
			faceCount = bs.readInt()
			vertStart = bs.readInt()
			vertCount = bs.readInt()
			bs.seek(0x10, NOESEEK_REL)
			CheckTest = bs.readInt()
			if CheckTest < 0:
			        bs.seek(0x0, NOESEEK_REL)
			        boneTest = -2
			else:
			        bs.seek(0x4, NOESEEK_REL)
			        boneTest = bs.readInt()
			localBB = bs.read("f"*6)
			null = bs.readInt()
			if boneTest < 0:
		                boneIdCount = bs.readInt()
		                boneMap = bs.read("H"*boneIdCount)
			else:
				boneMap = []
			if faceStart == 0:
				myPos += 1
			MODELINFO.append([matID,faceStart,faceCount,vertStart,vertCount,myPos])
		print(MODELINFO)
		for a in range(0, len(MODELINFO)):
			meshName = str(i) + "_" + str(a)
			matName = str(i) + "_ mat _" + str(a)
			rapi.rpgSetName(meshName)
			vertBase = VERTEXFRAMES[(MODELINFO[a][5])][0] + 0x34
			uvBase = TVERTEXFRAMES[(MODELINFO[a][5])][0] + 20
			faceBase = TRIANGLES[(MODELINFO[a][5])][0] + 4
			print([vertBase,uvBase,faceBase])

			bs.seek(vertBase + (6 * MODELINFO[a][3]), NOESEEK_ABS)
			vertData = bs.readBytes(6 * MODELINFO[a][4])
			rapi.rpgBindPositionBuffer(vertData, noesis.RPGEODATA_USHORT, 6)
			bs.seek(uvBase + (4 * MODELINFO[a][3]), NOESEEK_ABS)
			uvData = bs.readBytes(4 * MODELINFO[a][4])
			rapi.rpgBindUV1Buffer(uvData, noesis.RPGEODATA_USHORT, 4)
			faceData = []
			if MODELINFO[a][2] == 0:
				rapi.rpgCommitTriangles(None, noesis.RPGEODATA_USHORT, MODELINFO[a][4], noesis.RPGEO_POINTS, 1)
			else:
				bs.seek(faceBase + (2 * MODELINFO[a][1]), NOESEEK_ABS)
				for c in range(0, MODELINFO[a][2]):
					face = bs.readUShort()
					faceData.append(face - MODELINFO[a][3])
				FaceBuff = struct.pack('H'*len(faceData), *faceData)
				#faceData = bs.readBytes(2 * MODELINFO[b][2])
				rapi.rpgCommitTriangles(FaceBuff, noesis.RPGEODATA_USHORT, MODELINFO[a][2], noesis.RPGEO_TRIANGLE, 1)

	mdl = rapi.rpgConstructModel()
	mdlList.append(mdl)         


	rapi.rpgClearBufferBinds()	
	return 1