import newGameLib
reload(newGameLib)
from newGameLib import *
import Blender
	
import math
from math import *


	
def primitivesParser(filename,g):
	#g.debug=True
	g.seek(-4,2)
	pos=g.tell()
	offset=g.i(1)[0]+4
	g.seek(-offset,2)
	offset=4
	while(True):
		a,b,c,d,e=g.i(5)
		streamName=g.word(g.i(1)[0]).strip()
		print 'offset:',offset,streamName
		streamList[streamName]=offset
		g.seekpad(4)
		t=g.tell()
		g.seek(offset+a)
		g.seekpad(4)
		offset=g.tell()
		g.seek(t)
		if g.tell()==pos:break
	g.tell()
	
	
def getStream(mesh,g):	
	print 'getStream'
	t=g.tell()
	chunk=g.find('\x00')
	if chunk =='xyznuviiiww':
		g.seek(t+64)
		count=g.i(1)[0]					
		for m in range(count):
			t=g.tell()
			mesh.vertPosList.append(g.f(3))
			g.seek(t+16)
			mesh.vertUVList.append(g.f(2))
			i1=g.B(1)[0]/3
			i2=g.B(1)[0]/3
			i3=g.B(1)[0]/3
			mesh.skinIndiceList.append([i1,i2])
			w1,w2=g.B(2)
			w3=255-(w1+w2)
			#print i1,i2,i3,w1,w2,w3
			mesh.skinWeightList.append([w1,w2])
			g.seek(t+29)
		g.seekpad(4)	
		
		
	elif chunk =='xyznuvtb':
		g.seek(t+64)
		count=g.i(1)[0]					
		for m in range(count):
			t=g.tell()
			mesh.vertPosList.append(g.f(3))
			g.seek(t+16)
			mesh.vertUVList.append(g.f(2))
			g.seek(t+32)
		g.seekpad(4)	
		
		
	elif chunk =='xyznuviiiwwtb':
		g.seek(t+64)
		count=g.i(1)[0]					
		for m in range(count):
			t=g.tell()
			mesh.vertPosList.append(g.f(3))
			g.seek(t+16)
			mesh.vertUVList.append(g.f(2))
			i1=g.B(1)[0]/3
			i2=g.B(1)[0]/3
			i3=g.B(1)[0]/3
			mesh.skinIndiceList.append([i1,i2])
			w1,w2=g.B(2)
			w3=255-(w1+w2)
			mesh.skinWeightList.append([w1,w2])
			g.seek(t+37)
		g.seekpad(4)	
		
	elif chunk=='list':
		g.seek(t+64)
		a,b=g.i(2)				
		mesh.indiceList=g.H(a)	
		for m in range(b):
			print m,g.i(4)
		g.seekpad(4)
	else:
		print 'WARNING:unknow chunk:',chunk
	
			
def getChildren(parent,xml,parentName):
	bone=Bone()
	if parentName is not None:bone.parentName=parentName
	identifier=xml.get(parent,'identifier').values.strip()
	if 'BlendBone' not in identifier:
		bone.name=identifier
		transform=xml.get(parent,'transform')
		row0=map(float,xml.get(transform,'row0').values.strip().split())
		row1=map(float,xml.get(transform,'row1').values.strip().split())
		row2=map(float,xml.get(transform,'row2').values.strip().split())
		row3=map(float,xml.get(transform,'row3').values.strip().split())
		rotMatrix=Matrix(row0,row1,row2).resize4x4()
		posMatrix=VectorMatrix(row3)
		bone.matrix=rotMatrix*posMatrix
		skeleton.boneList.append(bone)
		for node in xml.find(parent,'node'):getChildren(node,xml,bone.name)

			
			
def Parser():
	global streamList,skeleton	
	filename=input.filename
	print
	print filename
	print 
	ext=filename.split('.')[-1].lower()	
	
	
	if ext=='visual':
	
		skeleton=Skeleton()
		
		
		streamList={}
		primitivesPath=filename.lower().replace('.visual','.primitives')
		if os.path.exists(primitivesPath)==True:
			file=open(primitivesPath,'rb')
			g=BinaryReader(file)
			primitivesParser(primitivesPath,g)
			file.close()		
			
		print streamList.keys()	
	
		file=open(filename,'r')
		xml=Xml()
		#xml.DRAWCONSOLE=True
		xml.input=file
		xml.parse()
		renderSetList=xml.find(xml.root,'renderSet')
		print xml.root.children
		print renderSetList
		node=xml.get(xml.root,'node')
		getChildren(node,xml,None)
		
		skeleton.SORT=True
		skeleton.NICE=True
		#skeleton.BONESPACE=True
		skeleton.ARMATURESPACE=True
		skeleton.draw()
		
		for renderSet in renderSetList:
			print 'mesh'
			geometry=xml.get(renderSet,'geometry')
			mesh=Mesh()
			mesh.TRIANGLE=True
			vertices=xml.get(geometry,'vertices')
			streamName=vertices.values.strip()
			if streamName in streamList.keys():			
				primitivesPath=filename.lower().replace('.visual','.primitives')
				if os.path.exists(primitivesPath)==True:
					file=open(primitivesPath,'rb')
					g=BinaryReader(file)
					g.seek(streamList[streamName])
					getStream(mesh,g)
					file.close()
			
			primitive=xml.get(geometry,'primitive')
			streamName=primitive.values.strip()
			#print streamName
			if streamName in streamList.keys():			
				primitivesPath=filename.lower().replace('.visual','.primitives')
				if os.path.exists(primitivesPath)==True:
					file=open(primitivesPath,'rb')
					g=BinaryReader(file)
					g.seek(streamList[streamName])
					getStream(mesh,g)
					file.close()
			texture=xml.get(geometry,'Texture')
			mat=Mat()
			mat.TRIANGLE=True
			mat.ZTRANS=True
			texDir=filename.split('characters')[0]
			if texture is not None:
				mat.diffuse=texDir+texture.values.strip()
				if os.path.exists(mat.diffuse)==False:
					mat.diffuse=texDir+texture.values.strip().replace('.tga','.dds')
				print texture.values
			mesh.matList.append(mat)	
			
			nodeList=xml.find(renderSet,'node')
			for node in nodeList:
				mesh.boneNameList.append(node.values.strip().split('BlendBone')[0][-25:])
				#print node.values.strip().split('BlendBone')[0][-25:]
			skin=Skin()
			mesh.skinList.append(skin)
			
			mesh.BINDSKELETON='armature'
			mesh.draw()
			
			
			
	
	
	if ext=='primitives':
		streamList={}
		file=open(filename,'rb')
		g=BinaryReader(file)
		g.logOpen()
		primitivesParser(filename,g)
		g.logClose()
		file.close()		
		
 
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
	
Blender.Window.FileSelector(openFile,'import','Kingdom Heroes 2 Online *.visual')