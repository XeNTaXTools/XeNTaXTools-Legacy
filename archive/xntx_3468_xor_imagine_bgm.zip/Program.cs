﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.IO;


namespace xor_imagine_bgm
{
    class Program
    {
        static private UInt32 ReadUInt(FileStream fstream)
        {
            Byte[] bytes = new Byte[4];
            fstream.Read(bytes, 0, 4);
            UInt32 result = System.BitConverter.ToUInt32(bytes, 0);
            return result;
        }

        static private string[] getFiles(string SourceFolder, string Filter, System.IO.SearchOption searchOption)
        {
            // ArrayList will hold all file names
            ArrayList alFiles = new ArrayList();

            // Create an array of filter string
            string[] MultipleFilters = Filter.Split('|');

            // for each filter find mathing file names
            foreach (string FileFilter in MultipleFilters)
            {
                // add found file names to array list
                alFiles.AddRange(Directory.GetFiles(SourceFolder, FileFilter, searchOption));
            }

            // returns string array of relevant file names
            return (string[])alFiles.ToArray(typeof(string));
        }
        static void Main(string[] args)
        {
            UInt32 xored_key = 0;
            Console.WriteLine("(c) 2013 - Fastelbja");

            string[] sFiles = getFiles(AppDomain.CurrentDomain.BaseDirectory,"*.wav|*.mp3",SearchOption.TopDirectoryOnly);
            foreach (string sFilename in sFiles)
            {
                string sFileNameOut = Path.GetDirectoryName(sFilename) + "\\xored\\" + Path.GetFileName(sFilename);
                if (!Directory.Exists(Path.GetDirectoryName(sFilename) + "\\xored")) Directory.CreateDirectory(Path.GetDirectoryName(sFilename) + "\\xored");
                if (File.Exists(sFileNameOut)) File.Delete(sFileNameOut);

                FileStream fs = new FileStream(sFilename,FileMode.Open);
                BinaryReader br = new BinaryReader(fs);

                if (br.BaseStream.Length != 0)
                {
                    FileStream fs_out = new FileStream(sFileNameOut, FileMode.CreateNew);
                    BinaryWriter br_out = new BinaryWriter(fs_out);

                    Console.WriteLine("Decoding " + Path.GetFileName(sFilename) + " to xored\\" + Path.GetFileName(sFileNameOut));
                    if (ReadUInt(fs) == 0x46464952)
                    {
                        xored_key = 0;
                        br.BaseStream.Position = 0;
                    }
                    else
                    {
                        if (Path.GetExtension(sFilename).ToUpper() == ".MP3")
                        {
                            br.BaseStream.Position = br.BaseStream.Length - 4;
                            xored_key = br.ReadUInt32();
                        }
                        else
                        {
                            xored_key = br.ReadUInt32();
                            xored_key = xored_key ^ 0x46464952;
                        }
                        br.BaseStream.Position = 4;
                    }


                    do
                    {
                        UInt32 read_uint = ReadUInt(fs);
                        read_uint = read_uint ^ xored_key;
                        br_out.Write(read_uint);
                    } while (br.BaseStream.Position != br.BaseStream.Length);
                    br_out.Close();
                    fs_out.Close();
                }
                br.Close();
                fs.Close();
            }
        }
    }
}
