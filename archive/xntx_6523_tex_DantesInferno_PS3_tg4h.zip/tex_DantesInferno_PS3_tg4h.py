from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Dante's Inferno [PS3]", ".tg4h")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
	#noesis.logPopup()
	return 1

def noepyCheckType(data):
	return 1
	
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data, NOE_BIGENDIAN)
    bs.seek(0x1c, NOESEEK_ABS)
    datasize = bs.readUInt()
    print(datasize, ":datasize")	
    imgWidth = bs.readUShort()            
    print(imgWidth, ":imgWidth")
    imgHeight = bs.readUShort()           
    print(imgHeight, ":imgHeight")
    bs.seek(0x2c, NOESEEK_ABS)        
    Off1 = bs.readUInt()
    bs.seek(Off1 + 1, NOESEEK_ABS)        
    Off2 = bs.readUInt()
    bs.seek(Off2, NOESEEK_ABS)        
    imgFmt = bs.readString()
    print(imgFmt, ":imgFmt")
    texMain = rapi.getLocalFileName(rapi.getInputName()).replace(".tg4h", ".tg4d")
    print(texMain, ":texMain")
    var1 = texMain[:4] #get first 4 char
    var2 = texMain[4:] #get 4th char to end
    #var1 = int(var1) + 2                    
    var1 = int(var1) + 1                     
    if var1 > 99 and var1 < 1000:
        var1 = str("0") + str(var1)
        print("using one zero")
    elif var1 > 9 and var1 < 100:
        var1 = str("00") + str(var1)
        print("using two zeros")
    elif var1 < 10:
        var1 = str("000") + str(var1) 
        print("using three zeros")
    elif var1 > 999:
        var1 = str(var1)
        print("using no zeros")
    texMain = var1 + var2
    print(var1 , ":var1")
    print(var2 , ":var2")
    print(texMain , ":new texMain")
    texName = rapi.getDirForFilePath(rapi.getInputName()).replace("tg4h", "tg4d") + texMain
    print(texName, ":texName")
    wtf = NoeBitStream(rapi.loadIntoByteArray(texName))
    imgData = wtf.readBytes(datasize)
    #DXT1
    if imgFmt == 'DXT1':
        texFmt = noesis.NOESISTEX_DXT1
    #DXT1a
    elif imgFmt == 'DXT1a':
        texFmt = noesis.NOESISTEX_DXT1
    #DXT1c
    elif imgFmt == 'DXT1c':
        texFmt = noesis.NOESISTEX_DXT1
    #DXT5
    elif imgFmt == 'DXT5':
        texFmt = noesis.NOESISTEX_DXT5
    #DXT5_NM
    elif imgFmt == 'DXT5_NM':
        texFmt = noesis.NOESISTEX_DXT5
    #RGBA8
    elif imgFmt == 'RGBA8':
        imgData = rapi.imageDecodeRaw(imgData, imgWidth, imgHeight, "r8 g8 b8 a8")
        texFmt = noesis.NOESISTEX_RGBA32
    #RGBX8 (designed for a vertical scroll shader?)
    elif imgFmt == 'RGBX8':
        imgData = rapi.imageDecodeRaw(imgData, imgWidth, imgHeight, "b8 g8 r8 a8")
        texFmt = noesis.NOESISTEX_RGBA32
    #L8A8 (not sure how to read this format) 
    elif imgFmt == 'L8A8':
        imgData = rapi.imageDecodeRaw(imgData, imgWidth, imgHeight, "r8 g0 b0 a8") #?
        texFmt = noesis.NOESISTEX_DXT1
        # https://msdn.microsoft.com/en-us/library/windows/desktop/bb943991(v=vs.85).aspx#common_dds_file_resource_formats_and_associated_header_content
    #L8
    elif imgFmt == 'L8':
        imgData = rapi.imageDecodeRaw(imgData, imgWidth, imgHeight, "r8 g0 b0 a0") #?
        texFmt = noesis.NOESISTEX_RGBA32 #?
    #unknown, not handled
    else:
        print("WARNING: Unhandled image format")
        return None
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, imgData, texFmt))
    return 1