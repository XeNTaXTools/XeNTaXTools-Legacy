import newGameLib
reload(newGameLib)
from newGameLib import *
import Blender
import math
from math import *

def filesParser(filename,g):
	g.endian='>'
	g.word(4)
	w=g.i(3)
	unp=Unpacker()
	unp.inputFile=filename
	unp.outputDir=g.dirname+os.sep+g.basename
	unp.fileCount=w[1]
	for m in range(w[1]):
		unp.nameList.append(g.word(32))
		v=g.I(4)
		unp.offsetList.append(v[0])
		unp.sizeList.append(v[1])
	unp.unpack()
		
		
def NSHP(start,g):
		mesh=Mesh()
		mesh.TRISTRIP=True
		g.tell()	
		g.word(16)
		unk020 = g.H(1)[0]
		VertCount = g.H(1)[0]
		unk022 = g.H(1)[0]
		FaceSections = g.H(1)[0]
		unk024 = g.B(1)[0]
		unk025 = g.B(1)[0]
		unk026 = g.H(1)[0]
		unk027 = g.H(1)[0]
		unk028 = g.H(1)[0]
		unk029 = g.H(1)[0]
		unk02A = g.H(1)[0]
		g.seek(0xC,1)
		mesh.boneIDList=g.H(unk024)
		g.seekpad(4)
		g.tell()
		for m in range(VertCount):
			t=g.tell()
			mesh.vertPosList.append(g.f(3))
			g.seek(t+12)
			#print g.B(8)
			mesh.skinWeightList.append(g.B(4))
			#print mesh.skinWeightList[m]
			mesh.skinIndiceList.append(g.B(4))
			g.seek(t+28)
			mesh.vertUVList.append(g.half(2))
			g.seek(t+32)
		g.seekpad(4)	
		totalface = 0
		IDStart=0
		IDCount=0
		for b in range(FaceSections):
			mat=Mat()
			mat.ZTRANS=True
			mat.TRISTRIP=True
			mat.IDStart=IDStart
			unk030 = g.H(1)[0]
			mat.ID=unk030
			unk031 = g.H(1)[0]
			unk032 = g.H(1)[0]
			unk033 = g.H(1)[0]
			unk034 = g.H(1)[0]
			unk035 = g.H(1)[0]
			unk036 = g.H(1)[0]
			IDCount = g.H(1)[0]
			mat.IDCount=IDCount
			totalface += IDCount
			IDStart+=IDCount
			mesh.matList.append(mat)
		mesh.indiceList=g.H(totalface)
		meshList.append(mesh)
	
def NTX3(start,g):
	w=g.i(4)
	v=g.H(12)
	g.seek(start+w[2])
	img=Image()
	img.szer=v[4]
	img.wys=v[5]
	img.data=g.read(w[3])
	img.format='DXT1'
	imgList.append(img)

def NMTR(start,g):
	for m in range(matCount):
		mat=Mat()
		t=g.tell()
		w=g.H(8)
		if w[5]==1:			
			mat.diffuseImgID=w[2]
		else:
			mat.diffuseImgID=None
		g.f(4)
		g.i(4)
		w=g.h(8)
		if w[0]!=-1:
			mat.alphaImgID=w[0]
		else:
			mat.alphaImgID=None
			
		g.h(8)
		g.h(8)
		g.seek(t+96)
		matList.append(mat)
	
def NBN2(t,g):
	#g.debug=True
	#skeleton.ARMATURESPACE=True
	for m in range(boneCount):
		bone=Bone()
		t=g.tell()		
		bone.name=g.word(16)
		w=g.h(3)
		bone.parentID=w[1]
		g.seek(t+64-40)
		a=180*g.short(1,'h')[0]/pi
		b=180*g.short(1,'h')[0]/pi
		c=180*g.short(1,'h')[0]/pi
		#print a,b,c
		#print g.h(3)
		#print g.short(3)
		#bone.posMatrix=VectorMatrix(g.short(3))
		#bone.rotMatrix=Matrix()
		bone.rotMatrix=Euler(a,b,c).toMatrix().resize4x4()
		g.seek(t+64-12)
		bone.posMatrix=VectorMatrix(g.f(3))#.invert()
		g.seek(t+64)
		skeleton.boneList.append(bone)
	
def p3objParser(filename,g):
	global imgList
	global matList
	global meshList
	global matCount
	global boneCount
	global skeleton
	
	
	
	offset=g.tell()
	t=g.tell()
	g.endian='>'
	g.word(4)
	objSize,unk,unk=g.i(3)
	g.word(16)
	w=g.H(16)
	#print w
	if w[4]!=0:
		modelID=ParseID()
		skeleton=Skeleton()
		skeleton.name='armature-'+str(modelID)
		skeleton.NICE=True
		#skeleton.IK=True
		skeleton.BONESPACE=True
	
		t=g.tell()
		data=g.read(g.fileSize()-t)
		offset1=data.find('NSHP')
		g.seek(t+offset1)
		matCount=w[2]
		boneCount=w[4]
		imgList=[]
		matList=[]
		meshList=[]
		while(True):
			t=g.tell()
			if t==offset+objSize:break
			chunk=g.word(4)
			size=g.i(1)[0]
			if chunk=='NTX3':
				NTX3(t,g)
			if chunk=='NSHP':
				NSHP(t,g)
			if chunk=='NMTR':
				NMTR(t,g)
			if chunk=='NBN2':
				NBN2(t,g)	
			g.seek(t+size)
			
			
		skeleton.draw()	
			
		for imgID in range(len(imgList)):
			img=imgList[imgID]
			img.name=g.dirname+os.sep+str(modelID)+os.sep+str(imgID)+'.dds'
			img.draw()
			
		for meshID in range(len(meshList)):
			mesh=meshList[meshID]
			for matID in range(len(mesh.matList)):
				mat=mesh.matList[matID]
				mat.diffuse=imgList[matList[mat.ID].diffuseImgID].name
				if matList[mat.ID].alphaImgID is not None:
					mat.alpha=imgList[matList[mat.ID].alphaImgID].name
			mesh.BINDSKELETON=skeleton.name	
			skin=Skin()
			for m in range(len(mesh.boneIDList)):
				skin.boneMap.append(skeleton.boneNameList[mesh.boneIDList[m]])
			mesh.skinList.append(skin)
			mesh.SPLIT=True
			mesh.draw()
	
	
def bopParser(filename,g):
	g.endian='>'
	
	while(True):
		t=g.tell()
		data=g.read(g.fileSize()-t)
		offset=data.find('NMDL')
		if offset==-1:
			break
		g.seek(t+offset)
		p3objParser(filename,g)
		g.seek(4,1)	
		
			
def openFile(filename):
	print
	print filename
	print
	ext=filename.split('.')[-1].lower()
	
	
	if ext=='files':
		file=open(filename,'rb')
		g=BinaryReader(file)
		filesParser(filename,g)
		file.close()
	
	if ext=='p3obj':
		file=open(filename,'rb')
		g=BinaryReader(file)
		bopParser(filename,g)
		file.close()
	
	if ext=='bop':
		file=open(filename,'rb')
		g=BinaryReader(file)
		bopParser(filename,g)
		file.close()
	
	if ext=='e':
		file=open(filename,'rb')
		g=BinaryReader(file)
		bopParser(filename,g)
		file.close()
	
Blender.Window.FileSelector(openFile,'import','Eternal Sonata Ps3 files, *.files, *.p30bj, *.bop, *.e') 