#by Durik256
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Epic Mickey", ".nif")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)   
    return 1
    
def noepyCheckType(data):
    if data.find(b'\x15\x02\x01\x00') < 0:
        return 0
    return 1

def noepyLoadModel(bs, mdlList):
    face_ofsset = bs.find(b'\x15\x02\x01\x00') - 8
    bs = NoeBitStream(bs[face_ofsset:])
    ctx = rapi.rpgCreateContext()
    
    inum = bs.readInt()
    bs.seek(8, 1)
    
    IBUF = bs.readBytes(inum*2)
    
    bs.seek(17, 1)
    vnum = bs.readInt()
    bs.seek(12, 1)#bs.seek(12 + vnum*12 + 29, 1)
    UVBUF = bs.readBytes(vnum*12)
    bs.seek(29, 1)
    VBUF = bs.readBytes(vnum*12)
    print(bs.getOffset())
    
    rapi.rpgBindPositionBuffer(VBUF, noesis.RPGEODATA_FLOAT, 12)
    rapi.rpgBindUV1BufferOfs(UVBUF, noesis.RPGEODATA_FLOAT, 12, 4)
    rapi.rpgCommitTriangles(IBUF, noesis.RPGEODATA_SHORT, inum, noesis.RPGEO_TRIANGLE)
    
    mdl = rapi.rpgConstructModel()
    mdlList.append(mdl)
    return 1