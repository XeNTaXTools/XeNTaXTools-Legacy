#region Using statements
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
#endregion

namespace MshtoObj
{
    public partial class Form1 : Form
    {
        #region Variables

        //Locations
        string m_fileInput;

        //FileStreams
        public StreamReader m_inBaseReader;
        public BinaryReader m_inBinReader;
        public StreamWriter m_outBaseWriter;
        public BinaryWriter m_outBinWriter;

        //Structs
        struct Vector3
        {
            public Single X;
            public Single Y;
            public Single Z;

            public Vector3(Single x, Single y, Single z)
            {
                X = x;
                Y = y;
                Z = z;
            }
        }
        struct Vector2
        {
            public Single X;
            public Single Y;

            public Vector2(Single u, Single v)
            {
                X = u;
                Y = v;
            }
        }
        struct mesh_Data
        {
            public string m_ModelName;
            public string m_MeshName;
            public string m_TextureName;
            public Int16 m_PositionCount;
            public Int16 m_FaceCount;
            public Int16 m_Sector3Count;
        }
        struct FaceGroup
        {
            public int X;
            public int Y;
            public int Z;

            public FaceGroup(int x, int y, int z)
            {
                X = x;
                Y = y;
                Z = z;
            }
        }
        
        //Mesh Information
        int cntTex;
        int m_curPosCount;
        string m_mtlPath;
        Int16 mesh_LimbCount;
        mesh_Data MeshData;
        private List<Vector3> normals;
        private List<Vector2> texCoords;
        private List<FaceGroup> faceGroup;
        int curTex;

        //Import
        Exporter frmExport;
        #endregion

        #region Init

        public Form1()
        {
            InitializeComponent();
        }

        #endregion

        private void btnToObj_Click(object sender, EventArgs e)
        {
            //Get file
            OFD.ShowDialog();
            if (OFD.CheckFileExists)
            {
                m_fileInput = OFD.FileName;
                Export();
            }
        }

        #region Export

        public void Export()
        {
            //Prepare streams
            m_inBaseReader = new StreamReader(m_fileInput);
            m_inBinReader = new BinaryReader(m_inBaseReader.BaseStream);
            m_outBaseWriter = new StreamWriter(string.Format("{0}{1}",m_fileInput,".obj"));
            m_outBinWriter = new BinaryWriter(m_outBaseWriter.BaseStream);

            //Aquire Header Junk
            GetHeaderData();

            for (int x = 0; x < mesh_LimbCount; x++)
            {
                //Get the Positions
                GetLimbPositions();
                GetLimbTriangles();
                WriteNormals();
                WriteFaces();
                m_outBaseWriter.Flush();
                //Bypass sector3
                if (autoSec3.Checked)
                {
                    if (MeshData.m_Sector3Count == 0)
                    {
                        m_inBaseReader.BaseStream.Position += 4;
                    }
                    else
                    {
                        PassSector3();
                    }
                }
                else
                {
                    if (!chkSec3.Checked)
                    {
                        PassSector3();
                    }
                    else
                    {
                        m_inBaseReader.BaseStream.Position += 4;
                    }
                }
            }

            //Disarm the streams
            m_outBaseWriter.Close();
            m_inBaseReader.Close();
            m_outBaseWriter.Dispose();
            m_inBaseReader.Dispose();
        }

        //Get the data before the first limb
        void GetHeaderData()
        {
            m_curPosCount = 0;
            cntTex = 1;
            mesh_LimbCount = m_inBinReader.ReadInt16();

            //Write Header Comment
            m_outBaseWriter.WriteLine("#Exported with the power of Nava");
            //Write master mtlib reference
            m_mtlPath = string.Format("{0}.mtl",SplitFileName(m_fileInput));
            m_outBaseWriter.WriteLine(string.Format("mtllib {0}",m_mtlPath));
        }

        //Gets the positions
        void GetLimbPositions()
        {
            //Hold them in
            normals = new List<Vector3>();
            texCoords = new List<Vector2>();
            faceGroup = new List<FaceGroup>();
            MeshData = new mesh_Data();
            
            //Data Read
            MeshData.m_ModelName = SimplifyString(new string(m_inBinReader.ReadChars(100)));
            MeshData.m_MeshName = SimplifyString(new string(m_inBinReader.ReadChars(100)));
            /*skip1*/
            m_inBinReader.BaseStream.Seek(192, SeekOrigin.Current);
            MeshData.m_PositionCount = m_inBinReader.ReadInt16();
            MeshData.m_FaceCount = m_inBinReader.ReadInt16();
            MeshData.m_Sector3Count = m_inBinReader.ReadInt16();
            //safety mech
            long posProtect = m_inBaseReader.BaseStream.Position;
            MeshData.m_TextureName = SplitFileName(SimplifyString(new string(m_inBinReader.ReadChars(100))));
            m_inBaseReader.BaseStream.Position = posProtect + 100;
            /*skip2*/
            m_inBinReader.BaseStream.Seek(195, SeekOrigin.Current);

            WriteMTL(); //Prepare for textures

            //Write Group
            m_outBaseWriter.WriteLine("");
            m_outBaseWriter.WriteLine(string.Format("o {0}", MeshData.m_ModelName));
            m_outBaseWriter.WriteLine(string.Format("g {0}", MeshData.m_MeshName));

            //Loop Write Positions
            for (int cnt = 1; cnt <= MeshData.m_PositionCount; cnt++)
            {
                m_outBaseWriter.WriteLine(string.Format("v {0} {1} {2}", strSingle(m_inBinReader.ReadSingle()), strSingle(m_inBinReader.ReadSingle()), strSingle(m_inBinReader.ReadSingle())));
                //positions.Add(new Vector3(binReader.ReadSingle() * 50, binReader.ReadSingle() * 50, binReader.ReadSingle() * 50)); //*50 manual scaling factor
                m_inBinReader.BaseStream.Seek(4, SeekOrigin.Current);
                normals.Add(new Vector3(m_inBinReader.ReadSingle(),m_inBinReader.ReadSingle(),m_inBinReader.ReadSingle()));
            }

            //Line Space
            m_outBaseWriter.WriteLine(string.Format("#{0} V",MeshData.m_PositionCount));
            m_outBaseWriter.WriteLine("");
        }

        //Write MTL File
        void WriteMTL()
        {
            StreamWriter MTLwriter = new StreamWriter(m_mtlPath,true);
            MTLwriter.WriteLine("# Extracted with NavaForce!");
            MTLwriter.WriteLine("");
            MTLwriter.WriteLine(string.Format("newmtl modelx_auv{0}",curTex));
            MTLwriter.WriteLine("Ns 100.000");
            MTLwriter.WriteLine("d 1.00000");
            MTLwriter.WriteLine("illum 2");
            MTLwriter.WriteLine("Kd 1.00000 1.00000 1.00000");
            MTLwriter.WriteLine("Ka 1.00000 1.00000 1.00000");
            MTLwriter.WriteLine("Ks 1.00000 1.00000 1.00000");
            MTLwriter.WriteLine("Ke 0.00000e+0 0.00000e+0 0.00000e+0");
            MTLwriter.WriteLine(string.Format("map_Kd {0}",MeshData.m_TextureName));
            MTLwriter.Close();
        }

        //Link the triangles
        void GetLimbTriangles()
        {
            for (int cnt = 1; cnt <= MeshData.m_FaceCount; cnt++)
            {
                faceGroup.Add(new FaceGroup(m_inBinReader.ReadInt32(), m_inBinReader.ReadInt32(), m_inBinReader.ReadInt32()));
                m_inBinReader.BaseStream.Seek(36, SeekOrigin.Current);
                texCoords.Add(new Vector2(m_inBinReader.ReadSingle(), 1 - m_inBinReader.ReadSingle()));
                m_inBinReader.BaseStream.Seek(4, SeekOrigin.Current);
                texCoords.Add(new Vector2(m_inBinReader.ReadSingle(), 1 - m_inBinReader.ReadSingle()));
                m_inBinReader.BaseStream.Seek(4, SeekOrigin.Current);
                texCoords.Add(new Vector2(m_inBinReader.ReadSingle(), 1 - m_inBinReader.ReadSingle()));

                m_inBinReader.BaseStream.Seek(8, SeekOrigin.Current);
            }
        }

        //Write info to file
        void WriteNormals()
        {
            //Write out the texture coordinates
            for (int x = 0; x <= texCoords.Count-1; x++)
            {
                m_outBaseWriter.WriteLine(string.Format("vt {0} {1} 0.000000",texCoords[x].X,1-texCoords[x].Y));
            }
            m_outBaseWriter.WriteLine(string.Format("#VT {0}",texCoords.Count));
            m_outBaseWriter.WriteLine(""); //Line Skip

            //Write out the normals
            for (int x = 0; x <= normals.Count-1; x++)
            {
                m_outBaseWriter.WriteLine(string.Format("vn {0} {1} {2}", strSingle(normals[x].X), strSingle(normals[x].Y), strSingle(normals[x].Z)));
            }
            m_outBaseWriter.WriteLine("");
        }

        //Write faces out of file
        void WriteFaces()
        {
            //Write Group
            m_outBaseWriter.WriteLine(string.Format("#s {0}", MeshData.m_MeshName));

            //Write Material usage
            m_outBaseWriter.WriteLine(string.Format("usemtl modelx_auv{0}",curTex));
            curTex += 1;

            //Write out the texture coordinates
            for (int x = 0; x < faceGroup.Count; x++)
            {
                m_outBaseWriter.WriteLine(string.Format("f {0}/{3}/{0} {1}/{4}/{1} {2}/{5}/{2}", faceGroup[x].X + 1 + (m_curPosCount), faceGroup[x].Y + 1 + (m_curPosCount), faceGroup[x].Z + 1 + (m_curPosCount), cntTex, cntTex + 1, cntTex + 2));
                cntTex += 3;
            }

            //Increment face count for next limbset
            m_curPosCount += MeshData.m_PositionCount;
        }

        //Skip sector3
        void PassSector3()
        {
            m_inBinReader.BaseStream.Seek(204, SeekOrigin.Current);
            for (int cnt = 1; cnt <= MeshData.m_PositionCount; cnt++)
            {
                m_inBinReader.BaseStream.Seek(40, SeekOrigin.Current);
            }
        }
        #endregion

        #region Additives

        //Helping Function, cuts out 0x0 from strings
        string SimplifyString(string Input)
        {
            String[] splitter = Input.Split('\0');
            return splitter[0];
        }

        //Give only the file name
        string SplitFileName(string Input)
        {
            string[] splitName = Input.Split('\\');
            return splitName[splitName.GetUpperBound(0)];
        }

        //Get directory
        string SplitDirectory(string Input)
        {
            return Input.Replace(SplitFileName(m_fileInput), "");
        }

        //Write single properly
        string strSingle(Single single)
        {
            return single.ToString("0.000000");
        }

        #endregion

        //Export Form
        private void button1_Click(object sender, EventArgs e)
        {
            frmExport = new Exporter();
            frmExport.ShowDialog();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        //Advanced Extraction
        private void btnManual_Click(object sender, EventArgs e)
        {
            OFD.ShowDialog();
            if (OFD.CheckFileExists)
            {
                m_fileInput = OFD.FileName;
            }

            //Prepare streams
            m_inBaseReader = new StreamReader(m_fileInput);
            m_inBinReader = new BinaryReader(m_inBaseReader.BaseStream);
            m_outBaseWriter = new StreamWriter(string.Format("{0}{1}",m_fileInput,".obj"));
            m_outBinWriter = new BinaryWriter(m_outBaseWriter.BaseStream);

            //Aquire Header Junk
            GetHeaderData();

            for (int x = 0; x <= textBox1.Lines.GetUpperBound(0); x++)
            {
                //Get the Positions
                m_inBaseReader.BaseStream.Position = long.Parse(textBox1.Lines[x]);
                GetLimbPositions();
                GetLimbTriangles();
                WriteNormals();
                WriteFaces();
                m_outBaseWriter.Flush();
            }

            //Disarm the streams
            m_outBaseWriter.Close();
            m_inBaseReader.Close();
            m_outBaseWriter.Dispose();
            m_inBaseReader.Dispose();
        }


    }
}