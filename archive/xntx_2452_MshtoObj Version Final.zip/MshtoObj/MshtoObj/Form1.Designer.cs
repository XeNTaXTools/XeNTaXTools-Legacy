namespace MshtoObj
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnToObj = new System.Windows.Forms.Button();
            this.OFD = new System.Windows.Forms.OpenFileDialog();
            this.button1 = new System.Windows.Forms.Button();
            this.chkSec3 = new System.Windows.Forms.CheckBox();
            this.autoSec3 = new System.Windows.Forms.CheckBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btnManual = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnToObj
            // 
            this.btnToObj.Location = new System.Drawing.Point(12, 12);
            this.btnToObj.Name = "btnToObj";
            this.btnToObj.Size = new System.Drawing.Size(206, 23);
            this.btnToObj.TabIndex = 0;
            this.btnToObj.Text = "Convert to OBJ";
            this.btnToObj.UseVisualStyleBackColor = true;
            this.btnToObj.Click += new System.EventHandler(this.btnToObj_Click);
            // 
            // OFD
            // 
            this.OFD.FileName = "openFileDialog1";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 41);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(206, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "Convert to MSH";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // chkSec3
            // 
            this.chkSec3.AutoSize = true;
            this.chkSec3.Location = new System.Drawing.Point(12, 73);
            this.chkSec3.Name = "chkSec3";
            this.chkSec3.Size = new System.Drawing.Size(87, 17);
            this.chkSec3.TabIndex = 2;
            this.chkSec3.Text = "Skip Sector3";
            this.chkSec3.UseVisualStyleBackColor = true;
            // 
            // autoSec3
            // 
            this.autoSec3.AutoSize = true;
            this.autoSec3.Location = new System.Drawing.Point(12, 96);
            this.autoSec3.Name = "autoSec3";
            this.autoSec3.Size = new System.Drawing.Size(118, 17);
            this.autoSec3.TabIndex = 3;
            this.autoSec3.Text = "Autodetect Sector3";
            this.autoSec3.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(12, 143);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox1.Size = new System.Drawing.Size(206, 146);
            this.textBox1.TabIndex = 4;
            // 
            // btnManual
            // 
            this.btnManual.Location = new System.Drawing.Point(12, 295);
            this.btnManual.Name = "btnManual";
            this.btnManual.Size = new System.Drawing.Size(206, 23);
            this.btnManual.TabIndex = 5;
            this.btnManual.Text = "Manual Extract";
            this.btnManual.UseVisualStyleBackColor = true;
            this.btnManual.Click += new System.EventHandler(this.btnManual_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(230, 324);
            this.Controls.Add(this.btnManual);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.autoSec3);
            this.Controls.Add(this.chkSec3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnToObj);
            this.Name = "Form1";
            this.Text = "MSH OBJ Converter";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnToObj;
        private System.Windows.Forms.OpenFileDialog OFD;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.CheckBox chkSec3;
        private System.Windows.Forms.CheckBox autoSec3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button btnManual;
    }
}

