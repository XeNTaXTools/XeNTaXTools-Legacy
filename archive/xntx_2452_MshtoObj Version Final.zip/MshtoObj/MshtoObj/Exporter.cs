using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace MshtoObj
{
    public partial class Exporter : Form
    {
#region Variables

        //Locations
        string m_fileInput;
        string m_mtlPath;
        string m_texDir;

        //positions
        long m_posPosCount;

        //FileStreams
        public StreamReader m_inBaseReader;
        public BinaryReader m_inBinReader;
        public StreamWriter m_outBaseWriter;
        public BinaryWriter m_outBinWriter;

        //Structs
        struct Vector3
        {
            public Single X;
            public Single Y;
            public Single Z;

            public Vector3(Single x, Single y, Single z)
            {
                X = x;
                Y = y;
                Z = z;
            }
        }
        struct Vector2
        {
            public Single X;
            public Single Y;

            public Vector2(Single u, Single v)
            {
                X = u;
                Y = v;
            }
        }
        struct mesh_Data
        {
            public string m_ModelName;
            public string m_MeshName;
            public string m_TextureName;
            public Int16 m_PositionCount;
            public Int16 m_FaceCount;
            public Int16 m_Sector3Count;
        }
        struct FaceGroup
        {
            public int face1Pos;
            public int face1Tex;
            public int face2Pos;
            public int face2Tex;
            public int face3Pos;
            public int face3Tex;

            public FaceGroup(int pos1, int tex1, int pos2, int tex2, int pos3, int tex3)
            {
                face1Pos = pos1;
                face1Tex = tex1;
                face2Pos = pos2;
                face2Tex = tex2;
                face3Pos = pos3;
                face3Tex = tex3;
            }
        }

        //Mesh Information
        mesh_Data MeshData;
        private List<Vector3> positions;
        private List<Vector3> normals;
        private List<Vector2> texCoords;
        private List<FaceGroup> faceGroup;

        //Counts
        int m_faceOffset;   //The face per mesh number
        int m_MeshCount;    //Number of meshes in file
        int m_objOffset;    //OBJ vertex realignment
        int m_objTexOff;    //OBJ Texture realignment
#endregion

#region Init
        public Exporter()
        {
            positions = new List<Vector3>();
            normals = new List<Vector3>();
            texCoords = new List<Vector2>();
            faceGroup = new List<FaceGroup>();

            InitializeComponent();
        }
#endregion

        private void f_btnBegin_Click(object sender, EventArgs e)
        {
            OFD.Filter = "OBJ Files|*.obj|All Files|*.*";
            if (OFD.ShowDialog() == DialogResult.Cancel)
                return;
            textBox1.Text = OFD.FileName;    
        }

#region Import

        void Import()
        {
            //Prepare streams
            m_inBaseReader = new StreamReader(m_fileInput);
            m_inBinReader = new BinaryReader(m_inBaseReader.BaseStream);
            m_outBaseWriter = new StreamWriter(string.Format("{0}{1}", m_fileInput, ".msh"));
            m_outBinWriter = new BinaryWriter(m_outBaseWriter.BaseStream);

            //Write Dummy Header Bytes
            m_outBinWriter.Write("\0\0".ToCharArray(),0,2);
            m_texDir = m_mtlPath;

            //Fill MeshData with defaults
            MeshData = new mesh_Data();
            MeshData.m_MeshName = "NULL";
            MeshData.m_ModelName = "NULL";
            MeshData.m_TextureName = string.Format("{0}{1}",m_texDir,GetTextureName());
            m_objOffset = 0;
            m_objTexOff = 0;

            //Begin readthrough loop
            ParseOBJ();
        }

        //Read Each Line, break on O's
        void ParseOBJ()
        {
            string inRead;
            string[] strSplit;
            while (!m_inBaseReader.EndOfStream)
            {
                //Get Info
                inRead = m_inBaseReader.ReadLine();
                strSplit = inRead.Split(" /".ToCharArray());

                //Parse
                switch (strSplit[0])
                {
                    case "o":
                        if (texCoords.Count != 0)
                        {
                            WriteMesh();
                        }
                        //Clear info for next mesh
                        m_MeshCount += 1;
                        positions.Clear();
                        texCoords.Clear();
                        normals.Clear();
                        faceGroup.Clear();
                        MeshData = new mesh_Data();
                        MeshData.m_MeshName = "NULL";
                        MeshData.m_ModelName = "NULL";
                        MeshData.m_TextureName = string.Format("{0}{1}", m_texDir, GetTextureName());
                        MeshData.m_ModelName = inRead.Remove(0, 2);
                        break;
                    case "g":
                        MeshData.m_MeshName = inRead.Remove(0, 2);
                        break;
                    case "v":
                        positions.Add(new Vector3(Convert.ToSingle(strSplit[1]),Convert.ToSingle(strSplit[2]),Convert.ToSingle(strSplit[3])));
                        break;
                    case "vt":
                        texCoords.Add(new Vector2(Convert.ToSingle(strSplit[1]), Convert.ToSingle(strSplit[2])));
                        break;
                    case "vn":
                        normals.Add(new Vector3(Convert.ToSingle(strSplit[1]), Convert.ToSingle(strSplit[2]), Convert.ToSingle(strSplit[3])));
                        break;
                    case "f":
                        faceGroup.Add(new FaceGroup(int.Parse(strSplit[1]),int.Parse(strSplit[2]),int.Parse(strSplit[4]),int.Parse(strSplit[5]),int.Parse(strSplit[7]),int.Parse(strSplit[8])));
                        break;
                }
            }
            WriteMesh();
            m_outBinWriter.Seek(0, SeekOrigin.Begin);
            m_outBinWriter.Write(Convert.ToUInt16(m_MeshCount));
        }

        //Write Out PerMesh Data
        void WriteMesh()
        {
            m_outBinWriter.Write(ExpandString(MeshData.m_ModelName,100).ToCharArray(), 0, 100);         //OBJ Name
            m_outBinWriter.Write(ExpandString(MeshData.m_MeshName,100).ToCharArray(), 0, 100);          //Mesh Name
            m_outBinWriter.Write("\0\0".ToCharArray(),0,2);                                             //??? 2 Bytes
            m_outBinWriter.Write(16256);                                                                //Forcable Scale Factors
            m_outBinWriter.Write("\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0".ToCharArray(), 0, 16);              //16 Byte Blank Margin
            m_outBinWriter.Write(16256);                                                                //Forcable Scale Factors
            m_outBinWriter.Write("\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0".ToCharArray(), 0, 16);              //16 Byte Blank Margin
            m_outBinWriter.Write(16256);                                                                //Forcable Scale Factors
            m_outBinWriter.Write("\0\0".ToCharArray(), 0, 2);                                           //??? 2 Bytes
            m_outBinWriter.Write(1);                                                                    //Position Count 1, OBJ o's don't have position, everything relies on the positions of the vertices. Perhaps it was unsuitable to use obj conversion
            m_outBinWriter.Write(1);                                                                    //Position Count 2, This will be troublesome, but lets make do
            m_outBinWriter.Write(1);                                                                    //Position Count 3
            m_outBinWriter.Write("\0\0".ToCharArray(), 0, 2);                                           //??? 2 Bytes
            m_outBinWriter.Write(16256);                                                                //???   16256
            m_outBinWriter.Write(16256);                                                                //???   16256
            m_outBinWriter.Write("\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0".ToCharArray(), 0, 16);              //16 Byte Blank Margin
            m_outBinWriter.Write(16256);                                                                //???   16256
            m_outBinWriter.Write("\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0".ToCharArray(), 0, 16);              //16 Byte Blank Margin
            m_outBinWriter.Write(16256);                                                                //???   16256
            m_outBinWriter.Write("\0\0".ToCharArray(), 0, 2);                                           //??? 2 Bytes
            m_outBinWriter.Write(1);                                                                    //Position Count 1, OBJ o's don't have position, everything relies on the positions of the vertices. Perhaps it was unsuitable to use obj conversion
            m_outBinWriter.Write(1);                                                                    //Position Count 2, This will be troublesome, but lets make do
            m_outBinWriter.Write(1);                                                                    //Position Count 3
            m_outBinWriter.Write("\0\0".ToCharArray(), 0, 2);                                           //??? 2 Bytes
            m_outBinWriter.Write(16256);                                                                //???   16256
            m_outBinWriter.Write(16256);                                                                //???   16256
            m_outBinWriter.Write("\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0".ToCharArray(), 0, 16);              //16 Byte Blank Margin
            m_outBinWriter.Write(16256);                                                                //???   16256
            m_outBinWriter.Write("\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0".ToCharArray(), 0, 16);              //16 Byte Blank Margin
            m_outBinWriter.Write(16256);                                                                //???   16256
            m_outBinWriter.Write("\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0".ToCharArray(), 0, 16);              //16 Byte Blank Margin
            m_outBinWriter.Write(16256);                                                                //???2 Bye 16256
            /*Varible Storage*/            m_posPosCount = m_outBinWriter.BaseStream.Position-2;          //Store Location to return to
            m_outBinWriter.Write("\0\0\0\0".ToCharArray(), 0, 4);                                       //Filler for pos,face,sector3 counts
            m_outBinWriter.Write(MeshData.m_TextureName.ToCharArray(), 0, MeshData.m_TextureName.ToCharArray().GetUpperBound(0)+1);  //Write Texture Path
            m_outBinWriter.Write(ExpandString("", 236 - MeshData.m_TextureName.Length).ToCharArray(), 0, 236 - MeshData.m_TextureName.Length);  //Write variable blanks
            m_outBinWriter.Write("\x1\0\0\0\0\x1\0\0\x1".ToCharArray(),0,9);                            //Enable Lighting Boolean
            m_outBinWriter.Write(ExpandString("", 50).ToCharArray(), 0, 50);                           //Fill in room to vertex data
            m_outBinWriter.Flush();                                                                    //Flush Header

            //Write out Position Section
            for (int xii = 0; xii < positions.Count; xii++)
            {
                m_outBinWriter.Write(positions[xii].X);                                                 //Position X
                m_outBinWriter.Write(positions[xii].Y);                                                 //Position Y
                m_outBinWriter.Write(positions[xii].Z);                                                 //Position Z
                m_outBinWriter.Write("\0\0".ToCharArray(), 0, 2);                                       //Write Constant
                m_outBinWriter.Write(16256);                                                            //Write Constant
                m_outBaseWriter.BaseStream.Position -= 2;                                               //Eat Crap Data
                m_outBinWriter.Write(normals[xii].X);                                                   //Normal X
                m_outBinWriter.Write(normals[xii].Y);                                                   //Normal Y
                m_outBinWriter.Write(normals[xii].Z);                                                   //Normal Z
            }
            m_outBaseWriter.Flush();

            //Write out Face Sector (bin and base flush seperately, base first bin second)
            for (int xii = 0; xii < faceGroup.Count; xii++)
            {
                m_outBinWriter.Write(faceGroup[xii].face1Pos-1-m_objOffset);                                        //First Face
                m_outBinWriter.Write(faceGroup[xii].face2Pos-1-m_objOffset);                                        //Second Face
                m_outBinWriter.Write(faceGroup[xii].face3Pos-1-m_objOffset);                                        //Third Face
                m_outBinWriter.Write(ExpandString("", 36).ToCharArray(), 0, 36);                        //Dummy Data                                                               
                m_outBinWriter.Write(texCoords[faceGroup[xii].face1Tex-1-m_objTexOff].X);                           //TexCoord X1
                m_outBinWriter.Write(texCoords[faceGroup[xii].face1Tex-1-m_objTexOff].Y);                           //TexCoord Y1
                m_outBinWriter.Write(ExpandString("", 4).ToCharArray(), 0, 4);                          //Fill in room to vertex data
                m_outBinWriter.Write(texCoords[faceGroup[xii].face2Tex-1-m_objTexOff].X);                           //TexCoord X2
                m_outBinWriter.Write(texCoords[faceGroup[xii].face2Tex-1-m_objTexOff].Y);                           //TexCoord Y2
                m_outBinWriter.Write(ExpandString("", 4).ToCharArray(), 0, 4);                          //Fill in room to vertex data
                m_outBinWriter.Write(texCoords[faceGroup[xii].face3Tex-1-m_objTexOff].X);                           //TexCoord X3
                m_outBinWriter.Write(texCoords[faceGroup[xii].face3Tex-1-m_objTexOff].Y);                           //TexCoord Y3
                m_outBinWriter.Write(ExpandString("", 8).ToCharArray(), 0, 8);                          //Fill in room to vertex data
            }
            m_outBaseWriter.Flush();

            //BS Sector 3 - WE LOST ANIMATION HERE, WTF IS THE 204 BYTE SECTION?
            m_outBinWriter.Write(ExpandString("", 4).ToCharArray(), 0, 4);                              //Fill in room to vertex data
            m_outBinWriter.Flush();

            //Fill Size Reqs
            m_outBinWriter.BaseStream.Seek(m_posPosCount, SeekOrigin.Begin);
            m_outBinWriter.Write(Convert.ToUInt16(positions.Count));
            m_outBinWriter.Write(Convert.ToUInt16(faceGroup.Count));
            m_outBinWriter.Seek(0, SeekOrigin.End);

            //Realign Vertex Data
            m_objOffset += positions.Count;
            m_objTexOff += texCoords.Count;
        }

        //File Strings with blanks
        string ExpandString(string str, int len)
        {
            while (str.Length <= len)
            {
                str += "\0";
            }
            return str;
        }

        //Aquire texture name from MTL
        string GetTextureName()
        {
            StreamReader mtlReader = new StreamReader(textBox2.Text);
            while (!mtlReader.EndOfStream)
            {
                string inRead=mtlReader.ReadLine();
                string[] strSplit = inRead.Split(' ');
                if (strSplit[0] == "map_Kd")
                {
                    mtlReader.Close();
                    return inRead.Remove(0, 7);
                }
            }
            mtlReader.Close();
            return "";
        }

#endregion

#region Additives

        //Helping Function, cuts out 0x0 from strings
        string SimplifyString(string Input)
        {
            String[] splitter = Input.Split('\0');
            return splitter[0];
        }

        //Give only the file name
        string SplitFileName(string Input)
        {
            string[] splitName = Input.Split('\\');
            return splitName[splitName.GetUpperBound(0)];
        }

        //Get directory
        string SplitDirectory(string Input)
        {
            return Input.Replace(SplitFileName(m_fileInput), "");
        }

#endregion

        private void button1_Click(object sender, EventArgs e)
        {
            OFD.Filter = "MTL Files|*.mtl|All Files|*.*";
            if (OFD.ShowDialog() == DialogResult.Cancel)
                return;
            textBox2.Text = OFD.FileName;    
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Get Paths
            m_fileInput = textBox1.Text;
            m_mtlPath = textBox2.Text;

            //Prepare false directory
            if (f_radDef.Checked)
                m_mtlPath = "D:\\1\\ASE\\tex\\";
            else
                m_mtlPath = f_txtCustom.Text;
            //Import
            Import();
        }
    }
}