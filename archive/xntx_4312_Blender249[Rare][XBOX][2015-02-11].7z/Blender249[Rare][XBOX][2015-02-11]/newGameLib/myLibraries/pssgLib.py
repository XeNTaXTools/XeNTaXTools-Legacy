import os

class Prop:
	def __init__(self):
		self.ID=None
		self.name=None
		self.value=None

class Key:
	def __init__(self):
		self.ID=None
		self.name=None
		self.propList=[]

def parseKeys(g):
	global keys 
	global off_for_start
	g.word(4)
	g.i(2)
	for n in range(g.i(1)[0]):
		key=Key()
		key.ID = g.i(1)[0]
		key.name = g.word(g.i(1)[0])
		propCount = g.i(1)[0]   
		for m in range(propCount):
			prop=Prop()
			prop.ID = g.i(1)[0]
			prop.name = g.word(g.i(1)[0])
			propList.append(prop)
		keyList.append(key)	
			

def getKey(ID):
	KEY=None
	for key in keyList:
		if key.ID==ID:
			KEY=key
			break
	return KEY		
	
def getProp(ID):
	PROP=None
	for prop in propList:
		if prop.ID==ID:
			PROP=prop
			break
	return PROP		
		
		
		


	


class Node:
	def __init__(self):
		self.name=None
		self.children=[]
		self.propList=[]
		self.offset=None

		
		
class Pssg:
	def __init__(self):
		self.input=None
		self.TEX=False
		self.MESH=False
		self.SKELETON=False
		self.MORPHS=True
		self.rootNode=Node()
		self.debug=False
			
	def parseNodes(self):
		n=0
		self.tree(self.rootNode,self.input,n)
	
				
	def addProp(self,prop,node,g,n):
		t=g.tell()
		PROP=Prop()
		PROP.name=prop.name
		if prop.name=='jointCount':
			PROP.value=g.i(1)[0]
			node.propList.append(PROP)
		elif prop.name=='skeleton':
			PROP.value=g.word(g.i(1)[0])
			node.propList.append(PROP)
		elif prop.name=='nickname':
			PROP.value=g.word(g.i(1)[0])
			node.propList.append(PROP)
		elif prop.name=='id':
			PROP.value=g.word(g.i(1)[0])
			node.propList.append(PROP)
		elif prop.name=='source':
			PROP.value=g.word(g.i(1)[0])
			node.propList.append(PROP)
		elif prop.name=='sourceCount':
			PROP.value=g.i(1)[0]
			node.propList.append(PROP)
		elif prop.name=='indices':
			PROP.value=g.word(g.i(1)[0])
			node.propList.append(PROP)
		elif prop.name=='streamCount':
			PROP.value=g.i(1)[0]
			node.propList.append(PROP)
		elif prop.name=='shader':
			PROP.value=g.word(g.i(1)[0])
			node.propList.append(PROP)
		elif prop.name=='sourceID':
			PROP.value=g.i(1)[0]
			node.propList.append(PROP)
		elif prop.name=='streamID':
			PROP.value=g.i(1)[0]
			node.propList.append(PROP)
		elif prop.name=='joint':
			PROP.value=g.word(g.i(1)[0])
			node.propList.append(PROP)
		elif prop.name=='segmentCount':
			PROP.value=g.i(1)[0]
			node.propList.append(PROP)
		elif prop.name=='primitive':
			PROP.value=g.word(g.i(1)[0])
			node.propList.append(PROP)
		elif prop.name=='format':
			PROP.value=g.word(g.i(1)[0])
			node.propList.append(PROP)
		elif prop.name=='dataBlock':
			PROP.value=g.word(g.i(1)[0])
			node.propList.append(PROP)
		elif prop.name=='subStream':
			PROP.value=g.i(1)[0]
			node.propList.append(PROP)
		elif prop.name=='renderType':
			PROP.value=g.word(g.i(1)[0])
			node.propList.append(PROP)
		elif prop.name=='dataType':
			PROP.value=g.word(g.i(1)[0])
			node.propList.append(PROP)
		elif prop.name=='offset':
			PROP.value=g.i(1)[0]
			node.propList.append(PROP)
		elif prop.name=='stride':
			PROP.value=g.i(1)[0]
			node.propList.append(PROP)
		elif prop.name=='count':
			PROP.value=g.i(1)[0]
			node.propList.append(PROP)
		elif prop.name=='size':
			PROP.value=g.i(1)[0]
			node.propList.append(PROP)
		elif prop.name=='elementCount':
			PROP.value=g.i(1)[0]
			node.propList.append(PROP)
		elif prop.name=='shaderGroup':
			PROP.value=g.word(g.i(1)[0])
			node.propList.append(PROP)
		elif prop.name=='object':
			PROP.value=g.word(g.i(1)[0])
			node.propList.append(PROP)
		elif prop.name=='width':
			PROP.value=g.i(1)[0]
			node.propList.append(PROP)
		elif prop.name=='height':
			PROP.value=g.i(1)[0]
			node.propList.append(PROP)
		elif prop.name=='texelFormat':
			PROP.value=g.read(g.i(1)[0]).upper()
			node.propList.append(PROP)
		elif prop.name=='numberMipMapLevels':
			PROP.value=g.i(1)[0]
			node.propList.append(PROP)
		elif prop.name=='type':
			PROP.value=g.word(g.i(1)[0])
			node.propList.append(PROP)
		elif prop.name=='texture':
			PROP.value=g.word(g.i(1)[0])
			node.propList.append(PROP)
		elif prop.name=='parameterID':
			PROP.value=g.i(1)[0]
			node.propList.append(PROP)
		else:
			print 'WARNING: unknow',prop.name	
		if	self.debug==True:
			txt.write(' '*n+prop.name+' '+str(PROP.value)+'\n')
		g.seek(t)	
		
		
	def tree(self,parentNode,g,n):	
		sum1 = 0
		keyID = g.i(1)[0]
		seek1 = g.i(1)[0]
		back = g.tell()
		seek2 = g.i(1)[0]
		node=Node()
		key = getKey(keyID)
		node.name=key.name 
		txt.write(' '*n+node.name+'\n')	
		node.offset=g.tell() 
		parentNode.children.append(node)
		sum1+=8
		if seek1-seek2>0:
			if seek2!=0:
				sum2 = 0
				while(True):
					if sum2>=seek2:
						break
					propID = g.i(1)[0] 
					prop=getProp(propID)				 
					seek = g.i(1)[0] 
					self.addProp(prop,node,g,n+4)
					sum2+=8+seek
					g.seek(seek,1)   
				if seek1-sum1>=64+sum2:
					sum1+=4+sum2
					while(True):
						if sum1>=seek1:break
						twig=self.tree(node,g,n+4) 
						sum1+=twig 
				else:sum1+=seek1;g.seek(back+seek1)   
			else:sum1+=seek1;g.seek(back+seek1)
		else:sum1+=seek1;g.seek(back+seek1)
		return sum1
	
	
	def parse(self):
		global keyList
		global propList
		global txt
		keyList=[]
		propList=[]
		g=self.input
		txt=None
		if self.debug==True:
			txt=open(g.dirname+os.sep+g.basename+'.txt','w')
		g.endian='>'
		parseKeys(g)
		self.parseNodes()
		if self.debug==True:
			txt.close()
			
	def nextnode(self,node,key):
		children=node.children
		for child in children:
			if child.name!=key:
				self.nextnode(child,key)
			else:
				list.append(child)
						
	def get(self,node,key):
		global list
		list=[]
		children=node.children
		for child in children:
			child.key
			if child.key!=key:
				self.nextnode(child,key)
			else:
				list.append(child)
		return list[0]				
			
	def find(self,node,key):
		global list
		list=[]
		children=node.children
		for child in children:
			if child.name!=key:
				self.nextnode(child,key)
			else:
				list.append(child)
		return list			
		