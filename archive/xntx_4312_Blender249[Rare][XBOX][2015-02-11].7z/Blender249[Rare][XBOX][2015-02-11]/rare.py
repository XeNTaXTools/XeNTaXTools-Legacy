import newGameLib
reload(newGameLib)
from newGameLib import *
import Blender	

		
	
def getString(offset,g):
	g.seek(64+offset)
	pos=g.tell()
	name=g.find('\x00')
	return name
		
def getHeader(offset,g):
	g.seek(offset)
	#print g.tell()
	return g.i(1)+g.H(2)+g.i(8)
		
		
	
def section23(A,g,n):
	global flag23,mesh
	flag23=True
	n+=4
	string=getString(A[0],g)	
	print ' '*n,A[1],string,A[0]+64
	g.seek(A[9]+64)
	if flag23==True:
		mesh=Mesh()
		meshList.append(mesh)
	for m in range(A[10]):
		offset=g.i(1)[0]+64
		tm=g.tell()
		g.seek(offset)
		B=getHeader(g.tell(),g)
		if B[1]==19:section19(B,g,n)
		g.seek(tm)
	g.seek(A[6]+64)
	
	
	
	
def section22(A,g,n,MAT):
	n+=4
	g.seek(A[0]+64)
	string=g.word(16)
	mat=Mat()
	mat.diffuse=MAT.diffuse
	mat.diffuse1=MAT.diffuse1
	mat.ao=MAT.ao
	if A[9]==1:
		B=g.i(3)
		list=g.H(B[0])
		mat.TRISTRIP=True
		mat.IDStart=len(mesh.indiceList)
		mat.IDCount=B[0]
		mesh.matList.append(mat)
		mesh.indiceList.extend(list)
		print ' '*n,A[1],string,A[0]+64,A[9]
		#for ID in list:mesh.skinIDList[ID][len(mesh.skinList)-1]=1
	else:
		countList=g.i(A[9])
		#print countList
		offsetList=g.i(A[9])
		#print offsetList
		typeList=g.i(A[9])
		#print typeList
		faceList=[]
		for m in range(A[9]):
			g.seek(offsetList[m]+64)
			if typeList[m]==7:
				faceList.extend(g.H(countList[m]))
			if typeList[m]==6:
				g.H(countList[m])
		#for ID in faceList:
		#	mesh.skinIDList[ID][len(mesh.skinList)-1]=1
		mat.QUAD=True
		mat.IDStart=len(mesh.indiceList)
		mat.IDCount=len(faceList)#A[9]
		mesh.matList.append(mat)
		mesh.indiceList.extend(faceList)
		print ' '*n,A[1],string,A[0]+64,A[9]
	
		
def section21(A,g,n):
	n+=4
	string=getString(A[0],g)
	print ' '*n,A[1],string,A[0]+64
	g.seek(A[6]+64)
	while(True):
		pos=g.tell()
		B=getHeader(g.tell(),g)
		if B[1]==18:section18(B,g,n)
		#elif B[1]==20:section20(B,g,n)
		else:
			g.seek(pos)
			break
		
def section20(A,g,n,MAT):
	n+=4
	g.seek(A[0]+64)
	string=g.word(16)
	mat=Mat()
	mat.diffuse=MAT.diffuse
	mat.diffuse1=MAT.diffuse1
	mat.ao=MAT.ao
	if A[9]==1:
		B=g.i(3)
		list=g.H(B[0])
		mat.TRISTRIP=True
		mat.IDStart=len(mesh.indiceList)
		mat.IDCount=B[0]
		mesh.matList.append(mat)
		mesh.indiceList.extend(list)
		print ' '*n,A[1],string,A[0]+64,A[9]
		for ID in list:mesh.skinIDList[ID][len(mesh.skinList)-1]=1
	else:
		countList=g.i(A[9])
		#print countList
		offsetList=g.i(A[9])
		#print offsetList
		typeList=g.i(A[9])
		#print typeList
		faceList=[]
		for m in range(A[9]):
			g.seek(offsetList[m]+64)
			if typeList[m]==7:
				faceList.extend(g.H(countList[m]))
			if typeList[m]==6:
				g.H(countList[m])
		for ID in faceList:
			mesh.skinIDList[ID][len(mesh.skinList)-1]=1
		mat.QUAD=True
		mat.IDStart=len(mesh.indiceList)
		mat.IDCount=len(faceList)#A[9]
		mesh.matList.append(mat)
		mesh.indiceList.extend(faceList)
		print ' '*n,A[1],string,A[0]+64,A[9]
		
	
def section19(A,g,n):
	global mesh
	n+=4
	string=getString(A[0],g)
	print ' '*n,A[1],string,A[0]+64
	g.seek(A[9]+64)
	if flag23==False:
		mesh=Mesh()
		meshList.append(mesh)
	for m in range(A[10]):
		B=g.i(6)
		print ' '*(n+4),B		
		if B[0]==2316:		
			p.seek(B[4])
			count=B[5]/12
			for m in range(count):
				mesh.vertPosList.append(p.f(3))	
				mesh.skinIDList.append([])
		if B[0]==3336:		
			p.seek(B[4])
			count=B[5]/8
			for m in range(count):
				mesh.vertUVList.append(p.f(2))
		if B[0]==8:		
			p.seek(B[4])
			count=B[5]/8
			boneMap=[]
			for m in range(count):
				[a,b]=map(int,p.f(2))
				if a not in boneMap:boneMap.append(a)
				if b not in boneMap:boneMap.append(b)					
				#mesh.skinIndiceList.append([boneMap.index(a),boneMap.index(b)])
				mesh.skinIndiceList.append([a/3-8,b/3-8])
			#print boneMap	
		if B[0]==2056:		
			p.seek(B[4])
			count=B[5]/8
			for m in range(count):
				mesh.skinWeightList.append(p.f(2))		
		#if B[0]==2572:		
		#	p.seek(B[4])
		#	count=B[5]/12
		#	for m in range(count):
		#		p.f(3)
	#mesh.draw()			
	g.seek(A[6]+64)
		
def section18(A,g,n):
	sys=Sys(input.filename)
	mat=Mat()
	n+=4
	string=getString(A[0],g)
	print ' '*n,A[1],string,A[0]+64
	g.seek(A[7]+64)
	#print g.i(10)
	g.seek(A[8]+64)
	#print g.i(10)
	g.seek(A[9]+64)
	B=g.i(20)
	print B
	if B[2]!=0:
		g.seek(B[2]+64)
		texList=[]
		for m in range(B[3]):
			C=g.i(7)
			print C
			#texList.append(C)
			texList.append(sys.dir+os.sep+sys.base+'_files'+os.sep+str(C[0])+'.dds')
		g.seek(B[9]+64)
		#for m in range(B[10]):
		for m in range(B[10]):
			D=g.i(4)
			print D
			tm=g.tell()
			g.seek(D[0]+64)
			type=g.find('\x00')
			print type
			if type=='colour0':mat.diffuse1=texList[D[2]]
			if type=='colour1':mat.diffuse=texList[D[2]]
			if type=='RARE_lightmap-1':mat.ao=texList[D[2]]
			g.seek(tm)
			
	
	g.seek(A[6]+64)
	while(True):
		pos=g.tell()
		B=getHeader(g.tell(),g)
		if B[1]==11:section11(B,g,n)
		elif B[1]==22:section22(B,g,n,mat)
		elif B[1]==20:section20(B,g,n,mat)
		else:
			g.seek(pos)
			break
		
	
		
def section17(A,g,n):
	n+=4
	string=getString(A[0],g)
	print ' '*n,A[1],string,A[0]+64
	g.seek(A[6]+64)
	while(True):
		pos=g.tell()
		B=getHeader(g.tell(),g)
		if B[1]==21:section21(B,g,n)
		#elif B[1]==20:section20(B,g,n)
		else:
			g.seek(pos)
			break
	
def section12(A,g,n):
	n+=4
	string=getString(A[0],g)	
	print ' '*n,A[1],string,A[0]+64
	g.seek(A[6]+64)
	while(True):
		pos=g.tell()
		B=getHeader(g.tell(),g)
		if B[1]==17:section17(B,g,n)
		#elif B[1]==20:section20(B,g,n)
		else:
			g.seek(pos)
			break
	
	
def section11(A,g,n):
	n+=4
	g.seek(A[0]+64)
	string=g.word(16)
	print ' '*n,A[1],string,A[0]+64
	g.seek(A[9]+64)
	skin=Skin()
	skin.boneMap=g.B(A[10])
	#skin.boneMap=range(A[10])
	#print skin.boneMap
	for m in range(len(mesh.vertPosList)):
		mesh.skinIDList[m].append(0)
	mesh.skinList.append(skin)
	g.seek(A[6]+64)
	
	
def section2(A,g,n):
	n+=4
	string=getString(A[0],g)	
	print ' '*n,A,string,A[0]+64
	g.seek(A[10]+64)
	skeleton=Skeleton()
	skeleton.BONESPACE=True
	skeleton.NICE=True
	for m in range(A[9]):
		bone=Bone()
		bone.name=str(m)
		bone.parentID,bone.ID=g.h(2)
		bone.matrix=VectorMatrix(g.f(3))
		g.f(3)
		g.B(4)
		#print ' '*n,value
		skeleton.boneList.append(bone)
	skeleton.draw()	
	
	
	g.seek(A[6]+64)
	"""while(True):
		pos=g.tell()
		B=getHeader(g.tell(),g)
		if B[1]==19:section19(B,g,n)
		else:
			g.seek(pos)
			break"""
			
			
			
		
def section1(A,g,n):
	n+=4
	string=getString(A[0],g)
	print ' '*n,A[1],string,A[0]+64
	g.seek(A[6]+64)
	while(True):
		pos=g.tell()
		B=getHeader(g.tell(),g)
		if B[1]==19:section19(B,g,n)
		#elif B[1]==20:section20(B,g,n)
		else:
			g.seek(pos)
			break
			
	
def fileParser(filename,g):
	global meshList,flag23
	n=0
	meshList=[]
	flag23=False
	
	g.endian='<'
	A=g.i(12)
	g.seek(A[0])
	ListA=[]
	for m in range(A[1]):
		ListA.append(g.i(2))
	for m in range(A[1]):
		g.seek(ListA[m][1])
		print ListA[m]
		if ListA[m][0]==2:
			g.i(1)+g.H(2)+g.f(14)
		if ListA[m][0]==4:
			count=g.i(1)[0]
			g.i(3)
			for n in range(count):				
				g.i(8)
		if ListA[m][0]==7:
			count,offset=g.i(2)
			g.seek(offset)
			offList=g.i(count)
			for i,off in enumerate(offList):
				g.seek(off)
				B=g.i(2)+g.H(4)+g.i(12)
				#print B
				sys=Sys(filename)
				sys.addDir(sys.base+'_files')
				#new=open(sys.dir+os.sep+sys.base+'_files'+os.sep+str(i)+'.dds','wb')
				p.seek(B[7])
				data=p.read(B[8])
				img=imageLib.Image()
				img.szer=B[2]
				img.wys=B[3]
				img.name=sys.dir+os.sep+sys.base+'_files'+os.sep+str(i)+'.dds'
				if B[0]==12:img.format='DXT1'
				if B[0]==14:img.format='DXT5'
				img.data=data
				img.draw()
		
		
		if ListA[m][0]==0:
			pos=g.tell()
			B=g.i(8)
			pos=g.tell()
			C=g.i(13)
			"""print C
			back=g.tell()
			g.seek(C[4]+64)
			count,offset=g.i(2)
			g.seek(offset+64)
			for n in range(count):
				D=g.i(3)
				t=g.tell()
				g.seek(D[1]+64)
				print g.B(4),
				g.seek(D[0]+64)
				print g.find('\x00')
				g.seek(t)
			g.seek(back)
			#C=g.i(1)+g.H(2)+g.i(8)"""
	
			
			#g.seek(C[6]+64)
			while(True):
				pos=g.tell()
				A=getHeader(g.tell(),g)
				if A[1]==19:section19(A,g,n)
				elif A[1]==1:section1(A,g,n)
				elif A[1]==2:section2(A,g,n)
				elif A[1]==12:section12(A,g,n)
				elif A[1]==17:section17(A,g,n)
				elif A[1]==19:section19(A,g,n)
				#elif A[1]==18:section18(A,g,n)
				#elif A[1]==20:section20(A,g,n)
				#elif A[1]==21:section21(A,g,n)
				elif A[1]==23:section23(A,g,n)
				else:
					print 'unknow:',A
					g.seek(pos)
					break
				
	g.debug=True
	g.tell()	
	for mesh in meshList:
		print 'mesh'
		mesh.TRISTRIP=True
		#skin=Skin()
		#mesh.skinList.append(skin)
		#for i,ID in enumerate(mesh.skinIDList):
		#	if ID==None:
		#		print i,ID
		mesh.SPLIT=True
		mesh.draw()
	
def bnlParser(filename,g):
	global fileCount,offset,offset1,offset2
	g.debug=True
	A=g.i(8)
	print A
	offset=A[3]+A[5]+A[7]
	offset1=A[3]
	offset2=A[3]+A[5]
	fileCount=A[3]/160
	g.seek(32)
	g.i(2)
	new=open(filename+'.dec','wb')
	data=g.read(g.fileSize()-g.tell())
	new.write(zlib.decompress(data))
	new.close()
	
	file=open(filename+'.dec','rb')
	g=BinaryReader(file)
	g.logOpen()
	decParser(filename,g)
	g.logClose()
	file.close()
	
		
def decParser(filename,g):
	global offset
	#g.debug=True
	sys=Sys(filename)
	sys.addDir(sys.base)
	sum5=0
	sum7=0
	g.seek(offset)
	g.i(28)
	sum2=0
	for m in range(22):
		A=g.i(4)
		sum2+=A[3]
	print g.tell()+sum2,g.fileSize()	
	g.seek(0)
	for m in range(fileCount):
		name=g.word(128)
		A=g.i(8)
		t=g.tell()
		#print m,name
		#if A[-1]!=0:
		g.seek(offset+A[4])		
		#print m,g.tell(),name
		new=open(sys.dir+os.sep+sys.base+os.sep+name+'.info','wb')
		new.write(g.read(A[5]))
		new.close()
		#offset+=A[7]
		g.seek(offset1+A[6])
		if A[7]>0:
			new=open(sys.dir+os.sep+sys.base+os.sep+name+'.data','wb')
			B=g.i(2)
			print m,B
			for n in range(B[1]):
				off,size=g.i(2)
				tn=g.tell()
				g.seek(offset2+off)
				new.write(g.read(size))
				g.seek(tn)
			new.close()	
		
		g.seek(t)
		sum5+=A[5]
		sum7+=A[7]
	print offset,sum5,sum7,sum5+sum7+offset,g.fileSize()
	
def Parser():	
	global p
	filename=input.filename
	print
	print filename
	print
	
	ext=filename.split('.')[-1].lower()
	if ext=='info':	
		streamFile=open(filename.replace('.info','.data'),'rb')
		p=BinaryReader(streamFile)
		p.logOpen()
		file=open(filename,'rb')		
		g=BinaryReader(file)
		g.logOpen()		
		fileParser(filename,g)
		g.logClose()
		p.logClose()
		file.close()
		streamFile.close()
		
	if ext=='bnl':
		file=open(filename,'rb')
		g=BinaryReader(file)
		bnlParser(filename,g)
		file.close()
		
	if ext=='dec':
		file=open(filename,'rb')
		g=BinaryReader(file)
		decParser(filename,g)
		file.close()
		
 
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
	 
Blender.Window.FileSelector(openFile,'import','rare files') 