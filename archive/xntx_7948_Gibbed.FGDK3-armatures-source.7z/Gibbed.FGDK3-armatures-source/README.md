# Gibbed's FGDK3 Tools

[![Build status](https://ci.appveyor.com/api/projects/status/x15o931j61aew5wa/branch/main?svg=true)](https://ci.appveyor.com/project/gibbed/gibbed-fgdk3/branch/main)
