﻿namespace BLP_Converter
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Threading.Tasks;
    using System.Windows.Forms;

    internal static class Program
    {
        private static string[] nameDB;

        private static Dictionary<string, string> fileTypes = new Dictionary<string, string>()
        {
            { "MC", "0x19" }, { "CL", "0x1A" }, { "-C", "0x08" }, { "-H", "0x17" }, { "HL", "0x18" }, { "-P", "0x09" }
        };

        public static string[] OpenBLP(string fileName)
        {
            List<string> fileEnts = new List<string>();
            int fileCount = 0;
            try
            {
                if (nameDB == null)
                {
                    nameDB = File.ReadAllLines(Path.GetDirectoryName(Application.ExecutablePath) + @"\dlc5lr.dat");
                }

                MemoryStream ms = new MemoryStream();
                using (FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.Read))
                {
                    fs.CopyTo(ms);
                }

                using (BinaryReader br = new BinaryReader(ms))
                {
                    br.BaseStream.Position = 0;
                    if (br.ReadInt32() != 0x46495031)
                    {
                        throw new Exception("Unsupported file format!");
                    }

                    fileCount = br.ReadInt32();
                    int tableOffset = br.ReadInt32();
                    br.BaseStream.Position = tableOffset;
                    for (int i = 0; i < fileCount; i++)
                    {
                        int nameDBPos = br.ReadInt32();
                        if ((nameDBPos > nameDB.Length - 1) || (nameDBPos < 0))
                        {
                            br.BaseStream.Position += 16;
                            continue;
                        }

                        string resolvedName = nameDB[nameDBPos];
                        string fileType = fileTypes[resolvedName.Substring(resolvedName.Length - 2)];
                        int packedSize = br.ReadInt32();
                        int encFlags = br.ReadInt32();
                        int unpackedSize = br.ReadInt32();
                        int checkSum = br.ReadInt32();
                        fileEnts.Add(fileType + "\tchara_dlccos_none\t" + resolvedName + "\t" + packedSize.ToString("X8") + "\t"
                             + encFlags.ToString("X8") + "\t" + unpackedSize.ToString("X8") + "\t" + checkSum.ToString("X8"));
                    }
                }

                int unresolvedEnts = fileCount - fileEnts.Count;
                if (unresolvedEnts > 0)
                {
                    Task.Factory.StartNew(() => { MessageBox.Show("Skipped unknown entries: " + unresolvedEnts.ToString(), "Info"); });
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Error");
            }

            return fileEnts.ToArray();
        }

        [STAThread]
        private static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }
}