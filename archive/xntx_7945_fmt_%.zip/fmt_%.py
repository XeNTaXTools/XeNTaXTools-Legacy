from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("_%", ".VEHC")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)
    noesis.logPopup()
    return 1

SBBHarr = []
VBarr = []
IBarr = []
       
def noepyCheckType(data):
    return 1

def noepyLoadModel(data, mdlList):
    bs = NoeBitStream(data)
    CHNKoffset = [(i+4) for i in findall(b'CHNK', data)]
    
    for offset in CHNKoffset[1:]:
        readCHNK (bs, offset)
    
    importVEHC(bs, mdlList)
    
    #clear buff
    global SBBHarr, VBarr, IBarr
    SBBHarr, VBarr, IBarr = [], [], []
    return 1

def importVEHC(bs, mdlList):
    positions = []
    print("VBarr",len(VBarr))
    print("VBarr",len(IBarr))
    for vb in VBarr:
        bs.seek(vb.offset, NOESEEK_ABS)
        for x in range(vb.numverts):
            v = [float(bs.readShort()/4096) for x in range(4)]
            positions.append(NoeVec3([v[0],v[1],v[2]]))
            bs.seek(vb.stride-8, NOESEEK_REL)
        
    meshes = []
    face = []
    print("SBBHarr",len(SBBHarr))
    for sb in SBBHarr: 
        name = str(sb.dpHash)
        #face = []

        vpad = 0
        for vb in range(1,len(VBarr)):
            if VBarr[vb].vxHash == sb.vxHash:
                while vb > 0:
                    vb -= 1
                    vpad += VBarr[vb].numverts
                    
                break #no need to test the other VBs


        for ib in range(len(IBarr)):
            if IBarr[ib].ixHash == sb.ixHash:
                bs.seek(IBarr[ib].offset + sb.offset*IBarr[ib].indsize, NOESEEK_ABS)
                if IBarr[ib].indsize == 2: 
                    face += [(bs.readUShort()+vpad+ sb.padding) for x in range(sb.count)]

                elif IBarr[ib].indsize == 4: 
                    face += [(bs.readUInt()+vpad+ sb.padding) for x in range(sb.count)]
                break
                
        #mesh = createMesh(face,positions,name)
        #meshes.append(mesh)        
    mdl = NoeModel([NoeMesh(face,positions,name)])
    mdlList.append(mdl)
    return 1
"""  
def createMesh(face,positions,name):
    myPos = []
    myFace = face
    alone = list(set(myFace))
    for j in range(len(alone)):
        for i in range(len(myFace)):
            if alone[j] == myFace[i]:
                myFace[i] = j
                
    for m in alone: 
        myPos.append(positions[int(m)])

    mesh = NoeMesh(myFace,myPos,name)
    return mesh
""" 
def readCHNK (bs, offset):
    aVB = VB()
    aIB = IB()
    bs.seek(offset, NOESEEK_ABS)
    CHNKoffset = offset

    CHNKsize = bs.readUInt()
    CHNKsections = bs.readUInt()
    CHNKparams = bs.readUInt()
    SectArr = []#name,offset,size
        
    for i in range(CHNKsections):
        sectName = noeAsciiFromBytes(bs.readBytes(4))
        sectOffset = bs.readUInt()
        bs.seek(4, NOESEEK_REL)
        sectSize = bs.readUInt()
        bs.seek((CHNKparams - 3)*4, NOESEEK_REL)

        SectArr.append([sectName, (sectOffset + CHNKoffset - 4), sectSize])

    for sect in SectArr:
        readSect(bs,sect,aVB,aIB)
    return 1
    
def readSect(bs,sect,aVB,aIB):
    name,offset,size = sect
    bs.seek(offset, NOESEEK_ABS)

    if name == "SBBH":
        dpHash = bs.readInt64()
        matHash = bs.readInt64()
        vxHash = bs.readInt64()
        bs.seek(8, NOESEEK_REL)
        padding = bs.readUInt()
        bs.seek(12, NOESEEK_REL)
        ixHash = bs.readInt64()
        IBoffset = bs.readUInt()
        Icount = bs.readUInt()
        SBBHarr.append(SBBH(dpHash, matHash, vxHash, padding, ixHash, IBoffset, Icount))
        
    elif name == "VXHD":
        aVB.vxHash = bs.readInt64()
        aVB.numverts = bs.readUInt()
        aVB.stride = bs.readUInt()
        
    elif name == "VXDP":
        aVB.dpHasharr = []
        
        for j in range(int(size/8)):
            aVB.dpHasharr.append(bs.readInt64())
        
    elif name == "VXDT":
        aVB.offset = bs.getOffset()
        
    elif name == "VDCL":
        aVB.vproparr = []
        aVP = vprop()
        numprops = bs.readUInt()
        
        for j in range(numprops):
            aVP.type = bs.readUInt()
            aVP.elmts = bs.readUInt()
            aVP.eltype = bs.readUInt()
            aVP.hash = bs.readInt()

            aVB.vproparr.append(copy.copy(aVP))
        VBarr.append(copy.copy(aVB))
        
    elif name == "IXHD":
        aIB.ixHash = bs.readInt64()
        aIB.numinds = bs.readUInt()
        aIB.indsize = bs.readUInt()
        bs.seek(8, NOESEEK_REL)
        
    elif name == "IXDT":
        aIB.offset = bs.getOffset()
        IBarr.append(copy.copy(aIB)) 
    return 1

def findall(p, s):
    i = s.find(p)
    while i != -1:
        yield i
        i = s.find(p, i+1)
        
#class
class SBBH:
    def __init__(self, dpHash, matHash, vxHash, padding, ixHash, offset, count):
        self.dpHash = dpHash
        self.matHash = matHash
        self.vxHash = vxHash
        self.padding = padding
        self.ixHash = ixHash
        self.offset = offset
        self.count = count
        
class VB:
    def __init__(self, vxHash=0, numverts=0, stride=0, dpHasharr=[], offset=0, vproparr=[]):
        self.vxHash = vxHash
        self.numverts = numverts
        self.stride = stride
        self.dpHasharr = dpHasharr
        self.offset = offset
        self.vproparr = vproparr
        
class IB:
    def __init__(self, ixHash=0, numinds=0, indsize=0, offset=0):
        self.ixHash = ixHash
        self.numinds = numinds
        self.indsize = indsize
        self.offset = offset
        
class vprop:
    def __init__(self, type=0, elmts=0, eltype=0, hash=0):
        self.type = type
        self.elmts = elmts
        self.eltype = eltype
        self.hash = hash
