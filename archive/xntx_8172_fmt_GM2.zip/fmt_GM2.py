#by Durik256 for xentax
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Blood +: One Night Kiss", ".GM2")
    noesis.setHandlerTypeCheck(handle, CheckType)
    noesis.setHandlerLoadModel(handle, LoadModel)
    return 1

def CheckType(data):
    if data[:4] != b'GMF2':
        return 0
    return 1
    
def LoadModel(data, mdlList):
    bs = NoeBitStream(data)
    ctx = rapi.rpgCreateContext()
    
    bs.seek(24)
    bone_num, mesh_num, unk, mat_num = [bs.readUShort() for x in range(4)]
    #0-bone_off;1-tx_off;2-zero;3-mat_off;4-unk;5-submesh_num
    info = [bs.readInt() for x in range(6)]
    
    bs.seek(info[3])
    for x in range(mat_num):
        name = noeAsciiFromBytes(bs.readBytes(8))
        off_prew, off_next = bs.readInt(), bs.readInt()
        unk, offset = bs.readInt(), bs.readInt()
        bs.seek(8,1)
    
    bs.seek(offset + 104)
    mesh_offset = bs.readInt()
    bs.seek(mesh_offset)
    
    print('submesh_count:', info[5])
    
    #possible false offset
    result = [(mesh_offset+i+16) for i in findall(b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x80', data[mesh_offset:])]
 
    for x in result:
        bs.seek(x)
        count = bs.readUInt()
        bs.seek(12,1)
        
        #weed out false offset
        if count<100 and count>0:
            vbuf = bs.readBytes(count*64)
            ibuf = autoTriangles(count)
            
            rapi.rpgBindPositionBuffer(vbuf, noesis.RPGEODATA_FLOAT, 64)
            rapi.rpgCommitTriangles(ibuf, noesis.RPGEODATA_USHORT, len(ibuf)//2, noesis.RPGEO_TRIANGLE_STRIP)
            #rapi.rpgCommitTriangles(None, noesis.RPGEODATA_USHORT, count, noesis.RPGEO_POINTS)
        
        bs.seek(16,1)
    
    mdl = rapi.rpgConstructModel()
    mdlList.append(mdl)
    return 1
    
def autoTriangles(vcount):
    ibuf = b''
    for x in range(vcount):
        ibuf +=(x).to_bytes(2, 'little')
    return ibuf

def findall(p, s):
    i = s.find(p)
    while i != -1:
        yield i
        i = s.find(p, i+1)