import newGameLib
from newGameLib import *
import Blender	

def parseType(g,n):
	flag=True
	t=g.tell()
	unk,hash,size=g.i(3)
	write(txt,[unk,hash,size],n)
	n+=4
	if unk==1:
		g.i(1)[0]
		localSize=16
		while(True):
			localSize+=parseType(g,n)			
			if localSize>=size:break
		g.seek(t+4+size)
		write(txt,[g.tell()],n)
		print unk,hash,size,g.tell()
	return size	

def nxmParser1(filename,g):
	n=0
	#parseType(g,n)
	g.i(4)
	g.i(4)
	g.i(3)
	g.f(50)
	g.B(1)
	g.word(g.i(1)[0])
	g.i(2)
	g.i(4)
	g.i(4)
	g.i(3)
	g.f(50)
	g.B(1)
	g.word(g.i(1)[0])
	g.i(4)
	g.i(3)
	g.i(3)
	g.i(4)
	g.i(4)
	g.i(4)
	g.i(4)
	g.i(4)
	g.i(3)
	g.i(4)
	g.i(2)
	g.B(49)
	g.i(2)
	g.B(230)
	g.i(5)
	g.i(2)
	g.B(8)
	g.i(2)
	g.B(28942-8)
	g.i(2)
	g.B(26071-8)
	g.i(2)
	g.B(5288-8)
	g.i(50)

def parseHash1(g,n):
	flag=True
	t=g.tell()
	hash,size=g.i(2)
	write(txt,[t,':',hash,size],n)
	n+=4
	if hash==1358766115:
		unk1,unk2=g.i(2)
		#for m in range(unk2):
		parseHash(g,n)#==False#:break
	elif hash==1358311440:
		unk1,unk2=g.i(2)
		#for m in range(unk2):
		parseHash(g,n)#==False#:break
	elif hash==1358249996:
		g.seek(t+size)
		parseHash(g,n)
	elif hash==1358249997:
		unk1,unk2=g.i(2)
		#for m in range(unk1):
		if size>12:
			parseHash(g,n)#==False#:break
		g.seek(t+size)
		parseHash(g,n)
	elif hash==1358249998:
		unk1,unk2=g.i(2)
		#for m in range(unk1):
		if size>12:
			parseHash(g,n)#==False#:break
		g.seek(t+size)
		parseHash(g,n)
	else:
		flag=False
	return flag	
		
	#g.i(10)	
	
def getLoop(hash,size,g,n,model,parentBoneName):
	parentName=parentBoneName
	if hash==1358766115:
		loop1358766115(size,g,n,model,parentName)
	elif hash==1358249996:
		m1=Matrix4x4(g.f(16))
		m2=Matrix4x4(g.f(16))
		m3=Matrix4x4(g.f(16))
		write(txt,m1,n+4)
		write(txt,m2,n+4)
		write(txt,m3,n+4)
		g.f(2)
		#A=g.f(50)
		#write(txt,[A],n+4)
		A=g.B(1)[0]
		#write(txt,[A],n+4)
		A=g.word(g.i(1)[0])
		print A,parentName
		bone=Bone()
		bone.matrix=m3#.invert()
		bone.parentName=parentName
		bone.name=A
		model.skeleton.boneList.append(bone)
		parentName=A
		write(txt,[A],n)
		
		n+=4	
		while(True):
			count=g.i(1)[0]
			write(txt,[count],n)
			t=g.tell()
			hash,size1=g.i(2)
			write(txt,[t+8,":",hash,size1,t+size1],n)
			if size1>=8:
				getLoop(hash,t+size1,g,n,model,parentBoneName)
			g.seek(t+size1)
			if g.tell()>=size:break	
		
		
	elif hash==1358315544000:
		A=g.B(6)
		#write(txt,[A],0)
		#A=g.word(g.i(1)[0])
		#write(txt,[A],0)
		
		n+=4	
		while(True):
			count=g.i(1)[0]
			write(txt,[count],n)
			t=g.tell()
			hash,size1=g.i(2)
			write(txt,[t+8,":",hash,size1,t+size1],n)
			if size1>=8:
				getLoop(hash,t+size1,g,n,model,parentBoneName)
			g.seek(t+size1)
			if g.tell()>=size:break	
		
		
	elif hash==1358315540:
		A=g.i(3)
		#g.H(1000)
		if model.mesh:model.mesh.indiceList=g.H(A[1])
		
	elif hash==1369964687:
		#write(txt,[g.tell(),g.i(3)],n)
		#write(txt,[g.tell(),g.f(30)],n)
		A=g.i(3)
		for m in range(A[0]/A[2]):
			model.mesh.vertPosList.append(g.f(3))	
		A=g.i(3)
		A=g.i(3)
		for m in range(A[0]/A[2]):
			model.mesh.vertUVList.append(g.f(2))	
		A=g.i(3)
		for m in range(A[0]/A[2]):
			model.mesh.skinWeightList.append(g.B(2))
		#mesh.draw()	
		
	elif hash==1358311440:
		parentName=loop1358311440(size,g,n,model,parentName)
	elif hash==1358249997:
		loop1358249997(size,g,n,model,parentName)
	elif hash==1358249998:
		loop1358249998(size,g,n,model,parentName)
	elif hash==1358315537:
		loop1358315537(size,g,n,model,parentName)
	elif hash==1358315541:
		loop1358315541(size,g,n,model,parentName)
	elif hash==1358319641:
		loop1358319641(size,g,n,model,parentName)
	elif hash==1369964687:
		write(txt,[g.tell(),g.i(3)],n)
	else:
		pass#print 'unknow hash:',hash
	return parentName	
	
	
def loop1358319641(offset,g,n,model,parentBoneName):
	unk1,unk2,count=g.i(3)
	write(txt,[unk1,unk2,count],n)
	n+=4	
	for m in range(count):
		t=g.tell()
		hash,size=g.i(2)
		write(txt,[t,':',"hash:",hash,"size:",size,"end offset:",t+size,"end parent offset:",offset],n)
		if size>12:
			getLoop(hash,t+size,g,n,model,parentBoneName)
		g.seek(t+size)
		
def xxxloop1358319641(offset,g,n,model,parentBoneName):
	unk1=g.i(1)[0]
	unk2=g.i(1)[0]
	write(txt,[unk1,unk2],n)
	n+=4		
	while(True):
		count=g.i(1)[0]
		write(txt,[count],n)
		for m in range(count):
			t=g.tell()
			hash,size=g.i(2)
			write(txt,[t,':',"hash:",hash,"size:",size,"end offset:",t+size,"end parent offset:",offset],n)
			if size>=8:
				getLoop(hash,t+size,g,n,model,parentBoneName)
			g.seek(t+size)
		if g.tell()>=offset:break	
	
def loop1358315541(offset,g,n,model,parentBoneName):
	n+=4
	model.mesh=Mesh()	
	while(True):
		count=g.i(1)[0]
		write(txt,[count],n)
		for m in range(count):
			t=g.tell()
			hash,size=g.i(2)
			write(txt,[t,':',"hash:",hash,"size:",size,"end offset:",t+size,"end parent offset:",offset],n)
			if size>12:
				getLoop(hash,t+size,g,n,model,parentBoneName)
			g.seek(t+size)
		if g.tell()>=offset:break	
		
	
def loop1358315537(offset,g,n,model,parentBoneName):
	unk,count=g.i(2)
	write(txt,[unk,count],n)
	n+=4	
	for m in range(count):
		t=g.tell()
		hash,size=g.i(2)
		write(txt,[t,':',"hash:",hash,"size:",size,"end offset:",t+size,"end parent offset:",offset],n)
		if size>12:
			getLoop(hash,t+size,g,n,model,parentBoneName)
		g.seek(t+size)
	
def loop1358766115(offset,g,n,model,parentBoneName):
	unk,count=g.i(2)
	write(txt,[unk,count],n)
	n+=4	
	for m in range(count):
		t=g.tell()
		hash,size=g.i(2)
		write(txt,[t,':',"hash:",hash,"size:",size,"end offset:",t+size,"end parent offset:",offset],n)
		if size>12:
			getLoop(hash,t+size,g,n,model,parentBoneName)
		g.seek(t+size)
		
	
def xxxloop1358311440(offset,g,n,model,parentBoneName):
	unk,count=g.i(2)
	write(txt,[unk,count],n)
	n+=4	
	parentName=parentBoneName
	for m in range(count):
		t=g.tell()
		hash,size=g.i(2)
		write(txt,[t,':',"hash:",hash,"size:",size,"end offset:",t+size,"end parent offset:",offset],n)
		if size>12:
			parentName=getLoop(hash,t+size,g,n,model,parentName)
		g.seek(t+size)
	write(txt,["parentName:",parentName],n)
	return 	parentName
		
		
def loop1358311440(offset,g,n,model,parentBoneName):
	unk,count=g.i(2)
	write(txt,[unk,count],n)
	n+=4	
	parentName=parentBoneName	
	while(True):
	#for m in range(count):
		t=g.tell()
		hash,size=g.i(2)
		write(txt,[t,':',"hash:",hash,"size:",size,"end offset:",t+size,"end parent offset:",offset],n)
		if size>12:
			parentName=getLoop(hash,t+size,g,n,model,parentName)
		g.seek(t+size)
		if g.tell()>=offset:break
	write(txt,["parentName:",parentName],n)
	#if g.tell()<g.fileSize()-16:
	#	write(txt,g.i(3),n)
	return 	parentName
	
def loop1358249997(offset,g,n,model,parentBoneName):
	unk=g.i(1)[0]
	write(txt,[unk],n)
	n+=4		
	while(True):
		count=g.i(1)[0]
		write(txt,[count],n)
		for m in range(count):
			t=g.tell()
			hash,size=g.i(2)
			write(txt,[t,':',"hash:",hash,"size:",size,"end offset:",t+size,"end parent offset:",offset],n)
			if size>=8:
				getLoop(hash,t+size,g,n,model,parentBoneName)
			g.seek(t+size)
		if g.tell()>=offset:break	
		
	
def loop1358249998(offset,g,n,model,parentBoneName):
	n+=4	
	while(True):
		count=g.i(1)[0]
		write(txt,[count],n)
		for m in range(count):
			t=g.tell()
			hash,size=g.i(2)
			write(txt,[t,':',"hash:",hash,"size:",size,"end offset:",t+size,"end parent offset:",offset],n)
			if size>=8:
				getLoop(hash,t+size,g,n,model,parentBoneName)
			g.seek(t+size)
		if g.tell()>=offset:break	
		
		
def nxmParser(filename,g):

	count=g.i(1)[0]
	n=0
	class Model:pass
	model=Model()
	model.mesh=None
	model.skeleton=Skeleton()
	model.skeleton.ARMATURESPACE=True
	model.skeleton.NICE=True
	parentBoneName=None
		
	for m in range(count):
		hash,size=g.i(2)
		write(txt,[hash,size],n)
		getLoop(hash,size,g,n,model,parentBoneName)
	model.skeleton.draw()
	
	if model.mesh:
		model.mesh.TRIANGLE=True
		model.mesh.BINDSKELETON=model.skeleton.name
		model.mesh.draw()
	
	print g.tell()
	
def Parser(filename):
	global txt
	#os.system('cls')
	txt=open("log.txt","w")
	sys=Sys(filename)
	if sys.ext=='nxm':sys.parseFile(nxmParser,'rb',log=0)
	txt.close()
 
 
	
Blender.Window.FileSelector(Parser,'import','.nxm' ) 
	