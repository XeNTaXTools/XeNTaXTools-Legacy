from inc_noesis import *
import os

def registerNoesisTypes():
	handle = noesis.register("S4 lol model",".scn")
	noesis.setHandlerTypeCheck(handle, CheckModelType)
	noesis.setHandlerLoadModel(handle, LoadModel)
	return 1
# =================================================================
# Noesis check type
# =================================================================

def CheckModelType(data):
	bs = NoeBitStream(data)
	if len(data) < 16:
		print("Invalid scn file, too small")
		return 0
	return 1
	
# =================================================================
# Misc
# =================================================================

# =================================================================
# GLG helper classes
# =================================================================

def LoadModel(data, mdlList):
	
	ctx = rapi.rpgCreateContext()
	
	bs = NoeBitStream(data)
	bs.setEndian(NOE_LITTLEENDIAN)
	
	
	offsets = []
	while(bs.tell() + 1 <= bs.getSize()):
		i = bs.readUByte()
		if i == 248 and bs.tell() + 1 <= bs.getSize():
			k = bs.readUByte()
			if k == 152 and bs.tell() + 1 <= bs.getSize():
				l = bs.readUByte()
				if l == 16 and bs.tell() + 1 <= bs.getSize():
					u = bs.readUByte()
					if u == 8 and bs.tell() + 1 <= bs.getSize():
						offsets.append(bs.tell())					
	for i,offset in enumerate(offsets):
		bs.seek(offset)
		name = bs.readString()
		bs.readString()
		bs.read("20f")
		count = bs.readUInt()
		bs.readUInt()
		bs.readBytes(1024+1028)
		bs.readUInt()
		vertexCount = bs.readUInt()
		vertexBuff = bs.readBytes(vertexCount*3*4)
		faceCount = bs.readUInt()
		idxBuff = bs.readBytes(faceCount*3*2)
		bs.readUInt()
		normBuff = bs.readBytes(vertexCount*3*4)
		bs.readUInt()
		uvBuff = bs.readBytes(vertexCount*2*4)
		
		meshName = name
		rapi.rpgSetName(meshName)
		rapi.rpgBindPositionBuffer(vertexBuff, noesis.RPGEODATA_FLOAT, 12)
		rapi.rpgBindNormalBuffer(normBuff, noesis.RPGEODATA_FLOAT, 12)
		rapi.rpgBindUV1Buffer(uvBuff, noesis.RPGEODATA_FLOAT, 8)
		rapi.rpgCommitTriangles(idxBuff, noesis.RPGEODATA_USHORT, faceCount*3, noesis.RPGEO_TRIANGLE, 1)
		
	
	
	try:
		mdl = rapi.rpgConstructModel()
	except:
		mdl = NoeModel()
	mdlList.append(mdl)
		
	return 1
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
		
		
		