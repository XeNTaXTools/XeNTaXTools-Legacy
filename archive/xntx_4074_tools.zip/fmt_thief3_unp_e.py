from inc_noesis import *
import noesis
import rapi

from datetime import datetime
import string
import os
import re

# debug level 1/2/3 and etc
DEBUG = 0
# game name
GAMEID = 'Thief 3 ASCII tim2e'
# first bytes for each extensions, if eq b'' open without check
IDBYTES = {'e': b''}


def registerNoesisTypes():
    handle = noesis.register(GAMEID, ';'.join('.' + e for e in IDBYTES.keys()))
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)
    if DEBUG:
        noesis.logPopup()
        print("\n", datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
        print("----------------------------------------------------------------------------------------")
    return 1


def noepyCheckType(data):
    extension = rapi.getLocalFileName(rapi.getInputName()).split('.')[-1]
    if len(data) < 4 or not extension in IDBYTES:
        return 0
    size = len(IDBYTES[extension])
    if size != 0 and NoeBitStream(data).readBytes(size) != IDBYTES[extension]:
        return 0
    return 1


def noepyLoadModel(data, mdlList):
    if DEBUG:
        print("\n", datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
        print(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")

    ctx = rapi.rpgCreateContext()
    # rapi.rpgSetOption(noesis.RPGOPT_TRIWINDBACKWARD, 1)
    rapi.setPreviewOption("setAngOfs", "0 120 0")

    f = open(rapi.getInputName(), 'r')
    parser = ModelParser(f)
    parser.parseModel()
    f.close()

    try:
        mdl = rapi.rpgConstructModel()
    except:
        mdl = NoeModel([], [], [])

    mdl.setModelMaterials(NoeModelMaterials(parser.texList, parser.matList))
    mdl.setBones(parser.boneList)
    mdl.setAnims(parser.animList)
    mdlList.append(mdl)
    rapi.rpgClearBufferBinds()
    return 1


class Node:
    def __init__(self):
        self.type = None
        self.children = []
        self.data = {}
        self.name = None


class Mesh():
    def __init__(self):
        self.name = None
        self.material = None
        self.vertList = []
        self.normList = []
        self.uvList = []
        self.idxList = []
        self.skinWList = []
        self.skinIList = []


class Material:
    def __init__(self):
        self.id = None
        self.name = None
        self.diffuse = None
        self.normal = None
        self.specular = None


class Bone:
    def __init__(self):
        self.ID = None
        self.name = None
        self.parentID = None
        self.parentName = None
        self.matrix = None
        self.children = []


class Skeleton:
    def __init__(self):
        self.boneList = []
        self.boneNameList = []


class ModelParser(object):
    def __init__(self, data):
        self.inFile = data
        self.fileName = self.inFile.name
        self.fileBaseName = rapi.getLocalFileName(self.inFile.name).split('.')[0]
        self.fileExtension = rapi.getLocalFileName(self.inFile.name).split('.')[-1]
        self.folderName = rapi.getDirForFilePath(self.inFile.name)
        self.meshList = []
        self.boneList = []
        self.animList = []
        self.texList = []
        self.matList = []

    def _plotPoints(self, numVerts):
        rapi.rpgCommitTriangles(None, noesis.RPGEODATA_USHORT, numVerts, noesis.RPGEO_POINTS, 1)

    def _parseFile(self):
        nodeList = []
        currentNode = None
        currentSection = None
        sections = {'COMMENT': re.compile("^\\s*COMMENT\\s*{?", re.IGNORECASE),
                    'MATERIALS': re.compile("^\\s*MATERIALS\\s*{?", re.IGNORECASE),
                    'POINTS': re.compile("^\\s*POINTS\\s*{?", re.IGNORECASE),
                    'PARTS': re.compile("^\\s*PARTS\\s*{?", re.IGNORECASE),
                    'PART_MAPPINGS': re.compile("^\\s*PART_MAPPINGS\\s*{?", re.IGNORECASE)}
        for l in self.inFile.readlines():
            l = l.strip()
            if len(l) == 0 or re.match("^\\s*[//|}]", l):
                continue
            if re.match("^\\s*END", l):
                break
            if re.match("^\\s*BEGIN", l):
                currentNode = Node()
                currentNode.name = l.split(None, 1)[1].strip('"')
                nodeList.append(currentNode)
                continue
            if currentNode is None:
                continue
            lineParsed = False
            for s in sections.keys():
                if re.match(sections[s], l.strip()):
                    currentNode.data[s] = []
                    currentSection = s
                    lineParsed = True
                    break
            if lineParsed or currentSection is None:
                continue
            currentNode.data[currentSection].append(l)

        return nodeList

    def _readMaterial(self, data):
        materials = {}

        folder = self.fileName.lower().split('staticmeshes')[0] + os.sep + 'textures' + os.sep
        if not os.path.isdir(folder):
            folder = self.folderName + os.sep + 'textures' + os.sep
            if not os.path.isdir(folder):
                folder = self.folderName + os.sep

        for l in data:
            material = Material()
            (material.id, material.name, method, stream, tail) = l.split(',', 4)
            diffuse = stream.split('TMAP')
            if len(diffuse) == 2:
                material.diffuse = folder + diffuse[1].strip(' "').split(".")[0] + ".dds"
            materials[material.id] = material
        return materials

    def _readPoints(self, data):
        points = []
        for l in data:
            p = l.split(',', 2)
            p = [float(s.strip(" ;")) for s in p]
            points.append(p)
        return points

    def _readParts(self, data):
        parts = {}
        for l in data:
            p = l.split(',', 6)
            p = [s.strip(" ();") for s in p]
            key = int(p[3], 16)
            if not key in parts:
                parts[key] = {}
            parts[key][int(p[2])] = [int(p[4]), int(p[5]), int(p[6])]
        return parts

    def _readMappings(self, data):
        mapping = {}
        for l in data:
            m = l.split(',', 6)
            m = [s.strip(" ();") for s in m]
            mapping[int(m[0])] = [float(m[1]), float(m[2]), float(m[3]), float(m[4]), float(m[5]), float(m[6])]
        return mapping

    def parseModel(self):
        nodeList = self._parseFile()
        # print(nodeList[0].__dict__)
        if len(nodeList) < 1:
            return

        materials = self._readMaterial(nodeList[0].data['MATERIALS'])
        for k in materials:
            material = NoeMaterial(materials[k].name, materials[k].diffuse)  # material.setTexture(materials[k].diffuse)
            self.matList.append(material)

        points = self._readPoints(nodeList[0].data['POINTS'])
        b = bytearray()
        for p in points:
            b += struct.pack('f' * len(p), *p)
        rapi.rpgBindPositionBufferOfs(b, noesis.RPGEODATA_FLOAT, 12, 0)

        uv = [[0, 0] for c in range(len(points))]
        mapping = self._readMappings(nodeList[0].data['PART_MAPPINGS'])
        parts = self._readParts(nodeList[0].data['PARTS'])
        for k in parts.keys():
            for p in parts[k].keys():
                uv[parts[k][p][0]] = [mapping[p][0], mapping[p][1]]
                uv[parts[k][p][1]] = [mapping[p][2], mapping[p][3]]
                uv[parts[k][p][2]] = [mapping[p][4], mapping[p][5]]

        b = bytearray()
        for e in uv:
            b += struct.pack('f' * len(e), *e)
        rapi.rpgBindUV1BufferOfs(b, noesis.RPGEODATA_FLOAT, 8, 0)

        for k in sorted(parts.keys()):
            rapi.rpgSetName("mesh" + str(k))
            rapi.rpgSetMaterial(materials[str(k)].name)
            b = bytearray()
            for p in sorted(parts[k].keys()):
                b += struct.pack('H' * len(parts[k][p]), *parts[k][p])
            rapi.rpgCommitTriangles(b, noesis.RPGEODATA_USHORT, len(parts[k]) * 3, noesis.RPGEO_TRIANGLE, 1)