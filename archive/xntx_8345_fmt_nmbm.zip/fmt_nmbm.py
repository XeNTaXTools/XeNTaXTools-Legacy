from inc_noesis import *
import os

#Version 0.6

# =================================================================
# Plugin Options
# =================================================================

bLoadAnim = True # Enable anim loading
bLoadAllVariations = True #If set to True, will autodetect and load color swaps

# =================================================================
# Miscenalleous
# =================================================================

def registerNoesisTypes():
	handle = noesis.register("Disgaea 6",".nmbm")
	noesis.setHandlerTypeCheck(handle, CheckType)
	noesis.setHandlerLoadModel(handle, LoadModel)	
	handle = noesis.register("NLTX", ".nltx")
	noesis.setHandlerTypeCheck(handle, CheckTexType)
	noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
	return 1
	
def CheckType(data):
	bs = NoeBitStream(data)
	if bs.readUInt() == 0x424d4e:
		return 1
	print("Invalid magic")
	return 0

def CheckTexType(data):
	bs = NoeBitStream(data)
	if bs.readBytes(8) == b"NMPLTEX1": 
		return 1
	return 0

# =================================================================
# Classes
# =================================================================

class Submesh:
	def __init__(self):
		self.id = None
		self.matIndex = None
		self.vCount = None
		self.vOffset = None
		self.idxCount = None
		self.idxOffset = None
		self.idxWidth = None
		self.flags = None
		
	def parse(self,bs):
		self.id = bs.readUInt()
		bs.readUInt()
		self.matIndex = bs.readUInt()
		bs.readUInt()
		self.vOffset = bs.readUInt()
		self.vCount = bs.readUInt()
		self.idxOffset = bs.readUInt()
		self.idxCount = bs.readUInt()
		self.idxWidth = bs.readUInt()
		bs.read('6f') #probably bounding box info
		bs.read('4f')
		self.flags = bs.readUInt()

# =================================================================
# Textures
# =================================================================

def parseNLTX(bs, name):
	bs.readBytes(8)
	unk8 = bs.readBytes(8)
	unk10 = bs.readBytes(4)
	format = bs.readUByte()
	unk15 = bs.readByte()
	unk16 = bs.readUShort()
	width, height = bs.readUInt(), bs.readUInt()
	unk20 = bs.readUInt()
	unk24 = bs.readUByte()
	mipCount = bs.readUByte()
	bs.readBytes(6)
	decompSize = bs.readUInt()
	compSize = bs.readUInt()
	dataOffset = bs.readUInt()
	# blockHeight = 1 << bs.readUByte()
	# blockWidth = 1 << bs.readUByte()

	bs.seek(dataOffset)
	
	#YKCMP_V1
	bs.readBytes(0x14) #already known info
	compData = bs.readBytes(compSize-0x14)
	textureData = rapi.decompLZ4(compData, decompSize)
	# print(format)
	if format == 2:
		format = noesis.NOESISTEX_DXT1
	elif format == 3:
		format = noesis.NOESISTEX_DXT5
	elif format == 6:
		format = noesis.FOURCC_BC7
	
	blockWidth = blockHeight = 4
	maxBlockHeight = 8
	blockSize = 16 if format == noesis.NOESISTEX_DXT1 else 16
	maxBlockHeight = 4 if width <= 128 or height <= 128 else maxBlockHeight
	maxBlockHeight = 2 if width <= 32 or height <= 32 else maxBlockHeight
	widthInBlocks = (width  + (blockWidth - 1)) // blockWidth
	heightInBlocks = (height + (blockHeight - 1)) // blockHeight
	textureData = rapi.callExtensionMethod("untile_blocklineargob", textureData, widthInBlocks,  heightInBlocks, blockSize, maxBlockHeight)
	# print(len(textureData))
	textureData = rapi.imageDecodeDXT(textureData, width, height, format)
	texture = NoeTexture(name, width, height, textureData, noesis.NOESISTEX_RGBA32)
	return texture

def noepyLoadRGBA(data, texList):
	bs = NoeBitStream(data)
	rapi.processCommands('-texnorepfn')
	name = rapi.getLocalFileName(rapi.getInputName())[:-5]+".dds"
	texList.append(parseNLTX(bs,name))
	return 1

# =================================================================
# Animation
# =================================================================

def parseTIMEChunk(bs):
	checkpoint1 = bs.tell()
	bs.seek(0x10,1)
	framerate = bs.readFloat()
	timingCount = bs.readUInt()
	
	bs.seek(checkpoint1+0x20)
	timings = []
	for _ in range(timingCount):
		timings.append(bs.readFloat())
	return [timings, framerate]

def parseTRSAChunk(bs, boneMap, timings, framerate, jointList):
	checkpoint1 = bs.tell()
	bs.seek(0x14,1)
	nodeCount = bs.readUInt()
	
	bs.seek(checkpoint1+0x1C)
	
	keyframedJointList = []
	
	for _ in range(nodeCount):
		checkpoint2 = bs.tell()
		id = bs.readUInt()
		bs.read('6i')
		print(bs.tell())
		offsetToNext = bs.readUInt()
		if id not in boneMap: #Only care about actual deforming bones
			bs.seek(checkpoint2+offsetToNext)
			continue
		
		rotNoeKeyFramedValues = []
		posNoeKeyFramedValues = []
		scaleNoeKeyFramedValues = []
		
		for i in range(5):
			checkpoint3 = bs.tell()
			size = bs.readUInt()
			semantic = bs.readUShort()
			keyframeCount = bs.readUShort()
			unk = bs.readUInt()
			values = []
			for j in range(keyframeCount):
				unk2 = bs.readUInt()
				values.append(NoeVec3(bs.read('3f')))
				bs.readFloat()
			bs.seek(checkpoint3 + size)
			
			for timing, value in zip(timings, values):
				if semantic == 0xE:
					scaleNoeKeyFramedValues.append(NoeKeyFramedValue(timing/framerate,value))
				elif semantic == 0xF:
					value = (NoeAngles([value[0], value[1], value[2]]).toDegrees().toMat43()).toQuat()
					rotNoeKeyFramedValues.append(NoeKeyFramedValue(timing/framerate,value))
				# elif semantic == 0x10:
					# posNoeKeyFramedValues.append(NoeKeyFramedValue(timing/framerate,value))
			
		actionBone = NoeKeyFramedBone(boneMap[id])
		if len(posNoeKeyFramedValues)>0:
			actionBone.setTranslation(posNoeKeyFramedValues, noesis.NOEKF_TRANSLATION_VECTOR_3)
		if len(scaleNoeKeyFramedValues)>0:
			actionBone.setScale(scaleNoeKeyFramedValues, noesis.NOEKF_SCALE_VECTOR_3)
		if len(rotNoeKeyFramedValues)>0:
			actionBone.setRotation(rotNoeKeyFramedValues, noesis.NOEKF_ROTATION_QUATERNION_4)	
		keyframedJointList.append(actionBone)
		
		bs.seek(checkpoint2+offsetToNext)
		
	anim = NoeKeyFramedAnim("anim", jointList, keyframedJointList, framerate)
	return anim

def parseNMAFile(bs, boneMap, jointList):
	bs.seek(0x20) #jump to first chunk
	bIsChunkEOFC = False
	timings = []
	animList = []
	framerate = -1
	while not bIsChunkEOFC and bs.tell() < bs.getSize():
		checkpoint = bs.tell()
		
		chunkMagic, chunkVersion, chunkSize, unk0C = bs.read('4i')
		chunkHeaderSize, headerlessChunkSize, unk18, unk1C = bs.read('4i')
		bs.seek(checkpoint+chunkHeaderSize)
		
		if chunkMagic == 0x43464f45: #EOFC
			bIsChunkEOFC = True
			continue
		elif chunkMagic == 	0x454d4954: #TIME
			timings, framerate = parseTIMEChunk(bs)
		elif chunkMagic	== 0x41535254: #TRSA
			animList.append(parseTRSAChunk(bs, boneMap, timings, framerate, jointList))
			
		bs.seek(checkpoint + chunkSize)
		
	return [animList, framerate]

# =================================================================
# Model
# =================================================================

def parseMATEChunk(bs):
	checkpoint1 = bs.tell()
	bs.seek(0x14,1)
	materialCount = bs.readUInt()
	
	bs.seek(checkpoint1+0x24)
	textureList = []
	materialList = [[]]
	bModelCountDone = False
	modelCount = 1
	alreadyLoadedTexture = {}
	rapi.processCommands('-texnorepfn')
	
	for i in range(materialCount):
		bMatAdded = False
		if len(materialList[0]) < i: #dumb hack in case first mats didn't have samplers
			for mat in materialList:
				mat.append(NoeMaterial("",""))
		checkpoint2 = bs.tell()
		# print(bs.tell())
		id = bs.readUInt()
		bs.readBytes(4)
		nameOffset = bs.readUInt()
		bs.readBytes(8)
		matOffset = bs.readUInt()
		bs.readBytes(8)
		
		bs.seek(checkpoint1 + nameOffset)
		name = bs.readString()
		
		bs.seek(checkpoint1 + matOffset + 0xC)
		propCount = bs.readUInt()
		
		for j in range(propCount):
			valueCount, propNameOffset = bs.read('2i')
			valueCount -= 4
			checkpoint3 = bs.tell()
			bs.seek(checkpoint1 + propNameOffset)
			propName = bs.readString()
			bs.seek(checkpoint3)
			
			if "Sampler" in propName:
				# print(propName)
				samplerNameOffset = bs.readUInt()
				bs.seek(checkpoint1 + samplerNameOffset)
				samplerName = bs.readString()
				bs.seek(checkpoint3 + 0x4)
				# print(samplerName.lower())
				texFileName = rapi.getDirForFilePath(rapi.getInputName()) + os.sep + samplerName.lower()
				localName = samplerName.lower()
				
				#scanning for texture variations
				if not bModelCountDone and bLoadAllVariations:
					try:
						tempName = localName.split('_')[0] +'_' + str(int(localName.split('_')[1])+1).zfill(len(localName.split('_')[1]))+'_' + '_'.join(localName.split('_')[2:])
						fullName = rapi.getDirForFilePath(rapi.getInputName()) + os.sep + tempName				
						while tempName != localName:
							if not rapi.checkFileExists(fullName):
								break
							modelCount+=1
							tempName = tempName.split('_')
							tempName = tempName[0] +'_' + str(int(tempName[1])+1).zfill(len(tempName[1]))+'_' + '_'.join(tempName[2:])
							fullName = rapi.getDirForFilePath(rapi.getInputName()) + os.sep + tempName					
						bModelCountDone = True
						materialList = [[] for _ in range(modelCount)] #in case first mats didn't have samplers
						print("Detected " + str(modelCount) + " variations")
					except:
						pass
				if not bMatAdded: #make sure material wasn't already added
					for mat in materialList:		
						material = NoeMaterial('material_' + str(i), "")
						mat.append(material)
					bMatAdded = True
				if rapi.checkFileExists(texFileName):
					name = samplerName.lower()[:-5]+".dds"
					texFileNames = []
					names = []
					try:
						for i in range(modelCount):					
							tempName = localName.split('_')[0] +'_' + str(int(localName.split('_')[1])+i).zfill(len(localName.split('_')[1]))+'_' + '_'.join(localName.split('_')[2:])
							fullName = rapi.getDirForFilePath(rapi.getInputName()) + os.sep + tempName
							texFileNames.append(fullName)
							names.append(tempName[:-5]+".dds")
					except:
						names.append(name)
						texFileNames.append(texFileName)	
					if name not in alreadyLoadedTexture:
						for texFileName, name in zip(texFileNames, names):
							textureList.append(parseNLTX(NoeBitStream(rapi.loadIntoByteArray(texFileName)), name))
						alreadyLoadedTexture[name] = True
					if propName == "AlbedoSampler":
						for mat, name in zip(materialList, names):
							mat[-1].setTexture(name)
					elif propName == "NormalSampler":
						for mat, name in zip(materialList, names):
							mat[-1].setNormalTexture(name)
			else:
				bs.read(str(valueCount)+'i')
				if bMatAdded: #make sure material wasn't already added
					for mat in materialList:		
						material = NoeMaterial('material_' + str(i), "")
						mat.append(material)
					bMatAdded = True
		bs.seek(checkpoint2 + 0x30)
	return [textureList, materialList]

def parseNODEChunk(bs):
	checkpoint1 = bs.tell()
	bs.seek(0x14,1)
	nodeCount = bs.readUShort()
	bs.seek(checkpoint1+0x20)
	jointList = []
	boneMap = {} #used to remap ids instead of using names 
	boneIDToInfo = {} #prevent edge case of deforming bones parented to non deforming ones
	addedIDs = {}
	toUpdateJointIDs = {}
	
	for node in range(nodeCount):
		checkpoint2 = bs.tell()
		id = bs.readUShort() #joint ID
		flags = bs.readUShort()
		nameOffset = bs.readUInt()
		unk0C = bs.readInt()
		parentID = bs.readInt() #parent ID
		bs.read('4f') #skipping info for now
		bs.read('3f') #scale, seems to be always 1, skipping for now
		unk = bs.read('4f') #seems to be always 0 0 0 1, quat too ?
		pos = bs.read('3f')  
		quat = bs.read('4f')
		boneMatrix = NoeQuat(quat).toMat43().transpose() #rotation
		boneMatrix[3] = NoeVec3(pos) #translation
		bs.seek(checkpoint2 + nameOffset)
		name = bs.readString()
		boneIDToInfo[id] = [name, boneMatrix, parentID]		
		if unk0C != -1:
			addedIDs[id] = True
			boneMap[id] = unk0C
			jointList.append(NoeBone(unk0C, name, boneMatrix, None, boneMap[parentID] if parentID in boneMap else -1)) #cause root has a parent that's not a deforming bone
			if parentID not in boneMap:
				toUpdateJointIDs[id] = len(jointList)-1
		bs.seek(checkpoint2 + 0xA0 if unk0C == -1 else checkpoint2 + 0xE0)
	
	for id in toUpdateJointIDs:
		name, boneMatrix, parentID = boneIDToInfo[id]
		if parentID not in addedIDs:
			addedIDs[parentID] = True
			boneMap[parentID] = len(jointList)
			if boneIDToInfo[parentID][2] in boneMap:
				jointList.append(NoeBone(boneMap[parentID], boneIDToInfo[parentID][0], boneIDToInfo[parentID][1], None, boneMap[boneIDToInfo[parentID][2]]))
			else:
				jointList.append(NoeBone(boneMap[parentID], boneIDToInfo[parentID][0], boneIDToInfo[parentID][1], None, -1))
		jointList[toUpdateJointIDs[id]].parentIndex = boneMap[parentID]
	# jointList.append(NoeBone(len(jointList), "dummy", NoeMat43(), None, -1))
	# jointList[0].parentIndex = len(jointList)-1	
	return [jointList, boneMap]
		
def parseMESHChunk(bs):
	checkpoint1 = bs.tell()
	#grabbing known header values
	bs.seek(0x14,1)
	submeshCount = bs.readUInt()	
	bs.seek(checkpoint1+0x20)
	unkSection1EntryCount = bs.readUInt()
	unkSection2EntryCount = bs.readUInt()
	idxSectionSize = bs.readUInt()
	idxSectinOffset = bs.readUInt()
	bs.seek(0x10,1)
	
	submeshes = []
	for _ in range(submeshCount):
		submesh = Submesh()
		submesh.parse(bs)
		submeshes.append(submesh)
	bs.seek(unkSection1EntryCount*12,1)
	skip = 0
	for _ in range(unkSection2EntryCount):
		index = bs.readUInt()
		unk = bs.readUInt()
		skip += bs.readUInt()*40
	bs.seek(skip,1)
	
	vBufferGlobalOffset = bs.tell()
	
	for submesh in submeshes:
		meshName = 'submesh_' + str(submesh.id)
		materialName = 'material_' + str(submesh.matIndex)
		rapi.rpgSetName(meshName)
		rapi.rpgSetMaterial(materialName)
		
		bs.seek(vBufferGlobalOffset + submesh.vOffset)
		# print(bs.tell())
		# print(hex(submesh.flags))
		# print(submesh.vCount)
		rapi.rpgClearBufferBinds()
		if submesh.flags & 1:
			rapi.rpgBindPositionBufferOfs(bs.readBytes(12*submesh.vCount), noesis.RPGEODATA_FLOAT, 0xC,0x0)
		if submesh.flags & 8:
			# rapi.rpgBindColorBuffer(bs.readBytes(4*submesh.vCount), noesis.RPGEODATA_UBYTE,4,4)
			bs.readBytes(4*submesh.vCount) #skip colors to get vertex color-less display
		if submesh.flags & 2:
			rapi.rpgBindNormalBufferOfs(bs.readBytes(12*submesh.vCount), noesis.RPGEODATA_FLOAT, 0xC,0x0)
		if submesh.flags & 4:
			# rapi.rpgBindTangentBufferOfs() #not sure, skipping for now : no w info about dot product sign
			bs.seek(12*submesh.vCount,1)
		if submesh.flags & 16:
			rapi.rpgBindUV1Buffer(bs.readBytes(4*submesh.vCount), noesis.RPGEODATA_HALFFLOAT, 0x4)
		if submesh.flags & 32:
			rapi.rpgBindBoneWeightBuffer(bs.readBytes(8*submesh.vCount), noesis.RPGEODATA_HALFFLOAT,0x8, 0x4)
			rapi.rpgBindBoneIndexBuffer(bs.readBytes(4*submesh.vCount), noesis.RPGEODATA_UBYTE, 0x4, 0x4)
		bs.seek(vBufferGlobalOffset + idxSectinOffset + submesh.idxOffset)
		# print(bs.tell())
		# print(submesh.idxCount)
		rapi.rpgCommitTriangles(bs.readBytes(submesh.idxWidth*submesh.idxCount),noesis.RPGEODATA_USHORT if submesh.idxWidth == 2 else noesis.RPGEODATA_UINT, submesh.idxCount,noesis.RPGEO_TRIANGLE, 1)	
		# rapi.rpgCommitTriangles(None,noesis.RPGEODATA_USHORT, submesh.vCount,noesis.RPGEO_POINTS, 1)		

def LoadModel(data, mdlList):
	
	ctx = rapi.rpgCreateContext()
	bs = NoeBitStream(data)
	bs.setEndian(NOE_LITTLEENDIAN)
	
	bs.seek(0x20) #jump to first chunk
	bIsChunkEOFC = False
	jointList = []
	boneMap = {}
	animList = []
	textureList = []
	materialList = [[]]
	framerate = -1
	
	while not bIsChunkEOFC and bs.tell() < bs.getSize():
		checkpoint = bs.tell()
		
		chunkMagic, chunkVersion, chunkSize, unk0C = bs.read('4i')
		chunkHeaderSize, headerlessChunkSize, unk18, unk1C = bs.read('4i')
		bs.seek(checkpoint+chunkHeaderSize)
		
		if chunkMagic == 0x43464f45: #EOFC
			bIsChunkEOFC = True
			continue
		elif chunkMagic == 0x45444f4e: #NODE
			jointList, boneMap = parseNODEChunk(bs)
		elif chunkMagic == 0x4853454d: #MESH
			parseMESHChunk(bs)
		elif chunkMagic == 0x4554414D: #MATE
			textureList, materialList = parseMATEChunk(bs)
					
		bs.seek(checkpoint + chunkSize)	
	
	if jointList:	
		jointList = rapi.multiplyBones(jointList)	
	
	if bLoadAnim:
		animData = rapi.loadPairedFileOptional("animation file", ".nmba")
		if animData is not None:
			animDataBs = NoeBitStream(animData)
			animList, framerate = parseNMAFile(animDataBs,boneMap, jointList)
		
	try:
		mdl = rapi.rpgConstructModel()
	except:
		mdl = NoeModel()
	mdl.setBones(jointList)
	mdl.setAnims(animList)
	mdl.setModelMaterials(NoeModelMaterials(textureList, materialList[0]))
	mdlList.append(mdl)
	for i in range(len(materialList)-1):
		mdltemp = NoeModel()
		mdltemp.meshes = mdl.meshes
		mdltemp.bones = mdl.bones
		mdltemp.setModelMaterials(NoeModelMaterials(textureList, materialList[i+1]))
		mdlList.append(mdltemp)
	
	return 1
	
	