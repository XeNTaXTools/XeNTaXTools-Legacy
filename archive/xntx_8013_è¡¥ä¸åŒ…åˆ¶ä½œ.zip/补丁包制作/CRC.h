
#pragma once

DWORD FileCrc32Win32(LPCTSTR szFilename, DWORD &dwCrc32, DWORD& dwFileSize);