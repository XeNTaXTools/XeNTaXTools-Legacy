#Noesis Python model import+export test module, imports/exports some data from/to a made-up format

from inc_noesis import *

import noesis

#rapi methods should only be used during handler callbacks
import rapi

#registerNoesisTypes is called by Noesis to allow the script to register formats.
#Do not implement this function in script files unless you want them to be dedicated format modules!
def registerNoesisTypes():
   handle = noesis.register("BOUT Evolution Model", ".bsc")
   noesis.setHandlerTypeCheck(handle, noepyCheckType)
   noesis.setHandlerLoadModel(handle, noepyLoadModel) #see also noepyLoadModelRPG
   noesis.setHandlerWriteModel(handle, noepyWriteModel)
   #noesis.setHandlerWriteAnim(handle, noepyWriteAnim)
   return 1


#check if it's this type based on the data
def noepyCheckType(data):
   bs = NoeBitStream(data)
   if len(data) < 3:
      return 0
   return 1       

class EvoModel:
 def __init__(self, mdlList, bname):
  self.mdlList = mdlList
  self.bname = bname

 def LoadSkeleton(self, bone):
  if len(self.bname) > 0:
   self.boneMat = []
   self.boneNames = []
   self.bones = []
   self.frameBones = []

   shadow = bone.readFloat()
   bone.seek(4, NOESEEK_REL) #Seek past junk data
   self.boneCount = bone.readByte()
   self.frameCount = bone.readShort()
   self.numOfFrameCount = bone.readByte()
   self.sizeOne = bone.readShort()
   self.sizeTwo = bone.readShort()
   self.finalBoneCount = bone.readShort()
   bone.seek(16, NOESEEK_REL) #Seek past unused data
   self.walkSpeed = bone.readFloat()
   self.runSpeed = bone.readFloat()
   self.walkJumpSpeed = bone.readFloat()
   self.runJumpSpeed = bone.readFloat()
   self.fallHeightSpeed = bone.readFloat()
   bone.seek(20, NOESEEK_REL) #Seek past unused data
   self.keyFrameCount = []
   for fc in range(0, self.numOfFrameCount):
    keyF = bone.readInt()
    self.keyFrameCount.append(keyF)
   bone.seek(self.frameCount*3, NOESEEK_REL) #Collision Stuff
   bone.seek(self.frameCount*4, NOESEEK_REL) #animation accelerations
   bone.seek(self.sizeOne*0xEF, NOESEEK_REL) #Effects
   for sfxCounter in range(0, self.sizeTwo):
    sfxID = bone.readUInt()
    checkSkip = bone.readByte()
    if(checkSkip == -1):
     bone.seek(0x20, NOESEEK_REL)
    elif(sfxCounter == sfxID):
     bone.seek(0x0D, NOESEEK_REL)
    else:
     break
   print(bone.getOffset())
   for bc in range(0, self.boneCount):
    self.bname = ""
    while True:
     by = bone.readBytes(1)[0]
     if by != 0x00:
      self.bname += chr(by)
     else:
      break
    frameMats = []
    bone.seek((0x44 - len(self.bname) - 1), NOESEEK_REL)
    boneBuff = bone.readBytes(0x40)
    self.boneMatrix = NoeMat44.fromBytes(boneBuff)
    self.boneMat.append(self.boneMatrix.toMat43())
    self.boneNames.append(self.bname)
    frameMats.append(self.boneMatrix.toMat43())
    b = NoeBone(bc, self.boneNames[bc], self.boneMatrix.toMat43(), None, bc)
    self.bones.append(b)
    for frames in range (0, self.frameCount - 1):
     frameMats.append(NoeMat44.fromBytes(bone.readBytes(0x40)).toMat43())
    self.frameBones.append(frameMats)
   print(bone.getOffset())
   return 1

 def LoadModel(self, bs, mname, filePath):
  ctx = rapi.rpgCreateContext() 
  bones = self.bones
  hdrInfo = bs.read("bbb") #0 = Bone/MeshCount, #1 = TexCount, #2 = BoneData count
  texNames = []
  if hdrInfo[0] > 0:
   for texCount in range(0, hdrInfo[1]):
    curChar = 0x61 + texCount
    texNames.append(mname +".b"+chr(curChar)+"0")
   texList = []
   matList = []
   for c in range(0, hdrInfo[2] + 1):
    while True:
     curByte = bs.read("b")[0]
     if curByte == 0x42:
      curByte = bs.read("b")[0]
      if curByte == 0x6F:
       break
     if curByte == 0x62:
      curByte = bs.read("b")[0]
      if curByte == 0x6F:
       break
   bs.seek(-2, NOESEEK_REL)
   for b in range(0, hdrInfo[0]):
    boneNameBytes = bs.readBytes(32)
    boneName = ""
    for o in range(0, len(boneNameBytes)+1):
     if boneNameBytes[o] == 0:
      break
     boneName += chr(boneNameBytes[o])
 #Now reading mesh
    bs.seek(64 - len(boneNameBytes), NOESEEK_REL) #Skip junk data
    texID = bs.readShort()
    vertCount = bs.read("i")[0]
    faceCount = bs.read("i")[0]
    bs.seek(24, NOESEEK_REL)
    if (rapi.checkFileExists(filePath + texNames[texID])):
     material = NoeMaterial(str(texID), "")
     material.setTexture(str(texID))
     matList.append(material)
    vertBuff = bs.readBytes(vertCount * 44)
    rapi.rpgBindPositionBufferOfs(vertBuff, noesis.RPGEODATA_FLOAT, 44, 0)
    rapi.rpgBindNormalBufferOfs(vertBuff, noesis.RPGEODATA_FLOAT, 44, 12)
    rapi.rpgBindUV1BufferOfs(vertBuff, noesis.RPGEODATA_FLOAT, 44, 28)
    if len(self.bname) > 0:
     for bn in range(0, len(bones)):
      if(self.boneNames[bn] == boneName):
       boneIndices = noePack("i"*vertCount, *[bn]*vertCount)
       rapi.rpgBindBoneIndexBuffer(boneIndices, noesis.RPGEODATA_INT, 4, 1)
       boneWeights = noePack("f"*vertCount, *[1.0]*vertCount)
       rapi.rpgBindBoneWeightBuffer(boneWeights, noesis.RPGEODATA_FLOAT, 4, 1)

    FaceBuff = bs.readBytes(faceCount * 2)
    if (rapi.checkFileExists(filePath + texNames[texID])):
     rapi.rpgSetMaterial(str(texID))
    rapi.rpgCommitTriangles(FaceBuff, noesis.RPGEODATA_USHORT, faceCount, noesis.RPGEO_TRIANGLE, 1)
   if len(self.bname) > 0:
    rapi.rpgSkinPreconstructedVertsToBones(bones)
   mdl = rapi.rpgConstructModel()
   if len(self.bname) > 0:
    mdl.setBones(bones)
    curFrameCount = 0
    anim = []
    for kfc in range(0, self.numOfFrameCount):
     animation = []
     for frames in range(0, self.keyFrameCount[kfc]):
      for anims in range(0, self.boneCount):
       animation.append(self.frameBones[anims][frames + curFrameCount])
     anim.append(NoeAnim(str(kfc), bones, self.keyFrameCount[kfc], animation, 30.0))
     curFrameCount += self.keyFrameCount[kfc]
    mdl.setAnims(anim)
   for texCount in range(0, hdrInfo[1]):
    if (rapi.checkFileExists(filePath + texNames[texCount])):
     tex = open(filePath +texNames[texCount],'rb').read()
     texture = rapi.loadTexByHandler(tex,'.jpg')
     if texture == None:
      texture = rapi.loadTexByHandler(tex,'.png')
     if texture == None:
      texture = rapi.loadTexByHandler(tex,'.tga')
     if texture != None:
      texture.name = str(texCount)
      texList.append(texture)
   mdl.setModelMaterials(NoeModelMaterials(texList, matList))
   self.mdlList.append(mdl)
  return 1

def noepyWriteModel(mdl, bs):
  anims = rapi.getDeferredAnims()
  bs.writeByte(len(mdl.modelMats.matList))
  bs.writeByte(len(mdl.modelMats.texList))
  for count in range(0, 0x11):
   bs.writeByte(0)
  for b in range(0, len(mdl.modelMats.matList)):
   for count in range(0, 5):
    bs.writeByte(0xCD)
  
  return 1

#load the model
def noepyLoadModel(data, mdlList):
 ctx = rapi.rpgCreateContext()
 bs = NoeBitStream(data)
 curFile = rapi.getLastCheckedName()
 filePath = rapi.getDirForFilePath(curFile)
 mname = curFile.split('\\')
 mname = mname[len(mname) - 1]
 mname = mname[0:len(mname) - 4] #remove .bsc using strip had issues with some names
 bname = ""
 if mname.find("trans") == -1:
  if mname.find("gr") != -1:
   bname = "gr_bone.bon"
  elif mname.find("az") != -1:
   bname = "az_bone.bon"
  elif mname.find("hs") != -1:
   bname = "hs_bone.bon"
  else:
   bname = mname +".bon"
 else:
  bname = mname +".bon"
 if rapi.checkFileExists(filePath+"\\"+bname) == False:
  bname = ""
 model = EvoModel(mdlList, bname)
 boneRead = open(filePath +bname,'rb').read()
 bone = NoeBitStream(boneRead)
 model.LoadSkeleton(bone)


 model.LoadModel(bs, mname, filePath)

 f = open(curFile.replace("body", "head"),'rb').read() 
 f = NoeBitStream(f)
 model.LoadModel(f, mname.replace("body","head"), filePath)

 f = open(curFile.replace("body", "arm"),'rb').read()
 f = NoeBitStream(f)
 model.LoadModel(f, mname.replace("body","arm"), filePath)
 
 rapi.setPreviewOption("drawAllModels", "1")
 rapi.setPreviewOption("animateAllModels", "1")

 return 1