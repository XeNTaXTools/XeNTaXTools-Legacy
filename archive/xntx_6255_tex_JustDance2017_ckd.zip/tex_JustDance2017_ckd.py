from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Just Dance 2017", ".ckd")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    if bs.readBytes(8) != b'\x00\x00\x00\x09\x54\x45\x58\x00': return 0
    return 1

def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data, NOE_BIGENDIAN)
    bs.seek(0x2c, NOESEEK_ABS)
    data = bs.readBytes(len(data) - bs.tell())
    texList.append(rapi.loadTexByHandler(data, ".dds"))
    return 1