# Pinshape .bingeom viewer
# Noesis script by Dave, 2021

from inc_noesis import *
import json

def registerNoesisTypes():
	handle = noesis.register("Pinshape",".bingeom")
	noesis.setHandlerTypeCheck(handle, bcCheckType)
	noesis.setHandlerLoadModel(handle, bcLoadModel)
	return 1


# Check file type

def bcCheckType(data):
	return 1


# Read the model data

def bcLoadModel(data, mdlList):
	bs = NoeBitStream(data)
	ctx = rapi.rpgCreateContext()

	file_end = len(data)
	bs.seek(file_end - 8)
	text_size = bs.readUInt()
	bs.seek(file_end - 8 - text_size)
	mesh_text = bs.readBytes(text_size).decode("utf-8")
	text1 = json.loads(mesh_text)

	face_start = text1["faces"]["o"]
	face_size = text1["faces"]["l"]
	face_stride = text1["faces"]["b"]
	face_entries = int(face_size / face_stride)
	vert_start = text1["positions"]["o"]
	vert_size = text1["positions"]["l"]
	vert_count = int(vert_size / 12)

	bs.seek(vert_start)
	vertices = bs.readBytes(vert_count * 12)

	bs.seek(face_start)
	faces = bs.readBytes(face_size)

	rapi.rpgSetName("Mesh1")
	rapi.rpgBindPositionBuffer(vertices, noesis.RPGEODATA_FLOAT, 12)

	if face_stride == 1:
		rapi.rpgCommitTriangles(faces, noesis.RPGEODATA_UBYTE, face_entries, noesis.RPGEO_TRIANGLE, 0)

	if face_stride == 2:
		rapi.rpgCommitTriangles(faces, noesis.RPGEODATA_USHORT, face_entries, noesis.RPGEO_TRIANGLE, 0)

	if face_stride == 4:
		rapi.rpgCommitTriangles(faces, noesis.RPGEODATA_UINT, face_entries, noesis.RPGEO_TRIANGLE, 0)


	mdl = rapi.rpgConstructModel()
	mdlList.append(mdl)

	return 1

