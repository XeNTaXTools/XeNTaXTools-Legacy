// Tim2Format.cpp : Defines the initialization routines for the DLL.
//

#include "stdafx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CTim2FormatApp

BEGIN_MESSAGE_MAP(CTim2FormatApp, CWinApp)
END_MESSAGE_MAP()

const CTim2FormatApp::SELECTORTOFUNCMAP CTim2FormatApp::m_SelectorToRoutine[] =
{
	{ formatSelectorAbout, About },
	{ formatSelectorReadPrepare, ReadPrepare },
	{ formatSelectorReadStart, ReadStart },
	{ formatSelectorReadContinue, ReadContinue },
	{ formatSelectorReadFinish, ReadFinish },

	{ formatSelectorOptionsPrepare, OptionsPrepare },
	{ formatSelectorOptionsStart, OptionsStart },
	{ formatSelectorOptionsContinue, OptionsContinue },
	{ formatSelectorOptionsFinish, OptionsFinish },

	{ formatSelectorEstimatePrepare, EstimatePrepare },
	{ formatSelectorEstimateStart, EstimateStart },
	{ formatSelectorEstimateContinue, EstimateContinue },
	{ formatSelectorEstimateFinish, EstimateFinish },

	{ formatSelectorWritePrepare, WritePrepare },
	{ formatSelectorWriteStart, WriteStart },
	{ formatSelectorWriteContinue, WriteContinue },
	{ formatSelectorWriteFinish, WriteFinish },

	{ formatSelectorFilterFile, FilterFile }
};

#define NUMSELECTORHANDLERS (sizeof(m_SelectorToRoutine)/	\
	sizeof(m_SelectorToRoutine[0]))
	
// CTim2FormatApp construction

CTim2FormatApp::CTim2FormatApp()
{
	m_CurTimFile = NULL;
	m_RowData = NULL;
}


// The one and only CTim2FormatApp object

CTim2FormatApp theApp;


// CTim2FormatApp initialization

BOOL CTim2FormatApp::InitInstance()
{
	CWinApp::InitInstance();

	return TRUE;
}

void CTim2FormatApp::HandleSelector(const short selector, 
									FormatRecord *formatParamsBlock,
									long *data,
									short *result)
{
	int i;

	// yes this would probably be faster with an STL map, 
	// but there are only a few of them to search through
	*result = formatBadParameters;
	for (i=0; i<NUMSELECTORHANDLERS; i++)
	{
		if (m_SelectorToRoutine[i].selector == selector)
		{
			SELECTORCALLBACK func;
			func = m_SelectorToRoutine[i].cb;
			(this->*func)(formatParamsBlock, data, result);
			break;
		}
	}

	// unlock handle pointing to parameter block and data so it can move
	// if memory gets shuffled:
	if ((Handle)*data != NULL)
	{
		UnlockHandle(formatParamsBlock->handleProcs, (Handle)*data);
	}
}

// display about box
void CTim2FormatApp::About(FormatRecord *formatParamsBlock, long *data, short *result)
{
	CAboutBox aboutDlg;

	aboutDlg.DoModal();
	*result = noErr;
}

// Prepare to read from a file/stream
void CTim2FormatApp::ReadPrepare(FormatRecord *formatParamsBlock, long *data, short *result)
{
	formatParamsBlock->maxData = 0;
	*result = noErr;
}

// Start reading the first chunk
void CTim2FormatApp::ReadStart(FormatRecord *formatParamsBlock, long *data, short *result)
{
	DWORD i;
	DWORD fSize;
	DWORD bytesRead;
	HANDLE fileHandle;

	fileHandle = (HANDLE)formatParamsBlock->dataFork;
	fSize = GetFileSize(fileHandle, &fSize);

	// make sure at beginning of file
	SetFilePointer(fileHandle, 0, 0, FILE_BEGIN);

	// allocate memory for the darn thing
	m_CurTimFile = GlobalAlloc(GMEM_FIXED, fSize);
	if (m_CurTimFile == NULL)
	{
		*result = memFullErr;
		return;
	}

	if (!ReadFile(fileHandle, m_CurTimFile, fSize, &bytesRead, NULL))
	{
		*result = readErr;
		GlobalFree(m_CurTimFile);
		m_CurTimFile = NULL;
		return;
	}

	// we only load pics (TIM2), not CLUTs
	if (Tim2CheckFileHeader(m_CurTimFile) != 1)
	{
		*result = formatCannotRead;
		GlobalFree(m_CurTimFile);
		m_CurTimFile = NULL;
		return;
	}

	// right now we only handle 1 picture and no-mip maps
	// should we put the other pictures in layers, but then what about mip-maps?
	m_ImageHeader = Tim2GetPictureHeader(m_CurTimFile, 0);
	if (m_ImageHeader == NULL)
	{
		*result = fnfErr;
		return;
	}

	formatParamsBlock->imageRsrcData = NULL;
	formatParamsBlock->imageRsrcSize = 0;


	if ((m_ImageHeader->ImageType == TIM2_IDTEX4) ||
			(m_ImageHeader->ImageType == TIM2_IDTEX8))
	{
		DWORD nColors = 256;

		formatParamsBlock->imageMode = plugInModeIndexedColor;
		formatParamsBlock->depth = 8;
		formatParamsBlock->planes = 2;
		formatParamsBlock->lutCount = 256;
		if (m_ImageHeader->ImageType == TIM2_IDTEX4)
		{
			nColors = 16;
			formatParamsBlock->lutCount = 16;
		}
		// copy the clut data to the redLUT
		for (i=0; i<nColors; i++)
		{
			DWORD color;
			// Guess we should use Clut #0?
			color = Tim2GetClutColor(m_ImageHeader, 0, i);

			// need to load alpha channel somehow????

			formatParamsBlock->greenLUT[i] = (unsigned8)((color >> 16) & 0xff);
			formatParamsBlock->blueLUT[i] = (unsigned8)((color >> 8) & 0xff);
			formatParamsBlock->redLUT[i] = (unsigned8)((color >> 0) & 0xff);
		}
	}
	else
	{
		formatParamsBlock->imageMode = plugInModeRGBColor;
		formatParamsBlock->depth = 8;
		switch (m_ImageHeader->ImageType)
		{
			case TIM2_RGB32:
				formatParamsBlock->planes = 4;
				break;
			case TIM2_RGB24:
			case TIM2_RGB16:
				formatParamsBlock->planes = 3;
				break;
		}

	}

	formatParamsBlock->imageSize.h = m_ImageHeader->ImageWidth;
	formatParamsBlock->imageSize.v = m_ImageHeader->ImageHeight;

	// temporary storage for one channel of data
	m_RowData = (BYTE *)GlobalAlloc(GMEM_FIXED, formatParamsBlock->imageSize.h);
	*result = noErr;
}

// Read the next chunk from the file
void CTim2FormatApp::ReadContinue(FormatRecord *formatParamsBlock, long *data, short *result)
{
	int32 done;
	int32 total;
	int16 plane;
	int16 row;
	DWORD colorBytes;
	
	// Set up the progress variables.
	done = 0;
	total = formatParamsBlock->imageSize.v * (long) formatParamsBlock->planes;

	// Set up to start returning chunks of data.
	
	formatParamsBlock->theRect.left = 0;
	formatParamsBlock->theRect.right = formatParamsBlock->imageSize.h;
	formatParamsBlock->colBytes = (formatParamsBlock->depth + 7) >> 3;
	colorBytes = formatParamsBlock->colBytes;

	formatParamsBlock->rowBytes = formatParamsBlock->imageSize.h * ((formatParamsBlock->depth + 7) >> 3);
	if (formatParamsBlock->lutCount == 16)
	{
		formatParamsBlock->rowBytes /= 2;
		colorBytes = 0;
	}
	formatParamsBlock->data = m_RowData;
	formatParamsBlock->planeBytes = 0;
	if (formatParamsBlock->depth == 16)
		formatParamsBlock->maxValue = 0x8000;

	for (plane = 0; plane < formatParamsBlock->planes; ++plane)
	{
		
		formatParamsBlock->loPlane = formatParamsBlock->hiPlane = plane;
		
		for (row = 0; row < formatParamsBlock->imageSize.v; ++row)
		{
			
			formatParamsBlock->theRect.top = row;
			formatParamsBlock->theRect.bottom = row + 1;

			UnInterleaveData(row, plane, colorBytes);

			if (formatParamsBlock->advanceState)
			{
				*result = (*(formatParamsBlock->advanceState))();
				if (*result != noErr)
				{
					break;
				}
			}

			if (formatParamsBlock->progressProc)
			{			
				(*(formatParamsBlock->progressProc))(++done, total);
			}
		
		}
	}
		
	formatParamsBlock->data = NULL;
	*result = noErr;
	
}

// Read file finished
void CTim2FormatApp::ReadFinish(FormatRecord *formatParamsBlock, long *data, short *result)
{

	if (m_CurTimFile != NULL)
	{
		GlobalFree(m_CurTimFile);
		m_CurTimFile = NULL;
	}

	if (m_RowData != NULL)
	{
		GlobalFree(m_RowData);
		m_RowData = NULL;
	}

	*result = noErr;
}

// Prepare for options chunks
void CTim2FormatApp::OptionsPrepare(FormatRecord *formatParamsBlock, long *data, short *result)
{
	DWORD newWidth;
	DWORD newHeight;
	// here we could add options dialog, so far options would be
	// -- CLUT is 16 bit or 32 bit?
	// -- MIPMAP textures on output
	// -- 

	newWidth = 1 << Tim2GetLog2(formatParamsBlock->imageSize.h);
	newHeight = 1 << Tim2GetLog2(formatParamsBlock->imageSize.v);

	// check for power of 2 texture size
	if ((newWidth != formatParamsBlock->imageSize.h) ||
		(newHeight != formatParamsBlock->imageSize.v))
	{
		MessageBox(NULL, _T("Texture needs to be power of 2 in width & height\n"),
						_T("Size Error!"), MB_OK);
		*result = paramErr;
	}
	else
	{
		formatParamsBlock->maxData = 0;
		*result = noErr;
	}
}

// Start the options chunks
void CTim2FormatApp::OptionsStart(FormatRecord *formatParamsBlock, long *data, short *result)
{
	*result = noErr;
}

// Set the next options chunk
void CTim2FormatApp::OptionsContinue(FormatRecord *formatParamsBlock, long *data, short *result)
{
	formatParamsBlock->data = NULL;
	*result = noErr;
}

// Options are finished
void CTim2FormatApp::OptionsFinish(FormatRecord *formatParamsBlock, long *data, short *result)
{
	*result = noErr;
}

// Estimate the size of a file prepare routine
void CTim2FormatApp::EstimatePrepare(FormatRecord *formatParamsBlock, long *data, short *result)
{
	formatParamsBlock->maxData = 0;
	m_ImageHeader = &m_LocalImageHeader;
	*result = noErr;
}

// Estimate the file size start chunk
void CTim2FormatApp::EstimateStart(FormatRecord *formatParamsBlock, long *data, short *result)
{
	DWORD bytesPerColor;
	DWORD rowBytes;
	DWORD psm;
	// ok, let's set the data size

	bytesPerColor = formatParamsBlock->planes;
	// Number of CLUT colors, fro RGB mode
	m_ImageHeader->ClutColors  = 0;

	// calculate row # bytes
	rowBytes = formatParamsBlock->imageSize.h * bytesPerColor;
	// if indexed find, 4 bit or 8 bit indices to write
	if (formatParamsBlock->imageMode == plugInModeIndexedColor)
	{
		m_ImageHeader->ClutColors = (TIM2_UINT16)formatParamsBlock->lutCount;
		m_ImageHeader->ImageType = TIM2_IDTEX8;
		m_ImageHeader->ClutType = 0;
		psm = GS_PSMT8;
		if (m_ImageHeader->ClutColors <= 16)
		{
			m_ImageHeader->ClutColors = 16;
			m_ImageHeader->ImageType = TIM2_IDTEX4;
			psm = GS_PSMT4;
			// flag 16 colors
			m_ImageHeader->ClutType = 0x40;
			rowBytes /= 2;
		}
		else if (m_ImageHeader->ClutColors < 256)
		{
			// force to have 256 colors
			m_ImageHeader->ClutColors = 256;
		}

		if (bytesPerColor > 1)
		{
			// with alpha channel
			m_ImageHeader->ClutSize = m_ImageHeader->ClutColors * 4;
			m_ImageHeader->ClutType |= TIM2_RGB32;
			rowBytes /= 2;
		}
		else
		{
			// no alpha channel!
			m_ImageHeader->ClutSize = m_ImageHeader->ClutColors * 3;
			m_ImageHeader->ClutType |= TIM2_RGB24;
		}
	}
	else
	{
		m_ImageHeader->ClutSize = 0;
		// No CLUT part
		m_ImageHeader->ClutType = TIM2_NONE;
		if (bytesPerColor == 3)
		{
			m_ImageHeader->ImageType = TIM2_RGB24;
			psm = GS_PSMCT24;
		}
		else
		{
			m_ImageHeader->ImageType = TIM2_RGB32;
			psm = GS_PSMCT32;
		}
	}

	m_ImageHeader->ImageSize = formatParamsBlock->imageSize.v * rowBytes;
	m_ImageHeader->TotalSize = sizeof(TIM2_PICTUREHEADER) + 
		m_ImageHeader->ImageSize + m_ImageHeader->ClutSize;
	// Header part size
	m_ImageHeader->HeaderSize  = sizeof(TIM2_PICTUREHEADER);
	// Picture format
	m_ImageHeader->PictFormat  = 0;
	// Number of MIPMAP textures, should be option to generate mips?
	m_ImageHeader->MipMapTextures = 1;
	// Image width
	m_ImageHeader->ImageWidth  = formatParamsBlock->imageSize.h;
	// Image height
	m_ImageHeader->ImageHeight = formatParamsBlock->imageSize.v;

	// Write picture header
	// Set all GS register settings to 0
	m_ImageHeader->GsTex0        = 0;
	((GsTex0 *)&m_ImageHeader->GsTex0)->TBW = Tim2CalcBufWidth(psm, m_ImageHeader->ImageWidth);
	((GsTex0 *)&m_ImageHeader->GsTex0)->PSM = psm;
	((GsTex0 *)&m_ImageHeader->GsTex0)->TW  = Tim2GetLog2(m_ImageHeader->ImageWidth);
	((GsTex0 *)&m_ImageHeader->GsTex0)->TH  = Tim2GetLog2(m_ImageHeader->ImageHeight);
	m_ImageHeader->GsTex1        = 0;
	m_ImageHeader->GsTexaFbaPabe = 0;
	m_ImageHeader->GsTexClut     = 0;

	// set the size of disk
	formatParamsBlock->minDataBytes = 
		formatParamsBlock->maxDataBytes = sizeof(TIM2_FILEHEADER) +
		m_ImageHeader->TotalSize + m_ImageHeader->ClutSize;

	// and we are done estimating
	formatParamsBlock->data = NULL;

	*result = noErr;
}

// Estimate continue with chunk
void CTim2FormatApp::EstimateContinue(FormatRecord *formatParamsBlock, long *data, short *result)
{
	formatParamsBlock->data = NULL;
	*result = noErr;
}

// Estimate the size of the file
void CTim2FormatApp::EstimateFinish(FormatRecord *formatParamsBlock, long *data, short *result)
{
	*result = noErr;
}

/// display about box
void CTim2FormatApp::WritePrepare(FormatRecord *formatParamsBlock, long *data, short *result)
{
	m_RowData = (BYTE *)GlobalAlloc(GMEM_FIXED, formatParamsBlock->imageSize.h);
	if (m_RowData == NULL)
	{
		*result = memFullErr;
		return;
	}

	m_ImageHeader = &m_LocalImageHeader;
	*result = noErr;
}

// write the first chunk of the file
void CTim2FormatApp::WriteStart(FormatRecord *formatParamsBlock, long *data, short *result)
{
	// Write out file header
	TIM2_FILEHEADER fhdr;
	DWORD i;
	HANDLE fHandle;
	DWORD bytesWritten;

	fhdr.FileId[0] = 'T';				// Set file ID
	fhdr.FileId[1] = 'I';
	fhdr.FileId[2] = 'M';
	fhdr.FileId[3] = '2';
	fhdr.FormatVersion = 4;				// Format version 4
	fhdr.FormatId  = 0;					// 16-byte alignment mode
	fhdr.Pictures  = 1;					// Number of pictures is 1
	for (i=0; i<8; i++) 
	{
		fhdr.pad[i] = 0x00;				// Clear padding member with 0x00
	}

	fHandle = (HANDLE)formatParamsBlock->dataFork;
	// Write file header
	if (!WriteFile(fHandle, &fhdr, sizeof(TIM2_FILEHEADER), &bytesWritten, NULL))
	{
		*result = writErr;
		return;
	}

	if (!WriteFile(fHandle, m_ImageHeader, sizeof(TIM2_PICTUREHEADER), &bytesWritten, NULL))
	{
		*result = writErr;
		return;
	}

	formatParamsBlock->theRect.left = 0;
	formatParamsBlock->theRect.right = m_ImageHeader->ImageWidth;
	formatParamsBlock->colBytes = (formatParamsBlock->depth + 7) >> 3;
	formatParamsBlock->rowBytes = m_ImageHeader->ImageWidth;
	formatParamsBlock->loPlane = 0;
	formatParamsBlock->hiPlane = 0;
	formatParamsBlock->planeBytes = 0;

	// allocate memory to receive plane data
	formatParamsBlock->data = GlobalAlloc(GMEM_FIXED, m_ImageHeader->ImageWidth);
	if (formatParamsBlock->data  == NULL)
	{
		*result = memFullErr;
		return;
	}

	*result = noErr;
}

// write next chunk of data
void CTim2FormatApp::WriteContinue(FormatRecord *formatParamsBlock, long *data, short *result)
{
	int32 done;
	int32 total;
	int16 plane;
	int16 row;
	DWORD colorBytes;
	HANDLE fHandle;
	DWORD bytesWritten;
	DWORD i;
	
	// Set up the progress variables.
	done = 0;
	total = formatParamsBlock->imageSize.v * (long) formatParamsBlock->planes;

	// Set up to start returning chunks of data.
	
	formatParamsBlock->theRect.left = 0;
	formatParamsBlock->theRect.right = formatParamsBlock->imageSize.h;
	formatParamsBlock->colBytes = (formatParamsBlock->depth + 7) >> 3;
	colorBytes = formatParamsBlock->colBytes;

	formatParamsBlock->rowBytes = formatParamsBlock->imageSize.h * ((formatParamsBlock->depth + 7) >> 3);
	// if 16 colors, fake colorBytes to 0, so divide will happen
	if (formatParamsBlock->lutCount == 16)
	{
		colorBytes = 0;
	}

	formatParamsBlock->planeBytes = 0;
	if (formatParamsBlock->depth == 16)
		formatParamsBlock->maxValue = 0x8000;

	fHandle = (HANDLE)formatParamsBlock->dataFork;

	for (row = 0; row < formatParamsBlock->imageSize.v; ++row)
	{
		
		formatParamsBlock->theRect.top = row;
		formatParamsBlock->theRect.bottom = row + 1;

		for (plane = 0; plane < formatParamsBlock->planes; ++plane)
		{
			
			formatParamsBlock->loPlane = formatParamsBlock->hiPlane = plane;


			// get the data
			if (formatParamsBlock->advanceState)
			{
				*result = (*(formatParamsBlock->advanceState))();
				if (*result != noErr)
				{
					break;
				}
			}

			// re-interleave the data
			InterleaveData(row, plane, colorBytes, (BYTE *)formatParamsBlock->data);

			if (formatParamsBlock->progressProc)
			{			
				(*(formatParamsBlock->progressProc))(++done, total);
			}
		}

		if (!WriteFile(fHandle, m_RowData, (m_ImageHeader->ImageSize / m_ImageHeader->ImageHeight), 
					&bytesWritten, NULL))
		{
			*result = writErr;
			return;
		}

	}
		
	// write out the CLUT if we have one.
	if (m_ImageHeader->ClutType != TIM2_NONE)
	{
		// now we need to write out the clut data.....
		for (i=0; i<(DWORD)formatParamsBlock->lutCount; i++)
		{
			DWORD curColor;

			// retrieve current alpha value
			curColor = Tim2GetClutColor(m_ImageHeader, 0, i, m_PaletteData);
			// mask to only alpha
			curColor &= 0xff000000;
			// add new entries
			curColor |= (formatParamsBlock->blueLUT[i] << 16);
			curColor |= (formatParamsBlock->greenLUT[i] << 8);
			curColor |= (formatParamsBlock->redLUT[i]);
			// reset color data with alpha
			curColor = Tim2SetClutColor(m_ImageHeader, 0, i, curColor, m_PaletteData);
		}

		if (!WriteFile(fHandle, m_PaletteData, m_ImageHeader->ClutSize, &bytesWritten, NULL))
		{
			*result = writErr;
			return;
		}
	}

	formatParamsBlock->theRect.left = 0;
	formatParamsBlock->theRect.right = 0;
	formatParamsBlock->theRect.top = 0;
	formatParamsBlock->theRect.bottom = 0;

	GlobalFree(formatParamsBlock->data);
	formatParamsBlock->data = NULL;

	*result = noErr;
}

// Writing is finished so close up the file
void CTim2FormatApp::WriteFinish(FormatRecord *formatParamsBlock, long *data, short *result)
{

	if (m_RowData != NULL)
	{
		GlobalFree(m_RowData);
		m_RowData = NULL;
	}

	*result = noErr;
}

// get filters for my known file types, probably
void CTim2FormatApp::FilterFile(FormatRecord *formatParamsBlock, long *data, short *result)
{
	TIM2_FILEHEADER header;
	HANDLE fileHandle;
	DWORD bytesRead;

	fileHandle = (HANDLE)formatParamsBlock->dataFork;
	// make sure at beginning of file
	SetFilePointer(fileHandle, 0, 0, FILE_BEGIN);

	if (!ReadFile(fileHandle, &header, sizeof(TIM2_FILEHEADER), &bytesRead, NULL))
	{
		*result = readErr;
		return;
	}

	// we only load pics (TIM2), not CLUTs
	if (Tim2CheckFileHeader(&header) == 1)
		*result = noErr;
	else
		*result = formatCannotRead;
}

// unlock the handles from Photoshop
void CTim2FormatApp::UnlockHandle(HandleProcs *procs, Handle h)
{
	if (ProcsAvailable(procs, NULL))
	{
		(*procs->unlockProc)(h);	
	}		
	else
	{ 
		GlobalUnlock(h);
	}
	
} 

// see if Procs are available to manage things.
BOOL CTim2FormatApp::ProcsAvailable(HandleProcs *procs, BOOL *outNewerVersion)
{
	BOOL available = TRUE;		// assume procs are available
	BOOL newerVersion = FALSE;	// assume we're running under correct version
	
	if (procs == NULL)
	{
		available = FALSE;
	}	
	else if (procs->handleProcsVersion < kCurrentHandleProcsVersion)
	{
		available = FALSE;
	}	
	else if (procs->handleProcsVersion > kCurrentHandleProcsVersion)
	{	
		available = FALSE;	
		newerVersion = TRUE;
	}	
	else if (procs->numHandleProcs < kCurrentHandleProcsCount)
	{
		available = FALSE;
	}
	else if (procs->newProc == NULL ||
			 procs->disposeProc == NULL ||
			 procs->getSizeProc == NULL ||
			 procs->setSizeProc == NULL)
	{
		available = FALSE;
	}
		
	if (newerVersion && (outNewerVersion != NULL))
		*outNewerVersion = newerVersion;
		
	return available;
}

// uninterleave the data, ARGB -> m_RowData[] = R (G, B, A)
void CTim2FormatApp::UnInterleaveData(DWORD row, DWORD plane, DWORD bytesPerColor)
{
	DWORD i;
	BYTE *rowPtr;
	DWORD rowBytes;

	if (bytesPerColor == 0)
	{
		row /= 2;
		bytesPerColor = 1;
	}

	rowPtr = (BYTE *)Tim2GetImage(m_ImageHeader, 0);
	rowPtr += (row * m_ImageHeader->ImageWidth * bytesPerColor);

	rowBytes = m_ImageHeader->ImageWidth;
	switch (m_ImageHeader->ImageType)
	{
		case TIM2_IDTEX4:
			rowBytes /= 2;		// fall through
		case TIM2_IDTEX8:
			// plane zero is index data
			if (plane == 0)
			{
				memcpy(m_RowData, rowPtr, rowBytes);
			}
			else	// plane 1 is Alpha Data
			{
				for (i=0; i<m_ImageHeader->ImageWidth; i++)
				{
					DWORD color;
					color = Tim2GetTextureColor(m_ImageHeader, 0, 0, i, row);
					m_RowData[i] = (BYTE)((color >> 24) & 0xff);
				}
			}
			break;
		default:
			for (i=0; i<m_ImageHeader->ImageWidth; i++)
			{
				m_RowData[i] = rowPtr[plane];
				// bump to next color
				rowPtr += bytesPerColor;
			}
	}
}

// interleave the data, m_RowData[] = R (G, B, A) -> ARGB
void CTim2FormatApp::InterleaveData(DWORD row, DWORD plane, DWORD bytesPerColor,
									BYTE *srcData)
{
	DWORD i;
	BYTE *rowPtr;
	DWORD rowBytes;

	if (bytesPerColor == 0)
	{
		row /= 2;
		bytesPerColor = 1;
	}

	rowPtr = m_RowData;
	rowBytes = m_ImageHeader->ImageWidth;
	switch (m_ImageHeader->ImageType)
	{
		case TIM2_IDTEX4:
			// plane zero is index data
			if (plane == 0)
			{
				for (i=0; i<m_ImageHeader->ImageWidth; i++)
				{
					rowPtr[i/2] = (srcData[i] << 4) | (srcData[i+1] & 0x0f);
				}
			}
			else
			{
				for (i=0; i < (DWORD)(m_ImageHeader->ImageWidth>>1); i++)
				{
					DWORD color;
					int index;
					// grab alpha component
					color = ((DWORD)srcData[i*2]) << 24;
					index = m_RowData[i] >> 4;
					// and save off in our clut data 
					Tim2SetClutColor(m_ImageHeader, 0, index, color, m_PaletteData);

					color = (DWORD)(srcData[(i*2)+1]) << 24;
					index = m_RowData[i] & 0x0f;
					// and save off in our clut data 
					Tim2SetClutColor(m_ImageHeader, 0, index, color, m_PaletteData);

				}
			}
			break;
		case TIM2_IDTEX8:
			// plane zero is index data
			if (plane == 0)
			{
				memcpy(rowPtr, srcData, rowBytes);
			}
			else	// plane 1 is Alpha Data
			{
				for (i=0; i<m_ImageHeader->ImageWidth; i++)
				{
					DWORD color;
					int index;
					// grab alpha component
					color = (DWORD)(srcData[i]) << 24;
					index = m_RowData[i];

					// and save off in our clut data 
					Tim2SetClutColor(m_ImageHeader, 0, index, color, m_PaletteData);
				}
			}
			break;
		default:
			for (i=0; i<m_ImageHeader->ImageWidth; i++)
			{
				rowPtr[plane] = srcData[i];
				// bump to next color
				rowPtr += bytesPerColor;
			}
	}

}

extern "C" void _declspec(dllexport) PluginMain(const short selector,
						             FormatRecord *formatParamBlock,
						             long *data,
						             short *result)
{
	theApp.HandleSelector(selector, formatParamBlock, data, result);
	
} 
