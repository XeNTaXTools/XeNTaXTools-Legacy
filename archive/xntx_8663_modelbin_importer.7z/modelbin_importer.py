import bpy
import bmesh
import struct
import os

class File(object):
    def __init__(self, path):
        self.__f = open(path, "rb")
    
    def __del__(self):
        self.__f.close()
    
    def seek(self, offset, whence=0):
        self.__f.seek(offset, whence)
    
    def readS16(self):
        v = self.__f.read(2)
        if not v:
            return None
        return struct.unpack('h', v)[0]
    
    def readS32(self):
        v = self.__f.read(4)
        if not v:
            return None
        return struct.unpack('i', v)[0]
    
    def readF16(self):
        v = self.__f.read(2)
        if not v:
            return None
        return struct.unpack('e', v)[0]
    
    def readF32(self):
        v = self.__f.read(4)
        if not v:
            return None
        return struct.unpack('f', v)[0]
    
    def readS16_NORM(self):
        return self.readS16() / 32767

TireWidthMM = 145
TireAspect = 80
WheelOriginalDiameterIN = 10
WheelDiameterIN = 14



f = File("D:\\games\\rips\\FH5\\media\\Cars\\_library\\scene\\wheels\\CRA_Series313\\CRA_Series313_wheelLF.modelbin")
start_face = 2800
start_vertex = 4358

f.seek(0xE9B)
S = [f.readF32(), f.readF32(), f.readF32(), f.readF32()]
T = [f.readF32(), f.readF32(), f.readF32(), f.readF32()]

# faces
faces = []
f.seek(0x212C + start_face * 3 * 4)
for i in range(5067):
    faces.append((f.readS32() - start_vertex, f.readS32() - start_vertex, f.readS32() - start_vertex))

# weights
weights = []
f.seek(0xCB7A8 + (start_vertex - 4358) * 4 * 8)
for i in range(4591):
    w = []
    for j in range(2):
        w.append((f.readF16(), f.readF16(), f.readF16(), f.readF16()))
    weights.append(w)
    f.seek(2 * 8, os.SEEK_CUR)

# positions
verts = []
f.seek(0x37E48 + start_vertex * 8)
for i in range(4591):
    v = [f.readS16_NORM(), f.readS16_NORM(), f.readS16_NORM(), f.readS16_NORM()]
    v[0] = v[0] * S[0] + T[0] + weights[i][0][0] * (1 - TireWidthMM / 1000) / 0.9 + weights[i][1][0] * (WheelDiameterIN - 10) / 14
    v[1] = v[1] * S[1] + T[1] + weights[i][0][1] * (1 - TireWidthMM / 1000) / 0.9 + weights[i][1][1] * (WheelDiameterIN - 10) / 14
    v[2] = v[2] * S[2] + T[2] + weights[i][0][2] * (1 - TireWidthMM / 1000) / 0.9 + weights[i][1][2] * (WheelDiameterIN - 10) / 14
    verts.append((v[0], v[2], v[1]))

mesh = bpy.data.meshes.new("CRA_Series313_wheelLF")
mesh.from_pydata(verts, [], faces)
obj = bpy.data.objects.new(mesh.name, mesh)
bpy.data.collections["Collection"].objects.link(obj)



f = File("D:\\games\\rips\\FH5\\media\\Cars\\_library\\scene\\tires\\tire_whiteWall\\tireL_whiteWall.modelbin")
start_face = 0
start_vertex = 0

f.seek(0xC27)
S = [f.readF32(), f.readF32(), f.readF32(), f.readF32()]
T = [f.readF32(), f.readF32(), f.readF32(), f.readF32()]

# faces
faces = []
f.seek(0x1B38 + start_face * 3 * 4)
for i in range(3360):
    faces.append((f.readS32() - start_vertex, f.readS32() - start_vertex, f.readS32() - start_vertex))

# weights
weights = []
f.seek(0x384C8 + (start_vertex - 0) * 10 * 8)
for i in range(2187):
    w = []
    for j in range(5):
        w.append((f.readF16(), f.readF16(), f.readF16(), f.readF16()))
    weights.append(w)
    f.seek(5 * 8, os.SEEK_CUR)

# positions
verts = []
f.seek(0x18478 + start_vertex * 8)
for i in range(2187):
    v = [f.readS16_NORM(), f.readS16_NORM(), f.readS16_NORM(), f.readS16_NORM()]
    v[0] = (v[0] * S[0] + T[0] + weights[i][3][0] * (WheelDiameterIN - 10) / 14 + weights[i][4][0] * (TireWidthMM * TireAspect / 100 - 225 + WheelOriginalDiameterIN * 12.7) / 275) * TireWidthMM / 1000
    v[1] = v[1] * S[1] + T[1] + weights[i][3][1] * (WheelDiameterIN - 10) / 14 + weights[i][4][1] * (TireWidthMM * TireAspect / 100 - 225 + WheelOriginalDiameterIN * 12.7) / 275
    v[2] = v[2] * S[2] + T[2] + weights[i][3][2] * (WheelDiameterIN - 10) / 14 + weights[i][4][2] * (TireWidthMM * TireAspect / 100 - 225 + WheelOriginalDiameterIN * 12.7) / 275
    verts.append((v[0], v[2], v[1]))

mesh = bpy.data.meshes.new("tireL_whiteWall")
mesh.from_pydata(verts, [], faces)
obj = bpy.data.objects.new(mesh.name, mesh)
bpy.data.collections["Collection"].objects.link(obj)
