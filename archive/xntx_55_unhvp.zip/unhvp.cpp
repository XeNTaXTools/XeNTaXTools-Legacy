#include <iostream.h>
#include <fstream.h>
#include <stdlib.h>
#include <direct.h>
#include <zlib.h>

int readInteger(ifstream *);
void readNext(ifstream *);
void readDirectory(ifstream *);
void readFile(ifstream *);

int main(int argc,char* argv[]){
  if((argc==2)||(argc==3)){
    int i,n;
    ifstream hvp;
    hvp.open(argv[1],ios::in|ios::binary);
    if(!hvp){
      cout<<"ERROR: file not found or unreadable for entry "<<argv[1]<<endl;
      exit(1);
    }
    char tag[]={'H','V',' ','P','a','c','k','F','i','l','e'};
    char data[11];
    hvp.read(data,11);
    if(memcmp(tag,data,11)){
      cout<<"ERROR: "<<argv[1]<<" is not a valid HV PackFile"<<endl;
      exit(1);
    }
    if(argc==3){
      char *token;
      token=strchr(argv[2],'\\');
      if(token){
        cout<<"ERROR: second argument is not a valid directory name"<<endl;
        exit(1);
      } else{
        mkdir(argv[2]); // Error message missing
        chdir(argv[2]);
      }
    }
    hvp.ignore(5);
    n=readInteger(&hvp);
    hvp.ignore(20);
    for(i=0;i<n;i++)
      readNext(&hvp);
    hvp.close();
  } else{
    cout<<"-------------------------------------------------------------------------------"<<endl<<endl;
    cout<<"                       UnHVP v1.0 - HV PackFile Resource                       "<<endl;
    cout<<"            (C) Copyright Baccello, 2004-2005. All Rights Reserved.            "<<endl<<endl;
    cout<<"-------------------------------------------------------- baccello@infinito.it -"<<endl<<endl;;
    cout<<"USAGE: unhvp <archive> [output directory]"<<endl;
  }
  return(0);
}

int readInteger(ifstream *pf){
  int i;
  i=pf->get()<<24;
  i+=pf->get()<<16;
  i+=pf->get()<<8;
  i+=pf->get();
  return(i);
}

void readNext(ifstream *pf){
  int type;
  pf->ignore(4);
  type=pf->get();
  if(type)
    readFile(pf);
  else
    readDirectory(pf);
}

void readDirectory(ifstream *pf){
  int i,nfile,lname;
  char *name;
  pf->ignore(4);
  nfile=readInteger(pf);
  lname=readInteger(pf);
  name=(char*)malloc(lname+1); // Error message missing
  for(i=0;i<lname;i++)
    name[i]=pf->get();
  name[lname]='\0';
  mkdir(name); // Error message missing
  chdir(name);
  free(name);
  for(i=0;i<nfile;i++)
    readNext(pf);
  chdir("..");
}

void readFile(ifstream *pf){
  int i,cflag,csize,size,offset,lname,tmp;
  char *name,*cdata,*data;
  ofstream file;
  cflag=readInteger(pf);
  csize=readInteger(pf);
  size=readInteger(pf);
  pf->ignore(4);
  offset=readInteger(pf);
  lname=readInteger(pf);
  name=(char*)malloc(lname+1); // Error message missing
  for(i=0;i<lname;i++)
    name[i]=pf->get();
  name[lname]='\0';
  cout<<name<<endl;
  tmp=pf->tellg();
  pf->seekg(offset);
  if(cflag){
    z_stream strm;
    strm.zalloc=Z_NULL;
    strm.zfree=Z_NULL;
    strm.opaque=Z_NULL;
    cdata=(char*)malloc(csize);
    data=(char*)malloc(size);
    pf->read(cdata,csize);
    inflateInit(&strm);
    strm.avail_in=csize;
    strm.next_in=cdata;
    strm.avail_out=size;
    strm.next_out=data;
    inflate(&strm,Z_NO_FLUSH);
    inflateEnd(&strm);
    free(cdata);
  } else{
    data=(char*)malloc(size);
    pf->read(data,size);
  }
  file.open(name,ios::out|ios::trunc|ios::binary);
  file.write(data,size);
  pf->seekg(tmp);
  free(data);
  free(name);
  file.close();
}