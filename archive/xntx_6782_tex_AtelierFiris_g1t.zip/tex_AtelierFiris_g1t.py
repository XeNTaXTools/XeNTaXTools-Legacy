from inc_noesis import *

def registerNoesisTypes():
    #handle = noesis.register("Kaizoku Musou 3", ".g1tg;.g1t")
    handle = noesis.register("Atelier Firis", ".g1t")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    if noeStrFromBytes(bs.readBytes(4)) != 'GT1G': return 0
    return 1
	
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.seek(0x8, NOESEEK_ABS)
    filesize = bs.readInt()
    tableOffset = bs.readInt()
    numTexs = bs.readInt() #0x10
    #print(numTexs, "numTexs")
    bs.seek(tableOffset, NOESEEK_ABS)
    for i in range(numTexs):
        texOffset = bs.readInt()
        print(texOffset, "texOffset")
        TMP = bs.tell()
        print(hex(TMP), "start1")
        bs.seek(texOffset + tableOffset, NOESEEK_ABS)
        texName = rapi.getExtensionlessName(rapi.getInputName()) + "_" + str(i)
        print(hex(bs.tell()), "we're here")
        unk = bs.readByte()
        imgFmt = bs.readUByte()             
        print(imgFmt, "imgFmt")
        texSize = bs.readByte()
        print(hex(texSize), "texSize")
        width = texSize & 0x0F
        height = (texSize & 0xF0) // 16
        print(hex(width), "width")
        print(hex(height), "height")
        imgWidth = 2 ** width
        imgHeight = 2 ** height
        print(imgWidth, "x", imgHeight)
        bs.seek(0x4, NOESEEK_REL)
        check = bs.readUByte()
        if check == 0x10:
            bs.seek(0xc, NOESEEK_REL)
        print(hex(bs.tell()), "start2")
        #DXT1
        if imgFmt == 0x59: #6:
            datasize = ((imgWidth * imgHeight) * 4) // 8
        #DXT5
        elif imgFmt == 0x5b: #8:
            datasize = ((imgWidth * imgHeight) * 8) // 8
        print(datasize, "datasize")
        data = bs.readBytes(datasize)      
        print(hex(bs.tell()), "at end")
        #DXT1
        if imgFmt == 0x59: #6:
            texFmt = noesis.NOESISTEX_DXT1
        #DXT5
        elif imgFmt == 0x5b: #8:
            texFmt = noesis.NOESISTEX_DXT5
        #unknown, not handled
        else:
            print("WARNING: Unhandled image format")
            return None
        texList.append(NoeTexture(texName, imgWidth, imgHeight, data, texFmt))
        bs.seek(TMP, NOESEEK_ABS)
    return 1