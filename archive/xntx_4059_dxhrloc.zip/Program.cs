﻿using System;
using System.IO;
using System.Diagnostics;

namespace DeusExHRLoc
{
    class Program
    {
        static void Main(string[] args)
        {
            Process p = Process.GetCurrentProcess();
            string assemblyName = p.ProcessName + ".exe";

            Console.Clear();
            Console.WriteLine("Deus Ex Human Revolution Text file Tool (PC/X360/PS3)\nTom Evin 2014.10.18."); //2011.10.17.
            if (args.Length < 1)
            {
                Console.WriteLine("\nError:\nMissing argument.\n\nUsage: " + assemblyName + " filename.bin");
                Console.WriteLine("\nRepack: Txt and bin need!");
                Console.WriteLine("\nPress Enter to exit");
                Console.Read();
            }
            else
            {
                if (File.Exists(args[0] + ".txt"))
                    ConvertToBin(args[0], assemblyName);
                else
                    ConvertToText(args[0], assemblyName);
                    
            }
        }

        #region Olvasás
        private static void ConvertToText(string filename, string assemblyName)
        {
            try
            {
                try
                {
                    FileStream ins = File.OpenRead(filename);
                    FileStream outs = File.OpenWrite(filename + ".txt");
                    var b = new byte[4];
                    var a = new byte[2];
                    var sor = new byte[2];
                    sor[0] = 0x0d;
                    sor[1] = 0x0a;
                    int notPc = 0;

                    outs.WriteByte(0xef);
                    outs.WriteByte(0xbb);
                    outs.WriteByte(0xbf);

                    ins.Seek(4, SeekOrigin.Begin);
                    ins.Read(b, 0, 4);
                    if (b[3] > 0x00) notPc = 1;
                    if (notPc == 1) Array.Reverse(b);
                    int db = BitConverter.ToInt32(b, 0);
                    int[] offset = new int[db];

                    ins.Seek(4, SeekOrigin.Current);
                    for (int i = 0; i < db-1; i++)
                    {
                        ins.Read(b, 0, 4);
                        if (notPc == 1) Array.Reverse(b);
                        offset[i] = BitConverter.ToInt32(b, 0);
                    }

                    for (int i = 0; i < db-1; i++)
                    {
                        ins.Seek(offset[i], SeekOrigin.Begin);
                        for (; ; )
                        {
                            ins.Read(a, 0, 1);
                            if (a[0] == 0x0a) { a[0] = 0x7c; }
                            if (a[0] == 0x00) { outs.Write(sor, 0, 2); break; }
                            outs.Write(a, 0, 1);
                        }
                    }
                    ins.Close();

                    // clean up
                    outs.Flush();
                    outs.Close();
                    Console.WriteLine("\nDone.");
                    //Console.Read();

                }
                catch (FileNotFoundException exc)
                {
                    Console.WriteLine("\nError:\n" + exc.Message + "\n\nUsage: " + assemblyName + " filename.bin");
                    Console.Read();
                }
                catch (FileLoadException exc)
                {
                    Console.WriteLine(exc.Message);
                    Console.Read();
                }
            }
            catch (IndexOutOfRangeException exc)
            {
                Console.WriteLine(exc.Message);
                Console.Read();
            }
        }
        #endregion

        #region Írás
        private static void ConvertToBin(string filename, string assemblyName)
        {
            try
            {
                File.Delete(filename + "2");
            }
            catch (IndexOutOfRangeException)
            {
                return;
            }
            try
            {
                try
                {
                    FileStream ins = File.OpenRead(filename);
                    FileStream ins2 = File.OpenRead(filename + ".txt");
                    FileStream outs = File.OpenWrite(filename + "2");
                    byte[] b = new byte[4];
                    byte[] a = new byte[2];
                    int k, j, db2 = 0, notPc = 0;

                    ins.Read(b, 0, 4);
                    outs.Write(b, 0, 4);
                    ins.Read(b, 0, 4);
                    if (b[3] > 0x00) notPc = 1;
                    if (notPc == 1) Array.Reverse(b);
                    int db = BitConverter.ToInt32(b, 0);
                    if (notPc == 1) Array.Reverse(b);
                    outs.Write(b, 0, 4);
                    int[] offset = new int[db];
                    int headerSize = 8 + db * 4;

                    ins.Read(b, 0, 4);
                    outs.Write(b, 0, 4);
                    ins.Close();

                    ins2.Seek(0, SeekOrigin.End);
                    int vege = (int)ins2.Position;
                    ins2.Seek(0, SeekOrigin.Begin);

                    ins2.Read(a, 0, 1);
                    if (a[0] == 0xef) { ins2.Seek(3, SeekOrigin.Begin); k = 3; j = 0; }
                    else { ins2.Seek(0, SeekOrigin.Begin); k = 0; j = 0; }

                    for (int i = k; i < vege -1; i++)
                    {
                        ins2.Read(a, 0, 1);
                        j++;
                        if (a[0] == 0x0d)
                        {
                            ins2.Seek(1, SeekOrigin.Current);
                            i++;
                            //new header writing
                            if (offset[db2] == j - 1 && j < vege)
                            {
                                outs.WriteByte(0x00);
                                outs.WriteByte(0x00);
                                outs.WriteByte(0x00);
                                outs.WriteByte(0x00);
                                j--;
                            }
                            else
                            {
                                b = BitConverter.GetBytes(offset[db2] + headerSize);
                                if (notPc == 1) Array.Reverse(b);
                                outs.Write(b, 0, 4);
                            }
                            offset[db2] = j;
                        }
                    }
                    
                    //copy texts
                    ins2.Seek(k, SeekOrigin.Begin);
                    for (int i = k; i < vege; i++)
                    {
                        ins2.Read(a, 0, 1);
                        if (a[0] == 0x0d)
                        {
                            ins2.Seek(1, SeekOrigin.Current);
                            ins2.Read(a, 0, 1);
                            if (a[0] != 0x0d) ins2.Seek(-2, SeekOrigin.Current); //jump over empty line in text
                            else i += 2;
                            ins2.Seek(1, SeekOrigin.Current); outs.WriteByte(0x00);
                            i++;
                        }
                        else
                        {
                            if (a[0] == 0x7c) a[0] = 0x0a;
                            outs.Write(a, 0, 1);
                        }
                    } 
                    ins2.Close();
                    // clean up
                    outs.Flush();
                    outs.Close();
                    Console.WriteLine("\nDone.");
                    //Console.Read();
                }
                catch (FileNotFoundException exc)
                {
                    Console.WriteLine("\nError:\n" + exc.Message + "\n\nUsage: " + assemblyName + " filename.bin");
                    Console.Read();
                }
                catch (FileLoadException exc)
                {
                    Console.WriteLine(exc.Message);
                    Console.Read();
                }
            }
            catch (IndexOutOfRangeException exc)
            {
                Console.WriteLine(exc.Message);
                Console.Read();
            }
        }
        #endregion
    }
}
