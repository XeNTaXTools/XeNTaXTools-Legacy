from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Ridge Racer [PSVita]", ".tex")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
	#noesis.logPopup()
	return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    bs.seek(0xc) 
    headLen = bs.readUShort()
    bs.seek(headLen - 0x10) 
    if noeStrFromBytes(bs.readBytes(4)) != "GIDX": return 0
    return 1
	
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.seek(0x8)
    datasize = bs.readUInt()
    headLen = bs.readUShort()
    bs.seek(0x13)
    imgFmt = bs.readUByte() 
    imgWidth = bs.readUShort()
    imgHeight = bs.readUShort()           
    bs.seek(headLen)        
    data = bs.readBytes(datasize)      
    #DXT5
    if imgFmt == 0x02:
        data = rapi.imageFromMortonOrder(data, imgWidth>>1, imgHeight>>2, 8)
        data = rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_DXT5)
        texFmt = noesis.NOESISTEX_RGBA32
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1