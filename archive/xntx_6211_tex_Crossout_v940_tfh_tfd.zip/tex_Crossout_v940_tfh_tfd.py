from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Crossout (v940)", ".tfh")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    return 1
    
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.readBits(4)
    imgWidth = bs.readBits(12)
    imgHeight = bs.readUShort() // 4
    print(imgWidth, "x", imgHeight)
    bs.readBits(4)
    bs.readBits(4)
    imgFmt2 = bs.readUByte()
    print(hex(imgFmt2), ":imgFmt2")
    imgFmt = bs.readUByte()
    bs.readByte()
    print(hex(imgFmt), ":imgFmt")
    tfdFile = rapi.getExtensionlessName(rapi.getInputName()) + ".tfd"
    print(tfdFile, ":tfd file")
    bs2 = NoeBitStream(rapi.loadIntoByteArray(tfdFile))
    dataStart = bs.readUInt()
    bs.seek(dataStart - 4, NOESEEK_ABS)
    check = bs.readUInt()
    if check == 0:
        bs.seek(-8, NOESEEK_REL)
        check2 = bs.readUInt()
        if check2 == 0:
            bs.seek(-8, NOESEEK_REL)
            check3 = bs.readUInt()
            if check3 == 0:
                bs.seek(-8, NOESEEK_REL)
                check4 = bs.readUInt()
                if check4 == 0:
                    bs.seek(-16, NOESEEK_REL)
                else:
                    bs.seek(-12, NOESEEK_REL)
            else:
                bs.seek(-12, NOESEEK_REL)
        else:
            bs.seek(-12, NOESEEK_REL)
    else:
        bs.seek(-12, NOESEEK_REL)
    mainMipOffset = bs.readUInt()
    print(hex(mainMipOffset), ":mainMipOffset")
    datasize = bs.readUInt()
    imgSize = bs.readUInt() #??
    print(hex(datasize), ":datasize")
    bs2.seek(mainMipOffset, NOESEEK_ABS)        
    data = bs2.readBytes(datasize)      
    #DXT1
    if imgFmt == 0x3b or imgFmt == 0x38 or imgFmt == 0x5b or imgFmt2 == 0x7 or imgFmt2 == 0xb:
        texFmt = noesis.NOESISTEX_DXT1 
        print("DXT1")
    #DXT5
    elif imgFmt == 0x53 or imgFmt == 0x50 or imgFmt2 == 0xa: 
        texFmt = noesis.NOESISTEX_DXT5
        print("DXT5")
    #RGBA32
    elif imgFmt == 0x28 or imgFmt == 0x0 or imgFmt2 == 0x5 or imgFmt2 == 0x8:
        texFmt = noesis.NOESISTEX_RGBA32
        print("RGBA32")
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1