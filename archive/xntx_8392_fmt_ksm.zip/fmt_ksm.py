#by Durik256
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Elsword", ".x")
    noesis.setHandlerTypeCheck(handle, CheckType)
    noesis.setHandlerLoadModel(handle, LoadModel)
    return 1

def CheckType(data):
    if data[:4] != b'KSM ':
        return 0
    return 1

def LoadModel(data, mdlList):
    bs = NoeBitStream(data)
    ctx = rapi.rpgCreateContext()
    bones = []
    
    bs.seek(4)#KSM
    ver = bs.readInt()#?
    fsize = bs.readInt()
    bs.seek(16,1)
    numNodes = bs.readInt()
    
    temp = []
    for x in range(numNodes):
        offset = bs.readInt()
        mat = NoeMat44.fromBytes(bs.readBytes(64)).toMat43()
        unk = bs.read('f3i')#unk, meshOfs, parent, childs?
        temp.append([x,unk[2],unk[3]])
        
        curPos = bs.getOffset()
        bs.seek(offset)
        name = noeStrFromBytes(bs.readBytes(bs.readInt()))
        
        if unk[1]:
            bs.seek(unk[1]+12)
            loadMesh(bs, name)
        
        bs.seek(curPos)
        print(x,unk[2:],name)
        bones.append(NoeBone(x,name,mat))
        
    #Set Parent
    setParent(temp[0], temp, bones, -1)
    
    bones = rapi.multiplyBones(bones)
    mdl = rapi.rpgConstructModel()#NoeModel()
    mdl.setModelMaterials(NoeModelMaterials([], [NoeMaterial('mat_0', '')]))
    mdl.setBones(bones)
    mdlList.append(mdl)
    return 1
    
def setParent(t, temp, bones, p):
    bones[t[0]].parentIndex = p
    if t[1] != -1:
        setParent(temp[t[1]], temp, bones, p)
    if t[2] != -1:
        setParent(temp[t[2]], temp, bones, t[0])
    
def loadMesh(bs, name):
    #0-numMat, 1-matOfs, 2-vnum, 3-vOfs, 4-fnum, 5-fOfs, 6...9 -weight [ofs/num]
    inf = bs.read('10I')
    
    #Material
    '''
    materials = []
    for x in range(inf[0]):
        bs.seek(inf[1])
        color = [NoeVec4.fromBytes(bs.readBytes(16)) for j in range(4)]
        unk, txOfs = bs.readInt(), bs.readInt()
        nameTx = ''
        if txOfs:
            bs.seek(txOfs)
            nameTx = bs.readBytes(bs.readInt()).decode()
        materials.append(NoeMat('mat_%i'%x, nameTx))
    '''
    
    #Mesh
    bs.seek(inf[3])
    vbuf = bs.readBytes(inf[2]*32)
    bs.seek(inf[5])
    ibuf = bs.readBytes(inf[4]*6)
    
    rapi.rpgSetName(name)
    rapi.rpgBindPositionBuffer(vbuf, noesis.RPGEODATA_FLOAT, 32)
    rapi.rpgBindUV1BufferOfs(vbuf, noesis.RPGEODATA_FLOAT, 32, 24)
    rapi.rpgCommitTriangles(ibuf, noesis.RPGEODATA_USHORT, inf[4]*3, noesis.RPGEO_TRIANGLE)