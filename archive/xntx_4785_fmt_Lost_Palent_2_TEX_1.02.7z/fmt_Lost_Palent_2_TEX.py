#Lost Planet 2 [PC] .TEX [PC] - ".TEX" Loader
#By Zaramot
#v1.02

from inc_noesis import *
import subprocess

def registerNoesisTypes():
	handle = noesis.register("Lost Planet 2 [PC]", ".tex")
	noesis.setHandlerTypeCheck(handle, texCheckType)
	noesis.setHandlerLoadRGBA(handle, texLoadDDS)
	noesis.logPopup()
	return 1
		
def texCheckType(data):
	bs = NoeBitStream(data)
	fileMagic = bs.readUInt()
	if fileMagic == 0x584554:
		return 1
	else: 
		print("Fatal Error: Unknown file magic: " + str(hex(fileMagic) + " expected  0x584554!"))
		return 0

def texLoadDDS(data, texList):
    bs = NoeBitStream(data)
	
    fileMagic = bs.readUInt()
    bs.seek(0x10, NOESEEK_ABS) #Texture DXT1 or DXT5
    TexID = bs.readUShort()
    bs.seek(0x14, NOESEEK_ABS) #Entry start
    dataOff = (bs.readUInt())
    ddsName = rapi.getLocalFileName(rapi.getInputName())
    print (ddsName)
    bs.seek(0xC, NOESEEK_ABS) #Entry start
    TWidth = bs.readUShort()
    if TWidth == 0x72:
	    Width = 2048
    elif TWidth == 9216:
	    Width = 1024
    elif TWidth == 8704:
	    Width = 512
    elif TWidth == 8448:
	    Width = 256		
    elif TWidth == 8320:
	    Width = 128
    elif TWidth == 8256:
	    Width = 64
    elif TWidth == 8200:
	    Width = 8
    else:
	    print("WARNING: Unhandled image format " + repr(Width) + "x" + repr(Height))		
    bs.seek(0xA, NOESEEK_ABS) #Entry start
    Height = (bs.readUShort()) // 2
    print (TexID)
    print (Height)
    print (Width)	
    bs.seek(dataOff, NOESEEK_ABS) #Texture start			
    #DXT1
    if TexID == 0x13:
	    texFmt = noesis.NOESISTEX_DXT1
	    ddsSize = (Width * Height * 4) // 8
	    ddsData = bs.readBytes(ddsSize)
    #DXT1
    elif TexID == 0x19:
	    texFmt = noesis.NOESISTEX_DXT1
	    ddsSize = (Width * Height * 4) // 8
	    ddsData = bs.readBytes(ddsSize)
    #DXT5
    elif TexID == 0x17:
	    texFmt = noesis.NOESISTEX_DXT5
	    ddsSize = (Width * Height * 8) // 8
	    ddsData = bs.readBytes(ddsSize)
    #DXT5
    elif TexID == 0x1F:
	    texFmt = noesis.NOESISTEX_DXT5
	    ddsSize = (Width * Height * 8) // 8
	    ddsData = bs.readBytes(ddsSize)
    print (ddsSize)
    tex1 = (NoeTexture(ddsName, Height, Width, ddsData, texFmt))
    texList.append(tex1)

    return 1
	