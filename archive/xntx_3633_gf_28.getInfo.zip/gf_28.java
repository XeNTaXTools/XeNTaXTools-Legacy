
import java.io.*;
import java.util.*;

public class gf_28 {
  
  static int readInt(DataInputStream d) throws IOException {
    byte w[] = new byte[4];
    d.readFully(w,0,4);
    return
      (w[3])      << 24 |
      (w[2]&0xFF) << 16 |
      (w[1]&0xFF) <<  8 |
      (w[0]&0xFF);
  }
  
  static String readString(DataInputStream d, int l) throws IOException {
    String s = "";
    int i;
    for (i=0; i<l; i++) {
      char b = (char) d.readUnsignedByte();
      if (b==0) break;
      s+=b;
    }
    d.skipBytes(l-i-1);
    return s;
  }
  
  public static void main (String [] args) {
    
    try {
      
      String filename;
      
      Scanner scan = new Scanner(System.in);
      if (args.length!=1) {
        System.out.print("\n>");
        filename = scan.next();
      } else {
        filename = args[0];
      }
      
      File f = new File(filename);
      if (!f.exists()) {
        System.out.println("\nFile "+filename+" doesn't exist!");
        System.exit(1);
      }
      
      filename = f.getAbsolutePath();
      
      DataInputStream file =
                new DataInputStream(
                new BufferedInputStream(
                new FileInputStream(filename)));
      
      String id = readString(file, 0x28);
      int header_size = readInt(file);
      file.skipBytes(8);
      int header_unknown = readInt(file);
      file.skipBytes(12);
      String name1 = readString(file, 0x10);
      String font_name = readString(file, readInt(file));
      
      System.out.println("\""+id+"\"\r\n\""+name1+"\"\r\n\""+font_name+"\"\r\n");
      
      int unknown1 = readInt(file);
      int num_entries = readInt(file);
      int size_entry = readInt(file) >> 2;
      int unknown2 = readInt(file);
      int unknown3 = readInt(file);
      int num_files = readInt(file);
      
      for (int i=0; i<num_files; i++) {
          String name = readString(file, readInt(file));
          System.out.println("\""+name+"\""+","+readInt(file)+","+readInt(file)+","+readInt(file)+","+Integer.toHexString(readInt(file)));
      }
      
      int unknown4 = readInt(file);
      int unknown5 = readInt(file);
      System.out.println();
      
      for (int i=0; i<num_entries; i++) {
        for (int j=1; j<size_entry; j++) {
          System.out.print(readInt(file)+",");
        }
        System.out.println(readInt(file));
      }
      
      file.close();
      
    } catch (IOException e) {
      e.printStackTrace();
    } 
  }
}