from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Dragon's Dogma", ".tex")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
	#noesis.logPopup()
	return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    Magic = bs.readBytes(4).decode("ASCII")
    if Magic != "TEX\x00":
        return 0
    return 1
	
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.seek(0x4, NOESEEK_ABS)
    header = bs.read("I" * 3)
    version = header[0] & 0xfff         # First dword
    alpha_flag = (header[0] >> 12) & 0xfff
    shift = (header[0] >> 24) & 0xf
    unk2 = (header[0] >> 28) & 0xf
    mip_count = header[1] & 0x3f        # Second dword
    imgWidth = (header[1] >> 6) & 0x1fff
    imgHeight = (header[1] >> 19) & 0x1fff
    unk3 = header[2] & 0xff             # Third dword
    imgFmt = (header[2] >> 8) & 0xff
    unk4 = (header[2] >> 16) & 0x1fff
    dataStart = bs.readUInt()
    datasize = bs.readUInt() - dataStart
    bs.seek(dataStart, NOESEEK_ABS)        
    data = bs.readBytes(datasize)      
    #DXT1
    if imgFmt == 0x13 or imgFmt == 0x14 or imgFmt == 0x19:
        texFmt = noesis.NOESISTEX_DXT1
    #DXT5
    elif imgFmt == 0x18 or imgFmt == 0x1f or imgFmt == 0x25 or imgFmt == 0x2f:
        texFmt = noesis.NOESISTEX_DXT5
    #RGBA
    elif imgFmt == 0x28:
        texFmt = noesis.NOESISTEX_RGBA32
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1