/*****************************************************************************
 *
 * SurRender - Real-Time 3D Graphics Library
 * -----------------------------------------
 *
 * (C) 1994-1998 Hybrid Holding, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Holding, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irrepairable harm to
 * Hybrid Holding and legal action against the party in breach.
 *
 * Desc:	MAX model instance
 *
 * $Archive: /srsdk1x/include/misc/hximporter/srMAXModelInstance.hpp $
 * $Author: samuli $ 
 * $Revision: #1 $
 * $Modtime: 11/09/98 9:45p $
 * $Date: 2003/01/08 $
 * 
 *****************************************************************************/


#ifndef __MAXMODELINSTANCE_HPP_INCLUDED
#define __MAXMODELINSTANCE_HPP_INCLUDED

#include "srModelInstance.hpp"
#include "srHXTypes.hpp"

#pragma SRPACKPUSH

/******************************************************************************
 *
 * Class:			srMAXModelInstance
 *
 * Description:		Basic ModelInstance with local translation and rotation
 *					extensions.
 *
 * Notes:			Alignment not supported.
 *
 ******************************************************************************/

class SRHXDEC srMAXModelInstance : public srClassSupport<srMAXModelInstance, srModelInstance, false, srHX::ID_MAX_MODEL_INSTANCE>
{
public:
	srMAXModelInstance(srNode* parent = NULL);

	srMAXModelInstance& operator=(const srMAXModelInstance& src)
	{
		srModelInstance::operator=(src);
		localRotation		= src.localRotation;
		localTranslation	= src.localTranslation;
		return *this;
	}
	srClass*					vInstance()									{ return new srMAXModelInstance; }
	static SRCSTRING			sGetClassName()								{ return "srMAXModelInstance"; }
	void						dump(srOStream &str);

	void						process (const ProcessInfo& pInfo, e_processType type);
	void						setLocalRotation(const srMatrix3& mtx)		{ localRotation = mtx;		}
	void						setLocalTranslation(const srVector3& loc)	{ localTranslation = loc;	}
	void						getLocalRotation(srMatrix3& mtx)			{ mtx = localRotation;		}
	srVector3					getLocalTranslation()						{ return localTranslation;	}

	void						setTime(double time);

protected:
	~srMAXModelInstance()		{ };

	srMatrix3					localRotation;
	srVector3					localTranslation;
private:
};


#pragma SRPACKPOP

#endif //		__MAXMODELINSTANCE_HPP_INCLUDED