/*****************************************************************************
 *
 * SurRender - Real-Time 3D Graphics Library
 * -----------------------------------------
 *
 * (C) 1994-1998 Hybrid Holding, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Holding, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irrepairable harm to
 * Hybrid Holding and legal action against the party in breach.
 *
 * Desc:	morph object
 *
 * $Archive: /srSDK1x/include/misc/hximporter/srMAXMorphModel.hpp $
 * $Author: samuli $ 
 * $Revision: #1 $
 * $Modtime: 9/21/99 3:09p $
 * $Date: 2003/01/08 $
 * 
 *****************************************************************************/


#ifndef __SRMAXMORPHMODEL_HPP_INCLUDED
#define __SRMAXMORPHMODEL_HPP_INCLUDED

#include "srHXTypes.hpp"
#include "srMeshModel.hpp"

/*
#include "srMAXModifier.hpp"
*/
#pragma SRPACKPUSH

/******************************************************************************
 *
 * Class:			srMAXMorphModel
 *
 * Description:		Basic srMeshModel with vertex location morphing extension.
 *
 ******************************************************************************/
class SRHXDEC srMAXMorphModel : public srClassSupport<srMAXMorphModel, srMeshModel, false, srHX::ID_MAX_MORPH_MODEL>
{
public:
	struct MorphKey
	{
		SRDWORD		target;				// morph target index
		float		time;				// time
	};

								srMAXMorphModel();
								~srMAXMorphModel();
	srClass*					vInstance()									{ return new srMAXMorphModel; }
	static SRCSTRING			sGetClassName()								{ return "srMAXMorphModel"; }
	void						dump(srOStream &str);
	srMAXMorphModel&			operator=(const srMAXMorphModel& src);

	SRDWORD			getTargetCount()						{ return numTargets; }

	void			setTargetCount(SRDWORD nTargets = 1);
	srVector3*		getTargetVertexLocation(SRDWORD targetIndex = 0);
	
	SRDWORD			getKeyCount()							{ return numKeys;	}
	void			setKeyCount(SRDWORD morphKeys );
	void			setMorphKey(SRDWORD ndx, const MorphKey& key);

	void			setTime(double t)						{ time = t; }

	virtual	void	calculateBounds();
	virtual	void	render					(srGERD& gerd);
	virtual void	reindexVertices			(const SRDWORD* remap);

	
	// modifier stuff
	void			setOriginalVertices(srVector3* v)		{ vertices.resize(getVertexCount()); for(SRLONG i = 0; i < getVertexCount(); i++) vertices[i] = v[i]; }
/*	void			setModifier(SRDWORD, srMAXModifier* m)			{ modifier = m; }
	srMAXModifier*	getModifier(SRDWORD)							{ return modifier; }
*/
protected:

	void			interpolateVertexLoc();
	void			cubicInterpolateVertexLoc();

	SRDWORD			numTargets;				// number of morph targets
	SRDWORD			numKeys;				// number of morph keys
	double			time;					// time 
	srVector3**		vertexLoc;				// target vertex location arrays
	MorphKey*		morphKeys;				// morph key array

	// 'modifier stack'
//	srMAXModifier*			modifier;
	srArray<srVector3>		vertices;

private:
};

#pragma SRPACKPOP

#endif		// __SRMAXMORPHMODEL_HPP_INCLUDED