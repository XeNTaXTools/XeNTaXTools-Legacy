/*****************************************************************************
 *
 * SurRender - Real-Time 3D Graphics Library
 * -----------------------------------------
 *
 * (C) 1994-1998 Hybrid Holding, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Holding, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irrepairable harm to
 * Hybrid Holding and legal action against the party in breach.
 *
 * Desc:	MAX model instance
 *
 * $Archive: /srSDK1x/sources/misc/hximporter/srMAXModelInstance.cpp $
 * $Author: samuli $ 
 * $Revision: #1 $
 * $Modtime: 9/10/99 2:47p $
 * $Date: 2003/01/08 $
 * 
 *****************************************************************************/

#include "srModelInstance.hpp"
#include "srMAXModelInstance.hpp"
#include "srMAXMorphModel.hpp"
#include "srIO.hpp"
#include "srMathIO.hpp"
#include "srGERD.hpp"
#include "srMatrix4.hpp"
#include "srVector3.hpp"
#include "srStatisticsManager.hpp"

/******************************************************************************
 *
 * Function:		srMAXModelInstance::srMAXModelInstance(srNode* parent)
 *
 * Description:		constructor
 *
 * Parameters:		parent		= parent node
 *					
 * Notes:			Resets local transformation to identity rotation and zero
 *					translation.
 *
 ******************************************************************************/

srMAXModelInstance::srMAXModelInstance(srNode* parent)
{
	setParent(parent);
	localRotation.ident();
	localTranslation.make(0.f, 0.f, 0.f);
}

/******************************************************************************
 *
 * Function:		srMAXModelInstance::process()
 *
 * Description:		Model instance processing function
 *
 * Parameters:		pInfo	= reference to process info structure
 *					type	= process type (PROCESS in this case)
 *
 * Notes:			This function sends matrix manipulation commands
 *					to GERD to orientate the model properly and then
 *					calls the model's srModel::render() function.
 *
 *					process() function is extended from srModelInstance
 *					to apply local rotation and translation (neither
 *					inherited in scene hierarchy).
 *
 ******************************************************************************/

void srMAXModelInstance::process (const ProcessInfo& pInfo, e_processType type)
{
	srGERD*		gerd = &(pInfo.gerd);
	srAssert (type == PROCESS && getModel() && gerd);	// should never get PUSH/POP etc..

	srCore.getStatisticsManager()->increaseMeshTraversed ();

	// notice, this call will set matrix mode to srGERD::MODELVIEW
	applyWorldSpaceMatrix(pInfo.gerd);					// push/multiply current world space matrix

	srMatrix4d	m;
	m.ident();

	srMatrix4d trns;
	trns.ident();
	trns.setTranslation(localTranslation);

	m.setMatrix3(localRotation);
	gerd->multMatrix(trns);
	gerd->multMatrix(m);								// multiply modelview matrix

	if (exclusionMask)
	{
		SRDWORD oldMask = gerd->getExclusionMask();
		gerd->setExclusionMask (oldMask | exclusionMask);
		getModel()->render	(pInfo.gerd);						// send rendering command to model
		gerd->setExclusionMask (oldMask);
	} else
		getModel()->render (pInfo.gerd);

	gerd->popMatrix();									// pop modelview matrix
}

/******************************************************************************
 *
 * Function:		srMAXModelInstance::setTime(double t)
 *
 * Description:		Set animation time [0,1]
 *
 * Parameters:		t	= time
 *
 ******************************************************************************/
void srMAXModelInstance::setTime(double t)
{
	srMAXMorphModel* m = (srMAXMorphModel*)getModel();
	if(m->getClassID() == srHX::ID_MAX_MORPH_MODEL)
	{
		m->setTime(t);
	}
}


/******************************************************************************
 *
 * Function:		srMAXModelInstance::dump()
 *
 * Description:		Dumps the contents of the class to stream
 *
 * Parameters:		str	= output stream
 *
 ******************************************************************************/

void srMAXModelInstance::dump(srOStream &str)
{
	srModelInstance::dump(str);

	long oldflags = str.flags();
	str.setf(std::ios::left, std::ios::adjustfield);
	str.width(DUMP_FIELD_WIDTH);
	str << "  LocalTM Rotation: " << localRotation;
	str.width(DUMP_FIELD_WIDTH);
	str << std::endl;
	str << "  LocalTM Translation: " << localTranslation;
	str.flags(oldflags);
}

