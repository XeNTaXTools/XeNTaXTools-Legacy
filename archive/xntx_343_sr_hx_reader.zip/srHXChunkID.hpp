#ifndef __SRHXCHUNKID_HPP_INCLUDED
#define __SRHXCHUNKID_HPP_INCLUDED
/*****************************************************************************
 *
 * SurRender - Real-Time 3D Graphics Library
 * -----------------------------------------
 *
 * (C) 1994-1998 Hybrid Holding, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Holding, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irrepairable harm to
 * Hybrid Holding and legal action against the party in breach.
 *
 *
 * Desc: SurRender3D HX-file format chunk id enums
 * 
 * $Archive: /srSDK1x/include/misc/hximporter/srHXChunkID.hpp $
 * $Author: samuli $
 * $Revision: #1 $
 * $Modtime: 8/25/99 5:33p $
 * $Date: 2003/01/08 $
 *
 *****************************************************************************/


enum e_srHXChunkID
{
	HXCHNK_MAGIC											= 0xBABECAFE,

		HXCHNK_PROPERTIES									= 0x5000,
			HXCHNK_UNIT_SCALE								= 0x5001,

		HXCHNK_MATERIAL_LIBRARY								= 0x2000,
			HXCHNK_MATERIAL									= 0x2100,
				HXCHNK_MATERIAL_HEADER						= 0x2110,

			// 
			HXCHNK_MATERIAL_VERTEX							= 0x2410,			// vertex material
			HXCHNK_MATERIAL_SHADER							= 0x2420,			// polygon shader
			HXCHNK_MATERIAL_TEXTURE							= 0x2430,			// polygon texture
				HXCHNK_MATERIAL_TEXTURE_HEADER				= 0x2431,			// polygon texture
				HXCHNK_MATERIAL_TEXTURE_FILENAME			= 0x2432,

		HXCHNK_MODEL_LIBRARY								= 0x1000,
			HXCHNK_OBJECT									= 0x1001,
				HXCHNK_OBJECT_HEADER						= 0x1002,
				HXCHNK_OBJECT_NAME							= 0x1003,
			
				HXCHNK_TRIMESH								= 0x1100,
					HXCHNK_TRIMESH_HEADER					= 0x1110,
					HXCHNK_TRIMESH_MORPH_TARGETS_HEADER		= 0x1131,
					HXCHNK_TRIMESH_MORPH_KEYFRAMES_HEADER	= 0x1132,
					HXCHNK_TRIMESH_MORPH_KEYFRAME_ARRAY		= 0x1133,

					HXCHNK_TRIMESH_VERTEXLOC				= 0x1111,
					HXCHNK_TRIMESH_POLYVERTEX				= 0x1112,
					HXCHNK_TRIMESH_VERTEXUVW				= 0x1113,
					HXCHNK_TRIMESH_VERTEX_SHADE_REMAP		= 0x1114,
					HXCHNK_TRIMESH_PASS_ARRAYS				= 0x1120,
						HXCHNK_TRIMESH_PASS_HEADER			= 0x1121,
						HXCHNK_TRIMESH_VERTEX_MATERIAL_ARRAY= 0x1122,
						HXCHNK_TRIMESH_TEXTURE_ARRAY		= 0x1123,
						HXCHNK_TRIMESH_SHADER_ARRAY			= 0x1124,
						HXCHNK_TRIMESH_VERTEX_COLOR_ARRAY	= 0x1125,


					HXCHNK_MODIFIER										= 0x1400,
						HXCHNK_MODIFIER_HEADER							= 0x1401,
						HXCHNK_MODIFIER_MORPHER							= 0x1410,
							HXCHNK_MODIFIER_MORPHER_HEADER				= 0x1411,
							HXCHNK_MODIFIER_MORPHER_ORIG_VERTICES		= 0x1412,
							HXCHNK_MODIFIER_MORPHER_CHANNEL				= 0x1413,
								HXCHNK_MODIFIER_MORPHER_CHANNEL_HEADER	= 0x1414,
								HXCHNK_MODIFIER_MORPHER_CHANNEL_VINDEX	= 0x1415,
								HXCHNK_MODIFIER_MORPHER_CHANNEL_VDELTA	= 0x1146,
								HXCHNK_MODIFIER_MORPHER_CHANNEL_CONTROLLER= 0x1147,


					HXCHNK_KEYFRAME_CONTROLLER					= 0x3000,
						HXCHNK_KEYFRAME_CONTROLLER_HEADER		= 0x3001,
						HXCHNK_KEYFRAME_CONTROLLER_KEY_ARRAY	= 0x3002,



				HXCHNK_LIGHT								= 0x1200,
					HXCHNK_LIGHT_HEADER						= 0x1210,

				HXCHNK_CAMERA								= 0x1300,
					HXCHNK_CAMERA_HEADER					= 0x1310,


		HXCHNK_SCENE										= 0x4000,
			HXCHNK_NODE										= 0x4100,
				HXCHNK_NODE_HEADER							= 0x4101,
				HXCHNK_NODE_TRANSFORM						= 0x4102,
				HXCHNK_NODE_CHILD_ID_ARRAY					= 0x4103,	
				HXCHNK_NODE_NAME							= 0x4104,
				HXCHNK_NODE_LOCAL_TRANSFORM					= 0x4105,			// apply only to object (not inherited)

				HXCHNK_NODE_MODEL							= 0x4110,
					HXCHNK_NODE_MODEL_HEADER				= 0x4111,

				HXCHNK_NODE_CAMERA							= 0x4121,

				HXCHNK_NODE_LIGHT							= 0x4132,
					HXCHNK_NODE_LIGHT_HEADER				= 0x4130
			
};



#endif	// __SRHXCHUNKID_HPP_INCLUDED

