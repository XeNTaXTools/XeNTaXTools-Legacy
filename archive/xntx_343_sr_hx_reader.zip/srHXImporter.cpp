
/*****************************************************************************
 *
 * SurRender - Real-Time 3D Graphics Library
 * -----------------------------------------
 *
 * (C) 1994-1999 Hybrid Holding, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Holding, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irrepairable harm to
 * Hybrid Holding and legal action against the party in breach.
 *
 *
 * Desc:	SurRender HX-file importer
 *
 * $Archive: /srSDK1x/sources/misc/hximporter/srHXImporter.cpp $
 * $Author: samuli $
 * $Revision: #1 $
 * $Modtime: 10.05.99 21:10 $
 * $Date: 2003/01/08 $
 *
 *****************************************************************************/


#include "srTexture.hpp"
#include "srHXImporter.hpp"
#include "srDLLInit.inl"
#include "srIO.hpp"

/******************************************************************************
 *
 * Function:		srHXImporter::srHXImporter()
 *
 * Description:		constructor
 *
 ******************************************************************************/
srHXImporter::srHXImporter()
{
	registerLoaders();

	unitScale	= 1.0;
	unitType	= srHX::UNIT_METERS; 
}

/******************************************************************************
 *
 * Function:		srHXImporter::~srHXImporter()
 *
 * Description:		destructor
 *
 ******************************************************************************/
srHXImporter::~srHXImporter()
{
	unregisterLoaders();

	for(SRDWORD i = 0; i < shaderLookup.getElements(); i++)
		delete shaderLookup[i];
}

/******************************************************************************
 *
 * Function:		srHXImporter::importScene()
 *
 * Description:		Import the whole file
 *
 * Parameters:		scene		= srScene to use as parent for all read nodes
 *					inputStream	= binary stream to use for importing
 *
 ******************************************************************************/
void srHXImporter::importScene(srScene* scene, srBinIStream& inputStream)
{
	// set input stream:
	setStream(&inputStream);

	// get input file size:
	int o = inputStream.tell();
	inputStream.seek(0, srBinStream::END);
	int fSize = inputStream.tell();
	inputStream.seek(o, srBinStream::BEGIN);

	parentScene = scene;
	// read it:
	readChunks(fSize, 1);
}

/******************************************************************************
 *
 * Function:		srHXImporter::getUnitScale()
 *
 * Description:		Query the file's unit scale
 *
 * Returns:			srHXImporter::UnitScale structure containing 
 *					the modeler program's master scale and unit type.
 *
 ******************************************************************************/
srHXImporter::UnitScale srHXImporter::getUnitScale()
{
	UnitScale foo; 
	foo.scale = (SRDWORD)unitScale;  
	foo.type = (srHX::e_unittype)unitType; 
	return foo; 
}

	
