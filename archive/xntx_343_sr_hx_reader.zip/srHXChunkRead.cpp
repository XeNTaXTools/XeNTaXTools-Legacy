/*****************************************************************************
 *
 * SurRender - Real-Time 3D Graphics Library
 * -----------------------------------------
 *
 * (C) 1994-1998 Hybrid Holding, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Holding, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irrepairable harm to
 * Hybrid Holding and legal action against the party in breach.
 *
 *
 * Desc: SurRender3D HX-file reader
 *
 * $Archive: /srSDK1x/sources/misc/hximporter/srHXChunkRead.cpp $
 * $Author: samuli $
 * $Revision: #1 $
 * $Modtime: 10.05.99 21:10 $
 * $Date: 2003/01/08 $
 *
 *****************************************************************************/

#include "srHXChunkRead.hpp"


/******************************************************************************
 *
 * Function:		void srHXChunkRead::~srHXChunkRead()
 *
 * Description:		constructor
 *
 ******************************************************************************/
srHXChunkRead::srHXChunkRead()
{
	stream = NULL;
}

/******************************************************************************
 *
 * Function:		void srHXChunkRead::~srHXChunkRead()
 *
 * Description:		destructor
 *
 ******************************************************************************/
srHXChunkRead::~srHXChunkRead()
{
}

/******************************************************************************
 *
 * Function:		void srHXChunkRead::get(srVector3* arr, SRDWORD count)
 *
 * Description:		Read a srVector3 array
 *
 * Parameters:		arr		= srVector3 array
 *					count	= number of elements to read
 *
 ******************************************************************************/
void srHXChunkRead::get(srVector3* arr, SRDWORD count)
{
	SRDWORD* f = (SRDWORD*)arr;
	for(SRDWORD i = 0; i < count * 3; i++)
		*stream >> f[i];
}

/******************************************************************************
 *
 * Function:		void srHXChunkRead::get(srVector3i* arr, SRDWORD count)
 *
 * Description:		Read a srVector3i array
 *
 * Parameters:		arr		= srVector3i array
 *					count	= number of elements to read
 *
 ******************************************************************************/
void srHXChunkRead::get(srVector3i* arr, SRDWORD count)
{
	SRDWORD* f = (SRDWORD*)arr;
	for(SRDWORD i = 0; i < count * 3; i++)
		*stream >> f[i];
}

/******************************************************************************
 *
 * Function:		void srHXChunkRead::getString()
 *
 * Description:		Read a string
 *
 ******************************************************************************/
SRCHAR* srHXChunkRead::getString()
{
	SRCHAR* str = new SRCHAR[getCurChunkDataSize()];
	stream->read(str, getCurChunkDataSize());
	return str;
}


/******************************************************************************
 *
 * Function:		void srHXChunkRead::readChunks()
 *
 * Description:		Recursive chunk reader
 *
 ******************************************************************************/
void srHXChunkRead::readChunks(int nextChunk, int level)
{
	struct Foo
	{
		SRDWORD cID;
		ReadFunc read;
		ReadFunc postRead;
	};

	while((int)(stream->tell()) < nextChunk)
	{
		Chunk chnk;
		chnk.get(*stream);
		curChunkDataSize = chnk.dataSize;

		int fpos = stream->tell();

		ReaderDef* r = readerHash.get(chnk.id);
		if(r)
		{
//			srOut << "\n";
//			for(int i = 0; i < level; i++) srOut << "- ";
//			srOut << "id = " << std::hex << chnk.id << std::dec;

			// DEBUG DEBUG kludge!
			Foo a = *(Foo*)r;

			if(a.read)
				(this->*a.read)();

			// advance to the end of this chunk:
			if(fpos + chnk.dataSize > stream->tell()) 
				stream->seek((fpos + chnk.dataSize) - stream->tell(), srBinStream::CURRENT);

			// enter subchunk
			if(chnk.nextChunk >= stream->tell())
				readChunks(chnk.nextChunk, level + 1);

			// call chunk post process function (after all subchunks are read):
			if(a.postRead)
				(this->*a.postRead)();
		}

		// advance to the end of this chunk:
		if(fpos + chnk.dataSize > stream->tell()) 
			stream->seek((fpos + chnk.dataSize) - stream->tell(), srBinStream::CURRENT);
	}
}

