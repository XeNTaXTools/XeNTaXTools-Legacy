
#ifndef __SRMAXBEZCONTROLLER_HPP_INCLUDED
#define __SRMAXBEZCONTROLLER_HPP_INCLUDED

#include "srArray.hpp"

class srMAXBezController
{
public:
	enum e_flags
	{
		HYBRID_SMOOTH		= 1,
		HYBRID_LINEAR		= 2,
		HYBRID_USER			= 4,
		HYBRID_FAST			= 8,
		HYBRID_SLOW			= 16,
		HYBRID_STEP			= 32,
		HYBRID_MAX			= 64
	};

	enum
	{
		KEY_CONSTVELOCITY	= 1 << 12
	};

	
	struct Key
	{
		Key()
		{
			flags = 0;
			setInTanType(HYBRID_SMOOTH);
			setOutTanType(HYBRID_SMOOTH);
		}

		void		setInTanType(e_flags t)	{ int a = flags & ~(HYBRID_MAX-1); a |= t; flags = a;}
		void		setOutTanType(e_flags t){ int a = flags & (~((HYBRID_MAX-1)<<6)); a |= t<<6; flags = a;}

		float		time;
		SRDWORD		flags;
//		srVector3	value;
//		srVector3	inTan;
//		srVector3	outTan;
	};


	float			getValue(float time);



	SRDWORD			GetInTanType(SRDWORD f)		{ return f & (HYBRID_MAX-1); }
	SRDWORD			GetOutTanType(SRDWORD f)	{ return (f>>6) & (HYBRID_MAX-1); }

	float&			Value(int i, int j)			{ return values[j][i]; }
	float&			InTan(int i, int j)			{ return inTangents[j][i]; }
	float&			OutTan(int i, int j)		{ return outTangents[j][i]; }
	float			Time(int i)					{ return keys[i].time;		}
	SRDWORD&		KFlags(int i)				{ return keys[i].flags; }

	int				getKeyIndex(float t)
	{
		for(int i=0; i < NKeys(); i++) 
		{
			int n = i == (NKeys()-1) ? i : i + 1;
			if(t < keys[n].time && keys[i].time <= t)
				return i;
		}
		return -1;
	}


	srMAXBezController();


	// foo
	void			CompAdjBesselBezPoints(int i);
	void			BesselEnd(int i);
	void			BesselStart(int i);
	void			LinearIn(int i);
	void			LinearOut(int i);
	void			FastIn(int i);
	void			FastOut(int i);
	void			SlowIn(int i);
	void			SlowOut(int i);
	void			StepIn(int i);
	void			StepOut(int i);
	float			ArcLengthTo(int n0, int n1, float tou);
	void			InterpConstVelocity(int n0, int n1, float d, float *val);
	void			UpdateConstVelocity(int i);
	void			PrepareTrack();
	float			DU(int n0,int n1);
	void			InterpValue(int n0, int n1, float u, float *val);

	SRBOOL			Closed()	{ return false;}

	float			getRangeStart()			{ return rangeStart; }
	float			getRangeEnd()			{ return rangeEnd;   }



	void			setNumElements(int n)	
	{
		nElems = n;
		values.resize(n);
		inTangents.resize(n);
		outTangents.resize(n);
	}
	void			setNumKeys(SRDWORD nk)
	{
		nKeys = nk;
		for(SRDWORD i = 0; i < (SRDWORD)nElems; i++)
		{
			values[i].resize(nk);
			inTangents[i].resize(nk);
			outTangents[i].resize(nk);
		}
		keys.resize(nk);
	}

	// data
	int				nElems;
	int				nKeys;

	int				NKeys()			{ return nKeys; }
	srArray<Key>	keys;
	float			rangeStart;
	float			rangeEnd;

	srArray< srArray<float> >	values;
	srArray< srArray<float> >	inTangents;
	srArray< srArray<float> >	outTangents;
};





#endif	// __SRMAXBEZCONTROLLER_HPP_INCLUDED


