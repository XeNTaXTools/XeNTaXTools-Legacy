
/*****************************************************************************
 *
 * SurRender - Real-Time 3D Graphics Library
 * -----------------------------------------
 *
 * (C) 1994-1999 Hybrid Holding, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Holding, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irrepairable harm to
 * Hybrid Holding and legal action against the party in breach.
 *
 *
 * Desc: SurRender3D HX-file reader
 *
 * $Archive: /srSDK1x/sources/misc/hximporter/srHXReaders.cpp $
 * $Author: samuli $
 * $Revision: #1 $
 * $Modtime: 9/21/99 3:10p $
 * $Date: 2003/01/08 $
 *
 *****************************************************************************/


#include "srHXChunkID.hpp"
#include "srHXImporter.hpp"
#include "srEnvironmentMapper.hpp"
#include "srTextureFile.hpp"
#include "srMAXModelInstance.hpp"
#include "srCamera.hpp"
#include "srLight.hpp"
#include "sruModelOptimizer.hpp"

typedef	void (srHXImporter::*RFunc)();

struct R
{
	SRDWORD id;
	RFunc	read;
	RFunc	postRead;
	
	R(SRDWORD i, RFunc r, RFunc pr)	{ id = i; read = r; postRead = pr; }
};

void srHXImporter::registerLoaders()
{
	// DEBUG DEBUG not a very elegant way of getting member function pointers and casting
	// them to void* pointers!!! 
#define INS(id, r, pr) temp[temp.getElements()] = new R((SRDWORD)id, r, pr); readerHash.insert((SRDWORD)id, (srHXChunkRead::ReaderDef*)temp[temp.getElements()-1]);

	INS(HXCHNK_MAGIC,											NULL,						NULL);
	INS(	HXCHNK_PROPERTIES,									NULL,						NULL);
	INS(		HXCHNK_UNIT_SCALE,								readUnitScale,				NULL);

	INS(	HXCHNK_MATERIAL_LIBRARY,							readMaterialLibrary,		NULL);
	INS(		HXCHNK_MATERIAL_VERTEX,							readVertexMaterial,			NULL);
	INS(		HXCHNK_MATERIAL_TEXTURE,						readMaterialTexture,		NULL);
	INS(			HXCHNK_MATERIAL_TEXTURE_HEADER,				readMaterialTextureHeader,	NULL);
	INS(			HXCHNK_MATERIAL_TEXTURE_FILENAME,			readMaterialTextureFname,	NULL);
	INS(		HXCHNK_MATERIAL_SHADER,							readMaterialShader,			NULL);

	INS(	HXCHNK_MODEL_LIBRARY,								readObjects,				NULL);
	INS(		HXCHNK_OBJECT,									NULL,						postReadObject);
	INS(			HXCHNK_OBJECT_HEADER,						readObjectHeader,			NULL);
	INS(			HXCHNK_OBJECT_NAME,							readObjectName,				NULL);
	INS(			HXCHNK_TRIMESH,								readTrimesh,				postReadTrimesh);
	INS(				HXCHNK_TRIMESH_HEADER,					readTrimeshHeader,			NULL);
	INS(				HXCHNK_TRIMESH_VERTEXLOC,				readTrimeshVertexLoc,		NULL);
	INS(				HXCHNK_TRIMESH_MORPH_TARGETS_HEADER,	readTrimeshMTgtHdr,			NULL);
	INS(				HXCHNK_TRIMESH_MORPH_KEYFRAMES_HEADER,	readTrimeshMKeyHdr,			NULL);
	INS(				HXCHNK_TRIMESH_MORPH_KEYFRAME_ARRAY,	readTrimeshMKeyArray,		NULL);
	INS(				HXCHNK_TRIMESH_POLYVERTEX,				readTrimeshPolyVertex,		NULL);
	INS(				HXCHNK_TRIMESH_VERTEX_SHADE_REMAP,		readTrimeshVertexShadeRemap,NULL);
	INS(				HXCHNK_TRIMESH_PASS_ARRAYS,				readTrimeshPassArrays,		NULL);
	INS(					HXCHNK_TRIMESH_PASS_HEADER,			readTrimeshPassHeader,		NULL);
	INS(					HXCHNK_TRIMESH_VERTEXUVW,			readTrimeshVertexUVW,		NULL);
	INS(					HXCHNK_TRIMESH_VERTEX_MATERIAL_ARRAY,	readTrimeshMtlArray,NULL);
	INS(					HXCHNK_TRIMESH_TEXTURE_ARRAY,		readTrimeshTexArray,		NULL);
	INS(					HXCHNK_TRIMESH_SHADER_ARRAY,		readTrimeshShaderArray,		NULL);
	INS(					HXCHNK_TRIMESH_VERTEX_COLOR_ARRAY,	readTrimeshVxColorArray,	NULL);
	INS(				HXCHNK_MODIFIER,						readModifier,				NULL);
	INS(					HXCHNK_MODIFIER_HEADER,				NULL,						NULL);
	INS(					HXCHNK_MODIFIER_MORPHER,			readMorphModifier,			NULL);
	INS(						HXCHNK_MODIFIER_MORPHER_HEADER,	readMorphModifierHeader,	NULL);
	INS(						HXCHNK_MODIFIER_MORPHER_ORIG_VERTICES, readMorphModifierOrigVertices, NULL);
	
	INS(						HXCHNK_MODIFIER_MORPHER_CHANNEL,readMorphModifierChannel,	postReadMorphModifierChannel);
	INS(						HXCHNK_MODIFIER_MORPHER_CHANNEL_HEADER,readMorphModifierChannelHeader,	NULL);
	INS(						HXCHNK_MODIFIER_MORPHER_CHANNEL_VINDEX,readMorphModifierChannelVIndex,	NULL);
	INS(						HXCHNK_MODIFIER_MORPHER_CHANNEL_VDELTA,readMorphModifierChannelVDeltas,	NULL);

	INS(				HXCHNK_KEYFRAME_CONTROLLER,				readKFController,			NULL);
	INS(					HXCHNK_KEYFRAME_CONTROLLER_HEADER,		readKFControllerHeader,		NULL);
	INS(					HXCHNK_KEYFRAME_CONTROLLER_KEY_ARRAY,	readKFControllerKeys,		NULL);

	
	INS(			HXCHNK_CAMERA,								NULL,						NULL);
	INS(				HXCHNK_CAMERA_HEADER,					readCameraHeader,			NULL);
	INS(			HXCHNK_LIGHT,								readLight,					NULL);
	INS(				HXCHNK_LIGHT_HEADER,					readLightHeader,			NULL);
	
	INS(	HXCHNK_SCENE,										readSceneGraph,				postReadSceneGraph);
	INS(		HXCHNK_NODE,									readNode,					postReadNode);
	INS(			HXCHNK_NODE_HEADER,							readNodeHeader,				NULL);
	INS(			HXCHNK_NODE_TRANSFORM,						readNodeTransform,			NULL);
	INS(			HXCHNK_NODE_LOCAL_TRANSFORM,				readNodeLocalTransform,		NULL);
	INS(			HXCHNK_NODE_NAME,							readNodeName,				NULL);
	INS(			HXCHNK_NODE_CHILD_ID_ARRAY,					readNodeChildIDArray,		NULL);
	INS(			HXCHNK_NODE_MODEL,							readNodeModel,				NULL);
	INS(				HXCHNK_NODE_MODEL_HEADER,				readNodeModelHeader,		NULL);
	INS(			HXCHNK_NODE_CAMERA,							readNodeCamera,				NULL);
	INS(			HXCHNK_NODE_LIGHT,							readNodeLight,				NULL);
	INS(				HXCHNK_NODE_LIGHT_HEADER,				readNodeLightHeader,		NULL);
#undef INS
}

void srHXImporter::unregisterLoaders()
{
	// DEBUG DEBUG kludge kludge
	for(SRDWORD i = 0; i < temp.getElements(); i++)
	{
		srHXChunkRead::ReaderDef* foo = (srHXChunkRead::ReaderDef*)temp[i];
		delete foo;
	}
}


//////////////////////////////////////////////////////////////////////////////////////
// properties importing
//////////////////////////////////////////////////////////////////////////////////////

void srHXImporter::readUnitScale()
{
	*stream >> unitType;
	*stream >> unitScale;
}


//////////////////////////////////////////////////////////////////////////////////////
// material importing
//////////////////////////////////////////////////////////////////////////////////////

struct MaterialHeader
{
	SRDWORD		refID;

	srVector3	diffuseColor;
	srVector3	specularColor;
	srVector3	emissiveColor;
	srVector3	ambientColor;
	float		shininess;
	float		opacity;
	float		translucency;
	SRDWORD		flags;

	void		get(srBinIStream* in)
	{
		int i;
		*in >> refID;
		for(i = 0; i < 3; i++)
			*in >> diffuseColor[i];
		for(i = 0; i < 3; i++)
			*in >> specularColor[i];
		for(i = 0; i < 3; i++)
			*in >> emissiveColor[i];
		for(i = 0; i < 3; i++)
			*in >> ambientColor[i];
		*in >> shininess;
		*in >> opacity;
		*in >> translucency;
		*in >> flags;
	}
};

struct ShaderHeader
{
	SRDWORD		refID;
	SRDWORD		shader;

	void		get(srBinIStream* in)
	{
		*in >> refID;
		*in >> shader;
	}
};

struct TextureHeader
{
	SRDWORD		refID;

	void		get(srBinIStream* in)
	{
		*in >> refID;
	}
};



void srHXImporter::readMaterialLibrary()
{
}

void srHXImporter::readVertexMaterial()
{
	srMaterial* shdMaterial = new srMaterial();

	MaterialHeader hdr;
	hdr.get(stream);

	// DEBUG DEBUG
	shdMaterial->setDiffuse(srVector4(hdr.diffuseColor.x, hdr.diffuseColor.y, hdr.diffuseColor.z, hdr.opacity));
	shdMaterial->setSpecular(srVector4(hdr.specularColor.x, hdr.specularColor.y, hdr.specularColor.z, 1.f));
	shdMaterial->setEmissive(srVector4(hdr.emissiveColor.x, hdr.emissiveColor.y, hdr.emissiveColor.z, 1.f));
	shdMaterial->setAmbient(srVector4(hdr.ambientColor.x, hdr.ambientColor.y, hdr.ambientColor.z, 1.f));
	shdMaterial->setTranslucency(hdr.translucency);
	
	if(hdr.shininess != 0.f)
		shdMaterial->setShininess(hdr.shininess);
	else
		shdMaterial->setSpecular(srVector4(0.f, 0.f, 0.f, 0.f));

	if(hdr.flags & 1)		// DEBUG DEBUG enums
		shdMaterial->setMapper(&srEnvironmentMapper);

	if(hdr.flags & 2)
		shdMaterial->enable(srMaterial::DEPTH_CUE);

	if(hdr.flags & 8)		// copy specular to diffuse
		shdMaterial->enable(srMaterial::COPY_SPECULAR_TO_DIFFUSE);

	materialLookup[hdr.refID] = shdMaterial;
}

void srHXImporter::readMaterialTexture()
{
}

void srHXImporter::readMaterialTextureHeader()
{
	TextureHeader t;
	t.get(stream);
	textureLookup[t.refID] = NULL;		
	curTexRefID = t.refID;
}

void srHXImporter::readMaterialTextureFname()
{
	char* fn = getString();
	SRCHAR drive[SR_MAX_DRIVE];
	SRCHAR dir[SR_MAX_DIR];
	SRCHAR fname[SR_MAX_FNAME];
	SRCHAR ext[SR_MAX_EXT];
	srSystem::splitPath(fn, drive, dir, fname, ext);
	SRCHAR tmp[SR_MAX_FNAME + SR_MAX_EXT + 1];
	sprintf(tmp, "%s%s", fname, ext);

	srTextureFile* t = srTextureFile::find(tmp);
	if(!t)
	{
		t = new srTextureFile(tmp);
	}

	// DEBUG DEBUG:
//	t->setMinFilter(srTextureIFace::FILTER_BEST);
//	t->setMagFilter(srTextureIFace::FILTER_BEST);
	textureLookup[curTexRefID] = t;

	delete[] fn;
}

void srHXImporter::readMaterialShader()
{
	ShaderHeader shd;
	shd.get(stream);
	srShader* s = new srShader();
	*s = shd.shader;
//	s->setPrimaryGradient(srShader::GRADIENT_DISABLE);
//	s->setSecondaryGradient(srShader::SECONDARY_GRADIENT_DISABLE);

	shaderLookup[shd.refID] = s;
}


//////////////////////////////////////////////////////////////////////////////////////
// reference object readers:
//////////////////////////////////////////////////////////////////////////////////////

void srHXImporter::readObjects()
{
	numObjectRefs = 0;
}

struct ObjectHeader
{
	SRDWORD	objectRefID;

	void	get(srBinIStream* in)
	{
		*in >> objectRefID;
	}
};

void srHXImporter::readObjectHeader()
{
	numObjectRefs++;
	ObjectHeader hdr;
	hdr.get(stream);

	curObjectRefID = hdr.objectRefID;
}

void srHXImporter::readObjectName()
{
	curObjectName = getString();
}

void srHXImporter::postReadObject()
{
	if(curObjectName)
		delete[] curObjectName;

	curObjectName = NULL;
}

//////////////////////////////////////////////////////////////////////////////////////
// srMeshModel importing (reference object)
//////////////////////////////////////////////////////////////////////////////////////

struct MeshHeader
{
	SRDWORD		vertexCount;
	SRDWORD		polyCount;
	SRDWORD		passCount;

	void		get(srBinIStream* in)
	{
		*in >> vertexCount;
		*in >> polyCount;
		*in >> passCount;
	}
};

struct Face
{
	SRDWORD a, b, c;
	SRDWORD smoothingGroup;

	void	get(srBinIStream* in)
	{
		*in >> a;
		*in >> b;
		*in >> c;
		*in >> smoothingGroup;
	}
};


void srHXImporter::readTrimesh()
{
	curModel = new srMAXMorphModel();//srMeshModel();
	curModel->setTargetCount(1);
	morphTargetNdx = 0;
}

void srHXImporter::readTrimeshMTgtHdr()
{
	SRDWORD foo;
	*stream >> foo;
	curModel->setTargetCount(foo);
}

void srHXImporter::readTrimeshMKeyHdr()
{
	SRDWORD foo;
	*stream >> foo;
	curModel->setKeyCount(foo);
}

void srHXImporter::readTrimeshMKeyArray()
{
//	srOut << "\nmorph key frames" << std::endl;

	for(SRDWORD i = 0; i < curModel->getKeyCount(); i++)
	{
		srMAXMorphModel::MorphKey key;
		*stream >> key.target;
		*stream >> key.time;

//		srOut << " " << key.target << "@" << key.time;

		curModel->setMorphKey(i, key);
	}
}

void srHXImporter::postReadTrimesh()
{
//	sruModelOptimizer::optimize(curModel);
	curModel->setDirtyAll();

//	curModel->setOriginalVertices(curModel->getVertexLoc());

	if(curObjectName)
		curModel->setName(curObjectName);

	curModel->calculateBounds();

	// invalidate curModel (no access after this)
	curModel = NULL;
	morphTargetNdx = 0;
}

void srHXImporter::readTrimeshHeader()
{
	MeshHeader hdr;
	hdr.get(stream);
	curModel->reset(hdr.polyCount, hdr.vertexCount);
	curModel->setPassCount(hdr.passCount);

	modelLib.insert(curObjectRefID, curModel);
}

void srHXImporter::readTrimeshVertexLoc()
{
	// DEBUG DEBUG 
	if(morphTargetNdx == 0)
	{
		srVector3* f = curModel->getVertexLoc();
		get(f, curModel->getVertexCount());
		f = curModel->getTargetVertexLocation(0);
		memcpy(f, curModel->getVertexLoc(), sizeof(srVector3) * curModel->getVertexCount());
	}
	else
		get(curModel->getTargetVertexLocation(morphTargetNdx), curModel->getVertexCount());
	
	morphTargetNdx++;
}

void srHXImporter::readTrimeshPolyVertex()
{
	srVector3i* pvx = curModel->getPolyVertex();
	for(SRDWORD i = 0; i < (SRDWORD)(curModel->getPolygonCount()); i++)
	{
		Face f;
		f.get(stream);
		pvx[i].i = f.a;
		pvx[i].j = f.b;
		pvx[i].k = f.c;
	}
}

void srHXImporter::readTrimeshPassArrays()
{
	curPassIndex = 0;
}

void srHXImporter::readTrimeshPassHeader()
{
	*stream >> curPassIndex;
}

void srHXImporter::readTrimeshMtlArray()
{
	SRDWORD* mtlNdx = new SRDWORD[curModel->getVertexCount()];

	for(SRDWORD i = 0; i < (SRDWORD)(curModel->getVertexCount()); i++)
	{
		*stream >> mtlNdx[i];
	}

	SRBOOL allEqual = true;
	SRDWORD f = mtlNdx[0];
	for(i = 1; i < (SRDWORD)(curModel->getVertexCount()) && allEqual; i++)
		if(mtlNdx[i] != f)
			allEqual = false;

	if(allEqual)
	{
		if(f != -1)
			curModel->setMaterial(materialLookup[f], curPassIndex);
	}
	else
	{
		srMeshModel::MaterialPtr* mtl = curModel->getVertexMaterial(curPassIndex);

		for(SRDWORD i = 0; i < (SRDWORD)(curModel->getVertexCount()); i++)
		{
			SRDWORD ndx = mtlNdx[i];
			if(ndx != -1)
				mtl[i] = materialLookup[ndx];
			else
				mtl[i] = NULL;			// use default material
		}
	}

	delete[] mtlNdx;
}

void srHXImporter::readTrimeshTexArray()
{
	SRDWORD* txNdx = new SRDWORD[curModel->getPolygonCount()];

	for(SRDWORD i = 0; i < (SRDWORD)(curModel->getPolygonCount()); i++)
	{
		*stream >> txNdx[i];
	}

	bool allEqual = true;
	SRDWORD f = txNdx[0];
	for(i = 1; i < (SRDWORD)(curModel->getPolygonCount()) && allEqual; i++)
		if(f != txNdx[i])
			allEqual = false;


	if(allEqual)
	{
		if(f != -1)
			curModel->setTexture(textureLookup[f], curPassIndex);
	}
	else
	{
		srMeshModel::TexturePtr* tx = curModel->getPolyTexture(curPassIndex);
		for(i = 0; i < (SRDWORD)(curModel->getPolygonCount()); i++)
		{
			SRDWORD ndx = txNdx[i];

			if(ndx != -1 && textureLookup[ndx])
				tx[i] = textureLookup[ndx];
			else
				tx[i] = NULL;
		}
	}

	delete[] txNdx;
}

void srHXImporter::readTrimeshShaderArray()
{
	srShader* tmpArr = new srShader[curModel->getPolygonCount()];

	bool sort = false;
	for(SRDWORD i = 0; i < (SRDWORD)(curModel->getPolygonCount()); i++)
	{
		SRDWORD ndx;
		*stream >> ndx;

		if(ndx != -1)
			tmpArr[i] = *shaderLookup[ndx];
		else
			tmpArr[i] = srShader();

		if(tmpArr[i].getDstBlendFunc() != srShader::DSTBLEND_ZERO)
			sort = true;
	}

	bool allEqual = true;
	srShader f = tmpArr[0];
	for(i = 1; i < (SRDWORD)(curModel->getPolygonCount()) && allEqual; i++)
		if(f != tmpArr[i])
			allEqual = false;


	if(!allEqual)
	{
		srShader* sh = curModel->getPolyShader(curPassIndex);
		for(i = 0; i < (SRDWORD)(curModel->getPolygonCount()); i++)
			sh[i] = tmpArr[i];
	}
	else
		curModel->setShader(f, curPassIndex);

	if(sort && !curPassIndex)
		curModel->enable(srMeshModel::SORT);

	delete[] tmpArr;
}

void srHXImporter::readTrimeshVertexUVW()
{
	srVector2* pvx = curModel->getVertexTexCoords(curPassIndex);

	for(SRDWORD i = 0; i < (SRDWORD)(curModel->getVertexCount()); i++)
	{
		float uv;
		*stream >> uv;
		pvx[i].x = uv;
		*stream >> uv;
		pvx[i].y = -uv;
	}
}

void srHXImporter::readTrimeshVxColorArray()
{
	srVector3* pvx = curModel->getVertexDIG(curPassIndex);

	for(SRDWORD i = 0; i < (SRDWORD)(curModel->getVertexCount()); i++)
	{
		float a, b, c;
		*stream >> a;
		*stream >> b;
		*stream >> c;
		pvx[i].x = a;
		pvx[i].y = b;
		pvx[i].z = c;
	}
}

void srHXImporter::readTrimeshVertexShadeRemap()
{
	SRDWORD* n = curModel->getVertexShadeIndex();

	for(SRDWORD i = 0; i < (SRDWORD)(curModel->getVertexCount()); i++)
	{
		SRDWORD f;
		*stream >> f;
		n[i] = f;
	}
}


/////////////////////////////
// controllers
/////////////////////////////

void srHXImporter::readKFController()
{
	srOut << "reading kf controller" << std::endl;
}

void srHXImporter::readKFControllerHeader()
{
	srOut << "  header" << std::endl;
	struct KFCHdr
	{
		SRDWORD		nKeys;
		SRDWORD		nElements;
		SRDWORD		flags;
		float		rangeStart;
		float		rangeEnd;
	} a;
	*stream >> a.nKeys;
	*stream >> a.nElements;
	*stream >> a.flags;
	*stream >> a.rangeStart;
	*stream >> a.rangeEnd;
/*

	rangeStart = 0.f;
	rangeEnd   = 1.f;
	const int N = 7;

	setNumElements(2);
	setNumKeys(N);

	srand(0xdeadbabe);

/*	for(int i = 0; i < N; i++)
	{
		keys[i].value[1] = (((rand() % 100)/50.f)-1.f)*1.6f;
		keys[i].value[0] = (((float)i / (float)N) - 0.5f) * 7.f;
		keys[i].time	 = (float)i / (N-1);
	}*/

/*	for(int i = 0; i < N; i++)
	{
		double ang = srDegreeToRad(((float)i / (float)(N-1)) * 360.f);
		values[0][i] = sin(ang)*1.5f;
		values[1][i] = cos(ang)*1.5f;
		keys[i].time	 = (float)i / (N-1);
	}

*/

/*	curBezControl->setNumElements(a.nElements);
	curBezControl->setNumKeys(a.nKeys);
	curBezControl->rangeStart	= a.rangeStart;
	curBezControl->rangeEnd		= a.rangeEnd;
*/
	srOut << "    nKeys = " << a.nKeys;
	srOut << "    nElements = " << a.nElements;
}

void srHXImporter::readKFControllerKeys()
{
	/*Key k;
	IBezFloatKey fk;
	kCntrl->GetKey(i, &fk);
	k.flags	= 0;			// DEBUG DEBUG
	k.time	= (float)fk.time / 4800.f;
	out->put(k.flags);
	out->put(k.time);

	out->put(fk.val);
	out->put(fk.intan);
	out->put(fk.outtan);
	*/

	srOut << "    keys:" << std::endl;

/*	SRDWORD nElements = curBezControl->nElems;
	SRDWORD nKeys	  = curBezControl->nKeys;

	for(SRDWORD i = 0; i < nKeys; i++)
	{
		SRDWORD j;
		SRDWORD flags;
		*stream >> flags;
		float time;
		*stream >> time;

		float val[3], inTan[3], outTan[3];		
		for(j = 0; j < nElements; j++)
			*stream >> val[j];
		for(j = 0; j < nElements; j++)
			*stream >> inTan[j];
		for(j = 0; j < nElements; j++)
			*stream >> outTan[j];

		curBezControl->values[0][i]		= val[0];
		curBezControl->inTangents[0][i]	= inTan[0];
		curBezControl->outTangents[0][i]= inTan[0];
		curBezControl->keys[i].time		= time;
//		curBezControl->keys[i].flags	= HYBRID_SMOOTH;

		srOut << "      @ " << time << "\t w=" << val[0] << "  inTan=" << inTan[0] << "  outTan=" << outTan[0] << std::endl;
	}
*/
}

/////////////////////////////
// modifiers
/////////////////////////////

void srHXImporter::readModifier()
{
	srOut << "modifier" << std::endl;

//	morphMod = NULL;
}
void srHXImporter::readMorphModifier()
{
	srOut << "  morph" << std::endl;

//	morphMod		= new srMAXMorphModifier();
//	morphChannelNdx = 0;
//	curModel->setModifier(0, morphMod);
}

void srHXImporter::readMorphModifierHeader()
{
/*	struct MHdr
	{
		SRDWORD	nChannels;
		SRDWORD res[3];
	};
	MHdr a;

	*stream >> a.nChannels;
	*stream >> a.res[0] >> a.res[1] >> a.res[2];
	srOut << "     nChannels = " << a.nChannels << std::endl;

	morphMod->setMorphChannelCount(a.nChannels);
	*/
}

void srHXImporter::readMorphModifierChannel()
{
//	curBezControl = &morphMod->getMorphChannel(morphChannelNdx).getController();
}
void srHXImporter::postReadMorphModifierChannel()
{
/*	// DEBUG DEBUG
	srMAXMorphModifier::WeightController& cntrl = morphMod->getMorphChannel(morphChannelNdx).getController();
	typedef srMAXMorphModifier::WeightController::FloatKey WKey;

	cntrl.setKeyCount(6);
	cntrl.setKey(0, WKey(0.f, 0.f));
	cntrl.setKey(1, WKey(2.f, 1.f));
	cntrl.setKey(2, WKey(4.f, 0.0f));
	cntrl.setKey(3, WKey(6.f, 0.0f));
	cntrl.setKey(4, WKey(8.f, 1.0f));
	cntrl.setKey(5, WKey(10.f, 0.0f));
*/

//	curBezControl = NULL;
//	morphChannelNdx++;
}
							
void srHXImporter::readMorphModifierChannelHeader()
{
	/*struct MCHdr
	{
		SRDWORD	vertexCount;
	} a;
	*stream >> a.vertexCount;
	srMAXMorphModifier::Channel& chn = morphMod->getMorphChannel(morphChannelNdx);
	chn.setVertexCount(a.vertexCount);
	*/
}

void srHXImporter::readMorphModifierChannelVIndex()
{
/*	srMAXMorphModifier::Channel& chn = morphMod->getMorphChannel(morphChannelNdx);
	SRDWORD* vIndex = chn.getVertexIndices();
	for(SRDWORD i = 0; i < chn.getVertexCount(); i++)
	{
		*stream >> vIndex[i];
	}
	*/
}

void srHXImporter::readMorphModifierChannelVDeltas()
{
/*	srMAXMorphModifier::Channel& chn = morphMod->getMorphChannel(morphChannelNdx);
	srVector3* vDeltas = chn.getVertexDeltas();
	for(SRDWORD i = 0; i < chn.getVertexCount(); i++)
	{
		*stream >> vDeltas[i].x;
		*stream >> vDeltas[i].y;
		*stream >> vDeltas[i].z;
	}*/
}

void srHXImporter::readMorphModifierOrigVertices()
{
/*	srArray<srVector3> origVx(curModel->getVertexCount());
	
	for(SRDWORD i = 0; i < (SRDWORD)curModel->getVertexCount(); i++)
	{
		*stream >> origVx[i].x;
		*stream >> origVx[i].y;
		*stream >> origVx[i].z;
	}

	curModel->setOriginalVertices(&origVx[0]);*/
}

//////////////////////////////////////////////////////////////////////////////////////
// Camera/Light Importing
//////////////////////////////////////////////////////////////////////////////////////

struct CameraHeader
{
	float			fov;
	float			nearClip;
	float			farClip;

	void			get(srBinIStream* in)
	{
		*in >> fov;
		*in >> nearClip;
		*in >> farClip;
	}
};

struct NodeLightHeader
{
	void		get(srBinIStream*)		{ }
};

struct LightHeader
{
	srVector3	color;

	float		nearRange;
	float		farRange;

	float		intensity;
	float		spotAngle;
	SRDWORD		type;			// 0 == omni, 1 == spot, 2 == directional

	void		get(srBinIStream* in)
	{
		for(int i = 0; i < 3; i++) 
			*in >> color[i];
		*in >> nearRange;
		*in >> farRange;

		*in >> intensity;
		*in >> spotAngle;
		*in >> type;
	}
};

void srHXImporter::readCameraHeader()
{
	CameraHeader hdr;
	hdr.get(stream);

	srCamera* cam = new srCamera(parentScene);
	modelLib.insert(curObjectRefID, cam);
	cam->setClipRange(hdr.nearClip, hdr.farClip);
	// DEBUG DEBUG
	cam->setFOV(hdr.fov, 4.f/3.f);
}

void srHXImporter::readNodeCamera()
{
	srCamera* l = (srCamera*)modelLib.get(curNodeHdr.refObjectID);
	curNode = new srCamera(parentScene);
	srCamera* foo = (srCamera*)curNode;
	*foo = *l;
}



void srHXImporter::readLight()
{
}

void srHXImporter::readLightHeader()
{
	LightHeader hdr;
	hdr.get(stream);
	srLight* curLight = NULL;

	switch(hdr.type)
	{
	case 0:		curLight = new srLight(parentScene, srLight::POINT_LIGHT);			break;
	case 1:		curLight = new srLight(parentScene, srLight::SPOT_LIGHT);			break;
	case 2:		curLight = new srLight(parentScene, srLight::DIRECTIONAL_LIGHT);	break;
	default:	curLight = new srLight(parentScene);
	}

	curLight->setDiffuse(hdr.color);
	curLight->setSpotAngle(hdr.spotAngle);
	curLight->setIntensity(hdr.intensity);
	curLight->setAttenuationModel(srLight::ATTENUATION_3DSMAX);
	curLight->setFarAttenuationRange(hdr.nearRange, hdr.farRange);
	curLight->setSpotDirection(srVector3(0.f, 0.f, -1.f));

	modelLib.insert(curObjectRefID, curLight);
}

void srHXImporter::readNodeLight()
{
	curNode = new srLight(parentScene);
}

void srHXImporter::readNodeLightHeader()
{
	NodeLightHeader hdr;
	hdr.get(stream);

	srLight* l = (srLight*)modelLib.get(curNodeHdr.refObjectID);
	srLight* foo = (srLight*)curNode;
	*foo = *l;
}



//////////////////////////////////////////////////////////////////////////////////////
// Scene graph importing
//////////////////////////////////////////////////////////////////////////////////////

struct NodeModelHeader
{
	SRDWORD		passCount;
	SRDWORD		vertexMtlRefID[4];
	SRDWORD		textureRefID[4];
	SRDWORD		shaderRefID[4];

	void	get(srBinIStream* in)
	{
		int i;
		*in >> passCount;

		for(i = 0; i < 4; i++)
			*in >> vertexMtlRefID[i];
		for(i = 0; i < 4; i++)
			*in >> textureRefID[i];
		for(i = 0; i < 4; i++)
			*in >> shaderRefID[i];
	}
};


void srHXImporter::readSceneGraph()
{
	nodeCount = 0;
}

// DEBUG DEBUG kludge kludge
void srHXImporter::postReadSceneGraph()
{
	for(SRDWORD i = 0; i < nodeCount; i++)
	{
		srNode* n = nodeHash.get(i);

		Children* c = childIDArrayHash.get(i);
		if(c)
		{
			if(c->childCount)
			{
				for(SRDWORD j = 0; j < c->childCount; j++)
				{
					srNode* child = nodeHash.get(c->childIDArray[j]);
					child->setParent(n, false);
				}
			}
		}
	}

	for(i = 0; i < numObjectRefs; i++)
	{
		srClass* f = modelLib.get(i);

		if(f)
		{
			if(f->getClassID() != srHX::ID_MAX_MORPH_MODEL)
				f->release();
		}
	}
}

void srHXImporter::readNode()
{
	curNode	= NULL;
	curNodeName = NULL;
	nodeCount++;
}

void srHXImporter::readNodeHeader()
{
	curNodeHdr.get(stream);
}

void srHXImporter::readNodeTransform()
{
	curTransform.get(stream);
}

void srHXImporter::readNodeLocalTransform()
{
	curObjOffsTransform.get(stream);
}

void srHXImporter::readNodeName()
{
	curNodeName = getString();	
}

void srHXImporter::readNodeModel()
{
	curNode	= new srMAXModelInstance(parentScene);
}


void srHXImporter::readNodeModelHeader()
{
	NodeModelHeader hdr;
	hdr.get(stream);
	srMeshModel* m = (srMeshModel*)modelLib.get(curNodeHdr.refObjectID);
	if(m && curNode)
	{
		srMAXModelInstance* mi = (srMAXModelInstance*)curNode;
		mi->setModel(m);
	}
}


void srHXImporter::postReadNode()
{
	if(!curNode)
		curNode = new srNode(parentScene);

	if(curNode)
	{
		curNode->setRotation(curTransform.rot);
		curNode->setLocation(curTransform.translation);
		curNode->setScale(curTransform.scale);

		if(curNodeName)
			curNode->setName(curNodeName);

		if(curNode->getClassID() == srHX::ID_MAX_MODEL_INSTANCE)
		{
			srMAXModelInstance* mi = (srMAXModelInstance*)curNode;
			mi->setLocalTranslation(curObjOffsTransform.translation);
			mi->setLocalRotation(curObjOffsTransform.rot);

		}
	}
	
	nodeHash.insert(curNodeHdr.id, curNode);

	if(curNodeHdr.flags & 1)
		curNode->setFlag(srNode::DISABLE);


	// prevent further access to this node:
	curNode = NULL;

	if(curNodeName)
		delete[] curNodeName;

	curNodeName = NULL;
}

void srHXImporter::readNodeChildIDArray()
{
	Children* childArray = new Children(curNodeHdr.childCount);
	for(SRDWORD i = 0; i < curNodeHdr.childCount; i++)
		*stream >> childArray->childIDArray[i];

	childIDArrayHash.insert(curNodeHdr.id, childArray);
}



