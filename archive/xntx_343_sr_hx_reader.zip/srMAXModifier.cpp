
#ifdef KILGORE_TROUT

#include "srMAXModifier.hpp"


// DEBUG DEBUG
#include "srVariableTimer.hpp"
#include "srCore.hpp"

//--------------------------
// Catmull-Rom spline coeffs
//--------------------------
#define CR00	-0.5f
#define CR01	 1.5f
#define CR02	-1.5f
#define CR03	 0.5f
#define CR10	 1.0f
#define CR11	-2.5f
#define CR12	 2.0f
#define CR13	-0.5f
#define CR20	-0.5f
#define CR21	 0.0f
#define CR22	 0.5f
#define CR23     0.0f
#define CR30     0.0f
#define CR31	 1.0f
#define CR32     0.0f
#define CR33     0.0f

static float interpSplineCatmullRom(float u, srVector4 knot)
{
	float c0, c1, c2, c3;
	c3 = (CR00 * knot[0]) + (CR01 * knot[1])
	   + (CR02 * knot[2]) + (CR03 * knot[3]);
	c2 = (CR10 * knot[0]) + (CR11 * knot[1])
	   + (CR12 * knot[2]) + (CR13 * knot[3]);
	c1 = (CR20 * knot[0]) + (CR21 * knot[1])
	   + (CR22 * knot[2]) + (CR23 * knot[3]);
	c0 = (CR30 * knot[0]) + (CR31 * knot[1])
	   + (CR32 * knot[2]) + (CR33 * knot[3]);

	return ((c3*u + c2)*u + c1)*u + c0;
}


FloatController::FloatController()
{
	rangeStart	= 0.f;
	rangeEnd	= 0.f;
	outOfRangeType = CONSTANT;

	// DEBUG DEBUG is this legal?
	keys.resize(0);
}

FloatController::~FloatController()
{
}

void FloatController::evaluate(const FloatKey& k)
{
	if(rangeEnd < k.time)
		rangeEnd = k.time;
}

#include "srIO.hpp"

float FloatController::getValue(const float time)
{
	static hox = 0;
	hox++;
	SRDWORD ndx = 0, ndx2;

//	SRBOOL outRange = false;

	// DEBUG DEBUG finish this!
	for(; ndx < getKeyCount(); ndx++)
	{
		ndx2 = (ndx + 1) % getKeyCount();

/*		else		// LOOP
		{
			ndx2 = 0;
			outRange = true;
			break;
		}
*/
		if(keys[ndx].time <= time && keys[ndx2].time > time)
			break;
	}

	SRDWORD nd[4];
	for(SRDWORD i = 0; i < 4; i++)
	{
		nd[i] = (-1+ndx + i) % getKeyCount();
		if(nd[i] < 0) nd[i] = getKeyCount() - 1;
	}
	ndx2 = nd[2];

	float t0 = time - keys[ndx].time;
	t0 /= (keys[ndx2].time - keys[ndx].time);
	return interpSplineCatmullRom(t0, srVector4(keys[nd[0]].value, keys[nd[1]].value, keys[nd[2]].value, keys[nd[3]].value));
}



srMAXMorphModifier::srMAXMorphModifier()
{
	numMorphChannels	= 0;
}


void srMAXMorphModifier::apply(srVector3* vx, const srVector3* src, SRDWORD nVertices)
{
	const float thresh = 0.00001f;

	// DEBUG DEBUG todo: do not copy vertices on each update!

	// get original vertices (DEBUG DEBUG todo: use indexed copy here, gather 
	// all morphing points from vertexIndex tables)
	memcpy(vx, src, sizeof(srVector3) * nVertices);

	double t = srCore.getTimer()->getTime();
		
	// loop through all morph channels
	for(SRDWORD i = 0; i < numMorphChannels; i++)
	{
		SRDWORD		j;
		Channel& channel		= getMorphChannel(i);

		float w					= channel.getController().getValue((float)t);
		// if use limits
		if(w < 0.f)
			w = 0.f;
		if(w > 100.f)
			w = 100.f;

		if(fabs(w) > thresh)
		{
			SRDWORD		vCnt	= channel.getVertexCount();
			SRDWORD*	vNdx	= channel.getVertexIndices();
			srVector3*	deltas	= channel.getVertexDeltas();

			for(j = 0; j < vCnt; j++)
				vx[vNdx[j]] += deltas[j] * w;
		}
	}
}
#endif