
#ifndef __DYNARRAY_HPP_INCLUDED
#define __DYNARRAY_HPP_INCLUDED
/*****************************************************************************
 *
 * SurRender - Real-Time 3D Graphics Library
 * -----------------------------------------
 *
 * (C) 1994-1998 Hybrid Holding, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Holding, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irrepairable harm to
 * Hybrid Holding and legal action against the party in breach.
 *
 *
 * Desc:	Dynamic array 
 *
 * $Archive: /srsdk1x/include/misc/hximporter/DynArray.hpp $
 * $Author: samuli $
 * $Revision: #1 $
 * $Modtime: 11/05/98 4:53p $
 * $Date: 2003/01/08 $
 *
 *****************************************************************************/

#pragma SRPACKPUSH

/******************************************************************************
 *
 * Class:			DynArray
 *
 * Description:		Easy-to-use dynamic array template
 *					
 ******************************************************************************/
template<class T>
class DynArray
{
public:
	DynArray(int origSize = 1)
	{
		elements	= 0;
		size		= origSize;
		if(size)
			array	= new T[size];
		else array	= NULL;
	}

	~DynArray()
	{
		if(array)	delete[] array;
	}
	
	T& operator[](int ndx)
	{
		if((SRDWORD)ndx < size)
		{
			if((SRDWORD)ndx >= elements) 
				elements = ndx + 1;
			return array[ndx];
		}
		else
		{
			int newSize = (((size + (ndx - size + 1)) * 3) / 2)+1;

			T* tmp = new T[newSize];			// grow array 
			if(array && size)
			{
				srAssert(array);
				memcpy(tmp, array, size * sizeof(T));
				delete[] array;
			}
			array = tmp;
			srAssert(array);
			size = newSize;
		}
		
		if((SRDWORD)ndx >= elements) elements = ndx + 1;
		srAssert((SRDWORD)ndx < size);
		srAssert((SRDWORD)ndx < elements);
		return array[ndx];
	}

	// read only access (for fast reads, CRASHES if reading from outside the initialized range!)
	const T& operator[](int i) const
	{
		srAssert((SRDWORD)ndx < size);
		srAssert((SRDWORD)ndx < elements);
		return array[ndx];
	}

	SRDWORD	getElements()	{ return elements; }

private:
	SRDWORD			elements;		// exact amount of elements
	SRDWORD			size;			// allocated size
	T*				array;			// the actual memory 
};



/******************************************************************************
 *
 * Function:		DynArray::DynArray()
 *
 * Description:		constructor
 *
 * Parameters:		origSize	= initial array size
 *
 ******************************************************************************/
/******************************************************************************
 *
 * Function:		DynArray::~DynArray
 *
 * Description:		destructor
 *
 * Notes:			Frees any memory allocated
 *
 ******************************************************************************/
/******************************************************************************
 *
 * Function:		T& DynArray::operator[]()
 *
 * Description:		[] operator
 *
 * Parameters:		ndx		= index to the dynamic array
 *
 * Notes:			Indexes the dynamic array and allocates new memory if 
 *					accessing outside the allocated space.
 *
 ******************************************************************************/
/******************************************************************************
 *
 * Function:		const T& DynArray::operator[]() const
 *
 * Description:		[] operator
 *
 * Notes:			Access operator for read only access.
 *					Undefined behaviour if reading from outside the valid 
 *					range.
 *
 ******************************************************************************/
/******************************************************************************
 *
 * Function:		SRDWORD DynArray::getElements()
 *
 * Description:		Returns the number of elements in the array
 *
 * Returns:			The number of initialized elements in the array
 *
 * Notes:			This is not the physical allocated memory size
 *
 ******************************************************************************/

#pragma SRPACKPOP

#endif		// __DYNARRAY_HPP_INCLUDED