
/*****************************************************************************
 *
 * SurRender - Real-Time 3D Graphics Library
 * -----------------------------------------
 *
 * (C) 1994-1998 Hybrid Holding, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Holding, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irrepairable harm to
 * Hybrid Holding and legal action against the party in breach.
 *
 * Desc:	morph object
 *
 * $Archive: /srSDK1x/sources/misc/hximporter/srMAXMorphModel.cpp $
 * $Author: samuli $ 
 * $Revision: #1 $
 * $Modtime: 16.12.99 19:38 $
 * $Date: 2003/01/08 $
 * 
 *****************************************************************************/

#include "srHXTypes.hpp"
#include "srGERD.hpp"
#include "srVectorProcessor.hpp"
#include "srMAXMorphModel.hpp"
#include "srIO.hpp"

void srMAXMorphModel::dump(srOStream &str)
{
	srMeshModel::dump(str);

	long oldflags = str.flags();
	str.setf(std::ios::left, std::ios::adjustfield);
	str << '\n';
	str.width(DUMP_FIELD_WIDTH);
	str << "Number of targets:" << numTargets << '\n';
	str.width(DUMP_FIELD_WIDTH);
	str << "Number of keyframes:" << numKeys << '\n';
	str.width(DUMP_FIELD_WIDTH);
	str << "Time:" << time << '\n';


	str.flags(oldflags);
}

srMAXMorphModel& srMAXMorphModel::operator=(const srMAXMorphModel& src)
{
	if(&src != this)
	{
	
		srMeshModel::operator=(src);

		numTargets	= src.numTargets;
		numKeys		= src.numKeys;

		if(src.numTargets && src.vertexLoc)
		{
			numTargets	= src.numTargets;
			vertexLoc	= new srVector3*[src.numTargets];

			for(SRDWORD i = 0; i < src.numTargets; i++)
			{
				if(src.vertexLoc[i])
				{
					vertexLoc[i] = new srVector3[getVertexCount()];
					for(SRDWORD j = 0; j < (SRDWORD)getVertexCount(); j++)
					{
						vertexLoc[i][j] = src.vertexLoc[i][j];
					}
				}
				else vertexLoc[i] = NULL;
			}
		}
		else 
			vertexLoc	= NULL;

		if(src.numKeys && src.morphKeys)
		{
			morphKeys = new MorphKey[numKeys];

			for(SRDWORD j = 0; j < numKeys; j++)
				morphKeys[j] = src.morphKeys[j];
		}
		else
			morphKeys	= NULL;

		time	= src.time;
	}

	return *this;
}


/******************************************************************************
 *
 * Function:		srMAXMorphModel::srMAXMorphModel()
 *
 * Description:		constructor
 *
 ******************************************************************************/
srMAXMorphModel::srMAXMorphModel()
{
	numTargets	= 0;
	vertexLoc	= NULL;

	morphKeys	= NULL;
	numKeys		= 0;
//	modifier	= NULL;

	time		= 0.0;
}

/******************************************************************************
 *
 * Function:		srMAXMorphModel::~srMAXMorphModel()
 *
 * Description:		destructor
 *
 ******************************************************************************/
srMAXMorphModel::~srMAXMorphModel()
{
//	srAssert(numTargets);

	if(vertexLoc)
	{
		for(SRDWORD i = 0; i < numTargets; i++)
		{
			if(vertexLoc[i])
				delete[] vertexLoc[i];
		}
		delete[] vertexLoc;
	}

	if(morphKeys)
		delete[] morphKeys;
}

/******************************************************************************
 *
 * Function:		srMAXMorphModel::setTargetCount()
 *
 * Description:		Sets the number of morph targets
 *
 * Parameters:		nTargets		= number of morph targets in the mesh
 *
 ******************************************************************************/
void srMAXMorphModel::setTargetCount(SRDWORD nTargets)
{
//	srAssert(nTargets);

	if(numTargets)
	{
		srAssert(vertexLoc);
		for(SRDWORD i = 0; i < numTargets; i++)
			if(vertexLoc[i])
				delete[] vertexLoc[i];

		delete[] vertexLoc;
	}

	numTargets = nTargets;

	vertexLoc = new srVector3*[nTargets];

	for(SRDWORD i = 0; i < nTargets; i++)
		vertexLoc[i] = NULL;
}

/******************************************************************************
 *
 * Function:		srMAXMorphModel::getTargetVertexLocation(SRDWORD tIndex)
 *
 * Description:		Get morph target vertex location array
 *
 * Parameters:		tIndex		= which target to query
 *
 ******************************************************************************/
srVector3* srMAXMorphModel::getTargetVertexLocation(SRDWORD tIndex)
{
	if(vertexLoc[tIndex]) 
		return vertexLoc[tIndex];

	vertexLoc[tIndex] = new srVector3[getVertexCount()];
	return vertexLoc[tIndex];
}


/******************************************************************************
 *
 * Function:		srMAXMorphModel::calculateBounds()
 *
 * Description:		Calculate bounds for the entire morph sequence
 *
 ******************************************************************************/
void srMAXMorphModel::calculateBounds()
{
//	srAssert(numTargets);
	srAssert(vertexLoc);

	float maxRad = 0.f;
	srVector3 bMin, bMax;

	// find the biggest bounding box, and use that
	for(SRDWORD i = 0; i < numTargets; i++)
	{
		srVector3* vloc = vertexLoc[i];
		srAssert(vloc);

		if(i == 0)
		{
			bMin = vloc[0];
			bMax = vloc[0];
		}

		// rewrite this with srVectorProcessor
		for(SRDWORD j = 1; j < (SRDWORD)getVertexCount(); j++)
		{
			if(bMin.x > vloc[j].x) bMin.x = vloc[j].x;
			if(bMin.y > vloc[j].y) bMin.y = vloc[j].y;
			if(bMin.z > vloc[j].z) bMin.z = vloc[j].z;
			if(bMax.x < vloc[j].x) bMax.x = vloc[j].x;
			if(bMax.y < vloc[j].y) bMax.y = vloc[j].y;
			if(bMax.z < vloc[j].z) bMax.z = vloc[j].z;

			float r = (float)dot(vloc[j], vloc[j]);
			if(r > maxRad) 
				maxRad = r;
		}

		if(!i)
		{
			srVector3* f = getVertexLoc();
			for(SRDWORD j = 0; j < (SRDWORD)getVertexCount(); j++)
				f[j] = vloc[j];
		}
	}
	boundOrig	= srVector3(0.f, 0.f, 0.f);
	boundRadius = (float)sqrt(maxRad) * 1.0001f;
	boundMin	= bMin;
	boundMax	= bMax;
	updateAllClients	(Client::BOUNDS_DIRTY);
	flags.clear			(DIRTY_BOUNDS);
	flags.set			(DIRTY_TRIMESH);
}


/******************************************************************************
 *
 * Function:		srMAXMorphModel::interpolateVertexLoc()
 *
 * Description:		Morph between keyframes
 *
 * Notes:			Uses the 'time' parameter to morph between keyframes.
 *					Time must be set with the setTime() member.
 *
 *					Currently uses linear interpolation between keyframes.
 *
 *					Uses morphKeys array for sequencing morph keyframes.
 *
 ******************************************************************************/
void srMAXMorphModel::interpolateVertexLoc()
{
	if(numTargets < 2) 
		return;

	int nKeys = numKeys;

//	float startTime = (float)time;

	bool found = false;
	int ndx = 1;
	while(ndx < nKeys && !found)
	{
		int prev = ndx - 1;
		if(morphKeys[ndx].time >= time && morphKeys[prev].time <= time)
			found = true;
		else
			ndx++;
	}

	if(ndx == nKeys)
		return;

//	srAssert(vl);

	srVector3* vxl = getVertexLoc();

	int key0 = ndx - 1;
	if(ndx == 0) 
		key0 = nKeys-1;
	int key1 = ndx;

	int n0 = morphKeys[key0].target;
	int n1 = morphKeys[key1].target;

	float t = morphKeys[key1].time;
	t -= morphKeys[key0].time;

	float tm = (float)((time - morphKeys[key0].time) / t);

	n0 %= numTargets;
	n1 %= numTargets;

	srVector3* vl0 = vertexLoc[n0];
	srVector3* vl1 = vertexLoc[n1];

//	float a = 1.f - (float)tm;
	float b = (float)tm;
	// lerp vertices, change this if you want something better for interpolating the
	// vertex locations
	for(SRDWORD i = 0; i < (SRDWORD)getVertexCount(); i++)
	{
		vxl[i] = (vl1[i] - vl0[i]) * b + vl0[i];
	}

	calculatePolygonNormals();
	calculateVertexNormals();
}

/******************************************************************************
 *
 * Function:		srMAXMorphModel::render()
 *
 * Description:		Queries a trimesh using the virtual getTriMesh() call
 *					and then renders it with renderTriMesh().
 *
 * Parameters:		gerd	= reference to GERD
 *
 * Notes:			This function call is made virtual so that derived
 *					classes can "hook in" to modify the trimesh data between
 *					the data fetch and the render command.
 *
 *					The default implementation performs a GERD bounding sphere/box
 *					test unless the DISABLE_BOUNDING_BOX/DISABLE_BOUNDING_SPHERE flags 
 *					have been set. The bounding box test is performed only
 *					if the mesh has 8 or more vertices.
 *
 * Keywords:		Model (rendering), Trimesh 
 *
 ******************************************************************************/

void srMAXMorphModel::render (srGERD& gerd)
{
	// perform quick bounding sphere / box tests
	if (!control.test(DISABLE_BOUNDING_SPHERE))
	{
		srVector3	bOrig;
		float		bRadius;

		getBoundingSphere (bOrig, bRadius);
		if (gerd.testBoundingSphere (bOrig, bRadius) == srGERD::NOT_VISIBLE)
			return;
	}
	if (!control.test(DISABLE_BOUNDING_BOX) && getVertexCount() >= 8)
	{
		// bounding sphere test indicated that object 
 	
		srVector3		mn,mx;
		getBoundingBox  (mn,mx);

		if (gerd.testBoundingBox (mn,mx) == srGERD::NOT_VISIBLE)
			return;
	}

/*	if(modifier)
	{
		modifier->apply(getVertexLoc(), &vertices[0], getVertexCount());
		calculatePolygonNormals();
		calculateVertexNormals();
	}
*/
	interpolateVertexLoc();
//	cubicInterpolateVertexLoc();

/*	TriMesh tm;
	getTriMesh(tm);
	// edit here
	renderTriMesh	(gerd, tm);
*/
	renderTriMesh	(gerd, getTriMesh());
}


/******************************************************************************
 *
 * Function:		srMAXMorphModel::setKeyCount()
 *
 * Description:		Set keyframe count
 *
 * Parameters:		nKeys		= number of keyframes in the sequence
 *
 ******************************************************************************/
void srMAXMorphModel::setKeyCount(SRDWORD nKeys)
{
	numKeys			= nKeys;
	morphKeys		= new MorphKey[nKeys];
}

/******************************************************************************
 *
 * Function:		srMAXMorphModel::setMorphKey()
 *
 * Description:		Set a morphkey at given index
 *
 * Parameters:		ndx		= which keyframe to modify
 *					key		= keyframe to set
 *
 * Preconditions:	Prior call to setKeyCount() is necessary
 *
 * Notes:			Keyframes must be in a chronological order
 *
 ******************************************************************************/
void srMAXMorphModel::setMorphKey(SRDWORD ndx, const MorphKey& key)
{
	morphKeys[ndx] = key;
}





/*
static void computeHermiteBasis(float u, float *v) 
{
	float u2,u3,a;
	
	u2 = u*u;
	u3 = u2*u;
	a  = 2.0f*u3 - 3.0f*u2;
	v[0] = 1.0f + a;
	v[1] = -a;
	v[2] = u - 2.0f*u2 + u3;
	v[3] = -u2 + u3;
}
*/
/*
void CubicMorphCont::CalcFirstCoef(float *v,float *c)
{
	float G, H, J;

	H = .5f*(1.0f-keys[0].tens)*v[2];
	J = 3.0f*H;
	G = v[3] - H;
	c[0] = v[0] - J - G * keys[1].k;
	c[1] = v[1] + J + G*(keys[1].k-keys[1].l);
	c[2] = G*keys[1].l;
	}

void CubicMorphCont::CalcLastCoef(float *v,float *c)
{
	int nkeys = keys.Count();
	float G, H, J;

	H = .5f*(1.0f-keys[nkeys-1].tens)*v[3];
	J = 3.0f*H;
	G = v[2]-H;
	c[0] = -G*keys[nkeys-2].m;
	c[1] = v[0] - J + G*(keys[nkeys-2].m-keys[nkeys-2].n);
	c[2] = v[1] + J + G*keys[nkeys-2].n;
}
*/

// DEBUG DEBUG
/*
static void calcMiddleCoeffs(float *v,int *,float *c)
{
	c[0] = 0.f;//-v[2]*keys[knum[1]].m;
	c[1] = v[0];// + v[2]*(keys[knum[1]].m-keys[knum[1]].n) - v[3]*keys[knum[2]].k;
	c[2] = v[1];// + v[2]*keys[knum[1]].n + v[3]*(keys[knum[2]].k-keys[knum[2]].l);
	c[3] = 0.f;//v[3]*keys[knum[2]].l;
}
*/



/******************************************************************************
 *
 * Function:		srMAXMorphModel::interpolateVertexLoc()
 *
 * Description:		Morph between keyframes
 *
 * Notes:			Uses the 'time' parameter to morph between keyframes.
 *					Time must be set with the setTime() member.
 *
 *					Currently uses linear interpolation between keyframes.
 *
 *					Uses morphKeys array for sequencing morph keyframes.
 *
 ******************************************************************************/
void srMAXMorphModel::cubicInterpolateVertexLoc()
{
	if(numTargets < 2) 
		return;

	int nKeys = numKeys;

//	float startTime = (float)time;

	int ndx = 1;
	while(ndx < nKeys)
	{
		int prev = ndx - 1;
		if(morphKeys[ndx].time >= time && morphKeys[prev].time <= time)
			break;
		ndx++;
	}

	if(ndx == nKeys)
		return;

//	srAssert(vl);

	srVector3* vxl = getVertexLoc();

	int key0 = ndx - 1;
	if(ndx == 0) 
		key0 = nKeys-1;
	int key1 = ndx;

	int n0 = morphKeys[key0].target;
	int n1 = morphKeys[key1].target;

	float t = morphKeys[key1].time;
	t -= morphKeys[key0].time;

	float tm = (float)((time - morphKeys[key0].time) / t);

	n0 %= numTargets;
	n1 %= numTargets;

	srVector3* vl0 = vertexLoc[n0];
	srVector3* vl1 = vertexLoc[n1];

	float u2,u3,a;
	u2 = tm*tm;
	u3 = u2*tm;
	a  = 2.0f*u3 - 3.0f*u2;
	float t0 = 1.0f + a;
	float t1 = -a;

	// lerp vertices, change this if you want something better for interpolating the
	// vertex locations
	for(SRDWORD i = 0; i < (SRDWORD)(getVertexCount()); i++)
		vxl[i] = vl0[i] * t0 + vl1[i] * t1;

	calculatePolygonNormals();
	calculateVertexNormals();
}


void srMAXMorphModel::reindexVertices(const SRDWORD* reindex)
{
	if(!vertexLoc || (numTargets == 0))
		return;

	srVector3* tmp = new srVector3[vnum];

	for(SRDWORD i = 0; i < numTargets; i++)
	{
		if(vertexLoc[i])
		{
			for(SRDWORD j = 0; j < (SRDWORD)vnum; j++)
				tmp[j] = vertexLoc[i][j];

			for(j = 0; j < (SRDWORD)vnum; j++)
				vertexLoc[i][j] = tmp[reindex[j]];
		}
	}
	delete[] tmp;

	srMeshModel::reindexVertices(reindex);

	// this will copy the vertexLocs from the first target to the srMeshModel vertex loc array:
	calculateBounds();
}

