
#ifndef __SRHXCHUNKREAD_HPP_INCLUDED
#define __SRHXCHUNKREAD_HPP_INCLUDED
/*****************************************************************************
 *
 * SurRender - Real-Time 3D Graphics Library
 * -----------------------------------------
 *
 * (C) 1994-1998 Hybrid Holding, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Holding, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irrepairable harm to
 * Hybrid Holding and legal action against the party in breach.
 *
 *
 * Desc: SurRender3D HX-file reader
 *
 * $Archive: /srsdk1x/include/misc/hximporter/srHXChunkRead.hpp $
 * $Author: samuli $
 * $Revision: #1 $
 * $Modtime: 11/09/98 9:45p $
 * $Date: 2003/01/08 $
 *
 *****************************************************************************/


#include "srHXTypes.hpp"
#include "srIO.hpp"
#include "srBinIStream.hpp"
#include "srHash.hpp"

#pragma SRPACKPUSH

class srHXChunkRead;

typedef	void (srHXChunkRead::*ReadFunc)();



class SRHXDEC srHXChunkRead
{
public:
	class Chunk
	{
	public:
		SRDWORD		id;
		SRDWORD		dataSize;			// this chunks data size, not including subchunks
		SRDWORD		nextChunk;			// file offset to the next chunk on this level, 0 indicates no more chunks on the current level

		Chunk()		{ dataSize = 0; id = 0; nextChunk = 0; }

		void get(srBinIStream& in)
		{
			in >> id;
			in >> dataSize;
			in >> nextChunk;
		}
	};

	struct ReaderDef
	{
		SRDWORD		chunkID;
		void*		func;			// read function (this is a srHXChunkRead::member typed function pointer!)
		void*		postFunc;		// post process function (called after the whole chunk is read)
		ReaderDef(SRDWORD c, void *f, void *pf)	{ chunkID = c; func = f; postFunc = pf; }
	};

	srHXChunkRead();
	~srHXChunkRead();

	void		setStream(srBinIStream* input)		{ stream = input; }
	void		read();
	void		readChunks(int nextChunk, int level);

	SRDWORD		getCurChunkDataSize()				{ return curChunkDataSize; }

	void		get(srVector3* array, SRDWORD count);
	void		get(srVector3i* array, SRDWORD count);
	SRCHAR*		getString();

protected:
	srBinIStream*						stream;

	SRDWORD								curChunkDataSize;
	srHash<SRDWORD, ReaderDef*>			readerHash;
private:
};

#pragma SRPACKPOP


#endif		// __SRHXCHUNKREAD_HPP_INCLUDED