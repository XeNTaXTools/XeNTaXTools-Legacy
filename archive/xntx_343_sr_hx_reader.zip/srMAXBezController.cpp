

#ifdef KILGORE_TROUT

#include "srMAXBezController.hpp"
#include "srVector3.hpp"

srMAXBezController::srMAXBezController()
{
/*	rangeStart = 0.f;
	rangeEnd   = 1.f;
	const int N = 7;

	setNumElements(2);
	setNumKeys(N);

	srand(0xdeadbabe);

/*	for(int i = 0; i < N; i++)
	{
		keys[i].value[1] = (((rand() % 100)/50.f)-1.f)*1.6f;
		keys[i].value[0] = (((float)i / (float)N) - 0.5f) * 7.f;
		keys[i].time	 = (float)i / (N-1);
	}*/

/*	for(int i = 0; i < N; i++)
	{
		double ang = srDegreeToRad(((float)i / (float)(N-1)) * 360.f);
		values[0][i] = sin(ang)*1.5f;
		values[1][i] = cos(ang)*1.5f;
		keys[i].time	 = (float)i / (N-1);
	}*/
}

void srMAXBezController::CompAdjBesselBezPoints(int i)
{
	float dm,dp;
	float m;
	float ap,am;
	int nKeys = NKeys();
	int l = (i-1+nKeys)%nKeys;
	int n = (i+1)%nKeys, el;
	float ldu, du;	
	SRBOOL doIn, doOut;
	SRDWORD inType, outType;

	inType  = GetInTanType(KFlags(i));
	outType = GetOutTanType(KFlags(i));
	doIn    = inType==HYBRID_SMOOTH;
	doOut   = outType==HYBRID_SMOOTH;

	ldu = DU(l,i); 
	du  = DU(i,n); 
	if (ldu==0.0f || du==0.0f ||
	    ((i==0 || i==nKeys-1) && !Closed()) ) 
	{
		if (doOut) 
		{
			if (i==0) 
			{
				BesselStart(i);
			} else 
			{
				SlowOut(i);
			}
		}
		if (doIn) 
		{
			if (i==nKeys-1) 
			{
				BesselEnd(i);
			} else 
			{
				SlowIn(i);
			}
		}
		return;
	} 

	if (doOut && !doIn) 
	{
		switch (inType) 
		{			
			case HYBRID_LINEAR:
			case HYBRID_USER:
			case HYBRID_FAST:
			case HYBRID_SLOW:
				for  (el=0;el<nElems;el++) 
				{
					OutTan(i,el) = -InTan(i,el);
				}
				break;
			case HYBRID_STEP:
				for (el=0;el<nElems;el++) 
				{
					OutTan(i,el) = 0.0f;
				}
				break;
			}
		return;
		}
	if (doIn && !doOut) 
	{
		switch (outType) {			
			case HYBRID_LINEAR:
			case HYBRID_USER:
			case HYBRID_FAST:
			case HYBRID_SLOW:
				for (el=0;el<nElems;el++) 
				{
					InTan(i,el) = -OutTan(i,el);
				}
				break;			
			case HYBRID_STEP:
				for (el=0;el<nElems;el++) 
				{
					InTan(i,el) = 0.0f;
				}
				break;
		}
		return;
	}
	
	ap  = ldu / (ldu + du);
	am  = 1.0f-ap;

	for (el=0;el<nElems;el++) 
	{
		dm = Value(i,el) - Value(l,el);
		dp = Value(n,el) - Value(i,el);		
		m  = ( (am / ldu)*dm + (ap / du)*dp );		
		if (doIn)  InTan(i,el)  = -m;
		if (doOut) OutTan(i,el) = m;
	}
}

void srMAXBezController::BesselEnd(int i)
{
	float d0,d1,m,a,lldu,ldu;	
	int nKeys = NKeys();

	if (nKeys==1) 
	{
		for (int el=0;el<nElems;el++) 
		{
			InTan(i,el)  = .0f;
			OutTan(i,el) = .0f;
		}
	} else
	if (i==1) 
	{		
		ldu = DU(0,1); 
		if (ldu==0.0f) ldu = 1.0f;
		for (int el=0;el<nElems;el++) 
		{
			//InTan(i,el) = (Value(i-1,el)-Value(i,el))/(3.0f*ldu);
			InTan(i,el) = (Value(i-1,el)-Value(i,el))/(ldu);
			if (i==nKeys-1) OutTan(i,el) = .0f;
		}
	} else 
	{			
		ldu  = DU(i-1,i); 
		lldu = DU(i-2,i-1); 
		if (ldu==0.0f) ldu = 1.0f;
		if (lldu==0.0f) lldu = 1.0f;
		a =  lldu / (lldu + ldu);
		for (int el=0;el<nElems;el++) 
		{
			d0 = Value(i-1,el) - Value(i-2,el);
			d1 = Value(i,el) - Value(i-1,el);			
			m = ( ((a-1.0f) / lldu)*d0 + ((2.0f-a) / ldu)*d1);
			InTan(i,el) = -m;
			if (i==nKeys-1) OutTan(i,el) = .0f;
		}
	}
}

void srMAXBezController::BesselStart(int i)
{
	float d0,d1,m,a,ndu,du;			
	int nKeys = NKeys();

	if (nKeys==1) 
	{
		for (int el=0;el<nElems;el++) 
		{
			InTan(i,el)  = .0f;
			OutTan(i,el) = .0f;
		}
	} else
	if (i==nKeys-2) 
	{		
		du = DU(i,i+1); 
		if (du==0.0f) du = 1.0f;
		for (int el=0;el<nElems;el++) 
		{
			//OutTan(i,el) = (Value(i+1,el)-Value(i,el))/(3.0f*du);
			OutTan(i,el) = (Value(i+1,el)-Value(i,el))/(du);
			if (i==0) 
				InTan(i,el) = .0f;
		}
	} else 
	{						
		du  = DU(i,i+1); 
		ndu = DU(i+1,i+2); 
		if (du==0.0f) du = 1.0f;
		if (ndu==0.0f) ndu = 1.0f;
		a =  du / (du + ndu);
		for (int el=0;el<nElems;el++) 
		{
			d0 = Value(i+1,el) - Value(i,el);
			d1 = Value(i+2,el) - Value(i+1,el);			
			m = ( ((1.0f + a) / du) * d0 - (a / ndu) * d1);
			OutTan(i,el) = m;
			if (i==0) InTan(i,el) = .0f;
		}
	}
}

void srMAXBezController::LinearIn(int i)
{
	int j = (i-1+NKeys())%NKeys();
	float du = DU(j,i); 
	if (du==0.0f) du = 1.0f;
	for (int el=0;el<nElems;el++) 
	{
		InTan(i,el) = (Value(j,el)-Value(i,el))/du; 			
	}
}

void srMAXBezController::LinearOut(int i)
{
	int j = (i+1)%NKeys();
	float du = DU(i,j); 
	if (du==0.0f) du = 1.0f;
	for (int el=0;el<nElems;el++) 
	{
		OutTan(i,el) = (Value(j,el)-Value(i,el))/du; 			
	}
}

void srMAXBezController::FastIn(int i)
{
	int nKeys = NKeys();
	int j = (i-1+nKeys)%nKeys;
	float du = DU(j,i); 
	if (du==0.0f) du = 1.0f;
	for (int el=0;el<nElems;el++) 
	{
		InTan(i,el) = (Value(j,el)-Value(i,el))*2.0f/du; 			
	}
}

void srMAXBezController::FastOut(int i)
{
	int j = (i+1)%NKeys();
	float du = DU(i,j); 
	if (du==0.0f) du = 1.0f;
	for (int el=0;el<nElems;el++) 
	{
		OutTan(i,el) = (Value(j,el)-Value(i,el))*2.0f/du; 			
	}
}

void srMAXBezController::SlowIn(int i)
{
	for (int el=0;el<nElems;el++) 
	{
		InTan(i,el) = 0.0f;
	}
}

void srMAXBezController::SlowOut(int i)
{
	for (int el=0;el<nElems;el++) 
	{
		OutTan(i,el) = 0.0f;
	}
}

void srMAXBezController::StepIn(int i)
{
	SlowIn(i);
}

void srMAXBezController::StepOut(int i)
{
	SlowOut(i);
}


#define INTERP(v0,out,in,v1,u,u2,s) \
	(((s*v0 + (3.0f*u)*out)*s + (3.0f*u2)*in)*s + u*u2*v1)

#define NUMARCSTEPS 40
#define USTEP	0.025f
#define EPSILON 0.1f

float srMAXBezController::ArcLengthTo(int n0, int n1, float tou)
{
	srVector3 v0, v1, inTan, outTan, last, cur;	
	float du = DU(n0,n1)/3.0f;
	float len = 0.0f, u=0.0f, s, u2;

	for (int el=0; el<nElems; el++) 
	{
		v0[el]     = Value(n0,el);
		v1[el]     = Value(n1,el);
		inTan[el]  = InTan(n1,el) * du + v1[el];
		outTan[el] = OutTan(n0,el) * du + v0[el];
	}
	
	// Calculate arclength	
	last = v0;
	while (u<tou) 
	{	
		u   += USTEP;
		if (u>tou) u = tou;
		u2   = u*u;
		s    = 1.0f-u;
		cur  = INTERP(v0,outTan,inTan,v1,u,u2,s);
		len += (float)srVector3(cur-last).length();
		last = cur;
	}
	
	return len;
}

 /*
void srMAXBezController::DebugVelocity(int i)
{	
	int i1 = (i+1) % NKeys();
	float curLen = 0.0f, lastLen = 0.0f, u;
	float minv, maxv, v;
	float acc=0.0f;
	float ov=0.0f;
	TimeValue t0 = Time(i);
	TimeValue t1 = Time(i1);
	if (t1<t0) return;
		
	minv = maxv = 0.0f;
	for (int j=t0+GetTicksPerFrame(); j <= t1; j++) {
		u    = float(j-t0)/float(t1-t0);
		lastLen = curLen;
		curLen  = ArcLengthTo(i,i1,u);				
		v       = curLen - lastLen;
		
		if (j==t0+GetTicksPerFrame()) {
			minv = maxv = v;
		} else {
			if (v < minv) minv = v;
			if (v > maxv) maxv = v;
			}

		if (j==t0+2*GetTicksPerFrame()) {
			acc = v-ov;
		} else {
			if (fabs(v-ov) > fabs(acc)) {
				acc = v-ov;
				}
			}			 
		ov = v;		
		}
	
	TSTR buf, buf2;
	buf.printf("Min velocity:%f Max velocity:%f Max acceleration:%f",minv, maxv,acc);
	buf2.printf("Velocities for key #%d",i);
	MessageBox(NULL,buf,buf2,MB_OK);
}
*/
void srMAXBezController::InterpConstVelocity(int n0, int n1, float d, float *val)
{
/*	srVector3 v0, v1, inTan, outTan, last, cur, res;
	float du = DU(n0,n1)/3.0f, s;
	float totalDist = ArcLength(n0);
	float curDist   = DistCache(n0);
	float lastDist;
	float targDist  = d * totalDist;
	float u         = UCache(n0);
	float u2;
	BOOL neg		= targDist < curDist;
	float ustep     = neg ? -USTEP : USTEP;
		
	for (int el=0; el<nElems; el++) {		
		v0[el]     = Value(n0,el);
		v1[el]     = Value(n1,el);
		inTan[el]  = InTan(n1,el) * du + v1[el];
		outTan[el] = OutTan(n0,el) * du + v0[el];
		}	
	
	// Start from the cache position
	s = 1.0f-u;
	u2 = u*u;
	last = INTERP(v0,outTan,inTan,v1,u,u2,s);

	// Just in case
	if (targDist == curDist) {
		val[0] = last.x;
		val[1] = last.y;
		val[2] = last.z;
		return;
		}

	while (TRUE) {		
		u   += ustep;
		u2   = u*u;
		s    = 1.0f-u;
		cur  = INTERP(v0,outTan,inTan,v1,u,u2,s);
		
		lastDist = curDist;
		if (neg) {
			curDist -= Length(cur-last); 
			if (curDist < targDist) {				
				break;
				}
		} else {
			curDist += Length(cur-last); 
			if (curDist > targDist) {				
				break;
				}
			}
		last = cur;
		
		//assert(u>=-EPSILON && u<=1.0f+EPSILON);
		if (u<-EPSILON || u>1.0f+EPSILON) break;
		}

	// When we step past, linearly interpolate to get the result
	res = last + (cur-last) * ((targDist-lastDist) / (curDist-lastDist));
	DistCache(n0) = curDist;
	UCache(n0)    = u;
	val[0] = res.x;
	val[1] = res.y;
	val[2] = res.z;*/
}

void srMAXBezController::UpdateConstVelocity(int i)
{
/*	Point3 v0, v1, inTan, outTan, last, cur;
	int i1 = (i+1) % NKeys();
	float du = DU(i,i1)/3.0f;
	float len = 0.0f, u, s, u2;

	for (int el=0; el<nElems; el++) {
		v0[el]     = Value(i,el);
		v1[el]     = Value(i1,el);
		inTan[el]  = InTan(i1,el) * du + v1[el];
		outTan[el] = OutTan(i,el) * du + v0[el];
		}
	
	// Calculate arclength	
	last = v0;
	for (int j=1; j <= NUMARCSTEPS; j++) {
		u    = float(j)/NUMARCSTEPS;
		u2   = u*u;
		s    = 1.0f-u;
		cur  = INTERP(v0,outTan,inTan,v1,u,u2,s);
		len += Length(cur-last);
		last = cur;
		}
	ArcLength(i) = len;
	UCache(i)    = 0.0f;
	DistCache(i) = 0.0f;*/
}
	
void srMAXBezController::PrepareTrack()
{
	int nKeys = NKeys();
	for (int i=0; i<nKeys; i++) 
	{		
		SRDWORD inType  = GetInTanType(KFlags(i));
		SRDWORD outType = GetOutTanType(KFlags(i));		
		SRDWORD prevOut = i?GetOutTanType(KFlags(i-1)):0xffffffff;
		SRDWORD nextIn  = i<nKeys-1?GetInTanType(KFlags(i+1)):0xffffffff;

		switch (inType) 
		{
			case HYBRID_LINEAR: 
				if (prevOut!=HYBRID_LINEAR && i) 
				{
					BesselEnd(i);
				} else 
				{
					LinearIn(i);
				}
				break;
			case HYBRID_STEP: StepIn(i); break;
			case HYBRID_FAST: FastIn(i); break;
			case HYBRID_SLOW: SlowIn(i); break;
		}

		switch (outType) 
		{
			case HYBRID_LINEAR: 
				if (nextIn!=HYBRID_LINEAR && i<nKeys-1) 
				{
					BesselStart(i);
				} else 
				{
					LinearOut(i); 
				}
				break;
			case HYBRID_STEP: StepOut(i); break;
			case HYBRID_FAST: FastOut(i); break;
			case HYBRID_SLOW: SlowOut(i); break;
		}
		
		if (inType==HYBRID_SMOOTH || outType==HYBRID_SMOOTH) 
		{
			CompAdjBesselBezPoints(i);
		}
	}
	
	if (nElems==3) 
	{
		// Check for constant velocity keys.
		for (i=0; i<nKeys-1; i++) {
			if (KFlags(i)&KEY_CONSTVELOCITY) {
				if (GetInTanType(KFlags(i+1))==HYBRID_STEP ||
					GetOutTanType(KFlags(i))==HYBRID_STEP) {
					continue;
					}
				UpdateConstVelocity(i);
				}
			}
		}
}

float srMAXBezController::DU(int n0,int n1)
{
	float du;
	if (n1>n0) 
		du = float(Time(n1)-Time(n0));
	else 
		du = float(Time(n1)-getRangeStart() + getRangeEnd()-Time(n0));
	return du;
}

void srMAXBezController::InterpValue(int n0, int n1, float u, float *val)
{
	float s = (float)1.0-u;
	float u2 = u*u, out, in, du;
	SRDWORD inType  = GetInTanType(KFlags(n1));
	SRDWORD outType = GetOutTanType(KFlags(n0));

//	if (!TangentsValid()) {
		PrepareTrack();
//		ValidateTangents();
//		}
	
	if (outType==HYBRID_STEP || inType==HYBRID_STEP) 
	{
		for (int el=0; el<nElems; el++) 
		{
			if (u==1.0f) 
			{
				val[el] = Value(n1,el);
			} else 
			{
				val[el] = Value(n0,el);
			}
		}
		return;
	}
	
	if (KFlags(n0)&KEY_CONSTVELOCITY && nElems==3 && n0<NKeys()-1) 
	{
		InterpConstVelocity(n0,n1,u,val);
	} 
	else 
	{
		du = DU(n0,n1)/3.0f;
		for (int el=0; el<nElems; el++) 
		{
			out = OutTan(n0,el)*du + Value(n0,el);
			in  = InTan(n1,el)*du + Value(n1,el);
			val[el] = ( ( s*Value(n0,el) + (3.0f*u)*out)*s 
		 		+ (3.0f*u2)*in)*s + u*u2*Value(n1,el);	
		}
	}
}




float srMAXBezController::getValue(float time)
{
	time = (float)fmod(time, getRangeEnd());

	int n = getKeyIndex(time);
	int n0 = n;
	int n1 = n + 1;
	if(n1 >= NKeys())
		n1 = n;

	float u = (time - keys[n0].time) / (keys[n1].time - keys[n0].time);
	float v[3];
	InterpValue(n0, n1, u, v);
	return v[0];
}
#endif