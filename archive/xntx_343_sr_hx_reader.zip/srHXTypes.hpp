
#ifndef __SRHXTYPES_HPP_INCLUDED
#define __SRHXTYPES_HPP_INCLUDED
/*****************************************************************************
 *
 * SurRender - Real-Time 3D Graphics Library
 * -----------------------------------------
 *
 * (C) 1994-1998 Hybrid Holding, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Holding, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irrepairable harm to
 * Hybrid Holding and legal action against the party in breach.
 *
 *
 * Desc: HX types (class ids etc)
 *
 * $Archive: /srsdk1x/include/misc/hximporter/srHXTypes.hpp $
 * $Author: samuli $
 * $Revision: #1 $
 * $Modtime: 12/22/98 12:12p $
 * $Date: 2003/01/08 $
 *
 *****************************************************************************/


// are we building a DLL or are we using the DLL from another module?
#if defined(SRHX_BUILD_DLL)
#define SRHXDEC __declspec(dllexport)
#else
#define SRHXDEC __declspec(dllimport)
#endif

// sort of a namespace for our own class IDs
struct srHX
{
	enum										// HX MAX class IDs
	{	
		ID_MAX_MORPH_MODEL			= 0x8100, 
		ID_MAX_MODEL_INSTANCE
	};

	// unit scale
	enum e_unittype
	{
		UNIT_MILLIMETERS	= 0,		// metric
		UNIT_CENTIMETERS	= 1,
		UNIT_METERS			= 2,
		UNIT_KILOMETERS		= 3,
		UNIT_INCHES			= 4,		// imperial
		UNIT_FEET			= 5,
		UNIT_MILES			= 6,
	};
};


#endif		// __SRHXTYPES_HPP_INCLUDED