
#ifndef __SRMAXMODIFIER_HPP_INCLUDED
#define __SRMAXMODIFIER_HPP_INCLUDED

#include "srClassSupport.hpp"
#include "srArray.hpp"
#include "srMAXBezController.hpp"


class FloatController
{
public:
	enum e_loopType
	{
		CONSTANT,
		LOOP
		// more: ping pong, linear, relative repeat, cycle
	};

	struct FloatKey
	{
		FloatKey(float t, float v)		{ time = t; value = v; }
		FloatKey()						{ }

		float		time;
		float		value;
	};

						FloatController();
						~FloatController();


	void				setLoopType(e_loopType t)				{ outOfRangeType = t;		}
	e_loopType			getLoopType()							{ return outOfRangeType;	}

	SRDWORD				getKeyCount()							{ return keys.getSize();	}
	void				setKeyCount(SRDWORD s)					{ keys.resize(s);			}
	void				setKey(SRDWORD ndx, const FloatKey& k)	{ keys[ndx] = k; evaluate(k);	}

	float				getValue(const float time);


protected:
private:

	void				evaluate(const FloatKey& k);

	float				rangeStart;				// time range begin
	float				rangeEnd;				// time range end

	srArray<FloatKey>	keys;
	e_loopType			outOfRangeType;
};

class srMAXModifier : public srClassSupport<srMAXModifier, srClass, true, 0xca7f00b>
{
public:
							srMAXModifier()									{}
	virtual					~srMAXModifier()								{}
	virtual void			apply(srVector3* dst, const srVector3* src, SRDWORD vxCount) = 0;

protected:
private:
};

class srMAXMorphModifier : public srClassSupport<srMAXMorphModifier, srMAXModifier, false, 0xca7f00d>
{
public:
	// DEBUG DEBUG to be implemented
	class WeightController : public FloatController
	{
	public:
		float				getWeight(const float time)		{ return getValue(time); }
	};

	class Channel
	{
	public:
		SRDWORD				getVertexCount()				{ return numPoints;		}
		srVector3*			getVertexDeltas()				{ return &vDeltas[0];	}
		SRDWORD*			getVertexIndices()				{ return &vIndex[0];	}
		srMAXBezController&	getController()					{ return wController;	}

		void				setVertexCount(SRDWORD c)		{ numPoints = c; vIndex.resize(c, false); vDeltas.resize(c, false); }
		void				setVertexIndices(SRDWORD* n)	{ for(SRDWORD i = 0; i < numPoints; i++) vIndex[i] = n[i]; }
		void				setVertexDeltas(srVector3* v)	{ for(SRDWORD i = 0; i < numPoints; i++) vDeltas[i] = v[i]; }

	private:
		SRDWORD				numPoints;					// number of vertices in this morph channel
		srArray<SRDWORD>	vIndex;						// vertex indices (from linear to original vertex order)
		srArray<srVector3>	vDeltas;					// vertex deltas
//		WeightController	wController;				// animation track containing morph weight keyframes
		srMAXBezController	wController;				// weight controller
	};


	srClass*				vInstance()									{ return new srMAXMorphModifier; }
	static SRCSTRING		sGetClassName()								{ return "srMAXMorphModifier"; }

	
							srMAXMorphModifier();
							~srMAXMorphModifier() {}
	void					apply(srVector3* dst, const srVector3* src, SRDWORD vertexCount);
	SRDWORD					getMorphChannelCount()					{ return numMorphChannels; }
	void					setMorphChannelCount(SRDWORD cnt)		{ morphChannels.resize(cnt); numMorphChannels = cnt; }
	Channel&				getMorphChannel(SRDWORD chn)			{ return morphChannels[chn]; }

protected:
	SRDWORD					numMorphChannels;			// total number of morph channels
	srArray<Channel>		morphChannels;				// morph channels
//	srArray<srVector3>		vertices;					// original vertices
private:
};


#endif		// __SRMAXMODIFIER_HPP_INCLUDED