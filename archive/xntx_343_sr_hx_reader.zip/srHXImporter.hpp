
#ifndef __SRHXIMPORTER_HPP_INCLUDED
#define __SRHXIMPORTER_HPP_INCLUDED
/*****************************************************************************
 *
 * SurRender - Real-Time 3D Graphics Library
 * -----------------------------------------
 *
 * (C) 1994-1998 Hybrid Holding, Ltd.
 * All Rights Reserved.
 *
 * This file consists of unpublished, proprietary source code of
 * Hybrid Holding, and is considered Confidential Information for
 * purposes of non-disclosure agreement. Disclosure outside the terms
 * outlined in signed agreement may result in irrepairable harm to
 * Hybrid Holding and legal action against the party in breach.
 *
 *
 * Desc: SurRender3D HX-file reader
 *
 * $Archive: /srSDK1x/include/misc/hximporter/srHXImporter.hpp $
 * $Author: samuli $
 * $Revision: #1 $
 * $Modtime: 9/21/99 3:09p $
 * $Date: 2003/01/08 $
 *
 *****************************************************************************/

#include "srTypes.hpp"
#include "srHXTypes.hpp"
#include "srBinIStream.hpp"
#include "srScene.hpp"
#include "srHXChunkRead.hpp"
#include "DynArray.hpp"
#include "srShader.hpp"
#include "srMaterial.hpp"
#include "srMAXMorphModel.hpp"

#pragma SRPACKPUSH

/******************************************************************************
 *
 * Class:			srHXImporter
 *
 * Description:		SurRender HX-file importer
 *
 ******************************************************************************/
class SRHXDEC srHXImporter : public srHXChunkRead
{
public:
	srHXImporter();
	~srHXImporter();

	void		importScene(srScene* scene, srBinIStream& stream);

	struct UnitScale
	{
		SRDWORD				scale;
		srHX::e_unittype	type;
	};

	UnitScale	getUnitScale();
protected:

	srScene*	parentScene;

private:
	struct Children
	{
		Children()				{ childIDArray = NULL; childCount = 0;						}
		Children(int cCount)	{ childIDArray = new SRDWORD[cCount]; childCount = cCount;	}
		~Children()				{ if(childIDArray) delete[] childIDArray;					}

		SRDWORD		childCount;
		SRDWORD*	childIDArray;
	};

	struct Transformer
	{
		srMatrix3	rot;
		srVector3	translation;
		srVector3	scale;

		// DEBUG DEBUG kludge
		void	get(srBinIStream* in)
		{
			SRDWORD* f = (SRDWORD*)&rot;
			for(int i = 0; i < 3 + 9 + 3; i++)
			{
				*in >> f[i];
			}
		}
	};

	struct NodeHeader
	{
		SRDWORD		id;
		SRDWORD		refObjectID;
		SRDWORD		childCount;
		SRDWORD		flags;

		void	get(srBinIStream* in)
		{
			*in >> id;
			*in >> refObjectID;
			*in >> childCount;
			*in >> flags;
		}
	};

	void		registerLoaders();
	void		unregisterLoaders();


	// material readers:
	void		readMaterialLibrary();
	void		readVertexMaterial();
	void		readMaterialTexture();
	void		readMaterialTextureHeader();
	void		readMaterialTextureFname();
	void		readMaterialShader();

	// models
	void		readObjects();
	void		readObject();
	void		postReadObject();
	void		readObjectHeader();

	void		readObjectName();

	void		readTrimesh();
	void		postReadTrimesh();
	void		readTrimeshHeader();
	void		readTrimeshVertexLoc();
	void		readTrimeshPolyVertex();
	void		readTrimeshVertexUVW();
	void		readTrimeshVertexShadeRemap();

	void		readTrimeshPassArrays();
	void		readTrimeshPassHeader();
	void		readTrimeshMtlArray();
	void		readTrimeshTexArray();
	void		readTrimeshShaderArray();
	void		readTrimeshVxColorArray();

	void		readTrimeshMTgtHdr();
	void		readTrimeshMKeyHdr();
	void		readTrimeshMKeyArray();


	void		readModifier();
	void		readMorphModifier();
	void		readMorphModifierHeader();
	void		readMorphModifierChannel();
	void		postReadMorphModifierChannel();
	void		readMorphModifierChannelHeader();
	void		readMorphModifierChannelVIndex();
	void		readMorphModifierChannelVDeltas();
	void		readMorphModifierOrigVertices();

	void		readKFController();
	void		readKFControllerHeader();
	void		readKFControllerKeys();


	// cameras
	void		readCamera();
	void		readCameraHeader();

	// lights
	void		readLight();
	void		readLightHeader();


	// scene graph
	void		readSceneGraph();
	void		postReadSceneGraph();

	void		readNode();
	void		postReadNode();
	
	void		readNodeHeader();
	void		readNodeTransform();
	void		readNodeLocalTransform();
	void		readNodeModel();
	void		readNodeModelHeader();
	void		readNodeName();
	void		readNodeChildIDArray();

	void		readNodeLight();
	void		readNodeLightHeader();

	void		readNodeCamera();

	// properties
	void		readUnitScale();

	// material stuff:
	DynArray<srMaterial*>				materialLookup;
	DynArray<srTexture*>				textureLookup;
	SRDWORD								curTexRefID;
	DynArray<srShader*>					shaderLookup;
	SRDWORD								curPassIndex;


	// model library
	SRDWORD								curObjectRefID;
	SRDWORD								numObjectRefs;
	srMAXMorphModel*					curModel;
	srHash<SRDWORD, srClass*>			modelLib;
	SRDWORD								morphTargetNdx;

	// modifier stuff
/*	srMAXMorphModifier*					morphMod;
	SRDWORD								morphChannelNdx;
	srMAXBezController*					curBezControl;
*/	
	srHash<SRDWORD, srNode*>			nodeHash;
	srHash<SRDWORD, Children*>			childIDArrayHash;
	SRDWORD								nodeCount;

	Transformer							curTransform;
	Transformer							curObjOffsTransform;
	srNode*								curNode;
	NodeHeader							curNodeHdr;
	SRSTRING							curNodeName;
	SRSTRING							curObjectName;

	// unit type
	SRDWORD								unitType;
	// master unit scale
	float								unitScale;


	DynArray<void*>						temp;
};


#pragma SRPACKPOP
#endif	// __SRHXIMPORTER_HPP_INCLUDED
