from inc_noesis import *
import noesis
import rapi

def registerNoesisTypes():
    handle = noesis.register("swtor.jedipedia.net (cache)", ".gr2")
    noesis.setHandlerTypeCheck(handle, noeCheckGeneric)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)
    #noesis.logPopup()
    return 1

def noepyLoadModel(data, mdlList):
    ctx = rapi.rpgCreateContext()
    bs = NoeBitStream(data)
    type = bs.readUShort()
    if type == 0:
        bs.seek(0x24, NOESEEK_ABS)
    if type == 1:
        bs.seek(0x38, NOESEEK_ABS)
    if type == 2:
        search = bs.readBytes(200)
        index = search.rfind(b'\xFF\xFF') 
        bs.seek(index + 12, NOESEEK_ABS)
    VCount = bs.readInt()                                 #vertex count
    FCount = bs.readInt()                                 #face indices count
    if type == 0 or type == 1: 
        bs.seek(0x10, NOESEEK_REL)
    if type == 2:
        bs.seek(0x1c, NOESEEK_REL)
    VBuf = bs.readBytes(VCount * 12)
    rapi.rpgBindPositionBufferOfs(VBuf, noesis.RPGEODATA_FLOAT, 12, 0)   #position of vertices
    skip = bs.readBytes(VCount * 4)
    skip = bs.readBytes(VCount * 8)
    UVBuf = bs.readBytes(VCount * 8)
    rapi.rpgBindUV1BufferOfs(UVBuf, noesis.RPGEODATA_FLOAT, 8, 0)   #UVs
    skip = bs.readBytes(VCount * 8)
    IBuf = bs.readBytes(FCount * 2)                       #multiply by 2 for word, 4 for dword indices 
    rapi.rpgCommitTriangles(IBuf, noesis.RPGEODATA_SHORT, FCount, noesis.RPGEO_TRIANGLE, 1) #SHORT for word , INT for dword
    mdl = rapi.rpgConstructModel()                                                          
    mdlList.append(mdl)
    rapi.rpgClearBufferBinds()
    return 1