#include "stdafx.h"

// containers
void ProcessFLP(void);
bool ProcessFLP(const char* filename);

// textures
void ProcessHTX(void);
bool ProcessHTX(const char* filename);

// models
void ProcessHMD(void);
bool ProcessHMD(const char* filename);

struct VERTEX {
 float x;
 float y;
 float z;
 float u;
 float v;
 unsigned short type;
};

VERTEX read_vertex(ifstream& ifile, unsigned int size)
{
 VERTEX retval;
 if(size == 20) {
    retval.x = BE_read_float(ifile); // 4
    retval.y = BE_read_float(ifile); // 8
    retval.z = BE_read_float(ifile); // 12
    cout << (unsigned)BE_read_uint08(ifile) << endl; // 13
    cout << (unsigned)BE_read_uint08(ifile) << endl; // 14
    cout << (unsigned)BE_read_uint08(ifile) << endl; // 15
    cout << (unsigned)BE_read_uint08(ifile) << endl; // 16
    cout << endl;
    retval.u = BE_read_half_float(ifile); // 18
    retval.v = BE_read_half_float(ifile); // 20
   }
 else if(size == 32) {
    retval.x = BE_read_float(ifile); // 4
    retval.y = BE_read_float(ifile); // 8
    retval.z = BE_read_float(ifile); // 12
    cout << retval.x << endl;
    cout << retval.y << endl;
    cout << retval.z << endl;
    cout << BE_read_uint16(ifile) << endl; // 14
    cout << BE_read_uint16(ifile) << endl; // 16
    cout << BE_read_uint16(ifile) << endl; // 18
    cout << BE_read_uint16(ifile) << endl; // 20
    cout << BE_read_uint16(ifile) << endl; // 22
    cout << BE_read_uint16(ifile) << endl; // 24
    BE_read_half_float(ifile); // 26 (sometimes u)
    BE_read_half_float(ifile); // 28 (sometimes v)
    retval.u = BE_read_half_float(ifile); // 30 (sometimes u)
    retval.v = BE_read_half_float(ifile); // 32 (sometimes v)
    cout << retval.u << endl;
    cout << retval.v << endl;
    cout << endl;
   }
 return retval;
}

int main()
{
 //cout << "PROCESSING CONTAINERS" << endl;
 //ProcessFLP();
 //cout << "PROCESSING TEXTURES" << endl;
 //ProcessHTX();
 //cout << "PROCESSING MODELS" << endl;
 //ProcessHMD();

 ProcessHMD("sample3.hmd");

 return -1;
}

void ProcessFLP(void)
{
 deque<string> namelist;
 get_filename_list(namelist, "flp");
 for(size_t i = 0; i < namelist.size(); i++) ProcessFLP(namelist[i].c_str());
}

bool ProcessFLP(const char* filename)
{
 // message
 cout << "Processing FLP: " << filename << endl;

 // extract filename parameters
 char param1[MAX_PATH];
 char param2[MAX_PATH];
 char param3[MAX_PATH];
 char param4[MAX_PATH];
 _splitpath(filename, param1, param2, param3, param4);

 // change extension
 string fullpath(param1);
 fullpath += param2;

 // create extraction directory
 string epath = fullpath;
 epath += param3;
 epath += "\\";
 SHCreateDirectoryEx(NULL, epath.c_str(), NULL);
 
 // create file
 ifstream ifile(filename, ios::binary);
 if(!ifile) return error("Failed to open file.");

 // read header
 unsigned int h01 = LE_read_uint32(ifile); // magic
 unsigned int h02 = LE_read_uint32(ifile); // approx. filesize
 unsigned int h03 = LE_read_uint32(ifile); // 0x20
 unsigned int h04 = LE_read_uint32(ifile); // 0x10000000
 unsigned int h05 = LE_read_uint32(ifile); // 0x00
 unsigned int h06 = LE_read_uint32(ifile); // approx. filesize
 unsigned int h07 = LE_read_uint32(ifile); // 0x00
 unsigned int h08 = LE_read_uint32(ifile); // 0x00
 unsigned int h09 = BE_read_uint32(ifile); // number of files is big endian
 unsigned int h10 = LE_read_uint32(ifile); // 0 or 1
 unsigned int h11 = LE_read_uint32(ifile); // 0
 unsigned int h12 = LE_read_uint32(ifile); // 0

 // file information
 struct fileinfo {
  string filename;
  size_t length;
  size_t offset;
 };
 deque<fileinfo> filelist;

 // process file information
 for(size_t i = 0; i < h09; i++)
    {
     // read filename
     char buffer[36];
     ifile.read(&buffer[0], 36);
     unsigned int p1 = BE_read_uint32(ifile);
     unsigned int p2 = BE_read_uint32(ifile);
     unsigned int p3 = BE_read_uint32(ifile);
     //cout << "buffer = " << buffer << endl;
     //cout << "p1 = " << p1 << endl;
     //cout << "p2 = " << p2 << endl;
     //cout << "p3 = " << p3 << endl;
     //cout << endl;
     
     // save file information
     fileinfo info;
     info.filename = buffer;
     info.length = p1;
     info.offset = p2;
     filelist.push_back(info);
    }

 // process files
 for(size_t i = 0; i < filelist.size(); i++)
    {
     // create file
     string path(epath);
     path += filelist[i].filename;
     ofstream ofile(path.c_str(), ios::binary);
     if(!ofile) continue;

     // move to offset
     ifile.seekg(filelist[i].offset);
     if(ifile.fail()) return error("Failed to move to offset.");

     // copy contents
     char* data = new char[filelist[i].length];
     ifile.read(data, filelist[i].length);
     ofile.write(data, filelist[i].length);
     delete[] data;
     data = 0;
    }

 return true;
}

void ProcessHTX(void)
{
 deque<string> namelist;
 get_filename_list(namelist, "htx");
 for(size_t i = 0; i < namelist.size(); i++) ProcessHTX(namelist[i].c_str());
}

bool ProcessHTX(const char* filename)
{
 // message
 cout << "Processing HTX: " << filename << endl;

 // extract filename parameters
 char param1[MAX_PATH];
 char param2[MAX_PATH];
 char param3[MAX_PATH];
 char param4[MAX_PATH];
 _splitpath(filename, param1, param2, param3, param4);

 // full path
 string fullpath(param1);
 fullpath += param2;

 // create file
 ifstream ifile(filename, ios::binary);
 if(!ifile) return error("Failed to open file.");

 // header #1
 unsigned int h01 = LE_read_uint32(ifile); // magic
 unsigned int h02 = LE_read_uint32(ifile); // approx. filesize
 unsigned int h03 = LE_read_uint32(ifile); // 0x20
 unsigned int h04 = LE_read_uint32(ifile); // 0x1000000D
 unsigned int h05 = LE_read_uint32(ifile); // 0x00
 unsigned int h06 = LE_read_uint32(ifile); // 0x00
 unsigned int h07 = LE_read_uint32(ifile); // 0x00
 unsigned int h08 = LE_read_uint32(ifile); // 0x00

 if(h01 != 0x58455448)
    return error("Invalid HTX file.");

 // read textures
 for(;;)
    {
     // read magic
     unsigned int HTSF_01 = LE_read_uint32(ifile); // magic
     if(HTSF_01 == 0x43464F45) break; // finished
     if(HTSF_01 != 0x46535448) return error("Invalid HTX::HTSF section.");

     // read header
     unsigned int HTSF_02 = LE_read_uint32(ifile); // datasize (header + DDS + name)
     unsigned int HTSF_03 = LE_read_uint32(ifile); // 0x20
     unsigned int HTSF_04 = LE_read_uint32(ifile); // 0x1000000D
     unsigned int HTSF_05 = LE_read_uint32(ifile); // 1
     unsigned int HTSF_06 = LE_read_uint32(ifile); // datasize (header + DDS + name)
     unsigned int HTSF_07 = LE_read_uint32(ifile); // 0x00
     unsigned int HTSF_08 = LE_read_uint32(ifile); // 0x00
     unsigned int HTSF_09 = LE_read_uint32(ifile); // 2
     unsigned int HTSF_10 = LE_read_uint32(ifile); // 0x00
     unsigned int HTSF_11 = LE_read_uint32(ifile); // 0x00
     unsigned int HTSF_12 = LE_read_uint32(ifile); // 0x00
     unsigned int HTSF_13 = LE_read_uint32(ifile); // 0x00
     unsigned int HTSF_14 = LE_read_uint32(ifile); // 0x00
     unsigned int HTSF_15 = LE_read_uint32(ifile); // 0x00
     unsigned int HTSF_16 = LE_read_uint32(ifile); // 0x00

     // read DDS
     unsigned int datasize = HTSF_02 - 96;
     boost::shared_array<char> data(new char[datasize]);
     ifile.read((char*)&data[0], datasize);

     // read filename
     char buffer[32];
     ifile.read(&buffer[0], 32);

     // read padding
     char padding[32];
     ifile.read(&padding[0], 32);

     // create DDS file
     string ofilename(fullpath);
     ofilename += buffer;

     // write DDS
     ofstream ofile(ofilename.c_str(), ios::binary);
     ofile.write((char*)&data[0], datasize);
    }

 return true;
}

void ProcessHMD(void)
{
 deque<string> namelist;
 get_filename_list(namelist, "hmd");
 for(size_t i = 0; i < namelist.size(); i++) ProcessHTX(namelist[i].c_str());
}

bool ProcessHMD(const char* filename)
{
 // message
 cout << "Processing HMD: " << filename << endl;

 // extract filename parameters
 char param1[MAX_PATH];
 char param2[MAX_PATH];
 char param3[MAX_PATH];
 char param4[MAX_PATH];
 _splitpath(filename, param1, param2, param3, param4);

 // full path
 string fullpath(param1);
 fullpath += param2;

 // create file
 ifstream ifile(filename, ios::binary);
 if(!ifile) return error("Failed to open file.");

 // header #1
 unsigned int h01 = LE_read_uint32(ifile); // magic
 unsigned int h02 = LE_read_uint32(ifile); // approx. filesize
 unsigned int h03 = LE_read_uint32(ifile); // 0x20
 unsigned int h04 = LE_read_uint32(ifile); // 0x1000000D
 unsigned int h05 = LE_read_uint32(ifile); // 0x00
 unsigned int h06 = LE_read_uint32(ifile); // size of GSGM data
 unsigned int h07 = LE_read_uint32(ifile); // 0x00
 unsigned int h08 = LE_read_uint32(ifile); // 0x00
 if(h01 != 0x4C444D48) return error("Invalid HMD file.");

 // header #2
 cout << "GSGM magic = " << LE_read_uint32(ifile) << endl;
 cout << LE_read_uint32(ifile) << endl; // 258 (always)
 cout << LE_read_uint16(ifile) << endl; // 512 (always)
 cout << LE_read_uint16(ifile) << endl; // 2048 (always)
 cout << LE_read_uint16(ifile) << endl; // 0 (always)
 cout << LE_read_float(ifile) << endl; // 543 (changes)
 //cout << LE_read_half_float(ifile) << endl; // 11783 (changes)

 // read name
 char name[30];
 ifile.read(&name[0], 30);
 cout << "name = " << name << endl;

 // (offset, information) pairs
 unsigned int n_offset_pairs = 14;
 unsigned int offset[14];
 unsigned int fucker[14];
 for(unsigned int i = 0; i < 14; i++) {
     offset[i] = BE_read_uint32(ifile);
     fucker[i] = BE_read_uint32(ifile);
     cout << "offset pair = <" << offset[i] << "," << fucker[i] << ">" << endl;
    }
 cout << endl;

 // floats that come after offset section
 BE_read_float(ifile);
 BE_read_float(ifile);
 BE_read_float(ifile);
 BE_read_float(ifile);
 BE_read_float(ifile);
 BE_read_float(ifile);
 BE_read_float(ifile);
 BE_read_float(ifile);
 BE_read_float(ifile);
 BE_read_float(ifile);
 BE_read_float(ifile);
 BE_read_float(ifile);

 // more offset information pairs
 for(size_t i = 0; i < 4; i++) {
     unsigned int a = BE_read_uint32(ifile);
     unsigned int b = BE_read_uint32(ifile);
     cout << "<" << a << "," << b << ">" << endl;
    }
 cout << endl;

 // move to offset index 00
 cout << "-------------------" << endl;
 cout << "- OFFSET INDEX 00 -" << endl;
 cout << "-------------------" << endl;
 ifile.seekg(offset[0]);
 for(size_t i = 0; i < fucker[0]; i++) {
     unsigned int a[16];
     BE_read_array(ifile, &a[0], 16);
     float m[16];
     BE_read_array(ifile, &m[0], 16);
     for(size_t j = 0; j < 16; j++) cout << a[j] << "  ";
     cout << endl;
     for(size_t j = 0; j < 16; j++) cout << m[j] << "  ";
     cout << endl;
     cout << endl;
    }
 cout << endl;

 // move to offset index 01
 cout << "-------------------" << endl;
 cout << "- OFFSET INDEX 01 -" << endl;
 cout << "-------------------" << endl;
 ifile.seekg(offset[1]);
 for(size_t i = 0; i < fucker[1]; i++) {
     float m[16];
     BE_read_array(ifile, &m[0], 16);
     //for(size_t j = 0; j < 16; j++) cout << m[j] << "  ";
     //cout << endl;
    }
 cout << endl;

 // move to offset index 02
 cout << "-------------------" << endl;
 cout << "- OFFSET INDEX 02 -" << endl;
 cout << "-------------------" << endl;
 ifile.seekg(offset[2]);
 cout << endl;

 // move to offset index 03
 cout << "-------------------" << endl;
 cout << "- OFFSET INDEX 03 -" << endl;
 cout << "-------------------" << endl;
 ifile.seekg(offset[3]);
 for(size_t i = 0; i < fucker[3]; i++) {
     unsigned int m[32];
     BE_read_array(ifile, &m[0], 32);
     //for(size_t j = 0; j < 32; j++) cout << m[j] << "  ";
     //cout << endl;
    }
 cout << endl;

 // move to offset index 04
 cout << "-------------------" << endl;
 cout << "- OFFSET INDEX 04 -" << endl;
 cout << "-------------------" << endl;
 ifile.seekg(offset[4] + 32);
 for(size_t i = 0; i < fucker[4]; i++) {
     unsigned int m[4];
     BE_read_array(ifile, &m[0], 4);
     //for(size_t j = 0; j < 4; j++) cout << m[j] << "  ";
     //cout << endl;
    }
 cout << endl;

 // move to offset index 05
 cout << "-------------------" << endl;
 cout << "- OFFSET INDEX 05 -" << endl;
 cout << "-------------------" << endl;
 ifile.seekg(offset[5]);
 for(size_t i = 0; i < fucker[5]; i++) {
     float m[16];
     BE_read_array(ifile, &m[0], 16);
     //for(size_t j = 0; j < 16; j++) cout << m[j] << "  ";
     //cout << endl;
    }
 cout << endl;

 // move to offset index 06
 cout << "-------------------" << endl;
 cout << "- OFFSET INDEX 06 -" << endl;
 cout << "-------------------" << endl;
 ifile.seekg(offset[6]);
 unsigned int n_vtxinfo = fucker[6];

 // read vertex information header
 struct VERTEXINFOHEADER {
  float p1, p2, p3, p4;
  float p5, p6, p7, p8;
 };
 VERTEXINFOHEADER vih;
 vih.p1 = BE_read_float(ifile);
 vih.p2 = BE_read_float(ifile);
 vih.p3 = BE_read_float(ifile);
 vih.p4 = BE_read_float(ifile);
 vih.p5 = BE_read_float(ifile);
 vih.p6 = BE_read_float(ifile);
 vih.p7 = BE_read_float(ifile);
 vih.p8 = BE_read_float(ifile);

 // read vertex information
 struct VERTEXINFO {
  unsigned int   index;
  unsigned int   vertices;
  unsigned int   u01;
  unsigned short u02;
  unsigned short u03;
  unsigned int   offset;
  unsigned int   length;
  unsigned int   vertex_bytes;
  unsigned int   u04;
 };
 deque<VERTEXINFO> vinfolist;
 for(size_t i = 0; i < n_vtxinfo; i++)
    {
     VERTEXINFO vi = {
       BE_read_uint32(ifile),
       BE_read_uint32(ifile),
       BE_read_uint32(ifile),
       BE_read_uint16(ifile),
       BE_read_uint16(ifile),
       BE_read_uint32(ifile),
       BE_read_uint32(ifile),
       BE_read_uint32(ifile),
       BE_read_uint32(ifile),
     };
     vinfolist.push_back(vi);

     cout << "index = " << vi.index << endl;
     cout << "vertices = " << vi.vertices << endl;
     cout << "u01 = " << vi.u01 << endl;
     cout << "u02 = " << vi.u02 << endl;
     cout << "u03 = " << vi.u03 << endl;
     cout << "offset = " << vi.offset << endl;
     cout << "length = " << vi.length << endl;
     cout << "vertex_bytes = " << vi.vertex_bytes << endl;
     cout << "u04 = " << vi.u04 << endl;
     cout << endl;
    }
 cout << endl;

 // move to offset index 07
 cout << "-------------------" << endl;
 cout << "- OFFSET INDEX 07 -" << endl;
 cout << "-------------------" << endl;
 ifile.seekg(offset[7] + 0x20);

 // create lscript file
 ofstream ofile("sample.ls");
 ofile << "main" << endl;
 ofile << "{" << endl;
 ofile << " editbegin();" << endl;
 ofile << " uvmap = VMap(\"texture\", " << "\"texture\"" << ", 2);" << endl;

 // for each vertex buffer
 for(size_t i = 0; i < n_vtxinfo; i++)
    {
     for(size_t j = 0; j < vinfolist[i].vertices; j++)
        {
         VERTEX v = read_vertex(ifile, vinfolist[i].vertex_bytes);
         ofile << " pointlist[" << (j + 1) << "]" << " = " << "addpoint(" << v.x << "," << v.y << "," << v.z << ");" << endl;
         ofile << " uvmap.setValue(pointlist[" << (j + 1) << "]," << "@" << v.u << "," << (1.0f - v.v) << "@);" << endl;
        }
    }
 cout << endl;

 // move to offset index 08
 cout << "-------------------" << endl;
 cout << "- OFFSET INDEX 08 -" << endl;
 cout << "-------------------" << endl;
 ifile.seekg(offset[8]);
 size_t sum = 0;
 for(size_t i = 0; i < fucker[8]; i++) {
     unsigned short number = BE_read_uint16(ifile);
     char subname[30];     
     ifile.read(&subname[0], 30);
     cout << "data = (" << number << "," << subname << ")" << endl;
     sum += number;
    }
 cout << endl;

 // move to offset index 09
 cout << "-------------------" << endl;
 cout << "- OFFSET INDEX 09 -" << endl;
 cout << "-------------------" << endl;
 ifile.seekg(offset[9]);
 for(size_t i = 0; i < fucker[9]; i++) {
     unsigned short number = BE_read_uint16(ifile);
     char subname[30];     
     ifile.read(&subname[0], 30);
     cout << "data = (" << number << "," << subname << ")" << endl;
    }
 cout << endl;

 // move to offset index 10
 cout << "-------------------" << endl;
 cout << "- OFFSET INDEX 10 -" << endl;
 cout << "-------------------" << endl;
 ifile.seekg(offset[10]);

 // read name
 char main_name[32];
 ifile.read(&main_name[0], 32);
 cout << "name = " << main_name << endl;

 // read subnames
 for(size_t i = 0; i < fucker[10]; i++) {
     unsigned short number = BE_read_uint16(ifile);
     char subname[30];     
     ifile.read(&subname[0], 30);
     cout << "surface = (" << number << "," << subname << ")" << endl;
    }
 cout << endl;

 // move to offset index 11
 cout << "-------------------" << endl;
 cout << "- OFFSET INDEX 11 -" << endl;
 cout << "-------------------" << endl;
 ifile.seekg(offset[11] + 32);

 // name (optional)
 //unsigned short ib_number = BE_read_uint16(ifile);
 //char ib_name[30];
 //ifile.read(&ib_name[0], 28);
 //cout << "index buffer number = " << ib_number << endl;
 //cout << "index buffer name = " << ib_name << endl;

 // count indices
 unsigned int n_indices = fucker[11];
 cout << "n_indices = " << n_indices << endl;

 // read indices
 boost::shared_array<unsigned short> data(new unsigned short[n_indices]);
 BE_read_array(ifile, data.get(), n_indices);

 // start with at least one tristrip
 deque<deque<unsigned int>> tristriplist;
 tristriplist.push_back(deque<unsigned int>());

 // collect indicies in a deque
 for(size_t i = 0; i < n_indices; i++) {
     if(data[i] == 0xFFFF) tristriplist.push_back(deque<unsigned int>());
     else tristriplist.back().push_back(data[i]);
    }

 // process lists
 for(size_t i = 0; i < tristriplist.size(); i++)
    {
     unsigned int item = 0;
     unsigned int a = tristriplist[i][0]%vinfolist[0].vertices + 1;
     unsigned int b = tristriplist[i][1]%vinfolist[0].vertices + 1;
     unsigned int c = tristriplist[i][2]%vinfolist[0].vertices + 1;
     ofile << " addtriangle(pointlist[" << a << "], pointlist[" << b << "], pointlist[" << c << "]);" << endl;
     item += 1;

     for(size_t j = 3; j < tristriplist[i].size(); j++)
        {
         a = b;
         b = c;
         c = tristriplist[i][j]%vinfolist[0].vertices + 1;
         if(item % 2) ofile << " addtriangle(pointlist[" << a << "], pointlist[" << c << "], pointlist[" << b << "]);" << endl;
         else ofile << " addtriangle(pointlist[" << a << "], pointlist[" << b << "], pointlist[" << c << "]);" << endl;
         item += 1;
        }
    }

 // finish lscript file
 ofile << " editend();" << endl;
 ofile << "}" << endl;

/*
 // write triangles
 size_t index = 0;
 while(index < n_indices) {
     unsigned short a = data[index++] + 1;
     unsigned short b = data[index++] + 1;
     unsigned short c = data[index++] + 1;
     ofile << " addtriangle(pointlist[" << b << "], pointlist[" << c << "], pointlist[" << a << "]);" << endl;
    }
*/

/*
 // write first triangle
 size_t curr = 0;
 size_t item = 0;
 unsigned short a = data[curr + 0] + 1;
 unsigned short b = data[curr + 1] + 1;
 unsigned short c = data[curr + 2] + 1;
 ofile << " addtriangle(pointlist[" << a << "], pointlist[" << b << "], pointlist[" << c << "]);" << endl;
 curr += 3;
 item += 1;

 // write other triangles
 while(curr < n_indices)
      {
       unsigned d = data[curr];
       if(d != 0xFFFF)
         {
          a = b;
          b = c;
          c = d + 1;
          if(item % 2) ofile << " addtriangle(pointlist[" << b << "], pointlist[" << a << "], pointlist[" << c << "]);" << endl;
          else ofile << " addtriangle(pointlist[" << a << "], pointlist[" << b << "], pointlist[" << c << "]);" << endl;
          curr += 1;
          item += 1;
         }
       else
         {
          item = 0;
          a = data[curr + 1] + 1;
          b = data[curr + 2] + 1;
          c = data[curr + 3] + 1;
          ofile << " addtriangle(pointlist[" << a << "], pointlist[" << b << "], pointlist[" << c << "]);" << endl;
          curr += 4;
          item += 1;
         }
      }
 
 // finish lscript file
 ofile << " editend();" << endl;
 ofile << "}" << endl;
*/

 return true;
}