from urllib.request import ProxyHandler, build_opener, install_opener, urlretrieve
import lz4
from itertools import islice
from multiprocessing.dummy import Pool as ThreadPool
import os
import struct

pool = ThreadPool(100)

if not os.path.exists("musicGF"):
    os.makedirs("musicGF")

#proxy = urllib.request.ProxyHandler({'http': 'http://192.168.1.91:8888'})
proxy = ProxyHandler({})
opener = build_opener(proxy)
opener.addheaders = [('X-Unity-Version','5.4.5p1'),('User-Agent','Dalvik/1.6.0 (Linux; U; Android 4.4.4; GT-P5210 Build/KTU84P)')]
install_opener(opener)

def geturl(link):
	try:
		if not os.path.exists('musicGF\\' + os.path.dirname( link.rstrip('\n') ).split("Android/")[1]):
			os.makedirs('musicGF\\' + os.path.dirname( link.rstrip('\n') ).split("Android/")[1])
		print(link.rstrip('\n'))
		if link.rstrip('\n').endswith('.unity3d'):
			urlretrieve(link.rstrip('\n'), 'musicGF\\' + link.rstrip('\n').split("Android/")[1].replace('/','\\'))
		else:
			urlretrieve(link.rstrip('\n'), 'musicGF\\' + link.rstrip('\n').split("Android/")[1].replace('/','\\') + '.png')
	except:
		pass

with open('musicClean.txt', "rt" ) as f:
	while True:
		names = list(islice(f, 100))
		if len(names) == 0:
			break
		pool.starmap(geturl, zip(names) )

		

