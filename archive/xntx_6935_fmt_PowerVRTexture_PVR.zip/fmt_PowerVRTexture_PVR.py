# PowerVR Textures(*.PVR) Importer v1.0 by Bigchillghost
# Supports PVR version 1, 2 (alias Legacy) and 3

from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("PowerVR Textures", ".pvr")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
	#noesis.logPopup()
	return 1

def noepyCheckType(data):
	if len(data) < 0x34:
		return 0
	bs = NoeBitStream(data)
	Magic = bs.readBytes(4)
	if Magic == b'PVR\x03':
		return CheckTypePVRv3(bs)
	elif Magic == b'\x34\x00\x00\x00':
		return CheckTypePVRLegacy(bs, 2)
	elif Magic == b'\x2C\x00\x00\x00':
		return CheckTypePVRLegacy(bs, 1)
	else:
		return 0

def CheckTypePVRv3(bs):
	bs.seek(8, NOESEEK_ABS)
	PixelFormat = bs.readUInt64()
	if PixelFormat < 7 or (PixelFormat > 13 and PixelFormat < 256):
		return 0
	return 1

def CheckTypePVRLegacy(bs, ver):
	bs.seek(16, NOESEEK_ABS)
	PixelFormat = bs.readUByte()
	if PixelFormat in {0xC, 0xD, 0x18, 0x19, 0x36}:
		return 0
	if ver > 1:
		bs.seek(44, NOESEEK_ABS)
		identifier = bs.readUInt()
		if identifier != 0x21525650: # PVR!
			return 0

	return 1

def noepyLoadRGBA(data, texList):
	bs = NoeBitStream(data)
	Magic = bs.readBytes(4)
	if Magic == b'PVR\x03':
		return LoadPVRv3(data, texList)
	else:
		return LoadPVRLegacy(data, texList)

def LoadPVRv3(data, texList):
	bs = NoeBitStream(data)
	bs.seek(8, NOESEEK_ABS)
	PixelFormat = bs.readUInt64()
	bs.seek(8, NOESEEK_REL)
	Height = bs.readUInt()
	Width = bs.readUInt()
	bs.seek(0xC, NOESEEK_REL)
	MipMapCount = bs.readUInt()
	MetaDataSize = bs.readUInt()
	bs.seek(MetaDataSize, NOESEEK_REL)
	PixelDataSize = bs.getSize() - bs.tell()
	PixelData = bs.readBytes(PixelDataSize)
	if PixelFormat == 7: # DXT1/BC1
		texFmt = noesis.NOESISTEX_DXT1
	elif PixelFormat == 9: # DXT3/BC2
		texFmt = noesis.NOESISTEX_DXT3
	elif PixelFormat == 11: # DXT5/BC3
		texFmt = noesis.NOESISTEX_DXT5
	elif PixelFormat == 12: # ATI1/BC4
		PixelData = rapi.imageDecodeDXT(PixelData, Width, Height, noesis.FOURCC_ATI1)
		texFmt = noesis.NOESISTEX_RGBA32
		MipMapCount = 0
	elif PixelFormat == 13: # ATI2/BC5
		PixelData = rapi.imageDecodeDXT(PixelData, Width, Height, noesis.FOURCC_ATI2)
		texFmt = noesis.NOESISTEX_RGBA32
		MipMapCount = 0
	elif PixelFormat > 0x32: # uncompressed
		bs.seek(8, NOESEEK_ABS)
		ch = bs.readBytes(4)
		bR = bs.readBytes(4)
		fmtStr = ""
		start = 0
		stop = 4
		step = 1
		for i in range(0, 4):
			if bR[i] % 8 != 0:	# parse as little-endian integers
				start = 3
				stop = -1
				step = -1
				break
		
		for i in range(start, stop, step):
			if ch[i] != 0:
				if ch[i] in { 0x69, 0x6C, 0x78 }: # alias in { 'l', 'i', 'x' }
					fmtStr += "p%d"%bR[i]
				else:
					fmtStr += "%c%d"%(ch[i],bR[i])
		PixelData = rapi.imageDecodeRaw(PixelData, Width, Height, fmtStr)
		texFmt = noesis.NOESISTEX_RGBA32
		MipMapCount = 0
	else:	# unsupported
		return 0
	Texture = NoeTexture(rapi.getInputName(), Width, Height, PixelData, texFmt)
	Texture.setMipCount(MipMapCount)
	texList.append(Texture)
	return 1

def LoadPVRLegacy(data, texList):
	bs = NoeBitStream(data)
	HeaderSize = bs.readUInt()
	Height = bs.readUInt()
	Width = bs.readUInt()
	MipMapCount = bs.readUInt()
	PixelFormat = bs.readUByte()
	PixelDataSize = bs.getSize() - HeaderSize
	bs.seek(HeaderSize, NOESEEK_ABS)
	PixelData = bs.readBytes(PixelDataSize)
	if PixelFormat == 0x20: # DXT1/BC1
		texFmt = noesis.NOESISTEX_DXT1
	elif PixelFormat == 0x22: # DXT3/BC2
		texFmt = noesis.NOESISTEX_DXT3
	elif PixelFormat == 0x24: # DXT5/BC3
		texFmt = noesis.NOESISTEX_DXT5
	else:
		pixelFmtDict = {
		0x00:"b4g4r4a4", 			# ARGB4444
		0x01:"b5g5r5a1", 			# ARGB1555
		0x02:"b5g6r5",   			# RGB565
		0x03:"b5g5r5p1", 			# XRGB1555
		0x04:"r8g8b8",   			# RGB888
		0x05:"b8g8r8a8", 			# ARGB8888
		0x06:"b2g3r3a8", 			# ARGB8332
		0x10:"b4g4r4a4", 			# RGBA4444
		0x11:"b5g5r5a1", 			# RGBA5551
		0x12:"r8g8b8a8", 			# RGBA8888
		0x13:"b5g6r5",   			# RGB565
		0x14:"p1b5g5r5", 			# RGBX5551
		0x15:"r8g8b8",   			# RGB888
		0x1A:"b8g8r8a8", 			# ARGB8888
		0x25:"b2g3r3",   			# RGB332
		0x2A:"r10g10b10a2", 		# ABGR2101010
		0x2B:"b10g10r10a2", 		# ARGB2101010
		0x2D:"r16g16", 				# GR1616
		0x2F:"r16g16b16a16", 		# ABGR16161616
		0x40:"a8", 					# A8
		}
		if PixelFormat in pixelFmtDict:	# uncompressed
			fmtStr = pixelFmtDict[PixelFormat]
			PixelData = rapi.imageDecodeRaw(PixelData, Width, Height, fmtStr)
			texFmt = noesis.NOESISTEX_RGBA32
			MipMapCount = 0
		else:	# unsupported
			return 0
	Texture = NoeTexture(rapi.getInputName(), Width, Height, PixelData, texFmt)
	Texture.setMipCount(MipMapCount)
	texList.append(Texture)
	return 1
