from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Final Fire", ".dds")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
	#noesis.logPopup()
	return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    bs.seek(0x5c, NOESEEK_ABS)
    Magic = bs.readBytes(3).decode("ASCII")
    if Magic != 'DXT':
        return 0
    return 1
	
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    key = bs.readInt()
    bs.seek(0x14, NOESEEK_ABS)
    height = bs.readInt()           
    imgHeight = height ^ key
    width = bs.readInt()            
    imgWidth = width ^ key
    bs.seek(0x5c, NOESEEK_ABS)
    imgFmt = bs.readBytes(4).decode("ASCII")
    bs.seek(0x88, NOESEEK_ABS)
    datasize = len(data) - 0x88
    data = bs.readBytes(datasize)      
    #DXT1
    if imgFmt == "DXT1":
        texFmt = noesis.NOESISTEX_DXT1
    #DXT5
    elif imgFmt == "DXT5":
        texFmt = noesis.NOESISTEX_DXT5
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1