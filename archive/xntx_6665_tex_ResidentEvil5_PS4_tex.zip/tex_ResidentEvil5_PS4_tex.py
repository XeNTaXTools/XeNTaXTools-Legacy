from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Resident Evil 5 [PS4]", ".tex")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
	#noesis.logPopup()
	return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    if bs.readBytes(4) != b'\x54\x45\x58\x00': return 0
    return 1
	
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.seek(4)
    bs.readByte()
    bs.readByte()
    bs.readByte()
    bs.readByte()
    mipCount = bs.readUByte()
    #print(hex(mipCount), ":mips")
    width = bs.readBits(12)
    height = bs.readBits(12)
    #print(width, "x", height)
    imgWidth = width * 4
    imgHeight = height * 2
    textureCount = bs.readUByte()
    imgFmt = bs.readUByte()
    #print(hex(imgFmt), ":format")
    bs.readByte()
    bs.readByte()
    tmpOffset = bs.readUInt()
    bs.seek(tmpOffset)
    datasize = bs.getSize() - tmpOffset
    #print(hex(datasize), ":datasize")
    data = bs.readBytes(datasize)    
                
    if imgFmt == 0x30: #BC7 RE5
        imgFmt = b'\x90\x92'

    imgWidth = (imgWidth - 1) + 0xC000    
    #print(hex(imgWidth), ":width")
    imgHeight = ((imgHeight - 1) >> 2) + 0x7000
    #print(hex(imgHeight), ":height")
    gnfSize = datasize + 0x30
    
    #build PS4 gnf header and append tex data
    gnfHeader = b'\x47\x4E\x46\x20\x28\x00\x00\x00\x02\x01\x00\x00'
    gnfHeader += bytearray(noePack("I", gnfSize))      #4bytes
    gnfHeader += b'\x00\x00\x00\x00\x01\x00'
    gnfHeader += imgFmt                                #2bytes
    gnfHeader += bytearray(noePack("H", imgWidth))     #2bytes
    gnfHeader += bytearray(noePack("H", imgHeight))    #2bytes
    gnfHeader += b'\xAC\x0F\xD0\xA4\x01\xE0\x7F\x00\x00\x00\x00\x00\x00\00\x00\x00'
    gnfHeader += bytearray(noePack("I", datasize))     #4bytes
    gnfHeader += data                                  #nbytes
    
    texList.append(rapi.loadTexByHandler(gnfHeader, ".gnf"))
    return 1