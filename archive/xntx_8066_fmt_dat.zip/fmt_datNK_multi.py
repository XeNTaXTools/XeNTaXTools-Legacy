#by Durik256 for xentax.com 08.03.2022
from inc_noesis import *
import os

def registerNoesisTypes():
    handle = noesis.register("NKart Racers 2",".dat")
    noesis.setHandlerTypeCheck(handle, CheckType)
    noesis.setHandlerLoadModel(handle, LoadModel)    
    return 1
    
def CheckType(data):
    bs = NoeBitStream(data)
    if bs.readBytes(4) != b'\x00\x00\x80\xBF': return 0
    return 1

def LoadModel(data, mdlList):
    bs = NoeBitStream(data)
    bs.seek(12)
    numBone = bs.readUInt()
    
    #bones
    bones = []
    for x in range(numBone):
        name = noeAsciiFromBytes(bs.readBytes(32))
        unk = bs.readInt()
        bones.append(NoeBone(x,name, NoeMat43()))
    
    for x in bones:
        x.parentIndex = bs.readInt()
        
    for x in bones:
        bs.seek(32, NOESEEK_REL)
        
    #bs.seek(49, NOESEEK_REL)#unk
    offset =[49,26,24]
    for m in range(3):
        bs.seek(offset[m], NOESEEK_REL)#unk
        #materials
        numMat = bs.readInt()
        matName = [searchString(bs) for x in range(numMat)]
        num, unk0, unk1 = [bs.readInt() for x in range(3)]
        for x in range(num):
            bs.seek(40, NOESEEK_REL)
        
        
        #vertices
        stride, vsize = bs.readInt(), bs.readInt()
        vbuffer = bs.readBytes(vsize)
        #indices
        numIndices = bs.readInt()
        faces = bs.readBytes(numIndices*2)
        
        #create_model
        ctx = rapi.rpgCreateContext()
        rapi.rpgSetName("mesh_0")
        rapi.rpgBindPositionBuffer(vbuffer, noesis.RPGEODATA_FLOAT,stride)
        rapi.rpgBindUV1BufferOfs(vbuffer, noesis.RPGEODATA_HALFFLOAT,stride,20)
        rapi.rpgCommitTriangles(faces, noesis.RPGEODATA_USHORT, numIndices, noesis.RPGEO_TRIANGLE)
        
        mdl = rapi.rpgConstructModel()
        #mdl.setBones(bones)
        mdlList.append(mdl)
    rapi.setPreviewOption("setAngOfs", "0 90 0")
    return 1
    
def searchString(bs):
    bytes = []
    byte = None
    while byte != 0:
        byte = bs.readUByte()
        bytes.append(byte)
    return noeAsciiFromBytes(bytes)
