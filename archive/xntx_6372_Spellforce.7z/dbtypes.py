"""

exe message of note:
CGdResource::LoadObjects: outlinecount %u for object %u illegal


# size 3570 = 255 lots of 7 int16s
#type 3 unknown3
# zeroing this out makes patrolling NPCs run like mad thigns on their
# paths, also hero runs at huge speeds

# make a tool that replaces chunks in a map file

# size always 1048576, highly sparse
# nonzero count in Greyfell is 4285 max elem 53
# Liannon: 3701 max 52
# Eloni: 10010 max 53
# Southern Windwalls: 14767 max 52
# texture indices?
#type 31 unknown31 - texture overlays?

# very sparse
#type 32 unknown32



# major part is of length 128 * 128 * 3
# header conissts of x y stringId tuples, but format
# not figured out yet; stringIds are race names...
#type 53 unknown53

"""

DBTYPES = {
    2: (
        'TextureMap',
        None,
        None
    ),
    3: (
        'unknown3',
        'a b c d e f g h i',
        '<bbhhHbbhH'
    ),
    4: (
        'TextureSet',
        None,
        None
    ),
    6: (
        'HeightMap',
        None,
        None
    ),
    11: (
        'building',
        'x y angle u buildingId1 buildingId2',
        '<4H2B'
    ),
    12: (
        'npc',
        # c is always 0 in TOoD
        'x y c npcId scriptId f g',
        '<6HB'
    ),
    29: (
        'adornment',
        # u1 not in Rift, u2 not in Liannon nor Rift
        'x y adornId angle scriptId u0 u1 u2',
        '<8H'
    ),
    30: (
        'monument',
        'x y adornId angle g',
        '<4HB'
    ),
    35: (
        'portal',
        'x y angle portalId',
        '<4H'
    ),
    40: (
        'water',
        # type 0 is normal water, 2 probably lava
        # According to the editor, there are four lake types: water,
        # swamp, lava, ice.  This should be easy to check.
        'x y depth type',
        '<3HB',
        'int8count'
    ),
    42: (
        # There is a visibility flag and a block flag that can be placed
        # in the editor. 42 and 56 undoubtedly.  Which is which?
        'visFlag',
        'x y',
        '<2H'
    ),
    # 44 Weather todo
    # 46 unknown46 todo
    55: (
        'bindpoints',
        'x y nameId',
        '<2HL',
        'int32count'
    ),
    56: (
        'blockFlag',
        'x y',
        '<2H'
    ),
    # 59 CoopSpawnSettings todo
    # 60 unknown60 todo
    2001: (
        'BuildingsArmyRequirements',
        'unitId numberOfRequirements buildingId',
        '<HBH'
    ),
    2002: (
        'SpellParametersObject',
        '''spellNumber spellNameId requirementClass1 requirementSubclass1 '''
        '''requirementLevel1 requirementClass2 requirementSubclass2 '''
        '''requirementLevel2 requirementClass3 requirementSubclass3 '''
        '''requirementLevel3 unk1 unk2 unk3 manaUsage castTime cooldown '''
        '''minRange maxRange castType parameters[11]''',
        '<2H12BH2L3H11L'
    ),
    2003: (
        'ItemPriceParametersObject',
        '''itemId typeId nameId unitStatsId armyStatsId buildingId unknown '''
        '''copperSellingPrice copperBuyingPrice itemSetId''',
        '<6HB2LB'
    ),
    2004: (
        'ArmorParametersObject',
        '''itemId strength stamina agility dexterity health charisma '''
        '''intelligence wisdom mana armor fireResistance iceResistance '''
        '''blackResistance mindResistance runSpeed fightSpeed castSpeed''',
        '<H17h'
    ),
    2005: (
        'CreatureParameterObject',
        '''statsId level raceId agility charisma dexterity intelligence '''
        '''stamina strength wisdom unknown1 fireResistance iceResistance '''
        '''blackResistance mindResistance walkSpeed fightSpeed castSpeed '''
        '''size unknown2 spawnTime genderAndVulnerability headId '''
        '''equipmentSlotId''',
        '<2HB17HLBHB'
    ),
    2006: (
        'CreatureSkillObject',
        'creatureStatsId skillSchoolClass skillSchoolSubClass skillLevel',
        '<H3B'
    ),
    2012: (
        'itemUiElements',
        'itemId a name a',
        '<HB64sH'
    ),
    2013: (
        'itemScrolls',
        'itemId1 itemId2',
        '<2H'
    ),
    2014: (
        'ItemSpellEffectsObject',
        'itemId itemEffectNumber effectNumber',
        '<HBH'
    ),
    2015: (
        'WeaponParametersObject',
        'itemId minDamage maxDamage minRange maxRange speed type material',
        '<8H'
    ),
    # 2016 is the string table
    2017: (
        'ItemRequirementsObject',
        '''itemId requirementNumber schoolRequirementClass '''
        '''subSchoolRequirementClass level''',
        '<H4B'
    ),
    2018: (
        'ItemEffectsObject',
        'itemId effectNumber',
        '<2H'
    ),
    2022: (
        'races',
        'index a b c d e f nameId u1 u2 u3 u4 u5',
        '<7BH4LH'
    ),
    2023: (
        'unknown23',
        'a b c',  # 1..32, 1..32, 0 | 100 | -100
        '3b'
    ),
    2024: (
        'CreatureCommonParameterObject',
        '''creatureId nameId statsId experience unknown1 hpFactor unknown2 '''
        '''unknown3 armor unitNameId unknown4''',
        '<3HLH2LBH40sB'
    ),
    2025: (
        'CreatureEquipmentObject',
        'creatureId equipmentSlot itemId',
        '<HBH'
    ),
    2026: (
        'CreatureSpellObject',
        'creatureId skillNumber spellNumber',
        '<HBH'
    ),
    2028: (
        'CreatureResourcesObject',
        'creatureId resourceId resourceAmount',
        '<H2B'
    ),
    2029: (
        # anchor point is a guess based on editor docs 6.1
        'BuildingsObject',
        '''buildingId raceId enterSlot slotsAmount hpAmount nameId '''
        '''anchorX anchorY unknown3 workerJobTime unknown4 '''
        '''rotation unknown5 unknown6''',
        '<H3B2H2hB4HB'
    ),
    # 2030 todo
    2031: (
        'BuildingsRequirementsObject',
        'buildingId resourceId resourceAmount',
        '<HBH'
    ),
    2032: (
        'unknown32',
        'a b',  # 1..120, 778 | 1802
        '<2H'
    ),
    2036: (
        'buttons',
        '''index c nameId anIndex wood stone iron lenya aria moonsilver '''
        '''food name last1 last2''',
        '<11H64s2H'
    ),
    2039: (
        'skillTrees',
        'skillType skillSubtype nameId',
        '<2BH'
    ),
    2040: (
        'CreatureCorpseLootObject',
        '''creatureId slotNumber itemId1 chanceToGetItem1 itemId2 '''
        '''chanceToGetItem2 itemId3''',
        '<HBHBHBH'
    ),
    2041: (
        'MerchantInventoryObject',
        'inventoryId merchantId',
        '<2H'
    ),
    2042: (
        'MerchantInventoryItemsObject',
        'inventoryId itemId itemType',
        '<3H'
    ),
    2043: (
        'resourceName',
        'resourceType nameId',
        '<BH'
    ),
    2047: (
        'unknown47',
        'inventoryId b c',
        '<HBH'
    ),
    2048: (
        'PlayerLevelStatsObject',
        '''level hpFactor mpFactor experience maxAttributesPoints '''
        '''maxSkillLevel weaponFactor armorFactor''',
        '<B2HL2B2H'
    ),
    2049: (
        'unknown49',
        'a',
        '<h'
    ),
    2050: (
        'adorns',
        'adornId nameId groupId h name b c d',
        '<3HB41s3H'
    ),
    2051: (
        'npcNames',
        'a b nameId',
        '<3H'
    ),
    2052: (
        'campaigns',
        'index c d name coda',
        '<2HB64sH'
    ),
    2053: (
        'portals',
        'portalId u0 destX destY u4 nameId',
        '<HL2hBH'
    ),
    2054: (
        'spellUIMap',
        'index nameId a b c d e name last',
        '<2H5B64sH'
    ),
    2055: (
        'unknown55',
        'a b',
        '<HB'
    ),
    # 2056 todo
    # 2057 todo
    2058: (
        'unknown58',
        'a b',
        '<2H'
    ),
    2059: (
        'tooltips',
        'index nameId stringId',
        '<3H'
    ),
    2061: (
        'quests',
        'questId prevQuestId mainStory nameId descrId k m',
        '<2LB4H'
    ),
    2062: (
        'SkillParameterObject',
        '''skillTypeId level strengthRequired staminaRequired '''
        '''agilityRequired dexterityRequired charismaRequired '''
        '''intelligenceRequired wisdomRequired''',
        '9B'
    ),
    2063: (
        'weaponTypes',
        'typeId nameId c',
        '<2HB'
    ),
    2064: (
        'weaponMaterials',
        'materialId nameId',
        '<2H'
    ),
    2065: (
        'ChestCorpseLootObject',
        '''chestCorpseId slotNumber itemId1 chanceToGetItem1 itemId2 '''
        '''chanceToGetItem2 itemId3 ''',
        '<HBHBHBH'
    ),
    2067: (
        'HeroSpellObject',
        'statsId skillNumber spellNumber',
        '<HBH'
    ),
    2072: (
        'setBonuses',
        'index nameId u',
        '<BHB'
    )
    # 8000 todo
}


def field_name(dbtype, index):
    names = DBTYPES[dbtype][1]
    names = names.split(' ')
    return names[index]


def field_names(dbtype):
    names = DBTYPES[dbtype][1]
    return names.split(' ')


def type_size(dbtype):
    import struct
    return struct.calcsize(DBTYPES[dbtype][2])


def read_row(dbtype, data, row):
    import struct
    size = type_size(dbtype)
    offset = row * size
    if len(DBTYPES[dbtype]) == 4:  # special marker
        if DBTYPES[dbtype][3] == 'int8count':
            offset += 1
        elif DBTYPES[dbtype][3] == 'int32count':
            offset += 4
    chunk = data[offset:offset+size]
    fmt = DBTYPES[dbtype][2]
    vals = struct.unpack(fmt, chunk)
    return vals


"""

# 2030: variable length, special handling needed
# it has the format: int16 buildingId, int8, int8,
# int8 count of following pairs of int16 perhaps coord
# pairs, perhaps defining polygon

# 2057 looks the same type as 2030

# order:
# 2002 2054 2056 2005 2006 2067 2003 2004
# 2013 2015 2017 2014 2012 2018 2016 2022
# 2023 2024 2025 2026 2028 2040 2001 2029
# 2030 2031 2039 2062 2041 2042 2047 2044
# 2048 2050 2057 2065 2051 2052 2053 2055
# 2058 2059 2061 2063 2064 2032 2049 2036
# 2072

# order:
# 2001 2002 2003 2004 2005 2006 2012 2013
# 2014 2015 2016 2017 2018 2022 2023 2024
# 2025 2026 2028 2029 2030 2031 2032 2036
# 2039 2040 2041 2042 2044 2047 2048 2049
# 2050 2051 2052 2053 2054 2055 2056 2057
# 2058 2059 2061 2062 2063 2064 2065 2067
# 2072


"""

