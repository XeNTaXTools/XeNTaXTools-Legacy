GAME_PATH = "D:/Program Files (x86)/Steam/SteamApps/common/Spellforce Platinum Edition/"
EXPORT_PATH = "D:/Programming/Spellforce/"
