"""

Preview widgets for resource types found in the PakFiles.

More complex preview widgets get their own modules - at present, sound
and model.

"""

from PyQt5.QtCore import Qt, QSize
from PyQt5.QtGui import QFont, QFontMetrics
from PyQt5.QtWidgets import QFileDialog, QLabel, QPlainTextEdit
from PyQt5.QtWidgets import QGroupBox, QScrollBar, QStackedWidget, QVBoxLayout

import common
import luadec
from meshpreview import MeshPreview
from soundpreview import SoundPreview


class ImagePreview(QGroupBox):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setTitle('Image Preview')
        self.label = QLabel(self)
        self.max_size = QSize(512, 512)
        self.label.setFixedSize(self.max_size)
        vbox = QVBoxLayout()
        vbox.addWidget(self.label)
        self.setLayout(vbox)

    def set_pixmap(self, pixmap, name):
        too_wide = pixmap.width() > self.max_size.width()
        too_high = pixmap.height() > self.max_size.height()
        if too_wide or too_high:
            self.label.setPixmap(pixmap.scaled(self.max_size))
        else:
            self.label.setPixmap(pixmap)
        w, h = pixmap.width(), pixmap.height()
        self.setTitle('Image Preview: {} ({}x{})'.format(name, w, h))


class TextPreview(QPlainTextEdit):
    def __init__(self, parent=None):
        super().__init__(parent)
        f = QFont()
        f.setFamily('Courier')
        f.setStyleHint(QFont.Monospace)
        f.setFixedPitch(True)
        f.setPointSize(10)
        self.setFont(f)
        tabstop = 4
        metrics = QFontMetrics(f)
        self.setTabStopWidth(tabstop * metrics.width(' '))
        self.setReadOnly(True)

    def set_text(self, text):
        self.clear()
        self.appendPlainText(text)

    def scroll_to_top(self):
        self.verticalScrollBar().triggerAction(QScrollBar.SliderToMinimum)


class HexPreview(TextPreview):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedWidth(640)

    def set_data(self, data):
        self.clear()
        text = ''
        hexout = ''
        asciiout = ''
        spacer = ''
        fmt = '{:08X}  {}{} {}\n'
        for i, ch in enumerate(data):
            hexout += '{:02X} '.format(ch)
            if ch < 32 or ch > 126:
                asciiout += '.'
            else:
                asciiout += chr(ch)
            if i % 16 == 15:
                text += fmt.format(i - 15, hexout, spacer, asciiout)
                hexout = ''
                asciiout = ''
        if asciiout:
            spacer = ' ' * 3 * (16 - len(asciiout))
            text += fmt.format(i - len(asciiout) + 1, hexout, spacer, asciiout)
        self.appendPlainText(text)


class LuaPreview(TextPreview):
    def __init__(self, parent=None):
        super().__init__(parent)

    def set_data(self, data):
        self.clear()
        text = luadec.disassemble(data)
        self.appendPlainText(text)

    def mousePressEvent(self, event):
        if event.button() == Qt.RightButton:
            name, mask = QFileDialog.getSaveFileName(self, 'Save as...',
                                                     common.EXPORT_PATH,
                                                     '*.txt')
            if name:
                with open(name, 'w') as outf:
                    outf.write(self.toPlainText())
        else:
            event.ignore()


class StackedWidget(QStackedWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.text_preview = TextPreview(self)
        self.hex_preview = HexPreview(self)
        self.image_preview = ImagePreview(self)
        self.mesh_preview = MeshPreview(self)
        self.sound_preview = SoundPreview(self)
        self.lua_preview = LuaPreview(self)
        self.addWidget(self.text_preview)
        self.addWidget(self.hex_preview)
        self.addWidget(self.image_preview)
        self.addWidget(self.mesh_preview)
        self.addWidget(self.sound_preview)
        self.addWidget(self.lua_preview)

    def preview_text(self, data):
        self.text_preview.set_text(data.decode('latin-1'))
        self.setCurrentWidget(self.text_preview)
        self.text_preview.scroll_to_top()

    def preview_data(self, data):
        self.hex_preview.set_data(data)
        self.setCurrentWidget(self.hex_preview)
        self.hex_preview.scroll_to_top()

    def preview_pixmap(self, pixmap, name):
        self.image_preview.set_pixmap(pixmap, name)
        self.setCurrentWidget(self.image_preview)

    def preview_mesh(self, name, data, pakfiles):
        self.mesh_preview.load_model(name, data, pakfiles)
        self.setCurrentWidget(self.mesh_preview)

    def preview_sound(self, data):
        self.sound_preview.set_source(data)
        self.setCurrentWidget(self.sound_preview)

    def preview_lua(self, data):
        self.lua_preview.set_data(data)
        self.setCurrentWidget(self.lua_preview)
        self.lua_preview.scroll_to_top()
