"""

Simplistic model viewer.

Several simple improvements are possible.

Camera seems to have some trivial math bugs.

Things to add to main MeshPreview widget in top or left bar:
    number of meshes in the model
    number of verts and indices in each mesh

    dialog for posing multiple models:
    gets 'add to scene' input from a context menu from the treeview

side bar with treeview of bones
side bar with mesh details including materials - bring over the collapsible


from sql_building_DC.lua:

  [91]={mesh={"building_darkelf_foodstore","~_crane","~_decal","~_frame},
        selectionscaling=12}
  [144]={mesh="building_darkelf_foodstore"}

sf5/animation/building_darkelf_foodstore_crane.bob
sf8/mesh/building_darkelf_foodstore.msb, _crane, _decal, _frame
    foodstore: mesh0 1291 verts mesh1 1516 verts
                maxIndex: mesh0 1804 mesh1 1708
    crane: mesh0 171 verts mesh1 312 verts
            maxIndex: 244, 322
    decal: mesh1 4 verts
            maxIndex: 3
    frame: mesh0 2697 verts mesh1 73 verts
            maxIndex: 1288, 72
sf4/animation/building_darkelf_foodstore.bor
    NOB = 28
    NOSV = 251
    V goes up to 1804
sf4/animation/building_darkelf_foodstore_crane.bor
    NOB = 8
    NOSV = 251
    V goes up to 123

dark elf raceId == 6
from BuildingsObject data table:
buildingId = 91 raceId=6 'Food Store'

no cameras available for crane, decal, frame



We need a method of adding multiple models to a scene,
for instance the foodstore components above.  Think about
the best way to do this.

Perhaps a dialog to specify each model name and adjust coordinates,
this could be part of the wrapper widget around OpenGLWidget.  This
is more flexible than something like right-clicking on the treeview
and selecting 'add to scene', although that isn't a bad idea either.
It would necessitate making only left click activate preview from
the treeview, so context menu doesn't select.  That's a good idea
anyway.

"""

import logging

from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtGui import (QMatrix4x4, QVector2D, QVector3D,
                         QOpenGLBuffer, QOpenGLVertexArrayObject,
                         QImage, QOpenGLTexture, QSurfaceFormat,
                         QOpenGLVersionProfile,
                         QOpenGLShaderProgram, QOpenGLShader
)
from PyQt5.QtWidgets import QGroupBox, QOpenGLWidget, QHBoxLayout

from collapsible import CollapsibleListWidget
import des
import msb
import utils


logger = logging.getLogger(__name__)


class Camera:
    def __init__(self):
        self.eye = QVector3D(0.0, 0.0, 10.0)
        self.target = QVector3D(5.0, 5.0, 15.0)
        self.up = QVector3D(0.0, 0.0, 1.0)

    def set_eye(self, p):
        x, y, z = p
        self.eye = QVector3D(x, y, z)

    def orbit(self, diff):
        """Rotate the camera around the target on either axis."""
        factor = 2.0
        vertical_axis = QVector3D(0.0, 0.0, 1.0)
        horizontal_axis = QVector3D(1.0, 0.0, 0.0)
        if diff.x() > 0:
            self.eye -= self.target
            m = QMatrix4x4()
            m.rotate(-factor, vertical_axis)
            self.eye = m * self.eye
            self.eye += self.target
        elif diff.x() < 0:
            self.eye -= self.target
            m = QMatrix4x4()
            m.rotate(factor, vertical_axis)
            self.eye = m * self.eye
            self.eye += self.target
        if diff.y() < 0:
            self.eye -= self.target
            m = QMatrix4x4()
            m.rotate(-factor, horizontal_axis)
            self.eye = m * self.eye
            self.eye += self.target
        elif diff.y() > 0:
            self.eye -= self.target
            m = QMatrix4x4()
            m.rotate(factor, horizontal_axis)
            self.eye = m * self.eye
            self.eye += self.target

    def move(self, direction):
        """Move the camera forward, back, left, or right."""
        factor = 0.3
        if direction == 'forward':
            forward = (self.target - self.eye).normalized()
            self.eye += forward * factor
            self.target += forward * factor
        elif direction == 'back':
            backward = -(self.target - self.eye).normalized()
            self.eye += backward * factor
            self.target += backward * factor
        elif direction == 'right':
            # TODO: this slowly rotates, because the target is further away,
            # TODO: so we're making a smaller sideways translation to it
            # TODO: nevertheless, good enough for now
            forward = (self.target - self.eye).normalized()
            right = QVector3D.crossProduct(forward, self.up)
            self.eye += right * factor
            self.target += right * factor
        elif direction == 'left':
            forward = (self.target - self.eye).normalized()
            left = -QVector3D.crossProduct(forward, self.up)
            self.eye += left * factor
            self.target += left * factor

    def set_target(self, p):
        x, y, z = p
        self.target = QVector3D(x, y, z)


class MeshData:
    """
    Fill mesh data buffers and store state in a VAO.

    """
    def __init__(self, vertices, indices, bb, image, program, GL):
        self.vao = QOpenGLVertexArrayObject()
        self.vao.create()
        self.vao.bind()
        self.arrayBuf = QOpenGLBuffer(QOpenGLBuffer.VertexBuffer)
        self.indexBuf = QOpenGLBuffer(QOpenGLBuffer.IndexBuffer)
        self.arrayBuf.create()
        self.indexBuf.create()
        self.arrayBuf.bind()
        self.arrayBuf.allocate(vertices, len(vertices))
        self.indexBuf.bind()
        self.indexBuf.allocate(indices, len(indices))
        self.num_indices = len(indices) // 2
        vertexLocation = program.attributeLocation("a_position")
        program.enableAttributeArray(vertexLocation)
        program.setAttributeBuffer(vertexLocation, GL.GL_FLOAT,
                                   msb.Vertex.POS_OFFSET, 3,
                                   msb.Vertex.RAW_SIZE)
        texcoordLocation = program.attributeLocation("a_texcoord")
        program.enableAttributeArray(texcoordLocation)
        program.setAttributeBuffer(texcoordLocation, GL.GL_FLOAT,
                                   msb.Vertex.TEXCOORD_OFFSET, 2,
                                   msb.Vertex.RAW_SIZE)
        self.vao.release()
        if image is None:
            logger.warning('MeshData got no DiffuseMap')
            image = QImage(64, 64, QImage.Format_ARGB32)
            image.fill(Qt.white)
        else:
            image = image.toImage()  # it's a pixmap, fix the names
        self.diffuse_texture = QOpenGLTexture(image)
        self.bounding_box = bb


class ModelData:
    """
    Store a list of MeshData to draw.

    """
    def __init__(self, data, program, GL):
        self.meshes = []
        msbfile, textures = data
        for mesh, texture in zip(msbfile.meshes, textures):
            v = mesh.raw_verts
            i = mesh.raw_indices
            bb = mesh.bb
            t = texture
            self.meshes.append(MeshData(v, i, bb, t, program, GL))


class OpenGLWidget(QOpenGLWidget):
    init_complete = pyqtSignal()

    def __init__(self, parent):
        super().__init__(parent)

        self.GL = None

        self.camera = Camera()

        self.model = None

        self.render_mode = 'Textured'

        self.aspect = 1.5
        self.fov = 60

        self.program = QOpenGLShaderProgram(self)

        self.mousePressPosition = None
        self.oldMousePressPosition = None

        self.setFocusPolicy(Qt.StrongFocus)

        self.textures = []

    def load_model(self, model):
        if self.GL is None:
            logger.info('tried to set model with no GL context')
            return
        self.makeCurrent()
        if self.model is not None:
            self.unload_model()
        start_camera = model.pop()
        self.model = ModelData(model, self.program, self.GL)
        self.set_start_camera(start_camera)
        self.update()
        self.doneCurrent()

    def unload_model(self):
        for meshdata in self.model.meshes:
            meshdata.arrayBuf.destroy()
            meshdata.indexBuf.destroy()
            meshdata.vao.destroy()
            meshdata.diffuse_texture.destroy()
        self.model = None

    def init_shaders(self):
        if not self.program.addShaderFromSourceFile(QOpenGLShader.Vertex,
                                                    'resources/shaders/vshader.glsl'):
            logger.error('Failed to load vertex shader')
            self.close()
        if not self.program.addShaderFromSourceFile(QOpenGLShader.Fragment,
                                                    'resources/shaders/fshader.glsl'):
            logger.error('Failed to load fragment shader')
            self.close()
        if not self.program.link():
            logger.error('Failed to link program')
            self.close()
        if not self.program.bind():
            logger.error('Failed to bind program')
            self.close()

    def set_start_camera(self, start_camera):
        if not self.model:
            logger.error('no model')
            return
        if start_camera is None:
            logger.info('no camera found for model, guessing...')
            center = self.model.meshes[0].bounding_box.center()
            radius = self.model.meshes[0].bounding_box.radius()
            self.camera.target = center
            self.camera.eye = 2 * radius * QVector3D(0.707, 0.0, 0.707)
        else:
            self.camera.eye, self.camera.target = start_camera

    def initializeGL(self):
        profile = QOpenGLVersionProfile(QSurfaceFormat())
        self.GL = self.context().versionFunctions(profile)
        super().initializeGL()
        self.GL.glClearColor(0.2, 0.3, 0.3, 1.0)
        self.init_shaders()
        self.GL.glEnable(self.GL.GL_DEPTH_TEST)
        self.GL.glEnable(self.GL.GL_CULL_FACE)
        self.GL.initializeOpenGLFunctions()
        self.init_complete.emit()

    def paintGL(self):
        self.GL.glClearColor(0.2, 0.3, 0.3, 1.0)
        self.GL.glClear(self.GL.GL_COLOR_BUFFER_BIT | self.GL.GL_DEPTH_BUFFER_BIT)
        if self.model is None:
            logger.info('no active model to render')
            return
        mv = QMatrix4x4()
        mv.lookAt(self.camera.eye, self.camera.target, self.camera.up)
        mp = QMatrix4x4()
        mp.perspective(self.fov, self.aspect, 1, 50)
        mm = QMatrix4x4()
        mm.translate(0, 0, 0)
        m = mp * mv * mm
        self.program.setUniformValue("mvp_matrix", m)
        self.program.setUniformValue("texture", 0)
        for mesh_data in self.model.meshes:
            mesh_data.vao.bind()
            mesh_data.diffuse_texture.bind()
            self.GL.glDrawElements(self.GL.GL_TRIANGLES,
                                   mesh_data.num_indices,
                                   self.GL.GL_UNSIGNED_SHORT,
                                   None)
            mesh_data.vao.release()

    def resizeGL(self, w, h):
        self.aspect = w / h if h != 0 else 1

    def mousePressEvent(self, event):
        self.mousePressPosition = QVector2D(event.localPos())
        self.oldMousePressPosition = self.mousePressPosition

    def mouseMoveEvent(self, event):
        self.mousePressPosition = QVector2D(event.localPos())
        diff = self.mousePressPosition - self.oldMousePressPosition
        self.oldMousePressPosition = self.mousePressPosition
        self.camera.orbit(diff)
        self.update()

    def mouseReleaseEvent(self, event):
        self.mousePressPosition = None

    def keyPressEvent(self, event):
        keymap = {
            Qt.Key_W: 'forward',
            Qt.Key_S: 'back',
            Qt.Key_A: 'left',
            Qt.Key_D: 'right'
        }
        try:
            self.camera.move(keymap[event.key()])
            self.update()
        except KeyError:
            event.ignore()

    def wheelEvent(self, event):
        d = event.angleDelta()
        if d.y() < 0:
            self.fov *= 1.1
            #self.camera.eye.setY(self.camera.eye.y() * 1.1)
        elif d.y() > 0:
            self.fov /= 1.1
            #self.camera.eye.setY(self.camera.eye.y() / 1.1)
        self.update()


def find_model_pose(name, pakfiles):
    cameras = des.DESFile(pakfiles[6].read_by_name('data\\camera.des'))
    sought_name = '\"' + name[:name.index('.')] + '\"'
    for section in cameras.sections:
        if section.value('name') == sought_name:
            eye = section.value('from', valuetype='vector')
            target = section.value('to', valuetype='vector')
            return eye, target
    return None


class MeshPreview(QGroupBox):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setTitle('Mesh Preview')
        self.openGLWidget = OpenGLWidget(self)
        self.GL_ready = False
        self.pending_model = None
        self.openGLWidget.init_complete.connect(self.forward_model)
        # reminder: self.collapsible.add_widget(name, widget)
        # collapsible doesn't take ownership
        self.collapsible = CollapsibleListWidget(self)
        from PyQt5.QtWidgets import QPlainTextEdit
        self.stats_panel = QPlainTextEdit(self)
        self.collapsible.add_widget('Stats', self.stats_panel)

        hbox = QHBoxLayout()
        hbox.addWidget(self.collapsible)
        self.collapsible.setFixedWidth(200)
        hbox.addWidget(self.openGLWidget)
        self.setLayout(hbox)

    def forward_model(self):
        self.GL_ready = True
        if self.pending_model is not None:
            self.openGLWidget.load_model(self.pending_model)
            self.pending_model = None

    def load_model(self, name, data, pakfiles):
        self.setTitle('Mesh Preview: {}'.format(name))
        msbfile = msb.MeshBuffer(data)
        textures = []
        for mesh in msbfile.meshes:
            fullname = 'texture\\' + mesh.diffuse_material.name.lower() + '.dds'
            r = pakfiles[1].read_by_name(fullname)
            if r is not None:
                textures.append(utils.load_dds(r))
            else:
                logger.error('failed to find {}'.format(fullname))

        start_camera = find_model_pose(name, pakfiles)

        if not self.GL_ready:
            self.pending_model = [msbfile, textures, start_camera]
        else:
            self.openGLWidget.load_model([msbfile, textures, start_camera])

        # Set up some information for the side bar
        self.stats_panel.clear()
        t = 'Meshes: {}\n'.format(len(msbfile.meshes))
        for i, mesh in enumerate(msbfile.meshes):
            t += '  Mesh {} verts: {}\n'.format(i, len(mesh.verts))
            t += '          tris:  {}\n'.format(len(mesh.triangles))
            max_index = max(v.u1 for v in mesh.verts)
            t += '          maxIndex: {}\n'.format(max_index)
        self.stats_panel.appendPlainText(t)
