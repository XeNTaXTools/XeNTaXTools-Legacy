# FAILS on: ChestCorpseLootObject
# clicking on unhandled type 2057 was a KeyError on rowCount / tyepSize

from PyQt5.QtCore import Qt, QAbstractTableModel, QVariant, pyqtSignal
from PyQt5.QtWidgets import QHBoxLayout, QWidget
from PyQt5.QtWidgets import QListWidget,QListWidgetItem, QTableView

from cff import ContainerFile
import dbtypes
from stringprovider import StringProvider
import utils


class GameData:
    def __init__(self, filename):
        file = ContainerFile(filename)
        # TODO: ugly, but for the moment just take them:
        self.resources = file.resources
        # TODO: hack: this is due to piggybacking this class in mapviewer
        if 'GameData.cff' in filename:
            self.string_provider = StringProvider(self.resource(2016).data)

    def set_string_provider(self, string_provider):
        self.string_provider = string_provider

    def resource(self, key):
        # Bypass the index part of a resource, since it only applies
        # to the heightmaps.
        return self.resources[key][0]


class TableModel(QAbstractTableModel):
    def __init__(self, parent, game_data):
        super().__init__(parent)
        self.game_data = game_data
        self.dbtype = None
        self.renderers = (
            ("field_name == 'nameId'", self.render_string_id),
            ("field_name == 'stringId'", self.render_string_id),
            ("field_name == 'descrId'", self.render_string_id),
            ("self.dbtype == 2024 and field_name == 'name'", self.decode_string),
            ("self.dbtype == 2024 and field_name == 'unknown2'", self.hexify_int),
            ("self.dbtype == 2024 and field_name == 'unitNameId'", self.decode_string),
            ("self.dbtype == 2036 and field_name == 'name'", self.decode_string),
            ("self.dbtype == 2050 and field_name == 'name'", self.decode_string),
            ("self.dbtype == 2052 and field_name == 'name'", self.decode_string),
            ("self.dbtype == 2054 and field_name == 'name'", self.decode_string)
        )

    def rowCount(self, parent=None, *args, **kwargs):
        if self.dbtype is None:
            return 0
        r = self.game_data.resource(self.dbtype).data
        return len(r) // dbtypes.type_size(self.dbtype)

    def columnCount(self, parent=None, *args, **kwargs):
        if self.dbtype is None:
            return 0
        return len(dbtypes.field_names(self.dbtype))

    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid() or role != Qt.DisplayRole:
            return QVariant()
        if self.dbtype is None:
            return QVariant()
        # Upack data fields for the type:
        r = self.game_data.resource(self.dbtype).data
        values = dbtypes.read_row(self.dbtype, r, index.row())
        # Prepare specialized rendering of the data:
        field_name = dbtypes.field_name(self.dbtype, index.column())
        value = values[index.column()]
        for pred, func in self.renderers:
            if eval(pred):
                return func(value)
        # No specialized rendering, return the raw value:
        return value

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        if role != Qt.DisplayRole or orientation != Qt.Horizontal:
            return QVariant()
        if self.dbtype is None:
            return QVariant()
        return dbtypes.field_name(self.dbtype, section)

    def set_type(self, dbtype):
        self.dbtype = dbtype

    def force_update(self):
        self.beginResetModel()
        self.endResetModel()

    # Helper functions for rendering special data fields:
    def render_string_id(self, value):
        return self.game_data.string_provider.string(value)

    def decode_string(self, value):
        return utils.read_cstr(value)

    def hexify_int(self, value):
        return hex(value)

    def get_coord_list(self):
        names = dbtypes.field_names(self.dbtype)
        if 'x' in names and 'y' in names:
            coords = []
            xc = dbtypes.field_names(self.dbtype).index('x')
            yc = dbtypes.field_names(self.dbtype).index('y')
            for i in range(self.rowCount()):
                x = self.data(self.createIndex(i, xc))
                y = self.data(self.createIndex(i, yc))
                coords.append((x, y))
            return coords
        else:
            return []


class GameDataView(QWidget):
    coords_available = pyqtSignal(list)

    def __init__(self, parent, game_data):
        super().__init__(parent)
        self.game_data = game_data

        self.list_widget = QListWidget(self)
        self.table_view = QTableView(self)
        if self.game_data is not None:
            self.table_model = TableModel(self, self.game_data)
            self.populate_list()
            self.table_view.setModel(self.table_model)

        self.list_widget.itemClicked.connect(self.pick_type)

        self.list_widget.setFixedWidth(200)
        hbox = QHBoxLayout()
        hbox.addWidget(self.list_widget)
        hbox.addWidget(self.table_view)
        self.setLayout(hbox)

    def set_data(self, data):
        self.game_data = data
        self.table_model = TableModel(self, self.game_data)
        self.populate_list()
        self.table_view.setModel(self.table_model)

    def populate_list(self):
        self.list_widget.clear()
        for dbtype in self.game_data.resources:
            try:
                name = dbtypes.DBTYPES[dbtype][0]
            except KeyError:
                name = '(no schema)'
                item = QListWidgetItem('{}: {}'.format(dbtype, name))
                item.setFlags(Qt.ItemIsEnabled)
                self.list_widget.addItem(item)
                continue
            # Handle resources like TextureMap that make no sense to put
            # in a table preview:
            if dbtypes.DBTYPES[dbtype][1] is None:
                item = QListWidgetItem('{}: ({})'.format(dbtype, name))
                item.setFlags(Qt.ItemIsEnabled)
            else:
                item = QListWidgetItem('{}: {}'.format(dbtype, name))
                item.setData(Qt.UserRole, dbtype)
            self.list_widget.addItem(item)

    def pick_type(self, item):
        dbtype = item.data(Qt.UserRole)
        self.table_model.set_type(dbtype)
        self.table_model.force_update()
        self.coords_available.emit(self.table_model.get_coord_list())

        #self.table_view.setWordWrap(True)
        #self.table_view.setTextElideMode(Qt.ElideMiddle)
        #self.table_view.resizeRowsToContents()
