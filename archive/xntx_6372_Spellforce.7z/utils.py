import logging
import io

from PyQt5.QtCore import QBuffer, QByteArray, QIODevice
from PyQt5.QtGui import QImage, QPixmap

from PIL import Image, ImageQt


logger = logging.getLogger(__name__)


def read_cstr(source):
    if isinstance(source, bytes):
        ins = io.BytesIO(source)
    else:
        ins = source
    buf = bytearray()
    while True:
        rawch = ins.read(1)
        if not rawch:
            break
        ch = ord(rawch)
        if ch == 0:
            break
        buf.append(ch)
    return buf.decode('latin-1')


def raw_tga_to_pixmap(data):
    ba = QByteArray(data)
    buf = QBuffer(ba)
    if not buf.open(QIODevice.ReadOnly):
        logger.error('failed to open buffer')
        return QPixmap()
    else:
        image = QImage()
        if not image.load(buf, 'tga'):
            logger.error('raw_tga_to_pixmap failed to load image')
            return QPixmap()
        return QPixmap.fromImage(image)


def load_dds(data):
    ins = io.BytesIO(data)
    pilobj = Image.open(ins)
    return QPixmap.fromImage(ImageQt.ImageQt(pilobj))


