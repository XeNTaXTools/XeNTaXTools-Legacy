"""

As usual for a MainWindow, this file is mostly construction, connections,
and layout.

"""

import logging

from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QMainWindow
from PyQt5.QtWidgets import QAction, QMenu
from PyQt5.QtWidgets import QSplitter, QTabWidget
from PyQt5.QtWidgets import QTreeView, QMessageBox

import common
from gamedataview import GameData, GameDataView
from mapviewer import MapViewer
from pakfile import PakFileCollection
from paktreemodel import PakTreeModel
from pakpreviews import StackedWidget
import utils


logger = logging.getLogger(__name__)


class MainWindow(QMainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)

        # Members:
        self.pakfiles = PakFileCollection(common.GAME_PATH + 'pak/')
        self.game_data = GameData(common.GAME_PATH + 'data/GameData.cff')
        self.map_viewer = MapViewer(self, self.pakfiles, self.game_data)
        self.game_data_view = GameDataView(self, self.game_data)
        self.pak_tree_model = PakTreeModel(self, self.pakfiles)
        self.tree_view = QTreeView(self)
        self.tree_view.header().hide()
        self.tree_view.setModel(self.pak_tree_model)
        self.tree_view.setContextMenuPolicy(Qt.CustomContextMenu)
        export_action = QAction('Export', self)
        export_action.setStatusTip('Export resource to file')
        self.tree_context_menu = QMenu(self.tree_view)
        self.tree_context_menu.addAction(export_action)

        # Connections:
        self.tree_view.customContextMenuRequested.connect(self.do_tree_context_menu)
        export_action.triggered.connect(self.export_resource)
        self.tree_view.selectionModel().currentChanged.connect(self.examine_resource)

        # Layout:
        self.setGeometry(100, 100, 1600, 900)
        self.setWindowTitle('Spellforce Explorer')
        self.stacked_widget = StackedWidget(self)
        splitter = QSplitter()
        splitter.addWidget(self.tree_view)
        self.tree_view.setFixedWidth(400)
        splitter.addWidget(self.stacked_widget)
        tab_widget = QTabWidget(self)
        tab_widget.addTab(self.map_viewer, 'Map Viewer')
        tab_widget.addTab(splitter, 'Pak Viewer')
        tab_widget.addTab(self.game_data_view, 'Data Tables')
        self.setCentralWidget(tab_widget)

    def do_tree_context_menu(self, pos):
        self.tree_context_menu.exec(self.mapToGlobal(pos))

    def examine_resource(self, cur, prev):
        filename = self.pak_tree_model.get_filename(cur)
        if not filename:
            return
        filedata = self.pak_tree_model.get_filedata(cur)
        extension = filename.split('.')[1]
        if extension == 'bob':
            self.stacked_widget.preview_data(filedata)
        elif extension in ('bor', 'des', 'msh'):
            # TextTreeReader needed
            self.stacked_widget.preview_text(filedata)
        elif extension == 'bsi':
            self.stacked_widget.preview_data(filedata)
        elif extension == 'dds':
            pixmap = utils.load_dds(filedata)
            self.stacked_widget.preview_pixmap(pixmap, filename)
        elif extension == 'lua':
            self.stacked_widget.preview_lua(filedata)
        elif extension == 'msb':
            self.stacked_widget.preview_mesh(filename, filedata, self.pakfiles)
        elif extension in ('mp3', 'wav'):
            self.stacked_widget.preview_sound(filedata)
        elif extension == 'tga':
            pixmap = utils.raw_tga_to_pixmap(filedata)
            self.stacked_widget.preview_pixmap(pixmap, filename)
        elif extension == 'txt':
            self.stacked_widget.preview_text(filedata)

    def export_resource(self):
        model = self.tree_view.model()
        index = self.tree_view.selectionModel().currentIndex()
        if not model.is_file(index):
            return
        outfilename = common.EXPORT_PATH + model.get_filename(index)
        data = model.get_filedata(index)
        with open(outfilename, 'wb') as outf:
            outf.write(data)
        mb = QMessageBox()
        mb.setText('File exported')
        mb.exec()

