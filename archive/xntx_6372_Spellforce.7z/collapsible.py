"""

CollapsibleListWidget is a container that stores a vertical
stack of widgets, each of which can be collapsed or expanded.

The contained widgets are not owned.

    w = CollapsibleListWidget(parent)
    w.add_widget('title button text', widget)
    w.collapse_all()
    w.expand_all()

"""

import logging

from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtWidgets import QPushButton, QStyle
from PyQt5.QtWidgets import QTreeWidget, QTreeWidgetItem


logger = logging.getLogger(__name__)


class _CollapseButton(QPushButton):
    expand_requested_signal = pyqtSignal(str)

    def __init__(self, text, parent, item):
        super().__init__(text, parent)
        self.pressed.connect(self.button_pressed)
        self.tree_widget_item = item
        self.expanded_icon = self.style().standardIcon(
            QStyle.SP_TitleBarShadeButton)
        self.collapsed_icon = self.style().standardIcon(
            QStyle.SP_TitleBarUnshadeButton)
        self.setIcon(self.collapsed_icon)
        self.setStyleSheet("Text-align:left")
        # Prevent button from retaining highlight:
        self.setFocusPolicy(Qt.NoFocus)

    def button_pressed(self):
        item = self.tree_widget_item
        item.setExpanded(not item.isExpanded())
        if item.isExpanded():
            self.setIcon(self.expanded_icon)
            self.expand_requested_signal.emit(self.text())
        else:
            self.setIcon(self.collapsed_icon)


class CollapsibleListWidget(QTreeWidget):
    expanded_signal = pyqtSignal(str)

    def __init__(self, parent):
        super().__init__(parent)

        self.setRootIsDecorated(False)
        self.setHeaderHidden(True)
        self.setIndentation(0)

    def clear(self):
        logger.info('todo: clear')

    def add_widget(self, name, widget):
        item = QTreeWidgetItem()
        self.addTopLevelItem(item)
        button = _CollapseButton(name, self, item)
        button.expand_requested_signal.connect(self.do_expand_signal)
        self.setItemWidget(item, 0, button)

        container = QTreeWidgetItem()
        container.setDisabled(True)
        item.addChild(container)
        self.setItemWidget(container, 0, widget)

    def do_expand_signal(self, string):
        self.expanded_signal.emit(string)

    def collapse_all(self):
        for i in range(self.topLevelItemCount()):
            self.topLevelItem(i).setExpanded(False)
            item.setExpanded(False)

    def expand_all(self):
        for i in range(self.topLevelItemCount()):
            self.topLevelItem(i).setExpanded(True)
