"""

QAbstractItemModel to enable PakFile browsing via QTreeView.

"""

import enum

from PyQt5.QtCore import Qt, QAbstractItemModel, QModelIndex, QVariant
from PyQt5.QtWidgets import QFileIconProvider


class TreeNodeType(enum.Enum):
    NONE = 0
    ROOT = 1
    PAKFILENAME = 2
    DIRNAME = 3
    FILENAME = 4


class TreeNode:
    def __init__(self, type):
        self.type = type
        self.file_number = None
        self.value = None
        self.parent = None
        self.children = []

    def dir_offset(self):
        return self.value

    def file_index(self):
        return self.value

    def columnCount(self):
        if self.type == TreeNodeType.FILENAME:
            return 2
        return 1

    def row(self):
        # If this node has a parent, what is the row (i.e. index) of this node
        # in the parent's list of children?
        if self.parent is not None:
            return self.parent.children.index(self)
        return None


class PakTreeModel(QAbstractItemModel):
    def __init__(self, parent, pakfiles):
        super().__init__(parent)
        self.pakfiles = pakfiles
        # Prepare node decorations:
        self.file_icon_provider = QFileIconProvider()
        icon = self.file_icon_provider.icon
        self.icon_map = {
            TreeNodeType.PAKFILENAME: icon(QFileIconProvider.Folder),
            TreeNodeType.DIRNAME: icon(QFileIconProvider.Folder),
            TreeNodeType.FILENAME: icon(QFileIconProvider.File),
        }
        # Populate directories:
        self.root_node = TreeNode(TreeNodeType.ROOT)
        for num, file in self.pakfiles.files.items():
            child = TreeNode(TreeNodeType.PAKFILENAME)
            child.file_number = num
            child.parent = self.root_node
            for offset in file.sorted_dir_offsets():
                dirnode = TreeNode(TreeNodeType.DIRNAME)
                dirnode.file_number = num
                dirnode.value = offset
                dirnode.parent = child
                child.children.append(dirnode)
            self.root_node.children.append(child)

    def is_file(self, index):
        node = index.internalPointer()
        return node.type == TreeNodeType.FILENAME

    def get_filename(self, index):
        node = index.internalPointer()
        if node.type != TreeNodeType.FILENAME:
            return None
        pf = self.pakfiles[node.file_number]
        return pf.get_name_and_size(node.file_index())[0]

    def get_filedata(self, index):
        node = index.internalPointer()
        if node.type != TreeNodeType.FILENAME:
            return None
        pf = self.pakfiles[node.file_number]
        return pf.read_by_index(node.file_index())

    # Overrides:

    def index(self, row, column, parent):
        if not self.hasIndex(row, column, parent):
            return QModelIndex()
        if parent.isValid():
            parent_node = parent.internalPointer()
        else:
            parent_node = self.root_node
        child_node = parent_node.children[row]
        return self.createIndex(row, column, child_node)

    def parent(self, child):
        if not child.isValid():
            return QModelIndex()
        child_node = child.internalPointer()
        parent_node = child_node.parent
        if parent_node == self.root_node:
            return QModelIndex()
        return self.createIndex(parent_node.row(), 0, parent_node)

    def rowCount(self, parent=QModelIndex()):
        # Return the number of rows under the parent.
        if not parent.isValid():
            return len(self.root_node.children)
        elif parent.column() > 0:
            return 0
        else:
            return len(parent.internalPointer().children)

    def columnCount(self, parent=QModelIndex()):
        if not parent.isValid():
            return 1
        parent_node = parent.internalPointer()
        if not parent_node.children:
            return 2
        else:
            return 1

    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid():
            return QVariant()
        if role == Qt.DisplayRole:
            node = index.internalPointer()
            if node.type == TreeNodeType.PAKFILENAME:
                return 'sf{}.pak'.format(node.file_number)
            elif node.type == TreeNodeType.DIRNAME:
                pf = self.pakfiles[node.file_number]
                return pf.dirname_of_offset(node.dir_offset())
            elif node.type == TreeNodeType.FILENAME:
                pf = self.pakfiles[node.file_number]
                name, size = pf.get_name_and_size(node.file_index())
                return '{} ({})'.format(name, size)
        elif role == Qt.DecorationRole:
            node = index.internalPointer()
            return self.icon_map[node.type]
        elif role == Qt.ToolTipRole:
            return QVariant()
        else:
            return QVariant()

    def canFetchMore(self, parent):
        # True if there is more data available for parent.
        if not parent.isValid():
            return False
        node = parent.internalPointer()
        # PakFileName always has the directoreis populated by model construction.
        # Therefore an unpopulated node must be a Directory.
        return node.type == TreeNodeType.DIRNAME and not node.children

    def fetchMore(self, parent):
        # Fetch data for all items with the given parent:
        node = parent.internalPointer()
        pf = self.pakfiles[node.file_number]
        indices = pf.sorted_file_indices_of_dir_offset(node.dir_offset())
        for index in indices:
            filenode = TreeNode(TreeNodeType.FILENAME)
            filenode.file_number = node.file_number
            filenode.value = index
            filenode.parent = node
            node.children.append(filenode)

    def hasChildren(self, parent=QModelIndex()):
        if not parent.isValid():
            return True
        node = parent.internalPointer()
        # Files can't have children, but PakFiles and Directories always do:
        return node.type != TreeNodeType.FILENAME
