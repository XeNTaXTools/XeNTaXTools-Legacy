"""

bob animation file reader

Only tested with figure_animal_bird_fly.bob
Note that num_fields for that animation is equal to the number of bones
in figure_animal_bird.bor

import io
import struct

class error:
    def __init__(self, msg):
        self.msg = msg

class Bob:
    def __init__(self, src):
        if isinstance(src, io.BufferedReader) or isinstance(src, io.BytesIO):
            f = src
        elif isinstance(src, bytes):
            f = io.BytesIO(src)
        else:
            raise error('bad input type')
        self.fields = []
        try:
            header_a, num_fields = struct.unpack('<HL', f.read(6))
            for i in range(num_fields):
                a, b, c = struct.unpack('<3f', f.read(12))
                d, num_recs1 = struct.unpack('<2L', f.read(8))
                # First four are normalized values then fifth is larger
                # Rotation quaternion and weight/magnitude?
                recs1 = list(struct.iter_unpack('<5f', f.read(num_recs1 * 20)))
                p1 = (a, b, c, d, recs1)

                a, b, c = struct.unpack('<3f', f.read(12))
                d, num_recs2 = struct.unpack('<2L', f.read(8))
                # First three are normalized then fifth is larger, as above:
                recs2 = list(struct.iter_unpack('<4f', f.read(num_recs2 * 16)))
                p2 = (a, b, c, d, recs2)

                self.fields.append((p1, p2))
        except struct.error:
            raise error('incomplete input')

if __name__ == '__main__':
    with open('extracted resources/figure_animal_bird_fly.bob', 'rb') as f:
        b = Bob(f)


"""
