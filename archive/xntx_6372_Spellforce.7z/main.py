import logging
import sys

from PyQt5.QtWidgets import QApplication

from mainwindow import MainWindow

logging.basicConfig(format='%(asctime)s %(name)-12s %(levelname)-8s %(message)s',
                    level=logging.INFO)
app = QApplication(sys.argv)
m = MainWindow()
m.show()
sys.exit(app.exec_())
