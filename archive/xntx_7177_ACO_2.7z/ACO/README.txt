Tools for batch unpacking models and textures Assassin Creed Origins (Odyssey)

Supports:
	Geometry
	Multiple UV
	Textures

Do not support:
	Skin
	Animations

Using:

1. Edit the unpacker_forge.py script:
	In line 9, specify the path to the game directory
		path_Directory = 'G:\\SteamLibrary\\steamapps\\common\\Assassins Creed Odyssey' 
		
	In line 19, specify the path to quickbms_4gb_files.exe
		The string should look like
		str__ = '\"G:\\quickbms\\quickbms_4gb_files.exe\" -K -d '

	In line 20, specify the path to the script AC_O_Odyssey_UPD2a.bms
		The string should look like
		str__ = str__ + '\"G:\\SteamLibrary\\steamapps\\acu\\AC_O_Odyssey_UPD2a.bms\"  '

	Execute the script. It will unpack the forge game archives

2. Edit the unpacker_forge.py script:
	You need strings
	game = "acod" # for AssassinsCreedOrigins - "acor", AssassinsCreedOdyssey "acod". Defines the format of the generated files.
	input_path = 'G:\\SteamLibrary\\steamapps\\common\\sorted_all' # path to folder with raw files
	output_path = 'G:\\AssassinsCreedOdyseyUNP' # - path to folder for unpacked files
	bms_binary_path = 'G:\\quickbms\\quickbms_4gb_files.exe'
	script_path =  'G:\\SteamLibrary\\steamapps\\acu\\assassin_creed_raw.bms'
	export_without_sort = False # If you want to disable file sorting (unzip all), enter True
	export_mesh = True
	export_textures = False
	replase_files = False # (if False - if the names match, the files will be renamed, if True - replaced)

	If export_without_sort = False, you can edit the sort_mesh and sort_tex functions to select the necessary files
	
After execution, the script will unpack the raw files obtained in the previous step. Also, some files will be joined.
Now you can copy scripts from noesis_plugins to "noesisv\plugins\python" and work with the resulting files.

Good luck!



Credits:

Aluigi (http://aluigi.altervista.org/quickbms.htm) 
	- for QuickBMS and assassin_creed_raw.bms script

	
Zaramot  (https://forum.xentax.com/memberlist.php?mode=viewprofile&u=32230)
	- for AC_O_Odyssey_UPD2a.bms script


Pineapples721 (https://forum.xentax.com/memberlist.php?mode=viewprofile&u=65770 ,   http://t-poses.com/bs/)
	- for some hints about file formats


Rich Whitehouse (https://richwhitehouse.com/index.php?content=inc_projects.php)
	- for Noesis