import subprocess

import struct
import os

array_tex=[]


path_Directory = 'G:\\SteamLibrary\\steamapps\\common\\Assassins Creed Odyssey' 


for root, dirs, files in os.walk(path_Directory):
    for name in files:
        fullname = os.path.join(root, name)

        if fullname.endswith('.forge'):


           str__ = '\"G:\\quickbms\\quickbms_4gb_files.exe\" -K -d -R '
           str__ = str__ + '\"G:\\SteamLibrary\\steamapps\\acu\\AC_O_Odyssey_UPD2a.bms\"  '
           str__ = str__ + '\"' + fullname  + '"  '
           str__ = str__ + '\"' + fullname + 'folder'  + '"  '
           if not os.path.exists(fullname + 'folder'):
               os.makedirs(fullname + 'folder')


           print(str__)


		   
           subprocess.call(str__)
print ("end of dds creating")

input()
print ("end of dds creating")
