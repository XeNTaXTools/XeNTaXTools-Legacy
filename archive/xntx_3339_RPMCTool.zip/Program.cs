﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace RPMCTool
{
    class Program
    {

        public static void CopyStream(Stream input, Stream output)
        {
            byte[] buffer = new byte[2000];
            int len;
            while ((len = input.Read(buffer, 0, 2000)) > 0)
            {
                output.Write(buffer, 0, len);
            }
            output.Flush();
        }


        public static void compressFile(string inFile, string outFile)
        {
            FileStream outFileStream = new FileStream(outFile, FileMode.Create);

            zlib.ZOutputStream outZStream = new zlib.ZOutputStream(outFileStream, 8);
            FileStream inFileStream = new FileStream(inFile, FileMode.Open, FileAccess.Read);
            
            try
            {
                byte[] Magic = Encoding.ASCII.GetBytes("RPMC");
                byte[] FileSize = BitConverter.GetBytes(inFileStream.Length);


                outFileStream.Write(Magic, 0, Magic.Length);
                outFileStream.Write(FileSize, 0, 4);
                CopyStream(inFileStream, outZStream);

            }
            finally
            {
               outZStream.Close();
               outFileStream.Close();
               inFileStream.Close();
            }
        }

        public static void decompressFile(Stream input, string outFile)
        {
            System.IO.FileStream outFileStream = new System.IO.FileStream(outFile, System.IO.FileMode.Create);
            zlib.ZOutputStream outZStream = new zlib.ZOutputStream(outFileStream);
            Stream inFileStream = input;
            try
            {
                CopyStream(inFileStream, outZStream);
            }
            finally
            {
                outZStream.Close();
                outFileStream.Close();
                inFileStream.Close();
            }
        }
        
        static void Main(string[] args)
        {

            if (args.Length != 1)
            {
                args = new string[1];
                args[0] = "";
            }

            if (args.Length != 0)
            {

                FileStream F = new FileStream(args[0], FileMode.Open, FileAccess.Read);
                BinaryReader reader = new BinaryReader(F);
                ulong FileSize = (ulong)F.Length;

                byte[] PackedData = new byte[F.Length-8];
                string Magic = new string(reader.ReadChars(4));
                MemoryStream ms = new MemoryStream();

                if (Magic == "RPMC")
                {
                    FileSize = reader.ReadUInt32();

                    reader.Read(PackedData, 0, PackedData.Length);
                    ms = new MemoryStream(PackedData);

                    string sfile = "";
                    string sext = "";

                    int fileExtPos = args[0].LastIndexOf(".");
                    if (fileExtPos >= 0)
                    {
                        sfile = args[0].Substring(0, fileExtPos);
                        sext = args[0].Substring(fileExtPos, (args[0].Length - fileExtPos));
                    }
                    string output = sfile + "_unpacked" + sext;
                    decompressFile(ms, output);

                }
                else
                {
                    if (args[0].Contains("_unpacked"))
                    {
                        string sfile = "";
                        string sext = "";

                        int fileUnpackedPos = args[0].LastIndexOf("_unpacked");
                        if (fileUnpackedPos >= 0)
                        {
                            sfile = args[0].Substring(0, fileUnpackedPos);
                        }
                        int fileExtPos = args[0].LastIndexOf(".");
                        if (fileExtPos >= 0)
                        {
                            sext = args[0].Substring(fileExtPos, (args[0].Length - fileExtPos));
                        }
                        string output = sfile + sext;
                        compressFile(args[0], output);
                    }
                }

                F.Close();
            }

        }
    }
}
