import newGameLib
from newGameLib import *
import Blender	

def objParser(filename,g):
	meshCount=g.i(1)[0]
	g.H(1)
	for i in safe(meshCount):
		B=g.H(7)
		g.f(6)
		skeleton=Skeleton()
		skeleton.ARMATURESPACE=True
		skeleton.NICE=True
		mesh=Mesh()
		for m in safe(B[0]):
			bone=Bone()
			A=g.i(7)
			bone.parentID=A[4]
			g.H(1)[0]
			bone.matrix=Matrix4x4(g.f(16)).invert()
			g.f(16)
			g.f(16)
			g.f(16)
			g.f(16)
			skeleton.boneList.append(bone)
				
			if A[0]>0:
				mesh.boneName=str(m)
				skin=Skin()
				mesh.skinList.append(skin)
				for n in safe(A[0]):
					mesh.faceList.append(g.H(3))
				for n in safe(A[2]):
					t=g.tell()
					mesh.vertPosList.append(g.f(3))
					mesh.skinWeightList.append([g.f(1)[0]])
					mesh.skinIndiceList.append([g.i(1)[0]])
					g.f(3)
					mesh.vertUVList.append(g.f(2))
					g.seek(t+40)
		skeleton.draw()	
		mesh.BINDSKELETON=skeleton.name	
		mesh.draw()
		break	
	g.debug=True
	g.tell()


def aniParser(filename,g):
	#g.debug=True
	meshCount=g.i(1)[0]
	for i in safe(meshCount):#mesh
		animCount=g.H(1)[0]
		for n in safe(animCount):#anim
			A=g.H(2)
			action=Action()
			action.ARMATURESPACE=True
			action.FRAMESORT=True
			for m in safe(A[0]):#bones
				bone=ActionBone()
				bone.name=str(m)
				action.boneList.append(bone)
			
			for m in safe(A[1]):#frames
				for k in safe(A[0]):#bones
					bone=action.boneList[k]
					bone.matrixFrameList.append(m)
					matrix=Matrix3x3(g.f(9)).resize4x4()
					pos=g.f(3)
					matrix=matrix*VectorMatrix(pos)
					boneMatrix=Blender.Object.Get('armature').getData().bones[str(k)].matrix['ARMATURESPACE']
					bone.matrixKeyList.append(boneMatrix*matrix)
			action.draw()
			action.setContext()
			break		
		break		
	
	
	g.tell()
	
def Parser(filename):	
	ext=filename.split('.')[-1].lower()	
	os.system("cls")
	if ext=='obj':
		file=open(filename,'rb')
		g=BinaryReader(file)
		objParser(filename,g)
		file.close()
	if ext=='ani':
		file=open(filename,'rb')
		g=BinaryReader(file)
		aniParser(filename,g)
		file.close()
 
 
	
Blender.Window.FileSelector(Parser,'import','*.obj, *.ani') 
	