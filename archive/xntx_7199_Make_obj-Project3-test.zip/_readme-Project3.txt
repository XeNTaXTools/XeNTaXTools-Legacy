
Use for file 1 (13.443.442 bytes) and 2 (798.480 bytes) only!

Max meshes count for file 1 cut to 1696.