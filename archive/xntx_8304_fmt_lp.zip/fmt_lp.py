#by Durik256
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("The Force Unleashed", ".lp")
    noesis.setHandlerExtractArc(handle, ExtractLP)
    return 1
        
def ExtractLP(fileName, fileLen, justChecking):
    if justChecking: #it's valid
            return 1
    
    data = rapi.loadIntoByteArray(fileName)
    if data[:4] != b'kaPA':
        return 0
    
    bs = NoeBitStream(data)
    bs.seek(8)
    numFile = bs.readInt()
    bs.seek(12,1)
    namesOfs = bs.readInt() + 80
    sizeOfs = bs.readInt() + namesOfs
    OfsOfs = bs.readInt()
    dataOfs = bs.readInt()
    
    bs.seek(namesOfs)
    names = [noeAsciiFromBytes(x) for x in bs.readBytes(sizeOfs - namesOfs).split(b'\x00')[1:]]
    
    bs.seek(sizeOfs)
    size = []
    for x in range(numFile):
        bs.seek(44,1)
        size.append(bs.readInt())
        bs.seek(16,1)
    
    bs.seek(OfsOfs)
    offset = []
    for x in range(numFile):
        id = bs.readInt()
        offset.append(dataOfs + bs.readInt())
        bs.seek(8,1)

    for x in range(numFile):
        bs.seek(offset[x])
        export_data = bs.readBytes(size[x])
        rapi.exportArchiveFile(names[x], export_data)
        print("export", names[x])

    print("Extracting", numFile, "files.")
    return 1