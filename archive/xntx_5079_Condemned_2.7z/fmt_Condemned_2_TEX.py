#Condemned 2: Bloodshot [PC] - ".TEX" Loader
#By Zaramot
#v1.0

from inc_noesis import *
import subprocess

def registerNoesisTypes():
	handle = noesis.register("Condemned 2: Bloodshot [PC]", ".tex")
	noesis.setHandlerTypeCheck(handle, texCheckType)
	noesis.setHandlerLoadRGBA(handle, texLoadDDS)
	noesis.logPopup()
	return 1
		
def texCheckType(data):
	bs = NoeBitStream(data, NOE_BIGENDIAN)
	fileMagic = bs.readUInt()
	if fileMagic == 0x58545350:
		return 1
	else: 
		print("Fatal Error: Unknown file magic: " + str(hex(fileMagic) + " expected 0x58545350!"))
		return 0

def texLoadDDS(data, texList):
    bs = NoeBitStream(data, NOE_BIGENDIAN)
	
    fileMagic = bs.readUInt()
    bs.seek(0x8, NOESEEK_ABS) #Texture DXT1 or DXT5
    TexID = bs.readUByte()
    bs.seek(0x1C, NOESEEK_ABS) #Entry start
    ddsSize = (bs.readUInt())
    ddsName = rapi.getLocalFileName(rapi.getInputName())
    print (ddsName)
    bs.seek(0x10, NOESEEK_ABS) #Entry start
    TWidth = bs.readUShort()
    Height = bs.readUShort()
    print (TWidth)
    print (Height)
    print (TexID)
    print (ddsSize)
    bs.seek(0x20, NOESEEK_ABS) #Texture start
    ddsData = bs.readBytes(ddsSize)
    #DXT1
    if TexID == 134:
        texFmt = noesis.NOESISTEX_DXT1
    #DXT3
    elif TexID == 133:
        texFmt = noesis.NOESISTEX_DXT5
    #DXT5
    elif TexID == 136:
        texFmt = noesis.NOESISTEX_DXT5
    tex1 = (NoeTexture(ddsName, TWidth, Height, ddsData, texFmt))
    texList.append(tex1)

    return 1
	