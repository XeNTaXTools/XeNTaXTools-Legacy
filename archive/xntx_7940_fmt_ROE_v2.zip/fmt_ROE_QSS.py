from inc_noesis import *
import noesis
import rapi
import os
import glob


def registerNoesisTypes():
    handle = noesis.register("Ring of Elysium Skel", ".QSS")
    noesis.setHandlerTypeCheck(handle, ROECheckType)
    # see also noepyLoadModelRPG
    noesis.setHandlerLoadModel(handle, ROELoadModel)
    noesis.logPopup()
    return 1


def ROECheckType(data):
    return 1


def ROELoadModel(data, mdlList):
    ctx = rapi.rpgCreateContext()
    QSSboneNames = []
    meshes = []
    boneList = []

    if (True):
        ss = NoeBitStream(data)
        boneCount = ss.readUInt()
        print('boneCount', boneCount)
        for i in range(0, boneCount):
            boneBlockSize = ss.readUByte()
            boneName = noeStrFromBytes(ss.readBytes(boneBlockSize-192))
            QSSboneNames.append(boneName)
            boneParent = ss.readInt()
            print(str(i), str(boneParent), boneName)
            boneMtxLocal = NoeMat43.fromBytes(ss.readBytes(48))
            boneScaleLocal = NoeVec3.fromBytes(ss.readBytes(12))
            boneMtx = NoeMat43.fromBytes(ss.readBytes(48))
            boneScale = NoeVec3.fromBytes(ss.readBytes(12))
            boneMtx[3] *= boneScale
            BoneQuat = NoeQuat.fromBytes(ss.readBytes(16))
            newBone = NoeBone(i, boneName, boneMtx, None, boneParent)
            boneList.append(newBone)

    mesh = NoeMesh([], [])
    meshes.append(mesh)
    mdl = NoeModel(meshes, boneList)
    mdlList.append(mdl)
    return 1
