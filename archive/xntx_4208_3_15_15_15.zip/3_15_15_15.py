
		
def quatDecompress(s0,s1,s2):  
	tmp0= s0>>15 
	tmp1= (s1*2+tmp0) & 0x7FFF
	s0= s0 & 0x7FFF ;
	tmp2= s2*4 ;
	tmp2= (s2*4+ (s1>>14)) & 0x7FFF ;
	s1= tmp1 ;
	AxisFlag= s2>>13 ;
	#AxisFlag = ((s1 & 1) << 1) | (s2 & 1)
	s2= tmp2 ;
	f0 = 1.41421*(s0-0x3FFF)/0x7FFF ;
	f1 = 1.41421*(s1-0x3FFF)/0x7FFF ;
	f2 = 1.41421*(s2-0x3FFF)/0x7FFF ;  
	f3 = sqrt(1.0-(f0*f0+f1*f1+f2*f2)) 
	if AxisFlag==3:x= f2;y= f1;z= f0;w= f3
	if AxisFlag==2:x= f2;y= f1;z= f3;w= f0
	if AxisFlag==1:x= f2;y= f3;z= f1;w= f0
	if AxisFlag==0:x= f3;y= f2;z= f1;w= f0
	return x,y,z,w 