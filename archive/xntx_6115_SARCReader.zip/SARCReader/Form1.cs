﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SARCReader
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public struct fileInfo
        {
            public uint offset;
            public uint size;
            public string name;
        }

        public List<fileInfo> files = new List<fileInfo>();
        public byte[] buff;

        private void fileOpenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog d = new OpenFileDialog();
            d.Filter = "*.bin|*.bin";
            if (d.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                buff = File.ReadAllBytes(d.FileName);
                StringBuilder sb = new StringBuilder();
                uint magic = BitConverter.ToUInt32(buff, 0);
                if (magic != 0x43524153)
                    sb.AppendLine("Wrong magic (" + magic.ToString("X8") + ")");
                else
                {
                    uint count = BitConverter.ToUInt32(buff, 4);
                    int pos = 8;
                    files = new List<fileInfo>();
                    for (int i = 0; i < count; i++)
                    {
                        fileInfo info = new fileInfo();
                        sb.AppendLine("File Info #" + i.ToString("D4") + " :");
                        sb.AppendLine("Unknown1 = " + BitConverter.ToUInt32(buff, pos).ToString("X8"));
                        sb.AppendLine("Unknown2 = " + BitConverter.ToUInt32(buff, pos + 4).ToString("X8"));
                        info.size = BitConverter.ToUInt32(buff, pos + 8);
                        info.offset = BitConverter.ToUInt32(buff, pos + 12);
                        sb.AppendLine("Size     = " + info.size.ToString("X8"));
                        sb.AppendLine("Offset   = " + info.offset.ToString("X8"));                        
                        pos += 0x10;
                        info.name = readNullString(buff, pos);
                        sb.AppendLine("Path     = " + info.name);
                        pos += 0x100;
                        files.Add(info);
                    }
                }
                rtb1.Text = sb.ToString();
                comboBox1.Items.Clear();
                foreach (fileInfo info in files)
                    comboBox1.Items.Add(Path.GetFileName(info.name));
                comboBox1.SelectedIndex = 0;
            }            
        }
        private string readNullString(byte[] buff, int pos)
        {
            StringBuilder sb = new StringBuilder();
            while (buff[pos] != 0)
                sb.Append((char)buff[pos++]);
            return sb.ToString();
        }

        public static string HexDump(byte[] bytes, int bytesPerLine = 16)
        {
            if (bytes == null) return "<null>";
            int bytesLength = bytes.Length;

            char[] HexChars = "0123456789ABCDEF".ToCharArray();

            int firstHexColumn =
                  8                   // 8 characters for the address
                + 3;                  // 3 spaces

            int firstCharColumn = firstHexColumn
                + bytesPerLine * 3       // - 2 digit for the hexadecimal value and 1 space
                + (bytesPerLine - 1) / 8 // - 1 extra space every 8 characters from the 9th
                + 2;                  // 2 spaces 

            int lineLength = firstCharColumn
                + bytesPerLine           // - characters to show the ascii value
                + Environment.NewLine.Length; // Carriage return and line feed (should normally be 2)

            char[] line = (new String(' ', lineLength - Environment.NewLine.Length) + Environment.NewLine).ToCharArray();
            int expectedLines = (bytesLength + bytesPerLine - 1) / bytesPerLine;
            StringBuilder result = new StringBuilder(expectedLines * lineLength);

            for (int i = 0; i < bytesLength; i += bytesPerLine)
            {
                line[0] = HexChars[(i >> 28) & 0xF];
                line[1] = HexChars[(i >> 24) & 0xF];
                line[2] = HexChars[(i >> 20) & 0xF];
                line[3] = HexChars[(i >> 16) & 0xF];
                line[4] = HexChars[(i >> 12) & 0xF];
                line[5] = HexChars[(i >> 8) & 0xF];
                line[6] = HexChars[(i >> 4) & 0xF];
                line[7] = HexChars[(i >> 0) & 0xF];

                int hexColumn = firstHexColumn;
                int charColumn = firstCharColumn;

                for (int j = 0; j < bytesPerLine; j++)
                {
                    if (j > 0 && (j & 7) == 0) hexColumn++;
                    if (i + j >= bytesLength)
                    {
                        line[hexColumn] = ' ';
                        line[hexColumn + 1] = ' ';
                        line[charColumn] = ' ';
                    }
                    else
                    {
                        byte b = bytes[i + j];
                        line[hexColumn] = HexChars[(b >> 4) & 0xF];
                        line[hexColumn + 1] = HexChars[b & 0xF];
                        line[charColumn] = (b < 32 ? '·' : (char)b);
                    }
                    hexColumn += 3;
                    charColumn++;
                }
                result.Append(line);
            }
            return result.ToString();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int n = comboBox1.SelectedIndex;
            fileInfo info = files[n];
            MemoryStream m = new MemoryStream();
            m.Write(buff, (int)info.offset, (int)info.size);
            rtb2.Text = HexDump(m.ToArray());
        }

        private void exportSelectedToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int n = comboBox1.SelectedIndex;
            fileInfo info = files[n];
            MemoryStream m = new MemoryStream();
            m.Write(buff, (int)info.offset, (int)info.size);
            SaveFileDialog d = new SaveFileDialog();
            string ext = Path.GetExtension(info.name);
            d.Filter = "*" + ext + "|*" + ext;
            d.FileName = Path.GetFileName(info.name);
            if (d.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                File.WriteAllBytes(d.FileName, m.ToArray());
                MessageBox.Show("Done.");
            }
        }
    }
}
