#Base Model Class

from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Tears to Tiara II", ".mdl")
	noesis.setHandlerTypeCheck(handle, testCheckType)
	noesis.setHandlerLoadModel(handle, testLoadModel)
	#noesis.logPopup()
	return 1


def testCheckType(data):
	bs = NoeBitStream(data)
	test = bs.readBytes(8).decode("ASCII").rstrip("\0")
	if test == "Controll" or test == "AnmName ":
		return 1
	return 0


class Tears2mdl(object): 
      
	def __init__(self, data):     
          
		self.inFile   = NoeBitStream(data, NOE_BIGENDIAN)
		rapi.rpgSetOption(noesis.RPGOPT_BIGENDIAN, 1)
		self.texList  = []
		self.matList  = [] 
		self.boneList = []
		self.boneMap  = []
		self.meshOffsets = []

	def alignPosition(self, bs, alignment):
		alignment = alignment - 1
		bs.seek(((bs.tell() + alignment) & ~alignment), NOESEEK_ABS)

	def loadObjectControll(self, bs):
		self.controllCount = bs.readUInt()
		self.controllStart = bs.tell()
		for i in range(0, self.controllCount):
			bs.seek((self.controllStart + (i * 0xF28)), NOESEEK_ABS)
			usedBones = bs.readUInt()
			self.boneMap.append(bs.read(">" + usedBones * "i"))
		#print(self.boneMap)
		bs.seek((self.chunkStart + self.chunkSize), NOESEEK_ABS)
		pass

	def loadObjectTexture(self, bs):
		#print("Chunk Start:", self.chunkStart, "Chunk Type:", self.chunkType)
		self.textureStart = bs.tell()
		self.textureCount = bs.readUInt()
		textureOffsets = bs.read(">" + self.textureCount * "i")
		for i in range(0, self.textureCount):
			bs.seek((self.textureStart + textureOffsets[i]))
			texName1 = bs.readBytes(0x20).decode("ASCII").rstrip("\0")
			texName2 = bs.readBytes(0x20).decode("ASCII").rstrip("\0")
			texInfo = bs.read(">" + 7 * "i")
			if texInfo[0] == 0:
				texFmt = noesis.NOESISTEX_DXT1
			elif texInfo[0] == 1:
				texFmt = noesis.NOESISTEX_DXT5
			tex1 = NoeTexture(texName2, texInfo[5], texInfo[6], bs.readBytes(texInfo[4]), texFmt)
			#print([texName1, texName2, texInfo])
			self.texList.append(tex1)
		bs.seek((self.chunkStart + self.chunkSize), NOESEEK_ABS)
		pass

	def loadObjectLightTex(self, bs):
		bs.seek((self.chunkStart + self.chunkSize), NOESEEK_ABS)
		pass

	def loadObjectMaterial(self, bs):
		self.matCount = bs.readUInt()
		for i in range(0, self.matCount):
			matName = bs.readBytes(0x30).decode("ASCII").rstrip("\0")
			matInfo = bs.read(">" + 2 * "i")
			material = NoeMaterial(matName, "")
			self.matList.append(material)
		bs.seek((self.chunkStart + self.chunkSize), NOESEEK_ABS)
		pass

	def loadObjectEffect(self, bs):
		self.objectCount = bs.readUInt()
		for i in range(0, self.objectCount):
			opacity = bs.readUInt()
			bs.seek(0x54, NOESEEK_REL)
			diffuseInfo = bs.read(">" + 10 * "i")
			bs.seek(0x50, NOESEEK_REL)
			normalInfo = bs.read(">" + 10 * "i")
			bs.seek(0x50, NOESEEK_REL)
			#print(diffuseInfo, normalInfo)
			if diffuseInfo[3]:
				self.matList[i].setTexture(self.texList[diffuseInfo[0]].name)
				self.matList[i].setDiffuseColor( (0.35, 0.35, 0.35, 1.0) )
				self.matList[i].setSpecularColor([0.0, 0.0, 0.0, 1.0])
				secondPassMat = NoeMaterial(self.matList[i].name + "_emissive", self.texList[diffuseInfo[0]].name)
				secondPassMat.setFlags(noesis.NMATFLAG_TWOSIDED, 1)
				secondPassMat.setBlendMode("GL_SRC_ALPHA", "GL_ONE")
				secondPassMat.setDiffuseColor( (0.8, 0.8, 0.8, 1.0) )
				self.matList[i].setNextPass(secondPassMat)
			if normalInfo[3]:
				self.matList[i].setNormalTexture(self.texList[normalInfo[0]].name)
			self.matList[i].setFlags(noesis.NMATFLAG_TWOSIDED)
			#if self.texList[diffuseInfo[0]].name == "t111c_f1" or self.texList[diffuseInfo[0]].name == "t111c_f0":
			#	texAnimExpr = "8 + min(floor(mod(time*0.002, 4)), 4)"
			#	self.matList[i].setExpr_texidx(texAnimExpr)
			#	secondPassMat.setExpr_texidx(texAnimExpr)
			
		bs.seek((self.chunkStart + self.chunkSize), NOESEEK_ABS)
		pass

	def loadObjectNode(self, bs):
		#print("Chunk Start:", self.chunkStart, "Chunk Type:", self.chunkType)
		self.boneCount = bs.readUInt()
		self.bone2Count = bs.readUInt()
		boneParenting = []
		for i in range(0, self.boneCount):
			boneName = bs.readBytes(0x34).decode("ASCII").rstrip("\0")
			boneParenting.append(bs.read(">" + 2 * "i"))
			BonePos = NoeVec3.fromBytes(bs.readBytes(12), NOE_BIGENDIAN)
			boneFloat = bs.read(">" + 15 * "f")
			boneMtx = NoeMat44.fromBytes(bs.readBytes(64), NOE_BIGENDIAN).toMat43().inverse()
			newBone = NoeBone(i, (boneName + "_" + str(i)), boneMtx, None, -1)
			self.boneList.append(newBone)
		for i in range(0, self.boneCount):
			p = self.boneList[i]
			cidx = boneParenting[i][0]
			while cidx != -1:
				b = self.boneList[cidx]
				b.parentIndex = p.index
				cidx = boneParenting[cidx][1]
		for i in range(0, self.bone2Count):
			pass
		bs.seek((self.chunkStart + self.chunkSize), NOESEEK_ABS)

	def loadObjectMesh(self, bs):
		#print("Chunk Start:", self.chunkStart, "Chunk Type:", self.chunkType)
		self.meshStart = bs.tell()
		self.meshCount = bs.readUInt()
		self.meshOffsets = bs.read(">" + self.meshCount * "i")

		bs.seek((self.chunkStart + self.chunkSize), NOESEEK_ABS)
		pass

	def loadObjectDrawList(self, bs):
		self.drawListCount = bs.readUInt()
		self.drawListStart = bs.tell()
		for i in range(0, self.meshCount):
			bs.seek((self.drawListStart + (i * 0x74)), NOESEEK_ABS)
			drawInfo = bs.read(">" + 5 * "i")
			#print(drawInfo)
			parentIndex = self.boneList[(drawInfo[0])].parentIndex
			rapi.rpgSetTransform(None)
			if drawInfo[3] == -1:
				if parentIndex == -1:
					rapi.rpgSetBoneMap([drawInfo[0]])
				else:
					rapi.rpgSetBoneMap([parentIndex])
				rapi.rpgSetTransform(self.boneList[drawInfo[0]].getMatrix())
			else:
				rapi.rpgSetBoneMap(self.boneMap[drawInfo[3]])
			
			bs.seek((self.meshStart + self.meshOffsets[i]), NOESEEK_ABS)
			meshType, vertCount, faceCount = bs.read(">" + 3 * "i")
			#print([meshType, vertCount, faceCount])
			rapi.rpgSetName(self.boneList[(drawInfo[0])].name)
			rapi.rpgSetMaterial(self.matList[drawInfo[2]].name)
			#print(bs.tell())

			hash = bs.readBytes(8)
			vertBuff = bs.readBytes(0x24 * vertCount)
			hash = bs.readBytes(8)
			faceBuff = bs.readBytes(0x2 * faceCount)
			if (meshType) == 0:
				#Aligned Done
				indexBuff = bytearray(vertCount)
				weightData = [1.0]*(vertCount)
				weightBuff = struct.pack(">" + 'f'*len(weightData), *weightData)
				rapi.rpgBindPositionBufferOfs(vertBuff, noesis.RPGEODATA_FLOAT, 0x24, 0)
				rapi.rpgBindNormalBufferOfs(vertBuff, noesis.RPGEODATA_FLOAT, 0x24, 12)
				rapi.rpgBindColorBufferOfs(vertBuff, noesis.RPGEODATA_UBYTE, 0x24, 24, 4)
				rapi.rpgBindUV1BufferOfs(vertBuff, noesis.RPGEODATA_FLOAT, 0x24, 28)
				rapi.rpgBindBoneIndexBufferOfs(indexBuff, noesis.RPGEODATA_BYTE, 1, 0, 1)
				rapi.rpgBindBoneWeightBufferOfs(weightBuff, noesis.RPGEODATA_FLOAT, 4, 0, 1)
				rapi.rpgCommitTriangles(faceBuff, noesis.RPGEODATA_USHORT, faceCount, noesis.RPGEO_TRIANGLE, 1)
			elif (meshType) == 2:
				#Aligned Done
				self.alignPosition(bs, 4)
				hash = bs.readBytes(8)
				vertBuff2 = bs.readBytes(0x20 * vertCount)
				indexBuff = bytearray(vertCount)
				weightData = [1.0]*(vertCount)
				weightBuff = struct.pack(">" + 'f'*len(weightData), *weightData)
				rapi.rpgBindPositionBufferOfs(vertBuff, noesis.RPGEODATA_FLOAT, 0x24, 0)
				rapi.rpgBindNormalBufferOfs(vertBuff, noesis.RPGEODATA_FLOAT, 0x24, 12)
				rapi.rpgBindColorBufferOfs(vertBuff, noesis.RPGEODATA_UBYTE, 0x24, 24, 4)
				rapi.rpgBindUV1BufferOfs(vertBuff, noesis.RPGEODATA_FLOAT, 0x24, 28)
				rapi.rpgBindBoneIndexBufferOfs(indexBuff, noesis.RPGEODATA_BYTE, 1, 0, 1)
				rapi.rpgBindBoneWeightBufferOfs(weightBuff, noesis.RPGEODATA_FLOAT, 4, 0, 1)
				rapi.rpgCommitTriangles(faceBuff, noesis.RPGEODATA_USHORT, faceCount, noesis.RPGEO_TRIANGLE, 1)
			elif (meshType) == 4:
				#Aligned Done
				hash = bs.readBytes(8)
				self.alignPosition(bs, 4)
				weightBuff = bs.readBytes(0x14 * vertCount)
				rapi.rpgBindPositionBufferOfs(vertBuff, noesis.RPGEODATA_FLOAT, 0x24, 0)
				rapi.rpgBindNormalBufferOfs(vertBuff, noesis.RPGEODATA_FLOAT, 0x24, 12)
				rapi.rpgBindColorBufferOfs(vertBuff, noesis.RPGEODATA_UBYTE, 0x24, 24, 4)
				rapi.rpgBindUV1BufferOfs(vertBuff, noesis.RPGEODATA_FLOAT, 0x24, 28)
				rapi.rpgBindBoneIndexBufferOfs(weightBuff, noesis.RPGEODATA_BYTE, 0x14, 0, 4)
				rapi.rpgBindBoneWeightBufferOfs(weightBuff, noesis.RPGEODATA_FLOAT, 0x14, 4, 4)
				rapi.rpgCommitTriangles(faceBuff, noesis.RPGEODATA_USHORT, faceCount, noesis.RPGEO_TRIANGLE, 1)
			elif (meshType) == 6:
				#Aligned Done
				hash = bs.readBytes(8)
				vertBuff2 = bs.readBytes(0x20 * vertCount)
				hash = bs.readBytes(8)
				self.alignPosition(bs, 4)
				weightBuff = bs.readBytes(0x14 * vertCount)
				rapi.rpgBindPositionBufferOfs(vertBuff, noesis.RPGEODATA_FLOAT, 0x24, 0)
				rapi.rpgBindNormalBufferOfs(vertBuff, noesis.RPGEODATA_FLOAT, 0x24, 12)
				rapi.rpgBindColorBufferOfs(vertBuff, noesis.RPGEODATA_UBYTE, 0x24, 24, 4)
				rapi.rpgBindUV1BufferOfs(vertBuff, noesis.RPGEODATA_FLOAT, 0x24, 28)
				rapi.rpgBindBoneIndexBufferOfs(weightBuff, noesis.RPGEODATA_UBYTE, 0x14, 0, 4)
				rapi.rpgBindBoneWeightBufferOfs(weightBuff, noesis.RPGEODATA_FLOAT, 0x14, 4, 4)
				rapi.rpgCommitTriangles(faceBuff, noesis.RPGEODATA_USHORT, faceCount, noesis.RPGEO_TRIANGLE, 1)
			elif (meshType) == 16:
				#Aligned Done
				indexBuff = bytearray(vertCount)
				weightData = [1.0]*(vertCount)
				weightBuff = struct.pack(">" + 'f'*len(weightData), *weightData)
				rapi.rpgBindPositionBufferOfs(vertBuff, noesis.RPGEODATA_FLOAT, 0x24, 0)
				rapi.rpgBindNormalBufferOfs(vertBuff, noesis.RPGEODATA_FLOAT, 0x24, 12)
				rapi.rpgBindColorBufferOfs(vertBuff, noesis.RPGEODATA_UBYTE, 0x24, 24, 4)
				rapi.rpgBindUV1BufferOfs(vertBuff, noesis.RPGEODATA_FLOAT, 0x24, 28)
				rapi.rpgBindBoneIndexBufferOfs(indexBuff, noesis.RPGEODATA_BYTE, 1, 0, 1)
				rapi.rpgBindBoneWeightBufferOfs(weightBuff, noesis.RPGEODATA_FLOAT, 4, 0, 1)
				rapi.rpgCommitTriangles(faceBuff, noesis.RPGEODATA_USHORT, faceCount, noesis.RPGEO_TRIANGLE, 1)
			elif (meshType) == 18:
				#Aligned Done
				hash = bs.readBytes(8)
				vertBuff2 = bs.readBytes(0x20 * vertCount)
				indexBuff = bytearray(vertCount)
				weightData = [1.0]*(vertCount)
				weightBuff = struct.pack(">" + 'f'*len(weightData), *weightData)
				rapi.rpgBindPositionBufferOfs(vertBuff, noesis.RPGEODATA_FLOAT, 0x24, 0)
				rapi.rpgBindNormalBufferOfs(vertBuff, noesis.RPGEODATA_FLOAT, 0x24, 12)
				rapi.rpgBindColorBufferOfs(vertBuff, noesis.RPGEODATA_UBYTE, 0x24, 24, 4)
				rapi.rpgBindUV1BufferOfs(vertBuff, noesis.RPGEODATA_FLOAT, 0x24, 28)
				rapi.rpgBindBoneIndexBufferOfs(indexBuff, noesis.RPGEODATA_BYTE, 1, 0, 1)
				rapi.rpgBindBoneWeightBufferOfs(weightBuff, noesis.RPGEODATA_FLOAT, 4, 0, 1)
				rapi.rpgCommitTriangles(faceBuff, noesis.RPGEODATA_USHORT, faceCount, noesis.RPGEO_TRIANGLE, 1)
			elif (meshType) == 20:
				#Aligned Done
				hash = bs.readBytes(8)
				self.alignPosition(bs, 4)
				weightBuff = bs.readBytes(0x14 * vertCount)
				rapi.rpgBindPositionBufferOfs(vertBuff, noesis.RPGEODATA_FLOAT, 0x24, 0)
				rapi.rpgBindNormalBufferOfs(vertBuff, noesis.RPGEODATA_FLOAT, 0x24, 12)
				rapi.rpgBindColorBufferOfs(vertBuff, noesis.RPGEODATA_UBYTE, 0x24, 24, 4)
				rapi.rpgBindUV1BufferOfs(vertBuff, noesis.RPGEODATA_FLOAT, 0x24, 28)
				rapi.rpgBindBoneIndexBufferOfs(weightBuff, noesis.RPGEODATA_BYTE, 0x14, 0, 4)
				rapi.rpgBindBoneWeightBufferOfs(weightBuff, noesis.RPGEODATA_FLOAT, 0x14, 4, 4)
				rapi.rpgCommitTriangles(faceBuff, noesis.RPGEODATA_USHORT, faceCount, noesis.RPGEO_TRIANGLE, 1)
			elif (meshType) == 22:
				#Aligned Done
				hash = bs.readBytes(8)
				vertBuff2 = bs.readBytes(0x20 * vertCount)
				hash = bs.readBytes(8)
				self.alignPosition(bs, 4)
				weightBuff = bs.readBytes(0x14 * vertCount)
				rapi.rpgBindPositionBufferOfs(vertBuff, noesis.RPGEODATA_FLOAT, 0x24, 0)
				rapi.rpgBindNormalBufferOfs(vertBuff, noesis.RPGEODATA_FLOAT, 0x24, 12)
				rapi.rpgBindColorBufferOfs(vertBuff, noesis.RPGEODATA_UBYTE, 0x24, 24, 4)
				rapi.rpgBindUV1BufferOfs(vertBuff, noesis.RPGEODATA_FLOAT, 0x24, 28)
				rapi.rpgBindBoneIndexBufferOfs(weightBuff, noesis.RPGEODATA_BYTE, 0x14, 0, 4)
				rapi.rpgBindBoneWeightBufferOfs(weightBuff, noesis.RPGEODATA_FLOAT, 0x14, 4, 4)
				rapi.rpgCommitTriangles(faceBuff, noesis.RPGEODATA_USHORT, faceCount, noesis.RPGEO_TRIANGLE, 1)
			elif (meshType) == 33:
				#Aligned Done
				indexBuff = bytearray(vertCount)
				weightData = [1.0]*(vertCount)
				weightBuff = struct.pack(">" + 'f'*len(weightData), *weightData)
				rapi.rpgBindPositionBufferOfs(vertBuff, noesis.RPGEODATA_FLOAT, 0x24, 0)
				rapi.rpgBindNormalBufferOfs(vertBuff, noesis.RPGEODATA_FLOAT, 0x24, 12)
				rapi.rpgBindColorBufferOfs(vertBuff, noesis.RPGEODATA_UBYTE, 0x24, 24, 4)
				rapi.rpgBindUV1BufferOfs(vertBuff, noesis.RPGEODATA_FLOAT, 0x24, 28)
				rapi.rpgBindBoneIndexBufferOfs(indexBuff, noesis.RPGEODATA_BYTE, 1, 0, 1)
				rapi.rpgBindBoneWeightBufferOfs(weightBuff, noesis.RPGEODATA_FLOAT, 4, 0, 1)
				rapi.rpgCommitTriangles(faceBuff, noesis.RPGEODATA_USHORT, faceCount, noesis.RPGEO_TRIANGLE, 1)
			else:
				print("Unkown Mesh Format at ", bs.tell())
				print([meshType, vertCount, faceCount])
			rapi.rpgClearBufferBinds()
		bs.seek((self.chunkStart + self.chunkSize), NOESEEK_ABS)
		pass

	def loadObjectGroup(self, bs):
		bs.seek((self.chunkStart + self.chunkSize), NOESEEK_ABS)
		pass

	def loadObjectCamera(self, bs):
		bs.seek((self.chunkStart + self.chunkSize), NOESEEK_ABS)
		pass

	def loadObjectAnmName(self, bs):
		bs.seek((self.chunkStart + self.chunkSize), NOESEEK_ABS)
		pass

	def loadObjectNodeAnm(self, bs):
		bs.seek((self.chunkStart + self.chunkSize), NOESEEK_ABS)
		pass

	def loadObjectUVAnm(self, bs):
		bs.seek((self.chunkStart + self.chunkSize), NOESEEK_ABS)
		pass

	def parse_file(self): 
		'''Main parser method'''
		bs = self.inFile
		while bs.tell() < (bs.dataSize - 4):
			self.chunkStart = bs.tell()
			self.chunkType = bs.readBytes(8).decode("ASCII").rstrip("\0")
			self.chunkSize = bs.readUInt()
			#print("Chunk Start:", self.chunkStart, "Chunk Type:", self.chunkType)
			if self.chunkType in testObjectLoaderDict:
				testObjectLoaderDict[self.chunkType](self, bs)
			else:
				print("NO")
				print("Chunk Start:", self.chunkStart, "Chunk Type:", self.chunkType)
				print("Unknown object has unknown size, breaking.")
				bs.seek((self.chunkStart + self.chunkSize), NOESEEK_ABS)
				break
		return 1         

testObjectLoaderDict = {
	"Controll" : Tears2mdl.loadObjectControll,
	"Texture " : Tears2mdl.loadObjectTexture,
	"LightTex" : Tears2mdl.loadObjectLightTex,
	"Material" : Tears2mdl.loadObjectMaterial,
	"Effect  " : Tears2mdl.loadObjectEffect,
	"Node    " : Tears2mdl.loadObjectNode,
	"Mesh    " : Tears2mdl.loadObjectMesh,
	"DrawList" : Tears2mdl.loadObjectDrawList,
	"Group   " : Tears2mdl.loadObjectGroup,
	"Camera  " : Tears2mdl.loadObjectCamera,
	"AnmName " : Tears2mdl.loadObjectAnmName,
	"NodeAnm " : Tears2mdl.loadObjectNodeAnm,
	"UVAnm   " : Tears2mdl.loadObjectUVAnm  

}

def testLoadModel(data, mdlList):
	ctx = rapi.rpgCreateContext()
	parser = Tears2mdl(data)
	parser.parse_file()
	rapi.rpgSmoothTangents()
	rapi.rpgUnifyBinormals(1)
	try:
		mdl = rapi.rpgConstructModel()
	except:
		mdl = NoeModel()
	mdl.setModelMaterials(NoeModelMaterials(parser.texList, parser.matList))
	mdlList.append(mdl); mdl.setBones(parser.boneList)	
	return 1