
#include "human.h"

//+---------------------------------------------------------> cHuman

cHuman::cHuman()
{
}

//+---------------------------------------------------------> Delete()
// clears the model data

void cHuman::Delete()
{
	if(m_pBoneInfo)
	{
		delete[] m_pBoneInfo;
		m_pBoneInfo = NULL;
	}
	if(m_pBoneTransform)
	{
		delete[] m_pBoneTransform;
		m_pBoneTransform = NULL;
	}
	if(m_pTexture)
	{
		delete[] m_pTexture;
		m_pTexture = NULL;
	}
	if(m_pMaterial)
	{
		delete[] m_pMaterial;
		m_pMaterial = NULL;
	}
	if(m_pObject)
	{
		delete[] m_pObject;
		m_pObject = NULL;
	}
	if(m_pVertex)
	{
		delete[] m_pVertex;
		m_pVertex = NULL;
	}
	if(m_pIndex)
	{
		delete[] m_pIndex;
		m_pIndex = NULL;
	}
}

//+---------------------------------------------------------> Load()
// loads the designated model

bool cHuman::Load(const char *strModel)
{
	// try to open the file
	FILE *pFile = fopen(strModel, "rb");
	if(!pFile)
	{
		printf("Can't open file [%s] !\n", strModel);
		return false;
	}

	// read the header info and check the signature
	fread(this, sizeof(cHuman), 1, pFile);
	if(m_uiTag != 0x00444F4D)
	{
		printf("Invalid model file [%s] !!\n", strModel);
		fclose(pFile);
		return false;
	}

	// read the bone info
	m_pBoneInfo = new cBoneInfo[m_usBoneNum];
	fseek(pFile, m_uiBoneOffset, SEEK_SET);
	fread(m_pBoneInfo, sizeof(cBoneInfo), m_usBoneNum, pFile);

	printf("[%s]\n", strModel);
	printf("\tobjects: %d\n\tmaterials: %d\n\tverts: %d\n\tindices: %d\n\ttextures: %d\nreading data ... ", m_usObjectNum, m_usMaterialNum, m_uiVertexNum, m_uiIndexNum, m_uiTextureNum);

	// allocate memory for the bone tranforms and read them
	m_pBoneTransform = new cBoneTransform[m_usBoneNum];
	fread(m_pBoneTransform, sizeof(cBoneTransform), m_usBoneNum, pFile);

	// a big part is missing here !!!!!!!!!!!!!
    
	// read the textures names
	m_pTexture = new cTexture[m_uiTextureNum];
	fseek(pFile, m_uiTextureOffset, SEEK_SET);
	fread(m_pTexture, sizeof(cTexture), m_uiTextureNum, pFile);

	// now read the materials
	m_pMaterial = new cMaterial[m_usMaterialNum];
	fread(m_pMaterial, sizeof(cMaterial), m_usMaterialNum, pFile);

	// read the objects
	m_pObject = new cObject[m_usObjectNum];
	fseek(pFile, m_uiObjectOffset, SEEK_SET);
	fread(m_pObject, sizeof(cObject), m_usObjectNum, pFile);

	// a part is missing here !!!

	// read the vertex data
	m_pVertex = new cVertex[m_uiVertexNum];
	fseek(pFile, m_uiVertexOffset, SEEK_SET);
	fread(m_pVertex, sizeof(cVertex), m_uiVertexNum, pFile);

	// read the index data
	m_pIndex = new WORD[m_uiIndexNum];
	fseek(pFile, m_uiIndexOffset, SEEK_SET);
	fread(m_pIndex, 2, m_uiIndexNum, pFile);

	return true;
}

//+---------------------------------------------------------> Export()
// exports the model data

bool cHuman::Export(const char *strModel)
{
	FILE *pFile = fopen(strModel, "wt");
	printf("exporting data ... ");

	unsigned int uiIndex = 0;
	fprintf(pFile, "# %d verts\n", m_uiVertexNum);
	for(unsigned int a = 0; a < m_uiVertexNum; a++)
	{
		// for humans
		float x = (m_pVertex[a].x - 16383.5f) * 1.0f * 0.005f;
		float y = (m_pVertex[a].y - 16383.5f) * 0.005f;
		float z = (m_pVertex[a].z - 16383.5f) * 0.2f * 0.005f;

		// for weapons ??
		//float x = (m_pVertex[a].x - 16383.5f) * 0.0008f;
		//float y = (m_pVertex[a].y - 16383.5f) * 0.00035f;
		//float z = (m_pVertex[a].z - 16383.5f) * 0.0055f;

		// for vital suits
		//fprintf(pFile, "v %f %f %f\n", (m_pVertex[a].x - 16383.5f) * 1.4f, m_pVertex[a].y - 16383.5f, (m_pVertex[a].z - 16383.5f) * 0.5f);

		// otherwise
		//fprintf(pFile, "v %f %f %f\n", m_pVertex[a].x * 16.0f / 3276.7f, m_pVertex[a].y * 16.0f / 3276.7f, m_pVertex[a].z * 16.0f / 3276.7f);

		fprintf(pFile, "v %f %f %f\n", x, y, z);
	}

	// U coords
	WORD *pUW = new WORD[m_uiVertexNum];
	for(unsigned int a = 0; a < m_uiVertexNum; a++)
	{
		if(m_pVertex[a].u1 == -1)
			pUW[a] = m_pVertex[a].u0;
		else
			pUW[a] = m_pVertex[a].u1;
	}
	D3DXFLOAT16 *pU = (D3DXFLOAT16*)pUW;
	float *pUF = new float[m_uiVertexNum];
	D3DXFloat16To32Array(pUF, pU, m_uiVertexNum);


	// V coords
	WORD *pVW = new WORD[m_uiVertexNum];
	for(unsigned int a = 0; a < m_uiVertexNum; a++)
	{
		if(m_pVertex[a].v1 == -1)
			pVW[a] = m_pVertex[a].v0;
		else
			pVW[a] = m_pVertex[a].v1;
	}
	D3DXFLOAT16 *pW = (D3DXFLOAT16*)pVW;
	float *pVF = new float[m_uiVertexNum];
	D3DXFloat16To32Array(pVF, pW, m_uiVertexNum);

	// export UV coords
	for(unsigned int a = 0; a < m_uiVertexNum; a++)
		fprintf(pFile, "vt %f %f %f\n", pUF[a], 1.0f - pVF[a], 0.5f);

	for(unsigned int a = 0; a < m_uiVertexNum; a++)
		fprintf(pFile, "vn %f %f %f\n", m_pVertex[a].tx / 128.0f, m_pVertex[a].ty / 128.0f, m_pVertex[a].tz / 128.0f);

	for(a = 0; a < m_usObjectNum; a++)
	{
		int id = m_pMaterial[m_pObject[a].usMatId].uiLayer0 - 1;
		char strPart[128] = {0};
		if(id < 0)
			sprintf(strPart, "g part_%d_notextures\n", a);
		else
			sprintf(strPart, "g part_%d_%s\n", a, m_pTexture[id].strName);

		bool bBackface = true;
		fprintf(pFile, strPart);
		for(unsigned int b = 0; b < m_pObject[a].uiCount; b++)
		{
			bBackface = !bBackface;
			unsigned int i0 = m_pIndex[m_pObject[a].uiStart + b] + m_pObject[a].uiBase + (m_pObject[a].uiBase1 / 32) + 1 + uiIndex;
			unsigned int i1 = m_pIndex[m_pObject[a].uiStart + b + 1] + m_pObject[a].uiBase + (m_pObject[a].uiBase1 / 32) + 1 + uiIndex;
			unsigned int i2 = m_pIndex[m_pObject[a].uiStart + b + 2] + m_pObject[a].uiBase + (m_pObject[a].uiBase1 / 32) + 1 + uiIndex;

			//unsigned int i0 = m_pIndex[m_pObject[a].uiStart + m_pObject[a].uiBase + b] + 1;
			//unsigned int i1 = m_pIndex[m_pObject[a].uiStart + m_pObject[a].uiBase + b + 1] + 1;
			//unsigned int i2 = m_pIndex[m_pObject[a].uiStart + m_pObject[a].uiBase + b + 2] + 1;
			if(bBackface)
				fprintf(pFile, "f %d/%d/%d %d/%d/%d %d/%d/%d\n", i0, i0, i0, i2, i2, i2, i1, i1, i1);
			else
				fprintf(pFile, "f %d/%d/%d %d/%d/%d %d/%d/%d\n", i0, i0, i0, i1, i1, i1, i2, i2, i2);
		}
		fprintf(pFile, "g\n\n");
	}
	fclose(pFile);

	printf("done\n");
	return true;
}

//+---------------------------------------------------------> 
