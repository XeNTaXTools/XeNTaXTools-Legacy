
#include "stage.h"

//+---------------------------------------------------------> cStage()
// default constructor

cStage::cStage()
{
}

//+---------------------------------------------------------> Delete()
// clears the stage data

void cStage::Delete()
{
	if(m_pTexture)
	{
		delete[] m_pTexture;
		m_pTexture = NULL;
	}
	if(m_pMaterial)
	{
		delete[] m_pMaterial;
		m_pMaterial = NULL;
	}
	if(m_pObject)
	{
		delete[] m_pObject;
		m_pObject = NULL;
	}
	if(m_pObject2)
	{
		delete[] m_pObject2;
		m_pObject2 = NULL;
	}
	if(m_pVertex)
	{
		delete[] m_pVertex;
		m_pVertex = NULL;
	}
	if(m_pIndex)
	{
		delete[] m_pIndex;
		m_pIndex = NULL;
	}
}

//+---------------------------------------------------------> Load()
// loads the designated stage model

bool cStage::Load(const char *strStage)
{
	// try to open the file
	FILE *pFile = fopen(strStage, "rb");
	if(!pFile)
	{
		printf("Can't open stage model [%s] !\n", strStage);
		return false;
	}

	// read the header info and check the signature
	fread(this, sizeof(cStage), 1, pFile);
	if(m_uiTag != 0x00444F4D)
	{
		printf("Invalid model file [%s] !!\n", strStage);
		fclose(pFile);
		return false;
	}
    
	// extract the filename without extensions, for example
	// "z:/devil may cry 4/scr/st002/stage/st002-m00-base.mod" will give
	// "st002-m00-base"
	strName[0] = '\0';
	for(unsigned int a = unsigned int(strlen(strStage) - 1); a > 0; a--)
	{
		if((strStage[a] == '\\') || (strStage[a] == '/'))
		{
			for(unsigned int b = a + 1; b < unsigned int(strlen(strStage)); b++)
			{
				if(strStage[b] == '.')
					break;
				strName[b - a - 1] = strStage[b];
			}
			strName[b - a - 1] = '\0';
			break;
		}
	}
	printf("[%s]\n", strName);
	printf("\tobjects: %d\n\tmaterials: %d\n\tverts: %d\n\tindices: %d\n\ttextures: %d\nreading data ... ", m_usObjectNum, m_usMaterialNum, m_uiVertexNum, m_uiIndexNum, m_uiTextureNum);

	// read the textures names
	m_pTexture = new cStageTexture[m_uiTextureNum];
	fseek(pFile, m_uiTextureOffset, SEEK_SET);
	fread(m_pTexture, sizeof(cStageTexture), m_uiTextureNum, pFile);

	// now read the materials
	m_pMaterial = new cStageMaterial[m_usMaterialNum];
	fread(m_pMaterial, sizeof(cStageMaterial), m_usMaterialNum, pFile);

	// read the objects
	m_pObject = new cStageObject[m_usObjectNum];
	fseek(pFile, m_uiObjectOffset, SEEK_SET);
	fread(m_pObject, sizeof(cStageObject), m_usObjectNum, pFile);

	// read a count which must be the same as the object count
	unsigned int uiCount = 0;
	fread(&uiCount, 4, 1, pFile);
	if(uiCount != unsigned int(m_usObjectNum))
	{
		printf("Object counts did not match !!\n");
		return false;
	}
	m_pObject2 = new cStageObject2[uiCount];
	fread(m_pObject2, sizeof(cStageObject2), uiCount, pFile);

	// read the vertex data
	m_pVertex = new cStageVertex[m_uiVertexNum];
	fseek(pFile, m_uiVertexOffset, SEEK_SET);
	fread(m_pVertex, sizeof(cStageVertex), m_uiVertexNum, pFile);

	// read the index data
	m_pIndex = new WORD[m_uiIndexNum];
	fseek(pFile, m_uiIndexOffset, SEEK_SET);
	fread(m_pIndex, 2, m_uiIndexNum, pFile);

	printf("done\n");
	return true;
}

//+---------------------------------------------------------> Export()
// exports the data into the .obj file

bool cStage::Export(const char *strStage)
{
	//------------------------------------------------------------------------------------> 
	FILE *pFile = fopen(strStage, "wt");
	printf("exporting data ... ");
	fprintf(pFile, "# %d verts\n", m_uiVertexNum);
	for(unsigned int a = 0; a < m_uiVertexNum; a++)
		fprintf(pFile, "v %f %f %f\n", m_pVertex[a].x / 10.0f, m_pVertex[a].y / 10.0f, m_pVertex[a].z / 10.0f);

	// U coords
	WORD *pUW = new WORD[m_uiVertexNum];
	for(unsigned int a = 0; a < m_uiVertexNum; a++)
		pUW[a] = m_pVertex[a].u0;
	D3DXFLOAT16 *pU = (D3DXFLOAT16*)pUW;
	float *pUF = new float[m_uiVertexNum];
	D3DXFloat16To32Array(pUF, pU, m_uiVertexNum);

	// V coords
	WORD *pVW = new WORD[m_uiVertexNum];
	for(unsigned int a = 0; a < m_uiVertexNum; a++)
		pVW[a] = m_pVertex[a].v0;
	D3DXFLOAT16 *pW = (D3DXFLOAT16*)pVW;
	float *pVF = new float[m_uiVertexNum];
	D3DXFloat16To32Array(pVF, pW, m_uiVertexNum);

	// export UV coords
	for(unsigned int a = 0; a < m_uiVertexNum; a++)
		fprintf(pFile, "vt %f %f %f\n", pUF[a], 1.0f - pVF[a], 0.5f);

	for(unsigned int a = 0; a < m_uiVertexNum; a++)
		fprintf(pFile, "vn %f %f %f\n", m_pVertex[a].nx / 128.0f, m_pVertex[a].ny / 128.0f, m_pVertex[a].nz / 128.0f);

	//m_usObjectNum = 1;
	for(a = 0; a < m_usObjectNum; a++)
	{
		bool bBackface = true;
		fprintf(pFile, "g %s_%d\n", strName, a);
		for(unsigned int b = 0; b < m_pObject[a].uiCount; b++)
		{
			bBackface = !bBackface;
			unsigned int i0 = m_pIndex[m_pObject[a].uiStart + b] + m_pObject[a].uiBase + (m_pObject[a].uiBase1 / 32) + 1;
			unsigned int i1 = m_pIndex[m_pObject[a].uiStart + b + 1] + m_pObject[a].uiBase + (m_pObject[a].uiBase1 / 32) + 1;
			unsigned int i2 = m_pIndex[m_pObject[a].uiStart + b + 2] + m_pObject[a].uiBase + (m_pObject[a].uiBase1 / 32) + 1;

			//unsigned int i0 = m_pIndex[m_pObject[a].uiStart + b] + m_pObject[a].uiBase + 1;
			//unsigned int i1 = m_pIndex[m_pObject[a].uiStart + b + 1] + m_pObject[a].uiBase + 1;
			//unsigned int i2 = m_pIndex[m_pObject[a].uiStart + b + 2] + m_pObject[a].uiBase + 1;
			//fprintf(pFile, "f %d/%d %d/%d %d/%d\n", i0, i0, i1, i1, i2, i2);
			if(bBackface)
				fprintf(pFile, "f %d/%d/%d %d/%d/%d %d/%d/%d\n", i0, i0, i0, i2, i2, i2, i1, i1, i1);
			else
				fprintf(pFile, "f %d/%d/%d %d/%d/%d %d/%d/%d\n", i0, i0, i0, i1, i1, i1, i2, i2, i2);
		}
		fprintf(pFile, "g\n\n");
	}
	fclose(pFile);
	printf("done\n");
	//------------------------------------------------------------------------------------> 

	// another way to export data
	////------------------------------------------------------------------------------------> 
	//FILE *pFile = fopen(strStage, "wt");
	//printf("exporting data ... ");

	//// go through the objects
	//unsigned int uiIndex = 1;
	//m_usObjectNum = 200;
	//for(unsigned short a = 0; a < m_usObjectNum; a++)
	//{
	//	// write the verts of this object
	//	for(unsigned int b = 0; b < m_pObject[a].uiCount + 2; b++)
	//	{
	//		//float x = m_pVertex[m_pIndex[m_pIndex[m_pObject[a].uiStart + b] + m_pObject[a].uiBase + (m_pObject[a].uiBase1 / 32)]].x;
	//		//float y = m_pVertex[m_pIndex[m_pIndex[m_pObject[a].uiStart + b] + m_pObject[a].uiBase + (m_pObject[a].uiBase1 / 32)]].y;
	//		//float z = m_pVertex[m_pIndex[m_pIndex[m_pObject[a].uiStart + b] + m_pObject[a].uiBase + (m_pObject[a].uiBase1 / 32)]].z;
	//		float x = m_pVertex[m_pIndex[m_pObject[a].uiStart + b] + m_pObject[a].uiBase + (m_pObject[a].uiBase1 / 32)].x;
	//		float y = m_pVertex[m_pIndex[m_pObject[a].uiStart + b] + m_pObject[a].uiBase + (m_pObject[a].uiBase1 / 32)].y;
	//		float z = m_pVertex[m_pIndex[m_pObject[a].uiStart + b] + m_pObject[a].uiBase + (m_pObject[a].uiBase1 / 32)].z;
	//		fprintf(pFile, "v %f %f %f\n", x, y, z);
	//	}

	//	for(unsigned int b = 0; b < m_pObject[a].uiCount + 2; b++)
	//	{
	//		float u = (float)(m_pVertex[m_pIndex[m_pObject[a].uiStart + b] + m_pObject[a].uiBase + (m_pObject[a].uiBase1 / 32)].u0 / 65536.0f);
	//		float v = (float)(m_pVertex[m_pIndex[m_pObject[a].uiStart + b] + m_pObject[a].uiBase + (m_pObject[a].uiBase1 / 32)].v0 / 65536.0f);

	//		fprintf(pFile, "vt %f %f %f\n", u, 1.0f - v, 0.5f);
	//	}

	//	//for(unsigned int b = 0; b < m_pObject[a].uiCount + 2; b++)
	//	//{
	//	//	float nx = m_pVertex[m_pIndex[m_pObject[a].uiStart + b] + m_pObject[a].uiBase + (m_pObject[a].uiBase1 / 32)].nx / 128.0f;
	//	//	float ny = m_pVertex[m_pIndex[m_pObject[a].uiStart + b] + m_pObject[a].uiBase + (m_pObject[a].uiBase1 / 32)].ny / 128.0f;
	//	//	float nz = m_pVertex[m_pIndex[m_pObject[a].uiStart + b] + m_pObject[a].uiBase + (m_pObject[a].uiBase1 / 32)].nz / 128.0f;
	//	//	fprintf(pFile, "vn %f %f %f\n", nx, ny, nz);
	//	//}

	//	// write the indices of this object
	//	int id = m_pMaterial[m_pObject[a].usMatId].uiLayer0 - 1;
	//	char strPart[128] = {0};
	//	if(id < 0)
	//		sprintf(strPart, "g part_%d_notextures\n", a);
	//	else
	//		sprintf(strPart, "g part_%d_%s\n", a, m_pTexture[id].strName);

	//	fprintf(pFile, strPart);
	//	for(b = 0; b < m_pObject[a].uiCount; b++)
	//	{
	//		int i0 = b + uiIndex;
	//		int i1 = b + uiIndex + 1;
	//		int i2 = b + uiIndex + 2;
	//		if((i0 != i1) && (i0 != i2) && (i1 != i2))
	//			fprintf(pFile, "f %d/%d %d/%d %d/%d\n", i0, i0, i1, i1, i2, i2);
	//	}
	//	fprintf(pFile, "g\n\n");
	//	uiIndex += m_pObject[a].uiCount + 2;
	//}
	//fclose(pFile);
	//printf("done\n");
	////------------------------------------------------------------------------------------> 

	return true;
}

//+---------------------------------------------------------> 
