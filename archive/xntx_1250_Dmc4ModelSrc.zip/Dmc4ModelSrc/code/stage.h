
#ifndef _STAGE_H
#define _STAGE_H

//+---------------------------------------------------------> Headers

#include "main.h"

//+---------------------------------------------------------> cTexture

struct cStageTexture
{
	char					strName[64];
};

//+---------------------------------------------------------> cMaterial

struct cStageMaterial
{
	unsigned int			uiUnknown[6];
	unsigned int			uiLayer0;			// tex0: base 1, 0 means no bind
	unsigned int			uiLayer1;			// tex1
	unsigned int			uiLayer2;			// tex2
	unsigned int			uiLayers[5];		// tex3 ... tex8
	float					fColors[26];		// ambient, diffuse, specular, shininess, ...
};

//+---------------------------------------------------------> cStageObject

struct cStageObject
{
	unsigned short			usId;				// id from the indes table
	unsigned short			usMatId;			// material Id
	unsigned short			usFlag[8];			// 0xFF01, 0, 32, ???
	unsigned int			uiBase1;			// base multiple of 32
	unsigned int			uiZero;
	unsigned int			uiStart;			// start index
	unsigned int			uiCount;			// faces (indices - 2)
	unsigned int			uiBase;
	unsigned int			uiInconnu[3];
};

//+---------------------------------------------------------> cStageObject2

struct cStageObject2
{
	unsigned int			uiId;				// 0xFFFFFFFF
	float					fFloat0[3];
	D3DXVECTOR4				vBSphere;			// center + radius
	D3DXVECTOR4				vBBoxMin;			// w component is unused
	D3DXVECTOR4				vBBoxMax;
	float					fFloat1[20];
};

//+---------------------------------------------------------> cVertex

struct cStageVertex
{
	//	0	D3DDECLTYPE_FLOAT3		POSITION
	//	12	D3DDECLTYPE_UBYTE4N		NORMAL
	//	16	D3DDECLTYPE_UBYTE4N		TANGENT
	//	20	D3DDECLTYPE_FLOAT16_2	TEXCOORD
	//	24	D3DDECLTYPE_FLOAT16_2	TEXCOORD
	//	28	D3DDECLTYPE_FLOAT16_2	TEXCOORD
	float	x, y, z;
	BYTE	nx, ny, nz, nw;	// /= 255.0f
	BYTE	tx, ty, tz, tw;	// /= 255.0f
	short	u0, v0;
	short	u1, v1;
	short	u2, v2;
};

//+---------------------------------------------------------> cStage

class cStage
{
public:
							cStage();

	bool					Load(const char *strStage);
	bool					Export(const char *strStage);
	void					Delete();

private:

	unsigned int			m_uiTag;			// "MOD"
	unsigned short			m_usVersion;		// 0x99
	unsigned short			m_usBoneNum;		// 0 for stages
	unsigned short			m_usObjectNum;		// object count
	unsigned short			m_usMaterialNum;	// material count
	unsigned int			m_uiVertexNum;		// vertex count
	unsigned int			m_uiIndexNum;		// index count
	unsigned int			m_uiIII1;
	unsigned int			m_uiVertexDataSize;	// in bytes of course
	unsigned int			m_uiIII2;			// usually 0;
	unsigned int			m_uiTextureNum;		// texture count
	unsigned int			m_uiIII3;			// sometimes matches the first bone count
	unsigned int			m_uiIII4;
	unsigned int			m_uiBoneOffset;		// usually 144
	unsigned int			m_uiBoneOffset2;
	unsigned int			m_uiTextureOffset;
	unsigned int			m_uiObjectOffset;
	unsigned int			m_uiVertexOffset;
	unsigned int			m_uiIII5;			// 0
	unsigned int			m_uiIndexOffset;
	unsigned int			m_uiIII6;			// 0
	unsigned int			m_uiIII7;			// 0
	D3DXVECTOR4				m_vBSphere;			// bounding sphere: center + radius
	D3DXVECTOR4				m_vBBoxMin;
	D3DXVECTOR4				m_vBBoxMax;			// bounding box, w components are unused
	unsigned int			m_uiIII8[4];		// always 1000, 3000, 2 and a float
	D3DXVECTOR4				m_vBSphere000;
	D3DXVECTOR4				m_vBSphere2;		// second boudnig sphere

	char					strName[64];

	cStageTexture			*m_pTexture;
	cStageMaterial			*m_pMaterial;
	cStageObject			*m_pObject;
	cStageObject2			*m_pObject2;
	cStageVertex			*m_pVertex;
	WORD					*m_pIndex;
};

#endif