#Noesis Python model import+export test module, imports/exports some data from/to a made-up format

from inc_noesis import *

import noesis

#rapi methods should only be used during handler callbacks
import rapi

#registerNoesisTypes is called by Noesis to allow the script to register formats.
#Do not implement this function in script files unless you want them to be dedicated format modules!
def registerNoesisTypes():
   handle = noesis.register("One Piece Burning Blood", ".srdi")
   noesis.setHandlerTypeCheck(handle, noepyCheckType)
   noesis.setHandlerLoadModel(handle, noepyLoadModel) #see also noepyLoadModelRPG
       #noesis.setHandlerWriteModel(handle, noepyWriteModel)
       #noesis.setHandlerWriteAnim(handle, noepyWriteAnim)
   noesis.logPopup()
       #print("The log can be useful for catching debug prints from preview loads.\nBut don't leave it on when you release your script, or it will probably annoy people.")
   return 1
  
def noepyCheckType(data):
   bs = NoeBitStream(data)
   if len(data) < 2:
      return 0
   return 1   
	
def noepyLoadModel(data, mdlList):
	ctx = rapi.rpgCreateContext()
	bs = NoeBitStream(data)
	parser = SanaeParser(data)
	parser.parse_mesh(0)
	#srdi = rapi.rpgConstructModel()
	#mdlList.append(srdi)
	return 1
	
class SanaeParser(object):		
      def __init__(self, data):
         self.inFile = NoeBitStream(data)
         self.dirpath = rapi.getDirForFilePath(rapi.getInputName())

      def parse_mesh(self, data):
         self.inFile.seek(data, 0)
         vertBuff = bytes()
         uvBuff = bytes()
         triBuff = bytes()
         arr = int()
         numVerts = 0
         self.inFile.seek(68256, 0)
         for i in range(0, 2088):
            a = self.inFile.readShort()
            if a not in arr:
               arr.append(a)
         numVerts = len(arr)
         self.inFile.seek(data, 0)
         #print(numVerts)
         #for i in range(0, numVerts):
	 #numFaces = ??
