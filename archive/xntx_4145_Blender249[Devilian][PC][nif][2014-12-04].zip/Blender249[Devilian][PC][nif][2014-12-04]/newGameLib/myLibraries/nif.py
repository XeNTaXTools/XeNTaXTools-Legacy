


import nifLib.NiFooter
reload(nifLib.NiFooter)
from nifLib.NiFooter import *		
	

import nifLib.NiZBufferProperty
#reload(nifLib.NiZBufferProperty)
from nifLib.NiZBufferProperty import *	

import nifLib.NiVertexColorProperty
#reload(nifLib.NiVertexColorProperty)
from nifLib.NiVertexColorProperty import *	

import nifLib.NiStringExtraData
#reload(nifLib.NiStringExtraData)
from nifLib.NiStringExtraData import *		

import nifLib.NiMultiTargetTransformController
#reload(nifLib.NiMultiTargetTransformController)
from nifLib.NiMultiTargetTransformController import *

import nifLib.NiTransformController
#reload(nifLib.NiTransformController)
from nifLib.NiTransformController import *		

import nifLib.NiCollisionData
#reload(nifLib.NiCollisionData)
from nifLib.NiCollisionData import *			

import nifLib.NiFloatExtraData
#reload(nifLib.NiFloatExtraData)
from nifLib.NiFloatExtraData import *					

import nifLib.NiIntegerExtraData
#reload(nifLib.NiIntegerExtraData)
from nifLib.NiIntegerExtraData import *				

import nifLib.NiFloatsExtraData
#reload(nifLib.NiFloatsExtraData)
from nifLib.NiFloatsExtraData import *				

import nifLib.NiMaterialProperty
#reload(nifLib.NiMaterialProperty)
from nifLib.NiMaterialProperty import *					

import nifLib.NiTriShapeData
#reload(nifLib.NiTriShapeData)
from nifLib.NiTriShapeData import *							

import nifLib.NiSkinPartition
#reload(nifLib.NiSkinPartition)
from nifLib.NiSkinPartition import *							

import nifLib.NiAlphaProperty
#reload(nifLib.NiAlphaProperty)
from nifLib.NiAlphaProperty import *								

import nifLib.NiStencilProperty
#reload(nifLib.NiStencilProperty)
from nifLib.NiStencilProperty import *										

import nifLib.NiFlipController
#reload(nifLib.NiFlipController)
from nifLib.NiFlipController import *											

import nifLib.NiFloatInterpolator
#reload(nifLib.NiFloatInterpolator)
from nifLib.NiFloatInterpolator import *											

import nifLib.NiFloatData
#reload(nifLib.NiFloatData)
from nifLib.NiFloatData import *												

import nifLib.NiDirectionalLight
#reload(nifLib.NiDirectionalLight)
from nifLib.NiDirectionalLight import *				
													

import nifLib.NiBooleanExtraData
#reload(nifLib.NiBooleanExtraData)
from nifLib.NiBooleanExtraData import *	

import nifLib.NiTransformInterpolator
#reload(nifLib.NiTransformInterpolator)
from nifLib.NiTransformInterpolator import *	

import nifLib.NiBoneLODController
#reload(nifLib.NiBoneLODController)
from nifLib.NiBoneLODController import *			

import nifLib.NiAmbientLight
#reload(nifLib.NiAmbientLight)
from nifLib.NiAmbientLight import *					

import nifLib.NiTransformData
#reload(nifLib.NiTransformData)
from nifLib.NiTransformData import *					

import nifLib.NiVertexColorProperty
#reload(nifLib.NiVertexColorProperty)
from nifLib.NiVertexColorProperty import *					

import nifLib.NiShadeProperty
#reload(nifLib.NiShadeProperty)
from nifLib.NiShadeProperty import *						

import nifLib.NiSpecularProperty
#reload(nifLib.NiSpecularProperty)
from nifLib.NiSpecularProperty import *		

		
		
class Nif:
	def __init__(self):
		self.version=None
		self.endian=None
		self.versionAsString=None
		self.versionAsNumbers=None
		self.userVersion=None
		self.input=None
		self.meshList=[]
		self.stringList=[]
		self.nodeSizeList=[]
		self.offsetset=None
		self.nodeTypeList=[]
		self.nodeIDList=[]
		self.skeleton=None
		self.levelID=0
		self.nodeList=[]
		self.debug=False
		self.PARSINGFLAG=True
		self.nifFormatListNew=[(103,95,97,115),\
							   (3,0,1,30),\
							   (9,0,3,20),\
							   (3,0,1,30),\
							   (0,0,6,20),\
							   (1,0,6,20),\
							   (2,0,6,20),\
							   (7,0,2,20),\
							   (0,0,5,20),\
							   (8,0,2,20)]
		self.nifFormatListOld=[(4,0,0,20),(0,0,2,10)]
		
	
		
	def show(self,nodeID,levelID):	
		if self.debug==True:
			nodeType=self.nodeTypeList[self.nodeIDList[nodeID]]
			size=self.nodeSizeList[nodeID]
			print '-'*levelID,nodeID,nodeType,size
		
	
	def getNodeOffset(self,ID):
		self.input.debug=False
		here = self.input.tell()
		self.input.seek(self.offset)
		for m in range(ID): 
			back = self.input.tell()
			self.input.seek(back+self.nodeSizeList[m])
		offsetset = self.input.tell()
		self.input.seek(here) 
		return offsetset   
		
	def explore(self):
		#print 'explore'
		self.versionAsString =self.input.find('\x0A')
		self.versionAsNumbers=self.input.B(4)
		if self.versionAsNumbers!=(0,0,2,10):
			self.endian=self.input.B(1)[0]
		self.userVersion=self.input.i(1)[0]
		if self.debug==True:	
			print self.versionAsString
			print 'userVersion:',self.userVersion
			print 'endian:',self.endian
		print self.versionAsNumbers
		self.NifVersion()	
		
	def NifParser(self):
		g=self.input
		#print 'tell:',self.input.tell()
		nNodes = self.input.i(1)[0]
		if self.endian==0:
			self.input.endian='>'
		if self.debug==True:
			print 'nNodes:',nNodes
		if self.userVersion==12:
			self.input.i(1)
			self.input.find('\x00')
			self.input.find('\x00')
			self.input.find('\x00')
		if self.versionAsNumbers==(3,0,1,30):
			self.input.seek(4,1)
			stringCount=self.input.i(1)[0]
		else:
			stringCount=self.input.H(1)[0]
		if self.debug==True:print 'stringCount:',stringCount	
		for m in range(stringCount):
			NodeType = self.input.word(self.input.i(1)[0])
			if self.debug==True:print NodeType
			NodeType = NodeType.replace('\x01','')
			self.nodeTypeList.append(NodeType)
		for i in range(nNodes):	
			if self.input.endian=='<':
				self.nodeIDList.append(self.input.B(1)[0])
				self.input.B(1)[0]
			if self.input.endian=='>':
				self.input.B(1)[0]
				self.nodeIDList.append(self.input.B(1)[0])
		
		if self.versionAsNumbers in self.nifFormatListNew:
			self.nodeSizeList = self.input.i(nNodes)
			counts = self.input.i(2)
			#print counts
			for m in range(counts[0]):
				string=self.input.read(self.input.i(1)[0])
				self.stringList.append(string)
				#print string
		self.input.i(1)[0]
		self.offset=self.input.tell()
		
		if self.versionAsNumbers in self.nifFormatListNew:
			for ID in range(nNodes):
				t=self.input.tell()
				self.input.seek(t+self.nodeSizeList[ID])
			NiFooter(self)	
		
		if self.versionAsNumbers in self.nifFormatListOld:
			levelID=0
			self.skeleton=Skeleton()
			#self.skeleton.name=self.input.basename
			self.skeleton.ARMATURESPACE=True
			for ID in range(nNodes):
				nodeStart=self.input.tell()
				nodeType = self.nodeTypeList[self.nodeIDList[ID]]
				if nodeType=='NiNode':
					#pm(['NiNode'],self.levelID)
					
					NiNode(self,levelID,'',Matrix())
				elif nodeType=='NiDirectionalLight':NiDirectionalLight(self)
				elif nodeType=='NiZBufferProperty':NiZBufferProperty(self)
				elif nodeType=='NiVertexColorProperty':NiVertexColorProperty(self)
				elif nodeType=='NiSpecularProperty':NiSpecularProperty(self)
				elif nodeType=='NiShadeProperty':NiShaderProperty(self)
				elif nodeType=='NiStringExtraData':NiStringExtraData(self)
				elif nodeType=='NiTriShape':NiTriShape(self,levelID,Matrix())
				elif nodeType=='NiIntegerExtraData':NiIntegerExtraData(self)
				elif nodeType=='NiBooleanExtraData':NiBooleanExtraData(self)
				elif nodeType=='NiTexturingProperty':NiTexturingProperty(self,levelID)
				elif nodeType=='NiSourceTexture':NiSourceTexture(self,levelID)
				elif nodeType=='NiPixelData':NiPixelData(self,levelID)
				elif nodeType=='NiAlphaProperty':NiAlphaProperty(self)
				elif nodeType=='NiMaterialProperty':NiMaterialProperty(self)
				elif nodeType=='NiStencilProperty':NiStencilProperty(self)
				elif nodeType=='NiTriShapeData':
					mesh=Mesh()
					NiTriShapeData(self,mesh,levelID)
				elif nodeType=='NiSkinInstance':NiSkinInstance(self,levelID)
				elif nodeType=='NiSkinData':NiSkinData(self)
				elif nodeType=='NiSkinPartition':NiSkinPartition(self)
				elif nodeType=='NiCollisionData':NiCollisionData(self)
				elif nodeType=='NiTransformController':NiTransformController(self)
				elif nodeType=='NiTransformInterpolator':NiTransformInterpolator(self)
				elif nodeType=='NiTransformData':NiTransformData(self)
				elif nodeType=='NiMultiTargetTransformController':NiMultiTargetTransformController(self)
				elif nodeType=='NiBoneLODController':NiBoneLODController(self)
				elif nodeType=='NiAmbientLight':NiAmbientLight(self)
				elif nodeType=='NiCamera':NiCamera(self)
				elif nodeType=='NiFloatExtraData':NiFloatExtraData(self)
				elif nodeType=='NiFloatsExtraData':NiFloatsExtraData(self)
				elif nodeType=='NiFlipController':NiFlipController(self)
				elif nodeType=='NiFloatInterpolator':NiFloatInterpolator(self)
				elif nodeType=='NiFloatData':NiFloatData(self)
				else:
					print 'WARNING:',ID,nodeType
					break
				nodeEnd=self.input.tell()
				self.nodeSizeList.append(nodeEnd-nodeStart)
				#if self.parse==True:
				#	print ID,nodeType,' start at:',nodeStart,' size:',nodeEnd-nodeStart
			NiFooter(self)		
		
		
	def NifVersion(self):	
		g=self.input	
		if self.versionAsNumbers==(8,0,2,20):
			self.NifParser()
			
		elif self.versionAsNumbers==(4,0,0,20):
			self.NifParser()
			
		elif self.versionAsNumbers==(0,0,2,10):
			self.NifParser()
			
		elif self.versionAsNumbers==(0,0,5,20):
			#g.debug=True
			g.seek(-1,1)
			#print g.H(3)
			#g.seek(4,1)	
			#g.H(2),g.B(1)####################################
			nNodes = g.H(1)[0]+g.H(1)[0]
			
			if self.endian==0:
				self.input.endian='>'
			g.B(1)
			#g.i(1)
			for m in range(g.H(1)[0]):
				NodeType = g.word(g.i(1)[0])
				NodeType = NodeType.replace('\x01','')
				self.nodeTypeList.append(NodeType)
			
			self.nodeIDList = g.H(nNodes)
			self.nodeSizeList = g.i(nNodes)
			counts = g.i(2)
			stringList = []
			for m in range(counts[0]):
				self.stringList.append(g.word(g.i(1)[0]))
			g.i(1)
			self.offset=self.input.tell()
		
			for ID in range(nNodes):
				t=self.input.tell()
				self.input.seek(t+self.nodeSizeList[ID])
			NiFooter(self)	
			
			
		elif self.versionAsNumbers==(0,0,2,107):#Shadow Harvest
			self.NifParser()
			
		elif self.versionAsNumbers==(103,95,97,115):
			self.NifParser()
			
		elif self.versionAsNumbers==(9,0,3,20,):
			self.NifParser()
			
		elif self.versionAsNumbers==(7,0,2,20):
			self.NifParser()
			
		elif self.versionAsNumbers==(7,0,2,20):
			self.NifParser()
			
		elif self.versionAsNumbers==(0,0,6,20):#Catherine
			self.NifParser()
			
		elif self.versionAsNumbers==(1,0,6,20):#Devilon
			self.NifParser()
			
		elif self.versionAsNumbers==(2,0,6,20):#Devilon
			self.NifParser()
			
		elif self.versionAsNumbers==(3,0,1,30):#Dance on Broadway
			g.seek(-1,1)
			#print g.H(3)
			#g.seek(4,1)	
			#g.H(2),g.B(1)####################################
			nNodes = g.H(1)[0]+g.H(1)[0]
			if self.endian==0:
				self.input.endian='>'
			g.B(1)
			g.i(1)
			for m in range(g.H(1)[0]):
				NodeType = g.read(g.i(1)[0])
				NodeType = NodeType.replace('\x01','')
				self.nodeTypeList.append(NodeType)
			
			self.nodeIDList = g.H(nNodes)
			self.nodeSizeList = g.i(nNodes)
			counts = g.i(2)
			stringList = []
			for m in range(counts[0]):
				self.stringList.append(g.read(g.i(1)[0]))
			g.i(1)
			self.offset=self.input.tell()
		
			for ID in range(nNodes):
				t=self.input.tell()
				self.input.seek(t+self.nodeSizeList[ID])
			NiFooter(self)	
			
			
		else:
			print 'WARNING: unknow nif version',versionAsNumbers	
		