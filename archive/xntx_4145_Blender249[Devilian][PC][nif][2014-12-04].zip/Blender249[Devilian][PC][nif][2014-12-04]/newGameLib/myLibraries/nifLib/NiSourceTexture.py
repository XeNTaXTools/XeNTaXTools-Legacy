import NiPixelData
reload(NiPixelData)
from NiPixelData import *

def NiSourceTexture(self,levelID):
	texPath=None
	
	if self.versionAsNumbers==(0,0,5,20):
		texPath=None
		levelID+=4
		g=self.input
		id=g.i(1)[0]
		if id!=-1:
			if self.versionAsNumbers in self.nifFormatListOld:name=g.word(id)
			if self.versionAsNumbers in self.nifFormatListNew:name=self.stringList[id]
		else:
			name=None
		back = g.tell()
		#g.seek(offset)
		for n in range(g.i(1)[0]):g.i(1)
		g.i(1)[0]
		useExternal = g.B(1)[0]
		if self.debug==True:
			print '-'*levelID,'use external:',useExternal
		if self.versionAsNumbers in self.nifFormatListOld:name=g.word(g.i(1)[0])
		if self.versionAsNumbers in self.nifFormatListNew:name=self.stringList[g.i(1)[0]]
		texPath=name
		if self.debug==True:
			print '-'*levelID,name
			
		if useExternal ==1:
			#texDir=g.dirname.replace('model','texture')
			#mat.diffuse=name
			nodeID = g.i(1)[0]
			if nodeID!=-1:
				nodeType = self.nodeTypeList[self.nodeIDList[nodeID]]
				if self.debug==True:
					print '-'*levelID,nodeID,nodeType
		else:	
			nodeID = g.i(1)[0] 
			nodeType = self.nodeTypeList[self.nodeIDList[nodeID]]
			if self.debug==True:
				print '-'*levelID,nodeID,nodeType
			if nodeType == 'NiPixelData':
				if self.PARSINGFLAG==False:
					offset = self.getNodeOffset(nodeID)
					back=g.tell()
					g.seek(offset)
					image=NiPixelData(self,levelID)
					image.name=g.dirname+os.sep+name
					image.draw()
					texPath=image.name
					g.seek(back)
			
		#g.seek(back)
		#if self.versionAsNumbers==(4,0,0,20):
		if self.versionAsNumbers in self.nifFormatListOld:g.i(3),g.B(2)
		if self.versionAsNumbers in self.nifFormatListNew:g.i(3),g.B(3)
	
	
	
	elif self.versionAsNumbers==(0,0,6,20):
		texPath=None
		levelID+=4
		g=self.input
		#g.debug=True
		id=g.i(1)[0]
		if id!=-1:
			if self.versionAsNumbers in self.nifFormatListOld:name=g.word(id)
			if self.versionAsNumbers in self.nifFormatListNew:name=self.stringList[id]
		else:
			name=None
		back = g.tell()
		#g.seek(offset)
		for n in range(g.i(1)[0]):g.i(1)
		g.i(1)[0]
		useExternal = g.B(1)[0]
		if self.debug==True:
			print '-'*levelID,'use external:',useExternal
		if self.versionAsNumbers in self.nifFormatListOld:name=g.word(g.i(1)[0])
		if self.versionAsNumbers in self.nifFormatListNew:name=self.stringList[g.i(1)[0]]
		texPath=name
		if self.debug==True:
			print '-'*levelID,name
			
		if useExternal ==1:
			#texDir=g.dirname.replace('model','texture')
			#mat.diffuse=name
			nodeID = g.i(1)[0]
			if nodeID!=-1:
				nodeType = self.nodeTypeList[self.nodeIDList[nodeID]]
				if self.debug==True:
					print '-'*levelID,nodeID,nodeType
		else:	
			nodeID = g.i(1)[0] 
			nodeType = self.nodeTypeList[self.nodeIDList[nodeID]]
			if self.debug==True:
				print '-'*levelID,nodeID,nodeType
			if nodeType == 'NiPixelData':
				if self.PARSINGFLAG==False:
					offset = self.getNodeOffset(nodeID)
					back=g.tell()
					g.seek(offset)
					image=NiPixelData(self,levelID)
					image.name=g.dirname+os.sep+name
					image.draw()
					texPath=image.name
					g.seek(back)
			
		#g.seek(back)
		#if self.versionAsNumbers==(4,0,0,20):
		if self.versionAsNumbers in self.nifFormatListOld:g.i(3),g.B(2)
		if self.versionAsNumbers in self.nifFormatListNew:g.i(3),g.B(3)
		#g.debug=False
		
	elif self.versionAsNumbers==(4,0,0,20):
		texPath=None
		levelID+=4
		g=self.input
		id=g.i(1)[0]
		if id!=-1:
			if self.versionAsNumbers in self.nifFormatListOld:name=g.word(id)
			if self.versionAsNumbers in self.nifFormatListNew:name=self.stringList[id]
		else:
			name=None
		back = g.tell()
		#g.seek(offset)
		for n in range(g.i(1)[0]):g.i(1)
		g.i(1)[0]
		useExternal = g.B(1)[0]
		if self.debug==True:
			print '-'*levelID,'use external:',useExternal
		if self.versionAsNumbers in self.nifFormatListOld:name=g.word(g.i(1)[0])
		if self.versionAsNumbers in self.nifFormatListNew:name=self.stringList[g.i(1)[0]]
		texPath=name
		if self.debug==True:
			print '-'*levelID,name
			
		if useExternal ==1:
			#texDir=g.dirname.replace('model','texture')
			#mat.diffuse=name
			nodeID = g.i(1)[0]
			if nodeID!=-1:
				nodeType = self.nodeTypeList[self.nodeIDList[nodeID]]
				if self.debug==True:
					print '-'*levelID,nodeID,nodeType
		else:	
			nodeID = g.i(1)[0] 
			nodeType = self.nodeTypeList[self.nodeIDList[nodeID]]
			if self.debug==True:
				print '-'*levelID,nodeID,nodeType
			if nodeType == 'NiPixelData':
				if self.PARSINGFLAG==False:
					offset = self.getNodeOffset(nodeID)
					back=g.tell()
					g.seek(offset)
					image=NiPixelData(self,levelID)
					image.name=g.dirname+os.sep+name
					image.draw()
					texPath=image.name
					g.seek(back)
			
		#g.seek(back)
		#if self.versionAsNumbers==(4,0,0,20):
		if self.versionAsNumbers in self.nifFormatListOld:g.i(3),g.B(2)
		if self.versionAsNumbers in self.nifFormatListNew:g.i(3),g.B(3)
		
	elif self.versionAsNumbers==(0,0,2,10):
		texPath=None
		levelID+=4
		g=self.input
		id=g.i(1)[0]
		if id!=-1:
			if self.versionAsNumbers in self.nifFormatListOld:name=g.word(id)
			if self.versionAsNumbers in self.nifFormatListNew:name=self.stringList[id]
		else:
			name=None
		back = g.tell()
		#g.seek(offset)
		for n in range(g.i(1)[0]):g.i(1)
		g.i(1)[0]
		useExternal = g.B(1)[0]
		print 'useexternal:',useExternal
		if self.versionAsNumbers in self.nifFormatListOld:name=g.word(g.i(1)[0])
		if self.versionAsNumbers in self.nifFormatListNew:name=self.stringList[g.i(1)[0]]
		texPath=name
		if useExternal ==1:
			#texDir=g.dirname.replace('model','texture')
			#mat.diffuse=name
			nodeID = g.i(1)[0]
			if nodeID!=-1:
				nodeType = self.nodeTypeList[self.nodeIDList[nodeID]]
				if self.debug==True:
					print '-'*levelID,nodeID,nodeType
		else:	
			nodeID = g.i(1)[0] 
			#print nodeID
			nodeType = self.nodeTypeList[self.nodeIDList[nodeID]]
			if nodeType == 'NiPixelData':
				pass
				"""offset = self.getNodeOffset(nodeID)
				back=g.tell()
				g.seek(offset)
				NiPixelData(self,levelID)
				g.seek(back)"""
				"""if texType=='diffuse':
					NiPixelData(self,offset,mat,levelID)
					#mat.diffuse=imageName
				if texType=='normal':
					NiPixelData(self,offset,mat,levelID)
					#mat.normal=imageName
				if texType=='specular':
					NiPixelData(self,offset,mat,levelID)
					#mat.specular=imageName"""
			
		#g.seek(back)
		#if self.versionAsNumbers==(4,0,0,20):
		if self.versionAsNumbers in self.nifFormatListOld:g.i(3),g.B(2)
		if self.versionAsNumbers in self.nifFormatListNew:g.i(3),g.B(3)
		
	elif self.versionAsNumbers==(9,0,3,20):
		texPath=None
		levelID+=4
		g=self.input
		id=g.i(1)[0]
		if id!=-1:
			if self.versionAsNumbers in self.nifFormatListOld:name=g.word(id)
			if self.versionAsNumbers in self.nifFormatListNew:name=self.stringList[id]
		else:
			name=None
		back = g.tell()
		#g.seek(offset)
		for n in range(g.i(1)[0]):g.i(1)
		g.i(1)[0]
		useExternal = g.B(1)[0]
		if self.versionAsNumbers in self.nifFormatListOld:name=g.word(g.i(1)[0])
		if self.versionAsNumbers in self.nifFormatListNew:name=self.stringList[g.i(1)[0]]
		texPath=name
		if useExternal ==1:
			#texDir=g.dirname.replace('model','texture')
			#mat.diffuse=name
			nodeID = g.i(1)[0]
			if nodeID!=-1:
				nodeType = self.nodeTypeList[self.nodeIDList[nodeID]]
				if self.debug==True:
					print '-'*levelID,nodeID,nodeType
		else:	
			nodeID = g.i(1)[0] 
			#print nodeID
			nodeType = self.nodeTypeList[self.nodeIDList[nodeID]]
			if nodeType == 'NiPixelData':
				offset = self.getNodeOffset(nodeID)
				back=g.tell()
				g.seek(offset)
				#NiPixelData(self,levelID)
				g.seek(back)
				"""if texType=='diffuse':
					NiPixelData(self,offset,mat,levelID)
					#mat.diffuse=imageName
				if texType=='normal':
					NiPixelData(self,offset,mat,levelID)
					#mat.normal=imageName
				if texType=='specular':
					NiPixelData(self,offset,mat,levelID)
					#mat.specular=imageName"""
			
		#g.seek(back)
		#if self.versionAsNumbers==(4,0,0,20):
		if self.versionAsNumbers in self.nifFormatListOld:g.i(3),g.B(2)
		if self.versionAsNumbers in self.nifFormatListNew:g.i(3),g.B(3)
		
	elif self.versionAsNumbers==(103,95,97,115):
		levelID+=4
		g=self.input
		id=g.i(1)[0]
		if id!=-1:
			if self.versionAsNumbers in self.nifFormatListOld:name=g.word(id)
			if self.versionAsNumbers in self.nifFormatListNew:name=self.stringList[id]
		else:
			name=None
		back = g.tell()
		for n in range(g.i(1)[0]):g.i(1)
		g.i(1)[0]
		useExternal = g.B(1)[0]
		print 'useExternal:',useExternal
		if self.versionAsNumbers in self.nifFormatListOld:name=g.word(g.i(1)[0])
		if self.versionAsNumbers in self.nifFormatListNew:name=self.stringList[g.i(1)[0]]
		texPath=name
		print 'texPath:',texPath
		if useExternal ==1:
			#texDir=g.dirname.replace('model','texture')
			#mat.diffuse=name
			nodeID = g.i(1)[0]
			if nodeID!=-1:
				nodeType = self.nodeTypeList[self.nodeIDList[nodeID]]
				if self.debug==True:
					print '-'*levelID,nodeID,nodeType
		else:	
			nodeID = g.i(1)[0] 
			#print nodeID
			nodeType = self.nodeTypeList[self.nodeIDList[nodeID]]
			if nodeType == 'NiPixelData':
				offset = self.getNodeOffset(nodeID)
				back=g.tell()
				g.seek(offset)
				NiPixelData(self,levelID)
				g.seek(back)
				"""if texType=='diffuse':
					NiPixelData(self,offset,mat,levelID)
					#mat.diffuse=imageName
				if texType=='normal':
					NiPixelData(self,offset,mat,levelID)
					#mat.normal=imageName
				if texType=='specular':
					NiPixelData(self,offset,mat,levelID)
					#mat.specular=imageName"""
			
		#g.seek(back)
		#if self.versionAsNumbers==(4,0,0,20):
		if self.versionAsNumbers in self.nifFormatListOld:g.i(3),g.B(2)
		if self.versionAsNumbers in self.nifFormatListNew:g.i(3),g.B(3)

	elif self.versionAsNumbers==(8,0,2,20):
		levelID+=4
		g=self.input
		id=g.i(1)[0]
		if id!=-1:
			if self.versionAsNumbers in self.nifFormatListOld:name=g.word(id)
			if self.versionAsNumbers in self.nifFormatListNew:name=self.stringList[id]
		else:
			name=None
		back = g.tell()
		for n in range(g.i(1)[0]):g.i(1)
		g.i(1)[0]
		useExternal = g.B(1)[0]
		print 'useExternal:',useExternal
		if self.versionAsNumbers in self.nifFormatListOld:name=g.word(g.i(1)[0])
		if self.versionAsNumbers in self.nifFormatListNew:name=self.stringList[g.i(1)[0]]
		texPath=name
		print 'texPath:',texPath
		if useExternal ==1:
			#texDir=g.dirname.replace('model','texture')
			#mat.diffuse=name
			nodeID = g.i(1)[0]
			if nodeID!=-1:
				nodeType = self.nodeTypeList[self.nodeIDList[nodeID]]
				if self.debug==True:
					print '-'*levelID,nodeID,nodeType
		else:	
			nodeID = g.i(1)[0] 
			#print nodeID
			nodeType = self.nodeTypeList[self.nodeIDList[nodeID]]
			if nodeType == 'NiPixelData':
				offset = self.getNodeOffset(nodeID)
				back=g.tell()
				g.seek(offset)
				NiPixelData(self,levelID)
				g.seek(back)
				"""if texType=='diffuse':
					NiPixelData(self,offset,mat,levelID)
					#mat.diffuse=imageName
				if texType=='normal':
					NiPixelData(self,offset,mat,levelID)
					#mat.normal=imageName
				if texType=='specular':
					NiPixelData(self,offset,mat,levelID)
					#mat.specular=imageName"""
			
		#g.seek(back)
		#if self.versionAsNumbers==(4,0,0,20):
		if self.versionAsNumbers in self.nifFormatListOld:g.i(3),g.B(2)
		if self.versionAsNumbers in self.nifFormatListNew:g.i(3),g.B(3)
	
	elif self.versionAsNumbers==(1,0,6,20):
		texPath=None
		levelID+=4
		g=self.input
		#g.debug=True
		id=g.i(1)[0]
		if id!=-1:
			if self.versionAsNumbers in self.nifFormatListOld:name=g.word(id)
			if self.versionAsNumbers in self.nifFormatListNew:name=self.stringList[id]
		else:
			name=None
		back = g.tell()
		#g.seek(offset)
		for n in range(g.i(1)[0]):g.i(1)
		g.i(1)[0]
		useExternal = g.B(1)[0]
		if self.debug==True:
			print '-'*levelID,'use external:',useExternal
		if self.versionAsNumbers in self.nifFormatListOld:name=g.word(g.i(1)[0])
		if self.versionAsNumbers in self.nifFormatListNew:name=self.stringList[g.i(1)[0]]
		texPath=name
		if self.debug==True:
			print '-'*levelID,name
			
		if useExternal ==1:
			#texDir=g.dirname.replace('model','texture')
			#mat.diffuse=name
			nodeID = g.i(1)[0]
			if nodeID!=-1:
				nodeType = self.nodeTypeList[self.nodeIDList[nodeID]]
				if self.debug==True:
					print '-'*levelID,nodeID,nodeType
		else:	
			nodeID = g.i(1)[0] 
			nodeType = self.nodeTypeList[self.nodeIDList[nodeID]]
			if self.debug==True:
				print '-'*levelID,nodeID,nodeType
			if nodeType == 'NiPixelData':
				if self.PARSINGFLAG==False:
					offset = self.getNodeOffset(nodeID)
					back=g.tell()
					g.seek(offset)
					image=NiPixelData(self,levelID)
					image.name=g.dirname+os.sep+name
					image.draw()
					texPath=image.name
					g.seek(back)
			
		#g.seek(back)
		#if self.versionAsNumbers==(4,0,0,20):
		if self.versionAsNumbers in self.nifFormatListOld:g.i(3),g.B(2)
		if self.versionAsNumbers in self.nifFormatListNew:g.i(3),g.B(3)
		#g.debug=False

		
	elif self.versionAsNumbers==(2,0,6,20):
		texPath=None
		levelID+=4
		g=self.input
		#g.debug=True
		id=g.i(1)[0]
		if id!=-1:
			if self.versionAsNumbers in self.nifFormatListOld:name=g.word(id)
			if self.versionAsNumbers in self.nifFormatListNew:name=self.stringList[id]
		else:
			name=None
		back = g.tell()
		#g.seek(offset)
		for n in range(g.i(1)[0]):g.i(1)
		g.i(1)[0]
		useExternal = g.B(1)[0]
		if self.debug==True:
			print '-'*levelID,'use external:',useExternal
		if self.versionAsNumbers in self.nifFormatListOld:name=g.word(g.i(1)[0])
		if self.versionAsNumbers in self.nifFormatListNew:name=self.stringList[g.i(1)[0]]
		texPath=name
		if self.debug==True:
			print '-'*levelID,name
			
		if useExternal ==1:
			#texDir=g.dirname.replace('model','texture')
			#mat.diffuse=name
			nodeID = g.i(1)[0]
			if nodeID!=-1:
				nodeType = self.nodeTypeList[self.nodeIDList[nodeID]]
				if self.debug==True:
					print '-'*levelID,nodeID,nodeType
		else:	
			nodeID = g.i(1)[0] 
			nodeType = self.nodeTypeList[self.nodeIDList[nodeID]]
			if self.debug==True:
				print '-'*levelID,nodeID,nodeType
			if nodeType == 'NiPixelData':
				if self.PARSINGFLAG==False:
					offset = self.getNodeOffset(nodeID)
					back=g.tell()
					g.seek(offset)
					image=NiPixelData(self,levelID)
					image.name=g.dirname+os.sep+name
					image.draw()
					texPath=image.name
					g.seek(back)
			
		#g.seek(back)
		#if self.versionAsNumbers==(4,0,0,20):
		if self.versionAsNumbers in self.nifFormatListOld:g.i(3),g.B(2)
		if self.versionAsNumbers in self.nifFormatListNew:g.i(3),g.B(3)
		#g.debug=False
		
	else:
		print 'NiSourceTexture:',self.versionAsNumbers,'npt supported'
	
	return texPath	
		