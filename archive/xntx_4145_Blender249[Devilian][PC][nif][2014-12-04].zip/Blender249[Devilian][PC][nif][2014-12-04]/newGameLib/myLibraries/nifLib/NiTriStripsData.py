



def NiTriStripsData(self,levelID,mesh):
	g=self.input
	g.i(1)[0]
	numVertices = g.H(1)[0]
	print 'numVertices =',numVertices
	g.B(1)[0]
	g.B(1)[0]
	hasVertices = g.B(1)[0]#bool
	if hasVertices == 1:
		for n in range(numVertices):
			mesh.vertPosList.append(g.f(3))
	numUVSets = g.H(1)[0]
	hasNormals = g.B(1)[0]#bool
	if hasNormals == 1:
		for n in range(numVertices):g.f(3)
	if numUVSets >1:#in [61441]:
		for n in range(numVertices):g.f(3)#tangent
		for n in range(numVertices):g.f(3)#normals
  
	#break
	g.f(3)
	g.f(1)
	hasVertexColors = g.B(1)[0]#bool
	if hasVertexColors>0:
		for n in range(numVertices):g.f(4)
	if numUVSets!=0:#in [1,61441]:uv
		for n in range(numVertices):
			g.f(2)
	g.H(1)[0]
	g.i(1)[0]#new in version 20
	numTriangles = g.H(1)[0]
	numStrips = g.H(1)[0]
	strips = []
	for n in range(numStrips):
		strips.append(g.H(1)[0])
	hasPoints = g.B(1)[0]
	triangles = []
	if hasPoints>0:
			Strips = []
			for n in range(numStrips):
				points = []
				v1 = g.H(1)[0]
				v2 = g.H(1)[0] 
				for k in range(strips[n]-2):
					v3 = g.H(1)[0]
					points.append(v3)
					if v1!=v2 and v2!=v3 and v1!=v3:
						mesh.faceList.append([v1,v2,v3])
					v1 = v2
					v2 = v3  
				Strips.append(points)