


def BSShaderTextureSet(self):
	g=self.input
	texCount=g.i(1)[0]
	texList=[]
	for i in range(texCount):
		texName=g.word(g.i(1)[0])
		texList.append(texName)
		if self.debug==True:
			print texName
	return texList		