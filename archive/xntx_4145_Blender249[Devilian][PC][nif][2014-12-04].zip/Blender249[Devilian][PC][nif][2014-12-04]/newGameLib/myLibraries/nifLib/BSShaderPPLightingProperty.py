

def BSShaderPPLightingProperty(offset,m):
	if userversion in [0,11]:
			plik.seek(offset)   
			model = txt_list[i(1)[0]]
			for n in range(i(1)[0]):i(1)
			i(1),h(1),i(3),f(1),i(1)
			texture_set_id=i(1)[0]		
			offset = go_to_node(texture_set_id)
			texture_set(offset,m)
	if userversion==12:
			i(4),H(1),i(2),H(1),i(1),f(1),i(1)
			texture_id =  i(1)[0] 
			offset = go_to_node(texture_id)
			texture_set(offset,m) 
