



def NiFlipController(self): 
	g=self.input
	g.i(1)
	g.H(1)
	g.f(4)
	g.i(3)
	g.i(g.i(1)[0])
	