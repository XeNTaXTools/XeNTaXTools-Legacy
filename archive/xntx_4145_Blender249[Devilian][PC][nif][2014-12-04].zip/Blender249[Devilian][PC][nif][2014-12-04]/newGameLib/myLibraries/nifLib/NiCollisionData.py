
def NiCollisionData(self):
	g=self.input
	g.i(3)
	flag=g.B(1)[0]
	if self.versionAsNumbers in self.nifFormatListOld:
		type=g.i(1)[0]
		if type==1:
			g.f(15)
		if type==0:
			g.f(4)
	if self.versionAsNumbers in self.nifFormatListNew:
		if flag==1:
			type=g.i(1)[0]
			if type==2:
				g.f(8)
			else:
				print 'WARNING:',type
			
		