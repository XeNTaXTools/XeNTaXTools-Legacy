
def NiBSplineBasisData(self,levelID):
	g=self.input
	pointCount=g.i(1)[0]
	#print pointCount
	return pointCount