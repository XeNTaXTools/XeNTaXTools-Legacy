def NiAmbientLight(self):
	g=self.input
	id=g.i(1)[0]
	if id!=-1:
		if self.versionAsNumbers in self.nifFormatListOld:
			name=g.word(id)
		if self.versionAsNumbers in self.nifFormatListNew:
			name=self.stringList[id]
	else:
		name=None
	g.i(2),g.H(1) 
	g.f(13)
	g.i(2),g.B(1),g.i(1)
	g.f(10)
