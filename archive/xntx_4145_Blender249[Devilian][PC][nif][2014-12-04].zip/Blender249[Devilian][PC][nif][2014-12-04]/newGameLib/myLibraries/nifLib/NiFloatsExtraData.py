

def NiFloatsExtraData(self):
	g=self.input
	if self.versionAsNumbers in self.nifFormatListOld:
		name=g.word(g.i(1)[0])
	if self.versionAsNumbers in self.nifFormatListNew:
		name=self.stringList[g.i(1)[0]]
	g.f(g.i(1)[0])