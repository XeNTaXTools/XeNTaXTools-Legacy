def NiMultiTargetTransformController(self):
	g=self.input
	g.i(1)[0],g.H(1)[0],g.f(4),g.i(1)[0]
	for n in range(g.H(1)[0]):g.i(1)[0]
