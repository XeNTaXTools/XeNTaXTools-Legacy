from Blender.Mathutils import *

def NiSkinData(self):
	g=self.input
	g.f(13)
	boneCount=g.i(1)[0]
	Flag=g.B(1)[0]
	
	skinData=[]
	if Flag==1:
		for m in range(boneCount): 
			rotation=Matrix(g.f(3),g.f(3),g.f(3)).invert().resize4x4()
			translation=TranslationMatrix(Vector(g.f(3)))
			scale=g.f(1)[0]
			bounding_sphere_offset=Vector(g.f(3))
			bounding_sphere_radius=g.f(1)[0]
			matrix=rotation*translation
			if self.userVersion==196608:
				g.H(1)
				g.f(6)
			#if self.userVersion==12:
			#	print g.f(4)
			vertCount=g.H(1)[0]
			data=[] 
			for n in range(vertCount):
				vertID=g.H(1)[0]
				weight=g.f(1)[0]
				data.append([vertID,weight])
			skinData.append([matrix,data]) 
	return skinData	
						
		