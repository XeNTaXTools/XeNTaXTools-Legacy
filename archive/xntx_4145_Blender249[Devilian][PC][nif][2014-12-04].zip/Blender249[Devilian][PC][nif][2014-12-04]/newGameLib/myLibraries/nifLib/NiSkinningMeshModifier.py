

from newGameLib.myLibraries.skeletonLib import *

def NiSkinningMeshModifier(self,parentMatrix):
	skeleton=Skeleton()
	if self.versionAsNumbers==(1,0,6,20):
		skeleton.ARMATURESPACE=True
		skeleton.name='bind'
		skeleton.NICE=True
		g=self.input
		#g.b(4)
		Num = g.i(1)[0]
		for m in range(Num):
			g.H(1)[0]
		Num = g.i(1)[0]
		for m in range(Num):
			g.H(1)[0]
		g.H(1),g.i(1)
		g.f(9)
		g.f(3)
		g.f(1)  
		nBones = g.i(1)[0]
		bone_palette_names = []
		for m in range(nBones):
			g.i(1)[0]		
			#name = nodes[i(1)[0]][2];print name
			#bone_palette_names.append(name)
		for m in range(nBones):
			bone=Bone()
			rotMatrix=Matrix3x3(g.f(9)).invert().resize4x4()
			posMatrix=VectorMatrix(g.f(3))
			matrix=rotMatrix*posMatrix
			bone.matrix=matrix.invert()*parentMatrix
			g.f(1)  
			skeleton.boneList.append(bone)
		for m in range(nBones):
			g.f(3)
			g.f(1) 
		boneCount=g.i(1)[0]		
		for m in range(boneCount):
			ID=g.i(1)[0]
			if ID!=-1:
				if self.versionAsNumbers in self.nifFormatListOld:
					name=g.word(ID)
				if self.versionAsNumbers in self.nifFormatListNew:
					name=self.stringList[ID]
			else:
				name=None
			skeleton.boneList[m].name=name
		#skeleton.draw()
	elif self.versionAsNumbers==(2,0,6,20):
		skeleton.ARMATURESPACE=True
		skeleton.name='bind'
		skeleton.NICE=True
		g=self.input
		#g.b(4)
		Num = g.i(1)[0]
		for m in range(Num):
			g.H(1)[0]
		Num = g.i(1)[0]
		for m in range(Num):
			g.H(1)[0]
		g.H(1),g.i(1)
		g.f(9)
		g.f(3)
		g.f(1)  
		nBones = g.i(1)[0]
		bone_palette_names = []
		for m in range(nBones):
			g.i(1)[0]		
			#name = nodes[i(1)[0]][2];print name
			#bone_palette_names.append(name)
		for m in range(nBones):
			bone=Bone()
			rotMatrix=Matrix3x3(g.f(9)).invert().resize4x4()
			posMatrix=VectorMatrix(g.f(3))
			matrix=rotMatrix*posMatrix
			bone.matrix=matrix.invert()*parentMatrix
			g.f(1)  
			skeleton.boneList.append(bone)
		for m in range(nBones):
			g.f(3)
			g.f(1) 
		boneCount=g.i(1)[0]		
		for m in range(boneCount):
			ID=g.i(1)[0]
			if ID!=-1:
				if self.versionAsNumbers in self.nifFormatListOld:
					name=g.word(ID)
				if self.versionAsNumbers in self.nifFormatListNew:
					name=self.stringList[ID]
			else:
				name=None
			skeleton.boneList[m].name=name
		#skeleton.draw()
	else:
		print 'NiSkinningMeshModifier:',self.versionAsNumbers,'not supported'
	return skeleton	
