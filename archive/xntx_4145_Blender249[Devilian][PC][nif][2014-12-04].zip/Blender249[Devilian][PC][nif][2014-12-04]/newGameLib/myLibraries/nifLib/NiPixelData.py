
	
from newGameLib.myLibraries.imageLib import *

def NiPixelData(self,levelID):
	image=None
	levelID+=4
	g=self.input
	#print g.tell()
	pixelFormat = g.i(1)[0]
	texel=None
	if pixelFormat==4:texel='DXT1'
	elif pixelFormat==5:texel='DXT3'
	elif pixelFormat==6:texel='DXT5'
	elif pixelFormat==1:texel='RAW'
	elif pixelFormat==0:texel='RAW24'
	else:print 'unknow format',pixelFormat
	#if texel is not None:   
	bitPerPixel=g.B(1)[0]
	g.i(2)
	g.B(1)
	g.i(1)
	if self.versionAsNumbers==(0,0,6,20):
		g.B(1)####################################dla ragnaroka
	g.B(10*4)
	g.i(1)
	mipmapsCount=g.i(1)[0]
	#print mipmapsCount
	bytesPerPixel=g.i(1)[0]
	mipmapsList=[]
	for m in range(mipmapsCount):
		width=g.i(1)[0]
		height=g.i(1)[0]
		offset=g.i(1)[0]
		mipmapsList.append([width,height,offset])
	pixelCount=g.i(1)[0]
	#print pixelCount
	facesCount=g.i(1)[0] 
	#if texel=='RAW24':
	#	g.B(2)
	if self.PARSINGFLAG==False:
		offset=g.tell()
		g.seek(offset+mipmapsList[0][2])
		image=Image()
		image.data=g.read(mipmapsList[1][2])
		image.szer=mipmapsList[0][0]
		image.wys=mipmapsList[0][1]
		image.format=texel
		#mat.imageList.append(image)
		#image.draw()
	g.seek(pixelCount,1)
	
	return image