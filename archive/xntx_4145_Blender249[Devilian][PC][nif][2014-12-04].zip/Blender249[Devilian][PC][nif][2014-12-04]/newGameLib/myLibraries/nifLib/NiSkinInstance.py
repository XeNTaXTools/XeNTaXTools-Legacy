

import NiSkinData
reload(NiSkinData)
from NiSkinData import *


def NiSkinInstance(self,levelID): 
	boneNameList = []
	skinData=[]
	if self.versionAsNumbers==(4,0,0,20):
		levelID+=4
		g=self.input
		nodeID=g.i(1)[0]
		
		skinData=[]
		if self.PARSINGFLAG==False:
			offset = self.getNodeOffset(nodeID)
			t=g.tell()
			g.seek(offset)
			skinData=NiSkinData(self)	
			g.seek(t)


		#self.show(nodeID,levelID)
		
		ID=g.i(1)[0]
		#self.show(ID,levelID)
		unk=g.i(1)[0]
		numBones = g.i(1)[0]
		boneNameList = []
		for n in range(numBones):
			nodeID=g.i(1)[0]
			if self.PARSINGFLAG==False:
				t=g.tell()
				offset = self.getNodeOffset(nodeID)
				size=self.nodeSizeList[nodeID]
				g.seek(offset)
				name=g.word(g.i(1)[0])
				boneNameList.append(name)
				g.seek(t)
	elif self.versionAsNumbers==(0,0,2,10):
		levelID+=4
		g=self.input
		nodeID=g.i(1)[0]
		
		skinData=[]
		if self.PARSINGFLAG==False:
			offset = self.getNodeOffset(nodeID)
			t=g.tell()
			g.seek(offset)
			skinData=NiSkinData(self)	
			g.seek(t)


		#self.show(nodeID,levelID)
		
		ID=g.i(1)[0]
		#self.show(ID,levelID)
		unk=g.i(1)[0]
		numBones = g.i(1)[0]
		boneNameList = []
		for n in range(numBones):
			nodeID=g.i(1)[0]
			if self.PARSINGFLAG==False:
				t=g.tell()
				offset = self.getNodeOffset(nodeID)
				size=self.nodeSizeList[nodeID]
				g.seek(offset)
				name=g.word(g.i(1)[0])
				boneNameList.append(name)
				g.seek(t)
	else:
		levelID+=4
		g=self.input
		nodeID=g.i(1)[0]
		
		skinData=[]
		if self.PARSINGFLAG==False:
			offset = self.getNodeOffset(nodeID)
			t=g.tell()
			g.seek(offset)
			skinData=NiSkinData(self)	
			g.seek(t)


		#self.show(nodeID,levelID)
		
		ID=g.i(1)[0]
		#self.show(ID,levelID)
		unk=g.i(1)[0]
		numBones = g.i(1)[0]
		boneNameList = []
		for n in range(numBones):
			nodeID=g.i(1)[0]
			if self.PARSINGFLAG==False:
				t=g.tell()
				offset = self.getNodeOffset(nodeID)
				size=self.nodeSizeList[nodeID]
				g.seek(offset)
				name=self.stringList[g.i(1)[0]]
				boneNameList.append(name)
				g.seek(t)
	#else:
	#	print 'NiSkinInstance:',self.versionAsNumbers,'not supported'
		
	return boneNameList,skinData