import Blender
from Blender.Mathutils import *


import NiTriStrips
reload(NiTriStrips)
from NiTriStrips import *

import NiTriShape
reload(NiTriShape)
from NiTriShape import *

"""import NiDirectionalLight
reload(NiDirectionalLight)
from NiDirectionalLight import *"""


import NiMesh
reload(NiMesh)
from NiMesh import *

from newGameLib.myLibraries.skeletonLib import *
		


def NiNode(self,levelID,parentName,parentMatrix):
		
	if self.versionAsNumbers==(4,0,0,20):
		levelID+=4
		g=self.input
		if self.versionAsNumbers in self.nifFormatListOld:name=g.word(g.i(1)[0])
		if self.versionAsNumbers in self.nifFormatListNew:name=self.stringList[g.i(1)[0]]
		bone=Bone()
		bone.name=name[-25:]
		self.skeleton.boneList.append(bone)
		if len(parentName)>0:
			bone.parentName=parentName
		
		extraDataList=g.i(g.i(1)[0]);controller=g.i(1)[0];flag=g.H(1)[0]
		
		if self.userVersion==12:g.H(1)
		
		posMatrix=TranslationMatrix(Vector(g.f(3)))
		rotMatrix=Matrix(g.f(3),g.f(3),g.f(3)).invert().resize4x4()
		scale=g.f(1)[0]
		bone.matrix=rotMatrix*posMatrix*parentMatrix
		
		if self.userVersion!=12:properties=g.i(g.i(1)[0])
		g.i(1)
		childrenCount=g.i(1)[0]
		children=g.i(childrenCount)	
		effectCount=g.i(1)[0]
		g.i(effectCount)
		
		for m in range(childrenCount):
			ID=children[m]
			if ID!=-1:
				nodeType=self.nodeTypeList[self.nodeIDList[ID]]
				if self.PARSINGFLAG==False:
					size=self.nodeSizeList[ID]
					if self.debug==True:
						print '-'*levelID,ID,nodeType,size
					if self.versionAsNumbers!=(0,0,2,10):#Shadow Harvest
						offset=self.getNodeOffset(ID)
						g.seek(offset)
						if nodeType=='NiNode':
							NiNode(self,levelID,bone.name,bone.matrix)
						elif nodeType=='NiTriShape':
							NiTriShape(self,levelID,bone.matrix)
					
	elif self.versionAsNumbers==(0,0,2,10):
		levelID+=4
		g=self.input
		if self.versionAsNumbers in self.nifFormatListOld:name=g.word(g.i(1)[0])
		if self.versionAsNumbers in self.nifFormatListNew:name=self.stringList[g.i(1)[0]]
		bone=Bone()
		bone.name=name[-25:]
		self.skeleton.boneList.append(bone)
		if len(parentName)>0:
			bone.parentName=parentName
		
		extraDataList=g.i(g.i(1)[0]);controller=g.i(1)[0];flag=g.H(1)[0]
		
		if self.userVersion==12:g.H(1)
		
		posMatrix=TranslationMatrix(Vector(g.f(3)))
		rotMatrix=Matrix(g.f(3),g.f(3),g.f(3)).invert().resize4x4()
		scale=g.f(1)[0]
		bone.matrix=rotMatrix*posMatrix*parentMatrix
		
		if self.userVersion!=12:properties=g.i(g.i(1)[0])
		g.i(1)
		childrenCount=g.i(1)[0]
		children=g.i(childrenCount)	
		effectCount=g.i(1)[0]
		g.i(effectCount)
		
		for m in range(childrenCount):
			ID=children[m]
			if ID!=-1:
				nodeType=self.nodeTypeList[self.nodeIDList[ID]]
				if self.PARSINGFLAG==False:
					size=self.nodeSizeList[ID]
					if self.debug==True:
						print '-'*levelID,ID,nodeType,size
					#if self.versionAsNumbers!=(0,0,2,10):#Shadow Harvest
					offset=self.getNodeOffset(ID)
					g.seek(offset)
					if nodeType=='NiNode':
						NiNode(self,levelID,bone.name,bone.matrix)
					elif nodeType=='NiTriShape':
						NiTriShape(self,levelID,bone.matrix)
								
		
	elif self.versionAsNumbers==(9,0,3,20):
		levelID+=4
		g=self.input
		if self.versionAsNumbers in self.nifFormatListOld:name=g.word(g.i(1)[0])
		if self.versionAsNumbers in self.nifFormatListNew:name=self.stringList[g.i(1)[0]]
		
		bone=Bone()
		bone.name=name[-25:]
		self.skeleton.boneList.append(bone)
		if len(parentName)>0:
			bone.parentName=parentName
		
		extraDataList=g.i(g.i(1)[0]);controller=g.i(1)[0];flag=g.H(1)[0]
		
		if self.userVersion==12:g.H(1)
		
		posMatrix=TranslationMatrix(Vector(g.f(3)))
		rotMatrix=Matrix(g.f(3),g.f(3),g.f(3)).invert().resize4x4()
		scale=g.f(1)[0]
		bone.matrix=rotMatrix*posMatrix*parentMatrix
		
		if self.userVersion!=12:properties=g.i(g.i(1)[0])
		g.i(1)
		childrenCount=g.i(1)[0]
		children=g.i(childrenCount)	
		effectCount=g.i(1)[0]
		g.i(effectCount)
		
		for m in range(childrenCount):
			ID=children[m]
			if ID!=-1:
				nodeType=self.nodeTypeList[self.nodeIDList[ID]]
				size=self.nodeSizeList[ID]
				if self.debug==True:
					print '-'*levelID,ID,nodeType,size
				if self.versionAsNumbers==(4,0,0,20):pass
				else:
					if self.versionAsNumbers!=(0,0,2,10):#Shadow Harvest
						offset=self.getNodeOffset(ID)
						g.seek(offset)
						if nodeType=='NiNode':
							NiNode(self,levelID,bone.name,bone.matrix)
						elif nodeType=='NiTriShape':
							NiTriShape(self,levelID,bone.matrix)
						elif nodeType=='NiTriStrips':
							NiTriStrips(self,levelID,bone.matrix)
							
				
		
	elif self.versionAsNumbers==(103,95,97,115):
		levelID+=4
		g=self.input
		if self.versionAsNumbers in self.nifFormatListOld:name=g.word(g.i(1)[0])
		if self.versionAsNumbers in self.nifFormatListNew:name=self.stringList[g.i(1)[0]]
		
		bone=Bone()
		bone.name=name[-25:]
		self.skeleton.boneList.append(bone)
		if len(parentName)>0:
			bone.parentName=parentName
		
		extraDataList=g.i(g.i(1)[0]);controller=g.i(1)[0];flag=g.H(1)[0]
		
		if self.userVersion==12:g.H(1)
		
		posMatrix=TranslationMatrix(Vector(g.f(3)))
		rotMatrix=Matrix(g.f(3),g.f(3),g.f(3)).invert().resize4x4()
		scale=g.f(1)[0]
		bone.matrix=rotMatrix*posMatrix*parentMatrix
		
		if self.userVersion!=12:properties=g.i(g.i(1)[0])
		g.i(1)
		childrenCount=g.i(1)[0]
		children=g.i(childrenCount)	
		effectCount=g.i(1)[0]
		g.i(effectCount)
		
		for m in range(childrenCount):
			ID=children[m]
			if ID!=-1:
				nodeType=self.nodeTypeList[self.nodeIDList[ID]]
				size=self.nodeSizeList[ID]
				if self.debug==True:
					print '-'*levelID,ID,nodeType,size
				if self.versionAsNumbers==(4,0,0,20):pass
				else:
					if self.versionAsNumbers!=(0,0,2,10):#Shadow Harvest
						offset=self.getNodeOffset(ID)
						g.seek(offset)
						if nodeType=='NiNode':
							NiNode(self,levelID,bone.name,bone.matrix)
						elif nodeType=='NiTriShape':
							NiTriShape(self,levelID,bone.matrix)	
							
	elif self.versionAsNumbers==(8,0,2,20):
		levelID+=4
		g=self.input
		if self.versionAsNumbers in self.nifFormatListOld:name=g.word(g.i(1)[0])
		if self.versionAsNumbers in self.nifFormatListNew:name=self.stringList[g.i(1)[0]]
		
		bone=Bone()
		bone.name=name[-25:]
		self.skeleton.boneList.append(bone)
		if len(parentName)>0:
			bone.parentName=parentName
		
		extraDataList=g.i(g.i(1)[0]);controller=g.i(1)[0];flag=g.H(1)[0]
		
		if self.userVersion==12:g.H(1)
		
		posMatrix=TranslationMatrix(Vector(g.f(3)))
		rotMatrix=Matrix(g.f(3),g.f(3),g.f(3)).invert().resize4x4()
		scale=g.f(1)[0]
		bone.matrix=rotMatrix*posMatrix*parentMatrix
		
		if self.userVersion!=12:properties=g.i(g.i(1)[0])
		g.i(1)
		childrenCount=g.i(1)[0]
		children=g.i(childrenCount)	
		effectCount=g.i(1)[0]
		g.i(effectCount)
		
		for m in range(childrenCount):
			ID=children[m]
			if ID!=-1:
				nodeType=self.nodeTypeList[self.nodeIDList[ID]]
				size=self.nodeSizeList[ID]
				if self.debug==True:
					print '-'*levelID,ID,nodeType,size
				if self.versionAsNumbers==(4,0,0,20):pass
				else:
					if self.versionAsNumbers!=(0,0,2,10):#Shadow Harvest
						offset=self.getNodeOffset(ID)
						g.seek(offset)
						if nodeType=='NiNode':
							NiNode(self,levelID,bone.name,bone.matrix)
						elif nodeType=='NiTriShape':
							NiTriShape(self,levelID,bone.matrix)
								
	elif self.versionAsNumbers==(7,0,2,20):
		levelID+=4
		g=self.input
		if self.versionAsNumbers in self.nifFormatListOld:name=g.word(g.i(1)[0])
		if self.versionAsNumbers in self.nifFormatListNew:name=self.stringList[g.i(1)[0]]
		
		bone=Bone()
		bone.name=name[-25:]
		self.skeleton.boneList.append(bone)
		if len(parentName)>0:
			bone.parentName=parentName
		
		extraDataList=g.i(g.i(1)[0]);controller=g.i(1)[0];flag=g.H(1)[0]
		
		if self.userVersion==12:g.H(1)
		
		posMatrix=TranslationMatrix(Vector(g.f(3)))
		rotMatrix=Matrix(g.f(3),g.f(3),g.f(3)).invert().resize4x4()
		scale=g.f(1)[0]
		bone.matrix=rotMatrix*posMatrix*parentMatrix
		
		if self.userVersion!=12:properties=g.i(g.i(1)[0])
		g.i(1)
		childrenCount=g.i(1)[0]
		children=g.i(childrenCount)	
		effectCount=g.i(1)[0]
		g.i(effectCount)
		
		for m in range(childrenCount):
			ID=children[m]
			if ID!=-1:
				nodeType=self.nodeTypeList[self.nodeIDList[ID]]
				size=self.nodeSizeList[ID]
				if self.debug==True:
					print '-'*levelID,ID,nodeType,size
				if self.versionAsNumbers==(4,0,0,20):pass
				else:
					if self.versionAsNumbers!=(0,0,2,10):#Shadow Harvest
						offset=self.getNodeOffset(ID)
						g.seek(offset)
						if nodeType=='NiNode':
							NiNode(self,levelID,bone.name,bone.matrix)
						elif nodeType=='NiTriShape':
							NiTriShape(self,levelID,bone.matrix)
							
	elif self.versionAsNumbers==(3,0,1,30):
		levelID+=4
		g=self.input
		if self.versionAsNumbers in self.nifFormatListOld:name=g.word(g.i(1)[0])
		if self.versionAsNumbers in self.nifFormatListNew:name=self.stringList[g.i(1)[0]]
		
		bone=Bone()
		bone.name=name[-25:]
		self.skeleton.boneList.append(bone)
		if len(parentName)>0:
			bone.parentName=parentName
		
		extraDataList=g.i(g.i(1)[0]);controller=g.i(1)[0];flag=g.H(1)[0]
		
		if self.userVersion==12:g.H(1)
		
		posMatrix=TranslationMatrix(Vector(g.f(3)))
		rotMatrix=Matrix(g.f(3),g.f(3),g.f(3)).invert().resize4x4()
		scale=g.f(1)[0]
		bone.matrix=rotMatrix*posMatrix*parentMatrix
		
		if self.userVersion!=12:properties=g.i(g.i(1)[0])
		g.i(1)
		childrenCount=g.i(1)[0]
		children=g.i(childrenCount)	
		effectCount=g.i(1)[0]
		g.i(effectCount)
		
		for m in range(childrenCount):
			ID=children[m]
			if ID!=-1:
				nodeType=self.nodeTypeList[self.nodeIDList[ID]]
				size=self.nodeSizeList[ID]
				if self.debug==True:
					print '-'*levelID,ID,nodeType,size
				if self.versionAsNumbers==(4,0,0,20):pass
				else:
					if self.versionAsNumbers!=(0,0,2,10):#Shadow Harvest
						offset=self.getNodeOffset(ID)
						g.seek(offset)
						if nodeType=='NiNode':
							NiNode(self,levelID,bone.name,bone.matrix)
						elif nodeType=='NiTriShape':
							NiTriShape(self,levelID,bone.matrix)
						elif nodeType=='NiMesh':
							NiMesh(self,levelID,bone.matrix,ID)
										
							
	elif self.versionAsNumbers==(0,0,6,20):
		levelID+=4
		g=self.input
		if self.versionAsNumbers in self.nifFormatListOld:name=g.word(g.i(1)[0])
		if self.versionAsNumbers in self.nifFormatListNew:name=self.stringList[g.i(1)[0]]
		if self.debug==True:
			print '-'*levelID,name
		bone=Bone()
		bone.name=name[-25:]
		self.skeleton.boneList.append(bone)
		if len(parentName)>0:
			bone.parentName=parentName
		
		extraDataList=g.i(g.i(1)[0]);controller=g.i(1)[0];flag=g.H(1)[0]
		
		if self.userVersion==12:g.H(1)
		
		posMatrix=TranslationMatrix(Vector(g.f(3)))
		rotMatrix=Matrix(g.f(3),g.f(3),g.f(3)).invert().resize4x4()
		scale=g.f(1)[0]
		bone.matrix=rotMatrix*posMatrix*parentMatrix
		
		if self.userVersion!=12:properties=g.i(g.i(1)[0])
		g.i(1)
		childrenCount=g.i(1)[0]
		children=g.i(childrenCount)	
		effectCount=g.i(1)[0]
		g.i(effectCount)
		print children
		for m in range(childrenCount):
			ID=children[m]
			if ID!=-1:
				nodeType=self.nodeTypeList[self.nodeIDList[ID]]
				size=self.nodeSizeList[ID]
				if self.debug==True:
					print '-'*levelID,ID,nodeType,size
				if self.versionAsNumbers==(4,0,0,20):pass
				else:
					if self.versionAsNumbers!=(0,0,2,10):#Shadow Harvest
						offset=self.getNodeOffset(ID)
						g.seek(offset)
						if nodeType=='NiNode':
							NiNode(self,levelID,bone.name,bone.matrix)
						elif nodeType=='NiSortAdjustNode':
							NiNode(self,levelID,bone.name,bone.matrix)
						elif nodeType=='NiTriShape':
							NiTriShape(self,levelID,bone.matrix)
						elif nodeType=='NiMesh':
							NiMesh(self,levelID,bone.matrix,ID)
								
	elif self.versionAsNumbers==(0,0,5,20):
		levelID+=4
		g=self.input
		if self.versionAsNumbers in self.nifFormatListOld:name=g.word(g.i(1)[0])
		if self.versionAsNumbers in self.nifFormatListNew:name=self.stringList[g.i(1)[0]]
		
		bone=Bone()
		bone.name=name[-25:]
		self.skeleton.boneList.append(bone)
		if len(parentName)>0:
			bone.parentName=parentName
		
		extraDataList=g.i(g.i(1)[0]);controller=g.i(1)[0];flag=g.H(1)[0]
		
		if self.userVersion==12:g.H(1)
		
		posMatrix=TranslationMatrix(Vector(g.f(3)))
		rotMatrix=Matrix(g.f(3),g.f(3),g.f(3)).invert().resize4x4()
		scale=g.f(1)[0]
		bone.matrix=rotMatrix*posMatrix*parentMatrix
		
		if self.userVersion!=12:properties=g.i(g.i(1)[0])
		g.i(1)
		childrenCount=g.i(1)[0]
		children=g.i(childrenCount)	
		effectCount=g.i(1)[0]
		g.i(effectCount)
		
		for m in range(childrenCount):
			ID=children[m]
			if ID!=-1:
				nodeType=self.nodeTypeList[self.nodeIDList[ID]]
				size=self.nodeSizeList[ID]
				if self.debug==True:
					print '-'*levelID,ID,nodeType,size
				if self.versionAsNumbers==(4,0,0,20):pass
				else:
					if self.versionAsNumbers!=(0,0,2,10):#Shadow Harvest
						offset=self.getNodeOffset(ID)
						g.seek(offset)
						if nodeType=='NiNode':
							NiNode(self,levelID,bone.name,bone.matrix)
						elif nodeType=='NiSortAdjustNode':
							NiNode(self,levelID,bone.name,bone.matrix)
						elif nodeType=='NiSwitchNode':
							NiNode(self,levelID,bone.name,bone.matrix)
						elif nodeType=='NiTriShape':
							NiTriShape(self,levelID,bone.matrix)
						elif nodeType=='NiMesh':
							NiMesh(self,levelID,bone.matrix,ID)				
							
	elif self.versionAsNumbers==(1,0,6,20):
		levelID+=4
		g=self.input
		if self.versionAsNumbers in self.nifFormatListOld:name=g.word(g.i(1)[0])
		if self.versionAsNumbers in self.nifFormatListNew:name=self.stringList[g.i(1)[0]]
		if self.debug==True:
			print '-'*levelID,name
		bone=Bone()
		bone.name=name[-25:]
		self.skeleton.boneList.append(bone)
		if len(parentName)>0:
			bone.parentName=parentName
		
		extraDataList=g.i(g.i(1)[0]);controller=g.i(1)[0];flag=g.H(1)[0]
		
		if self.userVersion==12:g.H(1)
		
		posMatrix=TranslationMatrix(Vector(g.f(3)))
		rotMatrix=Matrix(g.f(3),g.f(3),g.f(3)).invert().resize4x4()
		scale=g.f(1)[0]
		bone.matrix=rotMatrix*posMatrix*parentMatrix
		
		if self.userVersion!=12:properties=g.i(g.i(1)[0])
		g.i(1)
		childrenCount=g.i(1)[0]
		children=g.i(childrenCount)	
		effectCount=g.i(1)[0]
		g.i(effectCount)
		print children
		for m in range(childrenCount):
			ID=children[m]
			if ID!=-1:
				nodeType=self.nodeTypeList[self.nodeIDList[ID]]
				size=self.nodeSizeList[ID]
				if self.debug==True:
					print '-'*levelID,ID,nodeType,size
				if self.versionAsNumbers==(4,0,0,20):pass
				else:
					if self.versionAsNumbers!=(0,0,2,10):#Shadow Harvest
						offset=self.getNodeOffset(ID)
						g.seek(offset)
						if nodeType=='NiNode':
							NiNode(self,levelID,bone.name,bone.matrix)
						elif nodeType=='GnJiggleBone':
							NiNode(self,levelID,bone.name,bone.matrix)
						elif nodeType=='NiSortAdjustNode':
							NiNode(self,levelID,bone.name,bone.matrix)
						elif nodeType=='NiTriShape':
							NiTriShape(self,levelID,bone.matrix)
						elif nodeType=='NiMesh':
							NiMesh(self,levelID,bone.matrix,ID)
								
	elif self.versionAsNumbers==(2,0,6,20):
		levelID+=4
		g=self.input
		if self.versionAsNumbers in self.nifFormatListOld:name=g.word(g.i(1)[0])
		if self.versionAsNumbers in self.nifFormatListNew:name=self.stringList[g.i(1)[0]]
		if self.debug==True:
			print '-'*levelID,name
		bone=Bone()
		bone.name=name[-25:]
		self.skeleton.boneList.append(bone)
		if len(parentName)>0:
			bone.parentName=parentName
		
		extraDataList=g.i(g.i(1)[0]);controller=g.i(1)[0];flag=g.H(1)[0]
		
		if self.userVersion==12:g.H(1)
		
		posMatrix=TranslationMatrix(Vector(g.f(3)))
		rotMatrix=Matrix(g.f(3),g.f(3),g.f(3)).invert().resize4x4()
		scale=g.f(1)[0]
		bone.matrix=rotMatrix*posMatrix*parentMatrix
		
		if self.userVersion!=12:properties=g.i(g.i(1)[0])
		g.i(1)
		childrenCount=g.i(1)[0]
		children=g.i(childrenCount)	
		effectCount=g.i(1)[0]
		g.i(effectCount)
		print children
		for m in range(childrenCount):
			ID=children[m]
			if ID!=-1:
				nodeType=self.nodeTypeList[self.nodeIDList[ID]]
				size=self.nodeSizeList[ID]
				if self.debug==True:
					print '-'*levelID,ID,nodeType,size
				if self.versionAsNumbers==(4,0,0,20):pass
				else:
					if self.versionAsNumbers!=(0,0,2,10):#Shadow Harvest
						offset=self.getNodeOffset(ID)
						g.seek(offset)
						if nodeType=='NiNode':
							NiNode(self,levelID,bone.name,bone.matrix)
						elif nodeType=='GnJiggleBone':
							NiNode(self,levelID,bone.name,bone.matrix)
						elif nodeType=='NiSortAdjustNode':
							NiNode(self,levelID,bone.name,bone.matrix)
						elif nodeType=='NiTriShape':
							NiTriShape(self,levelID,bone.matrix)
						elif nodeType=='NiMesh':
							NiMesh(self,levelID,bone.matrix,ID)
						else:
							print 'WARNING:NiNode:',nodeType
										
	else:
		print 'NiNode:',self.versionAsNumbers
							
							