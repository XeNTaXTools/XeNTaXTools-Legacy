
from Blender.Mathutils import *



import NiTexturingProperty
reload(NiTexturingProperty)
from NiTexturingProperty import *

import NiMaterialProperty
reload(NiMaterialProperty)
from NiMaterialProperty import *

import NiDataStream
reload(NiDataStream)
from NiDataStream import *

import NiSkinningMeshModifier
reload(NiSkinningMeshModifier)
from NiSkinningMeshModifier import *

from newGameLib.myLibraries.meshLib import *


def NiMesh(self,levelID,parentMatrix,meshID):
	if self.versionAsNumbers==(0,0,6,20):
		g=self.input
		ID=g.i(1)[0]
		if ID!=-1:
			if self.versionAsNumbers in self.nifFormatListOld:
				name=g.word(ID)
			if self.versionAsNumbers in self.nifFormatListNew:
				name=self.stringList[ID]
		else:
			name=None
		for n in range(g.i(1)[0]):
			g.i(1)[0]
		g.b(6)
		#print name
		
		
		
		pos = TranslationMatrix(Vector(g.f(3)))
		rot = Matrix(g.f(3),g.f(3),g.f(3)).invert().resize4x4()
		matrix = rot*pos*parentMatrix
		scale = g.f(1)[0]
		#print 'scale =', scale
		
		
		texList=None
		nProperties = g.i(1)[0]#;print 'nProperties =',nProperties
		for n in range(nProperties):
			ID = g.i(1)[0]
			nodeType=self.nodeTypeList[self.nodeIDList[ID]]
			offset = self.getNodeOffset(ID)
			
			if self.debug==True:
				size=self.nodeSizeList[ID]
				if self.debug==True:
					print '-'*levelID,ID,nodeType,size
			
			back=g.tell()
			g.seek(offset)
			if nodeType == 'NiMaterialProperty':
				NiMaterialProperty(self)
			if nodeType == 'NiTexturingProperty':
				texList=NiTexturingProperty(self,levelID)
			g.seek(back)	
				
				
		collisionObject=g.i(1)[0]	   
		matCount=g.i(1)[0]  
		for m in range(matCount):
			g.i(2)
		g.i(1)	  
		g.b(1)
		g.i(1)
		submeshCount = g.H(1)[0]
		g.b(17)
		dataCount = g.i(1)[0]
		
		meshList=[]
		for i in range(submeshCount):
			mesh=Mesh()
			mesh.name=str(meshID)
			mesh.TRIANGLE=True
			mesh.matrix=matrix
			meshList.append(mesh)
		
		for n in range(dataCount):
			streamList=[]
			streamID = g.i(1)[0]
			g.b(1)
			submeshCount=g.H(1)[0]
			submeshIDList=g.H(submeshCount)
			nodeType=self.nodeTypeList[self.nodeIDList[streamID]]
			offset=self.getNodeOffset(streamID)
			back=g.tell()
			g.seek(offset)
			regionList=NiDataStream(self)
			g.seek(back)
				
			
			
			
			componentCount = g.i(1)[0]
			for id in range(componentCount):
				name=self.stringList[g.i(1)[0]]
				index=g.i(1)[0]
				#print name,
				for m in range(submeshCount):
					mesh=meshList[submeshIDList[m]]
					region=regionList[submeshIDList[m]]
					if name=='INDEX':
						mesh.indiceList.extend(region[id])
					elif name=='POSITION':
						mesh.vertPosList.extend(region[id])
					elif name=='POSITION_BP':
						mesh.vertPosList.extend(region[id])
					elif name=='TEXCOORD':
						mesh.vertUVList.extend(region[id])
					else:pass
		for mesh in meshList:
			mat=Mat()
			mat.TRIANGLE=True
			mat.ZTRANS=True
			if texList is not None:
					#print texList
					if self.userVersion==196608:					
						texDir=g.dirname.lower().split('characters')[0]+'textures'
						if texList[0] is not None:
							texPath=texDir+os.sep+texList[0].split('.')[0]+'.nif'
							if os.path.exists(texPath)==True:
								#print texPath
								file=open(texPath,'rb')
								p=BinaryReader(file)
								p.debug=False
								#nif=Nif()
								#nif.debug=False
								#nif.input=p
								#nif.explore()
								#file.close()
								mat.diffuse=texDir+os.sep+texList[0].split('.')[0]+'.dds'
					else:
						if texList[0] is not None:
							texDir=g.dirname
							mat.diffuse=texDir+os.sep+texList[0]
			mesh.matList.append(mat)				
			#mesh.draw()
			self.meshList.append(mesh)
			
		g.debug=False
		g.i(g.i(1)[0])
		
		
	elif self.versionAsNumbers==(0,0,5,20):
		g=self.input
		ID=g.i(1)[0]
		if ID!=-1:
			if self.versionAsNumbers in self.nifFormatListOld:
				name=g.word(ID)
			if self.versionAsNumbers in self.nifFormatListNew:
				name=self.stringList[ID]
		else:
			name=None
		for n in range(g.i(1)[0]):
			g.i(1)[0]
		g.b(6)
		#print name
		
		
		
		pos = TranslationMatrix(Vector(g.f(3)))
		rot = Matrix(g.f(3),g.f(3),g.f(3)).resize4x4()
		matrix = rot*pos*parentMatrix
		scale = g.f(1)[0]
		#print 'scale =', scale
		
		
		texList=None
		nProperties = g.i(1)[0]#;print 'nProperties =',nProperties
		for n in range(nProperties):
			ID = g.i(1)[0]
			nodeType=self.nodeTypeList[self.nodeIDList[ID]]
			offset = self.getNodeOffset(ID)
			
			if self.debug==True:
				size=self.nodeSizeList[ID]
				if self.debug==True:
					print '-'*levelID,ID,nodeType,size
			
			back=g.tell()
			g.seek(offset)
			if nodeType == 'NiMaterialProperty':
				NiMaterialProperty(self)
			if nodeType == 'NiTexturingProperty':
				texList=NiTexturingProperty(self,levelID)
			g.seek(back)	
				
				
				
				
		collisionObject=g.i(1)[0]	   
		matCount=g.i(1)[0]  
		for m in range(matCount):
			g.i(2)
		g.i(1)	  
		g.b(1)
		g.i(1)
		submeshCount = g.H(1)[0]
		g.b(17)
		dataCount = g.i(1)[0]
		
		meshList=[]
		for i in range(submeshCount):
			mesh=Mesh()
			mesh.name=str(meshID)
			mesh.TRIANGLE=True
			mesh.matrix=matrix
			meshList.append(mesh)
		
		for n in range(dataCount):
			streamList=[]
			streamID = g.i(1)[0]
			g.b(1)
			submeshCount=g.H(1)[0]
			submeshIDList=g.H(submeshCount)
			nodeType=self.nodeTypeList[self.nodeIDList[streamID]]
			offset=self.getNodeOffset(streamID)
			back=g.tell()
			g.seek(offset)
			regionList=NiDataStream(self)
			g.seek(back)
				
			
			
			
			componentCount = g.i(1)[0]
			for id in range(componentCount):
				name=self.stringList[g.i(1)[0]]
				index=g.i(1)[0]
				#print name,
				for m in range(submeshCount):
					mesh=meshList[submeshIDList[m]]
					region=regionList[submeshIDList[m]]
					if name=='INDEX':
						mesh.indiceList.extend(region[id])
					elif name=='POSITION':
						mesh.vertPosList.extend(region[id])
					elif name=='POSITION_BP':
						mesh.vertPosList.extend(region[id])
					elif name=='TEXCOORD':
						mesh.vertUVList.extend(region[id])
					else:pass
		for mesh in meshList:
			mat=Mat()
			mat.TRIANGLE=True
			mat.ZTRANS=True
			if texList is not None:
					#print texList
					if self.userVersion==196608:					
						texDir=g.dirname.lower().split('characters')[0]+'textures'
						if texList[0] is not None:
							texPath=texDir+os.sep+texList[0].split('.')[0]+'.nif'
							if os.path.exists(texPath)==True:
								#print texPath
								file=open(texPath,'rb')
								p=BinaryReader(file)
								p.debug=False
								#nif=Nif()
								#nif.debug=False
								#nif.input=p
								#nif.explore()
								#file.close()
								mat.diffuse=texDir+os.sep+texList[0].split('.')[0]+'.dds'
					else:
						mat.diffuse=g.dirname+os.sep+texList[0]
			print mat.diffuse			
			mesh.matList.append(mat)				
			mesh.draw()
			
		g.debug=False
		g.i(g.i(1)[0])
		
		
		
	elif self.versionAsNumbers==(3,0,1,30):
		g=self.input
		ID=g.i(1)[0]
		if ID!=-1:
			if self.versionAsNumbers in self.nifFormatListOld:
				name=g.word(ID)
			if self.versionAsNumbers in self.nifFormatListNew:
				name=self.stringList[ID]
		else:
			name=None
		for n in range(g.i(1)[0]):
			g.i(1)[0]
		g.b(6)
		#print name
		
		
		
		pos = TranslationMatrix(Vector(g.f(3)))
		rot = Matrix(g.f(3),g.f(3),g.f(3)).resize4x4()
		matrix = rot*pos*parentMatrix
		scale = g.f(1)[0]
		#print 'scale =', scale
		
		
		nProperties = g.i(1)[0]#;print 'nProperties =',nProperties
		for n in range(nProperties):
			ID = g.i(1)[0]
			"""nodeType=NodeTypes[nodeIDList[ID]]
			offset=getNodeOffset(ID,g)
			if nodeType == 'NiMaterialProperty':
				NiMaterialProperty(offset,g)
			if nodeType == 'NiTexturingProperty':
				NiTexturingProperty(offset,g)"""
		collisionObject=g.i(1)[0]	   
		matCount=g.i(1)[0]  
		for m in range(matCount):
			g.i(2)
		g.i(1)	  
		g.b(1)
		g.i(1)
		submeshCount = g.H(1)[0]
		g.b(17)
		dataCount = g.i(1)[0]
		
		meshList=[]
		for i in range(submeshCount):
			mesh=Mesh()
			mesh.name=str(meshID)
			mesh.TRIANGLE=True
			mesh.matrix=matrix
			meshList.append(mesh)
		
		for n in range(dataCount):
			streamList=[]
			streamID = g.i(1)[0]
			g.b(1)
			submeshCount=g.H(1)[0]
			submeshIDList=g.H(submeshCount)
			nodeType=self.nodeTypeList[self.nodeIDList[streamID]]
			offset=self.getNodeOffset(streamID)
			back=g.tell()
			g.seek(offset)
			regionList=NiDataStream(self)
			g.seek(back)
				
			
			
			
			componentCount = g.i(1)[0]
			for id in range(componentCount):
				name=self.stringList[g.i(1)[0]]
				index=g.i(1)[0]
				print name,
				for m in range(submeshCount):
					mesh=meshList[submeshIDList[m]]
					region=regionList[submeshIDList[m]]
					if name=='INDEX':
						mesh.indiceList.extend(region[id])
					elif name=='POSITION':
						mesh.vertPosList.extend(region[id])
					elif name=='POSITION_BP':
						mesh.vertPosList.extend(region[id])
					elif name=='TEXCOORD':
						mesh.vertUVList.extend(region[id])
					else:pass
			print		
		for mesh in meshList:
			mesh.draw()
			
		g.debug=False
		g.i(g.i(1)[0])
		
	elif self.versionAsNumbers==(1,0,6,20):
		g=self.input
		ID=g.i(1)[0]
		if ID!=-1:
			if self.versionAsNumbers in self.nifFormatListOld:
				name=g.word(ID)
			if self.versionAsNumbers in self.nifFormatListNew:
				name=self.stringList[ID]
		else:
			name=None
			
		for n in range(g.i(1)[0]):
			g.i(1)[0]
		g.b(6)
		#print name
		
		
		
		pos = TranslationMatrix(Vector(g.f(3)))
		rot = Matrix(g.f(3),g.f(3),g.f(3)).invert().resize4x4()
		matrix = rot*pos*parentMatrix
		scale = g.f(1)[0]
		#print 'scale =', scale
		
		
		texList=None
		nProperties = g.i(1)[0]#;print 'nProperties =',nProperties
		for n in range(nProperties):
			ID = g.i(1)[0]
			nodeType=self.nodeTypeList[self.nodeIDList[ID]]
			offset = self.getNodeOffset(ID)
			
			if self.debug==True:
				size=self.nodeSizeList[ID]
				if self.debug==True:
					print '-'*levelID,ID,nodeType,size
			
			back=g.tell()
			g.seek(offset)
			if nodeType == 'NiMaterialProperty':
				NiMaterialProperty(self)
			if nodeType == 'NiTexturingProperty':
				texList=NiTexturingProperty(self,levelID)
			g.seek(back)	
				
				
		collisionObject=g.i(1)[0]	   
		matCount=g.i(1)[0] 
		print 'matCount:',matCount,g.tell()	
		for m in range(matCount):
			g.i(2)
		g.i(1)	  
		g.b(2)#only for version 20,6,0,1
		g.i(1)
		submeshCount = g.H(1)[0]
		
		print 'submeshCount:',submeshCount,g.tell()	
		g.b(17)
		dataCount = g.i(1)[0]
		print 'dataCount:',dataCount,g.tell()	
		
		meshList=[]
		for i in range(submeshCount):
			mesh=Mesh()
			mesh.name=str(meshID)
			mesh.compList=[]
			mesh.TRIANGLE=True
			mesh.matrix=matrix
			meshList.append(mesh)
		
		for n in range(dataCount):
			streamList=[]
			streamID = g.i(1)[0]
			g.b(1)
			submeshCount=g.H(1)[0]
			submeshIDList=g.H(submeshCount)
			nodeType=self.nodeTypeList[self.nodeIDList[streamID]]
			offset=self.getNodeOffset(streamID)
			back=g.tell()
			g.seek(offset)
			regionList=NiDataStream(self)
			g.seek(back)
				
			
			
			
			componentCount = g.i(1)[0]
			for id in range(componentCount):
				name=self.stringList[g.i(1)[0]]
				index=g.i(1)[0]
				print name
				for m in range(submeshCount):
					mesh=meshList[submeshIDList[m]]
					mesh.compList.append(name)
					region=regionList[submeshIDList[m]]
					if name=='INDEX':
						mesh.indiceList.extend(region[id])
					elif name=='POSITION':
						mesh.vertPosList.extend(region[id])
					elif name=='BLENDINDICES':
						mesh.skinIndiceList.extend(region[id])
						#print mesh.skinIndiceList
					elif name=='BLENDWEIGHT':
						mesh.skinWeightList.extend(region[id])
						#print mesh.skinWeightList
					elif name=='BONE_PALETTE':
						skin=Skin()
						skin.boneMap=region[id]
						mesh.skinList.append(skin)
					elif name=='POSITION_BP':
						if 'POSITION' not in mesh.compList:
							mesh.vertPosList.extend(region[id])
					elif name=='TEXCOORD':
						mesh.vertUVList.extend(region[id])
					else:pass
		for mesh in meshList:
			print mesh.compList
			mat=Mat()
			mat.TRIANGLE=True
			mat.ZTRANS=True
			if texList is not None:
					#print texList
					if self.userVersion==196608:					
						texDir=g.dirname.lower().split('characters')[0]+'textures'
						if texList[0] is not None:
							texPath=texDir+os.sep+texList[0].split('.')[0]+'.nif'
							if os.path.exists(texPath)==True:
								#print texPath
								file=open(texPath,'rb')
								p=BinaryReader(file)
								p.debug=False
								#nif=Nif()
								#nif.debug=False
								#nif.input=p
								#nif.explore()
								#file.close()
								mat.diffuse=texDir+os.sep+texList[0].split('.')[0]+'.dds'
					else:
						if texList[0] is not None:
							texDir=g.dirname
							mat.diffuse=texDir+os.sep+texList[0].split('.')[0]+'.dds'
							print mat.diffuse
			mesh.matList.append(mat)				
			#mesh.draw()
			print '#'*50
			print '#'*50,g.tell()
			print len(mesh.vertPosList),len(mesh.vertUVList),len(mesh.indiceList),len(mesh.skinIndiceList),len(mesh.skinWeightList)
			
		g.debug=False
		#g.i(g.i(1)[0])
		
		nProperties = g.i(1)[0]#;print 'nProperties =',nProperties MODIFIRS
		skeleton=None
		for n in range(nProperties):
			ID = g.i(1)[0]
			nodeType=self.nodeTypeList[self.nodeIDList[ID]]
			offset = self.getNodeOffset(ID)
			
			if self.debug==True:
				size=self.nodeSizeList[ID]
				if self.debug==True:
					print '-'*levelID,ID,nodeType,size
			
			back=g.tell()
			g.seek(offset)
			if nodeType == 'NiSkinningMeshModifier':
				skeleton=NiSkinningMeshModifier(self,matrix)
				skeleton.name='bind-'+str(meshID)
				skeleton.draw()
			g.seek(back)
			
			
		for i,mesh in enumerate(meshList):
			if skeleton is not None:				
				mesh.boneNameList=skeleton.boneNameList
			self.meshList.append(mesh)	
		
		
		
	elif self.versionAsNumbers==(2,0,6,20):
		g=self.input
		ID=g.i(1)[0]
		if ID!=-1:
			if self.versionAsNumbers in self.nifFormatListOld:
				name=g.word(ID)
			if self.versionAsNumbers in self.nifFormatListNew:
				name=self.stringList[ID]
		else:
			name=None
			
		for n in range(g.i(1)[0]):
			g.i(1)[0]
		g.b(6)
		#print name
		
		
		
		pos = TranslationMatrix(Vector(g.f(3)))
		rot = Matrix(g.f(3),g.f(3),g.f(3)).invert().resize4x4()
		matrix = rot*pos*parentMatrix
		scale = g.f(1)[0]
		#print 'scale =', scale
		
		
		texList=None
		nProperties = g.i(1)[0]#;print 'nProperties =',nProperties
		for n in range(nProperties):
			ID = g.i(1)[0]
			nodeType=self.nodeTypeList[self.nodeIDList[ID]]
			offset = self.getNodeOffset(ID)
			
			if self.debug==True:
				size=self.nodeSizeList[ID]
				if self.debug==True:
					print '-'*levelID,ID,nodeType,size
			
			back=g.tell()
			g.seek(offset)
			if nodeType == 'NiMaterialProperty':
				NiMaterialProperty(self)
			if nodeType == 'NiTexturingProperty':
				texList=NiTexturingProperty(self,levelID)
			g.seek(back)	
				
				
		collisionObject=g.i(1)[0]	   
		matCount=g.i(1)[0] 
		print 'matCount:',matCount,g.tell()	
		for m in range(matCount):
			g.i(2)
		g.i(1)	  
		g.b(2)#only for version 20,6,0,1
		g.i(1)
		submeshCount = g.H(1)[0]
		
		print 'submeshCount:',submeshCount,g.tell()	
		g.b(17)
		dataCount = g.i(1)[0]
		print 'dataCount:',dataCount,g.tell()	
		
		meshList=[]
		for i in range(submeshCount):
			mesh=Mesh()
			mesh.name=str(meshID)
			mesh.compList=[]
			mesh.TRIANGLE=True
			mesh.matrix=matrix
			meshList.append(mesh)
		
		for n in range(dataCount):
			streamList=[]
			streamID = g.i(1)[0]
			g.b(1)
			submeshCount=g.H(1)[0]
			submeshIDList=g.H(submeshCount)
			nodeType=self.nodeTypeList[self.nodeIDList[streamID]]
			offset=self.getNodeOffset(streamID)
			back=g.tell()
			g.seek(offset)
			regionList=NiDataStream(self)
			g.seek(back)
				
			
			
			
			componentCount = g.i(1)[0]
			for id in range(componentCount):
				name=self.stringList[g.i(1)[0]]
				index=g.i(1)[0]
				print name
				for m in range(submeshCount):
					mesh=meshList[submeshIDList[m]]
					mesh.compList.append(name)
					region=regionList[submeshIDList[m]]
					if name=='INDEX':
						mesh.indiceList.extend(region[id])
					elif name=='POSITION':
						mesh.vertPosList.extend(region[id])
					elif name=='BLENDINDICES':
						mesh.skinIndiceList.extend(region[id])
						#print mesh.skinIndiceList
					elif name=='BLENDWEIGHT':
						mesh.skinWeightList.extend(region[id])
						#print mesh.skinWeightList
					elif name=='BONE_PALETTE':
						skin=Skin()
						skin.boneMap=region[id]
						mesh.skinList.append(skin)
					elif name=='POSITION_BP':
						if 'POSITION' not in mesh.compList:
							mesh.vertPosList.extend(region[id])
					elif name=='TEXCOORD':
						mesh.vertUVList.extend(region[id])
					else:pass
		for mesh in meshList:
			print mesh.compList
			mat=Mat()
			mat.TRIANGLE=True
			mat.ZTRANS=True
			if texList is not None:
					#print texList
					if self.userVersion==196608:					
						texDir=g.dirname.lower().split('characters')[0]+'textures'
						if texList[0] is not None:
							texPath=texDir+os.sep+texList[0].split('.')[0]+'.nif'
							if os.path.exists(texPath)==True:
								#print texPath
								file=open(texPath,'rb')
								p=BinaryReader(file)
								p.debug=False
								#nif=Nif()
								#nif.debug=False
								#nif.input=p
								#nif.explore()
								#file.close()
								mat.diffuse=texDir+os.sep+texList[0].split('.')[0]+'.dds'
					else:
						if texList[0] is not None:
							texDir=g.dirname
							mat.diffuse=texDir+os.sep+texList[0].split('.')[0]+'.dds'
							print mat.diffuse
			mesh.matList.append(mat)				
			#mesh.draw()
			print '#'*50
			print '#'*50,g.tell()
			print len(mesh.vertPosList),len(mesh.vertUVList),len(mesh.indiceList),len(mesh.skinIndiceList),len(mesh.skinWeightList)
			
		g.debug=False
		#g.i(g.i(1)[0])
		
		nProperties = g.i(1)[0]#;print 'nProperties =',nProperties MODIFIRS
		skeleton=None
		for n in range(nProperties):
			ID = g.i(1)[0]
			nodeType=self.nodeTypeList[self.nodeIDList[ID]]
			offset = self.getNodeOffset(ID)
			
			if self.debug==True:
				size=self.nodeSizeList[ID]
				if self.debug==True:
					print '-'*levelID,ID,nodeType,size
			
			back=g.tell()
			g.seek(offset)
			if nodeType == 'NiSkinningMeshModifier':
				skeleton=NiSkinningMeshModifier(self,matrix)
				skeleton.name='bind-'+str(meshID)
				skeleton.draw()
			g.seek(back)
			
			
		for i,mesh in enumerate(meshList):
			if skeleton is not None:				
				mesh.boneNameList=skeleton.boneNameList
			self.meshList.append(mesh)	
		
		
	else:
		print 'NiMesh:',self.versionAsNumbers,'not supported'