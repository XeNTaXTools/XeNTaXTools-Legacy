import newGameLib
from newGameLib import *
import Blender


def nifParser(filename,g):	
	nif=Nif()
	nif.input=g
	nif.debug=True
	nif.explore()
	if len(nif.meshList)>0:
		nif.skeleton.draw()
		for mesh in nif.meshList:
			mesh.draw()
			
	else:	
		nif.skeleton.name='pose'
		#nif.skeleton.BINDMESH=True
		nif.skeleton.draw()
		scene = bpy.data.scenes.active
		for meshObject in scene.objects:
			if meshObject.type=='Mesh':
				if '.' in meshObject.name:
					id=meshObject.name.split('.')[0]
				else:
					id=meshObject.name
				for armatureObject in scene.objects:
					if armatureObject.type=='Armature':
						if armatureObject.name=='bind-'+id:			
							bindSkeleton=armatureObject
							poseSkeleton=Blender.Object.Get('pose')
							bindPose(bindSkeleton,poseSkeleton,meshObject)	
								
		
		
			
def Parser():
	filename=input.filename
	ext=filename.split('.')[-1].lower()
		
	
	if ext=='nif':
		file=open(filename,'rb')
		g=BinaryReader(file)
		g.logOpen()
		nifParser(filename,g)
		g.logClose()
		file.close()
			
 
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
	
Blender.Window.FileSelector(openFile,'import','nif - Gamebryo file') 
	