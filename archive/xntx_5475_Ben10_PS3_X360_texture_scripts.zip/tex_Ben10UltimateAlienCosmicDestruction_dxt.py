from inc_noesis import *

def registerNoesisTypes():
    ps3 = noesis.register("Ben 10 Ultimate Alien: Cosmic Destruction (PS3)", ".ps3dxt")
    noesis.setHandlerTypeCheck(ps3, ps3dxtCheckType)
    noesis.setHandlerLoadRGBA(ps3, ps3dxtLoadRGBA)

    xbx = noesis.register("Ben 10 Ultimate Alien: Cosmic Destruction (X360)", ".xbxdxt")
    noesis.setHandlerTypeCheck(xbx, xbxdxtCheckType)
    noesis.setHandlerLoadRGBA(xbx, xbxdxtLoadRGBA)
    #noesis.logPopup()
    return 1

#check if it's this type based on the data
def ps3dxtCheckType(data):
    bs = NoeBitStream(data)
    Magic = bs.readBytes(4)
    if Magic != b'\x90\x43\x40\x00':
        return 0
    return 1
	
def ps3dxtLoadRGBA(data, texList):
    datasize = len(data) - 0x80        
    bs = NoeBitStream(data, NOE_BIGENDIAN)
    bs.seek(0x06, NOESEEK_ABS)
    imgWidth = bs.readUShort()            
    imgHeight = bs.readUShort()           
    bs.seek(0x80, NOESEEK_ABS)        
    data = bs.readBytes(datasize)      
    texFmt = noesis.NOESISTEX_DXT1
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1
    

#check if it's this type based on the data
def xbxdxtCheckType(data):
    bs = NoeBitStream(data)
    Magic = bs.readBytes(4)
    if Magic != b'\x90\x43\x40\x00':
        return 0
    return 1
	
def xbxdxtLoadRGBA(data, texList):
    datasize = len(data) - 0x80        
    bs = NoeBitStream(data, NOE_BIGENDIAN)
    bs.seek(0x06, NOESEEK_ABS)
    imgWidth = bs.readUShort()            
    imgHeight = bs.readUShort()           
    bs.seek(0x80, NOESEEK_ABS)        
    data = bs.readBytes(datasize)      
    data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 8)
    texFmt = noesis.NOESISTEX_DXT1
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1