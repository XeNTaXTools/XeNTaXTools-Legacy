Public Structure Zone66Ship
    Dim Padding() As Byte ' 36 bytes
    Dim PayLoad As Byte
    Dim Fuel As Byte
    Dim Acc As Byte
    Dim Turning As Byte
    Dim TopSpeed As Byte
    Dim Armor As Byte
    Dim Gun1 As Byte ' Total should be 43 bytes.
End Structure