Public Class frmEdit
#Region " Private Constants "
    Private Const StructSize As Integer = 43
#End Region
    ' this is just a simple example, you'd want
    ' to validate input better, but that takes
    ' to much time for this simple example
#Region " Public Properties "
    Public Property PayLoad() As Byte
        Get
            Return GetByteFromString(txtPayLoad.Text)
        End Get
        Set(ByVal value As Byte)
            txtPayLoad.Text = value.ToString
        End Set
    End Property
    Public Property Fuel() As Byte
        Get
            Return GetByteFromString(txtFuel.Text)
        End Get
        Set(ByVal value As Byte)
            txtFuel.Text = value.ToString
        End Set
    End Property
    Public Property Acc() As Byte
        Get
            Return GetByteFromString(txtAcc.Text)
        End Get
        Set(ByVal value As Byte)
            txtAcc.Text = value.ToString
        End Set
    End Property
    Public Property Turning() As Byte
        Get
            Return GetByteFromString(txtTurning.Text)
        End Get
        Set(ByVal value As Byte)
            txtTurning.Text = value.ToString
        End Set
    End Property
    Public Property TopSpeed() As Byte
        Get
            Return GetByteFromString(txtTopSpeed.Text)
        End Get
        Set(ByVal value As Byte)
            txtTopSpeed.Text = value.ToString
        End Set
    End Property
    Public Property Armor() As Byte
        Get
            Return GetByteFromString(txtArmor.Text)
        End Get
        Set(ByVal value As Byte)
            txtArmor.Text = value.ToString
        End Set
    End Property
    Public Property Gun1() As Byte
        Get
            Return GetByteFromString(txtGun1.Text)
        End Get
        Set(ByVal value As Byte)
            txtGun1.Text = value.ToString
        End Set
    End Property
    ' This smart property ensures you maximum flexibility
    ' with geting and setting the values various ways
    Public Property Zone66Ship() As Zone66Ship
        Get
            Dim Result As New Zone66Ship
            Result.PayLoad = PayLoad
            Result.Fuel = Fuel
            Result.Acc = Acc
            Result.Turning = Turning
            Result.Armor = Armor
            Result.Gun1 = Gun1
            Return Result
        End Get
        Set(ByVal value As Zone66Ship)
            PayLoad = value.PayLoad
            Fuel = value.Fuel
            Acc = value.Acc
            Turning = value.Turning
            Armor = value.Armor
            Gun1 = value.Gun1
        End Set
    End Property
#End Region
#Region " Help Functions "
    Private Function GetByteFromString(ByVal Value As String) As Byte
        Dim Result As Byte
        ' If TryParse fails, Result becomes 0
        If Not Byte.TryParse(txtPayLoad.Text, Result) Then
            Debug.WriteLine(String.Format("'{0}' is not a valid byte", txtPayLoad))
        End If
        Return Result
    End Function
#End Region
#Region " Event Handlers "
    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        ReadNextShip()
    End Sub
    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        'TODO: write routine to write back the changes
        ReadNextShip()
    End Sub
#End Region

#Region " Functions "
    Private StreamPos As Int64 = 0
    Private sourcefile As String
    Private Function ReadNextShip() As Zone66Ship
        Dim Result As New Zone66Ship
        If Not String.IsNullOrEmpty(SourceFile) Then
            Me.Zone66Ship = GetZone66Ship(sourcefile, StreamPos)
        Else
            MsgBox("No source file was selected")
            ' pick a new file
            sourcefile = BrowseForFile("C:\", "zone66 files (*.z66)|*.z66")
        End If
        Return Result
    End Function
    ' notice the ByRef, this means there is a pointer to the variable, this allows us to update the variable
    Private Function GetZone66Ship(ByVal FileName As String, ByRef StartPosition As Int64) As Zone66Ship
        Dim Result As New Zone66Ship
        If System.IO.File.Exists(FileName) Then
            ' The "Using" constructor ensures us that
            ' if something goes wrong, everything will be handled as it should
            ' (Handles get closed, memory is released, this is because of the IDisposable interface).
            Using BR As New IO.BinaryReader(New IO.FileStream(FileName, IO.FileMode.Open))
                If StartPosition < BR.BaseStream.Length Then
                    If BR.BaseStream.Length >= StructSize + BR.BaseStream.Position Then
                        ' Jump to the position in memory
                        BR.BaseStream.Seek(StartPosition, IO.SeekOrigin.Begin)
                        Result.Padding = BR.ReadBytes(36)
                        Result.PayLoad = BR.ReadByte
                        Result.Fuel = BR.ReadByte
                        Result.Acc = BR.ReadByte
                        Result.Turning = BR.ReadByte
                        Result.TopSpeed = BR.ReadByte
                        Result.Armor = BR.ReadByte
                        Result.Gun1 = BR.ReadByte
                        ' Update the ByRef variable to hold the current position
                        StartPosition = BR.BaseStream.Position
                    Else
                        MsgBox("Not enough bytes left to read")
                        ' Reset source file to trigger new file browsing
                        sourcefile = String.Empty
                    End If
                Else
                    MsgBox(String.Format("The position {0} lies beyond the length of file File '{1}' (MAX = {2})!", StartPosition, FileName, BR.BaseStream.Length))
                    ' Reset source file to trigger new file browsing
                    sourcefile = String.Empty
                End If
            End Using
        Else
            MsgBox(String.Format("File '{0}' does not exist!", FileName))
            ' Reset source file to trigger new file browsing
            sourcefile = String.Empty
        End If
        Return Result
    End Function
#End Region
#Region " Helper Functions "
    Private Function BrowseForFile(ByVal InitialDir As String, ByVal Filter As String) As String
        ' Initialize Result to avoid warnings since we will return
        ' this variable, even if a user doesn't select a file
        Dim Result As String = String.Empty
        ' Create a new OpenFileDialog
        Dim ofd As New OpenFileDialog()
        ' Set the specified Start directory
        ofd.InitialDirectory = InitialDir
        ' Set the file filter
        ofd.Filter = Filter
        ' Make sure that if this function get's called again,
        ' the previous selected folder will be the next base dir
        ofd.RestoreDirectory = True
        ' Calling ShowDialog() returns a Dialog result.
        ' We should only take action if the user pressed OK to select
        ' the file. There is no need to do a check afterwards if 
        ' the file exists (as you would do when normaly accepting
        ' file input, since this OFD does these checks for us).
        If ofd.ShowDialog = Windows.Forms.DialogResult.OK Then
            Result = ofd.FileName
        End If
        ' Return the result variable, which could be empty, or hold the filename
        Return Result
    End Function
    Private Function BrowseForFileSteam(ByVal InitialDir As String, ByVal Filter As String) As System.IO.Stream
        ' Initialize Result to avoid warnings since we will return
        ' this variable, even if a user doesn't select a file
        Dim Result As System.IO.Stream = Nothing
        ' Create a new OpenFileDialog
        Dim ofd As New OpenFileDialog()
        ' Set the specified Start directory
        ofd.InitialDirectory = InitialDir
        ' Set the file filter
        ofd.Filter = Filter
        ' Make sure that if this function get's called again,
        ' the previous selected folder will be the next base dir
        ofd.RestoreDirectory = True
        ' Calling ShowDialog() returns a Dialog result.
        ' We should only take action if the user pressed OK to select
        ' the file. There is no need to do a check afterwards if 
        ' the file exists (as you would do when normaly accepting
        ' file input, since this OFD does these checks for us).
        If ofd.ShowDialog = Windows.Forms.DialogResult.OK Then
            Result = ofd.OpenFile
        End If
        ' Return the result variable, which could be empty, or hold the filename
        Return Result
    End Function
#End Region

    Private Sub frmEdit_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' select a source file on load
        sourcefile = BrowseForFile("C:\", "zone66 files (*.z66)|*.z66")
    End Sub
End Class