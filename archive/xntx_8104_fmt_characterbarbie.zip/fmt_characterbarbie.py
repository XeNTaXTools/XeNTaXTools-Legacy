#by Durik256 for xentax
#game:barbie dreamhouse party
#only for characterbarbie.hnk
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("characterbarbie",".hnk")
    noesis.setHandlerTypeCheck(handle, CheckType)
    noesis.setHandlerLoadModel(handle, LoadModel)    
    return 1
    
def CheckType(data):
    return 1

def LoadModel(data, mdlList):
    bs = NoeBitStream(data)

    #114-end_Block;2-unk;28-unk;29-vbuf;30-ibuf;112-header;113-name;4101-anim;4123-mdl_info;4432-mat?;8529-tx
    fsize = bs.getSize()
    while bs.getOffset() < fsize:
        size, type, unk = bs.readInt(), bs.readShort(), bs.readShort()
        print(size, type, 'offset:',bs.getOffset())
        bs.seek(size,1)
    
    #[ibuf_offset,num_indices,vbuf_offset,num_vert,stride]
    meshes = [[0xFBDC0,288,0xF9FF8,76,56],[0xFC000,252,0xFB098,60,56],[0x1381F0,1416,0xFC200,358,72],[0x138D00,6432,0x1026B0,1750,72],[0x13BF40,1134,0x1212E0,245,72],[0x13C81C,5022,0x1257C8,1060,72]]
    
    ctx = rapi.rpgCreateContext()
    for x in meshes:
        bs.seek(x[0])
        ibuf = bs.readBytes(x[1]*2)
        bs.seek(x[2])
        vbuf = bs.readBytes(x[3]*x[4])
    
        rapi.rpgSetEndian(1)
        rapi.rpgSetName(str(x[0]))
        rapi.rpgBindPositionBuffer(vbuf, noesis.RPGEODATA_FLOAT, x[4])
        rapi.rpgBindUV1BufferOfs(vbuf, noesis.RPGEODATA_FLOAT, x[4], 44 if x[4]==72 else 28) 
        rapi.rpgCommitTriangles(ibuf, noesis.RPGEODATA_SHORT, x[1], noesis.RPGEO_TRIANGLE)

    mdl = rapi.rpgConstructModel()
    mdlList.append(mdl)
    return 1