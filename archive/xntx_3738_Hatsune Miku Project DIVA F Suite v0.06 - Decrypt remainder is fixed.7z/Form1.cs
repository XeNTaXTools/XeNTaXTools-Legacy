﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Hatsune_Miku_Project_DIVA_F_Suite
{
    public partial class Form1 : Form
    {
        int bp = 0;

        //Looks like key data block
        byte[] keyData = 
        {
            #region key data
            0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00, 0x00, 
            0x70, 0x72, 0x6F, 0x6A, 0x65, 0x63, 0x74, 0x5F, 0x64, 0x69, 0x76, 0x61, 0x2E, 0x62, 0x69, 0x6E, 
            0xDB, 0x8B, 0xF0, 0x5B, 0xBE, 0xE8, 0x84, 0x04, 0xDA, 0x81, 0xF2, 0x65, 0xF4, 0xE3, 0x9B, 0x0B, 
            0xC8, 0x9F, 0xDB, 0xE4, 0x76, 0x77, 0x5F, 0xE0, 0xAC, 0xF6, 0xAD, 0x85, 0x58, 0x15, 0x36, 0x8E, 
            0x95, 0x9A, 0xC2, 0x8E, 0xE3, 0xED, 0x9D, 0x6E, 0x4F, 0x1B, 0x30, 0xEB, 0x17, 0x0E, 0x06, 0x65, 
            0x36, 0xF5, 0x8F, 0x7E, 0xD5, 0x18, 0x12, 0x10, 0x9A, 0x03, 0x22, 0xFB, 0x8D, 0x0D, 0x24, 0x9E, 
            0xF1, 0xC3, 0x84, 0x23, 0x24, 0xDB, 0x96, 0x33, 0xBE, 0xD8, 0xB4, 0xC8, 0x33, 0xD5, 0x90, 0x56, 
            0xD2, 0xA3, 0x35, 0xE0, 0xF6, 0x78, 0xA3, 0xD3, 0x48, 0xA0, 0x17, 0x1B, 0x7B, 0x75, 0x87, 0x4D, 
            0x0F, 0xB4, 0xD6, 0xC1, 0xF9, 0xCC, 0x75, 0x12, 0xB1, 0x6C, 0x62, 0x09, 0xCA, 0x19, 0xE5, 0x44, 
            0x5B, 0x6D, 0xCD, 0xB5, 0xA2, 0xA1, 0xB8, 0xA7, 0x13, 0xCD, 0xDA, 0xAE, 0xD9, 0xD4, 0x3F, 0xEA, 
            0x08, 0x18, 0x4A, 0x80, 0xAA, 0xB9, 0xF2, 0x27, 0xB9, 0x74, 0x28, 0x89, 0x60, 0xA0, 0x17, 0x63, 
            0xDE, 0xE8, 0xB1, 0x50, 0x74, 0x51, 0x43, 0x77, 0xCD, 0x25, 0x6B, 0xFE, 0xAD, 0x85, 0x7C, 0x9D, 
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
            0x70, 0x72, 0x6F, 0x6A, 0x65, 0x63, 0x74, 0x5F, 0x64, 0x69, 0x76, 0x61, 0x2E, 0x62, 0x69, 0x6E, 
            0xB5, 0x72, 0x73, 0x4F, 0xC6, 0x91, 0x4B, 0xCA, 0x3A, 0x2C, 0x91, 0x4B, 0xAE, 0x4D, 0xD4, 0xB0, 
            0x2F, 0xE5, 0xEC, 0x4E, 0xE9, 0x74, 0xA7, 0x84, 0xD3, 0x58, 0x36, 0xCF, 0x7D, 0x15, 0xE2, 0x7F, 
            0xA1, 0x17, 0x70, 0x85, 0x48, 0x63, 0xD7, 0x01, 0x9B, 0x3B, 0xE1, 0xCE, 0xE6, 0x2E, 0x03, 0xB1, 
            0xC0, 0xA2, 0x1D, 0x4D, 0x88, 0xC1, 0xCA, 0x4C, 0x13, 0xFA, 0x2B, 0x82, 0xF5, 0xD4, 0x28, 0x33, 
            0x0B, 0xB1, 0x4F, 0x60, 0x83, 0x70, 0x85, 0x2C, 0x90, 0x8A, 0xAE, 0xAE, 0x65, 0x5E, 0x86, 0x9D, 
            0x72, 0x70, 0xC6, 0x60, 0xF1, 0x00, 0x43, 0x4C, 0x61, 0x8A, 0xED, 0xE2, 0x04, 0xD4, 0x6B, 0x7F, 
            0x90, 0x04, 0x0A, 0x32, 0x61, 0x04, 0x49, 0x7E, 0x00, 0x8E, 0xA4, 0x9C, 0x04, 0x5A, 0xCF, 0xE3, 
            0x51, 0x73, 0x5B, 0x37, 0x30, 0x77, 0x12, 0x49, 0x30, 0xF9, 0xB6, 0xD5, 0x34, 0xA3, 0x79, 0x36, 
            0x6B, 0xBA, 0x86, 0x8D, 0x5B, 0xCD, 0x94, 0xC4, 0x6B, 0x34, 0x22, 0x11, 0x5F, 0x97, 0x5B, 0x27, 
            0xDE, 0xE8, 0xB1, 0x50, 0x74, 0x51, 0x43, 0x77, 0xCD, 0x25, 0x6B, 0xFE, 0xAD, 0x85, 0x7C, 0x9D, 
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
            #endregion
        };

        //Looks like v1.00 static sbox
        byte[] sbox_v100 = 
        {
            #region sbox v1.00
            0x63, 0x7C, 0x77, 0x7B, 0xF2, 0x6B, 0x6F, 0xC5, 0x30, 0x01, 0x67, 0x2B, 0xFE, 0xD7, 0xAB, 0x76, 
            0xCA, 0x82, 0xC9, 0x7D, 0xFA, 0x59, 0x47, 0xF0, 0xAD, 0xD4, 0xA2, 0xAF, 0x9C, 0xA4, 0x72, 0xC0, 
            0xB7, 0xFD, 0x93, 0x26, 0x36, 0x3F, 0xF7, 0xCC, 0x34, 0xA5, 0xE5, 0xF1, 0x71, 0xD8, 0x31, 0x15, 
            0x04, 0xC7, 0x23, 0xC3, 0x18, 0x96, 0x05, 0x9A, 0x07, 0x12, 0x80, 0xE2, 0xEB, 0x27, 0xB2, 0x75, 
            0x09, 0x83, 0x2C, 0x1A, 0x1B, 0x6E, 0x5A, 0xA0, 0x52, 0x3B, 0xD6, 0xB3, 0x29, 0xE3, 0x2F, 0x84, 
            0x53, 0xD1, 0x00, 0xED, 0x20, 0xFC, 0xB1, 0x5B, 0x6A, 0xCB, 0xBE, 0x39, 0x4A, 0x4C, 0x58, 0xCF, 
            0xD0, 0xEF, 0xAA, 0xFB, 0x43, 0x4D, 0x33, 0x85, 0x45, 0xF9, 0x02, 0x7F, 0x50, 0x3C, 0x9F, 0xA8, 
            0x51, 0xA3, 0x40, 0x8F, 0x92, 0x9D, 0x38, 0xF5, 0xBC, 0xB6, 0xDA, 0x21, 0x10, 0xFF, 0xF3, 0xD2, 
            0xCD, 0x0C, 0x13, 0xEC, 0x5F, 0x97, 0x44, 0x17, 0xC4, 0xA7, 0x7E, 0x3D, 0x64, 0x5D, 0x19, 0x73, 
            0x60, 0x81, 0x4F, 0xDC, 0x22, 0x2A, 0x90, 0x88, 0x46, 0xEE, 0xB8, 0x14, 0xDE, 0x5E, 0x0B, 0xDB, 
            0xE0, 0x32, 0x3A, 0x0A, 0x49, 0x06, 0x24, 0x5C, 0xC2, 0xD3, 0xAC, 0x62, 0x91, 0x95, 0xE4, 0x79, 
            0xE7, 0xC8, 0x37, 0x6D, 0x8D, 0xD5, 0x4E, 0xA9, 0x6C, 0x56, 0xF4, 0xEA, 0x65, 0x7A, 0xAE, 0x08, 
            0xBA, 0x78, 0x25, 0x2E, 0x1C, 0xA6, 0xB4, 0xC6, 0xE8, 0xDD, 0x74, 0x1F, 0x4B, 0xBD, 0x8B, 0x8A, 
            0x70, 0x3E, 0xB5, 0x66, 0x48, 0x03, 0xF6, 0x0E, 0x61, 0x35, 0x57, 0xB9, 0x86, 0xC1, 0x1D, 0x9E, 
            0xE1, 0xF8, 0x98, 0x11, 0x69, 0xD9, 0x8E, 0x94, 0x9B, 0x1E, 0x87, 0xE9, 0xCE, 0x55, 0x28, 0xDF, 
            0x8C, 0xA1, 0x89, 0x0D, 0xBF, 0xE6, 0x42, 0x68, 0x41, 0x99, 0x2D, 0x0F, 0xB0, 0x54, 0xBB, 0x16, 
            0x52, 0x09, 0x6A, 0xD5, 0x30, 0x36, 0xA5, 0x38, 0xBF, 0x40, 0xA3, 0x9E, 0x81, 0xF3, 0xD7, 0xFB, 
            0x7C, 0xE3, 0x39, 0x82, 0x9B, 0x2F, 0xFF, 0x87, 0x34, 0x8E, 0x43, 0x44, 0xC4, 0xDE, 0xE9, 0xCB, 
            0x54, 0x7B, 0x94, 0x32, 0xA6, 0xC2, 0x23, 0x3D, 0xEE, 0x4C, 0x95, 0x0B, 0x42, 0xFA, 0xC3, 0x4E, 
            0x08, 0x2E, 0xA1, 0x66, 0x28, 0xD9, 0x24, 0xB2, 0x76, 0x5B, 0xA2, 0x49, 0x6D, 0x8B, 0xD1, 0x25, 
            0x72, 0xF8, 0xF6, 0x64, 0x86, 0x68, 0x98, 0x16, 0xD4, 0xA4, 0x5C, 0xCC, 0x5D, 0x65, 0xB6, 0x92, 
            0x6C, 0x70, 0x48, 0x50, 0xFD, 0xED, 0xB9, 0xDA, 0x5E, 0x15, 0x46, 0x57, 0xA7, 0x8D, 0x9D, 0x84, 
            0x90, 0xD8, 0xAB, 0x00, 0x8C, 0xBC, 0xD3, 0x0A, 0xF7, 0xE4, 0x58, 0x05, 0xB8, 0xB3, 0x45, 0x06, 
            0xD0, 0x2C, 0x1E, 0x8F, 0xCA, 0x3F, 0x0F, 0x02, 0xC1, 0xAF, 0xBD, 0x03, 0x01, 0x13, 0x8A, 0x6B, 
            0x3A, 0x91, 0x11, 0x41, 0x4F, 0x67, 0xDC, 0xEA, 0x97, 0xF2, 0xCF, 0xCE, 0xF0, 0xB4, 0xE6, 0x73, 
            0x96, 0xAC, 0x74, 0x22, 0xE7, 0xAD, 0x35, 0x85, 0xE2, 0xF9, 0x37, 0xE8, 0x1C, 0x75, 0xDF, 0x6E, 
            0x47, 0xF1, 0x1A, 0x71, 0x1D, 0x29, 0xC5, 0x89, 0x6F, 0xB7, 0x62, 0x0E, 0xAA, 0x18, 0xBE, 0x1B, 
            0xFC, 0x56, 0x3E, 0x4B, 0xC6, 0xD2, 0x79, 0x20, 0x9A, 0xDB, 0xC0, 0xFE, 0x78, 0xCD, 0x5A, 0xF4, 
            0x1F, 0xDD, 0xA8, 0x33, 0x88, 0x07, 0xC7, 0x31, 0xB1, 0x12, 0x10, 0x59, 0x27, 0x80, 0xEC, 0x5F, 
            0x60, 0x51, 0x7F, 0xA9, 0x19, 0xB5, 0x4A, 0x0D, 0x2D, 0xE5, 0x7A, 0x9F, 0x93, 0xC9, 0x9C, 0xEF, 
            0xA0, 0xE0, 0x3B, 0x4D, 0xAE, 0x2A, 0xF5, 0xB0, 0xC8, 0xEB, 0xBB, 0x3C, 0x83, 0x53, 0x99, 0x61, 
            0x17, 0x2B, 0x04, 0x7E, 0xBA, 0x77, 0xD6, 0x26, 0xE1, 0x69, 0x14, 0x63, 0x55, 0x21, 0x0C, 0x7D
            #endregion
        };

        byte[] sbox2 = 
        {
            #region s2
            0x63, 0x7C, 0x77, 0x7B, 0xF2, 0x6B, 0x6F, 0xC5, 0x30, 0x01, 0x67, 0x2B, 0xFE, 0xD7, 0xAB, 0x76, 
            0xCA, 0x82, 0xC9, 0x7D, 0xFA, 0x59, 0x47, 0xF0, 0xAD, 0xD4, 0xA2, 0xAF, 0x9C, 0xA4, 0x72, 0xC0, 
            0xB7, 0xFD, 0x93, 0x26, 0x36, 0x3F, 0xF7, 0xCC, 0x34, 0xA5, 0xE5, 0xF1, 0x71, 0xD8, 0x31, 0x15, 
            0x04, 0xC7, 0x23, 0xC3, 0x18, 0x96, 0x05, 0x9A, 0x07, 0x12, 0x80, 0xE2, 0xEB, 0x27, 0xB2, 0x75, 
            0x09, 0x83, 0x2C, 0x1A, 0x1B, 0x6E, 0x5A, 0xA0, 0x52, 0x3B, 0xD6, 0xB3, 0x29, 0xE3, 0x2F, 0x84, 
            0x53, 0xD1, 0x00, 0xED, 0x20, 0xFC, 0xB1, 0x5B, 0x6A, 0xCB, 0xBE, 0x39, 0x4A, 0x4C, 0x58, 0xCF, 
            0xD0, 0xEF, 0xAA, 0xFB, 0x43, 0x4D, 0x33, 0x85, 0x45, 0xF9, 0x02, 0x7F, 0x50, 0x3C, 0x9F, 0xA8, 
            0x51, 0xA3, 0x40, 0x8F, 0x92, 0x9D, 0x38, 0xF5, 0xBC, 0xB6, 0xDA, 0x21, 0x10, 0xFF, 0xF3, 0xD2, 
            0xCD, 0x0C, 0x13, 0xEC, 0x5F, 0x97, 0x44, 0x17, 0xC4, 0xA7, 0x7E, 0x3D, 0x64, 0x5D, 0x19, 0x73, 
            0x60, 0x81, 0x4F, 0xDC, 0x22, 0x2A, 0x90, 0x88, 0x46, 0xEE, 0xB8, 0x14, 0xDE, 0x5E, 0x0B, 0xDB, 
            0xE0, 0x32, 0x3A, 0x0A, 0x49, 0x06, 0x24, 0x5C, 0xC2, 0xD3, 0xAC, 0x62, 0x91, 0x95, 0xE4, 0x79, 
            0xE7, 0xC8, 0x37, 0x6D, 0x8D, 0xD5, 0x4E, 0xA9, 0x6C, 0x56, 0xF4, 0xEA, 0x65, 0x7A, 0xAE, 0x08, 
            0xBA, 0x78, 0x25, 0x2E, 0x1C, 0xA6, 0xB4, 0xC6, 0xE8, 0xDD, 0x74, 0x1F, 0x4B, 0xBD, 0x8B, 0x8A, 
            0x70, 0x3E, 0xB5, 0x66, 0x48, 0x03, 0xF6, 0x0E, 0x61, 0x35, 0x57, 0xB9, 0x86, 0xC1, 0x1D, 0x9E, 
            0xE1, 0xF8, 0x98, 0x11, 0x69, 0xD9, 0x8E, 0x94, 0x9B, 0x1E, 0x87, 0xE9, 0xCE, 0x55, 0x28, 0xDF, 
            0x8C, 0xA1, 0x89, 0x0D, 0xBF, 0xE6, 0x42, 0x68, 0x41, 0x99, 0x2D, 0x0F, 0xB0, 0x54, 0xBB, 0x16, 
            0x52, 0x09, 0x6A, 0xD5, 0x30, 0x36, 0xA5, 0x38, 0xBF, 0x40, 0xA3, 0x9E, 0x81, 0xF3, 0xD7, 0xFB, 
            0x7C, 0xE3, 0x39, 0x82, 0x9B, 0x2F, 0xFF, 0x87, 0x34, 0x8E, 0x43, 0x44, 0xC4, 0xDE, 0xE9, 0xCB, 
            0x54, 0x7B, 0x94, 0x32, 0xA6, 0xC2, 0x23, 0x3D, 0xEE, 0x4C, 0x95, 0x0B, 0x42, 0xFA, 0xC3, 0x4E, 
            0x08, 0x2E, 0xA1, 0x66, 0x28, 0xD9, 0x24, 0xB2, 0x76, 0x5B, 0xA2, 0x49, 0x6D, 0x8B, 0xD1, 0x25, 
            0x72, 0xF8, 0xF6, 0x64, 0x86, 0x68, 0x98, 0x16, 0xD4, 0xA4, 0x5C, 0xCC, 0x5D, 0x65, 0xB6, 0x92, 
            0x6C, 0x70, 0x48, 0x50, 0xFD, 0xED, 0xB9, 0xDA, 0x5E, 0x15, 0x46, 0x57, 0xA7, 0x8D, 0x9D, 0x84, 
            0x90, 0xD8, 0xAB, 0x00, 0x8C, 0xBC, 0xD3, 0x0A, 0xF7, 0xE4, 0x58, 0x05, 0xB8, 0xB3, 0x45, 0x06, 
            0xD0, 0x2C, 0x1E, 0x8F, 0xCA, 0x3F, 0x0F, 0x02, 0xC1, 0xAF, 0xBD, 0x03, 0x01, 0x13, 0x8A, 0x6B, 
            0x3A, 0x91, 0x11, 0x41, 0x4F, 0x67, 0xDC, 0xEA, 0x97, 0xF2, 0xCF, 0xCE, 0xF0, 0xB4, 0xE6, 0x73, 
            0x96, 0xAC, 0x74, 0x22, 0xE7, 0xAD, 0x35, 0x85, 0xE2, 0xF9, 0x37, 0xE8, 0x1C, 0x75, 0xDF, 0x6E, 
            0x47, 0xF1, 0x1A, 0x71, 0x1D, 0x29, 0xC5, 0x89, 0x6F, 0xB7, 0x62, 0x0E, 0xAA, 0x18, 0xBE, 0x1B, 
            0xFC, 0x56, 0x3E, 0x4B, 0xC6, 0xD2, 0x79, 0x20, 0x9A, 0xDB, 0xC0, 0xFE, 0x78, 0xCD, 0x5A, 0xF4, 
            0x1F, 0xDD, 0xA8, 0x33, 0x88, 0x07, 0xC7, 0x31, 0xB1, 0x12, 0x10, 0x59, 0x27, 0x80, 0xEC, 0x5F, 
            0x60, 0x51, 0x7F, 0xA9, 0x19, 0xB5, 0x4A, 0x0D, 0x2D, 0xE5, 0x7A, 0x9F, 0x93, 0xC9, 0x9C, 0xEF, 
            0xA0, 0xE0, 0x3B, 0x4D, 0xAE, 0x2A, 0xF5, 0xB0, 0xC8, 0xEB, 0xBB, 0x3C, 0x83, 0x53, 0x99, 0x61, 
            0x17, 0x2B, 0x04, 0x7E, 0xBA, 0x77, 0xD6, 0x26, 0xE1, 0x69, 0x14, 0x63, 0x55, 0x21, 0x0C, 0x7D, 
            0x00, 0x00, 0x00, 0x00, 0x02, 0x01, 0x01, 0x03, 0x04, 0x02, 0x02, 0x06, 0x06, 0x03, 0x03, 0x05, 
            0x08, 0x04, 0x04, 0x0C, 0x0A, 0x05, 0x05, 0x0F, 0x0C, 0x06, 0x06, 0x0A, 0x0E, 0x07, 0x07, 0x09, 
            0x10, 0x08, 0x08, 0x18, 0x12, 0x09, 0x09, 0x1B, 0x14, 0x0A, 0x0A, 0x1E, 0x16, 0x0B, 0x0B, 0x1D, 
            0x18, 0x0C, 0x0C, 0x14, 0x1A, 0x0D, 0x0D, 0x17, 0x1C, 0x0E, 0x0E, 0x12, 0x1E, 0x0F, 0x0F, 0x11, 
            0x20, 0x10, 0x10, 0x30, 0x22, 0x11, 0x11, 0x33, 0x24, 0x12, 0x12, 0x36, 0x26, 0x13, 0x13, 0x35, 
            0x28, 0x14, 0x14, 0x3C, 0x2A, 0x15, 0x15, 0x3F, 0x2C, 0x16, 0x16, 0x3A, 0x2E, 0x17, 0x17, 0x39, 
            0x30, 0x18, 0x18, 0x28, 0x32, 0x19, 0x19, 0x2B, 0x34, 0x1A, 0x1A, 0x2E, 0x36, 0x1B, 0x1B, 0x2D, 
            0x38, 0x1C, 0x1C, 0x24, 0x3A, 0x1D, 0x1D, 0x27, 0x3C, 0x1E, 0x1E, 0x22, 0x3E, 0x1F, 0x1F, 0x21, 
            0x40, 0x20, 0x20, 0x60, 0x42, 0x21, 0x21, 0x63, 0x44, 0x22, 0x22, 0x66, 0x46, 0x23, 0x23, 0x65, 
            0x48, 0x24, 0x24, 0x6C, 0x4A, 0x25, 0x25, 0x6F, 0x4C, 0x26, 0x26, 0x6A, 0x4E, 0x27, 0x27, 0x69, 
            0x50, 0x28, 0x28, 0x78, 0x52, 0x29, 0x29, 0x7B, 0x54, 0x2A, 0x2A, 0x7E, 0x56, 0x2B, 0x2B, 0x7D, 
            0x58, 0x2C, 0x2C, 0x74, 0x5A, 0x2D, 0x2D, 0x77, 0x5C, 0x2E, 0x2E, 0x72, 0x5E, 0x2F, 0x2F, 0x71, 
            0x60, 0x30, 0x30, 0x50, 0x62, 0x31, 0x31, 0x53, 0x64, 0x32, 0x32, 0x56, 0x66, 0x33, 0x33, 0x55, 
            0x68, 0x34, 0x34, 0x5C, 0x6A, 0x35, 0x35, 0x5F, 0x6C, 0x36, 0x36, 0x5A, 0x6E, 0x37, 0x37, 0x59, 
            0x70, 0x38, 0x38, 0x48, 0x72, 0x39, 0x39, 0x4B, 0x74, 0x3A, 0x3A, 0x4E, 0x76, 0x3B, 0x3B, 0x4D, 
            0x78, 0x3C, 0x3C, 0x44, 0x7A, 0x3D, 0x3D, 0x47, 0x7C, 0x3E, 0x3E, 0x42, 0x7E, 0x3F, 0x3F, 0x41, 
            0x80, 0x40, 0x40, 0xC0, 0x82, 0x41, 0x41, 0xC3, 0x84, 0x42, 0x42, 0xC6, 0x86, 0x43, 0x43, 0xC5, 
            0x88, 0x44, 0x44, 0xCC, 0x8A, 0x45, 0x45, 0xCF, 0x8C, 0x46, 0x46, 0xCA, 0x8E, 0x47, 0x47, 0xC9, 
            0x90, 0x48, 0x48, 0xD8, 0x92, 0x49, 0x49, 0xDB, 0x94, 0x4A, 0x4A, 0xDE, 0x96, 0x4B, 0x4B, 0xDD, 
            0x98, 0x4C, 0x4C, 0xD4, 0x9A, 0x4D, 0x4D, 0xD7, 0x9C, 0x4E, 0x4E, 0xD2, 0x9E, 0x4F, 0x4F, 0xD1, 
            0xA0, 0x50, 0x50, 0xF0, 0xA2, 0x51, 0x51, 0xF3, 0xA4, 0x52, 0x52, 0xF6, 0xA6, 0x53, 0x53, 0xF5, 
            0xA8, 0x54, 0x54, 0xFC, 0xAA, 0x55, 0x55, 0xFF, 0xAC, 0x56, 0x56, 0xFA, 0xAE, 0x57, 0x57, 0xF9, 
            0xB0, 0x58, 0x58, 0xE8, 0xB2, 0x59, 0x59, 0xEB, 0xB4, 0x5A, 0x5A, 0xEE, 0xB6, 0x5B, 0x5B, 0xED, 
            0xB8, 0x5C, 0x5C, 0xE4, 0xBA, 0x5D, 0x5D, 0xE7, 0xBC, 0x5E, 0x5E, 0xE2, 0xBE, 0x5F, 0x5F, 0xE1, 
            0xC0, 0x60, 0x60, 0xA0, 0xC2, 0x61, 0x61, 0xA3, 0xC4, 0x62, 0x62, 0xA6, 0xC6, 0x63, 0x63, 0xA5, 
            0xC8, 0x64, 0x64, 0xAC, 0xCA, 0x65, 0x65, 0xAF, 0xCC, 0x66, 0x66, 0xAA, 0xCE, 0x67, 0x67, 0xA9, 
            0xD0, 0x68, 0x68, 0xB8, 0xD2, 0x69, 0x69, 0xBB, 0xD4, 0x6A, 0x6A, 0xBE, 0xD6, 0x6B, 0x6B, 0xBD, 
            0xD8, 0x6C, 0x6C, 0xB4, 0xDA, 0x6D, 0x6D, 0xB7, 0xDC, 0x6E, 0x6E, 0xB2, 0xDE, 0x6F, 0x6F, 0xB1, 
            0xE0, 0x70, 0x70, 0x90, 0xE2, 0x71, 0x71, 0x93, 0xE4, 0x72, 0x72, 0x96, 0xE6, 0x73, 0x73, 0x95, 
            0xE8, 0x74, 0x74, 0x9C, 0xEA, 0x75, 0x75, 0x9F, 0xEC, 0x76, 0x76, 0x9A, 0xEE, 0x77, 0x77, 0x99, 
            0xF0, 0x78, 0x78, 0x88, 0xF2, 0x79, 0x79, 0x8B, 0xF4, 0x7A, 0x7A, 0x8E, 0xF6, 0x7B, 0x7B, 0x8D, 
            0xF8, 0x7C, 0x7C, 0x84, 0xFA, 0x7D, 0x7D, 0x87, 0xFC, 0x7E, 0x7E, 0x82, 0xFE, 0x7F, 0x7F, 0x81, 
            0x1B, 0x80, 0x80, 0x9B, 0x19, 0x81, 0x81, 0x98, 0x1F, 0x82, 0x82, 0x9D, 0x1D, 0x83, 0x83, 0x9E, 
            0x13, 0x84, 0x84, 0x97, 0x11, 0x85, 0x85, 0x94, 0x17, 0x86, 0x86, 0x91, 0x15, 0x87, 0x87, 0x92, 
            0x0B, 0x88, 0x88, 0x83, 0x09, 0x89, 0x89, 0x80, 0x0F, 0x8A, 0x8A, 0x85, 0x0D, 0x8B, 0x8B, 0x86, 
            0x03, 0x8C, 0x8C, 0x8F, 0x01, 0x8D, 0x8D, 0x8C, 0x07, 0x8E, 0x8E, 0x89, 0x05, 0x8F, 0x8F, 0x8A, 
            0x3B, 0x90, 0x90, 0xAB, 0x39, 0x91, 0x91, 0xA8, 0x3F, 0x92, 0x92, 0xAD, 0x3D, 0x93, 0x93, 0xAE, 
            0x33, 0x94, 0x94, 0xA7, 0x31, 0x95, 0x95, 0xA4, 0x37, 0x96, 0x96, 0xA1, 0x35, 0x97, 0x97, 0xA2, 
            0x2B, 0x98, 0x98, 0xB3, 0x29, 0x99, 0x99, 0xB0, 0x2F, 0x9A, 0x9A, 0xB5, 0x2D, 0x9B, 0x9B, 0xB6, 
            0x23, 0x9C, 0x9C, 0xBF, 0x21, 0x9D, 0x9D, 0xBC, 0x27, 0x9E, 0x9E, 0xB9, 0x25, 0x9F, 0x9F, 0xBA, 
            0x5B, 0xA0, 0xA0, 0xFB, 0x59, 0xA1, 0xA1, 0xF8, 0x5F, 0xA2, 0xA2, 0xFD, 0x5D, 0xA3, 0xA3, 0xFE, 
            0x53, 0xA4, 0xA4, 0xF7, 0x51, 0xA5, 0xA5, 0xF4, 0x57, 0xA6, 0xA6, 0xF1, 0x55, 0xA7, 0xA7, 0xF2, 
            0x4B, 0xA8, 0xA8, 0xE3, 0x49, 0xA9, 0xA9, 0xE0, 0x4F, 0xAA, 0xAA, 0xE5, 0x4D, 0xAB, 0xAB, 0xE6, 
            0x43, 0xAC, 0xAC, 0xEF, 0x41, 0xAD, 0xAD, 0xEC, 0x47, 0xAE, 0xAE, 0xE9, 0x45, 0xAF, 0xAF, 0xEA, 
            0x7B, 0xB0, 0xB0, 0xCB, 0x79, 0xB1, 0xB1, 0xC8, 0x7F, 0xB2, 0xB2, 0xCD, 0x7D, 0xB3, 0xB3, 0xCE, 
            0x73, 0xB4, 0xB4, 0xC7, 0x71, 0xB5, 0xB5, 0xC4, 0x77, 0xB6, 0xB6, 0xC1, 0x75, 0xB7, 0xB7, 0xC2, 
            0x6B, 0xB8, 0xB8, 0xD3, 0x69, 0xB9, 0xB9, 0xD0, 0x6F, 0xBA, 0xBA, 0xD5, 0x6D, 0xBB, 0xBB, 0xD6, 
            0x63, 0xBC, 0xBC, 0xDF, 0x61, 0xBD, 0xBD, 0xDC, 0x67, 0xBE, 0xBE, 0xD9, 0x65, 0xBF, 0xBF, 0xDA, 
            0x9B, 0xC0, 0xC0, 0x5B, 0x99, 0xC1, 0xC1, 0x58, 0x9F, 0xC2, 0xC2, 0x5D, 0x9D, 0xC3, 0xC3, 0x5E, 
            0x93, 0xC4, 0xC4, 0x57, 0x91, 0xC5, 0xC5, 0x54, 0x97, 0xC6, 0xC6, 0x51, 0x95, 0xC7, 0xC7, 0x52, 
            0x8B, 0xC8, 0xC8, 0x43, 0x89, 0xC9, 0xC9, 0x40, 0x8F, 0xCA, 0xCA, 0x45, 0x8D, 0xCB, 0xCB, 0x46, 
            0x83, 0xCC, 0xCC, 0x4F, 0x81, 0xCD, 0xCD, 0x4C, 0x87, 0xCE, 0xCE, 0x49, 0x85, 0xCF, 0xCF, 0x4A, 
            0xBB, 0xD0, 0xD0, 0x6B, 0xB9, 0xD1, 0xD1, 0x68, 0xBF, 0xD2, 0xD2, 0x6D, 0xBD, 0xD3, 0xD3, 0x6E, 
            0xB3, 0xD4, 0xD4, 0x67, 0xB1, 0xD5, 0xD5, 0x64, 0xB7, 0xD6, 0xD6, 0x61, 0xB5, 0xD7, 0xD7, 0x62, 
            0xAB, 0xD8, 0xD8, 0x73, 0xA9, 0xD9, 0xD9, 0x70, 0xAF, 0xDA, 0xDA, 0x75, 0xAD, 0xDB, 0xDB, 0x76, 
            0xA3, 0xDC, 0xDC, 0x7F, 0xA1, 0xDD, 0xDD, 0x7C, 0xA7, 0xDE, 0xDE, 0x79, 0xA5, 0xDF, 0xDF, 0x7A, 
            0xDB, 0xE0, 0xE0, 0x3B, 0xD9, 0xE1, 0xE1, 0x38, 0xDF, 0xE2, 0xE2, 0x3D, 0xDD, 0xE3, 0xE3, 0x3E, 
            0xD3, 0xE4, 0xE4, 0x37, 0xD1, 0xE5, 0xE5, 0x34, 0xD7, 0xE6, 0xE6, 0x31, 0xD5, 0xE7, 0xE7, 0x32, 
            0xCB, 0xE8, 0xE8, 0x23, 0xC9, 0xE9, 0xE9, 0x20, 0xCF, 0xEA, 0xEA, 0x25, 0xCD, 0xEB, 0xEB, 0x26, 
            0xC3, 0xEC, 0xEC, 0x2F, 0xC1, 0xED, 0xED, 0x2C, 0xC7, 0xEE, 0xEE, 0x29, 0xC5, 0xEF, 0xEF, 0x2A, 
            0xFB, 0xF0, 0xF0, 0x0B, 0xF9, 0xF1, 0xF1, 0x08, 0xFF, 0xF2, 0xF2, 0x0D, 0xFD, 0xF3, 0xF3, 0x0E, 
            0xF3, 0xF4, 0xF4, 0x07, 0xF1, 0xF5, 0xF5, 0x04, 0xF7, 0xF6, 0xF6, 0x01, 0xF5, 0xF7, 0xF7, 0x02, 
            0xEB, 0xF8, 0xF8, 0x13, 0xE9, 0xF9, 0xF9, 0x10, 0xEF, 0xFA, 0xFA, 0x15, 0xED, 0xFB, 0xFB, 0x16, 
            0xE3, 0xFC, 0xFC, 0x1F, 0xE1, 0xFD, 0xFD, 0x1C, 0xE7, 0xFE, 0xFE, 0x19, 0xE5, 0xFF, 0xFF, 0x1A, 
            0x00, 0x00, 0x00, 0x00, 0x0E, 0x09, 0x0D, 0x0B, 0x1C, 0x12, 0x1A, 0x16, 0x12, 0x1B, 0x17, 0x1D, 
            0x38, 0x24, 0x34, 0x2C, 0x36, 0x2D, 0x39, 0x27, 0x24, 0x36, 0x2E, 0x3A, 0x2A, 0x3F, 0x23, 0x31, 
            0x70, 0x48, 0x68, 0x58, 0x7E, 0x41, 0x65, 0x53, 0x6C, 0x5A, 0x72, 0x4E, 0x62, 0x53, 0x7F, 0x45, 
            0x48, 0x6C, 0x5C, 0x74, 0x46, 0x65, 0x51, 0x7F, 0x54, 0x7E, 0x46, 0x62, 0x5A, 0x77, 0x4B, 0x69, 
            0xE0, 0x90, 0xD0, 0xB0, 0xEE, 0x99, 0xDD, 0xBB, 0xFC, 0x82, 0xCA, 0xA6, 0xF2, 0x8B, 0xC7, 0xAD, 
            0xD8, 0xB4, 0xE4, 0x9C, 0xD6, 0xBD, 0xE9, 0x97, 0xC4, 0xA6, 0xFE, 0x8A, 0xCA, 0xAF, 0xF3, 0x81, 
            0x90, 0xD8, 0xB8, 0xE8, 0x9E, 0xD1, 0xB5, 0xE3, 0x8C, 0xCA, 0xA2, 0xFE, 0x82, 0xC3, 0xAF, 0xF5, 
            0xA8, 0xFC, 0x8C, 0xC4, 0xA6, 0xF5, 0x81, 0xCF, 0xB4, 0xEE, 0x96, 0xD2, 0xBA, 0xE7, 0x9B, 0xD9, 
            0xDB, 0x3B, 0xBB, 0x7B, 0xD5, 0x32, 0xB6, 0x70, 0xC7, 0x29, 0xA1, 0x6D, 0xC9, 0x20, 0xAC, 0x66, 
            0xE3, 0x1F, 0x8F, 0x57, 0xED, 0x16, 0x82, 0x5C, 0xFF, 0x0D, 0x95, 0x41, 0xF1, 0x04, 0x98, 0x4A, 
            0xAB, 0x73, 0xD3, 0x23, 0xA5, 0x7A, 0xDE, 0x28, 0xB7, 0x61, 0xC9, 0x35, 0xB9, 0x68, 0xC4, 0x3E, 
            0x93, 0x57, 0xE7, 0x0F, 0x9D, 0x5E, 0xEA, 0x04, 0x8F, 0x45, 0xFD, 0x19, 0x81, 0x4C, 0xF0, 0x12, 
            0x3B, 0xAB, 0x6B, 0xCB, 0x35, 0xA2, 0x66, 0xC0, 0x27, 0xB9, 0x71, 0xDD, 0x29, 0xB0, 0x7C, 0xD6, 
            0x03, 0x8F, 0x5F, 0xE7, 0x0D, 0x86, 0x52, 0xEC, 0x1F, 0x9D, 0x45, 0xF1, 0x11, 0x94, 0x48, 0xFA, 
            0x4B, 0xE3, 0x03, 0x93, 0x45, 0xEA, 0x0E, 0x98, 0x57, 0xF1, 0x19, 0x85, 0x59, 0xF8, 0x14, 0x8E, 
            0x73, 0xC7, 0x37, 0xBF, 0x7D, 0xCE, 0x3A, 0xB4, 0x6F, 0xD5, 0x2D, 0xA9, 0x61, 0xDC, 0x20, 0xA2, 
            0xAD, 0x76, 0x6D, 0xF6, 0xA3, 0x7F, 0x60, 0xFD, 0xB1, 0x64, 0x77, 0xE0, 0xBF, 0x6D, 0x7A, 0xEB, 
            0x95, 0x52, 0x59, 0xDA, 0x9B, 0x5B, 0x54, 0xD1, 0x89, 0x40, 0x43, 0xCC, 0x87, 0x49, 0x4E, 0xC7, 
            0xDD, 0x3E, 0x05, 0xAE, 0xD3, 0x37, 0x08, 0xA5, 0xC1, 0x2C, 0x1F, 0xB8, 0xCF, 0x25, 0x12, 0xB3, 
            0xE5, 0x1A, 0x31, 0x82, 0xEB, 0x13, 0x3C, 0x89, 0xF9, 0x08, 0x2B, 0x94, 0xF7, 0x01, 0x26, 0x9F, 
            0x4D, 0xE6, 0xBD, 0x46, 0x43, 0xEF, 0xB0, 0x4D, 0x51, 0xF4, 0xA7, 0x50, 0x5F, 0xFD, 0xAA, 0x5B, 
            0x75, 0xC2, 0x89, 0x6A, 0x7B, 0xCB, 0x84, 0x61, 0x69, 0xD0, 0x93, 0x7C, 0x67, 0xD9, 0x9E, 0x77, 
            0x3D, 0xAE, 0xD5, 0x1E, 0x33, 0xA7, 0xD8, 0x15, 0x21, 0xBC, 0xCF, 0x08, 0x2F, 0xB5, 0xC2, 0x03, 
            0x05, 0x8A, 0xE1, 0x32, 0x0B, 0x83, 0xEC, 0x39, 0x19, 0x98, 0xFB, 0x24, 0x17, 0x91, 0xF6, 0x2F, 
            0x76, 0x4D, 0xD6, 0x8D, 0x78, 0x44, 0xDB, 0x86, 0x6A, 0x5F, 0xCC, 0x9B, 0x64, 0x56, 0xC1, 0x90, 
            0x4E, 0x69, 0xE2, 0xA1, 0x40, 0x60, 0xEF, 0xAA, 0x52, 0x7B, 0xF8, 0xB7, 0x5C, 0x72, 0xF5, 0xBC, 
            0x06, 0x05, 0xBE, 0xD5, 0x08, 0x0C, 0xB3, 0xDE, 0x1A, 0x17, 0xA4, 0xC3, 0x14, 0x1E, 0xA9, 0xC8, 
            0x3E, 0x21, 0x8A, 0xF9, 0x30, 0x28, 0x87, 0xF2, 0x22, 0x33, 0x90, 0xEF, 0x2C, 0x3A, 0x9D, 0xE4, 
            0x96, 0xDD, 0x06, 0x3D, 0x98, 0xD4, 0x0B, 0x36, 0x8A, 0xCF, 0x1C, 0x2B, 0x84, 0xC6, 0x11, 0x20, 
            0xAE, 0xF9, 0x32, 0x11, 0xA0, 0xF0, 0x3F, 0x1A, 0xB2, 0xEB, 0x28, 0x07, 0xBC, 0xE2, 0x25, 0x0C, 
            0xE6, 0x95, 0x6E, 0x65, 0xE8, 0x9C, 0x63, 0x6E, 0xFA, 0x87, 0x74, 0x73, 0xF4, 0x8E, 0x79, 0x78, 
            0xDE, 0xB1, 0x5A, 0x49, 0xD0, 0xB8, 0x57, 0x42, 0xC2, 0xA3, 0x40, 0x5F, 0xCC, 0xAA, 0x4D, 0x54, 
            0x41, 0xEC, 0xDA, 0xF7, 0x4F, 0xE5, 0xD7, 0xFC, 0x5D, 0xFE, 0xC0, 0xE1, 0x53, 0xF7, 0xCD, 0xEA, 
            0x79, 0xC8, 0xEE, 0xDB, 0x77, 0xC1, 0xE3, 0xD0, 0x65, 0xDA, 0xF4, 0xCD, 0x6B, 0xD3, 0xF9, 0xC6, 
            0x31, 0xA4, 0xB2, 0xAF, 0x3F, 0xAD, 0xBF, 0xA4, 0x2D, 0xB6, 0xA8, 0xB9, 0x23, 0xBF, 0xA5, 0xB2, 
            0x09, 0x80, 0x86, 0x83, 0x07, 0x89, 0x8B, 0x88, 0x15, 0x92, 0x9C, 0x95, 0x1B, 0x9B, 0x91, 0x9E, 
            0xA1, 0x7C, 0x0A, 0x47, 0xAF, 0x75, 0x07, 0x4C, 0xBD, 0x6E, 0x10, 0x51, 0xB3, 0x67, 0x1D, 0x5A, 
            0x99, 0x58, 0x3E, 0x6B, 0x97, 0x51, 0x33, 0x60, 0x85, 0x4A, 0x24, 0x7D, 0x8B, 0x43, 0x29, 0x76, 
            0xD1, 0x34, 0x62, 0x1F, 0xDF, 0x3D, 0x6F, 0x14, 0xCD, 0x26, 0x78, 0x09, 0xC3, 0x2F, 0x75, 0x02, 
            0xE9, 0x10, 0x56, 0x33, 0xE7, 0x19, 0x5B, 0x38, 0xF5, 0x02, 0x4C, 0x25, 0xFB, 0x0B, 0x41, 0x2E, 
            0x9A, 0xD7, 0x61, 0x8C, 0x94, 0xDE, 0x6C, 0x87, 0x86, 0xC5, 0x7B, 0x9A, 0x88, 0xCC, 0x76, 0x91, 
            0xA2, 0xF3, 0x55, 0xA0, 0xAC, 0xFA, 0x58, 0xAB, 0xBE, 0xE1, 0x4F, 0xB6, 0xB0, 0xE8, 0x42, 0xBD, 
            0xEA, 0x9F, 0x09, 0xD4, 0xE4, 0x96, 0x04, 0xDF, 0xF6, 0x8D, 0x13, 0xC2, 0xF8, 0x84, 0x1E, 0xC9, 
            0xD2, 0xBB, 0x3D, 0xF8, 0xDC, 0xB2, 0x30, 0xF3, 0xCE, 0xA9, 0x27, 0xEE, 0xC0, 0xA0, 0x2A, 0xE5, 
            0x7A, 0x47, 0xB1, 0x3C, 0x74, 0x4E, 0xBC, 0x37, 0x66, 0x55, 0xAB, 0x2A, 0x68, 0x5C, 0xA6, 0x21, 
            0x42, 0x63, 0x85, 0x10, 0x4C, 0x6A, 0x88, 0x1B, 0x5E, 0x71, 0x9F, 0x06, 0x50, 0x78, 0x92, 0x0D, 
            0x0A, 0x0F, 0xD9, 0x64, 0x04, 0x06, 0xD4, 0x6F, 0x16, 0x1D, 0xC3, 0x72, 0x18, 0x14, 0xCE, 0x79, 
            0x32, 0x2B, 0xED, 0x48, 0x3C, 0x22, 0xE0, 0x43, 0x2E, 0x39, 0xF7, 0x5E, 0x20, 0x30, 0xFA, 0x55, 
            0xEC, 0x9A, 0xB7, 0x01, 0xE2, 0x93, 0xBA, 0x0A, 0xF0, 0x88, 0xAD, 0x17, 0xFE, 0x81, 0xA0, 0x1C, 
            0xD4, 0xBE, 0x83, 0x2D, 0xDA, 0xB7, 0x8E, 0x26, 0xC8, 0xAC, 0x99, 0x3B, 0xC6, 0xA5, 0x94, 0x30, 
            0x9C, 0xD2, 0xDF, 0x59, 0x92, 0xDB, 0xD2, 0x52, 0x80, 0xC0, 0xC5, 0x4F, 0x8E, 0xC9, 0xC8, 0x44, 
            0xA4, 0xF6, 0xEB, 0x75, 0xAA, 0xFF, 0xE6, 0x7E, 0xB8, 0xE4, 0xF1, 0x63, 0xB6, 0xED, 0xFC, 0x68, 
            0x0C, 0x0A, 0x67, 0xB1, 0x02, 0x03, 0x6A, 0xBA, 0x10, 0x18, 0x7D, 0xA7, 0x1E, 0x11, 0x70, 0xAC, 
            0x34, 0x2E, 0x53, 0x9D, 0x3A, 0x27, 0x5E, 0x96, 0x28, 0x3C, 0x49, 0x8B, 0x26, 0x35, 0x44, 0x80, 
            0x7C, 0x42, 0x0F, 0xE9, 0x72, 0x4B, 0x02, 0xE2, 0x60, 0x50, 0x15, 0xFF, 0x6E, 0x59, 0x18, 0xF4, 
            0x44, 0x66, 0x3B, 0xC5, 0x4A, 0x6F, 0x36, 0xCE, 0x58, 0x74, 0x21, 0xD3, 0x56, 0x7D, 0x2C, 0xD8, 
            0x37, 0xA1, 0x0C, 0x7A, 0x39, 0xA8, 0x01, 0x71, 0x2B, 0xB3, 0x16, 0x6C, 0x25, 0xBA, 0x1B, 0x67, 
            0x0F, 0x85, 0x38, 0x56, 0x01, 0x8C, 0x35, 0x5D, 0x13, 0x97, 0x22, 0x40, 0x1D, 0x9E, 0x2F, 0x4B, 
            0x47, 0xE9, 0x64, 0x22, 0x49, 0xE0, 0x69, 0x29, 0x5B, 0xFB, 0x7E, 0x34, 0x55, 0xF2, 0x73, 0x3F, 
            0x7F, 0xCD, 0x50, 0x0E, 0x71, 0xC4, 0x5D, 0x05, 0x63, 0xDF, 0x4A, 0x18, 0x6D, 0xD6, 0x47, 0x13, 
            0xD7, 0x31, 0xDC, 0xCA, 0xD9, 0x38, 0xD1, 0xC1, 0xCB, 0x23, 0xC6, 0xDC, 0xC5, 0x2A, 0xCB, 0xD7, 
            0xEF, 0x15, 0xE8, 0xE6, 0xE1, 0x1C, 0xE5, 0xED, 0xF3, 0x07, 0xF2, 0xF0, 0xFD, 0x0E, 0xFF, 0xFB, 
            0xA7, 0x79, 0xB4, 0x92, 0xA9, 0x70, 0xB9, 0x99, 0xBB, 0x6B, 0xAE, 0x84, 0xB5, 0x62, 0xA3, 0x8F, 
            0x9F, 0x5D, 0x80, 0xBE, 0x91, 0x54, 0x8D, 0xB5, 0x83, 0x4F, 0x9A, 0xA8, 0x8D, 0x46, 0x97, 0xA3, 
            0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00, 
            0x08, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x20, 0x00, 0x00, 0x00, 0x40, 0x00, 0x00, 0x00, 
            0x80, 0x00, 0x00, 0x00, 0x1B, 0x00, 0x00, 0x00, 0x36, 0x00, 0x00, 0x00, 0x6C, 0x00, 0x00, 0x00, 
            0xD8, 0x00, 0x00, 0x00, 0xAB, 0x00, 0x00, 0x00, 0x4D, 0x00, 0x00, 0x00, 0x9A, 0x00, 0x00, 0x00, 
            0x2F, 0x00, 0x00, 0x00, 0x5E, 0x00, 0x00, 0x00, 0xBC, 0x00, 0x00, 0x00, 0x63, 0x00, 0x00, 0x00, 
            0xC6, 0x00, 0x00, 0x00, 0x97, 0x00, 0x00, 0x00, 0x35, 0x00, 0x00, 0x00, 0x6A, 0x00, 0x00, 0x00, 
            0xD4, 0x00, 0x00, 0x00, 0xB3, 0x00, 0x00, 0x00, 0x7D, 0x00, 0x00, 0x00, 0xFA, 0x00, 0x00, 0x00, 
            0xEF, 0x00, 0x00, 0x00, 0xC5, 0x00, 0x00, 0x00, 0x91, 0x00, 0x00, 0x00, 0x39, 0x00, 0x00, 0x00, 
            0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
            0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
            0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
            0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
            0xFF, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
            0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
            0xFF, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
            0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
            0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
            0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
            0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
            0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
            0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
            0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
            0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
            0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x01, 0x00, 
            0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
            0x00, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 
            0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x00, 0x00, 0x00, 0x00, 0x01, 
            0x00, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 
            0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
            0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 
            0x30, 0x31, 0x32, 0x33, 0x00, 0x35, 0x36, 0x37, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
            0x30, 0x31, 0x32, 0x33, 0x00, 0x00, 0x00, 0x00, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 
            0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 
            0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 
            0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 
            0x08, 0x09, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10, 
            0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F, 0x20, 
            0x21, 0x22, 0x23, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10, 
            0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F, 0x20, 
            0x21, 0x22, 0x23, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 
            0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 
            0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 
            0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 
            0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 
            0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 
            0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 
            0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 
            0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x3F, 0xF0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
            0x40, 0x24, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x40, 0x59, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
            0x40, 0x8F, 0x40, 0x00, 0x00, 0x00, 0x00, 0x00, 0x40, 0xC3, 0x88, 0x00, 0x00, 0x00, 0x00, 0x00, 
            0x40, 0xF8, 0x6A, 0x00, 0x00, 0x00, 0x00, 0x00, 0x41, 0x2E, 0x84, 0x80, 0x00, 0x00, 0x00, 0x00, 
            0x41, 0x63, 0x12, 0xD0, 0x00, 0x00, 0x00, 0x00, 0x41, 0x97, 0xD7, 0x84, 0x00, 0x00, 0x00, 0x00, 
            0x41, 0xCD, 0xCD, 0x65, 0x00, 0x00, 0x00, 0x00, 0x42, 0x02, 0xA0, 0x5F, 0x20, 0x00, 0x00, 0x00, 
            0x42, 0x37, 0x48, 0x76, 0xE8, 0x00, 0x00, 0x00, 0x42, 0x6D, 0x1A, 0x94, 0xA2, 0x00, 0x00, 0x00, 
            0x42, 0xA2, 0x30, 0x9C, 0xE5, 0x40, 0x00, 0x00, 0x42, 0xD6, 0xBC, 0xC4, 0x1E, 0x90, 0x00, 0x00, 
            0x43, 0x0C, 0x6B, 0xF5, 0x26, 0x34, 0x00, 0x00, 0x3F, 0x80, 0x00, 0x00, 0x41, 0x20, 0x00, 0x00, 
            0x42, 0xC8, 0x00, 0x00, 0x44, 0x7A, 0x00, 0x00, 0x46, 0x1C, 0x40, 0x00, 0x47, 0xC3, 0x50, 0x00, 
            0x49, 0x74, 0x24, 0x00, 0x4B, 0x18, 0x96, 0x80, 0x4C, 0xBE, 0xBC, 0x20, 0x4E, 0x6E, 0x6B, 0x28, 
            0x50, 0x15, 0x02, 0xF9, 0x51, 0xBA, 0x43, 0xB7, 0x53, 0x68, 0xD4, 0xA5, 0x55, 0x11, 0x84, 0xE7, 
            0x56, 0xB5, 0xE6, 0x21, 0x58, 0x63, 0x5F, 0xA9, 0x3F, 0xF0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
            0x40, 0x24, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x40, 0x59, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
            0x40, 0x8F, 0x40, 0x00, 0x00, 0x00, 0x00, 0x00, 0x40, 0xC3, 0x88, 0x00, 0x00, 0x00, 0x00, 0x00, 
            0x40, 0xF8, 0x6A, 0x00, 0x00, 0x00, 0x00, 0x00, 0x41, 0x2E, 0x84, 0x80, 0x00, 0x00, 0x00, 0x00, 
            0x41, 0x63, 0x12, 0xD0, 0x00, 0x00, 0x00, 0x00, 0x41, 0x97, 0xD7, 0x84, 0x00, 0x00, 0x00, 0x00, 
            0x41, 0xCD, 0xCD, 0x65, 0x00, 0x00, 0x00, 0x00, 0x42, 0x02, 0xA0, 0x5F, 0x20, 0x00, 0x00, 0x00, 
            0x42, 0x37, 0x48, 0x76, 0xE8, 0x00, 0x00, 0x00, 0x42, 0x6D, 0x1A, 0x94, 0xA2, 0x00, 0x00, 0x00, 
            0x42, 0xA2, 0x30, 0x9C, 0xE5, 0x40, 0x00, 0x00, 0x42, 0xD6, 0xBC, 0xC4, 0x1E, 0x90, 0x00, 0x00, 
            0x43, 0x0C, 0x6B, 0xF5, 0x26, 0x34, 0x00, 0x00, 0x3F, 0xF0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
            0x40, 0x24, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x40, 0x59, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
            0x40, 0x8F, 0x40, 0x00, 0x00, 0x00, 0x00, 0x00, 0x40, 0xC3, 0x88, 0x00, 0x00, 0x00, 0x00, 0x00, 
            0x40, 0xF8, 0x6A, 0x00, 0x00, 0x00, 0x00, 0x00, 0x41, 0x2E, 0x84, 0x80, 0x00, 0x00, 0x00, 0x00, 
            0x41, 0x63, 0x12, 0xD0, 0x00, 0x00, 0x00, 0x00, 0x41, 0x97, 0xD7, 0x84, 0x00, 0x00, 0x00, 0x00, 
            0x41, 0xCD, 0xCD, 0x65, 0x00, 0x00, 0x00, 0x00, 0x42, 0x02, 0xA0, 0x5F, 0x20, 0x00, 0x00, 0x00, 
            0x42, 0x37, 0x48, 0x76, 0xE8, 0x00, 0x00, 0x00, 0x42, 0x6D, 0x1A, 0x94, 0xA2, 0x00, 0x00, 0x00, 
            0x42, 0xA2, 0x30, 0x9C, 0xE5, 0x40, 0x00, 0x00, 0x42, 0xD6, 0xBC, 0xC4, 0x1E, 0x90, 0x00, 0x00, 
            0x43, 0x0C, 0x6B, 0xF5, 0x26, 0x34, 0x00, 0x00, 0x3F, 0x80, 0x00, 0x00, 0x41, 0x20, 0x00, 0x00, 
            0x42, 0xC8, 0x00, 0x00, 0x44, 0x7A, 0x00, 0x00, 0x46, 0x1C, 0x40, 0x00, 0x47, 0xC3, 0x50, 0x00, 
            0x49, 0x74, 0x24, 0x00, 0x4B, 0x18, 0x96, 0x80, 0x4C, 0xBE, 0xBC, 0x20, 0x4E, 0x6E, 0x6B, 0x28, 
            0x50, 0x15, 0x02, 0xF9, 0x51, 0xBA, 0x43, 0xB7, 0x53, 0x68, 0xD4, 0xA5, 0x55, 0x11, 0x84, 0xE7, 
            0x56, 0xB5, 0xE6, 0x21, 0x58, 0x63, 0x5F, 0xA9, 0x3F, 0xF0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
            0x40, 0x24, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x40, 0x59, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
            0x40, 0x8F, 0x40, 0x00, 0x00, 0x00, 0x00, 0x00, 0x40, 0xC3, 0x88, 0x00, 0x00, 0x00, 0x00, 0x00, 
            0x40, 0xF8, 0x6A, 0x00, 0x00, 0x00, 0x00, 0x00, 0x41, 0x2E, 0x84, 0x80, 0x00, 0x00, 0x00, 0x00, 
            0x41, 0x63, 0x12, 0xD0, 0x00, 0x00, 0x00, 0x00, 0x41, 0x97, 0xD7, 0x84, 0x00, 0x00, 0x00, 0x00, 
            0x41, 0xCD, 0xCD, 0x65, 0x00, 0x00, 0x00, 0x00, 0x42, 0x02, 0xA0, 0x5F, 0x20, 0x00, 0x00, 0x00
            #endregion
        };

        byte[] sbox3 = 
        {
            #region s3
            0x51, 0xA3, 0x40, 0x8F, 0x92, 0x9D, 0x38, 0xF5, 0xBC, 0xB6, 0xDA, 0x21, 0x10, 0xFF, 0xF3, 0xD2, 
            0xCD, 0x0C, 0x13, 0xEC, 0x5F, 0x97, 0x44, 0x17, 0xC4, 0xA7, 0x7E, 0x3D, 0x64, 0x5D, 0x19, 0x73, 
            0x60, 0x81, 0x4F, 0xDC, 0x22, 0x2A, 0x90, 0x88, 0x46, 0xEE, 0xB8, 0x14, 0xDE, 0x5E, 0x0B, 0xDB, 
            0xE0, 0x32, 0x3A, 0x0A, 0x49, 0x06, 0x24, 0x5C, 0xC2, 0xD3, 0xAC, 0x62, 0x91, 0x95, 0xE4, 0x79, 
            0xE7, 0xC8, 0x37, 0x6D, 0x8D, 0xD5, 0x4E, 0xA9, 0x6C, 0x56, 0xF4, 0xEA, 0x65, 0x7A, 0xAE, 0x08, 
            0xBA, 0x78, 0x25, 0x2E, 0x1C, 0xA6, 0xB4, 0xC6, 0xE8, 0xDD, 0x74, 0x1F, 0x4B, 0xBD, 0x8B, 0x8A, 
            0x70, 0x3E, 0xB5, 0x66, 0x48, 0x03, 0xF6, 0x0E, 0x61, 0x35, 0x57, 0xB9, 0x86, 0xC1, 0x1D, 0x9E, 
            0xE1, 0xF8, 0x98, 0x11, 0x69, 0xD9, 0x8E, 0x94, 0x9B, 0x1E, 0x87, 0xE9, 0xCE, 0x55, 0x28, 0xDF, 
            0x8C, 0xA1, 0x89, 0x0D, 0xBF, 0xE6, 0x42, 0x68, 0x41, 0x99, 0x2D, 0x0F, 0xB0, 0x54, 0xBB, 0x16, 
            0x52, 0x09, 0x6A, 0xD5, 0x30, 0x36, 0xA5, 0x38, 0xBF, 0x40, 0xA3, 0x9E, 0x81, 0xF3, 0xD7, 0xFB, 
            0x7C, 0xE3, 0x39, 0x82, 0x9B, 0x2F, 0xFF, 0x87, 0x34, 0x8E, 0x43, 0x44, 0xC4, 0xDE, 0xE9, 0xCB, 
            0x54, 0x7B, 0x94, 0x32, 0xA6, 0xC2, 0x23, 0x3D, 0xEE, 0x4C, 0x95, 0x0B, 0x42, 0xFA, 0xC3, 0x4E, 
            0x08, 0x2E, 0xA1, 0x66, 0x28, 0xD9, 0x24, 0xB2, 0x76, 0x5B, 0xA2, 0x49, 0x6D, 0x8B, 0xD1, 0x25, 
            0x72, 0xF8, 0xF6, 0x64, 0x86, 0x68, 0x98, 0x16, 0xD4, 0xA4, 0x5C, 0xCC, 0x5D, 0x65, 0xB6, 0x92, 
            0x6C, 0x70, 0x48, 0x50, 0xFD, 0xED, 0xB9, 0xDA, 0x5E, 0x15, 0x46, 0x57, 0xA7, 0x8D, 0x9D, 0x84, 
            0x90, 0xD8, 0xAB, 0x00, 0x8C, 0xBC, 0xD3, 0x0A, 0xF7, 0xE4, 0x58, 0x05, 0xB8, 0xB3, 0x45, 0x06, 
            0xD0, 0x2C, 0x1E, 0x8F, 0xCA, 0x3F, 0x0F, 0x02, 0xC1, 0xAF, 0xBD, 0x03, 0x01, 0x13, 0x8A, 0x6B, 
            0x3A, 0x91, 0x11, 0x41, 0x4F, 0x67, 0xDC, 0xEA, 0x97, 0xF2, 0xCF, 0xCE, 0xF0, 0xB4, 0xE6, 0x73, 
            0x96, 0xAC, 0x74, 0x22, 0xE7, 0xAD, 0x35, 0x85, 0xE2, 0xF9, 0x37, 0xE8, 0x1C, 0x75, 0xDF, 0x6E, 
            0x47, 0xF1, 0x1A, 0x71, 0x1D, 0x29, 0xC5, 0x89, 0x6F, 0xB7, 0x62, 0x0E, 0xAA, 0x18, 0xBE, 0x1B, 
            0xFC, 0x56, 0x3E, 0x4B, 0xC6, 0xD2, 0x79, 0x20, 0x9A, 0xDB, 0xC0, 0xFE, 0x78, 0xCD, 0x5A, 0xF4, 
            0x1F, 0xDD, 0xA8, 0x33, 0x88, 0x07, 0xC7, 0x31, 0xB1, 0x12, 0x10, 0x59, 0x27, 0x80, 0xEC, 0x5F, 
            0x60, 0x51, 0x7F, 0xA9, 0x19, 0xB5, 0x4A, 0x0D, 0x2D, 0xE5, 0x7A, 0x9F, 0x93, 0xC9, 0x9C, 0xEF, 
            0xA0, 0xE0, 0x3B, 0x4D, 0xAE, 0x2A, 0xF5, 0xB0, 0xC8, 0xEB, 0xBB, 0x3C, 0x83, 0x53, 0x99, 0x61, 
            0x17, 0x2B, 0x04, 0x7E, 0xBA, 0x77, 0xD6, 0x26, 0xE1, 0x69, 0x14, 0x63, 0x55, 0x21, 0x0C, 0x7D, 
            0x00, 0x00, 0x00, 0x00, 0x02, 0x01, 0x01, 0x03, 0x04, 0x02, 0x02, 0x06, 0x06, 0x03, 0x03, 0x05, 
            0x08, 0x04, 0x04, 0x0C, 0x0A, 0x05, 0x05, 0x0F, 0x0C, 0x06, 0x06, 0x0A, 0x0E, 0x07, 0x07, 0x09, 
            0x10, 0x08, 0x08, 0x18, 0x12, 0x09, 0x09, 0x1B, 0x14, 0x0A, 0x0A, 0x1E, 0x16, 0x0B, 0x0B, 0x1D, 
            0x18, 0x0C, 0x0C, 0x14, 0x1A, 0x0D, 0x0D, 0x17, 0x1C, 0x0E, 0x0E, 0x12, 0x1E, 0x0F, 0x0F, 0x11, 
            0x20, 0x10, 0x10, 0x30, 0x22, 0x11, 0x11, 0x33, 0x24, 0x12, 0x12, 0x36, 0x26, 0x13, 0x13, 0x35, 
            0x28, 0x14, 0x14, 0x3C, 0x2A, 0x15, 0x15, 0x3F, 0x2C, 0x16, 0x16, 0x3A, 0x2E, 0x17, 0x17, 0x39, 
            0x30, 0x18, 0x18, 0x28, 0x32, 0x19, 0x19, 0x2B, 0x34, 0x1A, 0x1A, 0x2E, 0x36, 0x1B, 0x1B, 0x2D, 
            0x38, 0x1C, 0x1C, 0x24, 0x3A, 0x1D, 0x1D, 0x27, 0x3C, 0x1E, 0x1E, 0x22, 0x3E, 0x1F, 0x1F, 0x21, 
            0x40, 0x20, 0x20, 0x60, 0x42, 0x21, 0x21, 0x63, 0x44, 0x22, 0x22, 0x66, 0x46, 0x23, 0x23, 0x65, 
            0x48, 0x24, 0x24, 0x6C, 0x4A, 0x25, 0x25, 0x6F, 0x4C, 0x26, 0x26, 0x6A, 0x4E, 0x27, 0x27, 0x69, 
            0x50, 0x28, 0x28, 0x78, 0x52, 0x29, 0x29, 0x7B, 0x54, 0x2A, 0x2A, 0x7E, 0x56, 0x2B, 0x2B, 0x7D, 
            0x58, 0x2C, 0x2C, 0x74, 0x5A, 0x2D, 0x2D, 0x77, 0x5C, 0x2E, 0x2E, 0x72, 0x5E, 0x2F, 0x2F, 0x71, 
            0x60, 0x30, 0x30, 0x50, 0x62, 0x31, 0x31, 0x53, 0x64, 0x32, 0x32, 0x56, 0x66, 0x33, 0x33, 0x55, 
            0x68, 0x34, 0x34, 0x5C, 0x6A, 0x35, 0x35, 0x5F, 0x6C, 0x36, 0x36, 0x5A, 0x6E, 0x37, 0x37, 0x59, 
            0x70, 0x38, 0x38, 0x48, 0x72, 0x39, 0x39, 0x4B, 0x74, 0x3A, 0x3A, 0x4E, 0x76, 0x3B, 0x3B, 0x4D, 
            0x78, 0x3C, 0x3C, 0x44, 0x7A, 0x3D, 0x3D, 0x47, 0x7C, 0x3E, 0x3E, 0x42, 0x7E, 0x3F, 0x3F, 0x41, 
            0x80, 0x40, 0x40, 0xC0, 0x82, 0x41, 0x41, 0xC3, 0x84, 0x42, 0x42, 0xC6, 0x86, 0x43, 0x43, 0xC5, 
            0x88, 0x44, 0x44, 0xCC, 0x8A, 0x45, 0x45, 0xCF, 0x8C, 0x46, 0x46, 0xCA, 0x8E, 0x47, 0x47, 0xC9, 
            0x90, 0x48, 0x48, 0xD8, 0x92, 0x49, 0x49, 0xDB, 0x94, 0x4A, 0x4A, 0xDE, 0x96, 0x4B, 0x4B, 0xDD, 
            0x98, 0x4C, 0x4C, 0xD4, 0x9A, 0x4D, 0x4D, 0xD7, 0x9C, 0x4E, 0x4E, 0xD2, 0x9E, 0x4F, 0x4F, 0xD1, 
            0xA0, 0x50, 0x50, 0xF0, 0xA2, 0x51, 0x51, 0xF3, 0xA4, 0x52, 0x52, 0xF6, 0xA6, 0x53, 0x53, 0xF5, 
            0xA8, 0x54, 0x54, 0xFC, 0xAA, 0x55, 0x55, 0xFF, 0xAC, 0x56, 0x56, 0xFA, 0xAE, 0x57, 0x57, 0xF9, 
            0xB0, 0x58, 0x58, 0xE8, 0xB2, 0x59, 0x59, 0xEB, 0xB4, 0x5A, 0x5A, 0xEE, 0xB6, 0x5B, 0x5B, 0xED, 
            0xB8, 0x5C, 0x5C, 0xE4, 0xBA, 0x5D, 0x5D, 0xE7, 0xBC, 0x5E, 0x5E, 0xE2, 0xBE, 0x5F, 0x5F, 0xE1, 
            0xC0, 0x60, 0x60, 0xA0, 0xC2, 0x61, 0x61, 0xA3, 0xC4, 0x62, 0x62, 0xA6, 0xC6, 0x63, 0x63, 0xA5, 
            0xC8, 0x64, 0x64, 0xAC, 0xCA, 0x65, 0x65, 0xAF, 0xCC, 0x66, 0x66, 0xAA, 0xCE, 0x67, 0x67, 0xA9, 
            0xD0, 0x68, 0x68, 0xB8, 0xD2, 0x69, 0x69, 0xBB, 0xD4, 0x6A, 0x6A, 0xBE, 0xD6, 0x6B, 0x6B, 0xBD, 
            0xD8, 0x6C, 0x6C, 0xB4, 0xDA, 0x6D, 0x6D, 0xB7, 0xDC, 0x6E, 0x6E, 0xB2, 0xDE, 0x6F, 0x6F, 0xB1, 
            0xE0, 0x70, 0x70, 0x90, 0xE2, 0x71, 0x71, 0x93, 0xE4, 0x72, 0x72, 0x96, 0xE6, 0x73, 0x73, 0x95, 
            0xE8, 0x74, 0x74, 0x9C, 0xEA, 0x75, 0x75, 0x9F, 0xEC, 0x76, 0x76, 0x9A, 0xEE, 0x77, 0x77, 0x99, 
            0xF0, 0x78, 0x78, 0x88, 0xF2, 0x79, 0x79, 0x8B, 0xF4, 0x7A, 0x7A, 0x8E, 0xF6, 0x7B, 0x7B, 0x8D, 
            0xF8, 0x7C, 0x7C, 0x84, 0xFA, 0x7D, 0x7D, 0x87, 0xFC, 0x7E, 0x7E, 0x82, 0xFE, 0x7F, 0x7F, 0x81, 
            0x1B, 0x80, 0x80, 0x9B, 0x19, 0x81, 0x81, 0x98, 0x1F, 0x82, 0x82, 0x9D, 0x1D, 0x83, 0x83, 0x9E, 
            0x13, 0x84, 0x84, 0x97, 0x11, 0x85, 0x85, 0x94, 0x17, 0x86, 0x86, 0x91, 0x15, 0x87, 0x87, 0x92, 
            0x0B, 0x88, 0x88, 0x83, 0x09, 0x89, 0x89, 0x80, 0x0F, 0x8A, 0x8A, 0x85, 0x0D, 0x8B, 0x8B, 0x86, 
            0x03, 0x8C, 0x8C, 0x8F, 0x01, 0x8D, 0x8D, 0x8C, 0x07, 0x8E, 0x8E, 0x89, 0x05, 0x8F, 0x8F, 0x8A, 
            0x3B, 0x90, 0x90, 0xAB, 0x39, 0x91, 0x91, 0xA8, 0x3F, 0x92, 0x92, 0xAD, 0x3D, 0x93, 0x93, 0xAE, 
            0x33, 0x94, 0x94, 0xA7, 0x31, 0x95, 0x95, 0xA4, 0x37, 0x96, 0x96, 0xA1, 0x35, 0x97, 0x97, 0xA2, 
            0x2B, 0x98, 0x98, 0xB3, 0x29, 0x99, 0x99, 0xB0, 0x2F, 0x9A, 0x9A, 0xB5, 0x2D, 0x9B, 0x9B, 0xB6, 
            0x23, 0x9C, 0x9C, 0xBF, 0x21, 0x9D, 0x9D, 0xBC, 0x27, 0x9E, 0x9E, 0xB9, 0x25, 0x9F, 0x9F, 0xBA, 
            0x5B, 0xA0, 0xA0, 0xFB, 0x59, 0xA1, 0xA1, 0xF8, 0x5F, 0xA2, 0xA2, 0xFD, 0x5D, 0xA3, 0xA3, 0xFE, 
            0x53, 0xA4, 0xA4, 0xF7, 0x51, 0xA5, 0xA5, 0xF4, 0x57, 0xA6, 0xA6, 0xF1, 0x55, 0xA7, 0xA7, 0xF2, 
            0x4B, 0xA8, 0xA8, 0xE3, 0x49, 0xA9, 0xA9, 0xE0, 0x4F, 0xAA, 0xAA, 0xE5, 0x4D, 0xAB, 0xAB, 0xE6, 
            0x43, 0xAC, 0xAC, 0xEF, 0x41, 0xAD, 0xAD, 0xEC, 0x47, 0xAE, 0xAE, 0xE9, 0x45, 0xAF, 0xAF, 0xEA, 
            0x7B, 0xB0, 0xB0, 0xCB, 0x79, 0xB1, 0xB1, 0xC8, 0x7F, 0xB2, 0xB2, 0xCD, 0x7D, 0xB3, 0xB3, 0xCE, 
            0x73, 0xB4, 0xB4, 0xC7, 0x71, 0xB5, 0xB5, 0xC4, 0x77, 0xB6, 0xB6, 0xC1, 0x75, 0xB7, 0xB7, 0xC2, 
            0x6B, 0xB8, 0xB8, 0xD3, 0x69, 0xB9, 0xB9, 0xD0, 0x6F, 0xBA, 0xBA, 0xD5, 0x6D, 0xBB, 0xBB, 0xD6, 
            0x63, 0xBC, 0xBC, 0xDF, 0x61, 0xBD, 0xBD, 0xDC, 0x67, 0xBE, 0xBE, 0xD9, 0x65, 0xBF, 0xBF, 0xDA, 
            0x9B, 0xC0, 0xC0, 0x5B, 0x99, 0xC1, 0xC1, 0x58, 0x9F, 0xC2, 0xC2, 0x5D, 0x9D, 0xC3, 0xC3, 0x5E, 
            0x93, 0xC4, 0xC4, 0x57, 0x91, 0xC5, 0xC5, 0x54, 0x97, 0xC6, 0xC6, 0x51, 0x95, 0xC7, 0xC7, 0x52, 
            0x8B, 0xC8, 0xC8, 0x43, 0x89, 0xC9, 0xC9, 0x40, 0x8F, 0xCA, 0xCA, 0x45, 0x8D, 0xCB, 0xCB, 0x46, 
            0x83, 0xCC, 0xCC, 0x4F, 0x81, 0xCD, 0xCD, 0x4C, 0x87, 0xCE, 0xCE, 0x49, 0x85, 0xCF, 0xCF, 0x4A, 
            0xBB, 0xD0, 0xD0, 0x6B, 0xB9, 0xD1, 0xD1, 0x68, 0xBF, 0xD2, 0xD2, 0x6D, 0xBD, 0xD3, 0xD3, 0x6E, 
            0xB3, 0xD4, 0xD4, 0x67, 0xB1, 0xD5, 0xD5, 0x64, 0xB7, 0xD6, 0xD6, 0x61, 0xB5, 0xD7, 0xD7, 0x62, 
            0xAB, 0xD8, 0xD8, 0x73, 0xA9, 0xD9, 0xD9, 0x70, 0xAF, 0xDA, 0xDA, 0x75, 0xAD, 0xDB, 0xDB, 0x76, 
            0xA3, 0xDC, 0xDC, 0x7F, 0xA1, 0xDD, 0xDD, 0x7C, 0xA7, 0xDE, 0xDE, 0x79, 0xA5, 0xDF, 0xDF, 0x7A, 
            0xDB, 0xE0, 0xE0, 0x3B, 0xD9, 0xE1, 0xE1, 0x38, 0xDF, 0xE2, 0xE2, 0x3D, 0xDD, 0xE3, 0xE3, 0x3E, 
            0xD3, 0xE4, 0xE4, 0x37, 0xD1, 0xE5, 0xE5, 0x34, 0xD7, 0xE6, 0xE6, 0x31, 0xD5, 0xE7, 0xE7, 0x32, 
            0xCB, 0xE8, 0xE8, 0x23, 0xC9, 0xE9, 0xE9, 0x20, 0xCF, 0xEA, 0xEA, 0x25, 0xCD, 0xEB, 0xEB, 0x26, 
            0xC3, 0xEC, 0xEC, 0x2F, 0xC1, 0xED, 0xED, 0x2C, 0xC7, 0xEE, 0xEE, 0x29, 0xC5, 0xEF, 0xEF, 0x2A, 
            0xFB, 0xF0, 0xF0, 0x0B, 0xF9, 0xF1, 0xF1, 0x08, 0xFF, 0xF2, 0xF2, 0x0D, 0xFD, 0xF3, 0xF3, 0x0E, 
            0xF3, 0xF4, 0xF4, 0x07, 0xF1, 0xF5, 0xF5, 0x04, 0xF7, 0xF6, 0xF6, 0x01, 0xF5, 0xF7, 0xF7, 0x02, 
            0xEB, 0xF8, 0xF8, 0x13, 0xE9, 0xF9, 0xF9, 0x10, 0xEF, 0xFA, 0xFA, 0x15, 0xED, 0xFB, 0xFB, 0x16, 
            0xE3, 0xFC, 0xFC, 0x1F, 0xE1, 0xFD, 0xFD, 0x1C, 0xE7, 0xFE, 0xFE, 0x19, 0xE5, 0xFF, 0xFF, 0x1A, 
            0x00, 0x00, 0x00, 0x00, 0x0E, 0x09, 0x0D, 0x0B, 0x1C, 0x12, 0x1A, 0x16, 0x12, 0x1B, 0x17, 0x1D, 
            0x38, 0x24, 0x34, 0x2C, 0x36, 0x2D, 0x39, 0x27, 0x24, 0x36, 0x2E, 0x3A, 0x2A, 0x3F, 0x23, 0x31, 
            0x70, 0x48, 0x68, 0x58, 0x7E, 0x41, 0x65, 0x53, 0x6C, 0x5A, 0x72, 0x4E, 0x62, 0x53, 0x7F, 0x45, 
            0x48, 0x6C, 0x5C, 0x74, 0x46, 0x65, 0x51, 0x7F, 0x54, 0x7E, 0x46, 0x62, 0x5A, 0x77, 0x4B, 0x69, 
            0xE0, 0x90, 0xD0, 0xB0, 0xEE, 0x99, 0xDD, 0xBB, 0xFC, 0x82, 0xCA, 0xA6, 0xF2, 0x8B, 0xC7, 0xAD, 
            0xD8, 0xB4, 0xE4, 0x9C, 0xD6, 0xBD, 0xE9, 0x97, 0xC4, 0xA6, 0xFE, 0x8A, 0xCA, 0xAF, 0xF3, 0x81, 
            0x90, 0xD8, 0xB8, 0xE8, 0x9E, 0xD1, 0xB5, 0xE3, 0x8C, 0xCA, 0xA2, 0xFE, 0x82, 0xC3, 0xAF, 0xF5, 
            0xA8, 0xFC, 0x8C, 0xC4, 0xA6, 0xF5, 0x81, 0xCF, 0xB4, 0xEE, 0x96, 0xD2, 0xBA, 0xE7, 0x9B, 0xD9, 
            0xDB, 0x3B, 0xBB, 0x7B, 0xD5, 0x32, 0xB6, 0x70, 0xC7, 0x29, 0xA1, 0x6D, 0xC9, 0x20, 0xAC, 0x66, 
            0xE3, 0x1F, 0x8F, 0x57, 0xED, 0x16, 0x82, 0x5C, 0xFF, 0x0D, 0x95, 0x41, 0xF1, 0x04, 0x98, 0x4A, 
            0xAB, 0x73, 0xD3, 0x23, 0xA5, 0x7A, 0xDE, 0x28, 0xB7, 0x61, 0xC9, 0x35, 0xB9, 0x68, 0xC4, 0x3E, 
            0x93, 0x57, 0xE7, 0x0F, 0x9D, 0x5E, 0xEA, 0x04, 0x8F, 0x45, 0xFD, 0x19, 0x81, 0x4C, 0xF0, 0x12, 
            0x3B, 0xAB, 0x6B, 0xCB, 0x35, 0xA2, 0x66, 0xC0, 0x27, 0xB9, 0x71, 0xDD, 0x29, 0xB0, 0x7C, 0xD6, 
            0x03, 0x8F, 0x5F, 0xE7, 0x0D, 0x86, 0x52, 0xEC, 0x1F, 0x9D, 0x45, 0xF1, 0x11, 0x94, 0x48, 0xFA, 
            0x4B, 0xE3, 0x03, 0x93, 0x45, 0xEA, 0x0E, 0x98, 0x57, 0xF1, 0x19, 0x85, 0x59, 0xF8, 0x14, 0x8E, 
            0x73, 0xC7, 0x37, 0xBF, 0x7D, 0xCE, 0x3A, 0xB4, 0x6F, 0xD5, 0x2D, 0xA9, 0x61, 0xDC, 0x20, 0xA2, 
            0xAD, 0x76, 0x6D, 0xF6, 0xA3, 0x7F, 0x60, 0xFD, 0xB1, 0x64, 0x77, 0xE0, 0xBF, 0x6D, 0x7A, 0xEB, 
            0x95, 0x52, 0x59, 0xDA, 0x9B, 0x5B, 0x54, 0xD1, 0x89, 0x40, 0x43, 0xCC, 0x87, 0x49, 0x4E, 0xC7, 
            0xDD, 0x3E, 0x05, 0xAE, 0xD3, 0x37, 0x08, 0xA5, 0xC1, 0x2C, 0x1F, 0xB8, 0xCF, 0x25, 0x12, 0xB3, 
            0xE5, 0x1A, 0x31, 0x82, 0xEB, 0x13, 0x3C, 0x89, 0xF9, 0x08, 0x2B, 0x94, 0xF7, 0x01, 0x26, 0x9F, 
            0x4D, 0xE6, 0xBD, 0x46, 0x43, 0xEF, 0xB0, 0x4D, 0x51, 0xF4, 0xA7, 0x50, 0x5F, 0xFD, 0xAA, 0x5B, 
            0x75, 0xC2, 0x89, 0x6A, 0x7B, 0xCB, 0x84, 0x61, 0x69, 0xD0, 0x93, 0x7C, 0x67, 0xD9, 0x9E, 0x77, 
            0x3D, 0xAE, 0xD5, 0x1E, 0x33, 0xA7, 0xD8, 0x15, 0x21, 0xBC, 0xCF, 0x08, 0x2F, 0xB5, 0xC2, 0x03, 
            0x05, 0x8A, 0xE1, 0x32, 0x0B, 0x83, 0xEC, 0x39, 0x19, 0x98, 0xFB, 0x24, 0x17, 0x91, 0xF6, 0x2F, 
            0x76, 0x4D, 0xD6, 0x8D, 0x78, 0x44, 0xDB, 0x86, 0x6A, 0x5F, 0xCC, 0x9B, 0x64, 0x56, 0xC1, 0x90, 
            0x4E, 0x69, 0xE2, 0xA1, 0x40, 0x60, 0xEF, 0xAA, 0x52, 0x7B, 0xF8, 0xB7, 0x5C, 0x72, 0xF5, 0xBC, 
            0x06, 0x05, 0xBE, 0xD5, 0x08, 0x0C, 0xB3, 0xDE, 0x1A, 0x17, 0xA4, 0xC3, 0x14, 0x1E, 0xA9, 0xC8, 
            0x3E, 0x21, 0x8A, 0xF9, 0x30, 0x28, 0x87, 0xF2, 0x22, 0x33, 0x90, 0xEF, 0x2C, 0x3A, 0x9D, 0xE4, 
            0x96, 0xDD, 0x06, 0x3D, 0x98, 0xD4, 0x0B, 0x36, 0x8A, 0xCF, 0x1C, 0x2B, 0x84, 0xC6, 0x11, 0x20, 
            0xAE, 0xF9, 0x32, 0x11, 0xA0, 0xF0, 0x3F, 0x1A, 0xB2, 0xEB, 0x28, 0x07, 0xBC, 0xE2, 0x25, 0x0C, 
            0xE6, 0x95, 0x6E, 0x65, 0xE8, 0x9C, 0x63, 0x6E, 0xFA, 0x87, 0x74, 0x73, 0xF4, 0x8E, 0x79, 0x78, 
            0xDE, 0xB1, 0x5A, 0x49, 0xD0, 0xB8, 0x57, 0x42, 0xC2, 0xA3, 0x40, 0x5F, 0xCC, 0xAA, 0x4D, 0x54, 
            0x41, 0xEC, 0xDA, 0xF7, 0x4F, 0xE5, 0xD7, 0xFC, 0x5D, 0xFE, 0xC0, 0xE1, 0x53, 0xF7, 0xCD, 0xEA, 
            0x79, 0xC8, 0xEE, 0xDB, 0x77, 0xC1, 0xE3, 0xD0, 0x65, 0xDA, 0xF4, 0xCD, 0x6B, 0xD3, 0xF9, 0xC6, 
            0x31, 0xA4, 0xB2, 0xAF, 0x3F, 0xAD, 0xBF, 0xA4, 0x2D, 0xB6, 0xA8, 0xB9, 0x23, 0xBF, 0xA5, 0xB2, 
            0x09, 0x80, 0x86, 0x83, 0x07, 0x89, 0x8B, 0x88, 0x15, 0x92, 0x9C, 0x95, 0x1B, 0x9B, 0x91, 0x9E, 
            0xA1, 0x7C, 0x0A, 0x47, 0xAF, 0x75, 0x07, 0x4C, 0xBD, 0x6E, 0x10, 0x51, 0xB3, 0x67, 0x1D, 0x5A, 
            0x99, 0x58, 0x3E, 0x6B, 0x97, 0x51, 0x33, 0x60, 0x85, 0x4A, 0x24, 0x7D, 0x8B, 0x43, 0x29, 0x76, 
            0xD1, 0x34, 0x62, 0x1F, 0xDF, 0x3D, 0x6F, 0x14, 0xCD, 0x26, 0x78, 0x09, 0xC3, 0x2F, 0x75, 0x02, 
            0xE9, 0x10, 0x56, 0x33, 0xE7, 0x19, 0x5B, 0x38, 0xF5, 0x02, 0x4C, 0x25, 0xFB, 0x0B, 0x41, 0x2E, 
            0x9A, 0xD7, 0x61, 0x8C, 0x94, 0xDE, 0x6C, 0x87, 0x86, 0xC5, 0x7B, 0x9A, 0x88, 0xCC, 0x76, 0x91, 
            0xA2, 0xF3, 0x55, 0xA0, 0xAC, 0xFA, 0x58, 0xAB, 0xBE, 0xE1, 0x4F, 0xB6, 0xB0, 0xE8, 0x42, 0xBD, 
            0xEA, 0x9F, 0x09, 0xD4, 0xE4, 0x96, 0x04, 0xDF, 0xF6, 0x8D, 0x13, 0xC2, 0xF8, 0x84, 0x1E, 0xC9, 
            0xD2, 0xBB, 0x3D, 0xF8, 0xDC, 0xB2, 0x30, 0xF3, 0xCE, 0xA9, 0x27, 0xEE, 0xC0, 0xA0, 0x2A, 0xE5, 
            0x7A, 0x47, 0xB1, 0x3C, 0x74, 0x4E, 0xBC, 0x37, 0x66, 0x55, 0xAB, 0x2A, 0x68, 0x5C, 0xA6, 0x21, 
            0x42, 0x63, 0x85, 0x10, 0x4C, 0x6A, 0x88, 0x1B, 0x5E, 0x71, 0x9F, 0x06, 0x50, 0x78, 0x92, 0x0D, 
            0x0A, 0x0F, 0xD9, 0x64, 0x04, 0x06, 0xD4, 0x6F, 0x16, 0x1D, 0xC3, 0x72, 0x18, 0x14, 0xCE, 0x79, 
            0x32, 0x2B, 0xED, 0x48, 0x3C, 0x22, 0xE0, 0x43, 0x2E, 0x39, 0xF7, 0x5E, 0x20, 0x30, 0xFA, 0x55, 
            0xEC, 0x9A, 0xB7, 0x01, 0xE2, 0x93, 0xBA, 0x0A, 0xF0, 0x88, 0xAD, 0x17, 0xFE, 0x81, 0xA0, 0x1C, 
            0xD4, 0xBE, 0x83, 0x2D, 0xDA, 0xB7, 0x8E, 0x26, 0xC8, 0xAC, 0x99, 0x3B, 0xC6, 0xA5, 0x94, 0x30, 
            0x9C, 0xD2, 0xDF, 0x59, 0x92, 0xDB, 0xD2, 0x52, 0x80, 0xC0, 0xC5, 0x4F, 0x8E, 0xC9, 0xC8, 0x44, 
            0xA4, 0xF6, 0xEB, 0x75, 0xAA, 0xFF, 0xE6, 0x7E, 0xB8, 0xE4, 0xF1, 0x63, 0xB6, 0xED, 0xFC, 0x68, 
            0x0C, 0x0A, 0x67, 0xB1, 0x02, 0x03, 0x6A, 0xBA, 0x10, 0x18, 0x7D, 0xA7, 0x1E, 0x11, 0x70, 0xAC, 
            0x34, 0x2E, 0x53, 0x9D, 0x3A, 0x27, 0x5E, 0x96, 0x28, 0x3C, 0x49, 0x8B, 0x26, 0x35, 0x44, 0x80, 
            0x7C, 0x42, 0x0F, 0xE9, 0x72, 0x4B, 0x02, 0xE2, 0x60, 0x50, 0x15, 0xFF, 0x6E, 0x59, 0x18, 0xF4, 
            0x44, 0x66, 0x3B, 0xC5, 0x4A, 0x6F, 0x36, 0xCE, 0x58, 0x74, 0x21, 0xD3, 0x56, 0x7D, 0x2C, 0xD8, 
            0x37, 0xA1, 0x0C, 0x7A, 0x39, 0xA8, 0x01, 0x71, 0x2B, 0xB3, 0x16, 0x6C, 0x25, 0xBA, 0x1B, 0x67, 
            0x0F, 0x85, 0x38, 0x56, 0x01, 0x8C, 0x35, 0x5D, 0x13, 0x97, 0x22, 0x40, 0x1D, 0x9E, 0x2F, 0x4B, 
            0x47, 0xE9, 0x64, 0x22, 0x49, 0xE0, 0x69, 0x29, 0x5B, 0xFB, 0x7E, 0x34, 0x55, 0xF2, 0x73, 0x3F, 
            0x7F, 0xCD, 0x50, 0x0E, 0x71, 0xC4, 0x5D, 0x05, 0x63, 0xDF, 0x4A, 0x18, 0x6D, 0xD6, 0x47, 0x13, 
            0xD7, 0x31, 0xDC, 0xCA, 0xD9, 0x38, 0xD1, 0xC1, 0xCB, 0x23, 0xC6, 0xDC, 0xC5, 0x2A, 0xCB, 0xD7, 
            0xEF, 0x15, 0xE8, 0xE6, 0xE1, 0x1C, 0xE5, 0xED, 0xF3, 0x07, 0xF2, 0xF0, 0xFD, 0x0E, 0xFF, 0xFB, 
            0xA7, 0x79, 0xB4, 0x92, 0xA9, 0x70, 0xB9, 0x99, 0xBB, 0x6B, 0xAE, 0x84, 0xB5, 0x62, 0xA3, 0x8F, 
            0x9F, 0x5D, 0x80, 0xBE, 0x91, 0x54, 0x8D, 0xB5, 0x83, 0x4F, 0x9A, 0xA8, 0x8D, 0x46, 0x97, 0xA3, 
            0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00, 
            0x08, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x20, 0x00, 0x00, 0x00, 0x40, 0x00, 0x00, 0x00, 
            0x80, 0x00, 0x00, 0x00, 0x1B, 0x00, 0x00, 0x00, 0x36, 0x00, 0x00, 0x00, 0x6C, 0x00, 0x00, 0x00, 
            0xD8, 0x00, 0x00, 0x00, 0xAB, 0x00, 0x00, 0x00, 0x4D, 0x00, 0x00, 0x00, 0x9A, 0x00, 0x00, 0x00, 
            0x2F, 0x00, 0x00, 0x00, 0x5E, 0x00, 0x00, 0x00, 0xBC, 0x00, 0x00, 0x00, 0x63, 0x00, 0x00, 0x00, 
            0xC6, 0x00, 0x00, 0x00, 0x97, 0x00, 0x00, 0x00, 0x35, 0x00, 0x00, 0x00, 0x6A, 0x00, 0x00, 0x00
            #endregion
        };

        byte[] keyData2 = { 0x6B, 0xBA, 0x86, 0x8D, 0x5B, 0xCD, 0x94, 0xC4, 0x6B, 0x34, 0x22, 0x11, 0x5F, 0x97, 0x5B, 0x27 };
        byte[] keyData1 = { 0xDE, 0xE8, 0xB1, 0x50, 0x74, 0x51, 0x43, 0x77, 0xCD, 0x25, 0x6B, 0xFE, 0xAD, 0x85, 0x7C, 0x9D };


        byte[] info4 = new byte[4];
        byte[] info2 = new byte[2];
        byte[] info1 = new byte[1];

        //long ctrs, r0s, r1s, r2s, r3s, r4s, r5s, r6s, r7s, r8s, r9s, r10s, r11s, r12s, r13s, r14s, r15s, r16s, r17s, r18s, r19s, r20s, r21s, r22s, r23s, r24s, r25s, r26s, r27s, r28s, r29s, r30s, r31s = 0;
        ulong ctru, r0u, r1u, r2u, r3u, r4u, r5u, r6u, r7u, r8u, r9u, r10u, r11u, r12u, r13u, r14u, r15u, r16u, r17u, r18u, r19u, r20u, r21u, r22u, r23u, r24u, r25u, r26u, r27u, r28u, r29u, r30u, r31u = 0;

        public Form1()
        {
            InitializeComponent();
        }

        //Real ArrayReverse
        private byte[] ArrayReverse(byte[] arr)
        {
            Array.Reverse(arr);
            return arr;
        }

        //Swap Byte Order DWORD
        public UInt64 SwapByteOrder(UInt64 value)
        {
            return
              ((value & 0xff00000000000000L) >> 56) |
              ((value & 0x00ff000000000000L) >> 40) |
              ((value & 0x0000ff0000000000L) >> 24) |
              ((value & 0x000000ff00000000L) >> 8) |
              ((value & 0x00000000ff000000L) << 8) |
              ((value & 0x0000000000ff0000L) << 24) |
              ((value & 0x000000000000ff00L) << 40) |
              ((value & 0x00000000000000ffL) << 56);
        }

        //Form Loader
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        //Extract .farc/FARC Button
        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "FARC Files |*.farc";
            if (ofd.ShowDialog() == DialogResult.Cancel) return;
            string loadedFARC = ofd.FileName;
            FileInfo fi = new FileInfo(loadedFARC);
            this.toolStripStatusLabel1.Text = "Please wait, extracting: " + fi.Name; Application.DoEvents();
            FileStream fs = new FileStream(loadedFARC, FileMode.Open, FileAccess.Read);
            extractFARC(ref fs, ref fi);
            fs.Close();
            this.toolStripStatusLabel1.Text = "Finished extracting: " + fi.Name; Application.DoEvents();
        }

        //Extract All .farc/FARC Button
        private void button2_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog fbd = new FolderBrowserDialog();
            if (fbd.ShowDialog() == DialogResult.Cancel) return;
            string farcRoot = fbd.SelectedPath;
            foreach (string file in Directory.GetFiles(farcRoot, "*", SearchOption.AllDirectories))
            {
                FileInfo fi = new FileInfo(file);
                if (fi.Extension == ".farc")
                {
                    FileStream fs = new FileStream(file, FileMode.Open, FileAccess.Read);
                    this.toolStripStatusLabel1.Text = "Extracting: " + fi.Name; Application.DoEvents();
                    extractFARC(ref fs, ref fi);
                    fs.Close();
                }
            }
            this.toolStripStatusLabel1.Text = "Finished extracting all FARC files"; Application.DoEvents();
        }

        uint tableSize = 0;
        uint entryCount = 0;
        string magic = String.Empty;

        //byte[] entryNameBuffer = new byte[0x12];
        byte[] zeroTest = new byte[1];
        //string entryName = String.Empty;
        //uint entryAddress = 0;
        //uint entrySize = 0;
        //uint entryUnk = 0;

        //Extract .farc/FARC
        private void extractFARC(ref FileStream fs, ref FileInfo fi)
        {
            bool isFARC = false;
            entryCount = 0;
            string extractedPath = fi.DirectoryName + "\\extracted_farc";
            Directory.CreateDirectory(extractedPath);

            fs.Read(info4, 0, 4); //magic
            magic = Encoding.ASCII.GetString(info4);
            fs.Read(info4, 0, 4); //table size + 0x14
            tableSize = BitConverter.ToUInt32(ArrayReverse(info4), 0);
            fs.Read(info4, 0, 4); //unk01

            if (magic == "FARC")
            {
                fs.Seek(0x10, SeekOrigin.Current);
                isFARC = true;
            }
            if (magic == "FArC" || magic == "FArc")
            {

            }
            //entryCount = (tableSize - 0x14) / 30;

            List<string> entryNames = new List<string>();
            List<uint> entryAddresses = new List<uint>();
            List<uint> entrySizes = new List<uint>();
            List<uint> entryUnks = new List<uint>();
            //Enumerate Entry Info Table
            //for (int i = 0; i < entryCount; i++)
            while (fs.Position < (tableSize + 8))
            {
                string entryName = String.Empty;
                bool endReached = false;
                fs.Read(zeroTest, 0, 1);
                entryName += Encoding.ASCII.GetString(zeroTest);
                while (endReached == false)
                {
                    fs.Read(zeroTest, 0, 1);
                    if (zeroTest[0] == 0)
                    {
                        endReached = true;
                    }
                    else
                    {
                        entryName += Encoding.ASCII.GetString(zeroTest);
                    }
                }

                //fs.Read(entryNameBuffer, 0, 0x12);
                //entryNames.Add(Encoding.ASCII.GetString(entryNameBuffer).Replace("\0", String.Empty));
                entryNames.Add(entryName);
                fs.Read(info4, 0, 4);
                entryAddresses.Add(BitConverter.ToUInt32(ArrayReverse(info4), 0));
                fs.Read(info4, 0, 4);
                entrySizes.Add(BitConverter.ToUInt32(ArrayReverse(info4), 0));
                fs.Read(info4, 0, 4);
                entryUnks.Add(BitConverter.ToUInt32(ArrayReverse(info4), 0));
                entryCount++;
            }

            bp++;

            //byte[] magicTest = new byte[4];
            //Extract Entries
            for (int i = 0; i < entryCount; i++)
            {
                fs.Seek(entryAddresses[i], SeekOrigin.Begin);
                //byte[] entryBuffer = new byte[entrySizes[i]];
                long remainder = entrySizes[i] % 0x10;
                long bytesToPad = 0x10 - remainder;
                byte[] paddedEntryBuffer = new byte[entrySizes[i] + bytesToPad];
                fs.Read(paddedEntryBuffer, 0, paddedEntryBuffer.Length);
                //MessageBox.Show(remainder.ToString("x"));
                
                //Array.Copy(entryBuffer, 0, paddedEntryBuffer, 0, entryBuffer.Length);

                string extractedEntryFullPath = String.Empty;
                extractedEntryFullPath = extractedPath + "\\" + fi.Name;
                Directory.CreateDirectory(extractedEntryFullPath);

                
                File.WriteAllBytes(extractedEntryFullPath + "\\" + entryNames[i], paddedEntryBuffer);
                if (isFARC == true)
                {
                    this.toolStripStatusLabel1.Text = "Please wait, decrypting: " + entryNames[i]; Application.DoEvents();
                    File.WriteAllBytes(extractedEntryFullPath + "\\" + entryNames[i] + "__decrypted.bin", decrypt(paddedEntryBuffer));
                }
                /*
                Array.Copy(entryBuffer, 0, magicTest, 0, 4);
                //MessageBox.Show(BitConverter.ToString(magicTest).Replace("-", String.Empty) + ", " + this.textBox1.Text);
                if (BitConverter.ToString(magicTest).Replace("-", String.Empty) == this.textBox1.Text.Replace(" ", String.Empty))
                {
                    //MessageBox.Show(fi.Name + ", " + entryNames[i]);
                    this.richTextBox1.Text += fi.Name + ", " + entryNames[i] + "\n";
                }
                */
            }
        }

        //byte[] cryptedData = null;
        byte[] lwzByte = new byte[4];
        byte[] ldByte = new byte[8];
        byte[] info8a = new byte[8];
        byte[] info4a = new byte[4];
        byte[] tmp16 = new byte[16];
        //Decrypt (and possibly encrypt), does not work as encryption
        private byte[] decrypt(byte[] dataToCrypt)
        {
            byte[] cryptedData = new byte[dataToCrypt.Length];
            
            //preload registers
            r28u = 0; //pointer to start of data to crypt
            r29u = 0; //0 noticed the first time

            //Main crypto Loop
            for (int i = 0; i < dataToCrypt.Length / 0x10; i++)
            {
                r4u = r28u + r29u;                                              //seg001:00000000000297C4                 add       r4, r28, r29  # this loop is decrypting data
                r3u = 0; //pointer to possible keys data                        //seg001:00000000000297C8                 lwz       r3, 0x3C(r30) # Load Word and Zero
                r4u = r4u & 0xFFFFFFFF;                                         //seg001:00000000000297CC                 clrldi    r4, r4, 32    # r4 = r4 & 0xFFFFFFFF

                //seg001:00000000000297D0                 bl        sub_5DA01C    # Branch
                #region sub_5DA01C
                r5u = r4u;                                                      //seg001:00000000005DA01C                 mr        r5, r4        # Move Register
                                                                                //seg001:00000000005DA020                 b         sub_5D9DBC    # Branch
                //storing pointer to where 16 bytes will be copied possibly     //seg001:00000000005D9DBC                 stdu      r1, -0xE0(r1) # Crypto
                                                                                //seg001:00000000005D9DC0                 mfspr   r0, LR          # Move from sprg,
                //storing pointer to where 16 bytes will be copied              //seg001:00000000005D9DC4                 std       r21, 0xE0+var_58(r1) # Store Double Word
                //storing pointer for blr                                       //seg001:00000000005D9DC8                 std       r0, 0xE0+arg_10(r1) # Store Double Word

                #endregion

                                                                                //seg001:00000000000297D4                 nop                     # No Operation
                r29u = r29u + 0x10;                                             //seg001:00000000000297D8                 addi      r29, r29, 0x10 # Add Immediate
                                                                                //seg001:00000000000297DC                 cmplw     cr7, r31, r29 # Compare Logical Word
                                                                                //seg001:00000000000297E0                 bgt       cr7, loc_297C4 # Branch if greater than
                info8a = new byte[8];
                Array.Copy(keyData, (long)(4 + r3u), info8a, 0, 4);
                r12u = SwapByteOrder(BitConverter.ToUInt64(info8a, 0)) >> 32;    //seg001:00000000005D9DCC                 lwz       r12, 4(r3)    # Load Word and Zero
                                                                                //seg001:00000000005D9DD0                 addi      r21, r1, 0xE0+var_70 # Add Immediate
                                                                                //seg001:00000000005D9DD4                 std       r30, 0xE0+var_10(r1) # Store Double Word
                r11u = ((r12u << 4) & 0xFFFFFFF0);                              //seg001:00000000005D9DD8                 slwi      r11, r12, 4   # r11 = ((r12 << 4) & FFFFFFF0)
                //storing size if data to decrypt + 1                           //seg001:00000000005D9DDC                 std       r31, 0xE0+var_8(r1) # Store Double Word
                r11u = r11u + 0x100;                                            //seg001:00000000005D9DE0                 addi      r11, r11, 0x100 # Add Immediate
                                                                                //seg001:00000000005D9DE4                 std       r22, 0xE0+var_50(r1) # Store Double Word
                r11u = r11u + r3u; //r11u = 0; //possible always going to be pointer to start of key part    //r11u = r11u + r3u;     //seg001:00000000005D9DE8                 add       r11, r3, r11  # Add
                                                                                //seg001:00000000005D9DEC                 std       r23, 0xE0+var_48(r1) # Store Double Word
                r11u = r11u & 0xFFFFFFFF;                                       //seg001:00000000005D9DF0                 clrldi    r11, r11, 32  # r11 = r11 & 0xFFFFFFFF
                                                                                //seg001:00000000005D9DF4                 std       r24, 0xE0+var_40(r1) # Store Double Word
                //storing pointer to data to be crypted                         //seg001:00000000005D9DF8                 std       r25, 0xE0+var_38(r1) # Store Double Word
                //storing pointer to name of data to be crypted                 //seg001:00000000005D9DFC                 std       r26, 0xE0+var_30(r1) # Store Double Word
                //storing size of data to be crypted aligned to 0x10            //seg001:00000000005D9E00                 std       r27, 0xE0+var_28(r1) # Store Double Word
                //storing pointer to data to be crypted                         //seg001:00000000005D9E04                 std       r28, 0xE0+var_20(r1) # Store Double Word
                ulong r29uStored = r29u; //storing current pointer to dataToCrypt    //seg001:00000000005D9E08                 std       r29, 0xE0+var_18(r1) # Store Double Word
                info8a = new byte[8];
                Array.Copy(dataToCrypt, (long)(0x4 + r4u), info8a, 0, 1);
                r9u = BitConverter.ToUInt64(info8a, 0);                          //seg001:00000000005D9E0C                 lbz       r9, 4(r4)     # reading first byte of encrypted data from cmn.farc
                r30u = r3u;                                                     //seg001:00000000005D9E10                 mr        r30, r3       # Move Register
                info8a = new byte[8];
                Array.Copy(dataToCrypt, (long)(0xC + r4u), info8a, 0, 1);
                r28u = BitConverter.ToUInt64(info8a, 0);                         //seg001:00000000005D9E14                 lbz       r28, 0xC(r4)  # Load Byte and Zero
                r31u = r5u;                                                     //seg001:00000000005D9E18                 mr        r31, r5       # Move Register
                info8a = new byte[8];
                Array.Copy(dataToCrypt, (long)(0xF + r4u), info8a, 0, 1);
                r22u = BitConverter.ToUInt64(info8a, 0);                         //seg001:00000000005D9E1C                 lbz       r22, 0xF(r4)  # Load Byte and Zero
                info8a = new byte[8];
                Array.Copy(dataToCrypt, (long)(0x3 + r4u), info8a, 0, 1);
                r0u = BitConverter.ToUInt64(info8a, 0);                          //seg001:00000000005D9E20                 lbz       r0, 3(r4)     # Load Byte and Zero
                info8a = new byte[8];
                Array.Copy(dataToCrypt, (long)(0x5 + r4u), info8a, 0, 1);
                r10u = BitConverter.ToUInt64(info8a, 0);                         //seg001:00000000005D9E24                 lbz       r10, 5(r4)    # Load Byte and Zero
                info8a = new byte[8];
                Array.Copy(dataToCrypt, (long)(0x6 + r4u), info8a, 0, 1);
                r8u = BitConverter.ToUInt64(info8a, 0);                          //seg001:00000000005D9E28                 lbz       r8, 6(r4)     # Load Byte and Zero
                info8a = new byte[8];
                Array.Copy(dataToCrypt, (long)(0x7 + r4u), info8a, 0, 1);
                r7u = BitConverter.ToUInt64(info8a, 0);                          //seg001:00000000005D9E2C                 lbz       r7, 7(r4)     # Load Byte and Zero
                info8a = new byte[8];
                Array.Copy(dataToCrypt, (long)(0x8 + r4u), info8a, 0, 1);
                r6u = BitConverter.ToUInt64(info8a, 0);                          //seg001:00000000005D9E30                 lbz       r6, 8(r4)     # Load Byte and Zero
                info8a = new byte[8];
                Array.Copy(dataToCrypt, (long)(0x9 + r4u), info8a, 0, 1);
                r5u = BitConverter.ToUInt64(info8a, 0);                          //seg001:00000000005D9E34                 lbz       r5, 9(r4)     # Load Byte and Zero
                info8a = new byte[8];
                Array.Copy(dataToCrypt, (long)(0xA + r4u), info8a, 0, 1);
                r3u = BitConverter.ToUInt64(info8a, 0);                          //seg001:00000000005D9E38                 lbz       r3, 0xA(r4)   # Load Byte and Zero
                info8a = new byte[8];
                Array.Copy(dataToCrypt, (long)(0xB + r4u), info8a, 0, 1);
                r29u = BitConverter.ToUInt64(info8a, 0);                         //seg001:00000000005D9E3C                 lbz       r29, 0xB(r4)  # Load Byte and Zero
                info8a = new byte[8];
                Array.Copy(dataToCrypt, (long)(0xD + r4u), info8a, 0, 1);
                r27u = BitConverter.ToUInt64(info8a, 0);                         //seg001:00000000005D9E40                 lbz       r27, 0xD(r4)  # Load Byte and Zero
                info8a = new byte[8];
                Array.Copy(dataToCrypt, (long)(0xE + r4u), info8a, 0, 1);
                r26u = BitConverter.ToUInt64(info8a, 0);                         //seg001:00000000005D9E44                 lbz       r26, 0xE(r4)  # Load Byte and Zero
                info8a = new byte[8];
                Array.Copy(dataToCrypt, (long)(0x0 + r4u), info8a, 0, 1);
                r23u = BitConverter.ToUInt64(info8a, 0);                         //seg001:00000000005D9E48                 lbz       r23, 0(r4)    # Load Byte and Zero
                info8a = new byte[8];
                Array.Copy(dataToCrypt, (long)(0x1 + r4u), info8a, 0, 1);
                r24u = BitConverter.ToUInt64(info8a, 0);                         //seg001:00000000005D9E4C                 lbz       r24, 1(r4)    # Load Byte and Zero
                info8a = new byte[8];
                Array.Copy(dataToCrypt, (long)(0x2 + r4u), info8a, 0, 1);
                r25u = BitConverter.ToUInt64(info8a, 0);                         //seg001:00000000005D9E50                 lbz       r25, 2(r4)    # Load Byte and Zero
                Array.Copy(BitConverter.GetBytes(r23u), 0, tmp16, (long)(0x0 + 0), 1);   //seg001:00000000005D9E54                 stb       r23, 0xE0+var_70(r1) # storing first 16 bytes of encrypted data (possibly the key)
                Array.Copy(BitConverter.GetBytes(r24u), 0, tmp16, (long)(0x1 + 0), 1);   //seg001:00000000005D9E58                 stb       r24, 0xE0+var_70+1(r1) # Store Byte
                Array.Copy(BitConverter.GetBytes(r25u), 0, tmp16, (long)(0x2 + 0), 1);   //seg001:00000000005D9E5C                 stb       r25, 0xE0+var_70+2(r1) # Store Byte
                Array.Copy(BitConverter.GetBytes(r0u),  0, tmp16, (long)(0x3 + 0), 1);   //seg001:00000000005D9E60                 stb       r0, 0xE0+var_70+3(r1) # Store Byte
                Array.Copy(BitConverter.GetBytes(r28u), 0, tmp16, (long)(0xC + 0), 1);   //seg001:00000000005D9E64                 stb       r28, 0xE0+var_64(r1) # Store Byte
                Array.Copy(BitConverter.GetBytes(r9u),  0, tmp16, (long)(0x4 + 0), 1);   //seg001:00000000005D9E68                 stb       r9, 0xE0+var_6C(r1) # Store Byte
                Array.Copy(BitConverter.GetBytes(r10u), 0, tmp16, (long)(0x5 + 0), 1);   //seg001:00000000005D9E6C                 stb       r10, 0xE0+var_6C+1(r1) # Store Byte
                Array.Copy(BitConverter.GetBytes(r8u),  0, tmp16, (long)(0x6 + 0), 1);   //seg001:00000000005D9E70                 stb       r8, 0xE0+var_6C+2(r1) # Store Byte
                Array.Copy(BitConverter.GetBytes(r7u),  0, tmp16, (long)(0x7 + 0), 1);   //seg001:00000000005D9E74                 stb       r7, 0xE0+var_6C+3(r1) # Store Byte
                Array.Copy(BitConverter.GetBytes(r6u),  0, tmp16, (long)(0x8 + 0), 1);   //seg001:00000000005D9E78                 stb       r6, 0xE0+var_68(r1) # Store Byte
                Array.Copy(BitConverter.GetBytes(r5u),  0, tmp16, (long)(0x9 + 0), 1);   //seg001:00000000005D9E7C                 stb       r5, 0xE0+var_68+1(r1) # Store Byte
                Array.Copy(BitConverter.GetBytes(r3u),  0, tmp16, (long)(0xA + 0), 1);   //seg001:00000000005D9E80                 stb       r3, 0xE0+var_68+2(r1) # Store Byte
                Array.Copy(BitConverter.GetBytes(r29u), 0, tmp16, (long)(0xB + 0), 1);   //seg001:00000000005D9E84                 stb       r29, 0xE0+var_68+3(r1) # Store Byte
                Array.Copy(BitConverter.GetBytes(r27u), 0, tmp16, (long)(0xD + 0), 1);   //seg001:00000000005D9E88                 stb       r27, 0xE0+var_64+1(r1) # Store Byte
                Array.Copy(BitConverter.GetBytes(r26u), 0, tmp16, (long)(0xE + 0), 1);   //seg001:00000000005D9E8C                 stb       r26, 0xE0+var_64+2(r1) # Store Byte
                Array.Copy(BitConverter.GetBytes(r22u), 0, tmp16, (long)(0xF + 0), 1);   //seg001:00000000005D9E90                 stb       r22, 0xE0+var_64+3(r1) # Store Byte
                Array.Copy(keyData, (long)(0x0 + r11u), info4a, 0, 4);//Array.Copy(keyData1, (long)(0x0 + r11u), info4a, 0, 4);
                r9u = SwapByteOrder(BitConverter.ToUInt32(info4a, 0)) >> 32;             //seg001:00000000005D9E94                 lwz       r9, 0(r11)    # reading from the end of a possible sbox?
                r28u = r12u - 1;                                                         //seg001:00000000005D9E98                 addi      r28, r12, -1  # Add Immediate
                Array.Copy(tmp16, (long)(0x0 + 0x0), info4a, 0, 4);
                r0u = SwapByteOrder(BitConverter.ToUInt32(info4a, 0)) >> 32;             //seg001:00000000005D9E9C                 lwz       r0, 0xE0+var_70(r1) # reading the possible key

                //seg001:00000000005D9EA0                 cmpwi     cr7, r28, 0   # Compare Word Immediate
                r0u = r0u ^ r9u;                                                        //seg001:00000000005D9EA4                 xor       r0, r0, r9    # XOR
                Array.Copy(BitConverter.GetBytes(SwapByteOrder(r0u) >> 32), 0, tmp16, (long)(0x0 + 0x0), 4);    //seg001:00000000005D9EA8                 stw       r0, 0xE0+var_70(r1) # Store Word
                Array.Copy(keyData, (long)(0x4 + r11u), info4a, 0, 4);//Array.Copy(keyData1, (long)(0x4 + r11u), info4a, 0, 4);
                r9u = SwapByteOrder(BitConverter.ToUInt32(info4a, 0)) >> 32;            //seg001:00000000005D9EAC                 lwz       r9, 4(r11)    # Load Word and Zero
                Array.Copy(tmp16, (long)(0x4 + 0), info4a, 0, 4);
                r0u = SwapByteOrder(BitConverter.ToUInt32(info4a, 0)) >> 32;            //seg001:00000000005D9EB0                 lwz       r0, 0xE0+var_6C(r1) # Load Word and Zero
                r0u = r0u ^ r9u;                                                        //seg001:00000000005D9EB4                 xor       r0, r0, r9    # XOR
                Array.Copy(BitConverter.GetBytes(SwapByteOrder(r0u) >> 32), 0, tmp16, (long)(0x4 + 0x0), 4);//seg001:00000000005D9EB8                 stw       r0, 0xE0+var_6C(r1) # Store Word
                Array.Copy(keyData, (long)(0x8 + r11u), info4a, 0, 4);//Array.Copy(keyData1, (long)(0x8 + r11u), info4a, 0, 4);
                r9u = SwapByteOrder(BitConverter.ToUInt32(info4a, 0)) >> 32;            //seg001:00000000005D9EBC                 lwz       r9, 8(r11)    # Load Word and Zero
                Array.Copy(tmp16, (long)(0x8 + 0), info4a, 0, 4);
                r0u = SwapByteOrder(BitConverter.ToUInt32(info4a, 0)) >> 32;            //seg001:00000000005D9EC0                 lwz       r0, 0xE0+var_68(r1) # Load Word and Zero
                r0u = r0u ^ r9u;                                                        //seg001:00000000005D9EC4                 xor       r0, r0, r9    # XOR
                Array.Copy(BitConverter.GetBytes(SwapByteOrder(r0u) >> 32), 0, tmp16, (long)(0x8 + 0x0), 4);//seg001:00000000005D9EB8//seg001:00000000005D9EC8                 stw       r0, 0xE0+var_68(r1) # Store Word
                Array.Copy(keyData, (long)(0xC + r11u), info4a, 0, 4);//Array.Copy(keyData1, (long)(0xC + r11u), info4a, 0, 4);
                r9u = SwapByteOrder(BitConverter.ToUInt32(info4a, 0)) >> 32;            //seg001:00000000005D9ECC                 lwz       r9, 0xC(r11)  # Load Word and Zero
                Array.Copy(tmp16, (long)(0xC + 0), info4a, 0, 4);
                r0u = SwapByteOrder(BitConverter.ToUInt32(info4a, 0)) >> 32;            //seg001:00000000005D9ED0                 lwz       r0, 0xE0+var_64(r1) # Load Word and Zero
                r0u = r0u ^ r9u;                                                        //seg001:00000000005D9ED4                 xor       r0, r0, r9    # XOR
                Array.Copy(BitConverter.GetBytes(SwapByteOrder(r0u) >> 32), 0, tmp16, (long)(0xC + 0x0), 4);//seg001:00000000005D9ED8                 stw       r0, 0xE0+var_64(r1) # Store Word
                //seg001:00000000005D9EDC                 beq       cr7, loc_5D9F14 # Branch if equal
                if (r28u == 0)
                {
                    //Skip to remaining transform
                    r3u = r21u;                                             //seg001:00000000005D9F14                 mr        r3, r21       # Move Register

                    //seg001:00000000005D9F18                 bl        sub_5D9A70    # prelim sub
                    #region sub_5D9A70
                    r7u = 0; //pointer to start of sbox  //r7u = 0x00000000B475A0;  //seg001:00000000005D9A70                 lwz       r7, off_C0151C # unk_B475A0 # Load Word and Zero
                    r11u = r3u;                                                     //seg001:00000000005D9A74                 mr        r11, r3       # Move Register
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0x0 + 0), info4a, 0, 1);
                    r9u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9A78                 lbz       r9, 0(r3)     # loading changed file key
                    r8u = r3u;                                                      //seg001:00000000005D9A7C                 mr        r8, r3        # Move Register
                    r4u = r3u;                                                      //seg001:00000000005D9A80                 mr        r4, r3        # Move Register
                    r9u = r9u + r7u;                                                //seg001:00000000005D9A84                 add       r9, r9, r7    # Add
                    r6u = r3u;                                                      //seg001:00000000005D9A88                 mr        r6, r3        # Move Register
                    r10u = r3u;                                                     //seg001:00000000005D9A8C                 mr        r10, r3       # Move Register
                    info4a = new byte[4];
                    Array.Copy(sbox_v100, (long)(0x100 + r9u), info4a, 0, 1);
                    r0u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9A90                 lbz       r0, 0x100(r9) # reading from a possible lookup table
                    Array.Copy(BitConverter.GetBytes(r0u), 0, tmp16, (long)(0x0 + r3u), 1);//seg001:00000000005D9A94                 stb       r0, 0(r3)     # storing byte from possible lookup table over first byte of possible changed key
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0x4 + r11u), info4a, 0, 1);
                    r9u = BitConverter.ToUInt32(info4a, 0);
                    r11u = (0x4 + r11u);                                                       //seg001:00000000005D9A98                 lbzu      r9, 4(r11)    # Load Byte and Zero with Update
                    r9u = r9u & 0xFF;                                               //seg001:00000000005D9A9C                 clrldi    r9, r9, 56    # r9 = r9 & 0xFF
                    r9u = r9u + r7u;                                                //seg001:00000000005D9AA0                 add       r9, r9, r7    # Add
                    info4a = new byte[4];
                    Array.Copy(sbox_v100, (long)(0x100 + r9u), info4a, 0, 1);
                    r0u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9AA4                 lbz       r0, 0x100(r9) # Load Byte and Zero
                    Array.Copy(BitConverter.GetBytes(r0u), 0, tmp16, (long)(0x0 + r11u), 1);//seg001:00000000005D9AA8                 stb       r0, 0(r11)    # Store Byte
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0x8 + r8u), info4a, 0, 1);
                    r9u = BitConverter.ToUInt32(info4a, 0);
                    r8u = (0x8 + r8u);                                                        //seg001:00000000005D9AAC                 lbzu      r9, 8(r8)     # Load Byte and Zero with Update
                    r11u = r3u;                                                     //seg001:00000000005D9AB0                 mr        r11, r3       # Move Register
                    r9u = r9u & 0xFF;                                               //seg001:00000000005D9AB4                 clrldi    r9, r9, 56    # r9 = r9 & 0xFF
                    r9u = r9u + r7u;                                                //seg001:00000000005D9AB8                 add       r9, r9, r7    # Add
                    info4a = new byte[4];
                    Array.Copy(sbox_v100, (long)(0x100 + r9u), info4a, 0, 1);
                    r0u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9ABC                 lbz       r0, 0x100(r9) # Load Byte and Zero
                    Array.Copy(BitConverter.GetBytes(r0u), 0, tmp16, (long)(0x0 + r8u), 1);//seg001:00000000005D9AC0                 stb       r0, 0(r8)     # Store Byte
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0xC + r11u), info4a, 0, 1);
                    r9u = BitConverter.ToUInt32(info4a, 0);
                    r11u = (0xC + r11u);                                                     //seg001:00000000005D9AC4                 lbzu      r9, 0xC(r11)  # Load Byte and Zero with Update
                    r8u = r3u;                                                      //seg001:00000000005D9AC8                 mr        r8, r3        # Move Register
                    r9u = r9u & 0xFF;                                               //seg001:00000000005D9ACC                 clrldi    r9, r9, 56    # r9 = r9 & 0xFF
                    r9u = r9u + r7u;                                                //seg001:00000000005D9AD0                 add       r9, r9, r7    # Add
                    info4a = new byte[4];
                    Array.Copy(sbox_v100, (long)(0x100 + r9u), info4a, 0, 1);
                    r0u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9AD4                 lbz       r0, 0x100(r9) # Load Byte and Zero
                    Array.Copy(BitConverter.GetBytes(r0u), 0, tmp16, (long)(0x0 + r11u), 1);//seg001:00000000005D9AD8                 stb       r0, 0(r11)    # Store Byte
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0x9 + r4u), info4a, 0, 1);
                    r9u = BitConverter.ToUInt32(info4a, 0);
                    r4u = (0x9 + r4u);                                                     //seg001:00000000005D9ADC                 lbzu      r9, 9(r4)     # Load Byte and Zero with Update
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0xD + r8u), info4a, 0, 1);
                    r11u = BitConverter.ToUInt32(info4a, 0);
                    r8u = (0xD + r8u);                                                     //seg001:00000000005D9AE0                 lbzu      r11, 0xD(r8)  # Load Byte and Zero with Update
                    r9u = r9u & 0xFF;                                               //seg001:00000000005D9AE4                 clrldi    r9, r9, 56    # r9 = r9 & 0xFF
                    r11u = r11u & 0xFF;                                             //seg001:00000000005D9AE8                 clrldi    r11, r11, 56  # r11 = r11 & 0xFF
                    r9u = r9u + r7u;                                                //seg001:00000000005D9AEC                 add       r9, r9, r7    # Add
                    r11u = r11u + r7u;                                              //seg001:00000000005D9AF0                 add       r11, r11, r7  # Add
                    info4a = new byte[4];
                    Array.Copy(sbox_v100, (long)(0x100 + r9u), info4a, 0, 1);
                    r0u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9AF4                 lbz       r0, 0x100(r9) # Load Byte and Zero
                    info4a = new byte[4];
                    Array.Copy(sbox_v100, (long)(0x100 + r11u), info4a, 0, 1);
                    r5u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9AF8                 lbz       r5, 0x100(r11) # Load Byte and Zero
                    r11u = r3u;                                                     //seg001:00000000005D9AFC                 mr        r11, r3       # Move Register
                    Array.Copy(BitConverter.GetBytes(r0u), 0, tmp16, (long)(0x0 + r8u), 1);//seg001:00000000005D9B00                 stb       r0, 0(r8)     # Store Byte
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0x5 + r6u), info4a, 0, 1);
                    r9u = BitConverter.ToUInt32(info4a, 0);
                    r6u = (0x5 + r6u);                                                     //seg001:00000000005D9B04                 lbzu      r9, 5(r6)     # Load Byte and Zero with Update
                    r9u = r9u & 0xFF;                                               //seg001:00000000005D9B08                 clrldi    r9, r9, 56    # r9 = r9 & 0xFF
                    r9u = r9u + r7u;                                                //seg001:00000000005D9B0C                 add       r9, r9, r7    # Add
                    info4a = new byte[4];
                    Array.Copy(sbox_v100, (long)(0x100 + r9u), info4a, 0, 1);
                    r0u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9B10                 lbz       r0, 0x100(r9) # Load Byte and Zero
                    Array.Copy(BitConverter.GetBytes(r0u), 0, tmp16, (long)(0x0 + r4u), 1);//seg001:00000000005D9B14                 stb       r0, 0(r4)     # Store Byte
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0x1 + r11u), info4a, 0, 1);
                    r9u = BitConverter.ToUInt32(info4a, 0);
                    r11u = (0x1 + r11u);                                                     //seg001:00000000005D9B18                 lbzu      r9, 1(r11)    # Load Byte and Zero with Update
                    r4u = r3u;                                                      //seg001:00000000005D9B1C                 mr        r4, r3        # Move Register
                    r9u = r9u & 0xFF;                                               //seg001:00000000005D9B20                 clrldi    r9, r9, 56    # r9 = r9 & 0xFF
                    r9u = r9u + r7u;                                                //seg001:00000000005D9B24                 add       r9, r9, r7    # Add
                    info4a = new byte[4];
                    Array.Copy(sbox_v100, (long)(0x100 + r9u), info4a, 0, 1);
                    r0u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9B28                 lbz       r0, 0x100(r9) # Load Byte and Zero
                    Array.Copy(BitConverter.GetBytes(r0u), 0, tmp16, (long)(0x0 + r6u), 1); //seg001:00000000005D9B2C                 stb       r0, 0(r6)     # Store Byte
                    Array.Copy(BitConverter.GetBytes(r5u), 0, tmp16, (long)(0x0 + r11u), 1);//seg001:00000000005D9B30                 stb       r5, 0(r11)    # Store Byte
                    r5u = r3u;                                                      //seg001:00000000005D9B34                 mr        r5, r3        # Move Register
                    r6u = r3u;                                                      //seg001:00000000005D9B38                 mr        r6, r3        # Move Register
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0x6 + r5u), info4a, 0, 1);
                    r11u = BitConverter.ToUInt32(info4a, 0);
                    r5u = (0x6 + r5u);                                                     //seg001:00000000005D9B3C                 lbzu      r11, 6(r5)    # Load Byte and Zero with Update
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0xE + r6u), info4a, 0, 1);
                    r9u = BitConverter.ToUInt32(info4a, 0);
                    r6u = (0xE + r6u);                                                     //seg001:00000000005D9B40                 lbzu      r9, 0xE(r6)   # Load Byte and Zero with Update
                    r11u = r11u & 0xFF;                                             //seg001:00000000005D9B44                 clrldi    r11, r11, 56  # r11 = r11 & 0xFF
                    r9u = r9u & 0xFF;                                               //seg001:00000000005D9B48                 clrldi    r9, r9, 56    # r9 = r9 & 0xFF
                    r11u = r11u + r7u;                                              //seg001:00000000005D9B4C                 add       r11, r11, r7  # Add
                    r9u = r9u + r7u;                                                //seg001:00000000005D9B50                 add       r9, r9, r7    # Add
                    info4a = new byte[4];
                    Array.Copy(sbox_v100, (long)(0x100 + r11u), info4a, 0, 1);
                    r0u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9B54                 lbz       r0, 0x100(r11) # Load Byte and Zero
                    info4a = new byte[4];
                    Array.Copy(sbox_v100, (long)(0x100 + r9u), info4a, 0, 1);
                    r8u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9B58                 lbz       r8, 0x100(r9) # Load Byte and Zero
                    Array.Copy(BitConverter.GetBytes(r0u), 0, tmp16, (long)(0x0 + r6u), 1);//seg001:00000000005D9B5C                 stb       r0, 0(r6)     # Store Byte
                    r6u = r3u;                                                      //seg001:00000000005D9B60                 mr        r6, r3        # Move Register
                    Array.Copy(BitConverter.GetBytes(r8u), 0, tmp16, (long)(0x0 + r5u), 1);//seg001:00000000005D9B64                 stb       r8, 0(r5)     # Store Byte
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0x2 + r4u), info4a, 0, 1);
                    r9u = BitConverter.ToUInt32(info4a, 0);
                    r4u = (0x2 + r4u);                                                     //seg001:00000000005D9B68                 lbzu      r9, 2(r4)     # Load Byte and Zero with Update
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0xA + r6u), info4a, 0, 1);
                    r11u = BitConverter.ToUInt32(info4a, 0);
                    r6u = (0xA + r6u);                                                     //seg001:00000000005D9B6C                 lbzu      r11, 0xA(r6)  # Load Byte and Zero with Update
                    r9u = r9u & 0xFF;                                               //seg001:00000000005D9B70                 clrldi    r9, r9, 56    # r9 = r9 & 0xFF
                    r11u = r11u & 0xFF;                                             //seg001:00000000005D9B74                 clrldi    r11, r11, 56  # r11 = r11 & 0xFF
                    r9u = r9u + r7u;                                                //seg001:00000000005D9B78                 add       r9, r9, r7    # Add
                    r11u = r11u + r7u;                                              //seg001:00000000005D9B7C                 add       r11, r11, r7  # Add
                    r5u = r3u;                                                      //seg001:00000000005D9B80                 mr        r5, r3        # Move Register
                    info4a = new byte[4];
                    Array.Copy(sbox_v100, (long)(0x100 + r9u), info4a, 0, 1);
                    r0u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9B84                 lbz       r0, 0x100(r9) # Load Byte and Zero
                    info4a = new byte[4];
                    Array.Copy(sbox_v100, (long)(0x100 + r11u), info4a, 0, 1);
                    r8u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9B88                 lbz       r8, 0x100(r11) # Load Byte and Zero
                    Array.Copy(BitConverter.GetBytes(r0u), 0, tmp16, (long)(0x0 + r6u), 1);//seg001:00000000005D9B8C                 stb       r0, 0(r6)     # Store Byte
                    Array.Copy(BitConverter.GetBytes(r8u), 0, tmp16, (long)(0x0 + r4u), 1);//seg001:00000000005D9B90                 stb       r8, 0(r4)     # Store Byte
                    r8u = r3u;                                                      //seg001:00000000005D9B94                 mr        r8, r3        # Move Register
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0x7 + r5u), info4a, 0, 1);
                    r9u = BitConverter.ToUInt32(info4a, 0);
                    r5u = (0x7 + r5u);                                                     //seg001:00000000005D9B98                 lbzu      r9, 7(r5)     # Load Byte and Zero with Update
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0x3 + r8u), info4a, 0, 1);
                    r11u = BitConverter.ToUInt32(info4a, 0);
                    r8u = (0x3 + r8u);                                                     //seg001:00000000005D9B9C                 lbzu      r11, 3(r8)    # Load Byte and Zero with Update
                    r9u = r9u & 0xFF;                                               //seg001:00000000005D9BA0                 clrldi    r9, r9, 56    # r9 = r9 & 0xFF
                    r11u = r11u & 0xFF;                                             //seg001:00000000005D9BA4                 clrldi    r11, r11, 56  # r11 = r11 & 0xFF
                    r9u = r9u + r7u;                                                //seg001:00000000005D9BA8                 add       r9, r9, r7    # Add
                    r11u = r11u + r7u;                                               //seg001:00000000005D9BAC                 add       r11, r11, r7  # Add
                    info4a = new byte[4];
                    Array.Copy(sbox_v100, (long)(0x100 + r9u), info4a, 0, 1);
                    r0u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9BB0                 lbz       r0, 0x100(r9) # Load Byte and Zero
                    info4a = new byte[4];
                    Array.Copy(sbox_v100, (long)(0x100 + r11u), info4a, 0, 1);
                    r6u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9BB4                 lbz       r6, 0x100(r11) # Load Byte and Zero
                    r11u = r3u;                                                     //seg001:00000000005D9BB8                 mr        r11, r3       # Move Register
                    Array.Copy(BitConverter.GetBytes(r0u), 0, tmp16, (long)(0x0 + r8u), 1);//seg001:00000000005D9BBC                 stb       r0, 0(r8)     # Store Byte
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0xB + r11u), info4a, 0, 1);
                    r9u = BitConverter.ToUInt32(info4a, 0);
                    r11u = (0xB + r11u);                                                     //seg001:00000000005D9BC0                 lbzu      r9, 0xB(r11)  # Load Byte and Zero with Update
                    r9u = r9u & 0xFF;                                               //seg001:00000000005D9BC4                 clrldi    r9, r9, 56    # r9 = r9 & 0xFF
                    r9u = r9u + r7u;                                                //seg001:00000000005D9BC8                 add       r9, r9, r7    # Add
                    info4a = new byte[4];
                    Array.Copy(sbox_v100, (long)(0x100 + r9u), info4a, 0, 1);
                    r0u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9BCC                 lbz       r0, 0x100(r9) # Load Byte and Zero
                    Array.Copy(BitConverter.GetBytes(r0u), 0, tmp16, (long)(0x0 + r5u), 1);//seg001:00000000005D9BD0                 stb       r0, 0(r5)     # Store Byte
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0xF + r10u), info4a, 0, 1);
                    r9u = BitConverter.ToUInt32(info4a, 0);
                    r10u = (0xF + r10u);                                                     //seg001:00000000005D9BD4                 lbzu      r9, 0xF(r10)  # Load Byte and Zero with Update
                    r9u = r9u & 0xFF;                                               //seg001:00000000005D9BD8                 clrldi    r9, r9, 56    # r9 = r9 & 0xFF
                    r9u = r9u + r7u;                                                //seg001:00000000005D9BDC                 add       r9, r9, r7    # Add
                    info4a = new byte[4];
                    Array.Copy(sbox_v100, (long)(0x100 + r9u), info4a, 0, 1);
                    r0u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9BE0                 lbz       r0, 0x100(r9) # Load Byte and Zero
                    Array.Copy(BitConverter.GetBytes(r0u), 0, tmp16, (long)(0x0 + r11u), 1);//seg001:00000000005D9BE4                 stb       r0, 0(r11)    # Store Byte
                    Array.Copy(BitConverter.GetBytes(r6u), 0, tmp16, (long)(0x0 + r10u), 1);//seg001:00000000005D9BE8                 stb       r6, 0(r10)    # Store Byte
                    //seg001:00000000005D9BEC                 blr                     # Branch unconditionally

                    bp++;


                    #endregion

                    r10u = r30u;                                            //seg001:00000000005D9F1C                 mr        r10, r30      # Move Register
                    Array.Copy(tmp16, (long)(0x0 + 0), info4a, 0, 4);
                    r0u = SwapByteOrder(BitConverter.ToUInt32(info4a, 0)) >> 32;            //seg001:00000000005D9F20                 lwz       r0, 0xE0+var_70(r1) # Load Word and Zero
                    Array.Copy(keyData, (long)(0x100 + r10u), info4a, 0, 4);
                    r9u = SwapByteOrder(BitConverter.ToUInt32(info4a, 0)) >> 32;
                    r10u = (0x100 + r10u);                                                  //seg001:00000000005D9F24                 lwzu      r9, 0x100(r10) # Load Word and Zero with Update
                    r0u = r0u ^ r9u;                                        //seg001:00000000005D9F28                 xor       r0, r0, r9    # XOR
                    Array.Copy(BitConverter.GetBytes(SwapByteOrder(r0u) >> 32), 0, tmp16, (long)(0x0 + 0x0), 4);//seg001:00000000005D9F2C                 stw       r0, 0xE0+var_70(r1) # Store Word
                    Array.Copy(keyData, (long)(0x4 + r10u), info4a, 0, 4);
                    r9u = SwapByteOrder(BitConverter.ToUInt32(info4a, 0)) >> 32;            //seg001:00000000005D9F30                 lwz       r9, 4(r10)    # Load Word and Zero
                    Array.Copy(tmp16, (long)(0x4 + 0), info4a, 0, 4);
                    r0u = SwapByteOrder(BitConverter.ToUInt32(info4a, 0)) >> 32;            //seg001:00000000005D9F34                 lwz       r0, 0xE0+var_6C(r1) # Load Word and Zero
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0x0 + 1), info4a, 0, 1);
                    r29u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9F38                 lbz       r29, 0xE0+var_70+1(r1) # Load Byte and Zero
                    r0u = r0u ^ r9u;                                                 //seg001:00000000005D9F3C                 xor       r0, r0, r9    # XOR
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0x0 + 2), info4a, 0, 1);
                    r3u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9F40                 lbz       r3, 0xE0+var_70+2(r1) # Load Byte and Zero
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0x0 + 3), info4a, 0, 1);
                    r5u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9F44                 lbz       r5, 0xE0+var_70+3(r1) # Load Byte and Zero
                    Array.Copy(BitConverter.GetBytes(SwapByteOrder(r0u) >> 32), 0, tmp16, (long)(0x4 + 0x0), 4);//seg001:00000000005D9F48                 stw       r0, 0xE0+var_6C(r1) # Store Word
                    Array.Copy(keyData, (long)(0x8 + r10u), info4a, 0, 4);
                    r9u = SwapByteOrder(BitConverter.ToUInt32(info4a, 0)) >> 32;            //seg001:00000000005D9F4C                 lwz       r9, 8(r10)    # Load Word and Zero
                    Array.Copy(tmp16, (long)(0x8 + 0), info4a, 0, 4);
                    r0u = SwapByteOrder(BitConverter.ToUInt32(info4a, 0)) >> 32;            //seg001:00000000005D9F50                 lwz       r0, 0xE0+var_68(r1) # Load Word and Zero
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0x4 + 2), info4a, 0, 1);
                    r8u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9F54                 lbz       r8, 0xE0+var_6C+2(r1) # Load Byte and Zero
                    r0u = r0u ^ r9u;                                                //seg001:00000000005D9F58                 xor       r0, r0, r9    # XOR
                    Array.Copy(tmp16, (long)(0xC + 0), info4a, 0, 4);
                    r9u = SwapByteOrder(BitConverter.ToUInt32(info4a, 0)) >> 32;            //seg001:00000000005D9F5C                 lwz       r9, 0xE0+var_64(r1) # Load Word and Zero
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0x4 + 3), info4a, 0, 1);
                    r7u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9F60                 lbz       r7, 0xE0+var_6C+3(r1) # Load Byte and Zero
                    Array.Copy(BitConverter.GetBytes(SwapByteOrder(r0u) >> 32), 0, tmp16, (long)(0x8 + 0x0), 4);//seg001:00000000005D9F64                 stw       r0, 0xE0+var_68(r1) # Store Word
                    Array.Copy(keyData, (long)(0xC + r10u), info4a, 0, 4);
                    r11u = SwapByteOrder(BitConverter.ToUInt32(info4a, 0)) >> 32;            //seg001:00000000005D9F68                 lwz       r11, 0xC(r10) # Load Word and Zero
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0x0 + 0), info4a, 0, 1);
                    r0u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9F6C                 lbz       r0, 0xE0+var_70(r1) # Load Byte and Zero
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0x4 + 0), info4a, 0, 1);
                    r10u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9F70                 lbz       r10, 0xE0+var_6C(r1) # Load Byte and Zero
                    r9u = r9u ^ r11u;                                               //seg001:00000000005D9F74                 xor       r9, r9, r11   # XOR
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0x8 + 0), info4a, 0, 1);
                    r6u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9F78                 lbz       r6, 0xE0+var_68(r1) # Load Byte and Zero
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0x4 + 1), info4a, 0, 1);
                    r11u = BitConverter.ToUInt32(info4a, 0);                        //seg001:00000000005D9F7C                 lbz       r11, 0xE0+var_6C+1(r1) # Load Byte and Zero
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0x8 + 1), info4a, 0, 1);
                    r4u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9F80                 lbz       r4, 0xE0+var_68+1(r1) # Load Byte and Zero
                    Array.Copy(BitConverter.GetBytes(SwapByteOrder(r9u) >> 32), 0, tmp16, (long)(0xC + 0x0), 4);//seg001:00000000005D9F84                 stw       r9, 0xE0+var_64(r1) # Store Word
                    Array.Copy(BitConverter.GetBytes(r0u), 0, cryptedData, (long)(0x0 + r31u), 1);//seg001:00000000005D9F88                 stb       r0, 0(r31)    # Store Byte
                    Array.Copy(BitConverter.GetBytes(r29u), 0, cryptedData, (long)(0x1 + r31u), 1);//seg001:00000000005D9F8C                 stb       r29, 1(r31)   # Store Byte
                    Array.Copy(BitConverter.GetBytes(r10u), 0, cryptedData, (long)(0x4 + r31u), 1);//seg001:00000000005D9F90                 stb       r10, 4(r31)   # Store Byte
                    Array.Copy(BitConverter.GetBytes(r11u), 0, cryptedData, (long)(0x5 + r31u), 1);//seg001:00000000005D9F94                 stb       r11, 5(r31)   # Store Byte
                    Array.Copy(BitConverter.GetBytes(r8u), 0, cryptedData, (long)(0x6 + r31u), 1);//seg001:00000000005D9F98                 stb       r8, 6(r31)    # Store Byte
                    Array.Copy(BitConverter.GetBytes(r3u), 0, cryptedData, (long)(0x2 + r31u), 1);//seg001:00000000005D9F9C                 stb       r3, 2(r31)    # Store Byte
                    Array.Copy(BitConverter.GetBytes(r5u), 0, cryptedData, (long)(0x3 + r31u), 1);//seg001:00000000005D9FA0                 stb       r5, 3(r31)    # Store Byte
                    Array.Copy(BitConverter.GetBytes(r7u), 0, cryptedData, (long)(0x7 + r31u), 1);//seg001:00000000005D9FA4                 stb       r7, 7(r31)    # Store Byte
                    Array.Copy(BitConverter.GetBytes(r6u), 0, cryptedData, (long)(0x8 + r31u), 1);//seg001:00000000005D9FA8                 stb       r6, 8(r31)    # Store Byte
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0x8 + 2), info4a, 0, 1);
                    r9u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9FAC                 lbz       r9, 0xE0+var_68+2(r1) # Load Byte and Zero
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0x8 + 3), info4a, 0, 1);
                    r7u = BitConverter.ToUInt32(info4a, 0);//seg001:00000000005D9FB0                 lbz       r7, 0xE0+var_68+3(r1) # Load Byte and Zero
                    Array.Copy(BitConverter.GetBytes(r4u), 0, cryptedData, (long)(0x9 + r31u), 1);//seg001:00000000005D9FB4                 stb       r4, 9(r31)    # Store Byte
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0xC + 3), info4a, 0, 1);
                    r0u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9FB8                 lbz       r0, 0xE0+var_64+3(r1) # Load Byte and Zero
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0xC + 0), info4a, 0, 1);
                    r11u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9FBC                 lbz       r11, 0xE0+var_64(r1) # Load Byte and Zero
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0xC + 1), info4a, 0, 1);
                    r10u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9FC0                 lbz       r10, 0xE0+var_64+1(r1) # Load Byte and Zero
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0xC + 2), info4a, 0, 1);
                    r8u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9FC4                 lbz       r8, 0xE0+var_64+2(r1) # Load Byte and Zero
                    Array.Copy(BitConverter.GetBytes(r9u), 0, cryptedData, (long)(0xA + r31u), 1);//seg001:00000000005D9FC8                 stb       r9, 0xA(r31)  # Store Byte
                    Array.Copy(BitConverter.GetBytes(r0u), 0, cryptedData, (long)(0xF + r31u), 1);//seg001:00000000005D9FCC                 stb       r0, 0xF(r31)  # Store Byte
                    Array.Copy(BitConverter.GetBytes(r7u), 0, cryptedData, (long)(0xB + r31u), 1);//seg001:00000000005D9FD0                 stb       r7, 0xB(r31)  # Store Byte
                    Array.Copy(BitConverter.GetBytes(r11u), 0, cryptedData, (long)(0xC + r31u), 1);//seg001:00000000005D9FD4                 stb       r11, 0xC(r31) # Store Byte
                    Array.Copy(BitConverter.GetBytes(r10u), 0, cryptedData, (long)(0xD + r31u), 1);//seg001:00000000005D9FD8                 stb       r10, 0xD(r31) # Store Byte
                    Array.Copy(BitConverter.GetBytes(r8u), 0, cryptedData, (long)(0xE + r31u), 1);//seg001:00000000005D9FDC                 stb       r8, 0xE(r31)  # Store Byte
                    //loading pointer for blr                                           //seg001:00000000005D9FE0                 ld        r0, 0xE0+arg_10(r1) # Load Double Word
                    //loading pointer to size of data + alignment to 0x10               //seg001:00000000005D9FE4                 ld        r21, 0xE0+var_58(r1) # Load Double Word
                    //loading unknown pointer 1                                         //seg001:00000000005D9FE8                 ld        r22, 0xE0+var_50(r1) # Load Double Word
                    //seg001:00000000005D9FEC                 mtspr   LR, r0          # Move to sprg,
                    //loading pointer to pointer to pointer etc.. (possibly pointer to sbox)    //seg001:00000000005D9FF0                 ld        r23, 0xE0+var_48(r1) # Load Double Word
                    //loading pointer to pointer to pointer etc.. (possibly pointer to sbox)    //seg001:00000000005D9FF4                 ld        r24, 0xE0+var_40(r1) # Load Double Word
                    r25u = 0;   //loading pointer to start of cryptedData                       //seg001:00000000005D9FF8                 ld        r25, 0xE0+var_38(r1) # Load Double Word
                    //loading pointer to name of FARC entry being accessed                      //seg001:00000000005D9FFC                 ld        r26, 0xE0+var_30(r1) # Load Double Word
                    //loading size of data + alignment to 0x10;                                 //seg001:00000000005DA000                 ld        r27, 0xE0+var_28(r1) # Load Double Word
                    r28u = 0;   //loading pointer to start of cryptedData                       //seg001:00000000005DA004                 ld        r28, 0xE0+var_20(r1) # Load Double Word
                    r29u = r29uStored; //loading current pointer to dataToCrypt                 //seg001:00000000005DA008                 ld        r29, 0xE0+var_18(r1) # Load Double Word
                    //loading pointer to pointer to pointer etc.. (possibly pointer to ????)    //seg001:00000000005DA00C                 ld        r30, 0xE0+var_10(r1) # Load Double Word
                    //loading size of data + alignment to 0x10;                                 //seg001:00000000005DA010                 ld        r31, 0xE0+var_8(r1) # Load Double Word
                    r1u = r1u + 0xE0;                                                           //seg001:00000000005DA014                 addi      r1, r1, 0xE0  # Add Immediate
                    //seg001:00000000005DA018                 blr                     # lr=00000000000297D4

                }
                else
                {
                    //main crypto sub loops
                    r9u = ((r12u << 4) & 0xFFFFFFF0);                                   //seg001:00000000005D9EE0                 slwi      r9, r12, 4    # r9 = ((r12 << 4) & FFFFFFF0)
                    r27u = r21u & 0xFFFFFFFF;                                           //seg001:00000000005D9EE4                 clrldi    r27, r21, 32  # r27 = r21 & 0xFFFFFFFF
                    r9u = r9u + r30u;  //pointing to keyData 1st group 2nd to last line //seg001:00000000005D9EE8                 add       r9, r9, r30   # Add
                    r29u = r9u + 0xF0; //pointing to keyData 2nd group 2nd to last line //seg001:00000000005D9EEC                 addi      r29, r9, 0xF0 # Add Immediate

                    //FIRST WHILE LOOP
                    while (r28u != 0)
                    {
                        r3u = r27u; //pointing to tmp16                                 //seg001:00000000005D9EF0                 mr        r3, r27       # Move Register
                        r28u = r28u - 1;                                                //seg001:00000000005D9EF4                 addi      r28, r28, -1  # Add Immediate

                        //seg001:00000000005D9EF8                 bl        sub_5D9A70    # prelim sub
                        #region sub_5D9A70
                        r7u = 0; //pointer to start of sbox  //r7u = 0x00000000B475A0;  //seg001:00000000005D9A70                 lwz       r7, off_C0151C # unk_B475A0 # Load Word and Zero
                        r11u = r3u;                                                     //seg001:00000000005D9A74                 mr        r11, r3       # Move Register
                        info4a = new byte[4];
                        Array.Copy(tmp16, (long)(0x0 + 0), info4a, 0, 1);
                        r9u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9A78                 lbz       r9, 0(r3)     # loading changed file key
                        r8u = r3u;                                                      //seg001:00000000005D9A7C                 mr        r8, r3        # Move Register
                        r4u = r3u;                                                      //seg001:00000000005D9A80                 mr        r4, r3        # Move Register
                        r9u = r9u + r7u;                                                //seg001:00000000005D9A84                 add       r9, r9, r7    # Add
                        r6u = r3u;                                                      //seg001:00000000005D9A88                 mr        r6, r3        # Move Register
                        r10u = r3u;                                                     //seg001:00000000005D9A8C                 mr        r10, r3       # Move Register
                        info4a = new byte[4];
                        Array.Copy(sbox_v100, (long)(0x100 + r9u), info4a, 0, 1);
                        r0u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9A90                 lbz       r0, 0x100(r9) # reading from a possible lookup table
                        Array.Copy(BitConverter.GetBytes(r0u), 0, tmp16, (long)(0x0 + r3u), 1);//seg001:00000000005D9A94                 stb       r0, 0(r3)     # storing byte from possible lookup table over first byte of possible changed key
                        info4a = new byte[4];
                        Array.Copy(tmp16, (long)(0x4 + r11u), info4a, 0, 1);
                        r9u = BitConverter.ToUInt32(info4a, 0);
                        r11u = (4 + r11u);                                                       //seg001:00000000005D9A98                 lbzu      r9, 4(r11)    # Load Byte and Zero with Update
                        r9u = r9u & 0xFF;                                               //seg001:00000000005D9A9C                 clrldi    r9, r9, 56    # r9 = r9 & 0xFF
                        r9u = r9u + r7u;                                                //seg001:00000000005D9AA0                 add       r9, r9, r7    # Add
                        info4a = new byte[4];
                        Array.Copy(sbox_v100, (long)(0x100 + r9u), info4a, 0, 1);
                        r0u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9AA4                 lbz       r0, 0x100(r9) # Load Byte and Zero
                        Array.Copy(BitConverter.GetBytes(r0u), 0, tmp16, (long)(0x0 + r11u), 1);//seg001:00000000005D9AA8                 stb       r0, 0(r11)    # Store Byte
                        info4a = new byte[4];
                        Array.Copy(tmp16, (long)(0x8 + r8u), info4a, 0, 1);
                        r9u = BitConverter.ToUInt32(info4a, 0);
                        r8u = (8 + r8u);                                                        //seg001:00000000005D9AAC                 lbzu      r9, 8(r8)     # Load Byte and Zero with Update
                        r11u = r3u;                                                     //seg001:00000000005D9AB0                 mr        r11, r3       # Move Register
                        r9u = r9u & 0xFF;                                               //seg001:00000000005D9AB4                 clrldi    r9, r9, 56    # r9 = r9 & 0xFF
                        r9u = r9u + r7u;                                                //seg001:00000000005D9AB8                 add       r9, r9, r7    # Add
                        info4a = new byte[4];
                        Array.Copy(sbox_v100, (long)(0x100 + r9u), info4a, 0, 1);
                        r0u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9ABC                 lbz       r0, 0x100(r9) # Load Byte and Zero
                        Array.Copy(BitConverter.GetBytes(r0u), 0, tmp16, (long)(0x0 + r8u), 1);//seg001:00000000005D9AC0                 stb       r0, 0(r8)     # Store Byte
                        info4a = new byte[4];
                        Array.Copy(tmp16, (long)(0xC + r11u), info4a, 0, 1);
                        r9u = BitConverter.ToUInt32(info4a, 0);
                        r11u = (0xC + r11u);                                                     //seg001:00000000005D9AC4                 lbzu      r9, 0xC(r11)  # Load Byte and Zero with Update
                        r8u = r3u;                                                      //seg001:00000000005D9AC8                 mr        r8, r3        # Move Register
                        r9u = r9u & 0xFF;                                               //seg001:00000000005D9ACC                 clrldi    r9, r9, 56    # r9 = r9 & 0xFF
                        r9u = r9u + r7u;                                                //seg001:00000000005D9AD0                 add       r9, r9, r7    # Add
                        info4a = new byte[4];
                        Array.Copy(sbox_v100, (long)(0x100 + r9u), info4a, 0, 1);
                        r0u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9AD4                 lbz       r0, 0x100(r9) # Load Byte and Zero
                        Array.Copy(BitConverter.GetBytes(r0u), 0, tmp16, (long)(0x0 + r11u), 1);//seg001:00000000005D9AD8                 stb       r0, 0(r11)    # Store Byte
                        info4a = new byte[4];
                        Array.Copy(tmp16, (long)(0x9 + r4u), info4a, 0, 1);
                        r9u = BitConverter.ToUInt32(info4a, 0);
                        r4u = (0x9 + r4u);                                                     //seg001:00000000005D9ADC                 lbzu      r9, 9(r4)     # Load Byte and Zero with Update
                        info4a = new byte[4];
                        Array.Copy(tmp16, (long)(0xD + r8u), info4a, 0, 1);
                        r11u = BitConverter.ToUInt32(info4a, 0);
                        r8u = (0xD + r8u);                                                     //seg001:00000000005D9AE0                 lbzu      r11, 0xD(r8)  # Load Byte and Zero with Update
                        r9u = r9u & 0xFF;                                               //seg001:00000000005D9AE4                 clrldi    r9, r9, 56    # r9 = r9 & 0xFF
                        r11u = r11u & 0xFF;                                             //seg001:00000000005D9AE8                 clrldi    r11, r11, 56  # r11 = r11 & 0xFF
                        r9u = r9u + r7u;                                                //seg001:00000000005D9AEC                 add       r9, r9, r7    # Add
                        r11u = r11u + r7u;                                              //seg001:00000000005D9AF0                 add       r11, r11, r7  # Add
                        info4a = new byte[4];
                        Array.Copy(sbox_v100, (long)(0x100 + r9u), info4a, 0, 1);
                        r0u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9AF4                 lbz       r0, 0x100(r9) # Load Byte and Zero
                        info4a = new byte[4];
                        Array.Copy(sbox_v100, (long)(0x100 + r11u), info4a, 0, 1);
                        r5u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9AF8                 lbz       r5, 0x100(r11) # Load Byte and Zero
                        r11u = r3u;                                                     //seg001:00000000005D9AFC                 mr        r11, r3       # Move Register
                        Array.Copy(BitConverter.GetBytes(r0u), 0, tmp16, (long)(0x0 + r8u), 1);//seg001:00000000005D9B00                 stb       r0, 0(r8)     # Store Byte
                        info4a = new byte[4];
                        Array.Copy(tmp16, (long)(0x5 + r6u), info4a, 0, 1);
                        r9u = BitConverter.ToUInt32(info4a, 0);
                        r6u = (0x5 + r6u);                                                     //seg001:00000000005D9B04                 lbzu      r9, 5(r6)     # Load Byte and Zero with Update
                        r9u = r9u & 0xFF;                                               //seg001:00000000005D9B08                 clrldi    r9, r9, 56    # r9 = r9 & 0xFF
                        r9u = r9u + r7u;                                                //seg001:00000000005D9B0C                 add       r9, r9, r7    # Add
                        info4a = new byte[4];
                        Array.Copy(sbox_v100, (long)(0x100 + r9u), info4a, 0, 1);
                        r0u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9B10                 lbz       r0, 0x100(r9) # Load Byte and Zero
                        Array.Copy(BitConverter.GetBytes(r0u), 0, tmp16, (long)(0x0 + r4u), 1);//seg001:00000000005D9B14                 stb       r0, 0(r4)     # Store Byte
                        info4a = new byte[4];
                        Array.Copy(tmp16, (long)(0x1 + r11u), info4a, 0, 1);
                        r9u = BitConverter.ToUInt32(info4a, 0);
                        r11u = (0x1 + r11u);                                                     //seg001:00000000005D9B18                 lbzu      r9, 1(r11)    # Load Byte and Zero with Update
                        r4u = r3u;                                                      //seg001:00000000005D9B1C                 mr        r4, r3        # Move Register
                        r9u = r9u & 0xFF;                                               //seg001:00000000005D9B20                 clrldi    r9, r9, 56    # r9 = r9 & 0xFF
                        r9u = r9u + r7u;                                                //seg001:00000000005D9B24                 add       r9, r9, r7    # Add
                        info4a = new byte[4];
                        Array.Copy(sbox_v100, (long)(0x100 + r9u), info4a, 0, 1);
                        r0u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9B28                 lbz       r0, 0x100(r9) # Load Byte and Zero
                        Array.Copy(BitConverter.GetBytes(r0u), 0, tmp16, (long)(0x0 + r6u), 1); //seg001:00000000005D9B2C                 stb       r0, 0(r6)     # Store Byte
                        Array.Copy(BitConverter.GetBytes(r5u), 0, tmp16, (long)(0x0 + r11u), 1);//seg001:00000000005D9B30                 stb       r5, 0(r11)    # Store Byte
                        r5u = r3u;                                                      //seg001:00000000005D9B34                 mr        r5, r3        # Move Register
                        r6u = r3u;                                                      //seg001:00000000005D9B38                 mr        r6, r3        # Move Register
                        info4a = new byte[4];
                        Array.Copy(tmp16, (long)(0x6 + r5u), info4a, 0, 1);
                        r11u = BitConverter.ToUInt32(info4a, 0);
                        r5u = (0x6 + r5u);                                                     //seg001:00000000005D9B3C                 lbzu      r11, 6(r5)    # Load Byte and Zero with Update
                        info4a = new byte[4];
                        Array.Copy(tmp16, (long)(0xE + r6u), info4a, 0, 1);
                        r9u = BitConverter.ToUInt32(info4a, 0);
                        r6u = (0xE + r6u);                                                     //seg001:00000000005D9B40                 lbzu      r9, 0xE(r6)   # Load Byte and Zero with Update
                        r11u = r11u & 0xFF;                                             //seg001:00000000005D9B44                 clrldi    r11, r11, 56  # r11 = r11 & 0xFF
                        r9u = r9u & 0xFF;                                               //seg001:00000000005D9B48                 clrldi    r9, r9, 56    # r9 = r9 & 0xFF
                        r11u = r11u + r7u;                                              //seg001:00000000005D9B4C                 add       r11, r11, r7  # Add
                        r9u = r9u + r7u;                                                //seg001:00000000005D9B50                 add       r9, r9, r7    # Add
                        info4a = new byte[4];
                        Array.Copy(sbox_v100, (long)(0x100 + r11u), info4a, 0, 1);
                        r0u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9B54                 lbz       r0, 0x100(r11) # Load Byte and Zero
                        info4a = new byte[4];
                        Array.Copy(sbox_v100, (long)(0x100 + r9u), info4a, 0, 1);
                        r8u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9B58                 lbz       r8, 0x100(r9) # Load Byte and Zero
                        Array.Copy(BitConverter.GetBytes(r0u), 0, tmp16, (long)(0x0 + r6u), 1);//seg001:00000000005D9B5C                 stb       r0, 0(r6)     # Store Byte
                        r6u = r3u;                                                      //seg001:00000000005D9B60                 mr        r6, r3        # Move Register
                        Array.Copy(BitConverter.GetBytes(r8u), 0, tmp16, (long)(0x0 + r5u), 1);//seg001:00000000005D9B64                 stb       r8, 0(r5)     # Store Byte
                        info4a = new byte[4];
                        Array.Copy(tmp16, (long)(0x2 + r4u), info4a, 0, 1);
                        r9u = BitConverter.ToUInt32(info4a, 0);
                        r4u = (0x2 + r4u);                                                     //seg001:00000000005D9B68                 lbzu      r9, 2(r4)     # Load Byte and Zero with Update
                        info4a = new byte[4];
                        Array.Copy(tmp16, (long)(0xA + r6u), info4a, 0, 1);
                        r11u = BitConverter.ToUInt32(info4a, 0);
                        r6u = (0xA + r6u);                                                     //seg001:00000000005D9B6C                 lbzu      r11, 0xA(r6)  # Load Byte and Zero with Update
                        r9u = r9u & 0xFF;                                               //seg001:00000000005D9B70                 clrldi    r9, r9, 56    # r9 = r9 & 0xFF
                        r11u = r11u & 0xFF;                                             //seg001:00000000005D9B74                 clrldi    r11, r11, 56  # r11 = r11 & 0xFF
                        r9u = r9u + r7u;                                                //seg001:00000000005D9B78                 add       r9, r9, r7    # Add
                        r11u = r11u + r7u;                                              //seg001:00000000005D9B7C                 add       r11, r11, r7  # Add
                        r5u = r3u;                                                      //seg001:00000000005D9B80                 mr        r5, r3        # Move Register
                        info4a = new byte[4];
                        Array.Copy(sbox_v100, (long)(0x100 + r9u), info4a, 0, 1);
                        r0u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9B84                 lbz       r0, 0x100(r9) # Load Byte and Zero
                        info4a = new byte[4];
                        Array.Copy(sbox_v100, (long)(0x100 + r11u), info4a, 0, 1);
                        r8u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9B88                 lbz       r8, 0x100(r11) # Load Byte and Zero
                        Array.Copy(BitConverter.GetBytes(r0u), 0, tmp16, (long)(0x0 + r6u), 1);//seg001:00000000005D9B8C                 stb       r0, 0(r6)     # Store Byte
                        Array.Copy(BitConverter.GetBytes(r8u), 0, tmp16, (long)(0x0 + r4u), 1);//seg001:00000000005D9B90                 stb       r8, 0(r4)     # Store Byte
                        r8u = r3u;                                                      //seg001:00000000005D9B94                 mr        r8, r3        # Move Register
                        info4a = new byte[4];
                        Array.Copy(tmp16, (long)(0x7 + r5u), info4a, 0, 1);
                        r9u = BitConverter.ToUInt32(info4a, 0);
                        r5u = (0x7 + r5u);                                                     //seg001:00000000005D9B98                 lbzu      r9, 7(r5)     # Load Byte and Zero with Update
                        info4a = new byte[4];
                        Array.Copy(tmp16, (long)(0x3 + r8u), info4a, 0, 1);
                        r11u = BitConverter.ToUInt32(info4a, 0);
                        r8u = (0x3 + r8u);                                                     //seg001:00000000005D9B9C                 lbzu      r11, 3(r8)    # Load Byte and Zero with Update
                        r9u = r9u & 0xFF;                                               //seg001:00000000005D9BA0                 clrldi    r9, r9, 56    # r9 = r9 & 0xFF
                        r11u = r11u & 0xFF;                                             //seg001:00000000005D9BA4                 clrldi    r11, r11, 56  # r11 = r11 & 0xFF
                        r9u = r9u + r7u;                                                //seg001:00000000005D9BA8                 add       r9, r9, r7    # Add
                        r11u = r11u + r7u;                                               //seg001:00000000005D9BAC                 add       r11, r11, r7  # Add
                        info4a = new byte[4];
                        Array.Copy(sbox_v100, (long)(0x100 + r9u), info4a, 0, 1);
                        r0u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9BB0                 lbz       r0, 0x100(r9) # Load Byte and Zero
                        info4a = new byte[4];
                        Array.Copy(sbox_v100, (long)(0x100 + r11u), info4a, 0, 1);
                        r6u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9BB4                 lbz       r6, 0x100(r11) # Load Byte and Zero
                        r11u = r3u;                                                     //seg001:00000000005D9BB8                 mr        r11, r3       # Move Register
                        Array.Copy(BitConverter.GetBytes(r0u), 0, tmp16, (long)(0x0 + r8u), 1);//seg001:00000000005D9BBC                 stb       r0, 0(r8)     # Store Byte
                        info4a = new byte[4];
                        Array.Copy(tmp16, (long)(0xB + r11u), info4a, 0, 1);
                        r9u = BitConverter.ToUInt32(info4a, 0);
                        r11u = (0xB + r11u);                                                     //seg001:00000000005D9BC0                 lbzu      r9, 0xB(r11)  # Load Byte and Zero with Update
                        r9u = r9u & 0xFF;                                               //seg001:00000000005D9BC4                 clrldi    r9, r9, 56    # r9 = r9 & 0xFF
                        r9u = r9u + r7u;                                                //seg001:00000000005D9BC8                 add       r9, r9, r7    # Add
                        info4a = new byte[4];
                        Array.Copy(sbox_v100, (long)(0x100 + r9u), info4a, 0, 1);
                        r0u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9BCC                 lbz       r0, 0x100(r9) # Load Byte and Zero
                        Array.Copy(BitConverter.GetBytes(r0u), 0, tmp16, (long)(0x0 + r5u), 1);//seg001:00000000005D9BD0                 stb       r0, 0(r5)     # Store Byte
                        info4a = new byte[4];
                        Array.Copy(tmp16, (long)(0xF + r10u), info4a, 0, 1);
                        r9u = BitConverter.ToUInt32(info4a, 0);
                        r10u = (0xF + r10u);                                                     //seg001:00000000005D9BD4                 lbzu      r9, 0xF(r10)  # Load Byte and Zero with Update
                        r9u = r9u & 0xFF;                                               //seg001:00000000005D9BD8                 clrldi    r9, r9, 56    # r9 = r9 & 0xFF
                        r9u = r9u + r7u;                                                //seg001:00000000005D9BDC                 add       r9, r9, r7    # Add
                        info4a = new byte[4];
                        Array.Copy(sbox_v100, (long)(0x100 + r9u), info4a, 0, 1);
                        r0u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9BE0                 lbz       r0, 0x100(r9) # Load Byte and Zero
                        Array.Copy(BitConverter.GetBytes(r0u), 0, tmp16, (long)(0x0 + r11u), 1);//seg001:00000000005D9BE4                 stb       r0, 0(r11)    # Store Byte
                        Array.Copy(BitConverter.GetBytes(r6u), 0, tmp16, (long)(0x0 + r10u), 1);//seg001:00000000005D9BE8                 stb       r6, 0(r10)    # Store Byte
                        //seg001:00000000005D9BEC                 blr                     # Branch unconditionally

                        bp++;

                        #endregion


                        r4u = r29u & 0xFFFFFFFF;                                        //seg001:00000000005D9EFC                 clrldi    r4, r29, 32   # r4 = r29 & 0xFFFFFFFF
                        r3u = r27u;                                                     //seg001:00000000005D9F00                 mr        r3, r27       # Move Register
                        r29u = r29u - 0x10;                                             //seg001:00000000005D9F04                 addi      r29, r29, -0x10 # Add Immediate

                        //seg001:00000000005D9F08                 bl        sub_5D9C98    # main sub
                        #region sub_5D9C98
                        r0u = 4;                                                        //seg001:00000000005D9C98                 li        r0, 4         # Load Immediate
                        r12u = 0; //pointer to start of sbox                            //seg001:00000000005D9C9C                 lwz       r12, off_C0151C # unk_B475A0 # Load Word and Zero
                        ulong r30uStored = r30u;//storing pointer to start of keyData                           //seg001:00000000005D9CA0                 std       r30, var_10(r1) # Store Double Word
                        ulong r31uStored = r31u;//storing pointer to start of dataToCrypt                       //seg001:00000000005D9CA4                 std       r31, var_8(r1) # Store Double Word
                        ctru = r0u;                                                     //seg001:00000000005D9CA8                 mtspr   CTR, r0         # Move to sprg,
                        r30u = r3u;                                                     //seg001:00000000005D9CAC                 mr        r30, r3       # Move Register
                        r31u = r4u;                                                     //seg001:00000000005D9CB0                 mr        r31, r4       # Move Register
                        r3u = 0;                                                        //seg001:00000000005D9CB4                 li        r3, 0         # Load Immediate

                        for (ulong j = 0; j < ctru; j++)
                        {
                            r4u = r30u + r3u;                                           //seg001:00000000005D9CB8                 add       r4, r30, r3   # Add
                            r11u = r3u + r31u;                                          //seg001:00000000005D9CBC                 add       r11, r3, r31  # Add
                            r4u = r4u & 0xFFFFFFFF;                                     //seg001:00000000005D9CC0                 clrldi    r4, r4, 32    # r4 = r4 & 0xFFFFFFFF
                            r11u = r11u & 0xFFFFFFFF;                                   //seg001:00000000005D9CC4                 clrldi    r11, r11, 32  # r11 = r11 & 0xFFFFFFFF
                            r3u = r3u + 4;                                              //seg001:00000000005D9CC8                 addi      r3, r3, 4     # Add Immediate
                            info4a = new byte[4];
                            Array.Copy(tmp16, (long)(0x1 + r4u), info4a, 0, 1);
                            r9u = BitConverter.ToUInt32(info4a, 0);                     //seg001:00000000005D9CCC                 lbz       r9, 1(r4)     # Load Byte and Zero
                            info4a = new byte[4];
                            Array.Copy(tmp16, (long)(0x2 + r4u), info4a, 0, 1);
                            r7u = BitConverter.ToUInt32(info4a, 0);                     //seg001:00000000005D9CD0                 lbz       r7, 2(r4)     # Load Byte and Zero
                            info4a = new byte[4];
                            Array.Copy(tmp16, (long)(0x0 + r4u), info4a, 0, 1);
                            r6u = BitConverter.ToUInt32(info4a, 0);                     //seg001:00000000005D9CD4                 lbz       r6, 0(r4)     # Load Byte and Zero
                            r9u = ((r9u << 2) & 0xFFFFFFFC) & 0x3FC;                    //seg001:00000000005D9CD8                 clrlslwi  r9, r9, 24,2  # r9 = ((r9 << 2) & FFFFFFFC) & 0x3FC
                            info4a = new byte[4];
                            Array.Copy(tmp16, (long)(0x3 + r4u), info4a, 0, 1);
                            r5u = BitConverter.ToUInt32(info4a, 0);                     //seg001:00000000005D9CDC                 lbz       r5, 3(r4)     # Load Byte and Zero
                            r7u = ((r7u << 2) & 0xFFFFFFFC) & 0x3FC;                    //seg001:00000000005D9CE0                 clrlslwi  r7, r7, 24,2  # r7 = ((r7 << 2) & FFFFFFFC) & 0x3FC
                            r6u = ((r6u << 2) & 0xFFFFFFFC) & 0x3FC;                    //seg001:00000000005D9CE4                 clrlslwi  r6, r6, 24,2  # r6 = ((r6 << 2) & FFFFFFFC) & 0x3FC
                            Array.Copy(keyData, (long)(0x0 + r11u), info4a, 0, 4);
                            r10u = SwapByteOrder(BitConverter.ToUInt32(info4a, 0)) >> 32;            //seg001:00000000005D9CE8                 lwz       r10, 0(r11)   # Load Word and Zero
                            r5u = ((r5u << 2) & 0xFFFFFFFC) & 0x3FC;                    //seg001:00000000005D9CEC                 clrlslwi  r5, r5, 24,2  # r5 = ((r5 << 2) & FFFFFFFC) & 0x3FC
                            r9u = r9u + r12u;                                           //seg001:00000000005D9CF0                 add       r9, r9, r12   # Add
                            r7u = r7u + r12u;                                           //seg001:00000000005D9CF4                 add       r7, r7, r12   # Add
                            r6u = r6u + r12u;                                           //seg001:00000000005D9CF8                 add       r6, r6, r12   # Add
                            r5u = r5u + r12u;                                           //seg001:00000000005D9CFC                 add       r5, r5, r12   # Add
                            Array.Copy(sbox2, (long)(0x600 + r9u), info4a, 0, 4);
                            r0u = SwapByteOrder(BitConverter.ToUInt32(info4a, 0)) >> 32;            //seg001:00000000005D9D00                 lwz       r0, 0x600(r9) # Load Word and Zero
                            Array.Copy(sbox2, (long)(0x600 + r7u), info4a, 0, 4);
                            r11u = SwapByteOrder(BitConverter.ToUInt32(info4a, 0)) >> 32;            //seg001:00000000005D9D04                 lwz       r11, 0x600(r7) # Load Word and Zero
                            Array.Copy(sbox2, (long)(0x600 + r6u), info4a, 0, 4);
                            r8u = SwapByteOrder(BitConverter.ToUInt32(info4a, 0)) >> 32;            //seg001:00000000005D9D08                 lwz       r8, 0x600(r6) # Load Word and Zero
                            r0u = (((r0u << 24) & 0xFF000000) | ((r0u >> 8) & 0xFFFFFF));           //seg001:00000000005D9D0C                 rotrwi    r0, r0, 8     # r0 = (((r0 << 24) & FF000000) | ((r0 >> 8) & 0xFFFFFF))
                            Array.Copy(sbox2, (long)(0x600 + r5u), info4a, 0, 4);
                            r9u = SwapByteOrder(BitConverter.ToUInt32(info4a, 0)) >> 32;            //seg001:00000000005D9D10                 lwz       r9, 0x600(r5) # Load Word and Zero
                            r11u = (((r11u << 16) & 0xFFFF0000) | ((r11u >> 16) & 0xFFFF));         //seg001:00000000005D9D14                 rotrwi    r11, r11, 16  # r11 = (((r11 << 16) & FFFF0000) | ((r11 >> 16) & 0xFFFF))
                            r10u = r10u ^ r8u;                                                      //seg001:00000000005D9D18                 xor       r10, r10, r8  # XOR
                            r9u = (((r9u << 8) & 0xFFFFFF00) | ((r9u >> 24) & 0xFF));               //seg001:00000000005D9D1C                 rotlwi    r9, r9, 8     # r9 = (((r9 << 8) & FFFFFF00) | ((r9 >> 24) & 0xFF))
                            r0u = r0u ^ r11u;                                                       //seg001:00000000005D9D20                 xor       r0, r0, r11   # XOR
                            r10u = r10u ^ r9u;                                                      //seg001:00000000005D9D24                 xor       r10, r10, r9  # XOR
                            r0u = r0u ^ r10u;                                                       //seg001:00000000005D9D28                 xor       r0, r0, r10   # XOR
                            Array.Copy(BitConverter.GetBytes(SwapByteOrder(r0u) >> 32), 0, tmp16, (long)(0x0 + r4u), 4);//seg001:00000000005D9D2C                 stw       r0, 0(r4)     # Store Word
                            //seg001:00000000005D9D30                 bdnz      loc_5D9CB8    # CTR--; branch if CTR non-zero

                        }
                        bp++;
                        r30u = r30uStored;// r30u = 0; //pointer to start of keyData                //seg001:00000000005D9D34                 ld        r30, var_10(r1) # Load Double Word
                        r31u = r31uStored;// r31u = 0; //pointer to start of dataToCrypt            //seg001:00000000005D9D38                 ld        r31, var_8(r1) # Load Double Word
                        //seg001:00000000005D9D3C                 blr                     # Branch unconditionally

                        #endregion

                        //seg001:00000000005D9F0C                 cmpwi     cr7, r28, 0   # Compare Word Immediate
                        //seg001:00000000005D9F10                 bne       cr7, loc_5D9EF0 # Branch if not equal

                    }

                    r3u = r21u;                                             //seg001:00000000005D9F14                 mr        r3, r21       # Move Register

                    //seg001:00000000005D9F18                 bl        sub_5D9A70    # prelim sub
                    #region sub_5D9A70
                    r7u = 0; //pointer to start of sbox  //r7u = 0x00000000B475A0;  //seg001:00000000005D9A70                 lwz       r7, off_C0151C # unk_B475A0 # Load Word and Zero
                    r11u = r3u;                                                     //seg001:00000000005D9A74                 mr        r11, r3       # Move Register
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0x0 + 0), info4a, 0, 1);
                    r9u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9A78                 lbz       r9, 0(r3)     # loading changed file key
                    r8u = r3u;                                                      //seg001:00000000005D9A7C                 mr        r8, r3        # Move Register
                    r4u = r3u;                                                      //seg001:00000000005D9A80                 mr        r4, r3        # Move Register
                    r9u = r9u + r7u;                                                //seg001:00000000005D9A84                 add       r9, r9, r7    # Add
                    r6u = r3u;                                                      //seg001:00000000005D9A88                 mr        r6, r3        # Move Register
                    r10u = r3u;                                                     //seg001:00000000005D9A8C                 mr        r10, r3       # Move Register
                    info4a = new byte[4];
                    Array.Copy(sbox_v100, (long)(0x100 + r9u), info4a, 0, 1);
                    r0u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9A90                 lbz       r0, 0x100(r9) # reading from a possible lookup table
                    Array.Copy(BitConverter.GetBytes(r0u), 0, tmp16, (long)(0x0 + r3u), 1);//seg001:00000000005D9A94                 stb       r0, 0(r3)     # storing byte from possible lookup table over first byte of possible changed key
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0x4 + r11u), info4a, 0, 1);
                    r9u = BitConverter.ToUInt32(info4a, 0);
                    r11u = (0x4 + r11u);                                                       //seg001:00000000005D9A98                 lbzu      r9, 4(r11)    # Load Byte and Zero with Update
                    r9u = r9u & 0xFF;                                               //seg001:00000000005D9A9C                 clrldi    r9, r9, 56    # r9 = r9 & 0xFF
                    r9u = r9u + r7u;                                                //seg001:00000000005D9AA0                 add       r9, r9, r7    # Add
                    info4a = new byte[4];
                    Array.Copy(sbox_v100, (long)(0x100 + r9u), info4a, 0, 1);
                    r0u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9AA4                 lbz       r0, 0x100(r9) # Load Byte and Zero
                    Array.Copy(BitConverter.GetBytes(r0u), 0, tmp16, (long)(0x0 + r11u), 1);//seg001:00000000005D9AA8                 stb       r0, 0(r11)    # Store Byte
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0x8 + r8u), info4a, 0, 1);
                    r9u = BitConverter.ToUInt32(info4a, 0);
                    r8u = (0x8 + r8u);                                                        //seg001:00000000005D9AAC                 lbzu      r9, 8(r8)     # Load Byte and Zero with Update
                    r11u = r3u;                                                     //seg001:00000000005D9AB0                 mr        r11, r3       # Move Register
                    r9u = r9u & 0xFF;                                               //seg001:00000000005D9AB4                 clrldi    r9, r9, 56    # r9 = r9 & 0xFF
                    r9u = r9u + r7u;                                                //seg001:00000000005D9AB8                 add       r9, r9, r7    # Add
                    info4a = new byte[4];
                    Array.Copy(sbox_v100, (long)(0x100 + r9u), info4a, 0, 1);
                    r0u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9ABC                 lbz       r0, 0x100(r9) # Load Byte and Zero
                    Array.Copy(BitConverter.GetBytes(r0u), 0, tmp16, (long)(0x0 + r8u), 1);//seg001:00000000005D9AC0                 stb       r0, 0(r8)     # Store Byte
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0xC + r11u), info4a, 0, 1);
                    r9u = BitConverter.ToUInt32(info4a, 0);
                    r11u = (0xC + r11u);                                                     //seg001:00000000005D9AC4                 lbzu      r9, 0xC(r11)  # Load Byte and Zero with Update
                    r8u = r3u;                                                      //seg001:00000000005D9AC8                 mr        r8, r3        # Move Register
                    r9u = r9u & 0xFF;                                               //seg001:00000000005D9ACC                 clrldi    r9, r9, 56    # r9 = r9 & 0xFF
                    r9u = r9u + r7u;                                                //seg001:00000000005D9AD0                 add       r9, r9, r7    # Add
                    info4a = new byte[4];
                    Array.Copy(sbox_v100, (long)(0x100 + r9u), info4a, 0, 1);
                    r0u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9AD4                 lbz       r0, 0x100(r9) # Load Byte and Zero
                    Array.Copy(BitConverter.GetBytes(r0u), 0, tmp16, (long)(0x0 + r11u), 1);//seg001:00000000005D9AD8                 stb       r0, 0(r11)    # Store Byte
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0x9 + r4u), info4a, 0, 1);
                    r9u = BitConverter.ToUInt32(info4a, 0);
                    r4u = (0x9 + r4u);                                                     //seg001:00000000005D9ADC                 lbzu      r9, 9(r4)     # Load Byte and Zero with Update
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0xD + r8u), info4a, 0, 1);
                    r11u = BitConverter.ToUInt32(info4a, 0);
                    r8u = (0xD + r8u);                                                     //seg001:00000000005D9AE0                 lbzu      r11, 0xD(r8)  # Load Byte and Zero with Update
                    r9u = r9u & 0xFF;                                               //seg001:00000000005D9AE4                 clrldi    r9, r9, 56    # r9 = r9 & 0xFF
                    r11u = r11u & 0xFF;                                             //seg001:00000000005D9AE8                 clrldi    r11, r11, 56  # r11 = r11 & 0xFF
                    r9u = r9u + r7u;                                                //seg001:00000000005D9AEC                 add       r9, r9, r7    # Add
                    r11u = r11u + r7u;                                              //seg001:00000000005D9AF0                 add       r11, r11, r7  # Add
                    info4a = new byte[4];
                    Array.Copy(sbox_v100, (long)(0x100 + r9u), info4a, 0, 1);
                    r0u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9AF4                 lbz       r0, 0x100(r9) # Load Byte and Zero
                    info4a = new byte[4];
                    Array.Copy(sbox_v100, (long)(0x100 + r11u), info4a, 0, 1);
                    r5u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9AF8                 lbz       r5, 0x100(r11) # Load Byte and Zero
                    r11u = r3u;                                                     //seg001:00000000005D9AFC                 mr        r11, r3       # Move Register
                    Array.Copy(BitConverter.GetBytes(r0u), 0, tmp16, (long)(0x0 + r8u), 1);//seg001:00000000005D9B00                 stb       r0, 0(r8)     # Store Byte
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0x5 + r6u), info4a, 0, 1);
                    r9u = BitConverter.ToUInt32(info4a, 0);
                    r6u = (0x5 + r6u);                                                     //seg001:00000000005D9B04                 lbzu      r9, 5(r6)     # Load Byte and Zero with Update
                    r9u = r9u & 0xFF;                                               //seg001:00000000005D9B08                 clrldi    r9, r9, 56    # r9 = r9 & 0xFF
                    r9u = r9u + r7u;                                                //seg001:00000000005D9B0C                 add       r9, r9, r7    # Add
                    info4a = new byte[4];
                    Array.Copy(sbox_v100, (long)(0x100 + r9u), info4a, 0, 1);
                    r0u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9B10                 lbz       r0, 0x100(r9) # Load Byte and Zero
                    Array.Copy(BitConverter.GetBytes(r0u), 0, tmp16, (long)(0x0 + r4u), 1);//seg001:00000000005D9B14                 stb       r0, 0(r4)     # Store Byte
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0x1 + r11u), info4a, 0, 1);
                    r9u = BitConverter.ToUInt32(info4a, 0);
                    r11u = (0x1 + r11u);                                                     //seg001:00000000005D9B18                 lbzu      r9, 1(r11)    # Load Byte and Zero with Update
                    r4u = r3u;                                                      //seg001:00000000005D9B1C                 mr        r4, r3        # Move Register
                    r9u = r9u & 0xFF;                                               //seg001:00000000005D9B20                 clrldi    r9, r9, 56    # r9 = r9 & 0xFF
                    r9u = r9u + r7u;                                                //seg001:00000000005D9B24                 add       r9, r9, r7    # Add
                    info4a = new byte[4];
                    Array.Copy(sbox_v100, (long)(0x100 + r9u), info4a, 0, 1);
                    r0u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9B28                 lbz       r0, 0x100(r9) # Load Byte and Zero
                    Array.Copy(BitConverter.GetBytes(r0u), 0, tmp16, (long)(0x0 + r6u), 1); //seg001:00000000005D9B2C                 stb       r0, 0(r6)     # Store Byte
                    Array.Copy(BitConverter.GetBytes(r5u), 0, tmp16, (long)(0x0 + r11u), 1);//seg001:00000000005D9B30                 stb       r5, 0(r11)    # Store Byte
                    r5u = r3u;                                                      //seg001:00000000005D9B34                 mr        r5, r3        # Move Register
                    r6u = r3u;                                                      //seg001:00000000005D9B38                 mr        r6, r3        # Move Register
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0x6 + r5u), info4a, 0, 1);
                    r11u = BitConverter.ToUInt32(info4a, 0);
                    r5u = (0x6 + r5u);                                                     //seg001:00000000005D9B3C                 lbzu      r11, 6(r5)    # Load Byte and Zero with Update
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0xE + r6u), info4a, 0, 1);
                    r9u = BitConverter.ToUInt32(info4a, 0);
                    r6u = (0xE + r6u);                                                     //seg001:00000000005D9B40                 lbzu      r9, 0xE(r6)   # Load Byte and Zero with Update
                    r11u = r11u & 0xFF;                                             //seg001:00000000005D9B44                 clrldi    r11, r11, 56  # r11 = r11 & 0xFF
                    r9u = r9u & 0xFF;                                               //seg001:00000000005D9B48                 clrldi    r9, r9, 56    # r9 = r9 & 0xFF
                    r11u = r11u + r7u;                                              //seg001:00000000005D9B4C                 add       r11, r11, r7  # Add
                    r9u = r9u + r7u;                                                //seg001:00000000005D9B50                 add       r9, r9, r7    # Add
                    info4a = new byte[4];
                    Array.Copy(sbox_v100, (long)(0x100 + r11u), info4a, 0, 1);
                    r0u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9B54                 lbz       r0, 0x100(r11) # Load Byte and Zero
                    info4a = new byte[4];
                    Array.Copy(sbox_v100, (long)(0x100 + r9u), info4a, 0, 1);
                    r8u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9B58                 lbz       r8, 0x100(r9) # Load Byte and Zero
                    Array.Copy(BitConverter.GetBytes(r0u), 0, tmp16, (long)(0x0 + r6u), 1);//seg001:00000000005D9B5C                 stb       r0, 0(r6)     # Store Byte
                    r6u = r3u;                                                      //seg001:00000000005D9B60                 mr        r6, r3        # Move Register
                    Array.Copy(BitConverter.GetBytes(r8u), 0, tmp16, (long)(0x0 + r5u), 1);//seg001:00000000005D9B64                 stb       r8, 0(r5)     # Store Byte
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0x2 + r4u), info4a, 0, 1);
                    r9u = BitConverter.ToUInt32(info4a, 0);
                    r4u = (0x2 + r4u);                                                     //seg001:00000000005D9B68                 lbzu      r9, 2(r4)     # Load Byte and Zero with Update
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0xA + r6u), info4a, 0, 1);
                    r11u = BitConverter.ToUInt32(info4a, 0);
                    r6u = (0xA + r6u);                                                     //seg001:00000000005D9B6C                 lbzu      r11, 0xA(r6)  # Load Byte and Zero with Update
                    r9u = r9u & 0xFF;                                               //seg001:00000000005D9B70                 clrldi    r9, r9, 56    # r9 = r9 & 0xFF
                    r11u = r11u & 0xFF;                                             //seg001:00000000005D9B74                 clrldi    r11, r11, 56  # r11 = r11 & 0xFF
                    r9u = r9u + r7u;                                                //seg001:00000000005D9B78                 add       r9, r9, r7    # Add
                    r11u = r11u + r7u;                                              //seg001:00000000005D9B7C                 add       r11, r11, r7  # Add
                    r5u = r3u;                                                      //seg001:00000000005D9B80                 mr        r5, r3        # Move Register
                    info4a = new byte[4];
                    Array.Copy(sbox_v100, (long)(0x100 + r9u), info4a, 0, 1);
                    r0u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9B84                 lbz       r0, 0x100(r9) # Load Byte and Zero
                    info4a = new byte[4];
                    Array.Copy(sbox_v100, (long)(0x100 + r11u), info4a, 0, 1);
                    r8u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9B88                 lbz       r8, 0x100(r11) # Load Byte and Zero
                    Array.Copy(BitConverter.GetBytes(r0u), 0, tmp16, (long)(0x0 + r6u), 1);//seg001:00000000005D9B8C                 stb       r0, 0(r6)     # Store Byte
                    Array.Copy(BitConverter.GetBytes(r8u), 0, tmp16, (long)(0x0 + r4u), 1);//seg001:00000000005D9B90                 stb       r8, 0(r4)     # Store Byte
                    r8u = r3u;                                                      //seg001:00000000005D9B94                 mr        r8, r3        # Move Register
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0x7 + r5u), info4a, 0, 1);
                    r9u = BitConverter.ToUInt32(info4a, 0);
                    r5u = (0x7 + r5u);                                                     //seg001:00000000005D9B98                 lbzu      r9, 7(r5)     # Load Byte and Zero with Update
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0x3 + r8u), info4a, 0, 1);
                    r11u = BitConverter.ToUInt32(info4a, 0);
                    r8u = (0x3 + r8u);                                                     //seg001:00000000005D9B9C                 lbzu      r11, 3(r8)    # Load Byte and Zero with Update
                    r9u = r9u & 0xFF;                                               //seg001:00000000005D9BA0                 clrldi    r9, r9, 56    # r9 = r9 & 0xFF
                    r11u = r11u & 0xFF;                                             //seg001:00000000005D9BA4                 clrldi    r11, r11, 56  # r11 = r11 & 0xFF
                    r9u = r9u + r7u;                                                //seg001:00000000005D9BA8                 add       r9, r9, r7    # Add
                    r11u = r11u + r7u;                                               //seg001:00000000005D9BAC                 add       r11, r11, r7  # Add
                    info4a = new byte[4];
                    Array.Copy(sbox_v100, (long)(0x100 + r9u), info4a, 0, 1);
                    r0u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9BB0                 lbz       r0, 0x100(r9) # Load Byte and Zero
                    info4a = new byte[4];
                    Array.Copy(sbox_v100, (long)(0x100 + r11u), info4a, 0, 1);
                    r6u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9BB4                 lbz       r6, 0x100(r11) # Load Byte and Zero
                    r11u = r3u;                                                     //seg001:00000000005D9BB8                 mr        r11, r3       # Move Register
                    Array.Copy(BitConverter.GetBytes(r0u), 0, tmp16, (long)(0x0 + r8u), 1);//seg001:00000000005D9BBC                 stb       r0, 0(r8)     # Store Byte
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0xB + r11u), info4a, 0, 1);
                    r9u = BitConverter.ToUInt32(info4a, 0);
                    r11u = (0xB + r11u);                                                     //seg001:00000000005D9BC0                 lbzu      r9, 0xB(r11)  # Load Byte and Zero with Update
                    r9u = r9u & 0xFF;                                               //seg001:00000000005D9BC4                 clrldi    r9, r9, 56    # r9 = r9 & 0xFF
                    r9u = r9u + r7u;                                                //seg001:00000000005D9BC8                 add       r9, r9, r7    # Add
                    info4a = new byte[4];
                    Array.Copy(sbox_v100, (long)(0x100 + r9u), info4a, 0, 1);
                    r0u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9BCC                 lbz       r0, 0x100(r9) # Load Byte and Zero
                    Array.Copy(BitConverter.GetBytes(r0u), 0, tmp16, (long)(0x0 + r5u), 1);//seg001:00000000005D9BD0                 stb       r0, 0(r5)     # Store Byte
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0xF + r10u), info4a, 0, 1);
                    r9u = BitConverter.ToUInt32(info4a, 0);
                    r10u = (0xF + r10u);                                                     //seg001:00000000005D9BD4                 lbzu      r9, 0xF(r10)  # Load Byte and Zero with Update
                    r9u = r9u & 0xFF;                                               //seg001:00000000005D9BD8                 clrldi    r9, r9, 56    # r9 = r9 & 0xFF
                    r9u = r9u + r7u;                                                //seg001:00000000005D9BDC                 add       r9, r9, r7    # Add
                    info4a = new byte[4];
                    Array.Copy(sbox_v100, (long)(0x100 + r9u), info4a, 0, 1);
                    r0u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9BE0                 lbz       r0, 0x100(r9) # Load Byte and Zero
                    Array.Copy(BitConverter.GetBytes(r0u), 0, tmp16, (long)(0x0 + r11u), 1);//seg001:00000000005D9BE4                 stb       r0, 0(r11)    # Store Byte
                    Array.Copy(BitConverter.GetBytes(r6u), 0, tmp16, (long)(0x0 + r10u), 1);//seg001:00000000005D9BE8                 stb       r6, 0(r10)    # Store Byte
                    //seg001:00000000005D9BEC                 blr                     # Branch unconditionally

                    bp++;


                    #endregion

                    r10u = r30u;                                            //seg001:00000000005D9F1C                 mr        r10, r30      # Move Register
                    Array.Copy(tmp16, (long)(0x0 + 0), info4a, 0, 4);
                    r0u = SwapByteOrder(BitConverter.ToUInt32(info4a, 0)) >> 32;            //seg001:00000000005D9F20                 lwz       r0, 0xE0+var_70(r1) # Load Word and Zero
                    Array.Copy(keyData, (long)(0x100 + r10u), info4a, 0, 4);
                    r9u = SwapByteOrder(BitConverter.ToUInt32(info4a, 0)) >> 32;
                    r10u = (0x100 + r10u);                                                  //seg001:00000000005D9F24                 lwzu      r9, 0x100(r10) # Load Word and Zero with Update
                    r0u = r0u ^ r9u;                                        //seg001:00000000005D9F28                 xor       r0, r0, r9    # XOR
                    Array.Copy(BitConverter.GetBytes(SwapByteOrder(r0u) >> 32), 0, tmp16, (long)(0x0 + 0x0), 4);//seg001:00000000005D9F2C                 stw       r0, 0xE0+var_70(r1) # Store Word
                    Array.Copy(keyData, (long)(0x4 + r10u), info4a, 0, 4);
                    r9u = SwapByteOrder(BitConverter.ToUInt32(info4a, 0)) >> 32;            //seg001:00000000005D9F30                 lwz       r9, 4(r10)    # Load Word and Zero
                    Array.Copy(tmp16, (long)(0x4 + 0), info4a, 0, 4);
                    r0u = SwapByteOrder(BitConverter.ToUInt32(info4a, 0)) >> 32;            //seg001:00000000005D9F34                 lwz       r0, 0xE0+var_6C(r1) # Load Word and Zero
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0x0 + 1), info4a, 0, 1);
                    r29u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9F38                 lbz       r29, 0xE0+var_70+1(r1) # Load Byte and Zero
                    r0u = r0u ^ r9u;                                                 //seg001:00000000005D9F3C                 xor       r0, r0, r9    # XOR
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0x0 + 2), info4a, 0, 1);
                    r3u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9F40                 lbz       r3, 0xE0+var_70+2(r1) # Load Byte and Zero
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0x0 + 3), info4a, 0, 1);
                    r5u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9F44                 lbz       r5, 0xE0+var_70+3(r1) # Load Byte and Zero
                    Array.Copy(BitConverter.GetBytes(SwapByteOrder(r0u) >> 32), 0, tmp16, (long)(0x4 + 0x0), 4);//seg001:00000000005D9F48                 stw       r0, 0xE0+var_6C(r1) # Store Word
                    Array.Copy(keyData, (long)(0x8 + r10u), info4a, 0, 4);
                    r9u = SwapByteOrder(BitConverter.ToUInt32(info4a, 0)) >> 32;            //seg001:00000000005D9F4C                 lwz       r9, 8(r10)    # Load Word and Zero
                    Array.Copy(tmp16, (long)(0x8 + 0), info4a, 0, 4);
                    r0u = SwapByteOrder(BitConverter.ToUInt32(info4a, 0)) >> 32;            //seg001:00000000005D9F50                 lwz       r0, 0xE0+var_68(r1) # Load Word and Zero
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0x4 + 2), info4a, 0, 1);
                    r8u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9F54                 lbz       r8, 0xE0+var_6C+2(r1) # Load Byte and Zero
                    r0u = r0u ^ r9u;                                                //seg001:00000000005D9F58                 xor       r0, r0, r9    # XOR
                    Array.Copy(tmp16, (long)(0xC + 0), info4a, 0, 4);
                    r9u = SwapByteOrder(BitConverter.ToUInt32(info4a, 0)) >> 32;            //seg001:00000000005D9F5C                 lwz       r9, 0xE0+var_64(r1) # Load Word and Zero
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0x4 + 3), info4a, 0, 1);
                    r7u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9F60                 lbz       r7, 0xE0+var_6C+3(r1) # Load Byte and Zero
                    Array.Copy(BitConverter.GetBytes(SwapByteOrder(r0u) >> 32), 0, tmp16, (long)(0x8 + 0x0), 4);//seg001:00000000005D9F64                 stw       r0, 0xE0+var_68(r1) # Store Word
                    Array.Copy(keyData, (long)(0xC + r10u), info4a, 0, 4);
                    r11u = SwapByteOrder(BitConverter.ToUInt32(info4a, 0)) >> 32;            //seg001:00000000005D9F68                 lwz       r11, 0xC(r10) # Load Word and Zero
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0x0 + 0), info4a, 0, 1);
                    r0u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9F6C                 lbz       r0, 0xE0+var_70(r1) # Load Byte and Zero
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0x4 + 0), info4a, 0, 1);
                    r10u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9F70                 lbz       r10, 0xE0+var_6C(r1) # Load Byte and Zero
                    r9u = r9u ^ r11u;                                               //seg001:00000000005D9F74                 xor       r9, r9, r11   # XOR
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0x8 + 0), info4a, 0, 1);
                    r6u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9F78                 lbz       r6, 0xE0+var_68(r1) # Load Byte and Zero
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0x4 + 1), info4a, 0, 1);
                    r11u = BitConverter.ToUInt32(info4a, 0);                        //seg001:00000000005D9F7C                 lbz       r11, 0xE0+var_6C+1(r1) # Load Byte and Zero
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0x8 + 1), info4a, 0, 1);
                    r4u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9F80                 lbz       r4, 0xE0+var_68+1(r1) # Load Byte and Zero
                    Array.Copy(BitConverter.GetBytes(SwapByteOrder(r9u) >> 32), 0, tmp16, (long)(0xC + 0x0), 4);//seg001:00000000005D9F84                 stw       r9, 0xE0+var_64(r1) # Store Word
                    Array.Copy(BitConverter.GetBytes(r0u), 0, cryptedData, (long)(0x0 + r31u), 1);//seg001:00000000005D9F88                 stb       r0, 0(r31)    # Store Byte
                    Array.Copy(BitConverter.GetBytes(r29u), 0, cryptedData, (long)(0x1 + r31u), 1);//seg001:00000000005D9F8C                 stb       r29, 1(r31)   # Store Byte
                    Array.Copy(BitConverter.GetBytes(r10u), 0, cryptedData, (long)(0x4 + r31u), 1);//seg001:00000000005D9F90                 stb       r10, 4(r31)   # Store Byte
                    Array.Copy(BitConverter.GetBytes(r11u), 0, cryptedData, (long)(0x5 + r31u), 1);//seg001:00000000005D9F94                 stb       r11, 5(r31)   # Store Byte
                    Array.Copy(BitConverter.GetBytes(r8u), 0, cryptedData, (long)(0x6 + r31u), 1);//seg001:00000000005D9F98                 stb       r8, 6(r31)    # Store Byte
                    Array.Copy(BitConverter.GetBytes(r3u), 0, cryptedData, (long)(0x2 + r31u), 1);//seg001:00000000005D9F9C                 stb       r3, 2(r31)    # Store Byte
                    Array.Copy(BitConverter.GetBytes(r5u), 0, cryptedData, (long)(0x3 + r31u), 1);//seg001:00000000005D9FA0                 stb       r5, 3(r31)    # Store Byte
                    Array.Copy(BitConverter.GetBytes(r7u), 0, cryptedData, (long)(0x7 + r31u), 1);//seg001:00000000005D9FA4                 stb       r7, 7(r31)    # Store Byte
                    Array.Copy(BitConverter.GetBytes(r6u), 0, cryptedData, (long)(0x8 + r31u), 1);//seg001:00000000005D9FA8                 stb       r6, 8(r31)    # Store Byte
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0x8 + 2), info4a, 0, 1);
                    r9u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9FAC                 lbz       r9, 0xE0+var_68+2(r1) # Load Byte and Zero
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0x8 + 3), info4a, 0, 1);
                    r7u = BitConverter.ToUInt32(info4a, 0);//seg001:00000000005D9FB0                 lbz       r7, 0xE0+var_68+3(r1) # Load Byte and Zero
                    Array.Copy(BitConverter.GetBytes(r4u), 0, cryptedData, (long)(0x9 + r31u), 1);//seg001:00000000005D9FB4                 stb       r4, 9(r31)    # Store Byte
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0xC + 3), info4a, 0, 1);
                    r0u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9FB8                 lbz       r0, 0xE0+var_64+3(r1) # Load Byte and Zero
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0xC + 0), info4a, 0, 1);
                    r11u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9FBC                 lbz       r11, 0xE0+var_64(r1) # Load Byte and Zero
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0xC + 1), info4a, 0, 1);
                    r10u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9FC0                 lbz       r10, 0xE0+var_64+1(r1) # Load Byte and Zero
                    info4a = new byte[4];
                    Array.Copy(tmp16, (long)(0xC + 2), info4a, 0, 1);
                    r8u = BitConverter.ToUInt32(info4a, 0);                         //seg001:00000000005D9FC4                 lbz       r8, 0xE0+var_64+2(r1) # Load Byte and Zero
                    Array.Copy(BitConverter.GetBytes(r9u), 0, cryptedData, (long)(0xA + r31u), 1);//seg001:00000000005D9FC8                 stb       r9, 0xA(r31)  # Store Byte
                    Array.Copy(BitConverter.GetBytes(r0u), 0, cryptedData, (long)(0xF + r31u), 1);//seg001:00000000005D9FCC                 stb       r0, 0xF(r31)  # Store Byte
                    Array.Copy(BitConverter.GetBytes(r7u), 0, cryptedData, (long)(0xB + r31u), 1);//seg001:00000000005D9FD0                 stb       r7, 0xB(r31)  # Store Byte
                    Array.Copy(BitConverter.GetBytes(r11u), 0, cryptedData, (long)(0xC + r31u), 1);//seg001:00000000005D9FD4                 stb       r11, 0xC(r31) # Store Byte
                    Array.Copy(BitConverter.GetBytes(r10u), 0, cryptedData, (long)(0xD + r31u), 1);//seg001:00000000005D9FD8                 stb       r10, 0xD(r31) # Store Byte
                    Array.Copy(BitConverter.GetBytes(r8u), 0, cryptedData, (long)(0xE + r31u), 1);//seg001:00000000005D9FDC                 stb       r8, 0xE(r31)  # Store Byte
                    //loading pointer for blr                                           //seg001:00000000005D9FE0                 ld        r0, 0xE0+arg_10(r1) # Load Double Word
                    //loading pointer to size of data + alignment to 0x10               //seg001:00000000005D9FE4                 ld        r21, 0xE0+var_58(r1) # Load Double Word
                    //loading unknown pointer 1                                         //seg001:00000000005D9FE8                 ld        r22, 0xE0+var_50(r1) # Load Double Word
                                                                                        //seg001:00000000005D9FEC                 mtspr   LR, r0          # Move to sprg,
                    //loading pointer to pointer to pointer etc.. (possibly pointer to sbox)    //seg001:00000000005D9FF0                 ld        r23, 0xE0+var_48(r1) # Load Double Word
                    //loading pointer to pointer to pointer etc.. (possibly pointer to sbox)    //seg001:00000000005D9FF4                 ld        r24, 0xE0+var_40(r1) # Load Double Word
                    r25u = 0;   //loading pointer to start of cryptedData                       //seg001:00000000005D9FF8                 ld        r25, 0xE0+var_38(r1) # Load Double Word
                    //loading pointer to name of FARC entry being accessed                      //seg001:00000000005D9FFC                 ld        r26, 0xE0+var_30(r1) # Load Double Word
                    //loading size of data + alignment to 0x10;                                 //seg001:00000000005DA000                 ld        r27, 0xE0+var_28(r1) # Load Double Word
                    r28u = 0;   //loading pointer to start of cryptedData                       //seg001:00000000005DA004                 ld        r28, 0xE0+var_20(r1) # Load Double Word
                    r29u = r29uStored; //loading current pointer to dataToCrypt                 //seg001:00000000005DA008                 ld        r29, 0xE0+var_18(r1) # Load Double Word
                    //loading pointer to pointer to pointer etc.. (possibly pointer to ????)    //seg001:00000000005DA00C                 ld        r30, 0xE0+var_10(r1) # Load Double Word
                    //loading size of data + alignment to 0x10;                                 //seg001:00000000005DA010                 ld        r31, 0xE0+var_8(r1) # Load Double Word
                    r1u = r1u + 0xE0;                                                           //seg001:00000000005DA014                 addi      r1, r1, 0xE0  # Add Immediate
                    //seg001:00000000005DA018                 blr                     # lr=00000000000297D4
                }


                bp++;
            }

            return cryptedData;
        }

        

        //String to Byte Array
        public static byte[] StringToByteArray(string hex)
        {
            return Enumerable.Range(0, hex.Length).Where(x => x % 2 == 0).Select(x => Convert.ToByte(hex.Substring(x, 2), 16)).ToArray();
        }

        //Decrypt Button
        private void button3_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            if (ofd.ShowDialog() == DialogResult.Cancel) return;
            string fileToCrypt = ofd.FileName;
            byte[] dataToCrypt = File.ReadAllBytes(fileToCrypt);
            byte[] cryptedData = decrypt(dataToCrypt);
            File.WriteAllBytes(ofd.FileName + "__crypted.bin", cryptedData);
        }
    }
}
