#Youyou Seisakuki mdl

import os, sys
from StructReader import StructReader
from ModelObject import Model3D

class KengekiMusou_mdl(Model3D):
    
    def __init__(self, obj3D=None, outFile=None, inFile=None):
        
        super(KengekiMusou_mdl,self).__init__("MDL")
        self.obj3D = obj3D
        self.inFile = inFile
        self.outFile = outFile
        
    def parse_skeleton(self):
        
        numSkel = self.inFile.read_long()
        self.inFile.seek(8, 1)
        for i in range(numSkel):
            tag = self.inFile.read_string(4)
            self.inFile.seek(124, 1)
            charLen = self.inFile.read_long()
            skelName = self.inFile.read_string(charLen)
            self.inFile.seek(1, 1)
        
    def parse_bones(self):
        
        numBones = self.inFile.read_long()
        self.inFile.seek(8, 1)
        for i in range(numBones):
            tag = self.inFile.read_string(4)
            boneIndex = self.inFile.read_long()
            self.inFile.seek(120, 1)
        charLen = self.inFile.read_long()
        name = self.inFile.read_string(charLen)
        self.inFile.seek(1, 1)
    
    def parse_materials(self):
        
        self.inFile.seek(444, 1) #pad
        charLen = self.inFile.read_long()
        texName = self.inFile.read_string(charLen)
        self.inFile.seek(1, 1)
        charLen = self.inFile.read_long()
        if charLen != 0:
            texName2 = self.inFile.read_string(charLen)
            self.inFile.seek(1, 1)
            charLen = self.inFile.read_long()
            if charLen != 0:
                texName3 = self.inFile.read_string(charLen)
                self.inFile.seek(26, 1)
        else:
            self.inFile.seek(31, 1)
        charLen = self.inFile.read_long()
        matName = self.inFile.read_string(charLen)
        self.inFile.seek(1, 1)
        
        matNum = self.mat_count()
        self.create_material(matNum)
        self.add_material_name(matNum, matName)
        self.add_texture_name(matNum, texName)

    def parse_faces(self, meshName, numFaces, meshNum):
        
        for i in range(numFaces):
            v1, v2, v3 = self.inFile.read_short(3)
            
            #print v1, v2, v3
            self.create_face(meshName, i)
            self.add_face_verts(meshName, i, [v1, v2, v3])
            
            self.add_face_material(meshName, i, meshNum)
        
    def parse_vertices(self, meshName, vertSize, numVerts):
        
        for i in range(numVerts):
            vx, vy, vz = self.inFile.read_float(3)
            if vertSize == 72:
                w1, w2, w3, w4 = self.inFile.read_float(4)
            nx, ny, nz = self.inFile.read_float(3)
            self.inFile.read_float(1)
            tu, tv = self.inFile.read_float(2)
            self.inFile.read_float(5)
            
            vx = float(vx) * -1
            self.create_vertex(meshName, i)
            self.add_coords(meshName, i, [vx, vy, vz])
            self.add_vert_uv(meshName, i, [tu, tv])
        
    def parse_file(self):
        '''Main parser method. Can be replaced'''
        
        fsize = self.inFile.filesize()
        
        
        self.inFile.seek(160, 1)
        while self.inFile.tell() != fsize:
            tag = self.inFile.read_string(4)
            if tag =="wwDD":
                self.inFile.seek(120, 1)
                numMesh, unk3 = self.inFile.read_short(2)
            elif tag == "mnd\x00":
                self.inFile.seek(124, 1)
            elif tag == "msh\x00":
                
                meshNum = self.mesh_count()
                meshName = "obj[%d]" %meshNum
                self.create_object(meshName)
        
                meshType, vertSize, numVerts, numFaces = self.inFile.read_long(4)
                self.inFile.read_long(3) #padding?
                self.parse_vertices(meshName, vertSize, numVerts)
                self.parse_faces(meshName, numFaces, meshNum)
                
                #temp
                if meshType == 0:
                    charLen = self.inFile.read_long()
                    name = self.inFile.read_string(charLen)
                    self.inFile.seek(1, 1)
            elif tag == "ski\x00":
                self.parse_bones()
            elif tag == "mat\x00":
                self.parse_materials()
            elif tag == "skl\x00":
                print "skeleton"
                self.parse_skeleton()
            
def read_file(path):
    '''Read the file'''
    
    openFile = StructReader(open(path, 'rb'))
    obj = KengekiMusou_mdl(inFile=openFile)
    obj.parse_file()
    openFile.close()
    return obj

def write_file(path):
    
    pass

def definitions():
    '''Return the header, extension, and a description of the format'''
    
    return "MgReso", "MDL", "Youyou Kengeki Musou MDL"

if __name__ == '__main__':
    
    file1 = "model.mdl"
    file2 = "karasu.mdl"
    file3 = "aya.mdl"
    file4 = "momiji.mdl"
    file5 = "himawariY.mdl"
    file6 = "st03.mdl"
    obj = read_file(file6)