---------------------
English
---------------------
Step 1. Extract the .cat file you want to edit. [You can choose multiple .cat files]
- Open QuickBMS [You can just otherwise click on the script and have the BMS files open with QuickBMS]
- Find Tamsoft CAT script and click on it.
- Click the .Cat file
- Then click the folder to extract to
- Delete things that aren't .tmd files unless you're into modeling
Step 2. Extract the .tmd files [You can choose multiple .tmd files]
- Open QuickBMS
- Find Tamsoft GXT script and click on it.
- Click the .tmd file
- Then click the folder to extract to
Step 3 Edit the .dds file [with GIMP or Photoshop (install the Intel DDS plugin)]
- Make a back up
- Change what you want to change
- Make sure you save it as DXT1, 5 or 10 keeping it the same as the original, [Look at the type of DXT by looking with Hex Edit the TMD file]
- If your new file doesn't match the same filesize as the old, then your DXT is the wrong number. DDS with Transparent space will be 5 or 10
Step 4 Repack GXT
- Open reimport.bat
- Find Tamsoft GXT script and click on it.
- Click the .tmd file
- Then click your modified .dds file
- If it's not the right filesize you'll get an error.
Step 5 Repack CAT
- Open reimport.bat
- Find Tamsoft CAT script and click on it.
- Click the .cat file
- Then click the .tmd file
Step 6 Replace the .cat file in the  Captain Tsubasa: Rise of New Champions Steam files. Be sure to back up the root file before handling.

Only repeat steps 3-6 when making any changes. Yes you have to do this everytime.