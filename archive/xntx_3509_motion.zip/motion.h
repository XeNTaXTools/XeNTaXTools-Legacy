
#ifndef _MOTION_H
#define _MOTION_H

//+---------------------------------------------------------> 

#include "main.h"

//+---------------------------------------------------------> cAnimBone

struct cAnimBone
{
	BYTE					cId;
	BYTE					cParent;			// -1 means no parents
	BYTE					cChild;				// child id
	char					cUnknown;
	unsigned int			uiChildNum;
	int						*pChild;
	D3DXVECTOR3				vTrans;				// translation vector
};

//+---------------------------------------------------------> cAnimKey

struct cAnimKey
{
	D3DXVECTOR3				vKey;
	unsigned short			usDuration;
};

//+---------------------------------------------------------> cAnimTrack

struct cAnimTrack
{
	unsigned short			usType;
	char					cZero;
	unsigned char			cBoneId;			// or parent ??
	cAnimKey				*pKey;				// originally a 1.0 float
	unsigned int			uiSize;
	unsigned int			uiOffset;			// absolute
	D3DXVECTOR3				vTransform;
	unsigned int			uiFrameNum;			// calculated, originally the w component of the transform ~1.0f
};

//+---------------------------------------------------------> cAnimInfo

struct cAnim
{
	unsigned int			uiOffset;			// absolute
	unsigned int			uiTrackNum;
	unsigned int			uiFrameNum;
	unsigned int			uiInconnu1;			// alternative start keyframe, -1 means no alternate
	D3DXVECTOR4				vTransform;			// w = 0.0f
	D3DXVECTOR4				vZero;				// 0.0, 0.0, 0.0, 1.0
	unsigned short			usFlag[32];

	unsigned int			uiCount2;			// absolute
	unsigned int			uiOffset2;
	unsigned short			usFlag2[30];
	cAnimTrack				*pTrack;
	
	unsigned int			uiCount3;			// absolute
	unsigned int			uiOffset3;
};

//+---------------------------------------------------------> cMotion

class cMotion
{
public:
							cMotion();

	bool					Load(const char *strMotion);
	bool					Export(const char *strMotion, const char *strModel, unsigned int uiMotionId);
	bool					Export(const char *strModel, const char *strPath);
	float					TransferAngle(float fAngle);
	void					Delete();

private:

	unsigned int			m_uiTag;			// 'LMT'
	unsigned short			m_usBoneNum;
	unsigned short			m_usAnimNum;

	unsigned int			*m_pAnimInfoOffset;
	cAnim					*m_pAnim;
};

//+---------------------------------------------------------> 

#endif