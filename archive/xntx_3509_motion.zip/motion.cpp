
#include "motion.h"

//+---------------------------------------------------------> cMotion()

cMotion::cMotion()
{
}

//+---------------------------------------------------------> Delete()

void cMotion::Delete()
{
	// animations
	if(m_pAnim)
	{
		for(unsigned short a = 0; a < m_usAnimNum; a++)
		{
			if(m_pAnim[a].pTrack && m_pAnimInfoOffset[a])
			{
				for(unsigned int b = 0; b < m_pAnim[a].uiTrackNum; b++)
				{
					if(m_pAnim[a].pTrack[b].uiFrameNum && m_pAnim[a].pTrack[b].pKey)
						delete[] m_pAnim[a].pTrack[b].pKey;
				}
				delete[] m_pAnim[a].pTrack;
				m_pAnim[a].pTrack = NULL;
			}
		}
		delete[] m_pAnim;
		m_pAnim = NULL;
	}

	// animation info offset
	if(m_pAnimInfoOffset)
	{
		delete[] m_pAnimInfoOffset;
		m_pAnimInfoOffset = NULL;
	}
}

unsigned int uiRot = 0;
//+---------------------------------------------------------> Load()

bool cMotion::Load(const char *strMotion)
{
	// open the motion file
	FILE *pFile = fopen(strMotion, "rb");
	if(!pFile)
	{
		printf("Can't open motion file [%s] !\n", strMotion);
		return false;
	}

	// read the header and check the signature
	fread(this, 8, 1, pFile);
	if(m_uiTag != 0x00544D4C)
	{
		printf("Invalid LMT file [%s] !\n", strMotion);
		return false;
	}
	printf("bones: %d\nanims: %d\n", m_usBoneNum, m_usAnimNum);

	// read the animations offsets
	m_pAnimInfoOffset = new unsigned int[m_usAnimNum];
	fread(m_pAnimInfoOffset, 4, m_usAnimNum, pFile);

	// go through all the animations and read their info
	m_pAnim = new cAnim[m_usAnimNum];
	for(unsigned short a = 0; a < m_usAnimNum; a++)
	{
		if(m_pAnimInfoOffset[a])
		{
			fseek(pFile, m_pAnimInfoOffset[a], SEEK_SET);
			fread(&m_pAnim[a], sizeof(cAnim), 1, pFile);
		}
	}

	// go through all the animations and read their tracks
	for(unsigned short a = 0; a < m_usAnimNum; a++)
	{
		// if the animation is there then go for it
		if(m_pAnimInfoOffset[a])
		{
			fseek(pFile, m_pAnim[a].uiOffset, SEEK_SET);
			m_pAnim[a].pTrack = new cAnimTrack[m_pAnim[a].uiTrackNum];
			fread(m_pAnim[a].pTrack, sizeof(cAnimTrack), m_pAnim[a].uiTrackNum, pFile);

			// go through all the tracks
			for(unsigned short b = 0; b < m_pAnim[a].uiTrackNum; b++)
			{
				unsigned int uiFrameNum = 0;
				switch(m_pAnim[a].pTrack[b].usType)
				{
				case 0x0306:	// strange x8 key, investigate later
					{
						uiFrameNum = 1;
						m_pAnim[a].pTrack[b].pKey = new cAnimKey;
						m_pAnim[a].pTrack[b].pKey->usDuration = 0;
						m_pAnim[a].pTrack[b].pKey->vKey.x = 0.0f;
						m_pAnim[a].pTrack[b].pKey->vKey.y = 0.0f;
						m_pAnim[a].pTrack[b].pKey->vKey.z = 0.0f;
					}
					break;

				case 0x0402:	// absolute translation
				case 0x0004:
				case 0x0304:	// verigy later, m10_300c_cut37.lmt
				case 0x0202:	// scale
				case 0x0502:	// scale
				case 0x0102:	// translation
					{
						if(m_pAnim[a].pTrack[b].uiSize != 12)
						{
							printf("There is more than one key here at %d!!\n", ftell(pFile));
							return false;
						}
						uiFrameNum = 1;
						D3DXVECTOR3 vKey;
						fseek(pFile, m_pAnim[a].pTrack[b].uiOffset, SEEK_SET);
						fread(&vKey, 12, 1, pFile);
						m_pAnim[a].pTrack[b].uiFrameNum = 1;
						m_pAnim[a].pTrack[b].pKey = new cAnimKey;
						m_pAnim[a].pTrack[b].pKey->usDuration = 0;
						m_pAnim[a].pTrack[b].pKey->vKey = vKey;
					}
					break;

				case 0x0006:	// rotation
					{
						uiRot++;
						uiFrameNum = m_pAnim[a].pTrack[b].uiSize / 8;
						m_pAnim[a].pTrack[b].uiFrameNum = uiFrameNum;
						m_pAnim[a].pTrack[b].pKey = new cAnimKey[uiFrameNum];
						__int64 *pData = new __int64[uiFrameNum];
						fseek(pFile, m_pAnim[a].pTrack[b].uiOffset, SEEK_SET);
						fread(pData, sizeof(__int64), uiFrameNum, pFile);
						for(unsigned int c = 0; c < uiFrameNum; c++)
						{
							__int64 uiX = pData[c] & 0x01FFFF;
							__int64 uiY = (pData[c] >> 17) & 0x01FFFF;
							__int64 uiZ = (pData[c] >> 34) & 0x07FFFF;
							__int64 uiSign = (pData[c] >> 53) & 0x07;
							__int64 uiDuration = (pData[c] >> 56) & 0xFF;
							
							BYTE sign = BYTE(uiSign);
							unsigned int x = unsigned int(uiX);
							unsigned int y = unsigned int(uiY);
							unsigned int z = unsigned int(uiZ);
							
							float x0 = (x * 1.198432e-05f);
							float x1 = (x0 - (3.141592f * 0.5f));
							
							x0 += (powf(x0, 3) * -0.1665219f) + (powf(x0, 5) * 0.008199913f) + (powf(x0, 7) * -0.0001614759f);
							x1 += (powf(x1, 3) * -0.1665219f) + (powf(x1, 5) * 0.008199913f) + (powf(x1, 7) * -0.0001614759f);
							
							float y0 = (y * 1.198432e-05f);
							float y1 = (y0 - (3.141592f * 0.5f));
							
							y0 += (powf(y0, 3) * -0.1665219f) + (powf(y0, 5) * 0.008199913f) + (powf(y0, 7) * -0.0001614759f);
							y1 += (powf(y1, 3) * -0.1665219f) + (powf(y1, 5) * 0.008199913f) + (powf(y1, 7) * -0.0001614759f);
							
							float z0 = (z * 1.907352e-06f);
							float w0 = 1.0f - (z0 * z0);

							z0 = sqrtf(1.0f - (w0 * w0));
							x0 = -(x0 * y1 * z0);
							y0 =  (     y0 * z0);
							z0 =  (x1 * y1 * z0);
							
							if (sign & 1)
								x0 = -x0;
							
							if (sign & 2)
								y0 = -y0;
							
							if (sign & 4)
								z0 = -z0;

							m_pAnim[a].pTrack[b].pKey[c].usDuration = unsigned short(uiDuration);
							m_pAnim[a].pTrack[b].pKey[c].vKey.x = x0;
							m_pAnim[a].pTrack[b].pKey[c].vKey.y = y0;
							m_pAnim[a].pTrack[b].pKey[c].vKey.z = z0;
						}
						delete[] pData;
					}
					break;

				case 0x0109:	// translation
				case 0x0409:
				case 0x0209:
					{
						uiFrameNum = m_pAnim[a].pTrack[b].uiSize / 16;
						m_pAnim[a].pTrack[b].uiFrameNum = m_pAnim[a].pTrack[b].uiSize / 16;
						m_pAnim[a].pTrack[b].pKey = new cAnimKey[uiFrameNum];
						fseek(pFile, m_pAnim[a].pTrack[b].uiOffset, SEEK_SET);
						fread(m_pAnim[a].pTrack[b].pKey, 16, uiFrameNum, pFile);
					}
					break;

				default:
					{
						printf("Unknown key type %d bone%d at [%d][%d]!!!\n", m_pAnim[a].pTrack[b].usType, m_pAnim[a].pTrack[b].cBoneId, ftell(pFile), b);
						return false;
					}
					break;
				}

			}
			//// fix the bone id's
			//for(unsigned b = 0; b < m_pAnim[a].uiTrackNum; b++)
			//{
			//	m_pAnim[a].pTrack[b].cBoneId = pBoneTable[m_pAnim[a].pTrack[b].cBoneId];
			//}
		}
	}

	fclose(pFile);
	return true;
}

//+---------------------------------------------------------> Export()

bool cMotion::Export(const char *strMotion, const char *strModel, unsigned int uiMotionId)
{
	// get the bone table from the model file
	FILE *pFile = fopen(strModel, "rb");
	if(!pFile)
	{
		printf("Can't open model %s !\n", strModel);
		return false;
	}
	unsigned short usBoneNum = 0;
	unsigned char strTable[256];
	unsigned char strOd[256];
	fseek(pFile, 6, SEEK_SET);
	fread(&usBoneNum, 2, 1, pFile);
	fseek(pFile, 176, SEEK_SET);
	for(unsigned short a = 0; a < usBoneNum; a++)
	{
		fread(&strOd[a], 1, 1, pFile);
		fseek(pFile, 23, SEEK_CUR);
	}
	fseek(pFile, 176 + (usBoneNum * 24) + (usBoneNum * 128), SEEK_SET);
	fread(strTable, 256, 1, pFile);
	fclose(pFile);

	// fix the bone id's
	for(unsigned int a = 0; a < m_pAnim[uiMotionId].uiTrackNum; a++)
		m_pAnim[uiMotionId].pTrack[a].cBoneId = strTable[m_pAnim[uiMotionId].pTrack[a].cBoneId];

	// open the output file
	pFile = fopen(strMotion ,"wt");
	fprintf(pFile, "set coordsys parent\n");
	fprintf(pFile, "animate on\n(\n");

	unsigned int uiFrame = 0;
	D3DXMATRIX matScale, matTrans, matRot;
	for(unsigned int a = 0; a < m_pAnim[uiMotionId].uiTrackNum; a++)
	{
		if(m_pAnim[uiMotionId].pTrack[a].cBoneId == 0xFF)
			continue;

		//printf("%d\n", m_pAnim[uiMotionId].pTrack[a].cBoneId);
		fprintf(pFile, "\tnoda = getnodebyname\"bone%d\"\n", m_pAnim[uiMotionId].pTrack[a].cBoneId);

		uiFrame = 0;
		D3DXMatrixIdentity(&matRot);
		D3DXMatrixIdentity(&matScale);
		D3DXMatrixIdentity(&matTrans);
		
		switch(m_pAnim[uiMotionId].pTrack[a].usType)
		{
		case 0x0202:	// scale
		case 0x0502:
			{
				for(unsigned int b = 0; b < m_pAnim[uiMotionId].pTrack[a].uiFrameNum; b++)
				{
					float x0 = m_pAnim[uiMotionId].pTrack[a].pKey[b].vKey.x;
					float y0 = m_pAnim[uiMotionId].pTrack[a].pKey[b].vKey.y;
					float z0 = m_pAnim[uiMotionId].pTrack[a].pKey[b].vKey.z;
					fprintf(pFile, "\tat time %d\n\t(\n", uiFrame);
					fprintf(pFile, "\t\tnoda.scale = [%f,%f,%f]\n", x0, z0, y0);
					fprintf(pFile, "\t)\n");
					uiFrame += m_pAnim[uiMotionId].pTrack[a].pKey[b].usDuration;
				}
			}
			break;
		
		case 0x0402:	// absolute translation
		case 0x0004:
		case 0x0102:	// translation
		case 0x0306:
			{
				float x1 = 0.0f;
				float y1 = 0.0f;
				float z1 = 0.0f;
				for(unsigned int b = 0; b < m_pAnim[uiMotionId].pTrack[a].uiFrameNum; b++)
				{
					float x0 = m_pAnim[uiMotionId].pTrack[a].pKey[b].vKey.x;
					float y0 = m_pAnim[uiMotionId].pTrack[a].pKey[b].vKey.y;
					float z0 = m_pAnim[uiMotionId].pTrack[a].pKey[b].vKey.z;
					fprintf(pFile, "\tat time %d\n\t(\n", uiFrame);
					fprintf(pFile, "\tnoda.pos += [%f,%f,%f]\n", x0, -z0, y0);
					fprintf(pFile, "\t)\n");
					uiFrame += m_pAnim[uiMotionId].pTrack[a].pKey[b].usDuration;
				}
			}
			break;
		
		case 0x0006:	// rotation
			{
				for(unsigned int b = 0; b < m_pAnim[uiMotionId].pTrack[a].uiFrameNum; b++)
				{
					float x0 = (powf(m_pAnim[uiMotionId].pTrack[a].pKey[b].vKey.x, 3) * 120.0f) + (powf(m_pAnim[uiMotionId].pTrack[a].pKey[b].vKey.x, 3) * 60.0f);
					float y0 = (powf(m_pAnim[uiMotionId].pTrack[a].pKey[b].vKey.y, 3) * 120.0f) + (powf(m_pAnim[uiMotionId].pTrack[a].pKey[b].vKey.y, 3) * 60.0f);
					float z0 = (powf(m_pAnim[uiMotionId].pTrack[a].pKey[b].vKey.z, 3) * 120.0f) + (powf(m_pAnim[uiMotionId].pTrack[a].pKey[b].vKey.z, 3) * 60.0f);

					//float fHalfPi = 3.14159265358f / 2.0f;
					//float x0 = (m_pAnim[uiMotionId].pTrack[a].pKey[b].vKey.x / fHalfPi) * 180.0f;
					//float y0 = (m_pAnim[uiMotionId].pTrack[a].pKey[b].vKey.y / fHalfPi) * 180.0f;
					//float z0 = (m_pAnim[uiMotionId].pTrack[a].pKey[b].vKey.z / fHalfPi) * 180.0f;

					fprintf(pFile, "\tat time %d\n\t(\n", uiFrame);
					fprintf(pFile, "\t\tnoda.rotation.x_rotation = %f; noda.rotation.y_rotation = %f; noda.rotation.z_rotation = %f;\n", x0, -z0, y0);
					fprintf(pFile, "\t)\n");
					uiFrame += m_pAnim[uiMotionId].pTrack[a].pKey[b].usDuration;
				}
			}
			break;
		
		case 0x0109:	// translation
		case 0x0409:
		case 0x0209:
			{
				float x1 = 0.0f;
				float y1 = 0.0f;
				float z1 = 0.0f;
				for(unsigned int b = 0; b < m_pAnim[uiMotionId].pTrack[a].uiFrameNum; b++)
				{
					// the current values
					float x0 = m_pAnim[uiMotionId].pTrack[a].pKey[b].vKey.x;
					float y0 = m_pAnim[uiMotionId].pTrack[a].pKey[b].vKey.y;
					float z0 = m_pAnim[uiMotionId].pTrack[a].pKey[b].vKey.z;

					float dx = x0 - x1;
					float dy = y0 - y1;
					float dz = z0 - z1;

					fprintf(pFile, "\tat time %d\n\t(\n", uiFrame);
					fprintf(pFile, "\tnoda.pos += [%f,%f,%f]\n", dx, -dz, dy);
					fprintf(pFile, "\t)\n");
					uiFrame += m_pAnim[uiMotionId].pTrack[a].pKey[b].usDuration;

					x1 = x0;
					y1 = y0;
					z1 = z0;
				}
			}
			break;
		}
	}
	fprintf(pFile, ")\n");
	fprintf(pFile, "animationRange = interval %d %d\n", 0, m_pAnim[uiMotionId].uiFrameNum - 1);
	fclose(pFile);
	return true;
}

//+---------------------------------------------------------> Export()

bool cMotion::Export(const char *strModel, const char *strPath)
{
	// get the bone table from the model file
	FILE *pFile = fopen(strModel, "rb");
	if(!pFile)
	{
		printf("Can't open model %s !\n", strModel);
		return false;
	}
	unsigned short usBoneNum = 0;
	char strTable[256];
	fseek(pFile, 6, SEEK_SET);
	fread(&usBoneNum, 2, 1, pFile);
	fseek(pFile, 144 + (usBoneNum * 24) + (usBoneNum * 128), SEEK_SET);
	fread(strTable, 256, 1, pFile);
	fclose(pFile);

	// set the base name
	char strName[128] = {0};
	for(unsigned int a = unsigned int(strlen(strModel) - 1); a > 0; a--)
	{
		if((strModel[a] == '\\') || (strModel[a] == '/'))
		{
			for(unsigned int b = a; b < unsigned int(strlen(strModel) - 1); b++)
				strName[b - a] = strModel[b + 1];
			strName[strlen(strName) - 4] = '\0';
			break;
		}
	}

	// go through the animations and output them
	for(unsigned short s = 0; s < m_usAnimNum; s++)
	{
		if(m_pAnimInfoOffset[s])
		{
			// fix the bone id's
			for(unsigned int a = 0; a < m_pAnim[s].uiTrackNum; a++)
				m_pAnim[s].pTrack[a].cBoneId = strTable[m_pAnim[s].pTrack[a].cBoneId];

			// open the output file
			char strMotion[128] = {0};
			char strOut[128] = {0};
			for(unsigned int l = 0; l < unsigned int(strlen(strPath)); l++)
			{
				strOut[l] = strPath[l];
				if((strOut[l] == '\\') || (strOut[l] == '/'))
					CreateDirectory(strOut, NULL);
			}
			CreateDirectory(strOut, NULL);
			sprintf(strMotion, "%s/%s_%d.ms", strPath, strName, s);
			pFile = fopen(strMotion ,"wt");
			fprintf(pFile, "set coordsys local\n");
			fprintf(pFile, "animate on\n(\n");

			unsigned int uiFrame = 0;
			D3DXMATRIX matScale, matTrans, matRot;
			for(unsigned int a = 0; a < m_pAnim[s].uiTrackNum; a++)
			{
				//if(m_pAnim[s].pTrack[a].cBoneId == 0xFF)
				//	continue;

				fprintf(pFile, "\tnoda = getnodebyname\"%s_bone%d\"\n", strName, m_pAnim[s].pTrack[a].cBoneId);
				//fprintf(pFile, "\tnoda = getnodebyname\"bone%d\"\n", m_pAnim[s].pTrack[a].cBoneId);

				uiFrame = 0;
				D3DXMatrixIdentity(&matRot);
				D3DXMatrixIdentity(&matScale);
				D3DXMatrixIdentity(&matTrans);
				
				switch(m_pAnim[s].pTrack[a].usType)
				{
				case 0x0202:	// scale
					{
						for(unsigned int b = 0; b < m_pAnim[s].pTrack[a].uiFrameNum; b++)
						{
							float x0 = m_pAnim[s].pTrack[a].pKey[b].vKey.x;
							float y0 = m_pAnim[s].pTrack[a].pKey[b].vKey.y;
							float z0 = m_pAnim[s].pTrack[a].pKey[b].vKey.z;
							fprintf(pFile, "\tat time %d\n\t(\n", uiFrame);
							fprintf(pFile, "\t\tnoda.scale = [%f,%f,%f]\n", x0, z0, y0);
							fprintf(pFile, "\t)\n");
							uiFrame += m_pAnim[s].pTrack[a].pKey[b].usDuration;
						}
					}
					break;
				
				//case 0x0402:	// absolute translation
				//case 0x0004:
				//case 0x0102:	// translation
				//case 0x0306:
				//	{
				//		float x1 = 0.0f;
				//		float y1 = 0.0f;
				//		float z1 = 0.0f;
				//		for(unsigned int b = 0; b < m_pAnim[s].pTrack[a].uiFrameNum; b++)
				//		{
				//			float x0 = m_pAnim[s].pTrack[a].pKey[b].vKey.x;
				//			float y0 = m_pAnim[s].pTrack[a].pKey[b].vKey.y;
				//			float z0 = m_pAnim[s].pTrack[a].pKey[b].vKey.z;
				//			fprintf(pFile, "\tat time %d\n\t(\n", uiFrame);
				//			fprintf(pFile, "\tnoda.pos += [%f,%f,%f]\n", x0, -z0, y0);
				//			fprintf(pFile, "\t)\n");
				//			uiFrame += m_pAnim[s].pTrack[a].pKey[b].usDuration;
				//		}
				//	}
				//	break;
				
				case 0x0006:	// rotation
					{
						for(unsigned int b = 0; b < m_pAnim[s].pTrack[a].uiFrameNum; b++)
						{
							float x0 = TransferAngle(m_pAnim[s].pTrack[a].pKey[b].vKey.x);
							float y0 = TransferAngle(m_pAnim[s].pTrack[a].pKey[b].vKey.y);
							float z0 = TransferAngle(m_pAnim[s].pTrack[a].pKey[b].vKey.z);

							//float fHalfPi = 3.14159265358f / 2.0f;
							//float x0 = (m_pAnim[s].pTrack[a].pKey[b].vKey.x / fHalfPi) * 180.0f;
							//float y0 = (m_pAnim[s].pTrack[a].pKey[b].vKey.y / fHalfPi) * 180.0f;
							//float z0 = (m_pAnim[s].pTrack[a].pKey[b].vKey.z / fHalfPi) * 180.0f;

							fprintf(pFile, "\tat time %d\n\t(\n", uiFrame);
							fprintf(pFile, "\t\tnoda.rotation.x_rotation = %f; noda.rotation.y_rotation = %f; noda.rotation.z_rotation = %f;\n", x0, -z0, y0);
							fprintf(pFile, "\t)\n");
							uiFrame += m_pAnim[s].pTrack[a].pKey[b].usDuration;
						}
					}
					break;
				
				//case 0x0109:	// translation
				////case 0x0409:
				////case 0x0209:
				//	{
				//		float x1 = 0.0f;
				//		float y1 = 0.0f;
				//		float z1 = 0.0f;
				//		for(unsigned int b = 0; b < m_pAnim[s].pTrack[a].uiFrameNum; b++)
				//		{
				//			// the current values
				//			float x0 = m_pAnim[s].pTrack[a].pKey[b].vKey.x;
				//			float y0 = m_pAnim[s].pTrack[a].pKey[b].vKey.y;
				//			float z0 = m_pAnim[s].pTrack[a].pKey[b].vKey.z;

				//			float dx = x0 - x1;
				//			float dy = y0 - y1;
				//			float dz = z0 - z1;

				//			fprintf(pFile, "\tat time %d\n\t(\n", uiFrame);
				//			fprintf(pFile, "\tnoda.pos += [%f,%f,%f]\n", dx, -dz, dy);
				//			fprintf(pFile, "\t)\n");
				//			uiFrame += m_pAnim[s].pTrack[a].pKey[b].usDuration;

				//			x1 = x0;
				//			y1 = y0;
				//			z1 = z0;
				//		}
				//	}
				//	break;
				}
			}
			fprintf(pFile, ")\n");
			//fprintf(pFile, "animationRange = interval %d %d\n", 0, m_pAnim[s].uiFrameNum - 1);
			fprintf(pFile, "animationRange = interval %d %d\n", 0, m_pAnim[s].uiFrameNum);
			fclose(pFile);
		}
	}
	return true;
}

//+---------------------------------------------------------> TransferAngle()

float cMotion::TransferAngle(float fAngle)
{
	//float fOut = 0.0f;
	//float fPos = fabs(fAngle);
	//if((fPos > 0.0f) && (fPos < .50f))
	//	fOut = fAngle * 120.0f;
	//if((fPos > 0.50f) && (fPos < .75f))
	//	fOut = fAngle * 148.0f;
	//if((fPos > .75f) && (fPos < .875f))
	//	fOut = fAngle * 200.0f;
	//if((fPos > .875f))
	//	fOut = fAngle * 464.0f;
	float fFact0 = 25379476.0f / 225225.0f;
	float fFact1 = 48393108416.0f / 354729375.0f;
	float fFact2 = 890109056.0f / 467775.0f;
	float fFact3 = 2013964288.0f / 151875.0f;
	float fFact4 = 99221504.0f / 2205.0f;
	float fFact5 = 915893387264.0f / 11694375.0f;
	float fFact6 = 406411280384.0f / 6081075.0f;
	float fFact7 = 2611340115968.0f / 118243125.0f;

	float fOut = (fFact0 * fAngle) + (fFact1 * powf(fAngle, 3)) - (fFact2 * powf(fAngle, 5)) + (fFact3 * powf(fAngle, 7)) - (fFact4 * powf(fAngle, 9)) + (fFact5 * powf(fAngle, 11)) - (fFact6 * powf(fAngle, 13)) + (fFact7 * powf(fAngle, 15));

	return fOut;
}

//+---------------------------------------------------------> 