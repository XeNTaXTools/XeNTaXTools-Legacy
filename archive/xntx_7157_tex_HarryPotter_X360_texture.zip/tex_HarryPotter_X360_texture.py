from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Harry Potter [X360]", ".texture")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    if bs.readBytes(4) != b'\x08\x00\x00\x08': return 0
    return 1

def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data, NOE_BIGENDIAN)
    bs.seek(0x28)
    imgWidth = bs.readUShort()
    imgHeight = bs.readUShort()
    bs.readByte()
    bs.readByte()
    bs.readByte()
    imgFmt = bs.readUByte()
    print(imgWidth, "x", imgHeight, "-", hex(imgFmt))
    bs.seek(0x5c)
    mips = bs.readUInt()
    datasize = bs.readUInt()
    bs.seek(0x1000)
    data = bs.readBytes(datasize)
    #DXT1
    if imgFmt == 0x6:
        data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 8)
        texFmt = noesis.NOESISTEX_DXT1
    #DXT5
    elif imgFmt == 0x1:
        data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 16)
        texFmt = noesis.NOESISTEX_DXT5
    #DXT5 packed normal map
    elif imgFmt == 0xf:
        data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 16)
        data = rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_ATI2)
        texFmt = noesis.NOESISTEX_RGBA32
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1