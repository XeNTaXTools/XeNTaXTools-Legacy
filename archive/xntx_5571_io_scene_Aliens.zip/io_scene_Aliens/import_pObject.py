# author: Volfin

import bpy
import os
import sys
import mathutils
import math
import platform
import imp
import csv
from bpy_extras.io_utils import unpack_list
from struct import *
import time


def to_blender_matrix(bl_mat):
    mat = mathutils.Matrix()
    for i, col in enumerate(bl_mat):
        for k, val in enumerate(col):
            mat[k][i] = val
    return mat

def import_mesh(context,import_vertcolors,skip_blank,normalize_weight,alt_load):
    global model_name,fmt_table,vert_count,face_count,data_mode1,data_mode2,mesh_scale
    SWAP_YZ_MATRIX = mathutils.Matrix.Rotation(math.radians(90.0), 4, 'X')

    me = bpy.data.meshes.new(model_name)
    me_obj = bpy.data.objects.new(model_name,me)
    me_obj.select = True
    context.scene.objects.link(me_obj)
    context.scene.objects.active = me_obj

    # read in mesh data
    vertex=[]
    normals=[]
    uvs=[]
    UV2=[]
    UV3=[]
    colors=[]
    colors2=[]
    w_count=[]
    m_weights=[]
    g_indices=[]
    faces=[]

    fmt_code=fmt_table[data_mode1][data_mode2]; # get format code
    print("Format is:"+str(fmt_code))

    if vert_count > 0 and fmt_code != 2:  #format 2 isn't loadable
        print("Reading VertData")
        # read in data
        for i in range(0,vert_count):
            tmp=Bh(3)
            vertex.extend([(tmp[0]/-2048.0,tmp[1]/2048.0,tmp[2]/2048.0)]) # -2048 to flip
            #vertex.append(Bh(1)[0]/2048.0) # W
            Bh(1)

            if fmt_code == 3:
                #UVs
                tmp=Bh(2)
                uvs.extend([(tmp[0]/2048.0, 1.0-(tmp[1]/2048.0))]) # UV coordinates Invert Y

                #colors (range from 0.0 to 1.0)
                tmp=BB(4)
                colors.extend([(tmp[0]/255.0,tmp[1]/255.0,tmp[2]/255.0)])
                #colors.append(BB(1)[0]) # A
            elif fmt_code==5:
                #colors (range from 0.0 to 1.0)
                tmp=BB(4)
                colors.extend([(tmp[0]/255.0,tmp[1]/255.0,tmp[2]/255.0)])
                #colors.append(BB(1)[0]) # A
            elif (fmt_code>=6 and fmt_code<=18) or fmt_code==22 or fmt_code==33:
                #UVs
                tmp=Bh(2)
                uvs.extend([(tmp[0]/2048.0, 1.0-(tmp[1]/2048.0))]) # UV coordinates Invert Y
            elif fmt_code==24 or fmt_code==26 or fmt_code==29 or fmt_code==35 or fmt_code==36:
                # bone weights
                w_count.extend([4])
                tmp=BB(4)
                g_indices.extend([(tmp[0],tmp[1],tmp[2],tmp[3])])
                
                tmp=BB(4)
                m_weights.extend([(tmp[0]/255.0,tmp[1]/255.0,tmp[2]/255.0,tmp[3]/255.0)])
            elif fmt_code==28:
                #UVs
                tmp=Bh(2)
                uvs.extend([(tmp[0]/2048.0, 1.0-(tmp[1]/2048.0))]) # UV coordinates Invert Y

                #uvs #2 
                tmp=Bh(2)
                UV2.extend([(tmp[0]/2048.0, 1.0-(tmp[1]/2048.0))]) # UV coordinates Invert Y
            elif fmt_code==34 or fmt_code==37:
                #colors (range from 0.0 to 1.0)
                tmp=BB(4)
                colors.extend([(tmp[0]/255.0,tmp[1]/255.0,tmp[2]/255.0)])
                #colors.append(BB(1)[0]) # A
                
                # bone weights
                w_count.extend([4])
                tmp=BB(4)
                g_indices.extend([(tmp[0],tmp[1],tmp[2],tmp[3])])
                
                tmp=BB(4)
                m_weights.extend([(tmp[0]/255.0,tmp[1]/255.0,tmp[2]/255.0,tmp[3]/255.0)])
            else:
                print("Invalid format code:"+str(fmt_code))

        #######################################################################################
        # alignment
        alignPosition(16)
        print("Reading NormData:"+str(filehandle.tell()))
        for i in range(0,vert_count):
            # now do normals block

            if fmt_code==3:
                # Float normals
                tmp=Bf(3)
                normals.extend([tmp[0],tmp[1],tmp[2]])
            elif fmt_code==4:
                # misc data (unknown discard)
                Bh(2)
                
                #UVs
                tmp=Bh(2)
                uvs.extend([(tmp[0]/2048.0, 1.0-(tmp[1]/2048.0))]) # UV coordinates Invert Y

                # Float normals
                tmp=Bf(3)
                normals.extend([tmp[0],tmp[1],tmp[2]])
            elif fmt_code==5:
                #UVs
                tmp=Bh(2)
                uvs.extend([(tmp[0]/2048.0, 1.0-(tmp[1]/2048.0))]) # UV coordinates Invert Y
                
                # misc data (unknown discard)
                Bh(2)
                Bf(2)

                # Float normals
                tmp=Bf(3)
                normals.extend([tmp[0],tmp[1],tmp[2]])
            elif fmt_code==6:
                # Float normals
                tmp=Bf(3)
                normals.extend([tmp[0],tmp[1],tmp[2]])

                #color (range from 0.0 to 1.0)
                tmp=BB(4)
                colors.extend([(tmp[0]/255.0,tmp[1]/255.0,tmp[2]/255.0)])
                #colors.append(BB(1)[0]) # A

                #float tangents (skip over)
                Bf(3)
            elif fmt_code==8:
                # Float normals
                tmp=Bf(3)
                normals.extend([tmp[0],tmp[1],tmp[2]])

                #float tangents (skip over)
                Bf(3)
            elif fmt_code==9:
                # Float normals
                tmp=Bf(3)
                normals.extend([tmp[0],tmp[1],tmp[2]])

                #color (range from 0.0 to 1.0)
                tmp=BB(4)
                colors.extend([(tmp[0]/255.0,tmp[1]/255.0,tmp[2]/255.0)])
                #colors.append(BB(1)[0]) # A

                #float tangents (skip over)
                Bf(3)
                
                #uvs #2 
                tmp=Bh(2)
                UV2.extend([(tmp[0]/2048.0, 1.0-(tmp[1]/2048.0))]) # UV coordinates Invert Y
            elif fmt_code==10:
                # Float normals
                tmp=Bf(3)
                normals.extend([tmp[0],tmp[1],tmp[2]])

                #color (range from 0.0 to 1.0)
                tmp=BB(4)
                colors.extend([(tmp[0]/255.0,tmp[1]/255.0,tmp[2]/255.0)])
                #colors.append(BB(1)[0]) # A

                #uvs #2 
                tmp=Bh(2)
                UV2.extend([(tmp[0]/2048.0, 1.0-(tmp[1]/2048.0))]) # UV coordinates Invert Y
            elif fmt_code==11:
                # Float normals
                tmp=Bf(3)
                normals.extend([tmp[0],tmp[1],tmp[2]])

                #float tangents (skip over)
                Bf(3)
                
                #uvs #2 
                tmp=Bh(2)
                UV2.extend([(tmp[0]/2048.0, 1.0-(tmp[1]/2048.0))]) # UV coordinates Invert Y
            elif fmt_code==12:
                # Float normals
                tmp=Bf(3)
                normals.extend([tmp[0],tmp[1],tmp[2]])

                #color (range from 0.0 to 1.0)
                tmp=BB(4)
                colors.extend([(tmp[0]/255.0,tmp[1]/255.0,tmp[2]/255.0)])
                #colors.append(BB(1)[0]) # A

                #uvs #2 
                tmp=Bh(2)
                UV2.extend([(tmp[0]/2048.0, 1.0-(tmp[1]/2048.0))]) # UV coordinates Invert Y
                
                #uvs #3
                tmp=Bh(2)
                UV3.extend([(tmp[0]/2048.0, 1.0-(tmp[1]/2048.0))]) # UV coordinates Invert Y
            elif fmt_code==13:
                # Float normals
                tmp=Bf(3)
                normals.extend([tmp[0],tmp[1],tmp[2]])
            elif fmt_code==14:
                # Float normals
                tmp=Bf(3)
                normals.extend([tmp[0],tmp[1],tmp[2]])

                #color (range from 0.0 to 1.0)
                tmp=BB(4)
                colors.extend([(tmp[0]/255.0,tmp[1]/255.0,tmp[2]/255.0)])
                #colors.append(BB(1)[0]) # A
            elif fmt_code==15:
                # Float normals
                tmp=Bf(3)
                normals.extend([tmp[0],tmp[1],tmp[2]])
                
                #float tangents (skip over)
                Bf(3)
                
                # misc data (unknown discard)
                Bf(2)
            elif fmt_code==16:
                # Float normals
                tmp=Bf(3)
                normals.extend([tmp[0],tmp[1],tmp[2]])

                #uvs #2 
                tmp=Bh(2)
                UV2.extend([(tmp[0]/2048.0, 1.0-(tmp[1]/2048.0))]) # UV coordinates Invert Y
            elif fmt_code==17 or fmt_code==25:
                # Float normals
                tmp=Bf(3)
                normals.extend([tmp[0],tmp[1],tmp[2]])

                #color (range from 0.0 to 1.0)
                tmp=BB(4)
                colors.extend([(tmp[0]/255.0,tmp[1]/255.0,tmp[2]/255.0)])
                #colors.append(BB(1)[0]) # A

                #float tangents (skip over)
                Bf(3)

                if fmt_code==25:
                    #uvs
                    tmp=Bh(2)
                    uvs.extend([(tmp[0]/2048.0, 1.0-(tmp[1]/2048.0))]) # UV coordinates Invert Y

                #uvs #2 
                tmp=Bh(2)
                UV2.extend([(tmp[0]/2048.0, 1.0-(tmp[1]/2048.0))]) # UV coordinates Invert Y

                if fmt_code==17:
                    #uvs #3
                    tmp=Bh(2)
                    UV3.extend([(tmp[0]/2048.0, 1.0-(tmp[1]/2048.0))]) # UV coordinates Invert Y
            elif fmt_code==18:
                # Float normals
                tmp=Bf(3)
                normals.extend([tmp[0],tmp[1],tmp[2]])

                #float tangents (skip over)
                Bf(3)

                #uvs #2 
                tmp=Bh(2)
                UV2.extend([(tmp[0]/2048.0, 1.0-(tmp[1]/2048.0))]) # UV coordinates Invert Y
                
                # misc data (unknown discard)
                Bf(2)
            elif fmt_code==19:
                # Float normals
                tmp=Bf(3)
                normals.extend([tmp[0],tmp[1],tmp[2]])

                #uvs
                tmp=Bh(2)
                uvs.extend([(tmp[0]/2048.0, 1.0-(tmp[1]/2048.0))]) # UV coordinates Invert Y

                #uvs #2 
                tmp=Bh(2)
                UV2.extend([(tmp[0]/2048.0, 1.0-(tmp[1]/2048.0))]) # UV coordinates Invert Y
                
                #uvs #3
                tmp=Bh(2)
                UV3.extend([(tmp[0]/2048.0, 1.0-(tmp[1]/2048.0))]) # UV coordinates Invert Y
            elif fmt_code==20:
                # Float normals
                tmp=Bf(3)
                normals.extend([tmp[0],tmp[1],tmp[2]])

                #uvs
                tmp=Bh(2)
                uvs.extend([(tmp[0]/2048.0, 1.0-(tmp[1]/2048.0))]) # UV coordinates Invert Y

                #float tangents (skip over)
                Bf(3)
            elif fmt_code==21:
                # int normals
                tmp=Bh(3)
                normals.extend([tmp[0]/65536.0,tmp[1]/65536.0,tmp[2]/65536.0])

                #unknown short (Skip)
                Bh(1)

                #uvs
                tmp=Bh(2)
                uvs.extend([(tmp[0]/2048.0, 1.0-(tmp[1]/2048.0))]) # UV coordinates Invert Y

                #color (range from 0.0 to 1.0)
                tmp=BB(4)
                colors.extend([(tmp[0]/255.0,tmp[1]/255.0,tmp[2]/255.0)])
                #colors.append(BB(1)[0]) # A

                #float tangents (skip over)
                Bf(3)
            elif fmt_code==22:
                # Float normals
                tmp=Bf(3)
                normals.extend([tmp[0],tmp[1],tmp[2]])

                #uvs #2 
                tmp=Bh(2)
                UV2.extend([(tmp[0]/2048.0, 1.0-(tmp[1]/2048.0))]) # UV coordinates Invert Y
                
                #uvs #3
                tmp=Bh(2)
                UV3.extend([(tmp[0]/2048.0, 1.0-(tmp[1]/2048.0))]) # UV coordinates Invert Y
            elif fmt_code==23:
                # Float normals
                tmp=Bf(3)
                normals.extend([tmp[0],tmp[1],tmp[2]])

                #uvs
                tmp=Bh(2)
                uvs.extend([(tmp[0]/2048.0, 1.0-(tmp[1]/2048.0))]) # UV coordinates Invert Y

                #color (range from 0.0 to 1.0)
                tmp=BB(4)
                colors.extend([(tmp[0]/255.0,tmp[1]/255.0,tmp[2]/255.0)])
                #colors.append(BB(1)[0]) # A

                #uvs #2 
                tmp=Bh(2)
                UV2.extend([(tmp[0]/2048.0, 1.0-(tmp[1]/2048.0))]) # UV coordinates Invert Y
            elif fmt_code==24 or fmt_code==26:
                # int normals
                tmp=Bh(3)
                normals.extend([tmp[0]/65536.0,tmp[1]/65536.0,tmp[2]/65536.0])

                # Int tangents (skip over)
                Bh(3)
                
                #uvs
                tmp=Bh(2)
                uvs.extend([(tmp[0]/2048.0, 1.0-(tmp[1]/2048.0))]) # UV coordinates Invert Y

                if not alt_load:
                    #color (range from 0.0 to 1.0)
                    tmp=BB(4)
                    colors.extend([(tmp[0]/255.0,tmp[1]/255.0,tmp[2]/255.0)])				
                    #colors.append(BB(1)[0]) # A
             
            elif fmt_code==27:
                # Float normals
                tmp=Bf(3)
                normals.extend([tmp[0],tmp[1],tmp[2]])

                #uvs
                tmp=Bh(2)
                uvs.extend([(tmp[0]/2048.0, 1.0-(tmp[1]/2048.0))]) # UV coordinates Invert Y

                #uvs #2 
                tmp=Bh(2)
                UV2.extend([(tmp[0]/2048.0, 1.0-(tmp[1]/2048.0))]) # UV coordinates Invert Y
                
                #float tangents (skip over)
                Bf(3)
            elif fmt_code==28:
                # Float normals
                tmp=Bf(3)
                normals.extend([tmp[0],tmp[1],tmp[2]])

                #float tangents (skip over)
                Bf(3)

                #color (range from 0.0 to 1.0)
                tmp=BB(4)
                colors.extend([(tmp[0]/255.0,tmp[1]/255.0,tmp[2]/255.0)])
                #colors.append(BB(1)[0]) # A

                #uvs #3
                tmp=Bh(2)
                UV3.extend([(tmp[0]/2048.0, 1.0-(tmp[1]/2048.0))]) # UV coordinates Invert Y
            elif fmt_code==29 or fmt_code==34 or fmt_code==35:
                # int normals
                tmp=Bh(3)
                normals.extend([tmp[0]/65536.0,tmp[1]/65536.0,tmp[2]/65536.0])

                # Int tangents (skip over)
                Bh(3)
                
                #uvs
                tmp=Bh(2)
                uvs.extend([(tmp[0]/2048.0, 1.0-(tmp[1]/2048.0))]) # UV coordinates Invert Y
                    
            elif fmt_code==30:
                #uvs
                tmp=Bh(2)
                uvs.extend([(tmp[0]/2048.0, 1.0-(tmp[1]/2048.0))]) # UV coordinates Invert Y
                
                # Float normals
                tmp=Bf(3)
                normals.extend([tmp[0],tmp[1],tmp[2]])
                
                #float tangents (skip over)
                Bf(3)
            elif fmt_code==31:
                # Float normals
                tmp=Bf(3)
                normals.extend([tmp[0],tmp[1],tmp[2]])

                #uvs
                tmp=Bh(2)
                uvs.extend([(tmp[0]/2048.0, 1.0-(tmp[1]/2048.0))]) # UV coordinates Invert Y

                #color (range from 0.0 to 1.0)
                tmp=BB(4)
                colors.extend([(tmp[0]/255.0,tmp[1]/255.0,tmp[2]/255.0)])
                #colors.append(BB(1)[0]) # A

                #uvs #2 
                tmp=Bh(2)
                UV2.extend([(tmp[0]/2048.0, 1.0-(tmp[1]/2048.0))]) # UV coordinates Invert Y

                #float tangents (skip over)
                Bf(3)
            elif fmt_code==32:
                # Float normals
                tmp=Bf(3)
                normals.extend([tmp[0],tmp[1],tmp[2]])

                #color (range from 0.0 to 1.0)
                tmp=BB(4)
                colors.extend([(tmp[0]/255.0,tmp[1]/255.0,tmp[2]/255.0)])
                #colors.append(BB(1)[0]) # A

                #uvs
                tmp=Bh(2)
                uvs.extend([(tmp[0]/2048.0, 1.0-(tmp[1]/2048.0))]) # UV coordinates Invert Y
            elif fmt_code==33:
                # Float normals
                tmp=Bf(3)
                normals.extend([tmp[0],tmp[1],tmp[2]])

                #color (range from 0.0 to 1.0)
                tmp=BB(4)
                colors.extend([(tmp[0]/255.0,tmp[1]/255.0,tmp[2]/255.0)])
                #colors.append(BB(1)[0]) # A

                #float tangents (skip over)
                Bf(3)

                #Bytes unknown (skip over)
                BB(4)
            elif fmt_code==36: # Eyes only (if not eye, then like 35, no float table)
                # int normals
                tmp=Bh(3)
                normals.extend([tmp[0]/65536.0,tmp[1]/65536.0,tmp[2]/65536.0])

                # Int tangents (skip over)
                Bh(3)
                
                #uvs
                tmp=Bh(2)
                uvs.extend([(tmp[0]/2048.0, 1.0-(tmp[1]/2048.0))]) # UV coordinates Invert Y

                if ((vert_count==330 and face_count==1800) or (vert_count==118 and face_count==540)): # is an eye
                    #float unknown (skip over)
                    Bf(9)
            elif fmt_code==37: # secondary color set
                # int normals
                tmp=Bh(3)
                normals.extend([tmp[0]/65536.0,tmp[1]/65536.0,tmp[2]/65536.0])

                # Int tangents (skip over)
                Bh(3)

                #uvs
                tmp=Bh(2)
                uvs.extend([(tmp[0]/2048.0, 1.0-(tmp[1]/2048.0))]) # UV coordinates Invert Y

                #color2 (range from 0.0 to 1.0)
                tmp=BB(4)
                colors2.extend([(tmp[0]/255.0,tmp[1]/255.0,tmp[2]/255.0)])
                #colors2.append(BB(1)[0]) # A
            else:
                print("Invalid format code:"+str(fmt_code))

        # third table
        if (fmt_code==26 or fmt_code==29 or fmt_code==34 or (fmt_code==36 and (vert_count==330 and face_count==1800) or (vert_count==118 and face_count==540)) or fmt_code==37):
            skip_blank= not skip_blank


        #alignment
        alignPosition(16)

        #print("vertex array length:"+str(len(vertex)))
        #print("normal array length:"+str(len(normals)))
        #print("weights array length:"+str(len(m_weights)))
        #print("index array length:"+str(len(g_indices)))
        #print("UV1 array length:"+str(len(uvs)))
        #print("UV2 array length:"+str(len(UV2)))
        #print("UV3 array length:"+str(len(UV3)))
        #print("Colors array length:"+str(len(colors)))
        #print("Skip_blank is:"+str(skip_blank))
              
        if (skip_blank):
            print("Skipping BlankData:"+str(filehandle.tell()))
            # some formats have a blank table to skip
            for i in range(0,vert_count):
                Bf(1)

        #alignment
        alignPosition(16)
        print("Reading FaceData:"+str(filehandle.tell()))
        face_count=int(face_count/3)
        for i in range(0,face_count): # divide by 3 because we read in 3 entries at a time
            #read in face data
            tmp=Bh(3)
            faces.extend([(tmp[2],tmp[1],tmp[0])])

 #       print("faces array length:"+str(len(faces)))
 #       print("# of faces found:"+str(face_count))

    try:
        me.from_pydata(vertex,[],faces)
        me.vertices.foreach_set("normal",normals) # add normals
    except:
        pass


    ###############################################
    if face_count > 0: # skip all this if no mesh

    ###############################################
    # Do UVs
    ###############################################
        if len(uvs) != 0:
            me.uv_textures.new(name='UV_0')
            uv_data = me.uv_layers[0].data
            for i in range(len(uv_data)):
                uv_data[i].uv = uvs[me.loops[i].vertex_index]
        if len(UV2) != 0:
            me.uv_textures.new(name='UV_1')
            uv_data = me.uv_layers[1].data
            for i in range(len(uv_data)):
                uv_data[i].uv = UV2[me.loops[i].vertex_index]
        if len(UV3) != 0:
            me.uv_textures.new(name='UV_2')
            uv_data = me.uv_layers[2].data
            for i in range(len(uv_data)):
                uv_data[i].uv = UV3[me.loops[i].vertex_index]

    ###############################################
    # Do Vertex Color
    ###############################################

        if len(colors) != 0 and import_vertcolors:
            me.vertex_colors.new(name='Color_Data')
            color_data = me.vertex_colors[0].data
            for i in range(len(color_data)):
                color_data[i].color = colors[me.loops[i].vertex_index]
        if len(colors2) != 0 and import_vertcolors:
            me.vertex_colors.new(name='Color_Data2')
            color_data = me.vertex_colors2[0].data
            for i in range(len(color_data)):
                color_data[i].color = colors2[me.loops[i].vertex_index]


    ###############################################
    # Finalize
    ###############################################

        # finalize mesh
        me.update(calc_edges=True)

        #scale
        scale_matrix = mathutils.Matrix.Scale(1.0*mesh_scale, 4)

        #global_trans = to_blender_matrix(mesh.global_transform())
        me_obj.matrix_basis = SWAP_YZ_MATRIX * scale_matrix#* global_trans

        # apply transforms (rotation)
        bpy.ops.object.transform_apply(location=False,rotation=True,scale=True)

    ###############################################    
    # calculate normalized weight
    ###############################################

        normalized_weights = {}

        for n,weights in enumerate(m_weights):
            normalized_weights[n]=0.0
            for weight in weights:
                if normalize_weight:
                    normalized_weights[n] = normalized_weights[n] + weight # total of all weights on vertice
                else:
                    normalized_weights[n] = 0.0
    ##############################################
    # create bone group
    ##############################################

        for n, indices in enumerate(g_indices):
            for p,index in enumerate(indices):                    
                # name is index
                bone_name = str(index)

                # use existing group or new
                group = None
                if bone_name in me_obj.vertex_groups.keys():
                    group = me_obj.vertex_groups[bone_name]
                if group == None:
                    group = me_obj.vertex_groups.new(bone_name)
                
                # do weight                    
                weight = m_weights[n][p]
                if weight == 0: # no weight = no influence, so not acutally used
                    continue;

                if normalized_weights[n] > 0.0:
                    group.add([n], weight/normalized_weights[n], 'ADD')
                else:
                    group.add([n], weight, 'ADD')

    return 0 # all fine

##################################################################

def alignPosition(alignment):
	alignment = alignment - 1
	filehandle.seek(((filehandle.tell() + alignment) & ~alignment), 0) # SEEK_SET

def file_str(long): 
   s=''
   for j in range(0,long): 
       lit =  unpack('c',filehandle.read(1))[0]
       #print("ord of "+str(lit)+" is "+str(ord(lit)))
       if ord(lit)!= 0:
           s+=lit.decode("utf-8")
       else:
           break;
   return s

def BB(n): # Unsigned Char Default is < (little Endian)  > = Big-Endian
    array = [] 
    for id in range(n): 
        array.append(unpack('B', filehandle.read(1))[0])
    return array
def Bb(n): # Signed Char
    array = [] 
    for id in range(n): 
        array.append(unpack('b', filehandle.read(1))[0])
    return array
def BH(n): # Unsigned Short
    array = [] 
    for id in range(n): 
        array.append(unpack('H', filehandle.read(2))[0])
    return array
def Bh(n): # Signed Short
    array = [] 
    for id in range(n): 
        array.append(unpack('h', filehandle.read(2))[0])
    return array
def Bf(n): # Float
	array = [] 
	for id in range(n):
		nz=filehandle.read(4)
		#print("NZ:"+str(nz))
		array.append(unpack('f',nz )[0])
	return array
def Bi(n): # Signed Long Int
    array = [] 
    for id in range(n): 
        array.append(unpack('i', filehandle.read(4))[0])
    return array
def BI(n): # Unsigned Long Int
    array = [] 
    for id in range(n): 
        array.append(unpack('I', filehandle.read(4))[0])
    return array
def Bd(n): # Double
    array = [] 
    for id in range(n): 
        array.append(unpack('d', filehandle.read(8))[0])
    return array

def views():
    """ Returns the set of 3D views.
    """
    rtn = []
    for a in bpy.data.screens["Default"].areas:
        if a.type == 'VIEW_3D':
            rtn.append(a)
    return rtn

def import_pObject(file, context, import_vertcolors,normalize_weight,skip_blank,alt_load):

    global filehandle,fmt_table,model_name,vert_count,face_count,data_mode1,data_mode2,mesh_scale
    report = None

    time1 = time.time()
    print("start")

    workingpath=os.path.dirname(os.path.realpath(__file__))

    # load in format table
    ReadData = csv.reader(open(workingpath+'\\Format_Cfg.dat','r'), delimiter=',')

    #adjust clipping mode
    view=views()
    print(view[0].spaces[0].type)  # should be VIEW_3D
    view[0].spaces[0].clip_end=10000

    row = 0 # we don't enumerate rows so we can skip comments and blank lines transparently
    fmt_table=[[]]
    #init matrix
    fmt_table = [[0 for i in range(58)] for i in range(58)]
    
    for line in ReadData:
        line_str = ''.join(line).strip() # remove whitespace
        #print("'"+line_str+"':"+str(row))
        #print("first char:"+line[0][0])
        if (line[0][0] == "#" or line_str == ""):
            #print("Continuing")
            continue

        for col,val in enumerate(line):
            #print("Col:"+str(col)+" Row:"+str(row)+"val:"+str(val)+"'")
            if val != "":
                fmt_table[col][row]=int(val)
            
        row=row+1

    root, ext = os.path.splitext(file)    
    model_name=root.split("\\")[-1]
    print(model_name)

    ##################################
    try:
        filehandle = open(file, "rb")
    except:
        report="Error loading '"+model_name+".pobject'\n"
        return report

    #get key data about the mesh
    filehandle.seek(0x50)
    data_mode1=BH(1)[0]
    data_mode2=BH(1)[0]

    filehandle.seek(0x56)
    mesh_scale=BH(1)[0]

    filehandle.seek(0x5A)
    vert_count=BH(1)[0]
    face_count=BH(1)[0]

    #skip to model start
    filehandle.seek(0x60)
    ####################################

    print("data mode1:"+str(data_mode1))
    print("data mode2:"+str(data_mode2))

    print("verts:"+str(vert_count))
    print("faces:"+str(face_count))

    # do mesh and materials
    result=import_mesh(context,import_vertcolors,skip_blank,normalize_weight,alt_load)

    if result is None and do_mesh:
        report = "Mesh Output Failed."
    elif result == 1 and do_mesh:
        report = "Vertice counts didn't match, aborting!"

    # set to smooth shaded	
    bpy.ops.object.shade_smooth()
    filehandle.close()
    print("time is ", time.time() - time1)
    return report
