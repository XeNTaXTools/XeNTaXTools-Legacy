# author: Volfin
# 1.00 - Initial Release
# 1.01 - Changed format 46/45 from type 24 to type 26
#      - Fixed secondary Eyeball type loading for type 36
# 1.02 - Models were flipped on the X axis. Fixed.
# 1.03 - Added Alt Loading Mode 2 toggle for missing faces
# 1.04 - validated to Blender version 2.70; added check for Object mode

bl_info = {
    "name": "Alien:Isolation pObject Importer",
    "author": "Volfin",
    "version": (1, 0, 4),
    "blender": (2, 7, 0),
    "location": "File > Import > pObject (Alien:Isolation Model)",
    "description": "Import pObject, io: mesh",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
    "category": "Import-Export"}
    
if "bpy" in locals():
    import imp
    if "import_pObject" in locals():
        imp.reload(import_pObject)
    if "export_pObject" in locals():
        imp.reload(export_pObject)

import bpy

from bpy.props import (StringProperty,
                       BoolProperty,
                       FloatProperty,
                       EnumProperty,
                       )

from bpy_extras.io_utils import (ImportHelper,path_reference_mode)

  
class pObjectImportOperator(bpy.types.Operator, ImportHelper):
    bl_idname = "import_scene.pobject"
    bl_label = "pObject Importer(.pObject)"
    
    filename_ext = ".pobject"

    import_vertcolors = BoolProperty(\
        name="Import Vertex Colors",\
        description="Import Vertex Colors (if any)",\
        default=True,\
        )

    normalize_weight = BoolProperty(\
        name="Normalize Weights",\
        description="Normalize the bone weights (if any)",\
        default=False,\
        )
    
    alt_load = BoolProperty(\
        name="Alt Load",\
        description="Try alternate loading mode (only use if normal fails to load properly)",\
        default=False,\
        )
    skip_blank = BoolProperty(\
        name="Alt Load2",\
        description="Try alternate loading mode2 (only use if Missing faces)",\
        default=False,\
        )


    filter_glob = StringProperty(default="*.pObject") # , options={'HIDDEN'}
    filepath = bpy.props.StringProperty(subtype="FILE_PATH")        
    path_mode = path_reference_mode

    def execute(self, context):
        import os, sys
        print("Import Execute called")
        cmd_folder = os.path.dirname(os.path.abspath(__file__))
        if cmd_folder not in sys.path:
            sys.path.insert(0, cmd_folder)

        import import_pObject
        result=import_pObject.import_pObject(self.filepath, bpy.context,self.import_vertcolors,self.normalize_weight,self.skip_blank,self.alt_load)

        # force back off
        self.skip_blank=False
        self.alt_load=False
        
        if result is not None:
            self.report({'ERROR'},result)

        return {'FINISHED'}

    def invoke(self, context, event):

        print("Import Invoke called")
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def draw(self, context):
        layout = self.layout
        row = layout.row(align=True)
        row.prop(self, "import_vertcolors")
        row = layout.row(align=True)
        row.prop(self, "normalize_weight")
        row = layout.row(align=True)
        row.prop(self, "alt_load")
        row = layout.row(align=True)
        row.prop(self, "skip_blank")

#
# Registration
#
def menu_func_import(self, context):
    self.layout.operator(pObjectImportOperator.bl_idname, text="pObject(Alien:Isolation Model)(.pObject)",icon='PLUGIN')
   
def register():
    bpy.utils.register_module(__name__)
    bpy.types.INFO_MT_file_import.append(menu_func_import)
    
def unregister():
    bpy.utils.unregister_module(__name__)
    bpy.types.INFO_MT_file_import.remove(menu_func_import)
    
if __name__ == "__main__":
    register()