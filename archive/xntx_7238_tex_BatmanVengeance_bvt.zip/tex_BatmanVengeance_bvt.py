from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Batman Vengeance", ".bvt")
    noesis.setHandlerTypeCheck(handle, noeCheckGeneric)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    return 1

def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    imgWidth = 256 
    imgHeight = 256
    bs.seek(0x0)     #data start
    data = bs.readBytes(0x10000)
    bs.seek(0x10004)      #palette start
    palette = bs.readBytes(0x200)
    data = rapi.imageDecodeRawPal(data, palette, imgWidth, imgHeight, 8, "r5 g5 b5 a1", noesis.DECODEFLAG_PS2SHIFT)
    data = rapi.imageFlipRGBA32(data, imgWidth, imgHeight, 0, 1)
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, noesis.NOESISTEX_RGBA32))
    return 1


