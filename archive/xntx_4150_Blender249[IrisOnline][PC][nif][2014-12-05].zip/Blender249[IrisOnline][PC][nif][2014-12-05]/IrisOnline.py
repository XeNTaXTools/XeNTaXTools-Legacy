import newGameLib
reload(newGameLib)
from newGameLib import *
import Blender


def nifParser(filename,g):	
	nif=Nif()
	nif.input=g
	nif.debug=False
	nif.explore()
	if len(nif.meshList)>0:
		nif.skeleton.draw()
		for mesh in nif.meshList:
			mesh.BINDSKELETON=nif.skeleton.name
			mesh.draw()
		
								
		
		
			
def Parser():
	filename=input.filename
	ext=filename.split('.')[-1].lower()
		
	
	if ext=='nif':
		file=open(filename,'rb')
		g=BinaryReader(file)
		g.logOpen()
		nifParser(filename,g)
		g.logClose()
		file.close()
	
	if ext=='kf':
		file=open(filename,'rb')
		g=BinaryReader(file)
		g.logOpen()
		nifParser(filename,g)
		g.logClose()
		file.close()
			
			
 
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
	
Blender.Window.FileSelector(openFile,'import','nif - Gamebryo file') 
	