

def NiFloatData(self): 
	g=self.input
	count=g.i(1)[0]
	type=g.i(1)[0]
	if type==5:
		for i in range(count):
			g.f(2)