


import NiSourceTexture
reload(NiSourceTexture)
from NiSourceTexture import *

class Mat:
	def __init__(self):
		self.diffuse=None
		self.normal=None
		self.specular=None
		self.imageList=[]


def NiTexturingProperty(self,levelID):	
	texList=[None,None,None]

	if self.versionAsNumbers==(4,0,0,20):
		#print 'NiTexturingProperty'
		g=self.input
		levelID+=4
		id=g.i(1)[0]
		if id!=-1:
			if self.versionAsNumbers in self.nifFormatListOld:
				name=g.word(id)
			if self.versionAsNumbers in self.nifFormatListNew:
				name=self.stringList[id]
		else:
			name=None
		#print name
		for n in range(g.i(1)[0]):g.i(1)
		g.i(1)[0]
		if self.versionAsNumbers in self.nifFormatListOld:
			g.i(1)[0]
		if self.versionAsNumbers in self.nifFormatListNew:
			g.H(1)[0]
		numTexture = g.i(1)[0]
			
			
		#mat=Mat()
		#mesh.matList.append(mat)
		#back = g.tell()
		#g.seek(offset)
		for n in range(numTexture):#n=0 - base texture
			has=g.B(1)[0]
			#print n,has
			if has == 1:#has?
				nodeID = g.i(1)[0] 
				#print nodeID
				nodeType = self.nodeTypeList[self.nodeIDList[nodeID]]
				if self.debug==True:
					print '-'*levelID,nodeID,nodeType
				if nodeType == 'NiSourceTexture':
					if self.PARSINGFLAG==False:
						offset = self.getNodeOffset(nodeID)
						t=g.tell()
						g.seek(offset)
						if n==0:
							texType='diffuse'			  
							texPath=NiSourceTexture(self,levelID)
							texList[0]=texPath
						if n==3:
							texType='specular'			
							texPath=NiSourceTexture(self,levelID)
							texList[2]=texPath
						if n==6:
							texType='normal'			
							texPath=NiSourceTexture(self,levelID)
							texList[1]=texPath
						g.seek(t)
				if self.versionAsNumbers in self.nifFormatListOld:
					g.i(3)
					if g.B(1)[0]==1:g.f(5),g.i(1),g.f(2)
				if self.versionAsNumbers in self.nifFormatListNew:
					flag=g.H(1)[0] 
					#print 'flag:',flag
					if self.versionAsNumbers==(0,0,6,20):
						g.H(1)[0]
						
					flag=g.B(1)[0]
					if flag==1:
						g.f(6)
						g.i(1)
						g.f(2)
						
		numShaderTexture = g.i(1)[0]#texture count
		#print 'numShaderTexture:',numShaderTexture
		for n in range(numShaderTexture):
			if g.B(1)[0] == 1:
				g.i(1)[0] 
				g.i(1)[0] 
				g.i(1)[0] 
				g.i(1)[0] 
				#H(1)[0]
				#h(1)[0] 
				g.B(1)[0]  
			g.i(1)[0]
		#g.seek(back)			
				
	elif self.versionAsNumbers==(0,0,2,10):
	
		#print 'NiTexturingProperty'
		g=self.input
		levelID+=4
		id=g.i(1)[0]
		if id!=-1:
			if self.versionAsNumbers in self.nifFormatListOld:
				name=g.word(id)
			if self.versionAsNumbers in self.nifFormatListNew:
				name=self.stringList[id]
		else:
			name=None
		#print name
		for n in range(g.i(1)[0]):g.i(1)
		g.i(1)[0]
		if self.versionAsNumbers in self.nifFormatListOld:
			g.i(1)[0]
		if self.versionAsNumbers in self.nifFormatListNew:
			g.H(1)[0]
		numTexture = g.i(1)[0]
			
			
		#mat=Mat()
		#mesh.matList.append(mat)
		#back = g.tell()
		#g.seek(offset)
		for n in range(numTexture):#n=0 - base texture
			has=g.B(1)[0]
			#print n,has
			if has == 1:#has?
				nodeID = g.i(1)[0] 
				#print nodeID
				nodeType = self.nodeTypeList[self.nodeIDList[nodeID]]
				if self.debug==True:
					print '-'*levelID,nodeID,nodeType,'='*10
				if nodeType == 'NiSourceTexture':
					pass
					"""offset = self.getNodeOffset(nodeID)
					t=g.tell()
					g.seek(offset)
					if n==0:
						texType='diffuse'			  
						texPath=NiSourceTexture(self,levelID)
						texList[0]=texPath
					if n==3:
						texType='specular'			
						texPath=NiSourceTexture(self,levelID)
						texList[2]=texPath
					if n==6:
						texType='normal'			
						texPath=NiSourceTexture(self,levelID)
						texList[1]=texPath
					g.seek(t)"""
				if self.versionAsNumbers in self.nifFormatListOld:
					g.i(3)
					g.h(2)
					if g.B(1)[0]==1:g.f(5),g.i(1),g.f(2)
				if self.versionAsNumbers in self.nifFormatListNew:
					flag=g.H(1)[0] 
					#print 'flag:',flag
					if self.versionAsNumbers==(0,0,6,20):
						g.H(1)[0]
						
					flag=g.B(1)[0]
					if flag==1:
						g.f(6)
						g.i(1)
						g.f(2)
						
		numShaderTexture = g.i(1)[0]#texture count
		print 'numShaderTexture:',numShaderTexture
		for n in range(numShaderTexture):
			if g.B(1)[0] == 1:
				g.i(1)[0] 
				g.i(1)[0] 
				g.i(1)[0] 
				g.i(1)[0] 
				g.H(1)[0]
				g.h(1)[0] 
				g.B(1)[0]  
			g.i(1)[0]
		#g.seek(back)	
		g.debug=False	
				
	elif self.versionAsNumbers==(9,0,3,20):
		#print 'NiTexturingProperty'
		g=self.input
		levelID+=4
		id=g.i(1)[0]
		if id!=-1:
			if self.versionAsNumbers in self.nifFormatListOld:
				name=g.word(id)
			if self.versionAsNumbers in self.nifFormatListNew:
				name=self.stringList[id]
		else:
			name=None
		#print name
		for n in range(g.i(1)[0]):g.i(1)
		g.i(1)[0]
		if self.versionAsNumbers in self.nifFormatListOld:
			g.i(1)[0]
		if self.versionAsNumbers in self.nifFormatListNew:
			g.H(1)[0]
		numTexture = g.i(1)[0]
			
			
		#mat=Mat()
		#mesh.matList.append(mat)
		#back = g.tell()
		#g.seek(offset)
		for n in range(numTexture):#n=0 - base texture
			has=g.B(1)[0]
			#print n,has
			if has == 1:#has?
				nodeID = g.i(1)[0] 
				#print nodeID
				nodeType = self.nodeTypeList[self.nodeIDList[nodeID]]
				if self.debug==True:
					print '-'*levelID,nodeID,nodeType,'='*10
				if nodeType == 'NiSourceTexture':
					offset = self.getNodeOffset(nodeID)
					t=g.tell()
					g.seek(offset)
					if n==0:
						texType='diffuse'			  
						texPath=NiSourceTexture(self,levelID)
						texList[0]=texPath
					if n==3:
						texType='specular'			
						texPath=NiSourceTexture(self,levelID)
						texList[2]=texPath
					if n==6:
						texType='normal'			
						texPath=NiSourceTexture(self,levelID)
						texList[1]=texPath
					g.seek(t)
				if self.versionAsNumbers in self.nifFormatListOld:
					g.i(3)
					if g.B(1)[0]==1:g.f(5),g.i(1),g.f(2)
				if self.versionAsNumbers in self.nifFormatListNew:
					flag=g.H(1)[0] 
					#print 'flag:',flag
					if self.versionAsNumbers==(0,0,6,20):
						g.H(1)[0]
						
					flag=g.B(1)[0]
					if flag==1:
						g.f(6)
						g.i(1)
						g.f(2)
						
		numShaderTexture = g.i(1)[0]#texture count
		#print 'numShaderTexture:',numShaderTexture
		for n in range(numShaderTexture):
			if g.B(1)[0] == 1:
				g.i(1)[0] 
				g.i(1)[0] 
				g.i(1)[0] 
				g.i(1)[0] 
				#H(1)[0]
				#h(1)[0] 
				g.B(1)[0]  
			g.i(1)[0]
		#g.seek(back)	
	elif self.versionAsNumbers==(0,0,6,20):
		#print 'NiTexturingProperty'
		g=self.input
		#g.debug=True
		levelID+=4
		id=g.i(1)[0]
		if id!=-1:
			if self.versionAsNumbers in self.nifFormatListOld:
				name=g.word(id)
			if self.versionAsNumbers in self.nifFormatListNew:
				name=self.stringList[id]
		else:
			name=None
		#print name
		for n in range(g.i(1)[0]):g.i(1)
		g.i(1)[0]
		if self.versionAsNumbers in self.nifFormatListOld:
			g.i(1)[0]
		if self.versionAsNumbers in self.nifFormatListNew:
			g.H(1)[0]
		numTexture = g.i(1)[0]
			
			
		#mat=Mat()
		#mesh.matList.append(mat)
		#back = g.tell()
		#g.seek(offset)
		for n in range(numTexture):#n=0 - base texture
			has=g.B(1)[0]
			#print n,has
			if has == 1:#has?
				nodeID = g.i(1)[0] 
				#print nodeID
				nodeType = self.nodeTypeList[self.nodeIDList[nodeID]]
				if self.debug==True:
					print '-'*levelID,nodeID,nodeType,'='*10
				if nodeType == 'NiSourceTexture':
					offset = self.getNodeOffset(nodeID)
					t=g.tell()
					g.seek(offset)
					if n==0:
						texType='diffuse'			  
						texPath=NiSourceTexture(self,levelID)
						texList[0]=texPath
					if n==3:
						texType='specular'			
						texPath=NiSourceTexture(self,levelID)
						texList[2]=texPath
					if n==6:
						texType='normal'			
						texPath=NiSourceTexture(self,levelID)
						texList[1]=texPath
					g.seek(t)
					#g.debug=True
				if self.versionAsNumbers in self.nifFormatListOld:
					g.i(3)
					if g.B(1)[0]==1:g.f(5),g.i(1),g.f(2)
				if self.versionAsNumbers in self.nifFormatListNew:
					flag=g.H(1)[0] 
					#print 'flag:',flag
					if self.versionAsNumbers==(0,0,6,20):
						g.H(1)[0]
						
					flag=g.B(1)[0]
					if flag==1:
						g.f(5)
						g.i(1)
						g.f(2)
						
		numShaderTexture = g.i(1)[0]#texture count
		#print 'numShaderTexture:',numShaderTexture
		for n in range(numShaderTexture):
			if g.B(1)[0] == 1:
				g.i(1)[0] 
				g.i(1)[0] 
				g.i(1)[0] 
				g.i(1)[0] 
				#H(1)[0]
				#h(1)[0] 
				g.B(1)[0]  
			g.i(1)[0]
		#g.seek(back)		
	elif self.versionAsNumbers==(0,0,5,20):
		#print 'NiTexturingProperty'
		g=self.input
		levelID+=4
		id=g.i(1)[0]
		if id!=-1:
			if self.versionAsNumbers in self.nifFormatListOld:
				name=g.word(id)
			if self.versionAsNumbers in self.nifFormatListNew:
				name=self.stringList[id]
		else:
			name=None
		#print name
		for n in range(g.i(1)[0]):g.i(1)
		g.i(1)[0]
		if self.versionAsNumbers in self.nifFormatListOld:
			g.i(1)[0]
		if self.versionAsNumbers in self.nifFormatListNew:
			g.H(1)[0]
		numTexture = g.i(1)[0]
			
			
		#mat=Mat()
		#mesh.matList.append(mat)
		#back = g.tell()
		#g.seek(offset)
		for n in range(numTexture):#n=0 - base texture
			has=g.B(1)[0]
			#print n,has
			if has == 1:#has?
				nodeID = g.i(1)[0] 
				#print nodeID
				nodeType = self.nodeTypeList[self.nodeIDList[nodeID]]
				if self.debug==True:
					print '-'*levelID,nodeID,nodeType,'='*10
				if nodeType == 'NiSourceTexture':
					offset = self.getNodeOffset(nodeID)
					t=g.tell()
					g.seek(offset)
					if n==0:
						texType='diffuse'			  
						texPath=NiSourceTexture(self,levelID)
						texList[0]=texPath
					if n==3:
						texType='specular'			
						texPath=NiSourceTexture(self,levelID)
						texList[2]=texPath
					if n==6:
						texType='normal'			
						texPath=NiSourceTexture(self,levelID)
						texList[1]=texPath
					g.seek(t)
				if self.versionAsNumbers in self.nifFormatListOld:
					g.i(3)
					if g.B(1)[0]==1:g.f(5),g.i(1),g.f(2)
				if self.versionAsNumbers in self.nifFormatListNew:
					flag=g.H(1)[0] 
					#print 'flag:',flag
					if self.versionAsNumbers==(0,0,6,20):
						g.H(1)[0]
						
					flag=g.B(1)[0]
					if flag==1:
						g.f(6)
						g.i(1)
						g.f(2)
						
		numShaderTexture = g.i(1)[0]#texture count
		#print 'numShaderTexture:',numShaderTexture
		for n in range(numShaderTexture):
			if g.B(1)[0] == 1:
				g.i(1)[0] 
				g.i(1)[0] 
				g.i(1)[0] 
				g.i(1)[0] 
				#H(1)[0]
				#h(1)[0] 
				g.B(1)[0]  
			g.i(1)[0]
		#g.seek(back)	
	elif self.versionAsNumbers==(1,0,6,20):
		#print 'NiTexturingProperty'
		g=self.input
		#g.debug=True
		levelID+=4
		id=g.i(1)[0]
		if id!=-1:
			if self.versionAsNumbers in self.nifFormatListOld:
				name=g.word(id)
			if self.versionAsNumbers in self.nifFormatListNew:
				name=self.stringList[id]
		else:
			name=None
		#print name
		for n in range(g.i(1)[0]):g.i(1)
		g.i(1)[0]
		if self.versionAsNumbers in self.nifFormatListOld:
			g.i(1)[0]
		if self.versionAsNumbers in self.nifFormatListNew:
			g.H(1)[0]
		numTexture = g.i(1)[0]
			
			
		#mat=Mat()
		#mesh.matList.append(mat)
		#back = g.tell()
		#g.seek(offset)
		for n in range(numTexture):#n=0 - base texture
			has=g.B(1)[0]
			print n,has,g.tell()
			if has == 1:#has?
				nodeID = g.i(1)[0] 
				#print nodeID
				nodeType = self.nodeTypeList[self.nodeIDList[nodeID]]
				if self.debug==True:
					print '-'*levelID,nodeID,nodeType,'='*10
				if nodeType == 'NiSourceTexture':
					offset = self.getNodeOffset(nodeID)
					t=g.tell()
					g.seek(offset)
					if n==0:
						texType='diffuse'			  
						texPath=NiSourceTexture(self,levelID)
						texList[0]=texPath
					if n==3:
						texType='specular'			
						texPath=NiSourceTexture(self,levelID)
						texList[2]=texPath
					if n==6:
						texType='normal'			
						texPath=NiSourceTexture(self,levelID)
						texList[1]=texPath
					g.seek(t)
					#g.debug=True
				if self.versionAsNumbers in self.nifFormatListOld:
					g.i(3)
					if g.B(1)[0]==1:g.f(5),g.i(1),g.f(2)
				if self.versionAsNumbers in self.nifFormatListNew:
					flag=g.H(1)[0] 
					print 'flag:',flag
					if self.versionAsNumbers==(1,0,6,20):
						g.H(1)[0]
						
					flag=g.B(1)[0]
					if flag==1:
						g.f(5)
						g.i(1)
						g.f(2)
						
		numShaderTexture = g.i(1)[0]#texture count
		#print 'numShaderTexture:',numShaderTexture
		for n in range(numShaderTexture):
			if g.B(1)[0] == 1:
				g.i(1)[0] 
				g.i(1)[0] 
				g.i(1)[0] 
				g.i(1)[0] 
				#H(1)[0]
				#h(1)[0] 
				g.B(1)[0]  
			g.i(1)[0]
		#g.seek(back)	
	elif self.versionAsNumbers==(2,0,6,20):
		#print 'NiTexturingProperty'
		g=self.input
		#g.debug=True
		levelID+=4
		id=g.i(1)[0]
		if id!=-1:
			if self.versionAsNumbers in self.nifFormatListOld:
				name=g.word(id)
			if self.versionAsNumbers in self.nifFormatListNew:
				name=self.stringList[id]
		else:
			name=None
		#print name
		for n in range(g.i(1)[0]):g.i(1)
		g.i(1)[0]
		if self.versionAsNumbers in self.nifFormatListOld:
			g.i(1)[0]
		if self.versionAsNumbers in self.nifFormatListNew:
			g.H(1)[0]
		numTexture = g.i(1)[0]
			
			
		#mat=Mat()
		#mesh.matList.append(mat)
		#back = g.tell()
		#g.seek(offset)
		for n in range(numTexture):#n=0 - base texture
			has=g.B(1)[0]
			print n,has,g.tell()
			if has == 1:#has?
				nodeID = g.i(1)[0] 
				#print nodeID
				nodeType = self.nodeTypeList[self.nodeIDList[nodeID]]
				if self.debug==True:
					print '-'*levelID,nodeID,nodeType,'='*10
				if nodeType == 'NiSourceTexture':
					offset = self.getNodeOffset(nodeID)
					t=g.tell()
					g.seek(offset)
					if n==0:
						texType='diffuse'			  
						texPath=NiSourceTexture(self,levelID)
						texList[0]=texPath
					if n==3:
						texType='specular'			
						texPath=NiSourceTexture(self,levelID)
						texList[2]=texPath
					if n==6:
						texType='normal'			
						texPath=NiSourceTexture(self,levelID)
						texList[1]=texPath
					g.seek(t)
					#g.debug=True
				if self.versionAsNumbers in self.nifFormatListOld:
					g.i(3)
					if g.B(1)[0]==1:g.f(5),g.i(1),g.f(2)
				if self.versionAsNumbers in self.nifFormatListNew:
					flag=g.H(1)[0] 
					print 'flag:',flag
					if self.versionAsNumbers==(2,0,6,20):
						g.H(1)[0]
						
					flag=g.B(1)[0]
					if flag==1:
						g.f(5)
						g.i(1)
						g.f(2)
						
		numShaderTexture = g.i(1)[0]#texture count
		#print 'numShaderTexture:',numShaderTexture
		for n in range(numShaderTexture):
			if g.B(1)[0] == 1:
				g.i(1)[0] 
				g.i(1)[0] 
				g.i(1)[0] 
				g.i(1)[0] 
				#H(1)[0]
				#h(1)[0] 
				g.B(1)[0]  
			g.i(1)[0]
		#g.seek(back)				
	else:
		print 'NiTexturingProperty:',self.versionAsNumbers,'not supported'
	
	return texList