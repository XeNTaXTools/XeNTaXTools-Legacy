

import NiBSplineBasisData
reload(NiBSplineBasisData)
from NiBSplineBasisData import *
from newGameLib.myLibraries.myFunction import *

def NiBSplineCompTransformInterpolator(self,levelID):
	levelID+=4
	g=self.input
	#g.debug=True
	g.f(2)
	#g.i(2)
	
	
	dataID=g.i(1)[0]	
	
	basicID=g.i(1)[0]		
	nodeType = self.nodeTypeList[self.nodeIDList[basicID]]
	offset=self.getNodeOffset(basicID)
	size=self.nodeSizeList[basicID]
	if self.debug==True:
		print '='*levelID,basicID,nodeType,size
	back=g.tell()
	g.seek(offset)
	#if nodeType=='NiNode':NiNode(self,levelID,'',Matrix())
	#if nodeType=='NiPersistentSrcTextureRendererData':NiPersistentSrcTextureRendererDataNode(self)
	#if nodeType=='MdlMan::CModelTemplateDataEntry':CModelTemplateDataEntry(self,levelID)
	if nodeType=='NiBSplineBasisData':
		pointCount=NiBSplineBasisData(self,levelID)
	g.seek(back)	
	
	
	#g.debug=True
	g.f(3)
	g.f(4)
	g.i(1)
	posOffset,rotOffset,scaleOffset=g.i(3)
	posBias,posMulti,rotBias,rotMulti,scBias,scMulti=g.f(6)
	print posOffset,rotOffset,scaleOffset
	
		
	nodeType = self.nodeTypeList[self.nodeIDList[dataID]]
	offset=self.getNodeOffset(dataID)
	size=self.nodeSizeList[dataID]
	if self.debug==True:
		print '='*levelID,dataID,nodeType,size
	back=g.tell()
	g.seek(offset)
	floatCount=g.i(1)[0]
	g.seek(floatCount*4,1)
	shortCount=g.i(1)[0]
	start=g.tell()
	posFrameList=[]
	posKeyList=[]
	rotFrameList=[]
	rotKeyList=[]
	if posOffset!=65535:
		g.seek(start+posOffset*2)
		for i in range(pointCount):
			posFrameList.append(i)
			r1=posBias+((g.h(1)[0]*posMulti)/32767.0)
			r2=posBias+((g.h(1)[0]*posMulti)/32767.0)
			r3=posBias+((g.h(1)[0]*posMulti)/32767.0)
			posKeyList.append(VectorMatrix([r1,r2,r3]))
	if rotOffset!=65535:
		g.seek(start+rotOffset*2)
		for i in range(pointCount):
			rotFrameList.append(i)
			r1=rotBias+((g.h(1)[0]*rotMulti)/32767.0)
			r2=rotBias+((g.h(1)[0]*rotMulti)/32767.0)
			r3=rotBias+((g.h(1)[0]*rotMulti)/32767.0)
			r4=rotBias+((g.h(1)[0]*rotMulti)/32767.0)
			rotKeyList.append(QuatMatrix([r1,r2,r3,r4]).invert().resize4x4())#.invert())
	g.seek(back)	
	return posFrameList,posKeyList,rotFrameList,rotKeyList
	