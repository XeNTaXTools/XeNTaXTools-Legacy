#
from newGameLib.myLibraries.imageLib import *



import CMeshDataEntry
reload(CMeshDataEntry)
from CMeshDataEntry import *



def CModelTemplateDataEntry(self,levelID):
	#print 'CModelTemplateDataEntry'
	g=self.input
	#g.debug=True
	g.tell()
	g.i(2)
	g.B(1)
	g.i(1)
	count=g.i(1)[0]
	levelID+=4
	for i in range(count):
		ID=g.i(1)[0]		
		nodeType = self.nodeTypeList[self.nodeIDList[ID]]
		offset=self.getNodeOffset(ID)
		size=self.nodeSizeList[ID]
		if self.debug==True:
			print '-'*levelID,ID,nodeType,size
		back=g.tell()
		g.seek(offset)
		if nodeType=='NiNode':
			NiNode(self,levelID)
		if nodeType=='NiPersistentSrcTextureRendererData':
			NiPersistentSrcTextureRendererDataNode(self)
		if nodeType=='MdlMan::CMeshDataEntry':
			CMeshDataEntry(self,levelID)
		g.seek(back)