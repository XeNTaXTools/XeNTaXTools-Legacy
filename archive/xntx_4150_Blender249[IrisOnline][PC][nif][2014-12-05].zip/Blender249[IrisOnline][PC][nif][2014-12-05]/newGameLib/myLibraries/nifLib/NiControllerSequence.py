
import NiBSplineCompTransformInterpolator
reload(NiBSplineCompTransformInterpolator)
from NiBSplineCompTransformInterpolator import *

from newGameLib.myLibraries.actionLib import *

def NiControllerSequence(self,levelID):
	if self.versionAsNumbers==(9,0,3,20):
		action=Action()
		action.BONESPACE=True
		#action.ARMATURESPACE=True
		action.BONESORT=True
		action.skeleton='armature'
		levelID+=4
		g=self.input
		#g.debug=True
		ID=g.i(1)[0]
		if ID!=-1:
			if self.versionAsNumbers in self.nifFormatListOld:
				name=g.word(ID)
			if self.versionAsNumbers in self.nifFormatListNew:
				name=self.stringList[ID]
		else:
			name=None
		#g.i(2)
		blockCount=g.i(1)[0]
		g.i(1)[0]
		self.input.logOpen()
		for i in range(blockCount):
			ID=g.i(1)[0]		
			nodeType = self.nodeTypeList[self.nodeIDList[ID]]
			offset=self.getNodeOffset(ID)
			size=self.nodeSizeList[ID]
			if self.debug==True:
				print '='*levelID,ID,nodeType,size
			back=g.tell()
			g.seek(offset)
			posFrameList=[]
			posKeyList=[]
			rotFrameList=[]
			rotKeyList=[]
			if nodeType=='NiBSplineCompTransformInterpolator':
				posFrameList,posKeyList,rotFrameList,rotKeyList=NiBSplineCompTransformInterpolator(self,levelID)
			g.seek(back)	
			w=g.i(6)
			#print w
			name=None
			if self.versionAsNumbers in self.nifFormatListOld:name=g.word(w[1])
			if self.versionAsNumbers in self.nifFormatListNew:name=self.stringList[w[1]]
			if name is not None:
				bone=ActionBone()
				bone.name=name
				bone.posFrameList=posFrameList
				bone.posKeyList=posKeyList
				bone.rotFrameList=rotFrameList
				bone.rotKeyList=rotKeyList
				action.boneList.append(bone)
			#break	
		action.draw()
		action.setContext()
		self.input.logClose()	
	else:
		action=Action()
		action.BONESPACE=True
		#action.ARMATURESPACE=True
		action.BONESORT=True
		action.skeleton='skeleton'
		levelID+=4
		g=self.input
		#g.debug=True
		ID=g.i(1)[0]
		if ID!=-1:
			if self.versionAsNumbers in self.nifFormatListOld:
				name=g.word(ID)
			if self.versionAsNumbers in self.nifFormatListNew:
				name=self.stringList[ID]
		else:
			name=None
		g.i(2)
		blockCount=g.i(1)[0]
		g.i(1)[0]
		self.input.logOpen()
		for i in range(blockCount):
			ID=g.i(1)[0]		
			nodeType = self.nodeTypeList[self.nodeIDList[ID]]
			offset=self.getNodeOffset(ID)
			size=self.nodeSizeList[ID]
			if self.debug==True:
				print '='*levelID,ID,nodeType,size
			back=g.tell()
			g.seek(offset)
			posFrameList=[]
			posKeyList=[]
			rotFrameList=[]
			rotKeyList=[]
			if nodeType=='NiBSplineCompTransformInterpolator':
				posFrameList,posKeyList,rotFrameList,rotKeyList=NiBSplineCompTransformInterpolator(self,levelID)
			g.seek(back)	
			w=g.i(6)
			#print w
			name=None
			if self.versionAsNumbers in self.nifFormatListOld:name=g.word(w[1])
			if self.versionAsNumbers in self.nifFormatListNew:name=self.stringList[w[1]]
			if name is not None:
				bone=ActionBone()
				bone.name=name
				bone.posFrameList=posFrameList
				bone.posKeyList=posKeyList
				bone.rotFrameList=rotFrameList
				bone.rotKeyList=rotKeyList
				action.boneList.append(bone)
			#break	
		action.draw()
		action.setContext()
		self.input.logClose()		
			