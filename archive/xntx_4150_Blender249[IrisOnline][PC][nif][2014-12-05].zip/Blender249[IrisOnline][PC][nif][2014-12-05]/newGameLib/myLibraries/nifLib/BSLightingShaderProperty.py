

import BSShaderTextureSet
reload(BSShaderTextureSet)
from BSShaderTextureSet import *

def BSLightingShaderProperty(self,levelID):
	texList=[None,None,None]
	g=self.input
	shaderType=g.i(1)[0]
	name=self.stringList[g.i(1)[0]]
	g.i(g.i(1)[0])
	controller=g.i(1)[0]
	flags=g.i(2)
	g.f(4)
	textureSetID=g.i(1)[0]
	offset = self.getNodeOffset(textureSetID)
	back=g.tell()
	g.seek(offset)
	nodeType=self.nodeTypeList[self.nodeIDList[textureSetID]]
	size=self.nodeSizeList[textureSetID]
	if self.debug==True:
		print '-'*levelID,textureSetID,nodeType,size
	if nodeType=='BSShaderTextureSet':
		texList=BSShaderTextureSet(self)					
	g.seek(back)
	return texList