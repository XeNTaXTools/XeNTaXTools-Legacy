
from Blender.Mathutils import *
	

import NiTriShapeData
reload(NiTriShapeData)
from NiTriShapeData import *

import NiTexturingProperty
reload(NiTexturingProperty)
from NiTexturingProperty import *

from newGameLib.myLibraries.meshLib import *
#from libraryList.nif import *
from newGameLib.myLibraries.binaresLib import *


import NiSkinInstance
reload(NiSkinInstance)
from NiSkinInstance import *

import BSLightingShaderProperty
reload(BSLightingShaderProperty)
from BSLightingShaderProperty import *

from newGameLib.myLibraries.skeletonLib import *

		
def NiTriShape(self,levelID,parentMatrix):

	if self.versionAsNumbers==(4,0,0,20):
		g=self.input
		levelID+=4
		if self.versionAsNumbers in self.nifFormatListOld:name=g.word(g.i(1)[0])
		if self.versionAsNumbers in self.nifFormatListNew:name=self.stringList[g.i(1)[0]]
		
		for n in range(g.i(1)[0]):g.i(1)
		g.i(1)[0],g.H(1)[0]
		
		if self.userVersion==12:
			g.H(1)
			
		pos = TranslationMatrix(Vector(g.f(3)))
		rot = Matrix(g.f(3),g.f(3),g.f(3)).resize4x4()
		nodeMatrix= rot*pos*parentMatrix
		
		g.f(1)[0]
		texList=None
		if self.userVersion!=12:
			for n in range(g.i(1)[0]):#properties 
				nodeID = g.i(1)[0]
				nodeType = self.nodeTypeList[self.nodeIDList[nodeID]]
				if self.debug==True:
					print '-'*levelID,nodeID,nodeType
				if nodeType == 'NiTexturingProperty':
					if self.PARSINGFLAG==False:
						offset = self.getNodeOffset(nodeID)
						back=g.tell()
						g.seek(offset)
						texList=NiTexturingProperty(self,levelID)
						g.seek(back)
		g.i(1)[0]
		
		#NiTriShapeData
		shapeNodeID = g.i(1)[0]
		skinNodeID = g.i(1)[0]
		#print shapeNodeID
		flag=g.B(1)[0]
		if flag==1:
			g.word(g.i(1)[0])
		g.i(1)	
		
		nodeType = self.nodeTypeList[self.nodeIDList[shapeNodeID]]
		if self.PARSINGFLAG==False:
			offset = self.getNodeOffset(shapeNodeID)
			back=g.tell()
			g.seek(offset)
			mesh=Mesh()
			mesh.name=name
			mesh.matrix=nodeMatrix
			#print mesh.name
			mat=Mat()
			mat.TRIANGLE=True
			mat.ZTRANS=True
			mesh.matList.append(mat)
			if self.debug==True:
				print '-'*levelID,shapeNodeID,nodeType
			NiTriShapeData(self,mesh,levelID)
			g.seek(back)
			chunk=name.lower().split('_')[-1]
			if texList is not None:
					#print texList
					if self.userVersion==196608:					
						texDir=g.dirname.lower().split('characters')[0]+'textures'
						if texList[0] is not None:
							texPath=texDir+os.sep+texList[0].split('.')[0]+'.nif'
							if os.path.exists(texPath)==True:
								#print texPath
								file=open(texPath,'rb')
								p=BinaryReader(file)
								p.debug=False
								#nif=Nif()
								#nif.debug=False
								#nif.input=p
								#nif.explore()
								#file.close()
								mat.diffuse=texDir+os.sep+texList[0].split('.')[0]+'.dds'
					else:
						mat.diffuse=texList[0]	
		
			#NiSkinInstance
			if skinNodeID!=-1:
					offset = self.getNodeOffset(skinNodeID)
					back=g.tell()
					g.seek(offset)
					if self.debug==True:
						nodeType=self.nodeTypeList[self.nodeIDList[skinNodeID]]
						size=self.nodeSizeList[skinNodeID]
						if self.debug==True:
							print '-'*levelID,skinNodeID,nodeType,size
					
					
					boneNameList,skinData=NiSkinInstance(self,levelID)
					g.seek(back)
					
					skin=Skin()
					mesh.boneNameList=boneNameList
					for m in range(len(mesh.vertPosList)):
						mesh.skinIndiceList.append([])
						mesh.skinWeightList.append([])
					skeleton=Skeleton()
					skeleton.NICE=True
					skeleton.ARMATURESPACE=True
					#skeleton.matrix=nodeMatrix
					skeleton.name=str(skinNodeID)	
					for m in range(len(skinData)):#bone list
						bone=Bone()
						matrix=skinData[m][0] 
						bone.name=boneNameList[m]
						bone.matrix=matrix.invert()*nodeMatrix
						data=skinData[m][1] 
						for n in range(len(data)):
							mesh.skinIndiceList[data[n][0]].append(m)
							mesh.skinWeightList[data[n][0]].append(data[n][1])
						skeleton.boneList.append(bone)
					mesh.skinList.append(skin)
					skeleton.draw()			
					mesh.BINDPOSESKELETON=skeleton.name		
			if self.versionAsNumbers in self.nifFormatListOld:
				if g.B(1)[0] == 1:
					g.word(g.i(1)[0]),g.i(1)[0] 
			if self.versionAsNumbers in self.nifFormatListNew:
				matCount=g.i(1)[0]
				for m in range(matCount):
					name=self.stringList[g.i(1)[0]]
				for m in range(matCount):
					g.i(1)
				g.i(1)
				g.B(1)	
					
					
			if self.userVersion==196608:
				if chunk not in ['medlod','lowlod','low','med']:
					#mesh.BINDSKELETON='skeleton'
					#mesh.BINDPOSE=True	
					self.meshList.append(mesh)
					#mesh.draw()		
			if self.userVersion==0:
				if chunk not in ['medlod','lowlod','low','med']:
					#mesh.BINDPOSESKELETON=skeleton.name	
					#mesh.BINDSKELETON='armature'
					#mesh.BINDPOSE=True	
					#mesh.draw()	
					self.meshList.append(mesh)			
			

	elif self.versionAsNumbers==(0,0,2,10):
		g=self.input
		levelID+=4
		if self.versionAsNumbers in self.nifFormatListOld:name=g.word(g.i(1)[0])
		if self.versionAsNumbers in self.nifFormatListNew:name=self.stringList[g.i(1)[0]]
		for n in range(g.i(1)[0]):g.i(1)
		g.i(1)[0],g.H(1)[0]
		
		if self.userVersion==12:
			g.H(1)
			
		pos = TranslationMatrix(Vector(g.f(3)))
		rot = Matrix(g.f(3),g.f(3),g.f(3)).invert().resize4x4()
		nodeMatrix= rot*pos
		
		g.f(1)[0]
		texList=None
		if self.userVersion!=12:
			for n in range(g.i(1)[0]):#properties 
				nodeID = g.i(1)[0]
				nodeType = self.nodeTypeList[self.nodeIDList[nodeID]]
				if self.debug==True:
					print '-'*levelID,nodeID,nodeType
				if nodeType == 'NiTexturingProperty':
					if self.versionAsNumbers!=(4,0,0,20):
						if self.PARSINGFLAG==False:
							offset = self.getNodeOffset(nodeID)
							back=g.tell()
							g.seek(offset)
							texList=NiTexturingProperty(self,levelID)
							g.seek(back)
		g.i(1)[0]
		
		#NiTriShapeData
		shapeNodeID = g.i(1)[0]
		skinNodeID = g.i(1)[0]
		#print shapeNodeID
		flag=g.B(1)[0]
		if flag==1:
			g.word(g.i(1)[0])
			g.i(1)	
		
		nodeType = self.nodeTypeList[self.nodeIDList[shapeNodeID]]
		if self.PARSINGFLAG==False:
			offset = self.getNodeOffset(shapeNodeID)
			back=g.tell()
			g.seek(offset)
			mesh=Mesh()
			mesh.name=name
			mesh.matrix=nodeMatrix
			#print mesh.name
			mat=Mat()
			mat.TRIANGLE=True
			mat.ZTRANS=True
			mesh.matList.append(mat)
			if self.debug==True:
				print '-'*levelID,shapeNodeID,nodeType
			NiTriShapeData(self,mesh,levelID)
			g.seek(back)
			chunk=name.lower().split('_')[-1]
			if texList is not None:
					#print texList
					if self.userVersion==196608:					
						texDir=g.dirname.lower().split('characters')[0]+'textures'
						if texList[0] is not None:
							texPath=texDir+os.sep+texList[0].split('.')[0]+'.nif'
							if os.path.exists(texPath)==True:
								#print texPath
								file=open(texPath,'rb')
								p=BinaryReader(file)
								#nif=Nif()
								#nif.debug=False
								#nif.input=p
								#nif.explore()
								#file.close()
								mat.diffuse=texDir+os.sep+texList[0].split('.')[0]+'.dds'
		
			#NiSkinInstance
			if skinNodeID!=-1:
					offset = self.getNodeOffset(skinNodeID)
					back=g.tell()
					g.seek(offset)
					if self.debug==True:
						nodeType=self.nodeTypeList[self.nodeIDList[skinNodeID]]
						size=self.nodeSizeList[skinNodeID]
						if self.debug==True:
							print '-'*levelID,skinNodeID,nodeType,size
					
					
					boneNameList,skinData=NiSkinInstance(self,levelID)
					g.seek(back)
					
					skin=Skin()
					mesh.boneNameList=boneNameList
					for m in range(len(mesh.vertPosList)):
						mesh.skinIndiceList.append([])
						mesh.skinWeightList.append([])
					skeleton=Skeleton()
					skeleton.NICE=True
					skeleton.ARMATURESPACE=True
					skeleton.name=str(skinNodeID)	
					for m in range(len(skinData)):#bone list
						bone=Bone()
						matrix=skinData[m][0] 
						bone.name=boneNameList[m]
						bone.matrix=matrix.invert()*nodeMatrix
						data=skinData[m][1] 
						for n in range(len(data)):
							mesh.skinIndiceList[data[n][0]].append(m)
							mesh.skinWeightList[data[n][0]].append(data[n][1])
						skeleton.boneList.append(bone)
					mesh.skinList.append(skin)
					skeleton.draw()			
					mesh.BINDPOSESKELETON=skeleton.name	
					
					
			if self.userVersion==196608:
				if chunk not in ['medlod','lowlod','low','med']:
					#mesh.BINDSKELETON='skeleton'
					#mesh.BINDPOSE=True	
					self.meshList.append(mesh)
					#mesh.draw()		
			if self.userVersion==0:
				if chunk not in ['medlod','lowlod','low','med']:
					#mesh.BINDPOSESKELETON=skeleton.name	
					#mesh.BINDSKELETON='armature'
					#mesh.BINDPOSE=True	
					#mesh.draw()	
					self.meshList.append(mesh)			
						
	elif self.versionAsNumbers==(9,0,3,20):
		g=self.input
		levelID+=4
		if self.versionAsNumbers in self.nifFormatListOld:name=g.word(g.i(1)[0])
		if self.versionAsNumbers in self.nifFormatListNew:name=self.stringList[g.i(1)[0]]
		
		for n in range(g.i(1)[0]):g.i(1)
		g.i(1)[0],g.H(1)[0]
		
		if self.userVersion==12:
			g.H(1)
			
		pos = TranslationMatrix(Vector(g.f(3)))
		rot = Matrix(g.f(3),g.f(3),g.f(3)).invert().resize4x4()
		nodeMatrix= rot*pos*parentMatrix
		
		g.f(1)[0]
		texList=None
		if self.userVersion!=12:
			for n in range(g.i(1)[0]):#properties 
				nodeID = g.i(1)[0]
				nodeType = self.nodeTypeList[self.nodeIDList[nodeID]]
				if self.debug==True:
					print '-'*levelID,nodeID,nodeType
				if nodeType == 'NiTexturingProperty':
					if self.versionAsNumbers!=(4,0,0,20):
						offset = self.getNodeOffset(nodeID)
						back=g.tell()
						g.seek(offset)
						texList=NiTexturingProperty(self,levelID)
						g.seek(back)
		g.i(1)[0]
		
		#NiTriShapeData
		shapeNodeID = g.i(1)[0]
		#print shapeNodeID
		nodeType = self.nodeTypeList[self.nodeIDList[shapeNodeID]]
		if self.versionAsNumbers!=(4,0,0,20):
			offset = self.getNodeOffset(shapeNodeID)
			back=g.tell()
			g.seek(offset)
			mesh=Mesh()
			mesh.name=name
			mesh.matrix=nodeMatrix
			#print mesh.name
			mat=Mat()
			mat.TRIANGLE=True
			mat.ZTRANS=True
			mesh.matList.append(mat)
			if self.debug==True:
				print '-'*levelID,shapeNodeID,nodeType
			NiTriShapeData(self,mesh,levelID)
			g.seek(back)
			chunk=name.lower().split('_')[-1]
			if texList is not None:
					#print texList
					if self.userVersion==196608:					
						texDir=g.dirname.lower().split('characters')[0]+'textures'
						if texList[0] is not None:
							texPath=texDir+os.sep+texList[0].split('.')[0]+'.nif'
							if os.path.exists(texPath)==True:
								#print texPath
								file=open(texPath,'rb')
								p=BinaryReader(file)
								p.debug=False
								#nif=Nif()
								#nif.debug=False
								#nif.input=p
								#nif.explore()
								#file.close()
								mat.diffuse=texDir+os.sep+texList[0].split('.')[0]+'.dds'
		
			#NiSkinInstance
			skinNodeID = g.i(1)[0]
			if skinNodeID!=-1:
				if self.versionAsNumbers!=(4,0,0,20):
					offset = self.getNodeOffset(skinNodeID)
					back=g.tell()
					g.seek(offset)
					if self.debug==True:
						nodeType=self.nodeTypeList[self.nodeIDList[skinNodeID]]
						size=self.nodeSizeList[skinNodeID]
						if self.debug==True:
							print '-'*levelID,skinNodeID,nodeType,size
					
					
					boneNameList,skinData=NiSkinInstance(self,levelID)
					g.seek(back)
					
					skin=Skin()
					mesh.boneNameList=boneNameList
					for m in range(len(mesh.vertPosList)):
						mesh.skinIndiceList.append([])
						mesh.skinWeightList.append([])
					skeleton=Skeleton()
					skeleton.NICE=True
					skeleton.ARMATURESPACE=True
					skeleton.name=str(skinNodeID)	
					for m in range(len(skinData)):#bone list
						bone=Bone()
						matrix=skinData[m][0] 
						bone.name=boneNameList[m]
						bone.matrix=matrix.invert()*nodeMatrix
						data=skinData[m][1] 
						for n in range(len(data)):
							mesh.skinIndiceList[data[n][0]].append(m)
							mesh.skinWeightList[data[n][0]].append(data[n][1])
						skeleton.boneList.append(bone)
					mesh.skinList.append(skin)
					skeleton.draw()			
					mesh.BINDPOSESKELETON=skeleton.name		
			if self.versionAsNumbers in self.nifFormatListOld:
				if g.B(1)[0] == 1:
					g.word(g.i(1)[0]),g.i(1)[0] 
			if self.versionAsNumbers in self.nifFormatListNew:
				matCount=g.i(1)[0]
				for m in range(matCount):
					name=self.stringList[g.i(1)[0]]
				for m in range(matCount):
					g.i(1)
				g.i(1)
				g.B(1)	
					
					
			if self.userVersion==196608:
				if chunk not in ['medlod','lowlod','low','med']:
					#mesh.BINDSKELETON='skeleton'
					#mesh.BINDPOSE=True	
					self.meshList.append(mesh)
					#mesh.draw()		
			if self.userVersion==0:
				if chunk not in ['medlod','lowlod','low','med']:
					#mesh.BINDPOSESKELETON=skeleton.name	
					#mesh.BINDSKELETON='armature'
					#mesh.BINDPOSE=True	
					#mesh.draw()	
					self.meshList.append(mesh)				
				
		
	elif self.versionAsNumbers==(103,95,97,115):
		g=self.input
		levelID+=4
		if self.versionAsNumbers in self.nifFormatListOld:name=g.word(g.i(1)[0])
		if self.versionAsNumbers in self.nifFormatListNew:name=self.stringList[g.i(1)[0]]
		
		for n in range(g.i(1)[0]):g.i(1)
		g.i(1)[0],g.H(1)[0]
		
		if self.userVersion==12:
			g.H(1)
			
		pos = TranslationMatrix(Vector(g.f(3)))
		rot = Matrix(g.f(3),g.f(3),g.f(3)).invert().resize4x4()
		nodeMatrix= rot*pos
		
		g.f(1)[0]
		texList=None
		if self.userVersion!=12:
			for n in range(g.i(1)[0]):#properties 
				nodeID = g.i(1)[0]
				nodeType = self.nodeTypeList[self.nodeIDList[nodeID]]
				if self.debug==True:
					print '-'*levelID,nodeID,nodeType
				if nodeType == 'NiTexturingProperty':
					if self.versionAsNumbers!=(4,0,0,20):
						offset = self.getNodeOffset(nodeID)
						back=g.tell()
						g.seek(offset)
						texList=NiTexturingProperty(self,levelID)
						g.seek(back)
		g.i(1)[0]
		
		#NiTriShapeData
		shapeNodeID = g.i(1)[0]
		#print shapeNodeID
		nodeType = self.nodeTypeList[self.nodeIDList[shapeNodeID]]
		if self.versionAsNumbers!=(4,0,0,20):
			offset = self.getNodeOffset(shapeNodeID)
			back=g.tell()
			g.seek(offset)
			mesh=Mesh()
			mesh.name=name
			mesh.matrix=nodeMatrix
			#print mesh.name
			mat=Mat()
			mat.TRIANGLE=True
			mat.ZTRANS=True
			mesh.matList.append(mat)
			if self.debug==True:
				print '-'*levelID,shapeNodeID,nodeType
			NiTriShapeData(self,mesh,levelID)
			g.seek(back)
			chunk=name.lower().split('_')[-1]
			if texList is not None:
					#print texList
					if self.userVersion==196608:					
						texDir=g.dirname.lower().split('characters')[0]+'textures'
						if texList[0] is not None:
							texPath=texDir+os.sep+texList[0].split('.')[0]+'.nif'
							if os.path.exists(texPath)==True:
								#print texPath
								file=open(texPath,'rb')
								p=BinaryReader(file)
								p.debug=False
								nif=Nif()
								nif.debug=False
								nif.input=p
								nif.explore()
								file.close()
								mat.diffuse=texDir+os.sep+texList[0].split('.')[0]+'.dds'
					else:
						texDir=g.dirname#.lower().split('characters')[0]+'textures'
						if texList[0] is not None:
							mat.diffuse=texDir+os.sep+texList[0].split('.')[0]+'.dds'
							if os.path.exists(mat.diffuse)==False:
								mat.diffuse=texDir+os.sep+texList[0].split('.')[0]+'.tga'
						
		
			#NiSkinInstance
			skinNodeID = g.i(1)[0]
			if skinNodeID!=-1:
				if self.versionAsNumbers!=(4,0,0,20):
					offset = self.getNodeOffset(skinNodeID)
					back=g.tell()
					g.seek(offset)
					if self.debug==True:
						nodeType=self.nodeTypeList[self.nodeIDList[skinNodeID]]
						size=self.nodeSizeList[skinNodeID]
						if self.debug==True:
							print '-'*levelID,skinNodeID,nodeType,size
					
					
					boneNameList,skinData=NiSkinInstance(self,levelID)
					g.seek(back)
					
					skin=Skin()
					mesh.boneNameList=boneNameList
					for m in range(len(mesh.vertPosList)):
						mesh.skinIndiceList.append([])
						mesh.skinWeightList.append([])
					skeleton=Skeleton()
					skeleton.ARMATURESPACE=True
					skeleton.NICE=True
					skeleton.name=str(skinNodeID)	
					for m in range(len(skinData)):#bone list
						bone=Bone()
						matrix=skinData[m][0] 
						bone.name=boneNameList[m]
						bone.matrix=matrix.invert()*nodeMatrix
						data=skinData[m][1] 
						for n in range(len(data)):
							mesh.skinIndiceList[data[n][0]].append(m)
							mesh.skinWeightList[data[n][0]].append(data[n][1])
						skeleton.boneList.append(bone)
					mesh.skinList.append(skin)
					skeleton.draw()			
					mesh.BINDPOSESKELETON=skeleton.name		
			if self.versionAsNumbers in self.nifFormatListOld:
				if g.B(1)[0] == 1:
					g.word(g.i(1)[0]),g.i(1)[0] 
			if self.versionAsNumbers in self.nifFormatListNew:
				matCount=g.i(1)[0]
				for m in range(matCount):
					name=self.stringList[g.i(1)[0]]
				for m in range(matCount):
					g.i(1)
				g.i(1)
				g.B(1)	
					
					
			if self.userVersion==196608:
				if chunk not in ['medlod','lowlod','low','med']:
					#mesh.BINDSKELETON='skeleton'
					#mesh.BINDPOSE=True	
					self.meshList.append(mesh)
					#mesh.draw()		
			if self.userVersion==0:
				if chunk not in ['medlod','lowlod','low','med']:
					#mesh.BINDPOSESKELETON=skeleton.name	
					#mesh.BINDSKELETON='armature'
					#mesh.BINDPOSE=True	
					#mesh.draw()	
					self.meshList.append(mesh)				
						
		
	elif self.versionAsNumbers==(8,0,2,20):
		g=self.input
		levelID+=4
		if self.versionAsNumbers in self.nifFormatListOld:name=g.word(g.i(1)[0])
		if self.versionAsNumbers in self.nifFormatListNew:name=self.stringList[g.i(1)[0]]
		
		for n in range(g.i(1)[0]):g.i(1)
		g.i(1)[0],g.H(1)[0]
		
		if self.userVersion==12:
			g.H(1)
			
		pos = TranslationMatrix(Vector(g.f(3)))
		rot = Matrix(g.f(3),g.f(3),g.f(3)).invert().resize4x4()
		nodeMatrix= rot*pos*parentMatrix
		
		g.f(1)[0]
		texList=None
		if self.userVersion!=12:
			for n in range(g.i(1)[0]):#properties 
				nodeID = g.i(1)[0]
				nodeType = self.nodeTypeList[self.nodeIDList[nodeID]]
				if self.debug==True:
					print '-'*levelID,nodeID,nodeType
				if nodeType == 'NiTexturingProperty':
					if self.versionAsNumbers!=(4,0,0,20):
						offset = self.getNodeOffset(nodeID)
						back=g.tell()
						g.seek(offset)
						texList=NiTexturingProperty(self,levelID)
						g.seek(back)
		g.i(1)[0]
		
		#NiTriShapeData
		shapeNodeID = g.i(1)[0]
		#print shapeNodeID
		nodeType = self.nodeTypeList[self.nodeIDList[shapeNodeID]]
		if self.versionAsNumbers!=(4,0,0,20):
			offset = self.getNodeOffset(shapeNodeID)
			back=g.tell()
			g.seek(offset)
			mesh=Mesh()
			mesh.name=name
			mesh.matrix=nodeMatrix
			#print mesh.name
			mat=Mat()
			mat.TRIANGLE=True
			mat.ZTRANS=True
			mesh.matList.append(mat)
			if self.debug==True:
				print '-'*levelID,shapeNodeID,nodeType
			NiTriShapeData(self,mesh,levelID)
			g.seek(back)
			chunk=name.lower().split('_')[-1]
			if texList is not None:
					#print texList
					if self.userVersion==196608:					
						texDir=g.dirname.lower().split('characters')[0]+'textures'
						if texList[0] is not None:
							texPath=texDir+os.sep+texList[0].split('.')[0]+'.nif'
							if os.path.exists(texPath)==True:
								#print texPath
								file=open(texPath,'rb')
								p=BinaryReader(file)
								p.debug=False
								nif=Nif()
								nif.debug=False
								nif.input=p
								nif.explore()
								file.close()
								mat.diffuse=texDir+os.sep+texList[0].split('.')[0]+'.dds'
					else:
						texDir=g.dirname#.lower().split('characters')[0]+'textures'
						if texList[0] is not None:
							mat.diffuse=texDir+os.sep+texList[0].split('.')[0]+'.dds'
							if os.path.exists(mat.diffuse)==False:
								mat.diffuse=texDir+os.sep+texList[0].split('.')[0]+'.tga'
						
		
			#NiSkinInstance
			skinNodeID = g.i(1)[0]
			if skinNodeID!=-1:
				if self.versionAsNumbers!=(4,0,0,20):
					offset = self.getNodeOffset(skinNodeID)
					back=g.tell()
					g.seek(offset)
					if self.debug==True:
						nodeType=self.nodeTypeList[self.nodeIDList[skinNodeID]]
						size=self.nodeSizeList[skinNodeID]
						if self.debug==True:
							print '-'*levelID,skinNodeID,nodeType,size
					
					
					boneNameList,skinData=NiSkinInstance(self,levelID)
					g.seek(back)
					
					skin=Skin()
					mesh.boneNameList=boneNameList
					for m in range(len(mesh.vertPosList)):
						mesh.skinIndiceList.append([])
						mesh.skinWeightList.append([])
					skeleton=Skeleton()
					skeleton.NICE=True
					skeleton.ARMATURESPACE=True
					skeleton.name=str(skinNodeID)	
					for m in range(len(skinData)):#bone list
						bone=Bone()
						matrix=skinData[m][0] 
						bone.name=boneNameList[m]
						bone.matrix=matrix.invert()*nodeMatrix
						data=skinData[m][1] 
						for n in range(len(data)):
							mesh.skinIndiceList[data[n][0]].append(m)
							mesh.skinWeightList[data[n][0]].append(data[n][1])
						skeleton.boneList.append(bone)
					mesh.skinList.append(skin)
					skeleton.draw()			
					mesh.BINDPOSESKELETON=skeleton.name		
			if self.versionAsNumbers in self.nifFormatListOld:
				if g.B(1)[0] == 1:
					g.word(g.i(1)[0]),g.i(1)[0] 
			if self.versionAsNumbers in self.nifFormatListNew:
				matCount=g.i(1)[0]
				for m in range(matCount):
					name=self.stringList[g.i(1)[0]]
				for m in range(matCount):
					g.i(1)
				g.i(1)
				g.B(1)	
					
					
			if self.userVersion==196608:
				if chunk not in ['medlod','lowlod','low','med']:
					#mesh.BINDSKELETON='skeleton'
					#mesh.BINDPOSE=True	
					self.meshList.append(mesh)
					#mesh.draw()		
			if self.userVersion==0:
				if chunk not in ['medlod','lowlod','low','med']:
					#mesh.BINDPOSESKELETON=skeleton.name	
					#mesh.BINDSKELETON='armature'
					#mesh.BINDPOSE=True	
					#mesh.draw()	
					self.meshList.append(mesh)	


	elif self.versionAsNumbers==(7,0,2,20):
		g=self.input
		levelID+=4
		if self.versionAsNumbers in self.nifFormatListOld:name=g.word(g.i(1)[0])
		if self.versionAsNumbers in self.nifFormatListNew:name=self.stringList[g.i(1)[0]]
		
		for n in range(g.i(1)[0]):g.i(1)
		g.i(1)[0],g.H(1)[0]
		
		if self.userVersion==12:
			g.H(1)
			
		pos = TranslationMatrix(Vector(g.f(3)))
		rot = Matrix(g.f(3),g.f(3),g.f(3)).invert().resize4x4()
		nodeMatrix= rot*pos*parentMatrix#.invert()
		
		g.f(1)[0]
		texList=None
		if self.userVersion!=12:
			for n in range(g.i(1)[0]):#properties 
				nodeID = g.i(1)[0]
				nodeType = self.nodeTypeList[self.nodeIDList[nodeID]]
				if self.debug==True:
					print '-'*levelID,nodeID,nodeType
				if nodeType == 'NiTexturingProperty':
					if self.versionAsNumbers!=(4,0,0,20):
						offset = self.getNodeOffset(nodeID)
						back=g.tell()
						g.seek(offset)
						texList=NiTexturingProperty(self,levelID)
						g.seek(back)
		g.i(1)[0]
		
		#NiTriShapeData
		shapeNodeID = g.i(1)[0]
		#print shapeNodeID
		nodeType = self.nodeTypeList[self.nodeIDList[shapeNodeID]]
		if self.versionAsNumbers!=(4,0,0,20):
			offset = self.getNodeOffset(shapeNodeID)
			back=g.tell()
			g.seek(offset)
			mesh=Mesh()
			mesh.name=name
			mesh.matrix=nodeMatrix#.invert()
			#print mesh.name
			mat=Mat()
			mat.TRIANGLE=True
			#mat.ZTRANS=True
			mesh.matList.append(mat)
			if self.debug==True:
				print '-'*levelID,shapeNodeID,nodeType
			NiTriShapeData(self,mesh,levelID)
			g.seek(back)
			chunk=name.lower().split('_')[-1]
			if texList is not None:
					#print texList
					if self.userVersion==196608:					
						texDir=g.dirname.lower().split('characters')[0]+'textures'
						if texList[0] is not None:
							texPath=texDir+os.sep+texList[0].split('.')[0]+'.nif'
							if os.path.exists(texPath)==True:
								#print texPath
								file=open(texPath,'rb')
								p=BinaryReader(file)
								p.debug=False
								nif=Nif()
								nif.debug=False
								nif.input=p
								nif.explore()
								file.close()
								mat.diffuse=texDir+os.sep+texList[0].split('.')[0]+'.dds'
					else:
						texDir=g.dirname#.lower().split('characters')[0]+'textures'
						if texList[0] is not None:
							mat.diffuse=texDir+os.sep+texList[0].split('.')[0]+'.dds'
							if os.path.exists(mat.diffuse)==False:
								mat.diffuse=texDir+os.sep+texList[0].split('.')[0]+'.tga'
						
		
			#NiSkinInstance
			skinNodeID = g.i(1)[0]
			if skinNodeID!=-1:
				if self.versionAsNumbers!=(4,0,0,20):
					offset = self.getNodeOffset(skinNodeID)
					back=g.tell()
					g.seek(offset)
					if self.debug==True:
						nodeType=self.nodeTypeList[self.nodeIDList[skinNodeID]]
						size=self.nodeSizeList[skinNodeID]
						print '-'*levelID,skinNodeID,nodeType,size
					
					
					boneNameList,skinData=NiSkinInstance(self,levelID)
					g.seek(back)
					
					skin=Skin()
					mesh.boneNameList=boneNameList
					for m in range(len(mesh.vertPosList)):
						mesh.skinIndiceList.append([])
						mesh.skinWeightList.append([])
					skeleton=Skeleton()
					skeleton.NICE=True
					skeleton.ARMATURESPACE=True
					skeleton.name=str(skinNodeID)	
					for m in range(len(skinData)):#bone list
						bone=Bone()
						matrix=skinData[m][0] 
						bone.name=boneNameList[m]
						bone.matrix=matrix.invert()*nodeMatrix
						data=skinData[m][1] 
						for n in range(len(data)):
							mesh.skinIndiceList[data[n][0]].append(m)
							mesh.skinWeightList[data[n][0]].append(data[n][1])
						skeleton.boneList.append(bone)
					mesh.skinList.append(skin)
					skeleton.draw()			
					#mesh.BINDPOSESKELETON=skeleton.name		
			if self.versionAsNumbers in self.nifFormatListOld:
				if g.B(1)[0] == 1:
					g.word(g.i(1)[0]),g.i(1)[0] 
			if self.versionAsNumbers in self.nifFormatListNew:
				matCount=g.i(1)[0]
				for m in range(matCount):
					name=self.stringList[g.i(1)[0]]
				for m in range(matCount):
					g.i(1)
				g.i(1)
				g.B(1)	
					
					
			if self.userVersion==196608:
				if chunk not in ['medlod','lowlod','low','med']:
					#mesh.BINDSKELETON='skeleton'
					#mesh.BINDPOSE=True	
					self.meshList.append(mesh)
					#mesh.draw()		
			if self.userVersion==0:
				if chunk not in ['medlod','lowlod','low','med']:
					#mesh.BINDPOSESKELETON=skeleton.name	
					#mesh.BINDSKELETON='armature'
					#mesh.BINDPOSE=True	
					#mesh.draw()	
					self.meshList.append(mesh)			
			if self.userVersion==12:
				BSPropertiesID=g.i(1)[0]#skyrim
				offset = self.getNodeOffset(BSPropertiesID)
				back=g.tell()
				g.seek(offset)
				nodeType=self.nodeTypeList[self.nodeIDList[BSPropertiesID]]
				size=self.nodeSizeList[BSPropertiesID]
				if self.debug==True:
					print '-'*levelID,BSPropertiesID,nodeType,size
				if nodeType=='BSLightingShaderProperty':
					texList=BSLightingShaderProperty(self,levelID)					
				g.seek(back)
				
				if texList is not None:					
					#texDir=g.dirname.lower().replace('meshes','textures')
					texDir=g.dirname.lower().split(os.sep+'meshes'+os.sep)[0]
					print texDir
					if os.path.exists(texDir)==True:
						if texList[0] is not None:
							search=Searcher()
							search.dir=texDir
							search.what=os.path.basename(texList[0]).lower()
							search.run()
							if len(search.list)>0:
								mat.diffuse=search.list[0]
							else:
								mat.ZTRANS=False
							#texPath=texDir+os.sep+texList[0]
							#if os.path.exists(texPath)==True:
							#	mat.diffuse=texPath
				
				
				
				if chunk not in ['medlod','lowlod','low','med']:
					#mesh.BINDPOSESKELETON=skeleton.name	
					#mesh.BINDSKELETON='armature'
					#mesh.BINDPOSE=True	
					#mesh.draw()	
					self.meshList.append(mesh)				
					
	else:
		print 'NiTriShape:',self.versionAsNumbers
		