
def NiTriShapeData(self,mesh,levelID):
	if self.versionAsNumbers==(4,0,0,20):
		g=self.input
		g.i(1)[0]
		numVertices = g.H(1)[0]
		#print 'numVertices:',numVertices
		g.B(1)[0]
		g.B(1)[0]
		hasVertices = g.B(1)[0]
		if hasVertices == 1:
			for n in range(numVertices):mesh.vertPosList.append(g.f(3))
		numUVSets,unk = g.B(2)
		#print 'numUVSets:',numUVSets,unk
		if self.userVersion==12:g.i(1)
		FlagA = g.B(1)[0]
		if FlagA == 1:
				for n in range(numVertices):g.f(3)
				if unk!=0:
					for n in range(numVertices):g.f(3)
					for n in range(numVertices):g.f(3)#normals
		g.f(4)
		FlagB = g.B(1)[0]
		if FlagB==1:
			for n in range(numVertices):
				g.f(4)
		for m in range(numUVSets):
			for n in range(numVertices):
				mesh.vertUVList.append(g.f(2))
		g.H(3)
		numTriangles = g.H(1)[0]
		#print 'numTriangles:',numTriangles,g.tell()
		g.i(1)[0] 
		hasTriangles = g.B(1)[0]#bool
		if hasTriangles == 1:
			for n in range(numTriangles):
				mesh.indiceList.extend(g.H(3))
		numMatchGroups = g.h(1)[0]
		for n in range(numMatchGroups):
			for k in range(g.h(1)[0]):g.h(1)[0]
			
	elif self.versionAsNumbers==(0,0,2,10):
		g=self.input
		g.i(1)[0]
		numVertices = g.H(1)[0]
		#print 'numVertices:',numVertices
		g.B(1)[0]
		g.B(1)[0]
		hasVertices = g.B(1)[0]
		if hasVertices == 1:
			for n in range(numVertices):mesh.vertPosList.append(g.f(3))
		numUVSets,unk = g.B(2)
		#print 'numUVSets:',numUVSets,unk
		if self.userVersion==12:g.i(1)
		FlagA = g.B(1)[0]
		if FlagA == 1:
				for n in range(numVertices):g.f(3)
				if unk!=0:
					for n in range(numVertices):g.f(3)
					for n in range(numVertices):g.f(3)#normals
		g.f(4)
		FlagB = g.B(1)[0]
		if FlagB==1:
			for n in range(numVertices):
				g.f(4)
		for m in range(numUVSets):
			for n in range(numVertices):
				mesh.vertUVList.append(g.f(2))
		g.H(1)
		numTriangles = g.H(1)[0]
		#print 'numTriangles:',numTriangles,g.tell()
		g.i(1)[0] 
		hasTriangles = g.B(1)[0]#bool
		if hasTriangles == 1:
			for n in range(numTriangles):
				mesh.indiceList.extend(g.H(3))
		numMatchGroups = g.h(1)[0]
		for n in range(numMatchGroups):
			for k in range(g.h(1)[0]):g.h(1)[0]
	elif self.versionAsNumbers==(9,0,3,20):
		if self.userVersion==196608:
			g=self.input
			g.i(1)[0]
			numVertices = g.H(1)[0]
			#print 'numVertices:',numVertices
			g.B(1)[0]
			g.B(1)[0]
			hasVertices = g.B(1)[0]
			if hasVertices == 1:
				for n in range(numVertices):mesh.vertPosList.append(g.f(3))
			numUVSets,unk = g.B(2)
			#print 'numUVSets:',numUVSets,unk
			if self.userVersion==12:g.i(1)
			FlagA = g.B(1)[0]
			if FlagA == 1:
					for n in range(numVertices):g.f(3)
					if unk!=0:
						for n in range(numVertices):g.f(3)
						for n in range(numVertices):g.f(3)#normals
			FlagB = g.B(1)[0]
			if FlagB==1:
				for n in range(numVertices):
					g.f(1)
			g.f(10)
			g.B(2),g.tell()
			FlagC = g.B(1)[0]
			if FlagC==1:
				for n in range(numVertices):
					g.f(4)
			for m in range(numUVSets):
				for n in range(numVertices):
					mesh.vertUVList.append(g.f(2))
			g.H(3)
			numTriangles = g.H(1)[0]
			#print 'numTriangles:',numTriangles,g.tell()
			g.i(1)[0] 
			hasTriangles = g.B(1)[0]#bool
			if hasTriangles == 1:
				for n in range(numTriangles):
					mesh.indiceList.extend(g.H(3))
			numMatchGroups = g.h(1)[0]
			for n in range(numMatchGroups):
				for k in range(g.h(1)[0]):g.h(1)[0]
		else:
			g=self.input
			g.i(1)[0]
			numVertices = g.H(1)[0]
			#print 'numVertices:',numVertices
			g.B(1)[0]
			g.B(1)[0]
			hasVertices = g.B(1)[0]
			if hasVertices == 1:
				for n in range(numVertices):mesh.vertPosList.append(g.f(3))
			numUVSets,unk = g.B(2)
			#print 'numUVSets:',numUVSets,unk
			if self.userVersion==12:g.i(1)
			FlagA = g.B(1)[0]
			if FlagA == 1:
					for n in range(numVertices):g.f(3)
					if unk!=0:
						for n in range(numVertices):g.f(3)
						for n in range(numVertices):g.f(3)#normals
			g.f(4)
			FlagB = g.B(1)[0]
			if FlagB==1:
				for n in range(numVertices):
					g.f(4)
			for m in range(numUVSets):
				for n in range(numVertices):
					mesh.vertUVList.append(g.f(2))
			g.H(3)
			numTriangles = g.H(1)[0]
			#print 'numTriangles:',numTriangles,g.tell()
			g.i(1)[0] 
			hasTriangles = g.B(1)[0]#bool
			if hasTriangles == 1:
				for n in range(numTriangles):
					mesh.indiceList.extend(g.H(3))
			numMatchGroups = g.h(1)[0]
			for n in range(numMatchGroups):
				for k in range(g.h(1)[0]):g.h(1)[0]		
			
	elif self.versionAsNumbers==(103,95,97,115):
		g=self.input
		g.i(1)[0]
		numVertices = g.H(1)[0]
		#print 'numVertices:',numVertices
		g.B(1)[0]
		g.B(1)[0]
		hasVertices = g.B(1)[0]
		if hasVertices == 1:
			for n in range(numVertices):mesh.vertPosList.append(g.f(3))
		numUVSets,unk = g.B(2)
		if self.userVersion==12:g.i(1)
		FlagA = g.B(1)[0]
		if FlagA == 1:
			if numUVSets==1:
				for n in range(numVertices):g.f(3)
			else:
				for n in range(numVertices):g.f(3)
		g.f(4)
		FlagB = g.B(1)[0]
		if FlagB==1:
			for n in range(numVertices):
				g.f(4)
		for m in range(numUVSets):
			for n in range(numVertices):
				mesh.vertUVList.append(g.f(2))
		g.H(3)
		numTriangles = g.H(1)[0]
		#print 'numTriangles:',numTriangles,g.tell()
		g.i(1)[0] 
		hasTriangles = g.B(1)[0]#bool
		if hasTriangles == 1:
			for n in range(numTriangles):
				mesh.indiceList.extend(g.H(3))
		numMatchGroups = g.h(1)[0]
		for n in range(numMatchGroups):
			for k in range(g.h(1)[0]):g.h(1)[0]
			
	elif self.versionAsNumbers==(8,0,2,20):
		g=self.input
		g.i(1)[0]
		numVertices = g.H(1)[0]
		#print 'numVertices:',numVertices
		g.B(1)[0]
		g.B(1)[0]
		hasVertices = g.B(1)[0]
		if hasVertices == 1:
			for n in range(numVertices):mesh.vertPosList.append(g.f(3))
		numUVSets,unk = g.B(2)
		if self.userVersion==12:g.i(1)
		FlagA = g.B(1)[0]
		if FlagA == 1:
			if numUVSets==1:
				for n in range(numVertices):g.f(3)
			else:
				for n in range(numVertices):g.f(3)
		g.f(4)
		FlagB = g.B(1)[0]
		if FlagB==1:
			for n in range(numVertices):
				g.f(4)
		for m in range(numUVSets):
			for n in range(numVertices):
				mesh.vertUVList.append(g.f(2))
		g.H(3)
		numTriangles = g.H(1)[0]
		#print 'numTriangles:',numTriangles,g.tell()
		g.i(1)[0] 
		hasTriangles = g.B(1)[0]#bool
		if hasTriangles == 1:
			for n in range(numTriangles):
				mesh.indiceList.extend(g.H(3))
		numMatchGroups = g.h(1)[0]
		for n in range(numMatchGroups):
			for k in range(g.h(1)[0]):g.h(1)[0]
			
			
	elif self.versionAsNumbers==(7,0,2,20):
			g=self.input
			g.i(1)[0]
			numVertices = g.H(1)[0]
			#print 'numVertices:',numVertices
			g.B(1)[0]
			g.B(1)[0]
			hasVertices = g.B(1)[0]
			if hasVertices == 1:
				for n in range(numVertices):mesh.vertPosList.append(g.f(3))
			numUVSets,unk = g.B(2)
			#print 'numUVSets:',numUVSets,unk
			if self.userVersion==12:g.i(1)
			FlagA = g.B(1)[0]
			if FlagA == 1:
					for n in range(numVertices):g.f(3)
					if unk!=0:
						for n in range(numVertices):g.f(3)
						for n in range(numVertices):g.f(3)#normals
			g.f(4)
			FlagB = g.B(1)[0]
			if FlagB==1:
				for n in range(numVertices):
					g.f(4)
			for m in range(numUVSets):
				for n in range(numVertices):
					mesh.vertUVList.append(g.f(2))
			g.H(3)
			numTriangles = g.H(1)[0]
			#print 'numTriangles:',numTriangles,g.tell()
			g.i(1)[0] 
			hasTriangles = g.B(1)[0]#bool
			if hasTriangles == 1:
				for n in range(numTriangles):
					mesh.indiceList.extend(g.H(3))
			numMatchGroups = g.h(1)[0]
			for n in range(numMatchGroups):
				for k in range(g.h(1)[0]):g.h(1)[0]		
			
			
	else:
		print 'NiTriShapeData:',self.versionAsNumbers,'not supported'