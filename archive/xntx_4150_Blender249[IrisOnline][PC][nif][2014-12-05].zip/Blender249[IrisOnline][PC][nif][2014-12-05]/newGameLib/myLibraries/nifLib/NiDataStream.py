

def componentDict(item,g):
	if item==66069:return g.H(1)[0]
	elif item==262408:return g.B(4)
	elif item==262416:return g.B(4)
	elif item==132150:return g.f(2)
	elif item==197687:return g.f(3)
	elif item==66597:return g.i(1)[0]
	elif item==263224:return g.f(4)
	elif item==262676:return g.f(2)
	else:print item

def NiDataStream(self):
	regionList=[]
	if self.versionAsNumbers==(3,0,1,30):
		g=self.input
		bytesCount=g.i(1)[0]
		g.i(1)[0]
		regionCount=g.i(1)[0]
		regionInfoList=[]
		for m in range(regionCount):
			IDStart=g.i(1)[0]
			IDCount=g.i(1)[0]
			regionInfoList.append([IDStart,IDCount])
		componentCount=g.i(1)[0]
		componentList=g.i(componentCount)
					
		regionList=[]
		for k in range(regionCount):		
			IDStart=regionInfoList[k][0]
			IDCount=regionInfoList[k][1]
			region=[]
			for m in range(componentCount):
				region.append([])
			for m in range(IDCount):
				for i,component in enumerate(componentList): 
					stream=region[i]
					stream.append(componentDict(component,g))
				
			regionList.append(region)		
	
	
	
	else:
		g=self.input
		bytesCount=g.i(1)[0]
		g.i(1)[0]
		regionCount=g.i(1)[0]
		regionInfoList=[]
		for m in range(regionCount):
			IDStart=g.i(1)[0]
			IDCount=g.i(1)[0]
			regionInfoList.append([IDStart,IDCount])
		componentCount=g.i(1)[0]
		componentList=g.i(componentCount)
		print 'componentList:',componentList
					
		regionList=[]
		for k in range(regionCount):		
			IDStart=regionInfoList[k][0]
			IDCount=regionInfoList[k][1]
			region=[]
			for m in range(componentCount):
				region.append([])
			for m in range(IDCount):
				for i,component in enumerate(componentList): 
					stream=region[i]
					stream.append(componentDict(component,g))
				
			regionList.append(region)		
						
				
	return regionList	