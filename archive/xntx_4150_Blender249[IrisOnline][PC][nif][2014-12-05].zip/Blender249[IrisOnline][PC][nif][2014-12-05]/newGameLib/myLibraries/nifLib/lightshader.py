
def lightshader(m):
	i(4),H(1),i(2),H(1),i(1),f(1),i(1)
	texture_id =  i(1)[0] 
	offset = go_to_node(texture_id)
	texture_set(offset,m)   
