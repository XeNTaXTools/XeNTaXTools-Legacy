 
def NiTransformInterpolator(self):
	g=self.input
	g.f(3),g.f(4),g.f(1)[0],g.i(1)[0]   