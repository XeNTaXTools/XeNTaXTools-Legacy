
def NiCamera(self):
	g=self.input
	if self.versionAsNumbers in self.nifFormatListOld:
		name=g.word(g.i(1)[0])
	if self.versionAsNumbers in self.nifFormatListNew:
		name=self.stringList[g.i(1)[0]]
	g.i(g.i(1)[0])
	g.i(1)[0]
	g.H(1)[0]
	g.f(3)
	g.f(9)
	g.f(1)
	g.i(g.i(1)[0])
	g.i(1)
	g.h(1)
	g.f(6)
	g.b(1)
	g.f(5)
	g.i(3)
	
	
	