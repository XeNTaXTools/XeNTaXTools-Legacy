
def NiSkinPartition(self):
	g=self.input
	for n in range(g.i(1)[0]):
		var = g.H(5)
		for k in range(var[2]):#bones
			g.H(1)[0]
		if g.B(1)[0]>0:#vertex map
			for p in range(var[0]):
				g.H(1)[0]
		if g.B(1)[0]>0:#vertex weight
			for p in range(var[0]):
				g.f(var[4])
		strips = []
		for p in range(var[3]):
			strips.append(g.H(1)[0])
		if g.B(1)[0]>0:#has faces
			if var[3]!=0:
				for p in range(var[3]):
					g.H(strips[p])
			if var[3]==0:
				for p in range(var[1]):
					g.H(3)
		if g.B(1)[0]>0:
			for p in range(var[0]):
				g.B(var[4])