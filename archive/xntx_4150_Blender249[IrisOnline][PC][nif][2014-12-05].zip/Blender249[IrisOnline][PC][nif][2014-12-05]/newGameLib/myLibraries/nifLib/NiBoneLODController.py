def NiBoneLODController(self):
	g=self.input
	g.i(1),g.H(1)[0]  
	g.f(4)
	g.i(1)
	g.i(2)
	for n in range(g.i(1)[0]):
		for k in range(g.i(1)[0]):
			g.i(1)[0]
	for n in range(g.i(1)[0]):
		for k in range(g.i(1)[0]):
			g.i(2)
	g.i(g.i(1)[0])		
