#
from newGameLib.myLibraries.imageLib import *

def NiPersistentSrcTextureRendererDataNode(self):
	g=self.input
	u=g.B(19)
	w=g.i(11)
	mipCount=g.i(1)[0]
	g.i(1)
	mipList=[]
	for i in range(mipCount):
		mipList.append(g.i(3))
	g.i(4)	
	image=Image()
	image.name=g.dirname+os.sep+g.basename+'.dds'
	image.szer=mipList[0][0]
	image.wys=mipList[0][1]	
	if u[0]==4:image.format='DXT1'
	if u[0]==5:image.format='DXT3'
	if u[0]==6:image.format='DXT5'
	#g.seek(1072)
	image.data=g.read(mipList[1][2]-mipList[0][2])
	image.draw()
	
	