
def shader(offset,id,m):
		back = plik.tell()
		node_type = NodeTypes[nodeID_list[id]]
		plik.seek(offset)
		if node_type == 'BSLightingShaderProperty':
			lightshader(m)
		if node_type == 'BSEffectShaderProperty':
			try:effectshader() 
			except:pass
		plik.seek(back)
