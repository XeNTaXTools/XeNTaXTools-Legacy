
	
from newGameLib.myLibraries.imageLib import *

def NiPixelData(self,levelID):
	g=self.input
	image=None
	levelID+=4
	g=self.input
	pixelFormat = g.i(1)[0]
	texel=None 
	bitPerPixel=g.B(1)[0]
	g.i(2)
	g.B(1)
	g.i(1)
	if self.versionAsNumbers==(0,0,6,20):
		g.B(1)####################################dla ragnaroka ,iris online
	g.B(10*4)
	g.i(1)
	mipmapsCount=g.i(1)[0]
	bytesPerPixel=g.i(1)[0]
	mipmapsList=[]
	for m in range(mipmapsCount):
		width=g.i(1)[0]
		height=g.i(1)[0]
		offset=g.i(1)[0]
		mipmapsList.append([width,height,offset])
		print m,'mipmap:',width,height,offset
	pixelCount=g.i(1)[0]
	print 'bytesPerPixel:',bytesPerPixel
	print 'pixelFormat:',pixelFormat
	if bytesPerPixel==2:
		if pixelFormat==4:texel='DXT1'
		elif pixelFormat==5:texel='DXT3'
		elif pixelFormat==6:texel='DXT5'
		elif pixelFormat==1:texel='1555to8888'
		elif pixelFormat==0:texel='565to888'
		else:print 'unknow format',pixelFormat
		
	if bytesPerPixel==3:
		if pixelFormat==4:texel='DXT1'
		elif pixelFormat==5:texel='DXT3'
		elif pixelFormat==6:texel='DXT5'
		elif pixelFormat==1:texel='tga32'
		elif pixelFormat==0:texel='tga24'
		else:print 'unknow format',pixelFormat
		
	if bytesPerPixel==4:
		if pixelFormat==4:texel='DXT1'
		elif pixelFormat==5:texel='DXT3'
		elif pixelFormat==6:texel='DXT5'
		elif pixelFormat==1:texel='tga32'
		elif pixelFormat==0:texel='tga24'
		else:print 'unknow format',pixelFormat
	
	facesCount=g.i(1)[0] 
	print 'texel:',texel
	if self.PARSINGFLAG==False:
		offset=g.tell()
		g.seek(offset+mipmapsList[0][2])
		image=Image()
		if len(mipmapsList)>1:
			image.data=g.read(mipmapsList[1][2])
		else:	
			image.data=g.read(g.fileSize()-g.tell())
		image.szer=mipmapsList[0][0]
		image.wys=mipmapsList[0][1]
		image.format=texel
	g.seek(pixelCount,1)
	
	return image