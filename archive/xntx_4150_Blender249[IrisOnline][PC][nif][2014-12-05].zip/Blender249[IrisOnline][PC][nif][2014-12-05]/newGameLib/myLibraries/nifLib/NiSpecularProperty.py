
def NiSpecularProperty(self):
	g=self.input
	id=g.i(1)[0]
	if id!=-1:
		if self.versionAsNumbers in self.nifFormatListOld:
			name=g.word(id)
		if self.versionAsNumbers in self.nifFormatListNew:
			name=self.stringList[id]
	else:
		name=None
	g.i(g.i(1)[0])
	g.i(1)[0]
	g.H(1)[0]