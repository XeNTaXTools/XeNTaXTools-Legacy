
from Blender.Mathutils import *

import NiTriStripsData
reload(NiTriStripsData)
from NiTriStripsData import *

from newGameLib.myLibraries.meshLib import *

def NiTriStrips(self,levelID,parentMatrix):
	g=self.input
	if self.versionAsNumbers in self.nifFormatListOld:
		name=g.word(g.i(1)[0])
	if self.versionAsNumbers in self.nifFormatListNew:
		name=self.stringList[g.i(1)[0]]
		
	numExtraDataList = g.i(1)[0]
	for n in range(numExtraDataList):g.i(1)
	g.i(1)[0]
	flag=g.H(1)[0]	  
	#if version==(10,7,0,2,20):h(1)
	pos = TranslationMatrix(Vector(g.f(3)))
	rot = Matrix(g.f(3),g.f(3),g.f(3)).invert().resize4x4()
	matrix = rot*pos*parentMatrix
	g.f(1)[0]#scale
	for n in range(g.i(1)[0]):#properties 
		ni_id = g.i(1)[0]
		"""node_type = NodeTypes[nodeID_list[ni_id]]
		print node_type,ni_id
		if node_type == 'NiTexturingProperty':
			offset = go_to_node(ni_id)
			nitexturingproperty(offset,m)  
		if node_type == 'BSShaderPPLightingProperty':
			offset = go_to_node(ni_id)
			BSShaderPPLightingProperty(offset,m)"""
	g.i(1)[0]   
	dataID = g.i(1)[0] 
	offset=self.getNodeOffset(dataID)
	back=g.tell()
	g.seek(offset)
	#if flag in [14,22]:
	mesh=Mesh()
	NiTriStripsData(self,levelID,mesh)
	mesh.draw()
	g.seek(back)	
	SkinInstance = g.i(1)[0]
	matCount=g.i(1)[0]
	for m in range(matCount):
		#name
		#extra data
		pass
	#if B(1)[0] == 1:
	#   print word(i(1)[0]),i(1)[0]
	#nodesdata[str(m)]['children_count'] = 0
	#nodesdata[str(m)]['children'] = []
	#nodesdata[str(m)]['matrix'] = matrix
	print g.i(1)[0]
	g.B(1)[0]
