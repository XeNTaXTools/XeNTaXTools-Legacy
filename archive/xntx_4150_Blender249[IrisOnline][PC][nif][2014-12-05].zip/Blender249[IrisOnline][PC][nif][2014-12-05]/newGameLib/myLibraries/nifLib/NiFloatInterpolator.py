

def NiFloatInterpolator(self): 
	g=self.input
	g.f(1)
	g.i(1)