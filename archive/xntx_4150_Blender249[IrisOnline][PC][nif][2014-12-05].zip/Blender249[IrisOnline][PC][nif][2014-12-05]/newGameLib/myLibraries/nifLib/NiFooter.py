
from Blender.Mathutils import *


import NiNode
reload(NiNode)
from NiNode import *

import NiPersistentSrcTextureRendererDataNode
reload(NiPersistentSrcTextureRendererDataNode)
from NiPersistentSrcTextureRendererDataNode import *

import CModelTemplateDataEntry
reload(CModelTemplateDataEntry)
from CModelTemplateDataEntry import *

import NiControllerSequence
reload(NiControllerSequence)
from NiControllerSequence import *

from newGameLib.myLibraries.skeletonLib import *

def NiFooter(self): 
	if self.debug==True:
		print 'NiFooter'
	g=self.input
	#g.logOpen()
	rootCount=g.i(1)[0]
	levelID=0
	self.skeleton=Skeleton()
	#self.skeleton.name=self.input.basename
	self.skeleton.ARMATURESPACE=True
	self.skeleton.NICE=True
	self.PARSINGFLAG=False
	for m in range(rootCount):
		ID=g.i(1)[0]
		nodeType = self.nodeTypeList[self.nodeIDList[ID]]
		offset=self.getNodeOffset(ID)
		size=self.nodeSizeList[ID]
		if self.debug==True:
			print '='*levelID,ID,nodeType,size
		back=g.tell()
		g.seek(offset)
		if nodeType=='NiNode':NiNode(self,levelID,'',Matrix().invert())
		if nodeType=='NiPersistentSrcTextureRendererData':NiPersistentSrcTextureRendererDataNode(self)
		if nodeType=='MdlMan::CModelTemplateDataEntry':CModelTemplateDataEntry(self,levelID)
		if nodeType=='NiControllerSequence':NiControllerSequence(self,levelID)
		if nodeType=='BSFadeNode':NiNode(self,levelID,'',Matrix())
		if nodeType=='NiPixelData':#Iris Online
			image=NiPixelData(self,levelID)
			self.imageList.append(image)
		g.seek(back)
	#self.skeleton.draw()	
	