def NiTransformData(self):
	g=self.input
	rotkeys=g.i(1)[0]
	if rotkeys>0:
		type=g.i(1)[0]
		if type==1:
			for n in range(rotkeys):
				g.f(5)				
		if type==4:
			for k in range(3):
				rotkeys=g.i(1)[0]
				type=g.i(1)[0]
				if type==2:
					for n in range(rotkeys):
						g.f(4)	
	poskeys=g.i(1)[0]
	if poskeys>0:
		type=g.i(1)[0]
		if type==1:
			for n in range(poskeys):
				g.f(4)		
	scalekeys=g.i(1)[0]
	if scalekeys>0:
		type=g.i(1)[0]
		if type==2:
			for n in range(scalekeys):
				g.f(4)
