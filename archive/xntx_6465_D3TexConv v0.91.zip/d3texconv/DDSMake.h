/*
    Copyright notice: This code is copyright Necrolis 2011
    it was created usign the DDS specs take from MSDN
*/

#ifndef H__DDSMAKE__H
#define H__DDSMAKE__H

#ifndef MAKEFOURCC
    #define MAKEFOURCC(ch0, ch1, ch2, ch3)                              \
                ((uint32_t)(uint8_t)(ch0) | ((uint32_t)(uint8_t)(ch1) << 8) |       \
                ((uint32_t)(uint8_t)(ch2) << 16) | ((uint32_t)(uint8_t)(ch3) << 24 ))
#endif /* defined(MAKEFOURCC) */

//Structures from MSDN

struct DDS_PIXELFORMAT
{
    uint32_t dwSize;
    uint32_t dwFlags;
    uint32_t dwFourCC;
    uint32_t dwRGBBitCount;
    uint32_t dwRBitMask;
    uint32_t dwGBitMask;
    uint32_t dwBBitMask;
    uint32_t dwABitMask;
};

struct DDS_HEADER
{
    uint32_t                dwSize;
    uint32_t                dwFlags;
    uint32_t                dwHeight;
    uint32_t                dwWidth;
    uint32_t                dwPitchOrLinearSize;
    uint32_t                dwDepth;
    uint32_t                dwMipMapCount;
    uint32_t                dwReserved1[11];
    struct DDS_PIXELFORMAT  ddspf;
    uint32_t                dwCaps;
    uint32_t                dwCaps2;
    uint32_t                dwCaps3;
    uint32_t                dwCaps4;
    uint32_t                dwReserved2;
};

struct DDS_FILE
{
    uint32_t dwMagic;
    struct DDS_HEADER pHeader;
};

enum DDS_DATA
{
    DDS_MAGIC               = 0x20534444,

    DDSD_CAPS               = 0x1,
    DDSD_HEIGHT	            = 0x2,
    DDSD_WIDTH              = 0x4,
    DDSD_PITCH              = 0x8,
    DDSD_PIXELFORMAT        = 0x1000,
    DDSD_MIPMAPCOUNT        = 0x20000,
    DDSD_LINEARSIZE         = 0x80000,
    DDSD_DEPTH              = 0x800000,

    DDSD_REQUIRED = DDSD_CAPS|DDSD_HEIGHT|DDSD_WIDTH|DDSD_PIXELFORMAT,

    DDSCAPS_UNCOMPRESSED    = 0x2,
    DDSCAPS_COMPLEX         = 0x8,
    DDSCAPS_MIPMAP          = 0x400000,
    DDSCAPS_TEXTURE         = 0x1000,

    DDSCAPS2_CUBEMAP            = 0x200,
    DDSCAPS2_CUBEMAP_POSITIVEX  = 0x400,
    DDSCAPS2_CUBEMAP_NEGATIVEX  = 0x800,
    DDSCAPS2_CUBEMAP_POSITIVEY  = 0x1000,
    DDSCAPS2_CUBEMAP_NEGATIVEY  = 0x2000,
    DDSCAPS2_CUBEMAP_POSITIVEZ  = 0x4000,
    DDSCAPS2_CUBEMAP_NEGATIVEZ  = 0x8000,
    DDSCAPS2_VOLUME             = 0x200000,

    DDPF_ALPHAPIXELS        = 0x1,
    DDPF_ALPHA              = 0x2,
    DDPF_FOURCC             = 0x4,
    DDPF_RGB                = 0x40,
    DDPF_YUV                = 0x200,
    DDPF_LUMINANCE          = 0x20000,
    DDPF_ARGB               = (DDPF_ALPHAPIXELS|DDPF_RGB),
};

int DDS_FillFormat(struct DDS_PIXELFORMAT* pFormat, struct DDS_HEADER* pHeader, uint32_t dwD3DFormat);
int DDS_CreateFile(const char* szName, uint8_t* pPixelData, size_t nPixelDataSize, size_t nWidth, size_t nHeight, uint32_t dwD3DFormat, size_t nMipLevels, size_t nStride);

#endif
