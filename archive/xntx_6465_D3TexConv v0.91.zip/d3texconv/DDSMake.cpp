/*
    Copyright notice: This code is copyright Necrolis 2011
    it was created usign the DDS specs take from MSDN
*/

#define _CRT_SECURE_NO_DEPRECATE

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <stdint.h>
#include <stddef.h>
#include "DDSMake.h"

int DDS_FillFormat(struct DDS_PIXELFORMAT* pFormat, struct DDS_HEADER* pHeader, uint32_t dwD3DFormat)
{
    switch(dwD3DFormat)
    {
        case MAKEFOURCC('D', 'X', 'T', '1'):
        {
            pFormat->dwFlags = DDPF_FOURCC;
            pFormat->dwFourCC = MAKEFOURCC('D', 'X', 'T', '1');
            break;
        }

        case MAKEFOURCC('D', 'X', 'T', '3'):
        {
            pFormat->dwFlags = DDPF_FOURCC;
            pFormat->dwFourCC = MAKEFOURCC('D', 'X', 'T', '3');
            break;
        }

        case MAKEFOURCC('D', 'X', 'T', '5'):
        {
            pFormat->dwFlags = DDPF_FOURCC;
            pFormat->dwFourCC = MAKEFOURCC('D', 'X', 'T', '5');
            break;
        }

        case 21:  //D3DFMT_A8R8G8B8
        {
            pFormat->dwFlags = DDPF_ARGB;
            pFormat->dwRGBBitCount = 32;
            pFormat->dwABitMask = 0xFF000000;
            pFormat->dwRBitMask = 0xFF0000;
            pFormat->dwGBitMask = 0xFF00;
            pFormat->dwBBitMask = 0xFF;
            pHeader->dwCaps |= DDSCAPS_UNCOMPRESSED;
            break;
        }

        case 25:  //D3DFMT_A1R5G5B5
        {
            pFormat->dwFlags = DDPF_ARGB;
            pFormat->dwRGBBitCount = 16;
            pFormat->dwABitMask = 0x8000;
            pFormat->dwRBitMask = 0x7C00;
            pFormat->dwGBitMask = 0x3E0;
            pFormat->dwBBitMask = 0x1F;
            pHeader->dwCaps |= DDSCAPS_UNCOMPRESSED;
            break;
        }

        case 50:  //D3DFMT_L8
        {
            pFormat->dwFlags = DDPF_LUMINANCE;
            pFormat->dwRGBBitCount = 8;
            pFormat->dwRBitMask = 0xFF;
            pHeader->dwCaps |= DDSCAPS_UNCOMPRESSED;
            break;
        }

        default:
        {
            printf("No conversion for format: %u\n",dwD3DFormat);
            return 0;
        }
    }

    return 1;
}

int DDS_CreateFile(const char* szName, uint8_t* pPixelData, size_t nPixelDataSize, size_t nWidth, size_t nHeight, uint32_t dwD3DFormat, size_t nMipLevels, size_t nStride)
{
    if(nWidth == 0 || nHeight == 0 || pPixelData == NULL)
        return 0;

    struct DDS_HEADER pHeader = {0};
    pHeader.dwSize = 124;
    pHeader.dwWidth = nWidth;
    pHeader.dwHeight = nHeight;
    pHeader.dwFlags = DDSD_REQUIRED | (nMipLevels > 1 ? DDSD_MIPMAPCOUNT : 0);
    if(nMipLevels > 1)
        pHeader.dwMipMapCount = nMipLevels;

    pHeader.dwHeight = nHeight;
    pHeader.dwCaps = DDSCAPS_TEXTURE | (nMipLevels > 1 ? DDSCAPS_MIPMAP|DDSCAPS_COMPLEX : 0);
    struct DDS_PIXELFORMAT* pFormat = &pHeader.ddspf;
    pFormat->dwSize = 32;
    if(!DDS_FillFormat(pFormat,&pHeader,dwD3DFormat))
        return 0;

    char szBuffer[512];
    sprintf(szBuffer,"%s.dds",szName);
    FILE* pFile = fopen(szBuffer,"wb+");
    if(pFile == NULL)
        return 0;

    uint32_t dwMagic = DDS_MAGIC;
    fwrite(&dwMagic,sizeof(uint32_t),1,pFile);
    fwrite(&pHeader,sizeof(pHeader),1,pFile);
    fwrite(pPixelData,sizeof(uint8_t),nPixelDataSize,pFile);
    fclose(pFile);
    return 1;
}
