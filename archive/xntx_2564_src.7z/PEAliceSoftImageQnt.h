/*
	This file is part of PropExtractor.

	PropExtractor is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	PropExtractor is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with PropExtractor. If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef _PEALICESOFTIMAGEQNT_H_
#define _PEALICESOFTIMAGEQNT_H_

#include "PEFile.h"
#include "PEImage.h"

namespace pe
{

	struct AliceImageQntHeaderV0
	{
		dword unknown1;
		dword unknown2;
		dword width;
		dword height;
		dword bpp;
		dword unknown3;
		dword pixel_size;
		dword unknown4[3];
	};

	struct AliceImageQntHeaderV1
	{
		dword header_size;
		dword originx;
		dword originy;
		dword width;
		dword height;
		dword bpp;
		dword rsv;
		dword pixel_size;
		dword unknown1[3];
	};

	struct AliceImageQntHeaderV2
	{
		dword header_size;
		dword originx;
		dword originy;
		dword width;
		dword height;
		dword bpp;
		dword rsv;
		dword pixel_size;
		dword alpha_size;
		byte something1[24];
	};

	struct AliceImageQntHeader
	{
		byte header[4];
		dword rsv0;
	};

	struct AliceImageQnt
	{
		AliceImageQntHeader* header;
		AliceImageQntHeaderV0* header_v0;
		AliceImageQntHeaderV1* header_v1;
		AliceImageQntHeaderV2* header_v2;

		byte* pixels;
		unsigned int data_size;

		byte* alpha;
		unsigned int alpha_data_size;

		unsigned int width, height;
		byte bpp;
		dword pixel_size;
		dword alpha_size;
	};

	PE_EXPORT int AliceImageQntReadHeader(AliceImageQntHeader* a_Header, PEStream* a_Stream);
	PE_EXPORT int AliceImageQntReadData(AliceImageQnt* a_Target, AliceImageQntHeader* a_Header, PEStream* a_Stream);
	PE_EXPORT int AliceImageQntToRaw(PEImageRaw* a_Target, AliceImageQnt* a_Image);

	PE_EXPORT int AliceImageQntReadAndDecrypt(PEImageRaw* a_Target, PEStream* a_Stream);
	PE_EXPORT int AliceImageQntReadPathAndDecrypt(PEImageRaw* a_Target, const wchar_t* a_Path);
	PE_EXPORT int AliceImageQntDecryptAndSave(const wchar_t* a_Path);

	PE_EXPORT int AliceImageQntDeleteHeader(AliceImageQntHeader* a_Header);
	PE_EXPORT int AliceImageQntDeleteData(AliceImageQnt* a_Image);

}; // namespace pe

#endif