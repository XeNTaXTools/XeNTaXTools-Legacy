#include <string>
#include <vector>
#include <iostream>
#include <fstream>
//#include <stdint.h>
#include <memory.h>
#include "WaveWriter.h"
#include <stdlib.h>

struct SWaveSoundInfo
{
    std::string Filename;
    std::string FilenameWithPath;
    std::streamoff Offset;
    bool AbsoluteOffset;
    std::streamsize Size;
    unsigned int SampleCount;
    int BitsPerSample;
    int SampleRate;
    int Channels;
};

struct SWaveHeader
{
    uint8_t RiffSig[4];        // 'RIFF'
    uint32_t WaveformChunkSize; // DataSize+110
    uint8_t WaveSig[4];        // 'WAVE'
    uint8_t FormatSig[4];      // 'fmt '
    uint32_t FormatChunkSize;   // 16
    uint16_t FormatTag;        // WAVE_FORMAT_PCM
    uint16_t Channels;         // 1=mono 2=stereo
    uint32_t SampleRate;        // Sample Rate
    uint32_t BytesPerSec;       // Bytes per second (See)
    uint16_t BlockAlign;       // sample block alignment
    uint16_t BitsPerSample;    // bits per sample
    uint8_t DataSig[4];        // 'data'
    uint32_t DataSize;          // Data size
};

struct SFatEntry
{
    std::streamoff Offset;
    std::streamsize Size;
    std::string Filename;
    std::string NameOnly;
};

enum EAction
{
    ACTION_EXTRACT,
    ACTION_REPACK
};

std::string GlobalsAreEvilDoNotUseThem;

void OutputFile(std::istream& Input, const SWaveSoundInfo& Info)
{
    std::ofstream OutWave;
    OutWave.open(Info.FilenameWithPath.c_str(), std::ios_base::out | std::ios_base::binary);
    if (!OutWave.is_open())
    {
        std::cout << "Unable to create wave file '" << Info.FilenameWithPath << "'." << std::endl;
        return;
    }

    PrepareWaveHeader(OutWave);

    // Write the data to the wave
    char Buffer[65536];
    int BytesLeft = Info.Size;
    Input.seekg(Info.Offset);

    while (BytesLeft && !Input.eof())
    {
        if (BytesLeft > sizeof(Buffer))
        {
            Input.read(Buffer, sizeof(Buffer));
            OutWave.write(Buffer, Input.gcount());
            BytesLeft -= Input.gcount();
        }
        else
        {
            Input.read(Buffer, BytesLeft);
            OutWave.write(Buffer, Input.gcount());
            BytesLeft -= Input.gcount();
            break;
        }
    }

    OutWave.seekp(0);

    WriteWaveHeader(OutWave, Info.SampleRate, Info.BitsPerSample, \
                    Info.Channels, Info.Size * 8 / Info.BitsPerSample);

    OutWave.close();
    return;
}

void DecUbiSndFile(std::istream& Input, const SWaveSoundInfo& Info)
{
    char Buffer[1024];
    _snprintf(Buffer, sizeof(Buffer), ".\\DecUbiSnd.exe \"%s\" -i %lu -s %lu -w --sample-rate %u -o \"%s\"", \
        GlobalsAreEvilDoNotUseThem.c_str(), Info.Offset, Info.Size, Info.SampleRate, Info.FilenameWithPath.c_str());
    system(Buffer);
    return;
}

void EncUbiSndFile(const std::string& TempFile, const std::string& InputFile)
{
    char Buffer[1024];
    _snprintf(Buffer, sizeof(Buffer), ".\\EncUbiSnd.exe \"%s\" -o \"%s\"", \
        InputFile.c_str(), TempFile.c_str());
    system(Buffer);
    return;
}

struct STempFile
{
    ~STempFile()
    {
        if (!Filename.empty())
        {
            remove(Filename.c_str());
        }
    }
    std::string Filename;
};

void RepackFile(std::iostream& Output, const SWaveSoundInfo& Info)
{
    STempFile TempFile;
    std::ifstream WaveInput;
    WaveInput.open(Info.FilenameWithPath.c_str(), std::ios_base::in | std::ios_base::binary);
    if (!WaveInput.is_open())
    {
        std::cout << ">   Will not repack " << Info.Filename << std::endl;
        return;
    }

    // Read the wave file.
    SWaveHeader Header;
    
    if (Info.AbsoluteOffset)
    {
        TempFile.Filename = ".temp~";
        WaveInput.close();
        EncUbiSndFile(TempFile.Filename, Info.FilenameWithPath);
        WaveInput.clear();
        WaveInput.open(TempFile.Filename.c_str(), std::ios_base::in | std::ios_base::binary);
        if (!WaveInput.is_open())
        {
            std::cerr << "EncUbiSnd failed." << std::endl;
            return;
        }

        memset(&Header, 0, sizeof(Header));

        WaveInput.seekg(0, std::ios_base::end);
        Header.DataSize = WaveInput.tellg();
        WaveInput.seekg(0);
        Header.Channels = Info.Channels;
        Header.SampleRate = Info.SampleRate;
        Header.BitsPerSample = 4;
    }
    else
    {
        // Read the wave file.
        WaveInput.read((char*)&Header, sizeof(SWaveHeader));

        if (memcmp(Header.RiffSig, "RIFF", 4) == 0 && memcmp(Header.WaveSig, "WAVE", 4) == 0 && \
            memcmp(Header.FormatSig, "fmt ", 4) == 0 && memcmp(Header.DataSig, "data", 4) == 0 && \
            Header.FormatTag == 1 && Header.BitsPerSample == Header.BitsPerSample && (Header.Channels == 1 || \
                        Header.Channels == 2))
        {
            //Channels=(unsigned char)Header.Channels;
            //SampleCount=Header.DataSize/2;
            //SampleRate=Header.SampleRate;
        }
        else
        {
            std::cerr << ">   Can't repack " << Info.FilenameWithPath << " because it is not in the correct format." << std::endl;
            return;
        }
    }

    if (Info.Size < Header.DataSize)
    {
        std::cerr << ">   Can't repack " << Info.FilenameWithPath << " because the size doesn't match." << std::endl;
        std::cerr << "        This one is " << Header.DataSize << " bytes but should be " << Info.Size << std::endl;
        std::cerr << "        So shave " << (Header.DataSize - Info.Size) * 8 / (Header.BitsPerSample * Info.Channels) << " sample frames off and it should work." << std::endl;
        return;
    }
    else if (Info.Size > Header.DataSize)
    {
        std::cerr << ">   Can't repack " << Info.FilenameWithPath << " because the size doesn't match." << std::endl;
        std::cerr << "        This one is " << Header.DataSize << " bytes but should be " << Info.Size << std::endl;
        std::cerr << "        So add " << (Info.Size - Header.DataSize) * 8 / (Header.BitsPerSample * Info.Channels) << " sample frames and it should work." << std::endl;
        return;
    }

    if (Info.Channels != Header.Channels || Info.SampleRate != Header.SampleRate)
    {
        std::cerr << ">   WARNING: " << Info.FilenameWithPath << " will be repacked but has different information!." << std::endl;
        std::cerr << "        This one is " << Header.SampleRate << " hz " << Header.BitsPerSample << " bit " << Header.Channels << " channel(s)," << std::endl;
        std::cerr << "        but should be " << Info.SampleRate << " hz " << Info.BitsPerSample << " bit " << Info.Channels << " channel(s)" << std::endl;
    }
    else
    {
        std::cout << ">   Repacking " << Info.FilenameWithPath << std::endl;
    }

    // Okay, now we can do the replacing
    char Buffer[65536];
    int BytesLeft = Info.Size;
    Output.seekg(Info.Offset);

    while (BytesLeft && !WaveInput.eof())
    {
        if (BytesLeft > sizeof(Buffer))
        {
            WaveInput.read(Buffer, sizeof(Buffer));
            Output.write(Buffer, WaveInput.gcount());
            BytesLeft -= WaveInput.gcount();
        }
        else
        {
            WaveInput.read(Buffer, BytesLeft);
            Output.write(Buffer, WaveInput.gcount());
            BytesLeft -= WaveInput.gcount();
            break;
        }
    }

    WaveInput.close();
    return;
}

void DoSoundBank(std::iostream& Input, std::streamoff EndOffset, \
                 const std::string& WavDirectory, \
                 EAction Action, \
                 const std::vector<SFatEntry>& Entries)
{
    std::vector<SWaveSoundInfo> SB0SoundList;

    uint32_t DirCount1;
    uint32_t DirCount2;
    int ExtraCount = 0;
    int TotalDataSize = 0;

    Input.seekg(4, std::ios_base::cur);
    Input.read((char*)&DirCount1, 4);
    Input.read((char*)&DirCount2, 4);
    Input.seekg(16 + DirCount1 * 100, std::ios_base::cur);

    for (int i = 0; i < DirCount2; i++)
    {
        uint32_t Type;
        uint32_t Size;
        uint32_t Size2;
        uint32_t SampleCount;
        uint32_t RelativeOffset;
        uint32_t SampleRate;
        uint16_t BitsPerSample;
        uint16_t Channels;
        uint32_t Location;
        char Filename[41];

        Input.seekg(4, std::ios_base::cur);
        Input.read((char*)&Type, 4);
        Input.read((char*)&Size, 4);
        Input.seekg(4, std::ios_base::cur);
        Input.read((char*)&RelativeOffset, 4);
        Input.seekg(28, std::ios_base::cur);
        Input.read((char*)&SampleCount, 4);
        Input.read((char*)&Size2, 4);
        Input.seekg(12, std::ios_base::cur);
        Input.read((char*)&SampleRate, 4);
        Input.read((char*)&BitsPerSample, 2);
        Input.read((char*)&Channels, 2);
        Input.read((char*)&Location, 4);
        Input.read(Filename, 40);
        Filename[40] = 0;
        Input.seekg(8, std::ios_base::cur);

        if (Type == 1)
        {
            std::cout << "    " << Filename << " - " << SampleRate << " hz " << BitsPerSample << " bit " << Channels << " channel(s)" << std::endl;

            if (Location == 0)
            {
                TotalDataSize += Size;
                if (Size % 4 > 0)
                {
                    TotalDataSize += 4 - Size % 4;
                }

                SB0SoundList.push_back(SWaveSoundInfo());

                SWaveSoundInfo& Item = SB0SoundList.back();
                Item.Filename = Filename;
                Item.FilenameWithPath = WavDirectory;
                Item.FilenameWithPath.append("/");
                Item.FilenameWithPath.append(Item.Filename);
                Item.Offset = RelativeOffset;
                Item.AbsoluteOffset = false;
                Item.Size = Size;
                Item.SampleCount = SampleCount;
                Item.BitsPerSample = BitsPerSample;
                Item.SampleRate = SampleRate;
                Item.Channels = Channels;
            }
            else if (Location == 3)
            {
                std::streamoff FileOffset;
                FileOffset = -1;
                for (std::vector<SFatEntry>::const_iterator Iter = Entries.begin(); Iter != Entries.end(); ++Iter)
                {
					if (strnicmp(Iter->NameOnly.c_str(), Filename, Iter->NameOnly.size()) == 0)
                    {
                        FileOffset = Iter->Offset;
                        break;
                    }
                }

                if (FileOffset)
                {
                    char Buffer[512];
                    static unsigned int CurrentNumber = 1;
                    _snprintf(Buffer, sizeof(Buffer), "%s_%u.wav", Filename, CurrentNumber);
                    CurrentNumber++;

                    SB0SoundList.push_back(SWaveSoundInfo());
                    
                    SWaveSoundInfo& Item = SB0SoundList.back();
                    Item.Filename = Buffer;
                    Item.FilenameWithPath = WavDirectory;
                    Item.FilenameWithPath.append("/");
                    Item.FilenameWithPath.append(Item.Filename);
                    Item.Offset = RelativeOffset + FileOffset;
                    Item.AbsoluteOffset = true;
                    Item.Size = Size;
                    Item.SampleCount = SampleCount;
                    Item.BitsPerSample = BitsPerSample;
                    Item.SampleRate = SampleRate;
                    Item.Channels = Channels;
                }
            }
        }
        else
        {
            ExtraCount++;
        }
    }

    uint32_t ImportantValue;
    std::streamoff DataOffset;
    Input.read((char*)&ImportantValue, 4);
    DataOffset = EndOffset - TotalDataSize;

    while (Input.tellg() < EndOffset)
    {
        uint32_t NextLong;
        Input.read((char*)&NextLong, 4);

        if (NextLong == EndOffset - Input.tellg())
        {
            std::cout << "    Found data start at " << Input.tellg() << " check: " << EndOffset - TotalDataSize << std::endl;
			if ((std::streamoff)Input.tellg() != (std::streamoff)(EndOffset - TotalDataSize))
            {
                std::cout << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << std::endl;
                DataOffset = Input.tellg();
            }
            break;
        }
    }

    if (Action == ACTION_REPACK)
    {
        std::cout << std::endl;
    }

    // Update the offset; make all offsets absolute, not relative.
    for (std::vector<SWaveSoundInfo>::iterator Iter = SB0SoundList.begin(); \
            Iter != SB0SoundList.end(); \
            ++Iter)
    {
        if (!Iter->AbsoluteOffset)
        {
            Iter->Offset += DataOffset;
        }
    }

    // Do all the files
    for (std::vector<SWaveSoundInfo>::const_iterator Iter = SB0SoundList.begin(); \
            Iter != SB0SoundList.end(); \
            ++Iter)
    {
        if (Action == ACTION_EXTRACT)
        {
            if (Iter->AbsoluteOffset)
            {
                DecUbiSndFile(Input, *Iter);
            }
            else
            {
                OutputFile(Input, *Iter);
            }
        }
        else if (Action == ACTION_REPACK)
        {
            RepackFile(Input, *Iter);
        }
    }
    return;
}

static void PrintUsage(const std::string& ProgramName)
{
    std::cerr << "Usage:" << std::endl;
    std::cerr << ProgramName << " extract {Path\\soundlocal.fat} {Path\\soundlocal.big} {Output directory}" << std::endl;
    std::cerr << ProgramName << " repack {Path\\soundlocal.fat} {Path\\soundlocal.big} {.wav directory}" << std::endl;
    std::cerr << std::endl;
    std::cerr << "Extract the contents of the .big file into individual .wav files in the output directory." << std::endl;
    std::cerr << "Repack the .big file with individual .wav files from the .wav directory, matching the names to those in the .big file." << std::endl;
    std::cerr << std::endl;
    return;
}

int main(int argc, char **argv) {
    EAction Action;
    std::string InputFatFilename;
    std::string InputBigFilename;
    std::string WavDirectory;

    // Check the number of arguments
    if (argc < 5)
    {
        PrintUsage(argv[0]);
        return 1;
    }

    // Get the arguments
    std::string ActionString = argv[1];
    if (ActionString == "extract")
    {
        Action = ACTION_EXTRACT;
    }
    else if (ActionString == "repack")
    {
        Action = ACTION_REPACK;
    }
    else
    {
        std::cerr << "The first parameter must be either extract or repack." << std::endl;
        return 1;
    }
    InputFatFilename = argv[2];
    InputBigFilename = argv[3];
    WavDirectory = argv[4];
    GlobalsAreEvilDoNotUseThem = InputBigFilename;

    // Open the file
    std::ifstream InputFat;
    InputFat.open(InputFatFilename.c_str(), std::ios_base::in | std::ios_base::binary);
    if (!InputFat.is_open())
    {
        std::cerr << "Could not open input file '" << InputFatFilename << "'." << std::endl;
        return 1;
    }

    std::fstream InputBig;
    std::streamsize InputBigSize;
    if (Action == ACTION_REPACK)
    {
        InputBig.open(InputBigFilename.c_str(), std::ios_base::in | std::ios_base::out | std::ios_base::binary);
    }
    else
    {
        InputBig.open(InputBigFilename.c_str(), std::ios_base::in | std::ios_base::binary);
    }
    if (!InputBig.is_open())
    {
        std::cerr << "Could not open input file '" << InputBigFilename << "'." << std::endl;
        return 1;
    }
    InputBig.seekg(0, std::ios_base::end);
    InputBigSize = InputBig.tellg();
    InputBig.seekg(0);

    std::vector<SFatEntry> Entries;

    // Read it
    while (!InputFat.eof())
    {
        SFatEntry Entry;
        char Buffer[512];
        uint32_t Offset;
        uint32_t Size;
        uint32_t FilenameLength;

        InputFat.seekg(4, std::ios_base::cur);
        InputFat.read((char*)&Offset, 4);
        InputFat.read((char*)&Size, 4);
        InputFat.seekg(4, std::ios_base::cur);
        InputFat.read((char*)&FilenameLength, 4);

        if (FilenameLength > sizeof(Buffer))
        {
            std::cerr << "Corrupt file." << std::endl;
            return 1;
        }

        InputFat.read(Buffer, FilenameLength);
        Buffer[FilenameLength] = 0;

        Entry.Offset = Offset;
        Entry.Size = Size;
        Entry.Filename = Buffer;

        if (Entry.Filename.size())
        {
            unsigned int i;
            for (i = Entry.Filename.size() - 1; i >= 0; i--)
            {
                if (Entry.Filename[i] == '/' || Entry.Filename[i] == '\\')
                {
                    i++;
                    break;
                }
            }
            Entry.NameOnly = Entry.Filename.substr(i, Entry.Filename.size());
        }
        Entries.push_back(Entry);
    }

    for (std::vector<SFatEntry>::const_iterator Iter = Entries.begin(); Iter != Entries.end(); ++Iter)
    {
        std::cout << Iter->Filename << "\t\t" << Iter->Offset << std::endl;
        
        if (Iter->Offset < InputBigSize)
        {
            if (Iter->Filename[Iter->Filename.size() - 2] == 'b')
            {
                InputBig.seekg(Iter->Offset);
                DoSoundBank(InputBig, Iter->Offset + Iter->Size, WavDirectory, Action, Entries);
            }
        }

        std::cout << std::endl;
    }

    InputFat.close();
    InputBig.close();
    return 0;
}
