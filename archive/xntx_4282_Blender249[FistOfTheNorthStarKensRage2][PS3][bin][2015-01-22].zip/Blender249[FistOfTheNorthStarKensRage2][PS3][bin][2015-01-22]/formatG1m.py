import newGameLib
reload(newGameLib)
from newGameLib import *
import Blender
	
import math
from math import *
	
def elixirParser(filename,g):
	g.debug=True
	g.endian='>'
	g.word(4)
	w=g.i(6)
	unp=Unpacker()
	#print dir(unp)
	unp.inputFile=filename
	unp.outputDir=g.dirname+os.sep+g.basename
	unp.fileCount=w[4]
	offset=w[2]+w[3]
	for m in range(w[4]):
		v=g.i(2)
		unp.nameList.append(g.word(w[3]/w[4]-8))
		unp.offsetList.append(offset)
		unp.sizeList.append(v[1])
		offset+=v[1]
	#g.seek(w[2]+w[3])
	g.tell()
	unp.unpack()	


def g1tParser(filename,g):
	#g.debug=True
	g.endian='>'
	g.word(4)
	g.word(4)
	w = g.i(4)
	g.seek(w[1])	
	for m in range(w[3]):
		t=g.tell()
		offsetList=g.i(w[2])
		for n in range(w[2]):
			#print n,offsetList[n]
			g.seek(w[1]+offsetList[n])
			v=g.H(10)
			print n,v
			img=imageLib.Image()
			if v[0]==257:   
				img.format='tga32'
			elif v[0]==264:   
				img.format='DXT5'
			elif v[0]==774:   
				img.format='DXT1'
			elif v[0]==776:   
				img.format='DXT5'
			elif v[0]==2054:  
				img.format='DXT1'
			elif v[0]==2056:  
				img.format='DXT5'
			elif v[0]==1800:  
				img.format='DXT5'
			elif v[0]==2310:  
				img.format='DXT1'
			elif v[0]==2312:  
				img.format='DXT5'
				
			elif v[0]==1798:  
				img.format='DXT1'
			elif v[0]==1544:  
				img.format='DXT5'
			elif v[0]==1542:  
				img.format='DXT1'
			elif v[0]==1288:  
				img.format='DXT5'
			elif v[0]==1286:  
				img.format='DXT1'
				
			elif v[0]==1032:  
				img.format='DXT5'
				
			elif v[0]==2568:  
				img.format='DXT5'
			elif v[0]==2566:  
				img.format='DXT1'
				
				
				
				
			else:
				print 'WARNING: nieznany format',v[0]	
			if v[1]==26112:
				img.szer=64
				img.wys=64
			elif v[1]==34816:
				img.szer=256
				img.wys=256
				
			elif v[1]==30464:
				img.szer=128
				img.wys=128
				
			elif v[1]==43520:
				img.szer=1024
				img.wys=1024
			elif v[1]==43264:
				img.szer=1024
				img.wys=512
				
			elif v[1]==39168:
				img.szer=512
				img.wys=512
				
			elif v[1]==39169:
				img.szer=512
				img.wys=512
				
			elif v[1]==39424:
				img.szer=512
				img.wys=1024
				
			elif v[1]==39425:
				img.szer=512				
				img.wys=512
				
			elif v[1]==38912:
				img.szer=512
				img.wys=256
			elif v[1]==43776:
				img.szer=1024
				img.wys=1024
			elif v[1]==47872:
				img.szer=2048
				img.wys=2048
			elif v[1]==47616:
				img.szer=2048
				img.wys=1024
				
				
			elif v[1]==34560:
				img.szer=256
				img.wys=128
			elif v[1]==26368:
				img.szer=64
				img.wys=128
			elif v[1]==43008:
				img.szer=128
				img.wys=128
				
			elif v[1]==34304:
				img.szer=128
				img.wys=128				
			elif v[1]==29952:
				img.szer=64
				img.wys=64	
						
			elif v[1]==8704:
				img.szer=64
				img.wys=64	
						
			elif v[1]==43521:
				img.szer=1024
				img.wys=1024
						
			elif v[1]==47873:
				img.szer=2048
				img.wys=2048
						
			elif v[1]==17408:
				img.szer=2048
				img.wys=2048
						
			elif v[1]==34817:
				img.szer=256
				img.wys=256
				
			else:
				print 'WARNING: nieznane wymiary',v[1]	
			img.name=g.dirname+os.sep+'textures'+os.sep+str(n)+'.dds'
			if n<w[2]-1:
				img.data=g.read(offsetList[n+1]-offsetList[n])
			else:
				img.data=g.read(g.fileSize()-offsetList[n]) 
			img.draw()
			#break
			
	g.tell()

def section1(g):
	count=g.i(1)[0]
	for m in range(count):
		g.b(4)
		g.f(7)
		g.b(4)
		g.f(7)

def section2(g):
	texDir=g.dirname.lower().replace('model','texture')+os.sep+'textures'
	#g.debug=True
	count=g.i(1)[0]
	for m in range(count):
		w=g.i(4)
		mat=Mat()
		List=[]
		for n in range(w[1]):
			List.append(g.b(12))
			if n==0:
				mat.diffuse=texDir+os.sep+str(List[n][1])+'.dds'
			
		g1m.matList.append(mat)
		g1m.textureList.append(List)
	#g.debug=False	


def section3(g):
	#g.debug=True
	#print g.tell()
	#for n in range(g.i(1)[0]):
		#print 
	g.i(1)	
	for m in range(g.i(1)[0]):
			w=g.i(3)
			v=g.h(2)
			g.word(w[1])
			g.f(v[0])
	g.tell()	
	#print ghghgh	
	#g.debug=False

class Stream:
	def __init__(self):
		self.unk0=None
		self.strideSize=None
		self.elementCount=None
		self.unk1=None
		self.offset=None


def section4(g):
	count=g.i(1)[0]
	for m in range(count):
		stream=Stream()
		stream.unk0=g.i(1)[0]
		stream.strideSize=g.i(1)[0]
		stream.elementCount=g.i(1)[0]
		stream.unk1=g.i(1)[0]
		stream.offset=g.tell()
		g1m.vertStreamList.append(stream)
		g.seek(stream.elementCount*stream.strideSize,1)	
		
class Stride:
	def __init__(self):
		self.count=None 
		self.list=[]
	
class VertElement:
	def __init__(self):
		self.streamID=None
		self.offset=None
		self.unk0=None
		self.unk1=None
		self.unk2=None
		self.unk3=None

def section5(g):
	count=g.i(1)[0]
	for m in range(count):
		streamList=g.i(g.i(1)[0])		   
		stride=Stride() 
		count=g.i(1)[0]
		stride.count=count
		for n in range(count):
			element=VertElement()
			element.streamID=streamList[g.H(1)[0]]
			element.offset=g.H(1)[0]
			element.unk0=g.b(1)[0]
			element.unk1=g.b(1)[0]
			element.unk2=g.b(1)[0]
			element.unk3=g.b(1)[0]
			stride.list.append(element)
		g1m.strideList.append(stride)
			

def section6(g):
	count=g.i(1)[0]
	for m in range(count):
		List=[]
		for n in range(g.i(1)[0]):
			g.i(1)
			#List.append(str(g.i(1)[0]))
			g.f(1)
			#List.append(str(g.H(2)[1]))
			List.append(g.H(2)[1])
		g1m.boneMapList.append(List)
		#print 'bone map:',List
		
				
def section7(g):
	count=g.i(1)[0]
	for m in range(count):
		stream=Stream()
		v=g.i(3)
		stream.elementCount=v[0]
		if v[1]==16:
			stream.strideSize=2
		elif v[1]==32:
			stream.strideSize=4
		else:
			print 'WARNING: nieznany rozmiar indice',v[1]   
		stream.offset=g.tell()  
		g.seek(stream.elementCount*stream.strideSize,1) 
		g1m.indiceStreamList.append(stream)
			

def section8(g):
	count=g.i(1)[0]
	for m in range(count):
		g1m.meshInfoList.append(g.i(14))
				

def G1MGParser(g):
	g.word(4)
	g.f(7)
	count=g.i(1)[0]
	for k in range(count):
		t=g.tell()
		v=g.H(2)	
		size=g.i(1)[0]
		if v[1]==1:
			section1(g)
		if v[1]==2:
			section2(g)
		#if v[1]==3:
		#	section3(g)
		if v[1]==4:
			section4(g)
		if v[1]==5:
			section5(g)
		if v[1]==6:
			section6(g)
		if v[1]==7:
			section7(g)
		if v[1]==8:
			section8(g)
		g.seek(t+size)

def G1MFParser(g): 
	w=g.i(36)	

def G1MMParser(g):
	skeleton=Skeleton()
	skeleton.ARMATURESPACE=True
	skeleton.NICE=True
	#skeleton.DEL=False
	count=g.i(1)[0]
	for k in range(count):
		bone=Bone()
		bone.name=str(k)		
		bone.matrix=Matrix(g.f(4),g.f(4),g.f(4),g.f(4)).invert()
		skeleton.boneList.append(bone)
	g1m.bindSkeletonList.append(skeleton)	
		

def G1MSParser(back,g):
	
	skeleton=Skeleton()
	skeleton.BONESPACE=True
	skeleton.NICE=True
	
	offset=g.i(1)[0]
	w=g.H(6)
	#print 'skeleton:',w,back+offset
	#g.H(w[4])
	#g.H(2)
	if w[2]>1:
		g.seek(back+offset)
		#skeleton.DEL=False
		for m in range(w[2]):		
			bone=Bone()
			bone.name=str(m)
			g.f(3)
			bone.parentID=g.i(1)[0]
			#print g.f(1)
			w=g.f(4)
			bone.rotMatrix=Quaternion(w[3],w[0],w[1],w[2]).toMatrix().resize4x4()
			bone.posMatrix=TranslationMatrix(Vector(g.f(4)))
			skeleton.boneList.append(bone)
			#print m,bone.parentID
		g.tell()
	else:
		g.seek(back+offset)
		print g.f(12)
	g1m.skeletonList.append(skeleton)	
	
	
class G1M:
	def __init__(self):
		self.meshCount=None 	
		self.boneMapList=[]
		self.meshList=[]
		self.matList=[]
		self.strideList=[]
		self.vertStreamList=[]
		self.indiceStreamList=[]
		self.meshInfoList=[]
		self.textureList=[]
		self.skeletonList=[]
		self.bindSkeletonList=[]

def g1mParser(filename,g,offset):
	global g1m
	ModelID=ParseID()
	print '==============G1M==============',ModelID
	g.endian='>'
	g.word(4)
	g.word(4)
	data = g.i(4)	
	g.seek(offset+data[1])
	g1m=G1M()
	for m in range(data[3]):	
		back = g.tell()
		chunk=g.word(4)
		g.word(4)
		size = g.i(1)[0]
		if chunk=='G1MF':
			w=g.i(36)
			g1m.meshCount=w[11]
			#G1MFParser(g)
		if chunk=='G1MS':G1MSParser(back,g)
		if chunk=='G1MG':G1MGParser(g)
		if chunk=='G1MM':G1MMParser(g)
		g.seek(back+size)
		g.tell()
	g.debug=False	
		
	
	texDir=g.dirname.lower().replace('model','texture')+os.sep+'textures'	
	g.debug=False
	g.tell()
	for meshID in range(g1m.meshCount):
		mesh=Mesh()
		#mesh.name=str(ModelID)+'-mesh-'+str(meshID)
		g1m.meshList.append(mesh)
	for infoID in range(len(g1m.meshInfoList)):
		info=g1m.meshInfoList[infoID]
		print info
		mesh=g1m.meshList[info[1]]
		#mesh.TRISTRIP=True
		stride=g1m.strideList[info[1]]
		indiceStream=g1m.indiceStreamList[info[1]]
		#print indiceStream.offset
		g.seek(indiceStream.offset+info[12]*indiceStream.strideSize)
		for m in range(info[13]):
			if indiceStream.strideSize==2:
				mesh.indiceList.append(g.H(1)[0])
			if indiceStream.strideSize==4:
				pass#mesh.indiceList.append(g.i(1)[0])
			
		mat=Mat()
		#mat.ZTRANS=True
		#mat=g1m.matList[infoID]
		if len(g1m.textureList[info[6]])>0:
			diffID=g1m.textureList[info[6]][0][1]
			mat.diffuse=texDir+os.sep+str(diffID)+'.dds'
		if len(g1m.textureList[info[6]])==4:
			diffID1=g1m.textureList[info[6]][1][1]
			mat.diffuse1=texDir+os.sep+str(diffID1)+'.dds'
			diffID2=g1m.textureList[info[6]][3][1]
			mat.diffuse2=texDir+os.sep+str(diffID2)+'.dds'
		if len(g1m.textureList[info[6]])==3:
			aoID=g1m.textureList[info[6]][2][1]
			#mat.ao=g.dirname+os.sep+'textures'+os.sep+str(aoID)+'.dds'
			specularID=g1m.textureList[info[6]][1][1]
			mat.specular=texDir+os.sep+str(specularID)+'.dds'
			
		#g1m.matList[info[6]].diffuse
		#mat.ao=g1m.matList[info[6]].ao
		#mat.name=mesh.name+'-'+str(m)
		mat.IDStart=info[12]
		mat.IDCount=info[13]
		mat.TRISTRIP=True
		#mat.TRIANGLE=True
		mesh.matList.append(mat)
		for m in range(stride.count):
			element=stride.list[m]
			if debug==True:
				print element.streamID,
				print element.offset,
				print element.unk0,
				print element.unk1,
				print element.unk2,
				print element.unk3
			if element.unk2==0:#vertPosList				 
				stream=g1m.vertStreamList[element.streamID]
				if debug==True:				
					print '----',
					print stream.elementCount,
					print stream.strideSize
				g.seek(stream.offset+info[10]*stream.strideSize)
				for n in range(info[11]):
					t=g.tell()
					g.seek(t+element.offset)
					if element.unk0==2:#3float
						mesh.vertPosList.append(g.f(3))
					if element.unk0==11:#3half
						mesh.vertPosList.append(g.half(3))
					if element.unk0==3:#3float
						mesh.vertPosList.append(g.f(3))
					g.seek(t+stream.strideSize)
			if element.unk2==5:#vertUVList  
				if element.unk3==0:#layer 0			 
					stream=g1m.vertStreamList[element.streamID]
					if debug==True:				
						print '----',
						print stream.elementCount,
						print stream.strideSize
					g.seek(stream.offset+info[10]*stream.strideSize)
					for n in range(info[11]):
						t=g.tell()
						g.seek(t+element.offset)
						if element.unk0==1:#2float
							mesh.vertUVList.append(g.f(2))
						if element.unk0==10:#2float
							mesh.vertUVList.append(g.half(2))
						g.seek(t+stream.strideSize)
			if element.unk2==1:#skinWeightList  
				if element.unk3==0:#layer 0			 
					stream=g1m.vertStreamList[element.streamID]
					if debug==True:				
						print '----',
						print stream.elementCount,
						print stream.strideSize
					g.seek(stream.offset+info[10]*stream.strideSize)
					for n in range(info[11]):
						t=g.tell()
						g.seek(t+element.offset)
						if element.unk0==0:#3float
							mesh.skinWeightList.append(g.f(3))
						elif element.unk0==1:#3float
							mesh.skinWeightList.append(g.f(3))
						elif element.unk0==2:#3float
							mesh.skinWeightList.append(g.f(3))
						elif element.unk0==3:
							mesh.skinWeightList.append(g.f(4))
						elif element.unk0==13:#3float
							W1=g.B(1)[0]/255.0
							W2=g.B(1)[0]/255.0
							W3=g.B(1)[0]/255.0
							mesh.skinWeightList.append([W1,W2,W3])
						else:
							print 'WARNING unk0:',element.unk0
							break
						g.seek(t+stream.strideSize)
			if element.unk2==33:#skinWeightList  
				if element.unk3==0:#layer 0			 
					stream=g1m.vertStreamList[element.streamID]
					if debug==True:				
						print '----',
						print stream.elementCount,
						print stream.strideSize
					g.seek(stream.offset+info[10]*stream.strideSize)
					for n in range(info[11]):
						t=g.tell()
						g.seek(t+element.offset)
						if element.unk0==11:#3float
							mesh.skinWeightList.append(g.f(2))
						elif element.unk0==1:#3float
							mesh.skinWeightList.append(g.f(3))
						elif element.unk0==2:#3float
							mesh.skinWeightList.append(g.f(3))
						elif element.unk0==3:
							mesh.skinWeightList.append(g.f(4))
						elif element.unk0==13:#3float
							W1=g.B(1)[0]/255.0
							W2=g.B(1)[0]/255.0
							W3=g.B(1)[0]/255.0
							mesh.skinWeightList.append([W1,W2,W3])
						else:
							print 'WARNING unk0:',element.unk0
							break
						g.seek(t+stream.strideSize)
			if element.unk2==2:#skinIndiceList  
				if element.unk3==0:#layer 0			 
					stream=g1m.vertStreamList[element.streamID]
					if debug==True:				
						print '----',
						print stream.elementCount,
						print stream.strideSize
					g.seek(stream.offset+info[10]*stream.strideSize)
					for n in range(info[11]):
						t=g.tell()
						g.seek(t+element.offset)
						if element.unk0==5:#3float
							ID1=g.B(1)[0]/3
							ID2=g.B(1)[0]/3
							ID3=g.B(1)[0]/3
							ID4=g.B(1)[0]/3
							mesh.skinIndiceList.append([ID1,ID2,ID3,ID4])
						g.seek(t+stream.strideSize) 
		
		skin=Skin()#mesh.skinList[0]
		skin.boneMap=g1m.boneMapList[info[2]]
		#skin.IDStart=info[10]
		#skin.IDCount=info[11]
		#mesh.skinList.append(skin)
		for m in range(info[11]):
			mesh.skinIDList.append(len(mesh.matList)-1)
		if len(mesh.skinIndiceList)>0:
			if len(mesh.skinIndiceList)==len(mesh.skinWeightList):
				mesh.skinList.append(skin)	
			else:
				print 'WARNING:skin'
				#mesh.skinList.append(skin)	
		else:
			for m in range(info[11]):
				mesh.skinWeightList.append([1.0])
				mesh.skinIndiceList.append([0])
			mesh.skinList.append(skin)
				
		
	if len(g1m.meshList)==0:	
		for i,skeleton in enumerate(g1m.skeletonList):		
				#skeleton.name=str(ModelID)+'-skeleton-'+str(i)	
				skeleton.name='armature'
				if len(skeleton.boneList)>1:
					try:skeleton.draw()
					except:pass
					break
	for i,skeleton in enumerate(g1m.bindSkeletonList):		
			skeleton.name=str(ModelID)+'-bindskeleton-'+str(i)
			try:skeleton.draw()
			except:pass
	for i,mesh in enumerate(g1m.meshList):
	#for i,mesh in enumerate(g1m.meshList[:2]):
			#mesh.BINDSKELETON='armature'
			mesh.name=str(ModelID)+'-mesh-'+str(i)
			print 'mesh:',i	 
			#mesh.SPLIT=True
			#mesh.WARNING=True	
			try:mesh.draw()		 
			except:pass
				
	


def bindPose(bindSkeleton,poseSkeleton,meshObject):
		#print 'BINDPOSE'
		mesh=meshObject.getData(mesh=1)
		poseBones=poseSkeleton.getData().bones
		bindBones=bindSkeleton.getData().bones			
		for vert in mesh.verts:
			index=vert.index
			skinList=mesh.getVertexInfluences(index)
			vco=vert.co.copy()*meshObject.matrixWorld
			vector=Vector()
			for skin in skinList:
				try:
					bone=skin[0]							
					weight=skin[1]					
					matA=bindBones[bone].matrix['ARMATURESPACE']*bindSkeleton.matrixWorld
					matB=poseBones[bone].matrix['ARMATURESPACE']*poseSkeleton.matrixWorld
					vector+=vco*matA.invert()*matB*weight
				except:pass	
			vert.co=vector
		mesh.update()
		Blender.Window.RedrawAll()
			
			
#ID=3
#bindSkeleton=Blender.Object.Get('armature-'+str(ID))
#poseSkeleton=Blender.Object.Get('bindPose-mesh-'+str(ID))
#meshObject=Blender.Object.Get('mesh-'+str(ID))

#bindPose(bindSkeleton,poseSkeleton,meshObject)		
	
	
			
def Parser():
	filename=input.filename
	print
	print filename
	print
	global debug
	ext=filename.split('.')[-1].lower()
	debug=True
	
	
	
	if ext=='bin':	
		g1tPath=filename.lower().replace('_mdl.bin','_tex.g1t').replace('model','texture')
		if os.path.exists(g1tPath)==True:
			file=open(g1tPath,'rb')
			g=BinaryReader(file)
			g.endian='>'
			a,b=g.i(2)
			data=''
			while(True):
				if g.tell()>=g.fileSize():break
				size=g.i(1)[0]	
				t=g.tell()
				if size!=0:	
					data+=zlib.decompress(g.read(size))
				g.seek(t+size)
			new=open(g1tPath+'.dec','wb')	
			new.write(data)
			new.close()
			file.close()
			file=open(g1tPath+'.dec','rb')
			g=BinaryReader(file)
			g1tParser(g1tPath,g)
			file.close()
	
	
		file=open(filename,'rb')
		g=BinaryReader(file)
		g.endian='>'
		a,b=g.i(2)
		data=''
		while(True):
			if g.tell()>=g.fileSize():break
			size=g.i(1)[0]	
			t=g.tell()
			if size!=0:data+=zlib.decompress(g.read(size))
			g.seek(t+size)
			
		decPath=filename+'.dec'	
		new=open(decPath,'wb')	
		new.write(data)
		new.close()		
		file.close()
		
		if os.path.exists(decPath)==True:
			file=open(decPath,'rb')
			g=BinaryReader(file)
			g.endian='>'
			count=g.i(1)[0]
			offset=g.i(count)
			for m in range(count):
				g.seek(offset[m])
				g1mParser(decPath,g,g.tell())
			file.close()
			
			scene = bpy.data.scenes.active
			poseSkeleton=None
			for object in scene.objects:
				if object.type=='Armature':
					if 'armature' in object.name:
						poseSkeleton=object
						break
			if poseSkeleton is not None:			
				for object in scene.objects:
					if object.type=='Armature':
						if '-bindskeleton-' in object.name:
							skeletonID=object.name.split('-')[0]
							bindSkeleton=object
							for object1 in scene.objects:
								if object1.type=='Mesh':
									meshID=object1.name.split('-')[0]
									if skeletonID==meshID:
										meshObject=object1
										#bindPose(bindSkeleton,poseSkeleton,meshObject)	
									
						
					
			
			
			
			
	
 
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
Blender.Window.FileSelector(openFile,'import','Fist of the North Star Kens Rage 2 files: *.bin')