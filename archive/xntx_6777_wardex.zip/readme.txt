wardex - The Ward (2000) audio extractor by DKDave

This is a simple command-line prog to extract the audio from the game "The Ward".

Place this prog in the same folder as RESDIR.DAT, WARD001.RES, WARD002.RES, WARD101.RES, and WARD102.RES

To use, open a command prompt, nagivate to the above folder, and type wardex from the command line to see some info on usage.

To extract all the audio, just type wardex x resdir.dat - this will create an output folder and extract all of the audio files.

The files are extracted as they appear in the archive.  However, the music files are broken up into segments, but they all seem to follow on, so it should be easy to combine them.  I haven't yet deciphered if the RESDIR.DAT file contains information on joining these together.


