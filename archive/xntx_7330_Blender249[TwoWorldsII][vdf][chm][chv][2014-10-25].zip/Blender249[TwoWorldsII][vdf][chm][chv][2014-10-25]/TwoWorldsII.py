import newGameLib
reload(newGameLib)
from newGameLib import *
import Blender

	
class Node:
	def __init__(self):
		self.type=None
		self.children=[]
		self.data={}
		self.name=None
	
	


	

def sectionParser(g,size,parent,n):
	section_size = size
	n+=4
	while(True):
		node=Node()
		nodeList.append(node)
		flag = g.B(1)[0] 
		print '-'*n,'flag:',flag
		back = g.tell()
		offset = g.i(1)[0]
		if flag == 1:					
			chunk = g.B(1)[0]   
			name = g.word(g.i(1)[0])
			print '-'*n,chunk,name,g.tell()
			if chunk == 18:node.data[name]=g.i(1)[0]
			if chunk == 21:node.data[name]=Matrix4x4(g.f(16)) 
			if chunk == 23:node.data[name]=g.tell()
			if chunk == 22:node.data[name]=g.find('\x01')
		if flag == 2:
			node.type = g.i(1)[0]
			print '-'*n,'node.type:',node.type	
			if node.type>=0:print '-submesh'
			if node.type ==-255:print '-bone'
			if node.type ==-253:print '-material'	 
			sectionParser(g,back+offset,node,n)
		g.seek(back+offset,0)
		
		parent.children.append(node)	
	
		if back+offset == section_size:
			break




 

  
def drawChvMesh(filename,g):
	for node in nodeList:
		if node.type>=0:
			lodLevel=None
			meshName=None
			vertCount,vertOffset,vertFormat=None,None,None
			faceCount,faceOffset=None,None
			boneCount,boneMapOffset,boneBindMatrixOffset=None,None,None
			matList=[]
			for child in node.children:
				for key in child.data.keys():
					print key,child.data[key]
					if key=='Name':meshName=child.data[key]
					if key=='NumVertexes':vertCount=child.data[key]
					if key=='NumVertexes':vertCount=child.data[key]
					if key=='Vertexes':vertOffset=child.data[key]
					if key=='VertexFormat':vertFormat=child.data[key]
					if key=='NumFaces':indiceCount=child.data[key]
					if key=='Faces':faceOffset=child.data[key]
					if key=='LODLevel':lodLevel=child.data[key]
					if key=='NumBones':boneCount=child.data[key]
					if key=='BoneIDS':boneMapOffset=child.data[key]
					if key=='BindMatrix':boneBindMatrixOffset=child.data[key]
				#print child.type	
				if child.type==-253:
					texDir=filename.lower().split('models')[0]+'textures'
					mat=Mat()
					for child253 in child.children:
						for key in child253.data.keys():
							print key,child253.data[key]
							if key=='TexS0':mat.diffuse=texDir+os.sep+child253.data[key]
							if key=='TexS1':mat.normal=texDir+os.sep+child253.data[key]
							if key=='TexS2':mat.specular=texDir+os.sep+child253.data[key]
					matList.append(mat)			
			if lodLevel is not None:
				if lodLevel==0:	
						
					skeleton=Skeleton()
					skeleton.name=meshName
					mesh=Mesh()
					mesh.UVFLIP=True
					skin=Skin()
					mesh.skinList.append(skin)
					if vertCount is not None and vertOffset is not None and vertFormat is not None: 
						g.seek(vertOffset)
						for i in range(vertCount):
							t=g.tell()
							mesh.vertPosList.append(g.f(3))
							mesh.skinWeightList.append(g.f(3))
							mesh.skinIndiceList.append(g.B(3))
							g.seek(t+36)
							mesh.vertUVList.append(g.f(2))
							if vertFormat==1:
								g.seek(t+52)
					if indiceCount is not None and faceOffset is not None: 
						g.seek(faceOffset)
						faceCount=indiceCount/3
						for i in range(faceCount):
							mesh.faceList.append(g.H(3))
					if boneCount is not None and boneMapOffset is not None: 
						skeleton.ARMATURESPACE=True
						g.seek(boneMapOffset)
						for i in range(boneCount):
							bone=Bone()
							name=g.word(512)
							mesh.boneNameList.append(name)
							bone.name=name
							skeleton.boneList.append(bone)
						g.seek(boneBindMatrixOffset)
						for i in range(boneCount):
							bone=skeleton.boneList[i]
							bone.matrix=Matrix4x4(g.f(16))
						skeleton.draw()	
					mesh.BINDSKELETON=skeleton.name		
					mesh.matList=matList		
					mesh.draw()			
				
						
			


def drawVdfMesh(filename,g):
	skeleton=Skeleton()
	skeleton.draw()
	for node in nodeList:
		if node.type>=0:
			lodLevel=None
			meshName=None
			vertCount,vertOffset,vertFormat=None,None,None
			faceCount,faceOffset=None,None
			boneCount,boneMapOffset,boneBindMatrixOffset=None,None,None
			matList=[]
			for child in node.children:
				for key in child.data.keys():
					print key,child.data[key]
					if key=='Name':meshName=child.data[key]
					if key=='NumVertexes':vertCount=child.data[key]
					if key=='NumVertexes':vertCount=child.data[key]
					if key=='Vertexes':vertOffset=child.data[key]
					if key=='VertexFormat':vertFormat=child.data[key]
					if key=='NumFaces':indiceCount=child.data[key]
					if key=='Faces':faceOffset=child.data[key]
					if key=='LODLevel':lodLevel=child.data[key]
					if key=='NumBones':boneCount=child.data[key]
					if key=='BoneIDS':boneMapOffset=child.data[key]
					if key=='BindMatrix':boneBindMatrixOffset=child.data[key]
				#print child.type	
				if child.type==-253:
					texDir=filename.lower().split('models')[0]+'textures'
					mat=Mat()
					for child253 in child.children:
						for key in child253.data.keys():
							print key,child253.data[key]
							if key=='TexS0':mat.diffuse=texDir+os.sep+child253.data[key]
							if key=='TexS1':mat.normal=texDir+os.sep+child253.data[key]
							if key=='TexS2':mat.specular=texDir+os.sep+child253.data[key]
					matList.append(mat)			
			if lodLevel is not None:
				if lodLevel==0:	
						
					skeleton=Skeleton()
					skeleton.name=meshName
					mesh=Mesh()
					mesh.UVFLIP=True
					if vertCount is not None and vertOffset is not None and vertFormat is not None: 
						g.seek(vertOffset)
						for i in range(vertCount):
							t=g.tell()
							mesh.vertPosList.append(g.f(3))
							g.seek(t+20)
							mesh.vertUVList.append(g.f(2))
							if vertFormat==1:
								g.seek(t+36)
					if indiceCount is not None and faceOffset is not None: 
						g.seek(faceOffset)
						faceCount=indiceCount/3
						for i in range(faceCount):
							mesh.faceList.append(g.H(3))
					mesh.matList=matList
					mesh.BINDSKELETON=skeleton.name
					mesh.draw()			
				
						
			

	

def read_tree(filename,g):
	g.i(1)[0]
	flag = g.B(1)[0] 
	back = g.tell()
	n=0
	print 'flag:',flag
	if flag == 2:
		section_size = g.i(1)[0] 
		node=Node()
		nodeList.append(node)
		node.type = g.i(1)[0] 
		print 'node.type',node.type
		if node.type ==-1:
			sectionParser(g,back+section_size,node,n)
	
	
def chvParser(filename,g):
	global nodeList
	nodeList=[]
	read_tree(filename,g)
	drawChvMesh(filename,g)
	
	
	
def vdfParser(filename,g):
	global nodeList
	nodeList=[]
	read_tree(filename,g)
	drawVdfMesh(filename,g)
	
	

def boneParser(g,size,parent,n):
	section_size = size
	n+=4
	bone=None
	while(True):
		flag = g.B(1)[0] 
		#print '-'*n,'flag:',flag
		back = g.tell()
		offset = g.i(1)[0]
		if flag == 1:					
			chunk = g.B(1)[0]   
			name = g.word(g.i(1)[0])
			#print '-'*n,chunk,name,g.tell()
			if chunk == 18:
				if name=='ParentID':
					parentID=g.i(1)[0]
			if chunk == 21:parent.matrix=Matrix4x4(g.f(16)) 
			#if chunk == 23:node.data[name]=g.tell()
			if chunk == 22:
				if name=='Name':
					bone=Bone()
					bone.name=g.find('\x01')
					bone.parentName=parent.name
					skeleton.boneList.append(bone)
		if flag == 2:
			type = g.i(1)[0] 
			if bone is None:
				bone=parent
			boneParser(g,back+offset,bone,n)
		g.seek(back+offset,0)
			
	
		if back+offset == section_size:
			break

	
	
def chmParser(filename,g):
	global skeleton
	skeleton=Skeleton()
	g.i(1)[0]
	flag = g.B(1)[0] 
	back = g.tell()
	n=0
	#print 'flag:',flag
	if flag == 2:
		section_size = g.i(1)[0] 
		bone=Bone()
		skeleton.boneList.append(bone)
		type = g.i(1)[0] 
		#print 'type',type
		if type ==-1:
			boneParser(g,back+section_size,bone,n)
	scene = bpy.data.scenes.active
	for object in scene.objects:
		if object.getType()=='Armature':
			armature=object.getData()	
			armature.makeEditable()	
			for bone in armature.bones.values():
				for item in skeleton.boneList:
					if item.name==bone.name:
						print item.parentName
						if item.parentName is not None:
							if item.parentName in armature.bones.keys():
								bone.parent=armature.bones[item.parentName]
			armature.update()
	
def Parser():	
	filename=input.filename
	imageList=input.imageList
	ext=filename.split('.')[-1].lower()	
	
	if ext=='chv':
		file=open(filename,'rb')
		g=BinaryReader(file)
		chvParser(filename,g)
		file.close()		
	
	if ext=='vdf':
		file=open(filename,'rb')
		g=BinaryReader(file)
		vdfParser(filename,g)
		file.close()	
	
	if ext=='chm':
		file=open(filename,'rb')
		g=BinaryReader(file)
		g.logOpen()
		chmParser(filename,g)
		g.logClose()
		file.close()
 
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
	
Blender.Window.FileSelector(openFile,'import','vdf - static model, chv - skinned model, chm - animation')	
	
	
	
	
	
	