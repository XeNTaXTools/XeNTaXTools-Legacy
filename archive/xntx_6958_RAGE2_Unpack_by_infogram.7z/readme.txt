Rage2Unpack 0.3a - Gibbed.JustCause4 modified to work with Rage 2 by infogram.
(Source code changed from Gibbed.JustCause4 is inside the src folder)

To use, make sure to extract all files from the zip archive (except src folder which is unneeded)

Huge thanks goes to (in no particular order):
- Grinderkiller for creating the filelist for Rage 2 (without that none of the extracted files would be named!)
- rengareng on XeNTaX for identifying the hash algorithm (without that the filelist would be useless!)
- gibbed for Gibbed.JustCause4 (hope you don't mind this small alteration of your work :)

Note that the included filelist is likely very incomplete, check the thread on XeNTaX for any updates:
https://forum.xentax.com/viewtopic.php?f=10&t=20486

If you want to modify a file and use it ingame, just store the file in the games root directory as a loose file, keeping the directory structure intact.
eg. if you're modifying "animations\ragdoll\ragdoll_params.brdd" inside "SteamApps\Rage 2\archives_win64\initial\game0.tab", you should store the modified file as
"SteamApps\Rage 2\animations\ragdoll\ragdoll_params.brdd", and the game should load it in fine!