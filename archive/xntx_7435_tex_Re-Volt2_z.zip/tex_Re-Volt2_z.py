from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Re-Volt 2", ".z")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    return 1
    
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    imgWidth = bs.readUInt()            
    imgHeight = bs.readUInt()
    print(imgWidth, "x", imgHeight)
    imgFmt = bs.readUInt()
    print(imgFmt, ":imgFmt")
    compSize = bs.readUInt()
    cmpData = bs.readBytes(compSize)
    decompSize = rapi.getInflatedSize(cmpData)
    print(hex(decompSize))
    data = rapi.decompInflate(cmpData, decompSize)
    #RGBA8888
    if imgFmt == 0x2908:
        data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "r8 g8 b8 a8")
        texFmt = noesis.NOESISTEX_RGBA32
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1