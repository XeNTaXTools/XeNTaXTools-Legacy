idTech 5 Audio Extraction Pack
Pack for extracting audio from games based on idTech 5 engine.

Tested and works with:
RAGE
Wolfenstein: The New Order
The Evil Within (+ DLCs)

Probably will be need to install audio codecs for playing. (for MS ADPCM, as minimum)

Thanks to:
aluigi (The Evil Within bms script for .tangoresources)
Killermannvs (ResourcesExporter for Wolfenstein: The New Order)
WRS (original RAGE gameresources.resources bms script)
Qartar (modified RAGE gameresources.resources bms script)
spider91 (streamed.resources unpack bms scripts for Wolfenstein: The New Order and RAGE , header+audio bms script linkers for all three games)