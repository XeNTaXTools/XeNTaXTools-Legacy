import newGameLib
from newGameLib import *
import Blender	




def c3bSkinParser(filename,g):


	model=Model(filename)
	def getChildren(parent,n):
		n+=4
		bone=Bone()
		bone.parentName=parent.name
		skeleton.boneList.append(bone)
		bone.name=g.word(g.i(1)[0])	
		a=g.B(1)
		bone.matrix=Matrix4x4(g.f(16))	
		b=g.i(1)[0]
		write(txt,[bone.name,a,b],n)
		for m in safe(g.i(1)[0]):
			getChildren(bone,n)

	a=g.B(6)
	write(txt,a,0)
	sectionCount=g.i(1)[0]
	boneNamesList=[]
	skeletonList=[]
	meshList=[]
	id=0
	nodeList=[]
	diffuseList=[]
	for i in safe(sectionCount):
		sectionName=g.word(g.i(1)[0])
		unk,offset=g.i(2)
		back=g.tell()
		g.seek(offset)
		#if sectionName=='DL_Body_meshnode':
		write(txt,[unk,offset,sectionName],0)
		if unk==3:
			action=Action()
			action.BONESORT=True
			action.BONESPACE=True
			action.name=g.word(g.i(1)[0])
			g.f(1)
			boneCount=g.i(1)[0]
			for k in safe(boneCount):
				bone=ActionBone()				
				action.boneList.append(bone)
				bone.name=g.word(g.i(1)[0])
				print 'bone:',bone.name
				frameCount=g.i(1)[0]
				for m in safe(frameCount):
					#try:
					time=int(g.f(1)[0]*60)
					#except:
					#	time=0
					flag=g.B(1)[0]
					if flag==7:
						rot=g.f(4)
						scale=g.f(3)
						#bone.sizeKeyList.append(VectorScaleMatrix(scale))
						#bone.sizeFrameList.append(time)
						pos=g.f(3)
						#bone.posKeyList.append(VectorMatrix(pos))
						#bone.rotKeyList.append(QuatMatrix(Quaternion(rot)).resize4x4())
						#bone.posFrameList.append(time)
						#bone.rotFrameList.append(time)
						bone.matrixFrameList.append(time)
						matrix=VectorScaleMatrix(scale)*QuatMatrix(Quaternion(rot)).resize4x4()*VectorMatrix(pos)
						bone.matrixKeyList.append(matrix)
					elif flag==5:
						rot=g.f(4)
						#bone.rotKeyList.append(QuatMatrix(Quaternion(rot)).resize4x4())
						#bone.rotFrameList.append(time)
						pos=g.f(3)
						#bone.posKeyList.append(VectorMatrix(pos))
						#bone.posFrameList.append(time)
						bone.matrixFrameList.append(time)
						matrix=QuatMatrix(Quaternion(rot)).resize4x4()*VectorMatrix(pos)
						bone.matrixKeyList.append(matrix)
					elif flag==3:
						rot=g.f(4)
						#bone.rotKeyList.append(QuatMatrix(Quaternion(rot)).resize4x4())
						#bone.rotFrameList.append(time)
						scale=g.f(3)
						#bone.sizeKeyList.append(VectorScaleMatrix(scale))
						#bone.sizeFrameList.append(time)
						bone.matrixFrameList.append(time)
						matrix=VectorScaleMatrix(scale)*QuatMatrix(Quaternion(rot)).resize4x4()
						bone.matrixKeyList.append(matrix)
					elif flag==4:
						pos=g.f(3)
						#bone.posKeyList.append(VectorMatrix(pos))
						#bone.posFrameList.append(time)
						bone.matrixFrameList.append(time)
						matrix=VectorMatrix(pos)
						bone.matrixKeyList.append(matrix)
					elif flag==1:
						rot=g.f(4)
						#bone.rotKeyList.append(QuatMatrix(Quaternion(rot)).resize4x4())
						#bone.rotFrameList.append(time)
						bone.matrixFrameList.append(time)
						matrix=QuatMatrix(Quaternion(rot)).resize4x4()
						bone.matrixKeyList.append(matrix)
					elif flag==6:
						scale=g.f(3)
						#bone.sizeKeyList.append(VectorScaleMatrix(scale))
						#bone.sizeFrameList.append(time)
						pos=g.f(3)
						#bone.posKeyList.append(VectorMatrix(pos))
						#bone.posFrameList.append(time)
						bone.matrixFrameList.append(time)
						matrix=VectorScaleMatrix(scale)*VectorMatrix(pos)
						bone.matrixKeyList.append(matrix)
					elif flag==2:
						scale=g.f(3)
						#bone.sizeKeyList.append(VectorScaleMatrix(scale))
						#bone.sizeFrameList.append(time)
						bone.matrixFrameList.append(time)
						matrix=VectorScaleMatrix(scale)
						bone.matrixKeyList.append(matrix)
					else:
						break
			action.draw()
			action.setContext()	
			#break
			
		if unk==2:
			nodeCount=g.i(1)[0]
			write(txt,['node count:',nodeCount],0)
			for m in safe(nodeCount):
				#g.logWrite('='*20+str(m))
				write(txt,[m,':',g.tell()],0)
				a=g.word(g.i(1)[0])
				b=g.B(1)[0]
				write(txt,[a,b],4)
				if b==0:
					c=g.f(16)
					d=g.i(1)[0]
					name1=g.word(g.i(1)[0])
					name2=g.word(g.i(1)[0])
					boneCount=g.i(1)[0]
					write(txt,[c],4)
					write(txt,[d],4)
					write(txt,[name1,name2],4)
					write(txt,['boneCount:',boneCount],4)
					boneNames=[]
					p.i([boneCount])
					for m in safe(boneCount):
						name=g.word(g.i(1)[0])
						matrix=g.f(16)
						if name:
							p.write(name+'\x00')
						p.f(matrix)
						boneNames.append(name)
						write(txt,[name],8)
					boneNamesList.append(boneNames)	
					nodeList.append([c,d,name1,name2,boneNames])
					e=g.i(2)
					f1=g.i(e[0])
					f2=g.i(e[1])
					write(txt,[e,f1,f2],4)
				if b==1:	
					c=g.f(16)
					d=g.i(1)[0]
					write(txt,[c],4)
					write(txt,[d],4)
					global skeleton 
					skeleton=Skeleton()
					skeletonList.append(skeleton)
					skeleton.NICE=True
					bone=Bone()
					skeleton.boneList.append(bone)
					bone.name=a
					bone.matrix=Matrix4x4(c)
					for n in safe(g.i(1)[0]):
						getChildren(bone,4)
					skeleton.draw()	
			write(txt,[g.tell()],0)
		
		#if sectionName=='Diffuse_matmaterial==':
		if unk==16:
			matCount=g.i(1)[0]	
			write(txt,['matCount:',matCount],0)
			for m in safe(matCount):
				write(txt,[m],0)
				name0=g.word(g.i(1)[0])
				b=g.f(14)
				c=g.i(1)[0]
				for n in safe(c):
					name1=g.word(g.i(1)[0])
					name2=g.word(g.i(1)[0])
					d=g.f(4)
					name3=g.word(g.i(1)[0])
					name4=g.word(g.i(1)[0])
					name5=g.word(g.i(1)[0])	
					write(txt,[b,c,d],4)
					write(txt,[name0],4)
					write(txt,[name1],4)
					write(txt,[name2],4)
					write(txt,[name3],4)
					write(txt,[name4],4)
		
		#if sectionName=='mesh==':
		if unk==34:
			meshCount=g.i(1)[0]
			allMatsCount=0
			write(txt,['meshCount:',meshCount],0)
			for k in safe(meshCount):
				write(txt,[k],0)
				stride=0
				B=[]
				vertexItemCount=g.i(1)[0]
				for m in safe(vertexItemCount):
					a=g.i(1)[0]
					b=g.word(g.i(1)[0])
					c=g.word(g.i(1)[0])
					B.append([c,stride])
					write(txt,[a,b,c,stride],4)
					if b=='GL_FLOAT':
						stride+=a*4
					else:
						print 'unknow:',b
						break
				count=g.i(1)[0]	
				print stride
				back1=g.tell()	
				vertCount=count*4/stride
				print 'vertCount:',vertCount
				mesh=Mesh()
				meshList.append(mesh)
				mesh.SPLIT=True
				#mesh.skeleton=skeletonList[k].name
				#print boneNameList
				for b in B:
					g.seek(back1)
					if b[0]=='VERTEX_ATTRIB_POSITION':
						for m in safe(vertCount):
							t=g.tell()
							g.seek(t+b[1])
							mesh.vertPosList.append(g.f(3))
							g.seek(t+stride)
					if b[0]=='VERTEX_ATTRIB_TEX_COORD':
						for m in safe(vertCount):
							t=g.tell()
							g.seek(t+b[1])
							mesh.vertUVList.append(g.f(2))
							g.seek(t+stride)	
					if b[0]=='VERTEX_ATTRIB_BLEND_WEIGHT':
						for m in safe(vertCount):
							t=g.tell()
							g.seek(t+b[1])
							mesh.skinWeightList.append(g.f(4))
							g.seek(t+stride)	
					if b[0]=='VERTEX_ATTRIB_BLEND_INDEX':
						for m in safe(vertCount):
							t=g.tell()
							g.seek(t+b[1])
							C=g.f(4)
							#group1=boneNameList[int(C[0])]
							#group2=boneNameList[int(C[1])]
							#group3=boneNameList[int(C[2])]
							#group4=boneNameList[int(C[3])]
							#mesh.skinGroupList.append([group1,group2,group3,group4])
							mesh.skinIndiceList.append([int(C[0]),int(C[1]),int(C[2]),int(C[3])])
							g.seek(t+stride)
				g.seek(back1+count*4)
				subMeshCount=g.i(1)[0]
				allMatsCount+=subMeshCount
				write(txt,['subMeshCount:',subMeshCount],4)
				for m in safe(vertCount):
					mesh.skinIDList.append([0]*subMeshCount)
				for m in safe(subMeshCount):
					skin=Skin()
					mesh.skinList.append(skin)	
					#boneNameList=boneNamesList[id]
					#skin.boneMap=range(len(mesh.boneNameList),len(mesh.boneNameList)+len(boneNameList))
					#mesh.boneNameList.extend(boneNameList)
					id+=1
					mat=Mat()
					mat.TRIANGLE=True
					mesh.matList.append(mat)
					name=g.word(g.i(1)[0])
					mat.name=name	
					indiceCount=g.i(1)[0]
					write(txt,[m,name,'indiceCount:',indiceCount],8)	
					back1=g.tell()
					mat.IDStart=len(mesh.indiceList)
					mat.IDCount=indiceCount
					indiceList=g.H(indiceCount)
					mesh.indiceList.extend(indiceList)
					g.seek(back1+indiceCount*2)
					for indice in indiceList:
						mesh.skinIDList[indice][m]=1
					g.f(6)
				#mesh.TRIANGLE=True	
				#mesh.draw()
		g.seek(back)
	
	model.meshList=meshList	
	for node in nodeList:
		print node
		for mesh in model.meshList:
			#for i in range(len(mesh.vertPosList)):
			#	mesh.vertPosList[i]=Vector(mesh.vertPosList[i])*Matrix4x4(node[0])
			for i,mat in enumerate(mesh.matList):
				if node[2]==mat.name:
					#mat.matrix=Matrix4x4(node[0])
					mesh.boneNameList.extend(node[4])
					for boneName in node[4]:
						mesh.skinList[i].boneMap.append(mesh.boneNameList.index(boneName))
	
	model.getMat()
	#model.draw()	
	for mesh in model.meshList:					
		mesh.draw()
			#for mat in mesh.matList:
			#	mat.object.setMatrix(mat.matrix)
			
		
	#for i,mesh in enumerate(meshList):
	#	for mat in mesh.matList:
	#		if mat.object:
	#			skeletonList[i].object.makeParentDeform([mat.object],1,0)
		
	g.logWrite(['current offset:',g.tell()])	
	g.debug=True
	g.tell()
	
		

	
	
def c3bAnimationParser(filename,g):


	
	action=Action()
	action.BONESORT=True
	action.BONESPACE=True

	def getChildren(parent):
		bone=Bone()
		bone.parentName=parent.name
		skeleton.boneList.append(bone)
		bone.name=g.word(g.i(1)[0])	
		g.B(1)
		bone.matrix=Matrix4x4(g.f(16))	
		g.i(1)[0]
		for n in safe(g.i(1)[0]):
			getChildren(bone)

	a=g.B(6)
	write(txt,a,0)
	sectionCount=g.i(1)[0]
	boneNamesList=[]
	skeletonList=[]
	meshList=[]
	id=0
	nodeList=[]
	diffuseList=[]
	for i in safe(sectionCount):
		sectionName=g.word(g.i(1)[0])
		unk,offset=g.i(2)
		back=g.tell()
		g.seek(offset)
		#if sectionName=='DL_Body_meshnode':
		write(txt,[unk,offset,sectionName],0)
		if unk==3:
			action.name=g.word(g.i(1)[0])
			g.f(1)
			boneCount=g.i(1)[0]
			for k in safe(boneCount):
				bone=ActionBone()				
				action.boneList.append(bone)
				bone.name=g.word(g.i(1)[0])
				print 'bone:',bone.name
				frameCount=g.i(1)[0]
				for m in safe(frameCount):
					#try:
					time=int(g.f(1)[0]*120)
					#except:
					#	time=0
					flag=g.B(1)[0]
					if flag==7:
						rot=g.f(4)
						scale=g.f(3)
						#bone.sizeKeyList.append(VectorScaleMatrix(scale))
						#bone.sizeFrameList.append(time)
						pos=g.f(3)
						bone.posKeyList.append(VectorMatrix(pos))
						bone.rotKeyList.append(QuatMatrix(Quaternion(rot)).resize4x4())
						bone.posFrameList.append(time)
						bone.rotFrameList.append(time)
						#bone.matrixFrameList.append(time)
						#matrix=VectorScaleMatrix(scale)*QuatMatrix(Quaternion(rot)).resize4x4()*VectorMatrix(pos)
						#bone.matrixKeyList.append(matrix)
					elif flag==5:
						rot=g.f(4)
						bone.rotKeyList.append(QuatMatrix(Quaternion(rot)).resize4x4())
						bone.rotFrameList.append(time)
						pos=g.f(3)
						bone.posKeyList.append(VectorMatrix(pos))
						bone.posFrameList.append(time)
						#bone.matrixFrameList.append(time)
						#matrix=QuatMatrix(Quaternion(rot)).resize4x4()*VectorMatrix(pos)
						#bone.matrixKeyList.append(matrix)
					elif flag==3:
						rot=g.f(4)
						bone.rotKeyList.append(QuatMatrix(Quaternion(rot)).resize4x4())
						bone.rotFrameList.append(time)
						scale=g.f(3)
						#bone.sizeKeyList.append(VectorScaleMatrix(scale))
						#bone.sizeFrameList.append(time)
						#bone.matrixFrameList.append(time)
						#matrix=VectorScaleMatrix(scale)*QuatMatrix(Quaternion(rot)).resize4x4()
						#bone.matrixKeyList.append(matrix)
					elif flag==4:
						pos=g.f(3)
						bone.posKeyList.append(VectorMatrix(pos))
						bone.posFrameList.append(time)
						#bone.matrixFrameList.append(time)
						#matrix=VectorMatrix(pos)
						#bone.matrixKeyList.append(matrix)
					elif flag==1:
						rot=g.f(4)
						bone.rotKeyList.append(QuatMatrix(Quaternion(rot)).resize4x4())
						bone.rotFrameList.append(time)
						#bone.matrixFrameList.append(time)
						#matrix=QuatMatrix(Quaternion(rot)).resize4x4()
						#bone.matrixKeyList.append(matrix)
					elif flag==6:
						scale=g.f(3)
						#bone.sizeKeyList.append(VectorScaleMatrix(scale))
						#bone.sizeFrameList.append(time)
						pos=g.f(3)
						bone.posKeyList.append(VectorMatrix(pos))
						bone.posFrameList.append(time)
						#bone.matrixFrameList.append(time)
						#matrix=VectorScaleMatrix(scale)*VectorMatrix(pos)
						#bone.matrixKeyList.append(matrix)
					elif flag==2:
						scale=g.f(3)
						#bone.sizeKeyList.append(VectorScaleMatrix(scale))
						#bone.sizeFrameList.append(time)
						#bone.matrixFrameList.append(time)
						#matrix=VectorScaleMatrix(scale)
						#bone.matrixKeyList.append(matrix)
					else:
						break
			
		if unk==2:
			nodeCount=g.i(1)[0]
			for m in safe(nodeCount):
				#g.logWrite('='*20+str(m))
				write(txt,[m,':',g.tell()],0)
				a=g.word(g.i(1)[0])
				b=g.B(1)[0]
				write(txt,[a,b],4)
				if b==1:
					c=g.f(16)
					d=g.i(1)[0]
					name1=g.word(g.i(1)[0])
					name2=g.word(g.i(1)[0])
					boneCount=g.i(1)[0]
					write(txt,[c],4)
					write(txt,[d],4)
					write(txt,[name1,name2],4)
					write(txt,['boneCount:',boneCount],4)
					boneNames=[]
					for m in safe(boneCount):
						name=g.word(g.i(1)[0])
						g.f(16)
						boneNames.append(name)
						write(txt,[name],8)
					boneNamesList.append(boneNames)	
					nodeList.append([c,d,name1,name2,boneNames])
					e=g.i(3)
					f=g.i(e[0])
					write(txt,[e,f],4)
				if b==0:	
					c=g.f(16)
					d=g.i(1)[0]
					write(txt,[c],4)
					write(txt,[d],4)
					global skeleton 
					skeleton=Skeleton()
					skeletonList.append(skeleton)
					#skeleton.NICE=True
					bone=Bone()
					skeleton.boneList.append(bone)
					bone.name=a
					bone.matrix=Matrix4x4(c)
					for n in safe(g.i(1)[0]):
						getChildren(bone)
					#skeleton.draw()	
			write(txt,[g.tell()],0)
		
		
		g.seek(back)
		
	scene = bpy.data.scenes.active
	for object in scene.objects:
		if object.getType()=='Armature':
			action.skeleton=object.name
			action.draw()
			action.setContext()	
		
	g.logWrite(['current offset:',g.tell()])	
	g.debug=True
	g.tell()
	
	
def bonesParser(filename,g):
	while(True):
		if g.tell()==g.fileSize():
			break
		boneCount=g.i(1)[0]
		skeleton=Skeleton()
		for m in safe(boneCount):
			bone=Bone()
			bone.name=g.find('\x00')
			bone.matrix=Matrix4x4(g.f(16)).invert()
			skeleton.boneList.append(bone)
		skeleton.draw()	
		
	
def cczParser(filename,g):
	g.word(4)
	g.i(3)
	new=open(filename.split('.ccz')[0],'wb')
	new.write(zlib.decompress(g.read(g.fileSize()-16)))
	new.close()
		
	
def Parser(filename):
	global txt,p
	bindBones=open('bindbones.bones','wb')
	p=BinaryReader(bindBones)
	
	txt=open('log.txt','w')
	os.system('cls')
	sys=Sys(filename)
	if sys.ext=='c3b':
		if 'skin' in filename.lower():
			sys.parseFile(c3bSkinParser,'rb',log=1)
		else:	
			sys.parseFile(c3bAnimationParser,'rb',log=1)
	if sys.ext=='ccz':
		sys.parseFile(cczParser,'rb',log=1)
	if sys.ext=='bones':
		sys.parseFile(bonesParser,'rb',log=1)
		
	txt.close()
	bindBones.close()
 

	
Blender.Window.FileSelector(Parser,'import','Avengers Academy files: *.c3b - model') 
	