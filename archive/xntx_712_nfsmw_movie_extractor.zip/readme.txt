
Go to NFSMW Dir\M;OVIES\ and copy the wanted movie files into the directory where all your
files from the zip-file are located.
Then run "convert.bat"

All vp6 files will now be converted to .avi files. To watch them, you need the VP6 Codec.
To install just double-click on "vp6_decoder.exe"

---
http://www.nfsplanet.com