# Test
# Noesis script by Dave, 2021

from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Test",".bm")
	noesis.setHandlerTypeCheck(handle, bcCheckType)
	noesis.setHandlerLoadModel(handle, bcLoadModel)
	return 1

# Check file type

def bcCheckType(data):
	bs = NoeBitStream(data)
	file_id = bs.readBytes(4).decode("utf-8")

	if file_id != "MESH":
		return 0
	else:
		return 1


# Read the model data

def bcLoadModel(data, mdlList):
	bs = NoeBitStream(data)
	ctx = rapi.rpgCreateContext()

	bs.seek(0x18)
	submesh_count = bs.readUInt()

	bs.seek(0x24)
	total_verts = bs.readUInt()
	text_len = bs.readUInt()
	text1 = bs.readBytes(text_len).decode("utf-8")
	bs.readBytes(8)
	vert_table = bs.tell()
	norm_table = vert_table + (total_verts * 12)
	uv_table = norm_table + (total_verts * 12)
	bs.seek(uv_table)
	text_len = bs.readUInt()
	text2 = bs.readBytes(text_len).decode("utf-8")
	uv_table = bs.tell()
	submesh_start = uv_table + (total_verts * 8)

	for s in range(submesh_count):
		bs.seek(submesh_start)
		text_len = bs.readUInt()
		mesh_name = bs.readBytes(text_len).decode("utf-8")
		misc1 = bs.readUInt()
		start_vert = bs.readUInt()
		vert_count = bs.readUInt()
		tri_count = bs.readUInt()
		faces = bs.readBytes(tri_count * 6)

		misc1 = bs.readUInt()
		bs.readBytes(misc1)
		bs.readBytes(20)
		text_len = bs.readUInt()
		misc_text = bs.readBytes(text_len).decode("utf-8")
		text_len = bs.readUInt()
		misc_text = bs.readBytes(text_len).decode("utf-8")
		bs.readBytes(12)

		submesh_start = bs.tell()

		bs.seek(vert_table + (start_vert * 12))
		vertices = bs.readBytes(vert_count * 12)
		bs.seek(norm_table + (start_vert * 12))
		normals = bs.readBytes(vert_count * 12)
		bs.seek(uv_table + (start_vert * 8))
		uvs = bs.readBytes(vert_count * 8)

		rapi.rpgSetName(mesh_name)
		rapi.rpgBindPositionBuffer(vertices, noesis.RPGEODATA_FLOAT, 12)
		rapi.rpgBindNormalBuffer(normals, noesis.RPGEODATA_FLOAT, 12)
		rapi.rpgBindUV1Buffer(uvs, noesis.RPGEODATA_FLOAT, 8)
		rapi.rpgCommitTriangles(faces, noesis.RPGEODATA_USHORT, tri_count * 3, noesis.RPGEO_TRIANGLE)
		rapi.rpgClearBufferBinds()

	mdl = rapi.rpgConstructModel()
	mdlList.append(mdl)

	return 1


