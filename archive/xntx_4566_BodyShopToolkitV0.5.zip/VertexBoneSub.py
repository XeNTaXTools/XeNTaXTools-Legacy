#Body Shop - Vertex Bone Sub (PC Only)
#Substitutes & Updates all bone values from source mesh countainer to target mesh container
 
#sourceTMC                          #String: Container that provides the vertices/indices                               
#targetTMC                          #String: Container verts/indices that will be added to
#vertsSource                        #String: Vertices to operate on, Text File
#boneSubFile                        #String: Bone Sub List, Leave Blank if no subs intended
#sourceBufferLength                 #Int: Number of Buffer Entries in Vertex, PC

#boneIndexNames                     #List: Add Entry only if a non standard name for body mesh

#Note: Current version only supports h64/d16 vertex buffer length, to be updated in the future
#Note: Bone Sub List File should have all entries on an individual line in the format of SourceBoneName|TargetBoneName

sourceTMC = 'x.TMC'   
targetTMC = 'y.TMC'      

vertsSource = 'x.txt'      
boneSubFile = ''                                        

sourceBufferLength = 16                                 

boneIndexNames = ('WGT_body','WGT_body1','WGT_fuku')    

#################################

from struct import *
from BodyShopUtils import *

#################################

sourceFile = open(sourceTMC,'rb')
targetFile = open(targetTMC,'rb')

vertsHexByteArraySource = ReadFileToByteArray(vertsSource)

boneSubArray = []

if (boneSubFile != ''):
    boneSubArray = ReadBoneSubToArray(boneSubFile)

#Read Source Bone Index

boneIndexSource = ReturnBoneIndex(sourceFile,boneIndexNames)
boneIndexTarget = ReturnBoneIndex(targetFile,boneIndexNames)

#Read Bone Names
boneNamesSource = ReadBoneNamesToArray(sourceFile)
boneNamesTarget = ReadBoneNamesToArray(targetFile)

#Flip, Group Verts
vertsFlippedSource = FlipData(vertsHexByteArraySource,4,True)
vertsGroupedSource = GroupVertices(vertsFlippedSource, sourceBufferLength)

#Add case statement based on buffer length

if (sourceBufferLength == 16):
    bufferIndexBoneWeight = 6
    bufferIndexBoneId = 7
elif (sourceBufferLength == 15):
    bufferIndexBoneWeight = 6
    bufferIndexBoneId = 7
    pass
elif (sourceBufferLength == 14):
    bufferIndexBoneWeight = 6
    bufferIndexBoneId = 7
    pass
elif (sourceBufferLength == 13):
    bufferIndexBoneWeight = 6
    bufferIndexBoneId = 7
    pass
elif (sourceBufferLength == 12):
    bufferIndexBoneWeight = 6
    bufferIndexBoneId = 7	
    pass

#Loop through Source Verts

for vertexBuffer in vertsGroupedSource:
    
    boneWeights = SplitString(vertexBuffer[bufferIndexBoneWeight],2)
    boneIds = SplitString(vertexBuffer[bufferIndexBoneId],2)
    
    boneIdPosition = 0
    boneIdsUpdated = []
    
    for boneId in boneIds:

        #Only process if there is a boneId with a weight
        if (boneId == '00' and boneWeights[boneIdPosition] == '00') == False:            

            #Attempt to find the value from the vertex in the Source Bone Index
            try:                
                vertexBoneIdSource = boneIndexSource[int(boneId,16)]
            except:
                vertexBoneIdSource = -1

            #Match Found
            if (vertexBoneIdSource != -1):

                #Find Source Bone Name
                boneNameSource = boneNamesSource[vertexBoneIdSource]['boneName']
                
                if (len(boneSubArray) > 0):
                    for boneName in boneSubArray:
                        if (boneName['boneSubSource'] == boneNameSource):
                            boneNameSource = boneName['boneSubSource']
                            break

                #Find Matching Bone in Target Bone Names
                boneNameTargetIndex = -1
                try:
                    boneNameTargetIndex = next(key for (key, value) in enumerate(boneNamesTarget) if value['boneName'] == boneNameSource)
                except:
                    pass

                #Find Target BoneId in Target Bone Names
                boneIdTarget = -1
                if (boneNameTargetIndex != -1):
                    boneIdTarget = boneNamesTarget[boneNameTargetIndex]['boneId']
                                
                #Find VertexBoneId in Target Bone Index
                if (boneIdTarget != -1):
                    vertexBoneIdTarget = boneIndexTarget.index(boneIdTarget)

            #Add Updated value to Buffer Set
            boneIdsUpdated.append(ConvertIntToHexByte(vertexBoneIdTarget,2))
        else:
            #Add Unchanged value to Buffer Set
            boneIdsUpdated.append(boneId)
        
        boneIdPosition += 1
        
    #Put BoneIds back into group
    #Replace Old Ids with Updated Ids
    vertexBuffer[bufferIndexBoneId] = JoinData(boneIdsUpdated,4)[0]

#Convert back to Hex Byte Array
vertsUngrouped = UngroupVertices(vertsGroupedSource)

#'Unflip' for PC Format
vertsFlipped = FlipData(vertsUngrouped,4)

#Write to File
WriteByteArrayToFile(vertsFlipped, vertsSource,'vertexBoneSub','txt')

#Cleanup
sourceFile.close()
targetFile.close()
