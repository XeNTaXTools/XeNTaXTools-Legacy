import os
from struct import *

#Conversion - Large
def FlipData(dataToFlip, interval, groupByInterval=False):
    flippedData = []
    
    counter = 0
    dataLength = len(dataToFlip)
    
    while counter < dataLength:

        segmentCounter = counter + interval
        groupString = ''
        while segmentCounter > counter:
            segmentCounter = segmentCounter - 1

            if (groupByInterval):
                groupString = groupString + dataToFlip[segmentCounter]
            else:
                flippedData.append(dataToFlip[segmentCounter])
        
        if (groupByInterval):
            flippedData.append(groupString)
            
        counter = counter + interval    
    
    return flippedData

def JoinData(dataToGroup, interval):
    groupedData = []

    counter = 0
    dataLength = len(dataToGroup)
    
    while counter < dataLength:

        segmentCounter = counter
        groupString = ''
        while segmentCounter < counter + interval:
            
            groupString = groupString + dataToGroup[segmentCounter]
            
            segmentCounter = segmentCounter + 1
            
        groupedData.append(groupString)
            
        counter = counter + interval    
    
    return groupedData

def SplitData(dataToSplit, interval):

    splitDataValues = []
    
    for byteString in dataToSplit:
        index = 0
        while index < interval:
            splitDataValues.append(byteString[2 * index:(2 * index) + 2])
            index += 1

    return splitDataValues

def SplitString(stringToSplit,interval):
    splitStringValues = []

    index = 0

    while index < (len(stringToSplit)/interval):
        splitStringValues.append(stringToSplit[2 * index:(2 * index) + 2])
        index += 1

    return splitStringValues

def ReadChunkAsByteArray(file,start,length):
    hexByteArray = []

    file.seek(start)
    data = file.read(length)

    for byte in data:
        hexByte = hex(byte)[2:].upper()
        if len(hexByte) < 2:
            hexByte = '0' + hexByte

        hexByteArray.append(hexByte)

    return hexByteArray



def ConvertChunkToByteArray(byteString):
    hexByteArray = []

    for byte in byteString:
        hexByte = format(byte, '#04x')
        hexByteArray.append(hexByte[2:].upper())

    return hexByteArray

def ConvertByteArrayToIntArray(hexByteArray):
    intArray = []

    for hexByte in hexByteArray:
        s = int(hexByte,16)

        intArray.append(s)    

    return intArray

#Conversion - Small

def ConvertByteStringToInt(byteStringValue, flip=False):

    hexByteArray = []

    for byte in byteStringValue:
        hexByte = hex(byte)[2:].upper()
        if len(hexByte) < 2:
            hexByte = '0' + hexByte

        hexByteArray.append(hexByte)

    if (flip):
        flippedByte = FlipData(hexByteArray, 4, True)
        return int(flippedByte[0],16)
    else:
        joinedByte = JoinData(hexByteArray,4)
        return int(joinedByte[0],16)

def ConvertByteStringToString(byteStringValue):

    stringValue = ''

    for byte in byteStringValue:
        stringValue += chr(byte)

    return stringValue.rstrip("\x00")

def ConvertIntToHexByte(intValue, length=8):
    hexByte = format(intValue,'#04x')[2:].upper()

    while len(hexByte) < length:
        hexByte = '0' + hexByte
        
    return hexByte

#File Input/Output
def ReadFileToByteArray(fileName):
    hexByteArray = []
    
    inputFile = open(fileName,'r')
    inputFileString = inputFile.read()
    inputFile.close()
    hexByteArray = inputFileString.split(' ')
    return hexByteArray

def WriteByteArrayToFile(hexByteArray, fileName, fileNameAppend, fileFormat):
    
    outputFile = open(fileName[:-4] + '_' + fileNameAppend + '.' + fileFormat,'w')
    
    for byte in hexByteArray:
        outputFile.write("%s " % byte)

    outputFile.close()

def WriteBytesToFile(byteString, fileName, fileNameAppend, fileFormat):
    outputFile = open(fileName[:-4] + '_' + fileNameAppend + '.' + fileFormat,'wb')
    outputFile.write(byteString)
    outputFile.close()

def ReturnFileSize(file):
    return(os.stat(file).st_size)

#TMC/TMCL Specific
def ReadBoneNamesToArray(file):
    boneNames = []

    #NodeLayOffset
    file.seek(352)
    nodeLayOffset = ConvertByteStringToInt(file.read(4), True)
    file.seek(nodeLayOffset + 20)
    nodeLayCount = ConvertByteStringToInt(file.read(4), True)

    file.seek(nodeLayOffset + 64)
    nodeLayIndexBytes = file.read(nodeLayCount * 4)
    nodeLayIndexByteArray = ConvertChunkToByteArray(nodeLayIndexBytes)
    nodeLayIndexByteArrayBE = FlipData(nodeLayIndexByteArray, 4, True)
    nodeLayIndexInt = ConvertByteArrayToIntArray(nodeLayIndexByteArrayBE)

    for offset in nodeLayIndexInt:
        #firstThree
        file.seek(nodeLayOffset + offset + 64)
        firstThree = ConvertByteStringToString(file.read(3))

        #Read line after, to test lines
        file.seek(nodeLayOffset + offset + 80)
        secondLineString = ConvertByteStringToString(file.read(7))

        #Bone Id
        file.seek(nodeLayOffset + offset + 56)
        boneId = ConvertByteStringToInt(file.read(4), True)

        if (firstThree ==  'WGT'):
            nameLength = 16
        else:
            if (secondLineString == 'NodeObj'):
                nameLength = 16
            else:
                nameLength = 32

        file.seek(nodeLayOffset + offset + 64)
        name = ConvertByteStringToString(file.read(nameLength))
        
        boneNames.append({'boneId': boneId, 'boneName': name})

    return boneNames
    
def ReturnMatchingBoneNameIndex(boneNameSource, targetBoneNames):

    for boneNameTarget in targetBoneNames:
        if (boneNameSource == boneNameTarget['boneName']):
            return boneNameTarget['boneId']
    
    return -1

def ReturnBoneIndex(file,boneNameIndex):
    file.seek(352)

    nodeLayOffset = ConvertByteStringToInt(file.read(4),True)

    file.seek(nodeLayOffset + 16)
    nodeLayLength = ConvertByteStringToInt(file.read(4),True)

    file.seek(nodeLayOffset)
    nodeLayDataBytes = file.read(nodeLayLength)
    nodeLayDataString = ConvertByteStringToString(nodeLayDataBytes)


    bodyIndexOffset = -1
    for boneName in boneNameIndex:
        indexSearch = nodeLayDataString.find(boneName)
        if (indexSearch != -1):
            bodyMeshName = boneName
            bodyIndexOffset = indexSearch
            break

    if (bodyIndexOffset != -1):
        file.seek(nodeLayOffset + bodyIndexOffset + 36)
        boneIndexCount = ConvertByteStringToInt(file.read(4),True)

        file.seek(nodeLayOffset + bodyIndexOffset + 112)
        boneIndexDataBytes = file.read(boneIndexCount * 4)
        boneIndexDataByteArray = ConvertChunkToByteArray(boneIndexDataBytes)
        boneIndexDataFlipped = FlipData(boneIndexDataByteArray, 4, True)
        boneIndexDataInt = ConvertByteArrayToIntArray(boneIndexDataFlipped)
        
    return boneIndexDataInt
    

def GroupVertices(sourceVerts, bufferLength):

    vertexIndex = 0
    verts = []

    while vertexIndex < len(sourceVerts):
    
        bufferCounter = vertexIndex
        bufferValues = []
    
        while bufferCounter < vertexIndex + bufferLength:
            bufferValues.append(sourceVerts[bufferCounter])
            bufferCounter += 1        
        
        verts.append(bufferValues)
    
        vertexIndex = vertexIndex + bufferLength

    return verts

def UngroupVertices(sourceVerts):
    vertexHexByteArray = []

    for vertexBuffer in sourceVerts:
        
        for bufferValue in vertexBuffer:
            
            splitValues = SplitString(bufferValue,2)
                        
            for value in splitValues:
                vertexHexByteArray.append(value)
            
    return vertexHexByteArray
