#Body Shop - Quick Ops (PC or Xbox 360)
#Adds single value to every value in an array and prints list for quick copy & paste
#Supports up to two lists

#sourceIsPC                             #Boolean: Affects Endian, True for PC, False for Xbox 360
#setA                                   #Array: Byte Values as ['00 00 00 00','00 00 00 00',...]
#setB                                   #Array: Byte Values as ['00 00 00 00','00 00 00 00',...]
#valueToAddA                            #Int: Value to Add (can be negative), Leave 0 otherwise
#valueToAddB                            #Int: Value to Add (can be negative), Leave 0 otherwise

sourceIsPC = True                       
setA = []                  
setB = []
valueToAddA =  0                   
valueToAddB = 0

#################################

from BodyShopUtils import *

#################################

def FlipStringBytes(valueString):

    characterList = []
    byteList = []
    finalList = []
    
    for character in valueString:
        characterList.append(character)

    characterIndex = 0
    
    while characterIndex < len(characterList):

        byteList.append(characterList[characterIndex] + characterList[characterIndex + 1])

        characterIndex = characterIndex + 2

    finalList = list(reversed(byteList))
    
    return finalList

def MergeListIntoString(valueList):

    combinedString = ''

    for byte in valueList:
        combinedString = combinedString + byte

    return combinedString

def SplitByteString(byteString):

    outValue = ''
    index = 0
    for value in byteString:
        outValue = outValue + value

        if index % 2 == 1:
            outValue = outValue + ' '
        
        index = index + 1
        
    return outValue

if len(setA) > 0:

    print('Set A')

    for entry in setA:
        entrySource = entry
        entryUpdated = ''
        entry = entry.replace(' ','')
        if sourceIsPC:
            entry = MergeListIntoString(FlipStringBytes(entry))

        entryInt = int(entry,16)

        entryInt = entryInt + valueToAddA

        entryUpdated = ConvertIntToHexByte(entryInt)

        if sourceIsPC:
             entryUpdated = MergeListIntoString(FlipStringBytes(entryUpdated))
        
        entryUpdated = SplitByteString(entryUpdated)

        print (entrySource + ' | ' + entryUpdated)
    
if len(setB) > 0:
    
    print('Set B')

    for entry in setB:
        entrySource = entry
        entryUpdated = ''
        entry = entry.replace(' ','')
        if sourceIsPC:
            entry = MergeListIntoString(FlipStringBytes(entry))

        entryInt = int(entry,16)
        
        entryInt = entryInt + valueToAddB    

        entryUpdated = ConvertIntToHexByte(entryInt)

        if sourceIsPC:
             entryUpdated = MergeListIntoString(FlipStringBytes(entryUpdated))
        
        entryUpdated = SplitByteString(entryUpdated)

        print (entrySource + ' | ' + entryUpdated)






