import getopt, sys, glob, io, binascii, os, fnmatch

def main(argv):
	global silent, verbose

	try:
		opts, args = getopt.getopt(argv, "hrsv", ["help","recursive","silent","verbose"])
	except getopt.GetoptError:
		usage()
		sys.exit(2)

	silent = 0
	verbose = 0
	recurse = 0

	for opt, arg in opts:
		if opt in ("-h", "--help"):
			usage()
			sys.exit()
		if opt in ("-r", "--recursive"):
			recurse = 1
		if opt in ("-s", "--silent"):
			silent = 1
		if opt in ("-v", "--verbose"):
			verbose = 1

	if not args: # Need at least one file name here, peeps
		usage()
		sys.exit()
		
	if silent and verbose:
		print ("I can't be silent and verbose at the same time")
		sys.exit()

	for arg in args:
		gargs = glob.glob(arg)
		if not gargs:
			if not silent:
				print ("File " + arg + " not found")
		else:
			for garg in gargs:
				if os.path.isdir(garg) and recurse:
					for file in locate("*.dds",garg):
						allgood = sanity_check(file)
						if allgood:
							patch(file)
						else:
							if not silent:
								try:
									print (file + " does not appear to be an Atlantica DDS file, skipping.")
								except:
									print ("Oh those Koreans, that filename made me burp")
				elif os.path.isfile(garg):
					allgood = sanity_check(garg)
					if allgood:
						patch(garg)
					else:
						if not silent:
							try:
								print (garg + " does not appear to be an Atlantica DDS file, skipping.")
							except:
								print ("Oh those Koreans, that filename made me burp")
				elif os.path.isdir(garg):
					if not silent:
						try:
							print (garg + " is a directory, did you mean to recurse?")
						except:
							print ("Oh those Koreans, that filename made me burp")
				else:
					if not silent:
						try:
							print (garg + " is not a regular file, skipping.")
						except:
							print ("Oh those Koreans, that filename made me burp")

def sanity_check(file): # See that the file conforms, loosely, to what we expect to see in an NDOORS DDS header
	result = 1 #Be optimistic, and change our mind if that was not warranted
	f = io.open(file, "rb", 0) # Open in binary mode read, do not buffer
	f.seek(0)
	if not f.read(4).decode() == "NDS@": # Should start with NDS@
		result = 0
	i = 4
	while (i <= 28):
		if int(binascii.hexlify(read_dword(f, i)),16) < 0xff107744: # We assume the magic number's been added, so no header field should be smaller
			result = 0
		i = i + 4
	f.close()
	return result

def patch(file):
	f = io.open(file, "r+b", 0) # Open in binary mode read-write, do not buffer
	if verbose:
		print ("Header values for " + file)

	# Write "DDS "
	f.seek(0) # Start of file
	f.write(bytes.fromhex('44445320')) # "DDS "
	# De-obfuscate the length - in a way this is silly, I could just write 124 decimal
	dword = read_dword(f, 4)
	idword = int(binascii.hexlify(dword),16) # make this into an int
	idword = idword - 0xff107744 # Subtract the magic number
	write_dword(f, 4, bytes.fromhex("%.8X" % idword)) # Format as hex string 8 chars wide, make into bytes, and write backwards-to-front
	if verbose:
		print ("Length: %.8X" % idword)

	# De-obfuscate the flags
	dword = read_dword(f, 8)
	idword = int(binascii.hexlify(dword),16) # make this into an int
	idword = idword - 0xff107744 # Subtract the magic number
	idword = idword | 0x0b # To get DDSD_WIDTH, as Ndoors sets 0111 instead of 1011
	write_dword(f, 8, bytes.fromhex("%.8X" % idword)) # Format as hex string 8 chars wide, make into bytes, and write backwards-to-front
	if verbose:
		print ("Flags: %.8X" % idword)

	# Now the next 5 dwords
	i = 12
	while (i <= 28):
		dword = read_dword(f,i)
		idword = int(binascii.hexlify(dword),16) # Again an int
		idword = idword - 0xff107744 # The magic number
		write_dword(f, i, bytes.fromhex("%.8X" % idword))
		if verbose:
			print ("Header field at %d" % i + ": %.8X" % idword)
		i = i + 4
	f.close()
	if not silent:
		try:
			print (file + " has been converted")
		except:
			print ("Oh those Koreans, that filename made me burp")		

def read_dword(file, offset): # Read a little-endian dword starting at offset - back to front. Returns a bytes object
	i = offset + 3
	result = bytes()
	while (i >= offset):
		file.seek(i)
		result += file.read(1)
		i = i - 1
	return result

def write_dword(file, offset, dword): # Write a little-endian dword starting at offset - back to front
	i = offset + 3
	j = 0
	while (i >= offset):
		file.seek(i)
		file.write(bytes.fromhex("%.2X" % dword[j]))
		i = i - 1
		j = j + 1
	return 0

def locate(pattern, root):
    for path, dirs, files in os.walk(root):
        for filename in [os.path.abspath(os.path.join(path, filename)) for filename in files if fnmatch.fnmatch(filename, pattern)]:
            yield filename

def usage():
	print ('This program will convert Atlantica Online .dds files to regular .dds files')
	print ('by de-obfuscating the header.')
	print ('It will in the process overwrite the original source file. DO NOT run this')
	print ('on your original game files, use a copy.')
	print ()
	print ("This program's options are:")
	print ()
	print ('ndoordds.py [-rsvh] [--recursive|silent|verbose|help] filename(s)...')
	print ()
	print ('-r 	Recurse into subdirectories, change all .dds files found within')
	print ('Use that one carefully :)')

if __name__ == "__main__":
    main(sys.argv[1:])
