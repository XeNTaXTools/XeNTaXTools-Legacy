from inc_noesis import *
import os

def registerNoesisTypes():
	handle = noesis.register("G.I.Joe: Rise of Cobra (PS3)", ".tfo")
	noesis.setHandlerTypeCheck(handle, GIJCheckType)
	noesis.setHandlerLoadRGBA(handle, GIJLoadRGBA)
	#noesis.logPopup()
	return 1

#check if it's this type based on the data
def GIJCheckType(data):
	bs = NoeBitStream(data)
	bs.seek(0x21, NOESEEK_ABS)
	Magic = bs.readBytes(3).decode("ASCII")
	if Magic != 'tfo':
		return 0
	return 1
	
def GIJLoadRGBA(data, texList):
	datasize = len(data) - 0xa5        
	bs = NoeBitStream(data)
	bs.setEndian(NOE_BIGENDIAN)
	bs.seek(0x29, NOESEEK_ABS)
	imgFmt = bs.readShort()
	bs.seek(0x45, NOESEEK_ABS)
	imgWidth = bs.readShort()            
	imgHeight = bs.readShort()           
	bs.seek(0xa5, NOESEEK_ABS)        
	data = bs.readBytes(datasize)      
	fileName = os.path.basename(rapi.getInputName())   #get file name + ext without path
	if "_n" in fileName:
		texFmt = noesis.NOESISTEX_DXT5
	#DXT1
	elif imgFmt == 2 or imgFmt == 0 or imgFmt == 0xa:
		texFmt = noesis.NOESISTEX_DXT1
	#DXT5
	elif imgFmt == 5:
		texFmt = noesis.NOESISTEX_DXT5
	#unknown, not handled
	else:
		print("WARNING: Unhandled image format " + repr(imgFmt) + " - " + repr(imgWidth) + "x" + repr(imgHeight) + " - " + repr(len(data)))
		return None
	texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
	return 1