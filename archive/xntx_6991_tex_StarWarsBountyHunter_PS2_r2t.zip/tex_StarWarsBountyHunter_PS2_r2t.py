from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Star Wars: Bounty Hunter [PS2]", ".r2t")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    if bs.readBytes(4) != b'\x72\x74\x78\x54': return 0
    return 1

def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.seek(0x54)
    imgWidth = bs.readUInt()
    imgHeight = bs.readUInt() * 2
    bs.seek(0x70)
    palData = []
    for i in range(8):                  #do this 8 times
       for j in range(32):              #read 1st 32 byte block of palette
          read = bs.readUByte()
          palData.append(read)
       bs.seek(0x20, NOESEEK_REL)
       for j in range(32):              #read 3rd 32 byte block of palette
          read = bs.readUByte()
          palData.append(read)
       bs.seek(-0x40, NOESEEK_REL)
       for j in range(32):              #read 2nd 32 byte block of palette
          read = bs.readUByte()
          palData.append(read)
       bs.seek(0x20, NOESEEK_REL)
       for j in range(32):              #read 4th 32 byte block of palette
          read = bs.readUByte()
          palData.append(read)
    palette = bytearray(palData)
    bs.seek(0x490)
    data = bs.readBytes(bs.getSize() - bs.tell())
    data = rapi.imageDecodeRawPal(data, palette, imgWidth, imgHeight, 8, "r8 g8 b8 p8")
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, noesis.NOESISTEX_RGBA32))
    return 1