from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Vampire Hurts", ".pic")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup(); print("The logPopup is still on in tex_pal.py")
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    if bs.readBytes(2) != b'\x08\xae': return 0
    return 1

def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    magic =  bs.readBytes(2)
    fileSize = bs.readUShort()
    bs.seek(0xa)
    dataOffset = bs.readUInt()
    bs.readInt()
    imgWidth = bs.readUInt()
    imgHeight = bs.readUInt()
    bs.readShort()
    imgFmt = bs.readUShort()
    if dataOffset > 0x36:
        bs.seek(0x36)
        palette = bs.readBytes(0x400)
        data = bs.readBytes(bs.getSize() - bs.tell())
        data = rapi.imageDecodeRawPal(data, palette, imgWidth, imgHeight, 8, "b8 g8 r8 p8")
    else:
        bs.seek(dataOffset)
        data = bs.readBytes(bs.getSize() - bs.tell())
        data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "b8 g8 r8")
    data = rapi.imageFlipRGBA32(data, imgWidth, imgHeight, 0, 1)
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, noesis.NOESISTEX_RGBA32))
    return 1