import newGameLib
reload(newGameLib)
from newGameLib import *
import Blender


	
	
class vertex_info:
	def __init__(self):
		vertex_info.vertex_element_offset=None
		vertex_info.vertex_count=None
		vertex_info.vertex_stride=None
		vertex_info.vertex_element_count=None
		vertex_info.vertex_element=None		

class indices_info:
	def __init__(self):
		self.offset=None
		self.icount=None
		self.istart=None
		self.vcount=None
		self.vstart=None
		self.matID=None
		self.skinID=None


def mktxParser(u,texPath):
	u.seek(-44,2)
	v=u.H(22)
	img=imageLib.Image()
	img.szer=v[0]
	img.wys=v[1]
	if v[7]==8:img.format='DXT1'
	elif v[7]==16:img.format='DXT1'
	elif v[7]==4:img.format='DXT1'
	elif v[7]==0:img.format='DXT1'
	elif v[7]==2:img.format='DXT1'
	elif v[7]==1:img.format='DXT1'
	else:
		print 'WARNING:image format for:',v[7]
	u.seek(0)
	img.data=u.read(u.fileSize()-48)
	img.name=texPath
	img.draw()
	
	
			
		
		
def binParser(p,mat):
	v=p.i(21)	
	p.seek(v[5])		
	p.seek(v[6])
	v1=p.i(29)	
	if v1[1]!=0:
		p.seek(v[5]+v1[1])#diff	
		texName=p.find('\x00')		
		texPath=p.dirname+os.sep+texName+'.mktx.tex'
		if os.path.exists(texPath)==True:
			mat.diffuse=p.dirname+os.sep+texName+'.mktx.dds'
			file=open(texPath,'rb')
			u=BinaryReader(file)			
			mktxParser(u,mat.diffuse)
			file.close()
	if v1[2]!=0:
		p.seek(v[5]+v1[2])#norm
		texName=p.find('\x00')		
		texPath=p.dirname+os.sep+texName+'.mktx.tex'
		if os.path.exists(texPath)==True:
			#mat.normal=p.dirname+os.sep+texName+'.mktx.dds'
			file=open(texPath,'rb')
			u=BinaryReader(file)			
			#mktxParser(u,mat.normal)
			file.close()		
	if v1[3]!=0:
		p.seek(v[5]+v1[3])#spec
		texName=p.find('\x00')		
		texPath=p.dirname+os.sep+texName+'.mktx.tex'
		#print texPath
		if os.path.exists(texPath)==True:
			#print 'file exists'
			#mat.specular=p.dirname+os.sep+texName+'.mktx.dds'
			file=open(texPath,'rb')
			u=BinaryReader(file)			
			#mktxParser(u,mat.specular)
			file.close()
			
		

def mdlParser(filename,g):
	vertex_info_list=[]
	indices_info_list=[]
	matList=[]
	boneMapList=[]
	
	g.word(4)
	v0=g.i(19)
	g.f(8)
	v1=g.i(12)
	
	
	
	skeleton=Skeleton()
	print 'SECTION 6'
	if v1[6]!=0:
		skeleton.ARMATURESPACE=True
		g.seek(v1[6])	
		A=g.i(10)
		if A[1]==13:
			g.seek(A[0])
			D=g.i(10)	
			g.seek(A[0]+D[1])
			for m in range(D[0]):
				bone=Bone()
				C=g.i(8)
				t=g.tell()
				g.seek(A[0]+C[6])
				bone.name=g.find('\x00')
				bone.parentID=C[4]
				g.seek(t)
				skeleton.boneList.append(bone)
			
			g.seek(A[0]+D[2])
			for m in range(D[0]):
				bone=skeleton.boneList[m]
				bone.matrix=Matrix4x4(g.f(16))
		elif A[1]==9:
			g.seek(A[4])
			D=g.i(10)	
			g.seek(A[4]+D[1])
			for m in range(D[0]):
				bone=Bone()
				C=g.i(8)
				t=g.tell()
				g.seek(A[4]+C[6])
				bone.name=g.find('\x00')
				bone.parentID=C[4]
				g.seek(t)
				skeleton.boneList.append(bone)
			
			g.seek(A[4]+D[2])
			print g.tell()
			for m in range(D[0]):
				bone=skeleton.boneList[m]
				bone.matrix=Matrix4x4(g.f(16))
		else:
			print 'WARNING:skeleton:',A
	skeleton.draw()	
	
	
	
	
	print 'SECTION 0'
	g.seek(v1[0])
	for m in range(v0[2]):
		t=g.tell()
		g.f(8)
		v2=g.i(8)
		g.seek(v2[4])
		g.find('\x00')
		g.seek(t+64)
	
	print 'SECTION 1'
	g.seek(v1[1])
	for m in range(v0[1]):
		t=g.tell()
		g.seek(g.i(1)[0])
		binName=g.find('\x00')
		binPath=g.dirname+os.sep+binName+'.min.bin'
		mat=Mat()
		if os.path.exists(binPath)==True:
			file=open(binPath,'rb')
			p=BinaryReader(file)			
			binParser(p,mat)
			file.close()
		matList.append(mat)
		g.seek(t+4)
		
	
	print 'SECTION 2'
	g.seek(v1[2])
	element_list=[]
	for m in range(v0[1]):
		v=g.i(v0[2])
		t=g.tell()
		list=[]
		for n in range(v0[2]):
			if v[n]!=0:
				g.seek(v[n])
				v2=g.i(3)
				v3=g.H(2)
				v4=g.i(12)
				#print '-'*4,v2,v3,v4
				info=indices_info()
				info.offset=None
				info.icount=v4[2]
				info.istart=v4[1]
				info.vcount=v4[3]
				info.vstart=v4[0]
				info.matID=m
				info.skinID=v3[1]
				list.append(info)
				
				j=4
				def tree(v2,j):
					j+=4
					t1=g.tell()
					g.seek(v2[2])
					v5=g.i(3)
					v6=g.H(2)
					v7=g.i(12)
					#print '-'*j,v5,v6,v7
					info=indices_info()
					info.offset=None
					info.icount=v7[2]
					info.istart=v7[1]
					info.vcount=v7[3]
					info.vstart=v7[0]
					info.matID=m
					info.skinID=v6[1]
					list.append(info)
					g.seek(t1)
					if v5[2]!=0:
						tree(v5,j)
						
				if v2[2]!=0:		
					tree(v2,j)		
				
				
				
				
		g.seek(t)
		element_list.append(list)
	indices_info_list=element_list	
	
	print 'SECTION 3'
	g.seek(v1[3])
	for m in range(v0[3]):
		t=g.tell()
		g.h(8)
		g.seek(t+16)
	
	print 'SECTION 4'
	g.seek(v1[4])
	for m in range(v0[4]):
		info=vertex_info()
		v2=g.i(8)
		t0=g.tell()
		g.seek(v2[0])
		v3=g.i(4)
		#print '-'*4,v3
		t1=g.tell()
		g.seek(v3[0])
		
		
		info.vertex_element_offset=v2[1]
		info.vertex_count=v2[3]
		info.vertex_stride=v3[2]
		info.vertex_element_count=v3[1]
		
		element_list=[]
		for n in range(v3[1]):
			#list=[]
			t2=g.tell()
			name=g.word(32)
			values=g.i(4)
			element_list.append([name,values])
			#print '-'*8,name,values
			g.seek(t2+48)
			#element_list.append(list)
		info.vertex_element=element_list
			
		g.seek(t1)		
		g.seek(t0)
		#print info.vertex_element
		vertex_info_list.append(info)
			
	print 'SECTION 5'
	g.seek(v1[5])
	v=g.i(4)#;print v
	indices_offset=v[0]
	indices_count=v[3]
	
	print 'SECTION 9'
	if v1[9]!=0:
		g.seek(v1[9])
		for m in range(v0[10]):
			t=g.tell()
			boneMapList.append(g.B(g.B(1)[0]))
			#print m,boneMapList[m]
			g.seek(t+257)
		
	
	g.tell()
	g.logClose()
	return vertex_info_list,indices_info_list,indices_offset,indices_count,matList,boneMapList,skeleton
	
	
	
def mdgParser(filename,g,vertex_info_list,indices_info_list,indices_offset,indices_count,matList,boneMapList,skeleton):
	g.word(4),g.i(3)
	vertex_position_list=[]
	faceslist=[]
	vertex_uv_list=[]
	skin_indices_list=[]
	skin_weights_list=[]
	for info in vertex_info_list:
		v_e_c=info.vertex_element_count
		#print '-'*4,v_e_c
		v_e_o=info.vertex_element_offset
		#print '-'*4,v_e_c
		v_c=info.vertex_count
		#print '-'*4,v_e_c
		v_s=info.vertex_stride
		#print '-'*4,v_e_c
		for m in range(v_e_c):
			g.seek(v_e_o)
			v_e=info.vertex_element[m]
			#print v_e
			if v_e[0]=='position':
				for k in range(v_c):
					t=g.tell()
					g.seek(t+v_e[1][0])
					vertex_position_list.append(g.f(3))
					g.seek(t+v_s)
			if v_e[0]=='uv':
				for k in range(v_c):
					t=g.tell()
					g.seek(t+v_e[1][0])
					vertex_uv_list.append(g.f(2))
					g.seek(t+v_s)
					
			if v_e[0]=='uv0':
				for k in range(v_c):
					t=g.tell()
					g.seek(t+v_e[1][0])
					vertex_uv_list.append(g.f(2))
					g.seek(t+v_s)
					
			if v_e[0]=='uv_0':
				for k in range(v_c):
					t=g.tell()
					g.seek(t+v_e[1][0])
					vertex_uv_list.append(g.f(2))
					g.seek(t+v_s)
					
			if v_e[0]=='map1':
				for k in range(v_c):
					t=g.tell()
					g.seek(t+v_e[1][0])
					vertex_uv_list.append(g.f(2))
					g.seek(t+v_s)
					
			if v_e[0]=='diffuse' and v_e[1][2]==5:
				for k in range(v_c):
					t=g.tell()
					g.seek(t+v_e[1][0])
					vertex_uv_list.append(g.f(2))
					g.seek(t+v_s)
					
			if v_e[0]=='skinIndices':
				for k in range(v_c):
					t=g.tell()
					g.seek(t+v_e[1][0])
					skin_indices_list.append(g.B(4))					
					g.seek(t+v_s)
					
			if v_e[0]=='skinWeights':
				for k in range(v_c):
					t=g.tell()
					g.seek(t+v_e[1][0])
					skin_weights_list.append(g.B(4))					
					g.seek(t+v_s)
	g.seek(indices_offset)
	indices=g.H(indices_count)				
			

	#skeleton=Skeleton()
	#skeleton.draw()	
	for m in range(len(indices_info_list)):
		info=indices_info_list[m]
		for n in range(len(info)):
			mesh=Mesh()
			#print '-'*4,n,
			data=info[n]
			icount=data.icount
			istart=data.istart
			vcount=data.vcount
			vstart=data.vstart
			matID=data.matID
			mat=Mat()
			mat.TRIANGLE=True
			mesh.matList.append(mat)	
			mat.diffuse=matList[matID].diffuse
			mat.normal=matList[matID].normal
			mat.specular=matList[matID].specular
			#print icount,istart,vcount,vstart,matID
			mesh.vertPosList=vertex_position_list[vstart:vstart+vcount]
			mesh.vertUVList=vertex_uv_list[vstart:vstart+vcount]
	
			mesh.indiceList=indices[istart:istart+icount]
			if len(skin_indices_list)>0 and len(skin_weights_list)>0:
				skin=Skin()
				skin.boneMap=boneMapList[data.skinID]
				mesh.skinIndiceList=skin_indices_list[vstart:vstart+vcount]
				mesh.skinWeightList=skin_weights_list[vstart:vstart+vcount]
				#make_vertex_group(skin_indices,skin_weights,m)
				mesh.skinList.append(skin)
				mesh.boneNameList=skeleton.boneNameList
			mesh.BINDSKELETON=skeleton.name	
			mesh.draw()
			
	
	
	
def Parser():	
	
	filename=input.filename
	
	print
	print filename
	print
	
	
	ext=filename.split('.')[-1].lower()	
	
	
	if ext=='mdl':
		file=open(filename,'rb')
		g=BinaryReader(file)
		vertex_info_list,indices_info_list,indices_offset,indices_count,matList,boneMapList,skeleton=mdlParser(filename,g)
		file.close()
		
		mdgPath=filename.replace('.mdl','.mdg')
		file=open(mdgPath,'rb')
		g=BinaryReader(file)
		mdgParser(filename,g,vertex_info_list,indices_info_list,indices_offset,indices_count,matList,boneMapList,skeleton)
		file.close()
	
 
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
	 
	 
	 
Blender.Window.FileSelector(openFile,'import','mdl - model') 
	 