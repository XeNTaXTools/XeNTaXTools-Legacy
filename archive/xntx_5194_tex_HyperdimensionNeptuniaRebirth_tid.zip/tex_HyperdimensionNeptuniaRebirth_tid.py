from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Hyperdimension Neptunia Rebirth", ".tid")
	noesis.setHandlerTypeCheck(handle, HNRCheckType)
	noesis.setHandlerLoadRGBA(handle, HNRLoadRGBA)
	#noesis.logPopup()
	return 1

#check if it's this type based on the data
def HNRCheckType(data):
	bs = NoeBitStream(data)
	Header = bs.readBytes(3).decode("ASCII")
	if Header != 'TID':
		return 0
	return 1
	
def HNRLoadRGBA(data, texList):
	datasize = len(data) - 0x80        
	bs = NoeBitStream(data)
	bs.seek(0x44, NOESEEK_ABS)
	imgWidth = bs.readInt()            
	imgHeight = bs.readInt()           
	bs.seek(0x64, NOESEEK_ABS)        
	imgFmt = bs.readInt()              
	bs.seek(0x78, NOESEEK_ABS)        
	subFmt = bs.readInt()              
	bs.seek(0x80, NOESEEK_ABS)        
	data = bs.readBytes(datasize)      
	#DXT1
	if imgFmt == 0x33545844 or imgFmt == 0x44585433:
		texFmt = noesis.NOESISTEX_DXT1
	#DXT5
	elif imgFmt == 0x35545844 or imgFmt == 0x44585435:
		texFmt = noesis.NOESISTEX_DXT5
	#RGBA32
	elif imgFmt == 0x00000000 and subFmt == 0x00000000:
		data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "a8 r8 g8 b8")
		texFmt = noesis.NOESISTEX_RGBA32
	elif imgFmt == 0x00000000 and subFmt != 0x00000000:
		data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "r8 g8 b8 a8")
		texFmt = noesis.NOESISTEX_RGBA32
	#unknown, not handled
	else:
		print("WARNING: Unhandled image format")
		return None
	texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
	return 1