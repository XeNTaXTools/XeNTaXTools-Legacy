from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Mafia 2 (X360)", ".dat")
	noesis.setHandlerTypeCheck(handle, M2CheckType)
	noesis.setHandlerLoadRGBA(handle, M2LoadRGBA)
	#noesis.logPopup()
	return 1

#check if it's this type based on the data
def M2CheckType(data):
	bs = NoeBitStream(data)
	bs.seek(0x1e, NOESEEK_ABS)
	Magic = bs.readBytes(4).decode("ASCII")
	if Magic != 'DDS\x20':
		return 0
	return 1
	
def M2LoadRGBA(data, texList):
	datasize = len(data) - 0x9e        
	bs = NoeBitStream(data)
	bs.setEndian(NOE_BIGENDIAN)
	bs.seek(0x2a, NOESEEK_ABS)
	imgWidth = bs.readInt()            
	imgHeight = bs.readInt()           
	bs.seek(0x72, NOESEEK_ABS)
	imgFmt = bs.readByte()             
	bs.seek(0x9e, NOESEEK_ABS)        
	data = bs.readBytes(datasize)      
	data = rapi.swapEndianArray(data, 2)
	#DXT1
	if imgFmt == 0x31:
		texFmt = noesis.NOESISTEX_DXT1
	#DXT5
	elif imgFmt == 0x35:
		texFmt = noesis.NOESISTEX_DXT5
	#unknown, not handled
	else:
		print("WARNING: Unhandled image format")
		return None
	texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
	return 1