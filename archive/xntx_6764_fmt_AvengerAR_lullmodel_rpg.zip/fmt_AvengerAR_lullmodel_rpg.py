# Playground: Marvel Studios' Avengers: Endgame lullmodel importer by Bigchillghost

import rapi
from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Playground: Marvel Studios' Avengers: Endgame", ".lullmodel")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadModel(handle, noepyLoadModel)
	#noesis.logPopup()
	return 1

#check if it's this type based on the data
def noepyCheckType(data):
	if len(data) < 0x80:
		return 0
	bs = NoeBitStream(data)
	Magic = bs.readBytes(4)
	if Magic != b'\x1C\x00\x00\x00':
		noesis.logPopup()
		return 0
	return 1

#load the model
def noepyLoadModel(data, mdlList):
	bs = NoeBitStream(data)
	bs.seek(0x20, NOESEEK_ABS)
	SkipSize = bs.readUInt()
	MtlChunkOffset = bs.tell()
	MtlChunkOffset += bs.readUInt()
	bs.seek(MtlChunkOffset + 4, NOESEEK_ABS)
	SkipSize = bs.readUInt()
	bs.seek(SkipSize - 4, NOESEEK_REL)
	SkipSize = bs.readUInt()
	bs.seek(SkipSize - 8, NOESEEK_REL)
	FIoffset = bs.tell()
	FIoffset += bs.readUInt()
	Voffset = bs.tell()
	Voffset += bs.readUInt()
	Vcount = bs.readUInt()
	Vcount = bs.readUInt()
	bs.seek(FIoffset, NOESEEK_ABS)
	FIcount = bs.readUInt()
	TypeSize = 2
	if Vcount > 0xFFFF:
		TypeSize = 4
	idxList = bs.readBytes(FIcount * TypeSize)
	bs.seek(Voffset, NOESEEK_ABS)
	meshes = []
	Vsize = bs.readUInt()
	Vbuf = bs.readBytes(Vsize)
	structSize = Vsize // Vcount
	UVpos = 0xC
	NMpos = 0x14
	if structSize == 0x3C:
		UVpos += 4
		NMpos += 4
	ctx = rapi.rpgCreateContext()
	rapi.rpgSetName('mesh')
	rapi.rpgBindPositionBuffer(Vbuf, noesis.RPGEODATA_FLOAT, structSize)
	rapi.rpgBindNormalBufferOfs(Vbuf, noesis.RPGEODATA_FLOAT, structSize, NMpos)
	rapi.rpgBindUV1BufferOfs(Vbuf, noesis.RPGEODATA_FLOAT, structSize, UVpos)
	
	if Vcount > 0xFFFF:
		rapi.rpgCommitTriangles(idxList, noesis.RPGEODATA_INT, FIcount, noesis.RPGEO_TRIANGLE, 0)
	else:
		rapi.rpgCommitTriangles(idxList, noesis.RPGEODATA_USHORT, FIcount, noesis.RPGEO_TRIANGLE, 0)
	rapi.rpgClearBufferBinds()
	
	mdl = rapi.rpgConstructModel()
	mdlList.append(mdl)
	#rapi.setPreviewOption("setAngOfs", "0 -90 0")
	return 1
