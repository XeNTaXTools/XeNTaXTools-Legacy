'''Noesis import plugin. Originally written by Giay Nhap and heavily newbified by Acewell :)'''

from inc_noesis import *
import noesis
import rapi

def registerNoesisTypes():
    handle = noesis.register("Truy Kich", ".wmdl")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    return 1

def noepyLoadModel(data, mdlList):
    ctx = rapi.rpgCreateContext()
    bs = NoeBitStream(data)
    fileName = rapi.getLocalFileName(rapi.getInputName())
    matList = []
    nextSubmesh = 1
    while nextSubmesh != 0:
        version = bs.readUInt()              #version 4 0x0
        bs.seek(4, NOESEEK_REL)              #0x08      
        numVerts = bs.readUInt()             #8091  
        bs.seek(4, NOESEEK_REL)              #0x10
        sizeofvBlock = bs.readUInt()         #0x471cc
        bs.seek(8, NOESEEK_REL)              #0x1c
        endVblock = bs.readUInt()            #0x47239
        skip = bs.readUInt()                 #0x02
        FIndOffs = bs.readUInt()             #0x47239
        numIdx = bs.readUInt()               #4913
        FCount = numIdx * 3                  #14739
        FileSize = bs.readUInt()             #0x5589b   0x30
        skip = bs.readUInt()                 #1
        bs.seek(8, NOESEEK_REL)              #0x3c
        endMesh = bs.readUInt()              #0x5588a
        bs.seek(12, NOESEEK_REL)             #0x4c
        unk = bs.readUInt()                  #0x558d1
        bs.seek(4, NOESEEK_REL)              #0x54
        nextSubmesh = bs.readUInt()          #0x55911
        bs.seek(1, NOESEEK_REL)              #0x59
        vbOffset = bs.readUByte()            #0x13(19)  0x5a
        bs.seek(vbOffset, NOESEEK_REL)       #0x6d
        vStride = sizeofvBlock // numVerts   #(291276 / 8091)
        VBuf = bs.readBytes(sizeofvBlock)
        if vStride == 36:
            rapi.rpgBindPositionBufferOfs(VBuf, noesis.RPGEODATA_FLOAT, 36, 0)
            #rapi.rpgBindNormalBufferOfs(VBuf, noesis.RPGEODATA_FLOAT, 36, 12)
            rapi.rpgBindUV1BufferOfs(VBuf, noesis.RPGEODATA_FLOAT, 36, 12)
        if vStride == 52:
            rapi.rpgBindPositionBufferOfs(VBuf, noesis.RPGEODATA_FLOAT, 52, 0)
            #rapi.rpgBindNormalBufferOfs(VBuf, noesis.RPGEODATA_FLOAT, 52, 12)
            rapi.rpgBindUV1BufferOfs(VBuf, noesis.RPGEODATA_FLOAT, 52, 12)
        bs.seek(endMesh - (FCount * 4), NOESEEK_ABS)              
        FBuf = bs.readBytes(FCount * 4)
        if "aaa" not in fileName:
            FBuf = rapi.swapEndianArray(FBuf, 4) #turn off byte swap for ~aaa.wmdl
        matNameLength = bs.readShort()
        texName = bs.readBytes(matNameLength).decode("ASCII")		
        skip = bs.readBytes(8)
        meshNameLength = bs.readShort()
        meshName = bs.readBytes(meshNameLength).decode("ASCII")
        rapi.rpgSetName(str(meshName))
        rapi.rpgSetMaterial(texName)
        rapi.rpgCommitTriangles(FBuf, noesis.RPGEODATA_UINT, FCount, noesis.RPGEO_TRIANGLE, 1)
        bs.seek(nextSubmesh, NOESEEK_ABS)              
    mdl = rapi.rpgConstructModel()                                                          
    texList = matList
    mdl.setModelMaterials(NoeModelMaterials(texList, matList))
    mdlList.append(mdl)
    rapi.rpgClearBufferBinds()
    return 1
