from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Ben 10 Omniverse", ".omni")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    Magic = bs.readBytes(4)
    if Magic != b'\x00\x00\x00\x01':
        return 0
    return 1
	
def noepyLoadRGBA(data, texList):
    datasize = len(data) - 0x6d        
    bs = NoeBitStream(data, NOE_BIGENDIAN)
    bs.seek(0x3e, NOESEEK_ABS)
    imgWidth = bs.readUShort()            
    imgHeight = bs.readUShort()
    print(imgWidth, "x", imgHeight)
    bs.seek(0x6d, NOESEEK_ABS)
    data = bs.readBytes(datasize)      
    fileName = rapi.getLocalFileName(rapi.getInputName())
    if "_d.omni" in fileName:
        data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 8)
        texFmt = noesis.NOESISTEX_DXT1
    elif "_n.omni" in fileName:
        data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 16)
        texFmt = noesis.NOESISTEX_DXT5
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1