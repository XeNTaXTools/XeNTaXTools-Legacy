#import newGameLib
#from newGameLib import *

import bpy,struct,os
import Blender
from Blender import *
from struct import *
from math import *
from Blender.Mathutils import *



"""
halftofloat - author fpmurphy from
http://forums.devshed.com/python-programming-11
/converting-half-precision-floating-point-numbers-from-hexidecimal-to-decimal-576842.html
""" 

def HalfToFloat(h):
	s = int((h >> 15) & 0x00000001) # sign
	e = int((h >> 10) & 0x0000001f) # exponent
	f = int(h & 0x000003ff)   # fraction

	if e == 0:
	   if f == 0:
		  return int(s << 31)
	   else:
		  while not (f & 0x00000400):
			 f <<= 1
			 e -= 1
		  e += 1
		  f &= ~0x00000400
		  #print s,e,f
	elif e == 31:
	   if f == 0:
		  return int((s << 31) | 0x7f800000)
	   else:
		  return int((s << 31) | 0x7f800000 | (f << 13))

	e = e + (127 -15)
	f = f << 13
	return int((s << 31) | (e << 23) | f)


def create_object_name():
	global model_id
	ids = []
	scene = bpy.data.scenes.active
	for mat in Material.Get():
		try:
			model_id = int(mat.name.split('-')[0])
			ids.append(model_id)
		except:pass
	try:
		model_id = max(ids)+1
	except:
		model_id = 0

def converthalf2float(h):
	id = HalfToFloat(h)
	str = struct.pack('I',id)
	return struct.unpack('f', str)[0]

def find_0(): 
	s=''
	while(True):
		litera =  struct.unpack('c',plik.read(1))[0]
		if  litera=='\x00':
			break
		else:
			s+=litera
	return s

def find(char): 
	s=''
	while(True):
		litera =  struct.unpack('c',plik.read(1))[0]
		if  litera==char:
			break
		else:
			s+=litera
	return s

def check_armature():
	global armobj,newarm
	armobj=None
	newarm=None
	scn = Scene.GetCurrent()
	scene = bpy.data.scenes.active
	for object in scene.objects:
		if object.getType()=='Armature':
			if object.name == 'armature':
				scene.objects.unlink(object)
	for object in bpy.data.objects:
		if object.name == 'armature':
			armobj = Blender.Object.Get('armature')
			newarm = armobj.getData()
			newarm.makeEditable()   
			for bone in newarm.bones.values():
				del newarm.bones[bone.name]
			newarm.update()
	if armobj==None: 
		armobj = Blender.Object.New('Armature','armature')
	if newarm==None: 
		newarm = Armature.New('armature')
		armobj.link(newarm)
	scn.link(armobj)
	newarm.drawType = Armature.STICK
	armobj.drawMode = Blender.Object.DrawModes.XRAY
	#armobj.setEuler(0,0,math.pi/2)


def b(n):
	return struct.unpack(n*'b', plik.read(n))
def B(n):
	return struct.unpack(n*'B', plik.read(n))
def h(n):
	return struct.unpack(n*'h', plik.read(n*2))
def H(n):
	return struct.unpack(n*'H', plik.read(n*2))
def i(n):
	return struct.unpack(n*'i', plik.read(n*4))
def I(n):
	return struct.unpack(n*'I', plik.read(n*4))
def f(n):
	return struct.unpack(n*'f', plik.read(n*4))

def word(long): 
   s=''
   for j in range(0,long): 
	   lit =  struct.unpack('c',plik.read(1))[0]
	   if ord(lit)!=0:
		   s+=lit
		   if len(s)>300:
			   break
   return s




def make_vertex_group():
	for id_0 in range(len(weighting)):
		data = weighting[id_0]
		for id_1 in range(4):
			gr = data[0][id_1]
			gr = str(gr)
			w  = data[1][id_1]/255.0
			if w!=0:# and gr !=str(0):
				if gr not in mesh.getVertGroupNames():
					mesh.addVertGroup(gr)   
					mesh.update()
				mesh.assignVertsToGroup(gr,[id_0],w,1)
	mesh.update()

def vertexuv():
	mesh.vertexUV = 1
	for m in range(len(mesh.verts)):
		mesh.verts[m].uvco = Vector(uvlist[m])
	mesh.update() 
	mesh.faceUV = 1
	for fc in mesh.faces: fc.uv = [v.uvco for v in fc.verts];fc.smooth = 1
	mesh.update()   

def drawmesh(name): 
	global obj,mesh
	mesh = bpy.data.meshes.new(name)
	mesh.verts.extend(vertexlist)
	mesh.faces.extend(faceslist,ignoreDups=True)
	if len(uvlist)!=0:
	   vertexuv()
	scene = bpy.data.scenes.active
	obj = scene.objects.new(mesh,name)
	#obj.sel=False
	mesh.recalcNormals()
	mesh.update()
	Redraw()
	"""
	make_vertex_group()
	scene = bpy.data.scenes.active
	#print materials
	#print bonenames
	try:
		mesh.materials+=[Material.Get(name)]
	except:
		pass
	for object in scene.objects:
		if object.getType()=='Armature':
			try:
				for gr_name in mesh.getVertGroupNames(): 
						gr = materials[name]['fix_groups'][int(gr_name)]
						#print gr
						gr = bonenames[str(gr)] 
						mesh.renameVertGroup(gr_name,gr)
				object.makeParentDeform([obj],1,0)
			except:
				pass
				"""
			

def make_bone(bonename):
	newarm.makeEditable()
	eb = Armature.Editbone() 
	#eb.tail*=0.10
	newarm.bones[bonename] = eb
	newarm.update()

def make_bone_parent(bonename,childname):
	newarm.makeEditable()
	bone = newarm.bones[bonename]
	childbone = newarm.bones[childname]
	childbone.parent = bone
	newarm.update()

def make_bone_position(bonename,rot,pos):
	bone = newarm.bones[bonename]
	rot = Quaternion(rot[3],rot[0],rot[1],rot[2])
	rot = rot.toMatrix()#.invert()
	rot=rot.resize4x4()
	matrix = rot*TranslationMatrix(Vector(pos))
	matrix*=bone.parent.matrix['ARMATURESPACE'] 
	newarm.makeEditable()  
	bone = newarm.bones[bonename]
	bone.matrix = matrix
	newarm.update()

def msh():
	global sections,meshes,offset
	meshes={}
	name=word(20)
	count=i(1)[0]
	offset=i(1)[0]
	#print name,count,offset
	sections={}
	for m in range(count):
		name=word(4)
		sections[name]={}
		sections[name]['count']=i(1)[0]
		sections[name]['off']=i(1)[0]
		sections[name]['size']=i(1)[0]
		#print name,sections[name]
	for section in sections:
		#print 'section',m,section
		plik.seek(sections[section]['off'])
		sections[section]['elems']=[]
		for n in range(sections[section]['count']):
			#print n	 
			sections[section]['elems'].append(i(3))
			#print sections[section]['elems'][n]
	#print plik.tell() 
	n=0  
	seek=0
	#oldoffset=0
	#print '#'*50
	if 'mesh' in sections.keys():
		parser(seek,'mesh',n,'')
		#print meshes
	if 'mdlh' in sections.keys():
		#global node_parent_name,node_name
		#node_parent_name='null'
		#node_name='null'
		global get_mesh_name,msh_name,mao_name
		get_mesh_name=''
		msh_name = ''
		mao_name = ''
		parser(seek,'mdlh',n,'')
			

def parser(seek,id,n,parent):
	global meshdata,vertex_off,indice_off#,node_name
	global node_name,pos,msh_name,get_mesh_name,mao_name
	n+=1
	v=sections[id]
	count=v['count']
	elems=v['elems'] 
	size=v['size']
	for m in range(count):
		e=elems[m]
		index=e[0]
		type=e[1]
		off=e[2]
		#print '-'*n,id,e
		if type in [-1610547201]:
			plik.seek(seek+offset+off)
			plik.seek(offset+i(1)[0])
			nChildren=i(1)[0]
			for m in range(nChildren):
				child_type=i(1)[0]
				child_off=i(1)[0]
				#print '-'*n,id,child_type,child_off
				t=plik.tell()
				if child_type in[1073741857]:#node
					#if node_name!='null':
					#   if node_parent_name!='null':
					#   make_bone_parent(node_parent_name,node_name)
					parser(child_off,'node',n,parent)
				if child_type==1073741829:#xprt
					parser(child_off,'xprt',n,parent)
				if child_type==1073741858:#mshh
					parser(child_off,'mshh',n,parent)
				if child_type in [1073741832]:#node trans
					parser(child_off,'trsl',n,parent)
				if child_type==1073741831:#node rot
					parser(child_off,'rota',n,parent)
				plik.seek(t)		
		if type in [-536870908]:#chn 
			plik.seek(seek+offset+off)
			plik.seek(offset+i(1)[0])
			nChildren=i(1)[0]
			for k in range(nChildren):
				child_off=i(1)[0]
				#print '-'*n,child_off
				t=plik.tell()
				meshes[str(k)]={}
				meshdata = meshes[str(k)]
				parser(child_off,'chnk',n,parent)
				plik.seek(t)
		if index==2:	
			plik.seek(seek+offset+off)
			plik.seek(offset+i(1)[0])
			mesh_name=word(i(1)[0]*2)[-15:]
			if id=='chnk':  
				meshdata['name']=mesh_name
		if index==6000:#node name
			plik.seek(seek+offset+off)
			plik.seek(offset+i(1)[0])
			node_name=word(i(1)[0]*2)
			print '-'*n,parent,node_name 
			#if id=='node':
			make_bone(node_name)
			if parent!='':
				try:make_bone_parent(parent,node_name)
				except:pass 
			parent=node_name
		if index==6001:
			plik.seek(seek+offset+off)
			plik.seek(offset+i(1)[0])
			mao_name=word(i(1)[0]*2).lower()
			if mao_name not in dragonmaterials.keys():
				dragonmaterials[mao_name]=[]
			print 'mao name=',mao_name
		if index==6005:
			plik.seek(seek+offset+off)
			plik.seek(offset+i(1)[0])
			msh_name=word(i(1)[0]*2).lower()
			print 'msh name=',msh_name
		if index==6006:
			plik.seek(seek+offset+off)
			plik.seek(offset+i(1)[0])
			get_mesh_name=word(i(1)[0]*2).lower()[-15:]
			print 'get mesh name=',get_mesh_name
			dragonmaterials[mao_name].append(get_mesh_name)
			print 'materials',dragonmaterials
				
		if index==6254:#node index
			plik.seek(seek+offset+off)
			#plik.seek(offset+i(1)[0])
			node_index=i(1)[0]
			#if node_index!=-1:
			#   make_bone_parent(node_parent_name,node_name)
		if index==6047:#node trsl
			plik.seek(seek+offset+off)
			#plik.seek(offset+i(1)[0])
			pos=f(4)
		if index==6048:#node rot
			plik.seek(seek+offset+off)
			#if id=='node':
			make_bone_position(node_name,f(4),pos)
			#except:pass	
		if type==4:
			plik.seek(seek+offset+off)
			value = i(1)[0]   
			if index==8000: 
				meshdata['vertsize']=value 
			if index==8001: 
				meshdata['vertcount']=value 
			if index==8002: 
				meshdata['indexcount']=value 
			if index==8006:
				meshdata['vertoff']=value 
			if index==8009:
				meshdata['indexstart']=value
		if type == -2147483648:
			plik.seek(seek+offset+off)
			plik.seek(offset+i(1)[0])
			if index==8022:
				vertex_off=plik.tell()
			if index==8023:
				indice_off=plik.tell()
		if type == -1073741823:
			plik.seek(seek+offset+off)
			plik.seek(offset+i(1)[0])
			nTwig=i(1)[0]#twig count
			print '-'*n,'twig',nTwig,plik.tell()
			for k in range(nTwig):
				#print
				#print '-'*n,'nTwig',k
				id='decl'
				decl(id,n)  
						
				
		
		
def decl(id,n):
	n+=4
	v=sections[str(id)]
	count=v['count']
	elems=v['elems'] 
	size=v['size']
	#plik.seek(offset)
	t=plik.tell()
	for m in range(count):
		e=elems[m]
		index=e[0]
		type=e[1]
		off=e[2]
		#print '-'*n,e,
		plik.seek(t+off)
		value = i(1)[0] 
		#print value
		if m==1:
			voff=value
		if m==2:
			datatype=value 
		if m==3 and value==0:   
			meshdata['coord_off']=voff 
			if datatype==2:
				meshdata['coord_type']=1#float
			if datatype==3:
				meshdata['coord_type']=1#float
			if datatype==16:
				meshdata['coord_type']=-1#half
		if m==3 and value==5:
			meshdata['uv_off']=voff 
			#meshdata['coord_type']=1
			
def show():
	global vertexlist,faceslist,uvlist 
	print dragonmaterials
	for id in meshes.keys():
		#print id,meshes[id] 
		data=meshes[id]
		plik.seek(vertex_off+data['vertoff']+4)
		#print plik.tell(),data['coord_off']
		vertexlist=[]
		faceslist=[]
		uvlist=[]
		for m in range(data['vertcount']):
			t=plik.tell()
			plik.seek(t+data['coord_off'])
			if data['coord_type']==-1:
				x=converthalf2float(H(1)[0])
				y=converthalf2float(H(1)[0])
				z=converthalf2float(H(1)[0])
				#print x,y,z,plik.tell()
				vertexlist.append([x,y,z])
			if data['coord_type']==1:
				vertexlist.append(f(3))
			plik.seek(t+data['uv_off'])
			u=converthalf2float(H(1)[0])
			v=1-converthalf2float(H(1)[0])
			uvlist.append([u,v])
			plik.seek(t+data['vertsize'])
		plik.seek(indice_off+data['indexstart']*2+4)
		for m in range(data['indexcount']/3):
			faceslist.append(H(3))
			#print faceslist[m]
		#print plik.tell()   
		drawmesh(data['name'])
		Redraw()
		Window.RedrawAll()   
		#break  

def chunks(line):
	sep = line.split()
	chunk_list = {} 
	for m in sep:
		if '=' in m:
			#print m
			chunk_name  = m.split('=')[0]
			chunk_value = m.split('=')[1].split('"')[1]
			chunk_list[chunk_name] = chunk_value
	return chunk_list

def mao():
	lines=plik.readlines()
	mat=Material.New(str(model_id)+'-mat')
	for line in lines:
		try:
			keys=chunks(line)
			if 'ResName'in keys.keys():
				tex_type = keys['Name']
				img_name = keys['ResName'].lower()
				#print tex_type,img_name 
				try:
					img=Blender.Image.Load(dds_files[img_name])
					#mat=Material.New(str(model_id)+'-mat')
					if tex_type in ['mml_tDiffuse','mml_tPackedTexture']:
						#mat.alpha = 0
						#mat.mode |= Material.Modes.ZTRANSP
						tex=Texture.New(str(model_id)+'-diff') 
						tex.setType('Image') 
						tex.setImageFlags()  
						tex.image = img   
						mat.setTexture(0,tex,Texture.TexCo.UV,\
						Texture.MapTo.COL)#|Texture.MapTo.ALPHA)
					if tex_type=='mml_tNormalMap':
						tex=Texture.New(str(model_id)+'-norm') 
						tex.setType('Image') 
						tex.setImageFlags('NormalMap')  
						tex.image = img 
						mat.setTexture(1,tex,Texture.TexCo.UV,\
						Texture.MapTo.NOR)
					if tex_type=='mml_tSpecularMask':
						tex=Texture.New(str(model_id)+'-spec') 
						tex.setType('Image') 
						tex.setImageFlags() 
						tex.image = img 
						mat.setTexture(2,tex,Texture.TexCo.UV,\
						Texture.MapTo.CSP)
				except:pass 
			
		except:pass 
		#mesh.materials+=[mat]
	return mat  

def assign_materials():
	global plik
	scene = bpy.data.scenes.active
	for mao_name in dragonmaterials.keys():   
		#print mao_name
		filename=dds_files[mao_name+'.mao']
		plik=open(filename,'rb')
		mat=mao()
		plik.close()
		mesh_names=dragonmaterials[mao_name]
		for mesh_name in mesh_names:
			#print mesh_name
			for object in scene.objects:
				if mesh_name in object.name.lower():
					object.getData(mesh=1).materials+=[mat]
			
		
def Parser(filename):
	print
	print filename
	print
	global plik,dragonmaterials,msh_name,dds_files,model_id
	model_id=create_object_name()
	dds_files = {}
	dirname=sys.dirname(filename)
	basename=sys.basename(filename)
	ext=basename.split('.')[-1].lower()
	dragonmaterials={}
	if ext=='mao':
		plik=open(filename,'r')
		mao()
		plik.close()	
	elif ext=='mmh':
		plik=open(filename,'rb')
		check_armature()
		msh()
		
		plik.close()
		
		#print 'msh_name',msh_name 
		if len(msh_name)>0:
			mshPath=filename.split('art')[0]+msh_name
			#print mshPath
			if os.path.exists(mshPath)==True:
				plik=open(mshPath,'rb')
				msh()
				show()
				#print dragonmaterials
				assign_materials()
				plik.close()	  
		#if len(mao_name)>0:
		#   filename=dds_files[mao_name+'.mao']
		#   plik=open(filename,'rb')
		#   mao()
		#   plik.close()
	elif ext=='msh':
		plik=open(filename,'rb')
		msh()
		show()
		plik.close()
	Redraw()


	
Blender.Window.FileSelector(Parser,'import','Dragon Age files: *.msh - mesh, *.mmh - skeleton') 
	