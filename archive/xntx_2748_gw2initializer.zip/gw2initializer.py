import os
import urllib.request
import struct
import sys
import shlex

infoList = [];

def getLatest(branch):
	"""Downloads 'latest' file to get the latest versions."""
	global infoList
	print("Downloading 'latest' for "+str(branch))
	latestPath = "/latest/"
	url = "http://assetcdn."+str(branch)+".arenanetworks.com"+latestPath+str(branch)
	data = None
	headers = { "Cookie" : "authCookie=access=/latest/*!/manifest/program/*!/program/*~md5=4e51ad868f87201ad93e428ff30c6691" }
	
	request = urllib.request.Request(url,data,headers)	
	
	try:
		res = urllib.request.urlopen(request)
		temp = res.read().decode()
		infoList = shlex.split(temp)
	except urllib.error.HTTPError as err:
		print(err.code)
		print(err.read())
		
def downloadEXE(branch):
	"""Downloads the patcher EXE for the specified version."""
	print("Downloading EXE for branch "+str(branch))
	filePath = "/program/"+str(branch)+"/0/0/"
	url = "http://assetcdn."+str(branch)+".arenanetworks.com"+filePath+str(infoList[1])
	data = None
	headers = { "Cookie" : "authCookie=access=/latest/*!/manifest/program/*!/program/*~md5=4e51ad868f87201ad93e428ff30c6691" }
	
	request = urllib.request.Request(url,data,headers)	
	
	try:
		res = urllib.request.urlopen(request)
		if(branch == 101):
			if not os.path.exists('./Beta'):
				os.mkdir('.\Beta')
			file = open("./Beta/Gw2Beta.exe", "wb")
		elif(branch == 102):
			if not os.path.exists('./Dev'):
				os.mkdir('Dev')
			file = open("./Dev/Gw2Dev.exe", "wb")
		else:
			if not os.path.exists('./Alternate'+str(branch)):
				os.mkdir('./Alternate'+str(branch))
			file = open("./Alternate"+str(branch)+"/Gw2Branch"+str(branch)+".exe", "wb")
		file.write(res.read())
		res.close()
	except urllib.error.HTTPError as err:
		print(err.code)
		print(err.read())
		
	downloadedFileSize = 0

	if(branch == 101):
		if(os.stat("./Beta/Gw2Beta.exe").st_size == int(infoList[2])):
			print("Gw2 EXE downloaded successfully.")
		else:
			print("Gw2 EXE downloaded unsuccessfully. "+str(downloadedFileSize)+" - "+infoList[2])
	elif(branch == 102):
		if(os.stat("./Dev/Gw2Dev.exe").st_size == int(infoList[2])):
			print("Gw2 EXE downloaded successfully.")
		else:
			print("Gw2 EXE downloaded unsuccessfully. "+str(downloadedFileSize)+" - "+infoList[2])
	else:
		if(os.stat("./Alternate"+str(branch)+"/Gw2Branch"+str(branch)+".exe").st_size == int(infoList[2])):
			print("Gw2 EXE downloaded successfully.")
		else:
			print("Gw2 EXE downloaded unsuccessfully. "+str(downloadedFileSize)+" - "+infoList[2])
		
	
		
		
def main():
	"""Downloads GW2EXE for whatever version you want."""
	branch = int(sys.argv[1]);
	getLatest(branch);
	downloadEXE(branch);

if __name__=="__main__":
	main()