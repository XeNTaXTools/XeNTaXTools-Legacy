from inc_noesis import *
import os

def registerNoesisTypes():
    handle = noesis.register("Hellboy: Science of Evil (PS3)", ".tex")
    noesis.setHandlerTypeCheck(handle, RHCheckType)
    noesis.setHandlerLoadRGBA(handle, RHLoadRGBA)
    #noesis.logPopup()
    return 1

def RHCheckType(data):
    bs = NoeBitStream(data)
    bs.seek(len(data) - 0x30, NOESEEK_ABS)
    Magic = bs.readBytes(4).decode("ASCII")
    if Magic != "3PTM":
        return 0
    return 1   

def RHLoadRGBA(data, texList):
    datasize = len(data)
    bs = NoeBitStream(data)
    bs.setEndian(NOE_BIGENDIAN)
    bs.seek(len(data) - 0x2C, NOESEEK_ABS)
    imgWidth = bs.readShort()
    imgHeight = bs.readShort()
    bs.seek(0x03, NOESEEK_REL)
    imgFmt = bs.readByte()              
    bs.seek(0)        
   	#DXT5
    if imgFmt == 0x08:
        texFmt = noesis.NOESISTEX_DXT5
    #DXT1 packed normal map
    elif imgFmt == 0x0C:
        data = bytearray()
        for y in range(0, imgHeight):
            for x in range(0, imgWidth):
                idx = noesis.morton2D(y, x)
                if (idx*4+4) > datasize:
                    idx = 0
                bs.seek(0 + idx*4, NOESEEK_ABS)
                data += bs.readBytes(4)
        data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "r8 g8 b8 a8")
        texFmt = noesis.NOESISTEX_RGBA32
    #DXT1
    else:
        texFmt = noesis.NOESISTEX_DXT1
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1