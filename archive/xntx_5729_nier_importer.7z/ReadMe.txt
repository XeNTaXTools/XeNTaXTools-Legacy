1.run src/wmb_parser.py to generate an itermediate file for model. (*.gtb)
2.run src/splitdds.py to get the textures related to that model, put textures in the same directory with gtb file.
3.if using blender, then put the "gtb_importer" folder into blender's addon folder. Enable that addon and you can import gtb files into blender. if you have dds files with gtb files in the same folder.then Blender will try to apply a default material for you, with textures assigned. However, to get the same visuals like the game, you have to setup your own pbr material.
4.if not using blender, then edit "src/wmb_parser.py", set DUMP_OBJ to True, and you'll get obj files instead.

known issues:
custom vertex normal is quite right.
joints and weights for some models are not correct.

PS:
gtb file is just a zlib compressed json file with fourcc "GTB\x00"
I invented this format so that I don't have to write Blender code for every single game.
Also, one can write importers for other DCC tools such as MAX and maya, without knowing details of wmb file.
check "src/wmb_parser.py" export_gtb for detail.

