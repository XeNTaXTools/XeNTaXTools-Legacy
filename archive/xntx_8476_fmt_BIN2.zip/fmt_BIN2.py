#by Durik256
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("test", ".BIN")
    noesis.setHandlerTypeCheck(handle, CheckType)
    noesis.setHandlerLoadModel(handle, LoadModel)
    return 1

def CheckType(data):
    if data[4:8] != b'SHPE':
        return 0
    return 1

def LoadModel(data, mdlList):
    bs = NoeBitStream(data)
    ctx = rapi.rpgCreateContext()
    
    result = [(i+14) for i in findall(b'\x00\x00\x00\x20\x10\x10\x10\x10\x00\x00\x00\x00\x80\x00', data)]
    
    if result:
        for x in result:
            bs.seek(x)
            num = bs.readByte()
            bs.seek(-(num*16+15),1)
            vbuf = bs.read(num*16)
            rapi.rpgBindPositionBuffer(vbuf, noesis.RPGEODATA_FLOAT, 16)
            
            bs.seek(16,1)
            uvbuf = bs.read(num*8)
            rapi.rpgBindUV1Buffer(uvbuf, noesis.RPGEODATA_FLOAT, 8)
            
            rapi.rpgCommitTriangles(None, noesis.RPGEODATA_USHORT, num, noesis.RPGEO_POINTS)#RPGEO_TRIANGLE_STRIP

    try:
        mdl = rapi.rpgConstructModel()
    except:
        mdl = NoeModel()

    mdlList.append(mdl)
    return 1

def findall(p, s):
    i = s.find(p)
    while i != -1:
        yield i
        i = s.find(p, i+1)