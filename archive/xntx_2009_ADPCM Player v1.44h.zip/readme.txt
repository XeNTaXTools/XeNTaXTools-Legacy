ADPCM Player v1.44f (c) FastElbJa

2008.01.14 : Fixed XA Ripping & add a checkbox (XA : Scan Empty Buffer), to
	     make a deeper find of songs.

2007.11.03 : Add FAG Support (use in Jackie Stunt Stuntmaster)
	     Basically MIB file

2007.07.28 : Add RAW format (use in XGRA) + others i can't rembember :P

2007.07.28 : Fix a noisy bug on Xbox APDCM Decoder

2007.07.24 : Fix broken ps2 rip
 	     Fix CD/XA mono support (still bad time calculations :( )

2007.07.23 : Adding CD/XA Support (for ripping & listening)
	     Beware ! The file have to be extracted from the ISO (ex: with CD-Mage).
	     No tests have been done with file different from Level B/C & 37,8Khz Stereo
	     The "Level B/C 37,8 Khz Stereo" is by the way the most common used format.

2007.07.19 : Fix bug with mono ADX files.
	     Fix loop entries in ADX.
	     Add support for some DSP (ex : Evolution Skateboarding - Gamecube)	

2007.05.26 : Better checking of VPK Files
             Adding support for VAG - Stereo Files (found in Jak 3 - SCUS-97330)
	     Adding Check Box to prevent bad checking 
	     of signatures Files (ex : God Of War 2 - SCES-54206)

