##########################
# Install Blender plugin #
##########################
Go to Edit -> Preferences, click on "Add-ons" tab on the left. You'll find in the top menu "Install...". Drive to "seca_mhs2wor.zip" files and enabled it.

####################
# Convert textures #
####################
Copy "texconv.exe" inside "archive" folder from the game.

#####################
# Extract ARC files #
#####################
ORIGINAL SCRIPT FROM SILVRIS - github.com/Silvris/MH-Tools-and-Scripts
Run "arc_tool.py" and "root.txt" will be generated.
Edit "root.txt" and write the complete path to "archive" folder. (Usually "C:\Program Files (x86)\Steam\steamapps\common\Monster Hunter Stories 2\nativeDX11x64\archive" in windows)
Save "root.txt" and drag and drop the ARC files or folders to extract the data.
!!!!!!!!!!!!!!
IMPORTANT NOTE
!!!!!!!!!!!!!!
If you drop a folder, it will extract all ARC files found on subfolders. Keep in mind all files extracted should takes up a lot of space.


Enjoy!
Contact: https://discord.gg/cq87dwxsnv
         contact@secaproject.com
