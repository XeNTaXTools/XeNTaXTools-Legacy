import newGameLib
reload(newGameLib)
from newGameLib import *
import Blender



def fbParser(filename,g):
	action=Action()
	action.BONESPACE=True
	action.BONESORT=True
	action.skeleton='armature'
	while(True):
		if g.tell()>=g.fileSize():break
		chunk=g.word(4)
		size=g.i(1)[0]
		t=g.tell()
		if chunk=='REVM':
			version=g.i(1)[0]
			if version not in [10,29,30]:
				print 'WARNING:file format not supported:',version
				break
		if chunk=='MNAM':
			g.i(2)
		if chunk=='NOBM':
			boneCount=g.i(1)[0]
			for i in range(boneCount):
				bone=ActionBone()
				w=g.i(2)
				bone.name=str(w[0])
				for m in range(g.i(1)[0]):
					bone.posFrameList.append(g.i(1)[0]/33)
					bone.posKeyList.append(VectorMatrix(g.f(3)))
				for m in range(g.i(1)[0]):
					bone.rotFrameList.append(g.i(1)[0]/33)
					bone.rotKeyList.append(QuatMatrix(g.f(4)).resize4x4())
				for m in range(g.i(1)[0]):
					g.i(1)[0]
					g.f(3)
				g.H(1)
				action.boneList.append(bone)
		g.seek(t+size)
	action.draw()
	action.setContext()

def mzParser(filename,g):
	
	
	skeleton=Skeleton()
	skeleton.ARMATURESPACE=True
	skeleton.NICE=True
	mesh=Mesh()
	mesh.boneNameList=skeleton.boneNameList
	texList=[]
	while(True):
		if g.tell()>=g.fileSize():break
		chunk=g.word(4)
		size=g.i(1)[0]
		t=g.tell()
		print chunk,size
		if chunk=='REVM':
			version=g.i(1)[0]
			if version not in [22,27,29,30,32]:
				print 'WARNING:file format not supported:',version
				break
		if chunk=='XTVM':
			if version in [30,32]:
				flagSize=2
				strideFlag=g.H(1)[0]
			if version in [22,27,29]:
				flagSize=1
				strideFlag=g.B(1)[0]
			print 'strideFlag:',strideFlag
			if strideFlag==257:
				uvOff=44
				stride=76
			elif strideFlag==256:
				uvOff=44
				stride=68
			elif strideFlag==0:
				uvOff=44
				stride=52
			elif strideFlag==1:
				uvOff=44
				stride=60
			else:
				print 'WARNING:strideFlag:',strideFlag
				break
			for m in range((size-flagSize)/stride):
				tm=g.tell()
				mesh.vertPosList.append(g.f(3))
				g.seek(tm+24)
				mesh.skinWeightList.append(g.f(4))
				mesh.skinIndiceList.append(g.B(4))
				g.seek(tm+uvOff)
				mesh.vertUVList.append(g.f(2))				
				g.seek(tm+stride)
		if chunk=='CAFM':
			mesh.indiceList=g.H(size/2)
		if chunk=='BUSM':
			g.debug=True
			sum=0
			if version in [22,27,29]:
				while(True):
					mat=Mat()
					mat.TRIANGLE=True
					mat.ZTRANS=True
					tw=g.tell()
					mat.texID=g.H(1)[0]
					w=g.H(4)
					mat.IDStart=w[2]
					mat.IDCount=w[3]
					mesh.matList.append(mat)
					g.B(1)
					mat.name=g.word(g.B(1)[0])
					sum+=g.tell()-tw
					if sum>=size:break
				g.debug=False
			if version in [30,32]:
				while(True):
					mat=Mat()
					mat.TRIANGLE=True
					mat.ZTRANS=True
					tw=g.tell()
					v=g.H(3)
					mat.texID=v[1]
					w=g.H(4)
					mat.IDStart=w[2]
					mat.IDCount=w[3]
					mesh.matList.append(mat)
					g.B(1)
					mat.name=g.word(g.B(1)[0])
					sum+=g.tell()-tw
					if sum>=size:break
				g.debug=False
		if chunk=='XTMM':#big unknow, use brute force for texList
			matCount=g.i(1)[0]
			for m in range(matCount): 
				matName=g.word(g.B(1)[0])
				print matName
				g.B(123)
				g.find('\x1E\x00')
				g.find('\x00\x00\x00')
				texName=g.word(g.B(1)[0])
				texList.append(texName)
				print m,texName
				g.B(1)
		if chunk=='NOBM':
			boneCount=g.i(1)[0]
			for m in range(boneCount):
				bone=Bone()
				bone.ID=g.i(1)[0]
				name=g.word(g.B(1)[0])
				bone.name=str(bone.ID)
				bone.parentID=g.i(1)[0]
				bone.rotMatrix=Matrix3x3(g.f(9)).resize4x4()
				bone.posMatrix=VectorMatrix(g.f(3))
				g.b(14)
				skeleton.boneList.append(bone)
		g.seek(t+size)
		
	skeleton.draw()	
	for mat in mesh.matList:
		imgPath=g.dirname+os.sep+texList[mat.texID]
		if len(texList[mat.texID])>0:
			mat.diffuse=imgPath
	skin=Skin()
	mesh.skinList.append(skin)	
	mesh.SPLIT=True
	mesh.BINDSKELETON='armature'
	mesh.draw()
	
	
def Parser():	
	filename=input.filename
	imageList=input.imageList
	ext=filename.split('.')[-1].lower()	
	print 
	print filename
	print
	
	if ext=='mz':
		file=open(filename,'rb')
		g=BinaryReader(file)
		mzParser(filename,g)
		file.close()
		
	if ext=='fb':
		file=open(filename,'rb')
		g=BinaryReader(file)
		fbParser(filename,g)
		file.close()
 
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
 
	
Blender.Window.FileSelector(openFile,'import','mz - skeleton mesh,fb - animation file') 