DecUbiSnd is a program to decode the audio streams found in many UbiSoft games. Run DecUbiSnd without any arguments to get a list of command line switches.

Coded by Zench of the XeNTaX forums