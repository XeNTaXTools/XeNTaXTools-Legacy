﻿#Technomancer .* [PC] - ".pgz" Loader
#v1.0
#plugin by zaramot

from inc_noesis import *
import subprocess
import os
import glob

def registerNoesisTypes():
	handle = noesis.register("Technomancer [PC]", ".pgz")
	noesis.setHandlerTypeCheck(handle, texCheckType)
	noesis.setHandlerLoadRGBA(handle, texLoadDDS)
	noesis.logPopup()
	return 1
		
def texCheckType(data):
	bs = NoeBitStream(data)
	fileMagic = bs.readUInt()
	if fileMagic == 0x47535350:
		return 1
	else: 
		print("Fatal Error: Unknown file magic: " + str(hex(fileMagic) + " expected 0x47535350!"))
		return 0

def texLoadDDS(data, texList):
    bs = NoeBitStream(data, NOE_BIGENDIAN)
	
    fileMagic = bs.readUInt()
    bs.seek(0x35F, NOESEEK_ABS) 
    TWidth = bs.readUInt()
    bs.seek(0x36B, NOESEEK_ABS) 
    Height = bs.readUInt()
    bs.seek(0x37B, NOESEEK_ABS)
    ddsType = bs.readString()
    bs.seek(0x406, NOESEEK_ABS)
    ddsNameSize = bs.readUInt()
    bs.seek((ddsNameSize+0x2B), NOESEEK_REL) 
    ddsSize = bs.readUInt()
    null = bs.readUInt() 
    ddsData = bs.readBytes(ddsSize-4)
    ddsName = rapi.getLocalFileName(rapi.getInputName())
    print (ddsName)
    print (TWidth)
    print (Height)
    print (ddsSize)
    print (ddsType)
    #print (ddsData)
    #DXT1
    if ddsType == "bc1":
        texFmt = noesis.NOESISTEX_DXT1
    #DXT5
    elif ddsType == "bc3":
        texFmt = noesis.NOESISTEX_DXT5
    #ATI1
    elif ddsType == "bc4":
        ddsData = rapi.imageDecodeDXT(ddsData, TWidth, Height, noesis.FOURCC_ATI1)
        texFmt = noesis.NOESISTEX_RGBA32
    #ATI2
    elif ddsType == "bc5":
        ddsData = rapi.imageDecodeDXT(ddsData, TWidth, Height, noesis.FOURCC_ATI2)
        texFmt = noesis.NOESISTEX_RGBA32
    tex1 = (NoeTexture(ddsName, TWidth, Height, ddsData, texFmt))
    texList.append(tex1)

    return 1
	