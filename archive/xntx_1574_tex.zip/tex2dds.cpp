/*	Ghostbusters texture converter
	Copyright 2010 Jonathan Wilson

	The Ghostbusters texture converter is free software; you can redistribute it and/or modify it under
	the terms of the GNU General Public License as published by the Free
	Software Foundation; either version 2, or (at your option) any later
	version. See the file COPYING for more details.
*/
#include <stdio.h>
#include <string.h>
typedef unsigned long       DWORD;
typedef unsigned char       BYTE;
#define MAKEFOURCC(ch0, ch1, ch2, ch3)                              \
            ((DWORD)(BYTE)(ch0) | ((DWORD)(BYTE)(ch1) << 8) |   \
            ((DWORD)(BYTE)(ch2) << 16) | ((DWORD)(BYTE)(ch3) << 24 ))
struct DDS_PIXELFORMAT
{
    DWORD dwSize;
    DWORD dwFlags;
    DWORD dwFourCC;
    DWORD dwRGBBitCount;
    DWORD dwRBitMask;
    DWORD dwGBitMask;
    DWORD dwBBitMask;
    DWORD dwABitMask;
};

#define DDS_FOURCC 0x00000004  // DDPF_FOURCC
#define DDS_RGB    0x00000040  // DDPF_RGB
#define DDS_RGBA   0x00000041  // DDPF_RGB | DDPF_ALPHAPIXELS
#define DDS_LUMINANCE 0x00020000
#define DDS_LUMINANCEA 0x00020001
const DDS_PIXELFORMAT DDSPF_DXT1 =
    { sizeof(DDS_PIXELFORMAT), DDS_FOURCC, MAKEFOURCC('D','X','T','1'), 0, 0, 0, 0, 0 };

const DDS_PIXELFORMAT DDSPF_DXT2 =
    { sizeof(DDS_PIXELFORMAT), DDS_FOURCC, MAKEFOURCC('D','X','T','2'), 0, 0, 0, 0, 0 };

const DDS_PIXELFORMAT DDSPF_DXT3 =
    { sizeof(DDS_PIXELFORMAT), DDS_FOURCC, MAKEFOURCC('D','X','T','3'), 0, 0, 0, 0, 0 };

const DDS_PIXELFORMAT DDSPF_DXT4 =
    { sizeof(DDS_PIXELFORMAT), DDS_FOURCC, MAKEFOURCC('D','X','T','4'), 0, 0, 0, 0, 0 };

const DDS_PIXELFORMAT DDSPF_DXT5 =
    { sizeof(DDS_PIXELFORMAT), DDS_FOURCC, MAKEFOURCC('D','X','T','5'), 0, 0, 0, 0, 0 };

const DDS_PIXELFORMAT DDSPF_A8R8G8B8 =
    { sizeof(DDS_PIXELFORMAT), DDS_RGBA, 0, 32, 0x00ff0000, 0x0000ff00, 0x000000ff, 0xff000000 };

const DDS_PIXELFORMAT DDSPF_A1R5G5B5 =
    { sizeof(DDS_PIXELFORMAT), DDS_RGBA, 0, 16, 0x00007c00, 0x000003e0, 0x0000001f, 0x00008000 };

const DDS_PIXELFORMAT DDSPF_A4R4G4B4 =
    { sizeof(DDS_PIXELFORMAT), DDS_RGBA, 0, 16, 0x00000f00, 0x000000f0, 0x0000000f, 0x0000f000 };

const DDS_PIXELFORMAT DDSPF_R8G8B8 =
    { sizeof(DDS_PIXELFORMAT), DDS_RGB, 0, 24, 0x00ff0000, 0x0000ff00, 0x000000ff, 0x00000000 };

const DDS_PIXELFORMAT DDSPF_R5G6B5 =
    { sizeof(DDS_PIXELFORMAT), DDS_RGB, 0, 16, 0x0000f800, 0x000007e0, 0x0000001f, 0x00000000 };

const DDS_PIXELFORMAT DDSPF_A8L8 = 
    { sizeof(DDS_PIXELFORMAT), DDS_LUMINANCEA, 0, 16, 0xff, 0, 0, 0xff00 };

const DDS_PIXELFORMAT DDSPF_L8 = 
    { sizeof(DDS_PIXELFORMAT), DDS_LUMINANCE, 0, 8, 0xff, 0, 0, 0 };

const DDS_PIXELFORMAT DDSPF_A16B16G16R16F =
    { sizeof(DDS_PIXELFORMAT), DDS_FOURCC, 113, 0, 0, 0, 0, 0 };

#define DDS_HEADER_FLAGS_TEXTURE    0x00001007  // DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH | DDSD_PIXELFORMAT 
#define DDS_HEADER_FLAGS_MIPMAP     0x00020000  // DDSD_MIPMAPCOUNT
#define DDS_HEADER_FLAGS_VOLUME     0x00800000  // DDSD_DEPTH
#define DDS_HEADER_FLAGS_PITCH      0x00000008  // DDSD_PITCH
#define DDS_HEADER_FLAGS_LINEARSIZE 0x00080000  // DDSD_LINEARSIZE
#define DDS_SURFACE_FLAGS_TEXTURE 0x00001000 // DDSCAPS_TEXTURE
#define DDS_SURFACE_FLAGS_MIPMAP  0x00400008 // DDSCAPS_COMPLEX | DDSCAPS_MIPMAP
#define DDS_SURFACE_FLAGS_CUBEMAP 0x00000008 // DDSCAPS_COMPLEX
#define DDS_CUBEMAP_POSITIVEX 0x00000600 // DDSCAPS2_CUBEMAP | DDSCAPS2_CUBEMAP_POSITIVEX
#define DDS_CUBEMAP_NEGATIVEX 0x00000a00 // DDSCAPS2_CUBEMAP | DDSCAPS2_CUBEMAP_NEGATIVEX
#define DDS_CUBEMAP_POSITIVEY 0x00001200 // DDSCAPS2_CUBEMAP | DDSCAPS2_CUBEMAP_POSITIVEY
#define DDS_CUBEMAP_NEGATIVEY 0x00002200 // DDSCAPS2_CUBEMAP | DDSCAPS2_CUBEMAP_NEGATIVEY
#define DDS_CUBEMAP_POSITIVEZ 0x00004200 // DDSCAPS2_CUBEMAP | DDSCAPS2_CUBEMAP_POSITIVEZ
#define DDS_CUBEMAP_NEGATIVEZ 0x00008200 // DDSCAPS2_CUBEMAP | DDSCAPS2_CUBEMAP_NEGATIVEZ
#define DDS_CUBEMAP_ALLFACES ( DDS_CUBEMAP_POSITIVEX | DDS_CUBEMAP_NEGATIVEX |\
                               DDS_CUBEMAP_POSITIVEY | DDS_CUBEMAP_NEGATIVEY |\
                               DDS_CUBEMAP_POSITIVEZ | DDS_CUBEMAP_NEGATIVEZ )
#define DDS_FLAGS_VOLUME 0x00200000 // DDSCAPS2_VOLUME
struct DDS_HEADER
{
    DWORD dwSize;
    DWORD dwHeaderFlags;
    DWORD dwHeight;
    DWORD dwWidth;
    DWORD dwPitchOrLinearSize;
    DWORD dwDepth; // only if DDS_HEADER_FLAGS_VOLUME is set in dwHeaderFlags
    DWORD dwMipMapCount;
    DWORD dwReserved1[11];
    DDS_PIXELFORMAT ddspf;
    DWORD dwSurfaceFlags;
    DWORD dwCubemapFlags;
    DWORD dwReserved2[3];
};
int main(int argc, char* argv[])
{
	FILE *tex = fopen(argv[1],"rb");
	char *c = strdup(argv[1]);
	c[strlen(c)-3] = 'd';
	c[strlen(c)-2] = 'd';
	c[strlen(c)-1] = 's';
	unsigned long l;
	unsigned long format;
	unsigned long width;
	unsigned long height;
	unsigned long mips;
	fread(&l,4,1,tex); //version
	fread(&l,4,1,tex); //hash 1
	fread(&l,4,1,tex); //hash 2
	fread(&l,4,1,tex); //hash 3
	fread(&l,4,1,tex); //hash 4
	fread(&l,4,1,tex); //null
	fread(&format,4,1,tex); // format
	fread(&width,4,1,tex); // width
	fread(&height,4,1,tex); // height
	fread(&l,4,1,tex); // unk
	fread(&mips,4,1,tex); // mips
	fread(&l,4,1,tex); // unk 2
	fread(&l,4,1,tex); // unk 3
	long pos = ftell(tex);
	fseek(tex,0,SEEK_END);
	long size = ftell(tex);
	size = size - pos;
	fseek(tex,pos,SEEK_SET);
	char *texdata = new char[size];
	fread(texdata,size,1,tex);
	DDS_HEADER desc;
	desc.dwSize = 124;
        desc.dwHeaderFlags = DDS_HEADER_FLAGS_TEXTURE;
	if (mips != 0)
	{
		desc.dwHeaderFlags |= DDS_HEADER_FLAGS_MIPMAP;
		desc.dwMipMapCount = mips + 1;
	}
	desc.dwHeight = height;
	desc.dwWidth = width;
	desc.dwSurfaceFlags = DDS_SURFACE_FLAGS_TEXTURE;
	desc.dwCubemapFlags = 0;
	if (mips != 0)
	{
		desc.dwSurfaceFlags |= DDS_SURFACE_FLAGS_MIPMAP;
	}
	switch (format)
	{
	case 3:
		//printf("A8R8G8B8 %s\n",argv[1]);
		desc.ddspf = DDSPF_A8R8G8B8;
		break;
	case 4:
		//printf("R5G6B5 %s\n",argv[1]);
		desc.ddspf = DDSPF_R5G6B5;
		break;
	case 5:
		//printf("A4R4G4B4 %s\n",argv[1]);
		desc.ddspf = DDSPF_A4R4G4B4;
		break;
	case 0x17:
		//printf("DXT3 %s\n",argv[1]);
		desc.ddspf = DDSPF_DXT3;
		break;
	case 0x2B:
		//printf("DXT1 %s\n",argv[1]);
		desc.ddspf = DDSPF_DXT1;
		break;
	case 0x18:
		//printf("A8R8G8B8 cubemap %s\n",argv[1]);
		desc.ddspf = DDSPF_A8R8G8B8;
		desc.dwSurfaceFlags |= DDS_SURFACE_FLAGS_CUBEMAP;
		desc.dwCubemapFlags = DDS_CUBEMAP_ALLFACES;
		break;
	case 0x2E:
		//printf("A16B16G16R16F %s\n",argv[1]);
		desc.ddspf = DDSPF_A16B16G16R16F;
		break;
	case 0x2F:
		//printf("A8L8 %s\n",argv[1]);
		desc.ddspf = DDSPF_A8L8;
		break;
	case 0x32:
		//printf("DXT5 %s\n",argv[1]);
		desc.ddspf = DDSPF_DXT5;
		break;
	case 0x37:
		//printf("L8 %s\n",argv[1]);
		desc.ddspf = DDSPF_L8;
		break;
	}
	FILE *dds = fopen(c,"wb");
	char c1 = 0x44;
	fwrite(&c1,1,1,dds);
	char c2 = 0x44;
	fwrite(&c2,1,1,dds);
	char c3 = 0x53;
	fwrite(&c3,1,1,dds);
	char c4 = 0x20;
	fwrite(&c4,1,1,dds);
	fwrite(&desc,sizeof(desc),1,dds);
	fwrite(texdata,size,1,dds);
	fclose(dds);
	fclose(tex);
	return 0;
}
