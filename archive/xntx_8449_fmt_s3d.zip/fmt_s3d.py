#by Durik256
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Terminal Reality", ".S3D")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)
    
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    if data[:14].decode() != '// S3D version':
        return 0
    return 1
	
def noepyLoadModel(data, mdlList):
    data = data.decode().split('\n')

    numTextures,numTris,numVerts,numParts,numFrames,numLights,numCameras = [int(i) for i in data[3].split(',')]
    
    txName, parts = [], []
    
    vertList, triList = [], []

    for i in range(len(data)):
        if "// partList:" in data[i]:
            for j in range(1,numParts+1):
                line = data[i+j].split(',')
                parts.append([int(i) for i in line[:-1]] + [line[-1].replace('"', '').strip()])
                print(parts[-1])
            i += numParts
        
        elif "// texture list:" in data[i]:
            for j in range(1,numTextures+1):
                txName.append(data[i+j].strip())
            i += numTextures
        
        elif "// triList:" in data[i]:
            for j in range(1,numTris+1):
                triList.append([float(i) for i in data[i+j].split(',')])
            i += numTris
        
        elif "// vertList:" in data[i]:
            for j in range(1,numVerts+1):
                v = NoeVec3([float(x) for x in data[i+j].split(',')])
                vertList.append(v)
            i += numVerts
            
        elif "// lightList:" in data[i]:
            i += numLights
            
        elif "// cameraList:" in data[i]:
            i += numCameras
     
    matList = []
    #createMaterials
    for x in range(numTextures):
        matList.append(NoeMaterial('mat_%i'%x, ''))
    
    #loadTexture
    texList = []
    try:
        dir = rapi.getDirForFilePath(rapi.getInputName())

        for x in range(numTextures):
            data = rapi.loadIntoByteArray(dir+txName[x])
            pal = rapi.loadIntoByteArray(os.path.splitext(dir+txName[x])[0]+'.ACT')

            data = rapi.imageDecodeRawPal(data, pal, 256, 256, 8, 'r8g8b8')
            tx = rapi.getExtensionlessName(txName[x])
            texList.append(NoeTexture(tx, 256, 256, data, noesis.NOESISTEX_RGBA32))
            matList[x].setTexture(tx)
    except:
        print('Error Load texture!')
    
    ctx = rapi.rpgCreateContext()
    
    #createMesh
    for part in parts:
        rapi.rpgSetName(part[4])
        #without materials
        if numTextures <= 0:
            vbuf, uvbuf = b'', b''
            
            for tri in triList[part[2]:part[2]+part[3]]:
                for i in range(3):
                    ofs = (i*3)
                    vbuf += vertList[int(tri[1+ofs])].toBytes()
                    uvbuf += noePack('2f', tri[2+ofs]/256, tri[3+ofs]/256)
        
            rapi.rpgBindPositionBuffer(vbuf, noesis.RPGEODATA_FLOAT, 12)
            rapi.rpgBindUV1Buffer(uvbuf, noesis.RPGEODATA_FLOAT, 8)
            rapi.rpgCommitTriangles(None, noesis.RPGEODATA_USHORT, len(vbuf)//12, noesis.RPGEO_TRIANGLE)
        else:
            #sort for materials
            dict = {}
            for x in range(numTextures):
                dict[x] = []
            
            for x in range(part[2],part[2]+part[3]):
                dict[int(triList[x][0])].append(x)
                
            for x in range(numTextures):
                if not dict[x]:
                    continue
                
                rapi.rpgSetMaterial(matList[x].name)
                
                vbuf, uvbuf = b'', b''
            
                for j in dict[x]:
                    for i in range(3):
                        ofs = (i*3)
                        vbuf += vertList[int(triList[j][1+ofs])].toBytes()
                        uvbuf += noePack('2f', triList[j][2+ofs]/256, triList[j][3+ofs]/256)
            
                rapi.rpgBindPositionBuffer(vbuf, noesis.RPGEODATA_FLOAT, 12)
                rapi.rpgBindUV1Buffer(uvbuf, noesis.RPGEODATA_FLOAT, 8)
                rapi.rpgCommitTriangles(None, noesis.RPGEODATA_USHORT, len(vbuf)//12, noesis.RPGEO_TRIANGLE)

        
    mdl = rapi.rpgConstructModel()
    mdl.setModelMaterials(NoeModelMaterials(texList, matList))
    mdlList.append(mdl)
    return 1