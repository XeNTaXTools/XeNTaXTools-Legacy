import newGameLib
reload(newGameLib)
from newGameLib import *
import Blender
	
import math
from math import *



def parseBone(g):
	bone=Bone()
	rot=g.f(4)
	bone.rotMatrix=Quaternion(rot[3],rot[0],rot[1],rot[2]).toMatrix().resize4x4()
	g.f(4)
	bone.posMatrix=TranslationMatrix(Vector(g.f(3)))
	g.f(5)
	data2 = g.i(4)
	name = g.word(g.i(1)[0])[-25:]
	#print name
	bone.name=name
	bone.parentID=data2[2]
	skeleton.boneList.append(bone) 
	
def parseImage(g):
	splitList=g.dirname.split(os.sep)
	
	
	search=Searcher()
	#search.dir=g.dirname.lower().split('char')[0]+os.sep+'char'
	search.dir=g.dirname.split(splitList[-2])[0]+'texture'
	print search.dir
	if os.path.exists(search.dir)==True:
	
		g.f(6)
		v=g.B(4)
		imageName = g.word(g.i(1)[0]).lower()+'.xtex'
		search.what=imageName
		search.run()
		if len(search.list)>0:
			file=open(search.list[0],'rb')
			p=BinaryReader(file)
			p.debug=False
			p.seek(16)
			name = Blender.sys.basename(p.find('\x00')).split('.')[0]
			p.i(4)
			type = p.i(1)[0]
			width = p.i(1)[0]
			height = p.i(1)[0]
			p.i(1)
			dxt =  p.read(4)
			mips =  p.i(1)[0]
			
			image=Image()
			image.name=search.list[0].replace('.xtex','dds')
			image.szer=width
			image.wys=height
			image.format=dxt
			image.data=p.read(p.fileSize()-p.tell())
			image.draw()
			if v[2]==2:
				mat.diffuse=image.name
			if v[2]==3:
				mat.specular=image.name
			if v[2]==5:
				mat.normal=image.name
			
			file.close()
	
def parseMesh(g):
	global usedVertexList
	vertPosList = []
	uvlist = []
	data1 = g.i(10)
	#print data1
	nVertexes = data1[2]
	nFaces = data1[3] 
	meshCount = data1[4]
	usedVertexList = g.i(data1[2])
	for m1 in range(data1[5]-1):
		data2 = g.i(3)
		#print data2
		if data2[0]==0:#position 
			for m in range(data1[2]):vertPosList.append(g.f(3))
		elif data2[0]==1:#normals 
			for m in range(data1[2]):g.f(3) 
		elif data2[0]==3:#uv
			for m in range(data1[2]):uvlist.append(g.f(2))
		elif data2[0]==2:
			for m in range(data1[2]):
				back1  = g.tell()
				xyz = g.f(4)
				g.seek(back1+data2[1])
		else:
			print 'unknow',data2
			break
	meshes_data = []
	vertIDstart=0
	for meshID in range(meshCount):
		mesh=Mesh()
		mesh.TRIANGLE=True
		#mesh.name=str(modelID)+'-model-'+str(meshID)
					
		v = g.i(4)	 
		indiceList = g.i(v[0])
		vertCount = v[1]
		fix_groups = g.i(v[3]) 
		id = v[2]
		material=matList[v[2]]
		material.TRIANGLE=True
		material.ZTRANS=True
					
		mesh.vertPosList=vertPosList[vertIDstart:vertIDstart+vertCount]
		mesh.vertUVList=uvlist[vertIDstart:vertIDstart+vertCount]
		mesh.indiceList=indiceList
		mesh.matList.append(material)
					
		skin=Skin()
		skin.vertexIDstart=vertIDstart
		skin.vertexIDcount=vertCount
		mesh.skinList.append(skin)
					
		vertIDstart+=vertCount
		if data1[6]==-256:#aby rozdzielic nody od modelu argo
			meshList.append(mesh)
		if data1[6]==-858993664:#aby rozdzielic nody od modelu warofdragons
			meshList.append(mesh)
						

def parseSkin(g):
	vertexweightsList=[]
	vertexindicesList=[]
	weightsList=[]
	indicesList=[]
	v = g.i(3)
	sum = 0 
				
	for m in range(v[1]):
		w = g.f(1)[0]
		gr = g.H(2)
		sum+=w 
		weightsList.append(w)
		indicesList.append(gr[0])
		if round(sum,4) == 1:
			vertexweightsList.append(weightsList)
			vertexindicesList.append(indicesList)						 
			weightsList=[]
			indicesList=[]
			sum = 0
	for mesh in meshList:
		vertIDstart=mesh.skinList[0].vertexIDstart
		vertCount=mesh.skinList[0].vertexIDcount
		weightsList=[]
		indicesList=[]
		for m in range(vertIDstart,vertIDstart+vertCount):
			weightsList.append(vertexweightsList[usedVertexList[m]])						
			indicesList.append(vertexindicesList[usedVertexList[m]])
		#mesh.skinList[0].indiceList=indicesList
		#mesh.skinList[0].weightList=weightsList
		mesh.skinIndiceList=indicesList
		mesh.skinWeightList=weightsList
		mesh.skinList[0].boneMap=skeleton.boneNameList
		mesh.skinList[0].vertexIDstart=None
		mesh.skinList[0].vertexIDcount=None
	
	
def xacParser(filename,g):	
	global skeleton
	global mat
	
	g.debug=False
		
	
	skeleton=Skeleton()
	skeleton.name='armature'
	skeleton.BONESPACE=True
	skeleton.DEL=True
	skeleton.NICE=True
	#skeleton.IK=True
	
	
	g.word(4)   
	g.H(16)
	g.word(g.i(1)[0])
	g.word(g.i(1)[0])
	g.word(g.i(1)[0])
	g.i(1),g.tell()
	#matID = 0
	while(True):
			data = g.i(3)#;print data
			back = g.tell()
			if data[0]==8:g.i(4)
			elif data[0]==0:
				
				parseBone(g)
			elif data[0]==3:
				#print 'MATERIAL',matID
				mat=Mat()
				#mat.name=str(modelID)+'-mat-'+str(matID)
				matList.append(mat)
				#matID+=1
			elif data[0]==4:
				#print 'IMAGE'
				parseImage(g)
			elif data[0]==1:
				#print 'MESH'
				parseMesh(g)
			elif data[0]==2:
				#print 'SKIN'
				parseSkin(g)					
			else:
				data4 = g.i(3)
			g.seek(back + data[1],0)   
			if g.tell()==g.fileSize():
				break
			
 
	print 'SKELETON'
	skeleton.draw()
	print 'MODEL'
	for mesh in meshList:
		mesh.BINDSKELETON=skeleton.name
		mesh.draw()

def xsmParser(filename,g):
	g.debug=False
	
	g.word(4)   
	g.H(12)
	g.word(g.i(1)[0])
	g.word(g.i(1)[0])
	g.word(g.i(1)[0])
	g.i(1)
	num = 0
	
	action=Action()
	action.name=Blender.sys.basename(filename).split('.')[0]
	action.BONESPACE=True
	action.BONESORT=True
	
	while(True):
		data = g.i(3)
		back = g.tell()
		if data[0]==200:			
			data2 = g.f(16)
			g.f(12)
			v=g.i(4)
			name = g.word(g.i(1)[0])[-25:]
			abone=ActionBone()
			abone.name=name
			for m in range(v[0]):   
				loc = g.f(3)
				time =  int(g.f(1)[0]*30)
				abone.posFrameList.append(time)
				posmatrix=TranslationMatrix(Vector(loc))
				abone.posKeyList.append(posmatrix)
			for m in range(v[1]):
				rot = g.f(4)
				time =  int(g.f(1)[0]*30)
				abone.rotFrameList.append(time)				
				qx,qy,qz,qw = rot[0],rot[1],rot[2],rot[3]
				rotmatrix=Quaternion(qw,qx,qy,qz).toMatrix().resize4x4()
				abone.rotKeyList.append(rotmatrix)
			for m in range(v[2]):g.f(3),round(g.f(1)[0]*30,0)
			for m in range(v[3]):g.f(4),round(g.f(1)[0]*30,0)
			action.boneList.append(abone)	
		g.seek(back + data[1]) 
		num+=1  
		if g.tell()==g.fileSize():break
	action.draw() 
	action.setContext()	
	g.tell()	
		
			
	
	
def Parser():	
	global meshList
	global matList
	global usedVertexList
	filename=input.filename
	print
	print filename
	print 
	ext=filename.split('.')[-1].lower()	
	dirname=Blender.sys.dirname(filename).lower()
	basename=Blender.sys.basename(filename).lower()
	
	all=False
		
	if ext=='xac':
		skeleton=Skeleton()
		skeleton.NICE=True
		skeleton.DEL=True
		skeleton.check()
		if all==False:
			meshList=[]
			matList=[]
			usedVertexList=None
			modelID=ParseID()	
			file=open(filename,'rb')
			g=BinaryReader(file)
			xacParser(filename,g)
			file.close()
		else:
			for file in os.listdir(dirname):
				if '.xac' in file:
					meshList=[]
					matList=[]
					usedVertexList=None
					modelID=ParseID()	
					filename=dirname+os.sep+file
					file=open(filename,'rb')
					g=BinaryReader(file)
					xacParser(filename,g)
					file.close()
			#export3DPACK('x:\\argo\\modele\\'+basename)
			Blender.Redraw()	
					
		
	if ext=='xsm':
		file=open(filename,'rb')
		g=BinaryReader(file)
		xsmParser(filename,g)
		file.close()
	

	
 
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
	
Blender.Window.FileSelector(openFile,'import','War of Dragons files  *.xac, *.xsm')