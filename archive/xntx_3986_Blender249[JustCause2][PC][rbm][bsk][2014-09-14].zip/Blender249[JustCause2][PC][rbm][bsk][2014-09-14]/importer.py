import newGameLib
reload(newGameLib)
from newGameLib import *
import Blender



def rbmParser(filename,g):
	g.word(g.i(1)[0])
	data = g.i(3)
	g.f(6)
	meshCount = g.i(1)[0]
	for meshID in range(meshCount):
		mesh=Mesh()
		values = g.B(9)
		g.f(6)
		if values[7] == 16: stride = 20
		elif values[7] == 8:stride = 28
		elif values[7] == 0:stride = 20
		elif values[7] == 1:stride = 20
		elif values[7] == 24:stride = 28
		elif values[7] == 5:stride = 20
		else:
			print 'error',values[7]
			break
		mat=Mat()   
		mat.TRIANGLE=True
		mat.diffuse=g.dirname+os.sep+g.word(g.i(1)[0])
		mat.normal=g.dirname+os.sep+g.word(g.i(1)[0])
		mat.specular=g.dirname+os.sep+g.word(g.i(1)[0])
			
			
		data = g.i(7)
		skin=Skin()
		for m in range(data[6]):
			tm=g.tell()
			mesh.vertPosList.append(g.f(3))
			mesh.skinWeightList.append(g.B((stride-12)/2))
			mesh.skinIndiceList.append(g.B((stride-12)/2))
			g.seek(tm+stride)
		for m in range(g.i(1)[0]):
			g.B(12)
			mesh.vertUVList.append(g.f(2))
		data = g.i(4)
		skin.boneMap = g.H(18)
		mesh.indiceList=g.H(g.i(1)[0])
		g.i(1)[0]
		mesh.matList.append(mat)
		mesh.skinList.append(skin)
		mesh.BINDSKELETON='armature'
		if bskFlag==True:
			mesh.boneNameList=boneNameList
		mesh.draw()

def bskParser(filename,g):
	skeleton.BONESPACE=True
	skeleton.NICE=True
	skeleton.BINDMESH=True
	g.seek(10480)
	g.word(16)
	parentList = g.h(84)#parent bones
	g.i(86)
	for m in range(84): 
		bone=Bone()
		bone.posMatrix=VectorMatrix(g.f(3))
		bone.rotMatrix=QuatMatrix(g.f(4))
		g.f(4)  
		bone.parentID=parentList[m]
		g.f(1)
		skeleton.boneList.append(bone)
	for m in range(84):
		g.i(4)
		bonename = g.find('\x00')
		g.seekpad(16)
		if bskFlag==True:
			skeleton.boneList[m].name=bonename
			boneNameList.append(bonename)
	for m in range(84):
		g.i(4)	
	
			


def tabParser(filename,g):
	g.logOpen()
	g.i(1)
	while(True):	
		if g.tell()>=g.fileSize():break
		fileList.append(g.i(3))
	g.logClose()	


def sarcParser(sarcDir,g):
	g.debug=True
	start=g.tell()-8
	st=g.tell()
	w = g.i(2)
	infoSize=w[1]
	while(True):
		len=g.i(1)[0]
		fileName=g.word(len)
		fileOffset,fileSize=g.i(2)
		if (g.tell()-st)>=infoSize:break
		print 'filename:',fileName
		back=g.tell()
		new=open(sarcDir+os.sep+fileName,'wb')
		g.seek(start+fileOffset)
		new.write(g.read(fileSize))
		new.close()
		g.seek(back)
			
		


def arcParser(filename,g):
	sys=Sys(filename)
	sys.addDir(sys.base+'_files')
	arcPath=g.dirname+os.sep+sys.base+'_files'
	for file in fileList:   
		g.seek(file[1]+4)
		chunk=g.word(4)
		if chunk=='SARC':
			sarcPath=arcPath+os.sep+'SARC'+'-'+str(g.tell())
			os.makedirs(sarcPath)
			sarcParser(sarcPath,g)
		
		

	
def Parser():   
	global fileList
	global skeleton
	global boneNameList
	global bskFlag
	filename=input.filename
	imageList=input.imageList
	ext=filename.split('.')[-1].lower() 
	fileList=[]
	
	skeleton=None
	boneNameList=[]
	bskFlag=False
	if ext=='rbm':
		bskPath=blendDir+os.sep+'biped.bsk'
		if os.path.exists(bskPath)==True:
			bskFlag=True
			skeleton=Skeleton()
			file=open(bskPath,'rb')
			g=BinaryReader(file)
			bskParser(bskPath,g)
			file.close()
			skeleton.draw()
		file=open(filename,'rb')
		g=BinaryReader(file)
		rbmParser(filename,g)
		file.close()
	
	if ext=='bsk':
		skeleton=Skeleton()
		file=open(filename,'rb')
		g=BinaryReader(file)
		bskParser(filename,g)
		file.close()
		skeleton.draw()
	
	if ext=='tab':
		file=open(filename,'rb')
		g=BinaryReader(file)
		tabParser(filename,g)
		file.close()
		
		arcPath=filename.replace('.tab','.arc')
		file=open(arcPath,'rb')
		g=BinaryReader(file)
		arcParser(arcPath,g)
		file.close()


			
			
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()

	
Blender.Window.FileSelector(openFile,'import','rbm - skinned mesh,bsk - skeleton file, tab - container') 