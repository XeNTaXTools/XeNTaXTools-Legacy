import newGameLib
from newGameLib import *
import Blender	

def datParser(filename,g):
	g.endian='>'
	#g.debug=True
	chunk=g.read(4)
	
	if chunk=='\x02\x02\x00\xff':
		A=g.i(7)
		B=g.H(3)
		g.seek(A[3])
		img=imageLib.Image()
		img.name=filename.lower().replace('.dat','.dds')
		img.szer=B[0]
		img.wys=B[1]
		#if B[2]==0:img.format='DXT1'
		if B[2]==1:img.format='DXT5'
		img.data=g.read(A[4])
		img.draw()
	
	
	if chunk=='\xff\x88\x77\x66':
		action=Action()
		action.skeleton='armature'
		#action.BONESORT=True
		action.FRAMESORT=True
		action.BONESPACE=True
		#action.ARMATURESPACE=True
	
		A=g.i(7)
		for m in range(A[3]):
			bone=ActionBone()
			bone.name=str(m)
			rotMatrix=QuatMatrix(g.f(4)).resize4x4()
			posMatrix=VectorMatrix(g.f(4))
			#matrix=rotMatrix*posMatrix
			#bone.matrixFrameList.append(0)
			#bone.matrixKeyList.append(matrix)
			bone.posFrameList.append(0)
			bone.rotFrameList.append(0)
			bone.posKeyList.append(posMatrix)
			bone.rotKeyList.append(rotMatrix)
			
			action.boneList.append(bone)
		start=g.tell()	
		for m in range(A[2]):
			g.word(4)
			B=g.i(6)
			boneList=g.i(B[2])
			print m,start+B[3]
			"""if m==1:
				back=g.tell()
				g.seek(start+B[3])
				for n in range(A[4]):#frame count
					for i in range(B[2]):#bone count	
						bone=action.boneList[boneList[i]]
						bone.posFrameList.append(1+n)
						bone.posKeyList.append(VectorMatrix(g.f(3)))
				g.seek(back)"""
			if m==2:
				back=g.tell()
				g.seek(start+B[3])
				for n in range(A[4]):#frame count
					for i in range(B[2]):#bone count	
						bone=action.boneList[boneList[i]]
						matrix=QuatMatrix(g.short(4,'h',15)).resize4x4()#*bone.bindmatrix
						#if n==0:
						#	bone.rotKeyList[0]*=matrix	
				g.seek(back)
			"""if m==3:
				back=g.tell()
				g.seek(start+B[3])
				for n in range(A[4]):#frame count
					for i in range(B[2]):#bone count
						bone=action.boneList[boneList[i]]
						posMatrix=VectorMatrix(g.f(3))
						rotMatrix=QuatMatrix(g.short(4,'h',15)).resize4x4().transpose()	
						matrix=rotMatrix#*posMatrix
						bone.matrixFrameList.append(1+n)
						bone.matrixKeyList.append(matrix)
				g.seek(back)"""
		action.draw()
		action.setContext()	
		Blender.Window.RedrawAll()
	
	
	if chunk=='\x88\xaa\x66\xbb':
		A=g.i(7)
		skeleton=Skeleton()
		skeleton.ARMATURESPACE=True
		skeleton.NICE=True
		for m in range(A[2]):
			bone=Bone()
			rotMatrix=QuatMatrix(g.f(4)).resize4x4()
			posMatrix=VectorMatrix(g.f(3))
			matrix=rotMatrix*posMatrix
			bone.matrix=matrix.invert()
			g.f(1)
			skeleton.boneList.append(bone)
		for m in range(A[2]):
			bone=skeleton.boneList[m]
			bone.parentID=g.i(1)[0]
		#g.i(A[2])
		#g.i(A[3])
		#g.f(40)	
		skeleton.BINDMESH=True
		skeleton.draw()		
	if chunk=='\xff\x88\x77\xbb':
		meshList=[]
		A=g.i(11)
		for m in range(A[2]):
			t=g.tell()
			mesh=Mesh()
			mat=Mat()
			mat.diffuse=g.dirname+os.sep+str(0)+'.dds'
			mat.normal=g.dirname+os.sep+str(1)+'.dds'
			mat.TRISTRIP=True
			mesh.matList.append(mat)
			B=g.i(12)
			print B
			mesh.vStart=B[5]
			mesh.iStart=B[6]
			mesh.vertCount=B[3]
			mesh.stride=B[11]
			mesh.indiceCount=B[2]
			mesh.boneMap=g.i(B[7])
			meshList.append(mesh)			
			g.seek(t+A[4])
		start=g.tell()	
		for m in range(A[2]):
			mesh=meshList[m]
			g.seek(start+mesh.vStart)
			for n in range(mesh.vertCount):
				t=g.tell()
				mesh.vertPosList.append(g.f(3))
				if mesh.stride==56:
					g.seek(t+24)
					mesh.vertUVList.append(g.f(2))
					mesh.skinIndiceList.append(g.B(4))
					mesh.skinWeightList.append(g.B(4))
					mesh.skinIDList.append([1])
				g.seek(t+mesh.stride)
			g.seek(start+mesh.iStart)
			mesh.indiceList=g.H(mesh.indiceCount)
			mesh.TRISTRIP=True
			if mesh.stride==56:
				skin=Skin()
				skin.boneMap=mesh.boneMap
				mesh.skinList.append(skin)
				mesh.draw()	
			
	g.debug=True		
	g.tell()
	
	
	
	
	
def Parser():	
	filename=input.filename
	print
	print filename
	print
	ext=filename.split('.')[-1].lower()	
	
	if ext=='dat':
		file=open(filename,'rb')
		g=BinaryReader(file)
		datParser(filename,g)
		file.close()
 
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
	
Blender.Window.FileSelector(openFile,'import','Invizimals The Lost Kingdom files: *.dat') 
	