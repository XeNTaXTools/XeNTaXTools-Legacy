# ================================================================================
# Midnight Club: LA (XBox 360, 2008)
# Noesis script by Dave, 2021
# ================================================================================

# NOTES:
# Extract files from xarchive_cache.rpf using RPFTool (or whatever other method works), and then decompress the resulting files and add .mcla extension for this script to work


from inc_noesis import *


def registerNoesisTypes():
	handle = noesis.register("Midnight Club: LA (XBox 360)",".mcla")
	noesis.setHandlerTypeCheck(handle, bcCheckType)
	noesis.setHandlerLoadModel(handle, bcLoadModel)
	return 1


def bcCheckType(data):
	bs = NoeBitStream(data)
	file_id = bs.readUInt()

	if file_id != 0x57c350:
		return 0
	else:
		return 1


# Read the model data

def bcLoadModel(data, mdlList):
	bs = NoeBitStream(data, NOE_BIGENDIAN)
	ctx = rapi.rpgCreateContext()

	curr_folder = rapi.getDirForFilePath(rapi.getInputName()).lower()
	curr_file = rapi.getLocalFileName(rapi.getInputName()).lower()

	bs.seek(8)
	main1 = GetOffset(bs)

	if main1 == 0:
		print("No meshes in this file")
		return 0

	bs.seek(main1)
	main2 = GetOffset(bs)
	main2_count = bs.readUShort()

	mesh_list = []
	bs.seek(main2)

	for a in range(main2_count):
		offset = GetOffset(bs)
		mesh_list.append(offset)

	for a in range(main2_count):
		bs.seek(mesh_list[a] + 4)
		main3 = GetOffset(bs)
		mesh_header_count = bs.readUShort()

		header_list = []

		bs.seek(main3)

		for h in range(mesh_header_count):
			mesh_header = GetOffset(bs)
			header_list.append(mesh_header)

		for h in range(mesh_header_count):
			mesh_header = header_list[h]
			bs.seek(mesh_header + 12)
			vertex_info = GetOffset(bs)
			bs.seek(12, NOESEEK_REL)
			face_info = GetOffset(bs)
			bs.seek(12, NOESEEK_REL)
			face_total = bs.readUInt()
			tri_count = bs.readUInt()
			vert_count = bs.readUShort()
			bs.seek(6, NOESEEK_REL)
			vert_stride = bs.readUShort()

			bs.seek(vertex_info + 4)
			vert_count = bs.readUShort()
			bs.readUShort()
			vert_data = GetOffset(bs)
			vert_stride = bs.readUInt()

			bs.seek(face_info + 8)
			face_data = GetOffset(bs)

			vertices = bytearray(vert_count * 12)
			uvs = bytearray(vert_count * 8)
			uv_flag = -1

# Read vertices - need to fix UVs, sometimes in different format/position ?

			bs.seek(vert_data)

			if vert_stride == 0x0c:
				for v in range(vert_count):
					vx = bs.readFloat()
					vy = bs.readFloat()
					vz = bs.readFloat()
					struct.pack_into("<fff", vertices, v*12, vx, vy, vz)

			elif vert_stride == 0x18:
				for v in range(vert_count):
					vx = bs.readFloat()
					vy = bs.readFloat()
					vz = bs.readFloat()
					bs.readBytes(12)
					struct.pack_into("<fff", vertices, v*12, vx, vy, vz)

			elif vert_stride == 0x1c:
				for v in range(vert_count):
					vx = bs.readFloat()
					vy = bs.readFloat()
					vz = bs.readFloat()
					bs.readUInt()
					uvx = bs.readHalfFloat()
					uvy = bs.readHalfFloat()
					bs.readBytes(8)
					struct.pack_into("<fff", vertices, v*12, vx, vy, vz)
					struct.pack_into("<ff", uvs, v*8, uvx, uvy)
					uv_flag = 1

			elif vert_stride == 0x20:
				for v in range(vert_count):
					vx = bs.readFloat()
					vy = bs.readFloat()
					vz = bs.readFloat()
					bs.readBytes(8)
					uvx = bs.readHalfFloat()
					uvy = bs.readHalfFloat()
					bs.readBytes(8)
					struct.pack_into("<fff", vertices, v*12, vx, vy, vz)
					struct.pack_into("<ff", uvs, v*8, uvx, uvy)
					uv_flag = 1

			elif vert_stride == 0x24:
				for v in range(vert_count):
					vx = bs.readFloat()
					vy = bs.readFloat()
					vz = bs.readFloat()
					struct.pack_into("<fff", vertices, v*12, vx, vy, vz)

			else:
				print("UNKNOWN STRIDE: ", vert_stride)


			rapi.rpgSetName("Mesh_" + str(a) + "_" + str(h))
			rapi.rpgBindPositionBuffer(vertices, noesis.RPGEODATA_FLOAT, 12)

			if uv_flag == 1:
				rapi.rpgBindUV1Buffer(uvs, noesis.RPGEODATA_FLOAT, 8)

			bs.seek(face_data)
			faces = bs.readBytes(face_total * 2)
			faces = rapi.swapEndianArray(faces, 2)
			rapi.rpgCommitTriangles(faces, noesis.RPGEODATA_USHORT, face_total, noesis.RPGEO_TRIANGLE)
			rapi.rpgClearBufferBinds()


	try:
		mdl = rapi.rpgConstructModel()
	except:
		mdl = NoeModel()

	mdlList.append(mdl)

	return 1


def GetOffset(bs):
	return bs.readUInt() & 0xfffffff


