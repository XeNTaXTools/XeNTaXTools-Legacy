#!/usr/bin/env python

__author__ = 'DizzyThermal'
__email__ = 'DizzyThermal@gmail.com'
__license__ = 'GNU GPLv3'

import array
import os
import sys

int_read = array.array('I')
_FILE_NAME_LENGTH = 13

def main(argv):
    if len(argv) < 2:
        print '\n'.join(
                ('Please provide input and output directories',
                    '',
                    'Example: $ dat_extractor.py <in-dir> <out-dir>'))
        sys.exit(1)
    else:
        in_dir = argv[1]
        out_dir = argv[2]

        if not os.path.isdir(in_dir):
            print 'Error: Invalid input directory: {}'.format(in_dir)
            sys.exit(1)
        if not os.path.isdir(out_dir):
            print 'Error: Invalid output directory: {}'.format(out_dir)
            sys.exit(1)
        if not os.access(out_dir, os.W_OK):
            print 'Error: Unable to write to output directory: {}'.format(out_dir)
            sys.exit(1)

    dat_files = os.listdir(in_dir)
    if not dat_files:
        print 'No DAT files in output directory: {}'.format(out_dir)
        sys.exit(0)

    dat_files.sort()

    print 'Processing {} DAT files'.format(len(dat_files))

    for dat_file in dat_files:
        print '  Processing: {}'.format(dat_file)
        dat_file = os.path.join(in_dir, dat_file)
        dat_file_handler = open(dat_file, 'rb')

        # Read number of Files
        int_read.fromfile(dat_file_handler, 1)
        num_of_files = int_read.pop() - 1
        print '\n'.join(
                ('  Number of Files to Extract: {}'.format(num_of_files),
                    ''))

        # Next File Location
        next_file_location = 0
        for k in range(num_of_files):
            # Read File Data Location
            int_read.fromfile(dat_file_handler, 1)
            data_location = int_read.pop()

            # Read File Name
            name = dat_file_handler.read(13).split(b'\0', 1)[0].decode()
            next_file_location = dat_file_handler.tell()

            # Read File Size (minus offset)
            int_read.fromfile(dat_file_handler, 1)
            size = int_read.pop() - data_location

            # Create Inner File Handler
            fn = os.path.join(out_dir, name)
            inner_file_handler = open(fn, 'wb')

            # Seek to File Data Location and Write
            print '    File:     {}'.format(name)
            print '    Size:     {}'.format(size)
            print '    Location: {}'.format(data_location)

            dat_file_handler.seek(data_location)
            inner_file_handler.write(dat_file_handler.read(size))
            print '\n'.join(('    Saved to: {}'.format(fn),
                ''))

            # Close Inner File Handler and Seek
            inner_file_handler.close()
            dat_file_handler.seek(next_file_location)

        dat_file_handler.close()

if __name__ == '__main__':
    main(sys.argv)
