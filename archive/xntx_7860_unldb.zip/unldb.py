import sys
from struct import unpack
from dataclasses import dataclass


@dataclass
class Face:
    offset: int
    count: int
    val3: int
    sub_mesh: int
    normal: (float, float, float)
    vec1: (float, float, float)


@dataclass()
class Triangle2:
    normal: (float, float, float)
    vec1: (float, float, float)
    val1: int
    val2: int
    val3: int
    val4: int
    val5: int
    val6: int


class ElementReader:
    def __init__(self):
        self.f = open(sys.argv[1], "rb")

    def set_list_lambda(self, list_lambda):
        self.list_lambda = list_lambda

    def read_element(self):
        t = unpack('b', self.f.read(1))[0]
        if t == 0x0D:
            string_length = self.read_element()
            return unpack("<" + str(string_length) + "s", self.f.read(string_length))[0].decode('ascii')
        if t == 0x11:
            self.f.seek(1, 1)
            data_size = self.read_element()
            return self.f.read(data_size)
        elif t == 0x12:
            data = unpack('BBB', self.f.read(3))
            return int.from_bytes(data, 'little')
        elif t == 0x13:
            return unpack('h', self.f.read(2))[0]
        elif t == 0x14:
            return unpack('b', self.f.read(1))[0]
        elif t == 0x16:
            return unpack('fff', self.f.read(12))
        elif t == 0x1c:
            num_elements = self.read_element()
            elements = []
            for i in range(num_elements):
                elements.append(self.list_lambda())
            print("We are at " + hex(self.f.tell()))
            return elements
        else:
            raise Exception("Invalid element")


def read_vec3():
    return ldb.read_element()


def read_triangle():
    t = Face(
        ldb.read_element(),
        ldb.read_element(),
        ldb.read_element(),
        ldb.read_element(),
        ldb.read_element(),
        ldb.read_element()
    )
    return t


def read_triangle2():
    t = Triangle2(
        ldb.read_element(),
        ldb.read_element(),
        ldb.read_element(),
        ldb.read_element(),
        ldb.read_element(),
        ldb.read_element(),
        ldb.read_element(),
        ldb.read_element()
    )
    return t


def read_index():
    return ldb.read_element()

ldb = ElementReader()

ldb.set_list_lambda(read_vec3)
position_list = ldb.read_element()
ldb.set_list_lambda(read_triangle)
face_list = ldb.read_element()
ldb.set_list_lambda(read_triangle2)
triangle2_list = ldb.read_element()
ldb.set_list_lambda(read_index)
index_list = ldb.read_element()

unknown = ldb.read_element()  # Always 32?
num_images = ldb.read_element()

for i in range(num_images):
    file_name = ldb.read_element()
    file_data = ldb.read_element()

    fout = open(file_name, "wb")
    fout.write(file_data)
    fout.close()
    print(file_name)

print("We are at " + hex(ldb.f.tell()))

fobj = open(sys.argv[1] + ".obj", "w")

for position in position_list:
    fobj.write("v %f %f %f\n" % position)

max_image = 0
for face in face_list:
    max_image = max(face.val3, max_image)
    indices = range(face.offset + 1, face.offset + face.count + 1)
    fobj.write("f")
    for index in indices:
        fobj.write(" %d" % index)
    fobj.write("\n")
    #fobj.write("f %d %d %d\n" % tuple(indices[:3]))


fobj.close()
