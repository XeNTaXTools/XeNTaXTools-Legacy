This update fixes sb0dump incompatibility problem with upcoming Ubisoft's
Prince of Persia: Warrior Within game sounds converting. However, it will not
support older Sands of Time, so i decided to release it as separate package.
Because both tools nearly the same, i advise you to read more detailed manual
how to use them available in popsottools05.zip archive.

If you want just to extract all music/sounds of ww, put both attached .exe's
and .bat files in to your prince of persia\sound folder and run .bat file.
Make sure you have about 1.5gb of free disk space!

changes history:
 7-dec : minor fix for compatibility with final game release, thanks to Z
15-oct : initial popww support

Enjoy,

Hadi Ranji
Hadi_Hercules@Yahoo.com