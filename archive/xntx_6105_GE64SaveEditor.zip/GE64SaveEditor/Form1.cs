﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GE64SaveEditor
{
    public partial class Form1 : Form
    {
        GE64SaveGame save;
        public Form1()
        {
            InitializeComponent();
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog d = new OpenFileDialog();
            d.Filter = "*.eep|*.eep";
            if(d.ShowDialog() == DialogResult.OK)
            {
                save = new GE64SaveGame(d.FileName);
                RefreshList();
            }
        }

        public void RefreshList()
        {
            listBox1.Items.Clear();
            if (save == null || !save.isValid) return;
            listBox1.Items.Add("Slot 1");
            listBox1.Items.Add("Slot 2");
            listBox1.Items.Add("Slot 3");
            listBox1.Items.Add("Slot 4");
            listBox1.Items.Add("Slot 5");
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int n = listBox1.SelectedIndex;
            if (n == -1 || save == null || !save.isValid) return;
            richTextBox1.Text = save.getSlotDetails(n);
        }
    }
}
