﻿using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GE64SaveEditor
{
    public class GE64SaveGame
    {
        public bool isValid = false;
        public byte[] raw;
        public GE64SaveGame(string path)
        {
            raw = File.ReadAllBytes(path);
            uint m1 = BitConverter.ToUInt32(raw, 0);
            uint m2 = BitConverter.ToUInt32(raw, 0);
            if(m1 == 0x33382489 && m2 == 0x33382489 && raw.Length == 0x200)
                isValid = true;
        }

        public byte[] getSlotDataRaw(int slot)
        {
            MemoryStream m = new MemoryStream();
            m.Write(raw, 0x20 + slot * 0x60, 0x60);
            return m.ToArray();
        }

        public string getSlotDetails(int slot)
        {
            StringBuilder sb = new StringBuilder();
            byte[] data = getSlotDataRaw(slot);
            MemoryStream m = new MemoryStream();
            m.Write(data, 0, 8);
            byte[] hash = m.ToArray();
            sb.Append("Hash : ");
            foreach (byte b in hash)
                sb.Append(b.ToString("X2"));
            sb.AppendLine("\n");
            for (int i = 0; i < 2; i++)
            {
                Level l = (Level)i;
                sb.AppendLine(l.ToString());
                sb.AppendLine("Time Agent   : " + toTime(ReadBits(data, timeMapAgent[l], 0xA)));
                sb.AppendLine("Time SAgent  : " + toTime(ReadBits(data, timeMapSAgent[l], 0xA)));
                sb.AppendLine("Time 00Agent : " + toTime(ReadBits(data, timeMap00Agent[l], 0xA)));
                sb.AppendLine();
            }
            return sb.ToString();
        }

        public ushort ReadBits(byte[] buff, int pos, int len)
        {
            ushort result = 0;
            for (int i = 0; i < len; i++)
            {
                result = (ushort)(result << 1);
                if (getBit(buff, pos + i))
                    result |= 1;
            }
            return result;
        }

        public bool getBit(byte[] buff, int pos)
        {
            byte b = buff[pos / 8];
            b = (byte)(b >> (7 - (pos % 8)));
            return (b & 1) == 1;
        }

        private string toTime(ushort sec)
        {
            if (sec == 0x3ff)
                return "--:--";
            else
                return (sec / 60) + ":" + (sec % 60).ToString("D2");
        }

        private enum Level
        {
            Dam,
            Facility
        }

        private Dictionary<Level, int> timeMapAgent = new Dictionary<Level, int>
        {
            {Level.Dam, 0x90},
            {Level.Facility, 0x9A}
        };

        private Dictionary<Level, int> timeMapSAgent = new Dictionary<Level, int>
        {
            {Level.Dam, 0x158},
            {Level.Facility, 0x162}
        };

        private Dictionary<Level, int> timeMap00Agent = new Dictionary<Level, int>
        {
            {Level.Dam, 0x220},
            {Level.Facility, 0x22A}
        };
    }
}
