#ROBOTICS NOTES Elite AR
#
from inc_noesis import *
import collections

def registerNoesisTypes():
	handle = noesis.register("ROBOTICS NOTES Elite AR", ".sdb")
	noesis.setHandlerTypeCheck(handle, rneARmodCheckType)
	noesis.setHandlerLoadModel(handle, rneARmodLoadModel)


	noesis.logPopup()

	return 1


def rneARmodCheckType(data):
	td = NoeBitStream(data)
	return 1


class sdbFile: 
         
	def __init__(self, bs):
		self.texList     = []
		self.matList     = []
		self.matDict     = {}
		self.boneList    = []
		self.boneMap     = []
		self.boneDict    = {}
		self.offsetList  = []
		self.meshOffsets = []
		self.loadAll(bs)


	def loadAll(self, bs):
		self.checkFilepair(bs)
		self.loadHeader(bs)
		self.loadMeshInfo(bs)
		self.loadBones(bs)
		self.loadTextures(bs)

	def loadMeshInfo(self, bs):
		meshBase = 0x54
		for a in range(0, self.Header[9]):
			bs.seek(self.Header[13] + (0x18C * a), NOESEEK_ABS)
			#print(bs.tell())
			bs.seek(0xE0, NOESEEK_REL)
			meshInfo = bs.read("6I")
			#print(meshInfo)
			boneMapCount = bs.readUInt()
			bonePos = bs.tell()
			boneMap = bs.read(boneMapCount * "H")
			if boneMapCount:
				rapi.rpgSetBoneMap(boneMap)
			else:
				rapi.rpgSetBoneMap(None)
			bs.seek(bonePos + 0x70, NOESEEK_ABS)
			matInfo = bs.read("10h")
			#print(matInfo)
			material = NoeMaterial("material_" + str(a), "")
			material.setFlags(noesis.NMATFLAG_TWOSIDED, 1)
			material.setTexture(str(matInfo[0]))
			if matInfo[1] != -1:
				material.setTexture(str(matInfo[1]))
				secondPassMat = NoeMaterial(material.name + "_ambient", str(matInfo[0]))
				secondPassMat.setFlags(noesis.NMATFLAG_TWOSIDED, 1)
				secondPassMat.setDiffuseColor( (0.8, 0.8, 0.8, 1.0) )
				material.setNextPass(secondPassMat)
			self.matList.append(material)
			rapi.rpgSetMaterial(material.name)
			bs.seek(meshBase + meshInfo[4], NOESEEK_ABS)
			vertStride = (meshInfo[5] - meshInfo[4]) // meshInfo[0]
			#print(vertStride)
			vertBuff = bs.readBytes((meshInfo[5] - meshInfo[4]))
			#for a in range(0, meshInfo[0]):
			if vertStride == 52:
				rapi.rpgBindPositionBufferOfs(vertBuff, noesis.RPGEODATA_FLOAT, vertStride, 0)
				rapi.rpgBindNormalBufferOfs(vertBuff, noesis.RPGEODATA_FLOAT, vertStride, 12)
				rapi.rpgBindUV1BufferOfs(vertBuff, noesis.RPGEODATA_FLOAT, vertStride, 24)
				if boneMapCount:
					rapi.rpgBindBoneIndexBufferOfs(vertBuff, noesis.RPGEODATA_UBYTE, vertStride, 32, 4)
					rapi.rpgBindBoneWeightBufferOfs(vertBuff, noesis.RPGEODATA_FLOAT, vertStride, 36, 4)
			else:
				print("Error New SIZE")
			bs.seek(meshBase + meshInfo[5], NOESEEK_ABS)
			#print(bs.tell())
			rapi.rpgSetName(str(a))
			faceBuff = bs.readBytes(meshInfo[1] * 2)
			rapi.rpgCommitTriangles(faceBuff, noesis.RPGEODATA_USHORT, meshInfo[1], noesis.RPGEO_TRIANGLE, 1)
			rapi.rpgClearBufferBinds()
			
	def loadBones(self, bs):
		for a in range(0, self.Header[10]):
			bs.seek(self.Header[14] + (0x1D0 * a), NOESEEK_ABS)
			bonepar = bs.read("8h")
			#print(bonepar)
			bs.seek(0x10C, NOESEEK_REL)
			bs.seek(0x24, NOESEEK_REL)
			#bs.seek(0x40, NOESEEK_REL)
			boneMtx = NoeMat44.fromBytes(bs.readBytes(64)).toMat43()
			bs.seek(0x40, NOESEEK_REL)
			bs.seek(0x10, NOESEEK_REL)
			#print(boneMtx)
			newBone = NoeBone(bonepar[0], str(bonepar[0]), boneMtx, None, bonepar[2])
			self.boneList.append(newBone)
		#self.boneList = rapi.multiplyBones(self.boneList)
		

	def loadTextures(self, bs):
		bs.seek(self.Header[15], NOESEEK_ABS)
		for a in range(0, self.Header[11]):
			#print(bs.tell())
			gxtSize = bs.readUInt()
			gxtData = bs.readBytes(gxtSize)
			gxt = gxtFile(NoeBitStream(gxtData), self.texList)
			gxt.loadAll(gxt.bs)


		
	def loadHeader(self, bs):
		self.Header = bs.read("21I")
		#print(self.Header)

	def checkFilepair (self, bs):
		if( rapi.checkFileExists( rapi.getDirForFilePath( rapi.getLastCheckedName() ) + "00000001" + ".vap" ) ):
			vapData = rapi.loadIntoByteArray( rapi.getDirForFilePath( rapi.getLastCheckedName() ) + "00000001" + ".vap" )
			#print("YES")
			#self.load_MTXI(txiData)
		
class gxtFile:

	def __init__(self, bs, texList):
		self.bs = bs
		self.texList = texList
		
	def loadAll(self, bs):
		self.loadGXTHeader(bs)
		self.loadGXT(bs)

	def loadGXTHeader(self, bs):
		self.texHeader = self.GXTHeader(*( \
		(noeStrFromBytes(bs.readBytes(4)),) \
		+ bs.read("7I")))
		#print(self.texHeader)
	
	def loadGXT(self, bs):
		texHeader = []

		for a in range(0, self.texHeader.texCount):
			bs.seek(0x20 + (a * 0x20), NOESEEK_ABS)
			texHeader.append(bs.read("5i4B2HI"))
			#print(texHeader[a])
			texName = str(len(self.texList))
			#print(info[a].split(','))
			bs.seek(texHeader[a][0], NOESEEK_ABS)
			texData = bs.readBytes(texHeader[a][1])
			self.psaLoadRGBA(texData, texHeader[a], texName)



	def psaLoadRGBA(self, texData, texInfo, texName):
		#print([texInfo[8], texInfo[9], texInfo[10]])
		#print("I am texture " + texName)

		texFmt = 0
		if texInfo[8] == 0x80:
			#PVRT2BPP
			texFmt = noesis.NOESISTEX_RGBA32
			texData = rapi.imageDecodePVRTC(texData, texInfo[9], texInfo[10], 2, noesis.PVRTC_DECODE_PVRTC2)
		elif texInfo[8] == 0x81:
			#PVRT4BPP
			texFmt = noesis.NOESISTEX_RGBA32
			texData = rapi.imageDecodePVRTC(texData, texInfo[9], texInfo[10], 4, noesis.PVRTC_DECODE_PVRTC2)
		elif texInfo[8] == 0x82:
			#PVRTII2BPP
			texFmt = noesis.NOESISTEX_RGBA32
			texData = rapi.imageDecodePVRTC(texData, texInfo[9], texInfo[10], 2, noesis.PVRTC_DECODE_PVRTC2)
		elif texInfo[8] == 0x83:
			#PVRTII4BPP
			texFmt = noesis.NOESISTEX_RGBA32
			texData = rapi.imageDecodePVRTC(texData, texInfo[9], texInfo[10], 4, noesis.PVRTC_DECODE_PVRTC2)
			texData = rapi.imageDecodeRaw(texData, texInfo[9], texInfo[10], "b8g8r8a8")
		elif texInfo[8] == 0xC:
			#texFmt = noesis.NOESISTEX_DXT1
			texFmt = noesis.NOESISTEX_RGBA32
			#texData = rapi.imageFromMortonOrder(texData, texInfo[9], texInfo[10])
			texData = rapi.imageFromMortonOrder(texData, texInfo[9], texInfo[10], 32 // 8, 2)
			texData = rapi.imageDecodeRaw(texData, texInfo[9], texInfo[10], "b8g8r8a8")
		elif texInfo[8] == 0x0:
			texFmt = noesis.NOESISTEX_RGBA32
			#texData = rapi.imageFromMortonOrder(texData, texInfo[9], texInfo[10])
			texData = rapi.imageFromMortonOrder(texData, texInfo[9]>>1, texInfo[10]>>2, 4)
			texData = rapi.imageDecodeRaw(texData, texInfo[9], texInfo[10], "b8g8r8a8")
		elif texInfo[8] == 0x85:
			#texFmt = noesis.NOESISTEX_DXT1
			texFmt = noesis.NOESISTEX_RGBA32
			texData = rapi.imageFromMortonOrder(texData, texInfo[9]>>1, texInfo[10]>>2, 4)
			texData = rapi.imageDecodeDXT(texData, texInfo[9], texInfo[10], noesis.FOURCC_DXT1)
			texData = rapi.imageDecodeRaw(texData, texInfo[9], texInfo[10], "r8g8b8a8")
		elif texInfo[8] == 0x86:
			#texFmt = noesis.NOESISTEX_DXT3
			texFmt = noesis.NOESISTEX_RGBA32
			texData = rapi.imageFromMortonOrder(texData, texInfo[9]>>1, texInfo[10]>>2, 8)
			texData = rapi.imageDecodeDXT(texData, texInfo[9], texInfo[10], noesis.FOURCC_DXT3)
			texData = rapi.imageDecodeRaw(texData, texInfo[9], texInfo[10], "r8g8b8a8")
		elif texInfo[8] == 0x87:
			#texFmt = noesis.NOESISTEX_DXT5
			texFmt = noesis.NOESISTEX_RGBA32
			texData = rapi.imageFromMortonOrder(texData, texInfo[9]>>1, texInfo[10]>>2, 8)
			texData = rapi.imageDecodeDXT(texData, texInfo[9], texInfo[10], noesis.FOURCC_DXT5)
			texData = rapi.imageDecodeRaw(texData, texInfo[9], texInfo[10], "r8g8b8a8")
		elif texInfo[8] == 0x8B:
			texFmt = noesis.NOESISTEX_RGBA32
			texData = rapi.imageFromMortonOrder(texData, texInfo[9]>>1, texInfo[10]>>2, 8)
			#texData = rapi.imageDecodeDXT(texData, texInfo[9], texInfo[10], noesis.FOURCC_ATI2)
			#texData = rapi.swapEndianArray(texData, 2)
			#texData = rapi.imageDecodePVRTC(texData, texInfo[9], texInfo[10], 4, noesis.PVRTC_DECODE_PVRTC2)
			texData = rapi.imageDecodeRaw(texData, texInfo[9], texInfo[10], "b8g8r8a8")
		elif texInfo[8] == 0x95:
			texFmt = noesis.NOESISTEX_RGBA32
			texData = rapi.imageFromMortonOrder(texData, texInfo[9]>>1, texInfo[10]>>2, 8)
			texData = rapi.imageDecodeRaw(texData, texInfo[9], texInfo[10], "r8g8b8a8")
		elif texInfo[8] == 0x98:
			texFmt = noesis.NOESISTEX_RGBA32
			texData = rapi.imageFromMortonOrder(texData, texInfo[9], texInfo[10], 24 // 8, 2)
			texData = rapi.imageDecodeRaw(texData, texInfo[9], texInfo[10], "b8g8r8")
		#tex1 = NoeTexture(str(texInfo[8]), texInfo[9], texInfo[10], texData, texFmt)
		tex1 = NoeTexture(texName, texInfo[9], texInfo[10], texData, texFmt)
		#print(tex1)
		if texFmt == 0:
			print("ERROR NOT FOUND")
		self.texList.append(tex1)

		
	# GXT Header
	GXTHeader = collections.namedtuple('GXTHeader', ' '.join((
		'magic',
		'version',
		'texCount',
		'texDataOff',
		'texDataSize',
		'P4Pallet',
		'P8Pallet',
		'pad0'
	)))

def rneARmodLoadModel(data, mdlList):
	ctx = rapi.rpgCreateContext()
	sdb = sdbFile(NoeBitStream(data))
	try:
		mdl = rapi.rpgConstructModel()
	except:
		mdl = NoeModel()
	mdl.setModelMaterials(NoeModelMaterials(sdb.texList, sdb.matList))
	mdlList.append(mdl); mdl.setBones(sdb.boneList)	
	return 1

