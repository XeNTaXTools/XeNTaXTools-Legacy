from inc_noesis import *
import noesis
import rapi

def registerNoesisTypes():
	handle = noesis.register("Aliens vs Predators",".rscf")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadModel(handle, noepyLoadModel)
	return 1
	
def noepyCheckType(data):
    bs = NoeBitStream(data)
    Magic = bs.readBytes(4)
    if Magic != b'\x0A\x00\x00\x00':
        return 0
    return 1  

def noepyLoadModel(data, mdlList):
	ctx = rapi.rpgCreateContext()
	bs = NoeBitStream(data)

	bs.seek(0x4, NOESEEK_ABS)
	VCnt = bs.readUInt()
	bs.seek(0x8, NOESEEK_ABS)
	FCnt = bs.readUInt()
	print("VCnt, ", VCnt)
	print("hex VCnt: ",hex(VCnt))
	print("FCnt, ", FCnt)
	print("hex FCnt: ",hex(FCnt))

	bs.seek(0XA1, NOESEEK_REL)
	Jump= bs.readUInt()
	print("Jump hex: ",hex(Jump))
	print("Jump, ", Jump)
	bs.seek(Jump-53, NOESEEK_REL)
	Voffset= bs.readUInt()
	print("hex Voffset: ",hex(Voffset))

	FVFsize = int(64)
	#bs.seek(Voffset, NOESEEK_ABS)
	VBSize = VCnt * FVFsize
	VBuff = bs.readBytes(VBSize)

	rapi.rpgBindPositionBufferOfs(VBuff, noesis.RPGEODATA_FLOAT, FVFsize, 0)
	rapi.rpgBindUV1BufferOfs(VBuff, noesis.RPGEODATA_HALFFLOAT, FVFsize, 52)

	addr=bs.tell()
	fileBuff = bs.data[addr:bs.dataSize]
	addr1= fileBuff.find(b'\x00\x00\x80\x3F\x00\x00\x01\x00')
	addr += addr1
	print("addr: ",hex(addr))
	bs.seek(addr)
	bs.seek(-3, NOESEEK_REL)
	Foffset= bs.tell()
	#Foffset= bs.readUInt()
	print("FIs at:", hex(Foffset))
	#bs.seek(Foffset, NOESEEK_ABS)
	FBuff = bs.readBytes(FCnt*2)

	#rapi.rpgBindPositionBufferOfs(VBuff, noesis.RPGEODATA_FLOAT, FVFsize, 0)
	#rapi.rpgBindUV1BufferOfs(VBuff, noesis.RPGEODATA_HALFFLOAT, FVFsize, 52)
	rapi.rpgCommitTriangles(FBuff, noesis.RPGEODATA_USHORT, FCnt, noesis.RPGEO_TRIANGLE_STRIP, 1)
	
	mdl = rapi.rpgConstructModel()
	mdlList.append(mdl)
	rapi.rpgClearBufferBinds()
	return 1