#Noesis Python model import+export test module, imports/exports some data from/to a made-up format

from inc_noesis import *

import noesis

#rapi methods should only be used during handler callbacks
import rapi

#registerNoesisTypes is called by Noesis to allow the script to register formats.
#Do not implement this function in script files unless you want them to be dedicated format modules!
def registerNoesisTypes():
	handle = noesis.register("Senran Kagura Shinovi Versus Vita Texture", ".gxt")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadRGBA(handle, gxtLoadRGBA) #see also noepyLoadModelRPG
	#noesis.logPopup()
	#print("The log can be useful for catching debug prints from preview loads.\nBut don't leave it on when you release your script, or it will probably annoy people.")
	return 1     

NOEPY_HEADER = "GXT"

#check if it's this type based on the data
def noepyCheckType(data):
   bs = NoeBitStream(data)
   if len(data) < 3:
      return 0
   if bs.readBytes(3).decode("ASCII").rstrip("\0") != NOEPY_HEADER:
      return 0
   return 1 

#load the model and textures
def gxtLoadRGBA(data, texList):
        ctx = rapi.rpgCreateContext()
        bs = NoeBitStream(data)
        bs.seek(0x8, NOESEEK_ABS)
        Files = bs.read("i")
        DOffset = bs.read("i")
        FSize = bs.read("i")
        FSize = FSize[0] + DOffset[0]
        for i in range(0, Files[0]):
                bs.seek(0x20 + (0x20 * i), NOESEEK_ABS)
                Offset = bs.read("i")
                SType = bs.read("i")
                bs.seek(0xC, NOESEEK_REL)
                Type = bs.read(">i")
                Width = bs.read("h")
                Height = bs.read("h")
                bs.seek(0x4, NOESEEK_REL)
                Offset2 = bs.read("i")
                if i == Files[0] - 1:
                        Size = FSize - Offset[0]
                else:
                        Size = Offset2[0] - Offset[0]
                texFmt = 0
                Name = rapi.getExtensionlessName(rapi.getLocalFileName(rapi.getInputName())) + "_" + str(i)
                bs.seek(Offset[0], NOESEEK_ABS)
                data = bs.readBytes(Size)
                swizz = 0
                #DXT1
                if Type[0] == 133:
                        if SType[0] == 512 or SType[0] == 2048 or SType[0] == 16384 or SType[0] == 32768 or SType[0] == 65536 or SType[0] == 131072:
                                texFmt = noesis.NOESISTEX_DXT1
                                swizz = 1
                        else:
                                texFmt = noesis.NOESISTEX_DXT1
                #DXT5
                if Type[0] == 135:
                        texFmt = noesis.NOESISTEX_DXT5
                        swizz = 1
                if swizz == 1:
                        dxtBlockBytes = 4 if texFmt == noesis.NOESISTEX_DXT1 else 8
                        tex1 = rapi.imageFromMortonOrder(data, Width[0]>>1, Height[0]>>2, dxtBlockBytes)
                        tex1 = NoeTexture(Name, Width[0], Height[0], tex1, texFmt)
                else:
                        tex1 = NoeTexture(Name, Width[0], Height[0], data, texFmt)
                texList.append(tex1)
        return 1
