
Make_obj, special version for MarieRose1301

###############################################
####### please don't upload it anywhere! ######
###############################################

Project compiled using CodeBlocks 13.12 for example

Other than the rest of the 3D formats handled in Make_obj
"One4All" creates separate submeshes, not all-in-one obj.


have fun,
shak-otay

provided as is - the author can't be made responsible for any problems 
that might arise using the code and/or the exe
