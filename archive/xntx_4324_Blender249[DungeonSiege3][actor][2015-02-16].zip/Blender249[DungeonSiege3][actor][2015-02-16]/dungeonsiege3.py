import newGameLib
from newGameLib import *
import Blender	

def mtrlParser(mat,p):
	p.word(4)
	p.i(2)
	mat.name = p.word(32)
	data = p.i(9)
	p.B(240)
	print mat.name
	for m in range(data[7]):
		name = p.word(32)
		print m,p.tell(),name
		if m==0:			
			for path in ddsList:
				if name in path:mat.diffuse=path
		if m==1:			
			for path in ddsList:
				if name in path:mat.normal=path
		if m==2:			
			for path in ddsList:
				if name in path:mat.specular=path
		p.B(24)		
		
def matParser(mat,p):
	p.word(4) 
	A = p.i(3)
	for m in range(A[2]):	   
		name = p.word(4)
		seek = p.i(1)[0]
		back = p.tell() 
		p.seek(seek)
		if name == 'MTRL':mtrlParser(mat,p)
		p.seek(back)


def modlParser(filename,g):
	g.word(4)
	data = g.i(3)
	for m in range(data[2]):
		tm = g.tell()
		meshName = g.word(32)
		mesh=None
		for mesh in meshList:
			if mesh.name==meshName:
				break
		mat=Mat()
		mat.ZTRANS=True
		mat.TRIANGLE=True
		mat.name = g.word(32)
		for path in opfList:
			if mat.name+'.opf' in path:	
				file=open(path,'rb')
				p=BinaryReader(file)
				matParser(mat,p)
				file.close()
		mesh.matList.append(mat)
		g.seek(tm+172)

def meshParser(filename,g):
	mesh=Mesh()
	g.word(4)
	g.i(2)
	mesh.name = g.word(32)
	data1 = g.i(10)
	data2 = g.f(6)
	data3 = g.i(9)
	mesh.stride=data1[5]
	mesh.posType=data1[4]
	mesh.vertCount=data1[3]
	mesh.vertOffset=data3[1]
	mesh.indiceCount=data1[6]
	mesh.indiceOffset=data3[3]
	meshList.append(mesh)		
		
def modelParser(filename,g):
	g.word(4) 
	A = g.i(3)
	for m in range(A[2]):	   
		name = g.word(4)
		seek = g.i(1)[0]
		back = g.tell() 
		g.seek(seek)
		if name == 'MESH':meshParser(filename,g)
		elif name == 'MODL':modlParser(filename,g)
		elif name == 'MTRL':mtrlParser(filename,g)
		g.seek(back)		
		
def opfParser(filename,g):
	g.word(4) 
	A = g.i(3)
	for m in range(A[2]):	   
		name = g.word(4)
		seek = g.i(1)[0]
		back = g.tell() 
		g.seek(seek)
		if name == 'MESH':meshParser(filename,g)
		g.seek(back)

def rvdParser(filename,g):	
	for mesh in meshList:
		g.seek(mesh.indiceOffset)
		mesh.indiceList=g.H(mesh.indiceCount)
		
		

def ridParser(filename,g):	
	for mesh in meshList:
		g.seek(mesh.vertOffset)
		for n in range(mesh.vertCount):
			back = g.tell()
			mesh.vertPosList.append(g.f(3))
			g.seek(back+36)
			mesh.vertUVList.append(g.f(2))
			g.seek(back+48)
			mesh.skinWeightList.append(g.f(4))
			mesh.skinIndiceList.append(g.B(4))
			mesh.skinIDList.append([1])
			g.seek(back+mesh.stride)
		skin=Skin()
		mesh.skinList.append(skin)
		
		
		
def rigParser(filename,g):
	g.seek(628,1)
	A = g.i(4)
	for m in range(A[1]): 
		bone=Bone()
		B = g.i(5)
		bone.parentID=B[3]
		g.f(8)
		g.f(8)
		bone.matrix = Matrix4x4(g.f(16))
		g.f(1)
		skeleton.boneList.append(bone)
		

def actorParser(filename,file):
	global meshList,skeleton
	global Raw_Vertex_Data
	
	skeleton=Skeleton()
	skeleton.NICE=True
	
	meshList=[]
	
	xml=Xml()
	xml.input=file
	xml.parse()
	root=xml.root
	OEIActor=xml.get(root,'OEIActor')
	
	Render_Geometry=xml.get(OEIActor,'Render_Geometry').values
	opfPath=gameDir+os.sep+Render_Geometry
	if os.path.exists(opfPath):		
		file=open(opfPath,'rb')
		g=BinaryReader(file)
		opfParser(opfPath,g)
		file.close()
		
	Raw_Vertex_Data=xml.get(OEIActor,'Raw_Vertex_Data').values
	rvdPath=gameDir+os.sep+Raw_Vertex_Data
	if os.path.exists(rvdPath):		
		file=open(rvdPath,'rb')
		g=BinaryReader(file)
		rvdParser(rvdPath,g)
		file.close()
		
	Raw_Index_Data=xml.get(OEIActor,'Raw_Index_Data').values
	ridPath=gameDir+os.sep+Raw_Index_Data
	if os.path.exists(ridPath):		
		file=open(ridPath,'rb')
		g=BinaryReader(file)
		ridParser(ridPath,g)
		file.close()
		
	Model=xml.get(OEIActor,'Model').values
	modelPath=gameDir+os.sep+Model
	if os.path.exists(modelPath):		
		file=open(modelPath,'rb')
		g=BinaryReader(file)
		modelParser(modelPath,g)
		file.close()
		
	Rig=xml.get(OEIActor,'Rig')
	if Rig is not None:
		rigPath=gameDir+os.sep+Rig.values
		if os.path.exists(rigPath):		
			file=open(rigPath,'rb')
			g=BinaryReader(file)
			rigParser(rigPath,g)
			file.close()
	skeleton.draw()	
	skeleton.object.setMatrix(Euler(90,0,-90).toMatrix())
	for mesh in meshList:
		mesh.BINDSKELETON=skeleton.name
		mesh.draw()
		
			
		
	
def Parser():
	global gameDir,opfList,ddsList
	filename=input.filename
	print
	print filename
	print 	
	
	ext=filename.split('.')[-1].lower()	
	
	gameDir=None
	opfList=[]
	ddsList=[]
	if 'character' in filename.lower():	
		gameDir=filename.split('character')[0]
	if gameDir is not None:
	
		search=Searcher()
		search.what='.opf'
		search.dir=gameDir
		search.run()
		opfList=search.list		
		
		search=Searcher()
		search.what='.dds'
		search.dir=gameDir
		search.run()
		ddsList=search.list
		
		print 'count opf files:',len(search.list)
		if ext=='actor':
			file=open(filename,'r')
			actorParser(filename,file)
			file.close()
	else:
		print 'File is outside of "character" folder'
 
def openFile(flagList):
	global input,output	
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
	
Blender.Window.FileSelector(openFile,'import','Dungeon Siege 3 files: *.actor') 
	