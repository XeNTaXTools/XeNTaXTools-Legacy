well, this is my endianness swapper for binary 3D model files.
The idea is to swap vertex and face index (FI) data from big endian to little endian or vice versa.

Generally you can swap face index data using a hexeditor supporting byte swapping for WORD (16 bit uint).
For combined data as is for head_192190_0_0_0.rx3 (vertex float and uvs half float) it's not so simple.

Here is where Make_obj-swap.exe will come in handy.
Follow the instructions carefully.

A param.txt file is required (one for the vertex block, another for the FIs, see params-FIs folder)

I won't explain in detail how to create params.txt for different model files
but using hex2obj (another tool of mine) with head_192190_0_0_0.rx3 and the belonging H2O file
should give some understanding.

You can find the rx3 file in the HEADS.rar from the opening post here:
http://forum.xentax.com/viewtopic.php?f=16&t=19026

instructions
------------
Start Make_obj-swap and load head_192190_0_0_0.rx3; params.txt must be present in the same folder!
A swapped.bin will be created.

RENAME it to swappedv.bin and copy it to the folder params-FI.
Start Make_obj-swap and load swappedv.bin,
another swapped.bin will be created with FIs swapped, too.

Finally you can copy the FIs block (size: FIcount x 2) and the vertex block (size vertexCount x FVFsize)
from that swapped.bin to (FIFA12) head_115533_0.rx3.

shak-otay, Nov 2018