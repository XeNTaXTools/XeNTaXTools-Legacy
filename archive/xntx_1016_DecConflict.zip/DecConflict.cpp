// DecConflict.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "WaveWriter.h"

/* VAG decoder, eh? */

double VAG_f[5][2] = { { 0.0 , 0.0 },
                   { 60.0 / 64.0, 0.0 },
		   { 115.0 / 64.0, -52.0 / 64.0 },
		   { 98.0 / 64.0, -55.0 / 64.0 } ,
		   { 122.0 / 64.00, -60.0 / 64.0 } } ;

int VAGdecodebuffer(unsigned char * input, short * out, short * hist1p, short * hist2p) {
	int predict_nr, shift_factor, flags;
	short hist1=*hist1p, hist2=*hist2p;
	int sample;
	int s;
	int i;
	predict_nr = input[0] >> 4;
	shift_factor = input[0] & 0xf;
	flags = input[1];
	for (i=0;i<28;i+=2) {
		s = (short)((input[i/2+2]&0xf)<<12)-1; //+2;
		sample=(int)((s >> shift_factor)+hist1*VAG_f[predict_nr][0]+hist2*VAG_f[predict_nr][1]+0.5);

		if (sample >= 32767)
			sample =  32767;

		else if (sample <= -32768)
			sample = -32768;
		out[i]=sample;
		hist2=hist1;
		hist1=sample;
		s = (short)((input[i/2+2]>>4)<<12)-1; //+2;
		sample=(int)((s >> shift_factor)+hist1*VAG_f[predict_nr][0]+hist2*VAG_f[predict_nr][1]+0.5);
		if (sample >= 32767)
			sample =  32767;
		else if (sample <= -32768)
			sample = -32768;
		out[i+1]=sample;
		hist2=hist1;
		hist1=sample;
	}
	*hist1p=hist1;
	*hist2p=hist2;
	return 0;
}

// The arguments sent to the application
struct SArguments
{
	SArguments() :
		ShowBanner(true),
		ShowUsage(false),
		InputFilename(""),
		OutputFilename(""),
		OuputWaveFile(true),
		OutputSampleRate(44100)
	{
	};

	bool ShowBanner;
	bool ShowUsage;
	std::string InputFilename;
	std::string OutputFilename;
	bool OuputWaveFile;
	unsigned long OutputSampleRate;
};

// Parse the arguments sent to the program
bool ParseArguments(SArguments& Args, unsigned long Argc, _TCHAR* Argv[])
{
	// Go through each of the arguments sent
	for(unsigned long i=1;i<Argc;)
	{
		std::string Arg(Argv[i++]);
		
		// Check it
		if(Arg=="-b" || Arg=="--no-banner")
		{
			Args.ShowBanner=false;
		}
		else if(Arg=="-o" || Arg=="--output")
		{
			if(i>=Argc)
			{
				return false;
			}
			Args.OutputFilename=std::string(Argv[i++]);
		}
		else if(Arg=="-w" || Arg=="--wave")
		{
			Args.OuputWaveFile=true;
		}
		else if(Arg=="-r" || Arg=="--raw")
		{
			Args.OuputWaveFile=false;
		}
		else if(Arg=="--sample-rate")
		{
			if(i>=Argc)
			{
				return false;
			}
			Args.OutputSampleRate=atoi(Argv[i++]);
		}
		else
		{
			Args.InputFilename=Arg;
		}
	}
	return true;
}

int _tmain(int Argc, _TCHAR* Argv[])
{
	// Parse the arguments
	SArguments Args;
	if(Argc==1)
	{
		Args.ShowUsage=true;
	}
	bool ArgParse=ParseArguments(Args, Argc, Argv);

	// Display banner
	if(Args.ShowBanner)
	{
		std::cerr << "Decode Conflict Denied Ops VAG Variant" << std::endl << std::endl;
	}

	// Display usage
	if(Args.ShowUsage)
	{
		std::cout << "Usage: DecConflict InputFilename [Options]" << std::endl;
		std::cout << std::endl;
		std::cout << "  -o, --output File     Specify the output filename" << std::endl;
		std::cout << "  -w, --wave            Output a standard wave file (.wav)" << std::endl;
		std::cout << "  -r, --raw             Output raw data (no header)" << std::endl;
		std::cout << "  --sample-rate Rate    Force a specific sampling rate" << std::endl;
		std::cout << std::endl;
	}

	// Check for errors
	if(!ArgParse)
	{
		std::cerr << "The arguments are not valid." << std::endl;
		return 1;
	}
	if(Args.InputFilename.empty())
	{
		std::cerr << "You need to enter an input filename." << std::endl;
		return 1;
	}
	if(Args.OutputFilename.empty())
	{
		std::cerr << "You need to enter an output filename." << std::endl;
		return 1;
	}

	// Load the input file
	std::ifstream Input;
	Input.open(Args.InputFilename.c_str(), std::ios_base::in | std::ios_base::binary);
	if(!Input.is_open())
	{
		std::cerr << "Could not open input file \"" << Args.InputFilename << "\"." << std::endl;
		return 1;
	}

	// Load the output file
	std::ofstream Output;
	Output.open(Args.OutputFilename.c_str(), std::ios_base::out | std::ios_base::binary | std::ios_base::trunc);
	if(!Output.is_open())
	{
		std::cerr << "Could not open output file \"" << Args.OutputFilename << "\"." << std::endl;
		return 1;
	}
	PrepareWaveHeader(Output);

	// Some properties
	const unsigned char BitsPerSample=16;
	const unsigned char Channels=2;
	unsigned long SampleCount=0;
	short LeftHistory1=0;
	short LeftHistory2=0;
	short RightHistory1=0;
	short RightHistory2=0;

	// Read the file
	while(!Input.eof())
	{
		unsigned char InputBuffer[16];
		short LeftOutputBuffer[28];
		short RightOutputBuffer[28];
		short OutputBuffer[56];

		// Left
		Input.read((char*)InputBuffer, 16);
		if(Input.gcount()<16)
		{
			break;
		}
		VAGdecodebuffer(InputBuffer, LeftOutputBuffer, &LeftHistory1, &LeftHistory2);
		SampleCount+=28;

		// Right
		Input.read((char*)InputBuffer, 16);
		if(Input.gcount()<16)
		{
			break;
		}
		VAGdecodebuffer(InputBuffer, RightOutputBuffer, &RightHistory1, &RightHistory2);
		SampleCount+=28;

		// Put them together
		unsigned long j=0;
		for(unsigned long i=0;i<56;i+=2)
		{
			OutputBuffer[i]=LeftOutputBuffer[j];
			j++;
		}
		j=0;
		for(unsigned long i=1;i<56;i+=2)
		{
			OutputBuffer[i]=RightOutputBuffer[j];
			j++;
		}

		// Write it
		Output.write((char*)OutputBuffer, 112);
	}

	// Close the files
	Output.seekp(0);
	WriteWaveHeader(Output, Args.OutputSampleRate, BitsPerSample, Channels, SampleCount);
	Input.close();
	Output.close();
	return 0;
}

