from inc_noesis import *
import noesis
import rapi

def registerNoesisTypes():
    handle = noesis.register("Sudden Attack", ".ltb")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    return 1

def noepyLoadModel(data, mdlList):
    ctx = rapi.rpgCreateContext()
    bs = NoeBitStream(data)
    bs.seek(0x5e, NOESEEK_ABS) 
    numSubmesh = bs.readUByte()
    for i in range(numSubmesh):
        skip = bs.readBytes(3)
        meshNamesize = bs.readUShort()
        meshName = bs.readBytes(meshNamesize).decode("ASCII")
        numLODs = bs.readUInt()
        bs.seek(0x39, NOESEEK_REL)
        for j in range(numLODs):
            rapi.rpgSetName(meshName + "_LOD" + str(j))
            sectionSize = bs.readUInt()
            startsectionSize = bs.tell()
            vertex_count = bs.readUInt()   
            face_count = bs.readUInt() * 3  
            vertex_stride = (sectionSize - 0x32 - (face_count * 2)) // vertex_count
            oldmeshType = bs.readUInt()
            if vertex_stride == 31:
                vertex_stride = 32
                bs.seek(0x18, NOESEEK_REL)
            else:
                bs.seek(0x16, NOESEEK_REL)                
            VertexBuffer = bs.readBytes(vertex_count * vertex_stride)
            if vertex_stride == 32:
                rapi.rpgBindPositionBufferOfs(VertexBuffer, noesis.RPGEODATA_FLOAT, 32, 0)
                rapi.rpgBindNormalBufferOfs(VertexBuffer, noesis.RPGEODATA_FLOAT, 32, 12)
                rapi.rpgBindUV1BufferOfs(VertexBuffer, noesis.RPGEODATA_FLOAT, 32, 24)
            elif vertex_stride == 36:
                rapi.rpgBindPositionBufferOfs(VertexBuffer, noesis.RPGEODATA_FLOAT, 36, 0)
                rapi.rpgBindNormalBufferOfs(VertexBuffer, noesis.RPGEODATA_FLOAT, 36, 16)
                rapi.rpgBindUV1BufferOfs(VertexBuffer, noesis.RPGEODATA_FLOAT, 36, 28)
            elif vertex_stride == 40:
                rapi.rpgBindPositionBufferOfs(VertexBuffer, noesis.RPGEODATA_FLOAT, 40, 0)
                rapi.rpgBindNormalBufferOfs(VertexBuffer, noesis.RPGEODATA_FLOAT, 40, 20)
                rapi.rpgBindUV1BufferOfs(VertexBuffer, noesis.RPGEODATA_FLOAT, 40, 32)
            elif vertex_stride == 44:
                rapi.rpgBindPositionBufferOfs(VertexBuffer, noesis.RPGEODATA_FLOAT, 44, 0)
                rapi.rpgBindNormalBufferOfs(VertexBuffer, noesis.RPGEODATA_FLOAT, 44, 24) 
                rapi.rpgBindUV1BufferOfs(VertexBuffer, noesis.RPGEODATA_FLOAT, 44, 36)
            elif vertex_stride == 56:
                rapi.rpgBindPositionBufferOfs(VertexBuffer, noesis.RPGEODATA_FLOAT, 56, 0)
                rapi.rpgBindNormalBufferOfs(VertexBuffer, noesis.RPGEODATA_FLOAT, 56, 12)
                rapi.rpgBindUV1BufferOfs(VertexBuffer, noesis.RPGEODATA_FLOAT, 56, 24)
            elif vertex_stride == 60:
                rapi.rpgBindPositionBufferOfs(VertexBuffer, noesis.RPGEODATA_FLOAT, 60, 0)
                rapi.rpgBindNormalBufferOfs(VertexBuffer, noesis.RPGEODATA_FLOAT, 60, 16)
                rapi.rpgBindUV1BufferOfs(VertexBuffer, noesis.RPGEODATA_FLOAT, 60, 28)
            elif vertex_stride == 64:
                rapi.rpgBindPositionBufferOfs(VertexBuffer, noesis.RPGEODATA_FLOAT, 64, 0)
                rapi.rpgBindNormalBufferOfs(VertexBuffer, noesis.RPGEODATA_FLOAT, 64, 20)
                rapi.rpgBindUV1BufferOfs(VertexBuffer, noesis.RPGEODATA_FLOAT, 64, 32)
            elif vertex_stride == 68:
                rapi.rpgBindPositionBufferOfs(VertexBuffer, noesis.RPGEODATA_FLOAT, 68, 0)
                rapi.rpgBindNormalBufferOfs(VertexBuffer, noesis.RPGEODATA_FLOAT, 68, 24)
                rapi.rpgBindUV1BufferOfs(VertexBuffer, noesis.RPGEODATA_FLOAT, 68, 36)
            else:
                print("This mesh not yet supported")
            FaceBuffer = bs.readBytes(face_count * 2)
            rapi.rpgCommitTriangles(FaceBuffer, noesis.RPGEODATA_USHORT, face_count, noesis.RPGEO_TRIANGLE, 1)
            jumpTo = sectionSize - (bs.tell() - startsectionSize)                 
            bs.seek(jumpTo, NOESEEK_REL)
            unk = bs.readUByte()
            bs.seek(unk + 0x1d, NOESEEK_REL)
        bs.seek(-0x20, NOESEEK_REL)
    mdl = rapi.rpgConstructModel()
    mdlList.append(mdl)
    rapi.rpgClearBufferBinds()
    return 1