﻿#Dark Souls III .TPF [PC] - ".TPF" Loader
#v1.0

from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Dark Souls III 2D Texture [PC]", ".tpf")
	noesis.setHandlerTypeCheck(handle, tpfCheckType)
	noesis.setHandlerLoadRGBA(handle, tpfLoadDDS)
	noesis.logPopup()
	return 1
		
def tpfCheckType(data):
	bs = NoeBitStream(data)
	fileMagic = bs.readUInt()
	if fileMagic == 0x465054:
		return 1
	else: 
		print("Fatal Error: Unknown file magic: " + str(hex(fileMagic) + " expected 0x465054!"))
		return 0

def tpfLoadDDS(data, texList):
	bs = NoeBitStream(data)
	
	fileMagic = bs.readUInt()
	fileUnk00  = bs.readUShort()
	fileUnk01  = bs.readUShort()
	numTextures  = bs.readUInt()
	fileUnk02  = bs.readUByte()
	fileUnk03  = bs.readUByte()
	fileUnk04  = bs.readUByte()
	fileUnk05  = bs.readUByte()
	
	for i in range (numTextures):
		bs.seek(0x10 + i * 0x14, NOESEEK_ABS)#Entry start
		ddsOffset = bs.readUInt()
		ddsSize2 = bs.readUInt() 
		ddsWidth = bs.readUShort()
		ddsHeight = bs.readUShort()
		ddsNameOffset = bs.readUInt()
		bs.seek(ddsNameOffset, NOESEEK_ABS)
		ddsName = bs.readString()
		bs.seek((ddsOffset+0xC), NOESEEK_ABS)
		ddsHeight =  bs.readUInt()
		ddsWidth =  bs.readUInt()
		bs.seek((ddsOffset+0x54), NOESEEK_ABS)
		dxtType = bs.readString()
		#DXT1
		if dxtType == "DXT1":
		    bs.seek((ddsOffset+0x80), NOESEEK_ABS)
		    ddsSize = ddsSize2 - 0x80   
		#DXT5
		elif dxtType == "DXT5":
		    bs.seek((ddsOffset+0x80), NOESEEK_ABS)
		    ddsSize = ddsSize2 - 0x80 
		#ATI1
		elif dxtType == "ATI1":
		    bs.seek((ddsOffset+0x80), NOESEEK_ABS)
		    ddsSize = ddsSize2 - 0x80  
		#ATI2
		elif dxtType == "ATI2":
		    bs.seek((ddsOffset+0x80), NOESEEK_ABS)
		    ddsSize = ddsSize2 - 0x80  
		#DX10
		elif dxtType == "DX10":
		    bs.seek((ddsOffset+0x80), NOESEEK_ABS)
		    ddsType = bs.readUInt()
		    bs.seek((ddsOffset+0x94), NOESEEK_ABS) 
		    ddsSize = ddsSize2 - 0x94
		ddsData = bs.readBytes(ddsSize)	 
		#DXT1
		if dxtType == "DXT1":
		    ddsFmt = noesis.NOESISTEX_DXT1
		#DXT5
		elif dxtType == "DXT5":
		    ddsFmt = noesis.NOESISTEX_DXT5
		#ATI1
		elif dxtType == "ATI1":
		    ddsData = rapi.imageDecodeDXT(ddsData, ddsWidth, ddsHeight, noesis.FOURCC_ATI1)
		    ddsFmt = noesis.NOESISTEX_RGBA32	
		#ATI2
		elif dxtType == "ATI2":
		    ddsData = rapi.imageDecodeDXT(ddsData, ddsWidth, ddsHeight, noesis.FOURCC_ATI2)
		    ddsFmt = noesis.NOESISTEX_RGBA32	
		#DXT1
		elif ddsType == 72:
		    ddsFmt = noesis.NOESISTEX_DXT1
		#DXT1
		elif ddsType == 78:
		    ddsFmt = noesis.NOESISTEX_DXT5
		#DXT5
		elif ddsType == 99:
		    ddsData = rapi.imageDecodeDXT(ddsData, ddsWidth, ddsHeight, noesis.FOURCC_BC7)
		    ddsFmt = noesis.NOESISTEX_RGBA32
		#DX10
		elif ddsType == 98:
		    ddsData = rapi.imageDecodeDXT(ddsData, ddsWidth, ddsHeight, noesis.FOURCC_BC7)
		    ddsFmt = noesis.NOESISTEX_RGBA32	
		#print (ddsType)   
		#print (dxtType)      
		texList.append(NoeTexture(ddsName, ddsWidth, ddsHeight, ddsData, ddsFmt))
	return 1
	