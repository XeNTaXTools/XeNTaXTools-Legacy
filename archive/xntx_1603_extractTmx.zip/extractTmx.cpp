//original code by PersonaRipper @ Xentax forums
//modified by bbrcher @ Xentax forums (May 8th, 2010)

#include <iostream>
using namespace std;
#include <fstream>
//#include <cstdlib>

int unnamedFileCounter = 0;
int globalFilePos = 0;

// Returns true if file name is found.
bool setFilePointerToTMX(ifstream &fin)
{
	//not the best method, but usable
	if( !fin.eof() )
		if( fin.get() == 'T' )
			if( fin.get() == 'M' )
				if( fin.get() == 'X' )
					if( fin.get() == '0' )
						return true;
	return false;
}

//bmp header struct

//if you don't support this, find some way to make sure there is no padding
#pragma pack(push)
#pragma pack(1)

struct bmpheader //includes magic, header and dib
{
	//magic
	char magicB;// = "BM"; // "BM" for windows
	char magicM;// = "BM"; // "BM" for windows
	//header
	int fileSize;// = 0;
	short spacer1;// = 0; //actually 2 shorts, both 0
	short spacer2;// = 0; //actually 2 shorts, both 0
	int bmpOffset;// = 0x36; //we'll use the min header
	//dib
	int dibSize;// = 40;
	int width;// = 0;
	int height;// = 0;
	short planes;// = 1; //always 1
	short bpp;// = 24; //we'll stick to 24
	int comp;// = 0; //not compressed
	int imageSize;// = 0;
	int hoz;// = 0;
	int vert;// = 0;
	int numColors;// = 0; //0 == 2^n
	int impColors;// = 0; //0 == all colors are important 
};

struct tmxheader
{
	int      startUnknown;   //0x02000000
	int      tmxSize;        //size of file including this header
	char    magicTag[4];       // "TMX0"
	int      unknown1;        //padding 0
	short      unknown2;        //non zero, may be different version value
	short      tmxWidth;
	short      tmxHeight;
	int      tmxFlags;       //so far only discerned 2 formats
	short      tmxEnd;         //0x00FF 
	char   reserved[32];       //nulls can have the file name in it
};

struct color
{
	unsigned char r;
	unsigned char g;
	unsigned char b;
	unsigned char a;
};

#pragma pack(pop)

//conversion func
void convertTMXtoBMP( ifstream &fin, char* name )
{
	if( fin.eof() )
		return;
	
	//start at the begining
	fin.seekg( 0, ios_base::beg );
	tmxheader theader;
	fin.read( (char*)(&theader), sizeof(theader) );

	//get palette info
	int palSize = 256;
	if( theader.tmxFlags == 0x14 )
		palSize = 16;

	//palette is always at 0x40
	color* palette = new color[palSize];
	fin.seekg( 0x40 );
	fin.read( (char*)palette, sizeof(color)*palSize );

	//tile the palette if 256 colors
	if( palSize == 256 )
	{
		color* tpal = new color[palSize];
		memcpy(tpal, palette, palSize * sizeof(color) );

		int i = 0;
		int j = 0;
		int idx = 0;
		int idxt = 0;
		
		for( i = 0; i < 8; i++ )
		{
			for( j = 0; j < 8; j++ )
				palette[idx++] = tpal[idxt++];
			idxt += 8;
			for( j = 0; j < 8; j++ )
				palette[idx++] = tpal[idxt++];
			idxt -= 16;
			for( j = 0; j < 8; j++ )
				palette[idx++] = tpal[idxt++];
			idxt += 8;
			for( j = 0; j < 8; j++ )
				palette[idx++] = tpal[idxt++];
		}
		
		delete[] tpal;
	}

	//silly scaling of alpha
	int i = 0;
	int alpha = 0;
	for( i = 0; i < palSize; i++ )
	{
		alpha = (int)(255.0f * ((float)(palette[i].a) / 128.0f));
		palette[i].a = alpha > 255 ? 255 : alpha;
	}

	//data placement is dependant on palette type
	int dataSize = theader.tmxWidth * theader.tmxHeight / (palSize == 16 ? 2 : 1);
	char* data = new char[ dataSize ];
	fin.seekg( palSize == 16 ? 0x80 : 0x440 );
	fin.read( (char*)data, dataSize );

	//what's our new filename called?
	char bmpfile[26];

	memcpy(bmpfile, name, 26);

	i = 0;
	while( bmpfile[i] != '.' && i < 22 )
		i++;

	if( i < 22 )
	{
		bmpfile[i++] = '.';
		bmpfile[i++] = 'B';
		bmpfile[i++] = 'M';
		bmpfile[i++] = 'P';
	}

	//let's make a BMP!
	ofstream fout(bmpfile, ofstream::binary);

	//header stuff
	bmpheader bheader;
	//magic
	bheader.magicB = 'B';
	bheader.magicM = 'M';
	//header
	bheader.fileSize = 0x36 + 4 * theader.tmxWidth * theader.tmxHeight;
	bheader.spacer1 = 0; //actually 2 shorts, both 0
	bheader.spacer2 = 0; //actually 2 shorts, both 0
	bheader.bmpOffset = 0x36; //we'll use the min header
	//dib
	bheader.dibSize = 40;
	bheader.width = theader.tmxWidth;
	bheader.height = theader.tmxHeight;
	bheader.planes = 1; //always 1
	bheader.bpp = 32; //we'll stick to 32 for alpha stuff
	bheader.comp = 0; //not compressed
	bheader.imageSize = 4 * theader.tmxWidth * theader.tmxHeight;
	bheader.hoz = 0;
	bheader.vert = 0;
	bheader.numColors = 0; //0 == 2^n
	bheader.impColors = 0; //0 == all colors are important 

	//write the header
	fout.write( (char*)&bheader, sizeof(bheader) );

	//write the data, left bottom corner to top right for some reason
	int j = 0;
	int k = theader.tmxHeight-1;

	int idx = 0;
	int outd = 0;

	int dataWidth = theader.tmxWidth / (palSize == 16 ? 2 : 1);
	while( k >= 0 )
	{
		j = 0;
		while( j < dataWidth )
		{
			idx = k * dataWidth + j;

			if( palSize == 16 )
			{
				outd = (data[idx] & 0x0F);
				fout.put(palette[outd].b);
				fout.put(palette[outd].g);
				fout.put(palette[outd].r);
				fout.put(palette[outd].a);

				outd = (data[idx] & 0xF0) >> 4;
				fout.put(palette[outd].b);
				fout.put(palette[outd].g);
				fout.put(palette[outd].r);
				fout.put(palette[outd].a);
			}
			else
			{
				outd = (unsigned char)data[idx];
				fout.put(palette[outd].b);
				fout.put(palette[outd].g);
				fout.put(palette[outd].r);
				fout.put(palette[outd].a);
			}

			j++;
		}
		k--;
	}
	
	//close
	fout.close();

	//clean up
	delete[] palette;
	delete[] data;
}

bool extractFile(ifstream &fin)
{

	if( fin.eof() )
		return false;

	//finds a TMX0 string
	while( !setFilePointerToTMX(fin) )
	{
		if( fin.eof() )
			return false;
	}

	if( fin.eof() )
		return false;

	//return to front of TMX file
	fin.seekg( -12, ios_base::cur );

	long size = 0;
	char size_byte[4];
	long start = (int)fin.tellg();

	//go to file size
	fin.seekg( 4, ios_base::cur );
	
	fin.read( size_byte, 4 );
	
	size = (unsigned char)size_byte[3];
	size = (size << 8) + (unsigned char)size_byte[2];
	size = (size << 8) + (unsigned char)size_byte[1];
	size = (size << 8) + (unsigned char)size_byte[0];

	//something is up, don't quit out
	if( size <= 0 )
		return false;

	long end = start + size;

	//go to file name if there is one
	char name[26];
	fin.seekg( start + 38, ios_base::beg );
	
	//length + null terminator
	fin.get(name, 26+1);
	if( fin.eof() )
		return false;

	//give us a name if we didn't find one
	if(name[0] == 0x00)
		sprintf(name,"Unknown%i",unnamedFileCounter++);

	//add the .TMX extension
	int i = 0;
	while( name[i] != 0 && i < 22 )
		i++;

	if( i < 22 )
	{
		name[i++] = '.';
		name[i++] = 'T';
		name[i++] = 'M';
		name[i] = 'X';
	}
	
	cout << "\tExtracting: " << name << "\t@ " << start << " [" << end << "]" << endl;
	cout << "\tFilesize: " << size << endl;
	ofstream fout(name, ofstream::binary);

	int count = 0;
	fin.seekg( start, ios_base::beg );
	while( !fin.eof() && size > 0 && count < size )
	{
		fout.put(fin.get());
		count++;
	}

	//finish up the TMX file
	fout.close();

	//k, lets convert it to a 32b bmp
	ifstream finTMX( name, ios_base::binary );

	convertTMXtoBMP( finTMX, name );

	finTMX.close();
	return true;
}

// Takes in a file name(s) on the command line,
int main(int argc, char* args[])
{
	int filesExtracted = 0;
	for(int i = 0; i < argc-1; i++)
	{
		cout << "Extracting files from " << args[i+1] << endl;

		ifstream fin(args[i+1], ifstream::binary);

		while(extractFile(fin))
			filesExtracted++;

		fin.close();
	}
	cout << filesExtracted << " files extracted from " << argc - 1 << " files.\n";
	return 0;
}