
Before compiling this project with CodeBlocks 13.12 for example
try out Make_obj.exe in \Make_obj\bin\Release 
with CITY_PARAMEDIC-dbd91b3e.36 (sadly I don't have this sample any more)

(This will create Makeobj_log.obj)

Or change the source to convert other .36 to .obj

have fun,
shak-otay

provided as is - the author can't be made responsible for any problems 
that might arise using the code and/or the exe
