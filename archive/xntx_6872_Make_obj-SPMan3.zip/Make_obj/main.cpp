/*
#################################################################
# DISCLAIMER This is an excerpt from my Make_H2O project. (RIP)
#
# It is provided as is. It's self-written, except the __inline,
# the bubblesort-function and the MinGW_gcc_dll.
#
# So this is MY code, but you can do with it whatever you want.
#
# If you don't like my coding style then don't use it or write
# your own code.
# I'm writing code to solve problems not to be sophisticated.
# So the more complaints the more of my ugly code will be hidden
# in the DLL_MakeH2O.dll.
#
# Use it on your own risk. I won't overtake any responsibilities.
#################################################################
*/

#include <windows.h>

#include <stdio.h>		// FILE
#include <math.h>		//
#include "Main.h"

static char g_szClassName[] = "MyWindowClass";
static HINSTANCE g_hInst = NULL;

#define IDC_MAIN_TEXT   1001
#define bool BOOL
#define false FALSE
#define true TRUE
#define ID_LIST     1
#define ID_EDIT     2
#define ID_BUTTON1  3
#define ID_COMBO1   4

//typedef unsigned long   DWORD; // no effect
// replaced %x by %lu

#define FILENAME  TEXT("Makeobj_log.obj")

#define chDIMOF(Array) (sizeof(Array) / sizeof(Array[0]))
__inline void chMB(PCSTR s) {
   char szTMP[128];
   GetModuleFileNameA(NULL, szTMP, chDIMOF(szTMP));
   MessageBoxA(GetActiveWindow(), s, szTMP, MB_OK);
}

BYTE model = 2 ;    // 1: SW_BF3
                    // 2: SPMan3

char szErrMess[1024]= "error in H20 no: " ;    // about 20 MB static file buffer for model files
char szFileNameG[MAX_PATH];
BYTE SM_cntArr[10] ;
DWORD dwFileSize, dwStart, lastJ ;
FILE *stream ;          // for logfile (unused so far)
LPVOID lpFBuf ;         // pointer to file buffer
bool bFstRun= true ;    // KinectSW
bool bDbg= true ;       // debug on

void bubblesort(int* &array, int* &array2, int length)   // array-Werte als call-by-value, oder doch by ref? (mit &)
 {
    int i, j;
    for (i = 0; i < length - 1; ++i)

        for (j = 0; j < length - i - 1; ++j) {
            if (array[j] > array[j + 1]) {
                int tmp = array[j]; array[j] = array[j + 1]; array[j + 1] = tmp;
                tmp = array2[j]; array2[j] = array2[j + 1]; array2[j + 1] = tmp;
            }
        }
 }

void Show_nFloats(FILE *stream, char* &pFBuf, DWORD &j, BYTE cnt, bool bBigE)
{
    char tmp[4] ;
    BYTE i, l ;
    float *pFloat ;
	float fData = 0.0f;

	pFloat= &fData ;

    if (bBigE)
        for (i=0;i<cnt;i++) {
            for (l=0;l<4;l++) tmp[3-l]= *(pFBuf+l) ;
            pFloat = (float*) tmp ;
			fprintf( stream, "%f ", *pFloat) ; pFBuf += 4 ; j+= 4 ;
		}
	else
        for (i=0;i<cnt;i++) {
			pFloat = (float*) pFBuf ;
			fprintf( stream, "%f ", *pFloat) ; pFBuf += 4 ; j+= 4 ;
		}
    fprintf( stream, "\n") ;
}

void ShowDWord(FILE *stream, char* &pFBuf, DWORD &j)
{
	BYTE i ;
	int nValue[4] ;

	for (i=0;i<4;i++) {									// 1x DW
		nValue[i] = (*pFBuf & 255) ; pFBuf++ ; j++ ;
		if (nValue[i]<16) fprintf( stream, "0") ;
		fprintf( stream, "%X ", nValue[i]) ;
	}
}

char * ShowString(FILE *stream, char* &pFBuf, DWORD &j, DWORD &dwStart)
{
	char szName[256] ;
	BYTE * pByte ;
	BYTE i ;
	DWORD dwCnt1 ;

	pByte = (BYTE*) &dwCnt1 ;							// DW-cnter Stringl�nge
	for (i=0;i<4;i++) {									//
		*pByte = *pFBuf &255 ; pByte++; pFBuf++; j++ ;
	}
	if (dwCnt1>255) { dwCnt1 = 0 ; fprintf( stream, "(strLen) ABBRUCH bei %7x\n\n", j+dwStart); }
	dwStart+= dwCnt1 + 4 ;
	for (i=0;i<dwCnt1;i++) {							// String f�llen
		szName[i]= *pFBuf ; pFBuf++; j++ ;
	}
	szName[i]= '\0' ;									// Bone name
	return szName ;             // return local address, nicht gut?
	//fprintf( stream, "%s ", szName) ;
}

char * ShowFName(FILE *stream, char* &pFBuf, DWORD &j, BYTE cnt, DWORD &dwStart)
{
	char szName[256] ;
	//BYTE * pByte ;
	BYTE i ;

	if (cnt>255) { cnt = 0 ; fprintf( stream, "(strLen) ABBRUCH bei %7x\n\n", j+dwStart); }
	dwStart+= cnt ;
	for (i=0;i<cnt;i++) {							// String f�llen
		szName[i]= *pFBuf ; pFBuf++; j++ ;
	}
	szName[i]= '\0' ;									// Bone name
	return szName ;             // return local address, nicht gut?
	//fprintf( stream, "%s ", szName) ;
}

WORD GetFaceIndexWord(char* &pFBuf, DWORD &j, DWORD &minFaceInd, DWORD &maxFaceInd, DWORD lastFaceInd, bool bBigE)		//
{																// lastFaceInd: start face index f�r n�chstes Submesh
	//char * pTmp ;
	BYTE i ;
	int nValue[3] ;
	WORD wFaceInd ;

	//pTmp= pFBuf ;
	for (i=0;i<2;i++) {
		nValue[i] = (*pFBuf & 255) ; pFBuf++ ; j++ ;			// 2 Byte-Index
	}
	if (bBigE)
        wFaceInd = (WORD) (nValue[1]+nValue[0]*256) + lastFaceInd ;
    else wFaceInd = (WORD) (nValue[0]+nValue[1]*256) + lastFaceInd ;
	// genome face-no +1 f�r Wandlung to Wavefront-obj
	wFaceInd++ ;
	if (wFaceInd<minFaceInd) minFaceInd = wFaceInd ;
	if (wFaceInd>maxFaceInd) maxFaceInd = wFaceInd ;
	return wFaceInd ;
}

DWORD GetFaceIndex(char* &pFBuf, DWORD &j, DWORD &minFaceInd, DWORD &maxFaceInd, DWORD lastFaceInd, bool bDW)		//
{																// lastFaceInd: start face index f�r n�chstes Submesh
	char * pTmp ;
	BYTE i ;
	int nValue[3] ;
	DWORD dwFaceInd ;

	pTmp= pFBuf ;   // helper var for GDB
	for (i=0;i<2;i++) { // supa, wie soll'n das 'n DWORD Wert werden?
		nValue[i] = (*pFBuf & 255) ; pFBuf++ ; j++ ;			// 2 Byte-Index
	}
	dwFaceInd = (WORD) (nValue[0]+nValue[1]*256) + lastFaceInd ;				//
	if (bDW) { nValue[2] = (*pFBuf & 255) ; pFBuf+=2 ; j+=2 ;
        dwFaceInd += (DWORD) nValue[2]*65536 ;
	}
	// genome face-no +1 f�r Wandlung to Wavefront-obj
	dwFaceInd++ ;
	if (dwFaceInd<minFaceInd) minFaceInd = dwFaceInd ;
	if (dwFaceInd>maxFaceInd) maxFaceInd = dwFaceInd ;
	return dwFaceInd ;
}

DWORD GetFaceIndexBigE(char* &pFBuf, DWORD &j, DWORD &minFaceInd, DWORD &maxFaceInd, DWORD lastFaceInd, bool bDW)		//
{																// lastFaceInd: start face index f�r n�chstes Submesh
	char * pTmp ;
	BYTE i ;
	int nValue[3] ;
	DWORD dwFaceInd ;

	pTmp= pFBuf ;                                               // helper var for GDB
	for (i=0;i<2;i++) {             //
		nValue[i] = (*pFBuf & 255) ; pFBuf++ ; j++ ;			// 2 Byte-Index
	}
        //fprintf( stream, "(%d) ", (WORD) (nValue[0]*256) ) ;        // this works
	dwFaceInd =  (WORD) (nValue[0]*256)+ nValue[1] + lastFaceInd ;// big endian
	// genome face-no +1 f�r Wandlung to Wavefront-obj
	dwFaceInd++ ;
	if (dwFaceInd<minFaceInd) minFaceInd = dwFaceInd ;
	if (dwFaceInd>maxFaceInd) maxFaceInd = dwFaceInd ;
	return dwFaceInd ;
}

bool show_table(DWORD dwStart)			// crappy code, I know, but: works
{					//
	char * pFBuf ;			//
	BYTE i ;
	int cnt=0, l, nValue[8] ;			//
	DWORD j ;		//

	pFBuf = (char *) lpFBuf ;           // start of file buffer
	pFBuf += dwStart ; j= 0 ; l= 0 ;
    fprintf( stream, "%s\n\n0x%x:\n", szFileNameG, dwStart) ;
	for (l=0;l<100;l++) {				// 100 entries a 8 DWORDs
		for (cnt=0;cnt<8;cnt++) {
			for (i=0;i<4;i++) {									// 1x DWord
				nValue[i] = (*pFBuf & 255) ; pFBuf++ ; j++ ;
			}
			if (nValue[2]!=0) fprintf( stream, "    x") ;
			else fprintf( stream, "%5d", nValue[0] + nValue[1]*256) ;       // little endian
			fprintf( stream, " ") ;
		}
		fprintf( stream, "\n") ;
	}
	fprintf( stream, "0x%x\n", dwStart+j) ;
	return true ;
}

void log_WordsBE(DWORD dwStart)			//
{					//
	char * pFBuf ;			//
	BYTE i ;
	int cnt=0, nValue[2] ;			//
	WORD w ;
	DWORD j ;		//

	pFBuf = (char *) lpFBuf ;           // start of file buffer
	pFBuf += dwStart ; j= 0 ;
    for (cnt=0;cnt<46;cnt++) {
        for (i=0;i<2;i++) {									// 1x DWord
			nValue[i] = (*pFBuf & 255) ; pFBuf++ ; j++ ;
		}
		w= nValue[0]*256 + nValue[1] ;       // big endian
		if (w!=0) fprintf( stream, "%5d ", w) ; else fprintf( stream, "0 ") ;
    }
    fprintf( stream, "\n") ;
}

bool log_MBG(void)			// crappy code, I know, but: works
{					//
	char * pFBuf ;			//
	BYTE fCnt=0 ;
	int cnt=1, FIcnt, i, l=0 ;			// , nValue[8]
	WORD FI ;
	DWORD j, dwStart= 0x395, lastFaceInd=0, minFaceInd= 0xFFFF, maxFaceInd=0 ;		//
	bool bStop= false ;

	pFBuf = (char *) lpFBuf ;           // start of file buffer
	dwStart= 0x138D ;
	pFBuf += dwStart ; j= 0 ;
    fprintf( stream, "# %s\n\n0x%x:\n", szFileNameG, dwStart) ;
	//for (l=0;l<6731;l++) {				// a 76 bytes (12, 2x8, 3x12 +4x5)  sind aber nicht immer 76 pro l
	while ((l<15000)&&!bStop) {
        if (*pFBuf==1) {
            pFBuf += 4 ; j += 4 ;       // skip 01 000000
            switch (cnt) {
                case 1: fprintf( stream, "v ") ; break ;
                case 2: fprintf( stream, "vt ") ; break ;
                default: fprintf( stream, "# ") ;
            }
            if (cnt<6) cnt++ ; else cnt= 1 ;
            if (*pFBuf==8) {
                pFBuf++ ; j ++ ; Show_nFloats(stream, pFBuf, j, 2, true) ;
            }
            else if (*pFBuf==12) {
                pFBuf++ ; j ++ ; Show_nFloats(stream, pFBuf, j, 3, true) ;
            }
            else {          // == 4?
                pFBuf++ ; j ++ ; ShowDWord(stream, pFBuf, j) ;
            }
            if (cnt==6) fprintf( stream, "# %d 0x%x\n", l, dwStart+j) ;
        }
        else if (*pFBuf==3) {  // idx
            pFBuf += 3 ; j += 3 ; // size des idx blocks folgt (als Word gelesen statt DWord)
            FIcnt= GetFaceIndexWord(pFBuf, j, minFaceInd, maxFaceInd, lastFaceInd, true) ; FIcnt-- ;
            fprintf( stream, "\n") ;
            for (i=0;i<FIcnt/2;i++) {       // weil, FIcnt ist die size
                FI= GetFaceIndexWord(pFBuf, j, minFaceInd, maxFaceInd, lastFaceInd, false) ; // littleE
                if (fCnt==0) fprintf( stream, "f ") ;
                fprintf( stream, "%d ", FI) ; fCnt++ ;
                if (fCnt==3) { fCnt=0 ; fprintf( stream, "\n") ; }
            }
            fprintf( stream, "\n") ; bStop= true ;
        }
        else if (*pFBuf==7) {
            ShowDWord(stream, pFBuf, j) ;
        }
        l++ ;
	}
	fprintf( stream, "# 0x%x\n", dwStart+j) ;
	return true ;
}

void SM_of_unkn_loop(HWND hwnd, char szPathname[], DWORD dwStart)      // scanning the submeshes params in the MLX table
{
   //char * pFBuf ;
   //BYTE * pByte, cnt, i ;

   //DWORD deltaFI, deltaV, dwFaceIndCnt, dwFICntLast=0, dwVertsCnt, dwVCntLast=0, addrFI=0x124D0, addrV=0x1BC20, j ;

   chMB("WIP, not included, sry!\nMaybe released when working better/for more than one model.") ;
}

DWORD dataAlignment(DWORD j){
    int cnt ;

    cnt = j/16 ; cnt++ ;
    if ((j%16)!=0) { j = cnt*16 ; }
    return j ;
}
DWORD dataAlignment_4(DWORD j){
    int cnt ;

    cnt = j/4 ; cnt++ ;
    if ((j%4)!=0) { j = cnt*4 ; }
    return j ;
}

void GetDW(char * &pFBuf, DWORD &j, DWORD &dw, bool bBigE) {
    BYTE * pByte, i ;
    WORD wLo, wHi ;
    DWORD dwTmp ;

    pByte = (BYTE*) &dw ;    			        // get vertex count
    for (i=0;i<4;i++) {									//
        *pByte = *pFBuf &255 ; pByte++; pFBuf++; j++ ;
    }
    if (bBigE) {
        dwTmp = dw / 65536 ;        // low word
        wLo= dwTmp % 256 ; wHi= dwTmp / 256 ;           // little to big endian correction
        dwTmp= wLo * 256 + wHi ;
        dw %= 65536 ;               // hi word
        wLo= dw % 256 ; wHi= dw / 256 ;
        dw= (wLo * 256 + wHi)*65536 + dwTmp ;
    }
}
void GetWord(char * &pFBuf, DWORD &j, WORD &w, bool bBigE) {
    BYTE * pByte, i ;
    WORD wLo, wHi ;

    pByte = (BYTE*) &w ;
    for (i=0;i<2;i++) {
        *pByte = *pFBuf &255 ; pByte++; pFBuf++; j++ ;
    }
    if (bBigE) {
        wLo= w % 256 ; wHi= w / 256 ;           // little to big endian correction
        w= wLo * 256 + wHi ;
    }
}

// *** for MLX only!***
BYTE GetFirstSubMesh_vertexStart(char * pFBuf, DWORD &addrFI, DWORD dwFIrel, BYTE KFMG_cnt) {
   char * pTmp ;
   BYTE cnt= 1, retcnt ;
   DWORD dwFIprev[256], dwFaceIndCnt, dwFICntLast=0, dwVertsCnt, dwVCntLast=0 ;
   DWORD addrFIbac, deltaFI, deltaV, j=0 ;	// addrFIprev,
   bool bStop= false ;

    pTmp= pFBuf ; addrFIbac= addrFI ;
        //fprintf( stream, "  addr FI, FIrel vCnt\n") ;
    // first calculation while loop results in false addrFI! because of possible negative counts
    do {
        dwFIprev[cnt-1]= dwFIrel ;
        GetDW(pFBuf, j, dwFIrel, false) ;                   // only required for last FI addr
        GetDW(pFBuf, j, dwVertsCnt, false) ;
        bStop= (dwVertsCnt==0)||(dwVertsCnt>65535) ;
        deltaV= dwVertsCnt - dwVCntLast ; dwVertsCnt= deltaV ;
        GetDW(pFBuf, j, dwFaceIndCnt, false) ;              // absoulte FI count
        deltaFI= dwFaceIndCnt - dwFICntLast ; dwFaceIndCnt= deltaFI ;
        pFBuf += 5*4 ; j += 5*4 ;                           // next table SM entry for MLX tables only!
            //fprintf( stream, "%d 0x%x %d (%d), v%d\n", cnt-1, addrFI, dwFIprev[cnt-1], deltaFI, deltaV) ; // deltaV evtl. negativ!
        //addrFIprev= addrFI ;
        addrFI += deltaFI*2 ;
        dwVCntLast += deltaV ; dwFICntLast += deltaFI ;
        if (cnt<254) cnt++ ; else chMB("more than 256 submeshes per KFMG can't be handled") ;
   } while (!bStop && (j<dwFileSize)) ;
   if (bStop) fprintf( stream, " breaking count in table= %d\n\n", dwVertsCnt) ;
   else fprintf( stream, " EOF met on table scan\n\n") ;
   if (cnt!=SM_cntArr[KFMG_cnt]) {
       fprintf( stream, "\n SM_counts: %d!=%d \n", SM_cntArr[KFMG_cnt], cnt) ;
       cnt= SM_cntArr[KFMG_cnt] ;
   }
   retcnt= cnt ;

   pFBuf= pTmp +4 ;     // weil FIrel jetzt nicht gelesen
   dwFIrel=0; dwFICntLast=0; dwVCntLast=0 ;
   addrFI= addrFIbac ; j= 0 ;
   for (cnt=0;cnt<retcnt;cnt++) {             // -1 to avoid last fxxxing value/line
       GetDW(pFBuf, j, dwVertsCnt, false) ;
       deltaV= dwVertsCnt - dwVCntLast ; dwVertsCnt= deltaV ;
       GetDW(pFBuf, j, dwFaceIndCnt, false) ;              // absoulte FI count
       deltaFI= dwFaceIndCnt - dwFICntLast ;               // kann negativ sein!
       deltaFI= dwFIprev[cnt] ;                             // <- daher
       dwFaceIndCnt= deltaFI ;
       pFBuf += 6*4 ; j += 6*4 ;                           // next table SM entry for MLX tables only!
       //addrFIprev= addrFI ;
       addrFI += deltaFI*2 ; //fprintf( stream, " %d (%d->) addr FI= 0x%x\n", cnt, deltaFI, addrFI) ;
       dwVCntLast += deltaV ; dwFICntLast += deltaFI ;
   }
   fprintf( stream, "last addr FI= 0x%x\n", addrFI) ;
   return retcnt ;
}
BYTE GetFirstSubMesh_vertexStart_(char * pFBuf, DWORD &addrFI) {
   BYTE cnt= 1 ;
   DWORD dwFIrel=0, dwFIprev, dwFaceIndCnt, dwFICntLast=0, dwVertsCnt, dwVCntLast=0 ;
   DWORD addrFIprev, deltaFI, deltaV, j=0 ;
   bool bStop= false ;

        //fprintf( stream, "  addr FI\n") ;
    do {
        dwFIprev= dwFIrel ;
        GetDW(pFBuf, j, dwFIrel, false) ;                   // only required for last FI addr
        GetDW(pFBuf, j, dwVertsCnt, false) ;
        bStop= (dwVertsCnt==0)||(dwVertsCnt>65535) ;
        deltaV= dwVertsCnt - dwVCntLast ; dwVertsCnt= deltaV ;
        GetDW(pFBuf, j, dwFaceIndCnt, false) ;              // absoulte FI count
        deltaFI= dwFaceIndCnt - dwFICntLast ; dwFaceIndCnt= deltaFI ;
        pFBuf += 5*4 ; j += 5*4 ;                           // next table SM entry for MLX tables only!
            fprintf( stream, "%d 0x%x %d (%d), v%d\n", cnt-1, addrFI, dwFIprev, deltaFI, deltaV) ; // deltaV evtl. negativ!
        addrFIprev= addrFI ;
        addrFI += deltaFI*2 ;
        dwVCntLast += deltaV ; dwFICntLast += deltaFI ;
        cnt++ ;
   } while (!bStop && (j<dwFileSize)) ;
   addrFI = addrFIprev + dwFIprev*2 ; fprintf( stream, "last addr FI= 0x%x, cnt %d\n", addrFI, dwFIprev) ;
   if (bStop) fprintf( stream, " breaking count in table= %d\n\n", dwVertsCnt) ;
   else fprintf( stream, " EOF met on table scan\n\n") ;
   return cnt ;
}
//SetWindowText (hwndEdit, "F200");

void logUVs(DWORD addrUV, DWORD Vcnt, BYTE vStride)
{
    char *pFBuf ;
    BYTE i ;
    DWORD k ;
    float *pFloat ;
	float fData = 0.0f;

    pFloat= &fData ;
    pFBuf = (char *) lpFBuf ;
    pFBuf += addrUV ;
	for (k=0;k < Vcnt;k++) {
        fprintf( stream, "vt ") ;
        for (i=0;i<2;i++) {
            pFloat = (float*) pFBuf ; fprintf( stream, "%f ", *pFloat) ; pFBuf += 4 ;
        }
        fprintf( stream, "\n") ;
		pFBuf += vStride-8 ;
	}
}
void log_UVsBE(DWORD addrUV, DWORD Vcnt, BYTE vStride)
{
    char *pFBuf, pTmp[4] ;
    BYTE i, l ;
    DWORD k ;
    float *pFloatBE ;
	float fData = 0.0f;

    pFloatBE= &fData ;
    pFBuf = (char *) lpFBuf ;
    pFBuf += addrUV ;
	for (k=0;k < Vcnt;k++) {
        fprintf( stream, "vt ") ;
        for (i=0;i<2;i++) {
            for (l=0;l<4;l++) pTmp[3-l]= *(pFBuf+l) ;
            pFloatBE= (float*) pTmp ; fprintf( stream, "%f ", *pFloatBE) ; pFBuf += 4 ;
        }
        fprintf( stream, "\n") ;
		pFBuf += vStride-8 ;
	}
}
void log_short_UVs(DWORD addrUV, DWORD Vcnt, BYTE vStride)
{
    char *pFBuf ;
    BYTE i, l ;
    int nValue[2] ;
    DWORD k ;
    float lPosXYZ ;

    pFBuf = (char *) lpFBuf ;
    pFBuf += addrUV ;
	for (k=0;k < Vcnt;k++) {
        fprintf( stream, "vt ") ;
		for (l=0;l<2;l++) {
			for (i=0;i<2;i++) {									// 1x Word
				nValue[i] = (*pFBuf & 255) ; pFBuf++ ;
			}
            //lPosXYZ= nValue[0] + nValue[1]*256 ;
            lPosXYZ= nValue[0]*256 + nValue[1] ;            // big endian
            if (lPosXYZ>32767) lPosXYZ -= 65536;
			//fprintf( stream, "%f ", lPosXYZ/32768.0) ;
			fprintf( stream, "%f ", lPosXYZ/4096.0) ;        // was /256.0
		}
		fprintf( stream, "\n") ;
		pFBuf += vStride-4 ;
	}
}

void Vertex12(FILE *stream, DWORD dwStart, DWORD dwVertsCnt, BYTE vStride, bool bBigE)	//
{
	char *pFBuf, pTmp[4] ;
	int i, l ;			//, nValue[12]
	DWORD j, k ;
    float *pFloat, *pFloatBE ;
	float fData = 0.0f ;    // , XYZPos

	pFBuf = (char *) lpFBuf ;
	pFBuf += dwStart ;	j= dwStart ;

	pFloatBE= &fData ; pFloat= &fData ;
    if (bBigE)
    for (k=0;k < dwVertsCnt;k++) {
		fprintf( stream, "v ") ;
        for (i=0;i<3;i++) {
            for (l=0;l<4;l++) pTmp[3-l]= *(pFBuf+l) ;
            pFloatBE= (float*) pTmp ;
			fprintf( stream, "%f ", *pFloatBE) ; pFBuf += 4 ; j+= 4 ;
		}
		fprintf( stream, "\n") ;
		pFBuf += vStride-12 ; j += vStride-12 ;
	}
	else for (k=0;k < dwVertsCnt;k++) {
		fprintf( stream, "v ") ;
        for (i=0;i<3;i++) {
			pFloat = (float*) pFBuf ;
			fprintf( stream, "%f ", *pFloat) ; pFBuf += 4 ; j+= 4 ;
		}
		fprintf( stream, "\n") ;
	}
}

void log_Verts(DWORD addrV, DWORD Vcnt, BYTE vStride)   // floats
{
    char *pFBuf ;
    BYTE i ;
    DWORD k ;
    float *pFloat ;
	float fData = 0.0f;

    pFloat= &fData ;
    pFBuf = (char *) lpFBuf ;
    pFBuf += addrV ;
	for (k=0;k < Vcnt;k++) {
        fprintf( stream, "v ") ;
        for (i=0;i<3;i++) {
            pFloat = (float*) pFBuf ; fprintf( stream, "%f ", *pFloat) ; pFBuf += 4 ; // +5 f�r el Mat
        }
        fprintf( stream, "\n") ;
		pFBuf += vStride-12 ;   // -15 f�r el Mat
	}
}

void log_short_Verts(DWORD addrV, DWORD Vcnt, BYTE vStride) // warum hier stride not in code?
{
    char *pFBuf ;
    BYTE i, l ;
    int nValue[2] ;
    DWORD k ;
    float lPosXYZ ;

    pFBuf = (char *) lpFBuf ;
    pFBuf += addrV ;
	for (k=0;k < Vcnt;k++) {
        fprintf( stream, "v ") ;
		for (l=0;l<3;l++) {
			for (i=0;i<2;i++) {									// 1x Word
				nValue[i] = (*pFBuf & 255) ; pFBuf++ ;
			}
            //lPosXYZ= nValue[0] + nValue[1]*256 ;
            lPosXYZ= nValue[0]*256 + nValue[1] ;            // big endian
            if (lPosXYZ>32767) lPosXYZ -= 65536;
			fprintf( stream, "%f ", lPosXYZ/256.0) ;        // 32768.0?
		}
		fprintf( stream, "\n") ;
		pFBuf += vStride-6 ;
	}
}

void log_short_Verts_SpMan3(DWORD addrV, DWORD Vcnt, BYTE vStride) // warum hier stride not in code?
{
    char *pFBuf ;
    BYTE i, l ;
    int nValue[2] ;
    DWORD k ;
    float lPosXYZ ;

    pFBuf = (char *) lpFBuf ;
    pFBuf += addrV ;
	for (k=0;k < Vcnt;k++) {
        fprintf( stream, "v ") ;
		for (l=0;l<3;l++) {
			for (i=0;i<2;i++) {									// 1x Word
				nValue[i] = (*pFBuf & 255) ; pFBuf++ ;
			}
            //lPosXYZ= nValue[0] + nValue[1]*256 ;
            lPosXYZ= nValue[0] + nValue[1]*256 ;        // little endian
            if (lPosXYZ>32767) lPosXYZ -= 65536;
			fprintf( stream, "%f ", lPosXYZ/256.0) ;        // 32768.0?
		}
		fprintf( stream, "\nvt ") ;
		pFBuf += 2 ;                                        // skip 2 bytes
		for (l=0;l<2;l++) {
			for (i=0;i<2;i++) {									// 1x Word
				nValue[i] = (*pFBuf & 255) ; pFBuf++ ;
			}
            lPosXYZ= nValue[0] + nValue[1]*256 ;            // little endian
            if (lPosXYZ>32767) lPosXYZ -= 65536;
			//fprintf( stream, "%f ", lPosXYZ/32768.0) ;
			fprintf( stream, "%f ", lPosXYZ/1024.0) ;        // was /256.0, /4096.0
		}
		fprintf( stream, "\n") ;
		pFBuf += vStride-12 ;
	}
}

bool check4addFIGroup(char * &pFBuf, DWORD &j, DWORD &FIcnt, DWORD border)
{
    //int nValue[8] ;
    DWORD dumCnt, flag ;

    GetDW(pFBuf, j, flag, false) ;
    if (flag!=1) return false ;
    GetDW(pFBuf, j, flag, false) ;
    if (flag!=1) return false ;
    else {
            //fprintf(stream, "JuppH\n") ;
        pFBuf += 8 ; j += 8 ; // nextFIgroup = j;
        GetDW(pFBuf, j, dumCnt, false) ;
        pFBuf += 4 ; j += 4 ;                   // skip 00000000 zwischen evtl. counts
        GetDW(pFBuf, j, flag, false) ;
        if (flag==dumCnt) return false ;        // 2 counter f�r irgendwas, aber keine FIs hier
        pFBuf -= 8 ; j -= 8 ;           // wieda zur�ck, wenn's kein dumCnt war
        GetDW(pFBuf, j, dumCnt, false) ;      // vCnt als dummyCnt
            //fprintf(stream, "dumCnt: %d at %x\n", dumCnt, j-4) ; return false ;
        if (dumCnt>1024) return false ;
        pFBuf += dumCnt*2 ; j += dumCnt*2 ;
        GetDW(pFBuf, j, FIcnt, false) ;
        GetDW(pFBuf, j, dumCnt, false) ;
        if (FIcnt!=dumCnt) return false ;        // FICnt
        // zu kompliziert
/*        pFBuf -= 4 ; j -= 4 ;           // wieda zur�ck, wenn's kein dumCnt war
        nValue[0]= 1; nValue[1]= 0; nValue[2]= 0; nValue[3]= 0;    // assumed signature of FIs end
        nValue[4]= 1; nValue[5]= 0; nValue[6]= 0; nValue[7]= 0;
        offs2 = FindBytes(lpFBuf, j, dwFileSize-j, nValue, 8) ;
        if (offs2==0) {chMB("error: no 01000000 after addFIgroup"); return false ;}
        FIcnt= offs2/2 ;
        if (j+FIcnt*2>border) return false ;    // wohl doch keine FIs hier     */
            //fprintf(stream, "%d FIs at %x\n", FIcnt, j) ;
    }
    return true ;
}

void SM_of_DFF_loop(HWND hwnd, char szPathname[], DWORD dwStart)      // dummy function
{
   char * pFBuf, *pTmp, szNo[4] ;
   BYTE cnt ;
   int nValue[16] ;      // delta
   WORD wFaceIndCnt, wVertsCnt ;         //
   DWORD addrFI=0, addrUV, addrV, j=0, offs2 ;  // , lastJ
   DWORD FIaddr_arr[999], FIcnt, FIcnt_arr[999], vCnt, vCnt_arr[999] ;
   //float *pFloat ;
   //float fData = 0.0f;
   bool bStop= false ;

   pFBuf = (char *) lpFBuf ; pTmp= pFBuf ;
        // dwStart = 0x23BA5 ;                                        // unneeded here
   pFBuf += dwStart ;
   SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " creating obj:") ;
   cnt= 0 ; pTmp= pFBuf ;
   nValue[0]= 0x46; nValue[1]= 0x41; nValue[2]= 0x43; nValue[3]= 0x45; nValue[4]= 0;    // 'FACE '
   do {
        offs2 = FindBytes(lpFBuf, j, dwFileSize-j, nValue, 5) ;       // j is offset here
        if (offs2!=0) {
            pFBuf += offs2 ; j += offs2 ; fprintf( stream, "#") ;
            while (*pFBuf== 'F') {
                pFBuf += 16 ; j += 16 ;
                //GetDW(pFBuf, j, FIcnt, true) ; fprintf( stream, " %d", FIcnt) ;
                pFBuf += 4 ; j += 4 ;
            }
            fprintf( stream, "\n# ----------\n") ;
        }
        else { pFBuf += 6 ; j += 6 ; }
   } while ((offs2!=0)&&(j<dwFileSize)) ;

}

void SM_of_SpMan3_loop(HWND hwnd, char szPathname[], DWORD dwStart)      // dummy function
{
   char * pFBuf, *pTmp, szNo[4] ;
   BYTE cnt, fCnt=0, FVFsize, FVFsize_arr[999], SMcnt ;
   int faceDir= 1, nValue[16] ;      // delta
   WORD i, wFaceIndCnt, wVertsCnt ;         //
   DWORD addrFI=0, addrUV, addrV, j=0, k, offs2 ;  // , lastJ
   DWORD FIaddr_arr[999], FIcnt, FIcnt_arr[999], vCnt, vCnt_arr[999], FIsum=0, vSum=0 ;
   DWORD minFaceInd = 16777215, maxFaceInd = 0, lastFaceInd=0, f1,f2,f3 ;
   //float *pFloat ;
   //float fData = 0.0f;
   bool bStop= false ;

   pFBuf = (char *) lpFBuf ; pTmp= pFBuf ;
   pFBuf += dwStart ;
   SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " creating obj:") ;
       chMB("Works for CITY_PARAMEDIC-dbd91b3e.36 only atm!") ;
   cnt= 0 ;
   nValue[0]= 0x04; nValue[1]= 0; nValue[2]= 0; nValue[3]= 0; nValue[4]= 0;    // 04 00000000
   do {
        offs2 = FindBytes(lpFBuf, j, dwFileSize-j, nValue, 5) ;       // j is offset here
        if (offs2!=0) {
            pFBuf += offs2 ; j += offs2 ;
            if ((*(pFBuf+9)==2)&&(*(pFBuf+10)==0)&&(*(pFBuf+11)==0)&&(*(pFBuf+12)==0)) {
                pFBuf -= 11 ; j -= 11 ;             // addr of vertex count
                GetDW(pFBuf, j, vCnt, false) ; fprintf( stream, "# %d. %d", cnt, vCnt) ;     // pFBuf and j increased by 4
                vCnt_arr[cnt]= vCnt ;
                pFBuf += 12 ; j += 12 ;
                GetDW(pFBuf, j, FIcnt, false) ; fprintf( stream, " %d\n", FIcnt) ;
                FIcnt_arr[cnt]= FIcnt ;
                pFBuf += 4 ; j += 4 ;
                if (vCnt>4) {
                    if (cnt<998) cnt++ ; else chMB("Too many submeshes!") ;
                    vSum += vCnt ;  FIsum += FIcnt ;
                }
                //fprintf( stream, "\n# ----------\n") ;
            }
            else { pFBuf += 6 ; j += 6 ; }
        }
   } while ((offs2!=0)&&(j<dwFileSize)) ;
   SMcnt= cnt ; fprintf( stream, "# %d SMs, vSum= %d, FIsum= %d\n", cnt, vSum, FIsum) ;

   cnt= 0 ; pFBuf= pTmp; j= 0 ;
   nValue[0]= 0; nValue[1]= 0; nValue[2]= 1; nValue[3]= 0; nValue[4]= 02; nValue[5]= 0;    // 0000 0100 0200
   do {
        offs2 = FindBytes(lpFBuf, j, dwFileSize-j, nValue, 6) ;       // j is offset here
        if (offs2!=0) {
            pFBuf += offs2 ; j += offs2 ;
            if ((*(pFBuf+7)==0)&&(*(pFBuf+9)==0)&&(j>0x40000)) {        // +9 required for blacksuit
                FIaddr_arr[cnt]= j ; fprintf( stream, "# %d. %x\n", cnt, FIaddr_arr[cnt]) ;
                pFBuf += 18 ; j += 18 ;                 // skipping 3 faces at least
                if (cnt<998) cnt++ ; else chMB("Too many FI blocks!") ;
                //fprintf( stream, "\n# ----------\n") ;
            }
            else { pFBuf += 6 ; j += 6 ; }
        }
   } while ((offs2!=0)&&(j<dwFileSize)) ;

   // getting FVFsizes, 16 bytes before 07 000000 0000 0800
   cnt= 0 ; pFBuf= pTmp; j= 0 ;
   nValue[0]= 7; nValue[1]= 0; nValue[2]= 0; nValue[3]= 0; nValue[4]= 0; nValue[5]= 0;    //
   nValue[6]= 8; nValue[7]= 0;
   do {
        offs2 = FindBytes(lpFBuf, j, dwFileSize-j, nValue, 8) ;       // j is offset here
        if (offs2!=0) {
            pFBuf += offs2 ; j += offs2 ;
            FVFsize_arr[cnt]= *(pFBuf-16) ;
            if ((FVFsize_arr[cnt]>11)&&(FVFsize_arr[cnt]<65)) {
                if (cnt<998) cnt++ ; else chMB("Too many FI blocks!") ;
            }
            pFBuf += 8 ; j += 8 ;
        }
   } while ((offs2!=0)&&(j<dwFileSize)) ;
   if (cnt!=SMcnt) { chMB("Number of FVFsize finds doesn't match submesh count!") ;
        fprintf( stream, "# finds of FVFsize: %d\n", cnt) ;
   }

   for (cnt=0;cnt<SMcnt;cnt++) {
            //if (cnt==2) FVFsize= 52 ; else FVFsize= 48 ;     // very ugly! Must be replaced
       addrV= FIaddr_arr[cnt] - vCnt_arr[cnt] * FVFsize_arr[cnt] ;    fprintf( stream, "# addrV: %x\n", addrV) ;
       log_short_Verts_SpMan3(addrV, vCnt_arr[cnt], FVFsize_arr[cnt]) ;

       pFBuf= pTmp + FIaddr_arr[cnt] ; j= FIaddr_arr[cnt] ;             // set start of FIs
        _itoa(cnt, szNo, 10) ; fprintf( stream, "g SM_%s\n", szNo) ;      // separating the submeshes (building groups)
            //fprintf( stream, "# FIcnt: %d\n", FIcnt_arr[i]) ;
       k= 0 ; bStop= false ;
        f1= GetFaceIndex(pFBuf, dwStart, minFaceInd, maxFaceInd, lastFaceInd, false) ;
        f2= GetFaceIndex(pFBuf, dwStart, minFaceInd, maxFaceInd, lastFaceInd, false) ;
        f3= GetFaceIndex(pFBuf, dwStart, minFaceInd, maxFaceInd, lastFaceInd, false) ;
        //startFI = lastFaceInd ;
        do {
            if ( (f1 != f2)&&(f1 != f3)&&(f2 != f3) )  {		// if not identical fInd, create face
                //if ((f1>vCntSum)||(f2>vCntSum)||(f3>vCntSum)) fprintf( stream, "# ") ;
                //if (faceDir > 0) fprintf( stream, "f %d %d %d\n", f1, f2, f3) ;
                //else fprintf( stream, "f %d %d %d\n", f1, f3, f2) ;
                if (faceDir > 0) fprintf( stream, "f %d/%d %d/%d %d/%d\n", f1,f1, f2,f2, f3,f3) ;
                else fprintf( stream, "f %d/%d %d/%d %d/%d\n", f1,f1, f3,f3, f2,f2) ;
            }
            faceDir *= -1 ; // here is bessa
            f1 = f2 ;       // shift the verts
            f2 = f3 ;       //
            // wenn die gleich sind, muss erh�ht werden, aber nur, wenn kein single mesh object
            f3= GetFaceIndex(pFBuf, dwStart, minFaceInd, maxFaceInd, lastFaceInd, false) ;
            if (f3>vCnt_arr[cnt]+lastFaceInd) {
                fprintf( stream, "error! FI > vCnt (%d >%d)\n", f3-lastFaceInd, vCnt_arr[cnt]) ;
                bStop= true ;
            }
            k++ ;
		} while ( (k < FIcnt_arr[cnt]-3)&&!bStop) ;
        //if (fCnt!=0)    // verhindern, dass falscher maxFaceInd berechnet wird
        if (maxFaceInd<lastFaceInd) {
            fprintf( stream, "error! maxFI %d < lastFI %d\n\n", maxFaceInd, lastFaceInd) ;
        }
        else lastFaceInd = maxFaceInd ;         // needed to "convert" relative to absolute face indices
            fprintf( stream, "# %d. maxFI %d,  lastFI %d\n\n", cnt, maxFaceInd, lastFaceInd) ;

    }
}

void SM_of_SW_BF3_loop(HWND hwnd, char szPathname[], DWORD dwStart)      // scanning the submeshes
{                                                                         // only one model tested
   char * pFBuf, *pTmp, szNo[4], szNo1[4] ;
   BYTE cnt, fCnt=0, i, SMcnt, FVFsize= 20 ;        // 24 for Han
   int k, l=0, nValue[16] ;
   WORD FI[3], grp_arr[512], grpCnt=0 ;             // cmpCnt=0,
   DWORD FIcnt, FIcnt_arr[999], indexF, vCnt, vCnt_arr[999] ;         //
   DWORD addrUV, addrUVtmp, addrV, j=0, offs2 ;     //  lastJ,
   DWORD minFaceInd = 16777215, maxFaceInd = 0, lastFaceInd=0 ;
   //float *pFloat ;
   //float fData = 0.0f;
   //bool bStop= false ;

   pFBuf = (char *) lpFBuf ; pTmp= pFBuf ;
   //dwStart = 0x23BA5 ;                                        // unneeded here
   pFBuf += dwStart ;
   SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " creating obj:") ;
/*   nValue[0]= 0x4B; nValue[1]= 0x5F; nValue[2]= 0x53; nValue[3]= 0x54; //  PAC K_ST N
   do {
        offs2 = FindBytes(lpFBuf, j, dwFileSize-j, nValue, 4) ;       // j is offset here
        if (offs2!=0) {
            pFBuf += offs2 - 51 ; j += offs2 - 51 ;
            GetDW(pFBuf, j, addrV, true) ; pFBuf += 16 ; j += 16 ;
            GetDW(pFBuf, j, addrUV, true) ; // j not used here
            fprintf( stream, "# v/uvaddr: 0x%x, 0x%x\n", addrV, addrUV) ;
            //if (cnt<999) cnt++ ; else chMB("Too many submeshes!") ;
            pFBuf += 28 ; j += 28 ;
        }
   } while ((offs2!=0)&&(j<dwFileSize)) ;   // keine neuen Adressen
   // 14th find: # v/uvaddr: 0xb2b40, 0xe3690
   */
   nValue[0]= 0x46; nValue[1]= 0x41; nValue[2]= 0x43; nValue[3]= 0x45; nValue[4]= 0;    // 'FACE '
   do {
        offs2 = FindBytes(lpFBuf, j, dwFileSize-j, nValue, 5) ;       // j is offset here
        if (offs2!=0) {
            pFBuf += offs2 ; j += offs2 ; fprintf( stream, "#") ;
            while (*pFBuf== 'F') {
                pFBuf += 16 ; j += 16 ;
                GetDW(pFBuf, j, indexF, true) ; fprintf( stream, " %d", indexF/4) ;
                grp_arr[grpCnt]= indexF/4 ; if (grpCnt<511) grpCnt++ ; else chMB("Too many groups!") ;
                pFBuf += 4 ; j += 4 ;
            }
            fprintf( stream, "\n# ----------\n") ;
            pFBuf += 6 ; j += 6 ;
        }
   } while ((offs2!=0)&&(j<dwFileSize)) ;

   cnt= 0 ; pFBuf= pTmp; j= 0 ;         //lastJ= 0 ;
   // get counts of submeshes
   nValue[0]= 0x45; nValue[1]= 0x5F; nValue[2]= 0x4F; nValue[3]= 0x50; // there's counts behind FAC E_OP A
   do {
        offs2 = FindBytes(lpFBuf, j, dwFileSize-j, nValue, 4) ;       // j is offset here
        if (offs2!=0) {
            pFBuf += offs2 - 47 ; j += offs2 - 47 ;
            GetDW(pFBuf, j, vCnt, true) ; GetDW(pFBuf, j, FIcnt, true) ; // j not used here
            vCnt_arr[cnt]= vCnt ; FIcnt_arr[cnt]= FIcnt ; fprintf( stream, "# %d %d\n", vCnt, FIcnt) ;
            if (cnt<999) cnt++ ; else chMB("Too many submeshes!") ;
            pFBuf += 40 ; j += 40 ;
        }
   } while ((offs2!=0)&&(j<dwFileSize)) ;
   if (bDbg) fprintf( stream, "# submesh count: %d \n", cnt) ;
    // get counts of last submesh                   // not needed any more because FACE_OPA gets all
/*   offs2 = FindBytes(lpFBuf, j, dwFileSize-j, nValue, 3) ;       // j is offset here
    if (offs2!=0) {
        pFBuf += offs2 + 4 ; j += offs2 + 4 ;
        GetDW(pFBuf, j, vCnt, true) ; GetDW(pFBuf, j, FIcnt, true) ; // j not used here
        vCnt_arr[cnt]= vCnt ; FIcnt_arr[cnt]= FIcnt ; fprintf( stream, "# %d %d\n", vCnt, FIcnt) ;
        pFBuf += 8 ; j += 8 ; cnt++ ;
    } else chMB("Error, last submesh not found!") ; */
    // where's the stzartaddresses for vertices and uvs?
   nValue[0]= 0x46; nValue[1]= 0x41; nValue[2]= 0x43; nValue[3]= 0x45; nValue[4]= 0;    // 'FACE '
   offs2 = FindBytes(lpFBuf, j, dwFileSize-j, nValue, 5) ;       // j is offset here
    if (offs2!=0) {
        pFBuf += offs2 ; j += offs2 ;                   //
        pFBuf += 8 ; j += 8 ;
    } else chMB("Error, 'FACE ' after last counts not found!") ;    // evtl. erste von 2 'FACE '
   nValue[0]= 0x50; nValue[1]= 0x4F; nValue[2]= 0x53; nValue[3]= 0;     // 'POS '
   offs2 = FindBytes(lpFBuf, j, dwFileSize-j, nValue, 4) ;       // j is offset here
    if (offs2!=0) {
        pFBuf += offs2 -32 ; j += offs2 - 32 ;                   //
        GetDW(pFBuf, j, addrV, true) ; pFBuf += 16 ; j += 16 ;
        GetDW(pFBuf, j, addrUV, true) ; fprintf( stream, "# %x %x\n", addrV, addrUV) ;
        pFBuf += 72 ; j += 72 ;
    } else chMB("Error, 'POS ' after 'FACE' not found!") ;
    if (j!=addrV) {
        chMB("address calculation went wrong! break...") ;
        if (bDbg) fprintf( stream, "# addr v, uv: 0x%x, 0x%x, curr. addr: 0x%x\n", addrV, addrUV, j) ;
        //return ;
    }
    SMcnt= cnt ; addrV= 0x3600 ;                                                        // set manually; j= 0x3568
    for (i=0;i < SMcnt;i++) {
        fprintf( stream, "# vAddr, cnt: %x, %d\n", addrV, vCnt_arr[i]) ;
        //log_Verts(addrV, vCnt_arr[i], FVFsize) ;
        if (addrV==0xb2b28) addrV= 0xb2b40 ;                                            // manual correction
        Vertex12( stream, addrV, vCnt_arr[i], FVFsize, true) ;
        addrV += FVFsize*vCnt_arr[i] ;
        if (i==0) {
            addrUVtmp= addrV +16 ; fprintf( stream, "# uvAddr: %x\n", addrV+16) ;       // +16 set manually
            log_short_UVs(addrUVtmp, vCnt_arr[i], 20) ; addrUVtmp += 4*vCnt_arr[i] ;     // 20 set manually
            addrV += FVFsize*vCnt_arr[i] ;
        }
        //log_short_Verts(addrV, vCnt_arr[i], FVFsize) ;
    }
    if (addrV!=addrUV) chMB("UV address calculation went wrong! break...") ; //return ;}
    // go for uvs, blocksize is 4
    //addrUV= 0xE3690 ;
    for (i=1;i < SMcnt;i++) {
        //log_short_UVs(addrUV, vCnt_arr[i], 4) ; addrUV += 4*vCnt_arr[i] ;
        fprintf( stream, "# uvAddr: %x\n", addrUV) ;
        log_UVsBE(addrUV, vCnt_arr[i], 16) ; addrUV += 16*vCnt_arr[i] ;     // 16 set manually
    }
    pFBuf= pTmp + addrUV + 40 ; j= addrUV + 40 ; fprintf( stream, "# start of FIs: %x\n", j) ;
    // go for face indices
    //0x10A640
    for (i=0;i < SMcnt;i++) {
        _itoa(i, szNo, 10) ; fprintf( stream, "g SM_%s\n", szNo) ;      // separating the submeshes (building groups)
            //fprintf( stream, "# FIcnt: %d\n", FIcnt_arr[i]) ;
        for (k=0;k<FIcnt_arr[i];k++) {       //

            if (j==0x11aeac) {
                pFBuf += 24 ; j += 24 ;
            }
            //               adding lastFaceInd inside fct. gor absolute FIs
            FI[fCnt]= (WORD) GetFaceIndexBigE(pFBuf, j, minFaceInd, maxFaceInd, lastFaceInd, false) ;	// j for count only!
            fCnt++ ;
            if (fCnt==3) {
                fCnt=0 ;
                        //fprintf( stream, "s %d. %d %d\n", i, (k+cmpCnt)/3, grp_arr[l]) ;
                    fprintf( stream, "  %d. %d %d\n", i, FI[0], grp_arr[l]) ;
                if (FI[0]>=grp_arr[l]) {          // (k+cmpCnt)/3>)
                    _itoa(l, szNo1, 10) ; fprintf( stream, "g SM_%s_%s\n", szNo, szNo1) ;
                    l++ ;
                }
                                      //
                //fprintf( stream, "f %d/%d %d/%d %d/%d\n", FI[0],FI[0],FI[1],FI[1],FI[2],FI[2]) ;
            }
        }
        if (maxFaceInd<lastFaceInd) {
            fprintf( stream, "# error! maxFI %d < lastFI %d\n\n", maxFaceInd, lastFaceInd) ;
        }
        else lastFaceInd = maxFaceInd ;         // needed to "convert" relative to absolute face indices
            fprintf( stream, "# %d. maxFI %d,  lastFI %d\n\n", i, maxFaceInd, lastFaceInd) ;
        fprintf( stream, "# next FI block: %x\n", j) ;
            //cmpCnt += FIcnt_arr[i] ;
    }
}

BOOL CheckValue(HWND hwnd)          // returns dwStart (value from editbox)
{
   BOOL bSuccess = FALSE;
   BOOL bErr = false ;      //
   char szText[2][8] ;      //
   char *stopStr ;          //
   signed long slTmp ;
   DWORD dwTextLength;

    GetDlgItemText(hwnd, ID_EDIT, (LPTSTR) szText[0], 8 ) ;
    dwTextLength = strlen(szText[0]) ;
    bErr = (dwTextLength==0) ;
    if (bErr)  {
        chMB("editbox must contain a value!\n") ; return false ;
    }

    slTmp= strtol(szText[0], &stopStr, 16) ;
    if (slTmp>=0) bSuccess = TRUE;
    else {
        chMB("error!\n enter a positive address") ;
        return false ;
    }
    dwStart = (DWORD) slTmp ;
    if (dwStart<=dwFileSize) bSuccess = TRUE;
    else {
        chMB("error!\n address greater than filesize") ;
        return false ;
    }
   return bSuccess;
}

BOOL DoFileOpenSave(HWND hwnd, BOOL bSave)
{
static char szFilter[] =  "model (*.*)\0*.*\0"
                          "All Files (*.*)\0*.*\0\0" ;

   OPENFILENAME ofn;
   char buffer[10], szFileName[MAX_PATH];

   ZeroMemory(&ofn, sizeof(ofn));
   szFileName[0] = 0;

   ofn.lStructSize = sizeof(ofn);
   ofn.hwndOwner = hwnd;
   ofn.lpstrFile = szFileName;
   ofn.nMaxFile = MAX_PATH;

   ofn.lpstrFilter       = szFilter;
   ofn.lpstrCustomFilter = NULL ;
   ofn.nMaxCustFilter    = 0 ;
   ofn.nFilterIndex      = 1L ;
   ofn.lpstrFile[0] = 0;
   ofn.lpstrTitle = TEXT("*.* open") ;
   ofn.Flags = OFN_EXPLORER | OFN_FILEMUSTEXIST;
   GetOpenFileName(&ofn);
   if (strlen((char *) ofn.lpstrFile)!= 0) {
        dwFileSize = _ReadFile(szFileName, lpFBuf, FALSE, stream) ;      // load the model to static buffer
        if (dwFileSize==0) {
            chMB("error: model file size==0!") ; return FALSE ;
        }
        strcpy(szFileNameG, szFileName) ;
        strcpy (szErrMess, "error in H20 no: ") ;
        SendDlgItemMessage(hwnd, ID_LIST, LB_RESETCONTENT, 0, 0L);
        switch (model) {        // set model in line 28 or make it available via a combo box
            case 1: break ;
            case 2: SetWindowText (GetDlgItem(hwnd, ID_EDIT), "0"); break ;
            case 3: SetWindowText (GetDlgItem(hwnd, ID_EDIT), "30"); break ;
            case 4: SetWindowText (GetDlgItem(hwnd, ID_EDIT), "B5B"); break ;   //
            case 5: case 6:                                                     // Atlantica, Winning
            case 7: case 8:                                                     //
            case 9: SetWindowText (GetDlgItem(hwnd, ID_EDIT), "0"); break ;
            case 10: if (!CheckValue(hwnd)) {
                        ltoa(dwFileSize,buffer,16);
                        SetWindowText (GetDlgItem(hwnd, ID_EDIT), buffer); }
                        else bFstRun= false ;
                     break ;
            case 11: SetWindowText (GetDlgItem(hwnd, ID_EDIT), "0"); break ;  // get startaddress from Edit1 ?
        }
        //if (CheckValue(hwnd)) {       // check the edit box contents (not required for model 2 so far)
        switch (model) {        // set model in line 28 or make it available via a combo box
            case 1: //SM_of_MLX_loop(hwnd, szFileName) ;
                    SM_of_SW_BF3_loop(hwnd, szFileName, 0) ;
                    EnableWindow(GetDlgItem(hwnd, ID_BUTTON1), TRUE) ;
                    //SetWindowText (GetDlgItem(hwnd, ID_EDIT), "F200");  // 0x10A10: table start in "DL020A_SD002J.MLX"
                    break ;// dwStart from Editbox
            case 2: SM_of_SpMan3_loop(hwnd, szFileName, 0) ; break ;
            case 3:  break ;
            case 4:  break ;
            case 5:  break ;
            case 6:  break ;
            case 7:  break ;
            case 8:  break ;  //
            case 9:  break ;  //
            case 10: break ;
            case 11: break ;
        }
        //}
    }
    return (TRUE) ;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam)
{
   static HWND  hwndButt1, hwndEdit ;
   static HWND  hwndCombo1, hwndList ;	// from environ.c
   static RECT  rect ;
   static int   cxChar, cyChar ;
   HDC          hdc ;
   PAINTSTRUCT  ps ;

   switch(Message)
   {
      case WM_CREATE:
           cxChar = LOWORD (GetDialogBaseUnits ()) ;
           cyChar = HIWORD (GetDialogBaseUnits ()) ;
           stream = fopen( FILENAME, "w" );
            if( stream == NULL ) {
                chMB("<Makeobj_log.txt> creation error!") ;
                DestroyWindow(hwnd);    // we really shouldn't "meet" the fclose()
                break ;                 // from WM_CLOSE
            }
         CreateWindow("EDIT", "",
            WS_CHILD | WS_VISIBLE | WS_HSCROLL | WS_VSCROLL | ES_MULTILINE |
               ES_WANTRETURN,
            CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
            hwnd, (HMENU)IDC_MAIN_TEXT, g_hInst, NULL);

         SendDlgItemMessage(hwnd, IDC_MAIN_TEXT, WM_SETFONT,
            (WPARAM)GetStockObject(DEFAULT_GUI_FONT), MAKELPARAM(TRUE, 0)); // GDI32.lib
            hwndList = CreateWindow (TEXT ("listbox"), NULL,
                              WS_CHILD | WS_VISIBLE | LBS_NOTIFY | WS_VSCROLL | WS_BORDER,
                              cxChar, cyChar ,
                              cxChar * 34 + GetSystemMetrics (SM_CXVSCROLL),
                              cyChar * 8,
                              hwnd, (HMENU) ID_LIST,
                              (HINSTANCE) GetWindowLong (hwnd, GWL_HINSTANCE),
                              NULL) ;
			SendDlgItemMessage(hwnd, ID_LIST, LB_RESETCONTENT, 0, 0L); //
   		    SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM) ">>> create obj files <<<") ;
			SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM) " editbox: hex start addr of ...") ;
			SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM) " ") ;
			SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM) " (log file MakeObj_log.txt in project dir)") ;
			SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM) "-------------------------------------------------------") ;

            hwndEdit = CreateWindow (TEXT ("edit"), NULL,
                            WS_CHILD | WS_VISIBLE | WS_BORDER,
                            cxChar+10, cyChar + 134+16 ,
                            10 * cxChar, cyChar,
                            hwnd, (HMENU) ID_EDIT,
                            (HINSTANCE) GetWindowLong (hwnd, GWL_HINSTANCE),
                        NULL) ;

			hwndButt1 = CreateWindow ( TEXT("button"),
                            TEXT ("log table"),         //
                            WS_CHILD | WS_VISIBLE | WS_DISABLED | BS_PUSHBUTTON,
                            cxChar+114, cyChar + 144,        // normal font: 130
                            10 * cxChar, 3 * cyChar / 2,
                            hwnd, (HMENU) ID_BUTTON1,
                        ((LPCREATESTRUCT) lParam)->hInstance, NULL) ;
            hwndCombo1 = CreateWindow (TEXT ("combobox"), NULL,          // model Auswahl combo
                              WS_CHILD | WS_VISIBLE | WS_BORDER | CBS_DROPDOWN,
                              cxChar+220, cyChar + 131+16,       // 170
                              9 * cxChar, 8*cyChar, //
                              hwnd, (HMENU) ID_COMBO1,
                              (HINSTANCE) GetWindowLong (hwnd, GWL_HINSTANCE),
                           NULL) ;
            SendMessage(hwndCombo1, CB_ADDSTRING, 0, (LPARAM) "SW_BF3") ;
            SendMessage(hwndCombo1, CB_ADDSTRING, 0, (LPARAM) "SpMan3") ;

            SendDlgItemMessage(hwnd, ID_COMBO1, CB_SETCURSEL, model-1, 0L);

        //SomeFunction("blubb") ;
      break;
      case WM_SIZE:
         //if(wParam != SIZE_MINIMIZED)
           // MoveWindow(GetDlgItem(hwnd, IDC_MAIN_TEXT), 0, 0, LOWORD(lParam),
             //  HIWORD(lParam), TRUE);
      break;
      case WM_PAINT : //return 0 ;
          InvalidateRect (hwnd, &rect, TRUE) ;

          hdc = BeginPaint (hwnd, &ps) ;
          SelectObject (hdc, GetStockObject (SYSTEM_FIXED_FONT)) ;
          SetBkMode (hdc, TRANSPARENT) ;

          //TextOut (hdc, 24 * cxChar, cyChar, szTop, lstrlen (szTop)) ;
          //TextOut (hdc, 24 * cxChar, cyChar, szUnd, lstrlen (szUnd)) ;

          EndPaint (hwnd, &ps) ;
          return 0 ;
      case WM_SETFOCUS:
         SetFocus(GetDlgItem(hwnd, IDC_MAIN_TEXT));
      break;
      case WM_COMMAND:
         switch(LOWORD(wParam))
         {
            case ID_BUTTON1:                    // show_table

                if (CheckValue(hwnd)) {         // editbox -> dwStart
                   SendDlgItemMessage(hwnd, ID_LIST, LB_RESETCONTENT, 0, 0L);
                   SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM) " (You might log here instead") ;
                   SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM) "  to MakeObj_log.txt)") ;
                   if (model==1) show_table(dwStart)  ; // log table to MakeH2O_log.txt
                   else {
                        SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM) " ") ;
                        SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM) " implemented for ... only") ;
                   }
                }
                break ;
            case ID_COMBO1:                             // model/format selection
                //_itoa(wParam/65536, szErrMess, 10) ; fprintf( stream, "%s\n", szErrMess) ;
                //if (wParam/65536==1) chMB("leckmichdochaa") ;
                 if (HIWORD(wParam)==CBN_SELCHANGE) {
                    model = (BYTE) LOWORD( SendDlgItemMessage(hwnd, ID_COMBO1, CB_GETCURSEL, 0, 0L) ) + 1 ;
                        //if (model==x) SetWindowText (GetDlgItem(hwnd, ID_EDIT), "ABCD");    // ABCD, kann vor File load �berschrieben werden
                 }
            break ;

            case CM_FILE_OPEN:
               DoFileOpenSave(hwnd, FALSE);
            break;
            case CM_FILE_SAVEAS:
               //DoFileOpenSaveAs(hwnd, TRUE);
            break;
            //case CM_FORMAT:
               //CheckFormat() ;
            //   chMB("not in use") ;
            break;
            case CM_FILE_EXIT:
               PostMessage(hwnd, WM_CLOSE, 0, 0);
            break;
            case CM_ABOUT:
               //MessageBox (NULL, "Make_H2O\n  by shak-otay 10/15\n \n     Verwendung auf\n      eigene Gefahr!\n (Use it on your own risk!)" , "About...", 0);
			   MessageBox (NULL, "         Make_obj\n    by shak-otay 03/17\n             ver 0.1\n \n     Verwendung auf\n      eigene Gefahr!\n (Use it on your own risk!)", "About...", 0);
            break ;
         }
      break;
      case WM_CLOSE:
         fclose( stream );        // uncomment when log file used
         DestroyWindow(hwnd);
      break;
      case WM_DESTROY:
         PostQuitMessage(0);
      break;
      default:
         return DefWindowProc(hwnd, Message, wParam, lParam);
   }
   return 0;
}


int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
   LPSTR lpCmdLine, int nCmdShow)
{
   WNDCLASSEX WndClass;
   HWND hwnd;
   MSG Msg;

   g_hInst = hInstance;

   WndClass.cbSize        = sizeof(WNDCLASSEX);
   WndClass.style         = 0;
   WndClass.lpfnWndProc   = WndProc;
   WndClass.cbClsExtra    = 0;
   WndClass.cbWndExtra    = 0;
   WndClass.hInstance     = g_hInst;
   WndClass.hIcon         = LoadIcon (hInstance, MAKEINTRESOURCE (5000)) ;//LoadIcon(NULL, IDI_APPLICATION);
   WndClass.hCursor       = LoadCursor(NULL, IDC_ARROW);
   WndClass.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
   WndClass.lpszMenuName  = "MAINMENU";
   WndClass.lpszClassName = g_szClassName;
   WndClass.hIconSm       = LoadIcon (hInstance, MAKEINTRESOURCE (5000)) ;//LoadIcon(NULL, IDI_APPLICATION);

   if(!RegisterClassEx(&WndClass))
   {
      MessageBox(0, "Window Registration Failed!", "Error!",
         MB_ICONEXCLAMATION | MB_OK | MB_SYSTEMMODAL);
      return 0;
   }

   hwnd = CreateWindowEx(
      WS_EX_CLIENTEDGE,
      g_szClassName,
      " Make_obj",
      WS_OVERLAPPEDWINDOW,
      CW_USEDEFAULT, CW_USEDEFAULT, 330, 256,
      NULL, NULL, g_hInst, NULL);

   if(hwnd == NULL)
   {
      MessageBox(0, "Window Creation Failed!", "Error!",
         MB_ICONEXCLAMATION | MB_OK | MB_SYSTEMMODAL);
      return 0;
   }

   ShowWindow(hwnd, nCmdShow);
   UpdateWindow(hwnd);

   while(GetMessage(&Msg, NULL, 0, 0))
   {
      TranslateMessage(&Msg);
      DispatchMessage(&Msg);
   }
   return Msg.wParam;
}


/*
   for (cnt=0;cnt<SMcnt;cnt++) {
       if (cnt==2) FVFsize= 52 ; else FVFsize= 48 ;
       addrV= FIaddr_arr[cnt] - vCnt_arr[cnt] * FVFsize ;    fprintf( stream, "# addrV: %x\n", addrV) ;
       log_short_Verts_SpMan3(addrV, vCnt_arr[cnt], FVFsize) ;

       pFBuf= pTmp + FIaddr_arr[cnt] ; j= FIaddr_arr[cnt] ;             // set start of FIs
        _itoa(cnt, szNo, 10) ; fprintf( stream, "g SM_%s\n", szNo) ;      // separating the submeshes (building groups)
            //fprintf( stream, "# FIcnt: %d\n", FIcnt_arr[i]) ;
        for (k=0;k<FIcnt_arr[cnt];k++) {       //
            //               adding lastFaceInd inside fct. gor absolute FIs
            FI[fCnt]= (WORD) GetFaceIndex(pFBuf, j, minFaceInd, maxFaceInd, lastFaceInd, false) ;	// j for count only!
            fCnt++ ;
            if (fCnt==3) {
                fCnt=0 ;
                fprintf( stream, "f %d/%d %d/%d %d/%d\n", FI[0],FI[0],FI[1],FI[1],FI[2],FI[2]) ;
            }
        }
        if (maxFaceInd<lastFaceInd) {
            fprintf( stream, "# error! maxFI %d < lastFI %d\n\n", maxFaceInd, lastFaceInd) ;
        }
        else lastFaceInd = maxFaceInd ;         // needed to "convert" relative to absolute face indices
            fprintf( stream, "# %d. maxFI %d,  lastFI %d\n\n", i, maxFaceInd, lastFaceInd) ;
        fprintf( stream, "# next FI block: %x\n", j) ;
            //cmpCnt += FIcnt_arr[i] ;
    }
*/
