Extract single or multiple files from Armed Assault PBO files.

- Prefix header is saved into file "$PBOPREFIX$". 
- Compressed files are not supported as they are unsupported in ArmA.
- If you don't select any files, all files in PBO are extracted.

ArmAUnPBO (C) 2006 feersum.endjinn AT gmail.com

This software is provided "as is", no warranty is given. Feel free to use provided source code as you want.