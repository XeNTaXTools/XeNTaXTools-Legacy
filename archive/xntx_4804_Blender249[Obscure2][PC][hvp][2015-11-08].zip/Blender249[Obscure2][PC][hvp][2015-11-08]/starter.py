import newGameLib
from newGameLib import *
import Blender
import shutil	


	
def tga(w,h,format,size,name,g):  
			new=open(name,'wb')
			print 'format:',format
			if format==21:	
				new.write('\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00')
				w = struct.pack('H',w)
				h = struct.pack('H',h)
				new.write(w)
				new.write(h)			
				new.write('\x20\x20')
			data=g.read(size)
			new.write(data)
			new.close()  
	
	
def section_4(filename,g):
	g.seek(4)
	g.debug=False
	while(True):
		if g.tell()==g.fileSize():break
		g.i(1)[0]
		image_name=g.dirname+os.sep+g.word(g.i(1)[0]).lower()+'.image'
		v=g.i(6)
		for m in range(v[0]):
			size=g.i(1)[0]
			t=g.tell()
			if m ==0:
				tga(v[3],v[4],v[5],size,image_name,g)
			g.seek(t+size)

def section_5(filename,g):
	g.i(1)[0]
	g.seek(9)
	model_name=g.word(g.i(1)[0])
	print 'model name=',model_name
	g.i(6)
	mat_count=g.i(1)[0]
	for m in range(mat_count):
		print 'material name',g.word(g.i(1)[0])
	v=g.i(7)#;print v
	flag=None
	if v[0]==1:
		g.seek(260,1)
		flag=True   
	if v[0]==9:
		#print Bf(67)
		g.seek(268,1)
		#flag=False   
		flag=True   
	print g.tell()
	if flag==True:
		v1=g.i(2);print 'v1=',v1
		v2=g.B(4);print 'v2=',v2
		mesh=Mesh()
		g.debug=False
		for m in range(v1[1]):
			t=g.tell()
			mesh.vertPosList.append(g.f(3))
			if v2[2]==7:			
				g.seek(t+28)				
				mesh.vertUVList.append(g.f(2))
				g.seek(t+36)
				
				skinIndiceList=[]
				skinWeightList=[]
				for n in range(4):
					skinIndiceList.append(g.i(1)[0])
					skinWeightList.append(g.f(1)[0])
				mesh.skinIndiceList.append(skinIndiceList)
				mesh.skinWeightList.append(skinWeightList)	
				g.seek(t+68)
			elif v2[2]==3:			
				g.seek(t+28)				
				mesh.vertUVList.append(g.f(2))
				g.seek(t+36)
				skinIndiceList=[]
				skinWeightList=[]
				for n in range(3):
					skinIndiceList.append(g.i(1)[0])
					skinWeightList.append(g.f(1)[0])
				g.seek(t+60)
			elif v2[2]==0:		
				g.seek(t+28)				
				mesh.vertUVList.append(g.f(2))
				g.seek(t+36)
		v3=g.i(3);print 'v3=',v3,g.tell()
		mat_indices=[]
		for m in range(v3[0]):
			mesh.faceList.append(g.H(3))
			mesh.matIDList.append(g.H(1)[0])#mat indeks
		#g.debug=True
		skin=Skin()
		mesh.skinList.append(skin)
		for m in range(mat_count):
			mat=Mat()
			mesh.matList.append(mat)
		
		skeleton=Skeleton()
		skeleton.name='srmature-'+str(ParseID())
		skeleton.ARMATURESPACE=True
		skeleton.NICE=True
		if v[0]!=1111:
			for m in range(mat_count):
				print g.i(2),g.B(1)
				img=None
				image_name=g.word(g.i(1)[0]).lower()
				g.i(14)
				g.f(4)	
				g.f(4)	
				g.f(4)	
				g.f(3)	
				image_name=g.word(g.i(1)[0]).lower()
				print 'image name',image_name
				"""if image_name+'.tga' in image_files:
					img=Blender.Image.Load(image_files[image_name+'.tga'])
				if image_name+'.bmp' in image_files:
					img=Blender.Image.Load(image_files[image_name+'.bmp'])"""
				#for image in Blender.Image.Get():
				#	if image.name==image_name:
				mat=mesh.matList[m]
				mat.diffuse=g.dirname+os.sep+image_name+'.bmp'
				print mat.diffuse

				print g.i(3)		
			skeleton_flag=g.i(1)[0]
			if skeleton_flag==6:
				print g.B(5)
				root=g.word(g.i(1)[0])
				g.seek(48,1)
				v2=g.i(3);print 'v2=',v2,g.tell()
				
				bone_name_list=[]
				bone_child_list={}
				bone_matrices=[]
				
				for m in range(v2[0]):
				
					bone=Bone()
					#if m>0:
					skeleton.boneList.append(bone)
					bone.name=g.word(g.i(1)[0])
					#bone_name_list.append(name)
					bone.childList=g.i(g.i(1)[0])
					#print m,bone.childList
					row1=g.f(4)
					row2=g.f(4)
					row3=g.f(4)
					row4=[0.0,0.0,0.0,1.0]
					matrix=Matrix(row1,row2,row3,row4)
					if m>0:bone.matrix=matrix.transpose()
					else:
						bone.matrix=Matrix()
					g.f(5)
					
				for i,bone in enumerate(skeleton.boneList):
					for childID in bone.childList:
						skeleton.boneList[childID].parentID=i
						#print i,childID
					
				skeleton.draw()	
					
		mesh.boneNameList=skeleton.boneNameList
		mesh.BINDSKELETON=skeleton.name
		mesh.draw()	

	
def tree(data,n,path):
	n+=4
	print '-'*n,data	
	id=data[4]
	path+=os.sep+str(id)
	try:os.mkdir(path)
	except:pass	
	for m in range(data[3]):
		if list[id][0]==4:
			tree(list[id],n,path)
		if list[id][0]==1:
			old=dir+os.sep+str(id)
			if os.path.exists(old)==False:
				os.makedirs(old)
			new=path+os.sep+str(id)
			shutil.move(old,new)
			#print '-'*(n+4),list[id]	
		id+=1
		

def i(n):
	return struct.unpack(n*'i', plik.read(n*4))	
	
def hvp_parser(filename):
	global plik
	global list,dir
	plik=open(filename,'rb')
	v0=i(5);print v0
	list=[]
	for m in range(v0[2]):
		list.append(i(6))		
	print 'tell',plik.tell()
	
	
	dir=os.path.dirname(filename)
	if os.path.exists(dir)==False:
		os.makedirs(dir)
	
	n=0
	path=dir
	if list[0][0]==4:
		path+=os.sep+str(0)
		try:os.mkdir(path)
		except:pass	
		tree(list[0],n,path)
	
	
	plik.close()	
	


def binParser(filename,g):
	#g.debug=True
	g.endian='>'
	type=g.i(1)[0]
	print 'type',type
	if type==5:
		section_5(filename,g)
	if type==4:
		section_4(filename,g)
	if type==3:
		section_4(filename,g)
	g.tell()
	
def Parser(filename):	
	print '='*70
	print filename
	print '='*70
	ext=filename.split('.')[-1].lower()	
	
	if ext=='hvp':	
		hvp_parser(filename)
	else:	
		file=open(filename,'rb')
		g=BinaryReader(file)
		binParser(filename,g)
		file.close()
 
	
Blender.Window.FileSelector(Parser,'import','Obscure 2 files') 
	