﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace landb5
{
    public class Line
    {
        public byte[] begin;//56 bytes
        public int size0, size1, size2;
        public byte[] who;
        public int size3, size4;
        public byte[] line;
        public byte[] end;//20 bytes

        public void read(BinaryReader input)
        {
            begin = input.ReadBytes(56);
            size0 = input.ReadInt32();
            size1 = input.ReadInt32();
            size2 = input.ReadInt32();
            if(size2>0)
                who = input.ReadBytes(size2);
            size3 = input.ReadInt32();
            size4 = input.ReadInt32();
            if (size4 > 0)
                line = input.ReadBytes(size4);
            end = input.ReadBytes(20);
        }

        public void write(BinaryWriter output)
        {
            output.Write(begin);
            output.Write(size0);
            output.Write(size1);
            output.Write(size2);
            if (size2 > 0)
                output.Write(who);
            output.Write(size3);
            output.Write(size4);
            if (size4 > 0)
                output.Write(line);
            output.Write(end);
        }

        public void changeLine(byte[] newLine) 
        {
            int diff = newLine.Length - size4;
            size0 += diff;
            size3 += diff;
            size4 += diff;
            line = newLine;
        }

        public void changeWho(byte[] newWho)
        {
            int diff = newWho.Length - size2;
            size0 += diff;
            size1 += diff;
            size2 += diff;
            line = newWho;      
        }
    }
}
