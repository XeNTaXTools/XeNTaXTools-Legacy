﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace landb5
{
    class Utils
    {
        public static byte[] NEWLINE = new byte[] { 0x0D, 0x0A };
        public const byte ZERO = 0;
        public const byte LS = 0x0A;
        public const byte BAR = 0x7C;// '|'
        public const byte SPACE = 0x20;// ' '

        public static void replaceBytes(byte[] array, byte oldByte, byte newByte) 
        {
            for (int i = 0; i < array.Length; i++) 
            {
                if (array[i] == oldByte)
                    array[i] = newByte;
            }
        }
    }
}
