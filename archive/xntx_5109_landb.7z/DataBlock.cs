﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace landb5
{
    class DataBlock
    {
        public int size;
        public byte[] data;

        public void read(BinaryReader input)
        {
            size = input.ReadInt32();
            if(size>0)
                data = input.ReadBytes(size-4);
        }

        public void write(BinaryWriter output)
        {
            output.Write(size);
            if (size > 0)
                output.Write(data);
        }
    }
}
