﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace landb5
{
    public class Program
    {
        static void Main(string[] args)
        {
            string inputFile = args[0];
            string outputFile = args[0] + ".txt";
            string newFile = args[0] + "2";

            if (args.Length >= 1)
            {
                LandDB5File landb5File = new LandDB5File();
                using (var input = new BinaryReader(File.OpenRead(inputFile)))
                {
                    landb5File.read(input);
                }
                if (args.Length == 1)
                {
                    using (var output = new BinaryWriter(File.Open(outputFile, FileMode.Create, FileAccess.Write)))
                    {
                        int lineCount = landb5File.lc;
                        for (int i = 0; i < lineCount; i++)
                        {
                            if (landb5File.lines[i].who != null)
                            {
                                output.Write(landb5File.lines[i].who);
                            }
                            output.Write(Utils.NEWLINE);
                            if (landb5File.lines[i].line != null)
                            {
                                byte[] lineArray = landb5File.lines[i].line;
                                Utils.replaceBytes(lineArray, Utils.ZERO, Utils.SPACE);
                                Utils.replaceBytes(lineArray, Utils.LS, Utils.BAR);
                                output.Write(lineArray);
                            }
                            output.Write(Utils.NEWLINE);
                        }
                    }
                }
                else
                {
                    using (var output = new StreamReader(outputFile))
                    {
                        int lineCount = landb5File.lc;
                        for (int i = 0; i < lineCount; i++)
                        {
                            byte[] newWho = System.Text.Encoding.UTF8.GetBytes(output.ReadLine());
                            if (landb5File.lines[i].who != null)
                            {                           
                                landb5File.lines[i].changeWho(newWho);
                            }
                            byte[] newLine = System.Text.Encoding.UTF8.GetBytes(output.ReadLine());
                            if (landb5File.lines[i].line != null)
                            {
                                Utils.replaceBytes(newLine, Utils.BAR, Utils.LS);
                                landb5File.lines[i].changeLine(newLine);
                            }
                        }
                    }

                    using (var output = new BinaryWriter(File.Open(newFile, FileMode.Create, FileAccess.Write)))
                    {
                        landb5File.write(output);
                    }
                }
                    Console.WriteLine("extraction done!");
               
            }

        }
    }
}
