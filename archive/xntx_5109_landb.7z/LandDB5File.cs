﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace landb5
{
    public class LandDB5File
    {
        public int magic, textSize, size2, size3, count;
        public byte[] hashes;
        DataBlock a, b;
        public int bs, lc;
        public Line[] lines;
        DataBlock c;
        public byte[] hashes2;//12
        public byte[] size2Data, size3Data;

        public LandDB5File() 
        {
            a = new DataBlock();
            b = new DataBlock();
            c = new DataBlock();
        }

        public void read(BinaryReader input)
        {
            magic = input.ReadInt32();
            textSize = input.ReadInt32();
            size2 = input.ReadInt32();
            size3 = input.ReadInt32();
            count = input.ReadInt32();
            hashes = input.ReadBytes(count * 12);
            a.read(input);
            b.read(input);
            bs = input.ReadInt32();
            lc = input.ReadInt32();
            if (lc > 0) 
            {
                lines = new Line[lc];
                for (int i = 0; i < lc; ++i) 
                {
                    lines[i] = new Line();
                    lines[i].read(input);
                }
            }
            c.read(input);
            hashes2 = input.ReadBytes(16);
            if (size2 > 0)
                size2Data = input.ReadBytes(size2);
            if (size3 > 0)
                size3Data = input.ReadBytes(size3);           
        }

        public void write(BinaryWriter output)
        {
            output.Write(magic);
            output.Write(textSize);
            output.Write(size2);
            output.Write(size3);
            output.Write(count);
            output.Write(hashes);
            a.write(output);
            b.write(output);
            output.Write(bs);
            output.Write(lc);
            if (lc > 0) 
            {
                for (int i = 0; i < lc; ++i)
                {
                    lines[i].write(output);
                }
            }
            c.write(output);
            output.Write(hashes2);
            if (size2 > 0)
                output.Write(size2Data);
            if (size3 > 0)
                output.Write(size3Data);
        }
    }
}
