# Spider-Man 2 (Xbox) model importer by Bigchillghost

from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Spider-Man 2 Xbox", ".xbx")
	noesis.setHandlerTypeCheck(handle, checkType)
	noesis.setHandlerLoadModel(handle, modelLoadModel)
	
	#noesis.logPopup()
	return 1

#check if it's this type based on the data
def checkType(data):
	if len(data) < 0x80:
		return 0
	bs = NoeBitStream(data)
	Magic = bs.readUInt()
	if Magic != 0x4D584258:
		return 0
	return 1

#load the model
def modelLoadModel(data, mdlList):
	bs = NoeBitStream(data)
	bs.seek(8, NOESEEK_ABS)
	entryCnt = bs.readUInt()
	entryOffset = bs.readUInt()
	bs.seek(entryOffset, NOESEEK_ABS)
	entryList = []
	for i in range(0, entryCnt):
		Size = bs.readUInt24()
		assetType = bs.readUByte()
		subEntryOffset = bs.readUInt()
		strOffset = bs.readUInt()
		entryList.append([Size, assetType, subEntryOffset])
	
	ctx = rapi.rpgCreateContext()
	for i in range(0, entryCnt):
		if entryList[i][1] != 2:
			continue
		bs.seek(entryList[i][2], NOESEEK_ABS)
		meshGroupNameOffset = bs.readUInt()
		bs.seek(4, NOESEEK_REL)
		subMeshCnt = bs.readUInt()
		subMeshEntryOffset = bs.readUInt()
		boneCnt = bs.readUInt()
		boneMatOffset = bs.readUInt()
		unkCnt = bs.readUInt()
		unkOffset = bs.readUInt()
		bs.seek(subMeshEntryOffset, NOESEEK_ABS)
		subMeshEntryInfoOffset = [0]*subMeshCnt
		for j in range(0, subMeshCnt):
			bs.seek(4, NOESEEK_REL)
			subMeshEntryInfoOffset[j] = bs.readUInt()
		subMeshEntryInfo = []
		for j in range(0, subMeshCnt):
			bs.seek(8, NOESEEK_REL)
			mappingBoneIndexCount = bs.readUInt()
			mappingBoneIndexOffset = bs.readUInt()
			bs.seek(0x1C, NOESEEK_REL)
			vertexIndexCount = bs.readUInt()
			vertexIndexOffset = bs.readUInt()
			bs.seek(0xC, NOESEEK_REL)
			vertexCount = bs.readUInt()
			vertexOffset = bs.readUInt()
			vertexDataSize = bs.readUInt()
			bs.seek(4, NOESEEK_REL)
			vertexDataStride = bs.readUInt()
			bs.seek(0xC, NOESEEK_REL)
			subMeshEntryInfo.append([vertexIndexCount, vertexIndexOffset, 
									 vertexCount, vertexOffset, 
									 vertexDataSize, vertexDataStride])
		bs.seek(meshGroupNameOffset+4, NOESEEK_ABS)
		meshGroupName = bs.readString()
		for j in range(0, subMeshCnt):
			bs.seek(subMeshEntryInfo[j][1], NOESEEK_ABS)
			vertexIndexCount = subMeshEntryInfo[j][0]
			dataSize = vertexIndexCount * 2
			vertexIndexData = bs.readBytes(dataSize)
			bs.seek(subMeshEntryInfo[j][3], NOESEEK_ABS)
			vertexData = bs.readBytes(subMeshEntryInfo[j][4])
			vertexStride = subMeshEntryInfo[j][5]
			rapi.rpgSetName(meshGroupName+'_%d'%j)
			rapi.rpgBindPositionBuffer(vertexData, noesis.RPGEODATA_FLOAT, vertexStride)
			rapi.rpgBindUV1BufferOfs(vertexData, noesis.RPGEODATA_FLOAT, vertexStride, 0x10)
			rapi.rpgCommitTriangles(vertexIndexData, noesis.RPGEODATA_USHORT, vertexIndexCount, noesis.RPGEO_TRIANGLE_STRIP, 1)
			rapi.rpgSmoothNormals()
			rapi.rpgClearBufferBinds()
	if rapi.rpgGetVertexCount() == 0:
		return 0
	mdl = rapi.rpgConstructModelSlim()
	mdlList.append(mdl)
	
	return 1