#!/usr/bin/env python

 
from gimpfu import *


def my_script_function(image,layer):       
    dec_nrm_red, dec_nrm_green, dec_nrm_blu, dec_nrm_alpha = None, None, None, None
    active_layer = pdb.gimp_image_get_active_layer(image)
    dec_nrm_red, dec_nrm_green, dec_nrm_blu, dec_nrm_alpha = pdb.plug_in_decompose(image, active_layer, "RGBA", 0)       
    gimp.Display(dec_nrm_blu)
    gimp.Display(dec_nrm_red)
    gimp.Display(dec_nrm_green)
    gimp.Display(dec_nrm_alpha)
    tcol_draw = pdb.gimp_image_active_drawable(dec_nrm_blu)
    pdb.gimp_invert(tcol_draw)
    new_image = pdb.plug_in_compose(dec_nrm_alpha,None, dec_nrm_green, dec_nrm_blu,dec_nrm_red, "RGBA")
    gimp.Display(new_image)  
    gimp.delete(dec_nrm_red)
    gimp.delete(dec_nrm_green)
    gimp.delete(dec_nrm_alpha)
    gimp.delete(dec_nrm_blu)

register(
    "ppc_clos2_texture",    
    "Castlevania LoS 2 Texture Tools",   
    "Converts texture to my texture",
    "Predator CZ", 
    "Predatory Studios", 
    "6/2014",
    "<Image>/P Tools/Castlevania LoS 2 Texture Tools", 
    "*", 
    [], 
    [],
    my_script_function,
    )

main()
