from inc_noesis import *
import os

def registerNoesisTypes():
    handle = noesis.register("Hellboy: Science of Evil (X360 & PS3)", ".tex")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    bs.seek(len(data) - 0x30, NOESEEK_ABS)
    Magic = bs.readBytes(4).decode("ASCII")
    if Magic != "CPTM":
        if Magic != "3PTM":
            return 0
    return 1   

def noepyLoadRGBA(data, texList):
    datasize = len(data)
    bs = NoeBitStream(data)
    bs.setEndian(NOE_BIGENDIAN)
    bs.seek(len(data) - 0x30, NOESEEK_ABS)
    Magic = noeStrFromBytes(bs.readBytes(4))
    imgWidth = bs.readShort()
    imgHeight = bs.readShort()
    bs.seek(0x03, NOESEEK_REL)
    imgFmt = bs.readByte()              
    bs.seek(0x0)        
    #X360
    if Magic == "CPTM":
        #DXT1
        if imgFmt == 5 or imgFmt == 9:
            data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 8)
            texFmt = noesis.NOESISTEX_DXT1
        #DXT5
        elif imgFmt == 8:
            data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 16)
            texFmt = noesis.NOESISTEX_DXT5
        #DXT1 packed normal map
        elif imgFmt == 0xA:
            data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 8)
            data = rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_DXT1NORMAL)
            texFmt = noesis.NOESISTEX_RGBA32
    #PS3
    elif Magic == "3PTM":
       	#DXT5
        if imgFmt == 0x08:
            texFmt = noesis.NOESISTEX_DXT5
        #DXT1 packed normal map
        elif imgFmt == 0x0C:
            data = bytearray()
            for y in range(0, imgHeight):
                for x in range(0, imgWidth):
                    idx = noesis.morton2D(y, x)
                    if (idx * 4 + 4) > datasize:
                        idx = 0
                    bs.seek(0 + idx * 4, NOESEEK_ABS)
                    data += bs.readBytes(4)
            data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "r8 g8 b8 a8")
            texFmt = noesis.NOESISTEX_RGBA32
        #DXT1
        else:
            texFmt = noesis.NOESISTEX_DXT1
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1