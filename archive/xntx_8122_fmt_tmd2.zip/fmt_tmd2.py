from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Neptunia x Senran Kagura Ninja wars [Nintendo Switch]", ".tmd2")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    if noeAsciiFromBytes(bs.readBytes(3)) != "tmd": 
        return 0
    return 1   

def noepyLoadModel(data, mdlList):
    ctx = rapi.rpgCreateContext()        
    bs = NoeBitStream(data)
    bs.seek(40)
    info =  [bs.readUInt() for x in range(42)]
    f_offset, f_count, v_count, v_offset = info[9], info[25], info[29], info[13]
    print("f_offset:", f_offset,"f_count:", f_count,"v_count:", v_count,"v_offset:", v_offset)
    
    bs.seek(f_offset)
    ibuf = bs.readBytes(f_count * 6)
    
    bs.seek(v_offset)
    vbuf = bs.readBytes(v_count * 48)
    
    rapi.rpgBindPositionBuffer(vbuf, noesis.RPGEODATA_FLOAT, 48)
    rapi.rpgCommitTriangles(ibuf, noesis.RPGEODATA_SHORT, f_count*3, noesis.RPGEO_TRIANGLE)
    
    mdl = rapi.rpgConstructModel()                                                          
    mdlList.append(mdl)
    return 1