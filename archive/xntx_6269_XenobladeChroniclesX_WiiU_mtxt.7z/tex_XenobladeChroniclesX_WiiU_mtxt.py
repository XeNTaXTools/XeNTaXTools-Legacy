from inc_noesis import *
import subprocess

def registerNoesisTypes():
    handle = noesis.register("Xenoblade Chronicles X [WiiU]", ".mtxt")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadDDS)
    #noesis.logPopup()
    return 1
        
def noepyCheckType(data):
    bs = NoeBitStream(data, NOE_BIGENDIAN)
    bs.seek(bs.getSize() - 4, NOESEEK_ABS)
    if noeStrFromBytes(bs.readBytes(4)) != "MTXT": return 0
    return 1

def noepyLoadDDS(data, texList):
    bs = NoeBitStream(data, NOE_BIGENDIAN)

    #http://forum.xentax.com/viewtopic.php?p=120654#p120654

    bs.seek(bs.getSize() - 0x70, NOESEEK_ABS)
    swizzle = bs.readUInt()
    dimension = bs.readUInt()
    width = bs.readUInt()
    height = bs.readUInt()
    depth = bs.readUInt()
    unk = bs.readUInt()
    type = bs.readUInt()  
    datasize = bs.readUInt()
    aaMode = bs.readUInt()
    tileMode = bs.readUInt()
    unk = bs.readUInt()
    alignment = bs.readUInt()
    pitch = bs.readUInt()
    bs.seek(0x0, NOESEEK_ABS)
    data = bs.readBytes(datasize)
    
    #http://mk8.tockdom.com/wiki/GTX%5CGSH_(File_Format)   
    #https://pastebin.com/DCrP1w9x
    #https://pastebin.com/VDvs7q8Y
    #https://github.com/aboood40091/GTX-Extractor/blob/master/gtx_extract.py

    gtxHeader = b'\x47\x66\x78\x32\x00\x00\x00\x20\x00\x00\x00\x06\x00\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    gtxHeader += b'\x42\x4C\x4B\x7B\x00\x00\x00\x20\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x0A\x00\x00\x00\x9C\x00\x00\x00\x00\x00\x00\x00\x00'
    gtxHeader += bytearray(noePack(">I", dimension))                 #dimension
    gtxHeader += bytearray(noePack(">I", width))                     #width
    gtxHeader += bytearray(noePack(">I", height))                    #height
    gtxHeader += bytearray(noePack(">I", depth))                     #depth
    gtxHeader += b'\x00\x00\x00\x01'                                 #num mips
    gtxHeader += bytearray(noePack(">I", type))                      #type #DXT1 = 0x31 DXT5 = 0x33
    gtxHeader += bytearray(noePack(">I", aaMode))                    #aamode
    gtxHeader += b'\x00\x00\x00\x01'                                 #usage
    gtxHeader += bytearray(noePack(">I", datasize))                  #size
    gtxHeader += b'\x00\x00\x00\x00'                                 #data pointer
    gtxHeader += b'\x00\x00\x00\x00'                                 #mip map data length
    gtxHeader += b'\x00\x00\x00\x00'                                 #mipmaps pointer
    gtxHeader += bytearray(noePack(">I", tileMode))                  #tilemode        0x0-0x10 ??
    gtxHeader += bytearray(noePack(">I", swizzle))                   #swizzle value   0x0-0x7 ??
    gtxHeader += bytearray(noePack(">I", alignment))                 #alignment
    gtxHeader += bytearray(noePack(">I", pitch))                     #pitch
    gtxHeader += b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x01\x00\x01\x02\x03\x1F\xF8\x7F\x21\xC4\x00\x03\xFF\x06\x88\x84\x00\x00\x00\x00\x00\x80\x00\x00\x10'
    gtxHeader += b'\x42\x4C\x4B\x7B\x00\x00\x00\x20\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x0B'
    gtxHeader += bytearray(noePack(">I", datasize))
    gtxHeader += b'\x00\x00\x00\x00\x00\x00\x00\x00'
    gtxHeader += data
    gtxHeader += b'\x42\x4C\x4B\x7B\x00\x00\x00\x20\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'

    texName = rapi.getLocalFileName(rapi.getInputName())
    dstFilePath = noesis.getScenesPath() + texName + ".gtx"
    newfile = open(dstFilePath, 'wb')
    newfile.write(gtxHeader)
    newfile.close()
    subprocess.Popen([noesis.getScenesPath() + 'TexConv2.bat', dstFilePath]).wait()
    texData = rapi.loadIntoByteArray(dstFilePath + ".dds")
    texture = rapi.loadTexByHandler(texData, ".dds")
    texture.name = texName
    texList.append(texture)
    return 1
    