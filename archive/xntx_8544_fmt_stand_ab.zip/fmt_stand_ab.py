#  stand.ab importer by Bigchillghost
from inc_noesis import *
import os

def registerNoesisTypes():
	handle = noesis.register("Stand", ".ab")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadModel(handle, noepyLoadModel)
	#noesis.logPopup()
	return 1

#check if it's this type based on the data
def noepyCheckType(data):
	if len(data) < 0x80:
		return 0
	bs = NoeBitStream(data)
	Tag = bs.readInt()
	if Tag != 0 and (Tag & 0xFFFF) != 0xDA78:
		return 0
	return 1

def getUnzipData(data):
	if data[0] != 0x78 or data[1] != 0xDA:
		return data
	decSize = rapi.getInflatedSize(data)
	dest = rapi.decompInflate(data, decSize)
	return dest

def scanMeshAndTex(filePath, meshFiles, texFiles):
	meshPath = filePath + '\\mesh'
	texPath = filePath + '\\texture\\'
	for item in os.listdir(meshPath):
		meshFiles.append(item)
	texList = []
	matList = []
	for item in os.listdir(texPath):
		texName = item.split('.', 1)[0]
		tex = rapi.loadExternalTex(texPath+item)
		tex.name = texName
		mat = NoeMaterial(texName, texName)
		texFiles.append(texName)
		texList.append(tex)
		matList.append(mat)
	return NoeModelMaterials(texList, matList)

#load the model
def noepyLoadModel(data, mdlList):
	#noesis.logPopup()
	data = getUnzipData(data)
	bs = NoeBitStream(data, NOE_BIGENDIAN)
	bs.seek(8, NOESEEK_ABS)
	unkCount = bs.readInt()
	bs.seek(unkCount*12+4, NOESEEK_REL)
	
	# bone info
	boneCount = bs.readInt()
	bones = []
	matList = []
	boneIndexMap = {}
	for i in range(0, boneCount):
		boneName = 'bone_%02d'%(i)
		bonePIndex = bs.readInt()
		bs.seek(4, NOESEEK_REL)
		keyElementIndex = bs.readInt()
		boneIndexMap[keyElementIndex // 6] = i
		tran = NoeVec3.fromBytes(bs.readBytes(12), NOE_BIGENDIAN)
		rot = NoeQuat3.fromBytes(bs.readBytes(12), NOE_BIGENDIAN).toQuat()
		boneMat = rot.toMat43()
		boneMat[3] = tran
		bones.append( NoeBone(i, boneName, boneMat, None, bonePIndex) )
	
	# Converting local matrix to world space
	for i in range(0, boneCount):
		j = bones[i].parentIndex
		if j != -1:
			bones[i].setMatrix(bones[i].getMatrix()*bones[j].getMatrix())
		matList.append(bones[i].getMatrix())
	# convert to right-hand system
	for i in range(0, boneCount):
		bones[i].setMatrix(bones[i].getMatrix().swapHandedness())
	
	# animation
	frameCount = bs.readInt()
	frameMats = [None]*frameCount*boneCount
	for i in range(0, frameCount):
		elementCount = bs.readInt()
		baseIndex = i*boneCount
		for j in range(0, boneCount):
			tran = NoeVec3.fromBytes(bs.readBytes(12), NOE_BIGENDIAN)
			rot = NoeQuat3.fromBytes(bs.readBytes(12), NOE_BIGENDIAN).toQuat()
			boneMat = rot.toMat43()
			boneMat[3] = tran
			boneIndex = boneIndexMap[j]
			frameMats[baseIndex+boneIndex] = boneMat.swapHandedness()
	anim = NoeAnim('stand', bones, frameCount, frameMats, 30)
	anims = [anim]
	
	# meshes
	filePath = rapi.getDirForFilePath(rapi.getInputName())
	meshFiles = []
	texFiles = []
	modelMats = scanMeshAndTex(filePath, meshFiles, texFiles)
	meshes = []
	meshCnt = len(meshFiles)
	for m in range(meshCnt):
		filename = meshFiles[m]
		path = filePath + '\\mesh\\' + filename
		fp = open(path, 'rb')
		data = fp.read()
		fp.close()
		data = getUnzipData(data)
		bs = NoeBitStream(data, NOE_BIGENDIAN)
	
		Vcount = bs.readInt()
		PositionIdx = []
		WeightNum = []
		TexCoords = []
		
		for i in range(0, Vcount):
			TexCoords.append(NoeVec3([bs.readFloat(),bs.readFloat(), 0.0]))
			PositionIdx.append(bs.readInt())
			WeightNum.append(bs.readInt())
		IdxCount = bs.readInt() * 3
		PolygonIndex = []
		for i in range(0, IdxCount):
			PolygonIndex.append(bs.readInt())
		WeightCount = bs.readInt()
		Positions = []
		blockStart = bs.tell()
		vertWeightList = []
		for i in range(0, Vcount):
			Offset = blockStart + PositionIdx[i]*0x14
			bs.seek(Offset, NOESEEK_ABS)
			rlt = NoeVec3([0.0,0.0,0.0])
			bindBoneNum = WeightNum[i]
			boneIDs = [0]*bindBoneNum
			boneWeights = [0.0]*bindBoneNum
			for j in range(0, bindBoneNum):
				boneID = bs.readInt()
				weight = bs.readFloat()
				boneIDs[j] = boneID
				boneWeights[j] = weight
				coord = NoeVec3.fromBytes(bs.readBytes(12), NOE_BIGENDIAN)
				rlt += matList[boneID]*coord*weight
			rlt[0] *= -1
			Positions.append(rlt)
			vertWeightList.append(NoeVertWeight(boneIDs, boneWeights))
	
		meshName = filename.split('.')[0]
		texFile = texFiles[m] if m < len(texFiles) else texFiles[0]
		mesh = NoeMesh(PolygonIndex, Positions, meshName, texFile)
		mesh.setUVs(TexCoords)
		mesh.weights = vertWeightList
		meshes.append(mesh)
	
	mdl = NoeModel(meshes)
	mdl.setModelMaterials(modelMats)
	mdl.setBones(bones)
	mdl.setAnims(anims)
	mdlList.append(mdl)
	rapi.setPreviewOption("setAngOfs", "0 -90 0")
	return 1
