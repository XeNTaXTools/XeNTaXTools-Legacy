from inc_noesis import *
import noesis
import rapi
import os

def registerNoesisTypes():
    handle = noesis.register("Dead Space 1", ".geo")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    Magic = bs.readBytes(4).decode("ASCII")
    print(Magic)
    if Magic != "MGAE": 
        return 0
    version = bs.readInt()
    if version != 0x21:
        return 0
    return 1   

def noepyLoadModel(data, mdlList):
    ctx = rapi.rpgCreateContext()
    #rapi.setPreviewOption("setAngOfs","0 -60 90")        #set the default preview angle        
    bs = NoeBitStream(data)
    meshName = rapi.getLocalFileName(rapi.getInputName()).strip(".geo")
    rapi.rpgSetName(meshName)
    bs.seek(0x68, NOESEEK_ABS)                        
    tableOff = bs.readUInt()                              #pointer to data table
    bs.seek(tableOff, NOESEEK_ABS)
    VBsize = bs.readUInt()                                #vertex block size ? (doesn't always work)
    VCount = bs.readUInt()                                #vert count
    print(VCount, "vertex count")
    skip = bs.readByte()
    skip = bs.readByte()
    skip = bs.readByte()
    skip = bs.readByte()
    VStart = bs.readInt()                                 #start vertex data
    UVBsize = bs.readUInt()                               #UV block size ?
    skip = bs.readInt()
    uvStride = bs.readUByte()
    print(uvStride, "UV stride")
    skip = bs.readByte()
    UVflag = bs.readUByte()  #if UV flag is 1 we skip the 0xFFFFFFFF, not 100% sure this always works
    print(UVflag, "UV flag")
    skip = bs.readByte()
    uvOff = bs.readUInt()                                 #start UV data 
    skip = bs.readInt()
    FCount = bs.readUInt()                                #face indices count
    print(FCount, "face count")
    skip = bs.readByte()
    skip = bs.readByte()
    skip = bs.readByte()
    skip = bs.readByte()
    FIOff = bs.readUInt()                                 #start face indices
    if VStart != 0:
        bs.seek(VStart, NOESEEK_ABS)                        
        VBytes = 12                                       #vertex stride
    else:    
        bs.seek(0x50, NOESEEK_REL)
        VBytes = 32                                       #vertex stride
    VBuf = bs.readBytes(VCount * VBytes)
    bs.seek(FIOff, NOESEEK_ABS)
    IBuf = bs.readBytes(FCount * 2)                       #multiply by 2 for word, 4 for dword indices 
    if VBytes == 32:
        rapi.rpgBindPositionBufferOfs(VBuf, noesis.RPGEODATA_FLOAT, VBytes, 0)   #position of vertices
        #rapi.rpgBindNormalBufferOfs(VBuf, noesis.RPGEODATA_FLOAT, VBytes, 12)   #normals -optional
    elif VBytes == 12:
        rapi.rpgBindPositionBufferOfs(VBuf, noesis.RPGEODATA_FLOAT, VBytes, 0)   #position of vertices
    rapi.rpgSetPosScaleBias(NoeVec3([174, 174, 174]), None) #scale up geometry X,Y,Z by 174
    bs.seek(uvOff, NOESEEK_ABS)
    UVBuf = bs.readBytes(VCount * uvStride)
    if UVflag == 1 or uvStride == 28:
        rapi.rpgBindUV1BufferOfs(UVBuf, noesis.RPGEODATA_FLOAT, uvStride, 4)   #UVs
    else:
        rapi.rpgBindUV1BufferOfs(UVBuf, noesis.RPGEODATA_FLOAT, uvStride, 0)   #UVs
    checkTri = int(FCount % 3)                            #check if FCount is evenly divisible by 3,
    print(checkTri, "div by 3 check")
    if checkTri != 0:                                     
        rapi.rpgCommitTriangles(IBuf, noesis.RPGEODATA_SHORT, FCount, noesis.RPGEO_TRIANGLE_STRIP, 1)
    else:
        rapi.rpgCommitTriangles(IBuf, noesis.RPGEODATA_SHORT, FCount, noesis.RPGEO_TRIANGLE, 1)
    mdl = rapi.rpgConstructModel()                                                          
    mdlList.append(mdl)
    rapi.rpgClearBufferBinds()
    return 1