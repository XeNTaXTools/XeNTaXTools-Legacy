from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Tamsoft TMD2 model", ".tmd2")
	noesis.setHandlerTypeCheck(handle, tmd2CheckType)
	noesis.setHandlerLoadModel(handle, tmd2LoadModel)
	noesis.setTypeSharedModelFlags(handle, noesis.NMSHAREDFL_FLATWEIGHTS)

	return 1

TMD2_HEADER = 0x30646D74

#check if it's this type based on the data
def tmd2CheckType(data):
	if len(data) < 0xA0:
		return 0
	bs = NoeBitStream(data)

	if bs.readInt() != TMD2_HEADER:
		return 0

	return 1

#read it
def tmd2LoadModel(data, mdlList):
	bs = NoeBitStream(data)
	if bs.readInt() != TMD2_HEADER:
		return 0

	ctx = rapi.rpgCreateContext()

	unknown_04             = bs.readUShort()
	vertex_format          = bs.readUShort()
	unknown_08             = bs.readUShort()
	unknown_0A             = bs.readUShort()
	unknown_0C             = bs.readUShort()
	unknown_0E             = bs.readUShort()
	bound_min_x            = bs.readFloat()
	bound_min_y            = bs.readFloat()
	bound_min_z            = bs.readFloat()
	bound_max_x            = bs.readFloat()
	bound_max_y            = bs.readFloat()
	bound_max_z            = bs.readFloat()
	offset_parts           = bs.readUInt()
	unknown_2C             = bs.readUInt()
	offset_unknown_data1   = bs.readUInt()
	offset_commands        = bs.readUInt()
	offset_materials       = bs.readUInt()
	offset_material_params = bs.readUInt()
	offset_string_data     = bs.readUInt()
	offset_unknown_data3   = bs.readUInt()
	offset_sub_meshes      = bs.readUInt()
	offset_faces           = bs.readUInt()
	offset_texture_info    = bs.readUInt()
	unknown_54             = bs.readUInt()
	offset_textures        = bs.readUInt()
	offset_vertices        = bs.readUInt()
	offset_bounding_boxes  = bs.readUInt()
	unknown_64             = bs.readUInt()
	num_parts              = bs.readUInt()
	unknown_6C             = bs.readUInt()
	num_unknown_data1      = bs.readUInt()
	num_commands           = bs.readUInt()
	num_materials          = bs.readUInt()
	num_material_params    = bs.readUInt()
	size_string_data       = bs.readUInt()
	num_unknown_data3      = bs.readUInt()
	num_sub_meshes         = bs.readUInt()
	num_faces              = bs.readUInt()
	num_texture_info       = bs.readUInt()
	unknown_94             = bs.readUInt()
	num_textures           = bs.readUInt()
	num_vertices           = bs.readUInt()

	vertex_stride = 12 + 4 + 4 + 8
	have_weight = 0
	have_tangent = 0
	have_binormal = 0
	have_amb_ocl = 0
	have_color = 1
	have_uv = 1

	if (vertex_format & 0x0001) == 0:
		have_amb_ocl = 1
		vertex_stride += 4
	if (vertex_format & 0x0008) != 0:
		have_tangent  = 1
		have_binormal = 1
		vertex_stride += 8
	if (vertex_format & 0x0020) != 0:
		have_uv += 1
		vertex_stride += 8
	if (vertex_format & 0x0040) != 0:
		have_uv += 1
		vertex_stride += 8
	if (vertex_format & 0x0100) != 0:
		have_color += 1
		vertex_stride += 4
	if (vertex_format & 0xA400) == 0xA400:
		have_weight = 8
		vertex_stride += 16
	elif (vertex_format & 0xA400) == 0x2400:
		have_weight = 4
		vertex_stride += 8

	if have_weight != 0:
		offset2_sub_meshes     = bs.readUInt()
		unknown_A4             = bs.readUInt()
		offset_bone_transforms = bs.readUInt()
		offset_bones           = bs.readUInt()
		unknown_B0             = bs.readUInt()
		unknown_B4             = bs.readUInt()
		num_bone_transforms    = bs.readUInt()
		num_bones              = bs.readUInt()
		offset_unknown_data4   = bs.readUInt()
		offset_unknown_data5   = bs.readUInt()
		unknown_C8             = bs.readUInt()
		unknown_CC             = bs.readUInt()

	if num_vertices <= 0x10000:
		face_index_type = noesis.RPGEODATA_USHORT
		face_index_type_size = 2
	else:
		face_index_type = noesis.RPGEODATA_UINT
		face_index_type_size = 4

	vert_offs_weights  = 0
	vert_offs_bones    = 0
	vert_offs_weights2 = 0
	vert_offs_bones2   = 0
	vert_offs_normal   = 0
	vert_offs_tangent  = 0
	vert_offs_binormal = 0
	vert_offs_amb_ocl  = 0
	vert_offs_color    = 0
	vert_offs_color2   = 0
	vert_offs_uv       = 0
	vert_offs_uv2      = 0
	vert_offs_uv3      = 0

	work_offs = 12
	if have_weight != 0:
		vert_offs_weights = work_offs
		work_offs += 4
		vert_offs_bones = work_offs
		work_offs += 4
		if have_weight == 8:
			vert_offs_weights2 = work_offs
			work_offs += 4
			vert_offs_bones2 = work_offs
			work_offs += 4
	vert_offs_normal = work_offs
	work_offs += 4
	if have_tangent != 0:
		vert_offs_tangent = work_offs
		work_offs += 4
	if have_binormal != 0:
		vert_offs_binormal = work_offs
		work_offs += 4
	if have_amb_ocl != 0:
		vert_offs_amb_ocl = work_offs
		work_offs += 4
	vert_offs_color = work_offs
	work_offs += 4
	if have_color == 2:
		vert_offs_color2 = work_offs
		work_offs += 4
	vert_offs_uv = work_offs
	work_offs += 8
	if 2 <= have_uv:
		vert_offs_uv2 = work_offs
		work_offs += 8
		if 3 <= have_uv:
			vert_offs_uv3 = work_offs
			work_offs += 8
	vert_stride = work_offs

	bs.seek(offset_vertices, NOESEEK_ABS)
	vertices = bs.readBytes(vert_stride * num_vertices)

	rapi.rpgBindPositionBufferOfs(vertices, noesis.RPGEODATA_FLOAT, vert_stride, 0)
	rapi.rpgBindNormalBufferOfs(vertices, noesis.RPGEODATA_UBYTE, vert_stride, vert_offs_normal)
	if have_tangent != 0:
		rapi.rpgBindTangentBufferOfs(vertices, noesis.RPGEODATA_UBYTE, vert_stride, vert_offs_tangent)
	rapi.rpgBindColorBufferOfs(vertices, noesis.RPGEODATA_UBYTE, vert_stride, vert_offs_color, 4)
	rapi.rpgBindUV1BufferOfs(vertices, noesis.RPGEODATA_FLOAT, vert_stride, vert_offs_uv)
	if 2 <= have_uv:
		rapi.rpgBindUV2BufferOfs(vertices, noesis.RPGEODATA_FLOAT, vert_stride, vert_offs_uv2)

	if have_weight == 4:
		rapi.rpgBindBoneWeightBufferOfs(vertices, noesis.RPGEODATA_UBYTE, vert_stride, vert_offs_weights, 4)
		rapi.rpgBindBoneIndexBufferOfs(vertices, noesis.RPGEODATA_UBYTE, vert_stride, vert_offs_bones, 4)
	elif have_weight == 8:
		rapi.immBegin(noesis.RPGEO_TRIANGLE)
		for i in range(num_vertices):
			vcmp = noeUnpackFrom("<bbbb", vertices, vert_stride * i + vert_offs_weights)
			vcmp += noeUnpackFrom("<bbbb", vertices, vert_stride * i + vert_offs_weights2)
			rapi.immBoneWeight(vcmp)
			vcmp = noeUnpackFrom("<bbbb", vertices, vert_stride * i + vert_offs_bones)
			vcmp += noeUnpackFrom("<bbbb", vertices, vert_stride * i + vert_offs_bones2)
			rapi.immBoneIndex(vcmp)
		rapi.immEnd()

	sub_meshes = []
	bs.seek(offset_sub_meshes, NOESEEK_ABS)
	for i in range(num_sub_meshes):
		num_sub_faces = bs.readUInt()
		start_index   = bs.readUInt()
		sub_meshes.append([start_index, num_sub_faces])

	bs.seek(offset_faces, NOESEEK_ABS)
	faces = bs.readBytes(num_faces * 3 * face_index_type_size)

	mesh_name = rapi.getExtensionlessName(rapi.getLocalFileName(rapi.getLastCheckedName()))
	for i in range(0, num_sub_meshes):
		rapi.rpgSetName(mesh_name + "_mesh_" + str(i))
		face_start =              sub_meshes[i][0] * 3 * face_index_type_size
		face_end   = face_start + sub_meshes[i][1] * 3 * face_index_type_size
		rapi.rpgCommitTriangles(faces[face_start : face_end], face_index_type, sub_meshes[i][1] * 3, noesis.RPGEO_TRIANGLE, 1)

	mdl = rapi.rpgConstructModel()

	bones = []
	if have_weight != 0:
		bone_names      = []
		bone_parent_ids = []
		bs.seek(offset_bones, NOESEEK_ABS)
		for i in range(num_bones):
			bone_hash       = bs.readUInt()
			bone_x          = bs.readFloat()
			bone_y          = bs.readFloat()
			bone_z          = bs.readFloat()
			bone_parent_id  = bs.readInt()
			bone_unknown_14 = bs.readUInt()

			bone_names.append("bone_{0:08X}".format(bone_hash))
			bone_parent_ids.append(bone_parent_id)

		bs.seek(offset_bone_transforms, NOESEEK_ABS)
		for i in range(num_bone_transforms):
			mat44 = NoeMat44.fromBytes(bs.readBytes(0x40))
			mat43 = mat44.toMat43().inverse()
			bones.append(NoeBone(i, bone_names[i], mat43, None, bone_parent_ids[i]))

	anims = []

	mdl.setBones(bones)
	mdl.setAnims(anims)
	mdlList.append(mdl)
	return 1

