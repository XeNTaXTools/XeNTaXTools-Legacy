import bpy
import Blender,os	
from Blender.Mathutils import *
import types
import zlib



def inflate(data):
    decompress = zlib.decompressobj(
            -zlib.MAX_WBITS  # see above
    )
    inflated = decompress.decompress(data)
    inflated += decompress.flush()
    return inflated	

def eta(value,pad):
	intv=value/int(pad)
	floatv=value/float(pad)
	neta=floatv-intv
	if 	neta>0:return (1+intv)*pad
	else: return intv*pad

def safe(count,COUNT=100000):
	if count>COUNT:
		print 'OJ JAKA LICZBA:',count
		return 0
	else:
		return count
		

def Float255(data):
	list=[]
	for get in data:
		list.append(get/255.0)
	return list	


class File:pass	
	
class Sys(object):
	def __init__(self,input):
		self.input=input
		if '.' in os.path.basename(input):
			self.ext=os.path.basename(input).split('.')[-1]
		else:
			self.ext=''
		if '.' in os.path.basename(input):
			self.base=os.path.basename(input).split('.'+self.ext)[0]
		else:
			self.base=os.path.basename(input)
		self.dir=os.path.dirname(input)
		self.blend=Blender.Get('filename')
	def	addDir(self,base):
		newDir=self.dir+os.sep+base
		if os.path.exists(newDir)==False:
			os.makedirs(newDir)
			
	def split(key):
		g=open(self.input,'rb')
		data=g.read()
		fileSize=len(data)
		fileList=[]
		
		while(True):
			offset=data.find(key)
			if offset>0:
				file=File()
				fileList.append(file)
				print start+offset,len(data)
				data=data[offset+len(key):]
				start+=offset+len(key)
				file.offset=start-len(key)			
				file.path=self.dir+os.sep+self.base+'_files'+os.sep+str(len(fileList))+'.file'
			else:
				break
		for i,file in enumerate(fileList):
			g.seek(file.offset)
			if os.path.exists(os.path.dirname(file.path))==False:
				os.makedirs(os.path.dirname(file.path))
			new=open(file.path,'wb')
			if i<len(fileList)-1:data=g.read(fileList[i+1].offset-file.offset)
			else:data=g.read(fileSize-file.offset)
			new.write(data)
			new.close()	
		g.close()

			
			
	
	
def isQuat(quat):
	sum=quat[0]**2+quat[1]**2+quat[2]**2+quat[3]**2
	return sum	
	
def QuatMatrix(quat):
	return Quaternion(quat[3],quat[0],quat[1],quat[2]).toMatrix()	
	
	
def VectorMatrix(vector):
	return TranslationMatrix(Vector(vector))		
	
	
def roundVector(vec,dec=17):
	fvec=[]
	for v in vec:
		fvec.append(round(v,dec))
	return Vector(fvec)
	
	
def roundMatrix(mat,dec=17):
	fmat = []
	for row in mat:
		fmat.append(roundVector(row,dec))
	return Matrix(*fmat)

def Matrix4x4(data):
	return Matrix(  data[:4],\
					data[4:8],\
					data[8:12],\
					data[12:16])	

def Matrix3x3(data):
	return Matrix(  data[:3],\
					data[3:6],\
					data[6:9])
	

class Searcher():
	def __init__(self):
		self.dir=None
		self.list=[]
		self.what=None
	def run(self):
		dir=self.dir	
		def tree(dir):
			list_dir = os.listdir(dir)
			olddir = dir
			for m in list_dir:
				if self.what.lower() in m.lower():
					self.list.append(olddir+os.sep+m)				
				if os.path.isdir(olddir+os.sep+m)==True:
					dir = olddir+os.sep+m
					tree(dir)
		tree(dir)	
	
	
		
def ParseID():
		ids = []
		scene = bpy.data.scenes.active
		for mat in Blender.Material.Get():
			try:
				model_id = int(mat.name.split('-')[0])
				ids.append(model_id)
			except:pass
		for object in scene.objects:
			if object.getType()=='Mesh':
				try:
					model_id = int(object.getData(mesh=1).name.split('-')[0])
					ids.append(model_id)
				except:pass 
		for object in scene.objects:
			if object.getType()=='Armature':
				try:
					model_id = int(object.getData(mesh=1).name.split('-')[0])
					ids.append(model_id)
				except:pass 
		for mesh in bpy.data.meshes:
				try:
					model_id = int(mesh.name.split('-')[0])
					ids.append(model_id)
				except:pass   
		try:
			model_id = max(ids)+1
		except:
			model_id = 0
		return model_id 	
	