from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Spiderman 3 (PC)", ".PCPACK")
    noesis.setHandlerExtractArc(handle, pacExtractArc)
    #noesis.logPopup()
    return 1
    
def pacExtractArc(fileName, fileLen, justChecking):
    with open(fileName, "rb") as file:
        bs = NoeBitStream(file.read(fileLen))
    if justChecking:
        return 1
    bs.seek(0x54, NOESEEK_ABS)
    fileCount = bs.readUInt()
    tableLen = fileCount * 16
    TMP = bs.tell()
    myString = bs.readBytes(4500) 
    myIndex = myString.find(b"\xA1\xA1\xA1\xA1")
    bs.seek((TMP + myIndex) - tableLen, NOESEEK_ABS)
    for i in range(fileCount):
        basename = bs.readUInt()
        extension = bs.readUInt()
        offset = bs.readUInt()
        size = bs.readUInt()
        TMP2 = bs.tell()
        fileName = hex(basename) + "." + hex(extension)
        fileName = fileName.replace("0x", "") 
        bs.seek(offset, NOESEEK_ABS)
        rapi.exportArchiveFile(fileName, bs.readBytes(size))
        bs.seek(TMP2, NOESEEK_ABS)
    return 1