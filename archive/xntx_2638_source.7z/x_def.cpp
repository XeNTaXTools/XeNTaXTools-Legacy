#include "xentax.h"

bool error(const char* message)
{
 std::cout << message << std::endl;
 return false;
}