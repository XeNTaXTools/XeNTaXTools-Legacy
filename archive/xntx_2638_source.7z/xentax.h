#ifndef __XENTAX_H
#define __XENTAX_H

// Windows Headers
#define NOMINMAX
#pragma warning (disable : 4307)
#pragma warning (disable : 4996)
#include<windows.h>
#include<windowsx.h>
#include<commctrl.h>
#include<shlobj.h>
#include<tchar.h>
#include<ddraw.h>
#include<atlbase.h>
#include<comdef.h>
#include<msxml6.h>
#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "msxml6.lib")

// Standard Headers
#ifndef RC_INVOKED
#include<iostream>
#include<iomanip>
#include<fstream>
#include<sstream>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<vector>
#include<string>
using namespace std;
#endif

// Boost Headers
#ifndef RC_INVOKED
#include<boost/shared_array.hpp>
#include<boost/shared_ptr.hpp>
#endif

// ZLIB Headers
#ifndef RC_INVOKED
#include "zlib.h"
#pragma comment(lib, "zdll.lib")
#endif

// Xentax Headers
#ifndef RC_INVOKED
#include "x_data.h"
#include "x_file.h"
#include "x_math.h"
#include "x_bone.h"
#include "x_geom.h"
#include "x_zlib.h"
#include "x_findfile.h"
#include "x_stream.h"
#include "x_alg.h"
#include "x_bmp.h"
#include "x_dds.h"
#include "x_def.h"
#include "x_dlg.h"
#include "x_xbox360.h"
#include "x_dae.h"
#endif

#endif
