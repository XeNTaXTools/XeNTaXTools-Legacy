#include "xentax.h"

BOOL CreateBMPHeaders(DWORD dx, DWORD dy, DWORD bpp, BITMAPFILEHEADER* fileHeader, BITMAPINFOHEADER* infoHeader)
{
 // validate
 if(!fileHeader) return FALSE;
 if(!infoHeader) return FALSE;
 if(dx == 0) return FALSE;
 if(dy == 0) return FALSE;
 if(!(bpp == 1 || bpp == 4 || bpp == 8 || bpp == 16 || bpp == 24 || bpp == 32)) return FALSE;

 // set file header
 fileHeader->bfType = 0x4D42; 
 fileHeader->bfSize = 0;
 fileHeader->bfReserved1 = 0;
 fileHeader->bfReserved2 = 0;
 fileHeader->bfOffBits = 0;

 // set info header
 infoHeader->biSize = sizeof(BITMAPINFOHEADER);
 infoHeader->biWidth = dx;
 infoHeader->biHeight = dy;
 infoHeader->biPlanes = 1;
 infoHeader->biBitCount = (WORD)bpp;
 infoHeader->biCompression = BI_RGB;
 infoHeader->biSizeImage = 0;
 infoHeader->biXPelsPerMeter = 0;
 infoHeader->biYPelsPerMeter = 0;
 infoHeader->biClrUsed = 0;
 infoHeader->biClrImportant = 0;

 return TRUE;
}