#ifndef __XENTAX_XBOX360_H
#define __XENTAX_XBOX360_H

bool XB360Unbundle(const char* exedir, const char* filename, const char* outdir);

#endif
