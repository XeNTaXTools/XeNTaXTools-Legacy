#ifndef __XENTAX_GEOM_H
#define __XENTAX_GEOM_H

#define VERTEX_POSITION 0x1
#define VERTEX_NORMAL   0x2
#define VERTEX_UV       0x4
#define VERTEX_WEIGHTS  0x8

#define FACE_FORMAT_UINT_08 0x1
#define FACE_FORMAT_UINT_16 0x2
#define FACE_FORMAT_UINT_32 0x4

#define FACE_TYPE_TRIANGLES   0x1
#define FACE_TYPE_TRISTRIP    0x2
#define FACE_TYPE_TRISTRIPCUT 0x4

struct VERTEX {
 float vx, vy, vz;
 float nx, ny, nz;
 float tu, tv;
 float w1, w2, w3, w4;
 unsigned short b1, b2, b3, b4;
};

struct VERTEX_BUFFER {
 unsigned char flags;
 uint32 elem;
 boost::shared_array<VERTEX> data;
};

struct INDEX_BUFFER {
 unsigned char format;
 unsigned char type;
 string name;
 uint32 reference;
 uint32 elem;
 boost::shared_array<char> data;
};

/*
** GEOMETRY SUPPORT
*/
struct VTX_BUFFER {
 unsigned char flags;
 uint32 elem;
 boost::shared_array<VERTEX> data;
 uint32 skeleton;
};

typedef deque<VTX_BUFFER> VTXBLIST;
typedef deque<VTX_BUFFER>::iterator VTXBLIST_ITERATOR;

struct IDX_BUFFER {
 unsigned char format;
 unsigned char type;
 string name;
 uint32 elem;
 boost::shared_array<char> data;
 uint32 material;
};

typedef deque<IDX_BUFFER> IDXBLIST;
typedef deque<IDX_BUFFER>::iterator IDXBLIST_ITERATOR;

/*
** MATERIAL SUPPORT
*/
struct MATERIAL {
 string id;      // identifier
 uint32 basemap; // reference to texture id
 uint32 specmap; // reference to texture id
 uint32 bumpmap; // reference to texture id
 uint32 normmap; // reference to texture id
};

typedef deque<MATERIAL> MATERIAL_LIST;
typedef deque<MATERIAL>::iterator MATERIAL_LIST_ITERATOR;

/*
** SKELETON SUPPORT
*/
struct SKELETON {
 std::string id;
 JOINTTREE tree;
};

typedef std::deque<SKELETON> SKELETON_LIST;
typedef SKELETON_LIST SKELETON_LIST_ITERATOR;

/*
** TEXTURE SUPPORT
*/
struct TEXTURE {
 string id;
 string filename;
};

typedef deque<TEXTURE> TEXTURE_LIST;
typedef TEXTURE_LIST::iterator TEXTURE_LIST_ITERATOR;

/*
** MESH SUPPORT
*/
struct MESH {
 VTX_BUFFER vertices;
 deque<IDX_BUFFER> surfaces;
};

struct GEOMETRY {
 string id;
 string name;
 deque<boost::shared_ptr<MESH>> meshlist;
};

/*
** BONE SUPPORT
*/

bool GeometryToOBJ(const char* path, const char* name, const deque<VERTEX_BUFFER>& vd, const deque<INDEX_BUFFER>& fd);

#endif
