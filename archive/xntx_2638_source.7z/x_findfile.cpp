#include "xentax.h"

find_file::find_file() : handle(0)
{
 ZeroMemory(&find32, sizeof(find32));
}

find_file::~find_file()
{
 close();
}

void find_file::close(void)
{
 // must check for valid handle in 
 // VC++ .NET or else exception results
 if(handle) FindClose(handle);
 handle = 0;
 ZeroMemory((void*)&find32, sizeof(find32)); 
}

bool find_file::find(const char* filename)
{
 close();
 handle = FindFirstFileA(filename, &find32);
 if(handle == INVALID_HANDLE_VALUE) handle = 0;
 return (handle != 0);
}

bool find_file::next(void)
{
 if(handle == 0) return false;
 return (FindNextFileA(handle, &find32) == TRUE);
}

bool find_file::is_dots(void)
{
 return (!strcmp(find32.cFileName, ".") || !strcmp(find32.cFileName, ".."));
}

bool find_file::is_directory(void)
{
 return ((find32.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) != 0);
}

bool find_file::is_encrypted(void)
{
 return ((find32.dwFileAttributes & FILE_ATTRIBUTE_ENCRYPTED) != 0);
}

bool find_file::is_compressed(void)
{
 return ((find32.dwFileAttributes & FILE_ATTRIBUTE_COMPRESSED) != 0);
}

bool find_file::is_normal(void)
{
 return ((find32.dwFileAttributes & FILE_ATTRIBUTE_NORMAL) != 0);
}

bool find_file::is_hidden(void)
{
 return ((find32.dwFileAttributes & FILE_ATTRIBUTE_HIDDEN) != 0);
}

bool find_file::is_system(void)
{
 return ((find32.dwFileAttributes & FILE_ATTRIBUTE_SYSTEM) != 0);
}

bool find_file::is_archived(void)
{
 return ((find32.dwFileAttributes & FILE_ATTRIBUTE_ARCHIVE) != 0);
}

bool find_file::is_readonly(void)
{
 return ((find32.dwFileAttributes & FILE_ATTRIBUTE_READONLY) != 0);
}

const char* find_file::filename(void)
{
 strlwr(find32.cFileName);
 return (const char*)find32.cFileName;
}

size_t find_file::filesize(void)
{
 return (find32.nFileSizeHigh*(MAXDWORD + 1)) + find32.nFileSizeLow;
}

bool find_file::operator !(void)const
{
 return !handle;
}