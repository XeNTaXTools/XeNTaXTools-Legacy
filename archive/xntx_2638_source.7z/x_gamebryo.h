#ifndef __XENTAX_GAMEBRYO_H
#define __XENTAX_GAMEBRYO_H

#define GAMEBRYO_BEGIN namespace Gamebryo {
#define GAMEBRYO_END };

GAMEBRYO_BEGIN

bool extract(void);
bool extract(const char* pathname);

GAMEBRYO_END

#endif
