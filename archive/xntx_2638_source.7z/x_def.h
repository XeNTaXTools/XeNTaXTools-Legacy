#ifndef __XENTAX_DEF_H
#define __XENTAX_DEF_H

bool error(const char* message);

#endif