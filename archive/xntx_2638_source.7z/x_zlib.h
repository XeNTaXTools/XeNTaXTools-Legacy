#ifndef __XENTAX_ZLIB_H
#define __XENTAX_ZLIB_H

bool CompressZLIB(ifstream& ifile, ofstream& ofile);
bool CompressZLIB(ifstream& ifile, ofstream& ofile, int level);

bool DecompressZLIB(ifstream& ifile, ofstream& ofile);
bool DecompressZLIB(ifstream& ifile, ofstream& ofile, int windowBits);
bool DecompressZLIB(ifstream& ifile, size_t n, ofstream& ofile, int windowBits);

#endif
