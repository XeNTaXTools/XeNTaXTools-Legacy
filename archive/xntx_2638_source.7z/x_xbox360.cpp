#include "xentax.h"

bool XB360Unbundle(const char* exedir, const char* filename, const char* outdir)
{
 using namespace std;

 // command line
 string cmdline = "\"";
 cmdline += exedir;
 cmdline += "unbundler.exe";
 cmdline += "\"";
 cmdline += " ";
 cmdline += "\"";
 cmdline += filename;
 cmdline += "\"";

 // process startup information
 STARTUPINFOA sinfo;
 ZeroMemory(&sinfo, sizeof(sinfo));
 sinfo.cb = sizeof(sinfo);

 // process information
 PROCESS_INFORMATION pinfo;
 ZeroMemory(&pinfo, sizeof(pinfo));

 // run xbdecompress
 char buffer[1024];
 memmove(buffer, cmdline.c_str(), cmdline.length() + 1);
 if(!CreateProcessA(NULL, buffer, NULL, NULL, FALSE, NORMAL_PRIORITY_CLASS, NULL, outdir, &sinfo, &pinfo)) return error("Failed to run xbdecompress on XPR file.");
 WaitForSingleObject(pinfo.hProcess, INFINITE);
 CloseHandle(pinfo.hProcess);
 CloseHandle(pinfo.hThread);

 return true;
}
