#ifndef __XENTAX_BMP_H
#define __XENTAX_BMP_H

BOOL CreateBMPHeaders(DWORD dx, DWORD dy, DWORD bpp, BITMAPFILEHEADER* fileHeader, BITMAPINFOHEADER* infoHeader);

#endif
