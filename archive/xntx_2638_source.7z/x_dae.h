#ifndef __XENTAX_DAE_H
#define __XENTAX_DAE_H

bool GeometryToDAE(const char* path, const char* name, const GEOMETRY& data, const MATERIAL_LIST& materials, const TEXTURE_LIST& textures, const SKELETON_LIST& sl);

#endif
