#include "xentax.h"

JOINTTREE::JOINTTREE()
{
 root = INVALID_JOINT;
}

bool JOINTTREE::InsertJoint(uint32 index, const JOINT& joint)
{
 // check if already inserted
 tree_t::iterator temp = tree.find(index);
 if(temp != tree.end()) return error("InsertJoint: Joint already exists.");

 // insert root
 if(joint.parent == INVALID_JOINT) {
    node_t node;
    node.joint = joint;
    tree.insert(tree_t::value_type(index, node));
    root = index;
    return true;
   }

 // find parent
 tree_t::iterator parent = tree.find(joint.parent);
 if(parent == tree.end()) return error("InsertJoint: Can't find parent joint.");

 // insert node
 node_t node;
 node.joint = joint;
 tree.insert(tree_t::value_type(index, node));

 // insert into parent's adjacency list
 parent->second.children.push_back(index);
 return true;
}

bool JOINTTREE::RemoveJoint(uint32 index)
{
 // TODO
 return true;
}

void JOINTTREE::PrintJointTree(std::stringstream& ss)const
{
 PrintJointTree(ss, root, 0);
}

void JOINTTREE::PrintJointTree(std::stringstream& ss, uint32 index, uint32 level)const
{
 // find node
 const_tree_iterator iter = tree.find(index);
 if(iter == tree.end()) return;

 // build string
 const node_t& node = iter->second;
 for(size_t i = 0; i < level; i++) ss << " ";
 ss << node.joint.name << std::endl;

 // visit children of joint tree node
 for(size_t i = 0; i < node.children.size(); i++) PrintJointTree(ss, node.children[i], level + 1);
}

void JOINTTREE::PrintColladaNodeHeirarchy(const std::string& id, std::stringstream& ss)const
{
 PrintColladaNodeHeirarchy(id, ss, root, 0);
}

void JOINTTREE::PrintColladaNodeHeirarchy(const std::string& id, std::stringstream& ss, uint32 index, uint32 level)const
{
 // NOTES:
 // Unlike in Collada specification, you must have id attributes for all joint nodes if you want to see the
 // names in 3DS MAX. Solution is to just define id and sid together at the same time.

 // find node
 const_tree_iterator iter = tree.find(index);
 if(iter == tree.end()) return;

 // determine spacing
 std::string spacing = "  ";
 for(size_t i = 0; i < level; i++) spacing += ' ';

 // print node
 const node_t& node = iter->second;
 if(index == root) ss << spacing << "<node id=\"" << id << "\" sid=\"" << node.joint.name << "\">" << std::endl;
 else ss << spacing << "<node id=\"" << node.joint.name << "\" sid=\"" << node.joint.name << "\" type=\"JOINT\">" << std::endl;

 // position node
 ss << spacing << " <matrix>" << endl;
 ss << spacing << "  " << "1 0 0 " << node.joint.rel_x << endl;
 ss << spacing << "  " << "0 1 0 " << node.joint.rel_y << endl;
 ss << spacing << "  " << "0 0 1 " << node.joint.rel_z << endl;
 ss << spacing << "  " << "0 0 0 1" << endl;
 ss << spacing << " </matrix>" << endl;

 // print children
 for(size_t i = 0; i < node.children.size(); i++)
     PrintColladaNodeHeirarchy(id, ss, node.children[i], level + 1);

 // finish node
 ss << spacing << "</node>" << endl;
}

void JOINTTREE::PrintColladaJoints(const std::string& id, std::stringstream& ss)const
{
 ss << "    <source id=\"" << id << "_joints\">" << endl;

 ss << "     <Name_array count=\"" << tree.size() << "\">" << endl;
 PrintColladaJoints(ss, root);
 ss << "     </Name_array>" << endl;

 ss << "     <technique_common>" << endl;
 ss << "      <acessor source=\"#" << id << "_joints\" count=\"" << tree.size() << "\" stride=\"1\">" << endl;
 ss << "       <param name=\"JOINT\" type=\"name\" />" << endl;
 ss << "      </acessor>" << endl;
 ss << "     </technique_common>" << endl;

 ss << "    </source>" << endl;
}

void JOINTTREE::PrintColladaJoints(std::stringstream& ss, uint32 index)const
{
 // find node
 const_tree_iterator iter = tree.find(index);
 if(iter == tree.end()) return;

 // print node
 const node_t& node = iter->second;
 ss << "      " << node.joint.name << std::endl;

 // print children
 for(size_t i = 0; i < node.children.size(); i++)
     PrintColladaJoints(ss, node.children[i]);
}

void JOINTTREE::PrintColladaBindMatrices(const std::string& id, std::stringstream& ss)const
{
 ss << "    <source id=\"" << id << "_matrices\">" << endl;
 ss << "     <float_array count=\"" << 16*tree.size() << "\">" << endl;
 PrintColladaBindMatrices(ss, root);
 ss << "     </float_array>" << endl;

 ss << "     <technique_common>" << endl;
 ss << "      <acessor source=\"#" << id << "_matrices\" count=\"" << tree.size() << "\" stride=\"16\">" << endl;
 ss << "       <param name=\"INV_BIND_MATRIX\" type=\"float4x4\" />" << endl;
 ss << "      </acessor>" << endl;
 ss << "     </technique_common>" << endl;

 ss << "    </source>" << endl;
}

void JOINTTREE::PrintColladaBindMatrices(std::stringstream& ss, uint32 index)const
{
 // find node
 const_tree_iterator iter = tree.find(index);
 if(iter == tree.end()) return;

 // print node
 const node_t& node = iter->second;
 ss << "      ";
 ss << node.joint.matrix[ 0] << " ";
 ss << node.joint.matrix[ 1] << " ";
 ss << node.joint.matrix[ 2] << " ";
 ss << node.joint.matrix[ 3] << " ";
 ss << node.joint.matrix[ 4] << " ";
 ss << node.joint.matrix[ 5] << " ";
 ss << node.joint.matrix[ 6] << " ";
 ss << node.joint.matrix[ 7] << " ";
 ss << node.joint.matrix[ 8] << " ";
 ss << node.joint.matrix[ 9] << " ";
 ss << node.joint.matrix[10] << " ";
 ss << node.joint.matrix[11] << " ";
 ss << node.joint.matrix[12] << " ";
 ss << node.joint.matrix[13] << " ";
 ss << node.joint.matrix[14] << " ";
 ss << node.joint.matrix[14] << " " << endl;

 // print children
 for(size_t i = 0; i < node.children.size(); i++)
     PrintColladaBindMatrices(ss, node.children[i]);
}