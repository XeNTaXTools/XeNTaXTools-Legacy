# Extraction Script for DefJam Vandetta, only works on the PS2 version for SLPS_252.75
#
# requires two files;
# SLPS_252.75
# Data/data.bin
#
# Author: mariokart64n
# Date:   October 20 2019
# 

from inc_noesis import *

gameID = "SLPS_252.75"

def registerNoesisTypes():
	#noesis.logPopup()
	handle = noesis.register("Def Jam Vandetta (PS2-JPN)", ".75")
	noesis.setHandlerExtractArc(handle, binExtractArc)
	return 1

def binExtractArc(fileName, fileLen, justChecking):
	fname = rapi.getLocalFileName(fileName)
	datafile = rapi.getDirForFilePath(fileName) + "DATA\\DATA.BIN"
	
	if justChecking:
		if fname.upper() != gameID:
			noesis.messagePrompt("Extraction Failed:\nUnsupported ELF File '" + fname + "'")
			return 0
		if (rapi.checkFileExists(datafile)) == False:
			noesis.messagePrompt("Extraction Failed:\nUnable to Find the data file 'DATA\\DATA.BIN'")
			return 0
		return 1
	
	elf = open(fileName, "rb")
	data = open(datafile, "rb")
	
	table_count = 293
	
	num = "000"
	file_ext = ".bin"
	for entry in range(0, table_count):
		elf.seek(0x0015A088 + (entry * 0x08))
		file_offset = noeUnpack("<I", elf.read(4))[0] * 0x0800
		file_size = noeUnpack("<I", elf.read(4))[0] * 0x0800
		
		data.seek(file_offset)
		file_ext = "."
		num = ("000" + str(entry + 1))[-3:]
		for c in range(0, 4):
			cc = data.read(1)[0]
			if cc > 47 and  cc < 91:
				if cc != 32:
					file_ext += chr(cc)
			else:
				if cc != 32:
					file_ext = ".bin"
					break
				
			
		
		file_ext = file_ext.lower()
		if file_ext == ".tim2": file_ext = ".tm2"
		
		data.seek(file_offset)
		rapi.exportArchiveFile("data_" + num + file_ext, data.read(file_size))
	
	elf.close()
	data.close()
	
	return 1
