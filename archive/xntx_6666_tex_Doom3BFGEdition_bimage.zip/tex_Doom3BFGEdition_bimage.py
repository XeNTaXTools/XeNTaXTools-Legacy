from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Doom 3: BFG Edition", ".bimage")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    bs.seek(0x8)
    if bs.readBytes(4) != b'\x0a\x4d\x49\x42': return 0
    return 1
    
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data, NOE_BIGENDIAN)
    bs.seek(0x10)
    imgFmt = bs.readUInt()
    bs.seek(0x4, 1)
    imgWidth = bs.readUInt()
    imgHeight = bs.readUInt()           
    print(imgWidth, "x", imgHeight)
    bs.seek(0x38)
    data = bs.readBytes(bs.getSize() - bs.tell())      
    if imgFmt == 0x7:
        texFmt = noesis.NOESISTEX_DXT1
    elif imgFmt == 0x8:
        texFmt = noesis.NOESISTEX_DXT5
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1