/*
  Archive.cpp
  A Game Extractor archive resource
*/

#include "stdafx.h"
#include "Resource.h"

// Constructors
geResource::geResource(JNIEnv* Env) :
	m_Env(Env),
	m_Resource(NULL),
	m_ResourceClass(NULL)
{
	// FAIL! Creating archives is not yet supported.
	// TODO: Support creating archives
	return;
}

geResource::geResource(JNIEnv* Env, jobject Resource) :
	m_Env(Env),
	m_Resource(Resource),
	m_ResourceClass(NULL)
{
	GetResourceClass();
	return;
}

geResource::~geResource()
{
	// Unref the resource
	if(m_Env)
	{
		if(m_Resource)
		{
			m_Env->DeleteLocalRef(m_Resource);
			m_Resource=NULL;
		}
		if(m_ResourceClass)
		{
			m_Env->DeleteLocalRef(m_ResourceClass);
			m_ResourceClass=NULL;
		}
	}
	return;
}


// General Methods
bool geResource::IsOkay() const
{
	return m_Env && m_Resource && m_ResourceClass ? true : false;
}

// Resource Methods
bool geResource::Extract(const std::string& OutputFilename) const
{
	// Make sure we're oaky
	if(!IsOkay())
	{
		return false;
	}

	// Objects (need to be freed)
	jclass FileClass;
	jstring FilenameString;
	jobject FileObject;

	// Find the file class
	FileClass=m_Env->FindClass("java/io/File");
	if(!FileClass)
	{
		m_Env->ExceptionClear();
		return false;
	}

	// Get the method ID of the constructor
	jmethodID FileConstructorID;
	FileConstructorID=m_Env->GetMethodID(FileClass, "<init>", "(Ljava/lang/String;)V");
	if(!FileConstructorID)
	{
		m_Env->ExceptionClear();
		m_Env->DeleteLocalRef(FileClass);
		return false;
	}

	// Create a string as the argument
	FilenameString=m_Env->NewStringUTF(OutputFilename.c_str());
	if(!FilenameString)
	{
		m_Env->ExceptionClear();
		m_Env->DeleteLocalRef(FileClass);
		return false;
	}

	// Construct the File object
	FileObject=m_Env->NewObject(FileClass, FileConstructorID, FilenameString);
	if(!FileObject)
	{
		m_Env->ExceptionClear();
		m_Env->DeleteLocalRef(FilenameString);
		m_Env->DeleteLocalRef(FileClass);
		return false;
	}

	// Find the extract function
	jmethodID ExtractMethodID;
	ExtractMethodID=m_Env->GetMethodID(m_ResourceClass, "extract", "(Ljava/io/File;)Ljava/io/File;");
	if(!ExtractMethodID)
	{
		m_Env->ExceptionClear();
		m_Env->DeleteLocalRef(FileObject);
		m_Env->DeleteLocalRef(FilenameString);
		m_Env->DeleteLocalRef(FileClass);
		return false;
	}

	// Call the extract function
	jobject ResultingFile;
	ResultingFile=(jobject)m_Env->CallObjectMethod(m_Resource, ExtractMethodID, FileObject);
	if(!ResultingFile)
	{
		m_Env->ExceptionClear();
		m_Env->DeleteLocalRef(FileObject);
		m_Env->DeleteLocalRef(FilenameString);
		m_Env->DeleteLocalRef(FileClass);
		return false;
	}

	// TODO: Perhaps get the filename of the resulting file?

	// Delete the objects
	m_Env->DeleteLocalRef(ResultingFile);
	m_Env->DeleteLocalRef(FileObject);
	m_Env->DeleteLocalRef(FilenameString);
	m_Env->DeleteLocalRef(FileClass);
	return true;
}

unsigned long long geResource::GetDecompressedLength() const
{
	// Make sure we're oaky
	if(!IsOkay())
	{
		return -1;
	}

	// Get the method ID
	jmethodID MethodID;
	MethodID=m_Env->GetMethodID(m_ResourceClass, "getDecompressedLength", "()J");
	if(!MethodID)
	{
		return -1;
	}

	// Call the method
	unsigned long long DecompLength;
	DecompLength=m_Env->CallLongMethod(m_Resource, MethodID);
	if(m_Env->ExceptionCheck())
	{
		m_Env->ExceptionClear();
		return -1;
	}
	return DecompLength;
}

std::string geResource::GetName() const
{
	// Make sure we're oaky
	if(!IsOkay())
	{
		return "";
	}

	// Get the method ID
	jmethodID GetNameMethodID;
	GetNameMethodID=m_Env->GetMethodID(m_ResourceClass, "getName", "()Ljava/lang/String;");
	if(!GetNameMethodID)
	{
		return "";
	}

	// Call the method
	jstring NameString;
	NameString=(jstring)m_Env->CallObjectMethod(m_Resource, GetNameMethodID);
	if(!NameString)
	{
		return "";
	}

	// Convert the string
	std::string Name;
	const char* Chars;
	Chars=m_Env->GetStringUTFChars(NameString, NULL);
	if(Chars)
	{
		Name=std::string(Chars);
	}
	m_Env->ReleaseStringUTFChars(NameString, Chars);
	m_Env->DeleteLocalRef(NameString);
	return Name;
}

// Helper Methods
void geResource::GetResourceClass()
{
	// Find the resource class
	m_ResourceClass=m_Env->FindClass("Resource");
	if(!m_ResourceClass)
	{
		m_Env->ExceptionClear();
		return;
	}
	return;
}
