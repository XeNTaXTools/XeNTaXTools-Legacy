/*
  Plugin.h
  A Game Extractor plugin
*/

#pragma once

// Make sure we have the right JNI header
#ifndef JNI_VERSION_1_6
#error "Java/JNI 1.6 or higher is required!"
#endif

// Forward Declarations
class geArchive;

// A Game Extractor plugin
class gePlugin
{
public:
	// Constructors
	gePlugin(JNIEnv* Env, const std::string& ClassName);
	virtual ~gePlugin();

	// General Methods
	virtual bool IsOkay() const;

	// ArchivePlugin Methods
	virtual void GetGames(std::vector<std::string>& Games) const;
	virtual void GetExtentions(std::vector<std::string>& Extentions) const;
	virtual int GetMatchRating(const std::string& Filename) const;
	virtual geArchive* Read(const std::string& Filename) const;

protected:
	virtual bool DoInstantiate(const std::string& ClassName);
	virtual void DoDelete();

protected:
	JNIEnv* m_Env;
	jclass m_Class;
	jobject m_Object;
};
