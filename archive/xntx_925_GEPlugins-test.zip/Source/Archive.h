/*
  Archive.h
  A Game Extractor archive
*/

#pragma once

// Required headers
#include "Resource.h"

// Make sure we have the right JNI header
#ifndef JNI_VERSION_1_6
#error "Java/JNI 1.6 or higher is required!"
#endif

// A Game Extractor archive
class geArchive
{
public:
	// Constructors
	geArchive(JNIEnv* Env);
	geArchive(JNIEnv* Env, jobjectArray Resources);
	virtual ~geArchive();

	// General Methods
	virtual bool IsOkay() const;

	// Management
	virtual unsigned long GetResourceCount() const;
	virtual geResource GetResource(unsigned long Index) const;
	virtual void SetResource(unsigned long Index, const geResource& NewResource);

protected:
	// Internal Variables
	JNIEnv* m_Env;
	jobjectArray m_Resources;
};
