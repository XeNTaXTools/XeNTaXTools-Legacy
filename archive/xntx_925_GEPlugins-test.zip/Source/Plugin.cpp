/*
  Plugin.cpp
  A Game Extractor plugin
*/

#include "stdafx.h"
#include "Plugin.h"
#include "Archive.h"

gePlugin::gePlugin(JNIEnv* Env, const std::string& ClassName) :
	m_Env(Env),
	m_Class(NULL),
	m_Object(NULL)
{
	// Try to instantate the plugin
	if(!DoInstantiate(ClassName))
	{
		m_Env=NULL;
		m_Class=NULL;
		m_Object=NULL;
	}
	return;
}

gePlugin::~gePlugin()
{
	// Delete the plugin
	DoDelete();
	return;
}

bool gePlugin::IsOkay() const
{
	if(!m_Env || !m_Class || !m_Object)
	{
		return false;
	}
	return true;
}

void gePlugin::GetGames(std::vector<std::string>& Games) const
{
	// Make sure we're okay
	if(!IsOkay())
	{
		return;
	}

	// Get the games list
	jmethodID GetGamesMethod;
	jobjectArray GamesObject;
	GetGamesMethod=m_Env->GetMethodID(m_Class, "getGames", "()[Ljava/lang/String;");
	if(GetGamesMethod)
	{
		GamesObject=(jobjectArray)m_Env->CallObjectMethod(m_Object, GetGamesMethod);
		if(GamesObject)
		{
			for(long i=0;i<m_Env->GetArrayLength(GamesObject);i++)
			{
				jstring String;
				const char* Chars;
				String=(jstring)m_Env->GetObjectArrayElement(GamesObject, i);
				if(String)
				{
					Chars=m_Env->GetStringUTFChars(String, NULL);
					if(Chars)
					{
						Games.push_back(std::string(Chars));
					}
					m_Env->ReleaseStringUTFChars(String, Chars);
					m_Env->DeleteLocalRef(String);
				}
			}
			m_Env->DeleteLocalRef(GamesObject);
		}
	}
	return;
}

void gePlugin::GetExtentions(std::vector<std::string>& Extentions) const
{
	// Make sure we're okay
	if(!IsOkay())
	{
		return;
	}

	// Get the extentions list
	jmethodID GetExtentionsMethod;
	jobjectArray ExtentionsObject;
	GetExtentionsMethod=m_Env->GetMethodID(m_Class, "getExtensions", "()[Ljava/lang/String;");
	if(GetExtentionsMethod)
	{
		ExtentionsObject=(jobjectArray)m_Env->CallObjectMethod(m_Object, GetExtentionsMethod);
		if(ExtentionsObject)
		{
			for(long i=0;i<m_Env->GetArrayLength(ExtentionsObject);i++)
			{
				jstring String;
				const char* Chars;
				String=(jstring)m_Env->GetObjectArrayElement(ExtentionsObject, i);
				if(String)
				{
					Chars=m_Env->GetStringUTFChars(String, NULL);
					if(Chars)
					{
						Extentions.push_back(std::string(Chars));
					}
					m_Env->ReleaseStringUTFChars(String, Chars);
					m_Env->DeleteLocalRef(String);
				}
			}
			m_Env->DeleteLocalRef(ExtentionsObject);
		}
	}
	return;
}

int gePlugin::GetMatchRating(const std::string& Filename) const
{
	// Make sure we're okay
	if(!IsOkay())
	{
		return -1;
	}

	// Objects (need to be freed)
	jclass FileClass;
	jstring FilenameString;
	jobject FileObject;

	// Find the file class
	FileClass=m_Env->FindClass("java/io/File");
	if(!FileClass)
	{
		m_Env->ExceptionClear();
		return -1;
	}

	// Get the method ID of the constructor
	jmethodID FileConstructorID;
	FileConstructorID=m_Env->GetMethodID(FileClass, "<init>", "(Ljava/lang/String;)V");
	if(!FileConstructorID)
	{
		m_Env->ExceptionClear();
		m_Env->DeleteLocalRef(FileClass);
		return -1;
	}

	// Create a string as the argument
	FilenameString=m_Env->NewStringUTF(Filename.c_str());
	if(!FilenameString)
	{
		m_Env->ExceptionClear();
		m_Env->DeleteLocalRef(FileClass);
		return -1;
	}

	// Construct the File object
	FileObject=m_Env->NewObject(FileClass, FileConstructorID, FilenameString);
	if(!FileObject)
	{
		m_Env->ExceptionClear();
		m_Env->DeleteLocalRef(FilenameString);
		m_Env->DeleteLocalRef(FileClass);
		return -1;
	}

	// Find the match rating function
	jmethodID GetMatchRatingID;
	GetMatchRatingID=m_Env->GetMethodID(m_Class, "getMatchRating", "(Ljava/io/File;)I");
	if(!GetMatchRatingID)
	{
		m_Env->ExceptionClear();
		m_Env->DeleteLocalRef(FileObject);
		m_Env->DeleteLocalRef(FilenameString);
		m_Env->DeleteLocalRef(FileClass);
		return -1;
	}

	// Call the match rating function
	int MatchRating;
	MatchRating=m_Env->CallIntMethod(m_Object, GetMatchRatingID, FileObject);
	if(m_Env->ExceptionCheck())
	{
		m_Env->ExceptionClear();
		m_Env->DeleteLocalRef(FileObject);
		m_Env->DeleteLocalRef(FilenameString);
		m_Env->DeleteLocalRef(FileClass);
		return -1;
	}

	// Delete the objects
	m_Env->DeleteLocalRef(FileObject);
	m_Env->DeleteLocalRef(FilenameString);
	m_Env->DeleteLocalRef(FileClass);
	return MatchRating;
}

geArchive* gePlugin::Read(const std::string& Filename) const
{
	// Make sure we're okay
	if(!IsOkay())
	{
		return NULL;
	}

	// Objects (need to be freed)
	jclass FileClass;
	jstring FilenameString;
	jobject FileObject;
	jobjectArray Resources;

	// Find the file class
	FileClass=m_Env->FindClass("java/io/File");
	if(!FileClass)
	{
		m_Env->ExceptionClear();
		return NULL;
	}

	// Get the method ID of the constructor
	jmethodID FileConstructorID;
	FileConstructorID=m_Env->GetMethodID(FileClass, "<init>", "(Ljava/lang/String;)V");
	if(!FileConstructorID)
	{
		m_Env->ExceptionClear();
		m_Env->DeleteLocalRef(FileClass);
		return NULL;
	}

	// Create a string as the argument
	FilenameString=m_Env->NewStringUTF(Filename.c_str());
	if(!FilenameString)
	{
		m_Env->ExceptionClear();
		m_Env->DeleteLocalRef(FileClass);
		return NULL;
	}

	// Construct the File object
	FileObject=m_Env->NewObject(FileClass, FileConstructorID, FilenameString);
	if(!FileObject)
	{
		m_Env->ExceptionClear();
		m_Env->DeleteLocalRef(FilenameString);
		m_Env->DeleteLocalRef(FileClass);
		return NULL;
	}

	// Find the read function
	jmethodID ReadMethodID;
	ReadMethodID=m_Env->GetMethodID(m_Class, "read", "(Ljava/io/File;)[LResource;");
	if(!ReadMethodID)
	{
		m_Env->ExceptionClear();
		m_Env->DeleteLocalRef(FileObject);
		m_Env->DeleteLocalRef(FilenameString);
		m_Env->DeleteLocalRef(FileClass);
		return NULL;
	}

	// Call the read function
	Resources=(jobjectArray)m_Env->CallObjectMethod(m_Object, ReadMethodID, FileObject);
	if(!Resources)
	{
		m_Env->ExceptionClear();
		m_Env->DeleteLocalRef(FileObject);
		m_Env->DeleteLocalRef(FilenameString);
		m_Env->DeleteLocalRef(FileClass);
		return NULL;
	}

	// Delete the objects
	m_Env->DeleteLocalRef(FileObject);
	m_Env->DeleteLocalRef(FilenameString);
	m_Env->DeleteLocalRef(FileClass);
	return new geArchive(m_Env, Resources);
}

bool gePlugin::DoInstantiate(const std::string& ClassName)
{
	// Make sure we're initialized
	if(!m_Env)
	{
		return false;
	}

	// Variables
	jmethodID ConstructorID;

	// Find the plugin class
	m_Class=m_Env->FindClass(ClassName.c_str());
	if(!m_Class)
	{
		return false;
	}

	// Get the method ID of the constructor
	ConstructorID=m_Env->GetMethodID(m_Class, "<init>", "()V");
	if(!ConstructorID)
	{
		m_Env->DeleteLocalRef(m_Class);
		return false;
	}

	// Construct the object
	m_Object=m_Env->NewObject(m_Class, ConstructorID);
	if(!m_Object)
	{
		m_Env->DeleteLocalRef(m_Class);
		return false;
	}
	return true;
}

void gePlugin::DoDelete()
{
	// Make sure we're initialized
	if(!m_Env)
	{
		return;
	}

	// Free it
	if(m_Object)
	{
		m_Env->DeleteLocalRef(m_Object);
		m_Object=NULL;
	}
	if(m_Class)
	{
		m_Env->DeleteLocalRef(m_Class);
		m_Class=NULL;
	}
	return;
}
