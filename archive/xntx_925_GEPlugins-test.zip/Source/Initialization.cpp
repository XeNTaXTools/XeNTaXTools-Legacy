/*
  Initialization.h
  Performs the initialization for GEPlugins
*/

#include "stdafx.h"
#include "Initialization.h"
#include "JavaSettingsClass.h"
#include "Plugin.h"

#include "Archive.h" // Delete?

bool InitializeEnvironment()
{
	// Check if it's already initialized
	if(g_Env.Initialized)
	{
		return true;
	}

	// Open the registry key
	HKEY Key;
	if(RegOpenKeyEx(HKEY_CURRENT_USER, "Software\\MexComGEPlugins", NULL, \
		KEY_ALL_ACCESS, &Key)!=ERROR_SUCCESS)
	{
		if(RegCreateKeyEx(HKEY_CURRENT_USER, "Software\\MexComGEPlugins", NULL, \
			NULL, 0, KEY_ALL_ACCESS, NULL, &Key, NULL)!=ERROR_SUCCESS)
		{
			// Failed to create the key -- oh well
			Key=NULL;
		}
	}

	// Look for some values in the registry
	if(Key)
	{
		// Storage variables
		unsigned long ValueType;
		unsigned long ValueSize;
		char StringData[1024];
		unsigned long IntegerData;

		// Get the filename of the JRE binary
		memset(StringData, 0, sizeof(StringData));
		ValueSize=sizeof(StringData);
		if(RegQueryValueEx(Key, "JreBinary", NULL, &ValueType, (unsigned char*)StringData, \
			&ValueSize)!=ERROR_SUCCESS)
		{
			g_Env.JreBinary="";
		}
		else
		{
			if(IsFile(StringData))
			{
				g_Env.JreBinary=StringData;
			}
			else
			{
				g_Env.JreBinary="";
			}
		}

		// Get the Game Extractor JAR filename
		memset(StringData, 0, sizeof(StringData));
		ValueSize=sizeof(StringData);
		if(RegQueryValueEx(Key, "GEJarFilename", NULL, &ValueType, (unsigned char*)StringData, \
			&ValueSize)!=ERROR_SUCCESS)
		{
			g_Env.GEJarFilename="";
		}
		else
		{
			if(IsFile(StringData))
			{
				g_Env.GEJarFilename=StringData;
			}
			else
			{
				g_Env.GEJarFilename="";
			}
		}

		// Get the Game Extractor plugins path
		memset(StringData, 0, sizeof(StringData));
		ValueSize=sizeof(StringData);
		if(RegQueryValueEx(Key, "GEPluginPath", NULL, NULL, (unsigned char*)StringData, \
			&ValueSize)!=ERROR_SUCCESS)
		{
			g_Env.GEPluginPath="";
		}
		else
		{
			if(IsDirectory(StringData))
			{
				g_Env.GEPluginPath=StringData;
			}
			else
			{
				g_Env.GEPluginPath="";
			}
		}

		// Get the cache filename
		memset(StringData, 0, sizeof(StringData));
		ValueSize=sizeof(StringData);
		if(RegQueryValueEx(Key, "CacheFilename", NULL, &ValueType, (unsigned char*)StringData, \
			&ValueSize)!=ERROR_SUCCESS)
		{
			g_Env.CacheFilename="";
		}
		else
		{
			if(IsFile(StringData))
			{
				g_Env.CacheFilename=StringData;
			}
			else
			{
				g_Env.CacheFilename="";
			}
		}

		// Get the flush cache flag
		ValueSize=sizeof(IntegerData);
		if(RegQueryValueEx(Key, "FlushCache", NULL, NULL, (unsigned char*)&IntegerData, \
			&ValueSize)!=ERROR_SUCCESS)
		{
			g_Env.FlushCache=true;
		}
		else
		{
			if(IntegerData)
			{
				g_Env.FlushCache=true;
			}
			else
			{
				g_Env.FlushCache=false;
			}
		}
	}

	// Locate the JRE if not already found; do not save into registry
	if(g_Env.JreBinary.empty())
	{
		HKEY JreKey;
		if(RegOpenKeyEx(HKEY_LOCAL_MACHINE, "Software\\JavaSoft\\Java Runtime Environment", NULL, \
			KEY_READ, &JreKey)==ERROR_SUCCESS)
		{
			std::string CurJavaKeyName;
			unsigned long ValueSize;
			char StringData[1024];

			// Figure out which version to use
			memset(StringData, 0, sizeof(StringData));
			ValueSize=sizeof(StringData);
			if(RegQueryValueEx(JreKey, "BrowserJavaVersion", NULL, NULL, \
				(unsigned char*)StringData, &ValueSize)==ERROR_SUCCESS)
			{
				// Set the current key name
				CurJavaKeyName="Software\\JavaSoft\\Java Runtime Environment\\";
				CurJavaKeyName.append(StringData);
			}

			// Close the key
			RegCloseKey(JreKey);

			// Now try to open the key for the current Java version
			if(RegOpenKeyEx(HKEY_LOCAL_MACHINE, CurJavaKeyName.c_str(), NULL, \
				KEY_READ, &JreKey)==ERROR_SUCCESS)
			{
				// Get the path to the Java VM
				memset(StringData, 0, sizeof(StringData));
				ValueSize=sizeof(StringData);
				if(RegQueryValueEx(JreKey, "RuntimeLib", NULL, NULL, \
					(unsigned char*)StringData, &ValueSize)==ERROR_SUCCESS)
				{
					// Validate and save it
					if(IsFile(StringData))
					{
						g_Env.JreBinary=StringData;
					}
				}

				// Close the key
				RegCloseKey(JreKey);
			}
		}
	}

	// Find Game Extractor JAR file if not already found
	if(g_Env.GEJarFilename.empty())
	{
		std::string GEPath="C:\\Program Files\\Game Extractor\\GameExtractor.jar";
		if(IsFile(GEPath))
		{
			g_Env.GEJarFilename=GEPath;
		}
	}

	// Save Game Extractor JAR file
	if(!g_Env.GEJarFilename.empty())
	{
		RegSetValueEx(Key, "GEJarFilename", NULL, REG_SZ, \
			(unsigned char*)g_Env.GEJarFilename.c_str(), \
			(unsigned long)g_Env.GEJarFilename.size()+1);
	}

	// Find Game Extractor plugin path if not already found
	if(g_Env.GEPluginPath.empty())
	{
		std::string GEPath="C:\\Program Files\\Game Extractor\\plugins";
		if(IsDirectory(GEPath))
		{
			g_Env.GEPluginPath=GEPath;
		}
	}

	// Save Game Extractor plugin path
	if(!g_Env.GEPluginPath.empty())
	{
		RegSetValueEx(Key, "GEPluginPath", NULL, REG_SZ, \
			(unsigned char*)g_Env.GEPluginPath.c_str(), \
			(unsigned long)g_Env.GEPluginPath.size()+1);
	}

	// Find the cache if not already found
	if(g_Env.CacheFilename.empty())
	{
		// Get the path to the user storage area
		char PathBuffer[MAX_PATH];
		memset(PathBuffer, 0, sizeof(PathBuffer));
		SHGetFolderPath(NULL, CSIDL_APPDATA, NULL, SHGFP_TYPE_CURRENT, PathBuffer);

		// Check directories
		std::string Path=PathBuffer;
		if(IsDirectory(Path))
		{
			Path.append("\\MexComGEPlugins");
			if(!IsDirectory(Path))
			{
				if(mkdir(Path.c_str())!=0)
				{
					Path.clear();
				}
			}
		}
		else
		{
			Path.clear();
		}

		// Add the filename only if it exists
		if(!Path.empty())
		{
			Path.append("\\Cache");
			g_Env.CacheFilename=Path;
		}
	}

	// Save the cache filename
	if(!g_Env.CacheFilename.empty())
	{
		RegSetValueEx(Key, "CacheFilename", NULL, REG_SZ, \
			(unsigned char*)g_Env.CacheFilename.c_str(), \
			(unsigned long)g_Env.CacheFilename.size()+1);
	}

	// Set flush cache to false
	unsigned long FlushValue=0;
	RegSetValueEx(Key, "FlushCache", NULL, REG_DWORD, (unsigned char*)&FlushValue, \
		sizeof(FlushValue));

	// Okay, by this point we should have all our variables, so let's make sure
	if(g_Env.JreBinary.empty())
	{
		MessageBox(0, "Unable to find a version of Java that is usable.", "GEPlugins Error", MB_ICONSTOP);
		g_Env.Initialized=false;
		return false;
	}
	if(g_Env.GEJarFilename.empty())
	{
		MessageBox(0, "Unable to find Game Extractor's JAR file.", "GEPlugins Error", MB_ICONSTOP);
		g_Env.Initialized=false;
		return false;
	}

	// TODO: Load the cache if available and up to date
	// If the cache variable is empty then simply don't use a cache
	g_Env.FlushCache=true;

	// Find all plugins and save the cache otherwise
	if(g_Env.FlushCache)
	{
		// Create the instance
		g_Env.Cache=new geCache;

		// Search for plugins
		std::vector<std::string> ClassNames;
		//FindPlugins(g_Env.GEJarFilename, ClassNames);
		FindPlugins(g_Env.GEPluginPath, ClassNames);

		// Make sure the Java VM is loaded
		if(!InitializeJavaVM())
		{
			MessageBox(0, "Unable to load the Java Virtual Machine.", "GEPlugins Error", MB_ICONSTOP);
			delete g_Env.Cache;
			g_Env.Cache=NULL;
			g_Env.Initialized=false;
			return false;
		}

		// Get information about all of the plugins
		for(std::vector<std::string>::const_iterator Iter=ClassNames.begin();Iter!=ClassNames.end();++Iter)
		{
			RetrievePluginInfo(*Iter, *g_Env.Cache);
		}

		// TODO: Temporary; we might not even need a cache
		g_Env.Cache->Save(g_Env.CacheFilename);

		/*
		// Test a class!
		gePlugin TestPlugin(g_Env.Env, "Plugin_U_Generic");
		if(!TestPlugin.IsOkay())
		{
			MessageBox(0, "Not okay!", "Error", MB_ICONSTOP);
		}
		else
		{
			int MatchRating;
			geArchive* Archive;
			std::string Filename="C:\\Program Files\\Ubi Soft\\Splinter Cell\\Sounds\\Special.uax";
			MatchRating=TestPlugin.GetMatchRating(Filename);
			Archive=TestPlugin.Read(Filename);
			if(Archive)
			{
				// Do stuff with it
				unsigned long FileCount;
				//FileCount=Archive->GetResourceCount();
				//MessageBox(0, Archive->GetResource(5).GetName().c_str(), "", 0);
				for(unsigned long i=0;i<Archive->GetResourceCount();i++)
				{
					OutputDebugString(Archive->GetResource(i).GetName().c_str());
					OutputDebugString("\r\n");
				}
				//unsigned long long Length;
				//Length=Archive->GetResource(0).GetDecompressedLength();
				//Archive->GetResource(0).Extract("C:\\DELETE\\");

				// Delete it
				delete Archive;
				Archive=NULL;
			}
		}
		*/
	}

	// Close the key
	if(Key)
	{
		RegCloseKey(Key);
	}

	g_Env.Initialized=true;
	return true;
}

void UninitializeEnvironment()
{
	// Make sure it's already initialized
	if(!g_Env.Initialized)
	{
		return;
	}

	// Delete the cache
	delete g_Env.Cache;
	g_Env.Cache=NULL;

	// Do not destroy the Java VM because MexCom is really stupid in that it
	// loads this plugin and frees it many times, and we can't create a new JVM
	// after we have already destroyed one

	/*if(g_Env.Jvm)
	{
		g_Env.Jvm->DestroyJavaVM();
		g_Env.Jvm=NULL;
		g_Env.Env=NULL;
	}
	if(g_Env.JvmBinaryHandle)
	{
		FreeLibrary(g_Env.JvmBinaryHandle);
		g_Env.JvmBinaryHandle=NULL;
	}*/

	g_Env.Initialized=false;
	return;
}

typedef jint (JNICALL *TJNI_GetDefaultJavaVMInitArgs)(void *args);
typedef jint (JNICALL *TJNI_CreateJavaVM)(JavaVM **pvm, void **penv, void *args);
typedef jint (JNICALL *TJNI_GetCreatedJavaVMs)(JavaVM **vmBuf, jsize bufLen, jsize *nVMs);

bool InitializeJavaVM()
{
	// Make sure we aren't already initialized
	if(g_Env.Jvm)
	{
		return true;
	}

	// Make sure there's a valid path
	if(g_Env.JreBinary.empty())
	{
		return false;
	}

	// Load the library
	g_Env.JvmBinaryHandle=LoadLibrary(g_Env.JreBinary.c_str());
	if(!g_Env.JvmBinaryHandle)
	{
		return false;
	}

	// Find three functions that are required
	TJNI_GetDefaultJavaVMInitArgs GetDefaultJavaVMInitArgs;
	TJNI_CreateJavaVM CreateJavaVM;
	TJNI_GetCreatedJavaVMs GetCreatedJavaVMs;
	GetDefaultJavaVMInitArgs=(TJNI_GetDefaultJavaVMInitArgs)GetProcAddress(g_Env.JvmBinaryHandle, "JNI_GetDefaultJavaVMInitArgs");
	CreateJavaVM=(TJNI_CreateJavaVM)GetProcAddress(g_Env.JvmBinaryHandle, "JNI_CreateJavaVM");
	GetCreatedJavaVMs=(TJNI_GetCreatedJavaVMs)GetProcAddress(g_Env.JvmBinaryHandle, "JNI_GetCreatedJavaVMs");
	if(!GetDefaultJavaVMInitArgs || !CreateJavaVM || !GetCreatedJavaVMs)
	{
		FreeLibrary(g_Env.JvmBinaryHandle);
		g_Env.JvmBinaryHandle=NULL;
		return false;
	}

	// See if we created any JVMs already
	jsize nVMs;
	GetCreatedJavaVMs(&g_Env.Jvm, 1, &nVMs);
	if(g_Env.Jvm && nVMs)
	{
		// Get the environment for the already created JVM
		g_Env.Jvm->GetEnv((void**)&g_Env.Env, JNI_VERSION_1_6);
		if(!g_Env.Env)
		{
			return false;
		}
		return true;
	}

	// Initialize the arguments for the JVM
	JavaVMInitArgs VmArgs;
	memset(&VmArgs, 0, sizeof(VmArgs));
	VmArgs.version=JNI_VERSION_1_6;
	if(GetDefaultJavaVMInitArgs(&VmArgs)!=JNI_OK)
	{
		return false;
	}

	// Create the class path
	std::string ClassPath;
	ClassPath.append(g_Env.GEJarFilename);
	ClassPath.append(";");
	ClassPath.append(g_Env.GEPluginPath);

	// Set some options
	VmArgs.nOptions=1;
	VmArgs.options=(JavaVMOption*)calloc(VmArgs.nOptions, sizeof(JavaVMOption));
	VmArgs.options[0].optionString=(char*)calloc(24+ClassPath.size(), sizeof(char));
	_snprintf(VmArgs.options[0].optionString, 24+ClassPath.size(), "-Djava.class.path=%s", ClassPath.c_str());

	// Create the VM
	CreateJavaVM(&g_Env.Jvm, (void**)&g_Env.Env, &VmArgs);
	if(!g_Env.Jvm || !g_Env.Env)
	{
		return false;
	}

	// Override any Game Extractor classes
	jclass Settings;
	Settings=g_Env.Env->DefineClass("org/watto/Settings", NULL, (jbyte*)g_SettingsClass, \
		sizeof(g_SettingsClass));
	if(!Settings)
	{
		return false;
	}
	return true;
}

void RetrievePluginInfo(std::string PluginName, geCache& Cache)
{
	// Make sure we're initialized
	if(!g_Env.Jvm || !g_Env.Env)
	{
		return;
	}

	// Variables
	std::vector<std::string> Extentions;
	std::vector<std::string> Games;

	// Get the info from the plugin
	gePlugin Plugin(g_Env.Env, PluginName);
	if(!Plugin.IsOkay())
	{
		return;
	}
	Plugin.GetExtentions(Extentions);
	Plugin.GetGames(Games);

	// Go through the permutations of games and extentions
	for(std::vector<std::string>::const_iterator Iter=Games.begin();Iter!=Games.end();++Iter)
	{
		for(std::vector<std::string>::const_iterator Iter2=Extentions.begin();Iter2!=Extentions.end();++Iter2)
		{
			geCache::gePluginInfo Info;
			Info.Class=PluginName;
			Info.GameName=*Iter;
			Info.Extentions.clear();
			Info.Extentions.push_back(*Iter2);
			Cache.Add(Info);
		}
	}
	return;
}

bool IsFile(const std::string& Filename)
{
	unsigned long Attributes;
	Attributes=GetFileAttributes(Filename.c_str());
	if(Attributes==INVALID_FILE_ATTRIBUTES || (Attributes & FILE_ATTRIBUTE_DIRECTORY))
	{
		return false;
	}
	return true;
}

bool IsDirectory(const std::string& Path)
{
	unsigned long Attributes;
	Attributes=GetFileAttributes(Path.c_str());
	if(Attributes==INVALID_FILE_ATTRIBUTES || !(Attributes & FILE_ATTRIBUTE_DIRECTORY))
	{
		return false;
	}
	return true;
}

bool FindPlugins(const std::string& Path, std::vector<std::string>& ClassNames)
{
	// Is it a directory or a zip file
	if(IsDirectory(Path))
	{
		// Create a good search
		std::string InputSearch(Path);
		if(InputSearch[InputSearch.size()-1]!='/' && InputSearch[InputSearch.size()-1]!='\\')
		{
			InputSearch.append("\\");
		}
		InputSearch.append("Plugin_*.class");

		// Do the search
		_finddata_t FileInfo;
		intptr_t FindHandle;
		if((FindHandle=_findfirst(InputSearch.c_str(), &FileInfo))!=-1l)
		{
			do
			{
				std::string ClassName(FileInfo.name);
				ClassName=ClassName.substr(0, ClassName.size()-6);
				ClassNames.push_back(ClassName);
			} while(_findnext(FindHandle, &FileInfo)==0);
			_findclose(FindHandle);
		}
	}
	else if(IsFile(Path))
	{
		// Open the Jar file
		unzFile File;
		if(!(File=unzOpen(Path.c_str())))
		{
			return false;
		}

		// Browse the directory
		char Filename[1024];
		unzGoToFirstFile(File);
		do
		{
			// Get the next filename
			memset(Filename, 0, sizeof(Filename));
			unzGetCurrentFileInfo(File, NULL, Filename, sizeof(Filename), NULL, 0, NULL, 0);
			
			// See if this is a plugin filename
			bool IsPlugin=false;
			if(strnicmp(Filename, "Plugin_", 7)==0)
			{
				if(strnicmp(Filename+(strlen(Filename)-6), ".class", 6)==0)
				{
					IsPlugin=true;
				}
			}

			// Get its class name
			if(IsPlugin)
			{
				std::string ClassName(Filename);
				ClassName.replace(ClassName.size()-6, 6, "");
				ClassNames.push_back(ClassName);
			}
		} while(unzGoToNextFile(File)!=UNZ_END_OF_LIST_OF_FILE);

		// Close the Jar file
		unzClose(File);
	}
	else
	{
		return false;
	}
	return true;
}

char* HeapString(const std::string& String)
{
	unsigned long StringLength=(unsigned long)String.length()+1;
	char* StringPtr=(char*)HeapAlloc(GetProcessHeap(), 0, StringLength);
	strncpy(StringPtr, String.c_str(), StringLength);
	return StringPtr;
}
