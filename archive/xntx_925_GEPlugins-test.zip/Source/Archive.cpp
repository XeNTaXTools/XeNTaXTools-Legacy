/*
  Archive.cpp
  A Game Extractor archive
*/

#include "stdafx.h"
#include "Archive.h"

// Constructors
geArchive::geArchive(JNIEnv* Env) :
	m_Env(Env),
	m_Resources(NULL)
{
	// FAIL! Creating archives is not yet supported.
	// TODO: Support creating archives
	return;
}

geArchive::geArchive(JNIEnv* Env, jobjectArray Resources) :
	m_Env(Env),
	m_Resources(Resources)
{
	return;
}

geArchive::~geArchive()
{
	// Unref the resources
	if(m_Env && m_Resources)
	{
		m_Env->DeleteLocalRef(m_Resources);
		m_Resources=NULL;
	}
	return;
}

// General Methods
bool geArchive::IsOkay() const
{
	return m_Env && m_Resources ? true : false;
}

// Management
unsigned long geArchive::GetResourceCount() const
{
	// Make sure we're okay
	if(!IsOkay())
	{
		return 0;
	}

	// Get the number of elements in the array
	unsigned long NumberElements;
	NumberElements=m_Env->GetArrayLength(m_Resources);
	if(m_Env->ExceptionCheck())
	{
		m_Env->ExceptionClear();
		return 0;
	}
	return NumberElements;
}

geResource geArchive::GetResource(unsigned long Index) const
{
	// Make sure we're okay
	if(!IsOkay())
	{
		return geResource(m_Env);
	}

	// Get the array element
	jobject Resource;
	Resource=m_Env->GetObjectArrayElement(m_Resources, Index);
	if(!Resource)
	{
		m_Env->ExceptionClear();
		return geResource(m_Env);
	}
	return geResource(m_Env, Resource);
}

void geArchive::SetResource(unsigned long Index, const geResource& NewResource)
{
	// TODO: Implement function SetResource
	return;
}

