from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Super Robot Wars Z: Jigoku-hen [PS3]", ".bin")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    if bs.readBytes(4) != b'\x01\x05\x00\x00': return 0
    return 1
    
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data, NOE_BIGENDIAN)
    bs.seek(0x4)
    datasize = bs.readUInt()
    bs.readUInt()
    bs.readUInt()
    headerSize = bs.readUInt()
    datasize2 = bs.readUInt()
    bs.readByte()
    numMips = bs.readUByte()
    bs.readByte()
    bs.readByte()
    bs.readInt()
    imgWidth = bs.readUShort()
    imgHeight = bs.readUShort()
    print(imgWidth, "x", imgHeight)
    bs.seek(0x80)
    data = bs.readBytes(datasize)      
    #A8R8G8B8
    data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "a8 r8 g8 b8")
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, noesis.NOESISTEX_RGBA32))
    return 1