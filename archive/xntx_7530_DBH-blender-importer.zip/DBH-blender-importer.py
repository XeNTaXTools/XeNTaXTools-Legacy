import bpy
import bmesh
from math import radians
from mathutils import Vector
from os import system
import os
import re

path = "path-to-file.ascii"

class Importer:
    BLOCK_SIZES = [3, 6, 7, 8, 9]
    HEADER_SIZE = 6
    lines = None
    
    def purify_line(self, pattern, line):
        return pattern.sub('', line)

    def get_vector(self, line):
        if line is None or len(line) == 0 or line.isspace():
            return None
        values = [float(x) for x in line.split()]
        if len(values) < 2:
            return None
        return Vector(values)

    def get_face_indices(self, line):
        if line is None or len(line) == 0 or line.isspace():
            return None
        values = [float(x) for x in line.split()]
        if len(values) < 3:
            return None
        return [int(x) for x in line.split()][::-1]

    def get_polygons(self, submesh_info):
        polygons = []
        for p in range(submesh_info.get('triangles_count')):
            line_id = (submesh_info.get('beginning')+self.HEADER_SIZE) + submesh_info.get('vertices_count')*self.BLOCK_SIZES[submesh_info.get('data_type')] + 1 + p
            polygons.append(self.get_face_indices(self.lines[line_id]))
        return polygons

    def get_submesh_info(self, submesh_offset):
        data_type = int(self.lines[submesh_offset+1])
        submesh_name = self.lines[submesh_offset+3]
        vert_count = int(self.lines[submesh_offset+5])
        tris_count = int(self.lines[(submesh_offset+6)+vert_count*self.BLOCK_SIZES[data_type]])
        print("Reading vert count from line %s: %i" %(submesh_offset+5+1, vert_count))
        print("Reading tris count from line %s: %i" %((submesh_offset+6+1)+vert_count*self.BLOCK_SIZES[data_type], tris_count))
        d = { "submesh_name": submesh_name, "beginning": submesh_offset, "data_type": data_type, "vertices_count": vert_count, "triangles_count": tris_count }
        return d
    
    def extract_block_data(self, submesh_info, index):
        data = { "vertex_coordinates": None, "vertex_normal": None, "vertex_color": None, "uv_coordinates": None }
        line_id = (submesh_info.get('beginning')+self.HEADER_SIZE)+index*self.BLOCK_SIZES[submesh_info.get('data_type')]
        data['vertex_coordinates'] = self.get_vector(self.lines[line_id])
        if submesh_info['data_type'] != 0:
            data['vertex_normal'] = self.get_vector(self.lines[line_id+1])
            data['uv_coordinates'] = self.get_vector(self.lines[line_id+3])
            data['vertex_color'] = self.get_vector(self.lines[line_id+2])
        return data
      
    def set_uv(self, mesh, uv):
        mesh.uv_layers.new()
        values = mesh.uv_layers[0].data.values()
        for p in mesh.polygons:
            for loop_index in p.loop_indices:
                v_id = mesh.loops[loop_index].vertex_index
                values[loop_index].uv = uv[v_id]
    
    def set_tangents(self, mesh, tangents):
        values = mesh.loops
        for l in mesh.loops:
            l.tangent = tangents[l.vertex_index]
    
    def set_vertex_normals(self, mesh, normals):
        for v in mesh.vertices:
            v.normal = normals[v.index]
    
    def set_vertex_colors(self, mesh, colors):
        mesh.vertex_colors.new()
        values = mesh.vertex_colors[0].data.values()
        for p in mesh.polygons:
            for loop_index in p.loop_indices:
                v_id = mesh.loops[loop_index].vertex_index
                values[loop_index].color = [c/255.0 for c in colors[v_id]]
                
    def shade_smooth_object(self, object):
        object.select_set(True)
        bpy.ops.object.shade_smooth()
        object.select_set(False)

    def read_file(self, path):
        # reading raw data
        with open(path, 'r') as file:
            self.lines = file.readlines()
        if len(self.lines) < 2:
            return
        # removing unnessesary
        pattern = re.compile('\n')
        self.lines = [self.purify_line(pattern, x) for x in self.lines]
        # getting info
        submeshes_count = int(self.lines[1])
        print("Expecting %i submeshes" % submeshes_count)
        # begin cycle
        offset_submesh = 2
        for submesh_id in range(submeshes_count):
            submesh_info = self.get_submesh_info(offset_submesh)
            block_size = self.BLOCK_SIZES[submesh_info.get('data_type')]
            blocks_count = submesh_info['vertices_count']
            print("Submesh name: %s,\tdata type: %s, vertices: %i,\ttriangles: %i" %(submesh_info.get('submesh_name'), submesh_info.get('data_type'), submesh_info.get('vertices_count'), submesh_info.get('triangles_count')))
            # creating of mesh and object
            mesh = bpy.data.meshes.new(submesh_info.get('submesh_name'))
            object = bpy.data.objects.new(submesh_info.get('submesh_name'), mesh)
            bpy.context.collection.objects.link(object)
            # extraction of data
            blocks = [self.extract_block_data(submesh_info, x) for x in range(blocks_count)]
            # constructing mesh
            polygons = self.get_polygons(submesh_info)
            mesh.from_pydata([v['vertex_coordinates'] for v in blocks], [], polygons)
            print("0 faces indices: %s\n" %(''.join(str(p)+' ' for p in polygons[:3])))
            if not submesh_info['data_type'] == 0:
                self.set_vertex_normals(mesh, [v['vertex_normal'] for v in blocks])
                self.set_uv(mesh, [v['uv_coordinates'] for v in blocks])
                self.set_vertex_colors(mesh, [v['vertex_color'] for v in blocks])
                mesh.calc_tangents()
            object.rotation_euler = (radians(90.0), 0.0, 0.0)
            self.shade_smooth_object(object)
            # to the next submesh!
            offset_submesh += self.HEADER_SIZE + submesh_info.get('vertices_count') * block_size + submesh_info.get('triangles_count') + 1


if __name__ == "__main__":
    system('cls')
    importer = Importer()
    importer.read_file(path)
