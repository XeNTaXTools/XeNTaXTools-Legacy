#Deadly Premonition
from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Deadly Premonition XMD", ".xmd")
	noesis.setHandlerTypeCheck(handle, xmdCheckType)
	noesis.setHandlerLoadModel(handle, xmdLoadModel)

	handle = noesis.register("Deadly Premonition XPC", ".xpc")
	noesis.setHandlerTypeCheck(handle, xpcCheckType)
	noesis.setHandlerLoadRGBA(handle, xpcLoadRGBA)
	#noesis.logPopup()

	return 1


def xmdCheckType(data):
	td = NoeBitStream(data)
	if td.readUInt() != 0x31505A58:
		return 0
	return 1

def xpcCheckType(data):
	td = NoeBitStream(data)
	if td.readUInt() != 0x32435058:
		return 0
	return 1

class xmdFile: 
         
	def __init__(self, bs):
		self.bs = bs
		self.texList  = []
		self.matList  = [] 
		self.boneList = []
		self.boneMap  = []
		self.offsetList = []
		self.meshOffsets = []

	def loadAll(self, bs):
		XMD3, totalSize, self.totalFaceCount, self.totalVertCount, count3 = bs.readUInt(), bs.readUInt(), bs.readUInt(), bs.readUInt(), bs.readUInt()
		bs.seek(0x14, NOESEEK_REL)
		self.meshNameCount, self.boneCount, self.meshPartCount = bs.readUShort(), bs.readUShort(), bs.readUInt()
		bs.seek(0x7, NOESEEK_REL)
		self.unkCount = bs.readUShort()
		bs.seek(0x21, NOESEEK_REL)
		self.bonePalletCount = bs.readUShort()
		bs.seek(0x8, NOESEEK_REL)
		self.nameOffset, self.boneOffset, self.meshOffset = bs.readUInt(), bs.readUInt(), bs.readUInt()
		bs.seek(0x8, NOESEEK_REL)
		self.firstOffset = bs.readUInt()
		bs.seek(0x10, NOESEEK_REL)
		self.faceOffset, self.vertOffset, self.vert2Offset = bs.readUInt(), bs.readUInt(), bs.readUInt()
		bs.seek(0x10, NOESEEK_REL)
		self.bonePalletOffset = bs.readUInt()
		self.loadMeshNames(bs)
		self.loadBones(bs)
		self.loadMeshInfo(bs)
		self.loadUnk1(bs)
		self.loadBonePallet(bs)
		self.loadTex()
		self.loadMatInfo(bs)
		self.loadMeshs(bs)

	def loadMeshNames(self, bs):
		self.meshNames = []
		bs.seek(self.nameOffset, NOESEEK_ABS)
		for a in range(0, self.meshNameCount):
			self.meshNames.append(bs.readBytes(0x10).decode("ASCII").rstrip("\0"))
		
	def loadBones(self, bs):
		bs.seek(self.boneOffset, NOESEEK_ABS)
		for a in range(0, self.boneCount):
			boneName       = bs.readBytes(0xF).decode("ASCII").rstrip("\0")
			boneParent     = bs.readUByte()
			boneMtxLocal   = NoeMat44.fromBytes(bs.readBytes(64)).toMat43()
			boneMtxInverse = NoeMat44.fromBytes(bs.readBytes(64)).toMat43().inverse()
			newBone = NoeBone(a, boneName, boneMtxLocal, None, boneParent)
			self.boneList.append(newBone)
		self.boneList = rapi.multiplyBones(self.boneList)

	def loadMeshInfo(self, bs):
		self.meshInfo = []
		bs.seek(self.meshOffset, NOESEEK_ABS)
		for a in range(0, self.meshPartCount):
			meshName = bs.readBytes(0xE).decode("ASCII").rstrip("\0")
			matID = bs.readUByte()
			bs.seek(0xD, NOESEEK_REL)
			boundingBoxMin = NoeVec3.fromBytes(bs.readBytes(12))
			boundingBoxMax = NoeVec3.fromBytes(bs.readBytes(12))
			faceStart, vertStart, faceCount, vertCount = bs.readUInt(), bs.readUInt(), bs.readUInt(), bs.readUInt()
			boneMap, unk2 = bs.readUByte(), bs.readUByte()
			bs.seek(0xA, NOESEEK_REL)
			self.meshInfo.append([meshName, faceStart, vertStart, faceCount, vertCount, boneMap, matID])

	def loadUnk1(self, bs):
		bs.seek(self.firstOffset, NOESEEK_ABS)
		for a in range(0, self.unkCount):
			bs.seek(0x30, NOESEEK_REL)

	def loadBonePallet(self, bs):
		bs.seek(self.bonePalletOffset, NOESEEK_ABS)
		for a in range(0, self.bonePalletCount):
			start, count = bs.readUShort(), bs.readUShort()
			self.boneMap.append(bs.read("B" * count))
			bs.seek((0x4C - count), NOESEEK_REL)

	def loadTex(self): 
		folderName = rapi.getDirForFilePath(rapi.getInputName())
		baseName = rapi.getExtensionlessName(rapi.getLocalFileName(rapi.getInputName()))
		texFile = folderName + baseName + ".xpc"
		if (rapi.checkFileExists(texFile)):
			texData = rapi.loadIntoByteArray(texFile)
			xpcLoadRGBA(texData, self.texList)

	def loadMatInfo(self, bs):
		matCount = (len(self.texList) // 5)
		for a in range(0, matCount):
			texbase = 5 * a
			matName = rapi.getExtensionlessName(rapi.getLocalFileName(rapi.getInputName()))
			material = NoeMaterial("Material_" + matName + str(a), "")
			if self.texList[texbase].name != "BLANK":
				material.setTexture(self.texList[texbase].name)
			if self.texList[texbase + 1].name != "BLANK":
				material.setNormalTexture(self.texList[texbase + 1].name)
			#if self.texList[texbase + 2].name != "BLANK":
			#	material.setSpecularTexture(self.texList[texbase + 2].name)
			#print(self.texList[texbase + 3].name)
			#print(self.texList[texbase + 4].name)
			self.matList.append(material)

	def loadMeshs(self, bs):
		bs.seek(self.faceOffset, NOESEEK_ABS)
		totalFaceBuff = bs.readBytes(2 * self.totalFaceCount)
		bs.seek(self.vertOffset, NOESEEK_ABS)
		totalVertBuff = bs.readBytes(0x14 * self.totalVertCount)
		bs.seek(self.vert2Offset, NOESEEK_ABS)
		totalVert2Buff = bs.readBytes(0xC * self.totalVertCount)
		for a in range(0, self.meshPartCount):
			indexList = []
			weightList = []
			faceBuff = totalFaceBuff[self.meshInfo[a][3] * 2:(self.meshInfo[a][3] * 2) + (self.meshInfo[a][1] * 2)]
			vertBuff = totalVertBuff[self.meshInfo[a][4] * 20:(self.meshInfo[a][4] * 20) + (self.meshInfo[a][2] * 20)]
			normBuff = totalVert2Buff[self.meshInfo[a][4] * 12:(self.meshInfo[a][4] * 12) + (self.meshInfo[a][2] * 12)]
			rapi.rpgSetName(self.meshInfo[a][0])
			rapi.rpgSetMaterial(self.matList[self.meshInfo[a][6]].name)
			rapi.rpgSetBoneMap(self.boneMap[self.meshInfo[a][5]])
			tm = NoeBitStream(vertBuff)
			for b in range(0, self.meshInfo[a][2]):
				tm.seek(12, NOESEEK_REL)
				i1 = tm.readUByte();i2 = tm.readUByte();i3 = tm.readUByte();i4 = tm.readUByte()
				w1 = tm.readUByte();w2 = tm.readUByte();w3 = tm.readUByte();w4 = tm.readUByte()
				if w1 != 0:
					indexList.append(i1); weightList.append(w1)
				else:
					indexList.append(0); weightList.append(0)
				if w2 != 0:
					indexList.append(i2); weightList.append(w2)
				else:
					indexList.append(0); weightList.append(0)
				if w3 != 0:
					indexList.append(i3); weightList.append(w3)
				else:
					indexList.append(0); weightList.append(0)
				if w4 != 0:
					indexList.append(i4); weightList.append(w4)
				else:
					indexList.append(0); weightList.append(0)
			weightBuff = struct.pack('B'*len(indexList), *indexList)
			indexBuff  = struct.pack('B'*len(indexList), *indexList)
			rapi.rpgBindPositionBufferOfs(vertBuff, noesis.RPGEODATA_HALFFLOAT, 20, 0)
			#rapi.rpgBindNormalBufferOfs(normBuff, noesis.RPGEODATA_FLOAT, 12, 0)
			rapi.rpgBindUV1BufferOfs(vertBuff, noesis.RPGEODATA_HALFFLOAT, 20, 8)
			rapi.rpgBindBoneIndexBuffer(indexBuff, noesis.RPGEODATA_UBYTE, 4, 4)
			rapi.rpgBindBoneWeightBuffer(weightBuff, noesis.RPGEODATA_UBYTE, 4, 4)
			
			rapi.rpgCommitTriangles(faceBuff, noesis.RPGEODATA_USHORT, self.meshInfo[a][1], noesis.RPGEO_TRIANGLE_STRIP, 1)

def xmdLoadModel(data, mdlList):
	ctx = rapi.rpgCreateContext()
	cmpData = data[0x10:(len(data))]
	decompData = rapi.decompInflate(cmpData, rapi.getInflatedSize(cmpData))
	xmd = xmdFile(NoeBitStream(decompData))
	xmd.loadAll(xmd.bs)
	try:
		mdl = rapi.rpgConstructModel()
	except:
		mdl = NoeModel()
	mdl.setModelMaterials(NoeModelMaterials(xmd.texList, xmd.matList))
	mdlList.append(mdl); mdl.setBones(xmd.boneList)	
	return 1


def xpcLoadRGBA(data, texList):
	td = NoeBitStream(data)
	magic, fsize = td.readUInt(), td.readUInt()
	texCount, matCount, usedTex = td.readUShort(), td.readUShort(), td.readUInt()
	#print(magic, fsize)
	#print(texCount, matCount, usedTex)
	td.seek(0x20, NOESEEK_ABS)
	matStart, dataStart = td.readUInt(), td.readUInt()
	td.seek(matStart, NOESEEK_ABS)
	for a in range(0, matCount):
		for b in range(0, usedTex):
			texName = rapi.getExtensionlessName(td.readBytes(0x10).decode("ASCII").rstrip("\0"))
			offset, zsize, type, size = td.readUInt(), td.readUInt(), td.readUInt(), td.readUInt() // 256
			#print(texName, offset, zsize, type, size)
			cmpData = data[offset:(offset + zsize)]
			if offset != 0:
				decompData = rapi.decompInflate(cmpData, size)
				tex = NoeBitStream(decompData)
				tex.seek(12, NOESEEK_ABS)
				width, height = tex.readUInt(), tex.readUInt()
				tex.seek(84, NOESEEK_ABS)
				type = tex.readUInt()
				texFmt = noesis.NOESISTEX_DXT1
				#print(type)
				if type == 0x31545844:
					texFmt = noesis.NOESISTEX_DXT1
				elif type == 0x33545844:
					texFmt = noesis.NOESISTEX_DXT3
				elif type == 0x35545844:
					texFmt = noesis.NOESISTEX_DXT5
				texList.append(NoeTexture(texName, height, width, decompData[0x80:len(decompData)], texFmt))
			else:
				texList.append(NoeTexture("BLANK", 1, 1, decompData[0:8], noesis.NOESISTEX_DXT1))
	return 1