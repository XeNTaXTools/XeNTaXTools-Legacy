infogram UWP dumper 1.0

Usage:
This dumper should work with any current UWP game as of Sept 2016, to use this you'll need to take ownership (http://www.tenforums.com/tutorials/3841-take-ownership-add-context-menu-windows-10-a.html) of the following files:
- %LOCALAPPDATA%\Packages
- %LOCALAPPDATA%\Packages\[AppPackageID]
- %LOCALAPPDATA%\Packages\[AppPackageID]\TempState

(example AppPackageIDs are Microsoft.OpusPG_8wekyb3d8bbwe or Microsoft.Halo5Forge_8wekyb3d8bbwe)

Once injected the DLL should start copying the decrypted game files to %LOCALAPPDATA%\Packages\[AppPackageID]\TempState\dumped, it'll probably take a little while.