# Super Robot OG Infinite Battle
# Noesis script by Dave, 2021

from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Super Robot OG Infinite Battle",".bin")
	noesis.setHandlerTypeCheck(handle, bcCheckType)
	noesis.setHandlerLoadModel(handle, bcLoadModel)
	return 1

# Check file type

def bcCheckType(data):
	bs = NoeBitStream(data)
	file_id = bs.readBytes(6).decode("utf-8")

	if file_id == "BFMDLH":
		return 1
	else:
		return 0


# Read the model data

def bcLoadModel(data, mdlList):
	bs = NoeBitStream(data, NOE_BIGENDIAN)
	ctx = rapi.rpgCreateContext()

	curr_folder = rapi.getDirForFilePath(rapi.getInputName()).lower()
	curr_file = rapi.getLocalFileName(rapi.getInputName()).lower()
	basename = curr_file.split("_model.bin")[0]

	vf = NoeBitStream(rapi.loadIntoByteArray(curr_folder + basename + "_vertex.bin"), NOE_BIGENDIAN)
	tf = NoeBitStream(rapi.loadIntoByteArray(curr_folder + basename + "_texture.bin"), NOE_BIGENDIAN)

	tex_list, mat_list = LoadTextures(tf, bs)

	bs.seek(0x3c)
	mesh_table = bs.readUInt()
	bs.seek(0xa4)
	mesh_count = bs.readUInt()
	submesh_count = bs.readUInt()

	bs.seek(0x44)
	submesh_table = bs.readUInt()

	for a in range(mesh_count):
		bs.seek(mesh_table + (a * 0x40) + 0x14)
		sub_start = bs.readUShort()
		sub_count = bs.readUShort()

		for s in range(sub_count):
			bs.seek(submesh_table + ((sub_start + s) * 0x90) + 0x38)
			face_count = bs.readUShort()
			vert_count = bs.readUShort()
			vert_stride = bs.readUByte()
			mat_num = bs.readUByte()
			junk = bs.readBytes(2)
			face_data = bs.readUInt()
			vert_data = bs.readUInt()
			mesh_name = "Mesh_" + str(a) + "_" + str(s)
			DrawMesh(vf, vert_data, face_data, vert_count, face_count, vert_stride, mesh_name, mat_num)


	mdl = rapi.rpgConstructModel()
	mdl.setModelMaterials(NoeModelMaterials(tex_list, mat_list))
	mdlList.append(mdl)

	return 1



def DrawMesh(vf, vert_data, face_data, vcount, fcount, stride, mesh_name, mat_num,):
	vertices = bytearray(vcount * 12)
	uvs = bytearray(vcount * 8)
	normals = bytearray(vcount * 12)
	faces = bytearray(fcount * 6)
	bone_idx = bytearray(vcount * 8)

	vf.seek(vert_data)

	for v in range(vcount):
		vx = vf.readHalfFloat()
		vy = vf.readHalfFloat()
		vz = vf.readHalfFloat()

		if stride == 20:
			vf.readUShort()

		if stride == 22:
			vf.readUInt()

		uvx = vf.readHalfFloat()
		uvy = vf.readHalfFloat()
		nx = vf.readHalfFloat()
		ny = vf.readHalfFloat()
		nz = vf.readHalfFloat()
		vf.readBytes(2)
		struct.pack_into("<fff", vertices, v * 12, vx, vy, vz)
		struct.pack_into("<ff", uvs, v * 8, uvx, uvy)
		struct.pack_into("<fff", normals, v * 12, nx, ny, nz)

	vf.seek(face_data)

	for f in range(fcount * 3):
		fnum = vf.readUShort()
		struct.pack_into("<H", faces, f * 2, fnum)

	rapi.rpgSetName(mesh_name)
	rapi.rpgSetMaterial("Material_" + str(mat_num))
	rapi.rpgBindPositionBuffer(vertices, noesis.RPGEODATA_FLOAT, 12)
#	rapi.rpgBindNormalBuffer(normals, noesis.RPGEODATA_FLOAT, 12)
	rapi.rpgBindUV1Buffer(uvs, noesis.RPGEODATA_FLOAT, 8)
	rapi.rpgCommitTriangles(faces, noesis.RPGEODATA_USHORT, fcount * 3, noesis.RPGEO_TRIANGLE, 1)
	rapi.rpgClearBufferBinds()

	return 1


# Create material and texture lists

def LoadTextures(tf, bs):
	tex_list = []
	mat_list = []

	bs.seek(0x54)
	tex_table = bs.readUInt()
	bs.seek(0x74)
	mat_table = bs.readUInt()
	bs.seek(0xb8)
	mat_count = bs.readUInt()
	tex_count = bs.readUInt()

	for t in range(tex_count):
		bs.seek(tex_table + (t * 0x10))
		tex_start = bs.readUInt()
		tex_size = bs.readUInt()

		if tex_size > 0:
			tf.seek(tex_start + 0x20)
			width = tf.readUShort()
			height = tf.readUShort()
			tf.seek(tex_start + 0x80)
			raw_image = tf.readBytes(tex_size - 0x80)
			tex = NoeTexture("Texture_" + str(t), width, height, raw_image, noesis.NOESISTEX_DXT1)
			tex_list.append(tex)

	for m in range(mat_count):
		mat_offset = mat_table + (m * 0x210)
		bs.seek(mat_offset + 0x10)
		diffuse_tex = bs.readShort()
		bs.seek(mat_offset + 0x30)
		normal_tex = bs.readShort()
		bs.seek(mat_offset + 0x50)
		spec_tex = bs.readShort()
		bs.seek(mat_offset + 0x70)
		other_tex = bs.readShort()

		material = NoeMaterial("Material_" + str(m), "Texture_" + str(diffuse_tex))

		if normal_tex != -1:
			material.setNormalTexture("Texture_" + str(normal_tex))
		if spec_tex != -1:
			material.setSpecularTexture("Texture_" + str(spec_tex))
		if other_tex != -1:
			material.setOpacityTexture("Texture_" + str(other_tex))

		mat_list.append(material)

	return tex_list, mat_list



