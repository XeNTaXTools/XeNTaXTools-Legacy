from struct import Struct
from io import FileIO, BytesIO
from os import SEEK_SET, SEEK_CUR, SEEK_END
from array import array
import os.path
from collections import namedtuple

try:
    from .bintools import BinFile, BinBytes
    from . import tex_db
except ValueError:
    from bintools import BinFile, BinBytes
    import tex_db

def do_import(context, filepath):
    dirname, basename = os.path.split(filepath)
    base, ext = os.path.splitext(basename)
    tex_db_path = os.path.join(dirname, 'tex_db.bin')

    texname_map = tex_db.get(tex_db_path)

    f = BinFile(filepath)

    magic = f.int()
    obj_cnt = f.int()
    unk1 = f.int()
    obj_pptr = f.int()
    bone_pptr = f.int()
    obj_name_pptr = f.int()
    unk2_ptr = f.int()
    txp_arr = f.int()
    txp_count = f.int()

    unk2_val = f.int(1, unk2_ptr)[0]

    raw_txparr = f.int(txp_count, txp_arr)

    texfile_map = {}
    texbase = base.replace('_obj', '_tex')

    for i, tex_id in enumerate(raw_txparr):
        texfile_map[tex_id] = os.path.join(dirname, texbase + '_' + str(i))

    obj_name_ptrs = f.int(obj_cnt, obj_name_pptr)

    obj_names = [f.nstr(ptr) for ptr in obj_name_ptrs]

    obj_ptrs = f.int(obj_cnt, obj_pptr)
    bone_ptrs = f.int(obj_cnt, bone_pptr)

    arms = [Armature(f, ptr) for ptr in bone_ptrs if ptr != 0]
    objs = [Obj(f, ptr, name, texname_map) for ptr, name in zip(obj_ptrs,obj_names) if ptr != 0]

    return (objs, arms, texfile_map, f)

class ArmUnk:
    def __init__(s, f, base, arm):
        f.seek(base)
        s.base = base

        s.count1 = f.int()
        s.count2 = f.int()
        s.count3 = f.int()

        s.ptr1 = f.int()
        s.ptr2 = f.int()
        s.ptr3 = f.int()

        s.count4 = f.int()
        s.ptr4 = f.int()
        s.ptr5 = f.int()

        s.ptr1_data = f.struct('3f', s.count2, s.ptr1)

        s.ptr2_ptrs = f.int(s.count1, s.ptr2)
        s.ptr2_names = [f.nstr(ptr) for ptr in s.ptr2_ptrs]

        st_ptrpair = Struct('< 2I')

        s.ptr3_ptrs = []
        f.seek(s.ptr3)
        p = f.struct(st_ptrpair)
        while p[0] and p[1]:
            s.ptr3_ptrs.append(p)
            p = f.struct(st_ptrpair)

        s.ptr4_ptrs = f.int(s.count4, s.ptr4)
        s.ptr4_names = [f.nstr(ptr) for ptr in s.ptr4_ptrs]

        st_ptr5 = Struct('< 2I 1f')
        f.seek(s.ptr5)
        s.ptr5_data = []

        tmp = f.struct(st_ptr5)
        while tmp[0] and tmp[1] and tmp[2]:
            s.ptr5_data.append(tmp)
            tmp = f.struct(st_ptr5)

        s.ptr5_data2 = []
        for x in s.ptr5_data:
            r1 = arm.bid_name.get(x[0],x[0])
            r2 = arm.bid_name.get(x[1],x[1])
            r3 = x[2]
            s.ptr5_data2.append((r1,r2,r3))

        s.ptr3_data = []
        exps = s.exps = []
        osgs = s.osgs = []
        Osg = namedtuple('Osg', 'parent, c_child, e_child, c_child_bid, '
                ' e_child_bid, vec, vecs, matrix, child_count')
        Exp = namedtuple('Exp', 'parent, child, exprs, vecs')

        for i,j in s.ptr3_ptrs:
            str1 = f.nstr(i)
            if str1 == 'EXP':
                f.seek(j)
                sptrs = []
                sptrs.append(f.int())
                ff = f.struct('3f', 3)
                sptrs.append(f.int())
                count = f.int()
                sptrs.extend(f.int(count))
                strs = [f.nstr(p) for p in sptrs]

                ret = Exp(parent=strs[0], child=strs[1], exprs=strs[2:], vecs=ff)
                s.ptr3_data.append(ret)
                s.exps.append(ret)
            elif str1 == 'OSG':
                f.seek(j)
                sptr = f.int()
                ff = f.struct('3f', 3)
                ptr1_ref = f.int()
                unk1 = f.int()
                ptr4_ref1 = f.int()
                ptr4_ref2 = f.int()
                mtx_ptr = f.int()
                pstr = f.nstr(sptr)
                matrix = f.struct('4f',4,mtx_ptr)
                ff2 = s.ptr1_data[ptr1_ref]
                str2 = s.ptr4_names[ptr4_ref1 & 0x00FF]
                str3 = s.ptr4_names[ptr4_ref2 & 0x00FF]
                ret = Osg(parent=pstr, c_child=str2, e_child=str3,
                          c_child_bid=ptr4_ref1,
                          e_child_bid=ptr4_ref2, vec=ff2,
                          vecs=ff, matrix=matrix,
                          child_count=unk1)
                s.ptr3_data.append(ret)
                s.osgs.append(ret)
            else:
                pass

        s.child_parent = child_parent = {}

        for e in exps:
            child_parent[e.child] = e.parent

        for o in osgs:
            start = o.c_child_bid & 0x00FF
            stop = o.e_child_bid & 0x00FF

            children = [o.parent]
            children.extend(s.ptr4_names[start+1:stop])
            children.append(o.e_child)

            for i in range(len(children)-1):
                p = children[i]
                c = children[i+1]
                child_parent[c] = p

        for c,p in child_parent.items():
            LIMIT = 100
            count = 0
            parent = p
            while parent and not(parent in arm.name_bid) and count < LIMIT:
                count += 1
                parent = child_parent.get(parent)
            
            if count >= LIMIT:
                pass
            elif parent:
                if parent != p:
                    child_parent[c] = parent
            else:
                pass

class Armature:
    def __init__(s, f, base):
        f.seek(base)
        s.base = base

        s.chain_arr = f.int()
        s.mtx_arr = f.int()
        s.name_pptr = f.int()
        s.unk_ptr = f.int()
        s.count = f.int()


        st_matrix = Struct('< 16f')
        s.bids = f.int(s.count, s.chain_arr)
        matrices_raw = f.struct(st_matrix, s.count, s.mtx_arr)
        s.matrices = [(m[0:4],m[4:8],m[8:12],m[12:16]) for m in matrices_raw]
        s.name_ptrs = f.int(s.count, s.name_pptr)

        s.names = []
        for ptr in s.name_ptrs:
            s.names.append(f.nstr(ptr))

        s.bid_name = dict(zip(s.bids,s.names))
        s.name_bid = dict(zip(s.names,s.bids))

        if s.unk_ptr != 0:
            s.unk = ArmUnk(f, s.unk_ptr, s)
        else:
            s.unk = None

class Obj:
    def __init__(self, file, base, name, texname_map):
        s = self
        f = s.file = file
        s.base = base
        s.name = name

        s.unk = []
        f.seek(base)
        s.unk.append(f.int(2))
        s.unk.append(f.float(4))
        hdr = f.int(4)

        mesh_size = 216
        mesh_cnt = hdr[0]
        mesh_arr = hdr[1]

        mat_size = 1200
        mat_cnt = hdr[2]
        mat_arr = hdr[3]

        s.meshes = s._make_stuff(f, base, mesh_cnt, mesh_arr, mesh_size, Mesh)
        s.mats = s._make_stuff(f, base, mat_cnt, mat_arr, mat_size, Material)

        for mat in s.mats:
            mat.make_textures(texname_map)

        face_sec_size = 92
        st_vert = Struct('< 3f')
        st_vnorm = st_vert
        st_vcol = Struct('< 3f 4x')
        st_weight = Struct('< 4f')
        st_boneid = Struct('< 4f')
        st_uv = Struct('< 2f')

        for mesh in s.meshes:
            mesh.face_sections = s._make_stuff(f, base, mesh.face_sec_cnt,
                    mesh.face_sec_arr, face_sec_size, FaceSection)
            for fc in mesh.face_sections:
                fc.faces = fc.make_faces(f, base)
                fc.get_lookups(f,base)

            mesh.verts = f.struct(st_vert, mesh.vert_cnt, base + mesh.vert_arr)

            raw_vcols = f.struct(st_vcol, mesh.vcol_cnt, base + mesh.vcol_arr)

            mesh.vcols = []
            for vc in raw_vcols:
                mesh.vcols.append([abs(x) for x in vc])

            mesh.vnorms = f.struct(st_vnorm, mesh.vnorm_cnt, base + mesh.vnorm_arr)
            mesh.weights = f.struct(st_weight, mesh.weight_cnt, base + mesh.weight_arr)
            raw_boneids = f.struct(st_boneid, mesh.boneid_cnt, base + mesh.boneid_arr)

            mesh.boneids = []

            for bid4 in raw_boneids:
                mesh.boneids.append([int(x/3) for x in bid4])

            raw_uvs = f.struct(st_uv, mesh.uv_cnt, base + mesh.uv_arr)

            mesh.uvs = []
            for uv in raw_uvs:
                mesh.uvs.append((uv[0], (uv[1]*-1)+1))


    def _make_stuff(s, f, base, cnt, ptr, size, class_):
        ret = []
        for i in range(cnt):
            data = bytearray(size)
            f.seek(base + ptr + i * size)
            n = f.readinto(data)
            assert n == size
            ret.append(class_(data))
        return ret

class Mesh:
    def __init__(s, data):
        d = BinBytes(data)
        s.unk = []
        s.unk.append(d.int())
        s.unk.append(d.float(4))

        s.face_sec_cnt = d.int()
        s.face_sec_arr = d.int()

        s.unk.append(d.int(2))

        s.vert_cnt = d.int()
        s.vert_arr = d.int()
        s.vnorm_arr = d.int()
        s.vcol_arr = d.int()

        s.unk.append(d.int())

        s.uv_arr = d.int()

        s.unk.append(d.int(5))
        
        s.weight_arr = d.int()
        s.boneid_arr = d.int()

        s.unk.append(d.int(16))

        s.name = d.fstr(64)

        s.vnorm_cnt = s.vert_cnt if s.vnorm_arr > 0 else 0
        s.vcol_cnt = s.vert_cnt if s.vcol_arr > 0 else 0
        s.uv_cnt = s.vert_cnt if s.uv_arr > 0 else 0
        s.weight_cnt = s.vert_cnt if s.weight_arr > 0 else 0
        s.boneid_cnt = s.vert_cnt if s.boneid_arr > 0 else 0

class Texture:
    def __init__(s, data, idx, texname_map):
        d = BinBytes(data)

        s.index = idx

        s.flags1 = d.int()

        s.flags2 = d.int()

        s.id = d.int()

        s.type_raw = d.int()

        s.floats = d.float(26)

        s.name = texname_map.get(s.id, str(s.id))

        s.type = None

        if s.type_raw == 0xf1:
            s.type = 'color'
        if s.type_raw == 0xf2:
            s.type = 'normal'
        if s.type_raw == 0xf3:
            s.type = 'specular'
        
class Material:
    def __init__(s, data):
        d = BinBytes(data)
        s.unk = []
        s.texture_data = []
        s.textures = []
        s.tex_count = d.int()
        s.flags1 = d.int()
        s.type = d.fstr(8)


        for i in range(8):
            s.texture_data.append(d.read(30*4))

        s.unk2 = d.int()

        s.flags2 = d.int()
        s.floats = d.float(22)
        s.name = d.fstr(64)

    def make_textures(s, texmap):
        for i, d in enumerate(s.texture_data):
            tex = Texture(d, i, texmap)
            s.textures.append(tex)

class FaceSection:
    def __init__(s, data):
        d = BinBytes(data)
        s.unk = []
        s.unk.append(d.int(5))

        s.material_index = d.int()

        s.unk.append(d.int(2))
        s.lookup_count = d.int()
        s.lookup_arr = d.int()

        s.unk.append(d.int())

        s.ftype = d.int()

        s.unk.append(d.int())

        s.face_cnt = d.int()
        s.face_arr = d.int()

        s.unk.append(d.int(8))

    def get_lookups(s, f, base):
        s.lookups = f.short(s.lookup_count, base + s.lookup_arr)

    def make_faces(s, f, base):
        facevals = f.short(s.face_cnt, base + s.face_arr)
        facevals.reverse()

        faces = []

        if s.ftype == 5:
            start_direction = -1
            face_direction = start_direction
            f1 = facevals.pop()
            f2 = facevals.pop()
            while len(facevals) > 0:
                f3 = facevals.pop()
                if f3 == 0xFFFF:
                    f1 = facevals.pop()
                    f2 = facevals.pop()
                    face_direction = start_direction
                else:
                    face_direction *= -1
                    if f1 != f2 and f2 != f3 and f1 != f3:
                        if face_direction > 0:
                            faces.append((f1, f2, f3))
                        else:
                            faces.append((f1, f3, f2))
                    f1 = f2
                    f2 = f3

        return faces
