import bpy
from mathutils import Matrix, Vector
from bpy_extras.io_utils import unpack_list, unpack_face_list

def make_bone(arm, name, rmatrix):
    bone = arm.edit_bones.new(name)
    bone.tail = Vector((0,0,1))
    matrix = Matrix(rmatrix).transposed().inverted()

    bone.head = Vector(matrix[3][0:3])
    bone.tail = bone.head + (0.01 * Vector(matrix[0][0:3]).normalized())

def bone_parents(arm, bone, rarm):
    pname = None
    if rarm.unk and bone.name in rarm.unk.child_parent:
        pname = rarm.unk.child_parent[bone.name]

    if pname: 
        parent = arm.edit_bones.get(pname)
        if parent:
            bone.parent = parent

def mat_textures(mat, rmat, image_map):
    for i, rtex in enumerate(rmat.textures):
        if rtex.id == 0xFFFFFFFF: continue

        tex = bpy.data.textures.new(rtex.name, 'IMAGE')
        tex.image = image_map.get(rtex.id)
        tslot = mat.texture_slots.create(i)
        tslot.texture = tex
        tslot.use = True
        tslot.texture_coords = 'UV'
        tslot.uv_layer = 'uv1'

        if rtex.type != 'color':
            tslot.use_map_color_diffuse = False
        else:
            tslot.use_map_color_diffuse = True
            tslot.use_map_alpha = True
        
        if rtex.type == 'normal':
            tslot.use_map_normal = True
            tslot.normal_factor = 0.1
        
        if rtex.type == 'specular':
            tslot.use_map_color_spec = True

def get_image(texfile):
    image = None
    try:
        image = bpy.data.images.load(texfile + '.png')
    except:
        pass

    if image: return image

    try:
        image = bpy.data.images.load(texfile + '.tga')
    except:
        pass

    if image: return image

    try:
        image = bpy.data.images.load(texfile + '.dds')
    except:
        pass

    return image



def make_images(texfile_map):
    ret = {}

    for tex_id, texfile in texfile_map.items():
        ret[tex_id] = get_image(texfile)

    return ret

def make_mesh(obj, robj, mesh, rmesh, rarm):

    mesh.vertices.add(len(rmesh.verts))

    mesh.vertices.foreach_set("co", unpack_list(rmesh.verts))

    mesh.vertices.foreach_set("normal", unpack_list(rmesh.vnorms))

    mesh_face_offset = 0
    for fc in rmesh.face_sections:
        fc_mat_idx = fc.material_index
        fc_mat = bpy.data.materials[robj.mats[fc_mat_idx].name]
        mesh.materials.append(fc_mat)
        mesh.tessfaces.add(len(fc.faces))

        for face_idx in range(len(fc.faces)):
            rface = fc.faces[face_idx]
            face = mesh.tessfaces[face_idx + mesh_face_offset]
            face.vertices = rface
            face.material_index = fc_mat_idx

            if len(rmesh.boneids) == 0:
                continue

            for v in rface:
                bid4 = rmesh.boneids[v]
                weight4 = rmesh.weights[v]
                for i in range(4):
                    bid = bid4[i]
                    if bid >= len(fc.lookups): break
                    weight = weight4[i]
                    real_bid = fc.lookups[bid]
                    bname = rarm.names[real_bid]
                    vgroup = obj.vertex_groups.get(bname)
                    if vgroup == None:
                        vgroup = obj.vertex_groups.new(bname)
                    vgroup.add([v], weight, 'ADD')

        mesh_face_offset += len(fc.faces)

    vc_layer = mesh.tessface_vertex_colors.new()
    vc_layer.name = 'vc1'

    for i, face_vc in enumerate(vc_layer.data):
        if len(rmesh.vcols) == 0: break
        vertices_raw = mesh.tessfaces[i].vertices_raw
        face_vc.color1 = rmesh.vcols[vertices_raw[0]]
        face_vc.color2 = rmesh.vcols[vertices_raw[1]]
        face_vc.color3 = rmesh.vcols[vertices_raw[2]]

    uv_layer = mesh.tessface_uv_textures.new()
    uv_layer.name = 'uv1'

    for i, face_uv in enumerate(uv_layer.data):
        if len(rmesh.uvs) == 0: break
        vertices_raw = mesh.tessfaces[i].vertices_raw
        face_uv.uv1 = rmesh.uvs[vertices_raw[0]]
        face_uv.uv2 = rmesh.uvs[vertices_raw[1]]
        face_uv.uv3 = rmesh.uvs[vertices_raw[2]]


def do_blender(context, objs, arms, texfile_map):

    image_map = make_images(texfile_map)

    for i in range(len(objs)):
        robj = objs[i]

        if i < len(arms):
            rarm = arms[i]
        else:
            rarm = None

        if bpy.ops.object.mode_set.poll():
            bpy.ops.object.mode_set(mode='OBJECT')

        bpy.ops.object.add(type='ARMATURE', enter_editmode=True)

        parent_obj = bpy.context.object
        parent_obj.name = robj.name

        arm = parent_obj.data

        if rarm:
            for i in range(rarm.count):
                make_bone(arm, rarm.names[i], rarm.matrices[i])

            for bone in arm.edit_bones:
                bone_parents(arm, bone, rarm)

        if bpy.ops.object.mode_set.poll():
            bpy.ops.object.mode_set(mode='OBJECT')

        for rmat in robj.mats:
            mat = bpy.data.materials.new(rmat.name)

            mat_textures(mat, rmat, image_map)

        for rmesh in robj.meshes:
            mesh = bpy.data.meshes.new(rmesh.name)
            obj = bpy.data.objects.new(rmesh.name, mesh)

            obj.parent = parent_obj

            if rarm:
                arm_mod = obj.modifiers.new('armature','ARMATURE')
                arm_mod.object = parent_obj

            make_mesh(obj, robj, mesh, rmesh, rarm)

            mesh.update()
            bpy.context.scene.objects.link(obj)
