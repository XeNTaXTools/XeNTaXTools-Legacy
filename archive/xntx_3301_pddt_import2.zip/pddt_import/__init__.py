bl_info = {#{{{
    "name": "PDDT Importer",
    "description": "Imports _obj.bin files from PDDT",
    "author": "oddwarlock, based on chrrox's max script",
    "version": (0, 2),
    "blender": (2, 66, 0),
    "location": "File > Import",
    "warning": "",
    "category": "Import-Export"
    }#}}}
 
if "bpy" in locals():
    import imp
    imp.reload(pddt_obj)
    imp.reload(pddt_import)
else:
    from . import pddt_obj, pddt_import

import bpy
from bpy.props import *
from bpy_extras.io_utils import ImportHelper
from bpy.types import Operator
from mathutils import Matrix, Vector
from bpy_extras.io_utils import unpack_list, unpack_face_list

class IMPORT_OT_pddt(Operator, ImportHelper):
    bl_idname = "io_import_scene.pddt"
    bl_label = "Import PDDT file"

    filename_ext = "*_obj.bin"

    filter_glob = StringProperty(default="*_obj.bin", options={'HIDDEN'})

    def execute(self, context):
        objs, arms, texfile_map, f = pddt_obj.do_import(context, self.filepath)
        f.close()
        pddt_import.do_blender(context, objs, arms, texfile_map)
        return {'FINISHED'}

def menu_func_import(self, context):
    self.layout.operator(IMPORT_OT_pddt.bl_idname, text="PDDT (_obj.bin)")
 
def register():
    bpy.utils.register_module(__name__)
    bpy.types.INFO_MT_file_import.append(menu_func_import)
 
def unregister():
    bpy.utils.unregister_module(__name__)
    bpy.types.INFO_MT_file_import.remove(menu_func_import)
 
if __name__ == "__main__":
    register()
