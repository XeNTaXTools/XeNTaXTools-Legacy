from io import FileIO, BytesIO
from struct import Struct
from array import array
from os import SEEK_SET

class BinCommon():

    def __init__(self, endian):
        self._endian = endian
        self._structs = {}
        self._use_fromfile = type(self) == BinFile

    def _getstruct(self, format_str):
        new_struct = Struct(self._endian + format_str)
        self._structs[format_str] = new_struct
        return new_struct

    def struct(self, struct, count=None, offset=None, whence=SEEK_SET):
        if type(struct) == str:
            struct = self._getstruct(struct)

        size = struct.size
        if offset:
            self.seek(offset, whence)
        if count == None:
            data = self.read(size)
            ret = struct.unpack(data)
        else:
            ret = []
            data = self.read(size*count)
            for i in range(count):
                ret.append(struct.unpack_from(data, offset=i*size))
        return ret

    def _read(self, typecode, count, offset, whence):
        if offset:
            self.seek(offset, whence)

        ret = arr = array(typecode)

        if self._use_fromfile:
            if count == None:
                arr.fromfile(self, 1)
                ret = arr[0]
            else:
                arr.fromfile(self, count)
        else:
            if count == None:
                data = self.read(arr.itemsize)
                arr.frombytes(data)
                ret = arr[0]
            else:
                data = self.read(arr.itemsize*count)
                arr.frombytes(data)

        return ret

    def byte(self, count=None, offset=None, whence=SEEK_SET):
        return self._read('B', count, offset, whence)

    def short(self, count=None, offset=None, whence=SEEK_SET):
        return self._read('H', count, offset, whence)

    def int(self, count=None, offset=None, whence=SEEK_SET):
        return self._read('I', count, offset, whence)

    def float(self, count=None, offset=None, whence=SEEK_SET):
        return self._read('f', count, offset, whence)

    def double(self, count=None, offset=None, whence=SEEK_SET):
        return self._read('d', count, offset, whence)

    def fstr(self, size, offset=None, whence=SEEK_SET, decode=True):
        if offset:
            self.seek(offset, whence)
        ret = self.read(size)
        if decode:
            ret = ret.decode()
            ret = ret.partition('\x00')[0]
        return ret

    def nstr(self, offset=None, whence=SEEK_SET):
        if offset:
            self.seek(offset, whence)
        ret = bytearray()
        tmp = bytearray(1)

        while self.readinto(tmp) and tmp[0] != 0:
            ret.extend(tmp)

        return ret.decode()

class BinFile(FileIO, BinCommon):
    def __init__(self, *args, endian='<'):
        FileIO.__init__(self, *args)
        BinCommon.__init__(self, endian)

class BinBytes(BytesIO, BinCommon):
    def __init__(self, *args, endian='<'):
        BytesIO.__init__(self, *args)
        BinCommon.__init__(self, endian)
