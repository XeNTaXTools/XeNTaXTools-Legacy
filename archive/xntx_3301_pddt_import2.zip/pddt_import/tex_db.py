try:
    from .bintools import BinFile
except ValueError:
    from bintools import BinFile

def get(fname):
    try:
        f = BinFile(fname)
    except:
        return {}

    count, table_ptr = f.int(2)

    raw_pairs = f.struct('2I', count, table_ptr)
    pairs = {}

    for id, ptr in raw_pairs:
        pairs[id] = f.nstr(ptr)

    return pairs
