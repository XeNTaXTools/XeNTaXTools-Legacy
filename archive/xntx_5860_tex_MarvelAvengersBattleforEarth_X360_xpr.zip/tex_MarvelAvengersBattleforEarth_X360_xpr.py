from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Marvel Avengers: Battle for Earth (X360)", ".xpr")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
	#noesis.logPopup()
	return 1

def noepyCheckType(data):
	bs = NoeBitStream(data)
	Magic = bs.readBytes(4).decode("ASCII")
	if Magic != 'SMX7':
		return 0
	return 1

def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data, NOE_BIGENDIAN)
    bs.seek(0x04, NOESEEK_ABS)
    TX2D_START = bs.readInt()
    TX2D_SIZE = bs.readInt()
    KF_DATA_SIZE = bs.readInt()
    TX2D_DATA_SIZE = bs.readInt()
    COMPRESSION_TAG = bs.readInt()
    TX2D_NUMS = bs.readInt()
    TX2D_DATA_START = (TX2D_START + TX2D_SIZE + KF_DATA_SIZE)
    bs.seek(TX2D_START, NOESEEK_ABS)
    for i in range(TX2D_NUMS):
        print(i, ":this is i")
        tx2d = bs.readInt()
        relDataOff = bs.readInt()
        unk = bs.readInt()
        relStringOff = bs.readInt()
        unk2 = bs.readInt()
        tmp = bs.tell()
        bs.seek(relStringOff + TX2D_START, NOESEEK_ABS)
        texName = bs.readString().split("\\")
        texName = texName[-1]
        texName = texName[:-4]
        print(texName)
        bs.seek(relDataOff + TX2D_START, NOESEEK_ABS)
        bs.seek(0x21, NOESEEK_REL)
        START_OFFSET = bs.readShort()
        imgFmt = bs.readUByte()
        print(hex(imgFmt), ":imgFmt")
        height = bs.readUShort()
        print(height, ":height")
        width = bs.readUShort()
        print(width, ":width")
        imgHeight = (height + 1) * 8       
        imgWidth = (width + 1) & 0x1FFF
        print(imgWidth, "x", imgHeight, ":width and height")
        TX2D_ID = TX2D_NUMS - 1
        print(TX2D_ID, ":TX2D_ID")
        if START_OFFSET != 0:
            START_OFFSET = START_OFFSET * 0x100
        if i == TX2D_ID:
            datasize = TX2D_DATA_SIZE - START_OFFSET
        else:
            bs.seek(0x39, NOESEEK_REL)
            END_OFFSET = bs.readUShort() * 0x100
            datasize = END_OFFSET - START_OFFSET
        data_OFFSET = START_OFFSET + TX2D_DATA_START
        bs.seek(data_OFFSET, NOESEEK_ABS)
        data = bs.readBytes(datasize)
        #DXT1
        if imgFmt == 0x52:
            data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 8)
            texFmt = noesis.NOESISTEX_DXT1
        #DXT5
        elif imgFmt == 0x54:
            data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 16)
            texFmt = noesis.NOESISTEX_DXT5
        #DXT1 packed normal map
        elif imgFmt == 0x7C:
            data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 8)
            data = rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_DXT1NORMAL)
            texFmt = noesis.NOESISTEX_RGBA32
        #raw
        elif imgFmt == 0x86:
            data = rapi.imageUntile360Raw(data, imgWidth, imgHeight, 4)
            data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "a8 r8 g8 b8")
            texFmt = noesis.NOESISTEX_RGBA32
        #unknown, not handled
        else:
            print("WARNING: Unhandled image format " + repr(imgFmt) + " - " + repr(imgWidth) + "x" + repr(imgHeight) + " - " + repr(len(data)))
            return None
        texList.append(NoeTexture(texName, imgWidth, imgHeight, data, texFmt))
        bs.seek(tmp, NOESEEK_ABS)
    return 1