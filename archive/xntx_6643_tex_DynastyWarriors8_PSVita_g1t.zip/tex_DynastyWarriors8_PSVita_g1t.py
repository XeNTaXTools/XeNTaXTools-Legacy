from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Dynasty Warriors 8 [PS Vita]", ".dat")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    if noeStrFromBytes(bs.readBytes(8)) != 'GT1G0600': return 0
    return 1
	
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.seek(0x8, NOESEEK_ABS)
    filesize = bs.readInt()
    tableOffset = bs.readUInt()
    numTexs = bs.readUInt() #0x10
    #print(numTexs, "numTexs")
    bs.seek(tableOffset, NOESEEK_ABS)
    for i in range(numTexs):
        texOffset = bs.readUInt()
        print(texOffset, "texOffset")
        TMP = bs.tell()
        print(hex(TMP), "start1")
        bs.seek(texOffset + tableOffset, NOESEEK_ABS)
        texName = rapi.getExtensionlessName(rapi.getInputName()) + "_" + str(i)
        print(hex(bs.tell()), "we're here")
        unk = bs.readByte()
        imgFmt = bs.readUByte()             
        print(imgFmt, "imgFmt")
        texSize = bs.readUByte()
        print(hex(texSize), "texSize")
        width = texSize & 0x0F
        height = (texSize & 0xF0) // 16
        print(hex(width), "width")
        print(hex(height), "height")
        imgWidth = 2 ** width
        imgHeight = 2 ** height
        print(imgWidth, "x", imgHeight)
        bs.seek(0x4, NOESEEK_REL)
        check = bs.readUByte()
        if check == 0x10:
            bs.seek(0xc, NOESEEK_REL)
        print(hex(bs.tell()), "start2")
        #DXT5
        if imgFmt == 0x12 or imgFmt == 0x8:
            datasize = imgWidth * imgHeight
        print(hex(datasize), "datasize")
        data = bs.readBytes(datasize)      
        print(hex(bs.tell()), "at end")
        #DXT5
        if imgFmt == 0x8:
            texFmt = noesis.NOESISTEX_DXT5
        #DXT5 morton swizzled    
        elif imgFmt == 0x12:
            data = rapi.imageFromMortonOrder(data, imgWidth >> 1, imgHeight >> 2, 8)
            data = rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_DXT5)
            texFmt = noesis.NOESISTEX_RGBA32
        texList.append(NoeTexture(texName, imgWidth, imgHeight, data, texFmt))
        bs.seek(TMP, NOESEEK_ABS)
    return 1