from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("long 3d", ".axp")
    noesis.setHandlerExtractArc(handle, axpExtractArc)
    return 1

def axpExtractArc(fileName, fileLen, justChecking):
    if fileLen < 16:
        return 0
        
    if justChecking: #it's valid
            return 1

    f = open(fileName, "rb")
    fs = NoeFileStream(f)
    
    idstring = noeAsciiFromBytes(fs.readBytes(4))
    if idstring != "AXPK":
        return 0
    
    VER1 = fs.readShort()
    VER2 = fs.readShort()
    ZERO = fs.readInt()
    ZERO = fs.readInt()
    INFO_OFF = fs.readInt()
    FILES = fs.readInt()
    DUMMY = fs.readInt()
    DATA_OFF = fs.readInt()
    DATA_SIZE = fs.readInt()
    
    fs.seek(INFO_OFF, NOESEEK_ABS)
    allOffset = []
    allnames = []

    for i in range(FILES):
        OFFSET = fs.readInt()
        SIZE = fs.readInt()
        FLAGS = fs.readInt()# ever 0x80000000!

        if FLAGS != 0:
            allOffset.append([OFFSET,SIZE])

    fs.seek(allOffset[-1][0], NOESEEK_ABS)
    
    minus = 1
    #Model5.axp names its 1216
    try: 
        names = noeStrFromBytes(fs.readBytes(allOffset[-1][1]), enc = "Windows-1258").split('\n')
        for x in names:
            name = x.split('|')[0]
            if name and '.' in name: 
                allnames.append(name)
    except:
        #archive dont have name???
        minus = 0
        for x in range(len(allOffset)):
            allnames.append(str(x)+".dat")
            
    for x in range(len(allOffset)-minus):
        name_file = allnames[x]
        full, ext = os.path.splitext(allnames[x])
        fs.seek(allOffset[x][0], NOESEEK_ABS)

        #cut trash 96 bytes
        cut = 0

        if ext == ".mesh" or ext == ".skeleton":
            if fs.readShort() != 4096:
                fs.seek(94, NOESEEK_REL)
                cut = 94
            else:
                fs.seek(-2, NOESEEK_REL)

        if minus == 0:
            name_file = search_ext(fs, name_file, allOffset[x][0])        
            fs.seek(allOffset[x][0], NOESEEK_ABS)

        export_data = fs.readBytes(allOffset[x][1]-cut)
        
        name_file = str(x)+"."+name_file.split('.')[-1]

        rapi.exportArchiveFile(name_file, export_data)
        print("export", name_file)

    print("Extracting", len(allOffset)-1, "files.")
    return 1

def search_ext(fs, name, offset):
    fs.seek(offset, NOESEEK_ABS)
    header = fs.readUShort()
    
    #DDS
    if header == 17476:
        return name.split('.')[0]+".dds"
    #JPEG
    elif header == 55551:
        return name.split('.')[0]+".jpg"
    #TGA
    elif header == 0:#int
        fs.seek(offset, NOESEEK_ABS)
        if fs.readInt() == 131072:
            fs.seek(offset+2, NOESEEK_ABS)
            return name.split('.')[0]+".tga"
    #PNG
    elif header == 20617:
        return name.split('.')[0]+".png"
    #XML
    elif header == 16188:
        return name.split('.')[0]+".xml"
    #MODELS
    elif header == 4096 or header == 52356:
        x = 2 if header == 4096 else 98
        fs.seek(offset+x, NOESEEK_ABS)
        string = noeAsciiFromBytes(fs.readBytes(5))
        if string == "[Seri":
            return name.split('.')[0]+".skeleton"
        elif string == "[Mesh":
            return name.split('.')[0]+".mesh"
        else:
            fs.seek(-5, NOESEEK_REL)
            hd = fs.readUInt()
            if hd == 2389005229:
                return name.split('.')[0]+".skeleton"
            elif hd == 2405782957:
                return name.split('.')[0]+".mesh"
            else:
                return name
    else:
        return name