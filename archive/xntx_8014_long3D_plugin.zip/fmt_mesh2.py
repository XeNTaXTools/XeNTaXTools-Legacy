#broken file
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Broken Long 3D", ".mesh")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)
    return 1

offset_mesh = -1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    if bs.readInt() != 1979370628:
        bs.seek(92, NOESEEK_REL)
        if bs.readShort() != 4096:
            return 0
    return 1

def noepyLoadModel(data, mdlList):
    bs = NoeBitStream(data)
    bs.seek(122, NOESEEK_ABS)
    file_size = bs.getSize()

    mdlList.append(NoeModel())
    return 1