#by Durik256 for xentax.com 31.01.2022 (ogre?)
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Tân Thiên Long 3D", ".mesh")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadModel(handle, noepyLoadModel)
    noesis.logPopup()
    return 1

offset_mesh = -1
def noepyCheckType(data):
    global offset_mesh
    offset_mesh = data.find('[MeshSerializer'.encode())
    if offset_mesh == -1:
        return 0
    return 1

def noepyLoadModel(data, mdlList):
    bs = NoeBitStream(data)
    bs.seek(offset_mesh+35, NOESEEK_ABS)
    file_size = bs.getSize()
    
    while bs.getOffset() < file_size:
        if bs.readShort() == 10:
            break
        else:
            bs.seek(-1, NOESEEK_REL)
    

    meshes = []
    materials = []
    while bs.getOffset() < file_size:
        id = str(len(meshes))
        mesh = loadMesh(bs)
        mesh.setName("mesh_"+id)
        mesh.setMaterial("mat_"+id)
        materials.append(NoeMaterial("mat_"+id,""))
        meshes.append(mesh)
        if bs.getOffset()+80 < file_size:
            if not findStart(bs):
                break
        else:
            break

    mdl = NoeModel(meshes)
    mdl.setModelMaterials(NoeModelMaterials([], materials))
    mdlList.append(mdl)
    return 1

def findStart(bs):
    file_size = bs.getSize()
    chank = bs.readShort()
    if chank == 8288:
        return 0
    elif chank == 16400 or chank == 16384:
        bs.seek(12, NOESEEK_REL)
        while bs.getOffset() < file_size:
            if bs.readShort() == 10:
                return 1
            else:
                bs.seek(-1, NOESEEK_REL)
    return 0

def loadMesh(bs):
    face_count = bs.readInt()
    bs.seek(1, NOESEEK_REL)
    
    print("face_count",face_count,bs.getOffset())
    if face_count>65000:
        return 0
    face = [bs.readShort() for x in range(face_count)]
    print("face_end",bs.getOffset())
    
    #info mesh
    bs.readShort()#[00 50]
    size_FVF = bs.readInt()
    vert_count = bs.readInt()
    bs.readShort()#[00 51]
    print("size_FVF",size_FVF)
    print("vert_count",vert_count)
    this_count = bs.readInt()#54
    print("this_count",this_count)
    #vertex info
    bs.readShort()#[10 51]
    #0-size(16), 1-unk, 2-!inFVF?, 3-unk, 4-unk, 5-offset, 6-unk
    v_info = [bs.readShort() for x in range(7)]
    print("v_info",v_info)
    #normal info
    bs.readShort()#[10 51]
    n_info = [bs.readShort() for x in range(7)]
    print("n_info",n_info)
    param_count = int((this_count-6)/16)
    if param_count > 3:
        if param_count > 5:
            print("unk_info_error",param_count,bs.getOffset())
            return 0
        for x in range(param_count-3):
            #unk0 info
            bs.readShort()#[10 51]
            unk_info = [bs.readShort() for x in range(7)]
            print(x,"unk_info",unk_info)
    #uvs info
    bs.readShort()#[10 51]
    uv_info = [bs.readShort() for x in range(7)]
    print("uv_info",uv_info)
    bs.readShort()#[00 52]
    
    uv_start = bs.readInt()
    unk0 = bs.readShort()
    print("uv_start",uv_start,"unk0",unk0)
    size_bl = bs.readShort()
    print("size_bl",size_bl)
    bs.readShort()#[10 52]
    v_size = bs.readInt()
    print("v_size",v_size)
    
    vert, norm, uv = [], [], []
    #read vertex/normals,uvs
    print("vert_count ",vert_count,bs.getOffset())
    if vert_count>65000:
        return 0
    for x in range(vert_count):
        vert.append(NoeVec3.fromBytes(bs.readBytes(12)))
        if size_bl>12:
            norm.append(NoeVec3.fromBytes(bs.readBytes(12)))
        if size_bl > 24 and uv_info[2] == 0:
            bs.seek((uv_info[5]-24), NOESEEK_REL)
            uv.append(NoeVec3([bs.readFloat(), bs.readFloat()]+[0]))

    print("vert_end ",bs.getOffset())
    
    #read uvs
    if uv_info[2] > 0:
        print("uv_start ",bs.getOffset())
        for x in range(uv_info[2]-1):
            bs.readShort()#[00 52]
            count_seek = bs.readInt()-6
            bs.seek(count_seek,NOESEEK_REL)
        
        print("uv_start ",bs.getOffset())
        bs.readShort()#[00 52]
        end_uv = bs.readInt()
        
        unk_uv = bs.readShort()
        size_bl_uv = bs.readShort()
        bs.readShort()#[10 52]
        size_uv = bs.readInt()
        for x in range(vert_count):
            bs.seek(uv_info[5], NOESEEK_REL)
            uv.append(NoeVec3([bs.readFloat(), bs.readFloat()]+[0]))
  
        print("uv_end ",bs.getOffset())
    #if uv_info[2] == 3:
        #for x in range(3):
            #count_seek = bs.readInt()-4#7232/5428/3624
            #bs.seek(count_seek,NOESEEK_REL)
    
    #read weight
    bs.readShort()#[10 40]
    unk_w0 = bs.readShort()
    unk_w1 = bs.readShort()
    unk_w2 = bs.readShort()
    unk_w3 = bs.readInt()
    
    print("unk_w3_start ",bs.getOffset())
    if unk_w3 == 1065216:#if 8848: break
        bs.seek(-4, NOESEEK_REL)
        w = 0
        last = -1
        while w < vert_count:
            bs.seek(6, NOESEEK_REL)
            cur = bs.readInt()
            bs.seek(6, NOESEEK_REL)
            #print(cur,last,bs.getOffset())
            if cur != last:
                last = cur
                if bs.readShort() != 24576:
                    bs.seek(-2, NOESEEK_REL)
                    w += 1
                else:
                    break
        print("unk_w3_end ",bs.getOffset())
        
        for x in range(3): 
            bs.seek(6, NOESEEK_REL)
            if bs.readInt() == last:
                bs.seek(6, NOESEEK_REL)
            else:
                bs.seek(-10, NOESEEK_REL)
                break
        print("unk_w3_end2 ",bs.getOffset())
        #bs.seek(-6, NOESEEK_REL)
    
    print("end ",bs.getOffset())
    mesh = NoeMesh(face, vert , "mesh_0")
    mesh.setNormals(norm)
    mesh.setUVs(uv)
    return mesh