"""
Blender V3O Import/Export Scripts
Copyright (C) 2015 Robert Smilie

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
"""

bl_info = {
    "name": "Import/Export Emergency 4 Format (.v3o)",
    "author": "Robert Smilie",
    "version": (1, 0, 0),
    "blender": (2, 73, 0),
    "location": "File > Import-Export",
    "category": "Import-Export"}

if "bpy" in locals():
    import imp
    if "import_v3o" in locals():
        imp.reload(import_v3o)
    if "export_v3o" in locals():
        imp.reload(export_v3o)
import bpy
from bpy.props import (BoolProperty,
                       FloatProperty,
                       StringProperty,
                       EnumProperty,
                       )
from bpy_extras.io_utils import (ImportHelper,
                                 ExportHelper,
                                 path_reference_mode,
                                 axis_conversion,
                                 )

class ImportV3O(bpy.types.Operator, ImportHelper):
    """Import an Emergency 4 V3O File"""
    bl_idname = "import_mesh.v3o"
    bl_label = "Import V3O"
    bl_options = {'PRESET', 'UNDO'}
    
    filename_ext = '.v3o'
    filter_glob = StringProperty(default='*.v3o', options={'HIDDEN'})
    
    def execute(self, context):
        from . import import_v3o
        keywords = self.as_keywords(ignore=("filter_glob", "check_existing"))
        return import_v3o.load(self, context, **keywords)

class ExportV3O(bpy.types.Operator, ExportHelper):
    """Export an Emergency 4 V3O File"""
    bl_idname = "export_mesh.v3o"
    bl_label = 'Export V3O'
    bl_options = {'PRESET'}
    
    filename_ext = '.v3o'
    filter_glob = StringProperty(default='*.v3o', options={'HIDDEN'})
    
    path_mode = path_reference_mode
    
    check_extension = True
    
    def execute(self, context):
        from . import export_v3o
        keywords = self.as_keywords(ignore=("check_existing", "filter_glob"))
        return export_v3o.save(self, context, **keywords)

def menu_func_import(self, context):
    self.layout.operator(ImportV3O.bl_idname, text="Emergency 4 (.v3o)")

def menu_func_export(self, context):
    self.layout.operator(ExportV3O.bl_idname, text="Emergency 4 (.v3o)")

def register():
    bpy.utils.register_module(__name__)
    bpy.types.INFO_MT_file_export.append(menu_func_export)
    bpy.types.INFO_MT_file_import.append(menu_func_import)

def unregister():
    bpy.utils.unregister_module(__name__)
    bpy.types.INFO_MT_file_export.remove(menu_func_export)
    bpy.types.INFO_MT_file_import.remove(menu_func_import)

if __name__ == "__main__":
    register()