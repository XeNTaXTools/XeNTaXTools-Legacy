"""
Blender V3O Import/Export Scripts
Copyright (C) 2015 Robert Smilie

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
"""

import os
import time
import bpy
import bpy_extras.io_utils
import ntpath
import math, mathutils

def mesh_triangulate(me):
    import bmesh
    # create a new BMesh
    bm = bmesh.new()
    # copy the object mesh to the new BMesh
    bm.from_mesh(me)
    
    # ignore this for now
    #rotation = mathutils.Euler((0.0, 0.0, math.radians(90))).to_matrix()
    ##bmesh.ops.rotate(bm, cent=(0,0,0), matrix=rotation, verts=bm.verts)
    
    # apply a triangulation modifier to the bmesh
    bmesh.ops.triangulate(bm, faces=bm.faces)
    
    # apply a split-edge modifier to the bmesh
    #   - this separates the vertices/edges so the uv mapping will work properly
    #   - v3o files apparently do not support shared vertice uv mapping, so the vertices have to be separated
    bmesh.ops.split_edges(bm, edges=bm.edges)
    # write the changed bmesh back into the current mesh datablock
    bm.to_mesh(me)
    # release the bmesh data from memory
    bm.free()

def write_file(filepath, objects, scene, EXPORT_PATH_MODE='AUTO'):
    print('V3O Export Path: {}'.format(filepath))
    # record export start time
    timeStart = time.time()
    # open/create v3o file
    file = open(filepath, "w", encoding="utf8", newline="\n")
    fw = file.write
    
    # write v3o header
    fw('[VNUM=1.43]\n\n')
    
    # get meshes
    for ob_main in objects:
        obs = [(ob_main, ob_main.matrix_world)]
        
    for ob, ob_mat in obs:
        try:
            # try to get the object's mesh
            me = ob.to_mesh(scene, True, 'PREVIEW', calc_tessface=False)
        except RuntimeError:
            me = None
        
        # we couldn't get the object's mesh, so start on the next object ([GOTO LINE: 65])
        if me is None:
            continue
        
        # I *think* this is for a collision box,
        #  but honestly I have no idea what the last three lines are for in a v3o file
        # All I figured out was how to get roughly the same data to spit out as something zmodeler would do
        greatX = 0
        greatY = 0
        greatZ = 0
        lessX = 0
        lessY = 0
        lessZ = 0
        
        # call the function to triangulate the mesh (and split edges, something I added later)
        #   - a word about v3o meshes, at this time I only have triangulated meshes working,
        #       but if you take a look at the "P" lines in a v3o file, you'll notice the first integer
        #       is a "3", possibly indicating (what I believe) is the three following vertices
        #       I have no idea if it will work or not, but someone should try and see if quads will work
        mesh_triangulate(me)
        
        # ignore this, we don't need to recalculate normals
        #me.calc_normals()
        
        # get number of materials attached to the mesh
        materialNum = len(me.materials)
        print("Materials attached to mesh: {}".format(materialNum))
        # create a list to hold valid all [Material->ImageTexture]'s we find
        # format will be materials = [0 = [materialName, materialTextureName, materialTextureFileName, materialTextureUVMapName]]
        materials = list()
        # check if there are any materials attached to the mesh
        if materialNum > 0:
            #iterate through each material attached to the mesh
            for mat in me.materials:
                # get the material name
                g_matName = mat.name
                # iterate through all the texture slots to see if any textures have been assigned
                for i in range(0, len(mat.texture_slots)):
                    # check if the texture is set to something
                    if (mat.texture_slots[i] != None):
                        # now let's make sure the texture is in use, is an image and is set to use UV coords
                        if (mat.texture_slots[i].use == True) and (mat.texture_slots[i].texture.type == 'IMAGE') and (mat.texture_slots[i].texture_coords == 'UV'):
                            #print("Material->Assigned Texture->Enabled & Is Image & Uses UV Coords")
                            # we can only assign one texture per material in order to work with .v3o, so we'll use the first one we find and forget the rest
                            # get the texture name and texture file name
                            g_texName = mat.texture_slots[i].texture.name
                            g_texFileName = ntpath.basename(mat.texture_slots[i].texture.image.filepath)
                            # get the uv map name
                            g_texUVMapName = mat.texture_slots[i].uv_layer
                            # now save all this info so we can access it later
                            materials.append({'matName':g_matName, 'texName':g_texName, 'texFileName':g_texFileName, 'texUVMapName':g_texUVMapName})
                            break
        if (len(materials) == 0):
            # the mesh doesn't have any materials attached, so we'll create a default one
            materials.append({'matName':'Material', 'texName':'', 'texFileName':'', 'texUVMapName':''})
        
        # make a copy of the mesh vertices
        me_verts = me.vertices[:]
        # we're going to count the vertices
        vertnum = 0
        # we'll also create our own dictionary of vertices
        vertices = dict()
        # as well as a dict for the vertex normals
        vertexNormals = dict()
        # and another dict for the vertex UVs
        vertexUVs = dict()
        # iterate through each mesh vertices
        for v in me_verts:
            # we have to multiply the vertice coordinates by 10,000
            # (because blender units are floats, and most of the time are just too small when converted to integers)
            x = int(v.co[0]*10000)
            y = int(v.co[1]*10000)
            z = int(v.co[2]*10000)
            # vertex normals are also floats, but they're just for reflection, so they don't have to be as big of a number
            xnorm = int(v.normal[0]*256)
            ynorm = int(v.normal[1]*256)
            znorm = int(v.normal[2]*256)
            #print("{}, {}, {}".format(xnorm, ynorm, znorm))
            vindex = v.index
            # save the vertices for later, the index starts at 1 due to the fact v3o indexing starts at 1 instead of 0
            vertices[vindex+1] = [x, y, z]
            # save the vertex normals as well
            vertexNormals[vindex+1] = [xnorm, ynorm, znorm]
            # save the vertex UVs
            vertexUVs[vindex+1] = [0, 0]
            vertnum += 1
            # calc great/less coords (collisionBox/box) (great is actually less and vice-versa!)
            if greatX > x:
                greatX = x
            if greatY > y:
                greatY = y
            if greatZ > z:
                greatZ = z
            if lessX < x:
                lessX = x
            if lessY < y:
                lessY = y
            if lessZ < z:
                lessZ = z
        
        mesh_polys = me.polygons
        polynum = 0
        # we'll store the polygon info here later
        polygons = dict()
        for p in me.polygons:
            # get the polygon index
            pindex = p.index
            # get the vertex indices that make up this poly
            pverts = p.vertices
            # store the polygons
            polygons[pindex+1] = [pverts[0]+1, pverts[1]+1, pverts[2]+1, p.material_index+1]
            polynum += 1
            #print("Polygon: {}".format(p.index))
            vertCount = 0
            # check if there is a uv map set for the mesh
            if len(me.uv_layers) > 0:
                # okay, so here we're going to iterate through the loop indices of the poly
                #   - basically, a loop index is a vertex and an edge combination
                #   - a triangle contains 3 loop indices, which can be thought of as the three sides,
                #       but only one vertex is part of an edge (as opposed to two)
                for li in p.loop_indices:
                    # now we get the vertex index that is linked to the particular loop index
                    vi = me.loops[li].vertex_index
                    # now we grab the uv coordinates based on the loop index
                    uv = me.uv_layers.active.data[li].uv
                    #print("\tLoopID: {}, VertID: {}, UV: ({}, {})".format(li, vi, uv.x, uv.y))
                    # this is the x coordinate, again, we multiply by a larger integer so it scales properly
                    vertexUVs[vi+1][0] = int(uv.x*1024)
                    # v3o formats apparently handle the y (v) coordinate of the uv maps flipped, thus the *-1 here
                    vertexUVs[vi+1][1] = int(uv.y*1024)*-1
    # set the number of textures used
    fw('[NUMSURFACES={}]\n'.format(len(materials)))
    # set the number of vertices used
    fw('[NUMVERTICES={}]\n'.format(vertnum))
    # ignore this for now
    fw('[NUMBLENDVERTS={}]\n'.format(0))
    # set the number of polygons used
    fw('[NUMPOLYGONS={}]\n'.format(polynum))
    # ignore this and the next two as well
    fw('[NUMBONES={}]\n'.format(0))
    fw('[NUMMUSCLEANIMS={}]\n'.format(0))
    fw('[NUMMUSCLEFRAMES={}]\n\n'.format(0))
    # write the texture data to the file
    for tex in materials:
        fw("SRF, {texName}, 0, 0, 0, {texFile}, 517, 2, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0\n".format(
        texName=tex['matName'], texFile=tex['texFileName']
        ))
    # write the vertex data to the file
    for key, vertex in vertices.items():
        fw("D, {z}, {x}, {y}, {znorm}, {xnorm}, {ynorm}, {xtexco}, {ytexco}, 0, 0, 0, 0\n".format(
        z=vertex[0], x=vertex[1], y=vertex[2],
        znorm=vertexNormals[key][0], xnorm=vertexNormals[key][1], ynorm=vertexNormals[key][2],
        xtexco=vertexUVs[key][0], ytexco=vertexUVs[key][1]
        ))
    # write the polygon data to the file
    for key, poly in polygons.items():
        fw("P, 3, {v1}, {v2}, {v3}, 0, 0, 0, 0, {tex}, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0\n".format(
        v1=poly[0], v2=poly[1], v3=poly[2],
        tex=poly[3]
        ))
    # write tail of .v3o, I have no idea what this stuff is for, only that it's apparently needed
    # the best I could do with this is get it to least somehow measure up to what zmodeler's output would be
    fw("BOX, {gX}, {gY}, {gZ}, {lX}, {lY}, {lZ}\n".format(
    gX=int(greatX/100), gY=int(greatY/100), gZ=int(greatZ/100),
    lX=int(lessX/100), lY=int(lessY/100), lZ=int(lessZ/100)
    ))
    fw("N, 0, 0, 0, {notsureYet}\n".format(
    notsureYet=100))
    fw("CBOX, {gX}, {gY}, {gZ}, {lX}, {lY}, {lZ}\n".format(
    gX=round(float(greatX)/100.0,3), gY=round(float(greatY)/100.0,3), gZ=round(float(greatZ)/100.0,3),
    lX=round(float(lessX)/100.0,3), lY=round(float(lessY)/100.0,3), lZ=round(float(lessZ)/100.0,3)
    ))
    file.close()
    # print the total export time
    print("V3O Export time: {}".format(time.time()-timeStart))

def _write(context, filepath, EXPORT_PATH_MODE):
    scene = context.scene
    # Make sure we're in object mode
    if bpy.ops.object.mode_set.poll():
        bpy.ops.object.mode_set(mode='OBJECT')
    # get selected objects to export
    objects = context.selected_objects
    # now for the actual exporting
    write_file(filepath, objects, scene, EXPORT_PATH_MODE)

def save(operator, context, filepath="", path_mode='AUTO'):
    _write(context, filepath, EXPORT_PATH_MODE=path_mode)
    return {'FINISHED'}