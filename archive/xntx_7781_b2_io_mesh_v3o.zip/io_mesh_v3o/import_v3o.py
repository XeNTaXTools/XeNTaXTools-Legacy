"""
Blender V3O Import/Export Scripts
Copyright (C) 2015 Robert Smilie

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
"""

import os
import bpy
import mathutils
import ntpath
from bpy_extras.io_utils import unpack_list
from bpy_extras.image_utils import load_image

def load(operator, context, filepath):
    filepath = os.fsencode(filepath)
    
    # we'll base the object name off the file name
    objName = ntpath.basename(filepath).decode('utf-8', "replace")
    objName = os.path.splitext(objName)[0]
    
    # open the v3o file to import
    file = open(filepath, 'r')
    # this will hold the materials
    materials = dict()
    mindex = 0
    # these hold vertices, vertex normals, and vertex UVs
    vertices = []
    vertexNormals = dict()
    vertexUVs = dict()
    vindex = 0
    # these hold the polygons, the textures assigned to the polygons, and the poly loop indices
    polygons = []
    polygonTex = dict()
    polyLoops = dict()
    pindex = 0
    # this will hold the mesh loop indices
    meshLoopIndex = 0
    meshLoops = dict()
    polyLoopIndices = dict()
    for line in file:
        # is it a material?
        if line[0] == 'S':
            #print("Surface")
            ls = line.split(',')
            mat_name = ls[1][1:]
            mat_file = ls[5][1:]
            #print("Name: {}\nFile: {}".format(mat_name, mat_file))
            materials[mindex] = [mat_name, mat_file]
            mindex += 1
        # is it a vertex?
        elif line[0] == 'D':
            #print("Vertex")
            ls = line.split(',')
            #print(ls[0])
            vertices.append([float(ls[1])/10000, float(ls[2])/10000, float(ls[3])/10000])
            vertexNormals[vindex] = [float(ls[4])/256, float(ls[5])/256, float(ls[6])/256]
            vertexUVs[vindex] = [float(ls[7])/1024, float(ls[8])/1024*-1]
            vindex += 1
        # is it a polygon?
        elif line[0] == 'P':
            #print("Polygon")
            # the really cool thing about importing is the fact that the loop indices and what not are all in order already
            ls = line.split(',')
            v1 = int(ls[2])-1
            v2 = int(ls[3])-1
            v3 = int(ls[4])-1
            polygons.append([v1, v2, v3])
            polygonTex[pindex] = int(ls[9])-1
            #===
            meshLoops[meshLoopIndex] = v1
            meshLoops[meshLoopIndex+1] = v2
            meshLoops[meshLoopIndex+2] = v3
            polyLoopIndices[pindex] = (meshLoopIndex, meshLoopIndex+1, meshLoopIndex+2)
            #===
            pindex += 1
            meshLoopIndex += 3
    #print(vertexUVs)
    #print(materials)
    file.close()
    scene = context.scene
    # create an empty mesh
    me = bpy.data.meshes.new(os.path.splitext((os.path.basename(filepath)))[0].decode('utf-8', "replace"))
    # fill in the mesh based on the vertice/poly info
    me.from_pydata(vertices, [], polygons)
    # create the uv map
    uvTex = me.uv_textures.new(objName)
    uvLayer = me.uv_layers[uvTex.name]
    # set the uv map vertex coordinates
    for mlKey, mlValue in meshLoops.items():
        uvLayer.data[mlKey].uv = (vertexUVs[mlValue][0], vertexUVs[mlValue][1])
    # we're going to save the image references for access later
    imagesArray = list()
    for key, value in materials.items():
        #print("k: {}, v: {}".format(key, value))
        # create a new material
        newMat = bpy.data.materials.new(value[0])
        # get the image path (this is uneeded, iirc)
        newMat_image = os.path.join(os.path.dirname(filepath.decode('utf-8', "replace")), value[1])
        # turn on transparency, since Em4 supports transparent textures
        newMat.use_transparency = True
        #print(newMat_image)
        # create a blank texture of type Image
        newTex = bpy.data.textures.new(name='Texture', type='IMAGE')
        #print(os.path.dirname(newMat_image))
        # load the image into blender
        image = load_image(value[1], os.path.dirname(newMat_image), recursive=False)
        # store images in array so we can assign them to faces later
        imagesArray.append(image)
        # make sure the image actually loaded, else blender might throw an error on assignment
        if image is not None:
            # assign the image to the texture (material->texture->image is the basic hierarchy)
            newTex.image = image
        # add a texture slot to the material
        matTex = newMat.texture_slots.add()
        # assign the texture to the new texture slot in the material
        matTex.texture = newTex
        # set the texture coordinates to UV
        matTex.texture_coords = 'UV'
        # assign the UV map to the texture (it assigns by name)
        matTex.uv_layer = objName
        #print(image)
        # and finally assign the material (which contains the texture) to the mesh
        me.materials.append(newMat)
    for pkey, pval in polygonTex.items():
        # assign the images to the uv polys
        uvTex.data[pkey].image = imagesArray[pval]
        # assign the materials to the mesh polys
        me.polygons[pkey].material_index = pval
    # update all the mesh data we just threw in
    me.update()
    # create an object from our mesh
    obj = bpy.data.objects.new(objName, me)
    # link the new object to the scene
    base = scene.objects.link(obj)
    # and select the object/scene
    base.select = True
    # now update the scene data
    scene.update()
    # all done!
    return {"FINISHED"}