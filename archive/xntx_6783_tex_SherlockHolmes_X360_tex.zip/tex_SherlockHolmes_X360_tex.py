from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Sherlock Holmes [X360]", ".tex")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    if bs.readBytes(4) != b'\x00\x00\x00\x03': return 0
    return 1

def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data, NOE_BIGENDIAN)
    bs.seek(0x20)
    imgFmt = bs.readUInt()
    height = bs.readUShort()
    width = bs.readUShort()
    imgHeight = (height + 1) * 8
    imgWidth = (width + 1) & 0x1FFF
    print(imgWidth, "x", imgHeight, "-", hex(imgFmt))
    bs.seek(0xc, 1)
    data = bs.readBytes(bs.getSize() - bs.tell())
    #DXT1
    if imgFmt == 0x52:
        data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 8)
        texFmt = noesis.NOESISTEX_DXT1
    #DXT5
    elif imgFmt == 0x54:
        data = rapi.imageUntile360DXT(rapi.swapEndianArray(data, 2), imgWidth, imgHeight, 16)
        texFmt = noesis.NOESISTEX_DXT5
    #RGBA8888
    elif imgFmt == 0x86:
        data = rapi.imageUntile360Raw(data, imgWidth, imgHeight, 4)
        data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "a8r8g8b8")
        texFmt = noesis.NOESISTEX_RGBA32
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1