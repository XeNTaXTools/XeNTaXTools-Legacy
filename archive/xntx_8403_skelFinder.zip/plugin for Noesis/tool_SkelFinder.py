#by Durik256
from inc_noesis import *
from ctypes import *
import noewin

def registerNoesisTypes():
    handle = noesis.registerTool("&Skel Finder", SkelFinder)
    handle = noesis.register("Skel Finder", ".SkelFinder")
    noesis.setHandlerTypeCheck(handle, CheckType)
    noesis.setHandlerLoadModel(handle, loadModel)
    noesis.setHandlerWriteModel(handle, noepyWriteModel)
    return 1

numBones = 0
FilePath = ''
BigEndian = False
MultiplyBones = False
template = ''

def CheckType(data):
    if data[:4] == b'SKEL' or data[:4] == b'TEMP':
        return 1
    return 0

def loadModel(data, mdlList):
    bones = []
    
    if data[:4] == b'SKEL':
        bs = NoeBitStream(data)
        bs.seek(4)
        for x in range(bs.readInt()):
            name = noeAsciiFromBytes(bs.readBytes(bs.readInt()))
            mat = NoeMat43.fromBytes(bs.readBytes(48))
            parent = bs.readInt()
            bones.append(NoeBone(x, name, mat, None, parent))
    else:
        print('big:',BigEndian,'multiply:',MultiplyBones)
        
        if template:
            bs = NoeBitStream(rapi.loadIntoByteArray(FilePath))
            if BigEndian:
                bs.setEndian(1)
            
            bones = []
            print('num bones:', numBones)
            for x in range(numBones):
                bones.append(NoeBone(x,'name_%i'%x,NoeMat43()))
            
            for temp in template.split("off"):
                cmd = temp.split('\n');
                if cmd[0].split('[')[0].lower() == 'set':
                    bs.seek(int(cmd[0].split('[')[1].replace(']','')))
                
                for i in range(numBones):
                    for c in cmd:
                        param = c.lower().replace(']','').split('[')
                        if param[0] == "help":
                            printHELP()
                        
                        elif param[0] == "seek":
                            bs.seek(int(param[1].replace(']','')),1)
                        
                        elif param[0] == "quat":
                            arg = param[1].lower().strip().split(',')
                            quat = NoeQuat(readValue(bs,arg[0],4,True))
                            for a in arg[1:]:
                                if (a == "normalize" or a == "norm"):
                                    quat = quat.normalize()
                                if (a == "inverse" or a == "inv"):
                                    quat = NoeQuat([quat[3],quat[2],quat[1],quat[0]])
                                if (a == "transpose" or a == "trans"):
                                    quat = quat.transpose()
                            pos = bones[i].getMatrix()[3]
                            mat43 = quat.toMat43()
                            mat43[3] = pos
                            bones[i].setMatrix(mat43)
                            print('quat: ', quat)
                            
                        elif param[0] == "erad":
                            arg = param[1].lower().strip().split(',')
                            erad = NoeAngles(readValue(bs,arg[0],3,True))
                            pos = bones[i].getMatrix()[3]
                            mat43 = erad.toMat43()
                            mat43[3] = pos
                            bones[i].setMatrix(mat43)
                            print('erad: ', erad)
                            
                        elif param[0] == "edeg":
                            arg = param[1].lower().strip().split(',')
                            edeg = NoeAngles(readValue(bs,arg[0],3))
                            pos = bones[i].getMatrix()[3]
                            mat43 = edeg.toMat43()
                            mat43[3] = pos
                            bones[i].setMatrix(mat43)
                            print('edeg: ', edeg)
                        
                        elif param[0] == "mat43":
                            arg = param[1].lower().strip().split(',')
                            mat43 = NoeMat43([NoeVec3(readValue(bs,arg[0],3,True)),NoeVec3(readValue(bs,arg[0],3,True)),NoeVec3(readValue(bs,arg[0],3,True)),NoeVec3(readValue(bs,arg[0],3,True))])
                            for a in arg[1:]:
                                if (a == "inverse" or a == "inv"):
                                    mat43 = mat43.inverse()
                                if (a == "transpose" or a == "trans"):
                                    mat43 = mat43.transpose()
                                
                            bones[i].setMatrix(mat43)
                            print('mat43: ', mat43)
                        
                        elif param[0] == "mat44":
                            arg = param[1].lower().strip().split(',')
                            mat44 = NoeMat44([NoeVec4(readValue(bs,arg[0],4,True)),NoeVec4(readValue(bs,arg[0],4,True)),NoeVec4(readValue(bs,arg[0],4,True)),NoeVec4(readValue(bs,arg[0],4,True))])
                            for a in arg[1:]:
                                if (a == "inverse" or a == "inv"):
                                    mat44 = mat43.inverse()
                                if (a == "transpose" or a == "trans"):
                                    mat44 = mat43.transpose()
                                
                            bones[i].setMatrix(mat44.toMat43())
                            print('mat44: ', mat44)
                        
                        elif param[0] == "pos":
                            type = param[1].lower().strip().replace(']','')
                            mat43 = bones[i].getMatrix()
                            mat43[3] = NoeVec3(readValue(bs,type,3,True))
                            bones[i].setMatrix(mat43)
                            print('pos: ', mat43[3])
                            
                        elif param[0] == "parent":
                            arg = param[1].lower().strip().split(',')
                            if len(arg) > 1:
                                bones[i].parentIndex = None
                                bones[i].parentName = readName(bs, arg[1:])
                                print('parent: ',bones[i].parentName)
                            else:
                                bones[i].parentIndex = int(readValue(bs,arg[0]))
                                print('parent: ',bones[i].parentIndex)
                        
                        elif param[0] == "name":
                            arg = param[1].lower().strip().split(',')
                            name = readName(bs, arg)
                            print('name:',name)
                            if name:
                                bones[i].name = name
                            
            if MultiplyBones and bones:
                bones = rapi.multiplyBones(bones)
        else:
            print('Need template!')
    
    mdl = NoeModel()
    mdl.setBones(bones)
    mdlList.append(mdl)
    return 1

def readValue(bs, s, num=1, float=False):
    if s == 'int' or s == 'int32':
        val = [bs.readInt() for x in range(num)]
    elif s == 'uint' or s == 'uint32':
        val = [bs.readUInt() for x in range(num)]
    elif s == 'int64':
        val = [bs.readInt64() for x in range(num)]
    elif s == 'uint64':
        val = [bs.readUInt64() for x in range(num)]
    elif s == 'uint24' or s == 'int24':
        val = [bs.readUInt24() for x in range(num)]
    elif s == 'short' or s == 'int16':
        val = [bs.readShort() for x in range(num)]
        if float:
            val = [x/32768 for x in val]
    elif s == 'ushort' or s == 'uint16':
        val = [bs.readUShort() for x in range(num)]
        if float:
            val = [x/65536 for x in val]
    elif s == 'byte' or s == 'int8':
        val = [bs.readByte() for x in range(num)]
        if float:
            val = [x/127 for x in val]
    elif s == 'ubyte' or s == 'uint8':
        val = [bs.readUByte() for x in range(num)]
        if float:
            val = [x/256 for x in val]
    elif s == 'float' or s == 'float32':
        val = [bs.readFloat() for x in range(num)]
    elif s == 'halffloat' or s == 'half' or s == 'float16':
        val = [bs.readHalfFloat() for x in range(num)]
    elif s == 'double':
        val = [bs.readDouble() for x in range(num)]
    if num == 1:
        return val[0]
    else:
        return val

def readName(bs, arg):
    lenght = int(arg[0])
    if len(arg) > 1:
        lenght = readValue(bs, arg[1])+1;
        if len(arg) > 2:
            lenght -= 1
    
    if (lenght > 0):
        name = noeAsciiFromBytes(bs.readBytes(lenght)).strip()
        return name
        
    return None
    
def printHELP():
    text = '''help:
    types:
        -int, uint, int32, uint32
        -int24, uint24
        -short, ushort, int16, uint16
        -byte, ubyte, int8m uint8
        -float, float32
        -halfFloaf, float16, half
        -double
    option:
        -transpose - (Transposes the rows and columns of a matrix.)
        -inverse - (Inverts the specified matrix/quat)
    cmd:
        -help - (print a help text)
        -offset[int] - (The new position in the current stream(begin).divides the template into cycles)
        (all other commands will be executed in the loop as many times as the number of bones specified)
        -seek[int] - (skip specified number of bytes)
        -pos[type] - (will read a vector3 with the specified type, and set the position in the bone matrix)
        -quat[type,options] - (will read a quaternion with the specified type and automatically converted to a 4x3 matrix for the bone)
        -mat43[type,options] - (will read a 4x3 matrix with the specified type for the bone)
        -mat44[type,optins] - (will read a 4x4 matrix with the specified type and automatically converted to a 4x3 matrix for the bone)
        -name[int,type,bool] - (will read the string and assigned as the name of the bone)
        (if the string is fixed length specify only the first parameter (string length))
        (if the strings have different lengths, then the first parameter is ignored (specified as 0))
        (then the second parameter will read the specified type before the string as its length, for example int.)
        (and the 3rd parameter, specify false (in fact, it can be anything, only the presence is checked))
        (if there is no null byte after the string (\\x00), otherwise specify nothing (if there is a null byte at the end of the string).
        -parent[type,int,type,bool] - (will read the parent with the specified type for the bone)
        (if the parent is a numeric value, then specify only the first parameter. else if the parent is a string. 
        then the first parameter is ignored (specify 0). and other parameters as for the "name" command)
    '''
    print(text)

def noepyWriteModel2(mdl, bs):
    bones = mdl.bones
    bs.writeBytes(b'SKEL')
    
    #WRITE BONES
    bs.writeInt(len(bones))#num bones
    for bone in bones:
        bs.writeInt(len(bone.name))
        bs.writeString(bone.name,0)
        bs.writeBytes(bone.getMatrix().toBytes())
        bs.writeInt(bone.parentIndex)
    return 1
    
#
def noepyWriteModel(mdl, bs):
    bones = mdl.bones
    bs.writeBytes(b'SKEL')
    
    #WRITE BONES
    bs.writeInt(len(bones))#num bones
    for bone in bones:
        bs.writeInt(len(bone.name))
        bs.writeString(bone.name,0)
        bs.writeBytes(bone.getMatrix().toAngles().toBytes())
        bs.writeBytes(bone.getMatrix()[3].toBytes())
        bs.writeInt(bone.parentIndex)
    return 1

def WindowProc(hWnd, message, wParam, lParam):
    if message == noewin.WM_PAINT:
        noeWnd = noewin.getNoeWndForHWnd(hWnd)
        ps = noewin.PAINTSTRUCT()
        rect = noewin.RECT()
        hDC = noewin.user32.BeginPaint(hWnd, byref(ps))
        oldFont = None
        if noeWnd.hFont:
            oldFont = noewin.gdi32.SelectObject(hDC, noeWnd.hFont)    
        
        if oldFont:
            noewin.gdi32.SelectObject(hDC, oldFont)
        return 0
    return noewin.defaultWindowProc(hWnd, message, wParam, lParam)

#--------------------------------------------------------------------------------------------
def dialogOpenFile(noeWnd, controlId, wParam, lParam):
    #dialog = NoeUserDialog("Choose File")
    FileName = noesis.userPrompt(noesis.NOEUSERVAL_FILEPATH, "Open File", "Select any File", noesis.getSelectedFile())
    button = noeWnd.getControlById(controlId)
    
    global FilePath
    if FileName != None:
        button.userEditBox.setText(FileName)#
        FilePath = button.userEditBox.getText()
        button.userEditBox.setText(os.path.basename(FileName))
    else:
        button.userEditBox.setText('')
        FilePath = ''
    
    return True
    
def buttonRunPython(noeWnd, controlId, wParam, lParam):
    button = noeWnd.getControlById(controlId)
    #string = button.userEditBox.getText()
    
    global template, numBones
    numBones = 0
    template = button.userEditBox.getText()
    if template.split()[0].lower() == 'help':
        printHELP()
    try:
        numBones = int(button.numEditBox.getText())
    except:
        print('Error num bones!')

    if os.path.exists(FilePath) > 0:
        with open('temp_load.SkelFinder', 'w') as w:
            w.write('TEMP')
        noesis.openAndRemoveTempFile('temp_load.SkelFinder')
    else:
        print('Error file exists!', FilePath)
    return True
    
def EndianMethod(noeWnd, controlId, wParam, lParam):
    checkBox = noeWnd.getControlById(controlId)
    global BigEndian
    BigEndian = not checkBox.isChecked()
    checkBox.setChecked(noewin.BST_CHECKED if checkBox.isChecked() == 0 else noewin.BST_UNCHECKED)

def MultiplyMethod(noeWnd, controlId, wParam, lParam):
    checkBox = noeWnd.getControlById(controlId)
    global MultiplyBones
    MultiplyBones = not checkBox.isChecked()
    checkBox.setChecked(noewin.BST_CHECKED if checkBox.isChecked() == 0 else noewin.BST_UNCHECKED)
    
def SkelFinder(toolIndex):
    noesis.logPopup()
    
    noeWnd = noewin.NoeUserWindow("Skel Finder (by Durik256)", "SkelFinderClass", 228, 290, WindowProc)
    
    #offset a bit into the noesis window
    noeWindowRect = noewin.getNoesisWindowRect()
    if noeWindowRect:
        windowMargin = 64
        noeWnd.x = noeWindowRect[0] + windowMargin
        noeWnd.y = noeWindowRect[1] + windowMargin
    if not noeWnd.createWindow():
        print("Failed to create window.")
        return 0

    noeWnd.setFont("Arial", 14)
    
    noeWnd.createCheckBox("BigEndian", 10, 60, 88, 24, EndianMethod)
    noeWnd.createCheckBox("MultiplyBones", 106, 60, 120, 24, MultiplyMethod)
    
    #file block
    noeWnd.createStatic("File:", 10, 20, 30, 25)
    buttonOpenFile = noeWnd.createButton("...", 174, 16, 40, 25, dialogOpenFile)
    buttonFileSet = noeWnd.getControlByIndex(buttonOpenFile)
    FieldFile = noeWnd.createEditBox(40, 16, 130, 25, "", None, False, False)
    fileBox = noeWnd.getControlByIndex(FieldFile)
    buttonFileSet.userEditBox = fileBox
    
    #Template Field
    numField = noeWnd.createEditBox(175, 87, 40, 18, "0", None, False, False)
    numBox = noeWnd.getControlByIndex(numField)
    
    noeWnd.createStatic(">>Template:", 10, 90, 200, 55)
    
    buttonGetIndex = noeWnd.createButton("Run", 121, 224, 96, 24, buttonRunPython)
    buttonGet = noeWnd.getControlByIndex(buttonGetIndex)
    buttonGet.numEditBox = numBox
    
    editIndex = noeWnd.createEditBox(10, 110, 205, 105, "help")
    editBox = noeWnd.getControlByIndex(editIndex)
    buttonGet.userEditBox = editBox
    return 0