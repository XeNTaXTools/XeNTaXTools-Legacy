from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Dead Space 1/2/3 [PC/PS3/X360]", ".tg4h")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
	#noesis.logPopup()
	return 1

def noepyCheckType(data):
	return 1
	
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    check = bs.readUInt()
    print(check, ":check")	
    if check > bs.getSize():
        bs = NoeBitStream(data, NOE_BIGENDIAN)
        print("now using bigendian byte order")
    bs.seek(0x1c, NOESEEK_ABS)
    datasize = bs.readUInt()
    print(datasize, ":datasize")	
    imgWidth = bs.readUShort()            
    print(imgWidth, ":imgWidth")
    imgHeight = bs.readUShort()           
    print(imgHeight, ":imgHeight")
    bs.seek(0x3, NOESEEK_REL)
    flag = bs.readUByte()
    print(hex(flag), ":flag")
    bs.seek(0x2c, NOESEEK_ABS)        
    Off1 = bs.readUInt()
    bs.seek(Off1 + 1, NOESEEK_ABS)        
    Off2 = bs.readUInt()
    bs.seek(Off2, NOESEEK_ABS)        
    imgFmt = bs.readString()
    print(imgFmt, ":imgFmt")
    texMain = rapi.getLocalFileName(rapi.getInputName()).replace(".tg4h", ".tg4d")
    print(texMain, ":texMain")
    var1 = texMain[:4] #get first 4 char (0-3)
    var2 = texMain[4:] #get 4th char to end
    var1 = int(var1) + 1
    if var1 > 99 and var1 < 1000:
        var1 = str("0") + str(var1)
        print(":using one zero")
    elif var1 > 9 and var1 < 100:
        var1 = str("00") + str(var1)
        print(":using two zeros")
    elif var1 < 10:
        var1 = str("000") + str(var1) 
        print(":using three zeros")
    elif var1 > 999:
        var1 = str(var1)
        print(":using no zeros")
    texMain = var1 + var2
    print(var1 , ":var1")
    print(var2 , ":var2")
    print(texMain , "new texMain")
    texName = rapi.getDirForFilePath(rapi.getInputName()).replace("tg4h", "tg4d") + texMain
    print(texName, "texName")
    bs2 = NoeBitStream(rapi.loadIntoByteArray(texName))
    imgData = bs2.readBytes(datasize)
    if flag == 4:
        imgData = rapi.swapEndianArray(imgData, 2)
        print("X360 texture")
    #DXT1
    if imgFmt == 'DXT1' or imgFmt == 'DXT1a' or imgFmt == 'DXT1c':
        texFmt = noesis.NOESISTEX_DXT1
    #DXT5
    elif imgFmt == 'DXT5' or imgFmt == 'DXT5_NM':
        texFmt = noesis.NOESISTEX_DXT5
    #RGBA8
    elif imgFmt == 'RGBA8':
        imgData = rapi.imageDecodeRaw(imgData, imgWidth, imgHeight, "r8 g8 b8 a8")
        texFmt = noesis.NOESISTEX_RGBA32
    #RGBX8 (for a vertical scroll shader?)
    elif imgFmt == 'RGBX8':
        imgData = rapi.imageDecodeRaw(imgData, imgWidth, imgHeight, "b8 g8 r8 a8") #?
        texFmt = noesis.NOESISTEX_RGBA32
    #L8A8  
    elif imgFmt == 'L8A8':
        imgData = rapi.imageDecodeRaw(imgData, imgWidth, imgHeight, "r8 a8") #?
        texFmt = noesis.NOESISTEX_RGBA32 #?
    #L8
    elif imgFmt == 'L8':
        imgData = rapi.imageDecodeRaw(imgData, imgWidth, imgHeight, "r8") #?
        texFmt = noesis.NOESISTEX_RGBA32 #?
    #unknown, not handled
    else:
        print("WARNING: Unhandled image format")
        return None
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, imgData, texFmt))
    return 1