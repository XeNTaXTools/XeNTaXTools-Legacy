////////////////////////////////////////////////////////////////////////////////////////////////
//                                   TOTAL BYTE INFORMER                                      //
//                            Basic File Reader And Interpreter                               //
//                                  http://www.watto.org/                                     //
//                                                                                            //
//                Total Byte Informer is Copyright (C) 2002-2004  WATTO Studios               //
//                                                                                            //
// This program is free software; you can redistribute it and/or modify it under the terms of //
// the GNU General Public License published by the Free Software Foundation; either version 2 //
// of the License, or (at your option) any later version.                                     //
//                                                                                            //
// This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;  //
// without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  //
// See the GNU General Public License for more details.                                       //
//                                                                                            //
// You should have received a copy of the GNU General Public License along with this program. //
// If not, visit http://www.gnu.org or write to...                                            //
//                                                                                            //
//                            Free Software Foundation, Inc.,                                 //
//                            59 Temple Place, Suite 330,                                     //
//                            Boston, MA  02111-1307  USA                                     //
//                                                                                            //
// For further information relating to Total Byte Informer, including program updates, visit  //
// the WATTO Studios website at http://www.watto.org . Thank you.                             //
////////////////////////////////////////////////////////////////////////////////////////////////

import javax.swing.table.AbstractTableModel;

/**
**********************************************************************************************
  The model used to create the table
**********************************************************************************************
**/
public class ByteTableModel extends AbstractTableModel {

  /** The <code>ge.fileDetails</code> array **/
  public ByteData[] byteData;

  /** The program **/
  public TotalByteInformer tbi;

  String lr;


/**
**********************************************************************************************
  Constructor
**********************************************************************************************
**/
  public ByteTableModel(TotalByteInformer total, ByteData[] data, String leftright){
    tbi = total;
    byteData = data;
    lr = leftright;
    }

/**
**********************************************************************************************
  Gets the number of columns
  @return the number of columns
**********************************************************************************************
**/
  public int getColumnCount(){
    if (lr.equals("L")){
      return Integer.parseInt(tbi.leftCol.getText());
      }
    else if (lr.equals("R")){
      return Integer.parseInt(tbi.rightCol.getText());
      }
    else {
      return 0;
      }
    }

/**
**********************************************************************************************
  Gets the number of rows
  @return the number of rows
**********************************************************************************************
**/
  public int getRowCount(){
    if (lr.equals("L")){
      int cols = Integer.parseInt(tbi.leftCol.getText());
      int remainder = byteData.length % cols;

      int rows = byteData.length / cols;
      if (remainder > 0){
        rows++;
        }

      return rows;
      }
    else if (lr.equals("R")){
      int cols = Integer.parseInt(tbi.rightCol.getText());
      int remainder = byteData.length % cols;

      int rows = byteData.length / cols;
      if (remainder > 0){
        rows++;
        }

      return rows;
      }
    else {
      return 0;
      }

    }

/**
**********************************************************************************************
  Gets the name of a column
  @param col the number of the column
  @return the column name
**********************************************************************************************
**/
  public String getColumnName(int col){
    return "";
    }

/**
**********************************************************************************************
  Gets the value at a particular column and row
  @param col the number of the column
  @param row the number of the row
  @return the value of the chosen cell
**********************************************************************************************
**/
  public Object getValueAt(int row, int col){
    if (lr.equals("L")){
      int cols = Integer.parseInt(tbi.leftCol.getText());

      int byteNumber = (row*cols) + col;

      if (byteNumber < byteData.length){
        return new Integer(byteData[byteNumber].getValue());
        }
      else {
        return new Integer(0);
        }

      }
    else if (lr.equals("R")){
      int cols = Integer.parseInt(tbi.rightCol.getText());

      int byteNumber = (row*cols) + col;

      if (byteNumber < byteData.length){
        return new Integer(byteData[byteNumber].getValue());
        }
      else {
        return new Integer(0);
        }
      }
    else {
      return new Integer(0);
      }

    }

/**
**********************************************************************************************
  Gets the object class stored in a column (eg Number, String...)
  @param c the number of the column
  @return the column object class
**********************************************************************************************
**/
  public Class getColumnClass(int c){
    return getValueAt(0, c).getClass();
    }

/**
**********************************************************************************************
  Is the cell editable
  @param row the row number
  @param col the column number
  @return false
**********************************************************************************************
**/
  public boolean isCellEditable(int row, int col){
    return false;
    }

/**
**********************************************************************************************
  Ignored
**********************************************************************************************
**/
  public void setValueAt(Object value, int row, int col){
    }



/**
**********************************************************************************************
  Sets the data array
  @param data the data array
**********************************************************************************************
**/
  public void setDataArray(ByteData[] data){
    byteData = data;
    fireTableDataChanged();
    }



  }


