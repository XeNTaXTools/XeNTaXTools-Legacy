////////////////////////////////////////////////////////////////////////////////////////////////
//                                   TOTAL BYTE INFORMER                                      //
//                            Basic File Reader And Interpreter                               //
//                                  http://www.watto.org/                                     //
//                                                                                            //
//                Total Byte Informer is Copyright (C) 2002-2004  WATTO Studios               //
//                                                                                            //
// This program is free software; you can redistribute it and/or modify it under the terms of //
// the GNU General Public License published by the Free Software Foundation; either version 2 //
// of the License, or (at your option) any later version.                                     //
//                                                                                            //
// This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;  //
// without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  //
// See the GNU General Public License for more details.                                       //
//                                                                                            //
// You should have received a copy of the GNU General Public License along with this program. //
// If not, visit http://www.gnu.org or write to...                                            //
//                                                                                            //
//                            Free Software Foundation, Inc.,                                 //
//                            59 Temple Place, Suite 330,                                     //
//                            Boston, MA  02111-1307  USA                                     //
//                                                                                            //
// For further information relating to Total Byte Informer, including program updates, visit  //
// the WATTO Studios website at http://www.watto.org . Thank you.                             //
////////////////////////////////////////////////////////////////////////////////////////////////

import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;


/**
**********************************************************************************************

**********************************************************************************************
**/
public class ByteTableKeyListener implements KeyListener {

  public static TotalByteInformer tbi;


/**
**********************************************************************************************
  Constructor
**********************************************************************************************
**/
  public ByteTableKeyListener(TotalByteInformer total){
    tbi = total;
    }

/**
**********************************************************************************************

**********************************************************************************************
**/
  public void keyReleased(KeyEvent e) {

    if (e.getSource() == tbi.leftTable){
      tbi.calculate("L");
      }
    else if (e.getSource() == tbi.rightTable){
      tbi.calculate("R");
      }

    }


/**
**********************************************************************************************
  Ignored
**********************************************************************************************
**/
  public void keyTyped(KeyEvent e) {
    }

/**
**********************************************************************************************
  Ignored
**********************************************************************************************
**/
  public void keyPressed(KeyEvent e) {
    }


  }
