////////////////////////////////////////////////////////////////////////////////////////////////
//                                   TOTAL BYTE INFORMER                                      //
//                            Basic File Reader And Interpreter                               //
//                                  http://www.watto.org/                                     //
//                                                                                            //
//                Total Byte Informer is Copyright (C) 2002-2004  WATTO Studios               //
//                                                                                            //
// This program is free software; you can redistribute it and/or modify it under the terms of //
// the GNU General Public License published by the Free Software Foundation; either version 2 //
// of the License, or (at your option) any later version.                                     //
//                                                                                            //
// This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;  //
// without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  //
// See the GNU General Public License for more details.                                       //
//                                                                                            //
// You should have received a copy of the GNU General Public License along with this program. //
// If not, visit http://www.gnu.org or write to...                                            //
//                                                                                            //
//                            Free Software Foundation, Inc.,                                 //
//                            59 Temple Place, Suite 330,                                     //
//                            Boston, MA  02111-1307  USA                                     //
//                                                                                            //
// For further information relating to Total Byte Informer, including program updates, visit  //
// the WATTO Studios website at http://www.watto.org . Thank you.                             //
////////////////////////////////////////////////////////////////////////////////////////////////

/**
**********************************************************************************************
  Stores bytes
**********************************************************************************************
**/
public class ByteData{

  // value of byte
  public int value;

  // pos in array
  public int pos;


/**
**********************************************************************************************
  Constructor
**********************************************************************************************
**/
  public ByteData(){
    }


/**
**********************************************************************************************
  Constructor
**********************************************************************************************
**/
  public ByteData(int newValue, int newPos){
    value = newValue;
    if (value < 0){
      value = 256 + value;
      }
    pos = newPos;
    }



/**
**********************************************************************************************
  Gets the value
  @return the value
**********************************************************************************************
**/
  public int getValue(){
    return value;
    }

/**
**********************************************************************************************
  Gets the pos
  @return the pos
**********************************************************************************************
**/
  public int getPos(){
    return pos;
    }






/**
**********************************************************************************************
  Sets the value
  @param newValue the value
**********************************************************************************************
**/
  public void setValue(int newValue){
    value = newValue;
    }

/**
**********************************************************************************************
  Sets the pos
  @param newPos the pos
**********************************************************************************************
**/
  public void setPos(int newPos){
    pos = newPos;
    }


}