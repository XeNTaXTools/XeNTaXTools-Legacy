////////////////////////////////////////////////////////////////////////////////////////////////
//                                   TOTAL BYTE INFORMER                                      //
//                            Basic File Reader And Interpreter                               //
//                                  http://www.watto.org/                                     //
//                                                                                            //
//                Total Byte Informer is Copyright (C) 2002-2004  WATTO Studios               //
//                                                                                            //
// This program is free software; you can redistribute it and/or modify it under the terms of //
// the GNU General Public License published by the Free Software Foundation; either version 2 //
// of the License, or (at your option) any later version.                                     //
//                                                                                            //
// This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;  //
// without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  //
// See the GNU General Public License for more details.                                       //
//                                                                                            //
// You should have received a copy of the GNU General Public License along with this program. //
// If not, visit http://www.gnu.org or write to...                                            //
//                                                                                            //
//                            Free Software Foundation, Inc.,                                 //
//                            59 Temple Place, Suite 330,                                     //
//                            Boston, MA  02111-1307  USA                                     //
//                                                                                            //
// For further information relating to Total Byte Informer, including program updates, visit  //
// the WATTO Studios website at http://www.watto.org . Thank you.                             //
////////////////////////////////////////////////////////////////////////////////////////////////

import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;


/**
**********************************************************************************************

**********************************************************************************************
**/
public class CheckboxListener implements MouseListener{

  /** <code>GameExtractor</code> **/
  public static TotalByteInformer tbi;


/**
**********************************************************************************************
  Constructor
**********************************************************************************************
**/
  public CheckboxListener(TotalByteInformer total){
    tbi = total;
    }


/**
**********************************************************************************************
  Runs the <code>tbi.buttomClicked</code> method when the button is clicked.
  @param e The <code>MouseEvent</code> that was triggered
**********************************************************************************************
**/
  public void mouseClicked(MouseEvent e){
    tbi.checkboxClicked((javax.swing.JCheckBox)e.getSource());
    }


/**
**********************************************************************************************

**********************************************************************************************
**/
  public void mouseEntered(MouseEvent e){
    }


/**
**********************************************************************************************

**********************************************************************************************
**/
  public void mouseExited(MouseEvent e){
    }


/**
**********************************************************************************************
  Ignored
**********************************************************************************************
**/
  public void mousePressed(MouseEvent e){
    }


/**
**********************************************************************************************
  Ignored
**********************************************************************************************
**/
  public void mouseReleased(MouseEvent e){
    }


  }