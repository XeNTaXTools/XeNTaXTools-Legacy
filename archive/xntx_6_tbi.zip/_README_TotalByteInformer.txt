
 +====================================================================================+
                                   Total Byte Informer
                                  http://www.watto.org/

                           Designed and Coded by WATTO Studios
                                    Copyright 2004
 +====================================================================================+


 +====================================================================================+
                                    ABOUT THE PROGRAM
 +====================================================================================+

 Total Byte Informer is a simple program that displays information about the structure
 of a file. It was initially developed in Visual Basic to help determine the structure
 of gaming files, however it can be used for any file you wish.
 
 Unlike a hex editor, Total Byte Informer displays the bytes of the file as numbers, to
 make it quick and easy to understand. The string representation of each byte is also
 presented next to the byte number.

 By clicking on a byte of the file, Total Byte Informer displays full information about
 the values at that point in the file, including all typical number types from binary
 to long.

 Total Byte Informer contains 2 windows, that allow you to load files side-by-side and
 make comparisons between them. The program also allows you to seek to any part of the
 files, and view any number of bytes per row as you like.


 +====================================================================================+
                                    INSTALLATION
 +====================================================================================+

 Total Byte Informer is written in Java, which allows it to be run on any computer. In
 order to run this program, you must therefore download Java Runtime Environment 1.4+
 from http://www.java.com. The download is free, and it will allow you to run many other
 programs, and allows interaction with Java webpages. A direct link to the installation
 file for Java Runtime Environment is provided on the Total Byte Informer website.

 IF YOU ARE INSTALLING THIS VERSION OVER THE TOP OF AN OLDER VERSION, PLEASE ENSURE YOU
 DELETE THE OLD VERSION FIRST, OTHERWISE CONFLICTIONS BETWEEN FILES MAY OCCUR.

 WINDOWS - Method 1
 =======
 * Install Java Runtime Environment
 * Unzip the Total Byte Informer *.zip archive to your computer
 * Open "My Computer" and go to the directory where you unzipped Total Byte Informer
 * Run the program called TotalByteInformer.exe

 WINDOWS - Method 2
 =======
 * Install Java Runtime Environment to C:\java
 * Unzip the Total Byte Informer *.zip archive to C:\tbi
 * Open "My Computer" and go to the C:\tbi directory
 * Run the file called TotalByteInformer.bat

 WINDOWS - Method 3
 =======
 * Install Java Runtime Environment (In this example, we assume you install it to C:\java)
 * Unzip the Total Byte Informer *.zip archive (In this example, we assume you unzip it to C:\tbi)
 * Open MS-DOS Prompt (command prompt in WinXP) from the StartMenu-->Programs
 * Type "cd c:\tbi" (without the quotes) to go to the Total Byte Informer directory
 * Type "c:\java\bin\java.exe TotalByteInformer" (without the quotes) to run the program

 LINUX/MAC/OTHER
 ===============
 * Install Java Runtime Environment (In this example, we assume you install it to C:\java).
 * Extract the Total Byte Informer *.zip archive (In this example, we assume you extract it to C:\tbi)
 * Open a text-prompt window or command-line interface (A window that allows you to type commands)
 * Type "cd c:\tbi" (without the quotes) or a similar command to change to the Total Byte Informer directory
 * Type "c:\java\bin\java.exe TotalByteInformer" (without the quotes) to run the program


 +====================================================================================+
                              RECENT CHANGES AND VERSION HISTORY
 +====================================================================================+

  Version 0.16
  - Added a filename field to the interface to show the currently opened file name
  - Added a current offset field to the interface to show the clicked position
  - Added a field to allow the user to change the number of shown bytes
  - Null byte values are now shaded with a light yellow to stand out
  - Selected cells now have a border around them
  - Fixed a bug where the Byte(B) field would show the wrong value

  Version 0.15
  - Removed the String, Float, and Double fields from the display, as they aren't used much, and took up too much space
  - Added checkboxes to allow users to toggle the display of Strings, Hex, and Number representations of bytes

  Version 0.1
  - Initial program


 +====================================================================================+
                               CONTACT THE PROGRAMMERS
 +====================================================================================+

 The Total Byte Informer website is located at http://www.watto.org . At this site, you
 will find the latest information including program updates, help, and forums.

 You may contact the creator of Total Byte Informer by sending an email to watto@watto.org .
 Please give the email an appropriate subject line, or it may be deleted as spam. Please
 Describe any error messages you might recieve when running the program, and the steps
 you took to recieve the error. JPEG/GIF image attachments are accepted, nothing else.


 +====================================================================================+
                                LEGAL INFORMATION
 +====================================================================================+

    FOR FULL AND UPDATED LEGAL INFORMATION - VISIT THE TOTAL BYTE INFORMER WEBSITE

 Total Byte Informer was developed and created entirely by WATTO Studios Copyright (C) 2004. 
 No part of the program may be decrypted, reverse engineered, or used for any purpose
 other than that intended by the program. No part of this program may be used with the
 deliberate intention of causing harm or loss to people and/or organizations. WATTO 
 Studios takes no responsibility for loss or damage suffered through use of this software.

 For all legal issues, complaints, or criticisms, please contact me, I will do my best
 to address the issue as soon as possible. Thanks.


 +====================================================================================+
                         Thanks for reading ... Enjoy the program!
 +====================================================================================+
