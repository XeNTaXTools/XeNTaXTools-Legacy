////////////////////////////////////////////////////////////////////////////////////////////////
//                                   TOTAL BYTE INFORMER                                      //
//                            Basic File Reader And Interpreter                               //
//                                  http://www.watto.org/                                     //
//                                                                                            //
//                Total Byte Informer is Copyright (C) 2002-2004  WATTO Studios               //
//                                                                                            //
// This program is free software; you can redistribute it and/or modify it under the terms of //
// the GNU General Public License published by the Free Software Foundation; either version 2 //
// of the License, or (at your option) any later version.                                     //
//                                                                                            //
// This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;  //
// without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  //
// See the GNU General Public License for more details.                                       //
//                                                                                            //
// You should have received a copy of the GNU General Public License along with this program. //
// If not, visit http://www.gnu.org or write to...                                            //
//                                                                                            //
//                            Free Software Foundation, Inc.,                                 //
//                            59 Temple Place, Suite 330,                                     //
//                            Boston, MA  02111-1307  USA                                     //
//                                                                                            //
// For further information relating to Total Byte Informer, including program updates, visit  //
// the WATTO Studios website at http://www.watto.org . Thank you.                             //
////////////////////////////////////////////////////////////////////////////////////////////////

import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import javax.swing.JButton;


/**
**********************************************************************************************
  Changes the <code>tbi.statusbar</code> text to reflect the tooltip of a button, and simultaneously
  listens for clicks on the button, passing the event on to the program
**********************************************************************************************
**/
public class ButtonListener implements MouseListener{

  /** <code>GameExtractor</code> **/
  public static TotalByteInformer tbi;

  /** the previous message in the <code>ge.statusbar</code> **/
  public static String oldStatus;


/**
**********************************************************************************************
  Constructor that sets the instance of the program
  @param total The program instance
**********************************************************************************************
**/
  public ButtonListener(TotalByteInformer total){
    tbi = total;
    }


/**
**********************************************************************************************
  Runs the <code>tbi.buttomClicked</code> method when the button is clicked.
  @param e The <code>MouseEvent</code> that was triggered
**********************************************************************************************
**/
  public void mouseClicked(MouseEvent e){
    tbi.buttonClicked((JButton)e.getSource());
    }


/**
**********************************************************************************************
  Displays the buttons tooltip in the <code>tbi.statusbar</code> when the mouse moves over the
  button
  @param e The <code>MouseEvent</code> that was triggered
**********************************************************************************************
**/
  public void mouseEntered(MouseEvent e){
    oldStatus = tbi.statusbar.getText();
    tbi.statusbar.setText(((JButton)e.getSource()).getToolTipText());
    }


/**
**********************************************************************************************
  Resets the text in the <code>tbi.statusbar</code> back to the original (<code>oldStatus</code>)
  message when the mouse leaves the button
  @param e The <code>MouseEvent</code> that was triggered
**********************************************************************************************
**/
  public void mouseExited(MouseEvent e){
    if (tbi.statusbar.getText() == ((JButton)e.getSource()).getToolTipText()){
      tbi.statusbar.setText(oldStatus);
      }
    }


/**
**********************************************************************************************
  Ignored
**********************************************************************************************
**/
  public void mousePressed(MouseEvent e){
    }


/**
**********************************************************************************************
  Ignored
**********************************************************************************************
**/
  public void mouseReleased(MouseEvent e){
    }


  }