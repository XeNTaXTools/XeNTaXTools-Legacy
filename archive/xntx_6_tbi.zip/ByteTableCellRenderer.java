////////////////////////////////////////////////////////////////////////////////////////////////
//                                   TOTAL BYTE INFORMER                                      //
//                            Basic File Reader And Interpreter                               //
//                                  http://www.watto.org/                                     //
//                                                                                            //
//                Total Byte Informer is Copyright (C) 2002-2004  WATTO Studios               //
//                                                                                            //
// This program is free software; you can redistribute it and/or modify it under the terms of //
// the GNU General Public License published by the Free Software Foundation; either version 2 //
// of the License, or (at your option) any later version.                                     //
//                                                                                            //
// This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;  //
// without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  //
// See the GNU General Public License for more details.                                       //
//                                                                                            //
// You should have received a copy of the GNU General Public License along with this program. //
// If not, visit http://www.gnu.org or write to...                                            //
//                                                                                            //
//                            Free Software Foundation, Inc.,                                 //
//                            59 Temple Place, Suite 330,                                     //
//                            Boston, MA  02111-1307  USA                                     //
//                                                                                            //
// For further information relating to Total Byte Informer, including program updates, visit  //
// the WATTO Studios website at http://www.watto.org . Thank you.                             //
////////////////////////////////////////////////////////////////////////////////////////////////

import javax.swing.table.*;
import javax.swing.*;
import java.awt.*;

/**
**********************************************************************************************

**********************************************************************************************
**/
public class ByteTableCellRenderer extends DefaultTableCellRenderer{

  String text = " ";
  String hex = " ";
  String number = " ";

  TotalByteInformer tbi;

  String lr = "";


/**
**********************************************************************************************
  Constructor
**********************************************************************************************
**/
  public ByteTableCellRenderer(TotalByteInformer total, String leftright){
    tbi = total;
    lr = leftright;
    }


/**
**********************************************************************************************
  setValue
**********************************************************************************************
**/
  public void setValue(Object value) {

    //super.setValue(value);
    //setHorizontalAlignment(RIGHT);

    number = value.toString();

    int num = ((Integer)value).intValue();
    if (num <= 32){
      text = " ";
      }
    else {
      text = "" + (char)num;
      }


    hex = Integer.toHexString(num);
    if (hex.length() == 1){
      hex = "0" + hex;
      }

    }


/**
**********************************************************************************************
  opaque
**********************************************************************************************
**/
  public boolean isOpaque() {
    return true;
    }





/**
**********************************************************************************************
  paint
**********************************************************************************************
**/
  public void paint(Graphics g) {
    //super.paint(g);

    if (number.equals("0")){
      g.setColor(new Color(255,255,200));
      g.fillRect(0,0,getWidth(),getHeight());
      }


    paintBorder(g);


    int fromLeft = 2;

    if (lr.equals("L")){

      if (tbi.leftPaintString.isSelected()){
        g.setColor(Color.RED);
        g.drawString(text,fromLeft,getHeight()-3);
        fromLeft += 10;
        }

      if (tbi.leftPaintHex.isSelected()){
        g.setColor(Color.BLUE);
        g.drawString(hex,fromLeft,getHeight()-3);
        fromLeft += 16;
        }

      if (tbi.leftPaintNumber.isSelected()){
        if (number.length() == 1){
          fromLeft += 7;
          }
        if (number.length() == 2){
          fromLeft += 3;
          }

        g.setColor(Color.BLACK);
        g.drawString(number,fromLeft,getHeight()-3);
        fromLeft += 25;
        }

      }
    if (lr.equals("R")){
      if (tbi.rightPaintString.isSelected()){
        g.setColor(Color.RED);
        g.drawString(text,fromLeft,getHeight()-3);
        fromLeft += 10;
        }

      if (tbi.rightPaintHex.isSelected()){
        g.setColor(Color.BLUE);
        g.drawString(hex,fromLeft,getHeight()-3);
        fromLeft += 16;
        }

      if (tbi.rightPaintNumber.isSelected()){
        if (number.length() == 1){
          fromLeft += 7;
          }
        if (number.length() == 2){
          fromLeft += 3;
          }

        g.setColor(Color.BLACK);
        g.drawString(number,fromLeft,getHeight()-3);
        fromLeft += 25;
        }

      }

    }


}