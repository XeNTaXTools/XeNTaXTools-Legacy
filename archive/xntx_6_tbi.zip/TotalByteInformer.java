////////////////////////////////////////////////////////////////////////////////////////////////
//                                   TOTAL BYTE INFORMER                                      //
//                            Basic File Reader And Interpreter                               //
//                                  http://www.watto.org/                                     //
//                                                                                            //
//                Total Byte Informer is Copyright (C) 2002-2004  WATTO Studios               //
//                                                                                            //
// This program is free software; you can redistribute it and/or modify it under the terms of //
// the GNU General Public License published by the Free Software Foundation; either version 2 //
// of the License, or (at your option) any later version.                                     //
//                                                                                            //
// This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;  //
// without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  //
// See the GNU General Public License for more details.                                       //
//                                                                                            //
// You should have received a copy of the GNU General Public License along with this program. //
// If not, visit http://www.gnu.org or write to...                                            //
//                                                                                            //
//                            Free Software Foundation, Inc.,                                 //
//                            59 Temple Place, Suite 330,                                     //
//                            Boston, MA  02111-1307  USA                                     //
//                                                                                            //
// For further information relating to Total Byte Informer, including program updates, visit  //
// the WATTO Studios website at http://www.watto.org . Thank you.                             //
////////////////////////////////////////////////////////////////////////////////////////////////

/*******************************************/
/* THE BIG BIG LIST OF THINGS I NEED TO DO */
/*******************************************/

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

/**
**********************************************************************************************
  Total Byte Informer
**********************************************************************************************
**/
public class TotalByteInformer extends JFrame {

  /** The current version of the program **/
  public static double programVersion = 0.16;

  /** The global interface window **/
  public Container frame;


  String globalFilePath = "";


  ByteData[] leftByteData = new ByteData[0];
  ByteData[] rightByteData = new ByteData[0];

  String leftFile = "";
  String rightFile = "";

  FileManipulator leftFm;
  FileManipulator rightFm;


  JCheckBox leftPaintString = new JCheckBox("",false);
  JCheckBox leftPaintNumber = new JCheckBox("",true);
  JCheckBox leftPaintHex = new JCheckBox("",false);

  JCheckBox rightPaintString = new JCheckBox("",false);
  JCheckBox rightPaintNumber = new JCheckBox("",true);
  JCheckBox rightPaintHex = new JCheckBox("",false);


  JPanel leftPanel = new JPanel(new BorderLayout(3,3));
  JPanel rightPanel = new JPanel(new BorderLayout(3,3));
  //JPanel splitWindow = new JPanel(new GridLayout(1,2));
  JSplitPane splitWindow;

  JTable leftTable = new JTable();
  JTable rightTable = new JTable();

  JTextField leftPos = new JTextField("0");
  JTextField rightPos = new JTextField("0");

  JTextField leftCol = new JTextField("8");
  JTextField rightCol = new JTextField("8");

  JTextField leftNumBytes = new JTextField("1000");
  JTextField rightNumBytes = new JTextField("1000");

  JTextField leftFilename = new JTextField("");
  JTextField rightFilename = new JTextField("");

  JTextField leftOffset = new JTextField("0");
  JTextField rightOffset = new JTextField("0");


  JTextField leftBitL = new JTextField();
  JTextField leftByteL = new JTextField();
  JTextField leftShortL = new JTextField();
  JTextField leftIntL = new JTextField();
  JTextField leftLongL = new JTextField();

  JTextField leftBitB = new JTextField();
  JTextField leftByteB = new JTextField();
  JTextField leftShortB = new JTextField();
  JTextField leftIntB = new JTextField();
  JTextField leftLongB = new JTextField();

  JTextField rightBitL = new JTextField();
  JTextField rightByteL = new JTextField();
  JTextField rightShortL = new JTextField();
  JTextField rightIntL = new JTextField();
  JTextField rightLongL = new JTextField();

  JTextField rightBitB = new JTextField();
  JTextField rightByteB = new JTextField();
  JTextField rightShortB = new JTextField();
  JTextField rightIntB = new JTextField();
  JTextField rightLongB = new JTextField();



  /** The status bar **/
  public JLabel statusbar = new JLabel();

  /** The button toolbar **/
  public JToolBar buttonbar = new JToolBar();


  public JButton but_leftOpenFile;
  public JButton but_rightOpenFile;


/**
**********************************************************************************************
  Constructor
**********************************************************************************************
**/
  public TotalByteInformer() {
    try {

      setTitle("Total Byte Informer " + programVersion);

      frame = this.getContentPane();
      frame.setLayout(new BorderLayout());

      loadButtons();
      loadInterface();

      //splitWindow.add(leftPanel);
      //splitWindow.add(rightPanel);
      splitWindow = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,leftPanel,rightPanel);
      frame.add(splitWindow,BorderLayout.CENTER);

      setIconImage(new ImageIcon("icon.gif").getImage());

      pack();
      setExtendedState(JFrame.MAXIMIZED_BOTH);
      splitWindow.setDividerLocation(0.5);
      show();


      System.out.println("NOTE [TBI] - Interface Constructed");

      }
    catch (Exception e){
      System.out.println("ERROR [TBI] - " + e);
      e.printStackTrace();
      }
    }


/**
**********************************************************************************************
  Generates the buttons
**********************************************************************************************
**/
  public void loadButtons() {

    ButtonListener bl = new ButtonListener(this);

    but_leftOpenFile = new JButton("    Open File    ");
    but_leftOpenFile.addMouseListener(bl);
    buttonbar.add(but_leftOpenFile);

    but_rightOpenFile = new JButton("    Open File    ");
    but_rightOpenFile.addMouseListener(bl);
    buttonbar.add(but_rightOpenFile);



    CheckboxListener cbl = new CheckboxListener(this);

    leftPaintString.addMouseListener(cbl);
    leftPaintNumber.addMouseListener(cbl);
    leftPaintHex.addMouseListener(cbl);

    rightPaintString.addMouseListener(cbl);
    rightPaintNumber.addMouseListener(cbl);
    rightPaintHex.addMouseListener(cbl);

    System.out.println("NOTE [TBI] - Buttons Loaded");

    }


/**
**********************************************************************************************
  Generates the interface
**********************************************************************************************
**/
  public void loadInterface() {

    ReloadTableKeyListener kl = new ReloadTableKeyListener(this);



    JPanel leftLables = new JPanel(new GridLayout(23,1));
    JPanel leftFields = new JPanel(new GridLayout(23,1));

    leftLables.add(new JLabel("Bits (L)"));
    leftLables.add(new JLabel("Bits (B)"));
    leftLables.add(new JLabel("Byte (L)"));
    leftLables.add(new JLabel("Byte (B)"));
    leftLables.add(new JLabel("Short (L)"));
    leftLables.add(new JLabel("Short (B)"));
    leftLables.add(new JLabel("Int (L)"));
    leftLables.add(new JLabel("Int (B)"));
    leftLables.add(new JLabel("Long (L)"));
    leftLables.add(new JLabel("Long (B)"));
    leftLables.add(new JLabel(""));
    leftLables.add(new JLabel("File Offset"));
    leftLables.add(new JLabel("Show Columns"));
    leftLables.add(new JLabel("Loaded Bytes"));
    leftLables.add(new JLabel(""));
    leftLables.add(new JLabel("File:"));
    leftLables.add(new JLabel("Current File"));
    leftLables.add(new JLabel("Current Offset"));
    leftLables.add(new JLabel(""));
    leftLables.add(new JLabel("Show Numbers"));
    leftLables.add(new JLabel("Show Strings"));
    leftLables.add(new JLabel("Show Hex"));
    leftLables.add(new JLabel("Notes"));

    leftFields.add(leftBitL);
    leftFields.add(leftBitB);
    leftFields.add(leftByteL);
    leftFields.add(leftByteB);
    leftFields.add(leftShortL);
    leftFields.add(leftShortB);
    leftFields.add(leftIntL);
    leftFields.add(leftIntB);
    leftFields.add(leftLongL);
    leftFields.add(leftLongB);
    leftFields.add(new JLabel(""));
    leftFields.add(leftPos);
    leftFields.add(leftCol);
    leftFields.add(leftNumBytes);
    leftFields.add(new JLabel(""));
    leftFields.add(but_leftOpenFile);
    leftFields.add(leftFilename);
    leftFields.add(leftOffset);
    leftFields.add(new JLabel(""));
    leftFields.add(leftPaintNumber);
    leftFields.add(leftPaintString);
    leftFields.add(leftPaintHex);
    leftFields.add(new JLabel(""));



    leftPos.addKeyListener(kl);
    leftCol.addKeyListener(kl);
    leftNumBytes.addKeyListener(kl);


    JPanel leftGroup = new JPanel(new BorderLayout());
    leftGroup.add(leftLables,BorderLayout.WEST);
    leftGroup.add(leftFields,BorderLayout.CENTER);


    JPanel leftGroupFixed = new JPanel(new BorderLayout());
    leftGroupFixed.add(leftGroup,BorderLayout.NORTH);
    leftGroupFixed.add(new JScrollPane(new JTextArea("")),BorderLayout.CENTER);

    JSplitPane leftSplit = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftGroupFixed,new JScrollPane(leftTable));

    leftPanel.add(leftSplit,BorderLayout.CENTER);




    JPanel rightLables = new JPanel(new GridLayout(23,1));
    JPanel rightFields = new JPanel(new GridLayout(23,1));

    rightLables.add(new JLabel("Bits (L)"));
    rightLables.add(new JLabel("Bits (B)"));
    rightLables.add(new JLabel("Byte (L)"));
    rightLables.add(new JLabel("Byte (B)"));
    rightLables.add(new JLabel("Short (L)"));
    rightLables.add(new JLabel("Short (B)"));
    rightLables.add(new JLabel("Int (L)"));
    rightLables.add(new JLabel("Int (B)"));
    rightLables.add(new JLabel("Long (L)"));
    rightLables.add(new JLabel("Long (B)"));
    rightLables.add(new JLabel(""));
    rightLables.add(new JLabel("File Offset"));
    rightLables.add(new JLabel("Show Columns"));
    rightLables.add(new JLabel("Loaded Bytes"));
    rightLables.add(new JLabel(""));
    rightLables.add(new JLabel("File:"));
    rightLables.add(new JLabel("Current File"));
    rightLables.add(new JLabel("Current Offset"));
    rightLables.add(new JLabel(""));
    rightLables.add(new JLabel("Show Numbers"));
    rightLables.add(new JLabel("Show Strings"));
    rightLables.add(new JLabel("Show Hex"));
    rightLables.add(new JLabel("Notes"));

    rightFields.add(rightBitL);
    rightFields.add(rightBitB);
    rightFields.add(rightByteL);
    rightFields.add(rightByteB);
    rightFields.add(rightShortL);
    rightFields.add(rightShortB);
    rightFields.add(rightIntL);
    rightFields.add(rightIntB);
    rightFields.add(rightLongL);
    rightFields.add(rightLongB);
    rightFields.add(new JLabel(""));
    rightFields.add(rightPos);
    rightFields.add(rightCol);
    rightFields.add(rightNumBytes);
    rightFields.add(new JLabel(""));
    rightFields.add(but_rightOpenFile);
    rightFields.add(rightFilename);
    rightFields.add(rightOffset);
    rightFields.add(new JLabel(""));
    rightFields.add(rightPaintNumber);
    rightFields.add(rightPaintString);
    rightFields.add(rightPaintHex);
    rightFields.add(new JLabel(""));



    rightPos.addKeyListener(kl);
    rightCol.addKeyListener(kl);
    rightNumBytes.addKeyListener(kl);


    JPanel rightGroup = new JPanel(new BorderLayout());
    rightGroup.add(rightLables,BorderLayout.WEST);
    rightGroup.add(rightFields,BorderLayout.CENTER);


    JPanel rightGroupFixed = new JPanel(new BorderLayout());
    rightGroupFixed.add(rightGroup,BorderLayout.NORTH);
    rightGroupFixed.add(new JScrollPane(new JTextArea("")),BorderLayout.CENTER);

    JSplitPane rightSplit = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, rightGroupFixed,new JScrollPane(rightTable));

    rightPanel.add(rightSplit,BorderLayout.CENTER);



    leftTable.setCellSelectionEnabled(false);
    //leftTable.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);

    rightTable.setCellSelectionEnabled(false);
    //rightTable.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);

    leftTable.addMouseListener(new ByteTableMouseListener(this));
    rightTable.addMouseListener(new ByteTableMouseListener(this));

    leftTable.addKeyListener(new ByteTableKeyListener(this));
    rightTable.addKeyListener(new ByteTableKeyListener(this));
    }




/**
**********************************************************************************************
  Opens a file, and constructs the table
**********************************************************************************************
**/
  public void openFile(String lr){
    try {

      JFileChooser fc = new JFileChooser(globalFilePath);
      fc.showOpenDialog(this);

      String path = fc.getSelectedFile().getPath();
      globalFilePath = fc.getSelectedFile().getParent();

      if (lr.equals("L")){

        leftFile = path;
        leftFilename.setText(new File(path).getName());

        leftFm = new FileManipulator(path,"r");

        leftFm.seek(Integer.parseInt(leftPos.getText()));

        leftByteData = new ByteData[Integer.parseInt(leftNumBytes.getText())];
        byte[] fileIn = new byte[Integer.parseInt(leftNumBytes.getText())];
        leftFm.read(fileIn);

        for (int i=0;i<fileIn.length;i++){
          leftByteData[i] = new ByteData(fileIn[i],i);
          }

        leftTable.setModel(new ByteTableModel(this,leftByteData,"L"));

        ByteTableCellRenderer rend = new ByteTableCellRenderer(this,"L");
        for (int i=0;i<Integer.parseInt(leftCol.getText());i++){
          leftTable.getColumnModel().getColumn(i).setCellRenderer(rend);
          }

        leftFm.close();

        }

      else if (lr.equals("R")){

        rightFile = path;
        rightFilename.setText(new File(path).getName());

        rightFm = new FileManipulator(path,"r");

        rightFm.seek(Integer.parseInt(rightPos.getText()));

        rightByteData = new ByteData[Integer.parseInt(rightNumBytes.getText())];
        byte[] fileIn = new byte[Integer.parseInt(rightNumBytes.getText())];
        rightFm.read(fileIn);

        for (int i=0;i<fileIn.length;i++){
          rightByteData[i] = new ByteData(fileIn[i],i);
          }

        rightTable.setModel(new ByteTableModel(this,rightByteData,"R"));

        ByteTableCellRenderer rend = new ByteTableCellRenderer(this,"R");
        for (int i=0;i<Integer.parseInt(rightCol.getText());i++){
          rightTable.getColumnModel().getColumn(i).setCellRenderer(rend);
          }

        rightFm.close();

        }

      }
    catch (Exception e){
      System.out.println("ERROR [TBI] - " + e);
      e.printStackTrace();
      }
    }



/**
**********************************************************************************************
  Calculates the numbers
**********************************************************************************************
**/
  public void calculate(String lr){
    try {

      if (lr.equals("L")){

        int row = leftTable.getSelectedRow();
        int col = leftTable.getSelectedColumn();

        int cellNum = (row * Integer.parseInt(leftCol.getText())) + col;

        leftOffset.setText("" + cellNum);

        int value = leftByteData[cellNum].getValue();
        int value1 = 0;
        int value2 = 0;
        int value3 = 0;
        int value4 = 0;
        int value5 = 0;
        int value6 = 0;
        int value7 = 0;

        if (cellNum + 1 < Integer.parseInt(leftNumBytes.getText())){
          value1 = leftByteData[cellNum+1].getValue();
          }
        if (cellNum + 2 < Integer.parseInt(leftNumBytes.getText())){
          value2 = leftByteData[cellNum+2].getValue();
          }
        if (cellNum + 3 < Integer.parseInt(leftNumBytes.getText())){
          value3 = leftByteData[cellNum+3].getValue();
          }
        if (cellNum + 4 < Integer.parseInt(leftNumBytes.getText())){
          value4 = leftByteData[cellNum+4].getValue();
          }
        if (cellNum + 5 < Integer.parseInt(leftNumBytes.getText())){
          value5 = leftByteData[cellNum+5].getValue();
          }
        if (cellNum + 6 < Integer.parseInt(leftNumBytes.getText())){
          value6 = leftByteData[cellNum+6].getValue();
          }
        if (cellNum + 7 < Integer.parseInt(leftNumBytes.getText())){
          value7 = leftByteData[cellNum+7].getValue();
          }

        // bits
        boolean[] bitsL = leftFm.byte2bitL((byte)value);
        boolean[] bitsB = leftFm.byte2bitB((byte)value);

        String bitL = "";
        String bitB = "";

        for (int i=0;i<bitsL.length;i++){
          if (bitsL[i]){
            bitL += "1 ";
            }
          else {
            bitL += "0 ";
            }
          }

        for (int i=0;i<bitsB.length;i++){
          if (bitsB[i]){
            bitB += "1 ";
            }
          else {
            bitB += "0 ";
            }
          }

        leftBitL.setText("" + bitL);
        leftBitB.setText("" + bitB);


        // bytes
        int valueRev = leftFm.bit2byteL(bitsB);
        if (valueRev < 0){
          valueRev = 256 + valueRev;
          }

        leftByteL.setText("" + value);
        leftByteB.setText("" + (valueRev));


        // short
        byte[] shorts = new byte[]{(byte)value,(byte)value1};

        leftShortL.setText("" + leftFm.byte2shortL(shorts));
        leftShortB.setText("" + leftFm.byte2shortB(shorts));


        // int
        byte[] ints = new byte[]{(byte)value,(byte)value1,(byte)value2,(byte)value3};

        leftIntL.setText("" + leftFm.byte2intL(ints));
        leftIntB.setText("" + leftFm.byte2intB(ints));


        // long
        byte[] longs = new byte[]{(byte)value,(byte)value1,(byte)value2,(byte)value3,(byte)value4,(byte)value5,(byte)value6,(byte)value7};

        leftLongL.setText("" + leftFm.byte2longL(longs));
        leftLongB.setText("" + leftFm.byte2longB(longs));


        }
      else if (lr.equals("R")){

        int row = rightTable.getSelectedRow();
        int col = rightTable.getSelectedColumn();

        int cellNum = (row * Integer.parseInt(rightCol.getText())) + col;

        rightOffset.setText("" + cellNum);

        int value = rightByteData[cellNum].getValue();
        int value1 = 0;
        int value2 = 0;
        int value3 = 0;
        int value4 = 0;
        int value5 = 0;
        int value6 = 0;
        int value7 = 0;

        if (cellNum + 1 < Integer.parseInt(rightNumBytes.getText())){
          value1 = rightByteData[cellNum+1].getValue();
          }
        if (cellNum + 2 < Integer.parseInt(rightNumBytes.getText())){
          value2 = rightByteData[cellNum+2].getValue();
          }
        if (cellNum + 3 < Integer.parseInt(rightNumBytes.getText())){
          value3 = rightByteData[cellNum+3].getValue();
          }
        if (cellNum + 4 < Integer.parseInt(rightNumBytes.getText())){
          value4 = rightByteData[cellNum+4].getValue();
          }
        if (cellNum + 5 < Integer.parseInt(rightNumBytes.getText())){
          value5 = rightByteData[cellNum+5].getValue();
          }
        if (cellNum + 6 < Integer.parseInt(rightNumBytes.getText())){
          value6 = rightByteData[cellNum+6].getValue();
          }
        if (cellNum + 7 < Integer.parseInt(rightNumBytes.getText())){
          value7 = rightByteData[cellNum+7].getValue();
          }

        // bits
        boolean[] bitsL = rightFm.byte2bitL((byte)value);
        boolean[] bitsB = rightFm.byte2bitB((byte)value);

        String bitL = "";
        String bitB = "";

        for (int i=0;i<bitsL.length;i++){
          if (bitsL[i]){
            bitL += "1 ";
            }
          else {
            bitL += "0 ";
            }
          }

        for (int i=0;i<bitsB.length;i++){
          if (bitsB[i]){
            bitB += "1 ";
            }
          else {
            bitB += "0 ";
            }
          }

        rightBitL.setText("" + bitL);
        rightBitB.setText("" + bitB);


        // bytes
        int valueRev = rightFm.bit2byteL(bitsB);
        if (valueRev < 0){
          valueRev = 256 + valueRev;
          }

        rightByteL.setText("" + value);
        rightByteB.setText("" + (valueRev));


        // short
        byte[] shorts = new byte[]{(byte)value,(byte)value1};

        rightShortL.setText("" + rightFm.byte2shortL(shorts));
        rightShortB.setText("" + rightFm.byte2shortB(shorts));


        // int
        byte[] ints = new byte[]{(byte)value,(byte)value1,(byte)value2,(byte)value3};

        rightIntL.setText("" + rightFm.byte2intL(ints));
        rightIntB.setText("" + rightFm.byte2intB(ints));


        // long
        byte[] longs = new byte[]{(byte)value,(byte)value1,(byte)value2,(byte)value3,(byte)value4,(byte)value5,(byte)value6,(byte)value7};

        rightLongL.setText("" + rightFm.byte2longL(longs));
        rightLongB.setText("" + rightFm.byte2longB(longs));


        }

      }
    catch (Exception e){
      System.out.println("ERROR [TBI] - " + e);
      e.printStackTrace();
      }
    }




/**
**********************************************************************************************
  Opens a file, and constructs the table
**********************************************************************************************
**/
  public void reloadTable(String lr){
    try {

      if (lr.equals("L")){

        if (leftTable.getModel() == null){
          return;
          }
        if (Integer.parseInt(leftPos.getText()) < 0){
          return;
          }
        if (Integer.parseInt(leftCol.getText()) < 0){
          return;
          }

        String path = leftFile;

        leftFm = new FileManipulator(path,"r");

        leftFm.seek(Integer.parseInt(leftPos.getText()));

        leftByteData = new ByteData[Integer.parseInt(leftNumBytes.getText())];
        byte[] fileIn = new byte[Integer.parseInt(leftNumBytes.getText())];
        leftFm.read(fileIn);

        for (int i=0;i<fileIn.length;i++){
          leftByteData[i] = new ByteData(fileIn[i],i);
          }

        leftTable.setModel(new ByteTableModel(this,leftByteData,"L"));

        ByteTableCellRenderer rend = new ByteTableCellRenderer(this,"L");
        for (int i=0;i<Integer.parseInt(leftCol.getText());i++){
          leftTable.getColumnModel().getColumn(i).setCellRenderer(rend);
          }

        leftFm.close();

        }

      else if (lr.equals("R")){

        if (rightTable.getModel() == null){
          return;
          }
        if (Integer.parseInt(rightPos.getText()) < 0){
          return;
          }
        if (Integer.parseInt(rightCol.getText()) < 0){
          return;
          }

        String path = rightFile;

        rightFm = new FileManipulator(path,"r");

        rightFm.seek(Integer.parseInt(rightPos.getText()));

        rightByteData = new ByteData[Integer.parseInt(rightNumBytes.getText())];
        byte[] fileIn = new byte[Integer.parseInt(rightNumBytes.getText())];
        rightFm.read(fileIn);

        for (int i=0;i<fileIn.length;i++){
          rightByteData[i] = new ByteData(fileIn[i],i);
          }

        rightTable.setModel(new ByteTableModel(this,rightByteData,"R"));

        ByteTableCellRenderer rend = new ByteTableCellRenderer(this,"R");
        for (int i=0;i<Integer.parseInt(rightCol.getText());i++){
          rightTable.getColumnModel().getColumn(i).setCellRenderer(rend);
          }

        rightFm.close();

        }

      }
    catch (Exception e){
      System.out.println("ERROR [TBI] - " + e);
      e.printStackTrace();
      }
    }




/**
**********************************************************************************************
  Closes the program
**********************************************************************************************
**/
  public void closeProgram(){
    try {

      System.exit(0);

      }
    catch (Exception e){
      System.out.println("ERROR [TBI] - " + e);
      e.printStackTrace();
      }
    }






///// LISTENER METHODS /////


/**
**********************************************************************************************
  Used by the button listener to link the buttons to their specific methods
**********************************************************************************************
**/
  public void buttonClicked(JButton buttonObj) {

    if (buttonObj==but_leftOpenFile){
      openFile("L");
      }
    else if (buttonObj==but_rightOpenFile){
      openFile("R");
      }

    }


/**
**********************************************************************************************
  Used by the checkbox listener
**********************************************************************************************
**/
  public void checkboxClicked(JCheckBox boxObj) {

    if (boxObj==leftPaintString){
      reloadTable("L");
      }
    else if (boxObj==leftPaintNumber){
      reloadTable("L");
      }
    else if (boxObj==leftPaintHex){
      reloadTable("L");
      }
    else if (boxObj==rightPaintString){
      reloadTable("R");
      }
    else if (boxObj==rightPaintNumber){
      reloadTable("R");
      }
    else if (boxObj==rightPaintHex){
      reloadTable("R");
      }

    }




/**
**********************************************************************************************
  The main method
**********************************************************************************************
**/
  public static void main(String[] args) {

    final TotalByteInformer tbi = new TotalByteInformer();
    WindowAdapter closingWin = new WindowAdapter(){
      public void windowClosing(WindowEvent e){
        tbi.closeProgram();
        }
      };
    tbi.addWindowListener(closingWin);

    }
  }

