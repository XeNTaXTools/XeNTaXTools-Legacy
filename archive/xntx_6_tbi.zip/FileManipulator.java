//////////////////////////////////////////////////////////////////////////////////////////////
//                                    File Manipulator                                      //
//                      Generic Multi-Purpose File Reader and Writer                        //
//                                 http://www.watto.org                                     //
//                                                                                          //
//                 File Manipulator is Copyright (C) 2002-2004  WATTO Studios               //
//                                                                                          //
//  This program is free software; you can redistribute it and/or modify it under the terms //
//  of the GNU General Public License as published by the Free Software Foundation; either  //
//  version 2 of the License, or (at your option) any later version.                        //
//                                                                                          //
//  This program is distributed in the hope that it will be useful, but WITHOUT WARRANTY;   //
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR PARTICULAR PURPOSE. //
//  See the GNU General Public License for more details.                                    //
//                                                                                          //
//  A copy of the GNU General Public License is available from http://www.gnu.org or from   //
//                                                                                          //
//                              Free Software Foundation, Inc.,                             //
//                              59 Temple Place, Suite 330,                                 //
//                              Boston, MA  02111-1307  USA                                 //
//                                                                                          //
//  For further information relating to File Manipulator and other WATTO Studios programs,  //
//  visit the official website at http://www.watto.org . Thank you.                         //
//////////////////////////////////////////////////////////////////////////////////////////////

import java.io.RandomAccessFile;
import java.io.IOException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.FileDescriptor;
import java.nio.ByteOrder;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.DoubleBuffer;
import java.nio.FloatBuffer;
import java.nio.LongBuffer;
import java.nio.ShortBuffer;
import java.nio.IntBuffer;
import java.nio.channels.FileChannel;


/**
**********************************************************************************************
  Generic Multi-Purpose File Reader and Writer class. Read and write virtually any type of basic
  data to/from a file. Also contains a set of format converters.
  <BR><BR>
  This class is intended to replace the RandomAccessFile class by providing support for reading
  and writing Little-Endian and Big-Endian formats, aswell as providing a much greater range
  or reading and writing methods to cover most possible reading and writing needs.
  <BR><BR>
  Little-endian (Intel) and Big-endian (Motorola) formats are supported for most methods, and
  are specified by a <I>L</I> or <I>B</I> respectively in the method name. The generic methods
  will use the format specified by the <I>format</I> variable (default: Little-endian). This is
  set in the constructor, or by running the <I>setFormat(int encFormat)</I> method
  <BR><BR>
  This class has been constructed by WATTO Studios with input from other sources. WATTO Studios
  greatly thanks the following people and organisations for their contribution...<BR>
  Sun Microsystems (java.nio.Bits source code)<BR>
  Markus Hahn (Blowfish cryptography source code)<BR>
  <BR><BR>
  Please Note: The binary/bit methods in this class are not designed for use as a stream of bits,
  such as for reading entire files in binary form. Please see the BinaryStream class at WATTO
  Studios (http://www.watto.org) for a buffered stream suitable for reading and writing streams
  of bits to a file.
**********************************************************************************************
**/

public class FileManipulator implements DataInput, DataOutput{

  /** Little-Endian (Intel) format **/
  public static final int LITTLE_ENDIAN = 0;
  /** Big-Endian (Motorola) format **/
  public static final int BIG_ENDIAN = 1;

  /** Little-Endian (Intel) format **/
  public static final int INTEL = 0;
  /** Big-Endian (Motorola) format **/
  public static final int MOTOROLA = 1;

  /** Whether the Little-endian or Big-endian format will be used when running generic methods **/
  private int format = LITTLE_ENDIAN;


  /** A table of hex values **/
  private final static char[] hexTable = new char[]{'0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f'};

  /** The RandomAccessFile that forms the basis of this class **/
  RandomAccessFile raf;


/////////////////////////////////////
//                                 //
//  CONSTRUCTORS                   //
//                                 //
/////////////////////////////////////


/**
**********************************************************************************************
  Constructor that creates a file stream to read from, and optionally to write to.
  @param file the file object
  @param mode the access mode. Normally use either "r" or "rw" - for more information see the RandomAccessFile API documentation
  @see java.io.RandomAccessFile
**********************************************************************************************
**/
  public FileManipulator(File file, String mode) throws FileNotFoundException{
    raf = new RandomAccessFile(file,mode);
    }

/**
**********************************************************************************************
  Constructor that creates a file stream to read from, and optionally to write to.
  @param file the file object
  @param mode the access mode. Normally use either "r" or "rw" - for more information see the RandomAccessFile API documentation
  @see java.io.RandomAccessFile
**********************************************************************************************
**/
  public FileManipulator(String file, String mode) throws FileNotFoundException{
    raf = new RandomAccessFile(file,mode);
    }

/**
**********************************************************************************************
  Constructor that creates a file stream to read from, and optionally to write to. The encoding format is also specified.
  @param file the file object
  @param mode the access mode. Normally use either "r" or "rw" - for more information see the RandomAccessFile API documentation
  @param encFormat the encoding format to use in generic methods. Either LITTLE_ENDIAN (INTEL) or BIG_ENDIAN (MOTOROLA)
  @see java.io.RandomAccessFile
**********************************************************************************************
**/
  public FileManipulator(File file, String mode, int encFormat) throws FileNotFoundException{
    raf = new RandomAccessFile(file,mode);
    if (encFormat == 0 || encFormat == 1){
      format = encFormat;
      }
    }


/**
**********************************************************************************************
  Constructor that creates a file stream to read from, and optionally to write to. The encoding format is also specified.
  @param file the file object
  @param mode the access mode. Normally use either "r" or "rw" - for more information see the RandomAccessFile API documentation
  @param encFormat the encoding format to use in generic methods. Either LITTLE_ENDIAN (INTEL) or BIG_ENDIAN (MOTOROLA)
  @see java.io.RandomAccessFile
**********************************************************************************************
**/
  public FileManipulator(String file, String mode, int encFormat) throws FileNotFoundException{
    raf = new RandomAccessFile(file,mode);
    if (encFormat == 0 || encFormat == 1){
      format = encFormat;
      }
    }


/**
**********************************************************************************************
  Constructor that creates a file stream to read from and write to.
  @param file the file object
**********************************************************************************************
**/
  public FileManipulator(File file) throws FileNotFoundException{
    raf = new RandomAccessFile(file,"rw");
    }

/**
**********************************************************************************************
  Constructor that creates a file stream to read from and write to.
  @param file the file object
**********************************************************************************************
**/
  public FileManipulator(String file) throws FileNotFoundException{
    raf = new RandomAccessFile(file,"rw");
    }


/**
**********************************************************************************************
  Constructor that creates a file stream to read from and write to. The encoding format is also specified.
  @param file the file object
  @param encFormat the encoding format to use in generic methods. Either LITTLE_ENDIAN (INTEL) or BIG_ENDIAN (MOTOROLA)
**********************************************************************************************
**/
  public FileManipulator(File file, int encFormat) throws FileNotFoundException{
    raf = new RandomAccessFile(file,"rw");
    }

/**
**********************************************************************************************
  Constructor that creates a file stream to read from and write to. The encoding format is also specified.
  @param file the file object
  @param encFormat the encoding format to use in generic methods. Either LITTLE_ENDIAN (INTEL) or BIG_ENDIAN (MOTOROLA)
**********************************************************************************************
**/
  public FileManipulator(String file, int encFormat) throws FileNotFoundException{
    raf = new RandomAccessFile(file,"rw");
    }


////////////////////////////////////////
//                                    //
//  FILE_MANIPULATOR WORKING METHODS  //
//                                    //
////////////////////////////////////////

/**
**********************************************************************************************
  Sets the encoding format to use when running generic methods
  @return the encoding format being used by generic methods. Either LITTLE_ENDIAN (INTEL) or BIG_ENDIAN (MOTOROLA)
**********************************************************************************************
**/
  public int getFormat() throws IOException{
    return format;
    }

/**
**********************************************************************************************
  Sets the encoding format to use when running generic methods
  @param encFormat the encoding format to use in generic methods. Either LITTLE_ENDIAN (INTEL) or BIG_ENDIAN (MOTOROLA)
**********************************************************************************************
**/
  public void setFormat(int encFormat) throws IOException{
    format = encFormat;
    }


/////////////////////////////////////////////
//                                         //
//  RANDOM_ACCESS_FILE STANDARD METHODS    //
//                                         //
/////////////////////////////////////////////


/**
**********************************************************************************************
  Closes the file stream and releases any system resources associated with the stream.
  @see java.io.RandomAccessFile
**********************************************************************************************
**/
  public void close() throws IOException{
    raf.close();
    }


/**
**********************************************************************************************
  Returns the unique FileChannel object associated with this file.
  @return the file channel associated with this file
  @see java.io.RandomAccessFile
**********************************************************************************************
**/
  public FileChannel getChannel() throws IOException{
    return raf.getChannel();
    }


/**
**********************************************************************************************
  Returns the opaque file descriptor object associated with this stream.
  @return the file descriptor object associated with this stream.
  @see java.io.RandomAccessFile
**********************************************************************************************
**/
  public FileDescriptor getFD() throws IOException{
    return raf.getFD();
    }


/**
**********************************************************************************************
  Returns the current offset in this file.
  @return the offset from the start of the file, in bytes, at which the next read or write occurs
  @see java.io.RandomAccessFile
**********************************************************************************************
**/
  public long getFilePointer() throws IOException{
    return raf.getFilePointer();
    }


/**
**********************************************************************************************
  Returns the length of this file.
  @return the length of this file, measured in bytes.
  @see java.io.RandomAccessFile
**********************************************************************************************
**/
  public long length() throws IOException{
    return raf.length();
    }


/**
**********************************************************************************************
  Reads a byte of data from this file.
  @return the next byte of data, or -1 if the end of the file has been reached.
  @see java.io.RandomAccessFile
**********************************************************************************************
**/
  public int read() throws IOException{
    return raf.read();
    }


/**
**********************************************************************************************
  Reads up to buffer.length bytes of data from this file into an array of bytes.
  @param buffer the buffer into which the data is read
  @return the total number of bytes read into the buffer, or -1 if there is no more data
          because the end of this file has been reached.
  @see java.io.RandomAccessFile
**********************************************************************************************
**/
  public int read(byte[] buffer) throws IOException{
    return raf.read(buffer);
    }


/**
**********************************************************************************************
  Reads up to length bytes of data from this file into an array of bytes
  @param buffer the buffer into which the data is read
  @param offset the start offset of the data.
  @param length the maximum number of bytes read
  @return the total number of bytes read into the buffer, or -1 if there is no more data
          because the end of the file has been reached
  @see java.io.RandomAccessFile
**********************************************************************************************
**/
  public int read(byte[] buffer, int offset, int length) throws IOException{
    return raf.read(buffer,offset,length);
    }


/**
**********************************************************************************************
  Reads a boolean from this file
  @return the boolean value read.
  @see java.io.RandomAccessFile
**********************************************************************************************
**/
  public boolean readBoolean() throws IOException{
    return raf.readBoolean();
    }


/**
**********************************************************************************************
  Reads buffer.length bytes from this file into the byte array, starting at the current file pointer.
  @param buffer the buffer into which the data is read
  @see java.io.RandomAccessFile
**********************************************************************************************
**/
  public void readFully(byte[] buffer) throws IOException{
    raf.readFully(buffer);
    }


/**
**********************************************************************************************
  Reads exactly len bytes from this file into the byte array, starting at the current file pointer
  @param buffer the buffer into which the data is read
  @param offset the start offset of the data.
  @param length the maximum number of bytes read
  @see java.io.RandomAccessFile
**********************************************************************************************
**/
  public void readFully(byte[] buffer, int offset, int length) throws IOException{
    raf.readFully(buffer,offset,length);
    }


/**
**********************************************************************************************
  Reads the next line of text from this file
  @return the next line of text from this file, or null if end of file is encountered before
          even one byte is read.
  @see java.io.RandomAccessFile
**********************************************************************************************
**/
  public String readLine() throws IOException{
    return raf.readLine();
    }


/**
**********************************************************************************************
  Reads in a string from this file.
  @return a Unicode string.
  @see java.io.RandomAccessFile
**********************************************************************************************
**/
  public String readUTF() throws IOException{
    return raf.readUTF();
    }


/**
**********************************************************************************************
  Sets the file-pointer offset, measured from the beginning of this file, at which the next read
  or write occurs.
  @param position the offset position, measured in bytes from the beginning of the file, at
                  which to set the file pointer.
  @see java.io.RandomAccessFile
**********************************************************************************************
**/
  public void seek(long position) throws IOException{
    raf.seek(position);
    }


/**
**********************************************************************************************
  Sets the length of this file.
  @param newLength The desired length of the file
  @see java.io.RandomAccessFile
**********************************************************************************************
**/
  public void setLength(long newLength) throws IOException{
    raf.setLength(newLength);
    }


/**
**********************************************************************************************
  Attempts to skip over numToSkip bytes of input discarding the skipped bytes.
  @param numToSkip the number of bytes to be skipped
  @return the actual number of bytes skipped
  @see java.io.RandomAccessFile
**********************************************************************************************
**/
  public int skipBytes(int numToSkip) throws IOException{
    return raf.skipBytes(numToSkip);
    }


/**
**********************************************************************************************
  Writes the specified byte to this file.
  @param b the byte to be written.
  @see java.io.RandomAccessFile
**********************************************************************************************
**/
  public void write(int b) throws IOException{
    raf.write(b);
    }


/**
**********************************************************************************************
  Writes buffer.length bytes from the specified byte array to this file, starting at the current
  file pointer
  @param buffer the data
  @see java.io.RandomAccessFile
**********************************************************************************************
**/
  public void write(byte[] buffer) throws IOException{
    raf.write(buffer);
    }


/**
**********************************************************************************************
  Writes length bytes from the specified byte array starting at offset offset to this file
  @param buffer the data
  @param offset the start offset in the data.
  @param length the number of bytes to write
  @see java.io.RandomAccessFile
**********************************************************************************************
**/
  public void write(byte[] buffer, int offset, int length) throws IOException{
    raf.write(buffer,offset,length);
    }


/**
**********************************************************************************************
  Writes a boolean to the file as a one-byte value
  @param bool the boolean value to be written
  @see java.io.RandomAccessFile
**********************************************************************************************
**/
  public void writeBoolean(boolean bool) throws IOException{
    raf.writeBoolean(bool);
    }


/**
**********************************************************************************************
  Writes the string to the file as a sequence of bytes
  @param str a string of bytes to be written
  @see java.io.RandomAccessFile
**********************************************************************************************
**/
  public void writeBytes(String str) throws IOException{
    raf.writeBytes(str);
    }


/**
**********************************************************************************************
  Writes a string to the file as a sequence of characters
  @param str a String value to be written
  @see java.io.RandomAccessFile
**********************************************************************************************
**/
  public void writeChars(String str) throws IOException{
    raf.writeChars(str);
    }


/**
**********************************************************************************************
  Writes a string to the file using UTF-8 encoding in a machine-independent manner
  @param str a string to be written.
  @see java.io.RandomAccessFile
**********************************************************************************************
**/
  public void writeUTF(String str) throws IOException{
    raf.writeUTF(str);
    }


/**
**********************************************************************************************
  Writes a char to the file as a two-byte value
  @param character a char value to be written.
**********************************************************************************************
**/
  public void writeChar(int character) throws IOException{
    writeChar((char)character);
    }





/////////////////////////////////////////////
//                                         //
//  RANDOM_ACCESS_FILE ADDITIONAL METHODS  //
//                                         //
/////////////////////////////////////////////


/**
**********************************************************************************************
  Gets the current position of the pointer within the file
  @return the pointer position
**********************************************************************************************
**/
  public long getPosition() throws IOException{
    return getFilePointer();
    }

/**
**********************************************************************************************
  Gets the current position of the pointer within the file
  @return the pointer position
**********************************************************************************************
**/
  public long getOffset() throws IOException{
    return getFilePointer();
    }


/**
**********************************************************************************************
  Gets the length of the file
  @return the length of the file
**********************************************************************************************
**/
  public long getLength() throws IOException{
    return length();
    }

/**
**********************************************************************************************
  Gets the length of the file
  @return the length of the file
**********************************************************************************************
**/
  public long getSize() throws IOException{
    return length();
    }

/**
**********************************************************************************************
  Sets the length of the file
  @param size the length of the file
**********************************************************************************************
**/
  public void setSize(long size) throws IOException{
    setLength(size);
    }

/**
**********************************************************************************************
  Skips forward a number of bytes
  @param numBytes the number of bytes to skip
**********************************************************************************************
**/
  public void skip(int numBytes) throws IOException{
    skipBytes(numBytes);
    }

/**
**********************************************************************************************
  Skips forward a number of bytes
  @param numBytes the number of bytes to skip
**********************************************************************************************
**/
  public void forward(int numBytes) throws IOException{
    skipBytes(numBytes);
    }

/**
**********************************************************************************************
  Skips forward a number of bytes
  @param numBytes the number of bytes to skip
**********************************************************************************************
**/
  public void skipForward(int numBytes) throws IOException{
    skipBytes(numBytes);
    }

/**
**********************************************************************************************
  Skips forward a number of bytes
  @param numBytes the number of bytes to skip
**********************************************************************************************
**/
  public void goForward(int numBytes) throws IOException{
    skipBytes(numBytes);
    }

/**
**********************************************************************************************
  Skips backwards a number of bytes
  @param numBytes the number of bytes to skip
**********************************************************************************************
**/
  public void back(long numBytes) throws IOException{
    seek(getFilePointer() - numBytes);
    }

/**
**********************************************************************************************
  Skips backwards a number of bytes
  @param numBytes the number of bytes to skip
**********************************************************************************************
**/
  public void skipBack(long numBytes) throws IOException{
    seek(getFilePointer() - numBytes);
    }

/**
**********************************************************************************************
  Skips backwards a number of bytes
  @param numBytes the number of bytes to skip
**********************************************************************************************
**/
  public void goBack(long numBytes) throws IOException{
    seek(getFilePointer() - numBytes);
    }


/**
**********************************************************************************************
  Skips to a particular position in the file
  @param position the position to move to
**********************************************************************************************
**/
  public void skipTo(long position) throws IOException{
    seek(position);
    }














//////////////////////////////////////
//                                  //
//  READ METHODS                    //
//                                  //
//////////////////////////////////////

///////////////////
// SHORT METHODS //
///////////////////

/**
**********************************************************************************************
  Reads a 16-bit short number.
  @return the number
**********************************************************************************************
**/
  public short readShort() throws IOException{
    if (format == LITTLE_ENDIAN){
      return readShortL();
      }
    else {
      return readShortB();
      }
    }

/**
**********************************************************************************************
  Reads a 16-bit short number in Little-Endian order.
  @return the number
**********************************************************************************************
**/
  public short readShortL() throws IOException{
    byte[] temp_b = new byte[2];
    read(temp_b);
    return byte2shortL(temp_b);
    }

/**
**********************************************************************************************
  Reads a 16-bit short number in Big-Endian order.
  @return the number
**********************************************************************************************
**/
  public short readShortB() throws IOException{
    byte[] temp_b = new byte[2];
    read(temp_b);
    return byte2shortB(temp_b);
    }

/**
**********************************************************************************************
  Reads an unsigned 16-bit short number.
  @return the number
**********************************************************************************************
**/
  public int readUnsignedShort() throws IOException{
    short number = readShort();
    if (number > 32767 || number < -32767){
      return (short)(0 - number);
      }
    else {
      return number;
      }
    }

/**
**********************************************************************************************
  Reads an unsigned 16-bit short number in Little-Endian order.
  @return the number
**********************************************************************************************
**/
  public short readUnsignedShortL() throws IOException{
    short number = readShortL();
    if (number > 32767 || number < -32767){
      return (short)(0 - number);
      }
    else {
      return number;
      }
    }

/**
**********************************************************************************************
  Reads an unsigned 16-bit short number in Big-Endian order.
  @return the number
**********************************************************************************************
**/
  public short readUnsignedShortB() throws IOException{
    short number = readShortB();
    if (number > 32767 || number < -32767){
      return (short)(0 - number);
      }
    else {
      return number;
      }
    }


//////////////////
// WORD METHODS //
//////////////////

/**
**********************************************************************************************
  Reads a 16-bit WORD.
  @return the WORD
**********************************************************************************************
**/
  public short readWord() throws IOException{
    return readShort();
    }

/**
**********************************************************************************************
  Reads a 16-bit WORD in Little-Endian order.
  @return the WORD
**********************************************************************************************
**/
  public short readWordL() throws IOException{
    return readShortL();
    }

/**
**********************************************************************************************
  Reads a 16-bit WORD in Big-Endian order.
  @return the WORD
**********************************************************************************************
**/
  public short readWordB() throws IOException{
    return readShortB();
    }

/**
**********************************************************************************************
  Reads an unsigned 16-bit WORD.
  @return the WORD
**********************************************************************************************
**/
  public short readUnsignedWord() throws IOException{
    return (short)readUnsignedShort();
    }

/**
**********************************************************************************************
  Reads an unsigned 16-bit WORD in Little-Endian order.
  @return the WORD
**********************************************************************************************
**/
  public short readUnsignedWordL() throws IOException{
    return readUnsignedShortL();
    }

/**
**********************************************************************************************
  Reads an unsigned 16-bit WORD in Big-Endian order.
  @return the WORD
**********************************************************************************************
**/
  public short readUnsignedWordB() throws IOException{
    return readUnsignedShortB();
    }


/////////////////
// INT METHODS //
/////////////////

/**
**********************************************************************************************
  Reads a 32-bit integer number.
  @return the number
**********************************************************************************************
**/
  public int readInt() throws IOException{
    if (format == LITTLE_ENDIAN){
      return readIntL();
      }
    else {
      return readIntB();
      }
    }

/**
**********************************************************************************************
  Reads a 32-bit integer number in Little-Endian order.
  @return the number
**********************************************************************************************
**/
  public int readIntL() throws IOException{
    byte[] temp_b = new byte[4];
    read(temp_b);
    return byte2intL(temp_b);
    }

/**
**********************************************************************************************
  Reads a 32-bit integer number in Big-Endian order.
  @return the number
**********************************************************************************************
**/
  public int readIntB() throws IOException{
    byte[] temp_b = new byte[4];
    read(temp_b);
    return byte2intB(temp_b);
    }

/**
**********************************************************************************************
  Reads an unsigned 32-bit int number.
  @return the number
**********************************************************************************************
**/
  public int readUnsignedInt() throws IOException{
    int number = readInt();
    if (number > 2147483647 || number < -2147483647){
      return (int)(0 - number);
      }
    else {
      return number;
      }
    }

/**
**********************************************************************************************
  Reads an unsigned 32-bit int number in Little-Endian order.
  @return the number
**********************************************************************************************
**/
  public int readUnsignedIntL() throws IOException{
    int number = readIntL();
    if (number > 2147483647 || number < -2147483647){
      return (int)(0 - number);
      }
    else {
      return number;
      }
    }

/**
**********************************************************************************************
  Reads an unsigned 32-bit int number in Big-Endian order.
  @return the number
**********************************************************************************************
**/
  public int readUnsignedIntB() throws IOException{
    int number = readIntB();
    if (number > 2147483647 || number < -2147483647){
      return (int)(0 - number);
      }
    else {
      return number;
      }
    }


///////////////////
// DWORD METHODS //
///////////////////

/**
**********************************************************************************************
  Reads a 32-bit DWORD.
  @return the DWORD
**********************************************************************************************
**/
  public int readDword() throws IOException{
    return readInt();
    }

/**
**********************************************************************************************
  Reads a 32-bit DWORD in Little-Endian order.
  @return the DWORD
**********************************************************************************************
**/
  public int readDwordL() throws IOException{
    return readIntL();
    }

/**
**********************************************************************************************
  Reads a 32-bit DWORD in Big-Endian order.
  @return the DWORD
**********************************************************************************************
**/
  public int readDwordB() throws IOException{
    return readIntB();
    }

/**
**********************************************************************************************
  Reads an unsigned 32-bit DWORD.
  @return the DWORD
**********************************************************************************************
**/
  public int readUnsignedDword() throws IOException{
    return readUnsignedInt();
    }

/**
**********************************************************************************************
  Reads an unsigned 32-bit DWORD in Little-Endian order.
  @return the DWORD
**********************************************************************************************
**/
  public int readUnsignedDwordL() throws IOException{
    return readUnsignedIntL();
    }

/**
**********************************************************************************************
  Reads an unsigned 32-bit DWORD in Big-Endian order.
  @return the DWORD
**********************************************************************************************
**/
  public int readUnsignedDwordB() throws IOException{
    return readUnsignedIntB();
    }


//////////////////
// LONG METHODS //
//////////////////

/**
**********************************************************************************************
  Reads a 64-bit long number.
  @return the number
**********************************************************************************************
**/
  public long readLong() throws IOException{
    if (format == LITTLE_ENDIAN){
      return readLongL();
      }
    else {
      return readLongB();
      }
    }

/**
**********************************************************************************************
  Reads a 64-bit long number in Little-Endian order.
  @return the number
**********************************************************************************************
**/
  public long readLongL() throws IOException{
    byte[] temp_b = new byte[8];
    read(temp_b);
    return byte2longL(temp_b);
    }

/**
**********************************************************************************************
  Reads a 64-bit long number in Big-Endian order.
  @return the number
**********************************************************************************************
**/
  public long readLongB() throws IOException{
    byte[] temp_b = new byte[8];
    read(temp_b);
    return byte2longB(temp_b);
    }

/**
**********************************************************************************************
  Reads an unsigned 64-bit long number.
  @return the number
**********************************************************************************************
**/
  public long readUnsignedLong() throws IOException{
    long number = readLong();
    if (number > 9223372036854775807L || number < -9223372036854775807L){
      return (long)(0 - number);
      }
    else {
      return number;
      }
    }

/**
**********************************************************************************************
  Reads an unsigned 64-bit long number in Little-Endian order.
  @return the number
**********************************************************************************************
**/
  public long readUnsignedLongL() throws IOException{
    long number = readLongL();
    if (number > 9223372036854775807L || number < -9223372036854775807L){
      return (long)(0 - number);
      }
    else {
      return number;
      }
    }

/**
**********************************************************************************************
  Reads an unsigned 64-bit long number in Big-Endian order.
  @return the number
**********************************************************************************************
**/
  public long readUnsignedLongB() throws IOException{
    long number = readLongB();
    if (number > 9223372036854775807L || number < -9223372036854775807L){
      return (long)(0 - number);
      }
    else {
      return number;
      }
    }


///////////////////
// LONGINT METHODS //
///////////////////

/**
**********************************************************************************************
  Reads a 64-bit LONGINT.
  @return the LONGINT
**********************************************************************************************
**/
  public long readLongint() throws IOException{
    return readInt();
    }

/**
**********************************************************************************************
  Reads a 64-bit LONGINT in Little-Endian order.
  @return the LONGINT
**********************************************************************************************
**/
  public long readLongintL() throws IOException{
    return readIntL();
    }

/**
**********************************************************************************************
  Reads a 64-bit LONGINT in Big-Endian order.
  @return the LONGINT
**********************************************************************************************
**/
  public long readLongintB() throws IOException{
    return readIntB();
    }

/**
**********************************************************************************************
  Reads an unsigned 64-bit LONGINT.
  @return the LONGINT
**********************************************************************************************
**/
  public long readUnsignedLongint() throws IOException{
    return readUnsignedInt();
    }

/**
**********************************************************************************************
  Reads an unsigned 64-bit LONGINT in Little-Endian order.
  @return the LONGINT
**********************************************************************************************
**/
  public long readUnsignedLongintL() throws IOException{
    return readUnsignedIntL();
    }

/**
**********************************************************************************************
  Reads an unsigned 64-bit LONGINT in Big-Endian order.
  @return the LONGINT
**********************************************************************************************
**/
  public long readUnsignedLongintB() throws IOException{
    return readUnsignedIntB();
    }


///////////////////
// FLOAT METHODS //
///////////////////

/**
**********************************************************************************************
  Reads a 32-bit float number.
  @return the number
**********************************************************************************************
**/
  public float readFloat() throws IOException{
    if (format == LITTLE_ENDIAN){
      return readFloatL();
      }
    else {
      return readFloatB();
      }
    }

/**
**********************************************************************************************
  Reads a 32-bit float number in Little-Endian order.
  @return the number
**********************************************************************************************
**/
  public float readFloatL() throws IOException{
    byte[] temp_b = new byte[4];
    read(temp_b);
    return byte2floatL(temp_b);
    }

/**
**********************************************************************************************
  Reads a 32-bit float number in Big-Endian order.
  @return the number
**********************************************************************************************
**/
  public float readFloatB() throws IOException{
    byte[] temp_b = new byte[4];
    read(temp_b);
    return byte2floatB(temp_b);
    }

/**
**********************************************************************************************
  Reads an unsigned 32-bit float number.
  @return the number
**********************************************************************************************
**/
  public float readUnsignedFloat() throws IOException{
    float number = readFloat();
    if (number > 2147483647.0f || number < -2147483647.0f){
      return (float)(0 - number);
      }
    else {
      return number;
      }
    }

/**
**********************************************************************************************
  Reads an unsigned 32-bit float number in Little-Endian order.
  @return the number
**********************************************************************************************
**/
  public float readUnsignedFloatL() throws IOException{
    float number = readFloatL();
    if (number > 2147483647.0f || number < -2147483647.0f){
      return (float)(0 - number);
      }
    else {
      return number;
      }
    }

/**
**********************************************************************************************
  Reads an unsigned 32-bit float number in Big-Endian order.
  @return the number
**********************************************************************************************
**/
  public float readUnsignedFloatB() throws IOException{
    float number = readFloatB();
    if (number > 2147483647.0f || number < -2147483647.0f){
      return (float)(0 - number);
      }
    else {
      return number;
      }
    }


////////////////////
// DOUBLE METHODS //
////////////////////

/**
**********************************************************************************************
  Reads a 64-bit double number.
  @return the number
**********************************************************************************************
**/
  public double readDouble() throws IOException{
    if (format == LITTLE_ENDIAN){
      return readDoubleL();
      }
    else {
      return readDoubleB();
      }
    }

/**
**********************************************************************************************
  Reads a 64-bit double number in Little-Endian order.
  @return the number
**********************************************************************************************
**/
  public double readDoubleL() throws IOException{
    byte[] temp_b = new byte[8];
    read(temp_b);
    return byte2doubleL(temp_b);
    }

/**
**********************************************************************************************
  Reads a 64-bit double number in Big-Endian order.
  @return the number
**********************************************************************************************
**/
  public double readDoubleB() throws IOException{
    byte[] temp_b = new byte[8];
    read(temp_b);
    return byte2doubleB(temp_b);
    }

/**
**********************************************************************************************
  Reads an unsigned 64-bit double number.
  @return the number
**********************************************************************************************
**/
  public double readUnsignedDouble() throws IOException{
    double number = readDouble();
    if (number > 9223372036854775807.0 || number < -9223372036854775807.0){
      return (double)(0 - number);
      }
    else {
      return number;
      }
    }

/**
**********************************************************************************************
  Reads an unsigned 64-bit double number in Little-Endian order.
  @return the number
**********************************************************************************************
**/
  public double readUnsignedDoubleL() throws IOException{
    double number = readDoubleL();
    if (number > 9223372036854775807.0 || number < -9223372036854775807.0){
      return (double)(0 - number);
      }
    else {
      return number;
      }
    }

/**
**********************************************************************************************
  Reads an unsigned 64-bit double number in Big-Endian order.
  @return the number
**********************************************************************************************
**/
  public double readUnsignedDoubleB() throws IOException{
    double number = readDoubleB();
    if (number > 9223372036854775807.0 || number < -9223372036854775807.0){
      return (double)(0 - number);
      }
    else {
      return number;
      }
    }


//////////////////
// BYTE METHODS //
//////////////////

/**
**********************************************************************************************
  Reads a byte.
  @return the byte
**********************************************************************************************
**/
  public byte readByte() throws IOException{
    return (byte) read();
    }

/**
**********************************************************************************************
  Reads a series of bytes.
  @param numBytes the number of bytes to read
  @return the bytes
**********************************************************************************************
**/
  public byte[] readBytes(int numBytes) throws IOException{
    byte[] bytes = new byte[numBytes];
    read(bytes);
    return bytes;
    }

/**
**********************************************************************************************
  Reads an unsigned byte.
  @return the byte
**********************************************************************************************
**/
  public int readUnsignedByte() throws IOException{
    byte by = readByte();
    if (by > 127 || by < -127){
      return (byte)(0-by);
      }
    else {
      return by;
      }
    }


/////////////////
// BIT METHODS //
/////////////////

/**
**********************************************************************************************
  Reads 8 bits
  @return a boolean array representing the 8 bits
**********************************************************************************************
**/
  public boolean[] readBits() throws IOException{
    if (format == LITTLE_ENDIAN){
      return readBitsL();
      }
    else {
      return readBitsB();
      }
    }

/**
**********************************************************************************************
  Reads 8 bits in Little-Endian order
  @return a boolean array representing the 8 bits
**********************************************************************************************
**/
  public boolean[] readBitsL() throws IOException{
    return byte2bitL(readByte());
    }

/**
**********************************************************************************************
  Reads 8 bits in Big-Endian order
  @return a boolean array representing the 8 bits
**********************************************************************************************
**/
  public boolean[] readBitsB() throws IOException{
    return byte2bitB(readByte());
    }


////////////////////
// STRING METHODS //
////////////////////

/**
**********************************************************************************************
  Reads a string of ASCII/ANSI text
  @param numLetters the number of letters to read
  @return the string
**********************************************************************************************
**/
  public String readString(int numLetters) throws IOException{
    byte[] temp_b = new byte[numLetters];
    read(temp_b);
    return new String(temp_b);
    }

/**
**********************************************************************************************
  Reads a string of Unicode text
  @param numLetters the number of letters to read
  @return the string
**********************************************************************************************
**/
  public String readUnicodeString(int numLetters) throws IOException{
    byte[] temp_b = new byte[numLetters * 2];
    read(temp_b);
    return byte2unicode(temp_b);
    }


/////////////////
// HEX METHODS //
/////////////////

/**
**********************************************************************************************
  Reads a series of hex values
  @param numBytes the number of bytes to read
  @return a string containing the hex values
**********************************************************************************************
**/
  public String readHex(int numBytes) throws IOException{
    byte[] temp_b = new byte[numBytes];
    read(temp_b);
    return byte2hex(temp_b);
    }


//////////////////
// CHAR METHODS //
//////////////////

/**
**********************************************************************************************
  Reads a unicode character
  @return the character
**********************************************************************************************
**/
  public char readChar() throws IOException{
    if (format == LITTLE_ENDIAN){
      return readCharL();
      }
    else {
      return readCharB();
      }
    }

/**
**********************************************************************************************
  Reads a unicode character in Little-Endian order
  @return the character
**********************************************************************************************
**/
  public char readCharL() throws IOException{
    byte[] temp_b = new byte[2];
    read(temp_b);
    return byte2charL(temp_b);
    }

/**
**********************************************************************************************
  Reads a unicode character in Big-Endian order
  @return the unicode character
**********************************************************************************************
**/
  public char readCharB() throws IOException{
    byte[] temp_b = new byte[2];
    read(temp_b);
    return byte2charB(temp_b);
    }













//////////////////////////////////////
//                                  //
//  WRITE METHODS                   //
//                                  //
//////////////////////////////////////

///////////////////
// SHORT METHODS //
///////////////////

/**
**********************************************************************************************
  Writes a 16-bit short number.
  @param number the number
**********************************************************************************************
**/
  public void writeShort(short number) throws IOException{
    if (format == LITTLE_ENDIAN){
      writeShortL(number);
      }
    else {
      writeShortB(number);
      }
    }

/**
**********************************************************************************************
  Writes a 16-bit short number in Little-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeShortL(short number) throws IOException{
    write(short2byteL(number));
    }

/**
**********************************************************************************************
  Writes a 16-bit short number in Big-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeShortB(short number) throws IOException{
    write(short2byteB(number));
    }


/**
**********************************************************************************************
  Writes a 16-bit short number.
  @param number the number
**********************************************************************************************
**/
  public void writeShort(int number) throws IOException{
    writeShort((short)number);
    }

/**
**********************************************************************************************
  Writes a 16-bit short number in Little-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeShortL(int number) throws IOException{
    writeShortL((short)number);
    }

/**
**********************************************************************************************
  Writes a 16-bit short number in Big-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeShortB(int number) throws IOException{
    writeShortB((short)number);
    }


/**
**********************************************************************************************
  Writes a 16-bit short number.
  @param number the number
**********************************************************************************************
**/
  public void writeShort(long number) throws IOException{
    writeShort((short)number);
    }

/**
**********************************************************************************************
  Writes a 16-bit short number in Little-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeShortL(long number) throws IOException{
    writeShortL((short)number);
    }

/**
**********************************************************************************************
  Writes a 16-bit short number in Big-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeShortB(long number) throws IOException{
    writeShortB((short)number);
    }


/**
**********************************************************************************************
  Writes a 16-bit short number.
  @param number the number
**********************************************************************************************
**/
  public void writeShort(float number) throws IOException{
    writeShort((short)number);
    }

/**
**********************************************************************************************
  Writes a 16-bit short number in Little-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeShortL(float number) throws IOException{
    writeShortL((short)number);
    }

/**
**********************************************************************************************
  Writes a 16-bit short number in Big-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeShortB(float number) throws IOException{
    writeShortB((short)number);
    }


/**
**********************************************************************************************
  Writes a 16-bit short number.
  @param number the number
**********************************************************************************************
**/
  public void writeShort(double number) throws IOException{
    writeShort((short)number);
    }

/**
**********************************************************************************************
  Writes a 16-bit short number in Little-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeShortL(double number) throws IOException{
    writeShortL((short)number);
    }

/**
**********************************************************************************************
  Writes a 16-bit short number in Big-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeShortB(double number) throws IOException{
    writeShortB((short)number);
    }


//////////////////
// WORD METHODS //
//////////////////

/**
**********************************************************************************************
  Writes a 16-bit WORD number.
  @param number the number
**********************************************************************************************
**/
  public void writeWord(short number) throws IOException{
    writeShort(number);
    }

/**
**********************************************************************************************
  Writes a 16-bit WORD number in Little-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeWordL(short number) throws IOException{
    writeShortL(number);
    }

/**
**********************************************************************************************
  Writes a 16-bit WORD number in Big-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeWordB(short number) throws IOException{
    writeShortB(number);
    }


/**
**********************************************************************************************
  Writes a 16-bit WORD number.
  @param number the number
**********************************************************************************************
**/
  public void writeWord(int number) throws IOException{
    writeShort(number);
    }

/**
**********************************************************************************************
  Writes a 16-bit WORD number in Little-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeWordL(int number) throws IOException{
    writeShortL(number);
    }

/**
**********************************************************************************************
  Writes a 16-bit WORD number in Big-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeWordB(int number) throws IOException{
    writeShortB(number);
    }


/**
**********************************************************************************************
  Writes a 16-bit WORD number.
  @param number the number
**********************************************************************************************
**/
  public void writeWord(long number) throws IOException{
    writeShort(number);
    }

/**
**********************************************************************************************
  Writes a 16-bit WORD number in Little-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeWordL(long number) throws IOException{
    writeShortL(number);
    }

/**
**********************************************************************************************
  Writes a 16-bit WORD number in Big-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeWordB(long number) throws IOException{
    writeShortB(number);
    }


/**
**********************************************************************************************
  Writes a 16-bit WORD number.
  @param number the number
**********************************************************************************************
**/
  public void writeWord(float number) throws IOException{
    writeShort(number);
    }

/**
**********************************************************************************************
  Writes a 16-bit WORD number in Little-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeWordL(float number) throws IOException{
    writeShortL(number);
    }

/**
**********************************************************************************************
  Writes a 16-bit WORD number in Big-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeWordB(float number) throws IOException{
    writeShortB(number);
    }


/**
**********************************************************************************************
  Writes a 16-bit WORD number.
  @param number the number
**********************************************************************************************
**/
  public void writeWord(double number) throws IOException{
    writeShort(number);
    }

/**
**********************************************************************************************
  Writes a 16-bit WORD number in Little-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeWordL(double number) throws IOException{
    writeShortL(number);
    }

/**
**********************************************************************************************
  Writes a 16-bit WORD number in Big-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeWordB(double number) throws IOException{
    writeShortB(number);
    }


/////////////////
// INT METHODS //
/////////////////

/**
**********************************************************************************************
  Writes a 32-bit int number.
  @param number the number
**********************************************************************************************
**/
  public void writeInt(int number) throws IOException{
    if (format == LITTLE_ENDIAN){
      writeIntL(number);
      }
    else {
      writeIntB(number);
      }
    }

/**
**********************************************************************************************
  Writes a 32-bit int number in Little-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeIntL(int number) throws IOException{
    write(int2byteL(number));
    }

/**
**********************************************************************************************
  Writes a 32-bit int number in Big-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeIntB(int number) throws IOException{
    write(int2byteB(number));
    }


/**
**********************************************************************************************
  Writes a 32-bit int number.
  @param number the number
**********************************************************************************************
**/
  public void writeInt(short number) throws IOException{
    writeInt((int)number);
    }

/**
**********************************************************************************************
  Writes a 32-bit int number in Little-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeIntL(short number) throws IOException{
    writeIntL((int)number);
    }

/**
**********************************************************************************************
  Writes a 32-bit int number in Big-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeIntB(short number) throws IOException{
    writeIntB((int)number);
    }


/**
**********************************************************************************************
  Writes a 32-bit int number.
  @param number the number
**********************************************************************************************
**/
  public void writeInt(long number) throws IOException{
    writeInt((int)number);
    }

/**
**********************************************************************************************
  Writes a 32-bit int number in Little-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeIntL(long number) throws IOException{
    writeIntL((int)number);
    }

/**
**********************************************************************************************
  Writes a 32-bit int number in Big-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeIntB(long number) throws IOException{
    writeIntB((int)number);
    }


/**
**********************************************************************************************
  Writes a 32-bit int number.
  @param number the number
**********************************************************************************************
**/
  public void writeInt(float number) throws IOException{
    writeInt((int)number);
    }

/**
**********************************************************************************************
  Writes a 32-bit int number in Little-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeIntL(float number) throws IOException{
    writeIntL((int)number);
    }

/**
**********************************************************************************************
  Writes a 32-bit int number in Big-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeIntB(float number) throws IOException{
    writeIntB((int)number);
    }


/**
**********************************************************************************************
  Writes a 32-bit int number.
  @param number the number
**********************************************************************************************
**/
  public void writeInt(double number) throws IOException{
    writeInt((int)number);
    }

/**
**********************************************************************************************
  Writes a 32-bit int number in Little-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeIntL(double number) throws IOException{
    writeIntL((int)number);
    }

/**
**********************************************************************************************
  Writes a 32-bit int number in Big-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeIntB(double number) throws IOException{
    writeIntB((int)number);
    }


///////////////////
// DWORD METHODS //
///////////////////

/**
**********************************************************************************************
  Writes a 32-bit DWORD number.
  @param number the number
**********************************************************************************************
**/
  public void writeDword(int number) throws IOException{
    writeInt(number);
    }

/**
**********************************************************************************************
  Writes a 32-bit DWORD number in Little-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeDwordL(int number) throws IOException{
    writeIntL(number);
    }

/**
**********************************************************************************************
  Writes a 32-bit DWORD number in Big-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeDwordB(int number) throws IOException{
    writeIntB(number);
    }


/**
**********************************************************************************************
  Writes a 32-bit DWORD number.
  @param number the number
**********************************************************************************************
**/
  public void writeDword(short number) throws IOException{
    writeInt(number);
    }

/**
**********************************************************************************************
  Writes a 32-bit DWORD number in Little-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeDwordL(short number) throws IOException{
    writeIntL(number);
    }

/**
**********************************************************************************************
  Writes a 32-bit DWORD number in Big-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeDwordB(short number) throws IOException{
    writeIntB(number);
    }


/**
**********************************************************************************************
  Writes a 32-bit DWORD number.
  @param number the number
**********************************************************************************************
**/
  public void writeDword(long number) throws IOException{
    writeInt(number);
    }

/**
**********************************************************************************************
  Writes a 32-bit DWORD number in Little-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeDwordL(long number) throws IOException{
    writeIntL(number);
    }

/**
**********************************************************************************************
  Writes a 32-bit DWORD number in Big-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeDwordB(long number) throws IOException{
    writeIntB(number);
    }


/**
**********************************************************************************************
  Writes a 32-bit DWORD number.
  @param number the number
**********************************************************************************************
**/
  public void writeDword(float number) throws IOException{
    writeInt(number);
    }

/**
**********************************************************************************************
  Writes a 32-bit DWORD number in Little-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeDwordL(float number) throws IOException{
    writeIntL(number);
    }

/**
**********************************************************************************************
  Writes a 32-bit DWORD number in Big-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeDwordB(float number) throws IOException{
    writeIntB(number);
    }


/**
**********************************************************************************************
  Writes a 32-bit DWORD number.
  @param number the number
**********************************************************************************************
**/
  public void writeDword(double number) throws IOException{
    writeInt(number);
    }

/**
**********************************************************************************************
  Writes a 32-bit DWORD number in Little-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeDwordL(double number) throws IOException{
    writeIntL(number);
    }

/**
**********************************************************************************************
  Writes a 32-bit DWORD number in Big-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeDwordB(double number) throws IOException{
    writeIntB(number);
    }


//////////////////
// LONG METHODS //
//////////////////

/**
**********************************************************************************************
  Writes a 64-bit long number.
  @param number the number
**********************************************************************************************
**/
  public void writeLong(long number) throws IOException{
    if (format == LITTLE_ENDIAN){
      writeLongL(number);
      }
    else {
      writeLongB(number);
      }
    }

/**
**********************************************************************************************
  Writes a 64-bit long number in Little-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeLongL(long number) throws IOException{
    write(long2byteL(number));
    }

/**
**********************************************************************************************
  Writes a 64-bit long number in Big-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeLongB(long number) throws IOException{
    write(long2byteB(number));
    }


/**
**********************************************************************************************
  Writes a 64-bit long number.
  @param number the number
**********************************************************************************************
**/
  public void writeLong(short number) throws IOException{
    writeLong((long)number);
    }

/**
**********************************************************************************************
  Writes a 64-bit long number in Little-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeLongL(short number) throws IOException{
    writeLongL((long)number);
    }

/**
**********************************************************************************************
  Writes a 64-bit long number in Big-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeLongB(short number) throws IOException{
    writeLongB((long)number);
    }


/**
**********************************************************************************************
  Writes a 64-bit long number.
  @param number the number
**********************************************************************************************
**/
  public void writeLong(int number) throws IOException{
    writeLong((long)number);
    }

/**
**********************************************************************************************
  Writes a 64-bit long number in Little-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeLongL(int number) throws IOException{
    writeLongL((long)number);
    }

/**
**********************************************************************************************
  Writes a 64-bit long number in Big-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeLongB(int number) throws IOException{
    writeLongB((long)number);
    }


/**
**********************************************************************************************
  Writes a 64-bit long number.
  @param number the number
**********************************************************************************************
**/
  public void writeLong(float number) throws IOException{
    writeLong((long)number);
    }

/**
**********************************************************************************************
  Writes a 64-bit long number in Little-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeLongL(float number) throws IOException{
    writeLongL((long)number);
    }

/**
**********************************************************************************************
  Writes a 64-bit long number in Big-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeLongB(float number) throws IOException{
    writeLongB((long)number);
    }


/**
**********************************************************************************************
  Writes a 64-bit long number.
  @param number the number
**********************************************************************************************
**/
  public void writeLong(double number) throws IOException{
    writeLong((long)number);
    }

/**
**********************************************************************************************
  Writes a 64-bit long number in Little-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeLongL(double number) throws IOException{
    writeLongL((long)number);
    }

/**
**********************************************************************************************
  Writes a 64-bit long number in Big-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeLongB(double number) throws IOException{
    writeLongB((long)number);
    }


/////////////////////
// LONGINT METHODS //
/////////////////////

/**
**********************************************************************************************
  Writes a 64-bit LONGINT number.
  @param number the number
**********************************************************************************************
**/
  public void writeLongint(long number) throws IOException{
    writeLong(number);
    }

/**
**********************************************************************************************
  Writes a 64-bit LONGINT number in Little-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeLongintL(long number) throws IOException{
    writeLongL(number);
    }

/**
**********************************************************************************************
  Writes a 64-bit LONGINT number in Big-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeLongintB(long number) throws IOException{
    writeLongB(number);
    }


/**
**********************************************************************************************
  Writes a 64-bit LONGINT number.
  @param number the number
**********************************************************************************************
**/
  public void writeLongint(short number) throws IOException{
    writeLong(number);
    }

/**
**********************************************************************************************
  Writes a 64-bit LONGINT number in Little-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeLongintL(short number) throws IOException{
    writeLongL(number);
    }

/**
**********************************************************************************************
  Writes a 64-bit LONGINT number in Big-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeLongintB(short number) throws IOException{
    writeLongB(number);
    }


/**
**********************************************************************************************
  Writes a 64-bit LONGINT number.
  @param number the number
**********************************************************************************************
**/
  public void writeLongint(int number) throws IOException{
    writeLong(number);
    }

/**
**********************************************************************************************
  Writes a 64-bit LONGINT number in Little-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeLongintL(int number) throws IOException{
    writeLongL(number);
    }

/**
**********************************************************************************************
  Writes a 64-bit LONGINT number in Big-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeLongintB(int number) throws IOException{
    writeLongB(number);
    }


/**
**********************************************************************************************
  Writes a 64-bit LONGINT number.
  @param number the number
**********************************************************************************************
**/
  public void writeLongint(float number) throws IOException{
    writeLong(number);
    }

/**
**********************************************************************************************
  Writes a 64-bit LONGINT number in Little-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeLongintL(float number) throws IOException{
    writeLongL(number);
    }

/**
**********************************************************************************************
  Writes a 64-bit LONGINT number in Big-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeLongintB(float number) throws IOException{
    writeLongB(number);
    }


/**
**********************************************************************************************
  Writes a 64-bit LONGINT number.
  @param number the number
**********************************************************************************************
**/
  public void writeLongint(double number) throws IOException{
    writeLong(number);
    }

/**
**********************************************************************************************
  Writes a 64-bit LONGINT number in Little-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeLongintL(double number) throws IOException{
    writeLongL(number);
    }

/**
**********************************************************************************************
  Writes a 64-bit LONGINT number in Big-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeLongintB(double number) throws IOException{
    writeLongB(number);
    }


///////////////////
// FLOAT METHODS //
///////////////////

/**
**********************************************************************************************
  Writes a 32-bit float number.
  @param number the number
**********************************************************************************************
**/
  public void writeFloat(float number) throws IOException{
    if (format == LITTLE_ENDIAN){
      writeFloatL(number);
      }
    else {
      writeFloatB(number);
      }
    }

/**
**********************************************************************************************
  Writes a 32-bit float number in Little-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeFloatL(float number) throws IOException{
    write(float2byteL(number));
    }

/**
**********************************************************************************************
  Writes a 32-bit float number in Big-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeFloatB(float number) throws IOException{
    write(float2byteB(number));
    }


/**
**********************************************************************************************
  Writes a 32-bit float number.
  @param number the number
**********************************************************************************************
**/
  public void writeFloat(short number) throws IOException{
    writeFloat((float)number);
    }

/**
**********************************************************************************************
  Writes a 32-bit float number in Little-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeFloatL(short number) throws IOException{
    writeFloatL((float)number);
    }

/**
**********************************************************************************************
  Writes a 32-bit float number in Big-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeFloatB(short number) throws IOException{
    writeFloatB((float)number);
    }


/**
**********************************************************************************************
  Writes a 32-bit float number.
  @param number the number
**********************************************************************************************
**/
  public void writeFloat(int number) throws IOException{
    writeFloat((float)number);
    }

/**
**********************************************************************************************
  Writes a 32-bit float number in Little-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeFloatL(int number) throws IOException{
    writeFloatL((float)number);
    }

/**
**********************************************************************************************
  Writes a 32-bit float number in Big-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeFloatB(int number) throws IOException{
    writeFloatB((float)number);
    }


/**
**********************************************************************************************
  Writes a 32-bit float number.
  @param number the number
**********************************************************************************************
**/
  public void writeFloat(long number) throws IOException{
    writeFloat((float)number);
    }

/**
**********************************************************************************************
  Writes a 32-bit float number in Little-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeFloatL(long number) throws IOException{
    writeFloatL((float)number);
    }

/**
**********************************************************************************************
  Writes a 32-bit float number in Big-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeFloatB(long number) throws IOException{
    writeFloatB((float)number);
    }


/**
**********************************************************************************************
  Writes a 32-bit float number.
  @param number the number
**********************************************************************************************
**/
  public void writeFloat(double number) throws IOException{
    writeFloat((float)number);
    }

/**
**********************************************************************************************
  Writes a 32-bit float number in Little-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeFloatL(double number) throws IOException{
    writeFloatL((float)number);
    }

/**
**********************************************************************************************
  Writes a 32-bit float number in Big-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeFloatB(double number) throws IOException{
    writeFloatB((float)number);
    }


////////////////////
// DOUBLE METHODS //
////////////////////

/**
**********************************************************************************************
  Writes a 64-bit double number.
  @param number the number
**********************************************************************************************
**/
  public void writeDouble(double number) throws IOException{
    if (format == LITTLE_ENDIAN){
      writeDoubleL(number);
      }
    else {
      writeDoubleB(number);
      }
    }

/**
**********************************************************************************************
  Writes a 64-bit double number in Little-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeDoubleL(double number) throws IOException{
    write(double2byteL(number));
    }

/**
**********************************************************************************************
  Writes a 64-bit double number in Big-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeDoubleB(double number) throws IOException{
    write(double2byteB(number));
    }


/**
**********************************************************************************************
  Writes a 64-bit double number.
  @param number the number
**********************************************************************************************
**/
  public void writeDouble(short number) throws IOException{
    writeDouble((double)number);
    }

/**
**********************************************************************************************
  Writes a 64-bit double number in Little-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeDoubleL(short number) throws IOException{
    writeDoubleL((double)number);
    }

/**
**********************************************************************************************
  Writes a 64-bit double number in Big-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeDoubleB(short number) throws IOException{
    writeDoubleB((double)number);
    }


/**
**********************************************************************************************
  Writes a 64-bit double number.
  @param number the number
**********************************************************************************************
**/
  public void writeDouble(int number) throws IOException{
    writeDouble((double)number);
    }

/**
**********************************************************************************************
  Writes a 64-bit double number in Little-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeDoubleL(int number) throws IOException{
    writeDoubleL((double)number);
    }

/**
**********************************************************************************************
  Writes a 64-bit double number in Big-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeDoubleB(int number) throws IOException{
    writeDoubleB((double)number);
    }


/**
**********************************************************************************************
  Writes a 64-bit double number.
  @param number the number
**********************************************************************************************
**/
  public void writeDouble(long number) throws IOException{
    writeDouble((double)number);
    }

/**
**********************************************************************************************
  Writes a 64-bit double number in Little-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeDoubleL(long number) throws IOException{
    writeDoubleL((double)number);
    }

/**
**********************************************************************************************
  Writes a 64-bit double number in Big-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeDoubleB(long number) throws IOException{
    writeDoubleB((double)number);
    }


/**
**********************************************************************************************
  Writes a 64-bit double number.
  @param number the number
**********************************************************************************************
**/
  public void writeDouble(float number) throws IOException{
    writeDouble((double)number);
    }

/**
**********************************************************************************************
  Writes a 64-bit double number in Little-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeDoubleL(float number) throws IOException{
    writeDoubleL((double)number);
    }

/**
**********************************************************************************************
  Writes a 64-bit double number in Big-Endian order
  @param number the number
**********************************************************************************************
**/
  public void writeDoubleB(float number) throws IOException{
    writeDoubleB((double)number);
    }


//////////////////
// BYTE METHODS //
//////////////////

/**
**********************************************************************************************
  Writes a byte
  @param by the byte
**********************************************************************************************
**/
  public void writeByte(byte by) throws IOException{
    write(by);
    }

/**
**********************************************************************************************
  Writes a byte
  @param by the byte
**********************************************************************************************
**/
  public void writeByte(short by) throws IOException{
    write((byte)by);
    }

/**
**********************************************************************************************
  Writes a byte
  @param by the byte
**********************************************************************************************
**/
  public void writeByte(int by) throws IOException{
    write((byte)by);
    }

/**
**********************************************************************************************
  Writes a byte
  @param by the byte
**********************************************************************************************
**/
  public void writeByte(long by) throws IOException{
    write((byte)by);
    }

/**
**********************************************************************************************
  Writes a byte
  @param by the byte
**********************************************************************************************
**/
  public void writeByte(float by) throws IOException{
    write((byte)by);
    }

/**
**********************************************************************************************
  Writes a byte
  @param by the byte
**********************************************************************************************
**/
  public void writeByte(double by) throws IOException{
    write((byte)by);
    }

/**
**********************************************************************************************
  Writes a series of bytes
  @param by the bytes
**********************************************************************************************
**/
  public void writeBytes(byte[] bytes) throws IOException{
    write(bytes);
    }

/**
**********************************************************************************************
  Writes a series of bytes
  @param by the bytes
**********************************************************************************************
**/
  public void writeBytes(int[] bytes) throws IOException{
    for (int i=0;i<bytes.length;i++){
      write((byte)bytes[i]);
      }
    }


/////////////////
// BIT METHODS //
/////////////////

/**
**********************************************************************************************
  Writes a set of 8 bits.
  @param bits a boolean array representing the 8 bits.
**********************************************************************************************
**/
  public void writeBits(boolean[] bits) throws IOException{
    if (format == LITTLE_ENDIAN){
      writeBitsL(bits);
      }
    else {
      writeBitsB(bits);
      }
    }

/**
**********************************************************************************************
  Writes a set of 8 bits in Little-Endian order
  @param bits a boolean array representing the 8 bits.
**********************************************************************************************
**/
  public void writeBitsL(boolean[] bits) throws IOException{
    write(bit2byteL(bits));
    }

/**
**********************************************************************************************
  Writes a set of 8 bits in Big-Endian order
  @param bits a boolean array representing the 8 bits.
**********************************************************************************************
**/
  public void writeBitsB(boolean[] bits) throws IOException{
    write(bit2byteB(bits));
    }


////////////////////
// STRING METHODS //
////////////////////

/**
**********************************************************************************************
  Writes a string of ASCII/ANSI text
  @param text the string
**********************************************************************************************
**/
  public void writeString(String text) throws IOException{
    writeBytes(text);
    }


/////////////////
// HEX METHODS //
/////////////////

/**
**********************************************************************************************
  Writes a series of hex values
  @param hexString the hex values as a string
**********************************************************************************************
**/
  public void writeHex(String hexString) throws IOException{
    write(hex2byte(hexString));
    }


//////////////////
// CHAR METHODS //
//////////////////

/**
**********************************************************************************************
  Writes a unicode character
  @param character the character
**********************************************************************************************
**/
  public void writeChar(char character) throws IOException{
    if (format == LITTLE_ENDIAN){
      writeCharL(character);
      }
    else {
      writeCharB(character);
      }
    }

/**
**********************************************************************************************
  Writes a unicode character in Little-Endian order
  @param character the character
**********************************************************************************************
**/
  public void writeCharL(char character) throws IOException{
    write(char2byteL(character));
    }

/**
**********************************************************************************************
  Writes a unicode character in Big-Endian order
  @param character the Unicode character
**********************************************************************************************
**/
  public void writeCharB(char character) throws IOException{
    write(char2byteB(character));
    }


////////////////////
// OBJECT METHODS //
////////////////////

/**
**********************************************************************************************
  Writes an Object to the file as a string. It is written using the objects toString() method
  @param obj the object to write as a string to the file
**********************************************************************************************
**/
  public void writeObject(Object obj) throws IOException{
    writeString(obj.toString());
    }













/////////////////////////////////////
//                                 //
//  CONVERSIONS                    //
//                                 //
/////////////////////////////////////

/////////////////////////////
// BYTE <--> SHORT METHODS //
/////////////////////////////

/**
**********************************************************************************************
  Converts a byte array into a 16-bit short number using Little-Endian order
  @param bArray the bytes to be converted to a short. The array must be of length 2
  @return the 16-bit short number
**********************************************************************************************
**/
  public short byte2shortL(byte[] bArray){
    ByteBuffer bBuffer = ByteBuffer.wrap(bArray);
    bBuffer.order(ByteOrder.LITTLE_ENDIAN);
    ShortBuffer lBuffer = bBuffer.asShortBuffer();
    return lBuffer.get();
    }

/**
**********************************************************************************************
  Converts a byte array into a 16-bit short number using Big-Endian order
  @param bArray the bytes to be converted to a short. The array must be of length 2
  @return the 16-bit short number
**********************************************************************************************
**/
  public short byte2shortB(byte[] bArray){
    ByteBuffer bBuffer = ByteBuffer.wrap(bArray);
    bBuffer.order(ByteOrder.BIG_ENDIAN);
    ShortBuffer lBuffer = bBuffer.asShortBuffer();
    return lBuffer.get();
    }

/**
**********************************************************************************************
  Converts a 16-bit short number into a byte array using Little-Endian order
  @param number the short to be converted to a byte array.
  @return the byte array representing the number
**********************************************************************************************
**/
  public byte[] short2byteL(short number){
    byte[] bArray = new byte[2];
    ByteBuffer bBuffer = ByteBuffer.wrap(bArray);
    bBuffer.order(ByteOrder.LITTLE_ENDIAN);
    ShortBuffer lBuffer = bBuffer.asShortBuffer();
    lBuffer.put(0, number);
    return bArray;
    }

/**
**********************************************************************************************
  Converts a 16-bit short number into a byte array using Big-Endian order
  @param number the short to be converted to a byte array.
  @return the byte array representing the number
**********************************************************************************************
**/
  public byte[] short2byteB(short number){
    byte[] bArray = new byte[2];
    ByteBuffer bBuffer = ByteBuffer.wrap(bArray);
    bBuffer.order(ByteOrder.BIG_ENDIAN);
    ShortBuffer lBuffer = bBuffer.asShortBuffer();
    lBuffer.put(0, number);
    return bArray;
    }


///////////////////////////
// BYTE <--> INT METHODS //
///////////////////////////

/**
**********************************************************************************************
  Converts a byte array into a 32-bit integer number using Little-Endian order
  @param bArray the bytes to be converted to a integer. The array must be of length 4
  @return the 32-bit integer number
**********************************************************************************************
**/
  public int byte2intL(byte[] bArray){
    ByteBuffer bBuffer = ByteBuffer.wrap(bArray);
    bBuffer.order(ByteOrder.LITTLE_ENDIAN);
    IntBuffer lBuffer = bBuffer.asIntBuffer();
    return lBuffer.get();
    }

/**
**********************************************************************************************
  Converts a byte array into a 32-bit integer number using Big-Endian order
  @param bArray the bytes to be converted to a integer. The array must be of length 4
  @return the 32-bit integer number
**********************************************************************************************
**/
  public int byte2intB(byte[] bArray){
    ByteBuffer bBuffer = ByteBuffer.wrap(bArray);
    bBuffer.order(ByteOrder.BIG_ENDIAN);
    IntBuffer lBuffer = bBuffer.asIntBuffer();
    return lBuffer.get();
    }

/**
**********************************************************************************************
  Converts a 32-bit integer number into a byte array using Little-Endian order
  @param number the integer to be converted to a byte array.
  @return the byte array representing the number
**********************************************************************************************
**/
  public byte[] int2byteL(int number){
    byte[] bArray = new byte[4];
    ByteBuffer bBuffer = ByteBuffer.wrap(bArray);
    bBuffer.order(ByteOrder.LITTLE_ENDIAN);
    IntBuffer lBuffer = bBuffer.asIntBuffer();
    lBuffer.put(0, number);
    return bArray;
    }

/**
**********************************************************************************************
  Converts a 32-bit integer number into a byte array using Big-Endian order
  @param number the integer to be converted to a byte array.
  @return the byte array representing the number
**********************************************************************************************
**/
  public byte[] int2byteB(int number){
    byte[] bArray = new byte[4];
    ByteBuffer bBuffer = ByteBuffer.wrap(bArray);
    bBuffer.order(ByteOrder.BIG_ENDIAN);
    IntBuffer lBuffer = bBuffer.asIntBuffer();
    lBuffer.put(0, number);
    return bArray;
    }


////////////////////////////
// BYTE <--> LONG METHODS //
////////////////////////////

/**
**********************************************************************************************
  Converts a byte array into a 64-bit long number using Little-Endian order
  @param bArray the bytes to be converted to a long. The array must be of length 8
  @return the 64-bit long number
**********************************************************************************************
**/
  public long byte2longL(byte[] bArray){
    ByteBuffer bBuffer = ByteBuffer.wrap(bArray);
    bBuffer.order(ByteOrder.LITTLE_ENDIAN);
    LongBuffer lBuffer = bBuffer.asLongBuffer();
    return lBuffer.get();
    }

/**
**********************************************************************************************
  Converts a byte array into a 64-bit long number using Big-Endian order
  @param bArray the bytes to be converted to a long. The array must be of length 8
  @return the 64-bit long number
**********************************************************************************************
**/
  public long byte2longB(byte[] bArray){
    ByteBuffer bBuffer = ByteBuffer.wrap(bArray);
    bBuffer.order(ByteOrder.BIG_ENDIAN);
    LongBuffer lBuffer = bBuffer.asLongBuffer();
    return (int)lBuffer.get();
    }

/**
**********************************************************************************************
  Converts a 64-bit long number into a byte array using Little-Endian order
  @param number the long to be converted to a byte array.
  @return the byte array representing the number
**********************************************************************************************
**/
  public byte[] long2byteL(long number){
    byte[] bArray = new byte[8];
    ByteBuffer bBuffer = ByteBuffer.wrap(bArray);
    bBuffer.order(ByteOrder.LITTLE_ENDIAN);
    LongBuffer lBuffer = bBuffer.asLongBuffer();
    lBuffer.put(0, number);
    return bArray;
    }

/**
**********************************************************************************************
  Converts a 64-bit long number into a byte array using Big-Endian order
  @param number the long to be converted to a byte array.
  @return the byte array representing the number
**********************************************************************************************
**/
  public byte[] long2byteB(long number){
    byte[] bArray = new byte[8];
    ByteBuffer bBuffer = ByteBuffer.wrap(bArray);
    bBuffer.order(ByteOrder.BIG_ENDIAN);
    LongBuffer lBuffer = bBuffer.asLongBuffer();
    lBuffer.put(0, number);
    return bArray;
    }


/////////////////////////////
// BYTE <--> FLOAT METHODS //
/////////////////////////////

/**
**********************************************************************************************
  Converts a byte array into a 32-bit float number using Little-Endian order
  @param bArray the bytes to be converted to a float. The array must be of length 4
  @return the 32-bit float number
**********************************************************************************************
**/
  public float byte2floatL(byte[] bArray){
    ByteBuffer bBuffer = ByteBuffer.wrap(bArray);
    bBuffer.order(ByteOrder.LITTLE_ENDIAN);
    FloatBuffer lBuffer = bBuffer.asFloatBuffer();
    return lBuffer.get();
    }

/**
**********************************************************************************************
  Converts a byte array into a 32-bit float number using Big-Endian order
  @param bArray the bytes to be converted to a float. The array must be of length 4
  @return the 32-bit float number
**********************************************************************************************
**/
  public float byte2floatB(byte[] bArray){
    ByteBuffer bBuffer = ByteBuffer.wrap(bArray);
    bBuffer.order(ByteOrder.BIG_ENDIAN);
    FloatBuffer lBuffer = bBuffer.asFloatBuffer();
    return lBuffer.get();
    }

/**
**********************************************************************************************
  Converts a 32-bit float number into a byte array using Little-Endian order
  @param number the float to be converted to a byte array.
  @return the byte array representing the number
**********************************************************************************************
**/
  public byte[] float2byteL(float number){
    byte[] bArray = new byte[4];
    ByteBuffer bBuffer = ByteBuffer.wrap(bArray);
    bBuffer.order(ByteOrder.LITTLE_ENDIAN);
    FloatBuffer lBuffer = bBuffer.asFloatBuffer();
    lBuffer.put(0, number);
    return bArray;
    }

/**
**********************************************************************************************
  Converts a 32-bit float number into a byte array using Big-Endian order
  @param number the float to be converted to a byte array.
  @return the byte array representing the number
**********************************************************************************************
**/
  public byte[] float2byteB(float number){
    byte[] bArray = new byte[4];
    ByteBuffer bBuffer = ByteBuffer.wrap(bArray);
    bBuffer.order(ByteOrder.BIG_ENDIAN);
    FloatBuffer lBuffer = bBuffer.asFloatBuffer();
    lBuffer.put(0, number);
    return bArray;
    }


//////////////////////////////
// BYTE <--> DOUBLE METHODS //
//////////////////////////////

/**
**********************************************************************************************
  Converts a byte array into a 64-bit double number using Little-Endian order
  @param bArray the bytes to be converted to a double. The array must be of length 8
  @return the 64-bit double number
**********************************************************************************************
**/
  public double byte2doubleL(byte[] bArray){
    ByteBuffer bBuffer = ByteBuffer.wrap(bArray);
    bBuffer.order(ByteOrder.LITTLE_ENDIAN);
    DoubleBuffer lBuffer = bBuffer.asDoubleBuffer();
    return lBuffer.get();
    }

/**
**********************************************************************************************
  Converts a byte array into a 64-bit double number using Big-Endian order
  @param bArray the bytes to be converted to a double. The array must be of length 8
  @return the 64-bit double number
**********************************************************************************************
**/
  public double byte2doubleB(byte[] bArray){
    ByteBuffer bBuffer = ByteBuffer.wrap(bArray);
    bBuffer.order(ByteOrder.BIG_ENDIAN);
    DoubleBuffer lBuffer = bBuffer.asDoubleBuffer();
    return lBuffer.get();
    }

/**
**********************************************************************************************
  Converts a 64-bit double number into a byte array using Little-Endian order
  @param number the double to be converted to a byte array.
  @return the byte array representing the number
**********************************************************************************************
**/
  public byte[] double2byteL(double number){
    byte[] bArray = new byte[8];
    ByteBuffer bBuffer = ByteBuffer.wrap(bArray);
    bBuffer.order(ByteOrder.LITTLE_ENDIAN);
    DoubleBuffer lBuffer = bBuffer.asDoubleBuffer();
    lBuffer.put(0, number);
    return bArray;
    }

/**
**********************************************************************************************
  Converts a 64-bit double number into a byte array using Big-Endian order
  @param number the double to be converted to a byte array.
  @return the byte array representing the number
**********************************************************************************************
**/
  public byte[] double2byteB(double number){
    byte[] bArray = new byte[8];
    ByteBuffer bBuffer = ByteBuffer.wrap(bArray);
    bBuffer.order(ByteOrder.BIG_ENDIAN);
    DoubleBuffer lBuffer = bBuffer.asDoubleBuffer();
    lBuffer.put(0, number);
    return bArray;
    }


//////////////////////////////
// BYTE <--> STRING METHODS //
//////////////////////////////

/**
**********************************************************************************************
  Converts a byte array into a String
  @param bArray the bytes to be converted to a String.
  @return the String
**********************************************************************************************
**/
  public String byte2string(byte[] bArray){
    return new String(bArray);
    }

/**
**********************************************************************************************
  Converts a String to a byte array
  @param text the String to be converted to bytes.
  @return the bytes
**********************************************************************************************
**/
  public byte[] string2byte(String text){
    return text.getBytes();
    }


///////////////////////////////
// SHORT <--> STRING METHODS //
///////////////////////////////

/**
**********************************************************************************************
  Converts a short into a String
  @param number the short to be converted to a String.
  @return the String
**********************************************************************************************
**/
  public String short2string(short number){
    return number + "";
    }

/**
**********************************************************************************************
  Converts a String to a short
  @param text the String to be converted to a short.
  @return the short
**********************************************************************************************
**/
  public short string2short(String text){
    return Short.parseShort(text);
    }


/////////////////////////////
// INT <--> STRING METHODS //
/////////////////////////////

/**
**********************************************************************************************
  Converts a int into a String
  @param number the int to be converted to a String.
  @return the String
**********************************************************************************************
**/
  public String int2string(int number){
    return number + "";
    }

/**
**********************************************************************************************
  Converts a String to a int
  @param text the String to be converted to a int.
  @return the int
**********************************************************************************************
**/
  public int string2int(String text){
    return Integer.parseInt(text);
    }


//////////////////////////////
// LONG <--> STRING METHODS //
//////////////////////////////

/**
**********************************************************************************************
  Converts a long into a String
  @param number the long to be converted to a String.
  @return the String
**********************************************************************************************
**/
  public String long2string(long number){
    return number + "";
    }

/**
**********************************************************************************************
  Converts a String to a long
  @param text the String to be converted to a long.
  @return the long
**********************************************************************************************
**/
  public long string2long(String text){
    return Long.parseLong(text);
    }


///////////////////////////////
// FLOAT <--> STRING METHODS //
///////////////////////////////

/**
**********************************************************************************************
  Converts a float into a String
  @param number the float to be converted to a String.
  @return the String
**********************************************************************************************
**/
  public String float2string(float number){
    return number + "";
    }

/**
**********************************************************************************************
  Converts a String to a float
  @param text the String to be converted to a float.
  @return the float
**********************************************************************************************
**/
  public float string2float(String text){
    return Float.parseFloat(text);
    }


////////////////////////////////
// DOUBLE <--> STRING METHODS //
////////////////////////////////

/**
**********************************************************************************************
  Converts a double into a String
  @param number the double to be converted to a String.
  @return the String
**********************************************************************************************
**/
  public String double2string(double number){
    return number + "";
    }

/**
**********************************************************************************************
  Converts a String to a double
  @param text the String to be converted to a double.
  @return the double
**********************************************************************************************
**/
  public double string2double(String text){
    return Double.parseDouble(text);
    }


////////////////////////////////
// CHAR[] <--> STRING METHODS //
////////////////////////////////

/**
**********************************************************************************************
  Converts a char array into a String
  @param cArray the char array to be converted to a String.
  @return the String
**********************************************************************************************
**/
  public String char2string(char[] cArray){
    return new String(cArray);
    }

/**
**********************************************************************************************
  Converts a String to a char array
  @param text the String to be converted to a char array.
  @return the char array
**********************************************************************************************
**/
  public char[] string2char(String text){
    return text.toCharArray();
    }


/////////////////////////////
// INT[] <--> LONG METHODS //
/////////////////////////////

/**
**********************************************************************************************
  Converts an integer array into a long using Big-Endian order.
  @param intArray the integers to convert into a long. The integer array must be of length 2
  @return the long compiled from the 2 integers
**********************************************************************************************
**/
  public long int2longB(int[] intArray){
    return (((long) intArray[0]) << 32) |
           (((long) intArray[1]) & 0x0ffffffffL);
    }

/**
**********************************************************************************************
  Converts an integer array into a long using Little-Endian order.
  @param intArray the integers to convert into a long. The integer array must be of length 2
  @return the long compiled from the 2 integers
**********************************************************************************************
**/
  public long int2longL(int[] intArray){
    return int2longB(new int[]{intArray[1],intArray[0]});
    }

/**
**********************************************************************************************
  Converts a long into an integer array using Big-Endian order
  @param lValue the long number to be split into integers
  @return the long compiled from the 2 integers
**********************************************************************************************
**/
  public int[] long2intB(long lValue){
    int[] buf = new int[2];
    buf[0] = (int)(lValue >>> 32);
    buf[1] = (int) lValue;
    return buf;
    }

/**
**********************************************************************************************
  Converts a long into an integer array using Little-Endian order
  @param lValue the long number to be split into integers
  @return the long compiled from the 2 integers
**********************************************************************************************
**/
  public int[] long2intL(long lValue){
    int[] buf = new int[2];
    buf[1] = (int)(lValue >>> 32);
    buf[0] = (int) lValue;
    return buf;
    }


///////////////////////////
// LONG <--> INT METHODS //
///////////////////////////

/**
**********************************************************************************************
  Retrieves the lower 32-bit integer from a long number.
  @param number the number to be cut
  @return the lower 32-bit number
**********************************************************************************************
**/
  public int long2intLower(long number){
    return (int)number;
    }

/**
**********************************************************************************************
  Retrieves the higher 32-bit integer from a long number.
  @param number the number to be cut
  @return the higher 32-bit number
**********************************************************************************************
**/
  public int long2intHigher(long number){
    return (int)(number >>> 32);
    }


////////////////////////////
// INT <--> SHORT METHODS //
////////////////////////////

/**
**********************************************************************************************
  Retrieves the lower 16-bit short from an integer number.
  @param number the number to be cut
  @return the lower 16-bit number
**********************************************************************************************
**/
  public short int2shortLower(int number){
    return (short)number;
    }

/**
**********************************************************************************************
  Retrieves the higher 16-bit short from an integer number.
  @param number the number to be cut
  @return the higher 16-bit number
**********************************************************************************************
**/
  public short int2shortHigher(int number){
    return (short)(number >>> 16);
    }


/////////////////////////////
// SHORT <--> BYTE METHODS //
/////////////////////////////

/**
**********************************************************************************************
  Retrieves the lower 8-bit byte from a short number.
  @param number the number to be cut
  @return the lower 8-bit number
**********************************************************************************************
**/
  public byte short2byteLower(short number){
    return (byte)number;
    }

/**
**********************************************************************************************
  Retrieves the higher 8-bit byte from a short number.
  @param number the number to be cut
  @return the higher 8-bit number
**********************************************************************************************
**/
  public byte short2byteHigher(short number){
    return (byte)(number >>> 8);
    }


/////////////////////////////
// BYTE[] <--> HEX METHODS //
/////////////////////////////

/**
**********************************************************************************************
  Converts an array of bytes into a hex string.
  @param byteArray the bytes
  @return the hex string
**********************************************************************************************
**/
  public String byte2hex(byte[] byteArray){
    int nCnPos;
    StringBuffer sbuf;

    sbuf = new StringBuffer();
    sbuf.setLength(byteArray.length << 1);

    int nPos = 0;
    int nC = byteArray.length;
    int nOfs = 0;

    while (nOfs < nC){
      sbuf.setCharAt(nPos++, hexTable[(byteArray[nOfs  ] >> 4) & 0x0f]);
      sbuf.setCharAt(nPos++, hexTable[ byteArray[nOfs++]       & 0x0f]);
      }

    return sbuf.toString();
    }

/**
**********************************************************************************************
  Converts a hex string into a byte array. The hex string must have a length multiple of 2.
  @param sHex the hex string
  @return the byte array representing the hex string
**********************************************************************************************
**/
  public byte[] hex2byte(String sHex){

    byte[] data = new byte[(int)(sHex.length()/2)];
    int nLen = sHex.length();
    int nSrcOfs = 0;
    int nDstOfs = 0;

    int nI, nJ, nStrLen, nAvailBytes, nDstOfsBak;
    byte bActByte;
    boolean blConvertOK;


    // check for correct ranges
    nStrLen = sHex.length();

    nAvailBytes = (nStrLen - nSrcOfs) >> 1;
    if (nAvailBytes < nLen){
      nLen = nAvailBytes;
      }

    int nOutputCapacity = data.length - nDstOfs;
    if (nLen > nOutputCapacity){
      nLen = nOutputCapacity;
      }

    // convert now

    nDstOfsBak = nDstOfs;

    for (nI = 0; nI < nLen; nI++){
      bActByte = 0;
      blConvertOK = true;

      for (nJ = 0; nJ < 2; nJ++){
        bActByte <<= 4;
        char cActChar = sHex.charAt(nSrcOfs++);

        if ((cActChar >= 'a') && (cActChar <= 'f')){
          bActByte |= (byte) (cActChar - 'a') + 10;
          }
        else{
          if ((cActChar >= '0') && (cActChar <= '9')){
            bActByte |= (byte) (cActChar - '0');
            }
          else{
            blConvertOK = false;
            }
          }
        }
      if (blConvertOK){
        data[nDstOfs++] = bActByte;
        }
      }
    return data;
    }



/////////////////////////////
// BYTE <--> CHAR METHODS //
/////////////////////////////

/**
**********************************************************************************************
  Converts a byte array into a unicode character using Little-Endian order
  @param byteArray the 2 bytes to be converted to a char
  @return the char representing the 2 bytes
**********************************************************************************************
**/
  public char byte2charL(byte[] byteArray){
    ByteBuffer bBuffer = ByteBuffer.wrap(byteArray);
    bBuffer.order(ByteOrder.LITTLE_ENDIAN);
    CharBuffer lBuffer = bBuffer.asCharBuffer();
    return lBuffer.get();
    }

/**
**********************************************************************************************
  Converts a byte array into a unicode character using Big-Endian order
  @param byteArray the 2 bytes to be converted to a char
  @return the char representing the 2 bytes
**********************************************************************************************
**/
  public char byte2charB(byte[] byteArray){
    ByteBuffer bBuffer = ByteBuffer.wrap(byteArray);
    bBuffer.order(ByteOrder.BIG_ENDIAN);
    CharBuffer lBuffer = bBuffer.asCharBuffer();
    return lBuffer.get();
    }

/**
**********************************************************************************************
  Converts a unicode character into a byte array using Little-Endian order
  @param letter the unicode character
  @return the byte array representing the character
**********************************************************************************************
**/
  public byte[] char2byteL(char letter){
    byte[] bArray = new byte[2];
    ByteBuffer bBuffer = ByteBuffer.wrap(bArray);
    bBuffer.order(ByteOrder.LITTLE_ENDIAN);
    CharBuffer lBuffer = bBuffer.asCharBuffer();
    lBuffer.put(0, letter);
    return bArray;
    }

/**
**********************************************************************************************
  Converts a unicode character into a byte array using Big-Endian order
  @param letter the unicode character
  @return the byte array representing the character
**********************************************************************************************
**/
  public byte[] char2byteB(char letter){
    byte[] bArray = new byte[2];
    ByteBuffer bBuffer = ByteBuffer.wrap(bArray);
    bBuffer.order(ByteOrder.BIG_ENDIAN);
    CharBuffer lBuffer = bBuffer.asCharBuffer();
    lBuffer.put(0, letter);
    return bArray;
    }




//////////////////////////
// INT <--> HEX METHODS //
//////////////////////////

/**
**********************************************************************************************
  Converts an int into a hex string
  @param number the int to be converted to a hex string
  @return the hex string
**********************************************************************************************
**/
  public String int2hex(int number){
    return Integer.toHexString(number);
    }


///////////////////////////
// LONG <--> HEX METHODS //
///////////////////////////

/**
**********************************************************************************************
  Converts an long into a hex string
  @param number the long to be converted to a hex string
  @return the hex string
**********************************************************************************************
**/
  public String long2hex(long number){
    return Long.toHexString(number);
    }




///////////////////////////////
// BYTE[] <--> UNICODE METHODS //
///////////////////////////////
/**
**********************************************************************************************
  Converts a byte array into a unicode string
  @param byteArray the bytes representing unicode characters. The byte array length should be a multiple of 2.
  @return the unicode string representing the bytes
**********************************************************************************************
**/
  public String byte2unicode(byte[] byteArray){

    int nOfs = 0;
    int nLen = byteArray.length;

    int nAvailCapacity, nSBufPos;
    StringBuffer sbuf;

    // we need two bytes for every character
    nLen &= ~1;

    // enough bytes in the buf?
    nAvailCapacity = byteArray.length - nOfs;

    if (nAvailCapacity < nLen){
      nLen = nAvailCapacity;
      }

    sbuf = new StringBuffer();
    sbuf.setLength(nLen >> 1);

    nSBufPos = 0;

    while (0 < nLen){
      sbuf.setCharAt(nSBufPos++, (char)((byteArray[nOfs] << 8) | (byteArray[nOfs + 1] & 0x0ff)));
      nOfs += 2;
      nLen -= 2;
      }
    return sbuf.toString();
    }


/////////////////////////////
// BYTE <--> BIT[] METHODS //
/////////////////////////////

/**
**********************************************************************************************
  Converts a byte into a bit array using Big-Endian order
  @param inputByte the byte to convert into bits
  @return the bits as a boolean array. The bits are returned as a boolean array of length 8.
**********************************************************************************************
**/
  public boolean[] byte2bitB(byte inputByte){
    boolean[] bits = new boolean[8];
    /*
    for (int j=0;j<8;j++){
      if((inputByte & (byte)Math.pow(2,j)) == Math.pow(2,j)){
        bits[j] = true;
        }
      else {
        bits[j] = false;
        }
      }
    */

    int num = inputByte;
    if (num < 0){
      num = 256 + num;
      }

    if (num >= 128){bits[7] = true;num -= 128;}else {bits[7] = false;}
    if (num >= 64){ bits[6] = true;num -= 64;}else { bits[6] = false;}
    if (num >= 32){ bits[5] = true;num -= 32;}else { bits[5] = false;}
    if (num >= 16){ bits[4] = true;num -= 16;}else { bits[4] = false;}
    if (num >= 8){  bits[3] = true;num -= 8;}else {  bits[3] = false;}
    if (num >= 4){  bits[2] = true;num -= 4;}else {  bits[2] = false;}
    if (num >= 2){  bits[1] = true;num -= 2;}else {  bits[1] = false;}
    if (num >= 1){  bits[0] = true;num -= 1;}else {  bits[0] = false;}

    return bits;
    }

/**
**********************************************************************************************
  Converts a byte into a bit array using Little-Endian order
  @param inputByte the byte to convert into bits
  @return the bits as a boolean array. The bits are returned as a boolean array of length 8.
**********************************************************************************************
**/
  public boolean[] byte2bitL(byte inputByte){
    boolean[] bits = new boolean[8];
    /*
    for (int j=0;j<8;j++){
      if((inputByte & (byte)Math.pow(2,j)) == Math.pow(2,j)){
        bits[7-j] = true;
        }
      else {
        bits[7-j] = false;
        }
      }
    */
    int num = inputByte;
    if (num < 0){
      num = 256 + num;
      }

    if (num >= 128){bits[0] = true;num -= 128;}else {bits[0] = false;}
    if (num >= 64){ bits[1] = true;num -= 64;}else { bits[1] = false;}
    if (num >= 32){ bits[2] = true;num -= 32;}else { bits[2] = false;}
    if (num >= 16){ bits[3] = true;num -= 16;}else { bits[3] = false;}
    if (num >= 8){  bits[4] = true;num -= 8;}else {  bits[4] = false;}
    if (num >= 4){  bits[5] = true;num -= 4;}else {  bits[5] = false;}
    if (num >= 2){  bits[6] = true;num -= 2;}else {  bits[6] = false;}
    if (num >= 1){  bits[7] = true;num -= 1;}else {  bits[7] = false;}

    return bits;
    }

/**
**********************************************************************************************
  Converts a bit array into a byte using Big-Endian order
  @param bitArray the bit array to convert into a byte. The bit array must be a boolean array of length 8
  @return the byte compiled from the bits
**********************************************************************************************
**/
  public byte bit2byteB(boolean[] bitArray){
    int byteValue = 0;
    for (int j=0;j<8;j++){
      if (bitArray[j] == true){
        byteValue += Math.pow(2,j);
        }
      }
    return (byte) byteValue;
    }

/**
**********************************************************************************************
  Converts a bit array into a byte using Little-Endian order
  @param bitArray the bit array to convert into a byte. The bit array must be a boolean array of length 8
  @return the byte compiled from the bits
**********************************************************************************************
**/
  public byte bit2byteL(boolean[] bitArray){
    int byteValue = 0;
    for (int j=0;j<8;j++){
      if (bitArray[j] == true){
        byteValue += Math.pow(2,(7-j));
        }
      }
    return (byte) byteValue;
    }


//////////////////////////////
// SHORT <--> BIT[] METHODS //
//////////////////////////////

/**
**********************************************************************************************
  Converts a short into a bit array using Big-Endian order
  @param number the short to convert into bits
  @return the bits as a boolean array. The bits are returned as a boolean array of length 16
**********************************************************************************************
**/
  public boolean[] short2bitB(short number){
    boolean[] bits = new boolean[16];
    for (int j=0;j<16;j++){
      if((number & (byte)Math.pow(2,j)) == Math.pow(2,j)){
        bits[j] = true;
        }
      else {
        bits[j] = false;
        }
      }
    return bits;
    }

/**
**********************************************************************************************
  Converts a short into a bit array using Little-Endian order
  @param number the short to convert into bits
  @return the bits as a boolean array. The bits are returned as a boolean array of length 16
**********************************************************************************************
**/
  public boolean[] short2bitL(short number){
    boolean[] bits = new boolean[16];
    for (int j=0;j<16;j++){
      if((number & (short)Math.pow(2,j)) == Math.pow(2,j)){
        bits[15-j] = true;
        }
      else {
        bits[15-j] = false;
        }
      }
    return bits;
    }

/**
**********************************************************************************************
  Converts a bit array into a short using Big-Endian order
  @param bitArray the bit array to convert into a short. The bit array must be a boolean array of length 16
  @return the short compiled from the bits
**********************************************************************************************
**/
  public short bit2shortB(boolean[] bitArray){
    short shortValue = 0;
    for (int j=0;j<16;j++){
      if (bitArray[j] == true){
        shortValue += Math.pow(2,j);
        }
      }
    return shortValue;
    }

/**
**********************************************************************************************
  Converts a bit array into a short using Little-Endian order
  @param bitArray the bit array to convert into a short. The bit array must be a boolean array of length 16
  @return the short compiled from the bits
**********************************************************************************************
**/
  public short bit2shortL(boolean[] bitArray){
    short shortValue = 0;
    for (int j=0;j<16;j++){
      if (bitArray[j] == true){
        shortValue += Math.pow(2,(15-j));
        }
      }
    return shortValue;
    }


////////////////////////////
// INT <--> BIT[] METHODS //
////////////////////////////

/**
**********************************************************************************************
  Converts a int into a bit array using Big-Endian order
  @param number the int to convert into bits
  @return the bits as a boolean array. The bits are returned as a boolean array of length 32
**********************************************************************************************
**/
  public boolean[] int2bitB(int number){
    boolean[] bits = new boolean[32];
    for (int j=0;j<32;j++){
      if((number & (byte)Math.pow(2,j)) == Math.pow(2,j)){
        bits[j] = true;
        }
      else {
        bits[j] = false;
        }
      }
    return bits;
    }

/**
**********************************************************************************************
  Converts a int into a bit array using Little-Endian order
  @param number the int to convert into bits
  @return the bits as a boolean array. The bits are returned as a boolean array of length 32
**********************************************************************************************
**/
  public boolean[] int2bitL(int number){
    boolean[] bits = new boolean[32];
    for (int j=0;j<32;j++){
      if((number & (int)Math.pow(2,j)) == Math.pow(2,j)){
        bits[31-j] = true;
        }
      else {
        bits[31-j] = false;
        }
      }
    return bits;
    }

/**
**********************************************************************************************
  Converts a bit array into a int using Big-Endian order
  @param bitArray the bit array to convert into a int. The bit array must be a boolean array of length 32
  @return the int compiled from the bits
**********************************************************************************************
**/
  public int bit2intB(boolean[] bitArray){
    int intValue = 0;
    for (int j=0;j<32;j++){
      if (bitArray[j] == true){
        intValue += Math.pow(2,j);
        }
      }
    return intValue;
    }

/**
**********************************************************************************************
  Converts a bit array into a int using Little-Endian order
  @param bitArray the bit array to convert into a int. The bit array must be a boolean array of length 32
  @return the int compiled from the bits
**********************************************************************************************
**/
  public int bit2intL(boolean[] bitArray){
    int intValue = 0;
    for (int j=0;j<32;j++){
      if (bitArray[j] == true){
        intValue += Math.pow(2,(31-j));
        }
      }
    return intValue;
    }


/////////////////////////////
// LONG <--> BIT[] METHODS //
/////////////////////////////

/**
**********************************************************************************************
  Converts a long into a bit array using Big-Endian order
  @param number the long to convert into bits
  @return the bits as a boolean array. The bits are returned as a boolean array of length 64
**********************************************************************************************
**/
  public boolean[] long2bitB(long number){
    boolean[] bits = new boolean[64];
    for (int j=0;j<64;j++){
      if((number & (byte)Math.pow(2,j)) == Math.pow(2,j)){
        bits[j] = true;
        }
      else {
        bits[j] = false;
        }
      }
    return bits;
    }

/**
**********************************************************************************************
  Converts a long into a bit array using Little-Endian order
  @param number the long to convert into bits
  @return the bits as a boolean array. The bits are returned as a boolean array of length 64
**********************************************************************************************
**/
  public boolean[] long2bitL(long number){
    boolean[] bits = new boolean[64];
    for (int j=0;j<64;j++){
      if((number & (long)Math.pow(2,j)) == Math.pow(2,j)){
        bits[63-j] = true;
        }
      else {
        bits[63-j] = false;
        }
      }
    return bits;
    }

/**
**********************************************************************************************
  Converts a bit array into a long using Big-Endian order
  @param bitArray the bit array to convert into a long. The bit array must be a boolean array of length 64
  @return the long compiled from the bits
**********************************************************************************************
**/
  public long bit2longB(boolean[] bitArray){
    long longValue = 0;
    for (int j=0;j<64;j++){
      if (bitArray[j] == true){
        longValue += Math.pow(2,j);
        }
      }
    return longValue;
    }

/**
**********************************************************************************************
  Converts a bit array into a long using Little-Endian order
  @param bitArray the bit array to convert into a long. The bit array must be a boolean array of length 64
  @return the long compiled from the bits
**********************************************************************************************
**/
  public long bit2longL(boolean[] bitArray){
    long longValue = 0;
    for (int j=0;j<64;j++){
      if (bitArray[j] == true){
        longValue += Math.pow(2,(63-j));
        }
      }
    return longValue;
    }











/////////////////////////////////////
//                                 //
//  BIT SWAPPING                   //
//                                 //
/////////////////////////////////////

/**
**********************************************************************************************
  Swaps the bits of a short
  @param number the number to swap
  @return the swapped number
**********************************************************************************************
**/
  public static short swapShort(short number){
    return (short)((number << 8) | ((number >> 8) & 0xff));
    }

/**
**********************************************************************************************
  Swaps the bits of a character value
  @param character the character value to swap
  @return the swapped character value
**********************************************************************************************
**/
  public static char swapChar(char character){
    return (char)((character << 8) | ((character >> 8) & 0xff));
    }

/**
**********************************************************************************************
  Swaps the bits of a int
  @param number the number to swap
  @return the swapped number
**********************************************************************************************
**/
  public static int swapInt(int number){
    return (int)((swapShort((short)number) << 16) | (swapShort((short)(number >> 16)) & 0xffff));
    }

/**
**********************************************************************************************
  Swaps the bits of a long
  @param number the number to swap
  @return the swapped number
**********************************************************************************************
**/
  public static long swapLong(long number){
    return (long)(((long)swapInt((int)(number)) << 32) | ((long)swapInt((int)(number >> 32)) & 0xffffffffL));
    }

/**
**********************************************************************************************
  Swaps the bits of a float
  @param number the number to swap
  @return the swapped number
**********************************************************************************************
**/
  public static float swapFloat(float number){
    return Float.intBitsToFloat(swapInt(Float.floatToRawIntBits(number)));
    }

/**
**********************************************************************************************
  Swaps the bits of a double
  @param number the number to swap
  @return the swapped number
**********************************************************************************************
**/
  public static double swapDouble(double number){
    return Double.longBitsToDouble(swapLong(Double.doubleToRawLongBits(number)));
    }






}