from inc_noesis import *
import noesis
import rapi
import os
import glob


def registerNoesisTypes():
	handle = noesis.register("Black Desert anim", ".paa")
	noesis.setHandlerTypeCheck(handle, BDCheckType)
	noesis.setHandlerLoadModel(handle, BDLoadModel) #see also noepyLoadModelRPG
	#noesis.logPopup()
	return 1

def BDCheckType(data):
	bs = NoeBitStream(data)
	idMagic = bs.readInt()
	return 1

find = lambda searchList, elem: [[i for i, x in enumerate(searchList) if x == e] for e in elem]

def UnpackValue(value):
	if value < 0:
		return(value * 3.27680)
	elif value > 0:    
		return(value * 3.327670)
	else:
    # If we get this far then the value has to be 0
		return 0.0

def BDLoadModel(data, mdlList):
	ctx = rapi.rpgCreateContext()
	bs = NoeBitStream(data)
	rapi.setPreviewOption('setAngOfs',"0 90 90")

	boneNames = []#
	boneTable = {}#boneTable[str(boneHash)]->boneName in english
	boneTableIndex = {}#I added this  #  boneTableIndex[str(boneHash)]->bone index in Noesis/pab file(boneTableIndex[Bip01's hash]->0)
	
	boneMtxList = []
	BonePosList = []
	boneParentList = []
	BoneQuatList = []
	
	BoneLocalPosList = []
	BoneLocalRotList = []
		
	meshes = []#Doesn't load
	wholeBones = []#Come from pab file
	anims = []#Come from pab file

	test = rapi.getDirForFilePath(rapi.getInputName())
	os.chdir(test)
	test = glob.glob("*.pab")
	try:
		skelfile = rapi.getDirForFilePath(rapi.getInputName()) + test[0]
		
	except:
		skelfile = ""
	
	if (rapi.checkFileExists(skelfile)):
		ss = rapi.loadIntoByteArray(skelfile)
		ss = NoeBitStream(ss)
		ss.seek(0x10, NOESEEK_ABS)
		boneCount1 = ss.readUShort()
		#print(boneCount1) #Here store the whole body bone number
		for i in range(0, boneCount1):
			boneHash = ss.readUInt()
			boneNameSize = ss.readUByte()
			#boneName = ss.readBytes(boneNameSize).decode("ASCII",'ignore').rstrip("\0")
			boneName = noeStrFromBytes(ss.readBytes(boneNameSize), 'euc-kr')
			boneTable[str(boneHash)] = boneName
			boneTableIndex[str(boneHash)] = i#record boneIndex
			boneNames.append(boneName)
			boneParent = ss.readInt()
			boneMtx             = NoeMat44.fromBytes(ss.readBytes(64)).toMat43()##In Blender script,here is ->bone.matrix=Matrix4x4(g.f(16))

			#From
			boneMtxInverse      = NoeMat44.fromBytes(ss.readBytes(64)).toMat43().inverse()
			boneMtxLocal        = NoeMat44.fromBytes(ss.readBytes(64)).toMat43()
			boneMtxLocalInverse = NoeMat44.fromBytes(ss.readBytes(64)).toMat43().inverse()
			#In Szkaradek123's [2015-01-03] blender script,skipped loading these data above 


			boneScale           = NoeVec3.fromBytes(ss.readBytes(12))
			print(boneScale)
			BoneQuat            = NoeQuat.fromBytes(ss.readBytes(16))
			BonePos             = NoeVec3.fromBytes(ss.readBytes(12))
			
			#I think we should use bone non local matrix
			boneMtxList.append(boneMtx)#boneMtxList.append(boneMtxLocal)
			BonePosList.append(BonePos)
			boneParentList.append(boneParent)
			BoneQuatList.append(BoneQuat)
			
			BoneLocalPosList.append(boneMtxLocal.toAngles().toVec3())
			BoneLocalRotList.append(boneMtxLocal.toQuat())
			
			#Here's what I fixed in pab 2100 script
			flag=ss.readUShort()#ss.seek(0x2, NOESEEK_REL)
			if(flag==1025):#771pdw ADD Bone
				ss.seek(0x38, NOESEEK_REL)
				print("skipped 0x38")
			if(flag==256):#771psw 515pcw ADD Bone
				ss.seek(0x24, NOESEEK_REL)
				print("skipped 0x24")
                        #
                        
			newBone = NoeBone(i, boneName, boneMtx, None, boneParent)
			#Here we should succeed loading all bones in pab file
			wholeBones.append(newBone)
	
	# Zagruzka animacii	
	bs.readBytes(4)
	bs.seek(16, NOESEEK_ABS)
	boneCount = bs.readUShort()#Seems that NOT every bone has animation
	animationDuration = bs.readFloat()
	NumFrames = int(animationDuration * 30.0)#same as displayed in Noesis
	bs.readBytes(4)
	
	boneList = []
	kfBones = []
	timeList=[]
	
	framerate = 30.0
	
	for m in range(0, boneCount):#for m in range(0, boneCount1):#We just need to loop the numbers of animated bones times
		boneHash1 = bs.readUInt()
		
		boneName = boneTable[str(boneHash1)]#name = boneNames[m] #load boneName based on bone's hash
		Parent = boneParentList[boneTableIndex[str(boneHash1)]]#Parent = boneParentList[m]

		RotKeys = []; TrnKeys = []
				
		scaleKeyframeCount = bs.readUShort()#The numbers of scale KeyFrame of this bone
		for n in range(0, scaleKeyframeCount):#In each scale KeyFrame
			scalekeyframe = bs.readUShort()//33/framerate #At scalekeyframe Frame
			bs.readHalfFloat(); bs.readHalfFloat(); bs.readHalfFloat()#XYZ scale,data is 1 normally,skipped processing

		rotationKeyframeCount = bs.readUShort()#The numbers of rotation KeyFrame of this bone
		for n in range(0, rotationKeyframeCount):#In each rotation KeyFrame
			rotationkeyframe = bs.readUShort()//33/framerate#At rotationkeyframe Frame        #In Blender script,here is ->bone.rotFrameList.append(g.H(1)[0]/33)
			BoneQuat = NoeQuat( (bs.readHalfFloat(), bs.readHalfFloat(), bs.readHalfFloat(), bs.readHalfFloat()) ).transpose()
			#In Blender script,here is ->bone.rotKeyList.append(QuatMatrix(g.half(4)).resize4x4())
			#def QuatMatrix(quat):  return Quaternion(quat[3],quat[0],quat[1],quat[2]).toMatrix()
			RotKeys.append(NoeKeyFramedValue(rotationkeyframe, BoneQuat))
			
		positionKeyframeCount = bs.readUShort()#The numbers of rotation KeyFrame of this bone
		for n in range(0, positionKeyframeCount):##In each rotation KeyFrame
			positionkeyframe = bs.readUShort()//33/framerate#At rotationkeyframe Frame        
			BonePosition = NoeVec3( (bs.readHalfFloat(), bs.readHalfFloat(), bs.readHalfFloat()) )
			#In Blender script,here is ->bone.posKeyList.append(VectorMatrix(g.half(3)))
			#def VectorMatrix(vector):return TranslationMatrix(Vector(vector))
			TrnKeys.append(NoeKeyFramedValue(positionkeyframe, BonePosition))

		kfBone = NoeKeyFramedBone(boneTableIndex[str(boneHash1)])#kfBone = NoeKeyFramedBone(m)
		kfBone.setRotation(RotKeys, noesis.NOEKF_ROTATION_QUATERNION_4, noesis.NOEKF_INTERPOLATE_LINEAR)
		kfBone.setTranslation(TrnKeys, noesis.NOEKF_TRANSLATION_VECTOR_3, noesis.NOEKF_INTERPOLATE_LINEAR)
		kfBones.append(kfBone)
	anims.append(NoeKeyFramedAnim("BlackDesert anim", wholeBones, kfBones, framerate))	
	

	
	
	idxList = []
	posList = []
	mesh = NoeMesh(idxList, posList)
	meshes.append(mesh)
	mdl = NoeModel(meshes, wholeBones, anims)
	mdlList.append(mdl)			#important, don't forget to put your loaded model in the mdlList
	rapi.setPreviewOption("setAnimSpeed", str(framerate))
	
	return 1
