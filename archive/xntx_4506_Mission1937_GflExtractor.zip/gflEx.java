
import java.io.*;
import java.util.*;

public class gflEx {
	
	public static void main (String [] args) {

		boolean EOF = false;
		try {
		
			System.out.print("\n \u2554");
			for (int k=0;k<22;k++) System.out.print("\u2550");
			System.out.println("\u2557");
			System.out.println(" \u2551" + " 1937 - GFL Extractor " + "\u2551");
			System.out.print(" \u255A");
			for (int k=0;k<22;k++) System.out.print("\u2550");
			System.out.println("\u255D");

			String filename;
			Scanner scan = new Scanner(System.in);
			if (args.length!=1) {
				System.out.print("\n>");
				filename = scan.next();
			} else {
				filename = args[0];
			}
 
			File file = new File(filename);
			if (!file.exists()) {
				System.out.println("\nFile "+filename+" doesn't exist!");
				System.exit(1);
			}

			filename = file.getAbsolutePath();

			DataInputStream dis = new DataInputStream(new FileInputStream(filename));

			String extension = filename.substring(filename.length()-3,filename.length());
			if (!extension.toUpperCase().equals("GFL")) {
				dis.close();
				System.out.println("\nFile "+file.getName()+" is not a valid GFL file!");
				System.exit(1);
			}

			String name = filename.substring(0,filename.length()-4);
			File dir = new File(name);
			dir.mkdir();

			int pos = 0x4E;
			dis.skipBytes(pos);

			//FileOutputStream fout = new FileOutputStream(new File("gfl.out"));
			int i=0;
			while (!EOF) {

				dis.skipBytes(0x100); // filename?
				dis.skipBytes(3);
				pos+=0x103;
				/*
				int letter;
				int l_count = 1;
				while ((letter = dis.readUnsignedByte()) != 0) {
					l_count++;
					fout.write(letter);
				}
				dis.skipBytes(0x103 - l_count);
				fout.write(0xD);
				fout.write(0xA);
				*/

				int a =
					dis.readUnsignedByte() |
					dis.readUnsignedByte() << 8 |
					dis.readUnsignedByte() << 16 |
					dis.readUnsignedByte() << 24;

				byte b[] = new byte[a];
				dis.read(b);
				
				String type = ""+(char)b[0]+(char)b[1]+(char)b[2]+(char)b[3];
				if (type.equals("RIFF")) type="WAV";
				File f = new File(name+"\\"+i+"."+type);
				System.out.println(i+" "+type+" "+a+" "+pos);
				FileOutputStream fos = new FileOutputStream(f);
				fos.write(b);
				fos.close();
				i++;

				pos+=(a+4);
			}
			dis.close();
			//fout.close();

		} catch (EOFException e) {
			EOF = true;
			System.out.println("\n Done!");
		} catch (IOException e) {
			System.out.println("An I/O error has occurred!");
			e.printStackTrace();
			System.exit(0);
		}
	}
}