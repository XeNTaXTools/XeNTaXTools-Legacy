from struct import *

def FlipData(dataToFlip, interval, groupByInterval=False):
    flippedData = []
    
    counter = 0
    dataLength = len(dataToFlip)
    
    while counter < dataLength:

        segmentCounter = counter + interval
        groupString = ''
        while segmentCounter > counter:
            segmentCounter = segmentCounter - 1

            if (groupByInterval):
                groupString = groupString + dataToFlip[segmentCounter]
            else:
                flippedData.append(dataToFlip[segmentCounter])
        
        if (groupByInterval):
            flippedData.append(groupString)
            
        counter = counter + interval    
    
    return flippedData

def JoinData(dataToGroup, interval):
    groupedData = []

    counter = 0
    dataLength = len(dataToGroup)
    
    while counter < dataLength:

        segmentCounter = counter
        groupString = ''
        while segmentCounter < counter + interval:
            
            groupString = groupString + dataToGroup[segmentCounter]
            
            segmentCounter = segmentCounter + 1
            
        groupedData.append(groupString)
            
        counter = counter + interval    
    
    return groupedData

def SplitData(dataToSplit, interval):

    splitDataValues = []
    
    for byteString in dataToSplit:
        index = 0
        while index < interval:
            splitDataValues.append(byteString[2 * index:(2 * index) + 2])
            index += 1

    return splitDataValues

def GroupVertices(sourceVerts, bufferLength):

    vertexIndex = 0
    verts = []

    while vertexIndex < len(sourceVerts):
    
        bufferCounter = vertexIndex
        bufferValues = []
    
        while bufferCounter < vertexIndex + bufferLength:
            bufferValues.append(sourceVerts[bufferCounter])
            bufferCounter += 1        
        
        verts.append(bufferValues)
    
        vertexIndex = vertexIndex + bufferLength

    return verts

def ReadChunkAsByteArray(file,start,length):
    hexByteArray = []

    file.seek(start)
    data = file.read(length)

    for byte in data:
        hexByte = hex(byte)[2:].upper()
        if len(hexByte) < 2:
            hexByte = '0' + hexByte

        hexByteArray.append(hexByte)

    return hexByteArray

def ReadFileToByteArray(fileName):
    hexByteArray = []
    
    inputFile = open(fileName,'r')
    inputFileString = inputFile.read()
    inputFile.close()
    hexByteArray = inputFileString.split(' ')
    return hexByteArray

def WriteByteArrayToFile(hexByteArray, fileName, fileNameAppend, fileFormat):
    
    outputFile = open(fileName[:-4] + '_' + fileNameAppend + '.' + fileFormat,'w')
    
    for byte in hexByteArray:
        outputFile.write("%s " % byte)

    outputFile.close()
    
