Mesh Warp
=========
Use: Compare vertices from a single mesh object that exists in two same costume containers of different formats (PC/360) and snap the coordinates from one to the other.

Knowledge: Ability to find vertex data in containers to be compared.

Source Data: 
Hex data from a pc mesh object in a text file.
Hex data from a 360 mesh object in a text file.
Buffer length of pc mesh object.
Buffer length of 360 mesh object. 

Buffer lengths should total the number of objects comprising one vertex.  Normally body mesh objects are 44 bytes for 360. Each value in the buffer is 4 bytes.  Divide 44 by 4 to get 11.  A pc body mesh object may be 64 bytes with each buffer value being 4 bytes leaving a buffer length of 16.

1) Save the pc mesh object as a text file
2) Save the 360 mesh object as a text file
3) Update the appropriate variable names in MeshWarp.py
4) Update the buffer length values if needed.
5) Run MeshWarp.py
6) Update File will write out to a new text file.
7) Replace PC mesh object data with data in new text file.