from BodyShopUtils import *

pcSourceVertices = 'x.txt'            #Text document containing bytes for one mesh group, PC
consoleTargetVertices = 'y.txt'  #Text document containing bytes for same mesh group with modified coordinates, Xbox360

sourceBufferLength = 16                     #Number of Buffer Entries in Vertex, PC
targetBufferLength = 11                     #Number of Buffer Entries in Vertex, Xbox360

sourceHexByteArray = ReadFileToByteArray(pcSourceVertices)

targetHexByteArray = ReadFileToByteArray(consoleTargetVertices)

#Convert to big endian and combine byte string values
sourceFlipped = FlipData(sourceHexByteArray, 4, True)

#Combine byte string values
targetGrouped = JoinData(targetHexByteArray,4)

#Group Source Values by Vertex with nested buffer values
sourceVerts = GroupVertices(sourceFlipped,sourceBufferLength)

#Group Target Values by Vertex with nested buffer values
targetVerts = GroupVertices(targetGrouped,targetBufferLength)

vertexIndex = 0
editedVerts = []

for vertex in sourceVerts:

    #Replace X,Y,Z Values
    vertex[0] = targetVerts[vertexIndex][0]
    vertex[1] = targetVerts[vertexIndex][1]
    vertex[2] = targetVerts[vertexIndex][2]

    #Ungroup Verts in Same Loop

    bufferIndex = 0

    while bufferIndex < sourceBufferLength:
        editedVerts.append(vertex[bufferIndex])    
        bufferIndex += 1
    
    vertexIndex += 1

#Separate Modified Byte Values back into array
sourceHexByteArrayModified = SplitData(editedVerts, 4)

#Convert back to PC Endian
sourceHexByteArrayModifiedLittleEndian = FlipData(sourceHexByteArrayModified,4, False)

#Write out final file
WriteByteArrayToFile(sourceHexByteArrayModifiedLittleEndian, pcSourceVertices, 'snapped','txt')

