from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("MadWorld",".datM")
	noesis.setHandlerTypeCheck(handle, CheckType)
	noesis.setHandlerLoadModel(handle, LoadModel)
	
	return 1
	
def CheckType(data):
	bs = NoeBitStream(data)
	if len(data) < 16:
		print("Invalid file, too small")
		return 0
	return 1

def LoadModel(data, mdlList):
	
	ctx = rapi.rpgCreateContext()
	bs = NoeBitStream(data)
	bs.setEndian(NOE_BIGENDIAN)
	
	bs.readBytes(0x20)
	bs.seek(bs.readUInt()) #go to the JK partition
	JKOffset = bs.tell()
	bs.readShort() #magic
	vertexFlag = bs.readUByte()
	bs.readUByte() #padding
	posCount = bs.readUInt()
	posOffset = bs.readUInt()
	
	normCount = bs.readUInt() 
	normOffset = bs.readUInt()
	
	uvCount = bs.readUInt()
	uvOffset = bs.readUInt()
	
	bs.readUInt() #???
	bs.readUInt() #???
	
	bonePaletteCount = bs.readUInt()
	bonePaletteOffset = bs.readUInt()
	
	jointCount = bs.readUInt()
	jointParentingOffset = bs.readUInt() #joint indices seem to be after that section, fixed length ? Don't really care since in order
	
	bs.readUInt() #???
	
	jointPosOffset = bs.readUInt()
	
	bs.readUInt() #???
	bs.readUInt() #???	
	bs.readUInt() #???
	
	subMeshesOffset = bs.readUInt()
	
	#position		
	posBuffer = bytes()
	skinningInfo = []
	bs.seek(posOffset + JKOffset)
	for i in range(posCount):
		for j in range(3):
			posBuffer += noePack('f', bs.readShort()/8192) if vertexFlag == 0x12 else noePack('f', bs.readFloat())
		skinningInfo.append(bs.readShort() if vertexFlag == 0x12 else bs.readUShort())
		if vertexFlag == 0x13:
			bs.readUShort()
			
	#normals
	# normBuffer = bytes()
	# bs.seek(normOffset + JKOffset)
	# for i in range(normCount):
		# normBuffer += bs.readBytes(3)
		
	#uvs
	# uvBuffer = bytes()
	# bs.seek(uvOffset + JKOffset)
	# for i in range(uvCount):
		# for j in range(2):
			# uvBuffer += noePack('f', bs.readShort())
		
	#bones
	jointParenting = []
	jointPos = []
	jointList = []	
	bs.seek(jointParentingOffset + JKOffset)	
	for i in range(jointCount):
		jointParenting.append(bs.readByte())
	bs.seek(jointPosOffset + JKOffset)
	for i in range(jointCount):
		jointPos.append(NoeVec3([bs.readFloat(),bs.readFloat(),bs.readFloat()]))	
	for i in range(jointCount):
		jointMatrixTransform = NoeQuat().toMat43()
		jointMatrixTransform[3] = jointPos[i]
		joint = NoeBone(i, 'bone_' + str(i), jointMatrixTransform, None, jointParenting[i])
		jointList.append(joint)
		
	#skinning
	bs.seek(bonePaletteOffset + JKOffset)
	skinningMap = []
	for i in range(bonePaletteCount):
		indices = []
		weights = []
		for j in range(4):
			temp1, temp2 = bs.readByte(), bs.readByte()
			indices.append(temp1 if temp1 > 0 else 0)
			weights.append(temp2 if temp2 > 0 else 0)
		weights = [float(w)/sum(weights) for w in weights]
		skinningMap.append([indices,weights])
	
	boneIndicesBuffer = bytes()
	boneWeightsBuffer = bytes()
	for info in skinningInfo:
		indices, weights = skinningMap[info]
		for index, weight in zip(indices,weights):
			boneIndicesBuffer += noePack('H', index)
			boneWeightsBuffer += noePack('f', weight)	
		
	#faces 
	bs.seek(subMeshesOffset + JKOffset)
	offsetToNextSubmesh = 1
	subMeshesIndices = []
	subMeshesNames = []
	subMeshesFaceCount = []
	while offsetToNextSubmesh:
		checkPoint1 = bs.tell()
		offsetToNextSubmesh = bs.readUInt()
		bs.readBytes(0x1C) #???
		checkPoint2 = bs.tell()
		subMeshesNames.append(bs.readString())
		flag = 0
		while flag != 0x90:
			flag = bs.readUByte()
		indexCount = bs.readUShort()
		subMeshesFaceCount.append(indexCount//3)
		faceBuffer = bs.readBytes(0x6*indexCount)
		faceBuffer = noesis.swapEndianArray(faceBuffer,0x2)
		subMeshesIndices.append(noesis.deinterleaveBytes(faceBuffer,0x0,0x2,0x6))
		bs.seek(checkPoint1 + offsetToNextSubmesh)	
	
	rapi.rpgBindPositionBuffer(posBuffer, noesis.RPGEODATA_FLOAT,0xC)
	# rapi.rpgBindNormalBuffer(normBuffer, noesis.RPGEODATA_BYTE,0x3)
	# rapi.rpgBindUV1Buffer(uvBuffer, noesis.RPGEODATA_FLOAT, 0x8)
	rapi.rpgBindBoneIndexBuffer(boneIndicesBuffer, noesis.RPGEODATA_USHORT,0x8,0x4)
	rapi.rpgBindBoneWeightBuffer(boneWeightsBuffer, noesis.RPGEODATA_FLOAT,0x10,0x4)
	
	for j, name in enumerate(subMeshesNames):
			rapi.rpgSetName(name)			
			rapi.rpgCommitTriangles(subMeshesIndices[j], noesis.RPGEODATA_USHORT, subMeshesFaceCount[j]*3, noesis.RPGEO_TRIANGLE)
	try:
		mdl = rapi.rpgConstructModel()
	except:
		mdl = NoeModel()
	mdl.setBones(jointList)
	mdlList.append(mdl)
	
	return 1
	
	