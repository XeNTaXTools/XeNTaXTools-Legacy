import os, re

TIM2s = []
DATPath = 'C:\Archive\Papercrafting\Front Mission\DATs\FM5.DAT' 


def Duplicate_Checker():

    for i in range(len(TIM2s)): # Check this TIM2 against a list of previously extracted TIM2s.
        if TIM2s[i] == TIM2:
            return True

    TIM2s.append(TIM2) # Add this TIM2 to the list of previously extracted TIM2s.
    return False




with open(DATPath,'rb') as DAT:
    DATSize = os.path.getsize(DATPath)


    while (DAT.tell() < DATSize): # Loop until EOF.
        header = DAT.read(4)
   
        if re.fullmatch(b'TIM2', header) != None:
            DAT.seek(12,1) # Skip the rest of the header.
            TIM2Size = int.from_bytes(DAT.read(4), 'little') + 16 # Get the size of the TIM2 + the header.
            DAT.seek(-20, 1) # Jump back to the very start of the TIM2 file.
            TIM2 = DAT.read(TIM2Size) # Read in the TIM2 file.

            duplicate = Duplicate_Checker() # Determine if this TIM2 has alrady been extracted. Duplicate files of all types exist to decrease load times.

            if duplicate == False:

                offset = DAT.tell() - TIM2Size # Use the TIM2's offset as its name. 
                with open('C:\Archive\Papercrafting\Front Mission\Textures\FM5 Test\\' + str(offset) + '.tm2', 'wb') as texture:
                    texture.write(TIM2) # Finally, extract the TIM2.


            while DAT.tell() % 16 != 0: # Fail-safe to ensure that the header search always starts on a new line, probably not necessary.   
                DAT.seek(1,1)
                 
                          
        else: DAT.seek(12,1) # Skip the rest of the current line.
