from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Rival Knights Gameloft", ".tga")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
	#noesis.logPopup()
	return 1

#check if it's this type based on the data
def noepyCheckType(data):
    bs = NoeBitStream(data)
    Magic = bs.readBytes(4)
    if Magic != b'\x34\x00\x00\x00':
        return 0
    return 1
	
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.seek(0x4, NOESEEK_ABS)
    imgWidth = bs.readInt()           
    print(imgWidth, "imgwidth")
    imgHeight = bs.readInt()          
    print(imgHeight, "imgheight")
    bs.seek(0x14, NOESEEK_ABS)
    datasize = bs.readInt()           
    imgFmt = bs.readInt()
    bs.seek(0x34, NOESEEK_ABS)
    data = bs.readBytes(datasize)      
    if imgFmt == 0x8:
        texFmt = noesis.NOESISTEX_DXT5
    elif imgFmt == 0x18:
        data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "a0 b8 g8 r8")
        texFmt = noesis.NOESISTEX_RGBA32
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1