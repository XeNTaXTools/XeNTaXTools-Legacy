# Car 2 Texture Extractor by Bigchillghost
from inc_noesis import *
import rapi
import os

def registerNoesisTypes():
	handle = noesis.register("Car 2 object container", ".oct")
	noesis.setHandlerTypeCheck(handle, noepyCheckType)
	noesis.setHandlerExtractArc(handle, noepyUnpackOct)
	#noesis.logPopup()
	return 1

#check if it's this type based on the data
def noepyCheckType(data):
	if len(data) < 0x80:
		return 0
	bs = NoeBitStream(data)
	if bs.readInt() == 0x45017629:
		return 1
	return 0

def parseBaseElement(bs, fileLen, stringBuf):
	flag = bs.readUByte()
	flag2 = bs.readUByte()
	classId = bs.readUShort()
	if flag == 1 and flag2 == 0: # empty
		print("flag  %02x, flag2  %02x, %s"%(flag,flag2,stringBuf[classId]))
		return
	elif flag == 1 and flag2 > 0: # pool
		print("flag  %02x, flag2  %02x, %s"%(flag,flag2,stringBuf[classId]))
		if bs.tell() == fileLen:
			return
		test = bs.readUByte()
		bs.seek(-1, NOESEEK_REL)
		if test == 1:
			return
		parseBaseEle(bs, fileLen, stringBuf)
	else:
		print("\tflag  %02x  %02x, %s : "%(flag, flag2, stringBuf[classId]), end = "")
		if flag & 0x0F == 0xA:
			type = flag >> 4
			#print("type = %d"%type)
			len = 2
			if type == 0:
				count = bs.readUByte()
			elif type == 1:
				count = bs.readUByte()
				if flag2 == 0x14:
					len = 1
			elif type == 5:
				count = bs.readUShort()
			bs.seek(count*len, NOESEEK_REL)
			print("%#x, end at %x"%(count,bs.tell()))
		elif flag == 0x12:
			len = bs.readUByte()
			value = [bs.readFloat() for i in range(0,len)]
			print("read %d floats, end at %x"%(len, bs.tell()))
		elif flag == 0x13:
			value = bs.readFloat()
			print("%#f, end at %x"%(value,bs.tell()))
		elif flag == 0x16:
			objectId = bs.readUShort()
			len = bs.readUByte()
			value = [bs.readFloat() for i in range(0,len)]
			print("%s, read %d floats, end at %x"%(stringBuf[objectId], len, bs.tell()))
		elif flag == 0x1B:
			if flag2 == 0xC or flag2 == 0x14 or flag2 == 0x18:
				value = bs.readUByte()
			elif flag2 == 0xF:
				value = bs.readUInt()
			elif flag2 == 0xD or flag2 == 0x15:
				value = bs.readUShort()
			print("%#x, end at %x"%(value,bs.tell()))
		elif flag == 0x23:
			len = bs.readUByte()
			bs.seek(len, NOESEEK_REL)
			print("skip %x bytes, end at %x"%(len,bs.tell()))
		elif flag == 0x63:
			len = bs.readUShort()
			bs.seek(len, NOESEEK_REL)
			print("skip %x bytes, end at %x"%(len,bs.tell()))
		elif flag == 0xA3:
			len = bs.readUInt24()
			bs.seek(len, NOESEEK_REL)
			print("skip %x bytes, end at %x"%(len,bs.tell()))
		else:
			objectId = bs.readUShort()
			print("%s, end at %x"%(stringBuf[objectId],bs.tell()))
			return

def extractTextures(bs, fileLen, stringBuf, outPath):
	bs.seek(0x18, NOESEEK_REL)
	nameId = bs.readUShort()
	bs.seek(6, NOESEEK_REL)
	flag = bs.readUByte()
	bs.seek(3, NOESEEK_REL)
	if flag == 0x23:
		Size = bs.readUByte()
	elif flag == 0x63:
		Size = bs.readUShort()
	elif flag == 0xA3:
		Size = bs.readUInt24()
	else:
		Size = bs.readUInt()
	texData = bs.readBytes(Size)
	texName = stringBuf[nameId].replace(".png", ".dds")
	outName = outPath + texName
	destPath = rapi.getDirForFilePath(outName)
	if not os.path.exists(destPath):
		os.makedirs(destPath)
	Tex = open(outName, "wb")
	Tex.write(texData)
	Tex.close()
	print("extracted ", texName)
	if bs.tell() == fileLen:
		return
	test = bs.readUByte()
	bs.seek(-1, NOESEEK_REL)
	if test == 1:
		return
	extractTextures(bs, fileLen, stringBuf, outPath)
			
def noepyUnpackOct(fileName, fileLen, justChecking):
	noesis.logPopup()
	data = rapi.loadIntoByteArray(fileName)
	bs = NoeBitStream(data)
	bs.seek(0xC, NOESEEK_ABS)
	strSize = bs.readInt()
	dataSize = bs.readInt()
	bs.seek(0x3C, NOESEEK_ABS)
	stringBufEndOffset = strSize + 0x3C
	stringBuf = []
	Offset = bs.tell()
	while Offset < stringBufEndOffset:
		stringBuf.append(bs.readString())
		Offset = bs.tell()
	
	outPath = rapi.getDirForFilePath(fileName)
	try:
		index = stringBuf.index("TexturePool")
	except ValueError:
		return 1
	
	rawData = bs.readBytes(dataSize)
	key = struct.pack("<HH", 0x0401, index)
	Offset = rawData.find(key) + stringBufEndOffset
	print("find TexturePool offset at %#x"%Offset)
	bs.seek(Offset + 4, NOESEEK_ABS)
	extractTextures(bs, fileLen, stringBuf, outPath)
	
	'''
	# parsing all fragments
	while Offset < fileLen:
		parseBaseElement(bs, fileLen, stringBuf)
	'''	
	
	return 1
