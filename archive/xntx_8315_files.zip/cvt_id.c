#include <stdio.h>
#include <stdbool.h>

int main(int arg, char ** argv) {
	//Get ID
	int id;
	sscanf(argv[1],"%i",&id);
	
	//Extract compression flag
	bool isCompressed = id&1;
	id >>= 1;
	
	//Convert to filename
	char fname[6];
	fname[0] = 'A'+((id/676)%26);	//26^2
	fname[2] = 'A'+((id/ 26)%26);	//26^1
	fname[4] = 'A'+((id/  1)%26);	//26^0
	fname[1] = fname[3] = '/';
	
	//Print result and return
	printf("%s (%s)\n",fname,isCompressed?"Compressed":"Uncompressed");
	return 0;
}
