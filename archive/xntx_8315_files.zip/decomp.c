#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

int main(int argc, char ** argv) {
	//Open files
	FILE * fp  = fopen(argv[1],"rb");
	FILE * out = fopen(argv[2],"wb");
	
	//Setup output
	uint8_t  unk00    =                                             getc(fp)&0xFF ;
	uint32_t destSize = ((getc(fp)&0xFF)<<16)|((getc(fp)&0xFF)<<8)|(getc(fp)&0xFF);
	
	uint8_t * destBuf = (uint8_t*)malloc(destSize);
	uint32_t destOffs = 0;
	
	//Decompression loop
	while(destOffs<destSize) {
		uint8_t flags = getc(fp)&0xFF;
		for(int i=0; i<8; i++) {
			uint8_t cmd = flags&0x80;
			flags <<= 1;
			if(cmd) {
				//Get length+offset
				uint8_t b0 = getc(fp)&0xFF;
				uint8_t b1 = getc(fp)&0xFF;
				uint32_t offs = ((b0&0xF0)<<4)|b1;
				uint16_t len = b0&0x0F;
				if(len==0) {
					len = getc(fp)&0xFF;
					len += 0x11;
				} else len++;
				if(offs==0) goto decomp_end;
				//Write loop
				for(int j=0; j<len; j++) {
					destBuf[destOffs] = destBuf[destOffs-offs];
					destOffs++;
				}
				
			} else {
				//Get value
				uint8_t b0 = getc(fp)&0xFF;
				destBuf[destOffs] = b0;
				destOffs++;
			}
		}
	}
	decomp_end:;
	
	//Process relocation data
	long relStart = ftell(fp);
	relStart = (relStart+0xF)&(~0xF);
	fseek(fp,relStart,SEEK_SET);
	while(1) {
		uint8_t  b0 =                                                                   getc(fp)&0xFF ;
		uint32_t b1 =                       ((getc(fp)&0xFF)<<16)|((getc(fp)&0xFF)<<8)|(getc(fp)&0xFF);
		uint32_t b2 = ((getc(fp)&0xFF)<<24)|((getc(fp)&0xFF)<<16)|((getc(fp)&0xFF)<<8)|(getc(fp)&0xFF);
		b1 &= 0x00FFFFFC;
		switch(b0) {
			case 0:
			case 4: {
				destBuf[b1+0] = (b2>>24);
				destBuf[b1+1] = (b2>>16);
				destBuf[b1+2] = (b2>>8) ;
				destBuf[b1+3] =  b2     ;
				break;
			}
			case 1:
			case 5: {
				b2 -= b1;
				b2 &= 0x03FFFFFC;
				destBuf[b1+0] |= (b2>>24);
				destBuf[b1+1] |= (b2>>16);
				destBuf[b1+2] |= (b2>>8) ;
				destBuf[b1+3] |=  b2     ;
				break;
			}
			case 2:
			case 6: {
				if(b2&0x8000) b2 += 0x10000;
				destBuf[b1+2] = (b2>>24);
				destBuf[b1+3] = (b2>>16);
				break;
			}
			case 3:
			case 7: {
				destBuf[b1+2] = (b2>>8) ;
				destBuf[b1+3] =  b2     ;
				break;
			}
			case 8: {
				//TODO
				//r2  = 0x802DF480
				//r13 = 0x802DFA60
				break;
			}
			case 9:
			case 13: {
				b2 -= b1;
				destBuf[b1+0] = (b2>>24);
				destBuf[b1+1] = (b2>>16);
				destBuf[b1+2] = (b2>>8) ;
				destBuf[b1+3] =  b2     ;
				break;
			}
			case 0xFF: {
				goto rel_end;
				//break;
			}
		}
	}
	rel_end:;
	
	//Write output
	fwrite(destBuf,1,destSize,out);
	free(destBuf);
	
	//Close files and exit
	fclose(fp);
	fclose(out);
	return 0;
}
