# -*- coding: utf-8 -*-
import bpy
import bmesh
import math
import mathutils
import _io
#import noesis_function
import binascii 
import struct
import random
import time
import os
from math import isnan

NOESEEK_REL = 1
NOESEEK_ABS = 0
noesis_RPGEO_TRIANGLE_STRIP = 3
noesis_RPGEODATA_FLOAT = 0
noesis_RPGEODATA_USHORT = 4
def readfloat(input_byte):
    return struct.unpack('f',input_byte)[0]
def readfloats(input_byte,input_float_number):
    readfloats_result = []
    for i_input_float_number in range(0,input_float_number):
        readfloats_result.append(struct.unpack('f',input_byte[(0+i_input_float_number*4):(4+i_input_float_number*4)])[0])
    return readfloats_result
def readshort(input_byte):
    return struct.unpack('h',input_byte)[0]
def readUshorts(input_byte,input_Ushort_number):
    readUshorts_result = []
    for i_input_Ushort_number in range(0,input_Ushort_number):
        readUshorts_result.append(struct.unpack('H',input_byte[(0+i_input_Ushort_number*2):(2+i_input_Ushort_number*2)])[0])
    return readUshorts_result
def readint(input_byte):
    return struct.unpack('i',input_byte)[0]
def readbyte(input_byte):
    return struct.unpack('b',input_byte)[0]
def readUbyte(input_byte):
    return struct.unpack('B',input_byte)[0]
def FPS30(input_intlist):
    result_FPS30 = []
    result_FPS30 = input_intlist
    for i_result_FPS30 in range(0,len(result_FPS30) ):
        result_FPS30 [i_result_FPS30] = (result_FPS30 [i_result_FPS30] //0x10)
    return result_FPS30
def noeSuper(clobj):
	return super(clobj.__class__, clobj)
class NoeBitStream:
    position2= -2
    def __init__(self,dataopen):
        #self.name =''
        self.buff = dataopen
        self.buff2 = dataopen
        self.position = dataopen.tell()
        self.position2 = -1
    def tellme(self):
        print("in in in in NoeBitStream")
        print("tell nothing NoeBitStream( about offset =",NoeBitStream.position2)
class MineStream(NoeBitStream):
    #buuff = NoeBitStream.buff
    def __init__(self,data):
        self.data =data.buff
        self.h = 1
    def readByte(self):
        return struct.unpack('b',self.data.read(1) )[0]
    def readUByte(self):
        return struct.unpack('B',self.data.read(1) )[0]
    def readBytes(self,numBytes):
        readBytes_result = []
        input_byte = self.data.read(numBytes)
        #print("in_put=",input_byte)
        for i_input_byte_number in range(0,numBytes):
            readBytes_result.append(struct.unpack('b',input_byte[(0+i_input_byte_number):(1+i_input_byte_number)])[0])
        #return readBytes_result  ##return list ,list[0] type="Int"
        return input_byte
    def readInt(self):
        #input_byte = self.data.read(4)
        #readInt_result = struct.unpack('i',input_byte)
        #return readInt_result
        return struct.unpack('i',self.data.read(4))[0]
    def readUInt(self):
        return struct.unpack('I',self.data.read(4))[0]
    def readInts(self,numInts):
        readInts_result = []
        input_byte = self.data.read(numInts*4)
        print("Ints in_put=",input_byte)
        #print("i_input_byte_number=",i_input_byte_number)
        for i_input_byte_number in range(0,numInts):
            readInts_result.append(struct.unpack('i',input_byte[(0+i_input_byte_number*4):(4+i_input_byte_number*4)])[0])
        return readInts_result
    def readShort(self):
        return struct.unpack('h',self.data.read(2))[0]
    def readUShort(self):
        return struct.unpack('H',self.data.read(2))[0]
    def readShorts(self,numShorts):
        readShorts_result = []
        input_byte = self.data.read(numShorts*2)
        for i_input_byte_number in range(0,numShorts):
            readShorts_result.append(struct.unpack('h',input_byte[(0+i_input_byte_number*2):(2+i_input_byte_number*2)])[0])
        return readShorts_result
    def readUShorts(self,numUShorts):
        readUShorts_result = []
        input_byte = self.data.read(numUShorts*2)
        for i_input_byte_number in range(0,numUShorts):
            readUShorts_result.append(struct.unpack('H',input_byte[(0+i_input_byte_number*2):(2+i_input_byte_number*2)])[0])
        return readUShorts_result
    def readFloat(self):
        return struct.unpack('f',self.data.read(4))[0]
    def readFloats(self,numFloats):
        readFloats_result = []
        input_byte = self.data.read(numFloats*4)
        for i_input_byte_number in range(0,numFloats):
            readFloats_result.append(struct.unpack('f',input_byte[(0+i_input_byte_number*4):(4+i_input_byte_number*4)])[0])
        return readFloats_result
    def readHexs(self,numBytes):
        return str(binascii.b2a_hex(self.data.read(numBytes)) )[2:-1]
    def readEncodeShift_jis(self,numBytes):
        readEncodeShift_jis_result = []
        input_byte = self.data.read(numBytes)
        readEncodeShift_jis_result = input_byte.decode("shift-jis")
        return readEncodeShift_jis_result
    def readString(self,end_byte):
        readString_result = []
        readString_start = self.data.tell()
        iii_get = 0
        while self.data.read(1)[0] !=end_byte:
            #self.data.seek(-1,NOESEEK_REL)
            #print("sss=",self.data.read(1))
            nothing =0
            iii_get = iii_get+1
            if iii_get>350:
                break
        readString_end = self.data.tell()-1
        self.data.seek(readString_start,NOESEEK_ABS)
        input_byte = self.data.read(readString_end-readString_start)
        readString_result = input_byte.decode("shift-jis")
        return readString_result
        #for i_input_byte_number in range(0,numBytes):
            #readBytes_result.append(struct.unpack('b',input_byte[(0+i_input_byte_number):(1+i_input_byte_number)])[0])
    
    def tell(self):
        #print("IN IN IN mySTREAM")
        return self.data.tell()
        #return r
    def seek(self, addr, isRelative):
        #print("SEEK SEEK SEEK mySTREAM")
        self.data.seek(addr,isRelative)
    def close(self):
        self.data.close()
    def read(self,numBytes):
        return self.data.read(numBytes)
            #return struct.unpack('b',self.data.read(numBytes) )[0]
def pose_reset(BONE_hierarchy_name):
    for i_bone in bpy.data.objects[BONE_hierarchy_name].pose.bones:
        i_bone.location = (0,0,0)
        i_bone.rotation_quaternion = mathutils.Quaternion((1,0,0,0))
def loadAqn_NIFL(Aqn_filename,arm_ob_name=""):
    fo = open(Aqn_filename, "rb")
    bv= NoeBitStream(fo)
    bd = MineStream(bv)
    
    bd.seek(0x70C0,NOESEEK_ABS) #"cp0002_b01a_unpack.asf",directly go to bone data
    FVF_size = 0x150
    bonechunknumber = len(bpy.data.objects[arm_ob_name].data.bones)-1 # except bone"ROOT"
    for ii in range (0,bonechunknumber):
        ii= 8 #bones["R:Hips"]
        ii = 45#bpy.data.objects["cp0002_b01a_unpack.amt"].data.bones["R:LeftHandThumb2"].index
        print("ii=",ii)
        bd.seek(0x70C0+0x70+FVF_size*ii,NOESEEK_ABS) #bone_matrix base on parent
        bd.seek(0x70C0+0xF0+FVF_size*ii,NOESEEK_ABS) #direct bone_matrix reverse
        print(hex(bd.tell()))
        BoneM = mathutils.Matrix.Translation((0,0,0))
        BoneM_line = bd.readFloats(4)
        BoneM[0]= (BoneM_line[0],BoneM_line[1],BoneM_line[2],BoneM_line[3])
        print(BoneM[0])
        BoneM_line = bd.readFloats(4)
        BoneM[1]= (BoneM_line[0],BoneM_line[1],BoneM_line[2],BoneM_line[3])
        BoneM_line = bd.readFloats(4)
        BoneM[2]= (BoneM_line[0],BoneM_line[1],BoneM_line[2],BoneM_line[3])
        BoneM_line = bd.readFloats(4)
        BoneM[3]= (BoneM_line[0],BoneM_line[1],BoneM_line[2],BoneM_line[3])
        print("BoneM=",BoneM)   #.normalized()) , not change xyz
        BoneM_fixscale = BoneM.normalized()
        #len_L = mathutils.Vector((BoneM[0][0], BoneM[0][1], BoneM[0][2])).length
        len_L = mathutils.Vector((BoneM[0][0], BoneM[1][0], BoneM[2][0])).length
        BoneM_fixscale[0][3] /= len_L
        BoneM_fixscale[1][3] /= len_L
        BoneM_fixscale[2][3] /= len_L
        print("fix_M=",BoneM_fixscale)
        print("    m=",bpy.data.objects["cp0002_b01a_unpack.amt"].data.bones[ii+2].matrix_local.inverted())
        print(" Bone,",bpy.data.objects["cp0002_b01a_unpack.amt"].data.bones[ii+2].name)
        trackback()
        bd.seek(0x70C0+0xB0+FVF_size*ii,NOESEEK_ABS)
        bd.seek(0x70C0+0xF0+FVF_size*ii,NOESEEK_ABS) #fix 0.9615384, 5.9/0.9615=6.13
    bpy.data.objects["cp0002_b01a_unpack.amt"].data.bones["R:POS_ROOT"].matrix_local
str_aqn ="E:\\BaiduYunDownload\\StarOcean\\find\\data\\user\\0\\com.square_enix.android_googleplay.StarOceanj\\files\\download\\Character\\etc2\\hi\\"    
#loadAqn_NIFL(str_aqn+"cp0002_b01a_unpack.asf","cp0002_b01a_unpack.amt")                       
def loadAqm_NIFL(Aqm_filename,BONE_hierarchy_name,aqm_offsetframe=0,Aqm_filepath="",Aqm_filedirect_name="",aqm_debug=""):
    fo = open(Aqm_filename, "rb")
    bv= NoeBitStream(fo)
    ba = MineStream(bv)
    
    
    ba.seek(0x8,NOESEEK_ABS)
    ISF_motion_number = ba.readInt()
    print("ISF have .aaf number=",ISF_motion_number)
    
    m = mathutils.Matrix() #mathutils.Quaternion((0.707,0.707,0,0)).to_matrix().to_4x4()
    m[0].xyzw = 1,0,0,0
    m[1].xyzw = 0,0,1,0
    m[2].xyzw = 0,-1,0,0
    m[3].xyzw = 0,0,0,1
    
    for i_aaf in range(0,ISF_motion_number):
        #i_aaf = 0x13#0x16#16#FemaleGun_unpack  ,damage_F_END.aaf
        i_aaf = 0x7
        ba.seek(0x10+0x10*i_aaf,NOESEEK_ABS)
        aafMotion_name_offset = ba.readInt()
        aafMotion_data_offset = ba.readInt()
        aafMotion_anotheraction_offset = ba.readInt()
        ba.seek(aafMotion_name_offset,NOESEEK_ABS)
        #print(hex(ba.tell()))
        #trackback()
        readin_aaf_filename = ba.readString(0)
        if readin_aaf_filename[-4:] !=".aaf": #".aet"
            continue
        print("readin_Action_name=",readin_aaf_filename)
        ba.seek(aafMotion_data_offset,NOESEEK_ABS)
        ba.seek(0x4,NOESEEK_REL)
        aafMotion_anotheraction_offset2 = ba.readInt()
        #print(hex(aafMotion_anotheraction_offset),"=",hex(aafMotion_anotheraction_offset2))
        # aafMotion_data_offset+0x4 + aafMotion_anotheraction_offset2 = i_aaf_data_end+0x10 there"EE EE EE EE EE EE EE EE ...."
        ba.seek(aafMotion_data_offset+0x14,NOESEEK_ABS)
        jumpoffset_FFA = ba.readInt()
        ba.seek(aafMotion_data_offset+jumpoffset_FFA+0x10,NOESEEK_ABS)
        Bone_number = ba.readInt() #default 0x2E,max
        Bone_number_A = ba.readUShort() #xxx??
        ba.seek(0x4,NOESEEK_REL)
        Bone_number_B = ba.readUShort()  #for example,"home_t_stance_unpack.apk" have 0x1E(30) bones have animation
        Bone_number = Bone_number_A
        #if Bone_number > 0x2e *2:
            #trackback() 
        ba.seek(aafMotion_data_offset+jumpoffset_FFA+0x20,NOESEEK_ABS)
        Frame1 = ba.readInt()
        ba.seek(aafMotion_data_offset+jumpoffset_FFA+0x24,NOESEEK_ABS)
        Frame2 = ba.readInt()
        ba.seek(aafMotion_data_offset+jumpoffset_FFA+0x40,NOESEEK_ABS)
        data_lenth1 = ba.readInt() # aafMotion_data_offset + data_lenth1 = i_aaf_data_end
        ba.seek(aafMotion_data_offset+jumpoffset_FFA+0x44,NOESEEK_ABS)
        data_lenth2_where = ba.tell()
        data_lenth2 = ba.readInt() # data_lenth2_where + data_lenth2 = i_aaf_data_end
        ba.seek(aafMotion_data_offset+jumpoffset_FFA+0x50,NOESEEK_ABS)
        print(hex(ba.tell()))
        
        action = bpy.data.actions.new(name= readin_aaf_filename.rstrip(".aqm"))
        armature= bpy.data.objects[BONE_hierarchy_name]
        armature_name_context= bpy.data.objects[BONE_hierarchy_name].data.name
        #armature= bpy.data.objects["cannon"]
        if armature.animation_data is None:
            armature.animation_data_create()
        armature.animation_data.action = action
        
        #Bone_number = 0x2e #default,max
        for i_AnimeBone in range(0,Bone_number):
            i_bone_start = ba.tell()
            ba.seek(0x2,NOESEEK_REL)
            number_type_keyvalue = ba.readShort()
            i_bone_offset_jumpNextBone = ba.readInt()
            bonename = ba.readString(0)
            ##print("bone_name=",bonename)
            if bpy.data.armatures[armature_name_context].bones.get(bonename) ==None:
                ba.seek(i_bone_start+i_bone_offset_jumpNextBone,NOESEEK_ABS)
                continue
            ba.seek(i_bone_start+0x28,NOESEEK_ABS)
            
            number_type_keyvalue_mean = 1
            if number_type_keyvalue >1:
                number_type_keyvalue_mean = 2
                if number_type_keyvalue ==3:
                    number_type_keyvalue_mean = 3
            C_in = bpy.data.objects[BONE_hierarchy_name].data.bones[bonename].matrix_local.copy().inverted()
            C = bpy.data.objects[BONE_hierarchy_name].data.bones[bonename].matrix_local.copy()
            if (bpy.data.armatures[armature_name_context].bones[bonename].parent!=None):
                P_bone_name = bpy.data.armatures[armature_name_context].bones[bonename].parent.name
                P = bpy.data.armatures[armature_name_context].bones[P_bone_name].matrix_local.copy()
            else:
                P= mathutils.Matrix.Translation((0,0,0))
            P_in = P.inverted()    
            for i_keyvalue_type in range(0,number_type_keyvalue_mean):
                ###print("i_keyvalue_type=",i_keyvalue_type)
                #print("number_type_keyvalue_mean=",number_type_keyvalue_mean)
                #trackback()
                ba.seek(0x2,NOESEEK_REL)
                offset_jumptonext_type = ba.readUShort()
                ba.seek(0x4,NOESEEK_REL)
                ##print("    FF_offset",hex(ba.tell()))
                FF_offset = ba.tell()
                ba.seek(0x4,NOESEEK_REL)
                read_value_type = ba.readInt() #05: <xyz> and ?  06: XYZ-W
                read_value_type_addtion_structure1 = ba.readByte()
                read_value_type_addtion_structure2 = ba.readByte() 
                read_value_type_addtion_structure3 = ba.readByte()
                read_value_type_addtion_structure4 = ba.readByte()
                ba.seek(-0x4,NOESEEK_REL)
                read_value_type_addtion = ba.readInt()
                ###print("read_value_type_addtion=",hex(read_value_type_addtion))
                if read_value_type_addtion_structure1 != 0x0:
                    ba.seek(0x8,NOESEEK_REL)
                    read_max_frame = ba.readFloat()
                    read_value_lenth = ba.readInt()
                    ba.seek(FF_offset+0x1c,NOESEEK_ABS)
                    read_frame_offset =  ba.tell()
                    read_value_offset =  ba.tell() + 0x4*read_value_lenth
                if read_value_type_addtion_structure1 == 0x0:
                    read_max_frame = 1
                    read_value_lenth = 1
                    read_frame_offset= None
                    ba.seek(FF_offset+0x10,NOESEEK_ABS)
                    read_frame_offset = None 
                    read_value_offset =  ba.tell()
                #if 2<1:
                if read_value_type == 0x5: #0xc byte <xyz_LOCATION>
                    for i_frame in range(0,read_value_lenth):
                        ###print("    i_frame=",i_frame)
                        #if number_type_keyvalue == 0x2:
                        if read_value_type_addtion_structure1 ==0x3 and read_value_type_addtion_structure3 ==0x1:
                            ba.seek(read_value_offset+i_frame*0xc,NOESEEK_ABS) # if 03 00 01 xx,3*0x4 = 0xc
                                                                               # if 
                            #10.22 "FemaleKnuckle_unpack" --attack_long_H    ,bone["R:POS_ROOT"]XYZ? wrong,aren't need wave.
                            if i_frame==0:
                                print("    bone_name=",bonename,"mark:0x10003")                                             
                            #continue #trackback()
                            #10.22 "Gun_skill_18f_unpack" --R:X_R_EyeBlow01_D    [0,0,448]
                        #elif read_value_type_addtion_structure1 ==0x3 and read_value_type_addtion_structure3 ==0x2:
                        elif read_value_type_addtion_structure1 ==0x3 and read_value_type_addtion_structure2 ==0 and read_value_type_addtion_structure3 ==0x2:
                            ba.seek(read_value_offset+i_frame*0xc,NOESEEK_ABS) #if 03 00 02
                            #continue #a euler_rotation? no, have already wxyz in same time.  XYZ? 
                            #10.22 "FemaleKnuckle_unpack" --attack_long_H
                            #--down_F_FLY  [-83,0,-34] angle???
                            if i_frame==0:
                                print("    bone_name=",bonename,"mark:0x20003")
                            #trackback()
                            #continue                                                      
                        elif read_value_type_addtion_structure1 ==0x3 and read_value_type_addtion_structure3 ==0x3:
                            ba.seek(read_value_offset+i_frame*0xc,NOESEEK_ABS) #<XYZ>,not location.speed in 25F? 3.8m? ,change x=gohead
                            if i_frame==0:
                                print("    bone_name=",bonename,"mark:0x30003")
                            continue   #<xyz> X as Z?
                        #if number_type_keyvalue == 0x3:
                        elif read_value_type_addtion_structure1 ==0x3 and read_value_type_addtion_structure2 ==0x5:
                            ba.seek(read_value_offset+i_frame*0x24,NOESEEK_ABS) #if 03 05 04 xx,3*0x4+5*0x4+4*0x1= 0x20+0x4 ...
                            #10.22 example "run_LOOP.aaf"
                            #continue #trackback()
                        else:
                            continue
                        i_bone = bpy.data.objects[BONE_hierarchy_name].pose.bones[bonename]
                        ###loc_x=ba.readFloat()*-1 #/0.9615384
                        if read_value_type_addtion==0x40503:
                            loc_x=ba.readFloat()*-1 #/0.9615384
                        else:
                            loc_x=ba.readFloat()
                        loc_y=ba.readFloat() #/0.9615384
                        loc_z=ba.readFloat() #/0.9615384
                        
                        if read_value_type_addtion==0x30003:
                            loc_x,loc_z = loc_z,loc_x
                        if read_value_type_addtion==0x20003:
                            loc_x,loc_y = loc_y,loc_x    
                        ba.seek(0xc,NOESEEK_REL)
                        bpy.data.objects[BONE_hierarchy_name].pose.bones[bonename].location = [loc_x,loc_y,loc_z]
                        #loc_xk=ba.readFloat() #/0.9615384 
                        #loc_yk=ba.readFloat() #/0.9615384
                        #loc_zk=ba.readFloat() #/0.9615384
                        #bpy.data.objects[BONE_hierarchy_name].pose.bones[bonename].location = [loc_x*loc_xk,loc_y*loc_yk,loc_z*loc_zk]                        
                        #print(bpy.data.objects[BONE_hierarchy_name].pose.bones[bonename].location)
                        if read_frame_offset !=None:
                            ba.seek(read_frame_offset+i_frame*0x4,NOESEEK_ABS)
                            f = ba.readFloat()
                        else:
                            f = 0    
                        bpy.data.objects[BONE_hierarchy_name].pose.bones[bonename].keyframe_insert(data_path="location",frame=aqm_offsetframe+f)
                        ###if bonename=="R:X_slipper_move_L":
                            ###bpy.data.objects["visul_xyz"].location = [loc_x,loc_y,loc_z]
                            ####bpy.data.objects["visul_xyz"].keyframe_insert(data_path="location",frame=aqm_offsetframe+f)
                        #if i_bone.name =="R:X_C_UpperLip_D" and i_frame ==read_value_lenth -1:
                            #ba.seek(read_value_offset+i_frame*0xc,NOESEEK_ABS)
                            #print(hex(ba.tell()))
                            #trackbac()
                if read_value_type == 0x6: #quaternion_WXYZ
                    for i_frame in range(0,read_value_lenth):
                        i_bone = bpy.data.objects[BONE_hierarchy_name].pose.bones[bonename]
                        if read_frame_offset !=None:
                            ba.seek(read_frame_offset+i_frame*0x4,NOESEEK_ABS)
                            f = ba.readFloat()
                        else:
                            f = 0
                        ##if not (read_value_type_addtion_structure1==0x2 and read_value_type_addtion_structure2==0xd and read_value_type_addtion_structure3 == 0x9):
                            ##continue #00 0C 09 one Frame,almost wxyz 1,0,0,0 ,not read it
                        #if read_value_type_addtion_structure1==0x3 and read_value_type_addtion_structure2==0x5 and read_value_type_addtion_structure3 == 0x8:
                        #if bonename=="R:XD_SLska_01": #"viewer_Beadscp0110_b01a_unpack.apk",skirt
                            #print("read_value_type_addtion=",hex(read_value_type_addtion))
                            #trackback()
                        #if read_value_type_addtion not in (0x90d02,0x90c00):
                            #continue
                        if read_value_type_addtion in (0x90d02,0x90c00):    
                            ba.seek(read_value_offset+i_frame*0x10,NOESEEK_ABS)
                        elif read_value_type_addtion==0x80702:
                            ba.seek(read_value_offset+i_frame*0xc,NOESEEK_ABS) #xyz_euler_rotation
                            
                            Euler_Rollx = ba.readFloat()
                            Euler_Rolly = ba.readFloat()
                            Euler_Rollz = ba.readFloat() *-1
                            Euler_Rollx = Euler_Rollx*90 /180*3.1415926
                            Euler_Rolly = Euler_Rolly*90 /180*3.1415926
                            Euler_Rollz = Euler_Rollz*90 /180*3.1415926
                            bpy.data.objects[BONE_hierarchy_name].pose.bones[bonename].rotation_euler = [Euler_Rollx,Euler_Rolly,Euler_Rollz]
                            bpy.data.objects[BONE_hierarchy_name].pose.bones[bonename].keyframe_insert(data_path="rotation_euler",frame=aqm_offsetframe+f)
                            print("  f=",f)
                            continue
                        elif read_value_type_addtion==0x80503:
                            ba.seek(read_value_offset+i_frame*0x24,NOESEEK_ABS) #3x3 matrix?
                            roll_z63 = mathutils.Euler((0.0, 0.0, math.radians(63.0)), 'XYZ')
                            roll_z63 = roll_z63.to_matrix()
                            rollM_line = ba.readFloats(3)
                            roll_z63[0]= (rollM_line[0],rollM_line[1],rollM_line[2])
                            rollM_line = ba.readFloats(3)
                            roll_z63[1]= (rollM_line[0],rollM_line[1],rollM_line[2])
                            rollM_line = ba.readFloats(3)
                            roll_z63[2]= (rollM_line[0],rollM_line[1],rollM_line[2])
                            if bonename =="R:LeftUpLeg":
                                #print("  m=",roll_z63)
                                pass
                                #print("c=",roll_z63[0][0]*roll_z63[1][0]+roll_z63[0][1]*roll_z63[1][1]+roll_z63[0][2]*roll_z63[1][2])
                            #trackback()
                            
                            #bpy.data.objects[BONE_hierarchy_name].pose.bones[bonename].rotation_quaternion = roll_z63.to_quaternion()
                            #bpy.data.objects[BONE_hierarchy_name].pose.bones[bonename].keyframe_insert(data_path="rotation_quaternion",frame=aqm_offsetframe+f)
                            #print("  f=",f)
                            ba.seek(read_value_offset+i_frame*0x24,NOESEEK_ABS) #?????
                            
                            Euler_Rollx = ba.readFloat() 
                            Euler_Rolly = ba.readFloat() *-1 #ACCORDING TO "R:RightLeg"
                            
                            
                            
                            Euler_Rollz = ba.readFloat() *-1 #accorind to finger "R:LeftHandIndex1",pose to hold gun                          --------"FemaleGun_unpack"--down_F_END.aaf
                                                             #"R:LeftHandIndex1" and 2 and 3 use 24Euler,
                                                             #however,"R:LeftHandIndex4" use WXYZ
                            ##Euler_Rollx = Euler_Rollx*90 /180*3.1415926
                            ##Euler_Rolly = Euler_Rolly*90 /180*3.1415926
                            ##Euler_Rollz = Euler_Rollz*90 /180*3.1415926
                            bpy.data.objects[BONE_hierarchy_name].pose.bones[bonename].rotation_euler = [Euler_Rollx,Euler_Rolly,Euler_Rollz]
                            bpy.data.objects[BONE_hierarchy_name].pose.bones[bonename].keyframe_insert(data_path="rotation_euler",frame=aqm_offsetframe+f)
                            
                            ###bpy.data.objects[BONE_hierarchy_name].pose.bones[bonename].rotation_quaternion = roll_z63.to_quaternion()
                            ###bpy.data.objects[BONE_hierarchy_name].pose.bones[bonename].keyframe_insert(data_path="rotation_quaternion",frame=aqm_offsetframe+f)
                            #continue
                            
                            if i_frame==0:
                                bpy.data.objects["cp0002_b01a_unpack.amt"].pose.bones[bonename].rotation_mode = 'XYZ'
                                print("bone:",bonename,"24Euler")
                            continue    
                        else:
                            continue
 
                        Q_x = ba.readFloat()
                        Q_y = -ba.readFloat()
                        Q_z = -ba.readFloat()
                        Q_w = ba.readFloat()
                        Q_read = mathutils.Quaternion((Q_w,Q_x,Q_y,Q_z))
                        Q_read_M = mathutils.Quaternion((Q_w,Q_x,Q_y,Q_z)).to_matrix().to_4x4()
                        #bpy.data.objects[BONE_hierarchy_name].pose.bones[bonename].rotation_quaternion = [Q_w,Q_x,Q_y,Q_z]
                        
                        #bpy.data.objects[BONE_hierarchy_name].pose.bones[bonename].rotation_quaternion = Q_read.inverted() 
                        bpy.data.objects[BONE_hierarchy_name].pose.bones[bonename].rotation_quaternion = Q_read
                        ##bpy.data.objects[BONE_hierarchy_name].pose.bones[bonename].rotation_quaternion = Q_read_M.inverted().to_quaternion()
                        ###print("    XYZ-W:",bpy.data.objects[BONE_hierarchy_name].pose.bones[bonename].rotation_quaternion)
                        if read_frame_offset !=None:
                            ba.seek(read_frame_offset+i_frame*0x4,NOESEEK_ABS)
                            f = ba.readFloat()
                        else:
                            f = 0
                        bpy.data.objects[BONE_hierarchy_name].pose.bones[bonename].keyframe_insert(data_path="rotation_quaternion",frame=aqm_offsetframe+f)
                        if i_frame==0:
                            bpy.data.objects["cp0002_b01a_unpack.amt"].pose.bones[bonename].rotation_mode = 'QUATERNION'
                            print("bone:",bonename,"WXYZ")                        
                #0x964-0x238 = 72c
                ba.seek(FF_offset-0x8+offset_jumptonext_type,NOESEEK_ABS)
            ba.seek(i_bone_start+i_bone_offset_jumpNextBone,NOESEEK_ABS)
        print("this action keying",Bone_number,"Bones")
        print("readin_Action_name=",readin_aaf_filename)
        print("only a action load")
        trackback()                  
                
                
                
                
str_apk="E:\\xxxxxxxDownload\\StarOcean\\find\\data\\user\\0\\com.square_enix.android_googleplay.StarOceanj\\files\\download\\Motion\\"

pose_reset("cp0002_b01a_unpack.amt")
#loadAqm_NIFL(str_apk+"MaleTwinGun_unpack.apk","cp0002_b01a_unpack.amt")   
#loadAqm_NIFL(str_apk+"home_t_stance_unpack.apk","cp0002_b01a_unpack.amt")
#loadAqm_NIFL(str_apk+"NieR_A2_skill_01m_unpack.apk","cp0002_b01a_unpack.amt")
#loadAqm_NIFL(str_apk+"FemaleNieR_2B_unpack.apk","cp0002_b01a_unpack.amt")      #"home_cp0002_unpack" face act 
#loadAqm_NIFL(str_apk+"viewer_Beadscp0110_b01a_unpack.apk","viewer_Beadscp0110_b01a_unpack.amt")
#loadAqm_NIFL(str_apk+"FemaleBow_unpack.apk","cp0002_b01a_unpack.amt")
#loadAqm_NIFL(str_apk+"FemaleKnuckle_unpack.apk","cp0002_b01a_unpack.amt") 
loadAqm_NIFL(str_apk+"FemaleGun_unpack.apk","cp0002_b01a_unpack.amt")               
