from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Made Man [PC]", ".wim")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

#check if it's this type based on the data
def noepyCheckType(data):
    bs = NoeBitStream(data)
    if noeStrFromBytes(bs.readBytes(4)) != 'WIMG': return 0
    return 1
    
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.seek(0x4)
    fileSize = bs.readUInt()
    version = bs.readUInt() #?number of textures?
    tex1 = noeStrFromBytes(bs.readBytes(4))
    headerOffset = bs.readUInt()
    bs.seek(headerOffset)
    unk = bs.readShort()
    imgWidth = bs.readUInt()
    bs.readShort()
    imgHeight = bs.readUInt()
    bs.readShort()
    bs.readInt()
    mips = bs.readUShort()
    imgFmt = noeStrFromBytes(bs.readBytes(4))
    data = bs.readBytes(bs.getSize() - bs.tell())
    #DXT1
    if imgFmt == '1TXD':
        texFmt = noesis.NOESISTEX_DXT1
    #DXT5
    elif imgFmt == '5TXD':
        texFmt = noesis.NOESISTEX_DXT5
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, texFmt))
    return 1