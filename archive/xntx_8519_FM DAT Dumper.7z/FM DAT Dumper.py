import re
headers = []
UniqueFiles = 0
PotentialModels = 0

#Determines if a file is new or a duplicate.
def Header_Checker():

    #Loop through an array of previously seen headers, return true if its within the array.
    for i in range(len(headers)):
        if headers[i] == header:
            return True

    #Add this new header to the array.
    headers.append(header)
    return False


    
with open(,'rb') as DAT:
    with open(,'rb') as POS:

        #Calculate the start of the offsets and jump to them.
        OffsetsLocation = (int.from_bytes(POS.read(4), 'little') * 4) + 8 
        POS.seek(OffsetsLocation, 0)

        #Read from the POS until EOF.   
        while POS.read(8):

            #Jump back.    
            POS.seek(-8,1)

            #Get the offset of a file within the DAT and its size. 
            offset = int.from_bytes(POS.read(4), 'little') * 2048
            size = int.from_bytes(POS.read(4), 'little')

            #Jump to offset within the DAT and get the files header.
            DAT.seek(offset, 0)
            header = str(DAT.read(16))

            #Check the files header.
            duplicate = Header_Checker()

            if duplicate == False:
                UniqueFiles += 1

                #Read the file from the DAT.
                DAT.seek(offset, 0)
                data = DAT.read(size)

                if re.search(b'md[0-9]_', data) != None: # Search for the presence of this particular model tag within the file.
                    
                    #Write the data to a separate file.
                    with open( + str(offset), 'wb') as model:
                        PotentialModels += 1
                        model.write(data)
           
       
print('Unique Files:' + str(UniqueFiles), 'Potential Models:' + str(PotentialModels))      
        
        

