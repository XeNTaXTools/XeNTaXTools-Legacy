from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Final Fantasy XII: The Zodiac Age [PC]", ".phyre")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    texName = rapi.getLocalFileName(rapi.getInputName()).lower()
    if "dds.phyre" not in texName: return 0
    if noeStrFromBytes(bs.readBytes(4)) != "RYHP": return 0
    return 1
    
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.seek(0x8, NOESEEK_ABS)
    skipOFF = bs.readUInt()
    bs.seek(0x44, NOESEEK_REL)
    datasize = bs.readUInt()
    print(hex(datasize), ":data size")
    bs.seek(skipOFF + 0x4c, NOESEEK_REL)
    texName = bs.readString().split("/")
    texName = texName[-1].rstrip(".dds")
    print(texName)    
    tmp = bs.tell()
    print(hex(tmp), ":tmp")
    myString = bs.readBytes(bs.getSize() - tmp)
    myIndex = myString.find(b"\x00\x00\x50\x54\x65\x78\x74\x75\x72\x65\x32\x44")
    print(hex(myIndex))
    bs.seek((myIndex + tmp) - 6, NOESEEK_ABS)
    imgWidth = bs.readUInt()            
    imgHeight = bs.readUInt() 
    bs.seek(0xb, NOESEEK_REL)
    imgFmt = bs.readString()
    print(imgWidth, "x", imgHeight, "-", imgFmt)
    bs.seek(0x25, NOESEEK_REL)        
    data = bs.readBytes(datasize)      
    #BC5
    if imgFmt == "BC5":
        data = rapi.imageDecodeDXT(data, imgWidth, imgHeight, noesis.FOURCC_BC5)
        texFmt = noesis.NOESISTEX_RGBA32
    #ARGB8
    elif imgFmt == "ARGB8":                                     
        data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "b8 g8 r8 a8")
        texFmt = noesis.NOESISTEX_RGBA32
    #DXT5
    elif imgFmt == "DXT5":                                     
        texFmt = noesis.NOESISTEX_DXT5
    #A8
    elif imgFmt == "A8":                                     
        data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "a8")
        texFmt = noesis.NOESISTEX_RGBA32
    #RGBA16F cubemap
    #elif imgFmt == "RGBA16F":                                     
    #    data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "r16 g16 b16 a16")
    #    texFmt = noesis.NOESISTEX_RGBA32
    texList.append(NoeTexture(texName, imgWidth, imgHeight, data, texFmt))
    return 1