import newGameLib
from newGameLib import *
import Blender	


BINDPOSEFLAG=1


def datParser(filename,g):
	g.word(4)
	count=g.i(1)[0]
	sys=Sys(filename)
	sys.addDir(sys.base)
	for m in range(count):
		offset,size=g.i(2)
		t=g.tell()
		g.seek(offset)
		flag=g.read(4)
		if flag=='\x00\x78\x65\x74':
			g.seek(offset+144)
			data=g.read(size)
			try:data=zlib.decompress(data)
			except:pass
			img=imageLib.Image()
			img.szer=struct.unpack('H',data[:2])[0]
			img.wys=struct.unpack('H',data[2:4])[0]
			format=struct.unpack('BBBBBBBB',data[4:12])
			img.name=sys.dir+os.sep+sys.base+os.sep+str(m)+'.dds'
			if format[2]==0:img.format='DXT1'
			elif format[2]==32:img.format='DXT5'
			elif format[2]==16:img.format='DXT3'
			else:print m,'unknow format:',format
			img.data=data[12:]
			img.draw()
		elif flag=='\x00\x68\x73\x63':
			g.seek(offset+144)
			new=open(sys.dir+os.sep+sys.base+os.sep+str(m)+'.hsc','wb')
			data=zlib.decompress(g.read(size))
			new.write(data)
			new.close()
		elif flag=='\x00\x63\x64\x6d':
			g.seek(offset+144)
			new=open(sys.dir+os.sep+sys.base+os.sep+str(m)+'.cdm','wb')
			data=zlib.decompress(g.read(size))
			new.write(data)
			new.close()
		elif flag=='\x00\x6c\x64\x6d':
			g.seek(offset+144)
			new=open(sys.dir+os.sep+sys.base+os.sep+str(m)+'.ldm','wb')
			data=zlib.decompress(g.read(size))
			new.write(data)
			new.close()
		elif flag=='\x00\x6b\x70\x6d':
			g.seek(offset+144)
			new=open(sys.dir+os.sep+sys.base+os.sep+str(m)+'.kpm','wb')
			data=zlib.decompress(g.read(size))
			new.write(data)
			new.close()
		elif flag=='\x00\x73\x6d\x63':
			g.seek(offset+144)
			new=open(sys.dir+os.sep+sys.base+os.sep+str(m)+'.smc','wb')
			data=zlib.decompress(g.read(size))
			new.write(data)
			new.close()
		elif flag=='\x00\x64\x73\x63':
			g.seek(offset+144)
			new=open(sys.dir+os.sep+sys.base+os.sep+str(m)+'.dsc','wb')
			data=zlib.decompress(g.read(size))
			new.write(data)
			new.close()
		elif flag=='\x00\x52\x33\x4d':
			g.seek(offset+144)
			new=open(sys.dir+os.sep+sys.base+os.sep+str(m)+'.r3m','wb')
			data=zlib.decompress(g.read(size))
			new.write(data)
			new.close()
		else:
			g.seek(offset)
			new=open(sys.dir+os.sep+sys.base+os.sep+str(m)+'.txt','wb')
			data=g.read(size)
			new.write(data)
			new.close()
		g.seek(t)
	g.tell()
	
	
	
	


def bindPose(bindSkeleton,poseSkeleton,meshObject):
		mesh=meshObject.getData(mesh=1)
		poseBones=poseSkeleton.getData().bones
		bindBones=bindSkeleton.getData().bones			
		for vert in mesh.verts:
			index=vert.index
			skinList=mesh.getVertexInfluences(index)
			vco=vert.co.copy()*meshObject.matrixWorld
			vector=Vector()
			waga=0
			for skin in skinList:
					bone=skin[0]							
					weight=skin[1]	
					waga+=weight	
					matA=bindBones[bone].matrix['ARMATURESPACE']*bindSkeleton.matrixWorld
					matB=poseBones[bone].matrix['ARMATURESPACE']*poseSkeleton.matrixWorld
					vector+=vco*matA.invert()*matB*weight
			vert.co=vector
			if waga<0.9:
				print waga,
		mesh.update()
		Blender.Window.RedrawAll()
	
def ldmParser(filename,g):
	A=g.i(11)
	t=g.tell()
	boneNameList=[]
	for m in range(A[2]):boneNameList.append(g.find('\x00'))
	g.seek(t+A[0])
	boneMap=g.H(A[1]/2)
	skeleton=Skeleton()
	skeleton.BONESPACE=True
	skeleton.NICE=True
	skeleton.name='poseskeleton'
	for m in range(A[2]):
		bone=Bone()
		bone.name=boneNameList[m]
		rotMatrix=QuatMatrix(g.f(4)).resize4x4()
		posMatrix=VectorMatrix(g.f(3))
		matrix=rotMatrix*posMatrix
		bone.posMatrix=posMatrix
		g.f(3)
		B=g.h(8)
		bone.parentID=B[2]
		m,g.read(8)
		skeleton.boneList.append(bone)
	for m in range(A[2]):
		bone=skeleton.boneList[m]
		a=g.f(4)[:3]
		b=g.f(4)[:3]
		c=g.f(4)[:3]
		d=g.f(4)[:3]
		rotMatrix=Matrix(a,b,c).resize4x4()
		bone.rotMatrix=rotMatrix
	skeleton.draw()	
	skeleton=Skeleton()
	skeleton.ARMATURESPACE=True
	skeleton.NICE=True
	skeleton.name='bindskeleton'
	for m in range(A[2]):
		bone=Bone()
		bone.name=boneNameList[m]
		a=g.f(4)[:3]
		b=g.f(4)[:3]
		c=g.f(4)[:3]
		d=g.f(4)[:3]
		rotMatrix=Matrix(a,b,c).resize4x4()
		posMatrix=VectorMatrix(d)
		matrix=rotMatrix*posMatrix
		bone.matrix=matrix.invert()
		skeleton.boneList.append(bone)
	skeleton.draw()	
	for m in range(A[6]):
		g.B(8)
		g.i(6)
		g.f(4)
		g.f(4)		
		g.f(4)
		g.f(4)
		g.f(4)
	meshList=[]	
	for m in range(A[7]):	
		mesh=Mesh()
		mesh.info=g.i(13)
		meshList.append(mesh)
	start=g.tell()
	for mesh in meshList:
		g.seek(start+mesh.info[2])
		vertCount=mesh.info[3]/mesh.info[4]
		for m in range(vertCount):
			t=g.tell()
			mesh.vertPosList.append(g.f(3))
			if mesh.info[4]==68:g.seek(t+52)	
			if mesh.info[4]==64:g.seek(t+48)	
			if mesh.info[4]==60:g.seek(t+52)		
			if mesh.info[4]==56:g.seek(t+48)					
			mesh.vertUVList.append(g.f(2))
			skinFlag=1
			if mesh.info[4]==68:g.seek(t+60)	
			elif mesh.info[4]==64:g.seek(t+56)
			else:skinFlag=0
			if skinFlag==1:	
				mesh.skinIndiceList.append(g.B(4))
				mesh.skinWeightList.append(g.B(4))
			g.seek(t+mesh.info[4])			
		skin=Skin()
		skin.boneMap=boneMap[mesh.info[9]:mesh.info[9]+mesh.info[10]]
		mesh.boneNameList=boneNameList
		mesh.skinList.append(skin)	
		g.seek(start+A[8]+mesh.info[5])
		mesh.indiceList=g.H(mesh.info[6]/2)
		mesh.TRIANGLE=True				
		mesh.draw()
		if BINDPOSEFLAG==True:	
			if len(mesh.skinIndiceList)>0 and len(mesh.skinWeightList)>0:
				bindSkeleton=Blender.Object.Get('bindskeleton')
				poseSkeleton=Blender.Object.Get('poseskeleton')
				meshObject=Blender.Object.Get(mesh.object.name)
				bindPose(bindSkeleton,poseSkeleton,meshObject)	
	g.seek(start+A[8]+A[9])
	if BINDPOSEFLAG==True:	
			scene = bpy.data.scenes.active
			for object in scene.objects:
				if object.type=='Armature':
					if 'bindskeleton' in object.name:		
						scene.objects.unlink(object)
			scene.update()
			scene = bpy.data.scenes.active	
			try:poseSkeleton=Blender.Object.Get('poseskeleton')	
			except:pass
			if poseSkeleton is not None:
				for object in scene.objects:
					if object.type=='Mesh':
						poseSkeleton.makeParentDeform([object],0,0)
	print 'DONE'
	
def cshParser(filename,g):
	g.seek(144)
	new=open(filename+'.hsc','wb')
	data=zlib.decompress(g.read(g.fileSize()-144))
	new.write(data)
	new.close()
	g.tell()
		
def hscParser(filename,g):
	g.endian='>'
	A=g.i(3)
	for n in range(A[2]):	
		g.logWrite(n)
		for k in range(A[1]):
			a=g.i(1)[0]	
			b=g.B(4)
			print n,a,b,
			t=g.tell()
			g.seek(a)
			if b[0]==0:
				print g.find('\x00'),
			else:	
				print g.i(b[3]),
			g.seek(t)
		print	
	"""g.seek(448)
	for n in range(0):
		g.B(4)
		g.seekpad(4)
		n,g.find('\x00')
		g.B(8)
		g.seekpad(4)
		g.find('\x00')
		#p.B(3)
		g.seekpad(4)"""
			
		

def Parser():	
	filename=input.filename
	print
	print filename
	print
	
	ext=filename.split('.')[-1].lower()	
	
	
	if ext=='hsc':
		file=open(filename,'rb')
		g=BinaryReader(file)
		hscParser(filename,g)
		file.close()
		
	if ext=='csh':
		file=open(filename,'rb')
		g=BinaryReader(file)
		cshParser(filename,g)
		file.close()
	
	if ext=='dat':
		file=open(filename,'rb')
		g=BinaryReader(file)
		datParser(filename,g)
		file.close()
	
	if ext=='ldm':
		file=open(filename,'rb')
		g=BinaryReader(file)
		ldmParser(filename,g)
		file.close()
 
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
	 
Blender.Window.FileSelector(openFile,'import','Rise Of Incarnates files: dat - container file, ldm - skinned meshes') 