from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("Sims 3 [DS]", ".dst")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    bs = NoeBitStream(data)
    if noeStrFromBytes(bs.readBytes(4)) != 'DST1': return 0
    return 1
    
def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    bs.seek(0x4)
    bs.readByte()
    bs.readByte()
    bs.readByte()
    bs.readByte()
    bs.readShort()
    bs.readShort()
    imgWidth = bs.readUShort()
    imgHeight = bs.readUShort()
    numColors = bs.readUShort()
    palette = []
    for i in range(numColors):
        color = bs.readUShort()
        alpha = (color & 0x8000) >> 15
        red = (color & 0x7C00) >> 7
        green = (color & 0x03E0) >> 2
        blue = (color & 0x001F) << 3
        # print(hex(alpha), ":alpha")
        # print(hex(red), ":red")
        # print(hex(green), ":green")
        # print(hex(blue), ":blue", "\n")
        palette.append(blue)
        palette.append(green)
        palette.append(red)
        #palette.append(alpha)
        palette.append(0xFF)
    palette = bytearray(palette)
    data = bs.readBytes(imgWidth * imgHeight)
    data = rapi.imageDecodeRawPal(data, palette, imgWidth, imgHeight, 8, "r8 g8 b8 a8")
    texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, noesis.NOESISTEX_RGBA32))
    return 1