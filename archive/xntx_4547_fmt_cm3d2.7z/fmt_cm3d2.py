#sample class
from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Custom Maid 3D 2", ".model")
	noesis.setHandlerTypeCheck(handle, cm3d2modCheckType)
	noesis.setHandlerLoadModel(handle, cm3d2modLoadModel)

	#handle = noesis.register("cm3d2 tex", ".cm3d2tex")
	#noesis.setHandlerTypeCheck(handle, cm3d2texCheckType)
	#noesis.setHandlerLoadRGBA(handle, cm3d2texLoadRGBA)
	#noesis.logPopup()

	return 1


def cm3d2modCheckType(data):
	td = NoeBitStream(data)
	myHeader = td.readBytes(11).decode("ASCII")
	if "\nCM3D2_MESH" == myHeader:
		return 1
	else:
		return 0

#def cm3d2texCheckType(data):
#	td = NoeBitStream(data)
#	return 1

class cm3d2File: 
         
	def __init__(self, bs):
		self.bs = bs
		self.texList  = []
		self.matList  = [] 
		self.boneList = []
		self.boneMap  = []
		self.offsetList = []
		self.meshOffsets = []

	def loadAll(self, bs):
		self.loadMeshHeader(bs)
		self.loadBones(bs)

	def loadMeshNames(self, bs):
		pass

	def loadMeshHeader(self, bs):
		myHeader = bs.readBytes(11).decode("ASCII")
		myVersion = bs.readUInt()
		modelNameSize = bs.readUByte()
		modelName = bs.readBytes(modelNameSize).decode("ASCII")
		sceneNameSize = bs.readUByte()
		sceneName = bs.readBytes(sceneNameSize).decode("ASCII")
		print(modelName, sceneName)
		
	def loadBones(self, bs):
		boneCount = bs.readUInt()
		print(boneCount)

	def loadMeshInfo(self, bs):
		pass

	def loadUnk1(self, bs):
		pass

	def loadBonePallet(self, bs):
		pass

	def loadTex(self): 
		pass

	def loadMatInfo(self, bs):
		pass

	def loadMeshs(self, bs):
		pass

def cm3d2modLoadModel(data, mdlList):
	ctx = rapi.rpgCreateContext()
	cm3d2 = cm3d2File(NoeBitStream(data))
	cm3d2.loadAll(cm3d2.bs)
	try:
		mdl = rapi.rpgConstructModel()
	except:
		mdl = NoeModel()
	mdl.setModelMaterials(NoeModelMaterials(cm3d2.texList, cm3d2.matList))
	mdlList.append(mdl); mdl.setBones(cm3d2.boneList)	
	return 1


#def cm3d2texLoadRGBA(data, texList):
#	td = NoeBitStream(data)
#	return 1