#ifndef __STDAFX_H
#define __STDAFX_H

// Windows Headers
#define NOMINMAX
#pragma warning (disable : 4307)
#pragma warning (disable : 4996)
#include<windows.h>
#include<shlobj.h>
#include<ddraw.h>

// Standard Headers
#include<iostream>
#include<iomanip>
#include<fstream>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<vector>
#include<string>
#include<sstream>
using namespace std;

// Boost Headers
#include<boost/shared_array.hpp>
#include<boost/shared_ptr.hpp>

// SL Headers
#include "slMathTraits.h"
#include "slEuler.h"
#include "slVector2D.h"
#include "slVector3D.h"
#include "slMatrix.h"

template<class T>
inline void reverse_byte_order(T* data)
{
 unsigned char* ptr = reinterpret_cast<unsigned char*>(data);
 std::reverse(ptr, ptr + sizeof(T)); 
}

inline unsigned int interpret_as_unsigned(float x) { return *(reinterpret_cast<unsigned*>(&x)); }
inline float interpret_as_float(unsigned int x) { return *(reinterpret_cast<float*>(&x)); }

float float_16_to_32(unsigned short value);
bool error(const char* message);
bool get_filename_list(deque<string>& namelist, const char* fext);
bool get_filename_list(deque<string>& namelist, const char* fext, const char* rootname);

__int16 LE_read_sint16(ifstream& ifile);
__int32 LE_read_sint32(ifstream& ifile);

unsigned __int8  LE_read_uint08(ifstream& ifile);
unsigned __int16 LE_read_uint16(ifstream& ifile);
unsigned __int32 LE_read_uint32(ifstream& ifile);
unsigned __int64 LE_read_uint64(ifstream& ifile);
unsigned __int8  BE_read_uint08(ifstream& ifile);
unsigned __int16 BE_read_uint16(ifstream& ifile);
unsigned __int32 BE_read_uint32(ifstream& ifile);
unsigned __int64 BE_read_uint64(ifstream& ifile);

unsigned __int8  LE_read_uint08(ifstream& ifile, unsigned int offset);
unsigned __int16 LE_read_uint16(ifstream& ifile, unsigned int offset);
unsigned __int32 LE_read_uint32(ifstream& ifile, unsigned int offset);
unsigned __int64 LE_read_uint64(ifstream& ifile, unsigned int offset);
unsigned __int8  BE_read_uint08(ifstream& ifile, unsigned int offset);
unsigned __int16 BE_read_uint16(ifstream& ifile, unsigned int offset);
unsigned __int32 BE_read_uint32(ifstream& ifile, unsigned int offset);
unsigned __int64 BE_read_uint64(ifstream& ifile, unsigned int offset);

signed __int16 BE_read_sint16(ifstream& ifile);

float LE_read_half_float(ifstream& ifile);
float BE_read_half_float(ifstream& ifile);
float LE_read_float(ifstream& ifile);
float BE_read_float(ifstream& ifile);
double LE_read_double(ifstream& ifile);
double BE_read_double(ifstream& ifile);

float LE_read_float(ifstream& ifile, unsigned int offset);
float BE_read_float(ifstream& ifile, unsigned int offset);
double LE_read_double(ifstream& ifile, unsigned int offset);
double BE_read_double(ifstream& ifile, unsigned int offset);

// read arrays
template<class T>
inline bool LE_read_array(ifstream& ifile, T* data, unsigned int n)
{
 ifile.read((char*)&data[0], n*sizeof(T));
 if(ifile.fail()) return false;
 return true;
}

template<class T>
inline bool BE_read_array(ifstream& ifile, T* data, unsigned int n)
{
 ifile.read((char*)&data[0], n*sizeof(T));
 if(ifile.fail()) return false;
 if(sizeof(*data) > 1) for(size_t i = 0; i < n; i++) reverse_byte_order(&data[i]);
 return true;
}

template<class T>
inline bool LE_read_array(ifstream& ifile, unsigned int offset, T* data, unsigned int n)
{
 ifile.seekg(offset);
 if(ifile.fail()) return false;
 return LE_read_float_array(ifile, data, n);
}

template<class T>
inline bool BE_read_array(ifstream& ifile, unsigned int offset, T* data, unsigned int n)
{
 ifile.seekg(offset);
 if(ifile.fail()) return false;
 return BE_read_float_array(ifile, data, n);
}

class find_file {
 protected :
  HANDLE          handle;
  WIN32_FIND_DATA find32;
 public :
  void close(void);
 public :
  bool find(const char* filename);
  bool next(void);
 public :
  bool is_dots(void);
  bool is_directory(void);
  bool is_encrypted(void);
  bool is_compressed(void);
  bool is_normal(void);
  bool is_hidden(void);
  bool is_system(void);
  bool is_archived(void);
  bool is_readonly(void);
 public :
  const char* filename(void);
  size_t filesize(void);
 public :
  bool operator !(void)const;
 public :
  find_file();
 ~find_file();
 private :
  find_file(const find_file&);
  void operator =(const find_file&);
};

void CenterDialog(HWND window, bool in_parent = true);
BOOL BrowseDirectoryDialog(HWND parent, const char* caption, char* buffer);
BOOL ColorDialog(HWND parent, COLORREF& color);
BOOL OpenFileDialog(HWND parent, const char* filter, const char* title, const char* defext, char* filename, char* initdir = 0);
BOOL SaveFileDialog(HWND parent, const char* filter, const char* title, const char* defext, char* filename, char* initdir = 0);

#endif
