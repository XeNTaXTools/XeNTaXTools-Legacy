TYPEINFO
 Stores information about the different types of data stored in the file and how
 many of them they are. Example:
 info->typeName = RENDERSTREAMINSTANCE
 info->typeCount = 38
 RENDERINDEXSOURCE and RENDERDATASOURCE should have same typeCount.

RENDERSTREAMINSTANCE
 Associates an index buffer id with a shader id.

RENDERDATASOURCE
 Contains information about geometry. Links to one or more streams that contain links to
 buffers used to render geometry. There are two types of data sources, with index buffers
 and without index buffers. If the first child is a RENDERINDEXSOURCE, the s

SEGMENTSET
 Stores index buffers! Contains an id and links to segmentCount number of segments.
 Each segment is a RENDERDATASOURCE, which eventually links to an index buffer.
 SEGMENTSET
  - RENDERDATASOURCE
    - RENDERINDEXSOURCE
      - INDEXSOURCEDATA
    - RENDERSTREAM
    - RENDERSTREAM
    - RENDERSTREAM

DATABLOCK
 Stores data along with an id. Links to the information about the data and the actual data.
 Appears to always only contains one stream. Vertices and normals and UV data are stored in
 separate data blocks (non-interleaved arrays). Vertices may be stored int DATABLOCK:block
 and normals stored in DATABLOCK:blockB.
 DATABLOCK
  - DATABLOCKSTREAM (always at least 1)
  - DATABLOCKDATA
  - DATABLOCKSTREAM (if any)
  - DATABLOCKDATA
  - DATABLOCKSTREAM (if any)
  - DATABLOCKDATA

Best thing to do is to load all datablocks into a map keyed by name since all index buffers
reference datablocks by name. Segment set data can be stored into separate OBJ files.

(offset, name, parent) = (408300,RENDERINDEXSOURCE,408255)
(offset, name, parent) = (408414,RENDERSTREAM,408255)
(offset, name, parent) = (408478,RENDERSTREAM,408255)
(offset, name, parent) = (408542,RENDERSTREAM,408255)

// MAYA PYTHON!
import maya.cmds as cmds
v1 = [0, 0, 0];
v2 = [0, 0, 1];
v3 = [0, 1, 1];
cmds.polyCreateFacet(p = [(v1[0], v1[1], v1[2]), (v2[0], v2[1], v2[2]), (v3[0], v3[1], v3[2])]);

// MAYA PYTHON EVEN BETTER!
import maya.cmds as cmds
data = [[0, 0, 0], [0, 0, 1],[0, 1, 1]];
cmds.polyCreateFacet(p = data);