#ifndef __TOTORI_H
#define __TOTORI_H

struct TREENODE {
 public :
  unsigned int chunktype;
  unsigned int chunksize;
  unsigned int propbytes;
 public :
  unsigned int parent;
  deque<unsigned int> children;
};

// ANIMATION
// CHILD CHUNKS: YES
struct ANIMATION : public TREENODE {
 unsigned int channelCount;
 unsigned int constantChannelCount;
 float constantChannelStartTime;
 float constantChannelEndTime;
 string id;
};

// ANIMATIONCHANNEL
// CHILD CHUNKS: NO
struct ANIMATIONCHANNEL : public TREENODE {
 string timeBlock;
 string valueBlock;
 string id;
};

// ANIMATIONCHANNELDATABLOCK
// CHILD CHUNKS: YES
struct ANIMATIONCHANNELDATABLOCK : public TREENODE {
 unsigned int keyCount;
 string keyType;
 string id;
};

// ANIMATIONREF
// CHILD CHUNKS: NO
struct ANIMATIONREF : public TREENODE {
 string animation;
};

// ANIMATIONSET
// CHILD CHUNKS: YES
struct ANIMATIONSET : public TREENODE {
 unsigned int animationCount;
 string id;
};

// BOUNDINGBOX
// CHILD CHUNKS: NO
struct BOUNDINGBOX : public TREENODE {
 float bbmin[3];
 float bbmax[3];
};

// CAMERANODE
// CHILD CHUNKS: NO
struct CAMERANODE : public TREENODE {
 unsigned int isPerspective;
 float nearPlane;
 float farPlane;
 float aspect;
 float FOV;
 unsigned int stopTraversal;
 string nickname;
 string id;
};

// CGSTREAM
// CHILD CHUNKS: NO
struct CGSTREAM : public TREENODE {
 string cgStreamName;
 string cgStreamDataType;
 string cgStreamRenderType;
};

// CHANNELREF
// CHILD CHUNKS: NO
struct CHANNELREF : public TREENODE {
 string channel;
 string targetName;
};

// DATABLOCK
// CHILD CHUNKS: YES
struct DATABLOCK : public TREENODE {
 unsigned int streamCount;
 unsigned int size;
 unsigned int elementCount;
 unsigned int allocationStrategy;
 string id;
};

// DATABLOCKDATA
// CHILD CHUNKS: NO
struct DATABLOCKDATA : public TREENODE {
 boost::shared_array<unsigned char> data;
};

// DATABLOCKSTREAM
// CHILD CHUNKS: NO
struct DATABLOCKSTREAM : public TREENODE {
 string renderType;
 string dataType;
 unsigned int offset;
 unsigned int stride;
};

// INDEXSOURCEDATA
// CHILD CHUNKS: NO
struct INDEXSOURCEDATA : public TREENODE {
 boost::shared_array<unsigned char> data;
};

// INVERSEBINDMATRIX
// CHILD CHUNKS: NO
struct INVERSEBINDMATRIX : public TREENODE {
 float matrix[16];
};

// DATABLOCKSTREAM
// CHILD CHUNKS: UNKNOWN
struct JOINTNODE : public TREENODE {
 unsigned int stopTraversal;
 string nickname;
 string id;
};

// KEYS
// CHILD CHUNKS: NO
struct KEYS : public TREENODE {
 boost::shared_array<float> data;
};

// LIBRARY
// CHILD CHUNKS: YES
struct LIBRARY : public TREENODE {
 string type;
};

// MODIFIERNETWORK
// CHILD CHUNKS: YES
struct MODIFIERNETWORK : public TREENODE {
 unsigned int modifierCount;
 string streamingStrategy;
 string id;
};

// MODIFIERNETWORKCONNECTION
// CHILD CHUNKS: NO
struct MODIFIERNETWORKCONNECTION : public TREENODE {
 unsigned int modifier;
 unsigned int stream;
};

// MODIFIERNETWORKENTRY
// CHILD CHUNKS: YES
struct MODIFIERNETWORKENTRY : public TREENODE {
 string name;
};

// MODIFIERNETWORKINSTANCE
// CHILD CHUNKS: YES
struct MODIFIERNETWORKINSTANCE : public TREENODE {
 unsigned int dynamicStreamCount;
 unsigned int modifierInputCount;
 unsigned int modifierCount;
 unsigned int packetModifierCount;
 unsigned int sourceCount;
 unsigned int streamCount;
 unsigned int parameterCount;
 unsigned int allocationStrategy;
 string network;
 string indices;
 string shader;
 string id;
};

// MODIFIERNETWORKINSTANCECOMPILE
// CHILD CHUNKS: YES
struct MODIFIERNETWORKINSTANCECOMPILE : public TREENODE {
 unsigned int uniqueInputCount;
 unsigned int maxElementCount;
 unsigned int memorySizeForProcess;
};

// MODIFIERNETWORKINSTANCEDYNAMICSTREAM
// CHILD CHUNKS: NO
struct MODIFIERNETWORKINSTANCEDYNAMICSTREAM : public TREENODE {
 unsigned int id;
};

// MODIFIERNETWORKINSTANCEDYNAMICSTREAMTYPE
// CHILD CHUNKS: NO
struct MODIFIERNETWORKINSTANCEDYNAMICSTREAMTYPE : public TREENODE {
 string type;
};

// MODIFIERNETWORKINSTANCEMODIFIERINPUT
// CHILD CHUNKS: NO
struct MODIFIERNETWORKINSTANCEMODIFIERINPUT : public TREENODE {
 unsigned int source;
 unsigned int stream;
};

// MODIFIERNETWORKINSTANCEUNIQUEINPUT
// CHILD CHUNKS: NO
struct MODIFIERNETWORKINSTANCEUNIQUEINPUT : public TREENODE {
 unsigned int uniqueInputSource;
 unsigned int uniqueInputStream;
 unsigned int uniqueInputElementSize;
};

// MODIFIERNETWORKINSTANCEUNIQUEMODIFIERINPUT
// CHILD CHUNKS: NO
struct MODIFIERNETWORKINSTANCEUNIQUEMODIFIERINPUT : public TREENODE {
 boost::shared_array<unsigned char> data;
};

// MORPHMODIFIERWEIGHTS
// CHILD CHUNKS: NO
struct MORPHMODIFIERWEIGHTS : public TREENODE {
 unsigned int weightCount;
 string id;
};

// NODE
// CHILD CHUNKS: YES
struct NODE : public TREENODE {
 unsigned int stopTraversal;
 string nickname;
 string id;
};

// PSSGDATABASE
// CHILD CHUNKS: YES
struct PSSGDATABASE : public TREENODE {
 string creator;
 string creationMachine;
 string creationDate;
 float scale[3];
 float up[3];
};

// RENDERDATASOURCE
// CHILD CHUNKS: YES
struct RENDERDATASOURCE : public TREENODE {
 unsigned int streamCount;
 string primitive;
 string id;
};

// RENDERINDEXSOURCE
// CHILD CHUNKS: YES
struct RENDERINDEXSOURCE : public TREENODE {
 string primitive;
 string format;
 unsigned int count;
 unsigned int maximumIndex;
 unsigned int allocationStrategy;
 string id;
 unsigned int size;
};

// RENDERINSTANCESOURCE
// CHILD CHUNKS: NO
struct RENDERINSTANCESOURCE : public TREENODE {
 string source;
};

// RENDERINSTANCESTREAM
// CHILD CHUNKS: NO
struct RENDERINSTANCESTREAM : public TREENODE {
 unsigned int sourceID;
 unsigned int streamID;
};

// RENDERNODE
// CHILD CHUNKS: YES
struct RENDERNODE : public TREENODE {
 unsigned int stopTraversal;
 string nickname;
 string id;
};

// RENDERSTREAM
// CHILD CHUNKS: NO
struct RENDERSTREAM : public TREENODE {
 string dataBlock;
 unsigned int subStream;
 string id;
};

// RENDERSTREAMINSTANCE
// CHILD CHUNKS: YES
struct RENDERSTREAMINSTANCE : public TREENODE {
 unsigned int sourceCount;
 unsigned int streamCount;
 unsigned int allocationStrategy;
 string indices;
 string shader;
 string id;
};

// RISTREAM
// CHILD CHUNKS: NO
struct RISTREAM : public TREENODE {
 unsigned int stream; // changed
 unsigned int id;
};

// ROOTNODE
// CHILD CHUNKS: YES
struct ROOTNODE : public TREENODE {
 unsigned int stopTraversal;
 string nickname;
 string id;
};

struct SEGMENTSET : public TREENODE {
 unsigned int segmentCount;
 string id;
};

// SHADERGROUP
// CHILD CHUNKS: YES
struct SHADERGROUP : public TREENODE {
 unsigned int parameterCount;
 unsigned int parameterSavedCount;
 unsigned int parameterStreamCount;
 unsigned int instancesRequireSorting;
 unsigned int defaultRenderSortPriority;
 unsigned int passCount;
 string id;
};

// SHADERGROUPPASS
// CHILD CHUNKS: NO
struct SHADERGROUPPASS : public TREENODE {
 string vertexProgram;
 string fragmentProgram;
 string blendSourceColor;
 string blendDestColor;
 string blendSourceAlpha;
 string blendDestAlpha;
 string blendEquationColor;
 string blendEquationAlpha;
 string alphaTestFunc;
 string cullFaceType;
 string depthTestFunc;
 unsigned int renderTargetMask;
 unsigned int clearMask;
 unsigned int passConfigMask;
 unsigned int depthTestEnable;
 unsigned int depthMaskEnable;
 unsigned int blendEnable;
 unsigned int alphaTestEnable;
 unsigned int alphaTestRef;
 unsigned int pointTexCoordMask;
 float pointSize;
};

// SHADERINPUT
// CHILD CHUNKS: NO
struct SHADERINPUT : public TREENODE {
 unsigned int parameterID;
 string type;
 string format;
 string texture;
 boost::shared_array<unsigned char> data;
};

// SHADERINPUTDEFINITION
// CHILD CHUNKS: NO
struct SHADERINPUTDEFINITION : public TREENODE {
 string name;
 string type;
 string format;
};

// SHADERINSTANCE
// CHILD CHUNKS: NO
struct SHADERINSTANCE : public TREENODE {
 string shaderGroup;
 unsigned int parameterCount;
 unsigned int parameterSavedCount;
 unsigned int renderSortPriority;
 string id;
};

// SHADERPROGRAM
// CHILD CHUNKS: YES
struct SHADERPROGRAM : public TREENODE {
 unsigned int codeCount;
 string id;
};

// SHADERPROGRAMCODE
// CHILD CHUNKS: YES
struct SHADERPROGRAMCODE : public TREENODE {
 unsigned int codeSize;
 string codeType;
 string codeEntry;
 unsigned int profileType;
 unsigned int profile;
 unsigned int parameterCount;
 unsigned int streamCount;
};

// SHADERPROGRAMCODEBLOCK
// CHILD CHUNKS: NO
struct SHADERPROGRAMCODEBLOCK : public TREENODE {
 boost::shared_array<unsigned char> data;
};

// SHADERSTREAMDEFINITION
// CHILD CHUNKS: NO
struct SHADERSTREAMDEFINITION : public TREENODE {
 string renderTypeName;
 string name;
};

// SKELETON
// CHILD CHUNKS: YES
struct SKELETON : public TREENODE {
 unsigned int matrixCount;
 string id;
  boost::shared_array<INVERSEBINDMATRIX> ibm;
};

// SKINJOINT
// CHILD CHUNKS: NO
struct SKINJOINT : public TREENODE {
 string joint;
};

// SKINNODE
// CHILD CHUNKS: YES
struct SKINNODE : public TREENODE {
 unsigned int stopTraversal;
 string nickname;
 string id;
 unsigned int jointCount;
 string skeleton;
};

// TEXTURE
// CHILD CHUNKS: YES
struct TEXTURE : public TREENODE {
 unsigned int width;
 unsigned int height;
 string texelFormat;
 unsigned int transient;
 unsigned int wrapS;
 unsigned int wrapT;
 unsigned int wrapR;
 unsigned int minFilter;
 unsigned int magFilter;
 unsigned int automipmap;
 unsigned int numberMipMapLevels;
 unsigned int gammaRemapR;
 unsigned int gammaRemapG;
 unsigned int gammaRemapB;
 unsigned int gammaRemapA;
 unsigned int resolveMSAA;
 unsigned int imageBlockCount;
 unsigned int allocationStrategy;
 string filename;
};

// TEXTUREIMAGEBLOCK
// CHILD CHUNKS: YES
struct TEXTUREIMAGEBLOCK : public TREENODE {
 string name;
 unsigned int size;
};

// TEXTUREIMAGEBLOCKDATA
// CHILD CHUNKS: NO
struct TEXTUREIMAGEBLOCKDATA : public TREENODE {
 boost::shared_array<unsigned char> data;
};

// TRANSFORM
// CHILD CHUNKS: NO
struct TRANSFORM : public TREENODE {
 float matrix[16];
};

// TYPEINFO
// CHILD CHUNKS: NO
struct TYPEINFO : public TREENODE {
 string typeName;
 unsigned int typeCount;
};

// USERATTRIBUTE
// CHILD CHUNKS: NO
struct USERATTRIBUTE : public TREENODE {
 string type;
 string semantic;
 string svalue;
};

// USERATTRIBUTELIST
// CHILD CHUNKS: YES
struct USERATTRIBUTELIST : public TREENODE {
 unsigned int count;
 string id;
};

// USERDATA
// CHILD CHUNKS: NO
struct USERDATA : public TREENODE {
 string object;
};

#endif
