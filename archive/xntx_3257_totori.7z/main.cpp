#include "stdafx.h"
#include "totori.h"

#define COUT dbgfile

struct GAME_PROPERTY {
 string section;
 string name;
};

struct BUFFERDATA {
 unsigned int elementCount;
 string renderType;
 string dataType;
 unsigned int offset;
 unsigned int stride;
 boost::shared_array<unsigned char> data;
};

struct RENDERDATA {
 unsigned int streamCount;                  // RENDERDATASOURCE:streamCount
 string primitive;                          // RENDERINDEXSOURCE:primitive (if any)
 string format;                             // RENDERINDEXSOURCE:format (if any)
 unsigned int count;                        // RENDERINDEXSOURCE:count (if any)
 string id;                                 // RENDERINDEXSOURCE:id (if any)
 boost::shared_array<unsigned char> buffer; // INDEXSOURCEDATA:data (if any)
 boost::shared_array<string> blocks;        // RENDERSTREAM[streamCount]:dataBlock (reference to Vertex, Normal, ST buffers)
};

struct VERTEX {
 float x;
 float y;
 float z;
 float u;
 float v;
 float nx;
 float ny;
 float nz;
};

struct VERTEXBUFFER {
 boost::shared_array<VERTEX> data;
 unsigned int size;
};

class Exporter {
 private :
  ifstream ifile;
  string filename_param1;
  string filename_param2;
  string filename_param3;
  string filename_param4;
 private :
  ofstream dbgfile;
  ofstream objfile;
  ofstream mtlfile;
  ofstream melfile;
 // scanning
 private :
  deque<unsigned int> offsets;
 // parameters
 private :
  typedef map<unsigned int, string>::iterator parameter_iterator;
  map<unsigned int, string> parameters;
 // properties
 private :
  map<unsigned int, GAME_PROPERTY> properties;
  map<unsigned int, unsigned int> parent_list;
 // tree
 private :
  typedef map<unsigned int, boost::shared_ptr<TREENODE>>::iterator tree_iterator;
  map<unsigned int, boost::shared_ptr<TREENODE>> tree;
  unsigned int root;
 private :
  typedef map<string, BUFFERDATA> buffer_map_type;
  typedef map<string, BUFFERDATA>::value_type buffer_map_value_type;
  typedef map<string, BUFFERDATA>::iterator buffer_map_iterator;
  map<string, BUFFERDATA> buffer_map; // store buffers by name
 private :
  typedef map<string, RENDERDATA> render_map_type;
  typedef map<string, RENDERDATA>::value_type render_map_value_type;
  typedef map<string, RENDERDATA>::iterator render_map_iterator;
  map<string, RENDERDATA> render_map; // store buffers by name
 private :
  bool scanChildren(boost::shared_ptr<TREENODE> node, unsigned int parent, unsigned int limit, bool debug);
  bool readProperties(const char* section);
  bool readString(string& str);
  bool readNumber(unsigned int& value);
  bool readFloat(float& value);
  bool readFloat3(float* ptr);
  bool readFloat4(float* ptr);
  bool traverseTREE(unsigned int node, unsigned int level);
  bool traverseDATABLOCK(tree_iterator iter);
  bool traverseRENDERDATASOURCE(tree_iterator iter);
  bool saveModel(void);
 private :
  bool processParameter(void);
  bool processPSSG(void);
  bool processANIMATION(unsigned int chunktype, unsigned int position);
  bool processANIMATIONCHANNEL(unsigned int chunktype, unsigned int position);
  bool processANIMATIONCHANNELDATABLOCK(unsigned int chunktype, unsigned int position);
  bool processANIMATIONREF(unsigned int chunktype, unsigned int position);
  bool processANIMATIONSET(unsigned int chunktype, unsigned int position);
  bool processBOUNDINGBOX(unsigned int chunktype, unsigned int position);
  bool processCAMERANODE(unsigned int chunktype, unsigned int position);
  bool processCGSTREAM(unsigned int chunktype, unsigned int position);
  bool processCHANNELREF(unsigned int chunktype, unsigned int position);
  bool processCONSTANTCHANNEL(unsigned int chunktype, unsigned int position);
  bool processDATABLOCK(unsigned int chunktype, unsigned int position);
  bool processDATABLOCKSTREAM(unsigned int chunktype, unsigned int position);
  bool processDATABLOCKDATA(unsigned int chunktype, unsigned int position);
  bool processINDEXSOURCEDATA(unsigned int chunktype, unsigned int position);
  bool processINVERSEBINDMATRIX(unsigned int chunktype, unsigned int position);
  bool processJOINTNODE(unsigned int chunktype, unsigned int position);
  bool processKEYS(unsigned int chunktype, unsigned int position);
  bool processLIBRARY(unsigned int chunktype, unsigned int position);
  bool processLIGHTNODE(unsigned int chunktype, unsigned int position); // meruru
  bool processMODIFIERNETWORK(unsigned int chunktype, unsigned int position);
  bool processMODIFIERNETWORKCONNECTION(unsigned int chunktype, unsigned int position);
  bool processMODIFIERNETWORKENTRY(unsigned int chunktype, unsigned int position);
  bool processMODIFIERNETWORKINSTANCE(unsigned int chunktype, unsigned int position);
  bool processMODIFIERNETWORKINSTANCECOMPILE(unsigned int chunktype, unsigned int position);
  bool processMODIFIERNETWORKINSTANCEDYNAMICSTREAM(unsigned int chunktype, unsigned int position);
  bool processMODIFIERNETWORKINSTANCEDYNAMICSTREAMTYPE(unsigned int chunktype, unsigned int position);
  bool processMODIFIERNETWORKINSTANCEMODIFIERINPUT(unsigned int chunktype, unsigned int position);
  bool processMODIFIERNETWORKINSTANCEUNIQUEINPUT(unsigned int chunktype, unsigned int position);
  bool processMODIFIERNETWORKINSTANCEUNIQUEMODIFIERINPUT(unsigned int chunktype, unsigned int position);
  bool processMORPHMODIFIERWEIGHTS(unsigned int chunktype, unsigned int position);
  bool processNODE(unsigned int chunktype, unsigned int position);
  bool processPSSGDATABASE(unsigned int chunktype, unsigned int position);
  bool processRENDERDATASOURCE(unsigned int chunktype, unsigned int position);
  bool processRENDERINDEXSOURCE(unsigned int chunktype, unsigned int position);
  bool processRENDERINSTANCESOURCE(unsigned int chunktype, unsigned int position);
  bool processRENDERINSTANCESTREAM(unsigned int chunktype, unsigned int position);
  bool processRENDERNODE(unsigned int chunktype, unsigned int position);
  bool processRENDERSTREAM(unsigned int chunktype, unsigned int position);
  bool processRENDERSTREAMINSTANCE(unsigned int chunktype, unsigned int position);
  bool processRISTREAM(unsigned int chunktype, unsigned int position);
  bool processROOTNODE(unsigned int chunktype, unsigned int position);
  bool processSEGMENTSET(unsigned int chunktype, unsigned int position);
  bool processSHADERGROUP(unsigned int chunktype, unsigned int position);
  bool processSHADERGROUPPASS(unsigned int chunktype, unsigned int position);
  bool processSHADERINPUT(unsigned int chunktype, unsigned int position);
  bool processSHADERINPUTDEFINITION(unsigned int chunktype, unsigned int position);
  bool processSHADERINSTANCE(unsigned int chunktype, unsigned int position);
  bool processSHADERPROGRAM(unsigned int chunktype, unsigned int position);
  bool processSHADERPROGRAMCODE(unsigned int chunktype, unsigned int position);
  bool processSHADERPROGRAMCODEBLOCK(unsigned int chunktype, unsigned int position);
  bool processSHADERSTREAMDEFINITION(unsigned int chunktype, unsigned int position);
  bool processSKELETON(unsigned int chunktype, unsigned int position);
  bool processSKINJOINT(unsigned int chunktype, unsigned int position);
  bool processSKINNODE(unsigned int chunktype, unsigned int position);
  bool processTEXTURE(unsigned int chunktype, unsigned int position);
  bool processTEXTUREIMAGEBLOCK(unsigned int chunktype, unsigned int position);
  bool processTEXTUREIMAGEBLOCKDATA(unsigned int chunktype, unsigned int position);
  bool processTRANSFORM(unsigned int chunktype, unsigned int position);
  bool processTYPEINFO(unsigned int chunktype, unsigned int position);
  bool processUSERATTRIBUTE(unsigned int chunktype, unsigned int position);
  bool processUSERATTRIBUTELIST(unsigned int chunktype, unsigned int position);
  bool processUSERDATA(unsigned int chunktype, unsigned int position);
  bool processWEIGHTS(unsigned int chunktype, unsigned int position);
 public :
  void clear(void);
  bool process(const char* filename);
 public :
  Exporter();
 ~Exporter();
 private :
  Exporter(const Exporter&);
  void operator =(const Exporter&);
};

bool extractPSSG(void)
{
 deque<string> namelist;
 if(!get_filename_list(namelist, ".PSSG")) return false;
 for(size_t i = 0; i < namelist.size(); i++) {
     Exporter e;
     if(!e.process(namelist[i].c_str())) return false;
    }
 return true;
}

bool extractPSSG(const char* rootname)
{
 deque<string> namelist;
 if(!get_filename_list(namelist, ".PSSG", rootname)) return false;
 for(size_t i = 0; i < namelist.size(); i++) {
     Exporter e;
     if(!e.process(namelist[i].c_str())) return false;
    }
 return true;
}

int main()
{
 cout << "Building list of filenames..." << endl;
 extractPSSG();

 //cout << "Building list of filenames..." << endl;
 //extractPSSG("G:\\dev\\projects\\xentax\\Release\\totori\\btlfield\\*.*"); // 100%
 //extractPSSG("G:\\dev\\projects\\xentax\\Release\\totori\\cg\\*.*"); // 100%
 //extractPSSG("G:\\dev\\projects\\xentax\\Release\\totori\\chara\\*.*"); // 100%
 //extractPSSG("G:\\dev\\projects\\xentax\\Release\\totori\\fieldmap\\*.*"); // 100%
 //extractPSSG("G:\\dev\\projects\\xentax\\Release\\totori\\ipu\\*.*"); // no PSSG files
 //extractPSSG("G:\\dev\\projects\\xentax\\Release\\totori\\item_obj\\*.*"); //  100%
 //extractPSSG("G:\\dev\\projects\\xentax\\Release\\totori\\obj\\*.*"); // 100%
 //extractPSSG("G:\\dev\\projects\\xentax\\Release\\totori\\pssg\\*.*"); // 100%
 //extractPSSG("G:\\dev\\projects\\xentax\\Release\\totori\\sound\\*.*"); // no PSSG files
 //extractPSSG("G:\\dev\\projects\\xentax\\Release\\totori\\winxls\\*.*"); // no PSSG files
 //extractPSSG("G:\\dev\\projects\\xentax\\Release\\totori\\worldmap\\*.*"); // 100%

 //Exporter e;
 //e.process("PC00_MODEL.pssg");

 return -1;
}

Exporter::Exporter()
{
 root = 0;
}

Exporter::~Exporter()
{
}

void Exporter::clear(void)
{
 buffer_map.clear();

 // close output files
 dbgfile.close();
 objfile.close();
 mtlfile.close();
 melfile.close();

 // close input files
 ifile.close();

 // clear data
 properties.clear();

 // clear tree
 tree.clear();
 root = 0;
}

bool Exporter::process(const char* filename)
{
 cout << "Processing " << filename << endl;
 clear();
 ifile.open(filename, ios::binary);
 if(!ifile.is_open()) return error("Could not open file.");

 // extract filename parameters 
 char param1[MAX_PATH];
 char param2[MAX_PATH];
 char param3[MAX_PATH];
 char param4[MAX_PATH];
 _splitpath(filename, param1, param2, param3, param4);
 filename_param1 = param1;
 filename_param2 = param2;
 filename_param3 = param3;
 filename_param4 = param4;

 // 
 string dbgfilename(filename_param1);
 dbgfilename += param2;
 dbgfilename += param3;
 dbgfilename += ".txt";
 dbgfile.open(dbgfilename);
 if(!dbgfile.is_open()) return error("Could not create debug file.");

 // process first chunk
 typedef map<unsigned int, string>::value_type value_type;
 parameters.insert(value_type(0, "PSSG"));
 return processPSSG();
}

bool Exporter::scanChildren(boost::shared_ptr<TREENODE> node, unsigned int parent, unsigned int limit, bool debug)
{
 // validate
 if(!node.get()) return error("Invalid tree node.");

 // add child chunks to stack
 unsigned int bytes_read = 0;
 while(bytes_read < limit)
      {
       // save offset
       unsigned int offset = (unsigned int)ifile.tellg();
       offsets.push_back(offset);
       node->children.push_back(offset);

       // save child/parent
       typedef map<unsigned int, unsigned int>::value_type value_type;
       parent_list.insert(value_type(offset, parent));

       // read chunk data
       unsigned int chunktype = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
       unsigned int chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += 4;
       bytes_read += chunksize;

       // debug information
       typedef map<unsigned int, string>::iterator iterator;
       iterator iter = parameters.find(chunktype);
       if(iter == parameters.end()) return error("Typename not found during scan for child chunks.");
       if(debug) COUT << "(offset, name, parent) = " << "(" << offset << "," << iter->second << "," << parent << ")" << endl;

       // skip data
       ifile.seekg(chunksize, ios::cur);
      }

 return true;
}

bool Exporter::readProperties(const char* section)
{
 bool debug = true;

 // create section
 GAME_PROPERTY prop;
 prop.section = section;

 // get number of properties
 unsigned int items = BE_read_uint32(ifile);
 if(items > 9999) return error("Read an unexpected number of integer parameters.");

 // read properties
 for(size_t i = 0; i < items; i++)
    {
     unsigned int index = BE_read_uint32(ifile);
     if(ifile.fail()) return error("Read failed.");

     unsigned int namesize = BE_read_uint32(ifile);
     if(ifile.fail()) return error("Read failed.");

     boost::shared_array<char> name(new char[namesize + 1]);
     ifile.read(name.get(), namesize);
     if(ifile.fail()) return error("Read failed.");
     name[namesize] = '\0';
     prop.name = name.get();

     typedef map<unsigned int, GAME_PROPERTY>::value_type value_type;
     properties.insert(value_type(index, prop));
     if(debug) COUT << " " << name.get() << ":" << index << endl;
    }

 return true;
}

bool Exporter::readString(string& str)
{
 // extract length
 unsigned int namesize = BE_read_uint32(ifile);
 if(ifile.fail()) return error("Read failed.");

 // extract string      
 boost::shared_array<char> name(new char[namesize + 1]);
 ifile.read(name.get(), namesize);
 if(ifile.fail()) return error("Read failed.");
 name[namesize] = '\0';
 str = string(name.get());

 return true;
}

bool Exporter::readNumber(unsigned int& value)
{
 unsigned int temp = BE_read_uint32(ifile);
 if(ifile.fail()) return error("Read failed.");
 value = temp;
 return true;
}

bool Exporter::readFloat(float& value)
{
 float temp = BE_read_float(ifile);
 if(ifile.fail()) return error("Read failed.");
 value = temp;
 return true;
}

bool Exporter::readFloat3(float* ptr)
{
 float x = BE_read_float(ifile); if(ifile.fail()) return error("Read failed.");
 float y = BE_read_float(ifile); if(ifile.fail()) return error("Read failed.");
 float z = BE_read_float(ifile); if(ifile.fail()) return error("Read failed.");
 ptr[0] = x;
 ptr[1] = y;
 ptr[2] = z;
 return true;
}

bool Exporter::readFloat4(float* ptr)
{
 float x = BE_read_float(ifile); if(ifile.fail()) return error("Read failed.");
 float y = BE_read_float(ifile); if(ifile.fail()) return error("Read failed.");
 float z = BE_read_float(ifile); if(ifile.fail()) return error("Read failed.");
 float w = BE_read_float(ifile); if(ifile.fail()) return error("Read failed.");
 ptr[0] = x;
 ptr[1] = y;
 ptr[2] = z;
 ptr[3] = w;
 return true;
}

bool Exporter::traverseTREE(unsigned int node, unsigned int level)
{
 // traverse tree
 tree_iterator iter = tree.find(node);
 if(iter == tree.end()) return true;

 // find section name
 parameter_iterator pi = parameters.find(iter->second->chunktype);
 if(pi == parameters.end()) {
    stringstream ss;
    ss << "Failed to find parameter for chunktype " << iter->second->chunktype << "." << ends;
    return error(ss.str().c_str());
   }

 // print string
 bool debug = true;
 if(debug) {
    for(size_t i = 0; i < level; i++) COUT << " ";
    COUT << pi->second.c_str() << endl;
   }

 // process DATABLOCK
 if(pi->second == "DATABLOCK") traverseDATABLOCK(iter);
 else if(pi->second == "RENDERDATASOURCE") traverseRENDERDATASOURCE(iter);

 // traverse children
 deque<unsigned int>& children = iter->second->children;
 for(size_t i = 0; i < children.size(); i++) if(!traverseTREE(children[i], level + 1)) return false;
 return true;
}

bool Exporter::traverseDATABLOCK(tree_iterator iter)
{
 // convert TREENODE to DATABLOCK
 DATABLOCK* info = static_cast<DATABLOCK*>(iter->second.get());
 if(!info) return error("Failed to case from TREENODE to DATABLOCK.");

 // check number of streams
 if(info->streamCount != 1) return error("Expecting only one DATABLOCK stream.");

 // validate children
 deque<unsigned int>& children = info->children;
 if(children.size() != 2) return error("Expecting DATABLOCKSTREAM and DATABLOCKDATA.");

 // child #1
 tree_iterator dbs_iter = tree.find(children[0]);
 if(dbs_iter == tree.end()) return error("Could not find DATABLOCKSTREAM.");
 parameter_iterator p1_iter = parameters.find(dbs_iter->second->chunktype);
 if(p1_iter == parameters.end()) return error("Expecting DATABLOCKSTREAM parameter.");
 if(p1_iter->second != "DATABLOCKSTREAM") return error("Expecting DATABLOCKSTREAM.");
 DATABLOCKSTREAM* dbs = static_cast<DATABLOCKSTREAM*>(dbs_iter->second.get());
 if(!dbs) return error("Failed to case from TREENODE to DATABLOCKSTREAM.");

 // child #2
 tree_iterator dbd_iter = tree.find(children[1]);
 if(dbd_iter == tree.end()) return error("Could not find DATABLOCKDATA");
 parameter_iterator p2_iter = parameters.find(dbd_iter->second->chunktype);
 if(p2_iter == parameters.end()) return error("Expecting DATABLOCKDATA parameter.");
 if(p2_iter->second != "DATABLOCKDATA") return error("Expecting DATABLOCKDATA.");
 DATABLOCKDATA* dbd = static_cast<DATABLOCKDATA*>(dbd_iter->second.get());
 if(!dbd) return error("Failed to case from TREENODE to DATABLOCKDATA.");

 // valid data types
 // "Vertex", "SkinnableVertex"
 // "Normal", "SkinnableNormal"
 // "ST"
 // "SkinWeights"
 // "SkinIndices"
 // "Color"
 // "Tangent", "SkinnableTangent"
 // "Binormal"

 // store data
 BUFFERDATA vd;
 vd.elementCount = info->elementCount;
 vd.renderType = dbs->renderType;
 vd.dataType = dbs->dataType;
 vd.offset = dbs->offset;
 vd.stride = dbs->stride;
 vd.data = dbd->data;

 // insert buffer data
 buffer_map.insert(buffer_map_value_type(info->id, vd));
 return true;
}

bool Exporter::traverseRENDERDATASOURCE(tree_iterator iter)
{
 // convert TREENODE to RENDERDATASOURCE
 RENDERDATASOURCE* info = static_cast<RENDERDATASOURCE*>(iter->second.get());
 if(!info) return error("Failed to case from TREENODE to RENDERDATASOURCE.");
 if(!info->streamCount) return true;
 if(!info->children.size()) return true;

 // prepare RENDERDATA
 RENDERDATA rd;
 rd.streamCount = info->streamCount;
 rd.blocks.reset(new string[info->streamCount]);

 // no index buffer
 if(info->primitive == "triangles")
   {
    // prepare RENDERDATA
    rd.primitive = info->primitive;
    rd.format = "";        // not used
    rd.count = 0;          // not used
    rd.id = "";            // not used
    rd.buffer.reset(NULL); // not used

    // read render streams
    for(size_t i = 0; i < info->streamCount; i++)
       {
        // find RENDERSTREAM node
        tree_iterator node = tree.find(info->children[i]);
        if(node == tree.end()) return error("Could not find node.");

        // find RENDERSTREAM parameter
        parameter_iterator param = parameters.find(node->second->chunktype);
        if(param == parameters.end()) return error("Could not find parameter.");
        if(param->second != "RENDERSTREAM") {
           stringstream ss;
           ss << "Expecting RENDERSTREAM node but found " << param->second << " instead." << ends;
           return error(ss.str().c_str());
          }

        // safe to cast
        RENDERSTREAM* rs = static_cast<RENDERSTREAM*>(node->second.get());
        if(!rs) return error("Failed to cast from TREENODE to RENDERSTREAM.");

        // save blocks
        rd.blocks[i] = string(rs->dataBlock.c_str() + 1); // remove # from front
       }
   }
 // index buffer
 else if(info->primitive.length() == 0)
   {
    // find first child node
    tree_iterator node = tree.find(info->children[0]);
    if(node == tree.end()) return error("Could not find node.");

    // find first child parameter
    parameter_iterator param = parameters.find(node->second->chunktype);
    if(param == parameters.end()) return error("Could not find parameter.");

    // first child is RENDERINDEXSOURCE
    if(param->second == "RENDERINDEXSOURCE")
      {
       // safe to cast
       RENDERINDEXSOURCE* ris = static_cast<RENDERINDEXSOURCE*>(node->second.get());
       if(!ris) return error("Failed to cast from TREENODE to RENDERINDEXSOURCE.");
       if(!ris->children.size()) return error("Invalid RENDERINDEXSOURCE.");
   
       // find INDEXSOURCEDATA node
       node = tree.find(ris->children[0]);
       if(node == tree.end()) return error("Could not find node.");
   
       // find INDEXSOURCEDATA parameter
       param = parameters.find(node->second->chunktype);
       if(param == parameters.end()) return error("Could not find parameter.");
       if(param->second != "INDEXSOURCEDATA") {
          stringstream ss;
          ss << "Expecting INDEXSOURCEDATA node but found " << param->second << " instead." << ends;
          return error(ss.str().c_str());
         }
   
       // safe to cast
       INDEXSOURCEDATA* isd = static_cast<INDEXSOURCEDATA*>(node->second.get());
       if(!isd) return error("Failed to cast from TREENODE to INDEXSOURCEDATA.");
   
       // prepare RENDERDATA
       rd.primitive = ris->primitive;
       rd.format = ris->format;
       rd.count = ris->count;
       rd.id = ris->id;
       rd.buffer = isd->data;
   
       // read render streams
       for(size_t i = 0; i < info->streamCount; i++)
          {
           // find RENDERSTREAM node
           tree_iterator node = tree.find(info->children[i + 1]);
           if(node == tree.end()) return error("Could not find node.");
   
           // find RENDERSTREAM parameter
           parameter_iterator param = parameters.find(node->second->chunktype);
           if(param == parameters.end()) return error("Could not find parameter.");
           if(param->second != "RENDERSTREAM") {
              stringstream ss;
              ss << "Expecting RENDERSTREAM node but found " << param->second << " instead." << ends;
              return error(ss.str().c_str());
             }
   
           // safe to cast
           RENDERSTREAM* rs = static_cast<RENDERSTREAM*>(node->second.get());
           if(!rs) return error("Failed to cast from TREENODE to RENDERSTREAM.");
   
           // save blocks
           rd.blocks[i] = string(rs->dataBlock.c_str() + 1); // remove # from front
          }
      }
    // first child is RENDERSTREAM
    else if(param->second == "RENDERSTREAM")
      {
       // prepare RENDERDATA
       rd.primitive = "";     // not used
       rd.format = "";        // not used
       rd.count = 0;          // not used
       rd.id = "";            // not used
       rd.buffer.reset(NULL); // not used
   
       // read render streams
       for(size_t i = 0; i < info->streamCount; i++)
          {
           // find RENDERSTREAM node
           tree_iterator node = tree.find(info->children[i]);
           if(node == tree.end()) return error("Could not find node.");
   
           // find RENDERSTREAM parameter
           parameter_iterator param = parameters.find(node->second->chunktype);
           if(param == parameters.end()) return error("Could not find parameter.");
           if(param->second != "RENDERSTREAM") {
              stringstream ss;
              ss << "Expecting RENDERSTREAM node but found " << param->second << " instead." << ends;
              return error(ss.str().c_str());
             }
   
           // safe to cast
           RENDERSTREAM* rs = static_cast<RENDERSTREAM*>(node->second.get());
           if(!rs) return error("Failed to cast from TREENODE to RENDERSTREAM.");
   
           // save blocks
           rd.blocks[i] = string(rs->dataBlock.c_str() + 1); // remove # from front
          }
      }
    else {
       stringstream ss;
       ss << "Expecting RENDERINDEXSOURCE or RENDERSTREAM but found " << param->second << " instead." << ends;
       return error(ss.str().c_str());
      }
   }
 else {
    stringstream ss;
    ss << "Unknown primitive type " << info->primitive << "." << endl;
    return error(ss.str().c_str());
   }

 // insert render data
 render_map.insert(render_map_value_type(info->id, rd));
 return true;
}

bool Exporter::saveModel(void)
{
 // build material filename
 string lsfilename(filename_param1);
 lsfilename += filename_param2;
 lsfilename += filename_param3;
 lsfilename += ".ls";

 ofstream ofile(lsfilename.c_str());
 if(!ofile) return error("Failed to create LS file.");
 ofile << "main" << endl;
 ofile << "{" << endl;

 // for each render map
 size_t surface = 0;
 for(render_map_iterator iter = render_map.begin(); iter != render_map.end(); iter++)
    {
     RENDERDATA rd = iter->second;

     // store vertex maps
     ofile << " editbegin();" << endl;
     ofile << " uvmap = VMap(\"texture\", \"" << iter->first << "\", 2);" << endl;
     ofile << " vnmap = VMap(\"texture\", \"" << iter->first << "\", 2);" << endl;
     ofile << " editend();" << endl;

     // set layer and surface
     ofile << " lyrsetfg(" << (++surface) << ");" << endl;
     ofile << " setsurface(\"" << iter->first  << "\");" << endl;

     // build material filename
     string mfilename(filename_param1);
     mfilename += filename_param2;
     mfilename += iter->first;
     mfilename += ".mtl";

     // create mtl file
     ofstream mtlfile(mfilename.c_str());
     if(!mtlfile) return error("Failed to create OBJ file.");
     mtlfile << "newmtl " << iter->first << endl;
     mtlfile << "Ka 0 0 0" << endl;
     mtlfile << "Kd 0.784314 0.784314 0.784314" << endl;
     mtlfile << "Ks 0 0 0" << endl;
     mtlfile << "Ni 1" << endl;
     mtlfile << "Ns 400" << endl;
     mtlfile << "Tf 1 1 1" << endl;
     mtlfile << "d 1" << endl;
     // TODO: Auto texture

     // build filename
     string wavename(filename_param1);
     wavename += filename_param2;
     wavename += iter->first;
     wavename += ".obj";

     // create obj file
     ofstream objfile(wavename.c_str());
     if(!objfile) return error("Failed to create OBJ file.");

     // write header
     objfile << "o " << iter->first << ".obj" << endl;
     objfile << "mtllib " << iter->first << ".mtl" << endl;
     objfile << "g " << iter->first << endl;
     objfile << "use " << iter->first << endl;
     objfile << endl;

     // keep track
     size_t n_vertex = 0;
     size_t n_normal = 0;
     size_t n_uv = 0;

     // for each stream
     for(size_t i = 0; i < rd.streamCount; i++)
        {
         // find buffer data
         string blockname = rd.blocks[i];
         buffer_map_iterator iter = buffer_map.find(blockname);
         if(iter == buffer_map.end()) return error("Blockname lookup failed.");
         BUFFERDATA bmi = iter->second;

         // position data pointer
         unsigned char* ptr = bmi.data.get();
         ptr += bmi.offset;

         // data block is vertex
         if(bmi.renderType == "Vertex" || bmi.renderType == "SkinnableVertex")
           {
            ofile << " editbegin();" << endl;
            objfile << "# " << blockname << endl;
            n_vertex = bmi.elementCount;
            for(size_t j = 0; j < bmi.elementCount; j++) {
                if(bmi.dataType == "float3") {
                   float* v = reinterpret_cast<float*>(ptr);
                   float a = v[0];
                   float b = v[1];
                   float c = v[2];
                   reverse_byte_order(&a);
                   reverse_byte_order(&b);
                   reverse_byte_order(&c);
                   objfile << "v " << a << " " << b << " " << c << endl;
                   ofile << " pointlist[" << j + 1 << "]" << " = " << "addpoint(" << a << "," << b << "," << c << ");" << endl;
                  }
                else {
                   stringstream ss;
                   ss << "Unknown Vertex/SkinnableVertex data type " << bmi.dataType << "." << endl;
                   return error(ss.str().c_str());
                  }
                ptr += bmi.stride;
               }
            objfile << endl;
            ofile << " editend();" << endl;
           }
         // normal data
         else if(bmi.renderType == "Normal" || bmi.renderType == "SkinnableNormal")
           {
            objfile << "# " << blockname << endl;
            n_normal = bmi.elementCount;
            for(size_t j = 0; j < bmi.elementCount; j++) {
                if(bmi.dataType == "float3") {
                   float* v = reinterpret_cast<float*>(ptr);
                   float a = v[0];
                   float b = v[1];
                   float c = v[2];
                   reverse_byte_order(&a);
                   reverse_byte_order(&b);
                   reverse_byte_order(&c);
                   objfile << "vn " << a << " " << b << " " << c << endl;
                  }
                else {
                   stringstream ss;
                   ss << "Unknown Normal/SkinnableNormal data type " << bmi.dataType << "." << endl;
                   return error(ss.str().c_str());
                  }
                ptr += bmi.stride;
               }
            objfile << endl;
           }
         // texture map data
         else if(bmi.renderType == "ST")
           {
            ofile << " editbegin();" << endl;
            objfile << "# " << blockname << endl;
            n_uv = bmi.elementCount;
            for(size_t j = 0; j < bmi.elementCount; j++) {
                if(bmi.dataType == "float2") {
                   float* v = reinterpret_cast<float*>(ptr);
                   float a = v[0];
                   float b = v[1];
                   reverse_byte_order(&a);
                   reverse_byte_order(&b);
                   objfile << "vt " << a << " " << (1.0f - b) << endl;
                   ofile << " uvmap.setValue(pointlist[" << (j + 1) << "]," << "@" << a << "," << (1.0f - b) << "@);" << endl;
                  }
                else if(bmi.dataType == "float3") {
                   float* v = reinterpret_cast<float*>(ptr);
                   float a = v[0];
                   float b = v[1];
                   reverse_byte_order(&a);
                   reverse_byte_order(&b);
                   objfile << "vt " << a << " " << (1.0f - b) << endl;
                   ofile << " uvmap.setValue(pointlist[" << (j + 1) << "]," << "@" << a << "," << (1.0f - b) << "@);" << endl;
                  }
                else {
                   stringstream ss;
                   ss << "Unknown ST data type " << bmi.dataType << "." << endl;
                   return error(ss.str().c_str());
                  }
                ptr += bmi.stride;
               }
            objfile << endl;
            ofile << " editend();" << endl;
           }
         // some other data
         else
           {
           }
        }

     // using index buffer
     if(rd.count > 0)
       {
        if(rd.primitive.length() == 0) rd.primitive = "triangles"; // force?
        if(rd.primitive == "triangles")
          {
           ofile << " editbegin();" << endl;
           if(rd.count % 3) return error("Number of triangle vertices must be divisible by three.");
           if(rd.format == "uchar")
             {
              unsigned char* ptr = rd.buffer.get();
              size_t index = 0;
              for(size_t j = 0; j < rd.count/3; j++) {
                  unsigned char temp1 = ptr[index++];
                  unsigned char temp2 = ptr[index++];
                  unsigned char temp3 = ptr[index++];
                  unsigned short a = 1 + (unsigned short)temp1;
                  unsigned short b = 1 + (unsigned short)temp2;
                  unsigned short c = 1 + (unsigned short)temp3;
                  objfile << "f " << a << "/" << a << "/" << a << " "
                                  << b << "/" << b << "/" << b << " "
                                  << c << "/" << c << "/" << c << endl;
                  ofile << " addtriangle(pointlist[" << a << "], pointlist[" << b << "], pointlist[" << c << "]);" << endl;
                 }
             }
           else if(rd.format == "ushort")
             {
              unsigned short* ptr = reinterpret_cast<unsigned short*>(rd.buffer.get());
              size_t index = 0;
              for(size_t j = 0; j < rd.count/3; j++) {
                  unsigned short a = ptr[index++];
                  unsigned short b = ptr[index++];
                  unsigned short c = ptr[index++];
                  reverse_byte_order(&a);
                  reverse_byte_order(&b);
                  reverse_byte_order(&c);
                  a = a + 1;
                  b = b + 1;
                  c = c + 1;
                  objfile << "f " << a << "/" << a << "/" << a << " "
                                  << b << "/" << b << "/" << b << " "
                                  << c << "/" << c << "/" << c << endl;
                  ofile << " addtriangle(pointlist[" << a << "], pointlist[" << b << "], pointlist[" << c << "]);" << endl;
                 }
             }
           else if(rd.format == "uint")
             {
              unsigned int* ptr = reinterpret_cast<unsigned int*>(rd.buffer.get());
              size_t index = 0;
              for(size_t j = 0; j < rd.count/3; j++) {
                  unsigned int a = ptr[index++];
                  unsigned int b = ptr[index++];
                  unsigned int c = ptr[index++];
                  reverse_byte_order(&a);
                  reverse_byte_order(&b);
                  reverse_byte_order(&c);
                  a = a + 1;
                  b = b + 1;
                  c = c + 1;
                  objfile << "f " << a << "/" << a << "/" << a << " "
                                  << b << "/" << b << "/" << b << " "
                                  << c << "/" << c << "/" << c << endl;
                  ofile << " addtriangle(pointlist[" << a << "], pointlist[" << b << "], pointlist[" << c << "]);" << endl;
                 }
             }
           else
             {
              stringstream ss;
              ss << "Unknown format type " << rd.format << "." << endl;
              return error(ss.str().c_str());
             }
           ofile << " editend();" << endl;
          }
        else {
           stringstream ss;
           ss << "Unknown primitive " << rd.primitive << "." << endl;
           return error(ss.str().c_str());
          }
       }
     // not using index buffer
     else
       {
        // validate
        if(n_vertex % 3) return error("Number of triangle vertices must be divisible by three.");
        size_t n_triangles = n_vertex/3;

        ofile << " editbegin();" << endl;

        // connect faces
        size_t index = 1;
        for(size_t i = 0; i < n_triangles; i++) {
            ofile << " addtriangle(pointlist[" << index + 0 << "], pointlist[" << index + 1 << "], pointlist[" << index + 2 << "]);" << endl;
            objfile << "f ";
            objfile << index << "/" << index << "/" << index << " "; index++;
            objfile << index << "/" << index << "/" << index << " "; index++;
            objfile << index << "/" << index << "/" << index << " "; index++;
            objfile << endl;
           }

        ofile << " editend();" << endl;
       }
    }

 // finialize script file
 ofile << "}" << endl;
 return true;
}

bool Exporter::processPSSG(void)
{
 bool debug = true;

 unsigned int chunkname = BE_read_uint32(ifile);
 if(ifile.fail()) return error("Read failed.");
 if(chunkname != 0x50535347) return error("Expecting PSSG chunk.");

 // filesize - 8
 unsigned int chunksize = BE_read_uint32(ifile);
 if(ifile.fail()) return error("Read failed.");
 if(chunksize == 0) return error("Invalid PSSG chunksize.");

 // number of properties + 1
 unsigned int n_properties = BE_read_uint32(ifile);
 if(n_properties > 9999) return error("Read an unexpected number of PSSG properties.");

 // number of parameters (each parameter has 0 or more properties)
 unsigned int n_parameters = BE_read_uint32(ifile);
 if(n_parameters > 9999) return error("Read an unexpected number of PSSG parameters.");

 for(unsigned int i = 0; i < n_parameters; i++)
    {
     // read parameter index
     unsigned int index = 0;
     if(!readNumber(index)) return false;
     if(index != i + 1) return error("Integer parameter index does not match.");

     // read parameter
     string parameter;
     if(!readString(parameter)) return false;

     // display parameter and index
     if(debug) COUT << parameter << ":" << index << endl;

     // add parameter to map
     typedef map<unsigned int, string>::value_type value_type;
     parameters.insert(value_type(index, parameter));

     // macros
     #define FIRST_TEST(TESTNAME) if(parameter == TESTNAME) { if(!readProperties(TESTNAME)) return false; }
     #define OTHER_TEST(TESTNAME) else if(parameter == TESTNAME) { if(!readProperties(TESTNAME)) return false; }
     #define FINAL_TEST else { stringstream ss; ss << "Unknown integer parameter type " << parameter.c_str() << "." << ends; return error(ss.str().c_str()); }

     // read properties
     FIRST_TEST("ANIMATION")
     OTHER_TEST("ANIMATIONCHANNEL")
     OTHER_TEST("ANIMATIONCHANNELDATABLOCK")
     OTHER_TEST("ANIMATIONREF")
     OTHER_TEST("ANIMATIONSET")
     OTHER_TEST("BOUNDINGBOX")
     OTHER_TEST("CAMERANODE")
     OTHER_TEST("CGSTREAM")
     OTHER_TEST("CHANNELREF")
     OTHER_TEST("CONSTANTCHANNEL")
     OTHER_TEST("DATABLOCK")
     OTHER_TEST("DATABLOCKDATA")
     OTHER_TEST("DATABLOCKSTREAM")
     OTHER_TEST("INDEXSOURCEDATA")
     OTHER_TEST("INVERSEBINDMATRIX")
     OTHER_TEST("JOINTNODE")
     OTHER_TEST("KEYS")
     OTHER_TEST("LIBRARY")
     OTHER_TEST("LIGHTNODE")
     OTHER_TEST("MODIFIERNETWORK")
     OTHER_TEST("MODIFIERNETWORKCONNECTION")
     OTHER_TEST("MODIFIERNETWORKENTRY")
     OTHER_TEST("MODIFIERNETWORKINSTANCE")
     OTHER_TEST("MODIFIERNETWORKINSTANCECOMPILE")
     OTHER_TEST("MODIFIERNETWORKINSTANCEDYNAMICSTREAM")
     OTHER_TEST("MODIFIERNETWORKINSTANCEDYNAMICSTREAMTYPE")
     OTHER_TEST("MODIFIERNETWORKINSTANCEMODIFIERINPUT")
     OTHER_TEST("MODIFIERNETWORKINSTANCEUNIQUEINPUT")
     OTHER_TEST("MODIFIERNETWORKINSTANCEUNIQUEMODIFIERINPUT")
     OTHER_TEST("MORPHMODIFIERWEIGHTS")
     OTHER_TEST("NODE")
     OTHER_TEST("PSSGDATABASE")
     OTHER_TEST("RENDERDATASOURCE")
     OTHER_TEST("RENDERINDEXSOURCE")
     OTHER_TEST("RENDERINSTANCE")
     OTHER_TEST("RENDERINSTANCESOURCE")
     OTHER_TEST("RENDERINSTANCESTREAM")
     OTHER_TEST("RENDERINTERFACEBOUND")
     OTHER_TEST("RENDERNODE")
     OTHER_TEST("RENDERSTREAM")
     OTHER_TEST("RENDERSTREAMINSTANCE")
     OTHER_TEST("RISTREAM")
     OTHER_TEST("ROOTNODE")
     OTHER_TEST("SEGMENTSET")
     OTHER_TEST("SHADERGROUP")
     OTHER_TEST("SHADERGROUPPASS")
     OTHER_TEST("SHADERINPUT")
     OTHER_TEST("SHADERINPUTDEFINITION")
     OTHER_TEST("SHADERINSTANCE")
     OTHER_TEST("SHADERPROGRAM")
     OTHER_TEST("SHADERPROGRAMCODE")
     OTHER_TEST("SHADERPROGRAMCODEBLOCK")
     OTHER_TEST("SHADERSTREAMDEFINITION")
     OTHER_TEST("SKELETON")
     OTHER_TEST("SKINJOINT")
     OTHER_TEST("SKINNODE")
     OTHER_TEST("TEXTURE")
     OTHER_TEST("TEXTUREIMAGEBLOCK")
     OTHER_TEST("TEXTUREIMAGEBLOCKDATA")
     OTHER_TEST("TRANSFORM")
     OTHER_TEST("TYPEINFO")
     OTHER_TEST("USERATTRIBUTE")
     OTHER_TEST("USERATTRIBUTELIST")
     OTHER_TEST("USERDATA")
     OTHER_TEST("WEIGHTS")
     OTHER_TEST("XXX")
     FINAL_TEST
    }

 // process offsets
 root = (unsigned int)ifile.tellg();
 offsets.push_back(root);
 while(offsets.size()) { if(!processParameter()) return false; }

 // traverse tree
 unsigned int level = 0;
 if(!traverseTREE(root, level)) return false;

 // save model 
 return saveModel();
}

bool Exporter::processParameter(void)
{
 // read chunk on top of stack
 unsigned position = offsets.front();
 ifile.seekg(position);
 offsets.pop_front();

 // read chunktype
 unsigned int chunktype = BE_read_uint32(ifile);
 if(ifile.eof()) return true;
 else if(ifile.fail()) return error("Read failed.");

 // find parameter
 typedef map<unsigned int, string>::iterator iterator;
 iterator iter = parameters.find(chunktype);
 if(iter == parameters.end()) {
    stringstream ss;
    ss << "Could not find parameter at index " << chunktype << "." << ends;
    return error(ss.str().c_str());
   }

 #define FIRST_PARAMETER_TEST(name) if(iter->second == #name) return process##name##(chunktype, position)
 #define OTHER_PARAMETER_TEST(name) else if(iter->second == #name) return process##name##(chunktype, position)

 // process parameter
 FIRST_PARAMETER_TEST(PSSGDATABASE);
 OTHER_PARAMETER_TEST(ANIMATION);
 OTHER_PARAMETER_TEST(ANIMATIONCHANNEL);
 OTHER_PARAMETER_TEST(ANIMATIONCHANNELDATABLOCK);
 OTHER_PARAMETER_TEST(ANIMATIONREF);
 OTHER_PARAMETER_TEST(ANIMATIONSET);
 OTHER_PARAMETER_TEST(BOUNDINGBOX);
 OTHER_PARAMETER_TEST(CAMERANODE);
 OTHER_PARAMETER_TEST(CGSTREAM);
 OTHER_PARAMETER_TEST(CHANNELREF);
 OTHER_PARAMETER_TEST(CONSTANTCHANNEL);
 OTHER_PARAMETER_TEST(DATABLOCK);
 OTHER_PARAMETER_TEST(DATABLOCKDATA);
 OTHER_PARAMETER_TEST(DATABLOCKSTREAM);
 OTHER_PARAMETER_TEST(INDEXSOURCEDATA);
 OTHER_PARAMETER_TEST(INVERSEBINDMATRIX);
 OTHER_PARAMETER_TEST(JOINTNODE);
 OTHER_PARAMETER_TEST(KEYS);
 OTHER_PARAMETER_TEST(LIBRARY);
 OTHER_PARAMETER_TEST(LIGHTNODE);
 OTHER_PARAMETER_TEST(MODIFIERNETWORK);
 OTHER_PARAMETER_TEST(MODIFIERNETWORKCONNECTION);
 OTHER_PARAMETER_TEST(MODIFIERNETWORKENTRY);
 OTHER_PARAMETER_TEST(MODIFIERNETWORKINSTANCE);
 OTHER_PARAMETER_TEST(MODIFIERNETWORKINSTANCECOMPILE);
 OTHER_PARAMETER_TEST(MODIFIERNETWORKINSTANCEDYNAMICSTREAM);
 OTHER_PARAMETER_TEST(MODIFIERNETWORKINSTANCEDYNAMICSTREAMTYPE);
 OTHER_PARAMETER_TEST(MODIFIERNETWORKINSTANCEMODIFIERINPUT);
 OTHER_PARAMETER_TEST(MODIFIERNETWORKINSTANCEUNIQUEINPUT);
 OTHER_PARAMETER_TEST(MODIFIERNETWORKINSTANCEUNIQUEMODIFIERINPUT);
 OTHER_PARAMETER_TEST(MORPHMODIFIERWEIGHTS);
 OTHER_PARAMETER_TEST(NODE);
 OTHER_PARAMETER_TEST(RENDERDATASOURCE);
 OTHER_PARAMETER_TEST(RENDERINDEXSOURCE);
 OTHER_PARAMETER_TEST(RENDERINSTANCESOURCE);
 OTHER_PARAMETER_TEST(RENDERINSTANCESTREAM);
 OTHER_PARAMETER_TEST(RENDERNODE);
 OTHER_PARAMETER_TEST(RENDERSTREAM);
 OTHER_PARAMETER_TEST(RENDERSTREAMINSTANCE);
 OTHER_PARAMETER_TEST(RISTREAM);
 OTHER_PARAMETER_TEST(ROOTNODE);
 OTHER_PARAMETER_TEST(SEGMENTSET);
 OTHER_PARAMETER_TEST(SHADERGROUP);
 OTHER_PARAMETER_TEST(SHADERGROUPPASS);
 OTHER_PARAMETER_TEST(SHADERINPUT);
 OTHER_PARAMETER_TEST(SHADERINPUTDEFINITION);
 OTHER_PARAMETER_TEST(SHADERINSTANCE);
 OTHER_PARAMETER_TEST(SHADERPROGRAM);
 OTHER_PARAMETER_TEST(SHADERPROGRAMCODE);
 OTHER_PARAMETER_TEST(SHADERPROGRAMCODEBLOCK);
 OTHER_PARAMETER_TEST(SHADERSTREAMDEFINITION);
 OTHER_PARAMETER_TEST(SKELETON);
 OTHER_PARAMETER_TEST(SKINJOINT);
 OTHER_PARAMETER_TEST(SKINNODE);
 OTHER_PARAMETER_TEST(TEXTURE);
 OTHER_PARAMETER_TEST(TEXTUREIMAGEBLOCK);
 OTHER_PARAMETER_TEST(TEXTUREIMAGEBLOCKDATA);
 OTHER_PARAMETER_TEST(TRANSFORM);
 OTHER_PARAMETER_TEST(TYPEINFO);
 OTHER_PARAMETER_TEST(USERATTRIBUTE);
 OTHER_PARAMETER_TEST(USERATTRIBUTELIST);
 OTHER_PARAMETER_TEST(USERDATA);
 OTHER_PARAMETER_TEST(WEIGHTS);

 // error
 stringstream ss;
 ss << "Unimplemented parameter test " << iter->second.c_str() << ends;
 return error(ss.str().c_str());
}

bool Exporter::processPSSGDATABASE(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "--------------" << endl;
 if(debug) COUT << " PSSGDATABASE " << endl;
 if(debug) COUT << "--------------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new PSSGDATABASE);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 PSSGDATABASE* info = static_cast<PSSGDATABASE*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");

 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "PSSGDATABASE" && name == "creator") {
          if(!readString(info->creator)) return false;
          if(debug) COUT << "info->creator = " << info->creator << endl;
         }
       else if(section == "PSSGDATABASE" && name == "creationMachine") {
          if(!readString(info->creationMachine)) return false;
          if(debug) COUT << "creationMachine = " << info->creationMachine << endl;
         }
       else if(section == "PSSGDATABASE" && name == "creationDate") {
          if(!readString(info->creationDate)) return false;
          if(debug) COUT << "creationDate = " << info->creationDate << endl;
         }
       else if(section == "PSSGDATABASE" && name == "scale") {
          if(!readFloat3(&info->scale[0])) return false;
          if(debug) COUT << "scale = " << "<" << info->scale[0] << "," << info->scale[1] << "," << info->scale[2] << ">" << endl;
         }
       else if(section == "PSSGDATABASE" && name == "up") {
          if(!readFloat3(&info->up[0])) return false;
          if(debug) COUT << "up = " << "<" << info->up[0] << "," << info->up[1] << "," << info->up[2] << ">" << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 // add child chunks to stack
 scanChildren(node, position, info->chunksize - bytes_read - 4, debug);
 return true;
}

bool Exporter::processANIMATION(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "-----------" << endl;
 if(debug) COUT << " ANIMATION " << endl;
 if(debug) COUT << "-----------" << endl;
 if(debug) COUT << "offset = " << position << endl;
 
 // insert node
 boost::shared_ptr<TREENODE> node(new ANIMATION);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // retrieve parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;
 
 // read chunk properties
 ANIMATION* info = static_cast<ANIMATION*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");

 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "ANIMATION" && name == "channelCount") {
          if(!readNumber(info->channelCount)) return false;
          if(debug) COUT << "channelCount = " << info->channelCount << endl;
         }
       else if(section == "ANIMATION" && name == "constantChannelCount") {
          if(!readNumber(info->constantChannelCount)) return false;
          if(debug) COUT << "constantChannelCount = " << info->constantChannelCount << endl;
         }
       else if(section == "ANIMATION" && name == "constantChannelStartTime") {
          if(!readFloat(info->constantChannelStartTime)) return false;
          if(debug) COUT << "constantChannelStartTime = " << info->constantChannelStartTime << endl;
         }
       else if(section == "ANIMATION" && name == "constantChannelEndTime") {
          if(!readFloat(info->constantChannelEndTime)) return false;
          if(debug) COUT << "constantChannelEndTime = " << info->constantChannelEndTime << endl;
         }
       else if(section == "XXX" && name == "id") {
          if(!readString(info->id)) return false;
          if(debug) COUT << "id = " << info->id << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 // add child chunks to stack
 scanChildren(node, position, info->chunksize - bytes_read - 4, debug);
 return true;
}

bool Exporter::processANIMATIONCHANNEL(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "------------------" << endl;
 if(debug) COUT << " ANIMATIONCHANNEL " << endl;
 if(debug) COUT << "------------------" << endl;
 if(debug) COUT << "offset = " << position << endl;
 
 // insert node
 boost::shared_ptr<TREENODE> node(new ANIMATIONCHANNEL);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // retrieve parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;
 
 // read chunk properties
 ANIMATIONCHANNEL* info = static_cast<ANIMATIONCHANNEL*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");
 //if(info->propbytes) return error("Property table unexpected.");

 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "ANIMATIONCHANNEL" && name == "timeBlock") {
          if(!readString(info->timeBlock)) return false;
          if(debug) COUT << "timeBlock = " << info->timeBlock << endl;
         }
       else if(section == "ANIMATIONCHANNEL" && name == "valueBlock") {
          if(!readString(info->valueBlock)) return false;
          if(debug) COUT << "valueBlock = " << info->valueBlock << endl;
         }
       else if(section == "XXX" && name == "id") {
          if(!readString(info->id)) return false;
          if(debug) COUT << "id = " << info->id << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 return true;
}

bool Exporter::processANIMATIONCHANNELDATABLOCK(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "---------------------------" << endl;
 if(debug) COUT << " ANIMATIONCHANNELDATABLOCK " << endl;
 if(debug) COUT << "---------------------------" << endl;
 if(debug) COUT << "offset = " << position << endl;
 
 // insert node
 boost::shared_ptr<TREENODE> node(new ANIMATIONCHANNELDATABLOCK);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // retrieve parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;
 
 // read chunk properties
 ANIMATIONCHANNELDATABLOCK* info = static_cast<ANIMATIONCHANNELDATABLOCK*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");

 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "ANIMATIONCHANNELDATABLOCK" && name == "keyCount") {
          if(!readNumber(info->keyCount)) return false;
          if(debug) COUT << "keyCount = " << info->keyCount << endl;
         }
       else if(section == "ANIMATIONCHANNELDATABLOCK" && name == "keyType") {
          if(!readString(info->keyType)) return false;
          if(debug) COUT << "keyType = " << info->keyType << endl;
         }
       else if(section == "XXX" && name == "id") {
         if(!readString(info->id)) return false;
         if(debug) COUT << "id = " << info->id << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 // add child chunks to stack
 scanChildren(node, position, info->chunksize - bytes_read - 4, debug);
 return true;
}

bool Exporter::processANIMATIONREF(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "--------------" << endl;
 if(debug) COUT << " ANIMATIONREF " << endl;
 if(debug) COUT << "--------------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new ANIMATIONREF);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // retrieve parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;
 
 // read chunk properties
 ANIMATIONREF* info = static_cast<ANIMATIONREF*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");

 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "ANIMATIONREF" && name == "animation") {
          if(!readString(info->animation)) return false;
          if(debug) COUT << "animation = " << info->animation << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 return true;
}

bool Exporter::processANIMATIONSET(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "--------------" << endl;
 if(debug) COUT << " ANIMATIONSET " << endl;
 if(debug) COUT << "--------------" << endl;
 if(debug) COUT << "offset = " << position << endl;
 
 // insert node
 boost::shared_ptr<TREENODE> node(new ANIMATIONSET);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 ANIMATIONSET* info = static_cast<ANIMATIONSET*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");

 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "ANIMATIONSET" && name == "animationCount") {
          if(!readNumber(info->animationCount)) return false;
          if(debug) COUT << "animationCount = " << info->animationCount << endl;
         }
       else if(section == "XXX" && name == "id") {
          if(!readString(info->id)) return false;
          if(debug) COUT << "id = " << info->id << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 // add child chunks to stack
 scanChildren(node, position, info->chunksize - bytes_read - 4, debug);
 return true;
}

bool Exporter::processBOUNDINGBOX(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "-------------" << endl;
 if(debug) COUT << " BOUNDINGBOX " << endl;
 if(debug) COUT << "-------------" << endl;
 if(debug) COUT << "offset = " << position << endl;
 
 // insert node
 boost::shared_ptr<TREENODE> node(new BOUNDINGBOX);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 BOUNDINGBOX* info = static_cast<BOUNDINGBOX*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes) return error("Property table unexpected.");

 // read minimum
 ifile.read((char*)&info->bbmin[0], 3*sizeof(float));
 if(ifile.fail()) return error("Read failed.");
 for(size_t i = 0; i < 3; i++) {
     reverse_byte_order(&info->bbmin[i]);
     if(debug) COUT << "info->bbmin[" << i << "] = " << info->bbmin[i] << endl;
    }

 // read maximum
 ifile.read((char*)&info->bbmax[0], 3*sizeof(float));
 if(ifile.fail()) return error("Read failed.");
 for(size_t i = 0; i < 3; i++) {
     reverse_byte_order(&info->bbmax[i]);
     if(debug) COUT << "info->bbmax[" << i << "] = " << info->bbmax[i] << endl;
    }

 return true;
}

bool Exporter::processCAMERANODE(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "------------" << endl;
 if(debug) COUT << " CAMERANODE " << endl;
 if(debug) COUT << "------------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new CAMERANODE);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 CAMERANODE* info = static_cast<CAMERANODE*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");

 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "CAMERANODE" && name == "isPerspective") {
          if(!readNumber(info->isPerspective)) return false;
          if(debug) COUT << "info->isPerspective = " << info->isPerspective << endl;
         }
       else if(section == "CAMERANODE" && name == "nearPlane") {
          if(!readFloat(info->nearPlane)) return false;
          if(debug) COUT << "info->nearPlane = " << info->nearPlane << endl;
         }
       else if(section == "CAMERANODE" && name == "farPlane") {
          if(!readFloat(info->farPlane)) return false;
          if(debug) COUT << "info->farPlane = " << info->farPlane << endl;
         }
       else if(section == "CAMERANODE" && name == "aspect") {
          if(!readFloat(info->aspect)) return false;
          if(debug) COUT << "info->aspect = " << info->aspect << endl;
         }
       else if(section == "CAMERANODE" && name == "FOV") {
          if(!readFloat(info->FOV)) return false;
          if(debug) COUT << "info->FOV = " << info->FOV << endl;
         }
       else if(section == "NODE" && name == "stopTraversal") {
          if(!readNumber(info->stopTraversal)) return false;
          if(debug) COUT << "info->stopTraversal = " << info->stopTraversal << endl;
         }
       else if(section == "NODE" && name == "nickname") {
          if(!readString(info->nickname)) return false;
          if(debug) COUT << "info->nickname = " << info->nickname << endl;
         }
       else if(section == "XXX" && name == "id") {
          if(!readString(info->id)) return false;
          if(debug) COUT << "info->id = " << info->id << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 return true;
}

bool Exporter::processCGSTREAM(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "----------" << endl;
 if(debug) COUT << " CGSTREAM " << endl;
 if(debug) COUT << "----------" << endl;
 if(debug) COUT << "offset = " << position << endl;
 
 // insert node
 boost::shared_ptr<TREENODE> node(new CGSTREAM);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 CGSTREAM* info = static_cast<CGSTREAM*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");

 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "CGSTREAM" && name == "cgStreamName") {
          if(!readString(info->cgStreamName)) return false;
          if(debug) COUT << "info->cgStreamName = " << info->cgStreamName << endl;
         }
       else if(section == "CGSTREAM" && name == "cgStreamDataType") {
          if(!readString(info->cgStreamDataType)) return false;
          if(debug) COUT << "info->cgStreamDataType = " << info->cgStreamDataType << endl;
         }
       else if(section == "CGSTREAM" && name == "cgStreamRenderType") {
          if(!readString(info->cgStreamRenderType)) return false;
          if(debug) COUT << "info->cgStreamRenderType = " << info->cgStreamRenderType << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 return true;
}

bool Exporter::processCHANNELREF(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "------------" << endl;
 if(debug) COUT << " CHANNELREF " << endl;
 if(debug) COUT << "------------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new CHANNELREF);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // retrieve parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;
 
 // read chunk properties
 CHANNELREF* info = static_cast<CHANNELREF*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");

 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "CHANNELREF" && name == "channel") {
          if(!readString(info->channel)) return false;
          if(debug) COUT << "channel = " << info->channel << endl;
         }
       else if(section == "CHANNELREF" && name == "targetName") {
          if(!readString(info->targetName)) return false;
          if(debug) COUT << "targetName = " << info->targetName << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 return true;
}

bool Exporter::processCONSTANTCHANNEL(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "-----------------" << endl;
 if(debug) COUT << " CONSTANTCHANNEL " << endl;
 if(debug) COUT << "-----------------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 struct CONSTANTCHANNEL : public TREENODE {
  float value[4];
  string targetName;
  string keyType;
 };

 // insert node
 boost::shared_ptr<TREENODE> node(new CONSTANTCHANNEL);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // retrieve parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;
 
 // read chunk properties
 CONSTANTCHANNEL* info = static_cast<CONSTANTCHANNEL*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");

 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "CONSTANTCHANNEL" && name == "value") {
          if(!readFloat4(info->value)) return false;
          if(debug) COUT << "value = " << "<" << info->value[0] << "," << info->value[1] << "," << info->value[2] << "," << info->value[3] << ">" << endl;
         }
       else if(section == "CONSTANTCHANNEL" && name == "targetName") {
          if(!readString(info->targetName)) return false;
          if(debug) COUT << "targetName = " << info->targetName << endl;
         }
       else if(section == "CONSTANTCHANNEL" && name == "keyType") {
          if(!readString(info->keyType)) return false;
          if(debug) COUT << "keyType = " << info->keyType << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 return true;
}

bool Exporter::processDATABLOCK(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "-----------" << endl;
 if(debug) COUT << " DATABLOCK " << endl;
 if(debug) COUT << "-----------" << endl;
 if(debug) COUT << "offset = " << position << endl;
 
 // insert node
 boost::shared_ptr<TREENODE> node(new DATABLOCK);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 DATABLOCK* info = static_cast<DATABLOCK*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");
 
 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "DATABLOCK" && name == "streamCount") {
          if(!readNumber(info->streamCount)) return false;
          if(debug) COUT << "info->streamCount = " << info->streamCount << endl;
         }
       else if(section == "DATABLOCK" && name == "size") {
          if(!readNumber(info->size)) return false;
          if(debug) COUT << "info->size = " << info->size << endl;
         }
       else if(section == "DATABLOCK" && name == "elementCount") {
          if(!readNumber(info->elementCount)) return false;
          if(debug) COUT << "info->elementCount = " << info->elementCount << endl;
         }
       else if(section == "RENDERINTERFACEBOUND" && name == "allocationStrategy") {
          if(!readNumber(info->allocationStrategy)) return false;
          if(debug) COUT << "info->allocationStrategy = " << info->allocationStrategy << endl;
         }
       else if(section == "XXX" && name == "id") {
          if(!readString(info->id)) return false;
          if(debug) COUT << "info->id = " << info->id << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 // add child chunks to stack
 scanChildren(node, position, info->chunksize - bytes_read - 4, debug);
 return true;
}

bool Exporter::processDATABLOCKDATA(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "---------------" << endl;
 if(debug) COUT << " DATABLOCKDATA " << endl;
 if(debug) COUT << "---------------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new DATABLOCKDATA);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 DATABLOCKDATA* info = static_cast<DATABLOCKDATA*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes) return error("Property table unexpected.");
 
 // read chunk data
 unsigned int datasize = info->chunksize - 4;
 info->data.reset(new unsigned char[datasize]);
 ifile.read((char*)info->data.get(), datasize);
 if(ifile.fail()) return error("Read failed.");

 return true;
}

bool Exporter::processDATABLOCKSTREAM(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "-----------------" << endl;
 if(debug) COUT << " DATABLOCKSTREAM " << endl;
 if(debug) COUT << "-----------------" << endl;
 if(debug) COUT << "offset = " << position << endl;
 
 // insert node
 boost::shared_ptr<TREENODE> node(new DATABLOCKSTREAM);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 DATABLOCKSTREAM* info = static_cast<DATABLOCKSTREAM*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");
 
 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "DATABLOCKSTREAM" && name == "renderType") {
          if(!readString(info->renderType)) return false;
          if(debug) COUT << "info->renderType = " << info->renderType << endl;
         }
       else if(section == "DATABLOCKSTREAM" && name == "dataType") {
          if(!readString(info->dataType)) return false;
          if(debug) COUT << "info->dataType = " << info->dataType << endl;
         }
       else if(section == "DATABLOCKSTREAM" && name == "offset") {
          if(!readNumber(info->offset)) return false;
          if(debug) COUT << "info->offset = " << info->offset << endl;
         }
       else if(section == "DATABLOCKSTREAM" && name == "stride") {
          if(!readNumber(info->stride)) return false;
          if(debug) COUT << "info->stride = " << info->stride << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 return true;
}

bool Exporter::processINDEXSOURCEDATA(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "-----------------" << endl;
 if(debug) COUT << " INDEXSOURCEDATA " << endl;
 if(debug) COUT << "-----------------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new INDEXSOURCEDATA);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 INDEXSOURCEDATA* info = static_cast<INDEXSOURCEDATA*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes) return error("Property table unexpected.");

 // read chunk data
 unsigned int datasize = info->chunksize - 4;
 info->data.reset(new unsigned char[datasize]);
 ifile.read((char*)info->data.get(), datasize);
 if(ifile.fail()) return error("Read failed.");

 return true;
}

bool Exporter::processINVERSEBINDMATRIX(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "-------------------" << endl;
 if(debug) COUT << " INVERSEBINDMATRIX " << endl;
 if(debug) COUT << "-------------------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new INVERSEBINDMATRIX);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 INVERSEBINDMATRIX* info = static_cast<INVERSEBINDMATRIX*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes) return error("Property table unexpected.");

/*
 // allocate matrices
 info->ibm.reset(new INVERSEBINDMATRIX[info->matrixCount]);

 // load matrices
 for(size_t i = 0; i < info->matrixCount; i++)
    {
     // read subchunk type
     info->ibm[i].chunktype = BE_read_uint32(ifile);
     if(ifile.fail()) return error("Read failed.");
     if(debug) COUT << "info->ibm.chunktype = " << info->ibm[i].chunktype << endl;
    
     // read subchunk size
     info->ibm[i].chunksize = BE_read_uint32(ifile);
     if(ifile.fail()) return error("Read failed.");
     if(debug) COUT << "info->ibm.chunksize = " << info->ibm[i].chunksize << endl;
    
     // read subchunk bytes in property table
     info->ibm[i].property_table_bytes = BE_read_uint32(ifile);
     if(ifile.fail()) return error("Read failed.");
     if(debug) COUT << "info->ibm.property_table_bytes = " << info->ibm[i].property_table_bytes << endl;
     if(info->ibm[i].property_table_bytes) return error("Property table unexpected.");
    
     // read matrix
     BE_read_array(ifile, &info->ibm[i].matrix[0], 16);
     if(ifile.fail()) return error("Read failed.");
     if(debug) for(size_t j = 0; j < 16; j++) COUT << "info->ibm[" << i << "].matrix[" << j << "] = " << info->ibm[i].matrix[j] << endl;
    }
*/

 return true;
}

bool Exporter::processJOINTNODE(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "-----------" << endl;
 if(debug) COUT << " JOINTNODE " << endl;
 if(debug) COUT << "-----------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new JOINTNODE);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 JOINTNODE* info = static_cast<JOINTNODE*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");

 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "NODE" && name == "nickname") {
          if(!readString(info->nickname)) return false;
          if(debug) COUT << "info->nickname = " << info->nickname << endl;
         }
       else if(section == "NODE" && name == "stopTraversal") {
          if(!readNumber(info->stopTraversal)) return false;
          if(debug) COUT << "info->stopTraversal = " << info->stopTraversal << endl;
         }
       else if(section == "XXX" && name == "id") {
          if(!readString(info->id)) return false;
          if(debug) COUT << "info->id = " << info->id << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 // add child chunks to stack
 scanChildren(node, position, info->chunksize - bytes_read - 4, debug);
 return true;
}

bool Exporter::processKEYS(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "------" << endl;
 if(debug) COUT << " KEYS " << endl;
 if(debug) COUT << "------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new KEYS);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // retrieve parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;
 
 // read chunk properties
 KEYS* info = static_cast<KEYS*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes) return error("Property table unexpected.");

 // read chunk data
 unsigned int datasize = info->chunksize - 4;
 info->data.reset(new float[datasize]);
 ifile.read((char*)info->data.get(), datasize);
 if(ifile.fail()) return error("Read failed.");

 return true;
}

bool Exporter::processLIBRARY(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "---------" << endl;
 if(debug) COUT << " LIBRARY " << endl;
 if(debug) COUT << "---------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new LIBRARY);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 LIBRARY* info = static_cast<LIBRARY*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");

 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "LIBRARY" && name == "type") {
          if(!readString(info->type)) return false;
          if(debug) COUT << "type = " << info->type << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 // add child chunks to stack
 scanChildren(node, position, info->chunksize - bytes_read - 4, debug);
 return true;
}

bool Exporter::processLIGHTNODE(unsigned int chunktype, unsigned int position)
{
 return true;
}

bool Exporter::processMODIFIERNETWORK(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "-----------------" << endl;
 if(debug) COUT << " MODIFIERNETWORK " << endl;
 if(debug) COUT << "-----------------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new MODIFIERNETWORK);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 MODIFIERNETWORK* info = static_cast<MODIFIERNETWORK*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");

 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "MODIFIERNETWORK" && name == "modifierCount") {
          if(!readNumber(info->modifierCount)) return false;
          if(debug) COUT << "info->modifierCount = " << info->modifierCount << endl;
         }
       else if(section == "MODIFIERNETWORK" && name == "streamingStrategy") {
          if(!readString(info->streamingStrategy)) return false;
          if(debug) COUT << "info->streamingStrategy = " << info->streamingStrategy << endl;
         }
       else if(section == "XXX" && name == "id") {
          if(!readString(info->id)) return false;
          if(debug) COUT << "info->id = " << info->id << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 // add child chunks to stack
 scanChildren(node, position, info->chunksize - bytes_read - 4, debug);
 return true;
}

bool Exporter::processMODIFIERNETWORKCONNECTION(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "---------------------------" << endl;
 if(debug) COUT << " MODIFIERNETWORKCONNECTION " << endl;
 if(debug) COUT << "---------------------------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new MODIFIERNETWORKCONNECTION);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 MODIFIERNETWORKCONNECTION* info = static_cast<MODIFIERNETWORKCONNECTION*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");

 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "MODIFIERNETWORKCONNECTION" && name == "modifier") {
          if(!readNumber(info->modifier)) return false;
          if(debug) COUT << "info->modifier = " << info->modifier << endl;
         }
       else if(section == "MODIFIERNETWORKCONNECTION" && name == "stream") {
          if(!readNumber(info->stream)) return false;
          if(debug) COUT << "info->stream = " << info->stream << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 return true;
}

bool Exporter::processMODIFIERNETWORKENTRY(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "----------------------" << endl;
 if(debug) COUT << " MODIFIERNETWORKENTRY " << endl;
 if(debug) COUT << "----------------------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new MODIFIERNETWORKENTRY);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 MODIFIERNETWORKENTRY* info = static_cast<MODIFIERNETWORKENTRY*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");

 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "MODIFIERNETWORKENTRY" && name == "name") {
          if(!readString(info->name)) return false;
          if(debug) COUT << "info->name = " << info->name << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 // add child chunks to stack
 scanChildren(node, position, info->chunksize - bytes_read - 4, debug);
 return true;
}

bool Exporter::processMODIFIERNETWORKINSTANCE(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "-------------------------" << endl;
 if(debug) COUT << " MODIFIERNETWORKINSTANCE " << endl;
 if(debug) COUT << "-------------------------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new MODIFIERNETWORKINSTANCE);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 MODIFIERNETWORKINSTANCE* info = static_cast<MODIFIERNETWORKINSTANCE*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");

 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "MODIFIERNETWORKINSTANCE" && name == "dynamicStreamCount") {
          if(!readNumber(info->dynamicStreamCount)) return false;
          if(debug) COUT << "info->dynamicStreamCount = " << info->dynamicStreamCount << endl;
         }
       else if(section == "MODIFIERNETWORKINSTANCE" && name == "modifierInputCount") {
          if(!readNumber(info->modifierInputCount)) return false;
          if(debug) COUT << "info->modifierInputCount = " << info->modifierInputCount << endl;
         }
       else if(section == "MODIFIERNETWORKINSTANCE" && name == "modifierCount") {
          if(!readNumber(info->modifierCount)) return false;
          if(debug) COUT << "info->modifierCount = " << info->modifierCount << endl;
         }
       else if(section == "MODIFIERNETWORKINSTANCE" && name == "packetModifierCount") {
          if(!readNumber(info->packetModifierCount)) return false;
          if(debug) COUT << "info->packetModifierCount = " << info->packetModifierCount << endl;
         }
       else if(section == "MODIFIERNETWORKINSTANCE" && name == "network") {
          if(!readString(info->network)) return false;
          if(debug) COUT << "info->network = " << info->network << endl;
         }
       else if(section == "MODIFIERNETWORKINSTANCE" && name == "parameterCount") {
          if(!readNumber(info->streamCount)) return false;
          if(debug) COUT << "info->parameterCount = " << info->parameterCount << endl;
         }
       else if(section == "RENDERSTREAMINSTANCE" && name == "sourceCount") {
          if(!readNumber(info->sourceCount)) return false;
          if(debug) COUT << "info->sourceCount = " << info->sourceCount << endl;
         }
       else if(section == "RENDERSTREAMINSTANCE" && name == "indices") {
          if(!readString(info->indices)) return false;
          if(debug) COUT << "info->indices = " << info->indices << endl;
         }
       else if(section == "RENDERINSTANCE" && name == "streamCount") {
          if(!readNumber(info->streamCount)) return false;
          if(debug) COUT << "info->streamCount = " << info->streamCount << endl;
         }
       else if(section == "RENDERINSTANCE" && name == "shader") {
          if(!readString(info->shader)) return false;
          if(debug) COUT << "info->shader = " << info->shader << endl;
         }
       else if(section == "RENDERINTERFACEBOUND" && name == "allocationStrategy") {
          if(!readNumber(info->allocationStrategy)) return false;
          if(debug) COUT << "info->allocationStrategy = " << info->allocationStrategy << endl;
         }
       else if(section == "XXX" && name == "id") {
          if(!readString(info->id)) return false;
          if(debug) COUT << "info->id = " << info->id << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 // add child chunks to stack
 scanChildren(node, position, info->chunksize - bytes_read - 4, debug);
 return true;
}

bool Exporter::processMODIFIERNETWORKINSTANCECOMPILE(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "--------------------------------" << endl;
 if(debug) COUT << " MODIFIERNETWORKINSTANCECOMPILE " << endl;
 if(debug) COUT << "--------------------------------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new MODIFIERNETWORKINSTANCECOMPILE);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 MODIFIERNETWORKINSTANCECOMPILE* info = static_cast<MODIFIERNETWORKINSTANCECOMPILE*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");

 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "MODIFIERNETWORKINSTANCECOMPILE" && name == "uniqueInputCount") {
          if(!readNumber(info->uniqueInputCount)) return false;
          if(debug) COUT << "info->uniqueInputCount = " << info->uniqueInputCount << endl;
         }
       else if(section == "MODIFIERNETWORKINSTANCECOMPILE" && name == "maxElementCount") {
          if(!readNumber(info->maxElementCount)) return false;
          if(debug) COUT << "info->maxElementCount = " << info->maxElementCount << endl;
         }
       else if(section == "MODIFIERNETWORKINSTANCECOMPILE" && name == "memorySizeForProcess") {
          if(!readNumber(info->memorySizeForProcess)) return false;
          if(debug) COUT << "info->memorySizeForProcess = " << info->memorySizeForProcess << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 // add child chunks to stack
 scanChildren(node, position, info->chunksize - bytes_read - 4, debug);
 return true;
}

bool Exporter::processMODIFIERNETWORKINSTANCEDYNAMICSTREAM(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "--------------------------------------" << endl;
 if(debug) COUT << " MODIFIERNETWORKINSTANCEDYNAMICSTREAM " << endl;
 if(debug) COUT << "--------------------------------------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new MODIFIERNETWORKINSTANCEDYNAMICSTREAM);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 MODIFIERNETWORKINSTANCEDYNAMICSTREAM* info = static_cast<MODIFIERNETWORKINSTANCEDYNAMICSTREAM*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");

 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "MODIFIERNETWORKINSTANCEDYNAMICSTREAM" && name == "id") {
          if(!readNumber(info->id)) return false;
          if(debug) COUT << "info->id = " << info->id << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 return true;
}

bool Exporter::processMODIFIERNETWORKINSTANCEDYNAMICSTREAMTYPE(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "------------------------------------------" << endl;
 if(debug) COUT << " MODIFIERNETWORKINSTANCEDYNAMICSTREAMTYPE " << endl;
 if(debug) COUT << "------------------------------------------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new MODIFIERNETWORKINSTANCEDYNAMICSTREAMTYPE);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 MODIFIERNETWORKINSTANCEDYNAMICSTREAMTYPE* info = static_cast<MODIFIERNETWORKINSTANCEDYNAMICSTREAMTYPE*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");

 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "MODIFIERNETWORKINSTANCEDYNAMICSTREAMTYPE" && name == "type") {
          if(!readString(info->type)) return false;
          if(debug) COUT << "info->type = " << info->type << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 return true;
}

bool Exporter::processMODIFIERNETWORKINSTANCEMODIFIERINPUT(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "--------------------------------------" << endl;
 if(debug) COUT << " MODIFIERNETWORKINSTANCEMODIFIERINPUT " << endl;
 if(debug) COUT << "--------------------------------------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new MODIFIERNETWORKINSTANCEMODIFIERINPUT);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 MODIFIERNETWORKINSTANCEMODIFIERINPUT* info = static_cast<MODIFIERNETWORKINSTANCEMODIFIERINPUT*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");
 
 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "MODIFIERNETWORKINSTANCEMODIFIERINPUT" && name == "source") {
          if(!readNumber(info->source)) return false;
          if(debug) COUT << "info->source = " << info->source << endl;
         }
       else if(section == "MODIFIERNETWORKINSTANCEMODIFIERINPUT" && name == "stream") {
          if(!readNumber(info->stream)) return false;
          if(debug) COUT << "info->stream = " << info->stream << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 return true;
}

bool Exporter::processMODIFIERNETWORKINSTANCEUNIQUEINPUT(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "------------------------------------" << endl;
 if(debug) COUT << " MODIFIERNETWORKINSTANCEUNIQUEINPUT " << endl;
 if(debug) COUT << "------------------------------------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new MODIFIERNETWORKINSTANCEUNIQUEINPUT);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 MODIFIERNETWORKINSTANCEUNIQUEINPUT* info = static_cast<MODIFIERNETWORKINSTANCEUNIQUEINPUT*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");

 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "MODIFIERNETWORKINSTANCEUNIQUEINPUT" && name == "uniqueInputSource") {
          if(!readNumber(info->uniqueInputSource)) return false;
          if(debug) COUT << "info->uniqueInputSource = " << info->uniqueInputSource << endl;
         }
       else if(section == "MODIFIERNETWORKINSTANCEUNIQUEINPUT" && name == "uniqueInputStream") {
          if(!readNumber(info->uniqueInputStream)) return false;
          if(debug) COUT << "info->uniqueInputStream = " << info->uniqueInputStream << endl;
         }
       else if(section == "MODIFIERNETWORKINSTANCEUNIQUEINPUT" && name == "uniqueInputElementSize") {
          if(!readNumber(info->uniqueInputElementSize)) return false;
          if(debug) COUT << "info->uniqueInputElementSize = " << info->uniqueInputElementSize << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 return true;
}

bool Exporter::processMODIFIERNETWORKINSTANCEUNIQUEMODIFIERINPUT(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "--------------------------------------------" << endl;
 if(debug) COUT << " MODIFIERNETWORKINSTANCEUNIQUEMODIFIERINPUT " << endl;
 if(debug) COUT << "--------------------------------------------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new MODIFIERNETWORKINSTANCEUNIQUEMODIFIERINPUT);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 MODIFIERNETWORKINSTANCEUNIQUEMODIFIERINPUT* info = static_cast<MODIFIERNETWORKINSTANCEUNIQUEMODIFIERINPUT*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes) return error("Property table unexpected.");

 // read chunk data
 unsigned int datasize = info->chunksize - 4;
 info->data.reset(new unsigned char[datasize]);
 ifile.read((char*)info->data.get(), datasize);
 if(ifile.fail()) return error("Read failed.");

 return true;
}

bool Exporter::processMORPHMODIFIERWEIGHTS(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "----------------------" << endl;
 if(debug) COUT << " MORPHMODIFIERWEIGHTS " << endl;
 if(debug) COUT << "----------------------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new MORPHMODIFIERWEIGHTS);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 MORPHMODIFIERWEIGHTS* info = static_cast<MORPHMODIFIERWEIGHTS*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");

 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "MORPHMODIFIERWEIGHTS" && name == "weightCount") {
          if(!readNumber(info->weightCount)) return false;
          if(debug) COUT << "info->weightCount = " << info->weightCount << endl;
         }
       else if(section == "XXX" && name == "id") {
          if(!readString(info->id)) return false;
          if(debug) COUT << "info->id = " << info->id << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 return true;
}

bool Exporter::processNODE(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "------" << endl;
 if(debug) COUT << " NODE " << endl;
 if(debug) COUT << "------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new NODE);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 NODE* info = static_cast<NODE*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");

 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "NODE" && name == "stopTraversal") {
          if(!readNumber(info->stopTraversal)) return false;
          if(debug) COUT << "node.stopTraversal = " << info->stopTraversal << endl;
         }
       else if(section == "NODE" && name == "nickname") {
          if(!readString(info->nickname)) return false;
          if(debug) COUT << "node.nickname = " << info->nickname << endl;
         }
       else if(section == "XXX" && name == "id") {
          if(!readString(info->id)) return false;
          if(debug) COUT << "info->id = " << info->id << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 // add child chunks to stack
 scanChildren(node, position, info->chunksize - bytes_read - 4, debug);
 return true;
}

bool Exporter::processRENDERDATASOURCE(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "------------------" << endl;
 if(debug) COUT << " RENDERDATASOURCE " << endl;
 if(debug) COUT << "------------------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new RENDERDATASOURCE);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 RENDERDATASOURCE* info = static_cast<RENDERDATASOURCE*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");

 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "RENDERDATASOURCE" && name == "streamCount") {
          if(!readNumber(info->streamCount)) return false;
          if(debug) COUT << "info->streamCount = " << info->streamCount << endl;
         }
       else if(section == "RENDERDATASOURCE" && name == "primitive") {
          if(!readString(info->primitive)) return false;
          if(debug) COUT << "info->primitive = " << info->primitive << endl;
         }
       else if(section == "XXX" && name == "id") {
          if(!readString(info->id)) return false;
          if(debug) COUT << "info->id = " << info->id << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 // add child chunks to stack
 scanChildren(node, position, info->chunksize - bytes_read - 4, debug);
 return true;
}

bool Exporter::processRENDERINDEXSOURCE(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "-------------------" << endl;
 if(debug) COUT << " RENDERINDEXSOURCE " << endl;
 if(debug) COUT << "-------------------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new RENDERINDEXSOURCE);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 RENDERINDEXSOURCE* info = static_cast<RENDERINDEXSOURCE*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");
 
 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "RENDERINDEXSOURCE" && name == "primitive") {
          if(!readString(info->primitive)) return false;
          if(debug) COUT << "info->primitive = " << info->primitive << endl;
         }
       else if(section == "RENDERINDEXSOURCE" && name == "format") {
          if(!readString(info->format)) return false;
          if(debug) COUT << "info->format = " << info->format << endl;
         }
       else if(section == "RENDERINDEXSOURCE" && name == "count") {
          if(!readNumber(info->count)) return false;
          if(debug) COUT << "info->count = " << info->count << endl;
         }
       else if(section == "RENDERINDEXSOURCE" && name == "maximumIndex") {
          if(!readNumber(info->maximumIndex)) return false;
          if(debug) COUT << "info->maximumIndex = " << info->maximumIndex << endl;
         }
       else if(section == "RENDERINTERFACEBOUND" && name == "allocationStrategy") {
          if(!readNumber(info->allocationStrategy)) return false;
          if(debug) COUT << "info->allocationStrategy = " << info->allocationStrategy << endl;
         }
       else if(section == "XXX" && name == "id") {
          if(!readString(info->id)) return false;
          if(debug) COUT << "info->id = " << info->id << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 // add child chunks to stack
 scanChildren(node, position, info->chunksize - bytes_read - 4, debug);
 return true;
}

bool Exporter::processRENDERINSTANCESOURCE(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "----------------------" << endl;
 if(debug) COUT << " RENDERINSTANCESOURCE " << endl;
 if(debug) COUT << "----------------------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new RENDERINSTANCESOURCE);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 RENDERINSTANCESOURCE* info = static_cast<RENDERINSTANCESOURCE*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");

 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "RENDERINSTANCESOURCE" && name == "source") {
          if(!readString(info->source)) return false;
          if(debug) COUT << "info->source = " << info->source << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 return true;
}

bool Exporter::processRENDERINSTANCESTREAM(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "----------------------" << endl;
 if(debug) COUT << " RENDERINSTANCESTREAM " << endl;
 if(debug) COUT << "----------------------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new RENDERINSTANCESTREAM);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 RENDERINSTANCESTREAM* info = static_cast<RENDERINSTANCESTREAM*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");

 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "RENDERINSTANCESTREAM" && name == "sourceID") {
          if(!readNumber(info->sourceID)) return false;
          if(debug) COUT << "info->sourceID = " << info->sourceID << endl;
         }
       else if(section == "RENDERINSTANCESTREAM" && name == "streamID") {
          if(!readNumber(info->streamID)) return false;
          if(debug) COUT << "info->streamID = " << info->streamID << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 return true;
}

bool Exporter::processRENDERNODE(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "------------" << endl;
 if(debug) COUT << " RENDERNODE " << endl;
 if(debug) COUT << "------------" << endl;
 if(debug) COUT << "offset = " << position << endl;
 
 // insert node
 boost::shared_ptr<TREENODE> node(new RENDERNODE);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 RENDERNODE* info = static_cast<RENDERNODE*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");

 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "NODE" && name == "stopTraversal") {
          if(!readNumber(info->stopTraversal)) return false;
          if(debug) COUT << "info->stopTraversal = " << info->stopTraversal << endl;
         }
       else if(section == "NODE" && name == "nickname") {
          if(!readString(info->nickname)) return false;
          if(debug) COUT << "info->nickname = " << info->nickname << endl;
         }
       else if(section == "XXX" && name == "id") {
          if(!readString(info->id)) return false;
          if(debug) COUT << "info->id = " << info->id << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 // add child chunks to stack
 scanChildren(node, position, info->chunksize - bytes_read - 4, debug);
 return true;
}

bool Exporter::processRENDERSTREAM(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "--------------" << endl;
 if(debug) COUT << " RENDERSTREAM " << endl;
 if(debug) COUT << "--------------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new RENDERSTREAM);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 RENDERSTREAM* info = static_cast<RENDERSTREAM*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");

 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "RENDERSTREAM" && name == "dataBlock") {
          if(!readString(info->dataBlock)) return false;
          if(debug) COUT << "info->dataBlock = " << info->dataBlock << endl;
         }
       else if(section == "RENDERSTREAM" && name == "subStream") {
          if(!readNumber(info->subStream)) return false;
          if(debug) COUT << "info->subStream = " << info->subStream << endl;
         }
       else if(section == "XXX" && name == "id") {
          if(!readString(info->id)) return false;
          if(debug) COUT << "info->id = " << info->id << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 return true;
}

bool Exporter::processRENDERSTREAMINSTANCE(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "----------------------" << endl;
 if(debug) COUT << " RENDERSTREAMINSTANCE " << endl;
 if(debug) COUT << "----------------------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new RENDERSTREAMINSTANCE);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 RENDERSTREAMINSTANCE* info = static_cast<RENDERSTREAMINSTANCE*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");

 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "RENDERSTREAMINSTANCE" && name == "sourceCount") {
          if(!readNumber(info->sourceCount)) return false;
          if(debug) COUT << "info->sourceCount = " << info->sourceCount << endl;
         }
       else if(section == "RENDERSTREAMINSTANCE" && name == "indices") {
          if(!readString(info->indices)) return false;
          if(debug) COUT << "info->indices = " << info->indices << endl;
         }
       else if(section == "RENDERINSTANCE" && name == "streamCount") {
          if(!readNumber(info->streamCount)) return false;
          if(debug) COUT << "info->streamCount = " << info->streamCount << endl;
         }
       else if(section == "RENDERINSTANCE" && name == "shader") {
          if(!readString(info->shader)) return false;
          if(debug) COUT << "info->shader = " << info->shader << endl;
         }
       else if(section == "RENDERINTERFACEBOUND" && name == "allocationStrategy") {
          if(!readNumber(info->allocationStrategy)) return false;
          if(debug) COUT << "info->allocationStrategy = " << info->allocationStrategy << endl;
         }
       else if(section == "XXX" && name == "id") {
          if(!readString(info->id)) return false;
          if(debug) COUT << "info->id = " << info->id << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 // add child chunks to stack
 scanChildren(node, position, info->chunksize - bytes_read - 4, debug);
 return true;
}

bool Exporter::processRISTREAM(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "----------" << endl;
 if(debug) COUT << " RISTREAM " << endl;
 if(debug) COUT << "----------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new RISTREAM);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 RISTREAM* info = static_cast<RISTREAM*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");

 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "RISTREAM" && name == "stream") {
          if(!readNumber(info->stream)) return false;
          if(debug) COUT << "info->stream = " << info->stream << endl;
         }
       else if(section == "RISTREAM" && name == "id") {
          if(!readNumber(info->id)) return false;
          if(debug) COUT << "info->id = " << info->id << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 return true;
}

bool Exporter::processROOTNODE(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "----------" << endl;
 if(debug) COUT << " ROOTNODE " << endl;
 if(debug) COUT << "----------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new ROOTNODE);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 ROOTNODE* info = static_cast<ROOTNODE*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");
 
 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "NODE" && name == "stopTraversal") {
          if(!readNumber(info->stopTraversal)) return false;
          if(debug) COUT << "info->stopTraversal = " << info->stopTraversal << endl;
         }
       else if(section == "NODE" && name == "nickname") {
          if(!readString(info->nickname)) return false;
          if(debug) COUT << "info->nickname = " << info->nickname << endl;
         }
       else if(section == "XXX" && name == "id") {
          if(!readString(info->id)) return false;
          if(debug) COUT << "info->id = " << info->id << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 // add child chunks to stack
 scanChildren(node, position, info->chunksize - bytes_read - 4, debug);
 return true;
}

bool Exporter::processSEGMENTSET(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "------------" << endl;
 if(debug) COUT << " SEGMENTSET " << endl;
 if(debug) COUT << "------------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new SEGMENTSET);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 SEGMENTSET* info = static_cast<SEGMENTSET*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");

 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "SEGMENTSET" && name == "segmentCount") {
          if(!readNumber(info->segmentCount)) return false;
          if(debug) COUT << "info->segmentCount = " << info->segmentCount << endl;
         }
       else if(section == "XXX" && name == "id") {
          if(!readString(info->id)) return false;
          if(debug) COUT << "info->id = " << info->id << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 // add child chunks to stack
 scanChildren(node, position, info->chunksize - bytes_read - 4, debug);
 return true;
}

bool Exporter::processSHADERGROUP(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "-------------" << endl;
 if(debug) COUT << " SHADERGROUP " << endl;
 if(debug) COUT << "-------------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new SHADERGROUP);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 SHADERGROUP* info = static_cast<SHADERGROUP*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");

 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "SHADERGROUP" && name == "parameterCount") {
          if(!readNumber(info->parameterCount)) return false;
          if(debug) COUT << "info->parameterCount = " << info->parameterCount << endl;
         }
       else if(section == "SHADERGROUP" && name == "parameterSavedCount") {
          if(!readNumber(info->parameterSavedCount)) return false;
          if(debug) COUT << "info->parameterSavedCount = " << info->parameterSavedCount << endl;
         }
       else if(section == "SHADERGROUP" && name == "parameterStreamCount") {
          if(!readNumber(info->parameterStreamCount)) return false;
          if(debug) COUT << "info->parameterStreamCount = " << info->parameterStreamCount << endl;
         }
       else if(section == "SHADERGROUP" && name == "instancesRequireSorting") {
          if(!readNumber(info->instancesRequireSorting)) return false;
          if(debug) COUT << "info->instancesRequireSorting = " << info->instancesRequireSorting << endl;
         }
       else if(section == "SHADERGROUP" && name == "defaultRenderSortPriority") {
          if(!readNumber(info->defaultRenderSortPriority)) return false;
          if(debug) COUT << "info->defaultRenderSortPriority = " << info->defaultRenderSortPriority << endl;
         }
       else if(section == "SHADERGROUP" && name == "passCount") {
          if(!readNumber(info->passCount)) return false;
          if(debug) COUT << "info->passCount = " << info->passCount << endl;
         }
       else if(section == "XXX" && name == "id") {
          if(!readString(info->id)) return false;
          if(debug) COUT << "info->id = " << info->id << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 // add child chunks to stack
 scanChildren(node, position, info->chunksize - bytes_read - 4, debug);
 return true;
}

bool Exporter::processSHADERGROUPPASS(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "-----------------" << endl;
 if(debug) COUT << " SHADERGROUPPASS " << endl;
 if(debug) COUT << "-----------------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new SHADERGROUPPASS);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 SHADERGROUPPASS* info = static_cast<SHADERGROUPPASS*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");

 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "SHADERGROUPPASS" && name == "vertexProgram") {
          if(!readString(info->vertexProgram)) return false;
          if(debug) COUT << "info->vertexProgram = " << info->vertexProgram << endl;
         }
       else if(section == "SHADERGROUPPASS" && name == "fragmentProgram") {
          if(!readString(info->fragmentProgram)) return false;
          if(debug) COUT << "info->fragmentProgram = " << info->fragmentProgram << endl;
         }
       else if(section == "SHADERGROUPPASS" && name == "renderTargetMask") {
          if(!readNumber(info->renderTargetMask)) return false;
          if(debug) COUT << "info->renderTargetMask = " << info->renderTargetMask << endl;
         }
       else if(section == "SHADERGROUPPASS" && name == "clearMask") {
          if(!readNumber(info->clearMask)) return false;
          if(debug) COUT << "info->clearMask = " << info->clearMask << endl;
         }
       else if(section == "SHADERGROUPPASS" && name == "passConfigMask") {
          if(!readNumber(info->passConfigMask)) return false;
          if(debug) COUT << "info->passConfigMask = " << info->passConfigMask << endl;
         }
       else if(section == "SHADERGROUPPASS" && name == "blendEnable") {
          if(!readNumber(info->blendEnable)) return false;
          if(debug) COUT << "info->blendEnable = " << info->blendEnable << endl;
         }
       else if(section == "SHADERGROUPPASS" && name == "blendEquationColor") {
          if(!readString(info->blendEquationColor)) return false;
          if(debug) COUT << "info->blendEquationColor = " << info->blendEquationColor << endl;
         }
       else if(section == "SHADERGROUPPASS" && name == "blendEquationAlpha") {
          if(!readString(info->blendEquationAlpha)) return false;
          if(debug) COUT << "info->blendEquationAlpha = " << info->blendEquationAlpha << endl;
         }
       else if(section == "SHADERGROUPPASS" && name == "blendSourceColor") {
          if(!readString(info->blendSourceColor)) return false;
          if(debug) COUT << "info->blendSourceColor = " << info->blendSourceColor << endl;
         }
       else if(section == "SHADERGROUPPASS" && name == "blendDestColor") {
          if(!readString(info->blendDestColor)) return false;
          if(debug) COUT << "info->blendDestColor = " << info->blendDestColor << endl;
         }
       else if(section == "SHADERGROUPPASS" && name == "blendSourceAlpha") {
          if(!readString(info->blendSourceAlpha)) return false;
          if(debug) COUT << "info->blendSourceAlpha = " << info->blendSourceAlpha << endl;
         }
       else if(section == "SHADERGROUPPASS" && name == "blendDestAlpha") {
          if(!readString(info->blendDestAlpha)) return false;
          if(debug) COUT << "info->blendDestAlpha = " << info->blendDestAlpha << endl;
         }
       else if(section == "SHADERGROUPPASS" && name == "alphaTestEnable") {
          if(!readNumber(info->alphaTestEnable)) return false;
          if(debug) COUT << "info->alphaTestEnable = " << info->alphaTestEnable << endl;
         }
       else if(section == "SHADERGROUPPASS" && name == "alphaTestFunc") {
          if(!readString(info->alphaTestFunc)) return false;
          if(debug) COUT << "info->alphaTestFunc = " << info->alphaTestFunc << endl;
         }
       else if(section == "SHADERGROUPPASS" && name == "alphaTestRef") {
          if(!readNumber(info->alphaTestRef)) return false;
          if(debug) COUT << "info->alphaTestRef = " << info->alphaTestRef << endl;
         }
       else if(section == "SHADERGROUPPASS" && name == "cullFaceType") {
          if(!readString(info->cullFaceType)) return false;
          if(debug) COUT << "info->cullFaceType = " << info->cullFaceType << endl;
         }
       else if(section == "SHADERGROUPPASS" && name == "depthMaskEnable") {
          if(!readNumber(info->depthMaskEnable)) return false;
          if(debug) COUT << "info->depthMaskEnable = " << info->depthMaskEnable << endl;
         }
       else if(section == "SHADERGROUPPASS" && name == "depthTestEnable") {
          if(!readNumber(info->depthTestEnable)) return false;
          if(debug) COUT << "info->depthTestEnable = " << info->depthTestEnable << endl;
         }
       else if(section == "SHADERGROUPPASS" && name == "depthTestFunc") {
          if(!readString(info->depthTestFunc)) return false;
          if(debug) COUT << "info->depthTestFunc = " << info->depthTestFunc << endl;
         }
       else if(section == "SHADERGROUPPASS" && name == "pointSize") {
          if(!readFloat(info->pointSize)) return false;
          if(debug) COUT << "info->pointSize = " << info->pointSize << endl;
         }
       else if(section == "SHADERGROUPPASS" && name == "pointTexCoordMask") {
          if(!readNumber(info->pointTexCoordMask)) return false;
          if(debug) COUT << "info->pointTexCoordMask = " << info->pointTexCoordMask << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 return true;
}

bool Exporter::processSHADERINPUT(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "-------------" << endl;
 if(debug) COUT << " SHADERINPUT " << endl;
 if(debug) COUT << "-------------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new SHADERINPUT);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 SHADERINPUT* info = static_cast<SHADERINPUT*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");

 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "SHADERINPUT" && name == "parameterID") {
          if(!readNumber(info->parameterID)) return false;
          if(debug) COUT << "info->parameterID = " << info->parameterID << endl;
         }
       else if(section == "SHADERINPUT" && name == "type") {
          if(!readString(info->type)) return false;
          if(debug) COUT << "info->type = " << info->type << endl;
         }
       else if(section == "SHADERINPUT" && name == "format") {
          if(!readString(info->format)) return false;
          if(debug) COUT << "info->format = " << info->format << endl;
         }
       else if(section == "SHADERINPUT" && name == "texture") {
          if(!readString(info->texture)) return false;
          if(debug) COUT << "info->texture = " << info->texture << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 // read extra data
 if(info->type == "constant")
   {
    if(info->format == "float3") {
       float* temp = new float[3];
       temp[0] = BE_read_float(ifile); if(ifile.fail()) return error("Read failed.");
       temp[1] = BE_read_float(ifile); if(ifile.fail()) return error("Read failed.");
       temp[2] = BE_read_float(ifile); if(ifile.fail()) return error("Read failed.");
       if(debug) COUT << "si.data = " << "<" << temp[0] << "," << temp[1] << "," << temp[2] << ">" << endl;
       info->data.reset(reinterpret_cast<unsigned char*>(temp));
      }
    else if(info->format == "float4") {
       float* temp = new float[4];
       temp[0] = BE_read_float(ifile); if(ifile.fail()) return error("Read failed.");
       temp[1] = BE_read_float(ifile); if(ifile.fail()) return error("Read failed.");
       temp[2] = BE_read_float(ifile); if(ifile.fail()) return error("Read failed.");
       temp[3] = BE_read_float(ifile); if(ifile.fail()) return error("Read failed.");
       if(debug) COUT << "si.data = " << "<" << temp[0] << "," << temp[1] << "," << temp[2] << "," << temp[3] << ">" << endl;
       info->data.reset(reinterpret_cast<unsigned char*>(temp));
      }
   }

 return true;
}

bool Exporter::processSHADERINPUTDEFINITION(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "-----------------------" << endl;
 if(debug) COUT << " SHADERINPUTDEFINITION " << endl;
 if(debug) COUT << "-----------------------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new SHADERINPUTDEFINITION);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 SHADERINPUTDEFINITION* info = static_cast<SHADERINPUTDEFINITION*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");

 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "SHADERINPUTDEFINITION" && name == "name") {
          if(!readString(info->name)) return false;
          if(debug) COUT << "info->name = " << info->name << endl;
         }
       else if(section == "SHADERINPUTDEFINITION" && name == "type") {
          if(!readString(info->type)) return false;
          if(debug) COUT << "info->type = " << info->type << endl;
         }
       else if(section == "SHADERINPUTDEFINITION" && name == "format") {
          if(!readString(info->format)) return false;
          if(debug) COUT << "info->format = " << info->format << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 return true;
}

bool Exporter::processSHADERINSTANCE(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "----------------" << endl;
 if(debug) COUT << " SHADERINSTANCE " << endl;
 if(debug) COUT << "----------------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new SHADERINSTANCE);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 SHADERINSTANCE* info = static_cast<SHADERINSTANCE*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");
 
 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "SHADERINSTANCE" && name == "shaderGroup") {
          if(!readString(info->shaderGroup)) return false;
          if(debug) COUT << "info->shaderGroup = " << info->shaderGroup << endl;
         }
       else if(section == "SHADERINSTANCE" && name == "parameterCount") {
          if(!readNumber(info->parameterCount)) return false;
          if(debug) COUT << "info->parameterCount = " << info->parameterCount << endl;
         }
       else if(section == "SHADERINSTANCE" && name == "parameterSavedCount") {
          if(!readNumber(info->parameterSavedCount)) return false;
          if(debug) COUT << "info->parameterSavedCount = " << info->parameterSavedCount << endl;
         }
       else if(section == "SHADERINSTANCE" && name == "renderSortPriority") {
          if(!readNumber(info->renderSortPriority)) return false;
          if(debug) COUT << "info->renderSortPriority = " << info->renderSortPriority << endl;
         }
       else if(section == "XXX" && name == "id") {
          if(!readString(info->id)) return false;
          if(debug) COUT << "info->id = " << info->id << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 return true;
}

bool Exporter::processSHADERPROGRAM(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "---------------" << endl;
 if(debug) COUT << " SHADERPROGRAM " << endl;
 if(debug) COUT << "---------------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new SHADERPROGRAM);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 SHADERPROGRAM* info = static_cast<SHADERPROGRAM*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");

 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "SHADERPROGRAM" && name == "codeCount") {
          if(!readNumber(info->codeCount)) return false;
          if(debug) COUT << "info->codeCount = " << info->codeCount << endl;
         }
       else if(section == "XXX" && name == "id") {
          if(!readString(info->id)) return false;
          if(debug) COUT << "info->id = " << info->id << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 // add child chunks to stack
 scanChildren(node, position, info->chunksize - bytes_read - 4, debug);
 return true;
}

bool Exporter::processSHADERPROGRAMCODE(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "-------------------" << endl;
 if(debug) COUT << " SHADERPROGRAMCODE " << endl;
 if(debug) COUT << "-------------------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new SHADERPROGRAMCODE);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 SHADERPROGRAMCODE* info = static_cast<SHADERPROGRAMCODE*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");

 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "SHADERPROGRAMCODE" && name == "codeSize") {
          if(!readNumber(info->codeSize)) return false;
          if(debug) COUT << "info->codeSize = " << info->codeSize << endl;
         }
       else if(section == "SHADERPROGRAMCODE" && name == "codeType") {
          if(!readString(info->codeType)) return false;
          if(debug) COUT << "info->codeType = " << info->codeType << endl;
         }
       else if(section == "SHADERPROGRAMCODE" && name == "codeEntry") {
          if(!readString(info->codeEntry)) return false;
          if(debug) COUT << "info->codeEntry = " << info->codeEntry << endl;
         }
       else if(section == "SHADERPROGRAMCODE" && name == "profileType") {
          if(!readNumber(info->profileType)) return false;
          if(debug) COUT << "info->profileType = " << info->profileType << endl;
         }
       else if(section == "SHADERPROGRAMCODE" && name == "profile") {
          if(!readNumber(info->profile)) return false;
          if(debug) COUT << "info->profile = " << info->profile << endl;
         }
       else if(section == "SHADERPROGRAMCODE" && name == "parameterCount") {
          if(!readNumber(info->parameterCount)) return false;
          if(debug) COUT << "info->parameterCount = " << info->parameterCount << endl;
         }
       else if(section == "SHADERPROGRAMCODE" && name == "streamCount") {
          if(!readNumber(info->streamCount)) return false;
          if(debug) COUT << "info->streamCount = " << info->streamCount << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 // add child chunks to stack
 scanChildren(node, position, info->chunksize - bytes_read - 4, debug);
 return true;
}

bool Exporter::processSHADERPROGRAMCODEBLOCK(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "------------------------" << endl;
 if(debug) COUT << " SHADERPROGRAMCODEBLOCK " << endl;
 if(debug) COUT << "------------------------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new SHADERPROGRAMCODEBLOCK);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 SHADERPROGRAMCODEBLOCK* info = static_cast<SHADERPROGRAMCODEBLOCK*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes) return error("Property table unexpected.");

 // read chunk data
 unsigned int datasize = info->chunksize - 4;
 info->data.reset(new unsigned char[datasize]);
 ifile.read((char*)info->data.get(), datasize);
 if(ifile.fail()) return error("Read failed.");

 return true;
}

bool Exporter::processSHADERSTREAMDEFINITION(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "------------------------" << endl;
 if(debug) COUT << " SHADERSTREAMDEFINITION " << endl;
 if(debug) COUT << "------------------------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new SHADERSTREAMDEFINITION);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 SHADERSTREAMDEFINITION* info = static_cast<SHADERSTREAMDEFINITION*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");
 
 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "SHADERSTREAMDEFINITION" && name == "renderTypeName") {
          if(!readString(info->renderTypeName)) return false;
          if(debug) COUT << "info->renderTypeName = " << info->renderTypeName << endl;
         }
       else if(section == "SHADERSTREAMDEFINITION" && name == "name") {
          if(!readString(info->name)) return false;
          if(debug) COUT << "info->name = " << info->name << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 return true;
}

bool Exporter::processSKELETON(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "----------" << endl;
 if(debug) COUT << " SKELETON " << endl;
 if(debug) COUT << "----------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new SKELETON);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 SKELETON* info = static_cast<SKELETON*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");
 
 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "SKELETON" && name == "matrixCount") {
          if(!readNumber(info->matrixCount)) return false;
          if(debug) COUT << "info->matrixCount = " << info->matrixCount << endl;
         }
       else if(section == "XXX" && name == "id") {
          if(!readString(info->id)) return false;
          if(debug) COUT << "info->id = " << info->id << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 // add child chunks to stack
 scanChildren(node, position, info->chunksize - bytes_read - 4, debug);
 return true;
};

bool Exporter::processSKINJOINT(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "-----------" << endl;
 if(debug) COUT << " SKINJOINT " << endl;
 if(debug) COUT << "-----------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new SKINJOINT);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 SKINJOINT* info = static_cast<SKINJOINT*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");

 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "SKINJOINT" && name == "joint") {
          if(!readString(info->joint)) return false;
          if(debug) COUT << "info->joint = " << info->joint << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 // add child chunks to stack
 scanChildren(node, position, info->chunksize - bytes_read - 4, debug);
 return true;
}

bool Exporter::processSKINNODE(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "----------" << endl;
 if(debug) COUT << " SKINNODE " << endl;
 if(debug) COUT << "----------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new SKINNODE);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 SKINNODE* info = static_cast<SKINNODE*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");

 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "SKINNODE" && name == "jointCount") {
          if(!readNumber(info->jointCount)) return false;
          if(debug) COUT << "info->jointCount = " << info->jointCount << endl;
         }
       else if(section == "SKINNODE" && name == "skeleton") {
          if(!readString(info->skeleton)) return false;
          if(debug) COUT << "info->skeleton = " << info->skeleton << endl;
         }
       else if(section == "NODE" && name == "stopTraversal") {
          if(!readNumber(info->stopTraversal)) return false;
          if(debug) COUT << "info->stopTraversal = " << info->stopTraversal << endl;
         }
       else if(section == "NODE" && name == "nickname") {
          if(!readString(info->nickname)) return false;
          if(debug) COUT << "info->nickname = " << info->nickname << endl;
         }
       else if(section == "XXX" && name == "id") {
          if(!readString(info->id)) return false;
          if(debug) COUT << "info->id = " << info->id << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 // add child chunks to stack
 scanChildren(node, position, info->chunksize - bytes_read - 4, debug);
 return true;
}

bool Exporter::processTEXTURE(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "---------" << endl;
 if(debug) COUT << " TEXTURE " << endl;
 if(debug) COUT << "---------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new TEXTURE);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 TEXTURE* info = static_cast<TEXTURE*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");

 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "TEXTURE" && name == "width") {
          if(!readNumber(info->width)) return false;
          if(debug) COUT << "info->width = " << info->width << endl;
         }
       else if(section == "TEXTURE" && name == "height") {
          if(!readNumber(info->height)) return false;
          if(debug) COUT << "info->height = " << info->height << endl;
         }
       else if(section == "TEXTURE" && name == "texelFormat") {
          if(!readString(info->texelFormat)) return false;
          if(debug) COUT << "info->texelFormat = " << info->texelFormat << endl;
         }
       else if(section == "TEXTURE" && name == "transient") {
          if(!readNumber(info->transient)) return false;
          if(debug) COUT << "info->transient = " << info->transient << endl;
         }
       else if(section == "TEXTURE" && name == "wrapS") {
          if(!readNumber(info->wrapS)) return false;
          if(debug) COUT << "info->wrapS = " << info->wrapS << endl;
         }
       else if(section == "TEXTURE" && name == "wrapT") {
          if(!readNumber(info->wrapT)) return false;
          if(debug) COUT << "info->wrapT = " << info->wrapT << endl;
         }
       else if(section == "TEXTURE" && name == "wrapR") {
          if(!readNumber(info->wrapR)) return false;
          if(debug) COUT << "info->wrapR = " << info->wrapR << endl;
         }
       else if(section == "TEXTURE" && name == "minFilter") {
          if(!readNumber(info->minFilter)) return false;
          if(debug) COUT << "info->minFilter = " << info->minFilter << endl;
         }
       else if(section == "TEXTURE" && name == "magFilter") {
          if(!readNumber(info->magFilter)) return false;
          if(debug) COUT << "info->magFilter = " << info->magFilter << endl;
         }
       else if(section == "TEXTURE" && name == "automipmap") {
          if(!readNumber(info->automipmap)) return false;
          if(debug) COUT << "info->automipmap = " << info->automipmap << endl;
         }
       else if(section == "TEXTURE" && name == "numberMipMapLevels") {
          if(!readNumber(info->numberMipMapLevels)) return false;
          if(debug) COUT << "info->numberMipMapLevels = " << info->numberMipMapLevels << endl;
         }
       else if(section == "TEXTURE" && name == "gammaRemapR") {
          if(!readNumber(info->gammaRemapR)) return false;
          if(debug) COUT << "info->gammaRemapR = " << info->gammaRemapR << endl;
         }
       else if(section == "TEXTURE" && name == "gammaRemapG") {
          if(!readNumber(info->gammaRemapG)) return false;
          if(debug) COUT << "info->gammaRemapG = " << info->gammaRemapG << endl;
         }
       else if(section == "TEXTURE" && name == "gammaRemapB") {
          if(!readNumber(info->gammaRemapB)) return false;
          if(debug) COUT << "info->gammaRemapB = " << info->gammaRemapB << endl;
         }
       else if(section == "TEXTURE" && name == "gammaRemapA") {
          if(!readNumber(info->gammaRemapA)) return false;
          if(debug) COUT << "info->gammaRemapA = " << info->gammaRemapA << endl;
         }
       else if(section == "TEXTURE" && name == "resolveMSAA") {
          if(!readNumber(info->resolveMSAA)) return false;
          if(debug) COUT << "info->resolveMSAA = " << info->resolveMSAA << endl;
         }
       else if(section == "TEXTURE" && name == "imageBlockCount") {
          if(!readNumber(info->imageBlockCount)) return false;
          if(debug) COUT << "info->imageBlockCount = " << info->imageBlockCount << endl;
         }
       else if(section == "RENDERINTERFACEBOUND" && name == "allocationStrategy") {
          if(!readNumber(info->allocationStrategy)) return false;
          if(debug) COUT << "info->allocationStrategy = " << info->allocationStrategy << endl;
         }
       else if(section == "XXX" && name == "id") {
          if(!readString(info->filename)) return false;
          if(debug) COUT << "info->filename = " << info->filename << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 // add child chunks to stack
 scanChildren(node, position, info->chunksize - bytes_read - 4, debug);
 return true;
}

bool Exporter::processTEXTUREIMAGEBLOCK(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "-------------------" << endl;
 if(debug) COUT << " TEXTUREIMAGEBLOCK " << endl;
 if(debug) COUT << "-------------------" << endl;
 if(debug) COUT << "offset = " << position << endl;
 
 // insert node
 boost::shared_ptr<TREENODE> node(new TEXTUREIMAGEBLOCK);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 TEXTUREIMAGEBLOCK* info = static_cast<TEXTUREIMAGEBLOCK*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");

 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "TEXTUREIMAGEBLOCK" && name == "typename") {
          if(!readString(info->name)) return false;
          if(debug) COUT << "info->name = " << info->name << endl;
         }
       else if(section == "TEXTUREIMAGEBLOCK" && name == "size") {
          if(!readNumber(info->size)) return false;
          if(debug) COUT << "info->size = " << info->size << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 // add child chunks to stack
 scanChildren(node, position, info->chunksize - bytes_read - 4, debug);
 return true;
}

bool Exporter::processTEXTUREIMAGEBLOCKDATA(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "-----------------------" << endl;
 if(debug) COUT << " TEXTUREIMAGEBLOCKDATA " << endl;
 if(debug) COUT << "-----------------------" << endl;
 if(debug) COUT << "offset = " << position << endl;
 
 // insert node
 boost::shared_ptr<TREENODE> node(new TEXTUREIMAGEBLOCKDATA);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 TEXTUREIMAGEBLOCKDATA* info = static_cast<TEXTUREIMAGEBLOCKDATA*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes) return error("Property table unexpected.");

 // save textures?
 bool save_texture = true;
 if(!save_texture) return true;

 // get TEXTUREIMAGEBLOCK
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::iterator tree_iterator;
 tree_iterator parent_ptr = tree.find(parent);
 if(parent_ptr == tree.end()) return error("Expecting TEXTUREIMAGEBLOCKDATA to have TEXTUREIMAGEBLOCK parent.");
 TEXTUREIMAGEBLOCK* tib = static_cast<TEXTUREIMAGEBLOCK*>(parent_ptr->second.get());
 if(!tib) return error("Static cast failed.");

 // get TEXTURE
 parent_ptr = tree.find(tib->parent);
 if(parent_ptr == tree.end()) return error("Expecting TEXTUREIMAGEBLOCK to have TEXTURE parent.");
 TEXTURE* texture = static_cast<TEXTURE*>(parent_ptr->second.get());
 if(!tib) return error("Static cast failed.");

 // read texture data
 info->data.reset(new unsigned char[tib->size]);
 ifile.read((char*)info->data.get(), tib->size);
 if(ifile.fail()) return error("Read failed.");

 // change extension
 string fullpath = "";
 fullpath += filename_param1;
 fullpath += filename_param2;

 // create texture file
 string ofilename = fullpath;
 ofilename += texture->filename;
 ofstream ofile(ofilename.c_str(), ios::binary);
 if(!ofile) return error("Error creating texture file.");

 // determine compression
 bool compressed = false;
 if(texture->texelFormat == "dxt1") compressed = true;
 else if(texture->texelFormat == "dxt2") compressed = true;
 else if(texture->texelFormat == "dxt3") compressed = true;
 else if(texture->texelFormat == "dxt4") compressed = true;
 else if(texture->texelFormat == "dxt5") compressed = true;
 else if(texture->texelFormat == "ui8x4") compressed = false;
 else return error("Invalid texture compression method.");

 // save header
 DWORD dwMagic = 0x20534444;
 DWORD dwSize = 124;
 DWORD dwFlags = DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH | DDSD_PIXELFORMAT;
 if(texture->numberMipMapLevels) dwFlags |= DDSD_MIPMAPCOUNT;
 if(compressed) dwFlags |= DDSD_LINEARSIZE;
 else dwFlags |= DDSD_PITCH;
 DWORD dwHeight = texture->height;
 DWORD dwWidth = texture->width;
 DWORD dwPitchOrLinearSize = texture->width*texture->height;
 if(!compressed) dwPitchOrLinearSize = (texture->width*32 + 7)/8;
 DWORD dwDepth = 0;
 DWORD dwMipMapCount = texture->numberMipMapLevels;
 DWORD dwReserved1[11] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
 DWORD dwSize2 = 32;
 DWORD dwFlags2 = (compressed ? DDPF_FOURCC : DDPF_RGB | DDPF_ALPHAPIXELS);
 DWORD dwFourCC = 0;
 if(texture->texelFormat == "dxt1") dwFourCC = 0x31545844;
 else if(texture->texelFormat == "dxt2") dwFourCC = 0x32545844;
 else if(texture->texelFormat == "dxt3") dwFourCC = 0x33545844;
 else if(texture->texelFormat == "dxt4") dwFourCC = 0x34545844;
 else if(texture->texelFormat == "dxt5") dwFourCC = 0x35545844;
 else dwFourCC = 0;
 DWORD dwRGBBitCount = 0;
 DWORD dwRBitMask = (compressed ? 0 : 0x00ff0000);
 DWORD dwGBitMask = (compressed ? 0 : 0x0000ff00);
 DWORD dwBBitMask = (compressed ? 0 : 0x000000ff);
 DWORD dwABitMask = (compressed ? 0 : 0xff000000);
 DWORD dwCaps = DDSCAPS_TEXTURE;
 if(texture->numberMipMapLevels) dwCaps |= DDSCAPS_COMPLEX | DDSCAPS_MIPMAP;
 DWORD dwCaps2 = 0;
 DWORD dwCaps3 = 0;
 DWORD dwCaps4 = 0;
 DWORD dwReserved2 = 0;
 ofile.write((char*)&dwMagic, sizeof(dwMagic));
 ofile.write((char*)&dwSize, sizeof(dwSize));
 ofile.write((char*)&dwFlags, sizeof(dwFlags));
 ofile.write((char*)&dwHeight, sizeof(dwHeight));
 ofile.write((char*)&dwWidth, sizeof(dwWidth));
 ofile.write((char*)&dwPitchOrLinearSize, sizeof(dwPitchOrLinearSize));
 ofile.write((char*)&dwDepth, sizeof(dwDepth));
 ofile.write((char*)&dwMipMapCount, sizeof(dwMipMapCount));
 ofile.write((char*)&dwReserved1[0], 11*sizeof(DWORD));
 ofile.write((char*)&dwSize2, sizeof(dwSize2));
 ofile.write((char*)&dwFlags2, sizeof(dwFlags2));
 ofile.write((char*)&dwFourCC, sizeof(dwFourCC));
 ofile.write((char*)&dwRGBBitCount, sizeof(dwRGBBitCount));
 ofile.write((char*)&dwRBitMask, sizeof(dwRBitMask));
 ofile.write((char*)&dwGBitMask, sizeof(dwGBitMask));
 ofile.write((char*)&dwBBitMask, sizeof(dwBBitMask));
 ofile.write((char*)&dwABitMask, sizeof(dwABitMask));
 ofile.write((char*)&dwCaps, sizeof(dwCaps));
 ofile.write((char*)&dwCaps2, sizeof(dwCaps2));
 ofile.write((char*)&dwCaps3, sizeof(dwCaps3));
 ofile.write((char*)&dwCaps4, sizeof(dwCaps4));
 ofile.write((char*)&dwReserved2, sizeof(dwReserved2));

 // save data
 ofile.write((char*)info->data.get(), tib->size);

 return true;
}

bool Exporter::processTRANSFORM(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "-----------" << endl;
 if(debug) COUT << " TRANSFORM " << endl;
 if(debug) COUT << "-----------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new TRANSFORM);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 TRANSFORM* info = static_cast<TRANSFORM*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes) return error("Property table unexpected.");
 
 // read transform
 ifile.read((char*)&info->matrix[0], 16*sizeof(float));
 for(size_t i = 0; i < 16; i++) {
     reverse_byte_order(&info->matrix[i]);
     if(debug) COUT << "info->matrix[" << i << "] = " << info->matrix[i] << endl;
    }

 return true;
}

bool Exporter::processTYPEINFO(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "----------" << endl;
 if(debug) COUT << " TYPEINFO " << endl;
 if(debug) COUT << "----------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new TYPEINFO);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 TYPEINFO* info = static_cast<TYPEINFO*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");
 
 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "TYPEINFO" && name == "typeName") {
          if(!readString(info->typeName)) return false;
          if(debug) COUT << "info->typeName = " << info->typeName << endl;
         }
       else if(section == "TYPEINFO" && name == "typeCount") {
          if(!readNumber(info->typeCount)) return false;
          if(debug) COUT << "info->typeCount = " << info->typeCount << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 return true;
}

bool Exporter::processUSERATTRIBUTE(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "---------------" << endl;
 if(debug) COUT << " USERATTRIBUTE " << endl;
 if(debug) COUT << "---------------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new USERATTRIBUTE);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 USERATTRIBUTE* info = static_cast<USERATTRIBUTE*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");

 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "USERATTRIBUTE" && name == "type") {
          if(!readString(info->type)) return false;
          if(debug) COUT << "info->type = " << info->type << endl;
         }
       else if(section == "USERATTRIBUTE" && name == "semantic") {
          if(!readString(info->semantic)) return false;
          if(debug) COUT << "info->semantic = " << info->semantic << endl;
         }
       else if(section == "USERATTRIBUTE" && name == "svalue") {
          if(!readString(info->svalue)) return false;
          if(debug) COUT << "info->svalue = " << info->svalue << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 return true;
}

bool Exporter::processUSERATTRIBUTELIST(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "-------------------" << endl;
 if(debug) COUT << " USERATTRIBUTELIST " << endl;
 if(debug) COUT << "-------------------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new USERATTRIBUTELIST);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 USERATTRIBUTELIST* info = static_cast<USERATTRIBUTELIST*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");
 
 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "USERATTRIBUTELIST" && name == "count") {
          if(!readNumber(info->count)) return false;
          if(debug) COUT << "info->count = " << info->count << endl;
         }
       else if(section == "XXX" && name == "id") {
          if(!readString(info->id)) return false;
          if(debug) COUT << "info->id = " << info->id << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 // add child chunks to stack
 scanChildren(node, position, info->chunksize - bytes_read - 4, debug);
 return true;
}

bool Exporter::processUSERDATA(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "----------" << endl;
 if(debug) COUT << " USERDATA " << endl;
 if(debug) COUT << "----------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 // insert node
 boost::shared_ptr<TREENODE> node(new USERDATA);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 USERDATA* info = static_cast<USERDATA*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");
 
 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "USERDATA" && name == "object") {
          if(!readString(info->object)) return false;
          if(debug) COUT << "info->object = " << info->object << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 return true;
}

bool Exporter::processWEIGHTS(unsigned int chunktype, unsigned int position)
{
 bool debug = true;
 if(debug) COUT << endl;
 if(debug) COUT << "---------" << endl;
 if(debug) COUT << " WEIGHTS " << endl;
 if(debug) COUT << "---------" << endl;
 if(debug) COUT << "offset = " << position << endl;

 struct WEIGHTS : public TREENODE {
 };
 
 // insert node
 boost::shared_ptr<TREENODE> node(new WEIGHTS);
 typedef map<unsigned int, boost::shared_ptr<TREENODE>>::value_type value_type;
 tree.insert(value_type(position, node));

 // set parent
 unsigned int parent = 0;
 map<unsigned int, unsigned int>::iterator iter = parent_list.find(position);
 if(iter != parent_list.end()) parent = iter->second;
 if(debug) COUT << "parent = " << parent << endl;
 node->parent = parent;

 // read chunk properties
 WEIGHTS* info = static_cast<WEIGHTS*>(node.get());
 info->chunktype = chunktype;
 info->chunksize = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 info->propbytes = BE_read_uint32(ifile); if(ifile.fail()) return error("Read failed.");
 if(debug) COUT << "chunktype = " << info->chunktype << endl;
 if(debug) COUT << "chunksize = " << info->chunksize << endl;
 if(debug) COUT << "propbytes = " << info->propbytes << endl;

 // validate
 if(info->propbytes > 1000) return error("Unexpected number of property table bytes.");
 if(info->propbytes == 0) return error("Property table expected.");

 // read properties
 unsigned int bytes_read = 0;
 while(bytes_read < info->propbytes)
      {
       // read index
       unsigned int type = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
      
       // data bytes
       unsigned int size = BE_read_uint32(ifile);
       if(ifile.fail()) return error("Read failed.");
       bytes_read += 4;
       bytes_read += size;
      
       // find index
       typedef map<unsigned int, GAME_PROPERTY>::iterator iterator;
       iterator iter = properties.find(type);
       if(iter == properties.end()) {
          stringstream ss;
          ss << "Failed to find property for index " << type << "." << ends;
          return error(ss.str().c_str());
         }
      
       // aliases
       const string& section = iter->second.section;
       const string& name = iter->second.name;

       if(section == "WEIGHTS" && name == "NEVERUSED") {
          //if(!readString(info->NEVERUSED)) return false;
          //if(debug) COUT << "info->NEVERUSED = " << info->NEVERUSED << endl;
         }
       else if(section == "WEIGHTS" && name == "NEVERUSED") {
          //if(!readString(info->NEVERUSED)) return false;
          //if(debug) COUT << "info->NEVERUSED = " << info->NEVERUSED << endl;
         }
       else if(section == "WEIGHTS" && name == "NEVERUSED") {
          //if(!readString(info->NEVERUSED)) return false;
          //if(debug) COUT << "info->NEVERUSED = " << info->NEVERUSED << endl;
         }
       else {
          stringstream ss;
          ss << "Unknown block property " << section << ":" << name << "." << ends;
          return error(ss.str().c_str());
         }
      }

 // add child chunks to stack
 scanChildren(node, position, info->chunksize - bytes_read - 4, debug);
 return error("WEIGHTS not implemented.");
}