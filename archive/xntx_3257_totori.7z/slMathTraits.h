#ifndef __SL_MATH_TRAITS_H
#define __SL_MATH_TRAITS_H

namespace sl {

template<class T>
struct math_traits {
 public :
  static T pi(void)        { return (T)(3.14159265358979323846264338328); }
  static T pi_over_2(void) { return (T)(1.57079632679489661923132169164); }
  static T pi_over_4(void) { return (T)(0.78539816339744830961566084582); }
  static T zero(void) { return T(0.0); }
  static T one(void)  { return T(1.0); }
  static T two(void)  { return T(2.0); }
 public :
  static T neg_pi(void)        { return (T)(-3.14159265358979323846264338328); }
  static T neg_pi_over_2(void) { return (T)(-1.57079632679489661923132169164); }
  static T neg_pi_over_4(void) { return (T)(-0.78539816339744830961566084582); }
  static T neg_one(void)  { return T(-1.0); }
  static T neg_two(void)  { return T(-2.0); }
 public :
  static T small_value(void) { return (T)(1.0e-6); }
  static T neg_small_value(void) { return (T)(-1.0e-6); }
  static bool is_small(T x) { return ((x > neg_small_value()) && (x < small_value())); }
  static bool is_close(T x, T y) { return is_small(x - y); }
};

// TODO:
// SPECIALIZE FOR FLOAT
// SPECIALIZE FOR DOUBLE
// SPECIALIZE FOR LONG DOUBLE

};

#endif
