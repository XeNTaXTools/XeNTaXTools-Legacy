﻿
using System;
using System.Runtime.CompilerServices;
using System.Text;

internal class b : Encoding
{
  [SpecialName]
  public override string get_WebName()
  {
    return "GBK";
  }

  [SpecialName]
  public static int b()
  {
    return 7426;
  }

  public override int GetBytes(char[] chars, int charIndex, int charCount, byte[] bytes, int byteIndex)
  {
    throw new NotImplementedException();
  }

  public override int GetChars(byte[] bytes, int byteIndex, int byteCount, char[] chars, int charIndex)
  {
    int index1 = 0;
    int index2 = 0;
    while (index2 < byteCount)
    {
      if (index2 + 1 >= bytes.Length)
      {
        char[] chars1 = Encoding.UTF8.GetChars(new byte[1]
        {
          bytes[index2]
        });
        chars[index1] = chars1[0];
      }
      else
      {
        byte[] A_0 = new byte[2]
        {
          bytes[index2],
          bytes[index2 + 1]
        };
        char A_1 = char.MinValue;
        if (a.a(A_0, out A_1))
        {
          chars[index1] = A_1;
          ++index1;
        }
        else
        {
          char[] chars1 = Encoding.UTF8.GetChars(new byte[1]
          {
            A_0[1]
          });
          chars[index1] = chars1[0];
          int index3 = index1 + 1;
          if (index2 + 2 >= bytes.Length)
          {
            char[] chars2 = Encoding.UTF8.GetChars(new byte[1]
            {
              A_0[0]
            });
            chars[index3] = chars2[0];
            index1 = index3 + 1;
          }
          else if (a.a(new byte[2]
          {
            A_0[0],
            bytes[index2 + 2]
          }, out A_1))
          {
            chars[index3] = A_1;
            index1 = index3 + 1;
            ++index2;
          }
          else
          {
            char[] chars2 = Encoding.UTF8.GetChars(new byte[1]
            {
              A_0[0]
            });
            chars[index3] = chars2[0];
            index1 = index3 + 1;
          }
        }
      }
      index2 += 2;
    }
    return chars.Length;
  }

  public override int GetByteCount(char[] chars, int index, int count)
  {
    return count;
  }

  public override int GetCharCount(byte[] bytes, int index, int count)
  {
    return count;
  }

  public override int GetMaxByteCount(int charCount)
  {
    return charCount;
  }

  public override int GetMaxCharCount(int byteCount)
  {
    return byteCount;
  }
}
