﻿using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: Extension]
[assembly: Dotfuscator("241404:0:0:5.34.0.6830", 0)]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyCompany("Launcher")]
[assembly: AssemblyInformationalVersion("1.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyProduct("Launcher")]
[assembly: AssemblyTitle("Launcher")]
[assembly: AssemblyVersion("1.0.0.0")]
