﻿
using System;
using System.IO;

public static class MiniLZO
{
  private static readonly uint j = 65539;
  private const byte a = 14;
  private const uint b = 16383;
  private const uint c = 8;
  private const uint d = 2048;
  private const byte e = 32;
  private const uint f = 16384;
  private const byte g = 16;
  private const uint h = 9;
  private const uint i = 49151;

  static MiniLZO()
  {
    if (IntPtr.Size == 8)
      MiniLZO.j = 131078U;
    else
      MiniLZO.j = 65539U;
  }

  public static byte[] Compress(this byte[] src)
  {
    return src.Compress(0, src.Length);
  }

  public static byte[] Compress(this byte[] src, int srcCount)
  {
    return src.Compress(0, srcCount);
  }

  public static byte[] Compress(this byte[] src, int srcStart, int srcLength)
  {
    uint A_5 = (uint) (srcLength + srcLength / 16 + 64 + 3 + 4);
    byte[] A_3 = new byte[(int) A_5];
    uint num = MiniLZO.a(src, (uint) srcStart, (uint) srcLength, A_3, 0U, A_5, (uint[]) null);
    if ((long) A_3.Length != (long) num)
    {
      byte[] numArray = new byte[(int) num];
      Buffer.BlockCopy((Array) A_3, 0, (Array) numArray, 0, (int) num);
      A_3 = numArray;
    }
    return A_3;
  }

  public static byte[] Compress(this MemoryStream source)
  {
    byte[] buffer = source.GetBuffer();
    int capacity = source.Capacity;
    uint length = (uint) source.Length;
    uint A_5 = (uint) ((int) length + (int) (length / 16U) + 64 + 3 + 4);
    int num1 = (int) length;
    uint num2 = (uint) (capacity - num1);
    uint num3 = (uint) ((int) Math.Min(length, 49151U) + (int) (length / 64U) + 16 + 3 + 4);
    uint A_1;
    byte[] A_3;
    if (num2 < num3)
    {
      A_1 = 0U;
      A_3 = new byte[(int) A_5];
    }
    else
    {
      A_1 = num3;
      source.SetLength((long) (length + num3));
      A_3 = buffer;
      Buffer.BlockCopy((Array) A_3, 0, (Array) A_3, (int) num3, (int) length);
      uint num4 = num2 - num3;
    }
    uint num5 = MiniLZO.a(buffer, A_1, length, A_3, 0U, A_5, (uint[]) null);
    if (A_3 == buffer)
    {
      source.SetLength((long) num5);
      source.Capacity = (int) num5;
      return source.GetBuffer();
    }
    byte[] numArray = new byte[(int) num5];
    Buffer.BlockCopy((Array) A_3, 0, (Array) numArray, 0, (int) num5);
    return numArray;
  }

  public static byte[] Decompress(this byte[] src)
  {
    byte[] numArray = new byte[(int) src[src.Length - 4] | (int) src[src.Length - 3] << 8 | ((int) src[src.Length - 2] << 16 | (int) src[src.Length - 1] << 24)];
    uint num1 = 0;
    uint num2 = 0;
    uint num3 = (uint) (src.Length - 4);
    uint length = (uint) numArray.Length;
    uint A_1 = 0;
    uint num4 = 0;
    bool flag1 = false;
    bool flag2 = false;
    bool flag3 = false;
    bool flag4 = false;
    bool flag5 = false;
    bool flag6 = false;
    if (src[(int) A_1] > (byte) 17)
    {
      num1 = (uint) src[(int) A_1] - 17U;
      ++A_1;
      if (num1 < 4U)
      {
        flag2 = true;
      }
      else
      {
        if (length - num4 < num1)
          throw new OverflowException("Output Overrun");
        if (num3 - A_1 < num1 + 1U)
          throw new OverflowException("Input Overrun");
        do
        {
          numArray[(int) num4] = src[(int) A_1];
          ++num4;
          ++A_1;
        }
        while (--num1 != 0U);
        flag5 = true;
      }
    }
    while (!flag6 && A_1 < num3)
    {
      if (!flag2 && !flag5)
      {
        num1 = (uint) src[(int) A_1];
        ++A_1;
        if (num1 >= 16U)
        {
          flag1 = true;
        }
        else
        {
          if (num1 == 0U)
          {
            if (num3 - A_1 < 1U)
              throw new OverflowException("Input Overrun");
            while (src[(int) A_1] == (byte) 0)
            {
              num1 += (uint) byte.MaxValue;
              ++A_1;
              if (num3 - A_1 < 1U)
                throw new OverflowException("Input Overrun");
            }
            num1 += 15U + (uint) src[(int) A_1];
            ++A_1;
          }
          if (length - num4 < num1 + 3U)
            throw new OverflowException("Output Overrun");
          if (num3 - A_1 < num1 + 4U)
            throw new OverflowException("Input Overrun");
          int num5 = 0;
          while (num5 < 4)
          {
            numArray[(int) num4] = src[(int) A_1];
            ++num5;
            ++num4;
            ++A_1;
          }
          if (--num1 != 0U)
          {
            if (num1 >= 4U)
            {
              do
              {
                int num6 = 0;
                while (num6 < 4)
                {
                  numArray[(int) num4] = src[(int) A_1];
                  ++num6;
                  ++num4;
                  ++A_1;
                }
                num1 -= 4U;
              }
              while (num1 >= 4U);
              if (num1 != 0U)
              {
                do
                {
                  numArray[(int) num4] = src[(int) A_1];
                  ++num4;
                  ++A_1;
                }
                while (--num1 != 0U);
              }
            }
            else
            {
              do
              {
                numArray[(int) num4] = src[(int) A_1];
                ++num4;
                ++A_1;
              }
              while (--num1 != 0U);
            }
          }
        }
      }
      if (!flag1 && !flag2)
      {
        flag5 = false;
        num1 = (uint) src[(int) A_1];
        ++A_1;
        if (num1 < 16U)
        {
          uint num5 = num4 - 2049U - (num1 >> 2) - ((uint) src[(int) A_1] << 2);
          ++A_1;
          if (num5 < 0U || num5 >= num4)
            throw new OverflowException("Lookbehind Overrun");
          if (length - num4 < 3U)
            throw new OverflowException("Output Overrun");
          numArray[(int) num4] = numArray[(int) num5];
          uint num6 = num4 + 1U;
          uint num7 = num5 + 1U;
          numArray[(int) num6] = numArray[(int) num7];
          uint num8 = num6 + 1U;
          uint num9 = num7 + 1U;
          numArray[(int) num8] = numArray[(int) num9];
          num4 = num8 + 1U;
          num2 = num9 + 1U;
          flag3 = true;
        }
      }
      flag1 = false;
label_44:
      uint num10;
      if (num1 >= 64U)
      {
        num10 = num4 - 1U - (num1 >> 2 & 7U) - ((uint) src[(int) A_1] << 3);
        ++A_1;
        num1 = (num1 >> 5) - 1U;
        if (num10 < 0U || num10 >= num4)
          throw new OverflowException("Lookbehind Overrun");
        if (length - num4 < num1 + 2U)
          throw new OverflowException("Output Overrun");
        flag4 = true;
      }
      else if (num1 >= 32U)
      {
        num1 &= 31U;
        if (num1 == 0U)
        {
          if (num3 - A_1 < 1U)
            throw new OverflowException("Input Overrun");
          while (src[(int) A_1] == (byte) 0)
          {
            num1 += (uint) byte.MaxValue;
            ++A_1;
            if (num3 - A_1 < 1U)
              throw new OverflowException("Input Overrun");
          }
          num1 += 31U + (uint) src[(int) A_1];
          ++A_1;
        }
        num10 = num4 - 1U - ((uint) MiniLZO.a(src, A_1) >> 2);
        A_1 += 2U;
      }
      else if (num1 >= 16U)
      {
        uint num5 = num4 - (uint) (((int) num1 & 8) << 11);
        num1 &= 7U;
        if (num1 == 0U)
        {
          if (num3 - A_1 < 1U)
            throw new OverflowException("Input Overrun");
          while (src[(int) A_1] == (byte) 0)
          {
            num1 += (uint) byte.MaxValue;
            ++A_1;
            if (num3 - A_1 < 1U)
              throw new OverflowException("Input Overrun");
          }
          num1 += 7U + (uint) src[(int) A_1];
          ++A_1;
        }
        num10 = num5 - ((uint) MiniLZO.a(src, A_1) >> 2);
        A_1 += 2U;
        if ((int) num10 == (int) num4)
          flag6 = true;
        else
          num10 -= 16384U;
      }
      else
      {
        uint num5 = num4 - 1U - (num1 >> 2) - ((uint) src[(int) A_1] << 2);
        ++A_1;
        if (num5 < 0U || num5 >= num4)
          throw new OverflowException("Lookbehind Overrun");
        if (length - num4 < 2U)
          throw new OverflowException("Output Overrun");
        numArray[(int) num4] = numArray[(int) num5];
        uint num6 = num4 + 1U;
        uint num7 = num5 + 1U;
        numArray[(int) num6] = numArray[(int) num7];
        num4 = num6 + 1U;
        num10 = num7 + 1U;
        flag3 = true;
      }
      if (!flag6 && !flag3 && !flag4)
      {
        if (num10 < 0U || num10 >= num4)
          throw new OverflowException("Lookbehind Overrun");
        if (length - num4 < num1 + 2U)
          throw new OverflowException("Output Overrun");
      }
      if (!flag6 && num1 >= 6U && (num4 - num10 >= 4U && !flag3) && !flag4)
      {
        int num5 = 0;
        while (num5 < 4)
        {
          numArray[(int) num4] = numArray[(int) num10];
          ++num5;
          ++num4;
          ++num10;
        }
        num1 -= 2U;
        do
        {
          int num6 = 0;
          while (num6 < 4)
          {
            numArray[(int) num4] = numArray[(int) num10];
            ++num6;
            ++num4;
            ++num10;
          }
          num1 -= 4U;
        }
        while (num1 >= 4U);
        if (num1 != 0U)
        {
          do
          {
            numArray[(int) num4] = numArray[(int) num10];
            ++num4;
            ++num10;
          }
          while (--num1 != 0U);
        }
      }
      else if (!flag6 && !flag3)
      {
        flag4 = false;
        numArray[(int) num4] = numArray[(int) num10];
        uint num5 = num4 + 1U;
        uint num6 = num10 + 1U;
        numArray[(int) num5] = numArray[(int) num6];
        num4 = num5 + 1U;
        uint num7 = num6 + 1U;
        do
        {
          numArray[(int) num4] = numArray[(int) num7];
          ++num4;
          ++num7;
        }
        while (--num1 != 0U);
      }
      if (!flag6 && !flag2)
      {
        flag3 = false;
        num1 = (uint) src[(int) A_1 - 2] & 3U;
        if (num1 == 0U)
          continue;
      }
      if (!flag6)
      {
        flag2 = false;
        if (length - num4 < num1)
          throw new OverflowException("Output Overrun");
        if (num3 - A_1 < num1 + 1U)
          throw new OverflowException("Input Overrun");
        numArray[(int) num4] = src[(int) A_1];
        ++num4;
        uint num5 = A_1 + 1U;
        if (num1 > 1U)
        {
          numArray[(int) num4] = src[(int) num5];
          ++num4;
          ++num5;
          if (num1 > 2U)
          {
            numArray[(int) num4] = src[(int) num5];
            ++num4;
            ++num5;
          }
        }
        num1 = (uint) src[(int) num5];
        A_1 = num5 + 1U;
      }
      if (!flag6 && A_1 < num3)
        goto label_44;
    }
    if (!flag6)
      throw new OverflowException("EOF Marker Not Found");
    if (A_1 > num3)
      throw new OverflowException("Input Overrun");
    if (A_1 < num3)
      throw new OverflowException("Input Not Consumed");
    return numArray;
  }

  private static uint a(byte[] A_0, uint A_1, uint A_2, byte[] A_3, uint A_4, uint A_5, uint[] A_6)
  {
    if (A_6 == null)
      A_6 = new uint[(int) MiniLZO.j];
    uint num1;
    if (A_2 <= 13U)
    {
      num1 = A_2;
      A_5 = 0U;
    }
    else
    {
      uint num2 = A_1 + A_2;
      uint num3 = (uint) ((int) A_1 + (int) A_2 - 8 - 5);
      uint num4 = A_1;
      uint A_1_1 = A_1 + 4U;
      uint num5 = A_4;
      bool flag1 = false;
      bool flag2 = false;
      do
      {
        uint num6 = 0;
        uint A_0_1 = MiniLZO.b(A_0, A_1_1);
        uint A_1_2 = A_1_1 - (A_1_1 - A_6[(int) A_0_1]);
        if (A_1_2 < A_1 || (num6 = A_1_1 - A_1_2) == 0U || num6 > 49151U)
          flag1 = true;
        else if (num6 > 2048U && (int) A_0[(int) A_1_2 + 3] != (int) A_0[(int) A_1_1 + 3])
        {
          A_0_1 = MiniLZO.a(A_0_1);
          A_1_2 = A_1_1 - (A_1_1 - A_6[(int) A_0_1]);
          if (A_1_2 < A_1 || (num6 = A_1_1 - A_1_2) == 0U || num6 > 49151U)
            flag1 = true;
          else if (num6 > 2048U && (int) A_0[(int) A_1_2 + 3] != (int) A_0[(int) A_1_1 + 3])
            flag1 = true;
        }
        if (!flag1 && (int) MiniLZO.a(A_0, A_1_2) == (int) MiniLZO.a(A_0, A_1_1) && (int) A_0[(int) A_1_2 + 2] == (int) A_0[(int) A_1_1 + 2])
          flag2 = true;
        flag1 = false;
        if (!flag2)
        {
          A_6[(int) A_0_1] = A_1_1;
          ++A_1_1;
          if (A_1_1 >= num3)
            break;
        }
        else
        {
          flag2 = false;
          A_6[(int) A_0_1] = A_1_1;
          if ((int) A_1_1 - (int) num4 != 0)
          {
            uint num7 = A_1_1 - num4;
            if (num7 <= 3U)
              A_3[(int) num5 - 2] |= (byte) num7;
            else if (num7 <= 18U)
            {
              A_3[(int) num5] = (byte) (num7 - 3U);
              ++num5;
            }
            else
            {
              uint num8 = num7 - 18U;
              A_3[(int) num5] = (byte) 0;
              uint num9 = num5 + 1U;
              while (num8 > (uint) byte.MaxValue)
              {
                num8 -= (uint) byte.MaxValue;
                A_3[(int) num9] = (byte) 0;
                ++num9;
              }
              A_3[(int) num9] = (byte) num8;
              num5 = num9 + 1U;
            }
            do
            {
              A_3[(int) num5] = A_0[(int) num4];
              ++num5;
              ++num4;
            }
            while (--num7 != 0U);
          }
          uint num10 = A_1_1 + 3U;
          int num11 = (int) A_0[(int) A_1_2 + 3];
          byte[] numArray = A_0;
          int index1 = (int) num10;
          A_1_1 = (uint) (index1 + 1);
          int num12 = (int) numArray[index1];
          if (num11 != num12 || (int) A_0[(int) A_1_2 + 4] != (int) A_0[(int) A_1_1++] || ((int) A_0[(int) A_1_2 + 5] != (int) A_0[(int) A_1_1++] || (int) A_0[(int) A_1_2 + 6] != (int) A_0[(int) A_1_1++]) || ((int) A_0[(int) A_1_2 + 7] != (int) A_0[(int) A_1_1++] || (int) A_0[(int) A_1_2 + 8] != (int) A_0[(int) A_1_1++]))
          {
            --A_1_1;
            uint num7 = A_1_1 - num4;
            if (num6 <= 2048U)
            {
              uint num8 = num6 - 1U;
              A_3[(int) num5] = (byte) ((int) num7 - 1 << 5 | ((int) num8 & 7) << 2);
              uint num9 = num5 + 1U;
              A_3[(int) num9] = (byte) (num8 >> 3);
              num5 = num9 + 1U;
            }
            else if (num6 <= 16384U)
            {
              uint num8 = num6 - 1U;
              A_3[(int) num5] = (byte) (32 | (int) num7 - 2);
              uint num9 = num5 + 1U;
              A_3[(int) num9] = (byte) (((int) num8 & 63) << 2);
              uint num13 = num9 + 1U;
              A_3[(int) num13] = (byte) (num8 >> 6);
              num5 = num13 + 1U;
            }
            else
            {
              uint num8 = num6 - 16384U;
              A_3[(int) num5] = (byte) (16 | (int) ((num8 & 16384U) >> 11) | (int) num7 - 2);
              uint num9 = num5 + 1U;
              A_3[(int) num9] = (byte) (((int) num8 & 63) << 2);
              uint num13 = num9 + 1U;
              A_3[(int) num13] = (byte) (num8 >> 6);
              num5 = num13 + 1U;
            }
          }
          else
          {
            for (uint index2 = (uint) ((int) A_1_2 + 8 + 1); A_1_1 < num2 && (int) A_0[(int) index2] == (int) A_0[(int) A_1_1]; ++A_1_1)
              ++index2;
            uint num7 = A_1_1 - num4;
            uint num8;
            uint num9;
            if (num6 <= 16384U)
            {
              num8 = num6 - 1U;
              if (num7 <= 33U)
              {
                A_3[(int) num5] = (byte) (32 | (int) num7 - 2);
                num9 = num5 + 1U;
              }
              else
              {
                uint num13 = num7 - 33U;
                A_3[(int) num5] = (byte) 32;
                uint num14 = num5 + 1U;
                while (num13 > (uint) byte.MaxValue)
                {
                  num13 -= (uint) byte.MaxValue;
                  A_3[(int) num14] = (byte) 0;
                  ++num14;
                }
                A_3[(int) num14] = (byte) num13;
                num9 = num14 + 1U;
              }
            }
            else
            {
              num8 = num6 - 16384U;
              if (num7 <= 9U)
              {
                A_3[(int) num5] = (byte) (16 | (int) ((num8 & 16384U) >> 11) | (int) num7 - 2);
                num9 = num5 + 1U;
              }
              else
              {
                uint num13 = num7 - 9U;
                A_3[(int) num5] = (byte) (16U | (num8 & 16384U) >> 11);
                uint num14 = num5 + 1U;
                while (num13 > (uint) byte.MaxValue)
                {
                  num13 -= (uint) byte.MaxValue;
                  A_3[(int) num14] = (byte) 0;
                  ++num14;
                }
                A_3[(int) num14] = (byte) num13;
                num9 = num14 + 1U;
              }
            }
            A_3[(int) num9] = (byte) (((int) num8 & 63) << 2);
            uint num15 = num9 + 1U;
            A_3[(int) num15] = (byte) (num8 >> 6);
            num5 = num15 + 1U;
          }
          num4 = A_1_1;
        }
      }
      while (A_1_1 < num3);
      A_5 = num5 - A_4;
      num1 = num2 - num4;
    }
    if (num1 != 0U)
    {
      uint num2 = A_2 - num1 + A_1;
      if (A_5 == 0U && num1 <= 238U)
        A_3[(int) A_5++] = (byte) (17U + num1);
      else if (num1 <= 3U)
        A_3[(int) A_5 - 2] |= (byte) num1;
      else if (num1 <= 18U)
      {
        A_3[(int) A_5++] = (byte) (num1 - 3U);
      }
      else
      {
        uint num3 = num1 - 18U;
        A_3[(int) A_5++] = (byte) 0;
        while (num3 > (uint) byte.MaxValue)
        {
          num3 -= (uint) byte.MaxValue;
          A_3[(int) A_5++] = (byte) 0;
        }
        A_3[(int) A_5++] = (byte) num3;
      }
      do
      {
        A_3[(int) A_5++] = A_0[(int) num2++];
      }
      while (--num1 != 0U);
    }
    A_3[(int) A_5++] = (byte) 17;
    A_3[(int) A_5++] = (byte) 0;
    A_3[(int) A_5++] = (byte) 0;
    A_3[(int) A_5++] = (byte) A_2;
    A_3[(int) A_5++] = (byte) (A_2 >> 8);
    A_3[(int) A_5++] = (byte) (A_2 >> 16);
    A_3[(int) A_5++] = (byte) (A_2 >> 24);
    return A_5;
  }

  private static uint a(byte[] A_0, int A_1)
  {
    return MiniLZO.a(MiniLZO.a(33U, MiniLZO.a(A_0, A_1, (byte) 5, (byte) 5, (byte) 6)) >> 5, (byte) 0);
  }

  private static uint b(byte[] A_0, uint A_1)
  {
    byte num1 = A_0[(int) A_1 + 2];
    byte num2 = A_0[(int) A_1 + 1];
    byte num3 = A_0[(int) A_1];
    return 16383U & ((uint) (33 * ((((int) num1 << 6 ^ (int) num2) << 5 ^ (int) num3) << 5)) ^ (uint) num3) >> 5;
  }

  private static uint a(uint A_0)
  {
    return (uint) ((int) A_0 & 2047 ^ 8223);
  }

  private static uint a(uint A_0, byte A_1)
  {
    return (A_0 & 16383U >> (int) A_1) << (int) A_1;
  }

  private static uint a(uint A_0, uint A_1)
  {
    return A_0 * A_1;
  }

  private static uint a(byte[] A_0, int A_1, byte A_2, byte A_3)
  {
    return ((uint) A_0[A_1 + 2] << (int) A_3 ^ (uint) A_0[A_1 + 1]) << (int) A_2 ^ (uint) A_0[A_1];
  }

  private static uint a(byte[] A_0, int A_1, byte A_2, byte A_3, byte A_4)
  {
    return MiniLZO.a(A_0, A_1 + 1, A_3, A_4) << (int) A_2 ^ (uint) A_0[A_1];
  }

  private static uint a(byte[] A_0, uint A_1, byte A_2, byte A_3)
  {
    return ((uint) A_0[(int) A_1 + 2] << (int) A_3 ^ (uint) A_0[(int) A_1 + 1]) << (int) A_2 ^ (uint) A_0[(int) A_1];
  }

  private static uint a(byte[] A_0, uint A_1, byte A_2, byte A_3, byte A_4)
  {
    return MiniLZO.a(A_0, A_1 + 1U, A_3, A_4) << (int) A_2 ^ (uint) A_0[(int) A_1];
  }

  private static ushort a(byte[] A_0, uint A_1)
  {
    return (ushort) ((uint) A_0[(int) A_1] + (uint) A_0[(int) A_1 + 1] * 256U);
  }
}
