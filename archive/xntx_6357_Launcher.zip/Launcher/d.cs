﻿
using System.Runtime.CompilerServices;

[CompilerGenerated]
internal sealed class d
{
  internal static readonly long a;
}
