﻿using System;
using System.Runtime.InteropServices;

[AttributeUsage(AttributeTargets.Assembly)]
[ComVisible(false)]
public sealed class DotfuscatorAttribute : Attribute
{
  private string a;
  private int c;

  public DotfuscatorAttribute(string a, int c)
  {
    DotfuscatorAttribute dotfuscatorAttribute = this;
    // ISSUE: explicit constructor call
    dotfuscatorAttribute.\u002Ector();
    dotfuscatorAttribute.a = a;
    this.c = c;
  }

  public string a()
  {
    return this.a;
  }

  public string A
  {
    get
    {
      return this.a;
    }
  }

  public int c()
  {
    return this.c;
  }

  public int C
  {
    get
    {
      return this.c;
    }
  }
}
