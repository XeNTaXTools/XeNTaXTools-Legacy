﻿
using System;
using System.Security.Cryptography;

namespace Delay
{
  public class MD5Managed : HashAlgorithm
  {
    private static byte[] u = new byte[64];
    private readonly MD5Managed.a a = new MD5Managed.a();
    private readonly byte[] b = new byte[16];
    private bool c;
    private bool d;
    private const int e = 7;
    private const int f = 12;
    private const int g = 17;
    private const int h = 22;
    private const int i = 5;
    private const int j = 9;
    private const int k = 14;
    private const int l = 20;
    private const int m = 4;
    private const int n = 11;
    private const int o = 16;
    private const int p = 23;
    private const int q = 6;
    private const int r = 10;
    private const int s = 15;
    private const int t = 21;

    public MD5Managed()
    {
      this.a();
    }

    public override void Initialize()
    {
      this.a();
    }

    private void a()
    {
      MD5Managed.a(this.a);
      this.c = false;
      this.d = false;
    }

    protected override void HashCore(byte[] array, int ibStart, int cbSize)
    {
      if (array == null)
        throw new ArgumentNullException(nameof (array));
      if (this.d)
        throw new CryptographicException("Hash not valid for use in specified state.");
      this.c = true;
      MD5Managed.a(this.a, array, (uint) ibStart, (uint) cbSize);
    }

    protected override byte[] HashFinal()
    {
      this.d = true;
      MD5Managed.a(this.b, this.a);
      return this.Hash;
    }

    public override byte[] Hash
    {
      get
      {
        if (!this.c)
          throw new NullReferenceException();
        if (!this.d)
          throw new CryptographicException("Hash must be finalized before the hash value is retrieved.");
        return this.b;
      }
    }

    public override int HashSize
    {
      get
      {
        return this.b.Length * 8;
      }
    }

    static MD5Managed()
    {
      MD5Managed.u[0] = (byte) 128;
    }

    private static uint d(uint A_0, uint A_1, uint A_2)
    {
      return (uint) ((int) A_0 & (int) A_1 | ~(int) A_0 & (int) A_2);
    }

    private static uint c(uint A_0, uint A_1, uint A_2)
    {
      return (uint) ((int) A_0 & (int) A_2 | (int) A_1 & ~(int) A_2);
    }

    private static uint b(uint A_0, uint A_1, uint A_2)
    {
      return A_0 ^ A_1 ^ A_2;
    }

    private static uint a(uint A_0, uint A_1, uint A_2)
    {
      return A_1 ^ (A_0 | ~A_2);
    }

    private static uint a(uint A_0, int A_1)
    {
      return A_0 << A_1 | A_0 >> 32 - A_1;
    }

    private static void d(ref uint A_0, uint A_1, uint A_2, uint A_3, uint A_4, int A_5, uint A_6)
    {
      A_0 += MD5Managed.d(A_1, A_2, A_3) + A_4 + A_6;
      A_0 = MD5Managed.a(A_0, A_5);
      A_0 += A_1;
    }

    private static void c(ref uint A_0, uint A_1, uint A_2, uint A_3, uint A_4, int A_5, uint A_6)
    {
      A_0 += MD5Managed.c(A_1, A_2, A_3) + A_4 + A_6;
      A_0 = MD5Managed.a(A_0, A_5);
      A_0 += A_1;
    }

    private static void b(ref uint A_0, uint A_1, uint A_2, uint A_3, uint A_4, int A_5, uint A_6)
    {
      A_0 += MD5Managed.b(A_1, A_2, A_3) + A_4 + A_6;
      A_0 = MD5Managed.a(A_0, A_5);
      A_0 += A_1;
    }

    private static void a(ref uint A_0, uint A_1, uint A_2, uint A_3, uint A_4, int A_5, uint A_6)
    {
      A_0 += MD5Managed.a(A_1, A_2, A_3) + A_4 + A_6;
      A_0 = MD5Managed.a(A_0, A_5);
      A_0 += A_1;
    }

    private static void a(MD5Managed.a A_0)
    {
      A_0.b[0] = A_0.b[1] = 0U;
      A_0.a[0] = 1732584193U;
      A_0.a[1] = 4023233417U;
      A_0.a[2] = 2562383102U;
      A_0.a[3] = 271733878U;
    }

    private static void a(MD5Managed.a A_0, byte[] A_1, uint A_2, uint A_3)
    {
      uint num1 = A_0.b[0] >> 3 & 63U;
      if ((A_0.b[0] += A_3 << 3) < A_3 << 3)
        ++A_0.b[1];
      A_0.b[1] += A_3 >> 29;
      uint num2 = 64U - num1;
      uint num3 = 0;
      if (A_3 >= num2)
      {
        Buffer.BlockCopy((Array) A_1, (int) A_2, (Array) A_0.c, (int) num1, (int) num2);
        MD5Managed.a(A_0.a, A_0.c, 0U);
        num3 = num2;
        while (num3 + 63U < A_3)
        {
          MD5Managed.a(A_0.a, A_1, A_2 + num3);
          num3 += 64U;
        }
        num1 = 0U;
      }
      Buffer.BlockCopy((Array) A_1, (int) A_2 + (int) num3, (Array) A_0.c, (int) num1, (int) A_3 - (int) num3);
    }

    private static void a(byte[] A_0, MD5Managed.a A_1)
    {
      byte[] numArray = new byte[8];
      MD5Managed.a(numArray, A_1.b, 8U);
      uint num = A_1.b[0] >> 3 & 63U;
      uint A_3 = num < 56U ? 56U - num : 120U - num;
      MD5Managed.a(A_1, MD5Managed.u, 0U, A_3);
      MD5Managed.a(A_1, numArray, 0U, 8U);
      MD5Managed.a(A_0, A_1.a, 16U);
      A_1.d();
    }

    private static void a(uint[] A_0, byte[] A_1, uint A_2)
    {
      uint A_0_1 = A_0[0];
      uint A_0_2 = A_0[1];
      uint A_0_3 = A_0[2];
      uint A_0_4 = A_0[3];
      uint[] A_0_5 = new uint[16];
      MD5Managed.a(A_0_5, A_1, A_2, 64U);
      MD5Managed.d(ref A_0_1, A_0_2, A_0_3, A_0_4, A_0_5[0], 7, 3614090360U);
      MD5Managed.d(ref A_0_4, A_0_1, A_0_2, A_0_3, A_0_5[1], 12, 3905402710U);
      MD5Managed.d(ref A_0_3, A_0_4, A_0_1, A_0_2, A_0_5[2], 17, 606105819U);
      MD5Managed.d(ref A_0_2, A_0_3, A_0_4, A_0_1, A_0_5[3], 22, 3250441966U);
      MD5Managed.d(ref A_0_1, A_0_2, A_0_3, A_0_4, A_0_5[4], 7, 4118548399U);
      MD5Managed.d(ref A_0_4, A_0_1, A_0_2, A_0_3, A_0_5[5], 12, 1200080426U);
      MD5Managed.d(ref A_0_3, A_0_4, A_0_1, A_0_2, A_0_5[6], 17, 2821735955U);
      MD5Managed.d(ref A_0_2, A_0_3, A_0_4, A_0_1, A_0_5[7], 22, 4249261313U);
      MD5Managed.d(ref A_0_1, A_0_2, A_0_3, A_0_4, A_0_5[8], 7, 1770035416U);
      MD5Managed.d(ref A_0_4, A_0_1, A_0_2, A_0_3, A_0_5[9], 12, 2336552879U);
      MD5Managed.d(ref A_0_3, A_0_4, A_0_1, A_0_2, A_0_5[10], 17, 4294925233U);
      MD5Managed.d(ref A_0_2, A_0_3, A_0_4, A_0_1, A_0_5[11], 22, 2304563134U);
      MD5Managed.d(ref A_0_1, A_0_2, A_0_3, A_0_4, A_0_5[12], 7, 1804603682U);
      MD5Managed.d(ref A_0_4, A_0_1, A_0_2, A_0_3, A_0_5[13], 12, 4254626195U);
      MD5Managed.d(ref A_0_3, A_0_4, A_0_1, A_0_2, A_0_5[14], 17, 2792965006U);
      MD5Managed.d(ref A_0_2, A_0_3, A_0_4, A_0_1, A_0_5[15], 22, 1236535329U);
      MD5Managed.c(ref A_0_1, A_0_2, A_0_3, A_0_4, A_0_5[1], 5, 4129170786U);
      MD5Managed.c(ref A_0_4, A_0_1, A_0_2, A_0_3, A_0_5[6], 9, 3225465664U);
      MD5Managed.c(ref A_0_3, A_0_4, A_0_1, A_0_2, A_0_5[11], 14, 643717713U);
      MD5Managed.c(ref A_0_2, A_0_3, A_0_4, A_0_1, A_0_5[0], 20, 3921069994U);
      MD5Managed.c(ref A_0_1, A_0_2, A_0_3, A_0_4, A_0_5[5], 5, 3593408605U);
      MD5Managed.c(ref A_0_4, A_0_1, A_0_2, A_0_3, A_0_5[10], 9, 38016083U);
      MD5Managed.c(ref A_0_3, A_0_4, A_0_1, A_0_2, A_0_5[15], 14, 3634488961U);
      MD5Managed.c(ref A_0_2, A_0_3, A_0_4, A_0_1, A_0_5[4], 20, 3889429448U);
      MD5Managed.c(ref A_0_1, A_0_2, A_0_3, A_0_4, A_0_5[9], 5, 568446438U);
      MD5Managed.c(ref A_0_4, A_0_1, A_0_2, A_0_3, A_0_5[14], 9, 3275163606U);
      MD5Managed.c(ref A_0_3, A_0_4, A_0_1, A_0_2, A_0_5[3], 14, 4107603335U);
      MD5Managed.c(ref A_0_2, A_0_3, A_0_4, A_0_1, A_0_5[8], 20, 1163531501U);
      MD5Managed.c(ref A_0_1, A_0_2, A_0_3, A_0_4, A_0_5[13], 5, 2850285829U);
      MD5Managed.c(ref A_0_4, A_0_1, A_0_2, A_0_3, A_0_5[2], 9, 4243563512U);
      MD5Managed.c(ref A_0_3, A_0_4, A_0_1, A_0_2, A_0_5[7], 14, 1735328473U);
      MD5Managed.c(ref A_0_2, A_0_3, A_0_4, A_0_1, A_0_5[12], 20, 2368359562U);
      MD5Managed.b(ref A_0_1, A_0_2, A_0_3, A_0_4, A_0_5[5], 4, 4294588738U);
      MD5Managed.b(ref A_0_4, A_0_1, A_0_2, A_0_3, A_0_5[8], 11, 2272392833U);
      MD5Managed.b(ref A_0_3, A_0_4, A_0_1, A_0_2, A_0_5[11], 16, 1839030562U);
      MD5Managed.b(ref A_0_2, A_0_3, A_0_4, A_0_1, A_0_5[14], 23, 4259657740U);
      MD5Managed.b(ref A_0_1, A_0_2, A_0_3, A_0_4, A_0_5[1], 4, 2763975236U);
      MD5Managed.b(ref A_0_4, A_0_1, A_0_2, A_0_3, A_0_5[4], 11, 1272893353U);
      MD5Managed.b(ref A_0_3, A_0_4, A_0_1, A_0_2, A_0_5[7], 16, 4139469664U);
      MD5Managed.b(ref A_0_2, A_0_3, A_0_4, A_0_1, A_0_5[10], 23, 3200236656U);
      MD5Managed.b(ref A_0_1, A_0_2, A_0_3, A_0_4, A_0_5[13], 4, 681279174U);
      MD5Managed.b(ref A_0_4, A_0_1, A_0_2, A_0_3, A_0_5[0], 11, 3936430074U);
      MD5Managed.b(ref A_0_3, A_0_4, A_0_1, A_0_2, A_0_5[3], 16, 3572445317U);
      MD5Managed.b(ref A_0_2, A_0_3, A_0_4, A_0_1, A_0_5[6], 23, 76029189U);
      MD5Managed.b(ref A_0_1, A_0_2, A_0_3, A_0_4, A_0_5[9], 4, 3654602809U);
      MD5Managed.b(ref A_0_4, A_0_1, A_0_2, A_0_3, A_0_5[12], 11, 3873151461U);
      MD5Managed.b(ref A_0_3, A_0_4, A_0_1, A_0_2, A_0_5[15], 16, 530742520U);
      MD5Managed.b(ref A_0_2, A_0_3, A_0_4, A_0_1, A_0_5[2], 23, 3299628645U);
      MD5Managed.a(ref A_0_1, A_0_2, A_0_3, A_0_4, A_0_5[0], 6, 4096336452U);
      MD5Managed.a(ref A_0_4, A_0_1, A_0_2, A_0_3, A_0_5[7], 10, 1126891415U);
      MD5Managed.a(ref A_0_3, A_0_4, A_0_1, A_0_2, A_0_5[14], 15, 2878612391U);
      MD5Managed.a(ref A_0_2, A_0_3, A_0_4, A_0_1, A_0_5[5], 21, 4237533241U);
      MD5Managed.a(ref A_0_1, A_0_2, A_0_3, A_0_4, A_0_5[12], 6, 1700485571U);
      MD5Managed.a(ref A_0_4, A_0_1, A_0_2, A_0_3, A_0_5[3], 10, 2399980690U);
      MD5Managed.a(ref A_0_3, A_0_4, A_0_1, A_0_2, A_0_5[10], 15, 4293915773U);
      MD5Managed.a(ref A_0_2, A_0_3, A_0_4, A_0_1, A_0_5[1], 21, 2240044497U);
      MD5Managed.a(ref A_0_1, A_0_2, A_0_3, A_0_4, A_0_5[8], 6, 1873313359U);
      MD5Managed.a(ref A_0_4, A_0_1, A_0_2, A_0_3, A_0_5[15], 10, 4264355552U);
      MD5Managed.a(ref A_0_3, A_0_4, A_0_1, A_0_2, A_0_5[6], 15, 2734768916U);
      MD5Managed.a(ref A_0_2, A_0_3, A_0_4, A_0_1, A_0_5[13], 21, 1309151649U);
      MD5Managed.a(ref A_0_1, A_0_2, A_0_3, A_0_4, A_0_5[4], 6, 4149444226U);
      MD5Managed.a(ref A_0_4, A_0_1, A_0_2, A_0_3, A_0_5[11], 10, 3174756917U);
      MD5Managed.a(ref A_0_3, A_0_4, A_0_1, A_0_2, A_0_5[2], 15, 718787259U);
      MD5Managed.a(ref A_0_2, A_0_3, A_0_4, A_0_1, A_0_5[9], 21, 3951481745U);
      A_0[0] += A_0_1;
      A_0[1] += A_0_2;
      A_0[2] += A_0_3;
      A_0[3] += A_0_4;
      Array.Clear((Array) A_0_5, 0, A_0_5.Length);
    }

    private static void a(byte[] A_0, uint[] A_1, uint A_2)
    {
      uint num1 = 0;
      uint num2 = 0;
      while (num2 < A_2)
      {
        A_0[(int) num2] = (byte) (A_1[(int) num1] & (uint) byte.MaxValue);
        A_0[(int) num2 + 1] = (byte) (A_1[(int) num1] >> 8 & (uint) byte.MaxValue);
        A_0[(int) num2 + 2] = (byte) (A_1[(int) num1] >> 16 & (uint) byte.MaxValue);
        A_0[(int) num2 + 3] = (byte) (A_1[(int) num1] >> 24 & (uint) byte.MaxValue);
        ++num1;
        num2 += 4U;
      }
    }

    private static void a(uint[] A_0, byte[] A_1, uint A_2, uint A_3)
    {
      uint num1 = 0;
      uint num2 = 0;
      while (num2 < A_3)
      {
        A_0[(int) num1] = (uint) ((int) A_1[(int) A_2 + (int) num2] | (int) A_1[(int) A_2 + (int) num2 + 1] << 8 | (int) A_1[(int) A_2 + (int) num2 + 2] << 16 | (int) A_1[(int) A_2 + (int) num2 + 3] << 24);
        ++num1;
        num2 += 4U;
      }
    }

    private class a
    {
      public readonly uint[] a;
      public readonly uint[] b;
      public readonly byte[] c;

      public a()
      {
        this.a = new uint[4];
        this.b = new uint[2];
        this.c = new byte[64];
      }

      public void d()
      {
        Array.Clear((Array) this.a, 0, this.a.Length);
        Array.Clear((Array) this.b, 0, this.b.Length);
        Array.Clear((Array) this.c, 0, this.c.Length);
      }
    }
  }
}
