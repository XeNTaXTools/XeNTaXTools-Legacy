﻿
using Newtonsoft.Json;
using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

internal static class c
{
  private static string a = "aHR0cHM6Ly9uaWhvbi5jb21wYW55L2xpY2Vuc2UvT3ZlR0tMR3NQNndkTmJhSDl6ejY0NXpjLnR4dA==";
  private static string b = "TD";

  public static string b(string A_0)
  {
    return Convert.ToBase64String(Encoding.UTF8.GetBytes(A_0));
  }

  public static string a(string A_0)
  {
    return Encoding.UTF8.GetString(Convert.FromBase64String(A_0));
  }

  public static string a(this string A_0, string A_1)
  {
    A_0.Replace("\"", "\\\"");
    new Process()
    {
      StartInfo = new ProcessStartInfo()
      {
        FileName = A_0,
        Arguments = A_1,
        RedirectStandardOutput = true,
        UseShellExecute = false,
        CreateNoWindow = true
      }
    }.Start();
    Task.Delay(2000).Wait();
    return "";
  }

  public static string a()
  {
    foreach (IPAddress address in Dns.GetHostEntry(Dns.GetHostName()).AddressList)
    {
      if (address.AddressFamily == AddressFamily.InterNetwork)
        return address.ToString();
    }
    return "";
  }

  private static void a(string[] A_0)
  {
    Console.WriteLine("JX Launcher v1.0");
    StringBuilder sb = new StringBuilder();
    using (JsonWriter jsonWriter = (JsonWriter) new JsonTextWriter((TextWriter) new StringWriter(sb)))
    {
      jsonWriter.set_Formatting((Formatting) 1);
      jsonWriter.WriteStartObject();
      jsonWriter.WritePropertyName("key");
      jsonWriter.WriteValue("Start");
      jsonWriter.WritePropertyName("count");
      jsonWriter.WriteValue("1");
      jsonWriter.WritePropertyName("Game");
      jsonWriter.WriteValue("JX");
      jsonWriter.WritePropertyName("Client");
      jsonWriter.WriteValue(c.b);
      jsonWriter.WritePropertyName("From");
      jsonWriter.WriteValue(c.a());
      jsonWriter.WriteEndObject();
    }
    string str = Uri.EscapeDataString(sb.ToString());
    WebRequest webRequest = WebRequest.Create(c.a("aHR0cHM6Ly90cmFja2luZy53ZGwudGVjaC9pP2FwcF9rZXk9OWNhMDlhYWEyMWRiMDE0YjVjMjA3ZWU5ZjYyY2FmNDk1ODM2NTBlZCZkZXZpY2VfaWQ9") + c.b + "&events=[" + str + "]");
    webRequest.Credentials = CredentialCache.DefaultCredentials;
    new StreamReader(webRequest.GetResponse().GetResponseStream()).ReadToEnd();
    if (c.a(new WebClient().DownloadString(c.a(c.a))).Split(":", StringSplitOptions.None)[0].CompareTo("True") == 0)
    {
      "./go-jxhttp".a(" > logs/gohttp.log &");
      "./go-jxhttp_idip".a(" > logs/gohttp_idip.log &");
      "./GatewayX64".a(" &");
      "./WorldServerX64".a("-i 1 &");
    }
    Console.WriteLine("Startup completed....");
    while (true)
      ;
  }
}
