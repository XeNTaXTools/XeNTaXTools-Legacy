﻿

using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

public class TabFile
{
  public static bool s_bIsGbk = true;
  private Dictionary<string, int> a;
  private Dictionary<int, Dictionary<int, string>> b;
  private int c;
  private int d;

  public int nRowCount
  {
    get
    {
      return this.c;
    }
  }

  public int nColumnCount
  {
    get
    {
      return this.d;
    }
  }

  public TabFile()
  {
    this.a = new Dictionary<string, int>();
    this.b = new Dictionary<int, Dictionary<int, string>>();
  }

  public bool LoadFile(string szPath)
  {
    Encoding encoding = !TabFile.s_bIsGbk ? (Encoding) new UTF8Encoding() : (Encoding) new global::b();
    string szText = File.ReadAllText(szPath, encoding);
    if (szText == null)
      return false;
    bool flag = false;
    try
    {
      return this.LoadFileFromText(szPath, szText);
    }
    catch (Exception ex)
    {
      return flag;
    }
  }

  public bool LoadFileFromText(string szPath, string szText)
  {
    szText = szText.TrimEnd('\r', '\t', ' ', '\n');
    StringReader stringReader = new StringReader(szText);
    string str1 = stringReader.ReadLine();
    if (str1 == null)
    {
      stringReader.Close();
      return false;
    }
    this.b.Clear();
    this.a.Clear();
    this.c = 0;
    this.d = 0;
    char[] chArray1 = new char[2]{ '\t', ' ' };
    char[] chArray2 = new char[1]{ '\t' };
    string str2 = str1.TrimEnd(chArray1);
    this.b[1] = new Dictionary<int, string>();
    string[] strArray1 = str2.Split(chArray2);
    ++this.c;
    this.d = Math.Max(this.d, strArray1.Length);
    for (int index = 0; index < strArray1.Length; ++index)
    {
      this.a.ContainsKey(strArray1[index]);
      this.a[strArray1[index]] = index + 1;
      this.b[1][index + 1] = strArray1[index];
    }
    int index1 = 2;
    for (string str3 = stringReader.ReadLine(); str3 != null; str3 = stringReader.ReadLine())
    {
      string[] strArray2 = str3.TrimEnd(chArray1).Split(chArray2);
      this.d = Math.Max(this.d, strArray2.Length);
      this.b[index1] = new Dictionary<int, string>();
      for (int index2 = 0; index2 < strArray2.Length; ++index2)
        this.b[index1][index2 + 1] = strArray2[index2];
      ++index1;
      ++this.c;
    }
    stringReader.Close();
    return true;
  }

  public string GetCell(int nRow, int nColumn)
  {
    Dictionary<int, string> dictionary = (Dictionary<int, string>) null;
    if (this.b == null || !this.b.TryGetValue(nRow, out dictionary))
      return string.Empty;
    string str = (string) null;
    if (dictionary != null && dictionary.TryGetValue(nColumn, out str))
      return str;
    return string.Empty;
  }

  public string GetCell(int nRow, string szColumn)
  {
    int nColumn = -1;
    if (!this.a.TryGetValue(szColumn, out nColumn))
      return string.Empty;
    return this.GetCell(nRow, nColumn);
  }

  public bool GetInteger(int nRow, string szColumn, out int nRetInteger)
  {
    nRetInteger = 0;
    return int.TryParse(this.GetCell(nRow, szColumn), out nRetInteger);
  }

  public bool GetInteger(int nRow, string szColumn, int nDef, out int nRetInteger)
  {
    nRetInteger = 0;
    if (int.TryParse(this.GetCell(nRow, szColumn), out nRetInteger))
      return true;
    nRetInteger = nDef;
    return false;
  }

  public bool GetInteger(int nRow, int nColumn, out int nRetInteger)
  {
    nRetInteger = 0;
    return int.TryParse(this.GetCell(nRow, nColumn), out nRetInteger);
  }

  public bool GetFloat(int nRow, string szColumn, out float fRetFloat)
  {
    fRetFloat = 0.0f;
    return float.TryParse(this.GetCell(nRow, szColumn), out fRetFloat);
  }

  public bool GetFloat(int nRow, string szColumn, float fDefault, out float fRetFloat)
  {
    fRetFloat = fDefault;
    return float.TryParse(this.GetCell(nRow, szColumn), out fRetFloat);
  }

  public bool GetFloat(int nRow, int nColumn, out float fRetFloat)
  {
    fRetFloat = 0.0f;
    return float.TryParse(this.GetCell(nRow, nColumn), out fRetFloat);
  }

  public void SetCell(int nRow, int nColumn, object value)
  {
    Dictionary<int, string> dictionary = (Dictionary<int, string>) null;
    if (!this.b.TryGetValue(nRow, out dictionary))
    {
      dictionary = new Dictionary<int, string>();
      this.b[nRow] = dictionary;
    }
    dictionary[nColumn] = value.ToString();
    if (nRow == 1)
      this.a[value.ToString()] = nColumn;
    this.c = Math.Max(nRow, this.c);
    this.d = Math.Max(nColumn, this.d);
  }

  private byte[] a(int A_0, int A_1, bool A_2)
  {
    int num = this.GetCell(A_0, A_1) == string.Empty ? 1 : 0;
    return (byte[]) null;
  }

  public bool SaveAs(string filePath, bool bIsGBK = true)
  {
    Path.IsPathRooted(filePath);
    try
    {
      FileStream fileStream = new FileStream(filePath, FileMode.Create);
      BinaryWriter binaryWriter = new BinaryWriter((Stream) fileStream);
      Dictionary<int, string> dictionary = (Dictionary<int, string>) null;
      for (int index = 1; index <= this.c; ++index)
      {
        string empty = string.Empty;
        if (this.b.TryGetValue(index, out dictionary))
        {
          for (int nColumn = 1; nColumn <= this.d; ++nColumn)
          {
            empty += this.GetCell(index, nColumn);
            if (nColumn < this.d)
              empty += "\t";
          }
        }
        if (index < this.c)
          empty += "\n";
        byte[] buffer = !bIsGBK ? Encoding.GetEncoding("UTF-8").GetBytes(empty) : Encoding.GetEncoding("GBK").GetBytes(empty);
        binaryWriter.Write(buffer);
      }
      binaryWriter.Flush();
      fileStream.Flush();
      binaryWriter.Close();
      fileStream.Close();
    }
    catch
    {
      return false;
    }
    return true;
  }
}
