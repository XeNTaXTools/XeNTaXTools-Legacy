0import newGameLib
from newGameLib import *
import Blender	

def materialParser(file,mat):
	xml=Xml()
	#xml.DRAWCONSOLE=True		  
	xml.input=file
	xml.parse()
	phaseNodeList=xml.find(xml.root,'phase')	
	for phaseNode in phaseNodeList:
		chunks=phaseNode.chunks
		if 'name' in chunks:
			if chunks['name']=='color':
				samplerNodeList=xml.find(phaseNode,'sampler')	
				for samplerNode in samplerNodeList:
					chunks=samplerNode.chunks
					if 'name' in chunks:
						if chunks['name']=='diffuse':
							if 'texture' in chunks:
								mat.diffuse=os.path.dirname(file.name)+os.sep+chunks['texture']+'.3.dds'
						if chunks['name']=='normalmap':
							if 'texture' in chunks:
								mat.normal=os.path.dirname(file.name)+os.sep+chunks['texture']+'.3.dds'
						if chunks['name']=='specular':
							if 'texture' in chunks:
								mat.specular=os.path.dirname(file.name)+os.sep+chunks['texture']+'.3.dds'
				

def modelParser(filename,g):
	meshList=[]
	while(True):
		if g.tell()>=g.fileSize():break
		chunk=g.word(4)
		if chunk=='SMDL':
			A=g.i(7)
			g.f(6)
		elif chunk=='bone':
			size=g.i(1)[0]
	
			skeleton=Skeleton()
			skeleton.ARMATURESPACE=True
			
			for m in range(A[6]):
				bone=Bone()
				bone.parentID=g.i(1)[0]
				g.f(12)
				bone.rotMatrix=Matrix3x3(g.f(9)).resize4x4()
				bone.posMatrix=VectorMatrix(g.f(3))
				bone.name=g.word(g.B(1)[0])[-25:]
				g.B(1)
				skeleton.boneList.append(bone)
			skeleton.draw()	
		elif chunk=='mesh':
		
			mesh=Mesh()	
			meshList.append(mesh)
			mat=Mat()
			mat.ZTRANS=True
			mat.TRIANGLE=True
			mesh.matList.append(mat)
			B=g.i(4)
			g.f(6)
			g.i(1)
			a,b=g.B(2)
			print a,b
			print g.find('\x00')
			materialName=g.find('\x00')
			materialPath=g.dirname+os.sep+materialName+'.material'
			if os.path.exists(materialPath)==True:
				file=open(materialPath,'r')
				materialParser(file,mat)
				file.close()
				if mat.diffuse is None:
					mat.diffuse=g.dirname+os.sep+'color.tga.3.dds'
					
		elif chunk=='vrts':
			size=g.i(1)[0]
			ti=g.tell()
			g.i(1)
			for m in range(B[3]):mesh.vertPosList.append(g.f(3))	
			g.seek(ti+size)
		elif chunk=='face':	
			size=g.i(1)[0]
			ti=g.tell()
			a,b=g.i(2)
			indiceType=g.B(1)[0]
			if indiceType==2:
				for m in range(b):mesh.faceList.append(g.H(3))	
			if indiceType==1:	
				for m in range(b):mesh.faceList.append(g.B(3))	
			g.seek(ti+size)
		elif chunk=='texc':	
			size=g.i(1)[0]
			ti=g.tell()
			g.i(2)
			for m in range(B[3]):mesh.vertUVList.append(g.f(2))	
			g.seek(ti+size)	
		elif chunk=='tang':	
			size=g.i(1)[0]
			ti=g.tell()
			g.i(2)
			for m in range(B[3]):
				g.f(3)	
			g.seek(ti+size)
		elif chunk=='sign':	
			size=g.i(1)[0]
			ti=g.tell()
			g.i(2)
			for m in range(B[3]):
				g.B(1)	
			g.seek(ti+size)
		elif chunk=='colr':	
			size=g.i(1)[0]
			ti=g.tell()
			g.i(2)
			for m in range(B[3]):
				g.B(4)	
			g.seek(ti+size)		
		elif chunk=='nrml':	
			size=g.i(1)[0]
			ti=g.tell()
			g.i(1)
			for m in range(B[3]):
				g.f(3)			
		elif chunk=='lnk1':	
			size=g.i(1)[0]
			ti=g.tell()
			a,b=g.i(2)
			a,b
			for m in range(b):
				count=g.i(1)[0]
				mesh.skinWeightList.append(g.f(count))
				mesh.skinIndiceList.append(g.i(count))	
			g.seek(ti+size)			
		elif chunk=='lnk3':	
			size=g.i(1)[0]
			ti=g.tell()
			a,b=g.i(2)
			a,b
			for m in range(b):
				count=g.i(1)[0]
				mesh.skinWeightList.append(g.f(count))
				mesh.skinIndiceList.append(g.i(count))	
			g.seek(ti+size)	
		else:
			print 'unknow:',chunk
			break
	print g.tell(),g.fileSize()	
	for mesh in meshList:	
		skin=Skin()
		mesh.skinList.append(skin)	
		mesh.boneNameList=skeleton.boneNameList
		mesh.BINDSKELETON=skeleton.name	
		mesh.draw()
	
	
def clipParser(filename,g):
	g.word(8)
	A=g.i(4)
	action=Action()
	#action.UPDATE=False
	action.BONESORT=True
	action.BONESPACE=True
	for m in range(A[2]):
		bone=ActionBone()
		bone.channelList={}
		action.boneList.append(bone)	
	while(True):
		if g.tell()>=g.fileSize():break
		g.word(4)
		B=g.i(1)
		t=g.tell()
		C=g.i(3)
		bone=action.boneList[C[0]]
		name=g.word(g.B(1)[0])
		bone.name=name
		g.B(1)[0]
		if C[1]==6:bone.channelList[C[1]]=[C[2],g.B(1)[0]]
		else:bone.channelList[C[1]]=[C[2],g.f(C[2])]
		g.seek(t+B[0])
		
	keyCount=A[3]
	for bone in action.boneList:
		for m in range(keyCount):
			bone.posFrameList.append(m)
			if m>=bone.channelList[0][0]:x=bone.channelList[0][1][-1]
			else:x=bone.channelList[0][1][m]				
			if m>=bone.channelList[1][0]:y=bone.channelList[1][1][-1]
			else:y=bone.channelList[1][1][m]				
			if m>=bone.channelList[2][0]:z=bone.channelList[2][1][-1]
			else:z=bone.channelList[2][1][m]				
			matrix=VectorMatrix([x,y,z])
			bone.posKeyList.append(matrix)			
		for m in range(keyCount):
			bone.rotFrameList.append(m)	
			if m>=bone.channelList[3][0]:x=bone.channelList[3][1][-1]
			else:x=bone.channelList[3][1][m]				
			if m>=bone.channelList[4][0]:y=bone.channelList[4][1][-1]
			else:y=bone.channelList[4][1][m]				
			if m>=bone.channelList[5][0]:z=bone.channelList[5][1][-1]
			else:z=bone.channelList[5][1][m]
			euler = Blender.Mathutils.Euler()
			RotateEuler(euler,z,'z')
			RotateEuler(euler,x,'x')
			RotateEuler(euler,y,'y')
			matrix=euler.toMatrix().resize4x4()
			bone.rotKeyList.append(matrix)
	action.draw()
	action.setContext()	
			
	
	
	
def Parser(filename):	
	ext=filename.split('.')[-1].lower()	
	
	if ext=='model':
		file=open(filename,'rb')
		g=BinaryReader(file)
		g.logOpen()
		modelParser(filename,g)
		g.logClose()
		file.close()
	
	if ext=='clip':
		file=open(filename,'rb')
		g=BinaryReader(file)
		clipParser(filename,g)
		file.close()
 
 
	
	
Blender.Window.FileSelector(Parser,'import','select: *.model, *.clip') 
	