﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace bf3
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            //x:\bf\Chunks0.toc
            var path = @"x:\bf\Chunks0.toc";
            FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
            var rawData = ReadData(fs);
            byte[] magic = new byte[257];
            byte[] data = new byte[fs.Length - 0x22c];
            Buffer.BlockCopy(rawData, 0x128, magic, 0, 257);
            Buffer.BlockCopy(rawData, 0x22c, data, 0, rawData.Length - 0x22c);


            for (int i = 0; i < data.Length; i++)
            {
                data[i] = (byte) (data[i] ^ magic[i%257] ^ 0x7B);
            }
            SaveToFile(path.Replace("toc", "txt"), data);
        }

        public static byte[] ReadData(Stream input)
        {
            using (var ms = new MemoryStream())
            {
                input.CopyTo(ms);
                return ms.ToArray();
            }
        }

        public static void SaveToFile(string file, byte[] array)
        {
            var fs = new FileStream(file, FileMode.Create, FileAccess.Write);
            fs.Write(array, 0, array.Length);
            fs.Close();
        }
    }
}
