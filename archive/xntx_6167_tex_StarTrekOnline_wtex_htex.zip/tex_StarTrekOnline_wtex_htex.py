from inc_noesis import *

############################################
mipmapsFirst = 1    #Set true(1) or false(0)
############################################

def registerNoesisTypes():
    handle = noesis.register("Star Trek Online", ".wtex;.htex")
    noesis.setHandlerTypeCheck(handle, noepyCheckType)
    noesis.setHandlerLoadRGBA(handle, noepyLoadRGBA)
    #noesis.logPopup()
    return 1

def noepyCheckType(data):
    return 1

def noepyLoadRGBA(data, texList):
    bs = NoeBitStream(data)
    check = bs.readShort()
    if check == 0x7848:
        bs.seek(0x0, NOESEEK_ABS)
        data = bs.readBytes(len(data))
        tex = rapi.loadTexByHandler(data, ".crn")
        texList.append(tex)
    else:
        bs.seek(check, NOESEEK_ABS)
        check2 = bs.readShort()
        if check2 == 0x4444:
            bs.seek(check + 0xc, NOESEEK_ABS)
            imgHeight = bs.readUInt()
            imgWidth = bs.readUInt()
            dataSize = bs.readUInt()
            bs.seek(0x3c, NOESEEK_REL)
            FourCC = bs.readUInt()
            RGBBitCount = bs.readUInt()
            if mipmapsFirst == True:
                bs.seek(len(data) - dataSize, NOESEEK_ABS)
            else: 
                bs.seek(check + 0x80, NOESEEK_ABS)
            data = bs.readBytes(dataSize)
            if FourCC == 0x0:
                if RGBBitCount == 0x18:
                    data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "b8 g8 r8")
                elif RGBBitCount == 0x20:
                    data = rapi.imageDecodeRaw(data, imgWidth, imgHeight, "b8 g8 r8 p8")
                texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, noesis.NOESISTEX_RGBA32))
        else:
            bs.seek(check, NOESEEK_ABS)
            data = bs.readBytes(len(data) - check)
            tex = rapi.loadTexByHandler(data, ".crn")
            texList.append(tex)
    return 1