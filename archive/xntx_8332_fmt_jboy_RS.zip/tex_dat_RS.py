#by Durik256
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("REAL STEEL", ".dat")
    noesis.setHandlerTypeCheck(handle, CheckType)
    noesis.setHandlerLoadRGBA(handle, LoadRGBA)
    return 1

def CheckType(data):
    return 1
    
def LoadRGBA(data, texList):
    bs = NoeBitStream(data) 
    n = bs.readInt()
    bs.seek(16)
    
    for x in range(n):
        c, t = bs.readBytes(16), bs.readBytes(4)
        s, o = bs.readInt(), bs.readInt()
        p = bs.getOffset()
        if t == b'dds\x00':
            bs.seek(o)
            texList.append(rapi.loadTexByHandler(bs.readBytes(s), '.dds'))
            bs.seek(p)
        bs.seek(4,1)
    return 1