#by Durik256
from inc_noesis import *

def registerNoesisTypes():
    handle = noesis.register("REAL STEEL", ".jboy")
    noesis.setHandlerTypeCheck(handle, CheckType)
    noesis.setHandlerLoadModel(handle, LoadModel)
    return 1

def CheckType(data):
    if data[:4] != b'JBOY':
        return 0
    return 1
    
def LoadModel(data, mdlList):
    bs = NoeBitStream(data, 1)
    h = i(bs,'>14H11I')
    
    sm = []
    for x in range(h[13]):
        x = i(bs,'>45I')
        sm.append(list(x[:2])+list(x[26:29])+[x[38],x[23],x[2]]+list(x[3:3+x[2]]))
        print(x)
        print(sm[-1])
    
    ctx = rapi.rpgCreateContext()
    rapi.rpgSetEndian(1)
    for x in sm:
        bs.seek(x[2]+12)
        st = (x[3]-x[2]-4)//x[0]
        vb = bs.readBytes(x[0]*st)
        rapi.rpgBindPositionBuffer(vb, 0, st)
        
        bs.seek(x[4]+8)
        ub = bs.readBytes(x[0]*8)
        rapi.rpgBindUV1Buffer(ub, 0, 8)
        
        bs.seek(x[3]+8)
        rapi.rpgSetBoneMap([q-1 for q in x[8:8+x[7]]])
        w = cw(bs,x[0],x[6])
        rapi.rpgBindBoneIndexBuffer(w, 8, x[6]*5, x[6])
        rapi.rpgBindBoneWeightBufferOfs(w, 0, x[6]*5, x[6], x[6])
        
        bs.seek(x[5]+8)
        for x in range(x[1]):
            f, cp = i(bs,'>3I'), bs.getOffset()
            bs.seek(f[2]+8)
            ibuf = bs.readBytes(f[1]*2)
            rapi.rpgSetMaterial('mat_%i'%f[2])
            rapi.rpgCommitTriangles(ibuf, 4, f[1], 3)
            bs.seek(cp)
    
    bs.seek(h[17]+8)
    bn = []
    for x in range(h[15]):
        n = noeStrFromBytes(bs.readBytes(16))
        p = bs.seek(32,1)*0+bs.readInt()
        mt = NoeAngles.fromBytes(bs.readBytes(12),1).toMat43()
        mt[3] = NoeVec3.fromBytes(bs.readBytes(12),1)
        bs.seek(4,1)
        bn.append(NoeBone(x,n,mt,None,p))
    
    rapi.rpgSetOption(noesis.RPGOPT_TRIWINDBACKWARD, 1)
    mdl = rapi.rpgConstructModel()
    mdl.setBones(bn)
    mdlList.append(mdl)
    rapi.setPreviewOption("setAngOfs", "0 -90 -90")
    return 1
    
def i(bs,s):
    return struct.unpack(s, bs.readBytes(struct.calcsize(s)))
    
def cw(bs,v,n):
    w = b''
    for x in range(v):
        x = i(bs,'>'+'4bf'*n)
        w += struct.pack('>%ib%if'%(n,n),*([x[q*5] for q in range(n)]+[x[q*5+4] for q in range(n)]))
    return w
    