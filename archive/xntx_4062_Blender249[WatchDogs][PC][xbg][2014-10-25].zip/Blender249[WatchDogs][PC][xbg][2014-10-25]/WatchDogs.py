import newGameLib
reload(newGameLib)
from newGameLib import *

import Blender

UVTrans=0.5   #  try: 0.0 , 0.5 , 1.0
UVScale=1.5   #  try: 0.5 , 1.0 , 1.5


def ParseMesh(inputMeshList,g):
	
	outputMeshList=[]	
	vertPosList=[]
	vertUVList=[]
	skinIndiceList=[]
	skinWeightList=[]	
	skinIDList=[]	
		
	count=len(inputMeshList)	
	sum=0
	for m in range(count):	
		mesh=inputMeshList[m]
		print m,mesh.vertStride,mesh.vertCount,mesh.faceCount,mesh.totalVertCount,mesh.matID,mesh.UVFlag,mesh.scaleFlag
		for n in range(mesh.vertCount):
			t=g.tell()
			vertPosList.append(g.short(3,'h',14))
			skinIDList.append(mesh.boneMapID)
			if mesh.vertStride in [32]:
				if mesh.UVFlag==4506:
					g.seek(t+8)
					u=UVTrans+UVScale*g.short(1,'h',15)[0]
					v=UVTrans+UVScale*g.short(1,'h',15)[0]
					vertUVList.append([u,v])
					g.seek(t+16)
					skinWeightList.append(g.B(4))
					skinIndiceList.append(g.B(4))
				if mesh.UVFlag==6090:
					g.seek(t+8)	
					u=UVTrans+UVScale*g.short(1,'h',15)[0]
					v=UVTrans+UVScale*g.short(1,'h',15)[0]
					vertUVList.append([u,v])
					#g.seek(3,1)
					#print g.B(20)
					"""skinWeightList.append([1.0])
					skinIndiceList.append([g.B(1)[0]])"""
			if mesh.vertStride in [28]:
				if mesh.UVFlag==1994:
					g.seek(t+8)	
					u=UVTrans+UVScale*g.short(1,'h',15)[0]
					v=UVTrans+UVScale*g.short(1,'h',15)[0]
					vertUVList.append([u,v])
					#print g.B(16)
					"""g.seek(t+27)
					skinWeightList.append([1.0])
					skinIndiceList.append([g.B(1)[0]])"""
				if mesh.UVFlag==37322:
					g.seek(t+12)
					u=UVTrans+UVScale*g.short(1,'h',15)[0]
					v=UVTrans+UVScale*g.short(1,'h',15)[0]
					vertUVList.append([u,v])
					"""g.seek(t+16)
					skinWeightList.append(g.B(4))
					skinIndiceList.append(g.B(4))"""	
			if mesh.vertStride in [36]:
				if mesh.UVFlag==1946:
					g.seek(t+8)
					u=UVTrans+UVScale*g.short(1,'h',15)[0]
					v=UVTrans+UVScale*g.short(1,'h',15)[0]
					vertUVList.append([u,v])
					g.seek(t+12)
					skinWeightList.append(g.B(4))
					skinIndiceList.append(g.B(4))
				if mesh.UVFlag==37322:
					g.seek(t+12)	
					u=UVTrans+UVScale*g.short(1,'h',15)[0]
					v=UVTrans+UVScale*g.short(1,'h',15)[0]
					vertUVList.append([u,v])
					g.seek(t+16)
					skinWeightList.append(g.B(4))
					skinIndiceList.append(g.B(4))							
			if mesh.vertStride in [40]:
				if mesh.UVFlag==6042:
					g.seek(t+8)
					u=UVTrans+UVScale*g.short(1,'h',15)[0]
					v=UVTrans+UVScale*g.short(1,'h',15)[0]
					vertUVList.append([u,v])
					g.seek(t+16)
					skinWeightList.append(g.B(4))
					skinIndiceList.append(g.B(4))							
			if mesh.vertStride in [44]:
				if mesh.UVFlag==6074:
					g.seek(t+8)
					u=UVTrans+UVScale*g.short(1,'h',15)[0]
					v=UVTrans+UVScale*g.short(1,'h',15)[0]
					vertUVList.append([u,v])
					g.seek(t+16)
					skinWeightList.append(g.B(4))
					skinIndiceList.append(g.B(4))			
			g.seek(t+mesh.vertStride)
		sum+=mesh.vertCount		
		if sum==mesh.totalVertCount:
			print '-'*20,'add new mesh'
			
			mesh=Mesh()
			if len(boneMapList)>0:
				for j in range(len(boneMapList)):
					skin=Skin()
					for k in range(len(boneMapList[j])):
						boneID=boneMapList[j][k]
						for i in range(len(boneIDList)):
							if boneIDList[i]==boneID:
								#skin.boneMap.append(skeleton.boneNameList[i])
								skin.boneMap.append(i)
								break
					mesh.skinList.append(skin)				

				
			mesh.BINDSKELETON='armature'
			mesh.skinIndiceList=skinIndiceList
			mesh.skinWeightList=skinWeightList
			mesh.vertPosList=vertPosList
			mesh.vertUVList=vertUVList
			mesh.boneNameList=skeleton.boneNameList
			if len(mesh.skinWeightList)>0:
				mesh.skinIDList=skinIDList
			outputMeshList.append(mesh)
			vertPosList=[]
			vertUVList=[]
			skinIndiceList=[]
			skinWeightList=[]
			skinIDList=[]
			sum=0
			#mesh.draw()
			
			
			
			
	g.i(1)[0]
	faceList=[]	
	lodMatList=[]
	matIDList=[]
	meshID=0
	sum=0
	for m in range(count):
		mesh=inputMeshList[m]
		mat=matList[mesh.matID]
		for n in range(mesh.faceCount):
			faceList.append(g.H(3))
			matIDList.append(len(lodMatList))
		sum+=mesh.vertCount	
		lodMatList.append(mat)	
		if sum==mesh.totalVertCount:
			mesh=outputMeshList[meshID]
			mesh.matList=lodMatList
			mesh.faceList=faceList
			mesh.matIDList=matIDList
			meshID+=1
			mesh.SPLIT=True
			mesh.draw()
			faceList=[]
			matIDList=[]	
			lodMatList=[]
			sum=0
	g.seekpad(4)

def StringList(g):
	list=[]
	count=g.i(1)[0]
	for m in range(count):
		hash=g.i(1)[0]
		list.append(g.word(g.i(1)[0]))
		g.seekpad(4)
	return list	
		

def MeshList(g):
	meshList=[]
	meshCount=g.i(1)[0]
	print 'meshCount:',meshCount
	
	
	for m in range(meshCount):
		mesh=Mesh()
		g.f(10)
		w=g.H(20)
		matCount=g.i(1)[0]
		g.i(2)
		#print m,w			
		mesh.vertStride=w[4]
		mesh.matID=w[2]
		mesh.vertCount=1+w[18]-w[17]
		mesh.totalVertCount=w[16]
		mesh.faceCount=w[10]
		mesh.UVFlag=w[3]
		mesh.scaleFlag=0
		mesh.boneMapID=w[6]
		
		
		for n in range(matCount):
			g.seek(68,1)
			g.word(g.i(1)[0])
			g.seekpad(4)
			g.H(2)
		meshList.append(mesh)
	return meshList


def Print(value,list):
	print value,':',list[value]

def sectionE(g,bool):
	v=g.i(2)
	g.seekpad(16)
	matrixCount=v[1]
	for m in range(matrixCount):Matrix4x4(g.f(16))

def sectionD(g,bool):#bones
	chunk=g.i(1)[0]# or count ?	
	if chunk==1:
		boneCount=g.i(1)[0]		
		for m in range(boneCount):
			bone=Bone()
			g.i(1)
			bone.posMatrix=VectorMatrix(g.f(3))
			bone.rotMatrix=QuatMatrix(g.f(4))
			w=g.h(2)
			boneIDList.append(w[1])
			bone.parentID=w[0]
			hash=g.B(4)
			bone.name=g.word(g.i(1)[0])[-25:]
			g.seekpad(4)
			skeleton.boneList.append(bone)

def sectionC(g,bool):
	boneMapCount=g.i(1)[0]	
	for n in range(boneMapCount):
		boneIDCount=g.i(1)[0]
		boneMapList.append(g.H(boneIDCount))
		#print n,boneMapList[n]
		g.seekpad(4)

def sectionB1(g,bool):
	StringList(g)
		
def sectionB(g,bool):
	matCount=g.i(1)[0]
	for m in range(matCount):
		hash=g.i(1)[0]
		g.word(g.i(1)[0])
		g.seekpad(4)
		g.i(1)

def sectionA(g,bool):		
	count=g.i(1)[0]	
	for m in range(count):
		mat=Mat()
		hash=g.read(4)
		matFile=g.word(g.i(1)[0])
		matPath=filename.split('graphics')[0]+matFile
		if os.path.exists(matPath):
			file=open(matPath,'rb')
			p=BinaryReader(file)
			
			p.seek(68)
			p.word(p.i(1)[0])
			p.seekpad(4)
			p.word(p.i(1)[0])
			p.seekpad(4)
			
			p.seek(32,1)
			for n in range(1):
				xbtPath=filename.split('graphics')[0]+p.word(p.i(1)[0])
				p.seekpad(4)
				if os.path.exists(xbtPath)==True:
					xbtParser(xbtPath)
					ddsPath=xbtPath.replace('.xbt','.dds')
					if n==0:
						mat.diffuse=ddsPath
					p.i(2)
			file.close()
		matList.append(mat)	
		g.seekpad(4)

def sectionG(g,bool):
	count=g.i(1)[0]	
	for i in range(count):		
		g.i(2)
		g.f(7)	
		g.i(4)
		g.i(1)
		type=g.i(1)[0]
		if type==2:
			g.tell()
			count=g.i(1)[0]
			count=g.i(1)[0]
			for m in range(count):
				hash=g.i(1)[0]
				m,g.word(g.i(1)[0])
				g.seekpad(16)
				g.f(4)	
				g.f(4)	
				g.f(4)	
				g.f(4)	
				g.f(1)
			g.i(1)[0]
			count=g.i(1)[0]
			for m in range(count):
				hash=g.i(1)[0]
				m,g.word(g.i(1)[0])
				g.seekpad(16)
				g.f(4)	
				g.f(4)	
				g.f(4)	
				g.f(4)	
				g.f(7)
			count=g.i(1)[0]
			for m in range(count):
				hash=g.i(1)[0]
				m,g.word(g.i(1)[0])
				g.seekpad(16)
				g.f(4)	
				g.f(4)	
				g.f(4)	
				g.f(4)	
				g.f(6)
			count=g.i(1)[0]	
			for m in range(count):
				cv=g.i(1)[0]
				g.tell()
				count=g.i(1)[0]
				for m in range(count):
					g.f(5)
			count=g.i(1)[0]		
			for m in range(count):
				cv=g.i(1)[0]
				count=g.i(1)[0]	
				for m in range(count):
					g.f(9)
			count=g.i(1)[0]		
			for m in range(count):
				cv=g.i(1)[0]
				count=g.i(1)[0]	
				for m in range(count):
					g.f(9)
			count=g.i(1)[0]
			for m in range(count):
				hash=g.i(1)[0]
				m,g.word(g.i(1)[0])
				g.seekpad(4)
				g.f(4)
				
			count=g.i(1)[0]
			for m in range(count):
				hash=g.i(1)[0]
				m,g.word(g.i(1)[0])
				g.seekpad(4)
					
			count=g.i(1)[0]
			count=g.i(1)[0]
			count=g.i(1)[0]
			count=g.i(1)[0]
		else:
			chunk=g.i(1)[0]
			count=g.i(1)[0]#8
			for m in range(count):
				hash=g.i(1)[0]
				m,g.word(g.i(1)[0])
				g.seekpad(16)
				g.f(4)	
				g.f(4)	
				g.f(4)	
				g.f(4)	
				g.f(1)
			count=g.i(1)[0]#7
			for m in range(count):
				hash=g.i(1)[0]
				m,g.word(g.i(1)[0])
				g.seekpad(16)
				g.f(23)			
			count=g.i(1)[0]#6
			for m in range(count):
				hash=g.i(1)[0]
				m,g.word(g.i(1)[0])
				g.seekpad(16)
				g.f(23)
			chunk=g.i(1)[0]
			count=g.i(1)[0]#5
			for m in range(count):
				m,g.h(6)
				g.f(4)
			chunk=g.i(1)[0]
			count=g.i(1)[0]#4
			for m in range(count):
				g.seek(44,1)			
			count=g.i(1)[0]#4
			for m in range(count):
				hash=g.i(1)[0]
				m,g.word(g.i(1)[0])
				g.seekpad(4)
				g.f(4)			
			count=g.i(1)[0]#3
			for m in range(count):
				hash=g.i(1)[0]
				m,g.word(g.i(1)[0])
				g.seekpad(4)
			count=g.i(1)[0]#2
			for m in range(count):
				g.H(3)
			g.seekpad(4)
			g.debug=False			
			chunk=g.i(1)[0]
			count=g.i(1)[0]#4
			for m in range(count):
				m,g.H(3)
			chunk=g.i(1)[0]
			g.seekpad(4)				
			g.debug=False
	
def sectionK(g,bool):
	if g.i(1)[0]>0:		
		size=g.i(1)[0]
		t=g.tell()
		g.seek(t+size)	
	
def sectionF(g,bool):
	count=g.i(1)[0]
	for m in range(count):
		w0=g.H(4)+g.f(1)
		w1=None
		if w0[1]==6:
			w1=g.i(3)
	
def xbgParser(filename,g):
	global skeleton,boneMapList,matList,boneIDList	
	skeleton=Skeleton()
	skeleton.BONESPACE=True	
	skeleton.NICE=True	
	#skeleton.IK=True
	boneMapList=[]
	matList=[]
	boneIDList=[]
	g.word(4)	
	w=g.H(14)
	g.f(2)
	g.f(3)
	g.f(3)
	g.f(3)
	g.f(3)
	g.f(3)
	g.f(3)
	lodCount=g.i(1)[0]
	g.f(lodCount)
	g.f(1)[0]
	g.i(1)[0]
	g.f(lodCount-g.i(1)[0])
	sectionA(g,0)
	sectionB(g,0)
	sectionB1(g,0)
	sectionC(g,0)
	sectionD(g,0)
	sectionE(g,0)
	sectionK(g,0)
	sectionG(g,0)	
	sectionF(g,0)
	
	skeleton.draw()	
	List=[]
	for m in range(lodCount):
		meshList=MeshList(g)
		List.append(meshList)
	min,max=g.i(2)
	for i in range(max):
		g.i(1)
		ParseMesh(List[min+i],g)
		break
	print g.tell()
	
def xbtParser(filename):
	
	file=open(filename,'rb')
	g=BinaryReader(file)
	g.word(4)
	w=g.i(3)
	g.seek(w[1])
	new=open(filename.replace('.xbt','.dds'),'wb')	
	new.write(g.read(g.fileSize()-g.tell()))
	new.close()
	file.close()
	
def binParser(filename,g):
	print filename
	g.debug=True
	g.seek(68)
	new.write(g.word(g.i(1)[0])+'    ')
	g.seekpad(4)
	new.write(g.word(g.i(1)[0])+'\n')
	g.seekpad(4)
	
		
def Parser(path):
	global filename
	filename=path
	print '-'*50
	print '-'*50
	print filename
	print '-'*50
	print '-'*50
	ext=filename.split('.')[-1].lower()	
	
	if ext=='xbg':
		file=open(filename,'rb')
		g=BinaryReader(file)
		xbgParser(filename,g)
		file.close()
	
	if ext=='xbt':
		xbtParser(filename)
		
	
Blender.Window.FileSelector(Parser,'import','xbg - geometry file , xbt - texture') 