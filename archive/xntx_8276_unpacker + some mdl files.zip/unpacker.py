import os
import subprocess
import sys
import struct
import argparse

if sys.version_info[0] < 3:
    raise Exception("Must be using Python 3")

DEBUG = True
VERSION = 2.1
LOG_FILE = open(os.path.join(os.path.dirname(os.path.realpath(__file__)), 'unpacker.log'), 'w')

def log(*strings, tp=''):
    s = ' |' + tp + '| ' + ' '.join(map(str, strings))
    global LOG_FILE
    print(s)
    LOG_FILE.write(s + '\n')

LOG_FILE.write('##################################\n'
               '##  GRP Unpacker Log File v1.0  ##\n'
               '##################################\n')

log('Checking libs...', tp='I')
try:
    import zstandard
except ImportError:
    subprocess.check_output([sys.executable, '-m', 'pip', 'install', 'zstandard'])
    import zstandard
    log('The zstandard library has been installed', tp='I')

parser = argparse.ArgumentParser(description='Crossout Unpacker v{}'.format(str(VERSION)))
parser.add_argument('-i', '--input_folder', type=str, help='Path to game data folder')
parser.add_argument('-o', '--output_folder', type=str, help='Path to folder to save')
args = parser.parse_args()
DATA_PATH = args.input_folder.replace('/', '\\')
SAVE_PATH = args.output_folder.replace('/', '\\')

if not os.path.exists(SAVE_PATH):
    os.makedirs(SAVE_PATH)
if not os.path.exists(DATA_PATH):
    log('The data folder does not exists!', tp='E', err=True)

archive_count = 0
errors = 0
for fn in os.listdir(DATA_PATH):
    file = os.path.join(DATA_PATH, fn)
    if os.path.isfile(file):
        archive = open(file, 'rb')
        if archive.read(4) != b'GRP2':
            archive.close()
            continue
        archive_count += 1
        main_data_offset = struct.unpack('I', archive.read(4))[0] + 16
        archive.seek(4, 1)
        size = struct.unpack('I', archive.read(4))[0] + 16
        name_offsets_offset = struct.unpack('I', archive.read(4))[0]
        files_count = struct.unpack('I', archive.read(4))[0]
        archive.seek(8, 1)
        data_offsets_offset = struct.unpack('I', archive.read(4))[0]
        log(f'Parsing {fn} with {files_count} files...', tp='I')
        for i in range(files_count):
            archive.seek(name_offsets_offset + 4 * i)
            name_offset = struct.unpack('I', archive.read(4))[0]
            if i < files_count - 1:
                ln = abs(name_offset - struct.unpack('I', archive.read(4))[0]) - 1
            else:
                ln = abs(name_offset - data_offsets_offset) - 1
            archive.seek(name_offset)
            name = archive.read(ln).decode('utf-8')
            archive.seek(4 + data_offsets_offset + 12 * i)
            data_offset = struct.unpack('I', archive.read(4))[0]
            archive.seek(8, 1)
            if i < files_count - 1:
                ln = abs(data_offset - struct.unpack('I', archive.read(4))[0])
            else:
                ln = abs(data_offset - size)
            archive.seek(data_offset)
            sp = os.path.join(SAVE_PATH, '\\'.join(name.split('/')[:-1]))
            if not os.path.exists(sp):
                os.makedirs(sp)
            data = archive.read(ln)
            if len(data) > 0 and struct.unpack('i', data[:4])[0] == -47205080:
                decomp = zstandard.ZstdDecompressor()
                try:
                    data = decomp.decompress(data)
                except zstandard.ZstdError as e:
                    name += '.zst'
                    errors += 1
                    log(name + ' - ' + str(e), tp='E')
                with open(os.path.join(SAVE_PATH, name.replace('/', '\\')), 'wb') as dest:
                    dest.write(data)
            else:
                with open(os.path.join(SAVE_PATH, name.replace('/', '\\')), 'wb') as dest:
                    dest.write(data)
        archive.close()
log(errors, 'errors', tp='I')
log(archive_count, 'archives have been unpacked', tp='I')
