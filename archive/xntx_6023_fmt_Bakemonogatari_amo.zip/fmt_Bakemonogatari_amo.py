from inc_noesis import *
import noesis
import rapi
import tex_Bakemonogatari_amt

def registerNoesisTypes():
	handle = noesis.register("Bakemonogatari Portable", ".AMO")
	noesis.setHandlerTypeCheck(handle, amoCheckType)
	noesis.setHandlerLoadModel(handle, amoLoadModel)
	#noesis.logPopup()
	return 1



def amoCheckType(data):
	bs = NoeBitStream(data)
	magic = bs.readBytes(4).decode("ASCII")
	if magic != '#AMO':
		return 0
	return 1     

def amoLoadModel(data, mdlList):
	ctx = rapi.rpgCreateContext()

	basePath = rapi.getDirForFilePath(rapi.getInputName())
	baseName = rapi.getExtensionlessName(rapi.getLocalFileName(rapi.getInputName()))
	print (baseName)
	print (basePath)
	amtFile = basePath + baseName + (".amt")
	matList = []
	texList = []
	if (rapi.checkFileExists(amtFile)):
		texData = rapi.loadIntoByteArray(amtFile)
		if tex_Bakemonogatari_amt.AMTLoadRGBA(texData, texList) == 1:
			for a in range(0, len(texList)):
				material = NoeMaterial("mat" + str(a), "")
				material.setTexture(texList[a].name)
				material.setFlags(0, 1)
				matList.append(material)
	bs = NoeBitStream(data)
	bs.seek(16, NOESEEK_ABS)
	c1, o1, c2, o2, c3, o3 = bs.read("6I")

	meshName = []
	bs.seek(o3, NOESEEK_ABS)
	for a in range(0, c1):
		meshName.append(bs.readBytes(0x20).decode("ASCII").rstrip("\0"))
	#print(meshName)

	bs.seek(o1, NOESEEK_ABS)
	for a in range(0, c1):
		Info = bs.read("8I")

	bs.seek(o2, NOESEEK_ABS)
	amgOff = bs.read(str(c2) + "I")
	for a in range(0, c2):
		bs.seek(amgOff[a], NOESEEK_ABS)
		amgInfo = bs.read("8I")
		bs.seek(amgOff[a] + amgInfo[5], NOESEEK_ABS)
		chnkInfo = []
		for b in range(0, amgInfo[4]):
			chnkInfo.append(bs.read("12f4B7I"))
		amgMesh = []
		amfBone = []
		for b in range(0, amgInfo[4]):
			bs.seek(amgOff[a] + chnkInfo[b][16], NOESEEK_ABS)
			amgInfo2 = bs.read("8I")
			if amgInfo2[1] != 0:
				amgMesh.append(amgInfo2)
			else:
				amfBone.append(amgInfo2)
		for b in range(0, len(amgMesh)):
			bs.seek(amgOff[a] + amgMesh[b][5], NOESEEK_ABS)
			bs.seek(amgOff[a] + amgMesh[b][1], NOESEEK_ABS);  amgBase = bs.tell()
			meshCount, meshTbl = bs.read("2I")
			bs.seek(amgBase + meshTbl, NOESEEK_ABS)
			meshOff = bs.read(str(meshCount) + "I")
			for c in range(0, meshCount):
				rapi.rpgSetName(str(amgMesh[b][0]) + " - " + str(c))
				bs.seek(amgBase + meshOff[c], NOESEEK_ABS)
				tmp = bs.read("6f")
				bs.seek(0x14, NOESEEK_REL)
				texID = bs.readInt()
				if texID != -1:
					rapi.rpgSetMaterial("mat" + str(texID))
				cUnk0, cUnk1, cUnk2, chnkCount, cUnk3, cUnk4 = bs.read("2I4H")
				for d in range(0, chnkCount):
					meshInfo = bs.read("3IH2B")
					bs.seek(amgBase + meshInfo[1], NOESEEK_ABS)
					pspVert = rapi.decodePSPVert(meshInfo[2])
					if pspVert.uvType == 2:
						rapi.rpgSetUVScaleBias(NoeVec3 ((2.0, 2.0, 1.0)), NoeVec3 ((0.0, 0.0, 0.0)))
					elif pspVert.uvType == 3:
						rapi.rpgSetUVScaleBias(NoeVec3 ((1.0, 1.0, 1.0)), NoeVec3 ((0.0, 0.0, 0.0)))
					vertData = bs.readBytes(pspVert.vertexSize * meshInfo[3])
					if vertData is not None and len(vertData) > 0:
						pspVert.bindBuffers(vertData)
						if meshInfo[4] == 3:
							rapi.rpgCommitTriangles(None, noesis.RPGEODATA_SHORT, meshInfo[3], noesis.RPGEO_TRIANGLE, 1)
						else:
							rapi.rpgCommitTriangles(None, noesis.RPGEODATA_SHORT, meshInfo[3], noesis.RPGEO_TRIANGLE_STRIP, 1)
					bs.seek(amgBase + meshInfo[0], NOESEEK_ABS)
					rapi.rpgClearBufferBinds()


	try:
		mdl = rapi.rpgConstructModel()
	except:
		mdl = NoeModel()
	mdl.setModelMaterials(NoeModelMaterials(texList, matList))
	mdlList.append(mdl)	
	rapi.rpgClearBufferBinds()	
	return 1