#! python3
#doa5 archivarius, a tool for extracting and swaping files in Dead or Alive 5 DLC archives (version 1.8)

######## options ########
show_the_additional_settings_bar                 = True
force_the_decryption_only_for_files_smaller_than = 4000 #"textures.--hl" = 4000, "char.tmcl" = 12000, "stage.tmcl" = 35000
#########################

import glob, os, struct, io, inspect
from time import time
from tkinter import *
from tkinter.filedialog import *
from tkinter.messagebox import *
from time import time
import zlib

listoffiles = []
listofnamesandindices = []
glblnkname = ''

tkwindowname = "'Dead or Alive 5 Last Round' Achivarius v1.8 PC"

#read the doa5 file table if exists
ftablepath = os.path.dirname(inspect.getfile(inspect.currentframe())) + "/doa5LRarchivarius.dat"
unpackedxexpath = os.path.dirname(inspect.getfile(inspect.currentframe())) + "/default.exe"
xexfound = True if os.path.exists(unpackedxexpath) else False
ftable = []
if os.path.exists(ftablepath):
    with open(ftablepath,'r') as f:
        for line in f: ftable.append(line[:-1].split('\t'))#get rid of 'new line' in the end
else: print('Error:', ftablepath, "not found")
ftablenames = [fl[2] for fl in ftable]#make a list of names from ftable

keytecmo = b"Except as expressly authorized, it is strictly prohibited to reproduce, distribute, exhibit or modify this software and any of its contents, including audio and visual contents. By way of example, to capture, copy or download any of the contents in this software, including audio and visual contents, onto any hardware or other software source media for any purpose, by the Internet or any other source, is strictly prohibited. Reversed engineering, decompiling or disassembly of this software is also strictly prohibited."
keytecmo *= 2

ftypesdescriptions = {
    0x0a:'npc on stages (RC_*) tmc',
    0x0b:'npc on stages (RC_*) tmcl',
    0x11:'hair tmc',
    0x12:'hair tmcl',
    0x13:'face tmc',
    0x14:'face tmcl',
    0x15:'debug(low poly) models for characters tmc',
    0x16:'debug(low poly) models for characters tmcl',
    0x19:'costume tmc',
    0x1a:'costume tmcl',
    0x1b:"static'n'animated stage parts (*, 'RG_*') tmc",
    0x1c:"static'n'animated stage parts (*, 'RG_*') tmcl",
    0x27:"stage light effects? ('stg_*', 'rtm_*', 'RS_*', 'chr_*') tmc",
    0x28:"stage light effects? ('stg_*', 'rtm_*', 'RS_*', 'chr_*') tmcl",

    0x08:'empty tex file(for all costumes){*.??C}',
    0x17:'tex file with pants textures(for girls costumes){*.??H}',
    0x18:'tex file with pants textures(for girls costumes){*.??HL}',
    0x24:'phyd character file',
    0x0e:'mpm character animation',
    0x25:'undd stage',
    0x56:'bclip stage',
    0x1e:'mpm stage animation',
    0x00:'ttgl stage',
    0x1f:'scn stage',
    0x24:'phyd (stage)',
    0x1c:'tmcl stage model',
    0x1b:'tmc stage model',
    0x04:'cam stage',

    0x09:'??P (dlc costume selection icon)',
    0x05:'??N unk no magic',
    0x07:'MPM animation',
    0x03:'??M (tag motion files with different extention ?)',
    0x04:'??M unk no magic',
    0x21:'TNF TNFL font file',
    0x22:'bin message file with regional text',
    0x23:'?',
    0x2C:'XWS sound file',
    0x27:'xws char sound file',
    0x28:'xws char stream sound file',
}

class cfile:
    #bin(lnkname,fileid,filename), lnk(lnkoffset,size,zipsize), blp()
    def __init__(self, lnkid, fileid, filenameoffset, lnkname, filename, binoffset):
        self.lnkid = lnkid
        self.fileid = fileid
        self.filenameoffset = filenameoffset
        self.lnkname = lnkname
        self.filename = filename
        self.binoffset = binoffset
    def setfromlnk(self, dataoffset, size, zipsize, lnkoffset, hasblp, bytes10, bytes10unziped):
        self.dataoffset = dataoffset
        self.size = size
        self.zipsize = zipsize
        self.lnkoffset = lnkoffset
        self.hasblp = hasblp
        self.bytes10 = bytes10
        self.bytes10unziped = bytes10unziped
    def setfromftable(self, fttype, ftlnkname, ftfilename, ftrealname, ftsize, ftflags, ftunzipsize, ftchecksumm, isinftable):
        self.fttype = fttype
        self.ftlnkname = ftlnkname
        self.ftrealname = ftrealname
        self.ftsize = ftsize
        self.ftflags = ftflags
        self.ftunzipsize = ftunzipsize
        self.ftchecksumm = ftchecksumm
        self.isinftable = isinftable
    def setfromblp(self, filetableindex, packedsize, packflags, unpackedsize, checksum, blpoffset, linkedblp):
        self.filetableindex = filetableindex
        self.packedsize = packedsize
        self.packflags = packflags
        self.unpackedsize = unpackedsize
        self.checksum = checksum
        self.blpoffset = blpoffset
        self.linkedblp = linkedblp

#'fread' [seek and] read from ONE file just using the format; you have to set the file in fglb first
fglb = {'endian':"<"}#'file' = filehandle
def fread(offset = -1, fmt = 'L', extractifsingle = True):
    global fglb
    if type(offset) is str:
        if type(fmt) is bool:
            extractifsingle = fmt
        fmt = offset
    elif offset != -1:
        fglb['file'].seek(offset)
    result = struct.unpack(fglb['endian'] + fmt, fglb['file'].read(struct.calcsize("!"+fmt)))
    if extractifsingle and len(result) == 1:
        return result[0]
    return result

def freadstring(offset = -1):
    global fglb
    if offset != -1:
        fglb['file'].seek(offset)
    mahbytes = b''
    while True:
        mahbytes += fglb['file'].read(1)
        if mahbytes[-1] == 0:
            result = mahbytes[:-1].decode('ASCII')
            break
    return result

def parseandcollect(binname):
    global glblnkname
    lnkname = binname.replace('.bin','.lnk')
    blpname = binname.replace('.bin','.blp')
    bcmname = binname.replace('.bin','.bcm')
    #check for existence
    if not os.path.exists(lnkname):
        print('doa5 bin file not found or locked by other process', binname)
        return 0
    if not os.path.exists(lnkname):
        print('doa5 lnk file not found or locked by other process', lnkname)
        return 0
    hasblp = True if os.path.exists(blpname) else False
    glblnkname = lnkname

    #parse bin
    global listoffiles
    listoffiles = []
    with open(binname,"rb") as binfile:#just change this to f and comment iobytes
        with io.BytesIO() as f:
            bindata = binfile.read()
            f.write(bindata)#with this it's a little bit faster
            global fglb
            fglb["endian"] = '<'
            fglb["file"] = f
            binmagic, lnksnum, filesnum, lnksinfobase, filesinfobase, lnknamesbase, filenamesbase = fread(0, "4s6L")
            if binmagic != b'LFMO':
                print("Error: wrong magic dword")
                return 0
            if lnksnum > 1: #if multiple lnk archives then pass
                print("multiple lnk archives not supported")
                return 0
            for i in range(filesnum): #iterate through files info and gather filenames
                binoffset = filesinfobase + i*0xC
                lnkid, fileid, filenameoffset = fread(binoffset, "3L")
                i = 0
                while bindata[filenameoffset+i]!=0: i+=1
                filename = bindata[filenameoffset:filenameoffset+i].decode('ASCII')
                if filename[0] == '/': filename = filename[1:]
                currentfile = cfile(lnkid, fileid, filenameoffset, lnkname, filename, binoffset)
                listoffiles.append(currentfile)

    #parse ftable
    ftlinkdict = {}
    for flidx, fl in enumerate(listoffiles):
        if fl.filename in ftablenames:
            ftindex = ftablenames.index(fl.filename)
            fttype, ftlnkname, ftfilename, ftrealname, ftsize, ftflags, ftunzipsize, ftchecksumm = ftable[ftindex]
            fttype = int(fttype, 16)
            ftflags = int(ftflags, 16)
            ftsize = int(ftsize, 16)
            ftunzipsize = int(ftunzipsize, 16)
            ftchecksumm = int(ftchecksumm, 16)
            fl.setfromftable(fttype, ftlnkname, ftfilename, ftrealname, ftsize, ftflags, ftunzipsize, ftchecksumm, True)
            ftlinkdict[ftindex] = flidx
        else:
            fl.isinftable = False

    #parse lnk
    with open(lnkname,"rb") as f:
        fglb["file"] = f
        lnkmagic, u0, filescount, u1, lnksize, u2, u3 = fread(0, "4s6L")
        for fl in listoffiles: #read lnk info to class
            lnkoffset = 0x1c + fl.fileid*0x20
            u0, foffset, u1, fsize, u2, fzippedsize, u3, u4 = fread(lnkoffset, "8L")
            bytes10 = bytes(fread(foffset, '16B'))
            bytes10unziped = struct.unpack(">L",bytes10[:4])[0] if bytes10[8:10] == b'\x78\x9C' else 0
            fl.setfromlnk(foffset, fsize, fzippedsize, lnkoffset, hasblp, bytes10, bytes10unziped)

    #parse bcm (not used)
    bcmlist = []
    if os.path.exists(bcmname):
         with open(bcmname, 'rb') as f:
            fglb["file"] = f
            bcmversion, bcmfilesnum, bcmunknown = fread(0, "BBH")
            for i in range(bcmfilesnum): #read bcm info to list
                bcmoffset = 4 + i*2
                bcmchar, bcmcos = fread(bcmoffset, "BB")
                bcmlist.append((bcmchar,bcmcos))

    #parse blp
    for fl in listoffiles: #prepare variable
        fl.linkedblp = False
    if hasblp:
        with open(blpname, 'rb') as f:
            fglb["file"] = f
            blplinks = []
            blpmagic, blpfilesnum, blpheadersize, blpsize = fread(0, "4s3L")
            blplist = [fread("5L") for i in range(blpfilesnum)]
            solvedblps = []
            for i,(filetableindex, packedsize, packflags, unpackedsize, checksum) in enumerate(blplist): #read blp info to list

                blpoffset = blpheadersize + i*0x14
                if filetableindex in ftlinkdict:# and packedsize == listoffiles[ftlinkdict[filetableindex]].size:
                    listoffiles[ftlinkdict[filetableindex]].setfromblp(filetableindex, packedsize, packflags, unpackedsize, checksum, blpoffset, True)
                    solvedblps.append(filetableindex)
                else:
                    blplinks.append("0x%x"%blpoffset)
            if blplinks:#todo: link the blps to filelist by unique packed sizes
                blpsizes = [blp[1] for blp in blplist if blp[0] not in solvedblps]
                blpsizesback = [blp for blp in blplist if blp[0] not in solvedblps]
                for fl in listoffiles:
                    if fl.linkedblp == False and blpsizes.count(fl.size) == 1:
                        blpindex = blplist.index(blpsizesback[blpsizes.index(fl.size)])
                        blpoffset = blpindex*0x14+blpheadersize
                        filetableindex, packedsize, packflags, unpackedsize, checksum = blplist[blpindex]
                        fl.setfromblp(filetableindex, packedsize, packflags, unpackedsize, checksum, blpoffset, True)
                        if "0x%x"%blpoffset in blplinks: blplinks.remove("0x%x"%blpoffset)
            if blplinks: print('unlinked blp at:', blplinks)

    return 1

def selectlnkbin(texlist, lnklabel, fndentry, showrealnames):
    props = {'filetypes':[("DoA5 DLC bin/lnk/blp containers", '*.bin')], 'title':'Open a DoA5 DLC lnk/bin/blp File'}#DoA5/NG3 bin/lnk containers      Open a TeamNinja DoA5/NG3 lnk/bin File
    infile = askopenfilename(**props)
    if infile != "":
        lnklabel['text'] = infile
        os.chdir(os.path.dirname(infile))
        if parseandcollect(infile):
            populatetexlist(texlist, fndentry, showrealnames)

def populatetexlist(texlist, fndentry, showrealnames):
        #populate the injector's files list
        global listofnamesandindices
        listofnamesandindices = []
        texlist.delete(0, END)
        for i, finfo in enumerate(listoffiles):
            if showrealnames and finfo.isinftable and finfo.ftrealname:
                listofnamesandindices.append((finfo.ftrealname.upper(), i))
            else:
                listofnamesandindices.append((finfo.filename.upper(), i))
        if fndentry:
            for fname, i in reversed(listofnamesandindices):
                if fndentry not in fname:
                    listofnamesandindices.pop(i)
        listofnamesandindices.sort()
        for enum, (fname, i) in enumerate(listofnamesandindices):
            texlist.insert(END, fname)
            if not listoffiles[i].isinftable and not listoffiles[i].linkedblp:
                texlist.itemconfig(enum, bg="#ffeeff")#set color background for selected item(ffbbbb)

        texlist['height'] = min(len(listoffiles), 36)
        if len(texlist.curselection()) == 0:
            texlist.selection_set(0)

def tlonselect(e, texlist):#text list on select
    if len(texlist.curselection()) == 0:
        return 0
    getindex = listofnamesandindices[int(texlist.curselection()[0])][1]
    fl = listoffiles[getindex]
    outprint = 0
    if outprint == 1:#dat table
        if fl.linkedblp:
            print('0xFF\chara_dlccos_none\t',fl.filename, '\tnamename\t', "%x\t"%fl.packedsize, sep='')
    if outprint == 2:#openoffice table
        pass
    else:#normal
        print("\r\n####################################\r\n")
    ##    print("lnkid", fl.lnkid)
        print("file index in 'bin' = ", fl.fileid)
    ##    print("lnkname", fl.lnkname)
        print("filename = ", fl.filename)
        print("file name offset in 'bin' = 0x%x"%fl.filenameoffset)
        print("info offset in bin = 0x%x"%fl.binoffset)

        print("unpacked size in 'lnk' = ", fl.size)
        print("packed size in 'lnk'  =  ", fl.zipsize)
        print("info offset in 'lnk' = 0x%x"%fl.lnkoffset)
        print("data offset in 'lnk' = 0x%x"%fl.dataoffset)
        print("10 bytes of data = ", fl.bytes10)
        if fl.bytes10unziped:
            print("unziped size in '10 bytes of data' = ", fl.bytes10unziped)

        if fl.isinftable:
            fltypedescription = "(no description for this file type)"
            if fl.fttype in ftypesdescriptions:
                fltypedescription = ">>> " + ftypesdescriptions[fl.fttype]
            print("file type = 0x%x"%fl.fttype, fltypedescription)
            print("assigned location = ", fl.ftlnkname)
            print("guessed name = ", fl.ftrealname)
            if not fl.linkedblp:
                if fl.ftsize != fl.ftunzipsize:
                    print("packed size in 'file table' = ", fl.ftsize)
                    print("packflags in 'file table' = 0x%x"%fl.ftflags)
                    print("unpacked size in 'file table' = ", fl.ftunzipsize)
                    print("checksum in 'file table' = 0x%x"%fl.ftchecksumm)
                else:
                    print("size in 'file table' = ", fl.ftsize, "(file table says that this file is unpacked)")

        else:
        	print("!!! not found in doa5 file's table")

        if fl.linkedblp:
            print("info offset in 'blp' = 0x%x"%fl.blpoffset)
            if fl.packflags:
                print("ftable order in 'blp' = ", fl.filetableindex)
                print("packed size in 'blp' = ", fl.packedsize)
                print("packflags in 'blp' = 0x%x"%fl.packflags)
                print("unpacked size in 'blp' = ", fl.unpackedsize)
                print("checksum in 'blp' = 0x%x"%fl.checksum)
            else:
                print("ftable order in 'blp' = ", fl.filetableindex)
                print("size in 'blp' = ", fl.packedsize, "(blp says that this file is unpacked)")
        else:
        	print("!!! has no linked blp")

def swapselected(texlist, noteinject):
    if len(texlist.curselection()):
        listindex = int(texlist.curselection()[0])
        flr = [listoffiles[listofnamesandindices[listindex][1]]]
        fl = flr[0]
        texlist.itemconfig(listindex, bg="#ffbbbb")#set color background for selected item(ffbbbb)
        blpname = glblnkname.replace('.lnk','.blp')
        cdlnks = ["NO_LINK","common","chara_common","chara_rtm","message","rtm_common","sprite_common","sprite_ingame","stage_common","stage_debug","stage_rtm"]
        if os.path.exists(blpname) and not fl.linkedblp:
            tmsg = ("injection aborted", "autodetection, of this file inside *.blp, failed.")# (in this case the 'default.xex' executable should be patched directly).\n ")
            print(*tmsg)
            if not noteinject:showinfo(*tmsg)
            return
        elif not fl.isinftable and not fl.hasblp:
            tmsg = ("injection aborted:", blpname+" file is not found for this dlc file")
            print(*tmsg)
            if not noteinject:showinfo(*tmsg)
            return
        elif fl.isinftable and fl.ftlnkname in cdlnks and xexfound == False:
            tmsg = ("injection aborted:", "'"+unpackedxexpath+"' is not found, thus this file can't be injected(to CD lnk) \n use 'xextool' to unpack the 'default.xex' to 'default.exe' and put it in the same directory as this script, after patching encrypt the 'default.exe' back to 'default.xex', and write it back to the disc along with the patched lnk file")
            print(*tmsg)
            if not noteinject:showinfo(*tmsg)
            return
        print(xexfound == False)

        texlist.itemconfig(listindex, bg="#ffffbb")#set color background for selected item(ffbbbb)
        props = {'filetypes':[('all files', '.*')], 'title':'Select a file to inject'}
        infile = askopenfilename(**props)
        if infile != "":
            texlist.itemconfig(listindex, bg="#bbffbb")#set color background for selected item(ffbbbb)
            if not noteinject:
                if not askyesno("Ireversible action", "Do you really want to patch the 'lnk' and 'blp' files?\ndon't forget to backup!!!"):
                    return
            fsize = os.stat(infile).st_size
            lnkarchivesize = os.stat(glblnkname).st_size
            with open(infile, 'rb') as fi:
                indata = fi.read()
            if fl.isinftable and fl.ftlnkname in cdlnks:
                with open(unpackedxexpath, 'r+b') as fxex:
                    fxex.seek(0xc8d840 + fl.filetableindex*8)
                    fxex.write(struct.pack('<2L', fsize, 0))
            else:
                with open(blpname, 'r+b') as fblp:
                    fblp.seek(fl.blpoffset + 4)
                    fblp.write(struct.pack('<4L', fsize, 0,0,0))
            with open(glblnkname, 'r+b') as flnk:
                flnk.seek(fl.lnkoffset)
                if fsize > fl.size:
                    flnk.write(struct.pack('<8L', 0, lnkarchivesize, 0,fsize,0,fsize,0,0))#append to the end of lnk
                    flnk.seek(0x10)
                    flnk.write(struct.pack('<L', (lnkarchivesize+fsize)))#add file size to lnk size
                    flnk.seek(0,2)
                    flr[0].dataoffset = lnkarchivesize
                else:
                    flnk.write(struct.pack('<8L', 0, fl.dataoffset, 0,fsize,0,fsize,0,0))
                    flnk.seek(fl.dataoffset)
                flnk.write(indata)
            if fl.isinftable or fl.linkedblp:
                flr[0].checksum = flr[0].unpackedsize = flr[0].packflags = flr[0].ftchecksumm = flr[0].ftunzipsize = flr[0].ftflags = 0
            flr[0].ftsize = flr[0].ftunzipsize = flr[0].packedsize = flr[0].zipsize = flr[0].size = fsize
            flr[0].bytes10 = indata[:0x10]
            print('\nfile injected successfully!')

def unzip(data, notify):
    stime = time()
    inflated = []
    itera = 0
    l = len(data)
    while(data):
        startidx = data.find(b'\x78\x9C', 4, 0x20)
        if data[startidx+2] == data[startidx+3] == 0:
            startidx = data.find(b'\x78\x9C', startidx+4, 0x20)
        if startidx == -1:
            if len(data) > 0x100: #this size is questionable !!
                #data can be unzipped (is this happening when the zipped bigger then unzipped??)
                startidx = data.find(b'\x00\x00\x40\x00', 4, 0x20)                                                      #comment this line to disable processing for unzipped data
                if startidx == -1 or (len(data)-startidx-4)<0x4000:#if unzipped data is not found or is smaller than anounced
                    if not notify:
                        print('finished unzipping prematurelly. file is incomplete: ', hex(len(data)), 'remained from', hex(l))
                else:
                    inflated.append(data[startidx:startidx+0x4000])
                    data = data[startidx+0x4000:]
                    continue
            if not notify:
                print('endzip_', len(data),data)
            break
        else:
            decompress = zlib.decompressobj(-zlib.MAX_WBITS)
            try:
                inflated.append(decompress.decompress(data[startidx+2:]))
            except Exception as ex:
                if not notify:
                    print('error unzipping at chunk', itera, ', position', l-len(data))
                return b''
            data = decompress.unused_data
            inflated.append(decompress.flush())
        itera += 1
    if not notify:
        print('unziped in %.2f'%(time() - stime))
    return b''.join(inflated)

def unxorkeys(key, data):
    key = (key*(len(data)//len(key)+1))[:len(data)]
    buff = [(dd ^ kk) for dd, kk in zip(data, key)]
    return bytes(buff)

def unxor(key, data, notify):
    stime = time()
    key = (key*(len(data)//len(key)+1))[:len(data)]
    buff = [((dd ^ kk) if (dd and dd != kk) else dd) for dd, kk in zip(data, key)]
    if not notify:
        print('unxored in %.2f'%(time() - stime))
    return bytes(buff)

def findkeys(fdata):
    longtecmokey = keytecmo*(len(fdata)//len(keytecmo)+1) #don't need to shorten it here coz it's not used for xoring
    starts = []
    keys = []
    l = len(fdata)
    start = end = l - 3
    itera = 0
    while (start-2):
        start = fdata[:end].rfind(b'\x00\x00')#should be divisible by 0x10
        end = start
        if start%0x10==2 and fdata[start]==fdata[start+1]==0 and fdata[start+2]!=0:
            starts.append(start-2)
            itera += 1
            if itera == 100:
                break   #100 keys should be enough

    for sti, start in enumerate(starts):
        end = starts[sti-1] if sti > 0 else l-1
        while fdata[end-1] == 0:
            end -= 1
        size = end-start+1 - 5+0x8000
        
        c1 = fdata[0+start] ^ longtecmokey[0+start] ^ (size & 0xFF)
        c2 = fdata[1+start] ^ longtecmokey[1+start] ^ (size // 0x100)
        c5 = fdata[4+start] ^ longtecmokey[4+start] ^ 0x78
        c6 = fdata[5+start] ^ longtecmokey[5+start] ^ 0x9C

        if c2==c5:
            if start%3 == 0: ykey = bytes([c1,c2,c6])          
            elif start%3 == 1: ykey = bytes([c6,c1,c2])
            elif start%3 == 2: ykey = bytes([c5,c6,c1])
            keys.append(ykey)

    #get 3 keys by apearance in keys
    ap = [(keys.count(k),k) for k in set(keys)]
    ap.sort(reverse=True)
    ap = ap[:3]
    ap = [b for a,b in ap]

    return ap

def extractselected(texlist, notify, decryptall):
    if len(texlist.curselection()):
        selindex = listofnamesandindices[int(texlist.curselection()[0])][1]
        nametosave = listofnamesandindices[int(texlist.curselection()[0])][0]
        props = {'filetypes':[('all files', '.*')], 'title':'Save extracted file', 'initialfile':nametosave}
        outfile = asksaveasfilename(**props)
        if outfile != "":
            print(nametosave)
            os.chdir(os.path.dirname(outfile))
            extractnow(outfile, selindex, notify, decryptall)

def extractfiltered(texlist,root,decryptall): #extract all files filtered by the "search entry"
    if len(texlist.curselection()):
        props = {'title':'Save Folder'}
        dpath = askdirectory(**props)
        failedfiles = []
        print()
        if dpath != "":
            os.chdir(dpath)
            root.title("this will be slow!    you have to be very patient...")
            stime = time()
            allf = len(listofnamesandindices)
            for enum, (nametosave,selindex) in enumerate(listofnamesandindices):
                print("%dof%d "%(enum+1,allf) , nametosave, end = "")
                outfile = dpath + '/' + nametosave
                if not extractnow(outfile, selindex, True, decryptall):
                    failedfiles.append(nametosave)
                print()
            print("\n\t!!! FINALLY I'M DONE !!! \t(in %.0f seconds)\n"%(time() - stime))
            if failedfiles:
                print("files i couldn't 'decrypt':", *failedfiles, sep = "\n")
            root.title(tkwindowname)

def extractnow(outfile, selindex, notify, decryptall):
    fl = listoffiles[selindex]

    with open(glblnkname, 'rb') as f:
        f.seek(fl.dataoffset)
        fdata = f.read(fl.size)
        #handle data (unxor/upack)
        if fdata[8:10] == b'\x78\x9C':
            print(" #", end = "")
            fdata = unxor(keytecmo, unzip(fdata,notify), notify)
        else:
            #handle the "force the decryption" option
            fdecryptok = (decryptall and int.from_bytes(fl.bytes10[:4], 'big') < force_the_decryption_only_for_files_smaller_than)
            if fl.linkedblp or fl.isinftable or fdecryptok:
                fflags = fl.ftflags if fl.isinftable else fl.packflags
                fflag = ("%x"%(fflags & 0xFFFF0000))[0]
                if fflag in ('e', 'c') or fdecryptok:
                    print(" *", end = "")

                    #create key and unzip
                    fdata = fdata[4:]

                    keys = findkeys(fdata)

                    #if outfile[-4:] == ".--H": #if h type: then generate 2 bytes key as a resort key (also worked for .TMC)
                    c5 = fdata[4] ^ keytecmo[4] ^ 0x78
                    c6 = fdata[5] ^ keytecmo[5] ^ 0x9C
                    hkey = bytes([c5,c6])
                    keys = keys+[hkey]

                    for enumk,key in enumerate(keys):
                        if not notify:
                            print("\nkey%d = "%(enumk+1), *["%02X"%b for b in key], sep="")

                        key1 = unxorkeys(key, keytecmo)
                        data2 = unxor(key1, fdata, notify)
                        fdata2 = unzip(data2, notify)
                        if fdata2 == b'':
                             if not notify:
                                print("Error, key generation failed.", end = "")
                             if enumk != len(keys)-1:
                                if not notify:
                                    print(" Retry with another key", end = "")
                             else:
                                print("\t!!\tError, key generation failed.", end = "")
                                if not notify:
                                    print()
                                    showinfo("Error", "key generation failed")
                                return  False  #no more keys, get out of here
                        else:
                            fdata = fdata2
                            break

        #write data
        with open(outfile, 'wb') as fs:
            fs.write(fdata)
    return True

def main():
    root = Tk()
    root.title(tkwindowname)

    injector = IntVar()
    noteinject = IntVar()
    decryptall  = IntVar()
    showrealnames = IntVar()
    showrealnames.set(1)

    fr1 = Frame()
    fr1.pack(fill=X)
    fr11 = Frame(fr1)
    fr11.pack(fill=X)
    Button(fr11, text='open bin/lnk', font='sans 11', command=lambda:selectlnkbin(texlist, lnklabel, fndentry.get().upper(), showrealnames.get())).pack(side = 'left')
    lnklabel = Label(fr11, text='press "open bin/lnk" button to select a DoA5U packed file to work with', fg='brown')
    lnklabel.pack()
    fr12 = Frame()
    texlist=Listbox(fr12, height=36, width=82, font='courier 9')
    texlist.bind('<<ListboxSelect>>', lambda x:tlonselect(x, texlist))
    texlist.pack(side='left', fill=BOTH, expand=True)
    scroolbarframe = Frame(fr12)
    scroolbarframe.pack(fill=Y, expand=True)
    vscrollbar = Scrollbar(scroolbarframe, command=texlist.yview)
    vscrollbar.pack(side=RIGHT, fill=Y, expand=True)
    texlist['yscrollcommand'] = vscrollbar.set

    optbarframe = Frame()
    optbarframe.pack()
    extoptbarframe = Frame()
    if show_the_additional_settings_bar:
        extoptbarframe.pack(fill=X, expand=True)
    fr12.pack(fill=BOTH, expand=True)

    Button(optbarframe, text='swap selected', font='sans 11', command=lambda:swapselected(texlist, noteinject.get())).pack(side = 'right')
    Button(optbarframe, text='extract selected', font='sans 11', command=lambda:extractselected(texlist,noteinject.get(), decryptall.get())).pack(side = 'right')
    Button(optbarframe, text='extract all', font='sans 11', command=lambda:extractfiltered(texlist,root,decryptall.get())).pack(side = 'right')
    Checkbutton(optbarframe, text="i hate dialog boxes", variable=noteinject).pack(side = 'left')
    fndentry = Entry(optbarframe, width = 10)
    fndentry.bind("<KeyRelease>", lambda x:populatetexlist(texlist, fndentry.get().upper(), showrealnames.get()))
    fndentry.pack(side='left')
    Checkbutton(optbarframe, text="Show Real Names", variable=showrealnames, command=lambda:populatetexlist(texlist, fndentry.get().upper(), showrealnames.get())).pack(side = 'left')
##    Label(optbarframe, text="don't forget to backup!!!", font='sans 12', fg='red').pack()
    Checkbutton(extoptbarframe, text="force the decryption for files smaller then %.0f Mb"%(force_the_decryption_only_for_files_smaller_than/1000), variable=decryptall).pack(side = 'left')

    root.mainloop()

if __name__ == '__main__':
    main()
    print("end()")