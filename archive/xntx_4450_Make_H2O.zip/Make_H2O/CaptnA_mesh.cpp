void SM_of_CA_mesh_loop(HWND hwnd, char szPathname[], DWORD dwStart)      // scanning the submeshes params for Captn America
{                                                                         // only model tested
   char * pFBuf ;
   BYTE * pByte, cnt, i ;
   int nValue[16] ;
   WORD wLo, wHi, wFaceIndCnt, wVertsCnt, wOffs2VBlock ;         //
   DWORD addrFI, addrUV, addrV, j, jOld, offs2 ;  //
   char lines[6][20]= {"","Vb1","12 99","","120300",""} ;
   bool bStop= false ;

   pFBuf = (char *) lpFBuf ; j= 0 ;
   //dwStart = 0 ;                                        // unneeded here
   //pFBuf += dwStart ;

   cnt= 0 ; j= 0 ;
   do {
        nValue[0]= 0; nValue[1]= 6; nValue[2]= 0; nValue[3]= 0xFF;		// assumed signature of submesh header
        nValue[4]= 0x12; nValue[5]= 0;
        offs2 = FindBytes(lpFBuf, j, dwFileSize-j, nValue, 6) ;
        if (offs2!=0) {
            pFBuf += offs2 ; j += offs2 ;
            pFBuf += 6 ; j += 6 ;                               // skip signature bytes
            pByte = (BYTE*) &wVertsCnt ;    			        // get vertex count
            for (i=0;i<2;i++) {									//
                *pByte = *pFBuf &255 ; pByte++; pFBuf++; j++ ;
            }
            wLo= wVertsCnt % 256 ; wHi= wVertsCnt / 256 ;       // little to big endian correction
            wVertsCnt= wLo * 256 + wHi ;
            pByte = (BYTE*) &wFaceIndCnt ;						//
            for (i=0;i<2;i++) {									//
                *pByte = *pFBuf &255 ; pByte++; pFBuf++; j++ ;
            }
            wLo= wFaceIndCnt % 256 ; wHi= wFaceIndCnt / 256 ;   // little to big endian correction
            wFaceIndCnt= wLo * 256 + wHi ;
            pFBuf += 14*16 + 4 ; j += 14*16 + 4;                // simply skip bytes before face indices block
            addrFI= j ;                                         //  (or search for 0000 0001 0002?)
            pFBuf += wFaceIndCnt * 2 ; j += wFaceIndCnt * 2 ;   // skip face indices
            jOld= j ; j = dataAlignment(j) ;                   // data alignment
            pFBuf += (j-jOld) ;                                 // don't forget to update the pointer
            // now we are at start of vertex block (are we?)
            addrV = j ;
            pFBuf += wVertsCnt * 12 ; j += wVertsCnt * 12 ;
            fprintf(stream, "SM %d, UV block: 0x%x\n", cnt, j) ;
            jOld= j ; j = dataAlignment(j) ;                   // data alignment
            pFBuf += (j-jOld) ;                                 // don't forget to update the pointer
            // point to fst uv set
            addrUV = j + 24 ;     //
            create_H2O(szPathname, cnt, lines, addrFI, wFaceIndCnt, addrUV, 40, addrV, wVertsCnt, 2) ;
            pFBuf += wVertsCnt * 40 ; j += wVertsCnt * 40 ;     // skip uvs (and other) block
            jOld= j ; j = dataAlignment(j) ;                   // data alignment
            pFBuf += (j-jOld) ;
            pFBuf += wVertsCnt * 8 ; j += wVertsCnt * 8 ;       // skip unknown block
            jOld= j ; j = dataAlignment(j) ;                   // data alignment
            pFBuf += (j-jOld) ;                                 // don't forget to update the pointer
            //offs += 96 ;                          // skip unknown bytes
        }
        else {                      // sadly we don't have control, when there's no "MHDR" in the file
            create_H2O(szPathname, cnt, lines, addrFI, wFaceIndCnt, addrUV, 40, addrV, wVertsCnt, 2) ;
            bStop= true ;
        }
        cnt++ ;                                                 // next submesh
   } while (!bStop&&(j<dwFileSize)) ;

   if (strlen(szErrMess)>17) MessageBox(NULL, szErrMess, "error", MB_ICONINFORMATION);
}