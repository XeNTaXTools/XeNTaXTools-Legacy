#include <windows.h>

#include <stdio.h>		// FILE
#include <math.h>		//
#include "Main.h"

static char g_szClassName[] = "MyWindowClass";
static HINSTANCE g_hInst = NULL;

#define IDC_MAIN_TEXT   1001
#define bool BOOL
#define false FALSE
#define true TRUE
#define ID_LIST     1
#define ID_EDIT     2
#define ID_BUTTON1  3


#define FILENAME  TEXT("MakeH2O_log.txt")

#define chDIMOF(Array) (sizeof(Array) / sizeof(Array[0]))
__inline void chMB(PCSTR s) {
   char szTMP[128];
   GetModuleFileNameA(NULL, szTMP, chDIMOF(szTMP));
   MessageBoxA(GetActiveWindow(), s, szTMP, MB_OK);
}

BYTE model = 3 ;    // 1: MLX, 2: Capt'n America, 3: Sly Cooper TiT

char szErrMess[127]= "error in H20 no: " ;    // about 20 MB static file buffer for model files
DWORD dwFileSize, dwStart ;
FILE *stream ;          // for logfile (unused so far)
LPVOID lpFBuf ;         // pointer to file buffer

bool create_H2O(char szPathname[], BYTE no, char lines[][20], DWORD addrFI, DWORD dwFaceIndCnt, DWORD addrUV, BYTE sizeUVB, DWORD addrV, DWORD dwVertsCnt, BYTE mode)
{                                                                                   // modi: 0= seq. mode, 1=VBlock, 2= mixed mode
	FILE * stream ;  // local
	char szH2O[256], szNo[4], szTmp[12] ;

    // upset about the use of "unsafe" strcpy/strcat? -> noone hinders u to rewrite this
    // but the code until "return" doesn't require a change for other models!
    _itoa(no, szNo, 10) ;           // number of next H2O file to be created
    strcpy(szH2O, szPathname) ; strcat(szH2O,"_") ; strcat(szH2O,szNo) ; strcat(szH2O,".h2o") ;
    stream = fopen( szH2O, "w" );
    if( stream == NULL ) {
        printf("%s open error!\n", szH2O) ;
        return (FALSE) ;
    }
    strcpy(lines[0], "0x") ; _itoa(addrFI, szTmp, 16) ; strcat(lines[0], szTmp) ; strcat(lines[0], " ") ;
    _itoa(dwFaceIndCnt, szTmp, 10) ; strcat(lines[0], szTmp) ;
    if (szTmp[0]=='-') {
        //strcat(lines[0], "err") ;
        strcat(szErrMess, szNo) ; strcat(szErrMess, ", ") ;
    }
    fprintf(stream, "%s\n", lines[0]) ;
    fprintf(stream, "%s\n%s\n", lines[1], lines[2]) ;
    strcpy(lines[3], "0x") ; _itoa(addrV, szTmp, 16) ; strcat(lines[3], szTmp) ; strcat(lines[3], " ") ;
    _itoa(dwVertsCnt, szTmp, 10) ; strcat(lines[3], szTmp) ;
    if (szTmp[0]=='-') {
        strcat(szErrMess, szNo) ; strcat(szErrMess, ", ") ;
    }
    fprintf(stream, "%s\n%s\n", lines[3], lines[4]) ;
    if (mode==2) {    // 'mixed mode' has a separate UV block
        strcpy(lines[5], "0x") ; _itoa(addrUV, szTmp, 16) ; strcat(lines[5], szTmp) ; strcat(lines[5], " ") ;
        _itoa(sizeUVB, szTmp, 10) ; strcat(lines[5], szTmp) ;
        if (szTmp[0]=='-') {
            strcat(szErrMess, szNo) ; strcat(szErrMess, ", ") ;
        }
    }
    fprintf(stream, "%s\n", lines[5]) ;
	fclose (stream) ;
	return true ;
}

bool show_table(DWORD dwStart)			// crappy code, I know, but: works
{					//
	char * pFBuf ;			//
	BYTE i ;
	int cnt=0, l, nValue[8] ;			//
	DWORD j ;		//

	pFBuf = (char *) lpFBuf ;           // start of file buffer
	pFBuf += dwStart ; j= 0 ; l= 0 ;

	for (l=0;l<100;l++) {				// 100 entries a 8 DWORDs
		for (cnt=0;cnt<8;cnt++) {
			for (i=0;i<4;i++) {									// 1x DWord
				nValue[i] = (*pFBuf & 255) ; pFBuf++ ; j++ ;
			}
			if (nValue[2]!=0) fprintf( stream, "    x") ;
			else fprintf( stream, "%5d", nValue[0] + nValue[1]*256) ;       // little endian
			fprintf( stream, " ") ;
		}
		fprintf( stream, "\n") ;
	}
	fprintf( stream, "0x%x\n", dwStart+j) ;
	return true ;
}

void SM_of_MLX_loop(HWND hwnd, char szPathname[], DWORD dwStart)      // scanning the submeshes params in the MLX table
{
   //char * pFBuf ;
   //BYTE * pByte, cnt, i ;

   //DWORD deltaFI, deltaV, dwFaceIndCnt, dwFICntLast=0, dwVertsCnt, dwVCntLast=0, addrFI=0x124D0, addrV=0x1BC20, j ;

   chMB("MLX not included, sry!\nMaybe released when working for more than one model.") ;
}

DWORD dataAlignment(DWORD j){
    int cnt ;

    cnt = j/16 ; cnt++ ;
    if ((j%16)!=0) { j = cnt*16 ; }
    return j ;
}
void GetDW(char * &pFBuf, DWORD &j, DWORD &dw, bool bBigE) {
    BYTE * pByte, i ;
    WORD wLo, wHi ;

    pByte = (BYTE*) &dw ;    			        // get vertex count
    for (i=0;i<4;i++) {									//
        *pByte = *pFBuf &255 ; pByte++; pFBuf++; j++ ;
    }
    if (bBigE) {                    // �h, das is aber DW!
        wLo= dw % 256 ; wHi= dw / 256 ;           // little to big endian correction
        dw= wLo * 256 + wHi ;
    }
}
void GetWord(char * &pFBuf, DWORD &j, WORD &w, bool bBigE) {
    BYTE * pByte, i ;
    WORD wLo, wHi ;

    pByte = (BYTE*) &w ;
    for (i=0;i<2;i++) {
        *pByte = *pFBuf &255 ; pByte++; pFBuf++; j++ ;
    }
    if (bBigE) {
        wLo= w % 256 ; wHi= w / 256 ;           // little to big endian correction
        w= wLo * 256 + wHi ;
    }
}

void SM_of_CA_mesh_loop(HWND hwnd, char szPathname[], DWORD dwStart)      // scanning the submeshes params for Captn America
{                                                                         // only model tested
   char * pFBuf, *pTmp, szNo[4] ;
   BYTE cnt ;
   int delta, nValue[16] ;
   WORD wFaceIndCnt, wVertsCnt, wOffs2VBlock ;         //
   DWORD addrFI=0, addrUV, addrV, j, jOld, lastJ, offs2 ;  //
   char lines[6][20]= {"","Vb1","12 99","","120300",""} ;
   bool bStop= false ;

   pFBuf = (char *) lpFBuf ; pTmp= pFBuf ;
   //dwStart = 0 ;                                        // unneeded here
   //pFBuf += dwStart ;
   SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " creating H2O files:") ;
   cnt= 0 ; lastJ= 0 ;
   do {
        pFBuf= pTmp ; j= lastJ ;                                // restore from previous run
        nValue[0]= 0; nValue[1]= 6; nValue[2]= 0; nValue[3]= 0xFF;		// assumed signature of submesh header
        nValue[4]= 0x12; nValue[5]= 0;
        offs2 = FindBytes(lpFBuf, j, dwFileSize-j, nValue, 6) ;
        if (offs2!=0) {
            pFBuf += offs2 ; j += offs2 ;
            pFBuf += 6 ; j += 6 ;                               // skip signature bytes
            GetWord(pFBuf, j, wVertsCnt, true) ;   			            // get vertex count
            GetWord(pFBuf, j, wFaceIndCnt, true) ;
            pFBuf += 8 ; j += 8 ;                               // skip FFFFFFFF and 4 bytes
            GetWord(pFBuf, j, wOffs2VBlock, true) ;
            pTmp= pFBuf ; lastJ= j ;                            // backup current file buffer pos
            delta= j - addrFI ;                                 // addrFI from previous run
            if (delta<=0) {                                     // avoid finding the same addrFI again
                pFBuf -= delta ; j -= delta ;
                pFBuf++ ; j++ ;
            }
                    //pFBuf += 14*16 + 4 ; j += 14*16 + 4;            // simply skip bytes before face indices block; nope
            nValue[0]= 0; nValue[1]= 0; nValue[2]= 0; nValue[3]= 1;	  // first face
            nValue[4]= 0; nValue[5]= 2;
            offs2 = FindBytes(lpFBuf, j, dwFileSize-j, nValue, 6) ;
            if (offs2!=0) {
                pFBuf += offs2 ; j += offs2 ;
                addrFI= j ;                                         //
                pFBuf += wFaceIndCnt * 2 ; j += wFaceIndCnt * 2 ;   // skip face indices
                jOld= j ; j = dataAlignment(j) ;                   // data alignment
                pFBuf += (j-jOld) ;                                 // don't forget to update the pointer
                // now we are at start of vertex block (are we?)
                addrV = j ;
                pFBuf += wVertsCnt * 12 ; j += wVertsCnt * 12 ;
                fprintf(stream, "SM %d, UV block: 0x%x\n", cnt, j) ;
                jOld= j ; j = dataAlignment(j) ;                   // data alignment
                pFBuf += (j-jOld) ;                                 // don't forget to update the pointer
                // point to fst uv set
                addrUV = j + 24 ;     //
                _itoa(cnt, szNo, 10) ;
                if (create_H2O(szPathname, cnt, lines, addrFI, wFaceIndCnt, addrUV, 40, addrV, wVertsCnt, 2) )
                    SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) szNo) ;
                else SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " failed") ;
                //  code might come in handy when search for 0000 0001 0002 results in problems
/*                pFBuf += wVertsCnt * 40 ; j += wVertsCnt * 40 ;     // skip uvs (and other) block
                jOld= j ; j = dataAlignment(j) ;                   // data alignment
                pFBuf += (j-jOld) ;
                pFBuf += wVertsCnt * 8 ; j += wVertsCnt * 8 ;      // skip unknown block
                jOld= j ; j = dataAlignment(j) ;                   // data alignment
                pFBuf += (j-jOld) ;                                 // don't forget to update the pointer   */
                    //offs += 96 ;                          // skip unknown bytes
            }
        }
        else bStop= true ;
        cnt++ ;                                                 // next submesh
   } while (!bStop&&(j<dwFileSize)) ;

   if (strlen(szErrMess)>17) MessageBox(NULL, szErrMess, "error", MB_ICONINFORMATION);
}

void SM_of_SlyC_mdl_loop(HWND hwnd, char szPathname[], DWORD dwStart)      // scanning the submeshes params for Mesh_1807
{
   char * pFBuf, szNo[4] ;
   BYTE * pByte, cnt, i ;
   int cnt1, nValue[16] ;        //
   WORD  wFaceIndCnt, wVertsCnt ;
   DWORD addrFI, addrUV, addrV, dwSM_HeaderSize, j, offs2, oldJ ;  //
   bool bStop= false ;

    // ###  line to be changed for other models than MLX! ###
    //char lines[5][20]= {"","Vb1","76 40","021000","0x0 255"} ;                      // [5][16] sollte reichen?
    //char lines[6][20]= {"","Vb1","12 99","","120300",""} ;          // Capt'n A.
    char lines[6][20]= {"","Vb1","26 10","","120201",""} ;            // Sly Cooper TiT

    //0x124D0 1469          this is the ref H2O file for the first submesh of "DL020A_SD002J.MLX"
    //Vb1 -> lines[1]       which you'll get after having found out the format and saving the H2O in hex2obj
    //76 40 -> [2]
    //0x1BC20 701           this line's contents varies (same with first line)
    //021000 -> [4]
    //0x0 255- > [5]

   pFBuf = (char *) lpFBuf ; j= 0 ;
   if ((*pFBuf!=0x4D)&&(*(pFBuf+3)!=0x48)) {
    chMB("This doesn't seem to be a SlyCooper mesh file!") ; return ;
   }
   SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " creating H2O files:") ;
   pFBuf += dwStart ; j += dwStart ;                            // dwStart: start of first submesh at 0x30, from editbox
   addrUV = 0 ;     // zero for VB mode (hex2obj)
   cnt= 0 ;
   do {
        pFBuf += 4 ; j += 4 ;                                   // point to header size
        pByte = (BYTE*) &dwSM_HeaderSize ;						//
        for (i=0;i<4;i++) {									//
            *pByte = *pFBuf &255 ; pByte++; pFBuf++; j++ ;
        }
        if (dwSM_HeaderSize==144) {chMB("headersize= 144: not supported so far.\nbreak...") ; return ;}
        pFBuf++; j++ ;                                          // skip 04
        pByte = (BYTE*) &wVertsCnt ;						    // get vertex count
        for (i=0;i<2;i++) {									//
            *pByte = *pFBuf &255 ; pByte++; pFBuf++; j++ ;
        }
        pByte = (BYTE*) &wFaceIndCnt ;						//
        for (i=0;i<2;i++) {									//
            *pByte = *pFBuf &255 ; pByte++; pFBuf++; j++ ;
        }
        // with cnt==0, first submesh, we are at file offset 0x3D now. We have to skip 123 bytes to vertex start: 0xB8
        //pFBuf += 123 ; j += 123 ;                               // that's the headersize -1
        pFBuf += dwSM_HeaderSize - 1 ; j += (dwSM_HeaderSize -1) ;
        addrV = j ;                                             // parameter (start of vertices) for create_H2O()
        offs2 = wVertsCnt*26 ;                                  // use vertex stride to calculate size of vertex data block
        pFBuf += offs2 ; j += offs2 ; oldJ = j ;                //
        cnt1 = j/4 ; cnt1++ ;
        if ((j%4)!=0) j = cnt1*4 ;                              // 4 byte alignment
        pFBuf += (j-oldJ) ;                                     // yeah, don't forget to update the pointer
            //fprintf( stream, "debug: pos of MDIX=%x?\n", j) ;
        pFBuf += 8 ; j += 8 ;                                   // skip 8 bytes ("MIDX" and DWORD)
        addrFI = j ;
        offs2 = wFaceIndCnt*2 ;                                 // size of face indices block with word indices
        pFBuf += offs2 ; j += offs2 ;                           //
        // we could do a simple byte alignment here, then skip another 8 bytes
        // but I would like to introduce a search feature; we search for "MHDR"
        // j is the current position in the model file
        _itoa(cnt, szNo, 10) ;
        nValue[0]= 0x4D; nValue[1]= 0x48; nValue[2]= 0x44; nValue[3]= 0x52;		// "MHDR": signature start of submesh block
        offs2 = FindBytes(lpFBuf, j, dwFileSize-j, nValue, 4) ;
        if (offs2!=0) {
            pFBuf += offs2 ; j += offs2 ;
                //fprintf( stream, "       pos of MHDR=%x?\n", j) ;
            if (create_H2O(szPathname, cnt, lines, addrFI, wFaceIndCnt, addrUV, 255, addrV, wVertsCnt, 2))
                SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) szNo) ;
            else SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " failed") ;
        }
        else {                      // sadly we don't have control, when there's no "MHDR" in the file
            if (create_H2O(szPathname, cnt, lines, addrFI, wFaceIndCnt, addrUV, 255, addrV, wVertsCnt, 2) )
                SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) szNo) ;
            else SendMessage(GetDlgItem(hwnd, ID_LIST), LB_ADDSTRING, 0, (LPARAM) " failed") ;
            bStop= true ;
        }
        cnt++ ;                                                 // next submesh
   } while (!bStop&&(j<dwFileSize)) ;                //
   if (strlen(szErrMess)>17) MessageBox(NULL, szErrMess, "error", MB_ICONINFORMATION);
}

BOOL CheckValue(HWND hwnd)
{
   BOOL bSuccess = FALSE;
   BOOL bErr = false ;      //
   char szText[2][8] ;      //
   char *stopStr ;          //
   signed long slTmp ;
   DWORD dwTextLength;

    GetDlgItemText(hwnd, ID_EDIT, (LPTSTR) szText[0], 8 ) ;
    dwTextLength = strlen(szText[0]) ;
    bErr = (dwTextLength==0) ;
    if (bErr)  {
        chMB("editbox must contain a value!") ; return false ;
    }

    slTmp= strtol(szText[0], &stopStr, 16) ;
    if (slTmp>=0) bSuccess = TRUE;
    else {
        chMB("error!\n enter a positive address") ;
        return false ;
    }
    dwStart = (DWORD) slTmp ;
    if (dwStart<=dwFileSize) bSuccess = TRUE;
    else {
        chMB("error!\n address greater than filesize") ;
        return false ;
    }
   return bSuccess;
}

BOOL DoFileOpenSave(HWND hwnd, BOOL bSave)
{
static char szFilter[] =  "model (*.*)\0*.*\0"
                          "All Files (*.*)\0*.*\0\0" ;

   OPENFILENAME ofn;
   char szFileName[MAX_PATH];

   ZeroMemory(&ofn, sizeof(ofn));
   szFileName[0] = 0;

   ofn.lStructSize = sizeof(ofn);
   ofn.hwndOwner = hwnd;
   ofn.lpstrFile = szFileName;
   ofn.nMaxFile = MAX_PATH;

   ofn.lpstrFilter       = szFilter;
	  ofn.lpstrCustomFilter = NULL ;
	  ofn.nMaxCustFilter    = 0 ;
	  ofn.nFilterIndex      = 1L ;
	  ofn.lpstrFile[0] = 0;
	  ofn.lpstrTitle = TEXT("*.* laden") ;
	  ofn.Flags = OFN_EXPLORER | OFN_FILEMUSTEXIST;
	  GetOpenFileName(&ofn);
	  if (strlen((char *) ofn.lpstrFile)!= 0) {
          dwFileSize = _ReadFile(szFileName, lpFBuf, FALSE, stream) ;      // load the model to static buffer
          if (dwFileSize==0) {
              chMB("error: model file size==0!") ; return FALSE ;
          }
          if (CheckValue(hwnd)) {       // check the edit box contents (not required for model 2 so far)
                switch (model) {        // set model in line 28 or make it available via a combo box
                    case 1: SM_of_MLX_loop(hwnd, szFileName, dwStart) ;
                            EnableWindow(GetDlgItem(hwnd, ID_BUTTON1), TRUE) ;
                            break ;// dwStart from Editbox
                    case 2: SM_of_CA_mesh_loop(hwnd, szFileName, dwStart) ;  break ;
                    case 3: SM_of_SlyC_mdl_loop(hwnd, szFileName, dwStart) ;  break ;
                }
          }
	  }
      return (TRUE) ;
   return FALSE;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam)
{
   static HWND  hwndButt1, hwndEdit ;
   static HWND  hwndList ;	// from environ.c
   static RECT  rect ;
   static int   cxChar, cyChar ;
   HDC          hdc ;
   PAINTSTRUCT  ps ;

   switch(Message)
   {
      case WM_CREATE:
           cxChar = LOWORD (GetDialogBaseUnits ()) ;
           cyChar = HIWORD (GetDialogBaseUnits ()) ;
           stream = fopen( FILENAME, "w" );
            if( stream == NULL ) {
                chMB("<MakeH2O_log.txt> creation error!") ;
                DestroyWindow(hwnd);    // we really shouldn't "meet" the fclose()
                break ;                 // from WM_CLOSE
            }
         CreateWindow("EDIT", "",
            WS_CHILD | WS_VISIBLE | WS_HSCROLL | WS_VSCROLL | ES_MULTILINE |
               ES_WANTRETURN,
            CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
            hwnd, (HMENU)IDC_MAIN_TEXT, g_hInst, NULL);

         SendDlgItemMessage(hwnd, IDC_MAIN_TEXT, WM_SETFONT,
            (WPARAM)GetStockObject(DEFAULT_GUI_FONT), MAKELPARAM(TRUE, 0)); // GDI32.lib
            hwndList = CreateWindow (TEXT ("listbox"), NULL,
                              WS_CHILD | WS_VISIBLE | LBS_NOTIFY | WS_VSCROLL | WS_BORDER,
                              cxChar, cyChar ,
                              cxChar * 34 + GetSystemMetrics (SM_CXVSCROLL),
                              cyChar * 8,
                              hwnd, (HMENU) ID_LIST,
                              (HINSTANCE) GetWindowLong (hwnd, GWL_HINSTANCE),
                              NULL) ;
			SendDlgItemMessage(hwnd, ID_LIST, LB_RESETCONTENT, 0, 0L); //
   		    SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM) ">>> create H2O files <<<") ;
			SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM) " editbox: start addr of SM header") ;
			SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM) "               or MLX table") ;
			SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM) " (log file in project dir)") ;
			SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM) "-------------------------------------------------------") ;
			SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM) "") ;

            hwndEdit = CreateWindow (TEXT ("edit"), NULL,
                            WS_CHILD | WS_VISIBLE | WS_BORDER,
                            cxChar+10, cyChar + 134 ,
                            10 * cxChar, cyChar,
                            hwnd, (HMENU) ID_EDIT,
                            (HINSTANCE) GetWindowLong (hwnd, GWL_HINSTANCE),
                        NULL) ;
            switch (model) {        // set model in line 28 or make it available via a combo box
                case 1: SetWindowText (hwndEdit, "10A10");            // table start in "DL020A_SD002J.MLX"
                            break ;
                case 2: SetWindowText (hwndEdit, "0");  break ;
                case 3: SetWindowText (hwndEdit, "30");  break ;        // start of first submesh ("MDHR")
            }

			hwndButt1 = CreateWindow ( TEXT("button"),
                            TEXT ("log table"),         //
                            WS_CHILD | WS_VISIBLE | WS_DISABLED | BS_PUSHBUTTON,
                            cxChar+120, cyChar + 130 ,        //
                            10 * cxChar, 3 * cyChar / 2,
                            hwnd, (HMENU) ID_BUTTON1,
                        ((LPCREATESTRUCT) lParam)->hInstance, NULL) ;
        //SomeFunction("blubb") ;
      break;
      case WM_SIZE:
         //if(wParam != SIZE_MINIMIZED)
           // MoveWindow(GetDlgItem(hwnd, IDC_MAIN_TEXT), 0, 0, LOWORD(lParam),
             //  HIWORD(lParam), TRUE);
      break;
      case WM_PAINT : //return 0 ;
          InvalidateRect (hwnd, &rect, TRUE) ;

          hdc = BeginPaint (hwnd, &ps) ;
          SelectObject (hdc, GetStockObject (SYSTEM_FIXED_FONT)) ;
          SetBkMode (hdc, TRANSPARENT) ;

          //TextOut (hdc, 24 * cxChar, cyChar, szTop, lstrlen (szTop)) ;
          //TextOut (hdc, 24 * cxChar, cyChar, szUnd, lstrlen (szUnd)) ;

          EndPaint (hwnd, &ps) ;
          return 0 ;
      case WM_SETFOCUS:
         SetFocus(GetDlgItem(hwnd, IDC_MAIN_TEXT));
      break;
      case WM_COMMAND:
         switch(LOWORD(wParam))
         {
            case ID_BUTTON1:                    // show_table
                if (CheckValue(hwnd)) {
                   SendDlgItemMessage(hwnd, ID_LIST, LB_RESETCONTENT, 0, 0L);
                   SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM) " (You might log here instead into a file.)") ;
                   if (model==1) show_table(dwStart)  ; // log table to MakeH2O_log.txt
                   else {
                        SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM) " ") ;
                        SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM) " implemented for MLX only") ;
                   }
                }
                return 0 ;

            case CM_FILE_OPEN:
               DoFileOpenSave(hwnd, FALSE);
            break;
            case CM_FILE_SAVEAS:
               //DoFileOpenSaveAs(hwnd, TRUE);
            break;
            case CM_FILE_EXIT:
               PostMessage(hwnd, WM_CLOSE, 0, 0);
            break;
            case CM_ABOUT:
               MessageBox (NULL, "Make_H2O\n  by shak-otay 04/15\n \n Verwendung auf\n  eigene Gefahr!" , "About...", 0);
         }
      break;
      case WM_CLOSE:
         fclose( stream );        // uncomment when log file used
         DestroyWindow(hwnd);
      break;
      case WM_DESTROY:
         PostQuitMessage(0);
      break;
      default:
         return DefWindowProc(hwnd, Message, wParam, lParam);
   }
   return 0;
}


int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
   LPSTR lpCmdLine, int nCmdShow)
{
   WNDCLASSEX WndClass;
   HWND hwnd;
   MSG Msg;

   g_hInst = hInstance;

   WndClass.cbSize        = sizeof(WNDCLASSEX);
   WndClass.style         = 0;
   WndClass.lpfnWndProc   = WndProc;
   WndClass.cbClsExtra    = 0;
   WndClass.cbWndExtra    = 0;
   WndClass.hInstance     = g_hInst;
   WndClass.hIcon         = LoadIcon (hInstance, MAKEINTRESOURCE (5000)) ;//LoadIcon(NULL, IDI_APPLICATION);
   WndClass.hCursor       = LoadCursor(NULL, IDC_ARROW);
   WndClass.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
   WndClass.lpszMenuName  = "MAINMENU";
   WndClass.lpszClassName = g_szClassName;
   WndClass.hIconSm       = LoadIcon (hInstance, MAKEINTRESOURCE (5000)) ;//LoadIcon(NULL, IDI_APPLICATION);

   if(!RegisterClassEx(&WndClass))
   {
      MessageBox(0, "Window Registration Failed!", "Error!",
         MB_ICONEXCLAMATION | MB_OK | MB_SYSTEMMODAL);
      return 0;
   }

   hwnd = CreateWindowEx(
      WS_EX_CLIENTEDGE,
      g_szClassName,
      " Make_H2O",
      WS_OVERLAPPEDWINDOW,
      CW_USEDEFAULT, CW_USEDEFAULT, 320, 240,
      NULL, NULL, g_hInst, NULL);

   if(hwnd == NULL)
   {
      MessageBox(0, "Window Creation Failed!", "Error!",
         MB_ICONEXCLAMATION | MB_OK | MB_SYSTEMMODAL);
      return 0;
   }

   ShowWindow(hwnd, nCmdShow);
   UpdateWindow(hwnd);

   while(GetMessage(&Msg, NULL, 0, 0))
   {
      TranslateMessage(&Msg);
      DispatchMessage(&Msg);
   }
   return Msg.wParam;
}


