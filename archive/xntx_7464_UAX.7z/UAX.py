#//////////////////////////////////////////////////
#PREREQUISITES:
#//////////////////////////////////////////////////

#Place these in the bin\ folder:
#quickbms.exe (QuickBMS) - http://aluigi.altervista.org/quickbms.htm
#extract.exe (Unreal Package Extractor) - https://www.gildor.org/downloads


#//////////////////////////////////////////////////
#USER SETTINGS:
#//////////////////////////////////////////////////

#Replace this with the path to your GameData\Sounds folder.
uaxpath = 'E:\\Steam\\steamapps\\common\\Star Wars Republic Commando\\GameData\\Sounds\\'


#//////////////////////////////////////////////////
#THE CODE:
#//////////////////////////////////////////////////

import os
import shutil
import subprocess
from glob import glob, iglob
workspacepath = os.getcwd() + '\\workspace\\'

def afterslash(string, index):
	return string.rsplit('\\', 1)[index]

try:
	os.mkdir(workspacepath)
except:
	pass

os.chdir(workspacepath)
#Generate list of .UAX files
UAXListGen = os.walk(uaxpath)
UAXList = ['']
for root, dirs, files in UAXListGen:
	for name in files:
		if os.path.join(root, name).endswith('.uax'):
			uax = os.path.join(root, name)
			UAXList.append(uax)
UAXList.pop(0)


for uax in UAXList:
	uaxfilename = uax.rsplit('\\', 1)[1]
	shutil.copyfile(uax, workspacepath + uaxfilename)

	print('Extracting .uax...')
	subprocess.call("..\\bin\\extract.exe " + uaxfilename, shell=True)
	print('Extraction complete!')

	uaxpathdumped = (workspacepath + (uaxfilename.rsplit('.', 1)[0]) + '\\')


	#Generate list of .Sound files
	SoundlistGen = os.walk(uaxpathdumped)
	Soundlist = ['']
	for root, dirs, files in SoundlistGen:
		for name in files:
			if os.path.join(root, name).endswith('.Sound'):
				sound = os.path.join(root, name)
				sound = (sound.replace(uaxpathdumped, ' ')).strip()
				sound = (sound.rsplit('.', 1)[0])
				Soundlist.append(sound)
	Soundlist.pop(0)

	print('Converting .uax to .wav...')
	for soundfile in Soundlist:
		#Trim to header
		subprocess.call('..\\bin\\quickbms.exe ' + '-Y ..\\bin\\RIFF.bms "' + uaxpathdumped + soundfile + '.Sound" "' + uaxpathdumped + soundfile + '.out"', shell=True)

		#Rename output .Sound to .wav
		renin = (uaxpathdumped + soundfile + '.out\\' + afterslash(soundfile, 1) + '.Sound')
		renout = (uaxpathdumped + afterslash(soundfile, 0) + '\\' + afterslash(soundfile, 1) + '.wav')
		os.rename(renin, renout)
	print('Conversion complete!')


#Cleanup
print('Cleaning up...')
cleanupgen = os.walk(workspacepath)
for root, dirs, files in cleanupgen:
	for name in files:
		if os.path.join(root, name).endswith('.wav'):
			file = os.path.join(root, name)
			#print(file)
		else:
			file = os.path.join(root, name)
			os.remove(file)

def listdirs(directory, targetlist):
	for folder in os.listdir(directory):
		d = os.path.join(directory, folder)
		if os.path.isdir(d):
			targetlist.append(d)
			listdirs(d, targetlist)

dirlist = ['']
dirlist.pop(0)
listdirs(workspacepath, dirlist)
for dir in dirlist:
	if len(os.listdir(dir)) == 0: # Check is empty..
		shutil.rmtree(dir) # Delete..
print('Cleanup complete! The script should now exit automatically.')