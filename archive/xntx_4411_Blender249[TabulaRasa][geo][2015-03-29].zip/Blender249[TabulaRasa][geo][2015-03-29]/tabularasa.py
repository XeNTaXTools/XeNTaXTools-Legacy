import newGameLib
reload(newGameLib)
from newGameLib import *
import Blender	
	
	
def ECPG(g):
	#g.debug=True
	mesh=Mesh()
	g.B(1)#material
	chunk=g.word(4)
	size2,unk,unk=g.i(3)
	pos2=g.tell()	
	g.seek(pos2+size2)
	g.tell()
	
	
	
	chunk=g.word(4)#indices
	size3,unk1,unk2=g.i(3)
	pos3=g.tell()
	a=g.i(1)[0]
	#g.debug=False
	mesh.indiceList=g.H(a)
	#g.debug=True
	mesh.TRIANGLE=True
	g.seek(pos3+size3)
	g.tell()
	
	#g.debug=True
	chunk=g.word(4)#TREV
	g.i(3)
	
	chunk=g.word(4)#LCED
	size3,unk,unk=g.i(3)
	pos3=g.tell()
	#g.f(1)
	#stride,vertCount=g.H(2)
	#print 'stride,vertCount:',stride,vertCount
	#chunk=g.word(4)
	#size3,unk,unk=g.i(3)
	a,b=g.i(2)
	vertItem=g.h(b*(a-1))
	print 'vertItem??????:',a,b,vertItem,g.tell()
	e=g.i(1)[0]
	if a==9:stride=80
	elif a==6:stride=48
	else:stride=80
	for n in range(e):	
		pos=g.tell()
		mesh.vertPosList.append(g.f(3))
		if stride==48:
			mesh.skinWeightList.append(g.f(2))
			mesh.skinIndiceList.append(g.B(2))
			g.seek(14,1)
			mesh.vertUVList.append(g.f(2))
		if stride==80:
			mesh.skinWeightList.append(g.f(2))
			mesh.skinIndiceList.append(g.B(2))
			g.seek(18,1)
			mesh.vertUVList.append(g.f(2))
		"""if a==3:
			g.seek(12,1)
			mesh.vertUVList.append(g.f(2))
		if a==5:
			mesh.skinWeightList.append(g.f(2))
			mesh.skinIndiceList.append(g.B(2))
			g.seek(14+12,1)
			mesh.vertUVList.append(g.f(2))
		if a==2:g.seek(12,1)
		if a==4:g.seek(24,1)"""
		"""if stride==44:
			mesh.skinWeightList.append(g.f(2))
			mesh.skinIndiceList.append(g.B(2))
			g.seek(14,1)
			mesh.vertUVList.append(g.f(2))
		if stride==68:
			mesh.skinWeightList.append(g.f(2))
			mesh.skinIndiceList.append(g.B(2))
			g.seek(14,1)
			mesh.vertUVList.append(g.f(2))
		if stride==56:
			#print g.f(11)
			#mesh.skinWeightList.append(g.f(2))
			#mesh.skinIndiceList.append(g.B(2))
			g.seek(12,1)
			mesh.vertUVList.append(g.f(2))
			#break
		if stride==36:
			mesh.skinWeightList.append(g.f(2))
			mesh.skinIndiceList.append(g.B(2))
			mesh.vertUVList.append(g.f(2))
		if stride==32:
			#print g.B(20)
			#mesh.skinWeightList.append(g.f(2))
			#mesh.skinIndiceList.append(g.B(2))
			g.seek(12,1)
			mesh.vertUVList.append(g.f(2))"""
		g.seek(pos+stride)	
	#g.debug=True	
	print 'end'	
	g.tell()	
	skin=Skin()
	mesh.skinList.append(skin)
	if stride in [44,68,80]:
		mesh.boneNameList=skeleton.boneNameList
		mesh.BINDSKELETON='armature'
	#mesh.draw()	
	g.seek(pos2+size2)
	g.tell()
	meshList.append(mesh)
	
def geoParser(filename,g):
	global skeleton,meshList
	chunk=g.word(7)
	skeleton=Skeleton()
	skeleton.ARMATURESPACE=True
	skeleton.NICE=True
	
	#g.debug=True
	while(True):		
		chunk=g.word(4)
		print '-'*20,chunk,g.tell()
		if chunk=='XDOB':
			g.B(5)
			a,b,c=g.i(3)
			for m in range(b):
				g.find('\x00')
		elif chunk=='XOBB':
			g.i(3)
			g.B(1)
			g.f(10)
		elif chunk=='GDPC':
			A=g.i(4)
			print A
			fdpcCount=A[3]
			for m in range(fdpcCount):
				g.word(4)
				B=g.i(5)
				g.f(7)
				for m in range(g.i(1)[0]):
					g.find('\x00')
					g.find('\x00')
			count=g.i(1)[0]
			for m in range(count):
				a,b=g.i(2)
				for n in range(b):
					g.find('\x00')
					g.find('\x00')
			#g.debug=False
		elif chunk=='EKSP':
			g.i(4)
		elif chunk=='NOBP':
			bone=Bone()
			A=g.i(7)
			bone.parentID=A[3]
		elif chunk=='TADB':
			g.i(3)
			bone.name=g.find('\x00')
			g.f(10)
			matrix=Matrix4x4(g.f(16))
			bone.matrix=matrix.invert()
			skeleton.boneList.append(bone)
		elif chunk=='':
			print 'clear'
			break
		else:
			break
	skeleton.draw()

	count=g.i(1)[0]
	for m in range(count):
		chunk=g.word(4)
		print '#'*50,m,chunk,'1'
		size1,unk,unk=g.i(3)
		pos1=g.tell()
		if chunk=='ECPG':			
			meshList=[]
			ECPG(g)
			for mesh in meshList:
				#mesh.boneNameList=boneNameList
				mesh.draw()
		if chunk=='NKSG':		
			meshList=[]
			chunk=g.word(4)
			print chunk
			size2,unk,unk=g.i(3)
			pos2=g.tell()
			ECPG(g)			
			g.seek(pos2+size2)
			print g.tell()	
			count=g.i(1)[0]
			boneNameList=[]
			for n in range(count):	
				boneNameList.append(g.find('\x00'))
			for mesh in meshList:
				mesh.boneNameList=boneNameList
				mesh.draw()
		g.seek(pos1+size1)
		g.tell()
		
	count=g.i(1)[0]
	for m in range(count):
		chunk=g.word(4)
		print '#'*50,m,chunk		
		size1,unk,unk=g.i(3)
		pos1=g.tell()
		if chunk=='ECPG':
			meshList=[]
			#ECPG(g)
			
		if chunk=='NKSG':
			meshList=[]
			chunk=g.word(4)
			size2,unk,unk=g.i(3)
			pos2=g.tell()
			ECPG(g)			
			g.seek(pos2+size2)
			for mesh in meshList:
				#mesh.boneNameList=boneNameList
				#mesh.draw()
				pass
		
		g.seek(pos1+size1)
		g.tell()
		#break
		
	count=g.B(1)[0]
	for m in range(count):
		chunk=g.word(4)
		size,unk,unk=g.i(3)
		pos=g.tell()
		g.seek(pos+size)
		g.tell()
	g.debug=True			
	g.tell()
	g.logClose()
	
	
def anmParser(filename,g):
	g.logOpen()
	#g.debug=True
	chunk=g.word(8)
	action=Action()
	#action.ARMATURESPACE=True
	action.BONESPACE=True
	action.BONESORT=True
	action.skeleton='armature'
	while(True):		
		chunk=g.word(4)
		print chunk
		if chunk=='MINA':
			a,b,c,d=g.i(4)			
			g.B(1)
			for m in range(d):
				bone=ActionBone()
				g.word(8)
				g.i(5)
				chunk=g.word(4)
				bone.name=g.find('\x00')
				print bone.name
				g.B(5)
				frameCount=g.i(1)[0]
				chunk=g.word(4)
				size,unk,unk=g.i(3)
				pos=g.tell()
				if chunk=='TRSK':
					for n in range(frameCount):
						bone.posFrameList.append(n)
						bone.rotFrameList.append(n)
						g.seek(12,1)#scale
						bone.rotKeyList.append(QuatMatrix(g.f(4)).resize4x4())
						bone.posKeyList.append(VectorMatrix(g.f(3)))
						frame=g.f(1)
				if chunk=='TREK':
					for n in range(frameCount):
						bone.posFrameList.append(n)
						bone.rotFrameList.append(n)
						#g.seek(12,1)#scale
						bone.rotKeyList.append(QuatMatrix(g.f(4)).resize4x4())
						bone.posKeyList.append(VectorMatrix(g.f(3)))
						frame=g.f(1)
				action.boneList.append(bone)	
				
				g.seek(pos+size)
				#break
		else:
			print chunk
			break	
	action.draw()
	action.setContext()	
	g.tell()
	g.logClose()	
	
def Parser():	
	filename=input.filename
	print
	print filename
	print
	ext=filename.split('.')[-1].lower()	
	
	if ext=='geo':
		file=open(filename,'rb')
		g=BinaryReader(file)
		#g.logOpen()
		geoParser(filename,g)
		file.close()
		#g.logClose()
	
	if ext=='anm':
		file=open(filename,'rb')
		g=BinaryReader(file)
		anmParser(filename,g)
		file.close()
 
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
	
Blender.Window.FileSelector(openFile,'import','Tabula Rasa: geo - model and skeleton') 