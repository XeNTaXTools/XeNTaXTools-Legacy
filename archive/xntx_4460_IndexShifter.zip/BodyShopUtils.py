def FlipData(dataToFlip, interval, groupByInterval=False):
    flippedData = []
    
    counter = 0
    dataLength = len(dataToFlip)
    
    while counter < dataLength:

        segmentCounter = counter + interval
        groupString = ''
        while segmentCounter > counter:
            segmentCounter = segmentCounter - 1

            if (groupByInterval):
                groupString = groupString + dataToFlip[segmentCounter]
            else:
                flippedData.append(dataToFlip[segmentCounter])
        
        if (groupByInterval):
            flippedData.append(groupString)
            
        counter = counter + interval    
    
    return flippedData
