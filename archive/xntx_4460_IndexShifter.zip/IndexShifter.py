from struct import *
from BodyShopUtils import *

hexByteFlipInterval = 2             # <-- Change this value if needed (int)
hexByteShiftValue = 0               # <-- Value to add/subtract from all bytes (int)
fileName = 'x.txt'                  # <-- File to Import

hexByteArray = []
shiftedValuesString = ''
inputFileString = ''
paddedValuesArray = []
parsedValuesArray = []
    
try:
    inputFile = open(fileName,'r')
    inputFileString = inputFile.read()
    hexByteArray = inputFileString.split(' ')

    flippedHexData = FlipData(hexByteArray, hexByteFlipInterval, True)
    
    for byteString in flippedHexData:
        
        hexAsInt = int(byteString,16)
        if (hexAsInt < 65535):
            hexAsInt = hexAsInt + hexByteShiftValue

        if (hexAsInt < 0):
            hexAsInt = 0

        intAsHex = hex(hexAsInt)[2:].upper()
        paddedHex = str(intAsHex)

        while len(paddedHex) < (hexByteFlipInterval * 2):
            paddedHex = '0' + paddedHex

        paddedValuesArray.append(paddedHex)

    for paddedByte in paddedValuesArray:
        byteString = paddedByte
        c = 0
        while c < hexByteFlipInterval:
            parsedValuesArray.append(byteString[2 * c:(2 *c) + 2])
            c += 1
    
    targetHexData = FlipData(parsedValuesArray, hexByteFlipInterval, False)      

    outputFile = open('indexData_Offset' + str(hexByteShiftValue) + '.txt','w')
    
    for byte in targetHexData:
        outputFile.write("%s " % byte)

    outputFile.close()
    
finally:
    inputFile.close()
