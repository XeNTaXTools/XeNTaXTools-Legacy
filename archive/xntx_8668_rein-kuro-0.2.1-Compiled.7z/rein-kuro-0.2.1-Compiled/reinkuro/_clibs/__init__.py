"""Python interface for C implemented dark encryption used by NieR Rein."""
