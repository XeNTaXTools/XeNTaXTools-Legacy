from reinkuro.octo import init_arguments, cli

if __name__ == "__main__":
    __args__ = init_arguments()
    cli(__args__)
