#Ironsight Animation - ".bea" plugin
#By PeterZ
#Special thanks: shakotay2 and Bigchillghost
# v0.1 (2022.9.5) - need some fix

from inc_noesis import *
import noesis
import rapi
import os
import glob
bAddRootBone=True

def registerNoesisTypes():
    handle = noesis.register("Ironsight Animation", ".bea")
    noesis.setHandlerTypeCheck(handle, CheckType)
    # see also noepyLoadModelRPG
    noesis.setHandlerLoadModel(handle, LoadModel)
    noesis.logPopup()
    return 1

def CheckType(data):
    bs = NoeBitStream(data)
    idMagic = bs.readBytes(4)
    if idMagic != b'ANIM':
        return 0
    return 1

def LoadModel(data, mdlList):
    ctx = rapi.rpgCreateContext()
    skelbones=[]
    noeAnims=[]
    kfBones=[]
    kfBoneFrame_rotKeys=[]#[kfBoneIdx][frameIdx]
    kfBoneFrame_trnKeys=[]#[kfBoneIdx][frameIdx]
    bs = NoeBitStream(data)

    test = rapi.getDirForFilePath(rapi.getInputName())
    os.chdir(test)
    test = glob.glob("*.msh")
    try:
        skelfile = rapi.getDirForFilePath(rapi.getInputName()) + test[0]
    except:
        skelfile = ""
    if rapi.checkFileExists(skelfile):
        print('Loading skeleton from',skelfile)

        ss = rapi.loadIntoByteArray(skelfile)
        ss = NoeBitStream(ss)
        ss.seek(0x24)
        skelBoneCount=ss.readUInt()
        print('skeleton BoneCount',str(skelBoneCount))

        if(bAddRootBone):
            tmp=b'0000000000000000'
            skelbones.append(NoeBone(0, 'root', NoeQuat.fromBytes(tmp).toMat43(), None, -1))#add  rootBone
        for skelBoneIndex in range(0,skelBoneCount):
            skelBoneName='bone'+str(skelBoneIndex)
            getPos=ss.tell()+56
            skelBoneHash=ss.readInt()
            unk=ss.readInt()
            skelBoneParent=ss.readInt()
            x=ss.readFloat();y=ss.readFloat();z=ss.readFloat()
            skelBoneMtx = NoeQuat.fromBytes(ss.readBytes(16)).toMat43()
            skelBoneMtx.__setitem__(3,(x,y,z))
            if(bAddRootBone):
                skelBoneIndex=skelBoneIndex+1
                skelBoneParent=skelBoneParent+1

            skelNewBone = NoeBone(skelBoneIndex, skelBoneName, skelBoneMtx, None, int(skelBoneParent))
            skelbones.append(skelNewBone)
            ss.seek(getPos, NOESEEK_ABS)
        print('Finish Loading skeleton')  
    
    print("Loading Animation from",rapi.getInputName())

    bs.readBytes(4)#ANIM
    fileVersion=bs.readUInt()
    print("fileVersion",str(fileVersion))
    bs.readBytes(4)
    kfTotalBoneCount=bs.readUInt()
    print("kfTotalBoneCount",str(kfTotalBoneCount))
    for i in range(kfTotalBoneCount):
        kfBoneFrame_rotKeys.append([])
        kfBoneFrame_trnKeys.append([])
    kfTotalFrameCount=bs.readUInt()
    bs.seek(4,NOESEEK_REL)
    if(kfTotalBoneCount==skelBoneCount):
        for kframeIdx in range(kfTotalFrameCount):
            kfBoneCountSize=bs.readUInt()
            if(fileVersion==8):
                kfBoneCount=kfBoneCountSize
            elif(fileVersion==10):
                kfBoneCount=kfBoneCountSize//20
            if(kfBoneCount==kfTotalBoneCount):
                for kfBoneIdx in range(kfBoneCount):
                    rotQuat=NoeQuat((float(bs.readShort())/16384,float(bs.readShort())/16384,float(bs.readShort())/16384,float(bs.readShort())/16384))
                    posVec=NoeVec3((bs.readFloat(),bs.readFloat(),bs.readFloat()))
                    # print(posVec)
                    kfBoneFrame_rotKeys[kfBoneIdx].append(NoeKeyFramedValue(kframeIdx, rotQuat))
                    kfBoneFrame_trnKeys[kfBoneIdx].append(NoeKeyFramedValue(kframeIdx, posVec))
            else:
                raise
    else:
        print("BoneCount in Anim File",str(kfTotalBoneCount))
        print("BoneCount in Mesh File",str(skelBoneCount))
        print("Mesh file dismatch")
        return 1
    es=noeStrFromBytes(bs.readBytes(bs.readUInt()))
    print("ES",es)
    #bea File END

    for kfBoneIdx in range(kfTotalBoneCount):
        if(bAddRootBone):
            kfBone = NoeKeyFramedBone(kfBoneIdx+1)
        else:
            kfBone = NoeKeyFramedBone(kfBoneIdx)
        kfBone.setRotation(kfBoneFrame_rotKeys[kfBoneIdx], noesis.NOEKF_ROTATION_QUATERNION_4, noesis.NOEKF_INTERPOLATE_LINEAR)
        kfBone.setTranslation(kfBoneFrame_trnKeys[kfBoneIdx], noesis.NOEKF_TRANSLATION_VECTOR_3, noesis.NOEKF_INTERPOLATE_LINEAR)
        kfBones.append(kfBone)
    noeAnims.append(NoeKeyFramedAnim("Ironsight Animation", skelbones, kfBones, 1))
    mdl = NoeModel([],skelbones,noeAnims)
    mdlList.append(mdl)
    return 1



