import newGameLib
from newGameLib import *
import Blender	

class Section:pass
class Model:pass

def i3sParser(filename,g):
	#g.debug=True
	g.word(4)
	A=g.i(45)
	
	g.seek(A[3])
	stringList=g.read(A[5]).split('\x0d\x0a')
	print len(stringList)
	
	g.seek(A[8])
	sectionList=[]
	for m in range(A[7]):
		section=Section()
		sectionList.append(section)
		section.info=g.i(7)
		section.name=stringList[section.info[0]]
		
	modelList=[]
	for i,section in enumerate(sectionList):
		g.seek(section.info[3])
		print i,section.name,g.tell()
		if section.name=='i3TextureBindAttr':
			B=g.H(1)+g.B(6)
			diffuse=g.dirname+os.sep+'converted_'+os.path.basename(stringList[B[1]]).split('.')[0]+'.dds'
			#print diffuse
			
		if section.name=='i3NormalMapBindAttr':
			B=g.H(1)+g.B(2)
			normal=g.dirname+os.sep+'converted_'+os.path.basename(stringList[B[1]]).split('.')[0]+'.dds'
			#print normal
			
		if section.name=='i3SpecularMapBindAttr':
			B=g.H(1)+g.B(2)
			specular=g.dirname+os.sep+'converted_'+os.path.basename(stringList[B[1]]).split('.')[0]+'.dds'
			#print specular
		
		if section.name=='i3AttrSet':
			mat=Mat()
			mat.TRIANGLE=True
			#mesh.matList.append(mat)
			try:mat.diffuse=diffuse
			except: pass
			try:mat.normal=normal
			except: pass
			try:mat.specular=specular
			except: pass
			g.word(g.B(1)[0])
			g.word(4)
			B=g.i(4)
			#print B
			g.word(4)
			B=g.i(3)
			#print B
			g.i(B[0])
		
		if section.name=='i3VertexArray':
			print '='*50
			mesh=Mesh()
			#mesh.TRIANGLE=True
			model.meshList.append(mesh)
			g.word(4)
			B=g.i(4)
			print B
			g.f(5)
			#g.debug=False
			mesh.vertType=B[0]
			
			if B[0]==574631:mesh.stride=68
			elif B[0]==574595:mesh.stride=44
			elif B[0]==296103:mesh.stride=64
			elif B[0]==296067:mesh.stride=40
			elif B[0]==17575:mesh.stride=60
			elif B[0]==11779:mesh.stride=68
			elif B[0]==1191:mesh.stride=56
			elif B[0]==1155:mesh.stride=32
			elif B[0]==297127:mesh.stride=72
			elif B[0]==18599:mesh.stride=68
			elif B[0]==581799:mesh.stride=124
			elif B[0]==575619:mesh.stride=52
			elif B[0]==297091:mesh.stride=48
			elif B[0]==581763:mesh.stride=100
			elif B[0]==18563:mesh.stride=44
			elif B[0]==17539:mesh.stride=36
			elif B[0]==17547:mesh.stride=40
			elif B[0]==574639:mesh.stride=72
			else:
				print 'UNKNOW STRIDE for:',B[0],g.tell()
				break
			
			
			
			
			skin=Skin()
			mesh.skinList.append(skin)
			mesh.vertStreamOffset=g.tell()
			for m in range(B[1]):
				t=g.tell()
				mesh.vertPosList.append(g.f(3))
				if mesh.stride==72:
					g.seek(t+28)
					mesh.vertUVList.append(g.f(2))
					mesh.skinIndiceList.append(g.B(3))
					g.seek(1,1)
					w1,w2=g.f(2)
					mesh.skinWeightList.append([w1,w2,1-(w1+w2)])
				if mesh.stride==68:
					g.seek(t+24)
					mesh.vertUVList.append(g.f(2))
					mesh.skinIndiceList.append(g.B(3))
					g.seek(1,1)
					w1,w2=g.f(2)
					mesh.skinWeightList.append([w1,w2,1-(w1+w2)])
				if mesh.stride==64:
					g.seek(t+24)
					mesh.vertUVList.append(g.f(2))
					mesh.skinIndiceList.append(g.B(3))
					g.seek(1,1)
					w1,w2=g.f(2)
					mesh.skinWeightList.append([w1,w2,1-(w1+w2)])
				if mesh.stride==60:
					g.seek(t+24)
					mesh.vertUVList.append(g.f(2))
					mesh.skinIndiceList.append(g.B(4))
					mesh.skinWeightList.append([1.0])
				if mesh.stride==56:
					g.seek(t+24)
					mesh.vertUVList.append(g.f(2))
					#mesh.skinIndiceList.append(g.B(4))
					#mesh.skinWeightList.append([1.0])
				if mesh.stride==44:
					g.seek(t+24)
					mesh.vertUVList.append(g.f(2))
					mesh.skinIndiceList.append(g.B(3))
					g.seek(1,1)
					w1,w2=g.f(2)
					mesh.skinWeightList.append([w1,w2,1-(w1+w2)])
				if mesh.stride==40:
					g.seek(t+28)
					mesh.vertUVList.append(g.f(2))
					mesh.skinIndiceList.append(g.B(4))
					mesh.skinWeightList.append([1.0])
				if mesh.stride==36:
					g.seek(t+24)
					mesh.vertUVList.append(g.f(2))
					mesh.skinIndiceList.append(g.B(3))
					g.seek(1,1)
					w1,w2=g.f(2)
					mesh.skinWeightList.append([w1,w2,1-(w1+w2)])
				if mesh.stride==32:
					g.seek(t+24)
					mesh.vertUVList.append(g.f(2))
					#mesh.skinIndiceList.append(g.B(4))
					#mesh.skinWeightList.append([1.0])
				"""if B[0]==574631:
					g.seek(t+24)
					mesh.vertUVList.append(g.f(2))
					mesh.skinIndiceList.append(g.B(4))
					mesh.skinWeightList.append(g.f(2))"""
				g.seek(t+mesh.stride)
			#g.debug=True
			
		if section.name=='i3IndexArray':
			print '-'*40
			g.word(4)
			B=g.i(7)#7
			#g.debug=False
			list=g.H(B[0])
			print
			print min(list),max(list)
			print
			mat.IDStart=len(mesh.indiceList)
			mat.IDCount=len(list)
			mesh.indiceList.extend(list)
			#g.debug=True
			#break
			
			mesh.matList.append(mat)
			
		if section.name=='i3GeometryAttr':
			g.word(4)
			g.B(9)
			B=g.i(3)
			#print B
			
			g.f(10)
			
		if section.name=='i3Geometry':
			g.word(g.B(1)[0])
			g.word(4)
			g.i(5)
			
		if section.name=='i3LOD':
			g.word(4)
			g.i(11)
			
		if section.name=='i3Body':
			g.word(g.B(1)[0])
			g.word(4)
			g.i(4)
			g.word(4)
			g.f(1)[0]
			g.i(11)
			
		if section.name=='i3SceneGraphInfo':
			g.word(g.B(1)[0])
			g.word(4)
			g.i(9)
			
		if section.name=='i3Transform':
			g.word(g.B(1)[0])
			g.word(4)
			g.i(6)
			
		if section.name=='i3MatrixArray':
			print '#'*30,'bind'
			model=Model()
			modelList.append(model)
			model.meshList=[]
			bindskeleton=Skeleton()
			model.bindSkeleton=bindskeleton
			bindskeleton.name='bind'
			bindskeleton.ARMATURESPACE=True
			bindskeleton.NICE=True
			boneCount=g.i(1)[0]
			print 'bonecount:',boneCount
			for m in range(boneCount):
				bone=Bone()
				bone.matrix=Matrix4x4(g.f(16)).invert()
				bindskeleton.boneList.append(bone)
			#bindskeleton.draw()
			
			
		if section.name=='i3BoneMatrixListAttr':
			print '#'*30,'pose'
			g.word(4)
			A=g.i(11)
			print A
			poseskeleton=Skeleton()
			model.poseSkeleton=poseskeleton
			poseskeleton.name='pose'
			poseskeleton.BONESPACE=True
			poseskeleton.NICE=True
			slashList={}
			for m in range(A[0]):
				bone=Bone()
				tm=g.tell()
				bone.name=g.find('\x00')
				g.seek(tm+48)
				matrix=Matrix4x4(g.f(16))
				bone.matrix=matrix
				g.seek(tm+112)
				slash=g.i(1)[0]
				slashList[slash]=bone.name
				if slash-1>0:
					bone.parentName=slashList[slash-1]
				g.seek(tm+128)
				#print '  '*slash,bone.name,bone.parentID
				poseskeleton.boneList.append(bone)
		
		
	for j,model in enumerate(modelList):
		if model.poseSkeleton is not None:
			model.poseSkeleton.name+='-'+str(j)
			model.poseSkeleton.draw()
		if model.bindSkeleton is not None:		
			for i,bone in 	enumerate(model.poseSkeleton.boneList):
				model.bindSkeleton.boneList[i].name=model.poseSkeleton.boneList[i].name
			model.bindSkeleton.name+='-'+str(j)
			model.bindSkeleton.draw()
	
	
		for mesh in model.meshList:
			mesh.boneNameList=model.poseSkeleton.boneNameList
			print mesh.vertType,mesh.stride,mesh.vertStreamOffset
			mesh.draw()
			if model.bindSkeleton is not None:
				bindPose(model.bindSkeleton.object,model.poseSkeleton.object,mesh.object)
			
			model.poseSkeleton.object.makeParentDeform([mesh.object],1,0)
		
	g.tell()
	
def Parser(filename):	
	print '='*70
	print filename
	print '='*70
	ext=filename.split('.')[-1].lower()	
	
	if ext=='i3s':
		file=open(filename,'rb')
		g=BinaryReader(file)
		i3sParser(filename,g)
		file.close()
 
	
Blender.Window.FileSelector(Parser,'import','files: *.i3s') 
	