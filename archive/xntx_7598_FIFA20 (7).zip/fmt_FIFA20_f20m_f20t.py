# FIFA20 model/texture importer by Bigchillghost

from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("FIFA 20", ".f20m")
	noesis.setHandlerTypeCheck(handle, checkType)
	noesis.setHandlerLoadModel(handle, modelLoadModel)
	
	handle = noesis.register("FIFA 20", ".f20t")
	noesis.setHandlerTypeCheck(handle, checkType)
	noesis.setHandlerLoadRGBA(handle, textureLoadRGBA)
	#noesis.logPopup()
	return 1

#check if it's this type based on the data
def checkType(data):
	if len(data) < 0x80:
		return 0
	return 1

#load the model
def modelLoadModel(data, mdlList):
	#noesis.logPopup()
	print("handling %s"%rapi.getInputName())
	ctx = rapi.rpgCreateContext()
	bs = NoeBitStream(data)
	bs.seek(0x20, NOESEEK_REL)
	lodOffset = []
	for j in range(0, 7):
		lodOffset.append(bs.readUInt())
		bs.seek(4, NOESEEK_REL)
	meshPathStrOffset = bs.readUInt64()
	meshNameStrOffset = bs.readUInt64()
	bs.seek(0x2C, NOESEEK_REL)
	lodNum = bs.readUShort()
	unknownCnt = bs.readUShort()
	MatrixCnt = bs.readUShort()
	BBoxCnt = bs.readUShort()
	MatrixOffset = bs.readUInt()
	bs.seek(4, NOESEEK_REL)
	if lodOffset[0] > 0xA0:
		BBoxOffset = bs.readUInt()
		bs.seek(8, NOESEEK_REL)
	
	subMeshNum = []
	infoOffset = []
	indexTypeFlag = []
	indexSize = []
	vertSize = []
	srcMD5 = []
	dataOffset = []
	lodNameStrOffset = []
	for i in range(0, lodNum):
		bs.seek(lodOffset[i], NOESEEK_ABS)
		bs.seek(8, NOESEEK_REL)
		subMeshNum.append(bs.readUInt())
		infoOffset.append(bs.readUInt())
		bs.seek(0x34, NOESEEK_REL)
		meshIdxCnt = bs.readUInt()
		meshIdxBufOffset = bs.readUInt()
		bs.seek(8, NOESEEK_REL)
		indexTypeFlag.append(bs.readUInt())
		indexSize.append(bs.readUInt())
		vertSize.append(bs.readUInt())
		partA = bs.readUInt()
		partB = bs.readUShort()
		partC = bs.readUShort()
		partD = bs.readBytes(8)
		srcMD5.append([partA,partB,partC,partD])
		dataOffset.append(bs.readInt()) # -1 for external source
		bs.seek(0x10, NOESEEK_REL)
		lodNameStrOffset.append(bs.readUInt())
	useLodID = 0
	if dataOffset[useLodID] == -1: # external data
		srcPath = rapi.getDirForFilePath(rapi.getInputName())
		md5 = srcMD5[useLodID]
		srcMD5Str = "%08x-%04x-%04x-%02x%02x-"%(md5[0],md5[1],md5[2],md5[3][0],md5[3][1])
		for j in range(0, 6):
			srcMD5Str += "%02x"%md5[3][2+j]
		srcFileName = srcPath + srcMD5Str
		try:
			bsMesh = NoeBitStream(rapi.loadIntoByteArray(srcFileName))
		except RuntimeError:
			noesis.messagePrompt("file %s is not found!"%srcMD5Str)
			return 0
	else: # internal data
		if lodOffset[0] > 0xA0:
			if BBoxCnt == 0:
				BBoxCnt = MatrixCnt
			internalOffset = BBoxOffset + BBoxCnt * 0x20
		else:
			internalOffset = meshIdxBufOffset + meshIdxCnt
			internalOffset = ((internalOffset - 1) // 0x10 + 1)*0x10
		capSize = indexSize[0] + vertSize[0]
		bs.seek(internalOffset, NOESEEK_ABS)
		bsMesh = NoeBitStream(bs.readBytes(capSize))
		
	bs.seek(lodNameStrOffset[useLodID], NOESEEK_ABS)
	meshLodName = bs.readString()
	
	subMeshCnt = subMeshNum[useLodID]
	idxBaseOffset = vertSize[useLodID]
	bs.seek(infoOffset[useLodID], NOESEEK_ABS)
	for j in range(0, subMeshCnt):
		#### read mesh info ####
		bs.seek(8, NOESEEK_REL)
		MtlStrOffset = bs.readUInt()
		bs.seek(0xC, NOESEEK_REL)
		
		faceCnt = bs.readUInt()
		indexOffset = bs.readUInt()
		vertOffset = bs.readUInt()
		vertCnt = bs.readUInt()
		
		bs.seek(0x18, NOESEEK_REL)
		dataTypeDict = {}
		attrDict = {}
		attrIdxDict = {}
		for k in range(0, 16):
			attrFlag = bs.readUByte()
			dataTypeFlag = bs.readUByte()
			attrOffset = bs.readUByte()
			blockID = bs.readUByte()
			dataTypeDict[attrFlag] = dataTypeFlag
			attrDict[attrFlag] = attrOffset
			attrIdxDict[attrFlag] = blockID
			
		attrStride = []
		for k in range(0, 16):
			attrStride.append(bs.readUShort())
		bs.seek(0x40, NOESEEK_REL)
		
		curPosOfRes = bs.tell()
		bs.seek(MtlStrOffset, NOESEEK_ABS)
		matName = bs.readString()
		bs.seek(curPosOfRes, NOESEEK_ABS)
		
		if vertCnt == 0: # could happen, where the mesh doesn't exist
			continue
		#### hanlding mesh data ####
		posStride = attrStride[attrIdxDict[1]]
		posTypeFlag = dataTypeDict[1]
		posType = noesis.RPGEODATA_HALFFLOAT
		if posTypeFlag == 8:
			posType = noesis.RPGEODATA_HALFFLOAT
		elif posTypeFlag == 3:
			posType = noesis.RPGEODATA_FLOAT
		else:
			noesis.messagePrompt("unknown pos format: %x"%posTypeFlag)
			return 0
		lindexTypeFlag = indexTypeFlag[useLodID]
		indexType = noesis.RPGEODATA_USHORT
		indexTypeSize = 2
		if lindexTypeFlag == 0x2E:
			indexType = noesis.RPGEODATA_INT
			indexTypeSize = 4
		elif lindexTypeFlag != 0x21:
			noesis.messagePrompt("unknown index format: %x"%lindexTypeFlag)
			return 0
		lPosSize = vertCnt * posStride
		lIdxSize = faceCnt * indexTypeSize * 3
		lIdxOffset = indexOffset * indexTypeSize + idxBaseOffset
		bsMesh.seek(vertOffset, NOESEEK_ABS)
		posData = bsMesh.readBytes(lPosSize)
		bsMesh.seek(lIdxOffset, NOESEEK_ABS)
		idxData = bsMesh.readBytes(lIdxSize)
		meshName = "%s_mesh%03d"%(meshLodName, j)
		
		if 0x21 not in attrDict: # no UVs
			continue
		rapi.rpgSetName(meshName)
		rapi.rpgSetMaterial(matName)
		rapi.rpgBindPositionBuffer(posData, posType, posStride)
		if 6 in attrDict:
			nmID = attrIdxDict[6]
			nmStride = attrStride[nmID]
			nmSize = vertCnt * nmStride
			nmOffset = 0
			for k in range(0, nmID):
				nmOffset += attrStride[k]
			nmOffset *= vertCnt
			nmOffset += vertOffset
			bsMesh.seek(nmOffset, NOESEEK_ABS)
			nmData = bsMesh.readBytes(nmSize)
			rapi.rpgBindNormalBuffer(nmData, noesis.RPGEODATA_HALFFLOAT, nmStride)
		if 0x21 in attrDict:
			uvID = attrIdxDict[0x21]
			uvStride = attrStride[uvID]
			uvSize = vertCnt * uvStride
			uvOffset = 0
			for k in range(0, uvID):
				uvOffset += attrStride[k]
			uvOffset *= vertCnt
			uvOffset += vertOffset
			bsMesh.seek(uvOffset, NOESEEK_ABS)
			uvData = bsMesh.readBytes(uvSize)
			rapi.rpgBindUV1Buffer(uvData, noesis.RPGEODATA_HALFFLOAT, uvStride)
		if 0x22 in attrDict:
			uvID = attrIdxDict[0x22]
			uvStride = attrStride[uvID]
			uvSize = vertCnt * uvStride
			uvOffset = 0
			for k in range(0, uvID):
				uvOffset += attrStride[k]
			uvOffset *= vertCnt
			uvOffset += vertOffset
			bsMesh.seek(uvOffset, NOESEEK_ABS)
			uv2Data = bsMesh.readBytes(uvSize)
			rapi.rpgBindUV2Buffer(uv2Data, noesis.RPGEODATA_HALFFLOAT, uvStride)
		rapi.rpgCommitTriangles(idxData, indexType, faceCnt*3, noesis.RPGEO_TRIANGLE, 1)
		rapi.rpgClearBufferBinds()
	
	if rapi.rpgGetVertexCount() == 0:
		return 0
	mdl = rapi.rpgConstructModelSlim()
	mdlList.append(mdl)
	return 1

def textureLoadRGBA(data, texList):
	bs = NoeBitStream(data)
	bs.seek(0xC, NOESEEK_ABS)
	imgFmt = bs.readInt()
	bs.seek(6, NOESEEK_REL)
	Width = bs.readUShort()
	Height = bs.readUShort()
	bs.seek(4, NOESEEK_REL)
	mipNum = bs.readUShort()
	Hash1 = bs.readUInt()
	Hash2 = bs.readUShort()
	Hash3 = bs.readUShort()
	Hash4 = bs.readBytes(8)
	SrcDataFileName = "%08x-%04x-%04x-%02x%02x-"%(Hash1,Hash2,Hash3,Hash4[0],Hash4[1])
	for i in range(0, 6):
		SrcDataFileName += "%02x"%Hash4[2+i]
	SrcDataFileFullName = rapi.getDirForFilePath(rapi.getInputName()) + SrcDataFileName
	bs.seek(0x3C, NOESEEK_REL)
	dataSize = bs.readInt()
	try:
		PixelData = rapi.loadIntoByteArray(SrcDataFileFullName)
	except RuntimeError:
		noesis.messagePrompt("Error: no such file as %s"%SrcDataFileName)
		return 0
	if imgFmt == 0x36 or imgFmt == 0x37 or imgFmt == 0x39: #DXT1
		texFmt = noesis.NOESISTEX_DXT1
	elif imgFmt == 0x3C or imgFmt == 0x3D: #DXT5
		texFmt = noesis.NOESISTEX_DXT5
	elif imgFmt == 0x6 or imgFmt == 0x3E: # ATI1/BC4
		PixelData = rapi.imageDecodeDXT(PixelData, Width, Height, noesis.FOURCC_ATI1)
		texFmt = noesis.NOESISTEX_RGBA32
	elif imgFmt == 0x3F: # ATI2/BC5
		PixelData = rapi.imageDecodeDXT(PixelData, Width, Height, noesis.FOURCC_ATI2)
		texFmt = noesis.NOESISTEX_RGBA32
	elif imgFmt == 0x40: # BC6
		PixelData = rapi.imageDecodeDXT(PixelData, Width, Height, noesis.FOURCC_BC6H)
		texFmt = noesis.NOESISTEX_RGBA32
	elif imgFmt == 0x42 or imgFmt == 0x43: # BC7
		PixelData = rapi.imageDecodeDXT(PixelData, Width, Height, noesis.FOURCC_BC7)
		texFmt = noesis.NOESISTEX_RGBA32
	elif imgFmt == 0x12 or imgFmt == 0x14 or imgFmt == 0x1D: # RGBA
		PixelData = rapi.imageDecodeRaw(PixelData, Width, Height, "g8r8a8b8")
		texFmt = noesis.NOESISTEX_RGBA32
	else:
		noesis.messagePrompt("Error: unsupported image format: " + repr(imgFmt))
		return 0
	texList.append(NoeTexture(rapi.getInputName(), Width, Height, PixelData, texFmt))
	return 1